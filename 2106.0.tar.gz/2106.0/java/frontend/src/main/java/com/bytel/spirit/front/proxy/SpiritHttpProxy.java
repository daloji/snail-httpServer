/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.front.proxy;

import com.bytel.ravel.common.data.exchange.generated.RavelResponse;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.request.IRavelRequest;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.frontend.proxy.HttpProxy;
import com.bytel.ravel.frontend.proxy.generated.Proxy;
import com.bytel.ravel.frontend.proxy.generated.URI;

/**
 *
 * @author jgregori
 * @version ($Revision$ $Date$)
 */
public class SpiritHttpProxy extends HttpProxy
{

  /**
   * @param proxy_p
   *          proxy
   */
  public SpiritHttpProxy(Proxy proxy_p)
  {
    super(proxy_p);
  }

  @Override
  protected void sendHttpRequest(URI uri_p, IRavelRequest request_p) throws RavelException
  {
    String msgId = SpiritProxyUtils.getMsgIdFromHeader(request_p.getRequestHeader());//Get msgId from Header if present, null otherwise
    if (StringTools.isNotNullOrEmpty(msgId))
    {
      request_p.setMsgId(msgId);
    }
    super.sendHttpRequest(uri_p, request_p);

    // add RequestId-spirit in the response headers
    if ((request_p.getResponse() != null) && (request_p.getResponse().getGenericResponse() != null))
    {
      RavelResponse.ResponseHeader header = new RavelResponse.ResponseHeader();
      header.setName(SpiritProxyUtils.X_REQUEST_ID_SPIRIT);
      header.setValue(request_p.getMsgId());
      // note that getResponseHeader() cannot ne null.
      request_p.getResponse().getGenericResponse().getResponseHeader().add(header);
    }
  }

}
