/*******************************************************************************
 * $Id: DESKey.java 1646 2017-10-05 12:50:04Z vthibaul $
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.front.common.encryption;

import com.bytel.ravel.common.encryption.IPassPhrase;

/**
 * Specific DES Key pass phrase
 * 
 * @author lchanyip
 * @version ($Revision: 1646 $ $Date: 2017-10-05 14:50:04 +0200 (jeu. 05 oct. 2017) $)
 */
public class DESKey implements IPassPhrase
{
  /**
   * Key phrase.
   */
  private final static String DES_ENCRYPTION_PASS_PHRASE = "Bruce Lee is the best of the best of the best..."; //$NON-NLS-1$

  @Override
  public String getPassPhrase()
  {
    return DES_ENCRYPTION_PASS_PHRASE;
  }
}
