/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.front.proxy;

import java.util.List;

import com.bytel.ravel.common.data.exchange.generated.RavelRequest.RequestHeader;

/**
 * Class containing common methods convenient for Proxy classes
 *
 * @author jgregori
 * @version ($Revision$ $Date$)
 */
public final class SpiritProxyUtils
{

  /**
   * Name of the header containing msgId
   */
  public static final String X_REQUEST_ID_SPIRIT = "X-Request-Id-Spirit"; //$NON-NLS-1$

  /**
   * Retrieve the msgId from Header values. If the header X-Message-Id is not present return null.
   *
   * @param requestHeader_p
   *          The list of request headers.
   * @return The X-Message-Id header value, null if header is not present
   */
  public static String getMsgIdFromHeader(List<RequestHeader> requestHeader_p)
  {
    for (RequestHeader h : requestHeader_p)
    {
      //check if the header is the X-Message-Id
      if (X_REQUEST_ID_SPIRIT.equalsIgnoreCase(h.getName())) //according to Tracabilite STBL header names are not case sensitive
      {
        return h.getValue();
      }
    }
    return null;
  }

  /**
   *
   */
  private SpiritProxyUtils()
  {

  }
}
