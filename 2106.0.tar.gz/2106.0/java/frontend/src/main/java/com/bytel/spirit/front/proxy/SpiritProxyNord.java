/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.front.proxy;

import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.request.IRavelRequest;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.frontend.proxy.ProxyNord;
import com.bytel.ravel.frontend.proxy.generated.Proxy;

/**
 *
 * Proxy SpiritProxyNord. Utilisé sur Spirit pour appeler le système Spirit ou OSS legacy ou les deux.
 *
 * @author jgregori
 * @version ($Revision$ $Date$)
 */
public class SpiritProxyNord extends ProxyNord
{

  /**
   * @param proxy_p
   */
  public SpiritProxyNord(Proxy proxy_p)
  {
    super(proxy_p);
  }

  @Override
  public IRavelRequest sendRequest(IRavelRequest request_p) throws RavelException
  {
    String msgId = SpiritProxyUtils.getMsgIdFromHeader(request_p.getRequestHeader());//Get msgId from Header if present, null otherwise
    if (StringTools.isNotNullOrEmpty(msgId))
    {
      request_p.setMsgId(msgId);
    }
    return super.sendRequest(request_p);
  }

}
