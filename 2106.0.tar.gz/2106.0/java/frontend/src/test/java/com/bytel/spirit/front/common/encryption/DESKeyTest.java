/*******************************************************************************
* $Id: DESKeyTest.java 1646 2017-10-05 12:50:04Z vthibaul $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.front.common.encryption;

import org.junit.Assert;
import org.junit.Test;

/**
 * DESKey test class
 *
 * @author lchanyip
 * @version ($Revision: 1646 $ $Date: 2017-10-05 14:50:04 +0200 (jeu. 05 oct. 2017) $)
 */
public class DESKeyTest
{
  /**
   * Test GetPassPhrase OK
   */
  @Test
  public void TestGetPassPhrase()
  {
    DESKey key = new DESKey();
    Assert.assertNotNull(key.getPassPhrase());
  }
}
