/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.front.proxy;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.easymock.EasyMock;
import org.easymock.EasyMockSupport;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.Mock;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.reflect.Whitebox;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.bytel.ravel.common.configuration.ACManager;
import com.bytel.ravel.common.data.exchange.generated.RavelRequest.RequestHeader;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.log.event.SystemLogEvent;
import com.bytel.ravel.frontend.proxy.CallSpiritThread;
import com.bytel.ravel.frontend.proxy.IProxy;
import com.bytel.ravel.frontend.proxy.generated.Proxy;
import com.bytel.ravel.frontend.proxy.generated.URI;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.client.HttpClientClassic;
import com.bytel.ravel.net.loadbalancing.LoadBalancerFactory;

/**
 *
 * @author jgregori
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({ CallSpiritThread.class, SpiritProxyNord.class, RavelLogger.class, LoadBalancerFactory.class })
public class SpiritProxyNordTest extends EasyMockSupport
{
  @BeforeClass
  public static void init() throws RavelException
  {
    try
    {
      ACManager.getInstance().setApplicationContext(null);
    }
    catch (Exception ex)
    {
      // nothing to do: not initialized
    }
    new ClassPathXmlApplicationContext("classpath:BeansProcessTestMocks.xml"); //$NON-NLS-1$
  }

  /**
   * Mock du proxy
   */
  @Mock
  private Proxy _proxyMock;

  /**
   * The HTTP Client
   */
  @Mock
  private HttpClientClassic _httpClientMock;

  /**
   * Instance of {@code ProxyNord}
   */
  private IProxy _proxy;

  /**
   * Initialization of tests
   *
   * @throws Exception
   *           Exception to be thrown in case of failure
   */
  @Before
  public void setUp() throws Exception
  {
    // on réinitialise tous les mocks afin de ne pas avoir d'interférence entre les tests
    PowerMock.resetAll();
    _proxyMock = PowerMock.createMock(Proxy.class);
    _httpClientMock = PowerMock.createMock(HttpClientClassic.class);
  }

  /**
   * Scenario: Send request through SpiritProxyNord. <br>
   * Input: add X-ESSAGE-ID header into requestHeader <br>
   * Result: msgId is set in the request with X-Request-Id header value.
   *
   * @throws Exception
   *           This exception should never happen except if a mistake was made in the code
   */
  @Test
  public void testSpiritProxyNord_001() throws Exception
  {
    EasyMock.expect(_proxyMock.getLoadBalancer()).andReturn(null);
    EasyMock.expect(_proxyMock.getURI()).andReturn(getURI());

    String msgId = UUID.randomUUID().toString();
    List<RequestHeader> requestHeader = ProxyTestUtils.buildRequestHeader(msgId);
    Request request = new Request("operation1", "process123", "client123"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    request.getRequestHeader().addAll(requestHeader);

    PowerMock.expectNew(HttpClientClassic.class, EasyMock.anyString(), EasyMock.anyString(), EasyMock.anyInt()).andReturn(_httpClientMock);
    _httpClientMock.addHeader(requestHeader.get(0).getName(), requestHeader.get(0).getValue());
    EasyMock.expectLastCall();

    PowerMock.mockStatic(RavelLogger.class);
    RavelLogger.log(EasyMock.anyObject(SystemLogEvent.class));

    EasyMock.expect(_proxyMock.getTimeOut()).andReturn(0);
    EasyMock.expect(_proxyMock.getResponseTimeOut()).andReturn(null);

    _httpClientMock.send(request);
    EasyMock.expectLastCall();

    PowerMock.replayAll();
    _proxy = new SpiritProxyNord(_proxyMock);
    _proxy.init();
    Whitebox.setInternalState(_proxy, "_mode", "NOMINAL_CIBLE"); //$NON-NLS-2$
    _proxy.sendRequest(request);
    PowerMock.verifyAll();

    assertEquals(msgId, request.getMsgId());

  }

  /**
   * Scenario: Send request through SpiritProxyNord. <br>
   * Input: send request with any request header <br>
   * Result: Existing msgId is conserved in the request if X-Request-Id is not present
   *
   * @throws Exception
   *           This exception should never happen except if a mistake was made in the code
   */
  @Test
  public void testSpiritProxyNord_002() throws Exception
  {
    EasyMock.expect(_proxyMock.getLoadBalancer()).andReturn(null);
    EasyMock.expect(_proxyMock.getURI()).andReturn(getURI());

    Request request = new Request("operation1", "process123", "client123"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    String msgId = UUID.randomUUID().toString();
    request.setMsgId(msgId);

    PowerMock.mockStatic(RavelLogger.class);
    RavelLogger.log(EasyMock.anyObject(SystemLogEvent.class));

    EasyMock.expect(_proxyMock.getTimeOut()).andReturn(0);
    EasyMock.expect(_proxyMock.getResponseTimeOut()).andReturn(null);
    PowerMock.expectNew(HttpClientClassic.class, EasyMock.anyString(), EasyMock.anyString(), EasyMock.anyInt()).andReturn(_httpClientMock);

    _httpClientMock.send(request);
    EasyMock.expectLastCall();

    PowerMock.replayAll();
    _proxy = new SpiritProxyNord(_proxyMock);
    _proxy.init();
    Whitebox.setInternalState(_proxy, "_mode", "NOMINAL_CIBLE"); //$NON-NLS-2$
    _proxy.sendRequest(request);
    PowerMock.verifyAll();
    assertEquals(msgId, request.getMsgId()); //the existing msgId is conserved if no X-MESSAGE-ID header is present.

  }

  /**
   * Build list of RequestHeader containing the X-Request-Id
   *
   * @return list of RequestHeader
   */
  private List<RequestHeader> buildRequestHeader()
  {

    List<RequestHeader> requestHeaders = new ArrayList<>();

    RequestHeader h = new RequestHeader();
    h.setName("X-Request-Id-Spirit");
    h.setValue(UUID.randomUUID().toString());
    requestHeaders.add(h);
    return requestHeaders;

  }

  /**
   * Builds a list with one URI
   *
   * @return URI list
   */
  private List<URI> getURI()
  {
    List<URI> uriL = new ArrayList<>();
    URI uri = new URI();
    uri.setAccessPoint("http://localhost"); //$NON-NLS-1$
    uriL.add(uri);
    return uriL;
  }

}
