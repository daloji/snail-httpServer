/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.front.proxy;

import java.util.ArrayList;
import java.util.List;

import com.bytel.ravel.common.data.exchange.generated.RavelRequest.RequestHeader;

/**
 *
 * @author jgregori
 * @version ($Revision$ $Date$)
 */
public final class ProxyTestUtils
{

  /**
   * Build list of RequestHeader containing the X-Request-Id
   *
   * @param msgId_p
   *          msgId
   *
   * @return list of RequestHeader
   */
  public static List<RequestHeader> buildRequestHeader(String msgId_p)
  {

    List<RequestHeader> requestHeaders = new ArrayList<>();

    RequestHeader h = new RequestHeader();
    h.setName(SpiritProxyUtils.X_REQUEST_ID_SPIRIT);
    h.setValue(msgId_p);
    requestHeaders.add(h);
    return requestHeaders;

  }

  /**
   *
   */
  private ProxyTestUtils()
  {
  }
}
