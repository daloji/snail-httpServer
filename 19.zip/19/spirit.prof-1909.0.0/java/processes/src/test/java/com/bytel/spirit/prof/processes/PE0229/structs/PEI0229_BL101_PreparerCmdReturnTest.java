/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PE0229.structs;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PowerMockListener;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.testlisteners.FieldDefaulter;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.modules.junit4.PowerMockRunnerDelegate;
import org.powermock.reflect.Whitebox;
import org.springframework.test.context.ContextConfiguration;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.test.podam.PodamBytelJUnit4ClassRunner;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.spirit.common.shared.saab.cmd.Commande;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author jjoly
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PowerMockListener(FieldDefaulter.class)
@PowerMockRunnerDelegate(PodamBytelJUnit4ClassRunner.class)
@ContextConfiguration("classpath:BeansProcessTestMocks.xml")
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
@PrepareForTest({ PEI0229_BL101_PreparerCmdReturn.class })
public final class PEI0229_BL101_PreparerCmdReturnTest
{
  /**
   * bean Factory generation
   */
  private static PodamFactory __podam;

  /**
   *
   */
  private static Retour __retour;

  /**
   *
   */
  private static String __idActionCorrective;

  /**
   *
   */
  private static Commande __commande;

  /**
   * Initialize before all tests
   *
   * @throws Exception
   *           On errors Exception to be thrown in case of failure
   */
  @BeforeClass
  public static void setUpBeforeClass() throws Exception
  {
    __podam = new PodamFactoryImpl();
    __podam.getStrategy().setMemoization(false);
    __podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());

    __retour = RetourFactory.createOkRetour();
    __idActionCorrective = __podam.manufacturePojo(String.class);
    __commande = __podam.manufacturePojoWithFullData(Commande.class);
  }

  /**
   * Instance to evaluate
   */
  private PEI0229_BL101_PreparerCmdReturn _instance;

  /**
   * Exception has been thrown
   */
  private boolean _exception;

  /**
   * Initialize before tests
   *
   * @throws Exception
   *           On errors Thrown in case of error during switch in attributes of parent class
   */
  @Before
  public void setUp() throws Exception
  {
    _instance = null;
    _exception = false;

    PowerMock.resetAll();
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.prof.processes.PE0229.structs.PEI0229_BL101_PreparerCmdReturn#PEI0229_BL101_PreparerCmdReturn(com.bytel.ravel.common.business.generated.Retour)}.<br/>
   * <b>Entrées:</b>NULL value in input<br/>
   * <b>Attendu:</b>NullPointerException<br/>
   *
   * @throws Exception
   *           On errors
   */
  @Test
  public void testPEI0229_BL101_PreparerCmdReturn_001() throws Exception
  {
    try
    {
      PowerMock.replayAll();

      _instance = new PEI0229_BL101_PreparerCmdReturn(null);
    }
    catch (final NullPointerException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertTrue(_exception);

      assertNull(_instance);
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.prof.processes.PE0229.structs.PEI0229_BL101_PreparerCmdReturn#PEI0229_BL101_PreparerCmdReturn(com.bytel.ravel.common.business.generated.Retour)}.<br/>
   * <b>Entrées:</b><br/>
   * <b>Attendu:</b>OK<br/>
   *
   * @throws Exception
   *           On errors
   */
  @Test
  public void testPEI0229_BL101_PreparerCmdReturn_002() throws Exception
  {
    final Retour expected = __retour;
    Retour actual = null;

    try
    {
      PowerMock.replayAll();

      _instance = new PEI0229_BL101_PreparerCmdReturn(RetourFactory.createOkRetour());
      actual = Whitebox.getInternalState(_instance, "_retour"); //$NON-NLS-1$
    }
    catch (final Exception e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertFalse(_exception);

      assertNotNull(_instance);
      assertEquals(expected, actual);
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.prof.processes.PE0229.structs.PEI0229_BL101_PreparerCmdReturn#getRetour}.<br/>
   * <b>Entrées:</b><br/>
   * <b>Attendu:</b>OK<br/>
   *
   * @throws Exception
   *           On errors
   */
  @Test
  public void testPEI0229_BL101_PreparerCmdReturn_003() throws Exception
  {
    final Retour expected = __retour;
    Retour actual = null;

    try
    {
      PowerMock.replayAll();

      _instance = new PEI0229_BL101_PreparerCmdReturn(RetourFactory.createKO(null, null, null));
      Whitebox.setInternalState(_instance, "_retour", expected); //$NON-NLS-1$
      actual = _instance.getRetour();
    }
    catch (final Exception e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertNotNull(actual);
      assertEquals(expected, actual);
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.prof.processes.PE0229.structs.PEI0229_BL101_PreparerCmdReturn#setRetour(com.bytel.ravel.common.business.generated.Retour)}
   * <b>Entrées:</b><br/>
   * <b>Attendu:</b>OK<br/>
   *
   * @throws Exception
   *           On errors
   */
  @Test
  public void testPEI0229_BL101_PreparerCmdReturn_004() throws Exception
  {
    final Retour expected = __retour;
    Retour actual = null;

    try
    {
      PowerMock.replayAll();

      _instance = new PEI0229_BL101_PreparerCmdReturn(RetourFactory.createKO(null, null, null));
      _instance.setRetour(expected);
      actual = Whitebox.getInternalState(_instance, "_retour"); //$NON-NLS-1$
    }
    catch (final Exception e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertNotNull(actual);
      assertEquals(expected, actual);
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.prof.processes.PE0229.structs.PEI0229_BL101_PreparerCmdReturn#getIdActionCorrective()}.<br/>
   * <b>Entrées:</b><br/>
   * <b>Attendu:</b><br/>
   *
   * @throws Exception
   *           On errors
   */
  @Test
  public void testPEI0229_BL101_PreparerCmdReturn_005() throws Exception
  {
    final String expected = __idActionCorrective;
    String actual = null;

    try
    {
      PowerMock.replayAll();

      _instance = new PEI0229_BL101_PreparerCmdReturn(RetourFactory.createKO(null, null, null));
      Whitebox.setInternalState(_instance, "_idActionCorrective", expected); //$NON-NLS-1$
      actual = _instance.getIdActionCorrective();
    }
    catch (final Exception e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertNotNull(actual);
      assertEquals(expected, actual);
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.prof.processes.PE0229.structs.PEI0229_BL101_PreparerCmdReturn#setCommande(com.bytel.spirit.common.shared.saab.cmd.Commande)}.<br/>
   * <b>Entrées:</b><br/>
   * <b>Attendu:</b>OK<br/>
   *
   * @throws Exception
   *           On errors
   */
  @Test
  public void testPEI0229_BL101_PreparerCmdReturn_006() throws Exception
  {
    final String expected = __idActionCorrective;
    String actual = null;

    try
    {
      PowerMock.replayAll();

      _instance = new PEI0229_BL101_PreparerCmdReturn(RetourFactory.createKO(null, null, null));
      _instance.setIdActionCorrective(expected);
      actual = Whitebox.getInternalState(_instance, "_idActionCorrective"); //$NON-NLS-1$
    }
    catch (final Exception e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertNotNull(actual);
      assertEquals(expected, actual);
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.prof.processes.PE0229.structs.PEI0229_BL101_PreparerCmdReturn#getCommande()}.<br/>
   * <b>Entrées:</b><br/>
   * <b>Attendu:</b>OK<br/>
   *
   * @throws Exception
   *           On errors
   */
  @Test
  public void testPEI0229_BL101_PreparerCmdReturn_007() throws Exception
  {
    final Commande expected = __commande;
    Commande actual = null;

    try
    {
      PowerMock.replayAll();

      _instance = new PEI0229_BL101_PreparerCmdReturn(RetourFactory.createKO(null, null, null));
      Whitebox.setInternalState(_instance, "_commande", expected); //$NON-NLS-1$
      actual = _instance.getCommande();
    }
    catch (final Exception e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertNotNull(actual);
      assertEquals(expected, actual);
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.prof.processes.PE0229.structs.PEI0229_BL101_PreparerCmdReturn#setCommande(com.bytel.spirit.common.shared.saab.cmd.Commande)}.<br/>
   * <b>Entrées:</b><br/>
   * <b>Attendu:</b>OK<br/>
   *
   * @throws Exception
   *           On errors
   */
  @Test
  public void testPEI0229_BL101_PreparerCmdReturn_008() throws Exception
  {
    final Commande expected = __commande;
    Commande actual = null;

    try
    {
      PowerMock.replayAll();

      _instance = new PEI0229_BL101_PreparerCmdReturn(RetourFactory.createKO(null, null, null));
      _instance.setCommande(expected);
      actual = Whitebox.getInternalState(_instance, "_commande"); //$NON-NLS-1$
    }
    catch (final Exception e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertNotNull(actual);
      assertEquals(expected, actual);
    }
  }
}
