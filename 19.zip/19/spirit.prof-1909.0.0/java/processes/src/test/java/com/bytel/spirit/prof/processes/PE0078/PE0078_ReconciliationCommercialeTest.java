/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PE0078;

import static org.junit.Assert.assertEquals;

import java.io.Closeable;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.Mock;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.test.context.ContextConfiguration;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.data.exchange.generated.RavelRequest.RequestHeader;
import com.bytel.ravel.common.data.exchange.generated.RavelResponse;
import com.bytel.ravel.common.data.exchange.generated.RavelResponse.ResponseHeader;
import com.bytel.ravel.common.datetime.DateTimeManager;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.request.Parameter;
import com.bytel.ravel.common.factory.request.UrlParameters;
import com.bytel.ravel.common.factory.response.IRavelResponse;
import com.bytel.ravel.common.factory.response.RavelResponseFactory;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.utils.ACManagerUtil;
import com.bytel.ravel.common.utils.DateTimeTools.DateTimeFormatPattern;
import com.bytel.ravel.common.utils.Mode;
import com.bytel.ravel.common.utils.RetourFactoryForTU;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.net.http.HttpConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.ProcessManager;
import com.bytel.spirit.common.activities.shared.BL800_ObtenirSequence;
import com.bytel.spirit.common.activities.shared.BL800_ObtenirSequence.BL800_ObtenirSequenceBuilder;
import com.bytel.spirit.common.activities.shared.structs.UniqueIdConstant;
import com.bytel.spirit.common.connectors.rex.REXProxy;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.error.ReponseErreur;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.rex.ReconciliationCommerciale;
import com.bytel.spirit.common.shared.saab.rex.request.CreateOrUpdateReconciliationCommercialeRequest;
import com.bytel.spirit.prof.connectors.bssgp.activities.BSSGP_SI001_Resynchro;
import com.bytel.spirit.prof.connectors.bssgp.activities.BSSGP_SI001_Resynchro.BSSGP_SI001_ResynchroBuilder;
import com.bytel.spirit.prof.processes.PE0078.PE0078_ReconciliationCommerciale.ReconciliationCommercialeReturn;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author pramos
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@ContextConfiguration("classpath:BeansProcessTestMocks.xml")
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
@PrepareForTest({ REXProxy.class, PE0078_ReconciliationCommerciale.class, Tracabilite.class, BL800_ObtenirSequenceBuilder.class, BSSGP_SI001_ResynchroBuilder.class })
public class PE0078_ReconciliationCommercialeTest implements Closeable
{

  /**
   * SPRING context
   */
  private static ClassPathXmlApplicationContext __context;

  private static final String LOCATION_HEADER_URL_PARAM = "locationHeaderUrl"; //$NON-NLS-1$

  /**
   * Factory de génération des beans
   */
  private static PodamFactory __podam;

  static
  {
    __podam = new PodamFactoryImpl();
  }

  /**
   * Initialization method: Create: - spring context - connectors - service manager.
   *
   * @throws RavelException
   *           the exception
   */
  @BeforeClass
  public static void init() throws RavelException
  {

    // désactivation du cache podam
    __podam.getStrategy().setMemoization(false);
    __podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());

    ACManagerUtil.resetACManager();
    new ClassPathXmlApplicationContext("classpath:BeansProcessTestMocks.xml"); //$NON-NLS-1$

    HashMap<String, String> map = new HashMap<String, String>();
    map.put(PE0078_ReconciliationCommercialeTest.LOCATION_HEADER_URL_PARAM, "http://xxx/reconciliations-commerciales/"); //$NON-NLS-1$
    ConcurrentHashMap<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();

    processParams.put(StringConstants.EMPTY_STRING, map);

    DateTimeManager.getInstance().initialize(Mode.FIXED);
    DateTimeManager.getInstance().setFixedClockAt(DateTimeManager.getInstance().now());

  }

  /**
   * Instance of {@code PE0078_ReconciliationCommerciale}
   */
  private PE0078_ReconciliationCommerciale _processInstance;

  @Mock
  private BL800_ObtenirSequenceBuilder _bl800BuilderMock;

  @Mock
  private BL800_ObtenirSequence _bl800Mock;

  @Mock
  private BSSGP_SI001_ResynchroBuilder _si001BuilderMock;

  @Mock
  private BSSGP_SI001_Resynchro _si001Mock;

  /**
   * REX Proxy
   */
  @Mock
  private REXProxy _rexProxy;

  /**
   * The mock object {@code Request}
   */
  private Request _request;

  @Override
  public void close() throws IOException
  {
    __context.close();
  }

  /**
   * Scenario: BL001 failed to invalid URL parameter<br>
   * Input: The {clientOperateur} URL parameter not set<br>
   * Result:
   *
   * @throws Throwable
   */
  @Test
  public void PE0078_BL001_VerifierDonneesCreation_KO_001() throws Throwable
  {

    _request.setHttpMethod("POST"); //$NON-NLS-1$
    _request.setPayload(null);
    //   _request.getUrlParameters().getUrlParameters().add(new Pair<String, String>("clientOperateur", "BSS_GP"));
    //   _request.getUrlParameters().getUrlParameters().add(new Pair<String, String>("noCompte", "610123456789"));

    final ReponseErreur erreur = new ReponseErreur();
    erreur.setError(IMegSpiritConsts.NON_RESPECT_STI);
    erreur.setErrorDescription("clientOperateur non renseigné."); //$NON-NLS-1$
    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    response.setResult(new StringBuilder().append("{\"error\":\"").append(erreur.getError()).append("\",\"error_description\":\"").append(erreur.getErrorDescription()).append("\"}").toString()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    final Response expected = new Response(ErrorCode.KO_00400, response);

    _processInstance = new PE0078_ReconciliationCommerciale();

    _processInstance.initializeContext();
    _processInstance.run(_request);
    assertEquals(expected.getErrorCode(), _request.getResponse().getErrorCode());
    assertEquals(expected.getMarshalledResponseJson(), _request.getResponse().getMarshalledResponseJson());
  }

  /**
   * Scenario: BL001 failed to invalid URL parameter<br>
   * Input: The {idReconciliation} URL parameter not set<br>
   * Result:
   *
   * @throws Throwable
   */
  @Test
  public void PE0078_BL001_VerifierDonneesSuivi_KO_001() throws Throwable
  {

    _request.setHttpMethod("GET"); //$NON-NLS-1$
    _request.setPayload(null);
    //   _request.getUrlParameters().getUrlParameters().add(new Pair<String, String>("clientOperateur", "BSS_GP"));
    //   _request.getUrlParameters().getUrlParameters().add(new Pair<String, String>("noCompte", "610123456789"));

    final ReponseErreur erreur = new ReponseErreur();
    erreur.setError(IMegSpiritConsts.NON_RESPECT_STI);
    erreur.setErrorDescription("idReconciliation non renseigné."); //$NON-NLS-1$
    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    response.setResult(new StringBuilder().append("{\"error\":\"").append(erreur.getError()).append("\",\"error_description\":\"").append(erreur.getErrorDescription()).append("\"}").toString()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    final Response expected = new Response(ErrorCode.KO_00400, response);

    _processInstance = new PE0078_ReconciliationCommerciale();

    _processInstance.initializeContext();
    _processInstance.run(_request);
    assertEquals(expected.getErrorCode(), _request.getResponse().getErrorCode());
    assertEquals(expected.getMarshalledResponseJson(), _request.getResponse().getMarshalledResponseJson());
  }

  /**
   * Scenario: BL100 failed to invalid URL parameter<br>
   * Input: The {clientOperateur} URL parameter must be "BSS_GP"<br>
   * Result:
   *
   * @throws Throwable
   */
  @Test
  public void PE0078_BL100_CreerReconciliationCo_KO_001() throws Throwable
  {
    _request.setHttpMethod("POST"); //$NON-NLS-1$
    _request.setPayload(null);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    list.add(new Parameter("clientOperateur", "BSS_ENT")); //$NON-NLS-1$ //$NON-NLS-2$
    list.add(new Parameter("noCompte", "610123456789")); //$NON-NLS-1$ //$NON-NLS-2$
    urlParametersType.setUrlParameters(list);
    _request.setUrlParameters(urlParametersType);

    final ReponseErreur erreur = new ReponseErreur();
    erreur.setError(IMegSpiritConsts.RECONCIL_INCOMPATIBLE_CLIENT_OPE);
    erreur.setErrorDescription("Le client opérateur BSS_ENT ne permet pas la réconciliation commerciale"); //$NON-NLS-1$
    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    response.setResult(new StringBuilder().append("{\"error\":\"").append(erreur.getError()).append("\",\"error_description\":\"").append(erreur.getErrorDescription()).append("\"}").toString()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    final Response expected = new Response(ErrorCode.KO_00404, response);

    _processInstance = new PE0078_ReconciliationCommerciale();

    _processInstance.initializeContext();
    _processInstance.run(_request);
    assertEquals(expected.getErrorCode(), _request.getResponse().getErrorCode());
    assertEquals(expected.getMarshalledResponseJson(), _request.getResponse().getMarshalledResponseJson());
  }

  /**
   * Scenario: BL100 failed to invalid sequence<br>
   * Input: Valid {clientOperateur} and {noCompte} URL parameters"<br>
   * Result:
   *
   * @throws Throwable
   */
  @Test
  public void PE0078_BL100_CreerReconciliationCo_KO_002() throws Throwable
  {
    _request.setHttpMethod("POST"); //$NON-NLS-1$
    _request.setPayload(null);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    list.add(new Parameter("clientOperateur", "BSS_GP")); //$NON-NLS-1$ //$NON-NLS-2$
    list.add(new Parameter("noCompte", "610123456789")); //$NON-NLS-1$ //$NON-NLS-2$
    urlParametersType.setUrlParameters(list);
    _request.setUrlParameters(urlParametersType);

    PowerMock.expectNew(BL800_ObtenirSequenceBuilder.class).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.code(UniqueIdConstant.ID_RECONCILIATION_COMMERCIALE)).andReturn(_bl800BuilderMock);

    EasyMock.expect(_bl800BuilderMock.build()).andReturn(_bl800Mock);
    EasyMock.expect(_bl800Mock.execute(EasyMock.anyObject(PE0078_ReconciliationCommerciale.class))).andReturn(null);
    Retour bl800Retour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.CODE_SEQUENCE_INVALIDE, "", null); //$NON-NLS-1$
    EasyMock.expect(_bl800Mock.getRetour()).andReturn(bl800Retour);

    final ReponseErreur erreur = new ReponseErreur();
    erreur.setError(bl800Retour.getDiagnostic());
    erreur.setErrorDescription(bl800Retour.getLibelle());
    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    final Response expected = new Response(ErrorCode.KO_00500, ravelResponse);

    // On enregistre le scénario des appels avant de lancer le test
    PowerMock.replayAll();

    _processInstance = new PE0078_ReconciliationCommerciale();
    _processInstance.initializeContext();
    _processInstance.run(_request);
    assertEquals(expected.getErrorCode(), _request.getResponse().getErrorCode());
    assertEquals(ravelResponse.getResult(), _request.getResponse().getResult());
  }

  /**
   * Scenario: BL100 failed to BSSGP_SI001_Resynchro return NOK<br>
   * Input: Valid {clientOperateur} and {noCompte} URL parameters"<br>
   * Result:
   *
   * @throws Throwable
   */
  @Test
  public void PE0078_BL100_CreerReconciliationCo_KO_003() throws Throwable
  {
    _request.setHttpMethod("POST"); //$NON-NLS-1$
    _request.setPayload(null);
    String noCompte = "610123456789"; //$NON-NLS-1$
    String clientOperateur = "BSS_GP"; //$NON-NLS-1$

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    list.add(new Parameter("clientOperateur", clientOperateur)); //$NON-NLS-1$
    list.add(new Parameter("noCompte", noCompte)); //$NON-NLS-1$
    urlParametersType.setUrlParameters(list);
    _request.setUrlParameters(urlParametersType);

    PowerMock.expectNew(BL800_ObtenirSequenceBuilder.class).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.code(UniqueIdConstant.ID_RECONCILIATION_COMMERCIALE)).andReturn(_bl800BuilderMock);

    EasyMock.expect(_bl800BuilderMock.build()).andReturn(_bl800Mock);
    String idReconciliation = "123456789"; //$NON-NLS-1$
    EasyMock.expect(_bl800Mock.execute(EasyMock.anyObject(PE0078_ReconciliationCommerciale.class))).andReturn(idReconciliation);
    Retour bl800Retour = RetourFactoryForTU.createOkRetour();
    EasyMock.expect(_bl800Mock.getRetour()).andReturn(bl800Retour);

    PowerMock.expectNew(BSSGP_SI001_ResynchroBuilder.class).andReturn(_si001BuilderMock);
    EasyMock.expect(_si001BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_si001BuilderMock);
    EasyMock.expect(_si001BuilderMock.idDemande(idReconciliation)).andReturn(_si001BuilderMock);
    EasyMock.expect(_si001BuilderMock.noCompte(noCompte)).andReturn(_si001BuilderMock);
    EasyMock.expect(_si001BuilderMock.build()).andReturn(_si001Mock);
    EasyMock.expect(_si001Mock.execute(EasyMock.anyObject(PE0078_ReconciliationCommerciale.class))).andReturn(null);
    Retour si001Retour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.KO_CLIENT_OPERATEUR, "", null); //$NON-NLS-1$
    EasyMock.expect(_si001Mock.getRetour()).andReturn(si001Retour);

    final ReponseErreur erreur = new ReponseErreur();
    erreur.setError(si001Retour.getDiagnostic());
    erreur.setErrorDescription(si001Retour.getLibelle());
    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    response.setResult(new StringBuilder().append("{\"error\":\"").append(erreur.getError()).append("\",\"error_description\":\"").append(erreur.getErrorDescription()).append("\"}").toString()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    final Response expected = new Response(ErrorCode.KO_00404, response);

    // On enregistre le scénario des appels avant de lancer le test
    PowerMock.replayAll();

    _processInstance = new PE0078_ReconciliationCommerciale();
    _processInstance.initializeContext();
    _processInstance.run(_request);
    assertEquals(expected.getErrorCode(), _request.getResponse().getErrorCode());
    assertEquals(expected.getMarshalledResponseJson(), _request.getResponse().getMarshalledResponseJson());
  }

  /**
   * Scenario: BL100 failed to REX004_CreerReconciliationCommerciale return NOK<br>
   * Input: Valid {clientOperateur} and {noCompte} URL parameters"<br>
   * Result:
   *
   * @throws Throwable
   */
  @Test
  public void PE0078_BL100_CreerReconciliationCo_KO_004() throws Throwable
  {
    _request.setHttpMethod("POST"); //$NON-NLS-1$
    _request.setPayload(null);
    String noCompte = "610123456789"; //$NON-NLS-1$
    String clientOperateur = "BSS_GP"; //$NON-NLS-1$
    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    list.add(new Parameter("clientOperateur", clientOperateur)); //$NON-NLS-1$
    list.add(new Parameter("noCompte", noCompte)); //$NON-NLS-1$
    urlParametersType.setUrlParameters(list);
    _request.setUrlParameters(urlParametersType);

    PowerMock.expectNew(BL800_ObtenirSequenceBuilder.class).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.code(UniqueIdConstant.ID_RECONCILIATION_COMMERCIALE)).andReturn(_bl800BuilderMock);

    EasyMock.expect(_bl800BuilderMock.build()).andReturn(_bl800Mock);
    String idReconciliation = "123456789"; //$NON-NLS-1$
    EasyMock.expect(_bl800Mock.execute(EasyMock.anyObject(PE0078_ReconciliationCommerciale.class))).andReturn(idReconciliation);
    Retour bl800Retour = RetourFactoryForTU.createOkRetour();
    EasyMock.expect(_bl800Mock.getRetour()).andReturn(bl800Retour);

    PowerMock.expectNew(BSSGP_SI001_ResynchroBuilder.class).andReturn(_si001BuilderMock);
    EasyMock.expect(_si001BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_si001BuilderMock);
    EasyMock.expect(_si001BuilderMock.idDemande(idReconciliation)).andReturn(_si001BuilderMock);
    EasyMock.expect(_si001BuilderMock.noCompte(noCompte)).andReturn(_si001BuilderMock);

    EasyMock.expect(_si001BuilderMock.build()).andReturn(_si001Mock);
    EasyMock.expect(_si001Mock.execute(EasyMock.anyObject(PE0078_ReconciliationCommerciale.class))).andReturn(null);
    EasyMock.expect(_si001Mock.getRetour()).andReturn(RetourFactoryForTU.createOkRetour());

    PowerMock.mockStatic(REXProxy.class);
    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxy);

    Retour rexRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.ERREUR_INTERNE, "", null); //$NON-NLS-1$
    ConnectorResponse<Retour, Nothing> rexResponse = new ConnectorResponse<Retour, Nothing>(rexRetour, null);
    EasyMock.expect(_rexProxy.reconciliationCommercialeCreer(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(CreateOrUpdateReconciliationCommercialeRequest.class))).andReturn(rexResponse);

    final ReponseErreur erreur = new ReponseErreur();
    erreur.setError(rexRetour.getDiagnostic());
    erreur.setErrorDescription(rexRetour.getLibelle());
    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    final Response expected = new Response(ErrorCode.KO_00500, ravelResponse);

    // On enregistre le scénario des appels avant de lancer le test
    PowerMock.replayAll();

    _processInstance = new PE0078_ReconciliationCommerciale();
    _processInstance.initializeContext();
    _processInstance.run(_request);
    assertEquals(expected.getErrorCode(), _request.getResponse().getErrorCode());
    assertEquals(expected.getMarshalledResponseJson(), _request.getResponse().getMarshalledResponseJson());
  }

  /**
   * Scenario: BL100 success to REX004_CreerReconciliationCommerciale return OK<br>
   * Input: Valid {clientOperateur} and {noCompte} URL parameters"<br>
   * Result:
   *
   * @throws Throwable
   */
  @Test
  public void PE0078_BL100_CreerReconciliationCo_OK() throws Throwable
  {
    _request.setHttpMethod("POST"); //$NON-NLS-1$
    _request.setPayload(null);
    String noCompte = "610123456789"; //$NON-NLS-1$
    String clientOperateur = "BSS_GP"; //$NON-NLS-1$
    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    list.add(new Parameter("clientOperateur", clientOperateur)); //$NON-NLS-1$
    list.add(new Parameter("noCompte", noCompte)); //$NON-NLS-1$
    urlParametersType.setUrlParameters(list);
    _request.setUrlParameters(urlParametersType);

    PowerMock.expectNew(BL800_ObtenirSequenceBuilder.class).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.code(UniqueIdConstant.ID_RECONCILIATION_COMMERCIALE)).andReturn(_bl800BuilderMock);

    EasyMock.expect(_bl800BuilderMock.build()).andReturn(_bl800Mock);
    String idReconciliation = "123456789"; //$NON-NLS-1$
    EasyMock.expect(_bl800Mock.execute(EasyMock.anyObject(PE0078_ReconciliationCommerciale.class))).andReturn(idReconciliation);
    Retour bl800Retour = RetourFactoryForTU.createOkRetour();
    EasyMock.expect(_bl800Mock.getRetour()).andReturn(bl800Retour);

    PowerMock.expectNew(BSSGP_SI001_ResynchroBuilder.class).andReturn(_si001BuilderMock);
    EasyMock.expect(_si001BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_si001BuilderMock);
    EasyMock.expect(_si001BuilderMock.idDemande(idReconciliation)).andReturn(_si001BuilderMock);
    EasyMock.expect(_si001BuilderMock.noCompte(noCompte)).andReturn(_si001BuilderMock);

    EasyMock.expect(_si001BuilderMock.build()).andReturn(_si001Mock);
    EasyMock.expect(_si001Mock.execute(EasyMock.anyObject(PE0078_ReconciliationCommerciale.class))).andReturn(null);
    EasyMock.expect(_si001Mock.getRetour()).andReturn(RetourFactoryForTU.createOkRetour());

    PowerMock.mockStatic(REXProxy.class);
    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxy);
    ConnectorResponse<Retour, Nothing> rexResponse = new ConnectorResponse<Retour, Nothing>(RetourFactoryForTU.createOkRetour(), null);
    EasyMock.expect(_rexProxy.reconciliationCommercialeCreer(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(CreateOrUpdateReconciliationCommercialeRequest.class))).andReturn(rexResponse);

    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    RavelResponse.ResponseHeader header = new ResponseHeader();
    header.setName("Location"); //$NON-NLS-1$
    header.setValue("http://xxx/reconciliations-commerciales/" + idReconciliation); //$NON-NLS-1$
    response.getResponseHeader().add(header);
    final Response expected = new Response(ErrorCode.OK_00201, response);

    // On enregistre le scénario des appels avant de lancer le test
    PowerMock.replayAll();

    _processInstance = new PE0078_ReconciliationCommerciale();
    _processInstance.initializeContext();
    _processInstance.run(_request);
    assertEquals(expected.getErrorCode(), _request.getResponse().getErrorCode());
    assertEquals(expected.getMarshalledResponseJson(), _request.getResponse().getMarshalledResponseJson());
  }

  /**
   * Scenario: BL200 failed to retrieve oListeReconciliationCo of REX005_RecupererListeReconcilationCo<br>
   * Input: The {idReconciliation} URL parameter<br>
   * Result:
   *
   * @throws Throwable
   */
  @Test
  public void PE0078_BL200_RechercherReconciliationCo_KO_001() throws Throwable
  {

    _request.setHttpMethod("GET"); //$NON-NLS-1$
    _request.setPayload(null);
    String idReconciliation = "/reconciliations-commerciales/123456789"; //$NON-NLS-1$
    _request.setUrlDynamicParameters(idReconciliation);

    Retour rexRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.ERREUR_INTERNE, "", null); //$NON-NLS-1$
    PowerMock.mockStatic(REXProxy.class);
    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxy);
    ConnectorResponse<Retour, List<ReconciliationCommerciale>> rexResponse = new ConnectorResponse<>(rexRetour, null);
    EasyMock.expect(_rexProxy.reconciliationCommercialeLireTousParIdReconciliation(EasyMock.anyObject(Tracabilite.class), EasyMock.anyString())).andReturn(rexResponse);

    // On enregistre le scénario des appels avant de lancer le test
    PowerMock.replayAll();

    final ReponseErreur erreur = new ReponseErreur();
    erreur.setError(rexRetour.getDiagnostic());
    erreur.setErrorDescription(rexRetour.getLibelle());
    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    final Response expected = new Response(ErrorCode.KO_00500, response);

    _processInstance = new PE0078_ReconciliationCommerciale();

    _processInstance.initializeContext();
    _processInstance.run(_request);
    assertEquals(expected.getErrorCode(), _request.getResponse().getErrorCode());
    assertEquals(response.getResult(), _request.getResponse().getResult());
  }

  /**
   * Scenario: BL200 failed to retrieve oListeReconciliationCo of REX005_RecupererListeReconcilationCo<br>
   * Input: The {sClientOperateur} and {sNoCompte} URL parameter<br>
   * Result:
   *
   * @throws Throwable
   */
  @Test
  public void PE0078_BL200_RechercherReconciliationCo_KO_002() throws Throwable
  {

    _request.setHttpMethod("GET"); //$NON-NLS-1$
    _request.setPayload(null);
    //String idReconciliation = "123456789"; //$NON-NLS-1$
    //_request.setUrlDynamicParameters(idReconciliation);
    String noCompte = "610123456789"; //$NON-NLS-1$
    String clientOperateur = "BSS_GP"; //$NON-NLS-1$
    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    list.add(new Parameter("clientOperateur", clientOperateur)); //$NON-NLS-1$
    list.add(new Parameter("noCompte", noCompte)); //$NON-NLS-1$
    urlParametersType.setUrlParameters(list);
    _request.setUrlParameters(urlParametersType);

    Retour rexRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.ERREUR_INTERNE, "", null); //$NON-NLS-1$
    ConnectorResponse<Retour, List<ReconciliationCommerciale>> rexResponse = new ConnectorResponse<>(rexRetour, null);
    PowerMock.mockStatic(REXProxy.class);
    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxy);
    EasyMock.expect(_rexProxy.reconciliationCommercialeLireTousParClientOperateurNoCompte(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(clientOperateur), EasyMock.eq(noCompte))).andReturn(rexResponse);

    // On enregistre le scénario des appels avant de lancer le test
    PowerMock.replayAll();

    final ReponseErreur erreur = new ReponseErreur();
    erreur.setError(rexRetour.getDiagnostic());
    erreur.setErrorDescription(rexRetour.getLibelle());
    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    final Response expected = new Response(ErrorCode.KO_00500, response);

    _processInstance = new PE0078_ReconciliationCommerciale();

    _processInstance.initializeContext();
    _processInstance.run(_request);
    assertEquals(expected.getErrorCode(), _request.getResponse().getErrorCode());
    assertEquals(expected.getMarshalledResponseJson(), _request.getResponse().getMarshalledResponseJson());
  }

  /**
   * Scenario: BL200 retrieve oListeReconciliationCo of REX005_RecupererListeReconcilationCo<br>
   * Input: The {sClientOperateur} and {sNoCompte} URL parameter<br>
   * Result:
   *
   * @throws Throwable
   */
  @Test
  public void PE0078_BL200_RechercherReconciliationCo_OK() throws Throwable
  {
    _request.setHttpMethod("GET"); //$NON-NLS-1$
    _request.setPayload(null);
    //String idReconciliation = "123456789"; //$NON-NLS-1$
    //_request.setUrlDynamicParameters(idReconciliation);
    String noCompte = "610123456789"; //$NON-NLS-1$
    String clientOperateur = "BSS_GP"; //$NON-NLS-1$
    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    list.add(new Parameter("clientOperateur", clientOperateur)); //$NON-NLS-1$
    list.add(new Parameter("noCompte", noCompte)); //$NON-NLS-1$
    urlParametersType.setUrlParameters(list);
    _request.setUrlParameters(urlParametersType);

    PowerMock.mockStatic(REXProxy.class);
    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxy);
    List<ReconciliationCommerciale> reconciliationCommercialeList = Arrays.asList(__podam.manufacturePojoWithFullData(ReconciliationCommerciale.class));
    ConnectorResponse<Retour, List<ReconciliationCommerciale>> rexResponse = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), reconciliationCommercialeList);
    EasyMock.expect(_rexProxy.reconciliationCommercialeLireTousParClientOperateurNoCompte(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(clientOperateur), EasyMock.eq(noCompte))).andReturn(rexResponse);

    // On enregistre le scénario des appels avant de lancer le test
    PowerMock.replayAll();

    _processInstance = new PE0078_ReconciliationCommerciale();

    _processInstance.initializeContext();
    _processInstance.run(_request);

    String idReconciliation = reconciliationCommercialeList.get(0).getIdReconciliation();
    LocalDateTime dateReconciliation = reconciliationCommercialeList.get(0).getDateCreation();
    String clientOpe = reconciliationCommercialeList.get(0).getClientOperateur();
    String noCpt = reconciliationCommercialeList.get(0).getNoCompte();
    Boolean cmdReconcilRecue = reconciliationCommercialeList.get(0).getCmdReconcilRecue();
    String idCmd = reconciliationCommercialeList.get(0).getIdCmd();
    LocalDateTime dateReception = reconciliationCommercialeList.get(0).getDateReception();

    ReconciliationCommercialeReturn expectedReconCo = new ReconciliationCommercialeReturn(idReconciliation, dateReconciliation, clientOpe, noCpt, cmdReconcilRecue, idCmd, dateReception);

    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    String result = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(Arrays.asList(expectedReconCo));
    response.setResult(result);
    final Response expected = new Response(ErrorCode.OK_00200, response);

    assertEquals(expected.getErrorCode(), _request.getResponse().getErrorCode());
    assertEquals(expected.getMarshalledResponseJson(), _request.getResponse().getMarshalledResponseJson());
  }

  /**
   * Initialization of tests
   *
   * @throws Exception
   *           Exception to be thrown in case of failure
   */
  @Before
  public void setUp() throws Exception
  {

    // on réinitialise tous les mocks afin de ne pas avoir d'interférence entre les tests
    PowerMock.resetAll();

    _request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    final RequestHeader requestHeader4 = new RequestHeader();
    requestHeader4.setName(IHttpHeadersConsts.X_REQUEST_ID);
    requestHeader4.setValue("123415151515151"); //$NON-NLS-1$
    _request.getRequestHeader().add(requestHeader4);

    final RequestHeader requestHeader3 = new RequestHeader();
    requestHeader3.setName(IHttpHeadersConsts.X_SOURCE);
    requestHeader3.setValue("IHM_SPIRIT"); //$NON-NLS-1$
    _request.getRequestHeader().add(requestHeader3);

    final RequestHeader requestHeader2 = new RequestHeader();
    requestHeader2.setName(IHttpHeadersConsts.X_PROCESS);
    requestHeader2.setValue("RECONCILIATION EXPLOITANT"); //$NON-NLS-1$
    _request.getRequestHeader().add(requestHeader2);

  }
}
