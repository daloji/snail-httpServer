/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PI0035.sti;

import static org.junit.Assert.assertEquals;

import java.time.LocalDateTime;

import org.junit.BeforeClass;
import org.junit.Test;

import com.bytel.ravel.common.datetime.DateTimeManager;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.spirit.common.shared.saab.rpg.LienSAPA;
import com.bytel.spirit.common.shared.saab.rpg.Statut;
import com.bytel.spirit.prof.processes.PI0035.sti.PI0035_LienSaPa;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 * Tests the class {@link PI0035_LienSaPa}
 *
 * @author jgregori
 * @version ($Revision$ $Date$)
 */
public class PI0035_LienSaPaTest
{
  /**
   * Factory de génération des beans
   */
  private static PodamFactory __podam = new PodamFactoryImpl();

  /**
   * Initialize before all tests
   */
  @BeforeClass
  public static void setUpBeforeClass()
  {
    // désactivation du cache podam
    __podam.getStrategy().setMemoization(false);
    __podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());

  }

  /**
   * Tests static method {@link PI0035_LienSaPa#buildFromLienSAPA(LienSAPA)}.
   */
  @Test
  public void testBuildFromLienSaPa()
  {
    LienSAPA lienSaPa = __podam.manufacturePojo(LienSAPA.class);

    PI0035_LienSaPa pfiCompLienSaPa = PI0035_LienSaPa.buildFromLienSAPA(lienSaPa);
    PFITestUtils.assertLienSAPA(lienSaPa, pfiCompLienSaPa);

  }

  /**
   * Tests static method {@link PI0035_LienSaPa#buildFromLienSAPA(LienSAPA)}.
   */
  @Test
  public void testBuildFromLienSaPa_001()
  {
    LocalDateTime local = DateTimeManager.getInstance().now();
    LienSAPA lienSaPa = new LienSAPA("noServiceAccessible", "identifiantFonctionnelPA", Statut.ACTIF, local, local); //$NON-NLS-1$ //$NON-NLS-2$
    PI0035_LienSaPa pfiCompLienSaPa = PI0035_LienSaPa.buildFromLienSAPA(lienSaPa);
    assertEquals(pfiCompLienSaPa.equals(pfiCompLienSaPa), true);

  }
}
