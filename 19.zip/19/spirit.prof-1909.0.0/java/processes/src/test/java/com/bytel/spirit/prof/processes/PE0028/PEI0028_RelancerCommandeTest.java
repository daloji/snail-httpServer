/*******************************************************************************
* $Id: PEI0028_RelancerCommandeTest.java 14166 2018-12-06 09:31:32Z fbarnabe $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PE0028;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.io.Closeable;
import java.io.IOException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentMap;

import org.easymock.EasyMock;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.Mock;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.reflect.Whitebox;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.request.Parameter;
import com.bytel.ravel.common.factory.request.UrlParameters;
import com.bytel.ravel.common.factory.response.IRavelResponse;
import com.bytel.ravel.common.factory.response.RavelResponseFactory;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.utils.ACManagerUtil;
import com.bytel.ravel.common.utils.DateTimeTools.DateTimeFormatPattern;
import com.bytel.ravel.common.utils.RetourFactoryForTU;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.ProcessManager;
import com.bytel.ravel.services.utils.Test_Consts;
import com.bytel.spirit.common.connectors.cmd.CMDProxy;
import com.bytel.spirit.common.connectors.ink.ResponseConnector;
import com.bytel.spirit.common.connectors.ink.activities.PROV_SI001_LancerOrchestrateur;
import com.bytel.spirit.common.connectors.ink.activities.PROV_SI001_LancerOrchestrateur.PROV_SI001_LancerOrchestrateurBuilder;
import com.bytel.spirit.common.connectors.rex.REXProxy;
import com.bytel.spirit.common.shared.saab.cmd.Commande;
import com.bytel.spirit.common.shared.saab.cmd.Statut;
import com.bytel.spirit.common.shared.saab.rex.request.CreateErreurSpiritRequest;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.BasicResponse;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.ressources.RetourConverter;
import com.bytel.spirit.common.shared.misc.tracabilite.IRefFoncConstants;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.prof.processes.Messages;
import com.bytel.spirit.prof.processes.PE0018.PEI0018_CommandePfi;
import com.bytel.spirit.prof.processes.PE0028.PEI0028_RelancerCommande.BL001_VerifierDonneesReturn;
import com.bytel.spirit.prof.processes.PE0028.PEI0028_RelancerCommande.BL010_RecupererNomPEPReturn;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author kbettenc
 * @version ($Revision: 14166 $ $Date: 2018-12-06 10:31:32 +0100 (jeu. 06 déc. 2018) $)
 */
@RunWith(PowerMockRunner.class)
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
@PrepareForTest({ PEI0028_RelancerCommande.class, CMDProxy.class, REXProxy.class })
public class PEI0028_RelancerCommandeTest implements Closeable
{
  /**
   *
   */
  private static final String PEI0028_BL010_RECUPERER_NOM_PEP = "PEI0028_BL010_RecupererNomPEP"; //$NON-NLS-1$

  /**
   *
   */
  private static final String PEI0028_BL001_VERIFIER_DONNEES = "PEI0028_BL001_VerifierDonnees"; //$NON-NLS-1$

  /**
   * Factory de génération des beans
   */
  private static PodamFactory __podam = new PodamFactoryImpl();

  /**
   * SPRING context
   */
  private static ClassPathXmlApplicationContext __context;

  /**
   * The default process name.
   */
  public static final String DEFAULT_PROCESSNAME = "PEI0028_RelancerCommande"; //$NON-NLS-1$

  /**
   * Tracabilite
   */
  private static Tracabilite _tracabilite;

  /**
   * Initialization method: Create: - spring context - connectors - service manager.
   *
   * @throws RavelException
   *           the exception
   */
  @BeforeClass
  public static void init() throws RavelException
  {

    // désactivation du cache podam
    __podam.getStrategy().setMemoization(false);
    __podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());

    ACManagerUtil.resetACManager();
    __context = new ClassPathXmlApplicationContext("classpath:BeansProcessTestMocks.xml"); //$NON-NLS-1$
  }

  /**
   * Instance of {@link PEI0028_RelancerCommande}
   */
  private PEI0028_RelancerCommande _processInstance;

  /**
  *
  */
  @Mock
  private CMDProxy _cmdProxy;

  /**
  *
  */
  @Mock
  private REXProxy _rexProxy;

  /**
   * The mock of {@code PROV_SI001_LancerOrchestrateurBuilder}
   */
  @Mock
  private PROV_SI001_LancerOrchestrateurBuilder _provSI001BuilderMock;

  /**
   * The mock of {@code PROV_SI001_LancerOrchestrateur}
   */
  @Mock
  private PROV_SI001_LancerOrchestrateur _provSI001Mock;

  @Override
  public void close() throws IOException
  {
    __context.close();
  }

  /**
   * Scenario: BL001 failed due to invalid URL parameter<br>
   * Input: The {idCommande} URL parameter not set<br>
   * Result:
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PEI0028_BL001_VerifierDonnees_KO_001() throws Throwable
  {

    Request request = prepareRequest(null);

    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, Messages.getString("PEI0028.IdCommandeNonRenseigne"), null); //$NON-NLS-1$

    BL001_VerifierDonneesReturn retour = Whitebox.invokeMethod(_processInstance, PEI0028_BL001_VERIFIER_DONNEES, _tracabilite, request);

    _processInstance.continueProcess(request, _tracabilite);

    assertEquals(expectedRetour, retour.getRetour());
    Assert.assertNull(retour.getIdCommande());
  }

  /**
   * Test PEI0028_BL001_VerifierDonnes nominal case. Assert that tracabilite is well filled with request headers. Assert
   * that validation is OK.
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PEI0028_BL001_VerifierDonnees_OK_001() throws Throwable
  {

    Request request = prepareRequest("123456789"); //$NON-NLS-1$

    Retour expectedRetour = RetourFactoryForTU.createOkRetour();

    BL001_VerifierDonneesReturn retour = Whitebox.invokeMethod(_processInstance, PEI0028_BL001_VERIFIER_DONNEES, _tracabilite, request);

    assertEquals(expectedRetour, retour.getRetour());
    assertEquals("123456789", retour.getIdCommande()); //$NON-NLS-1$
  }

  /**
   * <b>Scenario: <b>BL010 failed due to CMDProxy call KO<br>
   * <b>Input: <b>CMDProxy mock KO<br>
   * <b>Result: <b>Retour {KO, CAT_4, COMMANDE_INCONNUE, La commande 12345678 est inconnue.
   *
   * @throws Exception
   *           on errors
   */
  @Test
  public void PEI0028_BL010_RecupererNomPEP_KO_001() throws Exception
  {
    String idCmd = "12345678"; //$NON-NLS-1$
    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegConsts.TRAITEMENT_ARRETE, "Connector exception", null); //$NON-NLS-1$

    EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdProxy);
    ConnectorResponse<Retour, Commande> expectedReturn = new ConnectorResponse<Retour, Commande>(RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, "Connector exception", null), null); //$NON-NLS-1$
    EasyMock.expect(_cmdProxy.commandeLireUn(_tracabilite, idCmd)).andReturn(expectedReturn);

    PowerMock.replayAll();
    BL010_RecupererNomPEPReturn retour = Whitebox.invokeMethod(_processInstance, PEI0028_BL010_RECUPERER_NOM_PEP, _tracabilite, expectedRetour, idCmd);
    PowerMock.verifyAll();

    assertEquals(expectedRetour, retour.getRetour());
    Assert.assertNull(retour.getNomPEP());
    Assert.assertNull(retour.getListeCleSequencement());

  }

  /**
   * <b>Scenario: <b>BL010 failed due to Commande with status different to ACQUITTE<br>
   * <b>Input: <b>Commande with status <> ACQUITTE <br>
   * <b>Result: <b>Retour {KO, CAT_4, STATUT_COMMANDE_INVALIDE, La commande {idCmd} est au statut {statut}, elle ne peut
   * pas être relancée.}
   *
   * @throws Exception
   *           on errors
   */
  @Test
  public void PEI0028_BL010_RecupererNomPEP_KO_002() throws Exception
  {

    Commande commande = __podam.manufacturePojo(Commande.class);

    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.STATUT_COMMANDE_INVALIDE, MessageFormat.format(Messages.getString("PEI0028.StatutCommandeInvalide"), commande.getIdCmd(), commande.getStatut()), null); //$NON-NLS-1$

    EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdProxy);
    ConnectorResponse<Retour, Commande> expectedReturn = new ConnectorResponse<Retour, Commande>(RetourFactoryForTU.createOkRetour(), commande);
    EasyMock.expect(_cmdProxy.commandeLireUn(_tracabilite, commande.getIdCmd())).andReturn(expectedReturn);

    PowerMock.replayAll();
    BL010_RecupererNomPEPReturn retour = Whitebox.invokeMethod(_processInstance, PEI0028_BL010_RECUPERER_NOM_PEP, _tracabilite, expectedRetour, commande.getIdCmd());
    PowerMock.verifyAll();

    assertEquals(expectedRetour, retour.getRetour());
    Assert.assertNull(retour.getNomPEP());
    Assert.assertNull(retour.getListeCleSequencement());

  }

  /**
   * <b>Scenario: <b>BL010 failed because nothing is returned from the config table with the NatureCommande <br>
   * <b>Input: <b>A Commande with a NatureCommande not present in the config process table<br>
   * <b>Result: <b>Retour {KO, CAT_4, NATURE_COMMANDE_INVALIDE, La commande {idCmd} est de nature invalide :
   * {natureCommande}}
   *
   * @throws Exception
   *           on errors
   */
  @Test
  public void PEI0028_BL010_RecupererNomPEP_KO_003() throws Exception
  {

    Commande commande = __podam.manufacturePojo(Commande.class);
    commande.setStatut(Statut.ACQUITTE.name());

    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.NATURE_COMMANDE_INVALIDE, MessageFormat.format(Messages.getString("PEI0028.NatureCommandeInvalide"), commande.getIdCmd(), commande.getNatureCommande()), null); //$NON-NLS-1$

    EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdProxy);
    ConnectorResponse<Retour, Commande> expectedReturn = new ConnectorResponse<Retour, Commande>(RetourFactoryForTU.createOkRetour(), commande);
    EasyMock.expect(_cmdProxy.commandeLireUn(_tracabilite, commande.getIdCmd())).andReturn(expectedReturn);

    PowerMock.replayAll();
    BL010_RecupererNomPEPReturn retour = Whitebox.invokeMethod(_processInstance, PEI0028_BL010_RECUPERER_NOM_PEP, _tracabilite, expectedRetour, commande.getIdCmd());
    PowerMock.verifyAll();

    assertEquals(expectedRetour, retour.getRetour());
    Assert.assertNull(retour.getNomPEP());
    assertEquals(commande.getListeCleSequencement(), retour.getListeCleSequencement());
  }

  /**
   * <b>Scenario: <b>BL010 failed because empty is returned from the config table with the NatureCommande <br>
   * <b>Input: <b>A Commande with a NatureCommande not present in the config process table<br>
   * <b>Result: <b>Retour {KO, CAT_4, NATURE_COMMANDE_INVALIDE, La commande {idCmd} est de nature invalide :
   * {natureCommande}}
   *
   * @throws Exception
   *           on errors
   */
  @Test
  public void PEI0028_BL010_RecupererNomPEP_KO_004() throws Exception
  {
    Map<String, String> map = new HashMap<>();

    map.put(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    ConcurrentMap<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.put(StringConstants.EMPTY_STRING, map);

    Commande commande = __podam.manufacturePojo(Commande.class);
    commande.setStatut(Statut.ACQUITTE.name());

    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.NATURE_COMMANDE_INVALIDE, MessageFormat.format(Messages.getString("PEI0028.NatureCommandeInvalide"), commande.getIdCmd(), commande.getNatureCommande()), null); //$NON-NLS-1$

    EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdProxy);
    ConnectorResponse<Retour, Commande> expectedReturn = new ConnectorResponse<Retour, Commande>(RetourFactoryForTU.createOkRetour(), commande);
    EasyMock.expect(_cmdProxy.commandeLireUn(_tracabilite, commande.getIdCmd())).andReturn(expectedReturn);

    PowerMock.replayAll();
    BL010_RecupererNomPEPReturn retour = Whitebox.invokeMethod(_processInstance, PEI0028_BL010_RECUPERER_NOM_PEP, _tracabilite, expectedRetour, commande.getIdCmd());
    PowerMock.verifyAll();

    assertEquals(expectedRetour, retour.getRetour());
    Assert.assertNull(retour.getNomPEP());
    assertEquals(commande.getListeCleSequencement(), retour.getListeCleSequencement());

  }

  /**
   * <b>Scenario: <b>BL010 failed due to CMDProxy call KO (CAT4 DONNE_INCONNUE)<br>
   * <b>Input: <b>CMDProxy mock KO<br>
   * <b>Result: <b>Retour {KO, CAT_4, COMMANDE_INCONNUE, La commande 12345678 est inconnue.
   *
   * @throws Exception
   *           on errors
   */
  @Test
  public void PEI0028_BL010_RecupererNomPEP_KO_005() throws Exception
  {
    String idCmd = "12345678"; //$NON-NLS-1$
    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.COMMANDE_INCONNUE, MessageFormat.format(Messages.getString("PEI0028.CommandeInconnue"), idCmd), null); //$NON-NLS-1$

    EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdProxy);
    ConnectorResponse<Retour, Commande> expectedReturn = new ConnectorResponse<Retour, Commande>(RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "Donne inconnue", null), null); //$NON-NLS-1$
    EasyMock.expect(_cmdProxy.commandeLireUn(_tracabilite, idCmd)).andReturn(expectedReturn);

    PowerMock.replayAll();
    BL010_RecupererNomPEPReturn retour = Whitebox.invokeMethod(_processInstance, PEI0028_BL010_RECUPERER_NOM_PEP, _tracabilite, expectedRetour, idCmd);
    PowerMock.verifyAll();

    assertEquals(expectedRetour, retour.getRetour());
    Assert.assertNull(retour.getNomPEP());
    Assert.assertNull(retour.getListeCleSequencement());

  }

  /**
   * <b>Scenario: <b>Nominal case for BL010 <br>
   * <b>Input: <b>Valid inputs<br>
   * <b>Result: <b>Retour {OK}
   *
   * @throws Exception
   *           on errors
   */
  @Test
  public void PEI0028_BL010_RecupererNomPEP_OK_001() throws Exception
  {
    addTableConfigNomPEPParNatureCommande();

    Commande commande = __podam.manufacturePojo(Commande.class);
    commande.setStatut(Statut.ACQUITTE.name());
    commande.setNatureCommande("CONSTRUCTION"); //$NON-NLS-1$

    Retour expectedRetour = RetourFactoryForTU.createOkRetour();

    EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdProxy);
    ConnectorResponse<Retour, Commande> expectedReturn = new ConnectorResponse<Retour, Commande>(RetourFactoryForTU.createOkRetour(), commande);
    EasyMock.expect(_cmdProxy.commandeLireUn(_tracabilite, commande.getIdCmd())).andReturn(expectedReturn);

    PowerMock.replayAll();
    BL010_RecupererNomPEPReturn retour = Whitebox.invokeMethod(_processInstance, PEI0028_BL010_RECUPERER_NOM_PEP, _tracabilite, expectedRetour, commande.getIdCmd());
    PowerMock.verifyAll();

    assertEquals(expectedRetour, retour.getRetour());
    assertEquals(commande.getListeCleSequencement(), retour.getListeCleSequencement());
    assertEquals("PEP0004_CommandeFournitureAcces", retour.getNomPEP()); //$NON-NLS-1$
    assertEquals(commande.getNoCompte(), _tracabilite.getRefFonc().get(IRefFoncConstants.NO_COMPTE));
    assertEquals(commande.getClientOperateur(), _tracabilite.getRefFonc().get(IRefFoncConstants.CLI_OPE));
  }

  /**
   * <b>Scenario: <b>Nominal case for BL010 <br>
   * <b>Input: <b>Valid inputs (Commande with empty listeSequencement)<br>
   * <b>Result: <b>Retour {OK}
   *
   * @throws Exception
   *           on errors
   */
  @Test
  public void PEI0028_BL010_RecupererNomPEP_OK_002() throws Exception
  {
    addTableConfigNomPEPParNatureCommande();

    Commande commande = __podam.manufacturePojo(Commande.class);
    commande.setStatut(Statut.ACQUITTE.name());
    commande.setListeCleSequencement(null);
    commande.setNatureCommande("CONSTRUCTION"); //$NON-NLS-1$

    Retour expectedRetour = RetourFactoryForTU.createOkRetour();

    EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdProxy);
    ConnectorResponse<Retour, Commande> expectedReturn = new ConnectorResponse<Retour, Commande>(RetourFactoryForTU.createOkRetour(), commande);
    EasyMock.expect(_cmdProxy.commandeLireUn(_tracabilite, commande.getIdCmd())).andReturn(expectedReturn);

    PowerMock.replayAll();
    BL010_RecupererNomPEPReturn retour = Whitebox.invokeMethod(_processInstance, PEI0028_BL010_RECUPERER_NOM_PEP, _tracabilite, expectedRetour, commande.getIdCmd());
    PowerMock.verifyAll();

    assertEquals(expectedRetour, retour.getRetour());
    assertEquals(commande.getListeCleSequencement(), retour.getListeCleSequencement());
    assertEquals("PEP0004_CommandeFournitureAcces", retour.getNomPEP()); //$NON-NLS-1$
    assertEquals(commande.getNoCompte(), _tracabilite.getRefFonc().get(IRefFoncConstants.NO_COMPTE));
    assertEquals(commande.getClientOperateur(), _tracabilite.getRefFonc().get(IRefFoncConstants.CLI_OPE));
  }

  /**
   * <b>Scenario: <b>startProcess KO due to BL001 KO<br>
   * <b>Input: <b>{idCommande} URL parameter not set<br>
   * <b>Result: <b> Response in request STATUS : 400 BAD REQUEST {"retour": {"resultat": "NOK","categorie":
   * "CAT-3","diagnostic": "NON_RESPECT_STI","libelle" : "Paramètre obligatoire idCommande manquant","activité" : "
   * PEI0028_BL001_VerifierDonnees"}} / After continueProcess : {OK}
   *
   *
   * @throws RavelException
   *           on errors
   */
  @Test
  public void PEI0028_startProcess_BL001_KO_001() throws RavelException
  {
    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, Messages.getString("PEI0028.IdCommandeNonRenseigne"), PEI0028_BL001_VERIFIER_DONNEES);

    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(new BasicResponse(RetourConverter.convertToJsonRetour(expectedRetour))));
    final Response expected = new Response(ErrorCode.OK_00200, response);

    Request request = prepareRequest(null);

    Retour retourBL005 = RetourFactoryForTU.createOkRetour();
    ConnectorResponse<Retour, Nothing> resultRex = new ConnectorResponse<Retour, Nothing>(retourBL005, null);
    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxy);
    EasyMock.expect(_rexProxy.erreurSpiritCreer(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(CreateErreurSpiritRequest.class))).andReturn(resultRex);

    try
    {
      PowerMock.replayAll();
      _processInstance.run(request);
      _processInstance.continueProcess(request, _tracabilite);
      PowerMock.verifyAll();
    }
    catch (Throwable exception)
    {
      fail("Should not append : " + exception.getMessage()); //$NON-NLS-1$
    }

    assertEquals(expected.getMarshalledResponseJson(), request.getResponse().getMarshalledResponseJson());
    assertEquals(expectedRetour, _processInstance.getRetour());

  }

  /**
   * <b>Scenario: <b>startProcess KO due to BL010 KO <br>
   * <b>Input: <b>CMDProxy mock KO<br>
   * <b>Result: <b> STATUS : 404 NOT FOUND {"retour": {"resultat": "NOK","categorie": "CAT-4","diagnostic":
   * "COMMANDE_INCONNUE","libelle" : "La commande [idCommande] est inconnue.","activité" : "
   * PEI0028_BL010_RecupererNomPEP"}} / After continueProcess : {OK}
   *
   * @throws RavelException
   *           on errors
   */
  @Test
  public void PEI0028_startProcess_BL010_KO_001() throws RavelException
  {

    String idCmd = "12345678"; //$NON-NLS-1$
    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, "Connector exception", PEI0028_BL010_RECUPERER_NOM_PEP); //$NON-NLS-1$

    Map<String, String> refFonc = new HashMap<String, String>();
    refFonc.put(IRefFoncConstants.ID_CMD, idCmd);

    _tracabilite.setRefFonc(refFonc);

    EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdProxy);
    ConnectorResponse<Retour, Commande> expectedReturn = new ConnectorResponse<Retour, Commande>(RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, "Connector exception", PEI0028_BL010_RECUPERER_NOM_PEP), null); //$NON-NLS-1$
    EasyMock.expect(_cmdProxy.commandeLireUn(_tracabilite, idCmd)).andReturn(expectedReturn);

    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(new BasicResponse(RetourConverter.convertToJsonRetour(expectedRetour))));
    final Response expected = new Response(ErrorCode.OK_00200, response);

    Request request = prepareRequest(idCmd);

    Retour retourBL005 = RetourFactoryForTU.createOkRetour();
    ConnectorResponse<Retour, Nothing> resultRex = new ConnectorResponse<Retour, Nothing>(retourBL005, null);
    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxy);
    EasyMock.expect(_rexProxy.erreurSpiritCreer(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(CreateErreurSpiritRequest.class))).andReturn(resultRex);

    try
    {
      PowerMock.replayAll();
      _processInstance.run(request);
      _processInstance.continueProcess(request, _tracabilite);
      PowerMock.verifyAll();
    }
    catch (Throwable exception)
    {
      fail("Should not append : " + exception.getMessage()); //$NON-NLS-1$
    }

    assertEquals(expected.getMarshalledResponseJson(), request.getResponse().getMarshalledResponseJson());
    assertEquals(expectedRetour, _processInstance.getRetour());

  }

  /**
   * <b>Scenario: <b>startProcess KO due to BL010 KO (Commande with status different to ACQUITTE)<br>
   * <b>Input: <b>Commande with status <> ACQUITTE <br>
   * <b>Result: <b> STATUS : 404 NOT FOUND {"retour": {"resultat": "NOK","categorie": "CAT-4","diagnostic":
   * "STATUT_COMMANDE_INVALIDE","libelle" : "La commande [idCommande] est au statut [statutCommande], elle ne peut pas
   * être relancée.","activité" : " PEI0028_BL010_RecupererNomPEP"}}
   *
   * / After continueProcess : {"retour": {"resultat"="KO", "categorie"="CAT-4", "diagnostic"="DONNEE_EXISTANTE",
   * "libelle"="idErreurSpirit 12345 existe déjà" }} / After continueProcess : {OK}
   *
   * @throws RavelException
   *           on errors
   */
  @Test
  public void PEI0028_startProcess_BL010_KO_002() throws Exception
  {
    Commande commande = __podam.manufacturePojo(Commande.class);

    Retour expectedRetourBL002 = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.STATUT_COMMANDE_INVALIDE, MessageFormat.format(Messages.getString("PEI0028.StatutCommandeInvalide"), commande.getIdCmd(), commande.getStatut()), PEI0028_BL010_RECUPERER_NOM_PEP); //$NON-NLS-1$

    Map<String, String> refFonc = new HashMap<String, String>();
    refFonc.put(IRefFoncConstants.ID_CMD, commande.getIdCmd());

    _tracabilite.setRefFonc(refFonc);

    EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdProxy);
    ConnectorResponse<Retour, Commande> expectedReturn = new ConnectorResponse<Retour, Commande>(expectedRetourBL002, null);
    EasyMock.expect(_cmdProxy.commandeLireUn(_tracabilite, commande.getIdCmd())).andReturn(expectedReturn);

    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(new BasicResponse(RetourConverter.convertToJsonRetour(expectedRetourBL002))));
    final Response expected = new Response(ErrorCode.OK_00200, response);

    Request request = prepareRequest(commande.getIdCmd());

    Retour retourBL005 = RetourFactoryForTU.createOkRetour();
    ConnectorResponse<Retour, Nothing> resultRex = new ConnectorResponse<Retour, Nothing>(retourBL005, null);
    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxy);
    EasyMock.expect(_rexProxy.erreurSpiritCreer(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(CreateErreurSpiritRequest.class))).andReturn(resultRex);

    try
    {
      PowerMock.replayAll();
      _processInstance.run(request);
      _processInstance.continueProcess(request, _tracabilite);
      PowerMock.verifyAll();
    }
    catch (Throwable exception)
    {
      fail("Should not append : " + exception.getMessage()); //$NON-NLS-1$
    }

    assertEquals(expected.getMarshalledResponseJson(), request.getResponse().getMarshalledResponseJson());
    assertEquals(expectedRetourBL002, _processInstance.getRetour());
  }

  /**
   * <b>Scenario: <b>BL010 failed because nothing is returned from the config table with the NatureCommande <br>
   * <b>Input: <b>A Commande with a NatureCommande not present in the config process table<br>
   * <b>Result: <b> STATUS : 404 NOT FOUND {"retour": {"resultat": "NOK","categorie": "CAT-4","diagnostic":
   * "STATUT_COMMANDE_INVALIDE","libelle" : "La commande [idCommande] est de nature invalide :
   * [natureCommande]","activité" : " PEI0028_BL010_RecupererNomPEP"}} / After continueProcess : {OK}
   *
   * @throws RavelException
   *           on errors
   */
  @Test
  public void PEI0028_startProcess_BL010_KO_003() throws RavelException
  {
    Commande commande = __podam.manufacturePojo(Commande.class);
    commande.setStatut(Statut.ACQUITTE.name());

    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.COMMANDE_INCONNUE, MessageFormat.format(Messages.getString("PEI0028.CommandeInconnue"), commande.getIdCmd(), commande.getNatureCommande()), PEI0028_BL010_RECUPERER_NOM_PEP); //$NON-NLS-1$

    Map<String, String> refFonc = new HashMap<String, String>();
    refFonc.put(IRefFoncConstants.ID_CMD, commande.getIdCmd());

    _tracabilite.setRefFonc(refFonc);

    EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdProxy);
    Retour expectedCmdRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, MessageFormat.format(Messages.getString("PEI0028.NatureCommandeInvalide"), commande.getIdCmd(), commande.getNatureCommande()), PEI0028_BL010_RECUPERER_NOM_PEP); //$NON-NLS-1$
    ConnectorResponse<Retour, Commande> expectedReturn = new ConnectorResponse<Retour, Commande>(expectedCmdRetour, commande);
    EasyMock.expect(_cmdProxy.commandeLireUn(_tracabilite, commande.getIdCmd())).andReturn(expectedReturn);

    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(new BasicResponse(RetourConverter.convertToJsonRetour(expectedRetour))));
    final Response expected = new Response(ErrorCode.OK_00200, response);

    Request request = prepareRequest(commande.getIdCmd());

    Retour retourBL005 = RetourFactoryForTU.createOkRetour();
    ConnectorResponse<Retour, Nothing> resultRex = new ConnectorResponse<Retour, Nothing>(retourBL005, null);
    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxy);
    EasyMock.expect(_rexProxy.erreurSpiritCreer(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(CreateErreurSpiritRequest.class))).andReturn(resultRex);

    try
    {
      PowerMock.replayAll();
      _processInstance.run(request);
      _processInstance.continueProcess(request, _tracabilite);
      PowerMock.verifyAll();
    }
    catch (Throwable exception)
    {
      fail("Should not append : " + exception.getMessage()); //$NON-NLS-1$
    }

    assertEquals(expected.getMarshalledResponseJson(), request.getResponse().getMarshalledResponseJson());
    assertEquals(expectedRetour, _processInstance.getRetour());
  }

  /**
   * <b>Scenario: <b>Nominal case for startProcess<br>
   * <b>Input: <b>Valid inputs<br>
   * <b>Result: <b>Retour {OK}
   *
   * @throws Exception
   *           on errors
   */
  @Test
  public void PEI0028_startProcess_OK_001() throws Exception
  {
    addTableConfigNomPEPParNatureCommande();

    Commande commande = __podam.manufacturePojo(Commande.class);
    commande.setStatut(Statut.ACQUITTE.name());
    commande.setNatureCommande("CONSTRUCTION"); //$NON-NLS-1$

    Map<String, String> refFonc = new HashMap<String, String>();
    refFonc.put(IRefFoncConstants.ID_CMD, commande.getIdCmd());

    _tracabilite.setRefFonc(refFonc);

    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(RetourFactoryForTU.createOkRetour()));
    response.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(basicResponse));
    final Response expected = new Response(ErrorCode.OK_00200, response);

    Request request = prepareRequest(commande.getIdCmd());

    EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdProxy);
    ConnectorResponse<Retour, Commande> expectedReturn = new ConnectorResponse<Retour, Commande>(RetourFactoryForTU.createOkRetour(), commande);
    EasyMock.expect(_cmdProxy.commandeLireUn(_tracabilite, commande.getIdCmd())).andReturn(expectedReturn);

    PowerMock.expectNew(PROV_SI001_LancerOrchestrateurBuilder.class).andReturn(_provSI001BuilderMock);
    EasyMock.expect(_provSI001BuilderMock.tracabilite(_tracabilite)).andReturn(_provSI001BuilderMock);
    EasyMock.expect(_provSI001BuilderMock.cles(commande.getListeCleSequencement())).andReturn(_provSI001BuilderMock);
    EasyMock.expect(_provSI001BuilderMock.priorite(10)).andReturn(_provSI001BuilderMock);
    EasyMock.expect(_provSI001BuilderMock.type(IMegSpiritConsts.CONTINUER_PROCESSUS)).andReturn(_provSI001BuilderMock);
    EasyMock.expect(_provSI001BuilderMock.processus("PEP0004_CommandeFournitureAcces")).andReturn(_provSI001BuilderMock); //$NON-NLS-1$
    EasyMock.expect(_provSI001BuilderMock.noms(Arrays.asList(IRefFoncConstants.ID_CMD))).andReturn(_provSI001BuilderMock);
    EasyMock.expect(_provSI001BuilderMock.valeurs(Arrays.asList(commande.getIdCmd()))).andReturn(_provSI001BuilderMock);
    EasyMock.expect(_provSI001BuilderMock.build()).andReturn(_provSI001Mock);
    EasyMock.expect(_provSI001Mock.execute(EasyMock.anyObject(PEI0018_CommandePfi.class))).andReturn(__podam.manufacturePojoWithFullData(ResponseConnector.class));
    EasyMock.expect(_provSI001Mock.getRetour()).andReturn(RetourFactoryForTU.createOkRetour());

    try
    {
      PowerMock.replayAll();

      _processInstance.run(request);
      _processInstance.continueProcess(request, _tracabilite);

      PowerMock.verifyAll();
    }
    catch (Throwable exception)
    {
      fail("Should not append : " + exception.getMessage()); //$NON-NLS-1$
    }

    assertEquals(expected.getMarshalledResponseJson(), request.getResponse().getMarshalledResponseJson());

  }

  /**
   * Initialization of tests
   *
   */
  @Before
  public void setUp()
  {
    // context initialization
    _processInstance = new PEI0028_RelancerCommande();
    _processInstance.initializeContext();

    _tracabilite = new Tracabilite();
    _tracabilite.setIdProcessusSpirit(_processInstance.getIdProcess());
    _tracabilite.setIdCorrelationSpirit(Test_Consts.DEFAULT_MSGID);
    _tracabilite.setIdCorrelationByTel(StringConstants.EMPTY_STRING);
    _tracabilite.setNomProcessus(StringConstants.EMPTY_STRING);
    _tracabilite.setNomSysteme(System.getenv("SERVICE")); //$NON-NLS-1$

    // on réinitialise tous les mocks afin de ne pas avoir d'interférence entre les tests
    PowerMock.resetAll();

    PowerMock.mockStaticStrict(CMDProxy.class);
    PowerMock.mockStaticStrict(REXProxy.class);
  }

  /**
   * Add parameter of type NatureCommande to process
   */
  private void addTableConfigNomPEPParNatureCommande()
  {
    Map<String, String> map = new HashMap<>();

    map.put("NatureCommande_CONSTRUCTION", "PEP0004_CommandeFournitureAcces"); //$NON-NLS-1$ //$NON-NLS-2$
    map.put("NatureCommande_MODIFICATION", "PEP0005_CommandeModificationAcces"); //$NON-NLS-1$ //$NON-NLS-2$
    map.put("NatureCommande_SUPPRESSION", "PEP0006_CommandeSuppressionAcces"); //$NON-NLS-1$ //$NON-NLS-2$
    map.put("NatureCommande_PHOTO_PFI", "PEP0018_CreerCommandeProvPhotoPfi"); //$NON-NLS-1$ //$NON-NLS-2$
    map.put("NatureCommande_TRANSFERT_BOITE_MAIL_SECONDAIRE", "PEP0142_CreerCommandeTransfertBoiteMailSecondaire"); //$NON-NLS-1$ //$NON-NLS-2$
    map.put("NatureCommande_PHOTO_BOITE_MAIL_SECONDAIRE", "PEP0143_CreerCommandePhotoBoiteMailSecondaire"); //$NON-NLS-1$ //$NON-NLS-2$

    ConcurrentMap<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.put(StringConstants.EMPTY_STRING, map);
  }

  /**
   * Create a Generic Request to call PEI0028_RelancerCommande
   *
   * @param idCommande_p
   *          The idCommande to add to the urlParameters
   * @return GenericRequest to call PEI0028_RelancerCommande
   * @throws RavelException
   *           on error
   */
  private Request prepareRequest(String idCommande_p) throws RavelException
  {
    Request request = new Request(DEFAULT_PROCESSNAME, "idProcess", "idClient"); //$NON-NLS-1$ //$NON-NLS-2$
    request.setMsgId(Test_Consts.DEFAULT_MSGID);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();

    if (idCommande_p != null)
    {
      list.add(new Parameter(PEI0028_RelancerCommande.ParameterUrl.idCommande.name(), idCommande_p));
    }
    urlParametersType.setUrlParameters(list);
    request.setUrlParameters(urlParametersType);

    return request;
  }
}
