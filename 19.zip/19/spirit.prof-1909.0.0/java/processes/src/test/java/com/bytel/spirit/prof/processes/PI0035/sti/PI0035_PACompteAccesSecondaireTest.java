/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PI0035.sti;

import static org.apache.commons.lang3.StringUtils.isBlank;

import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.validation.ConstraintViolation;

import org.easymock.EasyMockSupport;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.spirit.common.shared.misc.validation.IValidationConst;
import com.bytel.spirit.common.shared.saab.rpg.PA;
import com.bytel.spirit.common.shared.saab.rpg.PaTypeCompteAccesSecondaire;
import com.bytel.spirit.common.shared.saab.rpg.TypePA;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author jiantila
 * @version ($Revision$ $Date$)
 */

@RunWith(PowerMockRunner.class)
@PrepareForTest({ PI0035_PACompteAccesSecondaire.class })
public class PI0035_PACompteAccesSecondaireTest extends EasyMockSupport
{
  /**
  *
  */
  public static final String VALUE_AUTHORIZED = IValidationConst.FORMAT_ATTRIBUT_NON_RESPECTE;
  /**
  *
  */
  public static final String CONDITIONAL = IValidationConst.ATTRIBUT_COND_INATTENDU;

  /**
  *
  */
  public static final String MANDATORY = IValidationConst.ATTRIBUT_OBLIGATOIRE_MANQUANT;
  /**
   * Factory de génération des beans
   */
  private static PodamFactory __podam = new PodamFactoryImpl();

  /**
   * Initialize before all tests
   */
  @BeforeClass
  public static void setUpBeforeClass()
  {
    // désactivation du cache podam
    __podam.getStrategy().setMemoization(false);
    __podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());
  }

  /**
   * @param constraintValidation_p
   *          constraint
   * @return String
   */
  public String getNameConstraint(final ConstraintViolation<?> constraintValidation_p)
  {
    return Stream.of(constraintValidation_p.getRootBeanClass().getSimpleName(), constraintValidation_p.getPropertyPath().toString()).filter(s -> !isBlank(s)).collect(Collectors.joining(".")); //$NON-NLS-1$
  }

  /**
   * Tests static method {@link PFICompletPA#buildFromPA(PA)} with PaTypeCompteAccesSecondaire
   */
  @Test
  public void testBuildFromPACompteAccesSecondaire()
  {
    PA pa = __podam.manufacturePojo(PA.class);
    PaTypeCompteAccesSecondaire paCAS = __podam.manufacturePojo(PaTypeCompteAccesSecondaire.class);
    pa.setTypePA(TypePA.COMPTE_ACCES_SECONDAIRE.name());
    pa.setPaTypeCompteAccesSecondaire(paCAS);

    PI0035_PA pfiCompLF = PI0035_PA.buildFromPA(pa);
    PFITestUtils.assertPA(pa, pfiCompLF);

  }
}
