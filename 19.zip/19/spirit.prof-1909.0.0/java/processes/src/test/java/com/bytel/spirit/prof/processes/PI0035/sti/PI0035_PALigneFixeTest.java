/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PI0035.sti;

import org.junit.BeforeClass;
import org.junit.Test;

import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.spirit.common.shared.saab.rpg.PA;
import com.bytel.spirit.common.shared.saab.rpg.PaTypeLigneFixe;
import com.bytel.spirit.common.shared.saab.rpg.TypePA;
import com.bytel.spirit.prof.processes.PI0035.sti.PI0035_PA;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 * Test class {@link PFICompletPALigneFixe}
 *
 * @author jgregori
 * @version ($Revision$ $Date$)
 */

public class PI0035_PALigneFixeTest
{
  /**
   * Factory de génération des beans
   */
  private static PodamFactory __podam = new PodamFactoryImpl();

  /**
   * Initialize before all tests
   */
  @BeforeClass
  public static void setUpBeforeClass()
  {
    // désactivation du cache podam
    __podam.getStrategy().setMemoization(false);
    __podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());

  }

  /**
   * Tests static method {@link PFICompletPA#buildFromPA(PA)} with PATypeLigneFixe
   */
  @Test
  public void testBuildFromPALigneFixe()
  {
    PA pa = __podam.manufacturePojo(PA.class);
    PaTypeLigneFixe paLF = __podam.manufacturePojo(PaTypeLigneFixe.class);
    pa.setTypePA(TypePA.LIGNE_FIXE.name());
    pa.setPaTypeLigneFixe(paLF);

    PI0035_PA pi0035PA = PI0035_PA.buildFromPA(pa);
    PFITestUtils.assertPA(pa, pi0035PA);

  }
}
