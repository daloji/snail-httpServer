/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PM029;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;

import javax.ws.rs.core.Response.Status;

import org.apache.commons.lang.RandomStringUtils;
import org.easymock.EasyMock;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.data.exchange.generated.RavelRequest.RequestHeader;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.request.Parameter;
import com.bytel.ravel.common.factory.request.UrlParameters;
import com.bytel.ravel.common.utils.ACManagerUtil;
import com.bytel.ravel.common.utils.DateTimeTools;
import com.bytel.ravel.common.utils.DateTimeTools.DateTimeFormatPattern;
import com.bytel.ravel.common.utils.RetourFactoryForTU;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.connector.raveldatabase.RavelPersistenceDBProxy;
import com.bytel.ravel.services.process.ProcessManager;
import com.bytel.ravel.services.utils.Test_Consts;
import com.bytel.spirit.common.connectors.oam.FollowUpTable;
import com.bytel.spirit.common.connectors.oam.OAMProxy;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.ressources.Consts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.prof.connectors.naf.NafProxy;
import com.bytel.spirit.prof.connectors.naf.generated.ws.notifieracqfct.opale.NotificationProvisionning;
import com.bytel.spirit.prof.connectors.naf.generated.ws.notifieracqfct.opale.NotivProvResponse;
import com.bytel.spirit.prof.connectors.naf.generated.ws.notifieracqfct.pp.EnumOKNOK;
import com.bytel.spirit.prof.connectors.naf.generated.ws.notifieracqfct.pp.NotifierAcqFctOut;
import com.bytel.spirit.prof.connectors.naf.generated.ws.notifieracqfct.pp.NotifierAcqFctReponseType;
import com.bytel.spirit.prof.connectors.naf.generated.ws.notifieracqfct.pp.ReponseServicePIVOTTYPEDansFluxCRFonctionnel;
import com.bytel.spirit.prof.processes.Messages;
import com.bytel.spirit.prof.processes.PM029.PM029NotifierAcqFct.ParameterUrl;

/**
 *
 * @author lmerces
 * @version ($Revision$ $Date$)
 */
//Déclaration du runner de test pour lancer les TUs avec le runner PowerMock
@RunWith(PowerMockRunner.class)
//Préparation des classes pour les tests, toutes les classes comportant des méthodes statiques à mocker doivent être présentes dans l'annotation
@PrepareForTest({ OAMProxy.class, NafProxy.class, RavelPersistenceDBProxy.class })
//To avoid: SecretKeyFactory.getInstance() throws exception for all algorithms in unit tests
@PowerMockIgnore("javax.crypto.*")
public class PM029NotifierAcqFctTest
{
  /**
   * The default process name.
   */
  public static final String DEFAULT_PROCESSNAME = PM029NotifierAcqFct.class.getName();

  /**
   * NAF_CONNECTOR_PP
   */
  public static final String NAF_CONNECTOR_PP = "NAFConnectorPP"; //$NON-NLS-1$

  /**
   * NAF_CONNECTOR_ENT
   */
  public static final String NAF_CONNECTOR_ENT = "NAFConnectorENT"; //$NON-NLS-1$

  /**
   * INSTANCE
   */
  public static final String INSTANCE = RandomStringUtils.randomAlphanumeric(20);

  /**
   * Initialization method: Create: - spring context - connectors - service manager.
   *
   * @throws RavelException
   *           the exception
   */
  @BeforeClass
  public static void init() throws RavelException
  {
    ACManagerUtil.resetACManager();
    new ClassPathXmlApplicationContext("classpath:BeansProcessTestMocks.xml"); //$NON-NLS-1$
  }

  /**
   * OAMConnector
   */
  @MockStrict
  private OAMProxy _oamConnector;

  /**
   * NafConnector
   */
  @MockStrict
  private NafProxy _nafConnector;

  /**
   * The _current process.
   */
  PM029NotifierAcqFct _currentInstance;

  /**
   * Tracabilite
   */
  Tracabilite _tracabilite = new Tracabilite(StringConstants.EMPTY_STRING, Test_Consts.DEFAULT_MSGID, "PROF", "nomPRocessus", "idProcessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$;

  /**
   * Called before each test with the annotation @Before to clean the connectors.
   */
  @Before
  public void beforeTest()
  {
    // on réinitialise tous les mocks afin de ne pas avoir d'interférence entre les tests
    PowerMock.resetAll();

    // On initialise toutes les classes à mocker comportant un appel à une méthode statique
    // Dans notre cas on mock statiquemement toutes les classes des activités et des proxys appelés (pour les createContexte et les getInstance)
    PowerMock.mockStaticStrict(OAMProxy.class);
    PowerMock.mockStaticStrict(NafProxy.class);
    PowerMock.mockStaticStrict(RavelPersistenceDBProxy.class);

    // Initialize the context
    _currentInstance = new PM029NotifierAcqFct();
    _currentInstance.initializeContext();

    HashMap<String, String> map = new HashMap<String, String>();
    map.put(PM029NotifierAcqFct.SIDTITF, "IDTITF"); //$NON-NLS-1$
    map.put(PM029NotifierAcqFct.NB_MAX_ENTREES, "10000"); //$NON-NLS-1$
    map.put(PM029NotifierAcqFct.TIMEOUT_CONSULTER_DEMANDES_ACQUITTER, "30"); //$NON-NLS-1$
    map.put(PM029NotifierAcqFct.TIMEOUT_WS_NOTIFIER_ACQ_FCT, "30"); //$NON-NLS-1$
    map.put(PM029NotifierAcqFct.NAF_CONNECTOR_ID, NAF_CONNECTOR_PP);
    map.put(PM029NotifierAcqFct.WSDL_LIGNE_MARCHE, "PP"); //$NON-NLS-1$

    ConcurrentHashMap<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.put(StringConstants.EMPTY_STRING, map);

  }

  /**
   * cleanup stream
   */
  @After
  public void cleanUpStreams()
  {
    System.setOut(System.out);
  }

  /**
   * NotifierAcqFctTest : OK
   *
   * @throws Throwable
   *           throwable
   */
  //@Test
  // (FBA) Test incorrect desactivé
  // le mock ne semble pas detecté la méthode qui arrive et correspondant pourtant en tout point à la méthode attendue :
  // Unexpected method call NafProxy.notifierAcqFctPP(Tracabilite [_idCorrelationByTel=, _idCorrelationSpirit=4C25AE9D-CA17-4831-9243-30DC02C78079, _nomSysteme=null, _nomProcessus=, _idProcessusSpirit=9c952cd263874e378028c941597fffe4, _refFonc={}], "NAFConnectorPP", "idtactasd", "typntfasd", 30, "20180823155926"):
  // NafProxy.notifierAcqFctPP(isA(com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite), "NAFConnectorPP", "idtactasd", "typntfasd", 30, "20180823155926"): expected: 1, actual: 0
  public void PM029_NotifierAcqFctTest_000() throws Throwable
  {
    Calendar cal = Calendar.getInstance();
    FollowUpTable followUpTable = new FollowUpTable();
    followUpTable.setIdtDde("123456"); //$NON-NLS-1$
    followUpTable.setNomSvc("nomsvcaass"); //$NON-NLS-1$
    followUpTable.setIdtSysTec("idtsystecasd"); //$NON-NLS-1$
    followUpTable.setIdtParSic(2);
    followUpTable.setIdtAct("idtactasd"); //$NON-NLS-1$
    followUpTable.setDatCreact(cal.getTime());
    followUpTable.setIdtItf("idtitfasd"); //$NON-NLS-1$
    followUpTable.setNbrPfi(2);
    followUpTable.setNbrPfiPro(2);
    followUpTable.setDatDebTrt(cal.getTime());
    followUpTable.setDatFinTrt(cal.getTime());
    followUpTable.setEtaRcp("etarcpasd"); //$NON-NLS-1$
    followUpTable.setLibRcp("librcpasd"); //$NON-NLS-1$
    followUpTable.setEtapro("etaproasd"); //$NON-NLS-1$
    followUpTable.setLibPro("libproasd"); //$NON-NLS-1$
    followUpTable.setEtaNtf("etantfasd"); //$NON-NLS-1$
    followUpTable.setLibNtf("libntfasd"); //$NON-NLS-1$
    followUpTable.setTypNtf("typntfasd"); //$NON-NLS-1$
    followUpTable.setDatNtf(cal.getTime());

    List<FollowUpTable> resultat = new ArrayList<FollowUpTable>();
    resultat.add(followUpTable);

    String sIdtitf = "IDTITF"; //$NON-NLS-1$
    int iTimeOut = 30;

    NotifierAcqFctOut response = new NotifierAcqFctOut();
    NotifierAcqFctReponseType rType = new NotifierAcqFctReponseType();
    ReponseServicePIVOTTYPEDansFluxCRFonctionnel rService = new ReponseServicePIVOTTYPEDansFluxCRFonctionnel();
    rService.setCodeErreur(EnumOKNOK.OK);
    rType.setReponseService(rService);
    response.setNotifierAcqFctReponseType(rType);

    //Prepare mock
    EasyMock.expect(OAMProxy.getInstance()).andReturn(_oamConnector);
    EasyMock.expectLastCall().times(2);
    EasyMock.expect(_oamConnector.consulterDemandesAAcquitter(EasyMock.isA(Tracabilite.class), EasyMock.eq(10000), EasyMock.eq(sIdtitf), EasyMock.eq(iTimeOut))).andReturn(new ConnectorResponse<List<FollowUpTable>, Retour>(resultat, RetourFactoryForTU.createOkRetour()));
    EasyMock.expect(_oamConnector.mettreAJourDemandeSuivi(EasyMock.isA(Tracabilite.class), EasyMock.eq(followUpTable))).andReturn(new ConnectorResponse<Integer, Retour>(1, RetourFactoryForTU.createOkRetour()));
    EasyMock.expect(NafProxy.getInstance()).andReturn(_nafConnector);
    EasyMock.expect(_nafConnector.notifierAcqFctPP(EasyMock.isA(Tracabilite.class), EasyMock.eq(NAF_CONNECTOR_PP), EasyMock.eq(followUpTable.getIdtAct()), EasyMock.eq(followUpTable.getTypNtf()), EasyMock.eq(iTimeOut), EasyMock.eq(DateTimeFormatPattern.yyyyMMddHHmmss.format(DateTimeTools.toLocalDateTime(followUpTable.getDatFinTrt()))))).andReturn(new ConnectorResponse<NotifierAcqFctOut, Integer>(response, Status.OK.getStatusCode()));

    // On enregistre le scénario des appels
    PowerMock.replayAll();
    //Prepare mock

    Response responseProcess = executeStartProcess();

    //On demande à PowerMock de vérifier la stack d'appel en fonction du scénario
    PowerMock.verifyAll();

    Assert.assertNotNull(responseProcess);
    Assert.assertEquals(ErrorCode.OK_00200, responseProcess.getErrorCode());
  }

  /**
   * NotifierAcqFctTest : OK
   *
   * @throws Throwable
   *           throwable
   */
  //@Test
  // (FBA) Test incorrect desactivé
  // le mock ne semble pas detecté la méthode qui arrive et correspondant pourtant en tout point à la méthode attendue :
  // Unexpected method call NafProxy.notifierAcqFctPP(Tracabilite [_idCorrelationByTel=, _idCorrelationSpirit=4C25AE9D-CA17-4831-9243-30DC02C78079, _nomSysteme=null, _nomProcessus=, _idProcessusSpirit=9c952cd263874e378028c941597fffe4, _refFonc={}], "NAFConnectorPP", "idtactasd", "typntfasd", 30, "20180823155926"):
  // NafProxy.notifierAcqFctPP(isA(com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite), "NAFConnectorPP", "idtactasd", "typntfasd", 30, "20180823155926"): expected: 1, actual: 0
  public void PM029_NotifierAcqFctTest_000_ENT() throws Throwable
  {
    HashMap<String, String> map = new HashMap<String, String>();
    map.put(PM029NotifierAcqFct.SIDTITF, "IWS_SIENT1"); //$NON-NLS-1$
    map.put(PM029NotifierAcqFct.NB_MAX_ENTREES, "10000"); //$NON-NLS-1$
    map.put(PM029NotifierAcqFct.TIMEOUT_CONSULTER_DEMANDES_ACQUITTER, "30"); //$NON-NLS-1$
    map.put(PM029NotifierAcqFct.TIMEOUT_WS_NOTIFIER_ACQ_FCT, "30"); //$NON-NLS-1$
    map.put(PM029NotifierAcqFct.NAF_CONNECTOR_ID, NAF_CONNECTOR_ENT);
    map.put(PM029NotifierAcqFct.WSDL_LIGNE_MARCHE, "ENT"); //$NON-NLS-1$

    ConcurrentHashMap<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.clear();
    processParams.put(StringConstants.EMPTY_STRING, map);

    Calendar cal = Calendar.getInstance();
    FollowUpTable followUpTable = new FollowUpTable();
    followUpTable.setIdtDde("123456"); //$NON-NLS-1$
    followUpTable.setNomSvc("nomsvcaass"); //$NON-NLS-1$
    followUpTable.setIdtSysTec("idtsystecasd"); //$NON-NLS-1$
    followUpTable.setIdtParSic(2);
    followUpTable.setIdtAct("idtactasd"); //$NON-NLS-1$
    followUpTable.setDatCreact(cal.getTime());
    followUpTable.setIdtItf("IWS_SIENT1"); //$NON-NLS-1$
    followUpTable.setNbrPfi(2);
    followUpTable.setNbrPfiPro(2);
    followUpTable.setDatDebTrt(cal.getTime());
    followUpTable.setDatFinTrt(cal.getTime());
    followUpTable.setEtaRcp("etarcpasd"); //$NON-NLS-1$
    followUpTable.setLibRcp("librcpasd"); //$NON-NLS-1$
    followUpTable.setEtapro("etaproasd"); //$NON-NLS-1$
    followUpTable.setLibPro("libproasd"); //$NON-NLS-1$
    followUpTable.setEtaNtf("etantfasd"); //$NON-NLS-1$
    followUpTable.setLibNtf("libntfasd"); //$NON-NLS-1$
    followUpTable.setTypNtf("typntfasd"); //$NON-NLS-1$
    followUpTable.setDatNtf(cal.getTime());

    List<FollowUpTable> resultat = new ArrayList<FollowUpTable>();
    resultat.add(followUpTable);

    String sIdtitf = "IWS_SIENT1"; //$NON-NLS-1$
    int iTimeOut = 30;

    NotivProvResponse response = new NotivProvResponse();
    NotificationProvisionning rType = new NotificationProvisionning();
    rType.setCodeErreur("OK"); //$NON-NLS-1$
    response.setNotificationProvisionning(rType);

    //Prepare mock
    EasyMock.expect(OAMProxy.getInstance()).andReturn(_oamConnector);
    EasyMock.expectLastCall().times(2);
    EasyMock.expect(_oamConnector.consulterDemandesAAcquitter(EasyMock.isA(Tracabilite.class), EasyMock.eq(10000), EasyMock.eq(sIdtitf), EasyMock.eq(iTimeOut))).andReturn(new ConnectorResponse<List<FollowUpTable>, Retour>(resultat, RetourFactoryForTU.createOkRetour()));
    EasyMock.expect(_oamConnector.mettreAJourDemandeSuivi(EasyMock.isA(Tracabilite.class), EasyMock.eq(followUpTable))).andReturn(new ConnectorResponse<Integer, Retour>(1, RetourFactoryForTU.createOkRetour()));
    EasyMock.expect(NafProxy.getInstance()).andReturn(_nafConnector);
    EasyMock.expect(_nafConnector.notifierAcqFctOpale(EasyMock.isA(Tracabilite.class), EasyMock.eq(NAF_CONNECTOR_ENT), EasyMock.eq(followUpTable.getIdtAct()), EasyMock.eq(followUpTable.getTypNtf()), EasyMock.eq(iTimeOut), EasyMock.eq(DateTimeFormatPattern.yyyyMMddHHmmss.format(DateTimeTools.toLocalDateTime(followUpTable.getDatFinTrt()))))).andReturn(new ConnectorResponse<NotivProvResponse, Integer>(response, Status.OK.getStatusCode()));
    // On enregistre le scénario des appels
    PowerMock.replayAll();

    Response responseProcess = executeStartProcess();

    //On demande à PowerMock de vérifier la stack d'appel en fonction du scénario
    PowerMock.verifyAll();

    Assert.assertNotNull(responseProcess);
    Assert.assertEquals(ErrorCode.OK_00200, responseProcess.getErrorCode());

  }

  /**
   * NotifierAcqFctTest : KO parameters config
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PM029_NotifierAcqFctTest_001() throws Throwable
  {
    HashMap<String, String> map = new HashMap<String, String>();
    map.put(PM029NotifierAcqFct.SIDTITF, null);

    ConcurrentHashMap<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.put(StringConstants.EMPTY_STRING, map);

    //Prepare mock
    //RESDatabaseProxy should not be called ! If it's called, an assertion error is thrown !
    // On enregistre le scénario des appels
    PowerMock.replayAll();
    //Prepare mock

    Response responseProcess = executeStartProcess();

    //On demande à PowerMock de vérifier la stack d'appel en fonction du scénario
    PowerMock.verifyAll();

    Assert.assertNotNull(responseProcess);
    Assert.assertEquals(ErrorCode.PRCESS_00002, responseProcess.getErrorCode());

  }

  /**
   * NotifierAcqFctTest : NotifierAcqFct KO
   *
   * @throws Throwable
   *           throwable
   */
  //@Test
  // (FBA) Test incorrect desactivé
  // le mock ne semble pas detecté la méthode qui arrive et correspondant pourtant en tout point à la méthode attendue :
  // Unexpected method call NafProxy.notifierAcqFctPP(Tracabilite [_idCorrelationByTel=, _idCorrelationSpirit=4C25AE9D-CA17-4831-9243-30DC02C78079, _nomSysteme=null, _nomProcessus=, _idProcessusSpirit=9c952cd263874e378028c941597fffe4, _refFonc={}], "NAFConnectorPP", "idtactasd", "typntfasd", 30, "20180823155926"):
  // NafProxy.notifierAcqFctPP(isA(com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite), "NAFConnectorPP", "idtactasd", "typntfasd", 30, "20180823155926"): expected: 1, actual: 0
  public void PM029_NotifierAcqFctTest_002() throws Throwable
  {
    Calendar cal = Calendar.getInstance();
    FollowUpTable followUpTable = new FollowUpTable();
    followUpTable.setIdtDde("123456"); //$NON-NLS-1$
    followUpTable.setNomSvc("nomsvcaass"); //$NON-NLS-1$
    followUpTable.setIdtSysTec("idtsystecasd"); //$NON-NLS-1$
    followUpTable.setIdtParSic(2);
    followUpTable.setIdtAct("idtactasd"); //$NON-NLS-1$
    followUpTable.setDatCreact(cal.getTime());
    followUpTable.setIdtItf("idtitfasd"); //$NON-NLS-1$
    followUpTable.setNbrPfi(2);
    followUpTable.setNbrPfiPro(2);
    followUpTable.setDatDebTrt(cal.getTime());
    followUpTable.setDatFinTrt(cal.getTime());
    followUpTable.setEtaRcp("etarcpasd"); //$NON-NLS-1$
    followUpTable.setLibRcp("librcpasd"); //$NON-NLS-1$
    followUpTable.setEtapro("etaproasd"); //$NON-NLS-1$
    followUpTable.setLibPro("libproasd"); //$NON-NLS-1$
    followUpTable.setEtaNtf("etantfasd"); //$NON-NLS-1$
    followUpTable.setLibNtf("libntfasd"); //$NON-NLS-1$
    followUpTable.setTypNtf("typntfasd"); //$NON-NLS-1$
    followUpTable.setDatNtf(cal.getTime());

    List<FollowUpTable> resultat = new ArrayList<FollowUpTable>();
    resultat.add(followUpTable);

    String sIdtitf = "IDTITF"; //$NON-NLS-1$
    int iTimeOut = 30;

    NotifierAcqFctOut response = new NotifierAcqFctOut();
    NotifierAcqFctReponseType rType = new NotifierAcqFctReponseType();
    ReponseServicePIVOTTYPEDansFluxCRFonctionnel rService = new ReponseServicePIVOTTYPEDansFluxCRFonctionnel();
    rService.setCodeErreur(EnumOKNOK.OK);
    rType.setReponseService(rService);
    response.setNotifierAcqFctReponseType(rType);

    //Prepare mock
    EasyMock.expect(OAMProxy.getInstance()).andReturn(_oamConnector);
    EasyMock.expectLastCall().times(2);
    EasyMock.expect(_oamConnector.consulterDemandesAAcquitter(EasyMock.isA(Tracabilite.class), EasyMock.eq(10000), EasyMock.eq(sIdtitf), EasyMock.eq(iTimeOut))).andReturn(new ConnectorResponse<List<FollowUpTable>, Retour>(resultat, RetourFactoryForTU.createOkRetour()));
    EasyMock.expect(_oamConnector.mettreAJourDemandeSuivi(EasyMock.isA(Tracabilite.class), EasyMock.eq(followUpTable))).andReturn(new ConnectorResponse<Integer, Retour>(1, RetourFactoryForTU.createOkRetour()));
    EasyMock.expect(NafProxy.getInstance()).andReturn(_nafConnector);
    EasyMock.expect(_nafConnector.notifierAcqFctPP(EasyMock.isA(Tracabilite.class), EasyMock.eq(NAF_CONNECTOR_PP), EasyMock.eq(followUpTable.getIdtAct()), EasyMock.eq(followUpTable.getTypNtf()), EasyMock.eq(iTimeOut), EasyMock.eq(DateTimeFormatPattern.yyyyMMddHHmmss.format(DateTimeTools.toLocalDateTime(followUpTable.getDatFinTrt()))))).andReturn(new ConnectorResponse<NotifierAcqFctOut, Integer>(response, Status.SERVICE_UNAVAILABLE.getStatusCode()));

    // On enregistre le scénario des appels
    PowerMock.replayAll();

    Response responseProcess = executeStartProcess();

    //On demande à PowerMock de vérifier la stack d'appel en fonction du scénario
    PowerMock.verifyAll();

    Assert.assertNotNull(responseProcess);
    Assert.assertEquals(ErrorCode.OK_00200, responseProcess.getErrorCode());

  }

  /**
   * NotifierAcqFctTest : NotifierAcqFct KO
   *
   * @throws Throwable
   *           throwable
   */
  //@Test
  // (FBA) Test incorrect desactivé
  // le mock ne semble pas detecté la méthode qui arrive et correspondant pourtant en tout point à la méthode attendue :
  // Unexpected method call NafProxy.notifierAcqFctPP(Tracabilite [_idCorrelationByTel=, _idCorrelationSpirit=4C25AE9D-CA17-4831-9243-30DC02C78079, _nomSysteme=null, _nomProcessus=, _idProcessusSpirit=9c952cd263874e378028c941597fffe4, _refFonc={}], "NAFConnectorPP", "idtactasd", "typntfasd", 30, "20180823155926"):
  // NafProxy.notifierAcqFctPP(isA(com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite), "NAFConnectorPP", "idtactasd", "typntfasd", 30, "20180823155926"): expected: 1, actual: 0
  public void PM029_NotifierAcqFctTest_002_ENT() throws Throwable
  {
    HashMap<String, String> map = new HashMap<String, String>();
    map.put(PM029NotifierAcqFct.SIDTITF, "IWS_SIENT1"); //$NON-NLS-1$
    map.put(PM029NotifierAcqFct.NB_MAX_ENTREES, "10000"); //$NON-NLS-1$
    map.put(PM029NotifierAcqFct.TIMEOUT_CONSULTER_DEMANDES_ACQUITTER, "30"); //$NON-NLS-1$
    map.put(PM029NotifierAcqFct.TIMEOUT_WS_NOTIFIER_ACQ_FCT, "30"); //$NON-NLS-1$
    map.put(PM029NotifierAcqFct.NAF_CONNECTOR_ID, NAF_CONNECTOR_ENT);
    map.put(PM029NotifierAcqFct.WSDL_LIGNE_MARCHE, "ENT"); //$NON-NLS-1$

    ConcurrentHashMap<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.put(StringConstants.EMPTY_STRING, map);

    Calendar cal = Calendar.getInstance();
    FollowUpTable followUpTable = new FollowUpTable();
    followUpTable.setIdtDde("123456"); //$NON-NLS-1$
    followUpTable.setNomSvc("nomsvcaass"); //$NON-NLS-1$
    followUpTable.setIdtSysTec("idtsystecasd"); //$NON-NLS-1$
    followUpTable.setIdtParSic(2);
    followUpTable.setIdtAct("idtactasd"); //$NON-NLS-1$
    followUpTable.setDatCreact(cal.getTime());
    followUpTable.setIdtItf("IWS_SIENT1"); //$NON-NLS-1$
    followUpTable.setNbrPfi(2);
    followUpTable.setNbrPfiPro(2);
    followUpTable.setDatDebTrt(cal.getTime());
    followUpTable.setDatFinTrt(cal.getTime());
    followUpTable.setEtaRcp("etarcpasd"); //$NON-NLS-1$
    followUpTable.setLibRcp("librcpasd"); //$NON-NLS-1$
    followUpTable.setEtapro("etaproasd"); //$NON-NLS-1$
    followUpTable.setLibPro("libproasd"); //$NON-NLS-1$
    followUpTable.setEtaNtf("etantfasd"); //$NON-NLS-1$
    followUpTable.setLibNtf("libntfasd"); //$NON-NLS-1$
    followUpTable.setTypNtf("typntfasd"); //$NON-NLS-1$
    followUpTable.setDatNtf(cal.getTime());

    List<FollowUpTable> resultat = new ArrayList<FollowUpTable>();
    resultat.add(followUpTable);

    String sIdtitf = "IWS_SIENT1"; //$NON-NLS-1$
    int iTimeOut = 30;

    NotivProvResponse response = new NotivProvResponse();
    NotificationProvisionning rType = new NotificationProvisionning();
    rType.setCodeErreur("OK"); //$NON-NLS-1$
    response.setNotificationProvisionning(rType);

    //Prepare mock
    EasyMock.expect(OAMProxy.getInstance()).andReturn(_oamConnector);
    EasyMock.expectLastCall().times(2);
    EasyMock.expect(_oamConnector.consulterDemandesAAcquitter(EasyMock.isA(Tracabilite.class), EasyMock.eq(10000), EasyMock.eq(sIdtitf), EasyMock.eq(iTimeOut))).andReturn(new ConnectorResponse<List<FollowUpTable>, Retour>(resultat, RetourFactoryForTU.createOkRetour()));
    EasyMock.expect(_oamConnector.mettreAJourDemandeSuivi(EasyMock.isA(Tracabilite.class), EasyMock.eq(followUpTable))).andReturn(new ConnectorResponse<Integer, Retour>(1, RetourFactoryForTU.createOkRetour()));
    EasyMock.expect(NafProxy.getInstance()).andReturn(_nafConnector);
    //EasyMock.expect(_nafConnector.notifierAcqFctOpale(EasyMock.isA(Tracabilite.class), EasyMock.eq(NAF_CONNECTOR_ENT), EasyMock.eq(followUpTable.getIdtAct()), EasyMock.eq(followUpTable.getTypNtf()), EasyMock.eq(iTimeOut), EasyMock.eq(DateTimeFormatPattern.yyyyMMddHHmmss.format(DateTimeTools.toLocalDateTime(followUpTable.getDatFinTrt()))))).andReturn(new ConnectorResponse<NotivProvResponse, Integer>(response, Status.SERVICE_UNAVAILABLE.getStatusCode()));

    // On enregistre le scénario des appels
    PowerMock.replayAll();

    Response responseProcess = executeStartProcess();

    //On demande à PowerMock de vérifier la stack d'appel en fonction du scénario
    PowerMock.verifyAll();

    Assert.assertNotNull(responseProcess);
    Assert.assertEquals(ErrorCode.OK_00200, responseProcess.getErrorCode());

  }

  /**
   * NotifierAcqFctTest : OK (multiple notifications)
   *
   * @throws Throwable
   *           throwable
   */
  //@Test
  // (FBA) Test incorrect desactivé
  // le mock ne semble pas detecté la méthode qui arrive et correspondant pourtant en tout point à la méthode attendue :
  // Unexpected method call NafProxy.notifierAcqFctPP(Tracabilite [_idCorrelationByTel=, _idCorrelationSpirit=4C25AE9D-CA17-4831-9243-30DC02C78079, _nomSysteme=null, _nomProcessus=, _idProcessusSpirit=9c952cd263874e378028c941597fffe4, _refFonc={}], "NAFConnectorPP", "idtactasd", "typntfasd", 30, "20180823155926"):
  // NafProxy.notifierAcqFctPP(isA(com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite), "NAFConnectorPP", "idtactasd", "typntfasd", 30, "20180823155926"): expected: 1, actual: 0
  public void PM029_NotifierAcqFctTest_003() throws Throwable
  {
    Calendar cal = Calendar.getInstance();
    List<FollowUpTable> resultat = new ArrayList<FollowUpTable>();

    String sIdtitf = "IDTITF"; //$NON-NLS-1$
    int nbMaxEntrees = 50;
    int iTimeOut = 30;

    HashMap<String, String> map = new HashMap<String, String>();
    map.put(PM029NotifierAcqFct.SIDTITF, "IDTITF"); //$NON-NLS-1$
    map.put(PM029NotifierAcqFct.NB_MAX_ENTREES, String.valueOf(50));
    map.put(PM029NotifierAcqFct.TIMEOUT_CONSULTER_DEMANDES_ACQUITTER, "30"); //$NON-NLS-1$
    map.put(PM029NotifierAcqFct.TIMEOUT_WS_NOTIFIER_ACQ_FCT, "30"); //$NON-NLS-1$
    map.put(PM029NotifierAcqFct.NAF_CONNECTOR_ID, NAF_CONNECTOR_PP);
    map.put(PM029NotifierAcqFct.WSDL_LIGNE_MARCHE, "PP"); //$NON-NLS-1$

    ConcurrentHashMap<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.clear();
    processParams.put(StringConstants.EMPTY_STRING, map);

    NotifierAcqFctOut response = null;
    NotifierAcqFctReponseType rType = null;
    ReponseServicePIVOTTYPEDansFluxCRFonctionnel rService = null;

    FollowUpTable followUpTable = new FollowUpTable();

    Map<String, String> mapLogDemandes = new HashMap<String, String>();

    //Prepare mock
    EasyMock.expect(OAMProxy.getInstance()).andReturn(_oamConnector);
    EasyMock.expectLastCall().anyTimes();
    EasyMock.expect(_oamConnector.consulterDemandesAAcquitter(EasyMock.isA(Tracabilite.class), EasyMock.eq(nbMaxEntrees), EasyMock.eq(sIdtitf), EasyMock.eq(iTimeOut))).andReturn(new ConnectorResponse<List<FollowUpTable>, Retour>(resultat, RetourFactoryForTU.createOkRetour()));
    //Prepare mock

    Random random = new Random();
    for (int i = 0; i < nbMaxEntrees; i++)
    {
      followUpTable = new FollowUpTable();

      cal.add(Calendar.MINUTE, i);

      followUpTable.setIdtDde("1" + i); //$NON-NLS-1$
      followUpTable.setNomSvc("nomsvcaass"); //$NON-NLS-1$
      followUpTable.setIdtSysTec("idtsystecasd"); //$NON-NLS-1$
      followUpTable.setIdtParSic(2);
      followUpTable.setIdtAct("idtactasd"); //$NON-NLS-1$
      followUpTable.setDatCreact(cal.getTime());
      followUpTable.setIdtItf(sIdtitf);
      followUpTable.setNbrPfi(2);
      followUpTable.setNbrPfiPro(2);
      followUpTable.setDatDebTrt(cal.getTime());
      followUpTable.setDatFinTrt(cal.getTime());
      followUpTable.setEtaRcp("etarcpasd"); //$NON-NLS-1$
      followUpTable.setLibRcp("librcpasd"); //$NON-NLS-1$
      followUpTable.setEtapro("etaproasd"); //$NON-NLS-1$
      followUpTable.setLibPro("libproasd"); //$NON-NLS-1$
      followUpTable.setEtaNtf("etantfasd"); //$NON-NLS-1$
      followUpTable.setLibNtf("libntfasd"); //$NON-NLS-1$
      followUpTable.setTypNtf("typntfasd"); //$NON-NLS-1$
      followUpTable.setDatNtf(cal.getTime());

      resultat.add(followUpTable);

      boolean result = random.nextBoolean();

      response = new NotifierAcqFctOut();
      rType = new NotifierAcqFctReponseType();
      rService = new ReponseServicePIVOTTYPEDansFluxCRFonctionnel();
      rService.setCodeErreur(result ? EnumOKNOK.OK : EnumOKNOK.NOK);

      if (!result)
      {
        rService.setDiagnostic("Diagnostic"); //$NON-NLS-1$
        if (random.nextBoolean())
        {
          rService.setRaison(Consts.DEF_1.toString());
        }
        else
        {
          rService.setRaison(Consts.DEF_4.toString());
          rService.setDiagnostic("Notification déjà reçue"); //$NON-NLS-1$
        }
      }

      if (result)
      {
        mapLogDemandes.put(followUpTable.getIdtDde(), MessageFormat.format(Messages.getString("PM029_NotifierAcqFct.NotifierAcqFctOK"), followUpTable.getIdtDde(), followUpTable.getIdtAct(), StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING)); //$NON-NLS-1$
      }
      else
      {
        if (Consts.DEF_4.toString().equals(rService.getRaison()))
        {
          mapLogDemandes.put(followUpTable.getIdtDde(), MessageFormat.format(Messages.getString("PM029_NotifierAcqFct.NotifierAcqFctOK"), followUpTable.getIdtDde(), followUpTable.getIdtAct(), "NOTIFICATION_DEJA_RECUE", rService.getDiagnostic())); //$NON-NLS-1$ //$NON-NLS-2$
        }
        else
        {
          mapLogDemandes.put(followUpTable.getIdtDde(), MessageFormat.format(Messages.getString("PM029_NotifierAcqFct.NotifierAcqFctKO"), "KOTech", followUpTable.getIdtDde(), followUpTable.getIdtAct(), "ECHEC_NOTIFICATION", rService.getDiagnostic())); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
        }
      }

      rType.setReponseService(rService);
      response.setNotifierAcqFctReponseType(rType);

      //Prepare mock
      EasyMock.expect(_oamConnector.mettreAJourDemandeSuivi(EasyMock.isA(Tracabilite.class), EasyMock.eq(followUpTable))).andReturn(new ConnectorResponse<Integer, Retour>(result ? 1 : 0, RetourFactoryForTU.createOkRetour()));
      EasyMock.expect(NafProxy.getInstance()).andReturn(_nafConnector);
      EasyMock.expect(_nafConnector.notifierAcqFctPP(EasyMock.isA(Tracabilite.class), EasyMock.eq(NAF_CONNECTOR_PP), EasyMock.eq(followUpTable.getIdtAct()), EasyMock.eq(followUpTable.getTypNtf()), EasyMock.eq(iTimeOut), EasyMock.eq(DateTimeFormatPattern.yyyyMMddHHmmss.format(DateTimeTools.toLocalDateTime(followUpTable.getDatFinTrt()))))).andReturn(new ConnectorResponse<NotifierAcqFctOut, Integer>(response, Status.OK.getStatusCode()));
      //Prepare mock
    }

    // On enregistre le scénario des appels
    PowerMock.replayAll();

    Response responseProcess = executeStartProcess();

    //On demande à PowerMock de vérifier la stack d'appel en fonction du scénario
    PowerMock.verifyAll();

    Assert.assertNotNull(responseProcess);
    Assert.assertEquals(ErrorCode.OK_00200, responseProcess.getErrorCode());

  }

  /**
   * NotifierAcqFctTest : OK (multiple notifications)
   *
   * @throws Throwable
   *           throwable
   */
  //@Test
  // (FBA) Test incorrect desactivé
  // le mock ne semble pas detecté la méthode qui arrive et correspondant pourtant en tout point à la méthode attendue :
  // Unexpected method call NafProxy.notifierAcqFctPP(Tracabilite [_idCorrelationByTel=, _idCorrelationSpirit=4C25AE9D-CA17-4831-9243-30DC02C78079, _nomSysteme=null, _nomProcessus=, _idProcessusSpirit=9c952cd263874e378028c941597fffe4, _refFonc={}], "NAFConnectorPP", "idtactasd", "typntfasd", 30, "20180823155926"):
  // NafProxy.notifierAcqFctPP(isA(com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite), "NAFConnectorPP", "idtactasd", "typntfasd", 30, "20180823155926"): expected: 1, actual: 0
  public void PM029_NotifierAcqFctTest_003_ENT() throws Throwable
  {
    Calendar cal = Calendar.getInstance();
    List<FollowUpTable> resultat = new ArrayList<FollowUpTable>();

    String sIdtitf = "IWS_SIENT1"; //$NON-NLS-1$
    int nbMaxEntrees = 50;
    int iTimeOut = 30;

    HashMap<String, String> map = new HashMap<String, String>();
    map.put(PM029NotifierAcqFct.SIDTITF, "IWS_SIENT1"); //$NON-NLS-1$
    map.put(PM029NotifierAcqFct.NB_MAX_ENTREES, String.valueOf(50));
    map.put(PM029NotifierAcqFct.TIMEOUT_CONSULTER_DEMANDES_ACQUITTER, "30"); //$NON-NLS-1$
    map.put(PM029NotifierAcqFct.TIMEOUT_WS_NOTIFIER_ACQ_FCT, "30"); //$NON-NLS-1$
    map.put(PM029NotifierAcqFct.NAF_CONNECTOR_ID, NAF_CONNECTOR_ENT);
    map.put(PM029NotifierAcqFct.WSDL_LIGNE_MARCHE, "ENT"); //$NON-NLS-1$

    ConcurrentHashMap<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.put(StringConstants.EMPTY_STRING, map);

    NotivProvResponse response = null;
    NotificationProvisionning rType = null;

    FollowUpTable followUpTable = new FollowUpTable();

    Map<String, String> mapLogDemandes = new HashMap<String, String>();

    //Prepare mock
    EasyMock.expect(OAMProxy.getInstance()).andReturn(_oamConnector);
    EasyMock.expectLastCall().anyTimes();
    EasyMock.expect(_oamConnector.consulterDemandesAAcquitter(EasyMock.isA(Tracabilite.class), EasyMock.eq(nbMaxEntrees), EasyMock.eq(sIdtitf), EasyMock.eq(iTimeOut))).andReturn(new ConnectorResponse<List<FollowUpTable>, Retour>(resultat, RetourFactoryForTU.createOkRetour()));
    //Prepare mock

    Random random = new Random();
    for (int i = 0; i < nbMaxEntrees; i++)
    {
      followUpTable = new FollowUpTable();

      cal.add(Calendar.MINUTE, i);

      followUpTable.setIdtDde("1" + i); //$NON-NLS-1$
      followUpTable.setNomSvc("nomsvcaass"); //$NON-NLS-1$
      followUpTable.setIdtSysTec("idtsystecasd"); //$NON-NLS-1$
      followUpTable.setIdtParSic(2);
      followUpTable.setIdtAct("idtactasd"); //$NON-NLS-1$
      followUpTable.setDatCreact(cal.getTime());
      followUpTable.setIdtItf(sIdtitf);
      followUpTable.setNbrPfi(2);
      followUpTable.setNbrPfiPro(2);
      followUpTable.setDatDebTrt(cal.getTime());
      followUpTable.setDatFinTrt(cal.getTime());
      followUpTable.setEtaRcp("etarcpasd"); //$NON-NLS-1$
      followUpTable.setLibRcp("librcpasd"); //$NON-NLS-1$
      followUpTable.setEtapro("etaproasd"); //$NON-NLS-1$
      followUpTable.setLibPro("libproasd"); //$NON-NLS-1$
      followUpTable.setEtaNtf("etantfasd"); //$NON-NLS-1$
      followUpTable.setLibNtf("libntfasd"); //$NON-NLS-1$
      followUpTable.setTypNtf("typntfasd"); //$NON-NLS-1$
      followUpTable.setDatNtf(cal.getTime());

      resultat.add(followUpTable);

      boolean result = random.nextBoolean();

      response = new NotivProvResponse();
      rType = new NotificationProvisionning();
      rType.setCodeErreur(result ? "OK" : "NOK"); //$NON-NLS-1$ //$NON-NLS-2$

      if (!result)
      {
        rType.setDiagnostic("Diagnostic"); //$NON-NLS-1$
        if (random.nextBoolean())
        {
          rType.setRaison(Consts.DEF_1.toString());
        }
        else
        {
          rType.setRaison(Consts.DEF_4.toString());
          rType.setDiagnostic("Notification déjà reçue"); //$NON-NLS-1$
        }
      }

      if (result)
      {
        mapLogDemandes.put(followUpTable.getIdtDde(), MessageFormat.format(Messages.getString("PM029_NotifierAcqFct.NotifierAcqFctOK"), followUpTable.getIdtDde(), followUpTable.getIdtAct(), StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING)); //$NON-NLS-1$
      }
      else
      {
        if (Consts.DEF_4.toString().equals(rType.getRaison()))
        {
          mapLogDemandes.put(followUpTable.getIdtDde(), MessageFormat.format(Messages.getString("PM029_NotifierAcqFct.NotifierAcqFctOK"), followUpTable.getIdtDde(), followUpTable.getIdtAct(), "NOTIFICATION_DEJA_RECUE", rType.getDiagnostic())); //$NON-NLS-1$ //$NON-NLS-2$
        }
        else
        {
          mapLogDemandes.put(followUpTable.getIdtDde(), MessageFormat.format(Messages.getString("PM029_NotifierAcqFct.NotifierAcqFctKO"), "KOTech", followUpTable.getIdtDde(), followUpTable.getIdtAct(), "ECHEC_NOTIFICATION", rType.getDiagnostic())); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
        }
      }

      response.setNotificationProvisionning(rType);

      //Prepare mock
      EasyMock.expect(_oamConnector.mettreAJourDemandeSuivi(EasyMock.isA(Tracabilite.class), EasyMock.eq(followUpTable))).andReturn(new ConnectorResponse<Integer, Retour>(result ? 1 : 0, RetourFactoryForTU.createOkRetour()));
      EasyMock.expect(NafProxy.getInstance()).andReturn(_nafConnector);
      EasyMock.expect(_nafConnector.notifierAcqFctOpale(EasyMock.isA(Tracabilite.class), EasyMock.eq(NAF_CONNECTOR_ENT), EasyMock.eq(followUpTable.getIdtAct()), EasyMock.eq(followUpTable.getTypNtf()), EasyMock.eq(iTimeOut), EasyMock.eq(DateTimeFormatPattern.yyyyMMddHHmmss.format(DateTimeTools.toLocalDateTime(followUpTable.getDatFinTrt()))))).andReturn(new ConnectorResponse<NotivProvResponse, Integer>(response, Status.OK.getStatusCode()));

      //Prepare mock
    }

    // On enregistre le scénario des appels
    PowerMock.replayAll();

    //_oamConnector.addData_consulterDemandesAAcquitter(nbMaxEntrees, sIdtitf, iTimeOut, resultat, RetourFactoryForTU.createOkRetour(), ravelException);

    Response responseProcess = executeStartProcess();

    //On demande à PowerMock de vérifier la stack d'appel en fonction du scénario
    PowerMock.verifyAll();

    Assert.assertNotNull(responseProcess);
    Assert.assertEquals(ErrorCode.OK_00200, responseProcess.getErrorCode());

  }

  /**
   * NotifierAcqFctTest : KO
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PM029_NotifierAcqFctTest_005() throws Throwable
  {
    ConcurrentHashMap<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.get(StringConstants.EMPTY_STRING).remove(PM029NotifierAcqFct.NB_MAX_ENTREES);

    PowerMock.replayAll();
    //Prepare mock

    Response responseProcess = executeStartProcess();

    //On demande à PowerMock de vérifier la stack d'appel en fonction du scénario
    PowerMock.verifyAll();

    Assert.assertNotNull(responseProcess);
    Assert.assertEquals(ErrorCode.PRCESS_00002, responseProcess.getErrorCode());

  }

  /**
   * NotifierAcqFctTest : KO
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PM029_NotifierAcqFctTest_006() throws Throwable
  {
    int nbEntrees = -1;

    ConcurrentHashMap<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.get(StringConstants.EMPTY_STRING).put(PM029NotifierAcqFct.NB_MAX_ENTREES, Integer.toString(nbEntrees));

    PowerMock.replayAll();
    //Prepare mock

    Response responseProcess = executeStartProcess();

    //On demande à PowerMock de vérifier la stack d'appel en fonction du scénario
    PowerMock.verifyAll();

    Assert.assertNotNull(responseProcess);
    Assert.assertEquals(ErrorCode.PRCESS_00002, responseProcess.getErrorCode());

  }

  /**
   * NotifierAcqFctTest : KO
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PM029_NotifierAcqFctTest_007() throws Throwable
  {
    ConcurrentHashMap<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.get(StringConstants.EMPTY_STRING).remove(PM029NotifierAcqFct.TIMEOUT_CONSULTER_DEMANDES_ACQUITTER);

    PowerMock.replayAll();
    //Prepare mock

    Response responseProcess = executeStartProcess();

    //On demande à PowerMock de vérifier la stack d'appel en fonction du scénario
    PowerMock.verifyAll();

    Assert.assertNotNull(responseProcess);
    Assert.assertEquals(ErrorCode.PRCESS_00002, responseProcess.getErrorCode());

  }

  /**
   * NotifierAcqFctTest : KO
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PM029_NotifierAcqFctTest_008() throws Throwable
  {
    ConcurrentHashMap<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.get(StringConstants.EMPTY_STRING).remove(PM029NotifierAcqFct.TIMEOUT_WS_NOTIFIER_ACQ_FCT);

    PowerMock.replayAll();
    //Prepare mock

    Response responseProcess = executeStartProcess();

    //On demande à PowerMock de vérifier la stack d'appel en fonction du scénario
    PowerMock.verifyAll();

    Assert.assertNotNull(responseProcess);
    Assert.assertEquals(ErrorCode.PRCESS_00002, responseProcess.getErrorCode());

  }

  /**
   * NotifierAcqFctTest : KO
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PM029_NotifierAcqFctTest_009() throws Throwable
  {
    ConcurrentHashMap<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.get(StringConstants.EMPTY_STRING).remove(PM029NotifierAcqFct.NAF_CONNECTOR_ID);

    PowerMock.replayAll();
    //Prepare mock

    Response responseProcess = executeStartProcess();

    //On demande à PowerMock de vérifier la stack d'appel en fonction du scénario
    PowerMock.verifyAll();

    Assert.assertNotNull(responseProcess);
    Assert.assertEquals(ErrorCode.PRCESS_00002, responseProcess.getErrorCode());

  }

  /**
   * NotifierAcqFctTest : KO
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PM029_NotifierAcqFctTest_010() throws Throwable
  {
    ConcurrentHashMap<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.get(StringConstants.EMPTY_STRING).remove(PM029NotifierAcqFct.WSDL_LIGNE_MARCHE);

    PowerMock.replayAll();
    //Prepare mock

    Response responseProcess = executeStartProcess();

    //On demande à PowerMock de vérifier la stack d'appel en fonction du scénario
    PowerMock.verifyAll();

    Assert.assertNotNull(responseProcess);
    Assert.assertEquals(ErrorCode.PRCESS_00002, responseProcess.getErrorCode());

  }

  /**
   * NotifierAcqFctTest : KO
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PM029_NotifierAcqFctTest_011() throws Throwable
  {
    String ligneMarche = "TEST"; //$NON-NLS-1$

    ConcurrentHashMap<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.get(StringConstants.EMPTY_STRING).put(PM029NotifierAcqFct.WSDL_LIGNE_MARCHE, ligneMarche);

    PowerMock.replayAll();
    //Prepare mock

    Response responseProcess = executeStartProcess();

    //On demande à PowerMock de vérifier la stack d'appel en fonction du scénario
    PowerMock.verifyAll();

    Assert.assertNotNull(responseProcess);
    Assert.assertEquals(ErrorCode.PRCESS_00002, responseProcess.getErrorCode());

  }

  /**
   * NotifierAcqFctTest : OK
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PM029_NotifierAcqFctTest_012() throws Throwable
  {
    String sIdtitf = "IDTITF"; //$NON-NLS-1$
    int iTimeOut = 30;

    NotifierAcqFctOut response = new NotifierAcqFctOut();
    NotifierAcqFctReponseType rType = new NotifierAcqFctReponseType();
    ReponseServicePIVOTTYPEDansFluxCRFonctionnel rService = new ReponseServicePIVOTTYPEDansFluxCRFonctionnel();
    rService.setCodeErreur(EnumOKNOK.OK);
    rType.setReponseService(rService);
    response.setNotifierAcqFctReponseType(rType);

    //Prepare mock
    EasyMock.expect(OAMProxy.getInstance()).andReturn(_oamConnector);
    EasyMock.expectLastCall().times(1);
    EasyMock.expect(_oamConnector.consulterDemandesAAcquitter(EasyMock.isA(Tracabilite.class), EasyMock.eq(10000), EasyMock.eq(sIdtitf), EasyMock.eq(iTimeOut))).andReturn(new ConnectorResponse<List<FollowUpTable>, Retour>(null, RetourFactoryForTU.createKO("", "", "", null))); //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$
    // On enregistre le scénario des appels
    PowerMock.replayAll();
    //Prepare mock

    Response responseProcess = executeStartProcess();

    //On demande à PowerMock de vérifier la stack d'appel en fonction du scénario
    PowerMock.verifyAll();

    Assert.assertNotNull(responseProcess);
    Assert.assertEquals(ErrorCode.PRCESS_00002, responseProcess.getErrorCode());
  }

  /**
   * Add custom headers
   *
   * @param requestHeader_p
   *          request to add headers
   * @param tracabilite_p
   *          object to add headers from
   */
  private void addXHeaders(List<RequestHeader> requestHeader_p, Tracabilite tracabilite_p)
  {
    RequestHeader hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_REQUEST_ID);
    hdr.setValue(tracabilite_p.getIdCorrelationByTel());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_REQUEST_ID_SPIRIT);
    hdr.setValue(tracabilite_p.getIdCorrelationSpirit());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_SOURCE);
    hdr.setValue(tracabilite_p.getNomSysteme());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_PROCESS);
    hdr.setValue(tracabilite_p.getNomProcessus());
    requestHeader_p.add(hdr);

  }

  /**
   * Execute start process.
   *
   * @return response
   *
   * @throws Throwable
   *           The throwable.
   */
  private Response executeStartProcess() throws Throwable
  {
    Request request = new Request(DEFAULT_PROCESSNAME, "idProcess", "idClient"); //$NON-NLS-1$ //$NON-NLS-2$
    request.setMsgId(Test_Consts.DEFAULT_MSGID);

    List<Parameter> params = new ArrayList<>();

    params.add(new Parameter(ParameterUrl.idAppelant.name(), "idAppelant")); //$NON-NLS-1$
    params.add(new Parameter(ParameterUrl.idFlux.name(), "idFlux")); //$NON-NLS-1$

    UrlParameters urlParameters = new UrlParameters(params);

    addXHeaders(request.getRequestHeader(), _tracabilite);

    request.setUrlParameters(urlParameters);
    _currentInstance.run(request);

    return (Response) request.getResponse();
  }
}
