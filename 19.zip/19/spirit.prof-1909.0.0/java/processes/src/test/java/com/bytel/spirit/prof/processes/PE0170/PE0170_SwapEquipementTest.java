/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.prof.processes.PE0170;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.text.MessageFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

import org.easymock.Capture;
import org.easymock.CaptureType;
import org.easymock.EasyMock;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockNice;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PowerMockListener;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.testlisteners.FieldDefaulter;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.modules.junit4.PowerMockRunnerDelegate;
import org.powermock.reflect.Whitebox;
import org.springframework.test.context.ContextConfiguration;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.data.exchange.generated.RavelRequest;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.response.IRavelResponse;
import com.bytel.ravel.common.factory.response.RavelResponseFactory;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.test.JUnitTools;
import com.bytel.ravel.common.test.podam.JavaTimeManufacturer;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.test.podam.PodamBytelJUnit4ClassRunner;
import com.bytel.ravel.common.utils.DateTimeTools;
import com.bytel.ravel.common.utils.Pair;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.RetourFactoryForTU;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.ProcessManager;
import com.bytel.spirit.common.activities.ossfai.OSSFAI_SI012_RecupererIdCmdRaccoEnCours;
import com.bytel.spirit.common.activities.ossfai.OSSFAI_SI012_RecupererIdCmdRaccoEnCours.OSSFAI_SI012_RecupererIdCmdRaccoEnCoursBuilder;
import com.bytel.spirit.common.activities.ossfai.OSSFAI_SI013_RecupererIdCmdEquipement;
import com.bytel.spirit.common.activities.ossfai.OSSFAI_SI013_RecupererIdCmdEquipement.OSSFAI_SI013_RecupererIdCmdEquipementBuilder;
import com.bytel.spirit.common.activities.ossfai.OSSFAI_SI014_RecupererListeEquipementParCommandeEtParType;
import com.bytel.spirit.common.activities.ossfai.OSSFAI_SI014_RecupererListeEquipementParCommandeEtParType.OSSFAI_SI014_RecupererListeEquipementParCommandeEtParTypeBuilder;
import com.bytel.spirit.common.activities.ossfai.OSSFAI_SI015_LibererEquipement;
import com.bytel.spirit.common.activities.ossfai.OSSFAI_SI015_LibererEquipement.OSSFAI_SI015_LibererEquipementBuilder;
import com.bytel.spirit.common.activities.ossfai.OSSFAI_SI016_RecupererInfoVerrouDecLibEqt;
import com.bytel.spirit.common.activities.ossfai.OSSFAI_SI016_RecupererInfoVerrouDecLibEqt.OSSFAI_SI016_RecupererInfoVerrouDecLibEqtBuilder;
import com.bytel.spirit.common.activities.ossfai.OSSFAI_SI017_DeclarerEquipement;
import com.bytel.spirit.common.activities.ossfai.OSSFAI_SI017_DeclarerEquipement.OSSFAI_SI017_DeclarerEquipementBuilder;
import com.bytel.spirit.common.activities.shared.BL4600_CreerErreurSpirit;
import com.bytel.spirit.common.activities.shared.BL4600_CreerErreurSpirit.BL4600_CreerErreurSpiritBuilder;
import com.bytel.spirit.common.activities.shared.BL800_ObtenirSequence;
import com.bytel.spirit.common.activities.shared.BL800_ObtenirSequence.BL800_ObtenirSequenceBuilder;
import com.bytel.spirit.common.activities.shared.structs.UniqueIdConstant;
import com.bytel.spirit.common.connectors.cmd.CMDProxy;
import com.bytel.spirit.common.connectors.rpg.RPGProxy;
import com.bytel.spirit.common.generated.ws.equipement.CommandeONT;
import com.bytel.spirit.common.generated.ws.equipement.CommandeSTB;
import com.bytel.spirit.common.generated.ws.equipement.CreationOss;
import com.bytel.spirit.common.generated.ws.equipement.Manufacturer;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.error.ReponseErreur;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.cmd.Commande;
import com.bytel.spirit.common.shared.saab.cmd.Statut;
import com.bytel.spirit.common.shared.saab.cmd.request.CreateCommandeRequest;
import com.bytel.spirit.common.shared.saab.rpg.PFI;
import com.bytel.spirit.prof.connectors.bssgp.activities.BSSGP_SI002_EnvoyerCRSwap;
import com.bytel.spirit.prof.connectors.bssgp.activities.BSSGP_SI002_EnvoyerCRSwap.BSSGP_SI002_EnvoyerCRSwapBuilder;
import com.bytel.spirit.prof.connectors.generated.config.ConfigCoherenceEquipement;
import com.bytel.spirit.prof.processes.Messages;
import com.bytel.spirit.prof.processes.PE0170.PE0170_SwapEquipement.State;
import com.bytel.spirit.prof.processes.PE0170.structs.EquipementCible;
import com.bytel.spirit.prof.processes.PE0170.structs.EquipementSource;
import com.bytel.spirit.prof.processes.PE0170.structs.InfosService;
import com.bytel.spirit.prof.processes.PE0170.structs.PE0170_BL100_VerifierFonctionnelReturn;
import com.bytel.spirit.prof.processes.PE0170.structs.PE0170_ConfigCoherenceEquipement;
import com.bytel.spirit.prof.processes.PE0170.structs.PE0170_Eqt;
import com.bytel.spirit.prof.processes.PE0170.structs.PortefeuilleServices;
import com.bytel.spirit.prof.processes.PE0170.structs.SwapEqt;
import com.bytel.spirit.prof.processes.PE0170.structs.TypeAcces;
import com.bytel.spirit.prof.processes.PE0170.structs.TypeEquipement;
import com.bytel.spirit.prof.processes.PE0170.structs.TypeSwap;

import fr.bouyguestelecom.dolmen.ossservices.guichet.DeclarationEquipement;
import fr.bouyguestelecom.dolmen.ossservices.guichet.EtatCommandeEnum;
import fr.bouyguestelecom.dolmen.ossservices.guichet.LiberationEquipement;
import fr.bouyguestelecom.dolmen.ossservices.guichet.TypeCommandeEnum;
import fr.bouyguestelecom.dolmen.ossservices.suivi.CommandeEquipement;
import fr.bouyguestelecom.dolmen.ossservices.suivi.ContexteCommandeOss;
import fr.bouyguestelecom.dolmen.ossservices.suivi.SystemeTechnique;
import fr.bytel.oss.diag.odad.Command;
import fr.bytel.oss.diag.odad.CommandsByPortfolios;
import fr.bytel.oss.diag.odad.GetOrdersInfoByPortfolioResp;
import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 * @author jpais
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PowerMockListener(FieldDefaulter.class)
@PowerMockRunnerDelegate(PodamBytelJUnit4ClassRunner.class)
@ContextConfiguration("classpath:BeansProcessTestMocks.xml")
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
@PrepareForTest({ PE0170_SwapEquipement.class, RPGProxy.class, CMDProxy.class, OSSFAI_SI012_RecupererIdCmdRaccoEnCours.class, OSSFAI_SI012_RecupererIdCmdRaccoEnCoursBuilder.class, OSSFAI_SI013_RecupererIdCmdEquipement.class, OSSFAI_SI013_RecupererIdCmdEquipementBuilder.class, OSSFAI_SI014_RecupererListeEquipementParCommandeEtParType.class, OSSFAI_SI014_RecupererListeEquipementParCommandeEtParTypeBuilder.class, OSSFAI_SI015_LibererEquipementBuilder.class, OSSFAI_SI015_LibererEquipement.class, BL800_ObtenirSequenceBuilder.class, BL800_ObtenirSequence.class, BSSGP_SI002_EnvoyerCRSwap.class, BSSGP_SI002_EnvoyerCRSwapBuilder.class, BL4600_CreerErreurSpiritBuilder.class, BL4600_CreerErreurSpirit.class, BL800_ObtenirSequenceBuilder.class, BL800_ObtenirSequence.class, })
public class PE0170_SwapEquipementTest
{
  /**
   *
   */
  private static final String PE0170_SWAP_EQUIPEMENT_CONTINUE_PROCESS = "PE0170_SwapEquipement.continueProcess"; //$NON-NLS-1$

  /**
   * ConfigCoherenceEquipement Param
   */
  private static final String CONFIG_COHERENCE_EQUIPEMENT_PARAM = "CONFIG_COHERENCE_EQUIPEMENT_PATH"; //$NON-NLS-1$

  /**
   * ControleSNActifIad Param
   */
  private static final String CONFIG_CONTROLE_SN_ACTIF_IAD_PARAM = "ControleSNActifIad"; //$NON-NLS-1$

  /**
   * ControleSNActifStb Param
   */
  private static final String CONFIG_CONTROLE_SN_ACTIF_STB_PARAM = "ControleSNActifStb"; //$NON-NLS-1$

  /**
   * ControleSNActifOnt Param
   */
  private static final String CONFIG_CONTROLE_SN_ACTIF_ONT_PARAM = "ControleSNActifOnt"; //$NON-NLS-1$

  /**
   * ControleEquipementActif Param
   */
  private static final String CONFIG_CONTROLE_EQUIPEMENT_ACTIF_PARAM = "ControleEquipementActif"; //$NON-NLS-1$

  /**
   * nbVerifMax Param
   */
  private static final String CONFIG_NBVERIFMAX_PARAM = "nbVerifMax"; //$NON-NLS-1$

  /**
   * The constant for PE0170.BL101.MauvaisFormatError message
   */
  private static final String MESSAGE_BAD_FORMAT_ERROR = Messages.getString("PE0170.BL101.MauvaisFormatError"); //$NON-NLS-1$

  /**
   * The constant for PE0170.BL102.InvalidEquipError message
   */
  private static final String MESSAGE_INVALID_EQUIP_ERROR = Messages.getString("PE0170.BL102.InvalidEquipError"); //$NON-NLS-1$

  /**
   * The constant for PE0170.BL100.NoCompteInconnu message
   */
  private static final String MESSAGE_NO_COMPTE_INCONNU = Messages.getString("PE0170.BL100.NoCompteInconnu"); //$NON-NLS-1$

  /**
   * The constant for PE0170.BL103.StiError message
   */
  private static final String MESSAGE_STI_ERROR = Messages.getString("PE0170.BL103.StiError"); //$NON-NLS-1$

  /**
   * idCmdRaccoEnCours constant
   */
  private static final String ID_CMD_RACCO_EN_COURS = "idCmdRaccoEnCours"; //$NON-NLS-1$

  /**
   * identifiantTechniqueEqtALiberer constant
   */
  private static final String IDENTIFIANT_TECHNIQUE_EQT_A_LIBERER = "identifiantTechniqueEqtALiberer"; //$NON-NLS-1$

  /**
   * The constant for PE0170.BL100.PlusieursCommandesEnCours message
   */
  private static final String MESSAGE_PLUSIEURS_COMMANDES_EN_COURS = Messages.getString("PE0170.BL100.PlusieursCommandesEnCours"); //$NON-NLS-1$

  /**
   * The constant for PE0170.BL100.PasDeCommandeEnCours message
   */
  private static final String MESSAGE_PAS_DE_COMMANDE_EN_COURS = Messages.getString("PE0170.BL100.PasDeCommandeEnCours"); //$NON-NLS-1$

  /**
   * The constant for PE0170.BL400.ProblemeCalculSrvId message
   */
  private static final String MESSAGE_PROBLEME_CALCUL_SRVID = Messages.getString("PE0170.BL400.ProblemeCalculSrvId"); //$NON-NLS-1$

  /**
   * The constant for PE0170.BL500.CommandeStatutInvalideCloturer message
   */
  private static final String MESSAGE_COMMANDE_STATUT_INVALIDE_CLOTURER = Messages.getString("PE0170.BL500.CommandeStatutInvalideCloturer"); //$NON-NLS-1$

  /**
   * The constant for PE0170.BL600.WrongTechError message
   */
  private static final String MESSAGE_WRONG_TECH_ERREUR = Messages.getString("PE0170.BL600.WrongTechError"); //$NON-NLS-1$

  /**
   * The constant for PE0170.BL600.CommandeExistantError message
   */
  private static final String MESSAGE_COMMANDE_EXISTANTE_ERREUR = Messages.getString("PE0170.BL600.CommandeExistantError"); //$NON-NLS-1$

  /*
   * Tracabilite
   */
  private static Tracabilite _tracabilite;

  /**
   * The constant for PE0170.NbIterationMax
   */
  private static final String MESSAGE_NB_ITERATION_MAX = Messages.getString("PE0170.NbIterationMax"); //$NON-NLS-1$

  /**
   * Factory to generate beans
   */
  private static PodamFactory __podam;

  /**
   * Run before tests
   *
   * @throws Exception
   *           throw exception
   */
  @BeforeClass
  public static void setUpBeforeClass() throws Exception
  {
    // désactivation du cache podam
    __podam = new PodamFactoryImpl();
    __podam.getStrategy().setMemoization(false);
    __podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());
    JavaTimeManufacturer.registerPodamFactory(__podam);
  }

  /**
   * Mock de {@link ProcessManager}
   */
  //@MockStrict
  //ProcessManager _processManager;

  /**
   * Instance of {@code PE0170_SwapEquipement}
   */
  private PE0170_SwapEquipement _processInstance;

  /**
   * _RPGProxy Mock
   */
  @MockStrict
  RPGProxy _rpgProxyMock;

  /**
   * _CMDProxy Mock
   */
  @MockStrict
  CMDProxy _cmdProxyMock;

  /**
   * The BL4600 mock
   */
  @MockStrict
  BL4600_CreerErreurSpirit _bl4600Mock;

  /**
   * The BL4600 builder mock
   */
  @MockStrict
  BL4600_CreerErreurSpiritBuilder _bl4600BuilderMock;

  /**
   * The SI012 activity mock
   */
  @MockStrict
  OSSFAI_SI012_RecupererIdCmdRaccoEnCours _si012Mock;

  /**
   * The SI012 activity builder mock
   */
  @MockStrict
  OSSFAI_SI012_RecupererIdCmdRaccoEnCoursBuilder _si012BuilderMock;

  /**
   * The SI013 activity mock
   */
  @MockStrict
  OSSFAI_SI013_RecupererIdCmdEquipement _si013Mock;

  /**
   * The SI013 activity builder mock
   */
  @MockStrict
  OSSFAI_SI013_RecupererIdCmdEquipement.OSSFAI_SI013_RecupererIdCmdEquipementBuilder _si013BuilderMock;

  /**
   * The SI014 activity mock
   */
  @MockStrict
  OSSFAI_SI014_RecupererListeEquipementParCommandeEtParType _si014Mock;

  /**
   * The SI014 activity builder mock
   */
  @MockStrict
  OSSFAI_SI014_RecupererListeEquipementParCommandeEtParType.OSSFAI_SI014_RecupererListeEquipementParCommandeEtParTypeBuilder _si014BuilderMock;

  /**
   * The SI015 activity mock
   */
  @MockStrict
  OSSFAI_SI015_LibererEquipement _si015Mock;

  /**
   * The SI015 activity builder mock
   */
  @MockStrict
  OSSFAI_SI015_LibererEquipementBuilder _si015BuilderMock;

  /**
   * The SI016 activity mock
   */
  @MockStrict
  OSSFAI_SI016_RecupererInfoVerrouDecLibEqt _si016Mock;

  /**
   * The SI016 activity builder mock
   */
  @MockStrict
  OSSFAI_SI016_RecupererInfoVerrouDecLibEqtBuilder _si016BuilderMock;

  /**
   * The SI017 activity mock
   */
  @MockStrict
  OSSFAI_SI017_DeclarerEquipement _si017Mock;

  /**
   * The SI017 activity builder mock
   */
  @MockStrict
  OSSFAI_SI017_DeclarerEquipementBuilder _si017BuilderMock;

  /**
   * The BSSGP_SI002 activity mock
   */
  @MockNice
  BSSGP_SI002_EnvoyerCRSwap _bssGpSI002Mock;

  /**
   * The BSSGP_SI002 activity builder mock
   */
  @MockNice
  BSSGP_SI002_EnvoyerCRSwapBuilder _bssGpSI002BuilderMock;

  /**
  *
  */
  @MockStrict
  private BL800_ObtenirSequenceBuilder _bl800BuilderMock;

  /**
  *
  */
  @MockStrict
  private BL800_ObtenirSequence _bl800Mock;

  /**
   * Setup configuration
   */
  @Before
  public void beforeTest()
  {
    PowerMock.resetAll();
    PowerMock.mockStatic(RPGProxy.class);
    PowerMock.mockStatic(CMDProxy.class);
    PowerMock.mockStatic(OSSFAI_SI012_RecupererIdCmdRaccoEnCours.class);
    PowerMock.mockStatic(OSSFAI_SI012_RecupererIdCmdRaccoEnCoursBuilder.class);
    PowerMock.mockStatic(OSSFAI_SI013_RecupererIdCmdEquipement.class);
    PowerMock.mockStatic(OSSFAI_SI013_RecupererIdCmdEquipementBuilder.class);
    PowerMock.mockStatic(OSSFAI_SI014_RecupererListeEquipementParCommandeEtParType.class);
    PowerMock.mockStatic(OSSFAI_SI014_RecupererListeEquipementParCommandeEtParTypeBuilder.class);
    PowerMock.mockStatic(OSSFAI_SI015_LibererEquipement.class);
    PowerMock.mockStatic(OSSFAI_SI015_LibererEquipementBuilder.class);
    PowerMock.mockStatic(BL800_ObtenirSequence.class);
    PowerMock.mockStatic(BL800_ObtenirSequenceBuilder.class);
    PowerMock.mockStatic(BL4600_CreerErreurSpirit.class);
    PowerMock.mockStatic(BL4600_CreerErreurSpiritBuilder.class);
    PowerMock.mockStaticNice(BSSGP_SI002_EnvoyerCRSwap.class);
    PowerMock.mockStaticNice(BSSGP_SI002_EnvoyerCRSwapBuilder.class);
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. Assert that validation errors exist.<br>
   * <b>Input:</b> The required field portefeuilleServices is null.<br>
   * <b>Result:</b> Attribut(s) obligatoire(s) manquant(s): [_portefeuilleServices]
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_BL001_VerifierDonnees_Test_CONTRAINTE_01() throws Exception
  {
    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, "Attribut(s) obligatoire(s) manquant(s): [_equipementSource._noIdentifiant]", null); //$NON-NLS-1$

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    fillAllRequestHeaders(request);
    _tracabilite.setIdCorrelationByTel("125667889000877"); //$NON-NLS-1$
    request.setHttpMethod("POST"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    SwapEqt swapEqtRequest = buildValidSwapEqtRequest();

    swapEqtRequest.getEquipementSource().setNoIdentifiant(null); //cause validation error

    String jsonRequest = GsonTools.getGson(DateTimeTools.DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(swapEqtRequest, SwapEqt.class);

    request.setPayload(jsonRequest);
    Pair<Retour, String> retour = Whitebox.invokeMethod(_processInstance, "PE0170_BL001_VerifierDonnees", _tracabilite, request); //$NON-NLS-1$

    assertEquals(retourExpected, retour._first);
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. Assert that validation errors exist.<br>
   * <b>Input:</b> The required field portefeuilleServices is null.<br>
   * <b>Result:</b> Attribut(s) obligatoire(s) manquant(s): [_portefeuilleServices]
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_BL001_VerifierDonnees_Test_CONTRAINTE_02() throws Exception
  {
    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, "Format d'attribut(s) non respecté(s): [_equipementSource._noIdentifiant]", null); //$NON-NLS-1$

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    fillAllRequestHeaders(request);
    _tracabilite.setIdCorrelationByTel("125667889000877"); //$NON-NLS-1$
    request.setHttpMethod("POST"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    SwapEqt swapEqtRequest = buildValidSwapEqtRequest();

    swapEqtRequest.getEquipementSource().setNoIdentifiant(""); //$NON-NLS-1$ //cause validation error

    String jsonRequest = GsonTools.getGson(DateTimeTools.DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(swapEqtRequest, SwapEqt.class);

    request.setPayload(jsonRequest);
    Pair<Retour, String> retour = Whitebox.invokeMethod(_processInstance, "PE0170_BL001_VerifierDonnees", _tracabilite, request); //$NON-NLS-1$

    assertEquals(retourExpected, retour._first);
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. Assert that validation errors exist.<br>
   * <b>Input:</b> The required field portefeuilleServices is null.<br>
   * <b>Result:</b> Attribut(s) obligatoire(s) manquant(s): [_portefeuilleServices]
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_BL001_VerifierDonnees_Test_CONTRAINTE_03() throws Exception
  {
    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, "Format d'attribut(s) non respecté(s): [_equipementSource._noIdentifiant]", null); //$NON-NLS-1$

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    fillAllRequestHeaders(request);
    _tracabilite.setIdCorrelationByTel("125667889000877"); //$NON-NLS-1$
    request.setHttpMethod("POST"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    SwapEqt swapEqtRequest = buildValidSwapEqtRequest();

    swapEqtRequest.getEquipementSource().setNoIdentifiant("0123456789ABCDEF"); //$NON-NLS-1$ //cause validation error

    String jsonRequest = GsonTools.getGson(DateTimeTools.DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(swapEqtRequest, SwapEqt.class);

    request.setPayload(jsonRequest);
    Pair<Retour, String> retour = Whitebox.invokeMethod(_processInstance, "PE0170_BL001_VerifierDonnees", _tracabilite, request); //$NON-NLS-1$

    assertEquals(retourExpected, retour._first);
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. Assert that validation errors exist.<br>
   * <b>Input:</b> The required field portefeuilleServices is null.<br>
   * <b>Result:</b> Attribut(s) obligatoire(s) manquant(s): [_portefeuilleServices]
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_BL001_VerifierDonnees_Test_KO_01() throws Exception
  {
    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, "Attribut(s) obligatoire(s) manquant(s): [_portefeuilleServices]", null); //$NON-NLS-1$

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    fillAllRequestHeaders(request);
    _tracabilite.setIdCorrelationByTel("125667889000877"); //$NON-NLS-1$
    request.setHttpMethod("POST"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    SwapEqt swapEqtRequest = buildValidSwapEqtRequest();
    swapEqtRequest.setPortefeuilleServices(null); //cause validation error

    String jsonRequest = GsonTools.getGson(DateTimeTools.DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(swapEqtRequest, SwapEqt.class);

    request.setPayload(jsonRequest);
    Pair<Retour, String> retour = Whitebox.invokeMethod(_processInstance, "PE0170_BL001_VerifierDonnees", _tracabilite, request); //$NON-NLS-1$

    assertEquals(retourExpected, retour._first);
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. Assert that validation errors exist.<br>
   * <b>Input:</b> The required field idCommande of InfosServices is null.<br>
   * <b>Result:</b> Attribut(s) obligatoire(s) manquant(s): [_infosService._idCommande]
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_BL001_VerifierDonnees_Test_KO_02() throws Exception
  {
    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, "Attribut(s) obligatoire(s) manquant(s): [_infosService._idCommande]", null); //$NON-NLS-1$

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    fillAllRequestHeaders(request);
    _tracabilite.setIdCorrelationByTel("125667889000877"); //$NON-NLS-1$
    request.setHttpMethod("POST"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    SwapEqt swapEqtRequest = buildValidSwapEqtRequest();
    swapEqtRequest.getInfosService().setIdCommande(null); //cause validation error

    String jsonRequest = GsonTools.getGson(DateTimeTools.DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(swapEqtRequest, SwapEqt.class);

    request.setPayload(jsonRequest);
    Pair<Retour, String> retour = Whitebox.invokeMethod(_processInstance, "PE0170_BL001_VerifierDonnees", _tracabilite, request); //$NON-NLS-1$

    assertEquals(retourExpected, retour._first);
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. Assert that validation errors exist.<br>
   * <b>Input:</b> The required field idCommande of InfosServices and the field EquipementCible are null.<br>
   * <b>Result:</b> Attribut(s) obligatoire(s) manquant(s): [_infosService._idCommande]
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_BL001_VerifierDonnees_Test_KO_03() throws Exception
  {
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    fillAllRequestHeaders(request);
    _tracabilite.setIdCorrelationByTel("125667889000877"); //$NON-NLS-1$
    request.setHttpMethod("POST"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    SwapEqt swapEqtRequest = buildValidSwapEqtRequest();
    swapEqtRequest.getInfosService().setIdCommande(null); //cause validation error
    swapEqtRequest.setEquipementCible(null);

    String jsonRequest = GsonTools.getGson(DateTimeTools.DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(swapEqtRequest, SwapEqt.class);

    request.setPayload(jsonRequest);
    Pair<Retour, String> retour = Whitebox.invokeMethod(_processInstance, "PE0170_BL001_VerifierDonnees", _tracabilite, request); //$NON-NLS-1$

    assertTrue(retour._first.getLibelle().contains("_infosService._idCommande")); //$NON-NLS-1$
    assertTrue(retour._first.getLibelle().contains("_equipementCible")); //$NON-NLS-1$
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. The required header X-Client-Operateur is not set.<br>
   * <b>Input:</b> "X-Client-Operateur" not set in headers.<br>
   * <b>Result:</b> Retour {KO, CAT-3, NON_RESPECT_STI, Header X-Client-Operateur null ou vide.
   * PE0170_BL001_VerifierDonnees}
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_BL001_VerifierDonnees_Test_KO_04() throws Exception
  {
    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString("PE0170.BL001.HeaderNullOrEmpty"), IHttpHeadersConsts.X_CLIENT_OPERATEUR), null); //$NON-NLS-1$

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RavelRequest.RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RavelRequest.RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "SWAP RACCO"); //$NON-NLS-1$
    RavelRequest.RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "DOMINGO"); //$NON-NLS-1$

    fillRequestHeaders(request, xRequestId, xProcess, xSource);

    _processInstance.getProcessContext().setXClientOperateur(null);

    Pair<Retour, String> retour = Whitebox.invokeMethod(_processInstance, "PE0170_BL001_VerifierDonnees", _tracabilite, request); //$NON-NLS-1$

    assertEquals(retourExpected, retour._first);
  }

  /**
   * <b>Scenario:</b> Tests nominal case OK.<br>
   * <b>Input:</b> All valid inputs.<br>
   * <b>Result:</b> Retour OK.
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_BL001_VerifierDonnees_Test_OK() throws Exception
  {
    Retour retourExpected = RetourFactory.createOkRetour();
    String expectedSrvId = "39506957"; //$NON-NLS-1$

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    fillAllRequestHeaders(request);
    _tracabilite.setIdCorrelationByTel("125667889000877"); //$NON-NLS-1$
    request.setHttpMethod("POST"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    SwapEqt swapEqtRequest = buildValidSwapEqtRequest();

    String jsonRequest = GsonTools.getGson(DateTimeTools.DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(swapEqtRequest, SwapEqt.class);

    request.setPayload(jsonRequest);
    Pair<Retour, String> retour = Whitebox.invokeMethod(_processInstance, "PE0170_BL001_VerifierDonnees", _tracabilite, request); //$NON-NLS-1$

    assertEquals(retourExpected, retour._first);
    assertEquals(expectedSrvId, retour._second);
  }

  /**
   * <b>Scenario:</b> Tests non nominal case.<br>
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_BL002_FormaterReponse_Test_KO_01() throws Exception
  {
    final Commande cmd = __podam.manufacturePojoWithFullData(Commande.class);
    Retour retour001 = RetourFactoryForTU.createNOK(IMegConsts.CAT3, "BL001", "BL001"); //$NON-NLS-1$ //$NON-NLS-2$
    Pair<Retour, ReponseErreur> reponseBL002 = Whitebox.invokeMethod(_processInstance, "PE0170_BL002_FormaterReponse", _tracabilite, cmd, retour001, null, null, null, null, null, null); //$NON-NLS-1$
    assertEquals(retour001.getDiagnostic(), reponseBL002._second.getError());
    assertEquals(retour001.getLibelle(), reponseBL002._second.getErrorDescription());

    //case error BL100
    Retour retour100 = RetourFactoryForTU.createNOK(IMegConsts.CAT3, "BL100", "BL100"); //$NON-NLS-1$ //$NON-NLS-2$
    reponseBL002 = Whitebox.invokeMethod(_processInstance, "PE0170_BL002_FormaterReponse", _tracabilite, cmd, null, retour100, null, null, null, null, null); //$NON-NLS-1$
    assertEquals(retour100.getDiagnostic(), reponseBL002._second.getError());
    assertEquals(retour100.getLibelle(), reponseBL002._second.getErrorDescription());

    //case error BL600
    Retour retour600 = RetourFactoryForTU.createNOK(IMegConsts.CAT3, "600", "600"); //$NON-NLS-1$ //$NON-NLS-2$
    reponseBL002 = Whitebox.invokeMethod(_processInstance, "PE0170_BL002_FormaterReponse", _tracabilite, cmd, null, null, retour600, null, null, null, null); //$NON-NLS-1$
    assertEquals(retour600.getDiagnostic(), reponseBL002._second.getError());
    assertEquals(retour600.getLibelle(), reponseBL002._second.getErrorDescription());

    //case error BL700
    Retour retour700 = RetourFactoryForTU.createNOK(IMegConsts.CAT3, "700", "700"); //$NON-NLS-1$ //$NON-NLS-2$
    reponseBL002 = Whitebox.invokeMethod(_processInstance, "PE0170_BL002_FormaterReponse", _tracabilite, cmd, null, null, null, retour700, null, null, null); //$NON-NLS-1$
    assertEquals(retour700.getDiagnostic(), reponseBL002._second.getError());
    assertEquals(retour700.getLibelle(), reponseBL002._second.getErrorDescription());

    //case error BL104
    Retour retour104 = RetourFactoryForTU.createNOK(IMegConsts.CAT3, "104", "104"); //$NON-NLS-1$ //$NON-NLS-2$
    reponseBL002 = Whitebox.invokeMethod(_processInstance, "PE0170_BL002_FormaterReponse", _tracabilite, cmd, null, null, null, null, retour104, null, null); //$NON-NLS-1$
    assertEquals(retour104.getDiagnostic(), reponseBL002._second.getError());
    assertEquals(retour104.getLibelle(), reponseBL002._second.getErrorDescription());

    //case error BL105, not COMMANDE_EXISTANTE
    Retour retour105 = RetourFactoryForTU.createNOK(IMegConsts.CAT3, "105", "105"); //$NON-NLS-1$ //$NON-NLS-2$
    reponseBL002 = Whitebox.invokeMethod(_processInstance, "PE0170_BL002_FormaterReponse", _tracabilite, cmd, null, null, null, null, null, retour105, null); //$NON-NLS-1$
    assertEquals(retour105.getDiagnostic(), reponseBL002._second.getError());
    assertEquals(retour105.getLibelle(), reponseBL002._second.getErrorDescription());

    //case error BL105 COMMANDE_EXISTANTE
    retour105 = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.COMMANDE_EXISTANTE, "105"); //$NON-NLS-1$

    // CmdLireUnParIdExterne KO
    Retour retourCMDLire = RetourFactoryForTU.createNOK(IMegConsts.CAT3, "error Lire", "error Lire"); //$NON-NLS-1$ //$NON-NLS-2$
    createMockCmdLireUnParIdExterne(retourCMDLire, null);
    PowerMock.replayAll();
    reponseBL002 = Whitebox.invokeMethod(_processInstance, "PE0170_BL002_FormaterReponse", _tracabilite, cmd, null, null, null, null, null, retour105, null); //$NON-NLS-1$
    PowerMock.verify();
    assertEquals(retourCMDLire.getDiagnostic(), reponseBL002._second.getError());
    assertEquals(retourCMDLire.getLibelle(), reponseBL002._second.getErrorDescription());

    beforeTest();
    //case error BL105 COMMANDE_EXISTANTE
    retour105 = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.COMMANDE_EXISTANTE, "105"); //$NON-NLS-1$

    // CmdLireUnParIdExterne OK, cmd INITIE
    cmd.setStatut("INITIE"); //$NON-NLS-1$
    retourCMDLire = RetourFactoryForTU.createOkRetour();
    createMockCmdLireUnParIdExterne(retourCMDLire, cmd);
    PowerMock.replayAll();
    reponseBL002 = Whitebox.invokeMethod(_processInstance, "PE0170_BL002_FormaterReponse", _tracabilite, cmd, null, null, null, null, null, retour105, null); //$NON-NLS-1$
    PowerMock.verify();
    assertEquals(IMegSpiritConsts.REJEU_TECHNIQUE, reponseBL002._second.getError());
    assertEquals("Commande déjà lancée. Si toujours pas de réponse, réessayer plus tard", reponseBL002._second.getErrorDescription()); //$NON-NLS-1$

    beforeTest();
    //case error BL105 COMMANDE_EXISTANTE
    retour105 = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.COMMANDE_EXISTANTE, "105"); //$NON-NLS-1$

    // CmdLireUnParIdExterne OK, cmd REJETE
    cmd.setStatut("REJETE"); //$NON-NLS-1$
    cmd.setCodeErreur("rejete erreur"); //$NON-NLS-1$
    cmd.setLibelleErreur("rejete libele"); //$NON-NLS-1$
    retourCMDLire = RetourFactoryForTU.createOkRetour();
    createMockCmdLireUnParIdExterne(retourCMDLire, cmd);
    PowerMock.replayAll();
    reponseBL002 = Whitebox.invokeMethod(_processInstance, "PE0170_BL002_FormaterReponse", _tracabilite, cmd, null, null, null, null, null, retour105, null); //$NON-NLS-1$
    PowerMock.verify();
    assertEquals(cmd.getCodeErreur(), reponseBL002._second.getError());
    assertEquals(cmd.getLibelleErreur(), reponseBL002._second.getErrorDescription());

    //case error BL200
    Retour retour200 = RetourFactoryForTU.createNOK(IMegConsts.CAT3, "200", "200"); //$NON-NLS-1$ //$NON-NLS-2$
    reponseBL002 = Whitebox.invokeMethod(_processInstance, "PE0170_BL002_FormaterReponse", _tracabilite, cmd, null, null, null, null, null, null, retour200); //$NON-NLS-1$
    assertEquals(retour200.getDiagnostic(), reponseBL002._second.getError());
    assertEquals(retour200.getLibelle(), reponseBL002._second.getErrorDescription());

    //case error, no retours
    reponseBL002 = Whitebox.invokeMethod(_processInstance, "PE0170_BL002_FormaterReponse", _tracabilite, cmd, null, null, null, null, null, null, null); //$NON-NLS-1$
    assertEquals(IMegSpiritConsts.TRAITEMENT_ARRETE, reponseBL002._second.getError());
    assertEquals("Pas d'objet Retour", reponseBL002._second.getErrorDescription()); //$NON-NLS-1$

  }

  /**
   * <b>Scenario:</b> Tests nominal case.<br>
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_BL002_FormaterReponse_Test_OK_01() throws Exception
  {
    final Commande cmd = __podam.manufacturePojoWithFullData(Commande.class);
    Retour retour001 = RetourFactoryForTU.createOkRetour();
    Pair<Retour, ReponseErreur> reponseBL002 = Whitebox.invokeMethod(_processInstance, "PE0170_BL002_FormaterReponse", _tracabilite, cmd, retour001, null, null, null, null, null, null); //$NON-NLS-1$
    assertNull(reponseBL002._second);
  }

  /**
   * <b>Scenario:</b>The retour passed should be returned.<br>
   * <b>Input:</b>Retour NOK and Response null<br>
   * <b>Result:</b> Retour NOK from retourIN.
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_BL005_GererErreurPROSPER_Test_KO_01() throws Throwable
  {
    //Retour passed as an argument
    Retour retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.DONNEE_INVALIDE, null);

    //Retour returned by BL4600
    Retour retourBL4600 = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.DONNEE_INVALIDE, "Libelle erreur BL4600"); //$NON-NLS-1$

    //Setup mock BL4600
    createMockBL4600(retourBL4600);

    //Call PE0170_BL005_GererErreurPROSPER
    PowerMock.replayAll();
    Retour bl005Result = Whitebox.invokeMethod(_processInstance, "PE0170_BL005_GererErreurPROSPER", _tracabilite, retour, null, null, false); //$NON-NLS-1$
    PowerMock.verify();

    //Asserts
    assertEquals(retour, bl005Result);
  }

  /**
   * <b>Scenario:</b>The retourOrigine passed should be returned.<br>
   * <b>Input:</b>Response not null, retourOrigine null and retourSyncLibererOk true<br>
   * <b>Result:</b> Retour null from retourOrigine
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_BL005_GererErreurPROSPER_Test_KO_02() throws Throwable
  {
    //Response passed as an argument
    ReponseErreur response = new ReponseErreur();

    //Retour returned by BL4600
    Retour retourBL4600 = RetourFactory.createNOK(IMegConsts.CAT6, null, "Libelle erreur BL4600"); //$NON-NLS-1$

    //Setup mock BL4600
    createMockBL4600(retourBL4600);

    //Call PE0170_BL005_GererErreurPROSPER
    PowerMock.replayAll();
    Retour bl005Result = Whitebox.invokeMethod(_processInstance, "PE0170_BL005_GererErreurPROSPER", _tracabilite, null, null, response, true); //$NON-NLS-1$
    PowerMock.verify();

    //Asserts
    assertEquals(null, bl005Result);
  }

  /**
   * <b>Scenario:</b>The retourOrigine passed should be returned.<br>
   * <b>Input:</b>Response not null, RetourOrigine CAT-6 and retourSyncLibererOk false<br>
   * <b>Result:</b> Retour CAT-6 from retourOrigine
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_BL005_GererErreurPROSPER_Test_KO_03() throws Throwable
  {
    //RetourOrigine passed as an argument
    Retour retourOrigine = RetourFactory.createNOK(IMegConsts.CAT6, null, null);

    //Response passed as an argument
    ReponseErreur response = new ReponseErreur();

    //Retour returned by BL4600
    Retour retourBL4600 = RetourFactory.createNOK(IMegConsts.CAT6, null, "Libelle erreur BL4600"); //$NON-NLS-1$

    //Setup mock BL4600
    createMockBL4600(retourBL4600);

    //Call PE0170_BL005_GererErreurPROSPER
    PowerMock.replayAll();
    Retour bl005Result = Whitebox.invokeMethod(_processInstance, "PE0170_BL005_GererErreurPROSPER", _tracabilite, null, retourOrigine, response, false); //$NON-NLS-1$
    PowerMock.verify();

    //Asserts
    assertEquals(retourOrigine, bl005Result);
  }

  /**
   * <b>Scenario:</b>The retourOrigine passed should be returned.<br>
   * <b>Input:</b>Response not null, RetourOrigine CAT-10 and retourSyncLibererOk false<br>
   * <b>Result:</b> Retour CAT-10 from retourOrigine
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_BL005_GererErreurPROSPER_Test_KO_04() throws Throwable
  {
    //RetourOrigine passed as an argument
    Retour retourOrigine = RetourFactory.createNOK(IMegConsts.CAT10, null, null);

    //Response passed as an argument
    ReponseErreur response = new ReponseErreur();

    //Retour returned by BL4600
    Retour retourBL4600 = RetourFactory.createNOK(IMegConsts.CAT10, null, "Libelle erreur BL4600"); //$NON-NLS-1$

    //Setup mock BL4600
    createMockBL4600(retourBL4600);

    //Call PE0170_BL005_GererErreurPROSPER
    PowerMock.replayAll();
    Retour bl005Result = Whitebox.invokeMethod(_processInstance, "PE0170_BL005_GererErreurPROSPER", _tracabilite, null, retourOrigine, response, false); //$NON-NLS-1$
    PowerMock.verify();

    //Asserts
    assertEquals(retourOrigine, bl005Result);
  }

  /**
   * <b>Scenario:</b>Nominal test case<br>
   * <b>Input:</b>Response not null, RetourOrigine and retourSyncLibererOk false<br>
   * <b>Result:</b> Retour CAT-10 from retourOrigine
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_BL005_GererErreurPROSPER_Test_OK_05() throws Throwable
  {
    //RetourOrigine passed as an argument
    Retour retourOrigine = RetourFactory.createNOK(IMegConsts.CAT1, null, null);

    //Response passed as an argument
    ReponseErreur response = new ReponseErreur();

    //Call PE0170_BL005_GererErreurPROSPER
    PowerMock.replayAll();
    Retour bl005Result = Whitebox.invokeMethod(_processInstance, "PE0170_BL005_GererErreurPROSPER", _tracabilite, null, retourOrigine, response, false); //$NON-NLS-1$
    PowerMock.verify();

    //Asserts
    assertEquals(RetourFactory.createOkRetour(), bl005Result);
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. The RPG instance returns a NOK CAT-4.<br>
   * <b>Input:</b>The SwapEqt and SrvId attributes.<br>
   * <b>Result:</b> Retour {KO, CAT-4, NO_COMPTE_INCONNU, noCompte=X non connu}
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_BL100_VerifierFonctionnel_Test_KO_01() throws Throwable
  {

    //Retour RPG
    Retour retourRpg = RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, null);

    //Build objects
    SwapEqt swapEqt = buildValidSwapEqtRequest();
    String srvId = "493827"; //$NON-NLS-1$
    PFI pfi = new PFI();

    //Setup mock RPG
    createMockRpgLireUn(retourRpg, pfi);

    //Expected retour from BL100_VerifierFonctionnel
    Retour expectedRetourBL100 = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.NO_COMPTE_INCONNU, MessageFormat.format(MESSAGE_NO_COMPTE_INCONNU, swapEqt.getPortefeuilleServices().getNoCompte()));

    //Call PE0170_BL100_VerifierFonctionnel
    PowerMock.replayAll();
    PE0170_BL100_VerifierFonctionnelReturn bl100Result = Whitebox.invokeMethod(_processInstance, "PE0170_BL100_VerifierFonctionnel", _tracabilite, swapEqt, srvId); //$NON-NLS-1$
    PowerMock.verify();

    //Asserts
    assertEquals(expectedRetourBL100, bl100Result.getRetour());
    assertNull(bl100Result.getTypeSwap());
    assertNull(bl100Result.getIdCommandeRaccoEnCours());
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. The RPG instance returns a NOK CAT-4.<br>
   * <b>Input:</b>The SwapEqt and SrvId attributes.<br>
   * <b>Result:</b> Retour {KO, CAT-4, PORTEFEUILLE_VIDE, rpgLibelle}
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_BL100_VerifierFonctionnel_Test_KO_02() throws Throwable
  {

    //Build objects
    SwapEqt swapEqt = buildValidSwapEqtRequest();
    swapEqt.getPortefeuilleServices().setTypeAcces(TypeAcces.XDSL);
    String srvId = "493827"; //$NON-NLS-1$
    PFI pfi = new PFI();

    //Retour RPG
    String libelleExpected = "rpgLibelle"; //$NON-NLS-1$
    Retour retourRpg = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.PORTEFEUILLE_VIDE, libelleExpected);

    //Expected retour from BL100_VerifierFonctionnel
    Retour expectedRetourBL100 = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.PORTEFEUILLE_VIDE, libelleExpected);

    //Setup mock RPG
    createMockRpgLireUn(retourRpg, pfi);

    //Call PE0170_BL100_VerifierFonctionnel
    PowerMock.replayAll();
    PE0170_BL100_VerifierFonctionnelReturn bl100Result = Whitebox.invokeMethod(_processInstance, "PE0170_BL100_VerifierFonctionnel", _tracabilite, swapEqt, srvId); //$NON-NLS-1$
    PowerMock.verify();

    //Asserts
    assertEquals(expectedRetourBL100, bl100Result.getRetour());
    assertNull(bl100Result.getTypeSwap());
    assertNull(bl100Result.getIdCommandeRaccoEnCours());
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. The OSSFAI_SI012_RecupererIdCmdRaccoEnCours returns a NOK CAT-3.<br>
   * <b>Input:</b>The SwapEqt and SrvId attributes.<br>
   * <b>Result:</b> Retour {KO, CAT-10, TRAITEMENT_ARRETE, SI012 libelle}
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_BL100_VerifierFonctionnel_Test_KO_03() throws Throwable
  {

    //Build objects
    SwapEqt swapEqt = buildValidSwapEqtRequest();
    swapEqt.getPortefeuilleServices().setTypeAcces(TypeAcces.XDSL);
    String srvId = "493827"; //$NON-NLS-1$
    PFI pfi = new PFI();

    //Retour RPG
    Retour retourRpg = RetourFactory.createOkRetour();

    //Retour SI012
    String libelleSI012 = "SI012 Libelle"; //$NON-NLS-1$
    Retour si012Retour = RetourFactory.createNOK(IMegConsts.CAT3, null, libelleSI012);

    //Expected retour from BL100_VerifierFonctionnel
    Retour expectedRetourBL100 = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, libelleSI012);

    //Setup mock RPG
    createMockRpgLireUn(retourRpg, pfi);

    //Setup mock SI012
    createMockSI012(si012Retour, srvId, null, "XDSL"); //$NON-NLS-1$

    //Call PE0170_BL100_VerifierFonctionnel
    PowerMock.replayAll();
    PE0170_BL100_VerifierFonctionnelReturn bl100Result = Whitebox.invokeMethod(_processInstance, "PE0170_BL100_VerifierFonctionnel", _tracabilite, swapEqt, srvId); //$NON-NLS-1$
    PowerMock.verify();

    //Asserts
    assertEquals(expectedRetourBL100, bl100Result.getRetour());
    assertNull(bl100Result.getTypeSwap());
    assertNull(bl100Result.getIdCommandeRaccoEnCours());
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. The OSSFAI_SI012_RecupererIdCmdRaccoEnCours returns a NOK
   * DONNEE_INCONNUE.<br>
   * <b>Input:</b>The SwapEqt and SrvId attributes.<br>
   * <b>Result:</b> Retour {KO, CAT-6, DONNEE_INDISPONIBLE, SI012 libelle}
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_BL100_VerifierFonctionnel_Test_KO_04() throws Throwable
  {

    //Build objects
    SwapEqt swapEqt = buildValidSwapEqtRequest();
    swapEqt.getPortefeuilleServices().setTypeAcces(TypeAcces.FTTLA);
    String srvId = "493827"; //$NON-NLS-1$
    PFI pfi = new PFI();

    //Retour RPG
    Retour retourRpg = RetourFactory.createOkRetour();

    //Retour SI012
    String libelleSI012 = "SI012 Libelle"; //$NON-NLS-1$
    Retour si012Retour = RetourFactory.createNOK(null, IMegConsts.DONNEE_INCONNUE, libelleSI012);

    //Expected retour from BL100_VerifierFonctionnel
    Retour expectedRetourBL100 = RetourFactory.createNOK(IMegConsts.CAT6, IMegSpiritConsts.DONNEE_NON_DISPONIBLE, MessageFormat.format(MESSAGE_PAS_DE_COMMANDE_EN_COURS, srvId));

    //Setup mock RPG
    createMockRpgLireUn(retourRpg, pfi);

    //Setup mock SI012
    createMockSI012(si012Retour, srvId, null, "CABLE"); //$NON-NLS-1$

    //Call PE0170_BL100_VerifierFonctionnel
    PowerMock.replayAll();
    PE0170_BL100_VerifierFonctionnelReturn bl100Result = Whitebox.invokeMethod(_processInstance, "PE0170_BL100_VerifierFonctionnel", _tracabilite, swapEqt, srvId); //$NON-NLS-1$
    PowerMock.verify();

    //Asserts
    assertEquals(expectedRetourBL100, bl100Result.getRetour());
    assertNull(bl100Result.getTypeSwap());
    assertNull(bl100Result.getIdCommandeRaccoEnCours());
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. The OSSFAI_SI012_RecupererIdCmdRaccoEnCours returns a NOK CAT-2
   * COMMANDE_INCONNUE.<br>
   * <b>Input:</b>The SwapEqt and SrvId attributes.<br>
   * <b>Result:</b> Retour {KO, CAT-11, COMMANDE_EXISTANTE, SI012 libelle}
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_BL100_VerifierFonctionnel_Test_KO_05() throws Throwable
  {

    //Build objects
    SwapEqt swapEqt = buildValidSwapEqtRequest();
    String srvId = "493827"; //$NON-NLS-1$
    PFI pfi = new PFI();

    //Retour RPG
    Retour retourRpg = RetourFactory.createOkRetour();

    //Retour SI012
    String libelleSI012 = "SI012 Libelle"; //$NON-NLS-1$
    Retour si012Retour = RetourFactory.createNOK(IMegConsts.CAT2, IMegSpiritConsts.COMMANDE_INCONNUE, libelleSI012);

    //Expected retour from BL100_VerifierFonctionnel
    Retour expectedRetourBL100 = RetourFactory.createNOK(IMegConsts.CAT2, IMegSpiritConsts.COMMANDE_INCONNUE, libelleSI012);

    //Setup mock RPG
    createMockRpgLireUn(retourRpg, pfi);

    //Setup mock SI012
    createMockSI012(si012Retour, srvId, null, "FIBRE"); //$NON-NLS-1$

    //Call PE0170_BL100_VerifierFonctionnel
    PowerMock.replayAll();
    PE0170_BL100_VerifierFonctionnelReturn bl100Result = Whitebox.invokeMethod(_processInstance, "PE0170_BL100_VerifierFonctionnel", _tracabilite, swapEqt, srvId); //$NON-NLS-1$
    PowerMock.verify();

    //Asserts
    assertEquals(expectedRetourBL100, bl100Result.getRetour());
    assertNull(bl100Result.getTypeSwap());
    assertNull(bl100Result.getIdCommandeRaccoEnCours());
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. The filtered commandes list has more than one valid command.<br>
   * <b>Input:</b>The SwapEqt and SrvId attributes.<br>
   * <b>Result:</b> Retour {KO, CAT-4, PLUS_QU_UNE_DONNEE, Plusieurs commandes OSS Services en cours pour un même client
   * FTTH SrvId={0}}
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_BL100_VerifierFonctionnel_Test_KO_06() throws Throwable
  {

    //Build objects
    SwapEqt swapEqt = buildValidSwapEqtRequest();
    String srvId = "493827"; //$NON-NLS-1$
    PFI pfi = new PFI();

    //Retour RPG
    Retour retourRpg = RetourFactory.createOkRetour();

    //Retour SI012
    Retour si012Retour = RetourFactory.createOkRetour();

    //Expected retour from BL100_VerifierFonctionnel
    Retour expectedRetourBL100 = RetourFactory.createNOK(IMegConsts.CAT6, IMegSpiritConsts.DONNEE_NON_DISPONIBLE, MessageFormat.format(MESSAGE_PLUSIEURS_COMMANDES_EN_COURS, srvId));

    //Setup mock RPG
    createMockRpgLireUn(retourRpg, pfi);

    //Setup mock SI012
    createMockSI012(si012Retour, srvId, "ALL_VALID_CMDS", "FIBRE"); //$NON-NLS-1$ //$NON-NLS-2$

    //Call PE0170_BL100_VerifierFonctionnel
    PowerMock.replayAll();
    PE0170_BL100_VerifierFonctionnelReturn bl100Result = Whitebox.invokeMethod(_processInstance, "PE0170_BL100_VerifierFonctionnel", _tracabilite, swapEqt, srvId); //$NON-NLS-1$
    PowerMock.verify();

    //Asserts
    assertEquals(expectedRetourBL100, bl100Result.getRetour());
    assertNull(bl100Result.getTypeSwap());
    assertNull(bl100Result.getIdCommandeRaccoEnCours());
  }

  /**
   * <b>Scenario:</b> Tests nominal case. The filtered commandes list is empty because all commands had invalid
   * types/status.<br>
   * <b>Input:</b>The SwapEqt and SrvId attributes.<br>
   * <b>Result:</b> Retour OK and Type Swap should be 'SAV'. IdCommandeRaccoEnCours should be null.
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_BL100_VerifierFonctionnel_Test_OK_01() throws Throwable
  {

    //Build objects
    SwapEqt swapEqt = buildValidSwapEqtRequest();
    String srvId = "493827"; //$NON-NLS-1$
    PFI pfi = new PFI();

    //Retour RPG
    Retour retourRpg = RetourFactory.createOkRetour();

    //Retour SI012
    Retour si012Retour = RetourFactory.createOkRetour();

    //Expected retour from BL100_VerifierFonctionnel
    Retour expectedRetourBL100 = RetourFactory.createOkRetour();

    //Setup mock RPG
    createMockRpgLireUn(retourRpg, pfi);

    //Setup mock SI012
    createMockSI012(si012Retour, srvId, "ALL_INVALID_CMDS", "FIBRE"); //$NON-NLS-1$ //$NON-NLS-2$

    //Call PE0170_BL100_VerifierFonctionnel
    PowerMock.replayAll();
    PE0170_BL100_VerifierFonctionnelReturn bl100Result = Whitebox.invokeMethod(_processInstance, "PE0170_BL100_VerifierFonctionnel", _tracabilite, swapEqt, srvId); //$NON-NLS-1$
    PowerMock.verify();

    //Asserts
    assertEquals(expectedRetourBL100, bl100Result.getRetour());
    assertEquals(TypeSwap.SAV, bl100Result.getTypeSwap());
    assertNull(bl100Result.getIdCommandeRaccoEnCours());
  }

  /**
   * <b>Scenario:</b> Tests nominal case. The filtered commandes list has only one valid commande.<br>
   * <b>Input:</b>The SwapEqt and SrvId attributes.<br>
   * <b>Result:</b> Retour OK and typeSwap should be 'RACCO'. IdCommandeRaccoEnCours should be filled.
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_BL100_VerifierFonctionnel_Test_OK_02() throws Throwable
  {

    //Build objects
    SwapEqt swapEqt = buildValidSwapEqtRequest();
    String srvId = "493827"; //$NON-NLS-1$
    PFI pfi = new PFI();

    //Retour RPG
    Retour retourRpg = RetourFactory.createOkRetour();

    //Retour SI012
    Retour si012Retour = RetourFactory.createOkRetour();

    //Expected retour from BL100_VerifierFonctionnel
    Retour expectedRetourBL100 = RetourFactory.createOkRetour();

    //Setup mock RPG
    createMockRpgLireUn(retourRpg, pfi);

    //Setup mock SI012 and get its mocked response in order to assert after
    GetOrdersInfoByPortfolioResp result012 = createMockSI012(si012Retour, srvId, "ONE_VALID_CMD", "FIBRE"); //$NON-NLS-1$ //$NON-NLS-2$

    //Call PE0170_BL100_VerifierFonctionnel
    PowerMock.replayAll();
    PE0170_BL100_VerifierFonctionnelReturn bl100Result = Whitebox.invokeMethod(_processInstance, "PE0170_BL100_VerifierFonctionnel", _tracabilite, swapEqt, srvId); //$NON-NLS-1$
    PowerMock.verify();

    //Asserts
    assertEquals(expectedRetourBL100, bl100Result.getRetour());
    assertEquals(TypeSwap.RACCO, bl100Result.getTypeSwap());
    assertEquals(String.valueOf(result012.getCommandsByPortfolios().getCommands().getCommand().get(0).getCommandId()), bl100Result.getIdCommandeRaccoEnCours());
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. Check entry parameters.<br>
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_BL101_ControlerSN_Test_KO_01() throws Exception
  {

    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, Messages.getString("PE0170.BL001.StiError")); //$NON-NLS-1$
    Retour reponseBL101 = Whitebox.invokeMethod(_processInstance, "PE0170_BL101_ControlerSN", _tracabilite, null, null); //$NON-NLS-1$
    assertEquals(retourExpected, reponseBL101);

    reponseBL101 = Whitebox.invokeMethod(_processInstance, "PE0170_BL101_ControlerSN", _tracabilite, "sNumeroSerie", null); //$NON-NLS-1$ //$NON-NLS-2$
    assertEquals(retourExpected, reponseBL101);

    reponseBL101 = Whitebox.invokeMethod(_processInstance, "PE0170_BL101_ControlerSN", _tracabilite, null, "sTypeEquipement"); //$NON-NLS-1$ //$NON-NLS-2$
    assertEquals(retourExpected, reponseBL101);

  }

  /**
   * <b>Scenario:</b> Tests non nominal case. Check coherence between equipment type and NumeroSerie.<br>
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_BL101_ControlerSN_Test_KO_02() throws Exception
  {
    //Modem case
    String equipement = "MODEM"; //$NON-NLS-1$
    String numeroSerie = "222"; //$NON-NLS-1$

    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.SN_INVALIDE, MessageFormat.format(MESSAGE_BAD_FORMAT_ERROR, numeroSerie, equipement));
    Retour reponseBL101 = Whitebox.invokeMethod(_processInstance, "PE0170_BL101_ControlerSN", _tracabilite, numeroSerie, equipement); //$NON-NLS-1$
    assertEquals(retourExpected, reponseBL101);

    numeroSerie = "144"; //$NON-NLS-1$
    retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.SN_INVALIDE, MessageFormat.format(MESSAGE_BAD_FORMAT_ERROR, numeroSerie, equipement));
    reponseBL101 = Whitebox.invokeMethod(_processInstance, "PE0170_BL101_ControlerSN", _tracabilite, numeroSerie, equipement); //$NON-NLS-1$
    assertEquals(retourExpected, reponseBL101);

    numeroSerie = "184"; //$NON-NLS-1$
    retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.SN_INVALIDE, MessageFormat.format(MESSAGE_BAD_FORMAT_ERROR, numeroSerie, equipement));
    reponseBL101 = Whitebox.invokeMethod(_processInstance, "PE0170_BL101_ControlerSN", _tracabilite, numeroSerie, equipement); //$NON-NLS-1$
    assertEquals(retourExpected, reponseBL101);

    //case DECODEUR_TV
    equipement = "DECODEUR_TV"; //$NON-NLS-1$
    numeroSerie = "111"; //$NON-NLS-1$
    retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.SN_INVALIDE, MessageFormat.format(MESSAGE_BAD_FORMAT_ERROR, numeroSerie, equipement));
    reponseBL101 = Whitebox.invokeMethod(_processInstance, "PE0170_BL101_ControlerSN", _tracabilite, numeroSerie, equipement); //$NON-NLS-1$
    assertEquals(retourExpected, reponseBL101);

    //case BRANCHEMENT_OPTIQUE
    equipement = "BRANCHEMENT_OPTIQUE"; //$NON-NLS-1$
    numeroSerie = "111"; //$NON-NLS-1$
    retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.SN_INVALIDE, MessageFormat.format(MESSAGE_BAD_FORMAT_ERROR, numeroSerie, equipement));
    reponseBL101 = Whitebox.invokeMethod(_processInstance, "PE0170_BL101_ControlerSN", _tracabilite, numeroSerie, equipement); //$NON-NLS-1$
    assertEquals(retourExpected, reponseBL101);
  }

  /**
   * <b>Scenario:</b> Test nominal case.<br>
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_BL101_ControlerSN_Test_OK() throws Exception
  {
    //Modem case
    String equipement = "MODEM"; //$NON-NLS-1$
    String numeroSerie = "111"; //$NON-NLS-1$

    Retour retourExpected = RetourFactoryForTU.createOkRetour();
    Retour reponseBL101 = Whitebox.invokeMethod(_processInstance, "PE0170_BL101_ControlerSN", _tracabilite, numeroSerie, equipement); //$NON-NLS-1$
    assertEquals(retourExpected, reponseBL101);

    //case DECODEUR_TV
    equipement = "DECODEUR_TV"; //$NON-NLS-1$
    numeroSerie = "2121212"; //$NON-NLS-1$
    reponseBL101 = Whitebox.invokeMethod(_processInstance, "PE0170_BL101_ControlerSN", _tracabilite, numeroSerie, equipement); //$NON-NLS-1$
    assertEquals(retourExpected, reponseBL101);

    //case BRANCHEMENT_OPTIQUE
    equipement = "BRANCHEMENT_OPTIQUE"; //$NON-NLS-1$
    numeroSerie = "14444"; //$NON-NLS-1$
    reponseBL101 = Whitebox.invokeMethod(_processInstance, "PE0170_BL101_ControlerSN", _tracabilite, numeroSerie, equipement); //$NON-NLS-1$
    assertEquals(retourExpected, reponseBL101);

    numeroSerie = "18444"; //$NON-NLS-1$
    reponseBL101 = Whitebox.invokeMethod(_processInstance, "PE0170_BL101_ControlerSN", _tracabilite, numeroSerie, equipement); //$NON-NLS-1$
    assertEquals(retourExpected, reponseBL101);
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. Check entry parameters.<br>
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_BL102_ControlerEquipement_Test_KO_01() throws Exception
  {

    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, Messages.getString("PE0170.BL001.StiError")); //$NON-NLS-1$
    Retour reponseBL102 = Whitebox.invokeMethod(_processInstance, "PE0170_BL102_ControlerEquipement", _tracabilite, null, null, null, null); //$NON-NLS-1$
    assertEquals(retourExpected, reponseBL102);

    reponseBL102 = Whitebox.invokeMethod(_processInstance, "PE0170_BL102_ControlerEquipement", _tracabilite, "typeAcces_p", null, null, null); //$NON-NLS-1$ //$NON-NLS-2$
    assertEquals(retourExpected, reponseBL102);

    reponseBL102 = Whitebox.invokeMethod(_processInstance, "PE0170_BL102_ControlerEquipement", _tracabilite, null, "typeEquipement_p", null, null); //$NON-NLS-1$ //$NON-NLS-2$
    assertEquals(retourExpected, reponseBL102);

    reponseBL102 = Whitebox.invokeMethod(_processInstance, "PE0170_BL102_ControlerEquipement", _tracabilite, null, null, "fabriquant_p", null); //$NON-NLS-1$ //$NON-NLS-2$
    assertEquals(retourExpected, reponseBL102);

    reponseBL102 = Whitebox.invokeMethod(_processInstance, "PE0170_BL102_ControlerEquipement", _tracabilite, null, null, null, "modele_p"); //$NON-NLS-1$ //$NON-NLS-2$
    assertEquals(retourExpected, reponseBL102);
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. Check incoherences.<br>
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_BL102_ControlerEquipement_Test_KO_02() throws Exception
  {

    // Setup process parameters
    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(true, true, true, true, 120);

    // Process Manager Mock
    ProcessManager.getInstance().getProcessParams().clear();
    ProcessManager.getInstance().getProcessParams().putAll(processParams);

    PowerMock.replayAll();

    _processInstance = new PE0170_SwapEquipement();
    _processInstance.initializeContext();

    // Call methode
    Whitebox.invokeMethod(_processInstance, "loadProcessParameters"); //$NON-NLS-1$

    String typeAcces_p = "FTTH"; //$NON-NLS-1$
    String typeEquipement_p = "MODEM"; //$NON-NLS-1$
    String fabriquant_p = "TECOM"; //$NON-NLS-1$
    String modele_p = "###"; //$NON-NLS-1$

    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.EQUIPEMENT_INVALIDE, MessageFormat.format(MESSAGE_INVALID_EQUIP_ERROR, typeAcces_p, typeEquipement_p, fabriquant_p, modele_p));
    Retour reponseBL102 = Whitebox.invokeMethod(_processInstance, "PE0170_BL102_ControlerEquipement", _tracabilite, typeAcces_p, typeEquipement_p, fabriquant_p, modele_p); //$NON-NLS-1$
    assertEquals(retourExpected, reponseBL102);

    fabriquant_p = "###"; //$NON-NLS-1$
    retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.EQUIPEMENT_INVALIDE, MessageFormat.format(MESSAGE_INVALID_EQUIP_ERROR, typeAcces_p, typeEquipement_p, fabriquant_p, modele_p));
    reponseBL102 = Whitebox.invokeMethod(_processInstance, "PE0170_BL102_ControlerEquipement", _tracabilite, typeAcces_p, typeEquipement_p, fabriquant_p, modele_p); //$NON-NLS-1$
    assertEquals(retourExpected, reponseBL102);

    typeEquipement_p = "###"; //$NON-NLS-1$
    retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.EQUIPEMENT_INVALIDE, MessageFormat.format(MESSAGE_INVALID_EQUIP_ERROR, typeAcces_p, typeEquipement_p, fabriquant_p, modele_p));
    reponseBL102 = Whitebox.invokeMethod(_processInstance, "PE0170_BL102_ControlerEquipement", _tracabilite, typeAcces_p, typeEquipement_p, fabriquant_p, modele_p); //$NON-NLS-1$
    assertEquals(retourExpected, reponseBL102);

    typeAcces_p = "###"; //$NON-NLS-1$
    retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.EQUIPEMENT_INVALIDE, MessageFormat.format(MESSAGE_INVALID_EQUIP_ERROR, typeAcces_p, typeEquipement_p, fabriquant_p, modele_p));
    reponseBL102 = Whitebox.invokeMethod(_processInstance, "PE0170_BL102_ControlerEquipement", _tracabilite, typeAcces_p, typeEquipement_p, fabriquant_p, modele_p); //$NON-NLS-1$
    assertEquals(retourExpected, reponseBL102);

  }

  /**
   * <b>Scenario:</b> Test nominal case.<br>
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_BL102_ControlerEquipement_Test_OK_01() throws Exception
  {

    // Setup process parameters
    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(true, true, true, true, 120);

    // Process Manager Mock
    ProcessManager.getInstance().getProcessParams().clear();
    ProcessManager.getInstance().getProcessParams().putAll(processParams);

    PowerMock.replayAll();

    _processInstance = new PE0170_SwapEquipement();
    _processInstance.initializeContext();

    // Call methode
    Whitebox.invokeMethod(_processInstance, "loadProcessParameters"); //$NON-NLS-1$

    String typeAcces_p = "FTTH"; //$NON-NLS-1$
    String typeEquipement_p = "MODEM"; //$NON-NLS-1$
    String fabriquant_p = "Sagem"; //$NON-NLS-1$
    String modele_p = "3784f"; //$NON-NLS-1$

    Retour retourExpected = RetourFactoryForTU.createOkRetour();
    Retour reponseBL102 = Whitebox.invokeMethod(_processInstance, "PE0170_BL102_ControlerEquipement", _tracabilite, typeAcces_p, typeEquipement_p, fabriquant_p, modele_p); //$NON-NLS-1$
    assertEquals(retourExpected, reponseBL102);

    fabriquant_p = "UBEE"; //$NON-NLS-1$
    modele_p = "TVW620.I"; //$NON-NLS-1$
    reponseBL102 = Whitebox.invokeMethod(_processInstance, "PE0170_BL102_ControlerEquipement", _tracabilite, typeAcces_p, typeEquipement_p, fabriquant_p, modele_p); //$NON-NLS-1$
    assertEquals(retourExpected, reponseBL102);

    typeEquipement_p = "DECODEUR_TV"; //$NON-NLS-1$
    fabriquant_p = "ARCADYAN"; //$NON-NLS-1$
    modele_p = "HMB4213H"; //$NON-NLS-1$
    reponseBL102 = Whitebox.invokeMethod(_processInstance, "PE0170_BL102_ControlerEquipement", _tracabilite, typeAcces_p, typeEquipement_p, fabriquant_p, modele_p); //$NON-NLS-1$
    assertEquals(retourExpected, reponseBL102);

    typeEquipement_p = "BRANCHEMENT_OPTIQUE"; //$NON-NLS-1$
    fabriquant_p = "TECOM"; //$NON-NLS-1$
    modele_p = "GP6110_BYT"; //$NON-NLS-1$
    reponseBL102 = Whitebox.invokeMethod(_processInstance, "PE0170_BL102_ControlerEquipement", _tracabilite, typeAcces_p, typeEquipement_p, fabriquant_p, modele_p); //$NON-NLS-1$
    assertEquals(retourExpected, reponseBL102);

  }

  /**
   * <b>Scenario:</b> Tests non nominal case. Check entry parameters.<br>
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_BL103_CalculerNoCompteCourt_Test_KO_01() throws Exception
  {
    String noCompte_p = null;
    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_STI_ERROR, noCompte_p));
    Pair<Retour, String> reponseBL103 = Whitebox.invokeMethod(_processInstance, "PE0170_BL103_CalculerNoCompteCourt", _tracabilite, noCompte_p); //$NON-NLS-1$
    assertEquals(retourExpected, reponseBL103._first);

    // size not 12
    noCompte_p = "123456789"; //$NON-NLS-1$
    reponseBL103 = Whitebox.invokeMethod(_processInstance, "PE0170_BL103_CalculerNoCompteCourt", _tracabilite, noCompte_p); //$NON-NLS-1$
    retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_STI_ERROR, noCompte_p));
    assertEquals(retourExpected, reponseBL103._first);
  }

  /**
   * <b>Scenario:</b> Test nominal case.<br>
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_BL103_CalculerNoCompteCourt_Test_OK_01() throws Exception
  {
    String noCompte_p = "610012345678"; //$NON-NLS-1$
    String expectedNoCompteCourte = "12345678"; //$NON-NLS-1$
    Retour retourExpected = RetourFactoryForTU.createOkRetour();
    Pair<Retour, String> reponseBL103 = Whitebox.invokeMethod(_processInstance, "PE0170_BL103_CalculerNoCompteCourt", _tracabilite, noCompte_p); //$NON-NLS-1$
    assertEquals(retourExpected, reponseBL103._first);
    assertEquals(expectedNoCompteCourte, reponseBL103._second);

    noCompte_p = "610001234567"; //$NON-NLS-1$
    expectedNoCompteCourte = "1234567"; //$NON-NLS-1$
    reponseBL103 = Whitebox.invokeMethod(_processInstance, "PE0170_BL103_CalculerNoCompteCourt", _tracabilite, noCompte_p); //$NON-NLS-1$
    assertEquals(retourExpected, reponseBL103._first);
    assertEquals(expectedNoCompteCourte, reponseBL103._second);
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. Check entry parameters.<br>
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_BL104_PreparerCmd_Test_KO_01() throws Exception
  {

    String dCmdRaccoEnCours = "232323232323"; //$NON-NLS-1$
    SwapEqt swapEqt = buildValidSwapEqtRequest();
    final PE0170_Eqt eqtProvisionneALiberer_p = __podam.manufacturePojoWithFullData(PE0170_Eqt.class);

    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, Messages.getString("PE0170.BL001.StiError")); //$NON-NLS-1$
    Pair<Retour, Commande> bl104Result = Whitebox.invokeMethod(_processInstance, "PE0170_BL104_PreparerCmd", _tracabilite, null, null, null); //$NON-NLS-1$
    assertEquals(retourExpected, bl104Result._first);

    bl104Result = Whitebox.invokeMethod(_processInstance, "PE0170_BL104_PreparerCmd", _tracabilite, swapEqt, null, null); //$NON-NLS-1$
    assertEquals(retourExpected, bl104Result._first);

    bl104Result = Whitebox.invokeMethod(_processInstance, "PE0170_BL104_PreparerCmd", _tracabilite, swapEqt, dCmdRaccoEnCours, null); //$NON-NLS-1$
    assertEquals(retourExpected, bl104Result._first);

    bl104Result = Whitebox.invokeMethod(_processInstance, "PE0170_BL104_PreparerCmd", _tracabilite, null, dCmdRaccoEnCours, eqtProvisionneALiberer_p); //$NON-NLS-1$
    assertEquals(retourExpected, bl104Result._first);
  }

  /**
   * <b>Scenario:</b> Test non nominal case, call to bl800 fails<br>
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_BL104_PreparerCmd_Test_KO_02() throws Exception
  {
    String dCmdRaccoEnCours = "232323232323"; //$NON-NLS-1$
    SwapEqt swapEqt = buildValidSwapEqtRequest();
    final PE0170_Eqt eqtProvisionneALiberer_p = __podam.manufacturePojoWithFullData(PE0170_Eqt.class);
    eqtProvisionneALiberer_p.setIdentifiantTechnique("some id"); //$NON-NLS-1$

    /* Mock BL800*/
    PowerMock.expectNew(BL800_ObtenirSequenceBuilder.class).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.code(EasyMock.eq(UniqueIdConstant.ID_CMD_GP))).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.build()).andReturn(_bl800Mock);
    String sequence = UUID.randomUUID().toString();
    EasyMock.expect(_bl800Mock.execute(EasyMock.anyObject(PE0170_SwapEquipement.class))).andReturn(sequence);
    Retour bl800Retour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.CODE_SEQUENCE_INVALIDE, "", null); //$NON-NLS-1$
    EasyMock.expect(_bl800Mock.getRetour()).andReturn(bl800Retour).anyTimes();

    PowerMock.replayAll();
    _processInstance.initializeContext();
    _processInstance.getProcessContext().setXClientOperateur("Client operateur"); //$NON-NLS-1$
    Pair<Retour, Commande> bl104Result = Whitebox.invokeMethod(_processInstance, "PE0170_BL104_PreparerCmd", _tracabilite, swapEqt, dCmdRaccoEnCours, eqtProvisionneALiberer_p); //$NON-NLS-1$

    PowerMock.verifyAll();

    //Asserts
    assertEquals(bl800Retour, bl104Result._first);
  }

  /**
   * <b>Scenario:</b> Test nominal case.<br>
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_BL104_PreparerCmd_Test_OK_01() throws Exception
  {
    String cmdId = "11111"; //$NON-NLS-1$
    String dCmdRaccoEnCours = "232323232323"; //$NON-NLS-1$
    SwapEqt swapEqt = buildValidSwapEqtRequest();
    final PE0170_Eqt eqtProvisionneALiberer_p = __podam.manufacturePojoWithFullData(PE0170_Eqt.class);
    eqtProvisionneALiberer_p.setIdentifiantTechnique("some id"); //$NON-NLS-1$

    PowerMock.expectNew(BL800_ObtenirSequenceBuilder.class).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.code(UniqueIdConstant.ID_CMD_GP)).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.build()).andReturn(_bl800Mock);
    EasyMock.expect(_bl800Mock.execute(EasyMock.anyObject())).andReturn(cmdId);
    EasyMock.expect(_bl800Mock.getRetour()).andReturn(RetourFactoryForTU.createOkRetour());
    Retour retourExpected = RetourFactoryForTU.createOkRetour();

    PowerMock.replayAll();
    _processInstance.initializeContext();
    _processInstance.getProcessContext().setXClientOperateur("Client operateur"); //$NON-NLS-1$
    Pair<Retour, Commande> bl104Result = Whitebox.invokeMethod(_processInstance, "PE0170_BL104_PreparerCmd", _tracabilite, swapEqt, dCmdRaccoEnCours, eqtProvisionneALiberer_p); //$NON-NLS-1$
    PowerMock.verify();

    //Asserts
    assertEquals(retourExpected, bl104Result._first);
    Commande cmd = bl104Result._second;
    Assert.assertNotNull(cmd.getIdCmd());
    assertEquals(swapEqt.getInfosService().getIdCommande(), cmd.getIdExterne());
    assertEquals("SWAP_EQT", cmd.getNatureCommande()); //$NON-NLS-1$
    assertEquals("INITIE", cmd.getStatut()); //$NON-NLS-1$
    SwapEqt SwapEqtOut = GsonTools.getIso8601Ms().fromJson(cmd.getDonneesBrut(), SwapEqt.class);
    Assert.assertNotNull(SwapEqtOut);
    assertEquals("Client operateur", cmd.getClientOperateur()); //$NON-NLS-1$
    assertEquals(swapEqt.getPortefeuilleServices().getNoCompte(), cmd.getNoCompte());
    Map<String, String> donneesSpecifiques = GsonTools.getIso8601Ms().fromJson(cmd.getDonneesSpecifiques(), Map.class);
    String idCommandeOss = donneesSpecifiques.get(ID_CMD_RACCO_EN_COURS);
    String identifiantTechniqueEqtALiberer = donneesSpecifiques.get(IDENTIFIANT_TECHNIQUE_EQT_A_LIBERER);
    assertEquals(dCmdRaccoEnCours, idCommandeOss);
    assertEquals(eqtProvisionneALiberer_p.getIdentifiantTechnique(), identifiantTechniqueEqtALiberer);
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. Call to CMD fails<br>
   * <b>Input:</b> command<br>
   * <b>Result:</b> Retour
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_BL105_CreerCommande_Test_KO_01() throws Exception
  {

    EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdProxyMock);
    ConnectorResponse<Retour, Nothing> expectedReturn = new ConnectorResponse<>(RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, StringConstants.EMPTY_STRING, null), null);
    EasyMock.expect(_cmdProxyMock.commandeCreer(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(CreateCommandeRequest.class))).andReturn(expectedReturn);
    final Commande request = __podam.manufacturePojoWithFullData(Commande.class);

    PowerMock.replayAll();
    Pair<Retour, Nothing> retour = Whitebox.invokeMethod(_processInstance, "PE0170_BL105_CreerCommande", _tracabilite, request); //$NON-NLS-1$
    PowerMock.verify();

    assertEquals(expectedReturn._first, retour._first);
  }

  /**
   * <b>Scenario:</b> Tests nominal case.<br>
   * <b>Input:</b> command<br>
   * <b>Result:</b> Retour
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_BL105_CreerCommande_Test_OK_01() throws Exception
  {

    EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdProxyMock);

    ConnectorResponse<Retour, Nothing> expectedRetourn = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), null);
    EasyMock.expect(_cmdProxyMock.commandeCreer(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(CreateCommandeRequest.class))).andReturn(expectedRetourn);
    final Commande request = __podam.manufacturePojoWithFullData(Commande.class);

    PowerMock.replayAll();
    Pair<Retour, Nothing> retour = Whitebox.invokeMethod(_processInstance, "PE0170_BL105_CreerCommande", _tracabilite, request); //$NON-NLS-1$
    PowerMock.verify();

    assertEquals(expectedRetourn._first, retour._first);
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. Fail call to FAI15 and CMD modifier Statut<br>
   * <b>Input:</b><br>
   * <b>Result:</b> Retour OK, retourSyncLibererOk false
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_BL200_LibererEquipement_Test_KO_01() throws Throwable
  {

    String idCmdRaccoEnCours_p = "11111"; //$NON-NLS-1$
    SwapEqt swapEqt = buildValidSwapEqtRequest();
    final PE0170_Eqt eqtProvisionneALiberer_p = __podam.manufacturePojoWithFullData(PE0170_Eqt.class);
    eqtProvisionneALiberer_p.setIdentifiantTechnique("some id"); //$NON-NLS-1$
    eqtProvisionneALiberer_p.setFabriquant("TECOM"); //$NON-NLS-1$

    //Build objects
    Commande commande = __podam.manufacturePojoWithFullData(Commande.class);
    String idCmd = "12345"; //$NON-NLS-1$
    commande.setIdCmd(idCmd);
    LocalDateTime dateCommande_p = LocalDateTime.now();
    commande.setDateCommande(dateCommande_p);
    Map<String, String> donneesSpecifiques = new HashMap<>();
    donneesSpecifiques.put(ID_CMD_RACCO_EN_COURS, idCmdRaccoEnCours_p);
    donneesSpecifiques.put(IDENTIFIANT_TECHNIQUE_EQT_A_LIBERER, eqtProvisionneALiberer_p.getIdentifiantTechnique());
    commande.setDonneesSpecifiques(GsonTools.getIso8601Ms().toJson(donneesSpecifiques));

    //Setup mock SI015 KO
    Retour retourSI15 = RetourFactoryForTU.createNOK(IMegConsts.CAT3, null, null);
    createMockSI015LibererEquipement(retourSI15);

    //Setup mock CMD KO
    Retour retourCMD = RetourFactoryForTU.createNOK(IMegConsts.CAT3, null, null);
    createMockCmdCommandeModifierStatut(retourCMD, commande.getIdCmd(), Statut.REJETE.name());

    /* Mock BL4600*/
    PowerMock.expectNew(BL4600_CreerErreurSpiritBuilder.class).andReturn(_bl4600BuilderMock);
    EasyMock.expect(_bl4600BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl4600BuilderMock);
    EasyMock.expect(_bl4600BuilderMock.retour(EasyMock.anyObject(Retour.class))).andReturn(_bl4600BuilderMock);
    EasyMock.expect(_bl4600BuilderMock.build()).andReturn(_bl4600Mock);
    Retour bl4600Retour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.COMMANDE_TRAITEE_NOK, "bl4600Retour", null); //$NON-NLS-1$
    EasyMock.expect(_bl4600Mock.execute(EasyMock.anyObject(PE0170_SwapEquipement.class))).andReturn(null);
    EasyMock.expect(_bl4600Mock.getRetour()).andReturn(bl4600Retour);

    PowerMock.replayAll();
    //Call PE0170_BL200
    Retour bl200Result = Whitebox.invokeMethod(_processInstance, "PE0170_BL200_LibererEquipement", _tracabilite, swapEqt, eqtProvisionneALiberer_p, commande); //$NON-NLS-1$
    PowerMock.verify();

    //Asserts
    assertEquals(bl4600Retour, bl200Result);
    //TODO
    //assertEquals(false, bl200Result._second);

    beforeTest();
    //Case FAI15 fails, cmdModifierStatut OK, and final return should be retourSI15

    //Setup mock SI015 KO
    retourSI15 = RetourFactoryForTU.createNOK(IMegConsts.CAT4, null, null);
    createMockSI015LibererEquipement(retourSI15);

    //Setup mock CMD KO
    retourCMD = RetourFactoryForTU.createOkRetour();
    createMockCmdCommandeModifierStatut(retourCMD, commande.getIdCmd(), Statut.REJETE.name());

    PowerMock.replayAll();
    //Call PE0170_BL200
    bl200Result = Whitebox.invokeMethod(_processInstance, "PE0170_BL200_LibererEquipement", _tracabilite, swapEqt, eqtProvisionneALiberer_p, commande); //$NON-NLS-1$
    PowerMock.verify();

    //Asserts
    assertEquals(retourSI15, bl200Result);
    //TODO
    //assertEquals(false, bl200Result._second);

    beforeTest();
    //Case FAI15 fails, cmdModifierStatut OK, and final return should be CAT10

    //Setup mock SI015 KO
    retourSI15 = RetourFactoryForTU.createNOK(IMegConsts.CAT3, null, null);
    createMockSI015LibererEquipement(retourSI15);

    //Setup mock CMD OK
    retourCMD = RetourFactoryForTU.createOkRetour();
    createMockCmdCommandeModifierStatut(retourCMD, commande.getIdCmd(), Statut.REJETE.name());

    PowerMock.replayAll();
    //Call PE0170_BL200
    bl200Result = Whitebox.invokeMethod(_processInstance, "PE0170_BL200_LibererEquipement", _tracabilite, swapEqt, eqtProvisionneALiberer_p, commande); //$NON-NLS-1$
    PowerMock.verify();

    //Asserts
    Retour retourCAT10 = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, retourSI15.getLibelle());
    assertEquals(retourCAT10, bl200Result);
    //TODO
    //assertEquals(false, bl200Result._second);

    beforeTest();
    //Case FAI15 OK, cmdModifierStatut KO

    //Setup mock SI015 OK
    retourSI15 = RetourFactoryForTU.createOkRetour();
    createMockSI015LibererEquipement(retourSI15);

    //Setup mock CMD KO
    retourCMD = RetourFactoryForTU.createNOK(IMegConsts.CAT3, null, null);
    createMockCmdCommandeModifierStatut(retourCMD, commande.getIdCmd(), Statut.ACQUITTE.name());

    PowerMock.replayAll();
    //Call PE0170_BL200
    bl200Result = Whitebox.invokeMethod(_processInstance, "PE0170_BL200_LibererEquipement", _tracabilite, swapEqt, eqtProvisionneALiberer_p, commande); //$NON-NLS-1$
    PowerMock.verify();

    //Asserts
    assertEquals(retourCMD, bl200Result);
    //TODO
    //assertEquals(true, bl200Result._second);

  }

  /**
   * <b>Scenario:</b> Tests nominal case.<br>
   * <b>Input:</b><br>
   * <b>Result:</b> Retour OK, retourSyncLibererOk true
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_BL200_LibererEquipement_Test_OK_01() throws Throwable
  {

    String idCmdRaccoEnCours_p = "11111"; //$NON-NLS-1$
    SwapEqt swapEqt = buildValidSwapEqtRequest();
    final PE0170_Eqt eqtProvisionneALiberer_p = __podam.manufacturePojoWithFullData(PE0170_Eqt.class);
    eqtProvisionneALiberer_p.setIdentifiantTechnique("some id"); //$NON-NLS-1$
    eqtProvisionneALiberer_p.setFabriquant("TECOM"); //$NON-NLS-1$

    //Build objects
    Commande commande = __podam.manufacturePojoWithFullData(Commande.class);
    String idCmd = "12345"; //$NON-NLS-1$
    commande.setIdCmd(idCmd);
    LocalDateTime dateCommande_p = LocalDateTime.now();
    commande.setDateCommande(dateCommande_p);
    Map<String, String> donneesSpecifiques = new HashMap<>();
    donneesSpecifiques.put(ID_CMD_RACCO_EN_COURS, idCmdRaccoEnCours_p);
    donneesSpecifiques.put(IDENTIFIANT_TECHNIQUE_EQT_A_LIBERER, eqtProvisionneALiberer_p.getIdentifiantTechnique());
    commande.setDonneesSpecifiques(GsonTools.getIso8601Ms().toJson(donneesSpecifiques));
    Retour retour = RetourFactoryForTU.createOkRetour();

    //Setup mock CMD
    createMockCmdCommandeModifierStatut(retour, commande.getIdCmd(), Statut.ACQUITTE.name());

    //Setup mock SI015
    createMockSI015LibererEquipement(retour);

    PowerMock.replayAll();
    //Call PE0170_BL200
    Retour bl200Result = Whitebox.invokeMethod(_processInstance, "PE0170_BL200_LibererEquipement", _tracabilite, swapEqt, eqtProvisionneALiberer_p, commande); //$NON-NLS-1$
    PowerMock.verify();

    //Asserts
    assertEquals(retour, bl200Result);
    //TODO
    //assertEquals(true, bl200Result._second);
    assertEquals(Statut.ACQUITTE.name(), commande.getStatut());

    beforeTest();
    //Case modem
    swapEqt.getInfosService().setTypeEquipement(TypeEquipement.MODEM);
    eqtProvisionneALiberer_p.setFabriquant("SAGEM"); //$NON-NLS-1$

    //Setup mock CMD
    createMockCmdCommandeModifierStatut(retour, commande.getIdCmd(), Statut.ACQUITTE.name());

    //Setup mock SI015
    createMockSI015LibererEquipement(retour);

    PowerMock.replayAll();
    //Call PE0170_BL200
    bl200Result = Whitebox.invokeMethod(_processInstance, "PE0170_BL200_LibererEquipement", _tracabilite, swapEqt, eqtProvisionneALiberer_p, commande); //$NON-NLS-1$
    PowerMock.verify();

    //Asserts
    assertEquals(retour, bl200Result);
    //TODO
    //assertEquals(true, bl200Result._second);
    assertEquals(Statut.ACQUITTE.name(), commande.getStatut());

    beforeTest();
    //Case modem
    swapEqt.getInfosService().setTypeEquipement(TypeEquipement.DECODEUR_TV);
    eqtProvisionneALiberer_p.setFabriquant("THOMSON"); //$NON-NLS-1$

    //Setup mock CMD
    createMockCmdCommandeModifierStatut(retour, commande.getIdCmd(), Statut.ACQUITTE.name());

    //Setup mock SI015
    createMockSI015LibererEquipement(retour);

    PowerMock.replayAll();
    //Call PE0170_BL200
    bl200Result = Whitebox.invokeMethod(_processInstance, "PE0170_BL200_LibererEquipement", _tracabilite, swapEqt, eqtProvisionneALiberer_p, commande); //$NON-NLS-1$
    PowerMock.verify();

    //Asserts
    assertEquals(retour, bl200Result);
    //TODO
    //assertEquals(true, bl200Result._second);
    assertEquals(Statut.ACQUITTE.name(), commande.getStatut());

  }

  /**
   * <b>Scenario:</b> Tests non nominal case. CMD Proxy returns NOK.<br>
   * <b>Input:</b>The commande swap identifier.<br>
   * <b>Result:</b> Retour KO and flag should be null.
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_BL300_VerifierAvancement_Test_KO_01() throws Throwable
  {
    //Build objects
    Commande commande = new Commande();
    String idCmd = "12345"; //$NON-NLS-1$
    commande.setIdCmd(idCmd);

    //Retour CMD Proxy
    Retour retourCmd = RetourFactory.createNOK(IMegConsts.CAT4, null, null);

    //Setup mock CMD
    createMockCmdLireUn(retourCmd, commande);

    //Call PE0170_BL300_VerifierAvancement
    PowerMock.replayAll();
    Pair<Retour, Boolean> bl300Result = Whitebox.invokeMethod(_processInstance, "PE0170_BL300_VerifierAvancement", _tracabilite, idCmd); //$NON-NLS-1$
    PowerMock.verify();

    //Asserts
    assertEquals(retourCmd, bl300Result._first);
    assertNull(bl300Result._second);
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. CMD Proxy returns OK but activity SI016 returns NOK CAT-3.<br>
   * <b>Input:</b>The commande swap identifier.<br>
   * <b>Result:</b> Retour KO CAT-10 and flag should be null.
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_BL300_VerifierAvancement_Test_KO_02() throws Throwable
  {

    //Build objects
    Commande commande = new Commande();
    String idCmd = "1c27c3ba-bd3a-462e-8e9e-cba6180f614d"; //$NON-NLS-1$
    commande.setIdCmd(idCmd);
    Boolean flagVerrouDecLibEqt = false;

    String idCmdOss = "12345"; //$NON-NLS-1$
    Map<String, String> donneesSpecifiques = new HashMap<>();
    donneesSpecifiques.put(ID_CMD_RACCO_EN_COURS, idCmdOss);
    commande.setDonneesSpecifiques(GsonTools.getIso8601Ms().toJson(donneesSpecifiques));

    //Retour CMD Proxy
    Retour retourCmd = RetourFactory.createOkRetour();

    //Retour SI016
    Retour retourSI016 = RetourFactory.createNOK(IMegConsts.CAT3, null, null);

    //Retour BL300_VerifierAvancement
    Retour expectedRetourBl300 = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, null);

    //Setup mock CMD
    createMockCmdLireUn(retourCmd, commande);

    //Setup mock SI016
    createMockSI016RecupererInfoVerrou(retourSI016, flagVerrouDecLibEqt, idCmdOss);

    _processInstance.getProcessContext().setNbVerifMax(120);

    //Call PE0170_BL300_VerifierAvancement
    PowerMock.replayAll();
    Pair<Retour, Boolean> bl300Result = Whitebox.invokeMethod(_processInstance, "PE0170_BL300_VerifierAvancement", _tracabilite, idCmd); //$NON-NLS-1$
    PowerMock.verify();

    //Asserts
    assertEquals(expectedRetourBl300, bl300Result._first);
    assertNull(bl300Result._second);
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. CMD Proxy returns OK but activity SI016 returns NOK CAT-2.<br>
   * <b>Input:</b>The commande swap identifier.<br>
   * <b>Result:</b> Retour KO CAT-10 and flag should be null.
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_BL300_VerifierAvancement_Test_KO_03() throws Throwable
  {
    //Build objects
    Commande commande = new Commande();
    String idCmd = "1c27c3ba-bd3a-462e-8e9e-cba6180f614d"; //$NON-NLS-1$
    commande.setIdCmd(idCmd);
    Boolean flagVerrouDecLibEqt = false;

    String idCmdOss = "12345"; //$NON-NLS-1$
    Map<String, String> donneesSpecifiques = new HashMap<>();
    donneesSpecifiques.put(ID_CMD_RACCO_EN_COURS, idCmdOss);
    commande.setDonneesSpecifiques(GsonTools.getIso8601Ms().toJson(donneesSpecifiques));

    //Retour CMD Proxy
    Retour retourCmd = RetourFactory.createOkRetour();

    //Retour SI016
    Retour retourSI016 = RetourFactory.createNOK(IMegConsts.CAT2, null, null);

    //Retour BL300_VerifierAvancement
    Retour expectedRetourBl300 = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, null);

    //Setup mock CMD
    createMockCmdLireUn(retourCmd, commande);

    //Setup mock SI016
    createMockSI016RecupererInfoVerrou(retourSI016, flagVerrouDecLibEqt, idCmdOss);

    _processInstance.getProcessContext().setNbVerifMax(120);

    //Call PE0170_BL300_VerifierAvancement
    PowerMock.replayAll();
    Pair<Retour, Boolean> bl300Result = Whitebox.invokeMethod(_processInstance, "PE0170_BL300_VerifierAvancement", _tracabilite, idCmd); //$NON-NLS-1$
    PowerMock.verify();

    //Asserts
    assertEquals(expectedRetourBl300, bl300Result._first);
    assertNull(bl300Result._second);
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. CMD Proxy returns OK but activity SI016 returns NOK CAT-4.<br>
   * <b>Input:</b>The commande swap identifier.<br>
   * <b>Result:</b> Retour KO CAT-4 and flag should be null.
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_BL300_VerifierAvancement_Test_KO_04() throws Throwable
  {

    //Build objects
    Commande commande = new Commande();
    String idCmd = "1c27c3ba-bd3a-462e-8e9e-cba6180f614d"; //$NON-NLS-1$
    commande.setIdCmd(idCmd);
    Boolean flagVerrouDecLibEqt = false;

    String idCmdOss = "12345"; //$NON-NLS-1$
    Map<String, String> donneesSpecifiques = new HashMap<>();
    donneesSpecifiques.put(ID_CMD_RACCO_EN_COURS, idCmdOss);
    commande.setDonneesSpecifiques(GsonTools.getIso8601Ms().toJson(donneesSpecifiques));

    //Retour CMD Proxy
    Retour retourCmd = RetourFactory.createOkRetour();

    //Retour SI016
    Retour retourSI016 = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.COMMANDE_INCONNUE, null);

    //Retour BL300_VerifierAvancement
    Retour expectedRetourBl300 = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.COMMANDE_INCONNUE, null);

    //Setup mock CMD
    createMockCmdLireUn(retourCmd, commande);

    //Setup mock SI016
    createMockSI016RecupererInfoVerrou(retourSI016, flagVerrouDecLibEqt, idCmdOss);

    _processInstance.getProcessContext().setNbVerifMax(120);

    //Call PE0170_BL300_VerifierAvancement
    PowerMock.replayAll();
    Pair<Retour, Boolean> bl300Result = Whitebox.invokeMethod(_processInstance, "PE0170_BL300_VerifierAvancement", _tracabilite, idCmd); //$NON-NLS-1$
    PowerMock.verify();

    //Asserts
    assertEquals(expectedRetourBl300, bl300Result._first);
    assertNull(bl300Result._second);
  }

  /**
   * <b>Scenario:</b> Tests nominal case. CMD Proxy returns OK but activity SI016 returns OK.<br>
   * <b>Input:</b>The commande swap identifier.<br>
   * <b>Result:</b> Retour OK and flag should be true.
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_BL300_VerifierAvancement_Test_OK_01() throws Throwable
  {
    //Build objects
    Commande commande = new Commande();
    String idCmd = "1c27c3ba-bd3a-462e-8e9e-cba6180f614d"; //$NON-NLS-1$
    commande.setIdCmd(idCmd);
    Boolean flagVerrouDecLibEqt = false;

    String idCmdOss = "12345"; //$NON-NLS-1$
    Map<String, String> donneesSpecifiques = new HashMap<>();
    donneesSpecifiques.put(ID_CMD_RACCO_EN_COURS, idCmdOss);
    commande.setDonneesSpecifiques(GsonTools.getIso8601Ms().toJson(donneesSpecifiques));

    //Retour CMD Proxy
    Retour retourCmd = RetourFactory.createOkRetour();

    //Retour SI016
    Retour retourSI016 = RetourFactory.createOkRetour();

    //Retour BL300_VerifierAvancement
    Retour expectedRetourBl300 = RetourFactory.createOkRetour();

    //Setup mock CMD
    createMockCmdLireUn(retourCmd, commande);

    //Setup mock SI016
    createMockSI016RecupererInfoVerrou(retourSI016, flagVerrouDecLibEqt, idCmdOss);

    _processInstance.getProcessContext().setNbVerifMax(120);

    //Call PE0170_BL300_VerifierAvancement
    PowerMock.replayAll();
    Pair<Retour, Boolean> bl300Result = Whitebox.invokeMethod(_processInstance, "PE0170_BL300_VerifierAvancement", _tracabilite, idCmd); //$NON-NLS-1$
    PowerMock.verify();

    //Asserts
    assertEquals(expectedRetourBl300, bl300Result._first);
    assertTrue(bl300Result._second);
  }

  /**
   * <b>Scenario:</b> Tests nominal case. CMD Proxy returns OK but activity SI016 returns OK.<br>
   * <b>Input:</b>The commande swap identifier.<br>
   * <b>Result:</b> Retour OK and flag should be false.
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_BL300_VerifierAvancement_Test_OK_02() throws Throwable
  {
    //Build objects
    Commande commande = new Commande();
    String idCmd = "1c27c3ba-bd3a-462e-8e9e-cba6180f614d"; //$NON-NLS-1$
    commande.setIdCmd(idCmd);
    Boolean flagVerrouDecLibEqt = true;

    String idCmdOss = "12345"; //$NON-NLS-1$
    Map<String, String> donneesSpecifiques = new HashMap<>();
    donneesSpecifiques.put(ID_CMD_RACCO_EN_COURS, idCmdOss);
    commande.setDonneesSpecifiques(GsonTools.getIso8601Ms().toJson(donneesSpecifiques));

    //Retour CMD Proxy
    Retour retourCmd = RetourFactory.createOkRetour();

    //Retour SI016
    Retour retourSI016 = RetourFactory.createOkRetour();

    //Retour BL300_VerifierAvancement
    Retour expectedRetourBl300 = RetourFactory.createOkRetour();

    //Setup mock CMD
    createMockCmdLireUn(retourCmd, commande);

    //Setup mock SI016
    createMockSI016RecupererInfoVerrou(retourSI016, flagVerrouDecLibEqt, idCmdOss);

    _processInstance.getProcessContext().setNbVerifMax(120);

    //Call PE0170_BL300_VerifierAvancement
    PowerMock.replayAll();
    Pair<Retour, Boolean> bl300Result = Whitebox.invokeMethod(_processInstance, "PE0170_BL300_VerifierAvancement", _tracabilite, idCmd); //$NON-NLS-1$
    PowerMock.verify();

    //Asserts
    assertEquals(expectedRetourBl300, bl300Result._first);
    assertFalse(bl300Result._second);
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. CMDProxy.lireUn returns NOK CAT-4.<br>
   * <b>Input:</b>The commande swap identifier, the swapEqt object and the equipement to liberer.<br>
   * <b>Result:</b> Retour NOK CAT-4.
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_BL400_DeclarerEquipement_Test_KO_01() throws Throwable
  {

    //Build objects
    Commande commande = new Commande();
    String idCmd = "1c27c3ba-bd3a-462e-8e9e-cba6180f614d"; //$NON-NLS-1$
    commande.setIdCmd(idCmd);
    SwapEqt swapEqt = buildValidSwapEqtRequest();
    PE0170_Eqt pe170Eqt = new PE0170_Eqt();
    pe170Eqt.setNoSequence("98765"); //$NON-NLS-1$

    //Retour CMD Proxy
    Retour retourCmd = RetourFactory.createNOK(IMegConsts.CAT4, null, null);

    //Retour BL400_DeclarerEquipement
    Retour expectedRetourBl400 = RetourFactory.createNOK(IMegConsts.CAT4, null, null);

    //Setup mock CMD
    createMockCmdLireUn(retourCmd, commande);

    //Call PE0170_BL400_DeclarerEquipement
    PowerMock.replayAll();
    Retour bl400Result = Whitebox.invokeMethod(_processInstance, "PE0170_BL400_DeclarerEquipement", _tracabilite, idCmd, swapEqt, pe170Eqt); //$NON-NLS-1$
    PowerMock.verify();

    //Asserts
    assertEquals(expectedRetourBl400, bl400Result);
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. CMDProxy.lireUn returns OK but BL103_CalculerNoCompteCourt returns NOK
   * CAT-3.<br>
   * <b>Input:</b>The commande swap identifier, the swapEqt object and the equipement to liberer.<br>
   * <b>Result:</b> Retour NOK CAT-10.
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_BL400_DeclarerEquipement_Test_KO_02() throws Throwable
  {

    //Build objects
    Commande commande = new Commande();
    String idCmd = "12345"; //$NON-NLS-1$
    commande.setIdCmd(idCmd);
    SwapEqt swapEqt = buildValidSwapEqtRequest();
    swapEqt.getInfosService().setTypeEquipement(TypeEquipement.MODEM);
    swapEqt.getEquipementCible().setNomFabriquant("Sagem"); //$NON-NLS-1$
    String invalidNoCompte = "9485764321"; //$NON-NLS-1$
    swapEqt.getPortefeuilleServices().setNoCompte(invalidNoCompte);
    PE0170_Eqt pe170Eqt = new PE0170_Eqt();
    pe170Eqt.setNoSequence("98765"); //$NON-NLS-1$

    //Retour CMD Proxy
    Retour retourCmd = RetourFactory.createOkRetour();

    //Retour BL400_DeclarerEquipement
    Retour expectedRetourBl400 = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, MessageFormat.format(MESSAGE_PROBLEME_CALCUL_SRVID, swapEqt.getPortefeuilleServices().getNoCompte()));

    //Setup mock CMD
    createMockCmdLireUn(retourCmd, commande);

    //Call PE0170_BL400_DeclarerEquipement
    PowerMock.replayAll();
    Retour bl400Result = Whitebox.invokeMethod(_processInstance, "PE0170_BL400_DeclarerEquipement", _tracabilite, idCmd, swapEqt, pe170Eqt); //$NON-NLS-1$
    PowerMock.verify();

    //Asserts
    assertEquals(expectedRetourBl400, bl400Result);
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. CMDProxy.lireUn returns OK, BL103_CalculerNoCompteCourt returns OK but
   * SI017 activity returns NOK CAT-3.<br>
   * <b>Input:</b>The commande swap identifier, the swapEqt object and the equipement to liberer.<br>
   * <b>Result:</b> Retour NOK CAT-10.
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_BL400_DeclarerEquipement_Test_KO_03() throws Throwable
  {

    //Build objects
    Commande commande = new Commande();
    String idCmd = "12345"; //$NON-NLS-1$
    String donneesSpecifiques = "{\"identifiantTechniqueEqtALiberer\":\"453827\",\"idCmdRaccoEnCours\":\"54321\"}"; //$NON-NLS-1$
    commande.setIdCmd(idCmd);
    commande.setDonneesSpecifiques(donneesSpecifiques);
    SwapEqt swapEqt = buildValidSwapEqtRequest();
    swapEqt.getInfosService().setTypeEquipement(TypeEquipement.DECODEUR_TV);
    swapEqt.getEquipementCible().setNomFabriquant("SAGEMCOM"); //$NON-NLS-1$
    PE0170_Eqt pe170Eqt = new PE0170_Eqt();
    String noSequence = "98765"; //$NON-NLS-1$
    pe170Eqt.setNoSequence(noSequence);

    //Retour CMD Proxy
    Retour retourCmd = RetourFactory.createOkRetour();

    //Retour SI017 activity
    String libelleErreurSI017 = "SI017 Libelle erreur"; //$NON-NLS-1$
    Retour retourSI017 = RetourFactory.createNOK(IMegConsts.CAT3, null, libelleErreurSI017);

    //Retour BL400_DeclarerEquipement
    Retour expectedRetourBl400 = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, libelleErreurSI017);

    //Setup mock CMD
    createMockCmdLireUn(retourCmd, commande);

    //Setup mock SI017
    createMockSI017DeclarerEquipement(retourSI017);

    //Call PE0170_BL400_DeclarerEquipement
    PowerMock.replayAll();
    Retour bl400Result = Whitebox.invokeMethod(_processInstance, "PE0170_BL400_DeclarerEquipement", _tracabilite, idCmd, swapEqt, pe170Eqt); //$NON-NLS-1$
    PowerMock.verify();

    //Asserts
    assertEquals(expectedRetourBl400, bl400Result);
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. CMDProxy.lireUn returns OK, BL103_CalculerNoCompteCourt returns OK but
   * SI017 activity returns NOK CAT-5 and the CMDProxy.modifierStatut returns NOK.<br>
   * <b>Input:</b>The commande swap identifier, the swapEqt object and the equipement to liberer.<br>
   * <b>Result:</b> Retour NOK CAT-5 because in this scenario the final retour should be the one returned by the
   * declaration operation and not the one returned by BL4600.
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_BL400_DeclarerEquipement_Test_KO_04() throws Throwable
  {

    //Build objects
    Commande commande = new Commande();
    String idCmd = "12345"; //$NON-NLS-1$
    String donneesSpecifiques = "{\"identifiantTechniqueEqtALiberer\":\"453827\",\"idCmdRaccoEnCours\":\"54321\"}"; //$NON-NLS-1$
    commande.setIdCmd(idCmd);
    commande.setDonneesSpecifiques(donneesSpecifiques);
    SwapEqt swapEqt = buildValidSwapEqtRequest();
    swapEqt.getInfosService().setTypeEquipement(TypeEquipement.MODEM);
    swapEqt.getEquipementCible().setNomFabriquant("Sagem"); //$NON-NLS-1$
    PE0170_Eqt pe170Eqt = new PE0170_Eqt();
    String noSequence = "98765"; //$NON-NLS-1$
    pe170Eqt.setNoSequence(noSequence);

    //Retour CMD Proxy lireUn
    Retour retourCmdLireUn = RetourFactory.createOkRetour();

    //Retour SI017 activity
    String libelleErreurSI017 = "SI017 Libelle erreur"; //$NON-NLS-1$
    Retour retourSI017 = RetourFactory.createNOK(IMegConsts.CAT5, null, libelleErreurSI017);

    //Retour CMD Proxy modifierStatut
    Retour retourCmdModifierStatut = RetourFactory.createNOK(IMegConsts.CAT2, null, null);

    //Retour BL400_DeclarerEquipement
    Retour expectedRetourBl400 = RetourFactory.createNOK(IMegConsts.CAT5, null, libelleErreurSI017);

    //Setup mock CMD lireUn
    createMockCmdLireUn(retourCmdLireUn, commande);

    //Setup mock SI017
    createMockSI017DeclarerEquipement(retourSI017);

    //Setup mock CMD modifierStatut
    Statut statutCommande = Statut.ECHEC;
    Capture<String> capturedStatut = createMockCmdModifierStatut(retourCmdModifierStatut);

    //Setup mock BL4600
    createMockBL4600(null);

    //Call PE0170_BL400_DeclarerEquipement
    PowerMock.replayAll();
    Retour bl400Result = Whitebox.invokeMethod(_processInstance, "PE0170_BL400_DeclarerEquipement", _tracabilite, idCmd, swapEqt, pe170Eqt); //$NON-NLS-1$
    PowerMock.verify();

    //Asserts
    assertEquals(expectedRetourBl400, retourSI017);
    assertEquals(statutCommande.name(), capturedStatut.getValue());
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. CMDProxy.lireUn returns OK, BL103_CalculerNoCompteCourt returns OK, SI017
   * activity returns OK but the CMDProxy.modifierStatut returns NOK CAT-4.<br>
   * <b>Input:</b>The commande swap identifier, the swapEqt object and the equipement to liberer.<br>
   * <b>Result:</b> Retour NOK CAT-4.
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_BL400_DeclarerEquipement_Test_KO_05() throws Throwable
  {

    //Build objects
    Commande commande = new Commande();
    String idCmd = "12345"; //$NON-NLS-1$
    String donneesSpecifiques = "{\"identifiantTechniqueEqtALiberer\":\"453827\",\"idCmdRaccoEnCours\":\"54321\"}"; //$NON-NLS-1$
    commande.setIdCmd(idCmd);
    commande.setDonneesSpecifiques(donneesSpecifiques);
    SwapEqt swapEqt = buildValidSwapEqtRequest();
    PE0170_Eqt pe170Eqt = new PE0170_Eqt();
    String noSequence = "98765"; //$NON-NLS-1$
    pe170Eqt.setNoSequence(noSequence);

    //Retour CMD Proxy lireUn
    Retour retourCmdLireUn = RetourFactory.createOkRetour();

    //Retour SI017 activity
    Retour retourSI017 = RetourFactory.createOkRetour();

    //Retour CMD Proxy modifierStatut
    Retour retourCmdModifierStatut = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.ENTREE_INCORRECTE, null);

    //Retour BL400_DeclarerEquipement
    Retour expectedRetourBl400 = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.ENTREE_INCORRECTE, null);

    //Setup mock CMD lireUn
    createMockCmdLireUn(retourCmdLireUn, commande);

    //Setup mock SI017
    createMockSI017DeclarerEquipement(retourSI017);

    //Setup mock CMD modifierStatut
    Statut statutCommande = Statut.EN_COURS;
    Capture<String> capturedStatut = createMockCmdModifierStatut(retourCmdModifierStatut);

    //Call PE0170_BL400_DeclarerEquipement
    PowerMock.replayAll();
    Whitebox.invokeMethod(_processInstance, "PE0170_BL400_DeclarerEquipement", _tracabilite, idCmd, swapEqt, pe170Eqt); //$NON-NLS-1$
    PowerMock.verify();

    //Asserts
    assertEquals(expectedRetourBl400, retourCmdModifierStatut);
    assertEquals(statutCommande.name(), capturedStatut.getValue());
  }

  /**
   * <b>Scenario:</b> Tests nominal case. CMDProxy.lireUnreturns OK, BL103_CalculerNoCompteCourt returns OK, SI017
   * activity returns OK and CMDProxy.modifierStatut returns OK.<br>
   * <b>Input:</b>The commande swap identifier, the swapEqt object and the equipement to liberer.<br>
   * <b>Result:</b> Retour OK.
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_BL400_DeclarerEquipement_Test_OK_01() throws Throwable
  {

    //Build objects
    Commande commande = new Commande();
    String idCmd = "12345"; //$NON-NLS-1$
    String donneesSpecifiques = "{\"identifiantTechniqueEqtALiberer\":\"453827\",\"idCmdRaccoEnCours\":\"54321\"}"; //$NON-NLS-1$
    commande.setIdCmd(idCmd);
    commande.setDonneesSpecifiques(donneesSpecifiques);
    SwapEqt swapEqt = buildValidSwapEqtRequest();
    PE0170_Eqt pe170Eqt = new PE0170_Eqt();
    String noSequence = "98765"; //$NON-NLS-1$
    pe170Eqt.setNoSequence(noSequence);

    //Retour CMD Proxy lireUn
    Retour retourCmdLireUn = RetourFactory.createOkRetour();

    //Retour SI017 activity
    Retour retourSI017 = RetourFactory.createOkRetour();

    //Retour CMD Proxy modifierStatut
    Retour retourCmdModifierStatut = RetourFactory.createOkRetour();

    //Retour BL400_DeclarerEquipement
    Retour expectedRetourBl400 = RetourFactory.createOkRetour();

    //Setup mock CMD lireUn
    createMockCmdLireUn(retourCmdLireUn, commande);

    //Setup mock SI017
    createMockSI017DeclarerEquipement(retourSI017);

    //Setup mock CMD modifierStatut
    Statut statutCommande = Statut.EN_COURS;
    Capture<String> capturedStatut = createMockCmdModifierStatut(retourCmdModifierStatut);

    //Call PE0170_BL400_DeclarerEquipement
    PowerMock.replayAll();
    Retour bl400Result = Whitebox.invokeMethod(_processInstance, "PE0170_BL400_DeclarerEquipement", _tracabilite, idCmd, swapEqt, pe170Eqt); //$NON-NLS-1$
    PowerMock.verify();

    //Asserts
    assertEquals(expectedRetourBl400, retourCmdModifierStatut);
    assertEquals(statutCommande.name(), capturedStatut.getValue());
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. CMDProxy.lireUn returns NOK.<br>
   * <b>Input:</b>The commande swap identifier.<br>
   * <b>Result:</b> Retour NOK.
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_BL500_CloturerCommande_Test_KO_01() throws Throwable
  {
    //Build objects
    Commande commande = new Commande();
    String idCmd = "12345"; //$NON-NLS-1$
    commande.setIdCmd(idCmd);

    //Retour CMD Proxy lireUn
    Retour retourCmdLireUn = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.TRAITEMENT_ARRETE, "Libelle CMDProxy.lireUn error"); //$NON-NLS-1$

    //Setup mock CMD lireUn
    createMockCmdLireUn(retourCmdLireUn, commande);

    //Call PE0170_BL500_CloturerCommande
    PowerMock.replayAll();
    Retour bl500Result = Whitebox.invokeMethod(_processInstance, "PE0170_BL500_CloturerCommande", _tracabilite, idCmd); //$NON-NLS-1$
    PowerMock.verify();

    //Asserts
    assertEquals(retourCmdLireUn, bl500Result);
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. CMDProxy.lireUn returns OK but commande status is not equal to
   * 'EN_COURS'.<br>
   * <b>Input:</b>The commande swap identifier.<br>
   * <b>Result:</b> Retour {NOK, CAT-10, TRAITEMENT_ARRETE}.
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_BL500_CloturerCommande_Test_KO_02() throws Throwable
  {
    //Build objects
    Commande commande = new Commande();
    String idCmd = "12345"; //$NON-NLS-1$
    commande.setIdCmd(idCmd);
    commande.setStatut(Statut.REJETE.name());

    //Retour CMD Proxy lireUn
    Retour retourCmdLireUn = RetourFactory.createOkRetour();

    //Expected retour
    Retour expectedRetour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, MessageFormat.format(MESSAGE_COMMANDE_STATUT_INVALIDE_CLOTURER, commande.getIdCmd(), commande.getStatut()));

    //Setup mock CMD lireUn
    createMockCmdLireUn(retourCmdLireUn, commande);

    //Call PE0170_BL500_CloturerCommande
    PowerMock.replayAll();
    Retour bl500Result = Whitebox.invokeMethod(_processInstance, "PE0170_BL500_CloturerCommande", _tracabilite, idCmd); //$NON-NLS-1$
    PowerMock.verify();

    //Asserts
    assertEquals(expectedRetour, bl500Result);
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. CMDProxy.lireUn returns OK, commande has status 'EN_COURS' but
   * BSSGP_SI002_EnvoyerCRSwap returns NOK.<br>
   * <b>Input:</b>The commande swap identifier.<br>
   * <b>Result:</b> Retour NOK.
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_BL500_CloturerCommande_Test_KO_03() throws Throwable
  {
    //Build objects
    Commande commande = new Commande();
    String idCmd = "1c27c3ba-bd3a-462e-8e9e-cba6180f614d"; //$NON-NLS-1$
    commande.setIdCmd(idCmd);
    String idExterne = "1234"; //$NON-NLS-1$
    commande.setIdExterne(idExterne);
    commande.setStatut(Statut.EN_COURS.name());
    SwapEqt swapEqt = buildValidSwapEqtRequest();
    String idCmdOss = "12345"; //$NON-NLS-1$
    swapEqt.getInfosService().setIdCommande(idCmdOss);
    _processInstance.getProcessContext().setSwapEqt(swapEqt);

    Map<String, String> donneesSpecifiques = new HashMap<>();
    donneesSpecifiques.put(ID_CMD_RACCO_EN_COURS, "12345"); //$NON-NLS-1$
    donneesSpecifiques.put(IDENTIFIANT_TECHNIQUE_EQT_A_LIBERER, "453827"); //$NON-NLS-1$
    commande.setDonneesSpecifiques(GsonTools.getIso8601Ms().toJson(donneesSpecifiques));

    //Retour CMD Proxy lireUn
    Retour retourCmdLireUn = RetourFactory.createOkRetour();

    //Retour BSSGP_SI002_EnvoyerCRSwap
    Retour retourSI002EnvoyerCRSwap = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.DONNEE_INVALIDE, "Libelle SI002 error"); //$NON-NLS-1$

    //Setup mock CMD lireUn
    createMockCmdLireUn(retourCmdLireUn, commande);

    //Setup mock BSSGP_SI002_EnvoyerCRSwap
    String expectedStatutBssGP = "CR_OK"; //$NON-NLS-1$
    Capture<String> capturedStatut = createMockBssGpSI002(retourSI002EnvoyerCRSwap, idExterne, idCmdOss);

    //Call PE0170_BL500_CloturerCommande
    PowerMock.replayAll();
    Retour bl500Result = Whitebox.invokeMethod(_processInstance, "PE0170_BL500_CloturerCommande", _tracabilite, idCmd); //$NON-NLS-1$
    PowerMock.verify();

    //Asserts
    assertEquals(retourSI002EnvoyerCRSwap, bl500Result);
    assertEquals(expectedStatutBssGP, capturedStatut.getValue());
  }

  /**
   * <b>Scenario:</b> Tests nominal case. CMDProxy.lireUn returns OK, commande has status 'EN_COURS' and
   * BSSGP_SI002_EnvoyerCRSwap returns OK.<br>
   * <b>Input:</b>The commande swap identifier.<br>
   * <b>Result:</b> Retour OK.
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_BL500_CloturerCommande_Test_OK_01() throws Throwable
  {
    //Build objects
    Commande commande = new Commande();
    String idCmd = "1c27c3ba-bd3a-462e-8e9e-cba6180f614d"; //$NON-NLS-1$
    commande.setIdCmd(idCmd);
    String idExterne = "1234"; //$NON-NLS-1$
    commande.setIdExterne(idExterne);
    commande.setStatut(Statut.EN_COURS.name());
    SwapEqt swapEqt = buildValidSwapEqtRequest();
    String idCmdOss = "12345"; //$NON-NLS-1$
    swapEqt.getInfosService().setIdCommande(idCmdOss);
    _processInstance.getProcessContext().setSwapEqt(swapEqt);

    Map<String, String> donneesSpecifiques = new HashMap<>();
    donneesSpecifiques.put(ID_CMD_RACCO_EN_COURS, "12345"); //$NON-NLS-1$
    donneesSpecifiques.put(IDENTIFIANT_TECHNIQUE_EQT_A_LIBERER, "453827"); //$NON-NLS-1$
    commande.setDonneesSpecifiques(GsonTools.getIso8601Ms().toJson(donneesSpecifiques));

    //Retour CMD Proxy lireUn
    Retour retourCmdLireUn = RetourFactory.createOkRetour();

    //Retour BSSGP_SI002_EnvoyerCRSwap
    Retour retourSI002EnvoyerCRSwap = RetourFactory.createOkRetour();

    //Setup mock CMD lireUn
    createMockCmdLireUn(retourCmdLireUn, commande);

    //Setup mock CMD modifierStatut
    String expectedStatutModifier = "TRAITE_OK"; //$NON-NLS-1$
    Retour retourModifierStatut = RetourFactory.createOkRetour();
    Capture<String> capturedStatutModifierStatut = createMockCmdModifierStatut(retourModifierStatut);

    //Setup mock BSSGP_SI002_EnvoyerCRSwap
    String expectedStatutBssGP = "CR_OK"; //$NON-NLS-1$
    Capture<String> capturedStatutBssGp = createMockBssGpSI002(retourSI002EnvoyerCRSwap, idExterne, idCmdOss);

    //Call PE0170_BL500_CloturerCommande
    PowerMock.replayAll();
    Retour bl500Result = Whitebox.invokeMethod(_processInstance, "PE0170_BL500_CloturerCommande", _tracabilite, idCmd); //$NON-NLS-1$
    PowerMock.verify();

    //Asserts
    assertEquals(retourSI002EnvoyerCRSwap, bl500Result);
    assertEquals(expectedStatutBssGP, capturedStatutBssGp.getValue());
    assertEquals(expectedStatutModifier, capturedStatutModifierStatut.getValue());
  }

  /**
   * <b>Scenario:</b> Tests no nominal case. Entry params<br>
   * <b>Input:</b><br>
   * <b>Result:</b> Retour KO
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_BL600_VerifierFonctionnelSwapRacco_Test_KO_01() throws Throwable
  {

    String idCmdRaccoEnCours_p = "11111"; //$NON-NLS-1$
    SwapEqt swapEqt = buildValidSwapEqtRequest();
    swapEqt.getPortefeuilleServices().setTypeAcces(TypeAcces.XDSL);
    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ENTREE_INCORRECTE, MessageFormat.format(MESSAGE_WRONG_TECH_ERREUR, swapEqt.getPortefeuilleServices().getTypeAcces()));

    PowerMock.replayAll();
    //Call PE0170_BL600
    Pair<Retour, PE0170_Eqt> bl600Result = Whitebox.invokeMethod(_processInstance, "PE0170_BL600_VerifierFonctionnelSwapRacco", _tracabilite, swapEqt, idCmdRaccoEnCours_p); //$NON-NLS-1$
    PowerMock.verify();

    //Asserts
    assertEquals(retour, bl600Result._first);
    Assert.assertNull(bl600Result._second);
  }

  /**
   * <b>Scenario:</b> Tests no nominal case. First lireTousParStatutEtPFI is NOK, but not CAT4 DONNEE INCONNUE<br>
   * <b>Input:</b><br>
   * <b>Result:</b> Retour KO
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_BL600_VerifierFonctionnelSwapRacco_Test_KO_02() throws Throwable
  {

    String idCmdRaccoEnCours_p = "11111"; //$NON-NLS-1$
    SwapEqt swapEqt = buildValidSwapEqtRequest();
    Retour retourKO = RetourFactoryForTU.createNOK(IMegConsts.CAT3, "some error", "some error"); //$NON-NLS-1$ //$NON-NLS-2$
    ConnectorResponse<Retour, List<Commande>> cmdListRetour = new ConnectorResponse<>(retourKO, null);

    //BL600
    EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdProxyMock);
    EasyMock.expect(_cmdProxyMock.commandeLireTousParStatutEtPFI(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("Client operateur"), EasyMock.eq(swapEqt.getPortefeuilleServices().getNoCompte()), EasyMock.eq(Statut.EN_COURS.name()))).andReturn(cmdListRetour); //$NON-NLS-1$

    PowerMock.replayAll();
    //Call PE0170_BL600
    Pair<Retour, PE0170_Eqt> bl600Result = Whitebox.invokeMethod(_processInstance, "PE0170_BL600_VerifierFonctionnelSwapRacco", _tracabilite, swapEqt, idCmdRaccoEnCours_p); //$NON-NLS-1$
    PowerMock.verify();

    //Asserts
    assertEquals(retourKO, bl600Result._first);
    Assert.assertNull(bl600Result._second);
  }

  /**
   * <b>Scenario:</b> Tests no nominal case. Second lireTousParStatutEtPFI is NOK, but not CAT4 DONNEE INCONNUE<br>
   * <b>Input:</b><br>
   * <b>Result:</b> Retour KO
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_BL600_VerifierFonctionnelSwapRacco_Test_KO_03() throws Throwable
  {

    String idCmdRaccoEnCours_p = "11111"; //$NON-NLS-1$
    SwapEqt swapEqt = buildValidSwapEqtRequest();

    Retour retourKO = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "some error"); //$NON-NLS-1$
    ConnectorResponse<Retour, List<Commande>> cmdListRetour = new ConnectorResponse<>(retourKO, null);

    Commande commande2 = new Commande();
    String idCmd = "12345"; //$NON-NLS-1$
    Retour retourOk = RetourFactoryForTU.createOkRetour();
    commande2.setIdCmd(idCmd);
    commande2.setNatureCommande("SWAP_EQT"); //$NON-NLS-1$
    ArrayList<Commande> listCommande = new ArrayList<>();
    listCommande.add(commande2);
    ConnectorResponse<Retour, List<Commande>> cmdListRetour2 = new ConnectorResponse<>(retourOk, listCommande);

    //lireTousParStatutEtPFI EN Cours
    EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdProxyMock);
    EasyMock.expect(_cmdProxyMock.commandeLireTousParStatutEtPFI(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("Client operateur"), EasyMock.eq(swapEqt.getPortefeuilleServices().getNoCompte()), EasyMock.eq(Statut.EN_COURS.name()))).andReturn(cmdListRetour); //$NON-NLS-1$

    //lireTousParStatutEtPFI Echec
    EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdProxyMock);
    EasyMock.expect(_cmdProxyMock.commandeLireTousParStatutEtPFI(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("Client operateur"), EasyMock.eq(swapEqt.getPortefeuilleServices().getNoCompte()), EasyMock.eq(Statut.ECHEC.name()))).andReturn(cmdListRetour2); //$NON-NLS-1$

    PowerMock.replayAll();
    //Call PE0170_BL600
    Pair<Retour, PE0170_Eqt> bl600Result = Whitebox.invokeMethod(_processInstance, "PE0170_BL600_VerifierFonctionnelSwapRacco", _tracabilite, swapEqt, idCmdRaccoEnCours_p); //$NON-NLS-1$
    PowerMock.verify();

    //Asserts
    String errorMessage = MessageFormat.format(MESSAGE_COMMANDE_EXISTANTE_ERREUR, commande2.getIdCmd(), "Client operateur", swapEqt.getPortefeuilleServices().getNoCompte()); //$NON-NLS-1$
    Retour retourKO2 = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.COMMANDE_EXISTANTE, errorMessage);
    assertEquals(retourKO2, bl600Result._first);
    Assert.assertNull(bl600Result._second);
  }

  /**
   * <b>Scenario:</b> Tests no nominal case. first lireTousParStatutEtPFI is OK, but commande id doesn't match<br>
   * <b>Input:</b><br>
   * <b>Result:</b> Retour KO
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_BL600_VerifierFonctionnelSwapRacco_Test_KO_04() throws Throwable
  {

    String idCmdRaccoEnCours_p = "11111"; //$NON-NLS-1$
    SwapEqt swapEqt = buildValidSwapEqtRequest();

    Commande commande2 = new Commande();
    String idCmd = "12345"; //$NON-NLS-1$
    Retour retourOk = RetourFactoryForTU.createOkRetour();
    commande2.setIdCmd(idCmd);
    commande2.setNatureCommande("SWAP_EQT"); //$NON-NLS-1$
    ArrayList<Commande> listCommande = new ArrayList<>();
    listCommande.add(commande2);
    ConnectorResponse<Retour, List<Commande>> cmdListRetour = new ConnectorResponse<>(retourOk, listCommande);

    //lireTousParStatutEtPFI EN Cours
    EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdProxyMock);
    EasyMock.expect(_cmdProxyMock.commandeLireTousParStatutEtPFI(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("Client operateur"), EasyMock.eq(swapEqt.getPortefeuilleServices().getNoCompte()), EasyMock.eq(Statut.EN_COURS.name()))).andReturn(cmdListRetour); //$NON-NLS-1$

    PowerMock.replayAll();
    //Call PE0170_BL600
    Pair<Retour, PE0170_Eqt> bl600Result = Whitebox.invokeMethod(_processInstance, "PE0170_BL600_VerifierFonctionnelSwapRacco", _tracabilite, swapEqt, idCmdRaccoEnCours_p); //$NON-NLS-1$
    PowerMock.verify();

    //Asserts
    String errorMessage = MessageFormat.format(MESSAGE_COMMANDE_EXISTANTE_ERREUR, commande2.getIdCmd(), "Client operateur", swapEqt.getPortefeuilleServices().getNoCompte()); //$NON-NLS-1$
    Retour retourKO2 = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.COMMANDE_EXISTANTE, errorMessage);
    assertEquals(retourKO2, bl600Result._first);
    Assert.assertNull(bl600Result._second);
  }

  /**
   * <b>Scenario:</b> Tests no nominal case. BL101 KO<br>
   * <b>Input:</b><br>
   * <b>Result:</b> Retour KO
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_BL600_VerifierFonctionnelSwapRacco_Test_KO_05() throws Throwable
  {

    String idCmdRaccoEnCours_p = "11111"; //$NON-NLS-1$
    SwapEqt swapEqt = buildValidSwapEqtRequest();

    Retour retourKO = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "some error"); //$NON-NLS-1$
    ConnectorResponse<Retour, List<Commande>> cmdListRetour = new ConnectorResponse<>(retourKO, null);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(true, true, true, true, 120);

    ProcessManager.getInstance().getProcessParams().clear();
    ProcessManager.getInstance().getProcessParams().putAll(processParams);

    //lireTousParStatutEtPFI EN Cours
    EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdProxyMock);
    EasyMock.expect(_cmdProxyMock.commandeLireTousParStatutEtPFI(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("Client operateur"), EasyMock.eq(swapEqt.getPortefeuilleServices().getNoCompte()), EasyMock.eq(Statut.EN_COURS.name()))).andReturn(cmdListRetour); //$NON-NLS-1$

    //lireTousParStatutEtPFI Echec
    EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdProxyMock);
    EasyMock.expect(_cmdProxyMock.commandeLireTousParStatutEtPFI(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("Client operateur"), EasyMock.eq(swapEqt.getPortefeuilleServices().getNoCompte()), EasyMock.eq(Statut.ECHEC.name()))).andReturn(cmdListRetour); //$NON-NLS-1$

    //lireTousParStatutEtPFI Echec
    EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdProxyMock);
    EasyMock.expect(_cmdProxyMock.commandeLireTousParStatutEtPFI(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("Client operateur"), EasyMock.eq(swapEqt.getPortefeuilleServices().getNoCompte()), EasyMock.eq(Statut.ACQUITTE.name()))).andReturn(cmdListRetour); //$NON-NLS-1$

    PowerMock.replayAll();

    // Load Process Config
    Whitebox.invokeMethod(_processInstance, "loadProcessParameters"); //$NON-NLS-1$

    //Call PE0170_BL600
    Pair<Retour, PE0170_Eqt> bl600Result = Whitebox.invokeMethod(_processInstance, "PE0170_BL600_VerifierFonctionnelSwapRacco", _tracabilite, swapEqt, idCmdRaccoEnCours_p); //$NON-NLS-1$
    PowerMock.verify();

    //Asserts
    Retour retourKO2 = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.SN_INVALIDE, MessageFormat.format(MESSAGE_BAD_FORMAT_ERROR, swapEqt.getEquipementCible().getNoIdentifiant(), swapEqt.getInfosService().getTypeEquipement().name()));
    assertEquals(retourKO2, bl600Result._first);
    Assert.assertNull(bl600Result._second);
  }

  /**
   * <b>Scenario:</b> Tests no nominal case. BL102 KO<br>
   * <b>Input:</b><br>
   * <b>Result:</b> Retour KO
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_BL600_VerifierFonctionnelSwapRacco_Test_KO_06() throws Throwable
  {
    String idCmdRaccoEnCours_p = "11111"; //$NON-NLS-1$
    SwapEqt swapEqt = buildValidSwapEqtRequest();

    Retour retourKO = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "some error"); //$NON-NLS-1$
    ConnectorResponse<Retour, List<Commande>> cmdListRetour = new ConnectorResponse<>(retourKO, null);

    Commande commande2 = new Commande();
    String idCmd = "12345"; //$NON-NLS-1$
    Retour retourOk = RetourFactoryForTU.createOkRetour();
    commande2.setIdCmd(idCmd);
    commande2.setIdExterne("3948"); //$NON-NLS-1$
    commande2.setNatureCommande("SWAP_EQT"); //$NON-NLS-1$
    ArrayList<Commande> listCommande = new ArrayList<>();
    listCommande.add(commande2);
    ConnectorResponse<Retour, List<Commande>> cmdListRetour2 = new ConnectorResponse<>(retourOk, listCommande);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(true, false, false, false, 120);

    ProcessManager.getInstance().getProcessParams().clear();
    ProcessManager.getInstance().getProcessParams().putAll(processParams);

    //lireTousParStatutEtPFI EN Cours
    EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdProxyMock);
    EasyMock.expect(_cmdProxyMock.commandeLireTousParStatutEtPFI(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("Client operateur"), EasyMock.eq(swapEqt.getPortefeuilleServices().getNoCompte()), EasyMock.eq(Statut.EN_COURS.name()))).andReturn(cmdListRetour); //$NON-NLS-1$

    //lireTousParStatutEtPFI Echec
    EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdProxyMock);
    EasyMock.expect(_cmdProxyMock.commandeLireTousParStatutEtPFI(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("Client operateur"), EasyMock.eq(swapEqt.getPortefeuilleServices().getNoCompte()), EasyMock.eq(Statut.ECHEC.name()))).andReturn(cmdListRetour2); //$NON-NLS-1$

    PowerMock.replayAll();

    // Load Process Config
    Whitebox.invokeMethod(_processInstance, "loadProcessParameters"); //$NON-NLS-1$

    //Call PE0170_BL600
    Pair<Retour, PE0170_Eqt> bl600Result = Whitebox.invokeMethod(_processInstance, "PE0170_BL600_VerifierFonctionnelSwapRacco", _tracabilite, swapEqt, idCmdRaccoEnCours_p); //$NON-NLS-1$
    PowerMock.verify();

    //Asserts
    assertEquals(IMegConsts.CAT4, bl600Result._first.getCategorie());
    assertEquals(IMegSpiritConsts.EQUIPEMENT_INVALIDE, bl600Result._first.getDiagnostic());
    Assert.assertNull(bl600Result._second);
  }

  /**
   * <b>Scenario:</b> Tests no nominal case. S013 KO<br>
   * <b>Input:</b><br>
   * <b>Result:</b> Retour KO
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_BL600_VerifierFonctionnelSwapRacco_Test_KO_07() throws Throwable
  {

    String idCmdRaccoEnCours_p = "11111"; //$NON-NLS-1$
    SwapEqt swapEqt = buildValidSwapEqtRequest();

    Commande commande2 = new Commande();
    String idCmd = "12345"; //$NON-NLS-1$
    Retour retourOk = RetourFactoryForTU.createOkRetour();
    commande2.setIdCmd(idCmd);
    ArrayList<Commande> listCommande = new ArrayList<>();
    listCommande.add(commande2);
    ConnectorResponse<Retour, List<Commande>> cmdListRetour = new ConnectorResponse<>(retourOk, listCommande);
    Retour retourKO13 = RetourFactoryForTU.createNOK(IMegConsts.CAT4, "KO 13", "KO 13"); //$NON-NLS-1$ //$NON-NLS-2$

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(true, true, true, true, 120);

    ProcessManager.getInstance().getProcessParams().clear();
    ProcessManager.getInstance().getProcessParams().putAll(processParams);

    //lireTousParStatutEtPFI EN Cours
    EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdProxyMock);
    EasyMock.expect(_cmdProxyMock.commandeLireTousParStatutEtPFI(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("Client operateur"), EasyMock.eq(swapEqt.getPortefeuilleServices().getNoCompte()), EasyMock.eq(Statut.EN_COURS.name()))).andReturn(cmdListRetour); //$NON-NLS-1$

    PowerMock.expectNew(OSSFAI_SI013_RecupererIdCmdEquipementBuilder.class).andReturn(_si013BuilderMock);
    EasyMock.expect(_si013BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_si013BuilderMock);
    EasyMock.expect(_si013BuilderMock.systemeTechnique(SystemeTechnique.OSS_SERVICES)).andReturn(_si013BuilderMock);
    EasyMock.expect(_si013BuilderMock.idCommande(11111L)).andReturn(_si013BuilderMock);
    EasyMock.expect(_si013BuilderMock.build()).andReturn(_si013Mock);
    EasyMock.expect(_si013Mock.execute(_processInstance)).andReturn(null);
    EasyMock.expect(_si013Mock.getRetour()).andReturn(retourKO13).anyTimes();

    PowerMock.replayAll();
    //Call PE0170_BL600
    Pair<Retour, PE0170_Eqt> bl600Result = Whitebox.invokeMethod(_processInstance, "PE0170_BL600_VerifierFonctionnelSwapRacco", _tracabilite, swapEqt, idCmdRaccoEnCours_p); //$NON-NLS-1$
    PowerMock.verify();

    //Asserts
    assertEquals(retourKO13, bl600Result._first);
    Assert.assertNull(bl600Result._second);
  }

  /**
   * <b>Scenario:</b> Tests no nominal case. S014 KO<br>
   * <b>Input:</b><br>
   * <b>Result:</b> Retour KO
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_BL600_VerifierFonctionnelSwapRacco_Test_KO_08() throws Throwable
  {

    String idCmdRaccoEnCours_p = "11111"; //$NON-NLS-1$
    SwapEqt swapEqt = buildValidSwapEqtRequest();

    //Build objects
    String idCmd = "12345"; //$NON-NLS-1$
    Retour retourOk = RetourFactoryForTU.createOkRetour();
    ContexteCommandeOss si013Reponse = new ContexteCommandeOss();
    com.bytel.spirit.common.generated.ws.equipement.CommandeEquipement si014Reponse = new com.bytel.spirit.common.generated.ws.equipement.CommandeEquipement();

    CommandeEquipement cmdEquipement = new CommandeEquipement();
    cmdEquipement.setId(6789L);
    CommandeONT commandeOnt = __podam.manufacturePojoWithFullData(CommandeONT.class);
    commandeOnt.setManufacturer(Manufacturer.HUAWEI);
    CreationOss creationOss = new CreationOss();
    creationOss.getOnts().add(commandeOnt);

    Retour retourKO14 = RetourFactoryForTU.createNOK(IMegConsts.CAT4, "KO 14", "KO 14"); //$NON-NLS-1$ //$NON-NLS-2$

    Commande commande2 = new Commande();
    commande2.setIdCmd(idCmd);
    ArrayList<Commande> listCommande = new ArrayList<>();
    listCommande.add(commande2);
    ConnectorResponse<Retour, List<Commande>> cmdListRetour = new ConnectorResponse<>(retourOk, listCommande);

    si013Reponse.setCommandeEquipement(cmdEquipement);
    si014Reponse.setCreation(creationOss);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(true, true, true, true, 120);

    ProcessManager.getInstance().getProcessParams().clear();
    ProcessManager.getInstance().getProcessParams().putAll(processParams);

    //lireTousParStatutEtPFI EN Cours
    EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdProxyMock);
    EasyMock.expect(_cmdProxyMock.commandeLireTousParStatutEtPFI(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("Client operateur"), EasyMock.eq(swapEqt.getPortefeuilleServices().getNoCompte()), EasyMock.eq(Statut.EN_COURS.name()))).andReturn(cmdListRetour); //$NON-NLS-1$

    PowerMock.expectNew(OSSFAI_SI013_RecupererIdCmdEquipementBuilder.class).andReturn(_si013BuilderMock);
    EasyMock.expect(_si013BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_si013BuilderMock);
    EasyMock.expect(_si013BuilderMock.systemeTechnique(SystemeTechnique.OSS_SERVICES)).andReturn(_si013BuilderMock);
    EasyMock.expect(_si013BuilderMock.idCommande(11111L)).andReturn(_si013BuilderMock);
    EasyMock.expect(_si013BuilderMock.build()).andReturn(_si013Mock);
    EasyMock.expect(_si013Mock.execute(_processInstance)).andReturn(si013Reponse);
    EasyMock.expect(_si013Mock.getRetour()).andReturn(retourOk);

    PowerMock.expectNew(OSSFAI_SI014_RecupererListeEquipementParCommandeEtParTypeBuilder.class).andReturn(_si014BuilderMock);
    EasyMock.expect(_si014BuilderMock.idCommandeEquipement(6789L)).andReturn(_si014BuilderMock);
    EasyMock.expect(_si014BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_si014BuilderMock);
    EasyMock.expect(_si014BuilderMock.build()).andReturn(_si014Mock);
    EasyMock.expect(_si014Mock.execute(_processInstance)).andReturn(null);
    EasyMock.expect(_si014Mock.getRetour()).andReturn(retourKO14).anyTimes();

    PowerMock.replayAll();
    //Call PE0170_BL600
    Pair<Retour, PE0170_Eqt> bl600Result = Whitebox.invokeMethod(_processInstance, "PE0170_BL600_VerifierFonctionnelSwapRacco", _tracabilite, swapEqt, idCmdRaccoEnCours_p); //$NON-NLS-1$
    PowerMock.verify();

    //Asserts
    assertEquals(retourKO14, bl600Result._first);
    Assert.assertNull(bl600Result._second);
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. oSwapEqt.InfosService.typeEquipement not expected<br>
   * <b>Input:</b><br>
   * <b>Result:</b> Retour KO
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_BL600_VerifierFonctionnelSwapRacco_Test_KO_09() throws Throwable
  {

    String idCmdRaccoEnCours_p = "11111"; //$NON-NLS-1$
    SwapEqt swapEqt = buildValidSwapEqtRequest();
    swapEqt.getInfosService().setTypeEquipement(null);

    //Build objects
    String idCmd = "12345"; //$NON-NLS-1$
    Retour retourOk = RetourFactoryForTU.createOkRetour();
    ContexteCommandeOss si013Reponse = new ContexteCommandeOss();
    com.bytel.spirit.common.generated.ws.equipement.CommandeEquipement si014Reponse = new com.bytel.spirit.common.generated.ws.equipement.CommandeEquipement();

    CommandeEquipement cmdEquipement = new CommandeEquipement();
    cmdEquipement.setId(6789L);
    CommandeONT commandeOnt = __podam.manufacturePojoWithFullData(CommandeONT.class);
    commandeOnt.setManufacturer(Manufacturer.HUAWEI);
    CreationOss creationOss = new CreationOss();
    creationOss.getOnts().add(commandeOnt);

    Commande commande2 = new Commande();
    commande2.setIdCmd(idCmd);
    ArrayList<Commande> listCommande = new ArrayList<>();
    listCommande.add(commande2);
    ConnectorResponse<Retour, List<Commande>> cmdListRetour = new ConnectorResponse<>(retourOk, listCommande);

    si013Reponse.setCommandeEquipement(cmdEquipement);
    si014Reponse.setCreation(creationOss);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(true, true, true, true, 120);

    ProcessManager.getInstance().getProcessParams().clear();
    ProcessManager.getInstance().getProcessParams().putAll(processParams);

    //BL600
    EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdProxyMock);
    EasyMock.expect(_cmdProxyMock.commandeLireTousParStatutEtPFI(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("Client operateur"), EasyMock.eq(swapEqt.getPortefeuilleServices().getNoCompte()), EasyMock.eq(Statut.EN_COURS.name()))).andReturn(cmdListRetour); //$NON-NLS-1$

    PowerMock.expectNew(OSSFAI_SI013_RecupererIdCmdEquipementBuilder.class).andReturn(_si013BuilderMock);
    EasyMock.expect(_si013BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_si013BuilderMock);
    EasyMock.expect(_si013BuilderMock.systemeTechnique(SystemeTechnique.OSS_SERVICES)).andReturn(_si013BuilderMock);
    EasyMock.expect(_si013BuilderMock.idCommande(11111L)).andReturn(_si013BuilderMock);
    EasyMock.expect(_si013BuilderMock.build()).andReturn(_si013Mock);
    EasyMock.expect(_si013Mock.execute(_processInstance)).andReturn(si013Reponse);
    EasyMock.expect(_si013Mock.getRetour()).andReturn(retourOk);

    PowerMock.expectNew(OSSFAI_SI014_RecupererListeEquipementParCommandeEtParTypeBuilder.class).andReturn(_si014BuilderMock);
    EasyMock.expect(_si014BuilderMock.idCommandeEquipement(6789L)).andReturn(_si014BuilderMock);
    EasyMock.expect(_si014BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_si014BuilderMock);
    EasyMock.expect(_si014BuilderMock.build()).andReturn(_si014Mock);
    EasyMock.expect(_si014Mock.execute(_processInstance)).andReturn(si014Reponse);
    EasyMock.expect(_si014Mock.getRetour()).andReturn(retourOk);

    PowerMock.replayAll();
    //Call PE0170_BL600
    Pair<Retour, PE0170_Eqt> bl600Result = Whitebox.invokeMethod(_processInstance, "PE0170_BL600_VerifierFonctionnelSwapRacco", _tracabilite, swapEqt, idCmdRaccoEnCours_p); //$NON-NLS-1$
    PowerMock.verify();

    //Asserts
    assertEquals(IMegConsts.CAT10, bl600Result._first.getCategorie());
    assertEquals(IMegSpiritConsts.TRAITEMENT_ARRETE, bl600Result._first.getDiagnostic());
    Assert.assertNull(bl600Result._second);
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. Equip inconnu<br>
   * <b>Input:</b><br>
   * <b>Result:</b> Retour KO
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_BL600_VerifierFonctionnelSwapRacco_Test_KO_10() throws Throwable
  {

    String idCmdRaccoEnCours_p = "11111"; //$NON-NLS-1$
    SwapEqt swapEqt = buildValidSwapEqtRequest();
    swapEqt.getInfosService().setTypeEquipement(TypeEquipement.DECODEUR_TV);

    //Build objects
    String idCmd = "12345"; //$NON-NLS-1$
    Retour retourOk = RetourFactoryForTU.createOkRetour();
    ContexteCommandeOss si013Reponse = new ContexteCommandeOss();
    com.bytel.spirit.common.generated.ws.equipement.CommandeEquipement si014Reponse = new com.bytel.spirit.common.generated.ws.equipement.CommandeEquipement();

    CommandeEquipement cmdEquipement = new CommandeEquipement();
    cmdEquipement.setId(6789L);
    CommandeSTB commandeStb = __podam.manufacturePojoWithFullData(CommandeSTB.class);
    commandeStb.setManufacturer(Manufacturer.HUAWEI);

    CommandeSTB commandeStb2 = __podam.manufacturePojoWithFullData(CommandeSTB.class);
    commandeStb2.setManufacturer(Manufacturer.HUAWEI);

    CreationOss creationOss = new CreationOss();
    creationOss.getStbs().add(commandeStb);
    creationOss.getStbs().add(commandeStb2);

    Commande commande2 = new Commande();
    commande2.setIdCmd(idCmd);
    ArrayList<Commande> listCommande = new ArrayList<>();
    listCommande.add(commande2);
    ConnectorResponse<Retour, List<Commande>> cmdListRetour = new ConnectorResponse<>(retourOk, listCommande);

    si013Reponse.setCommandeEquipement(cmdEquipement);
    si014Reponse.setCreation(creationOss);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(true, true, true, true, 120);

    ProcessManager.getInstance().getProcessParams().clear();
    ProcessManager.getInstance().getProcessParams().putAll(processParams);

    //BL600
    EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdProxyMock);
    EasyMock.expect(_cmdProxyMock.commandeLireTousParStatutEtPFI(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("Client operateur"), EasyMock.eq(swapEqt.getPortefeuilleServices().getNoCompte()), EasyMock.eq(Statut.EN_COURS.name()))).andReturn(cmdListRetour); //$NON-NLS-1$

    PowerMock.expectNew(OSSFAI_SI013_RecupererIdCmdEquipementBuilder.class).andReturn(_si013BuilderMock);
    EasyMock.expect(_si013BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_si013BuilderMock);
    EasyMock.expect(_si013BuilderMock.systemeTechnique(SystemeTechnique.OSS_SERVICES)).andReturn(_si013BuilderMock);
    EasyMock.expect(_si013BuilderMock.idCommande(11111L)).andReturn(_si013BuilderMock);
    EasyMock.expect(_si013BuilderMock.build()).andReturn(_si013Mock);
    EasyMock.expect(_si013Mock.execute(_processInstance)).andReturn(si013Reponse);
    EasyMock.expect(_si013Mock.getRetour()).andReturn(retourOk);

    PowerMock.expectNew(OSSFAI_SI014_RecupererListeEquipementParCommandeEtParTypeBuilder.class).andReturn(_si014BuilderMock);
    EasyMock.expect(_si014BuilderMock.idCommandeEquipement(6789L)).andReturn(_si014BuilderMock);
    EasyMock.expect(_si014BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_si014BuilderMock);
    EasyMock.expect(_si014BuilderMock.build()).andReturn(_si014Mock);
    EasyMock.expect(_si014Mock.execute(_processInstance)).andReturn(si014Reponse);
    EasyMock.expect(_si014Mock.getRetour()).andReturn(retourOk);

    PowerMock.replayAll();
    //Call PE0170_BL600
    Pair<Retour, PE0170_Eqt> bl600Result = Whitebox.invokeMethod(_processInstance, "PE0170_BL600_VerifierFonctionnelSwapRacco", _tracabilite, swapEqt, idCmdRaccoEnCours_p); //$NON-NLS-1$
    PowerMock.verify();

    //Asserts
    assertEquals(IMegConsts.CAT4, bl600Result._first.getCategorie());
    assertEquals(IMegSpiritConsts.EQUIPEMENT_INCONNU, bl600Result._first.getDiagnostic());
    Assert.assertNull(bl600Result._second);
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. No equipements from OSS<br>
   * <b>Input:</b><br>
   * <b>Result:</b> Retour KO
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_BL600_VerifierFonctionnelSwapRacco_Test_KO_11() throws Throwable
  {

    String idCmdRaccoEnCours_p = "11111"; //$NON-NLS-1$
    SwapEqt swapEqt = buildValidSwapEqtRequest();
    swapEqt.getInfosService().setTypeEquipement(TypeEquipement.DECODEUR_TV);

    //Build objects
    String idCmd = "12345"; //$NON-NLS-1$
    Retour retourOk = RetourFactoryForTU.createOkRetour();
    ContexteCommandeOss si013Reponse = new ContexteCommandeOss();
    com.bytel.spirit.common.generated.ws.equipement.CommandeEquipement si014Reponse = new com.bytel.spirit.common.generated.ws.equipement.CommandeEquipement();

    CommandeEquipement cmdEquipement = new CommandeEquipement();
    cmdEquipement.setId(6789L);

    CreationOss creationOss = new CreationOss();

    Commande commande2 = new Commande();
    commande2.setIdCmd(idCmd);
    ArrayList<Commande> listCommande = new ArrayList<>();
    listCommande.add(commande2);
    ConnectorResponse<Retour, List<Commande>> cmdListRetour = new ConnectorResponse<>(retourOk, listCommande);

    si013Reponse.setCommandeEquipement(cmdEquipement);
    si014Reponse.setCreation(creationOss);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(true, true, true, true, 120);

    ProcessManager.getInstance().getProcessParams().clear();
    ProcessManager.getInstance().getProcessParams().putAll(processParams);

    //BL600
    EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdProxyMock);
    EasyMock.expect(_cmdProxyMock.commandeLireTousParStatutEtPFI(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("Client operateur"), EasyMock.eq(swapEqt.getPortefeuilleServices().getNoCompte()), EasyMock.eq(Statut.EN_COURS.name()))).andReturn(cmdListRetour); //$NON-NLS-1$

    PowerMock.expectNew(OSSFAI_SI013_RecupererIdCmdEquipementBuilder.class).andReturn(_si013BuilderMock);
    EasyMock.expect(_si013BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_si013BuilderMock);
    EasyMock.expect(_si013BuilderMock.systemeTechnique(SystemeTechnique.OSS_SERVICES)).andReturn(_si013BuilderMock);
    EasyMock.expect(_si013BuilderMock.idCommande(11111L)).andReturn(_si013BuilderMock);
    EasyMock.expect(_si013BuilderMock.build()).andReturn(_si013Mock);
    EasyMock.expect(_si013Mock.execute(_processInstance)).andReturn(si013Reponse);
    EasyMock.expect(_si013Mock.getRetour()).andReturn(retourOk);

    PowerMock.expectNew(OSSFAI_SI014_RecupererListeEquipementParCommandeEtParTypeBuilder.class).andReturn(_si014BuilderMock);
    EasyMock.expect(_si014BuilderMock.idCommandeEquipement(6789L)).andReturn(_si014BuilderMock);
    EasyMock.expect(_si014BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_si014BuilderMock);
    EasyMock.expect(_si014BuilderMock.build()).andReturn(_si014Mock);
    EasyMock.expect(_si014Mock.execute(_processInstance)).andReturn(si014Reponse);
    EasyMock.expect(_si014Mock.getRetour()).andReturn(retourOk);

    PowerMock.replayAll();
    //Call PE0170_BL600
    Pair<Retour, PE0170_Eqt> bl600Result = Whitebox.invokeMethod(_processInstance, "PE0170_BL600_VerifierFonctionnelSwapRacco", _tracabilite, swapEqt, idCmdRaccoEnCours_p); //$NON-NLS-1$
    PowerMock.verify();

    //Asserts
    assertEquals(IMegConsts.CAT6, bl600Result._first.getCategorie());
    assertEquals(IMegSpiritConsts.DONNEE_NON_DISPONIBLE, bl600Result._first.getDiagnostic());
    Assert.assertNull(bl600Result._second);
  }

  /**
   * <b>Scenario:</b> Tests nominal case.<br>
   * <b>Input:</b><br>
   * <b>Result:</b> Retour OK
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_BL600_VerifierFonctionnelSwapRacco_Test_OK_01() throws Throwable
  {

    String idCmdRaccoEnCours_p = "11111"; //$NON-NLS-1$
    SwapEqt swapEqt = buildValidSwapEqtRequest();

    //Build objects
    String idCmd = "12345"; //$NON-NLS-1$
    Retour retourOk = RetourFactoryForTU.createOkRetour();
    ContexteCommandeOss si013Reponse = new ContexteCommandeOss();
    com.bytel.spirit.common.generated.ws.equipement.CommandeEquipement si014Reponse = new com.bytel.spirit.common.generated.ws.equipement.CommandeEquipement();

    CommandeEquipement cmdEquipement = new CommandeEquipement();
    cmdEquipement.setId(6789L);
    CommandeONT commandeOnt = __podam.manufacturePojoWithFullData(CommandeONT.class);
    commandeOnt.setManufacturer(Manufacturer.HUAWEI);
    CreationOss creationOss = new CreationOss();
    creationOss.getOnts().add(commandeOnt);

    Commande commande2 = new Commande();
    commande2.setIdCmd(idCmd);
    ArrayList<Commande> listCommande = new ArrayList<>();
    listCommande.add(commande2);
    ConnectorResponse<Retour, List<Commande>> cmdListRetour = new ConnectorResponse<>(retourOk, listCommande);

    si013Reponse.setCommandeEquipement(cmdEquipement);
    si014Reponse.setCreation(creationOss);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(true, true, true, true, 120);

    ProcessManager.getInstance().getProcessParams().clear();
    ProcessManager.getInstance().getProcessParams().putAll(processParams);

    //BL600
    EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdProxyMock);
    EasyMock.expect(_cmdProxyMock.commandeLireTousParStatutEtPFI(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("Client operateur"), EasyMock.eq(swapEqt.getPortefeuilleServices().getNoCompte()), EasyMock.eq(Statut.EN_COURS.name()))).andReturn(cmdListRetour); //$NON-NLS-1$

    PowerMock.expectNew(OSSFAI_SI013_RecupererIdCmdEquipementBuilder.class).andReturn(_si013BuilderMock);
    EasyMock.expect(_si013BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_si013BuilderMock);
    EasyMock.expect(_si013BuilderMock.systemeTechnique(SystemeTechnique.OSS_SERVICES)).andReturn(_si013BuilderMock);
    EasyMock.expect(_si013BuilderMock.idCommande(11111L)).andReturn(_si013BuilderMock);
    EasyMock.expect(_si013BuilderMock.build()).andReturn(_si013Mock);
    EasyMock.expect(_si013Mock.execute(_processInstance)).andReturn(si013Reponse);
    EasyMock.expect(_si013Mock.getRetour()).andReturn(retourOk);

    PowerMock.expectNew(OSSFAI_SI014_RecupererListeEquipementParCommandeEtParTypeBuilder.class).andReturn(_si014BuilderMock);
    EasyMock.expect(_si014BuilderMock.idCommandeEquipement(6789L)).andReturn(_si014BuilderMock);
    EasyMock.expect(_si014BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_si014BuilderMock);
    EasyMock.expect(_si014BuilderMock.build()).andReturn(_si014Mock);
    EasyMock.expect(_si014Mock.execute(_processInstance)).andReturn(si014Reponse);
    EasyMock.expect(_si014Mock.getRetour()).andReturn(retourOk);

    PowerMock.replayAll();
    //Call PE0170_BL600
    Pair<Retour, PE0170_Eqt> bl600Result = Whitebox.invokeMethod(_processInstance, "PE0170_BL600_VerifierFonctionnelSwapRacco", _tracabilite, swapEqt, idCmdRaccoEnCours_p); //$NON-NLS-1$
    PowerMock.verify();

    //Asserts
    assertEquals(retourOk, bl600Result._first);
    Assert.assertNotNull(bl600Result._second);
  }

  /**
   * <b>Scenario:</b> Tests nominal case. Multiple equips from oss<br>
   * <b>Input:</b><br>
   * <b>Result:</b> Retour OK
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */

  @Test
  public void PE0170_BL600_VerifierFonctionnelSwapRacco_Test_OK_02() throws Throwable
  {

    String idCmdRaccoEnCours_p = "11111"; //$NON-NLS-1$
    SwapEqt swapEqt = buildValidSwapEqtRequest();
    swapEqt.getInfosService().setTypeEquipement(TypeEquipement.DECODEUR_TV);

    //Build objects
    String idCmd = "12345"; //$NON-NLS-1$
    Retour retourOk = RetourFactoryForTU.createOkRetour();
    ContexteCommandeOss si013Reponse = new ContexteCommandeOss();
    com.bytel.spirit.common.generated.ws.equipement.CommandeEquipement si014Reponse = new com.bytel.spirit.common.generated.ws.equipement.CommandeEquipement();

    CommandeEquipement cmdEquipement = new CommandeEquipement();
    cmdEquipement.setId(6789L);
    CommandeSTB commandeStb = __podam.manufacturePojoWithFullData(CommandeSTB.class);
    commandeStb.setManufacturer(Manufacturer.HUAWEI);
    commandeStb.setSerialNumber("9876"); //$NON-NLS-1$);

    CommandeSTB commandeStb2 = __podam.manufacturePojoWithFullData(CommandeSTB.class);
    commandeStb2.setManufacturer(Manufacturer.HUAWEI);

    CreationOss creationOss = new CreationOss();
    creationOss.getStbs().add(commandeStb);
    creationOss.getStbs().add(commandeStb2);

    Commande commande2 = new Commande();
    commande2.setIdCmd(idCmd);
    ArrayList<Commande> listCommande = new ArrayList<>();
    listCommande.add(commande2);
    ConnectorResponse<Retour, List<Commande>> cmdListRetour = new ConnectorResponse<>(retourOk, listCommande);

    si013Reponse.setCommandeEquipement(cmdEquipement);
    si014Reponse.setCreation(creationOss);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(true, true, true, true, 120);

    ProcessManager.getInstance().getProcessParams().clear();
    ProcessManager.getInstance().getProcessParams().putAll(processParams);

    //BL600
    EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdProxyMock);
    EasyMock.expect(_cmdProxyMock.commandeLireTousParStatutEtPFI(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("Client operateur"), EasyMock.eq(swapEqt.getPortefeuilleServices().getNoCompte()), EasyMock.eq(Statut.EN_COURS.name()))).andReturn(cmdListRetour); //$NON-NLS-1$

    PowerMock.expectNew(OSSFAI_SI013_RecupererIdCmdEquipementBuilder.class).andReturn(_si013BuilderMock);
    EasyMock.expect(_si013BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_si013BuilderMock);
    EasyMock.expect(_si013BuilderMock.systemeTechnique(SystemeTechnique.OSS_SERVICES)).andReturn(_si013BuilderMock);
    EasyMock.expect(_si013BuilderMock.idCommande(11111L)).andReturn(_si013BuilderMock);
    EasyMock.expect(_si013BuilderMock.build()).andReturn(_si013Mock);
    EasyMock.expect(_si013Mock.execute(_processInstance)).andReturn(si013Reponse);
    EasyMock.expect(_si013Mock.getRetour()).andReturn(retourOk);

    PowerMock.expectNew(OSSFAI_SI014_RecupererListeEquipementParCommandeEtParTypeBuilder.class).andReturn(_si014BuilderMock);
    EasyMock.expect(_si014BuilderMock.idCommandeEquipement(6789L)).andReturn(_si014BuilderMock);
    EasyMock.expect(_si014BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_si014BuilderMock);
    EasyMock.expect(_si014BuilderMock.build()).andReturn(_si014Mock);
    EasyMock.expect(_si014Mock.execute(_processInstance)).andReturn(si014Reponse);
    EasyMock.expect(_si014Mock.getRetour()).andReturn(retourOk);

    PowerMock.replayAll();
    //Call PE0170_BL600
    Pair<Retour, PE0170_Eqt> bl600Result = Whitebox.invokeMethod(_processInstance, "PE0170_BL600_VerifierFonctionnelSwapRacco", _tracabilite, swapEqt, idCmdRaccoEnCours_p); //$NON-NLS-1$
    PowerMock.verify();

    //Asserts
    assertEquals(retourOk, bl600Result._first);
    Assert.assertNotNull(bl600Result._second);
  }

  /**
   * <b>Scenario:</b> Tests nominal case. Multiple equips from oss<br>
   * <b>Input:</b><br>
   * <b>Result:</b> Retour OK
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */

  @Test
  public void PE0170_BL600_VerifierFonctionnelSwapRacco_Test_OK_03() throws Throwable
  {

    String idCmdRaccoEnCours_p = "11111"; //$NON-NLS-1$
    SwapEqt swapEqt = buildValidSwapEqtRequest();
    swapEqt.getInfosService().setTypeEquipement(TypeEquipement.DECODEUR_TV);

    //Build objects
    String idCmd = "12345"; //$NON-NLS-1$
    Retour retourOk = RetourFactoryForTU.createOkRetour();
    ContexteCommandeOss si013Reponse = new ContexteCommandeOss();
    com.bytel.spirit.common.generated.ws.equipement.CommandeEquipement si014Reponse = new com.bytel.spirit.common.generated.ws.equipement.CommandeEquipement();

    CommandeEquipement cmdEquipement = new CommandeEquipement();
    cmdEquipement.setId(6789L);
    CommandeSTB commandeStb = __podam.manufacturePojoWithFullData(CommandeSTB.class);
    commandeStb.setManufacturer(Manufacturer.HUAWEI);
    commandeStb.setSequenceEquipment("4532"); //$NON-NLS-1$

    CommandeSTB commandeStb2 = __podam.manufacturePojoWithFullData(CommandeSTB.class);
    commandeStb2.setManufacturer(Manufacturer.HUAWEI);

    CreationOss creationOss = new CreationOss();
    creationOss.getStbs().add(commandeStb);
    creationOss.getStbs().add(commandeStb2);

    Commande commande2 = new Commande();
    commande2.setIdCmd(idCmd);
    ArrayList<Commande> listCommande = new ArrayList<>();
    listCommande.add(commande2);
    ConnectorResponse<Retour, List<Commande>> cmdListRetour = new ConnectorResponse<>(retourOk, listCommande);

    si013Reponse.setCommandeEquipement(cmdEquipement);
    si014Reponse.setCreation(creationOss);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(true, true, true, true, 120);

    ProcessManager.getInstance().getProcessParams().clear();
    ProcessManager.getInstance().getProcessParams().putAll(processParams);

    //BL600
    EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdProxyMock);
    EasyMock.expect(_cmdProxyMock.commandeLireTousParStatutEtPFI(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("Client operateur"), EasyMock.eq(swapEqt.getPortefeuilleServices().getNoCompte()), EasyMock.eq(Statut.EN_COURS.name()))).andReturn(cmdListRetour); //$NON-NLS-1$

    PowerMock.expectNew(OSSFAI_SI013_RecupererIdCmdEquipementBuilder.class).andReturn(_si013BuilderMock);
    EasyMock.expect(_si013BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_si013BuilderMock);
    EasyMock.expect(_si013BuilderMock.systemeTechnique(SystemeTechnique.OSS_SERVICES)).andReturn(_si013BuilderMock);
    EasyMock.expect(_si013BuilderMock.idCommande(11111L)).andReturn(_si013BuilderMock);
    EasyMock.expect(_si013BuilderMock.build()).andReturn(_si013Mock);
    EasyMock.expect(_si013Mock.execute(_processInstance)).andReturn(si013Reponse);
    EasyMock.expect(_si013Mock.getRetour()).andReturn(retourOk);

    PowerMock.expectNew(OSSFAI_SI014_RecupererListeEquipementParCommandeEtParTypeBuilder.class).andReturn(_si014BuilderMock);
    EasyMock.expect(_si014BuilderMock.idCommandeEquipement(6789L)).andReturn(_si014BuilderMock);
    EasyMock.expect(_si014BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_si014BuilderMock);
    EasyMock.expect(_si014BuilderMock.build()).andReturn(_si014Mock);
    EasyMock.expect(_si014Mock.execute(_processInstance)).andReturn(si014Reponse);
    EasyMock.expect(_si014Mock.getRetour()).andReturn(retourOk);

    PowerMock.replayAll();
    //Call PE0170_BL600
    Pair<Retour, PE0170_Eqt> bl600Result = Whitebox.invokeMethod(_processInstance, "PE0170_BL600_VerifierFonctionnelSwapRacco", _tracabilite, swapEqt, idCmdRaccoEnCours_p); //$NON-NLS-1$
    PowerMock.verify();

    //Asserts
    assertEquals(retourOk, bl600Result._first);
    Assert.assertNotNull(bl600Result._second);
  }

  /**
   * <b>Scenario:</b> Test non nominal case.<br>
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_BL700_VerifierFonctionnelSwapSav_Test_KO() throws Exception
  {

    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.RACCO_INCONNU, "Pas de raccordement en cours de construction"); //$NON-NLS-1$
    Retour reponseBL700 = Whitebox.invokeMethod(_processInstance, "PE0170_BL700_VerifierFonctionnelSwapSav", _tracabilite); //$NON-NLS-1$
    assertEquals(retourExpected, reponseBL700);

  }

  @Test
  public void PE0170_ConfigCoherenceEquipementTest() throws Exception
  {
    // Setup process parameters
    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(true, true, true, true, 120);

    // Process Manager Mock
    ProcessManager.getInstance().getProcessParams().clear();
    ProcessManager.getInstance().getProcessParams().putAll(processParams);

    PowerMock.replayAll();

    _processInstance = new PE0170_SwapEquipement();
    _processInstance.initializeContext();

    // Call methode
    Whitebox.invokeMethod(_processInstance, "loadProcessParameters"); //$NON-NLS-1$

    // Get result
    PE0170_ConfigCoherenceEquipement pe0170ConfigCoherenceEquipement = (PE0170_ConfigCoherenceEquipement) JUnitTools.getInaccessibleFieldValue(_processInstance, "_pe0170ConfigCoherenceEquipement"); //$NON-NLS-1$
    ConfigCoherenceEquipement configCoherenceEquipement = pe0170ConfigCoherenceEquipement.getConfigCoherenceEquipement();

    // Assertions
    Assert.assertEquals(TypeAcces.FTTH.name(), configCoherenceEquipement.getCoherenceEquipements().get(0).getTypeAcces());
    Assert.assertEquals(TypeEquipement.MODEM.name(), configCoherenceEquipement.getCoherenceEquipements().get(0).getTypeEquipement());
    Assert.assertEquals("Sagem", configCoherenceEquipement.getCoherenceEquipements().get(0).getFabriquant()); //$NON-NLS-1$
    Assert.assertEquals("3784f", configCoherenceEquipement.getCoherenceEquipements().get(0).getModele()); //$NON-NLS-1$

    Assert.assertEquals(TypeAcces.FTTH.name(), configCoherenceEquipement.getCoherenceEquipements().get(1).getTypeAcces());
    Assert.assertEquals(TypeEquipement.MODEM.name(), configCoherenceEquipement.getCoherenceEquipements().get(1).getTypeEquipement());
    Assert.assertEquals("Sagem", configCoherenceEquipement.getCoherenceEquipements().get(1).getFabriquant()); //$NON-NLS-1$
    Assert.assertEquals("3784b", configCoherenceEquipement.getCoherenceEquipements().get(1).getModele()); //$NON-NLS-1$

    Assert.assertEquals(TypeAcces.FTTH.name(), configCoherenceEquipement.getCoherenceEquipements().get(5).getTypeAcces());
    Assert.assertEquals(TypeEquipement.MODEM.name(), configCoherenceEquipement.getCoherenceEquipements().get(5).getTypeEquipement());
    Assert.assertEquals("UBEE", configCoherenceEquipement.getCoherenceEquipements().get(5).getFabriquant()); //$NON-NLS-1$
    Assert.assertEquals("TVW620.I", configCoherenceEquipement.getCoherenceEquipements().get(5).getModele()); //$NON-NLS-1$

    Assert.assertEquals(TypeAcces.FTTH.name(), configCoherenceEquipement.getCoherenceEquipements().get(9).getTypeAcces());
    Assert.assertEquals(TypeEquipement.DECODEUR_TV.name(), configCoherenceEquipement.getCoherenceEquipements().get(9).getTypeEquipement());
    Assert.assertEquals("ARCADYAN", configCoherenceEquipement.getCoherenceEquipements().get(9).getFabriquant()); //$NON-NLS-1$
    Assert.assertEquals("HMB4213H", configCoherenceEquipement.getCoherenceEquipements().get(9).getModele()); //$NON-NLS-1$

    Assert.assertEquals(TypeAcces.FTTH.name(), configCoherenceEquipement.getCoherenceEquipements().get(13).getTypeAcces());
    Assert.assertEquals(TypeEquipement.BRANCHEMENT_OPTIQUE.name(), configCoherenceEquipement.getCoherenceEquipements().get(13).getTypeEquipement());
    Assert.assertEquals("Huawei", configCoherenceEquipement.getCoherenceEquipements().get(13).getFabriquant()); //$NON-NLS-1$
    Assert.assertEquals("HG8010H", configCoherenceEquipement.getCoherenceEquipements().get(13).getModele()); //$NON-NLS-1$

    assertTrue(pe0170ConfigCoherenceEquipement.isCoherenceEquipement(TypeAcces.FTTH.name(), TypeEquipement.BRANCHEMENT_OPTIQUE.name(), "Huawei", "HG8010H")); //$NON-NLS-1$ //$NON-NLS-2$
    assertTrue(pe0170ConfigCoherenceEquipement.isNotCoherenceEquipement(TypeAcces.FTTH.name(), TypeEquipement.BRANCHEMENT_OPTIQUE.name(), "Huawei", "test")); //$NON-NLS-1$ //$NON-NLS-2$
  }

  /**
   * <b>Scenario:</b> Test non-nominal case for PE0170_SwapEquipement - continueProcess<br>
   * <b>Expected:</b> ProcessRetour: NOK<br>
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */

  @Test
  public void PE0170_SwapEquipement_continueProcess_Test_KO_01() throws Throwable
  {
    Exception e = new Exception("Exception in BL300"); //$NON-NLS-1$
    Retour retourNOK = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e.getMessage());
    SwapEqt swapEqt = buildValidSwapEqtRequest();
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    String jsonRequest = GsonTools.getGson(DateTimeTools.DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(swapEqt, SwapEqt.class);
    Map<String, String> donneesSpecifiques = new HashMap<>();
    donneesSpecifiques.put(ID_CMD_RACCO_EN_COURS, "12345"); //$NON-NLS-1$
    donneesSpecifiques.put(IDENTIFIANT_TECHNIQUE_EQT_A_LIBERER, "453827"); //$NON-NLS-1$

    String noSequence = "98765"; //$NON-NLS-1$
    String idCmd = "1c27c3ba-bd3a-462e-8e9e-cba6180f614d"; //$NON-NLS-1$

    Commande commande = new Commande();
    PE0170_Eqt pe170Eqt = new PE0170_Eqt();

    fillAllRequestHeaders(request);
    request.setContentType("application/json"); //$NON-NLS-1$
    request.setPayload(jsonRequest);
    commande.setIdCmd(idCmd);
    commande.setDonneesSpecifiques(GsonTools.getIso8601Ms().toJson(donneesSpecifiques));
    commande.setStatut("EN_COURS"); //$NON-NLS-1$
    pe170Eqt.setNoSequence(noSequence);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(true, true, true, true, 120);

    ProcessManager.getInstance().getProcessParams().clear();
    ProcessManager.getInstance().getProcessParams().putAll(processParams);

    //Setting processContext to prepare for continueProcess execution
    _processInstance.getProcessContext().setState(State.PE0170_BL300_LIBERER);
    _processInstance.getProcessContext().setNbVerif(0);
    _processInstance.getProcessContext().setNbVerifMax(5);
    _processInstance.getProcessContext().setCommande(commande);
    _processInstance.getProcessContext().setSwapEqt(swapEqt);
    _processInstance.getProcessContext().setEqtProvisionneALiberer(pe170Eqt);

    //BL300 (first call)
    createMockCmdLireUn(retourNOK, null);

    //BL005
    createMockBL4600ForBL500();

    PowerMock.replayAll();
    _processInstance.continueProcess(request, _tracabilite);
    PowerMock.verifyAll();

    Assert.assertEquals(retourNOK, _processInstance.getProcessContext().getProcessRetour());
    Assert.assertEquals(State.PE0170_END, _processInstance.getProcessContext().getState());
  }

  /**
   * <b>Scenario:</b> Test non-nominal case for PE0170_SwapEquipement - continueProcess<br>
   * <b>Expected:</b> ReponseErreur != null - ProcessRetour: NOK<br>
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */

  @Test
  public void PE0170_SwapEquipement_continueProcess_Test_KO_02() throws Throwable
  {
    Exception e = new Exception("startProcess returned ReponseErreur"); //$NON-NLS-1$
    Retour retourNOK = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e.getMessage());
    SwapEqt swapEqt = buildValidSwapEqtRequest();
    ReponseErreur reponseErreur = new ReponseErreur();
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    String jsonRequest = GsonTools.getGson(DateTimeTools.DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(swapEqt, SwapEqt.class);
    Map<String, String> donneesSpecifiques = new HashMap<>();
    donneesSpecifiques.put(ID_CMD_RACCO_EN_COURS, "12345"); //$NON-NLS-1$
    donneesSpecifiques.put(IDENTIFIANT_TECHNIQUE_EQT_A_LIBERER, "453827"); //$NON-NLS-1$

    String noSequence = "98765"; //$NON-NLS-1$
    String idCmd = "1c27c3ba-bd3a-462e-8e9e-cba6180f614d"; //$NON-NLS-1$
    Commande commande = new Commande();
    PE0170_Eqt pe170Eqt = new PE0170_Eqt();

    fillAllRequestHeaders(request);
    request.setContentType("application/json"); //$NON-NLS-1$
    request.setPayload(jsonRequest);
    commande.setIdCmd(idCmd);
    commande.setDonneesSpecifiques(GsonTools.getIso8601Ms().toJson(donneesSpecifiques));
    commande.setStatut("EN_COURS"); //$NON-NLS-1$
    pe170Eqt.setNoSequence(noSequence);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(true, true, true, true, 120);

    ProcessManager.getInstance().getProcessParams().clear();
    ProcessManager.getInstance().getProcessParams().putAll(processParams);

    //Setting processContext to prepare for continueProcess execution
    _processInstance.getProcessContext().setState(State.PE0170_BL300_LIBERER);
    _processInstance.getProcessContext().setNbVerif(0);
    _processInstance.getProcessContext().setNbVerifMax(5);
    _processInstance.getProcessContext().setCommande(commande);
    _processInstance.getProcessContext().setSwapEqt(swapEqt);
    _processInstance.getProcessContext().setEqtProvisionneALiberer(pe170Eqt);

    //Retour and ReponseErreur from startProcess
    _processInstance.getProcessContext().setReponseErreur(reponseErreur);
    _processInstance.getProcessContext().setProcessRetour(retourNOK);

    PowerMock.replayAll();
    _processInstance.continueProcess(request, _tracabilite);
    PowerMock.verifyAll();

    Assert.assertEquals(RetourFactoryForTU.createOkRetour(), _processInstance.getProcessContext().getProcessRetour()); // retour OK car rejet de la demande sans action exploitant (ni CAT6, CAT10 ou rollback)
    Assert.assertEquals(State.PE0170_END, _processInstance.getProcessContext().getState());
  }

  /**
   * <b>Scenario:</b> Test non-nominal case for PE0170_SwapEquipement - continueProcess.<br>
   * b>Expected:</b> BL400 returns NOK<br>
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */

  @Test
  public void PE0170_SwapEquipement_continueProcess_Test_KO_03() throws Throwable
  {
    Exception e = new Exception("Exception in BL400"); //$NON-NLS-1$
    Retour retourNOK = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e.getMessage());
    Retour retourOk = RetourFactoryForTU.createOkRetour();
    SwapEqt swapEqt = buildValidSwapEqtRequest();
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    String jsonRequest = GsonTools.getGson(DateTimeTools.DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(swapEqt, SwapEqt.class);
    Map<String, String> donneesSpecifiques = new HashMap<>();
    String idCmdOss = "12345"; //$NON-NLS-1$
    donneesSpecifiques.put(ID_CMD_RACCO_EN_COURS, idCmdOss);
    donneesSpecifiques.put(IDENTIFIANT_TECHNIQUE_EQT_A_LIBERER, "453827"); //$NON-NLS-1$

    String noSequence = "98765"; //$NON-NLS-1$
    String idCmd = "1c27c3ba-bd3a-462e-8e9e-cba6180f614d"; //$NON-NLS-1$
    Commande commande = new Commande();
    PE0170_Eqt pe170Eqt = new PE0170_Eqt();

    fillAllRequestHeaders(request);
    request.setContentType("application/json"); //$NON-NLS-1$
    request.setPayload(jsonRequest);
    commande.setIdCmd(idCmd);
    commande.setDonneesSpecifiques(GsonTools.getIso8601Ms().toJson(donneesSpecifiques));
    commande.setStatut("EN_COURS"); //$NON-NLS-1$
    pe170Eqt.setNoSequence(noSequence);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(true, true, true, true, 120);

    ProcessManager.getInstance().getProcessParams().clear();
    ProcessManager.getInstance().getProcessParams().putAll(processParams);

    //Setting processContext to prepare for continueProcess execution
    _processInstance.getProcessContext().setState(State.PE0170_BL300_LIBERER);
    _processInstance.getProcessContext().setNbVerif(0);
    _processInstance.getProcessContext().setNbVerifMax(5);
    _processInstance.getProcessContext().setCommande(commande);
    _processInstance.getProcessContext().setSwapEqt(swapEqt);
    _processInstance.getProcessContext().setEqtProvisionneALiberer(pe170Eqt);

    //BL300 (first call)
    createMockCmdLireUn(retourOk, commande);
    createMockSI016RecupererInfoVerrou(retourOk, false, idCmdOss);

    //BL400
    createMockCmdLireUn(retourNOK, null);

    //BL005
    createMockBL4600ForBL500();

    PowerMock.replayAll();
    _processInstance.continueProcess(request, _tracabilite);
    PowerMock.verifyAll();

    Assert.assertEquals(retourNOK, _processInstance.getProcessContext().getProcessRetour());
    Assert.assertEquals(State.PE0170_END, _processInstance.getProcessContext().getState());
  }

  /**
   * <b>Scenario:</b> Test non-nominal case for PE0170_SwapEquipement - continueProcess<br>
   * <b>Expected:</b> After SLEEP phase, NbVerif reaches NbVerifMax - ProcessRetour: NOK<br>
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_SwapEquipement_continueProcess_Test_KO_04() throws Throwable
  {
    Retour retourOk = RetourFactoryForTU.createOkRetour();
    //    Retour retourNOK = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, "NbVerif has surpassed NbVerifMax"); //$NON-NLS-1$
    SwapEqt swapEqt = buildValidSwapEqtRequest();
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    String jsonRequest = GsonTools.getGson(DateTimeTools.DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(swapEqt, SwapEqt.class);
    Map<String, String> donneesSpecifiques = new HashMap<>();
    String idCmdOss = "12345"; //$NON-NLS-1$
    donneesSpecifiques.put(ID_CMD_RACCO_EN_COURS, idCmdOss);
    donneesSpecifiques.put(IDENTIFIANT_TECHNIQUE_EQT_A_LIBERER, "453827"); //$NON-NLS-1$

    String noSequence = "98765"; //$NON-NLS-1$
    String idCmd = "1c27c3ba-bd3a-462e-8e9e-cba6180f614d"; //$NON-NLS-1$
    Commande commande = new Commande();
    PE0170_Eqt pe170Eqt = new PE0170_Eqt();

    fillAllRequestHeaders(request);
    request.setContentType("application/json"); //$NON-NLS-1$
    request.setPayload(jsonRequest);
    commande.setIdCmd(idCmd);
    commande.setDonneesSpecifiques(GsonTools.getIso8601Ms().toJson(donneesSpecifiques));
    commande.setStatut("EN_COURS"); //$NON-NLS-1$
    pe170Eqt.setNoSequence(noSequence);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(true, true, true, true, 120);

    ProcessManager.getInstance().getProcessParams().clear();
    ProcessManager.getInstance().getProcessParams().putAll(processParams);

    //Setting processContext to prepare for continueProcess execution
    _processInstance.getProcessContext().setState(State.PE0170_BL300_LIBERER_SLEEP);
    _processInstance.getProcessContext().setProcessRetour(retourOk);
    _processInstance.getProcessContext().setNbVerif(4);
    _processInstance.getProcessContext().setNbVerifMax(5);
    _processInstance.getProcessContext().setCommande(commande);
    _processInstance.getProcessContext().setSwapEqt(swapEqt);
    _processInstance.getProcessContext().setEqtProvisionneALiberer(pe170Eqt);

    //BL300 (first call)
    createMockCmdLireUn(retourOk, commande);
    createMockSI016RecupererInfoVerrou(retourOk, false, idCmdOss);

    //BL005
    createMockBL4600ForBL500();

    PowerMock.replayAll();
    _processInstance.continueProcess(request, _tracabilite);
    PowerMock.verifyAll();

    Assert.assertEquals(RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.NB_ITERATION_MAX, MESSAGE_NB_ITERATION_MAX, PE0170_SWAP_EQUIPEMENT_CONTINUE_PROCESS), _processInstance.getProcessContext().getProcessRetour());
    Assert.assertEquals(State.PE0170_END, _processInstance.getProcessContext().getState());
  }

  /**
   * <b>Scenario:</b> Test nominal case for PE0170_SwapEquipement - continueProcess.<br>
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_SwapEquipement_continueProcess_Test_OK_01() throws Throwable
  {
    Retour retourOk = RetourFactoryForTU.createOkRetour();
    SwapEqt swapEqt = buildValidSwapEqtRequest();
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    String jsonRequest = GsonTools.getGson(DateTimeTools.DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(swapEqt, SwapEqt.class);
    Map<String, String> donneesSpecifiques = new HashMap<>();
    String idCmdOss = "12345"; //$NON-NLS-1$
    donneesSpecifiques.put(ID_CMD_RACCO_EN_COURS, idCmdOss);
    donneesSpecifiques.put(IDENTIFIANT_TECHNIQUE_EQT_A_LIBERER, "453827"); //$NON-NLS-1$
    String noSequence = "98765"; //$NON-NLS-1$

    Commande commande = new Commande();
    PE0170_Eqt pe170Eqt = new PE0170_Eqt();

    fillAllRequestHeaders(request);
    request.setContentType("application/json"); //$NON-NLS-1$
    request.setPayload(jsonRequest);
    commande.setDonneesSpecifiques(GsonTools.getIso8601Ms().toJson(donneesSpecifiques));
    commande.setStatut("EN_COURS"); //$NON-NLS-1$
    pe170Eqt.setNoSequence(noSequence);
    String idExterne = "1223"; //$NON-NLS-1$
    commande.setIdExterne(idExterne);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(true, true, true, true, 120);

    ProcessManager.getInstance().getProcessParams().clear();
    ProcessManager.getInstance().getProcessParams().putAll(processParams);

    //Setting processContext to prepare for continueProcess execution
    _processInstance.getProcessContext().setState(State.PE0170_BL300_LIBERER);
    _processInstance.getProcessContext().setNbVerif(0);
    _processInstance.getProcessContext().setNbVerifMax(5);
    _processInstance.getProcessContext().setCommande(commande);
    _processInstance.getProcessContext().setSwapEqt(swapEqt);
    _processInstance.getProcessContext().setEqtProvisionneALiberer(pe170Eqt);

    //BL300 (first call)
    createMockCmdLireUn(retourOk, commande);
    createMockSI016RecupererInfoVerrou(retourOk, false, idCmdOss);

    //BL400
    createMockCmdLireUn(retourOk, commande);
    createMockSI017DeclarerEquipement(retourOk);
    createMockCmdModifierStatut(retourOk);

    //BL300 (second call)
    createMockCmdLireUn(retourOk, commande);
    createMockSI016RecupererInfoVerrou(retourOk, false, idCmdOss);

    //BL500
    createMockCmdLireUn(retourOk, commande);

    PowerMock.expectNew(BSSGP_SI002_EnvoyerCRSwapBuilder.class).andReturn(_bssGpSI002BuilderMock);
    EasyMock.expect(_bssGpSI002BuilderMock.tracabilite(_tracabilite)).andReturn(_bssGpSI002BuilderMock);
    EasyMock.expect(_bssGpSI002BuilderMock.transId(Long.parseLong(idExterne))).andReturn(_bssGpSI002BuilderMock);
    EasyMock.expect(_bssGpSI002BuilderMock.ossCommandeId(Long.parseLong(idCmdOss))).andReturn(_bssGpSI002BuilderMock);
    EasyMock.expect(_bssGpSI002BuilderMock.ossCRTypeStatEnum(EasyMock.anyObject())).andReturn(_bssGpSI002BuilderMock);
    EasyMock.expect(_bssGpSI002BuilderMock.message(EasyMock.anyObject())).andReturn(_bssGpSI002BuilderMock);
    EasyMock.expect(_bssGpSI002BuilderMock.origine(EasyMock.anyObject())).andReturn(_bssGpSI002BuilderMock);
    EasyMock.expect(_bssGpSI002BuilderMock.build()).andReturn(_bssGpSI002Mock);
    EasyMock.expect(_bssGpSI002Mock.executeNextStep(EasyMock.anyObject())).andReturn(null);
    EasyMock.expect(_bssGpSI002Mock.getRetour()).andReturn(retourOk);

    createMockCmdModifierStatut(retourOk);

    PowerMock.replayAll();
    _processInstance.continueProcess(request, _tracabilite);
    PowerMock.verifyAll();

    Assert.assertEquals(retourOk, _processInstance.getProcessContext().getProcessRetour());
    Assert.assertEquals(State.PE0170_END, _processInstance.getProcessContext().getState());
  }

  /**
   * <b>Scenario:</b> Test nominal case for PE0170_SwapEquipement - continueProcess goes into SLEEP state.<br>
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_SwapEquipement_continueProcess_Test_OK_02() throws Throwable
  {
    Retour retourOk = RetourFactoryForTU.createOkRetour();
    SwapEqt swapEqt = buildValidSwapEqtRequest();
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    String jsonRequest = GsonTools.getGson(DateTimeTools.DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(swapEqt, SwapEqt.class);
    Map<String, String> donneesSpecifiques = new HashMap<>();
    String idCmdOss = "12345"; //$NON-NLS-1$
    donneesSpecifiques.put(ID_CMD_RACCO_EN_COURS, idCmdOss);
    donneesSpecifiques.put(IDENTIFIANT_TECHNIQUE_EQT_A_LIBERER, "453827"); //$NON-NLS-1$

    String noSequence = "98765"; //$NON-NLS-1$
    String idCmd = "1c27c3ba-bd3a-462e-8e9e-cba6180f614d"; //$NON-NLS-1$
    Commande commande = new Commande();
    PE0170_Eqt pe170Eqt = new PE0170_Eqt();

    fillAllRequestHeaders(request);
    request.setContentType("application/json"); //$NON-NLS-1$
    request.setPayload(jsonRequest);
    commande.setIdCmd(idCmd);
    commande.setDonneesSpecifiques(GsonTools.getIso8601Ms().toJson(donneesSpecifiques));
    commande.setStatut("EN_COURS"); //$NON-NLS-1$
    pe170Eqt.setNoSequence(noSequence);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(true, true, true, true, 120);

    ProcessManager.getInstance().getProcessParams().clear();
    ProcessManager.getInstance().getProcessParams().putAll(processParams);

    //Setting processContext to prepare for continueProcess execution
    _processInstance.getProcessContext().setState(State.PE0170_BL300_LIBERER);
    _processInstance.getProcessContext().setNbVerif(0);
    _processInstance.getProcessContext().setNbVerifMax(5);
    _processInstance.getProcessContext().setCommande(commande);
    _processInstance.getProcessContext().setSwapEqt(swapEqt);
    _processInstance.getProcessContext().setEqtProvisionneALiberer(pe170Eqt);

    //BL300 (first call)
    createMockCmdLireUn(retourOk, commande);
    createMockSI016RecupererInfoVerrou(retourOk, true, idCmdOss);

    PowerMock.replayAll();
    _processInstance.continueProcess(request, _tracabilite);
    PowerMock.verifyAll();

    Assert.assertEquals(retourOk, _processInstance.getProcessContext().getProcessRetour());
    Assert.assertEquals(State.PE0170_BL300_LIBERER_SLEEP, _processInstance.getProcessContext().getState());
  }

  /**
   * <b>Scenario:</b> Test nominal case for PE0170_SwapEquipement - continueProcess enters SLEEP state after
   * BL300_DECLARER<br>
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_SwapEquipement_continueProcess_Test_OK_03() throws Throwable
  {
    Retour retourOk = RetourFactoryForTU.createOkRetour();
    SwapEqt swapEqt = buildValidSwapEqtRequest();
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    String jsonRequest = GsonTools.getGson(DateTimeTools.DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(swapEqt, SwapEqt.class);
    Map<String, String> donneesSpecifiques = new HashMap<>();
    String idCmdOss = "12345"; //$NON-NLS-1$
    donneesSpecifiques.put(ID_CMD_RACCO_EN_COURS, idCmdOss);
    donneesSpecifiques.put(IDENTIFIANT_TECHNIQUE_EQT_A_LIBERER, "453827"); //$NON-NLS-1$

    String noSequence = "98765"; //$NON-NLS-1$
    String idCmd = "1c27c3ba-bd3a-462e-8e9e-cba6180f614d"; //$NON-NLS-1$
    Commande commande = new Commande();
    PE0170_Eqt pe170Eqt = new PE0170_Eqt();

    fillAllRequestHeaders(request);
    request.setContentType("application/json"); //$NON-NLS-1$
    request.setPayload(jsonRequest);
    commande.setIdCmd(idCmd);
    commande.setDonneesSpecifiques(GsonTools.getIso8601Ms().toJson(donneesSpecifiques));
    commande.setStatut("EN_COURS"); //$NON-NLS-1$
    pe170Eqt.setNoSequence(noSequence);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(true, true, true, true, 120);

    ProcessManager.getInstance().getProcessParams().clear();
    ProcessManager.getInstance().getProcessParams().putAll(processParams);

    //Setting processContext to prepare for continueProcess execution
    _processInstance.getProcessContext().setState(State.PE0170_BL300_LIBERER);
    _processInstance.getProcessContext().setNbVerif(0);
    _processInstance.getProcessContext().setNbVerifMax(5);
    _processInstance.getProcessContext().setCommande(commande);
    _processInstance.getProcessContext().setSwapEqt(swapEqt);
    _processInstance.getProcessContext().setEqtProvisionneALiberer(pe170Eqt);

    //BL300 (first call)
    createMockCmdLireUn(retourOk, commande);
    createMockSI016RecupererInfoVerrou(retourOk, false, idCmdOss);

    //BL400
    createMockCmdLireUn(retourOk, commande);
    createMockSI017DeclarerEquipement(retourOk);
    createMockCmdModifierStatut(retourOk);

    //BL300 (second call)
    createMockCmdLireUn(retourOk, commande);
    createMockSI016RecupererInfoVerrou(retourOk, true, idCmdOss);

    PowerMock.replayAll();
    _processInstance.continueProcess(request, _tracabilite);
    PowerMock.verifyAll();

    Assert.assertEquals(retourOk, _processInstance.getProcessContext().getProcessRetour());
    Assert.assertEquals(State.PE0170_BL300_DECLARER_SLEEP, _processInstance.getProcessContext().getState());
  }

  /**
   * <b>Scenario:</b> Test nominal case for PE0170_SwapEquipement - continueProcess wakes up from SLEEP (caused by
   * BL300_DECLARER) and continues to BL500.<br>
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_SwapEquipement_continueProcess_Test_OK_04() throws Throwable
  {
    Retour retourOk = RetourFactoryForTU.createOkRetour();
    SwapEqt swapEqt = buildValidSwapEqtRequest();
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    String jsonRequest = GsonTools.getGson(DateTimeTools.DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(swapEqt, SwapEqt.class);
    Map<String, String> donneesSpecifiques = new HashMap<>();
    String idCmdOss = "12345"; //$NON-NLS-1$
    donneesSpecifiques.put(ID_CMD_RACCO_EN_COURS, idCmdOss);
    donneesSpecifiques.put(IDENTIFIANT_TECHNIQUE_EQT_A_LIBERER, "453827"); //$NON-NLS-1$

    String noSequence = "98765"; //$NON-NLS-1$
    Commande commande = new Commande();
    PE0170_Eqt pe170Eqt = new PE0170_Eqt();

    fillAllRequestHeaders(request);
    request.setContentType("application/json"); //$NON-NLS-1$
    request.setPayload(jsonRequest);
    commande.setDonneesSpecifiques(GsonTools.getIso8601Ms().toJson(donneesSpecifiques));
    commande.setStatut("EN_COURS"); //$NON-NLS-1$
    commande.setIdExterne(swapEqt.getInfosService().getIdCommande());
    pe170Eqt.setNoSequence(noSequence);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(true, true, true, true, 120);

    ProcessManager.getInstance().getProcessParams().clear();
    ProcessManager.getInstance().getProcessParams().putAll(processParams);

    //Setting processContext to prepare for continueProcess execution
    _processInstance.getProcessContext().setState(State.PE0170_BL300_DECLARER_SLEEP);
    _processInstance.getProcessContext().setNbVerif(0);
    _processInstance.getProcessContext().setNbVerifMax(5);
    _processInstance.getProcessContext().setCommande(commande);
    _processInstance.getProcessContext().setSwapEqt(swapEqt);
    _processInstance.getProcessContext().setEqtProvisionneALiberer(pe170Eqt);

    long idCmd = Long.parseLong(_processInstance.getProcessContext().getSwapEqt().getInfosService().getIdCommande());

    //BL300 (second call)
    createMockCmdLireUn(retourOk, commande);
    createMockSI016RecupererInfoVerrou(retourOk, false, idCmdOss);

    //BL500
    createMockCmdLireUn(retourOk, commande);

    PowerMock.expectNew(BSSGP_SI002_EnvoyerCRSwapBuilder.class).andReturn(_bssGpSI002BuilderMock);
    EasyMock.expect(_bssGpSI002BuilderMock.tracabilite(_tracabilite)).andReturn(_bssGpSI002BuilderMock);
    EasyMock.expect(_bssGpSI002BuilderMock.transId(Long.parseLong(commande.getIdExterne()))).andReturn(_bssGpSI002BuilderMock);
    EasyMock.expect(_bssGpSI002BuilderMock.ossCommandeId(Long.parseLong(idCmdOss))).andReturn(_bssGpSI002BuilderMock);
    EasyMock.expect(_bssGpSI002BuilderMock.ossCRTypeStatEnum(EasyMock.anyObject())).andReturn(_bssGpSI002BuilderMock);
    EasyMock.expect(_bssGpSI002BuilderMock.message(EasyMock.anyObject())).andReturn(_bssGpSI002BuilderMock);
    EasyMock.expect(_bssGpSI002BuilderMock.origine(EasyMock.anyObject())).andReturn(_bssGpSI002BuilderMock);
    EasyMock.expect(_bssGpSI002BuilderMock.build()).andReturn(_bssGpSI002Mock);
    EasyMock.expect(_bssGpSI002Mock.executeNextStep(EasyMock.anyObject())).andReturn(null);
    EasyMock.expect(_bssGpSI002Mock.getRetour()).andReturn(retourOk);

    createMockCmdModifierStatut(retourOk);

    PowerMock.replayAll();
    _processInstance.continueProcess(request, _tracabilite);
    PowerMock.verifyAll();

    Assert.assertEquals(retourOk, _processInstance.getProcessContext().getProcessRetour());
    Assert.assertEquals(State.PE0170_END, _processInstance.getProcessContext().getState());
  }

  /**
   * <b>Scenario:</b> Test nominal case for PE0170_SwapEquipement - startProcess.<br>
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0170_SwapEquipement_startProcess_Test_OK() throws Throwable
  {
    Retour retourOk = RetourFactoryForTU.createOkRetour();
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    SwapEqt swapEqt = buildValidSwapEqtRequest();
    String jsonRequest = GsonTools.getGson(DateTimeTools.DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(swapEqt, SwapEqt.class);
    String srvId = "39506957"; //$NON-NLS-1$
    String idCmd = "12345"; //$NON-NLS-1$
    String sequence = UUID.randomUUID().toString();
    Commande commande = new Commande();
    commande.setIdCmd(idCmd);
    ArrayList<Commande> listCommande = new ArrayList<>();
    listCommande.add(commande);
    CommandeEquipement cmdEquipement = new CommandeEquipement();
    cmdEquipement.setId(6789L);
    CommandeONT commandeOnt = __podam.manufacturePojoWithFullData(CommandeONT.class);
    commandeOnt.setManufacturer(Manufacturer.HUAWEI);
    CreationOss creationOss = new CreationOss();
    creationOss.getOnts().add(commandeOnt);

    fillAllRequestHeaders(request);
    request.setContentType("application/json"); //$NON-NLS-1$
    request.setPayload(jsonRequest);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(false, false, false, false, 120);

    ProcessManager.getInstance().getProcessParams().clear();
    ProcessManager.getInstance().getProcessParams().putAll(processParams);

    //Creating mock return objects
    PFI pfi = new PFI();
    GetOrdersInfoByPortfolioResp si012Retour = new GetOrdersInfoByPortfolioResp();
    ContexteCommandeOss si013Reponse = new ContexteCommandeOss();
    com.bytel.spirit.common.generated.ws.equipement.CommandeEquipement si014Reponse = new com.bytel.spirit.common.generated.ws.equipement.CommandeEquipement();

    // Creating the Mock return values
    ConnectorResponse<Retour, PFI> rpgRetour = new ConnectorResponse<>(retourOk, pfi);
    ConnectorResponse<Retour, List<Commande>> cmdListRetour = new ConnectorResponse<>(retourOk, listCommande);
    ConnectorResponse<Retour, Nothing> cmdCommandeCreer = new ConnectorResponse<>(retourOk, null);
    si012Retour.setCommandsByPortfolios(buildCommandsPortfolio("ONE_VALID_CMD")); //$NON-NLS-1$
    si013Reponse.setCommandeEquipement(cmdEquipement);
    si014Reponse.setCreation(creationOss);

    //BL100
    EasyMock.expect(RPGProxy.getInstance()).andReturn(_rpgProxyMock);
    EasyMock.expect(_rpgProxyMock.pfiLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("BSS_GP"), EasyMock.eq(swapEqt.getPortefeuilleServices().getNoCompte()))).andReturn(rpgRetour); //$NON-NLS-1$

    PowerMock.expectNew(OSSFAI_SI012_RecupererIdCmdRaccoEnCoursBuilder.class).andReturn(_si012BuilderMock);
    EasyMock.expect(_si012BuilderMock.login("PE0170")).andReturn(_si012BuilderMock); //$NON-NLS-1$
    EasyMock.expect(_si012BuilderMock.st("SPIRIT")).andReturn(_si012BuilderMock); //$NON-NLS-1$
    EasyMock.expect(_si012BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_si012BuilderMock);
    EasyMock.expect(_si012BuilderMock.srvId(Long.parseLong(srvId))).andReturn(_si012BuilderMock);
    EasyMock.expect(_si012BuilderMock.accessType("FIBRE")).andReturn(_si012BuilderMock); //$NON-NLS-1$
    EasyMock.expect(_si012BuilderMock.build()).andReturn(_si012Mock);
    EasyMock.expect(_si012Mock.execute(_processInstance)).andReturn(si012Retour);
    EasyMock.expect(_si012Mock.getRetour()).andReturn(retourOk);

    //BL600
    EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdProxyMock);
    EasyMock.expect(_cmdProxyMock.commandeLireTousParStatutEtPFI(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("BSS_GP"), EasyMock.eq(swapEqt.getPortefeuilleServices().getNoCompte()), EasyMock.eq(Statut.EN_COURS.name()))).andReturn(cmdListRetour); //$NON-NLS-1$

    PowerMock.expectNew(OSSFAI_SI013_RecupererIdCmdEquipementBuilder.class).andReturn(_si013BuilderMock);
    EasyMock.expect(_si013BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_si013BuilderMock);
    EasyMock.expect(_si013BuilderMock.systemeTechnique(SystemeTechnique.OSS_SERVICES)).andReturn(_si013BuilderMock);
    EasyMock.expect(_si013BuilderMock.idCommande(123L)).andReturn(_si013BuilderMock);
    EasyMock.expect(_si013BuilderMock.build()).andReturn(_si013Mock);
    EasyMock.expect(_si013Mock.execute(_processInstance)).andReturn(si013Reponse);
    EasyMock.expect(_si013Mock.getRetour()).andReturn(retourOk);

    PowerMock.expectNew(OSSFAI_SI014_RecupererListeEquipementParCommandeEtParTypeBuilder.class).andReturn(_si014BuilderMock);
    EasyMock.expect(_si014BuilderMock.idCommandeEquipement(6789L)).andReturn(_si014BuilderMock);
    EasyMock.expect(_si014BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_si014BuilderMock);
    EasyMock.expect(_si014BuilderMock.build()).andReturn(_si014Mock);
    EasyMock.expect(_si014Mock.execute(_processInstance)).andReturn(si014Reponse);
    EasyMock.expect(_si014Mock.getRetour()).andReturn(retourOk);

    //BL104
    PowerMock.expectNew(BL800_ObtenirSequenceBuilder.class).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.code(UniqueIdConstant.ID_CMD_GP)).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.build()).andReturn(_bl800Mock);
    EasyMock.expect(_bl800Mock.execute(_processInstance)).andReturn(sequence);
    EasyMock.expect(_bl800Mock.getRetour()).andReturn(retourOk);

    //BL105
    EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdProxyMock);
    EasyMock.expect(_cmdProxyMock.commandeCreer(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(CreateCommandeRequest.class))).andReturn(cmdCommandeCreer);

    //BL200
    PowerMock.expectNew(OSSFAI_SI015_LibererEquipementBuilder.class).andReturn(_si015BuilderMock);
    EasyMock.expect(_si015BuilderMock.liberationEquipement(EasyMock.anyObject(LiberationEquipement.class))).andReturn(_si015BuilderMock);
    EasyMock.expect(_si015BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_si015BuilderMock);
    EasyMock.expect(_si015BuilderMock.build()).andReturn(_si015Mock);
    EasyMock.expect(_si015Mock.execute(_processInstance)).andReturn(null);
    EasyMock.expect(_si015Mock.getRetour()).andReturn(retourOk);

    createMockCmdModifierStatut(retourOk);

    PowerMock.replayAll();

    // Load Process Config
    Whitebox.invokeMethod(_processInstance, "loadProcessParameters"); //$NON-NLS-1$

    // Call startProcess
    _processInstance.run(request);
    PowerMock.verifyAll();

    //Expected response
    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setResult("{}"); //$NON-NLS-1$
    final Response expected = new Response(ErrorCode.OK_00204, response);

    //Comparison expected-result
    assertEquals(expected.getMarshalledResponseJson(), request.getResponse().getMarshalledResponseJson());
  }

  /**
   * Initialization of tests
   *
   */
  @Before
  public void setUp()
  {
    // context initialization
    _processInstance = new PE0170_SwapEquipement();
    _processInstance.initializeContext();
    _processInstance.getProcessContext().setXClientOperateur("Client operateur"); //$NON-NLS-1$

    _tracabilite = new Tracabilite();
    _tracabilite.setIdProcessusSpirit(_processInstance.getIdProcess());
    _tracabilite.setIdCorrelationSpirit(null);
    _tracabilite.setIdCorrelationByTel(StringConstants.EMPTY_STRING);
    _tracabilite.setNomProcessus(StringConstants.EMPTY_STRING);
    _tracabilite.setNomSysteme(System.getenv("SERVICE")); //$NON-NLS-1$

    PowerMock.resetAll();
  }

  /**
   * Auxiliar method to build command list to be returned by the activity SI012.
   *
   * @param typeOfListToBuild_p
   *          Type of command list to be built (With only valid commands, only invalid commands or both of them).
   * @return
   */
  private CommandsByPortfolios buildCommandsPortfolio(String typeOfListToBuild_p)
  {

    CommandsByPortfolios commandsByPortfolio = new CommandsByPortfolios();
    CommandsByPortfolios.Commands commands = new CommandsByPortfolios.Commands();
    Command commandValidOne;
    Command commandValidTwo;
    Command commandInvalidOne;
    Command commandInvalidTwo;
    switch (typeOfListToBuild_p)
    {
      case "ALL_VALID_CMDS": //$NON-NLS-1$
        commandValidOne = new Command();
        commandValidOne.setCommandId(123);
        commandValidOne.setCommandType(TypeCommandeEnum.SOUSCRIPTION.name());
        commandValidOne.setCommandStatus(EtatCommandeEnum.PENDING.name());
        commandValidTwo = new Command();
        commandValidTwo.setCommandId(456);
        commandValidTwo.setCommandType(TypeCommandeEnum.MIGRATION_TEL.name());
        commandValidTwo.setCommandStatus(EtatCommandeEnum.COMPLETING.name());
        commands.getCommand().add(commandValidOne);
        commands.getCommand().add(commandValidTwo);
        break;
      case "ALL_INVALID_CMDS": //$NON-NLS-1$
        commandInvalidOne = new Command();
        commandInvalidOne.setCommandId(123);
        commandInvalidOne.setCommandType(TypeCommandeEnum.CHANGEMENT_EQUIPEMENT.name());
        commandInvalidOne.setCommandStatus(EtatCommandeEnum.PENDING.name());
        commandInvalidTwo = new Command();
        commandInvalidTwo.setCommandId(456);
        commandInvalidTwo.setCommandType(TypeCommandeEnum.MIGRATION_TEL.name());
        commandInvalidTwo.setCommandStatus(EtatCommandeEnum.CANCELED.name());
        commands.getCommand().add(commandInvalidOne);
        commands.getCommand().add(commandInvalidTwo);
        break;
      case "ONE_VALID_CMD": //$NON-NLS-1$
        commandValidOne = new Command();
        commandValidOne.setCommandId(123);
        commandValidOne.setCommandType(TypeCommandeEnum.SOUSCRIPTION.name());
        commandValidOne.setCommandStatus(EtatCommandeEnum.PENDING.name());
        commandInvalidOne = new Command();
        commandInvalidOne.setCommandId(456);
        commandInvalidOne.setCommandType(TypeCommandeEnum.MIGRATION_TEL.name());
        commandInvalidOne.setCommandStatus(EtatCommandeEnum.CANCELED.name());
        commands.getCommand().add(commandValidOne);
        commands.getCommand().add(commandInvalidOne);
        break;
      default:
        break;
    }
    commandsByPortfolio.setCommands(commands);
    return commandsByPortfolio;
  }

  /**
   * Builds a valid {@link SwapEqt} object
   *
   * @return {@link SwapEqt}
   */
  private SwapEqt buildValidSwapEqtRequest()
  {
    SwapEqt swapEqt = new SwapEqt();

    EquipementCible equipementCible = new EquipementCible();
    equipementCible.setCodeEan("1234"); //$NON-NLS-1$
    equipementCible.setModeleEquipement("SAGEM"); //$NON-NLS-1$
    equipementCible.setNoIdentifiant("9876"); //$NON-NLS-1$
    equipementCible.setNomFabriquant("TECOM"); //$NON-NLS-1$
    swapEqt.setEquipementCible(equipementCible);

    EquipementSource equipementSource = new EquipementSource();
    equipementSource.setNoIdentifiant("5678"); //$NON-NLS-1$
    swapEqt.setEquipementSource(equipementSource);

    InfosService infosService = new InfosService();
    infosService.setIdCommande("3948"); //$NON-NLS-1$
    infosService.setNoSequence("4532"); //$NON-NLS-1$
    infosService.setTypeEquipement(TypeEquipement.BRANCHEMENT_OPTIQUE);
    swapEqt.setInfosService(infosService);

    PortefeuilleServices portefeuilleServices = new PortefeuilleServices();
    portefeuilleServices.setNoCompte("610039506957"); //$NON-NLS-1$
    portefeuilleServices.setTypeAcces(TypeAcces.FTTH);
    swapEqt.setPortefeuilleServices(portefeuilleServices);

    return swapEqt;
  }

  /**
   * Create a new request header
   *
   * @param name
   *          The request header name
   * @param value
   *          The request header value
   * @return the {@link RavelRequest.RequestHeader}
   */
  private RavelRequest.RequestHeader createHeader(String name, String value)
  {
    RavelRequest.RequestHeader requestHeader = new RavelRequest.RequestHeader();
    requestHeader.setName(name);
    requestHeader.setValue(value);

    return requestHeader;
  }

  /**
   * Creation du Mock BL4600
   *
   * @throws RavelException
   */
  private void createMockBL4600(Retour retour_p) throws Exception
  {
    PowerMock.expectNew(BL4600_CreerErreurSpiritBuilder.class).andReturn(_bl4600BuilderMock);
    EasyMock.expect(_bl4600BuilderMock.tracabilite(_tracabilite)).andReturn(_bl4600BuilderMock);
    EasyMock.expect(_bl4600BuilderMock.retour(EasyMock.anyObject())).andReturn(_bl4600BuilderMock);
    EasyMock.expect(_bl4600BuilderMock.build()).andReturn(_bl4600Mock);
    EasyMock.expect(_bl4600Mock.execute(_processInstance)).andReturn(null);
    EasyMock.expect(_bl4600Mock.getRetour()).andReturn(retour_p);
  }

  /**
   * Creation du Mock BL4600
   *
   * @throws RavelException
   */
  private void createMockBL4600ForBL500() throws Exception
  {
    PowerMock.expectNew(BL4600_CreerErreurSpiritBuilder.class).andReturn(_bl4600BuilderMock);
    EasyMock.expect(_bl4600BuilderMock.tracabilite(_tracabilite)).andReturn(_bl4600BuilderMock);
    EasyMock.expect(_bl4600BuilderMock.retour(EasyMock.anyObject())).andReturn(_bl4600BuilderMock);
    EasyMock.expect(_bl4600BuilderMock.build()).andReturn(_bl4600Mock);
    EasyMock.expect(_bl4600Mock.execute(_processInstance)).andReturn(null);
  }

  /**
   * Creation du mock SI002
   *
   * @param retourSI002_p
   *          Retour
   * @param idExterne
   *          idExterne
   * @param idOssCmd
   *          idOsscmd
   * @return retour
   * @throws Exception
   *           exception
   */
  private Capture<String> createMockBssGpSI002(Retour retourSI002_p, String idExterne, String idOssCmd) throws Exception
  {
    Capture<String> capturedTypeStat = EasyMock.newCapture();

    PowerMock.expectNew(BSSGP_SI002_EnvoyerCRSwapBuilder.class).andReturn(_bssGpSI002BuilderMock);
    EasyMock.expect(_bssGpSI002BuilderMock.tracabilite(_tracabilite)).andReturn(_bssGpSI002BuilderMock);
    EasyMock.expect(_bssGpSI002BuilderMock.transId(Long.parseLong(idExterne))).andReturn(_bssGpSI002BuilderMock);
    EasyMock.expect(_bssGpSI002BuilderMock.ossCommandeId(Long.parseLong(idOssCmd))).andReturn(_bssGpSI002BuilderMock);
    EasyMock.expect(_bssGpSI002BuilderMock.ossCRTypeStatEnum(EasyMock.capture(capturedTypeStat))).andReturn(_bssGpSI002BuilderMock);
    EasyMock.expect(_bssGpSI002BuilderMock.message(EasyMock.anyString())).andReturn(_bssGpSI002BuilderMock);
    EasyMock.expect(_bssGpSI002BuilderMock.origine("OSS")).andReturn(_bssGpSI002BuilderMock); //$NON-NLS-1$
    EasyMock.expect(_bssGpSI002BuilderMock.build()).andReturn(_bssGpSI002Mock);
    EasyMock.expect(_bssGpSI002Mock.execute(EasyMock.anyObject())).andReturn(null);
    EasyMock.expect(_bssGpSI002Mock.getRetour()).andReturn(retourSI002_p);

    return capturedTypeStat;
  }

  /**
   * Creation du Mock CMD
   *
   * @param retour_p
   *          Retour
   * @param commandeId_p
   *          commandeId_p
   * @param statut_p
   *          statut_p
   * @throws RavelException
   */
  private void createMockCmdCommandeModifierStatut(Retour retour_p, String commandeId_p, String statut_p) throws RavelException
  {

    ConnectorResponse<Retour, Nothing> resultCmd = new ConnectorResponse<>(retour_p, null);
    EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdProxyMock);
    EasyMock.expect(_cmdProxyMock.commandeModifierStatut(EasyMock.anyObject(Tracabilite.class), EasyMock.matches(commandeId_p), EasyMock.matches(statut_p), EasyMock.anyObject(), EasyMock.anyObject())).andReturn(resultCmd);
  }

  /**
   * Creation du Mock CMD.lireUn
   *
   * @param retour_p
   *          Retour
   * @param commande_p
   *          Commande
   * @throws RavelException
   */
  private void createMockCmdLireUn(Retour retour_p, Commande commande_p) throws RavelException
  {
    ConnectorResponse<Retour, Commande> resultCmd = new ConnectorResponse<>(retour_p, commande_p);
    EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdProxyMock);
    EasyMock.expect(_cmdProxyMock.commandeLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject())).andReturn(resultCmd);
  }

  /**
   * Creation du Mock CMD
   *
   * @param retour_p
   *          Retour
   * @param commande_p
   *          Commande
   * @throws RavelException
   */
  private void createMockCmdLireUnParIdExterne(Retour retour_p, Commande commande_p) throws RavelException
  {

    ConnectorResponse<Retour, Commande> resultCmd = new ConnectorResponse<>(retour_p, commande_p);
    EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdProxyMock);
    EasyMock.expect(_cmdProxyMock.commandelireUnParIdExterneEtNatureCommandeEtPFI(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(), EasyMock.anyObject(), EasyMock.anyObject(), EasyMock.anyObject())).andReturn(resultCmd);
  }

  /**
   * Creation du Mock CMD.modifierStatut
   *
   * @param retour_p
   *          Retour
   * @throws RavelException
   */
  private Capture<String> createMockCmdModifierStatut(Retour retour_p) throws RavelException
  {
    Capture<String> capturedStatut = EasyMock.newCapture(CaptureType.FIRST);
    ConnectorResponse<Retour, Nothing> resultCmd = new ConnectorResponse<>(retour_p, null);
    EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdProxyMock);
    EasyMock.expect(_cmdProxyMock.commandeModifierStatut(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(), EasyMock.capture(capturedStatut), EasyMock.anyObject(), EasyMock.anyObject())).andReturn(resultCmd);

    return capturedStatut;
  }

  /**
   * Creation du Mock RPG PFI
   *
   * @param retour_p
   *          Retour
   * @param pfi_p
   *          PFI
   * @throws RavelException
   *           exception
   *
   */
  private void createMockRpgLireUn(Retour retour_p, PFI pfi_p) throws RavelException
  {
    ConnectorResponse<Retour, PFI> resultRpg = new ConnectorResponse<>(retour_p, pfi_p);
    EasyMock.expect(RPGProxy.getInstance()).andReturn(_rpgProxyMock);
    EasyMock.expect(_rpgProxyMock.pfiLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(), EasyMock.anyObject())).andReturn(resultRpg);
  }

  /**
   * Creation du mock SI012
   *
   * @param retour_p
   *          Retour
   * @param srvId_p
   *          SrvId
   * @param typeOfCmdListToBuild_p
   *          Type of command list to be built (With only valid commands, only invalid commands or both of them).
   * @return
   * @throws Exception
   */
  private GetOrdersInfoByPortfolioResp createMockSI012(Retour retour_p, String srvId_p, String typeOfCmdListToBuild_p, String typeAcces) throws Exception
  {

    PowerMock.expectNew(OSSFAI_SI012_RecupererIdCmdRaccoEnCours.OSSFAI_SI012_RecupererIdCmdRaccoEnCoursBuilder.class).andReturn(_si012BuilderMock);
    EasyMock.expect(_si012BuilderMock.login("PE0170")).andReturn(_si012BuilderMock); //$NON-NLS-1$
    EasyMock.expect(_si012BuilderMock.st("SPIRIT")).andReturn(_si012BuilderMock); //$NON-NLS-1$
    EasyMock.expect(_si012BuilderMock.tracabilite(_tracabilite)).andReturn(_si012BuilderMock);
    EasyMock.expect(_si012BuilderMock.srvId(Long.parseLong(srvId_p))).andReturn(_si012BuilderMock);
    EasyMock.expect(_si012BuilderMock.accessType(typeAcces)).andReturn(_si012BuilderMock);
    EasyMock.expect(_si012BuilderMock.build()).andReturn(_si012Mock);

    //Call SI012
    GetOrdersInfoByPortfolioResp si012Result = null;
    if (typeOfCmdListToBuild_p != null)
    {
      si012Result = new GetOrdersInfoByPortfolioResp();
      si012Result.setCommandsByPortfolios(buildCommandsPortfolio(typeOfCmdListToBuild_p));
    }

    EasyMock.expect(_si012Mock.execute(_processInstance)).andReturn(si012Result);
    EasyMock.expect(_si012Mock.getRetour()).andReturn(retour_p);
    return si012Result;
  }

  /**
   * Creation du mock SI015
   *
   * @param retour_p
   *          Retour
   * @throws Exception
   */
  private void createMockSI015LibererEquipement(Retour retour_p) throws Exception
  {
    PowerMock.expectNew(OSSFAI_SI015_LibererEquipementBuilder.class).andReturn(_si015BuilderMock);
    EasyMock.expect(_si015BuilderMock.liberationEquipement(EasyMock.anyObject(LiberationEquipement.class))).andReturn(_si015BuilderMock);
    EasyMock.expect(_si015BuilderMock.tracabilite(_tracabilite)).andReturn(_si015BuilderMock);
    EasyMock.expect(_si015BuilderMock.build()).andReturn(_si015Mock);
    EasyMock.expect(_si015Mock.execute(_processInstance)).andReturn(null);
    EasyMock.expect(_si015Mock.getRetour()).andReturn(retour_p);
  }

  /**
   * Creation du mock SI016
   *
   * @param retour_p
   *          Retour
   * @param flagVerrouDecLibEqt_p
   *          Flag
   * @param idCommandeOss_p
   *          Commande identifier
   * @throws Exception
   */
  private void createMockSI016RecupererInfoVerrou(Retour retour_p, Boolean flagVerrouDecLibEqt_p, String idCommandeOss_p) throws Exception
  {

    PowerMock.expectNew(OSSFAI_SI016_RecupererInfoVerrouDecLibEqtBuilder.class).andReturn(_si016BuilderMock);
    EasyMock.expect(_si016BuilderMock.tracabilite(_tracabilite)).andReturn(_si016BuilderMock);
    EasyMock.expect(_si016BuilderMock.idCommandeOss(Long.parseLong((idCommandeOss_p)))).andReturn(_si016BuilderMock);
    EasyMock.expect(_si016BuilderMock.build()).andReturn(_si016Mock);
    EasyMock.expect(_si016Mock.execute(_processInstance)).andReturn(flagVerrouDecLibEqt_p);
    EasyMock.expect(_si016Mock.getRetour()).andReturn(retour_p);
  }

  /**
   * Creation du mock SI017
   *
   * @param retour_p
   *          Retour
   * @throws Exception
   */
  private void createMockSI017DeclarerEquipement(Retour retour_p) throws Exception
  {
    PowerMock.expectNew(OSSFAI_SI017_DeclarerEquipementBuilder.class).andReturn(_si017BuilderMock);
    EasyMock.expect(_si017BuilderMock.tracabilite(_tracabilite)).andReturn(_si017BuilderMock);
    EasyMock.expect(_si017BuilderMock.declarationEquipement(EasyMock.anyObject(DeclarationEquipement.class))).andReturn(_si017BuilderMock);
    EasyMock.expect(_si017BuilderMock.build()).andReturn(_si017Mock);
    EasyMock.expect(_si017Mock.execute(EasyMock.anyObject())).andReturn(null);
    EasyMock.expect(_si017Mock.getRetour()).andReturn(retour_p);
  }

  /**
   * @return process params
   */
  private ConcurrentHashMap<String, Map<String, String>> createProcessParams(boolean controleEquipementActif, boolean controleSNActifIad, boolean controleSNActifStb, boolean controleSNActifOnt, int nbVerifMax)
  {
    ConcurrentHashMap<String, Map<String, String>> processParams = new ConcurrentHashMap<>();
    HashMap<String, String> map = new HashMap<>();
    map.put(CONFIG_COHERENCE_EQUIPEMENT_PARAM, "src/test/resources/coherence_equipement.xml"); //$NON-NLS-1$
    map.put(CONFIG_CONTROLE_EQUIPEMENT_ACTIF_PARAM, String.valueOf(controleEquipementActif));
    map.put(CONFIG_CONTROLE_SN_ACTIF_IAD_PARAM, String.valueOf(controleSNActifIad));
    map.put(CONFIG_CONTROLE_SN_ACTIF_STB_PARAM, String.valueOf(controleSNActifStb));
    map.put(CONFIG_CONTROLE_SN_ACTIF_ONT_PARAM, String.valueOf(controleSNActifOnt));
    map.put(CONFIG_NBVERIFMAX_PARAM, String.valueOf(nbVerifMax));
    processParams.put(StringConstants.EMPTY_STRING, map);
    return processParams;
  }

  /**
   * Fills all the request headers
   *
   * @param request_p
   *          The request
   */
  private void fillAllRequestHeaders(Request request_p)
  {
    RavelRequest.RequestHeader xClientOperateur = createHeader(IHttpHeadersConsts.X_CLIENT_OPERATEUR, "BSS_GP"); //$NON-NLS-1$
    RavelRequest.RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "DOMINGO"); //$NON-NLS-1$
    RavelRequest.RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "GESTION MAIL SECONDAIRE"); //$NON-NLS-1$
    RavelRequest.RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$

    fillRequestHeaders(request_p, xClientOperateur, xSource, xProcess, xRequestId);
  }

  /**
   * Fills the specified request headers
   *
   * @param request_p
   *          The request
   * @param headers_p
   *          the list of headers to add
   */
  private void fillRequestHeaders(Request request_p, RavelRequest.RequestHeader... headers_p)
  {
    request_p.getRequestHeader().addAll(Arrays.asList(headers_p));
  }
}
