/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PI0248;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.test.context.ContextConfiguration;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.request.Parameter;
import com.bytel.ravel.common.factory.request.UrlParameters;
import com.bytel.ravel.common.factory.response.IRavelResponse;
import com.bytel.ravel.common.factory.response.RavelResponseFactory;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.utils.ACManagerUtil;
import com.bytel.ravel.common.utils.DateTimeTools.DateTimeFormatPattern;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.RetourFactoryForTU;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.ProcessManager;
import com.bytel.ravel.services.utils.Test_Consts;
import com.bytel.spirit.common.connectors.res.RESProxy;
import com.bytel.spirit.common.shared.functional.types.json.specifiques.DonneesSpecifiquesP2P;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.RetourConverter;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.CageP2P;
import com.bytel.spirit.common.shared.saab.res.CarteP2P;
import com.bytel.spirit.common.shared.saab.res.OltComposite;
import com.bytel.spirit.common.shared.saab.res.PortP2P;
import com.bytel.spirit.prof.processes.PI0248.structs.STI248Response;
import com.bytel.spirit.prof.processes.PI0248.structs.STI248Response.ReponseFonctionnelle;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author jramos
 * @version ($Revision$ $Date$)
 */

@RunWith(PowerMockRunner.class)
@ContextConfiguration("classpath:BeansProcessTestMocks.xml")
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
@PrepareForTest({ RESProxy.class })

public class PI0248_RecupererDetailProvisioningP2P_Test
{

  /**
   * Tracabilite
   */
  private static Tracabilite _tracabilite;

  /**
   * Factory de génération des beans
   */
  private static PodamFactory __podam = new PodamFactoryImpl();

  /**
   * SPRING context
   */
  @SuppressWarnings("unused")
  private static ClassPathXmlApplicationContext __context;

  /**
   * The default process name.
   */
  public static final String DEFAULT_PROCESSNAME = "PI0248_RecupererDetailProvisioningP2P"; //$NON-NLS-1$

  /**
   * Initialization method: Create: - spring context - connectors - service manager.
   *
   * @throws RavelException
   *           the exception
   */
  @BeforeClass
  public static void init() throws RavelException
  {
    // désactivation du cache podam
    __podam.getStrategy().setMemoization(false);
    __podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());

    ACManagerUtil.resetACManager();
    __context = new ClassPathXmlApplicationContext("classpath:BeansProcessTestMocks.xml"); //$NON-NLS-1$
  }

  /**
   * Instance of {@link PI0248_RecupererDetailProvisioningP2P}
   */
  private PI0248_RecupererDetailProvisioningP2P _processInstance;

  /**
   * RES PRoxy
   */
  @MockStrict
  private RESProxy _resProxy;

  /**
   * Tests the PI0248_RecupererDetailProvisioningP2P process when request is invalid NomOlt null or empty.
   *
   * <b>Inputs:</b> Request without parameters<br>
   * <b>Expected:</b> Request response : KO_00400 <br>
   * <b>"{\"retour\":{\"resultat\":\"NOK\",\"categorie\":\"CAT-3\",\"diagnostic\":\"ENTREE_INCORRECTE\"<br>
   *
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void PI0248_RecupererDetailProvisioningP2P_KO_PARAMETER001() throws Throwable
  {
    Request request = prepareRequest(null, null, null);

    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ENTREE_INCORRECTE, "Paramètre nomOlt null ou vide.", "PI0248_BL001_VerifierDonnees"); //$NON-NLS-1$ //$NON-NLS-2$

    STI248Response sti248ResponseExpected = new STI248Response(RetourConverter.convertToJsonRetour(retour), null);
    ReponseFonctionnelle reponse = new ReponseFonctionnelle(null, null, null, _tracabilite, null);
    sti248ResponseExpected.setReponseFonctionnelle(reponse);

    PowerMock.replayAll();
    _processInstance.run(request);

    PowerMock.verify();

    IRavelResponse response = request.getResponse();

    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(sti248ResponseExpected));

    assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());
    assertEquals(RetourFactory.createOkRetour(), _processInstance.getRetour());
  }

  /**
   * Tests the PI0248_RecupererDetailProvisioningP2P process when request is invalid PositionCarteP2P null or empty.
   *
   * <b>Inputs:</b> Request with parameters, Missing PositionCarteP2P<br>
   * <b>Expected:</b> Request response : KO_00400 <br>
   * <b>"{\"retour\":{\"resultat\":\"NOK\",\"categorie\":\"CAT-3\",\"diagnostic\":\"ENTREE_INCORRECTE\"<br>
   *
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void PI0248_RecupererDetailProvisioningP2P_KO_PARAMETER002() throws Throwable
  {
    Request request = prepareRequest("nomOlt", null, null); //$NON-NLS-1$

    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ENTREE_INCORRECTE, "Paramètre positionCarteP2P null ou vide.", "PI0248_BL001_VerifierDonnees"); //$NON-NLS-1$ //$NON-NLS-2$

    STI248Response sti248ResponseExpected = new STI248Response(RetourConverter.convertToJsonRetour(retour), null);
    ReponseFonctionnelle reponse = new ReponseFonctionnelle(null, null, null, _tracabilite, null);
    sti248ResponseExpected.setReponseFonctionnelle(reponse);

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verify();

    IRavelResponse response = request.getResponse();

    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(sti248ResponseExpected));

    assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());
    assertEquals(RetourFactory.createOkRetour(), _processInstance.getRetour());
  }

  /**
   * Tests the PI0248_RecupererDetailProvisioningP2P process when request is invalid PositionRelativePortP2P null or
   * empty.
   *
   * <b>Inputs:</b> Request with parameters, Missing PositionRelativePortP2P<br>
   * <b>Expected:</b> Request response : KO_00400 <br>
   * <b>"{\"retour\":{\"resultat\":\"NOK\",\"categorie\":\"CAT-3\",\"diagnostic\":\"ENTREE_INCORRECTE\"<br>
   *
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void PI0248_RecupererDetailProvisioningP2P_KO_PARAMETER003() throws Throwable
  {
    Request request = prepareRequest("nomOlt", "1", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-2

    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ENTREE_INCORRECTE, "Paramètre positionRelativePortP2P null ou vide.", "PI0248_BL001_VerifierDonnees"); //$NON-NLS-1$ //$NON-NLS-2$

    STI248Response sti248ResponseExpected = new STI248Response(RetourConverter.convertToJsonRetour(retour), null);
    ReponseFonctionnelle reponse = new ReponseFonctionnelle(null, null, null, _tracabilite, null);
    sti248ResponseExpected.setReponseFonctionnelle(reponse);

    PowerMock.replayAll();
    _processInstance.run(request);

    PowerMock.verify();

    IRavelResponse response = request.getResponse();

    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(sti248ResponseExpected));

    assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());
    assertEquals(RetourFactory.createOkRetour(), _processInstance.getRetour());
  }

  /**
   * Tests the PI0248_RecupererDetailProvisioningP2P process when request is invalid NomOlt is not allowed.
   *
   * <b>Inputs:</b> Request with parameters, but invalid nomOlt <br>
   * <b>Expected:</b> Request response : KO_00400 <br>
   * <b>"{\"retour\":{\"resultat\":\"NOK\",\"categorie\":\"CAT-3\",\"diagnostic\":\"ENTREE_INCORRECTE\"<br>
   *
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void PI0248_RecupererDetailProvisioningP2P_KO_PARAMETER005() throws Throwable
  {
    Request request = prepareRequest("", "1", "1"); //$NON-NLS-1$ //$NON-NLS-2$//$NON-NLS-3$

    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ENTREE_INCORRECTE, "Paramètre nomOlt null ou vide.", "PI0248_BL001_VerifierDonnees"); //$NON-NLS-1$ //$NON-NLS-2$

    STI248Response sti248ResponseExpected = new STI248Response(RetourConverter.convertToJsonRetour(retour), null);
    ReponseFonctionnelle reponse = new ReponseFonctionnelle(null, null, null, _tracabilite, null);
    sti248ResponseExpected.setReponseFonctionnelle(reponse);

    PowerMock.replayAll();
    _processInstance.run(request);

    PowerMock.verify();

    IRavelResponse response = request.getResponse();

    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(sti248ResponseExpected));

    assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());
    assertEquals(RetourFactory.createOkRetour(), _processInstance.getRetour());
  }

  /**
   * Tests the PI0248_RecupererDetailProvisioningP2P process when request is invalid PositionCarteP2P is not allowed.
   *
   * <b>Inputs:</b> Request with parameters, but invalid PositionCarteP2P <br>
   * <b>Expected:</b> Request response : KO_00400 <br>
   * <b>"{\"retour\":{\"resultat\":\"NOK\",\"categorie\":\"CAT-3\",\"diagnostic\":\"ENTREE_INCORRECTE\"<br>
   *
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void PI0248_RecupererDetailProvisioningP2P_KO_PARAMETER006() throws Throwable
  {
    Request request = prepareRequest("nomolt", "A", "1"); //$NON-NLS-1$ //$NON-NLS-2$//$NON-NLS-3$

    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ENTREE_INCORRECTE, "La valeur spécifiée dans positionCarteP2P n'est pas autorisée.", "PI0248_BL001_VerifierDonnees"); //$NON-NLS-1$ //$NON-NLS-2$

    STI248Response sti248ResponseExpected = new STI248Response(RetourConverter.convertToJsonRetour(retour), null);
    ReponseFonctionnelle reponse = new ReponseFonctionnelle(null, null, null, _tracabilite, null);
    sti248ResponseExpected.setReponseFonctionnelle(reponse);

    PowerMock.replayAll();
    _processInstance.run(request);

    PowerMock.verify();

    IRavelResponse response = request.getResponse();

    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(sti248ResponseExpected));

    assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());
    assertEquals(RetourFactory.createOkRetour(), _processInstance.getRetour());
  }

  /**
   * Tests the PI0248_RecupererDetailProvisioningP2P process when request is invalid PositionRelativePortP2P is not
   * allowed.
   *
   * <b>Inputs:</b> Request with parameters, but invalid PositionRelativePortP2P <br>
   * <b>Expected:</b> Request response : KO_00400 <br>
   * <b>"{\"retour\":{\"resultat\":\"NOK\",\"categorie\":\"CAT-3\",\"diagnostic\":\"ENTREE_INCORRECTE\"<br>
   *
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void PI0248_RecupererDetailProvisioningP2P_KO_PARAMETER007() throws Throwable
  {
    Request request = prepareRequest("nomolt", "1", "A"); //$NON-NLS-1$ //$NON-NLS-2$//$NON-NLS-3$

    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ENTREE_INCORRECTE, "La valeur spécifiée dans positionRelativePortP2P n'est pas autorisée.", "PI0248_BL001_VerifierDonnees"); //$NON-NLS-1$ //$NON-NLS-2$

    STI248Response sti248ResponseExpected = new STI248Response(RetourConverter.convertToJsonRetour(retour), null);
    ReponseFonctionnelle reponse = new ReponseFonctionnelle(null, null, null, _tracabilite, null);
    sti248ResponseExpected.setReponseFonctionnelle(reponse);

    PowerMock.replayAll();
    _processInstance.run(request);

    PowerMock.verify();

    IRavelResponse response = request.getResponse();

    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(sti248ResponseExpected));

    assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());
    assertEquals(RetourFactory.createOkRetour(), _processInstance.getRetour());
  }

  /**
   * Tests the PI0248_RecupererDetailProvisioningP2P case pad3200OltCompositeLireUn:CAT2/SERVICE_TIERS_INDISPONIBLE.
   *
   * Parameters are Ok<br>
   * CALL BL001 return OK <br>
   * CALL BL100 return NOK <br>
   * CALL ResPROXY.pad3200OltCompositeLireUn return ConnectorResponse<Retour, OltComposite><NOK, NULL> <br>
   *
   * <b>Inputs:</b> Request with valid parameters <br>
   * <b>Expected:</b> Request response : KO_00503 <br>
   * <b>"{\"retour\":{\"resultat\":\"NOK\",\"categorie\":\"CAT-2\",\"diagnostic\":\"SERVICE_TIERS_INDISPONIBLE\"<br>
   *
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void PI0248_RecupererDetailProvisioningP2P_TEST01() throws Throwable
  {
    Request request = prepareRequest("nomolt", "1", "1"); //$NON-NLS-1$ //$NON-NLS-2$//$NON-NLS-3$

    Retour retour = RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, ""); //$NON-NLS-1$

    STI248Response sti248ResponseExpected = new STI248Response(RetourConverter.convertToJsonRetour(retour), null);
    ReponseFonctionnelle reponse = new ReponseFonctionnelle(null, null, null, _tracabilite, null);
    sti248ResponseExpected.setReponseFonctionnelle(reponse);

    Retour retourpad3200 = RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, ""); //$NON-NLS-1$
    ConnectorResponse<Retour, OltComposite> resultRes = new ConnectorResponse<Retour, OltComposite>(retourpad3200, null);

    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxy);
    EasyMock.expect(_resProxy.pad3200OltCompositeLireUn(_tracabilite, "nomolt")).andReturn(resultRes); //$NON-NLS-1$

    PowerMock.replayAll();
    _processInstance.run(request);

    PowerMock.verify();

    IRavelResponse response = request.getResponse();

    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(sti248ResponseExpected));

    assertEquals(ErrorCode.KO_00503, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());
    assertEquals(RetourFactory.createOkRetour(), _processInstance.getRetour());
  }

  /**
   * Tests the PI0248_RecupererDetailProvisioningP2P case pad3200OltCompositeLireUn:OK.
   *
   * Parameters are Ok <br>
   * CALL BL001 return OK <br>
   * CALL BL100 --- CALL ResPROXY.pad3200OltCompositeLireUn return ConnectorResponse<Retour, OltComposite><OK> <br>
   *
   * <b>Inputs:</b> Request with valid parameters <br>
   * <b>Expected:</b> Request response : OK_00200 <br>
   * <b>"{\"retour\":{\"resultat\":\"OK\""<br>
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void PI0248_RecupererDetailProvisioningP2P_TEST02() throws Throwable
  {
    Request request = prepareRequest("nomolt", "1", "1"); //$NON-NLS-1$ //$NON-NLS-2$//$NON-NLS-3$

    Retour retour = RetourFactory.createOkRetour();

    OltComposite oltComposite = prepareOltComposite();
    OltComposite oltComposite1 = prepareOltComposite();
    oltComposite.setListeCarteP2P(null);
    oltComposite1.getListeCarteP2P().get(1).setListeCageP2P(null);
    STI248Response sti248ResponseExpected = new STI248Response(RetourConverter.convertToJsonRetour(retour), null);

    DonneesSpecifiquesP2P donneesSpecifiquesP2P = new DonneesSpecifiquesP2P("modele"); //$NON-NLS-1$

    ReponseFonctionnelle reponse = new ReponseFonctionnelle(oltComposite, oltComposite1.getListeCarteP2P().get(1), donneesSpecifiquesP2P, null, "OPERATIONNEL"); //$NON-NLS-1$
    sti248ResponseExpected.setReponseFonctionnelle(reponse);

    Retour retourpad3200 = RetourFactory.createOkRetour();
    OltComposite olt = prepareOltComposite();
    ConnectorResponse<Retour, OltComposite> resultRes = new ConnectorResponse<Retour, OltComposite>(retourpad3200, olt);

    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxy);
    EasyMock.expect(_resProxy.pad3200OltCompositeLireUn(_tracabilite, "nomolt")).andReturn(resultRes); //$NON-NLS-1$

    PowerMock.replayAll();
    _processInstance.run(request);

    PowerMock.verify();

    IRavelResponse response = request.getResponse();

    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(sti248ResponseExpected));

    assertEquals(ErrorCode.OK_00200, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());
    assertEquals(RetourFactory.createOkRetour(), _processInstance.getRetour());
  }

  /**
   * Tests case PI0248_RecupererDetailProvisioningP2P: No object is found in MAP CARTEP2P, for key.
   *
   * Parameters are Ok.<br>
   * CALL BL001 return OK <br>
   * CALL BL100 --- CALL ResPROXY.pad3200OltCompositeLireUn return ConnectorResponse<Retour, OltComposite><OK, NOT NULL>
   * <br>
   * SEARCH IN MAP CARTEP2P AND RETURN NULL<br>
   * <b>Inputs:</b> Request with valid parameters <br>
   * <b>Expected:</b> Request response : KO_00404 <br>
   * <b>"{\"retour\":{\"resultat\":\"NOK\",\"categorie\":\"CAT-4\",\"diagnostic\":\"DONNEE_INCONNUE"
   * PI0248.ObjectNonTrouveCarteP2P<br>
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void PI0248_RecupererDetailProvisioningP2P_TEST03() throws Throwable
  {
    Request request = prepareRequest("nomolt", "2", "1"); //$NON-NLS-1$ //$NON-NLS-2$//$NON-NLS-3$

    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "Aucun object est trouvee dans le MAP CarteP2P, pur la cleé 2.", "PI0248_BL100_Traitement"); //$NON-NLS-1$ //$NON-NLS-2$

    OltComposite oltComposite = prepareOltComposite();
    oltComposite.getListeCarteP2P().clear();

    STI248Response sti248ResponseExpected = new STI248Response(RetourConverter.convertToJsonRetour(retour), null);

    ReponseFonctionnelle reponse = new ReponseFonctionnelle(null, null, null, _tracabilite, null);

    sti248ResponseExpected.setReponseFonctionnelle(reponse);

    Retour retourpad3200 = RetourFactory.createOkRetour();
    OltComposite olt = prepareOltComposite();
    ConnectorResponse<Retour, OltComposite> resultRes = new ConnectorResponse<Retour, OltComposite>(retourpad3200, olt);

    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxy);
    EasyMock.expect(_resProxy.pad3200OltCompositeLireUn(_tracabilite, "nomolt")).andReturn(resultRes); //$NON-NLS-1$

    PowerMock.replayAll();
    _processInstance.run(request);

    PowerMock.verify();

    IRavelResponse response = request.getResponse();

    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(sti248ResponseExpected));

    assertEquals(ErrorCode.KO_00404, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());
    assertEquals(RetourFactory.createOkRetour(), _processInstance.getRetour());
  }

  /**
   * Tests case Nominal PI0248_RecupererDetailProvisioningP2P - SEARCH IN MAP CARTEP2P AND RETURN OK but Statuttechnique
   * not equal in ConnectorResponse.
   *
   * Parameters are Ok. <br>
   * CALL BL001 return OK <br>
   * CALL BL100 --- CALL ResPROXY.pad3200OltCompositeLireUn return ConnectorResponse<Retour, OltComposite><OK, NOT NULL>
   * <br>
   * SEARCH IN MAP CARTEP2P AND RETURN OK but Statuttechnique not equal<br>
   * <b>Inputs:</b> Request with valid parameters <br>
   * <b>Expected:</b> Request response : OK_00200 <br>
   * <b>"{\"retour\":{\"resultat\":\"OK\""<br>
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void PI0248_RecupererDetailProvisioningP2P_TEST04() throws Throwable
  {
    Request request = prepareRequest("nomolt", "1", "1"); //$NON-NLS-1$ //$NON-NLS-2$//$NON-NLS-3$

    Retour retour = RetourFactory.createOkRetour();

    OltComposite oltComposite = prepareOltComposite1();
    OltComposite oltComposite1 = prepareOltComposite1();
    oltComposite.setListeCarteP2P(null);
    oltComposite1.getListeCarteP2P().get(1).setListeCageP2P(null);

    STI248Response sti248ResponseExpected = new STI248Response(RetourConverter.convertToJsonRetour(retour), null);

    DonneesSpecifiquesP2P donneesSpecifiquesP2P = new DonneesSpecifiquesP2P("modele"); //$NON-NLS-1$

    ReponseFonctionnelle reponse = new ReponseFonctionnelle(oltComposite, oltComposite1.getListeCarteP2P().get(1), donneesSpecifiquesP2P, null, "OPERATIONNEL1"); //$NON-NLS-1$
    sti248ResponseExpected.setReponseFonctionnelle(reponse);

    Retour retourpad3200 = RetourFactory.createOkRetour();
    OltComposite olt = prepareOltComposite1();
    ConnectorResponse<Retour, OltComposite> resultRes = new ConnectorResponse<Retour, OltComposite>(retourpad3200, olt);

    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxy);
    EasyMock.expect(_resProxy.pad3200OltCompositeLireUn(_tracabilite, "nomolt")).andReturn(resultRes); //$NON-NLS-1$

    PowerMock.replayAll();
    _processInstance.run(request);

    PowerMock.verify();

    IRavelResponse response = request.getResponse();

    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(sti248ResponseExpected));

    assertEquals(ErrorCode.OK_00200, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());
    assertEquals(RetourFactory.createOkRetour(), _processInstance.getRetour());
  }

  /**
   * Tests case Nominal PI0248_RecupererDetailProvisioningP2P - SEARCH IN MAP CARTEP2P RETURN OK but Statuttechnique not
   * equal in CARTEP2P.
   *
   * Parameters are Ok. <br>
   * CALL BL001 return OK <br>
   * CALL BL100 --- CALL ResPROXY.pad3200OltCompositeLireUn return ConnectorResponse<Retour, OltComposite><OK, NOT NULL>
   * <br>
   * SEARCH IN MAP CARTEP2P AND RETURN OK but Statuttechnique not equal<br>
   * <b>Inputs:</b> Request with valid parameters <br>
   * <b>Expected:</b> Request response : OK_00200 <br>
   * <b>"{\"retour\":{\"resultat\":\"OK\""<br>
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void PI0248_RecupererDetailProvisioningP2P_TEST05() throws Throwable
  {
    Request request = prepareRequest("nomolt", "1", "1"); //$NON-NLS-1$ //$NON-NLS-2$//$NON-NLS-3$

    Retour retour = RetourFactory.createOkRetour();

    OltComposite oltComposite = prepareOltComposite2();
    OltComposite oltComposite1 = prepareOltComposite2();
    oltComposite.setListeCarteP2P(null);
    oltComposite1.getListeCarteP2P().get(1).setListeCageP2P(null);

    STI248Response sti248ResponseExpected = new STI248Response(RetourConverter.convertToJsonRetour(retour), null);

    DonneesSpecifiquesP2P donneesSpecifiquesP2P = new DonneesSpecifiquesP2P("modele"); //$NON-NLS-1$

    ReponseFonctionnelle reponse = new ReponseFonctionnelle(oltComposite, oltComposite1.getListeCarteP2P().get(1), donneesSpecifiquesP2P, null, "OPERATIONNEL1"); //$NON-NLS-1$
    sti248ResponseExpected.setReponseFonctionnelle(reponse);

    Retour retourpad3200 = RetourFactory.createOkRetour();
    OltComposite olt = prepareOltComposite2();
    ConnectorResponse<Retour, OltComposite> resultRes = new ConnectorResponse<Retour, OltComposite>(retourpad3200, olt);

    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxy);
    EasyMock.expect(_resProxy.pad3200OltCompositeLireUn(_tracabilite, "nomolt")).andReturn(resultRes); //$NON-NLS-1$

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verify();

    IRavelResponse response = request.getResponse();

    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(sti248ResponseExpected));

    assertEquals(ErrorCode.OK_00200, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());
    assertEquals(RetourFactory.createOkRetour(), _processInstance.getRetour());
  }

  /**
   * Tests case the PI0248_RecupererDetailProvisioningP2P - No object is found in MAP PortP2P.
   *
   * Parameters are Ok <br>
   * CALL BL001 return OK <br>
   * CALL BL100 --- CALL ResPROXY.pad3200OltCompositeLireUn return ConnectorResponse<Retour, OltComposite><OK, NOT NULL>
   * <br>
   * SEARCH IN MAP CARTEEP2P AND RETURN OK<br>
   * SEARCH IN MAP PORTP2P AND RETURN NULL<br>
   *
   * <b>Inputs:</b> Request with valid parameters <br>
   * <b>Expected:</b> Request response : KO_00404 <br>
   * <b>"{\"retour\":{\"resultat\":\"NOK\",\"categorie\":\"CAT-4\",\"diagnostic\":\"DONNEE_INCONNUE\"
   * PI0248.ObjectNonTrouveCageP2P<br>
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void PI0248_RecupererDetailProvisioningP2P_TEST06() throws Throwable
  {
    Request request = prepareRequest("nomolt", "1", "2"); //$NON-NLS-1$ //$NON-NLS-2$//$NON-NLS-3$

    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "Aucun object est trouvee dans le MAP PortP2P, pur la cleé 2.", "PI0248_BL100_Traitement"); //$NON-NLS-1$ //$NON-NLS-2$

    STI248Response sti248ResponseExpected = new STI248Response(RetourConverter.convertToJsonRetour(retour), null);

    ReponseFonctionnelle reponse = new ReponseFonctionnelle(null, null, null, _tracabilite, null);
    sti248ResponseExpected.setReponseFonctionnelle(reponse);

    Retour retourpad3200 = RetourFactory.createOkRetour();
    OltComposite olt = prepareOltComposite3();
    ConnectorResponse<Retour, OltComposite> resultRes = new ConnectorResponse<Retour, OltComposite>(retourpad3200, olt);

    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxy);
    EasyMock.expect(_resProxy.pad3200OltCompositeLireUn(_tracabilite, "nomolt")).andReturn(resultRes); //$NON-NLS-1$

    PowerMock.replayAll();
    _processInstance.run(request);

    PowerMock.verify();

    IRavelResponse response = request.getResponse();

    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(sti248ResponseExpected));

    assertEquals(ErrorCode.KO_00404, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());
    assertEquals(RetourFactory.createOkRetour(), _processInstance.getRetour());
  }

  /**
   * Tests cas the PI0248_RecupererDetailProvisioningP2P SEARCH IN MAP CAGEP2P RETURN OK but Statuttechnique not equal
   * in CAGEP2P.
   *
   * Parameters are Ok.<br>
   * * CALL BL001 return OK <br>
   * CALL BL100 --- CALL ResPROXY.pad3200OltCompositeLireUn return ConnectorResponse<Retour, OltComposite><OK, NOT NULL>
   * <br>
   * SEARCH IN MAP CARTEEP2P AND RETURN OK<br>
   * SEARCH IN MAP CAGEP2P AND RETURN OK but Statuttechnique not equal<br>
   *
   * <b>Inputs:</b> Request with valid parameters <br>
   * <b>Expected:</b> Request response : OK_00200 <br>
   * <b>"{\"retour\":{\"resultat\":\"OK\""<br>
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void PI0248_RecupererDetailProvisioningP2P_TEST07() throws Throwable
  {
    Request request = prepareRequest("nomolt", "1", "2"); //$NON-NLS-1$ //$NON-NLS-2$//$NON-NLS-3$

    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "Aucun object est trouvee dans le MAP PortP2P, pur la cleé 2.", "PI0248_BL100_Traitement"); //$NON-NLS-1$ //$NON-NLS-2$

    OltComposite oltComposite = prepareOltComposite4();
    OltComposite oltComposite1 = prepareOltComposite4();
    oltComposite.setListeCarteP2P(null);
    oltComposite1.getListeCarteP2P().get(1).setListeCageP2P(null);

    STI248Response sti248ResponseExpected = new STI248Response(RetourConverter.convertToJsonRetour(retour), null);

    ReponseFonctionnelle reponse = new ReponseFonctionnelle(null, null, null, _tracabilite, null);
    sti248ResponseExpected.setReponseFonctionnelle(reponse);

    Retour retourpad3200 = RetourFactory.createOkRetour();
    OltComposite olt = prepareOltComposite4();
    ConnectorResponse<Retour, OltComposite> resultRes = new ConnectorResponse<Retour, OltComposite>(retourpad3200, olt);

    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxy);
    EasyMock.expect(_resProxy.pad3200OltCompositeLireUn(_tracabilite, "nomolt")).andReturn(resultRes); //$NON-NLS-1$

    PowerMock.replayAll();
    _processInstance.run(request);

    PowerMock.verify();

    IRavelResponse response = request.getResponse();

    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(sti248ResponseExpected));

    assertEquals(ErrorCode.KO_00404, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());
    assertEquals(RetourFactory.createOkRetour(), _processInstance.getRetour());
  }

  /**
   * Tests case the PI0248_RecupererDetailProvisioningP2P - No object is found in MAP PortP2P, for key.<br>
   *
   * CALL BL001 return OK <br>
   * CALL BL100 --- CALL ResPROXY.pad3200OltCompositeLireUn return ConnectorResponse<Retour, OltComposite><NOK, NOT
   * NULL> <br>
   * SEARCH IN MAP CARTEEP2P AND RETURN OK<br>
   * SEARCH IN MAP CAGEP2P AND RETURN OK<br>
   * SEARCH IN MAP CAGEP2P AND RETURN NULL<br>
   *
   * <b>Inputs:</b> Request with valid parameters <br>
   * <b>Expected:</b> Request response : KO_00404 <br>
   * <b>"{\"retour\":{\"resultat\":\"NOK\",\"categorie\":\"CAT-4\",\"diagnostic\":\"DONNEE_INCONNUE\"
   * PI0248.ObjectNonTrouveCageP2P<br>
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void PI0248_RecupererDetailProvisioningP2P_TEST08() throws Throwable
  {
    Request request = prepareRequest("nomolt", "1", "2"); //$NON-NLS-1$ //$NON-NLS-2$//$NON-NLS-3$

    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "Aucun object est trouvee dans le MAP PortP2P, pur la cleé 2.", "PI0248_BL100_Traitement"); //$NON-NLS-1$ //$NON-NLS-2$

    STI248Response sti248ResponseExpected = new STI248Response(RetourConverter.convertToJsonRetour(retour), null);

    ReponseFonctionnelle reponse = new ReponseFonctionnelle(null, null, null, _tracabilite, null);
    sti248ResponseExpected.setReponseFonctionnelle(reponse);

    Retour retourpad3200 = RetourFactory.createOkRetour();
    OltComposite olt = prepareOltComposite5();
    ConnectorResponse<Retour, OltComposite> resultRes = new ConnectorResponse<Retour, OltComposite>(retourpad3200, olt);

    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxy);
    EasyMock.expect(_resProxy.pad3200OltCompositeLireUn(_tracabilite, "nomolt")).andReturn(resultRes); //$NON-NLS-1$

    PowerMock.replayAll();
    _processInstance.run(request);

    PowerMock.verify();

    IRavelResponse response = request.getResponse();

    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(sti248ResponseExpected));

    assertEquals(ErrorCode.KO_00404, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());
    assertEquals(RetourFactory.createOkRetour(), _processInstance.getRetour());
  }

  /**
   * Tests case the PI0248_RecupererDetailProvisioningP2P - SEARCH IN MAP PORTP2P RETURN Ok but Statuttechnique not
   * equal.
   *
   * Parameters are Ok <br>
   * CALL BL001 return OK <br>
   * CALL BL100 --- CALL ResPROXY.pad3200OltCompositeLireUn return ConnectorResponse<Retour, OltComposite><OK, NOT NULL>
   * <br>
   * SEARCH IN MAP CARTEEP2P AND RETURN OK<br>
   * SEARCH IN MAP CAGEP2P AND RETURN OK<br>
   * SEARCH IN MAP CAGEP2P AND RETURN Ok but Statuttechnique not equal <br>
   *
   * <b>Inputs:</b> Request with valid parameters <br>
   * <b>Expected:</b> Request response : OK_00200 <br>
   * <b>"{\"retour\":{\"resultat\":\"OK\"<br>
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void PI0248_RecupererDetailProvisioningP2P_TEST09() throws Throwable
  {
    Request request = prepareRequest("nomolt", "1", "1"); //$NON-NLS-1$ //$NON-NLS-2$//$NON-NLS-3$

    Retour retour = RetourFactory.createOkRetour();

    OltComposite oltComposite = prepareOltComposite6();
    OltComposite oltComposite1 = prepareOltComposite6();
    oltComposite.setListeCarteP2P(null);
    oltComposite1.getListeCarteP2P().get(1).setListeCageP2P(null);

    STI248Response sti248ResponseExpected = new STI248Response(RetourConverter.convertToJsonRetour(retour), null);

    DonneesSpecifiquesP2P donneesSpecifiquesP2P = new DonneesSpecifiquesP2P("modele"); //$NON-NLS-1$

    ReponseFonctionnelle reponse = new ReponseFonctionnelle(oltComposite, oltComposite1.getListeCarteP2P().get(1), donneesSpecifiquesP2P, null, "OPERATIONNEL1"); //$NON-NLS-1$
    sti248ResponseExpected.setReponseFonctionnelle(reponse);

    Retour retourpad3200 = RetourFactory.createOkRetour();
    OltComposite olt = prepareOltComposite6();
    ConnectorResponse<Retour, OltComposite> resultRes = new ConnectorResponse<Retour, OltComposite>(retourpad3200, olt);

    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxy);
    EasyMock.expect(_resProxy.pad3200OltCompositeLireUn(_tracabilite, "nomolt")).andReturn(resultRes); //$NON-NLS-1$

    PowerMock.replayAll();
    _processInstance.run(request);

    PowerMock.verify();

    IRavelResponse response = request.getResponse();

    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(sti248ResponseExpected));

    assertEquals(ErrorCode.OK_00200, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());
    assertEquals(RetourFactory.createOkRetour(), _processInstance.getRetour());
  }

  /**
   * Sets the test
   *
   */
  @Before
  public void setUp()
  {
    _processInstance = new PI0248_RecupererDetailProvisioningP2P();
    _processInstance.initializeContext();

    _tracabilite = new Tracabilite();
    _tracabilite.setIdCorrelationByTel(StringConstants.EMPTY_STRING);
    _tracabilite.setIdProcessusSpirit(_processInstance.getIdProcess());
    _tracabilite.setIdCorrelationSpirit(Test_Consts.DEFAULT_MSGID);
    _tracabilite.setNomProcessus(StringConstants.EMPTY_STRING);
    _tracabilite.setNomSysteme(System.getenv("SERVICE")); //$NON-NLS-1$

    ProcessManager.getInstance().getProcessParams().clear();

    // on réinitialise tous les mocks afin de ne pas avoir d'interférence entre les tests
    PowerMock.resetAll();
    PowerMock.mockStatic(RESProxy.class);

  }

  /**
   * Prepare the object OltCompsite
   *
   * @return OltComposite
   */
  private OltComposite prepareOltComposite()
  {
    OltComposite olt = new OltComposite("nomolt", null, null, null, null, null, null); //$NON-NLS-1$

    CarteP2P carteP2P = new CarteP2P(1, "typeCarte", "modele", "OPERATIONNEL"); //$NON-NLS-1$ //$NON-NLS-2$//$NON-NLS-3$
    CageP2P cageP2P = new CageP2P(1, "OPERATIONNEL"); //$NON-NLS-1$
    PortP2P portP2P = new PortP2P(1, 1, "OPERATIONNEL"); //$NON-NLS-1$

    Map<Integer, CarteP2P> mapCarteP2P_p = new HashMap<Integer, CarteP2P>();
    mapCarteP2P_p.put(1, carteP2P);

    Map<Integer, CageP2P> mapCageP2P_p = new HashMap<Integer, CageP2P>();
    mapCageP2P_p.put(1, cageP2P);

    Map<Integer, PortP2P> mapPortP2P_p = new HashMap<Integer, PortP2P>();
    mapPortP2P_p.put(1, portP2P);

    cageP2P.setListePortP2P(mapPortP2P_p);

    carteP2P.setListeCageP2P(mapCageP2P_p);

    olt.setListeCarteP2P(mapCarteP2P_p);
    olt.setStatutTechnique("OPERATIONNEL"); //$NON-NLS-1$

    return olt;
  }

  /**
   * Prepare the object OltCompsite
   *
   * @return OltComposite
   */
  private OltComposite prepareOltComposite1()
  {
    OltComposite olt = new OltComposite("nomolt", null, null, null, null, null, null); //$NON-NLS-1$

    CarteP2P carteP2P = new CarteP2P(1, "typeCarte", "modele", "OPERATIONNEL1"); //$NON-NLS-1$ //$NON-NLS-2$//$NON-NLS-3$
    CageP2P cageP2P = new CageP2P(1, "OPERATIONNEL1"); //$NON-NLS-1$
    PortP2P portP2P = new PortP2P(1, 1, "OPERATIONNEL1"); //$NON-NLS-1$

    Map<Integer, CarteP2P> mapCarteP2P_p = new HashMap<Integer, CarteP2P>();
    mapCarteP2P_p.put(1, carteP2P);

    Map<Integer, CageP2P> mapCageP2P_p = new HashMap<Integer, CageP2P>();
    mapCageP2P_p.put(1, cageP2P);

    Map<Integer, PortP2P> mapPortP2P_p = new HashMap<Integer, PortP2P>();
    mapPortP2P_p.put(1, portP2P);

    cageP2P.setListePortP2P(mapPortP2P_p);

    carteP2P.setListeCageP2P(mapCageP2P_p);

    olt.setListeCarteP2P(mapCarteP2P_p);
    olt.setStatutTechnique("OPERATIONNEL1"); //$NON-NLS-1$

    return olt;
  }

  /**
   * Prepare the object OltCompsite
   *
   * @return OltComposite
   */
  private OltComposite prepareOltComposite2()
  {
    OltComposite olt = new OltComposite("nomolt", null, null, null, null, null, null); //$NON-NLS-1$

    CarteP2P carteP2P = new CarteP2P(1, "typeCarte", "modele", "OPERATIONNEL1"); //$NON-NLS-1$ //$NON-NLS-2$//$NON-NLS-3$
    CageP2P cageP2P = new CageP2P(1, "OPERATIONNEL1"); //$NON-NLS-1$
    PortP2P portP2P = new PortP2P(1, 1, "OPERATIONNEL1"); //$NON-NLS-1$

    Map<Integer, CarteP2P> mapCarteP2P_p = new HashMap<Integer, CarteP2P>();
    mapCarteP2P_p.put(1, carteP2P);

    Map<Integer, CageP2P> mapCageP2P_p = new HashMap<Integer, CageP2P>();
    mapCageP2P_p.put(1, cageP2P);

    Map<Integer, PortP2P> mapPortP2P_p = new HashMap<Integer, PortP2P>();
    mapPortP2P_p.put(1, portP2P);

    cageP2P.setListePortP2P(mapPortP2P_p);

    carteP2P.setListeCageP2P(mapCageP2P_p);

    olt.setListeCarteP2P(mapCarteP2P_p);
    olt.setStatutTechnique("OPERATIONNEL"); //$NON-NLS-1$

    return olt;
  }

  /**
   * Prepare the object OltCompsite
   *
   * @return OltComposite
   */
  private OltComposite prepareOltComposite3()
  {
    OltComposite olt = new OltComposite("nomolt", null, null, null, null, null, null); //$NON-NLS-1$

    CarteP2P carteP2P = new CarteP2P(1, "typeCarte", "modele", "OPERATIONNEL"); //$NON-NLS-1$ //$NON-NLS-2$//$NON-NLS-3$
    CageP2P cageP2P = new CageP2P(1, "OPERATIONNEL"); //$NON-NLS-1$

    Map<Integer, CarteP2P> mapCarteP2P_p = new HashMap<Integer, CarteP2P>();
    mapCarteP2P_p.put(1, carteP2P);

    Map<Integer, CageP2P> mapCageP2P_p = new HashMap<Integer, CageP2P>();
    mapCageP2P_p.put(1, cageP2P);

    carteP2P.setListeCageP2P(mapCageP2P_p);

    olt.setListeCarteP2P(mapCarteP2P_p);
    olt.setStatutTechnique("OPERATIONNEL"); //$NON-NLS-1$

    DonneesSpecifiquesP2P donneesSpecifiquesP2P = new DonneesSpecifiquesP2P();
    donneesSpecifiquesP2P.setModele(carteP2P.getModele());

    return olt;
  }

  /**
   * Prepare the object OltCompsite
   *
   * @return OltComposite
   */
  private OltComposite prepareOltComposite4()
  {
    OltComposite olt = new OltComposite("nomolt", null, null, null, null, null, null); //$NON-NLS-1$

    CarteP2P carteP2P = new CarteP2P(1, "typeCarte", "modele", "OPERATIONNEL"); //$NON-NLS-1$ //$NON-NLS-2$//$NON-NLS-3$
    CageP2P cageP2P = new CageP2P(1, "OPERATIONNEL1"); //$NON-NLS-1$

    Map<Integer, CarteP2P> mapCarteP2P_p = new HashMap<Integer, CarteP2P>();
    mapCarteP2P_p.put(1, carteP2P);

    Map<Integer, CageP2P> mapCageP2P_p = new HashMap<Integer, CageP2P>();
    mapCageP2P_p.put(1, cageP2P);

    carteP2P.setListeCageP2P(mapCageP2P_p);

    olt.setListeCarteP2P(mapCarteP2P_p);
    olt.setStatutTechnique("OPERATIONNEL"); //$NON-NLS-1$

    return olt;
  }

  /**
   * Prepare the object OltCompsite
   *
   * @return OltComposite
   */
  private OltComposite prepareOltComposite5()
  {
    OltComposite olt = new OltComposite("nomolt", null, null, null, null, null, null); //$NON-NLS-1$

    CarteP2P carteP2P = new CarteP2P(1, "typeCarte", "modele", "OPERATIONNEL"); //$NON-NLS-1$ //$NON-NLS-2$//$NON-NLS-3$
    CageP2P cageP2P = new CageP2P(1, "OPERATIONNEL"); //$NON-NLS-1$
    PortP2P portP2P = new PortP2P(1, 1, "OPERATIONNEL"); //$NON-NLS-1$

    Map<Integer, CarteP2P> mapCarteP2P_p = new HashMap<Integer, CarteP2P>();
    mapCarteP2P_p.put(1, carteP2P);

    Map<Integer, CageP2P> mapCageP2P_p = new HashMap<Integer, CageP2P>();
    mapCageP2P_p.put(1, cageP2P);

    Map<Integer, PortP2P> mapPortP2P_p = new HashMap<Integer, PortP2P>();
    mapPortP2P_p.put(1, portP2P);

    cageP2P.setListePortP2P(mapPortP2P_p);

    carteP2P.setListeCageP2P(mapCageP2P_p);

    olt.setListeCarteP2P(mapCarteP2P_p);
    olt.setStatutTechnique("OPERATIONNEL"); //$NON-NLS-1$

    return olt;
  }

  /**
   * Prepare the object OltCompsite
   *
   * @return OltComposite
   */
  private OltComposite prepareOltComposite6()
  {
    OltComposite olt = new OltComposite("nomolt", null, null, null, null, null, null); //$NON-NLS-1$

    CarteP2P carteP2P = new CarteP2P(1, "typeCarte", "modele", "OPERATIONNEL"); //$NON-NLS-1$ //$NON-NLS-2$//$NON-NLS-3$
    CageP2P cageP2P = new CageP2P(1, "OPERATIONNEL"); //$NON-NLS-1$
    PortP2P portP2P = new PortP2P(1, 1, "OPERATIONNEL1"); //$NON-NLS-1$

    Map<Integer, CarteP2P> mapCarteP2P_p = new HashMap<Integer, CarteP2P>();
    mapCarteP2P_p.put(1, carteP2P);

    Map<Integer, CageP2P> mapCageP2P_p = new HashMap<Integer, CageP2P>();
    mapCageP2P_p.put(1, cageP2P);

    Map<Integer, PortP2P> mapPortP2P_p = new HashMap<Integer, PortP2P>();
    mapPortP2P_p.put(1, portP2P);

    cageP2P.setListePortP2P(mapPortP2P_p);

    carteP2P.setListeCageP2P(mapCageP2P_p);

    olt.setListeCarteP2P(mapCarteP2P_p);
    olt.setStatutTechnique("OPERATIONNEL"); //$NON-NLS-1$

    return olt;
  }

  /**
   * Create a Generic Request to call PI0248_RecupererDetailProvisioningP2P
   *
   * @param nomOlt_p
   *          nomOlt_p
   * @param positionCarteP2P_p
   *          positionCarteP2P_p
   * @param positionRelativePortP2P_p
   *          positionPortP2P_p
   *
   *          * @return GenericRequest to call PI0248_RecupererDetailProvisioningP2P
   * @throws RavelException
   *           on error
   */

  private Request prepareRequest(String nomOlt_p, String positionCarteP2P_p, String positionRelativePortP2P_p) throws RavelException
  {
    Request request = new Request(DEFAULT_PROCESSNAME, "idProcess", "idClient"); //$NON-NLS-1$ //$NON-NLS-2$
    request.setMsgId(Test_Consts.DEFAULT_MSGID);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();

    if (nomOlt_p != null)
    {
      list.add(new Parameter(PI0248_RecupererDetailProvisioningP2P.ParameterUrl.nomOlt.name(), nomOlt_p));
    }
    if (positionCarteP2P_p != null)
    {
      list.add(new Parameter(PI0248_RecupererDetailProvisioningP2P.ParameterUrl.positionCarteP2P.name(), positionCarteP2P_p));
    }
    if (positionRelativePortP2P_p != null)
    {
      list.add(new Parameter(PI0248_RecupererDetailProvisioningP2P.ParameterUrl.positionRelativePortP2P.name(), positionRelativePortP2P_p));
    }
    urlParametersType.setUrlParameters(list);
    request.setUrlParameters(urlParametersType);

    return request;
  }

}
