/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PI0035.sti;

import static org.apache.commons.lang3.StringUtils.isBlank;
import static org.junit.Assert.assertEquals;

import java.time.LocalDateTime;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.validation.ConstraintViolation;

import org.easymock.EasyMockSupport;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.bytel.ravel.common.datetime.DateTimeManager;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.spirit.common.shared.misc.validation.IValidationConst;
import com.bytel.spirit.common.shared.saab.rpg.PA;
import com.bytel.spirit.common.shared.saab.rpg.PaTypeVoip;
import com.bytel.spirit.common.shared.saab.rpg.Statut;
import com.bytel.spirit.common.shared.saab.rpg.TypePA;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author jiantila
 * @version ($Revision$ $Date$)
 */

@RunWith(PowerMockRunner.class)
@PrepareForTest({ PI0035_PAVoip.class })
public class PI0035_PAVoipTest extends EasyMockSupport
{
  /**
  *
  */
  public static final String VALUE_AUTHORIZED = IValidationConst.FORMAT_ATTRIBUT_NON_RESPECTE;
  /**
  *
  */
  public static final String CONDITIONAL = IValidationConst.ATTRIBUT_COND_INATTENDU;

  /**
  *
  */
  public static final String MANDATORY = IValidationConst.ATTRIBUT_OBLIGATOIRE_MANQUANT;
  /**
   * Factory de génération des beans
   */
  private static PodamFactory __podam = new PodamFactoryImpl();

  /**
   * Initialize before all tests
   */
  @BeforeClass
  public static void setUpBeforeClass()
  {
    // désactivation du cache podam
    __podam.getStrategy().setMemoization(false);
    __podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());
  }

  /**
   * @param constraintValidation_p
   *          constraint
   * @return String
   */
  public String getNameConstraint(final ConstraintViolation<?> constraintValidation_p)
  {
    return Stream.of(constraintValidation_p.getRootBeanClass().getSimpleName(), constraintValidation_p.getPropertyPath().toString()).filter(s -> !isBlank(s)).collect(Collectors.joining(".")); //$NON-NLS-1$
  }

  /**
   * Tests static method {@link PI0035_PA#buildFromPA(PA)} with PaTypeVoip
   */
  @Test
  public void testBuildFromPAVoip()
  {
    PA pa = __podam.manufacturePojo(PA.class);
    PaTypeVoip paVoip = __podam.manufacturePojo(PaTypeVoip.class);
    pa.setTypePA(TypePA.VOIP.name());
    pa.setPaTypeVoip(paVoip);

    PI0035_PA pfiCompLF = PI0035_PA.buildFromPA(pa);
    PFITestUtils.assertPA(pa, pfiCompLF);

  }

  /**
   * Tests static method {@link PI0035_PA#buildFromPA(PA)} with PaTypeVoip
   */
  @Test
  public void testBuildFromPAVoip_001()
  {
    LocalDateTime currentDateTime = DateTimeManager.getInstance().now();
    PA pa = new PA("identifiantFonctionnelPA", "typePA", Statut.ACTIF, currentDateTime, currentDateTime); //$NON-NLS-1$//$NON-NLS-2$
    PaTypeVoip paVoip = new PaTypeVoip("numeroTelephone", "codeRio", 10); //$NON-NLS-1$ //$NON-NLS-2$
    pa.setTypePA(TypePA.VOIP.name());
    pa.setPaTypeVoip(paVoip);
    PI0035_PA pfiCompLF = PI0035_PA.buildFromPA(pa);
    assertEquals(pfiCompLF.equals(pfiCompLF), true);

  }
}
