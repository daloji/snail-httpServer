/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PE0229.structs;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PowerMockListener;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.testlisteners.FieldDefaulter;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.modules.junit4.PowerMockRunnerDelegate;
import org.powermock.reflect.Whitebox;
import org.springframework.test.context.ContextConfiguration;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.test.podam.PodamBytelJUnit4ClassRunner;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.spirit.common.shared.saab.cmd.Statut;
import com.bytel.spirit.common.shared.saab.rst.ServiceTechnique;
import com.bytel.spirit.common.shared.misc.ressources.RetourConverter;
import com.bytel.spirit.common.shared.types.json.ModificationCommerciale;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author jjoly
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PowerMockListener(FieldDefaulter.class)
@PowerMockRunnerDelegate(PodamBytelJUnit4ClassRunner.class)
@ContextConfiguration("classpath:BeansProcessTestMocks.xml")
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
@PrepareForTest({ PEP0229_BL001_Return.class })
public final class PEP0229_BL001_ReturnTest
{
  /**
   * bean Factory generation
   */
  private static PodamFactory __podam;

  /**
   *
   */
  private static Retour __retour;

  /**
   *
   */
  private static String __noCompte;

  /**
   *
   */
  private static String __clientOperateur;

  /**
   *
   */
  private static List<ServiceTechnique> __stCibles;

  /**
   *
   */
  private static List<ModificationCommerciale> __modComm;

  /**
   *
   */
  private static Statut __statusCmd;

  /**
   * Initialize before all tests
   *
   * @throws Exception
   *           On errors Exception to be thrown in case of failure
   */
  @BeforeClass
  public static void setUpBeforeClass() throws Exception
  {
    __podam = new PodamFactoryImpl();
    __podam.getStrategy().setMemoization(false);
    __podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());

    __retour = RetourFactory.createOkRetour();
    __noCompte = __podam.manufacturePojo(String.class);
    __clientOperateur = __podam.manufacturePojo(String.class);
    __stCibles = __podam.manufacturePojoWithFullData(ArrayList.class, ServiceTechnique.class);
    __modComm = __podam.manufacturePojoWithFullData(ArrayList.class, ModificationCommerciale.class);
    __statusCmd = __podam.manufacturePojo(Statut.class);
  }

  /**
   * Instance to evaluate
   */
  private PEP0229_BL001_Return _instance;

  /**
   * Exception has been thrown
   */
  private boolean _exception;

  /**
   * Initialize before tests
   *
   * @throws Exception
   *           On errors Thrown in case of error during switch in attributes of parent class
   */
  @Before
  public void setUp() throws Exception
  {
    _instance = null;
    _exception = false;

    PowerMock.resetAll();
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.prof.processes.PE0229.structs.PEP0229_BL001_Return#PEP0229_BL001_Return(com.bytel.ravel.common.business.generated.Retour, java.lang.String, java.lang.String)}.<br/>
   * <b>Entrées:</b>NULL value in input<br/>
   * <b>Attendu:</b>NullPointerException<br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void testPEP0229_BL001_Return_001() throws Exception
  {
    try
    {
      PowerMock.replayAll();

      _instance = new PEP0229_BL001_Return(null, null, null, null);
      Whitebox.setInternalState(_instance, "_retour", RetourConverter.convertToJsonRetour(RetourFactory.createOkRetour())); //$NON-NLS-1$
    }
    catch (final NullPointerException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertTrue(_exception);

      assertNull(_instance);
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.prof.processes.PE0229.structs.PEP0229_BL001_Return#PEP0229_BL001_Return(com.bytel.ravel.common.business.generated.Retour, java.lang.String, java.lang.String)}.<br/>
   * <b>Entrées:</b>NULL value in input<br/>
   * <b>Attendu:</b>NullPointerException<br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void testPEP0229_BL001_Return_002() throws Exception
  {
    try
    {
      PowerMock.replayAll();

      _instance = new PEP0229_BL001_Return(__retour, null, null, null);
      Whitebox.setInternalState(_instance, "_retour", __retour); //$NON-NLS-1$
    }
    catch (final Exception e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertFalse(_exception);

      assertNotNull(_instance);
      assertEquals(RetourFactory.createOkRetour(), Whitebox.getInternalState(_instance, "_retour")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_noCompte")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_clientOperateur")); //$NON-NLS-1$
      //assertEquals(new ArrayList<ServiceTechnique>(), Whitebox.getInternalState(_instance, "_stCibles")); //$NON-NLS-1$
      //assertEquals(new ArrayList<ModificationCommerciale>(), Whitebox.getInternalState(_instance, "_modComm")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_statusCmd")); //$NON-NLS-1$
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.prof.processes.PE0229.structs.PEP0229_BL001_Return#PEP0229_BL001_Return(com.bytel.ravel.common.business.generated.Retour, java.lang.String, java.lang.String)}.<br/>
   * <b>Entrées:</b>NULL value in input<br/>
   * <b>Attendu:</b>NullPointerException<br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void testPEP0229_BL001_Return_003() throws Exception
  {
    try
    {
      PowerMock.replayAll();

      _instance = new PEP0229_BL001_Return(__retour, __noCompte, null, null);
      Whitebox.setInternalState(_instance, "_retour", __retour); //$NON-NLS-1$
    }
    catch (final Exception e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertFalse(_exception);

      assertNotNull(_instance);
      assertEquals(RetourFactory.createOkRetour(), Whitebox.getInternalState(_instance, "_retour")); //$NON-NLS-1$
      assertEquals(__noCompte, Whitebox.getInternalState(_instance, "_noCompte")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_clientOperateur")); //$NON-NLS-1$
      //assertEquals(new ArrayList<ServiceTechnique>(), Whitebox.getInternalState(_instance, "_stCibles")); //$NON-NLS-1$
      //assertEquals(new ArrayList<ModificationCommerciale>(), Whitebox.getInternalState(_instance, "_modComm")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_statusCmd")); //$NON-NLS-1$
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.prof.processes.PE0229.structs.PEP0229_BL001_Return#PEP0229_BL001_Return(com.bytel.ravel.common.business.generated.Retour, java.lang.String, java.lang.String)}.<br/>
   * <b>Entrées:</b><br/>
   * <b>Attendu:</b><br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void testPEP0229_BL001_Return_004() throws Exception
  {
    try
    {
      PowerMock.replayAll();

      _instance = new PEP0229_BL001_Return(__retour, __noCompte, __clientOperateur, null);
    }
    catch (final Exception e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertFalse(_exception);

      assertNotNull(_instance);
      assertEquals(RetourFactory.createOkRetour(), Whitebox.getInternalState(_instance, "_retour")); //$NON-NLS-1$
      assertEquals(__noCompte, Whitebox.getInternalState(_instance, "_noCompte")); //$NON-NLS-1$
      assertEquals(__clientOperateur, Whitebox.getInternalState(_instance, "_clientOperateur")); //$NON-NLS-1$
      //assertEquals(new ArrayList<ServiceTechnique>(), Whitebox.getInternalState(_instance, "_stCibles")); //$NON-NLS-1$
      //assertEquals(new ArrayList<ModificationCommerciale>(), Whitebox.getInternalState(_instance, "_modComm")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_statusCmd")); //$NON-NLS-1$
    }
  }

  /**
   * Test method for {@link com.bytel.spirit.prof.processes.PE0229.structs.PEP0229_BL001_Return#getNoCompte()}.<br/>
   * <b>Entrées:</b><br/>
   * <b>Attendu:</b><br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void testPEP0229_BL001_Return_005() throws Exception
  {
    final String expected = __noCompte;
    String actual = null;

    try
    {
      PowerMock.replayAll();

      _instance = new PEP0229_BL001_Return(__retour, __noCompte, __clientOperateur, null);
      actual = _instance.getNoCompte();
    }
    catch (final Exception e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertFalse(_exception);

      assertNotNull(_instance);
      assertEquals(expected, actual);
      assertEquals(__retour, Whitebox.getInternalState(_instance, "_retour")); //$NON-NLS-1$
      assertEquals(__noCompte, Whitebox.getInternalState(_instance, "_noCompte")); //$NON-NLS-1$
      assertEquals(__clientOperateur, Whitebox.getInternalState(_instance, "_clientOperateur")); //$NON-NLS-1$
      //assertEquals(new ArrayList<ServiceTechnique>(), Whitebox.getInternalState(_instance, "_stCibles")); //$NON-NLS-1$
      //assertEquals(new ArrayList<ModificationCommerciale>(), Whitebox.getInternalState(_instance, "_modComm")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_statusCmd")); //$NON-NLS-1$
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.prof.processes.PE0229.structs.PEP0229_BL001_Return#getClientOperateur()}.<br/>
   * <b>Entrées:</b><br/>
   * <b>Attendu:</b><br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void testPEP0229_BL001_Return_006() throws Exception
  {
    final String expected = __clientOperateur;
    String actual = null;

    try
    {
      PowerMock.replayAll();

      _instance = new PEP0229_BL001_Return(__retour, __noCompte, __clientOperateur, null);
      actual = _instance.getClientOperateur();
    }
    catch (final NullPointerException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertFalse(_exception);

      assertNotNull(_instance);
      assertEquals(expected, actual);
      assertEquals(__retour, Whitebox.getInternalState(_instance, "_retour")); //$NON-NLS-1$
      assertEquals(__noCompte, Whitebox.getInternalState(_instance, "_noCompte")); //$NON-NLS-1$
      assertEquals(__clientOperateur, Whitebox.getInternalState(_instance, "_clientOperateur")); //$NON-NLS-1$
      //assertEquals(new ArrayList<ServiceTechnique>(), Whitebox.getInternalState(_instance, "_stCibles")); //$NON-NLS-1$
      //assertEquals(new ArrayList<ModificationCommerciale>(), Whitebox.getInternalState(_instance, "_modComm")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_statusCmd")); //$NON-NLS-1$
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.prof.processes.PE0229.structs.PEP0229_BL001_Return#getClientOperateur()}.<br/>
   * <b>Entrées:</b><br/>
   * <b>Attendu:</b><br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void testPEP0229_BL001_Return_007() throws Exception
  {
    final String expected = __clientOperateur;
    String actual = null;

    try
    {
      PowerMock.replayAll();

      _instance = new PEP0229_BL001_Return(__retour, __noCompte, __clientOperateur, null);
      actual = _instance.getClientOperateur();
    }
    catch (final Exception e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertFalse(_exception);

      assertNotNull(_instance);
      assertEquals(expected, actual);
      assertEquals(__retour, Whitebox.getInternalState(_instance, "_retour")); //$NON-NLS-1$
      assertEquals(__noCompte, Whitebox.getInternalState(_instance, "_noCompte")); //$NON-NLS-1$
      assertEquals(__clientOperateur, Whitebox.getInternalState(_instance, "_clientOperateur")); //$NON-NLS-1$
      //assertEquals(new ArrayList<ServiceTechnique>(), Whitebox.getInternalState(_instance, "_stCibles")); //$NON-NLS-1$
      //assertEquals(new ArrayList<ModificationCommerciale>(), Whitebox.getInternalState(_instance, "_modComm")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_statusCmd")); //$NON-NLS-1$
    }
  }

  /**
   * Test method for {@link com.bytel.spirit.prof.processes.PE0229.structs.PEP0229_BL001_Return#getRetour()}.<br/>
   * <b>Entrées:</b><br/>
   * <b>Attendu:</b><br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void testPEP0229_BL001_Return_008() throws Exception
  {
    final Retour expected = __retour;
    Retour actual = null;

    try
    {
      PowerMock.replayAll();

      _instance = new PEP0229_BL001_Return(__retour, __noCompte, __clientOperateur, null);
      actual = _instance.getRetour();
    }
    catch (final Exception e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertFalse(_exception);

      assertNotNull(_instance);
      assertEquals(expected, actual);
      assertEquals(__retour, Whitebox.getInternalState(_instance, "_retour")); //$NON-NLS-1$
      assertEquals(__noCompte, Whitebox.getInternalState(_instance, "_noCompte")); //$NON-NLS-1$
      assertEquals(__clientOperateur, Whitebox.getInternalState(_instance, "_clientOperateur")); //$NON-NLS-1$
      //assertEquals(new ArrayList<ServiceTechnique>(), Whitebox.getInternalState(_instance, "_stCibles")); //$NON-NLS-1$
      //assertEquals(new ArrayList<ModificationCommerciale>(), Whitebox.getInternalState(_instance, "_modComm")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_statusCmd")); //$NON-NLS-1$
    }
  }

  /**
   * Test method for {@link com.bytel.spirit.prof.processes.PE0229.structs.PEP0229_BL001_Return#getStatusCmd()}.<br/>
   * <b>Entrées:</b><br/>
   * <b>Attendu:</b><br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void testPEP0229_BL001_Return_011() throws Exception
  {
    final Statut expected = __statusCmd;
    Statut actual = null;

    try
    {
      PowerMock.replayAll();

      _instance = new PEP0229_BL001_Return(__retour, __noCompte, __clientOperateur, null);
      Whitebox.setInternalState(_instance, "_statusCmd", __statusCmd); //$NON-NLS-1$
      actual = _instance.getStatusCmd();
    }
    catch (final Exception e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertFalse(_exception);

      assertNotNull(_instance);
      assertEquals(expected, actual);
      assertEquals(__retour, Whitebox.getInternalState(_instance, "_retour")); //$NON-NLS-1$
      assertEquals(__noCompte, Whitebox.getInternalState(_instance, "_noCompte")); //$NON-NLS-1$
      assertEquals(__clientOperateur, Whitebox.getInternalState(_instance, "_clientOperateur")); //$NON-NLS-1$
      //assertEquals(new ArrayList<ServiceTechnique>(), Whitebox.getInternalState(_instance, "_stCibles")); //$NON-NLS-1$
      //assertEquals(new ArrayList<ModificationCommerciale>(), Whitebox.getInternalState(_instance, "_modComm")); //$NON-NLS-1$
      assertEquals(__statusCmd, Whitebox.getInternalState(_instance, "_statusCmd")); //$NON-NLS-1$
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.prof.processes.PE0229.structs.PEP0229_BL001_Return#setNoCompte(java.lang.String)}.<br/>
   * <b>Entrées:</b><br/>
   * <b>Attendu:</b><br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void testPEP0229_BL001_Return_012() throws Exception
  {
    final String expected = __noCompte;
    String actual = null;

    try
    {
      PowerMock.replayAll();

      _instance = new PEP0229_BL001_Return(__retour, __podam.manufacturePojo(String.class), __clientOperateur, null);
      _instance.setNoCompte(__noCompte);
      actual = Whitebox.getInternalState(_instance, "_noCompte"); //$NON-NLS-1$
    }
    catch (final Exception e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertFalse(_exception);

      assertNotNull(_instance);
      assertEquals(expected, actual);
      assertEquals(__retour, Whitebox.getInternalState(_instance, "_retour")); //$NON-NLS-1$
      assertEquals(__noCompte, Whitebox.getInternalState(_instance, "_noCompte")); //$NON-NLS-1$
      assertEquals(__clientOperateur, Whitebox.getInternalState(_instance, "_clientOperateur")); //$NON-NLS-1$
      //assertEquals(new ArrayList<ServiceTechnique>(), Whitebox.getInternalState(_instance, "_stCibles")); //$NON-NLS-1$
      //assertEquals(new ArrayList<ModificationCommerciale>(), Whitebox.getInternalState(_instance, "_modComm")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_statusCmd")); //$NON-NLS-1$
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.prof.processes.PE0229.structs.PEP0229_BL001_Return#setClientOperateur(java.lang.String)}.<br/>
   * <b>Entrées:</b><br/>
   * <b>Attendu:</b><br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void testPEP0229_BL001_Return_013() throws Exception
  {
    final String expected = __clientOperateur;
    String actual = null;

    try
    {
      PowerMock.replayAll();

      _instance = new PEP0229_BL001_Return(__retour, __noCompte, __podam.manufacturePojo(String.class), null);
      _instance.setClientOperateur(__clientOperateur);
      actual = Whitebox.getInternalState(_instance, "_clientOperateur"); //$NON-NLS-1$
    }
    catch (final Exception e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertFalse(_exception);

      assertNotNull(_instance);
      assertEquals(expected, actual);
      assertEquals(__retour, Whitebox.getInternalState(_instance, "_retour")); //$NON-NLS-1$
      assertEquals(__noCompte, Whitebox.getInternalState(_instance, "_noCompte")); //$NON-NLS-1$
      assertEquals(__clientOperateur, Whitebox.getInternalState(_instance, "_clientOperateur")); //$NON-NLS-1$
      //assertEquals(new ArrayList<ServiceTechnique>(), Whitebox.getInternalState(_instance, "_stCibles")); //$NON-NLS-1$
      //assertEquals(new ArrayList<ModificationCommerciale>(), Whitebox.getInternalState(_instance, "_modComm")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_statusCmd")); //$NON-NLS-1$
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.prof.processes.PE0229.structs.PEP0229_BL001_Return#setRetour(com.bytel.ravel.common.business.generated.Retour)}.<br/>
   * <b>Entrées:</b><br/>
   * <b>Attendu:</b><br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void testPEP0229_BL001_Return_014() throws Exception
  {
    final Retour expected = __retour;
    Retour actual = null;

    try
    {
      PowerMock.replayAll();

      _instance = new PEP0229_BL001_Return(RetourFactory.createKO(null, null, null), __noCompte, __clientOperateur, null);
      _instance.setRetour(__retour);
      actual = Whitebox.getInternalState(_instance, "_retour"); //$NON-NLS-1$
    }
    catch (final Exception e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertFalse(_exception);

      assertNotNull(_instance);
      assertEquals(expected, actual);
      assertEquals(__retour, Whitebox.getInternalState(_instance, "_retour")); //$NON-NLS-1$
      assertEquals(__noCompte, Whitebox.getInternalState(_instance, "_noCompte")); //$NON-NLS-1$
      assertEquals(__clientOperateur, Whitebox.getInternalState(_instance, "_clientOperateur")); //$NON-NLS-1$
      //assertEquals(new ArrayList<ServiceTechnique>(), Whitebox.getInternalState(_instance, "_stCibles")); //$NON-NLS-1$
      //assertEquals(new ArrayList<ModificationCommerciale>(), Whitebox.getInternalState(_instance, "_modComm")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_statusCmd")); //$NON-NLS-1$
    }
  }

  /**
   * Test method for {@link com.bytel.spirit.prof.processes.PE0229.structs.PEP0229_BL001_Return#getStatusCmd()}.<br/>
   * <b>Entrées:</b><br/>
   * <b>Attendu:</b><br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void testPEP0229_BL001_Return_017() throws Exception
  {
    final Statut expected = __statusCmd;
    Statut actual = null;

    try
    {
      PowerMock.replayAll();

      _instance = new PEP0229_BL001_Return(__retour, __noCompte, __clientOperateur, null);
      _instance.setStatusCmd(__statusCmd);
      actual = Whitebox.getInternalState(_instance, "_statusCmd"); //$NON-NLS-1$
    }
    catch (final Exception e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertFalse(_exception);

      assertNotNull(_instance);
      assertEquals(expected, actual);
      assertEquals(__retour, Whitebox.getInternalState(_instance, "_retour")); //$NON-NLS-1$
      assertEquals(__noCompte, Whitebox.getInternalState(_instance, "_noCompte")); //$NON-NLS-1$
      assertEquals(__clientOperateur, Whitebox.getInternalState(_instance, "_clientOperateur")); //$NON-NLS-1$
      //assertEquals(new ArrayList<ServiceTechnique>(), Whitebox.getInternalState(_instance, "_stCibles")); //$NON-NLS-1$
      //assertEquals(new ArrayList<ModificationCommerciale>(), Whitebox.getInternalState(_instance, "_modComm")); //$NON-NLS-1$
      assertEquals(__statusCmd, Whitebox.getInternalState(_instance, "_statusCmd")); //$NON-NLS-1$
    }
  }
}
