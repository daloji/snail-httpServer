/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PE0229;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;

import java.text.MessageFormat;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;

import javax.ws.rs.core.MediaType;

import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.Mock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PowerMockListener;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.testlisteners.FieldDefaulter;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.modules.junit4.PowerMockRunnerDelegate;
import org.powermock.reflect.Whitebox;
import org.springframework.test.context.ContextConfiguration;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.data.exchange.generated.RavelRequest.RequestHeader;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.request.Parameter;
import com.bytel.ravel.common.factory.request.UrlParameters;
import com.bytel.ravel.common.factory.response.IRavelResponse;
import com.bytel.ravel.common.factory.response.RavelResponseFactory;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.json.IRavelJson;
import com.bytel.ravel.common.json.IRavelJsonAdapter;
import com.bytel.ravel.common.json.RavelJson.RavelJsonBuilder;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.test.podam.JavaTimeManufacturer;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.test.podam.PodamBytelJUnit4ClassRunner;
import com.bytel.ravel.common.utils.DateTimeTools.DateTimeFormatPattern;
import com.bytel.ravel.common.utils.Pair;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.RetourFactoryForTU;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.net.http.HttpConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.utils.Test_Consts;
import com.bytel.spirit.common.activities.shared.BL1700_AjouterRefFonc;
import com.bytel.spirit.common.activities.shared.BL1700_AjouterRefFonc.BL1700_AjouterRefFoncBuilder;
import com.bytel.spirit.common.activities.shared.BL5100_CreerActionCorrective;
import com.bytel.spirit.common.activities.shared.BL5100_CreerActionCorrective.BL5100_CreerActionCorrectiveBuilder;
import com.bytel.spirit.common.activities.shared.BL5110_ExecuterActionCorrective;
import com.bytel.spirit.common.activities.shared.BL5110_ExecuterActionCorrective.BL5110_ExecuterActionCorrectiveBuilder;
import com.bytel.spirit.common.activities.shared.BL800_ObtenirSequence;
import com.bytel.spirit.common.activities.shared.BL800_ObtenirSequence.BL800_ObtenirSequenceBuilder;
import com.bytel.spirit.common.connectors.cmd.CMDProxy;
import com.bytel.spirit.common.connectors.ink.ResponseConnector;
import com.bytel.spirit.common.connectors.ink.activities.PROV_SI001_LancerOrchestrateur;
import com.bytel.spirit.common.connectors.ink.activities.PROV_SI001_LancerOrchestrateur.PROV_SI001_LancerOrchestrateurBuilder;
import com.bytel.spirit.common.connectors.rst.RSTProxy;
import com.bytel.spirit.common.shared.functional.types.json.RavelJsonTools;
import com.bytel.spirit.common.shared.functional.types.json.action_corrective.ActionCorrective;
import com.bytel.spirit.common.shared.functional.types.json.action_corrective.ActionServiceTechnique;
import com.bytel.spirit.common.shared.functional.types.json.action_corrective.ActionServiceTechniqueMail;
import com.bytel.spirit.common.shared.functional.types.json.action_corrective.ActionServiceTechniqueOlt;
import com.bytel.spirit.common.shared.functional.types.json.action_corrective.RestrictionLevel;
import com.bytel.spirit.common.shared.functional.types.json.action_corrective.Status;
import com.bytel.spirit.common.shared.functional.types.json.action_corrective.TypeAction;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.TypePFS;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.mail.DonneesIdentificationSTPfsMail;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.mail.DonneesProvisionneesSTPfsMail;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.mail.StPfsMail;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.mail.TypeServiceMail;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.olt.DonneesIdentificationSTPfsOlt;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.olt.DonneesProvisionneesSTPfsOlt;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.error.ReponseErreur;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.processes.SpiritProcessSkeleton;
import com.bytel.spirit.common.shared.misc.ressources.Consts;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.cmd.Commande;
import com.bytel.spirit.common.shared.saab.cmd.NatureCommande;
import com.bytel.spirit.common.shared.saab.cmd.Statut;
import com.bytel.spirit.common.shared.saab.rst.ServiceTechnique;
import com.bytel.spirit.common.shared.saab.rst.TypeST;
import com.bytel.spirit.common.shared.types.json.ModificationCommerciale;
import com.bytel.spirit.common.shared.types.json.Suivi;
import com.bytel.spirit.prof.processes.Messages;
import com.bytel.spirit.prof.processes.PE0229.PEI0229_CommandeActionCorrective.PEI0229_CommandeActionCorrectiveContext;
import com.bytel.spirit.prof.processes.PE0229.PEI0229_CommandeActionCorrective.State;
import com.bytel.spirit.prof.processes.PE0229.structs.PEI0229_BL002_FormaterReponseCreationReturn;
import com.bytel.spirit.prof.processes.PE0229.structs.PEI0229_BL100_CreerActionCorrectiveReturn;
import com.bytel.spirit.prof.processes.PE0229.structs.PEI0229_BL101_PreparerCmdReturn;
import com.bytel.spirit.prof.processes.PE0229.structs.PEI229_Retour;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author pramos
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PowerMockListener(FieldDefaulter.class)
@PowerMockRunnerDelegate(PodamBytelJUnit4ClassRunner.class)
@ContextConfiguration("classpath:BeansProcessTestMocks.xml")
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
@PrepareForTest({ PEI0229_CommandeActionCorrective.class, BL5100_CreerActionCorrective.class, PROV_SI001_LancerOrchestrateur.class, PROV_SI001_LancerOrchestrateurBuilder.class, BL1700_AjouterRefFonc.class, BL1700_AjouterRefFoncBuilder.class, BL800_ObtenirSequence.class, BL800_ObtenirSequenceBuilder.class, PEI0229_BL100_CreerActionCorrectiveReturn.class, PEI0229_BL101_PreparerCmdReturn.class, Tracabilite.class, CMDProxy.class, RSTProxy.class, BL5110_ExecuterActionCorrectiveBuilder.class, BL5110_ExecuterActionCorrective.class })
public final class PEI0229_CommandeActionCorrectiveTest
{
  /**
   * Factory de génération des beans
   */
  private static final String DEFAULT_PROCESSNAME = PEI0229_CommandeActionCorrectiveTest.class.getSimpleName();

  /**
   * Parameter that have the URL configuration
   */
  private static final String PEP0229_NAME = "PEP0229_CommandeActionCorrective"; //$NON-NLS-1$

  /**
   * SPRING context
   */
  private static PodamFactory __podam;

  /**
   * The action corrective's identifier
   */
  private static String __idActionCorrective;

  /**
   * The requets payload
   */
  private static String __sti;

  /**
   * The X-RequestId
   */
  private static String __xRequestId;

  /**
   * The X-Source
   */
  private static String __xSource;

  /**
   * The X-MessageId
   */
  private static String __xMessageId;

  /**
   * The X-ActionId
   */
  private static String __xActionId;

  /**
   * The X-Process
   */
  private static String __xProcess;

  /**
   * Operateur client
   */
  private static String __clientOperateur;

  /**
   * Compte Number
   */
  private static String __noCompte;

  /**
   * The action corrective's identifier
   */
  private static Commande __commande;

  /**
   * Initialization method: Create: - spring context - connectors - service manager.
   *
   * @throws RavelException
   *           the exception
   */
  @BeforeClass
  public static void setUpBeforeClass() throws RavelException
  {
    // désactivation du cache podam
    __podam = new PodamFactoryImpl();
    __podam.getStrategy().setMemoization(false);
    __podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());
    JavaTimeManufacturer.registerPodamFactory(__podam);

    __sti = __podam.manufacturePojo(String.class);
    __xActionId = __podam.manufacturePojo(String.class);
    __clientOperateur = __podam.manufacturePojo(String.class);
    __xMessageId = __podam.manufacturePojo(String.class);
    __xProcess = __podam.manufacturePojo(String.class);
    __xRequestId = __podam.manufacturePojo(String.class);
    __xSource = __podam.manufacturePojo(String.class);
    __noCompte = __podam.manufacturePojo(String.class);
    __idActionCorrective = __podam.manufacturePojo(String.class);

    __commande = new Commande();
    __commande.setIdCmd(__idActionCorrective);
    __commande.setIdExterne(__xRequestId + " - " + __xMessageId); //$NON-NLS-1$
    __commande.setDateCommande(LocalDateTime.now().truncatedTo(ChronoUnit.SECONDS));
    __commande.setNatureCommande(NatureCommande.ACTION_CORRECTIVE.name()); // FIXME Create ACTION_CORRECTIVE NatureCommande in Common/SAAB
    __commande.setStatut(Statut.INITIE.toString());
    __commande.setDonneesBrut(__sti);
    __commande.setDateAcquittement(LocalDateTime.now().truncatedTo(ChronoUnit.SECONDS));
    __commande.setCodeErreur(null);
    __commande.setLibelleErreur(null);
    __commande.setListeCleSequencement(Arrays.asList(__clientOperateur + __noCompte));
    __commande.setClientOperateur(__clientOperateur);
    __commande.setNoCompte(__noCompte);
  }

  /**
   * Tracabilite
   */
  private Tracabilite _tracabilite;

  /**
   * The mock of {@ode PROV_SI001_LancerOrchestrateurBuilder}
   */
  @Mock
  private PROV_SI001_LancerOrchestrateurBuilder _provSI001BuilderMock;

  /**
   * The mock of {@code BL1700_AjouterRefFonc}
   */
  @Mock
  private BL1700_AjouterRefFonc _bl1700;

  /**
   * The mock of {@code BL1700_AjouterRefFoncBuilder}
   */
  @Mock
  private BL1700_AjouterRefFoncBuilder _bl1700builder;

  /**
   * The mock of {@code BL800_ObtenirSequence}
   */
  @Mock
  private BL800_ObtenirSequence _bl800Mock;

  /**
   * The mock of {@code PROV_SI001_LancerOrchestrateur}
   */
  @Mock
  private PROV_SI001_LancerOrchestrateur _provSI001Mock;

  /**
   * The mock of {@link BL1700_AjouterRefFonc}
   */
  @MockStrict
  protected BL1700_AjouterRefFonc _bl1700Mock;

  /**
   * The mock of {@link CMDProxy}
   */
  @Mock
  private CMDProxy _cmdProxy;
  /**
  *
  */
  @Mock
  private RSTProxy _rstProxy;

  /**
   * The mock object {@link PEI0229_BL100_CreerActionCorrectiveReturn}
   */
  @MockStrict
  private PEI0229_BL100_CreerActionCorrectiveReturn _bl100Mock;

  /**
   * The mock object {@link PEI0229_BL101_PreparerCmdReturn}
   */
  @MockStrict
  private PEI0229_BL101_PreparerCmdReturn _bl101Mock;

  /**
   * The mock object {@link SpiritProcessSkeleton}
   */
  @MockStrict
  private SpiritProcessSkeleton _activityCallerMock;

  /**
   * The mock object {@code PEI0229_CommandeActionCorrectiveContext}
   */
  @MockStrict
  private PEI0229_CommandeActionCorrectiveContext _contextMock;

  /**
   * The mock object {@code IRavelResponse}
   */
  @MockStrict
  private IRavelResponse _responseMock;

  /**
   * The mock object {@code Request}
   */
  private Request _request;

  /**
   * Instance of {@code PEI0229_CommandeActionCorrective}
   */
  private PEI0229_CommandeActionCorrective _processInstance;

  /**
   * Exception has been thrown
   */
  private boolean _exception;

  /**
   * Tests the PEI0033_BL001_VerifierDonnees_KO_001 erreur retour du connecteur RPG
   *
   *
   * <b>Expected:</b> Retour {KO; CAT4; NUMERO_COMPTE_INCONNU; "Il nexiste pas de numero de compte {0} pour le client
   * opérateur {1}"}<br>
   *
   * @throws Throwable
   *           exception
   */
  @Test
  public void PEI0229_BL001_VerifierDonneesSuiviOK_001() throws Throwable
  {
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);
    Retour retour = RetourFactoryForTU.createOkRetour();
    String methode = "GET"; //$NON-NLS-1$
    Request request = prepareRequest(tracabilite, methode);
    prepareBl1700Mock();

    PowerMock.replayAll();
    Retour retourBL001 = Whitebox.invokeMethod(_processInstance, "PEI0229_BL001_VerifierDonneesSuivi", tracabilite, request); //$NON-NLS-1$
    PowerMock.verifyAll();
    assertEquals(retourBL001.getResultat(), retour.getResultat());

  }

  /**
   * Connector CMDProxy.getInstance().commandeLireUn return KO
   *
   * @throws Exception
   *           On errors
   */
  @Test
  public void PEI0229_BL100_RechercherActionsCorrectives_KO_001() throws Exception
  {
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);
    Retour retour = RetourFactoryForTU.createKO(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, IMegSpiritConsts.ACTION_DEJA_DEMARRE, StringConstants.EMPTY_STRING);
    ConnectorResponse<Retour, Commande> connectorRep = new ConnectorResponse<>(retour, null);
    String idAction = "idcation"; //$NON-NLS-1$
    prepareCmdRequest(idAction, connectorRep);

    PowerMock.replayAll();
    Pair<Retour, ActionCorrective> retourBL100 = Whitebox.invokeMethod(_processInstance, "PEI0229_BL100_RechercherActionsCorrectives", tracabilite, idAction, false); //$NON-NLS-1$
    String libelle = "identifiant Action Corrective " + idAction + " est inconnu"; //$NON-NLS-1$ //$NON-NLS-2$
    assertEquals(retourBL100._first.getCategorie(), IMegConsts.CAT4);
    assertEquals(retourBL100._first.getDiagnostic(), IMegSpiritConsts.ID_ACTION_INCONNU);
    assertEquals(retourBL100._first.getLibelle(), libelle);
    PowerMock.verifyAll();
  }

  /**
   * Connector RSTProxy.getInstance().serviceTechniqueLireTousParPfi return KO bFiltreResStatutOnly= true statut
   * commande=DEMARRE
   *
   * @throws Exception
   *           On errors
   */
  @Test
  public void PEI0229_BL100_RechercherActionsCorrectives_KO_002() throws Exception
  {
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);

    Retour retour = RetourFactoryForTU.createOkRetour();
    String idSt = "idSt1"; //$NON-NLS-1$
    Commande commande = __podam.manufacturePojo(Commande.class);
    commande.setStatut(Statut.DEMARRE.name());
    ActionCorrective active = __podam.manufacturePojo(ActionCorrective.class);
    ActionServiceTechnique actionServiceTechnique = __podam.manufacturePojoWithFullData(ActionServiceTechniqueMail.class);
    actionServiceTechnique.setIdSt(idSt);
    actionServiceTechnique.setTypePfs(TypePFS.MAIL.name());
    active.setActionsServicesTechniques(Arrays.asList(actionServiceTechnique));

    Suivi suivi = new Suivi(Statut.DEMARRE.name());
    suivi.setLibelleErreur(commande.getLibelleErreur());
    active.setSuivi(suivi);
    commande.setDonneesBrut(RavelJsonTools.getInstance().toJson(active, ActionCorrective.class));

    ConnectorResponse<Retour, Commande> connectorRep = new ConnectorResponse<>(retour, commande);
    String idAction = "idcation"; //$NON-NLS-1$
    prepareCmdRequest(idAction, connectorRep);

    retour = RetourFactoryForTU.createKO(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, IMegSpiritConsts.ACTION_DEJA_DEMARRE, StringConstants.EMPTY_STRING);
    List<ServiceTechnique> listservtech = new ArrayList<>();
    ServiceTechnique servTech = __podam.manufacturePojo(ServiceTechnique.class);
    listservtech.add(servTech);
    ConnectorResponse<Retour, List<ServiceTechnique>> connectorRepServTech = new ConnectorResponse<>(retour, listservtech);
    prepareRSTRequest(connectorRepServTech);
    PowerMock.replayAll();
    Pair<Retour, ActionCorrective> retourBL100 = Whitebox.invokeMethod(_processInstance, "PEI0229_BL100_RechercherActionsCorrectives", tracabilite, idAction, true); //$NON-NLS-1$
    PowerMock.verifyAll();
    assertEquals(retourBL100._first.getResultat(), "KO"); //$NON-NLS-1$
    assertEquals(retourBL100._second.getSuivi().getStatut(), Statut.DEMARRE.name());
  }

  /**
   * Connector CMDProxy.getInstance().commandeLireUn return OK bFiltreResStatutOnly= false
   *
   * @throws Exception
   *           On errors
   */
  @Test
  public void PEI0229_BL100_RechercherActionsCorrectives_OK_001() throws Exception
  {
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);

    Retour retour = RetourFactoryForTU.createOkRetour();
    Commande commande = __podam.manufacturePojo(Commande.class);
    commande.setStatut(Statut.ACQUITTE.name());
    ActionCorrective active = __podam.manufacturePojo(ActionCorrective.class);
    commande.setDonneesBrut(RavelJsonTools.getInstance().toJson(active, ActionCorrective.class));

    ConnectorResponse<Retour, Commande> connectorRep = new ConnectorResponse<>(retour, commande);
    String idAction = "idcation"; //$NON-NLS-1$
    prepareCmdRequest(idAction, connectorRep);

    PowerMock.replayAll();
    Pair<Retour, ActionCorrective> retourBL100 = Whitebox.invokeMethod(_processInstance, "PEI0229_BL100_RechercherActionsCorrectives", tracabilite, idAction, false); //$NON-NLS-1$
    assertEquals(retourBL100._first.getResultat(), "OK"); //$NON-NLS-1$
    PowerMock.verifyAll();
  }

  /**
   * Connector CMDProxy.getInstance().commandeLireUn return OK bFiltreResStatutOnly= true statut commande=INITIE
   *
   * @throws Exception
   *           On errors
   */
  @Test
  public void PEI0229_BL100_RechercherActionsCorrectives_OK_002() throws Exception
  {
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);
    Retour retour = RetourFactoryForTU.createOkRetour();

    String idSt = "idSt1"; //$NON-NLS-1$
    Commande commande = __podam.manufacturePojo(Commande.class);
    commande.setStatut(Statut.INITIE.name());
    ActionCorrective active = __podam.manufacturePojo(ActionCorrective.class);
    ActionServiceTechnique actionServiceTechnique = __podam.manufacturePojoWithFullData(ActionServiceTechniqueMail.class);
    actionServiceTechnique.setIdSt(idSt);
    actionServiceTechnique.setTypePfs(TypePFS.MAIL.name());
    active.setActionsServicesTechniques(Arrays.asList(actionServiceTechnique));

    Suivi suivi = new Suivi(Statut.INITIE.name());
    suivi.setLibelleErreur(commande.getLibelleErreur());
    active.setSuivi(suivi);
    commande.setDonneesBrut(RavelJsonTools.getInstance().toJson(active, ActionCorrective.class));

    ConnectorResponse<Retour, Commande> connectorRep = new ConnectorResponse<>(retour, commande);
    String idAction = "idcation"; //$NON-NLS-1$
    prepareCmdRequest(idAction, connectorRep);

    PowerMock.replayAll();
    Pair<Retour, ActionCorrective> retourBL100 = Whitebox.invokeMethod(_processInstance, "PEI0229_BL100_RechercherActionsCorrectives", tracabilite, idAction, true); //$NON-NLS-1$
    PowerMock.verifyAll();
    assertEquals(retourBL100._first.getResultat(), "OK"); //$NON-NLS-1$
    assertEquals(retourBL100._second.getSuivi().getStatut(), Statut.PROPOSE.name());
  }

  /**
   * Connector CMDProxy.getInstance().commandeLireUn return OK bFiltreResStatutOnly= true statut commande=EN_COURS
   *
   * @throws Exception
   *           On errors
   */
  @Test
  public void PEI0229_BL100_RechercherActionsCorrectives_OK_003() throws Exception
  {
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);

    Retour retour = RetourFactoryForTU.createOkRetour();

    String idSt = "idSt1"; //$NON-NLS-1$
    Commande commande = __podam.manufacturePojo(Commande.class);
    commande.setStatut(Statut.ACQUITTE.name());
    ActionCorrective active = __podam.manufacturePojo(ActionCorrective.class);
    ActionServiceTechnique actionServiceTechnique = __podam.manufacturePojoWithFullData(ActionServiceTechniqueMail.class);
    actionServiceTechnique.setIdSt(idSt);
    actionServiceTechnique.setTypePfs(TypePFS.MAIL.name());
    active.setActionsServicesTechniques(Arrays.asList(actionServiceTechnique));

    Suivi suivi = new Suivi(Statut.ACQUITTE.name());
    suivi.setLibelleErreur(commande.getLibelleErreur());
    active.setSuivi(suivi);
    commande.setDonneesBrut(RavelJsonTools.getInstance().toJson(active, ActionCorrective.class));

    ConnectorResponse<Retour, Commande> connectorRep = new ConnectorResponse<>(retour, commande);
    String idAction = "idcation"; //$NON-NLS-1$
    prepareCmdRequest(idAction, connectorRep);

    PowerMock.replayAll();
    Pair<Retour, ActionCorrective> retourBL100 = Whitebox.invokeMethod(_processInstance, "PEI0229_BL100_RechercherActionsCorrectives", tracabilite, idAction, true); //$NON-NLS-1$
    PowerMock.verifyAll();
    assertEquals(retourBL100._first.getResultat(), "OK"); //$NON-NLS-1$
    assertEquals(retourBL100._second.getSuivi().getStatut(), Statut.EN_COURS.name());
  }

  /**
   * Connector CMDProxy.getInstance().commandeLireUn return OK bFiltreResStatutOnly= true statut commande=TRAITE_OK
   *
   * @throws Exception
   *           On errors
   */
  @Test
  public void PEI0229_BL100_RechercherActionsCorrectives_OK_005() throws Exception
  {
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);

    Retour retour = RetourFactoryForTU.createOkRetour();
    String idSt = "idSt1"; //$NON-NLS-1$
    Commande commande = __podam.manufacturePojo(Commande.class);
    commande.setStatut(Statut.TRAITE_OK.name());
    ActionCorrective active = __podam.manufacturePojo(ActionCorrective.class);
    ActionServiceTechnique actionServiceTechnique = __podam.manufacturePojoWithFullData(ActionServiceTechniqueMail.class);
    actionServiceTechnique.setIdSt(idSt);
    actionServiceTechnique.setTypePfs(TypePFS.MAIL.name());
    active.setActionsServicesTechniques(Arrays.asList(actionServiceTechnique));

    Suivi suivi = new Suivi(Statut.TRAITE_OK.name());
    suivi.setLibelleErreur(commande.getLibelleErreur());
    active.setSuivi(suivi);
    commande.setDonneesBrut(RavelJsonTools.getInstance().toJson(active, ActionCorrective.class));

    ConnectorResponse<Retour, Commande> connectorRep = new ConnectorResponse<>(retour, commande);
    String idAction = "idcation"; //$NON-NLS-1$
    prepareCmdRequest(idAction, connectorRep);

    PowerMock.replayAll();
    Pair<Retour, ActionCorrective> retourBL100 = Whitebox.invokeMethod(_processInstance, "PEI0229_BL100_RechercherActionsCorrectives", tracabilite, idAction, true); //$NON-NLS-1$

    PowerMock.verifyAll();
    assertEquals(retourBL100._first.getResultat(), "OK"); //$NON-NLS-1$
    assertEquals(retourBL100._second.getSuivi().getStatut(), Statut.TRAITE.name());
  }

  /**
   * Connector CMDProxy.getInstance().commandeLireUn return OK bFiltreResStatutOnly= true statut commande=TRAITE_NOK
   *
   * @throws Exception
   *           On errors
   */
  @Test
  public void PEI0229_BL100_RechercherActionsCorrectives_OK_006() throws Exception
  {
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);

    Retour retour = RetourFactoryForTU.createOkRetour();
    String idSt = "idSt1"; //$NON-NLS-1$
    Commande commande = __podam.manufacturePojo(Commande.class);
    commande.setStatut(Statut.TRAITE_NOK.name());
    ActionCorrective active = __podam.manufacturePojo(ActionCorrective.class);
    ActionServiceTechnique actionServiceTechnique = __podam.manufacturePojoWithFullData(ActionServiceTechniqueMail.class);
    actionServiceTechnique.setIdSt(idSt);
    actionServiceTechnique.setTypePfs(TypePFS.MAIL.name());
    active.setActionsServicesTechniques(Arrays.asList(actionServiceTechnique));

    Suivi suivi = new Suivi(Statut.TRAITE_NOK.name());
    suivi.setLibelleErreur(commande.getLibelleErreur());
    active.setSuivi(suivi);
    commande.setDonneesBrut(RavelJsonTools.getInstance().toJson(active, ActionCorrective.class));

    ConnectorResponse<Retour, Commande> connectorRep = new ConnectorResponse<>(retour, commande);
    String idAction = "idcation"; //$NON-NLS-1$
    prepareCmdRequest(idAction, connectorRep);

    PowerMock.replayAll();
    Pair<Retour, ActionCorrective> retourBL100 = Whitebox.invokeMethod(_processInstance, "PEI0229_BL100_RechercherActionsCorrectives", tracabilite, idAction, true); //$NON-NLS-1$
    PowerMock.verifyAll();
    assertEquals(retourBL100._first.getResultat(), "OK"); //$NON-NLS-1$
    assertEquals(retourBL100._second.getSuivi().getStatut(), Statut.INVALIDE.name());
  }

  /**
   * Connector CMDProxy.getInstance().commandeLireUn return OK bFiltreResStatutOnly= true statut commande=DEMARRE
   *
   * @throws Exception
   *           On errors
   */
  @Test
  public void PEI0229_BL100_RechercherActionsCorrectives_OK_008() throws Exception
  {
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);

    Retour retour = RetourFactoryForTU.createOkRetour();

    String idSt = "idSt1"; //$NON-NLS-1$
    Commande commande = __podam.manufacturePojo(Commande.class);
    commande.setStatut(Statut.DEMARRE.name());
    ActionCorrective active = __podam.manufacturePojo(ActionCorrective.class);
    ActionServiceTechnique actionServiceTechnique = __podam.manufacturePojoWithFullData(ActionServiceTechniqueMail.class);
    actionServiceTechnique.setIdSt(idSt);
    actionServiceTechnique.setTypePfs(TypePFS.MAIL.name());
    active.setActionsServicesTechniques(Arrays.asList(actionServiceTechnique));

    Suivi suivi = new Suivi(Statut.DEMARRE.name());
    suivi.setLibelleErreur(commande.getLibelleErreur());
    active.setSuivi(suivi);
    commande.setDonneesBrut(RavelJsonTools.getInstance().toJson(active, ActionCorrective.class));

    ConnectorResponse<Retour, Commande> connectorRep = new ConnectorResponse<>(retour, commande);
    String idAction = "idcation"; //$NON-NLS-1$
    prepareCmdRequest(idAction, connectorRep);

    // retour = RetourFactoryForTU.createKO(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, IMegSpiritConsts.ACTION_DEJA_DEMARRE, "");
    List<ServiceTechnique> listservtech = new ArrayList<>();
    StPfsMail servTech = __podam.manufacturePojo(StPfsMail.class);
    listservtech.add(servTech);
    ConnectorResponse<Retour, List<ServiceTechnique>> connectorRepServTech = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), listservtech);
    prepareRSTRequest(connectorRepServTech);
    PowerMock.replayAll();
    Pair<Retour, ActionCorrective> retourBL100 = Whitebox.invokeMethod(_processInstance, "PEI0229_BL100_RechercherActionsCorrectives", tracabilite, idAction, true); //$NON-NLS-1$
    PowerMock.verifyAll();
    assertEquals(retourBL100._first.getResultat(), "OK"); //$NON-NLS-1$
    assertEquals(retourBL100._second.getSuivi().getStatut(), Statut.DEMARRE.name());
  }

  /**
   * Connector CMDProxy.getInstance().commandeLireUn return OK bFiltreResStatutOnly= true statut commande=DEMARRE
   *
   * Service TEchnique.idSt = idSt1; Service Technique.statut = ECHEC;
   *
   * @throws Exception
   *           On errors
   */
  @Test
  public void PEI0229_BL100_RechercherActionsCorrectives_OK_009() throws Exception
  {
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);

    Retour retour = RetourFactoryForTU.createOkRetour();

    String idSt = "idSt1"; //$NON-NLS-1$
    Commande commande = __podam.manufacturePojo(Commande.class);
    commande.setStatut(Statut.DEMARRE.name());
    ActionCorrective active = __podam.manufacturePojo(ActionCorrective.class);
    ActionServiceTechnique actionServiceTechnique = __podam.manufacturePojoWithFullData(ActionServiceTechniqueMail.class);
    actionServiceTechnique.setIdSt(idSt);
    actionServiceTechnique.setTypePfs(TypePFS.MAIL.name());
    active.setActionsServicesTechniques(Arrays.asList(actionServiceTechnique));

    Suivi suivi = new Suivi(Statut.DEMARRE.name());
    suivi.setLibelleErreur(commande.getLibelleErreur());
    active.setSuivi(suivi);
    commande.setDonneesBrut(RavelJsonTools.getInstance().toJson(active, ActionCorrective.class));

    ConnectorResponse<Retour, Commande> connectorRep = new ConnectorResponse<>(retour, commande);
    String idAction = "idcation"; //$NON-NLS-1$
    prepareCmdRequest(idAction, connectorRep);

    // retour = RetourFactoryForTU.createKO(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, IMegSpiritConsts.ACTION_DEJA_DEMARRE, "");
    List<ServiceTechnique> listservtech = new ArrayList<>();
    StPfsMail servTech = __podam.manufacturePojo(StPfsMail.class);
    servTech.setIdSt(idSt);
    servTech.setStatut("ECHEC"); //$NON-NLS-1$
    listservtech.add(servTech);
    ConnectorResponse<Retour, List<ServiceTechnique>> connectorRepServTech = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), listservtech);
    prepareRSTRequest(connectorRepServTech);
    PowerMock.replayAll();
    Pair<Retour, ActionCorrective> retourBL100 = Whitebox.invokeMethod(_processInstance, "PEI0229_BL100_RechercherActionsCorrectives", tracabilite, idAction, true); //$NON-NLS-1$
    PowerMock.verifyAll();
    assertEquals(retourBL100._first.getResultat(), "OK"); //$NON-NLS-1$
    assertEquals(Statut.INTERVENTION_SUPPORT.name(), retourBL100._second.getSuivi().getStatut());
  }

  /**
   * cas nominal PEI0229_CommandeActionCorrective cas KO status Only
   *
   * @throws Throwable
   *           On errors
   */
  @Test
  public void PEI0229_CommandeActionCorrective_BL100_KO_001() throws Throwable
  {
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);
    Retour retour = RetourFactoryForTU.createKO(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, IMegSpiritConsts.ACTION_DEJA_DEMARRE, StringConstants.EMPTY_STRING);
    ConnectorResponse<Retour, Commande> connectorRep = new ConnectorResponse<>(retour, null);
    String idAction = "idSuivi"; //$NON-NLS-1$
    String methode = "GET"; //$NON-NLS-1$
    Request request = prepareRequest(tracabilite, methode);
    prepareBl1700Mock();
    prepareCmdRequest(idAction, connectorRep);

    request.setOperation("PEI0229_CommandeActionCorrective_Suivi_EXT"); //$NON-NLS-1$
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    //Response expected
    String infoErreur = "identifiant Action Corrective idSuivi est inconnu"; //$NON-NLS-1$
    ReponseErreur responseErreur = new ReponseErreur();
    responseErreur.setErrorDescription(infoErreur);
    responseErreur.setError("ID_ACTION_INCONNU"); //$NON-NLS-1$
    String result = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss).toJson(responseErreur);

    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    response.setResult(result);
    final Response expected = new Response(ErrorCode.KO_00404, response);
    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());
    assertEquals(expected.getMarshalledResponseJson(), request.getResponse().getMarshalledResponseJson());
  }

  @Test
  public void PEI0229_Deserialization() throws Throwable
  {
    ActionCorrective ActionCorrective;
    IRavelJson instance = new RavelJsonBuilder() //
        .profil("STARK") //$NON-NLS-1$
        .build();
    String json = "{ \"actionsServicesTechniques\": [ { \"dateModification\": \"2019-01-22T10:32:01.277+0100\", \"idSt\": \"92161264-1e28-11e9-9233-0050568d237e\", \"statut\": \"INDETERMINE\",  \"typeAction\": \"MODIFICATION\", \"typeServiceTechnique\": \"PFS\" } ],  \"clientOperateur\": \"BSS_GP\",  \"noCompte\": \"610023341423\" }"; //$NON-NLS-1$

    final IRavelJsonAdapter<ActionCorrective> adapter = instance.adapter(ActionCorrective.class);
    ActionCorrective = adapter.fromJson(json);

  }

  /**
   * cas ou BL5110 KO (IMegConsts.CAT10, IMegConsts.DONNEE_INCONNUE, IMegSpiritConsts.ACTION_DEJA_DEMARRE)
   *
   * @throws Throwable
   *           exception
   */
  @Test
  public void PEI0229_PUT_BL001_VerifierDonnesModification_KO_001() throws Throwable
  {
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);
    String methode = "PUT"; //$NON-NLS-1$
    Request request = prepareRequest(tracabilite, methode);
    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    list.add(new Parameter("action", "executerAction")); //$NON-NLS-1$ //$NON-NLS-2$
    urlParametersType.setUrlParameters(list);
    request.setUrlParameters(urlParametersType);
    Retour retour = RetourFactoryForTU.createKO(IMegConsts.CAT4, IMegSpiritConsts.ID_ACTION_INCONNU, "identifant Action Corrective idSuivi est inconnu.", StringConstants.EMPTY_STRING); //$NON-NLS-1$
    String idAction = "idSuivi"; //$NON-NLS-1$
    prepareBl1700Mock();
    prepareBL5110(idAction, retour);
    PowerMock.replayAll();

    _processInstance.run(request);

    PowerMock.verifyAll();
    //result

    ReponseErreur responseErrResult = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss, DateTimeFormatPattern.yyyy_dash_MM_dash_dd).fromJson(request.getResponse().getGenericResponse().getResult(), ReponseErreur.class);

    //Response expected
    ReponseErreur responseErr = new ReponseErreur();
    responseErr.setError(IMegSpiritConsts.ID_ACTION_INCONNU);
    responseErr.setErrorDescription("identifant Action Corrective idSuivi est inconnu."); //$NON-NLS-1$
    ReponseErreur responseErrExpected = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss, DateTimeFormatPattern.yyyy_dash_MM_dash_dd).fromJson(request.getResponse().getGenericResponse().getResult(), ReponseErreur.class);
    String resultexpected = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(responseErrExpected);
    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    response.setResult(resultexpected);
    final Response expected = new Response(ErrorCode.KO_00404, response);

    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());
    assertEquals(responseErrResult.getError(), responseErr.getError());
    assertEquals(responseErrResult.getErrorDescription(), responseErr.getErrorDescription());
  }

  /**
   * cas ou BL5110 KO (IMegConsts.CAT10, IMegConsts.DONNEE_INCONNUE, IMegSpiritConsts.ACTION_DEJA_DEMARRE)
   *
   * @throws Throwable
   *           exception
   */
  @Test
  public void PEI0229_PUT_BL001_VerifierDonnesModification_KO_002() throws Throwable
  {
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);
    String methode = "PUT"; //$NON-NLS-1$
    Request request = prepareRequest(tracabilite, methode);
    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    list.add(new Parameter("action", "executerAction")); //$NON-NLS-1$ //$NON-NLS-2$
    urlParametersType.setUrlParameters(list);
    request.setUrlParameters(urlParametersType);
    Retour retour = RetourFactoryForTU.createKO(IMegConsts.CAT4, IMegSpiritConsts.ERREUR_INTERNE, "identifant Action Corrective idSuivi est inconnu.", StringConstants.EMPTY_STRING); //$NON-NLS-1$
    String idAction = "idSuivi"; //$NON-NLS-1$
    prepareBl1700Mock();
    prepareBL5110(idAction, retour);
    PowerMock.replayAll();

    _processInstance.run(request);

    PowerMock.verifyAll();
    //result

    ReponseErreur responseErrResult = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss, DateTimeFormatPattern.yyyy_dash_MM_dash_dd).fromJson(request.getResponse().getGenericResponse().getResult(), ReponseErreur.class);

    //Response expected
    ReponseErreur responseErr = new ReponseErreur();
    responseErr.setError(IMegSpiritConsts.ID_ACTION_INCONNU);
    responseErr.setErrorDescription("identifant Action Corrective idSuivi est inconnu."); //$NON-NLS-1$
    ReponseErreur responseErrExpected = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss, DateTimeFormatPattern.yyyy_dash_MM_dash_dd).fromJson(request.getResponse().getGenericResponse().getResult(), ReponseErreur.class);
    String resultexpected = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(responseErrExpected);
    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    response.setResult(resultexpected);
    final Response expected = new Response(ErrorCode.KO_00500, response);

    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());
  }

  /**
   * Non Respect de la STI
   *
   * @throws Throwable
   *           On errors
   *
   */
  @Test
  public void PEI0229_PUT_KO_001() throws Throwable
  {
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);
    _request.setHttpMethod("PUT"); //$NON-NLS-1$
    _request.setPayload(null);

    String methode = "PUT"; //$NON-NLS-1$
    Request request = prepareRequest(tracabilite, methode);

    PowerMock.replayAll();

    _processInstance.run(request);

    PowerMock.verifyAll();
    //result

    ReponseErreur responseErrResult = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss, DateTimeFormatPattern.yyyy_dash_MM_dash_dd).fromJson(request.getResponse().getGenericResponse().getResult(), ReponseErreur.class);

    //Response expected
    ReponseErreur responseErr = new ReponseErreur();
    responseErr.setError(IMegSpiritConsts.NON_RESPECT_STI);
    responseErr.setErrorDescription("Le paramètre action est obligatoire."); //$NON-NLS-1$
    ReponseErreur responseErrExpected = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss, DateTimeFormatPattern.yyyy_dash_MM_dash_dd).fromJson(request.getResponse().getGenericResponse().getResult(), ReponseErreur.class);
    String resultexpected = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss).toJson(responseErrExpected);
    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    response.setResult(resultexpected);
    final Response expected = new Response(ErrorCode.KO_00400, response);

    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());
    assertEquals(responseErrResult.getError(), responseErr.getError());
    assertEquals(responseErrResult.getErrorDescription(), responseErr.getErrorDescription());
  }

  /**
   * cas ou PEI0229_PUT_BL5110_Retour_Null
   *
   *
   * @throws Throwable
   *           exception
   */
  @Test
  public void PEI0229_PUT_KO_BL5110() throws Throwable
  {
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);
    String methode = "PUT"; //$NON-NLS-1$
    Request request = prepareRequest(tracabilite, methode);
    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    list.add(new Parameter("action", "executerAction")); //$NON-NLS-1$ //$NON-NLS-2$
    urlParametersType.setUrlParameters(list);
    request.setUrlParameters(urlParametersType);
    Retour retour = RetourFactory.createKO(IMegConsts.CAT2, Consts.SERVICE_INDISPONIBLE.name(), "Error when calling BL5110_ExecuterActionCorrective"); //$NON-NLS-1$
    Commande commande = __podam.manufacturePojo(Commande.class);
    commande.setStatut(Statut.INITIE.name());
    String idAction = "idSuivi"; //$NON-NLS-1$
    prepareBL5110(idAction, null);
    prepareBl1700Mock();
    List<String> keys = new ArrayList<>();
    keys.add("idCmd"); //$NON-NLS-1$
    List<String> values = new ArrayList<>();
    values.add(commande.getIdCmd());
    PowerMock.replayAll();

    _processInstance.run(request);

    PowerMock.verifyAll();

    //Response expected
    ReponseErreur responseErr = new ReponseErreur();
    responseErr.setError(IMegConsts.DONNEE_INCONNUE);
    responseErr.setErrorDescription("ACTION_DEJA_DEMARRE"); //$NON-NLS-1$
    ReponseErreur responseErrExpected = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss, DateTimeFormatPattern.yyyy_dash_MM_dash_dd).fromJson(request.getResponse().getGenericResponse().getResult(), ReponseErreur.class);
    String resultexpected = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(responseErrExpected);
    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    response.setResult(resultexpected);
    final Response expected = new Response(ErrorCode.KO_00503, response);

    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());

  }

  /**
   * cas ou PEI0229_PUT_NOMINAL
   *
   *
   * @throws Throwable
   *           exception
   */
  @Test
  public void PEI0229_PUT_KO_Exception() throws Throwable
  {
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);
    String methode = "PUT"; //$NON-NLS-1$
    Request request = prepareRequest(tracabilite, methode);
    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    list.add(new Parameter("action", "executerAction")); //$NON-NLS-1$ //$NON-NLS-2$
    urlParametersType.setUrlParameters(list);
    request.setUrlParameters(urlParametersType);
    Retour retour = RetourFactory.createKO(IMegConsts.CAT2, Consts.SERVICE_INDISPONIBLE.name(), "Error when calling BL5110_ExecuterActionCorrective"); //$NON-NLS-1$
    Commande commande = __podam.manufacturePojo(Commande.class);
    commande.setStatut(Statut.INITIE.name());
    String idAction = "idSuivi"; //$NON-NLS-1$
    //prepareBL5110(idAction, null);
    prepareBL5110Exception(idAction);
    prepareBl1700Mock();
    List<String> keys = new ArrayList<>();
    keys.add("idCmd"); //$NON-NLS-1$
    List<String> values = new ArrayList<>();
    values.add(commande.getIdCmd());
    PowerMock.replayAll();

    _processInstance.run(request);

    PowerMock.verifyAll();

    //Response expected
    ReponseErreur responseErr = new ReponseErreur();
    responseErr.setError(IMegConsts.DONNEE_INCONNUE);
    responseErr.setErrorDescription("ACTION_DEJA_DEMARRE"); //$NON-NLS-1$
    ReponseErreur responseErrExpected = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss, DateTimeFormatPattern.yyyy_dash_MM_dash_dd).fromJson(request.getResponse().getGenericResponse().getResult(), ReponseErreur.class);
    String resultexpected = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(responseErrExpected);
    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    response.setResult(resultexpected);
    final Response expected = new Response(ErrorCode.KO_00503, response);

    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());

  }

  /**
   * cas ou PEI0229_PUT_NOMINAL
   *
   *
   * @throws Throwable
   *           exception
   */
  @Test
  public void PEI0229_PUT_NOMINAL_OK_001() throws Throwable
  {
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);
    String methode = "PUT"; //$NON-NLS-1$
    Request request = prepareRequest(tracabilite, methode);
    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    list.add(new Parameter("action", "executerAction")); //$NON-NLS-1$ //$NON-NLS-2$
    urlParametersType.setUrlParameters(list);
    request.setUrlParameters(urlParametersType);
    Retour retour = RetourFactoryForTU.createOkRetour();
    Commande commande = __podam.manufacturePojo(Commande.class);
    commande.setStatut(Statut.INITIE.name());
    String idAction = "idSuivi"; //$NON-NLS-1$
    prepareBL5110(idAction, retour);
    prepareBl1700Mock();
    List<String> keys = new ArrayList<>();
    keys.add("idCmd"); //$NON-NLS-1$
    List<String> values = new ArrayList<>();
    values.add(commande.getIdCmd());
    PowerMock.replayAll();

    _processInstance.run(request);

    PowerMock.verifyAll();

    //Response expected
    ReponseErreur responseErr = new ReponseErreur();
    responseErr.setError(IMegConsts.DONNEE_INCONNUE);
    responseErr.setErrorDescription("ACTION_DEJA_DEMARRE"); //$NON-NLS-1$
    ReponseErreur responseErrExpected = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss, DateTimeFormatPattern.yyyy_dash_MM_dash_dd).fromJson(request.getResponse().getGenericResponse().getResult(), ReponseErreur.class);
    String resultexpected = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(responseErrExpected);
    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    response.setResult(resultexpected);
    final Response expected = new Response(ErrorCode.OK_00202, response);

    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());

  }

  /**
   * Initialization of tests
   *
   * @throws Exception
   *           Exception to be thrown in case of failure
   */
  @Before
  public void setUp() throws Exception
  {
    _exception = false;
    _processInstance = new PEI0229_CommandeActionCorrective();
    _processInstance.initializeContext();

    _tracabilite = new Tracabilite();
    _tracabilite.setIdProcessusSpirit(_processInstance.getIdProcess());
    _tracabilite.setIdCorrelationSpirit(Test_Consts.DEFAULT_MSGID);
    _tracabilite.setIdCorrelationByTel(StringConstants.EMPTY_STRING);
    _tracabilite.setNomProcessus(StringConstants.EMPTY_STRING);
    _tracabilite.setNomSysteme(System.getenv("SERVICE")); //$NON-NLS-1$

    // on réinitialise tous les mocks afin de ne pas avoir d'interférence entre les tests
    PowerMock.resetAll();

    PowerMock.mockStaticStrict(CMDProxy.class);
    PowerMock.mockStaticStrict(RSTProxy.class);
    PowerMock.mockStaticStrict(BL1700_AjouterRefFonc.class);
    PowerMock.mockStaticStrict(PROV_SI001_LancerOrchestrateur.class);

    _request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    final RequestHeader requestHeader3 = new RequestHeader();
    requestHeader3.setName(IHttpHeadersConsts.X_SOURCE);
    requestHeader3.setValue("IHM_SPIRIT"); //$NON-NLS-1$
    _request.getRequestHeader().add(requestHeader3);

    final RequestHeader requestHeader2 = new RequestHeader();
    requestHeader2.setName(IHttpHeadersConsts.X_PROCESS);
    requestHeader2.setValue("ACTION CORRECTIVE"); //$NON-NLS-1$
    _request.getRequestHeader().add(requestHeader2);

    final RequestHeader requestHeader4 = new RequestHeader();
    requestHeader4.setName(IHttpHeadersConsts.X_REQUEST_ID);
    requestHeader4.setValue("123415151515151"); //$NON-NLS-1$
    _request.getRequestHeader().add(requestHeader4);

    final RequestHeader requestHeader5 = new RequestHeader();
    requestHeader5.setName(IHttpHeadersConsts.X_MESSAGE_ID);
    requestHeader5.setValue("222222222"); //$NON-NLS-1$
    _request.getRequestHeader().add(requestHeader5);

    final RequestHeader requestHeader6 = new RequestHeader();
    requestHeader6.setName(IHttpHeadersConsts.X_ACTION_ID);
    requestHeader6.setValue("23423werr2354345"); //$NON-NLS-1$
    _request.getRequestHeader().add(requestHeader6);
  }

  /**
   * PEI0229_CommandeActionCorrective not status Only
   *
   * @throws Throwable
   *           On errors
   */
  @Test
  public void test_PEI0229_GET_Nominal_Not_status_Only() throws Throwable
  {
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);
    Retour retour = RetourFactoryForTU.createOkRetour();

    Commande commande = __podam.manufacturePojo(Commande.class);
    commande.setStatut(Statut.DEMARRE.name());
    ActionCorrective active = __podam.manufacturePojo(ActionCorrective.class);
    Suivi suivi = new Suivi(Statut.DEMARRE.name());
    active.setSuivi(suivi);
    commande.setDonneesBrut(RavelJsonTools.getInstance().toJson(active, ActionCorrective.class));

    String methode = "GET"; //$NON-NLS-1$
    Request request = prepareRequest(tracabilite, methode);

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    //Response expected

    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    final Response expected = new Response(ErrorCode.KO_00503, response);
    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());

  }

  /**
   * cas nominal PEI0229_CommandeActionCorrective,<br/>
   *
   * Retour diagnostic: "NON_RESPECT_STI"
   *
   * @throws Throwable
   *           On errors
   */
  @Test
  public void test_PEI0229_GET_Nominal_Not_status_Only_002() throws Throwable
  {
    String idSt = "st1"; //$NON-NLS-1$
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);
    Retour retour = RetourFactory.createKO(StringConstants.EMPTY_STRING, "NON_RESPECT_STI", StringConstants.EMPTY_STRING); //$NON-NLS-1$

    Commande commande = __podam.manufacturePojo(Commande.class);
    commande.setStatut(Statut.DEMARRE.name());
    ActionCorrective active = __podam.manufacturePojo(ActionCorrective.class);
    ActionServiceTechnique actionServiceTechnique = __podam.manufacturePojoWithFullData(ActionServiceTechniqueMail.class);
    actionServiceTechnique.setIdSt(idSt);
    actionServiceTechnique.setTypePfs(TypePFS.MAIL.name());
    active.setActionsServicesTechniques(Arrays.asList(actionServiceTechnique));

    Suivi suivi = new Suivi(Statut.DEMARRE.name());
    suivi.setLibelleErreur(commande.getLibelleErreur());
    active.setSuivi(suivi);
    commande.setDonneesBrut(RavelJsonTools.getInstance().toJson(active, ActionCorrective.class));
    ConnectorResponse<Retour, Commande> connectorRep = new ConnectorResponse<>(retour, commande);
    String idAction = "idSuivi"; //$NON-NLS-1$

    String methode = "GET"; //$NON-NLS-1$
    Request request = prepareRequest(tracabilite, methode);
    //operation suivi
    request.setOperation("PEI0229_CommandeActionCorrective_Suivi"); //$NON-NLS-1$

    prepareBl1700Mock();
    prepareCmdRequest(idAction, connectorRep);

    List<ServiceTechnique> listservtech = new ArrayList<>();
    StPfsMail servTech = __podam.manufacturePojo(StPfsMail.class);
    servTech.setIdSt(idSt);
    servTech.setTypeServiceTechnique(TypeST.PFS.name());
    servTech.setTypePfs(TypePFS.MAIL.name());
    listservtech.add(servTech);
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    //Response expected
    PEI229_Retour pei229 = new PEI229_Retour();
    pei229.setSuivi(active.getSuivi());

    String resultexpected = RavelJsonTools.getInstance().toJson(pei229.getSuivi(), Suivi.class);

    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    response.setResult(resultexpected);
    final Response expected = new Response(ErrorCode.KO_00400, response);

    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());
  }

  /**
   * cas nominal PEI0229_CommandeActionCorrective,<br/>
   *
   * Retour diagnostic: "ID_ACTION_INCONNU"
   *
   * @throws Throwable
   *           On errors
   */
  @Test
  public void test_PEI0229_GET_Nominal_Not_status_Only_003() throws Throwable
  {
    String idSt = "st1"; //$NON-NLS-1$
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);
    Retour retour = RetourFactory.createKO(StringConstants.EMPTY_STRING, "ID_ACTION_INCONNU", StringConstants.EMPTY_STRING); //$NON-NLS-1$

    Commande commande = __podam.manufacturePojo(Commande.class);
    commande.setStatut(Statut.DEMARRE.name());
    ActionCorrective active = __podam.manufacturePojo(ActionCorrective.class);
    ActionServiceTechnique actionServiceTechnique = __podam.manufacturePojoWithFullData(ActionServiceTechniqueMail.class);
    actionServiceTechnique.setIdSt(idSt);
    actionServiceTechnique.setTypePfs(TypePFS.MAIL.name());
    active.setActionsServicesTechniques(Arrays.asList(actionServiceTechnique));

    Suivi suivi = new Suivi(Statut.DEMARRE.name());
    suivi.setLibelleErreur(commande.getLibelleErreur());
    active.setSuivi(suivi);
    commande.setDonneesBrut(RavelJsonTools.getInstance().toJson(active, ActionCorrective.class));
    ConnectorResponse<Retour, Commande> connectorRep = new ConnectorResponse<>(retour, commande);
    String idAction = "idSuivi"; //$NON-NLS-1$

    String methode = "GET"; //$NON-NLS-1$
    Request request = prepareRequest(tracabilite, methode);
    //operation suivi
    request.setOperation("PEI0229_CommandeActionCorrective_Suivi"); //$NON-NLS-1$

    prepareBl1700Mock();
    prepareCmdRequest(idAction, connectorRep);

    List<ServiceTechnique> listservtech = new ArrayList<>();
    StPfsMail servTech = __podam.manufacturePojo(StPfsMail.class);
    servTech.setIdSt(idSt);
    servTech.setTypeServiceTechnique(TypeST.PFS.name());
    servTech.setTypePfs(TypePFS.MAIL.name());
    listservtech.add(servTech);
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    //Response expected
    PEI229_Retour pei229 = new PEI229_Retour();
    pei229.setSuivi(active.getSuivi());

    String resultexpected = RavelJsonTools.getInstance().toJson(pei229.getSuivi(), Suivi.class);

    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    response.setResult(resultexpected);
    final Response expected = new Response(ErrorCode.KO_00404, response);

    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());
  }

  /**
   * cas nominal PEI0229_CommandeActionCorrective,<br/>
   *
   * Retour diagnostic: "ERREUR_INTERNE"
   *
   * @throws Throwable
   *           On errors
   */
  @Test
  public void test_PEI0229_GET_Nominal_Not_status_Only_004() throws Throwable
  {
    String idSt = "st1"; //$NON-NLS-1$
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);
    Retour retour = RetourFactory.createKO(StringConstants.EMPTY_STRING, "ERREUR_INTERNE", StringConstants.EMPTY_STRING); //$NON-NLS-1$

    Commande commande = __podam.manufacturePojo(Commande.class);
    commande.setStatut(Statut.DEMARRE.name());
    ActionCorrective active = __podam.manufacturePojo(ActionCorrective.class);
    ActionServiceTechnique actionServiceTechnique = __podam.manufacturePojoWithFullData(ActionServiceTechniqueMail.class);
    actionServiceTechnique.setIdSt(idSt);
    actionServiceTechnique.setTypePfs(TypePFS.MAIL.name());
    active.setActionsServicesTechniques(Arrays.asList(actionServiceTechnique));

    Suivi suivi = new Suivi(Statut.DEMARRE.name());
    suivi.setLibelleErreur(commande.getLibelleErreur());
    active.setSuivi(suivi);
    commande.setDonneesBrut(RavelJsonTools.getInstance().toJson(active, ActionCorrective.class));
    ConnectorResponse<Retour, Commande> connectorRep = new ConnectorResponse<>(retour, commande);
    String idAction = "idSuivi"; //$NON-NLS-1$

    String methode = "GET"; //$NON-NLS-1$
    Request request = prepareRequest(tracabilite, methode);
    //operation suivi
    request.setOperation("PEI0229_CommandeActionCorrective_Suivi"); //$NON-NLS-1$

    prepareBl1700Mock();
    prepareCmdRequest(idAction, connectorRep);

    List<ServiceTechnique> listservtech = new ArrayList<>();
    StPfsMail servTech = __podam.manufacturePojo(StPfsMail.class);
    servTech.setIdSt(idSt);
    servTech.setTypeServiceTechnique(TypeST.PFS.name());
    servTech.setTypePfs(TypePFS.MAIL.name());
    listservtech.add(servTech);
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    //Response expected
    PEI229_Retour pei229 = new PEI229_Retour();
    pei229.setSuivi(active.getSuivi());

    String resultexpected = RavelJsonTools.getInstance().toJson(pei229.getSuivi(), Suivi.class);

    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    response.setResult(resultexpected);
    final Response expected = new Response(ErrorCode.KO_00500, response);

    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());
  }

  /**
   * cas nominal PEI0229_CommandeActionCorrective cas nominal status Only
   *
   * @throws Throwable
   *           On errors
   */
  @Test
  public void test_PEI0229_GET_Nominal_status_Only() throws Throwable
  {
    String idSt = "st1"; //$NON-NLS-1$
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);
    Retour retour = RetourFactoryForTU.createOkRetour();

    Commande commande = __podam.manufacturePojo(Commande.class);
    commande.setStatut(Statut.DEMARRE.name());
    ActionCorrective active = __podam.manufacturePojo(ActionCorrective.class);
    ActionServiceTechnique actionServiceTechnique = __podam.manufacturePojoWithFullData(ActionServiceTechniqueMail.class);
    actionServiceTechnique.setIdSt(idSt);
    actionServiceTechnique.setTypePfs(TypePFS.MAIL.name());
    active.setActionsServicesTechniques(Arrays.asList(actionServiceTechnique));

    Suivi suivi = new Suivi(Statut.DEMARRE.name());
    suivi.setLibelleErreur(commande.getLibelleErreur());
    active.setSuivi(suivi);
    commande.setDonneesBrut(RavelJsonTools.getInstance().toJson(active, ActionCorrective.class));
    ConnectorResponse<Retour, Commande> connectorRep = new ConnectorResponse<>(retour, commande);
    String idAction = "idSuivi"; //$NON-NLS-1$

    String methode = "GET"; //$NON-NLS-1$
    Request request = prepareRequest(tracabilite, methode);
    //operation suivi
    request.setOperation("PEI0229_CommandeActionCorrective_Suivi"); //$NON-NLS-1$

    prepareBl1700Mock();
    prepareCmdRequest(idAction, connectorRep);

    List<ServiceTechnique> listservtech = new ArrayList<>();
    StPfsMail servTech = __podam.manufacturePojo(StPfsMail.class);
    servTech.setIdSt(idSt);
    servTech.setTypeServiceTechnique(TypeST.PFS.name());
    servTech.setTypePfs(TypePFS.MAIL.name());
    listservtech.add(servTech);
    ConnectorResponse<Retour, List<ServiceTechnique>> connectorRepServTech = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), listservtech);
    prepareRSTRequest(connectorRepServTech);
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    //Response expected
    PEI229_Retour pei229 = new PEI229_Retour();
    pei229.setSuivi(active.getSuivi());

    String resultexpected = RavelJsonTools.getInstance().toJson(pei229.getSuivi(), Suivi.class);

    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    response.setResult(resultexpected);
    final Response expected = new Response(ErrorCode.OK_00200, response);

    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());
    assertEquals(expected.getMarshalledResponseJson(), request.getResponse().getMarshalledResponseJson());
  }

  /**
   * cas Request URL Dynamic Parameters is null.
   *
   * @throws Throwable
   *           On errors
   */
  @Test
  public void test_PEI0229_GET_URLDynamicParameters_Null() throws Throwable
  {
    String idSt = "st1"; //$NON-NLS-1$
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);
    Retour retour = RetourFactoryForTU.createOkRetour();

    Commande commande = __podam.manufacturePojo(Commande.class);
    commande.setStatut(Statut.DEMARRE.name());
    ActionCorrective active = __podam.manufacturePojo(ActionCorrective.class);
    ActionServiceTechnique actionServiceTechnique = __podam.manufacturePojoWithFullData(ActionServiceTechniqueMail.class);
    actionServiceTechnique.setIdSt(idSt);
    actionServiceTechnique.setTypePfs(TypePFS.MAIL.name());
    active.setActionsServicesTechniques(Arrays.asList(actionServiceTechnique));

    Suivi suivi = new Suivi(Statut.DEMARRE.name());
    suivi.setLibelleErreur(commande.getLibelleErreur());
    active.setSuivi(suivi);
    commande.setDonneesBrut(RavelJsonTools.getInstance().toJson(active, ActionCorrective.class));
    ConnectorResponse<Retour, Commande> connectorRep = new ConnectorResponse<>(retour, commande);
    String idAction = "idSuivi"; //$NON-NLS-1$

    String methode = "GET"; //$NON-NLS-1$
    Request request = prepareRequest(tracabilite, methode);
    //operation suivi
    request.setOperation("PEI0229_CommandeActionCorrective_Suivi"); //$NON-NLS-1$

    List<ServiceTechnique> listservtech = new ArrayList<>();
    StPfsMail servTech = __podam.manufacturePojo(StPfsMail.class);
    servTech.setIdSt(idSt);
    servTech.setTypeServiceTechnique(TypeST.PFS.name());
    servTech.setTypePfs(TypePFS.MAIL.name());
    listservtech.add(servTech);
    ConnectorResponse<Retour, List<ServiceTechnique>> connectorRepServTech = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), listservtech);

    request.setUrlDynamicParameters(null);

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    //Response expected
    PEI229_Retour pei229 = new PEI229_Retour();
    pei229.setSuivi(active.getSuivi());

    String resultexpected = RavelJsonTools.getInstance().toJson(pei229.getSuivi(), Suivi.class);

    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    response.setResult(resultexpected);
    final Response expected = new Response(ErrorCode.KO_00400, response);

    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());
  }

  /**
   * Test method for {@link com.bytel.spirit.prof.processes.PE0229.PEI0229_CommandeActionCorrective#startPostProcess}.
   *
   * ActionCorrective null
   *
   * <b>Entrées:</b> <br/>
   * <b>Attendu:</b> OK <br/>
   *
   * @throws Throwable
   *           On errors On errors
   */
  @Test
  public void test_PEI0229_POST_Nominal_NOK() throws Throwable
  {
    String methode = "POST"; //$NON-NLS-1$
    _tracabilite.setNomProcessus("PEI0229_CommandeActionCorrective"); //$NON-NLS-1$
    _tracabilite.setIdCorrelationByTel("IdCorrelationByTel"); //$NON-NLS-1$
    _tracabilite.setNomSysteme("NomSysteme"); //$NON-NLS-1$
    Request request = prepareRequest(_tracabilite, methode);
    final ActionCorrective pei0229 = new ActionCorrective();
    pei0229.setClientOperateur("clientOperateur"); //$NON-NLS-1$
    pei0229.setNoCompte("noCompte"); //$NON-NLS-1$
    ActionServiceTechniqueMail peiServiceTechMail = new ActionServiceTechniqueMail("MODIFICATION", "ACTIF", LocalDateTime.now()); //$NON-NLS-1$ //$NON-NLS-2$
    peiServiceTechMail.setIdSt("idSt"); //$NON-NLS-1$
    DonneesProvisionneesSTPfsMail donneProvMail = new DonneesProvisionneesSTPfsMail("adresseMail", 100, 11, "RESTREINT"); //$NON-NLS-1$//$NON-NLS-2$
    peiServiceTechMail.setDonneesProvisionneesStPfsMail(donneProvMail);
    ActionServiceTechniqueOlt peiServiceTechOlt = new ActionServiceTechniqueOlt("MODIFICATION", "ACTIF", LocalDateTime.now()); //$NON-NLS-1$ //$NON-NLS-2$
    DonneesIdentificationSTPfsOlt donneeIdentif = new DonneesIdentificationSTPfsOlt("nomOlt", "pos", "positionRelativePort", "ontId", "technologie"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    peiServiceTechOlt.setDonneesIdentificationStPfsOlt(donneeIdentif);
    //peiServiceTechOlt.setIdSt("idSt"); //$NON-NLS-1$
    peiServiceTechMail.setIdSt("idSt"); //$NON-NLS-1$
    List<ActionServiceTechnique> listActioSt = new ArrayList<>();
    listActioSt.add(peiServiceTechMail);
    //listActioSt.add(peiServiceTechOlt);
    pei0229.setActionsServicesTechniques(listActioSt);
    try
    {
      Retour retourConnector = RetourFactory.createOkRetour();
      IRavelJson instance = new RavelJsonBuilder() //
          .profil("STARK") //$NON-NLS-1$
          .build();
      final IRavelJsonAdapter<ActionCorrective> adapter = instance.adapter(ActionCorrective.class);
      String json = adapter.toJson(null);
      request.setPayload(json);
      _processInstance = new PEI0229_CommandeActionCorrective();
      // On enregistre le scénario des appels avant de lancer le test
      PowerMock.replayAll();
      _processInstance.initializeContext();
      _processInstance.run(request);
      PowerMock.verifyAll();
      IRavelResponse response = request.getResponse();
      assertEquals(ErrorCode.KO_00400, response.getErrorCode());
      Retour actual = _processInstance.getRetour();
      assertEquals(RetourFactory.createNOK(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING).getResultat(), actual.getResultat());

    }
    catch (final RavelException actual)
    {
      fail("Should not append"); //$NON-NLS-1$
    }
  }

  /**
   * Test method for {@link com.bytel.spirit.prof.processes.PE0229.PEI0229_CommandeActionCorrective#startPostProcess}.
   *
   * ActionCorrective noCompte and ClientOperator are null
   *
   * <b>Entrées:</b> <br/>
   * <b>Attendu:</b> OK <br/>
   *
   * @throws Throwable
   *           On errors On errors
   */
  @Test
  public void test_PEI0229_POST_Nominal_NOK_02() throws Throwable
  {
    String methode = "POST"; //$NON-NLS-1$
    _tracabilite.setNomProcessus("PEI0229_CommandeActionCorrective"); //$NON-NLS-1$
    _tracabilite.setIdCorrelationByTel("IdCorrelationByTel"); //$NON-NLS-1$
    _tracabilite.setNomSysteme("NomSysteme"); //$NON-NLS-1$
    Request request = prepareRequest(_tracabilite, methode);
    final ActionCorrective pei0229 = new ActionCorrective();
    pei0229.setClientOperateur("clientOperateur"); //$NON-NLS-1$
    pei0229.setNoCompte("noCompte"); //$NON-NLS-1$
    ActionServiceTechniqueMail peiServiceTechMail = new ActionServiceTechniqueMail("MODIFICATION", "ACTIF", LocalDateTime.now()); //$NON-NLS-1$ //$NON-NLS-2$
    peiServiceTechMail.setIdSt("idSt"); //$NON-NLS-1$
    DonneesProvisionneesSTPfsMail donneProvMail = new DonneesProvisionneesSTPfsMail("adresseMail", 100, 11, "RESTREINT"); //$NON-NLS-1$//$NON-NLS-2$
    peiServiceTechMail.setDonneesProvisionneesStPfsMail(donneProvMail);
    ActionServiceTechniqueOlt peiServiceTechOlt = new ActionServiceTechniqueOlt("MODIFICATION", "ACTIF", LocalDateTime.now()); //$NON-NLS-1$ //$NON-NLS-2$
    DonneesIdentificationSTPfsOlt donneeIdentif = new DonneesIdentificationSTPfsOlt("nomOlt", "pos", "positionRelativePort", "ontId", "technologie"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    peiServiceTechOlt.setDonneesIdentificationStPfsOlt(donneeIdentif);
    //peiServiceTechOlt.setIdSt("idSt"); //$NON-NLS-1$
    peiServiceTechMail.setIdSt("idSt"); //$NON-NLS-1$
    List<ActionServiceTechnique> listActioSt = new ArrayList<>();
    listActioSt.add(peiServiceTechMail);
    //listActioSt.add(peiServiceTechOlt);
    pei0229.setActionsServicesTechniques(listActioSt);
    pei0229.setNoCompte(null);
    pei0229.setClientOperateur(null);
    try
    {
      Retour retourConnector = RetourFactory.createOkRetour();
      ConnectorResponse<Retour, Nothing> connectRep = new ConnectorResponse<>(retourConnector, null);
      //prepareBl1700Mock();
      //prepareCmdcommandeCreer(connectRep);
      IRavelJson instance = new RavelJsonBuilder() //
          .profil("STARK") //$NON-NLS-1$
          .build();
      final IRavelJsonAdapter<ActionCorrective> adapter = instance.adapter(ActionCorrective.class);
      String json = adapter.toJson(pei0229);
      request.setPayload(json);
      _processInstance = new PEI0229_CommandeActionCorrective();
      // On enregistre le scénario des appels avant de lancer le test
      PowerMock.replayAll();
      _processInstance.initializeContext();
      _processInstance.run(request);
      PowerMock.verifyAll();
      IRavelResponse response = request.getResponse();
      assertEquals(ErrorCode.KO_00400, response.getErrorCode());
      Retour actual = _processInstance.getRetour();
      assertEquals(RetourFactory.createNOK(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING).getResultat(), actual.getResultat());

    }
    catch (final RavelException actual)
    {
      fail("Should not append"); //$NON-NLS-1$
    }
  }

  /**
   * Test method for {@link com.bytel.spirit.prof.processes.PE0229.PEI0229_CommandeActionCorrective#startPostProcess}.
   * <b>Entrées:</b> <br/>
   * <b>Attendu:</b> OK <br/>
   *
   * @throws Throwable
   *           On errors On errors
   */
  @Test
  public void test_PEI0229_POST_Nominal_OK_01() throws Throwable
  {
    String methode = "POST"; //$NON-NLS-1$
    _tracabilite.setNomProcessus("PEI0229_CommandeActionCorrective"); //$NON-NLS-1$
    _tracabilite.setIdCorrelationByTel("IdCorrelationByTel"); //$NON-NLS-1$
    _tracabilite.setNomSysteme("NomSysteme"); //$NON-NLS-1$
    Request request = prepareRequest(_tracabilite, methode);
    final ActionCorrective pei0229 = new ActionCorrective();
    pei0229.setClientOperateur("clientOperateur"); //$NON-NLS-1$
    pei0229.setNoCompte("noCompte"); //$NON-NLS-1$
    ActionServiceTechniqueMail peiServiceTechMail = new ActionServiceTechniqueMail("MODIFICATION", "ACTIF", LocalDateTime.now()); //$NON-NLS-1$ //$NON-NLS-2$
    peiServiceTechMail.setIdSt("idSt"); //$NON-NLS-1$
    DonneesProvisionneesSTPfsMail donneProvMail = new DonneesProvisionneesSTPfsMail("adresseMail", 100, 11, "RESTREINT"); //$NON-NLS-1$//$NON-NLS-2$
    peiServiceTechMail.setDonneesProvisionneesStPfsMail(donneProvMail);
    ActionServiceTechniqueOlt peiServiceTechOlt = new ActionServiceTechniqueOlt("MODIFICATION", "ACTIF", LocalDateTime.now()); //$NON-NLS-1$ //$NON-NLS-2$
    DonneesIdentificationSTPfsOlt donneeIdentif = new DonneesIdentificationSTPfsOlt("nomOlt", "pos", "positionRelativePort", "ont1", "GPON"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    peiServiceTechOlt.setDonneesIdentificationStPfsOlt(donneeIdentif);
    //peiServiceTechOlt.setIdSt("idSt"); //$NON-NLS-1$
    peiServiceTechMail.setIdSt("idSt"); //$NON-NLS-1$
    List<ActionServiceTechnique> listActioSt = new ArrayList<>();
    listActioSt.add(peiServiceTechMail);
    //listActioSt.add(peiServiceTechOlt);
    pei0229.setActionsServicesTechniques(listActioSt);
    try
    {
      Retour retourConnector = RetourFactory.createOkRetour();
      ConnectorResponse<Retour, Nothing> connectRep = new ConnectorResponse<>(retourConnector, null);
      prepareBl1700Mock();
      prepareCmdcommandeCreer(connectRep);
      IRavelJson instance = new RavelJsonBuilder() //
          .profil("STARK") //$NON-NLS-1$
          .build();
      final IRavelJsonAdapter<ActionCorrective> adapter = instance.adapter(ActionCorrective.class);
      String json = adapter.toJson(pei0229);
      request.setPayload(json);
      _processInstance = new PEI0229_CommandeActionCorrective();
      // On enregistre le scénario des appels avant de lancer le test
      PowerMock.replayAll();
      _processInstance.initializeContext();
      _processInstance.run(request);
      PowerMock.verifyAll();
      IRavelResponse response = request.getResponse();
      assertEquals(ErrorCode.OK_00201, response.getErrorCode());
      Retour actual = _processInstance.getRetour();
      assertEquals(RetourFactory.createOkRetour().getResultat(), actual.getResultat());

    }
    catch (final RavelException actual)
    {
      fail("Should not append"); //$NON-NLS-1$
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.prof.processes.PE0229.PEI0229_CommandeActionCorrective#startPostProcess(com.ravel.ravel.net.http.Request,}.
   *
   * Retour BL5100 null
   *
   * <b>Entrées:</b> STP FPS Generique <br/>
   * <b>Attendu:</b> OK <br/>
   *
   * @throws Throwable
   *           On errors On errors
   */
  @Test
  public void test_PEI0229_POST_STPFS_GENERIQUE_NOK_003() throws Throwable
  {
    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, "", null); //$NON-NLS-1$
    String methode = "POST"; //$NON-NLS-1$
    _tracabilite.setNomProcessus("PEI0229_CommandeActionCorrective"); //$NON-NLS-1$
    _tracabilite.setIdCorrelationByTel("IdCorrelationByTel"); //$NON-NLS-1$
    _tracabilite.setNomSysteme("NomSysteme"); //$NON-NLS-1$
    Request request = prepareRequest(_tracabilite, methode);
    final ActionCorrective pei0229 = new ActionCorrective(__podam.manufacturePojo(String.class), __podam.manufacturePojo(String.class));
    ActionServiceTechniqueMail peiServiceTechMail = new ActionServiceTechniqueMail(TypeAction.MODIFICATION.name(), Status.ACTIF.name(), LocalDateTime.now());
    peiServiceTechMail.setIdSt(__podam.manufacturePojo(String.class));
    peiServiceTechMail.setDonneesProvisionneesStPfsMail(new DonneesProvisionneesSTPfsMail(__podam.manufacturePojo(String.class), 0, 0, RestrictionLevel.NON_RESTREINT.name()));
    ActionServiceTechniqueOlt peiServiceTechOlt = new ActionServiceTechniqueOlt(TypeAction.MODIFICATION.name(), Status.ACTIF.name(), LocalDateTime.now());
    peiServiceTechOlt.setIdSt(__podam.manufacturePojo(String.class));
    peiServiceTechOlt.setDonneesProvisionnessStPfsOlt(new DonneesProvisionneesSTPfsOlt(__podam.manufacturePojo(String.class), __podam.manufacturePojo(String.class), __podam.manufacturePojo(String.class)));
    List<ActionServiceTechnique> listActioSt = Arrays.asList(peiServiceTechMail, peiServiceTechOlt);
    pei0229.setActionsServicesTechniques(listActioSt);

    try
    {
      Retour retourConnector = RetourFactory.createOkRetour();
      ConnectorResponse<Retour, Nothing> connectRep = new ConnectorResponse<>(retourConnector, null);
      prepareBl1700Mock();
      //prepareCmdcommandeCreer(connectRep);

      IRavelJson instance = new RavelJsonBuilder() //
          .profil("STARK") //$NON-NLS-1$
          .build();
      final IRavelJsonAdapter<ActionCorrective> adapter = instance.adapter(ActionCorrective.class);
      String json = adapter.toJson(pei0229);
      request.setPayload(json);
      _processInstance = new PEI0229_CommandeActionCorrective();
      prepareBL5100(pei0229, null);

      // On enregistre le scénario des appels avant de lancer le test
      PowerMock.replayAll();
      _processInstance.initializeContext();
      _processInstance.run(request);
      PowerMock.verifyAll();
      IRavelResponse response = request.getResponse();
      assertEquals(ErrorCode.KO_00503, response.getErrorCode());
      Retour actual = _processInstance.getRetour();
      assertEquals(RetourFactory.createNOK(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING).getResultat(), actual.getResultat());
    }
    catch (final RavelException actual)
    {
      fail("Should not append"); //$NON-NLS-1$
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.prof.processes.PE0229.PEI0229_CommandeActionCorrective#startPostProcess(com.ravel.ravel.net.http.Request,}.
   *
   * BL5100 throws exception
   *
   * <b>Entrées:</b> STP FPS Generique <br/>
   * <b>Attendu:</b> OK <br/>
   *
   * @throws Throwable
   *           On errors On errors
   */
  @Test
  public void test_PEI0229_POST_STPFS_GENERIQUE_NOK_004() throws Throwable
  {
    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, "", null); //$NON-NLS-1$
    String methode = "POST"; //$NON-NLS-1$
    _tracabilite.setNomProcessus("PEI0229_CommandeActionCorrective"); //$NON-NLS-1$
    _tracabilite.setIdCorrelationByTel("IdCorrelationByTel"); //$NON-NLS-1$
    _tracabilite.setNomSysteme("NomSysteme"); //$NON-NLS-1$
    Request request = prepareRequest(_tracabilite, methode);
    final ActionCorrective pei0229 = new ActionCorrective(__podam.manufacturePojo(String.class), __podam.manufacturePojo(String.class));
    ActionServiceTechniqueMail peiServiceTechMail = new ActionServiceTechniqueMail(TypeAction.MODIFICATION.name(), Status.ACTIF.name(), LocalDateTime.now());
    peiServiceTechMail.setIdSt(__podam.manufacturePojo(String.class));
    peiServiceTechMail.setDonneesProvisionneesStPfsMail(new DonneesProvisionneesSTPfsMail(__podam.manufacturePojo(String.class), 0, 0, RestrictionLevel.NON_RESTREINT.name()));
    ActionServiceTechniqueOlt peiServiceTechOlt = new ActionServiceTechniqueOlt(TypeAction.MODIFICATION.name(), Status.ACTIF.name(), LocalDateTime.now());
    peiServiceTechOlt.setIdSt(__podam.manufacturePojo(String.class));
    peiServiceTechOlt.setDonneesProvisionnessStPfsOlt(new DonneesProvisionneesSTPfsOlt(__podam.manufacturePojo(String.class), __podam.manufacturePojo(String.class), __podam.manufacturePojo(String.class)));
    List<ActionServiceTechnique> listActioSt = Arrays.asList(peiServiceTechMail, peiServiceTechOlt);
    pei0229.setActionsServicesTechniques(listActioSt);

    try
    {
      Retour retourConnector = RetourFactory.createOkRetour();
      ConnectorResponse<Retour, Nothing> connectRep = new ConnectorResponse<>(retourConnector, null);
      prepareBl1700Mock();
      //prepareCmdcommandeCreer(connectRep);

      IRavelJson instance = new RavelJsonBuilder() //
          .profil("STARK") //$NON-NLS-1$
          .build();
      final IRavelJsonAdapter<ActionCorrective> adapter = instance.adapter(ActionCorrective.class);
      String json = adapter.toJson(pei0229);
      request.setPayload(json);
      _processInstance = new PEI0229_CommandeActionCorrective();
      prepareBL5100Exception(pei0229, null);

      // On enregistre le scénario des appels avant de lancer le test
      PowerMock.replayAll();
      _processInstance.initializeContext();
      _processInstance.run(request);
      PowerMock.verifyAll();
      IRavelResponse response = request.getResponse();
      assertEquals(ErrorCode.KO_00503, response.getErrorCode());
      Retour actual = _processInstance.getRetour();
      assertEquals(RetourFactory.createKO(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING).getResultat(), actual.getResultat());
    }
    catch (final RavelException actual)
    {
      fail("Should not append"); //$NON-NLS-1$
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.prof.processes.PE0229.PEI0229_CommandeActionCorrective#startPostProcess(com.ravel.ravel.net.http.Request,}.
   *
   * BL5100 throws exception
   *
   * <b>Entrées:</b> STP FPS Generique <br/>
   * <b>Attendu:</b> OK <br/>
   *
   * @throws Throwable
   *           On errors On errors
   */
  @Test
  public void test_PEI0229_POST_STPFS_GENERIQUE_NOK_005() throws Throwable
  {
    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.NON_RESPECT_STI, "", null); //$NON-NLS-1$
    String methode = "POST"; //$NON-NLS-1$
    _tracabilite.setNomProcessus("PEI0229_CommandeActionCorrective"); //$NON-NLS-1$
    _tracabilite.setIdCorrelationByTel("IdCorrelationByTel"); //$NON-NLS-1$
    _tracabilite.setNomSysteme("NomSysteme"); //$NON-NLS-1$
    Request request = prepareRequest(_tracabilite, methode);
    final ActionCorrective pei0229 = new ActionCorrective(__podam.manufacturePojo(String.class), __podam.manufacturePojo(String.class));
    ActionServiceTechniqueMail peiServiceTechMail = new ActionServiceTechniqueMail(TypeAction.MODIFICATION.name(), Status.ACTIF.name(), LocalDateTime.now());
    peiServiceTechMail.setIdSt(__podam.manufacturePojo(String.class));
    peiServiceTechMail.setDonneesProvisionneesStPfsMail(new DonneesProvisionneesSTPfsMail(__podam.manufacturePojo(String.class), 0, 0, RestrictionLevel.NON_RESTREINT.name()));
    ActionServiceTechniqueOlt peiServiceTechOlt = new ActionServiceTechniqueOlt(TypeAction.MODIFICATION.name(), Status.ACTIF.name(), LocalDateTime.now());
    peiServiceTechOlt.setIdSt(__podam.manufacturePojo(String.class));
    peiServiceTechOlt.setDonneesProvisionnessStPfsOlt(new DonneesProvisionneesSTPfsOlt(__podam.manufacturePojo(String.class), __podam.manufacturePojo(String.class), __podam.manufacturePojo(String.class)));
    List<ActionServiceTechnique> listActioSt = Arrays.asList(peiServiceTechMail, peiServiceTechOlt);
    pei0229.setActionsServicesTechniques(listActioSt);

    try
    {
      Retour retourConnector = RetourFactory.createOkRetour();
      ConnectorResponse<Retour, Nothing> connectRep = new ConnectorResponse<>(retourConnector, null);
      prepareBl1700Mock();
      //prepareCmdcommandeCreer(connectRep);

      IRavelJson instance = new RavelJsonBuilder() //
          .profil("STARK") //$NON-NLS-1$
          .build();
      final IRavelJsonAdapter<ActionCorrective> adapter = instance.adapter(ActionCorrective.class);
      String json = adapter.toJson(pei0229);
      request.setPayload(json);
      _processInstance = new PEI0229_CommandeActionCorrective();
      prepareBL5100(pei0229, retour);

      // On enregistre le scénario des appels avant de lancer le test
      PowerMock.replayAll();
      _processInstance.initializeContext();
      _processInstance.run(request);
      PowerMock.verifyAll();
      IRavelResponse response = request.getResponse();
      assertEquals(ErrorCode.KO_00500, response.getErrorCode());
      Retour actual = _processInstance.getRetour();
      assertEquals(RetourFactory.createNOK(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING).getResultat(), actual.getResultat());
    }
    catch (final RavelException actual)
    {
      fail("Should not append"); //$NON-NLS-1$
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.prof.processes.PE0229.PEI0229_CommandeActionCorrective#startPostProcess(com.ravel.ravel.net.http.Request,}.
   * <b>Entrées:</b> STP FPS Generique <br/>
   * <b>Attendu:</b> OK <br/>
   *
   * @throws Throwable
   *           On errors On errors
   */
  @Test
  public void test_PEI0229_POST_STPFS_GENERIQUE_OK_002() throws Throwable
  {
    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, "", null); //$NON-NLS-1$
    String methode = "POST"; //$NON-NLS-1$
    _tracabilite.setNomProcessus("PEI0229_CommandeActionCorrective"); //$NON-NLS-1$
    _tracabilite.setIdCorrelationByTel("IdCorrelationByTel"); //$NON-NLS-1$
    _tracabilite.setNomSysteme("NomSysteme"); //$NON-NLS-1$
    Request request = prepareRequest(_tracabilite, methode);
    final ActionCorrective pei0229 = new ActionCorrective(__podam.manufacturePojo(String.class), __podam.manufacturePojo(String.class));
    ActionServiceTechniqueMail peiServiceTechMail = new ActionServiceTechniqueMail(TypeAction.MODIFICATION.name(), Status.ACTIF.name(), LocalDateTime.now());
    peiServiceTechMail.setIdSt(__podam.manufacturePojo(String.class));
    peiServiceTechMail.setDonneesProvisionneesStPfsMail(new DonneesProvisionneesSTPfsMail(__podam.manufacturePojo(String.class), 0, 0, RestrictionLevel.NON_RESTREINT.name()));
    ActionServiceTechniqueOlt peiServiceTechOlt = new ActionServiceTechniqueOlt(TypeAction.MODIFICATION.name(), Status.ACTIF.name(), LocalDateTime.now());
    peiServiceTechOlt.setIdSt(__podam.manufacturePojo(String.class));
    peiServiceTechOlt.setDonneesProvisionnessStPfsOlt(new DonneesProvisionneesSTPfsOlt(__podam.manufacturePojo(String.class), __podam.manufacturePojo(String.class), __podam.manufacturePojo(String.class)));
    List<ActionServiceTechnique> listActioSt = Arrays.asList(peiServiceTechMail, peiServiceTechOlt);
    pei0229.setActionsServicesTechniques(listActioSt);

    try
    {
      Retour retourConnector = RetourFactory.createOkRetour();
      ConnectorResponse<Retour, Nothing> connectRep = new ConnectorResponse<>(retourConnector, null);
      prepareBl1700Mock();
      prepareCmdcommandeCreer(connectRep);
      IRavelJson instance = new RavelJsonBuilder() //
          .profil("STARK") //$NON-NLS-1$
          .build();
      final IRavelJsonAdapter<ActionCorrective> adapter = instance.adapter(ActionCorrective.class);
      String json = adapter.toJson(pei0229);
      request.setPayload(json);
      _processInstance = new PEI0229_CommandeActionCorrective();
      // On enregistre le scénario des appels avant de lancer le test
      PowerMock.replayAll();
      _processInstance.initializeContext();
      _processInstance.run(request);
      PowerMock.verifyAll();
      IRavelResponse response = request.getResponse();
      assertEquals(ErrorCode.OK_00201, response.getErrorCode());
      Retour actual = _processInstance.getRetour();
      assertEquals(RetourFactory.createOkRetour().getResultat(), actual.getResultat());
    }
    catch (final RavelException actual)
    {
      fail("Should not append"); //$NON-NLS-1$
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.prof.processes.PE0229.PEI0229_CommandeActionCorrective#PEI0229_BL001_VerifierDonneesCreation(com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite, com.bytel.ravel.net.http.Request)}
   * .<br/>
   * <b>Entrées:</b>X-Action-Id is not here<br/>
   * <b>Attendu:</b>KO<br/>
   *
   * @throws Exception
   *           On errors
   */
  @Test
  public void testPEI0229_BL001_VerifierDonneesCreation_002() throws Exception
  {
    final Retour expected = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString("PEI0229.BL001.HeaderNullOrEmpty"), IHttpHeadersConsts.X_ACTION_ID)); //$NON-NLS-1$
    Pair<Retour, ActionCorrective> actual = null;

    Whitebox.setInternalState(_processInstance, "_processContext", _contextMock); //$NON-NLS-1$
    Whitebox.setInternalState(_processInstance, "_tracabilite", _tracabilite); //$NON-NLS-1$

    try
    {
      final RequestHeader authorization = new RequestHeader();
      authorization.setName(IHttpHeadersConsts.AUTHORIZATION);
      authorization.setValue("Basic ".concat(Base64.getEncoder().encodeToString("scott:tiger".getBytes("UTF-8")))); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

      _request.getRequestHeader().clear();
      _request.getRequestHeader().addAll(Arrays.asList(authorization));

      // _contextMock.setState(State.PEI0229_POST_BL001);
      // EasyMock.expectLastCall().once();

      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_processInstance, "PEI0229_BL001_VerifierDonneesCreation", _tracabilite, _request); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse("Check no RavelException call", _exception); //$NON-NLS-1$

      assertNotNull("Check expected assignment", actual); //$NON-NLS-1$
      assertEquals("Check equality between expected and actual objects", expected, actual._first); //$NON-NLS-1$
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.prof.processes.PE0229.PEI0229_CommandeActionCorrective#PEI0229_BL001_VerifierDonneesCreation(com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite, com.bytel.ravel.net.http.Request)}
   * .<br/>
   * <b>Entrées:</b>X-Message-Id is not here<br/>
   * <b>Attendu:</b>KO<br/>
   *
   * @throws Exception
   *           On errors
   */
  @Test
  public void testPEI0229_BL001_VerifierDonneesCreation_004() throws Exception
  {
    final Retour expected = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString("PEI0229.BL001.HeaderNullOrEmpty"), IHttpHeadersConsts.X_MESSAGE_ID)); //$NON-NLS-1$
    Pair<Retour, ActionCorrective> actual = null;

    Whitebox.setInternalState(_processInstance, "_processContext", _contextMock); //$NON-NLS-1$
    Whitebox.setInternalState(_processInstance, "_tracabilite", _tracabilite); //$NON-NLS-1$

    try
    {
      final RequestHeader authorization = new RequestHeader();
      authorization.setName(IHttpHeadersConsts.AUTHORIZATION);
      authorization.setValue("Basic ".concat(Base64.getEncoder().encodeToString("scott:tiger".getBytes("UTF-8")))); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

      final RequestHeader xActionId = new RequestHeader();
      xActionId.setName(IHttpHeadersConsts.X_ACTION_ID);
      xActionId.setValue(__xActionId);

      /*final RequestHeader xClientOperateur = new RequestHeader();
      xClientOperateur.setName(IHttpHeadersConsts.X_CLIENT_OPERATEUR);
      xClientOperateur.setValue(__clientOperateur);*/

      _request.getRequestHeader().clear();
      _request.getRequestHeader().addAll(Arrays.asList(authorization, xActionId));

      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_processInstance, "PEI0229_BL001_VerifierDonneesCreation", _tracabilite, _request); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse("Check no RavelException call", _exception); //$NON-NLS-1$

      assertNotNull("Check expected assignment", actual); //$NON-NLS-1$
      assertEquals("Check equality between expected and actual objects", expected, actual._first); //$NON-NLS-1$
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.prof.processes.PE0229.PEI0229_CommandeActionCorrective#PEI0229_BL001_VerifierDonneesCreation(com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite, com.bytel.ravel.net.http.Request)}
   * .<br/>
   * <b>Entrées:</b>X-Request-Id is not here<br/>
   * <b>Attendu:</b>KO<br/>
   *
   * @throws Exception
   *           On errors
   * @note Test gelé car la vérification du X-Request-Id est faite par le FrontEnd
   */
  //@Test
  public void testPEI0229_BL001_VerifierDonneesCreation_006() throws Exception
  {
    final Retour expected = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString("PEI0229.BL001.HeaderNullOrEmpty"), IHttpHeadersConsts.X_REQUEST_ID)); //$NON-NLS-1$
    Retour actual = null;

    Whitebox.setInternalState(_processInstance, "_processContext", _contextMock); //$NON-NLS-1$
    Whitebox.setInternalState(_processInstance, "_tracabilite", _tracabilite); //$NON-NLS-1$

    try
    {
      final RequestHeader authorization = new RequestHeader();
      authorization.setName(IHttpHeadersConsts.AUTHORIZATION);
      authorization.setValue("Basic ".concat(Base64.getEncoder().encodeToString("scott:tiger".getBytes("UTF-8")))); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

      final RequestHeader xActionId = new RequestHeader();
      xActionId.setName(IHttpHeadersConsts.X_ACTION_ID);
      xActionId.setValue(__xActionId);

      /*final RequestHeader xClientOperateur = new RequestHeader();
      xClientOperateur.setName(IHttpHeadersConsts.X_CLIENT_OPERATEUR);
      xClientOperateur.setValue(__clientOperateur);*/

      final RequestHeader xMessageId = new RequestHeader();
      xMessageId.setName(IHttpHeadersConsts.X_MESSAGE_ID);
      xMessageId.setValue(__xMessageId);

      final RequestHeader xProcess = new RequestHeader();
      xProcess.setName(IHttpHeadersConsts.X_PROCESS);
      xProcess.setValue(__xProcess);

      _request.getRequestHeader().clear();
      _request.getRequestHeader().addAll(Arrays.asList(authorization, xActionId, xMessageId, xProcess));

      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_processInstance, "PEI0229_BL001_VerifierDonneesCreation", _tracabilite, _request); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse("Check no RavelException call", _exception); //$NON-NLS-1$

      assertNotNull("Check expected assignment", actual); //$NON-NLS-1$
      assertEquals("Check equality between expected and actual objects", expected, actual); //$NON-NLS-1$
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.prof.processes.PE0229.PEI0229_CommandeActionCorrective#PEI0229_BL001_VerifierDonneesCreation(com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite, com.bytel.ravel.net.http.Request)}
   * .<br/>
   * <b>Entrées:</b>X-Source is not here<br/>
   * <b>Attendu:</b>KO<br/>
   *
   * @throws Exception
   *           On errors
   */
  @Test
  public void testPEI0229_BL001_VerifierDonneesCreation_007() throws Exception
  {
    final Retour expected = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString("PEI0229.BL001.HeaderNullOrEmpty"), IHttpHeadersConsts.X_SOURCE)); //$NON-NLS-1$
    Pair<Retour, ActionCorrective> actual = null;

    Whitebox.setInternalState(_processInstance, "_processContext", _contextMock); //$NON-NLS-1$
    Whitebox.setInternalState(_processInstance, "_tracabilite", _tracabilite); //$NON-NLS-1$

    try
    {
      final RequestHeader authorization = new RequestHeader();
      authorization.setName(IHttpHeadersConsts.AUTHORIZATION);
      authorization.setValue("Basic ".concat(Base64.getEncoder().encodeToString("scott:tiger".getBytes("UTF-8")))); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

      final RequestHeader xActionId = new RequestHeader();
      xActionId.setName(IHttpHeadersConsts.X_ACTION_ID);
      xActionId.setValue(__xActionId);

      /*final RequestHeader xClientOperateur = new RequestHeader();
      xClientOperateur.setName(IHttpHeadersConsts.X_CLIENT_OPERATEUR);
      xClientOperateur.setValue(__clientOperateur);*/

      final RequestHeader xMessageId = new RequestHeader();
      xMessageId.setName(IHttpHeadersConsts.X_MESSAGE_ID);
      xMessageId.setValue(__xMessageId);

      final RequestHeader xProcess = new RequestHeader();
      xProcess.setName(IHttpHeadersConsts.X_PROCESS);
      xProcess.setValue(__xProcess);

      final RequestHeader xRequestId = new RequestHeader();
      xRequestId.setName(IHttpHeadersConsts.X_REQUEST_ID);
      xRequestId.setValue(__xRequestId);

      _request.getRequestHeader().clear();
      _request.getRequestHeader().addAll(Arrays.asList(authorization, xActionId, xMessageId, xProcess, xRequestId));

      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_processInstance, "PEI0229_BL001_VerifierDonneesCreation", _tracabilite, _request); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse("Check no RavelException call", _exception); //$NON-NLS-1$

      assertNotNull("Check expected assignment", actual); //$NON-NLS-1$
      assertEquals("Check equality between expected and actual objects", expected, actual._first); //$NON-NLS-1$
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.prof.processes.PE0229.PEI0229_CommandeActionCorrective#PEI0229_BL001_VerifierDonneesCreation(com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite, com.bytel.ravel.net.http.Request)}
   * .<br/>
   * <b>Entrées:</b>Payload is null<br/>
   * <b>Attendu:</b>KO<br/>
   *
   * @throws Exception
   *           On errors
   */
  //@Test
  public void testPEI0229_BL001_VerifierDonneesCreation_008() throws Exception
  {
    final Retour expected = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString("PEI0229.POST.BL001.StiError"), "Body obligatoire.")); //$NON-NLS-1$ //$NON-NLS-2$
    Retour actual = null;

    Whitebox.setInternalState(_processInstance, "_processContext", _contextMock); //$NON-NLS-1$
    Whitebox.setInternalState(_processInstance, "_tracabilite", _tracabilite); //$NON-NLS-1$

    try
    {
      _request.getRequestHeader().clear();

      final RequestHeader authorization = new RequestHeader();
      authorization.setName(IHttpHeadersConsts.AUTHORIZATION);
      authorization.setValue("Basic ".concat(Base64.getEncoder().encodeToString("scott:tiger".getBytes("UTF-8")))); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

      final RequestHeader xActionId = new RequestHeader();
      xActionId.setName(IHttpHeadersConsts.X_ACTION_ID);
      xActionId.setValue(__xActionId);

      /*final RequestHeader xClientOperateur = new RequestHeader();
      xClientOperateur.setName(IHttpHeadersConsts.X_CLIENT_OPERATEUR);
      xClientOperateur.setValue(__clientOperateur);*/

      final RequestHeader xMessageId = new RequestHeader();
      xMessageId.setName(IHttpHeadersConsts.X_MESSAGE_ID);
      xMessageId.setValue(__xMessageId);

      final RequestHeader xProcess = new RequestHeader();
      xProcess.setName(IHttpHeadersConsts.X_PROCESS);
      xProcess.setValue(__xProcess);

      final RequestHeader xRequestId = new RequestHeader();
      xRequestId.setName(IHttpHeadersConsts.X_REQUEST_ID);
      xRequestId.setValue(__xRequestId);

      final RequestHeader xSource = new RequestHeader();
      xSource.setName(IHttpHeadersConsts.X_SOURCE);
      xSource.setValue(__xSource);

      _request.getRequestHeader().addAll(Arrays.asList(authorization, xActionId, xMessageId, xProcess, xRequestId, xSource));
      _request.setPayload(null);

      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_processInstance, "PEI0229_BL001_VerifierDonneesCreation", _tracabilite, _request); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse("Check no RavelException call", _exception); //$NON-NLS-1$

      assertNotNull("Check expected assignment", actual); //$NON-NLS-1$
      assertEquals("Check equality between expected and actual objects", expected, actual); //$NON-NLS-1$
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.prof.processes.PE0229.PEI0229_CommandeActionCorrective#PEI0229_BL001_VerifierDonneesCreation(com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite, com.bytel.ravel.net.http.Request)}
   * .<br/>
   * <b>Entrées:</b>Validation error, _noCompte not here<br/>
   * <b>Attendu:</b>KO<br/>
   *
   * @throws Exception
   *           On errors
   */
  //@Test
  public void testPEI0229_BL001_VerifierDonneesCreation_009() throws Exception
  {
    final Retour expected = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString("Validation.RequiredField"), "[_noCompte]")); //$NON-NLS-1$ //$NON-NLS-2$
    Retour actual = null;

    Whitebox.setInternalState(_processInstance, "_processContext", _contextMock); //$NON-NLS-1$
    Whitebox.setInternalState(_processInstance, "_tracabilite", _tracabilite); //$NON-NLS-1$

    try
    {
      final RequestHeader authorization = new RequestHeader();
      authorization.setName(IHttpHeadersConsts.AUTHORIZATION);
      authorization.setValue("Basic ".concat(Base64.getEncoder().encodeToString("scott:tiger".getBytes("UTF-8")))); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

      final RequestHeader xActionId = new RequestHeader();
      xActionId.setName(IHttpHeadersConsts.X_ACTION_ID);
      xActionId.setValue(__xActionId);

      final RequestHeader xMessageId = new RequestHeader();
      xMessageId.setName(IHttpHeadersConsts.X_MESSAGE_ID);
      xMessageId.setValue(__xMessageId);

      final RequestHeader xProcess = new RequestHeader();
      xProcess.setName(IHttpHeadersConsts.X_PROCESS);
      xProcess.setValue(__xProcess);

      final RequestHeader xRequestId = new RequestHeader();
      xRequestId.setName(IHttpHeadersConsts.X_REQUEST_ID);
      xRequestId.setValue(__xRequestId);

      final RequestHeader xSource = new RequestHeader();
      xSource.setName(IHttpHeadersConsts.X_SOURCE);
      xSource.setValue(__xSource);

      _request.getRequestHeader().clear();
      _request.getRequestHeader().addAll(Arrays.asList(authorization, xActionId, xMessageId, xProcess, xRequestId, xSource));

      StPfsMail serviceTechnique = __podam.manufacturePojoWithFullData(StPfsMail.class);
      serviceTechnique.setTypeServiceTechnique(TypeST.PFS.name());
      serviceTechnique.setTypePfs(TypePFS.MAIL.name());
      DonneesIdentificationSTPfsMail donnesIdent = new DonneesIdentificationSTPfsMail(TypeServiceMail.PRINCIPAL.name(), "compteMail"); //$NON-NLS-1$
      DonneesProvisionneesSTPfsMail donnesProv = new DonneesProvisionneesSTPfsMail("charles.rock", 10, 1, "RESTREINT"); //$NON-NLS-1$ //$NON-NLS-2$
      serviceTechnique.setDonneesIdentificationStPfsMail(donnesIdent);
      serviceTechnique.setDonneesProvisionneesStPfsMail(donnesProv);

      //Build a valid ModificationCommercial element
      final ModificationCommerciale modificationCommerciale = __podam.manufacturePojoWithFullData(ModificationCommerciale.class);//new ModificationCommerciale();
      modificationCommerciale.setStatut("EN_COURS"); // EN_COURS|TRAITE //$NON-NLS-1$
      modificationCommerciale.setStatutCommercialAttendu("ACTIF"); // ACTIF|SUSPENDU|RESILIE //$NON-NLS-1$

      final ActionCorrective actionCorrectiveRequest = new ActionCorrective("BSS_GP", null); //$NON-NLS-1$
      actionCorrectiveRequest.setSuivi(null);

      _request.setPayload(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(actionCorrectiveRequest));

      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_processInstance, "PEI0229_BL001_VerifierDonneesCreation", _tracabilite, _request); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse("Check no RavelException call", _exception); //$NON-NLS-1$

      assertNotNull("Check expected assignment", actual); //$NON-NLS-1$
      assertEquals("Check equality between expected and actual objects", expected, actual); //$NON-NLS-1$
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.prof.processes.PE0229.PEI0229_CommandeActionCorrective#PEI0229_BL002_FormaterReponseCreation(com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite, com.bytel.ravel.common.business.generated.Retour, java.lang.String)}
   * .<br/>
   * <b>Entrées:</b><br/>
   * <b>Attendu:</b>OK<br/>
   *
   * @throws Exception
   *           On errors
   */
  @Test
  public void testPEI0229_BL002_FormaterReponseCreation_001() throws Exception
  {
    final Retour retour = RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.ERREUR_INTERNE, null);

    Whitebox.setInternalState(_processInstance, "_processContext", _contextMock); //$NON-NLS-1$
    Whitebox.setInternalState(_processInstance, "_tracabilite", _tracabilite); //$NON-NLS-1$

    final ReponseErreur reponseErreur = new ReponseErreur();
    reponseErreur.setError(IMegSpiritConsts.ERREUR_INTERNE);
    reponseErreur.setErrorDescription(null);
    final PEI0229_BL002_FormaterReponseCreationReturn expected = new PEI0229_BL002_FormaterReponseCreationReturn(retour);
    expected.setReponseErreur(reponseErreur);
    PEI0229_BL002_FormaterReponseCreationReturn actual = null;

    try
    {
      _contextMock.setState(State.ENDED);
      EasyMock.expectLastCall().once();

      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_processInstance, "PEI0229_BL002_FormaterReponseCreation", _tracabilite, retour, __idActionCorrective); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse("Check no RavelException call", _exception); //$NON-NLS-1$

      assertNotNull("Check expected assignment", actual); //$NON-NLS-1$
      assertEquals("Check equality between expected and actual objects", expected, actual); //$NON-NLS-1$
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.prof.processes.PE0229.PEI0229_CommandeActionCorrective#PEI0229_BL002_FormaterReponseCreation(com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite, com.bytel.ravel.common.business.generated.Retour, java.lang.String)}
   * .<br/>
   * <b>Entrées:</b><br/>
   * <b>Attendu:</b>OK<br/>
   *
   * @throws Exception
   *           On errors
   */
  @Test
  public void testPEI0229_BL002_FormaterReponseCreation_002() throws Exception
  {
    final Retour retour = RetourFactory.createOkRetour();

    Whitebox.setInternalState(_processInstance, "_processContext", _contextMock); //$NON-NLS-1$
    Whitebox.setInternalState(_processInstance, "_tracabilite", _tracabilite); //$NON-NLS-1$

    final PEI0229_BL002_FormaterReponseCreationReturn expected = new PEI0229_BL002_FormaterReponseCreationReturn(retour);
    expected.setReponseFonctionnelle(new PEI0229_BL002_FormaterReponseCreationReturn.ReponseFonctionnelle(__idActionCorrective));
    PEI0229_BL002_FormaterReponseCreationReturn actual = null;

    try
    {
      _contextMock.setState(State.ENDED);
      EasyMock.expectLastCall().once();

      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_processInstance, "PEI0229_BL002_FormaterReponseCreation", _tracabilite, retour, __idActionCorrective); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse("Check no RavelException call", _exception); //$NON-NLS-1$

      assertNotNull("Check expected assignment", actual); //$NON-NLS-1$
      assertEquals("Check equality between expected and actual objects", expected, actual); //$NON-NLS-1$
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.prof.processes.PE0229.PEI0229_CommandeActionCorrective#PEI0229_BL100_CreerActionCorrective(com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite, java.lang.String)}
   * .<br/>
   * <b>Entrées:</b><br/>
   * <b>Attendu:</b>OK<br/>
   *
   * @throws Exception
   *           On errors
   */
  @Test
  public void testPEI0229_BL100_CreerActionCorrective_001_OK() throws Exception
  {

    ActionServiceTechniqueMail actionServiceTechnique = __podam.manufacturePojoWithFullData(ActionServiceTechniqueMail.class);
    actionServiceTechnique.setTypePfs(TypePFS.MAIL.name());
    ActionCorrective pei229_ActionCorrective = __podam.manufacturePojoWithFullData(ActionCorrective.class);
    pei229_ActionCorrective.setActionsServicesTechniques(Arrays.asList(actionServiceTechnique));

    Retour retourOk = RetourFactory.createOkRetour();
    ConnectorResponse<Retour, Nothing> cmdResp = new ConnectorResponse<>(retourOk, null);
    prepareCmdcommandeCreer(cmdResp);
    PowerMock.replayAll();
    Pair<Retour, String> bl100Retour = Whitebox.invokeMethod(_processInstance, "PEI0229_BL100_CreerActionCorrective", _tracabilite, pei229_ActionCorrective); //$NON-NLS-1$
    PowerMock.verifyAll();
    assertNotNull(bl100Retour._first);
    assertEquals(retourOk.getResultat(), bl100Retour._first.getResultat());
  }

  /**
   * Add custom headers
   *
   * @param requestHeader_p
   *          request
   * @param tracabilite_p
   *          tracabilite
   */
  private void addXHeaders(List<RequestHeader> requestHeader_p, Tracabilite tracabilite_p)
  {
    RequestHeader hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.CONTENT_TYPE);
    hdr.setValue(MediaType.APPLICATION_JSON);
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_REQUEST_ID);
    hdr.setValue(tracabilite_p.getIdCorrelationByTel());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_REQUEST_ID_SPIRIT);
    hdr.setValue(tracabilite_p.getIdCorrelationSpirit());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_SOURCE);
    hdr.setValue(tracabilite_p.getNomSysteme());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_PROCESS);
    hdr.setValue(tracabilite_p.getNomProcessus());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_PROCESS_ID_SPIRIT);
    hdr.setValue(tracabilite_p.getIdProcessusSpirit());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_MESSAGE_ID);
    hdr.setValue(tracabilite_p.getIdProcessusSpirit());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_ACTION_ID);
    hdr.setValue(tracabilite_p.getNomProcessus());
    requestHeader_p.add(hdr);
  }

  /**
   * prepareBl1700Mock
   *
   * @throws Exception
   *           exception
   */
  private void prepareBl1700Mock() throws Exception
  {
    PowerMock.expectNew(BL1700_AjouterRefFoncBuilder.class).andReturn(_bl1700builder);
    EasyMock.expect(_bl1700builder.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl1700builder);
    EasyMock.expect(_bl1700builder.refFonc(EasyMock.anyObject())).andReturn(_bl1700builder);
    EasyMock.expect(_bl1700builder.build()).andReturn(_bl1700);
    EasyMock.expect(_bl1700.execute(EasyMock.anyObject(PEI0229_CommandeActionCorrective.class))).andReturn(null);
    //EasyMock.expect(_bl1700.getRetour()).andReturn(RetourFactoryForTU.createOkRetour());

  }

  /**
   * prepare BL5110
   *
   * @param actionCorrective_p
   *          idActionCorrective
   * @param retour_p
   *          retour
   * @throws Exception
   *           on error
   */
  private void prepareBL5100(ActionCorrective actionCorrective_p, Retour retour_p) throws Exception
  {
    BL5100_CreerActionCorrective bl5100_CreerActionCorrective = PowerMock.createMock(BL5100_CreerActionCorrective.class);
    BL5100_CreerActionCorrectiveBuilder builder = PowerMock.createMockAndExpectNew(BL5100_CreerActionCorrectiveBuilder.class);
    EasyMock.expect(builder.actionCorrective(actionCorrective_p)).andReturn(builder);
    EasyMock.expect(builder.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(builder);
    EasyMock.expect(builder.idExterne(EasyMock.anyObject(String.class))).andReturn(builder);
    EasyMock.expect(builder.build()).andReturn(bl5100_CreerActionCorrective);
    EasyMock.expect(bl5100_CreerActionCorrective.execute(_processInstance)).andReturn(null);
    EasyMock.expect(bl5100_CreerActionCorrective.getRetour()).andReturn(retour_p);
  }

  /**
   * prepare BL5110
   *
   * @param actionCorrective_p
   *          idActionCorrective
   * @param retour_p
   *          retour
   * @throws Exception
   *           on error
   */
  private void prepareBL5100Exception(ActionCorrective actionCorrective_p, Retour retour_p) throws Exception
  {
    BL5100_CreerActionCorrective bl5100_CreerActionCorrective = PowerMock.createMock(BL5100_CreerActionCorrective.class);
    BL5100_CreerActionCorrectiveBuilder builder = PowerMock.createMockAndExpectNew(BL5100_CreerActionCorrectiveBuilder.class);
    EasyMock.expect(builder.actionCorrective(actionCorrective_p)).andReturn(builder);
    EasyMock.expect(builder.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(builder);
    EasyMock.expect(builder.idExterne(EasyMock.anyObject(String.class))).andReturn(builder);
    EasyMock.expect(builder.build()).andReturn(bl5100_CreerActionCorrective);
    RuntimeException runtimeException = new RuntimeException("Testing the Catch", new Throwable("Testing the Catch")); //$NON-NLS-1$//$NON-NLS-2$
    EasyMock.expect(bl5100_CreerActionCorrective.execute(_processInstance)).andThrow(runtimeException);
  }

  /**
   * prepare BL5110
   *
   * @param idActionCorrective_p
   *          idActionCorrective
   * @param retour_p
   *          retour
   * @throws Exception
   *           on error
   */
  private void prepareBL5110(String idActionCorrective_p, Retour retour_p) throws Exception
  {
    BL5110_ExecuterActionCorrective bl5110_ExecuterActionCorrective = PowerMock.createMock(BL5110_ExecuterActionCorrective.class);
    BL5110_ExecuterActionCorrectiveBuilder builder = PowerMock.createMockAndExpectNew(BL5110_ExecuterActionCorrectiveBuilder.class);
    EasyMock.expect(builder.idActionCorrective(idActionCorrective_p)).andReturn(builder);
    EasyMock.expect(builder.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(builder);
    EasyMock.expect(builder.build()).andReturn(bl5110_ExecuterActionCorrective);
    EasyMock.expect(bl5110_ExecuterActionCorrective.execute(_processInstance)).andReturn(null);
    EasyMock.expect(bl5110_ExecuterActionCorrective.getRetour()).andReturn(retour_p);
  }

  /**
   * prepare BL5110
   *
   * @param idActionCorrective_p
   *          idActionCorrective
   * @param retour_p
   *          retour
   * @throws Exception
   *           on error
   */
  private void prepareBL5110Exception(String idActionCorrective_p) throws Exception
  {
    BL5110_ExecuterActionCorrective bl5110_ExecuterActionCorrective = PowerMock.createMock(BL5110_ExecuterActionCorrective.class);
    BL5110_ExecuterActionCorrectiveBuilder builder = PowerMock.createMockAndExpectNew(BL5110_ExecuterActionCorrectiveBuilder.class);
    EasyMock.expect(builder.idActionCorrective(idActionCorrective_p)).andReturn(builder);
    EasyMock.expect(builder.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(builder);
    EasyMock.expect(builder.build()).andReturn(bl5110_ExecuterActionCorrective);
    RuntimeException runtimeException = new RuntimeException("Testing the Catch", new Throwable("Testing the Catch")); //$NON-NLS-1$//$NON-NLS-2$
    EasyMock.expect(bl5110_ExecuterActionCorrective.execute(_processInstance)).andThrow(runtimeException);
  }

  /**
   * prepare CmdPRoxy commandeCreer
   *
   * @param connectorRep
   * @throws RavelException
   */
  private void prepareCmdcommandeCreer(ConnectorResponse<Retour, Nothing> connectorRep) throws RavelException
  {

    EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdProxy);
    EasyMock.expect(_cmdProxy.commandeCreer(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject())).andReturn(connectorRep);

  }

  /**
   * prepareCmdRequest CMD
   *
   * @param sIdActionCorrective_p
   *          idActionCorrective
   * @param retour_p
   *          retour
   * @param connectorRep
   *          connector Response
   * @throws RavelException
   *           exception
   */
  private void prepareCmdRequest(String sIdActionCorrective_p, ConnectorResponse<Retour, Commande> connectorRep) throws RavelException
  {
    EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdProxy);
    EasyMock.expect(_cmdProxy.commandeLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(sIdActionCorrective_p))).andReturn(connectorRep);
  }

  /**
   * prepareCmdRequest CMD
   *
   * @param idCmd_p
   *          idcmd
   * @param statut
   *          statut
   * @param connectorRep
   *          connector Response
   * @throws RavelException
   *           exception
   */
  private void prepareCommandeModifierStatut(String idCmd_p, String statut, ConnectorResponse<Retour, Nothing> connectorRep) throws RavelException
  {

    EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdProxy);
    EasyMock.expect(_cmdProxy.commandeModifierStatut(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(idCmd_p), EasyMock.eq(statut), EasyMock.eq(null), EasyMock.eq(null))).andReturn(connectorRep);

  }

  /**
   * preparePROV_SI001Mock
   *
   * @param keys
   *          key
   * @param values
   *          value
   *
   * @throws Exception
   *           exception
   */
  private void preparePROV_SI001Mock(List<String> keys, List<String> values) throws Exception
  {
    PowerMock.expectNew(PROV_SI001_LancerOrchestrateurBuilder.class).andReturn(_provSI001BuilderMock);
    EasyMock.expect(_provSI001BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_provSI001BuilderMock);
    EasyMock.expect(_provSI001BuilderMock.cles(EasyMock.anyObject())).andReturn(_provSI001BuilderMock);
    EasyMock.expect(_provSI001BuilderMock.priorite(10)).andReturn(_provSI001BuilderMock);
    EasyMock.expect(_provSI001BuilderMock.type(IMegSpiritConsts.CONTINUER_PROCESSUS)).andReturn(_provSI001BuilderMock);
    EasyMock.expect(_provSI001BuilderMock.processus(PEP0229_NAME)).andReturn(_provSI001BuilderMock);
    EasyMock.expect(_provSI001BuilderMock.noms(keys)).andReturn(_provSI001BuilderMock);
    EasyMock.expect(_provSI001BuilderMock.valeurs(values)).andReturn(_provSI001BuilderMock);
    EasyMock.expect(_provSI001BuilderMock.build()).andReturn(_provSI001Mock);
    EasyMock.expect(_provSI001Mock.execute(EasyMock.anyObject(PEI0229_CommandeActionCorrective.class))).andReturn(__podam.manufacturePojoWithFullData(ResponseConnector.class));
    EasyMock.expect(_provSI001Mock.getRetour()).andReturn(RetourFactoryForTU.createOkRetour());

  }

  /**
   * prepareGetRequest
   *
   * @param tracabilite_p
   *          tracabilite
   * @param methode_p
   *          method
   * @return Request
   * @throws RavelException
   *           exception
   */
  private Request prepareRequest(Tracabilite tracabilite_p, String methode_p) throws RavelException
  {
    Request request = new Request(DEFAULT_PROCESSNAME, "idProcess", "idClient"); //$NON-NLS-1$ //$NON-NLS-2$
    request.setHttpMethod(methode_p);
    request.setMsgId(Test_Consts.DEFAULT_MSGID);
    request.setUrlDynamicParameters("idSuivi"); //$NON-NLS-1$
    addXHeaders(request.getRequestHeader(), tracabilite_p);
    return request;
  }

  /**
   * prepareCmdRequest CMD
   *
   * @param connectorRep
   *          Connector response
   * @throws RavelException
   *           exception
   */
  private void prepareRSTRequest(ConnectorResponse<Retour, List<ServiceTechnique>> connectorRep) throws RavelException
  {

    EasyMock.expect(RSTProxy.getInstance()).andReturn(_rstProxy);

    EasyMock.expect(_rstProxy.serviceTechniqueLireTousParPfi(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(String.class), EasyMock.anyObject(String.class), EasyMock.eq(StringConstants.EMPTY_STRING), EasyMock.eq(StringConstants.EMPTY_STRING))).andReturn(connectorRep);

  }
}
