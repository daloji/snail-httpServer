/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PP0315;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.easymock.EasyMock;
import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.response.IRavelResponse;
import com.bytel.ravel.common.factory.response.RavelResponseFactory;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.ACManagerUtil;
import com.bytel.ravel.common.utils.MarshallTools;
import com.bytel.ravel.common.utils.Pair;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.RetourFactoryForTU;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.net.http.HttpConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.process.IActivityCaller;
import com.bytel.ravel.services.process.ProcessManager;
import com.bytel.spirit.common.activities.shared.BL1200_DeplacerFichier;
import com.bytel.spirit.common.activities.shared.BL1200_DeplacerFichier.BL1200_DeplacerFichierBuilder;
import com.bytel.spirit.common.activities.shared.BL1700_AjouterRefFonc;
import com.bytel.spirit.common.activities.shared.BL1700_AjouterRefFonc.BL1700_AjouterRefFoncBuilder;
import com.bytel.spirit.common.activities.shared.BL3800_TrouverFichier;
import com.bytel.spirit.common.activities.shared.BL3800_TrouverFichier.BL3800_TrouverFichierBuilder;
import com.bytel.spirit.common.activities.shared.BL3900_DeplacerEtRenommerFichier;
import com.bytel.spirit.common.activities.shared.BL3900_DeplacerEtRenommerFichier.BL3900_DeplacerEtRenommerFichierBuilder;
import com.bytel.spirit.common.activities.shared.BL4600_CreerErreurSpirit;
import com.bytel.spirit.common.activities.shared.BL4600_CreerErreurSpirit.BL4600_CreerErreurSpiritBuilder;
import com.bytel.spirit.common.shared.misc.ressources.RetourConverter;
import com.bytel.spirit.common.shared.misc.tracabilite.IRefFoncConstants;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.prof.processes.generated.PP0315.ConfigurationPP0315;
import com.google.common.io.Files;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author dangelis
 * @version ($Revision$ $Date$)
 */
//Déclaration du runner de test pour lancer les TUs avec le runner PowerMock
@RunWith(PowerMockRunner.class)
//Préparation des classes pour les tests, toutes les classes comportant des méthodes statiques à mocker doivent être présentes dans l'annotation
@PrepareForTest({ BL1200_DeplacerFichierBuilder.class, BL1200_DeplacerFichier.class, BL1200_DeplacerFichierBuilder.class, BL1200_DeplacerFichier.class, BL1700_AjouterRefFonc.class, BL3800_TrouverFichier.class, BL3800_TrouverFichierBuilder.class, PP0315_GenererErreurSpirit.class })
@PowerMockIgnore("javax.crypto.*")
public class PP0315_GenererErreurSpiritTest
{

  /**
   * The default process name.
   */
  public static final String DEFAULT_PROCESSNAME = PP0315_GenererErreurSpirit.class.getName();

  /**
   * Initialization method: Create: - spring context - connectors - service manager.
   *
   * @throws RavelException
   *           the exception
   */
  @BeforeClass
  public static void init() throws RavelException
  {
    ACManagerUtil.resetACManager();
    new ClassPathXmlApplicationContext("classpath:BeansProcessTestMocks.xml"); //$NON-NLS-1$
  }

  /**
   * BL3800_TrouverFichier Mock
   */
  @MockStrict
  private BL3800_TrouverFichier _bl3800TrouverFichier;
  /**
   * BL3800_TrouverFichierBuilder Mock
   */
  @MockStrict
  private BL3800_TrouverFichierBuilder _bl3800TrouverFichierBuilder;
  /**
   * BL1700_AjouterRefFoncBuilder Mock
   */
  @MockStrict
  private BL1700_AjouterRefFoncBuilder _bl1700AjouterRefFoncBuilder;
  /**
   * BL1700_AjouterRefFonc Mock
   */
  @MockStrict
  private BL1700_AjouterRefFonc _bl1700AjouterRefFonc;
  /**
   * BL4600_CreerErreurSpirit Mock
   */
  @MockStrict
  private BL4600_CreerErreurSpirit _bl4600CreeErreurSpirit;

  /**
   * BL4600_CreerErreurSpiritBuilder Mock
   */
  @MockStrict
  private BL4600_CreerErreurSpiritBuilder _bl4600CreerErreurSpiritBuilder;

  /**
   * BL1200_DeplacerFichier Mock
   */
  @MockStrict
  private BL1200_DeplacerFichier _bl1200DeplacerFichier;

  /**
   * BL1200_DeplacerFichierBuilder Mock
   */
  @MockStrict
  private BL1200_DeplacerFichierBuilder _bl1200DeplacerFichierBuilder;

  /**
   * BL3900_DeplacerEtRenommerFichier Mock
   */
  @MockStrict
  private BL3900_DeplacerEtRenommerFichier _bl3900DeplacerEtRenommerFichier;

  /**
   * BL3900_DeplacerEtRenommerFichierBuilder Mock
   */
  @MockStrict
  private BL3900_DeplacerEtRenommerFichierBuilder _bl3900DeplacerEtRenommerFichierBuilder;
  /**
   * The temporary destination folder.
   */
  private TemporaryFolder _tempFolder;

  /**
   * File folder config
   */
  private File _tempFolderConfig;

  /**
   * File folder Echec
   */
  private File _tempFolderEchec;

  /**
   * File folder Succes
   */
  private File _tempFolderSucces;

  /**
   * Confuguration Processus
   */
  private ConfigurationPP0315 _configuration;

  /**
   * Factory to generate beans
   */
  private PodamFactory _podam = new PodamFactoryImpl();

  /**
   *
   */
  PP0315_GenererErreurSpirit _currentInstance;

  /**
   * after Test The file copy config OLT must copy to initial folder
   */
  @After
  public void afterTest()
  {
    _tempFolder.delete();
    _tempFolderConfig.delete();
    _tempFolderEchec.delete();
    _tempFolderSucces.delete();
  }

  /**
   * before Test
   *
   * @throws Throwable
   *           exception
   *
   */
  @Before
  public void beforeTest() throws Throwable
  {
    // Initialize the context
    _currentInstance = new PP0315_GenererErreurSpirit();
    _currentInstance.initializeContext();
    _podam.getStrategy().setMemoization(false);
    _tempFolder = new TemporaryFolder();
    _tempFolder.create();
    //creation repertoire config dans le repertoire temporaire
    _tempFolderConfig = _tempFolder.newFolder("Config"); //$NON-NLS-1$
    //creation repertoire Echec dans le repertoire temporaire
    _tempFolderEchec = _tempFolder.newFolder("Echec"); //$NON-NLS-1$
    //creation repertoire Succes dans le repertoire temporaire
    _tempFolderSucces = _tempFolder.newFolder("Succes"); //$NON-NLS-1$
    //creation ConfigurationPP0240
    _configuration = new ConfigurationPP0315();
    _configuration.setRepertoireSource(_tempFolderConfig.getAbsolutePath());
    _configuration.setMasqueNomFichier("GENERER-ERREUR-SPIRIT*"); //$NON-NLS-1$
    _configuration.setRepertoireEchec(_tempFolderEchec.getAbsolutePath());
    _configuration.setRepertoireSucces(_tempFolderSucces.getAbsolutePath());
    //generation String a partir de l'objet ConfigurationPP0240
    String configXml = MarshallTools.marshall(_configuration);
    String extension = ".xml"; //$NON-NLS-1$

    //creation du fichier de configuration dans le dossier temporaire Config
    File file = File.createTempFile("ConfigurationPP0315", extension, _tempFolderConfig); //$NON-NLS-1$
    BufferedWriter bw = new BufferedWriter(new FileWriter(file));
    bw.write(configXml);
    bw.close();
    Map<String, String> map = new HashMap<>();
    map.put("FILE_PATH", file.getAbsolutePath()); //$NON-NLS-1$
    String filename = getFilePath("GENERER-ERREUR-SPIRIT_20171017035054_v1.csv"); //$NON-NLS-1$
    //copie du fichier de configuration OLT dans le dossier de configuration temporaire Config
    copyFileConfig(filename, _tempFolderConfig + File.separator + "GENERER-ERREUR-SPIRIT_20171017035054_v1.csv"); //$NON-NLS-1$
    ConcurrentHashMap<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.put(StringConstants.EMPTY_STRING, map);
    //deactivate cache podam

    PowerMock.resetAll();

    PowerMock.mockStatic(BL3800_TrouverFichier.class);
  }

  /**
   * Copy file
   *
   * @param source_p
   *          source
   * @param destination_p
   *          destination
   */
  public void copyFileConfig(String source_p, String destination_p)
  {

    if ((source_p != null) && (destination_p != null))
    {
      Path pathSrc = Paths.get(source_p);
      Path pathDest = Paths.get(destination_p);

      try
      {
        Files.copy(pathSrc.toFile(), pathDest.toFile());
      }
      catch (IOException exception)
      {
        fail("Should not append : " + exception.getMessage()); //$NON-NLS-1$
      }

    }
  }

  /**
   * Test OK Nominal file <br/>
   *
   *
   * <b>Entrée:</b> input valid and correct data in file <br/>
   * <b>Attendu:</b> OK.<br/>
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void PP0315_GenererErreurSpirit_0K_001() throws Throwable
  {
    Request request = new Request(DEFAULT_PROCESSNAME, "idProcess", "idClient"); //$NON-NLS-1$ //$NON-NLS-2$
    PowerMock.expectNew(BL3800_TrouverFichierBuilder.class).andReturn(_bl3800TrouverFichierBuilder);
    EasyMock.expect(_bl3800TrouverFichierBuilder.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl3800TrouverFichierBuilder);
    EasyMock.expect(_bl3800TrouverFichierBuilder.repertoire(_tempFolderConfig.getAbsolutePath())).andReturn(_bl3800TrouverFichierBuilder);
    EasyMock.expect(_bl3800TrouverFichierBuilder.masqueNomFichier("GENERER-ERREUR-SPIRIT*")).andReturn(_bl3800TrouverFichierBuilder); //$NON-NLS-1$
    EasyMock.expect(_bl3800TrouverFichierBuilder.build()).andReturn(_bl3800TrouverFichier);
    EasyMock.expect(_bl3800TrouverFichier.execute(EasyMock.anyObject(IActivityCaller.class))).andReturn(new Pair<String, Retour>("GENERER-ERREUR-SPIRIT_20171017035054_v1.csv", RetourFactory.createOkRetour())); //$NON-NLS-1$
    PowerMock.expectNew(BL1700_AjouterRefFoncBuilder.class).andReturn(_bl1700AjouterRefFoncBuilder);
    EasyMock.expect(_bl1700AjouterRefFoncBuilder.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl1700AjouterRefFoncBuilder);
    Map<String, String> refFonc = new HashMap<>();
    refFonc.put(IRefFoncConstants.NOM_FICHIER, "GENERER-ERREUR-SPIRIT_20171017035054_v1.csv"); //$NON-NLS-1$
    EasyMock.expect(_bl1700AjouterRefFoncBuilder.refFonc(refFonc)).andReturn(_bl1700AjouterRefFoncBuilder);
    EasyMock.expect(_bl1700AjouterRefFoncBuilder.build()).andReturn(_bl1700AjouterRefFonc);
    EasyMock.expect(_bl1700AjouterRefFonc.execute(EasyMock.anyObject(IActivityCaller.class))).andReturn(null);
    Map<String, String> refFonc1 = new HashMap<>();
    refFonc1.put("cliOpe", "BSS_GP"); //$NON-NLS-1$ //$NON-NLS-2$
    refFonc1.put("noCpt", "1234567890"); //$NON-NLS-1$ //$NON-NLS-2$
    PowerMock.expectNew(BL1700_AjouterRefFoncBuilder.class).andReturn(_bl1700AjouterRefFoncBuilder);
    EasyMock.expect(_bl1700AjouterRefFoncBuilder.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl1700AjouterRefFoncBuilder);
    EasyMock.expect(_bl1700AjouterRefFoncBuilder.refFonc(refFonc1)).andReturn(_bl1700AjouterRefFoncBuilder);
    EasyMock.expect(_bl1700AjouterRefFoncBuilder.build()).andReturn(_bl1700AjouterRefFonc);
    EasyMock.expect(_bl1700AjouterRefFonc.execute(EasyMock.anyObject(IActivityCaller.class))).andReturn(null);

    PowerMock.expectNew(BL4600_CreerErreurSpiritBuilder.class).andReturn(_bl4600CreerErreurSpiritBuilder);
    EasyMock.expect(_bl4600CreerErreurSpiritBuilder.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl4600CreerErreurSpiritBuilder);
    EasyMock.expect(_bl4600CreerErreurSpiritBuilder.retour(EasyMock.anyObject(Retour.class))).andReturn(_bl4600CreerErreurSpiritBuilder);
    EasyMock.expect(_bl4600CreerErreurSpiritBuilder.build()).andReturn(_bl4600CreeErreurSpirit);
    EasyMock.expect(_bl4600CreeErreurSpirit.execute(EasyMock.anyObject(IActivityCaller.class))).andReturn(null);
    EasyMock.expect(_bl4600CreeErreurSpirit.getRetour()).andReturn(RetourFactory.createOkRetour());

    PowerMock.expectNew(BL1200_DeplacerFichierBuilder.class).andReturn(_bl1200DeplacerFichierBuilder);
    EasyMock.expect(_bl1200DeplacerFichierBuilder.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl1200DeplacerFichierBuilder);
    EasyMock.expect(_bl1200DeplacerFichierBuilder.nomFichier(EasyMock.startsWith("GENERER-ERREUR-SPIRIT_20171017035054_v1.csv"))).andReturn(_bl1200DeplacerFichierBuilder); //$NON-NLS-1$
    EasyMock.expect(_bl1200DeplacerFichierBuilder.repertoireSrc(_tempFolderConfig.getAbsolutePath())).andReturn(_bl1200DeplacerFichierBuilder);
    EasyMock.expect(_bl1200DeplacerFichierBuilder.repertoireDes(_tempFolderSucces.getAbsolutePath())).andReturn(_bl1200DeplacerFichierBuilder);
    EasyMock.expect(_bl1200DeplacerFichierBuilder.build()).andReturn(_bl1200DeplacerFichier);
    EasyMock.expect(_bl1200DeplacerFichier.execute(EasyMock.anyObject(IActivityCaller.class))).andReturn(null);
    EasyMock.expect(_bl1200DeplacerFichier.getRetour()).andReturn(RetourFactory.createOkRetour());
    PowerMock.replayAll();
    _currentInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);

    final Response expected = new Response(ErrorCode.OK_00201, response);

    assertEquals(expected.getMarshalledResponseJson(), request.getResponse().getMarshalledResponseJson());
    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());

  }

  /**
   * Test KO with bad configuration <br/>
   *
   *
   * <b>Entrée:</b> input valid and correct data in file <br/>
   * <b>Attendu:</b> OK.<br/>
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void PP0315_GenererErreurSpirit_KO_001() throws Throwable
  {

    ConcurrentHashMap<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.clear();
    Request request = new Request(DEFAULT_PROCESSNAME, "idProcess", "idClient"); //$NON-NLS-1$ //$NON-NLS-2$
    PowerMock.replayAll();
    _currentInstance.run(request);
    PowerMock.verifyAll();

    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, "Les paramètres de config sont manquants"); //$NON-NLS-1$
    retour.setActivite("PP0315_BL001_VerifierDonnees");
    com.bytel.ravel.types.Retour retourp = RetourConverter.convertToJsonRetour(retour);
    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    response.setResult(GsonTools.getIso8601Ms().toJson(retourp));
    final Response expected = new Response(ErrorCode.KO_00500, response);
    assertEquals(expected.getMarshalledResponseJson(), request.getResponse().getMarshalledResponseJson());
    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());

  }

  /**
   * Test KO file without header <br/>
   *
   *
   * <b>Entrée:</b> input valid and correct data in file <br/>
   * <b>Attendu:</b> OK.<br/>
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void PP0315_GenererErreurSpirit_KO_002() throws Throwable
  {
    String configXml = MarshallTools.marshall(_configuration);
    //creation du fichier de configuration dans le dossier temporaire Config
    File file = File.createTempFile("ConfigurationPP0315", "xml", _tempFolderConfig); //$NON-NLS-1$ //$NON-NLS-2$
    BufferedWriter bw = new BufferedWriter(new FileWriter(file));
    bw.write(configXml);
    bw.close();
    String filename = getFilePath("GENERER.csv"); //$NON-NLS-1$
    _configuration.setMasqueNomFichier("GENERER*"); //$NON-NLS-1$
    //copie du fichier de configuration OLT dans le dossier de configuration temporaire Config
    copyFileConfig(filename, _tempFolderConfig + File.separator + "GENERER.csv"); //$NON-NLS-1$
    Request request = new Request(DEFAULT_PROCESSNAME, "idProcess", "idClient"); //$NON-NLS-1$ //$NON-NLS-2$

    PowerMock.expectNew(BL3800_TrouverFichierBuilder.class).andReturn(_bl3800TrouverFichierBuilder);
    EasyMock.expect(_bl3800TrouverFichierBuilder.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl3800TrouverFichierBuilder);
    EasyMock.expect(_bl3800TrouverFichierBuilder.repertoire(_tempFolderConfig.getAbsolutePath())).andReturn(_bl3800TrouverFichierBuilder);
    EasyMock.expect(_bl3800TrouverFichierBuilder.masqueNomFichier("GENERER-ERREUR-SPIRIT*")).andReturn(_bl3800TrouverFichierBuilder); //$NON-NLS-1$
    EasyMock.expect(_bl3800TrouverFichierBuilder.build()).andReturn(_bl3800TrouverFichier);
    EasyMock.expect(_bl3800TrouverFichier.execute(EasyMock.anyObject(IActivityCaller.class))).andReturn(new Pair<String, Retour>("GENERER.csv", RetourFactory.createOkRetour())); //$NON-NLS-1$
    PowerMock.expectNew(BL1700_AjouterRefFoncBuilder.class).andReturn(_bl1700AjouterRefFoncBuilder);
    EasyMock.expect(_bl1700AjouterRefFoncBuilder.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl1700AjouterRefFoncBuilder);
    Map<String, String> refFonc = new HashMap<>();
    refFonc.put(IRefFoncConstants.NOM_FICHIER, "GENERER.csv"); //$NON-NLS-1$
    EasyMock.expect(_bl1700AjouterRefFoncBuilder.refFonc(refFonc)).andReturn(_bl1700AjouterRefFoncBuilder);
    EasyMock.expect(_bl1700AjouterRefFoncBuilder.build()).andReturn(_bl1700AjouterRefFonc);
    EasyMock.expect(_bl1700AjouterRefFonc.execute(EasyMock.anyObject(IActivityCaller.class))).andReturn(null);
    PowerMock.expectNew(BL3900_DeplacerEtRenommerFichierBuilder.class).andReturn(_bl3900DeplacerEtRenommerFichierBuilder);
    EasyMock.expect(_bl3900DeplacerEtRenommerFichierBuilder.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl3900DeplacerEtRenommerFichierBuilder);
    EasyMock.expect(_bl3900DeplacerEtRenommerFichierBuilder.nomFichierSrc(("GENERER.csv"))).andReturn(_bl3900DeplacerEtRenommerFichierBuilder);//$NON-NLS-1$
    EasyMock.expect(_bl3900DeplacerEtRenommerFichierBuilder.nomFichierDes(EasyMock.startsWith("GENERER.csv"))).andReturn(_bl3900DeplacerEtRenommerFichierBuilder); //$NON-NLS-1$
    EasyMock.expect(_bl3900DeplacerEtRenommerFichierBuilder.repertoireSrc(_tempFolderConfig.getAbsolutePath())).andReturn(_bl3900DeplacerEtRenommerFichierBuilder);
    EasyMock.expect(_bl3900DeplacerEtRenommerFichierBuilder.repertoireDes(_tempFolderEchec.getAbsolutePath())).andReturn(_bl3900DeplacerEtRenommerFichierBuilder);
    EasyMock.expect(_bl3900DeplacerEtRenommerFichierBuilder.build()).andReturn(_bl3900DeplacerEtRenommerFichier);
    EasyMock.expect(_bl3900DeplacerEtRenommerFichier.execute(EasyMock.anyObject(IActivityCaller.class))).andReturn(null);
    EasyMock.expect(_bl3900DeplacerEtRenommerFichier.getRetour()).andReturn(RetourFactory.createOkRetour());

    PowerMock.replayAll();
    _currentInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    final Response expected = new Response(ErrorCode.OK_00201, response);
    assertEquals(expected.getMarshalledResponseJson(), request.getResponse().getMarshalledResponseJson());
    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());

  }

  /**
   * Test KO with _bl4600CreeErreurSpirit return KO<br/>
   *
   *
   * <b>Entrée:</b> input valid and correct data in file <br/>
   * <b>Attendu:</b> OK.<br/>
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void PP0315_GenererErreurSpirit_KO_003() throws Throwable
  {

    Request request = new Request(DEFAULT_PROCESSNAME, "idProcess", "idClient"); //$NON-NLS-1$ //$NON-NLS-2$
    PowerMock.expectNew(BL3800_TrouverFichierBuilder.class).andReturn(_bl3800TrouverFichierBuilder);
    EasyMock.expect(_bl3800TrouverFichierBuilder.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl3800TrouverFichierBuilder);
    EasyMock.expect(_bl3800TrouverFichierBuilder.repertoire(_tempFolderConfig.getAbsolutePath())).andReturn(_bl3800TrouverFichierBuilder);
    EasyMock.expect(_bl3800TrouverFichierBuilder.masqueNomFichier("GENERER-ERREUR-SPIRIT*")).andReturn(_bl3800TrouverFichierBuilder); //$NON-NLS-1$
    EasyMock.expect(_bl3800TrouverFichierBuilder.build()).andReturn(_bl3800TrouverFichier);
    EasyMock.expect(_bl3800TrouverFichier.execute(EasyMock.anyObject(IActivityCaller.class))).andReturn(new Pair<String, Retour>("GENERER-ERREUR-SPIRIT_20171017035054_v1.csv", RetourFactory.createOkRetour())); //$NON-NLS-1$
    PowerMock.expectNew(BL1700_AjouterRefFoncBuilder.class).andReturn(_bl1700AjouterRefFoncBuilder);
    EasyMock.expect(_bl1700AjouterRefFoncBuilder.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl1700AjouterRefFoncBuilder);
    Map<String, String> refFonc = new HashMap<>();
    refFonc.put(IRefFoncConstants.NOM_FICHIER, "GENERER-ERREUR-SPIRIT_20171017035054_v1.csv"); //$NON-NLS-1$
    EasyMock.expect(_bl1700AjouterRefFoncBuilder.refFonc(refFonc)).andReturn(_bl1700AjouterRefFoncBuilder);
    EasyMock.expect(_bl1700AjouterRefFoncBuilder.build()).andReturn(_bl1700AjouterRefFonc);
    EasyMock.expect(_bl1700AjouterRefFonc.execute(EasyMock.anyObject(IActivityCaller.class))).andReturn(null);
    Map<String, String> refFonc1 = new HashMap<>();
    refFonc1.put("cliOpe", "BSS_GP"); //$NON-NLS-1$ //$NON-NLS-2$
    refFonc1.put("noCpt", "1234567890"); //$NON-NLS-1$ //$NON-NLS-2$
    PowerMock.expectNew(BL1700_AjouterRefFoncBuilder.class).andReturn(_bl1700AjouterRefFoncBuilder);
    EasyMock.expect(_bl1700AjouterRefFoncBuilder.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl1700AjouterRefFoncBuilder);
    EasyMock.expect(_bl1700AjouterRefFoncBuilder.refFonc(refFonc1)).andReturn(_bl1700AjouterRefFoncBuilder);
    EasyMock.expect(_bl1700AjouterRefFoncBuilder.build()).andReturn(_bl1700AjouterRefFonc);
    EasyMock.expect(_bl1700AjouterRefFonc.execute(EasyMock.anyObject(IActivityCaller.class))).andReturn(null);
    PowerMock.expectNew(BL4600_CreerErreurSpiritBuilder.class).andReturn(_bl4600CreerErreurSpiritBuilder);
    EasyMock.expect(_bl4600CreerErreurSpiritBuilder.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl4600CreerErreurSpiritBuilder);

    EasyMock.expect(_bl4600CreerErreurSpiritBuilder.retour(EasyMock.anyObject(Retour.class))).andReturn(_bl4600CreerErreurSpiritBuilder);
    EasyMock.expect(_bl4600CreerErreurSpiritBuilder.build()).andReturn(_bl4600CreeErreurSpirit);
    EasyMock.expect(_bl4600CreeErreurSpirit.execute(EasyMock.anyObject(IActivityCaller.class))).andReturn(null);
    EasyMock.expect(_bl4600CreeErreurSpirit.getRetour()).andReturn(RetourFactory.createKO("CAT-2", "ERROR", "ERROR")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    EasyMock.expect(_bl4600CreeErreurSpirit.getRetour()).andReturn(RetourFactory.createKO("CAT-2", "ERROR", "ERROR")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    PowerMock.expectNew(BL3900_DeplacerEtRenommerFichierBuilder.class).andReturn(_bl3900DeplacerEtRenommerFichierBuilder);
    EasyMock.expect(_bl3900DeplacerEtRenommerFichierBuilder.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl3900DeplacerEtRenommerFichierBuilder);
    EasyMock.expect(_bl3900DeplacerEtRenommerFichierBuilder.nomFichierSrc(("GENERER-ERREUR-SPIRIT_20171017035054_v1.csv"))).andReturn(_bl3900DeplacerEtRenommerFichierBuilder);//$NON-NLS-1$
    EasyMock.expect(_bl3900DeplacerEtRenommerFichierBuilder.nomFichierDes(EasyMock.startsWith("GENERER-ERREUR-SPIRIT_20171017035054_v1.csv"))).andReturn(_bl3900DeplacerEtRenommerFichierBuilder); //$NON-NLS-1$
    EasyMock.expect(_bl3900DeplacerEtRenommerFichierBuilder.repertoireSrc(_tempFolderConfig.getAbsolutePath())).andReturn(_bl3900DeplacerEtRenommerFichierBuilder);
    EasyMock.expect(_bl3900DeplacerEtRenommerFichierBuilder.repertoireDes(_tempFolderEchec.getAbsolutePath())).andReturn(_bl3900DeplacerEtRenommerFichierBuilder);
    EasyMock.expect(_bl3900DeplacerEtRenommerFichierBuilder.build()).andReturn(_bl3900DeplacerEtRenommerFichier);
    EasyMock.expect(_bl3900DeplacerEtRenommerFichier.execute(EasyMock.anyObject(IActivityCaller.class))).andReturn(null);
    EasyMock.expect(_bl3900DeplacerEtRenommerFichier.getRetour()).andReturn(RetourFactory.createOkRetour());

    PowerMock.replayAll();
    _currentInstance.run(request);
    PowerMock.verifyAll();
    Retour retour = RetourFactoryForTU.createKO(IMegConsts.CAT2, "ERROR", "ERROR", null); //$NON-NLS-1$ //$NON-NLS-2$
    com.bytel.ravel.types.Retour retourp = RetourConverter.convertToJsonRetour(retour);
    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    response.setResult(GsonTools.getIso8601Ms().toJson(retourp));
    final Response expected = new Response(ErrorCode.KO_00500, response);
    assertEquals(expected.getMarshalledResponseJson(), request.getResponse().getMarshalledResponseJson());
    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());

  }

  /**
   * Test KO with incorrect data in the file.<br/>
   *
   *
   * <b>Entrée:</b> input valid but incorrect data inside file <br/>
   * <b>Attendu:</b> OK.<br/>
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void PP0315_GenererErreurSpirit_KO_004() throws Throwable
  {
    String configXml = MarshallTools.marshall(_configuration);
    //creation du fichier de configuration dans le dossier temporaire Config
    File file = File.createTempFile("ConfigurationPP0315", "xml", _tempFolderConfig); //$NON-NLS-1$ //$NON-NLS-2$
    BufferedWriter bw = new BufferedWriter(new FileWriter(file));
    bw.write(configXml);
    bw.close();
    String filename = getFilePath("GENERER2.csv"); //$NON-NLS-1$
    _configuration.setMasqueNomFichier("GENERER*"); //$NON-NLS-1$
    //copie du fichier de configuration OLT dans le dossier de configuration temporaire Config
    copyFileConfig(filename, _tempFolderConfig + File.separator + "GENERER2.csv"); //$NON-NLS-1$
    Request request = new Request(DEFAULT_PROCESSNAME, "idProcess", "idClient"); //$NON-NLS-1$ //$NON-NLS-2$

    PowerMock.expectNew(BL3800_TrouverFichierBuilder.class).andReturn(_bl3800TrouverFichierBuilder);
    EasyMock.expect(_bl3800TrouverFichierBuilder.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl3800TrouverFichierBuilder);
    EasyMock.expect(_bl3800TrouverFichierBuilder.repertoire(_tempFolderConfig.getAbsolutePath())).andReturn(_bl3800TrouverFichierBuilder);
    EasyMock.expect(_bl3800TrouverFichierBuilder.masqueNomFichier("GENERER-ERREUR-SPIRIT*")).andReturn(_bl3800TrouverFichierBuilder); //$NON-NLS-1$
    EasyMock.expect(_bl3800TrouverFichierBuilder.build()).andReturn(_bl3800TrouverFichier);
    EasyMock.expect(_bl3800TrouverFichier.execute(EasyMock.anyObject(IActivityCaller.class))).andReturn(new Pair<String, Retour>("GENERER2.csv", RetourFactory.createOkRetour())); //$NON-NLS-1$
    PowerMock.expectNew(BL1700_AjouterRefFoncBuilder.class).andReturn(_bl1700AjouterRefFoncBuilder);
    EasyMock.expect(_bl1700AjouterRefFoncBuilder.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl1700AjouterRefFoncBuilder);
    Map<String, String> refFonc = new HashMap<>();
    refFonc.put(IRefFoncConstants.NOM_FICHIER, "GENERER2.csv"); //$NON-NLS-1$
    EasyMock.expect(_bl1700AjouterRefFoncBuilder.refFonc(refFonc)).andReturn(_bl1700AjouterRefFoncBuilder);
    EasyMock.expect(_bl1700AjouterRefFoncBuilder.build()).andReturn(_bl1700AjouterRefFonc);
    EasyMock.expect(_bl1700AjouterRefFonc.execute(EasyMock.anyObject(IActivityCaller.class))).andReturn(null);

    PowerMock.replayAll();
    _currentInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    final Response expected = new Response(ErrorCode.OK_00201, response);
    assertEquals(expected.getMarshalledResponseJson(), request.getResponse().getMarshalledResponseJson());
    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());

  }

  /**
   * Get Path from file name
   *
   * @param filename
   *          file name
   * @return String file
   */
  private String getFilePath(String filename)
  {
    String os = System.getProperty("os.name").toLowerCase(); //$NON-NLS-1$
    URL url = this.getClass().getResource("/" + filename); //$NON-NLS-1$
    if (url == null)
    {
      return filename;
    }

    String tmp = url.getFile();
    if (os.indexOf("win") >= 0) //$NON-NLS-1$
    {
      tmp = tmp.replace('/', '\\');
      if (tmp.startsWith("\\")) //$NON-NLS-1$
      {
        tmp = tmp.substring(1);
      }
    }

    return tmp;

  }

}
