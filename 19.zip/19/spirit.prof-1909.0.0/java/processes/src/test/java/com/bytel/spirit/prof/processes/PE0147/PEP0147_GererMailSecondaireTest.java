/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PE0147;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import java.io.Closeable;
import java.io.IOException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.RandomStringUtils;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.reflect.Whitebox;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.response.IRavelResponse;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.ACManagerUtil;
import com.bytel.ravel.common.utils.DateTimeTools.DateTimeFormatPattern;
import com.bytel.ravel.common.utils.Pair;
import com.bytel.ravel.common.utils.RetourFactoryForTU;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.ProcessManager;
import com.bytel.spirit.common.connectors.cmd.CMDProxy;
import com.bytel.spirit.common.connectors.reftech.ReftechProxy;
import com.bytel.spirit.common.connectors.reftech.structs.ReftechRetour;
import com.bytel.spirit.common.connectors.rex.REXProxy;
import com.bytel.spirit.common.connectors.rpg.RPGProxy;
import com.bytel.spirit.common.connectors.rst.RSTProxy;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.ressources.RetourConverter;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.TypeObjetCommercial;
import com.bytel.spirit.common.shared.saab.cmd.Commande;
import com.bytel.spirit.common.shared.saab.cmd.request.CreateModificationCommercialeRequest;
import com.bytel.spirit.common.shared.saab.rex.request.CreateErreurSpiritRequest;
import com.bytel.spirit.common.shared.saab.rpg.PA;
import com.bytel.spirit.common.shared.saab.rpg.PFI;
import com.bytel.spirit.common.shared.saab.rpg.PaTypeCompteAcces;
import com.bytel.spirit.common.shared.saab.rpg.PaTypeCompteAccesSecondaire;
import com.bytel.spirit.common.shared.saab.rpg.Statut;
import com.bytel.spirit.common.shared.saab.rpg.TypePA;
import com.bytel.spirit.common.shared.saab.rpg.request.CreatePfiRequest;
import com.bytel.spirit.common.shared.saab.rst.ServiceTechnique;
import com.bytel.spirit.common.shared.saab.rst.StLienAllocationCommercial;
import com.bytel.spirit.prof.processes.Messages;
import com.bytel.spirit.prof.processes.PE0147.structs.PEP0147_Retour;
import com.bytel.spirit.prof.processes.PE0147.structs.PEP0147_RetourBL001;
import com.bytel.spirit.prof.shared.types.json.CommandeId;
import com.bytel.spirit.prof.shared.types.json.request.ServiceMailGererMailSecondaireRequest;
import com.bytel.spirit.prof.shared.types.json.request.ServiceMailGererMailSecondaireRequest.IdentifiantAcces;
import com.bytel.spirit.prof.shared.types.json.request.ServiceMailGererMailSecondaireRequest.MailSecondaire;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author mbaptist
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
@PrepareForTest({ PEP0147_GererMailSecondaire.class, ProcessManager.class, Tracabilite.class, ReftechProxy.class, RSTProxy.class, CMDProxy.class, RPGProxy.class, REXProxy.class })
public class PEP0147_GererMailSecondaireTest implements Closeable
{

  /**
   *
   */
  private static final String PEP0147_BL001_VERIFIER_DONNEES = "PEP0147_BL001_VerifierDonnees"; //$NON-NLS-1$
  /**
  *
  */
  private static final String PEP0147_BL200_CREERMAILSECONDAIRE = "PEP0147_BL200_CreerMailSecondaire"; //$NON-NLS-1$

  /**
   * Factory de génération des beans
   */
  private static PodamFactory __podam = new PodamFactoryImpl();

  /**
   * SPRING context
   */
  private static ClassPathXmlApplicationContext __context;

  /**
   * Tracabilite
   */
  private static Tracabilite _tracabilite;

  /**
   * Run before tests
   *
   * @throws Exception
   *           throw exception
   */
  @BeforeClass
  public static void setUpBeforeClass() throws Exception
  {
    ACManagerUtil.resetACManager();
    __context = new ClassPathXmlApplicationContext("classpath:BeansProcessTestMocks.xml"); //$NON-NLS-1$
  }

  /**
   * Instance of {@code PEI0018_CreerCommandeProvPhotoPfi}
   */
  private PEP0147_GererMailSecondaire _processInstance;

  /**
   * The mock object {@code Request}
   */
  private Request _request;

  /**
   * _CMDProxyMock Mock
   */
  @MockStrict
  private CMDProxy _cmdProxy;

  /**
   * RPG PRoxy
   */
  @MockStrict
  private RPGProxy _rpgProxy;

  /**
   * RPG PRoxy
   */
  @MockStrict
  private ReftechProxy _reftchProxy;

  /**
   * RPG PRoxy
   */
  @MockStrict
  private RSTProxy _rstProxy;

  /**
   * RPG PRoxy
   */
  @MockStrict
  private REXProxy _rexProxy;

  @Override
  public void close() throws IOException
  {
    __context.close();
  }

  @Before
  public void initAllConfiguration()
  {
    PowerMock.resetAll();
    PowerMock.mockStatic(CMDProxy.class);
    PowerMock.mockStatic(RPGProxy.class);
    PowerMock.mockStatic(RSTProxy.class);
    PowerMock.mockStatic(ReftechProxy.class);
    PowerMock.mockStatic(REXProxy.class);

  }

  /**
   * Tests the PEP0147_BL001_VerifierDonnees method when CMD004 returns KO
   *
   * <b>Inputs:</b> Generated KO for CM004 mock<br>
   * <b>Expected:</b> Retour {KO; CAT4; DONNEE_INVALIDE; ""}<br>
   *
   * @throws Exception
   *           on unexpected error
   */
  @Test
  public void PEP0147_BL001_VerifierDonnees_KO_001() throws Exception
  {
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);
    String idCmd = RandomStringUtils.random(5);

    Retour erreur = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INVALIDE, StringConstants.EMPTY_STRING, null);
    ConnectorResponse<Retour, Commande> responseExpected = new ConnectorResponse<Retour, Commande>(erreur, null);
    PEP0147_RetourBL001 pep0147_RetourBL001 = new PEP0147_RetourBL001();

    _processInstance = new PEP0147_GererMailSecondaire();

    PowerMock.mockStatic(CMDProxy.class);
    EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdProxy);
    EasyMock.expect(_cmdProxy.commandeLireUn(tracabilite, idCmd)).andReturn(responseExpected);

    PowerMock.replayAll();
    Pair<Retour, Commande> retour = Whitebox.invokeMethod(_processInstance, PEP0147_BL001_VERIFIER_DONNEES, tracabilite, idCmd);
    PowerMock.verifyAll();

    assertEquals(responseExpected._first, retour._first);
  }

  /**
   * Tests the PEP0147_BL001_VerifierDonnees method when the status of the command is not "ACQUITTE"
   *
   * <b>Inputs:</b> A command with the status "TRAITEE_NOK" <br>
   * <b>Expected:</b> Retour {KO; CAT-4; DONNEE_INVALIDE; La commande 'idCmd' est au statut TRAITEE_NOK, elle ne peut
   * pas être traitée par ce processus}<br>
   *
   * @throws Exception
   *           on unexpected error
   */
  @Test
  public void PEP0147_BL001_VerifierDonnees_KO_002() throws Exception
  {
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);
    String idCmd = RandomStringUtils.random(5);

    Commande commandeExpected = __podam.manufacturePojo(Commande.class);
    commandeExpected.setStatut("TRAITE_NOK"); //$NON-NLS-1$
    PEP0147_RetourBL001 pep0147_RetourBL001Expected = new PEP0147_RetourBL001();

    Retour retour = RetourFactoryForTU.createOkRetour();
    ConnectorResponse<Retour, Commande> responseExpected = new ConnectorResponse<Retour, Commande>(retour, commandeExpected);
    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.DONNEE_INVALIDE, MessageFormat.format(Messages.getString("PEP0147.CommandeNonTraitee"), responseExpected._second.getIdCmd(), responseExpected._second.getStatut()), null); //$NON-NLS-1$

    _processInstance = new PEP0147_GererMailSecondaire();

    PowerMock.mockStatic(CMDProxy.class);
    EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdProxy);
    EasyMock.expect(_cmdProxy.commandeLireUn(tracabilite, idCmd)).andReturn(responseExpected);

    PowerMock.replayAll();
    Pair<Retour, Commande> retourBL001 = Whitebox.invokeMethod(_processInstance, PEP0147_BL001_VERIFIER_DONNEES, tracabilite, idCmd);
    PowerMock.verifyAll();

    assertEquals(retourExpected.getLibelle(), retourBL001._first.getLibelle());
    assertEquals(retourExpected.getDiagnostic(), retourBL001._first.getDiagnostic());
    assertEquals(retourExpected.getCategorie(), retourBL001._first.getCategorie());
  }

  /**
   * Nominal case for the PEP0147_BL001_VerifierDonnees method<br>
   *
   * <b>Inputs:</b> Valid inputs <br>
   * <b>Expected:</b> Retour {OK}<br>
   *
   * @throws Exception
   *           on unexpected error
   */

  @Test
  public void PEP0147_BL001_VerifierDonnees_OK_001() throws Exception
  {
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);
    String idCmd = RandomStringUtils.random(5);

    Retour retourExpected = RetourFactoryForTU.createOkRetour();
    Commande commandeExpected = __podam.manufacturePojo(Commande.class);
    commandeExpected.setStatut("ACQUITTE"); //$NON-NLS-1$

    PEP0147_RetourBL001 pep0147_RetourBL001 = new PEP0147_RetourBL001();
    pep0147_RetourBL001.setStatut("ACTIF"); //$NON-NLS-1$
    pep0147_RetourBL001.setMail("loginMail"); //$NON-NLS-1$

    ServiceMailGererMailSecondaireRequest gererMailSecondaireRequest = __podam.manufacturePojo(ServiceMailGererMailSecondaireRequest.class);
    MailSecondaire mailSecondaire = new MailSecondaire();
    mailSecondaire.setStatut("ACTIF"); //$NON-NLS-1$
    mailSecondaire.setMail("loginMail"); //$NON-NLS-1$

    IdentifiantAcces identifiantAcces = new IdentifiantAcces();
    identifiantAcces.setLoginMail("loginMail"); //$NON-NLS-1$
    gererMailSecondaireRequest.setMailSecondaire(mailSecondaire);
    gererMailSecondaireRequest.setIdentifiantAcces(identifiantAcces);
    commandeExpected.setDonneesBrut(GsonTools.getIso8601Ms().toJson(gererMailSecondaireRequest));
    ConnectorResponse<Retour, Commande> responseExpected = new ConnectorResponse<Retour, Commande>(retourExpected, commandeExpected);

    _processInstance = new PEP0147_GererMailSecondaire();

    PowerMock.mockStatic(CMDProxy.class);
    EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdProxy);
    EasyMock.expect(_cmdProxy.commandeLireUn(tracabilite, idCmd)).andReturn(responseExpected);

    PowerMock.replayAll();
    Pair<Retour, PEP0147_RetourBL001> retour = Whitebox.invokeMethod(_processInstance, PEP0147_BL001_VERIFIER_DONNEES, tracabilite, idCmd);
    PowerMock.verifyAll();

    assertEquals(pep0147_RetourBL001.getStatut(), retour._second.getStatut());
    assertEquals(pep0147_RetourBL001.getMail(), retour._second.getMail());
  }

  /**
   * Tests the PEP0147_BL002_FormaterReponse method when the retour is KO
   *
   * <b>Inputs:</b> Retour KO <br>
   * <b>Expected:</b> Retour {KO; CAT-4; DONNEE_INCONNUE; Donnee inconnue} and ReponseFonctionnelle null<br>
   *
   * @throws Exception
   *           on unexpected error
   */
  @Test
  public void PEP0147_BL002_FormaterReponse_KO_001() throws Exception
  {
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);
    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "Donnee inconnue", null); //$NON-NLS-1$

    _processInstance = new PEP0147_GererMailSecondaire();

    PowerMock.replayAll();
    PEP0147_Retour retourBL002 = Whitebox.invokeMethod(_processInstance, "PEP0147_BL002_FormaterReponse", tracabilite, retour, null); //$NON-NLS-1$
    PowerMock.verifyAll();

    assertNull(retourBL002.getReponseFonctionnelle());
    assertEquals(retour, RetourConverter.convertFromJsonRetour(retourBL002.getRetour()));
  }

  /**
   * Tests the PEP0147_BL002_FormaterReponse method when the PFI is null
   *
   * <b>Inputs:</b> Retour OK ans PFI null <br>
   * <b>Expected:</b> Retour {OK} and ReponseFonctionnelle null<br>
   *
   * @throws Exception
   *           on unexpected error
   */
  @Test
  public void PEP0147_BL002_FormaterReponse_KO_002() throws Exception
  {
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);
    Retour retour = RetourFactoryForTU.createOkRetour();

    _processInstance = new PEP0147_GererMailSecondaire();

    PowerMock.replayAll();
    PEP0147_Retour retourBL002 = Whitebox.invokeMethod(_processInstance, "PEP0147_BL002_FormaterReponse", tracabilite, retour, null); //$NON-NLS-1$
    PowerMock.verifyAll();

    assertNull(retourBL002.getReponseFonctionnelle());
    assertEquals(retour, RetourConverter.convertFromJsonRetour(retourBL002.getRetour()));
  }

  /**
   * Tests the PEP0147_BL002_FormaterReponse method nominal case
   *
   * <b>Inputs:</b> Retour OK and PFI not null<br>
   * <b>Expected:</b> Retour {OK} ReponseFonctionnelle {clientOperateur = pfi.getClientOperateur; noCompte =
   * pfi.getNoCompte}<br>
   *
   * @throws Exception
   *           on unexpected error
   */
  @Test
  public void PEP0147_BL002_FormaterReponse_OK_001() throws Exception
  {
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);
    Retour retour = RetourFactoryForTU.createOkRetour();
    PFI pfi = __podam.manufacturePojo(PFI.class);

    _processInstance = new PEP0147_GererMailSecondaire();

    PowerMock.replayAll();
    PEP0147_Retour retourBL002 = Whitebox.invokeMethod(_processInstance, "PEP0147_BL002_FormaterReponse", tracabilite, retour, pfi); //$NON-NLS-1$
    PowerMock.verifyAll();

    assertEquals(pfi.getClientOperateur(), retourBL002.getReponseFonctionnelle().getClientOperateur());
    assertEquals(pfi.getNoCompte(), retourBL002.getReponseFonctionnelle().getNoCompte());
    assertEquals(retour, RetourConverter.convertFromJsonRetour(retourBL002.getRetour()));
  }

  /**
   * Tests the PEP0147_BL100_RecupererPFI method when is generated an exception with category CAT-2
   *
   * <b>Inputs:</b> A commande.getClientOperateur() and commande.getNoCompte() <br>
   * <b>Expected:</b> Retour {KO; CAT-2; SERVICE_TIERS_INDISPONIBLE; exception}<br>
   *
   * @throws Exception
   *           on unexpected error
   */

  @Test
  public void PEP0147_BL100_RecupererPFI_KO_001() throws Exception
  {
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);
    Commande commande = __podam.manufacturePojo(Commande.class);

    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, "exception", null); //$NON-NLS-1$

    ConnectorResponse<Retour, PFI> responseExpected = new ConnectorResponse<Retour, PFI>(retourExpected, null);

    _processInstance = new PEP0147_GererMailSecondaire();

    PowerMock.mockStatic(RPGProxy.class);
    EasyMock.expect(RPGProxy.getInstance()).andReturn(_rpgProxy);
    EasyMock.expect(_rpgProxy.pfiLireUn(tracabilite, commande.getClientOperateur(), commande.getNoCompte())).andReturn(responseExpected);

    PowerMock.replayAll();
    Pair<Retour, Commande> retour = Whitebox.invokeMethod(_processInstance, "PEP0147_BL100_RecupererPFI", tracabilite, commande); //$NON-NLS-1$
    PowerMock.verifyAll();

    assertEquals(retourExpected, retour._first);
    assertEquals(null, retour._second);
  }

  /**
   * Tests the PEP0147_BL100_RecupererPFI method when is generated an exception with category CAT-10
   *
   * <b>Inputs:</b> A commande.getClientOperateur() and commande.getNoCompte() <br>
   * <b>Expected:</b> Retour {KO; CAT-10; TRAITEMENT_ARRETE; exception}<br>
   *
   * @throws Exception
   *           on unexpected error
   */

  @Test
  public void PEP0147_BL100_RecupererPFI_KO_002() throws Exception
  {
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);
    Commande commande = __podam.manufacturePojo(Commande.class);

    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegConsts.TRAITEMENT_ARRETE, "exception", null); //$NON-NLS-1$

    ConnectorResponse<Retour, PFI> responseExpected = new ConnectorResponse<Retour, PFI>(retourExpected, null);

    _processInstance = new PEP0147_GererMailSecondaire();

    PowerMock.mockStatic(RPGProxy.class);
    EasyMock.expect(RPGProxy.getInstance()).andReturn(_rpgProxy);
    EasyMock.expect(_rpgProxy.pfiLireUn(tracabilite, commande.getClientOperateur(), commande.getNoCompte())).andReturn(responseExpected);

    PowerMock.replayAll();
    Pair<Retour, Commande> retour = Whitebox.invokeMethod(_processInstance, "PEP0147_BL100_RecupererPFI", tracabilite, commande); //$NON-NLS-1$
    PowerMock.verifyAll();

    assertEquals(retourExpected, retour._first);
    assertEquals(null, retour._second);
  }

  /**
   * Nominal case for the PEP0147_BL001_RecupererPFI method<br>
   *
   * <b>Inputs:</b> Valid inputs <br>
   * <b>Expected:</b> Retour {OK}<br>
   *
   * @throws Exception
   *           on unexpected error
   */
  @Test
  public void PEP0147_BL100_RecupererPFI_OK_001() throws Exception
  {
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);
    Commande commande = __podam.manufacturePojo(Commande.class);

    Retour retourExpected = RetourFactoryForTU.createOkRetour();
    PFI pfiExpected = __podam.manufacturePojo(PFI.class);
    ConnectorResponse<Retour, PFI> responseExpected = new ConnectorResponse<Retour, PFI>(retourExpected, pfiExpected);

    _processInstance = new PEP0147_GererMailSecondaire();

    PowerMock.mockStatic(RPGProxy.class);
    EasyMock.expect(RPGProxy.getInstance()).andReturn(_rpgProxy);
    EasyMock.expect(_rpgProxy.pfiLireUn(tracabilite, commande.getClientOperateur(), commande.getNoCompte())).andReturn(responseExpected);

    PowerMock.replayAll();
    Pair<Retour, Commande> retour = Whitebox.invokeMethod(_processInstance, "PEP0147_BL100_RecupererPFI", tracabilite, commande); //$NON-NLS-1$
    PowerMock.verifyAll();

    assertEquals(retourExpected, retour._first);
    assertEquals(pfiExpected, retour._second);
  }

  /**
   * // si PA compte ACCES non trouvé
   *
   * @throws Exception
   */
  @Test
  public void PEP0147_BL200_CreerMailSecondaire_KO_001() throws Exception
  {
    Tracabilite tracabilite = new Tracabilite();
    Commande commande = new Commande();
    PFI pfi = new PFI();
    List<PA> listpa = new ArrayList<>();
    PaTypeCompteAcces paType = new PaTypeCompteAcces("charles.rock"); //$NON-NLS-1$
    PA pa = new PA(null, TypePA.COMPTE_ACCES_SECONDAIRE.name(), Statut.ACTIF, null, null);
    pa.setPaTypeCompteAcces(paType);
    listpa.add(pa);
    pfi.setPa(listpa);
    PEP0147_GererMailSecondaire pep0147 = new PEP0147_GererMailSecondaire();
    pep0147.initializeContext();
    PowerMock.replayAll();

    Retour bl101retour = Whitebox.invokeMethod(pep0147, "PEP0147_BL200_CreerMailSecondaire", tracabilite, pfi, "charles.rock", commande); //$NON-NLS-1$ //$NON-NLS-2$
    PowerMock.verify();
    assertEquals(bl101retour.getDiagnostic(), IMegConsts.DONNEE_INCONNUE);
    assertEquals(bl101retour.getCategorie(), IMegConsts.CAT4);
    assertEquals(bl101retour.getLibelle(), "PA COMPTE_ACCES non trouvé pour ce pfi"); //$NON-NLS-1$
    assertEquals(bl101retour.getResultat(), "NOK"); //$NON-NLS-1$
  }

  /**
   * @throws Exception
   */
  @Test
  public void PEP0147_BL200_CreerMailSecondaire_OK() throws Exception
  {
    Tracabilite tracabilite = new Tracabilite();
    Commande commande = new Commande();
    PFI pfi = new PFI();
    List<PA> listpa = new ArrayList<>();
    PaTypeCompteAcces paType = new PaTypeCompteAcces("charles.rock"); //$NON-NLS-1$
    PA pa = new PA(null, TypePA.COMPTE_ACCES_SECONDAIRE.name(), Statut.ACTIF, null, null);
    pa.setPaTypeCompteAcces(paType);
    listpa.add(pa);
    pfi.setPa(listpa);

    paType = new PaTypeCompteAcces("charles.rock"); //$NON-NLS-1$
    pa = new PA(null, TypePA.COMPTE_ACCES.name(), Statut.ACTIF, null, null);
    pa.setPaTypeCompteAcces(paType);
    listpa.add(pa);
    pfi.setPa(listpa);
    createMockCmd(RetourFactoryForTU.createOkRetour(), null);
    createMockRPG(RetourFactoryForTU.createOkRetour(), pfi);
    PEP0147_GererMailSecondaire pep0147 = new PEP0147_GererMailSecondaire();
    pep0147.initializeContext();
    PowerMock.replayAll();

    Retour bl101retour = Whitebox.invokeMethod(pep0147, "PEP0147_BL200_CreerMailSecondaire", tracabilite, pfi, "charles.rock", commande); //$NON-NLS-1$ //$NON-NLS-2$
    PowerMock.verify();
    assertEquals(bl101retour.getDiagnostic(), null);
    assertEquals(bl101retour.getCategorie(), null);
    assertEquals(bl101retour.getLibelle(), null);
    assertEquals(bl101retour.getResultat(), "OK"); //$NON-NLS-1$
  }

  /**
   * PA type acces secondaire Non trouvé
   *
   * @throws Exception
   */
  @Test
  public void PEP0147_BL300_ResilierMailSecondaire_KO_001() throws Exception
  {

    Tracabilite tracabilite = new Tracabilite();
    Commande commande = new Commande();

    PFI pfi = new PFI();
    List<PA> listpa = new ArrayList<>();
    PaTypeCompteAcces paType = new PaTypeCompteAcces("charles.rock"); //$NON-NLS-1$
    PA pa = new PA(null, TypePA.COMPTE_ACCES.name(), Statut.ACTIF, null, null);
    pa.setPaTypeCompteAcces(paType);
    pa.setIdentifiantFonctionnelPA("identifiantFonctionnelPA"); //$NON-NLS-1$
    listpa.add(pa);
    pfi.setPa(listpa);
    PEP0147_GererMailSecondaire pep0147 = new PEP0147_GererMailSecondaire();
    pep0147.initializeContext();

    StLienAllocationCommercial stliencommercial = new StLienAllocationCommercial("PA", com.bytel.spirit.common.shared.saab.rst.Statut.ACTIF.name(), "ocClientOperateur", "ocNoCompte", TypeObjetCommercial.PA.name(), "BSS_GP", "ocNoCompte", "idRessource", "ADRESSE_MAIL"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$
    stliencommercial.setOcIdentifiantFonctionnelPA("identifiantFonctionnelPA"); //$NON-NLS-1$

    List<ServiceTechnique> listServTech = new ArrayList<>();
    listServTech.add(stliencommercial);
    ConnectorResponse<Retour, List<ServiceTechnique>> connectRep = new ConnectorResponse<Retour, List<ServiceTechnique>>(RetourFactoryForTU.createOkRetour(), listServTech);
    //    createMockRST(connectRep, pfi);

    PowerMock.replayAll();
    Retour bl101retour = Whitebox.invokeMethod(pep0147, "PEP0147_BL300_ResilierMailSecondaire", tracabilite, pfi, "charles.rock", commande); //$NON-NLS-1$ //$NON-NLS-2$
    PowerMock.verify();

    //    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "Lien d'allocation de la ressource adresse mail non trouvée", null);
    Retour retourExpected = RetourFactoryForTU.createOkRetour();

    assertEquals(retourExpected, bl101retour);

  }

  /**
   * PEP0147_BL300_ResilierMailSecondaire nominal
   *
   * @throws Exception
   */
  @Test
  public void PEP0147_BL300_ResilierMailSecondaire_OK_001() throws Exception
  {

    Tracabilite tracabilite = new Tracabilite();
    Commande commande = new Commande();
    PFI pfi = new PFI();
    List<PA> listpa = new ArrayList<>();
    PaTypeCompteAccesSecondaire paType = new PaTypeCompteAccesSecondaire("charles.rock"); //$NON-NLS-1$
    PA pa = new PA(null, TypePA.COMPTE_ACCES_SECONDAIRE.name(), Statut.ACTIF, null, null);
    pa.setPaTypeCompteAccesSecondaire(paType);
    pa.setIdentifiantFonctionnelPA("identifiantFonctionnelPA"); //$NON-NLS-1$
    listpa.add(pa);
    pfi.setPa(listpa);
    PEP0147_GererMailSecondaire pep0147 = new PEP0147_GererMailSecondaire();
    pep0147.initializeContext();

    StLienAllocationCommercial stliencommercial = new StLienAllocationCommercial("PA", com.bytel.spirit.common.shared.saab.rst.Statut.ACTIF.name(), "ocClientOperateur", "ocNoCompte", TypeObjetCommercial.PA.name(), "BSS_GP", "ocNoCompte", "charles.rock", "ADRESSE_MAIL"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$
    stliencommercial.setOcIdentifiantFonctionnelPA("identifiantFonctionnelPA"); //$NON-NLS-1$

    List<ServiceTechnique> listServTech = new ArrayList<>();
    listServTech.add(stliencommercial);
    ConnectorResponse<Retour, List<ServiceTechnique>> connectRep = new ConnectorResponse<Retour, List<ServiceTechnique>>(RetourFactoryForTU.createOkRetour(), listServTech);
    //    createMockRST(connectRep, pfi);
    createMockRefTech(1);
    createMockCmdModif(RetourFactoryForTU.createOkRetour(), null);
    createMockRPG(RetourFactoryForTU.createOkRetour(), pfi);
    PowerMock.replayAll();
    Retour bl101retour = Whitebox.invokeMethod(pep0147, "PEP0147_BL300_ResilierMailSecondaire", tracabilite, pfi, "charles.rock", commande); //$NON-NLS-1$ //$NON-NLS-2$
    PowerMock.verify();

    assertEquals(RetourFactoryForTU.createOkRetour(), bl101retour);

  }

  /**
   * PEP0147_GererMailSecondaire_KO_001 BL001_verifierDonnees retour KO
   *
   * @throws Throwable
   */
  @Test
  @Ignore
  public void PEP0147_GererMailSecondaire_KO_001() throws Throwable
  {

    Tracabilite tracabilite = new Tracabilite();
    Commande commande = new Commande();
    PFI pfi = new PFI();
    List<PA> listpa = new ArrayList<>();
    PaTypeCompteAcces paType = new PaTypeCompteAcces("charles.rock"); //$NON-NLS-1$
    PA pa = new PA(null, TypePA.COMPTE_ACCES_SECONDAIRE.name(), Statut.ACTIF, null, null);
    pa.setPaTypeCompteAcces(paType);
    pa.setIdentifiantFonctionnelPA("identifiantFonctionnelPA"); //$NON-NLS-1$
    listpa.add(pa);
    pfi.setPa(listpa);
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    PEP0147_GererMailSecondaire pep0147 = new PEP0147_GererMailSecondaire();
    pep0147.initializeContext();
    StLienAllocationCommercial stliencommercial = new StLienAllocationCommercial("PA", com.bytel.spirit.common.shared.saab.rst.Statut.ACTIF.name(), "ocClientOperateur", "ocNoCompte", TypeObjetCommercial.PA.name(), "BSS_GP", "ocNoCompte", "idRessource", "ADRESSE_MAIL"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$
    stliencommercial.setOcIdentifiantFonctionnelPA("identifiantFonctionnelPA"); //$NON-NLS-1$
    List<ServiceTechnique> listServTech = new ArrayList<>();
    listServTech.add(stliencommercial);

    CommandeId command = new CommandeId("idCommande"); //$NON-NLS-1$
    commande.setStatut("ACTIF"); //$NON-NLS-1$
    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(command, CommandeId.class);
    request.setPayload(jSonRequest);
    createMockCmdLireun(RetourFactoryForTU.createOkRetour(), commande);
    PEP0147_GererMailSecondaire pep147 = new PEP0147_GererMailSecondaire();
    PowerMock.replayAll();
    pep147.initializeContext();
    pep147.run(request);
    pep147.continueProcess(null, null);
    PowerMock.verify();

    PEP0147_Retour expectedRetour = new PEP0147_Retour(RetourConverter.convertToJsonRetour(RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INVALIDE, "La commande null est au statut ACTIF, elle ne peut pas être traitée par ce processus.", PEP0147_BL001_VERIFIER_DONNEES))); //$NON-NLS-1$
    String jsonExpectedRetour = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(expectedRetour);

    IRavelResponse response = request.getResponse();
    assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    assertEquals(jsonExpectedRetour, response.getGenericResponse().getResult());
  }

  /**
   * PEP0147_GererMailSecondaire_KO_002 BL100_RecupererPfi KO After continueProcess : {0}
   *
   * @throws Throwable
   */
  @Test
  public void PEP0147_GererMailSecondaire_KO_002() throws Throwable
  {
    Tracabilite tracabilite = new Tracabilite();
    Commande commande = new Commande();
    PFI pfi = new PFI();
    List<PA> listpa = new ArrayList<>();
    PaTypeCompteAcces paType = new PaTypeCompteAcces("charles.rock"); //$NON-NLS-1$
    PA pa = new PA(null, TypePA.COMPTE_ACCES_SECONDAIRE.name(), Statut.ACTIF, null, null);
    pa.setPaTypeCompteAcces(paType);
    pa.setIdentifiantFonctionnelPA("identifiantFonctionnelPA"); //$NON-NLS-1$
    listpa.add(pa);
    pfi.setPa(listpa);
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    PEP0147_GererMailSecondaire pep0147 = new PEP0147_GererMailSecondaire();
    pep0147.initializeContext();

    StLienAllocationCommercial stliencommercial = new StLienAllocationCommercial("PA", com.bytel.spirit.common.shared.saab.rst.Statut.ACTIF.name(), "ocClientOperateur", "ocNoCompte", TypeObjetCommercial.PA.name(), "BSS_GP", "ocNoCompte", "idRessource", "ADRESSE_MAIL"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$
    stliencommercial.setOcIdentifiantFonctionnelPA("identifiantFonctionnelPA"); //$NON-NLS-1$

    List<ServiceTechnique> listServTech = new ArrayList<>();
    listServTech.add(stliencommercial);

    CommandeId command = new CommandeId("idCommande"); //$NON-NLS-1$
    commande.setStatut("ACQUITTE"); //$NON-NLS-1$
    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(command, CommandeId.class);
    request.setPayload(jSonRequest);
    ServiceMailGererMailSecondaireRequest gererMailSecondaireRequest = __podam.manufacturePojo(ServiceMailGererMailSecondaireRequest.class);
    MailSecondaire mailSecondaire = new MailSecondaire();
    mailSecondaire.setStatut("ACTIF"); //$NON-NLS-1$
    IdentifiantAcces identifiantAcces = new IdentifiantAcces();
    identifiantAcces.setLoginMail("charles.rock"); //$NON-NLS-1$
    gererMailSecondaireRequest.setMailSecondaire(mailSecondaire);
    gererMailSecondaireRequest.setIdentifiantAcces(identifiantAcces);
    commande.setDonneesBrut(GsonTools.getIso8601Ms().toJson(gererMailSecondaireRequest));
    createMockCmdLireun(RetourFactoryForTU.createOkRetour(), commande);
    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.ACCES_DONNEES_INDISPONIBLE, "", "PEP0147_BL100_RecupererPFI");//$NON-NLS-1$ //$NON-NLS-2$
    createMockRPGLire(retour, pfi);

    Retour retourBL005 = RetourFactoryForTU.createOkRetour();
    ConnectorResponse<Retour, Nothing> resultRex = new ConnectorResponse<Retour, Nothing>(retourBL005, null);
    // Used in BL005
    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxy);
    EasyMock.expect(_rexProxy.erreurSpiritCreer(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(CreateErreurSpiritRequest.class))).andReturn(resultRex);

    PEP0147_GererMailSecondaire pep147 = new PEP0147_GererMailSecondaire();
    PowerMock.replayAll();
    pep147.initializeContext();
    pep147.run(request);
    pep147.continueProcess(request, tracabilite);
    PowerMock.verify();
    IRavelResponse response = request.getResponse();

    assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    assertEquals("{\"retour\":{\"resultat\":\"NOK\",\"categorie\":\"CAT-4\",\"diagnostic\":\"ACCES_DONNEES_INDISPONIBLE\",\"libelle\":\"\",\"activite\":\"PEP0147_BL100_RecupererPFI\"}}", response.getGenericResponse().getResult()); //$NON-NLS-1$
    // after BL005
    assertEquals(pep147.getRetour(), retourBL005);
  }

  /**
   * PEP0147_GererMailSecondaire_KO_002 BL200_CreerMailSecondaire KO
   *
   * @throws Throwable
   */
  @Test
  @Ignore
  public void PEP0147_GererMailSecondaire_KO_003() throws Throwable
  {
    Tracabilite tracabilite = new Tracabilite();
    Commande commande = new Commande();
    PFI pfi = new PFI();
    List<PA> listpa = new ArrayList<>();
    PaTypeCompteAcces paType = new PaTypeCompteAcces("charles.rock"); //$NON-NLS-1$
    PA pa = new PA(null, TypePA.COMPTE_ACCES_SECONDAIRE.name(), Statut.ACTIF, null, null);
    pa.setPaTypeCompteAcces(paType);
    pa.setIdentifiantFonctionnelPA("identifiantFonctionnelPA"); //$NON-NLS-1$
    listpa.add(pa);
    pfi.setPa(listpa);
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    PEP0147_GererMailSecondaire pep0147 = new PEP0147_GererMailSecondaire();
    pep0147.initializeContext();
    StLienAllocationCommercial stliencommercial = new StLienAllocationCommercial("PA", com.bytel.spirit.common.shared.saab.rst.Statut.ACTIF.name(), "ocClientOperateur", "ocNoCompte", TypeObjetCommercial.PA.name(), "BSS_GP", "ocNoCompte", "idRessource", "ADRESSE_MAIL"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$
    stliencommercial.setOcIdentifiantFonctionnelPA("identifiantFonctionnelPA"); //$NON-NLS-1$

    List<ServiceTechnique> listServTech = new ArrayList<>();
    listServTech.add(stliencommercial);

    CommandeId command = new CommandeId("idCommande"); //$NON-NLS-1$
    commande.setStatut("ACQUITTE"); //$NON-NLS-1$
    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(command, CommandeId.class);
    request.setPayload(jSonRequest);
    ServiceMailGererMailSecondaireRequest gererMailSecondaireRequest = __podam.manufacturePojo(ServiceMailGererMailSecondaireRequest.class);
    MailSecondaire mailSecondaire = new MailSecondaire();
    mailSecondaire.setStatut("ACTIF"); //$NON-NLS-1$
    IdentifiantAcces identifiantAcces = new IdentifiantAcces();
    identifiantAcces.setLoginMail("loginMail"); //$NON-NLS-1$
    gererMailSecondaireRequest.setMailSecondaire(mailSecondaire);
    gererMailSecondaireRequest.setIdentifiantAcces(identifiantAcces);
    commande.setDonneesBrut(GsonTools.getIso8601Ms().toJson(gererMailSecondaireRequest));
    createMockCmdLireun(RetourFactoryForTU.createOkRetour(), commande);
    createMockRPGLire(RetourFactoryForTU.createOkRetour(), pfi);

    PEP0147_GererMailSecondaire pep147 = new PEP0147_GererMailSecondaire();
    PowerMock.replayAll();
    pep147.initializeContext();
    pep147.run(request);
    pep147.continueProcess(null, null);
    PowerMock.verify();

    PEP0147_Retour expectedRetour = new PEP0147_Retour(RetourConverter.convertToJsonRetour(RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "PA COMPTE_ACCES non trouvé pour ce pfi", PEP0147_BL200_CREERMAILSECONDAIRE))); //$NON-NLS-1$
    String jsonExpectedRetour = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(expectedRetour);

    IRavelResponse response = request.getResponse();
    assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    assertEquals(jsonExpectedRetour, response.getGenericResponse().getResult());
  }

  /**
   * cas Nominal Processus PEP0147 statut actif
   *
   * @throws Throwable
   *           expected
   */
  @Test
  public void PEP0147_GererMailSecondaire_OK_001() throws Throwable
  {

    Tracabilite tracabilite = __podam.manufacturePojoWithFullData(Tracabilite.class);
    Commande commande = __podam.manufacturePojoWithFullData(Commande.class);
    PFI pfi = new PFI();
    List<PA> listpa = new ArrayList<>();
    PaTypeCompteAcces paType = new PaTypeCompteAcces("charles.rock"); //$NON-NLS-1$
    PA pa = new PA(null, TypePA.COMPTE_ACCES_SECONDAIRE.name(), Statut.ACTIF, null, null);
    pa.setPaTypeCompteAcces(paType);
    listpa.add(pa);
    pfi.setPa(listpa);

    paType = new PaTypeCompteAcces("charles.rock"); //$NON-NLS-1$
    pa = new PA(null, TypePA.COMPTE_ACCES.name(), Statut.ACTIF, null, null);
    pa.setPaTypeCompteAcces(paType);
    listpa.add(pa);
    pfi.setPa(listpa);
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    request.setHttpMethod("POST"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    CommandeId command = new CommandeId("idCommande"); //$NON-NLS-1$
    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(command, CommandeId.class);
    request.setPayload(jSonRequest);
    commande.setStatut("ACQUITTE"); //$NON-NLS-1$

    ServiceMailGererMailSecondaireRequest gererMailSecondaireRequest = __podam.manufacturePojo(ServiceMailGererMailSecondaireRequest.class);
    MailSecondaire mailSecondaire = new MailSecondaire();
    mailSecondaire.setStatut("ACTIF"); //$NON-NLS-1$
    IdentifiantAcces identifiantAcces = new IdentifiantAcces();
    identifiantAcces.setLoginMail("loginMail"); //$NON-NLS-1$
    gererMailSecondaireRequest.setMailSecondaire(mailSecondaire);
    gererMailSecondaireRequest.setIdentifiantAcces(identifiantAcces);
    commande.setDonneesBrut(GsonTools.getIso8601Ms().toJson(gererMailSecondaireRequest));

    String jSon = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(pfi, PFI.class);

    createMockCmdLireun(RetourFactoryForTU.createOkRetour(), commande);
    createMockRPGLire(RetourFactoryForTU.createOkRetour(), pfi);
    createMockCmd(RetourFactoryForTU.createOkRetour(), null);
    createMockRPG(RetourFactoryForTU.createOkRetour(), pfi);
    createMockCommandeModifierStatut(RetourFactoryForTU.createOkRetour(), null);
    PEP0147_GererMailSecondaire pep147 = new PEP0147_GererMailSecondaire();
    PowerMock.replayAll();
    pep147.initializeContext();
    pep147.run(request);
    pep147.continueProcess(null, null);
    PowerMock.verify();
    IRavelResponse response = request.getResponse();

    assertEquals(ErrorCode.OK_00200, response.getErrorCode());
    assertEquals("{\"reponseFonctionnelle\":{},\"retour\":{\"resultat\":\"OK\"}}", response.getGenericResponse().getResult()); //$NON-NLS-1$
  }

  /**
   * cas Nominal Processus PEP0147 statut actif
   *
   * @throws Throwable
   *           expected
   */
  @Test
  public void PEP0147_GererMailSecondaire_OK_002() throws Throwable
  {

    Tracabilite tracabilite = __podam.manufacturePojoWithFullData(Tracabilite.class);
    Commande commande = __podam.manufacturePojoWithFullData(Commande.class);
    PFI pfi = new PFI();
    List<PA> listpa = new ArrayList<>();
    PaTypeCompteAccesSecondaire paType = new PaTypeCompteAccesSecondaire("charles.rock"); //$NON-NLS-1$
    PA pa = new PA(null, TypePA.COMPTE_ACCES_SECONDAIRE.name(), Statut.ACTIF, null, null);
    pa.setPaTypeCompteAccesSecondaire(paType);
    pa.setIdentifiantFonctionnelPA("identifiantFonctionnelPA"); //$NON-NLS-1$
    listpa.add(pa);
    pfi.setPa(listpa);

    paType = new PaTypeCompteAccesSecondaire("charles.rock"); //$NON-NLS-1$
    pa = new PA(null, TypePA.COMPTE_ACCES.name(), Statut.ACTIF, null, null);
    pa.setPaTypeCompteAccesSecondaire(paType);
    listpa.add(pa);
    pfi.setPa(listpa);
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    request.setHttpMethod("POST"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    CommandeId command = new CommandeId("idCommande"); //$NON-NLS-1$
    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(command, CommandeId.class);
    request.setPayload(jSonRequest);
    commande.setStatut("ACQUITTE"); //$NON-NLS-1$

    ServiceMailGererMailSecondaireRequest gererMailSecondaireRequest = __podam.manufacturePojo(ServiceMailGererMailSecondaireRequest.class);
    MailSecondaire mailSecondaire = new MailSecondaire();
    mailSecondaire.setStatut("RESILIE"); //$NON-NLS-1$
    mailSecondaire.setMail("charles.rock");
    IdentifiantAcces identifiantAcces = new IdentifiantAcces();
    identifiantAcces.setLoginMail("charles.rock"); //$NON-NLS-1$
    gererMailSecondaireRequest.setMailSecondaire(mailSecondaire);
    gererMailSecondaireRequest.setIdentifiantAcces(identifiantAcces);
    commande.setDonneesBrut(GsonTools.getIso8601Ms().toJson(gererMailSecondaireRequest));

    createMockCmdLireun(RetourFactoryForTU.createOkRetour(), commande);
    createMockRPGLire(RetourFactoryForTU.createOkRetour(), pfi);
    createMockRefTech(1);
    createMockCmdModif(RetourFactoryForTU.createOkRetour(), null);

    StLienAllocationCommercial stliencommercial = new StLienAllocationCommercial("PA", com.bytel.spirit.common.shared.saab.rst.Statut.ACTIF.name(), "ocClientOperateur", "ocNoCompte", TypeObjetCommercial.PA.name(), "BSS_GP", "ocNoCompte", "charles.rock", "ADRESSE_MAIL"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$
    stliencommercial.setOcIdentifiantFonctionnelPA("identifiantFonctionnelPA"); //$NON-NLS-1$

    List<ServiceTechnique> listServTech = new ArrayList<>();
    listServTech.add(stliencommercial);

    ConnectorResponse<Retour, List<ServiceTechnique>> connectRep = new ConnectorResponse<Retour, List<ServiceTechnique>>(RetourFactoryForTU.createOkRetour(), listServTech);
    //    createMockRST(connectRep, pfi);
    createMockRPG(RetourFactoryForTU.createOkRetour(), null);
    createMockCommandeModifierStatut(RetourFactoryForTU.createOkRetour(), null);

    PEP0147_GererMailSecondaire pep147 = new PEP0147_GererMailSecondaire();
    PowerMock.replayAll();
    pep147.initializeContext();
    pep147.run(request);
    pep147.continueProcess(null, null);
    PowerMock.verify();
    IRavelResponse response = request.getResponse();

    assertEquals(ErrorCode.OK_00200, response.getErrorCode());
    assertEquals("{\"reponseFonctionnelle\":{},\"retour\":{\"resultat\":\"OK\"}}", response.getGenericResponse().getResult()); //$NON-NLS-1$
  }

  /**
   * Creation du Mock Connecteur CMD
   *
   * @param retour
   *          retour
   * @param nothing
   *          nothing
   * @throws RavelException
   *           exception
   *
   */
  private void createMockCmd(Retour retour, Nothing nothing) throws RavelException
  {

    ConnectorResponse<Retour, Nothing> resultCmd = new ConnectorResponse<Retour, Nothing>(retour, nothing);
    EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdProxy);
    EasyMock.expect(_cmdProxy.modificationCommercialeCreerListe(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(CreateModificationCommercialeRequest.class))).andReturn(resultCmd);
  }

  /**
   * Creation du Mock Connecteur CMD
   *
   * @param retour
   *          retour
   * @param nothing
   *          nothing
   * @throws RavelException
   *           exception
   *
   */
  private void createMockCmdLireun(Retour retour_p, Commande commande_p) throws RavelException
  {

    ConnectorResponse<Retour, Commande> resultCmd = new ConnectorResponse<Retour, Commande>(retour_p, commande_p);
    EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdProxy);
    EasyMock.expect(_cmdProxy.commandeLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject())).andReturn(resultCmd);

  }

  /**
   * Creation du Mock Connecteur CMD
   *
   * @param retour
   *          retour
   * @param nothing
   *          nothing
   * @throws RavelException
   *           exception
   *
   */
  private void createMockCmdModif(Retour retour, Nothing nothing) throws RavelException
  {

    ConnectorResponse<Retour, Nothing> resultCmd = new ConnectorResponse<Retour, Nothing>(retour, nothing);
    EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdProxy);
    EasyMock.expect(_cmdProxy.modificationCommercialeCreerListe(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(CreateModificationCommercialeRequest.class))).andReturn(resultCmd);
  }

  /**
   * Creation du Mock Connecteur CMD createMockCommandeModifierStatut
   *
   * @param retour
   *          retour
   * @param nothing
   *          nothing
   * @throws RavelException
   *           exception
   *
   */
  private void createMockCommandeModifierStatut(Retour retour, Nothing nothing) throws RavelException
  {

    ConnectorResponse<Retour, Nothing> resultCmd = new ConnectorResponse<Retour, Nothing>(retour, nothing);
    EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdProxy);
    EasyMock.expect(_cmdProxy.commandeModifierStatut(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(), EasyMock.anyObject(), EasyMock.anyObject(), EasyMock.anyObject())).andReturn(resultCmd);
  }

  /**
   * @throws RavelException
   */
  ;

  private void createMockRefTech(int value) throws RavelException
  {
    ReftechRetour refRetour = new ReftechRetour(value, null);
    ConnectorResponse<ReftechRetour, Nothing> expectedResponse = new ConnectorResponse<ReftechRetour, Nothing>(refRetour, null);
    EasyMock.expect(ReftechProxy.getInstance()).andReturn(_reftchProxy);
    EasyMock.expect(_reftchProxy.modifierStatutAdressMail(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(), EasyMock.anyObject(), EasyMock.anyObject())).andReturn(expectedResponse);
  }

  /**
   * @param retour
   * @param pfi
   * @param operateur
   * @param numcompte
   * @throws RavelException
   */
  private void createMockRPG(Retour retour, PFI pfi_p) throws RavelException
  {

    ConnectorResponse<Retour, Nothing> expectedResponse = new ConnectorResponse<Retour, Nothing>(retour, null);
    EasyMock.expect(RPGProxy.getInstance()).andReturn(_rpgProxy);

    CreatePfiRequest createPFI = new CreatePfiRequest(pfi_p);
    EasyMock.expect(_rpgProxy.pfiEcrire(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(CreatePfiRequest.class))).andReturn(expectedResponse);

  }

  /**
   * @param retour
   * @param pfi
   * @param operateur
   * @param numcompte
   * @throws RavelException
   */
  private void createMockRPGLire(Retour retour, PFI pfi_p) throws RavelException
  {

    ConnectorResponse<Retour, PFI> expectedResponse = new ConnectorResponse<Retour, PFI>(retour, pfi_p);
    EasyMock.expect(RPGProxy.getInstance()).andReturn(_rpgProxy);
    EasyMock.expect(_rpgProxy.pfiLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(), EasyMock.anyObject())).andReturn(expectedResponse);

  }

  //  /**
  //   * @param retour
  //   * @param pfi_p
  //   * @throws RavelException
  //   */
  //  private void createMockRST(ConnectorResponse<Retour, List<ServiceTechnique>> connectRep, PFI pfi_p) throws RavelException
  //  {
  //
  //    EasyMock.expect(RSTProxy.getInstance()).andReturn(_rstProxy);
  //    EasyMock.expect(_rstProxy.serviceTechniqueLireTousParPfi(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(), EasyMock.anyObject(), EasyMock.anyObject(), EasyMock.anyObject())).andReturn(connectRep);
  //  }

}
