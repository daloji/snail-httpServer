/*******************************************************************************
 * $Id: PEP0142_CreerCommandeTransfertBoiteMailSecondaireTest.java 17601 2019-02-22 11:50:36Z fmonteir $
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.prof.processes.PE0142;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import com.bytel.spirit.common.shared.types.json.request.ServiceMailRequest;
import com.bytel.spirit.common.shared.types.json.request.ServiceMailRequest.IdentifiantAcces;
import com.bytel.spirit.common.shared.types.json.request.ServiceMailRequest.PortefeuilleServices;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.utils.ACManagerUtil;
import com.bytel.ravel.common.utils.DateTimeTools.DateTimeFormatPattern;
import com.bytel.ravel.common.utils.RetourFactoryForTU;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.ProcessManager;
import com.bytel.ravel.services.utils.Test_Consts;
import com.bytel.spirit.common.connectors.air.AIRProxy;
import com.bytel.spirit.common.connectors.cmd.CMDProxy;
import com.bytel.spirit.common.connectors.rpg.RPGProxy;
import com.bytel.spirit.common.connectors.rst.RSTProxy;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.TypePFS;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.mail.DonneesIdentificationSTPfsMail;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.mail.DonneesProvisionneesSTPfsMail;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.mail.StPfsMail;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.ressources.RetourConverter;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.TypeObjetCommercial;
import com.bytel.spirit.common.shared.saab.air.CleRecherche;
import com.bytel.spirit.common.shared.saab.air.IndexRecherchePfi;
import com.bytel.spirit.common.shared.saab.air.request.CreateIndexRecherchePfiRequest;
import com.bytel.spirit.common.shared.saab.cmd.Commande;
import com.bytel.spirit.common.shared.saab.cmd.Statut;
import com.bytel.spirit.common.shared.saab.rpg.PA;
import com.bytel.spirit.common.shared.saab.rpg.PFI;
import com.bytel.spirit.common.shared.saab.rpg.PaTypeCompteAcces;
import com.bytel.spirit.common.shared.saab.rpg.PaTypeCompteAccesSecondaire;
import com.bytel.spirit.common.shared.saab.rpg.TypePA;
import com.bytel.spirit.common.shared.saab.rpg.request.CreatePfiRequest;
import com.bytel.spirit.common.shared.saab.rst.ServiceTechnique;
import com.bytel.spirit.common.shared.saab.rst.StLienAllocationCommercial;
import com.bytel.spirit.common.shared.saab.rst.TypeST;
import com.bytel.spirit.common.shared.saab.rst.request.UpdateStLienAllocationCommercialRequest;
import com.bytel.spirit.common.shared.saab.rst.request.UpdateStPfsRequest;
import com.bytel.spirit.prof.processes.PE0142.structs.PEP0142_Retour;
import com.bytel.spirit.prof.shared.types.json.CommandeId;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author jiantila
 * @version ($Revision: 17601 $ $Date: 2019-02-22 12:50:36 +0100 (ven. 22 févr. 2019) $)
 *
 */

@RunWith(PowerMockRunner.class)
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
@PrepareForTest({ CMDProxy.class, RPGProxy.class, RSTProxy.class, AIRProxy.class })
public class PEP0142_CreerCommandeTransfertBoiteMailSecondaireTest
{

  /**
   *
   */
  private static final String BL100_ACTIVITY_NAME = "PEP0142_BL100_CopierPaCompteAccesSecondaire";

  /**
   * LIBELLE_1
   */
  private static final String LIBELLE_1 = "La commande null est au statut EN_COURS, elle ne peut pas être traitée par ce processus."; //$NON-NLS-1$

  /**
   * LIBELLE_2
   */
  private static final String LIBELLE_2 = "Pas de PA CA avec loginmail sur le Pfi NO_COMPTE_SOURCE, La commande ne peut pas être traitée par ce processus"; //$NON-NLS-1$
  /**
   * LIBELLE_3
   */

  private static final String LIBELLE_3 = "Pas de PA Compte secondaire a déplacer."; //$NON-NLS-1$

  /**
   * LIBELLE_4
   */
  private static final String LIBELLE_4 = "Pas de PA CA avec loginmail sur le Pfi NO_COMPTE_CIBLE, La commande ne peut pas être traitée par ce processus"; //$NON-NLS-1$
  /**
   *
   */
  private static final String CLIENT_OPERATEUR = "CLIENT_OPERATEUR"; //$NON-NLS-1$

  /**
   * MAIL constant
   */
  private static final String TYPE_RESSOURCE_ADRESSE_MAIL = "ADRESSE_MAIL"; //$NON-NLS-1$

  /**
   * NO_COMPTE
   */
  private static final String NO_COMPTE = "NO_COMPTE"; //$NON-NLS-1$

  /**
   *
   */
  private static final String NO_COMPTE_CIBLE = "NO_COMPTE_CIBLE"; //$NON-NLS-1$

  /**
  *
  */
  private static final String NO_COMPTE_SOURCE = "NO_COMPTE_SOURCE"; //$NON-NLS-1$
  /**
   * Tracabilite
   */
  private static Tracabilite _tracabilite;

  /**
   * Factory de génération des beans
   */
  private static PodamFactory __podam = new PodamFactoryImpl();

  /**
   *
   */
  private static String BL001_ACTIVITY_NAME = "PEP0142_BL001_VerifierDonnees"; //$NON-NLS-1$
  /**
   * SPRING context
   */
  private static ClassPathXmlApplicationContext __context;

  @BeforeClass
  public static void init() throws RavelException
  {
    // désactivation du cache podam
    __podam.getStrategy().setMemoization(false);
    __podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());

    ACManagerUtil.resetACManager();
    __context = new ClassPathXmlApplicationContext("classpath:BeansProcessTestMocks.xml"); //$NON-NLS-1$

  }

  /**
   * CMD PRoxy
   */
  @MockStrict
  private CMDProxy _cmdProxy;

  /**
   * RPG PRoxy
   */
  @MockStrict
  private RPGProxy _rpgProxy;

  /**
   * RST PRoxy
   */
  @MockStrict
  private RSTProxy _rstProxy;

  /**
   * Instance of {@ * AIR PRoxy
   */
  @MockStrict
  private AIRProxy _airProxy;

  /**
   * link PI0035_RecupererPfiComplet}
   */
  private PEP0142_CreerCommandeTransfertBoiteMailSecondaire _processInstance;

  /**
   * case PEP0142_BL001_VerifierDonnees KO because statut Commande object is Not ACQUITE
   *
   * @throws RavelException
   */
  @Test
  public void PEP0142_CreerCommandeTransfertBoiteMail_KO_001() throws RavelException
  {
    String idCommand = "ID_COMMAND"; //$NON-NLS-1$
    Request request = createRequest(idCommand);
    Commande commande = new Commande();
    commande.setStatut(Statut.EN_COURS.name());
    ConnectorResponse<Retour, Commande> connectorRep_p = new ConnectorResponse<Retour, Commande>(RetourFactoryForTU.createOkRetour(), commande);
    createMockCMDcommandeLireUn(idCommand, connectorRep_p);

    // Run scenario
    PowerMock.replayAll();
    _processInstance.startProcess(request, _tracabilite);
    // Continue Process
    _processInstance.continueProcess(request, _tracabilite);
    PowerMock.verifyAll();
    Retour retourKo = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.DONNEE_INVALIDE, LIBELLE_1, BL001_ACTIVITY_NAME);
    PEP0142_Retour expectedResult = new PEP0142_Retour(RetourConverter.convertToJsonRetour(retourKo));
    String jsonExpectedRetour = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(expectedResult);

    assertEquals(ErrorCode.KO_00400, request.getResponse().getErrorCode());
    assertEquals(jsonExpectedRetour, request.getResponse().getGenericResponse().getResult());
  }

  /**
   * case PEP0142_BL001_VerifierDonnees KO because PEP0142_BL202_TransfererStPfsMail second RST Proxy error *
   * "{\"retour\":{\"resultat\":\"KO\",\"categorie\":\"CAT-4\",\"diagnostic\":\"DONNEE_INCONNUE\",\"libelle\":\"Pas de
   * PA CA avec loginmail sur le Pfi NO_COMPTE_CIBLE, La commande ne peut pas être traitée par ce processus\"}}"<br>
   *
   * @throws RavelException
   */
  @Test
  public void PEP0142_CreerCommandeTransfertBoiteMail_KO_0010() throws RavelException
  {
    String idCommand = "ID_COMMAND"; //$NON-NLS-1$
    String identFonct = "identifiantFonct"; //$NON-NLS-1$
    Request request = createRequest(idCommand);
    Commande commande = new Commande();
    commande.setStatut(Statut.ACQUITTE.name());
    ServiceMailRequest serviceMailreq = createServiceMailRequest();
    commande.setDonneesBrut(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(serviceMailreq, ServiceMailRequest.class));
    commande.setNoCompte("commandeCompte"); //$NON-NLS-1$
    commande.setClientOperateur(CLIENT_OPERATEUR);

    PFI pfisource = new PFI();
    List<PA> listpa = new ArrayList<>();
    PaTypeCompteAcces paType = new PaTypeCompteAcces("charles.rock"); //$NON-NLS-1$
    paType.setEmailLogin("loginmail"); //$NON-NLS-1$
    PA pat2 = new PA(identFonct, TypePA.COMPTE_ACCES_SECONDAIRE.name(), com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, null, null); // The COMPTE_ACCESS_SECONDAIRE
    PaTypeCompteAccesSecondaire paTypeCompteAccesSecondairet = new PaTypeCompteAccesSecondaire("paSecondaire"); //$NON-NLS-1$
    pat2.setPaTypeCompteAccesSecondaire(paTypeCompteAccesSecondairet);
    pat2.setIdentifiantFonctionnelPALie(identFonct);
    listpa.add(pat2);

    PA pa = new PA(null, "COMPTE_ACCES", com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, null, null); //$NON-NLS-1$
    pa.setPaTypeCompteAcces(paType);
    pa.setIdentifiantFonctionnelPALie(identFonct);
    pa.setIdentifiantFonctionnelPA(identFonct);
    listpa.add(pa);
    pfisource.setPa(listpa);
    pfisource.setClientOperateur(CLIENT_OPERATEUR);
    pfisource.setNoCompte(NO_COMPTE_SOURCE);
    PFI pficible = new PFI();
    listpa = new ArrayList<>();
    paType = new PaTypeCompteAcces("charles.rock"); //$NON-NLS-1$
    paType.setEmailLogin("loginmail"); //$NON-NLS-1$
    pat2 = new PA(identFonct, TypePA.COMPTE_ACCES_SECONDAIRE.name(), com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, null, null); // The COMPTE_ACCESS_SECONDAIRE
    paTypeCompteAccesSecondairet = new PaTypeCompteAccesSecondaire("paSecondaire"); //$NON-NLS-1$
    pat2.setPaTypeCompteAccesSecondaire(paTypeCompteAccesSecondairet);
    pat2.setIdentifiantFonctionnelPALie("identFonctd"); //$NON-NLS-1$
    listpa.add(pat2);

    pa = new PA(null, "COMPTE_ACCES", com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, null, null); //$NON-NLS-1$
    pa.setPaTypeCompteAcces(paType);
    pa.setIdentifiantFonctionnelPALie("identFonctd"); //$NON-NLS-1$
    pa.setIdentifiantFonctionnelPA("identFonctd"); //$NON-NLS-1$
    listpa.add(pa);

    pficible.setPa(listpa);

    ConnectorResponse<Retour, Commande> connectorRep_p = new ConnectorResponse<Retour, Commande>(RetourFactoryForTU.createOkRetour(), commande);
    createMockCMDcommandeLireUn(idCommand, connectorRep_p);

    ConnectorResponse<Retour, PFI> connectorRepRpg = new ConnectorResponse<Retour, PFI>(RetourFactoryForTU.createOkRetour(), pfisource);
    createMockRPGpfiLireUn(CLIENT_OPERATEUR, NO_COMPTE_SOURCE, connectorRepRpg);
    connectorRepRpg = new ConnectorResponse<Retour, PFI>(RetourFactoryForTU.createOkRetour(), pfisource);
    createMockRPGpfiLireUn(CLIENT_OPERATEUR, NO_COMPTE_CIBLE, connectorRepRpg);

    List<ServiceTechnique> listServiceTechnique1 = new ArrayList<>();

    StLienAllocationCommercial stLac = new StLienAllocationCommercial("idST", com.bytel.spirit.common.shared.saab.rst.Statut.ACTIF.name(), CLIENT_OPERATEUR, NO_COMPTE_SOURCE, TypeObjetCommercial.PA.name(), "BSS_GP", "ocNoCompte", "idRessource", TYPE_RESSOURCE_ADRESSE_MAIL); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    stLac.setOcIdentifiantFonctionnelPA(identFonct);

    listServiceTechnique1.add(stLac);

    ConnectorResponse<Retour, List<ServiceTechnique>> rstRetour = new ConnectorResponse<Retour, List<ServiceTechnique>>(RetourFactoryForTU.createOkRetour(), listServiceTechnique1);
    creatMockRSTstserviceTechniqueLireTousParPfi(CLIENT_OPERATEUR, NO_COMPTE_SOURCE, "LAC", StringConstants.EMPTY_STRING, rstRetour); //$NON-NLS-1$
    List<String> list = new ArrayList<>();
    list.add("idSt"); //$NON-NLS-1$
    UpdateStLienAllocationCommercialRequest updateLien = new UpdateStLienAllocationCommercialRequest(CLIENT_OPERATEUR, NO_COMPTE_SOURCE, NO_COMPTE_CIBLE, list);
    ConnectorResponse<Retour, Nothing> connectRepRst = new ConnectorResponse<Retour, Nothing>(RetourFactoryForTU.createOkRetour(), null);
    CreateMockRststLienAllocationCommercial(updateLien, connectRepRst);

    List<ServiceTechnique> listServiceTechnique2 = new ArrayList<>();

    StPfsMail stPfsMail = __podam.manufacturePojoWithFullData(StPfsMail.class);
    stPfsMail.setDonneesIdentificationStPfsMail(new DonneesIdentificationSTPfsMail("SECONDAIRE", "idCompteMail")); //$NON-NLS-1$ //$NON-NLS-2$
    stPfsMail.setDonneesProvisionneesStPfsMail(new DonneesProvisionneesSTPfsMail("paSecondaire", 23, 128, "TOP")); //$NON-NLS-1$ //$NON-NLS-2$
    stPfsMail.setTypeServiceTechnique(TypeST.PFS.name());
    stPfsMail.setTypePfs(TypePFS.MAIL.name());

    listServiceTechnique2.add(stPfsMail);

    rstRetour = new ConnectorResponse<Retour, List<ServiceTechnique>>(RetourFactoryForTU.createOkRetour(), listServiceTechnique2);
    creatMockRSTstserviceTechniqueLireTousParPfi(CLIENT_OPERATEUR, NO_COMPTE_SOURCE, TypeST.PFS.name(), TypePFS.MAIL.name(), rstRetour);

    Retour retourKo = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, StringConstants.EMPTY_STRING, null);
    connectRepRst = new ConnectorResponse<Retour, Nothing>(retourKo, null);

    UpdateStPfsRequest updateStpfsRequest = new UpdateStPfsRequest(CLIENT_OPERATEUR, NO_COMPTE_SOURCE, NO_COMPTE_SOURCE, list);
    CreateMockRSTstLienAllocCommercialGererModifPfiAssocie(updateStpfsRequest, connectRepRst);

    // Run scenario
    PowerMock.replayAll();
    _processInstance.startProcess(request, _tracabilite);
    // Continue Process
    _processInstance.continueProcess(request, _tracabilite);
    PowerMock.verifyAll();
    retourKo = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, StringConstants.EMPTY_STRING, null);
    PEP0142_Retour expectedResult = new PEP0142_Retour(RetourConverter.convertToJsonRetour(retourKo));
    String jsonExpectedRetour = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(expectedResult);

    assertEquals(ErrorCode.KO_00400, request.getResponse().getErrorCode());
    assertEquals(jsonExpectedRetour, request.getResponse().getGenericResponse().getResult());

  }

  /**
   * case PEP0142_BL001_VerifierDonnees KO because PEP0142_BL300_SupprimerPaCompteAccesSecondaire call RPG PfiEcrire
   * Proxy error *
   * "{\"retour\":{\"resultat\":\"KO\",\"categorie\":\"CAT-4\",\"diagnostic\":\"DONNEE_INCONNUE\",\"libelle\":\"Pas de
   * PA CA avec loginmail sur le Pfi NO_COMPTE_CIBLE, La commande ne peut pas être traitée par ce processus\"}}"<br>
   *
   * @throws RavelException
   */
  @Test
  public void PEP0142_CreerCommandeTransfertBoiteMail_KO_0011() throws RavelException
  {
    String idCommand = "ID_COMMAND"; //$NON-NLS-1$
    String identFonct = "identifiantFonct"; //$NON-NLS-1$
    Request request = createRequest(idCommand);
    Commande commande = new Commande();
    commande.setStatut(Statut.ACQUITTE.name());
    ServiceMailRequest serviceMailreq = createServiceMailRequest();
    commande.setDonneesBrut(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(serviceMailreq, ServiceMailRequest.class));
    commande.setNoCompte("commandeCompte"); //$NON-NLS-1$
    commande.setClientOperateur(CLIENT_OPERATEUR);

    PFI pfisource = new PFI();
    List<PA> listpa = new ArrayList<>();
    PaTypeCompteAcces paType = new PaTypeCompteAcces("charles.rock"); //$NON-NLS-1$
    paType.setEmailLogin("loginmail"); //$NON-NLS-1$
    PA pat2 = new PA(identFonct, TypePA.COMPTE_ACCES_SECONDAIRE.name(), com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, null, null); // The COMPTE_ACCESS_SECONDAIRE
    PaTypeCompteAccesSecondaire paTypeCompteAccesSecondairet = new PaTypeCompteAccesSecondaire("paSecondaire"); //$NON-NLS-1$
    pat2.setPaTypeCompteAccesSecondaire(paTypeCompteAccesSecondairet);
    pat2.setIdentifiantFonctionnelPALie(identFonct);
    listpa.add(pat2);

    PA pa = new PA(null, "COMPTE_ACCES", com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, null, null); //$NON-NLS-1$
    pa.setPaTypeCompteAcces(paType);
    pa.setIdentifiantFonctionnelPALie(identFonct);
    pa.setIdentifiantFonctionnelPA(identFonct);
    listpa.add(pa);
    pfisource.setPa(listpa);
    pfisource.setClientOperateur(CLIENT_OPERATEUR);
    pfisource.setNoCompte(NO_COMPTE_SOURCE);
    PFI pficible = new PFI();
    listpa = new ArrayList<>();
    paType = new PaTypeCompteAcces("charles.rock"); //$NON-NLS-1$
    paType.setEmailLogin("loginmail"); //$NON-NLS-1$
    pat2 = new PA(identFonct, TypePA.COMPTE_ACCES_SECONDAIRE.name(), com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, null, null); // The COMPTE_ACCESS_SECONDAIRE
    paTypeCompteAccesSecondairet = new PaTypeCompteAccesSecondaire("paSecondaire"); //$NON-NLS-1$
    pat2.setPaTypeCompteAccesSecondaire(paTypeCompteAccesSecondairet);
    pat2.setIdentifiantFonctionnelPALie("identFonctd"); //$NON-NLS-1$
    listpa.add(pat2);

    pa = new PA(null, "COMPTE_ACCES", com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, null, null); //$NON-NLS-1$
    pa.setPaTypeCompteAcces(paType);
    pa.setIdentifiantFonctionnelPALie("identFonctd"); //$NON-NLS-1$
    pa.setIdentifiantFonctionnelPA("identFonctd"); //$NON-NLS-1$
    listpa.add(pa);

    pficible.setPa(listpa);

    ConnectorResponse<Retour, Commande> connectorRep_p = new ConnectorResponse<Retour, Commande>(RetourFactoryForTU.createOkRetour(), commande);
    createMockCMDcommandeLireUn(idCommand, connectorRep_p);

    ConnectorResponse<Retour, PFI> connectorRepRpg = new ConnectorResponse<Retour, PFI>(RetourFactoryForTU.createOkRetour(), pfisource);
    createMockRPGpfiLireUn(CLIENT_OPERATEUR, NO_COMPTE_SOURCE, connectorRepRpg);
    connectorRepRpg = new ConnectorResponse<Retour, PFI>(RetourFactoryForTU.createOkRetour(), pfisource);
    createMockRPGpfiLireUn(CLIENT_OPERATEUR, NO_COMPTE_CIBLE, connectorRepRpg);

    List<ServiceTechnique> listServiceTechnique1 = new ArrayList<>();
    StLienAllocationCommercial stLac = new StLienAllocationCommercial("idST", com.bytel.spirit.common.shared.saab.rst.Statut.ACTIF.name(), CLIENT_OPERATEUR, NO_COMPTE_SOURCE, TypeObjetCommercial.PA.name(), "BSS_GP", "ocNoCompte", "idRessource", TYPE_RESSOURCE_ADRESSE_MAIL); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    stLac.setOcIdentifiantFonctionnelPA(identFonct);

    listServiceTechnique1.add(stLac);

    ConnectorResponse<Retour, List<ServiceTechnique>> rstRetour = new ConnectorResponse<Retour, List<ServiceTechnique>>(RetourFactoryForTU.createOkRetour(), listServiceTechnique1);
    creatMockRSTstserviceTechniqueLireTousParPfi(CLIENT_OPERATEUR, NO_COMPTE_SOURCE, "LAC", StringConstants.EMPTY_STRING, rstRetour); //$NON-NLS-1$
    List<String> list = new ArrayList<>();
    list.add("idSt"); //$NON-NLS-1$
    UpdateStLienAllocationCommercialRequest updateLien = new UpdateStLienAllocationCommercialRequest(CLIENT_OPERATEUR, NO_COMPTE_SOURCE, NO_COMPTE_CIBLE, list);
    ConnectorResponse<Retour, Nothing> connectRepRst = new ConnectorResponse<Retour, Nothing>(RetourFactoryForTU.createOkRetour(), null);
    CreateMockRststLienAllocationCommercial(updateLien, connectRepRst);

    List<ServiceTechnique> listServiceTechnique2 = new ArrayList<>();
    StLienAllocationCommercial stLac2 = new StLienAllocationCommercial("idST", com.bytel.spirit.common.shared.saab.rst.Statut.ACTIF.name(), CLIENT_OPERATEUR, NO_COMPTE_SOURCE, TypeObjetCommercial.PA.name(), "BSS_GP", "ocNoCompte", "idRessource", TYPE_RESSOURCE_ADRESSE_MAIL); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    stLac2.setOcIdentifiantFonctionnelPA(identFonct);
    listServiceTechnique2.add(stLac2);

    StPfsMail stPfsMail = __podam.manufacturePojoWithFullData(StPfsMail.class);
    stPfsMail.setDonneesIdentificationStPfsMail(new DonneesIdentificationSTPfsMail("SECONDAIRE", "idCompteMail")); //$NON-NLS-1$ //$NON-NLS-2$
    stPfsMail.setDonneesProvisionneesStPfsMail(new DonneesProvisionneesSTPfsMail("paSecondaire", 23, 128, "TOP")); //$NON-NLS-1$ //$NON-NLS-2$
    stPfsMail.setTypeServiceTechnique(TypeST.PFS.name());
    stPfsMail.setTypePfs(TypePFS.MAIL.name());

    listServiceTechnique2.add(stPfsMail);

    rstRetour = new ConnectorResponse<Retour, List<ServiceTechnique>>(RetourFactoryForTU.createOkRetour(), listServiceTechnique2);
    creatMockRSTstserviceTechniqueLireTousParPfi(CLIENT_OPERATEUR, NO_COMPTE_SOURCE, TypeST.PFS.name(), TypePFS.MAIL.name(), rstRetour);

    Retour retourKo = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, StringConstants.EMPTY_STRING, null);
    connectRepRst = new ConnectorResponse<Retour, Nothing>(RetourFactoryForTU.createOkRetour(), null);

    UpdateStPfsRequest updateStpfsRequest = new UpdateStPfsRequest(CLIENT_OPERATEUR, NO_COMPTE_SOURCE, NO_COMPTE_SOURCE, list);
    CreateMockRSTstLienAllocCommercialGererModifPfiAssocie(updateStpfsRequest, connectRepRst);
    creatMockRSTstserviceTechniqueLireTousParPfi(CLIENT_OPERATEUR, NO_COMPTE_SOURCE, "LAC", StringConstants.EMPTY_STRING, rstRetour); //$NON-NLS-1$

    retourKo = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.DONNEE_INVALIDE, "", null); //$NON-NLS-1$
    ConnectorResponse<Retour, Nothing> connectRpg = new ConnectorResponse<Retour, Nothing>(retourKo, null);
    createMockRPGpfiEcrire(connectRpg);

    // Run scenario
    PowerMock.replayAll();
    _processInstance.startProcess(request, _tracabilite);
    // Continue Process
    _processInstance.continueProcess(request, _tracabilite);
    PowerMock.verifyAll();
    retourKo = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INVALIDE, StringConstants.EMPTY_STRING, null);
    PEP0142_Retour expectedResult = new PEP0142_Retour(RetourConverter.convertToJsonRetour(retourKo));
    String jsonExpectedRetour = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(expectedResult);

    assertEquals(ErrorCode.KO_00400, request.getResponse().getErrorCode());
    assertEquals(jsonExpectedRetour, request.getResponse().getGenericResponse().getResult());

  }

  /**
   * case PEP0142_BL001_VerifierDonnees KO because PEP0142_BL300_SupprimerPaCompteAccesSecondaire second call RPG
   * PfiEcrire Proxy error *
   * "{\"retour\":{\"resultat\":\"KO\",\"categorie\":\"CAT-4\",\"diagnostic\":\"DONNEE_INCONNUE\",\"libelle\":\"Pas de
   * PA CA avec loginmail sur le Pfi NO_COMPTE_CIBLE, La commande ne peut pas être traitée par ce processus\"}}"<br>
   *
   * @throws RavelException
   */
  @Test
  public void PEP0142_CreerCommandeTransfertBoiteMail_KO_0012() throws RavelException
  {
    String idCommand = "ID_COMMAND"; //$NON-NLS-1$
    String identFonct = "identifiantFonct"; //$NON-NLS-1$
    Request request = createRequest(idCommand);
    Commande commande = new Commande();
    commande.setStatut(Statut.ACQUITTE.name());
    ServiceMailRequest serviceMailreq = createServiceMailRequest();
    commande.setDonneesBrut(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(serviceMailreq, ServiceMailRequest.class));
    commande.setNoCompte("commandeCompte"); //$NON-NLS-1$
    commande.setClientOperateur(CLIENT_OPERATEUR);

    PFI pfisource = new PFI();
    List<PA> listpa = new ArrayList<>();
    PaTypeCompteAcces paType = new PaTypeCompteAcces("charles.rock"); //$NON-NLS-1$
    paType.setEmailLogin("loginmail"); //$NON-NLS-1$
    PA pat2 = new PA(identFonct, TypePA.COMPTE_ACCES_SECONDAIRE.name(), com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, null, null); // The COMPTE_ACCESS_SECONDAIRE
    PaTypeCompteAccesSecondaire paTypeCompteAccesSecondairet = new PaTypeCompteAccesSecondaire("paSecondaire"); //$NON-NLS-1$
    pat2.setPaTypeCompteAccesSecondaire(paTypeCompteAccesSecondairet);
    pat2.setIdentifiantFonctionnelPALie(identFonct);
    listpa.add(pat2);

    PA pa = new PA(null, "COMPTE_ACCES", com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, null, null); //$NON-NLS-1$
    pa.setPaTypeCompteAcces(paType);
    pa.setIdentifiantFonctionnelPALie(identFonct);
    pa.setIdentifiantFonctionnelPA(identFonct);
    listpa.add(pa);
    pfisource.setPa(listpa);
    pfisource.setClientOperateur(CLIENT_OPERATEUR);
    pfisource.setNoCompte(NO_COMPTE_SOURCE);
    PFI pficible = new PFI();
    listpa = new ArrayList<>();
    paType = new PaTypeCompteAcces("charles.rock"); //$NON-NLS-1$
    paType.setEmailLogin("loginmail"); //$NON-NLS-1$
    pat2 = new PA(identFonct, TypePA.COMPTE_ACCES_SECONDAIRE.name(), com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, null, null); // The COMPTE_ACCESS_SECONDAIRE
    paTypeCompteAccesSecondairet = new PaTypeCompteAccesSecondaire("paSecondaire"); //$NON-NLS-1$
    pat2.setPaTypeCompteAccesSecondaire(paTypeCompteAccesSecondairet);
    pat2.setIdentifiantFonctionnelPALie("identFonctd"); //$NON-NLS-1$
    listpa.add(pat2);

    pa = new PA(null, "COMPTE_ACCES", com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, null, null); //$NON-NLS-1$
    pa.setPaTypeCompteAcces(paType);
    pa.setIdentifiantFonctionnelPALie("identFonctd"); //$NON-NLS-1$
    pa.setIdentifiantFonctionnelPA("identFonctd"); //$NON-NLS-1$
    listpa.add(pa);

    pficible.setPa(listpa);

    ConnectorResponse<Retour, Commande> connectorRep_p = new ConnectorResponse<Retour, Commande>(RetourFactoryForTU.createOkRetour(), commande);
    createMockCMDcommandeLireUn(idCommand, connectorRep_p);

    ConnectorResponse<Retour, PFI> connectorRepRpg = new ConnectorResponse<Retour, PFI>(RetourFactoryForTU.createOkRetour(), pfisource);
    createMockRPGpfiLireUn(CLIENT_OPERATEUR, NO_COMPTE_SOURCE, connectorRepRpg);
    connectorRepRpg = new ConnectorResponse<Retour, PFI>(RetourFactoryForTU.createOkRetour(), pfisource);
    createMockRPGpfiLireUn(CLIENT_OPERATEUR, NO_COMPTE_CIBLE, connectorRepRpg);

    List<ServiceTechnique> listServiceTechnique1 = new ArrayList<>();
    StLienAllocationCommercial stLac = new StLienAllocationCommercial("idST", com.bytel.spirit.common.shared.saab.rst.Statut.ACTIF.name(), CLIENT_OPERATEUR, NO_COMPTE_SOURCE, TypeObjetCommercial.PA.name(), "BSS_GP", "ocNoCompte", "idRessource", TYPE_RESSOURCE_ADRESSE_MAIL); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    stLac.setOcIdentifiantFonctionnelPA(identFonct);

    listServiceTechnique1.add(stLac);

    ConnectorResponse<Retour, List<ServiceTechnique>> rstRetour = new ConnectorResponse<Retour, List<ServiceTechnique>>(RetourFactoryForTU.createOkRetour(), listServiceTechnique1);
    creatMockRSTstserviceTechniqueLireTousParPfi(CLIENT_OPERATEUR, NO_COMPTE_SOURCE, "LAC", StringConstants.EMPTY_STRING, rstRetour); //$NON-NLS-1$
    List<String> list = new ArrayList<>();
    list.add("idSt"); //$NON-NLS-1$
    UpdateStLienAllocationCommercialRequest updateLien = new UpdateStLienAllocationCommercialRequest(CLIENT_OPERATEUR, NO_COMPTE_SOURCE, NO_COMPTE_CIBLE, list);
    ConnectorResponse<Retour, Nothing> connectRepRst = new ConnectorResponse<Retour, Nothing>(RetourFactoryForTU.createOkRetour(), null);
    CreateMockRststLienAllocationCommercial(updateLien, connectRepRst);

    listServiceTechnique1 = new ArrayList<>();

    StPfsMail stPfsMail = __podam.manufacturePojoWithFullData(StPfsMail.class);
    stPfsMail.setDonneesIdentificationStPfsMail(new DonneesIdentificationSTPfsMail("SECONDAIRE", "idCompteMail")); //$NON-NLS-1$ //$NON-NLS-2$
    stPfsMail.setDonneesProvisionneesStPfsMail(new DonneesProvisionneesSTPfsMail("paSecondaire", 23, 128, "TOP")); //$NON-NLS-1$ //$NON-NLS-2$
    stPfsMail.setTypeServiceTechnique(TypeST.PFS.name());
    stPfsMail.setTypePfs(TypePFS.MAIL.name());
    listServiceTechnique1.add(stPfsMail);

    rstRetour = new ConnectorResponse<Retour, List<ServiceTechnique>>(RetourFactoryForTU.createOkRetour(), listServiceTechnique1);
    creatMockRSTstserviceTechniqueLireTousParPfi(CLIENT_OPERATEUR, NO_COMPTE_SOURCE, TypeST.PFS.name(), TypePFS.MAIL.name(), rstRetour);

    Retour retourKo = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, StringConstants.EMPTY_STRING, null);
    connectRepRst = new ConnectorResponse<Retour, Nothing>(RetourFactoryForTU.createOkRetour(), null);

    UpdateStPfsRequest updateStpfsRequest = new UpdateStPfsRequest(CLIENT_OPERATEUR, NO_COMPTE_SOURCE, NO_COMPTE_SOURCE, list);
    CreateMockRSTstLienAllocCommercialGererModifPfiAssocie(updateStpfsRequest, connectRepRst);
    creatMockRSTstserviceTechniqueLireTousParPfi(CLIENT_OPERATEUR, NO_COMPTE_SOURCE, "LAC", StringConstants.EMPTY_STRING, rstRetour); //$NON-NLS-1$
    retourKo = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.DONNEE_INVALIDE, "", null); //$NON-NLS-1$
    ConnectorResponse<Retour, Nothing> connectRpg = new ConnectorResponse<Retour, Nothing>(RetourFactoryForTU.createOkRetour(), null);
    createMockRPGpfiEcrire(connectRpg);
    connectRpg = new ConnectorResponse<Retour, Nothing>(retourKo, null);
    createMockRPGpfiEcrire(connectRpg);
    // Run scenario
    PowerMock.replayAll();
    _processInstance.startProcess(request, _tracabilite);
    // Continue Process
    _processInstance.continueProcess(request, _tracabilite);
    PowerMock.verifyAll();
    retourKo = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INVALIDE, StringConstants.EMPTY_STRING, null);
    PEP0142_Retour expectedResult = new PEP0142_Retour(RetourConverter.convertToJsonRetour(retourKo));
    String jsonExpectedRetour = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(expectedResult);

    assertEquals(ErrorCode.KO_00400, request.getResponse().getErrorCode());
    assertEquals(jsonExpectedRetour, request.getResponse().getGenericResponse().getResult());

  }

  /**
   * case PEP0142_BL001_VerifierDonnees KO because PEP0142_BL400_ModifierStatutCmd
   * CMDProxy.getInstance().commandeModifierStatut error PfiEcrire Proxy error *
   * "{\"retour\":{\"resultat\":\"KO\",\"categorie\":\"CAT-4\",\"diagnostic\":\"DONNEE_INCONNUE\",\"libelle\":\"Pas de
   * PA CA avec loginmail sur le Pfi NO_COMPTE_CIBLE, La commande ne peut pas être traitée par ce processus\"}}"<br>
   *
   * @throws RavelException
   */
  @Test
  public void PEP0142_CreerCommandeTransfertBoiteMail_KO_0013() throws RavelException
  {
    String idCommand = "ID_COMMAND"; //$NON-NLS-1$
    String identFonct = "identifiantFonct"; //$NON-NLS-1$
    Request request = createRequest(idCommand);
    Commande commande = new Commande();
    commande.setStatut(Statut.ACQUITTE.name());
    ServiceMailRequest serviceMailreq = createServiceMailRequest();
    commande.setDonneesBrut(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(serviceMailreq, ServiceMailRequest.class));
    commande.setNoCompte("commandeCompte"); //$NON-NLS-1$
    commande.setClientOperateur(CLIENT_OPERATEUR);

    PFI pfisource = new PFI();
    List<PA> listpa = new ArrayList<>();
    PaTypeCompteAcces paType = new PaTypeCompteAcces("charles.rock"); //$NON-NLS-1$
    paType.setEmailLogin("loginmail"); //$NON-NLS-1$
    PA pat2 = new PA(identFonct, TypePA.COMPTE_ACCES_SECONDAIRE.name(), com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, null, null); // The COMPTE_ACCESS_SECONDAIRE
    PaTypeCompteAccesSecondaire paTypeCompteAccesSecondairet = new PaTypeCompteAccesSecondaire("paSecondaire"); //$NON-NLS-1$
    pat2.setPaTypeCompteAccesSecondaire(paTypeCompteAccesSecondairet);
    pat2.setIdentifiantFonctionnelPALie(identFonct);
    listpa.add(pat2);

    PA pa = new PA(null, "COMPTE_ACCES", com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, null, null); //$NON-NLS-1$
    pa.setPaTypeCompteAcces(paType);
    pa.setIdentifiantFonctionnelPALie(identFonct);
    pa.setIdentifiantFonctionnelPA(identFonct);
    listpa.add(pa);
    pfisource.setPa(listpa);
    pfisource.setClientOperateur(CLIENT_OPERATEUR);
    pfisource.setNoCompte(NO_COMPTE_SOURCE);
    PFI pficible = new PFI();
    listpa = new ArrayList<>();
    paType = new PaTypeCompteAcces("charles.rock"); //$NON-NLS-1$
    paType.setEmailLogin("loginmail"); //$NON-NLS-1$
    pat2 = new PA(identFonct, TypePA.COMPTE_ACCES_SECONDAIRE.name(), com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, null, null); // The COMPTE_ACCESS_SECONDAIRE
    paTypeCompteAccesSecondairet = new PaTypeCompteAccesSecondaire("paSecondaire"); //$NON-NLS-1$
    pat2.setPaTypeCompteAccesSecondaire(paTypeCompteAccesSecondairet);
    pat2.setIdentifiantFonctionnelPALie("identFonctd"); //$NON-NLS-1$
    listpa.add(pat2);

    pa = new PA(null, "COMPTE_ACCES", com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, null, null); //$NON-NLS-1$
    pa.setPaTypeCompteAcces(paType);
    pa.setIdentifiantFonctionnelPALie("identFonctd"); //$NON-NLS-1$
    pa.setIdentifiantFonctionnelPA("identFonctd"); //$NON-NLS-1$
    listpa.add(pa);

    pficible.setPa(listpa);

    ConnectorResponse<Retour, Commande> connectorRep_p = new ConnectorResponse<Retour, Commande>(RetourFactoryForTU.createOkRetour(), commande);
    createMockCMDcommandeLireUn(idCommand, connectorRep_p);

    ConnectorResponse<Retour, PFI> connectorRepRpg = new ConnectorResponse<Retour, PFI>(RetourFactoryForTU.createOkRetour(), pfisource);
    createMockRPGpfiLireUn(CLIENT_OPERATEUR, NO_COMPTE_SOURCE, connectorRepRpg);
    connectorRepRpg = new ConnectorResponse<Retour, PFI>(RetourFactoryForTU.createOkRetour(), pfisource);
    createMockRPGpfiLireUn(CLIENT_OPERATEUR, NO_COMPTE_CIBLE, connectorRepRpg);

    List<ServiceTechnique> listServiceTechnique1 = new ArrayList<>();
    StLienAllocationCommercial stLac = new StLienAllocationCommercial("idST", com.bytel.spirit.common.shared.saab.rst.Statut.ACTIF.name(), CLIENT_OPERATEUR, NO_COMPTE_SOURCE, TypeObjetCommercial.PA.name(), "BSS_GP", "ocNoCompte", "idRessource", TYPE_RESSOURCE_ADRESSE_MAIL); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    stLac.setOcIdentifiantFonctionnelPA(identFonct);

    listServiceTechnique1.add(stLac);

    ConnectorResponse<Retour, List<ServiceTechnique>> rstRetour = new ConnectorResponse<Retour, List<ServiceTechnique>>(RetourFactoryForTU.createOkRetour(), listServiceTechnique1);
    creatMockRSTstserviceTechniqueLireTousParPfi(CLIENT_OPERATEUR, NO_COMPTE_SOURCE, "LAC", StringConstants.EMPTY_STRING, rstRetour); //$NON-NLS-1$
    List<String> list = new ArrayList<>();
    list.add("idSt"); //$NON-NLS-1$
    UpdateStLienAllocationCommercialRequest updateLien = new UpdateStLienAllocationCommercialRequest(CLIENT_OPERATEUR, NO_COMPTE_SOURCE, NO_COMPTE_CIBLE, list);
    ConnectorResponse<Retour, Nothing> connectRepRst = new ConnectorResponse<Retour, Nothing>(RetourFactoryForTU.createOkRetour(), null);
    CreateMockRststLienAllocationCommercial(updateLien, connectRepRst);

    listServiceTechnique1 = new ArrayList<>();

    StPfsMail stPfsMail = __podam.manufacturePojoWithFullData(StPfsMail.class);
    stPfsMail.setDonneesIdentificationStPfsMail(new DonneesIdentificationSTPfsMail("SECONDAIRE", "idCompteMail")); //$NON-NLS-1$ //$NON-NLS-2$
    stPfsMail.setDonneesProvisionneesStPfsMail(new DonneesProvisionneesSTPfsMail("paSecondaire", 23, 128, "TOP")); //$NON-NLS-1$ //$NON-NLS-2$
    stPfsMail.setTypeServiceTechnique(TypeST.PFS.name());
    stPfsMail.setTypePfs(TypePFS.MAIL.name());
    listServiceTechnique1.add(stPfsMail);

    rstRetour = new ConnectorResponse<Retour, List<ServiceTechnique>>(RetourFactoryForTU.createOkRetour(), listServiceTechnique1);
    creatMockRSTstserviceTechniqueLireTousParPfi(CLIENT_OPERATEUR, NO_COMPTE_SOURCE, TypeST.PFS.name(), TypePFS.MAIL.name(), rstRetour);

    Retour retourKo = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, StringConstants.EMPTY_STRING, null);
    connectRepRst = new ConnectorResponse<Retour, Nothing>(RetourFactoryForTU.createOkRetour(), null);

    UpdateStPfsRequest updateStpfsRequest = new UpdateStPfsRequest(CLIENT_OPERATEUR, NO_COMPTE_SOURCE, NO_COMPTE_SOURCE, list);
    CreateMockRSTstLienAllocCommercialGererModifPfiAssocie(updateStpfsRequest, connectRepRst);
    creatMockRSTstserviceTechniqueLireTousParPfi(CLIENT_OPERATEUR, NO_COMPTE_SOURCE, "LAC", StringConstants.EMPTY_STRING, rstRetour); //$NON-NLS-1$
    retourKo = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.DONNEE_INVALIDE, "", null); //$NON-NLS-1$
    ConnectorResponse<Retour, Nothing> connectRpg = new ConnectorResponse<Retour, Nothing>(RetourFactoryForTU.createOkRetour(), null);
    createMockRPGpfiEcrire(connectRpg);
    connectRpg = new ConnectorResponse<Retour, Nothing>(RetourFactoryForTU.createOkRetour(), null);
    createMockRPGpfiEcrire(connectRpg);

    List<IndexRecherchePfi> listindex = new ArrayList<>();
    IndexRecherchePfi indexRecherche = new IndexRecherchePfi(CLIENT_OPERATEUR, NO_COMPTE_SOURCE);
    List<CleRecherche> listCle = new ArrayList<>();
    CleRecherche clerecherche = new CleRecherche("type", "valeur"); //$NON-NLS-1$//$NON-NLS-2$
    listCle.add(clerecherche);
    indexRecherche.setListeCleRecherche(listCle);
    listindex.add(indexRecherche);
    ConnectorResponse<Retour, List<IndexRecherchePfi>> connectorRepAir = new ConnectorResponse<Retour, List<IndexRecherchePfi>>(RetourFactoryForTU.createOkRetour(), listindex);
    creatMockAIRindexRechercherPfiLireUn(CLIENT_OPERATEUR, NO_COMPTE_SOURCE, connectorRepAir);

    ConnectorResponse<Retour, Nothing> connectorRepCmd = new ConnectorResponse<Retour, Nothing>(retourKo, null);
    creatMockCmdcommandeModifierStatut(idCommand, Statut.EN_COURS.name(), null, null, null, connectorRepCmd);

    // Run scenario
    PowerMock.replayAll();

    _processInstance.startProcess(request, _tracabilite);
    // Continue Process
    _processInstance.continueProcess(request, _tracabilite);
    PowerMock.verifyAll();
    retourKo = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INVALIDE, StringConstants.EMPTY_STRING, null);
    PEP0142_Retour expectedResult = new PEP0142_Retour(RetourConverter.convertToJsonRetour(retourKo));
    String jsonExpectedRetour = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(expectedResult);

    assertEquals(ErrorCode.KO_00400, request.getResponse().getErrorCode());
    assertEquals(jsonExpectedRetour, request.getResponse().getGenericResponse().getResult());

  }

  /**
   * case PEP0142_BL001_VerifierDonnees KO because PEP0142_BL400_SupprimerCleRechercheAdresseMail
   * AIRProxy.getInstance().indexRechercherPfiLireUn error PfiLire Proxy error *
   * "{\"retour\":{\"resultat\":\"KO\",\"categorie\":\"CAT-4\",\"diagnostic\":\"DONNEE_INCONNUE\",\"libelle\":\"Pas de
   * PA CA avec loginmail sur le Pfi NO_COMPTE_CIBLE, La commande ne peut pas être traitée par ce processus\"}}"<br>
   *
   * @throws RavelException
   */
  @Test
  public void PEP0142_CreerCommandeTransfertBoiteMail_KO_0014() throws RavelException
  {
    String idCommand = "ID_COMMAND"; //$NON-NLS-1$
    String identFonct = "identifiantFonct"; //$NON-NLS-1$
    Request request = createRequest(idCommand);
    Commande commande = new Commande();
    commande.setStatut(Statut.ACQUITTE.name());
    ServiceMailRequest serviceMailreq = createServiceMailRequest();
    commande.setDonneesBrut(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(serviceMailreq, ServiceMailRequest.class));
    commande.setNoCompte("commandeCompte"); //$NON-NLS-1$
    commande.setClientOperateur(CLIENT_OPERATEUR);

    PFI pfisource = new PFI();
    List<PA> listpa = new ArrayList<>();
    PaTypeCompteAcces paType = new PaTypeCompteAcces("charles.rock"); //$NON-NLS-1$
    paType.setEmailLogin("loginmail"); //$NON-NLS-1$
    PA pat2 = new PA(identFonct, TypePA.COMPTE_ACCES_SECONDAIRE.name(), com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, null, null); // The COMPTE_ACCESS_SECONDAIRE
    PaTypeCompteAccesSecondaire paTypeCompteAccesSecondairet = new PaTypeCompteAccesSecondaire("paSecondaire"); //$NON-NLS-1$
    pat2.setPaTypeCompteAccesSecondaire(paTypeCompteAccesSecondairet);
    pat2.setIdentifiantFonctionnelPALie(identFonct);
    listpa.add(pat2);

    PA pa = new PA(null, "COMPTE_ACCES", com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, null, null); //$NON-NLS-1$
    pa.setPaTypeCompteAcces(paType);
    pa.setIdentifiantFonctionnelPALie(identFonct);
    pa.setIdentifiantFonctionnelPA(identFonct);
    listpa.add(pa);
    pfisource.setPa(listpa);
    pfisource.setClientOperateur(CLIENT_OPERATEUR);
    pfisource.setNoCompte(NO_COMPTE_SOURCE);
    PFI pficible = new PFI();
    listpa = new ArrayList<>();
    paType = new PaTypeCompteAcces("charles.rock"); //$NON-NLS-1$
    paType.setEmailLogin("loginmail"); //$NON-NLS-1$
    pat2 = new PA(identFonct, TypePA.COMPTE_ACCES_SECONDAIRE.name(), com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, null, null); // The COMPTE_ACCESS_SECONDAIRE
    paTypeCompteAccesSecondairet = new PaTypeCompteAccesSecondaire("paSecondaire"); //$NON-NLS-1$
    pat2.setPaTypeCompteAccesSecondaire(paTypeCompteAccesSecondairet);
    pat2.setIdentifiantFonctionnelPALie("identFonctd"); //$NON-NLS-1$
    listpa.add(pat2);

    pa = new PA(null, "COMPTE_ACCES", com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, null, null); //$NON-NLS-1$
    pa.setPaTypeCompteAcces(paType);
    pa.setIdentifiantFonctionnelPALie("identFonctd"); //$NON-NLS-1$
    pa.setIdentifiantFonctionnelPA("identFonctd"); //$NON-NLS-1$
    listpa.add(pa);

    pficible.setPa(listpa);

    ConnectorResponse<Retour, Commande> connectorRep_p = new ConnectorResponse<Retour, Commande>(RetourFactoryForTU.createOkRetour(), commande);
    createMockCMDcommandeLireUn(idCommand, connectorRep_p);

    ConnectorResponse<Retour, PFI> connectorRepRpg = new ConnectorResponse<Retour, PFI>(RetourFactoryForTU.createOkRetour(), pfisource);
    createMockRPGpfiLireUn(CLIENT_OPERATEUR, NO_COMPTE_SOURCE, connectorRepRpg);
    connectorRepRpg = new ConnectorResponse<Retour, PFI>(RetourFactoryForTU.createOkRetour(), pfisource);
    createMockRPGpfiLireUn(CLIENT_OPERATEUR, NO_COMPTE_CIBLE, connectorRepRpg);

    List<ServiceTechnique> listServiceTechnique1 = new ArrayList<>();
    StLienAllocationCommercial stLac = new StLienAllocationCommercial("idST", com.bytel.spirit.common.shared.saab.rst.Statut.ACTIF.name(), CLIENT_OPERATEUR, NO_COMPTE_SOURCE, TypeObjetCommercial.PA.name(), "BSS_GP", "ocNoCompte", "idRessource", TYPE_RESSOURCE_ADRESSE_MAIL); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    stLac.setOcIdentifiantFonctionnelPA(identFonct);
    listServiceTechnique1.add(stLac);

    ConnectorResponse<Retour, List<ServiceTechnique>> rstRetour = new ConnectorResponse<Retour, List<ServiceTechnique>>(RetourFactoryForTU.createOkRetour(), listServiceTechnique1);
    creatMockRSTstserviceTechniqueLireTousParPfi(CLIENT_OPERATEUR, NO_COMPTE_SOURCE, "LAC", StringConstants.EMPTY_STRING, rstRetour); //$NON-NLS-1$
    List<String> list = new ArrayList<>();
    list.add("idSt"); //$NON-NLS-1$
    UpdateStLienAllocationCommercialRequest updateLien = new UpdateStLienAllocationCommercialRequest(CLIENT_OPERATEUR, NO_COMPTE_SOURCE, NO_COMPTE_CIBLE, list);
    ConnectorResponse<Retour, Nothing> connectRepRst = new ConnectorResponse<Retour, Nothing>(RetourFactoryForTU.createOkRetour(), null);
    CreateMockRststLienAllocationCommercial(updateLien, connectRepRst);

    listServiceTechnique1 = new ArrayList<>();
    StPfsMail stPfsMail = __podam.manufacturePojoWithFullData(StPfsMail.class);
    stPfsMail.setDonneesIdentificationStPfsMail(new DonneesIdentificationSTPfsMail("SECONDAIRE", "idCompteMail")); //$NON-NLS-1$ //$NON-NLS-2$
    stPfsMail.setDonneesProvisionneesStPfsMail(new DonneesProvisionneesSTPfsMail("paSecondaire", 23, 128, "TOP")); //$NON-NLS-1$ //$NON-NLS-2$
    stPfsMail.setTypeServiceTechnique(TypeST.PFS.name());
    stPfsMail.setTypePfs(TypePFS.MAIL.name());
    listServiceTechnique1.add(stPfsMail);

    rstRetour = new ConnectorResponse<Retour, List<ServiceTechnique>>(RetourFactoryForTU.createOkRetour(), listServiceTechnique1);
    creatMockRSTstserviceTechniqueLireTousParPfi(CLIENT_OPERATEUR, NO_COMPTE_SOURCE, TypeST.PFS.name(), TypePFS.MAIL.name(), rstRetour);

    Retour retourKo = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, StringConstants.EMPTY_STRING, null);
    connectRepRst = new ConnectorResponse<Retour, Nothing>(RetourFactoryForTU.createOkRetour(), null);

    UpdateStPfsRequest updateStpfsRequest = new UpdateStPfsRequest(CLIENT_OPERATEUR, NO_COMPTE_SOURCE, NO_COMPTE_SOURCE, list);
    CreateMockRSTstLienAllocCommercialGererModifPfiAssocie(updateStpfsRequest, connectRepRst);
    creatMockRSTstserviceTechniqueLireTousParPfi(CLIENT_OPERATEUR, NO_COMPTE_SOURCE, "LAC", StringConstants.EMPTY_STRING, rstRetour); //$NON-NLS-1$
    retourKo = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.DONNEE_INVALIDE, "", null); //$NON-NLS-1$
    ConnectorResponse<Retour, Nothing> connectRpg = new ConnectorResponse<Retour, Nothing>(RetourFactoryForTU.createOkRetour(), null);
    createMockRPGpfiEcrire(connectRpg);
    connectRpg = new ConnectorResponse<Retour, Nothing>(RetourFactoryForTU.createOkRetour(), null);
    createMockRPGpfiEcrire(connectRpg);

    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, ""); //$NON-NLS-1$
    ConnectorResponse<Retour, List<IndexRecherchePfi>> connectorRepAir = new ConnectorResponse<Retour, List<IndexRecherchePfi>>(retour, null);
    creatMockAIRindexRechercherPfiLireUn(CLIENT_OPERATEUR, NO_COMPTE_SOURCE, connectorRepAir);
    //ConnectorResponse<Retour, Nothing> connectRep = new ConnectorResponse<Retour, Nothing>(RetourFactoryForTU.createOkRetour(), null);
    //creatMockAIRindexRechercherPfiEcrire(connectRep);

    ConnectorResponse<Retour, Nothing> connectorRepCmd = new ConnectorResponse<Retour, Nothing>(retourKo, null);
    creatMockCmdcommandeModifierStatut(idCommand, Statut.EN_COURS.name(), null, null, null, connectorRepCmd);

    // Run scenario
    PowerMock.replayAll();

    _processInstance.startProcess(request, _tracabilite);
    // Continue Process
    _processInstance.continueProcess(request, _tracabilite);
    PowerMock.verifyAll();
    retourKo = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INVALIDE, StringConstants.EMPTY_STRING, null);
    PEP0142_Retour expectedResult = new PEP0142_Retour(RetourConverter.convertToJsonRetour(retourKo));
    String jsonExpectedRetour = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(expectedResult);

    assertEquals(ErrorCode.KO_00400, request.getResponse().getErrorCode());
    assertEquals(jsonExpectedRetour, request.getResponse().getGenericResponse().getResult());

  }

  /**
   * case PEP0142_BL001_VerifierDonnees KO because PEP0142_BL100_CopierPaCompteAccesSecondaire KO first call of RPG
   * pfiLireUn connector KO
   * "{\"retour\":{\"resultat\":\"KO\",\"categorie\":\"CAT-4\",\"diagnostic\":\"DONNEE_INVALIDE\",\"libelle\":\"\"}}"<br>
   *
   * @throws RavelException
   */
  @Test
  public void PEP0142_CreerCommandeTransfertBoiteMail_KO_002() throws RavelException
  {
    String idCommand = "ID_COMMAND"; //$NON-NLS-1$
    Request request = createRequest(idCommand);
    Commande commande = new Commande();
    commande.setStatut(Statut.ACQUITTE.name());
    ServiceMailRequest serviceMailreq = createServiceMailRequest();
    commande.setDonneesBrut(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(serviceMailreq, ServiceMailRequest.class));
    commande.setNoCompte("commandeCompte"); //$NON-NLS-1$
    commande.setClientOperateur(CLIENT_OPERATEUR);
    ConnectorResponse<Retour, Commande> connectorRep_p = new ConnectorResponse<Retour, Commande>(RetourFactoryForTU.createOkRetour(), commande);
    createMockCMDcommandeLireUn(idCommand, connectorRep_p);
    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.DONNEE_INVALIDE, "", null); //$NON-NLS-1$
    ConnectorResponse<Retour, PFI> connectorRepRpg = new ConnectorResponse<Retour, PFI>(retour, null);
    createMockRPGpfiLireUn(CLIENT_OPERATEUR, NO_COMPTE_SOURCE, connectorRepRpg);
    // Run scenario
    PowerMock.replayAll();
    _processInstance.startProcess(request, _tracabilite);
    // Continue Process
    _processInstance.continueProcess(request, _tracabilite);
    PowerMock.verifyAll();
    Retour retourKo = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.DONNEE_INVALIDE, "", null); //$NON-NLS-1$
    PEP0142_Retour expectedResult = new PEP0142_Retour(RetourConverter.convertToJsonRetour(retourKo));
    String jsonExpectedRetour = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(expectedResult);

    assertEquals(ErrorCode.KO_00400, request.getResponse().getErrorCode());
    assertEquals(jsonExpectedRetour, request.getResponse().getGenericResponse().getResult());
  }

  /**
   * case PEP0142_BL001_VerifierDonnees KO because PEP0142_BL100_CopierPaCompteAccesSecondaire KO second call of RPG
   * pfiLireUn connector KO
   * "{\"retour\":{\"resultat\":\"KO\",\"categorie\":\"CAT-4\",\"diagnostic\":\"DONNEE_INVALIDE\",\"libelle\":\"\"}}"<br>
   *
   * @throws RavelException
   */
  @Test
  public void PEP0142_CreerCommandeTransfertBoiteMail_KO_003() throws RavelException
  {
    String idCommand = "ID_COMMAND"; //$NON-NLS-1$
    Request request = createRequest(idCommand);
    Commande commande = new Commande();
    commande.setStatut(Statut.ACQUITTE.name());
    ServiceMailRequest serviceMailreq = createServiceMailRequest();
    commande.setDonneesBrut(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(serviceMailreq, ServiceMailRequest.class));
    commande.setNoCompte("commandeCompte"); //$NON-NLS-1$
    commande.setClientOperateur(CLIENT_OPERATEUR);

    PFI pfi = new PFI();
    List<PA> listpa = new ArrayList<>();
    PaTypeCompteAcces paType = new PaTypeCompteAcces("charles.rock"); //$NON-NLS-1$
    PA pa = new PA(null, "COMPTE_ACCES", null, null, null); //$NON-NLS-1$
    pa.setPaTypeCompteAcces(paType);
    listpa.add(pa);
    pfi.setPa(listpa);

    ConnectorResponse<Retour, Commande> connectorRep_p = new ConnectorResponse<Retour, Commande>(RetourFactoryForTU.createOkRetour(), commande);
    createMockCMDcommandeLireUn(idCommand, connectorRep_p);

    ConnectorResponse<Retour, PFI> connectorRepRpg = new ConnectorResponse<Retour, PFI>(RetourFactoryForTU.createOkRetour(), pfi);
    createMockRPGpfiLireUn(CLIENT_OPERATEUR, NO_COMPTE_SOURCE, connectorRepRpg);
    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.DONNEE_INVALIDE, "", null); //$NON-NLS-1$
    connectorRepRpg = new ConnectorResponse<Retour, PFI>(retour, null);
    createMockRPGpfiLireUn(CLIENT_OPERATEUR, NO_COMPTE_CIBLE, connectorRepRpg);
    // Run scenario
    PowerMock.replayAll();
    _processInstance.startProcess(request, _tracabilite);
    // Continue Process
    _processInstance.continueProcess(request, _tracabilite);
    PowerMock.verifyAll();
    Retour retourKo = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.DONNEE_INVALIDE, "", null); //$NON-NLS-1$
    PEP0142_Retour expectedResult = new PEP0142_Retour(RetourConverter.convertToJsonRetour(retourKo));
    String jsonExpectedRetour = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(expectedResult);

    assertEquals(ErrorCode.KO_00400, request.getResponse().getErrorCode());
    assertEquals(jsonExpectedRetour, request.getResponse().getGenericResponse().getResult());
  }

  /**
   * case PEP0142_BL001_VerifierDonnees KO because PEP0142_BL100_CopierPaCompteAccesSecondaire KO PA not found pfiLireUn
   * connector KO
   * "{\"retour\":{\"resultat\":\"KO\",\"categorie\":\"CAT-4\",\"diagnostic\":\"DONNEE_INCONNUE\",\"libelle\":\"Pas de
   * PA CA avec nologinsource sur le Pfi NO_COMPTE_SOURCE, La commande ne peut pas être traitée par ce
   * processus\"}}"<br>
   *
   * @throws RavelException
   */
  @Test
  public void PEP0142_CreerCommandeTransfertBoiteMail_KO_004() throws RavelException
  {
    String idCommand = "ID_COMMAND"; //$NON-NLS-1$
    Request request = createRequest(idCommand);
    Commande commande = new Commande();
    commande.setStatut(Statut.ACQUITTE.name());
    ServiceMailRequest serviceMailreq = createServiceMailRequest();
    commande.setDonneesBrut(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(serviceMailreq, ServiceMailRequest.class));
    commande.setNoCompte("commandeCompte"); //$NON-NLS-1$
    commande.setClientOperateur(CLIENT_OPERATEUR);

    PFI pfi = new PFI();
    List<PA> listpa = new ArrayList<>();
    PaTypeCompteAcces paType = new PaTypeCompteAcces("charles.rock"); //$NON-NLS-1$
    PA pa = new PA(null, "COMPTE_ACCES", null, null, null); //$NON-NLS-1$
    pa.setPaTypeCompteAcces(paType);
    listpa.add(pa);
    pfi.setPa(listpa);

    ConnectorResponse<Retour, Commande> connectorRep_p = new ConnectorResponse<Retour, Commande>(RetourFactoryForTU.createOkRetour(), commande);
    createMockCMDcommandeLireUn(idCommand, connectorRep_p);

    ConnectorResponse<Retour, PFI> connectorRepRpg = new ConnectorResponse<Retour, PFI>(RetourFactoryForTU.createOkRetour(), pfi);
    createMockRPGpfiLireUn(CLIENT_OPERATEUR, NO_COMPTE_SOURCE, connectorRepRpg);

    connectorRepRpg = new ConnectorResponse<Retour, PFI>(RetourFactoryForTU.createOkRetour(), pfi);
    createMockRPGpfiLireUn(CLIENT_OPERATEUR, NO_COMPTE_CIBLE, connectorRepRpg);
    // Run scenario
    PowerMock.replayAll();
    _processInstance.startProcess(request, _tracabilite);
    // Continue Process
    _processInstance.continueProcess(request, _tracabilite);
    PowerMock.verifyAll();
    Retour retourKo = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, LIBELLE_2, BL100_ACTIVITY_NAME);
    PEP0142_Retour expectedResult = new PEP0142_Retour(RetourConverter.convertToJsonRetour(retourKo));
    String jsonExpectedRetour = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(expectedResult);

    assertEquals(ErrorCode.KO_00400, request.getResponse().getErrorCode());
    assertEquals(jsonExpectedRetour, request.getResponse().getGenericResponse().getResult());
  }

  /**
   * case PEP0142_BL001_VerifierDonnees KO because PEP0142_BL100_CopierPaCompteAccesSecondaire KO second call of RPG
   * pfiLireUn connector KO
   * "{\"retour\":{\"resultat\":\"KO\",\"categorie\":\"CAT-4\",\"diagnostic\":\"DONNEE_INCONNUE\",\"libelle\":\"Pas de
   * PA CA avec nologinsource sur le Pfi NO_COMPTE_SOURCE, La commande ne peut pas être traitée par ce
   * processus\"}}"<br>
   *
   * @throws RavelException
   */
  @Test
  public void PEP0142_CreerCommandeTransfertBoiteMail_KO_005() throws RavelException
  {
    String idCommand = "ID_COMMAND"; //$NON-NLS-1$
    Request request = createRequest(idCommand);
    Commande commande = new Commande();
    commande.setStatut(Statut.ACQUITTE.name());
    ServiceMailRequest serviceMailreq = createServiceMailRequest();
    commande.setDonneesBrut(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(serviceMailreq, ServiceMailRequest.class));
    commande.setNoCompte("commandeCompte"); //$NON-NLS-1$

    commande.setClientOperateur(CLIENT_OPERATEUR);

    PFI pfi = new PFI();
    List<PA> listpa = new ArrayList<>();
    PaTypeCompteAcces paType = new PaTypeCompteAcces("charles.rock"); //$NON-NLS-1$
    paType.setEmailLogin("loginmail"); //$NON-NLS-1$
    PA pa = new PA(null, "COMPTE_ACCES", com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, null, null); //$NON-NLS-1$
    pa.setPaTypeCompteAcces(paType);
    listpa.add(pa);
    pfi.setPa(listpa);

    ConnectorResponse<Retour, Commande> connectorRep_p = new ConnectorResponse<Retour, Commande>(RetourFactoryForTU.createOkRetour(), commande);
    createMockCMDcommandeLireUn(idCommand, connectorRep_p);

    ConnectorResponse<Retour, PFI> connectorRepRpg = new ConnectorResponse<Retour, PFI>(RetourFactoryForTU.createOkRetour(), pfi);
    createMockRPGpfiLireUn(CLIENT_OPERATEUR, NO_COMPTE_SOURCE, connectorRepRpg);

    connectorRepRpg = new ConnectorResponse<Retour, PFI>(RetourFactoryForTU.createOkRetour(), pfi);
    createMockRPGpfiLireUn(CLIENT_OPERATEUR, NO_COMPTE_CIBLE, connectorRepRpg);

    Retour retourKo = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "", null); //$NON-NLS-1$

    ConnectorResponse<Retour, Nothing> connectorRepCmd = new ConnectorResponse<Retour, Nothing>(retourKo, null);
    creatMockCmdcommandeModifierStatut(idCommand, Statut.OBSOLETE.name(), IMegSpiritConsts.NOP_TRANSFERT_MAIL_SECONDAIRE, IMegSpiritConsts.NOP_TRANSFERT_MAIL_SECONDAIRE, LIBELLE_3, connectorRepCmd);
    // Run scenario
    PowerMock.replayAll();
    _processInstance.startProcess(request, _tracabilite);
    // Continue Process
    _processInstance.continueProcess(request, _tracabilite);
    PowerMock.verifyAll();
    retourKo = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "", null); //$NON-NLS-1$
    PEP0142_Retour expectedResult = new PEP0142_Retour(RetourConverter.convertToJsonRetour(retourKo));
    String jsonExpectedRetour = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(expectedResult);

    assertEquals(ErrorCode.KO_00400, request.getResponse().getErrorCode());
    assertEquals(jsonExpectedRetour, request.getResponse().getGenericResponse().getResult());
  }

  /**
   * case PEP0142_BL001_VerifierDonnees KO because PEP0142_BL100_CopierPaCompteAccesSecondaire KO PFICible not found *
   * "{\"retour\":{\"resultat\":\"KO\",\"categorie\":\"CAT-4\",\"diagnostic\":\"DONNEE_INCONNUE\",\"libelle\":\"Pas de
   * PA CA avec loginmail sur le Pfi NO_COMPTE_CIBLE, La commande ne peut pas être traitée par ce processus\"}}"<br>
   *
   * @throws RavelException
   */
  @Test
  public void PEP0142_CreerCommandeTransfertBoiteMail_KO_006() throws RavelException
  {
    String idCommand = "ID_COMMAND"; //$NON-NLS-1$
    Request request = createRequest(idCommand);
    Commande commande = new Commande();
    commande.setStatut(Statut.ACQUITTE.name());
    ServiceMailRequest serviceMailreq = createServiceMailRequest();
    commande.setDonneesBrut(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(serviceMailreq, ServiceMailRequest.class));
    commande.setNoCompte("commandeCompte"); //$NON-NLS-1$
    commande.setClientOperateur(CLIENT_OPERATEUR);

    PFI pfisource = new PFI();
    List<PA> listpa = new ArrayList<>();
    PaTypeCompteAcces paType = new PaTypeCompteAcces("charles.rock"); //$NON-NLS-1$
    paType.setEmailLogin("loginmail"); //$NON-NLS-1$
    PA pa = new PA(null, "COMPTE_ACCES", com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, null, null); //$NON-NLS-1$
    pa.setPaTypeCompteAcces(paType);
    listpa.add(pa);
    pfisource.setPa(listpa);

    ConnectorResponse<Retour, Commande> connectorRep_p = new ConnectorResponse<Retour, Commande>(RetourFactoryForTU.createOkRetour(), commande);
    createMockCMDcommandeLireUn(idCommand, connectorRep_p);

    ConnectorResponse<Retour, PFI> connectorRepRpg = new ConnectorResponse<Retour, PFI>(RetourFactoryForTU.createOkRetour(), pfisource);
    createMockRPGpfiLireUn(CLIENT_OPERATEUR, NO_COMPTE_SOURCE, connectorRepRpg);

    PFI pficible = new PFI();
    connectorRepRpg = new ConnectorResponse<Retour, PFI>(RetourFactoryForTU.createOkRetour(), pficible);
    createMockRPGpfiLireUn(CLIENT_OPERATEUR, NO_COMPTE_CIBLE, connectorRepRpg);

    // Run scenario
    PowerMock.replayAll();
    _processInstance.startProcess(request, _tracabilite);
    // Continue Process
    _processInstance.continueProcess(request, _tracabilite);
    PowerMock.verifyAll();
    Retour retourKo = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, LIBELLE_4, BL100_ACTIVITY_NAME);
    PEP0142_Retour expectedResult = new PEP0142_Retour(RetourConverter.convertToJsonRetour(retourKo));
    String jsonExpectedRetour = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(expectedResult);

    assertEquals(ErrorCode.KO_00400, request.getResponse().getErrorCode());
    assertEquals(jsonExpectedRetour, request.getResponse().getGenericResponse().getResult());
  }

  /**
   * case PEP0142_BL001_VerifierDonnees KO because PEP0142_BL201_TransfererStLienAllocationComAdresseMail RST Proxy
   * error *
   * "{\"retour\":{\"resultat\":\"KO\",\"categorie\":\"CAT-4\",\"diagnostic\":\"DONNEE_INCONNUE\",\"libelle\":\"Pas de
   * PA CA avec loginmail sur le Pfi NO_COMPTE_CIBLE, La commande ne peut pas être traitée par ce processus\"}}"<br>
   *
   * @throws RavelException
   */
  @Test
  public void PEP0142_CreerCommandeTransfertBoiteMail_KO_007() throws RavelException
  {
    String idCommand = "ID_COMMAND"; //$NON-NLS-1$
    String identFonct = "identifiantFonct"; //$NON-NLS-1$
    Request request = createRequest(idCommand);
    Commande commande = new Commande();
    commande.setStatut(Statut.ACQUITTE.name());
    ServiceMailRequest serviceMailreq = createServiceMailRequest();
    commande.setDonneesBrut(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(serviceMailreq, ServiceMailRequest.class));
    commande.setNoCompte("commandeCompte"); //$NON-NLS-1$
    commande.setClientOperateur(CLIENT_OPERATEUR);

    PFI pfisource = new PFI();
    List<PA> listpa = new ArrayList<>();
    PaTypeCompteAcces paType = new PaTypeCompteAcces("charles.rock"); //$NON-NLS-1$
    paType.setEmailLogin("loginmail"); //$NON-NLS-1$
    PA pat2 = new PA(identFonct, TypePA.COMPTE_ACCES_SECONDAIRE.name(), com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, null, null); // The COMPTE_ACCESS_SECONDAIRE
    PaTypeCompteAccesSecondaire paTypeCompteAccesSecondairet = new PaTypeCompteAccesSecondaire("paSecondaire"); //$NON-NLS-1$
    pat2.setPaTypeCompteAccesSecondaire(paTypeCompteAccesSecondairet);
    pat2.setIdentifiantFonctionnelPALie(identFonct);
    listpa.add(pat2);

    PA pa = new PA(null, "COMPTE_ACCES", com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, null, null); //$NON-NLS-1$
    pa.setPaTypeCompteAcces(paType);
    pa.setIdentifiantFonctionnelPALie(identFonct);
    pa.setIdentifiantFonctionnelPA(identFonct);
    listpa.add(pa);
    pfisource.setPa(listpa);
    pfisource.setClientOperateur(CLIENT_OPERATEUR);
    pfisource.setNoCompte(NO_COMPTE_SOURCE);
    PFI pficible = new PFI();
    listpa = new ArrayList<>();
    paType = new PaTypeCompteAcces("charles.rock"); //$NON-NLS-1$
    paType.setEmailLogin("loginmail"); //$NON-NLS-1$
    pat2 = new PA(identFonct, TypePA.COMPTE_ACCES_SECONDAIRE.name(), com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, null, null); // The COMPTE_ACCESS_SECONDAIRE
    paTypeCompteAccesSecondairet = new PaTypeCompteAccesSecondaire("paSecondaire"); //$NON-NLS-1$
    pat2.setPaTypeCompteAccesSecondaire(paTypeCompteAccesSecondairet);
    pat2.setIdentifiantFonctionnelPALie("identFonctd"); //$NON-NLS-1$
    listpa.add(pat2);

    pa = new PA(null, "COMPTE_ACCES", com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, null, null); //$NON-NLS-1$
    pa.setPaTypeCompteAcces(paType);
    pa.setIdentifiantFonctionnelPALie("identFonctd"); //$NON-NLS-1$
    pa.setIdentifiantFonctionnelPA("identFonctd"); //$NON-NLS-1$
    listpa.add(pa);

    pficible.setPa(listpa);

    ConnectorResponse<Retour, Commande> connectorRep_p = new ConnectorResponse<Retour, Commande>(RetourFactoryForTU.createOkRetour(), commande);
    createMockCMDcommandeLireUn(idCommand, connectorRep_p);

    ConnectorResponse<Retour, PFI> connectorRepRpg = new ConnectorResponse<Retour, PFI>(RetourFactoryForTU.createOkRetour(), pfisource);
    createMockRPGpfiLireUn(CLIENT_OPERATEUR, NO_COMPTE_SOURCE, connectorRepRpg);
    connectorRepRpg = new ConnectorResponse<Retour, PFI>(RetourFactoryForTU.createOkRetour(), pfisource);
    createMockRPGpfiLireUn(CLIENT_OPERATEUR, NO_COMPTE_CIBLE, connectorRepRpg);
    Retour retourKo = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, LIBELLE_4, null);
    ConnectorResponse<Retour, List<ServiceTechnique>> rstRetour = new ConnectorResponse<Retour, List<ServiceTechnique>>(retourKo, null);
    creatMockRSTstserviceTechniqueLireTousParPfi(CLIENT_OPERATEUR, NO_COMPTE_SOURCE, "LAC", StringConstants.EMPTY_STRING, rstRetour); //$NON-NLS-1$
    // Run scenario
    PowerMock.replayAll();
    _processInstance.startProcess(request, _tracabilite);
    // Continue Process
    _processInstance.continueProcess(request, _tracabilite);
    PowerMock.verifyAll();
    retourKo = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, LIBELLE_4, null);
    PEP0142_Retour expectedResult = new PEP0142_Retour(RetourConverter.convertToJsonRetour(retourKo));
    String jsonExpectedRetour = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(expectedResult);

    assertEquals(ErrorCode.KO_00400, request.getResponse().getErrorCode());
    assertEquals(jsonExpectedRetour, request.getResponse().getGenericResponse().getResult());
  }

  /**
   * case PEP0142_BL001_VerifierDonnees KO because PEP0142_BL100_CopierPaCompteAccesSecondaire RST Proxy error *
   * "{\"retour\":{\"resultat\":\"KO\",\"categorie\":\"CAT-4\",\"diagnostic\":\"DONNEE_INCONNUE\",\"libelle\":\"Pas de
   * PA CA avec loginmail sur le Pfi NO_COMPTE_CIBLE, La commande ne peut pas être traitée par ce processus\"}}"<br>
   *
   * @throws RavelException
   */
  @Test
  public void PEP0142_CreerCommandeTransfertBoiteMail_KO_008() throws RavelException
  {
    String idCommand = "ID_COMMAND"; //$NON-NLS-1$
    String identFonct = "identifiantFonct"; //$NON-NLS-1$
    Request request = createRequest(idCommand);
    Commande commande = new Commande();
    commande.setStatut(Statut.ACQUITTE.name());
    ServiceMailRequest serviceMailreq = createServiceMailRequest();
    commande.setDonneesBrut(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(serviceMailreq, ServiceMailRequest.class));
    commande.setNoCompte("commandeCompte"); //$NON-NLS-1$
    commande.setClientOperateur(CLIENT_OPERATEUR);

    PFI pfisource = new PFI();
    List<PA> listpa = new ArrayList<>();
    PaTypeCompteAcces paType = new PaTypeCompteAcces("charles.rock"); //$NON-NLS-1$
    paType.setEmailLogin("loginmail"); //$NON-NLS-1$
    PA pat2 = new PA(identFonct, TypePA.COMPTE_ACCES_SECONDAIRE.name(), com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, null, null); // The COMPTE_ACCESS_SECONDAIRE
    PaTypeCompteAccesSecondaire paTypeCompteAccesSecondairet = new PaTypeCompteAccesSecondaire("paSecondaire"); //$NON-NLS-1$
    pat2.setPaTypeCompteAccesSecondaire(paTypeCompteAccesSecondairet);
    pat2.setIdentifiantFonctionnelPALie(identFonct);
    listpa.add(pat2);

    PA pa = new PA(null, "COMPTE_ACCES", com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, null, null); //$NON-NLS-1$
    pa.setPaTypeCompteAcces(paType);
    pa.setIdentifiantFonctionnelPALie(identFonct);
    pa.setIdentifiantFonctionnelPA(identFonct);
    listpa.add(pa);
    pfisource.setPa(listpa);
    pfisource.setClientOperateur(CLIENT_OPERATEUR);
    pfisource.setNoCompte(NO_COMPTE_SOURCE);
    PFI pficible = new PFI();
    listpa = new ArrayList<>();
    paType = new PaTypeCompteAcces("charles.rock"); //$NON-NLS-1$
    paType.setEmailLogin("loginmail"); //$NON-NLS-1$
    pat2 = new PA(identFonct, TypePA.COMPTE_ACCES_SECONDAIRE.name(), com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, null, null); // The COMPTE_ACCESS_SECONDAIRE
    paTypeCompteAccesSecondairet = new PaTypeCompteAccesSecondaire("paSecondaire"); //$NON-NLS-1$
    pat2.setPaTypeCompteAccesSecondaire(paTypeCompteAccesSecondairet);
    pat2.setIdentifiantFonctionnelPALie("identFonctd"); //$NON-NLS-1$
    listpa.add(pat2);

    pa = new PA(null, "COMPTE_ACCES", com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, null, null); //$NON-NLS-1$
    pa.setPaTypeCompteAcces(paType);
    pa.setIdentifiantFonctionnelPALie("identFonctd"); //$NON-NLS-1$
    pa.setIdentifiantFonctionnelPA("identFonctd"); //$NON-NLS-1$
    listpa.add(pa);

    pficible.setPa(listpa);

    ConnectorResponse<Retour, Commande> connectorRep_p = new ConnectorResponse<Retour, Commande>(RetourFactoryForTU.createOkRetour(), commande);
    createMockCMDcommandeLireUn(idCommand, connectorRep_p);

    ConnectorResponse<Retour, PFI> connectorRepRpg = new ConnectorResponse<Retour, PFI>(RetourFactoryForTU.createOkRetour(), pfisource);
    createMockRPGpfiLireUn(CLIENT_OPERATEUR, NO_COMPTE_SOURCE, connectorRepRpg);
    connectorRepRpg = new ConnectorResponse<Retour, PFI>(RetourFactoryForTU.createOkRetour(), pfisource);
    createMockRPGpfiLireUn(CLIENT_OPERATEUR, NO_COMPTE_CIBLE, connectorRepRpg);

    StLienAllocationCommercial stLac = new StLienAllocationCommercial("idST", com.bytel.spirit.common.shared.saab.rst.Statut.ACTIF.name(), CLIENT_OPERATEUR, NO_COMPTE_SOURCE, TypeObjetCommercial.PA.name(), "BSS_GP", "ocNoCompte", "idRessource", TYPE_RESSOURCE_ADRESSE_MAIL); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    stLac.setOcIdentifiantFonctionnelPA(identFonct);
    List<ServiceTechnique> listServiceTechnique1 = new ArrayList<>();
    listServiceTechnique1.add(stLac);

    ConnectorResponse<Retour, List<ServiceTechnique>> rstRetour = new ConnectorResponse<Retour, List<ServiceTechnique>>(RetourFactoryForTU.createOkRetour(), listServiceTechnique1);
    creatMockRSTstserviceTechniqueLireTousParPfi(CLIENT_OPERATEUR, NO_COMPTE_SOURCE, "LAC", StringConstants.EMPTY_STRING, rstRetour); //$NON-NLS-1$
    UpdateStLienAllocationCommercialRequest updateLien = new UpdateStLienAllocationCommercialRequest(CLIENT_OPERATEUR, NO_COMPTE_SOURCE, NO_COMPTE_CIBLE, null);
    Retour retourKo = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, StringConstants.EMPTY_STRING, null);
    ConnectorResponse<Retour, Nothing> connectRep = new ConnectorResponse<Retour, Nothing>(retourKo, null);
    CreateMockRststLienAllocationCommercial(updateLien, connectRep);
    // Run scenario
    PowerMock.replayAll();
    _processInstance.startProcess(request, _tracabilite);
    // Continue Process
    _processInstance.continueProcess(request, _tracabilite);
    PowerMock.verifyAll();
    retourKo = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, StringConstants.EMPTY_STRING, null);
    PEP0142_Retour expectedResult = new PEP0142_Retour(RetourConverter.convertToJsonRetour(retourKo));
    String jsonExpectedRetour = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(expectedResult);

    assertEquals(ErrorCode.KO_00400, request.getResponse().getErrorCode());
    assertEquals(jsonExpectedRetour, request.getResponse().getGenericResponse().getResult());

  }

  /**
   * case PEP0142_BL001_VerifierDonnees KO because PEP0142_BL202_TransfererStPfsMail RST Proxy error *
   * "{\"retour\":{\"resultat\":\"KO\",\"categorie\":\"CAT-4\",\"diagnostic\":\"DONNEE_INCONNUE\",\"libelle\":\"Pas de
   * PA CA avec loginmail sur le Pfi NO_COMPTE_CIBLE, La commande ne peut pas être traitée par ce processus\"}}"<br>
   *
   * @throws RavelException
   */
  @Test
  public void PEP0142_CreerCommandeTransfertBoiteMail_KO_009() throws RavelException
  {
    String idCommand = "ID_COMMAND"; //$NON-NLS-1$
    String identFonct = "identifiantFonct"; //$NON-NLS-1$
    Request request = createRequest(idCommand);
    Commande commande = new Commande();
    commande.setStatut(Statut.ACQUITTE.name());
    ServiceMailRequest serviceMailreq = createServiceMailRequest();
    commande.setDonneesBrut(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(serviceMailreq, ServiceMailRequest.class));
    commande.setNoCompte("commandeCompte"); //$NON-NLS-1$
    commande.setClientOperateur(CLIENT_OPERATEUR);

    PFI pfisource = new PFI();
    List<PA> listpa = new ArrayList<>();
    PaTypeCompteAcces paType = new PaTypeCompteAcces("charles.rock"); //$NON-NLS-1$
    paType.setEmailLogin("loginmail"); //$NON-NLS-1$
    PA pat2 = new PA(identFonct, TypePA.COMPTE_ACCES_SECONDAIRE.name(), com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, null, null); // The COMPTE_ACCESS_SECONDAIRE
    PaTypeCompteAccesSecondaire paTypeCompteAccesSecondairet = new PaTypeCompteAccesSecondaire("paSecondaire"); //$NON-NLS-1$
    pat2.setPaTypeCompteAccesSecondaire(paTypeCompteAccesSecondairet);
    pat2.setIdentifiantFonctionnelPALie(identFonct);
    listpa.add(pat2);

    PA pa = new PA(null, "COMPTE_ACCES", com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, null, null); //$NON-NLS-1$
    pa.setPaTypeCompteAcces(paType);
    pa.setIdentifiantFonctionnelPALie(identFonct);
    pa.setIdentifiantFonctionnelPA(identFonct);
    listpa.add(pa);
    pfisource.setPa(listpa);
    pfisource.setClientOperateur(CLIENT_OPERATEUR);
    pfisource.setNoCompte(NO_COMPTE_SOURCE);
    PFI pficible = new PFI();
    listpa = new ArrayList<>();
    paType = new PaTypeCompteAcces("charles.rock"); //$NON-NLS-1$
    paType.setEmailLogin("loginmail"); //$NON-NLS-1$
    pat2 = new PA(identFonct, TypePA.COMPTE_ACCES_SECONDAIRE.name(), com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, null, null); // The COMPTE_ACCESS_SECONDAIRE
    paTypeCompteAccesSecondairet = new PaTypeCompteAccesSecondaire("paSecondaire"); //$NON-NLS-1$
    pat2.setPaTypeCompteAccesSecondaire(paTypeCompteAccesSecondairet);
    pat2.setIdentifiantFonctionnelPALie("identFonctd"); //$NON-NLS-1$
    listpa.add(pat2);

    pa = new PA(null, "COMPTE_ACCES", com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, null, null); //$NON-NLS-1$
    pa.setPaTypeCompteAcces(paType);
    pa.setIdentifiantFonctionnelPALie("identFonctd"); //$NON-NLS-1$
    pa.setIdentifiantFonctionnelPA("identFonctd"); //$NON-NLS-1$
    listpa.add(pa);

    pficible.setPa(listpa);

    ConnectorResponse<Retour, Commande> connectorRep_p = new ConnectorResponse<Retour, Commande>(RetourFactoryForTU.createOkRetour(), commande);
    createMockCMDcommandeLireUn(idCommand, connectorRep_p);

    ConnectorResponse<Retour, PFI> connectorRepRpg = new ConnectorResponse<Retour, PFI>(RetourFactoryForTU.createOkRetour(), pfisource);
    createMockRPGpfiLireUn(CLIENT_OPERATEUR, NO_COMPTE_SOURCE, connectorRepRpg);
    connectorRepRpg = new ConnectorResponse<Retour, PFI>(RetourFactoryForTU.createOkRetour(), pfisource);
    createMockRPGpfiLireUn(CLIENT_OPERATEUR, NO_COMPTE_CIBLE, connectorRepRpg);
    StLienAllocationCommercial stLac = new StLienAllocationCommercial("idST", com.bytel.spirit.common.shared.saab.rst.Statut.ACTIF.name(), CLIENT_OPERATEUR, NO_COMPTE_SOURCE, TypeObjetCommercial.PA.name(), "BSS_GP", "ocNoCompte", "idRessource", TYPE_RESSOURCE_ADRESSE_MAIL); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    stLac.setOcIdentifiantFonctionnelPA(identFonct);
    List<ServiceTechnique> listServiceTechnique1 = new ArrayList<>();
    listServiceTechnique1.add(stLac);

    ConnectorResponse<Retour, List<ServiceTechnique>> rstRetour = new ConnectorResponse<Retour, List<ServiceTechnique>>(RetourFactoryForTU.createOkRetour(), listServiceTechnique1);
    creatMockRSTstserviceTechniqueLireTousParPfi(CLIENT_OPERATEUR, NO_COMPTE_SOURCE, "LAC", StringConstants.EMPTY_STRING, rstRetour); //$NON-NLS-1$
    List<String> list = new ArrayList<>();
    list.add("idSt"); //$NON-NLS-1$
    UpdateStLienAllocationCommercialRequest updateLien = new UpdateStLienAllocationCommercialRequest(CLIENT_OPERATEUR, NO_COMPTE_SOURCE, NO_COMPTE_CIBLE, list);
    ConnectorResponse<Retour, Nothing> connectRep = new ConnectorResponse<Retour, Nothing>(RetourFactoryForTU.createOkRetour(), null);
    CreateMockRststLienAllocationCommercial(updateLien, connectRep);
    Retour retourKo = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, StringConstants.EMPTY_STRING, null);
    rstRetour = new ConnectorResponse<Retour, List<ServiceTechnique>>(retourKo, null);
    creatMockRSTstserviceTechniqueLireTousParPfi(CLIENT_OPERATEUR, NO_COMPTE_SOURCE, TypeST.PFS.name(), TypePFS.MAIL.name(), rstRetour);

    // Run scenario
    PowerMock.replayAll();
    _processInstance.startProcess(request, _tracabilite);
    // Continue Process
    _processInstance.continueProcess(request, _tracabilite);
    PowerMock.verifyAll();
    retourKo = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, StringConstants.EMPTY_STRING, null);
    PEP0142_Retour expectedResult = new PEP0142_Retour(RetourConverter.convertToJsonRetour(retourKo));
    String jsonExpectedRetour = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(expectedResult);

    assertEquals(ErrorCode.KO_00400, request.getResponse().getErrorCode());
    assertEquals(jsonExpectedRetour, request.getResponse().getGenericResponse().getResult());

  }

  /**
   * case PEP0142_CreerCommandeTransfertBoiteMail Nominal
   * "{\"retour\":{\"resultat\":\"KO\",\"categorie\":\"CAT-4\",\"diagnostic\":\"DONNEE_INCONNUE\",\"libelle\":\"Pas de
   * PA CA avec loginmail sur le Pfi NO_COMPTE_CIBLE, La commande ne peut pas être traitée par ce processus\"}}"<br>
   *
   * @throws RavelException
   */
  @Test
  public void PEP0142_CreerCommandeTransfertBoiteMail_Nominal_OK() throws RavelException
  {
    String idCommand = "ID_COMMAND"; //$NON-NLS-1$
    String identFonct = "identifiantFonct"; //$NON-NLS-1$
    Request request = createRequest(idCommand);
    Commande commande = new Commande();
    commande.setStatut(Statut.ACQUITTE.name());
    ServiceMailRequest serviceMailreq = createServiceMailRequest();
    commande.setDonneesBrut(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(serviceMailreq, ServiceMailRequest.class));
    commande.setNoCompte("commandeCompte"); //$NON-NLS-1$
    commande.setClientOperateur(CLIENT_OPERATEUR);

    PFI pfisource = new PFI();
    List<PA> listpa = new ArrayList<>();
    PaTypeCompteAcces paType = new PaTypeCompteAcces("charles.rock"); //$NON-NLS-1$
    paType.setEmailLogin("loginmail"); //$NON-NLS-1$
    PA pat2 = new PA(identFonct, TypePA.COMPTE_ACCES_SECONDAIRE.name(), com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, null, null); // The COMPTE_ACCESS_SECONDAIRE
    pat2.setPaTypeCompteAcces(paType);
    PaTypeCompteAccesSecondaire paTypeCompteAccesSecondairet = new PaTypeCompteAccesSecondaire("paSecondaire"); //$NON-NLS-1$
    pat2.setPaTypeCompteAccesSecondaire(paTypeCompteAccesSecondairet);
    pat2.setIdentifiantFonctionnelPALie(identFonct);
    listpa.add(pat2);

    PA pa = new PA(null, "COMPTE_ACCES", com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, null, null); //$NON-NLS-1$
    pa.setPaTypeCompteAcces(paType);
    pa.setIdentifiantFonctionnelPALie(identFonct);
    pa.setIdentifiantFonctionnelPA(identFonct);
    listpa.add(pa);
    pfisource.setPa(listpa);
    pfisource.setClientOperateur(CLIENT_OPERATEUR);
    pfisource.setNoCompte(NO_COMPTE_SOURCE);
    PFI pficible = new PFI();
    listpa = new ArrayList<>();
    paType = new PaTypeCompteAcces("charles.rock"); //$NON-NLS-1$
    paType.setEmailLogin("loginmail"); //$NON-NLS-1$
    pat2 = new PA(identFonct, TypePA.COMPTE_ACCES_SECONDAIRE.name(), com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, null, null); // The COMPTE_ACCESS_SECONDAIRE
    paTypeCompteAccesSecondairet = new PaTypeCompteAccesSecondaire("paSecondaire"); //$NON-NLS-1$
    pat2.setPaTypeCompteAccesSecondaire(paTypeCompteAccesSecondairet);
    pat2.setIdentifiantFonctionnelPALie("identFonctd"); //$NON-NLS-1$
    listpa.add(pat2);

    pa = new PA(null, "COMPTE_ACCES", com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, null, null); //$NON-NLS-1$
    pa.setPaTypeCompteAcces(paType);
    pa.setIdentifiantFonctionnelPALie("identFonctd"); //$NON-NLS-1$
    pa.setIdentifiantFonctionnelPA("identFonctd"); //$NON-NLS-1$
    listpa.add(pa);

    pficible.setPa(listpa);

    ConnectorResponse<Retour, Commande> connectorRep_p = new ConnectorResponse<Retour, Commande>(RetourFactoryForTU.createOkRetour(), commande);
    createMockCMDcommandeLireUn(idCommand, connectorRep_p);

    ConnectorResponse<Retour, PFI> connectorRepRpg = new ConnectorResponse<Retour, PFI>(RetourFactoryForTU.createOkRetour(), pfisource);
    createMockRPGpfiLireUn(CLIENT_OPERATEUR, NO_COMPTE_SOURCE, connectorRepRpg);
    connectorRepRpg = new ConnectorResponse<Retour, PFI>(RetourFactoryForTU.createOkRetour(), pfisource);
    createMockRPGpfiLireUn(CLIENT_OPERATEUR, NO_COMPTE_CIBLE, connectorRepRpg);

    StLienAllocationCommercial stLac = new StLienAllocationCommercial("idST", com.bytel.spirit.common.shared.saab.rst.Statut.ACTIF.name(), CLIENT_OPERATEUR, NO_COMPTE_SOURCE, TypeObjetCommercial.PA.name(), "BSS_GP", "ocNoCompte", "idRessource", TYPE_RESSOURCE_ADRESSE_MAIL); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    stLac.setOcIdentifiantFonctionnelPA(identFonct);
    List<ServiceTechnique> listServiceTechnique1 = new ArrayList<>();
    listServiceTechnique1.add(stLac);

    ConnectorResponse<Retour, List<ServiceTechnique>> rstRetour = new ConnectorResponse<Retour, List<ServiceTechnique>>(RetourFactoryForTU.createOkRetour(), listServiceTechnique1);
    creatMockRSTstserviceTechniqueLireTousParPfi(CLIENT_OPERATEUR, NO_COMPTE_SOURCE, "LAC", StringConstants.EMPTY_STRING, rstRetour); //$NON-NLS-1$
    List<String> list = new ArrayList<>();
    list.add("idSt"); //$NON-NLS-1$
    UpdateStLienAllocationCommercialRequest updateLien = new UpdateStLienAllocationCommercialRequest(CLIENT_OPERATEUR, NO_COMPTE_SOURCE, NO_COMPTE_CIBLE, list);
    ConnectorResponse<Retour, Nothing> connectRepRst = new ConnectorResponse<Retour, Nothing>(RetourFactoryForTU.createOkRetour(), null);
    CreateMockRststLienAllocationCommercial(updateLien, connectRepRst);

    listServiceTechnique1 = new ArrayList<>();

    StPfsMail stPfsMail = __podam.manufacturePojoWithFullData(StPfsMail.class);
    stPfsMail.setDonneesIdentificationStPfsMail(new DonneesIdentificationSTPfsMail("SECONDAIRE", "idCompteMail")); //$NON-NLS-1$ //$NON-NLS-2$
    stPfsMail.setDonneesProvisionneesStPfsMail(new DonneesProvisionneesSTPfsMail("paSecondaire", 23, 128, "TOP")); //$NON-NLS-1$ //$NON-NLS-2$
    stPfsMail.setTypeServiceTechnique(TypeST.PFS.name());
    stPfsMail.setTypePfs(TypePFS.MAIL.name());
    listServiceTechnique1.add(stPfsMail);

    rstRetour = new ConnectorResponse<Retour, List<ServiceTechnique>>(RetourFactoryForTU.createOkRetour(), listServiceTechnique1);
    creatMockRSTstserviceTechniqueLireTousParPfi(CLIENT_OPERATEUR, NO_COMPTE_SOURCE, TypeST.PFS.name(), TypePFS.MAIL.name(), rstRetour);

    Retour retourKo = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, StringConstants.EMPTY_STRING, null);
    connectRepRst = new ConnectorResponse<Retour, Nothing>(RetourFactoryForTU.createOkRetour(), null);

    UpdateStPfsRequest updateStpfsRequest = new UpdateStPfsRequest(CLIENT_OPERATEUR, NO_COMPTE_SOURCE, NO_COMPTE_SOURCE, list);
    CreateMockRSTstLienAllocCommercialGererModifPfiAssocie(updateStpfsRequest, connectRepRst);
    creatMockRSTstserviceTechniqueLireTousParPfi(CLIENT_OPERATEUR, NO_COMPTE_SOURCE, "LAC", StringConstants.EMPTY_STRING, rstRetour); //$NON-NLS-1$
    retourKo = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.DONNEE_INVALIDE, "", null); //$NON-NLS-1$
    ConnectorResponse<Retour, Nothing> connectRpg = new ConnectorResponse<Retour, Nothing>(RetourFactoryForTU.createOkRetour(), null);
    createMockRPGpfiEcrire(connectRpg);
    connectRpg = new ConnectorResponse<Retour, Nothing>(RetourFactoryForTU.createOkRetour(), null);
    createMockRPGpfiEcrire(connectRpg);

    //Build list of CleRecherche to return in response of AIR
    List<IndexRecherchePfi> listindex = new ArrayList<>();
    IndexRecherchePfi indexRecherche = new IndexRecherchePfi(CLIENT_OPERATEUR, NO_COMPTE_SOURCE);
    List<CleRecherche> listCle = new ArrayList<>();
    CleRecherche clerecherche = new CleRecherche(TYPE_RESSOURCE_ADRESSE_MAIL, "toKeep"); //$NON-NLS-1$
    listCle.add(clerecherche);
    CleRecherche clerecherche2 = new CleRecherche(TYPE_RESSOURCE_ADRESSE_MAIL, "paSecondaire"); //$NON-NLS-1$
    listCle.add(clerecherche2);

    indexRecherche.setListeCleRecherche(listCle);
    listindex.add(indexRecherche);

    indexRecherche = new IndexRecherchePfi(CLIENT_OPERATEUR, NO_COMPTE_SOURCE);
    listindex.add(indexRecherche);
    ConnectorResponse<Retour, List<IndexRecherchePfi>> connectorRepAir = new ConnectorResponse<Retour, List<IndexRecherchePfi>>(RetourFactoryForTU.createOkRetour(), listindex);
    creatMockAIRindexRechercherPfiLireUn(CLIENT_OPERATEUR, NO_COMPTE_SOURCE, connectorRepAir);
    ConnectorResponse<Retour, Nothing> connectRep = new ConnectorResponse<Retour, Nothing>(RetourFactoryForTU.createOkRetour(), null);
    creatMockAIRindexRechercherPfiEcrire(connectRep);
    ConnectorResponse<Retour, Nothing> connectorRepCmd = new ConnectorResponse<Retour, Nothing>(RetourFactoryForTU.createOkRetour(), null);
    creatMockCmdcommandeModifierStatut(idCommand, Statut.EN_COURS.name(), null, null, null, connectorRepCmd);

    // Run scenario
    PowerMock.replayAll();
    _processInstance.startProcess(request, _tracabilite);
    // Continue Process
    _processInstance.continueProcess(request, _tracabilite);
    PowerMock.verifyAll();
    Retour retouroK = RetourFactoryForTU.createOkRetour();
    PEP0142_Retour expectedResult = new PEP0142_Retour(RetourConverter.convertToJsonRetour(retouroK));
    String jsonExpectedRetour = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(expectedResult);

    assertEquals(ErrorCode.OK_00200, request.getResponse().getErrorCode());

  }

  /**
   *
   */
  @Before
  public void setUp()
  {
    _processInstance = new PEP0142_CreerCommandeTransfertBoiteMailSecondaire();
    _processInstance.initializeContext();

    _tracabilite = new Tracabilite();
    _tracabilite.setIdCorrelationByTel(StringConstants.EMPTY_STRING);
    _tracabilite.setIdProcessusSpirit(_processInstance.getIdProcess());
    _tracabilite.setIdCorrelationSpirit(Test_Consts.DEFAULT_MSGID);
    _tracabilite.setNomProcessus(StringConstants.EMPTY_STRING);
    _tracabilite.setNomSysteme(System.getenv("SERVICE")); //$NON-NLS-1$

    ProcessManager.getInstance().getProcessParams().clear();

    // on réinitialise tous les mocks afin de ne pas avoir d'interférence entre les tests
    PowerMock.resetAll();
    PowerMock.mockStatic(CMDProxy.class);
    PowerMock.mockStatic(RPGProxy.class);
    PowerMock.mockStatic(RSTProxy.class);
    PowerMock.mockStatic(AIRProxy.class);
  }

  /**
   * create mock for CMDProxy commandeLireUn
   *
   * @param idCmd_p
   *          idcomand
   * @param connectorRep_p
   *          rep connector
   * @throws RavelException
   */
  private void createMockCMDcommandeLireUn(String idCmd_p, ConnectorResponse<Retour, Commande> connectorRep_p) throws RavelException
  {
    EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdProxy);
    EasyMock.expect(_cmdProxy.commandeLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(idCmd_p))).andReturn(connectorRep_p);
  }

  /**
   * create mock RPGPRoxy
   *
   * @param connectorRep_p
   *          rep connecteur
   * @throws RavelException
   */
  private void createMockRPGpfiEcrire(ConnectorResponse<Retour, Nothing> connectorRep_p) throws RavelException
  {
    EasyMock.expect(RPGProxy.getInstance()).andReturn(_rpgProxy);
    EasyMock.expect(_rpgProxy.pfiEcrire(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(CreatePfiRequest.class))).andReturn(connectorRep_p);
  }

  /**
   * create mock RPGPRoxy
   *
   * @param clientOperateur_p
   *          client operateur
   * @param noCompte_p
   *          no compte
   * @param connectorRep_p
   *          rep connecteur
   * @throws RavelException
   */
  private void createMockRPGpfiLireUn(String clientOperateur_p, String noCompte_p, ConnectorResponse<Retour, PFI> connectorRep_p) throws RavelException
  {
    EasyMock.expect(RPGProxy.getInstance()).andReturn(_rpgProxy);
    EasyMock.expect(_rpgProxy.pfiLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(clientOperateur_p), EasyMock.eq(noCompte_p))).andReturn(connectorRep_p);
  }

  /**
   * @param updateSt
   * @param connectRep
   * @throws RavelException
   */
  private void CreateMockRststLienAllocationCommercial(UpdateStLienAllocationCommercialRequest updateSt, ConnectorResponse<Retour, Nothing> connectRep) throws RavelException
  {

    EasyMock.expect(RSTProxy.getInstance()).andReturn(_rstProxy);
    EasyMock.expect(_rstProxy.stLienAllocationCommercialGererModifPfiAssocie(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(UpdateStLienAllocationCommercialRequest.class))).andReturn(connectRep);

  }

  /**
   * CreateMockRSTstLienAllocCommercialGererModifPfiAssocie
   *
   * @param updateSt
   *          updateStpfs
   * @param connectRep
   *          connector Rep
   * @throws RavelException
   */
  private void CreateMockRSTstLienAllocCommercialGererModifPfiAssocie(UpdateStPfsRequest updateSt, ConnectorResponse<Retour, Nothing> connectRep) throws RavelException
  {

    EasyMock.expect(RSTProxy.getInstance()).andReturn(_rstProxy);
    EasyMock.expect(_rstProxy.stPfsGererModifPfiAssocie(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(UpdateStPfsRequest.class))).andReturn(connectRep);

  }

  /**
   * Used to create a new Request for the process
   *
   * @param idCmd_p
   *          The command idà
   * @return {@link Request}
   */
  private Request createRequest(String idCmd_p)
  {
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    request.setHttpMethod("POST"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    CommandeId command = new CommandeId(idCmd_p);
    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(command, CommandeId.class);
    request.setPayload(jSonRequest);

    return request;
  }

  private ServiceMailRequest createServiceMailRequest()
  {

    ServiceMailRequest serviceMailRequest = new ServiceMailRequest();
    IdentifiantAcces identifiantAcces = new IdentifiantAcces();
    identifiantAcces.setLoginMail("loginmail"); //$NON-NLS-1$
    serviceMailRequest.setIdentifiantAccesCible(identifiantAcces);

    identifiantAcces = new IdentifiantAcces();
    identifiantAcces.setLoginMail("loginmail"); //$NON-NLS-1$
    serviceMailRequest.setIdentifiantAccesSource(identifiantAcces);

    PortefeuilleServices portefeuilleServices = new PortefeuilleServices();
    portefeuilleServices.setNoCompte("NO_COMPTE_CIBLE"); //$NON-NLS-1$
    serviceMailRequest.setPortefeuilleServicesCible(portefeuilleServices);

    portefeuilleServices = new PortefeuilleServices();
    portefeuilleServices.setNoCompte("NO_COMPTE_SOURCE"); //$NON-NLS-1$
    serviceMailRequest.setPortefeuilleServicesSource(portefeuilleServices);

    return serviceMailRequest;
  }

  /**
   * createMock AIRProxy indexRechercherPfiEcrire
   *
   * @param connectrep_p
   *          connectrep
   * @throws RavelException
   *           exception
   */
  private void creatMockAIRindexRechercherPfiEcrire(ConnectorResponse<Retour, Nothing> connectrep_p) throws RavelException
  {
    EasyMock.expect(AIRProxy.getInstance()).andReturn(_airProxy);
    EasyMock.expect(_airProxy.indexRechercherPfiEcrire(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(CreateIndexRecherchePfiRequest.class))).andReturn(connectrep_p);

  }

  /**
   * createMock AIRProxy indexRechercherPfiLireUn
   *
   * @param clientOperateur_p
   *          client
   * @param noCompte_p
   *          compte
   * @param connectrep_p
   *          connecteRep
   * @throws RavelException
   */
  private void creatMockAIRindexRechercherPfiLireUn(String clientOperateur_p, String noCompte_p, ConnectorResponse<Retour, List<IndexRecherchePfi>> connectrep_p) throws RavelException
  {
    EasyMock.expect(AIRProxy.getInstance()).andReturn(_airProxy);
    EasyMock.expect(_airProxy.indexRechercherPfiLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(String.class), EasyMock.anyObject(String.class))).andReturn(connectrep_p);
  }

  /**
   *
   * create Mock creatMockCmdcommandeModifierStatut
   *
   * @param idCmd_p
   * @param statutCmd_p
   * @param mailstat
   * @param info
   * @param connectRep
   * @throws RavelException
   */
  private void creatMockCmdcommandeModifierStatut(String idCmd_p, String statutCmd_p, String mailstat, String type, String info, ConnectorResponse<Retour, Nothing> connectRep) throws RavelException
  {
    EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdProxy);
    EasyMock.expect(_cmdProxy.commandeModifierStatut(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(idCmd_p), EasyMock.eq(statutCmd_p), EasyMock.eq(type), EasyMock.eq(info))).andReturn(connectRep);
  }

  /**
   * create Mock RstserviceTechniqueLireTousParPfi
   *
   * @param client_op
   * @param comptesource_p
   * @param type_p
   * @param info_p
   * @param rstRetour
   * @throws RavelException
   */
  private void creatMockRSTstserviceTechniqueLireTousParPfi(String client_op, String comptesource_p, String type_p, String info_p, ConnectorResponse<Retour, List<ServiceTechnique>> rstRetour) throws RavelException
  {

    EasyMock.expect(RSTProxy.getInstance()).andReturn(_rstProxy);
    EasyMock.expect(_rstProxy.serviceTechniqueLireTousParPfi(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(client_op), EasyMock.eq(comptesource_p), EasyMock.eq(type_p), EasyMock.eq(info_p))).andReturn(rstRetour);

  }

}
