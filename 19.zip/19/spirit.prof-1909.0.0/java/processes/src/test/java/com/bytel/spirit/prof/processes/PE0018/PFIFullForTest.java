/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PE0018;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;

import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.spirit.common.shared.saab.cmd.Commande;
import com.bytel.spirit.prof.shared.types.abstracts.sti0017.AbstractPointAcces;
import com.bytel.spirit.prof.shared.types.json.AccesTechnique;
import com.bytel.spirit.prof.shared.types.json.AdresseInstallation;
import com.bytel.spirit.prof.shared.types.json.ClientTitulaire;
import com.bytel.spirit.prof.shared.types.json.CompteTv;
import com.bytel.spirit.prof.shared.types.json.DemandePortage;
import com.bytel.spirit.prof.shared.types.json.Entreprise;
import com.bytel.spirit.prof.shared.types.json.EquipementFixe;
import com.bytel.spirit.prof.shared.types.json.IdentifiantAcces;
import com.bytel.spirit.prof.shared.types.json.IdentifiantContenu;
import com.bytel.spirit.prof.shared.types.json.Individu;
import com.bytel.spirit.prof.shared.types.json.NumeroFax;
import com.bytel.spirit.prof.shared.types.json.NumeroVoip;
import com.bytel.spirit.prof.shared.types.json.OneBoxIAD;
import com.bytel.spirit.prof.shared.types.json.OneBoxSTB;
import com.bytel.spirit.prof.shared.types.json.PhotoPfi;
import com.bytel.spirit.prof.shared.types.json.PointAccesCompteAcces;
import com.bytel.spirit.prof.shared.types.json.PointAccesFax;
import com.bytel.spirit.prof.shared.types.json.PointAccesLigneFixe;
import com.bytel.spirit.prof.shared.types.json.PointAccesTV;
import com.bytel.spirit.prof.shared.types.json.PointAccesVoip;
import com.bytel.spirit.prof.shared.types.json.PortTelephonique;
import com.bytel.spirit.prof.shared.types.json.Raccordement;
import com.bytel.spirit.prof.shared.types.json.RendezVous;
import com.bytel.spirit.prof.shared.types.json.ServiceAccessible;

/**
 *
 * @author jsantos
 * @version ($Revision$ $Date$)
 */
public class PFIFullForTest
{
  /**
   * The INDIVIDU
   */
  public static final String INDIVIDU = "INDIVIDU"; //$NON-NLS-1$

  /**
   * The ENTREPRISE
   */
  public static final String ENTREPRISE = "ENTREPRISE"; //$NON-NLS-1$

  //Dados que têm de ser conhecidos para linkar as listagens
  /**
   * noServiceCommercialConnu
   */
  private String _noServiceCommercialConnu;

  /**
   * pointAccesConnu
   */
  private String _pointAccesConnu;

  /**
   * pointAccesEquipement
   */
  private String _pointAccesEquipement;

  /**
   * noEquipement
   */
  private String _noEquipement;

  /**
   * commande
   */
  private Commande _commande = new Commande();

  /**
   * Default constructor
   */
  public PFIFullForTest()
  {
    buildCommande(INDIVIDU);
  }

  /**
   * Build a AccesTechnique
   *
   * @return The AccesTechnique
   */
  public AccesTechnique buildAccesTechnique()
  {
    AccesTechnique accesTechnique = new AccesTechnique();
    accesTechnique.setTechnologieAcces(RandomStringUtils.random(10));
    accesTechnique.setIdProfilTechnique(RandomStringUtils.random(10));
    accesTechnique.setIdOperateurCollecte(RandomStringUtils.random(10));
    accesTechnique.setCodeOperateurImmeuble(RandomStringUtils.random(10));
    accesTechnique.setTypeDeGroupage(RandomStringUtils.random(10));
    return accesTechnique;
  }

  /**
   * Build a AccesTechniqueV1
   *
   * @return The AccesTechniqueV1
   */
  public com.bytel.spirit.prof.shared.types.json.sti0017.AccesTechnique buildAccesTechniqueV1()
  {
    com.bytel.spirit.prof.shared.types.json.sti0017.AccesTechnique accesTechnique = new com.bytel.spirit.prof.shared.types.json.sti0017.AccesTechnique();
    accesTechnique.setTechnologieAcces(RandomStringUtils.random(10));
    accesTechnique.setIdProfilTechnique(RandomStringUtils.random(10));
    accesTechnique.setIdOperateurCollecte(RandomStringUtils.random(10));
    accesTechnique.setCodeOperateurImmeuble(RandomStringUtils.random(10));
    accesTechnique.setTypeDeGroupage(RandomStringUtils.random(10));
    return accesTechnique;
  }

  /**
   * Build a AdresseInstallation
   *
   * @return The AdresseInstallation
   */
  public AdresseInstallation buildAdresseInstallation()
  {
    AdresseInstallation adresseInstallation = new AdresseInstallation();
    adresseInstallation.setNumero(RandomStringUtils.random(10));
    adresseInstallation.setIndiceRepetition(RandomStringUtils.random(10));
    adresseInstallation.setNomVoie(RandomStringUtils.random(10));
    adresseInstallation.setCodePostal(RandomStringUtils.random(10));
    adresseInstallation.setVille(RandomStringUtils.random(10));
    adresseInstallation.setCodeInsee(RandomStringUtils.random(10));
    adresseInstallation.setCodeRivoli(RandomStringUtils.random(10));
    adresseInstallation.setPorte(RandomStringUtils.random(10));
    adresseInstallation.setLogo(RandomStringUtils.random(10));
    adresseInstallation.setBatiment(RandomStringUtils.random(10));
    adresseInstallation.setEscalier(RandomStringUtils.random(10));
    adresseInstallation.setEtage(RandomStringUtils.random(10));
    adresseInstallation.setPrecedentProprietaire(RandomStringUtils.random(10));
    adresseInstallation.setHexacle(RandomStringUtils.random(10));
    return adresseInstallation;
  }

  /**
   * Build a AdresseInstallationV1
   *
   * @return The AdresseInstallationV1
   */
  public com.bytel.spirit.prof.shared.types.json.sti0017.AdresseInstallation buildAdresseInstallationV1()
  {
    com.bytel.spirit.prof.shared.types.json.sti0017.AdresseInstallation adresseInstallation = new com.bytel.spirit.prof.shared.types.json.sti0017.AdresseInstallation();
    adresseInstallation.setNumero(RandomStringUtils.random(10));
    adresseInstallation.setIndiceRepetition(RandomStringUtils.random(10));
    adresseInstallation.setNomVoie(RandomStringUtils.random(10));
    adresseInstallation.setCodePostal(RandomStringUtils.random(10));
    adresseInstallation.setVille(RandomStringUtils.random(10));
    adresseInstallation.setCodeInsee(RandomStringUtils.random(10));
    adresseInstallation.setCodeRivoli(RandomStringUtils.random(10));
    adresseInstallation.setPorte(RandomStringUtils.random(10));
    adresseInstallation.setLogo(RandomStringUtils.random(10));
    adresseInstallation.setBatiment(RandomStringUtils.random(10));
    adresseInstallation.setEscalier(RandomStringUtils.random(10));
    adresseInstallation.setEtage(RandomStringUtils.random(10));
    adresseInstallation.setPrecedentProprietaire(RandomStringUtils.random(10));
    adresseInstallation.setHexacle(RandomStringUtils.random(10));
    return adresseInstallation;
  }

  /**
   * Build ClientTitulaire
   *
   * @param typeTitulaire_p
   *          The titulaire type
   * @return The ClienteTitulaire
   */
  public ClientTitulaire buildClientTitulaire(String typeTitulaire_p)
  {
    ClientTitulaire clientTitulaire = new ClientTitulaire();
    clientTitulaire.setNoPersonne(RandomStringUtils.random(10));
    clientTitulaire.setNoTel(RandomStringUtils.random(10));
    clientTitulaire.setEmail(RandomStringUtils.random(10));
    switch (typeTitulaire_p)
    {
      case INDIVIDU:
        clientTitulaire.setIndividu(buildIndividu());
        break;
      case ENTREPRISE:
        clientTitulaire.setEntreprise(buildEntreprise());
        break;
    }
    return clientTitulaire;
  }

  /**
   * Build ClientTitulaireV1
   *
   * @param typeTitulaire_p
   *          The titulaire type
   * @return The ClientTitulaireV1
   */
  public com.bytel.spirit.prof.shared.types.json.sti0017.ClientTitulaire buildClientTitulaireV1(String typeTitulaire_p)
  {
    com.bytel.spirit.prof.shared.types.json.sti0017.ClientTitulaire clientTitulaire = new com.bytel.spirit.prof.shared.types.json.sti0017.ClientTitulaire();
    clientTitulaire.setNoPersonne(RandomStringUtils.random(10));
    clientTitulaire.setNoTel(RandomStringUtils.random(10));
    clientTitulaire.setEmail(RandomStringUtils.random(10));
    switch (typeTitulaire_p)
    {
      case INDIVIDU:
        clientTitulaire.setIndividu(buildIndividuV1());
        break;
      case ENTREPRISE:
        clientTitulaire.setEntreprise(buildEntrepriseV1());
        break;
    }
    return clientTitulaire;
  }

  /**
   * Build a Commande
   *
   * @param typeTitulaire
   *          The titulaire type
   */
  public void buildCommande(String typeTitulaire)
  {
    _commande.setClientOperateur(RandomStringUtils.random(20));
    _commande.setNoCompte(RandomStringUtils.random(20));
    _commande.setStatut("ACTIF"); //$NON-NLS-1$

    _commande.setDonneesBrut(GsonTools.getIso8601Ms().toJson(buildPhotoPfi(typeTitulaire)));
  }

  /**
   * Build an Entreprise
   *
   * @return The Entreprise
   */
  public Entreprise buildEntreprise()
  {
    Entreprise entreprise = new Entreprise();
    entreprise.setIndividu(buildIndividu());
    entreprise.setSiren(RandomStringUtils.random(10));
    entreprise.setRaisonSociale(RandomStringUtils.random(20));
    return entreprise;
  }

  /**
   * Build an Entreprise
   *
   * @return The Entreprise
   */
  public com.bytel.spirit.prof.shared.types.json.sti0017.Entreprise buildEntrepriseV1()
  {
    com.bytel.spirit.prof.shared.types.json.sti0017.Entreprise entreprise = new com.bytel.spirit.prof.shared.types.json.sti0017.Entreprise();
    entreprise.setIndividu(buildIndividuV1());
    entreprise.setSiren(RandomStringUtils.random(10));
    entreprise.setRaisonSociale(RandomStringUtils.random(20));
    return entreprise;
  }

  /**
   * Build a list of EquipementFixe
   *
   * @return The list
   */
  public List<EquipementFixe> buildEquipementFixe()
  {
    List<EquipementFixe> equipementFixes = new ArrayList<>();
    EquipementFixe equipementFixe = new EquipementFixe();
    _noEquipement = RandomStringUtils.random(10);
    equipementFixe.setNoEquipement(_noEquipement);
    equipementFixe.setNoIdentifiant(RandomStringUtils.random(10));
    equipementFixe.setTypeEquipement(RandomStringUtils.random(10));
    equipementFixe.setModeleEquipement(RandomStringUtils.random(10));
    equipementFixe.setNomFabricant(RandomStringUtils.random(10));
    equipementFixe.setMacAdressModem(RandomStringUtils.random(10));
    equipementFixe.setMacAdressMta(RandomStringUtils.random(10));
    equipementFixe.setMacAdressGateway(RandomStringUtils.random(10));
    equipementFixe.setMacAdressTV(RandomStringUtils.random(10));
    equipementFixe.setGencod(RandomStringUtils.random(10));
    equipementFixe.setNoEquipementLie(RandomStringUtils.random(10));
    OneBoxIAD oneBoxIAD = new OneBoxIAD();
    oneBoxIAD.setModeleEquipementIAD(RandomStringUtils.random(10));
    oneBoxIAD.setNoIdentifiantIAD(RandomStringUtils.random(10));
    equipementFixe.setOneBoxIAD(oneBoxIAD);
    OneBoxSTB oneBoxSTB = new OneBoxSTB();
    oneBoxSTB.setModeleEquipementSTB(RandomStringUtils.random(10));
    oneBoxSTB.setNoIdentifiantSTB(RandomStringUtils.random(10));
    equipementFixe.setOneBoxSTB(oneBoxSTB);
    equipementFixes.add(equipementFixe);
    return equipementFixes;
  }

  /**
   * Build a list of EquipementFixe
   *
   * @return The list
   */
  public List<com.bytel.spirit.prof.shared.types.json.sti0017.EquipementFixe> buildEquipementFixeV1()
  {
    List<com.bytel.spirit.prof.shared.types.json.sti0017.EquipementFixe> equipementFixes = new ArrayList<>();
    com.bytel.spirit.prof.shared.types.json.sti0017.EquipementFixe equipementFixe = new com.bytel.spirit.prof.shared.types.json.sti0017.EquipementFixe();
    _noEquipement = RandomStringUtils.random(10);
    equipementFixe.setNoEquipement(_noEquipement);
    equipementFixe.setNoIdentifiant(RandomStringUtils.random(10));
    equipementFixe.setTypeEquipement(RandomStringUtils.random(10));
    equipementFixe.setModeleEquipement(RandomStringUtils.random(10));
    equipementFixe.setNomFabricant(RandomStringUtils.random(10));
    equipementFixe.setMacAdressModem(RandomStringUtils.random(10));
    equipementFixe.setMacAdressMta(RandomStringUtils.random(10));
    equipementFixe.setMacAdressGateway(RandomStringUtils.random(10));
    equipementFixe.setMacAdressTV(RandomStringUtils.random(10));
    equipementFixe.setGencod(RandomStringUtils.random(10));
    equipementFixe.setNoEquipementLie(RandomStringUtils.random(10));
    com.bytel.spirit.prof.shared.types.json.sti0017.OneBoxIAD oneBoxIAD = new com.bytel.spirit.prof.shared.types.json.sti0017.OneBoxIAD();
    oneBoxIAD.setModeleEquipementIAD(RandomStringUtils.random(10));
    oneBoxIAD.setNoIdentifiantIAD(RandomStringUtils.random(10));
    equipementFixe.setOneBoxIAD(oneBoxIAD);
    com.bytel.spirit.prof.shared.types.json.sti0017.OneBoxSTB oneBoxSTB = new com.bytel.spirit.prof.shared.types.json.sti0017.OneBoxSTB();
    oneBoxSTB.setModeleEquipementSTB(RandomStringUtils.random(10));
    oneBoxSTB.setNoIdentifiantSTB(RandomStringUtils.random(10));
    equipementFixe.setOneBoxSTB(oneBoxSTB);
    equipementFixes.add(equipementFixe);
    return equipementFixes;
  }

  /**
   * Build an IdentifiantAcces
   *
   * @return The IdentifiantAcces
   */
  public IdentifiantAcces buildIdentifiantAcces()
  {
    IdentifiantAcces identifiantAcces = new IdentifiantAcces();
    identifiantAcces.setLogin(RandomStringUtils.random(32, "abcdefghijklmnopqrstuvwxyz_-.0123456789")); //$NON-NLS-1$
    return identifiantAcces;
  }

  /**
   * Build an Individu
   *
   * @return The Individu
   */
  public Individu buildIndividu()
  {
    Individu individu = new Individu();
    individu.setCivilite(RandomStringUtils.random(5));
    individu.setNom(RandomStringUtils.random(10));
    individu.setPrenom(RandomStringUtils.random(10));
    return individu;
  }

  /**
   * Build an IndividuV1
   *
   * @return The IndividuV1
   */
  public com.bytel.spirit.prof.shared.types.json.sti0017.Individu buildIndividuV1()
  {
    com.bytel.spirit.prof.shared.types.json.sti0017.Individu individu = new com.bytel.spirit.prof.shared.types.json.sti0017.Individu();
    individu.setCivilite(RandomStringUtils.random(5));
    individu.setNom(RandomStringUtils.random(10));
    individu.setPrenom(RandomStringUtils.random(10));
    return individu;
  }

  /**
   * Build a PhotoPfi
   *
   * @param typeTitulaire_p
   *          The Titulaire Type
   * @return The PhotoPfi
   */
  public PhotoPfi buildPhotoPfi(String typeTitulaire_p)
  {
    PhotoPfi photoPfi = new PhotoPfi();
    com.bytel.spirit.prof.shared.types.json.sti0017.PortefeuilleServices portefeuilleServices = new com.bytel.spirit.prof.shared.types.json.sti0017.PortefeuilleServices();
    //ClientTitulaire
    portefeuilleServices.setClientTitulaire(buildClientTitulaireV1(typeTitulaire_p));
    //ServicesAccessibles
    portefeuilleServices.setServicesAccessibles(buildServicesAccessiblesV1());
    //PointAcces
    portefeuilleServices.setPointsAcces(buildPointAccesV1());
    portefeuilleServices.setStatut("ACTIF"); //$NON-NLS-1$

    photoPfi.setPortefeuilleServices(portefeuilleServices);

    return photoPfi;
  }

  /**
   * Build an AbstractPointAcces list
   *
   * @return The list
   */
  public List<com.bytel.spirit.prof.shared.types.abstracts.AbstractPointAcces> buildPointAcces()
  {
    List<com.bytel.spirit.prof.shared.types.abstracts.AbstractPointAcces> abstractPointAcces = new ArrayList<com.bytel.spirit.prof.shared.types.abstracts.AbstractPointAcces>();
    //LigneFixe
    abstractPointAcces.add(buildPointAccesLigneFixe());
    //CompteAcs
    abstractPointAcces.add(buildPointAccesCompteAcces());
    //Tv
    abstractPointAcces.add(buildPointAccesTV());
    //Voip
    abstractPointAcces.add(buildPointAccesVoipPortage());
    //Voip
    abstractPointAcces.add(buildPointAccesVoipPortTelephonique());
    //Fax
    abstractPointAcces.add(buildPointAccesFax());
    return abstractPointAcces;
  }

  /**
   * Build PointAccesCompteAcces
   *
   * @return The PointAccesCompteAcces
   */
  public PointAccesCompteAcces buildPointAccesCompteAcces()
  {
    PointAccesCompteAcces compteAcces = new PointAccesCompteAcces();
    compteAcces.setIdentifiantFonctionnelPA(RandomStringUtils.randomNumeric(10));
    compteAcces.setStatut("RESILIE"); //$NON-NLS-1$
    compteAcces.setIdentifiantFonctionnelPA(RandomStringUtils.randomNumeric(20));
    compteAcces.setIdentifiantAcces(buildIdentifiantAcces());
    return compteAcces;
  }

  /**
   * Build PointAccesCompteAcces
   *
   * @return The PointAccesCompteAcces
   */
  public com.bytel.spirit.prof.shared.types.json.sti0017.PointAccesCompteAcces buildPointAccesCompteAccesV1()
  {
    com.bytel.spirit.prof.shared.types.json.sti0017.PointAccesCompteAcces compteAcces = new com.bytel.spirit.prof.shared.types.json.sti0017.PointAccesCompteAcces();
    compteAcces.setIdentifiantFonctionnelPA(RandomStringUtils.randomNumeric(10));
    compteAcces.setStatut("RESILIE"); //$NON-NLS-1$
    compteAcces.setIdentifiantFonctionnelPA(RandomStringUtils.randomNumeric(20));
    compteAcces.setIdentifiantAcces(buildIdentifiantAcces());
    return compteAcces;
  }

  /**
   * Build PointAccesFax
   *
   * @return The PointAccesFax
   */
  public PointAccesFax buildPointAccesFax()
  {
    PointAccesFax fax = new PointAccesFax();
    fax.setIdentifiantFonctionnelPA(RandomStringUtils.randomNumeric(10));
    fax.setStatut("ACTIF"); //$NON-NLS-1$
    NumeroFax numeroFax = new NumeroFax();
    numeroFax.setNumero(RandomStringUtils.random(10));
    fax.setNumeroFax(numeroFax);
    return fax;
  }

  /**
   * Build PointAccesFax
   *
   * @return The PointAccesFax
   */
  public com.bytel.spirit.prof.shared.types.json.sti0017.PointAccesFax buildPointAccesFaxV1()
  {
    com.bytel.spirit.prof.shared.types.json.sti0017.PointAccesFax fax = new com.bytel.spirit.prof.shared.types.json.sti0017.PointAccesFax();
    fax.setIdentifiantFonctionnelPA(RandomStringUtils.randomNumeric(10));
    fax.setStatut("ACTIF"); //$NON-NLS-1$
    NumeroFax numeroFax = new NumeroFax();
    numeroFax.setNumero(RandomStringUtils.random(10));
    fax.setNumeroFax(numeroFax);
    return fax;
  }

  /**
   * Build PointAccesLigneFixe
   *
   * @return The PointAccesLigneFixe
   */
  public PointAccesLigneFixe buildPointAccesLigneFixe()
  {
    PointAccesLigneFixe ligneFixe = new PointAccesLigneFixe();
    ligneFixe.setIdentifiantFonctionnelPA(_pointAccesConnu);
    ligneFixe.setStatut("ACTIF"); //$NON-NLS-1$
    ligneFixe.setIndicateurPACible(true);
    ligneFixe.setIndicateurPAPrincipal(true);
    ligneFixe.setDatePriseEnCompteChangementStatut(LocalDate.now());
    ligneFixe.setRaccordement(buildRaccordement());
    return ligneFixe;
  }

  /**
   * Build PointAccesLigneFixe
   *
   * @return The PointAccesLigneFixe
   */
  public com.bytel.spirit.prof.shared.types.json.sti0017.PointAccesLigneFixe buildPointAccesLigneFixeV1()
  {
    com.bytel.spirit.prof.shared.types.json.sti0017.PointAccesLigneFixe ligneFixe = new com.bytel.spirit.prof.shared.types.json.sti0017.PointAccesLigneFixe();
    ligneFixe.setIdentifiantFonctionnelPA(_pointAccesConnu);
    ligneFixe.setStatut("ACTIF"); //$NON-NLS-1$
    ligneFixe.setIndicateurPACible(true);
    ligneFixe.setIndicateurPAPrincipal(true);
    ligneFixe.setDatePriseEnCompteChangementStatut(LocalDate.now());
    ligneFixe.setRaccordement(buildRaccordementV1());
    return ligneFixe;
  }

  /**
   * Build PointAccesTV
   *
   * @return The PointAccesTV
   */
  public PointAccesTV buildPointAccesTV()
  {
    PointAccesTV tv = new PointAccesTV();
    _pointAccesEquipement = RandomStringUtils.randomNumeric(10);
    tv.setIdentifiantFonctionnelPA(_pointAccesEquipement);
    tv.setIdentifiantFonctionnelPALie(RandomStringUtils.randomNumeric(10));
    tv.setStatut("ACTIF"); //$NON-NLS-1$
    CompteTv compteTv = new CompteTv();
    compteTv.setIdCompteTV(RandomStringUtils.random(10));
    tv.setCompteTv(compteTv);
    IdentifiantContenu contenu = new IdentifiantContenu();
    contenu.setIdContenuTV(RandomStringUtils.random(10));
    tv.setIdentifiantContenu(contenu);
    return tv;
  }

  /**
   * Build PointAccesTV
   *
   * @return The PointAccesTV
   */
  public com.bytel.spirit.prof.shared.types.json.sti0017.PointAccesTV buildPointAccesTVV1()
  {
    com.bytel.spirit.prof.shared.types.json.sti0017.PointAccesTV tv = new com.bytel.spirit.prof.shared.types.json.sti0017.PointAccesTV();
    _pointAccesEquipement = RandomStringUtils.randomNumeric(10);
    tv.setIdentifiantFonctionnelPA(_pointAccesEquipement);
    tv.setIdentifiantFonctionnelPALie(RandomStringUtils.randomNumeric(10));
    tv.setStatut("ACTIF"); //$NON-NLS-1$
    CompteTv compteTv = new CompteTv();
    compteTv.setIdCompteTV(RandomStringUtils.random(10));
    tv.setCompteTv(compteTv);
    IdentifiantContenu contenu = new IdentifiantContenu();
    contenu.setIdContenuTV(RandomStringUtils.random(10));
    tv.setIdentifiantContenu(contenu);
    return tv;
  }

  /**
   * Build an AbstractPointAcces list
   *
   * @return The list
   */
  public List<AbstractPointAcces> buildPointAccesV1()
  {
    List<AbstractPointAcces> abstractPointAcces = new ArrayList<AbstractPointAcces>();
    //LigneFixe
    abstractPointAcces.add(buildPointAccesLigneFixeV1());
    //CompteAcs
    abstractPointAcces.add(buildPointAccesCompteAccesV1());
    //Tv
    abstractPointAcces.add(buildPointAccesTVV1());
    //Voip
    abstractPointAcces.add(buildPointAccesVoipPortageV1());
    //Voip
    abstractPointAcces.add(buildPointAccesVoipPortTelephoniqueV1());
    //Fax
    abstractPointAcces.add(buildPointAccesFaxV1());
    return abstractPointAcces;
  }

  /**
   * Build PointAccesVoip
   *
   * @return The PointAccesVoip
   */
  public PointAccesVoip buildPointAccesVoipPortage()
  {
    PointAccesVoip voip = new PointAccesVoip();
    voip.setIdentifiantFonctionnelPA(RandomStringUtils.randomNumeric(10));
    voip.setStatut("ACTIF"); //$NON-NLS-1$
    voip.setIdentifiantFonctionnelPALie(RandomStringUtils.randomNumeric(10));
    NumeroVoip numeroVoip = new NumeroVoip();
    numeroVoip.setNumero(RandomStringUtils.random(10));
    voip.setNumeroVoip(numeroVoip);
    DemandePortage demandePortage = new DemandePortage();
    demandePortage.setCodeRIO(RandomStringUtils.random(10));
    voip.setDemandePortage(demandePortage);
    return voip;
  }

  /**
   * Build PointAccesVoip
   *
   * @return The PointAccesVoip
   */
  public com.bytel.spirit.prof.shared.types.json.sti0017.PointAccesVoip buildPointAccesVoipPortageV1()
  {
    com.bytel.spirit.prof.shared.types.json.sti0017.PointAccesVoip voip = new com.bytel.spirit.prof.shared.types.json.sti0017.PointAccesVoip();
    voip.setIdentifiantFonctionnelPA(RandomStringUtils.randomNumeric(10));
    voip.setStatut("ACTIF"); //$NON-NLS-1$
    voip.setIdentifiantFonctionnelPALie(RandomStringUtils.randomNumeric(10));
    NumeroVoip numeroVoip = new NumeroVoip();
    numeroVoip.setNumero(RandomStringUtils.random(10));
    voip.setNumeroVoip(numeroVoip);
    DemandePortage demandePortage = new DemandePortage();
    demandePortage.setCodeRIO(RandomStringUtils.random(10));
    voip.setDemandePortage(demandePortage);
    return voip;
  }

  /**
   * Build PointAccesVoip
   *
   * @return The PointAccesVoip
   */
  public PointAccesVoip buildPointAccesVoipPortTelephonique()
  {
    PointAccesVoip voip = new PointAccesVoip();
    voip.setIdentifiantFonctionnelPA(RandomStringUtils.randomNumeric(10));
    voip.setStatut("ACTIF"); //$NON-NLS-1$
    voip.setIdentifiantFonctionnelPALie(RandomStringUtils.randomNumeric(10));
    NumeroVoip numeroVoip = new NumeroVoip();
    numeroVoip.setNumero(RandomStringUtils.random(10));
    voip.setNumeroVoip(numeroVoip);
    PortTelephonique portTelephonique = new PortTelephonique();
    portTelephonique.setNumeroPort(1);
    voip.setPortTelephonique(portTelephonique);
    return voip;
  }

  /**
   * Build PointAccesVoip
   *
   * @return The PointAccesVoip
   */
  public com.bytel.spirit.prof.shared.types.json.sti0017.PointAccesVoip buildPointAccesVoipPortTelephoniqueV1()
  {
    com.bytel.spirit.prof.shared.types.json.sti0017.PointAccesVoip voip = new com.bytel.spirit.prof.shared.types.json.sti0017.PointAccesVoip();
    voip.setIdentifiantFonctionnelPA(RandomStringUtils.randomNumeric(10));
    voip.setStatut("ACTIF"); //$NON-NLS-1$
    voip.setIdentifiantFonctionnelPALie(RandomStringUtils.randomNumeric(10));
    NumeroVoip numeroVoip = new NumeroVoip();
    numeroVoip.setNumero(RandomStringUtils.random(10));
    voip.setNumeroVoip(numeroVoip);
    PortTelephonique portTelephonique = new PortTelephonique();
    portTelephonique.setNumeroPort(1);
    voip.setPortTelephonique(portTelephonique);
    return voip;
  }

  /**
   * Build Raccordement
   *
   * @return The Raccordement
   */
  public Raccordement buildRaccordement()
  {
    Raccordement raccordement = new Raccordement();
    raccordement.setIdRaccordement("123456"); //$NON-NLS-1$
    raccordement.setIdPrise(RandomStringUtils.random(20));
    raccordement.setCodeNRA(RandomStringUtils.random(20));
    raccordement.setIdRessourceReseauXDSL(RandomStringUtils.random(20));
    raccordement.setIdRessourceReseauFTTX(RandomStringUtils.random(20));
    raccordement.setIdLigne(RandomStringUtils.random(20));
    raccordement.setIdAction(RandomStringUtils.random(20));
    raccordement.setTypeActionADSL(RandomStringUtils.random(20));
    raccordement.setIndicateurAccesPRO(true);
    raccordement.setReferencePmOi(RandomStringUtils.random(20));
    raccordement.setAdslEtatFT(RandomStringUtils.random(20));
    raccordement.setQualitesTVPossibles(RandomStringUtils.random(20));
    raccordement.setIdClientExterne(RandomStringUtils.random(20));
    //BuildAccesTechnique
    raccordement.setAccesTechnique(buildAccesTechnique());
    //BuildAdresseInstallation
    raccordement.setAdresseInstallation(buildAdresseInstallation());
    raccordement.setIdMandatDegroupage(RandomStringUtils.random(10));
    //BuildRendezVous
    raccordement.setRendezVous(buildRendezVous());
    //BuildEquipement
    raccordement.setEquipements(buildEquipementFixe());
    return raccordement;
  }

  /**
   * Build Raccordement
   *
   * @return The Raccordement
   */
  public com.bytel.spirit.prof.shared.types.json.sti0017.Raccordement buildRaccordementV1()
  {
    com.bytel.spirit.prof.shared.types.json.sti0017.Raccordement raccordement = new com.bytel.spirit.prof.shared.types.json.sti0017.Raccordement();
    raccordement.setIdRaccordement("123456"); //$NON-NLS-1$
    raccordement.setIdPrise(RandomStringUtils.random(20));
    raccordement.setCodeNRA(RandomStringUtils.random(20));
    raccordement.setIdRessourceReseauXDSL(RandomStringUtils.random(20));
    raccordement.setIdRessourceReseauFTTX(RandomStringUtils.random(20));
    raccordement.setIdLigne(RandomStringUtils.random(20));
    raccordement.setIdAction(RandomStringUtils.random(20));
    raccordement.setTypeActionADSL(RandomStringUtils.random(20));
    raccordement.setIndicateurAccesPRO(true);
    raccordement.setReferencePmOi(RandomStringUtils.random(20));
    raccordement.setAdslEtatFT(RandomStringUtils.random(20));
    raccordement.setQualitesTVPossibles(RandomStringUtils.random(20));
    raccordement.setIdClientExterne(RandomStringUtils.random(20));
    //BuildAccesTechnique
    raccordement.setAccesTechnique(buildAccesTechniqueV1());
    //BuildAdresseInstallation
    raccordement.setAdresseInstallation(buildAdresseInstallationV1());
    raccordement.setIdMandatDegroupage(RandomStringUtils.random(10));
    //BuildRendezVous
    raccordement.setRendezVous(buildRendezVous());
    //BuildEquipement
    raccordement.setEquipements(buildEquipementFixeV1());
    return raccordement;
  }

  /**
   * Build RendezVous
   *
   * @return The RendezVous
   */
  public RendezVous buildRendezVous()
  {
    RendezVous rendezVous = new RendezVous();
    rendezVous.setCodePrestataire(RandomStringUtils.random(10));
    rendezVous.setCommentaire(RandomStringUtils.random(10));
    rendezVous.setIdExterneRendezVous(RandomStringUtils.random(10));
    return rendezVous;
  }

  /**
   * Build ServiceAccessible List
   *
   * @return The list
   */
  public List<ServiceAccessible> buildServicesAccessibles()
  {
    List<ServiceAccessible> serviceAccessibles = new ArrayList<ServiceAccessible>();
    //Known
    ServiceAccessible serviceAccessibleConnu = new ServiceAccessible();
    serviceAccessibleConnu.setNoServiceAccessible(RandomStringUtils.random(20));
    _noServiceCommercialConnu = RandomStringUtils.random(20);
    serviceAccessibleConnu.setNoServiceCommercial(_noServiceCommercialConnu);
    serviceAccessibleConnu.setStatut("RESILIE"); //$NON-NLS-1$
    _pointAccesConnu = RandomStringUtils.random(10);
    ArrayList<String> listeIdPointAcces = new ArrayList<>();
    listeIdPointAcces.add(_pointAccesConnu);
    listeIdPointAcces.add(RandomStringUtils.random(10));
    listeIdPointAcces.add(RandomStringUtils.random(10));
    serviceAccessibleConnu.setListeIdPointAcces(listeIdPointAcces);

    //Unknown
    ServiceAccessible serviceAccessibleNonConnu = new ServiceAccessible();
    serviceAccessibleNonConnu.setNoServiceAccessible(RandomStringUtils.random(20));
    serviceAccessibleNonConnu.setNoServiceCommercial(RandomStringUtils.random(20));
    serviceAccessibleNonConnu.setStatut("ACTIF"); //$NON-NLS-1$
    listeIdPointAcces = new ArrayList<>();
    listeIdPointAcces.add(RandomStringUtils.random(10));
    serviceAccessibleNonConnu.setListeIdPointAcces(listeIdPointAcces);

    serviceAccessibles.add(serviceAccessibleConnu);
    serviceAccessibles.add(serviceAccessibleNonConnu);

    return serviceAccessibles;
  }

  /**
   * Build ServiceAccessible List
   *
   * @return The list
   */
  public List<com.bytel.spirit.prof.shared.types.json.sti0017.ServiceAccessible> buildServicesAccessiblesV1()
  {
    List<com.bytel.spirit.prof.shared.types.json.sti0017.ServiceAccessible> serviceAccessibles = new ArrayList<com.bytel.spirit.prof.shared.types.json.sti0017.ServiceAccessible>();
    //Known
    com.bytel.spirit.prof.shared.types.json.sti0017.ServiceAccessible serviceAccessibleConnu = new com.bytel.spirit.prof.shared.types.json.sti0017.ServiceAccessible();
    serviceAccessibleConnu.setNoServiceAccessible(RandomStringUtils.random(20));
    _noServiceCommercialConnu = RandomStringUtils.random(20);
    serviceAccessibleConnu.setNoServiceCommercial(_noServiceCommercialConnu);
    serviceAccessibleConnu.setStatut("RESILIE"); //$NON-NLS-1$
    _pointAccesConnu = RandomStringUtils.random(10);
    ArrayList<String> listeIdPointAcces = new ArrayList<>();
    listeIdPointAcces.add(_pointAccesConnu);
    listeIdPointAcces.add(RandomStringUtils.random(10));
    listeIdPointAcces.add(RandomStringUtils.random(10));
    serviceAccessibleConnu.setListeIdPointAcces(listeIdPointAcces);

    //Unknown
    com.bytel.spirit.prof.shared.types.json.sti0017.ServiceAccessible serviceAccessibleNonConnu = new com.bytel.spirit.prof.shared.types.json.sti0017.ServiceAccessible();
    serviceAccessibleNonConnu.setNoServiceAccessible(RandomStringUtils.random(20));
    serviceAccessibleNonConnu.setNoServiceCommercial(RandomStringUtils.random(20));
    serviceAccessibleNonConnu.setStatut("ACTIF"); //$NON-NLS-1$
    listeIdPointAcces = new ArrayList<>();
    listeIdPointAcces.add(RandomStringUtils.random(10));
    serviceAccessibleNonConnu.setListeIdPointAcces(listeIdPointAcces);

    serviceAccessibles.add(serviceAccessibleConnu);
    serviceAccessibles.add(serviceAccessibleNonConnu);

    return serviceAccessibles;
  }

  /**
   * @return the commande
   */
  public Commande getCommande()
  {
    return _commande;
  }

  /**
   * @return the noServiceCommercialConnu
   */
  public String getNoServiceCommercialConnu()
  {
    return _noServiceCommercialConnu;
  }

}
