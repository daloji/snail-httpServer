/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PI0252;

import static org.junit.Assert.assertEquals;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.test.context.ContextConfiguration;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.datetime.DateTimeManager;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.request.Parameter;
import com.bytel.ravel.common.factory.request.UrlParameters;
import com.bytel.ravel.common.factory.response.IRavelResponse;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.utils.ACManagerUtil;
import com.bytel.ravel.common.utils.Mode;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.RetourFactoryForTU;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.utils.Test_Consts;
import com.bytel.spirit.common.activities.shared.BL5220_AllouerRessourceRaccordement;
import com.bytel.spirit.common.activities.shared.BL5220_AllouerRessourceRaccordement.BL5220_AllouerRessourceRaccordementBuilder;
import com.bytel.spirit.common.activities.shared.BL5250_ExtraireCaracteristiquesCommunes;
import com.bytel.spirit.common.activities.shared.BL5250_ExtraireCaracteristiquesCommunes.BL5250_ExtraireCaracteristiquesCommunesBuilder;
import com.bytel.spirit.common.activities.shared.BL5260_ExtraireCaracteristiquesSpecifiques;
import com.bytel.spirit.common.activities.shared.BL5260_ExtraireCaracteristiquesSpecifiques.BL5260_ExtraireCaracteristiquesSpecifiquesBuilder;
import com.bytel.spirit.common.activities.shared.structs.CaracteristiquesCommunes;
import com.bytel.spirit.common.activities.shared.structs.CaracteristiquesSpecifiques;
import com.bytel.spirit.common.connectors.rpg.RPGProxy;
import com.bytel.spirit.common.connectors.rst.RSTProxy;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.RetourConverter;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.TypeObjetCommercial;
import com.bytel.spirit.common.shared.saab.res.TypeRessource;
import com.bytel.spirit.common.shared.saab.rpg.PFI;
import com.bytel.spirit.common.shared.saab.rst.ServiceTechnique;
import com.bytel.spirit.common.shared.saab.rst.StLienAllocationCommercial;
import com.bytel.spirit.common.shared.saab.rst.Statut;
import com.bytel.spirit.common.shared.saab.rst.TypeST;
import com.bytel.spirit.prof.processes.Messages;
import com.bytel.spirit.prof.processes.PI0252.PI0252_AllouerRessourceRaccordement.ParameterUrl;
import com.bytel.spirit.prof.processes.PI0252.structs.PI0252_Retour;
import com.bytel.spirit.prof.processes.PI0252.structs.PI0252_Retour.ReponseFonctionnelle;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author aazzouzi
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@ContextConfiguration("classpath:BeansProcessTestMocks.xml")
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
@PrepareForTest({ PI0252_AllouerRessourceRaccordement.class, RSTProxy.class, RPGProxy.class, BL5220_AllouerRessourceRaccordement.class, BL5220_AllouerRessourceRaccordementBuilder.class, BL5250_ExtraireCaracteristiquesCommunes.class, BL5250_ExtraireCaracteristiquesCommunesBuilder.class, BL5260_ExtraireCaracteristiquesSpecifiques.class, BL5260_ExtraireCaracteristiquesSpecifiquesBuilder.class })
public class PI0252_AllouerRessourceRaccordementTest
{

  /**
   * Tracabilite
   */
  private static Tracabilite _tracabilite;

  /**
   * SPRING context
   */
  @SuppressWarnings("unused")
  private static ClassPathXmlApplicationContext __context;

  /**
   * Factory de génération des beans
   */
  private static PodamFactory __podam = new PodamFactoryImpl();

  /**
   * Initialization method: Create: - spring context - connectors - service manager.
   *
   * @throws RavelException
   *           the exception
   */
  @BeforeClass
  public static void init() throws RavelException
  {
    // désactivation du cache podam
    __podam.getStrategy().setMemoization(false);
    __podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());

    ACManagerUtil.resetACManager();
    __context = new ClassPathXmlApplicationContext("classpath:BeansProcessTestMocks.xml"); //$NON-NLS-1$

    DateTimeManager.getInstance().initialize(Mode.FIXED);
    DateTimeManager.getInstance().setFixedClockAt(DateTimeManager.getInstance().now());

  }

  /**
   * PI0252_AllouerRessourceRaccordement
   */
  private PI0252_AllouerRessourceRaccordement _processInstance;
  /**
  *
  */
  @MockStrict
  private RSTProxy _rstProxyMock;
  /**
  *
  */
  @MockStrict
  private RPGProxy _rpgProxyMock;
  /**
  *
  */
  @MockStrict
  private BL5220_AllouerRessourceRaccordement _bl5220Mock;
  /**
  *
  */
  @MockStrict
  private BL5220_AllouerRessourceRaccordementBuilder _bl5220BuilderMock;
  /**
  *
  */
  @MockStrict
  private BL5250_ExtraireCaracteristiquesCommunes _bl5250Mock;
  /**
  *
  */
  @MockStrict
  private BL5250_ExtraireCaracteristiquesCommunesBuilder _bl5250BuilderMock;

  /**
  *
  */
  @MockStrict
  private BL5260_ExtraireCaracteristiquesSpecifiques _bl5260Mock;

  /**
  *
  */
  @MockStrict
  private BL5260_ExtraireCaracteristiquesSpecifiquesBuilder _bl5260BuilderMock;

  /**
   * Test case where idRessource is null in request.
   *
   * <b> Expected: </ b> Return NOK (CAT3, ENTREE_INCORRECTE, Paramètre idRessource null ou vide dans la requête.) <br/>
   *
   * @throws Throwable
   *           in case of error
   */
  @Test
  public void PI0252_AllouerRessourceRaccordementTest_KO_001() throws Throwable
  {
    com.bytel.ravel.types.Retour retourExpected = RetourConverter.convertToJsonRetour(RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ENTREE_INCORRECTE, MessageFormat.format(Messages.getString("PI0252.BL001.ParameterNullOrEmpty"), ParameterUrl.idRessource.name()))); //$NON-NLS-1$
    PI0252_Retour expectedResponse = new PI0252_Retour(retourExpected);

    ReponseFonctionnelle reponseFonctionnelle = null;
    reponseFonctionnelle = new ReponseFonctionnelle();
    reponseFonctionnelle.setTracabilitePi(_tracabilite);
    expectedResponse.setReponseFonctionnelle(reponseFonctionnelle);

    String idRessource = null;
    String idSt = "idSt"; //$NON-NLS-1$
    Request request = prepareRequest(idRessource, idSt);

    _processInstance.run(request);

    IRavelResponse response = request.getResponse();
    PI0252_Retour actualResponse = GsonTools.getIso8601Ms().fromJson(response.getGenericResponse().getResult(), PI0252_Retour.class);

    assertEquals(ErrorCode.KO_00400, response.getErrorCode());

    checkRetour(expectedResponse.getRetour(), actualResponse.getRetour());
  }

  /**
   * Test case where idSt is null in request.
   *
   * <b> Expected: </ b> Return NOK (CAT3, ENTREE_INCORRECTE, Paramètre idSt null ou vide dans la requête.) <br/>
   *
   * @throws Throwable
   *           in case of error
   */
  @Test
  public void PI0252_AllouerRessourceRaccordementTest_KO_002() throws Throwable
  {
    com.bytel.ravel.types.Retour retourExpected = RetourConverter.convertToJsonRetour(RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ENTREE_INCORRECTE, MessageFormat.format(Messages.getString("PI0252.BL001.ParameterNullOrEmpty"), ParameterUrl.idSt.name()))); //$NON-NLS-1$
    PI0252_Retour expectedResponse = new PI0252_Retour(retourExpected);

    ReponseFonctionnelle reponseFonctionnelle = null;
    reponseFonctionnelle = new ReponseFonctionnelle();
    reponseFonctionnelle.setTracabilitePi(_tracabilite);
    expectedResponse.setReponseFonctionnelle(reponseFonctionnelle);

    String idRessource = "idRessource";//$NON-NLS-1$
    String idSt = null;
    Request request = prepareRequest(idRessource, idSt);

    _processInstance.run(request);

    IRavelResponse response = request.getResponse();
    PI0252_Retour actualResponse = GsonTools.getIso8601Ms().fromJson(response.getGenericResponse().getResult(), PI0252_Retour.class);

    assertEquals(ErrorCode.KO_00400, response.getErrorCode());

    checkRetour(expectedResponse.getRetour(), actualResponse.getRetour());
  }

  /**
   * Test case where RSTProxy.serviceTechniqueLireUn returns KO CaT1 SERVICE_TIERS_INDISPONIBLE.
   *
   * <b> Expected: </ b> Return NOK (CAT1, SERVICE_TIERS_INDISPONIBLE, "") <br/>
   *
   * @throws Throwable
   *           in case of error
   */
  @Test
  public void PI0252_AllouerRessourceRaccordementTest_KO_003() throws Throwable
  {
    com.bytel.ravel.types.Retour retourExpected = RetourConverter.convertToJsonRetour(RetourFactory.createNOK(IMegConsts.CAT1, IMegConsts.SERVICE_TIERS_INDISPONIBLE, StringUtils.EMPTY));
    PI0252_Retour expectedResponse = new PI0252_Retour(retourExpected);

    ReponseFonctionnelle reponseFonctionnelle = null;
    reponseFonctionnelle = new ReponseFonctionnelle();
    reponseFonctionnelle.setTracabilitePi(_tracabilite);
    expectedResponse.setReponseFonctionnelle(reponseFonctionnelle);

    String idRessource = "idRessource";//$NON-NLS-1$
    String idSt = "idSt"; //$NON-NLS-1$
    Request request = prepareRequest(idRessource, idSt);

    Retour rstRetourKo = RetourFactory.createNOK(IMegConsts.CAT1, IMegConsts.SERVICE_TIERS_INDISPONIBLE, StringUtils.EMPTY);
    List<ServiceTechnique> listServiceTechnique = new ArrayList<>();
    ConnectorResponse<Retour, List<ServiceTechnique>> rstResponse = new ConnectorResponse<Retour, List<ServiceTechnique>>(rstRetourKo, listServiceTechnique);

    // Mock du RSTProxy.serviceTechniqueLireUn
    EasyMock.expect(RSTProxy.getInstance()).andReturn(_rstProxyMock);
    EasyMock.expect(_rstProxyMock.serviceTechniqueLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(idSt))).andReturn(rstResponse);

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();
    PI0252_Retour actualResponse = GsonTools.getIso8601Ms().fromJson(response.getGenericResponse().getResult(), PI0252_Retour.class);

    assertEquals(ErrorCode.KO_00503, response.getErrorCode());
    checkRetour(expectedResponse.getRetour(), actualResponse.getRetour());
  }

  /**
   * Test case where RSTProxy.serviceTechniqueLireUn returns OK but the oStLac.statut <> INDETERMINE
   *
   * <b> Expected: </ b> Return NOK (CAT3, ENTREE_INCORRECTE, Paramètre idSt null ou vide dans la requête.) <br/>
   *
   * @throws Throwable
   *           in case of error
   */
  @Test
  public void PI0252_AllouerRessourceRaccordementTest_KO_004() throws Throwable
  {
    com.bytel.ravel.types.Retour retourExpected = RetourConverter.convertToJsonRetour(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, "Le ST LAC doit etre au statut INDETERMINE, associé à une ressource de type RACCO et un PA"));
    PI0252_Retour expectedResponse = new PI0252_Retour(retourExpected);

    ReponseFonctionnelle reponseFonctionnelle = null;
    reponseFonctionnelle = new ReponseFonctionnelle();
    reponseFonctionnelle.setTracabilitePi(_tracabilite);
    expectedResponse.setReponseFonctionnelle(reponseFonctionnelle);

    String idRessource = "idRessource";//$NON-NLS-1$
    String idSt = "idSt"; //$NON-NLS-1$
    Request request = prepareRequest(idRessource, idSt);

    Retour rstRetourOk = RetourFactory.createOkRetour();

    StLienAllocationCommercial stLAC = new StLienAllocationCommercial("idStLac", Statut.ACTIF.name(), "ClientOperateur", "noCompte", TypeObjetCommercial.PA.name(), "clientOperateur", "noCompte", "idRessource", TypeST.LAC.name()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$

    List<ServiceTechnique> listServiceTechnique = new ArrayList<>();
    listServiceTechnique.add(stLAC);

    ConnectorResponse<Retour, List<ServiceTechnique>> rstResponse = new ConnectorResponse<Retour, List<ServiceTechnique>>(rstRetourOk, listServiceTechnique);

    // Mock du RSTProxy.serviceTechniqueLireUn
    EasyMock.expect(RSTProxy.getInstance()).andReturn(_rstProxyMock);
    EasyMock.expect(_rstProxyMock.serviceTechniqueLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(idSt))).andReturn(rstResponse);

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();
    PI0252_Retour actualResponse = GsonTools.getIso8601Ms().fromJson(response.getGenericResponse().getResult(), PI0252_Retour.class);

    assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    checkRetour(expectedResponse.getRetour(), actualResponse.getRetour());
  }

  /**
   * Test case where RSTProxy.serviceTechniqueLireUn returns OK but the oStLac.StLienAllocationCommercial = null
   *
   * <b> Expected: </ b> Return NOK (CAT3, ENTREE_INCORRECTE, Paramètre idSt null ou vide dans la requête.) <br/>
   *
   * @throws Throwable
   *           in case of error
   */
  @Test
  public void PI0252_AllouerRessourceRaccordementTest_KO_005() throws Throwable
  {
    com.bytel.ravel.types.Retour retourExpected = RetourConverter.convertToJsonRetour(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, "Le ST LAC doit etre au statut INDETERMINE, associé à une ressource de type RACCO et un PA"));
    PI0252_Retour expectedResponse = new PI0252_Retour(retourExpected);

    ReponseFonctionnelle reponseFonctionnelle = null;
    reponseFonctionnelle = new ReponseFonctionnelle();
    reponseFonctionnelle.setTracabilitePi(_tracabilite);
    expectedResponse.setReponseFonctionnelle(reponseFonctionnelle);

    String idRessource = "idRessource";//$NON-NLS-1$
    String idSt = "idSt"; //$NON-NLS-1$
    Request request = prepareRequest(idRessource, idSt);

    Retour rstRetourOk = RetourFactory.createOkRetour();

    StLienAllocationCommercial stLAC = new StLienAllocationCommercial("idStLac", Statut.INDETERMINE.name(), "ClientOperateur", "noCompte", TypeObjetCommercial.PA.name(), "clientOperateur", "noCompte", "idRessource", TypeST.LAC.name()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$

    List<ServiceTechnique> listServiceTechnique = new ArrayList<>();
    listServiceTechnique.add(stLAC);

    ConnectorResponse<Retour, List<ServiceTechnique>> rstResponse = new ConnectorResponse<Retour, List<ServiceTechnique>>(rstRetourOk, listServiceTechnique);

    // Mock du RSTProxy.serviceTechniqueLireUn
    EasyMock.expect(RSTProxy.getInstance()).andReturn(_rstProxyMock);
    EasyMock.expect(_rstProxyMock.serviceTechniqueLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(idSt))).andReturn(rstResponse);

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();
    PI0252_Retour actualResponse = GsonTools.getIso8601Ms().fromJson(response.getGenericResponse().getResult(), PI0252_Retour.class);

    assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    checkRetour(expectedResponse.getRetour(), actualResponse.getRetour());
  }

  /**
   * Test case where RSTProxy.serviceTechniqueLireUn returns OK but the oStLac.StLienAllocationCommercial.typeRessource
   * <> Racco
   *
   * <b> Expected: </ b> Return NOK (CAT3, ENTREE_INCORRECTE, Paramètre idSt null ou vide dans la requête.) <br/>
   *
   * @throws Throwable
   *           in case of error
   */
  @Test
  public void PI0252_AllouerRessourceRaccordementTest_KO_006() throws Throwable
  {
    com.bytel.ravel.types.Retour retourExpected = RetourConverter.convertToJsonRetour(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, "Le ST LAC doit etre au statut INDETERMINE, associé à une ressource de type RACCO et un PA"));
    PI0252_Retour expectedResponse = new PI0252_Retour(retourExpected);

    ReponseFonctionnelle reponseFonctionnelle = null;
    reponseFonctionnelle = new ReponseFonctionnelle();
    reponseFonctionnelle.setTracabilitePi(_tracabilite);
    expectedResponse.setReponseFonctionnelle(reponseFonctionnelle);

    String idRessource = "idRessource";//$NON-NLS-1$
    String idSt = "idSt"; //$NON-NLS-1$
    Request request = prepareRequest(idRessource, idSt);

    Retour rstRetourOk = RetourFactory.createOkRetour();
    StLienAllocationCommercial stLienAllocationCommercial = new StLienAllocationCommercial("idStLac", Statut.INDETERMINE.name(), "ClientOperateur", "noCompte", TypeObjetCommercial.PA.name(), "ClientOperateur", "numCompte", "IdRessource", TypeRessource.PORT_P2P.name()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$

    List<ServiceTechnique> listServiceTechnique = new ArrayList<>();
    listServiceTechnique.add(stLienAllocationCommercial);

    ConnectorResponse<Retour, List<ServiceTechnique>> rstResponse = new ConnectorResponse<Retour, List<ServiceTechnique>>(rstRetourOk, listServiceTechnique);

    // Mock du RSTProxy.serviceTechniqueLireUn
    EasyMock.expect(RSTProxy.getInstance()).andReturn(_rstProxyMock);
    EasyMock.expect(_rstProxyMock.serviceTechniqueLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(idSt))).andReturn(rstResponse);

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();
    PI0252_Retour actualResponse = GsonTools.getIso8601Ms().fromJson(response.getGenericResponse().getResult(), PI0252_Retour.class);

    assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    checkRetour(expectedResponse.getRetour(), actualResponse.getRetour());
  }

  /**
   * Test case where RSTProxy.serviceTechniqueLireUn returns OK but the oStLac.StLienAllocationCommercial.IdRessource <>
   * request.IdRessource (_processContext.getIdRessource())
   *
   * <b> Expected: </ b> Return NOK (CAT3, ENTREE_INCORRECTE, Paramètre idSt null ou vide dans la requête.) <br/>
   *
   * @throws Throwable
   *           in case of error
   */
  @Test
  public void PI0252_AllouerRessourceRaccordementTest_KO_007() throws Throwable
  {
    com.bytel.ravel.types.Retour retourExpected = RetourConverter.convertToJsonRetour(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, "Le ST LAC doit etre au statut INDETERMINE, associé à une ressource de type RACCO et un PA"));
    PI0252_Retour expectedResponse = new PI0252_Retour(retourExpected);

    ReponseFonctionnelle reponseFonctionnelle = null;
    reponseFonctionnelle = new ReponseFonctionnelle();
    reponseFonctionnelle.setTracabilitePi(_tracabilite);
    expectedResponse.setReponseFonctionnelle(reponseFonctionnelle);

    String idRessource = "idRessource";//$NON-NLS-1$
    String idSt = "idSt"; //$NON-NLS-1$
    Request request = prepareRequest(idRessource, idSt);

    Retour rstRetourOk = RetourFactory.createOkRetour();
    StLienAllocationCommercial stLienAllocationCommercial = new StLienAllocationCommercial("idStLac", Statut.INDETERMINE.name(), "ClientOperateur", "noCompte", TypeObjetCommercial.PA.name(), "ClientOperateur", "numCompte", "unIdRessourceDifferent", TypeRessource.RACCO.name()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$

    List<ServiceTechnique> listServiceTechnique = new ArrayList<>();
    listServiceTechnique.add(stLienAllocationCommercial);

    ConnectorResponse<Retour, List<ServiceTechnique>> rstResponse = new ConnectorResponse<Retour, List<ServiceTechnique>>(rstRetourOk, listServiceTechnique);

    // Mock du RSTProxy.serviceTechniqueLireUn
    EasyMock.expect(RSTProxy.getInstance()).andReturn(_rstProxyMock);
    EasyMock.expect(_rstProxyMock.serviceTechniqueLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(idSt))).andReturn(rstResponse);

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();
    PI0252_Retour actualResponse = GsonTools.getIso8601Ms().fromJson(response.getGenericResponse().getResult(), PI0252_Retour.class);

    assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    checkRetour(expectedResponse.getRetour(), actualResponse.getRetour());
  }

  /**
   * Test case where RSTProxy.serviceTechniqueLireUn returns OK but the
   * oStLac.StLienAllocationCommercial.TypeObjetCommercial <> PA
   *
   * <b> Expected: </ b> Return NOK (CAT3, ENTREE_INCORRECTE, Paramètre idSt null ou vide dans la requête.) <br/>
   *
   * @throws Throwable
   *           in case of error
   */
  @Test
  public void PI0252_AllouerRessourceRaccordementTest_KO_008() throws Throwable
  {
    com.bytel.ravel.types.Retour retourExpected = RetourConverter.convertToJsonRetour(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, "Le ST LAC doit etre au statut INDETERMINE, associé à une ressource de type RACCO et un PA"));
    PI0252_Retour expectedResponse = new PI0252_Retour(retourExpected);

    ReponseFonctionnelle reponseFonctionnelle = null;
    reponseFonctionnelle = new ReponseFonctionnelle();
    reponseFonctionnelle.setTracabilitePi(_tracabilite);
    expectedResponse.setReponseFonctionnelle(reponseFonctionnelle);

    String idRessource = "idRessource";//$NON-NLS-1$
    String idSt = "idSt"; //$NON-NLS-1$
    Request request = prepareRequest(idRessource, idSt);

    Retour rstRetourOk = RetourFactory.createOkRetour();
    StLienAllocationCommercial stLienAllocationCommercial = new StLienAllocationCommercial("idStLac", Statut.INDETERMINE.name(), "ClientOperateur", "noCompte", TypeObjetCommercial.SA.name(), "ClientOperateur", "numCompte", idRessource, TypeRessource.RACCO.name()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$

    List<ServiceTechnique> listServiceTechnique = new ArrayList<>();
    listServiceTechnique.add(stLienAllocationCommercial);

    ConnectorResponse<Retour, List<ServiceTechnique>> rstResponse = new ConnectorResponse<Retour, List<ServiceTechnique>>(rstRetourOk, listServiceTechnique);

    // Mock du RSTProxy.serviceTechniqueLireUn
    EasyMock.expect(RSTProxy.getInstance()).andReturn(_rstProxyMock);
    EasyMock.expect(_rstProxyMock.serviceTechniqueLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(idSt))).andReturn(rstResponse);

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();
    PI0252_Retour actualResponse = GsonTools.getIso8601Ms().fromJson(response.getGenericResponse().getResult(), PI0252_Retour.class);

    assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    checkRetour(expectedResponse.getRetour(), actualResponse.getRetour());
  }

  /**
   * Test case where RSTProxy.serviceTechniqueLireUn returns OK, RPGProxy.pfiLireUn returns NOK <b> Expected: </ b>
   * Return NOK (CAT3, ENTREE_INCORRECTE, Paramètre idSt null ou vide dans la requête.) <br/>
   *
   * @throws Throwable
   *           in case of error
   */
  @Test
  public void PI0252_AllouerRessourceRaccordementTest_KO_009() throws Throwable
  {
    com.bytel.ravel.types.Retour retourExpected = RetourConverter.convertToJsonRetour(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, StringUtils.EMPTY));
    PI0252_Retour expectedResponse = new PI0252_Retour(retourExpected);

    ReponseFonctionnelle reponseFonctionnelle = null;
    reponseFonctionnelle = new ReponseFonctionnelle();
    reponseFonctionnelle.setTracabilitePi(_tracabilite);
    expectedResponse.setReponseFonctionnelle(reponseFonctionnelle);

    String idRessource = "idRessource";//$NON-NLS-1$
    String idSt = "idSt"; //$NON-NLS-1$
    Request request = prepareRequest(idRessource, idSt);

    Retour rstRetourOk = RetourFactory.createOkRetour();
    StLienAllocationCommercial stLienAllocationCommercial = new StLienAllocationCommercial("idStLac", Statut.INDETERMINE.name(), "ClientOperateur", "noCompte", TypeObjetCommercial.PA.name(), "ClientOperateur", "numCompte", idRessource, TypeRessource.RACCO.name()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$

    List<ServiceTechnique> listServiceTechnique = new ArrayList<>();
    listServiceTechnique.add(stLienAllocationCommercial);

    Retour rpgRetourKo = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, StringUtils.EMPTY);

    ConnectorResponse<Retour, List<ServiceTechnique>> rstResponse = new ConnectorResponse<>(rstRetourOk, listServiceTechnique);
    ConnectorResponse<Retour, PFI> rpgResponse = new ConnectorResponse<>(rpgRetourKo, null);

    // Mock du RSTProxy.serviceTechniqueLireUn
    EasyMock.expect(RSTProxy.getInstance()).andReturn(_rstProxyMock);
    EasyMock.expect(_rstProxyMock.serviceTechniqueLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(idSt))).andReturn(rstResponse);

    // Mock du RPGProxy.pfiLireUn
    EasyMock.expect(RPGProxy.getInstance()).andReturn(_rpgProxyMock);
    EasyMock.expect(_rpgProxyMock.pfiLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(stLienAllocationCommercial.getClientOperateur()), EasyMock.eq(stLienAllocationCommercial.getNoCompte()))).andReturn(rpgResponse);

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();
    PI0252_Retour actualResponse = GsonTools.getIso8601Ms().fromJson(response.getGenericResponse().getResult(), PI0252_Retour.class);

    assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    checkRetour(expectedResponse.getRetour(), actualResponse.getRetour());
  }

  /**
   * Test case where RSTProxy.serviceTechniqueLireUn returns OK, RPGProxy.pfiLireUn returns OK, BL5250 returns KO
   *
   * <b> Expected: </ b> Return NOK (CAT3, ENTREE_INCORRECTE, Paramètre idSt null ou vide dans la requête.) <br/>
   *
   * @throws Throwable
   *           in case of error
   */
  @Test
  public void PI0252_AllouerRessourceRaccordementTest_KO_010() throws Throwable
  {
    com.bytel.ravel.types.Retour retourExpected = RetourConverter.convertToJsonRetour(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, StringUtils.EMPTY));
    PI0252_Retour expectedResponse = new PI0252_Retour(retourExpected);

    ReponseFonctionnelle reponseFonctionnelle = null;
    reponseFonctionnelle = new ReponseFonctionnelle();
    reponseFonctionnelle.setTracabilitePi(_tracabilite);
    expectedResponse.setReponseFonctionnelle(reponseFonctionnelle);

    String idRessource = "idRessource";//$NON-NLS-1$
    String idSt = "idSt"; //$NON-NLS-1$
    Request request = prepareRequest(idRessource, idSt);

    Retour rstRetourOk = RetourFactory.createOkRetour();
    StLienAllocationCommercial stLienAllocationCommercial = new StLienAllocationCommercial("idStLac", Statut.INDETERMINE.name(), "ClientOperateur", "noCompte", TypeObjetCommercial.PA.name(), "ClientOperateur", "numCompte", idRessource, TypeRessource.RACCO.name()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$

    List<ServiceTechnique> listServiceTechnique = new ArrayList<>();
    listServiceTechnique.add(stLienAllocationCommercial);

    Retour rpgRetourOk = RetourFactory.createOkRetour();
    Retour retourBl52250Ko = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, StringUtils.EMPTY);

    ConnectorResponse<Retour, List<ServiceTechnique>> rstResponse = new ConnectorResponse<>(rstRetourOk, listServiceTechnique);
    ConnectorResponse<Retour, PFI> rpgResponse = new ConnectorResponse<>(rpgRetourOk, null);

    // Mock du RSTProxy.serviceTechniqueLireUn
    EasyMock.expect(RSTProxy.getInstance()).andReturn(_rstProxyMock);
    EasyMock.expect(_rstProxyMock.serviceTechniqueLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(idSt))).andReturn(rstResponse);

    // Mock du RPGProxy.pfiLireUn
    EasyMock.expect(RPGProxy.getInstance()).andReturn(_rpgProxyMock);
    EasyMock.expect(_rpgProxyMock.pfiLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(stLienAllocationCommercial.getClientOperateur()), EasyMock.eq(stLienAllocationCommercial.getNoCompte()))).andReturn(rpgResponse);

    //Mock Activity - BL5250_ExtraireCaracteristiquesCommunes
    PowerMock.expectNew(BL5250_ExtraireCaracteristiquesCommunesBuilder.class).andReturn(_bl5250BuilderMock);
    EasyMock.expect(_bl5250BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl5250BuilderMock);
    EasyMock.expect(_bl5250BuilderMock.pfi(null)).andReturn(_bl5250BuilderMock);

    //Build Activity - BL5250_ExtraireCaracteristiquesCommunes
    EasyMock.expect(_bl5250BuilderMock.build()).andReturn(_bl5250Mock);
    EasyMock.expect(_bl5250Mock.execute(_processInstance)).andReturn(null);
    EasyMock.expect(_bl5250Mock.getRetour()).andReturn(retourBl52250Ko);
    EasyMock.expect(_bl5250Mock.getRetour()).andReturn(retourBl52250Ko);

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();
    PI0252_Retour actualResponse = GsonTools.getIso8601Ms().fromJson(response.getGenericResponse().getResult(), PI0252_Retour.class);

    assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    checkRetour(expectedResponse.getRetour(), actualResponse.getRetour());
  }

  /**
   * Test case where RSTProxy.serviceTechniqueLireUn returns OK, RPGProxy.pfiLireUn returns OK, BL5250 returns OK,
   * BL5260 returns KO
   *
   * <b> Expected: </ b> Return NOK (CAT3, ENTREE_INCORRECTE, Paramètre idSt null ou vide dans la requête.) <br/>
   *
   * @throws Throwable
   *           in case of error
   */
  @Test
  public void PI0252_AllouerRessourceRaccordementTest_KO_011() throws Throwable
  {
    com.bytel.ravel.types.Retour retourExpected = RetourConverter.convertToJsonRetour(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, StringUtils.EMPTY));
    PI0252_Retour expectedResponse = new PI0252_Retour(retourExpected);

    ReponseFonctionnelle reponseFonctionnelle = null;
    reponseFonctionnelle = new ReponseFonctionnelle();
    reponseFonctionnelle.setTracabilitePi(_tracabilite);
    expectedResponse.setReponseFonctionnelle(reponseFonctionnelle);

    String idRessource = "idRessource";//$NON-NLS-1$
    String idSt = "idSt"; //$NON-NLS-1$
    Request request = prepareRequest(idRessource, idSt);

    StLienAllocationCommercial stLienAllocationCommercial = new StLienAllocationCommercial("idStLac", Statut.INDETERMINE.name(), "ClientOperateur", "noCompte", TypeObjetCommercial.PA.name(), "ClientOperateur", "numCompte", idRessource, TypeRessource.RACCO.name()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
    stLienAllocationCommercial.setOcIdentifiantFonctionnelPA("ocIdentifiantFonctionnelPA"); //$NON-NLS-1$

    List<ServiceTechnique> listServiceTechnique = new ArrayList<>();
    listServiceTechnique.add(stLienAllocationCommercial);
    CaracteristiquesCommunes caracteristiqueCommune = new CaracteristiquesCommunes();
    caracteristiqueCommune.setClientOperateur("ClientOperateur"); //$NON-NLS-1$
    caracteristiqueCommune.setNoCompte("noCompte"); //$NON-NLS-1$
    PFI pfi = new PFI();
    pfi.setClientOperateur("clientOp"); //$NON-NLS-1$

    Retour retourOk = RetourFactory.createOkRetour();
    Retour bl5260RetourKo = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, StringUtils.EMPTY);

    ConnectorResponse<Retour, List<ServiceTechnique>> rstResponse = new ConnectorResponse<>(retourOk, listServiceTechnique);
    ConnectorResponse<Retour, PFI> rpgResponse = new ConnectorResponse<>(retourOk, pfi);

    // Mock du RSTProxy.serviceTechniqueLireUn
    EasyMock.expect(RSTProxy.getInstance()).andReturn(_rstProxyMock);
    EasyMock.expect(_rstProxyMock.serviceTechniqueLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(idSt))).andReturn(rstResponse);

    // Mock du RPGProxy.pfiLireUn
    EasyMock.expect(RPGProxy.getInstance()).andReturn(_rpgProxyMock);
    EasyMock.expect(_rpgProxyMock.pfiLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(stLienAllocationCommercial.getClientOperateur()), EasyMock.eq(stLienAllocationCommercial.getNoCompte()))).andReturn(rpgResponse);

    //Mock Activity - BL5250_ExtraireCaracteristiquesCommunes
    PowerMock.expectNew(BL5250_ExtraireCaracteristiquesCommunesBuilder.class).andReturn(_bl5250BuilderMock);
    EasyMock.expect(_bl5250BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl5250BuilderMock);
    EasyMock.expect(_bl5250BuilderMock.pfi(pfi)).andReturn(_bl5250BuilderMock);

    //Build Activity - BL5250_ExtraireCaracteristiquesCommunes
    EasyMock.expect(_bl5250BuilderMock.build()).andReturn(_bl5250Mock);
    EasyMock.expect(_bl5250Mock.execute(_processInstance)).andReturn(caracteristiqueCommune);
    EasyMock.expect(_bl5250Mock.getRetour()).andReturn(retourOk);

    //Mock Activity - BL5260_ExtraireCaracteristiquesSpecifiques
    PowerMock.expectNew(BL5260_ExtraireCaracteristiquesSpecifiquesBuilder.class).andReturn(_bl5260BuilderMock);
    EasyMock.expect(_bl5260BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl5260BuilderMock);
    EasyMock.expect(_bl5260BuilderMock.pfi(pfi)).andReturn(_bl5260BuilderMock);
    EasyMock.expect(_bl5260BuilderMock.identifiantFonctionnelIPA(stLienAllocationCommercial.getOcIdentifiantFonctionnelPA())).andReturn(_bl5260BuilderMock);

    //Build Activity - BL5260_ExtraireCaracteristiquesSpecifiques
    EasyMock.expect(_bl5260BuilderMock.build()).andReturn(_bl5260Mock);
    EasyMock.expect(_bl5260Mock.execute(_processInstance)).andReturn(null);
    EasyMock.expect(_bl5260Mock.getRetour()).andReturn(bl5260RetourKo);
    EasyMock.expect(_bl5260Mock.getRetour()).andReturn(bl5260RetourKo);

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();
    PI0252_Retour actualResponse = GsonTools.getIso8601Ms().fromJson(response.getGenericResponse().getResult(), PI0252_Retour.class);

    assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    checkRetour(expectedResponse.getRetour(), actualResponse.getRetour());
  }

  /**
   * Test case where RSTProxy.serviceTechniqueLireUn returns OK, RPGProxy.pfiLireUn returns OK, BL5250 returns OK,
   * BL5260 returns OK, Bl5220 returns KO
   *
   * <b> Expected: </ b> Return NOK (CAT3, ENTREE_INCORRECTE, Paramètre idSt null ou vide dans la requête.) <br/>
   *
   * @throws Throwable
   *           in case of error
   */
  @Test
  public void PI0252_AllouerRessourceRaccordementTest_KO_012() throws Throwable
  {
    com.bytel.ravel.types.Retour retourExpected = RetourConverter.convertToJsonRetour(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, StringUtils.EMPTY));
    PI0252_Retour expectedResponse = new PI0252_Retour(retourExpected);

    ReponseFonctionnelle reponseFonctionnelle = null;
    reponseFonctionnelle = new ReponseFonctionnelle();
    reponseFonctionnelle.setTracabilitePi(_tracabilite);
    expectedResponse.setReponseFonctionnelle(reponseFonctionnelle);

    String idRessource = "idRessource";//$NON-NLS-1$
    String idSt = "idSt"; //$NON-NLS-1$
    Request request = prepareRequest(idRessource, idSt);

    StLienAllocationCommercial stLienAllocationCommercial = new StLienAllocationCommercial("idStLac", Statut.INDETERMINE.name(), "ClientOperateur", "noCompte", TypeObjetCommercial.PA.name(), "ClientOperateur", "numCompte", idRessource, TypeRessource.RACCO.name()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
    stLienAllocationCommercial.setOcIdentifiantFonctionnelPA("ocIdentifiantFonctionnelPA"); //$NON-NLS-1$

    List<ServiceTechnique> listServiceTechnique = new ArrayList<>();
    listServiceTechnique.add(stLienAllocationCommercial);
    CaracteristiquesCommunes caracteristiqueCommune = new CaracteristiquesCommunes();
    caracteristiqueCommune.setClientOperateur("ClientOperateur"); //$NON-NLS-1$
    caracteristiqueCommune.setNoCompte("noCompte"); //$NON-NLS-1$
    CaracteristiquesSpecifiques caracteristiquesSpecifiques = new CaracteristiquesSpecifiques();
    caracteristiquesSpecifiques.setCodeAccesTechnique("codeAccesTechnique"); //$NON-NLS-1$
    caracteristiquesSpecifiques.setNomNR("nomNR"); //$NON-NLS-1$
    PFI pfi = new PFI();
    pfi.setClientOperateur("clientOp"); //$NON-NLS-1$

    Retour retourOk = RetourFactory.createOkRetour();
    Retour retourKo = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, StringUtils.EMPTY);

    ConnectorResponse<Retour, List<ServiceTechnique>> rstResponse = new ConnectorResponse<>(retourOk, listServiceTechnique);
    ConnectorResponse<Retour, PFI> rpgResponse = new ConnectorResponse<>(retourOk, pfi);

    // Mock du RSTProxy.serviceTechniqueLireUn
    EasyMock.expect(RSTProxy.getInstance()).andReturn(_rstProxyMock);
    EasyMock.expect(_rstProxyMock.serviceTechniqueLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(idSt))).andReturn(rstResponse);

    // Mock du RPGProxy.pfiLireUn
    EasyMock.expect(RPGProxy.getInstance()).andReturn(_rpgProxyMock);
    EasyMock.expect(_rpgProxyMock.pfiLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(stLienAllocationCommercial.getClientOperateur()), EasyMock.eq(stLienAllocationCommercial.getNoCompte()))).andReturn(rpgResponse);

    //Mock Activity - BL5250_ExtraireCaracteristiquesCommunes
    PowerMock.expectNew(BL5250_ExtraireCaracteristiquesCommunesBuilder.class).andReturn(_bl5250BuilderMock);
    EasyMock.expect(_bl5250BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl5250BuilderMock);
    EasyMock.expect(_bl5250BuilderMock.pfi(pfi)).andReturn(_bl5250BuilderMock);

    //Build Activity - BL5250_ExtraireCaracteristiquesCommunes
    EasyMock.expect(_bl5250BuilderMock.build()).andReturn(_bl5250Mock);
    EasyMock.expect(_bl5250Mock.execute(_processInstance)).andReturn(caracteristiqueCommune);
    EasyMock.expect(_bl5250Mock.getRetour()).andReturn(retourOk);

    //Mock Activity - BL5260_ExtraireCaracteristiquesSpecifiques
    PowerMock.expectNew(BL5260_ExtraireCaracteristiquesSpecifiquesBuilder.class).andReturn(_bl5260BuilderMock);
    EasyMock.expect(_bl5260BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl5260BuilderMock);
    EasyMock.expect(_bl5260BuilderMock.pfi(pfi)).andReturn(_bl5260BuilderMock);
    EasyMock.expect(_bl5260BuilderMock.identifiantFonctionnelIPA(stLienAllocationCommercial.getOcIdentifiantFonctionnelPA())).andReturn(_bl5260BuilderMock);

    //Build Activity - BL5260_ExtraireCaracteristiquesSpecifiques
    EasyMock.expect(_bl5260BuilderMock.build()).andReturn(_bl5260Mock);
    EasyMock.expect(_bl5260Mock.execute(_processInstance)).andReturn(caracteristiquesSpecifiques);
    EasyMock.expect(_bl5260Mock.getRetour()).andReturn(retourOk);

    //Mock Activity - BL5220_AllouerRessourceRaccordement
    PowerMock.expectNew(BL5220_AllouerRessourceRaccordementBuilder.class).andReturn(_bl5220BuilderMock);
    EasyMock.expect(_bl5220BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl5220BuilderMock);
    EasyMock.expect(_bl5220BuilderMock.idRessource(idRessource)).andReturn(_bl5220BuilderMock);
    EasyMock.expect(_bl5220BuilderMock.idLienAllocation(idSt)).andReturn(_bl5220BuilderMock);
    EasyMock.expect(_bl5220BuilderMock.caracteristiquesCommunes(caracteristiqueCommune)).andReturn(_bl5220BuilderMock);
    EasyMock.expect(_bl5220BuilderMock.caracteristiquesSpecifiques(caracteristiquesSpecifiques)).andReturn(_bl5220BuilderMock);

    //Build Activity - BL5220_AllouerRessourceRaccordement
    EasyMock.expect(_bl5220BuilderMock.build()).andReturn(_bl5220Mock);
    EasyMock.expect(_bl5220Mock.execute(_processInstance)).andReturn(null);
    EasyMock.expect(_bl5220Mock.getRetour()).andReturn(retourKo);

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();
    PI0252_Retour actualResponse = GsonTools.getIso8601Ms().fromJson(response.getGenericResponse().getResult(), PI0252_Retour.class);

    assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    checkRetour(expectedResponse.getRetour(), actualResponse.getRetour());
  }

  /**
   * Test case where RSTProxy.serviceTechniqueLireUn returns KO CAT-4 DONNEE_INCONNUE.
   *
   * <b> Expected: </ b> Return NOK (CAT1, SERVICE_TIERS_INDISPONIBLE, "") <br/>
   *
   * @throws Throwable
   *           in case of error
   */
  @Test
  public void PI0252_AllouerRessourceRaccordementTest_KO_013() throws Throwable
  {
    com.bytel.ravel.types.Retour retourExpected = RetourConverter.convertToJsonRetour(RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, StringUtils.EMPTY));
    PI0252_Retour expectedResponse = new PI0252_Retour(retourExpected);

    ReponseFonctionnelle reponseFonctionnelle = null;
    reponseFonctionnelle = new ReponseFonctionnelle();
    reponseFonctionnelle.setTracabilitePi(_tracabilite);
    expectedResponse.setReponseFonctionnelle(reponseFonctionnelle);

    String idRessource = "idRessource";//$NON-NLS-1$
    String idSt = "idSt"; //$NON-NLS-1$
    Request request = prepareRequest(idRessource, idSt);

    Retour rstRetourKo = RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, StringUtils.EMPTY);
    List<ServiceTechnique> listServiceTechnique = new ArrayList<>();
    ConnectorResponse<Retour, List<ServiceTechnique>> rstResponse = new ConnectorResponse<Retour, List<ServiceTechnique>>(rstRetourKo, listServiceTechnique);

    // Mock du RSTProxy.serviceTechniqueLireUn
    EasyMock.expect(RSTProxy.getInstance()).andReturn(_rstProxyMock);
    EasyMock.expect(_rstProxyMock.serviceTechniqueLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(idSt))).andReturn(rstResponse);

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();
    PI0252_Retour actualResponse = GsonTools.getIso8601Ms().fromJson(response.getGenericResponse().getResult(), PI0252_Retour.class);

    assertEquals(ErrorCode.KO_00404, response.getErrorCode());
    checkRetour(expectedResponse.getRetour(), actualResponse.getRetour());
  }

  /**
   * Test case where RSTProxy.serviceTechniqueLireUn returns OK, RPGProxy.pfiLireUn returns OK, BL5250 returns OK,
   * BL5260 returns OK, Bl5220 returns OK
   *
   * <b> Expected: </ b> Return NOK (CAT3, ENTREE_INCORRECTE, Paramètre idSt null ou vide dans la requête.) <br/>
   *
   * @throws Throwable
   *           in case of error
   */
  @Test
  public void PI0252_AllouerRessourceRaccordementTest_OK_001() throws Throwable
  {
    com.bytel.ravel.types.Retour retourExpected = RetourConverter.convertToJsonRetour(RetourFactory.createOkRetour());
    PI0252_Retour expectedResponse = new PI0252_Retour(retourExpected);

    ReponseFonctionnelle reponseFonctionnelle = null;
    reponseFonctionnelle = new ReponseFonctionnelle();
    reponseFonctionnelle.setTracabilitePi(_tracabilite);
    expectedResponse.setReponseFonctionnelle(reponseFonctionnelle);

    String idRessource = "idRessource";//$NON-NLS-1$
    String idSt = "idSt"; //$NON-NLS-1$
    Request request = prepareRequest(idRessource, idSt);

    StLienAllocationCommercial stLienAllocationCommercial = new StLienAllocationCommercial("idStLac", Statut.INDETERMINE.name(), "ClientOperateur", "noCompte", TypeObjetCommercial.PA.name(), "ClientOperateur", "numCompte", idRessource, TypeRessource.RACCO.name()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
    stLienAllocationCommercial.setOcIdentifiantFonctionnelPA("ocIdentifiantFonctionnelPA"); //$NON-NLS-1$

    List<ServiceTechnique> listServiceTechnique = new ArrayList<>();
    listServiceTechnique.add(stLienAllocationCommercial);
    CaracteristiquesCommunes caracteristiqueCommune = new CaracteristiquesCommunes();
    caracteristiqueCommune.setClientOperateur("ClientOperateur"); //$NON-NLS-1$
    caracteristiqueCommune.setNoCompte("noCompte"); //$NON-NLS-1$
    CaracteristiquesSpecifiques caracteristiquesSpecifiques = new CaracteristiquesSpecifiques();
    caracteristiquesSpecifiques.setCodeAccesTechnique("codeAccesTechnique"); //$NON-NLS-1$
    caracteristiquesSpecifiques.setNomNR("nomNR"); //$NON-NLS-1$
    PFI pfi = new PFI();
    pfi.setClientOperateur("clientOp"); //$NON-NLS-1$

    Retour retourOk = RetourFactory.createOkRetour();

    ConnectorResponse<Retour, List<ServiceTechnique>> rstResponse = new ConnectorResponse<>(retourOk, listServiceTechnique);
    ConnectorResponse<Retour, PFI> rpgResponse = new ConnectorResponse<>(retourOk, pfi);
    // Mock du RSTProxy.serviceTechniqueLireUn
    EasyMock.expect(RSTProxy.getInstance()).andReturn(_rstProxyMock);
    EasyMock.expect(_rstProxyMock.serviceTechniqueLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(idSt))).andReturn(rstResponse);

    // Mock du RPGProxy.pfiLireUn
    EasyMock.expect(RPGProxy.getInstance()).andReturn(_rpgProxyMock);
    EasyMock.expect(_rpgProxyMock.pfiLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(stLienAllocationCommercial.getClientOperateur()), EasyMock.eq(stLienAllocationCommercial.getNoCompte()))).andReturn(rpgResponse);

    //Mock Activity - BL5250_ExtraireCaracteristiquesCommunes
    PowerMock.expectNew(BL5250_ExtraireCaracteristiquesCommunesBuilder.class).andReturn(_bl5250BuilderMock);
    EasyMock.expect(_bl5250BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl5250BuilderMock);
    EasyMock.expect(_bl5250BuilderMock.pfi(pfi)).andReturn(_bl5250BuilderMock);

    //Build Activity - BL5250_ExtraireCaracteristiquesCommunes
    EasyMock.expect(_bl5250BuilderMock.build()).andReturn(_bl5250Mock);
    EasyMock.expect(_bl5250Mock.execute(_processInstance)).andReturn(caracteristiqueCommune);
    EasyMock.expect(_bl5250Mock.getRetour()).andReturn(retourOk);

    //Mock Activity - BL5260_ExtraireCaracteristiquesSpecifiques
    PowerMock.expectNew(BL5260_ExtraireCaracteristiquesSpecifiquesBuilder.class).andReturn(_bl5260BuilderMock);
    EasyMock.expect(_bl5260BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl5260BuilderMock);
    EasyMock.expect(_bl5260BuilderMock.pfi(pfi)).andReturn(_bl5260BuilderMock);
    EasyMock.expect(_bl5260BuilderMock.identifiantFonctionnelIPA(stLienAllocationCommercial.getOcIdentifiantFonctionnelPA())).andReturn(_bl5260BuilderMock);

    //Build Activity - BL5260_ExtraireCaracteristiquesSpecifiques
    EasyMock.expect(_bl5260BuilderMock.build()).andReturn(_bl5260Mock);
    EasyMock.expect(_bl5260Mock.execute(_processInstance)).andReturn(caracteristiquesSpecifiques);
    EasyMock.expect(_bl5260Mock.getRetour()).andReturn(retourOk);

    //Mock Activity - BL5220_AllouerRessourceRaccordement
    PowerMock.expectNew(BL5220_AllouerRessourceRaccordementBuilder.class).andReturn(_bl5220BuilderMock);
    EasyMock.expect(_bl5220BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl5220BuilderMock);
    EasyMock.expect(_bl5220BuilderMock.idRessource(idRessource)).andReturn(_bl5220BuilderMock);
    EasyMock.expect(_bl5220BuilderMock.idLienAllocation(idSt)).andReturn(_bl5220BuilderMock);
    EasyMock.expect(_bl5220BuilderMock.caracteristiquesCommunes(caracteristiqueCommune)).andReturn(_bl5220BuilderMock);
    EasyMock.expect(_bl5220BuilderMock.caracteristiquesSpecifiques(caracteristiquesSpecifiques)).andReturn(_bl5220BuilderMock);

    //Build Activity - BL5220_AllouerRessourceRaccordement
    EasyMock.expect(_bl5220BuilderMock.build()).andReturn(_bl5220Mock);
    EasyMock.expect(_bl5220Mock.execute(_processInstance)).andReturn(null);
    EasyMock.expect(_bl5220Mock.getRetour()).andReturn(retourOk);

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();
    PI0252_Retour actualResponse = GsonTools.getIso8601Ms().fromJson(response.getGenericResponse().getResult(), PI0252_Retour.class);

    assertEquals(ErrorCode.OK_00200, response.getErrorCode());
    checkRetour(expectedResponse.getRetour(), actualResponse.getRetour());
  }

  /**
   * Initialization method: Create: - spring context - connectors - service manager.
   *
   * @throws RavelException
   *           the exception
   */
  @Before
  public void setUp() throws RavelException
  {
    _processInstance = new PI0252_AllouerRessourceRaccordement();
    _processInstance.initializeContext();

    _tracabilite = new Tracabilite();
    _tracabilite.setIdCorrelationByTel("125667889000877"); //$NON-NLS-1$
    _tracabilite.setIdProcessusSpirit(_processInstance.getIdProcess());
    _tracabilite.setIdCorrelationSpirit(Test_Consts.DEFAULT_MSGID);
    _tracabilite.setNomProcessus(StringConstants.EMPTY_STRING);
    _tracabilite.setNomSysteme(System.getenv("SERVICE")); //$NON-NLS-1$

    PowerMock.resetAll();
    PowerMock.mockStatic(RSTProxy.class);
    PowerMock.mockStatic(RPGProxy.class);

  }

  /**
   * Compares 2 retours field by field.
   *
   * @param expected_p
   *          retour expected
   * @param actual_p
   *          retour actual
   */
  private void checkRetour(com.bytel.ravel.types.Retour expected_p, com.bytel.ravel.types.Retour actual_p)
  {
    assertEquals(expected_p.getResultat(), actual_p.getResultat());
    assertEquals(expected_p.getCategorie(), actual_p.getCategorie());
    assertEquals(expected_p.getDiagnostic(), actual_p.getDiagnostic());
    assertEquals(expected_p.getLibelle(), actual_p.getLibelle());
  }

  /**
   * Create a Generic Request to call PI0252
   *
   * @param idRessource_p
   *          The idRessource to add to the body
   * @param idSt_p
   *          The idSt to add to the body
   *
   * @return GenericRequest to call PI0252
   *
   * @throws RavelException
   *           on error
   */
  private Request prepareRequest(String idRessource_p, String idSt_p) throws RavelException
  {
    Request request = new Request(PI0252_AllouerRessourceRaccordement.class.getSimpleName(), "idProcess", "idClient"); //$NON-NLS-1$ //$NON-NLS-2$
    request.setMsgId(Test_Consts.DEFAULT_MSGID);
    request.setContentType("application/json"); //$NON-NLS-1$

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();

    if (idRessource_p != null)
    {
      list.add(new Parameter(PI0252_AllouerRessourceRaccordement.ParameterUrl.idRessource.name(), idRessource_p));
    }
    if (idSt_p != null)
    {
      list.add(new Parameter(PI0252_AllouerRessourceRaccordement.ParameterUrl.idSt.name(), idSt_p));
    }
    urlParametersType.setUrlParameters(list);
    request.setUrlParameters(urlParametersType);

    return request;
  }

}
