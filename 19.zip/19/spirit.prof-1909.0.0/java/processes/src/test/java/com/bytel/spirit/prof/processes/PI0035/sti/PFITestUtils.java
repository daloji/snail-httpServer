/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PI0035.sti;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import com.bytel.spirit.common.shared.saab.cmd.ModificationCommerciale;
import com.bytel.spirit.common.shared.saab.res.AccesTechnique;
import com.bytel.spirit.common.shared.saab.res.Ressource;
import com.bytel.spirit.common.shared.saab.res.RessourceAggregeP2P;
import com.bytel.spirit.common.shared.saab.res.TypeRessourceAggrege;
import com.bytel.spirit.common.shared.saab.rpg.AccessTechniqueCommercial;
import com.bytel.spirit.common.shared.saab.rpg.ContexteInstallation;
import com.bytel.spirit.common.shared.saab.rpg.EquipementDeclare;
import com.bytel.spirit.common.shared.saab.rpg.InfoBrutBssEnt;
import com.bytel.spirit.common.shared.saab.rpg.LienEquipementPA;
import com.bytel.spirit.common.shared.saab.rpg.LienSAPA;
import com.bytel.spirit.common.shared.saab.rpg.PA;
import com.bytel.spirit.common.shared.saab.rpg.PFI;
import com.bytel.spirit.common.shared.saab.rpg.PaTypeCompteAcces;
import com.bytel.spirit.common.shared.saab.rpg.PaTypeCompteAccesSecondaire;
import com.bytel.spirit.common.shared.saab.rpg.PaTypeFax;
import com.bytel.spirit.common.shared.saab.rpg.PaTypeLigneFixe;
import com.bytel.spirit.common.shared.saab.rpg.PaTypeTv;
import com.bytel.spirit.common.shared.saab.rpg.PaTypeVoip;
import com.bytel.spirit.common.shared.saab.rpg.RaccordementCommercial;
import com.bytel.spirit.common.shared.saab.rpg.SA;
import com.bytel.spirit.common.shared.saab.rpg.Titulaire;
import com.bytel.spirit.common.shared.saab.rpg.TypePA;
import com.bytel.spirit.common.shared.saab.rpg.TypeTitulaire;

/**
 *
 * @author jgregori
 * @version ($Revision$ $Date$)
 */
public final class PFITestUtils
{
  /**
   * Assert that each attributes of {@link PI0035_AccesTechnique} is equal to
   * {@link com.bytel.spirit.common.shared.saab.res.AccesTechnique}
   *
   * @param accesTechnique_p
   *          {@link com.bytel.spirit.common.shared.saab.res.AccesTechnique}
   * @param pi0035_accesTechnique_p
   *          {@link PI0035_AccesTechnique}
   */
  public static void assertAccesTechnique(AccesTechnique accesTechnique_p, PI0035_AccesTechnique pi0035_accesTechnique_p)
  {
    assertEquals(accesTechnique_p.getCodeAccesTechnique(), pi0035_accesTechnique_p.getCodeAccesTechnique());
    assertEquals(accesTechnique_p.getGammeTechno(), pi0035_accesTechnique_p.getGammeTechno());
    assertEquals(accesTechnique_p.getCouverture(), pi0035_accesTechnique_p.getCouverture());
    assertEquals(accesTechnique_p.getNormeTechno(), pi0035_accesTechnique_p.getNormeTechno());
    assertEquals(accesTechnique_p.getLigneMarche(), pi0035_accesTechnique_p.getLigneMarche());
    assertEquals(accesTechnique_p.getTechno(), pi0035_accesTechnique_p.getTechno());
    assertEquals(accesTechnique_p.getDebitDescendantMax(), pi0035_accesTechnique_p.getDebitDescendantMax());
    assertEquals(accesTechnique_p.getDebitMontantMax(), pi0035_accesTechnique_p.getDebitMontantMax());
  }

  /**
   * Assert that each attributes of {@link PI0035_AccesTechniqueCommercial} is equal to
   * {@link com.bytel.spirit.common.shared.saab.rpg.AccessTechniqueCommercial}
   *
   * @param accessTechniqueCommercial_p
   *          {@link com.bytel.spirit.common.shared.saab.rpg.AccessTechniqueCommercial}
   * @param pi0035_accesTechniqueCommercial_p
   *          {@link PI0035_AccesTechniqueCommercial}
   */
  public static void assertAccesTechniqueCommercial(AccessTechniqueCommercial accessTechniqueCommercial_p, PI0035_AccesTechniqueCommercial pi0035_accesTechniqueCommercial_p)
  {
    assertEquals(accessTechniqueCommercial_p.getTechnologieAcces(), pi0035_accesTechniqueCommercial_p.getTechnologieAcces());
    assertEquals(accessTechniqueCommercial_p.getCodeAccesTechnique(), pi0035_accesTechniqueCommercial_p.getCodeAccesTechnique());
  }

  /**
   * Assert that each attributes of {@link PI0035_ContexteInstallation} is equal to
   * {@link com.bytel.spirit.common.shared.saab.rpg.ContexteInstallation}
   *
   * @param cI_p
   *          {@link com.bytel.spirit.common.shared.saab.rpg.ContexteInstallation}
   * @param pfiCcI_p
   *          {@link PI0035_ContexteInstallation}
   *
   */
  public static void assertContexteInstallation(ContexteInstallation cI_p, PI0035_ContexteInstallation pfiCcI_p)
  {
    assertEquals(cI_p.getIdMandat(), pfiCcI_p.getIdMandat());
    assertEquals(cI_p.getTypeMes(), pfiCcI_p.getTypeMes());
    assertEquals(cI_p.getDateClient(), pfiCcI_p.getDateClient());
    assertEquals(cI_p.getCreneauClient(), pfiCcI_p.getCreneauClient());
    assertEquals(cI_p.getIdRdv(), pfiCcI_p.getIdRdv());
    assertEquals(cI_p.getPrestataire(), pfiCcI_p.getPrestataire());
    assertEquals(cI_p.getCommentaire(), pfiCcI_p.getCommentaire());
  }

  /**
   * Assert that each attributes of {@link PI0035_Entreprise} is equal to
   * {@link com.bytel.spirit.common.shared.saab.rpg.Entreprise}
   *
   * @param ent_p
   *          {@link com.bytel.spirit.common.shared.saab.rpg.Entreprise}
   * @param pfiSimpleEnt_p
   *          {@link PI0035_Entreprise}
   *
   */
  public static void assertEntreprise(com.bytel.spirit.common.shared.saab.rpg.Entreprise ent_p, PI0035_Entreprise pfiSimpleEnt_p)
  {
    assertEquals(ent_p.getNoSiren(), pfiSimpleEnt_p.getNoSiren());
    assertEquals(ent_p.getRaisonSociale(), pfiSimpleEnt_p.getRaisonSociale());
  }

  /**
   * Assert that each attributes of {@link PI0035_EquipementDeclare} is equal to
   * {@link com.bytel.spirit.common.shared.saab.rpg.EquipementDeclare}
   *
   * @param eqtDeclare_p
   *          {@link com.bytel.spirit.common.shared.saab.rpg.EquipementDeclare}
   * @param pi0035EqtDeclare_p
   *          {@link PI0035_Entreprise}
   */
  public static void assertEquipementDeclare(EquipementDeclare eqtDeclare_p, PI0035_EquipementDeclare pi0035EqtDeclare_p)
  {
    assertEquals(eqtDeclare_p.getNoEquipement(), pi0035EqtDeclare_p.getNoEquipement());
    assertEquals(eqtDeclare_p.getStatut().name(), pi0035EqtDeclare_p.getStatut());
    assertEquals(eqtDeclare_p.getNoIdentifiant(), pi0035EqtDeclare_p.getNoIdentifiant());
    assertEquals(eqtDeclare_p.getTypeEquipement(), pi0035EqtDeclare_p.getTypeEqtDeclare());
    assertEquals(eqtDeclare_p.getModele(), pi0035EqtDeclare_p.getModele());
    assertEquals(eqtDeclare_p.getNomFabricant(), pi0035EqtDeclare_p.getNomFabricant());
    assertEquals(eqtDeclare_p.getNoIdentifiantIadOnebox(), pi0035EqtDeclare_p.getNoIdentifiantIADOneBox());
    assertEquals(eqtDeclare_p.getModeleIadOnebox(), pi0035EqtDeclare_p.getModeleIADOneBox());
    assertEquals(eqtDeclare_p.getNoIdentifiantStbOnebox(), pi0035EqtDeclare_p.getNoIdentifiantSTBOneBox());
    assertEquals(eqtDeclare_p.getModeleStbOnebox(), pi0035EqtDeclare_p.getModeleSTBOneBox());
    assertEquals(eqtDeclare_p.getMacAddressModem(), pi0035EqtDeclare_p.getMacAdressModem());
    assertEquals(eqtDeclare_p.getMacAddressMta(), pi0035EqtDeclare_p.getMacAdressMta());
    assertEquals(eqtDeclare_p.getMacAddressGateway(), pi0035EqtDeclare_p.getMacAdressGateway());
    assertEquals(eqtDeclare_p.getMacAddressTv(), pi0035EqtDeclare_p.getMacAdressTV());
    assertEquals(eqtDeclare_p.getCodeEan(), pi0035EqtDeclare_p.getCodeEAN());
    assertEquals(eqtDeclare_p.getNoEquipementLie(), pi0035EqtDeclare_p.getNoEquipementLie());
    assertEquals(eqtDeclare_p.getDateCreation(), pi0035EqtDeclare_p.getDateCreation());
    assertEquals(eqtDeclare_p.getDateModification(), pi0035EqtDeclare_p.getDateModification());

  }

  /**
   * Assert that each attributes of {@link PI0035_Individu} is equal to
   * {@link com.bytel.spirit.common.shared.saab.rpg.Individu}
   *
   * @param individu_p
   *          {@link PI0035_Individu}
   * @param pfiSimpleIndividu_p
   *          {@link com.bytel.spirit.common.shared.saab.rpg.Individu}
   */
  public static void assertIndividu(com.bytel.spirit.common.shared.saab.rpg.Individu individu_p, PI0035_Individu pfiSimpleIndividu_p)
  {
    assertEquals(individu_p.getNom(), pfiSimpleIndividu_p.getNom());
    assertEquals(individu_p.getPrenom(), pfiSimpleIndividu_p.getPrenom());
    assertEquals(individu_p.getCivilite(), pfiSimpleIndividu_p.getCivilite());
  }

  /**
   * Assert that each attributes of {@link PI0035_InfoBruteBssENT} is equal to
   * {@link com.bytel.spirit.common.shared.saab.rpg.InfoBrutBssEnt}
   *
   * @param infoBruteBss_p
   *          {@link com.bytel.spirit.common.shared.saab.rpg.InfoBrutBssEnt}
   * @param pfiCInfoBruteBss_p
   *          {@link PI0035_InfoBruteBssENT}
   *
   */
  public static void assertInfoBruteBSSEnt(InfoBrutBssEnt infoBruteBss_p, PI0035_InfoBruteBssENT pfiCInfoBruteBss_p)
  {
    assertEquals(infoBruteBss_p.getCodeOffre(), pfiCInfoBruteBss_p.getCodeOffre());
    assertEquals(infoBruteBss_p.getNdi(), pfiCInfoBruteBss_p.getNdi());
    assertEquals(infoBruteBss_p.getNdiActif(), pfiCInfoBruteBss_p.getNdiActif());
    assertEquals(infoBruteBss_p.getNdiAssocie(), pfiCInfoBruteBss_p.getNdiAssocie());
    assertEquals(infoBruteBss_p.getNdiVoisin(), pfiCInfoBruteBss_p.getNdiVoisin());
  }

  /**
   * Assert that each attributes of {@link PI0035_LienEqtPa} is equal to
   * {@link com.bytel.spirit.common.shared.saab.rpg.LienEquipementPA}
   *
   *
   * @param lienEqtPa_p
   *          {@link com.bytel.spirit.common.shared.saab.rpg.LienEquipementPA}
   * @param pfiCompLienEqtPa_p
   *          {@link PI0035_LienEqtPa}
   */
  public static void assertLienEqtPA(LienEquipementPA lienEqtPa_p, PI0035_LienEqtPa pfiCompLienEqtPa_p)
  {
    assertEquals(lienEqtPa_p.getNoEquipement(), pfiCompLienEqtPa_p.getNoEquipement());
    assertEquals(lienEqtPa_p.getIdFonctionnelPa(), pfiCompLienEqtPa_p.getIdentifiantFonctionnelPA());
    assertEquals(lienEqtPa_p.getStatut().name(), pfiCompLienEqtPa_p.getStatut());
    assertEquals(lienEqtPa_p.getDateCreation(), pfiCompLienEqtPa_p.getDateCreation());
    assertEquals(lienEqtPa_p.getDateModification(), pfiCompLienEqtPa_p.getDateModification());

  }

  /**
   * Assert that each attributes of {@link PI0035_LienSaPa} is equal to
   * {@link com.bytel.spirit.common.shared.saab.rpg.LienSAPA}
   *
   *
   * @param lienSaPa_p
   *          {@link com.bytel.spirit.common.shared.saab.rpg.LienSAPA}
   * @param pi0035LienSaPa_p
   *          {@link PI0035_LienSaPa}
   */
  public static void assertLienSAPA(LienSAPA lienSaPa_p, PI0035_LienSaPa pi0035LienSaPa_p)
  {
    assertEquals(lienSaPa_p.getNoServiceAccessible(), pi0035LienSaPa_p.getNoServiceAccessible());
    assertEquals(lienSaPa_p.getIdentifiantFonctionnelPA(), pi0035LienSaPa_p.getIdentifiantFonctionnelPA());
    assertEquals(lienSaPa_p.getStatut().name(), pi0035LienSaPa_p.getStatut());
    assertEquals(lienSaPa_p.getDateCreation(), pi0035LienSaPa_p.getDateCreation());
    assertEquals(lienSaPa_p.getDateModification(), pi0035LienSaPa_p.getDateModification());

  }

  /**
   * Assert that each attributes of {@link PI0035_ModificationCommerciale} is equal to
   * {@link com.bytel.spirit.common.shared.saab.cmd.ModificationCommerciale}
   *
   * @param modComm_p
   *          {@link com.bytel.spirit.common.shared.saab.cmd.ModificationCommerciale}
   * @param pi0035ModComm_p
   *          {@link PI0035_ModificationCommerciale}
   */
  public static void assertModificationCommerciale(ModificationCommerciale modComm_p, PI0035_ModificationCommerciale pi0035ModComm_p)
  {
    assertEquals(modComm_p.getIdModificationCommerciale(), pi0035ModComm_p.getIdModificationCommerciale());
    assertEquals(modComm_p.getStatut(), pi0035ModComm_p.getStatut());
    assertEquals(modComm_p.getIdCmd(), pi0035ModComm_p.getIdCmd());
    assertEquals(modComm_p.getTypeObjetCommercial(), pi0035ModComm_p.getTypeObjetCommercial());
    assertEquals(modComm_p.getNoServiceAccessible(), pi0035ModComm_p.getNoServiceAccessible());
    assertEquals(modComm_p.getIdentifiantFonctionnelPA(), pi0035ModComm_p.getIdentifiantFonctionnelPA());
    assertEquals(modComm_p.getNoEquipement(), pi0035ModComm_p.getNoEquipement());
    assertEquals(modComm_p.getStatutCommercialAttendu(), pi0035ModComm_p.getStatutCommercialAttendu());
    assertEquals(modComm_p.getDateCreation(), pi0035ModComm_p.getDateCreation());
    assertEquals(modComm_p.getDateModification(), pi0035ModComm_p.getDateModification());
  }

  /**
   * Assert that each attributes of {@link PI0035_PA} is equal to {@link com.bytel.spirit.common.shared.saab.rpg.PA}
   *
   * @param pa_p
   *          {@link com.bytel.spirit.common.shared.saab.rpg.PA}
   * @param pfiCPa_p
   *          {@link PI0035_PA}
   */
  public static void assertPA(PA pa_p, PI0035_PA pfiCPa_p)
  {
    assertEquals(pa_p.getIdentifiantFonctionnelPA(), pfiCPa_p.getIdentifiantFonctionnelPA());
    assertEquals(pa_p.getStatut().name(), pfiCPa_p.getStatut());
    assertEquals(pa_p.getTypePA(), pfiCPa_p.getTypePA());
    assertEquals(pa_p.getIdentifiantFonctionnelPALie(), pfiCPa_p.getIdentifiantFonctionnelPALie());

    TypePA typePA = TypePA.valueOf(pa_p.getTypePA());

    switch (typePA)
    {
      case COMPTE_ACCES:
        PFITestUtils.assertPACA(pa_p.getPaTypeCompteAcces(), (PI0035_PACompteAcces) pfiCPa_p);
        break;
      case COMPTE_ACCES_SECONDAIRE:
        PFITestUtils.assertPACAS(pa_p.getPaTypeCompteAccesSecondaire(), (PI0035_PACompteAccesSecondaire) pfiCPa_p);
        break;
      case FAX:
        PFITestUtils.assertPAFAX(pa_p.getPaTypeFax(), (PI0035_PAFAX) pfiCPa_p);
        break;
      case LIGNE_FIXE:
        PFITestUtils.assertPALigneFixe(pa_p.getPaTypeLigneFixe(), (PI0035_PALigneFixe) pfiCPa_p);
        break;
      case TV:
        PFITestUtils.assertPATv(pa_p.getPaTypeTv(), (PI0035_PATV) pfiCPa_p);
        break;
      case VOIP:
        PFITestUtils.assertPAVoip(pa_p.getPaTypeVoip(), (PI0035_PAVoip) pfiCPa_p);
        break;
      default:
        fail();

    }
    assertEquals(pa_p.getDateCreation(), pfiCPa_p.getDateCreation());
    assertEquals(pa_p.getDateModification(), pfiCPa_p.getDateModification());
  }

  /**
   * Assert that each attributes of {@link PI0035_PACompteAcces} is equal to
   * {@link com.bytel.spirit.common.shared.saab.rpg.PaTypeCompteAcces}
   *
   * @param paCa
   *          {@link com.bytel.spirit.common.shared.saab.rpg.PaTypeCompteAcces}
   * @param pfiCPaCa_p
   *          {@link PI0035_PACompteAcces}
   */
  public static void assertPACA(PaTypeCompteAcces paCa, PI0035_PACompteAcces pfiCPaCa_p)
  {
    assertEquals(paCa.getEmailLogin(), pfiCPaCa_p.getLoginEmail());
  }

  /**
   * Assert that each attributes of {@link PI0035_PACompteAccesSecondaire} is equal to
   * {@link com.bytel.spirit.common.shared.saab.rpg.PaTypeCompteAccesSecondaire}
   *
   * @param paCaS_p
   *          {@link com.bytel.spirit.common.shared.saab.rpg.PaTypeCompteAccesSecondaire}
   * @param pfiCPaCaS_p
   *          {@link PI0035_PACompteAccesSecondaire}
   *
   */
  public static void assertPACAS(PaTypeCompteAccesSecondaire paCaS_p, PI0035_PACompteAccesSecondaire pfiCPaCaS_p)
  {
    assertEquals(paCaS_p.getLoginEmail(), pfiCPaCaS_p.getLoginEmail());
    assertEquals(paCaS_p.isIgnorerReconciliationInterne(), pfiCPaCaS_p.getIgnorerReconciliationInterne().booleanValue());
  }

  /**
   * Assert that each attributes of {@link PI0035_PAFAX} is equal to
   * {@link com.bytel.spirit.common.shared.saab.rpg.PaTypeFax}
   *
   * @param paFax_p
   *          {@link com.bytel.spirit.common.shared.saab.rpg.PaTypeFax}
   * @param pfiCPaFax_p
   *          {@link PI0035_PAFAX}
   *
   */
  public static void assertPAFAX(PaTypeFax paFax_p, PI0035_PAFAX pfiCPaFax_p)
  {
    assertEquals(paFax_p.getNumeroTelephone(), pfiCPaFax_p.getNumeroTelephone());
  }

  /**
   * Assert that each attributes of {@link PI0035_PALigneFixe} is equal to
   * {@link com.bytel.spirit.common.shared.saab.rpg.PaTypeLigneFixe}
   *
   * @param paLF_p
   *          {@link com.bytel.spirit.common.shared.saab.rpg.PaTypeLigneFixe}
   * @param pfiCPaLF_p
   *          {@link PI0035_PALigneFixe}
   *
   */
  public static void assertPALigneFixe(PaTypeLigneFixe paLF_p, PI0035_PALigneFixe pfiCPaLF_p)
  {
    assertEquals(paLF_p.getDatePriseEnCompteChangementStatut(), pfiCPaLF_p.getDatePriseEnCompteChangementStatut());
    assertEquals(paLF_p.getIdRaccordement(), pfiCPaLF_p.getIdRaccordement());
    PFITestUtils.assertInfoBruteBSSEnt(paLF_p.getInfoBrutBssEnt(), pfiCPaLF_p.getInfoBruteBssEnt());
    PFITestUtils.assertContexteInstallation(paLF_p.getContexteInstallation(), pfiCPaLF_p.getContexteInstallation());
  }

  /**
   * Assert that each attributes of {@link PI0035_PATV} is equal to
   * {@link com.bytel.spirit.common.shared.saab.rpg.PaTypeTv}
   *
   * @param paTv_p
   *          {@link com.bytel.spirit.common.shared.saab.rpg.PaTypeTv}
   * @param pfiCPaTv_p
   *          {@link PI0035_PATV}
   *
   */
  public static void assertPATv(PaTypeTv paTv_p, PI0035_PATV pfiCPaTv_p)
  {
    assertEquals(paTv_p.getIdCompteTv(), pfiCPaTv_p.getCompteTV());
    assertEquals(paTv_p.getIdContenuTv(), pfiCPaTv_p.getIdContenuTV());

  }

  /**
   * Assert that each attributes of {@link PI0035_PAVoip} is equal to
   * {@link com.bytel.spirit.common.shared.saab.rpg.PaTypeVoip}
   *
   * @param paVoip_p
   *          {@link com.bytel.spirit.common.shared.saab.rpg.PaTypeVoip}
   * @param pfiCPaVoip_p
   *          {@link PI0035_PAVoip}
   *
   */
  public static void assertPAVoip(PaTypeVoip paVoip_p, PI0035_PAVoip pfiCPaVoip_p)
  {
    assertEquals(paVoip_p.getNumeroTelephone(), pfiCPaVoip_p.getNumeroTelephone());
    assertEquals(paVoip_p.getCodeRio(), pfiCPaVoip_p.getCodeRIO());
    assertEquals(paVoip_p.getNumeroPortTelephonique(), pfiCPaVoip_p.getNumPortTelephonique());

  }

  /**
   * Assert that each attributes of {@link PI0035_PFI} is equal to {@link com.bytel.spirit.common.shared.saab.rpg.PFI}
   *
   * @param pfi_p
   *          {@link com.bytel.spirit.common.shared.saab.rpg.PFI}
   * @param pi0035PFI_p
   *          {@link PI0035_PFI}
   *
   */
  public static void assertPFI(PFI pfi_p, PI0035_PFI pi0035PFI_p)
  {
    assertEquals(pfi_p.getClientOperateur(), pi0035PFI_p.getClientOperateur());
    assertEquals(pfi_p.getNoCompte(), pi0035PFI_p.getNoCompte());
    assertEquals(pfi_p.getStatut().name(), pi0035PFI_p.getStatut());
    assertEquals(pfi_p.getLigneMarche(), pi0035PFI_p.getLigneMarche());
    assertEquals(pfi_p.getDateCreation(), pi0035PFI_p.getDateCreation());
    assertEquals(pfi_p.getDateModification(), pi0035PFI_p.getDateModification());
    PFITestUtils.assertTitulaire(pfi_p.getTitulaire(), pi0035PFI_p.getTitulaire());

  }

  /**
   * Assert that each attributes of {@link PI0035_RaccordementCommercial} is equal to
   * {@link com.bytel.spirit.common.shared.saab.rpg.RaccordementCommercial}
   *
   * @param raccordementCommercial_p
   *          {@link com.bytel.spirit.common.shared.saab.rpg.RaccordementCommercial}
   * @param pi0035_raccordementCommercial_p
   *          {@link PI0035_RaccordementCommercial}
   */
  public static void assertRaccordementCommercial(RaccordementCommercial raccordementCommercial_p, PI0035_RaccordementCommercial pi0035_raccordementCommercial_p)
  {
    PFITestUtils.assertAccesTechniqueCommercial(raccordementCommercial_p.getAccesTechniqueCommercial(), pi0035_raccordementCommercial_p.getAccesTechniqueCommercial());
    assertEquals(raccordementCommercial_p.getCodeNro(), pi0035_raccordementCommercial_p.getCodeNro());
  }

  /**
   * Assert that each attributes of {@link PI0035_RessourceAggregeP2P} is equal to
   * {@link com.bytel.spirit.common.shared.saab.res.RessourceAggregeP2P}
   *
   * @param ressourceAggregeP2P_p
   *          {@link com.bytel.spirit.common.shared.saab.res.RessourceAggregeP2P}
   * @param pi0035_ressourceAggregeP2P_p
   *          {@link PI0035_RessourceAggregeP2P}
   */
  public static void assertRessourceAggrege(RessourceAggregeP2P ressourceAggregeP2P_p, PI0035_RessourceAggregeP2P pi0035_ressourceAggregeP2P_p)
  {
    assertEquals(TypeRessourceAggrege.P2P.name(), pi0035_ressourceAggregeP2P_p.getTypeRessourceAggrege());
    assertEquals(ressourceAggregeP2P_p.getNomOLT(), pi0035_ressourceAggregeP2P_p.getNomOLT());
    assertEquals(Integer.valueOf(ressourceAggregeP2P_p.getPositionCarteP2P()), Integer.valueOf(pi0035_ressourceAggregeP2P_p.getPositionCarteP2P()));
    assertEquals(Integer.valueOf(ressourceAggregeP2P_p.getPositionCageP2P()), Integer.valueOf(pi0035_ressourceAggregeP2P_p.getPositionCageP2P()));
    assertEquals(Integer.valueOf(ressourceAggregeP2P_p.getPositionPortP2P()), Integer.valueOf(pi0035_ressourceAggregeP2P_p.getPositionPortP2P()));
  }

  /**
   * Assert that each attributes of {@link PI0035_RessourceRaccordement} is equal to
   * {@link com.bytel.spirit.common.shared.saab.res.Ressource}
   *
   * @param ressource_p
   *          {@link com.bytel.spirit.common.shared.saab.res.Ressource}
   * @param pi0035_ressourceRaccordement_p
   *          {@link PI0035_RessourceRaccordement}
   */
  public static void assertRessourceRaccordement(Ressource ressource_p, PI0035_RessourceRaccordement pi0035_ressourceRaccordement_p)
  {
    assertEquals(ressource_p.getIdRessource(), pi0035_ressourceRaccordement_p.getIdRessource());
    assertEquals(ressource_p.getTypeRessource(), pi0035_ressourceRaccordement_p.getTypeRessource());
    assertEquals(ressource_p.getStatut(), pi0035_ressourceRaccordement_p.getStatut());
    assertEquals(ressource_p.getIdSt(), pi0035_ressourceRaccordement_p.getIdST());
    assertEquals(ressource_p.getDateCreation(), pi0035_ressourceRaccordement_p.getDateCreation());
    assertEquals(ressource_p.getDateModification(), pi0035_ressourceRaccordement_p.getDateModification());
    assertEquals(ressource_p.getRessourceRaccordement().getTypeRaccordement(), pi0035_ressourceRaccordement_p.getTypeRaccordement());
    assertEquals(ressource_p.getRessourceRaccordement().getNomNR(), pi0035_ressourceRaccordement_p.getNomNR());
  }

  /**
   * Assert that each attributes of {@link PI0035_SA} is equal to {@link com.bytel.spirit.common.shared.saab.rpg.SA}
   *
   * @param sa_p
   *          {@link com.bytel.spirit.common.shared.saab.rpg.SA}
   * @param pfiCompletSA_p
   *          {@link PI0035_SA}
   */
  public static void assertSA(SA sa_p, PI0035_SA pfiCompletSA_p)
  {
    assertEquals(sa_p.getNoServiceAccessible(), pfiCompletSA_p.getNoServiceAccessible());
    assertEquals(sa_p.getStatut().name(), pfiCompletSA_p.getStatut());
    assertEquals(sa_p.getNoServiceCommercial(), pfiCompletSA_p.getNoServiceCommercial());
    assertEquals(sa_p.getCategorieServiceCommercial(), pfiCompletSA_p.getCategorieServiceCommercial());
    assertEquals(sa_p.getNomServiceCommercial(), pfiCompletSA_p.getNomServiceCommercial());
    assertEquals(sa_p.getDateCreation(), pfiCompletSA_p.getDateCreation());
    assertEquals(sa_p.getDateModification(), pfiCompletSA_p.getDateModification());
  }

  /**
   * Assert that each attributes of {@link PI0035_Titulaire} is equal to
   * {@link com.bytel.spirit.common.shared.saab.rpg.Titulaire}
   *
   * @param titulaire_p
   *          {@link com.bytel.spirit.common.shared.saab.rpg.Titulaire}
   * @param pfiSimpleTitulaire_p
   *          {@link PI0035_Titulaire}
   *
   */
  public static void assertTitulaire(Titulaire titulaire_p, PI0035_Titulaire pfiSimpleTitulaire_p)
  {
    assertEquals(titulaire_p.getTypeTitulaire().name(), pfiSimpleTitulaire_p.getTypeTitulaire());
    if (TypeTitulaire.ENTREPRISE == titulaire_p.getTypeTitulaire())
    {
      PFITestUtils.assertEntreprise(titulaire_p.getEntreprise(), pfiSimpleTitulaire_p.getEntreprise());
    }
    else
    {
      PFITestUtils.assertIndividu(titulaire_p.getIndividu(), pfiSimpleTitulaire_p.getIndividu());
    }
  }

  /**
   * Utility class, so hide constructor
   */
  private PFITestUtils()
  {
    // Nothing to do
  }
}
