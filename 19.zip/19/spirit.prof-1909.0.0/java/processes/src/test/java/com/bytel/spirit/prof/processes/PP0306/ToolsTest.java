/*******************************************************************************
* $Id: ToolsTest.java 21377 2019-05-14 12:39:42Z lchanyip $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PP0306;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.Pair;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.services.utils.Test_Consts;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.mail.StPfsMail;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.olt.StPfsOlt;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.RetourConverter;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.rst.ServiceTechnique;
import com.bytel.spirit.common.shared.saab.rst.TypeST;
import com.bytel.spirit.prof.processes.Messages;

/**
 * Tools test class
 *
 * @author lchanyip
 * @version ($Revision: 21377 $ $Date: 2019-05-14 14:39:42 +0200 (mar. 14 mai 2019) $)
 */
public class ToolsTest
{

  /**
   * Tracabilite
   */
  private static Tracabilite _tracabilite;

  /**
   * Executed before all tests
   *
   * @throws Exception
   */
  @BeforeClass
  public static void executedBeforeAll() throws Exception
  {
    _tracabilite = new Tracabilite();
    _tracabilite.setIdProcessusSpirit(Test_Consts.DEFAULT_MSGID);
    _tracabilite.setIdCorrelationSpirit(Test_Consts.DEFAULT_MSGID);
    _tracabilite.setIdCorrelationByTel(StringConstants.EMPTY_STRING);
    _tracabilite.setNomProcessus(StringConstants.EMPTY_STRING);
    _tracabilite.setNomSysteme(System.getenv("SERVICE")); //$NON-NLS-1$
  }

  /**
   * Test createFileIfNotExists method
   */
  @Test
  public void testcreateFileIfNotExists()
  {
    String file = "src/test/resources/filetest.txt";
    File f = new File(file);
    if (f.exists())
    {
      f.delete();
    }

    Retour retour = Tools.createFileIfNotExists(_tracabilite, file);
    Assert.assertEquals(StringConstants.OK, retour.getResultat());
    Assert.assertTrue(new File(file).exists());
  }

  /**
   * Test filterEchecStatus method
   */
  @Test
  public void testfilterEchecStatus()
  {
    //Test null input list
    List<ServiceTechnique> result = Tools.filterEchecStatus(null);
    Assert.assertTrue(result.isEmpty());

    //Test empty input list
    result = Tools.filterEchecStatus(new ArrayList<>());
    Assert.assertTrue(result.isEmpty());

    //Test with non empty list
    StPfsMail st1 = new StPfsMail("idSt", com.bytel.spirit.common.shared.saab.rst.Statut.INACTIF.name(), "clientOperateur", "noCompte", null);
    StPfsOlt st2 = new StPfsOlt("idSt2", com.bytel.spirit.common.shared.saab.rst.Statut.ECHEC.name(), "clientOperateur2", "noCompte2", null);
    List<ServiceTechnique> list = Arrays.asList(st1, st2);
    result = Tools.filterEchecStatus(list);
    Assert.assertEquals(1, result.size());
    Assert.assertEquals("idSt2", result.get(0).getIdSt());
    Assert.assertEquals(TypeST.PFS.name(), result.get(0).getTypeServiceTechnique());
    Assert.assertEquals(com.bytel.spirit.common.shared.saab.rst.Statut.ECHEC.name(), result.get(0).getStatut());
    Assert.assertEquals("clientOperateur2", result.get(0).getClientOperateur());
    Assert.assertEquals("noCompte2", result.get(0).getNoCompte());
  }

  /**
   * Test getMapValue method
   */
  @Test
  public void testGetMapValue()
  {
    Map<String, String> map = new HashMap<String, String>();
    map.put("IdErreurSpirit", "test");

    Assert.assertEquals("test", Tools.getMapValue(map, "IdErreurSpirit"));
    Assert.assertEquals("test", Tools.getMapValue(map, "iderreurspirit"));
    Assert.assertNull(Tools.getMapValue(map, "xxx"));
  }

  /**
   * Test loading file src/test/resources/PP0306_ErreurSpirit_filters_test_empty.txt
   *
   * @throws Throwable
   */
  @Test
  public void testKOLoadFiltersFromConfigFile() throws Throwable
  {
    //test loading empty file
    Pair<Retour, List<Map<String, String>>> result = Tools.loadFiltersFromConfigFile(_tracabilite, "src/test/resources/PP0306_ErreurSpirit_filters_test_empty.txt");
    Assert.assertEquals(StringConstants.NOK, result._first.getResultat());
    Assert.assertEquals(IMegConsts.CAT4, result._first.getCategorie());
    Assert.assertEquals(IMegConsts.CONFIGURATION_INVALIDE, result._first.getDiagnostic());
    Assert.assertEquals(Messages.getString("PP0306.AucuneDecisionConfiguree"), result._first.getLibelle());

    //test file not found
    result = Tools.loadFiltersFromConfigFile(_tracabilite, "src/test/resources/xxx.txt");
    Assert.assertEquals(StringConstants.NOK, result._first.getResultat());
    Assert.assertEquals(IMegConsts.CAT3, result._first.getCategorie());
    Assert.assertEquals(IMegSpiritConsts.FICHIER_INCORRECT, result._first.getDiagnostic());
  }

  /**
   * Test matches method
   */
  @Test
  public void testMatches()
  {
    Pair<Retour, List<Map<String, String>>> result = Tools.loadFiltersFromConfigFile(_tracabilite, "src/test/resources/PP0306_ErreurSpirit_filters_test.txt");
    Assert.assertEquals("OK", result._first.getResultat());
    Assert.assertEquals(6, result._second.size());

    Retour retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.TRAITEMENT_ARRETE, "blablabla");
    Pair<Boolean, String> result2 = Tools.matches(RetourConverter.convertToJsonRetour(retour), result._second);
    Assert.assertEquals(true, result2._first);
    Assert.assertEquals("ACTION_CORRECTIVE", result2._second);

    retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.TRAITEMENT_ARRETE, "test does not match");
    result2 = Tools.matches(RetourConverter.convertToJsonRetour(retour), result._second);
    Assert.assertEquals(false, result2._first);
    Assert.assertNull(result2._second);

    retour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, "test does not match");
    result2 = Tools.matches(RetourConverter.convertToJsonRetour(retour), result._second);
    Assert.assertEquals(false, result2._first);
    Assert.assertNull(result2._second);

    retour = RetourFactory.createNOK("CAT-7", IMegSpiritConsts.TRAITEMENT_ARRETE, "toto test matched");
    result2 = Tools.matches(RetourConverter.convertToJsonRetour(retour), result._second);
    Assert.assertEquals(true, result2._first);
    Assert.assertEquals("ACTION_CORRECTIVE", result2._second);

    retour = RetourFactory.createNOK("CAT-3", "DONNEE_INCOHERENTE", "test DONNEE_INCOHERENTE");
    result2 = Tools.matches(RetourConverter.convertToJsonRetour(retour), result._second);
    Assert.assertEquals(true, result2._first);
    Assert.assertEquals("ACTION_CORRECTIVE_TEST", result2._second);

    retour = RetourFactory.createNOK("CAT-4", "DONNEE_INCONNUE", "toto");
    retour.setActivite("test");
    result2 = Tools.matches(RetourConverter.convertToJsonRetour(retour), result._second);
    Assert.assertEquals(true, result2._first);
    Assert.assertEquals("IGNORER_ERREUR", result2._second);

    retour = RetourFactory.createNOK("CAT-4", "DONNEE_INCONNUE", "toto");
    retour.setActivite("test does not match");
    result2 = Tools.matches(RetourConverter.convertToJsonRetour(retour), result._second);
    Assert.assertEquals(false, result2._first);
    Assert.assertNull(result2._second);
  }

  /**
   * Test loading file src/test/resources/PP0306_ErreurSpirit_filters_test.txt
   */
  @Test
  public void testOKLoadFiltersFromConfigFile()
  {
    Pair<Retour, List<Map<String, String>>> result = Tools.loadFiltersFromConfigFile(_tracabilite, "src/test/resources/PP0306_ErreurSpirit_filters_test.txt");
    Assert.assertEquals("OK", result._first.getResultat());
    Assert.assertEquals(6, result._second.size());

    //check
    Assert.assertEquals("ACTION_CORRECTIVE", result._second.get(0).get(Tools.TYPE_DECISION_ATTRIBUTE));
    Assert.assertEquals("CAT-4", result._second.get(0).get(Tools.FILTRE_CATEGORIE_ATTRIBUTE));
    Assert.assertEquals("TRAITEMENT_ARRETE", result._second.get(0).get(Tools.FILTRE_DIAGNOSTIC_ATTRIBUTE));
    Assert.assertEquals("bla.*", result._second.get(0).get(Tools.FILTRE_LIBELLE_ATTRIBUTE));
    Assert.assertNull(result._second.get(0).get(Tools.FILTRE_ACTIVITE_ATTRIBUTE));

    Assert.assertNull(result._second.get(1).get(Tools.TYPE_DECISION_ATTRIBUTE));
    Assert.assertEquals("CAT-5", result._second.get(1).get(Tools.FILTRE_CATEGORIE_ATTRIBUTE));
    Assert.assertNull(result._second.get(1).get(Tools.FILTRE_DIAGNOSTIC_ATTRIBUTE));
    Assert.assertNull(result._second.get(1).get(Tools.FILTRE_LIBELLE_ATTRIBUTE));
    Assert.assertNull(result._second.get(1).get(Tools.FILTRE_ACTIVITE_ATTRIBUTE));

    Assert.assertNull(result._second.get(2).get(Tools.TYPE_DECISION_ATTRIBUTE));
    Assert.assertEquals("CAT-6", result._second.get(2).get(Tools.FILTRE_CATEGORIE_ATTRIBUTE));
    Assert.assertEquals("DONNEE_INCONNUE", result._second.get(2).get(Tools.FILTRE_DIAGNOSTIC_ATTRIBUTE));
    Assert.assertNull(result._second.get(2).get(Tools.FILTRE_LIBELLE_ATTRIBUTE));
    Assert.assertNull(result._second.get(2).get(Tools.FILTRE_ACTIVITE_ATTRIBUTE));

    Assert.assertNull(result._second.get(3).get(Tools.TYPE_DECISION_ATTRIBUTE));
    Assert.assertEquals("CAT-7", result._second.get(3).get(Tools.FILTRE_CATEGORIE_ATTRIBUTE));
    Assert.assertNull(result._second.get(3).get(Tools.FILTRE_DIAGNOSTIC_ATTRIBUTE));
    Assert.assertEquals("toto.*", result._second.get(3).get(Tools.FILTRE_LIBELLE_ATTRIBUTE));
    Assert.assertNull(result._second.get(3).get(Tools.FILTRE_ACTIVITE_ATTRIBUTE));

    Assert.assertEquals("ACTION_CORRECTIVE_TEST", result._second.get(4).get(Tools.TYPE_DECISION_ATTRIBUTE));
    Assert.assertEquals("CAT-3", result._second.get(4).get(Tools.FILTRE_CATEGORIE_ATTRIBUTE));
    Assert.assertEquals("DONNEE_INCOHERENTE", result._second.get(4).get(Tools.FILTRE_DIAGNOSTIC_ATTRIBUTE));
    Assert.assertEquals(".*", result._second.get(4).get(Tools.FILTRE_LIBELLE_ATTRIBUTE));
    Assert.assertNull(result._second.get(4).get(Tools.FILTRE_ACTIVITE_ATTRIBUTE));

    Assert.assertEquals("IGNORER_ERREUR", result._second.get(5).get(Tools.TYPE_DECISION_ATTRIBUTE));
    Assert.assertEquals("CAT-4", result._second.get(5).get(Tools.FILTRE_CATEGORIE_ATTRIBUTE));
    Assert.assertEquals("DONNEE_INCONNUE", result._second.get(5).get(Tools.FILTRE_DIAGNOSTIC_ATTRIBUTE));
    Assert.assertEquals(".*", result._second.get(5).get(Tools.FILTRE_LIBELLE_ATTRIBUTE));
    Assert.assertEquals("test", result._second.get(5).get(Tools.FILTRE_ACTIVITE_ATTRIBUTE));
  }

}
