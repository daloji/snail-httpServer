/*******************************************************************************
 * $Id: PI0035_STTest.java 12705 2018-11-05 16:45:35Z jgregori $
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.prof.processes.PI0035.sti;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.bytel.spirit.common.shared.functional.types.json.st.pfs.hssfixe.DonneesIdentificationStPfsHSSFixe;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.hssfixe.DonneesProvisionneesStPfsHSSFixe;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.hssfixe.StPfsHSSFixe;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.mail.DonneesIdentificationSTPfsMail;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.mail.DonneesProvisionneesSTPfsMail;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.mail.StPfsMail;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.olt.DonneesIdentificationSTPfsOlt;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.olt.DonneesProvisionneesSTPfsOlt;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.olt.StPfsOlt;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.pfs_enum.DonneesIdentificationStPfsEnum;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.pfs_enum.DonneesProvisionneesStPfsEnum;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.pfs_enum.StPfsEnum;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.tasfixe.DonneesIdentificationStPfsTASFixe;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.tasfixe.DonneesProvisionneesStPfsTASFixe;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.tasfixe.StPfsTASFixe;
import com.bytel.spirit.common.shared.saab.res.TypeRessource;
import com.bytel.spirit.common.shared.saab.rst.StLienAllocationCommercial;
import com.bytel.spirit.common.shared.saab.rst.Statut;
import com.bytel.spirit.prof.processes.PE0018.utils.TypeObjectCommercialEnum;

/**
 *
 * @author jiantila
 * @version ($Revision: 12705 $ $Date: 2018-11-05 17:45:35 +0100 (lun. 05 nov. 2018) $)
 */
public class PI0035_STTest
{
  /**
   *
   */
  @Test
  public void testbuilfFromServiceTechnique_001_OK()
  {
    StLienAllocationCommercial servicetech = new StLienAllocationCommercial("idST", Statut.ACTIF.name(), "clientOperateur", "noCompte", TypeObjectCommercialEnum.SA.name(), "BSS_GP", "ocNoCompte", "idRessource", TypeRessource.COMPTE_MAIL.name()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$

    PI0035_ServiceTechnique pi0035St = PI0035_ServiceTechnique.buildFromServiceTechnique(servicetech);
    assertEquals(pi0035St.getIdSt(), servicetech.getIdSt());
    assertEquals(pi0035St.getStatut(), servicetech.getStatut());
    assertEquals(pi0035St.getTypeServiceTechnique(), servicetech.getTypeServiceTechnique());
    assertEquals(pi0035St.getIdSt(), servicetech.getIdSt());
  }

  /**
   *
   */
  @Test
  public void testbuilfFromServiceTechnique_002_OK()
  {
    StLienAllocationCommercial servicetech = new StLienAllocationCommercial("idST", Statut.ACTIF.name(), "clientOperateur", "noCompte", TypeObjectCommercialEnum.PA.name(), "BSS_GP", "ocNoCompte", "idRessource", TypeRessource.COMPTE_MAIL.name()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$

    PI0035_ServiceTechnique pi0035St = PI0035_ServiceTechnique.buildFromServiceTechnique(servicetech);
    assertEquals(pi0035St.getIdSt(), servicetech.getIdSt());
    assertEquals(pi0035St.getStatut(), servicetech.getStatut());
    assertEquals(pi0035St.getTypeServiceTechnique(), servicetech.getTypeServiceTechnique());
    assertEquals(pi0035St.getIdSt(), servicetech.getIdSt());
  }

  /**
  *
  */
  @Test
  public void testbuilfFromServiceTechnique_003_OK()
  {
    StLienAllocationCommercial servicetech = new StLienAllocationCommercial("idST", Statut.ACTIF.name(), "clientOperateur", "noCompte", TypeObjectCommercialEnum.EQT_DECLARE.name(), "BSS_GP", "noCompte", "idRessource", TypeRessource.COMPTE_MAIL.name()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$

    PI0035_ServiceTechnique pi0035St = PI0035_ServiceTechnique.buildFromServiceTechnique(servicetech);
    assertEquals(pi0035St.getIdSt(), servicetech.getIdSt());
    assertEquals(pi0035St.getStatut(), servicetech.getStatut());
    assertEquals(pi0035St.getTypeServiceTechnique(), servicetech.getTypeServiceTechnique());
    assertEquals(pi0035St.getIdSt(), servicetech.getIdSt());
  }

  /**
  *
  */
  @Test
  public void testbuilfFromServiceTechnique_004_OK()
  {
    DonneesIdentificationSTPfsMail donneesIdentificationSTPfsMail = new DonneesIdentificationSTPfsMail("SECONDAIRE", "id"); //$NON-NLS-1$ //$NON-NLS-2$
    DonneesProvisionneesSTPfsMail donneesProvisionneesSTPfsMail = new DonneesProvisionneesSTPfsMail("paSecondaire", 0, 0, "TOP"); //$NON-NLS-1$ //$NON-NLS-2$
    StPfsMail servicetech = new StPfsMail("idSt", "ACTIF", "clientOperateur", "noCompte", donneesIdentificationSTPfsMail, donneesProvisionneesSTPfsMail); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$

    PI0035_ServiceTechnique pi0035St = PI0035_ServiceTechnique.buildFromServiceTechnique(servicetech);
    assertEquals(pi0035St.getIdSt(), servicetech.getIdSt());
    assertEquals(pi0035St.getStatut(), servicetech.getStatut());
    assertEquals(pi0035St.getTypeServiceTechnique(), servicetech.getTypeServiceTechnique());
    assertEquals(pi0035St.getIdSt(), servicetech.getIdSt());
  }

  /**
  *
  */
  @Test
  public void testbuilfFromServiceTechnique_005_OK()
  {
    DonneesIdentificationSTPfsOlt donneesIdentificationSTPfsMail = new DonneesIdentificationSTPfsOlt("nomOlt", "Pos1", "Pos2", "ont1", "GPON"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    DonneesProvisionneesSTPfsOlt donneesProvisionneesSTPfsMail = new DonneesProvisionneesSTPfsOlt("codeAcces", "vLan", "123456789"); //$NON-NLS-1$ //$NON-NLS-2$
    StPfsOlt servicetech = new StPfsOlt("idSt", Statut.ACTIF.name(), "clientOperateur", "noCompte", donneesIdentificationSTPfsMail, donneesProvisionneesSTPfsMail); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    PI0035_ServiceTechnique pi0035St = PI0035_ServiceTechnique.buildFromServiceTechnique(servicetech);
    assertEquals(pi0035St.getIdSt(), servicetech.getIdSt());
    assertEquals(pi0035St.getStatut(), servicetech.getStatut());
    assertEquals(pi0035St.getTypeServiceTechnique(), servicetech.getTypeServiceTechnique());
    assertEquals(pi0035St.getIdSt(), servicetech.getIdSt());
  }

  /**
   * Test for coverage of class StPfsEnum
   */
  @Test
  public void testbuilfFromServiceTechnique_006_OK()
  {
    DonneesIdentificationStPfsEnum donneesIdentificationSTPfsEnum = new DonneesIdentificationStPfsEnum("idFunPa"); //$NON-NLS-1$
    DonneesProvisionneesStPfsEnum donneesProvisionneesSTPfsEnum = new DonneesProvisionneesStPfsEnum("1423523453453", "41242@bytel.fr"); //$NON-NLS-1$ //$NON-NLS-2$
    StPfsEnum servicetech = new StPfsEnum("idSt", Statut.ACTIF.name(), "clientOperateur", "noCompte", donneesIdentificationSTPfsEnum, donneesProvisionneesSTPfsEnum); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    PI0035_ServiceTechnique pi0035St = PI0035_ServiceTechnique.buildFromServiceTechnique(servicetech);
    assertEquals(servicetech.getIdSt(), pi0035St.getIdSt());
    assertEquals(servicetech.getStatut(), pi0035St.getStatut());
    assertEquals(servicetech.getTypeServiceTechnique(), pi0035St.getTypeServiceTechnique());
  }

  /**
   * Test for coverage of class StPfsHSSFixe
   */
  @Test
  public void testbuilfFromServiceTechnique_007_OK()
  {
    DonneesIdentificationStPfsHSSFixe donneesIdentificationSTPfsHSSFixe = new DonneesIdentificationStPfsHSSFixe("idFonctionnelPa"); //$NON-NLS-1$
    DonneesProvisionneesStPfsHSSFixe donneesProvisionneesSTPfsHSSFixe = new DonneesProvisionneesStPfsHSSFixe("idCompteIms", "noTelephone", "typeUsage", "impiFixe", "motDePasseIms", "sipUri", "telUri", "nomPrenomCourt", "codeInsee");
    StPfsHSSFixe servicetech = new StPfsHSSFixe("idSt", Statut.ACTIF.name(), "clientOperateur", "noCompte", donneesIdentificationSTPfsHSSFixe, donneesProvisionneesSTPfsHSSFixe); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    PI0035_ServiceTechnique pi0035St = PI0035_ServiceTechnique.buildFromServiceTechnique(servicetech);
    assertEquals(servicetech.getIdSt(), pi0035St.getIdSt());
    assertEquals(servicetech.getStatut(), pi0035St.getStatut());
    assertEquals(servicetech.getTypeServiceTechnique(), pi0035St.getTypeServiceTechnique());
  }

  /**
   * Test for coverage of class StPfsHSSFixe
   */
  @Test
  public void testbuilfFromServiceTechnique_008_OK()
  {
    DonneesIdentificationStPfsTASFixe donneesIdentificationSTPfsTASFixe = new DonneesIdentificationStPfsTASFixe("idFonctionnelPa"); //$NON-NLS-1$
    DonneesProvisionneesStPfsTASFixe donneesProvisionneesSTPfsTASFixe = new DonneesProvisionneesStPfsTASFixe("noTelephone", "typeUsage", "niveauRestriction", "notificationSuspension", "optionAppelSurTaxes", "nom", "prenom", "nomPrenomCourt");
    StPfsTASFixe servicetech = new StPfsTASFixe("idSt", Statut.ACTIF.name(), "clientOperateur", "noCompte", donneesIdentificationSTPfsTASFixe, donneesProvisionneesSTPfsTASFixe); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    PI0035_ServiceTechnique pi0035St = PI0035_ServiceTechnique.buildFromServiceTechnique(servicetech);
    assertEquals(servicetech.getIdSt(), pi0035St.getIdSt());
    assertEquals(servicetech.getStatut(), pi0035St.getStatut());
    assertEquals(servicetech.getTypeServiceTechnique(), pi0035St.getTypeServiceTechnique());
  }
}
