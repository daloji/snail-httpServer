/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PM028.activity;

import org.junit.Assert;
import org.junit.Test;

import com.bouygtel.commontypes.s3g.v3.EnumTypeStatutServiceAccessible;
import com.bouygtel.commontypes.s3g.v3.PIVOTREFERENCE;
import com.bouygtel.refcli.consulterpfi.out.ServiceAccessible;
import com.bouygtel.refcli.consulterpfi.out.ServiceCommercial;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.spirit.prof.processes.generated.provisionnerpfi.ServiceAccessibleStatut;

/**
 *
 * @author lchanyip
 * @version ($Revision$ $Date$)
 */
public class DonneesMetierConverterTest
{
  /**
   * Conversion d'un SA ACTIVE OK
   *
   * @throws RavelException
   *           exception
   */
  @Test
  public void Convert_SA_ACTIVE_OK() throws RavelException
  {
    ServiceAccessible sa = createCPFIOutService("1089", "ACTIVE"); //$NON-NLS-1$ //$NON-NLS-2$
    com.bytel.spirit.prof.processes.generated.provisionnerpfi.ServiceAccessible newsa = DonneesMetierConverter.convertServiceAccessibleConsulterPfiToProvisionnerPfi(sa);

    Assert.assertEquals(newsa.getStatut(), ServiceAccessibleStatut.ACTIVE);
    Assert.assertNotNull(newsa.getServiceCommercial());
    String noScProvIn = ((com.bytel.spirit.prof.processes.generated.provisionnerpfi.ServiceCommercial) (newsa.getServiceCommercial().getIdref())).getNoServiceCommercial();
    Assert.assertEquals(noScProvIn, "1089"); //$NON-NLS-1$
    Assert.assertTrue(newsa.getParametreSimpleValorises().isEmpty());
    Assert.assertNull(newsa.getPointAcces());
  }

  /**
   * Conversion d'un SA SUSPENDU OK
   *
   * @throws RavelException
   *           exception
   */
  @Test
  public void Convert_SA_SUSPENDU_OK() throws RavelException
  {
    ServiceAccessible sa = createCPFIOutService("1470", "SUSPENDU"); //$NON-NLS-1$ //$NON-NLS-2$
    com.bytel.spirit.prof.processes.generated.provisionnerpfi.ServiceAccessible newsa = DonneesMetierConverter.convertServiceAccessibleConsulterPfiToProvisionnerPfi(sa);

    Assert.assertEquals(newsa.getStatut(), ServiceAccessibleStatut.SUSPENDU);
    Assert.assertNotNull(newsa.getServiceCommercial());
    String noScProvIn = ((com.bytel.spirit.prof.processes.generated.provisionnerpfi.ServiceCommercial) (newsa.getServiceCommercial().getIdref())).getNoServiceCommercial();
    Assert.assertEquals(noScProvIn, "1470"); //$NON-NLS-1$
    Assert.assertTrue(newsa.getParametreSimpleValorises().isEmpty());
    Assert.assertNull(newsa.getPointAcces());
  }

  /**
   * @param noSC
   *          noSC
   * @param statut
   *          statut
   * @return service
   */
  private ServiceAccessible createCPFIOutService(String noSC, String statut)
  {
    ServiceAccessible sa = new ServiceAccessible();
    sa.setID("SA-REF-" + noSC); //$NON-NLS-1$
    sa.setStatut(EnumTypeStatutServiceAccessible.fromValue(statut));

    ServiceCommercial sc = new ServiceCommercial();
    sc.setID("SC-REF-" + noSC); //$NON-NLS-1$
    sc.setNoServiceCommercial(noSC);

    PIVOTREFERENCE pivotreference = new PIVOTREFERENCE();
    pivotreference.setIdref(sc);
    sa.setServiceCommercial(pivotreference);

    return sa;
  }
}
