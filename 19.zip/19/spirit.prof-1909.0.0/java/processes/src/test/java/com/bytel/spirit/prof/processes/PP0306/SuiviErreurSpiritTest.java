/*******************************************************************************
* $Id: SuiviErreurSpiritTest.java 17365 2019-02-19 10:37:45Z dmorgado $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PP0306;

import java.time.LocalDateTime;

import org.junit.Test;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.utils.RetourFactoryForTU;

/**
 *
 * @author lchanyip
 * @version ($Revision: 17365 $ $Date: 2019-02-19 11:37:45 +0100 (mar. 19 févr. 2019) $)
 */
public class SuiviErreurSpiritTest
{
  /**
   * Test getMapValue method
   */
  @Test
  public void testToString()
  {
    LocalDateTime dateCreation = LocalDateTime.now();
    LocalDateTime dateFinTraitement = dateCreation.plusMinutes(1);

    SuiviErreurSpirit suivi = new SuiviErreurSpirit("idErreurSpirit", dateCreation); //$NON-NLS-1$
    suivi.setClientOperateur("clientOperateur"); //$NON-NLS-1$
    suivi.setDateFinTraitement(dateFinTraitement);
    suivi.setIdAction("idActionCorrective"); //$NON-NLS-1$
    suivi.setNoCompte("noCompte"); //$NON-NLS-1$
    Retour retourNOK = RetourFactoryForTU.createNOK("CAT-4", "DONNEE_INCONNUE", "test erreur;", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    suivi.setRetour(retourNOK);
    suivi.setTypeDecision("test"); //$NON-NLS-1$
    System.out.println(suivi.toString());

    suivi = new SuiviErreurSpirit("idErreurSpirit", dateCreation); //$NON-NLS-1$
    System.out.println(suivi.toString());
  }
}
