/*******************************************************************************
* $Id: IModificationValue_Test.java 17760 2019-02-27 17:02:37Z kbettenc $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PE0018.utils.comparators;

/**
 *
 * @author kbettenc
 * @version ($Revision: 17760 $ $Date: 2019-02-27 18:02:37 +0100 (mer. 27 févr. 2019) $)
 */
public interface IModificationValue_Test
{
  /*
   * ---------------- Constants for buildPaTypeLigneFixe ----------------
   */
  /**
   * CODE_NRA
   */
  public static final String TECHNOLOGIE_ACCES = "technologieAcces"; //$NON-NLS-1$

  /**
   * ID_PROFIL_TECHNIQUE
   */
  public static final String ID_PROFIL_TECHNIQUE = "idProfilTechnique"; //$NON-NLS-1$

  /**
   * ID_OPERATEUR_COLLECTE
   */
  public static final String ID_OPERATEUR_COLLECTE = "idOperateurCollecte"; //$NON-NLS-1$

  /**
   * CODE_OPERATEUR_IMMEUBLE
   */
  public static final String CODE_OPERATEUR_IMMEUBLE = "codeOperateurImmeuble"; //$NON-NLS-1$

  /**
   * TYPE_DEGROUPAGE
   */
  public static final String TYPE_DEGROUPAGE = "typeDegroupage"; //$NON-NLS-1$

  /*
   * ---------------- Constants for buildAdresseInstallation ----------------
   */
  /**
   * NUMERO
   */
  public static final String NUMERO = "numero"; //$NON-NLS-1$

  /**
   * CODE_POSTAL
   */
  public static final String CODE_POSTAL = "codePostal"; //$NON-NLS-1$

  /**
   * VILLE
   */
  public static final String VILLE = "ville"; //$NON-NLS-1$

  /**
   * INDICE_REPETITION
   */
  public static final String INDICE_REPETITION = "indiceRepetition"; //$NON-NLS-1$

  /**
   * NOM_VOIE
   */
  public static final String NOM_VOIE = "nomVoie"; //$NON-NLS-1$

  /**
   * CODE_INSEE
   */
  public static final String CODE_INSEE = "codeInsee"; //$NON-NLS-1$

  /**
   * CODE_RIVOLI
   */
  public static final String CODE_RIVOLI = "codeRivoli"; //$NON-NLS-1$

  /**
   * PORTE
   */
  public static final String PORTE = "porte"; //$NON-NLS-1$

  /**
   * LOGO
   */
  public static final String LOGO = "logo"; //$NON-NLS-1$

  /**
   * BATIMENT
   */
  public static final String BATIMENT = "batiment"; //$NON-NLS-1$

  /**
   * ESCALIER
   */
  public static final String ESCALIER = "escalier"; //$NON-NLS-1$

  /**
   * ETAGE
   */
  public static final String ETAGE = "etage"; //$NON-NLS-1$

  /**
   * PRECEDENT_PROPRIETAIRE
   */
  public static final String PRECEDENT_PROPRIETAIRE = "precedentProprietaire"; //$NON-NLS-1$

  /**
   * HEXACLE
   */
  public static final String HEXACLE = "hexacle"; //$NON-NLS-1$

  /*
   * ---------------- Constants for buildAccesTechniqueCommercial ----------------
   */
  /**
   * CODE_ACCES_TECHNIQUE
   */
  public static final String CODE_ACCES_TECHNIQUE = "codeAccesTechnique"; //$NON-NLS-1$

  /*
   * ---------------- Constants for buildCommande ----------------
   */
  /**
   * CLIENT_OPERATEUR
   */
  public static final String CLIENT_OPERATEUR = "clientOperateur"; //$NON-NLS-1$

  /**
   * ID_CMD
   */
  public static final String ID_CMD = "idCmd"; //$NON-NLS-1$

  /**
   * NO_COMPTE
   */
  public static final String NO_COMPTE = "noCompte"; //$NON-NLS-1$

  /*
   * ---------------- Constants for buildContexteInstallation ----------------
   */
  /**
   * ID_MANDAT
   */
  public static final String ID_MANDAT = "idMandat"; //$NON-NLS-1$

  /**
   * TYPE_MES
   */
  public static final String TYPE_MES = "typeMes"; //$NON-NLS-1$

  /**
   * ID_RDV
   */
  public static final String ID_RDV = "idRdv"; //$NON-NLS-1$

  /**
   * PRESTATAIRE
   */
  public static final String PRESTATAIRE = "prestataire"; //$NON-NLS-1$

  /**
   * COMMENTAIRE
   */
  public static final String COMMENTAIRE = "commentaire"; //$NON-NLS-1$

  /**
   * CONTACT_NOMPRENOM
   */
  public static final String CONTACT_NOMPRENOM = "contactNomPrenom"; //$NON-NLS-1$

  /**
   * CONTACT_TELEPHONE
   */
  public static final String CONTACT_TELEPHONE = "contactTelephone"; //$NON-NLS-1$

  /**
   * CRENEAU_CLIENT
   */
  public static final String CRENEAU_CLIENT = "creneauClient"; //$NON-NLS-1$

  /*
   * ---------------- Constants for buildEntreprise ----------------
   */
  /**
   * NO_SIREN
   */
  public static final String NO_SIREN = "noSiren"; //$NON-NLS-1$

  /**
   * RAISON_SOCIALE
   */
  public static final String RAISON_SOCIALE = "raisonSociale"; //$NON-NLS-1$

  /*
   * ---------------- Constants for buildEquipementDeclare ----------------
   */
  /**
   * NO_EQUIPEMENT
   */
  public static final String NO_EQUIPEMENT = "noEquipement"; //$NON-NLS-1$

  /**
   * NO_IDENTIFIANT_EQUIP
   */
  public static final String NO_IDENTIFIANT_EQUIP = "noIdentifiantEquip"; //$NON-NLS-1$

  /**
   * MODELE_EQUIPEMENT
   */
  public static final String MODELE_EQUIPEMENT = "modeleEquipement"; //$NON-NLS-1$

  /**
   * NOM_FABRICANT_EQUIP
   */
  public static final String NOM_FABRICANT_EQUIP = "nomFabricantEquip"; //$NON-NLS-1$

  /**
   * NO_IDENTIFIANT_IAD_ONEBOX
   */
  public static final String NO_IDENTIFIANT_IAD_ONEBOX = "noIdentifiantIiadOnebox"; //$NON-NLS-1$

  /**
   * MODELE_IAD_ONEBOX
   */
  public static final String MODELE_IAD_ONEBOX = "modeleIadOnebox"; //$NON-NLS-1$

  /**
   * NO_IDENTIFIANT_STB_ONEBOX
   */
  public static final String NO_IDENTIFIANT_STB_ONEBOX = "noIdentifiantStbOnebox"; //$NON-NLS-1$

  /**
   * MODELE_STB_ONEBOX
   */
  public static final String MODELE_STB_ONEBOX = "modeleStbOnebox"; //$NON-NLS-1$

  /**
   * MAC_ADRESS_MODEM
   */
  public static final String MAC_ADRESS_MODEM = "macAdressModem"; //$NON-NLS-1$

  /**
   * MAC_ADRESS_MTA
   */
  public static final String MAC_ADRESS_MTA = "macAdressMta"; //$NON-NLS-1$

  /**
   * MAC_ADRESS_GATEWAY
   */
  public static final String MAC_ADRESS_GATEWAY = "macAdressGateway"; //$NON-NLS-1$

  /**
   * MAC_ADRESS_TV
   */
  public static final String MAC_ADRESS_TV = "macAdressTv"; //$NON-NLS-1$

  /**
   * CODE_EAN_EQUIP
   */
  public static final String CODE_EAN_EQUIP = "codeEanEquip"; //$NON-NLS-1$

  /**
   * NO_EQUIPEMENT_LIE
   */
  public static final String NO_EQUIPEMENT_LIE = "noEquipementLie"; //$NON-NLS-1$

  /*
   * ---------------- Constants for buildPaTypeLigneFixe ----------------
   */

  /**
   * ID_PRISE
   */
  public static final String ID_PRISE = "idPrise"; //$NON-NLS-1$

  /**
   * CODE_NRA
   */
  public static final String CODE_NRA = "codeNra"; //$NON-NLS-1$

  /**
   * ID_RESSOURCE_RESEAU_XDSL
   */
  public static final String ID_RESSOURCE_RESEAU_XDSL = "idRessourceReseauXDSL"; //$NON-NLS-1$

  /**
   * ID_RESSOURCE_RESEAU_FTTX
   */
  public static final String ID_RESSOURCE_RESEAU_FTTX = "idRessourceReseauFTTX"; //$NON-NLS-1$

  /**
   * ID_LIGNE
   */
  public static final String ID_LIGNE = "idLigne"; //$NON-NLS-1$

  /**
   * ID_ACTION
   */
  public static final String ID_ACTION = "idAction"; //$NON-NLS-1$

  /**
   * TYPE_ACTION_ADSL
   */
  public static final String TYPE_ACTION_ADSL = "typeActionAdsl"; //$NON-NLS-1$

  /**
   * REFERENCE_PM_OI
   */
  public static final String REFERENCE_PM_OI = "referencePmOi"; //$NON-NLS-1$

  /**
   * ADSL_ETAT_FT
   */
  public static final String ADSL_ETAT_FT = "adslEtatFT"; //$NON-NLS-1$

  /**
   * QUALITES_TV_POSSIBLES
   */
  public static final String QUALITES_TV_POSSIBLES = "qualitesTVPossibles"; //$NON-NLS-1$

  /**
   * ID_CLIENT_EXTERNE
   */
  public static final String ID_CLIENT_EXTERNE = "idClientExterne"; //$NON-NLS-1$

  /*
   * ---------------- Constants for buildPA ----------------
   */
  /**
   * ID_FONCTIONNEL_PA
   */
  public static final String ID_FONCTIONNEL_PA = "idFonctionnelPA"; //$NON-NLS-1$

  /**
   * ID_FONCTIONNEL_PA_LIE
   */
  public static final String ID_FONCTIONNEL_PA_LIE = "idFonctionnelPALie"; //$NON-NLS-1$

  /*
   * ---------------- Constants for buildPaTypeFax ----------------
   */
  /**
   * NUMERO_TELEPHONE
   */
  public static final String NUMERO_TELEPHONE = "numeroTelephone"; //$NON-NLS-1$

  /*
   * ---------------- Constants for buildPaTypeCompteAcces ----------------
   */
  /**
   * EMAIL_LOGIN
   */
  public static final String EMAIL_LOGIN = "emailLogin"; //$NON-NLS-1$

  /*
   * ---------------- Constants for buildPaTypeVoip ----------------
   */
  /**
   * CODE_RIO
   */
  public static final String CODE_RIO = "codeRio"; //$NON-NLS-1$

  /**
   * NUMERO_PORT_TELEPHONIQUE
   */
  public static final int NUMERO_PORT_TELEPHONIQUE = 1;

  /*
   * ---------------- Constants for buildPaTypeLigneFixe ----------------
   */

  /**
   * ID_RACCORDEMENT
   */
  public static final String ID_RACCORDEMENT = "idRaccordement"; //$NON-NLS-1$

  /**
   * DISTANCE
   */
  public static final int DISTANCE = 1;

  /**
   * VLAN
   */
  public static final String VLAN = "vlan"; //$NON-NLS-1$

  /*
   * ---------------- Constants for buildPaTypeTV ----------------
   */

  /**
   * ID_COMPTE_TV
   */
  public static final String ID_COMPTE_TV = "idCompteTV"; //$NON-NLS-1$

  /**
   * ID_CONTENU_TV
   */
  public static final String ID_CONTENU_TV = "idContenuTV"; //$NON-NLS-1$

  /*
   * ---------------- Constants for buildPfi ----------------
   */

  /**
   * LIGNE_MARCHE
   */
  public static final String LIGNE_MARCHE = "ligneMarche"; //$NON-NLS-1$

  /*
   * ---------------- Constants for buildSA ----------------
   */

  /**
   * NO_SERVICE_COMMERCIAL
   */
  public static final String NO_SERVICE_COMMERCIAL = "noServiceCommercial"; //$NON-NLS-1$

  /**
   * NO_SERVICE_ACCESSIBLE
   */
  public static final String NO_SERVICE_ACCESSIBLE = "noServiceAccessible"; //$NON-NLS-1$

  /**
   * NOM_SERVICE_COMMERCIAL
   */
  public static final String NOM_SERVICE_COMMERCIAL = "nomServiceCommercial";

  /**
   * CATEGORIE_SERVICE_COMMERCIAL
   */
  public static final String CATEGORIE_SERVICE_COMMERCIAL = "categorieServiceCommercial"; //$NON-NLS-1$

  /*
   * ---------------- Constants for buildTitulaire ----------------
   */
  /**
   * NO_PERSONNE
   */
  public static final String NO_PERSONNE = "noPersonne"; //$NON-NLS-1$

}
