/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PI0251;

import static org.junit.Assert.assertEquals;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.test.context.ContextConfiguration;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.datetime.DateTimeManager;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.request.Parameter;
import com.bytel.ravel.common.factory.request.UrlParameters;
import com.bytel.ravel.common.factory.response.IRavelResponse;
import com.bytel.ravel.common.factory.response.RavelResponseFactory;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.utils.ACManagerUtil;
import com.bytel.ravel.common.utils.DateTimeTools.DateTimeFormatPattern;
import com.bytel.ravel.common.utils.Mode;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.RetourFactoryForTU;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.ProcessManager;
import com.bytel.ravel.services.utils.Test_Consts;
import com.bytel.spirit.common.activities.shared.BL4600_CreerErreurSpirit;
import com.bytel.spirit.common.activities.shared.BL4600_CreerErreurSpirit.BL4600_CreerErreurSpiritBuilder;
import com.bytel.spirit.common.activities.shared.BL5230_ReparerRessourceRaccordement;
import com.bytel.spirit.common.activities.shared.BL5230_ReparerRessourceRaccordement.BL5230_ReparerRessourceRaccordementBuilder;
import com.bytel.spirit.common.activities.shared.BL5250_ExtraireCaracteristiquesCommunes;
import com.bytel.spirit.common.activities.shared.BL5250_ExtraireCaracteristiquesCommunes.BL5250_ExtraireCaracteristiquesCommunesBuilder;
import com.bytel.spirit.common.activities.shared.BL5260_ExtraireCaracteristiquesSpecifiques;
import com.bytel.spirit.common.activities.shared.BL5260_ExtraireCaracteristiquesSpecifiques.BL5260_ExtraireCaracteristiquesSpecifiquesBuilder;
import com.bytel.spirit.common.activities.shared.structs.CaracteristiquesCommunes;
import com.bytel.spirit.common.activities.shared.structs.CaracteristiquesSpecifiques;
import com.bytel.spirit.common.connectors.rpg.RPGProxy;
import com.bytel.spirit.common.connectors.rst.RSTProxy;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.rpg.PA;
import com.bytel.spirit.common.shared.saab.rpg.PFI;
import com.bytel.spirit.common.shared.saab.rpg.TypePA;
import com.bytel.spirit.common.shared.saab.rst.ServiceTechnique;
import com.bytel.spirit.common.shared.saab.rst.StLienAllocationCommercial;
import com.bytel.spirit.common.shared.saab.rst.Statut;
import com.bytel.spirit.common.shared.saab.rst.TypeST;
import com.bytel.spirit.prof.processes.Messages;
import com.bytel.spirit.prof.processes.PI0251.PI0251_ReparerRaccordements.ParameterUrl;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author bferreir
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@ContextConfiguration("classpath:BeansProcessTestMocks.xml")
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
@PrepareForTest({ PI0251_ReparerRaccordements.class, RPGProxy.class, RSTProxy.class, BL5250_ExtraireCaracteristiquesCommunes.class, BL5250_ExtraireCaracteristiquesCommunesBuilder.class, BL5260_ExtraireCaracteristiquesSpecifiques.class, BL5260_ExtraireCaracteristiquesSpecifiquesBuilder.class, BL5230_ReparerRessourceRaccordement.class, BL5230_ReparerRessourceRaccordementBuilder.class, BL4600_CreerErreurSpirit.class, BL4600_CreerErreurSpiritBuilder.class })
public class PI0251_ReparerRaccordementsTest
{
  /**
   * Constant idSt
   */
  private static final String ID_ST = "idSt"; //$NON-NLS-1$

  /**
   * Constant idRessource
   */
  private static final String ID_RESSOURCE = "idRessource"; //$NON-NLS-1$

  /**
   * Constant noCompte
   */
  private static final String NO_COMPTE = "noCompte"; //$NON-NLS-1$

  /**
   * Constant typeObjetCommercial
   */
  private static final String TYPE_OBJET_COMMERCIAL = "typeObjetCommercial"; //$NON-NLS-1$

  /**
   * ConstantclientOperateur
   */
  private static final String CLIENT_OPERATEUR = "clientOperateur"; //$NON-NLS-1$

  /**
   * Constant Raccordement
   */
  private static final String RACCORDEMENT = "RACCO"; //$NON-NLS-1$

  /**
   * Constant Tracabilite
   */
  private static Tracabilite _tracabilite;

  /**
   * Factory de génération des beans
   */
  private static PodamFactory __podam = new PodamFactoryImpl();

  /**
   * SPRING context
   */
  @SuppressWarnings("unused")
  private static ClassPathXmlApplicationContext __context;

  /**
   * The default process name.
   */
  public static final String DEFAULT_PROCESSNAME = "PI0251_ReparerRaccordements"; //$NON-NLS-1$

  /**
   * Constant RESSOURCE_INDISPONIBLE
   */
  private static final String RESSOURCE_INDISPONIBLE = "RESSOURCE_INDISPONIBLE"; //$NON-NLS-1$

  /**
   * Initialization method: Create: - spring context - connectors - service manager.
   *
   * @throws RavelException
   *           the exception
   */
  @BeforeClass
  public static void init() throws RavelException
  {
    // désactivation du cache podam
    __podam.getStrategy().setMemoization(false);
    __podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());

    ACManagerUtil.resetACManager();
    __context = new ClassPathXmlApplicationContext("classpath:BeansProcessTestMocks.xml"); //$NON-NLS-1$

      DateTimeManager.getInstance().initialize(Mode.FIXED);
      DateTimeManager.getInstance().setFixedClockAt(DateTimeManager.getInstance().now());

  }

  /**
   * Instance of {@link PI0251_ReparerRaccordements}
   */
  private PI0251_ReparerRaccordements _processInstance;

  /**
   * RPG PRoxy
   */
  @MockStrict
  private RPGProxy _rpgProxy;

  /**
   * RST PRoxy
   */
  @MockStrict
  private RSTProxy _rstProxy;

  /**
   * BL5250 Mock
   */
  @MockStrict
  private BL5250_ExtraireCaracteristiquesCommunes _bl5250;

  /**
   * BL5250Builder Mock
   */
  @MockStrict
  private BL5250_ExtraireCaracteristiquesCommunesBuilder _bl5250Builder;

  /**
   * BL5260 Mock
   */
  @MockStrict
  private BL5260_ExtraireCaracteristiquesSpecifiques _bl5260;

  /**
   * BL5260Builder Mock
   */
  @MockStrict
  private BL5260_ExtraireCaracteristiquesSpecifiquesBuilder _bl5260Builder;

  /**
   * BL5230 Mock
   */
  @MockStrict
  private BL5230_ReparerRessourceRaccordement _bl5230;

  /**
   * BL5260Builder Mock
   */
  @MockStrict
  private BL5230_ReparerRessourceRaccordementBuilder _bl5230Builder;

  /**
   * BL4600 Mock
   */
  @MockStrict
  private BL4600_CreerErreurSpirit _bl4600;

  /**
   * BL4600Builder Mock
   */
  @MockStrict
  private BL4600_CreerErreurSpiritBuilder _bl4600Builder;

  /**
   * Sets the test
   */
  @Before
  public void setUp()
  {
    _processInstance = new PI0251_ReparerRaccordements();
    _processInstance.initializeContext();

    _tracabilite = new Tracabilite();
    _tracabilite.setIdCorrelationByTel(StringConstants.EMPTY_STRING);
    _tracabilite.setIdProcessusSpirit(_processInstance.getIdProcess());
    _tracabilite.setIdCorrelationSpirit(Test_Consts.DEFAULT_MSGID);
    _tracabilite.setNomProcessus(StringConstants.EMPTY_STRING);
    _tracabilite.setNomSysteme(System.getenv("SERVICE")); //$NON-NLS-1$

    ProcessManager.getInstance().getProcessParams().clear();

    // on réinitialise tous les mocks afin de ne pas avoir d'interférence entre les tests
    PowerMock.resetAll();

    PowerMock.mockStatic(RPGProxy.class);
    PowerMock.mockStatic(RSTProxy.class);
  }

  /**
   * Test KO invalid input parameters.
   *
   * <b>Entrée:</b> clientOperateur=null.<br/>
   * <b>Attendu:</b> KO | CAT-3 | ENTREE_INCORRECTE | Paramètre [clientOperateur] null ou vide dans la requête.<br/>
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void test_001_KO_BL001() throws Throwable
  {
    Request request = prepareRequest(null, null);
    Retour retourKO = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ENTREE_INCORRECTE, MessageFormat.format(Messages.getString("PI0251.BL001.ParameterNullOrEmpty"), "clientOperateur"), "PI0251_BL001_VerifierDonnees"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verify();

    IRavelResponse response = request.getResponse();
    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(retourKO));

    assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());
    assertEquals(retourKO, _processInstance.getRetour());
  }

  /**
   * Test KO invalid input parameters.
   *
   * <b>Entrée:</b> clientOperateur valid and noCompte null.<br/>
   * <b>Attendu:</b> KO | CAT-3 | ENTREE_INCORRECTE | Paramètre [noCompte] null ou vide dans la requête.<br/>
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void test_002_KO_BL001() throws Throwable
  {
    Request request = prepareRequest(CLIENT_OPERATEUR, null);
    Retour retourKO = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ENTREE_INCORRECTE, MessageFormat.format(Messages.getString("PI0251.BL001.ParameterNullOrEmpty"), "noCompte"), "PI0251_BL001_VerifierDonnees"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verify();

    IRavelResponse response = request.getResponse();
    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(retourKO));

    assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());
    assertEquals(retourKO, _processInstance.getRetour());
  }

  /**
   * Test KO RST error.
   *
   * <b>Entrée:</b> input valid.<br/>
   * <b>Attendu:</b> KO | CAT-2 | SERVICE_TIERS_INDISPONIBLE | libelle.<br/>
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void test_003_KO_RST() throws Throwable
  {
    Request request = prepareRequest(CLIENT_OPERATEUR, NO_COMPTE);
    Retour retourKO = RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, "libelle"); //$NON-NLS-1$

    createMockRSTserviceTechniqueLireTousParPfi(retourKO, null, CLIENT_OPERATEUR, NO_COMPTE);

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verify();

    IRavelResponse response = request.getResponse();
    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(retourKO));

    assertEquals(ErrorCode.KO_00503, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());
    assertEquals(retourKO, _processInstance.getRetour());
  }

  /**
   * Test KO RST returns 1 ServiceTechnique with typeRessource=OTHER.<br/>
   * No ServiceTechnique is filtered.
   *
   * <b>Entrée:</b> input valid.<br/>
   * <b>Attendu:</b> OK.<br/>
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void test_004_OK_RST_VIDE() throws Throwable
  {
    Request request = prepareRequest(CLIENT_OPERATEUR, NO_COMPTE);
    Retour retour = RetourFactory.createOkRetour();

    StLienAllocationCommercial stLienAllocationCommercial = new StLienAllocationCommercial(ID_ST, Statut.INACTIF.name(), CLIENT_OPERATEUR, NO_COMPTE, TYPE_OBJET_COMMERCIAL, CLIENT_OPERATEUR, NO_COMPTE, ID_RESSOURCE, "OTHER"); //$NON-NLS-1$

    createMockRSTserviceTechniqueLireTousParPfi(retour, Arrays.asList(stLienAllocationCommercial), CLIENT_OPERATEUR, NO_COMPTE);

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verify();

    IRavelResponse response = request.getResponse();
    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(retour));

    assertEquals(ErrorCode.OK_00200, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());
    assertEquals(retour, _processInstance.getRetour());
  }

  /**
   * Test KO RPG returns KO.<br/>
   * RST returns:<br/>
   * 1 ServiceTechnique with LAC.typeRessource=Raccordement and statut=INACTIF<br/>
   * 1 ServiceTechnique with LAC.typeRessource=Raccordement and statut=ACTIF.
   *
   * <b>Entrée:</b> input valid.<br/>
   * <b>Attendu:</b> KO | CAT4 | DONNEE_INCONNUE | libelle.<br/>
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void test_005_KO_RPG() throws Throwable
  {
    Request request = prepareRequest(CLIENT_OPERATEUR, NO_COMPTE);
    Retour retourKO = RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "libelle"); //$NON-NLS-1$

    StLienAllocationCommercial st1 = new StLienAllocationCommercial(ID_ST, Statut.INACTIF.name(), CLIENT_OPERATEUR, NO_COMPTE, TYPE_OBJET_COMMERCIAL, CLIENT_OPERATEUR, NO_COMPTE, ID_RESSOURCE, RACCORDEMENT);

    StLienAllocationCommercial st2 = new StLienAllocationCommercial(ID_ST, Statut.ACTIF.name(), CLIENT_OPERATEUR, NO_COMPTE, TYPE_OBJET_COMMERCIAL, CLIENT_OPERATEUR, NO_COMPTE, ID_RESSOURCE, RACCORDEMENT);

    createMockRSTserviceTechniqueLireTousParPfi(RetourFactory.createOkRetour(), Arrays.asList(st1, st2), CLIENT_OPERATEUR, NO_COMPTE);

    createMockRPGpfiLireUn(retourKO, null, CLIENT_OPERATEUR, NO_COMPTE);

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verify();

    IRavelResponse response = request.getResponse();
    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(retourKO));

    assertEquals(ErrorCode.KO_00404, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());
    assertEquals(retourKO, _processInstance.getRetour());
  }

  /**
   * Test KO BL5250 returns null.<br/>
   * RST returns:<br/>
   * 1 ServiceTechnique with LAC.typeRessource=Raccordement and statut=INACTIF<br/>
   * 1 ServiceTechnique with LAC.typeRessource=Raccordement and statut=ACTIF.<br/>
   * RPG returns OK and Pfi null.<br/>
   * BL5250 returns null and that throws an Exception catched in startProcess.<br/>
   *
   * <b>Entrée:</b> input valid.<br/>
   * <b>Attendu:</b> KO | CAT10 | TRAITEMENT_ARRETE | null.<br/>
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void test_006_KO_BL5250_Exception() throws Throwable
  {
    Request request = prepareRequest(CLIENT_OPERATEUR, NO_COMPTE);
    Retour retourKO = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, null, "PI0251_ReparerRaccordements.startProcess"); //$NON-NLS-1$

    StLienAllocationCommercial st1 = new StLienAllocationCommercial(ID_ST, Statut.INACTIF.name(), CLIENT_OPERATEUR, NO_COMPTE, TYPE_OBJET_COMMERCIAL, CLIENT_OPERATEUR, NO_COMPTE, ID_RESSOURCE, RACCORDEMENT);

    StLienAllocationCommercial st2 = new StLienAllocationCommercial(ID_ST, Statut.ACTIF.name(), CLIENT_OPERATEUR, NO_COMPTE, TYPE_OBJET_COMMERCIAL, CLIENT_OPERATEUR, NO_COMPTE, ID_RESSOURCE, RACCORDEMENT);

    createMockRSTserviceTechniqueLireTousParPfi(RetourFactory.createOkRetour(), Arrays.asList(st1, st2), CLIENT_OPERATEUR, NO_COMPTE);

    PFI pfi = __podam.manufacturePojo(PFI.class);
    //to avoid IllegalArgumentException due to the autoset of the PFI
    for (PA pa : pfi.getPa())
    {
      pa.setTypePA(TypePA.COMPTE_ACCES.name());
    }

    createMockRPGpfiLireUn(RetourFactory.createOkRetour(), pfi, CLIENT_OPERATEUR, NO_COMPTE);

    PowerMock.expectNew(BL5250_ExtraireCaracteristiquesCommunesBuilder.class).andReturn(_bl5250Builder);
    EasyMock.expect(_bl5250Builder.tracabilite(_tracabilite)).andReturn(_bl5250Builder);
    EasyMock.expect(_bl5250Builder.pfi(pfi)).andReturn(_bl5250Builder);
    EasyMock.expect(_bl5250Builder.build()).andReturn(_bl5250);
    EasyMock.expect(_bl5250.execute(_processInstance)).andReturn(null);
    EasyMock.expect(_bl5250.getRetour()).andReturn(retourKO);
    EasyMock.expect(_bl5250.getRetour()).andReturn(retourKO);

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verify();

    IRavelResponse response = request.getResponse();
    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(retourKO));

    assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());
    assertEquals(retourKO, _processInstance.getRetour());
  }

  /**
   * Test KO BL5250 returns KO.<br/>
   * RST returns:<br/>
   * 1 ServiceTechnique with LAC.typeRessource=Raccordement and statut=INACTIF<br/>
   * 1 ServiceTechnique with LAC.typeRessource=Raccordement and statut=ACTIF.<br/>
   * RPG returns OK and Pfi null.<br/>
   * BL5250 returns KO.<br/>
   *
   * <b>Entrée:</b> input valid.<br/>
   * <b>Attendu:</b> KO | CAT3 | DONNEE_INVALIDE | libelle.<br/>
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void test_007_KO_BL5250() throws Throwable
  {
    Request request = prepareRequest(CLIENT_OPERATEUR, NO_COMPTE);
    Retour retourKO = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, "libelle"); //$NON-NLS-1$

    StLienAllocationCommercial st1 = new StLienAllocationCommercial(ID_ST, Statut.INACTIF.name(), CLIENT_OPERATEUR, NO_COMPTE, TYPE_OBJET_COMMERCIAL, CLIENT_OPERATEUR, NO_COMPTE, ID_RESSOURCE, RACCORDEMENT);

    StLienAllocationCommercial st2 = new StLienAllocationCommercial(ID_ST, Statut.ACTIF.name(), CLIENT_OPERATEUR, NO_COMPTE, TYPE_OBJET_COMMERCIAL, CLIENT_OPERATEUR, NO_COMPTE, ID_RESSOURCE, RACCORDEMENT);

    createMockRSTserviceTechniqueLireTousParPfi(RetourFactory.createOkRetour(), Arrays.asList(st1, st2), CLIENT_OPERATEUR, NO_COMPTE);

    PFI pfi = __podam.manufacturePojo(PFI.class);
    //to avoid IllegalArgumentException due to the autoset of the PFI
    for (PA pa : pfi.getPa())
    {
      pa.setTypePA(TypePA.COMPTE_ACCES.name());
    }

    createMockRPGpfiLireUn(RetourFactory.createOkRetour(), pfi, CLIENT_OPERATEUR, NO_COMPTE);

    createMockBL5250(null, retourKO, pfi);

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verify();

    IRavelResponse response = request.getResponse();
    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(retourKO));

    assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());
    assertEquals(retourKO, _processInstance.getRetour());
  }

  /**
   * Test KO BL5260 returns KO.<br/>
   * RST returns:<br/>
   * 1 ServiceTechnique with LAC.typeRessource=Raccordement and statut=INACTIF<br/>
   * 1 ServiceTechnique with LAC.typeRessource=Raccordement and statut=ACTIF.<br/>
   * RPG returns OK and Pfi null.<br/>
   * BL5250 returns OK.<br/>
   * BL5260 returns KO.
   *
   * <b>Entrée:</b> input valid.<br/>
   * <b>Attendu:</b> KO | CAT3 | DONNEE_INVALIDE | libelle.<br/>
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void test_008_KO_BL5260() throws Throwable
  {
    Request request = prepareRequest(CLIENT_OPERATEUR, NO_COMPTE);
    Retour retourKO = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, "libelle"); //$NON-NLS-1$

    StLienAllocationCommercial st1 = new StLienAllocationCommercial(ID_ST, Statut.INACTIF.name(), CLIENT_OPERATEUR, NO_COMPTE, TYPE_OBJET_COMMERCIAL, CLIENT_OPERATEUR, NO_COMPTE, ID_RESSOURCE, RACCORDEMENT);

    StLienAllocationCommercial st2 = new StLienAllocationCommercial(ID_ST, Statut.ACTIF.name(), CLIENT_OPERATEUR, NO_COMPTE, TYPE_OBJET_COMMERCIAL, CLIENT_OPERATEUR, NO_COMPTE, ID_RESSOURCE, RACCORDEMENT);
    st2.setOcIdentifiantFonctionnelPA("identifiantFonctionelIPA"); //$NON-NLS-1$

    createMockRSTserviceTechniqueLireTousParPfi(RetourFactory.createOkRetour(), Arrays.asList(st1, st2/*, st3*/), CLIENT_OPERATEUR, NO_COMPTE);

    PFI pfi = __podam.manufacturePojo(PFI.class);
    //to avoid IllegalArgumentException due to the autoset of the PFI
    for (PA pa : pfi.getPa())
    {
      pa.setTypePA(TypePA.COMPTE_ACCES.name());
    }

    createMockRPGpfiLireUn(RetourFactory.createOkRetour(), pfi, CLIENT_OPERATEUR, NO_COMPTE);

    CaracteristiquesCommunes caractCommunes = new CaracteristiquesCommunes(CLIENT_OPERATEUR, NO_COMPTE);
    createMockBL5250(caractCommunes, RetourFactory.createOkRetour(), pfi);

    createMockBL5260(null, retourKO, pfi, "identifiantFonctionelIPA"); //$NON-NLS-1$

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verify();

    IRavelResponse response = request.getResponse();
    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(retourKO));

    assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());
    assertEquals(retourKO, _processInstance.getRetour());
  }

  /**
   * Test KO BL5230 returns KO.<br/>
   * RST returns:<br/>
   * 1 ServiceTechnique with LAC.typeRessource=Raccordement and statut=INACTIF<br/>
   * 1 ServiceTechnique with LAC.typeRessource=Raccordement and statut=ACTIF.<br/>
   * RPG returns OK and Pfi null.<br/>
   * BL5250 returns OK.<br/>
   * BL5260 returns OK.<br/>
   * BL5230 returns KO (not RESSOURCE_INDISPONIBLE).<br/>
   *
   * <b>Entrée:</b> input valid.<br/>
   * <b>Attendu:</b> KO | CAT3 | DONNEE_INVALIDE | libelle.<br/>
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void test_009_KO_BL5230() throws Throwable
  {
    Request request = prepareRequest(CLIENT_OPERATEUR, NO_COMPTE);
    Retour retourKoOther = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, "libelle"); //$NON-NLS-1$

    StLienAllocationCommercial st1 = new StLienAllocationCommercial(ID_ST, Statut.INACTIF.name(), CLIENT_OPERATEUR, NO_COMPTE, TYPE_OBJET_COMMERCIAL, CLIENT_OPERATEUR, NO_COMPTE, ID_RESSOURCE, RACCORDEMENT);

    StLienAllocationCommercial st2 = new StLienAllocationCommercial(ID_ST, Statut.ACTIF.name(), CLIENT_OPERATEUR, NO_COMPTE, TYPE_OBJET_COMMERCIAL, CLIENT_OPERATEUR, NO_COMPTE, ID_RESSOURCE, RACCORDEMENT);
    st2.setOcIdentifiantFonctionnelPA("identifiantFonctionelIPA"); //$NON-NLS-1$

    createMockRSTserviceTechniqueLireTousParPfi(RetourFactory.createOkRetour(), Arrays.asList(st1, st2), CLIENT_OPERATEUR, NO_COMPTE);

    PFI pfi = __podam.manufacturePojo(PFI.class);
    //to avoid IllegalArgumentException due to the autoset of the PFI
    for (PA pa : pfi.getPa())
    {
      pa.setTypePA(TypePA.COMPTE_ACCES.name());
    }

    createMockRPGpfiLireUn(RetourFactory.createOkRetour(), pfi, CLIENT_OPERATEUR, NO_COMPTE);

    CaracteristiquesCommunes caractCommunes = new CaracteristiquesCommunes(CLIENT_OPERATEUR, NO_COMPTE);
    createMockBL5250(caractCommunes, RetourFactory.createOkRetour(), pfi);

    CaracteristiquesSpecifiques caractSpec = __podam.manufacturePojo(CaracteristiquesSpecifiques.class);
    createMockBL5260(caractSpec, RetourFactory.createOkRetour(), pfi, "identifiantFonctionelIPA"); //$NON-NLS-1$

    createMockBL5230(retourKoOther, ID_RESSOURCE, caractCommunes, caractSpec);

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verify();

    IRavelResponse response = request.getResponse();
    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(retourKoOther));

    assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());
    assertEquals(retourKoOther, _processInstance.getRetour());
  }

  /**
   * Test KO BL4600 returns 2 times (OK and KO).<br/>
   * RST returns:<br/>
   * 1 ServiceTechnique with LAC.typeRessource=Raccordement and statut=INACTIF<br/>
   * 2 ServiceTechnique with LAC.typeRessource=Raccordement and statut=ACTIF.<br/>
   * RPG returns OK and Pfi null.<br/>
   * BL5250 returns OK.<br/>
   * BL5260 returns OK.<br/>
   * BL5230 returns KO 2 times (RESSOURCE_INDISPONIBLE).<br/>
   * BL4600 returns OK first time and KO the second time.
   *
   * <b>Entrée:</b> input valid.<br/>
   * <b>Attendu:</b> KO | CAT3 | DONNEE_INVALIDE | libelle.<br/>
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void test_010_KO_BL4600() throws Throwable
  {
    Request request = prepareRequest(CLIENT_OPERATEUR, NO_COMPTE);
    Retour retourKoOther = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, "libelle"); //$NON-NLS-1$
    Retour retourKoResIndispo = RetourFactory.createNOK(IMegConsts.CAT3, RESSOURCE_INDISPONIBLE, "libelle"); //$NON-NLS-1$

    StLienAllocationCommercial st1 = new StLienAllocationCommercial(ID_ST, Statut.INACTIF.name(), CLIENT_OPERATEUR, NO_COMPTE, TYPE_OBJET_COMMERCIAL, CLIENT_OPERATEUR, NO_COMPTE, ID_RESSOURCE, RACCORDEMENT);

    StLienAllocationCommercial st2 = new StLienAllocationCommercial(ID_ST, Statut.ACTIF.name(), CLIENT_OPERATEUR, NO_COMPTE, TYPE_OBJET_COMMERCIAL, CLIENT_OPERATEUR, NO_COMPTE, ID_RESSOURCE, RACCORDEMENT);
    st2.setOcIdentifiantFonctionnelPA("identifiantFonctionelIPA"); //$NON-NLS-1$
    StLienAllocationCommercial st3 = new StLienAllocationCommercial(ID_ST, Statut.ACTIF.name(), CLIENT_OPERATEUR, NO_COMPTE, TYPE_OBJET_COMMERCIAL, CLIENT_OPERATEUR, NO_COMPTE, ID_RESSOURCE, RACCORDEMENT);
    st3.setOcIdentifiantFonctionnelPA("identifiantFonctionelIPA2"); //$NON-NLS-1$

    createMockRSTserviceTechniqueLireTousParPfi(RetourFactory.createOkRetour(), Arrays.asList(st1, st2, st3), CLIENT_OPERATEUR, NO_COMPTE);

    PFI pfi = __podam.manufacturePojo(PFI.class);
    //to avoid IllegalArgumentException due to the autoset of the PFI
    for (PA pa : pfi.getPa())
    {
      pa.setTypePA(TypePA.COMPTE_ACCES.name());
    }

    createMockRPGpfiLireUn(RetourFactory.createOkRetour(), pfi, CLIENT_OPERATEUR, NO_COMPTE);

    //FOR LOOP FIRST TIME 4600 OK
    CaracteristiquesCommunes caractCommunes = new CaracteristiquesCommunes(CLIENT_OPERATEUR, NO_COMPTE);
    createMockBL5250(caractCommunes, RetourFactory.createOkRetour(), pfi);

    CaracteristiquesSpecifiques caractSpec = __podam.manufacturePojo(CaracteristiquesSpecifiques.class);

    PowerMock.expectNew(BL5260_ExtraireCaracteristiquesSpecifiquesBuilder.class).andReturn(_bl5260Builder);
    EasyMock.expect(_bl5260Builder.tracabilite(_tracabilite)).andReturn(_bl5260Builder);
    EasyMock.expect(_bl5260Builder.pfi(pfi)).andReturn(_bl5260Builder);
    EasyMock.expect(_bl5260Builder.identifiantFonctionnelIPA("identifiantFonctionelIPA")).andReturn(_bl5260Builder); //$NON-NLS-1$
    EasyMock.expect(_bl5260Builder.build()).andReturn(_bl5260);
    EasyMock.expect(_bl5260.execute(_processInstance)).andReturn(caractSpec);
    EasyMock.expect(_bl5260.getRetour()).andReturn(RetourFactory.createOkRetour());

    PowerMock.expectNew(BL5260_ExtraireCaracteristiquesSpecifiquesBuilder.class).andReturn(_bl5260Builder);
    EasyMock.expect(_bl5260Builder.tracabilite(_tracabilite)).andReturn(_bl5260Builder);
    EasyMock.expect(_bl5260Builder.pfi(pfi)).andReturn(_bl5260Builder);
    EasyMock.expect(_bl5260Builder.identifiantFonctionnelIPA("identifiantFonctionelIPA2")).andReturn(_bl5260Builder); //$NON-NLS-1$
    EasyMock.expect(_bl5260Builder.build()).andReturn(_bl5260);
    EasyMock.expect(_bl5260.execute(_processInstance)).andReturn(caractSpec);
    EasyMock.expect(_bl5260.getRetour()).andReturn(RetourFactory.createOkRetour());

    createMockBL5230(retourKoResIndispo, ID_RESSOURCE, caractCommunes, caractSpec);

    PowerMock.expectNew(BL4600_CreerErreurSpiritBuilder.class).andReturn(_bl4600Builder);
    EasyMock.expect(_bl4600Builder.tracabilite(_tracabilite)).andReturn(_bl4600Builder);
    EasyMock.expect(_bl4600Builder.retour(retourKoResIndispo)).andReturn(_bl4600Builder);
    EasyMock.expect(_bl4600Builder.build()).andReturn(_bl4600);
    EasyMock.expect(_bl4600.execute(_processInstance)).andReturn(null);
    EasyMock.expect(_bl4600.getRetour()).andReturn(RetourFactory.createOkRetour());

    createMockBL5230(retourKoResIndispo, ID_RESSOURCE, caractCommunes, caractSpec);

    PowerMock.expectNew(BL4600_CreerErreurSpiritBuilder.class).andReturn(_bl4600Builder);
    EasyMock.expect(_bl4600Builder.tracabilite(_tracabilite)).andReturn(_bl4600Builder);
    EasyMock.expect(_bl4600Builder.retour(retourKoResIndispo)).andReturn(_bl4600Builder);
    EasyMock.expect(_bl4600Builder.build()).andReturn(_bl4600);
    EasyMock.expect(_bl4600.execute(_processInstance)).andReturn(null);
    EasyMock.expect(_bl4600.getRetour()).andReturn(retourKoOther);
    EasyMock.expect(_bl4600.getRetour()).andReturn(retourKoOther).times(2);

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verify();

    IRavelResponse response = request.getResponse();
    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(retourKoOther));

    assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());
    assertEquals(retourKoOther, _processInstance.getRetour());
  }

  /**
   * Test nominal OK case.<br/>
   * RST returns:<br/>
   * 1 ServiceTechnique with LAC.typeRessource=Raccordement and statut=INACTIF<br/>
   * 1 ServiceTechnique with LAC.typeRessource=Raccordement and statut=ACTIF.<br/>
   * RPG returns OK and Pfi null.<br/>
   * BL5250 returns OK.<br/>
   * BL5260 returns OK.<br/>
   * BL5230 returns OK.<br/>
   *
   * <b>Entrée:</b> input valid.<br/>
   * <b>Attendu:</b> OK.<br/>
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void test_011_OK() throws Throwable
  {
    Request request = prepareRequest(CLIENT_OPERATEUR, NO_COMPTE);
    StLienAllocationCommercial st1 = new StLienAllocationCommercial(ID_ST, Statut.INACTIF.name(), CLIENT_OPERATEUR, NO_COMPTE, TYPE_OBJET_COMMERCIAL, CLIENT_OPERATEUR, NO_COMPTE, ID_RESSOURCE, RACCORDEMENT);

    StLienAllocationCommercial st2 = new StLienAllocationCommercial(ID_ST, Statut.ACTIF.name(), CLIENT_OPERATEUR, NO_COMPTE, TYPE_OBJET_COMMERCIAL, CLIENT_OPERATEUR, NO_COMPTE, ID_RESSOURCE, RACCORDEMENT);
    st2.setOcIdentifiantFonctionnelPA("identifiantFonctionelIPA"); //$NON-NLS-1$

    createMockRSTserviceTechniqueLireTousParPfi(RetourFactory.createOkRetour(), Arrays.asList(st1, st2), CLIENT_OPERATEUR, NO_COMPTE);

    PFI pfi = __podam.manufacturePojo(PFI.class);
    //to avoid IllegalArgumentException due to the autoset of the PFI
    for (PA pa : pfi.getPa())
    {
      pa.setTypePA(TypePA.COMPTE_ACCES.name());
    }

    createMockRPGpfiLireUn(RetourFactory.createOkRetour(), pfi, CLIENT_OPERATEUR, NO_COMPTE);

    CaracteristiquesCommunes caractCommunes = new CaracteristiquesCommunes(CLIENT_OPERATEUR, NO_COMPTE);
    createMockBL5250(caractCommunes, RetourFactory.createOkRetour(), pfi);

    CaracteristiquesSpecifiques caractSpec = __podam.manufacturePojo(CaracteristiquesSpecifiques.class);
    createMockBL5260(caractSpec, RetourFactory.createOkRetour(), pfi, "identifiantFonctionelIPA"); //$NON-NLS-1$

    createMockBL5230(RetourFactory.createOkRetour(), ID_RESSOURCE, caractCommunes, caractSpec);

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verify();

    IRavelResponse response = request.getResponse();
    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(RetourFactory.createOkRetour()));

    assertEquals(ErrorCode.OK_00200, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());
    assertEquals(RetourFactory.createOkRetour(), _processInstance.getRetour());
  }

  /**
   * Create Mock for BL5230.
   *
   * @param retour_p
   *          the retour
   * @param idRessource_p
   *          idRessource
   * @param caractCommunes_p
   *          CaracteristiquesCommunes
   * @param caractSpec_p
   *          CaracteristiquesSpecifiques
   *
   * @throws Exception
   *           on error
   */
  private void createMockBL5230(Retour retour_p, String idRessource_p, CaracteristiquesCommunes caractCommunes_p, CaracteristiquesSpecifiques caractSpec_p) throws Exception
  {
    PowerMock.expectNew(BL5230_ReparerRessourceRaccordementBuilder.class).andReturn(_bl5230Builder);
    EasyMock.expect(_bl5230Builder.tracabilite(_tracabilite)).andReturn(_bl5230Builder);
    EasyMock.expect(_bl5230Builder.idRessource(idRessource_p)).andReturn(_bl5230Builder);
    EasyMock.expect(_bl5230Builder.caracteristiquesCommunes(caractCommunes_p)).andReturn(_bl5230Builder);
    EasyMock.expect(_bl5230Builder.caracteristiquesSpecifiques(caractSpec_p)).andReturn(_bl5230Builder);
    EasyMock.expect(_bl5230Builder.build()).andReturn(_bl5230);
    EasyMock.expect(_bl5230.execute(_processInstance)).andReturn(null);
    EasyMock.expect(_bl5230.getRetour()).andReturn(retour_p);
    EasyMock.expect(_bl5230.getRetour()).andReturn(retour_p);
    EasyMock.expect(_bl5230.getRetour()).andReturn(retour_p);
  }

  /**
   * Create mock for BL5250
   *
   * @param caractCommunes_p
   *          CaracteristiquesCommunes
   * @param retour_p
   *          the retour
   * @param pfi_p
   *          the PFI input
   * @throws Exception
   *           on errors
   */
  private void createMockBL5250(CaracteristiquesCommunes caractCommunes_p, Retour retour_p, PFI pfi_p) throws Exception
  {
    PowerMock.expectNew(BL5250_ExtraireCaracteristiquesCommunesBuilder.class).andReturn(_bl5250Builder);
    EasyMock.expect(_bl5250Builder.tracabilite(_tracabilite)).andReturn(_bl5250Builder);
    EasyMock.expect(_bl5250Builder.pfi(pfi_p)).andReturn(_bl5250Builder);
    EasyMock.expect(_bl5250Builder.build()).andReturn(_bl5250);
    EasyMock.expect(_bl5250.execute(_processInstance)).andReturn(caractCommunes_p);
    EasyMock.expect(_bl5250.getRetour()).andReturn(retour_p);
    EasyMock.expect(_bl5250.getRetour()).andReturn(retour_p);
  }

  /**
   * Create Mock for BL5260.
   *
   * @param caractSpec_p
   *          CaracteristiquesSpecifiques
   * @param retour_p
   *          the retour
   * @param pfi_p
   *          PFI
   * @param identifiantFonc_p
   *          identifiantFonctionelIPA
   *
   * @throws Exception
   *           on error
   */
  private void createMockBL5260(CaracteristiquesSpecifiques caractSpec_p, Retour retour_p, PFI pfi_p, String identifiantFonc_p) throws Exception
  {
    PowerMock.expectNew(BL5260_ExtraireCaracteristiquesSpecifiquesBuilder.class).andReturn(_bl5260Builder);
    EasyMock.expect(_bl5260Builder.tracabilite(_tracabilite)).andReturn(_bl5260Builder);
    EasyMock.expect(_bl5260Builder.pfi(pfi_p)).andReturn(_bl5260Builder);
    EasyMock.expect(_bl5260Builder.identifiantFonctionnelIPA(identifiantFonc_p)).andReturn(_bl5260Builder);
    EasyMock.expect(_bl5260Builder.build()).andReturn(_bl5260);
    EasyMock.expect(_bl5260.execute(_processInstance)).andReturn(caractSpec_p);
    EasyMock.expect(_bl5260.getRetour()).andReturn(retour_p);
    EasyMock.expect(_bl5260.getRetour()).andReturn(retour_p);
  }

  /**
   * Creates mock for method pfiLireUnFiltrerOCResilie in {@link RPGProxy}
   *
   * @param retour_p
   *          the retour
   * @param pfi_p
   *          the pfi
   * @param clientOperateur_p
   *          the clientOperateur
   * @param noCompte_p
   *          the noCompte
   * @throws RavelException
   *           on errors
   */
  private void createMockRPGpfiLireUn(Retour retour_p, PFI pfi_p, String clientOperateur_p, String noCompte_p) throws RavelException
  {
    ConnectorResponse<Retour, PFI> expectedResponse = new ConnectorResponse<Retour, PFI>(retour_p, pfi_p);
    EasyMock.expect(RPGProxy.getInstance()).andReturn(_rpgProxy);

    EasyMock.expect(_rpgProxy.pfiLireUn(_tracabilite, clientOperateur_p, noCompte_p)).andReturn(expectedResponse);
  }

  /**
   * Creates mock for method pfiLireTousParPfi in {@link RSTProxy}
   *
   * @param retour_p
   *          the retour
   * @param listeServiceTechniques_p
   *          the list of ServiceTechnique
   * @param clientOperateur_p
   *          the clientOperateur
   * @param noCompte_p
   *          the noCompte
   * @throws RavelException
   *           on errors
   */
  private void createMockRSTserviceTechniqueLireTousParPfi(Retour retour_p, List<ServiceTechnique> listeServiceTechniques_p, String clientOperateur_p, String noCompte_p) throws RavelException
  {
    ConnectorResponse<Retour, List<ServiceTechnique>> expectedResponse = new ConnectorResponse<Retour, List<ServiceTechnique>>(retour_p, listeServiceTechniques_p);
    EasyMock.expect(RSTProxy.getInstance()).andReturn(_rstProxy);

    EasyMock.expect(_rstProxy.serviceTechniqueLireTousParPfi(_tracabilite, clientOperateur_p, noCompte_p, TypeST.LAC.name(), StringConstants.EMPTY_STRING)).andReturn(expectedResponse);
  }

  /**
   * Create a Generic Request to call PI0035_RecupererPfiComplet
   *
   * @param clientOperateur_p
   *          The clientOperateur to add to the urlParameters
   * @param noCompte_p
   *          The noCompte to add to the urlParameters
   * @return GenericRequest to call PEI0028_RelancerCommande
   * @throws RavelException
   *           on error
   */
  private Request prepareRequest(String clientOperateur_p, String noCompte_p) throws RavelException
  {
    Request request = new Request(DEFAULT_PROCESSNAME, "idProcess", "idClient"); //$NON-NLS-1$ //$NON-NLS-2$
    request.setMsgId(Test_Consts.DEFAULT_MSGID);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();

    if (clientOperateur_p != null)
    {
      list.add(new Parameter(ParameterUrl.clientOperateur.name(), clientOperateur_p));
    }
    if (noCompte_p != null)
    {
      list.add(new Parameter(ParameterUrl.noCompte.name(), noCompte_p));
    }
    urlParametersType.setUrlParameters(list);
    request.setUrlParameters(urlParametersType);

    return request;
  }
}
