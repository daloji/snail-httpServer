/*******************************************************************************
 * $Id: PP0240_TraiterFichierListeOLTTest.java 17740 2019-02-27 14:00:00Z fbarnabe $
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.prof.processes.PP0240;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.easymock.EasyMock;
import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.response.IRavelResponse;
import com.bytel.ravel.common.factory.response.RavelResponseFactory;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.ACManagerUtil;
import com.bytel.ravel.common.utils.MarshallTools;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.RetourFactoryForTU;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.net.http.HttpConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.ProcessManager;
import com.bytel.spirit.common.connectors.res.RESProxy;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.ressources.RetourConverter;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.OltComposite;
import com.bytel.spirit.prof.processes.generated.ConfigurationPP0240;
import com.google.common.io.Files;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author jiantila
 * @version ($Revision: 17740 $ $Date: 2019-02-27 15:00:00 +0100 (mer. 27 févr. 2019) $)
 */

//Déclaration du runner de test pour lancer les TUs avec le runner PowerMock
@RunWith(PowerMockRunner.class)
//Préparation des classes pour les tests, toutes les classes comportant des méthodes statiques à mocker doivent être présentes dans l'annotation
@PrepareForTest({ RESProxy.class, System.class })
@PowerMockIgnore("javax.crypto.*")
public class PP0240_TraiterFichierListeOLTTest
{

  /**
   * The default process name.
   */
  public static final String DEFAULT_PROCESSNAME = PP0240_TraiterFichierListeOLTTest.class.getName();

  /**
   * OLT Config
   */
  private static final String OLT_CONFIG = "OLT_config.xml"; //$NON-NLS-1$

  /**
   * OLT Config avec balises "ListePE" et/ou "AdresseOLT" vides
   */
  private static final String OLT_VIDE_CONFIG = "OLT_vide_config.xml"; //$NON-NLS-1$

  /**
   * Tracabilite
   */
  private static Tracabilite _tracabilite;

  /**
   * Initialization method: Create: - spring context - connectors - service manager.
   *
   * @throws RavelException
   *           the exception
   */
  @BeforeClass
  public static void init() throws RavelException
  {
    ACManagerUtil.resetACManager();
    new ClassPathXmlApplicationContext("classpath:BeansProcessTestMocks.xml"); //$NON-NLS-1$
  }

  /**
   *
   */
  @MockStrict
  private RESProxy _resProxy;

  /**
   * The temporary destination folder.
   */
  private TemporaryFolder _tempFolder;

  /**
   * File folder config
   */
  private File _tempFolderConfig;

  /**
   * File folder Echec
   */
  private File _tempFolderEchec;

  /**
   * File folder Succes
   */
  private File _tempFolderSucces;

  /**
   * Confuguration Processus
   */
  private ConfigurationPP0240 _configuration;

  /**
   * Factory to generate beans
   */
  private PodamFactory _podam = new PodamFactoryImpl();

  /**
   *
   */
  PP0240_TraiterFichierListeOLT _currentInstance;

  private String _os = System.getProperty("os.name").toLowerCase(); //$NON-NLS-1$

  /**
   * after Test The file copy config OLT must copy to initial folder
   */
  @After
  public void afterTest()
  {
    _tempFolder.delete();
    _tempFolderConfig.delete();
    _tempFolderEchec.delete();
    _tempFolderSucces.delete();
  }

  /**
   * before Test
   *
   * @throws Throwable
   *           exception
   *
   */
  @Before
  public void beforeTest() throws Throwable
  {
    _podam.getStrategy().setMemoization(false);
    // Initialize the context
    _currentInstance = new PP0240_TraiterFichierListeOLT();
    _currentInstance.initializeContext();

    _tracabilite = new Tracabilite();
    _tracabilite.setIdProcessusSpirit(_currentInstance.getIdProcess());
    _tracabilite.setIdCorrelationSpirit(null);
    _tracabilite.setIdCorrelationByTel(StringConstants.EMPTY_STRING);
    _tracabilite.setNomProcessus(StringConstants.EMPTY_STRING);
    _tracabilite.setNomSysteme(System.getenv("SERVICE")); //$NON-NLS-1$
    Map<String, String> refFonc = new HashMap<>();
    refFonc.put("nomfichier", OLT_CONFIG); //$NON-NLS-1$
    _tracabilite.setRefFonc(refFonc);

    _tempFolder = new TemporaryFolder();
    _tempFolder.create();
    //creation repertoire config dans le repertoire temporaire
    _tempFolderConfig = _tempFolder.newFolder("Config"); //$NON-NLS-1$
    //creation repertoire Echec dans le repertoire temporaire
    _tempFolderEchec = _tempFolder.newFolder("Echec"); //$NON-NLS-1$
    //creation repertoire Succes dans le repertoire temporaire
    _tempFolderSucces = _tempFolder.newFolder("Succes"); //$NON-NLS-1$
    //creation ConfigurationPP0240
    _configuration = new ConfigurationPP0240();
    _configuration.setRepertoireSource(_tempFolderConfig.getAbsolutePath());
    _configuration.setMasqueNomFichier("OLT*"); //$NON-NLS-1$
    _configuration.setRepertoireEchec(_tempFolderEchec.getAbsolutePath());
    _configuration.setRepertoireSucces(_tempFolderSucces.getAbsolutePath());
    Map<String, String> versionConfig = new HashMap<>();
    versionConfig.put("NOKIA", "nokia"); //$NON-NLS-1$ //$NON-NLS-2$
    versionConfig.put("HUAWEI", "huawei"); //$NON-NLS-1$//$NON-NLS-2$
    _configuration.setVersionInterfaceEchange(versionConfig);
    //generation String a partir de l'objet ConfigurationPP0240
    String configXml = MarshallTools.marshall(_configuration);
    String extension = ".xml"; //$NON-NLS-1$

    //creation du fichier de configuration dans le dossier temporaire Config
    File file = File.createTempFile("ConfigurationPP0240", extension, _tempFolderConfig); //$NON-NLS-1$
    BufferedWriter bw = new BufferedWriter(new FileWriter(file));
    bw.write(configXml);
    bw.close();
    Map<String, String> map = new HashMap<>();
    map.put("FILE_PATH", file.getAbsolutePath()); //$NON-NLS-1$
    String filename = getFilePath("OLT_vide_config.xml"); //$NON-NLS-1$
    //copie du fichier de configuration OLT dans le dossier de configuration temporaire Config
    copyFileConfig(filename, _tempFolderConfig + File.separator + OLT_CONFIG);
    ConcurrentHashMap<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.put(StringConstants.EMPTY_STRING, map);
    //deactivate cache podam

    PowerMock.resetAll();
    PowerMock.mockStatic(RESProxy.class);
    PowerMock.mockStatic(System.class);
  }

  /**
   * Copy file
   *
   * @param source_p
   *          source
   * @param destination_p
   *          destination
   */
  public void copyFileConfig(String source_p, String destination_p)
  {

    if ((source_p != null) && (destination_p != null))
    {
      Path pathSrc = Paths.get(source_p);
      Path pathDest = Paths.get(destination_p);

      try
      {
        Files.copy(pathSrc.toFile(), pathDest.toFile());
      }
      catch (IOException exception)
      {
        fail("Should not append : " + exception.getMessage()); //$NON-NLS-1$
      }

    }
  }

  /**
   *
   * PP0240_TraiterFichierListeOLT (connector RES ERROR)
   *
   * @throws Throwable
   *           exception
   */
  @Test
  public void PP0240_TraiterFichierListeOLT_K0_002() throws Throwable
  {
    Request request = new Request(DEFAULT_PROCESSNAME, "idProcess", "idClient"); //$NON-NLS-1$ //$NON-NLS-2$
    Retour retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, ""); //$NON-NLS-1$
    ConnectorResponse<Retour, Nothing> connectRep = new ConnectorResponse<Retour, Nothing>(retour, null);
    createMockRes(connectRep);
    PowerMock.replayAll();
    _currentInstance.run(request);
    PowerMock.verifyAll();

    com.bytel.ravel.types.Retour retourp = RetourConverter.convertToJsonRetour(retour);
    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    response.setResult(GsonTools.getIso8601Ms().toJson(retourp));

    final Response expected = new Response(ErrorCode.KO_00500, response);

    assertEquals(expected.getMarshalledResponseJson(), request.getResponse().getMarshalledResponseJson());
    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());

  }

  /**
   * Config FILE_PATH is not set (Configuration processus not valid)
   *
   * @throws Throwable
   *           exception
   */
  @Test
  public void PP0240_TraiterFichierListeOLT_KO_001() throws Throwable
  {

    ConcurrentHashMap<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.clear();
    Request request = new Request(DEFAULT_PROCESSNAME, "idProcess", "idClient"); //$NON-NLS-1$ //$NON-NLS-2$
    PowerMock.replayAll();
    _currentInstance.run(request);
    PowerMock.verifyAll();

    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, "Les paramètres de config sont manquants"); //$NON-NLS-1$
    retour.setActivite("PP0240_BL001_VerifierDonnees"); //$NON-NLS-1$
    com.bytel.ravel.types.Retour retourp = RetourConverter.convertToJsonRetour(retour);
    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    response.setResult(GsonTools.getIso8601Ms().toJson(retourp));
    final Response expected = new Response(ErrorCode.KO_00500, response);
    assertEquals(expected.getMarshalledResponseJson(), request.getResponse().getMarshalledResponseJson());
    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());

  }

  /**
   *
   * PP0240_TraiterFichierListeOLT (cas Nominal)
   *
   * @throws Throwable
   *           exception
   */
  @Test
  public void PP0240_TraiterFichierListeOLT_OK_001() throws Throwable
  {
    Request request = new Request(DEFAULT_PROCESSNAME, "idProcess", "idClient"); //$NON-NLS-1$ //$NON-NLS-2$
    ConnectorResponse<Retour, Nothing> connectRep = new ConnectorResponse<Retour, Nothing>(RetourFactory.createOkRetour(), null);
    createMockRes(connectRep);
    PowerMock.replayAll();
    _currentInstance.run(request);
    PowerMock.verifyAll();
    String fileSuccess = _tempFolderSucces.getAbsolutePath() + File.separator + OLT_CONFIG;
    File file = new File(fileSuccess);
    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    final Response expected = new Response(ErrorCode.OK_00201, response);
    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());
    assertTrue(file.exists());

  }

  /**
   * cas Nominal mais avec le fichier OLT non Trouve
   *
   * @throws Throwable
   *           exception
   */
  @Test
  public void PP0240_TraiterFichierListeOLT_OK_002() throws Throwable
  {
    _configuration.setMasqueNomFichier("OLTKO*"); //$NON-NLS-1$
    String configXml = MarshallTools.marshall(_configuration);
    String extension = ".xml"; //$NON-NLS-1$
    //creation du fichier de configuration dans le dossier temporaire Config
    File file = File.createTempFile("ConfigurationPP0240", extension, _tempFolderConfig); //$NON-NLS-1$
    BufferedWriter bw = new BufferedWriter(new FileWriter(file));
    bw.write(configXml);
    bw.close();
    Map<String, String> map = new HashMap<>();
    map.put("FILE_PATH", file.getAbsolutePath()); //$NON-NLS-1$
    ConcurrentHashMap<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.clear();
    processParams.put(StringConstants.EMPTY_STRING, map);

    Request request = new Request(DEFAULT_PROCESSNAME, "idProcess", "idClient"); //$NON-NLS-1$ //$NON-NLS-2$
    PowerMock.replayAll();
    _currentInstance.run(request);
    PowerMock.verifyAll();

    Retour retour = RetourFactory.createOkRetour();
    com.bytel.ravel.types.Retour retourp = RetourConverter.convertToJsonRetour(retour);
    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    response.setResult(GsonTools.getIso8601Ms().toJson(retourp));

    final Response expected = new Response(ErrorCode.OK_00201, response);

    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());

  }

  /**
   *
   * PP0240_TraiterFichierListeOLT (cas Nominal)
   *
   * @throws Throwable
   *           exception
   */
  @Test
  public void PP0240_TraiterFichierListeOLT_OK_003() throws Throwable
  {
    //Changement du fichier de conf pour les besoins du test
    String filename = getFilePath("OLT_vide_config.xml"); //$NON-NLS-1$
    //copie du fichier de configuration OLT dans le dossier de configuration temporaire Config
    copyFileConfig(filename, _tempFolderConfig + File.separator + OLT_CONFIG);

    Request request = new Request(DEFAULT_PROCESSNAME, "idProcess", "idClient"); //$NON-NLS-1$ //$NON-NLS-2$

    String idOlt = "OLT0088"; //$NON-NLS-1$
    String nomNR = "SI584620"; //$NON-NLS-1$
    String constructeur = "NOKIA"; //$NON-NLS-1$
    String modeleOLT = "7302 ISAM FD"; //$NON-NLS-1$
    String version = _configuration.getVersionInterfaceEchange().get(constructeur);
    String statutTechnique = "INCOMPLET"; //$NON-NLS-1$
    OltComposite oltComposite = new OltComposite(idOlt, nomNR, constructeur, modeleOLT, StringConstants.EMPTY_STRING, version, statutTechnique);
    oltComposite.setNomProviderEdge(new HashSet<>());
    oltComposite.setListeCarteP2P(new HashMap<>());
    ConnectorResponse<Retour, Nothing> connectRep = new ConnectorResponse<Retour, Nothing>(RetourFactory.createOkRetour(), null);

    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxy);
    EasyMock.expect(_resProxy.oltCompositeGererImport(_tracabilite, oltComposite)).andReturn(connectRep);

    PowerMock.replayAll();
    _currentInstance.run(request);
    PowerMock.verifyAll();
    String fileSuccess = _tempFolderSucces.getAbsolutePath() + File.separator + OLT_CONFIG;
    File file = new File(fileSuccess);
    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    final Response expected = new Response(ErrorCode.OK_00201, response);
    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());
    assertTrue(file.exists());
  }

  /**
   * create Mock ResProxy
   *
   * @param connectRep
   *          connect Rep
   * @throws RavelException
   *           exception
   */
  private void createMockRes(ConnectorResponse<Retour, Nothing> connectRep) throws RavelException
  {
    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxy);
    EasyMock.expectLastCall().anyTimes();
    EasyMock.expect(_resProxy.oltCompositeGererImport(EasyMock.eq(_tracabilite), EasyMock.anyObject(OltComposite.class))).andReturn(connectRep);
    EasyMock.expectLastCall().anyTimes();
  }

  /**
   * Get Path from file name
   *
   * @param filename
   *          file name
   * @return String file
   */
  private String getFilePath(String filename)
  {
    URL url = this.getClass().getResource("/" + filename); //$NON-NLS-1$
    if (url == null)
    {
      return filename;
    }

    String tmp = url.getFile();
    if (_os.indexOf("win") >= 0) //$NON-NLS-1$
    {
      tmp = tmp.replace('/', '\\');
      if (tmp.startsWith("\\")) //$NON-NLS-1$
      {
        tmp = tmp.substring(1);
      }
    }

    return tmp;

  }

}
