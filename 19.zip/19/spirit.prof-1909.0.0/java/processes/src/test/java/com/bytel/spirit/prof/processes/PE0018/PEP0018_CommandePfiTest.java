/*******************************************************************************
* $Id: PEP0018_CommandePfiTest.java 18026 2019-03-06 10:50:14Z jiantila $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PE0018;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.text.MessageFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentMap;

import org.apache.commons.lang3.RandomStringUtils;
import org.easymock.EasyMock;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.Mock;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.reflect.Whitebox;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.configuration.ConfigFileManager;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.response.IRavelResponse;
import com.bytel.ravel.common.factory.response.RavelResponseFactory;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.utils.ACManagerUtil;
import com.bytel.ravel.common.utils.DateTimeTools.DateTimeFormatPattern;
import com.bytel.ravel.common.utils.Pair;
import com.bytel.ravel.common.utils.RetourFactoryForTU;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.ProcessManager;
import com.bytel.spirit.common.activities.shared.BL200_ObtenirServiceCommercial;
import com.bytel.spirit.common.activities.shared.BL200_ObtenirServiceCommercial.BL200_ObtenirServiceCommercialBuilder;
import com.bytel.spirit.common.activities.shared.BL4600_CreerErreurSpirit;
import com.bytel.spirit.common.activities.shared.BL4600_CreerErreurSpirit.BL4600_CreerErreurSpiritBuilder;
import com.bytel.spirit.common.activities.shared.BL5200_GererRaccordementCommercial;
import com.bytel.spirit.common.activities.shared.BL5200_GererRaccordementCommercial.BL5200_GererRaccordementCommercialBuilder;
import com.bytel.spirit.common.connectors.cmd.CMDProxy;
import com.bytel.spirit.common.connectors.rex.REXProxy;
import com.bytel.spirit.common.connectors.rpg.RPGProxy;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.ressources.RetourConverter;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.cmd.ClientOperateur;
import com.bytel.spirit.common.shared.saab.cmd.Commande;
import com.bytel.spirit.common.shared.saab.rpg.CatalogServiceCommercial;
import com.bytel.spirit.common.shared.saab.rpg.PFI;
import com.bytel.spirit.common.shared.saab.rpg.Statut;
import com.bytel.spirit.prof.processes.Messages;
import com.bytel.spirit.prof.processes.PE0018.structs.PEP0018_Retour;
import com.bytel.spirit.prof.shared.types.abstracts.AbstractPointAcces;
import com.bytel.spirit.prof.shared.types.json.ClientTitulaire;
import com.bytel.spirit.prof.shared.types.json.CommandeId;
import com.bytel.spirit.prof.shared.types.json.CommandePfi;
import com.bytel.spirit.prof.shared.types.json.PortefeuilleServices;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author jiantila
 * @version ($Revision: 18026 $ $Date: 2019-03-06 11:50:14 +0100 (mer., 06 mars 2019) $)
 */
@RunWith(PowerMockRunner.class)
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
@PrepareForTest({ PEP0018_CommandePfi.class, REXProxy.class, GsonTools.class, BL4600_CreerErreurSpirit.class, BL4600_CreerErreurSpiritBuilder.class, BL5200_GererRaccordementCommercialBuilder.class, BL5200_GererRaccordementCommercial.class, BL200_ObtenirServiceCommercial.class, BL200_ObtenirServiceCommercialBuilder.class, CMDProxy.class, RPGProxy.class })
public class PEP0018_CommandePfiTest
{

  /**
   * Configuration parameter INK_CONNECTOR_ID
   */
  private static final String INK_CONNECTORID_PARAM = "INK_CONNECTOR_ID"; //$NON-NLS-1$

  /**
   * Factory de génération des beans
   */
  private static PodamFactory __podam = new PodamFactoryImpl();

  /**
   * SPRING context
   */
  private static ClassPathXmlApplicationContext __context;

  /**
   * ConfigFileManager singleton
   */
  private static ConfigFileManager _configFileManager;

  /**
   * @throws Exception
   */
  @BeforeClass
  public static void setUpBeforeClass() throws Exception
  {
    // désactivation du cache podam
    __podam.getStrategy().setMemoization(false);
    __podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());

    ACManagerUtil.resetACManager();
    __context = new ClassPathXmlApplicationContext("classpath:BeansProcessTestMocks.xml"); //$NON-NLS-1$

    _configFileManager = new ConfigFileManager(""); //$NON-NLS-1$
    GsonTools.getGsonTools().init("src/test/resources/ravelJsonConf.xml"); //$NON-NLS-1$
    Map<String, String> map = new HashMap<>();
    map.put(INK_CONNECTORID_PARAM, "InkConnectorV2"); //$NON-NLS-1$
    ConcurrentMap<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.put(StringConstants.EMPTY_STRING, map);

  }

  /**
   * BL200_ObtenirServiceCommercial Mock
   */
  @Mock
  private BL200_ObtenirServiceCommercial bl200Mock;

  /**
   * BL200_ObtenirServiceCommercialBuilder Mock
   */
  @Mock
  private BL200_ObtenirServiceCommercialBuilder bl200BuilderMock;

  /**
   * BL5200_GererRaccordementCommercialBuilder Mock
   */
  @Mock
  private BL5200_GererRaccordementCommercialBuilder bl5200BuilderMock;

  /**
   * BL5200_GererRaccordementCommercial Mock
   */
  @Mock
  private BL5200_GererRaccordementCommercial bl5200Mock;

  /**
   * BL4600_CreerErreurSpirit Mock
   */
  @Mock
  private BL4600_CreerErreurSpirit bl4600Mock;

  /**
   * BL4600_CreerErreurSpiritBuilder Mock
   */
  @Mock
  private BL4600_CreerErreurSpiritBuilder bl4600BuilderMock;

  /**
   * generator data of PFI
   */
  private PFIFullForTest _pfiGenerator;

  /**
   * Tracabilite
   */
  private Tracabilite tracabilite;

  /**
   * _CMDProxyMock Mock
   */
  @Mock
  private CMDProxy cmdProxyMock;

  /**
   * RPGProxyMock Mock
   */
  @Mock
  private RPGProxy rpgProxyMock;

  /**
   * REXProxy Mock
   */
  @Mock
  private REXProxy rexProxyMock;

  /**
   * Instance of {@code PEI0018_CommandePfi}
   */
  private PEP0018_CommandePfi _processInstance;

  /**
   * Tests the PEP0018_BL001_VerifierDonnees method when idcmd null returns KO
   *
   * <b>Inputs:</b> idcm null k<br>
   * <b>Expected:</b> Retour {KO; CAT3; Donnee invalid; "Le parametre idCmd en entrée est invalide."}<br>
   *
   * @throws Throwable
   *
   * @throws Exception
   *           on unexpected error
   */
  @Test
  public void PEP0018_BL001_VerifierDonnees_KO_001() throws Throwable
  {

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    Retour retourexpect = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegConsts.DONNEE_INVALIDE, "Le parametre idCmd en entrée est invalide."); //$NON-NLS-1$
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();
    Response response = (Response) request.getResponse();
    String resp = response.getGenericResponse().getResult();
    PEP0018_Retour PepReponse = GsonTools.getIso8601Sec().fromJson(resp, PEP0018_Retour.class);

    Assert.assertEquals(ErrorCode.KO_00400, request.getResponse().getErrorCode());
    Assert.assertEquals(PepReponse.getRetour().getResultat(), retourexpect.getResultat());
    Assert.assertEquals(PepReponse.getRetour().getDiagnostic(), retourexpect.getDiagnostic());
    Assert.assertEquals(PepReponse.getRetour().getLibelle(), retourexpect.getLibelle());
  }

  /**
   * Tests the PEP0018_BL001_VerifierDonnees method when CMDProxy returns KO
   *
   * <b>Inputs:</b> idcm null k<br>
   * <b>Expected:</b> Retour {KO; CAT2; ERREUR_TECHNIQUE; "erreur"}<br>
   *
   * @throws Throwable
   *
   * @throws Exception
   *           on unexpected error
   */
  @Test
  public void PEP0018_BL001_VerifierDonnees_KO_002() throws Throwable
  {
    Commande command = __podam.manufacturePojo(Commande.class);
    command.setIdCmd("111"); //$NON-NLS-1$
    command.setStatut("ACQUITTE"); //$NON-NLS-1$
    CommandeId cmdId = new CommandeId(command.getIdCmd());
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    request.setPayload(GsonTools.getIso8601Ms().toJson(cmdId));
    Retour retourKo = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegConsts.ERREUR_TECHNIQUE, "erreur"); //$NON-NLS-1$
    ConnectorResponse<Retour, Commande> connectorRep = new ConnectorResponse<Retour, Commande>(retourKo, command);
    //prepare mock Cmd
    prepareMockCmdCommandeLireUn(connectorRep, command.getIdCmd());
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();
    Response response = (Response) request.getResponse();
    String resp = response.getGenericResponse().getResult();
    PEP0018_Retour PepReponse = GsonTools.getIso8601Sec().fromJson(resp, PEP0018_Retour.class);

    Assert.assertEquals(ErrorCode.KO_00400, request.getResponse().getErrorCode());
    Assert.assertEquals(PepReponse.getRetour().getResultat(), retourKo.getResultat());
    Assert.assertEquals(PepReponse.getRetour().getDiagnostic(), retourKo.getDiagnostic());
    Assert.assertEquals(PepReponse.getRetour().getLibelle(), retourKo.getLibelle());
  }

  /**
   * Tests the PEP0018_BL001_VerifierDonnees KO command STATUT != ACQUITTE
   *
   * <b>Inputs:</b> idcm null k<br>
   * <b>Expected:</b> Retour {KO; CAT2; ERREUR_TECHNIQUE; "erreur"}<br>
   *
   * @throws Throwable
   *
   * @throws Exception
   *           on unexpected error
   */
  @Test
  public void PEP0018_BL001_VerifierDonnees_KO_003() throws Throwable
  {
    Commande command = __podam.manufacturePojo(Commande.class);
    command.setIdCmd("111"); //$NON-NLS-1$
    command.setStatut("ENCOURS"); //$NON-NLS-1$
    CommandeId cmdId = new CommandeId(command.getIdCmd());
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    request.setPayload(GsonTools.getIso8601Ms().toJson(cmdId));
    ConnectorResponse<Retour, Commande> connectorRep = new ConnectorResponse<Retour, Commande>(RetourFactoryForTU.createOkRetour(), command);

    //prepare mock Cmd
    prepareMockCmdCommandeLireUn(connectorRep, command.getIdCmd());
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();
    Response response = (Response) request.getResponse();
    String resp = response.getGenericResponse().getResult();
    PEP0018_Retour PepReponse = GsonTools.getIso8601Sec().fromJson(resp, PEP0018_Retour.class);

    Assert.assertEquals(ErrorCode.KO_00400, request.getResponse().getErrorCode());
    Assert.assertEquals(PepReponse.getRetour().getCategorie(), IMegConsts.CAT4);
    Assert.assertEquals(PepReponse.getRetour().getDiagnostic(), IMegConsts.DONNEE_INVALIDE);
    Assert.assertEquals(PepReponse.getRetour().getLibelle(), "La commande 111 est au statut ENCOURS, elle ne peut pas être traitée par ce processus"); //$NON-NLS-1$

  }

  /**
   * Nominal case for the PEP0018_BL001_VerifierDonnees method<br>
   *
   * <b>Inputs:</b> Valid inputs <br>
   * <b>Expected:</b> Retour {OK}<br>
   *
   * @throws Exception
   *           on unexpected error
   */

  @Test
  public void PEP0018_BL001_VerifierDonnees_OK_001() throws Exception
  {

    String idCmd = RandomStringUtils.random(5);
    Retour retourExpected = RetourFactoryForTU.createOkRetour();
    Commande commandeExpected = __podam.manufacturePojo(Commande.class);
    commandeExpected.setStatut("ACQUITTE"); //$NON-NLS-1$
    CommandePfi commandePfi = __podam.manufacturePojo(CommandePfi.class);
    commandeExpected.setDonneesBrut(GsonTools.getIso8601Ms().toJson(commandePfi));
    ConnectorResponse<Retour, Commande> responseExpected = new ConnectorResponse<Retour, Commande>(retourExpected, commandeExpected);
    //prepare mock Cmd
    prepareMockCmdCommandeLireUn(responseExpected, idCmd);
    PowerMock.replayAll();
    Pair<Retour, Commande> bl001 = Whitebox.invokeMethod(_processInstance, "PEP0018_BL001_VerifierDonnees", tracabilite, idCmd); //$NON-NLS-1$
    PowerMock.verifyAll();

    assertEquals(retourExpected, bl001._first);
    assertEquals(commandeExpected, bl001._second);
  }

  /**
   * Test KO for the PEP0018_BL002_FormaterReponse method
   *
   * <b>Inputs: </b>Random ko generated<br>
   * <b>Expected: </b> Retour{KO}
   *
   * @throws Exception
   *           On unexpected error
   */

  @Test
  public void PEP0018_BL002_FormaterReponse_KO_001() throws Exception
  {
    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.ERREUR_INTERNE, "Erreur interne", null); //$NON-NLS-1$
    Commande commande = __podam.manufacturePojo(Commande.class);

    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setResult(GsonTools.getIso8601Ms().toJson(retourExpected));
    Response expectedResponse = new Response(ErrorCode.KO_00400, ravelResponse);

    PowerMock.replayAll();
    Pair<Response, Retour> bl002 = Whitebox.invokeMethod(_processInstance, "PEP0018_BL002_FormaterReponse", tracabilite, retourExpected, commande); //$NON-NLS-1$
    PowerMock.verifyAll();
    Assert.assertNotNull(bl002._first);
    Assert.assertNotNull(bl002._second);
    Assert.assertEquals(expectedResponse.getErrorCode(), bl002._first.getErrorCode());

    Assert.assertEquals(retourExpected, bl002._second);
  }

  /**
   * Test OK for the PEP0018_BL002_FormaterReponse method
   *
   * <b>Inputs: </b>Random ok generated<br>
   * <b>Expected: </b> Retour{OK}
   *
   * @throws Exception
   *           On unexpected error
   */

  @Test
  public void PEP0018_BL002_FormaterReponse_OK_001() throws Exception
  {
    Retour retourExpected = RetourFactoryForTU.createOkRetour();
    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setResult(GsonTools.getIso8601Ms().toJson(retourExpected));
    Response expectedResponse = new Response(ErrorCode.OK_00200, ravelResponse);
    Commande commande = __podam.manufacturePojo(Commande.class);
    PowerMock.replayAll();
    Pair<Response, Retour> bl002 = Whitebox.invokeMethod(_processInstance, "PEP0018_BL002_FormaterReponse", tracabilite, retourExpected, commande); //$NON-NLS-1$
    PowerMock.verifyAll();
    Assert.assertNotNull(bl002._first);
    Assert.assertNotNull(bl002._second);
    Assert.assertEquals(expectedResponse.getErrorCode(), bl002._first.getErrorCode());
    Assert.assertEquals(retourExpected, bl002._second);
  }

  /**
   * Test OK for the PEP0018_BL002_FormaterReponse method, commande EN_COUR
   *
   * <b>Inputs: </b>Random ok generated<br>
   * <b>Expected: </b> Retour{OK}
   *
   * @throws Exception
   *           On unexpected error
   */

  @Test
  public void PEP0018_BL002_FormaterReponse_OK_002() throws Exception
  {
    Retour retourExpected = RetourFactoryForTU.createOkRetour();
    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    PEP0018_Retour pep0018_retour = new PEP0018_Retour(RetourConverter.convertToJsonRetour(retourExpected));
    PEP0018_Retour.ReponseFonctionnelle reponseFonctionnelle = new PEP0018_Retour.ReponseFonctionnelle();
    reponseFonctionnelle.setClientOperateur("BSS_GP"); //$NON-NLS-1$
    reponseFonctionnelle.setNoCompte("123456789"); //$NON-NLS-1$
    pep0018_retour.setReponseFonctionnelle(reponseFonctionnelle);
    ravelResponse.setResult(GsonTools.getIso8601Ms().toJson(pep0018_retour));
    Response expectedResponse = new Response(ErrorCode.OK_00200, ravelResponse);
    Commande commande = __podam.manufacturePojo(Commande.class);
    commande.setClientOperateur("BSS_GP"); //$NON-NLS-1$
    commande.setNoCompte("123456789"); //$NON-NLS-1$
    commande.setStatut(com.bytel.spirit.common.shared.saab.cmd.Statut.EN_COURS.name());

    PowerMock.replayAll();
    Pair<Response, Retour> bl002 = Whitebox.invokeMethod(_processInstance, "PEP0018_BL002_FormaterReponse", tracabilite, retourExpected, commande); //$NON-NLS-1$
    PowerMock.verifyAll();

    Assert.assertNotNull(bl002._first);
    Assert.assertNotNull(bl002._second);
    Assert.assertEquals(expectedResponse.getErrorCode(), bl002._first.getErrorCode());
    Assert.assertEquals(expectedResponse.getMarshalledResponseJson(), bl002._first.getMarshalledResponseJson());
    Assert.assertEquals(retourExpected, bl002._second);
  }

  /**
   * Tests the PEP0018_BL100_RecupererPfiExistant method when an error (!= CAT-4) occurs in RPG002<br>
   *
   * <b>Inputs: </b>Generated KO on RPG002 mock<br>
   * <b>Expected: </b> Retour{KO; CAT-1; ERREUR_TECHNIQUE; ""}<br>
   *
   * @throws Exception
   *           On unexpected error
   */

  @Test
  public void PEP0018_BL100_RecupererPfiExistant_KO_001() throws Exception
  {

    Commande commande = __podam.manufacturePojo(Commande.class);
    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT1, IMegConsts.ERREUR_TECHNIQUE, StringConstants.EMPTY_STRING, null);
    ConnectorResponse<Retour, PFI> connectResponse = new ConnectorResponse<Retour, PFI>(retourExpected, null);

    //prepare mock RPG
    prepareMockRpgPfiLireUn(connectResponse, commande.getClientOperateur(), commande.getNoCompte());

    PowerMock.replayAll();
    Pair<Retour, PFI> bl100 = Whitebox.invokeMethod(_processInstance, "PEP0018_BL100_RecupererPfiExistant", tracabilite, commande); //$NON-NLS-1$
    PowerMock.verifyAll();

    Assert.assertEquals(retourExpected, bl100._first);
    Assert.assertNull(bl100._second);
  }

  /**
   * Tests the PEP0018_BL001_VerifierDonnees method when RpgProxy returns KO
   *
   * <b>Inputs:</b> commande with porteuille null k<br>
   * <b>Expected:</b> Retour {KO; CAT2; ERREUR_TECHNIQUE; "erreur"}<br>
   *
   * @throws Throwable
   *
   * @throws Exception
   *           on unexpected error
   */
  @Test
  public void PEP0018_BL100_RecupererPfiExistant_KO_002() throws Throwable
  {
    CommandePfi commandePfi = __podam.manufacturePojo(CommandePfi.class); //CommandePFI to put in donnees Brut of command
    commandePfi.getPortefeuilleServices().setStatut(Statut.ACTIF.name());
    commandePfi.setTimestamp(LocalDateTime.now().plusDays(1));
    Commande command = __podam.manufacturePojo(Commande.class);
    command.setIdCmd("111"); //$NON-NLS-1$
    command.setStatut("ACQUITTE"); //$NON-NLS-1$
    command.setDonneesBrut(GsonTools.getIso8601Ms().toJson(commandePfi));
    CommandeId cmdId = new CommandeId(command.getIdCmd());
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    request.setPayload(GsonTools.getIso8601Ms().toJson(cmdId));
    ConnectorResponse<Retour, Commande> connectorRep = new ConnectorResponse<Retour, Commande>(RetourFactoryForTU.createOkRetour(), command);
    //prepare mock CMD proxy
    prepareMockCmdCommandeLireUn(connectorRep, command.getIdCmd());
    Retour retourKo = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegConsts.ERREUR_TECHNIQUE, "erreur"); //$NON-NLS-1$
    ConnectorResponse<Retour, PFI> connectorRpg = new ConnectorResponse<Retour, PFI>(retourKo, null);
    //prepare mock RPG
    prepareMockRpgPfiLireUn(connectorRpg, command.getClientOperateur(), command.getNoCompte());
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();
    Response response = (Response) request.getResponse();
    String resp = response.getGenericResponse().getResult();
    PEP0018_Retour PepReponse = GsonTools.getIso8601Sec().fromJson(resp, PEP0018_Retour.class);

    Assert.assertEquals(ErrorCode.KO_00400, request.getResponse().getErrorCode());
    Assert.assertEquals(PepReponse.getRetour().getCategorie(), IMegConsts.CAT2);
    Assert.assertEquals(PepReponse.getRetour().getDiagnostic(), IMegConsts.ERREUR_TECHNIQUE);
    Assert.assertEquals(PepReponse.getRetour().getLibelle(), "erreur"); //$NON-NLS-1$

  }

  /**
   * Test OK for the PEP0018_BL100_RecupererPfiExistant method<br>
   *
   * <b>Inputs: </b>Valid inputs<br>
   * <b>Expected: </b> Retour{OK}<br>
   *
   * @throws Exception
   *           On unexpected error
   */

  @Test
  public void PEP0018_BL100_RecupererPfiExistant_OK_001() throws Exception
  {
    Commande commande = __podam.manufacturePojo(Commande.class);
    Retour retourExpected = RetourFactoryForTU.createOkRetour();
    PFI pfiExpected = new PFI();
    ConnectorResponse<Retour, PFI> connectorRpg = new ConnectorResponse<Retour, PFI>(retourExpected, pfiExpected);
    //prepare mock RPG proxy
    prepareMockRpgPfiLireUn(connectorRpg, commande.getClientOperateur(), commande.getNoCompte());
    PowerMock.replayAll();
    Pair<Retour, PFI> bl100 = Whitebox.invokeMethod(_processInstance, "PEP0018_BL100_RecupererPfiExistant", tracabilite, commande); //$NON-NLS-1$
    PowerMock.verifyAll();

    Assert.assertEquals(retourExpected, bl100._first);
    Assert.assertEquals(pfiExpected, bl100._second);
  }

  /**
   * Tests the PEP0018_BL100_RecupererPfiExistant method when an error (= CAT-4) occurs in RPG002<br>
   *
   * <b>Inputs: </b>Valid inputs and generated KO CAT-4 on RPG002 mock<br>
   * <b>Expected: </b> Retour{OK}<br>
   *
   * @throws Exception
   *           On unexpected error
   */

  @Test
  public void PEP0018_BL100_RecupererPfiExistant_OK_002() throws Exception
  {
    Commande commande = __podam.manufacturePojo(Commande.class);
    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, StringConstants.EMPTY_STRING, null);
    PFI pfiExpected = new PFI();
    ConnectorResponse<Retour, PFI> connectorRpg = new ConnectorResponse<Retour, PFI>(retourExpected, pfiExpected);
    //prepare Mock PFI proxy
    prepareMockRpgPfiLireUn(connectorRpg, commande.getClientOperateur(), commande.getNoCompte());

    PowerMock.replayAll();
    Pair<Retour, PFI> bl100 = Whitebox.invokeMethod(_processInstance, "PEP0018_BL100_RecupererPfiExistant", tracabilite, commande); //$NON-NLS-1$
    PowerMock.verifyAll();

    Assert.assertEquals(RetourFactoryForTU.createOkRetour(), bl100._first);
    Assert.assertNotNull(bl100._second);
  }

  /**
   * Test KO for the PEP0018_BL200_ConstruirePfiphotoFiltre method
   *
   * <b>Inputs:</b> Random command without donnesbruts<br>
   * <b>Expected:</b> RavelExcpetion<br>
   *
   * @throws Exception
   *           on unexpected error
   */
  @Test
  public void PEP0018_BL200_ConstruirePfiphotoFiltre_KO_001()
  {
    RavelException expectedException = new RavelException(ExceptionType.UNEXPECTED, ErrorCode.PRCESS_00001, Messages.getString("PEP0018_CommandePFI.ControlerDonneesEntreeDonneeIncoherente"));//$NON-NLS-1$
    Commande commande = _pfiGenerator.getCommande();
    commande.setDonneesBrut(null);
    try
    {
      Whitebox.invokeMethod(_processInstance, "PEP0018_BL200_ConstruirePfiphotoFiltre", tracabilite, commande); //$NON-NLS-1$
      fail();
    }
    catch (Exception e_p)
    {
      assertEquals(expectedException.getMessage(), e_p.getMessage());
    }
  }

  /**
   * Test OK for the PEP0018_BL200_ConstruirePfiphotoFiltre method
   *
   * <b>Inputs: </b>Random commande with one catalogServiceCommercial in cache<br>
   * <b>Expected: </b> Retour{KO}
   *
   * @throws Exception
   *           On unexpected error
   */

  @Test
  public void PEP0018_BL200_ConstruirePfiphotoFiltre_OK_001() throws Exception
  {
    Commande commande = _pfiGenerator.getCommande();
    commande.setClientOperateur(ClientOperateur.BSS_GP.name());
    Retour retourExpected = RetourFactoryForTU.createOkRetour();
    CatalogServiceCommercial catalogServiceCommercial1 = __podam.manufacturePojo(CatalogServiceCommercial.class);
    catalogServiceCommercial1.setClientOperateur(commande.getClientOperateur());
    catalogServiceCommercial1.setNoServiceCommercial(_pfiGenerator.getNoServiceCommercialConnu());
    CatalogServiceCommercial catalogServiceCommercial2 = __podam.manufacturePojo(CatalogServiceCommercial.class);
    //prepare Mock BL200
    prepareMockBL200(catalogServiceCommercial1, RetourFactoryForTU.createOkRetour());
    prepareMockBL200(catalogServiceCommercial2, RetourFactoryForTU.createOkRetour());

    PowerMock.replayAll();
    Pair<Retour, PFI> bl200 = Whitebox.invokeMethod(_processInstance, "PEP0018_BL200_ConstruirePfiphotoFiltre", tracabilite, commande); //$NON-NLS-1$
    PowerMock.verifyAll();

    assertEquals(retourExpected, bl200._first);
    //PFI
    PFI pfiResult = bl200._second;
    assertEquals(Statut.ACTIF, pfiResult.getStatut());
    assertEquals(commande.getClientOperateur(), pfiResult.getClientOperateur());
    assertEquals(commande.getNoCompte(), pfiResult.getNoCompte());
    assertEquals("GP", pfiResult.getLigneMarche()); //$NON-NLS-1$
    //Titulaire
    CommandePfi commandePfi = GsonTools.getIso8601Ms().fromJson(commande.getDonneesBrut(), CommandePfi.class);
    ClientTitulaire clientTitulaire = commandePfi.getPortefeuilleServices().getClientTitulaire();
    assertEquals(clientTitulaire.getNoPersonne(), pfiResult.getTitulaire().getNoPersonne());
    assertEquals(clientTitulaire.getNoTel(), pfiResult.getTitulaire().getNoTel());
    assertEquals(clientTitulaire.getEmail(), pfiResult.getTitulaire().getEmail());
    assertEquals("INDIVIDU", pfiResult.getTitulaire().getTypeTitulaire().name()); //$NON-NLS-1$
    assertEquals(clientTitulaire.getIndividu().getCivilite(), pfiResult.getTitulaire().getIndividu().getCivilite());
    assertEquals(clientTitulaire.getIndividu().getNom(), pfiResult.getTitulaire().getIndividu().getNom());
    assertEquals(clientTitulaire.getIndividu().getPrenom(), pfiResult.getTitulaire().getIndividu().getPrenom());

    assertEquals(catalogServiceCommercial1.getNom(), pfiResult.getSa().get(0).getNomServiceCommercial());
    assertEquals(catalogServiceCommercial1.getCategorie(), pfiResult.getSa().get(0).getCategorieServiceCommercial());
    assertEquals(catalogServiceCommercial2.getNom(), pfiResult.getSa().get(1).getNomServiceCommercial());
    assertEquals(catalogServiceCommercial2.getCategorie(), pfiResult.getSa().get(1).getCategorieServiceCommercial());

  }

  /**
   * Test OK for the PEP0018_BL200_ConstruirePfiphotoFiltre method
   *
   * <b>Inputs:</b> Random command <br>
   * <b>Expected:</b> Retour{K0}<br>
   *
   * @throws Exception
   *           on unexpected error
   */

  @Test
  public void PEP0018_BL200_ConstruirePfiphotoFiltre_OK_002() throws Exception
  {
    Commande commande = _pfiGenerator.getCommande();
    commande.setClientOperateur(ClientOperateur.BSS_GP.name());
    CatalogServiceCommercial catalogueCommercial = __podam.manufacturePojo(CatalogServiceCommercial.class);

    Retour retourOK = RetourFactoryForTU.createOkRetour();
    //prepare Mock BL200
    prepareMockBL200(catalogueCommercial, retourOK);
    prepareMockBL200(catalogueCommercial, retourOK);

    PowerMock.replayAll();
    Pair<Retour, PFI> bl200 = Whitebox.invokeMethod(_processInstance, "PEP0018_BL200_ConstruirePfiphotoFiltre", tracabilite, commande); //$NON-NLS-1$
    PowerMock.verifyAll();

    assertEquals(retourOK, bl200._first);

    //Check PFI
    PFI pfiResult = bl200._second;
    assertEquals(Statut.ACTIF, pfiResult.getStatut());
    assertEquals(commande.getClientOperateur(), pfiResult.getClientOperateur());
    assertEquals(commande.getNoCompte(), pfiResult.getNoCompte());
    assertEquals("GP", pfiResult.getLigneMarche()); //$NON-NLS-1$

    //Check the PFI's clientTitulaire
    CommandePfi commandePfi = GsonTools.getIso8601Ms().fromJson(commande.getDonneesBrut(), CommandePfi.class);
    ClientTitulaire clientTitulaire = commandePfi.getPortefeuilleServices().getClientTitulaire();
    assertEquals(clientTitulaire.getNoPersonne(), pfiResult.getTitulaire().getNoPersonne());
    assertEquals(clientTitulaire.getNoTel(), pfiResult.getTitulaire().getNoTel());
    assertEquals(clientTitulaire.getEmail(), pfiResult.getTitulaire().getEmail());
    assertEquals("INDIVIDU", pfiResult.getTitulaire().getTypeTitulaire().name()); //$NON-NLS-1$
    assertEquals(clientTitulaire.getIndividu().getCivilite(), pfiResult.getTitulaire().getIndividu().getCivilite());
    assertEquals(clientTitulaire.getIndividu().getNom(), pfiResult.getTitulaire().getIndividu().getNom());
    assertEquals(clientTitulaire.getIndividu().getPrenom(), pfiResult.getTitulaire().getIndividu().getPrenom());

    //Check the PFI's SA and LienSAPA
    assertEquals(2, pfiResult.getSa().size());
    assertEquals(4, pfiResult.getLienSAPA().size());

  }

  /**
   * Test the PEP0018_BL250_VerifierValiditePhoto <b>Inputs: </b>Valid inputs and generated KO CAT-4 on RPG002 mock<br>
   * <b>Expected: </b> Retour{KO}<br>
   *
   * @throws Exception
   *           On unexpected error
   */
  @Test
  public void PEP0018_BL250_VerifierValiditePhoto() throws Exception
  {
    Commande commande = _pfiGenerator.getCommande();
    PFI pfiPhotoFiltre_p = new PFI();
    pfiPhotoFiltre_p.setClientOperateur(commande.getClientOperateur());
    pfiPhotoFiltre_p.setNoCompte(commande.getNoCompte());
    LocalDateTime now = LocalDateTime.now();
    PFI existingPFI_p = new PFI();
    existingPFI_p.setClientOperateur(commande.getClientOperateur());
    existingPFI_p.setNoCompte(commande.getNoCompte());

    Retour retourOK = RetourFactoryForTU.createOkRetour();
    pfiPhotoFiltre_p.setDatePhoto(now.plusDays(1));
    existingPFI_p.setDatePhoto(now);
    Retour retour = Whitebox.invokeMethod(new PEP0018_CommandePfi(), "PEP0018_BL250_VerifierValiditePhoto", tracabilite, pfiPhotoFiltre_p, existingPFI_p); //$NON-NLS-1$
    assertEquals(retourOK, retour);

    Retour retourKO = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.PHOTO_PERIMEE, MessageFormat.format(Messages.getString("PEP0018_CommandePFI.PhotoPerimee"), DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZ.format(existingPFI_p.getDatePhoto())), null); //$NON-NLS-1$;
    pfiPhotoFiltre_p.setDatePhoto(now);
    existingPFI_p.setDatePhoto(now);
    retour = Whitebox.invokeMethod(new PEP0018_CommandePfi(), "PEP0018_BL250_VerifierValiditePhoto", tracabilite, pfiPhotoFiltre_p, existingPFI_p); //$NON-NLS-1$
    assertEquals(retourOK, retour);

    pfiPhotoFiltre_p.setDatePhoto(now.plusDays(1));
    existingPFI_p.setDatePhoto(null);
    existingPFI_p.setDateModification(now);
    retour = Whitebox.invokeMethod(new PEP0018_CommandePfi(), "PEP0018_BL250_VerifierValiditePhoto", tracabilite, pfiPhotoFiltre_p, existingPFI_p); //$NON-NLS-1$
    assertEquals(retourOK, retour);

    pfiPhotoFiltre_p.setDatePhoto(now);
    existingPFI_p.setDatePhoto(null);
    existingPFI_p.setDateModification(now);
    retour = Whitebox.invokeMethod(new PEP0018_CommandePfi(), "PEP0018_BL250_VerifierValiditePhoto", tracabilite, pfiPhotoFiltre_p, existingPFI_p); //$NON-NLS-1$
    assertEquals(retourKO, retour);

  }

  /**
   * Tests the PEP0018_BL320_ControlesFonctionnels //CF003 BL200 KO<br>
   *
   * <b>Inputs: </b>Valid inputs and generated KO CAT-4 on BL200 mock<br>
   * <b>Expected: </b> Retour{OK}<br>
   *
   * @throws Exception
   *           On unexpected error
   */
  @Test
  public void PEP0018_BL320_ControlesFonctionnels_KO_001() throws Throwable
  {
    CommandePfi commandePfi = new CommandePfi(); //CommandePFI to put in donnees Brut of command
    PortefeuilleServices portfeulleservice = __podam.manufacturePojo(PortefeuilleServices.class);
    commandePfi.setPortefeuilleServices(portfeulleservice);
    commandePfi.getPortefeuilleServices().setStatut(Statut.ACTIF.name());
    commandePfi.getPortefeuilleServices().setServicesAccessibles(_pfiGenerator.buildServicesAccessibles());
    commandePfi.setTimestamp(LocalDateTime.now().plusDays(1));
    AbstractPointAcces pAccesVoipPortage = _pfiGenerator.buildPointAccesVoipPortage();
    AbstractPointAcces pAccesVoipPortTel = _pfiGenerator.buildPointAccesVoipPortTelephonique();
    AbstractPointAcces pAccesFax = _pfiGenerator.buildPointAccesFax();
    AbstractPointAcces pAccesCa = _pfiGenerator.buildPointAccesCompteAcces();
    List<AbstractPointAcces> pointsAcces = new ArrayList<>();
    pointsAcces.add(pAccesVoipPortage);
    pointsAcces.add(pAccesVoipPortTel);
    pointsAcces.add(pAccesFax);
    pointsAcces.add(pAccesCa);
    commandePfi.getPortefeuilleServices().setPointsAcces(pointsAcces);
    Commande command = __podam.manufacturePojo(Commande.class);
    command.setIdCmd("111"); //$NON-NLS-1$
    command.setStatut("ACQUITTE"); //$NON-NLS-1$
    command.setDonneesBrut(GsonTools.getIso8601Ms().toJson(commandePfi));
    CommandeId cmdId = new CommandeId(command.getIdCmd());
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    request.setPayload(GsonTools.getIso8601Ms().toJson(cmdId));
    PFI pfiExpected = new PFI();
    pfiExpected.setClientOperateur(command.getClientOperateur());
    pfiExpected.setNoCompte(command.getNoCompte());
    pfiExpected.setDatePhoto(LocalDateTime.now());
    // prepare all mock Connector
    ConnectorResponse<Retour, Commande> connectorRep = new ConnectorResponse<Retour, Commande>(RetourFactoryForTU.createOkRetour(), command);
    //prepare Mock CMD proxy
    prepareMockCmdCommandeLireUn(connectorRep, command.getIdCmd());
    ConnectorResponse<Retour, PFI> connectorRpg = new ConnectorResponse<Retour, PFI>(RetourFactoryForTU.createOkRetour(), pfiExpected);
    //prepare Mock RPG proxy
    prepareMockRpgPfiLireUn(connectorRpg, command.getClientOperateur(), command.getNoCompte());
    //prepare mock BL200
    CatalogServiceCommercial catalogue = __podam.manufacturePojo(CatalogServiceCommercial.class);

    for (int i = 0; i < commandePfi.getPortefeuilleServices().getServicesAccessibles().size(); i++)
    {
      prepareMockBL200(catalogue, RetourFactoryForTU.createOkRetour());
    }
    Retour retourKO = RetourFactoryForTU.createKO(IMegConsts.CAT4, IMegSpiritConsts.DONNEE_INDISPONIBLE, "erreur", null); //$NON-NLS-1$
    //For BL320 CF003
    //prepare Mock BL200
    prepareMockBL200(catalogue, retourKO);

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();
    Response response = (Response) request.getResponse();
    String resp = response.getGenericResponse().getResult();
    PEP0018_Retour PepReponse = GsonTools.getIso8601Sec().fromJson(resp, PEP0018_Retour.class);

    Assert.assertEquals(ErrorCode.KO_00400, request.getResponse().getErrorCode());
    Assert.assertEquals(PepReponse.getRetour().getCategorie(), IMegConsts.CAT4);
    Assert.assertEquals(PepReponse.getRetour().getDiagnostic(), IMegSpiritConsts.DONNEE_INDISPONIBLE);
    Assert.assertEquals(PepReponse.getRetour().getLibelle(), "[CF0003] erreur"); //$NON-NLS-1$
  }

  /**
   * Tests the PEP0018_BL400_CreerListeModCom_KO error when calling CMDproxy <br>
   *
   * <b>Inputs: </b>Valid inputs and generated KO CAT-4 on CMDproxy<br>
   * <b>Expected: </b> Retour{KO}<br>
   *
   * @throws Exception
   *           On unexpected error
   */
  @Test
  public void PEP0018_BL400_CreerListeModCom_KO_001() throws Throwable
  {
    CommandePfi commandePfi = new CommandePfi(); //CommandePFI to put in donnees Brut of command
    PortefeuilleServices portfeulleservice = __podam.manufacturePojo(PortefeuilleServices.class);
    commandePfi.setPortefeuilleServices(portfeulleservice);
    commandePfi.getPortefeuilleServices().setStatut(Statut.ACTIF.name());
    commandePfi.getPortefeuilleServices().setServicesAccessibles(_pfiGenerator.buildServicesAccessibles());
    commandePfi.setTimestamp(LocalDateTime.now().plusDays(1));
    AbstractPointAcces pAccesVoipPortage = _pfiGenerator.buildPointAccesVoipPortage();
    AbstractPointAcces pAccesVoipPortTel = _pfiGenerator.buildPointAccesVoipPortTelephonique();
    AbstractPointAcces pAccesFax = _pfiGenerator.buildPointAccesFax();
    AbstractPointAcces pAccesCa = _pfiGenerator.buildPointAccesCompteAcces();
    List<AbstractPointAcces> pointsAcces = new ArrayList<>();
    pointsAcces.add(pAccesVoipPortage);
    pointsAcces.add(pAccesVoipPortTel);
    pointsAcces.add(pAccesFax);
    pointsAcces.add(pAccesCa);
    commandePfi.getPortefeuilleServices().setPointsAcces(pointsAcces);
    Commande command = __podam.manufacturePojo(Commande.class);
    command.setIdCmd("111"); //$NON-NLS-1$
    command.setStatut("ACQUITTE"); //$NON-NLS-1$
    command.setDonneesBrut(GsonTools.getIso8601Ms().toJson(commandePfi));
    CommandeId cmdId = new CommandeId(command.getIdCmd());
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    request.setPayload(GsonTools.getIso8601Ms().toJson(cmdId));
    PFI pfiExpected = new PFI();
    pfiExpected.setClientOperateur(command.getClientOperateur());
    pfiExpected.setNoCompte(command.getNoCompte());
    pfiExpected.setDatePhoto(LocalDateTime.now());
    // prepare all mock Connector
    ConnectorResponse<Retour, Commande> connectorRep = new ConnectorResponse<Retour, Commande>(RetourFactoryForTU.createOkRetour(), command);
    //prepare Mock CMD proxy
    prepareMockCmdCommandeLireUn(connectorRep, command.getIdCmd());
    ConnectorResponse<Retour, PFI> connectorRpg = new ConnectorResponse<Retour, PFI>(RetourFactoryForTU.createOkRetour(), pfiExpected);
    //prepare Mock RPG proxy
    prepareMockRpgPfiLireUn(connectorRpg, command.getClientOperateur(), command.getNoCompte());
    //prepare mock BL200
    CatalogServiceCommercial catalogue = __podam.manufacturePojo(CatalogServiceCommercial.class);

    for (int i = 0; i < commandePfi.getPortefeuilleServices().getServicesAccessibles().size(); i++)
    {
      prepareMockBL200(catalogue, RetourFactoryForTU.createOkRetour());
    }
    //call mock For BL320 CF003
    //prepare Mock BL200
    prepareMockBL200(catalogue, RetourFactoryForTU.createOkRetour());
    prepareMockBL200(catalogue, RetourFactoryForTU.createOkRetour());

    Retour retourKO = RetourFactoryForTU.createKO(IMegConsts.CAT4, IMegSpiritConsts.DONNEE_INDISPONIBLE, "erreur", null); //$NON-NLS-1$
    ConnectorResponse<Retour, Nothing> connectRep = new ConnectorResponse<Retour, Nothing>(retourKO, null);
    //prepare Mock CMD proxy
    prepareMockmodificationCommercialeCreerListe(connectRep);
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();
    Response response = (Response) request.getResponse();
    String resp = response.getGenericResponse().getResult();
    PEP0018_Retour PepReponse = GsonTools.getIso8601Sec().fromJson(resp, PEP0018_Retour.class);

    Assert.assertEquals(ErrorCode.KO_00400, request.getResponse().getErrorCode());
    Assert.assertEquals(PepReponse.getRetour().getCategorie(), IMegConsts.CAT4);
    Assert.assertEquals(PepReponse.getRetour().getDiagnostic(), IMegSpiritConsts.DONNEE_INDISPONIBLE);
    Assert.assertEquals(PepReponse.getRetour().getLibelle(), "erreur"); //$NON-NLS-1$
  }

  /**
   * Tests the PEP0018_BL410_CreerOuModifierPfi error when calling RPGProxy <br>
   *
   * <b>Inputs: </b>Valid inputs and generated KO CAT-4 on RPGProxy<br>
   * <b>Expected: </b> Retour{KO}<br>
   *
   * @throws Exception
   *           On unexpected error
   */
  @Test
  public void PEP0018_BL410_CreerOuModifierPfi_KO_001() throws Throwable
  {
    CommandePfi commandePfi = new CommandePfi(); //CommandePFI to put in donnees Brut of command
    PortefeuilleServices portfeulleservice = __podam.manufacturePojo(PortefeuilleServices.class);
    commandePfi.setPortefeuilleServices(portfeulleservice);
    commandePfi.getPortefeuilleServices().setStatut(Statut.ACTIF.name());
    commandePfi.getPortefeuilleServices().setServicesAccessibles(_pfiGenerator.buildServicesAccessibles());
    commandePfi.setTimestamp(LocalDateTime.now().plusDays(1));
    AbstractPointAcces pAccesVoipPortage = _pfiGenerator.buildPointAccesVoipPortage();
    AbstractPointAcces pAccesVoipPortTel = _pfiGenerator.buildPointAccesVoipPortTelephonique();
    AbstractPointAcces pAccesFax = _pfiGenerator.buildPointAccesFax();
    AbstractPointAcces pAccesCa = _pfiGenerator.buildPointAccesCompteAcces();
    List<AbstractPointAcces> pointsAcces = new ArrayList<>();
    pointsAcces.add(pAccesVoipPortage);
    pointsAcces.add(pAccesVoipPortTel);
    pointsAcces.add(pAccesFax);
    pointsAcces.add(pAccesCa);
    commandePfi.getPortefeuilleServices().setPointsAcces(pointsAcces);
    Commande command = __podam.manufacturePojo(Commande.class);
    command.setIdCmd("111"); //$NON-NLS-1$
    command.setStatut("ACQUITTE"); //$NON-NLS-1$
    command.setDonneesBrut(GsonTools.getIso8601Ms().toJson(commandePfi));
    CommandeId cmdId = new CommandeId(command.getIdCmd());
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    request.setPayload(GsonTools.getIso8601Ms().toJson(cmdId));
    PFI pfiExpected = new PFI();
    pfiExpected.setClientOperateur(command.getClientOperateur());
    pfiExpected.setNoCompte(command.getNoCompte());
    pfiExpected.setDatePhoto(LocalDateTime.now());
    // prepare all mock Connector
    ConnectorResponse<Retour, Commande> connectorRep = new ConnectorResponse<Retour, Commande>(RetourFactoryForTU.createOkRetour(), command);
    //prepare Mock CMD proxy
    prepareMockCmdCommandeLireUn(connectorRep, command.getIdCmd());
    ConnectorResponse<Retour, PFI> connectorRpg = new ConnectorResponse<Retour, PFI>(RetourFactoryForTU.createOkRetour(), pfiExpected);
    //prepare Mock RPG proxy
    prepareMockRpgPfiLireUn(connectorRpg, command.getClientOperateur(), command.getNoCompte());

    CatalogServiceCommercial catalogue = __podam.manufacturePojo(CatalogServiceCommercial.class);

    for (int i = 0; i < commandePfi.getPortefeuilleServices().getServicesAccessibles().size(); i++)
    {
      prepareMockBL200(catalogue, RetourFactoryForTU.createOkRetour());
    }
    //call mock For BL320 CF003
    //prepare mock BL200
    prepareMockBL200(catalogue, RetourFactoryForTU.createOkRetour());
    prepareMockBL200(catalogue, RetourFactoryForTU.createOkRetour());
    ConnectorResponse<Retour, Nothing> connectRep = new ConnectorResponse<Retour, Nothing>(RetourFactoryForTU.createOkRetour(), null);
    //prepare mock CMD proxy
    prepareMockmodificationCommercialeCreerListe(connectRep);
    connectRep = new ConnectorResponse<Retour, Nothing>(RetourFactoryForTU.createKO(IMegConsts.CAT4, IMegSpiritConsts.DONNEE_INDISPONIBLE, "erreur", null), null); //$NON-NLS-1$
    //prepare mock RPG proxy
    preparaMockPfiEcrire(connectRep);
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();
    Response response = (Response) request.getResponse();
    String resp = response.getGenericResponse().getResult();
    PEP0018_Retour PepReponse = GsonTools.getIso8601Sec().fromJson(resp, PEP0018_Retour.class);

    Assert.assertEquals(ErrorCode.KO_00400, request.getResponse().getErrorCode());
    Assert.assertEquals(PepReponse.getRetour().getCategorie(), IMegConsts.CAT4);
    Assert.assertEquals(PepReponse.getRetour().getDiagnostic(), IMegSpiritConsts.DONNEE_INDISPONIBLE);
    Assert.assertEquals(PepReponse.getRetour().getLibelle(), "erreur"); //$NON-NLS-1$
  }

  /**
   * Tests the PEP0018_BL420_CreerComparaisonCommerciale error when calling RExproxy <br>
   *
   * <b>Inputs: </b>Valid inputs and generated KO CAT-4 on RExproxy<br>
   * <b>Expected: </b> Retour{K0}<br>
   *
   * @throws Exception
   *           On unexpected error
   */
  @Test
  public void PEP0018_BL420_CreerComparaisonCommerciale_KO_001() throws Throwable
  {
    CommandePfi commandePfi = new CommandePfi(); //CommandePFI to put in donnees Brut of command
    PortefeuilleServices portfeulleservice = __podam.manufacturePojo(PortefeuilleServices.class);
    commandePfi.setPortefeuilleServices(portfeulleservice);
    commandePfi.getPortefeuilleServices().setStatut(Statut.ACTIF.name());
    commandePfi.getPortefeuilleServices().setServicesAccessibles(_pfiGenerator.buildServicesAccessibles());
    commandePfi.setTimestamp(LocalDateTime.now().plusDays(1));
    AbstractPointAcces pAccesVoipPortage = _pfiGenerator.buildPointAccesVoipPortage();
    AbstractPointAcces pAccesVoipPortTel = _pfiGenerator.buildPointAccesVoipPortTelephonique();
    AbstractPointAcces pAccesFax = _pfiGenerator.buildPointAccesFax();
    AbstractPointAcces pAccesCa = _pfiGenerator.buildPointAccesCompteAcces();
    List<AbstractPointAcces> pointsAcces = new ArrayList<>();
    pointsAcces.add(pAccesVoipPortage);
    pointsAcces.add(pAccesVoipPortTel);
    pointsAcces.add(pAccesFax);
    pointsAcces.add(pAccesCa);
    commandePfi.getPortefeuilleServices().setPointsAcces(pointsAcces);
    Commande command = __podam.manufacturePojo(Commande.class);
    command.setIdCmd("111"); //$NON-NLS-1$
    command.setStatut("ACQUITTE"); //$NON-NLS-1$
    command.setDonneesBrut(GsonTools.getIso8601Ms().toJson(commandePfi));
    CommandeId cmdId = new CommandeId(command.getIdCmd());
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    request.setPayload(GsonTools.getIso8601Ms().toJson(cmdId));
    PFI pfiExpected = new PFI();
    pfiExpected.setClientOperateur(command.getClientOperateur());
    pfiExpected.setNoCompte(command.getNoCompte());
    pfiExpected.setDatePhoto(LocalDateTime.now());
    // prepare all mock Connector
    ConnectorResponse<Retour, Commande> connectorRep = new ConnectorResponse<Retour, Commande>(RetourFactoryForTU.createOkRetour(), command);
    //prepare mock CMD proxy
    prepareMockCmdCommandeLireUn(connectorRep, command.getIdCmd());
    ConnectorResponse<Retour, PFI> connectorRpg = new ConnectorResponse<Retour, PFI>(RetourFactoryForTU.createOkRetour(), pfiExpected);
    //prepare mock RPG proxy
    prepareMockRpgPfiLireUn(connectorRpg, command.getClientOperateur(), command.getNoCompte());
    //prepare mock BL200
    CatalogServiceCommercial catalogue = __podam.manufacturePojo(CatalogServiceCommercial.class);

    for (int i = 0; i < commandePfi.getPortefeuilleServices().getServicesAccessibles().size(); i++)
    {
      prepareMockBL200(catalogue, RetourFactoryForTU.createOkRetour());
    }
    //call mock For BL320 CF003
    prepareMockBL200(catalogue, RetourFactoryForTU.createOkRetour());
    prepareMockBL200(catalogue, RetourFactoryForTU.createOkRetour());
    ConnectorResponse<Retour, Nothing> connectRep = new ConnectorResponse<Retour, Nothing>(RetourFactoryForTU.createOkRetour(), null);
    //prepare mock CMD proxy
    prepareMockmodificationCommercialeCreerListe(connectRep);
    connectRep = new ConnectorResponse<Retour, Nothing>(RetourFactoryForTU.createOkRetour(), null);
    //prepare mock RPG proxy
    preparaMockPfiEcrire(connectRep);
    connectRep = new ConnectorResponse<Retour, Nothing>(RetourFactoryForTU.createKO(IMegConsts.CAT4, IMegSpiritConsts.DONNEE_INDISPONIBLE, "erreur", null), null); //$NON-NLS-1$
    //prepare mock REX proxy
    prepareMockRexcomparaisonCommercialeCompositeCreer(connectRep);
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();
    Response response = (Response) request.getResponse();
    String resp = response.getGenericResponse().getResult();
    PEP0018_Retour PepReponse = GsonTools.getIso8601Sec().fromJson(resp, PEP0018_Retour.class);

    Assert.assertEquals(ErrorCode.KO_00400, request.getResponse().getErrorCode());
    Assert.assertEquals(PepReponse.getRetour().getCategorie(), IMegConsts.CAT4);
    Assert.assertEquals(PepReponse.getRetour().getDiagnostic(), IMegSpiritConsts.DONNEE_INDISPONIBLE);
    Assert.assertEquals(PepReponse.getRetour().getLibelle(), "erreur"); //$NON-NLS-1$
  }

  /**
   * Tests the PEP0018_BL430_ModifierStatutCmdEnCours error when calling CmdcommandeModifierStatut <br>
   *
   * <b>Inputs: </b>Valid inputs and generated KO CAT-4 on CmdcommandeModifierStatut<br>
   * <b>Expected: </b>Retour{KO}}<br>
   *
   * @throws Exception
   *           On unexpected error
   */
  @Test
  public void PEP0018_BL430_ModifierStatutCmdEnCours_KO_001() throws Throwable
  {
    CommandePfi commandePfi = new CommandePfi(); //CommandePFI to put in donnees Brut of command
    PortefeuilleServices portfeulleservice = __podam.manufacturePojo(PortefeuilleServices.class);
    commandePfi.setPortefeuilleServices(portfeulleservice);
    commandePfi.getPortefeuilleServices().setStatut(Statut.ACTIF.name());
    commandePfi.getPortefeuilleServices().setServicesAccessibles(_pfiGenerator.buildServicesAccessibles());
    commandePfi.setTimestamp(LocalDateTime.now().plusDays(1));
    AbstractPointAcces pAccesVoipPortage = _pfiGenerator.buildPointAccesVoipPortage();
    AbstractPointAcces pAccesVoipPortTel = _pfiGenerator.buildPointAccesVoipPortTelephonique();
    AbstractPointAcces pAccesFax = _pfiGenerator.buildPointAccesFax();
    AbstractPointAcces pAccesCa = _pfiGenerator.buildPointAccesCompteAcces();
    List<AbstractPointAcces> pointsAcces = new ArrayList<>();
    pointsAcces.add(pAccesVoipPortage);
    pointsAcces.add(pAccesVoipPortTel);
    pointsAcces.add(pAccesFax);
    pointsAcces.add(pAccesCa);
    commandePfi.getPortefeuilleServices().setPointsAcces(pointsAcces);
    Commande command = __podam.manufacturePojo(Commande.class);
    command.setIdCmd("111"); //$NON-NLS-1$
    command.setStatut("ACQUITTE"); //$NON-NLS-1$
    command.setDonneesBrut(GsonTools.getIso8601Ms().toJson(commandePfi));
    CommandeId cmdId = new CommandeId(command.getIdCmd());
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    request.setPayload(GsonTools.getIso8601Ms().toJson(cmdId));
    PFI pfiExpected = new PFI();
    pfiExpected.setClientOperateur(command.getClientOperateur());
    pfiExpected.setNoCompte(command.getNoCompte());
    pfiExpected.setDatePhoto(LocalDateTime.now());
    // prepare all mock Connector
    ConnectorResponse<Retour, Commande> connectorRep = new ConnectorResponse<Retour, Commande>(RetourFactoryForTU.createOkRetour(), command);
    //prepare mock CMD proxy
    prepareMockCmdCommandeLireUn(connectorRep, command.getIdCmd());
    ConnectorResponse<Retour, PFI> connectorRpg = new ConnectorResponse<Retour, PFI>(RetourFactoryForTU.createOkRetour(), pfiExpected);
    //prepare mock RPG proxy
    prepareMockRpgPfiLireUn(connectorRpg, command.getClientOperateur(), command.getNoCompte());
    //prepare mock BL200
    CatalogServiceCommercial catalogue = __podam.manufacturePojo(CatalogServiceCommercial.class);
    for (int i = 0; i < commandePfi.getPortefeuilleServices().getServicesAccessibles().size(); i++)
    {
      prepareMockBL200(catalogue, RetourFactoryForTU.createOkRetour());
    }
    //call mock For BL320 CF003
    prepareMockBL200(catalogue, RetourFactoryForTU.createOkRetour());
    prepareMockBL200(catalogue, RetourFactoryForTU.createOkRetour());
    ConnectorResponse<Retour, Nothing> connectRep = new ConnectorResponse<Retour, Nothing>(RetourFactoryForTU.createOkRetour(), null);
    //prepare mock CMD proxy
    prepareMockmodificationCommercialeCreerListe(connectRep);
    connectRep = new ConnectorResponse<Retour, Nothing>(RetourFactoryForTU.createOkRetour(), null);
    //prepare mock RPG proxy
    preparaMockPfiEcrire(connectRep);
    connectRep = new ConnectorResponse<Retour, Nothing>(RetourFactoryForTU.createOkRetour(), null);
    //prepare mock REX proxy
    prepareMockRexcomparaisonCommercialeCompositeCreer(connectRep);
    connectRep = new ConnectorResponse<Retour, Nothing>(RetourFactoryForTU.createKO(IMegConsts.CAT4, IMegSpiritConsts.DONNEE_INDISPONIBLE, "erreur", null), null); //$NON-NLS-1$
    //prepare mock CMD proxy
    prepareMockCmdcommandeModifierStatut(connectRep);
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();
    Response response = (Response) request.getResponse();
    String resp = response.getGenericResponse().getResult();
    PEP0018_Retour PepReponse = GsonTools.getIso8601Sec().fromJson(resp, PEP0018_Retour.class);

    Assert.assertEquals(ErrorCode.KO_00400, request.getResponse().getErrorCode());
    Assert.assertEquals(PepReponse.getRetour().getCategorie(), IMegConsts.CAT4);
    Assert.assertEquals(PepReponse.getRetour().getDiagnostic(), IMegSpiritConsts.DONNEE_INDISPONIBLE);
    Assert.assertEquals(PepReponse.getRetour().getLibelle(), "erreur"); //$NON-NLS-1$
  }

  /**
   * Tests the PEP0018_BL5200_GererRaccordementCommercialBuilder error when calling BL5200 <br>
   *
   * <b>Inputs: </b>Valid inputs and generated KO CAT-4 on REXproxy<br>
   * <b>Expected: </b> Retour{KO}<br>
   *
   * @throws Exception
   *           On unexpected error
   */
  @Test
  public void PEP0018_BL5200_GererRaccordementCommercialBuilder_KO_001() throws Throwable
  {
    CommandePfi commandePfi = new CommandePfi(); //CommandePFI to put in donnees Brut of command
    PortefeuilleServices portfeulleservice = __podam.manufacturePojo(PortefeuilleServices.class);
    commandePfi.setPortefeuilleServices(portfeulleservice);
    commandePfi.getPortefeuilleServices().setStatut(Statut.ACTIF.name());
    commandePfi.getPortefeuilleServices().setServicesAccessibles(_pfiGenerator.buildServicesAccessibles());
    commandePfi.setTimestamp(LocalDateTime.now().plusDays(1));
    AbstractPointAcces pAccesVoipPortage = _pfiGenerator.buildPointAccesVoipPortage();
    AbstractPointAcces pAccesVoipPortTel = _pfiGenerator.buildPointAccesVoipPortTelephonique();
    AbstractPointAcces pAccesFax = _pfiGenerator.buildPointAccesFax();
    AbstractPointAcces pAccesCa = _pfiGenerator.buildPointAccesCompteAcces();
    List<AbstractPointAcces> pointsAcces = new ArrayList<>();
    pointsAcces.add(pAccesVoipPortage);
    pointsAcces.add(pAccesVoipPortTel);
    pointsAcces.add(pAccesFax);
    pointsAcces.add(pAccesCa);
    commandePfi.getPortefeuilleServices().setPointsAcces(pointsAcces);
    Commande command = __podam.manufacturePojo(Commande.class);
    command.setIdCmd("111"); //$NON-NLS-1$
    command.setStatut("ACQUITTE"); //$NON-NLS-1$
    command.setDonneesBrut(GsonTools.getIso8601Ms().toJson(commandePfi));
    CommandeId cmdId = new CommandeId(command.getIdCmd());
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    request.setPayload(GsonTools.getIso8601Ms().toJson(cmdId));
    PFI pfiExpected = new PFI();
    pfiExpected.setClientOperateur(command.getClientOperateur());
    pfiExpected.setNoCompte(command.getNoCompte());
    pfiExpected.setDatePhoto(LocalDateTime.now());
    // prepare all mock Connector
    ConnectorResponse<Retour, Commande> connectorRep = new ConnectorResponse<Retour, Commande>(RetourFactoryForTU.createOkRetour(), command);
    //prepare mock CMD proxy
    prepareMockCmdCommandeLireUn(connectorRep, command.getIdCmd());
    ConnectorResponse<Retour, PFI> connectorRpg = new ConnectorResponse<Retour, PFI>(RetourFactoryForTU.createOkRetour(), pfiExpected);
    //prepare mock RPG proxy
    prepareMockRpgPfiLireUn(connectorRpg, command.getClientOperateur(), command.getNoCompte());
    //prepare mock BL200
    CatalogServiceCommercial catalogue = __podam.manufacturePojo(CatalogServiceCommercial.class);

    for (int i = 0; i < commandePfi.getPortefeuilleServices().getServicesAccessibles().size(); i++)
    {
      prepareMockBL200(catalogue, RetourFactoryForTU.createOkRetour());
    }
    //call mock For BL320 CF003
    prepareMockBL200(catalogue, RetourFactoryForTU.createOkRetour());
    prepareMockBL200(catalogue, RetourFactoryForTU.createOkRetour());
    ConnectorResponse<Retour, Nothing> connectRep = new ConnectorResponse<Retour, Nothing>(RetourFactoryForTU.createOkRetour(), null);
    //prepare mock CMD proxy
    prepareMockmodificationCommercialeCreerListe(connectRep);
    connectRep = new ConnectorResponse<Retour, Nothing>(RetourFactoryForTU.createOkRetour(), null);
    //prepare mock RPG proxy
    preparaMockPfiEcrire(connectRep);
    connectRep = new ConnectorResponse<Retour, Nothing>(RetourFactoryForTU.createOkRetour(), null);
    //prepare mock REX proxy
    prepareMockRexcomparaisonCommercialeCompositeCreer(connectRep);
    connectRep = new ConnectorResponse<Retour, Nothing>(RetourFactoryForTU.createOkRetour(), null);
    //prepare mock CMD proxy
    prepareMockCmdcommandeModifierStatut(connectRep);

    Retour retourKo = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.DONNEE_INDISPONIBLE, "erreur", null); //$NON-NLS-1$
    //prepare mock BL5200
    prepareMockBL5200(retourKo);
    //prepare mock BL4600
    prepareMockBL4600(retourKo);
    PowerMock.replayAll();
    _processInstance.run(request);
    _processInstance.continueProcess(request, tracabilite);
    PowerMock.verifyAll();
    Response response = (Response) request.getResponse();
    String resp = response.getGenericResponse().getResult();
    PEP0018_Retour PepReponse = GsonTools.getIso8601Sec().fromJson(resp, PEP0018_Retour.class);

    Assert.assertEquals(ErrorCode.KO_00400, request.getResponse().getErrorCode());
    Assert.assertEquals(PepReponse.getRetour().getCategorie(), IMegConsts.CAT4);
    Assert.assertEquals(PepReponse.getRetour().getDiagnostic(), IMegSpiritConsts.DONNEE_INDISPONIBLE);
    Assert.assertEquals(PepReponse.getRetour().getLibelle(), "erreur"); //$NON-NLS-1$
  }

  /**
   * Tests the PEP0018 Nominal <br>
   *
   * <b>Inputs: </b>Valid inputs <br>
   * <b>Expected: </b> Retour{OK}<br>
   *
   * @throws Exception
   *           On unexpected error
   */
  @Test
  public void PEP0018_Nominal_OK_001() throws Throwable
  {
    CommandePfi commandePfi = new CommandePfi(); //CommandePFI to put in donnees Brut of command
    PortefeuilleServices portfeulleservice = __podam.manufacturePojo(PortefeuilleServices.class);
    commandePfi.setPortefeuilleServices(portfeulleservice);
    commandePfi.getPortefeuilleServices().setStatut(Statut.ACTIF.name());
    commandePfi.getPortefeuilleServices().setServicesAccessibles(_pfiGenerator.buildServicesAccessibles());
    commandePfi.setTimestamp(LocalDateTime.now().plusDays(1));
    AbstractPointAcces pAccesVoipPortage = _pfiGenerator.buildPointAccesVoipPortage();
    AbstractPointAcces pAccesVoipPortTel = _pfiGenerator.buildPointAccesVoipPortTelephonique();
    AbstractPointAcces pAccesFax = _pfiGenerator.buildPointAccesFax();
    AbstractPointAcces pAccesCa = _pfiGenerator.buildPointAccesCompteAcces();
    List<AbstractPointAcces> pointsAcces = new ArrayList<>();
    pointsAcces.add(pAccesVoipPortage);
    pointsAcces.add(pAccesVoipPortTel);
    pointsAcces.add(pAccesFax);
    pointsAcces.add(pAccesCa);
    commandePfi.getPortefeuilleServices().setPointsAcces(pointsAcces);
    Commande command = __podam.manufacturePojo(Commande.class);
    command.setIdCmd("111"); //$NON-NLS-1$
    command.setStatut("ACQUITTE"); //$NON-NLS-1$
    command.setDonneesBrut(GsonTools.getIso8601Ms().toJson(commandePfi));
    CommandeId cmdId = new CommandeId(command.getIdCmd());
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    request.setPayload(GsonTools.getIso8601Ms().toJson(cmdId));
    PFI pfiExpected = new PFI();
    pfiExpected.setClientOperateur(command.getClientOperateur());
    pfiExpected.setNoCompte(command.getNoCompte());
    pfiExpected.setDatePhoto(LocalDateTime.now());
    // prepare all mock Connector
    ConnectorResponse<Retour, Commande> connectorRep = new ConnectorResponse<Retour, Commande>(RetourFactoryForTU.createOkRetour(), command);
    //prepare mock CMD proxy
    prepareMockCmdCommandeLireUn(connectorRep, command.getIdCmd());
    ConnectorResponse<Retour, PFI> connectorRpg = new ConnectorResponse<Retour, PFI>(RetourFactoryForTU.createOkRetour(), pfiExpected);
    //prepare mock RPG proxy
    prepareMockRpgPfiLireUn(connectorRpg, command.getClientOperateur(), command.getNoCompte());
    //prepare mock BL200
    CatalogServiceCommercial catalogue = __podam.manufacturePojo(CatalogServiceCommercial.class);
    //prepare mock BL200
    for (int i = 0; i < commandePfi.getPortefeuilleServices().getServicesAccessibles().size(); i++)
    {
      prepareMockBL200(catalogue, RetourFactoryForTU.createOkRetour());
    }
    //call mock For BL320 CF003
    prepareMockBL200(catalogue, RetourFactoryForTU.createOkRetour());
    prepareMockBL200(catalogue, RetourFactoryForTU.createOkRetour());
    ConnectorResponse<Retour, Nothing> connectRep = new ConnectorResponse<Retour, Nothing>(RetourFactoryForTU.createOkRetour(), null);
    //prepare mock CMD proxy
    prepareMockmodificationCommercialeCreerListe(connectRep);
    connectRep = new ConnectorResponse<Retour, Nothing>(RetourFactoryForTU.createOkRetour(), null);
    //prepare mock RPG proxy
    preparaMockPfiEcrire(connectRep);
    connectRep = new ConnectorResponse<Retour, Nothing>(RetourFactoryForTU.createOkRetour(), null);
    //prepare mock REX proxy
    prepareMockRexcomparaisonCommercialeCompositeCreer(connectRep);
    connectRep = new ConnectorResponse<Retour, Nothing>(RetourFactoryForTU.createOkRetour(), null);
    prepareMockCmdcommandeModifierStatut(connectRep);
    //prepare mock BL5200
    prepareMockBL5200(RetourFactoryForTU.createOkRetour());
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();
    Response response = (Response) request.getResponse();
    String resp = response.getGenericResponse().getResult();
    PEP0018_Retour PepReponse = GsonTools.getIso8601Sec().fromJson(resp, PEP0018_Retour.class);

    Assert.assertEquals(ErrorCode.OK_00200, request.getResponse().getErrorCode());
    Assert.assertEquals(PepReponse.getRetour().getResultat(), "OK"); //$NON-NLS-1$

  }

  /**
   * Tests the PEP0018_BL001_VerifierDonnees method when CMD004 returns KO
   *
   * <b>Inputs:</b> Generated KO for CM004 mock<br>
   * <b>Expected:</b> Retour {KO; CAT1; ERREUR_TECHNIQUE; ""}<br>
   *
   * @throws Exception
   *           on unexpected error
   */

  @Before
  public void setUp() throws Exception
  {
    _processInstance = new PEP0018_CommandePfi();
    _processInstance.initializeContext();
    tracabilite = __podam.manufacturePojo(Tracabilite.class);
    _pfiGenerator = new PFIFullForTest();

    PowerMock.resetAll();
    PowerMock.mockStaticStrict(CMDProxy.class);
    PowerMock.mockStaticStrict(RPGProxy.class);
    PowerMock.mockStaticStrict(BL200_ObtenirServiceCommercialBuilder.class);
    PowerMock.mockStaticStrict(BL200_ObtenirServiceCommercial.class);
    PowerMock.mockStaticStrict(REXProxy.class);
    PowerMock.mockStaticStrict(BL4600_CreerErreurSpirit.class);
    PowerMock.mockStaticStrict(BL4600_CreerErreurSpiritBuilder.class);

  }

  /**
   * mock rpgProxy pfiEcrire
   *
   * @param connectReponse
   *          connector response
   * @throws RavelException
   *           excepetion
   */
  private void preparaMockPfiEcrire(ConnectorResponse<Retour, Nothing> connectReponse) throws RavelException
  {
    EasyMock.expect(RPGProxy.getInstance()).andReturn(rpgProxyMock);
    EasyMock.expect(rpgProxyMock.pfiEcrire(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject())).andReturn(connectReponse);
  }

  /**
   * mock BL200
   *
   * @param catalogue
   *          catalogue
   * @param retour
   *          retour
   * @param clientOperateur
   *          client operateur
   * @param servicecommercial
   *          service commercial
   * @throws Exception
   */
  private void prepareMockBL200(CatalogServiceCommercial catalogue, Retour retour) throws Exception
  {

    PowerMock.expectNew(BL200_ObtenirServiceCommercialBuilder.class).andReturn(bl200BuilderMock);
    EasyMock.expect(bl200BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(bl200BuilderMock);
    EasyMock.expect(bl200BuilderMock.clientOperateur(EasyMock.anyObject())).andReturn(bl200BuilderMock);
    EasyMock.expect(bl200BuilderMock.noServiceCommercial(EasyMock.anyObject())).andReturn(bl200BuilderMock);
    EasyMock.expect(bl200BuilderMock.build()).andReturn(bl200Mock);
    EasyMock.expect(bl200Mock.execute(EasyMock.anyObject(PEP0018_CommandePfi.class))).andReturn(catalogue);
    EasyMock.expect(bl200Mock.getRetour()).andReturn(retour);
  }

  /**
   * prepare mock BL4600
   *
   * @param retour
   *          Retour
   * @throws Exception
   */
  private void prepareMockBL4600(Retour retour) throws Exception
  {

    PowerMock.expectNew(BL4600_CreerErreurSpiritBuilder.class).andReturn(bl4600BuilderMock);
    EasyMock.expect(bl4600BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(bl4600BuilderMock);
    EasyMock.expect(bl4600BuilderMock.retour(EasyMock.eq(retour))).andReturn(bl4600BuilderMock);
    EasyMock.expect(bl4600BuilderMock.build()).andReturn(bl4600Mock);
    EasyMock.expect(bl4600Mock.execute(EasyMock.anyObject(PEP0018_CommandePfi.class))).andReturn(null);
    EasyMock.expect(bl4600Mock.getRetour()).andReturn(retour);

  }

  /**
   * prepare mock BL5200
   *
   * @param retour
   *          Retour
   * @throws Exception
   */
  private void prepareMockBL5200(Retour retour) throws Exception
  {

    PowerMock.expectNew(BL5200_GererRaccordementCommercialBuilder.class).andReturn(bl5200BuilderMock);
    EasyMock.expect(bl5200BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(bl5200BuilderMock);
    EasyMock.expect(bl5200BuilderMock.noCompte(EasyMock.anyObject())).andReturn(bl5200BuilderMock);
    EasyMock.expect(bl5200BuilderMock.clientOperateur(EasyMock.anyObject())).andReturn(bl5200BuilderMock);
    EasyMock.expect(bl5200BuilderMock.build()).andReturn(bl5200Mock);
    EasyMock.expect(bl5200Mock.execute(EasyMock.anyObject(PEP0018_CommandePfi.class))).andReturn(null);
    EasyMock.expect(bl5200Mock.getRetour()).andReturn(retour);
  }

  /**
   * @param connectRep
   *          connectrop response
   * @param idcmd
   *          id cmd
   * @throws RavelException
   */
  private void prepareMockCmdCommandeLireUn(ConnectorResponse<Retour, Commande> connectRep, String idcmd) throws RavelException
  {
    EasyMock.expect(CMDProxy.getInstance()).andReturn(cmdProxyMock);
    EasyMock.expect(cmdProxyMock.commandeLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(idcmd))).andReturn(connectRep);
  }

  /**
   * @param connectRep
   *          connector reponse
   * @throws RavelException
   *           exception
   */
  private void prepareMockCmdcommandeModifierStatut(ConnectorResponse<Retour, Nothing> connectRep) throws RavelException
  {
    EasyMock.expect(CMDProxy.getInstance()).andReturn(cmdProxyMock);
    EasyMock.expect(cmdProxyMock.commandeModifierStatut(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(), EasyMock.anyObject(), EasyMock.anyObject(), EasyMock.anyObject())).andReturn(connectRep);
  }

  /**
   * @param connectRep
   * @param idcmd
   * @param listmodif
   * @throws RavelException
   */
  private void prepareMockmodificationCommercialeCreerListe(ConnectorResponse<Retour, Nothing> connectRep) throws RavelException
  {

    EasyMock.expect(CMDProxy.getInstance()).andReturn(cmdProxyMock);
    EasyMock.expect(cmdProxyMock.modificationCommercialeCreerListe(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject())).andReturn(connectRep);
  }

  /**
   * @param connectrep
   *          connector rep
   * @throws RavelException
   *           exception
   */
  private void prepareMockRexcomparaisonCommercialeCompositeCreer(ConnectorResponse<Retour, Nothing> connectrep) throws RavelException
  {

    EasyMock.expect(REXProxy.getInstance()).andReturn(rexProxyMock);
    EasyMock.expect(rexProxyMock.comparaisonCommercialeCompositeCreer(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject())).andReturn(connectrep);

  }

  /**
   * @param connectResponse
   *          connector response
   * @param clientOperateur
   *          client operateur
   * @param noCompte
   *          no compte
   * @throws RavelException
   *           ravel exceptino
   */
  private void prepareMockRpgPfiLireUn(ConnectorResponse<Retour, PFI> connectResponse, String clientOperateur, String noCompte) throws RavelException
  {
    EasyMock.expect(RPGProxy.getInstance()).andReturn(rpgProxyMock);
    EasyMock.expect(rpgProxyMock.pfiLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(clientOperateur), EasyMock.eq(noCompte))).andReturn(connectResponse);

  }
}
