/*******************************************************************************
* $Id: EquipementDeclareComparator_Test.java 17760 2019-02-27 17:02:37Z kbettenc $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PE0018.utils.comparators;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.junit.Test;

import com.bytel.ravel.common.exception.RavelException;
import com.bytel.spirit.common.shared.saab.cmd.Commande;
import com.bytel.spirit.common.shared.saab.cmd.NatureCommande;
import com.bytel.spirit.common.shared.saab.rpg.EquipementDeclare;
import com.bytel.spirit.common.shared.saab.rpg.PFI;
import com.bytel.spirit.common.shared.saab.rpg.Statut;
import com.bytel.spirit.prof.processes.PE0018.utils.PFIComparatorUtils;
import com.bytel.spirit.prof.processes.PE0018.utils.TypeModificationEnum;
import com.bytel.spirit.prof.processes.PE0018.utils.TypeObjectCommercialEnum;

/**
 *
 * @author pramos
 * @version ($Revision: 17760 $ $Date: 2019-02-27 18:02:37 +0100 (mer. 27 févr. 2019) $)
 */
public class EquipementDeclareComparator_Test implements IModificationPFI_Test
{
  /**
   *
   */
  private static final String ID_CMD = "idCmd"; //$NON-NLS-1$
  /**
   *
   */
  private static final String NO_COMPTE = "noCompte"; //$NON-NLS-1$
  /**
   *
   */
  private static final String CLIENT_OPERATEUR = "clientOperateur"; //$NON-NLS-1$

  /**
   * Creation of a EquipementDeclare<br>
   *
   * <b>Inputs:</b> A new EquipementDeclare<br>
   * <b>Expected:</b> Creation done <br>
   *
   * @throws RavelException
   */
  @Test
  public void testCreationEquipementDeclare_000() throws RavelException
  {
    Commande commande = new Commande();
    commande.setIdCmd(ID_CMD);

    EquipementDeclare equipTarget = buildEquipementDeclare();
    PFI pfi = new PFI();
    pfi.setClientOperateur(CLIENT_OPERATEUR);
    pfi.setNoCompte(NO_COMPTE);

    PFIComparatorUtils result = new PFIComparatorUtils();
    EquipementDeclareComparator comparator = new EquipementDeclareComparator(pfi, commande, result, LocalDateTime.now());
    comparator.compare(null, equipTarget);

    //Check EquipementDeclare
    assertEquals(Arrays.asList(equipTarget), pfi.getEquipementDeclare());

    //Check ModificationCommerciale
    assertEquals(commande.getIdCmd(), result.getMcList().get(0).getIdCmd());
    assertEquals(AbstractComparator.EN_COURS, result.getMcList().get(0).getStatut());
    assertEquals(TypeObjectCommercialEnum.EQT_DECLARE.name(), result.getMcList().get(0).getTypeObjetCommercial());
    assertEquals(pfi.getNoCompte(), result.getMcList().get(0).getNoCompte());
    assertEquals(pfi.getClientOperateur(), result.getMcList().get(0).getClientOperateur());
    assertEquals(equipTarget.getNoEquipement(), result.getMcList().get(0).getNoEquipement());

    //Check ElementComparaison
    assertEquals(TypeObjectCommercialEnum.EQT_DECLARE.name(), result.getEcList().get(0).getTypeObjetCommercial());
    assertEquals(TypeModificationEnum.CREATION.name(), result.getEcList().get(0).getTypeOperation());
    assertEquals(pfi.getClientOperateur(), result.getEcList().get(0).getClientOperateur());
    assertEquals(pfi.getNoCompte(), result.getEcList().get(0).getNoCompte());
    assertEquals(equipTarget.getNoEquipement(), result.getEcList().get(0).getNoEquipement());
  }

  /**
   * Test case when a EquipementDeclare is unchange and AddUnchangedObjects is false
   *
   * @throws RavelException
   */
  @Test
  public void testEqualsEquipementDeclare_001() throws RavelException
  {
    Commande commande = new Commande();
    PFI pfi = new PFI();
    EquipementDeclare equipSource = buildEquipementDeclare();

    PFIComparatorUtils result = new PFIComparatorUtils();
    EquipementDeclareComparator comparator = new EquipementDeclareComparator(pfi, commande, result, LocalDateTime.now());
    comparator.getPFIComparatorUtils().setAddUnchangedObjects(false);
    comparator.getPFIComparatorUtils().setPaTypeList(Arrays.asList("LIGNE_FIXE,VOIP,FAX,COMPTE_ACCES,TV".split(","))); //$NON-NLS-1$ //$NON-NLS-2$
    comparator.compare(equipSource, equipSource);

    assertEquals(0, pfi.getEquipementDeclare().size());
    //Check ModificationCommercial
    assertEquals(0, result.getMcList().size());
    //Check ElementComparaison
    assertEquals(0, result.getEcList().size());
  }

  /**
   * Test case when a EquipementDeclare is unchange
   */
  @Test
  public void testEqualsEquipementDeclare_002() throws RavelException
  {
    Commande commande = new Commande();
    PFI pfi = new PFI();
    EquipementDeclare equipSource = buildEquipementDeclare();

    PFIComparatorUtils result = new PFIComparatorUtils();
    EquipementDeclareComparator comparator = new EquipementDeclareComparator(pfi, commande, result, LocalDateTime.now());
    comparator.getPFIComparatorUtils().setAddUnchangedObjects(true);
    comparator.getPFIComparatorUtils().setPaTypeList(Arrays.asList("LIGNE_FIXE,VOIP,FAX,COMPTE_ACCES,TV".split(","))); //$NON-NLS-1$ //$NON-NLS-2$
    comparator.compare(equipSource, equipSource);

    assertEquals(0, pfi.getEquipementDeclare().size());
    //Check ModificationCommercial
    assertEquals(0, result.getMcList().size());
    //Check ElementComparaison
    assertEquals(TypeObjectCommercialEnum.EQT_DECLARE.name(), result.getEcList().get(0).getTypeObjetCommercial());
    assertEquals(TypeModificationEnum.AUCUNE.name(), result.getEcList().get(0).getTypeOperation());
    assertEquals(IModificationValue_Test.NO_EQUIPEMENT, result.getEcList().get(0).getNoEquipement());
    assertEquals(0, result.getEcList().get(0).getListeAttributModifie().size());
  }

  /**
   * Modification of a EquipementDeclare in a PFI from a Commande with NatureCommande PHOTO <br>
   *
   * <b>Inputs:</b> Commande with NatureCommande = PHOTO <br>
   * <b>Expected:</b> Modification done with a complete copy of the EquipementDeclare <br>
   */
  @Test
  public void testModificationEquipementDeclare_001() throws RavelException
  {
    Commande commande = new Commande();
    commande.setNatureCommande(NatureCommande.PHOTO_PFI.name());

    PFI pfi = new PFI();
    EquipementDeclare equipSource = buildEquipementDeclare();
    addEquipementDeclareToPFI(pfi, equipSource);

    EquipementDeclare equipTarget = new EquipementDeclare(equipSource.getNoEquipement(), "new_noIdentifiant", "new_typeEquipement", Statut.RESILIE, null, null); //$NON-NLS-1$ //$NON-NLS-2$
    equipTarget.setModele("new_modele"); //$NON-NLS-1$
    equipTarget.setNomFabricant("new_nomFabricant"); //$NON-NLS-1$
    equipTarget.setNoIdentifiantIadOnebox("new_noIdentifiantIadOnebox"); //$NON-NLS-1$
    equipTarget.setModeleIadOnebox("new_modeleIadOnebox"); //$NON-NLS-1$
    equipTarget.setNoIdentifiantStbOnebox("new_noIdentifiantStbOnebox"); //$NON-NLS-1$
    equipTarget.setModeleStbOnebox("new_modeleStbOnebox"); //$NON-NLS-1$
    equipTarget.setMacAddressModem("new_macAddressModem"); //$NON-NLS-1$
    equipTarget.setMacAddressMta("new_macAddressMta"); //$NON-NLS-1$
    equipTarget.setMacAddressGateway("new_macAddressGateway"); //$NON-NLS-1$
    equipTarget.setMacAddressTv("new_macAddressTv"); //$NON-NLS-1$
    equipTarget.setCodeEan("new_codeEan"); //$NON-NLS-1$
    equipTarget.setNoEquipementLie("new_noEquipementLie"); //$NON-NLS-1$

    PFIComparatorUtils result = new PFIComparatorUtils();
    EquipementDeclareComparator comparator = new EquipementDeclareComparator(pfi, commande, result, LocalDateTime.now());
    comparator.compare(equipSource, equipTarget);

    //Check EquipementDeclare
    assertFalse(pfi.getEquipementDeclare().contains(equipSource));
    assertTrue(pfi.getEquipementDeclare().contains(equipTarget));

    //Check ModificationCommercial
    assertTrue(result.getMcList().isEmpty());

    //Check ElementComparaison
    assertEquals(TypeObjectCommercialEnum.EQT_DECLARE.name(), result.getEcList().get(0).getTypeObjetCommercial());
    assertEquals(TypeModificationEnum.MODIF_ATTR.name(), result.getEcList().get(0).getTypeOperation());
    assertEquals(IModificationValue_Test.NO_EQUIPEMENT, result.getEcList().get(0).getNoEquipement());
    assertEquals(15, result.getEcList().get(0).getListeAttributModifie().size());
  }

  /**
   * Modification of a EquipementDeclare in a PFI from a Commande with NatureCommande MODIFICATION<br>
   *
   * <b>Inputs:</b> Commande with NatureCommande = MODIFICATION / EquipementDeclare with Statut = RESILIE (all the other
   * attributes are null) <br>
   * <b>Expected:</b> Modification done with a copy of the delta between EquipementDeclare source and target <br>
   */
  @Test
  public void testModificationEquipementDeclare_002() throws RavelException
  {
    Commande commande = new Commande();
    commande.setNatureCommande(NatureCommande.MODIFICATION_PFI.name());

    PFI pfi = new PFI();
    EquipementDeclare equipSource = buildEquipementDeclare();
    addEquipementDeclareToPFI(pfi, equipSource);

    EquipementDeclare equipTarget = new EquipementDeclare(null, null, null, Statut.RESILIE, null, null);
    equipTarget.setNoEquipement(equipSource.getNoEquipement()); //IDs need to be equal

    PFIComparatorUtils result = new PFIComparatorUtils();
    EquipementDeclareComparator comparator = new EquipementDeclareComparator(pfi, commande, result, LocalDateTime.now());
    comparator.compare(equipSource, equipTarget);

    //Only the status changes (=the one in the target)
    assertEquals(equipTarget.getStatut(), pfi.getEquipementDeclare().get(0).getStatut());
    assertEquals(IModificationValue_Test.NO_EQUIPEMENT, pfi.getEquipementDeclare().get(0).getNoEquipement());
    assertEquals(IModificationValue_Test.NO_IDENTIFIANT_EQUIP, pfi.getEquipementDeclare().get(0).getNoIdentifiant());
    assertEquals("MODEM", pfi.getEquipementDeclare().get(0).getTypeEquipement()); //$NON-NLS-1$
    assertEquals(IModificationValue_Test.MODELE_EQUIPEMENT, pfi.getEquipementDeclare().get(0).getModele());
    assertEquals(IModificationValue_Test.NOM_FABRICANT_EQUIP, pfi.getEquipementDeclare().get(0).getNomFabricant());
    assertEquals(IModificationValue_Test.NO_IDENTIFIANT_IAD_ONEBOX, pfi.getEquipementDeclare().get(0).getNoIdentifiantIadOnebox());
    assertEquals(IModificationValue_Test.MODELE_IAD_ONEBOX, pfi.getEquipementDeclare().get(0).getModeleIadOnebox());
    assertEquals(IModificationValue_Test.NO_IDENTIFIANT_STB_ONEBOX, pfi.getEquipementDeclare().get(0).getNoIdentifiantStbOnebox());
    assertEquals(IModificationValue_Test.MODELE_STB_ONEBOX, pfi.getEquipementDeclare().get(0).getModeleStbOnebox());
    assertEquals(IModificationValue_Test.MAC_ADRESS_MODEM, pfi.getEquipementDeclare().get(0).getMacAddressModem());
    assertEquals(IModificationValue_Test.MAC_ADRESS_MTA, pfi.getEquipementDeclare().get(0).getMacAddressMta());
    assertEquals(IModificationValue_Test.MAC_ADRESS_GATEWAY, pfi.getEquipementDeclare().get(0).getMacAddressGateway());
    assertEquals(IModificationValue_Test.MAC_ADRESS_TV, pfi.getEquipementDeclare().get(0).getMacAddressTv());
    assertEquals(IModificationValue_Test.CODE_EAN_EQUIP, pfi.getEquipementDeclare().get(0).getCodeEan());
    assertEquals(IModificationValue_Test.NO_EQUIPEMENT_LIE, pfi.getEquipementDeclare().get(0).getNoEquipementLie());

    //Check ModificationCommercial
    assertEquals(0, result.getMcList().size());
    //Check ElementComparaison
    assertEquals(TypeObjectCommercialEnum.EQT_DECLARE.name(), result.getEcList().get(0).getTypeObjetCommercial());
    assertEquals(TypeModificationEnum.MODIF_ATTR.name(), result.getEcList().get(0).getTypeOperation());
    assertEquals(equipTarget.getNoEquipement(), result.getEcList().get(0).getNoEquipement());
    assertEquals(1, result.getEcList().get(0).getListeAttributModifie().size());
  }

  /**
   * Modification of a EquipementDeclare in a PFI from a Commande with NatureCommande MODIFICATION<br>
   *
   * <b>Inputs:</b> Commande with NatureCommande = MODIFICATION / EquipementDeclare with only Statut=null (all the other
   * attributes are not null) <br>
   * <b>Expected:</b> Modification done with a copy of the delta between EquipementDeclare source and target <br>
   */
  @Test
  public void testModificationEquipementDeclare_003() throws RavelException
  {
    Commande commande = new Commande();
    commande.setNatureCommande(NatureCommande.MODIFICATION_PFI.name());

    PFI pfi = new PFI();
    EquipementDeclare equipSource = buildEquipementDeclare();
    addEquipementDeclareToPFI(pfi, equipSource);

    EquipementDeclare equipTarget = new EquipementDeclare("new_noEquipement", "new_noIdentifiant", "new_typeEquipement", null, null, null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    equipTarget.setNoEquipement(equipSource.getNoEquipement()); //IDs need to be equals
    equipTarget.setModele(RandomStringUtils.random(20));
    equipTarget.setNomFabricant(RandomStringUtils.random(20));
    equipTarget.setNoIdentifiantIadOnebox(RandomStringUtils.random(20));
    equipTarget.setModeleIadOnebox(RandomStringUtils.random(20));
    equipTarget.setNoIdentifiantStbOnebox(RandomStringUtils.random(20));
    equipTarget.setModeleStbOnebox(RandomStringUtils.random(20));
    equipTarget.setMacAddressModem(RandomStringUtils.random(20));
    equipTarget.setMacAddressMta(RandomStringUtils.random(20));
    equipTarget.setMacAddressGateway(RandomStringUtils.random(20));
    equipTarget.setMacAddressTv(RandomStringUtils.random(20));
    equipTarget.setCodeEan(RandomStringUtils.random(20));
    equipTarget.setNoEquipementLie(RandomStringUtils.random(20));

    PFIComparatorUtils result = new PFIComparatorUtils();
    EquipementDeclareComparator comparator = new EquipementDeclareComparator(pfi, commande, result, LocalDateTime.now());
    comparator.compare(equipSource, equipTarget);

    //Only the status stays the same as in the source
    assertEquals(Statut.ACTIF, pfi.getEquipementDeclare().get(0).getStatut());
    assertEquals(equipTarget.getNoEquipement(), pfi.getEquipementDeclare().get(0).getNoEquipement());
    assertEquals(equipTarget.getNoIdentifiant(), pfi.getEquipementDeclare().get(0).getNoIdentifiant());
    assertEquals(equipTarget.getTypeEquipement(), pfi.getEquipementDeclare().get(0).getTypeEquipement());
    assertEquals(equipTarget.getModele(), pfi.getEquipementDeclare().get(0).getModele());
    assertEquals(equipTarget.getNomFabricant(), pfi.getEquipementDeclare().get(0).getNomFabricant());
    assertEquals(equipTarget.getNoIdentifiantIadOnebox(), pfi.getEquipementDeclare().get(0).getNoIdentifiantIadOnebox());
    assertEquals(equipTarget.getModeleIadOnebox(), pfi.getEquipementDeclare().get(0).getModeleIadOnebox());
    assertEquals(equipTarget.getNoIdentifiantStbOnebox(), pfi.getEquipementDeclare().get(0).getNoIdentifiantStbOnebox());
    assertEquals(equipTarget.getModeleStbOnebox(), pfi.getEquipementDeclare().get(0).getModeleStbOnebox());
    assertEquals(equipTarget.getMacAddressModem(), pfi.getEquipementDeclare().get(0).getMacAddressModem());
    assertEquals(equipTarget.getMacAddressMta(), pfi.getEquipementDeclare().get(0).getMacAddressMta());
    assertEquals(equipTarget.getMacAddressGateway(), pfi.getEquipementDeclare().get(0).getMacAddressGateway());
    assertEquals(equipTarget.getMacAddressTv(), pfi.getEquipementDeclare().get(0).getMacAddressTv());
    assertEquals(equipTarget.getCodeEan(), pfi.getEquipementDeclare().get(0).getCodeEan());
    assertEquals(equipTarget.getNoEquipementLie(), pfi.getEquipementDeclare().get(0).getNoEquipementLie());

    //Check ModificationCommercial
    assertEquals(0, result.getMcList().size());
    //Check ElementComparaison
    assertEquals(TypeObjectCommercialEnum.EQT_DECLARE.name(), result.getEcList().get(0).getTypeObjetCommercial());
    assertEquals(TypeModificationEnum.MODIF_ATTR.name(), result.getEcList().get(0).getTypeOperation());
    assertEquals(equipTarget.getNoEquipement(), result.getEcList().get(0).getNoEquipement());
    assertEquals(14, result.getEcList().get(0).getListeAttributModifie().size());
  }

  /**
   * Deletion of a EquipementDeclare with Statut ACTIF<br>
   *
   * <b>Inputs:</b> EquipementDeclare with Statut = ACTIF <br>
   * <b>Expected:</b> The status of EquipementDeclare source is now RESILIE <br>
   */
  @Test
  public void testSuppressionEquipementDeclare_001() throws RavelException
  {
    Commande commande = new Commande();
    commande.setIdCmd(ID_CMD);
    PFI pfi = new PFI();
    EquipementDeclare equipSource = buildEquipementDeclare();
    addEquipementDeclareToPFI(pfi, equipSource);

    PFIComparatorUtils result = new PFIComparatorUtils();
    EquipementDeclareComparator comparator = new EquipementDeclareComparator(pfi, commande, result, LocalDateTime.now());
    comparator.compare(equipSource, null);

    //Check EquipementDeclare
    //Only the status changes (becomes RESILIE)
    assertEquals(Statut.RESILIE, pfi.getEquipementDeclare().get(0).getStatut());
    assertEquals(IModificationValue_Test.NO_EQUIPEMENT, pfi.getEquipementDeclare().get(0).getNoEquipement());
    assertEquals(IModificationValue_Test.NO_IDENTIFIANT_EQUIP, pfi.getEquipementDeclare().get(0).getNoIdentifiant());
    assertEquals("MODEM", pfi.getEquipementDeclare().get(0).getTypeEquipement()); //$NON-NLS-1$
    assertEquals(IModificationValue_Test.MODELE_EQUIPEMENT, pfi.getEquipementDeclare().get(0).getModele());
    assertEquals(IModificationValue_Test.NOM_FABRICANT_EQUIP, pfi.getEquipementDeclare().get(0).getNomFabricant());
    assertEquals(IModificationValue_Test.NO_IDENTIFIANT_IAD_ONEBOX, pfi.getEquipementDeclare().get(0).getNoIdentifiantIadOnebox());
    assertEquals(IModificationValue_Test.MODELE_IAD_ONEBOX, pfi.getEquipementDeclare().get(0).getModeleIadOnebox());
    assertEquals(IModificationValue_Test.NO_IDENTIFIANT_STB_ONEBOX, pfi.getEquipementDeclare().get(0).getNoIdentifiantStbOnebox());
    assertEquals(IModificationValue_Test.MODELE_STB_ONEBOX, pfi.getEquipementDeclare().get(0).getModeleStbOnebox());
    assertEquals(IModificationValue_Test.MAC_ADRESS_MODEM, pfi.getEquipementDeclare().get(0).getMacAddressModem());
    assertEquals(IModificationValue_Test.MAC_ADRESS_MTA, pfi.getEquipementDeclare().get(0).getMacAddressMta());
    assertEquals(IModificationValue_Test.MAC_ADRESS_GATEWAY, pfi.getEquipementDeclare().get(0).getMacAddressGateway());
    assertEquals(IModificationValue_Test.MAC_ADRESS_TV, pfi.getEquipementDeclare().get(0).getMacAddressTv());
    assertEquals(IModificationValue_Test.CODE_EAN_EQUIP, pfi.getEquipementDeclare().get(0).getCodeEan());
    assertEquals(IModificationValue_Test.NO_EQUIPEMENT_LIE, pfi.getEquipementDeclare().get(0).getNoEquipementLie());

    //Check ModificationCommerciale
    assertEquals(commande.getIdCmd(), result.getMcList().get(0).getIdCmd());
    assertEquals(AbstractComparator.EN_COURS, result.getMcList().get(0).getStatut());
    assertEquals(TypeObjectCommercialEnum.EQT_DECLARE.name(), result.getMcList().get(0).getTypeObjetCommercial());
    assertEquals(pfi.getNoCompte(), result.getMcList().get(0).getNoCompte());
    assertEquals(commande.getClientOperateur(), result.getMcList().get(0).getClientOperateur());
    assertEquals(IModificationValue_Test.NO_EQUIPEMENT, result.getMcList().get(0).getNoEquipement());
    assertEquals(Statut.RESILIE.name(), result.getMcList().get(0).getStatutCommercialAttendu());

    //Check ElementComparaison
    assertEquals(TypeObjectCommercialEnum.EQT_DECLARE.name(), result.getEcList().get(0).getTypeObjetCommercial());
    assertEquals(TypeModificationEnum.SUPPRESSION.name(), result.getEcList().get(0).getTypeOperation());
    assertEquals(equipSource.getNoEquipement(), result.getEcList().get(0).getNoEquipement());
    assertEquals(0, result.getEcList().get(0).getListeAttributModifie().size());
  }

  /**
   * Deletion of a EquipementDeclare with Statut RESILIE<br>
   *
   * <b>Inputs:</b> EquipementDeclare with Statut = RESILIE <br>
   * <b>Expected:</b> The EquipementDeclare source stays the sames <br>
   */
  @Test
  public void testSuppressionEquipementDeclare_002() throws RavelException
  {
    Commande commande = new Commande();
    PFI pfi = new PFI();
    EquipementDeclare equipSource = buildEquipementDeclare();
    equipSource.setStatut(Statut.RESILIE);
    addEquipementDeclareToPFI(pfi, equipSource);

    PFIComparatorUtils result = new PFIComparatorUtils();
    EquipementDeclareComparator comparator = new EquipementDeclareComparator(pfi, commande, result, LocalDateTime.now());
    comparator.compare(equipSource, null);

    //Check EquipementDeclare
    //No changes
    assertEquals(Statut.RESILIE, pfi.getEquipementDeclare().get(0).getStatut());
    assertEquals(IModificationValue_Test.NO_EQUIPEMENT, pfi.getEquipementDeclare().get(0).getNoEquipement());
    assertEquals(IModificationValue_Test.NO_IDENTIFIANT_EQUIP, pfi.getEquipementDeclare().get(0).getNoIdentifiant());
    assertEquals("MODEM", pfi.getEquipementDeclare().get(0).getTypeEquipement()); //$NON-NLS-1$
    assertEquals(IModificationValue_Test.MODELE_EQUIPEMENT, pfi.getEquipementDeclare().get(0).getModele());
    assertEquals(IModificationValue_Test.NOM_FABRICANT_EQUIP, pfi.getEquipementDeclare().get(0).getNomFabricant());
    assertEquals(IModificationValue_Test.NO_IDENTIFIANT_IAD_ONEBOX, pfi.getEquipementDeclare().get(0).getNoIdentifiantIadOnebox());
    assertEquals(IModificationValue_Test.MODELE_IAD_ONEBOX, pfi.getEquipementDeclare().get(0).getModeleIadOnebox());
    assertEquals(IModificationValue_Test.NO_IDENTIFIANT_STB_ONEBOX, pfi.getEquipementDeclare().get(0).getNoIdentifiantStbOnebox());
    assertEquals(IModificationValue_Test.MODELE_STB_ONEBOX, pfi.getEquipementDeclare().get(0).getModeleStbOnebox());
    assertEquals(IModificationValue_Test.MAC_ADRESS_MODEM, pfi.getEquipementDeclare().get(0).getMacAddressModem());
    assertEquals(IModificationValue_Test.MAC_ADRESS_MTA, pfi.getEquipementDeclare().get(0).getMacAddressMta());
    assertEquals(IModificationValue_Test.MAC_ADRESS_GATEWAY, pfi.getEquipementDeclare().get(0).getMacAddressGateway());
    assertEquals(IModificationValue_Test.MAC_ADRESS_TV, pfi.getEquipementDeclare().get(0).getMacAddressTv());
    assertEquals(IModificationValue_Test.CODE_EAN_EQUIP, pfi.getEquipementDeclare().get(0).getCodeEan());
    assertEquals(IModificationValue_Test.NO_EQUIPEMENT_LIE, pfi.getEquipementDeclare().get(0).getNoEquipementLie());

    assertTrue(result.getMcList().isEmpty());
    assertTrue(result.getEcList().isEmpty());
  }

  /**
   * @param pfi_p
   * @param equipSource_p
   * @return
   */
  private void addEquipementDeclareToPFI(PFI pfi_p, EquipementDeclare equipSource_p)
  {
    List<EquipementDeclare> equipementDeclareList = pfi_p.getEquipementDeclare();
    equipementDeclareList.add(equipSource_p);
    pfi_p.setEquipementDeclare(equipementDeclareList);
  }
}
