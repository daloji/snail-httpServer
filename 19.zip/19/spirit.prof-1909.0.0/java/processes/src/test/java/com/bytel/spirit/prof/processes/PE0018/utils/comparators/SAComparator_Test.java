/*******************************************************************************
* $Id: SAComparator_Test.java 17760 2019-02-27 17:02:37Z kbettenc $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PE0018.utils.comparators;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

import org.junit.Test;

import com.bytel.spirit.common.shared.saab.cmd.Commande;
import com.bytel.spirit.common.shared.saab.cmd.NatureCommande;
import com.bytel.spirit.common.shared.saab.rpg.PFI;
import com.bytel.spirit.common.shared.saab.rpg.SA;
import com.bytel.spirit.common.shared.saab.rpg.Statut;
import com.bytel.spirit.prof.processes.PE0018.utils.PFIComparatorUtils;
import com.bytel.spirit.prof.processes.PE0018.utils.TypeModificationEnum;
import com.bytel.spirit.prof.processes.PE0018.utils.TypeObjectCommercialEnum;

/**
 *
 * @author jsantos
 * @version ($Revision: 17760 $ $Date: 2019-02-27 18:02:37 +0100 (mer. 27 févr. 2019) $)
 */
public class SAComparator_Test implements IModificationPFI_Test
{

  /**
   *
   */
  private static final String NO_COMPTE = "noCompte"; //$NON-NLS-1$
  /**
   *
   */
  private static final String CLIENT_OPERATEUR = "clientOperateur"; //$NON-NLS-1$

  /**
   *
   */
  private static final String ID_CMD = "idCmd"; //$NON-NLS-1$

  /**
   * Creation of a SA<br>
   *
   * <b>Inputs:</b> A new SA<br>
   * <b>Expected:</b> Creation done <br>
   */
  @Test
  public void testCreationSA_000()
  {
    Commande commande = new Commande();
    commande.setIdCmd(ID_CMD);

    SA saTarget = buildSA();
    PFI pfi = new PFI();
    pfi.setClientOperateur(CLIENT_OPERATEUR);
    pfi.setNoCompte(NO_COMPTE);

    PFIComparatorUtils result = new PFIComparatorUtils();
    SAComparator comparator = new SAComparator(pfi, commande, result, LocalDateTime.now());
    comparator.compare(null, saTarget);

    //Check SA
    assertEquals(Arrays.asList(saTarget), pfi.getSa());

    //Check ModificationCommerciale
    assertEquals(commande.getIdCmd(), result.getMcList().get(0).getIdCmd());
    assertEquals(AbstractComparator.EN_COURS, result.getMcList().get(0).getStatut());
    assertEquals(TypeObjectCommercialEnum.SA.name(), result.getMcList().get(0).getTypeObjetCommercial());
    assertEquals(pfi.getNoCompte(), result.getMcList().get(0).getNoCompte());
    assertEquals(pfi.getClientOperateur(), result.getMcList().get(0).getClientOperateur());
    assertEquals(saTarget.getNoServiceAccessible(), result.getMcList().get(0).getNoServiceAccessible());

    //Check ElementComparaison
    assertEquals(TypeObjectCommercialEnum.SA.name(), result.getEcList().get(0).getTypeObjetCommercial());
    assertEquals(TypeModificationEnum.CREATION.name(), result.getEcList().get(0).getTypeOperation());
    assertEquals(pfi.getClientOperateur(), result.getEcList().get(0).getClientOperateur());
    assertEquals(pfi.getNoCompte(), result.getEcList().get(0).getNoCompte());
    assertEquals(saTarget.getNoServiceAccessible(), result.getEcList().get(0).getNoServiceAccessible());
  }

  /**
   * Test case when is to delete a SA
   */
  @Test
  public void testEqualsSA_005()
  {
    Commande commande = new Commande();
    SA saSource = buildSA();
    PFI pfi = new PFI();
    addSaToPFI(pfi, saSource);
    PFIComparatorUtils result = new PFIComparatorUtils();

    SAComparator comparator = new SAComparator(pfi, commande, result, LocalDateTime.now());
    comparator.getPFIComparatorUtils().setAddUnchangedObjects(true);
    comparator.getPFIComparatorUtils().setPaTypeList(Arrays.asList("LIGNE_FIXE,VOIP,FAX,COMPTE_ACCES,TV".split(","))); //$NON-NLS-1$ //$NON-NLS-2$
    comparator.compare(saSource, saSource);

    assertEquals(1, pfi.getSa().size());
    assertNull(pfi.getSa().get(0).getDateModification());
    //Check ModificationCommercial
    assertEquals(0, result.getMcList().size());
    //Check ElementComparaison
    assertEquals(TypeObjectCommercialEnum.SA.name(), result.getEcList().get(0).getTypeObjetCommercial());
    assertEquals(TypeModificationEnum.AUCUNE.name(), result.getEcList().get(0).getTypeOperation());
    //    assertEquals(saSource.getNoServiceAccessible(), result.getEcList().get(0).getIdObjetCommercial());
    assertEquals(0, result.getEcList().get(0).getListeAttributModifie().size());
  }

  /**
   * Test case when is to delete a SA and AddUnchangedObjects is false
   */
  @Test
  public void testEqualsSA_006()
  {
    Commande commande = new Commande();
    SA saSource = buildSA();
    PFI pfi = new PFI();
    addSaToPFI(pfi, saSource);
    PFIComparatorUtils result = new PFIComparatorUtils();

    SAComparator comparator = new SAComparator(pfi, commande, result, LocalDateTime.now());
    comparator.getPFIComparatorUtils().setAddUnchangedObjects(false);
    comparator.getPFIComparatorUtils().setPaTypeList(Arrays.asList("LIGNE_FIXE,VOIP,FAX,COMPTE_ACCES,TV".split(","))); //$NON-NLS-1$ //$NON-NLS-2$
    comparator.compare(saSource, saSource);

    assertEquals(1, pfi.getSa().size());
    assertNull(pfi.getSa().get(0).getDateModification());
    //Check ModificationCommercial
    assertEquals(0, result.getMcList().size());
    //Check ElementComparaison
    assertEquals(0, result.getEcList().size());
  }

  /**
   * Modification of a SA in a PFI from a Commande with NatureCommande PHOTO <br>
   *
   * <b>Inputs:</b> Commande with NatureCommande = PHOTO / All attributes of saTarget are different from saSource <br>
   * <b>Expected:</b> Modification done with a complete copy of the SA <br>
   */
  @Test
  public void testModificationSA_001()
  {
    Commande commande = new Commande();
    commande.setNatureCommande(NatureCommande.PHOTO_PFI.name());

    PFI pfi = new PFI();
    SA saSource = buildSA();
    addSaToPFI(pfi, saSource);

    SA saTarget = new SA();
    saTarget.setNoServiceAccessible(saSource.getNoServiceAccessible());
    saTarget.setNoServiceCommercial("new_noServiceCommercial"); //$NON-NLS-1$
    saTarget.setNomServiceCommercial("new_nomServiceCommercial"); //$NON-NLS-1$
    saTarget.setCategorieServiceCommercial("new_categorieServiceCommercial"); //$NON-NLS-1$
    saTarget.setStatut(Statut.RESILIE);

    PFIComparatorUtils result = new PFIComparatorUtils();
    SAComparator comparator = new SAComparator(pfi, commande, result, LocalDateTime.now());
    comparator.compare(saSource, saTarget);

    //Check SA
    assertFalse(pfi.getSa().contains(saSource));
    assertTrue(pfi.getSa().contains(saTarget));

    assertEquals(saTarget.getNoServiceAccessible(), pfi.getSa().get(0).getNoServiceAccessible());
    assertEquals(saTarget.getNomServiceCommercial(), pfi.getSa().get(0).getNomServiceCommercial());
    assertEquals(saTarget.getNoServiceCommercial(), pfi.getSa().get(0).getNoServiceCommercial());
    assertEquals(saTarget.getCategorieServiceCommercial(), pfi.getSa().get(0).getCategorieServiceCommercial());
    assertEquals(saTarget.getStatut(), pfi.getSa().get(0).getStatut());

    //Check ModificationCommerciale
    assertTrue(result.getMcList().isEmpty());

    //Check ElementComparaison
    assertEquals(TypeObjectCommercialEnum.SA.name(), result.getEcList().get(0).getTypeObjetCommercial());
    assertEquals(TypeModificationEnum.MODIF_ATTR.name(), result.getEcList().get(0).getTypeOperation());
    assertEquals(saTarget.getNoServiceAccessible(), result.getEcList().get(0).getNoServiceAccessible());
    assertEquals(4, result.getEcList().get(0).getListeAttributModifie().size());
  }

  /**
   * Modification of a SA in a PFI from a Commande with NatureCommande MODIFICATION<br>
   *
   * <b>Inputs:</b> Commande with NatureCommande = MODIFICATION / SA with Statut = RESILIE (all the other attributes are
   * null) <br>
   * <b>Expected:</b> Modification done with a copy of the delta between SA source and target <br>
   */
  @Test
  public void testModificationSA_002()
  {
    Commande commande = new Commande();
    commande.setNatureCommande(NatureCommande.MODIFICATION_PFI.name());

    PFI pfi = new PFI();
    SA saSource = buildSA();
    addSaToPFI(pfi, saSource);

    SA saTarget = new SA(null, null, null, null, Statut.RESILIE, null, null);
    saTarget.setNoServiceAccessible(saSource.getNoServiceAccessible());//IDs need to be equal

    PFIComparatorUtils result = new PFIComparatorUtils();
    SAComparator comparator = new SAComparator(pfi, commande, result, LocalDateTime.now());
    comparator.compare(saSource, saTarget);

    //Check SA
    //Only the status changes (=the one in the target)
    assertEquals(saTarget.getStatut(), pfi.getSa().get(0).getStatut());
    assertEquals(IModificationValue_Test.NO_SERVICE_ACCESSIBLE, pfi.getSa().get(0).getNoServiceAccessible());
    assertEquals(IModificationValue_Test.NOM_SERVICE_COMMERCIAL, pfi.getSa().get(0).getNomServiceCommercial());
    assertEquals(IModificationValue_Test.NO_SERVICE_COMMERCIAL, pfi.getSa().get(0).getNoServiceCommercial());
    assertEquals(IModificationValue_Test.CATEGORIE_SERVICE_COMMERCIAL, pfi.getSa().get(0).getCategorieServiceCommercial());

    //Check ModificationCommerciale
    assertEquals(0, result.getMcList().size());

    //Check ElementComparaison
    assertEquals(TypeObjectCommercialEnum.SA.name(), result.getEcList().get(0).getTypeObjetCommercial());
    assertEquals(TypeModificationEnum.MODIF_ATTR.name(), result.getEcList().get(0).getTypeOperation());
    assertEquals(IModificationValue_Test.NO_SERVICE_ACCESSIBLE, result.getEcList().get(0).getNoServiceAccessible());
    assertEquals(1, result.getEcList().get(0).getListeAttributModifie().size());
  }

  /**
   * Modification of a SA in a PFI from a Commande with NatureCommande MODIFICATION<br>
   *
   * <b>Inputs:</b> Commande with NatureCommande = MODIFICATION / SA with only Statut=null (all the other attributes are
   * not null) <br>
   * <b>Expected:</b> Modification done with a copy of the delta between SA source and target <br>
   */
  @Test
  public void testModificationSA_003()
  {
    Commande commande = new Commande();
    commande.setNatureCommande(NatureCommande.MODIFICATION_PFI.name());

    PFI pfi = new PFI();
    SA saSource = buildSA();
    addSaToPFI(pfi, saSource);

    SA saTarget = new SA("new_noServiceAccessible", "new_noServiceCommercial", "new_nomServiceCommercial", "new_categorieServiceCommercial", null, null, null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    saTarget.setNoServiceAccessible(saSource.getNoServiceAccessible());//IDs need to be equal

    PFIComparatorUtils result = new PFIComparatorUtils();
    SAComparator comparator = new SAComparator(pfi, commande, result, LocalDateTime.now());
    comparator.compare(saSource, saTarget);

    //Check SA
    //Only the status changes (=the one in the target)
    assertEquals(Statut.ACTIF, pfi.getSa().get(0).getStatut());
    assertEquals(saTarget.getNoServiceAccessible(), pfi.getSa().get(0).getNoServiceAccessible());
    assertEquals(saTarget.getNomServiceCommercial(), pfi.getSa().get(0).getNomServiceCommercial());
    assertEquals(saTarget.getNoServiceCommercial(), pfi.getSa().get(0).getNoServiceCommercial());
    assertEquals(saTarget.getCategorieServiceCommercial(), pfi.getSa().get(0).getCategorieServiceCommercial());

    //Check ModificationCommerciale
    assertEquals(0, result.getMcList().size());

    //Check ElementComparaison
    assertEquals(TypeObjectCommercialEnum.SA.name(), result.getEcList().get(0).getTypeObjetCommercial());
    assertEquals(TypeModificationEnum.MODIF_ATTR.name(), result.getEcList().get(0).getTypeOperation());
    assertEquals(IModificationValue_Test.NO_SERVICE_ACCESSIBLE, result.getEcList().get(0).getNoServiceAccessible());
    assertEquals(3, result.getEcList().get(0).getListeAttributModifie().size());
  }

  /**
   * Deletion of a SA with Statut ACTIF<br>
   *
   * <b>Inputs:</b> SA with Statut = ACTIF <br>
   * <b>Expected:</b> The status of SA source is now RESILIE <br>
   */
  @Test
  public void testSuppressionSA_001()
  {
    Commande commande = new Commande();
    commande.setIdCmd(ID_CMD);

    PFI pfi = new PFI();
    SA saSource = buildSA();
    addSaToPFI(pfi, saSource);

    PFIComparatorUtils result = new PFIComparatorUtils();
    SAComparator comparator = new SAComparator(pfi, commande, result, LocalDateTime.now());
    comparator.compare(saSource, null);

    //Check SA
    assertEquals(Arrays.asList(saSource), pfi.getSa());
    assertEquals(Statut.RESILIE, pfi.getSa().get(0).getStatut());

    //Check ModificationCommercial
    assertEquals(commande.getIdCmd(), result.getMcList().get(0).getIdCmd());
    assertEquals(AbstractComparator.EN_COURS, result.getMcList().get(0).getStatut());
    assertEquals(TypeObjectCommercialEnum.SA.name(), result.getMcList().get(0).getTypeObjetCommercial());
    assertEquals(pfi.getNoCompte(), result.getMcList().get(0).getNoCompte());
    assertEquals(pfi.getClientOperateur(), result.getMcList().get(0).getClientOperateur());
    assertEquals(saSource.getNoServiceAccessible(), result.getMcList().get(0).getNoServiceAccessible());
    assertEquals(Statut.RESILIE.name(), result.getMcList().get(0).getStatutCommercialAttendu());

    //Check ElementComparaison
    assertEquals(TypeObjectCommercialEnum.SA.name(), result.getEcList().get(0).getTypeObjetCommercial());
    assertEquals(TypeModificationEnum.SUPPRESSION.name(), result.getEcList().get(0).getTypeOperation());
    assertEquals(IModificationValue_Test.NO_SERVICE_ACCESSIBLE, result.getEcList().get(0).getNoServiceAccessible());
    assertEquals(0, result.getEcList().get(0).getListeAttributModifie().size());
  }

  /**
   * Deletion of a SA with Statut RESILIE<br>
   *
   * <b>Inputs:</b> SA with Statut = RESILIE <br>
   * <b>Expected:</b> The SA source stays the sames <br>
   */
  @Test
  public void testSuppressionSA_002()
  {
    Commande commande = new Commande();
    PFI pfi = new PFI();
    SA saSource = buildSA();
    saSource.setStatut(Statut.RESILIE);
    addSaToPFI(pfi, saSource);

    PFIComparatorUtils result = new PFIComparatorUtils();
    SAComparator comparator = new SAComparator(pfi, commande, result, LocalDateTime.now());
    comparator.compare(saSource, null);

    assertEquals(Arrays.asList(saSource), pfi.getSa());

    assertTrue(result.getMcList().isEmpty());
    assertTrue(result.getEcList().isEmpty());
  }

  /**
   * @param pfi
   * @param saSource
   */
  private void addSaToPFI(PFI pfi, SA saSource)
  {
    List<SA> listeSA = pfi.getSa();
    listeSA.add(saSource);
    pfi.setSa(listeSA);
  }

}
