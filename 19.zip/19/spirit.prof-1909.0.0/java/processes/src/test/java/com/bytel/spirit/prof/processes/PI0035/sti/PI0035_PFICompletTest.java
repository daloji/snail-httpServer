/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PI0035.sti;

import static org.apache.commons.lang3.StringUtils.isBlank;
import static org.junit.Assert.assertEquals;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.validation.ConstraintViolation;

import org.easymock.EasyMockSupport;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.bytel.ravel.common.datetime.DateTimeManager;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.spirit.common.shared.misc.validation.IValidationConst;
import com.bytel.spirit.common.shared.saab.rpg.EquipementDeclare;
import com.bytel.spirit.common.shared.saab.rpg.LienEquipementPA;
import com.bytel.spirit.common.shared.saab.rpg.LienSAPA;
import com.bytel.spirit.common.shared.saab.rpg.PA;
import com.bytel.spirit.common.shared.saab.rpg.PFI;
import com.bytel.spirit.common.shared.saab.rpg.PaTypeCompteAcces;
import com.bytel.spirit.common.shared.saab.rpg.SA;
import com.bytel.spirit.common.shared.saab.rpg.Statut;
import com.bytel.spirit.common.shared.saab.rpg.Titulaire;
import com.bytel.spirit.common.shared.saab.rpg.TypePA;
import com.bytel.spirit.common.shared.saab.rpg.TypeTitulaire;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author jiantila
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({ PI0035_PFIComplet.class })
public class PI0035_PFICompletTest extends EasyMockSupport
{
  /**
  *
  */
  public static final String VALUE_AUTHORIZED = IValidationConst.FORMAT_ATTRIBUT_NON_RESPECTE;
  /**
  *
  */
  public static final String CONDITIONAL = IValidationConst.ATTRIBUT_COND_INATTENDU;

  /**
  *
  */
  public static final String MANDATORY = IValidationConst.ATTRIBUT_OBLIGATOIRE_MANQUANT;
  /**
   * Factory de génération des beans
   */
  private static PodamFactory __podam = new PodamFactoryImpl();

  /**
   * Initialize before all tests
   */
  @BeforeClass
  public static void setUpBeforeClass()
  {
    // désactivation du cache podam
    __podam.getStrategy().setMemoization(false);
    __podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());
  }

  /**
   * @param constraintValidation_p
   * @return
   */
  public String getNameConstraint(final ConstraintViolation<?> constraintValidation_p)
  {
    return Stream.of(constraintValidation_p.getRootBeanClass().getSimpleName(), constraintValidation_p.getPropertyPath().toString()).filter(s -> !isBlank(s)).collect(Collectors.joining(".")); //$NON-NLS-1$
  }

  /**
   * verification buildFromPFI
   */
  @Test
  public void PI0035_PFICompletTest_003_OK()
  {
    //PI0035_PFIComplet pficomplet = new PI0035_PFIComplet();
    PFI pfi = new PFI();
    SA sa = new SA();
    LocalDateTime local = DateTimeManager.getInstance().now();
    sa.setCategorieServiceCommercial("categorie"); //$NON-NLS-1$
    sa.setDateCreation(local);
    sa.setDateModification(local);
    sa.setNomServiceCommercial("nomServiceCommercial"); //$NON-NLS-1$
    sa.setNoServiceAccessible("noServiceAccessible");//$NON-NLS-1$
    sa.setNoServiceCommercial("noServiceCommercial");//$NON-NLS-1$
    sa.setStatut(Statut.ACTIF);
    List<SA> listsa = new ArrayList<>();
    listsa.add(sa);
    pfi.setSa(listsa);
    Titulaire titulaire = new Titulaire(TypeTitulaire.ENTREPRISE, "noPersonne", local, local);//$NON-NLS-1$
    com.bytel.spirit.common.shared.saab.rpg.Entreprise entreprise = new com.bytel.spirit.common.shared.saab.rpg.Entreprise("siren", "raisonSocial"); //$NON-NLS-1$ //$NON-NLS-2$
    titulaire.setEntreprise(entreprise);
    pfi.setTitulaire(titulaire);
    pfi.setStatut(Statut.RESILIE);
    PI0035_PFIComplet pficomplet = PI0035_PFIComplet.buildFromPFI(pfi);
    assertEquals(pficomplet.getSa().size(), 1);
    assertEquals(pficomplet.getEqtDeclare().size(), 0);
    assertEquals(pficomplet.getIndexRecherche().size(), 0);
    assertEquals(pficomplet.getLienSaPa().size(), 0);
    assertEquals(pficomplet.getLienEqtPa().size(), 0);
    assertEquals(pficomplet.getPa().size(), 0);
    assertEquals(pficomplet.getSt().size(), 0);
  }

  /**
   * verification buildFromPFI
   */
  @Test
  public void PI0035_PFICompletTest_004_OK()
  {
    //PI0035_PFIComplet pficomplet = new PI0035_PFIComplet();
    PFI pfi = new PFI();
    SA sa = new SA();
    LocalDateTime local = DateTimeManager.getInstance().now();
    sa.setCategorieServiceCommercial("categorie"); //$NON-NLS-1$
    sa.setDateCreation(local);
    sa.setDateModification(local);
    sa.setNomServiceCommercial("nomServiceCommercial"); //$NON-NLS-1$
    sa.setNoServiceAccessible("noServiceAccessible");//$NON-NLS-1$
    sa.setNoServiceCommercial("noServiceCommercial");//$NON-NLS-1$
    sa.setStatut(Statut.ACTIF);
    List<SA> listsa = new ArrayList<>();
    listsa.add(sa);
    pfi.setSa(listsa);
    Titulaire titulaire = new Titulaire(TypeTitulaire.ENTREPRISE, "noPersonne", local, local);//$NON-NLS-1$
    com.bytel.spirit.common.shared.saab.rpg.Entreprise entreprise = new com.bytel.spirit.common.shared.saab.rpg.Entreprise("siren", "raisonSocial"); //$NON-NLS-1$ //$NON-NLS-2$
    titulaire.setEntreprise(entreprise);
    pfi.setTitulaire(titulaire);
    pfi.setStatut(Statut.RESILIE);
    PA pa = new PA("identifiantFonctionnelPA", TypePA.COMPTE_ACCES.name(), Statut.ACTIF, local, local); //$NON-NLS-1$
    PaTypeCompteAcces patype = new PaTypeCompteAcces("emailLogin"); //$NON-NLS-1$
    pa.setPaTypeCompteAcces(patype);
    List<PA> listpa = new ArrayList<>();
    listpa.add(pa);
    pfi.setPa(listpa);

    PI0035_PFIComplet pficomplet = PI0035_PFIComplet.buildFromPFI(pfi);
    assertEquals(pficomplet.getSa().size(), 1);
    assertEquals(pficomplet.getPa().size(), 1);
    assertEquals(pficomplet.getEqtDeclare().size(), 0);
    assertEquals(pficomplet.getIndexRecherche().size(), 0);
    assertEquals(pficomplet.getLienSaPa().size(), 0);
    assertEquals(pficomplet.getLienEqtPa().size(), 0);

    assertEquals(pficomplet.getSt().size(), 0);
  }

  /**
   * verification buildFromPFI
   */
  @Test
  public void PI0035_PFICompletTest_005_OK()
  {
    //PI0035_PFIComplet pficomplet = new PI0035_PFIComplet();
    PFI pfi = new PFI();
    SA sa = new SA();
    LocalDateTime local = DateTimeManager.getInstance().now();
    sa.setCategorieServiceCommercial("categorie"); //$NON-NLS-1$
    sa.setDateCreation(local);
    sa.setDateModification(local);
    sa.setNomServiceCommercial("nomServiceCommercial"); //$NON-NLS-1$
    sa.setNoServiceAccessible("noServiceAccessible");//$NON-NLS-1$
    sa.setNoServiceCommercial("noServiceCommercial");//$NON-NLS-1$
    sa.setStatut(Statut.ACTIF);
    List<SA> listsa = new ArrayList<>();
    listsa.add(sa);
    pfi.setSa(listsa);
    Titulaire titulaire = new Titulaire(TypeTitulaire.ENTREPRISE, "noPersonne", local, local);//$NON-NLS-1$
    com.bytel.spirit.common.shared.saab.rpg.Entreprise entreprise = new com.bytel.spirit.common.shared.saab.rpg.Entreprise("siren", "raisonSocial"); //$NON-NLS-1$ //$NON-NLS-2$
    titulaire.setEntreprise(entreprise);
    pfi.setTitulaire(titulaire);
    pfi.setStatut(Statut.RESILIE);
    PA pa = new PA("identifiantFonctionnelPA", TypePA.COMPTE_ACCES.name(), Statut.ACTIF, local, local); //$NON-NLS-1$
    PaTypeCompteAcces patype = new PaTypeCompteAcces("emailLogin"); //$NON-NLS-1$
    pa.setPaTypeCompteAcces(patype);
    List<PA> listpa = new ArrayList<>();
    listpa.add(pa);
    pfi.setPa(listpa);
    EquipementDeclare equiptdecl = new EquipementDeclare("noEquipement", "noIdentifiant", "typeEquipement", Statut.ACTIF, local, local); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    List<EquipementDeclare> listeqtDeclareList = new ArrayList<>();
    listeqtDeclareList.add(equiptdecl);
    pfi.setEquipementDeclare(listeqtDeclareList);
    PI0035_PFIComplet pficomplet = PI0035_PFIComplet.buildFromPFI(pfi);
    assertEquals(pficomplet.getSa().size(), 1);
    assertEquals(pficomplet.getPa().size(), 1);
    assertEquals(pficomplet.getEqtDeclare().size(), 1);
    assertEquals(pficomplet.getIndexRecherche().size(), 0);
    assertEquals(pficomplet.getLienSaPa().size(), 0);
    assertEquals(pficomplet.getLienEqtPa().size(), 0);

    assertEquals(pficomplet.getSt().size(), 0);
  }

  /**
   * verification buildFromPFI
   */
  @Test
  public void PI0035_PFICompletTest_006_OK()
  {
    //PI0035_PFIComplet pficomplet = new PI0035_PFIComplet();
    PFI pfi = new PFI();
    SA sa = new SA();
    LocalDateTime local = DateTimeManager.getInstance().now();
    sa.setCategorieServiceCommercial("categorie"); //$NON-NLS-1$
    sa.setDateCreation(local);
    sa.setDateModification(local);
    sa.setNomServiceCommercial("nomServiceCommercial"); //$NON-NLS-1$
    sa.setNoServiceAccessible("noServiceAccessible");//$NON-NLS-1$
    sa.setNoServiceCommercial("noServiceCommercial");//$NON-NLS-1$
    sa.setStatut(Statut.ACTIF);
    List<SA> listsa = new ArrayList<>();
    listsa.add(sa);
    pfi.setSa(listsa);
    Titulaire titulaire = new Titulaire(TypeTitulaire.ENTREPRISE, "noPersonne", local, local);//$NON-NLS-1$
    com.bytel.spirit.common.shared.saab.rpg.Entreprise entreprise = new com.bytel.spirit.common.shared.saab.rpg.Entreprise("siren", "raisonSocial"); //$NON-NLS-1$ //$NON-NLS-2$
    titulaire.setEntreprise(entreprise);
    pfi.setTitulaire(titulaire);
    pfi.setStatut(Statut.RESILIE);
    PA pa = new PA("identifiantFonctionnelPA", TypePA.COMPTE_ACCES.name(), Statut.ACTIF, local, local); //$NON-NLS-1$
    PaTypeCompteAcces patype = new PaTypeCompteAcces("emailLogin"); //$NON-NLS-1$
    pa.setPaTypeCompteAcces(patype);
    List<PA> listpa = new ArrayList<>();
    listpa.add(pa);
    pfi.setPa(listpa);
    EquipementDeclare equiptdecl = new EquipementDeclare("noEquipement", "noIdentifiant", "typeEquipement", Statut.ACTIF, local, local); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    List<EquipementDeclare> listeqtDeclareList = new ArrayList<>();
    listeqtDeclareList.add(equiptdecl);
    pfi.setEquipementDeclare(listeqtDeclareList);
    LienSAPA liensapa = new LienSAPA("noServiceAccessible", "identifiantFonctionnelPA", Statut.ACTIF, local, local); //$NON-NLS-1$ //$NON-NLS-2$
    List<LienSAPA> listlien = new ArrayList<>();
    listlien.add(liensapa);
    pfi.setLienSAPA(listlien);
    PI0035_PFIComplet pficomplet = PI0035_PFIComplet.buildFromPFI(pfi);
    assertEquals(pficomplet.getSa().size(), 1);
    assertEquals(pficomplet.getPa().size(), 1);
    assertEquals(pficomplet.getEqtDeclare().size(), 1);
    assertEquals(pficomplet.getLienSaPa().size(), 1);
    assertEquals(pficomplet.getIndexRecherche().size(), 0);
    assertEquals(pficomplet.getLienEqtPa().size(), 0);
    assertEquals(pficomplet.getSt().size(), 0);
  }

  /**
   * verification buildFromPFI
   */
  @Test
  public void PI0035_PFICompletTest_007_OK()
  {
    //PI0035_PFIComplet pficomplet = new PI0035_PFIComplet();
    PFI pfi = new PFI();
    SA sa = new SA();
    LocalDateTime local = DateTimeManager.getInstance().now();
    sa.setCategorieServiceCommercial("categorie"); //$NON-NLS-1$
    sa.setDateCreation(local);
    sa.setDateModification(local);
    sa.setNomServiceCommercial("nomServiceCommercial"); //$NON-NLS-1$
    sa.setNoServiceAccessible("noServiceAccessible");//$NON-NLS-1$
    sa.setNoServiceCommercial("noServiceCommercial");//$NON-NLS-1$
    sa.setStatut(Statut.ACTIF);
    List<SA> listsa = new ArrayList<>();
    listsa.add(sa);
    pfi.setSa(listsa);
    Titulaire titulaire = new Titulaire(TypeTitulaire.ENTREPRISE, "noPersonne", local, local);//$NON-NLS-1$
    com.bytel.spirit.common.shared.saab.rpg.Entreprise entreprise = new com.bytel.spirit.common.shared.saab.rpg.Entreprise("siren", "raisonSocial"); //$NON-NLS-1$ //$NON-NLS-2$
    titulaire.setEntreprise(entreprise);
    pfi.setTitulaire(titulaire);
    pfi.setStatut(Statut.RESILIE);
    PA pa = new PA("identifiantFonctionnelPA", TypePA.COMPTE_ACCES.name(), Statut.ACTIF, local, local); //$NON-NLS-1$
    PaTypeCompteAcces patype = new PaTypeCompteAcces("emailLogin"); //$NON-NLS-1$
    pa.setPaTypeCompteAcces(patype);
    List<PA> listpa = new ArrayList<>();
    listpa.add(pa);
    pfi.setPa(listpa);
    EquipementDeclare equiptdecl = new EquipementDeclare("noEquipement", "noIdentifiant", "typeEquipement", Statut.ACTIF, local, local); //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$
    List<EquipementDeclare> listeqtDeclareList = new ArrayList<>();
    listeqtDeclareList.add(equiptdecl);
    pfi.setEquipementDeclare(listeqtDeclareList);
    LienSAPA liensapa = new LienSAPA("noServiceAccessible", "identifiantFonctionnelPA", Statut.ACTIF, local, local); //$NON-NLS-1$ //$NON-NLS-2$
    List<LienSAPA> listlien = new ArrayList<>();
    listlien.add(liensapa);
    pfi.setLienSAPA(listlien);
    LienEquipementPA lienequipPA = new LienEquipementPA("noEquipement", "idFonctionnelPa", Statut.ACTIF, local, local); //$NON-NLS-1$ //$NON-NLS-2$
    List<LienEquipementPA> listlienequipPA = new ArrayList<>();
    listlienequipPA.add(lienequipPA);
    pfi.setLienEquipementPA(listlienequipPA);

    PI0035_PFIComplet pficomplet = PI0035_PFIComplet.buildFromPFI(pfi);
    assertEquals(pficomplet.getSa().size(), 1);
    assertEquals(pficomplet.getPa().size(), 1);
    assertEquals(pficomplet.getEqtDeclare().size(), 1);
    assertEquals(pficomplet.getLienSaPa().size(), 1);
    assertEquals(pficomplet.getIndexRecherche().size(), 0);
    assertEquals(pficomplet.getLienEqtPa().size(), 1);
    assertEquals(pficomplet.getSt().size(), 0);
  }
}
