package com.bytel.spirit.prof.processes.PE0142;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PowerMockListener;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.testlisteners.FieldDefaulter;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.modules.junit4.PowerMockRunnerDelegate;
import org.springframework.test.context.ContextConfiguration;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.data.exchange.generated.RavelRequest.RequestHeader;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.response.IRavelResponse;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.test.podam.JavaTimeManufacturer;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.test.podam.PodamBytelJUnit4ClassRunner;
import com.bytel.ravel.common.utils.DateTimeTools.DateTimeFormatPattern;
import com.bytel.ravel.common.utils.RetourFactoryForTU;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.ProcessManager;
import com.bytel.spirit.common.activities.shared.BL4600_CreerErreurSpirit;
import com.bytel.spirit.common.activities.shared.BL4600_CreerErreurSpirit.BL4600_CreerErreurSpiritBuilder;
import com.bytel.spirit.common.activities.shared.BL800_ObtenirSequence;
import com.bytel.spirit.common.activities.shared.BL800_ObtenirSequence.BL800_ObtenirSequenceBuilder;
import com.bytel.spirit.common.activities.shared.structs.UniqueIdConstant;
import com.bytel.spirit.common.connectors.cmd.CMDProxy;
import com.bytel.spirit.common.connectors.ink.ResponseConnector;
import com.bytel.spirit.common.connectors.ink.activities.PROV_SI001_LancerOrchestrateur;
import com.bytel.spirit.common.connectors.ink.activities.PROV_SI001_LancerOrchestrateur.PROV_SI001_LancerOrchestrateurBuilder;
import com.bytel.spirit.common.connectors.rex.REXProxy;
import com.bytel.spirit.common.connectors.rpg.RPGProxy;
import com.bytel.spirit.common.shared.misc.error.ReponseErreur;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.cmd.request.CreateCommandeRequest;
import com.bytel.spirit.common.shared.saab.rex.request.CreateErreurSpiritRequest;
import com.bytel.spirit.common.shared.saab.rpg.PA;
import com.bytel.spirit.common.shared.saab.rpg.PFI;
import com.bytel.spirit.common.shared.saab.rpg.PaTypeCompteAcces;
import com.bytel.spirit.common.shared.saab.rpg.Statut;
import com.bytel.spirit.common.shared.types.json.request.ServiceMailRequest;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author jgregori
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PowerMockListener(FieldDefaulter.class)
@PowerMockRunnerDelegate(PodamBytelJUnit4ClassRunner.class)
@ContextConfiguration("classpath:BeansProcessTestMocks.xml")
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
@PrepareForTest({ PEI0142_CreerCommandeTransfertBoiteMailSecondaire.class, Request.class, PROV_SI001_LancerOrchestrateur.class, PROV_SI001_LancerOrchestrateurBuilder.class, BL800_ObtenirSequenceBuilder.class, BL800_ObtenirSequence.class, BL4600_CreerErreurSpirit.class, BL4600_CreerErreurSpiritBuilder.class, RPGProxy.class, CMDProxy.class, REXProxy.class })
public class PEI0142_CreerCommandeTransfertBoiteMailSecondaireTest
{
  /**
   * Podam instance
   */
  private static PodamFactory __podam;

  /**
   * ID_ERREUR_SPIRIT constant
   */
  private static final String ID_ERREUR_SPIRIT = "f42482fb-f6a3-4a2c-b5d3-2e5949be0d02"; //$NON-NLS-1$

  /**
   * Run before tests
   *
   * @throws Exception
   *           throw exception
   */
  @BeforeClass
  public static void setUpBeforeClass() throws Exception
  {
    __podam = new PodamFactoryImpl();
    __podam.getStrategy().setMemoization(false);
    __podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());
    JavaTimeManufacturer.registerPodamFactory(__podam);
  }

  /**
   *
   */
  @MockStrict
  private PROV_SI001_LancerOrchestrateurBuilder _provLancerBuilder;

  /**
   *
   */
  @MockStrict
  private PROV_SI001_LancerOrchestrateur _provLancer;

  /**
   *
   */
  @MockStrict
  private RPGProxy _rpgDatabaseProxy;

  /**
   *
   */
  @MockStrict
  private CMDProxy _cmdProxy;

  /**
  *
  */
  @MockStrict
  private REXProxy _rexProxy;

  /**
   *
   */
  @MockStrict
  private BL800_ObtenirSequenceBuilder _bl800BuilderMock;

  /**
   *
   */
  @MockStrict
  private BL800_ObtenirSequence _bl800Mock;

  /**
   *
   */
  @Before
  public void initAllConfiguration()
  {
    PowerMock.resetAll();
    PowerMock.mockStatic(RPGProxy.class);
    PowerMock.mockStatic(CMDProxy.class);
    PowerMock.mockStatic(REXProxy.class);
    PowerMock.mockStatic(BL800_ObtenirSequence.class);
    PowerMock.mockStatic(BL800_ObtenirSequenceBuilder.class);
    PowerMock.mockStatic(PROV_SI001_LancerOrchestrateurBuilder.class);
    PowerMock.mockStatic(PROV_SI001_LancerOrchestrateur.class);

  }

  /**
   * Tests non nominal case. The required field IdentifiantAccesCible is not set. Assert that validation errors exist.
   *
   * @throws Throwable
   *           exception
   */
  @Test
  public void PEI0142_BL001_VerifierDonnes_Test_KO_01() throws Throwable
  {
    Tracabilite tracabilite = new Tracabilite();
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    List<RequestHeader> headers = new ArrayList<>();
    RequestHeader xClientOperateur = new RequestHeader();
    xClientOperateur.setName("X-Client-Operateur"); //$NON-NLS-1$
    xClientOperateur.setValue("BSS_GP"); //$NON-NLS-1$
    headers.add(xClientOperateur);
    RequestHeader xRequestId = new RequestHeader();
    xRequestId.setName("X-Request-Id"); //$NON-NLS-1$
    xRequestId.setValue("354545435"); //$NON-NLS-1$
    headers.add(xRequestId);
    RequestHeader xSource = new RequestHeader();
    xSource.setName("X-Source"); //$NON-NLS-1$
    xSource.setValue("SPIRIT"); //$NON-NLS-1$
    headers.add(xSource);
    RequestHeader xMessageId = new RequestHeader();
    xMessageId.setName("X-Message-Id"); //$NON-NLS-1$
    xMessageId.setValue("MessageID123"); //$NON-NLS-1$
    headers.add(xMessageId);
    RequestHeader xProcess = new RequestHeader();
    xProcess.setName("X-Process"); //$NON-NLS-1$
    xProcess.setValue("PROCESSUS TAKEOVER"); //$NON-NLS-1$
    headers.add(xProcess);
    request.getRequestHeader().addAll(headers);

    request.setHttpMethod("POST"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    ServiceMailRequest mailRequest = buildValidServiceMailRequest();
    mailRequest.setIdentifiantAccesCible(null); //set null identifiantAccessCible to cause a validation error

    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(mailRequest, ServiceMailRequest.class);

    request.setPayload(jSonRequest);
    PEI0142_CreerCommandeTransfertBoiteMailSecondaire pei0142 = new PEI0142_CreerCommandeTransfertBoiteMailSecondaire();

    PowerMock.expectNew(BL800_ObtenirSequenceBuilder.class).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.code(UniqueIdConstant.ID_ERREUR_SPIRIT)).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.build()).andReturn(_bl800Mock);
    EasyMock.expect(_bl800Mock.execute(pei0142)).andReturn(ID_ERREUR_SPIRIT);
    EasyMock.expect(_bl800Mock.getRetour()).andReturn(RetourFactoryForTU.createOkRetour());

    // Mock configuration ProcessusManager
    HashMap<String, String> map = new HashMap<>();
    map.put("declenchementPEP", "true"); //$NON-NLS-1$ //$NON-NLS-2$
    ConcurrentHashMap<String, Map<String, String>> processParams = new ConcurrentHashMap<>();
    processParams.put(StringConstants.EMPTY_STRING, map);
    ProcessManager.getInstance().getProcessParams().clear();
    ProcessManager.getInstance().getProcessParams().putAll(processParams);

    PowerMock.replayAll();
    pei0142.initializeContext();
    pei0142.run(request);
    pei0142.continueProcess(request, tracabilite);
    PowerMock.verify();
    IRavelResponse response = request.getResponse();

    assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    ReponseErreur error = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ, DateTimeFormatPattern.yyyy_dash_MM_dash_dd).fromJson(response.getGenericResponse().getResult(), ReponseErreur.class);
    assertEquals(IMegSpiritConsts.NON_RESPECT_STI, error.getError());
    assertEquals("Attribut(s) obligatoire(s) manquant(s): [_identifiantAccesCible]", error.getErrorDescription()); //$NON-NLS-1$
  }

  /**
   * Test PEI0142_BL001_VerifierDonnes cas ou le controle de la premiere PFI est en echec
   *
   * @throws Throwable
   *           exception
   */
  @Test
  public void PEI0142_BL001_VerifierDonnes_Test_KO_02() throws Throwable
  {
    String operateur = "BSS_GP"; //$NON-NLS-1$
    String numCompte = "3594886"; //$NON-NLS-1$
    Tracabilite tracabilite = new Tracabilite();
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    List<RequestHeader> headers = new ArrayList<>();
    RequestHeader xClientOperateur = new RequestHeader();
    xClientOperateur.setName("X-Client-Operateur"); //$NON-NLS-1$
    xClientOperateur.setValue(operateur);
    headers.add(xClientOperateur);
    RequestHeader xRequestId = new RequestHeader();
    xRequestId.setName("X-Request-Id"); //$NON-NLS-1$
    xRequestId.setValue(numCompte);
    headers.add(xRequestId);
    RequestHeader xMessageId = new RequestHeader();
    xMessageId.setName("X-Message-Id"); //$NON-NLS-1$
    xMessageId.setValue("MessageID123"); //$NON-NLS-1$
    headers.add(xMessageId);
    RequestHeader xSource = new RequestHeader();
    xSource.setName("X-Source"); //$NON-NLS-1$
    xSource.setValue("SPIRIT"); //$NON-NLS-1$
    headers.add(xSource);
    RequestHeader xProcess = new RequestHeader();
    xProcess.setName("X-Process"); //$NON-NLS-1$
    xProcess.setValue("PROCESSUS TAKEOVER"); //$NON-NLS-1$
    headers.add(xProcess);
    request.getRequestHeader().addAll(headers);
    // Mock configuration ProcessusManager
    HashMap<String, String> map = new HashMap<>();
    map.put("declenchementPEP", "true"); //$NON-NLS-1$ //$NON-NLS-2$
    ConcurrentHashMap<String, Map<String, String>> processParams = new ConcurrentHashMap<>();
    processParams.put(StringConstants.EMPTY_STRING, map);
    ProcessManager.getInstance().getProcessParams().clear();
    ProcessManager.getInstance().getProcessParams().putAll(processParams);

    PFI pfi = new PFI();
    List<PA> listpa = new ArrayList<>();
    PaTypeCompteAcces paType = new PaTypeCompteAcces("charles.rock"); //$NON-NLS-1$
    PA pa = new PA(null, "COMPTE_ACCES", Statut.ACTIF, null, null); //$NON-NLS-1$
    pa.setPaTypeCompteAcces(paType);
    listpa.add(pa);
    pfi.setPa(listpa);
    //Mock for RPGProxy OK
    createMockRPG(RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "", null), pfi, operateur, numCompte); //$NON-NLS-1$

    pfi = new PFI();
    listpa = new ArrayList<>();
    paType = new PaTypeCompteAcces("bernard.chevallier"); //$NON-NLS-1$
    pa = new PA(null, "COMPTE_ACCES", Statut.ACTIF, null, null); //$NON-NLS-1$
    pa.setPaTypeCompteAcces(paType);
    listpa.add(pa);
    pfi.setPa(listpa);

    numCompte = "76398756589"; //$NON-NLS-1$
    //Mock for RPGProxy OK
    createMockRPG(RetourFactoryForTU.createOkRetour(), pfi, operateur, numCompte);
    request.setHttpMethod("POST"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    ServiceMailRequest mailRequest = buildValidServiceMailRequest();
    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(mailRequest, ServiceMailRequest.class);

    request.setPayload(jSonRequest);
    PEI0142_CreerCommandeTransfertBoiteMailSecondaire pei0142 = new PEI0142_CreerCommandeTransfertBoiteMailSecondaire();

    PowerMock.expectNew(BL800_ObtenirSequenceBuilder.class).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.code(UniqueIdConstant.ID_ERREUR_SPIRIT)).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.build()).andReturn(_bl800Mock);
    EasyMock.expect(_bl800Mock.execute(pei0142)).andReturn(ID_ERREUR_SPIRIT);
    EasyMock.expect(_bl800Mock.getRetour()).andReturn(RetourFactoryForTU.createOkRetour());

    PowerMock.replayAll();
    pei0142.initializeContext();
    pei0142.run(request);
    pei0142.continueProcess(request, tracabilite);
    PowerMock.verify();
    IRavelResponse response = request.getResponse();

    assertEquals(ErrorCode.KO_00404, response.getErrorCode());
    ReponseErreur error = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ, DateTimeFormatPattern.yyyy_dash_MM_dash_dd).fromJson(response.getGenericResponse().getResult(), ReponseErreur.class);
    assertEquals(IMegSpiritConsts.NO_COMPTE_INCONNU, error.getError());
    assertEquals("noCompte 3594886 est inconnu", error.getErrorDescription()); //$NON-NLS-1$
  }

  /**
   * Test PEI0142_BL001_VerifierDonnes cas ou le controle de la deuxieme PFI est en echec
   *
   * @throws Throwable
   *           exception
   */
  @Test
  public void PEI0142_BL001_VerifierDonnes_Test_KO_03() throws Throwable
  {
    String operateur = "BSS_GP"; //$NON-NLS-1$
    String numCompte = "3594886"; //$NON-NLS-1$
    Tracabilite tracabilite = new Tracabilite();
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    List<RequestHeader> headers = new ArrayList<>();
    RequestHeader xClientOperateur = new RequestHeader();
    xClientOperateur.setName("X-Client-Operateur"); //$NON-NLS-1$
    xClientOperateur.setValue(operateur);
    headers.add(xClientOperateur);
    RequestHeader xRequestId = new RequestHeader();
    xRequestId.setName("X-Request-Id"); //$NON-NLS-1$
    xRequestId.setValue(numCompte);
    headers.add(xRequestId);
    RequestHeader xMessageId = new RequestHeader();
    xMessageId.setName("X-Message-Id"); //$NON-NLS-1$
    xMessageId.setValue("MessageID123"); //$NON-NLS-1$
    headers.add(xMessageId);
    RequestHeader xSource = new RequestHeader();
    xSource.setName("X-Source"); //$NON-NLS-1$
    xSource.setValue("SPIRIT"); //$NON-NLS-1$
    headers.add(xSource);
    RequestHeader xProcess = new RequestHeader();
    xProcess.setName("X-Process"); //$NON-NLS-1$
    xProcess.setValue("PROCESSUS TAKEOVER"); //$NON-NLS-1$
    headers.add(xProcess);
    request.getRequestHeader().addAll(headers);

    // Mock configuration ProcessusManager
    HashMap<String, String> map = new HashMap<>();
    map.put("declenchementPEP", "true"); //$NON-NLS-1$ //$NON-NLS-2$
    ConcurrentHashMap<String, Map<String, String>> processParams = new ConcurrentHashMap<>();
    processParams.put(StringConstants.EMPTY_STRING, map);
    ProcessManager.getInstance().getProcessParams().clear();
    ProcessManager.getInstance().getProcessParams().putAll(processParams);

    PFI pfi = new PFI();
    List<PA> listpa = new ArrayList<>();
    PaTypeCompteAcces paType = new PaTypeCompteAcces("charles.rock"); //$NON-NLS-1$
    PA pa = new PA(null, "COMPTE_ACCES", Statut.ACTIF, null, null); //$NON-NLS-1$
    pa.setPaTypeCompteAcces(paType);
    listpa.add(pa);
    pfi.setPa(listpa);
    //Mock for RPGProxy OK
    createMockRPG(RetourFactoryForTU.createOkRetour(), pfi, operateur, numCompte);
    pfi = new PFI();
    listpa = new ArrayList<>();
    paType = new PaTypeCompteAcces("bernard.chevallier"); //$NON-NLS-1$
    pa = new PA(null, "COMPTE_ACCES", Statut.ACTIF, null, null); //$NON-NLS-1$
    pa.setPaTypeCompteAcces(paType);
    listpa.add(pa);
    pfi.setPa(listpa);

    numCompte = "76398756589"; //$NON-NLS-1$
    //Mock for RPGProxy OK
    createMockRPG(RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "", null), pfi, operateur, numCompte); //$NON-NLS-1$
    request.setHttpMethod("POST"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    ServiceMailRequest mailRequest = buildValidServiceMailRequest();
    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(mailRequest, ServiceMailRequest.class);

    request.setPayload(jSonRequest);
    PEI0142_CreerCommandeTransfertBoiteMailSecondaire pei0142 = new PEI0142_CreerCommandeTransfertBoiteMailSecondaire();

    PowerMock.expectNew(BL800_ObtenirSequenceBuilder.class).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.code(UniqueIdConstant.ID_ERREUR_SPIRIT)).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.build()).andReturn(_bl800Mock);
    EasyMock.expect(_bl800Mock.execute(pei0142)).andReturn(ID_ERREUR_SPIRIT);
    EasyMock.expect(_bl800Mock.getRetour()).andReturn(RetourFactoryForTU.createOkRetour());

    PowerMock.replayAll();
    pei0142.initializeContext();
    pei0142.run(request);
    pei0142.continueProcess(request, tracabilite);
    PowerMock.verify();
    IRavelResponse response = request.getResponse();

    assertEquals(ErrorCode.KO_00404, response.getErrorCode());
    ReponseErreur error = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ, DateTimeFormatPattern.yyyy_dash_MM_dash_dd).fromJson(response.getGenericResponse().getResult(), ReponseErreur.class);
    assertEquals(IMegSpiritConsts.NO_COMPTE_INCONNU, error.getError());
    assertEquals("noCompte 76398756589 est inconnu", error.getErrorDescription()); //$NON-NLS-1$
  }

  /**
   * Test PEI0142_BL001_VerifierDonnes cas ou le controle de l'existence d'un PA_COMPTE_ACCES avec EMAIL sur chaque PFI
   * PA doit être [TYPE=COMPTE_ACEES ,STATUT=ACTIF ,login = email] (Echec de la premiere PA STATUT = RESILIE)
   *
   * @throws Throwable
   *           exception
   */
  @Test
  public void PEI0142_BL001_VerifierDonnes_Test_KO_04() throws Throwable
  {
    String operateur = "BSS_GP"; //$NON-NLS-1$
    String numCompte = "3594886"; //$NON-NLS-1$
    Tracabilite tracabilite = new Tracabilite();
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    List<RequestHeader> headers = new ArrayList<>();
    RequestHeader xClientOperateur = new RequestHeader();
    xClientOperateur.setName("X-Client-Operateur"); //$NON-NLS-1$
    xClientOperateur.setValue(operateur);
    headers.add(xClientOperateur);
    RequestHeader xRequestId = new RequestHeader();
    xRequestId.setName("X-Request-Id"); //$NON-NLS-1$
    xRequestId.setValue(numCompte);
    headers.add(xRequestId);
    RequestHeader xMessageId = new RequestHeader();
    xMessageId.setName("X-Message-Id"); //$NON-NLS-1$
    xMessageId.setValue("MessageID123"); //$NON-NLS-1$
    headers.add(xMessageId);
    RequestHeader xSource = new RequestHeader();
    xSource.setName("X-Source"); //$NON-NLS-1$
    xSource.setValue("SPIRIT"); //$NON-NLS-1$
    headers.add(xSource);
    RequestHeader xProcess = new RequestHeader();
    xProcess.setName("X-Process"); //$NON-NLS-1$
    xProcess.setValue("PROCESSUS TAKEOVER"); //$NON-NLS-1$
    headers.add(xProcess);
    request.getRequestHeader().addAll(headers);

    // Mock configuration ProcessusManager
    HashMap<String, String> map = new HashMap<>();
    map.put("declenchementPEP", "true"); //$NON-NLS-1$ //$NON-NLS-2$
    ConcurrentHashMap<String, Map<String, String>> processParams = new ConcurrentHashMap<>();
    processParams.put(StringConstants.EMPTY_STRING, map);
    ProcessManager.getInstance().getProcessParams().clear();
    ProcessManager.getInstance().getProcessParams().putAll(processParams);

    PFI pfi = new PFI();
    List<PA> listpa = new ArrayList<>();
    PaTypeCompteAcces paType = new PaTypeCompteAcces("charles.rock"); //$NON-NLS-1$
    PA pa = new PA(null, "COMPTE_ACCES", Statut.RESILIE, null, null); //$NON-NLS-1$
    pa.setPaTypeCompteAcces(paType);
    listpa.add(pa);
    pfi.setPa(listpa);
    //Mock for RPGProxy OK
    createMockRPG(RetourFactoryForTU.createOkRetour(), pfi, operateur, numCompte);
    pfi = new PFI();
    listpa = new ArrayList<>();
    paType = new PaTypeCompteAcces("bernard.chevallier"); //$NON-NLS-1$
    pa = new PA(null, "COMPTE_ACCES", Statut.RESILIE, null, null); //$NON-NLS-1$
    pa.setPaTypeCompteAcces(paType);
    listpa.add(pa);
    pfi.setPa(listpa);

    numCompte = "76398756589"; //$NON-NLS-1$
    //Mock for RPGProxy OK
    createMockRPG(RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "", null), pfi, operateur, numCompte); //$NON-NLS-1$
    request.setHttpMethod("POST"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    ServiceMailRequest mailRequest = buildValidServiceMailRequest();
    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(mailRequest, ServiceMailRequest.class);

    request.setPayload(jSonRequest);
    PEI0142_CreerCommandeTransfertBoiteMailSecondaire pei0142 = new PEI0142_CreerCommandeTransfertBoiteMailSecondaire();

    PowerMock.expectNew(BL800_ObtenirSequenceBuilder.class).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.code(UniqueIdConstant.ID_ERREUR_SPIRIT)).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.build()).andReturn(_bl800Mock);
    EasyMock.expect(_bl800Mock.execute(pei0142)).andReturn(ID_ERREUR_SPIRIT);
    EasyMock.expect(_bl800Mock.getRetour()).andReturn(RetourFactoryForTU.createOkRetour());

    PowerMock.replayAll();
    pei0142.initializeContext();
    pei0142.run(request);
    pei0142.continueProcess(request, tracabilite);
    PowerMock.verify();
    IRavelResponse response = request.getResponse();

    assertEquals(ErrorCode.KO_00404, response.getErrorCode());
    ReponseErreur error = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ, DateTimeFormatPattern.yyyy_dash_MM_dash_dd).fromJson(response.getGenericResponse().getResult(), ReponseErreur.class);
    assertEquals(IMegSpiritConsts.MAIL_INCONNU, error.getError());
    assertEquals("Mail charles.rock est inconnu", error.getErrorDescription()); //$NON-NLS-1$
  }

  /**
   * Test PEI0142_BL001_VerifierDonnes cas ou le controle de l'existence d'un PA_COMPTE_ACCES avec EMAIL sur chaque PFI
   * PA doit être [TYPE=COMPTE_ACEES ,STATUT=ACTIF ,login = email] (Echec de la deuxieme PA STATUT = RESILIE)
   *
   * @throws Throwable
   *           exception
   */
  @Test
  public void PEI0142_BL001_VerifierDonnes_Test_KO_05() throws Throwable
  {
    String operateur = "BSS_GP"; //$NON-NLS-1$
    String numCompte = "3594886"; //$NON-NLS-1$
    Tracabilite tracabilite = new Tracabilite();
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    List<RequestHeader> headers = new ArrayList<>();
    RequestHeader xClientOperateur = new RequestHeader();
    xClientOperateur.setName("X-Client-Operateur"); //$NON-NLS-1$
    xClientOperateur.setValue(operateur);
    headers.add(xClientOperateur);
    RequestHeader xRequestId = new RequestHeader();
    xRequestId.setName("X-Request-Id"); //$NON-NLS-1$
    xRequestId.setValue(numCompte);
    headers.add(xRequestId);
    RequestHeader xSource = new RequestHeader();
    xSource.setName("X-Source"); //$NON-NLS-1$
    xSource.setValue("SPIRIT"); //$NON-NLS-1$
    headers.add(xSource);
    RequestHeader xMessageId = new RequestHeader();
    xMessageId.setName("X-Message-Id"); //$NON-NLS-1$
    xMessageId.setValue("MessageID123"); //$NON-NLS-1$
    headers.add(xMessageId);
    RequestHeader xProcess = new RequestHeader();
    xProcess.setName("X-Process"); //$NON-NLS-1$
    xProcess.setValue("PROCESSUS TAKEOVER"); //$NON-NLS-1$
    headers.add(xProcess);
    request.getRequestHeader().addAll(headers);
    // Mock configuration ProcessusManager
    HashMap<String, String> map = new HashMap<>();
    map.put("declenchementPEP", "true"); //$NON-NLS-1$ //$NON-NLS-2$
    ConcurrentHashMap<String, Map<String, String>> processParams = new ConcurrentHashMap<>();
    processParams.put(StringConstants.EMPTY_STRING, map);
    ProcessManager.getInstance().getProcessParams().clear();
    ProcessManager.getInstance().getProcessParams().putAll(processParams);

    PFI pfi = new PFI();
    List<PA> listpa = new ArrayList<>();
    PaTypeCompteAcces paType = new PaTypeCompteAcces("charles.rock"); //$NON-NLS-1$
    PA pa = new PA(null, "COMPTE_ACCES", Statut.ACTIF, null, null); //$NON-NLS-1$
    pa.setPaTypeCompteAcces(paType);
    listpa.add(pa);
    pfi.setPa(listpa);
    //Mock for RPGProxy OK
    createMockRPG(RetourFactoryForTU.createOkRetour(), pfi, operateur, numCompte);
    pfi = new PFI();
    listpa = new ArrayList<>();
    paType = new PaTypeCompteAcces("bernard.chevallier"); //$NON-NLS-1$
    pa = new PA(null, "COMPTE_ACCES", Statut.RESILIE, null, null); //$NON-NLS-1$
    pa.setPaTypeCompteAcces(paType);
    listpa.add(pa);
    pfi.setPa(listpa);

    numCompte = "76398756589"; //$NON-NLS-1$
    //Mock for RPGProxy OK
    createMockRPG(RetourFactoryForTU.createOkRetour(), pfi, operateur, numCompte);
    request.setHttpMethod("POST"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    ServiceMailRequest mailRequest = buildValidServiceMailRequest();
    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(mailRequest, ServiceMailRequest.class);

    request.setPayload(jSonRequest);
    PEI0142_CreerCommandeTransfertBoiteMailSecondaire pei0142 = new PEI0142_CreerCommandeTransfertBoiteMailSecondaire();

    PowerMock.expectNew(BL800_ObtenirSequenceBuilder.class).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.code(UniqueIdConstant.ID_ERREUR_SPIRIT)).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.build()).andReturn(_bl800Mock);
    EasyMock.expect(_bl800Mock.execute(pei0142)).andReturn(ID_ERREUR_SPIRIT);
    EasyMock.expect(_bl800Mock.getRetour()).andReturn(RetourFactoryForTU.createOkRetour());

    PowerMock.replayAll();
    pei0142.initializeContext();
    pei0142.run(request);
    pei0142.continueProcess(request, tracabilite);
    PowerMock.verify();
    IRavelResponse response = request.getResponse();

    assertEquals(ErrorCode.KO_00404, response.getErrorCode());
    ReponseErreur error = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ, DateTimeFormatPattern.yyyy_dash_MM_dash_dd).fromJson(response.getGenericResponse().getResult(), ReponseErreur.class);
    assertEquals(IMegSpiritConsts.MAIL_INCONNU, error.getError());
    assertEquals("Mail bernard.chevallier est inconnu", error.getErrorDescription()); //$NON-NLS-1$
  }

  /**
   * cas ou l'appel au connecteur CMD est en echec
   *
   * @throws Throwable
   *           exception
   */
  @Test
  public void PEI0142_BL100_SauvgerderCmd_Test_KO() throws Throwable
  {
    String operateur = "BSS_GP"; //$NON-NLS-1$
    String numCompte = "3594886"; //$NON-NLS-1$
    Tracabilite tracabilite = new Tracabilite();
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    List<RequestHeader> headers = new ArrayList<>();
    RequestHeader xClientOperateur = new RequestHeader();
    xClientOperateur.setName("X-Client-Operateur"); //$NON-NLS-1$
    xClientOperateur.setValue(operateur);
    headers.add(xClientOperateur);
    RequestHeader xRequestId = new RequestHeader();
    xRequestId.setName("X-Request-Id"); //$NON-NLS-1$
    xRequestId.setValue(numCompte);
    headers.add(xRequestId);
    RequestHeader xMessageId = new RequestHeader();
    xMessageId.setName("X-Message-Id"); //$NON-NLS-1$
    xMessageId.setValue("MessageID123"); //$NON-NLS-1$
    headers.add(xMessageId);
    RequestHeader xSource = new RequestHeader();
    xSource.setName("X-Source"); //$NON-NLS-1$
    xSource.setValue("SPIRIT"); //$NON-NLS-1$
    headers.add(xSource);
    RequestHeader xProcess = new RequestHeader();
    xProcess.setName("X-Process"); //$NON-NLS-1$
    xProcess.setValue("PROCESSUS TAKEOVER"); //$NON-NLS-1$
    headers.add(xProcess);
    request.getRequestHeader().addAll(headers);

    // Mock configuration ProcessusManager
    HashMap<String, String> map = new HashMap<>();
    map.put("declenchementPEP", "true"); //$NON-NLS-1$ //$NON-NLS-2$
    ConcurrentHashMap<String, Map<String, String>> processParams = new ConcurrentHashMap<>();
    processParams.put(StringConstants.EMPTY_STRING, map);
    ProcessManager.getInstance().getProcessParams().clear();
    ProcessManager.getInstance().getProcessParams().putAll(processParams);

    PFI pfi = new PFI();
    List<PA> listpa = new ArrayList<>();
    PaTypeCompteAcces paType = new PaTypeCompteAcces("charles.rock"); //$NON-NLS-1$
    PA pa = new PA(null, "COMPTE_ACCES", Statut.ACTIF, null, null); //$NON-NLS-1$
    pa.setPaTypeCompteAcces(paType);
    listpa.add(pa);
    pfi.setPa(listpa);

    createBL800(RetourFactoryForTU.createOkRetour());
    //Mock for RPGProxy
    createMockRPG(RetourFactoryForTU.createOkRetour(), pfi, operateur, numCompte);
    //Mock for CMD
    Retour retourCmd = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, "", null); //$NON-NLS-1$
    createMockCmd(retourCmd, null);
    pfi = new PFI();
    listpa = new ArrayList<>();
    paType = new PaTypeCompteAcces("bernard.chevallier"); //$NON-NLS-1$
    pa = new PA(null, "COMPTE_ACCES", Statut.ACTIF, null, null); //$NON-NLS-1$
    pa.setPaTypeCompteAcces(paType);
    listpa.add(pa);
    pfi.setPa(listpa);

    numCompte = "76398756589"; //$NON-NLS-1$
    //Mock for RPGProxy OK
    createMockRPG(RetourFactoryForTU.createOkRetour(), pfi, operateur, numCompte);
    request.setHttpMethod("POST"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    ServiceMailRequest mailRequest = buildValidServiceMailRequest();
    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(mailRequest, ServiceMailRequest.class);

    request.setPayload(jSonRequest);
    PEI0142_CreerCommandeTransfertBoiteMailSecondaire pei0142 = new PEI0142_CreerCommandeTransfertBoiteMailSecondaire();

    PowerMock.expectNew(BL800_ObtenirSequenceBuilder.class).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.code(UniqueIdConstant.ID_ERREUR_SPIRIT)).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.build()).andReturn(_bl800Mock);
    EasyMock.expect(_bl800Mock.execute(pei0142)).andReturn(ID_ERREUR_SPIRIT);
    EasyMock.expect(_bl800Mock.getRetour()).andReturn(RetourFactoryForTU.createOkRetour());

    PowerMock.replayAll();
    pei0142.initializeContext();
    pei0142.run(request);
    pei0142.continueProcess(request, tracabilite);
    PowerMock.verify();
    IRavelResponse response = request.getResponse();

    assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    assertEquals("{\"error\":\"ERREUR_INTERNE\",\"error_description\":\"\"}", response.getGenericResponse().getResult()); //$NON-NLS-1$
  }

  /**
   * erreur appel BL101 PremareCmd KO IMegConsts.CAT4, IMegSpiritConsts.CODE_SEQUENCE_INVALIDE, ""
   *
   * @throws Throwable
   *           exception
   */
  @Test
  public void PEI0142_BL101_PreparerCmd_Test_KO() throws Throwable
  {
    String operateur = "BSS_GP"; //$NON-NLS-1$
    String numCompte = "3594886"; //$NON-NLS-1$
    Tracabilite tracabilite = new Tracabilite();
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    List<RequestHeader> headers = new ArrayList<>();
    RequestHeader xClientOperateur = new RequestHeader();
    xClientOperateur.setName("X-Client-Operateur"); //$NON-NLS-1$
    xClientOperateur.setValue(operateur);
    headers.add(xClientOperateur);
    RequestHeader xRequestId = new RequestHeader();
    xRequestId.setName("X-Request-Id"); //$NON-NLS-1$
    xRequestId.setValue(numCompte);
    headers.add(xRequestId);
    RequestHeader xMessageId = new RequestHeader();
    xMessageId.setName("X-Message-Id"); //$NON-NLS-1$
    xMessageId.setValue("MessageID123"); //$NON-NLS-1$
    headers.add(xMessageId);
    RequestHeader xSource = new RequestHeader();
    xSource.setName("X-Source"); //$NON-NLS-1$
    xSource.setValue("SPIRIT"); //$NON-NLS-1$
    headers.add(xSource);
    RequestHeader xProcess = new RequestHeader();
    xProcess.setName("X-Process"); //$NON-NLS-1$
    xProcess.setValue("PROCESSUS TAKEOVER"); //$NON-NLS-1$
    headers.add(xProcess);
    request.getRequestHeader().addAll(headers);

    // Mock configuration ProcessusManager
    HashMap<String, String> map = new HashMap<>();
    map.put("declenchementPEP", "true"); //$NON-NLS-1$ //$NON-NLS-2$
    ConcurrentHashMap<String, Map<String, String>> processParams = new ConcurrentHashMap<>();
    processParams.put(StringConstants.EMPTY_STRING, map);
    ProcessManager.getInstance().getProcessParams().clear();
    ProcessManager.getInstance().getProcessParams().putAll(processParams);

    PFI pfi = new PFI();
    List<PA> listpa = new ArrayList<>();
    PaTypeCompteAcces paType = new PaTypeCompteAcces("charles.rock"); //$NON-NLS-1$
    PA pa = new PA(null, "COMPTE_ACCES", Statut.ACTIF, null, null); //$NON-NLS-1$
    pa.setPaTypeCompteAcces(paType);
    listpa.add(pa);
    pfi.setPa(listpa);
    //Mock for RPGProxy OK
    Retour bl800Retour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.CODE_SEQUENCE_INVALIDE, "", null); //$NON-NLS-1$
    createBL800(bl800Retour);
    createMockRPG(RetourFactoryForTU.createOkRetour(), pfi, operateur, numCompte);
    createMockCmd(RetourFactoryForTU.createOkRetour(), null);
    pfi = new PFI();
    listpa = new ArrayList<>();
    paType = new PaTypeCompteAcces("bernard.chevallier"); //$NON-NLS-1$
    pa = new PA(null, "COMPTE_ACCES", Statut.ACTIF, null, null); //$NON-NLS-1$
    pa.setPaTypeCompteAcces(paType);
    listpa.add(pa);
    pfi.setPa(listpa);

    numCompte = "76398756589"; //$NON-NLS-1$
    //Mock for RPGProxy OK
    createMockRPG(RetourFactoryForTU.createOkRetour(), pfi, operateur, numCompte);
    request.setHttpMethod("POST"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    ServiceMailRequest mailRequest = buildValidServiceMailRequest();
    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(mailRequest, ServiceMailRequest.class);

    request.setPayload(jSonRequest);
    PEI0142_CreerCommandeTransfertBoiteMailSecondaire pei0142 = new PEI0142_CreerCommandeTransfertBoiteMailSecondaire();

    PowerMock.expectNew(BL800_ObtenirSequenceBuilder.class).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.code(UniqueIdConstant.ID_ERREUR_SPIRIT)).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.build()).andReturn(_bl800Mock);
    EasyMock.expect(_bl800Mock.execute(pei0142)).andReturn(ID_ERREUR_SPIRIT);
    EasyMock.expect(_bl800Mock.getRetour()).andReturn(RetourFactoryForTU.createOkRetour());

    PowerMock.replayAll();
    pei0142.initializeContext();
    pei0142.run(request);
    pei0142.continueProcess(request, tracabilite);
    PowerMock.verify();
    IRavelResponse response = request.getResponse();

    assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    assertEquals("{\"error\":\"ERREUR_INTERNE\",\"error_description\":\"\"}", response.getGenericResponse().getResult()); //$NON-NLS-1$
  }

  /**
   * Test PEI0142_BL005_GererErreurPROSPER. PROV_SI001_LancerOrchestrateur return an error retour / After
   *
   * @throws Throwable
   *           exception
   */
  @Test
  public void PEI0142_CreerCommandeTransfertBoiteMailSecondaire_KO() throws Throwable
  {

    String operateur = "BSS_GP"; //$NON-NLS-1$
    String numCompte = "3594886"; //$NON-NLS-1$
    Tracabilite tracabilite = new Tracabilite();
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    List<RequestHeader> headers = new ArrayList<>();
    RequestHeader xClientOperateur = new RequestHeader();
    xClientOperateur.setName("X-Client-Operateur"); //$NON-NLS-1$
    xClientOperateur.setValue(operateur);
    headers.add(xClientOperateur);
    RequestHeader xRequestId = new RequestHeader();
    xRequestId.setName("X-Request-Id"); //$NON-NLS-1$
    xRequestId.setValue(numCompte);
    headers.add(xRequestId);
    RequestHeader xMessageId = new RequestHeader();
    xMessageId.setName("X-Message-Id"); //$NON-NLS-1$
    xMessageId.setValue("MessageID123"); //$NON-NLS-1$
    headers.add(xMessageId);
    RequestHeader xSource = new RequestHeader();
    xSource.setName("X-Source"); //$NON-NLS-1$
    xSource.setValue("SPIRIT"); //$NON-NLS-1$
    headers.add(xSource);
    RequestHeader xProcess = new RequestHeader();
    xProcess.setName("X-Process"); //$NON-NLS-1$
    xProcess.setValue("PROCESSUS TAKEOVER"); //$NON-NLS-1$
    headers.add(xProcess);
    request.getRequestHeader().addAll(headers);

    PFI pfi = new PFI();
    List<PA> listpa = new ArrayList<>();
    PaTypeCompteAcces paType = new PaTypeCompteAcces("charles.rock"); //$NON-NLS-1$
    PA pa = new PA(null, "COMPTE_ACCES", Statut.ACTIF, null, null); //$NON-NLS-1$
    pa.setPaTypeCompteAcces(paType);
    listpa.add(pa);
    pfi.setPa(listpa);

    // Mock configuration ProcessusManager
    HashMap<String, String> map = new HashMap<>();
    map.put("declenchementPEP", "true"); //$NON-NLS-1$ //$NON-NLS-2$
    ConcurrentHashMap<String, Map<String, String>> processParams = new ConcurrentHashMap<>();
    processParams.put(StringConstants.EMPTY_STRING, map);
    ProcessManager.getInstance().getProcessParams().clear();
    ProcessManager.getInstance().getProcessParams().putAll(processParams);

    //Mock for RPGProxy OK
    createMockRPG(RetourFactoryForTU.createOkRetour(), pfi, operateur, numCompte);
    createBL800(RetourFactoryForTU.createOkRetour());
    createMockCmd(RetourFactoryForTU.createOkRetour(), null);
    pfi = new PFI();
    listpa = new ArrayList<>();
    paType = new PaTypeCompteAcces("bernard.chevallier"); //$NON-NLS-1$
    pa = new PA(null, "COMPTE_ACCES", Statut.ACTIF, null, null); //$NON-NLS-1$
    pa.setPaTypeCompteAcces(paType);
    listpa.add(pa);
    pfi.setPa(listpa);

    numCompte = "76398756589"; //$NON-NLS-1$
    //Mock for RPGProxy OK
    createMockRPG(RetourFactoryForTU.createOkRetour(), pfi, operateur, numCompte);

    createProvLancerOrchestr(RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "", null)); //$NON-NLS-1$
    request.setHttpMethod("POST"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    ServiceMailRequest mailRequest = buildValidServiceMailRequest();
    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(mailRequest, ServiceMailRequest.class);

    request.setPayload(jSonRequest);
    PEI0142_CreerCommandeTransfertBoiteMailSecondaire pei0142 = new PEI0142_CreerCommandeTransfertBoiteMailSecondaire();

    PowerMock.expectNew(BL800_ObtenirSequenceBuilder.class).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.code(UniqueIdConstant.ID_ERREUR_SPIRIT)).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.build()).andReturn(_bl800Mock);
    EasyMock.expect(_bl800Mock.execute(pei0142)).andReturn(ID_ERREUR_SPIRIT);
    EasyMock.expect(_bl800Mock.getRetour()).andReturn(RetourFactoryForTU.createOkRetour());

    Retour retourBL005 = RetourFactoryForTU.createOkRetour();
    ConnectorResponse<Retour, Nothing> resultRex = new ConnectorResponse<>(retourBL005, null);
    // Used in BL005
    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxy);
    EasyMock.expect(_rexProxy.erreurSpiritCreer(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(CreateErreurSpiritRequest.class))).andReturn(resultRex);

    PowerMock.replayAll();
    pei0142.initializeContext();
    pei0142.run(request);
    pei0142.continueProcess(request, tracabilite);
    PowerMock.verify();
    IRavelResponse response = request.getResponse();

    assertEquals(ErrorCode.OK_00204, response.getErrorCode());
    assertEquals("", response.getGenericResponse().getResult()); //$NON-NLS-1$
    assertEquals(RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "", null), pei0142.getRetour()); //$NON-NLS-1$
  }

  /**
   * Test PEI0142_CreerCommandeTransfertBoiteMailSecondaire nominal case. Assert that tracabilite is well filled with
   * request headers. Assert that validation is OK.
   *
   * @throws Throwable
   *           exception
   */
  @Test
  public void PEI0142_CreerCommandeTransfertBoiteMailSecondaire_OK() throws Throwable
  {

    String operateur = "BSS_GP"; //$NON-NLS-1$
    String numCompte = "3594886"; //$NON-NLS-1$
    Tracabilite tracabilite = new Tracabilite();
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    List<RequestHeader> headers = new ArrayList<>();
    RequestHeader xClientOperateur = new RequestHeader();
    xClientOperateur.setName("X-Client-Operateur"); //$NON-NLS-1$
    xClientOperateur.setValue(operateur);
    headers.add(xClientOperateur);
    RequestHeader xRequestId = new RequestHeader();
    xRequestId.setName("X-Request-Id"); //$NON-NLS-1$
    xRequestId.setValue(numCompte);
    headers.add(xRequestId);
    RequestHeader xMessageId = new RequestHeader();
    xMessageId.setName("X-Message-Id"); //$NON-NLS-1$
    xMessageId.setValue("MessageID123"); //$NON-NLS-1$
    headers.add(xMessageId);
    RequestHeader xSource = new RequestHeader();
    xSource.setName("X-Source"); //$NON-NLS-1$
    xSource.setValue("SPIRIT"); //$NON-NLS-1$
    headers.add(xSource);
    RequestHeader xProcess = new RequestHeader();
    xProcess.setName("X-Process"); //$NON-NLS-1$
    xProcess.setValue("PROCESSUS TAKEOVER"); //$NON-NLS-1$
    headers.add(xProcess);
    request.getRequestHeader().addAll(headers);

    PFI pfi = new PFI();
    List<PA> listpa = new ArrayList<>();
    PaTypeCompteAcces paType = new PaTypeCompteAcces("charles.rock"); //$NON-NLS-1$
    PA pa = new PA(null, "COMPTE_ACCES", Statut.ACTIF, null, null); //$NON-NLS-1$
    pa.setPaTypeCompteAcces(paType);
    listpa.add(pa);
    pfi.setPa(listpa);

    // Mock configuration ProcessusManager
    HashMap<String, String> map = new HashMap<>();
    map.put("declenchementPEP", "true"); //$NON-NLS-1$ //$NON-NLS-2$
    ConcurrentHashMap<String, Map<String, String>> processParams = new ConcurrentHashMap<>();
    processParams.put(StringConstants.EMPTY_STRING, map);
    ProcessManager.getInstance().getProcessParams().clear();
    ProcessManager.getInstance().getProcessParams().putAll(processParams);

    //Mock for RPGProxy OK
    createMockRPG(RetourFactoryForTU.createOkRetour(), pfi, operateur, numCompte);
    createBL800(RetourFactoryForTU.createOkRetour());
    createMockCmd(RetourFactoryForTU.createOkRetour(), null);
    pfi = new PFI();
    listpa = new ArrayList<>();
    paType = new PaTypeCompteAcces("bernard.chevallier"); //$NON-NLS-1$
    pa = new PA(null, "COMPTE_ACCES", Statut.ACTIF, null, null); //$NON-NLS-1$
    pa.setPaTypeCompteAcces(paType);
    listpa.add(pa);
    pfi.setPa(listpa);

    numCompte = "76398756589"; //$NON-NLS-1$
    //Mock for RPGProxy OK
    createMockRPG(RetourFactoryForTU.createOkRetour(), pfi, operateur, numCompte);

    createProvLancerOrchestr(RetourFactoryForTU.createOkRetour());
    request.setHttpMethod("POST"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    ServiceMailRequest mailRequest = buildValidServiceMailRequest();
    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(mailRequest, ServiceMailRequest.class);

    request.setPayload(jSonRequest);
    PEI0142_CreerCommandeTransfertBoiteMailSecondaire pei0142 = new PEI0142_CreerCommandeTransfertBoiteMailSecondaire();

    PowerMock.expectNew(BL800_ObtenirSequenceBuilder.class).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.code(UniqueIdConstant.ID_ERREUR_SPIRIT)).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.build()).andReturn(_bl800Mock);
    EasyMock.expect(_bl800Mock.execute(pei0142)).andReturn(ID_ERREUR_SPIRIT);
    EasyMock.expect(_bl800Mock.getRetour()).andReturn(RetourFactoryForTU.createOkRetour());

    PowerMock.replayAll();
    pei0142.initializeContext();
    pei0142.run(request);
    pei0142.continueProcess(request, tracabilite);
    PowerMock.verify();
    IRavelResponse response = request.getResponse();

    assertEquals(ErrorCode.OK_00204, response.getErrorCode());
    assertEquals("", response.getGenericResponse().getResult()); //$NON-NLS-1$

  }

  /**
   * Builds a valid {@link ServiceMailRequest} object
   *
   * @return {@link ServiceMailRequest}
   */
  private ServiceMailRequest buildValidServiceMailRequest()
  {
    ServiceMailRequest mailRequest = new ServiceMailRequest();

    ServiceMailRequest.IdentifiantAcces identifiantAccesSouce = new ServiceMailRequest.IdentifiantAcces();
    identifiantAccesSouce.setLoginMail("charles.rock"); //$NON-NLS-1$
    mailRequest.setIdentifiantAccesSource(identifiantAccesSouce);

    ServiceMailRequest.IdentifiantAcces identifiantAccesCible = new ServiceMailRequest.IdentifiantAcces();
    identifiantAccesCible.setLoginMail("bernard.chevallier"); //$NON-NLS-1$
    mailRequest.setIdentifiantAccesCible(identifiantAccesCible);

    ServiceMailRequest.PortefeuilleServices portefeuilleSource = new ServiceMailRequest.PortefeuilleServices();
    portefeuilleSource.setNoCompte("3594886"); //$NON-NLS-1$
    mailRequest.setPortefeuilleServicesSource(portefeuilleSource);
    ServiceMailRequest.PortefeuilleServices portefeuilleCible = new ServiceMailRequest.PortefeuilleServices();
    portefeuilleCible.setNoCompte("76398756589"); //$NON-NLS-1$
    mailRequest.setPortefeuilleServicesCible(portefeuilleCible);

    return mailRequest;

  }

  /**
   * creation mock BL800
   *
   * @param retour_p
   *          retour
   * @throws Exception
   *           exception
   */
  private void createBL800(Retour retour_p) throws Exception
  {

    PowerMock.expectNew(BL800_ObtenirSequenceBuilder.class).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.code(EasyMock.anyObject())).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.build()).andReturn(_bl800Mock);
    EasyMock.expect(_bl800Mock.execute(EasyMock.anyObject(PEI0142_CreerCommandeTransfertBoiteMailSecondaire.class))).andReturn("idcomd"); //$NON-NLS-1$
    EasyMock.expect(_bl800Mock.getRetour()).andReturn(retour_p);
  }

  /**
   * Creation du Mock Connecteur CMD
   *
   * @param retour
   *          retour
   * @param nothing
   *          nothing
   * @throws RavelException
   *           exception
   *
   */
  private void createMockCmd(Retour retour, Nothing nothing) throws RavelException
  {

    ConnectorResponse<Retour, Nothing> resultCmd = new ConnectorResponse<>(retour, nothing);
    EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdProxy);
    EasyMock.expect(_cmdProxy.commandeCreer(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(CreateCommandeRequest.class))).andReturn(resultCmd);
  }

  /**
   * Creation du Mock Connecteur RPG
   *
   * @param retour
   *          retour
   * @param pfi
   *          pfi
   * @param operateur
   *          operateur
   * @param numcompte
   *          nucompte
   * @throws RavelException
   *           exception
   */
  private void createMockRPG(Retour retour, PFI pfi, String operateur, String numcompte) throws RavelException
  {

    ConnectorResponse<Retour, PFI> expectedResponse = new ConnectorResponse<>(retour, pfi);
    EasyMock.expect(RPGProxy.getInstance()).andReturn(_rpgDatabaseProxy);
    EasyMock.expect(_rpgDatabaseProxy.pfiLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(operateur), EasyMock.eq(numcompte))).andReturn(expectedResponse);

  }

  /**
   * createProvLancerOrchestr
   *
   * @param retour_p
   *          retour
   * @throws Exception
   *           exception
   */
  private void createProvLancerOrchestr(Retour retour_p) throws Exception
  {

    PowerMock.expectNew(PROV_SI001_LancerOrchestrateurBuilder.class).andReturn(_provLancerBuilder);
    EasyMock.expect(_provLancerBuilder.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_provLancerBuilder);
    EasyMock.expect(_provLancerBuilder.cles(EasyMock.anyObject())).andReturn(_provLancerBuilder);
    EasyMock.expect(_provLancerBuilder.priorite(10)).andReturn(_provLancerBuilder);
    EasyMock.expect(_provLancerBuilder.type(EasyMock.anyObject())).andReturn(_provLancerBuilder);
    EasyMock.expect(_provLancerBuilder.noms(EasyMock.anyObject())).andReturn(_provLancerBuilder);
    EasyMock.expect(_provLancerBuilder.valeurs(EasyMock.anyObject())).andReturn(_provLancerBuilder);
    EasyMock.expect(_provLancerBuilder.processus(EasyMock.anyObject())).andReturn(_provLancerBuilder);
    EasyMock.expect(_provLancerBuilder.build()).andReturn(_provLancer);

    EasyMock.expect(_provLancer.execute(EasyMock.anyObject(PEI0142_CreerCommandeTransfertBoiteMailSecondaire.class))).andReturn(__podam.manufacturePojoWithFullData(ResponseConnector.class));
    EasyMock.expect(_provLancer.getRetour()).andReturn(retour_p);

  }

}