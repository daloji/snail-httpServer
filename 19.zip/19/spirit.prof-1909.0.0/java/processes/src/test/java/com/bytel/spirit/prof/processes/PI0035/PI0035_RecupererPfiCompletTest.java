/*******************************************************************************
* $Id: PI0035_RecupererPfiCompletTest.java 24220 2019-07-17 13:43:46Z jgregori $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PI0035;

import static java.util.Objects.nonNull;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import java.text.MessageFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.Mock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PowerMockListener;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.testlisteners.FieldDefaulter;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.modules.junit4.PowerMockRunnerDelegate;
import org.powermock.reflect.Whitebox;
import org.springframework.test.context.ContextConfiguration;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.data.exchange.generated.RavelRequest.RequestHeader;
import com.bytel.ravel.common.datetime.DateTimeManager;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.request.Parameter;
import com.bytel.ravel.common.factory.request.UrlParameters;
import com.bytel.ravel.common.factory.response.IRavelResponse;
import com.bytel.ravel.common.factory.response.RavelResponseFactory;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.test.podam.JavaTimeManufacturer;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.test.podam.PodamBytelJUnit4ClassRunner;
import com.bytel.ravel.common.utils.Pair;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.RetourFactoryForTU;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.ProcessManager;
import com.bytel.ravel.services.utils.Test_Consts;
import com.bytel.spirit.common.activities.ossfai.OSSFAI_SI019_LireStTelephonieLegacy;
import com.bytel.spirit.common.activities.ossfai.OSSFAI_SI019_LireStTelephonieLegacy.OSSFAI_SI019_LireStTelephonieLegacyBuilder;
import com.bytel.spirit.common.activities.ossfai.OSSFAI_SI025_LireStEquipementLegacyParSn;
import com.bytel.spirit.common.activities.ossfai.OSSFAI_SI025_LireStEquipementLegacyParSn.OSSFAI_SI025_LireStEquipementLegacyParSnBuilder;
import com.bytel.spirit.common.activities.ossfai.OSSFAI_SI031_LireNrmId;
import com.bytel.spirit.common.activities.ossfai.OSSFAI_SI031_LireNrmId.OSSFAI_SI031_LireNrmIdBuilder;
import com.bytel.spirit.common.activities.ossfai.OSSFAI_SI032_LireNrmInfos;
import com.bytel.spirit.common.activities.ossfai.OSSFAI_SI032_LireNrmInfos.OSSFAI_SI032_LireNrmInfosBuilder;
import com.bytel.spirit.common.activities.ossfai.structs.si019.ServiceTechniqueTelephonieLegacy;
import com.bytel.spirit.common.activities.ossfai.structs.si025.ServiceTechniqueEquipementLegacy;
import com.bytel.spirit.common.activities.shared.BL2500_RecupererRessourceAggrege;
import com.bytel.spirit.common.activities.shared.BL2500_RecupererRessourceAggrege.BL2500_RecupererRessourceAggregeBuilder;
import com.bytel.spirit.common.activities.shared.structs.BL2500_Return;
import com.bytel.spirit.common.connectors.air.AIRProxy;
import com.bytel.spirit.common.connectors.b2e.structs.StatutLegacy;
import com.bytel.spirit.common.connectors.cmd.CMDProxy;
import com.bytel.spirit.common.connectors.nrm.structs.NRMInfosRetour;
import com.bytel.spirit.common.connectors.res.RESProxy;
import com.bytel.spirit.common.connectors.rex.REXProxy;
import com.bytel.spirit.common.connectors.rpg.RPGProxy;
import com.bytel.spirit.common.connectors.rst.RSTProxy;
import com.bytel.spirit.common.shared.functional.types.json.RavelJsonTools;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.acsiad.DonneesIdentificationSTPfsAcsIad;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.acsiad.DonneesProvisionneesSTPfsAcsIad;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.acsiad.StPfsAcsIad;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.clf.DonneesIdentificationStPfsClf;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.clf.DonneesProvisionneesStPfsClf;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.clf.StPfsClf;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.fqdn.DonneesIdentificationSTPfsFqdn;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.fqdn.DonneesProvisionneesSTPfsFqdn;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.fqdn.StPfsFqdn;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.mail.DonneesIdentificationSTPfsMail;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.mail.DonneesProvisionneesSTPfsMail;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.mail.StPfsMail;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.olt.DonneesIdentificationSTPfsOlt;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.olt.DonneesProvisionneesSTPfsOlt;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.olt.StPfsOlt;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.pfs_enum.DonneesIdentificationStPfsEnum;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.pfs_enum.DonneesProvisionneesStPfsEnum;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.pfs_enum.StPfsEnum;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.pnf.DonneesIdentificationStPfsPnf;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.pnf.DonneesProvisionneesStPfsPnf;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.pnf.StPfsPnf;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.sam.DonneesIdentificationStPfsSam;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.sam.DonneesProvisionneesStPfsSam;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.sam.StPfsSam;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.vmscvm.DonneesIdentificationSTPfsVmsCvm;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.vmscvm.DonneesProvisionneesSTPfsVmsCvm;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.vmscvm.StPfsVmsCvm;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.vmsstw.DonneesIdentificationSTPfsVmsStw;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.vmsstw.DonneesProvisionneesSTPfsVmsStw;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.vmsstw.StPfsVmsStw;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.ressources.RetourConverter;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.TypeObjetCommercial;
import com.bytel.spirit.common.shared.saab.air.IndexRecherchePfi;
import com.bytel.spirit.common.shared.saab.cmd.CommandeComposite;
import com.bytel.spirit.common.shared.saab.cmd.ModificationCommerciale;
import com.bytel.spirit.common.shared.saab.cmd.ModificationTechnique;
import com.bytel.spirit.common.shared.saab.res.AccesTechnique;
import com.bytel.spirit.common.shared.saab.res.AdresseDonnee;
import com.bytel.spirit.common.shared.saab.res.Fqdn;
import com.bytel.spirit.common.shared.saab.res.Ressource;
import com.bytel.spirit.common.shared.saab.res.RessourceAggrege;
import com.bytel.spirit.common.shared.saab.res.RessourceAggregeP2P;
import com.bytel.spirit.common.shared.saab.res.RessourceRaccordement;
import com.bytel.spirit.common.shared.saab.res.RessourceRaccordementComposite;
import com.bytel.spirit.common.shared.saab.res.TypeRaccordement;
import com.bytel.spirit.common.shared.saab.res.TypeRessource;
import com.bytel.spirit.common.shared.saab.rex.request.CreateErreurSpiritRequest;
import com.bytel.spirit.common.shared.saab.rpg.EquipementDeclare;
import com.bytel.spirit.common.shared.saab.rpg.PA;
import com.bytel.spirit.common.shared.saab.rpg.PFI;
import com.bytel.spirit.common.shared.saab.rpg.Statut;
import com.bytel.spirit.common.shared.saab.rpg.TechnologieAccess;
import com.bytel.spirit.common.shared.saab.rpg.TypePA;
import com.bytel.spirit.common.shared.saab.rst.ServiceTechnique;
import com.bytel.spirit.common.shared.saab.rst.StLienAllocationCommercial;
import com.bytel.spirit.prof.processes.Messages;
import com.bytel.spirit.prof.processes.PI0035.PI0035_RecupererPfiComplet.ParameterUrl;
import com.bytel.spirit.prof.processes.PI0035.PI0035_RecupererPfiComplet.State;
import com.bytel.spirit.prof.processes.PI0035.sti.PI0035_AccesTechnique;
import com.bytel.spirit.prof.processes.PI0035.sti.PI0035_DonneesTopologieReseaux;
import com.bytel.spirit.prof.processes.PI0035.sti.PI0035_DonneesTopologieReseauxFqdn;
import com.bytel.spirit.prof.processes.PI0035.sti.PI0035_ErreurBloquante;
import com.bytel.spirit.prof.processes.PI0035.sti.PI0035_IndexRecherche;
import com.bytel.spirit.prof.processes.PI0035.sti.PI0035_ModificationCommerciale;
import com.bytel.spirit.prof.processes.PI0035.sti.PI0035_ModificationTechnique;
import com.bytel.spirit.prof.processes.PI0035.sti.PI0035_PFIComplet;
import com.bytel.spirit.prof.processes.PI0035.sti.PI0035_Ressource;
import com.bytel.spirit.prof.processes.PI0035.sti.PI0035_RessourceAggregeP2P;
import com.bytel.spirit.prof.processes.PI0035.sti.PI0035_RessourceRaccordement;
import com.bytel.spirit.prof.processes.PI0035.sti.PI0035_RessourceRaccordementP2P;
import com.bytel.spirit.prof.processes.PI0035.sti.PI0035_Retour;
import com.bytel.spirit.prof.processes.PI0035.sti.PI0035_Retour.ReponseFonctionnelle;
import com.bytel.spirit.prof.processes.PI0035.sti.PI0035_ServiceTechnique;
import com.bytel.spirit.prof.processes.PI0035.sti.PI0035_ServiceTechniqueLegacy;
import com.bytel.spirit.prof.processes.PI0035.sti.PI0035_StLegacyAccesGPON;
import com.bytel.spirit.prof.processes.PI0035.sti.PI0035_StLegacyFqdn;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author kbettenc
 * @version ($Revision: 24220 $ $Date: 2019-07-17 15:43:46 +0200 (mer. 17 juil. 2019) $)
 */
@RunWith(PowerMockRunner.class)
@PowerMockListener(FieldDefaulter.class)
@PowerMockRunnerDelegate(PodamBytelJUnit4ClassRunner.class)
@ContextConfiguration("classpath:BeansProcessTestMocks.xml")
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
@PrepareForTest({ PI0035_RecupererPfiComplet.class, RPGProxy.class, CMDProxy.class, RSTProxy.class, RESProxy.class, AIRProxy.class, REXProxy.class, OSSFAI_SI025_LireStEquipementLegacyParSnBuilder.class, OSSFAI_SI025_LireStEquipementLegacyParSn.class, OSSFAI_SI019_LireStTelephonieLegacyBuilder.class, OSSFAI_SI019_LireStTelephonieLegacy.class, BL2500_RecupererRessourceAggregeBuilder.class, BL2500_RecupererRessourceAggrege.class })
public final class PI0035_RecupererPfiCompletTest
{
  /**
   * Factory de génération des beans
   */
  private static PodamFactory __podam;

  /**
   * Initialization method: Create: - spring context - connectors - service manager.
   *
   * @throws RavelException
   *           the exception
   */
  @BeforeClass
  public static void init() throws RavelException
  {
    // désactivation du cache podam
    __podam = new PodamFactoryImpl();
    __podam.getStrategy().setMemoization(false);
    __podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());
    JavaTimeManufacturer.registerPodamFactory(__podam);
  }

  /**
   * Tracabilite
   */
  private Tracabilite _tracabilite;

  /**
   * Instance of {@link PI0035_RecupererPfiComplet}
   */
  private PI0035_RecupererPfiComplet _processInstance;

  /**
   * AIR PRoxy
   */
  @MockStrict
  private AIRProxy _airProxy;

  /**
   * CMD PRoxy
   */
  @MockStrict
  private CMDProxy _cmdProxy;

  /**
   * RES PRoxy
   */
  @MockStrict
  private RESProxy _resProxy;

  /**
   * REX PRoxy
   */
  @MockStrict
  private REXProxy _rexProxy;

  /**
   * RPG PRoxy
   */
  @MockStrict
  private RPGProxy _rpgProxy;

  /**
   * RST PRoxy
   */
  @MockStrict
  private RSTProxy _rstProxy;

  /**
   * Mock de {@link BL2500_RecupererRessourceAggrege}
   */
  @MockStrict
  private BL2500_RecupererRessourceAggrege _bl2500Mock;

  /**
   * Mock de {@link BL2500_RecupererRessourceAggregeBuilder}
   */
  @MockStrict
  private BL2500_RecupererRessourceAggregeBuilder _bl2500BuilderMock;

  /**
   * Mock de {@link OSSFAI_SI025_LireStEquipementLegacyParSn}
   */
  @Mock
  private OSSFAI_SI025_LireStEquipementLegacyParSn _si025Mock;

  /**
   * Mock de {@link OSSFAI_SI025_LireStEquipementLegacyParSnBuilder}
   */
  @Mock
  private OSSFAI_SI025_LireStEquipementLegacyParSnBuilder _si025BuilderMock;

  /**
   * Mock de {@link OSSFAI_SI019_LireStTelephonieLegacy}
   */
  @Mock
  private OSSFAI_SI019_LireStTelephonieLegacy _si019Mock;

  /**
   * Mock de {@link OSSFAI_SI019_LireStTelephonieLegacyBuilder}
   */
  @Mock
  private OSSFAI_SI019_LireStTelephonieLegacyBuilder _si019BuilderMock;

  /**
   * Mock de {@link OSSFAI_SI031_LireNrmId}
   */
  @Mock
  private OSSFAI_SI031_LireNrmId _si031Mock;

  /**
   * Mock de {@link OSSFAI_SI031_LireNrmIdBuilder}
   */
  @Mock
  private OSSFAI_SI031_LireNrmIdBuilder _si031BuilderMock;

  /**
   * Mock de {@link OSSFAI_SI032_LireNrmInfos}
   */
  @Mock
  private OSSFAI_SI032_LireNrmInfos _si032Mock;

  /**
   * Mock de {@link OSSFAI_SI032_LireNrmInfosBuilder}
   */
  @Mock
  private OSSFAI_SI032_LireNrmInfosBuilder _si032BuilderMock;

  /**
   * <b>Scenario:</b> Tests non nominal case.<br>
   * <b>Input:</b> All required headers and fields are set<br>
   * <b>Result:</b> Retour KO NON_RESPECT_STI. Le paramètre clientOperateur 123456789 n'est pas autorisé
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PI0035_BL001_VerifierDonnees_Test_KO_04() throws Exception
  {

    Request request = prepareRequest("123456789", "123456789"); //$NON-NLS-1$ //$NON-NLS-2$
    fillAllRequestHeaders(request);

    Retour bl001Retour = Whitebox.invokeMethod(_processInstance, "PI0035_BL001_VerifierDonnees", _tracabilite, request); //$NON-NLS-1$
    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, "Le paramètre clientOperateur 123456789 n'est pas autorisé", null); //$NON-NLS-1$
    assertEquals(expectedRetour, bl001Retour);
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. The required request parameter clientOperateur is not set.<br>
   * <b>Input:</b> "clientOperateur" request parameter not set in URL parameter<br>
   * <b>Result:</b> Retour {KO, CAT-3, NON_RESPECT_STI, Paramètre clientOperateur null ou vide dans la requête.,
   * PI0035_BL001_VerifierDonnees}
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PI0035_BL001_VerifierDonnees_Test_KO_05() throws Exception
  {

    Request request = prepareRequest(null, "123456789"); //$NON-NLS-1$
    fillAllRequestHeaders(request);

    Retour bl001Retour = Whitebox.invokeMethod(_processInstance, "PI0035_BL001_VerifierDonnees", _tracabilite, request); //$NON-NLS-1$
    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString("PI0035.BL001.ParameterNullOrEmpty"), PI0035_RecupererPfiComplet.ParameterUrl.clientOperateur.name()), null); //$NON-NLS-1$

    assertEquals(retourExpected, bl001Retour);
  }

  /**
   * <b>Scenario:</b> Tests non nominal case.<br>
   * <b>Input:</b> noCompte not set in Url parameters<br>
   * <b>Result:</b> Retour {KO, CAT-3, NON_RESPECT_STI, Paramètre noCompte null ou vide dans la requête.,
   * PI0035_BL001_VerifierDonnees}
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PI0035_BL001_VerifierDonnees_Test_KO_06() throws Exception
  {

    Request request = prepareRequest("BSS_GP", null); //$NON-NLS-1$
    fillAllRequestHeaders(request);

    Retour bl001Retour = Whitebox.invokeMethod(_processInstance, "PI0035_BL001_VerifierDonnees", _tracabilite, request); //$NON-NLS-1$
    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString("PI0035.BL001.ParameterNullOrEmpty"), PI0035_RecupererPfiComplet.ParameterUrl.noCompte.name()), null); //$NON-NLS-1$

    assertEquals(retourExpected, bl001Retour);
  }

  /**
   * <b>Scenario:</b> Tests nominal case.<br>
   * <b>Input:</b> All required headers and fields are set<br>
   * <b>Result:</b> Retour OK
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PI0035_BL001_VerifierDonnees_Test_OK_01() throws Exception
  {

    Request request = prepareRequest("BSS_GP", "123456789"); //$NON-NLS-1$ //$NON-NLS-2$
    fillAllRequestHeaders(request);

    Retour bl001Retour = Whitebox.invokeMethod(_processInstance, "PI0035_BL001_VerifierDonnees", _tracabilite, request); //$NON-NLS-1$

    assertEquals(RetourFactoryForTU.createOkRetour(), bl001Retour);
  }

  /**
   * Tests the PI0035_BL002_FormaterReponse method when the retour is KO
   *
   * <b>Inputs:</b> Retour KO <br>
   * <b>Expected:</b> Retour {KO; CAT-4; DONNEE_INCONNUE; Donnee inconnue} and ReponseFonctionnelle null<br>
   *
   * @throws Exception
   *           on unexpected error
   */
  @Test
  public void PI0035_BL002_FormaterReponse_KO_001() throws Exception
  {
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);
    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "Donnee inconnue", null); //$NON-NLS-1$

    _processInstance = new PI0035_RecupererPfiComplet();

    PowerMock.replayAll();
    PI0035_Retour retourBL002 = Whitebox.invokeMethod(_processInstance, "PI0035_BL002_FormaterReponse", tracabilite, retour, null, null); //$NON-NLS-1$
    PowerMock.verifyAll();

    assertEquals(retour, RetourConverter.convertFromJsonRetour(retourBL002.getRetour()));
  }

  /**
   * Tests the PI0035_BL002_FormaterReponse method when the PFI and ErreurBloquante are null
   *
   * <b>Inputs:</b> Retour OK and PFI null <br>
   * <b>Expected:</b> Retour {OK} and ReponseFonctionnelle null<br>
   *
   * @throws Exception
   *           on unexpected error
   */
  @Test
  public void PI0035_BL002_FormaterReponse_KO_002() throws Exception
  {
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);
    Retour retour = RetourFactoryForTU.createOkRetour();

    _processInstance = new PI0035_RecupererPfiComplet();

    PowerMock.replayAll();
    PI0035_Retour retourBL002 = Whitebox.invokeMethod(_processInstance, "PI0035_BL002_FormaterReponse", tracabilite, retour, null, null); //$NON-NLS-1$
    PowerMock.verifyAll();

    assertEquals(retour, RetourConverter.convertFromJsonRetour(retourBL002.getRetour()));
  }

  /**
   * Tests the PI0035_BL002_FormaterReponse method when the ErreurBloquante is null
   *
   * <b>Inputs:</b> Retour OK and PFI null <br>
   * <b>Expected:</b> Retour {OK} and ReponseFonctionnelle null<br>
   *
   * @throws Exception
   *           on unexpected error
   */
  @Test
  public void PI0035_BL002_FormaterReponse_KO_003() throws Exception
  {
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);
    Retour retour = RetourFactoryForTU.createOkRetour();
    PI0035_PFIComplet pfiComplet = __podam.manufacturePojo(PI0035_PFIComplet.class);

    _processInstance = new PI0035_RecupererPfiComplet();

    PowerMock.replayAll();
    PI0035_Retour retourBL002 = Whitebox.invokeMethod(_processInstance, "PI0035_BL002_FormaterReponse", tracabilite, retour, pfiComplet, null); //$NON-NLS-1$
    PowerMock.verifyAll();

    assertEquals(pfiComplet, retourBL002.getReponseFonctionnelle().getPfiComplet());
    assertEquals(retour, RetourConverter.convertFromJsonRetour(retourBL002.getRetour()));
  }

  /**
   * Tests the PI0035_BL002_FormaterReponse method when the PFI is null
   *
   * <b>Inputs:</b> Retour OK and PFI null <br>
   * <b>Expected:</b> Retour {OK} and ReponseFonctionnelle null<br>
   *
   * @throws Exception
   *           on unexpected error
   */
  @Test
  public void PI0035_BL002_FormaterReponse_KO_004() throws Exception
  {
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);
    Retour retour = RetourFactoryForTU.createOkRetour();
    List<PI0035_ErreurBloquante> listeErreurBloquante = Arrays.asList(new PI0035_ErreurBloquante("type", "libelle")); //$NON-NLS-1$ //$NON-NLS-2$

    _processInstance = new PI0035_RecupererPfiComplet();

    PowerMock.replayAll();
    PI0035_Retour retourBL002 = Whitebox.invokeMethod(_processInstance, "PI0035_BL002_FormaterReponse", tracabilite, retour, null, listeErreurBloquante); //$NON-NLS-1$
    PowerMock.verifyAll();

    assertNull(retourBL002.getReponseFonctionnelle().getPfiComplet());
    assertEquals(listeErreurBloquante, retourBL002.getReponseFonctionnelle().getErreurBloquante());
    assertEquals(retour, RetourConverter.convertFromJsonRetour(retourBL002.getRetour()));
  }

  /**
   * Tests the PI0035_BL002_FormaterReponse method nominal case
   *
   * <b>Inputs:</b> Retour OK and PFI not null<br>
   * <b>Expected:</b> Retour {OK} ReponseFonctionnelle {pfiComplet = pfiComplet; erreurBloquante =
   * listeErreurBloquante}<br>
   *
   * @throws Exception
   *           on unexpected error
   */
  @Test
  public void PI0035_BL002_FormaterReponse_OK_001() throws Exception
  {
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);
    Retour retour = RetourFactoryForTU.createOkRetour();
    PI0035_PFIComplet pfiComplet = __podam.manufacturePojo(PI0035_PFIComplet.class);
    List<PI0035_ErreurBloquante> listeErreurBloquante = Arrays.asList(new PI0035_ErreurBloquante("type", "libelle")); //$NON-NLS-1$ //$NON-NLS-2$

    _processInstance = new PI0035_RecupererPfiComplet();

    PowerMock.replayAll();
    PI0035_Retour retourBL002 = Whitebox.invokeMethod(_processInstance, "PI0035_BL002_FormaterReponse", tracabilite, retour, pfiComplet, listeErreurBloquante); //$NON-NLS-1$
    PowerMock.verifyAll();

    assertEquals(pfiComplet, retourBL002.getReponseFonctionnelle().getPfiComplet());
    assertEquals(listeErreurBloquante, retourBL002.getReponseFonctionnelle().getErreurBloquante());
    assertEquals(retour, RetourConverter.convertFromJsonRetour(retourBL002.getRetour()));
  }

  /**
   * Tests the PI0035_BL100_Recuperer method RPGProxy returns KO
   *
   * <b>Inputs:</b> RPGProxy mock returns KO<br>
   * <b>Expected:</b> Retour{KO,CAT-4,DONNEE_INVALIDE,""} PFIComplet null<br>
   *
   * @throws Exception
   *           on errors
   *
   */
  @Test
  public void PI0035_BL100_Recuperer_KO_001() throws Exception
  {
    String clientOperateur = "BSS_GP"; //$NON-NLS-1$
    String noCompte = "123456789"; //$NON-NLS-1$

    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INVALIDE, StringConstants.EMPTY_STRING, null);
    createMockRPGpfiLireUnFiltrerOCResilie(_tracabilite, retour, null, clientOperateur, noCompte);

    PowerMock.replayAll();
    Pair<Retour, PI0035_PFIComplet> retourBL100 = Whitebox.invokeMethod(_processInstance, "PI0035_BL100_Recuperer", _tracabilite, clientOperateur, noCompte); //$NON-NLS-1$
    PowerMock.verify();

    assertEquals(retour, retourBL100._first);
    assertNull(retourBL100._second);
  }

  /**
   * Tests the PI0035_BL100_Recuperer method CMDProxy returns KO
   *
   * <b>Inputs:</b> CMDProxy mock returns KO<br>
   * <b>Expected:</b> Retour{KO,CAT-4,DONNEE_INVALIDE,""} PFIComplet null<br>
   *
   * @throws Exception
   *           on errors
   *
   */
  @Test
  public void PI0035_BL100_Recuperer_KO_002() throws Exception
  {
    Retour retourOk = RetourFactoryForTU.createOkRetour();

    String clientOperateur = "BSS_GP"; //$NON-NLS-1$
    String noCompte = "123456789"; //$NON-NLS-1$

    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INVALIDE, StringConstants.EMPTY_STRING, null);
    PFI pfi = __podam.manufacturePojo(PFI.class);
    //to avoid IllegalArgumentException due to the autoset of the PFI
    for (PA sa : pfi.getPa())
    {
      sa.setTypePA(TypePA.COMPTE_ACCES.name());
    }

    createMockRPGpfiLireUnFiltrerOCResilie(_tracabilite, retourOk, pfi, clientOperateur, noCompte);
    createMockCMDcommandeCompositeGererLireTousModCommParPfiFiltrerTraite(_tracabilite, retour, null, clientOperateur, noCompte);

    PowerMock.replayAll();
    Pair<Retour, PI0035_PFIComplet> retourBL100 = Whitebox.invokeMethod(_processInstance, "PI0035_BL100_Recuperer", _tracabilite, clientOperateur, noCompte); //$NON-NLS-1$
    PowerMock.verify();

    assertEquals(retour, retourBL100._first);
    assertNull(retourBL100._second);
  }

  /**
   * Tests the PI0035_BL100_Recuperer method RSTProxy returns KO
   *
   * <b>Inputs:</b> RSTProxy mock returns KO<br>
   * <b>Expected:</b> Retour{KO,CAT-4,DONNEE_INVALIDE,""} PFIComplet null<br>
   *
   * @throws Exception
   *           on errors
   *
   */
  @Test
  public void PI0035_BL100_Recuperer_KO_003() throws Exception
  {
    Retour retourOk = RetourFactoryForTU.createOkRetour();

    String clientOperateur = "BSS_GP"; //$NON-NLS-1$
    String noCompte = "123456789"; //$NON-NLS-1$

    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INVALIDE, StringConstants.EMPTY_STRING, null);
    PFI pfi = __podam.manufacturePojo(PFI.class);
    //to avoid IllegalArgumentException due to the autoset of the PFI
    for (PA sa : pfi.getPa())
    {
      sa.setTypePA(TypePA.COMPTE_ACCES.name());
    }

    createMockRPGpfiLireUnFiltrerOCResilie(_tracabilite, retourOk, pfi, clientOperateur, noCompte);
    List<CommandeComposite> listeCommandeComposite = Arrays.asList(__podam.manufacturePojo(CommandeComposite.class));
    createMockCMDcommandeCompositeGererLireTousModCommParPfiFiltrerTraite(_tracabilite, retourOk, listeCommandeComposite, clientOperateur, noCompte);
    createMockRSTserviceTechniqueLireTousParPfiFiltrerInactif(_tracabilite, retour, null, clientOperateur, noCompte);

    PowerMock.replayAll();
    Pair<Retour, PI0035_PFIComplet> retourBL100 = Whitebox.invokeMethod(_processInstance, "PI0035_BL100_Recuperer", _tracabilite, clientOperateur, noCompte); //$NON-NLS-1$
    PowerMock.verify();

    assertEquals(retour, retourBL100._first);
    assertNull(retourBL100._second);
  }

  /**
   * Tests the PI0035_BL100_Recuperer method RESProxy returns KO
   *
   * <b>Inputs:</b> RESProxy mock returns KO<br>
   * <b>Expected:</b> Retour{KO,CAT-4,DONNEE_INVALIDE,""} PFIComplet null<br>
   *
   * @throws Exception
   *           on errors
   *
   */
  @Test
  public void PI0035_BL100_Recuperer_KO_004() throws Exception
  {
    Retour retourOk = RetourFactoryForTU.createOkRetour();

    String clientOperateur = "BSS_GP"; //$NON-NLS-1$
    String noCompte = "123456789"; //$NON-NLS-1$

    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INVALIDE, StringConstants.EMPTY_STRING, null);
    PFI pfi = __podam.manufacturePojo(PFI.class);
    //to avoid IllegalArgumentException due to the autoset of the PFI
    for (PA sa : pfi.getPa())
    {
      sa.setTypePA(TypePA.COMPTE_ACCES.name());
    }

    createMockRPGpfiLireUnFiltrerOCResilie(_tracabilite, retourOk, pfi, clientOperateur, noCompte);

    List<CommandeComposite> listeCommandeComposite = Arrays.asList(__podam.manufacturePojo(CommandeComposite.class));
    createMockCMDcommandeCompositeGererLireTousModCommParPfiFiltrerTraite(_tracabilite, retourOk, listeCommandeComposite, clientOperateur, noCompte);

    StLienAllocationCommercial stLienAllocationCommercial = new StLienAllocationCommercial("idST", Statut.ACTIF.name(), clientOperateur, noCompte, TypeObjetCommercial.PFI.name(), "BSS_GP", noCompte, "idRessource", TypeRessource.COMPTE_MAIL.name()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    List<ServiceTechnique> listeServiceTechnique = Arrays.asList(stLienAllocationCommercial);
    createMockRSTserviceTechniqueLireTousParPfiFiltrerInactif(_tracabilite, retourOk, listeServiceTechnique, clientOperateur, noCompte);

    Ressource ressource = new Ressource(stLienAllocationCommercial.getIdRessource(), stLienAllocationCommercial.getTypeRessource(), stLienAllocationCommercial.getStatut());
    createMockRESressourceLireUn(_tracabilite, retour, ressource);

    PowerMock.replayAll();
    Pair<Retour, PI0035_PFIComplet> retourBL100 = Whitebox.invokeMethod(_processInstance, "PI0035_BL100_Recuperer", _tracabilite, clientOperateur, noCompte); //$NON-NLS-1$
    PowerMock.verify();

    assertEquals(retour, retourBL100._first);
    assertNull(retourBL100._second);
  }

  /**
   * Tests the PI0035_BL100_Recuperer method AIRProxy returns KO
   *
   * <b>Inputs:</b> AIRProxy mock returns KO<br>
   * <b>Expected:</b> Retour{KO,CAT-4,DONNEE_INVALIDE,""} PFIComplet null<br>
   *
   * @throws Exception
   *           on errors
   *
   */
  @Test
  public void PI0035_BL100_Recuperer_KO_005() throws Exception
  {
    Retour retourOk = RetourFactoryForTU.createOkRetour();

    String clientOperateur = "BSS_GP"; //$NON-NLS-1$
    String noCompte = "123456789"; //$NON-NLS-1$

    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INVALIDE, StringConstants.EMPTY_STRING, null);
    PFI pfi = __podam.manufacturePojo(PFI.class);
    //to avoid IllegalArgumentException due to the autoset of the PFI
    for (PA sa : pfi.getPa())
    {
      sa.setTypePA(TypePA.COMPTE_ACCES.name());
    }

    createMockRPGpfiLireUnFiltrerOCResilie(_tracabilite, retourOk, pfi, clientOperateur, noCompte);

    List<CommandeComposite> listeCommandeComposite = Arrays.asList(__podam.manufacturePojo(CommandeComposite.class));
    createMockCMDcommandeCompositeGererLireTousModCommParPfiFiltrerTraite(_tracabilite, retourOk, listeCommandeComposite, clientOperateur, noCompte);

    StLienAllocationCommercial stLienAllocationCommercial = new StLienAllocationCommercial("idST", Statut.ACTIF.name(), clientOperateur, noCompte, TypeObjetCommercial.PFI.name(), "BSS_GP", noCompte, "idRessource", TypeRessource.COMPTE_MAIL.name()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    List<ServiceTechnique> listeServiceTechnique = Arrays.asList(stLienAllocationCommercial);
    createMockRSTserviceTechniqueLireTousParPfiFiltrerInactif(_tracabilite, retourOk, listeServiceTechnique, clientOperateur, noCompte);

    Ressource ressource = new Ressource(stLienAllocationCommercial.getIdRessource(), stLienAllocationCommercial.getTypeRessource(), stLienAllocationCommercial.getStatut());
    createMockRESressourceLireUn(_tracabilite, retourOk, ressource);

    createMockAIRindexRechercherPfiLireUn(_tracabilite, retour, null, clientOperateur, noCompte);

    PowerMock.replayAll();
    Pair<Retour, PI0035_PFIComplet> retourBL100 = Whitebox.invokeMethod(_processInstance, "PI0035_BL100_Recuperer", _tracabilite, clientOperateur, noCompte); //$NON-NLS-1$
    PowerMock.verify();

    assertEquals(retour, retourBL100._first);
    assertNull(retourBL100._second);
  }

  /**
   * Tests the PI0035_BL100_Recuperer method RESProxy returns KO
   *
   * <b>Inputs:</b> RESProxy mock returns KO<br>
   * <b>Expected:</b> Retour{KO,CAT-4,DONNEE_INVALIDE,""} PFIComplet null<br>
   *
   * @throws Exception
   *           on errors
   *
   */
  @Test
  public void PI0035_BL100_Recuperer_KO_006() throws Exception
  {
    Retour retourOk = RetourFactoryForTU.createOkRetour();

    String clientOperateur = "BSS_GP"; //$NON-NLS-1$
    String noCompte = "123456789"; //$NON-NLS-1$

    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INVALIDE, StringConstants.EMPTY_STRING, null);
    PFI pfi = __podam.manufacturePojo(PFI.class);
    //to avoid IllegalArgumentException due to the autoset of the PFI
    for (PA sa : pfi.getPa())
    {
      sa.setTypePA(TypePA.COMPTE_ACCES.name());
    }

    createMockRPGpfiLireUnFiltrerOCResilie(_tracabilite, retourOk, pfi, clientOperateur, noCompte);

    List<CommandeComposite> listeCommandeComposite = Arrays.asList(__podam.manufacturePojo(CommandeComposite.class));
    createMockCMDcommandeCompositeGererLireTousModCommParPfiFiltrerTraite(_tracabilite, retourOk, listeCommandeComposite, clientOperateur, noCompte);

    StLienAllocationCommercial stLienAllocationCommercial = new StLienAllocationCommercial("idST", Statut.ACTIF.name(), clientOperateur, noCompte, TypeObjetCommercial.PFI.name(), "BSS_GP", noCompte, "idRessource", TypeRessource.RACCO.name()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    List<ServiceTechnique> listeServiceTechnique = Arrays.asList(stLienAllocationCommercial);
    createMockRSTserviceTechniqueLireTousParPfiFiltrerInactif(_tracabilite, retourOk, listeServiceTechnique, clientOperateur, noCompte);

    Ressource ressource = new Ressource(stLienAllocationCommercial.getIdRessource(), stLienAllocationCommercial.getTypeRessource(), stLienAllocationCommercial.getStatut());

    createMockRESressourceRaccordementCompositeLireUn(_tracabilite, retour, ressource, null);

    PowerMock.replayAll();
    Pair<Retour, PI0035_PFIComplet> retourBL100 = Whitebox.invokeMethod(_processInstance, "PI0035_BL100_Recuperer", _tracabilite, clientOperateur, noCompte); //$NON-NLS-1$
    PowerMock.verify();

    assertEquals(retour, retourBL100._first);
    assertNull(retourBL100._second);
  }

  /**
   * Tests the nominal case of PI0035_BL100_Recuperer method
   *
   * <b>Inputs:</b> All valid inputs<br>
   * <b>Expected:</b> Retour{OK} and valid PFIComplet <br>
   *
   * @throws Exception
   *           on errors
   *
   */
  @Test
  public void PI0035_BL100_Recuperer_OK_001() throws Exception
  {
    Retour retourOk = RetourFactoryForTU.createOkRetour();

    String clientOperateur = "BSS_GP"; //$NON-NLS-1$
    String noCompte = "123456789"; //$NON-NLS-1$

    PFI pfi = __podam.manufacturePojo(PFI.class);
    List<EquipementDeclare> listEquiPfi = pfi.getEquipementDeclare();
    EquipementDeclare equipPfiLeg = new EquipementDeclare("noEquip", "noIdentif", "MODEM_DECODEUR_TV", com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, null, null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    listEquiPfi.add(equipPfiLeg);
    pfi.setEquipementDeclare(listEquiPfi);
    //to avoid IllegalArgumentException due to the autoset of the PFI
    for (PA pa : pfi.getPa())
    {
      pa.setTypePA(TypePA.COMPTE_ACCES.name());
    }

    createMockRPGpfiLireUnFiltrerOCResilie(_tracabilite, retourOk, pfi, clientOperateur, noCompte);

    List<CommandeComposite> listeCommandeComposite = Arrays.asList(__podam.manufacturePojo(CommandeComposite.class));
    createMockCMDcommandeCompositeGererLireTousModCommParPfiFiltrerTraite(_tracabilite, retourOk, listeCommandeComposite, clientOperateur, noCompte);

    StLienAllocationCommercial stLienAllocationCommercial = new StLienAllocationCommercial("idST", Statut.ACTIF.name(), clientOperateur, noCompte, TypeObjetCommercial.PFI.name(), "BSS_GP", noCompte, "idRessource", TypeRessource.COMPTE_MAIL.name()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    StPfsFqdn StPfsFqdn = new StPfsFqdn("idST", Statut.ACTIF.name(), clientOperateur, noCompte, new DonneesIdentificationSTPfsFqdn("name"), new DonneesProvisionneesSTPfsFqdn(22)); //$NON-NLS-1$ //$NON-NLS-2$
    StPfsVmsCvm stPfsVmsCvm = new StPfsVmsCvm("idST", Statut.ACTIF.name(), clientOperateur, noCompte, new DonneesIdentificationSTPfsVmsCvm("name"), new DonneesProvisionneesSTPfsVmsCvm("_noTelephone", "_typeUsage", "_ligneMarche", "_adresseMail", "_nomPrenomUtilisateur"));
    StPfsMail stPfsMail = new StPfsMail("idST", Statut.ACTIF.name(), clientOperateur, noCompte, new DonneesIdentificationSTPfsMail("typeServiceMail", "idCompteMail"), new DonneesProvisionneesSTPfsMail("adresseMail", 23123, 23214, "niveauRestriction"));
    StPfsOlt stPfsOlt = new StPfsOlt("idST", Statut.ACTIF.name(), clientOperateur, noCompte, new DonneesIdentificationSTPfsOlt("nomOlt", "positionCarte", "positionRelativePort", "ont1", "GPON"), new DonneesProvisionneesSTPfsOlt("codeAccesTechnique", "vlan", "123456789"));
    StPfsSam stPfsSam = new StPfsSam("idST", Statut.ACTIF.name(), clientOperateur, noCompte, new DonneesIdentificationStPfsSam("identifiantFonctionnelPa"), new DonneesProvisionneesStPfsSam("idCompteIms", "noTelephone", "typeUsage", "impiFixe", "motDePasseIms", "sipUri", "telUri", "nom", "prenom", "nomPrenomCourt", "niveauRestriction", "notificationSupension", "optionAppelSurTaxes"));
    StPfsClf stPfsClf = new StPfsClf("idST", Statut.ACTIF.name(), clientOperateur, noCompte, new DonneesIdentificationStPfsClf("identifiantFonctionnelPa"), new DonneesProvisionneesStPfsClf("impiFixe", "adresseIpClf", "codeInsee"));
    StPfsPnf stPfsPnf = new StPfsPnf("idST", Statut.ACTIF.name(), clientOperateur, noCompte, new DonneesIdentificationStPfsPnf("identifiantFonctionnelPa"), new DonneesProvisionneesStPfsPnf("noTelephone", "prefixeRoutage"));
    StPfsVmsStw stPfsVmsStw = new StPfsVmsStw("idST", Statut.ACTIF.name(), clientOperateur, noCompte, new DonneesIdentificationSTPfsVmsStw("identifiantFonctionnelPa"), new DonneesProvisionneesSTPfsVmsStw("noTelephone", "typeUsage", "ligneMarche", "adresseMail", "nomPrenomUtilisateur"));
    StPfsAcsIad stPfsAcsIad = new StPfsAcsIad("idST", Statut.ACTIF.name(), clientOperateur, noCompte, new DonneesIdentificationSTPfsAcsIad("noEquipement", "typeEquipement"), new DonneesProvisionneesSTPfsAcsIad("numeroSerie"));
    StPfsEnum stPfsEnum = new StPfsEnum("idST", Statut.ACTIF.name(), clientOperateur, noCompte, new DonneesIdentificationStPfsEnum("identifiantFonctionnelPa"), new DonneesProvisionneesStPfsEnum("noTelephone_p", "sipUri"));
    ArrayList<ServiceTechnique> listeServiceTechnique = new ArrayList<>();
    listeServiceTechnique.add(stLienAllocationCommercial);
    listeServiceTechnique.add(StPfsFqdn);
    listeServiceTechnique.add(stPfsVmsCvm);
    listeServiceTechnique.add(stPfsMail);
    listeServiceTechnique.add(stPfsOlt);
    listeServiceTechnique.add(stPfsSam);
    listeServiceTechnique.add(stPfsClf);
    listeServiceTechnique.add(stPfsPnf);
    listeServiceTechnique.add(stPfsVmsStw);
    listeServiceTechnique.add(stPfsAcsIad);
    listeServiceTechnique.add(stPfsEnum);

    createMockRSTserviceTechniqueLireTousParPfiFiltrerInactif(_tracabilite, retourOk, listeServiceTechnique, clientOperateur, noCompte);

    Ressource ressource = new Ressource(stLienAllocationCommercial.getIdRessource(), stLienAllocationCommercial.getTypeRessource(), stLienAllocationCommercial.getStatut());
    createMockRESressourceLireUn(_tracabilite, retourOk, ressource);

    Fqdn fqdn = new Fqdn();
    fqdn.setNomFQDN("name"); //$NON-NLS-1$
    fqdn.setStatutTechnique("OUVERT"); //$NON-NLS-1$
    Set<String> listeCoeurImsDesservis = new HashSet<>();
    listeCoeurImsDesservis.add("1"); //$NON-NLS-1$
    listeCoeurImsDesservis.add("2"); //$NON-NLS-1$
    fqdn.setListeCoeurImsDesservis(listeCoeurImsDesservis);
    createMockRESFqdnLireUn(_tracabilite, retourOk, fqdn);

    IndexRecherchePfi indexRecherchePfi = new IndexRecherchePfi(clientOperateur, noCompte);
    List<IndexRecherchePfi> listeIndexRecherchePfi = Arrays.asList(indexRecherchePfi);
    createMockAIRindexRechercherPfiLireUn(_tracabilite, retourOk, listeIndexRecherchePfi, clientOperateur, noCompte);

    List<ServiceTechniqueEquipementLegacy> response25 = new ArrayList<>();
    ServiceTechniqueEquipementLegacy equipLeg = __podam.manufacturePojo(ServiceTechniqueEquipementLegacy.class);
    response25.add(equipLeg);
    PowerMock.expectNew(OSSFAI_SI025_LireStEquipementLegacyParSnBuilder.class).andReturn(_si025BuilderMock);
    EasyMock.expect(_si025BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_si025BuilderMock);
    EasyMock.expect(_si025BuilderMock.numeroSerie(EasyMock.anyObject(String.class))).andReturn(_si025BuilderMock);
    EasyMock.expect(_si025BuilderMock.build()).andReturn(_si025Mock);
    EasyMock.expect(_si025Mock.execute(EasyMock.anyObject(PI0035_RecupererPfiComplet.class))).andReturn(response25);

    PowerMock.replayAll();
    Pair<Retour, PI0035_PFIComplet> retourBL100 = Whitebox.invokeMethod(_processInstance, "PI0035_BL100_Recuperer", _tracabilite, clientOperateur, noCompte); //$NON-NLS-1$
    PowerMock.verify();

    //PFIComplet expected in ReponseFonctionnelle
    PI0035_PFIComplet pfiCompletExpected = PI0035_PFIComplet.buildFromPFI(pfi);
    List<ModificationCommerciale> listeModificationCommerciale = listeCommandeComposite.get(0).getListeModificationCommerciale();
    List<ModificationTechnique> listeModificationTechnique = listeCommandeComposite.get(0).getListeModificationTechnique();
    List<PI0035_ModificationCommerciale> pfiCompletModCommList = pfiCompletExpected.getModificationCommerciale();
    List<PI0035_ModificationTechnique> pfiCompletModTechList = pfiCompletExpected.getModificationTechnique();
    for (ModificationCommerciale modComm : listeModificationCommerciale)
    {
      PI0035_ModificationCommerciale pfiCompletModComm = PI0035_ModificationCommerciale.builfFromModificationCommerciale(modComm);
      pfiCompletModCommList.add(pfiCompletModComm);
    }
    for (ModificationTechnique modTech : listeModificationTechnique)
    {
      PI0035_ModificationTechnique pfiCompletModTech = PI0035_ModificationTechnique.builfFromModificationTechnique(modTech);
      pfiCompletModTechList.add(pfiCompletModTech);
    }
    pfiCompletExpected.setModificationCommerciale(pfiCompletModCommList);
    pfiCompletExpected.setModificationTechnique(pfiCompletModTechList);

    PI0035_ServiceTechnique pfiCompletST = PI0035_ServiceTechnique.buildFromServiceTechnique(stLienAllocationCommercial);
    PI0035_ServiceTechnique pfiCompletSTPfsFqdn = PI0035_ServiceTechnique.buildFromServiceTechnique(StPfsFqdn);
    PI0035_ServiceTechnique pfiCompletSTPfsVmsCvm = PI0035_ServiceTechnique.buildFromServiceTechnique(stPfsVmsCvm);
    PI0035_ServiceTechnique pfiCompletSTPfsMail = PI0035_ServiceTechnique.buildFromServiceTechnique(stPfsMail);
    PI0035_ServiceTechnique pfiCompletSTPfsOlt = PI0035_ServiceTechnique.buildFromServiceTechnique(stPfsOlt);
    PI0035_ServiceTechnique pfiCompletSTPfsSam = PI0035_ServiceTechnique.buildFromServiceTechnique(stPfsSam);
    PI0035_ServiceTechnique pfiCompletSTPfsClf = PI0035_ServiceTechnique.buildFromServiceTechnique(stPfsClf);
    PI0035_ServiceTechnique pfiCompletSTPfsPnf = PI0035_ServiceTechnique.buildFromServiceTechnique(stPfsPnf);
    PI0035_ServiceTechnique pfiCompletSTPfsVmsStw = PI0035_ServiceTechnique.buildFromServiceTechnique(stPfsVmsStw);
    PI0035_ServiceTechnique pfiCompletSTPfsAcsIad = PI0035_ServiceTechnique.buildFromServiceTechnique(stPfsAcsIad);
    PI0035_ServiceTechnique pfiCompletSTPfsEnum = PI0035_ServiceTechnique.buildFromServiceTechnique(stPfsEnum);

    pfiCompletExpected.setSt(Arrays.asList(pfiCompletST, pfiCompletSTPfsFqdn, pfiCompletSTPfsVmsCvm, pfiCompletSTPfsMail, pfiCompletSTPfsOlt, pfiCompletSTPfsSam, pfiCompletSTPfsClf, pfiCompletSTPfsPnf, pfiCompletSTPfsVmsStw, pfiCompletSTPfsAcsIad, pfiCompletSTPfsEnum));

    PI0035_Ressource pfiCompletRessource = PI0035_Ressource.buildFromRessource(ressource);
    pfiCompletExpected.setRessource(Arrays.asList(pfiCompletRessource));

    PI0035_IndexRecherche pfiCompletIndexRecherche = PI0035_IndexRecherche.buildFromIndexRecherPFI(indexRecherchePfi);
    pfiCompletExpected.setIndexRecherche(Arrays.asList(pfiCompletIndexRecherche));

    List<PI0035_ServiceTechniqueLegacy> listPI0035_StLegacyEquipement = new ArrayList<>();
    PI0035_ServiceTechniqueLegacy pi0035_ServiceTechniqueLegacy = PI0035_ServiceTechniqueLegacy.buildFromServiceTechniqueEquipementLegacy(equipLeg);
    if (nonNull(pi0035_ServiceTechniqueLegacy))
    {
      listPI0035_StLegacyEquipement.add(pi0035_ServiceTechniqueLegacy);
    }
    listPI0035_StLegacyEquipement.add(new PI0035_StLegacyFqdn(StatutLegacy.INACTIF.name(), null, null, null));
    pfiCompletExpected.setStLegacy(listPI0035_StLegacyEquipement);
    PI0035_DonneesTopologieReseaux pi0035_DonneesTopologieReseaux = PI0035_DonneesTopologieReseaux.buildFromFqdn(fqdn);
    pfiCompletExpected.setDonneesTopologieReseaux(Arrays.asList(pi0035_DonneesTopologieReseaux));

    assertEquals(retourOk, retourBL100._first);
    assertEquals(pfiCompletExpected, retourBL100._second);
    PI0035_DonneesTopologieReseauxFqdn actualDonnesTopologieReseauxFqdn = (PI0035_DonneesTopologieReseauxFqdn) retourBL100._second.getDonneesTopologieReseaux().get(0);
    assertEquals(listeCoeurImsDesservis, actualDonnesTopologieReseauxFqdn.getListeCoeurImsDesservis());
  }

  /**
   * Tests the nominal case of PI0035_BL100_Recuperer method
   *
   * <b>Inputs:</b> All valid inputs<br>
   * TypeRessource.RACCO<br>
   * <b>Expected:</b> Retour{OK} and valid PFIComplet <br>
   *
   * @throws Exception
   *           on errors
   *
   */
  @Test
  public void PI0035_BL100_Recuperer_OK_002() throws Exception
  {
    Retour retourOk = RetourFactoryForTU.createOkRetour();

    String clientOperateur = "BSS_GP"; //$NON-NLS-1$
    String noCompte = "123456789"; //$NON-NLS-1$

    PFI pfi = __podam.manufacturePojo(PFI.class);
    //to avoid IllegalArgumentException due to the autoset of the PFI
    for (PA pa : pfi.getPa())
    {
      pa.setTypePA(TypePA.COMPTE_ACCES.name());
    }

    createMockRPGpfiLireUnFiltrerOCResilie(_tracabilite, retourOk, pfi, clientOperateur, noCompte);

    List<CommandeComposite> listeCommandeComposite = Arrays.asList(__podam.manufacturePojo(CommandeComposite.class));
    createMockCMDcommandeCompositeGererLireTousModCommParPfiFiltrerTraite(_tracabilite, retourOk, listeCommandeComposite, clientOperateur, noCompte);

    StLienAllocationCommercial stLienAllocationCommercial = new StLienAllocationCommercial("idST", Statut.ACTIF.name(), clientOperateur, noCompte, TypeObjetCommercial.PFI.name(), "BSS_GP", noCompte, "idRessource", TypeRessource.RACCO.name()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    List<ServiceTechnique> listeServiceTechnique = Arrays.asList(stLienAllocationCommercial);
    createMockRSTserviceTechniqueLireTousParPfiFiltrerInactif(_tracabilite, retourOk, listeServiceTechnique, clientOperateur, noCompte);

    Ressource ressource = new Ressource(stLienAllocationCommercial.getIdRessource(), stLienAllocationCommercial.getTypeRessource(), stLienAllocationCommercial.getStatut());
    ressource.setRessourceRaccordement(new RessourceRaccordement(TypeRaccordement.P2P.name(), "FTTOH-FIXED-10000-10000-MONO-DT-E-BT")); //$NON-NLS-1$
    AccesTechnique accesTechnique = new AccesTechnique("", "", TypeRaccordement.P2P.name(), null, null); //$NON-NLS-1$ //$NON-NLS-2$
    RessourceRaccordementComposite ressourceRaccordementComposite = new RessourceRaccordementComposite(ressource, accesTechnique);
    createMockRESressourceRaccordementCompositeLireUn(_tracabilite, retourOk, ressource, ressourceRaccordementComposite);

    RessourceAggrege ressourceAggrege = new RessourceAggregeP2P("", 0, 0, 0); //$NON-NLS-1$
    mockBL2500(stLienAllocationCommercial.getIdRessource(), retourOk, new BL2500_Return(ressource, accesTechnique, ressourceAggrege));

    IndexRecherchePfi indexRecherchePfi = new IndexRecherchePfi(clientOperateur, noCompte);
    List<IndexRecherchePfi> listeIndexRecherchePfi = Arrays.asList(indexRecherchePfi);
    createMockAIRindexRechercherPfiLireUn(_tracabilite, retourOk, listeIndexRecherchePfi, clientOperateur, noCompte);

    PowerMock.replayAll();
    Pair<Retour, PI0035_PFIComplet> retourBL100 = Whitebox.invokeMethod(_processInstance, "PI0035_BL100_Recuperer", _tracabilite, clientOperateur, noCompte); //$NON-NLS-1$
    PowerMock.verify();

    //PFIComplet expected in ReponseFonctionnelle
    PI0035_PFIComplet pfiCompletExpected = PI0035_PFIComplet.buildFromPFI(pfi);
    List<ModificationCommerciale> listeModificationCommerciale = listeCommandeComposite.get(0).getListeModificationCommerciale();
    List<ModificationTechnique> listeModificationTechnique = listeCommandeComposite.get(0).getListeModificationTechnique();
    List<PI0035_ModificationCommerciale> pfiCompletModCommList = pfiCompletExpected.getModificationCommerciale();
    List<PI0035_ModificationTechnique> pfiCompletModTechList = pfiCompletExpected.getModificationTechnique();
    for (ModificationCommerciale modComm : listeModificationCommerciale)
    {
      PI0035_ModificationCommerciale pfiCompletModComm = PI0035_ModificationCommerciale.builfFromModificationCommerciale(modComm);
      pfiCompletModCommList.add(pfiCompletModComm);
    }
    for (ModificationTechnique modTech : listeModificationTechnique)
    {
      PI0035_ModificationTechnique pfiCompletModTech = PI0035_ModificationTechnique.builfFromModificationTechnique(modTech);
      pfiCompletModTechList.add(pfiCompletModTech);
    }
    pfiCompletExpected.setModificationCommerciale(pfiCompletModCommList);
    pfiCompletExpected.setModificationTechnique(pfiCompletModTechList);

    PI0035_ServiceTechnique pfiCompletST = PI0035_ServiceTechnique.buildFromServiceTechnique(stLienAllocationCommercial);
    pfiCompletExpected.setSt(Arrays.asList(pfiCompletST));
    pfiCompletExpected.setStLegacy(Arrays.asList(new PI0035_StLegacyFqdn(StatutLegacy.INACTIF.name(), null, null, null)));
    pfiCompletExpected.setDonneesTopologieReseaux(new ArrayList<>());
    PI0035_AccesTechnique pi0035_accesTechnique = PI0035_AccesTechnique.buildFromAccesTechnique(ressourceRaccordementComposite.getAccesTechnique());

    PI0035_RessourceRaccordement ressourceRaccordement = PI0035_RessourceRaccordement.buildFromRessource(ressource);
    ressourceRaccordement.setAccesTechnique(pi0035_accesTechnique);

    PI0035_RessourceAggregeP2P ressourceAggregeP2P = PI0035_RessourceAggregeP2P.buildFromRessourceAggrege(RessourceAggregeP2P.class.cast(ressourceAggrege));
    ressourceRaccordement = new PI0035_RessourceRaccordementP2P(ressourceRaccordement.getIdRessource(), ressourceRaccordement.getTypeRessource(), ressourceRaccordement.getStatut(), ressourceRaccordement.getIdST(), ressourceRaccordement.getDateCreation(), ressourceRaccordement.getDateModification(), ressourceRaccordement.getTypeRaccordement(), ressourceRaccordement.getAdresseDonnee(), ressourceRaccordement.getNomNR(), ressourceRaccordement.getIdRessourceLie(), ressourceRaccordement.getAccesTechnique(), ressourceAggregeP2P);

    pfiCompletExpected.setRessource(Arrays.asList(ressourceRaccordement));

    PI0035_IndexRecherche pfiCompletIndexRecherche = PI0035_IndexRecherche.buildFromIndexRecherPFI(indexRecherchePfi);
    pfiCompletExpected.setIndexRecherche(Arrays.asList(pfiCompletIndexRecherche));

    assertEquals(retourOk, retourBL100._first);
    assertEquals(pfiCompletExpected, retourBL100._second);
  }

  /**
   * Tests all the PI0035_RecupererPFIComplet process when request is invalid
   *
   * <b>Inputs:</b> Request without parameters<br>
   * <b>Expected:</b> Request response : KO_00400
   * "{\"retour\":{\"resultat\":\"KO\",\"categorie\":\"CAT-3\",\"diagnostic\":\"NON_RESPECT_STI\",\"libelle\":\"Paramètre
   * [clientOperateur] null ou vide dans la requête.\"}}"<br>
   * / After continueProcess : {OK}
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void PI0035_RecupererPFIComplet_KO_001() throws Throwable
  {
    Request request = prepareRequest(null, null);

    Retour retourBL005 = RetourFactoryForTU.createOkRetour();
    ConnectorResponse<Retour, Nothing> resultRex = new ConnectorResponse<>(retourBL005, null);
    // Used in BL005
    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxy);
    EasyMock.expect(_rexProxy.erreurSpiritCreer(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(CreateErreurSpiritRequest.class))).andReturn(resultRex);

    PowerMock.replayAll();
    _processInstance.run(request);
    _processInstance.continueProcess(request, _tracabilite);
    PowerMock.verify();

    IRavelResponse response = request.getResponse();

    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString("PI0035.BL001.ParameterNullOrEmpty"), ParameterUrl.clientOperateur.name()), "PI0035_BL001_VerifierDonnees"); //$NON-NLS-1$ //$NON-NLS-2$

    PI0035_Retour pi0035Retour = new PI0035_Retour(RetourConverter.convertToJsonRetour(retour));
    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(RavelJsonTools.getInstance().toJson(pi0035Retour, PI0035_Retour.class));

    assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());
    assertEquals(retourBL005, _processInstance.getRetour());
  }

  /**
   * Tests all the PI0035_RecupererPFIComplet process when BL100 is KO
   *
   * <b>Inputs:</b> RPGProxy mock returns KO<br>
   * <b>Expected:</b> Request response : KO_00400
   * "{\"retour\":{\"resultat\":\"KO\",\"categorie\":\"CAT-4\",\"diagnostic\":\"DONNEE_INVALIDE\",\"libelle\":\"\"}}"<br>
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void PI0035_RecupererPFIComplet_KO_002() throws Throwable
  {
    String clientOperateur = "BSS_GP"; //$NON-NLS-1$
    String noCompte = "123456789"; //$NON-NLS-1$
    Request request = prepareRequest(clientOperateur, noCompte);
    fillAllRequestHeaders(request);

    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INVALIDE, StringConstants.EMPTY_STRING, null);
    createMockRPGpfiLireUnFiltrerOCResilie(_tracabilite, retour, null, clientOperateur, noCompte);

    Retour retourBL005 = RetourFactoryForTU.createOkRetour();
    ConnectorResponse<Retour, Nothing> resultRex = new ConnectorResponse<>(retourBL005, null);
    // Used in BL005
    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxy);
    EasyMock.expect(_rexProxy.erreurSpiritCreer(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(CreateErreurSpiritRequest.class))).andReturn(resultRex);

    PowerMock.replayAll();
    _processInstance.run(request);
    _processInstance.continueProcess(request, _tracabilite);
    PowerMock.verify();

    IRavelResponse response = request.getResponse();

    PI0035_Retour pi0035Retour = new PI0035_Retour(RetourConverter.convertToJsonRetour(retour));
    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(RavelJsonTools.getInstance().toJson(pi0035Retour, PI0035_Retour.class));

    assertEquals(ErrorCode.KO_00404, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());
    assertEquals(retourBL005, _processInstance.getRetour());
  }

  /**
   * Tests all the PI0035_RecupererPFIComplet process when BL100 is KO
   *
   * <b>Inputs:</b> CMDProxy mock returns KO<br>
   * <b>Expected:</b> Request response : KO_00400
   * "{\"retour\":{\"resultat\":\"KO\",\"categorie\":\"CAT-4\",\"diagnostic\":\"DONNEE_INVALIDE\",\"libelle\":\"\"}}"<br>
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void PI0035_RecupererPFIComplet_KO_003() throws Throwable
  {
    Retour retourOk = RetourFactoryForTU.createOkRetour();

    String clientOperateur = "BSS_GP"; //$NON-NLS-1$
    String noCompte = "123456789"; //$NON-NLS-1$
    Request request = prepareRequest(clientOperateur, noCompte);
    fillAllRequestHeaders(request);

    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INVALIDE, StringConstants.EMPTY_STRING, null);
    PFI pfi = __podam.manufacturePojo(PFI.class);
    //to avoid IllegalArgumentException due to the autoset of the PFI
    for (PA sa : pfi.getPa())
    {
      sa.setTypePA(TypePA.COMPTE_ACCES.name());
    }

    createMockRPGpfiLireUnFiltrerOCResilie(_tracabilite, retourOk, pfi, clientOperateur, noCompte);
    createMockCMDcommandeCompositeGererLireTousModCommParPfiFiltrerTraite(_tracabilite, retour, null, clientOperateur, noCompte);

    Retour retourBL005 = RetourFactoryForTU.createOkRetour();
    ConnectorResponse<Retour, Nothing> resultRex = new ConnectorResponse<>(retourBL005, null);
    // Used in BL005
    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxy);
    EasyMock.expect(_rexProxy.erreurSpiritCreer(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(CreateErreurSpiritRequest.class))).andReturn(resultRex);

    PowerMock.replayAll();
    _processInstance.run(request);
    _processInstance.continueProcess(request, _tracabilite);
    PowerMock.verify();

    IRavelResponse response = request.getResponse();

    PI0035_Retour pi0035Retour = new PI0035_Retour(RetourConverter.convertToJsonRetour(retour));
    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(RavelJsonTools.getInstance().toJson(pi0035Retour, PI0035_Retour.class));

    assertEquals(ErrorCode.KO_00404, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());
    assertEquals(retourBL005, _processInstance.getRetour());
  }

  /**
   * Tests all the PI0035_RecupererPFIComplet process when BL100 is KO
   *
   * <b>Inputs:</b> RSTProxy mock returns KO<br>
   * <b>Expected:</b> Request response : KO_00400
   * "{\"retour\":{\"resultat\":\"KO\",\"categorie\":\"CAT-4\",\"diagnostic\":\"DONNEE_INVALIDE\",\"libelle\":\"\"}}"<br>
   * After continueProcess: {OK}
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void PI0035_RecupererPFIComplet_KO_004() throws Throwable
  {
    Retour retourOk = RetourFactoryForTU.createOkRetour();

    String clientOperateur = "BSS_GP"; //$NON-NLS-1$
    String noCompte = "123456789"; //$NON-NLS-1$
    Request request = prepareRequest(clientOperateur, noCompte);
    fillAllRequestHeaders(request);

    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INVALIDE, StringConstants.EMPTY_STRING, null);
    PFI pfi = __podam.manufacturePojo(PFI.class);
    //to avoid IllegalArgumentException due to the autoset of the PFI
    for (PA sa : pfi.getPa())
    {
      sa.setTypePA(TypePA.COMPTE_ACCES.name());
    }

    createMockRPGpfiLireUnFiltrerOCResilie(_tracabilite, retourOk, pfi, clientOperateur, noCompte);
    List<CommandeComposite> listeCommandeComposite = Arrays.asList(__podam.manufacturePojo(CommandeComposite.class));
    createMockCMDcommandeCompositeGererLireTousModCommParPfiFiltrerTraite(_tracabilite, retourOk, listeCommandeComposite, clientOperateur, noCompte);
    createMockRSTserviceTechniqueLireTousParPfiFiltrerInactif(_tracabilite, retour, null, clientOperateur, noCompte);

    Retour retourBL005 = RetourFactoryForTU.createOkRetour();
    ConnectorResponse<Retour, Nothing> resultRex = new ConnectorResponse<>(retourBL005, null);
    // Used in BL005
    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxy);
    EasyMock.expect(_rexProxy.erreurSpiritCreer(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(CreateErreurSpiritRequest.class))).andReturn(resultRex);

    PowerMock.replayAll();
    _processInstance.run(request);
    _processInstance.continueProcess(request, _tracabilite);
    PowerMock.verify();

    IRavelResponse response = request.getResponse();

    PI0035_Retour pi0035Retour = new PI0035_Retour(RetourConverter.convertToJsonRetour(retour));
    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(RavelJsonTools.getInstance().toJson(pi0035Retour, PI0035_Retour.class));

    assertEquals(ErrorCode.KO_00404, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());
    assertEquals(retourBL005, _processInstance.getRetour());
  }

  /**
   * Tests all the PI0035_RecupererPFIComplet process when BL100 is KO
   *
   * <b>Inputs:</b> RESProxy mock returns KO<br>
   * <b>Expected:</b> Request response : KO_00400
   * "{\"retour\":{\"resultat\":\"KO\",\"categorie\":\"CAT-4\",\"diagnostic\":\"DONNEE_INVALIDE\",\"libelle\":\"\"}}"<br>
   * After continueProcess: {OK}
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void PI0035_RecupererPFIComplet_KO_005() throws Throwable
  {
    Retour retourOk = RetourFactoryForTU.createOkRetour();

    String clientOperateur = "BSS_GP"; //$NON-NLS-1$
    String noCompte = "123456789"; //$NON-NLS-1$
    Request request = prepareRequest(clientOperateur, noCompte);
    fillAllRequestHeaders(request);

    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INVALIDE, StringConstants.EMPTY_STRING, null);
    PFI pfi = __podam.manufacturePojo(PFI.class);
    //to avoid IllegalArgumentException due to the autoset of the PFI
    for (PA sa : pfi.getPa())
    {
      sa.setTypePA(TypePA.COMPTE_ACCES.name());
    }

    createMockRPGpfiLireUnFiltrerOCResilie(_tracabilite, retourOk, pfi, clientOperateur, noCompte);

    List<CommandeComposite> listeCommandeComposite = Arrays.asList(__podam.manufacturePojo(CommandeComposite.class));
    createMockCMDcommandeCompositeGererLireTousModCommParPfiFiltrerTraite(_tracabilite, retourOk, listeCommandeComposite, clientOperateur, noCompte);

    StLienAllocationCommercial stLienAllocationCommercial = new StLienAllocationCommercial("idST", Statut.ACTIF.name(), clientOperateur, noCompte, TypeObjetCommercial.PFI.name(), "BSS_GP", noCompte, "idRessource", TypeRessource.COMPTE_MAIL.name()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    List<ServiceTechnique> listeServiceTechnique = Arrays.asList(stLienAllocationCommercial);
    createMockRSTserviceTechniqueLireTousParPfiFiltrerInactif(_tracabilite, retourOk, listeServiceTechnique, clientOperateur, noCompte);

    Ressource ressource = new Ressource(stLienAllocationCommercial.getIdRessource(), stLienAllocationCommercial.getTypeRessource(), stLienAllocationCommercial.getStatut());
    createMockRESressourceLireUn(_tracabilite, retour, ressource);

    Retour retourBL005 = RetourFactoryForTU.createOkRetour();
    ConnectorResponse<Retour, Nothing> resultRex = new ConnectorResponse<>(retourBL005, null);
    // Used in BL005
    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxy);
    EasyMock.expect(_rexProxy.erreurSpiritCreer(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(CreateErreurSpiritRequest.class))).andReturn(resultRex);

    PowerMock.replayAll();
    _processInstance.run(request);
    _processInstance.continueProcess(request, _tracabilite);
    PowerMock.verify();

    IRavelResponse response = request.getResponse();

    PI0035_Retour pi0035Retour = new PI0035_Retour(RetourConverter.convertToJsonRetour(retour));
    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(RavelJsonTools.getInstance().toJson(pi0035Retour, PI0035_Retour.class));

    assertEquals(ErrorCode.KO_00404, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());
    assertEquals(retourBL005, _processInstance.getRetour());
  }

  /**
   * Tests all the PI0035_RecupererPFIComplet process when BL100 is KO
   *
   * <b>Inputs:</b> AIRProxy mock returns KO<br>
   * <b>Expected:</b> Request response : KO_00400
   * "{\"retour\":{\"resultat\":\"KO\",\"categorie\":\"CAT-4\",\"diagnostic\":\"DONNEE_INVALIDE\",\"libelle\":\"\"}}"<br>
   * After continueProcess: {OK}
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void PI0035_RecupererPFIComplet_KO_006() throws Throwable
  {
    Retour retourOk = RetourFactoryForTU.createOkRetour();

    String clientOperateur = "BSS_GP"; //$NON-NLS-1$
    String noCompte = "123456789"; //$NON-NLS-1$
    Request request = prepareRequest(clientOperateur, noCompte);
    fillAllRequestHeaders(request);

    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INVALIDE, StringConstants.EMPTY_STRING, null);
    PFI pfi = __podam.manufacturePojo(PFI.class);
    //to avoid IllegalArgumentException due to the autoset of the PFI
    for (PA sa : pfi.getPa())
    {
      sa.setTypePA(TypePA.COMPTE_ACCES.name());
    }

    createMockRPGpfiLireUnFiltrerOCResilie(_tracabilite, retourOk, pfi, clientOperateur, noCompte);

    List<CommandeComposite> listeCommandeComposite = Arrays.asList(__podam.manufacturePojo(CommandeComposite.class));
    createMockCMDcommandeCompositeGererLireTousModCommParPfiFiltrerTraite(_tracabilite, retourOk, listeCommandeComposite, clientOperateur, noCompte);

    StLienAllocationCommercial stLienAllocationCommercial = new StLienAllocationCommercial("idST", Statut.ACTIF.name(), clientOperateur, noCompte, TypeObjetCommercial.PFI.name(), "BSS_GP", noCompte, "idRessource", TypeRessource.COMPTE_MAIL.name()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    List<ServiceTechnique> listeServiceTechnique = Arrays.asList(stLienAllocationCommercial);
    createMockRSTserviceTechniqueLireTousParPfiFiltrerInactif(_tracabilite, retourOk, listeServiceTechnique, clientOperateur, noCompte);

    Ressource ressource = new Ressource(stLienAllocationCommercial.getIdRessource(), stLienAllocationCommercial.getTypeRessource(), stLienAllocationCommercial.getStatut());
    createMockRESressourceLireUn(_tracabilite, retourOk, ressource);

    createMockAIRindexRechercherPfiLireUn(_tracabilite, retour, null, clientOperateur, noCompte);

    Retour retourBL005 = RetourFactoryForTU.createOkRetour();
    ConnectorResponse<Retour, Nothing> resultRex = new ConnectorResponse<>(retourBL005, null);
    // Used in BL005
    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxy);
    EasyMock.expect(_rexProxy.erreurSpiritCreer(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(CreateErreurSpiritRequest.class))).andReturn(resultRex);

    PowerMock.replayAll();
    _processInstance.run(request);
    _processInstance.continueProcess(request, _tracabilite);
    PowerMock.verify();

    IRavelResponse response = request.getResponse();

    PI0035_Retour pi0035Retour = new PI0035_Retour(RetourConverter.convertToJsonRetour(retour));
    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(RavelJsonTools.getInstance().toJson(pi0035Retour, PI0035_Retour.class));

    assertEquals(ErrorCode.KO_00404, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());
    assertEquals(retourBL005, _processInstance.getRetour());
  }

  /**
   * Tests all the PI0035_RecupererPFIComplet process when BL100 is KO with clientOperateur = BSS_ENT
   *
   * <b>Inputs:</b> RPGProxy mock returns KO<br>
   * <b>Expected:</b> Request response : KO_00400
   * "{\"retour\":{\"resultat\":\"KO\",\"categorie\":\"CAT-4\",\"diagnostic\":\"DONNEE_INVALIDE\",\"libelle\":\"\"}}"<br>
   * After continueProcess: {OK}
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void PI0035_RecupererPFIComplet_KO_007() throws Throwable
  {
    String clientOperateur = "BSS_ENT"; //$NON-NLS-1$
    String noCompte = "123456789"; //$NON-NLS-1$
    Request request = prepareRequest(clientOperateur, noCompte);
    fillAllRequestHeaders(request);

    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INVALIDE, StringConstants.EMPTY_STRING, null);
    createMockRPGpfiLireUnFiltrerOCResilie(_tracabilite, retour, null, clientOperateur, noCompte);

    Retour retourBL005 = RetourFactoryForTU.createOkRetour();
    ConnectorResponse<Retour, Nothing> resultRex = new ConnectorResponse<>(retourBL005, null);
    // Used in BL005
    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxy);
    EasyMock.expect(_rexProxy.erreurSpiritCreer(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(CreateErreurSpiritRequest.class))).andReturn(resultRex);

    PowerMock.replayAll();
    _processInstance.run(request);
    _processInstance.continueProcess(request, _tracabilite);
    PowerMock.verify();

    IRavelResponse response = request.getResponse();

    PI0035_Retour pi0035Retour = new PI0035_Retour(RetourConverter.convertToJsonRetour(retour));
    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(RavelJsonTools.getInstance().toJson(pi0035Retour, PI0035_Retour.class));

    assertEquals(ErrorCode.KO_00404, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());
    assertEquals(retourBL005, _processInstance.getRetour());
  }

  /**
   * Tests all the PI0035_RecupererPFIComplet process when BL100 is KO CAT-10 with clientOperateur = BSS_ENT
   *
   * <b>Inputs:</b> RPGProxy mock returns KO<br>
   * <b>Expected:</b> Request response : KO_00500
   * "{\"retour\":{\"resultat\":\"KO\",\"categorie\":\"CAT-10\",\"diagnostic\":\"TRAITEMENT_ARRETE\",\"libelle\":\"Unexpected
   * error in rpg database connector:\"}}"<br>
   * After continueProcess: {OK}
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void PI0035_RecupererPFIComplet_KO_008() throws Throwable
  {
    String clientOperateur = "BSS_ENT"; //$NON-NLS-1$
    String noCompte = "123456789"; //$NON-NLS-1$
    Request request = prepareRequest(clientOperateur, noCompte);
    fillAllRequestHeaders(request);

    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegConsts.TRAITEMENT_ARRETE, "Unexpected error in rpg database connector", null); //$NON-NLS-1$
    createMockRPGpfiLireUnFiltrerOCResilie(_tracabilite, retour, null, clientOperateur, noCompte);

    Retour retourBL005 = RetourFactoryForTU.createOkRetour();
    ConnectorResponse<Retour, Nothing> resultRex = new ConnectorResponse<>(retourBL005, null);
    // Used in BL005
    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxy);
    EasyMock.expect(_rexProxy.erreurSpiritCreer(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(CreateErreurSpiritRequest.class))).andReturn(resultRex);

    PowerMock.replayAll();
    _processInstance.run(request);
    _processInstance.continueProcess(request, _tracabilite);
    PowerMock.verify();

    IRavelResponse response = request.getResponse();

    PI0035_Retour pi0035Retour = new PI0035_Retour(RetourConverter.convertToJsonRetour(retour));
    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(RavelJsonTools.getInstance().toJson(pi0035Retour, PI0035_Retour.class));

    assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());
    assertEquals(retourBL005, _processInstance.getRetour());
  }

  /**
   * Tests all the PI0035_RecupererPFIComplet process when BL100 is KO CAT-2 with clientOperateur = BSS_ENT
   *
   * <b>Inputs:</b> RPGProxy mock returns KO<br>
   * <b>Expected:</b> Request response : KO_00503
   * "{\"retour\":{\"resultat\":\"KO\",\"categorie\":\"CAT-2\",\"diagnostic\":\"TRAITEMENT_ARRETE\",\"libelle\":\"Unexpected
   * error in rpg database connector:\"}}"<br>
   * After continueProcess: {OK}
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void PI0035_RecupererPFIComplet_KO_009() throws Throwable
  {
    String clientOperateur = "BSS_ENT"; //$NON-NLS-1$
    String noCompte = "123456789"; //$NON-NLS-1$
    Request request = prepareRequest(clientOperateur, noCompte);
    fillAllRequestHeaders(request);

    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegConsts.TRAITEMENT_ARRETE, "Unexpected error in rpg database connector", null); //$NON-NLS-1$
    createMockRPGpfiLireUnFiltrerOCResilie(_tracabilite, retour, null, clientOperateur, noCompte);

    Retour retourBL005 = RetourFactoryForTU.createOkRetour();
    ConnectorResponse<Retour, Nothing> resultRex = new ConnectorResponse<>(retourBL005, null);
    // Used in BL005
    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxy);
    EasyMock.expect(_rexProxy.erreurSpiritCreer(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(CreateErreurSpiritRequest.class))).andReturn(resultRex);

    PowerMock.replayAll();
    _processInstance.run(request);
    _processInstance.continueProcess(request, _tracabilite);
    PowerMock.verify();

    IRavelResponse response = request.getResponse();

    PI0035_Retour pi0035Retour = new PI0035_Retour(RetourConverter.convertToJsonRetour(retour));
    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(RavelJsonTools.getInstance().toJson(pi0035Retour, PI0035_Retour.class));

    assertEquals(ErrorCode.KO_00503, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());
    assertEquals(retourBL005, _processInstance.getRetour());
  }

  /**
   * Tests all the PI0035_RecupererPFIComplet process when request is invalid
   *
   * <b>Inputs:</b> Request without parameters<br>
   * <b>Expected:</b> Request response : KO_00400
   * "{\"retour\":{\"resultat\":\"KO\",\"categorie\":\"CAT-3\",\"diagnostic\":\"NON_RESPECT_STI\",\"libelle\":\"Paramètre
   * [clientOperateur] null ou vide dans la requête.\"}}"<br>
   * After continueProcess: {OK}
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void PI0035_RecupererPFIComplet_KO_010() throws Throwable
  {
    Request request = prepareRequest(null, null);

    Retour retourBL005 = RetourFactoryForTU.createOkRetour();
    ConnectorResponse<Retour, Nothing> resultRex = new ConnectorResponse<>(retourBL005, null);
    // Used in BL005
    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxy);
    EasyMock.expect(_rexProxy.erreurSpiritCreer(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(CreateErreurSpiritRequest.class))).andReturn(resultRex);

    PowerMock.replayAll();
    _processInstance.run(request);
    _processInstance.continueProcess(request, _tracabilite);
    _processInstance.getProcessContext().setState(State.ENDED);
    PowerMock.verify();

    IRavelResponse response = request.getResponse();

    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString("PI0035.BL001.ParameterNullOrEmpty"), ParameterUrl.clientOperateur.name()), "PI0035_BL001_VerifierDonnees"); //$NON-NLS-1$ //$NON-NLS-2$
    PI0035_Retour pi0035Retour = new PI0035_Retour(RetourConverter.convertToJsonRetour(retour));
    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(RavelJsonTools.getInstance().toJson(pi0035Retour, PI0035_Retour.class));

    assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());
    assertEquals(retourBL005, _processInstance.getRetour());
  }

  /**
   * Tests all the PI0035_RecupererPFIComplet process when BL100 is KO (empty retour) with clientOperateur = BSS_ENT
   *
   * <b>Inputs:</b> RPGProxy mock returns KO<br>
   * <b>Expected:</b> Request response : KO_00503
   * "{\"retour\":{\"resultat\":\"KO\",\"categorie\":\"\",\"diagnostic\":\"\",\"libelle\":\"\"}}"<br>
   * After continueProcess: {OK}
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void PI0035_RecupererPFIComplet_KO_011() throws Throwable
  {
    String clientOperateur = "BSS_ENT"; //$NON-NLS-1$
    String noCompte = "123456789"; //$NON-NLS-1$
    Request request = prepareRequest(clientOperateur, noCompte);
    fillAllRequestHeaders(request);

    Retour retour = RetourFactoryForTU.createNOK(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, null);
    createMockRPGpfiLireUnFiltrerOCResilie(_tracabilite, retour, null, clientOperateur, noCompte);

    Retour retourBL005 = RetourFactoryForTU.createOkRetour();
    ConnectorResponse<Retour, Nothing> resultRex = new ConnectorResponse<>(retourBL005, null);
    // Used in BL005
    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxy);
    EasyMock.expect(_rexProxy.erreurSpiritCreer(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(CreateErreurSpiritRequest.class))).andReturn(resultRex);

    PowerMock.replayAll();
    _processInstance.run(request);
    _processInstance.continueProcess(request, _tracabilite);
    PowerMock.verify();

    IRavelResponse response = request.getResponse();

    PI0035_Retour pi0035Retour = new PI0035_Retour(RetourConverter.convertToJsonRetour(retour));
    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(RavelJsonTools.getInstance().toJson(pi0035Retour, PI0035_Retour.class));

    assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());
    assertEquals(retourBL005, _processInstance.getRetour());
  }

  /**
   * Non Nominal test for PI0035_RecupererPFIComplet: IdRaccordement is filled
   *
   * <b>Inputs:</b> PAs with type LIGNE FIXE are null<br>
   * <b>Expected:</b> Request response : OK_00404<br>
   * {\"retour\":{\"categorie\":\"CAT-4\",\"diagnostic\":\"DONNEE_INVALIDE\",\"libelle\":\"Réservation du raccordement
   * par le commercial non supporté pour le moment dans SPIRIT\",\"resultat\":\"NOK\"}} After continueProcess: {OK}
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void PI0035_RecupererPFIComplet_KO_012() throws Throwable
  {
    Retour retourOk = RetourFactoryForTU.createOkRetour();

    String clientOperateur = "BSS_GP"; //$NON-NLS-1$
    String noCompte = "123456789"; //$NON-NLS-1$
    Request request = prepareRequest(clientOperateur, noCompte);
    fillAllRequestHeaders(request);

    PFI pfi = __podam.manufacturePojo(PFI.class);
    List<EquipementDeclare> listEquiPfi = pfi.getEquipementDeclare();
    EquipementDeclare equipPfiLeg = new EquipementDeclare("noEquip", "noIdentif", "MODEM_DECODEUR_TV", com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, null, null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    listEquiPfi.add(equipPfiLeg);
    pfi.setEquipementDeclare(listEquiPfi);
    //to avoid IllegalArgumentException due to the autoset of the PFI
    for (PA pa : pfi.getPa())
    {
      pa.setTypePA(TypePA.COMPTE_ACCES.name());
    }

    createMockRPGpfiLireUnFiltrerOCResilie(_tracabilite, retourOk, pfi, clientOperateur, noCompte);

    List<CommandeComposite> listeCommandeComposite = Arrays.asList(__podam.manufacturePojo(CommandeComposite.class));
    createMockCMDcommandeCompositeGererLireTousModCommParPfiFiltrerTraite(_tracabilite, retourOk, listeCommandeComposite, clientOperateur, noCompte);

    StLienAllocationCommercial stLienAllocationCommercial = new StLienAllocationCommercial("idST", Statut.ACTIF.name(), clientOperateur, noCompte, TypeObjetCommercial.PFI.name(), "BSS_GP", noCompte, "idRessource", TypeRessource.COMPTE_MAIL.name()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    List<ServiceTechnique> listeServiceTechnique = Arrays.asList(stLienAllocationCommercial);
    createMockRSTserviceTechniqueLireTousParPfiFiltrerInactif(_tracabilite, retourOk, listeServiceTechnique, clientOperateur, noCompte);

    Ressource ressource = new Ressource(stLienAllocationCommercial.getIdRessource(), stLienAllocationCommercial.getTypeRessource(), stLienAllocationCommercial.getStatut());
    createMockRESressourceLireUn(_tracabilite, retourOk, ressource);

    IndexRecherchePfi indexRecherchePfi = new IndexRecherchePfi(clientOperateur, noCompte);
    List<IndexRecherchePfi> listeIndexRecherchePfi = Arrays.asList(indexRecherchePfi);
    createMockAIRindexRechercherPfiLireUn(_tracabilite, retourOk, listeIndexRecherchePfi, clientOperateur, noCompte);

    Retour retourBL005 = RetourFactoryForTU.createOkRetour();
    ConnectorResponse<Retour, Nothing> resultRex = new ConnectorResponse<>(retourBL005, null);
    // Used in BL005
    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxy);
    EasyMock.expect(_rexProxy.erreurSpiritCreer(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(CreateErreurSpiritRequest.class))).andReturn(resultRex);

    List<ServiceTechniqueEquipementLegacy> response25 = new ArrayList<>();
    ServiceTechniqueEquipementLegacy equipLeg = __podam.manufacturePojo(ServiceTechniqueEquipementLegacy.class);
    response25.add(equipLeg);
    PowerMock.expectNew(OSSFAI_SI025_LireStEquipementLegacyParSnBuilder.class).andReturn(_si025BuilderMock);
    EasyMock.expect(_si025BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_si025BuilderMock);
    EasyMock.expect(_si025BuilderMock.numeroSerie(EasyMock.anyObject(String.class))).andReturn(_si025BuilderMock);
    EasyMock.expect(_si025BuilderMock.build()).andReturn(_si025Mock);
    EasyMock.expect(_si025Mock.execute(EasyMock.anyObject(PI0035_RecupererPfiComplet.class))).andReturn(response25);

    // Mapping de l'object STLegacy de typeServiceTechnique = ACCESS_GPON
    LocalDateTime nowAccesGPON = DateTimeManager.getInstance().now();
    for (PA pa : pfi.getPa())
    {
      pa.setTypePA(TypePA.LIGNE_FIXE.name());
      pa.setStatut(Statut.ACTIF);
      pa.getPaTypeLigneFixe().getInfoBrutBssGp().getAccesTechnique().setTechnologieAcces(TechnologieAccess.FTTH.name());
      pa.getPaTypeLigneFixe().getInfoBrutBssGp().setIdRessourceReseauFTTX(String.valueOf(__podam.manufacturePojo(Long.class)));
      pa.setDateModification(nowAccesGPON);
      pa.setDateCreation(nowAccesGPON);
    }

    PowerMock.replayAll();
    _processInstance.run(request);
    _processInstance.continueProcess(request, _tracabilite);
    PowerMock.verify();

    String message = "Réservation du raccordement par le commercial non supporté pour le moment dans SPIRIT"; //$NON-NLS-1$
    Retour retourNOK = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.DONNEE_INVALIDE, message, "PI0035_BL100_Recuperer");
    PI0035_Retour pi0035Retour = new PI0035_Retour(RetourConverter.convertToJsonRetour(retourNOK));

    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(RavelJsonTools.getInstance().toJson(pi0035Retour, PI0035_Retour.class));

    IRavelResponse response = request.getResponse();
    assertEquals(ErrorCode.KO_00404, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());
    assertEquals(retourBL005, _processInstance.getRetour());
  }

  /**
   * Non Nominal test for PI0035_RecupererPFIComplet: activity OSSFAI_SI031_LireNrmId return NOK
   *
   * <b>Inputs:</b> Valid inputs<br>
   * <b>Expected:</b> Request response : OK_00503<br>
   * {\"retour\":{\"categorie\":\"CAT-2\",\"diagnostic\":\"SERVICE_TIERS_INDISPONIBLE\",\"libelle\":\"\",\"resultat\":\"NOK\"}}
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void PI0035_RecupererPFIComplet_KO_013() throws Throwable
  {
    Retour retourOk = RetourFactoryForTU.createOkRetour();

    String clientOperateur = "BSS_GP"; //$NON-NLS-1$
    String noCompte = "123456789"; //$NON-NLS-1$
    Request request = prepareRequest(clientOperateur, noCompte);
    fillAllRequestHeaders(request);

    PFI pfi = __podam.manufacturePojo(PFI.class);
    List<EquipementDeclare> listEquiPfi = pfi.getEquipementDeclare();
    EquipementDeclare equipPfiLeg = new EquipementDeclare("noEquip", "noIdentif", "MODEM_DECODEUR_TV", com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, null, null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    listEquiPfi.add(equipPfiLeg);
    pfi.setEquipementDeclare(listEquiPfi);
    //to avoid IllegalArgumentException due to the autoset of the PFI
    for (PA pa : pfi.getPa())
    {
      pa.setTypePA(TypePA.COMPTE_ACCES.name());
    }

    createMockRPGpfiLireUnFiltrerOCResilie(_tracabilite, retourOk, pfi, clientOperateur, noCompte);

    List<CommandeComposite> listeCommandeComposite = Arrays.asList(__podam.manufacturePojo(CommandeComposite.class));
    createMockCMDcommandeCompositeGererLireTousModCommParPfiFiltrerTraite(_tracabilite, retourOk, listeCommandeComposite, clientOperateur, noCompte);

    StLienAllocationCommercial stLienAllocationCommercial = new StLienAllocationCommercial("idST", Statut.ACTIF.name(), clientOperateur, noCompte, TypeObjetCommercial.PFI.name(), "BSS_GP", noCompte, "idRessource", TypeRessource.COMPTE_MAIL.name()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    List<ServiceTechnique> listeServiceTechnique = Arrays.asList(stLienAllocationCommercial);
    createMockRSTserviceTechniqueLireTousParPfiFiltrerInactif(_tracabilite, retourOk, listeServiceTechnique, clientOperateur, noCompte);

    Ressource ressource = new Ressource(stLienAllocationCommercial.getIdRessource(), stLienAllocationCommercial.getTypeRessource(), stLienAllocationCommercial.getStatut());
    createMockRESressourceLireUn(_tracabilite, retourOk, ressource);

    IndexRecherchePfi indexRecherchePfi = new IndexRecherchePfi(clientOperateur, noCompte);
    List<IndexRecherchePfi> listeIndexRecherchePfi = Arrays.asList(indexRecherchePfi);
    createMockAIRindexRechercherPfiLireUn(_tracabilite, retourOk, listeIndexRecherchePfi, clientOperateur, noCompte);

    Retour retourBL005 = RetourFactoryForTU.createOkRetour();
    ConnectorResponse<Retour, Nothing> resultRex = new ConnectorResponse<>(retourBL005, null);
    // Used in BL005
    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxy);
    EasyMock.expect(_rexProxy.erreurSpiritCreer(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(CreateErreurSpiritRequest.class))).andReturn(resultRex);

    List<ServiceTechniqueEquipementLegacy> response25 = new ArrayList<>();
    ServiceTechniqueEquipementLegacy equipLeg = __podam.manufacturePojo(ServiceTechniqueEquipementLegacy.class);
    response25.add(equipLeg);
    PowerMock.expectNew(OSSFAI_SI025_LireStEquipementLegacyParSnBuilder.class).andReturn(_si025BuilderMock);
    EasyMock.expect(_si025BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_si025BuilderMock);
    EasyMock.expect(_si025BuilderMock.numeroSerie(EasyMock.anyObject(String.class))).andReturn(_si025BuilderMock);
    EasyMock.expect(_si025BuilderMock.build()).andReturn(_si025Mock);
    EasyMock.expect(_si025Mock.execute(EasyMock.anyObject(PI0035_RecupererPfiComplet.class))).andReturn(response25);

    // Mapping de l'object STLegacy de typeServiceTechnique = ACCESS_GPON
    LocalDateTime nowAccesGPON = DateTimeManager.getInstance().now();
    for (PA pa : pfi.getPa())
    {
      pa.setTypePA(TypePA.LIGNE_FIXE.name());
      pa.setStatut(Statut.ACTIF);
      pa.getPaTypeLigneFixe().getInfoBrutBssGp().getAccesTechnique().setTechnologieAcces(TechnologieAccess.FTTH.name());
      pa.getPaTypeLigneFixe().getInfoBrutBssGp().setIdRessourceReseauFTTX(String.valueOf(__podam.manufacturePojo(Long.class)));
      pa.getPaTypeLigneFixe().setIdRaccordement(""); //$NON-NLS-1$
      pa.setDateModification(nowAccesGPON);
      pa.setDateCreation(nowAccesGPON);
    }

    Long nrmId = __podam.manufacturePojo(Long.class);
    Retour si031RetourNok = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, "");
    PowerMock.expectNew(OSSFAI_SI031_LireNrmIdBuilder.class).andReturn(_si031BuilderMock).anyTimes();
    EasyMock.expect(_si031BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_si031BuilderMock).anyTimes();
    EasyMock.expect(_si031BuilderMock.idOss(EasyMock.anyObject(Long.class))).andReturn(_si031BuilderMock).anyTimes();
    EasyMock.expect(_si031BuilderMock.build()).andReturn(_si031Mock).anyTimes();
    EasyMock.expect(_si031Mock.execute(EasyMock.anyObject(PI0035_RecupererPfiComplet.class))).andReturn(nrmId).anyTimes();
    EasyMock.expect(_si031Mock.getRetour()).andReturn(si031RetourNok).anyTimes();

    PowerMock.replayAll();
    _processInstance.run(request);
    _processInstance.continueProcess(request, _tracabilite);
    PowerMock.verify();

    Retour retourNOK = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, "");
    PI0035_Retour pi0035Retour = new PI0035_Retour(RetourConverter.convertToJsonRetour(retourNOK));

    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(RavelJsonTools.getInstance().toJson(pi0035Retour, PI0035_Retour.class));

    IRavelResponse response = request.getResponse();
    assertEquals(ErrorCode.KO_00503, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());
    assertEquals(retourBL005, _processInstance.getRetour());
  }

  /**
   * Non Nominal test for PI0035_RecupererPFIComplet: activity OSSFAI_SI032_LireNrmInfos return NOK
   *
   * <b>Inputs:</b> Valid inputs<br>
   * <b>Expected:</b> Request response : OK_00503<br>
   * {\"retour\":{\"categorie\":\"CAT-2\",\"diagnostic\":\"SERVICE_TIERS_INDISPONIBLE\",\"libelle\":\"\",\"resultat\":\"NOK\"}}
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void PI0035_RecupererPFIComplet_KO_014() throws Throwable
  {
    Retour retourOk = RetourFactoryForTU.createOkRetour();

    String clientOperateur = "BSS_GP"; //$NON-NLS-1$
    String noCompte = "123456789"; //$NON-NLS-1$
    Request request = prepareRequest(clientOperateur, noCompte);
    fillAllRequestHeaders(request);

    PFI pfi = __podam.manufacturePojo(PFI.class);
    List<EquipementDeclare> listEquiPfi = pfi.getEquipementDeclare();
    EquipementDeclare equipPfiLeg = new EquipementDeclare("noEquip", "noIdentif", "MODEM_DECODEUR_TV", com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, null, null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    listEquiPfi.add(equipPfiLeg);
    pfi.setEquipementDeclare(listEquiPfi);
    //to avoid IllegalArgumentException due to the autoset of the PFI
    for (PA pa : pfi.getPa())
    {
      pa.setTypePA(TypePA.COMPTE_ACCES.name());
    }

    createMockRPGpfiLireUnFiltrerOCResilie(_tracabilite, retourOk, pfi, clientOperateur, noCompte);

    List<CommandeComposite> listeCommandeComposite = Arrays.asList(__podam.manufacturePojo(CommandeComposite.class));
    createMockCMDcommandeCompositeGererLireTousModCommParPfiFiltrerTraite(_tracabilite, retourOk, listeCommandeComposite, clientOperateur, noCompte);

    StLienAllocationCommercial stLienAllocationCommercial = new StLienAllocationCommercial("idST", Statut.ACTIF.name(), clientOperateur, noCompte, TypeObjetCommercial.PFI.name(), "BSS_GP", noCompte, "idRessource", TypeRessource.COMPTE_MAIL.name()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    List<ServiceTechnique> listeServiceTechnique = Arrays.asList(stLienAllocationCommercial);
    createMockRSTserviceTechniqueLireTousParPfiFiltrerInactif(_tracabilite, retourOk, listeServiceTechnique, clientOperateur, noCompte);

    Ressource ressource = new Ressource(stLienAllocationCommercial.getIdRessource(), stLienAllocationCommercial.getTypeRessource(), stLienAllocationCommercial.getStatut());
    createMockRESressourceLireUn(_tracabilite, retourOk, ressource);

    IndexRecherchePfi indexRecherchePfi = new IndexRecherchePfi(clientOperateur, noCompte);
    List<IndexRecherchePfi> listeIndexRecherchePfi = Arrays.asList(indexRecherchePfi);
    createMockAIRindexRechercherPfiLireUn(_tracabilite, retourOk, listeIndexRecherchePfi, clientOperateur, noCompte);

    Retour retourBL005 = RetourFactoryForTU.createOkRetour();
    ConnectorResponse<Retour, Nothing> resultRex = new ConnectorResponse<>(retourBL005, null);
    // Used in BL005
    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxy);
    EasyMock.expect(_rexProxy.erreurSpiritCreer(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(CreateErreurSpiritRequest.class))).andReturn(resultRex);

    List<ServiceTechniqueEquipementLegacy> response25 = new ArrayList<>();
    ServiceTechniqueEquipementLegacy equipLeg = __podam.manufacturePojo(ServiceTechniqueEquipementLegacy.class);
    response25.add(equipLeg);
    PowerMock.expectNew(OSSFAI_SI025_LireStEquipementLegacyParSnBuilder.class).andReturn(_si025BuilderMock);
    EasyMock.expect(_si025BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_si025BuilderMock);
    EasyMock.expect(_si025BuilderMock.numeroSerie(EasyMock.anyObject(String.class))).andReturn(_si025BuilderMock);
    EasyMock.expect(_si025BuilderMock.build()).andReturn(_si025Mock);
    EasyMock.expect(_si025Mock.execute(EasyMock.anyObject(PI0035_RecupererPfiComplet.class))).andReturn(response25);

    // Mapping de l'object STLegacy de typeServiceTechnique = ACCESS_GPON
    LocalDateTime nowAccesGPON = DateTimeManager.getInstance().now();
    for (PA pa : pfi.getPa())
    {
      pa.setTypePA(TypePA.LIGNE_FIXE.name());
      pa.setStatut(Statut.ACTIF);
      pa.getPaTypeLigneFixe().getInfoBrutBssGp().getAccesTechnique().setTechnologieAcces(TechnologieAccess.FTTH.name());
      pa.getPaTypeLigneFixe().getInfoBrutBssGp().setIdRessourceReseauFTTX(String.valueOf(__podam.manufacturePojo(Long.class)));
      pa.getPaTypeLigneFixe().setIdRaccordement(""); //$NON-NLS-1$
      pa.setDateModification(nowAccesGPON);
      pa.setDateCreation(nowAccesGPON);
    }

    Long nrmId = __podam.manufacturePojo(Long.class);
    PowerMock.expectNew(OSSFAI_SI031_LireNrmIdBuilder.class).andReturn(_si031BuilderMock).anyTimes();
    EasyMock.expect(_si031BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_si031BuilderMock).anyTimes();
    EasyMock.expect(_si031BuilderMock.idOss(EasyMock.anyObject(Long.class))).andReturn(_si031BuilderMock).anyTimes();
    EasyMock.expect(_si031BuilderMock.build()).andReturn(_si031Mock).anyTimes();
    EasyMock.expect(_si031Mock.execute(EasyMock.anyObject(PI0035_RecupererPfiComplet.class))).andReturn(nrmId).anyTimes();
    EasyMock.expect(_si031Mock.getRetour()).andReturn(RetourFactory.createOkRetour()).anyTimes();

    NRMInfosRetour si032Retour = null;
    Retour si032RetourNok = RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, "");
    PowerMock.expectNew(OSSFAI_SI032_LireNrmInfosBuilder.class).andReturn(_si032BuilderMock).anyTimes();
    EasyMock.expect(_si032BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_si032BuilderMock).anyTimes();
    EasyMock.expect(_si032BuilderMock.nrmId(EasyMock.anyObject(Integer.class))).andReturn(_si032BuilderMock).anyTimes();
    EasyMock.expect(_si032BuilderMock.build()).andReturn(_si032Mock).anyTimes();
    EasyMock.expect(_si032Mock.execute(EasyMock.anyObject(PI0035_RecupererPfiComplet.class))).andReturn(si032Retour).anyTimes();
    EasyMock.expect(_si032Mock.getRetour()).andReturn(si032RetourNok).anyTimes();

    PowerMock.replayAll();
    _processInstance.run(request);
    _processInstance.continueProcess(request, _tracabilite);
    PowerMock.verify();

    Retour retourNOK = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, "");
    PI0035_Retour pi0035Retour = new PI0035_Retour(RetourConverter.convertToJsonRetour(retourNOK));

    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(RavelJsonTools.getInstance().toJson(pi0035Retour, PI0035_Retour.class));

    IRavelResponse response = request.getResponse();
    assertEquals(ErrorCode.KO_00503, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());
    assertEquals(retourBL005, _processInstance.getRetour());
  }

  /**
   * Nominal test for PI0035_RecupererPFIComplet
   *
   * <b>Inputs:</b> Valid inputs<br>
   * <b>Expected:</b> Request response : OK_00200<br>
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void PI0035_RecupererPFIComplet_OK_001() throws Throwable
  {
    Retour retourOk = RetourFactoryForTU.createOkRetour();

    String clientOperateur = "BSS_GP"; //$NON-NLS-1$
    String noCompte = "123456789"; //$NON-NLS-1$
    Request request = prepareRequest(clientOperateur, noCompte);
    fillAllRequestHeaders(request);

    PFI pfi = __podam.manufacturePojo(PFI.class);
    List<EquipementDeclare> listEquiPfi = pfi.getEquipementDeclare();
    EquipementDeclare equipPfiLeg = new EquipementDeclare("noEquip", "noIdentif", "MODEM_DECODEUR_TV", com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, null, null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    listEquiPfi.add(equipPfiLeg);
    pfi.setEquipementDeclare(listEquiPfi);
    //to avoid IllegalArgumentException due to the autoset of the PFI
    for (PA pa : pfi.getPa())
    {
      pa.setTypePA(TypePA.COMPTE_ACCES.name());
    }

    createMockRPGpfiLireUnFiltrerOCResilie(_tracabilite, retourOk, pfi, clientOperateur, noCompte);

    List<CommandeComposite> listeCommandeComposite = Arrays.asList(__podam.manufacturePojo(CommandeComposite.class));
    createMockCMDcommandeCompositeGererLireTousModCommParPfiFiltrerTraite(_tracabilite, retourOk, listeCommandeComposite, clientOperateur, noCompte);

    StLienAllocationCommercial stLienAllocationCommercial = new StLienAllocationCommercial("idST", Statut.ACTIF.name(), clientOperateur, noCompte, TypeObjetCommercial.PFI.name(), "BSS_GP", noCompte, "idRessource", TypeRessource.COMPTE_MAIL.name()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    List<ServiceTechnique> listeServiceTechnique = Arrays.asList(stLienAllocationCommercial);
    createMockRSTserviceTechniqueLireTousParPfiFiltrerInactif(_tracabilite, retourOk, listeServiceTechnique, clientOperateur, noCompte);

    Ressource ressource = new Ressource(stLienAllocationCommercial.getIdRessource(), stLienAllocationCommercial.getTypeRessource(), stLienAllocationCommercial.getStatut());
    createMockRESressourceLireUn(_tracabilite, retourOk, ressource);

    IndexRecherchePfi indexRecherchePfi = new IndexRecherchePfi(clientOperateur, noCompte);
    List<IndexRecherchePfi> listeIndexRecherchePfi = Arrays.asList(indexRecherchePfi);
    createMockAIRindexRechercherPfiLireUn(_tracabilite, retourOk, listeIndexRecherchePfi, clientOperateur, noCompte);

    Retour retourBL005 = RetourFactoryForTU.createOkRetour();
    ConnectorResponse<Retour, Nothing> resultRex = new ConnectorResponse<>(retourBL005, null);
    // Used in BL005
    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxy);
    EasyMock.expect(_rexProxy.erreurSpiritCreer(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(CreateErreurSpiritRequest.class))).andReturn(resultRex);

    List<ServiceTechniqueEquipementLegacy> response25 = new ArrayList<>();
    ServiceTechniqueEquipementLegacy equipLeg = __podam.manufacturePojo(ServiceTechniqueEquipementLegacy.class);
    response25.add(equipLeg);
    PowerMock.expectNew(OSSFAI_SI025_LireStEquipementLegacyParSnBuilder.class).andReturn(_si025BuilderMock);
    EasyMock.expect(_si025BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_si025BuilderMock);
    EasyMock.expect(_si025BuilderMock.numeroSerie(EasyMock.anyObject(String.class))).andReturn(_si025BuilderMock);
    EasyMock.expect(_si025BuilderMock.build()).andReturn(_si025Mock);
    EasyMock.expect(_si025Mock.execute(EasyMock.anyObject(PI0035_RecupererPfiComplet.class))).andReturn(response25);

    // Mapping de l'object STLegacy de typeServiceTechnique = ACCESS_GPON
    LocalDateTime nowAccesGPON = DateTimeManager.getInstance().now();
    for (PA pa : pfi.getPa())
    {
      pa.setTypePA(TypePA.LIGNE_FIXE.name());
      pa.setStatut(Statut.ACTIF);
      pa.getPaTypeLigneFixe().getInfoBrutBssGp().getAccesTechnique().setTechnologieAcces(TechnologieAccess.FTTH.name());
      pa.getPaTypeLigneFixe().getInfoBrutBssGp().setIdRessourceReseauFTTX(String.valueOf(__podam.manufacturePojo(Long.class)));
      pa.getPaTypeLigneFixe().setIdRaccordement(""); //$NON-NLS-1$
      pa.setDateModification(nowAccesGPON);
      pa.setDateCreation(nowAccesGPON);
    }

    Long nrmId = __podam.manufacturePojo(Long.class);
    PowerMock.expectNew(OSSFAI_SI031_LireNrmIdBuilder.class).andReturn(_si031BuilderMock).anyTimes();
    EasyMock.expect(_si031BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_si031BuilderMock).anyTimes();
    EasyMock.expect(_si031BuilderMock.idOss(EasyMock.anyObject(Long.class))).andReturn(_si031BuilderMock).anyTimes();
    EasyMock.expect(_si031BuilderMock.build()).andReturn(_si031Mock).anyTimes();
    EasyMock.expect(_si031Mock.execute(EasyMock.anyObject(PI0035_RecupererPfiComplet.class))).andReturn(nrmId).anyTimes();
    EasyMock.expect(_si031Mock.getRetour()).andReturn(RetourFactory.createOkRetour()).anyTimes();

    NRMInfosRetour si032Retour = __podam.manufacturePojo(NRMInfosRetour.class);
    PowerMock.expectNew(OSSFAI_SI032_LireNrmInfosBuilder.class).andReturn(_si032BuilderMock).anyTimes();
    EasyMock.expect(_si032BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_si032BuilderMock).anyTimes();
    EasyMock.expect(_si032BuilderMock.nrmId(EasyMock.anyObject(Integer.class))).andReturn(_si032BuilderMock).anyTimes();
    EasyMock.expect(_si032BuilderMock.build()).andReturn(_si032Mock).anyTimes();
    EasyMock.expect(_si032Mock.execute(EasyMock.anyObject(PI0035_RecupererPfiComplet.class))).andReturn(si032Retour).anyTimes();
    EasyMock.expect(_si032Mock.getRetour()).andReturn(RetourFactory.createOkRetour()).anyTimes();

    PowerMock.replayAll();
    _processInstance.run(request);
    _processInstance.continueProcess(request, _tracabilite);
    PowerMock.verify();

    //PFIComplet expected in ReponseFonctionnelle
    PI0035_PFIComplet pfiCompletExpected = PI0035_PFIComplet.buildFromPFI(pfi);
    List<ModificationCommerciale> listeModificationCommerciale = listeCommandeComposite.get(0).getListeModificationCommerciale();
    List<ModificationTechnique> listeModificationTechnique = listeCommandeComposite.get(0).getListeModificationTechnique();
    List<PI0035_ModificationCommerciale> pfiCompletModCommList = pfiCompletExpected.getModificationCommerciale();
    for (ModificationCommerciale modComm : listeModificationCommerciale)
    {
      PI0035_ModificationCommerciale pfiCompletModComm = PI0035_ModificationCommerciale.builfFromModificationCommerciale(modComm);
      pfiCompletModCommList.add(pfiCompletModComm);
    }
    pfiCompletExpected.setModificationCommerciale(pfiCompletModCommList);
    List<PI0035_ModificationTechnique> pfiCompletModTechList = pfiCompletExpected.getModificationTechnique();
    for (ModificationTechnique modTech : listeModificationTechnique)
    {
      PI0035_ModificationTechnique pfiCompletModTech = PI0035_ModificationTechnique.builfFromModificationTechnique(modTech);
      pfiCompletModTechList.add(pfiCompletModTech);
    }
    pfiCompletExpected.setModificationTechnique(pfiCompletModTechList);

    PI0035_ServiceTechnique pfiCompletST = PI0035_ServiceTechnique.buildFromServiceTechnique(stLienAllocationCommercial);
    pfiCompletExpected.setSt(Arrays.asList(pfiCompletST));

    PI0035_Ressource pfiCompletRessource = PI0035_Ressource.buildFromRessource(ressource);
    pfiCompletExpected.setRessource(Arrays.asList(pfiCompletRessource));

    PI0035_IndexRecherche pfiCompletIndexRecherche = PI0035_IndexRecherche.buildFromIndexRecherPFI(indexRecherchePfi);
    pfiCompletExpected.setIndexRecherche(Arrays.asList(pfiCompletIndexRecherche));

    List<PI0035_ServiceTechniqueLegacy> listPI0035_StLegacyEquipement = new ArrayList<>();
    PI0035_ServiceTechniqueLegacy pi0035_ServiceTechniqueLegacy = PI0035_ServiceTechniqueLegacy.buildFromServiceTechniqueEquipementLegacy(equipLeg);
    if (nonNull(pi0035_ServiceTechniqueLegacy))
    {
      listPI0035_StLegacyEquipement.add(pi0035_ServiceTechniqueLegacy);
    }
    listPI0035_StLegacyEquipement.add(new PI0035_StLegacyFqdn(StatutLegacy.INACTIF.name(), null, null, null));
    pfiCompletExpected.setStLegacy(listPI0035_StLegacyEquipement);
    pfiCompletExpected.setDonneesTopologieReseaux(new ArrayList<>());

    // Mapping de l'object STLegacy de typeServiceTechnique = ACCESS_GPON
    for (PA pa : pfi.getPa())
    {
      listPI0035_StLegacyEquipement.add(PI0035_StLegacyAccesGPON.buildFromStLegacyAccesGPON(si032Retour, Statut.ACTIF.toString(), //
          nowAccesGPON, nowAccesGPON, nrmId.toString(), pa.getPaTypeLigneFixe().getInfoBrutBssGp().getIdRessourceReseauFTTX(), si032Retour.getPort().toString()));
      pfiCompletExpected.setStLegacy(listPI0035_StLegacyEquipement);
    }

    ReponseFonctionnelle reponseFonctionnelle = new ReponseFonctionnelle();
    reponseFonctionnelle.setPfiComplet(pfiCompletExpected);
    reponseFonctionnelle.setErreurBloquante(new ArrayList<>());

    PI0035_Retour pi0035Retour = new PI0035_Retour(RetourConverter.convertToJsonRetour(retourOk));
    pi0035Retour.setReponseFonctionnelle(reponseFonctionnelle);

    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(RavelJsonTools.getInstance().toJson(pi0035Retour, PI0035_Retour.class));

    IRavelResponse response = request.getResponse();
    assertEquals(ErrorCode.OK_00200, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());
    assertEquals(retourBL005, _processInstance.getRetour());
  }

  /**
   * Nominal test for PI0035_RecupererPFIComplet
   *
   * <b>Inputs:</b> Valid inputs, all PAs with Type VOIP<br>
   * <b>Expected:</b> Request response : OK_00200<br>
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void PI0035_RecupererPFIComplet_OK_002() throws Throwable
  {
    Retour retourOk = RetourFactoryForTU.createOkRetour();

    String clientOperateur = "BSS_GP"; //$NON-NLS-1$
    String noCompte = "123456789"; //$NON-NLS-1$
    Request request = prepareRequest(clientOperateur, noCompte);
    fillAllRequestHeaders(request);

    PFI pfi = __podam.manufacturePojo(PFI.class);
    List<EquipementDeclare> listEquiPfi = pfi.getEquipementDeclare();
    EquipementDeclare equipPfiLeg = new EquipementDeclare("noEquip", "noIdentif", "MODEM_DECODEUR_TV", com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, null, null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    listEquiPfi.add(equipPfiLeg);
    pfi.setEquipementDeclare(listEquiPfi);
    //to avoid IllegalArgumentException due to the autoset of the PFI
    for (PA pa : pfi.getPa())
    {
      pa.setTypePA(TypePA.VOIP.name());
      pa.setStatut(com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF);
    }

    createMockRPGpfiLireUnFiltrerOCResilie(_tracabilite, retourOk, pfi, clientOperateur, noCompte);

    List<CommandeComposite> listeCommandeComposite = Arrays.asList(__podam.manufacturePojo(CommandeComposite.class));
    createMockCMDcommandeCompositeGererLireTousModCommParPfiFiltrerTraite(_tracabilite, retourOk, listeCommandeComposite, clientOperateur, noCompte);

    StLienAllocationCommercial stLienAllocationCommercial = new StLienAllocationCommercial("idST", Statut.ACTIF.name(), clientOperateur, noCompte, TypeObjetCommercial.PFI.name(), "BSS_GP", noCompte, "idRessource", TypeRessource.COMPTE_MAIL.name()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    List<ServiceTechnique> listeServiceTechnique = Arrays.asList(stLienAllocationCommercial);
    createMockRSTserviceTechniqueLireTousParPfiFiltrerInactif(_tracabilite, retourOk, listeServiceTechnique, clientOperateur, noCompte);

    Ressource ressource = new Ressource(stLienAllocationCommercial.getIdRessource(), stLienAllocationCommercial.getTypeRessource(), stLienAllocationCommercial.getStatut());
    createMockRESressourceLireUn(_tracabilite, retourOk, ressource);

    IndexRecherchePfi indexRecherchePfi = new IndexRecherchePfi(clientOperateur, noCompte);
    List<IndexRecherchePfi> listeIndexRecherchePfi = Arrays.asList(indexRecherchePfi);
    createMockAIRindexRechercherPfiLireUn(_tracabilite, retourOk, listeIndexRecherchePfi, clientOperateur, noCompte);

    Retour retourBL005 = RetourFactoryForTU.createOkRetour();
    ConnectorResponse<Retour, Nothing> resultRex = new ConnectorResponse<>(retourBL005, null);
    // Used in BL005
    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxy);
    EasyMock.expect(_rexProxy.erreurSpiritCreer(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(CreateErreurSpiritRequest.class))).andReturn(resultRex);

    List<PI0035_ServiceTechniqueLegacy> listPI0035_StLegacyEquipement = new ArrayList<>();
    for (PA pa : pfi.getPa())
    {
      ServiceTechniqueTelephonieLegacy st = __podam.manufacturePojo(ServiceTechniqueTelephonieLegacy.class);
      PowerMock.expectNew(OSSFAI_SI019_LireStTelephonieLegacyBuilder.class).andReturn(_si019BuilderMock);
      EasyMock.expect(_si019BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_si019BuilderMock);
      EasyMock.expect(_si019BuilderMock.numeroTelephone(EasyMock.eq(pa.getPaTypeVoip().getNumeroTelephone()))).andReturn(_si019BuilderMock);
      EasyMock.expect(_si019BuilderMock.build()).andReturn(_si019Mock);
      EasyMock.expect(_si019Mock.execute(EasyMock.anyObject(PI0035_RecupererPfiComplet.class))).andReturn(st);
      listPI0035_StLegacyEquipement.add(PI0035_ServiceTechniqueLegacy.buildFromServiceTechniqueTelephonieLegacy(st));
    }

    List<ServiceTechniqueEquipementLegacy> response25 = new ArrayList<>();
    ServiceTechniqueEquipementLegacy equipLeg = __podam.manufacturePojo(ServiceTechniqueEquipementLegacy.class);
    response25.add(equipLeg);
    PowerMock.expectNew(OSSFAI_SI025_LireStEquipementLegacyParSnBuilder.class).andReturn(_si025BuilderMock);
    EasyMock.expect(_si025BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_si025BuilderMock);
    EasyMock.expect(_si025BuilderMock.numeroSerie(EasyMock.anyObject(String.class))).andReturn(_si025BuilderMock);
    EasyMock.expect(_si025BuilderMock.build()).andReturn(_si025Mock);
    EasyMock.expect(_si025Mock.execute(EasyMock.anyObject(PI0035_RecupererPfiComplet.class))).andReturn(response25);

    PowerMock.replayAll();
    _processInstance.run(request);
    _processInstance.continueProcess(request, _tracabilite);
    PowerMock.verify();

    //PFIComplet expected in ReponseFonctionnelle
    PI0035_PFIComplet pfiCompletExpected = PI0035_PFIComplet.buildFromPFI(pfi);
    List<ModificationCommerciale> listeModificationCommerciale = listeCommandeComposite.get(0).getListeModificationCommerciale();
    List<ModificationTechnique> listeModificationTechnique = listeCommandeComposite.get(0).getListeModificationTechnique();
    List<PI0035_ModificationCommerciale> pfiCompletModCommList = pfiCompletExpected.getModificationCommerciale();
    for (ModificationCommerciale modComm : listeModificationCommerciale)
    {
      PI0035_ModificationCommerciale pfiCompletModComm = PI0035_ModificationCommerciale.builfFromModificationCommerciale(modComm);
      pfiCompletModCommList.add(pfiCompletModComm);
    }
    pfiCompletExpected.setModificationCommerciale(pfiCompletModCommList);
    List<PI0035_ModificationTechnique> pfiCompletModTechList = pfiCompletExpected.getModificationTechnique();
    for (ModificationTechnique modTech : listeModificationTechnique)
    {
      PI0035_ModificationTechnique pfiCompletModTech = PI0035_ModificationTechnique.builfFromModificationTechnique(modTech);
      pfiCompletModTechList.add(pfiCompletModTech);
    }
    pfiCompletExpected.setModificationTechnique(pfiCompletModTechList);

    PI0035_ServiceTechnique pfiCompletST = PI0035_ServiceTechnique.buildFromServiceTechnique(stLienAllocationCommercial);
    pfiCompletExpected.setSt(Arrays.asList(pfiCompletST));

    PI0035_Ressource pfiCompletRessource = PI0035_Ressource.buildFromRessource(ressource);
    pfiCompletExpected.setRessource(Arrays.asList(pfiCompletRessource));

    PI0035_IndexRecherche pfiCompletIndexRecherche = PI0035_IndexRecherche.buildFromIndexRecherPFI(indexRecherchePfi);
    pfiCompletExpected.setIndexRecherche(Arrays.asList(pfiCompletIndexRecherche));

    PI0035_ServiceTechniqueLegacy pi0035_ServiceTechniqueLegacy = PI0035_ServiceTechniqueLegacy.buildFromServiceTechniqueEquipementLegacy(equipLeg);
    if (nonNull(pi0035_ServiceTechniqueLegacy))
    {
      listPI0035_StLegacyEquipement.add(pi0035_ServiceTechniqueLegacy);
    }
    listPI0035_StLegacyEquipement.add(new PI0035_StLegacyFqdn(StatutLegacy.INACTIF.name(), null, null, null));
    pfiCompletExpected.setStLegacy(listPI0035_StLegacyEquipement);
    pfiCompletExpected.setDonneesTopologieReseaux(new ArrayList<>());

    ReponseFonctionnelle reponseFonctionnelle = new ReponseFonctionnelle();
    reponseFonctionnelle.setPfiComplet(pfiCompletExpected);
    reponseFonctionnelle.setErreurBloquante(new ArrayList<>());

    PI0035_Retour pi0035Retour = new PI0035_Retour(RetourConverter.convertToJsonRetour(retourOk));
    pi0035Retour.setReponseFonctionnelle(reponseFonctionnelle);

    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(RavelJsonTools.getInstance().toJson(pi0035Retour, PI0035_Retour.class));

    IRavelResponse response = request.getResponse();
    assertEquals(ErrorCode.OK_00200, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());
    assertEquals(retourBL005, _processInstance.getRetour());
  }

  /**
   * Nominal test for PI0035_RecupererPFIComplet
   *
   * <b>Inputs:</b> Valid inputs, all PAs with Type FAX<br>
   * <b>Expected:</b> Request response : OK_00200<br>
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void PI0035_RecupererPFIComplet_OK_003() throws Throwable
  {
    Retour retourOk = RetourFactoryForTU.createOkRetour();

    String clientOperateur = "BSS_GP"; //$NON-NLS-1$
    String noCompte = "123456789"; //$NON-NLS-1$
    Request request = prepareRequest(clientOperateur, noCompte);
    fillAllRequestHeaders(request);

    PFI pfi = __podam.manufacturePojo(PFI.class);
    List<EquipementDeclare> listEquiPfi = pfi.getEquipementDeclare();
    EquipementDeclare equipPfiLeg = new EquipementDeclare("noEquip", "noIdentif", "MODEM_DECODEUR_TV", com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, null, null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    listEquiPfi.add(equipPfiLeg);
    pfi.setEquipementDeclare(listEquiPfi);
    //to avoid IllegalArgumentException due to the autoset of the PFI
    for (PA pa : pfi.getPa())
    {
      pa.setTypePA(TypePA.FAX.name());
      pa.setStatut(com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF);
    }

    createMockRPGpfiLireUnFiltrerOCResilie(_tracabilite, retourOk, pfi, clientOperateur, noCompte);

    List<CommandeComposite> listeCommandeComposite = Arrays.asList(__podam.manufacturePojo(CommandeComposite.class));
    createMockCMDcommandeCompositeGererLireTousModCommParPfiFiltrerTraite(_tracabilite, retourOk, listeCommandeComposite, clientOperateur, noCompte);

    StLienAllocationCommercial stLienAllocationCommercial = new StLienAllocationCommercial("idST", Statut.ACTIF.name(), clientOperateur, noCompte, TypeObjetCommercial.PFI.name(), "BSS_GP", noCompte, "idRessource", TypeRessource.COMPTE_MAIL.name()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    List<ServiceTechnique> listeServiceTechnique = Arrays.asList(stLienAllocationCommercial);
    createMockRSTserviceTechniqueLireTousParPfiFiltrerInactif(_tracabilite, retourOk, listeServiceTechnique, clientOperateur, noCompte);

    Ressource ressource = new Ressource(stLienAllocationCommercial.getIdRessource(), stLienAllocationCommercial.getTypeRessource(), stLienAllocationCommercial.getStatut());
    createMockRESressourceLireUn(_tracabilite, retourOk, ressource);

    IndexRecherchePfi indexRecherchePfi = new IndexRecherchePfi(clientOperateur, noCompte);
    List<IndexRecherchePfi> listeIndexRecherchePfi = Arrays.asList(indexRecherchePfi);
    createMockAIRindexRechercherPfiLireUn(_tracabilite, retourOk, listeIndexRecherchePfi, clientOperateur, noCompte);

    Retour retourBL005 = RetourFactoryForTU.createOkRetour();
    ConnectorResponse<Retour, Nothing> resultRex = new ConnectorResponse<>(retourBL005, null);
    // Used in BL005
    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxy);
    EasyMock.expect(_rexProxy.erreurSpiritCreer(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(CreateErreurSpiritRequest.class))).andReturn(resultRex);

    List<PI0035_ServiceTechniqueLegacy> listPI0035_StLegacyEquipement = new ArrayList<>();
    for (PA pa : pfi.getPa())
    {
      ServiceTechniqueTelephonieLegacy st = __podam.manufacturePojo(ServiceTechniqueTelephonieLegacy.class);
      PowerMock.expectNew(OSSFAI_SI019_LireStTelephonieLegacyBuilder.class).andReturn(_si019BuilderMock);
      EasyMock.expect(_si019BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_si019BuilderMock);
      EasyMock.expect(_si019BuilderMock.numeroTelephone(EasyMock.eq(pa.getPaTypeFax().getNumeroTelephone()))).andReturn(_si019BuilderMock);
      EasyMock.expect(_si019BuilderMock.build()).andReturn(_si019Mock);
      EasyMock.expect(_si019Mock.execute(EasyMock.anyObject(PI0035_RecupererPfiComplet.class))).andReturn(st);
      listPI0035_StLegacyEquipement.add(PI0035_ServiceTechniqueLegacy.buildFromServiceTechniqueTelephonieLegacy(st));
    }

    List<ServiceTechniqueEquipementLegacy> response25 = new ArrayList<>();
    ServiceTechniqueEquipementLegacy equipLeg = __podam.manufacturePojo(ServiceTechniqueEquipementLegacy.class);
    response25.add(equipLeg);
    PowerMock.expectNew(OSSFAI_SI025_LireStEquipementLegacyParSnBuilder.class).andReturn(_si025BuilderMock);
    EasyMock.expect(_si025BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_si025BuilderMock);
    EasyMock.expect(_si025BuilderMock.numeroSerie(EasyMock.anyObject(String.class))).andReturn(_si025BuilderMock);
    EasyMock.expect(_si025BuilderMock.build()).andReturn(_si025Mock);
    EasyMock.expect(_si025Mock.execute(EasyMock.anyObject(PI0035_RecupererPfiComplet.class))).andReturn(response25);

    PowerMock.replayAll();
    _processInstance.run(request);
    _processInstance.continueProcess(request, _tracabilite);
    PowerMock.verify();

    //PFIComplet expected in ReponseFonctionnelle
    PI0035_PFIComplet pfiCompletExpected = PI0035_PFIComplet.buildFromPFI(pfi);
    List<ModificationCommerciale> listeModificationCommerciale = listeCommandeComposite.get(0).getListeModificationCommerciale();
    List<ModificationTechnique> listeModificationTechnique = listeCommandeComposite.get(0).getListeModificationTechnique();
    List<PI0035_ModificationCommerciale> pfiCompletModCommList = pfiCompletExpected.getModificationCommerciale();
    for (ModificationCommerciale modComm : listeModificationCommerciale)
    {
      PI0035_ModificationCommerciale pfiCompletModComm = PI0035_ModificationCommerciale.builfFromModificationCommerciale(modComm);
      pfiCompletModCommList.add(pfiCompletModComm);
    }
    pfiCompletExpected.setModificationCommerciale(pfiCompletModCommList);
    List<PI0035_ModificationTechnique> pfiCompletModTechList = pfiCompletExpected.getModificationTechnique();
    for (ModificationTechnique modTech : listeModificationTechnique)
    {
      PI0035_ModificationTechnique pfiCompletModTech = PI0035_ModificationTechnique.builfFromModificationTechnique(modTech);
      pfiCompletModTechList.add(pfiCompletModTech);
    }
    pfiCompletExpected.setModificationTechnique(pfiCompletModTechList);

    PI0035_ServiceTechnique pfiCompletST = PI0035_ServiceTechnique.buildFromServiceTechnique(stLienAllocationCommercial);
    pfiCompletExpected.setSt(Arrays.asList(pfiCompletST));

    PI0035_Ressource pfiCompletRessource = PI0035_Ressource.buildFromRessource(ressource);
    pfiCompletExpected.setRessource(Arrays.asList(pfiCompletRessource));

    PI0035_IndexRecherche pfiCompletIndexRecherche = PI0035_IndexRecherche.buildFromIndexRecherPFI(indexRecherchePfi);
    pfiCompletExpected.setIndexRecherche(Arrays.asList(pfiCompletIndexRecherche));

    PI0035_ServiceTechniqueLegacy pi0035_ServiceTechniqueLegacy = PI0035_ServiceTechniqueLegacy.buildFromServiceTechniqueEquipementLegacy(equipLeg);
    if (nonNull(pi0035_ServiceTechniqueLegacy))
    {
      listPI0035_StLegacyEquipement.add(pi0035_ServiceTechniqueLegacy);
    }
    listPI0035_StLegacyEquipement.add(new PI0035_StLegacyFqdn(StatutLegacy.INACTIF.name(), null, null, null));
    pfiCompletExpected.setStLegacy(listPI0035_StLegacyEquipement);
    pfiCompletExpected.setDonneesTopologieReseaux(new ArrayList<>());

    ReponseFonctionnelle reponseFonctionnelle = new ReponseFonctionnelle();
    reponseFonctionnelle.setPfiComplet(pfiCompletExpected);
    reponseFonctionnelle.setErreurBloquante(new ArrayList<>());

    PI0035_Retour pi0035Retour = new PI0035_Retour(RetourConverter.convertToJsonRetour(retourOk));
    pi0035Retour.setReponseFonctionnelle(reponseFonctionnelle);

    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(RavelJsonTools.getInstance().toJson(pi0035Retour, PI0035_Retour.class));

    IRavelResponse response = request.getResponse();
    assertEquals(ErrorCode.OK_00200, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());
    assertEquals(retourBL005, _processInstance.getRetour());
  }

  /**
   * Tests the nominal case of PI0035_RecupererPFIComplet for ano SPIRIT 1081
   *
   * <b>Inputs:</b> All valid inputs <br>
   * TypeRessource.RACCO and attributes not null<br>
   * <b>Expected:</b> Retour{OK} and valid PFIComplet <br>
   *
   * @throws Throwable
   *           On errors
   *
   */
  @Test
  public void PI0035_RecupererPFIComplet_OK_004() throws Throwable
  {
    Retour retourOk = RetourFactoryForTU.createOkRetour();

    String clientOperateur = "BSS_GP"; //$NON-NLS-1$
    String noCompte = "123456789"; //$NON-NLS-1$
    Request request = prepareRequest(clientOperateur, noCompte);
    fillAllRequestHeaders(request);

    PFI pfi = __podam.manufacturePojo(PFI.class);
    //to avoid IllegalArgumentException due to the autoset of the PFI
    for (PA pa : pfi.getPa())
    {
      pa.setTypePA(TypePA.COMPTE_ACCES.name());
    }

    createMockRPGpfiLireUnFiltrerOCResilie(_tracabilite, retourOk, pfi, clientOperateur, noCompte);

    List<CommandeComposite> listeCommandeComposite = Arrays.asList(__podam.manufacturePojo(CommandeComposite.class));
    createMockCMDcommandeCompositeGererLireTousModCommParPfiFiltrerTraite(_tracabilite, retourOk, listeCommandeComposite, clientOperateur, noCompte);

    StLienAllocationCommercial stLienAllocationCommercial = new StLienAllocationCommercial("idST", Statut.ACTIF.name(), clientOperateur, noCompte, TypeObjetCommercial.PFI.name(), "BSS_GP", noCompte, "idRessource", TypeRessource.RACCO.name()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    List<ServiceTechnique> listeServiceTechnique = Arrays.asList(stLienAllocationCommercial);
    createMockRSTserviceTechniqueLireTousParPfiFiltrerInactif(_tracabilite, retourOk, listeServiceTechnique, clientOperateur, noCompte);

    Ressource ressource = new Ressource(stLienAllocationCommercial.getIdRessource(), stLienAllocationCommercial.getTypeRessource(), stLienAllocationCommercial.getStatut());
    ressource.setIdRessourceLie("idRessourceLie"); //$NON-NLS-1$
    RessourceRaccordement ressourceRaccordement = new RessourceRaccordement(TypeRaccordement.P2P.name(), "FTTOH-FIXED-10000-10000-MONO-DT-E-BT"); //$NON-NLS-1$
    ressourceRaccordement.setNomNR("SI544520"); //$NON-NLS-1$
    ressourceRaccordement.setAdresseDonnee(new AdresseDonnee("voie", "codeRivoli", "codeInsee", "commune")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    ressource.setRessourceRaccordement(ressourceRaccordement);
    AccesTechnique accesTechnique = new AccesTechnique("FTTOH-FIXED-10000-10000-MONO-DT-E-BT", "ENT", TypeRaccordement.P2P.name(), null, null); //$NON-NLS-1$ //$NON-NLS-2$
    RessourceRaccordementComposite ressourceRaccordementComposite = new RessourceRaccordementComposite(ressource, accesTechnique);
    createMockRESressourceRaccordementCompositeLireUn(_tracabilite, retourOk, ressource, ressourceRaccordementComposite);

    RessourceAggregeP2P ressourceAggrP2P = new RessourceAggregeP2P("", 0, 0, 0); //$NON-NLS-1$
    ressourceAggrP2P.setDistanceCompatible(10);
    ressourceAggrP2P.setPositionRelativePortP2P(11);

    RessourceAggrege ressourceAggrege = ressourceAggrP2P;
    mockBL2500(stLienAllocationCommercial.getIdRessource(), retourOk, new BL2500_Return(ressource, accesTechnique, ressourceAggrege));

    IndexRecherchePfi indexRecherchePfi = new IndexRecherchePfi(clientOperateur, noCompte);
    List<IndexRecherchePfi> listeIndexRecherchePfi = Arrays.asList(indexRecherchePfi);

    createMockAIRindexRechercherPfiLireUn(_tracabilite, retourOk, listeIndexRecherchePfi, clientOperateur, noCompte);

    PowerMock.replayAll();
    _processInstance.run(request);
    _processInstance.continueProcess(request, _tracabilite);
    PowerMock.verify();

    //PFIComplet expected in ReponseFonctionnelle
    PI0035_PFIComplet pfiCompletExpected = PI0035_PFIComplet.buildFromPFI(pfi);
    List<ModificationCommerciale> listeModificationCommerciale = listeCommandeComposite.get(0).getListeModificationCommerciale();
    List<ModificationTechnique> listeModificationTechnique = listeCommandeComposite.get(0).getListeModificationTechnique();
    List<PI0035_ModificationCommerciale> pfiCompletModCommList = pfiCompletExpected.getModificationCommerciale();
    List<PI0035_ModificationTechnique> pfiCompletModTechList = pfiCompletExpected.getModificationTechnique();
    for (ModificationCommerciale modComm : listeModificationCommerciale)
    {
      PI0035_ModificationCommerciale pfiCompletModComm = PI0035_ModificationCommerciale.builfFromModificationCommerciale(modComm);
      pfiCompletModCommList.add(pfiCompletModComm);
    }
    for (ModificationTechnique modTech : listeModificationTechnique)
    {
      PI0035_ModificationTechnique pfiCompletModTech = PI0035_ModificationTechnique.builfFromModificationTechnique(modTech);
      pfiCompletModTechList.add(pfiCompletModTech);
    }
    pfiCompletExpected.setModificationCommerciale(pfiCompletModCommList);
    pfiCompletExpected.setModificationTechnique(pfiCompletModTechList);

    PI0035_ServiceTechnique pfiCompletST = PI0035_ServiceTechnique.buildFromServiceTechnique(stLienAllocationCommercial);
    pfiCompletExpected.setSt(Arrays.asList(pfiCompletST));
    pfiCompletExpected.setStLegacy(Arrays.asList(new PI0035_StLegacyFqdn(StatutLegacy.INACTIF.name(), null, null, null)));
    pfiCompletExpected.setDonneesTopologieReseaux(new ArrayList<>());
    PI0035_AccesTechnique pi0035_accesTechnique = PI0035_AccesTechnique.buildFromAccesTechnique(ressourceRaccordementComposite.getAccesTechnique());

    PI0035_RessourceRaccordement ressourceRaccordementExpected = PI0035_RessourceRaccordement.buildFromRessource(ressource);
    ressourceRaccordementExpected.setAccesTechnique(pi0035_accesTechnique);

    PI0035_RessourceAggregeP2P ressourceAggregeP2P = PI0035_RessourceAggregeP2P.buildFromRessourceAggrege(RessourceAggregeP2P.class.cast(ressourceAggrege));
    ressourceRaccordementExpected = new PI0035_RessourceRaccordementP2P(ressourceRaccordementExpected.getIdRessource(), ressourceRaccordementExpected.getTypeRessource(), ressourceRaccordementExpected.getStatut(), ressourceRaccordementExpected.getIdST(), ressourceRaccordementExpected.getDateCreation(), ressourceRaccordementExpected.getDateModification(), ressourceRaccordementExpected.getTypeRaccordement(), ressourceRaccordementExpected.getAdresseDonnee(), ressourceRaccordementExpected.getNomNR(), ressourceRaccordementExpected.getIdRessourceLie(), ressourceRaccordementExpected.getAccesTechnique(), ressourceAggregeP2P);

    pfiCompletExpected.setRessource(Arrays.asList(ressourceRaccordementExpected));

    PI0035_IndexRecherche pfiCompletIndexRecherche = PI0035_IndexRecherche.buildFromIndexRecherPFI(indexRecherchePfi);
    pfiCompletExpected.setIndexRecherche(Arrays.asList(pfiCompletIndexRecherche));

    ReponseFonctionnelle reponseFonctionnelle = new ReponseFonctionnelle();
    reponseFonctionnelle.setPfiComplet(pfiCompletExpected);
    reponseFonctionnelle.setErreurBloquante(new ArrayList<>());

    PI0035_Retour pi0035Retour = new PI0035_Retour(RetourConverter.convertToJsonRetour(retourOk));
    pi0035Retour.setReponseFonctionnelle(reponseFonctionnelle);

    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(RavelJsonTools.getInstance().toJson(pi0035Retour, PI0035_Retour.class));

    IRavelResponse response = request.getResponse();
    assertEquals(ErrorCode.OK_00200, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());
    assertEquals(RetourFactoryForTU.createOkRetour(), _processInstance.getRetour());
  }

  /**
   * Sets the test
   */
  @Before
  public void setUp()
  {
    _processInstance = new PI0035_RecupererPfiComplet();
    _processInstance.initializeContext();

    _tracabilite = new Tracabilite();
    _tracabilite.setIdCorrelationByTel(StringConstants.EMPTY_STRING);
    _tracabilite.setIdProcessusSpirit(_processInstance.getIdProcess());
    _tracabilite.setIdCorrelationSpirit(Test_Consts.DEFAULT_MSGID);
    _tracabilite.setNomProcessus(StringConstants.EMPTY_STRING);
    _tracabilite.setNomSysteme(System.getenv("SERVICE")); //$NON-NLS-1$

    final Map<String, String> map = new HashMap<>();
    map.put("miseEnServiceImagineVOIP", "false"); //$NON-NLS-1$ //$NON-NLS-2$
    map.put("presenceLivraison_ProvOLTGP-L", "true"); //$NON-NLS-1$ //$NON-NLS-2$
    ProcessManager.getInstance().getProcessParams().clear();
    ProcessManager.getInstance().getProcessParams().put(StringConstants.EMPTY_STRING, map);

    // on réinitialise tous les mocks afin de ne pas avoir d'interférence entre les tests
    PowerMock.resetAll();

    PowerMock.mockStatic(RPGProxy.class);
    PowerMock.mockStatic(CMDProxy.class);
    PowerMock.mockStatic(RSTProxy.class);
    PowerMock.mockStatic(RESProxy.class);
    PowerMock.mockStatic(AIRProxy.class);
    PowerMock.mockStatic(REXProxy.class);
    PowerMock.mockStatic(LocalDateTime.class);
    PowerMock.mockStatic(OSSFAI_SI025_LireStEquipementLegacyParSnBuilder.class);
    PowerMock.mockStatic(OSSFAI_SI025_LireStEquipementLegacyParSn.class);
    PowerMock.mockStatic(OSSFAI_SI019_LireStTelephonieLegacyBuilder.class);
    PowerMock.mockStatic(OSSFAI_SI019_LireStTelephonieLegacy.class);
  }

  /**
   * Create a new request header
   *
   * @param name
   *          The request header name
   * @param value
   *          The request header value
   * @return the {@link RequestHeader}
   */
  private RequestHeader createHeader(String name, String value)
  {
    RequestHeader requestHeader = new RequestHeader();
    requestHeader.setName(name);
    requestHeader.setValue(value);

    return requestHeader;
  }

  /**
   * Creates mock for method indexRechercherPfiLireUn in {@link AIRProxy}
   *
   * @param tracabilite_p
   *          the tracabilite
   * @param retour_p
   *          the retour
   * @param listeIndexRecherchePfi_p
   *          the list of IndexRecherchePfi
   * @param clientOperateur_p
   *          the clientOperateur
   * @param noCompte_p
   *          the noCompte
   * @throws RavelException
   *           on errors
   */
  private void createMockAIRindexRechercherPfiLireUn(Tracabilite tracabilite_p, Retour retour_p, List<IndexRecherchePfi> listeIndexRecherchePfi_p, String clientOperateur_p, String noCompte_p) throws RavelException
  {
    ConnectorResponse<Retour, List<IndexRecherchePfi>> expectedResponse = new ConnectorResponse<>(retour_p, listeIndexRecherchePfi_p);
    EasyMock.expect(AIRProxy.getInstance()).andReturn(_airProxy);

    EasyMock.expect(_airProxy.indexRechercherPfiLireUn(tracabilite_p, clientOperateur_p, noCompte_p)).andReturn(expectedResponse);
  }

  /**
   * Creates mock for method commandeCompositeGererLireTousModCommParPfiFiltrerTraite in {@link CMDProxy}
   *
   * @param tracabilite_p
   *          the tracabilite
   * @param retour_p
   *          the retour
   * @param listeCommandeComposites_p
   *          the list of CommandeComposite
   * @param clientOperateur_p
   *          the clientOperateur
   * @param noCompte_p
   *          the noCompte
   * @throws RavelException
   *           on errors
   */
  private void createMockCMDcommandeCompositeGererLireTousModCommParPfiFiltrerTraite(Tracabilite tracabilite_p, Retour retour_p, List<CommandeComposite> listeCommandeComposites_p, String clientOperateur_p, String noCompte_p) throws RavelException
  {
    ConnectorResponse<Retour, List<CommandeComposite>> expectedResponse = new ConnectorResponse<>(retour_p, listeCommandeComposites_p);
    EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdProxy);

    EasyMock.expect(_cmdProxy.commandeCompositeGererLireTousModCommModTechParPfiFiltrerTraite(tracabilite_p, clientOperateur_p, noCompte_p)).andReturn(expectedResponse);
  }

  /**
   * Creates mock for method ressourceLireUn in {@link RESProxy}
   *
   * @param tracabilite_p
   *          the tracabilite
   * @param retour_p
   *          the retour
   * @param fqdn_p
   *          the Fqdn
   * @throws RavelException
   *           on errors
   */
  private void createMockRESFqdnLireUn(Tracabilite tracabilite_p, Retour retour_p, Fqdn fqdn_p) throws RavelException
  {
    ConnectorResponse<Retour, Fqdn> expectedResponse = new ConnectorResponse<>(retour_p, fqdn_p);
    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxy);

    EasyMock.expect(_resProxy.fqdnLireUn(tracabilite_p, fqdn_p.getNomFQDN())).andReturn(expectedResponse);
  }

  /**
   * Creates mock for method ressourceLireUn in {@link RESProxy}
   *
   * @param tracabilite_p
   *          the tracabilite
   * @param retour_p
   *          the retour
   * @param ressource_p
   *          the ressource
   * @throws RavelException
   *           on errors
   */
  private void createMockRESressourceLireUn(Tracabilite tracabilite_p, Retour retour_p, Ressource ressource_p) throws RavelException
  {
    ConnectorResponse<Retour, Ressource> expectedResponse = new ConnectorResponse<>(retour_p, ressource_p);
    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxy);

    EasyMock.expect(_resProxy.ressourceLireUn(tracabilite_p, ressource_p.getIdRessource(), ressource_p.getTypeRessource())).andReturn(expectedResponse);
  }

  /**
   * Creates mock for method ressourceRaccordementCompositeLireUn in {@link RESProxy}
   *
   * @param tracabilite_p
   *          the tracabilite
   * @param retour_p
   *          the retour
   * @param ressource_p
   *          the ressource
   * @param ressourceRaccordementComposite_p
   *          the ressourceRaccordementComposite
   * @throws RavelException
   *           on errors
   */
  private void createMockRESressourceRaccordementCompositeLireUn(Tracabilite tracabilite_p, Retour retour_p, Ressource ressource_p, RessourceRaccordementComposite ressourceRaccordementComposite_p) throws RavelException
  {
    ConnectorResponse<Retour, RessourceRaccordementComposite> expectedResponse = new ConnectorResponse<>(retour_p, ressourceRaccordementComposite_p);
    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxy);

    EasyMock.expect(_resProxy.ressourceRaccordementCompositeLireUn(tracabilite_p, ressource_p.getIdRessource())).andReturn(expectedResponse);
  }

  /**
   * Creates mock for method pfiLireUnFiltrerOCResilie in {@link RPGProxy}
   *
   * @param tracabilite_p
   *          the tracabilite
   * @param retour_p
   *          the retour
   * @param pfi_p
   *          the pfi
   * @param clientOperateur_p
   *          the clientOperateur
   * @param noCompte_p
   *          the noCompte
   * @throws RavelException
   *           on errors
   */
  private void createMockRPGpfiLireUnFiltrerOCResilie(Tracabilite tracabilite_p, Retour retour_p, PFI pfi_p, String clientOperateur_p, String noCompte_p) throws RavelException
  {
    ConnectorResponse<Retour, PFI> expectedResponse = new ConnectorResponse<>(retour_p, pfi_p);
    EasyMock.expect(RPGProxy.getInstance()).andReturn(_rpgProxy);

    EasyMock.expect(_rpgProxy.pfiLireUnFiltrerOCResilie(tracabilite_p, clientOperateur_p, noCompte_p)).andReturn(expectedResponse);
  }

  /**
   * Creates mock for method pfiLireUnFiltrerOCResilie in {@link RSTProxy}
   *
   * @param tracabilite_p
   *          the tracabilite
   * @param retour_p
   *          the retour
   * @param listeServiceTechniques_p
   *          the list of ServiceTechnique
   * @param clientOperateur_p
   *          the clientOperateur
   * @param noCompte_p
   *          the noCompte
   * @throws RavelException
   *           on errors
   */
  private void createMockRSTserviceTechniqueLireTousParPfiFiltrerInactif(Tracabilite tracabilite_p, Retour retour_p, List<ServiceTechnique> listeServiceTechniques_p, String clientOperateur_p, String noCompte_p) throws RavelException
  {
    ConnectorResponse<Retour, List<ServiceTechnique>> expectedResponse = new ConnectorResponse<>(retour_p, listeServiceTechniques_p);
    EasyMock.expect(RSTProxy.getInstance()).andReturn(_rstProxy);

    EasyMock.expect(_rstProxy.serviceTechniqueLireTousParPfi(tracabilite_p, clientOperateur_p, noCompte_p, null, null)).andReturn(expectedResponse);
  }

  /**
   * Fills all the request headers
   *
   * @param request_p
   *          The request
   */
  private void fillAllRequestHeaders(Request request_p)
  {
    RequestHeader xRequestIdSpirit = createHeader(IHttpHeadersConsts.X_REQUEST_ID_SPIRIT, "125667889000877"); //$NON-NLS-1$
    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "DOMINGO"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "RECUPERER PFI COMPLET"); //$NON-NLS-1$
    RequestHeader xProcessIdSpirit = createHeader(IHttpHeadersConsts.X_PROCESS_ID_SPIRIT, "RECUPERER PFI COMPLET"); //$NON-NLS-1$

    fillRequestHeaders(request_p, xRequestIdSpirit, xSource, xProcess, xProcessIdSpirit);
  }

  /**
   * Fills the specified request headers
   *
   * @param request_p
   *          The request
   * @param headers_p
   *          the list of headers to add
   */
  private void fillRequestHeaders(Request request_p, RequestHeader... headers_p)
  {
    request_p.getRequestHeader().addAll(Arrays.asList(headers_p));
  }

  /**
   * Method used to mock the BL1200 activity
   *
   * @param idRessource_p
   *          The idRessource
   * @param retour_p
   *          The bl retour
   * @param bl2500Return_p
   *          The bl return
   * @throws Exception
   *           Exception thrown if something goes wrong
   */
  private void mockBL2500(String idRessource_p, Retour retour_p, BL2500_Return bl2500Return_p) throws Exception
  {
    PowerMock.expectNew(BL2500_RecupererRessourceAggregeBuilder.class).andReturn(_bl2500BuilderMock);
    EasyMock.expect(_bl2500BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl2500BuilderMock);
    EasyMock.expect(_bl2500BuilderMock.idRessource(idRessource_p)).andReturn(_bl2500BuilderMock);
    EasyMock.expect(_bl2500BuilderMock.build()).andReturn(_bl2500Mock);
    EasyMock.expect(_bl2500Mock.execute(_processInstance)).andReturn(bl2500Return_p);
    EasyMock.expect(_bl2500Mock.getRetour()).andReturn(retour_p);
  }

  /**
   * Create a Generic Request to call PI0035_RecupererPfiComplet
   *
   * @param clientOperateur_p
   *          The clientOperateur to add to the urlParameters
   * @param noCompte_p
   *          The noCompte to add to the urlParameters
   * @return GenericRequest to call PEI0028_RelancerCommande
   * @throws RavelException
   *           on error
   */
  private Request prepareRequest(String clientOperateur_p, String noCompte_p) throws RavelException
  {
    Request request = new Request(PI0035_RecupererPfiComplet.class.getName(), "idProcess", "idClient"); //$NON-NLS-1$ //$NON-NLS-2$
    request.setMsgId(Test_Consts.DEFAULT_MSGID);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();

    if (clientOperateur_p != null)
    {
      list.add(new Parameter(PI0035_RecupererPfiComplet.ParameterUrl.clientOperateur.name(), clientOperateur_p));
    }
    if (noCompte_p != null)
    {
      list.add(new Parameter(PI0035_RecupererPfiComplet.ParameterUrl.noCompte.name(), noCompte_p));
    }
    urlParametersType.setUrlParameters(list);
    request.setUrlParameters(urlParametersType);

    return request;
  }

}
