/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PE0018.utils.comparators;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Random;

import org.apache.commons.lang3.RandomStringUtils;

import com.bytel.spirit.common.shared.saab.cmd.Commande;
import com.bytel.spirit.common.shared.saab.rex.ElementComparaison;
import com.bytel.spirit.common.shared.saab.rpg.AccesTechnique;
import com.bytel.spirit.common.shared.saab.rpg.AccessTechniqueCommercial;
import com.bytel.spirit.common.shared.saab.rpg.AdresseInstallation;
import com.bytel.spirit.common.shared.saab.rpg.ContexteInstallation;
import com.bytel.spirit.common.shared.saab.rpg.Entreprise;
import com.bytel.spirit.common.shared.saab.rpg.EquipementDeclare;
import com.bytel.spirit.common.shared.saab.rpg.Individu;
import com.bytel.spirit.common.shared.saab.rpg.InfoBrutBssGp;
import com.bytel.spirit.common.shared.saab.rpg.LienEquipementPA;
import com.bytel.spirit.common.shared.saab.rpg.LienSAPA;
import com.bytel.spirit.common.shared.saab.rpg.PA;
import com.bytel.spirit.common.shared.saab.rpg.PFI;
import com.bytel.spirit.common.shared.saab.rpg.PaTypeCompteAcces;
import com.bytel.spirit.common.shared.saab.rpg.PaTypeFax;
import com.bytel.spirit.common.shared.saab.rpg.PaTypeLigneFixe;
import com.bytel.spirit.common.shared.saab.rpg.PaTypeTv;
import com.bytel.spirit.common.shared.saab.rpg.PaTypeVoip;
import com.bytel.spirit.common.shared.saab.rpg.RaccordementCommercial;
import com.bytel.spirit.common.shared.saab.rpg.SA;
import com.bytel.spirit.common.shared.saab.rpg.Statut;
import com.bytel.spirit.common.shared.saab.rpg.Titulaire;
import com.bytel.spirit.common.shared.saab.rpg.TypeTitulaire;
import com.bytel.spirit.prof.processes.PE0018.utils.IdProvider;
import com.bytel.spirit.prof.processes.PE0018.utils.Modification;
import com.bytel.spirit.prof.shared.types.json.PointAccesCompteAcces;
import com.bytel.spirit.prof.shared.types.json.PointAccesFax;
import com.bytel.spirit.prof.shared.types.json.PointAccesLigneFixe;
import com.bytel.spirit.prof.shared.types.json.PointAccesTV;
import com.bytel.spirit.prof.shared.types.json.PointAccesVoip;

/**
 *
 * @author jgregori
 * @version ($Revision$ $Date$)
 */
public interface IModificationPFI_Test
{

  default public ElementComparaison getElementComparaisonEq(List<ElementComparaison> list_p, String clientOp, String noCompte, String eq)
  {
    for (ElementComparaison el : list_p)
    {
      if (el.getClientOperateur().equals(clientOp) && el.getNoCompte().equals(noCompte) && eq.equals(el.getNoEquipement()))
      {
        return el;
      }

    }
    return null;
  }

  default public ElementComparaison getElementComparaisonEqPA(List<ElementComparaison> list_p, String clientOp, String noCompte, String eq, String idPa)
  {
    for (ElementComparaison el : list_p)
    {
      if (el.getClientOperateur().equals(clientOp) && el.getNoCompte().equals(noCompte) && idPa.equals(el.getIdentifiantFonctionnelPA()) && eq.equals(el.getNoEquipement()))
      {
        return el;
      }

    }
    return null;
  }

  default public ElementComparaison getElementComparaisonPA(List<ElementComparaison> list_p, String clientOp, String noCompte, String idPa)
  {
    for (ElementComparaison el : list_p)
    {
      if (el.getClientOperateur().equals(clientOp) && el.getNoCompte().equals(noCompte) && idPa.equals(el.getIdentifiantFonctionnelPA()))
      {
        return el;
      }

    }
    return null;
  }

  /**
   * Get an ElementComparaison in the list given in parameter by its Id.
   *
   * @param list_p
   *          List of ElementComparaison
   * @param identPa
   * @param identifier
   *          id of ElementComparaison too get.
   * @return
   */
  default public ElementComparaison getElementComparaisonPFI(List<ElementComparaison> list_p, String clientOp, String noCompte)
  {
    for (ElementComparaison el : list_p)
    {
      if (el.getClientOperateur().equals(clientOp) && el.getNoCompte().equals(noCompte))
      {
        return el;
      }

    }
    return null;
  }

  default public ElementComparaison getElementComparaisonSA(List<ElementComparaison> list_p, String clientOp, String noCompte, String idSa)
  {
    for (ElementComparaison el : list_p)
    {
      if (el.getClientOperateur().equals(clientOp) && el.getNoCompte().equals(noCompte) && idSa.equals(el.getNoServiceAccessible()))
      {
        return el;
      }

    }
    return null;
  }

  default public ElementComparaison getElementComparaisonSAPA(List<ElementComparaison> list_p, String clientOp, String noCompte, String idSa, String idPa)
  {
    for (ElementComparaison el : list_p)
    {
      if (el.getClientOperateur().equals(clientOp) && el.getNoCompte().equals(noCompte) && idPa.equals(el.getIdentifiantFonctionnelPA()) && idSa.equals(el.getNoServiceAccessible()))
      {
        return el;
      }

    }
    return null;
  }

  /**
   * Build AccesTechnique
   *
   * @return The AccesTechnique object
   */
  default AccesTechnique buildAccesTechnique()
  {
    AccesTechnique accesTechnique = new AccesTechnique(IModificationValue_Test.TECHNOLOGIE_ACCES, IModificationValue_Test.ID_PROFIL_TECHNIQUE);
    accesTechnique.setIdOperateurCollecte(IModificationValue_Test.ID_OPERATEUR_COLLECTE);
    accesTechnique.setCodeOperateurImmeuble(IModificationValue_Test.CODE_OPERATEUR_IMMEUBLE);
    accesTechnique.setTypeDegroupage(IModificationValue_Test.TYPE_DEGROUPAGE);
    return accesTechnique;
  }

  /**
   * Build AccesTechniqueCommerciale
   *
   * @return {@link AccessTechniqueCommercial} object
   */
  default AccessTechniqueCommercial buildAccesTechniqueCommercial()
  {
    AccessTechniqueCommercial accessTechniqueCommercial = new AccessTechniqueCommercial();
    accessTechniqueCommercial.setCodeAccesTechnique(IModificationValue_Test.CODE_ACCES_TECHNIQUE);
    accessTechniqueCommercial.setTechnologieAcces(IModificationValue_Test.TECHNOLOGIE_ACCES);
    return accessTechniqueCommercial;
  }

  /**
   * Build AdresseInstallation
   *
   * @return The {@link AdresseInstallation} object
   */
  default AdresseInstallation buildAdresseInstallation()
  {
    AdresseInstallation adresseInstallation = new AdresseInstallation(IModificationValue_Test.NUMERO, IModificationValue_Test.CODE_POSTAL, IModificationValue_Test.VILLE);
    adresseInstallation.setIndiceRepetition(IModificationValue_Test.INDICE_REPETITION);
    adresseInstallation.setNomVoie(IModificationValue_Test.NOM_VOIE);
    adresseInstallation.setCodeInsee(IModificationValue_Test.CODE_INSEE);
    adresseInstallation.setCodeRivoli(IModificationValue_Test.CODE_RIVOLI);
    adresseInstallation.setPorte(IModificationValue_Test.PORTE);
    adresseInstallation.setLogo(IModificationValue_Test.LOGO);
    adresseInstallation.setBatiment(IModificationValue_Test.BATIMENT);
    adresseInstallation.setEscalier(IModificationValue_Test.ESCALIER);
    adresseInstallation.setEtage(IModificationValue_Test.ETAGE);
    adresseInstallation.setPrecedentProprietaire(IModificationValue_Test.PRECEDENT_PROPRIETAIRE);
    adresseInstallation.setHexacle(IModificationValue_Test.HEXACLE);
    return adresseInstallation;
  }

  /**
   * Build Commande
   *
   * @return The {@link Commande} object
   */
  default Commande buildCommande()
  {
    Commande commande = new Commande();
    commande.setClientOperateur(IModificationValue_Test.CLIENT_OPERATEUR);
    commande.setIdCmd(IModificationValue_Test.ID_CMD);
    commande.setNoCompte(IModificationValue_Test.NO_COMPTE);
    return commande;
  }

  /**
   * Build ContexteInstallation
   *
   * @return The {@link ContexteInstallation} object
   */
  default ContexteInstallation buildContexteInstallation()
  {
    ContexteInstallation contexteInstallation = new ContexteInstallation();
    contexteInstallation.setIdMandat(IModificationValue_Test.ID_MANDAT);
    contexteInstallation.setTypeMes(IModificationValue_Test.TYPE_MES);
    contexteInstallation.setIdRdv(IModificationValue_Test.ID_RDV);
    contexteInstallation.setPrestataire(IModificationValue_Test.PRESTATAIRE);
    contexteInstallation.setCommentaire(IModificationValue_Test.COMMENTAIRE);
    contexteInstallation.setContactNomPrenom(IModificationValue_Test.CONTACT_NOMPRENOM);
    contexteInstallation.setContactTelephone(IModificationValue_Test.CONTACT_TELEPHONE);
    contexteInstallation.setCreneauClient(IModificationValue_Test.CRENEAU_CLIENT);
    return contexteInstallation;
  }

  /**
   * @return
   */
  default Entreprise buildEntreprise()
  {
    return new Entreprise(IModificationValue_Test.NO_SIREN, IModificationValue_Test.RAISON_SOCIALE);
  }

  /**
   * Build EquipementDeclare object
   *
   * @return The {@link EquipementDeclare} Object
   */
  default EquipementDeclare buildEquipementDeclare()
  {
    EquipementDeclare equipementDeclare = new EquipementDeclare(IModificationValue_Test.NO_EQUIPEMENT, IModificationValue_Test.NO_IDENTIFIANT_EQUIP, "MODEM", Statut.ACTIF, null, null);
    equipementDeclare.setModele(IModificationValue_Test.MODELE_EQUIPEMENT);
    equipementDeclare.setNomFabricant(IModificationValue_Test.NOM_FABRICANT_EQUIP);
    equipementDeclare.setNoIdentifiantIadOnebox(IModificationValue_Test.NO_IDENTIFIANT_IAD_ONEBOX);
    equipementDeclare.setModeleIadOnebox(IModificationValue_Test.MODELE_IAD_ONEBOX);
    equipementDeclare.setNoIdentifiantStbOnebox(IModificationValue_Test.NO_IDENTIFIANT_STB_ONEBOX);
    equipementDeclare.setModeleStbOnebox(IModificationValue_Test.MODELE_STB_ONEBOX);
    equipementDeclare.setMacAddressModem(IModificationValue_Test.MAC_ADRESS_MODEM);
    equipementDeclare.setMacAddressMta(IModificationValue_Test.MAC_ADRESS_MTA);
    equipementDeclare.setMacAddressGateway(IModificationValue_Test.MAC_ADRESS_GATEWAY);
    equipementDeclare.setMacAddressTv(IModificationValue_Test.MAC_ADRESS_TV);
    equipementDeclare.setCodeEan(IModificationValue_Test.CODE_EAN_EQUIP);
    equipementDeclare.setNoEquipementLie(IModificationValue_Test.NO_EQUIPEMENT_LIE);
    return equipementDeclare;
  }

  /**
   * Build EquipementDeclare object
   *
   * @return The EquipementDeclare Object
   */
  default EquipementDeclare buildEquipementDeclareRandom()
  {
    EquipementDeclare equip = new EquipementDeclare(RandomStringUtils.random(20), RandomStringUtils.random(20), "MODEM", Statut.ACTIF, null, null);
    equip.setModele(RandomStringUtils.random(20));
    equip.setNomFabricant(RandomStringUtils.random(20));
    equip.setNoIdentifiantIadOnebox(RandomStringUtils.random(20));
    equip.setModeleIadOnebox(RandomStringUtils.random(20));
    equip.setNoIdentifiantStbOnebox(RandomStringUtils.random(20));
    equip.setModeleStbOnebox(RandomStringUtils.random(20));
    equip.setMacAddressModem(RandomStringUtils.random(20));
    equip.setMacAddressMta(RandomStringUtils.random(20));
    equip.setMacAddressGateway(RandomStringUtils.random(20));
    equip.setMacAddressTv(RandomStringUtils.random(20));
    equip.setCodeEan(RandomStringUtils.random(20));
    equip.setNoEquipementLie(RandomStringUtils.random(20));
    return equip;
  }

  /**
   * build Individu object
   *
   * @return {@link Individu} object
   */
  default Individu buildIndividu()
  {
    Individu individu = new Individu("M", "Santos", "John");
    return individu;
  }

  /**
   * Build InfoBrutBssGp
   *
   * @return The InfoBrutBssGp object
   */
  default InfoBrutBssGp buildInfoBrutBssGp()
  {
    InfoBrutBssGp infoBrutBssGp = new InfoBrutBssGp(true, true);
    infoBrutBssGp.setIdPrise(IModificationValue_Test.ID_PRISE);
    infoBrutBssGp.setCodeNRA(IModificationValue_Test.CODE_NRA);
    infoBrutBssGp.setIdRessourceReseauXDSL(IModificationValue_Test.ID_RESSOURCE_RESEAU_XDSL);
    infoBrutBssGp.setIdRessourceReseauFTTX(IModificationValue_Test.ID_RESSOURCE_RESEAU_FTTX);
    infoBrutBssGp.setIdLigne(IModificationValue_Test.ID_LIGNE);
    infoBrutBssGp.setIdAction(IModificationValue_Test.ID_ACTION);
    infoBrutBssGp.setTypeActionADSL(IModificationValue_Test.TYPE_ACTION_ADSL);
    infoBrutBssGp.setIndicateurAccesPRO(true);
    infoBrutBssGp.setReferencePmOi(IModificationValue_Test.REFERENCE_PM_OI);
    infoBrutBssGp.setAdslEtatFT(IModificationValue_Test.ADSL_ETAT_FT);
    infoBrutBssGp.setQualitesTVPossibles(IModificationValue_Test.QUALITES_TV_POSSIBLES);
    infoBrutBssGp.setIdClientExterne(IModificationValue_Test.ID_CLIENT_EXTERNE);
    infoBrutBssGp.setAccesTechnique(buildAccesTechnique());
    infoBrutBssGp.setAdresseInstallation(buildAdresseInstallation());
    return infoBrutBssGp;
  }

  /**
   * Build LienEquipementPA object
   *
   * @return The LienEquipementPA Object
   */
  default LienEquipementPA buildLienEquipementPA()
  {
    LienEquipementPA lienEquipementPA = new LienEquipementPA(IModificationValue_Test.NO_EQUIPEMENT, IModificationValue_Test.ID_FONCTIONNEL_PA, Statut.ACTIF, null, null);
    return lienEquipementPA;
  }

  /**
   * Build LienSAPA object
   *
   * @return The LienSAPA Object
   */
  default LienSAPA buildLienSAPA()
  {
    LienSAPA lienSAPA = new LienSAPA(IModificationValue_Test.NO_SERVICE_ACCESSIBLE, IModificationValue_Test.ID_FONCTIONNEL_PA, Statut.ACTIF, null, null);
    return lienSAPA;
  }

  /**
   * Build PA object
   *
   * @return The PA Object
   */
  default PA buildPA(String id_p, String typePA_p)
  {
    PA pa = new PA(id_p, typePA_p, Statut.ACTIF, null, null);
    pa.setIdentifiantFonctionnelPALie(IModificationValue_Test.ID_FONCTIONNEL_PA_LIE);

    switch (typePA_p)
    {
      case PointAccesLigneFixe.TYPE:
        pa.setPaTypeLigneFixe(buildPaTypeLigneFixe());
        break;
      case PointAccesCompteAcces.TYPE:
        pa.setPaTypeCompteAcces(buildPaTypeCompteAcces());
        break;
      case PointAccesTV.TYPE:
        pa.setPaTypeTv(buildPaTypeTV());
        break;
      case PointAccesVoip.TYPE:
        pa.setPaTypeVoip(buildPaTypeVoip());
        break;
      case PointAccesFax.TYPE:
        pa.setPaTypeFax(buildPaTypeFax());
        break;
      default:
        break;
    }
    return pa;
  }

  /**
   * Build PA object
   *
   * @return The PA Object
   */
  default PA buildPARandom(String id_p, String typePA_p)
  {
    PA pa = new PA(id_p, typePA_p, Statut.ACTIF, null, null);
    pa.setIdentifiantFonctionnelPALie(RandomStringUtils.random(20));

    switch (typePA_p)
    {
      case PointAccesLigneFixe.TYPE:
        pa.setPaTypeLigneFixe(buildPaTypeLigneFixe());
        break;
      case PointAccesCompteAcces.TYPE:
        pa.setPaTypeCompteAcces(buildPaTypeCompteAcces());
        break;
      case PointAccesTV.TYPE:
        pa.setPaTypeTv(buildPaTypeTV());
        break;
      case PointAccesVoip.TYPE:
        pa.setPaTypeVoip(buildPaTypeVoip());
        break;
      case PointAccesFax.TYPE:
        pa.setPaTypeFax(buildPaTypeFax());
        break;
      default:
        break;
    }
    return pa;
  }

  /**
   * Build PaTypeCompteAcces
   *
   * @return The PaTypeCompteAcces object
   */
  default PaTypeCompteAcces buildPaTypeCompteAcces()
  {
    PaTypeCompteAcces paTypeCompteAcces = new PaTypeCompteAcces(IModificationValue_Test.EMAIL_LOGIN);
    return paTypeCompteAcces;
  }

  /**
   * Build PaTypeFax
   *
   * @return The PaTypeFax object
   */
  default PaTypeFax buildPaTypeFax()
  {
    PaTypeFax paTypeFax = new PaTypeFax(IModificationValue_Test.NUMERO_TELEPHONE);
    return paTypeFax;
  }

  /**
   * Build PaTypeLigneFixe
   *
   * @return The PaTypeLigneFixe Object
   */
  default PaTypeLigneFixe buildPaTypeLigneFixe()
  {
    PaTypeLigneFixe paTypeLigneFixe = new PaTypeLigneFixe();
    paTypeLigneFixe.setDistance(IModificationValue_Test.DISTANCE);
    paTypeLigneFixe.setDatePriseEnCompteChangementStatut(LocalDateTime.now());
    paTypeLigneFixe.setInfoBrutBssGp(buildInfoBrutBssGp());
    paTypeLigneFixe.setIdRaccordement(IModificationValue_Test.ID_RACCORDEMENT);
    paTypeLigneFixe.setContexteInstallation(buildContexteInstallation());
    paTypeLigneFixe.setRaccordementCommercial(buildRaccordementCommercial());
    paTypeLigneFixe.setVlan(IModificationValue_Test.VLAN);
    return paTypeLigneFixe;
  }

  /**
   * Build PaTypeTv
   *
   * @return The PaTypeTv object
   */
  default PaTypeTv buildPaTypeTV()
  {
    PaTypeTv paTypeTv = new PaTypeTv(IModificationValue_Test.ID_COMPTE_TV, IModificationValue_Test.ID_CONTENU_TV);
    return paTypeTv;
  }

  /**
   * Build PaTypeVoip
   *
   * @return The PaTypeVoip object
   */
  default PaTypeVoip buildPaTypeVoip()
  {
    PaTypeVoip paTypeVoip = new PaTypeVoip(IModificationValue_Test.NUMERO_TELEPHONE, IModificationValue_Test.CODE_RIO, IModificationValue_Test.NUMERO_PORT_TELEPHONIQUE);
    return paTypeVoip;
  }

  /**
   * Build PA object
   *
   * @return The PA Object
   */
  default PA buildPAWithRandom(String id)
  {
    PA pa = new PA(id, "LIGNE_FIXE", Statut.ACTIF, null, null);
    pa.setIdentifiantFonctionnelPALie(RandomStringUtils.random(20));
    if (new Random().nextBoolean())
    {
      pa.setPaTypeLigneFixe(buildPaTypeLigneFixe());
    }
    if (new Random().nextBoolean())
    {
      pa.setPaTypeCompteAcces(buildPaTypeCompteAcces());
    }
    if (new Random().nextBoolean())
    {
      pa.setPaTypeTv(buildPaTypeTV());
    }
    if (new Random().nextBoolean())
    {
      pa.setPaTypeVoip(buildPaTypeVoip());
    }
    if (new Random().nextBoolean())
    {
      pa.setPaTypeFax(buildPaTypeFax());
    }
    return pa;
  }

  /**
   * build PFI object
   *
   * @return
   */
  default PFI buildPFI()
  {
    PFI pfi = new PFI();

    pfi.setStatut(Statut.ACTIF);
    pfi.setNoCompte("pfi1");
    pfi.setClientOperateur("BSS_ENT");
    pfi.setTitulaire(buildTitulaire());
    pfi.setLigneMarche(IModificationValue_Test.LIGNE_MARCHE);
    return pfi;
  }

  /**
   * build PFI object
   *
   * @param n
   *          number f wanted PA in PA list
   *
   * @return
   */
  default PFI buildPFIWith(int n, String typePA_p)
  {
    if (n < 0)
    {
      n = 0;
    }
    PFI pfi = new PFI();

    pfi.setStatut(Statut.ACTIF);
    pfi.setNoCompte("pfi1");
    pfi.setClientOperateur("BSS_ENT");

    while (n > 0)
    {
      List<PA> pal = pfi.getPa();
      pal.add(buildPA("pa" + n--, typePA_p));
      pfi.setPa(pal);
    }
    pfi.setTitulaire(buildTitulaireWithIndividu());
    return pfi;
  }

  /**
   * build PFI object
   *
   * @param n
   *          number f wanted EquipementDeclare in EquipementDeclare list
   *
   * @return
   */
  default PFI buildPFIWithEquipementDeclare(int n)
  {
    if (n < 0)
    {
      n = 0;
    }
    PFI pfi = new PFI();

    pfi.setStatut(Statut.ACTIF);
    pfi.setNoCompte("pfi1");
    pfi.setClientOperateur("BSS_ENT");

    while (n > 0)
    {
      List<EquipementDeclare> equipList = pfi.getEquipementDeclare();
      EquipementDeclare equip = buildEquipementDeclareRandom();
      equip.setNoEquipement("equip" + n--);
      equipList.add(equip);
      pfi.setEquipementDeclare(equipList);
    }
    pfi.setTitulaire(buildTitulaireWithIndividu());
    return pfi;
  }

  /**
   * build PFI object
   *
   * @param n
   *          number f wanted LienEquipementPA in LienEquipementPA list
   *
   * @return
   */
  default PFI buildPFIWithLienEquipementPA(int n)
  {
    if (n < 0)
    {
      n = 0;
    }
    PFI pfi = new PFI();

    pfi.setStatut(Statut.ACTIF);
    pfi.setNoCompte("pfi1");
    pfi.setClientOperateur("BSS_ENT");

    while (n > 0)
    {
      List<LienEquipementPA> equipList = pfi.getLienEquipementPA();
      LienEquipementPA equip = buildLienEquipementPA();
      equip.setNoEquipement("equip" + n);
      equip.setIdFonctionnelPa("pa" + n);
      n--;
      equipList.add(equip);
      pfi.setLienEquipementPA(equipList);
    }
    pfi.setTitulaire(buildTitulaireWithIndividu());
    return pfi;
  }

  /**
   * build PFI object
   *
   * @param n
   *          number f wanted LienSAPA in LienSAPA list
   *
   * @return
   */
  default PFI buildPFIWithLienSAPA(int n)
  {
    if (n < 0)
    {
      n = 0;
    }
    PFI pfi = new PFI();

    pfi.setStatut(Statut.ACTIF);
    pfi.setNoCompte("pfi1");
    pfi.setClientOperateur("BSS_ENT");

    while (n > 0)
    {
      List<LienSAPA> sapaList = pfi.getLienSAPA();
      LienSAPA sapa = buildLienSAPA();
      sapa.setNoServiceAccessible("sa" + n);
      sapa.setIdentifiantFonctionnelPA("pa" + n);
      n--;
      sapaList.add(sapa);
      pfi.setLienSAPA(sapaList);
    }
    pfi.setTitulaire(buildTitulaireWithIndividu());
    return pfi;
  }

  /**
   * build PFI object
   *
   * @param n
   *          number f wanted PA in PA list
   *
   * @return
   */
  default PFI buildPFIWithLists(int nSa, int nPa, int nSaPa, int nEq, int nEqPa)
  {

    PFI pfi = new PFI();

    pfi.setStatut(Statut.ACTIF);
    pfi.setNoCompte("pfi1");
    pfi.setClientOperateur("BSS_ENT");
    pfi.setTitulaire(buildTitulaireWithIndividu());
    while (nSa > 0)
    {
      List<SA> sal = pfi.getSa();
      sal.add(buildSA(RandomStringUtils.random(20)));
      nSa--;
      pfi.setSa(sal);
    }
    while (nPa > 0)
    {
      List<PA> pal = pfi.getPa();
      pal.add(buildPAWithRandom(RandomStringUtils.random(20)));
      nPa--;
      pfi.setPa(pal);
    }
    while (nSaPa > 0)
    {
      List<LienSAPA> sapal = pfi.getLienSAPA();
      LienSAPA sapa = buildLienSAPA();
      sapa.setNoServiceAccessible(RandomStringUtils.random(20));
      sapa.setIdentifiantFonctionnelPA(RandomStringUtils.random(20));
      sapal.add(sapa);
      nSaPa--;
      pfi.setLienSAPA(sapal);
    }
    while (nEq > 0)
    {
      List<EquipementDeclare> eqpl = pfi.getEquipementDeclare();
      EquipementDeclare eqp = buildEquipementDeclareRandom();
      eqp.setNoEquipement(RandomStringUtils.random(20));
      nEq--;
      eqpl.add(eqp);
      pfi.setEquipementDeclare(eqpl);
    }
    while (nEqPa > 0)
    {
      List<LienEquipementPA> eqpPal = pfi.getLienEquipementPA();
      LienEquipementPA eqpPa = buildLienEquipementPA();
      eqpPa.setNoEquipement(RandomStringUtils.random(20));
      eqpPa.setIdFonctionnelPa(RandomStringUtils.random(20));
      nEqPa--;
      eqpPal.add(eqpPa);
      pfi.setLienEquipementPA(eqpPal);
    }

    return pfi;
  }

  /**
   * build PFI object
   *
   * @param n
   *          number f wanted PA in PA list
   *
   * @return
   */
  default PFI buildPFIWithPA(int n, String typePA_p)
  {
    if (n < 0)
    {
      n = 0;
    }
    PFI pfi = new PFI();

    pfi.setStatut(Statut.ACTIF);
    pfi.setNoCompte("pfi1");
    pfi.setClientOperateur("BSS_ENT");

    while (n > 0)
    {
      List<PA> pal = pfi.getPa();
      pal.add(buildPA("pa" + n--, typePA_p));
      pfi.setPa(pal);
    }
    pfi.setTitulaire(buildTitulaireWithIndividu());
    return pfi;
  }

  /**
   * build PFI object
   *
   * @param n
   *          number f wanted SA in SA list
   *
   * @return
   */
  default PFI buildPFIWithSA(int n)
  {
    if (n < 0)
    {
      n = 0;
    }
    PFI pfi = new PFI();

    pfi.setStatut(Statut.ACTIF);
    pfi.setNoCompte("pfi1");
    pfi.setClientOperateur("BSS_ENT");

    while (n > 0)
    {
      List<SA> sal = pfi.getSa();
      sal.add(buildSA("sa" + n--));
      pfi.setSa(sal);
    }
    pfi.setTitulaire(buildTitulaireWithIndividu());
    return pfi;
  }

  default RaccordementCommercial buildRaccordementCommercial()
  {
    RaccordementCommercial raccordementCommercial = new RaccordementCommercial();
    raccordementCommercial.setAccesTechniqueCommercial(buildAccesTechniqueCommercial());
    raccordementCommercial.setCodeNro(RandomStringUtils.random(20));
    return raccordementCommercial;
  }

  /**
   * build Individu object
   *
   * @return
   */
  default Individu buildRandomIndividu()
  {
    Individu i = new Individu(RandomStringUtils.random(1), RandomStringUtils.random(10), RandomStringUtils.random(10));
    return i;
  };

  /**
   * Build Raccordement
   *
   * @return The Raccordement object
   */
  /*  default Raccordement buildRaccordement()
  {
    Raccordement raccordement = new Raccordement();
    raccordement.setIdRaccordement("123456");
    raccordement.setInfoBrutBssGp(buildInfoBrutBssGp());
    return raccordement;
  }
  */
  /**
   * Build SA object
   *
   * @return The Random SA
   */
  default SA buildSA()
  {
    SA sa = new SA();
    sa.setStatut(Statut.ACTIF);
    sa.setNoServiceCommercial(IModificationValue_Test.NO_SERVICE_COMMERCIAL);
    sa.setNoServiceAccessible(IModificationValue_Test.NO_SERVICE_ACCESSIBLE);
    sa.setNomServiceCommercial(IModificationValue_Test.NOM_SERVICE_COMMERCIAL);
    sa.setCategorieServiceCommercial(IModificationValue_Test.CATEGORIE_SERVICE_COMMERCIAL);
    return sa;
  }

  /**
   * Build SA object
   *
   * @return
   */
  default SA buildSA(String id)
  {
    SA sa = new SA();
    sa.setStatut(Statut.ACTIF);
    sa.setNoServiceCommercial("1");
    sa.setNoServiceAccessible(id); //identifier
    sa.setNomServiceCommercial("service1");
    sa.setCategorieServiceCommercial("catg1");
    return sa;
  }

  default Titulaire buildTitulaire()
  {
    Titulaire titulaire = new Titulaire(TypeTitulaire.INDIVIDU, IModificationValue_Test.NO_PERSONNE, null, null);
    titulaire.setNoTel(IModificationValue_Test.NUMERO_TELEPHONE);
    titulaire.setEmail(IModificationValue_Test.EMAIL_LOGIN);
    titulaire.setIndividu(buildIndividu());
    titulaire.setEntreprise(buildEntreprise());
    return titulaire;
  }

  default Titulaire buildTitulaireWithIndividu()
  {
    Titulaire t = new Titulaire(TypeTitulaire.INDIVIDU, "p1", null, null);
    t.setNoTel("123456789");
    t.setEmail("teste@teste.pt");
    t.setIndividu(buildIndividu());
    return t;
  }

  /**
   * Get a commercial object of type T from a list of Commercial objects of type T.
   *
   * @param l
   *          The list
   * @param id
   *          The id to match
   * @return Element that matches
   */
  default <T> T getCommercialObjectByID(List<T> l, String id)
  {
    IdProvider<T> ip = new IdProvider<>();
    for (T t : l)
    {
      if (id.equals(ip.getId(t)))
      {
        return t;
      }
    }
    return null;
  }

  /**
   * check if a Modification list contains a modification given his identifier
   *
   * @param modifs_p
   *          List of modifications
   * @param id_p
   *          identifier to match
   * @return Element that matches
   */
  default <T> boolean isModificationWithIdInList(List<Modification<T>> modifs_p, String id_p)
  {
    for (Modification<T> m : modifs_p)
    {
      if (m.getIdentifier().equals(id_p))
      {
        return true;
      }
    }
    return false;
  }

}
