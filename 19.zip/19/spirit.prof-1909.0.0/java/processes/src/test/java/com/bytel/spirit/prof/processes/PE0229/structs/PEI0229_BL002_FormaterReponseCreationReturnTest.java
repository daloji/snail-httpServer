/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PE0229.structs;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PowerMockListener;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.testlisteners.FieldDefaulter;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.modules.junit4.PowerMockRunnerDelegate;
import org.powermock.reflect.Whitebox;
import org.springframework.test.context.ContextConfiguration;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.test.podam.PodamBytelJUnit4ClassRunner;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.spirit.common.shared.misc.error.ReponseErreur;
import com.bytel.spirit.prof.processes.PE0229.structs.PEI0229_BL002_FormaterReponseCreationReturn.ReponseFonctionnelle;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author jjoly
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PowerMockListener(FieldDefaulter.class)
@PowerMockRunnerDelegate(PodamBytelJUnit4ClassRunner.class)
@ContextConfiguration("classpath:BeansProcessTestMocks.xml")
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
@PrepareForTest({ PEI0229_BL002_FormaterReponseCreationReturn.class })
public final class PEI0229_BL002_FormaterReponseCreationReturnTest
{
  /**
   * bean Factory generation
   */
  private static PodamFactory __podam;

  /**
   *
   */
  private static Retour __retour;

  /**
   * + The error's response
   */
  private static ReponseErreur __reponseErreur;

  /**
   * The fonctional response
   */
  private static ReponseFonctionnelle __reponseFonctionnelle;

  /**
   * Initialize before all tests
   *
   * @throws Exception
   *           On errors Exception to be thrown in case of failure
   */
  @BeforeClass
  public static void setUpBeforeClass() throws Exception
  {
    __podam = new PodamFactoryImpl();
    __podam.getStrategy().setMemoization(false);
    __podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());

    __retour = RetourFactory.createOkRetour();
    __reponseErreur = __podam.manufacturePojoWithFullData(ReponseErreur.class);
    __reponseFonctionnelle = __podam.manufacturePojoWithFullData(ReponseFonctionnelle.class);
  }

  /**
   * Instance to evaluate
   */
  private PEI0229_BL002_FormaterReponseCreationReturn _instance;

  /**
   * Exception has been thrown
   */
  private boolean _exception;

  /**
   * Initialize before tests
   *
   * @throws Exception
   *           On errors Thrown in case of error during switch in attributes of parent class
   */
  @Before
  public void setUp() throws Exception
  {
    _instance = null;
    _exception = false;

    PowerMock.resetAll();
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.prof.processes.PE0229.structs.PEI0229_BL002_FormaterReponseCreationReturn#PEI0229_BL002_FormaterReponseCreationReturn(com.bytel.ravel.common.business.generated.Retour)}.<br/>
   * <b>Entrées:</b>NULL value in input<br/>
   * <b>Attendu:</b>NullPointerException<br/>
   *
   * @throws Exception
   *           On errors
   */
  @Test
  public void testPEI0229_BL002_FormaterReponseCreationReturn_001() throws Exception
  {
    try
    {
      PowerMock.replayAll();

      _instance = new PEI0229_BL002_FormaterReponseCreationReturn(null);
    }
    catch (final NullPointerException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertTrue(_exception);

      assertNull(_instance);
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.prof.processes.PE0229.structs.PEI0229_BL002_FormaterReponseCreationReturn#PEI0229_BL002_FormaterReponseCreationReturn(com.bytel.ravel.common.business.generated.Retour)}.<br/>
   * <b>Entrées:</b><br/>
   * <b>Attendu:</b>OK<br/>
   *
   * @throws Exception
   *           On errors
   */
  @Test
  public void testPEI0229_BL002_FormaterReponseCreationReturn_002() throws Exception
  {
    final Retour expected = __retour;
    Retour actual = null;

    try
    {
      PowerMock.replayAll();

      _instance = new PEI0229_BL002_FormaterReponseCreationReturn(RetourFactory.createOkRetour());
      actual = Whitebox.getInternalState(_instance, "_retour"); //$NON-NLS-1$
    }
    catch (final Exception e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertFalse(_exception);

      assertNotNull(_instance);
      assertEquals(expected, actual);
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.prof.processes.PE0229.structs.PEI0229_BL002_FormaterReponseCreationReturn#getRetour}.<br/>
   * <b>Entrées:</b><br/>
   * <b>Attendu:</b>OK<br/>
   *
   * @throws Exception
   *           On errors
   */
  @Test
  public void testPEI0229_BL002_FormaterReponseCreationReturn_003() throws Exception
  {
    final Retour expected = __retour;
    Retour actual = null;

    try
    {
      PowerMock.replayAll();

      _instance = new PEI0229_BL002_FormaterReponseCreationReturn(RetourFactory.createKO(null, null, null));
      Whitebox.setInternalState(_instance, "_retour", expected); //$NON-NLS-1$
      actual = _instance.getRetour();
    }
    catch (final Exception e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertNotNull(actual);
      assertEquals(expected, actual);
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.prof.processes.PE0229.structs.PEI0229_BL002_FormaterReponseCreationReturn#setRetour(com.bytel.ravel.common.business.generated.Retour)}
   * <b>Entrées:</b><br/>
   * <b>Attendu:</b>OK<br/>
   *
   * @throws Exception
   *           On errors
   */
  @Test
  public void testPEI0229_BL002_FormaterReponseCreationReturn_004() throws Exception
  {
    final Retour expected = __retour;
    Retour actual = null;

    try
    {
      PowerMock.replayAll();

      _instance = new PEI0229_BL002_FormaterReponseCreationReturn(RetourFactory.createKO(null, null, null));
      _instance.setRetour(expected);
      actual = Whitebox.getInternalState(_instance, "_retour"); //$NON-NLS-1$
    }
    catch (final Exception e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertNotNull(actual);
      assertEquals(expected, actual);
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.prof.processes.PE0229.structs.PEI0229_BL002_FormaterReponseCreationReturn#getReponseErreur()}.<br/>
   * <b>Entrées:</b><br/>
   * <b>Attendu:</b><br/>
   *
   * @throws Exception
   *           On errors
   */
  @Test
  public void testPEI0229_BL002_FormaterReponseCreationReturn_005() throws Exception
  {
    final ReponseErreur expected = __reponseErreur;
    ReponseErreur actual = null;

    try
    {
      PowerMock.replayAll();

      _instance = new PEI0229_BL002_FormaterReponseCreationReturn(RetourFactory.createKO(null, null, null));
      Whitebox.setInternalState(_instance, "_reponseErreur", expected); //$NON-NLS-1$
      actual = _instance.getReponseErreur();
    }
    catch (final Exception e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertNotNull(actual);
      assertEquals(expected, actual);
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.prof.processes.PE0229.structs.PEI0229_BL002_FormaterReponseCreationReturn#setReponseErreur(com.bytel.spirit.common.shared.misc.error.ReponseErreur)}.<br/>
   * <b>Entrées:</b><br/>
   * <b>Attendu:</b>OK<br/>
   *
   * @throws Exception
   *           On errors
   */
  @Test
  public void testPEI0229_BL002_FormaterReponseCreationReturn_006() throws Exception
  {
    final ReponseErreur expected = __reponseErreur;
    ReponseErreur actual = null;

    try
    {
      PowerMock.replayAll();

      _instance = new PEI0229_BL002_FormaterReponseCreationReturn(RetourFactory.createKO(null, null, null));
      _instance.setReponseErreur(expected);
      actual = Whitebox.getInternalState(_instance, "_reponseErreur"); //$NON-NLS-1$
    }
    catch (final Exception e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertNotNull(actual);
      assertEquals(expected, actual);
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.prof.processes.PE0229.structs.PEI0229_BL002_FormaterReponseCreationReturn#getReponseFonctionnelle()}.<br/>
   * <b>Entrées:</b><br/>
   * <b>Attendu:</b><br/>
   *
   * @throws Exception
   *           On errors
   */
  @Test
  public void testPEI0229_BL002_FormaterReponseCreationReturn_007() throws Exception
  {
    final ReponseFonctionnelle expected = __reponseFonctionnelle;
    ReponseFonctionnelle actual = null;

    try
    {
      PowerMock.replayAll();

      _instance = new PEI0229_BL002_FormaterReponseCreationReturn(RetourFactory.createKO(null, null, null));
      Whitebox.setInternalState(_instance, "_reponseFonctionnelle", expected); //$NON-NLS-1$
      actual = _instance.getReponseFonctionnelle();
    }
    catch (final Exception e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertNotNull(actual);
      assertEquals(expected, actual);
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.prof.processes.PE0229.structs.PEI0229_BL002_FormaterReponseCreationReturn#setReponseFonctionnelle(com.bytel.spirit.prof.processes.PE0229.structs.PEI0229_BL002_FormaterReponseCreationReturn.ReponseFonctionnelle)}.<br/>
   * <b>Entrées:</b><br/>
   * <b>Attendu:</b>OK<br/>
   *
   * @throws Exception
   *           On errors
   */
  @Test
  public void testPEI0229_BL002_FormaterReponseCreationReturn_008() throws Exception
  {
    final ReponseFonctionnelle expected = __reponseFonctionnelle;
    ReponseFonctionnelle actual = null;

    try
    {
      PowerMock.replayAll();

      _instance = new PEI0229_BL002_FormaterReponseCreationReturn(RetourFactory.createKO(null, null, null));
      _instance.setReponseFonctionnelle(expected);
      actual = Whitebox.getInternalState(_instance, "_reponseFonctionnelle"); //$NON-NLS-1$
    }
    catch (final Exception e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertNotNull(actual);
      assertEquals(expected, actual);
    }
  }
}
