/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PE0229;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.text.MessageFormat;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.HttpMethod;

import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PowerMockListener;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.testlisteners.FieldDefaulter;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.modules.junit4.PowerMockRunnerDelegate;
import org.powermock.reflect.Whitebox;
import org.springframework.test.context.ContextConfiguration;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.datetime.DateTimeManager;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.response.IRavelResponse;
import com.bytel.ravel.common.factory.response.RavelResponseFactory;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.json.IRavelJson;
import com.bytel.ravel.common.json.IRavelJsonAdapter;
import com.bytel.ravel.common.json.RavelJson.RavelJsonBuilder;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.test.podam.PodamBytelJUnit4ClassRunner;
import com.bytel.ravel.common.utils.DateTimeTools.DateTimeFormatPattern;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.net.http.HttpConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.activities.shared.BL1700_AjouterRefFonc;
import com.bytel.spirit.common.activities.shared.BL1700_AjouterRefFonc.BL1700_AjouterRefFoncBuilder;
import com.bytel.spirit.common.activities.shared.BL800_ObtenirSequence;
import com.bytel.spirit.common.activities.shared.BL800_ObtenirSequence.BL800_ObtenirSequenceBuilder;
import com.bytel.spirit.common.activities.shared.structs.UniqueIdConstant;
import com.bytel.spirit.common.connectors.cmd.CMDProxy;
import com.bytel.spirit.common.connectors.rst.RSTProxy;
import com.bytel.spirit.common.shared.functional.types.json.RavelJsonTools;
import com.bytel.spirit.common.shared.functional.types.json.action_corrective.ActionCorrective;
import com.bytel.spirit.common.shared.functional.types.json.action_corrective.ActionServiceTechnique;
import com.bytel.spirit.common.shared.functional.types.json.action_corrective.ActionServiceTechniqueMail;
import com.bytel.spirit.common.shared.functional.types.json.action_corrective.TypeAction;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.mail.DonneesProvisionneesSTPfsMail;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.mail.StPfsMail;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.processes.SpiritProcessSkeleton;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.ressources.SpiritConstants;
import com.bytel.spirit.common.shared.misc.tracabilite.IRefFoncConstants;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.cmd.Commande;
import com.bytel.spirit.common.shared.saab.cmd.ModificationCommercialeStatut;
import com.bytel.spirit.common.shared.saab.cmd.ModificationTechnique;
import com.bytel.spirit.common.shared.saab.cmd.ModificationTechniqueStatut;
import com.bytel.spirit.common.shared.saab.cmd.StatutCommercialAttendu;
import com.bytel.spirit.common.shared.saab.cmd.request.CreateModificationTechniqueRequest;
import com.bytel.spirit.common.shared.saab.rst.ServiceTechnique;
import com.bytel.spirit.common.shared.saab.rst.Statut;
import com.bytel.spirit.common.shared.saab.rst.request.UpdateServiceTechniqueRequest;
import com.bytel.spirit.common.shared.types.json.ModificationCommerciale;
import com.bytel.spirit.common.shared.types.json.Suivi;
import com.bytel.spirit.prof.processes.Messages;
import com.bytel.spirit.prof.processes.PE0229.PEP0229_CommandeActionCorrective.PEP0229_CommandeActionCorrectiveContext;
import com.bytel.spirit.prof.processes.PE0229.PEP0229_CommandeActionCorrective.State;
import com.bytel.spirit.prof.processes.PE0229.structs.PEP0229_BL001_Return;
import com.bytel.spirit.prof.processes.PE0229.structs.PEP0229_BL002_Return;
import com.bytel.spirit.prof.processes.PE0229.structs.PEP0229_BL002_Return.ReponseFonctionnelle;
import com.bytel.spirit.prof.processes.PE0229.structs.PEP0229_BL101_Return;
import com.bytel.spirit.prof.shared.types.json.CommandeId;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author jjoly
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PowerMockListener(FieldDefaulter.class)
@PowerMockRunnerDelegate(PodamBytelJUnit4ClassRunner.class)
@ContextConfiguration("classpath:BeansProcessTestMocks.xml")
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
@PrepareForTest({ PEP0229_CommandeActionCorrective.class, BL1700_AjouterRefFoncBuilder.class, BL1700_AjouterRefFonc.class, BL800_ObtenirSequenceBuilder.class, BL800_ObtenirSequence.class, CMDProxy.class, RSTProxy.class, PEP0229_BL001_Return.class, PEP0229_BL101_Return.class, RavelResponseFactory.class })
public final class PEP0229_CommandeActionCorrectiveTest
{
  /**
   * bean Factory generation
   */
  private static PodamFactory __podam;

  /**
   * Technical's Service identifier
   */
  private static String __idSt;

  /**
   * Commerciale's modification identifier
   */
  private static String __idModComm;

  /**
   * Commande identifier
   */
  private static String __idCmd;

  /**
   * Numero Compte PFS
   */
  private static String __noCompte;

  /**
   * Client Operateur
   */
  private static String __clientOperateur;

  /**
   * Correctives' actions
   */
  private static ActionCorrective __actionsCorrective;

  /**
   * Technical Service LAC
   */
  private static ServiceTechnique __lac;

  /**
   * Technical Service PFS
   */
  private static ServiceTechnique __pfs;

  /**
   * Technical Service RACCO
   */
  private static ServiceTechnique __racco;

  /**
   * ...
   */
  private static ModificationCommerciale __mc;

  /**
   * Initialize before all tests
   *
   * @throws Throwable
   *           On errors Exception to be thrown in case of failure
   */
  @BeforeClass
  public static void setUpBeforeClass() throws Throwable
  {
    __podam = new PodamFactoryImpl();
    __podam.getStrategy().setMemoization(false);
    __podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());

    __idSt = __podam.manufacturePojo(String.class);
    __idModComm = __podam.manufacturePojo(String.class);
    __idCmd = __podam.manufacturePojo(String.class);
    __noCompte = __podam.manufacturePojo(String.class);
    __clientOperateur = __podam.manufacturePojo(String.class);
    __actionsCorrective = __podam.manufacturePojoWithFullData(ActionCorrective.class);

    //    final StPfsMail stPfsMail = __podam.manufacturePojoWithFullData(StPfsMail.class);
    //    stPfsMail.setNiveauRestriction(__podam.manufacturePojo(String.class));
    //    final StPfs stPfs = new StPfs(TypePFS.MAIL.name());
    //    stPfs.setStPfsMail(stPfsMail);
    //    __pfs = new ServiceTechnique(__idSt, TypeST.PFS.name(), com.bytel.spirit.common.shared.saab.rst.Statut.ACTIF.name(), __clientOperateur, __noCompte);
    //    __pfs.setDateModification(LocalDateTime.now().truncatedTo(ChronoUnit.SECONDS));
    //    __pfs.setStPfs(stPfs);
    //    __racco = new ServiceTechnique(__podam.manufacturePojo(String.class), TypeST.RACCO.name(), com.bytel.spirit.common.shared.saab.rst.Statut.ACTIF.name(), __clientOperateur, __noCompte);
    //    __racco.setDateModification(LocalDateTime.now().truncatedTo(ChronoUnit.SECONDS));
    //    __lac = new ServiceTechnique(__podam.manufacturePojo(String.class), TypeST.LAC.name(), com.bytel.spirit.common.shared.saab.rst.Statut.ACTIF.name(), __clientOperateur, __noCompte);
    //    __lac.setDateModification(LocalDateTime.now().truncatedTo(ChronoUnit.SECONDS));

    __mc = new ModificationCommerciale();
    __mc.setIdModificationCommerciale(__idModComm);
    __mc.setIdCmd(__idCmd);
    __mc.setStatut(ModificationCommercialeStatut.EN_COURS.name());
    __mc.setTypeObjetCommercial("PFI"); //$NON-NLS-1$
    __mc.setClientOperateur(__clientOperateur);
    __mc.setNoCompte(__noCompte);
    __mc.setStatutCommercialAttendu(StatutCommercialAttendu.ACTIF.name());
    __mc.setDateCreation(LocalDateTime.now().truncatedTo(ChronoUnit.SECONDS));
    __mc.setDateModification(LocalDateTime.now().truncatedTo(ChronoUnit.SECONDS));
  }

  /**
   * RavelResponseFactory
   */
  @MockStrict
  private RavelResponseFactory _ravelResponseFactoryMock;

  /**
   * Mock de {@link BL1700_AjouterRefFonc}
   */
  @MockStrict
  protected BL1700_AjouterRefFonc _bl1700Mock;

  /**
   * Mock de {@link BL800_ObtenirSequence}
   */
  @MockStrict
  protected BL800_ObtenirSequence _bl800Mock;

  /**
   * Mock de {@link CMDProxy}
   */
  @MockStrict
  protected CMDProxy _cmdMock;

  /**
   * Mock de {@Code RSTProxy}
   */
  @MockStrict
  protected RSTProxy _rstMock;

  /**
   * Mock de {@Code RSTProxy}
   */
  @MockStrict
  protected PEP0229_BL001_Return _bl001Mock;

  /**
   * Mock de {@Code PEP0229_BL101_Return}
   */
  @MockStrict
  protected PEP0229_BL101_Return _bl101Mock;

  /**
   * Mock de {@link SpiritProcessSkeleton}
   */
  @MockStrict
  private SpiritProcessSkeleton _activityCallerMock;

  /**
   * The mock object {@code PEP0229_CommandeActionCorrectiveContext}
   */
  @MockStrict
  private PEP0229_CommandeActionCorrectiveContext _contextMock;

  /**
   * The mock object {@code Request}
   */
  //@MockStrict
  private Request _requestMock;

  /**
   * The mock object {@code IRavelResponse}
   */
  @MockStrict
  private IRavelResponse _responseMock;

  /**
   * The mock object {@code Tracabilite}
   */
  //@MockStrict
  private Tracabilite _tracabiliteMock;

  /**
   * Exception has been thrown
   */
  private boolean _exception;

  /**
   * Instance to evaluate
   */
  private PEP0229_CommandeActionCorrective _instance;

  /**
   * Initialize before tests
   *
   * @throws Exception
   *           On errors Thrown in case of error during switch in attributes of parent class
   */
  @Before
  public void setUp() throws Exception
  {
    _exception = false;
    _tracabiliteMock = new Tracabilite();
    _tracabiliteMock.setNomProcessus("PEP0229_CommandeActionCorrective"); //$NON-NLS-1$
    _requestMock = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    _requestMock.setHttpMethod(HttpMethod.POST);
    _requestMock.setContentType(HttpConstants.CONTENT_TYPE_JSON);
    _requestMock.setPayload(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss).toJson(new CommandeId(__idCmd), CommandeId.class));

    _instance = new PEP0229_CommandeActionCorrective();
    Whitebox.setInternalState(_instance, "_processContext", _contextMock); //$NON-NLS-1$
    Whitebox.setInternalState(_instance, "_tracabilite", _tracabiliteMock); //$NON-NLS-1$

    PowerMock.resetAll();

    PowerMock.mockStaticStrict(CMDProxy.class);
    PowerMock.mockStaticStrict(RSTProxy.class);
    PowerMock.mockStaticStrict(RavelResponseFactory.class);
  }

  /**
   * Test method for {@link com.bytel.spirit.prof.processes.PE0229.PEP0229_CommandeActionCorrective#continueProcess}.
   * <b>Entrées:</b> <br/>
   * <b>Attendu:</b> OK <br/>
   *
   * @throws Throwable
   *           On errors On errors
   */
  @Test
  public void testContinueProcess_001() throws Throwable
  {
    final Retour expected = RetourFactory.createOkRetour();
    Retour actual = null;

    try
    {
      //AspectLogger.logContinueProcess(EasyMock.anyObject(ProceedingJoinPoint.class));
      //EasyMock.expectLastCall().once();

      _instance = PowerMock.createPartialMock(PEP0229_CommandeActionCorrective.class, "PEP0229_BL005_GererErreurPROSPER"); //$NON-NLS-1$
      Whitebox.setInternalState(_instance, "_processContext", _contextMock); //$NON-NLS-1$
      Whitebox.setInternalState(_instance, "_tracabilite", _tracabiliteMock); //$NON-NLS-1$

      EasyMock.expect(_contextMock.getState()).andReturn(State.PEP0229_BL001).once();

      _contextMock.setState(State.PEP0229_END);
      EasyMock.expectLastCall().once();

      PowerMock.replayAll();

      _instance.setRetour(RetourFactory.createOkRetour());
      Whitebox.invokeMethod(_instance, "continueProcess", _requestMock, _tracabiliteMock); //$NON-NLS-1$
      actual = _instance.getRetour();
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse("Check no RavelException call", _exception); //$NON-NLS-1$

      assertNotNull("Check expected assignment", actual); //$NON-NLS-1$
      assertEquals("Check equality between expected and actual objects", expected, actual); //$NON-NLS-1$
    }
  }

  /**
   * Test method for {@link com.bytel.spirit.prof.processes.PE0229.PEP0229_CommandeActionCorrective#continueProcess}.
   * <b>Entrées:</b> <br/>
   * <b>Attendu:</b> OK <br/>
   *
   * @throws Throwable
   *           On errors On errors
   */
  @Test
  public void testContinueProcess_002() throws Throwable
  {
    final Retour expected = RetourFactory.createOkRetour();
    Retour actual = null;

    try
    {
      //AspectLogger.logContinueProcess(EasyMock.anyObject(ProceedingJoinPoint.class));
      //EasyMock.expectLastCall().once();

      _instance = PowerMock.createPartialMock(PEP0229_CommandeActionCorrective.class, "PEP0229_BL005_GererErreurPROSPER"); //$NON-NLS-1$
      Whitebox.setInternalState(_instance, "_processContext", _contextMock); //$NON-NLS-1$
      Whitebox.setInternalState(_instance, "_tracabilite", _tracabiliteMock); //$NON-NLS-1$

      EasyMock.expect(_contextMock.getState()).andReturn(State.PEP0229_BL005).once();

      PowerMock.expectPrivate(_instance, "PEP0229_BL005_GererErreurPROSPER", _tracabiliteMock, RetourFactory.createOkRetour()).andReturn(RetourFactory.createOkRetour()); //$NON-NLS-1$

      _contextMock.setState(State.PEP0229_END);
      EasyMock.expectLastCall().once();

      PowerMock.replayAll();

      _instance.setRetour(RetourFactory.createOkRetour());
      Whitebox.invokeMethod(_instance, "continueProcess", _requestMock, _tracabiliteMock); //$NON-NLS-1$
      actual = _instance.getRetour();
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse("Check no RavelException call", _exception); //$NON-NLS-1$

      assertNotNull("Check expected assignment", actual); //$NON-NLS-1$
      assertEquals("Check equality between expected and actual objects", expected, actual); //$NON-NLS-1$
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.prof.processes.PE0229.PEP0229_CommandeActionCorrective#PEP0229_BL001_VerifierDonnees}.
   * <b>Entrées:</b> BL1700 is generated an exception<br/>
   * <b>Attendu:</b> KO <br/>
   *
   * @throws Throwable
   *           On errors On errors
   */
  @Test
  public void testPEP0229_BL001_VerifierDonnees_001() throws Throwable
  {
    final Map<String, String> refFonc = new HashMap<>();
    refFonc.put(IRefFoncConstants.ID_CMD, __idCmd);

    final String message = __podam.manufacturePojo(String.class);
    final RavelException expected = new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.CNCTOR_00010, message);

    try
    {
      _contextMock.setState(State.PEP0229_BL001);
      EasyMock.expectLastCall().once();

      final BL1700_AjouterRefFoncBuilder builder = new BL1700_AjouterRefFoncBuilder();
      Whitebox.setInternalState(builder, "_toBuild", _bl1700Mock); //$NON-NLS-1$
      PowerMock.expectNew(BL1700_AjouterRefFoncBuilder.class).andReturn(builder).once();
      _bl1700Mock.setTracabilite(_tracabiliteMock);
      EasyMock.expectLastCall().once();
      _bl1700Mock.setRefFonc(refFonc);
      EasyMock.expectLastCall().once();
      EasyMock.expect(_bl1700Mock.getTracabilite()).andReturn(_tracabiliteMock).once();
      EasyMock.expect(_bl1700Mock.getRefFonc()).andReturn(refFonc).once();
      EasyMock.expect(_bl1700Mock.execute(EasyMock.anyObject(PEP0229_CommandeActionCorrective.class))).andThrow(new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.CNCTOR_00010, message)).once();

      PowerMock.replayAll();

      Whitebox.invokeMethod(_instance, "PEP0229_BL001_VerifierDonnees", _tracabiliteMock, __idCmd); //$NON-NLS-1$
    }
    catch (final RavelException actual)
    {
      _exception = true;

      assertEquals("Check RavelException._functionalResponse", expected.getFunctionalError(), actual.getFunctionalError()); //$NON-NLS-1$
      assertEquals("Check RavelException._exType", expected.getExceptionType(), actual.getExceptionType()); //$NON-NLS-1$
      assertEquals("Check RavelException._errorCode", expected.getErrorCode(), actual.getErrorCode()); //$NON-NLS-1$
      assertEquals("Check RavelException._sourceComponentName", expected.getSourceComponentName(), actual.getSourceComponentName()); //$NON-NLS-1$
      assertEquals("Check RavelException._detailMessage", expected.getMessage(), actual.getMessage()); //$NON-NLS-1$
    }
    finally
    {
      PowerMock.verifyAll();

      assertTrue("Check good RavelException call", _exception); //$NON-NLS-1$
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.prof.processes.PE0229.PEP0229_CommandeActionCorrective#PEP0229_BL001_VerifierDonnees}.
   * <b>Entrées:</b> CMD connector is generated an exception<br/>
   * <b>Attendu:</b> KO <br/>
   *
   * @throws Throwable
   *           On errors On errors
   */
  @Test
  public void testPEP0229_BL001_VerifierDonnees_002() throws Throwable
  {
    final Map<String, String> refFonc = new HashMap<>();
    refFonc.put(IRefFoncConstants.ID_CMD, __idCmd);

    final String message = __podam.manufacturePojo(String.class);
    final RavelException expected = new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.CNCTOR_00010, message);

    try
    {
      _contextMock.setState(State.PEP0229_BL001);
      EasyMock.expectLastCall().once();

      final BL1700_AjouterRefFoncBuilder builder = new BL1700_AjouterRefFoncBuilder();
      Whitebox.setInternalState(builder, "_toBuild", _bl1700Mock); //$NON-NLS-1$
      PowerMock.expectNew(BL1700_AjouterRefFoncBuilder.class).andReturn(builder).once();
      _bl1700Mock.setTracabilite(_tracabiliteMock);
      EasyMock.expectLastCall().once();
      _bl1700Mock.setRefFonc(refFonc);
      EasyMock.expectLastCall().once();
      EasyMock.expect(_bl1700Mock.getTracabilite()).andReturn(_tracabiliteMock).once();
      EasyMock.expect(_bl1700Mock.getRefFonc()).andReturn(refFonc).once();
      EasyMock.expect(_bl1700Mock.execute(EasyMock.anyObject(PEP0229_CommandeActionCorrective.class))).andReturn(null).once();

      EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdMock).once();
      EasyMock.expect(_cmdMock.commandeLireUn(_tracabiliteMock, __idCmd)).andThrow(new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.CNCTOR_00010, message)).once();

      PowerMock.replayAll();

      Whitebox.invokeMethod(_instance, "PEP0229_BL001_VerifierDonnees", _tracabiliteMock, __idCmd); //$NON-NLS-1$
    }
    catch (final RavelException actual)
    {
      _exception = true;

      assertEquals("Check RavelException._functionalResponse", expected.getFunctionalError(), actual.getFunctionalError()); //$NON-NLS-1$
      assertEquals("Check RavelException._exType", expected.getExceptionType(), actual.getExceptionType()); //$NON-NLS-1$
      assertEquals("Check RavelException._errorCode", expected.getErrorCode(), actual.getErrorCode()); //$NON-NLS-1$
      assertEquals("Check RavelException._sourceComponentName", expected.getSourceComponentName(), actual.getSourceComponentName()); //$NON-NLS-1$
      assertEquals("Check RavelException._detailMessage", expected.getMessage(), actual.getMessage()); //$NON-NLS-1$
    }
    finally
    {
      PowerMock.verifyAll();

      assertTrue("Check good RavelException call", _exception); //$NON-NLS-1$
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.prof.processes.PE0229.PEP0229_CommandeActionCorrective#PEP0229_BL001_VerifierDonnees}.
   * <b>Entrées:</b> CMD connector return an error<br/>
   * <b>Attendu:</b> KO <br/>
   *
   * @throws Throwable
   *           On errors On errors
   */
  @Test
  public void testPEP0229_BL001_VerifierDonnees_003() throws Throwable
  {
    final Commande commande = new Commande();
    commande.setIdCmd(__idCmd);
    commande.setStatut(com.bytel.spirit.common.shared.saab.cmd.Statut.REJETE.name());

    final String message = __podam.manufacturePojo(String.class);
    final Retour retour = RetourFactory.createNOK(IMegConsts.CAT1, IMegConsts.ERREUR_TECHNIQUE, message);

    final Map<String, String> refFonc = new HashMap<>();
    refFonc.put(IRefFoncConstants.ID_CMD, __idCmd);

    final PEP0229_BL001_Return expected = new PEP0229_BL001_Return(retour, null, null, null);
    PEP0229_BL001_Return actual = null;

    try
    {
      _contextMock.setState(State.PEP0229_BL001);
      EasyMock.expectLastCall().once();

      final BL1700_AjouterRefFoncBuilder builder = new BL1700_AjouterRefFoncBuilder();
      Whitebox.setInternalState(builder, "_toBuild", _bl1700Mock); //$NON-NLS-1$
      PowerMock.expectNew(BL1700_AjouterRefFoncBuilder.class).andReturn(builder).once();
      _bl1700Mock.setTracabilite(_tracabiliteMock);
      EasyMock.expectLastCall().once();
      _bl1700Mock.setRefFonc(refFonc);
      EasyMock.expectLastCall().once();
      EasyMock.expect(_bl1700Mock.getTracabilite()).andReturn(_tracabiliteMock).once();
      EasyMock.expect(_bl1700Mock.getRefFonc()).andReturn(refFonc).once();
      EasyMock.expect(_bl1700Mock.execute(EasyMock.anyObject(PEP0229_CommandeActionCorrective.class))).andReturn(null).once();

      EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdMock).once();
      EasyMock.expect(_cmdMock.commandeLireUn(_tracabiliteMock, __idCmd)).andReturn(new ConnectorResponse<>(retour, commande)).once();

      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_instance, "PEP0229_BL001_VerifierDonnees", _tracabiliteMock, __idCmd); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse("Check no RavelException call", _exception); //$NON-NLS-1$

      assertNotNull("Check expected assignment", actual); //$NON-NLS-1$
      assertEquals("Check equality between expected and actual objects", expected, actual); //$NON-NLS-1$
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.prof.processes.PE0229.PEP0229_CommandeActionCorrective#PEP0229_BL001_VerifierDonnees}.
   * <b>Entrées:</b> CMD connector return OK, but commande is REJETE<br/>
   * <b>Attendu:</b> KO <br/>
   *
   * @throws Throwable
   *           On errors On errors
   */
  @Test
  public void testPEP0229_BL001_VerifierDonnees_004() throws Throwable
  {
    final Commande commande = new Commande();
    commande.setIdCmd(__idCmd);
    commande.setStatut(com.bytel.spirit.common.shared.saab.cmd.Statut.REJETE.name());

    final Retour retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.DONNEE_INVALIDE, MessageFormat.format(Messages.getString("PE0229.BL001.InvalidParameterValue"), commande.getIdCmd(), commande.getStatut())); //$NON-NLS-1$

    final Map<String, String> refFonc = new HashMap<>();
    refFonc.put(IRefFoncConstants.ID_CMD, __idCmd);

    final PEP0229_BL001_Return expected = new PEP0229_BL001_Return(retour, null, null, null);
    PEP0229_BL001_Return actual = null;

    try
    {
      _contextMock.setState(State.PEP0229_BL001);
      EasyMock.expectLastCall().once();

      final BL1700_AjouterRefFoncBuilder builder = new BL1700_AjouterRefFoncBuilder();
      Whitebox.setInternalState(builder, "_toBuild", _bl1700Mock); //$NON-NLS-1$
      PowerMock.expectNew(BL1700_AjouterRefFoncBuilder.class).andReturn(builder).once();
      _bl1700Mock.setTracabilite(_tracabiliteMock);
      EasyMock.expectLastCall().once();
      _bl1700Mock.setRefFonc(refFonc);
      EasyMock.expectLastCall().once();
      EasyMock.expect(_bl1700Mock.getTracabilite()).andReturn(_tracabiliteMock).once();
      EasyMock.expect(_bl1700Mock.getRefFonc()).andReturn(refFonc).once();
      EasyMock.expect(_bl1700Mock.execute(EasyMock.anyObject(PEP0229_CommandeActionCorrective.class))).andReturn(null).once();

      EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdMock).once();
      EasyMock.expect(_cmdMock.commandeLireUn(_tracabiliteMock, __idCmd)).andReturn(new ConnectorResponse<>(RetourFactory.createOkRetour(), commande)).once();

      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_instance, "PEP0229_BL001_VerifierDonnees", _tracabiliteMock, __idCmd); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse("Check no RavelException call", _exception); //$NON-NLS-1$

      assertNotNull("Check expected assignment", actual); //$NON-NLS-1$
      assertEquals("Check equality between expected and actual objects", expected, actual); //$NON-NLS-1$
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.prof.processes.PE0229.PEP0229_CommandeActionCorrective#PEP0229_BL001_VerifierDonnees}.
   * <b>Entrées:</b> ActionServicetechnique are empty<br/>
   * <b>Attendu:</b> OK <br/>
   *
   * @throws Throwable
   *           On errors On errors
   */
  @Test
  public void testPEP0229_BL001_VerifierDonnees_005() throws Throwable
  {
    final Commande commande = new Commande();
    commande.setIdCmd(__idCmd);
    commande.setNoCompte(__noCompte);
    commande.setClientOperateur(__clientOperateur);
    commande.setStatut(com.bytel.spirit.common.shared.saab.cmd.Statut.ACQUITTE.name());

    ActionCorrective active = __podam.manufacturePojo(ActionCorrective.class);
    active.setActionsServicesTechniques(Arrays.asList());//force empty list
    active.setNoCompte(__noCompte);
    Suivi suivi = new Suivi("DEMARRE"); //$NON-NLS-1$

    suivi.setLibelleErreur(commande.getLibelleErreur());
    active.setSuivi(suivi);
    commande.setDonneesBrut(RavelJsonTools.getInstance().toJson(active, ActionCorrective.class));

    final Retour retour = RetourFactory.createOkRetour();

    final Map<String, String> refFonc = new HashMap<>();
    refFonc.put(IRefFoncConstants.ID_CMD, __idCmd);

    final PEP0229_BL001_Return expected = new PEP0229_BL001_Return(retour, __noCompte, __clientOperateur, null);
    PEP0229_BL001_Return actual = null;

    try
    {
      _contextMock.setState(State.PEP0229_BL001);
      EasyMock.expectLastCall().once();

      final BL1700_AjouterRefFoncBuilder builder = new BL1700_AjouterRefFoncBuilder();
      Whitebox.setInternalState(builder, "_toBuild", _bl1700Mock); //$NON-NLS-1$
      PowerMock.expectNew(BL1700_AjouterRefFoncBuilder.class).andReturn(builder).once();
      _bl1700Mock.setTracabilite(_tracabiliteMock);
      EasyMock.expectLastCall().once();
      _bl1700Mock.setRefFonc(refFonc);
      EasyMock.expectLastCall().once();
      EasyMock.expect(_bl1700Mock.getTracabilite()).andReturn(_tracabiliteMock).once();
      EasyMock.expect(_bl1700Mock.getRefFonc()).andReturn(refFonc).once();
      EasyMock.expect(_bl1700Mock.execute(EasyMock.anyObject(PEP0229_CommandeActionCorrective.class))).andReturn(null).once();

      EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdMock).once();
      EasyMock.expect(_cmdMock.commandeLireUn(_tracabiliteMock, __idCmd)).andReturn(new ConnectorResponse<>(retour, commande)).once();

      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_instance, "PEP0229_BL001_VerifierDonnees", _tracabiliteMock, __idCmd); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse("Check no RavelException call", _exception); //$NON-NLS-1$

      assertNotNull("Check expected assignment", actual); //$NON-NLS-1$
      assertEquals("Check equality between expected and actual objects", expected, actual); //$NON-NLS-1$
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.prof.processes.PE0229.PEP0229_CommandeActionCorrective#PEP0229_BL001_VerifierDonnees}.
   * <b>Entrées:</b> RST connector is generated an exception<br/>
   * <b>Attendu:</b> KO <br/>
   *
   * @throws Throwable
   *           On errors On errors
   */
  @Test
  public void testPEP0229_BL001_VerifierDonnees_006() throws Throwable
  {

    ActionServiceTechnique ast = new ActionServiceTechniqueMail(TypeAction.MODIFICATION.name(), Statut.ACTIF.name(), DateTimeManager.getInstance().now());
    ast.setIdSt("idSt1"); //$NON-NLS-1$
    List<ActionServiceTechnique> stList = Arrays.asList(ast);

    final ActionCorrective ac = new ActionCorrective(__clientOperateur, __noCompte);
    ac.setActionsServicesTechniques(stList);

    final Commande commande = new Commande();
    commande.setIdCmd(__idCmd);
    commande.setNoCompte(__noCompte);
    commande.setClientOperateur(__clientOperateur);
    commande.setStatut(com.bytel.spirit.common.shared.saab.cmd.Statut.ACQUITTE.name());

    IRavelJson instance = new RavelJsonBuilder() //
        .profil("STARK") //$NON-NLS-1$
        .build();
    final IRavelJsonAdapter<ActionCorrective> adapter = instance.adapter(ActionCorrective.class);
    String donneebrut = adapter.toJson(ac);
    commande.setDonneesBrut(donneebrut);

    final Map<String, String> refFonc = new HashMap<>();
    refFonc.put(IRefFoncConstants.ID_CMD, __idCmd);

    final String message = __podam.manufacturePojo(String.class);
    final RavelException expected = new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.CNCTOR_00010, message);

    try
    {
      _contextMock.setState(State.PEP0229_BL001);
      EasyMock.expectLastCall().once();

      final BL1700_AjouterRefFoncBuilder builder = new BL1700_AjouterRefFoncBuilder();
      Whitebox.setInternalState(builder, "_toBuild", _bl1700Mock); //$NON-NLS-1$
      PowerMock.expectNew(BL1700_AjouterRefFoncBuilder.class).andReturn(builder).once();
      _bl1700Mock.setTracabilite(_tracabiliteMock);
      EasyMock.expectLastCall().once();
      _bl1700Mock.setRefFonc(refFonc);
      EasyMock.expectLastCall().once();
      EasyMock.expect(_bl1700Mock.getTracabilite()).andReturn(_tracabiliteMock).once();
      EasyMock.expect(_bl1700Mock.getRefFonc()).andReturn(refFonc).once();
      EasyMock.expect(_bl1700Mock.execute(EasyMock.anyObject(PEP0229_CommandeActionCorrective.class))).andReturn(null).once();

      EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdMock).once();
      EasyMock.expect(_cmdMock.commandeLireUn(_tracabiliteMock, __idCmd)).andReturn(new ConnectorResponse<>(RetourFactory.createOkRetour(), commande)).once();

      EasyMock.expect(RSTProxy.getInstance()).andReturn(_rstMock).once();
      EasyMock.expect(_rstMock.serviceTechniqueLireTousParPfi(_tracabiliteMock, __clientOperateur, __noCompte, null, null)).andThrow(new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.CNCTOR_00010, message)).once();

      PowerMock.replayAll();

      Whitebox.invokeMethod(_instance, "PEP0229_BL001_VerifierDonnees", _tracabiliteMock, __idCmd); //$NON-NLS-1$
    }
    catch (final RavelException actual)
    {
      _exception = true;

      assertEquals("Check RavelException._functionalResponse", expected.getFunctionalError(), actual.getFunctionalError()); //$NON-NLS-1$
      assertEquals("Check RavelException._exType", expected.getExceptionType(), actual.getExceptionType()); //$NON-NLS-1$
      assertEquals("Check RavelException._errorCode", expected.getErrorCode(), actual.getErrorCode()); //$NON-NLS-1$
      assertEquals("Check RavelException._sourceComponentName", expected.getSourceComponentName(), actual.getSourceComponentName()); //$NON-NLS-1$
      assertEquals("Check RavelException._detailMessage", expected.getMessage(), actual.getMessage()); //$NON-NLS-1$
    }
    finally
    {
      PowerMock.verifyAll();

      assertTrue("Check good RavelException call", _exception); //$NON-NLS-1$
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.prof.processes.PE0229.PEP0229_CommandeActionCorrective#PEP0229_BL001_VerifierDonnees}.
   * <b>Entrées:</b> RST connector do not fetch an existing idST<br/>
   * <b>Attendu:</b> KO <br/>
   *
   * @throws Throwable
   *           On errors On errors
   */
  @Test
  public void testPEP0229_BL001_VerifierDonnees_007() throws Throwable
  {

    ActionServiceTechnique ast = new ActionServiceTechniqueMail(TypeAction.MODIFICATION.name(), Statut.ACTIF.name(), DateTimeManager.getInstance().now());
    ast.setIdSt(__idSt);
    List<ActionServiceTechnique> stList = Arrays.asList(ast);

    final ActionCorrective ac = new ActionCorrective(__clientOperateur, __noCompte);
    ac.setActionsServicesTechniques(stList);

    final Commande commande = new Commande();
    commande.setIdCmd(__idCmd);
    commande.setNoCompte(__noCompte);
    commande.setClientOperateur(__clientOperateur);
    commande.setStatut(com.bytel.spirit.common.shared.saab.cmd.Statut.ACQUITTE.name());

    IRavelJson instance = new RavelJsonBuilder() //
        .profil("STARK") //$NON-NLS-1$
        .build();
    final IRavelJsonAdapter<ActionCorrective> adapter = instance.adapter(ActionCorrective.class);
    String donneebrut = adapter.toJson(ac);
    commande.setDonneesBrut(donneebrut);

    final Retour retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.DONNEE_INVALIDE, MessageFormat.format(Messages.getString("PE0229.BL001.ActionDeprecated"), __idSt)); //$NON-NLS-1$

    final Map<String, String> refFonc = new HashMap<>();
    refFonc.put(IRefFoncConstants.ID_CMD, __idCmd);

    final PEP0229_BL001_Return expected = new PEP0229_BL001_Return(retour, null, null, null);
    expected.setStatusCmd(com.bytel.spirit.common.shared.saab.cmd.Statut.TRAITE_NOK);
    PEP0229_BL001_Return actual = null;

    List<com.bytel.spirit.common.shared.saab.rst.ServiceTechnique> listSt = new ArrayList<>();
    StPfsMail st = new StPfsMail("test", null, null, null, null, null); //$NON-NLS-1$
    st.setDateModification(LocalDateTime.now().truncatedTo(ChronoUnit.HOURS));
    listSt.add(st);

    try
    {
      _contextMock.setState(State.PEP0229_BL001);
      EasyMock.expectLastCall().once();

      final BL1700_AjouterRefFoncBuilder builder = new BL1700_AjouterRefFoncBuilder();
      Whitebox.setInternalState(builder, "_toBuild", _bl1700Mock); //$NON-NLS-1$
      PowerMock.expectNew(BL1700_AjouterRefFoncBuilder.class).andReturn(builder).once();
      _bl1700Mock.setTracabilite(_tracabiliteMock);
      EasyMock.expectLastCall().once();
      _bl1700Mock.setRefFonc(refFonc);
      EasyMock.expectLastCall().once();
      EasyMock.expect(_bl1700Mock.getTracabilite()).andReturn(_tracabiliteMock).once();
      EasyMock.expect(_bl1700Mock.getRefFonc()).andReturn(refFonc).once();
      EasyMock.expect(_bl1700Mock.execute(EasyMock.anyObject(PEP0229_CommandeActionCorrective.class))).andReturn(null).once();

      EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdMock).once();
      EasyMock.expect(_cmdMock.commandeLireUn(_tracabiliteMock, __idCmd)).andReturn(new ConnectorResponse<>(RetourFactory.createOkRetour(), commande)).once();

      EasyMock.expect(RSTProxy.getInstance()).andReturn(_rstMock).once();
      EasyMock.expect(_rstMock.serviceTechniqueLireTousParPfi(_tracabiliteMock, __clientOperateur, __noCompte, null, null)).andReturn(new ConnectorResponse<>(RetourFactory.createOkRetour(), listSt)).once();

      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_instance, "PEP0229_BL001_VerifierDonnees", _tracabiliteMock, __idCmd); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse("Check no RavelException call", _exception); //$NON-NLS-1$

      assertNotNull("Check expected assignment", actual); //$NON-NLS-1$
      assertEquals(expected.getClientOperateur(), actual.getClientOperateur());
      assertEquals(expected.getNoCompte(), actual.getNoCompte());
      assertEquals(expected.getStatusCmd(), actual.getStatusCmd());
      assertEquals(expected.getActionCorrective(), actual.getActionCorrective());
      assertEquals(expected.getRetour(), actual.getRetour());
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.prof.processes.PE0229.PEP0229_CommandeActionCorrective#PEP0229_BL001_VerifierDonnees}.
   * <b>Entrées:</b> RST connector fetch an existing idST but not in the past<br/>
   * <b>Attendu:</b> KO <br/>
   *
   * @throws Throwable
   *           On errors On errors
   */
  @Test
  public void testPEP0229_BL001_VerifierDonnees_008() throws Throwable
  {
    ActionServiceTechnique ast = new ActionServiceTechniqueMail(TypeAction.MODIFICATION.name(), Statut.ACTIF.name(), DateTimeManager.getInstance().now());
    ast.setIdSt(__idSt);
    List<ActionServiceTechnique> stList = Arrays.asList(ast);

    final ActionCorrective ac = new ActionCorrective(__clientOperateur, __noCompte);
    ac.setActionsServicesTechniques(stList);

    final Commande commande = new Commande();
    commande.setIdCmd(__idCmd);
    commande.setNoCompte(__noCompte);
    commande.setClientOperateur(__clientOperateur);
    commande.setStatut(com.bytel.spirit.common.shared.saab.cmd.Statut.ACQUITTE.name());

    IRavelJson instance = new RavelJsonBuilder() //
        .profil("STARK") //$NON-NLS-1$
        .build();
    final IRavelJsonAdapter<ActionCorrective> adapter = instance.adapter(ActionCorrective.class);
    String donneebrut = adapter.toJson(ac);
    commande.setDonneesBrut(donneebrut);

    final Retour retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.DONNEE_INVALIDE, MessageFormat.format(Messages.getString("PE0229.BL001.ActionDeprecated"), __idSt)); //$NON-NLS-1$

    final Map<String, String> refFonc = new HashMap<>();
    refFonc.put(IRefFoncConstants.ID_CMD, __idCmd);

    final PEP0229_BL001_Return expected = new PEP0229_BL001_Return(retour, null, null, null);
    expected.setStatusCmd(com.bytel.spirit.common.shared.saab.cmd.Statut.TRAITE_NOK);
    PEP0229_BL001_Return actual = null;

    List<com.bytel.spirit.common.shared.saab.rst.ServiceTechnique> listSt = new ArrayList<>();
    StPfsMail st = new StPfsMail(__idSt, null, null, null, null, null);
    st.setDateModification(LocalDateTime.now().truncatedTo(ChronoUnit.HOURS).plusDays(1));
    listSt.add(st);

    try
    {
      _contextMock.setState(State.PEP0229_BL001);
      EasyMock.expectLastCall().once();

      final BL1700_AjouterRefFoncBuilder builder = new BL1700_AjouterRefFoncBuilder();
      Whitebox.setInternalState(builder, "_toBuild", _bl1700Mock); //$NON-NLS-1$
      PowerMock.expectNew(BL1700_AjouterRefFoncBuilder.class).andReturn(builder).once();
      _bl1700Mock.setTracabilite(_tracabiliteMock);
      EasyMock.expectLastCall().once();
      _bl1700Mock.setRefFonc(refFonc);
      EasyMock.expectLastCall().once();
      EasyMock.expect(_bl1700Mock.getTracabilite()).andReturn(_tracabiliteMock).once();
      EasyMock.expect(_bl1700Mock.getRefFonc()).andReturn(refFonc).once();
      EasyMock.expect(_bl1700Mock.execute(EasyMock.anyObject(PEP0229_CommandeActionCorrective.class))).andReturn(null).once();

      EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdMock).once();
      EasyMock.expect(_cmdMock.commandeLireUn(_tracabiliteMock, __idCmd)).andReturn(new ConnectorResponse<>(RetourFactory.createOkRetour(), commande)).once();

      EasyMock.expect(RSTProxy.getInstance()).andReturn(_rstMock).once();
      EasyMock.expect(_rstMock.serviceTechniqueLireTousParPfi(_tracabiliteMock, __clientOperateur, __noCompte, null, null)).andReturn(new ConnectorResponse<>(RetourFactory.createOkRetour(), listSt)).once();

      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_instance, "PEP0229_BL001_VerifierDonnees", _tracabiliteMock, __idCmd); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse("Check no RavelException call", _exception); //$NON-NLS-1$

      assertNotNull("Check expected assignment", actual); //$NON-NLS-1$
      assertEquals(expected.getClientOperateur(), actual.getClientOperateur());
      assertEquals(expected.getNoCompte(), actual.getNoCompte());
      assertEquals(expected.getStatusCmd(), actual.getStatusCmd());
      assertEquals(expected.getActionCorrective(), actual.getActionCorrective());
      assertEquals(expected.getRetour(), actual.getRetour());
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.prof.processes.PE0229.PEP0229_CommandeActionCorrective#PEP0229_BL001_VerifierDonnees}.
   * <b>Entrées:</b> RST connector fetch an existing idST but in the past<br/>
   * <b>Attendu:</b> OK <br/>
   *
   * @throws Throwable
   *           On errors On errors
   */
  @Test
  public void testPEP0229_BL001_VerifierDonnees_009() throws Throwable
  {
    ActionServiceTechnique ast = new ActionServiceTechniqueMail(TypeAction.MODIFICATION.name(), Statut.ACTIF.name(), DateTimeManager.getInstance().now());
    ast.setIdSt(__idSt);
    List<ActionServiceTechnique> stList = Arrays.asList(ast);

    final ActionCorrective ac = new ActionCorrective(__clientOperateur, __noCompte);
    ac.setActionsServicesTechniques(stList);

    final Commande commande = new Commande();
    commande.setIdCmd(__idCmd);
    commande.setNoCompte(__noCompte);
    commande.setClientOperateur(__clientOperateur);
    commande.setStatut(com.bytel.spirit.common.shared.saab.cmd.Statut.ACQUITTE.name());
    IRavelJson instance = new RavelJsonBuilder() //
        .profil("STARK") //$NON-NLS-1$
        .build();
    final IRavelJsonAdapter<ActionCorrective> adapter = instance.adapter(ActionCorrective.class);
    String donneebrut = adapter.toJson(ac);
    commande.setDonneesBrut(donneebrut);

    final Retour retour = RetourFactory.createOkRetour();

    final Map<String, String> refFonc = new HashMap<>();
    refFonc.put(IRefFoncConstants.ID_CMD, __idCmd);

    final PEP0229_BL001_Return expected = new PEP0229_BL001_Return(retour, __noCompte, __clientOperateur, ac);
    expected.setActionCorrective(ac);
    PEP0229_BL001_Return actual = null;

    List<com.bytel.spirit.common.shared.saab.rst.ServiceTechnique> listSt = new ArrayList<>();
    StPfsMail st = new StPfsMail(__idSt, null, null, null, null, null);
    st.setDateModification(DateTimeManager.getInstance().now().truncatedTo(ChronoUnit.HOURS).minusDays(1));
    listSt.add(st);
    try
    {
      _contextMock.setState(State.PEP0229_BL001);
      EasyMock.expectLastCall().once();

      final BL1700_AjouterRefFoncBuilder builder = new BL1700_AjouterRefFoncBuilder();
      Whitebox.setInternalState(builder, "_toBuild", _bl1700Mock); //$NON-NLS-1$
      PowerMock.expectNew(BL1700_AjouterRefFoncBuilder.class).andReturn(builder).once();
      _bl1700Mock.setTracabilite(_tracabiliteMock);
      EasyMock.expectLastCall().once();
      _bl1700Mock.setRefFonc(refFonc);
      EasyMock.expectLastCall().once();
      EasyMock.expect(_bl1700Mock.getTracabilite()).andReturn(_tracabiliteMock).once();
      EasyMock.expect(_bl1700Mock.getRefFonc()).andReturn(refFonc).once();
      EasyMock.expect(_bl1700Mock.execute(EasyMock.anyObject(PEP0229_CommandeActionCorrective.class))).andReturn(null).once();

      EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdMock).once();
      EasyMock.expect(_cmdMock.commandeLireUn(_tracabiliteMock, __idCmd)).andReturn(new ConnectorResponse<>(RetourFactory.createOkRetour(), commande)).once();

      EasyMock.expect(RSTProxy.getInstance()).andReturn(_rstMock).once();
      EasyMock.expect(_rstMock.serviceTechniqueLireTousParPfi(_tracabiliteMock, __clientOperateur, __noCompte, null, null)).andReturn(new ConnectorResponse<>(retour, listSt)).once();

      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_instance, "PEP0229_BL001_VerifierDonnees", _tracabiliteMock, __idCmd); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse("Check no RavelException call", _exception); //$NON-NLS-1$

      assertNotNull("Check expected assignment", actual); //$NON-NLS-1$
      assertEquals(expected.getClientOperateur(), actual.getClientOperateur());
      assertEquals(expected.getNoCompte(), actual.getNoCompte());
      assertEquals(expected.getStatusCmd(), actual.getStatusCmd());
      assertEquals(expected.getActionCorrective(), actual.getActionCorrective());
      assertEquals(expected.getRetour(), actual.getRetour());
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.prof.processes.PE0229.PEP0229_CommandeActionCorrective#PEP0229_BL002_FormaterReponse}.
   * <b>Entrées:</b> KO Retour is passed as input<br/>
   * <b>Attendu:</b> OK <br/>
   *
   * @throws Throwable
   *           On errors On errors
   */
  @Test
  public void testPEP0229_BL002_FormaterReponse_001() throws Throwable
  {
    final Retour retour = RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.ERREUR_INTERNE, null);

    final PEP0229_BL002_Return expected = new PEP0229_BL002_Return(retour);
    PEP0229_BL002_Return actual = null;

    try
    {
      _contextMock.setState(State.PEP0229_BL002);
      EasyMock.expectLastCall().once();

      _contextMock.setState(State.PEP0229_BL005);
      EasyMock.expectLastCall().once();

      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_instance, "PEP0229_BL002_FormaterReponse", _tracabiliteMock, retour, null, __noCompte, __clientOperateur); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse("Check no RavelException call", _exception); //$NON-NLS-1$

      assertNotNull("Check expected assignment", actual); //$NON-NLS-1$
      assertEquals("Check equality between expected and actual objects", expected, actual); //$NON-NLS-1$
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.prof.processes.PE0229.PEP0229_CommandeActionCorrective#PEP0229_BL002_FormaterReponse}.
   * <b>Entrées:</b> OK Retour is passed as input but status is null<br/>
   * <b>Attendu:</b> OK <br/>
   *
   * @throws Throwable
   *           On errors On errors
   */
  @Test
  public void testPEP0229_BL002_FormaterReponse_002() throws Throwable
  {
    final Retour retour = RetourFactory.createOkRetour();

    final PEP0229_BL002_Return expected = new PEP0229_BL002_Return(retour);
    PEP0229_BL002_Return actual = null;

    try
    {
      _contextMock.setState(State.PEP0229_BL002);
      EasyMock.expectLastCall().once();

      _contextMock.setState(State.PEP0229_BL005);
      EasyMock.expectLastCall().once();

      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_instance, "PEP0229_BL002_FormaterReponse", _tracabiliteMock, retour, null, __noCompte, __clientOperateur); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse("Check no RavelException call", _exception); //$NON-NLS-1$

      assertNotNull("Check expected assignment", actual); //$NON-NLS-1$
      assertEquals("Check equality between expected and actual objects", expected, actual); //$NON-NLS-1$
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.prof.processes.PE0229.PEP0229_CommandeActionCorrective#PEP0229_BL002_FormaterReponse}.
   * <b>Entrées:</b> OK Retour is passed as input and status is EN_COURS<br/>
   * <b>Attendu:</b> OK <br/>
   *
   * @throws Throwable
   *           On errors On errors
   */
  @Test
  public void testPEP0229_BL002_FormaterReponse_003() throws Throwable
  {
    final Retour retour = RetourFactory.createOkRetour();

    final PEP0229_BL002_Return expected = new PEP0229_BL002_Return(retour);
    expected.setReponseFonctionnelle(new ReponseFonctionnelle(__clientOperateur, __noCompte));
    PEP0229_BL002_Return actual = null;

    try
    {
      _contextMock.setState(State.PEP0229_BL002);
      EasyMock.expectLastCall().once();

      _contextMock.setState(State.PEP0229_BL005);
      EasyMock.expectLastCall().once();

      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_instance, "PEP0229_BL002_FormaterReponse", _tracabiliteMock, retour, com.bytel.spirit.common.shared.saab.cmd.Statut.EN_COURS, __noCompte, __clientOperateur); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse("Check no RavelException call", _exception); //$NON-NLS-1$

      assertNotNull("Check expected assignment", actual); //$NON-NLS-1$
      assertEquals("Check equality between expected and actual objects", expected, actual); //$NON-NLS-1$
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.prof.processes.PE0229.PEP0229_CommandeActionCorrective#PEP0229_BL005_GererErreurPROSPER}.
   * <b>Entrées:</b> <br/>
   * <b>Attendu:</b> OK <br/>
   *
   * @throws Throwable
   *           On errors On errors
   */
  @Test
  public void testPEP0229_BL005_GererErreurPROSPER_001() throws Throwable
  {
    final Retour expected = RetourFactory.createOkRetour();
    Retour actual = null;

    try
    {
      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_instance, "PEP0229_BL005_GererErreurPROSPER", _tracabiliteMock, RetourFactory.createOkRetour()); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse("Check no RavelException call", _exception); //$NON-NLS-1$

      assertNotNull("Check expected assignment", actual); //$NON-NLS-1$
      assertEquals("Check equality between expected and actual objects", expected, actual); //$NON-NLS-1$
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.prof.processes.PE0229.PEP0229_CommandeActionCorrective#PEP0229_BL005_GererErreurPROSPER}.
   * <b>Entrées:</b> <br/>
   * <b>Attendu:</b> KO <br/>
   *
   * @throws Throwable
   *           On errors On errors
   */
  @Test
  public void testPEP0229_BL005_GererErreurPROSPER_002() throws Throwable
  {
    final Retour expected = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, "Connector REXConnector is unknown.");
    Retour actual = null;

    try
    {
      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_instance, "PEP0229_BL005_GererErreurPROSPER", _tracabiliteMock, RetourFactory.createKO(IMegConsts.CAT6, IMegSpiritConsts.MISE_A_JOUR_PARTIELLE, null)); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse("Check no RavelException call", _exception); //$NON-NLS-1$

      assertNotNull("Check expected assignment", actual); //$NON-NLS-1$
      assertEquals("Check equality between expected and actual objects", expected, actual); //$NON-NLS-1$
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.prof.processes.PE0229.PEP0229_CommandeActionCorrective#PEP0229_BL100_AppliquerActionCorrective}
   * . <b>Entrées:</b> No technical's services<br/>
   * <b>Attendu:</b> OK <br/>
   *
   * @throws Throwable
   *           On errors On errors
   */
  @Test
  public void testPEP0229_BL100_AppliquerActionCorrective_001() throws Throwable
  {
    final Retour expectedRetour = RetourFactory.createKO(null, null, null);
    Retour actual = null;

    final ActionCorrective ac = new ActionCorrective(__clientOperateur, __noCompte);
    ac.setActionsServicesTechniques(new ArrayList<ActionServiceTechnique>());

    try
    {
      _contextMock.setState(State.PEP0229_BL100);
      _contextMock.setState(State.PEP0229_BL101);

      final BL800_ObtenirSequenceBuilder builder = new BL800_ObtenirSequenceBuilder();
      Whitebox.setInternalState(builder, "_toBuild", _bl800Mock); //$NON-NLS-1$
      PowerMock.expectNew(BL800_ObtenirSequenceBuilder.class).andReturn(builder).once();
      _bl800Mock.setTracabilite(_tracabiliteMock);
      EasyMock.expectLastCall().once();
      _bl800Mock.setCode(UniqueIdConstant.ID_MODIFICATION_TECHNIQUE);
      EasyMock.expectLastCall().once();
      EasyMock.expect(_bl800Mock.getTracabilite()).andReturn(_tracabiliteMock).once();
      EasyMock.expect(_bl800Mock.getCode()).andReturn(UniqueIdConstant.ID_MODIFICATION_TECHNIQUE).once();
      EasyMock.expect(_bl800Mock.execute(EasyMock.anyObject(PEP0229_CommandeActionCorrective.class))).andReturn(__idModComm).once();
      EasyMock.expect(_bl800Mock.getRetour()).andReturn(expectedRetour);

      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_instance, "PEP0229_BL100_AppliquerActionCorrective", _tracabiliteMock, ac, __idCmd); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse("Check no RavelException call", _exception); //$NON-NLS-1$

      assertNotNull("Check expected assignment", actual); //$NON-NLS-1$
      assertEquals("Check equality between expected and actual objects", expectedRetour, actual); //$NON-NLS-1$
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.prof.processes.PE0229.PEP0229_CommandeActionCorrective#PEP0229_BL100_AppliquerActionCorrective}
   * . <b>Entrées:</b> PAs de PFS/MAIL<br/>
   * <b>Attendu:</b> OK <br/>
   *
   * @throws Throwable
   *           On errors On errors
   */
  @Test
  public void testPEP0229_BL100_AppliquerActionCorrective_002() throws Throwable
  {
    final Retour expectedRetour = RetourFactory.createKO(IMegConsts.CAT6, IMegSpiritConsts.MISE_A_JOUR_PARTIELLE, null);
    Retour actual = null;

    ModificationTechnique modTechnique = new ModificationTechnique();
    modTechnique.setIdModificationTechnique(__idModComm);
    modTechnique.setIdCmd(__idCmd);
    modTechnique.setIdSt(null);

    final ActionCorrective ac = new ActionCorrective(__clientOperateur, __noCompte);
    ActionServiceTechnique ast = new ActionServiceTechniqueMail(TypeAction.MODIFICATION.name(), Statut.ACTIF.name(), DateTimeManager.getInstance().now());
    ast.setIdSt(__idSt);
    ac.setActionsServicesTechniques(Arrays.asList(ast));

    try
    {
      _contextMock.setState(State.PEP0229_BL100);
      _contextMock.setState(State.PEP0229_BL101);

      final BL800_ObtenirSequenceBuilder builder = new BL800_ObtenirSequenceBuilder();
      Whitebox.setInternalState(builder, "_toBuild", _bl800Mock); //$NON-NLS-1$
      PowerMock.expectNew(BL800_ObtenirSequenceBuilder.class).andReturn(builder).once();
      _bl800Mock.setTracabilite(_tracabiliteMock);
      EasyMock.expectLastCall().once();
      _bl800Mock.setCode(UniqueIdConstant.ID_MODIFICATION_TECHNIQUE);
      EasyMock.expectLastCall().once();
      EasyMock.expect(_bl800Mock.getTracabilite()).andReturn(_tracabiliteMock).once();
      EasyMock.expect(_bl800Mock.getCode()).andReturn(UniqueIdConstant.ID_MODIFICATION_TECHNIQUE).once();
      EasyMock.expect(_bl800Mock.execute(EasyMock.anyObject(PEP0229_CommandeActionCorrective.class))).andReturn(__idModComm).once();
      EasyMock.expect(_bl800Mock.getRetour()).andReturn(RetourFactory.createOkRetour());

      EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdMock).once();
      EasyMock.expect(_cmdMock.modificationTechniqueCreerListe(EasyMock.anyObject(), EasyMock.anyObject())).andReturn(new ConnectorResponse<>(RetourFactory.createKO(null, null, null), null)).once();

      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_instance, "PEP0229_BL100_AppliquerActionCorrective", _tracabiliteMock, ac, __idCmd); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse("Check no RavelException call", _exception); //$NON-NLS-1$

      assertNotNull("Check expected assignment", actual); //$NON-NLS-1$
      assertEquals("Check equality between expected and actual objects", expectedRetour, actual); //$NON-NLS-1$
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.prof.processes.PE0229.PEP0229_CommandeActionCorrective#PEP0229_BL100_AppliquerActionCorrective}
   * . <b>Entrées:</b> Pas de PFS/MAIL<br/>
   * <b>Attendu:</b> OK <br/>
   *
   * @throws Throwable
   *           On errors On errors
   */
  @Test
  public void testPEP0229_BL100_AppliquerActionCorrective_003() throws Throwable
  {
    final Retour expectedRetour = RetourFactory.createKO(IMegConsts.CAT6, IMegSpiritConsts.MISE_A_JOUR_PARTIELLE, null);
    Retour actual = null;
    ModificationTechnique modTechnique = new ModificationTechnique();
    modTechnique.setIdCmd(__idCmd);
    modTechnique.setIdSt(__idSt);
    modTechnique.setStatut(ModificationTechniqueStatut.EN_COURS.name());

    ActionServiceTechniqueMail ast = new ActionServiceTechniqueMail(TypeAction.MODIFICATION.name(), Statut.ACTIF.name(), DateTimeManager.getInstance().now());
    ast.setIdSt(__idSt);
    DonneesProvisionneesSTPfsMail donneesProvMail = new DonneesProvisionneesSTPfsMail("adresseMail", 10, 10, "niveauRestriction");
    ast.setDonneesProvisionneesStPfsMail(donneesProvMail);
    List<ActionServiceTechnique> stList = Arrays.asList(ast);

    final ActionCorrective ac = new ActionCorrective(__clientOperateur, __noCompte);
    ac.setActionsServicesTechniques(stList);

    try
    {
      _contextMock.setState(State.PEP0229_BL100);
      EasyMock.expect(RSTProxy.getInstance()).andReturn(_rstMock).once();
      ConnectorResponse<Retour, Nothing> connectorRep = new ConnectorResponse<Retour, Nothing>(RetourFactory.createKO(null, null, null), null);
      EasyMock.expect(_rstMock.stPfsModifierStatutActif(_tracabiliteMock, ast.getIdSt(), ast.getDonneesProvisionnees())).andReturn(connectorRep);
      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_instance, "PEP0229_BL100_AppliquerActionCorrective", _tracabiliteMock, ac, __idCmd); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse("Check no RavelException call", _exception); //$NON-NLS-1$

      assertNotNull("Check expected assignment", actual); //$NON-NLS-1$
      assertEquals("Check equality between expected and actual objects", expectedRetour, actual); //$NON-NLS-1$
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.prof.processes.PE0229.PEP0229_CommandeActionCorrective#PEP0229_BL100_AppliquerActionCorrective}
   * . <b>Entrées:</b> RST connector is generated an exception<br/>
   * <b>Attendu:</b> KO <br/>
   *
   * @throws Throwable
   *           On errors On errors
   */
  @Test
  public void testPEP0229_BL100_AppliquerActionCorrective_004() throws Throwable
  {
    final Retour expectedRetour = RetourFactory.createKO(IMegConsts.CAT6, IMegSpiritConsts.MISE_A_JOUR_PARTIELLE, null);
    Retour actual = null;
    ModificationTechnique modTechnique = new ModificationTechnique();
    modTechnique.setIdCmd(__idCmd);
    modTechnique.setIdSt(__idSt);
    modTechnique.setStatut(ModificationTechniqueStatut.EN_COURS.name());

    ActionServiceTechnique actionSt = new ActionServiceTechniqueMail(TypeAction.MODIFICATION.name(), Statut.ACTIF.name(), DateTimeManager.getInstance().now());
    actionSt.setIdSt(__idSt);
    List<ActionServiceTechnique> stList = Arrays.asList(actionSt);

    final ActionCorrective ac = new ActionCorrective(__clientOperateur, __noCompte);
    ac.setActionsServicesTechniques(stList);

    UpdateServiceTechniqueRequest updateServiceTechniqueRequest = new UpdateServiceTechniqueRequest(actionSt.getIdSt(), actionSt.getTypeServiceTechnique(), actionSt.getStatut());
    updateServiceTechniqueRequest.setCommentaire(actionSt.getCommentaire());

    try
    {
      _contextMock.setState(State.PEP0229_BL100);

      _contextMock.setState(State.PEP0229_BL101);

      final BL800_ObtenirSequenceBuilder builder = new BL800_ObtenirSequenceBuilder();
      Whitebox.setInternalState(builder, "_toBuild", _bl800Mock); //$NON-NLS-1$
      PowerMock.expectNew(BL800_ObtenirSequenceBuilder.class).andReturn(builder).once();
      _bl800Mock.setTracabilite(_tracabiliteMock);
      EasyMock.expectLastCall().once();
      _bl800Mock.setCode(UniqueIdConstant.ID_MODIFICATION_TECHNIQUE);
      EasyMock.expectLastCall().once();
      EasyMock.expect(_bl800Mock.getTracabilite()).andReturn(_tracabiliteMock).once();
      EasyMock.expect(_bl800Mock.getCode()).andReturn(UniqueIdConstant.ID_MODIFICATION_TECHNIQUE).once();
      EasyMock.expect(_bl800Mock.execute(EasyMock.anyObject(PEP0229_CommandeActionCorrective.class))).andReturn(__idModComm).once();
      EasyMock.expect(_bl800Mock.getRetour()).andReturn(expectedRetour);

      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_instance, "PEP0229_BL100_AppliquerActionCorrective", _tracabiliteMock, ac, __idCmd); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse("Check no RavelException call", _exception); //$NON-NLS-1$

      assertNotNull("Check expected assignment", actual); //$NON-NLS-1$
      assertEquals("Check equality between expected and actual objects", expectedRetour, actual); //$NON-NLS-1$
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.prof.processes.PE0229.PEP0229_CommandeActionCorrective#PEP0229_BL100_AppliquerActionCorrective}
   * . <b>Entrées:</b> <br/>
   * <b>Attendu:</b> OK <br/>
   *
   * @throws Throwable
   *           On errors On errors
   */
  @Test
  public void testPEP0229_BL100_AppliquerActionCorrective_005() throws Throwable
  {
    Retour actual = null;

    ActionServiceTechnique actionSt = new ActionServiceTechniqueMail(TypeAction.MODIFICATION.name(), Statut.ACTIF.name(), DateTimeManager.getInstance().now());
    actionSt.setIdSt(__idSt);
    List<ActionServiceTechnique> stList = Arrays.asList(actionSt);

    final ActionCorrective ac = new ActionCorrective(__clientOperateur, __noCompte);
    ac.setActionsServicesTechniques(stList);

    UpdateServiceTechniqueRequest updateServiceTechniqueRequest = new UpdateServiceTechniqueRequest(actionSt.getIdSt(), actionSt.getTypeServiceTechnique(), actionSt.getStatut());
    updateServiceTechniqueRequest.setCommentaire(actionSt.getCommentaire());

    ModificationTechnique modTechnique = new ModificationTechnique();
    modTechnique.setIdModificationTechnique(__idModComm);
    modTechnique.setIdCmd(__idCmd);
    modTechnique.setIdSt(actionSt.getIdSt());
    List<ModificationTechnique> listModificationTechnique = new ArrayList<>();
    listModificationTechnique.add(modTechnique);
    CreateModificationTechniqueRequest createModificationTechniqueRequest = new CreateModificationTechniqueRequest(__idCmd, listModificationTechnique);

    try
    {
      _contextMock.setState(State.PEP0229_BL100);

      _contextMock.setState(State.PEP0229_BL101);

      final BL800_ObtenirSequenceBuilder builder = new BL800_ObtenirSequenceBuilder();
      Whitebox.setInternalState(builder, "_toBuild", _bl800Mock); //$NON-NLS-1$
      PowerMock.expectNew(BL800_ObtenirSequenceBuilder.class).andReturn(builder).once();
      _bl800Mock.setTracabilite(_tracabiliteMock);
      EasyMock.expectLastCall().once();
      _bl800Mock.setCode(UniqueIdConstant.ID_MODIFICATION_TECHNIQUE);
      EasyMock.expectLastCall().once();
      EasyMock.expect(_bl800Mock.getTracabilite()).andReturn(_tracabiliteMock).once();
      EasyMock.expect(_bl800Mock.getCode()).andReturn(UniqueIdConstant.ID_MODIFICATION_TECHNIQUE).once();
      EasyMock.expect(_bl800Mock.execute(EasyMock.anyObject(PEP0229_CommandeActionCorrective.class))).andReturn(__idModComm).once();
      EasyMock.expect(_bl800Mock.getRetour()).andReturn(RetourFactory.createOkRetour());

      EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdMock).once();
      EasyMock.expect(_cmdMock.modificationTechniqueCreerListe(EasyMock.anyObject(), EasyMock.anyObject())).andReturn(new ConnectorResponse<>(RetourFactory.createOkRetour(), null)).once();

      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_instance, "PEP0229_BL100_AppliquerActionCorrective", _tracabiliteMock, ac, __idCmd); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse("Check no RavelException call", _exception); //$NON-NLS-1$

      assertNotNull("Check expected assignment", actual); //$NON-NLS-1$
      assertEquals("Check equality between expected and actual objects", RetourFactory.createOkRetour(), actual); //$NON-NLS-1$
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.prof.processes.PE0229.PEP0229_CommandeActionCorrective#PEP0229_BL101_CreerModificationTechnique}
   * . <b>Entrées:</b> BL800 is generated an exception<br/>
   * <b>Attendu:</b> KO <br/>
   *
   * @throws Throwable
   *           On errors On errors
   */
  @Test
  public void testPEP0229_BL101_CreerModificationTechnique_001() throws Throwable
  {
    final String message = __podam.manufacturePojo(String.class);
    final RavelException expected = new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.CNCTOR_00010, message);

    try
    {

      _contextMock.setState(State.PEP0229_BL101);
      EasyMock.expectLastCall().once();

      final BL800_ObtenirSequenceBuilder builder = new BL800_ObtenirSequenceBuilder();
      Whitebox.setInternalState(builder, "_toBuild", _bl800Mock); //$NON-NLS-1$
      PowerMock.expectNew(BL800_ObtenirSequenceBuilder.class).andReturn(builder).once();
      _bl800Mock.setTracabilite(_tracabiliteMock);
      EasyMock.expectLastCall().once();
      _bl800Mock.setCode(UniqueIdConstant.ID_MODIFICATION_TECHNIQUE);
      EasyMock.expectLastCall().once();
      EasyMock.expect(_bl800Mock.getTracabilite()).andReturn(_tracabiliteMock).once();
      EasyMock.expect(_bl800Mock.getCode()).andReturn(UniqueIdConstant.ID_MODIFICATION_TECHNIQUE).once();
      EasyMock.expect(_bl800Mock.execute(EasyMock.anyObject(PEP0229_CommandeActionCorrective.class))).andThrow(new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.CNCTOR_00010, message)).once();

      PowerMock.replayAll();

      Whitebox.invokeMethod(_instance, "PEP0229_BL101_CreerModificationTechnique", _tracabiliteMock, __idCmd, ""); //$NON-NLS-1$ //$NON-NLS-2$
    }
    catch (final RavelException actual)
    {
      _exception = true;

      assertEquals("Check RavelException._functionalResponse", expected.getFunctionalError(), actual.getFunctionalError()); //$NON-NLS-1$
      assertEquals("Check RavelException._exType", expected.getExceptionType(), actual.getExceptionType()); //$NON-NLS-1$
      assertEquals("Check RavelException._errorCode", expected.getErrorCode(), actual.getErrorCode()); //$NON-NLS-1$
      assertEquals("Check RavelException._sourceComponentName", expected.getSourceComponentName(), actual.getSourceComponentName()); //$NON-NLS-1$
      assertEquals("Check RavelException._detailMessage", expected.getMessage(), actual.getMessage()); //$NON-NLS-1$
    }
    finally
    {
      PowerMock.verifyAll();

      assertTrue("Check good RavelException call", _exception); //$NON-NLS-1$
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.prof.processes.PE0229.PEP0229_CommandeActionCorrective#PEP0229_BL101_CreerModificationTechnique}
   * . <b>Entrées:</b> BL800 return an error<br/>
   * <b>Attendu:</b> KO <br/>
   *
   * @throws Throwable
   *           On errors On errors
   */
  @Test
  public void testPEP0229_BL101_CreerModificationTechnique_002() throws Throwable
  {

    final Retour expectedRetour = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, "Activity parameter not filled."); //$NON-NLS-1$
    PEP0229_BL101_Return actual = null;
    String idServiceTechnique = "idServiceTechnique"; //$NON-NLS-1$
    PEP0229_BL101_Return expected = new PEP0229_BL101_Return(expectedRetour, null);

    try
    {

      _contextMock.setState(State.PEP0229_BL101);
      EasyMock.expectLastCall().once();

      final BL800_ObtenirSequenceBuilder builder = new BL800_ObtenirSequenceBuilder();
      Whitebox.setInternalState(builder, "_toBuild", _bl800Mock); //$NON-NLS-1$
      PowerMock.expectNew(BL800_ObtenirSequenceBuilder.class).andReturn(builder).once();
      _bl800Mock.setTracabilite(_tracabiliteMock);
      EasyMock.expectLastCall().once();
      _bl800Mock.setCode(UniqueIdConstant.ID_MODIFICATION_TECHNIQUE);
      EasyMock.expectLastCall().once();
      EasyMock.expect(_bl800Mock.getTracabilite()).andReturn(_tracabiliteMock).once();
      EasyMock.expect(_bl800Mock.getCode()).andReturn(UniqueIdConstant.ID_MODIFICATION_TECHNIQUE).once();
      EasyMock.expect(_bl800Mock.execute(EasyMock.anyObject(PEP0229_CommandeActionCorrective.class))).andReturn(__idModComm).once();
      EasyMock.expect(_bl800Mock.getRetour()).andReturn(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, "Activity parameter not filled.")); //$NON-NLS-1$

      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_instance, "PEP0229_BL101_CreerModificationTechnique", _tracabiliteMock, __idCmd, idServiceTechnique); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse("Check no RavelException call", _exception); //$NON-NLS-1$

      assertNotNull("Check expected assignment", actual); //$NON-NLS-1$
      assertEquals("Check equality between expected and actual objects", expected, actual); //$NON-NLS-1$
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.prof.processes.PE0229.PEP0229_CommandeActionCorrective#PEP0229_BL101_CreerModificationTechnique}
   * . <b>Entrées:</b> .<br/>
   * <b>Attendu:</b> OK <br/>
   *
   * @throws Throwable
   *           On errors On errors
   */
  @Test
  public void testPEP0229_BL101_CreerModificationTechnique_003() throws Throwable
  {
    final Retour expectedRetour = RetourFactory.createOkRetour();
    PEP0229_BL101_Return actual = null;
    String idServiceTechnique = "idServiceTechnique"; //$NON-NLS-1$
    ModificationTechnique modTechnique = new ModificationTechnique();
    String idModificationTechnique = "idModificationTechnique"; //$NON-NLS-1$
    modTechnique.setIdModificationTechnique(idModificationTechnique);
    modTechnique.setIdCmd(__idCmd);
    modTechnique.setIdSt(idServiceTechnique);
    PEP0229_BL101_Return expected = new PEP0229_BL101_Return(expectedRetour, modTechnique);

    try
    {

      _contextMock.setState(State.PEP0229_BL101);
      EasyMock.expectLastCall().once();

      final BL800_ObtenirSequenceBuilder builder = new BL800_ObtenirSequenceBuilder();
      Whitebox.setInternalState(builder, "_toBuild", _bl800Mock); //$NON-NLS-1$
      PowerMock.expectNew(BL800_ObtenirSequenceBuilder.class).andReturn(builder).once();
      _bl800Mock.setTracabilite(_tracabiliteMock);
      EasyMock.expectLastCall().once();
      _bl800Mock.setCode(UniqueIdConstant.ID_MODIFICATION_TECHNIQUE);
      EasyMock.expectLastCall().once();
      EasyMock.expect(_bl800Mock.getTracabilite()).andReturn(_tracabiliteMock).once();
      EasyMock.expect(_bl800Mock.getCode()).andReturn(UniqueIdConstant.ID_MODIFICATION_TECHNIQUE).once();
      EasyMock.expect(_bl800Mock.execute(EasyMock.anyObject(PEP0229_CommandeActionCorrective.class))).andReturn(idModificationTechnique).once();
      EasyMock.expect(_bl800Mock.getRetour()).andReturn(expectedRetour);

      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_instance, "PEP0229_BL101_CreerModificationTechnique", _tracabiliteMock, __idCmd, idServiceTechnique); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse("Check no RavelException call", _exception); //$NON-NLS-1$

      assertNotNull("Check expected assignment", actual); //$NON-NLS-1$
      assertEquals("Check equality between expected and actual objects", expected, actual); //$NON-NLS-1$
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.prof.processes.PE0229.PEP0229_CommandeActionCorrective#PEP0229_BL400_ModifierStatutCmd}.
   * <b>Entrées:</b> retour_p is mandatory<br/>
   * <b>Attendu:</b> <br/>
   *
   * @throws Throwable
   *           On errors On errors
   */
  @Test(expected = NullPointerException.class)
  public void testPEP0229_BL400_ModifierStatutCmd_001() throws Throwable
  {
    Retour actual = null;

    try
    {

      _contextMock.setState(State.PEP0229_BL400);
      EasyMock.expectLastCall().once();

      EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdMock).once();

      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_instance, "PEP0229_BL400_ModifierStatutCmd", _tracabiliteMock, __idCmd, com.bytel.spirit.common.shared.saab.cmd.Statut.TRAITE_NOK, null); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse("Check no RavelException call", _exception); //$NON-NLS-1$

      assertNull("Check no assignment", actual); //$NON-NLS-1$
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.prof.processes.PE0229.PEP0229_CommandeActionCorrective#PEP0229_BL400_ModifierStatutCmd}.
   * <b>Entrées:</b> CMD connector is generated an exception<br/>
   * <b>Attendu:</b> KO <br/>
   *
   * @throws Throwable
   *           On errors On errors
   */
  @Test
  public void testPEP0229_BL400_ModifierStatutCmd_002() throws Throwable
  {
    final String message = __podam.manufacturePojo(String.class);
    final RavelException expected = new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.CNCTOR_00010, message);

    try
    {

      _contextMock.setState(State.PEP0229_BL400);
      EasyMock.expectLastCall().once();

      EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdMock).once();
      EasyMock.expect(_cmdMock.commandeModifierStatut(_tracabiliteMock, __idCmd, com.bytel.spirit.common.shared.saab.cmd.Statut.TRAITE_NOK.name(), IMegConsts.CAT1, null)).andThrow(new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.CNCTOR_00010, message)).once();

      PowerMock.replayAll();

      Whitebox.invokeMethod(_instance, "PEP0229_BL400_ModifierStatutCmd", _tracabiliteMock, __idCmd, com.bytel.spirit.common.shared.saab.cmd.Statut.TRAITE_NOK, RetourFactory.createNOK(IMegConsts.CAT1, null, null)); //$NON-NLS-1$
    }
    catch (final RavelException actual)
    {
      _exception = true;

      assertEquals("Check RavelException._functionalResponse", expected.getFunctionalError(), actual.getFunctionalError()); //$NON-NLS-1$
      assertEquals("Check RavelException._exType", expected.getExceptionType(), actual.getExceptionType()); //$NON-NLS-1$
      assertEquals("Check RavelException._errorCode", expected.getErrorCode(), actual.getErrorCode()); //$NON-NLS-1$
      assertEquals("Check RavelException._sourceComponentName", expected.getSourceComponentName(), actual.getSourceComponentName()); //$NON-NLS-1$
      assertEquals("Check RavelException._detailMessage", expected.getMessage(), actual.getMessage()); //$NON-NLS-1$
    }
    finally
    {
      PowerMock.verifyAll();

      assertTrue("Check good RavelException call", _exception); //$NON-NLS-1$
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.prof.processes.PE0229.PEP0229_CommandeActionCorrective#PEP0229_BL400_ModifierStatutCmd}.
   * <b>Entrées:</b> <br/>
   * <b>Attendu:</b> OK <br/>
   *
   * @throws Throwable
   *           On errors On errors
   */
  @Test
  public void testPEP0229_BL400_ModifierStatutCmd_003() throws Throwable
  {
    final Retour expected = RetourFactory.createOkRetour();
    Retour actual = null;

    try
    {

      _contextMock.setState(State.PEP0229_BL400);
      EasyMock.expectLastCall().once();

      EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdMock).once();
      EasyMock.expect(_cmdMock.commandeModifierStatut(_tracabiliteMock, __idCmd, com.bytel.spirit.common.shared.saab.cmd.Statut.TRAITE_NOK.name(), IMegConsts.CAT1, null)).andReturn(new ConnectorResponse<>(RetourFactory.createOkRetour(), null)).once();

      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_instance, "PEP0229_BL400_ModifierStatutCmd", _tracabiliteMock, __idCmd, com.bytel.spirit.common.shared.saab.cmd.Statut.TRAITE_NOK, RetourFactory.createNOK(IMegConsts.CAT1, null, null)); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse("Check no RavelException call", _exception); //$NON-NLS-1$

      assertNotNull("Check expected assignment", actual); //$NON-NLS-1$
      assertEquals("Check equality between expected and actual objects", expected, actual); //$NON-NLS-1$
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.prof.processes.PE0229.PEP0229_CommandeActionCorrective#PEP0229_BL400_ModifierStatutCmd}.
   * <b>Entrées:</b> CMD connector is generated an exception<br/>
   * <b>Attendu:</b> KO <br/>
   *
   * @throws Throwable
   *           On errors On errors
   */
  @Test
  public void testPEP0229_BL400_ModifierStatutCmd_004() throws Throwable
  {
    final String message = __podam.manufacturePojo(String.class);
    final RavelException expected = new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.CNCTOR_00010, message);

    try
    {

      _contextMock.setState(State.PEP0229_BL400);
      EasyMock.expectLastCall().once();

      EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdMock).once();
      EasyMock.expect(_cmdMock.commandeModifierStatut(_tracabiliteMock, __idCmd, com.bytel.spirit.common.shared.saab.cmd.Statut.TRAITE_OK.name(), StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING)).andThrow(new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.CNCTOR_00010, message)).once();
      PowerMock.replayAll();

      Whitebox.invokeMethod(_instance, "PEP0229_BL400_ModifierStatutCmd", _tracabiliteMock, __idCmd, com.bytel.spirit.common.shared.saab.cmd.Statut.TRAITE_OK, RetourFactory.createOkRetour()); //$NON-NLS-1$
    }
    catch (final RavelException actual)
    {
      _exception = true;

      assertEquals("Check RavelException._functionalResponse", expected.getFunctionalError(), actual.getFunctionalError()); //$NON-NLS-1$
      assertEquals("Check RavelException._exType", expected.getExceptionType(), actual.getExceptionType()); //$NON-NLS-1$
      assertEquals("Check RavelException._errorCode", expected.getErrorCode(), actual.getErrorCode()); //$NON-NLS-1$
      assertEquals("Check RavelException._sourceComponentName", expected.getSourceComponentName(), actual.getSourceComponentName()); //$NON-NLS-1$
      assertEquals("Check RavelException._detailMessage", expected.getMessage(), actual.getMessage()); //$NON-NLS-1$
    }
    finally
    {
      PowerMock.verifyAll();

      assertTrue("Check good RavelException call", _exception); //$NON-NLS-1$
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.prof.processes.PE0229.PEP0229_CommandeActionCorrective#PEP0229_BL400_ModifierStatutCmd}.
   * <b>Entrées:</b> <br/>
   * <b>Attendu:</b> OK <br/>
   *
   * @throws Throwable
   *           On errors On errors
   */
  @Test
  public void testPEP0229_BL400_ModifierStatutCmd_005() throws Throwable
  {
    final Retour expected = RetourFactory.createOkRetour();
    Retour actual = null;

    try
    {

      _contextMock.setState(State.PEP0229_BL400);
      EasyMock.expectLastCall().once();

      EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdMock).once();
      EasyMock.expect(_cmdMock.commandeModifierStatut(_tracabiliteMock, __idCmd, com.bytel.spirit.common.shared.saab.cmd.Statut.EN_COURS.name(), StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING)).andReturn(new ConnectorResponse<>(RetourFactory.createOkRetour(), null)).once();

      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_instance, "PEP0229_BL400_ModifierStatutCmd", _tracabiliteMock, __idCmd, com.bytel.spirit.common.shared.saab.cmd.Statut.EN_COURS, RetourFactory.createOkRetour()); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse("Check no RavelException call", _exception); //$NON-NLS-1$

      assertNotNull("Check expected assignment", actual); //$NON-NLS-1$
      assertEquals("Check equality between expected and actual objects", expected, actual); //$NON-NLS-1$
    }
  }

  /**
   * Test method for CreateDefaultFunctionalResponse
   *
   * <b>Entrées:</b> retour_p is mandatory<br/>
   * <b>Attendu:</b> <br/>
   *
   * @throws Throwable
   *           On errors On errors
   */
  @Test
  public void testPEP0229_CreateDefaultFunctionalResponse_001() throws Throwable
  {
    String actual = null;
    Retour retour1 = RetourFactory.createOkRetour();

    PowerMock.replayAll();

    actual = Whitebox.invokeMethod(_instance, "createDefaultFunctionalResponse", retour1); //$NON-NLS-1$

    PowerMock.verifyAll();

    assertEquals(null, actual, StringConstants.EMPTY_STRING);

  }

  /**
   * Test method for {@link com.bytel.spirit.prof.processes.PE0229.PEP0229_CommandeActionCorrective#startProcess}.
   * <b>Entrées:</b> BL001 return a KO/TRAITE_NOK<br/>
   * <b>Attendu:</b> KO <br/>
   *
   * @throws Throwable
   *           On errors On errors
   */
  @Test
  public void testStartProcess_001() throws Throwable
  {
    final Retour expected = RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.ERREUR_INTERNE, null);
    Retour actual = null;

    final Retour retour1 = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.DONNEE_INVALIDE, null);
    final Retour retour2 = RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.ERREUR_INTERNE, null);

    try
    {
      _instance = PowerMock.createPartialMock(PEP0229_CommandeActionCorrective.class, "PEP0229_BL001_VerifierDonnees", "PEP0229_BL002_FormaterReponse", "PEP0229_BL400_ModifierStatutCmd"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
      Whitebox.setInternalState(_instance, "_processContext", _contextMock); //$NON-NLS-1$
      Whitebox.setInternalState(_instance, "_tracabilite", _tracabiliteMock); //$NON-NLS-1$

      final PEP0229_BL001_Return bl001 = new PEP0229_BL001_Return(retour1, null, null, null);
      bl001.setStatusCmd(com.bytel.spirit.common.shared.saab.cmd.Statut.TRAITE_NOK);
      PowerMock.expectPrivate(_instance, "PEP0229_BL001_VerifierDonnees", _tracabiliteMock, __idCmd).andReturn(bl001).once(); //$NON-NLS-1$
      PowerMock.expectPrivate(_instance, "PEP0229_BL400_ModifierStatutCmd", _tracabiliteMock, __idCmd, com.bytel.spirit.common.shared.saab.cmd.Statut.TRAITE_NOK, retour1).andReturn(retour2).once(); //$NON-NLS-1$

      final PEP0229_BL002_Return bl002 = new PEP0229_BL002_Return(retour2);
      PowerMock.expectPrivate(_instance, "PEP0229_BL002_FormaterReponse", _tracabiliteMock, retour2, com.bytel.spirit.common.shared.saab.cmd.Statut.TRAITE_NOK, null, null).andReturn(bl002).once(); //$NON-NLS-1$

      EasyMock.expect(RavelResponseFactory.getInstance()).andReturn(_ravelResponseFactoryMock);
      EasyMock.expect(_ravelResponseFactoryMock.createResponse()).andReturn(_responseMock);
      _responseMock.setDataType(HttpConstants.CONTENT_TYPE_JSON);
      EasyMock.expectLastCall().andVoid().once();
      _responseMock.setResult("{\"retour\":{\"resultat\":\"NOK\",\"categorie\":\"CAT-1\",\"diagnostic\":\"ERREUR_INTERNE\"}}"); //$NON-NLS-1$

      EasyMock.expect(_responseMock.getResult()).andReturn(StringConstants.OK).once();

      EasyMock.expect(_responseMock.getResult()).andReturn(StringConstants.OK).once();
      EasyMock.expect(_contextMock.getState()).andReturn(State.PEP0229_END).once();

      PowerMock.replayAll();

      Whitebox.invokeMethod(_instance, "startProcess", _requestMock, _tracabiliteMock); //$NON-NLS-1$
      actual = _instance.getRetour();
    }
    catch (final Exception e)
    {
      _exception = true;
    }
    finally
    {

      PowerMock.verifyAll();

      assertFalse("Check no RavelException call", _exception); //$NON-NLS-1$

      assertNotNull("Check expected assignment", actual); //$NON-NLS-1$
      assertEquals("Check equality between expected and actual objects", expected, actual); //$NON-NLS-1$
    }
  }

  /**
   * Test method for {@link com.bytel.spirit.prof.processes.PE0229.PEP0229_CommandeActionCorrective#startProcess}.
   * <b>Entrées:</b> BL001 return a KO/null<br/>
   * <b>Attendu:</b> KO <br/>
   *
   * @throws Throwable
   *           On errors On errors
   */
  @Test
  public void testStartProcess_002() throws Throwable
  {
    final Retour expected = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.DONNEE_INVALIDE, null);
    Retour actual = null;

    final Retour retour1 = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.DONNEE_INVALIDE, null);

    try
    {
      _instance = PowerMock.createPartialMock(PEP0229_CommandeActionCorrective.class, "PEP0229_BL001_VerifierDonnees", "PEP0229_BL002_FormaterReponse"); //$NON-NLS-1$ //$NON-NLS-2$
      Whitebox.setInternalState(_instance, "_processContext", _contextMock); //$NON-NLS-1$
      Whitebox.setInternalState(_instance, "_tracabilite", _tracabiliteMock); //$NON-NLS-1$

      final PEP0229_BL001_Return bl001 = new PEP0229_BL001_Return(retour1, null, null, null);
      bl001.setStatusCmd(com.bytel.spirit.common.shared.saab.cmd.Statut.REJETE);
      PowerMock.expectPrivate(_instance, "PEP0229_BL001_VerifierDonnees", _tracabiliteMock, __idCmd).andReturn(bl001).once(); //$NON-NLS-1$

      final PEP0229_BL002_Return bl002 = new PEP0229_BL002_Return(retour1);
      PowerMock.expectPrivate(_instance, "PEP0229_BL002_FormaterReponse", _tracabiliteMock, retour1, null, null, null).andReturn(bl002).once(); //$NON-NLS-1$

      EasyMock.expect(RavelResponseFactory.getInstance()).andReturn(_ravelResponseFactoryMock);
      EasyMock.expect(_ravelResponseFactoryMock.createResponse()).andReturn(_responseMock).once();
      _responseMock.setDataType(HttpConstants.CONTENT_TYPE_JSON);
      EasyMock.expectLastCall().andVoid().once();
      _responseMock.setResult("{\"retour\":{\"resultat\":\"NOK\",\"categorie\":\"CAT-4\",\"diagnostic\":\"DONNEE_INVALIDE\"}}"); //$NON-NLS-1$

      EasyMock.expect(_responseMock.getResult()).andReturn(StringConstants.OK).once();
      EasyMock.expect(_responseMock.getResult()).andReturn(StringConstants.OK).once();
      EasyMock.expect(_contextMock.getState()).andReturn(State.PEP0229_END).once();
      PowerMock.replayAll();

      Whitebox.invokeMethod(_instance, "startProcess", _requestMock, _tracabiliteMock); //$NON-NLS-1$
      actual = _instance.getRetour();
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse("Check no RavelException call", _exception); //$NON-NLS-1$

      assertNotNull("Check expected assignment", actual); //$NON-NLS-1$
      assertEquals("Check equality between expected and actual objects", expected, actual); //$NON-NLS-1$
    }
  }

  /**
   * Test method for {@link com.bytel.spirit.prof.processes.PE0229.PEP0229_CommandeActionCorrective#startProcess}.
   * <b>Entrées:</b> BL100 return a KO<br/>
   * <b>Attendu:</b> KO <br/>
   *
   * @throws Throwable
   *           On errors On errors
   */
  @Test
  public void testStartProcess_003() throws Throwable
  {
    final Retour expected = RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.ERREUR_INTERNE, null);
    Retour actual = null;

    final Retour retour1 = RetourFactory.createOkRetour();
    final Retour retour2 = RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.ERREUR_INTERNE, null);

    ActionServiceTechnique actionSt = new ActionServiceTechniqueMail(TypeAction.MODIFICATION.name(), Statut.INACTIF.name(), DateTimeManager.getInstance().now());
    actionSt.setIdSt(__idSt);
    List<ActionServiceTechnique> stList = Arrays.asList(actionSt);

    final ActionCorrective ac = new ActionCorrective(__clientOperateur, __noCompte);
    ac.setActionsServicesTechniques(stList);
    try
    {
      _instance = PowerMock.createPartialMock(PEP0229_CommandeActionCorrective.class, "PEP0229_BL001_VerifierDonnees", "PEP0229_BL002_FormaterReponse", "PEP0229_BL100_AppliquerActionCorrective"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
      Whitebox.setInternalState(_instance, "_processContext", _contextMock); //$NON-NLS-1$
      Whitebox.setInternalState(_instance, "_tracabilite", _tracabiliteMock); //$NON-NLS-1$

      final PEP0229_BL001_Return bl001 = new PEP0229_BL001_Return(retour1, __noCompte, __clientOperateur, ac);
      PowerMock.expectPrivate(_instance, "PEP0229_BL001_VerifierDonnees", _tracabiliteMock, __idCmd).andReturn(bl001).once(); //$NON-NLS-1$

      PowerMock.expectPrivate(_instance, "PEP0229_BL100_AppliquerActionCorrective", _tracabiliteMock, ac, __idCmd).andReturn(retour2).once(); //$NON-NLS-1$

      final PEP0229_BL002_Return bl002 = new PEP0229_BL002_Return(retour2);
      PowerMock.expectPrivate(_instance, "PEP0229_BL002_FormaterReponse", _tracabiliteMock, retour2, null, __noCompte, __clientOperateur).andReturn(bl002).once(); //$NON-NLS-1$

      EasyMock.expect(RavelResponseFactory.getInstance()).andReturn(_ravelResponseFactoryMock);
      EasyMock.expect(_ravelResponseFactoryMock.createResponse()).andReturn(_responseMock).once();
      _responseMock.setDataType(HttpConstants.CONTENT_TYPE_JSON);
      EasyMock.expectLastCall().andVoid().once();
      _responseMock.setResult("{\"retour\":{\"resultat\":\"NOK\",\"categorie\":\"CAT-1\",\"diagnostic\":\"ERREUR_INTERNE\"}}"); //$NON-NLS-1$

      EasyMock.expect(_responseMock.getResult()).andReturn(StringConstants.OK).once();
      EasyMock.expect(_responseMock.getResult()).andReturn(StringConstants.OK).once();
      EasyMock.expect(_contextMock.getState()).andReturn(State.PEP0229_END).once();

      PowerMock.replayAll();

      Whitebox.invokeMethod(_instance, "startProcess", _requestMock, _tracabiliteMock); //$NON-NLS-1$
      actual = _instance.getRetour();
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse("Check no RavelException call", _exception); //$NON-NLS-1$

      assertNotNull("Check expected assignment", actual); //$NON-NLS-1$
      assertEquals("Check equality between expected and actual objects", expected, actual); //$NON-NLS-1$
    }
  }

  /**
   * Test method for {@link com.bytel.spirit.prof.processes.PE0229.PEP0229_CommandeActionCorrective#startProcess}.
   * <b>Entrées:</b> BL200 return a KO<br/>
   * <b>Attendu:</b> KO <br/>
   *
   * @throws Throwable
   *           On errors On errors
   */
  @Test
  public void testStartProcess_004() throws Throwable
  {

    final Retour retour1 = RetourFactory.createOkRetour();
    final Retour retour2 = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, null);

    ActionServiceTechnique actionSt = new ActionServiceTechniqueMail(TypeAction.MODIFICATION.name(), Statut.INACTIF.name(), DateTimeManager.getInstance().now());
    actionSt.setIdSt(__idSt);
    List<ActionServiceTechnique> stList = Arrays.asList(actionSt);

    final ActionCorrective ac = new ActionCorrective(__clientOperateur, __noCompte);
    ac.setActionsServicesTechniques(stList);

    try
    {
      _instance = PowerMock.createPartialMock(PEP0229_CommandeActionCorrective.class, "PEP0229_BL001_VerifierDonnees", "PEP0229_BL002_FormaterReponse", "PEP0229_BL100_AppliquerActionCorrective", "PEP0229_BL101_CreerModificationTechnique"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
      Whitebox.setInternalState(_instance, "_processContext", _contextMock); //$NON-NLS-1$
      Whitebox.setInternalState(_instance, "_tracabilite", _tracabiliteMock); //$NON-NLS-1$

      final PEP0229_BL001_Return bl001 = new PEP0229_BL001_Return(retour1, __noCompte, __clientOperateur, ac);
      PowerMock.expectPrivate(_instance, "PEP0229_BL001_VerifierDonnees", _tracabiliteMock, __idCmd).andReturn(bl001).once(); //$NON-NLS-1$

      PowerMock.expectPrivate(_instance, "PEP0229_BL100_AppliquerActionCorrective", _tracabiliteMock, ac, __idCmd).andReturn(retour2).once(); //$NON-NLS-1$

      final PEP0229_BL002_Return bl002 = new PEP0229_BL002_Return(retour2);
      PowerMock.expectPrivate(_instance, "PEP0229_BL002_FormaterReponse", _tracabiliteMock, retour2, null, __noCompte, __clientOperateur).andReturn(bl002).once(); //$NON-NLS-1$

      EasyMock.expect(RavelResponseFactory.getInstance()).andReturn(_ravelResponseFactoryMock);
      EasyMock.expect(_ravelResponseFactoryMock.createResponse()).andReturn(_responseMock).once();
      _responseMock.setDataType(HttpConstants.CONTENT_TYPE_JSON);
      EasyMock.expectLastCall().andVoid().once();
      _responseMock.setResult("{\"retour\":{\"resultat\":\"NOK\",\"categorie\":\"CAT-10\",\"diagnostic\":\"TRAITEMENT_ARRETE\"}}"); //$NON-NLS-1$

      EasyMock.expect(_responseMock.getResult()).andReturn(StringConstants.OK).once();
      EasyMock.expect(_responseMock.getResult()).andReturn(StringConstants.OK).once();
      EasyMock.expect(_contextMock.getState()).andReturn(State.PEP0229_END).once();

      PowerMock.replayAll();

      Whitebox.invokeMethod(_instance, "startProcess", _requestMock, _tracabiliteMock); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse("Check no RavelException call", _exception); //$NON-NLS-1$

    }
  }

  /**
   * Test method for {@link com.bytel.spirit.prof.processes.PE0229.PEP0229_CommandeActionCorrective#startProcess}.
   * <b>Entrées:</b> <br/>
   * <b>Attendu:</b> OK <br/>
   *
   * @throws Throwable
   *           On errors On errors
   */
  @Test
  public void testStartProcess_005() throws Throwable
  {

    final Retour retour1 = RetourFactory.createOkRetour();

    ActionServiceTechnique actionSt = new ActionServiceTechniqueMail(TypeAction.MODIFICATION.name(), Statut.INACTIF.name(), DateTimeManager.getInstance().now());
    actionSt.setIdSt(__idSt);
    List<ActionServiceTechnique> stList = Arrays.asList(actionSt);

    final ActionCorrective ac = new ActionCorrective(__clientOperateur, __noCompte);
    ac.setActionsServicesTechniques(stList);

    ModificationTechnique modTechnique = new ModificationTechnique();
    modTechnique.setIdModificationTechnique(__idModComm);
    modTechnique.setIdCmd(__idCmd);
    modTechnique.setIdSt(__idModComm);
    try
    {
      _instance = PowerMock.createPartialMock(PEP0229_CommandeActionCorrective.class, "PEP0229_BL001_VerifierDonnees", "PEP0229_BL002_FormaterReponse", "PEP0229_BL100_AppliquerActionCorrective", "PEP0229_BL101_CreerModificationTechnique", "PEP0229_BL400_ModifierStatutCmd"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
      Whitebox.setInternalState(_instance, "_processContext", _contextMock); //$NON-NLS-1$
      Whitebox.setInternalState(_instance, "_tracabilite", _tracabiliteMock); //$NON-NLS-1$

      final PEP0229_BL001_Return bl001 = new PEP0229_BL001_Return(retour1, __noCompte, __clientOperateur, ac);
      PowerMock.expectPrivate(_instance, "PEP0229_BL001_VerifierDonnees", _tracabiliteMock, __idCmd).andReturn(bl001).once(); //$NON-NLS-1$

      PowerMock.expectPrivate(_instance, "PEP0229_BL100_AppliquerActionCorrective", _tracabiliteMock, ac, __idCmd).andReturn(retour1).once(); //$NON-NLS-1$

      PowerMock.expectPrivate(_instance, "PEP0229_BL400_ModifierStatutCmd", _tracabiliteMock, __idCmd, com.bytel.spirit.common.shared.saab.cmd.Statut.EN_COURS, retour1).andReturn(retour1).once(); //$NON-NLS-1$

      final PEP0229_BL002_Return bl002 = new PEP0229_BL002_Return(retour1);
      PowerMock.expectPrivate(_instance, "PEP0229_BL002_FormaterReponse", _tracabiliteMock, retour1, com.bytel.spirit.common.shared.saab.cmd.Statut.EN_COURS, __noCompte, __clientOperateur).andReturn(bl002).once(); //$NON-NLS-1$

      EasyMock.expect(RavelResponseFactory.getInstance()).andReturn(_ravelResponseFactoryMock);
      EasyMock.expect(_ravelResponseFactoryMock.createResponse()).andReturn(_responseMock).once();
      _responseMock.setDataType(HttpConstants.CONTENT_TYPE_JSON);
      EasyMock.expectLastCall().andVoid().once();
      _responseMock.setResult("{\"retour\":{\"resultat\":\"OK\"}}"); //$NON-NLS-1$
      EasyMock.expectLastCall().andVoid().once();

      EasyMock.expect(_responseMock.getResult()).andReturn(StringConstants.OK).once();
      EasyMock.expect(_responseMock.getResult()).andReturn(StringConstants.OK).once();
      EasyMock.expect(_contextMock.getState()).andReturn(State.PEP0229_END).once();

      PowerMock.replayAll();

      Whitebox.invokeMethod(_instance, "startProcess", _requestMock, _tracabiliteMock); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse("Check no RavelException call", _exception); //$NON-NLS-1$

    }
  }
}
