/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PE0229.structs;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PowerMockListener;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.testlisteners.FieldDefaulter;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.modules.junit4.PowerMockRunnerDelegate;
import org.powermock.reflect.Whitebox;
import org.springframework.test.context.ContextConfiguration;

import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.test.podam.PodamBytelJUnit4ClassRunner;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.spirit.common.shared.misc.ressources.RetourConverter;
import com.bytel.spirit.prof.processes.PE0229.structs.PEP0229_BL002_Return.ReponseFonctionnelle;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author jjoly
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PowerMockListener(FieldDefaulter.class)
@PowerMockRunnerDelegate(PodamBytelJUnit4ClassRunner.class)
@ContextConfiguration("classpath:BeansProcessTestMocks.xml")
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
@PrepareForTest({ PEP0229_BL002_Return.class })
public final class PEP0229_BL002_ReturnTest
{
  /**
   * bean Factory generation
   */
  private static PodamFactory __podam;

  /**
   *
   */
  private static com.bytel.ravel.types.Retour __retour;

  /**
   *
   */
  private static ReponseFonctionnelle __reponseFonctionnelle;

  /**
   * Initialize before all tests
   *
   * @throws Exception
   *           On errors Exception to be thrown in case of failure
   */
  @BeforeClass
  public static void setUpBeforeClass() throws Exception
  {
    __podam = new PodamFactoryImpl();
    __podam.getStrategy().setMemoization(false);
    __podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());

    __retour = RetourConverter.convertToJsonRetour(RetourFactory.createOkRetour());
    __reponseFonctionnelle = __podam.manufacturePojoWithFullData(ReponseFonctionnelle.class);
  }

  /**
   * Instance to evaluate
   */
  private PEP0229_BL002_Return _instance;

  /**
   * Exception has been thrown
   */
  private boolean _exception;

  /**
   * Initialize before tests
   *
   * @throws Exception
   *           On errors Thrown in case of error during switch in attributes of parent class
   */
  @Before
  public void setUp() throws Exception
  {
    _instance = null;
    _exception = false;

    PowerMock.resetAll();
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.prof.processes.PE0229.structs.PEP0229_BL002_Return#PEP0229_BL002_Return(com.bytel.ravel.common.business.generated.Retour)}.<br/>
   * <b>Entrées:</b>NULL value in input<br/>
   * <b>Attendu:</b>NullPointerException<br/>
   *
   * @throws Exception
   *           On errors
   */
  @Test
  public void testPEP0229_BL002_Return_001() throws Exception
  {
    try
    {
      PowerMock.replayAll();

      _instance = new PEP0229_BL002_Return(null);
    }
    catch (final NullPointerException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertTrue(_exception);

      assertNull(_instance);
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.prof.processes.PE0229.structs.PEP0229_BL002_Return#PEP0229_BL002_Return(com.bytel.ravel.common.business.generated.Retour)}.<br/>
   * <b>Entrées:</b><br/>
   * <b>Attendu:</b><br/>
   *
   * @throws Exception
   *           On errors
   */
  @Test
  public void testPEP0229_BL002_Return_002() throws Exception
  {
    final com.bytel.ravel.types.Retour expected = __retour;
    com.bytel.ravel.types.Retour actual = null;

    try
    {
      PowerMock.replayAll();

      _instance = new PEP0229_BL002_Return(RetourFactory.createOkRetour());
      actual = Whitebox.getInternalState(_instance, "_retour"); //$NON-NLS-1$
    }
    catch (final Exception e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertFalse(_exception);

      assertNotNull(_instance);
      assertEquals(expected, actual);
    }
  }

  /**
   * Test method for {@link com.bytel.spirit.prof.processes.PE0229.structs.PEP0229_BL002_Return#getRetour}.<br/>
   * <b>Entrées:</b><br/>
   * <b>Attendu:</b><br/>
   *
   * @throws Exception
   *           On errors
   */
  @Test
  public void testPEP0229_BL002_Return_003() throws Exception
  {
    final com.bytel.ravel.types.Retour expected = __retour;
    com.bytel.ravel.types.Retour actual = null;

    try
    {
      PowerMock.replayAll();

      _instance = new PEP0229_BL002_Return(RetourFactory.createKO(null, null, null));
      Whitebox.setInternalState(_instance, "_retour", expected); //$NON-NLS-1$
      actual = _instance.getRetour();
    }
    catch (final Exception e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertNotNull(actual);
      assertEquals(expected, actual);
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.prof.processes.PE0229.structs.PEP0229_BL002_Return#getReponseFonctionnelle()}.<br/>
   * <b>Entrées:</b><br/>
   * <b>Attendu:</b><br/>
   *
   * @throws Exception
   *           On errors
   */
  @Test
  public void testPEP0229_BL002_Return_004() throws Exception
  {
    final ReponseFonctionnelle expected = __reponseFonctionnelle;
    ReponseFonctionnelle actual = null;

    try
    {
      PowerMock.replayAll();

      _instance = new PEP0229_BL002_Return(RetourFactory.createKO(null, null, null));
      Whitebox.setInternalState(_instance, "_reponseFonctionnelle", expected); //$NON-NLS-1$
      actual = _instance.getReponseFonctionnelle();
    }
    catch (final Exception e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertNotNull(actual);
      assertEquals(expected, actual);
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.prof.processes.PE0229.structs.PEP0229_BL002_Return#setReponseFonctionnelle(com.bytel.spirit.prof.processes.PE0229.structs.PEP0229_BL002_Return.ReponseFonctionnelle)}.<br/>
   * <b>Entrées:</b><br/>
   * <b>Attendu:</b><br/>
   *
   * @throws Exception
   *           On errors
   */
  @Test
  public void testPEP0229_BL002_Return_005() throws Exception
  {
    final ReponseFonctionnelle expected = __reponseFonctionnelle;
    ReponseFonctionnelle actual = null;

    try
    {
      PowerMock.replayAll();

      _instance = new PEP0229_BL002_Return(RetourFactory.createKO(null, null, null));
      _instance.setReponseFonctionnelle(expected);
      actual = Whitebox.getInternalState(_instance, "_reponseFonctionnelle"); //$NON-NLS-1$
    }
    catch (final Exception e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertNotNull(actual);
      assertEquals(expected, actual);
    }
  }
}
