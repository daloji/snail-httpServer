/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PM028.activity;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;

import org.easymock.EasyMock;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.bouygtel.refcli.consulterpfi.out.ConsulterPFIOut;
import com.bouygtel.refcli.consulterpfi.out.ConsulterPFIReponseType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.utils.ACManagerUtil;
import com.bytel.ravel.common.utils.MarshallTools;
import com.bytel.ravel.common.utils.Pair;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.utils.Test_Consts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.prof.connectors.svccomm.SvcCommMimProxy;
import com.bytel.spirit.prof.processes.PM028.Diagnostic;
import com.bytel.spirit.prof.processes.PM028.PM028ProvisionnerPfi;
import com.bytel.spirit.prof.processes.PM028.activity.PM028BL200CalculerImpact.PM028BL200CalculerImpactBuilder;
import com.bytel.spirit.prof.processes.generated.provisionnerpfi.ActeMetier;
import com.bytel.spirit.prof.processes.generated.provisionnerpfi.DonneesMetier;
import com.bytel.spirit.prof.processes.generated.provisionnerpfi.PIVOTREFERENCE;
import com.bytel.spirit.prof.processes.generated.provisionnerpfi.PartitionSic;
import com.bytel.spirit.prof.processes.generated.provisionnerpfi.PortefeuilleIndividuel;
import com.bytel.spirit.prof.processes.generated.provisionnerpfi.ProvisionnerPfiIn;
import com.bytel.spirit.prof.processes.generated.provisionnerpfi.ServiceAccessible;
import com.bytel.spirit.prof.processes.generated.provisionnerpfi.ServiceAccessibleStatut;
import com.bytel.spirit.prof.processes.generated.provisionnerpfi.ServiceCommercial;
import com.bytel.spirit.prof.processes.generated.provisionnerpfi.St;

/**
 *
 * @author lmerces
 * @version ($Revision$ $Date$)
 */
//Déclaration du runner de test pour lancer les TUs avec le runner PowerMock
@RunWith(PowerMockRunner.class)
//Préparation des classes pour les tests, toutes les classes comportant des méthodes statiques à mocker doivent être présentes dans l'annotation
@PrepareForTest({ SvcCommMimProxy.class })
//To avoid: SecretKeyFactory.getInstance() throws exception for all algorithms in unit tests
@PowerMockIgnore("javax.crypto.*")
public class PM028BL200CalculerImpactTest
{
  /**
   *
   */
  private static final String ACTIVE = "ACTIVE"; //$NON-NLS-1$
  /**
   *
   */
  private static final String INACTIF = "INACTIF"; //$NON-NLS-1$
  /**
   *
   */
  private static final String PFI_REPONSE_FILE = "src/test/resources/ConsulterPFIReponseType.xml"; //$NON-NLS-1$
  /**
   *
   */
  private static final String PFI_REPONSE_FILE_ANO320328 = "src/test/resources/ConsulterPFIReponseTypeANO320328.xml"; //$NON-NLS-1$

  /**
   * Initialization method: Create: - spring context - connectors - service manager
   */
  @BeforeClass
  public static void init()
  {
    ACManagerUtil.resetACManager();
    new ClassPathXmlApplicationContext("classpath:BeansProcessTestMocks.xml"); //$NON-NLS-1$
  }

  /**
  *
  */
  private PM028ProvisionnerPfi _currentInstance;

  /**
   * SvcCommMimConnectorMockHelper
   */
  @MockStrict
  private SvcCommMimProxy _svcCommMimConnector;

  /**
   * Cleans the Connector Mocks responses
   *
   * @throws Exception
   *           On Error
   */
  @Before
  public void beforeTest() throws Exception
  {
    // on réinitialise tous les mocks afin de ne pas avoir d'interférence entre les tests
    PowerMock.resetAll();

    // On initialise toutes les classes à mocker comportant un appel à une méthode statique
    // Dans notre cas on mock statiquemement toutes les classes des activités et des proxys appelés (pour les createContexte et les getInstance)
    PowerMock.mockStaticStrict(SvcCommMimProxy.class);

    // Initialize the context
    _currentInstance = new PM028ProvisionnerPfi();
    _currentInstance.initializeContext();
  }

  /**
   * Test du bypass du calcul d'impact pour forcer la ResynchroSiNpbt.
   *
   * @throws RavelException
   *           throws exception
   */
  @Test
  public void Test_000_Force_ResynchroSiNpbt() throws RavelException
  {
    ConsulterPFIReponseType consulterPFIReponseType = MarshallTools.unmarshall(ConsulterPFIReponseType.class, new File(PFI_REPONSE_FILE));
    ConsulterPFIOut consulterPFIOut = consulterPFIReponseType.getConsulterPFIOut();

    ProvisionnerPfiIn provisionnerPfiIn = buildProvisionnerPfiIn("10054013022", "201512111107xx", Arrays.asList("1470")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PortefeuilleIndividuel pfi = provisionnerPfiIn.getDonneesMetier().getPortefeuilleIndividuels().get(0);

    Tracabilite tracabilite = new Tracabilite(StringConstants.EMPTY_STRING, Test_Consts.DEFAULT_MSGID, "PROF", "nomPRocessus", "idProcessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PM028BL200CalculerImpact calculerImpact = new PM028BL200CalculerImpactBuilder().tracabilite(tracabilite).pfi(pfi).consulterPFIOut(consulterPFIOut).provisionnerPfiIn(provisionnerPfiIn).forceResynchroSiNpbt(true).build();
    ProvisionnerPfiIn result = calculerImpact.execute(_currentInstance);

    Assert.assertEquals(StringConstants.OK, calculerImpact.getRetour().getResultat());
    Assert.assertEquals(Diagnostic.RESYNCHRO_SI_NPBT.toString(), calculerImpact.getRetour().getDiagnostic());
    Assert.assertNull(calculerImpact.getRetour().getLibelle());
    Assert.assertEquals(provisionnerPfiIn, result);
  }

  /**
   * La date de dernier impact de la demande est différente de celle de la consultation PFI. La calcul d'impact sort en
   * ResynchroSiNpbt
   *
   * @throws RavelException
   *           throws exception
   */
  @Test
  public void Test_001_ResynchroSiNpbt_Dates_DernierImpact_differentes() throws RavelException
  {
    ConsulterPFIReponseType consulterPFIReponseType = MarshallTools.unmarshall(ConsulterPFIReponseType.class, new File(PFI_REPONSE_FILE));
    ConsulterPFIOut consulterPFIOut = consulterPFIReponseType.getConsulterPFIOut();

    ProvisionnerPfiIn provisionnerPfiIn = buildProvisionnerPfiIn("10054013022", "201512111107xx", Arrays.asList("1470")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PortefeuilleIndividuel pfi = provisionnerPfiIn.getDonneesMetier().getPortefeuilleIndividuels().get(0);

    Tracabilite tracabilite = new Tracabilite(StringConstants.EMPTY_STRING, Test_Consts.DEFAULT_MSGID, "PROF", "nomPRocessus", "idProcessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    PM028BL200CalculerImpact calculerImpact = new PM028BL200CalculerImpactBuilder().tracabilite(tracabilite).pfi(pfi).consulterPFIOut(consulterPFIOut).provisionnerPfiIn(provisionnerPfiIn).forceResynchroSiNpbt(false).build();
    ProvisionnerPfiIn result = calculerImpact.execute(_currentInstance);

    Assert.assertEquals(StringConstants.OK, calculerImpact.getRetour().getResultat());
    Assert.assertEquals(Diagnostic.RESYNCHRO_SI_NPBT.toString(), calculerImpact.getRetour().getDiagnostic());
    Assert.assertNull(calculerImpact.getRetour().getLibelle());
    Assert.assertEquals(provisionnerPfiIn, result);
  }

  /**
   * Incohérence entre les services présents dans la demande et les services présents dans le résultat du ConsulterPFI.
   * La calcul d'impact sort en ResynchroSiNpbt.
   *
   * @throws RavelException
   *           throws exception
   */
  @Test
  public void Test_002_ResynchroSiNpbt_Services_incoherents() throws RavelException
  {
    String dateDernierImpact = "20151211110709"; //$NON-NLS-1$
    String noCompte = "10054013022"; //$NON-NLS-1$
    ConsulterPFIReponseType consulterPFIReponseType = MarshallTools.unmarshall(ConsulterPFIReponseType.class, new File(PFI_REPONSE_FILE));
    ConsulterPFIOut consulterPFIOut = consulterPFIReponseType.getConsulterPFIOut();

    //le SA 1470 n'existe pas dans le résultat du ConsulterPFI
    ProvisionnerPfiIn provisionnerPfiIn = buildProvisionnerPfiIn(noCompte, dateDernierImpact, Arrays.asList("1470")); //$NON-NLS-1$
    PortefeuilleIndividuel pfi = provisionnerPfiIn.getDonneesMetier().getPortefeuilleIndividuels().get(0);

    Tracabilite tracabilite = new Tracabilite(StringConstants.EMPTY_STRING, Test_Consts.DEFAULT_MSGID, "PROF", "nomPRocessus", "idProcessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    PM028BL200CalculerImpact calculerImpact = new PM028BL200CalculerImpactBuilder().tracabilite(tracabilite).pfi(pfi).consulterPFIOut(consulterPFIOut).provisionnerPfiIn(provisionnerPfiIn).forceResynchroSiNpbt(false).build();
    ProvisionnerPfiIn result = calculerImpact.execute(_currentInstance);

    Assert.assertEquals(StringConstants.OK, calculerImpact.getRetour().getResultat());
    Assert.assertEquals(Diagnostic.RESYNCHRO_SI_NPBT.toString(), calculerImpact.getRetour().getDiagnostic());
    Assert.assertNull(calculerImpact.getRetour().getLibelle());
    Assert.assertEquals(provisionnerPfiIn, result);
  }

  /**
   * Ajout des SC du ConsulterPFI qui étaient inhibés par un SC inactivé dans la demande (Traitement 2). Dans ce test,
   * le service 63/ACTIVE de ConsulterPFI est inhibé par le service 1089/INACTIF de la demade. Le service 63/ACTIVE est
   * alors rajouté dans la demande. La calcul d'impact sort en ProvisionnerServices.
   *
   * @throws RavelException
   *           throws exception
   */
  @Test
  public void Test_003_ProvisionnerServices() throws RavelException
  {
    String dateDernierImpact = "20151211110709"; //$NON-NLS-1$
    String noCompte = "10054013022"; //$NON-NLS-1$
    ConsulterPFIReponseType consulterPFIReponseType = MarshallTools.unmarshall(ConsulterPFIReponseType.class, new File(PFI_REPONSE_FILE));
    ConsulterPFIOut consulterPFIOut = consulterPFIReponseType.getConsulterPFIOut();

    ProvisionnerPfiIn provisionnerPfiIn = buildProvisionnerPfiIn(noCompte, dateDernierImpact, Arrays.asList("1089/INACTIF", "107")); //$NON-NLS-1$ //$NON-NLS-2$
    PortefeuilleIndividuel pfi = provisionnerPfiIn.getDonneesMetier().getPortefeuilleIndividuels().get(0);

    //Prepare mock
    EasyMock.expect(SvcCommMimProxy.getInstance()).andReturn(_svcCommMimConnector);
    EasyMock.expectLastCall().anyTimes();

    //Traitement 2: ajout du service 63/ACTIVE dans la demande
    EasyMock.expect(_svcCommMimConnector.testInhibiton(Test_Consts.DEFAULT_MSGID, "107", "1089")).andReturn(new ConnectorResponse<Boolean, Integer>(false, null)); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_svcCommMimConnector.testInhibiton(Test_Consts.DEFAULT_MSGID, "6", "1089")).andReturn(new ConnectorResponse<Boolean, Integer>(false, null)); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_svcCommMimConnector.testInhibiton(Test_Consts.DEFAULT_MSGID, "63", "1089")).andReturn(new ConnectorResponse<Boolean, Integer>(true, null)); //$NON-NLS-1$ //$NON-NLS-2$

    //Traitement 3: Aucun prerequis pour les services active/suspendu de consulterPFIOut pour que le traitement 3 ne fasse rien !
    EasyMock.expect(_svcCommMimConnector.getPreRequis(Test_Consts.DEFAULT_MSGID, "107")).andReturn(new ConnectorResponse<String, Boolean>(null, false)); //$NON-NLS-1$
    EasyMock.expect(_svcCommMimConnector.getPreRequis(Test_Consts.DEFAULT_MSGID, "6")).andReturn(new ConnectorResponse<String, Boolean>(null, false)); //$NON-NLS-1$
    EasyMock.expect(_svcCommMimConnector.getPreRequis(Test_Consts.DEFAULT_MSGID, "63")).andReturn(new ConnectorResponse<String, Boolean>(null, false)); //$NON-NLS-1$

    //Traitement 4: Aucun service ACTIVE/SUSPENDU/INACTIF de la demande inhibé par un service ACTIVE/SUSPENDU de consulterPFIOut pour ne pas inhiber un service dans la demande
    EasyMock.expect(_svcCommMimConnector.testInhibiton(Test_Consts.DEFAULT_MSGID, "1089", "107")).andReturn(new ConnectorResponse<Boolean, Integer>(false, null)); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_svcCommMimConnector.testInhibiton(Test_Consts.DEFAULT_MSGID, "1089", "6")).andReturn(new ConnectorResponse<Boolean, Integer>(false, null)); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_svcCommMimConnector.testInhibiton(Test_Consts.DEFAULT_MSGID, "1089", "63")).andReturn(new ConnectorResponse<Boolean, Integer>(false, null)); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_svcCommMimConnector.testInhibiton(Test_Consts.DEFAULT_MSGID, "107", "6")).andReturn(new ConnectorResponse<Boolean, Integer>(false, null)); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_svcCommMimConnector.testInhibiton(Test_Consts.DEFAULT_MSGID, "107", "63")).andReturn(new ConnectorResponse<Boolean, Integer>(false, null)); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_svcCommMimConnector.testInhibiton(Test_Consts.DEFAULT_MSGID, "63", "107")).andReturn(new ConnectorResponse<Boolean, Integer>(false, null)); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_svcCommMimConnector.testInhibiton(Test_Consts.DEFAULT_MSGID, "63", "6")).andReturn(new ConnectorResponse<Boolean, Integer>(false, null)); //$NON-NLS-1$ //$NON-NLS-2$

    //Traitement 5: aucun prerequis pour ne pas inhiber les SC actifs ou suspendus de la demande de service pour lesquels un SC prérequis manque
    EasyMock.expect(_svcCommMimConnector.getPreRequis(Test_Consts.DEFAULT_MSGID, "1089")).andReturn(new ConnectorResponse<String, Boolean>(null, false)); //$NON-NLS-1$
    EasyMock.expect(_svcCommMimConnector.getPreRequis(Test_Consts.DEFAULT_MSGID, "107")).andReturn(new ConnectorResponse<String, Boolean>(null, false)); //$NON-NLS-1$
    EasyMock.expect(_svcCommMimConnector.getPreRequis(Test_Consts.DEFAULT_MSGID, "63")).andReturn(new ConnectorResponse<String, Boolean>(null, false)); //$NON-NLS-1$

    //Vérifie les services de la demande avant le calcul d'impact
    int i = 0;
    Assert.assertEquals(2, pfi.getServiceAccessibles().size());
    //1er service
    String psNoSc = ((ServiceCommercial) (((ServiceAccessible) pfi.getServiceAccessibles().get(i).getIdref()).getServiceCommercial().getIdref())).getNoServiceCommercial();
    Assert.assertEquals("1089", psNoSc); //$NON-NLS-1$
    String psSaStatut = ((ServiceAccessible) pfi.getServiceAccessibles().get(i++).getIdref()).getStatut().toString();
    Assert.assertEquals(INACTIF, psSaStatut);

    //2ieme service
    psNoSc = ((ServiceCommercial) (((ServiceAccessible) pfi.getServiceAccessibles().get(i).getIdref()).getServiceCommercial().getIdref())).getNoServiceCommercial();
    Assert.assertEquals("107", psNoSc); //$NON-NLS-1$
    psSaStatut = ((ServiceAccessible) pfi.getServiceAccessibles().get(i++).getIdref()).getStatut().toString();
    Assert.assertEquals(ACTIVE, psSaStatut);

    // On enregistre le scénario des appels
    PowerMock.replayAll();

    //lance le calcul d'impact
    Tracabilite tracabilite = new Tracabilite(StringConstants.EMPTY_STRING, Test_Consts.DEFAULT_MSGID, "PROF", "nomPRocessus", "idProcessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    PM028BL200CalculerImpact calculerImpact = new PM028BL200CalculerImpactBuilder().tracabilite(tracabilite).pfi(pfi).consulterPFIOut(consulterPFIOut).provisionnerPfiIn(provisionnerPfiIn).forceResynchroSiNpbt(false).build();
    ProvisionnerPfiIn result = calculerImpact.execute(_currentInstance);

    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.OK, calculerImpact.getRetour().getResultat());
    Assert.assertEquals(Diagnostic.PROVISIONNER_SERVICES.toString(), calculerImpact.getRetour().getDiagnostic());
    Assert.assertNull(calculerImpact.getRetour().getLibelle());
    Assert.assertEquals(3, result.getDonneesMetier().getPortefeuilleIndividuels().get(0).getServiceAccessibles().size());

    //Vérifie les services de la demande
    i = 0;
    //1er service
    psNoSc = ((ServiceCommercial) (((ServiceAccessible) pfi.getServiceAccessibles().get(i).getIdref()).getServiceCommercial().getIdref())).getNoServiceCommercial();
    Assert.assertEquals("1089", psNoSc); //$NON-NLS-1$
    psSaStatut = ((ServiceAccessible) pfi.getServiceAccessibles().get(i++).getIdref()).getStatut().toString();
    Assert.assertEquals(INACTIF, psSaStatut);

    //2ieme service
    psNoSc = ((ServiceCommercial) (((ServiceAccessible) pfi.getServiceAccessibles().get(i).getIdref()).getServiceCommercial().getIdref())).getNoServiceCommercial();
    Assert.assertEquals("107", psNoSc); //$NON-NLS-1$
    psSaStatut = ((ServiceAccessible) pfi.getServiceAccessibles().get(i++).getIdref()).getStatut().toString();
    Assert.assertEquals(ACTIVE, psSaStatut);

    psNoSc = ((ServiceCommercial) (((ServiceAccessible) pfi.getServiceAccessibles().get(i).getIdref()).getServiceCommercial().getIdref())).getNoServiceCommercial();
    Assert.assertEquals("63", psNoSc); //$NON-NLS-1$
    psSaStatut = ((ServiceAccessible) pfi.getServiceAccessibles().get(i++).getIdref()).getStatut().toString();
    Assert.assertEquals(ACTIVE, psSaStatut);

  }

  /**
   * Ajout des SC qui sont désinhibés par un SC activé dans la demande (Traitement 3). La calcul d'impact sort en
   * ProvisionnerPfi.
   *
   * @throws RavelException
   *           throws exception
   */
  @Test
  public void Test_004_ProvisionnerPfi() throws RavelException
  {
    String dateDernierImpact = "20151211110709"; //$NON-NLS-1$
    String noCompte = "10054013022"; //$NON-NLS-1$
    ConsulterPFIReponseType consulterPFIReponseType = MarshallTools.unmarshall(ConsulterPFIReponseType.class, new File(PFI_REPONSE_FILE));
    ConsulterPFIOut consulterPFIOut = consulterPFIReponseType.getConsulterPFIOut();

    ProvisionnerPfiIn provisionnerPfiIn = buildProvisionnerPfiIn(noCompte, dateDernierImpact, Arrays.asList("1089/INACTIF", "107")); //$NON-NLS-1$ //$NON-NLS-2$
    PortefeuilleIndividuel pfi = provisionnerPfiIn.getDonneesMetier().getPortefeuilleIndividuels().get(0);

    //Prepare mock
    EasyMock.expect(SvcCommMimProxy.getInstance()).andReturn(_svcCommMimConnector);
    EasyMock.expectLastCall().anyTimes();

    //Traitement 2: aucun SC du ConsulterPFI inhibé par un SC inactivé à rajouter dans la demande
    EasyMock.expect(_svcCommMimConnector.testInhibiton(Test_Consts.DEFAULT_MSGID, "107", "1089")).andReturn(new ConnectorResponse<Boolean, Integer>(false, null)); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_svcCommMimConnector.testInhibiton(Test_Consts.DEFAULT_MSGID, "6", "1089")).andReturn(new ConnectorResponse<Boolean, Integer>(false, null)); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_svcCommMimConnector.testInhibiton(Test_Consts.DEFAULT_MSGID, "63", "1089")).andReturn(new ConnectorResponse<Boolean, Integer>(true, null)); //$NON-NLS-1$ //$NON-NLS-2$

    //Traitement 3: le service 63/active de consulterPFIOut a un prerequis 107 qui existe dans la demande à l'état ACTIVE => le service 63 est rajouté à la demande
    EasyMock.expect(_svcCommMimConnector.getPreRequis(Test_Consts.DEFAULT_MSGID, "107")).andReturn(new ConnectorResponse<String, Boolean>(null, false)); //$NON-NLS-1$
    EasyMock.expect(_svcCommMimConnector.getPreRequis(Test_Consts.DEFAULT_MSGID, "6")).andReturn(new ConnectorResponse<String, Boolean>(null, false)); //$NON-NLS-1$
    EasyMock.expect(_svcCommMimConnector.getPreRequis(Test_Consts.DEFAULT_MSGID, "63")).andReturn(new ConnectorResponse<String, Boolean>("107", true)); //$NON-NLS-1$ //$NON-NLS-2$

    //Traitement 4: Aucun service ACTIVE/SUSPENDU/INACTIF de la demande inhibé par un service ACTIVE/SUSPENDU de consulterPFIOut pour ne pas inhiber un service dans la demande
    EasyMock.expect(_svcCommMimConnector.testInhibiton(Test_Consts.DEFAULT_MSGID, "1089", "107")).andReturn(new ConnectorResponse<Boolean, Integer>(false, null)); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_svcCommMimConnector.testInhibiton(Test_Consts.DEFAULT_MSGID, "1089", "6")).andReturn(new ConnectorResponse<Boolean, Integer>(false, null)); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_svcCommMimConnector.testInhibiton(Test_Consts.DEFAULT_MSGID, "1089", "63")).andReturn(new ConnectorResponse<Boolean, Integer>(false, null)); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_svcCommMimConnector.testInhibiton(Test_Consts.DEFAULT_MSGID, "107", "6")).andReturn(new ConnectorResponse<Boolean, Integer>(false, null)); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_svcCommMimConnector.testInhibiton(Test_Consts.DEFAULT_MSGID, "107", "63")).andReturn(new ConnectorResponse<Boolean, Integer>(false, null)); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_svcCommMimConnector.testInhibiton(Test_Consts.DEFAULT_MSGID, "63", "107")).andReturn(new ConnectorResponse<Boolean, Integer>(false, null)); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_svcCommMimConnector.testInhibiton(Test_Consts.DEFAULT_MSGID, "63", "6")).andReturn(new ConnectorResponse<Boolean, Integer>(false, null)); //$NON-NLS-1$ //$NON-NLS-2$

    //Traitement 5: aucun prerequis pour ne pas inhiber les SC actifs ou suspendus de la demande de service pour lesquels un SC prérequis manque
    EasyMock.expect(_svcCommMimConnector.getPreRequis(Test_Consts.DEFAULT_MSGID, "1089")).andReturn(new ConnectorResponse<String, Boolean>(null, false)); //$NON-NLS-1$
    EasyMock.expect(_svcCommMimConnector.getPreRequis(Test_Consts.DEFAULT_MSGID, "107")).andReturn(new ConnectorResponse<String, Boolean>(null, false)); //$NON-NLS-1$
    EasyMock.expect(_svcCommMimConnector.getPreRequis(Test_Consts.DEFAULT_MSGID, "63")).andReturn(new ConnectorResponse<String, Boolean>(null, false)); //$NON-NLS-1$

    //Vérifie les services de la demande avant le calcul d'impact
    int i = 0;
    Assert.assertEquals(pfi.getServiceAccessibles().size(), 2);
    //1er service
    String psNoSc = ((ServiceCommercial) (((ServiceAccessible) pfi.getServiceAccessibles().get(i).getIdref()).getServiceCommercial().getIdref())).getNoServiceCommercial();
    Assert.assertEquals("1089", psNoSc); //$NON-NLS-1$
    String psSaStatut = ((ServiceAccessible) pfi.getServiceAccessibles().get(i++).getIdref()).getStatut().toString();
    Assert.assertEquals(INACTIF, psSaStatut);

    //2ieme service
    psNoSc = ((ServiceCommercial) (((ServiceAccessible) pfi.getServiceAccessibles().get(i).getIdref()).getServiceCommercial().getIdref())).getNoServiceCommercial();
    Assert.assertEquals("107", psNoSc); //$NON-NLS-1$
    psSaStatut = ((ServiceAccessible) pfi.getServiceAccessibles().get(i++).getIdref()).getStatut().toString();
    Assert.assertEquals(ACTIVE, psSaStatut);

    // On enregistre le scénario des appels
    PowerMock.replayAll();

    //lance le calcul d'impact
    Tracabilite tracabilite = new Tracabilite(StringConstants.EMPTY_STRING, Test_Consts.DEFAULT_MSGID, "PROF", "nomPRocessus", "idProcessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    PM028BL200CalculerImpact calculerImpact = new PM028BL200CalculerImpactBuilder().tracabilite(tracabilite).pfi(pfi).consulterPFIOut(consulterPFIOut).provisionnerPfiIn(provisionnerPfiIn).forceResynchroSiNpbt(false).build();
    ProvisionnerPfiIn result = calculerImpact.execute(_currentInstance);

    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.OK, calculerImpact.getRetour().getResultat());
    Assert.assertEquals(Diagnostic.PROVISIONNER_SERVICES.toString(), calculerImpact.getRetour().getDiagnostic());
    Assert.assertNull(calculerImpact.getRetour().getLibelle());
    Assert.assertEquals(3, result.getDonneesMetier().getPortefeuilleIndividuels().get(0).getServiceAccessibles().size());

    //Vérifie les services de la demande
    i = 0;
    //1er service
    psNoSc = ((ServiceCommercial) (((ServiceAccessible) pfi.getServiceAccessibles().get(i).getIdref()).getServiceCommercial().getIdref())).getNoServiceCommercial();
    Assert.assertEquals("1089", psNoSc); //$NON-NLS-1$
    psSaStatut = ((ServiceAccessible) pfi.getServiceAccessibles().get(i++).getIdref()).getStatut().toString();
    Assert.assertEquals(INACTIF, psSaStatut);

    //2ieme service
    psNoSc = ((ServiceCommercial) (((ServiceAccessible) pfi.getServiceAccessibles().get(i).getIdref()).getServiceCommercial().getIdref())).getNoServiceCommercial();
    Assert.assertEquals("107", psNoSc); //$NON-NLS-1$
    psSaStatut = ((ServiceAccessible) pfi.getServiceAccessibles().get(i++).getIdref()).getStatut().toString();
    Assert.assertEquals(ACTIVE, psSaStatut);

    psNoSc = ((ServiceCommercial) (((ServiceAccessible) pfi.getServiceAccessibles().get(i).getIdref()).getServiceCommercial().getIdref())).getNoServiceCommercial();
    Assert.assertEquals("63", psNoSc); //$NON-NLS-1$
    psSaStatut = ((ServiceAccessible) pfi.getServiceAccessibles().get(i++).getIdref()).getStatut().toString();
    Assert.assertEquals(ACTIVE, psSaStatut);
  }

  /**
   * Supression de la demande les services accessibles inhibés par d'autres services accessibles (Traitement 4). La
   * calcul d'impact sort en ProvisionnerPfi.
   *
   * @throws RavelException
   *           throws exception
   */
  @Test
  public void Test_005_ProvisionnerPfi() throws RavelException
  {
    String dateDernierImpact = "20151211110709"; //$NON-NLS-1$
    String noCompte = "10054013022"; //$NON-NLS-1$
    ConsulterPFIReponseType consulterPFIReponseType = MarshallTools.unmarshall(ConsulterPFIReponseType.class, new File(PFI_REPONSE_FILE));
    ConsulterPFIOut consulterPFIOut = consulterPFIReponseType.getConsulterPFIOut();

    ProvisionnerPfiIn provisionnerPfiIn = buildProvisionnerPfiIn(noCompte, dateDernierImpact, Arrays.asList("1089/INACTIF", "107")); //$NON-NLS-1$ //$NON-NLS-2$
    PortefeuilleIndividuel pfi = provisionnerPfiIn.getDonneesMetier().getPortefeuilleIndividuels().get(0);

    //Prepare mock
    EasyMock.expect(SvcCommMimProxy.getInstance()).andReturn(_svcCommMimConnector);
    EasyMock.expectLastCall().anyTimes();

    //Traitement 2: aucun SC du ConsulterPFI inhibé par un SC inactivé à rajouter dans la demande
    EasyMock.expect(_svcCommMimConnector.testInhibiton(Test_Consts.DEFAULT_MSGID, "107", "1089")).andReturn(new ConnectorResponse<Boolean, Integer>(false, null)); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_svcCommMimConnector.testInhibiton(Test_Consts.DEFAULT_MSGID, "6", "1089")).andReturn(new ConnectorResponse<Boolean, Integer>(false, null)); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_svcCommMimConnector.testInhibiton(Test_Consts.DEFAULT_MSGID, "63", "1089")).andReturn(new ConnectorResponse<Boolean, Integer>(false, null)); //$NON-NLS-1$ //$NON-NLS-2$

    //Traitement 3: Aucun prerequis pour les services active/suspendu de consulterPFIOut pour que le traitement 3 ne fasse rien !
    EasyMock.expect(_svcCommMimConnector.getPreRequis(Test_Consts.DEFAULT_MSGID, "107")).andReturn(new ConnectorResponse<String, Boolean>(null, false)); //$NON-NLS-1$
    EasyMock.expect(_svcCommMimConnector.getPreRequis(Test_Consts.DEFAULT_MSGID, "6")).andReturn(new ConnectorResponse<String, Boolean>(null, false)); //$NON-NLS-1$
    EasyMock.expect(_svcCommMimConnector.getPreRequis(Test_Consts.DEFAULT_MSGID, "63")).andReturn(new ConnectorResponse<String, Boolean>(null, false)); //$NON-NLS-1$

    //Traitement 4: Le service 1089 de la demande est inhibé par le service 6 de consulterPFIOut => suppression du service 1089 de la demande
    EasyMock.expect(_svcCommMimConnector.testInhibiton(Test_Consts.DEFAULT_MSGID, "1089", "107")).andReturn(new ConnectorResponse<Boolean, Integer>(false, null)); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_svcCommMimConnector.testInhibiton(Test_Consts.DEFAULT_MSGID, "1089", "6")).andReturn(new ConnectorResponse<Boolean, Integer>(true, null)); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_svcCommMimConnector.testInhibiton(Test_Consts.DEFAULT_MSGID, "1089", "63")).andReturn(new ConnectorResponse<Boolean, Integer>(false, null)); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_svcCommMimConnector.testInhibiton(Test_Consts.DEFAULT_MSGID, "107", "6")).andReturn(new ConnectorResponse<Boolean, Integer>(false, null)); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_svcCommMimConnector.testInhibiton(Test_Consts.DEFAULT_MSGID, "107", "63")).andReturn(new ConnectorResponse<Boolean, Integer>(false, null)); //$NON-NLS-1$ //$NON-NLS-2$

    //Traitement 5: aucun prerequis pour ne pas inhiber les SC actifs ou suspendus de la demande de service pour lesquels un SC prérequis manque
    EasyMock.expect(_svcCommMimConnector.getPreRequis(Test_Consts.DEFAULT_MSGID, "107")).andReturn(new ConnectorResponse<String, Boolean>(null, false)); //$NON-NLS-1$

    //Vérifie les services de la demande avant le calcul d'impact
    int i = 0;
    Assert.assertEquals(pfi.getServiceAccessibles().size(), 2);
    //1er service
    String psNoSc = ((ServiceCommercial) (((ServiceAccessible) pfi.getServiceAccessibles().get(i).getIdref()).getServiceCommercial().getIdref())).getNoServiceCommercial();
    Assert.assertEquals("1089", psNoSc); //$NON-NLS-1$
    String psSaStatut = ((ServiceAccessible) pfi.getServiceAccessibles().get(i++).getIdref()).getStatut().toString();
    Assert.assertEquals(INACTIF, psSaStatut);

    PowerMock.replayAll();

    //2ieme service
    psNoSc = ((ServiceCommercial) (((ServiceAccessible) pfi.getServiceAccessibles().get(i).getIdref()).getServiceCommercial().getIdref())).getNoServiceCommercial();
    Assert.assertEquals("107", psNoSc); //$NON-NLS-1$
    psSaStatut = ((ServiceAccessible) pfi.getServiceAccessibles().get(i++).getIdref()).getStatut().toString();
    Assert.assertEquals(ACTIVE, psSaStatut);

    //lance le calcul d'impact
    Tracabilite tracabilite = new Tracabilite(StringConstants.EMPTY_STRING, Test_Consts.DEFAULT_MSGID, "PROF", "nomPRocessus", "idProcessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    PM028BL200CalculerImpact calculerImpact = new PM028BL200CalculerImpactBuilder().tracabilite(tracabilite).pfi(pfi).consulterPFIOut(consulterPFIOut).provisionnerPfiIn(provisionnerPfiIn).forceResynchroSiNpbt(false).build();
    ProvisionnerPfiIn result = calculerImpact.execute(_currentInstance);

    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.OK, calculerImpact.getRetour().getResultat());
    Assert.assertEquals(Diagnostic.PROVISIONNER_SERVICES.toString(), calculerImpact.getRetour().getDiagnostic());
    Assert.assertNull(calculerImpact.getRetour().getLibelle());
    Assert.assertEquals(1, result.getDonneesMetier().getPortefeuilleIndividuels().get(0).getServiceAccessibles().size());

    //Vérifie les services de la demande
    i = 0;
    //Le service 1089 a été supprimé
    //il ne reste plus que le service 107
    psNoSc = ((ServiceCommercial) (((ServiceAccessible) pfi.getServiceAccessibles().get(i).getIdref()).getServiceCommercial().getIdref())).getNoServiceCommercial();
    Assert.assertEquals("107", psNoSc); //$NON-NLS-1$
    psSaStatut = ((ServiceAccessible) pfi.getServiceAccessibles().get(i++).getIdref()).getStatut().toString();
    Assert.assertEquals(ACTIVE, psSaStatut);
  }

  /**
   * Inhibition des SC actifs ou suspendus de la demande de service pour lesquels un SC prérequis manque . La calcul
   * d'impact sort en ProvisionnerPfi.
   *
   * @throws RavelException
   *           throws exception
   */
  @Test
  public void Test_006_ProvisionnerPfi() throws RavelException
  {
    String dateDernierImpact = "20151211110709"; //$NON-NLS-1$
    String noCompte = "10054013022"; //$NON-NLS-1$
    ConsulterPFIReponseType consulterPFIReponseType = MarshallTools.unmarshall(ConsulterPFIReponseType.class, new File(PFI_REPONSE_FILE));
    ConsulterPFIOut consulterPFIOut = consulterPFIReponseType.getConsulterPFIOut();

    ProvisionnerPfiIn provisionnerPfiIn = buildProvisionnerPfiIn(noCompte, dateDernierImpact, Arrays.asList("1089/INACTIF", "107")); //$NON-NLS-1$ //$NON-NLS-2$
    PortefeuilleIndividuel pfi = provisionnerPfiIn.getDonneesMetier().getPortefeuilleIndividuels().get(0);

    //Prepare mock
    EasyMock.expect(SvcCommMimProxy.getInstance()).andReturn(_svcCommMimConnector);
    EasyMock.expectLastCall().anyTimes();

    //Traitement 2: aucun SC du ConsulterPFI inhibé par un SC inactivé à rajouter dans la demande
    EasyMock.expect(_svcCommMimConnector.testInhibiton(Test_Consts.DEFAULT_MSGID, "107", "1089")).andReturn(new ConnectorResponse<Boolean, Integer>(false, null)); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_svcCommMimConnector.testInhibiton(Test_Consts.DEFAULT_MSGID, "6", "1089")).andReturn(new ConnectorResponse<Boolean, Integer>(false, null)); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_svcCommMimConnector.testInhibiton(Test_Consts.DEFAULT_MSGID, "63", "1089")).andReturn(new ConnectorResponse<Boolean, Integer>(false, null)); //$NON-NLS-1$ //$NON-NLS-2$

    //Traitement 3: Aucun prerequis pour les services active/suspendu de consulterPFIOut pour que le traitement 3 ne fasse rien !
    EasyMock.expect(_svcCommMimConnector.getPreRequis(Test_Consts.DEFAULT_MSGID, "107")).andReturn(new ConnectorResponse<String, Boolean>(null, false)); //$NON-NLS-1$
    EasyMock.expect(_svcCommMimConnector.getPreRequis(Test_Consts.DEFAULT_MSGID, "6")).andReturn(new ConnectorResponse<String, Boolean>(null, false)); //$NON-NLS-1$
    EasyMock.expect(_svcCommMimConnector.getPreRequis(Test_Consts.DEFAULT_MSGID, "63")).andReturn(new ConnectorResponse<String, Boolean>(null, false)); //$NON-NLS-1$

    //Traitement 4: Aucun service ACTIVE/SUSPENDU/INACTIF de la demande inhibé par un service ACTIVE/SUSPENDU de consulterPFIOut pour ne pas inhiber un service dans la demande
    EasyMock.expect(_svcCommMimConnector.testInhibiton(Test_Consts.DEFAULT_MSGID, "1089", "107")).andReturn(new ConnectorResponse<Boolean, Integer>(false, null)); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_svcCommMimConnector.testInhibiton(Test_Consts.DEFAULT_MSGID, "1089", "6")).andReturn(new ConnectorResponse<Boolean, Integer>(false, null)); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_svcCommMimConnector.testInhibiton(Test_Consts.DEFAULT_MSGID, "1089", "63")).andReturn(new ConnectorResponse<Boolean, Integer>(false, null)); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_svcCommMimConnector.testInhibiton(Test_Consts.DEFAULT_MSGID, "107", "6")).andReturn(new ConnectorResponse<Boolean, Integer>(false, null)); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_svcCommMimConnector.testInhibiton(Test_Consts.DEFAULT_MSGID, "107", "63")).andReturn(new ConnectorResponse<Boolean, Integer>(false, null)); //$NON-NLS-1$ //$NON-NLS-2$

    //Traitement 5: Le service 107/ACTIVE de la demande a pour prerequis la service 630 qui n'existe pas dans consulterPFIOut => suppression du service 107 de la demande
    EasyMock.expect(_svcCommMimConnector.getPreRequis(Test_Consts.DEFAULT_MSGID, "1089")).andReturn(new ConnectorResponse<String, Boolean>(null, false)); //$NON-NLS-1$
    EasyMock.expect(_svcCommMimConnector.getPreRequis(Test_Consts.DEFAULT_MSGID, "107")).andReturn(new ConnectorResponse<String, Boolean>("630", true)); //$NON-NLS-1$ //$NON-NLS-2$

    //Vérifie les services de la demande avant le calcul d'impact
    int i = 0;
    Assert.assertEquals(pfi.getServiceAccessibles().size(), 2);
    //1er service
    String psNoSc = ((ServiceCommercial) (((ServiceAccessible) pfi.getServiceAccessibles().get(i).getIdref()).getServiceCommercial().getIdref())).getNoServiceCommercial();
    Assert.assertEquals("1089", psNoSc); //$NON-NLS-1$
    String psSaStatut = ((ServiceAccessible) pfi.getServiceAccessibles().get(i++).getIdref()).getStatut().toString();
    Assert.assertEquals(INACTIF, psSaStatut);

    //2ieme service
    psNoSc = ((ServiceCommercial) (((ServiceAccessible) pfi.getServiceAccessibles().get(i).getIdref()).getServiceCommercial().getIdref())).getNoServiceCommercial();
    Assert.assertEquals("107", psNoSc); //$NON-NLS-1$
    psSaStatut = ((ServiceAccessible) pfi.getServiceAccessibles().get(i++).getIdref()).getStatut().toString();
    Assert.assertEquals(ACTIVE, psSaStatut);

    PowerMock.replayAll();

    //lance le calcul d'impact
    Tracabilite tracabilite = new Tracabilite(StringConstants.EMPTY_STRING, Test_Consts.DEFAULT_MSGID, "PROF", "nomPRocessus", "idProcessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    PM028BL200CalculerImpact calculerImpact = new PM028BL200CalculerImpactBuilder().tracabilite(tracabilite).pfi(pfi).consulterPFIOut(consulterPFIOut).provisionnerPfiIn(provisionnerPfiIn).forceResynchroSiNpbt(false).build();
    ProvisionnerPfiIn result = calculerImpact.execute(_currentInstance);

    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.OK, calculerImpact.getRetour().getResultat());
    Assert.assertEquals(Diagnostic.PROVISIONNER_SERVICES.toString(), calculerImpact.getRetour().getDiagnostic());
    Assert.assertNull(calculerImpact.getRetour().getLibelle());
    Assert.assertEquals(1, result.getDonneesMetier().getPortefeuilleIndividuels().get(0).getServiceAccessibles().size());

    //Vérifie les services de la demande
    i = 0;
    //Le service 107 a été supprimé
    //il ne reste plus que le service 1089
    psNoSc = ((ServiceCommercial) (((ServiceAccessible) pfi.getServiceAccessibles().get(i).getIdref()).getServiceCommercial().getIdref())).getNoServiceCommercial();
    Assert.assertEquals("1089", psNoSc); //$NON-NLS-1$
    psSaStatut = ((ServiceAccessible) pfi.getServiceAccessibles().get(i++).getIdref()).getStatut().toString();
    Assert.assertEquals(INACTIF, psSaStatut);
  }

  /**
   * Teste le cas où tous les services de la demande ont été inhibés et qu'aucun service n'a été rajouté. Le calcul
   * d'impact sort en OK/PROVISIONNER_SERVICES.
   *
   * @throws RavelException
   *           throws exception
   */
  @Test
  public void Test_007_Aucun_Provisionning() throws RavelException
  {
    String dateDernierImpact = "20151211110709"; //$NON-NLS-1$
    String noCompte = "10054013022"; //$NON-NLS-1$
    ConsulterPFIReponseType consulterPFIReponseType = MarshallTools.unmarshall(ConsulterPFIReponseType.class, new File(PFI_REPONSE_FILE));
    ConsulterPFIOut consulterPFIOut = consulterPFIReponseType.getConsulterPFIOut();

    ProvisionnerPfiIn provisionnerPfiIn = buildProvisionnerPfiIn(noCompte, dateDernierImpact, Arrays.asList("1089/INACTIF", "107")); //$NON-NLS-1$ //$NON-NLS-2$
    PortefeuilleIndividuel pfi = provisionnerPfiIn.getDonneesMetier().getPortefeuilleIndividuels().get(0);

    //Prepare mock
    EasyMock.expect(SvcCommMimProxy.getInstance()).andReturn(_svcCommMimConnector);
    EasyMock.expectLastCall().anyTimes();

    //Traitement 2: aucun SC du ConsulterPFI inhibé par un SC inactivé à rajouter dans la demande
    EasyMock.expect(_svcCommMimConnector.testInhibiton(Test_Consts.DEFAULT_MSGID, "107", "1089")).andReturn(new ConnectorResponse<Boolean, Integer>(false, null)); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_svcCommMimConnector.testInhibiton(Test_Consts.DEFAULT_MSGID, "6", "1089")).andReturn(new ConnectorResponse<Boolean, Integer>(false, null)); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_svcCommMimConnector.testInhibiton(Test_Consts.DEFAULT_MSGID, "63", "1089")).andReturn(new ConnectorResponse<Boolean, Integer>(false, null)); //$NON-NLS-1$ //$NON-NLS-2$

    //Traitement 3: Aucun prerequis pour les services active/suspendu de consulterPFIOut pour que le traitement 3 ne fasse rien !
    EasyMock.expect(_svcCommMimConnector.getPreRequis(Test_Consts.DEFAULT_MSGID, "107")).andReturn(new ConnectorResponse<String, Boolean>(null, false)); //$NON-NLS-1$
    EasyMock.expect(_svcCommMimConnector.getPreRequis(Test_Consts.DEFAULT_MSGID, "6")).andReturn(new ConnectorResponse<String, Boolean>(null, false)); //$NON-NLS-1$
    EasyMock.expect(_svcCommMimConnector.getPreRequis(Test_Consts.DEFAULT_MSGID, "63")).andReturn(new ConnectorResponse<String, Boolean>(null, false)); //$NON-NLS-1$

    //Traitement 4: Le service 1089 de la demande est inhibé par le service 6 de consulterPFIOut => suppression du service 1089 de la demande
    EasyMock.expect(_svcCommMimConnector.testInhibiton(Test_Consts.DEFAULT_MSGID, "1089", "107")).andReturn(new ConnectorResponse<Boolean, Integer>(false, null)); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_svcCommMimConnector.testInhibiton(Test_Consts.DEFAULT_MSGID, "1089", "6")).andReturn(new ConnectorResponse<Boolean, Integer>(true, null)); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_svcCommMimConnector.testInhibiton(Test_Consts.DEFAULT_MSGID, "1089", "63")).andReturn(new ConnectorResponse<Boolean, Integer>(false, null)); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_svcCommMimConnector.testInhibiton(Test_Consts.DEFAULT_MSGID, "107", "6")).andReturn(new ConnectorResponse<Boolean, Integer>(false, null)); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_svcCommMimConnector.testInhibiton(Test_Consts.DEFAULT_MSGID, "107", "63")).andReturn(new ConnectorResponse<Boolean, Integer>(false, null)); //$NON-NLS-1$ //$NON-NLS-2$

    //Traitement 5: Le service 107/ACTIVE de la demande a pour prerequis la service 630 qui n'existe pas dans consulterPFIOut => suppression du service 107 de la demande
    EasyMock.expect(_svcCommMimConnector.getPreRequis(Test_Consts.DEFAULT_MSGID, "107")).andReturn(new ConnectorResponse<String, Boolean>("630", false)); //$NON-NLS-1$ //$NON-NLS-2$

    //Vérifie les services de la demande avant le calcul d'impact
    int i = 0;
    Assert.assertEquals(pfi.getServiceAccessibles().size(), 2);
    //1er service
    String psNoSc = ((ServiceCommercial) (((ServiceAccessible) pfi.getServiceAccessibles().get(i).getIdref()).getServiceCommercial().getIdref())).getNoServiceCommercial();
    Assert.assertEquals("1089", psNoSc); //$NON-NLS-1$
    String psSaStatut = ((ServiceAccessible) pfi.getServiceAccessibles().get(i++).getIdref()).getStatut().toString();
    Assert.assertEquals(INACTIF, psSaStatut);

    //2ieme service
    psNoSc = ((ServiceCommercial) (((ServiceAccessible) pfi.getServiceAccessibles().get(i).getIdref()).getServiceCommercial().getIdref())).getNoServiceCommercial();
    Assert.assertEquals("107", psNoSc); //$NON-NLS-1$
    psSaStatut = ((ServiceAccessible) pfi.getServiceAccessibles().get(i++).getIdref()).getStatut().toString();
    Assert.assertEquals(ACTIVE, psSaStatut);

    PowerMock.replayAll();

    //lance le calcul d'impact
    Tracabilite tracabilite = new Tracabilite(StringConstants.EMPTY_STRING, Test_Consts.DEFAULT_MSGID, "PROF", "nomPRocessus", "idProcessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    PM028BL200CalculerImpact calculerImpact = new PM028BL200CalculerImpactBuilder().tracabilite(tracabilite).pfi(pfi).consulterPFIOut(consulterPFIOut).provisionnerPfiIn(provisionnerPfiIn).forceResynchroSiNpbt(false).build();
    ProvisionnerPfiIn result = calculerImpact.execute(_currentInstance);

    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.OK, calculerImpact.getRetour().getResultat());
    Assert.assertEquals(Diagnostic.AUCUN_PROVISIONING.toString(), calculerImpact.getRetour().getDiagnostic());
    Assert.assertNull(calculerImpact.getRetour().getLibelle());
    Assert.assertEquals(0, result.getDonneesMetier().getPortefeuilleIndividuels().get(0).getServiceAccessibles().size());
    //Vérifie les services de la demande
    //Le service 107 a été supprimé
    //Le service 1089 a été supprimé
  }

  /**
   * Essayer si le retour c'est RESYNCHRO_SI_NPBT quand le statut de ConsulterPFIOut c'est RESILIE.
   *
   * @throws RavelException
   *           thrown exception
   * @throws IOException
   *           exception
   */
  @Test
  public void Test_008_ProvisionnerPfi() throws RavelException, IOException
  {
    String dateDernierImpact = "20151211110709"; //$NON-NLS-1$
    String noCompte = "10054013022"; //$NON-NLS-1$

    String fichier = new String(Files.readAllBytes(Paths.get(PFI_REPONSE_FILE_ANO320328)));
    ConsulterPFIReponseType consulterPFIReponseType = MarshallTools.unmarshallAndBypassDTDValidation(ConsulterPFIReponseType.class, fichier);
    ConsulterPFIOut consulterPFIOut = consulterPFIReponseType.getConsulterPFIOut();

    ProvisionnerPfiIn provisionnerPfiIn = buildProvisionnerPfiIn(noCompte, dateDernierImpact, Arrays.asList("1089/INACTIF", "107")); //$NON-NLS-1$ //$NON-NLS-2$
    PortefeuilleIndividuel pfi = provisionnerPfiIn.getDonneesMetier().getPortefeuilleIndividuels().get(0);

    //Vérifie les services de la demande avant le calcul d'impact
    int i = 0;
    Assert.assertEquals(pfi.getServiceAccessibles().size(), 2);
    //1er service
    String psNoSc = ((ServiceCommercial) (((ServiceAccessible) pfi.getServiceAccessibles().get(i).getIdref()).getServiceCommercial().getIdref())).getNoServiceCommercial();
    Assert.assertEquals("1089", psNoSc); //$NON-NLS-1$
    String psSaStatut = ((ServiceAccessible) pfi.getServiceAccessibles().get(i++).getIdref()).getStatut().toString();
    Assert.assertEquals(INACTIF, psSaStatut);

    //2ieme service
    psNoSc = ((ServiceCommercial) (((ServiceAccessible) pfi.getServiceAccessibles().get(i).getIdref()).getServiceCommercial().getIdref())).getNoServiceCommercial();
    Assert.assertEquals("107", psNoSc); //$NON-NLS-1$
    psSaStatut = ((ServiceAccessible) pfi.getServiceAccessibles().get(i++).getIdref()).getStatut().toString();
    Assert.assertEquals(ACTIVE, psSaStatut);

    //lance le calcul d'impact
    Tracabilite tracabilite = new Tracabilite(StringConstants.EMPTY_STRING, Test_Consts.DEFAULT_MSGID, "PROF", "nomPRocessus", "idProcessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    PM028BL200CalculerImpact calculerImpact = new PM028BL200CalculerImpactBuilder().tracabilite(tracabilite).pfi(pfi).consulterPFIOut(consulterPFIOut).provisionnerPfiIn(provisionnerPfiIn).forceResynchroSiNpbt(false).build();
    ProvisionnerPfiIn result = calculerImpact.execute(_currentInstance);

    Assert.assertEquals(StringConstants.OK, calculerImpact.getRetour().getResultat());
    Assert.assertEquals(Diagnostic.RESYNCHRO_SI_NPBT.toString(), calculerImpact.getRetour().getDiagnostic());
    Assert.assertNull(calculerImpact.getRetour().getLibelle());
    Assert.assertEquals(2, result.getDonneesMetier().getPortefeuilleIndividuels().get(0).getServiceAccessibles().size());

    //Vérifie les services de la demande
    i = 0;
    //1er service
    psNoSc = ((ServiceCommercial) (((ServiceAccessible) pfi.getServiceAccessibles().get(i).getIdref()).getServiceCommercial().getIdref())).getNoServiceCommercial();
    Assert.assertEquals("1089", psNoSc); //$NON-NLS-1$
    psSaStatut = ((ServiceAccessible) pfi.getServiceAccessibles().get(i++).getIdref()).getStatut().toString();
    Assert.assertEquals(INACTIF, psSaStatut);

    //2ieme service
    psNoSc = ((ServiceCommercial) (((ServiceAccessible) pfi.getServiceAccessibles().get(i).getIdref()).getServiceCommercial().getIdref())).getNoServiceCommercial();
    Assert.assertEquals("107", psNoSc); //$NON-NLS-1$
    psSaStatut = ((ServiceAccessible) pfi.getServiceAccessibles().get(i++).getIdref()).getStatut().toString();
    Assert.assertEquals(ACTIVE, psSaStatut);
  }

  /**
   * Create a ProvisionnerPfiIn base on on PROD exemple
   *
   * @param noCompte_p
   *          account number
   * @param dateDernierImpact_p
   *          last impact date
   * @param services_p
   *          services
   * @return a {@link ProvisionnerPfiIn} object
   */
  private ProvisionnerPfiIn buildProvisionnerPfiIn(String noCompte_p, String dateDernierImpact_p, List<String> services_p)
  {
    ProvisionnerPfiIn provisionnerPfiIn = new ProvisionnerPfiIn();
    PIVOTREFERENCE pivotreference = null;
    PortefeuilleIndividuel portefeuilleIndividuel = null;

    //acte metier
    ActeMetier acteMetier = new ActeMetier();
    acteMetier.setDateCreation("20110225101400"); //$NON-NLS-1$
    acteMetier.setIdentifiantActe("INJe6ee05f9dce0408aa205a0ef4ed184a5"); //$NON-NLS-1$
    acteMetier.setPriorite("1"); //$NON-NLS-1$
    PartitionSic partitionSic = new PartitionSic();
    partitionSic.setIdentifiant("1"); //$NON-NLS-1$
    acteMetier.setPartitionSic(partitionSic);
    St st = new St();
    st.setIdentifiant("114"); //$NON-NLS-1$
    acteMetier.setSt(st);
    portefeuilleIndividuel = new PortefeuilleIndividuel();
    portefeuilleIndividuel.setId("PFI-1"); //$NON-NLS-1$
    pivotreference = new PIVOTREFERENCE();
    pivotreference.setIdref(portefeuilleIndividuel);
    acteMetier.getPortefeuilleServices().add(pivotreference);

    //donnesMetier
    DonneesMetier donneesMetier = new DonneesMetier();
    portefeuilleIndividuel.setNoCompte(noCompte_p);
    portefeuilleIndividuel.setDateDernierImpact(dateDernierImpact_p);

    donneesMetier.getPortefeuilleIndividuels().add(portefeuilleIndividuel);

    for (String sa : services_p)
    {
      Pair<ServiceAccessible, ServiceCommercial> sasc = createProvInService(sa);
      donneesMetier.getServiceAccessibles().add(sasc._first);
      donneesMetier.getServiceCommercials().add(sasc._second);
      pivotreference = new PIVOTREFERENCE();
      pivotreference.setIdref(sasc._first);
      portefeuilleIndividuel.getServiceAccessibles().add(pivotreference);
    }

    provisionnerPfiIn.setActeMetier(acteMetier);
    provisionnerPfiIn.setDonneesMetier(donneesMetier);
    return provisionnerPfiIn;

  }

  /**
   * Create service to provision with SA and SC.
   *
   * @param service_p
   *          service
   * @return SA and SC to the supplied service
   */
  private Pair<ServiceAccessible, ServiceCommercial> createProvInService(String service_p)
  {
    ServiceCommercial serviceCommercial;
    ServiceAccessible serviceAccessible;

    String[] tab = service_p.split("/"); //$NON-NLS-1$
    String noSC = tab[0];
    String statut = ACTIVE;
    if (tab.length == 2)
    {
      statut = tab[1];
    }

    serviceAccessible = new ServiceAccessible();
    serviceAccessible.setId("SA-REF-" + noSC); //$NON-NLS-1$
    serviceAccessible.setStatut(ServiceAccessibleStatut.fromValue(statut));
    serviceCommercial = new ServiceCommercial();
    serviceCommercial.setId("SC-REF-" + noSC); //$NON-NLS-1$
    serviceCommercial.setNoServiceCommercial(noSC);
    PIVOTREFERENCE pivotreference = new PIVOTREFERENCE();
    pivotreference.setIdref(serviceCommercial);
    serviceAccessible.setServiceCommercial(pivotreference);

    return new Pair<ServiceAccessible, ServiceCommercial>(serviceAccessible, serviceCommercial);
  }
}
