/*******************************************************************************
* $Id: PEI0018_CommandePfiTest.java 17902 2019-03-01 15:58:00Z fbarnabe $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PE0018;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.lang.annotation.ElementType;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

import org.apache.commons.lang3.RandomStringUtils;
import org.easymock.EasyMock;
import org.hibernate.validator.internal.engine.ConstraintViolationImpl;
import org.hibernate.validator.internal.engine.path.PathImpl;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.Mock;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PowerMockListener;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.testlisteners.FieldDefaulter;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.modules.junit4.PowerMockRunnerDelegate;
import org.springframework.test.context.ContextConfiguration;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.configuration.ConfigFileManager;
import com.bytel.ravel.common.data.exchange.generated.RavelRequest.RequestHeader;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.response.IRavelResponse;
import com.bytel.ravel.common.factory.response.RavelResponseFactory;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.test.podam.PodamBytelJUnit4ClassRunner;
import com.bytel.ravel.common.utils.DateTimeTools.DateTimeFormatPattern;
import com.bytel.ravel.common.utils.RetourFactoryForTU;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.net.http.HttpConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.ProcessManager;
import com.bytel.spirit.common.activities.shared.BL1700_AjouterRefFonc;
import com.bytel.spirit.common.activities.shared.BL200_ObtenirServiceCommercial;
import com.bytel.spirit.common.activities.shared.BL200_ObtenirServiceCommercial.BL200_ObtenirServiceCommercialBuilder;
import com.bytel.spirit.common.activities.shared.BL4600_CreerErreurSpirit;
import com.bytel.spirit.common.activities.shared.BL4600_CreerErreurSpirit.BL4600_CreerErreurSpiritBuilder;
import com.bytel.spirit.common.activities.shared.BL800_ObtenirSequence;
import com.bytel.spirit.common.activities.shared.BL800_ObtenirSequence.BL800_ObtenirSequenceBuilder;
import com.bytel.spirit.common.activities.shared.structs.UniqueIdConstant;
import com.bytel.spirit.common.connectors.air.AIRProxy;
import com.bytel.spirit.common.connectors.cmd.CMDProxy;
import com.bytel.spirit.common.connectors.ink.ResponseConnector;
import com.bytel.spirit.common.connectors.ink.activities.PROV_SI001_LancerOrchestrateur;
import com.bytel.spirit.common.connectors.ink.activities.PROV_SI001_LancerOrchestrateur.PROV_SI001_LancerOrchestrateurBuilder;
import com.bytel.spirit.common.connectors.rex.REXProxy;
import com.bytel.spirit.common.connectors.rpg.RPGProxy;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.IRefFoncConstants;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.misc.validation.IValidationConst;
import com.bytel.spirit.common.shared.saab.air.IndexRecherchePfi;
import com.bytel.spirit.common.shared.saab.cmd.ClientOperateur;
import com.bytel.spirit.common.shared.saab.cmd.request.CreateCommandeRequest;
import com.bytel.spirit.common.shared.saab.rex.ReconciliationCommerciale;
import com.bytel.spirit.common.shared.saab.rex.request.CreateOrUpdateReconciliationCommercialeRequest;
import com.bytel.spirit.common.shared.saab.rex.request.ManageReconciliationCommercialeEnMasseRequest;
import com.bytel.spirit.common.shared.saab.rpg.CatalogServiceCommercial;
import com.bytel.spirit.common.shared.saab.rpg.Statut;
import com.bytel.spirit.prof.processes.Messages;
import com.bytel.spirit.prof.processes.PE0018.utils.CommandePFIUtils;
import com.bytel.spirit.prof.shared.misc.error.Reponse;
import com.bytel.spirit.prof.shared.types.json.CommandePfi;
import com.bytel.spirit.prof.shared.types.json.DemandePhoto;
import com.bytel.spirit.prof.shared.types.json.PhotoPfi;
import com.bytel.spirit.prof.shared.types.json.TypeCommand;
import com.bytel.spirit.prof.shared.types.json.request.PhotoPfiRequest;
import com.google.gson.Gson;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author jjoly
 * @version ($Revision: 17902 $ $Date: 2019-03-01 16:58:00 +0100 (ven. 01 mars 2019) $)
 */
@RunWith(PowerMockRunner.class)
@PowerMockListener(FieldDefaulter.class)
@PowerMockRunnerDelegate(PodamBytelJUnit4ClassRunner.class)
@ContextConfiguration("classpath:BeansProcessTestMocks.xml")
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
@PrepareForTest({ PEI0018_CommandePfi.class, GsonTools.class, Gson.class, PhotoPfi.class, Validation.class, RPGProxy.class, CMDProxy.class, REXProxy.class, BL800_ObtenirSequenceBuilder.class, AIRProxy.class, BL200_ObtenirServiceCommercial.class, BL200_ObtenirServiceCommercialBuilder.class, BL4600_CreerErreurSpirit.class, BL4600_CreerErreurSpiritBuilder.class })
public class PEI0018_CommandePfiTest
{
  /**
   * Factory de génération des beans
   */
  private static PodamFactory __podam;

  /**
   * Expected message for mandatory issue during validation
   */
  private static final String MANDATORY_ERROR = IValidationConst.ATTRIBUT_OBLIGATOIRE_MANQUANT;

  /**
   * Commande PFI Operation
   */
  private static final String COMMANDE_PFI = "commande-pfi"; //$NON-NLS-1$

  /**
   * ConfigFileManager singleton
   */
  @SuppressWarnings("unused")
  private static ConfigFileManager _configFileManager;

  /**
   * Duration of cache in ISO-8601 format
   */
  private static final String SERVICE_COM_CACHE_DURATION = "periodeMAJConfigServicesCo"; //$NON-NLS-1$

  /**
   * Expected message for missing conditionnal attribute during validation
   */
  private static final String CONDITIONNAL_ERROR = IValidationConst.ATTRIBUT_COND_MANQUANT;

  /**
   * Expected message for unexpected conditionnal attribute during validation
   */
  private static final String CONDITIONNAL_UNEXPECTED = IValidationConst.ATTRIBUT_COND_INATTENDU;

  /**
   * Expected message for attribute format not respect during validation
   */
  private static final String FORMAT_NOT_RESPECTED = IValidationConst.FORMAT_ATTRIBUT_NON_RESPECTE;

  /**
   * Initialize before all tests
   *
   * @throws Exception
   *           Exception to be thrown in case of failure
   */
  @BeforeClass
  public static void setUpBeforeClass() throws Exception
  {
    // désactivation du cache podam
    __podam = new PodamFactoryImpl();
    __podam.getStrategy().setMemoization(false);
    __podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());
  }

  /**
   * Instance of {@code PEI0018_CommandePFI}
   */
  private PEI0018_CommandePfi _processInstance;

  /**
   * The mock object {@code Request}
   */
  private Request _request;

  /**
   * The mock object {@code Gson}
   */
  @Mock
  private Gson _gsonMock;

  /**
   * The javax validation factory object
   */
  @Mock
  private ValidatorFactory _validationFactoryMock;
  /**
   * The javax validation object
   */
  @Mock
  private Validator _validationMock;

  /**
   * The input data
   */
  @Mock
  private String _infosPfiMock;

  /**
   * The mock object {@code String}
   */
  @Mock
  private String _inPayloadMock;

  /**
   * The mock object {@code IRavelResponse}
   */
  @Mock
  private IRavelResponse _ravelReponseMock;

  /**
   * The mock object {@code String}
   */
  @Mock
  private String _outPayloadMock;

  /**
   * The mock object {@code Response}
   */
  @Mock
  private Response _reponseMock;

  /**
   * The mock object {@code PROV_SI001_LancerOrchestrateurBuilder}
   */
  @Mock
  private PROV_SI001_LancerOrchestrateurBuilder _provSI001BuilderMock;

  /**
   * The mock object {@code PROV_SI001_LancerOrchestrateur}
   */
  @Mock
  private PROV_SI001_LancerOrchestrateur _provSI001Mock;

  /**
   * generator data of PFI
   */
  private PFIFullForTest _pfiGenerator;

  /**
   * The mock object {@Code CMDProxy}
   */
  @Mock
  private CMDProxy _cmdProxy;

  /**
   * The mock object {@Code REXProxy}
   */
  @Mock
  private REXProxy _rexProxy;

  /**
   * The mock object {@Code AIRProxy}
   */
  @Mock
  private AIRProxy _airProxy;

  /**
   * The mock object {@Code BL200_ObtenirServiceCommercialBuilder}
   */
  @Mock
  private BL200_ObtenirServiceCommercialBuilder _bl200BuilderMock;

  /**
   * The mock object {@Code BL200_ObtenirServiceCommercial}
   */
  @Mock
  private BL200_ObtenirServiceCommercial _bl200Mock;

  /**
   * The mock object {@Code BL800_ObtenirSequenceBuilder}
   */
  @Mock
  private BL800_ObtenirSequenceBuilder _bl800BuilderMock;

  /**
   * The mock object {@Code BL800_ObtenirSequence}
   */
  @Mock
  private BL800_ObtenirSequence _bl800Mock;

  /**
   * The mock object {@Code BL4600_CreerErreurSpiritBuilder}
   */
  @Mock
  private BL4600_CreerErreurSpiritBuilder _bl4600BuilderMock;

  /**
   * The mock object {@Code BL4600_CreerErreurSpirit}
   */
  @Mock
  private BL4600_CreerErreurSpirit _bl4600Mock;

  /**
   * Initialization of tests
   *
   * @throws Exception
   *           Exception to be thrown in case of failure
   */
  @Before
  public void setUp() throws Exception
  {
    _configFileManager = new ConfigFileManager("."); //$NON-NLS-1$
    GsonTools.getGsonTools().init("src/test/resources/ravelJsonConf.xml"); //$NON-NLS-1$

    // on réinitialise tous les mocks afin de ne pas avoir d'interférence entre les tests
    PowerMock.resetAll();

    Map<String, String> map = new HashMap<>();
    map.put(SERVICE_COM_CACHE_DURATION, "P0D"); //$NON-NLS-1$
    ProcessManager.getInstance().getProcessParams().put(StringConstants.EMPTY_STRING, map);

    // On initialise toutes les classes à mocker comportant un appel à une méthode statique
    // Dans notre cas on mock statiquemement toutes les classes des activités et des proxys appelés (pour les createContexte et le getInstance)

    PowerMock.mockStatic(Validation.class);
    PowerMock.mockStaticStrict(CMDProxy.class);
    PowerMock.mockStaticStrict(REXProxy.class);
    PowerMock.mockStaticStrict(AIRProxy.class);

    //_processManagerMock = PowerMock.createMock(ProcessManager.class);
    _validationMock = PowerMock.createMock(Validator.class);
    _validationFactoryMock = PowerMock.createMock(ValidatorFactory.class);

    _request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    final RequestHeader requestHeader4 = new RequestHeader();
    requestHeader4.setName(IHttpHeadersConsts.X_REQUEST_ID);
    requestHeader4.setValue("123415151515151"); //$NON-NLS-1$
    _request.getRequestHeader().add(requestHeader4);

    final RequestHeader requestHeader3 = new RequestHeader();
    requestHeader3.setName(IHttpHeadersConsts.X_SOURCE);
    requestHeader3.setValue("B2000"); //$NON-NLS-1$
    _request.getRequestHeader().add(requestHeader3);

    final RequestHeader requestHeader2 = new RequestHeader();
    requestHeader2.setName(IHttpHeadersConsts.X_PROCESS);
    requestHeader2.setValue("Photo New Sync Fai"); //$NON-NLS-1$
    _request.getRequestHeader().add(requestHeader2);

    _pfiGenerator = new PFIFullForTest();
  }

  /**
   * Scenario: BL001 failed to invalid header<br>
   * <b>Input:</b> "X-Client-Operateur" not set in headers<br>
   * <b>Result:</b> Echec du traitement suite à donnée incorrecte dans la demande WS ProvisionnerPfi reçue
   *
   * @throws Throwable
   *           On unexpected error
   */
  @Test
  public void testPEI0018_CommandePFI_001() throws Throwable
  {
    _request.setPayload(null);

    final Reponse erreur = new Reponse();
    erreur.setError("ENTREE_INCORRECTE"); //$NON-NLS-1$
    erreur.setErrorDescription(Messages.getString("PEI0018_CommandePFI.BL001_ControlerDonneesEntreeDonneeIncoherente")); //$NON-NLS-1$
    erreur.setErrorParameters(new ArrayList<>());

    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    response.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(erreur));
    final Response expected = new Response(ErrorCode.KO_00400, response);

    try
    {
      _processInstance = new PEI0018_CommandePfi();

      // On enregistre le scénario des appels avant de lancer le test
      PowerMock.replayAll();

      _processInstance.initializeContext();
      _processInstance.run(_request);
      _processInstance.continueProcess(null, null);
    }
    catch (final RavelException actual)
    {
      fail("Should not append"); //$NON-NLS-1$
    }
    finally
    {
      // On demande à PowerMock de vérifier la stack d'appel en fonction du scénariob
      PowerMock.verifyAll();

      assertEquals(expected.getMarshalledResponseJson(), _request.getResponse().getMarshalledResponseJson());
    }
  }

  /**
   * Scenario: BL001 failed due to invalidation payload <br>
   * <b>Input:</b> payload is set to null <br>
   * <b>Result:</b> Error HTTP 400 : Echec du traitement suite à donnée incorrecte dans la demande WS ProvisionnerPfi
   * reçue<br>
   *
   * @throws Throwable
   *           On unexpected error
   */
  @Test
  public void testPEI0018_CommandePFI_002() throws Throwable
  {
    final RequestHeader requestHeader1 = new RequestHeader();
    requestHeader1.setName(IHttpHeadersConsts.X_CLIENT_OPERATEUR);
    requestHeader1.setValue(""); //$NON-NLS-1$
    _request.getRequestHeader().add(requestHeader1);
    _request.setPayload(null);

    final Reponse erreur = new Reponse();
    erreur.setError("ENTREE_INCORRECTE"); //$NON-NLS-1$
    erreur.setErrorDescription(Messages.getString("PEI0018_CommandePFI.BL001_ControlerDonneesEntreeDonneeIncoherente")); //$NON-NLS-1$
    erreur.setErrorParameters(new ArrayList<>());

    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    response.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(erreur));
    final Response expected = new Response(ErrorCode.KO_00400, response);

    try
    {
      _processInstance = new PEI0018_CommandePfi();

      // On enregistre le scénario des appels avant de lancer le test
      PowerMock.replayAll();

      _processInstance.initializeContext();
      _processInstance.run(_request);
      _processInstance.continueProcess(null, null);
    }
    catch (final RavelException actual)
    {
      fail("Should not append"); //$NON-NLS-1$
    }
    finally
    {
      // On demande à PowerMock de vérifier la stack d'appel en fonction du scénariob
      PowerMock.verifyAll();

      assertEquals(expected.getMarshalledResponseJson(), _request.getResponse().getMarshalledResponseJson());
    }
  }

  /**
   * Scenario: BL100 failed due to invalid <br>
   * <b>Input:</b> "X-Client-Operateur" is blank <br>
   * <b>Result:</b> Error HTTP 400 : Echec du traitement suite à donnée incorrecte dans la demande WS ProvisionnerPfi
   * reçue <br>
   *
   * @throws Throwable
   *           On unexpected error
   */
  @Test
  public void testPEI0018_CommandePFI_003() throws Throwable
  {
    final PhotoPfi infosPfi = new PhotoPfi();
    infosPfi.setTimestamp(LocalDateTime.now());

    final RequestHeader requestHeader1 = new RequestHeader();
    requestHeader1.setName(IHttpHeadersConsts.X_CLIENT_OPERATEUR);
    requestHeader1.setValue(StringConstants.EMPTY_STRING);
    _request.getRequestHeader().add(requestHeader1);
    _request.setPayload(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(new PhotoPfiRequest(infosPfi)));

    final Reponse erreur = new Reponse();
    erreur.setError("ENTREE_INCORRECTE"); //$NON-NLS-1$
    erreur.setErrorDescription(Messages.getString("PEI0018_CommandePFI.BL001_ControlerDonneesEntreeDonneeIncoherente")); //$NON-NLS-1$
    erreur.setErrorParameters(new ArrayList<>());

    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    response.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(erreur));
    final Response expected = new Response(ErrorCode.KO_00400, response);

    try
    {
      _processInstance = new PEI0018_CommandePfi();

      // On enregistre le scénario des appels avant de lancer le test
      PowerMock.replayAll();

      _processInstance.initializeContext();
      _processInstance.run(_request);
      _processInstance.continueProcess(_request, null);
    }
    catch (final RavelException actual)
    {
      fail("Should not append"); //$NON-NLS-1$
    }
    finally
    {
      // On demande à PowerMock de vérifier la stack d'appel en fonction du scénariob
      PowerMock.verifyAll();

      assertEquals(expected.getMarshalledResponseJson(), _request.getResponse().getMarshalledResponseJson());
    }
  }

  /**
   * Scenario: BL100 failed due to wrong PorfeuilleServices <br>
   *
   * <b>Input:</b> PorfeuilleServices is present into object PhotoPfi but without noCompte <br/>
   * <b>Result:</b> Error HTTP 400 : Echec du traitement suite à donnée incorrecte dans la demande WS ProvisionnerPfi
   * reçue <br/>
   *
   * @throws Throwable
   *           On unexpected error
   */
  @Test
  public void testPEI0018_CommandePFI_006() throws Throwable
  {
    final PhotoPfi infosPfi = new PhotoPfi();
    infosPfi.setTimestamp(LocalDateTime.now());
    infosPfi.setPortefeuilleServices(new com.bytel.spirit.prof.shared.types.json.sti0017.PortefeuilleServices());

    final PhotoPfiRequest request = new PhotoPfiRequest();
    request.setPotoPfi(infosPfi);

    final Set<ConstraintViolation<PhotoPfi>> constraintViolations = new HashSet<>();
    final RequestHeader requestHeader1 = new RequestHeader();
    requestHeader1.setName(IHttpHeadersConsts.X_CLIENT_OPERATEUR);
    requestHeader1.setValue("BSS_GP"); //$NON-NLS-1$
    _request.getRequestHeader().add(requestHeader1);
    _request.setPayload(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(request));

    final Reponse erreur = new Reponse();
    erreur.setError("ENTREE_INCORRECTE"); //$NON-NLS-1$
    erreur.setErrorDescription(Messages.getString("PEI0018_CommandePFI.BL001_ControlerDonneesEntreeDonneeIncoherente")); //$NON-NLS-1$
    erreur.setErrorParameters(new ArrayList<>());

    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    response.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(erreur));
    final Response expected = new Response(ErrorCode.KO_00400, response);

    try
    {
      _processInstance = new PEI0018_CommandePfi();

      EasyMock.expect(Validation.buildDefaultValidatorFactory()).andReturn(_validationFactoryMock);
      EasyMock.expect(_validationFactoryMock.getValidator()).andReturn(_validationMock);
      EasyMock.expect(_validationMock.validate(EasyMock.anyObject(PhotoPfi.class))).andReturn(constraintViolations);
      _validationFactoryMock.close();
      PowerMock.expectLastCall().andVoid();

      // On enregistre le scénario des appels avant de lancer le test
      PowerMock.replayAll();

      _processInstance.initializeContext();
      _processInstance.run(_request);
      _processInstance.continueProcess(_request, null);
    }
    catch (final RavelException actual)
    {
      fail("Should not append"); //$NON-NLS-1$
    }
    finally
    {
      // On demande à PowerMock de vérifier la stack d'appel en fonction du scénariob
      PowerMock.verifyAll();

      assertEquals(expected.getMarshalledResponseJson(), _request.getResponse().getMarshalledResponseJson());
    }
  }

  /**
   * Scenario: CMD002 failed <br>
   * <b>Input:</b> Unable to call CMD002_CreerCommande <br>
   * <b>Result:</b> Error HTTP 400 : ERREUR_INTERNE
   *
   * @throws Throwable
   *           On unexpected error
   */
  @Test
  public void testPEI0018_CommandePFI_007() throws Throwable
  {
    final PhotoPfi infosPfi = new PhotoPfi();
    infosPfi.setTimestamp(LocalDateTime.now());
    final com.bytel.spirit.prof.shared.types.json.sti0017.PortefeuilleServices portefeuilleServices = new com.bytel.spirit.prof.shared.types.json.sti0017.PortefeuilleServices();
    portefeuilleServices.setNoCompte(RandomStringUtils.random(20));
    infosPfi.setPortefeuilleServices(portefeuilleServices);

    final PhotoPfiRequest request = new PhotoPfiRequest();
    request.setPotoPfi(infosPfi);

    final RequestHeader xClientOperateur = new RequestHeader();
    xClientOperateur.setName(IHttpHeadersConsts.X_CLIENT_OPERATEUR);
    xClientOperateur.setValue("BSS_GP"); //$NON-NLS-1$
    _request.getRequestHeader().add(xClientOperateur);
    _request.setPayload(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(request));

    final Set<ConstraintViolation<PhotoPfi>> constraintViolations = new HashSet<>();

    final Reponse erreur = new Reponse();
    erreur.setError("ERREUR_INTERNE"); //$NON-NLS-1$
    erreur.setErrorDescription(""); //$NON-NLS-1$

    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    response.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(erreur));
    final Response expected = new Response(ErrorCode.KO_00400, response);

    try
    {
      _processInstance = new PEI0018_CommandePfi();

      EasyMock.expect(Validation.buildDefaultValidatorFactory()).andReturn(_validationFactoryMock);
      EasyMock.expect(_validationFactoryMock.getValidator()).andReturn(_validationMock);
      EasyMock.expect(_validationMock.validate(EasyMock.anyObject(PhotoPfi.class))).andReturn(constraintViolations);
      _validationFactoryMock.close();
      PowerMock.expectLastCall().andVoid();

      EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdProxy);
      ConnectorResponse<Retour, Nothing> expectedReturn = new ConnectorResponse<>(RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, StringConstants.EMPTY_STRING, null), null);
      EasyMock.expect(_cmdProxy.commandeCreer(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(CreateCommandeRequest.class))).andReturn(expectedReturn);

      /* Mock BL800*/
      PowerMock.expectNew(BL800_ObtenirSequenceBuilder.class).andReturn(_bl800BuilderMock);
      EasyMock.expect(_bl800BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl800BuilderMock);
      EasyMock.expect(_bl800BuilderMock.code(EasyMock.eq(UniqueIdConstant.ID_CMD_GP))).andReturn(_bl800BuilderMock);
      EasyMock.expect(_bl800BuilderMock.build()).andReturn(_bl800Mock);
      String sequence = UUID.randomUUID().toString();
      EasyMock.expect(_bl800Mock.execute(EasyMock.anyObject(PEI0018_CommandePfi.class))).andReturn(sequence);
      EasyMock.expect(_bl800Mock.getRetour()).andReturn(RetourFactoryForTU.createOkRetour()).anyTimes();

      /* Mock BL800*/
      for (com.bytel.spirit.prof.shared.types.json.sti0017.ServiceAccessible serviceAccessible : portefeuilleServices.getServicesAccessibles())
      {
        PowerMock.expectNew(BL200_ObtenirServiceCommercialBuilder.class).andReturn(_bl200BuilderMock);
        EasyMock.expect(_bl200BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl200BuilderMock);
        EasyMock.expect(_bl200BuilderMock.clientOperateur("BSS_GP")).andReturn(_bl200BuilderMock); //$NON-NLS-1$
        EasyMock.expect(_bl200BuilderMock.noServiceCommercial(serviceAccessible.getNoServiceCommercial())).andReturn(_bl200BuilderMock);
        EasyMock.expect(_bl200BuilderMock.build()).andReturn(_bl200Mock);
        EasyMock.expect(_bl200Mock.execute(EasyMock.anyObject(PEI0018_CommandePfi.class))).andReturn(__podam.manufacturePojo(CatalogServiceCommercial.class));
        EasyMock.expect(_bl200Mock.getRetour()).andReturn(RetourFactoryForTU.createOkRetour()).anyTimes();
      }

      // On enregistre le scénario des appels avant de lancer le test
      PowerMock.replayAll();

      _processInstance.initializeContext();
      _processInstance.run(_request);
      _processInstance.continueProcess(_request, null);
    }
    catch (final RavelException actual)
    {
      fail("Should not append"); //$NON-NLS-1$
    }
    finally
    {
      // On demande à PowerMock de vérifier la stack d'appel en fonction du scénariob
      PowerMock.verifyAll();

      assertEquals(expected.getMarshalledResponseJson(), _request.getResponse().getMarshalledResponseJson());
    }
  }

  /**
   * Scenario: CMD002 passed <br>
   * Input: <br>
   * Result: Error HTTP 400
   *
   * @throws Throwable
   *           On unexpected error
   */
  @Test
  public void testPEI0018_CommandePFI_008() throws Throwable
  {
    final com.bytel.spirit.prof.shared.types.json.sti0017.PortefeuilleServices portefeuilleServices = new com.bytel.spirit.prof.shared.types.json.sti0017.PortefeuilleServices();
    portefeuilleServices.setNoCompte(RandomStringUtils.random(20));

    final DemandePhoto demandePhoto = new DemandePhoto("123456789", "987654321"); //$NON-NLS-1$ //$NON-NLS-2$

    final PhotoPfi infosPfi = new PhotoPfi();
    infosPfi.setTimestamp(LocalDateTime.now());
    infosPfi.setDemandePhoto(demandePhoto);
    infosPfi.setPortefeuilleServices(portefeuilleServices);

    final PhotoPfiRequest request = new PhotoPfiRequest();
    request.setPotoPfi(infosPfi);

    final Set<ConstraintViolation<PhotoPfi>> constraintViolations = new HashSet<>();
    final RequestHeader requestHeader1 = new RequestHeader();
    requestHeader1.setName(IHttpHeadersConsts.X_CLIENT_OPERATEUR);
    requestHeader1.setValue("BSS_GP"); //$NON-NLS-1$
    _request.getRequestHeader().add(requestHeader1);
    _request.setPayload(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(request));

    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setResult("{}"); //$NON-NLS-1$
    final Response expected = new Response(ErrorCode.OK_00200, response);

    try
    {
      _processInstance = new PEI0018_CommandePfi();

      EasyMock.expect(Validation.buildDefaultValidatorFactory()).andReturn(_validationFactoryMock);
      EasyMock.expect(_validationFactoryMock.getValidator()).andReturn(_validationMock);
      EasyMock.expect(_validationMock.validate(EasyMock.anyObject(PhotoPfi.class))).andReturn(constraintViolations);
      _validationFactoryMock.close();
      PowerMock.expectLastCall().andVoid();

      /* Mock BL800*/
      PowerMock.expectNew(BL800_ObtenirSequenceBuilder.class).andReturn(_bl800BuilderMock);
      EasyMock.expect(_bl800BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl800BuilderMock);
      EasyMock.expect(_bl800BuilderMock.code(EasyMock.eq(UniqueIdConstant.ID_CMD_GP))).andReturn(_bl800BuilderMock);
      EasyMock.expect(_bl800BuilderMock.build()).andReturn(_bl800Mock);
      EasyMock.expect(_bl800Mock.execute(EasyMock.anyObject(PEI0018_CommandePfi.class))).andReturn(UUID.randomUUID().toString());
      EasyMock.expect(_bl800Mock.getRetour()).andReturn(RetourFactoryForTU.createOkRetour()).anyTimes();

      /* Mock for CMD002 */
      EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdProxy).once();
      EasyMock.expect(_cmdProxy.commandeCreer(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(CreateCommandeRequest.class))).andReturn(new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), null));

      /* Mock for REX005 */
      final ReconciliationCommerciale reconcilCo = __podam.manufacturePojoWithFullData(ReconciliationCommerciale.class);
      reconcilCo.setIdTraitementMasse(null);

      EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxy).once();
      EasyMock.expect(_rexProxy.reconciliationCommercialeLireTousParIdReconciliation(EasyMock.anyObject(Tracabilite.class), EasyMock.anyString())).andReturn(new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), Arrays.asList(reconcilCo)));

      //EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxy).once();
      //EasyMock.expect(_rexProxy.reconciliationCommercialeEnMasseAcquitterUn(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(ManageReconciliationCommercialeEnMasseRequest.class))).andReturn(new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), null));

      /* Mock for REX006 */
      EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxy).once();
      EasyMock.expect(_rexProxy.reconciliationCommercialeModifier(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(CreateOrUpdateReconciliationCommercialeRequest.class))).andReturn(new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), null));

      /* Mock PROV_SI001 */
      PowerMock.expectNew(PROV_SI001_LancerOrchestrateurBuilder.class).andReturn(_provSI001BuilderMock);
      EasyMock.expect(_provSI001BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_provSI001BuilderMock);
      EasyMock.expect(_provSI001BuilderMock.cles(Arrays.asList("BSS_GP" + portefeuilleServices.getNoCompte()))).andReturn(_provSI001BuilderMock); //$NON-NLS-1$
      EasyMock.expect(_provSI001BuilderMock.priorite(10)).andReturn(_provSI001BuilderMock);
      EasyMock.expect(_provSI001BuilderMock.type(IMegSpiritConsts.CONTINUER_PROCESSUS)).andReturn(_provSI001BuilderMock);
      EasyMock.expect(_provSI001BuilderMock.processus("PEP0018_CommandePfi")).andReturn(_provSI001BuilderMock); //$NON-NLS-1$
      EasyMock.expect(_provSI001BuilderMock.noms(EasyMock.anyObject())).andReturn(_provSI001BuilderMock);
      EasyMock.expect(_provSI001BuilderMock.valeurs(EasyMock.anyObject())).andReturn(_provSI001BuilderMock);
      EasyMock.expect(_provSI001BuilderMock.build()).andReturn(_provSI001Mock);
      EasyMock.expect(_provSI001Mock.execute(EasyMock.anyObject(PEI0018_CommandePfi.class))).andReturn(__podam.manufacturePojoWithFullData(ResponseConnector.class));
      EasyMock.expect(_provSI001Mock.getRetour()).andReturn(RetourFactoryForTU.createOkRetour());

      // On enregistre le scénario des appels avant de lancer le test
      PowerMock.replayAll();

      _processInstance.initializeContext();
      _processInstance.run(_request);
      _processInstance.continueProcess(_request, null);
    }
    catch (final RavelException actual)
    {
      fail("Should not append"); //$NON-NLS-1$
    }
    finally
    {
      // On demande à PowerMock de vérifier la stack d'appel en fonction du scénariob
      PowerMock.verifyAll();

      assertEquals(expected.getMarshalledResponseJson(), _request.getResponse().getMarshalledResponseJson());
    }
  }

  /**
   * Scenario: OK with portefeuilleservices without declenchementPEP<br>
   * Input: <br>
   * Result: OK
   *
   * @throws Throwable
   *           On unexpected error
   */
  @Test
  public void testPEI0018_CommandePFI_010() throws Throwable
  {
    HashMap<String, String> map = new HashMap<>();
    map.put("declenchementPEP", "false"); //$NON-NLS-1$ //$NON-NLS-2$
    map.put(SERVICE_COM_CACHE_DURATION, "P0D"); //$NON-NLS-1$

    ConcurrentHashMap<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();

    processParams.put(StringConstants.EMPTY_STRING, map);

    PhotoPfi infosPfi = __podam.manufacturePojo(PhotoPfi.class); //PhotoPFI to put in donnes Brut of command
    infosPfi.getPortefeuilleServices().setStatut(Statut.ACTIF.name());

    //Init the catalogServiceCommercial for the list
    CatalogServiceCommercial catalogServiceCommercial = __podam.manufacturePojo(CatalogServiceCommercial.class);
    catalogServiceCommercial.setClientOperateur(_pfiGenerator.getCommande().getClientOperateur());
    catalogServiceCommercial.setNoServiceCommercial(_pfiGenerator.getNoServiceCommercialConnu());
    catalogServiceCommercial.setTypePA("VOIP"); //$NON-NLS-1$

    //initialize Statut of ServiceAccessible - workaround for Podam
    //The SA has the same noServiceCommercial as the catalogServiceCommercial so that it will be found on cache
    List<com.bytel.spirit.prof.shared.types.json.sti0017.ServiceAccessible> sAccessiblesList = new ArrayList<>();

    com.bytel.spirit.prof.shared.types.json.sti0017.ServiceAccessible sa = new com.bytel.spirit.prof.shared.types.json.sti0017.ServiceAccessible();
    sa.setNoServiceCommercial(catalogServiceCommercial.getNoServiceCommercial());
    sa.setListeIdPointAcces(Arrays.asList(catalogServiceCommercial.getNoServiceCommercial()));
    sAccessiblesList.add(sa);

    infosPfi.getPortefeuilleServices().setServicesAccessibles(sAccessiblesList);

    List<com.bytel.spirit.prof.shared.types.abstracts.sti0017.AbstractPointAcces> pointsAcces = new ArrayList<>();

    com.bytel.spirit.prof.shared.types.abstracts.sti0017.AbstractPointAcces pAccesVoip = _pfiGenerator.buildPointAccesVoipPortageV1();
    pAccesVoip.setIdentifiantFonctionnelPA(catalogServiceCommercial.getNoServiceCommercial());
    pointsAcces.add(pAccesVoip);
    infosPfi.getPortefeuilleServices().setPointsAcces(pointsAcces);

    final PhotoPfiRequest request = new PhotoPfiRequest();
    request.setPotoPfi(infosPfi);

    final Set<ConstraintViolation<PhotoPfi>> constraintViolations = new HashSet<>();

    final RequestHeader xClientOperateur = new RequestHeader();
    xClientOperateur.setName(IHttpHeadersConsts.X_CLIENT_OPERATEUR);
    xClientOperateur.setValue(ClientOperateur.BSS_GP.name());
    _request.getRequestHeader().add(xClientOperateur);

    _request.setPayload(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(request));

    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setResult("{}"); //$NON-NLS-1$
    final Response expected = new Response(ErrorCode.OK_00200, response);

    try
    {
      _processInstance = new PEI0018_CommandePfi();

      EasyMock.expect(Validation.buildDefaultValidatorFactory()).andReturn(_validationFactoryMock);
      EasyMock.expect(_validationFactoryMock.getValidator()).andReturn(_validationMock);
      EasyMock.expect(_validationMock.validate(EasyMock.anyObject(PhotoPfi.class))).andReturn(constraintViolations);
      _validationFactoryMock.close();
      PowerMock.expectLastCall().andVoid();

      PowerMock.expectNew(BL200_ObtenirServiceCommercialBuilder.class).andReturn(_bl200BuilderMock);
      EasyMock.expect(_bl200BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl200BuilderMock);
      EasyMock.expect(_bl200BuilderMock.clientOperateur("BSS_GP")).andReturn(_bl200BuilderMock); //$NON-NLS-1$
      EasyMock.expect(_bl200BuilderMock.noServiceCommercial(catalogServiceCommercial.getNoServiceCommercial())).andReturn(_bl200BuilderMock);
      EasyMock.expect(_bl200BuilderMock.build()).andReturn(_bl200Mock);
      EasyMock.expect(_bl200Mock.execute(EasyMock.anyObject(PEI0018_CommandePfi.class))).andReturn(catalogServiceCommercial);
      EasyMock.expect(_bl200Mock.getRetour()).andReturn(RetourFactoryForTU.createOkRetour()).anyTimes();

      /* Mock for CMD002 */
      EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdProxy);
      ConnectorResponse<Retour, Nothing> expectedRetourn = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), null);
      EasyMock.expect(_cmdProxy.commandeCreer(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(CreateCommandeRequest.class))).andReturn(expectedRetourn);

      /* Mock BL800*/
      PowerMock.expectNew(BL800_ObtenirSequenceBuilder.class).andReturn(_bl800BuilderMock);
      EasyMock.expect(_bl800BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl800BuilderMock);
      EasyMock.expect(_bl800BuilderMock.code(EasyMock.eq(UniqueIdConstant.ID_CMD_GP))).andReturn(_bl800BuilderMock);
      EasyMock.expect(_bl800BuilderMock.build()).andReturn(_bl800Mock);
      EasyMock.expect(_bl800Mock.execute(EasyMock.anyObject(PEI0018_CommandePfi.class))).andReturn(UUID.randomUUID().toString());
      EasyMock.expect(_bl800Mock.getRetour()).andReturn(RetourFactoryForTU.createOkRetour()).anyTimes();

      /* Mock for REX005 */
      EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxy).once();
      EasyMock.expect(_rexProxy.reconciliationCommercialeLireTousParIdReconciliation(EasyMock.anyObject(Tracabilite.class), EasyMock.anyString())).andReturn(new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), Arrays.asList(__podam.manufacturePojoWithFullData(ReconciliationCommerciale.class))));
      EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxy).once();
      EasyMock.expect(_rexProxy.reconciliationCommercialeEnMasseAcquitterUn(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(ManageReconciliationCommercialeEnMasseRequest.class))).andReturn(new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), null));

      //Mock for REX006
      //EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxy).once();
      //EasyMock.expect(_rexProxy.reconciliationCommercialeModifier(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(CreateOrUpdateReconciliationCommercialeRequest.class))).andReturn(new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), null));

      // On enregistre le scénario des appels avant de lancer le test
      PowerMock.replayAll();

      _processInstance.initializeContext();
      _processInstance.run(_request);
      _processInstance.continueProcess(_request, null);
    }
    catch (final RavelException actual)
    {
      fail("Should not append"); //$NON-NLS-1$
    }
    finally
    {
      // On demande à PowerMock de vérifier la stack d'appel en fonction du scénariob
      PowerMock.verifyAll();

      assertEquals(expected.getMarshalledResponseJson(), _request.getResponse().getMarshalledResponseJson());
    }
  }

  /**
   *
   * Test BL101 KO<br>
   *
   * <b>Inputs: </b>Valid inputs. Case AIRConnector returns KO<br>
   * <b>Expected: </b> Retour{KO}
   *
   * @throws Throwable
   *           On unexpected error
   */
  @Test
  public void testPEI0018_CommandePFI_BL101_KO_001() throws Throwable
  {
    Tracabilite tracabilite = new Tracabilite();
    tracabilite.setNomProcessus(StringConstants.EMPTY_STRING);

    PhotoPfi infosPfi = __podam.manufacturePojo(PhotoPfi.class); //PhotoPFI to put in donnes Brut of command
    infosPfi.getPortefeuilleServices().setStatut(Statut.ACTIF.name());

    Retour retourExpected = RetourFactoryForTU.createOkRetour();

    //Init the catalogServiceCommercial for the list
    CatalogServiceCommercial catalogServiceCommercial = __podam.manufacturePojo(CatalogServiceCommercial.class);
    catalogServiceCommercial.setClientOperateur(_pfiGenerator.getCommande().getClientOperateur());
    catalogServiceCommercial.setNoServiceCommercial(_pfiGenerator.getNoServiceCommercialConnu());
    catalogServiceCommercial.setTypePA("COMPTE_ACCES"); //$NON-NLS-1$

    //initialize Statut of ServiceAccessible - workaround for Podam
    //The SA has the same noServiceCommercial as the catalogServiceCommercial so that it will be found on cache
    List<com.bytel.spirit.prof.shared.types.json.sti0017.ServiceAccessible> sAccessiblesList = new ArrayList<>();

    com.bytel.spirit.prof.shared.types.json.sti0017.ServiceAccessible sa = new com.bytel.spirit.prof.shared.types.json.sti0017.ServiceAccessible();
    sa.setNoServiceCommercial(catalogServiceCommercial.getNoServiceCommercial());
    sa.setListeIdPointAcces(Arrays.asList(catalogServiceCommercial.getNoServiceCommercial()));
    sAccessiblesList.add(sa);

    infosPfi.getPortefeuilleServices().setServicesAccessibles(sAccessiblesList);

    List<com.bytel.spirit.prof.shared.types.abstracts.sti0017.AbstractPointAcces> pointsAcces = new ArrayList<>();

    com.bytel.spirit.prof.shared.types.abstracts.sti0017.AbstractPointAcces pAccesVoip = _pfiGenerator.buildPointAccesCompteAccesV1();
    pAccesVoip.setIdentifiantFonctionnelPA(catalogServiceCommercial.getNoServiceCommercial());
    pAccesVoip.setStatut("ACTIF"); //$NON-NLS-1$
    pointsAcces.add(pAccesVoip);
    infosPfi.getPortefeuilleServices().setPointsAcces(pointsAcces);

    final PhotoPfiRequest request = new PhotoPfiRequest();
    request.setPotoPfi(infosPfi);

    //Init requestHeader
    final RequestHeader requestHeader1 = new RequestHeader();
    requestHeader1.setName(IHttpHeadersConsts.X_CLIENT_OPERATEUR);
    requestHeader1.setValue(ClientOperateur.BSS_GP.name());
    _request.getRequestHeader().add(requestHeader1);
    _request.setPayload(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(request));

    //Expected response
    final Reponse erreur = new Reponse();
    erreur.setError(IMegSpiritConsts.ERREUR_INTERNE);
    erreur.setErrorDescription(StringConstants.EMPTY_STRING);

    //Expected response
    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    response.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(erreur));
    final Response expected = new Response(ErrorCode.KO_00400, response);

    try
    {
      _processInstance = new PEI0018_CommandePfi();

      /* Mock for Validator */
      final Set<ConstraintViolation<CommandePfi>> constraintViolations = new HashSet<>();

      EasyMock.expect(Validation.buildDefaultValidatorFactory()).andReturn(_validationFactoryMock);
      EasyMock.expect(_validationFactoryMock.getValidator()).andReturn(_validationMock);
      EasyMock.expect(_validationMock.validate(EasyMock.anyObject(CommandePfi.class))).andReturn(constraintViolations);
      _validationFactoryMock.close();

      PowerMock.expectNew(BL200_ObtenirServiceCommercialBuilder.class).andReturn(_bl200BuilderMock);
      EasyMock.expect(_bl200BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl200BuilderMock);
      EasyMock.expect(_bl200BuilderMock.clientOperateur("BSS_GP")).andReturn(_bl200BuilderMock); //$NON-NLS-1$
      EasyMock.expect(_bl200BuilderMock.noServiceCommercial(EasyMock.anyObject(String.class))).andReturn(_bl200BuilderMock);
      EasyMock.expect(_bl200BuilderMock.build()).andReturn(_bl200Mock);
      EasyMock.expect(_bl200Mock.execute(EasyMock.anyObject(PEI0018_CommandePfi.class))).andReturn(catalogServiceCommercial);
      EasyMock.expect(_bl200Mock.getRetour()).andReturn(retourExpected);

      tracabilite.setIdCorrelationByTel("123415151515151"); //$NON-NLS-1$
      Map<String, String> refFonc = new HashMap<>();
      refFonc.put(IRefFoncConstants.CLI_OPE, catalogServiceCommercial.getClientOperateur());
      refFonc.put(IRefFoncConstants.NO_COMPTE, StringConstants.EMPTY_STRING);

      BL1700_AjouterRefFonc bl1700 = new BL1700_AjouterRefFonc.BL1700_AjouterRefFoncBuilder().tracabilite(tracabilite).refFonc(refFonc).build();
      bl1700.execute(_processInstance);

      /* Mock BL800*/
      PowerMock.expectNew(BL800_ObtenirSequenceBuilder.class).andReturn(_bl800BuilderMock);
      EasyMock.expect(_bl800BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl800BuilderMock);
      EasyMock.expect(_bl800BuilderMock.code(EasyMock.eq(UniqueIdConstant.ID_CMD_GP))).andReturn(_bl800BuilderMock);
      EasyMock.expect(_bl800BuilderMock.build()).andReturn(_bl800Mock);
      String sequence = UUID.randomUUID().toString();
      EasyMock.expect(_bl800Mock.execute(EasyMock.anyObject(PEI0018_CommandePfi.class))).andReturn(sequence);
      EasyMock.expect(_bl800Mock.getRetour()).andReturn(RetourFactoryForTU.createOkRetour()).anyTimes();

      /* Mock for AIRProxy */
      ConnectorResponse<Retour, List<IndexRecherchePfi>> airReponse = new ConnectorResponse<>(RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, StringConstants.EMPTY_STRING, "PEI0018_BL101_CalculerListeCleSequencement"), null); //$NON-NLS-1$
      EasyMock.expect(AIRProxy.getInstance()).andReturn(_airProxy);
      EasyMock.expect(_airProxy.indexRechercherPfiLireTousParCleRecherche(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(String.class), EasyMock.anyObject(String.class))).andReturn(airReponse);

      // On enregistre le scénario des appels avant de lancer le test
      PowerMock.replayAll();

      _processInstance.initializeContext();
      _processInstance.run(_request);
      _processInstance.continueProcess(_request, null);
    }
    catch (final RavelException actual)
    {
      fail("Should not append"); //$NON-NLS-1$
    }
    finally
    {
      // On demande à PowerMock de vérifier la stack d'appel en fonction du scénariob
      PowerMock.verifyAll();

      assertEquals(expected.getMarshalledResponseJson(), _request.getResponse().getMarshalledResponseJson());
    }
  }

  /**
   * Test BL101 OK<br>
   *
   * <b>Inputs: </b>Valid inputs. Case AIRConnector returns OK<br>
   * <b>Expected: </b> Retour{OK}
   *
   * @throws Throwable
   *           On unexpected error
   */
  @Test
  public void testPEI0018_CommandePFI_BL101_OK_001() throws Throwable
  {
    Tracabilite tracabilite = new Tracabilite();
    tracabilite.setNomProcessus(StringConstants.EMPTY_STRING);

    PhotoPfi infosPfi = __podam.manufacturePojo(PhotoPfi.class); //PhotoPFI to put in donnes Brut of command
    infosPfi.getPortefeuilleServices().setStatut(Statut.ACTIF.name());

    Retour retourExpected = RetourFactoryForTU.createOkRetour();

    //Init the catalogServiceCommercial for the list
    CatalogServiceCommercial catalogServiceCommercial = __podam.manufacturePojo(CatalogServiceCommercial.class);
    catalogServiceCommercial.setClientOperateur(_pfiGenerator.getCommande().getClientOperateur());
    catalogServiceCommercial.setNoServiceCommercial(_pfiGenerator.getNoServiceCommercialConnu());
    catalogServiceCommercial.setTypePA("COMPTE_ACCES"); //$NON-NLS-1$

    //initialize Statut of ServiceAccessible - workaround for Podam
    //The SA has the same noServiceCommercial as the catalogServiceCommercial so that it will be found on cache
    List<com.bytel.spirit.prof.shared.types.json.sti0017.ServiceAccessible> sAccessiblesList = new ArrayList<>();

    com.bytel.spirit.prof.shared.types.json.sti0017.ServiceAccessible sa = new com.bytel.spirit.prof.shared.types.json.sti0017.ServiceAccessible();
    sa.setNoServiceCommercial(catalogServiceCommercial.getNoServiceCommercial());
    sa.setListeIdPointAcces(Arrays.asList(catalogServiceCommercial.getNoServiceCommercial()));
    sAccessiblesList.add(sa);

    infosPfi.getPortefeuilleServices().setServicesAccessibles(sAccessiblesList);

    List<com.bytel.spirit.prof.shared.types.abstracts.sti0017.AbstractPointAcces> pointsAcces = new ArrayList<>();

    com.bytel.spirit.prof.shared.types.abstracts.sti0017.AbstractPointAcces pAccesVoip = _pfiGenerator.buildPointAccesCompteAccesV1();
    pAccesVoip.setIdentifiantFonctionnelPA(catalogServiceCommercial.getNoServiceCommercial());
    pAccesVoip.setStatut("ACTIF"); //$NON-NLS-1$
    pointsAcces.add(pAccesVoip);
    infosPfi.getPortefeuilleServices().setPointsAcces(pointsAcces);

    final PhotoPfiRequest request = new PhotoPfiRequest();
    request.setPotoPfi(infosPfi);

    //Init the indexRechercherPfi for the list returned by AIRConnector
    IndexRecherchePfi indexRecherchePfi = new IndexRecherchePfi("clientOperateurMock", "noCompteMock"); //$NON-NLS-1$ //$NON-NLS-2$
    List<IndexRecherchePfi> listeIndexRecherchePfi = new ArrayList<>();
    listeIndexRecherchePfi.add(indexRecherchePfi);

    //Init requestHeader
    final RequestHeader requestHeader1 = new RequestHeader();
    requestHeader1.setName(IHttpHeadersConsts.X_CLIENT_OPERATEUR);
    requestHeader1.setValue(ClientOperateur.BSS_GP.name());
    _request.getRequestHeader().add(requestHeader1);
    _request.setPayload(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(request));

    //Expected response
    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    //response.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    response.setResult("{}"); //$NON-NLS-1$
    final Response expected = new Response(ErrorCode.OK_00200, response);

    try
    {
      _processInstance = new PEI0018_CommandePfi();

      /* Mock for Validator */
      final Set<ConstraintViolation<CommandePfi>> constraintViolations = new HashSet<>();

      EasyMock.expect(Validation.buildDefaultValidatorFactory()).andReturn(_validationFactoryMock);
      EasyMock.expect(_validationFactoryMock.getValidator()).andReturn(_validationMock);
      EasyMock.expect(_validationMock.validate(EasyMock.anyObject(CommandePfi.class))).andReturn(constraintViolations);
      _validationFactoryMock.close();

      PowerMock.expectNew(BL200_ObtenirServiceCommercialBuilder.class).andReturn(_bl200BuilderMock);
      EasyMock.expect(_bl200BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl200BuilderMock);
      EasyMock.expect(_bl200BuilderMock.clientOperateur("BSS_GP")).andReturn(_bl200BuilderMock); //$NON-NLS-1$
      EasyMock.expect(_bl200BuilderMock.noServiceCommercial(EasyMock.anyObject(String.class))).andReturn(_bl200BuilderMock);
      EasyMock.expect(_bl200BuilderMock.build()).andReturn(_bl200Mock);
      EasyMock.expect(_bl200Mock.execute(EasyMock.anyObject(PEI0018_CommandePfi.class))).andReturn(catalogServiceCommercial);
      EasyMock.expect(_bl200Mock.getRetour()).andReturn(retourExpected);

      tracabilite.setIdCorrelationByTel("123415151515151"); //$NON-NLS-1$
      Map<String, String> refFonc = new HashMap<>();
      refFonc.put(IRefFoncConstants.CLI_OPE, catalogServiceCommercial.getClientOperateur());
      refFonc.put(IRefFoncConstants.NO_COMPTE, StringConstants.EMPTY_STRING);

      BL1700_AjouterRefFonc bl1700 = new BL1700_AjouterRefFonc.BL1700_AjouterRefFoncBuilder().tracabilite(tracabilite).refFonc(refFonc).build();
      bl1700.execute(_processInstance);

      /* Mock BL800 */
      PowerMock.expectNew(BL800_ObtenirSequenceBuilder.class).andReturn(_bl800BuilderMock);
      EasyMock.expect(_bl800BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl800BuilderMock);
      EasyMock.expect(_bl800BuilderMock.code(EasyMock.eq(UniqueIdConstant.ID_CMD_GP))).andReturn(_bl800BuilderMock);
      EasyMock.expect(_bl800BuilderMock.build()).andReturn(_bl800Mock);
      String sequence = UUID.randomUUID().toString();
      EasyMock.expect(_bl800Mock.execute(EasyMock.anyObject(PEI0018_CommandePfi.class))).andReturn(sequence);
      EasyMock.expect(_bl800Mock.getRetour()).andReturn(RetourFactoryForTU.createOkRetour()).anyTimes();

      /* Mock for AIRProxy */
      ConnectorResponse<Retour, List<IndexRecherchePfi>> airReponse = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), listeIndexRecherchePfi);
      EasyMock.expect(AIRProxy.getInstance()).andReturn(_airProxy);
      EasyMock.expect(_airProxy.indexRechercherPfiLireTousParCleRecherche(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(String.class), EasyMock.anyObject(String.class))).andReturn(airReponse);

      /* Mock for CMD002 */
      EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdProxy);
      ConnectorResponse<Retour, Nothing> expectedRetourn = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), null);
      EasyMock.expect(_cmdProxy.commandeCreer(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(CreateCommandeRequest.class))).andReturn(expectedRetourn);

      /* Mock for REX005 */
      EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxy).once();
      EasyMock.expect(_rexProxy.reconciliationCommercialeLireTousParIdReconciliation(EasyMock.anyObject(Tracabilite.class), EasyMock.anyString())).andReturn(new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), Arrays.asList(__podam.manufacturePojoWithFullData(ReconciliationCommerciale.class))));

      EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxy).once();
      EasyMock.expect(_rexProxy.reconciliationCommercialeEnMasseAcquitterUn(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(ManageReconciliationCommercialeEnMasseRequest.class))).andReturn(new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), null));

      /* Mock for REX006 */
      //EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxy).once();
      //EasyMock.expect(_rexProxy.reconciliationCommercialeModifier(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(CreateOrUpdateReconciliationCommercialeRequest.class))).andReturn(new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), null));

      // On enregistre le scénario des appels avant de lancer le test
      PowerMock.replayAll();

      _processInstance.initializeContext();
      _processInstance.run(_request);
      _processInstance.continueProcess(_request, null);
    }
    catch (final RavelException actual)
    {
      fail("Should not append"); //$NON-NLS-1$
    }
    finally
    {
      // On demande à PowerMock de vérifier la stack d'appel en fonction du scénariob
      PowerMock.verifyAll();

      assertEquals(expected.getMarshalledResponseJson(), _request.getResponse().getMarshalledResponseJson());
    }
  }

  /**
   * Scenario: BL001 failed due to invalidation data into payload<br>
   * <b>Input: </b> generated payload with a validation issue on field "_idDemandePhoto" <br>
   * <b>Expected: </b> Error HTTP 400<br>
   *
   * @throws Throwable
   *           On unexpected error
   */
  @Test
  public void testPEI0018_CommandePFI_InvalidData_001() throws Throwable
  {
    final PhotoPfi infosPfi = new PhotoPfi();
    infosPfi.setTimestamp(LocalDateTime.now());

    final PhotoPfiRequest request = new PhotoPfiRequest();
    request.setPotoPfi(infosPfi);

    final Set<ConstraintViolation<CommandePfi>> constraintViolations = new HashSet<>();
    constraintViolations.add(ConstraintViolationImpl.forBeanValidation(MANDATORY_ERROR, null, null, MANDATORY_ERROR, CommandePfi.class, new CommandePfi(), null, null, PathImpl.createPathFromString("_idDemandePhoto"), null, ElementType.FIELD, null)); //$NON-NLS-1$
    final RequestHeader requestHeader1 = new RequestHeader();
    requestHeader1.setName(IHttpHeadersConsts.X_CLIENT_OPERATEUR);
    requestHeader1.setValue("BSS_GP"); //$NON-NLS-1$
    _request.getRequestHeader().add(requestHeader1);
    _request.setPayload(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(request));

    final Reponse erreur = new Reponse();
    erreur.setError("ENTREE_INCORRECTE"); //$NON-NLS-1$
    erreur.setErrorDescription(MANDATORY_ERROR);
    erreur.setErrorParameters(Arrays.asList("_idDemandePhoto")); //$NON-NLS-1$

    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    response.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(erreur));
    final Response expected = new Response(ErrorCode.KO_00400, response);

    try
    {
      _processInstance = new PEI0018_CommandePfi();

      EasyMock.expect(Validation.buildDefaultValidatorFactory()).andReturn(_validationFactoryMock);
      EasyMock.expect(_validationFactoryMock.getValidator()).andReturn(_validationMock);
      EasyMock.expect(_validationMock.validate(EasyMock.anyObject(CommandePfi.class))).andReturn(constraintViolations);
      _validationFactoryMock.close();
      PowerMock.expectLastCall().andVoid();

      // On enregistre le scénario des appels avant de lancer le test
      PowerMock.replayAll();

      _processInstance.initializeContext();
      _processInstance.run(_request);
      _processInstance.continueProcess(_request, null);
    }
    catch (final RavelException actual)
    {
      fail("Should not append"); //$NON-NLS-1$
    }
    finally
    {
      // On demande à PowerMock de vérifier la stack d'appel en fonction du scénariob
      PowerMock.verifyAll();

      assertEquals(expected.getMarshalledResponseJson(), _request.getResponse().getMarshalledResponseJson());
    }
  }

  /**
   * Scenario: BL001 failed due to invalidation data into payload<br>
   * <b>Input: </b>generated payload with a validation issue on field "_idDemandePhoto" ("Attribut conditionnel
   * manquant") <br>
   * <b>Expected: </b>Error HTTP 400 with IMegConsts.CAT3, IMegSpiritConsts.ENTREE_INCORRECTE, Attribut conditionnel
   * manquant<br>
   *
   * @throws Throwable
   *           On unexpected error
   */
  @Test
  public void testPEI0018_CommandePFI_InvalidData_002() throws Throwable
  {
    final PhotoPfi infosPfi = new PhotoPfi();
    infosPfi.setTimestamp(LocalDateTime.now());

    final PhotoPfiRequest request = new PhotoPfiRequest();
    request.setPotoPfi(infosPfi);

    final Set<ConstraintViolation<CommandePfi>> constraintViolations = new HashSet<>();
    constraintViolations.add(ConstraintViolationImpl.forBeanValidation(CONDITIONNAL_ERROR, null, null, CONDITIONNAL_ERROR, CommandePfi.class, new CommandePfi(), null, null, PathImpl.createPathFromString("_idDemandePhoto"), null, ElementType.FIELD, null)); //$NON-NLS-1$
    final RequestHeader requestHeader1 = new RequestHeader();
    requestHeader1.setName(IHttpHeadersConsts.X_CLIENT_OPERATEUR);
    requestHeader1.setValue("BSS_GP"); //$NON-NLS-1$
    _request.getRequestHeader().add(requestHeader1);
    _request.setPayload(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(request));

    final Reponse erreur = new Reponse();
    erreur.setError("ENTREE_INCORRECTE"); //$NON-NLS-1$
    erreur.setErrorDescription(CONDITIONNAL_ERROR);
    erreur.setErrorParameters(Arrays.asList("_idDemandePhoto")); //$NON-NLS-1$

    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    response.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(erreur));
    final Response expected = new Response(ErrorCode.KO_00400, response);

    try
    {
      _processInstance = new PEI0018_CommandePfi();

      EasyMock.expect(Validation.buildDefaultValidatorFactory()).andReturn(_validationFactoryMock);
      EasyMock.expect(_validationFactoryMock.getValidator()).andReturn(_validationMock);
      EasyMock.expect(_validationMock.validate(EasyMock.anyObject(CommandePfi.class))).andReturn(constraintViolations);
      _validationFactoryMock.close();
      PowerMock.expectLastCall().andVoid();

      // On enregistre le scénario des appels avant de lancer le test
      PowerMock.replayAll();

      _processInstance.initializeContext();
      _processInstance.run(_request);
      _processInstance.continueProcess(_request, null);
    }
    catch (final RavelException actual)
    {
      fail("Should not append"); //$NON-NLS-1$
    }
    finally
    {
      // On demande à PowerMock de vérifier la stack d'appel en fonction du scénariob
      PowerMock.verifyAll();

      assertEquals(expected.getMarshalledResponseJson(), _request.getResponse().getMarshalledResponseJson());
    }
  }

  /**
   * Scenario: BL001 failed due to invalidation data into payload<br>
   * <b>Input: </b>generated payload with a validation issue on field "_idDemandePhoto" ("Attribut conditionnel
   * inattendu") <br>
   * <b>Expected: </b>Error HTTP 400 with IMegConsts.CAT3, IMegSpiritConsts.ENTREE_INCORRECTE, Attribut conditionnel
   * inattendu<br>
   *
   * @throws Throwable
   *           On unexpected error
   */
  @Test
  public void testPEI0018_CommandePFI_InvalidData_003() throws Throwable
  {
    final PhotoPfi infosPfi = new PhotoPfi();
    infosPfi.setTimestamp(LocalDateTime.now());

    final PhotoPfiRequest request = new PhotoPfiRequest();
    request.setPotoPfi(infosPfi);

    final Set<ConstraintViolation<CommandePfi>> constraintViolations = new HashSet<>();
    constraintViolations.add(ConstraintViolationImpl.forBeanValidation(CONDITIONNAL_UNEXPECTED, null, null, CONDITIONNAL_UNEXPECTED, CommandePfi.class, new CommandePfi(), null, null, PathImpl.createPathFromString("_idDemandePhoto"), null, ElementType.FIELD, null)); //$NON-NLS-1$
    final RequestHeader requestHeader1 = new RequestHeader();
    requestHeader1.setName(IHttpHeadersConsts.X_CLIENT_OPERATEUR);
    requestHeader1.setValue("BSS_GP"); //$NON-NLS-1$
    _request.getRequestHeader().add(requestHeader1);
    _request.setPayload(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(request));

    final Reponse erreur = new Reponse();
    erreur.setError("ENTREE_INCORRECTE"); //$NON-NLS-1$
    erreur.setErrorDescription(CONDITIONNAL_UNEXPECTED);
    erreur.setErrorParameters(Arrays.asList("_idDemandePhoto")); //$NON-NLS-1$

    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    response.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(erreur));
    final Response expected = new Response(ErrorCode.KO_00400, response);

    try
    {
      _processInstance = new PEI0018_CommandePfi();

      EasyMock.expect(Validation.buildDefaultValidatorFactory()).andReturn(_validationFactoryMock);
      EasyMock.expect(_validationFactoryMock.getValidator()).andReturn(_validationMock);
      EasyMock.expect(_validationMock.validate(EasyMock.anyObject(CommandePfi.class))).andReturn(constraintViolations);
      _validationFactoryMock.close();
      PowerMock.expectLastCall().andVoid();

      // On enregistre le scénario des appels avant de lancer le test
      PowerMock.replayAll();

      _processInstance.initializeContext();
      _processInstance.run(_request);
      _processInstance.continueProcess(_request, null);
    }
    catch (final RavelException actual)
    {
      fail("Should not append"); //$NON-NLS-1$
    }
    finally
    {
      // On demande à PowerMock de vérifier la stack d'appel en fonction du scénariob
      PowerMock.verifyAll();

      assertEquals(expected.getMarshalledResponseJson(), _request.getResponse().getMarshalledResponseJson());
    }
  }

  /**
   * Scenario: BL001 failed due to invalidation data into payload<br>
   * <b>Input: </b>generated payload with a validation issue on field "_idDemandePhoto" ("Attribut conditionnel
   * inattendu") <br>
   * <b>Expected: </b>Error HTTP 400 with IMegConsts.CAT3, IMegSpiritConsts.ENTREE_INCORRECTE, Format d'attribut non
   * respecté
   *
   * @throws Throwable
   *           On unexpected error
   */
  @Test
  public void testPEI0018_CommandePFI_InvalidData_004() throws Throwable
  {
    final PhotoPfi infosPfi = new PhotoPfi();
    infosPfi.setTimestamp(LocalDateTime.now());

    final PhotoPfiRequest request = new PhotoPfiRequest();
    request.setPotoPfi(infosPfi);

    final Set<ConstraintViolation<CommandePfi>> constraintViolations = new HashSet<>();
    constraintViolations.add(ConstraintViolationImpl.forBeanValidation(FORMAT_NOT_RESPECTED, null, null, FORMAT_NOT_RESPECTED, CommandePfi.class, new CommandePfi(), null, null, PathImpl.createPathFromString("_idDemandePhoto"), null, ElementType.FIELD, null)); //$NON-NLS-1$
    final RequestHeader requestHeader1 = new RequestHeader();
    requestHeader1.setName(IHttpHeadersConsts.X_CLIENT_OPERATEUR);
    requestHeader1.setValue("BSS_GP"); //$NON-NLS-1$
    _request.getRequestHeader().add(requestHeader1);
    _request.setPayload(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(request));

    final Reponse erreur = new Reponse();
    erreur.setError("ENTREE_INCORRECTE"); //$NON-NLS-1$
    erreur.setErrorDescription(FORMAT_NOT_RESPECTED);
    erreur.setErrorParameters(Arrays.asList("_idDemandePhoto")); //$NON-NLS-1$

    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    response.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(erreur));
    final Response expected = new Response(ErrorCode.KO_00400, response);

    try
    {
      _processInstance = new PEI0018_CommandePfi();

      EasyMock.expect(Validation.buildDefaultValidatorFactory()).andReturn(_validationFactoryMock);
      EasyMock.expect(_validationFactoryMock.getValidator()).andReturn(_validationMock);
      EasyMock.expect(_validationMock.validate(EasyMock.anyObject(CommandePfi.class))).andReturn(constraintViolations);
      _validationFactoryMock.close();
      PowerMock.expectLastCall().andVoid();

      // On enregistre le scénario des appels avant de lancer le test
      PowerMock.replayAll();

      _processInstance.initializeContext();
      _processInstance.run(_request);
      _processInstance.continueProcess(_request, null);
    }
    catch (final RavelException actual)
    {
      fail("Should not append"); //$NON-NLS-1$
    }
    finally
    {
      // On demande à PowerMock de vérifier la stack d'appel en fonction du scénariob
      PowerMock.verifyAll();

      assertEquals(expected.getMarshalledResponseJson(), _request.getResponse().getMarshalledResponseJson());
    }
  }

  /**
   * Nominal case for {@link PEI0018_CommandePFI} <br>
   *
   * <b>Inputs: </b>Valid inputs. Case with noCompte not null<br>
   * <b>Expected: </b> Retour{OK}
   *
   * @throws Throwable
   *           On unexpected error
   */
  @Test
  public void testPEI0018_CommandePFI_NEW_OK_001() throws Throwable
  {
    Tracabilite tracabilite = new Tracabilite();
    tracabilite.setNomProcessus(StringConstants.EMPTY_STRING);

    PhotoPfi infosPfi = __podam.manufacturePojo(PhotoPfi.class); //PhotoPFI to put in donnes Brut of command
    infosPfi.getPortefeuilleServices().setStatut(Statut.ACTIF.name());

    Retour retourExpected = RetourFactoryForTU.createOkRetour();

    //Init the catalogServiceCommercial for the list
    CatalogServiceCommercial catalogServiceCommercial = __podam.manufacturePojo(CatalogServiceCommercial.class);
    catalogServiceCommercial.setClientOperateur(_pfiGenerator.getCommande().getClientOperateur());
    catalogServiceCommercial.setNoServiceCommercial(_pfiGenerator.getNoServiceCommercialConnu());
    catalogServiceCommercial.setTypePA("VOIP"); //$NON-NLS-1$

    /* Mock for Validator */
    final Set<ConstraintViolation<CommandePfi>> constraintViolations = new HashSet<>();

    EasyMock.expect(Validation.buildDefaultValidatorFactory()).andReturn(_validationFactoryMock);
    EasyMock.expect(_validationFactoryMock.getValidator()).andReturn(_validationMock);
    EasyMock.expect(_validationMock.validate(EasyMock.anyObject(CommandePfi.class))).andReturn(constraintViolations);
    _validationFactoryMock.close();

    PowerMock.expectNew(BL200_ObtenirServiceCommercialBuilder.class).andReturn(_bl200BuilderMock);
    EasyMock.expect(_bl200BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl200BuilderMock);
    EasyMock.expect(_bl200BuilderMock.clientOperateur(EasyMock.anyObject(String.class))).andReturn(_bl200BuilderMock);
    EasyMock.expect(_bl200BuilderMock.noServiceCommercial(EasyMock.anyObject(String.class))).andReturn(_bl200BuilderMock);
    EasyMock.expect(_bl200BuilderMock.build()).andReturn(_bl200Mock);
    EasyMock.expect(_bl200Mock.execute(EasyMock.anyObject(PEI0018_CommandePfi.class))).andReturn(catalogServiceCommercial);
    EasyMock.expect(_bl200Mock.getRetour()).andReturn(retourExpected);

    //initialize Statut of ServiceAccessible - workaround for Podam
    //The SA has the same noServiceCommercial as the catalogServiceCommercial so that it will be found on cache
    List<com.bytel.spirit.prof.shared.types.json.sti0017.ServiceAccessible> sAccessiblesList = new ArrayList<>();

    com.bytel.spirit.prof.shared.types.json.sti0017.ServiceAccessible sa = new com.bytel.spirit.prof.shared.types.json.sti0017.ServiceAccessible();
    sa.setNoServiceCommercial(catalogServiceCommercial.getNoServiceCommercial());
    sa.setListeIdPointAcces(Arrays.asList(catalogServiceCommercial.getNoServiceCommercial()));
    sAccessiblesList.add(sa);

    infosPfi.getPortefeuilleServices().setServicesAccessibles(sAccessiblesList);

    List<com.bytel.spirit.prof.shared.types.abstracts.sti0017.AbstractPointAcces> pointsAcces = new ArrayList<>();

    com.bytel.spirit.prof.shared.types.abstracts.sti0017.AbstractPointAcces pAccesVoip = _pfiGenerator.buildPointAccesVoipPortageV1();
    pAccesVoip.setIdentifiantFonctionnelPA(catalogServiceCommercial.getNoServiceCommercial());
    pointsAcces.add(pAccesVoip);
    infosPfi.getPortefeuilleServices().setPointsAcces(pointsAcces);

    CommandePfi commandepfi = CommandePFIUtils.transformPhotoPfi(infosPfi);
    commandepfi.setType(TypeCommand.CREATION);

    //Init requestHeader
    final RequestHeader requestHeader1 = new RequestHeader();
    requestHeader1.setName(IHttpHeadersConsts.X_CLIENT_OPERATEUR);
    requestHeader1.setValue(ClientOperateur.BSS_GP.name());
    _request.getRequestHeader().add(requestHeader1);
    _request.setPayload(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(commandepfi));
    _request.setOperation(COMMANDE_PFI);
    //Expected response
    String sequence = UUID.randomUUID().toString();
    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setResult("{\"commande_id\":\"" + sequence + "\"}"); //$NON-NLS-1$ //$NON-NLS-2$
    final Response expected = new Response(ErrorCode.OK_00200, response);

    try
    {
      _processInstance = new PEI0018_CommandePfi();

      tracabilite.setIdCorrelationByTel("123415151515151"); //$NON-NLS-1$
      Map<String, String> refFonc = new HashMap<>();
      refFonc.put(IRefFoncConstants.CLI_OPE, catalogServiceCommercial.getClientOperateur());
      refFonc.put(IRefFoncConstants.NO_COMPTE, StringConstants.EMPTY_STRING);

      BL1700_AjouterRefFonc bl1700 = new BL1700_AjouterRefFonc.BL1700_AjouterRefFoncBuilder().tracabilite(tracabilite).refFonc(refFonc).build();
      bl1700.execute(_processInstance);

      /* Mock BL800 */
      PowerMock.expectNew(BL800_ObtenirSequenceBuilder.class).andReturn(_bl800BuilderMock);
      EasyMock.expect(_bl800BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl800BuilderMock);
      EasyMock.expect(_bl800BuilderMock.code(EasyMock.eq(UniqueIdConstant.ID_CMD_GP))).andReturn(_bl800BuilderMock);
      EasyMock.expect(_bl800BuilderMock.build()).andReturn(_bl800Mock);
      EasyMock.expect(_bl800Mock.execute(EasyMock.anyObject(PEI0018_CommandePfi.class))).andReturn(sequence);
      EasyMock.expect(_bl800Mock.getRetour()).andReturn(RetourFactoryForTU.createOkRetour()).anyTimes();

      /*
      for (ServiceAccessible serviceAccessible : portefeuilleServices.getServicesAccessibles())
      {
        PowerMock.expectNew(BL200_ObtenirServiceCommercialBuilder.class).andReturn(_bl200BuilderMock);
        EasyMock.expect(_bl200BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl200BuilderMock);
        EasyMock.expect(_bl200BuilderMock.fraicheur(Duration.parse("PT0S"))).andReturn(_bl200BuilderMock); //$NON-NLS-1$
        EasyMock.expect(_bl200BuilderMock.clientOperateur("BSS_GP")).andReturn(_bl200BuilderMock); //$NON-NLS-1$
        EasyMock.expect(_bl200BuilderMock.noServiceCommercial(serviceAccessible.getNoServiceCommercial())).andReturn(_bl200BuilderMock);
        EasyMock.expect(_bl200BuilderMock.build()).andReturn(_bl200Mock);
        EasyMock.expect(_bl200Mock.execute(EasyMock.anyObject(PEI0018_CommandePfi.class))).andReturn(catalogServiceCommercial);
        EasyMock.expect(_bl200Mock.getRetour()).andReturn(RetourFactoryForTU.createOkRetour()).anyTimes();
      }
      */

      /* Mock for CMD002 */
      EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdProxy);
      ConnectorResponse<Retour, Nothing> expectedRetourn = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), null);
      EasyMock.expect(_cmdProxy.commandeCreer(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(CreateCommandeRequest.class))).andReturn(expectedRetourn);

      PowerMock.expectNew(PROV_SI001_LancerOrchestrateurBuilder.class).andReturn(_provSI001BuilderMock);
      EasyMock.expect(_provSI001BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_provSI001BuilderMock);
      EasyMock.expect(_provSI001BuilderMock.cles(EasyMock.anyObject())).andReturn(_provSI001BuilderMock);
      EasyMock.expect(_provSI001BuilderMock.priorite(10)).andReturn(_provSI001BuilderMock);
      EasyMock.expect(_provSI001BuilderMock.type(IMegSpiritConsts.CONTINUER_PROCESSUS)).andReturn(_provSI001BuilderMock);
      EasyMock.expect(_provSI001BuilderMock.processus("PEP0018_CommandePfi")).andReturn(_provSI001BuilderMock); //$NON-NLS-1$
      EasyMock.expect(_provSI001BuilderMock.noms(EasyMock.anyObject())).andReturn(_provSI001BuilderMock);
      EasyMock.expect(_provSI001BuilderMock.valeurs(EasyMock.anyObject())).andReturn(_provSI001BuilderMock);
      EasyMock.expect(_provSI001BuilderMock.build()).andReturn(_provSI001Mock);
      EasyMock.expect(_provSI001Mock.execute(EasyMock.anyObject(PEI0018_CommandePfi.class))).andReturn(__podam.manufacturePojoWithFullData(ResponseConnector.class));
      EasyMock.expect(_provSI001Mock.getRetour()).andReturn(RetourFactoryForTU.createOkRetour());

      /* Mock for REX005 */
      EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxy).once();
      EasyMock.expect(_rexProxy.reconciliationCommercialeLireTousParIdReconciliation(EasyMock.anyObject(Tracabilite.class), EasyMock.anyString())).andReturn(new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), Arrays.asList(__podam.manufacturePojoWithFullData(ReconciliationCommerciale.class))));

      EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxy).once();
      EasyMock.expect(_rexProxy.reconciliationCommercialeEnMasseAcquitterUn(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(ManageReconciliationCommercialeEnMasseRequest.class))).andReturn(new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), null));

      /* Mock for REX006 */
      //EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxy).once();
      //EasyMock.expect(_rexProxy.reconciliationCommercialeModifier(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(CreateOrUpdateReconciliationCommercialeRequest.class))).andReturn(new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), null));

      // On enregistre le scénario des appels avant de lancer le test
      PowerMock.replayAll();

      _processInstance.initializeContext();
      _processInstance.run(_request);
      _processInstance.continueProcess(_request, tracabilite);
    }
    catch (final RavelException actual)
    {
      fail("Should not append"); //$NON-NLS-1$
    }
    finally
    {
      // On demande à PowerMock de vérifier la stack d'appel en fonction du scénariob
      PowerMock.verifyAll();

      assertEquals(expected.getMarshalledResponseJson(), _request.getResponse().getMarshalledResponseJson());
    }
  }

  /**
   * Nominal case for {@link PEI0018_CommandePFI} <br>
   *
   * <b>Inputs: </b>Valid inputs. Case with noCompte not null<br>
   * <b>Expected: </b> Retour{OK}
   *
   * @throws Throwable
   *           On unexpected error
   */
  @Test
  public void testPEI0018_CommandePFI_OK_001() throws Throwable
  {
    Tracabilite tracabilite = new Tracabilite();
    tracabilite.setNomProcessus(StringConstants.EMPTY_STRING);

    PhotoPfi infosPfi = __podam.manufacturePojo(PhotoPfi.class); //PhotoPFI to put in donnes Brut of command
    infosPfi.getPortefeuilleServices().setStatut(Statut.ACTIF.name());

    //Init the catalogServiceCommercial for the list
    CatalogServiceCommercial catalogServiceCommercial = __podam.manufacturePojo(CatalogServiceCommercial.class);
    catalogServiceCommercial.setClientOperateur(_pfiGenerator.getCommande().getClientOperateur());
    catalogServiceCommercial.setNoServiceCommercial(_pfiGenerator.getNoServiceCommercialConnu());
    catalogServiceCommercial.setTypePA("VOIP"); //$NON-NLS-1$

    //initialize Statut of ServiceAccessible - workaround for Podam
    //The SA has the same noServiceCommercial as the catalogServiceCommercial so that it will be found on cache
    List<com.bytel.spirit.prof.shared.types.json.sti0017.ServiceAccessible> sAccessiblesList = new ArrayList<>();

    com.bytel.spirit.prof.shared.types.json.sti0017.ServiceAccessible sa = new com.bytel.spirit.prof.shared.types.json.sti0017.ServiceAccessible();
    sa.setNoServiceCommercial(catalogServiceCommercial.getNoServiceCommercial());
    sa.setListeIdPointAcces(Arrays.asList(catalogServiceCommercial.getNoServiceCommercial()));
    sAccessiblesList.add(sa);

    infosPfi.getPortefeuilleServices().setServicesAccessibles(sAccessiblesList);

    List<com.bytel.spirit.prof.shared.types.abstracts.sti0017.AbstractPointAcces> pointsAcces = new ArrayList<>();

    com.bytel.spirit.prof.shared.types.abstracts.sti0017.AbstractPointAcces pAccesVoip = _pfiGenerator.buildPointAccesVoipPortageV1();
    pAccesVoip.setIdentifiantFonctionnelPA(catalogServiceCommercial.getNoServiceCommercial());
    pointsAcces.add(pAccesVoip);
    infosPfi.getPortefeuilleServices().setPointsAcces(pointsAcces);

    final PhotoPfiRequest request = new PhotoPfiRequest();
    request.setPotoPfi(infosPfi);

    //Init requestHeader
    final RequestHeader requestHeader1 = new RequestHeader();
    requestHeader1.setName(IHttpHeadersConsts.X_CLIENT_OPERATEUR);
    requestHeader1.setValue(ClientOperateur.BSS_GP.name());
    _request.getRequestHeader().add(requestHeader1);
    _request.setPayload(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(request));

    //Expected response
    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setResult("{}"); //$NON-NLS-1$
    final Response expected = new Response(ErrorCode.OK_00200, response);

    try
    {
      _processInstance = new PEI0018_CommandePfi();

      /* Mock for Validator */
      final Set<ConstraintViolation<CommandePfi>> constraintViolations = new HashSet<>();

      EasyMock.expect(Validation.buildDefaultValidatorFactory()).andReturn(_validationFactoryMock);
      EasyMock.expect(_validationFactoryMock.getValidator()).andReturn(_validationMock);
      EasyMock.expect(_validationMock.validate(EasyMock.anyObject(CommandePfi.class))).andReturn(constraintViolations);
      _validationFactoryMock.close();

      tracabilite.setIdCorrelationByTel("123415151515151"); //$NON-NLS-1$
      Map<String, String> refFonc = new HashMap<>();
      refFonc.put(IRefFoncConstants.CLI_OPE, catalogServiceCommercial.getClientOperateur());
      refFonc.put(IRefFoncConstants.NO_COMPTE, StringConstants.EMPTY_STRING);

      BL1700_AjouterRefFonc bl1700 = new BL1700_AjouterRefFonc.BL1700_AjouterRefFoncBuilder().tracabilite(tracabilite).refFonc(refFonc).build();
      bl1700.execute(_processInstance);

      /* Mock BL800*/
      PowerMock.expectNew(BL800_ObtenirSequenceBuilder.class).andReturn(_bl800BuilderMock);
      EasyMock.expect(_bl800BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl800BuilderMock);
      EasyMock.expect(_bl800BuilderMock.code(EasyMock.eq(UniqueIdConstant.ID_CMD_GP))).andReturn(_bl800BuilderMock);
      EasyMock.expect(_bl800BuilderMock.build()).andReturn(_bl800Mock);
      EasyMock.expect(_bl800Mock.execute(EasyMock.anyObject(PEI0018_CommandePfi.class))).andReturn(UUID.randomUUID().toString());
      EasyMock.expect(_bl800Mock.getRetour()).andReturn(RetourFactoryForTU.createOkRetour()).anyTimes();

      for (com.bytel.spirit.prof.shared.types.json.sti0017.ServiceAccessible serviceAccessible : infosPfi.getPortefeuilleServices().getServicesAccessibles())
      {
        PowerMock.expectNew(BL200_ObtenirServiceCommercialBuilder.class).andReturn(_bl200BuilderMock);
        EasyMock.expect(_bl200BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl200BuilderMock);
        EasyMock.expect(_bl200BuilderMock.clientOperateur("BSS_GP")).andReturn(_bl200BuilderMock); //$NON-NLS-1$
        EasyMock.expect(_bl200BuilderMock.noServiceCommercial(serviceAccessible.getNoServiceCommercial())).andReturn(_bl200BuilderMock);
        EasyMock.expect(_bl200BuilderMock.build()).andReturn(_bl200Mock);
        EasyMock.expect(_bl200Mock.execute(EasyMock.anyObject(PEI0018_CommandePfi.class))).andReturn(catalogServiceCommercial);
        EasyMock.expect(_bl200Mock.getRetour()).andReturn(RetourFactoryForTU.createOkRetour()).anyTimes();
      }

      /* Mock for CMD002 */
      EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdProxy);
      ConnectorResponse<Retour, Nothing> expectedRetourn = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), null);
      EasyMock.expect(_cmdProxy.commandeCreer(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(CreateCommandeRequest.class))).andReturn(expectedRetourn);

      PowerMock.expectNew(PROV_SI001_LancerOrchestrateurBuilder.class).andReturn(_provSI001BuilderMock);
      EasyMock.expect(_provSI001BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_provSI001BuilderMock);
      EasyMock.expect(_provSI001BuilderMock.cles(EasyMock.anyObject())).andReturn(_provSI001BuilderMock);
      EasyMock.expect(_provSI001BuilderMock.priorite(10)).andReturn(_provSI001BuilderMock);
      EasyMock.expect(_provSI001BuilderMock.type(IMegSpiritConsts.CONTINUER_PROCESSUS)).andReturn(_provSI001BuilderMock);
      EasyMock.expect(_provSI001BuilderMock.processus("PEP0018_CommandePfi")).andReturn(_provSI001BuilderMock); //$NON-NLS-1$
      EasyMock.expect(_provSI001BuilderMock.noms(EasyMock.anyObject())).andReturn(_provSI001BuilderMock);
      EasyMock.expect(_provSI001BuilderMock.valeurs(EasyMock.anyObject())).andReturn(_provSI001BuilderMock);
      EasyMock.expect(_provSI001BuilderMock.build()).andReturn(_provSI001Mock);
      EasyMock.expect(_provSI001Mock.execute(EasyMock.anyObject(PEI0018_CommandePfi.class))).andReturn(__podam.manufacturePojoWithFullData(ResponseConnector.class));
      EasyMock.expect(_provSI001Mock.getRetour()).andReturn(RetourFactoryForTU.createOkRetour());

      /* Mock for REX005 */
      EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxy).once();
      EasyMock.expect(_rexProxy.reconciliationCommercialeLireTousParIdReconciliation(EasyMock.anyObject(Tracabilite.class), EasyMock.anyString())).andReturn(new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), Arrays.asList(__podam.manufacturePojoWithFullData(ReconciliationCommerciale.class))));

      EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxy).once();
      EasyMock.expect(_rexProxy.reconciliationCommercialeEnMasseAcquitterUn(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(ManageReconciliationCommercialeEnMasseRequest.class))).andReturn(new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), null));

      //Mock for REX006
      //EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxy).once();
      //EasyMock.expect(_rexProxy.reconciliationCommercialeModifier(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(CreateOrUpdateReconciliationCommercialeRequest.class))).andReturn(new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), null));

      // On enregistre le scénario des appels avant de lancer le test
      PowerMock.replayAll();

      _processInstance.initializeContext();
      _processInstance.run(_request);
      _processInstance.continueProcess(_request, tracabilite);
    }
    catch (final RavelException actual)
    {
      fail("Should not append"); //$NON-NLS-1$
    }
    finally
    {
      // On demande à PowerMock de vérifier la stack d'appel en fonction du scénariob
      PowerMock.verifyAll();

      assertEquals(expected.getMarshalledResponseJson(), _request.getResponse().getMarshalledResponseJson());
    }
  }

  /**
   * Nominal case with PHOTO VIDE for {@link PEI0018_CommandePFI} <br>
   *
   * <b>Inputs: </b>Valid inputs. Case with noCompte not null<br>
   * <b>Expected: </b> Retour{OK}
   *
   * @throws Throwable
   *           On unexpected error
   */
  //@Ignore("JJY - Gelé pour le moment, corrigé au plus tard le 29/10/2018")
  @Test
  public void testPEI0018_CommandePFI_OK_002() throws Throwable
  {
    Tracabilite tracabilite = new Tracabilite();
    tracabilite.setNomProcessus(StringConstants.EMPTY_STRING);

    PhotoPfi infosPfi = __podam.manufacturePojo(PhotoPfi.class); //PhotoPFI to put in donnes Brut of command
    infosPfi.setPortefeuilleServices(null);

    //Init the catalogServiceCommercial for the list
    CatalogServiceCommercial catalogServiceCommercial = __podam.manufacturePojo(CatalogServiceCommercial.class);
    catalogServiceCommercial.setClientOperateur(_pfiGenerator.getCommande().getClientOperateur());
    catalogServiceCommercial.setNoServiceCommercial(_pfiGenerator.getNoServiceCommercialConnu());
    catalogServiceCommercial.setTypePA("VOIP"); //$NON-NLS-1$

    //Add the catalogServiceCommercial to the list
    List<CatalogServiceCommercial> listeCatalogServiceComemrcial = new ArrayList<>();
    listeCatalogServiceComemrcial.add(catalogServiceCommercial);

    final PhotoPfiRequest request = new PhotoPfiRequest();
    request.setPotoPfi(infosPfi);

    //Init requestHeader
    final RequestHeader requestHeader1 = new RequestHeader();
    requestHeader1.setName(IHttpHeadersConsts.X_CLIENT_OPERATEUR);
    requestHeader1.setValue(ClientOperateur.BSS_GP.name());
    _request.getRequestHeader().add(requestHeader1);
    _request.setPayload(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(request));

    //Expected response
    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setResult("{}"); //$NON-NLS-1$
    final Response expected = new Response(ErrorCode.OK_00200, response);

    try
    {
      _processInstance = new PEI0018_CommandePfi();

      /* Mock for Validator */
      final Set<ConstraintViolation<CommandePfi>> constraintViolations = new HashSet<>();

      EasyMock.expect(Validation.buildDefaultValidatorFactory()).andReturn(_validationFactoryMock);
      EasyMock.expect(_validationFactoryMock.getValidator()).andReturn(_validationMock);
      EasyMock.expect(_validationMock.validate(EasyMock.anyObject(CommandePfi.class))).andReturn(constraintViolations);
      _validationFactoryMock.close();

      tracabilite.setIdCorrelationByTel("123415151515151"); //$NON-NLS-1$
      Map<String, String> refFonc = new HashMap<>();
      refFonc.put(IRefFoncConstants.CLI_OPE, catalogServiceCommercial.getClientOperateur());
      refFonc.put(IRefFoncConstants.NO_COMPTE, StringConstants.EMPTY_STRING);

      BL1700_AjouterRefFonc bl1700 = new BL1700_AjouterRefFonc.BL1700_AjouterRefFoncBuilder().tracabilite(tracabilite).refFonc(refFonc).build();
      bl1700.execute(_processInstance);

      /* Mock for CMD002 */
      EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdProxy);
      ConnectorResponse<Retour, Nothing> expectedRetourn = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), null);
      EasyMock.expect(_cmdProxy.commandeCreer(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(CreateCommandeRequest.class))).andReturn(expectedRetourn);

      /* Mock for REX005 */
      EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxy).once();
      EasyMock.expect(_rexProxy.reconciliationCommercialeLireTousParIdReconciliation(EasyMock.anyObject(Tracabilite.class), EasyMock.anyString())).andReturn(new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), Arrays.asList(__podam.manufacturePojoWithFullData(ReconciliationCommerciale.class))));

      EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxy).once();
      EasyMock.expect(_rexProxy.reconciliationCommercialeEnMasseAcquitterUn(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(ManageReconciliationCommercialeEnMasseRequest.class))).andReturn(new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), null));

      PowerMock.expectNew(PROV_SI001_LancerOrchestrateurBuilder.class).andReturn(_provSI001BuilderMock);
      EasyMock.expect(_provSI001BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_provSI001BuilderMock);
      EasyMock.expect(_provSI001BuilderMock.cles(EasyMock.anyObject())).andReturn(_provSI001BuilderMock);
      EasyMock.expect(_provSI001BuilderMock.priorite(10)).andReturn(_provSI001BuilderMock);
      EasyMock.expect(_provSI001BuilderMock.type(IMegSpiritConsts.CONTINUER_PROCESSUS)).andReturn(_provSI001BuilderMock);
      EasyMock.expect(_provSI001BuilderMock.processus("PEP0018_CommandePfi")).andReturn(_provSI001BuilderMock); //$NON-NLS-1$
      EasyMock.expect(_provSI001BuilderMock.noms(EasyMock.anyObject())).andReturn(_provSI001BuilderMock);
      EasyMock.expect(_provSI001BuilderMock.valeurs(EasyMock.anyObject())).andReturn(_provSI001BuilderMock);
      EasyMock.expect(_provSI001BuilderMock.build()).andReturn(_provSI001Mock);
      EasyMock.expect(_provSI001Mock.execute(EasyMock.anyObject(PEI0018_CommandePfi.class))).andReturn(__podam.manufacturePojoWithFullData(ResponseConnector.class));
      EasyMock.expect(_provSI001Mock.getRetour()).andReturn(RetourFactoryForTU.createNOK(IMegConsts.CAT1, IMegSpiritConsts.LECTURE_INDISPONIBLE, com.bytel.spirit.common.connectors.rpg.Messages.getString("RPGConnector.ConfigServicesCommerciaux.ServicesComCache"), null)); //$NON-NLS-1$

      PowerMock.expectNew(BL4600_CreerErreurSpiritBuilder.class).andReturn(_bl4600BuilderMock);
      EasyMock.expect(_bl4600BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl4600BuilderMock);
      EasyMock.expect(_bl4600BuilderMock.retour(RetourFactoryForTU.createNOK(IMegConsts.CAT1, IMegSpiritConsts.LECTURE_INDISPONIBLE, com.bytel.spirit.common.connectors.rpg.Messages.getString("RPGConnector.ConfigServicesCommerciaux.ServicesComCache"), null))).andReturn(_bl4600BuilderMock); //$NON-NLS-1$
      EasyMock.expect(_bl4600BuilderMock.build()).andReturn(_bl4600Mock);
      EasyMock.expect(_bl4600Mock.execute(EasyMock.anyObject(PEI0018_CommandePfi.class))).andReturn(null);
      EasyMock.expect(_bl4600Mock.getRetour()).andReturn(RetourFactoryForTU.createOkRetour()).anyTimes();

      // On enregistre le scénario des appels avant de lancer le test
      PowerMock.replayAll();

      _processInstance.initializeContext();
      _processInstance.run(_request);
      _processInstance.continueProcess(_request, tracabilite);
    }
    catch (final RavelException actual)
    {
      fail("Should not append"); //$NON-NLS-1$
    }
    finally
    {
      // On demande à PowerMock de vérifier la stack d'appel en fonction du scénariob
      PowerMock.verifyAll();

      assertEquals(expected.getMarshalledResponseJson(), _request.getResponse().getMarshalledResponseJson());
    }
  }

  /**
   * Nominal case for {@link PEI0018_CommandePFI} <br>
   * Call continueProcess and BL4600
   *
   * <b>Inputs: </b>Valid inputs. Case with noCompte not null<br>
   * <b>Expected: </b> Retour{OK}
   *
   * @throws Throwable
   *           On unexpected error
   */
  @Test
  public void testPEI0018_CommandePFI_OK_003() throws Throwable
  {
    Tracabilite tracabilite = new Tracabilite();
    tracabilite.setNomProcessus(StringConstants.EMPTY_STRING);

    PhotoPfi infosPfi = __podam.manufacturePojo(PhotoPfi.class); //PhotoPFI to put in donnes Brut of command
    infosPfi.getPortefeuilleServices().setStatut(Statut.ACTIF.name());

    Retour retourExpected = RetourFactoryForTU.createOkRetour();

    //Init the catalogServiceCommercial for the list
    CatalogServiceCommercial catalogServiceCommercial = __podam.manufacturePojo(CatalogServiceCommercial.class);
    catalogServiceCommercial.setClientOperateur(_pfiGenerator.getCommande().getClientOperateur());
    catalogServiceCommercial.setNoServiceCommercial(_pfiGenerator.getNoServiceCommercialConnu());
    catalogServiceCommercial.setTypePA("VOIP"); //$NON-NLS-1$

    //initialize Statut of ServiceAccessible - workaround for Podam
    //The SA has the same noServiceCommercial as the catalogServiceCommercial so that it will be found on cache
    List<com.bytel.spirit.prof.shared.types.json.sti0017.ServiceAccessible> sAccessiblesList = new ArrayList<>();

    com.bytel.spirit.prof.shared.types.json.sti0017.ServiceAccessible sa = new com.bytel.spirit.prof.shared.types.json.sti0017.ServiceAccessible();
    sa.setNoServiceCommercial(catalogServiceCommercial.getNoServiceCommercial());
    sa.setListeIdPointAcces(Arrays.asList(catalogServiceCommercial.getNoServiceCommercial()));
    sAccessiblesList.add(sa);

    infosPfi.getPortefeuilleServices().setServicesAccessibles(sAccessiblesList);

    List<com.bytel.spirit.prof.shared.types.abstracts.sti0017.AbstractPointAcces> pointsAcces = new ArrayList<>();

    com.bytel.spirit.prof.shared.types.abstracts.sti0017.AbstractPointAcces pAccesVoip = _pfiGenerator.buildPointAccesVoipPortageV1();
    pAccesVoip.setIdentifiantFonctionnelPA(catalogServiceCommercial.getNoServiceCommercial());
    pointsAcces.add(pAccesVoip);
    infosPfi.getPortefeuilleServices().setPointsAcces(pointsAcces);

    final PhotoPfiRequest request = new PhotoPfiRequest();
    request.setPotoPfi(infosPfi);

    //Init requestHeader
    final RequestHeader requestHeader1 = new RequestHeader();
    requestHeader1.setName(IHttpHeadersConsts.X_CLIENT_OPERATEUR);
    requestHeader1.setValue(ClientOperateur.BSS_GP.name());
    _request.getRequestHeader().add(requestHeader1);
    _request.setPayload(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(request));

    //Expected response
    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setResult("{}"); //$NON-NLS-1$
    final Response expected = new Response(ErrorCode.OK_00200, response);

    try
    {
      _processInstance = new PEI0018_CommandePfi();

      /* Mock for Validator */
      final Set<ConstraintViolation<CommandePfi>> constraintViolations = new HashSet<>();

      EasyMock.expect(Validation.buildDefaultValidatorFactory()).andReturn(_validationFactoryMock);
      EasyMock.expect(_validationFactoryMock.getValidator()).andReturn(_validationMock);
      EasyMock.expect(_validationMock.validate(EasyMock.anyObject(CommandePfi.class))).andReturn(constraintViolations);
      _validationFactoryMock.close();

      PowerMock.expectNew(BL200_ObtenirServiceCommercialBuilder.class).andReturn(_bl200BuilderMock);
      EasyMock.expect(_bl200BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl200BuilderMock);
      EasyMock.expect(_bl200BuilderMock.clientOperateur("BSS_GP")).andReturn(_bl200BuilderMock); //$NON-NLS-1$
      EasyMock.expect(_bl200BuilderMock.noServiceCommercial(EasyMock.anyObject(String.class))).andReturn(_bl200BuilderMock);
      EasyMock.expect(_bl200BuilderMock.build()).andReturn(_bl200Mock);
      EasyMock.expect(_bl200Mock.execute(EasyMock.anyObject(PEI0018_CommandePfi.class))).andReturn(catalogServiceCommercial);
      EasyMock.expect(_bl200Mock.getRetour()).andReturn(retourExpected);

      tracabilite.setIdCorrelationByTel("123415151515151"); //$NON-NLS-1$
      Map<String, String> refFonc = new HashMap<>();
      refFonc.put(IRefFoncConstants.CLI_OPE, catalogServiceCommercial.getClientOperateur());
      refFonc.put(IRefFoncConstants.NO_COMPTE, StringConstants.EMPTY_STRING);

      BL1700_AjouterRefFonc bl1700 = new BL1700_AjouterRefFonc.BL1700_AjouterRefFoncBuilder().tracabilite(tracabilite).refFonc(refFonc).build();
      bl1700.execute(_processInstance);

      /* Mock BL800*/
      PowerMock.expectNew(BL800_ObtenirSequenceBuilder.class).andReturn(_bl800BuilderMock);
      EasyMock.expect(_bl800BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl800BuilderMock);
      EasyMock.expect(_bl800BuilderMock.code(EasyMock.eq(UniqueIdConstant.ID_CMD_GP))).andReturn(_bl800BuilderMock);
      EasyMock.expect(_bl800BuilderMock.build()).andReturn(_bl800Mock);
      String sequence = UUID.randomUUID().toString();
      EasyMock.expect(_bl800Mock.execute(EasyMock.anyObject(PEI0018_CommandePfi.class))).andReturn(sequence);
      EasyMock.expect(_bl800Mock.getRetour()).andReturn(RetourFactoryForTU.createOkRetour()).anyTimes();

      /* Mock for CMD002 */
      EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdProxy);
      ConnectorResponse<Retour, Nothing> expectedRetourn = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), null);
      EasyMock.expect(_cmdProxy.commandeCreer(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(CreateCommandeRequest.class))).andReturn(expectedRetourn);

      PowerMock.expectNew(PROV_SI001_LancerOrchestrateurBuilder.class).andReturn(_provSI001BuilderMock);
      EasyMock.expect(_provSI001BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_provSI001BuilderMock);
      EasyMock.expect(_provSI001BuilderMock.cles(EasyMock.anyObject())).andReturn(_provSI001BuilderMock);
      EasyMock.expect(_provSI001BuilderMock.priorite(10)).andReturn(_provSI001BuilderMock);
      EasyMock.expect(_provSI001BuilderMock.type(IMegSpiritConsts.CONTINUER_PROCESSUS)).andReturn(_provSI001BuilderMock);
      EasyMock.expect(_provSI001BuilderMock.processus("PEP0018_CommandePfi")).andReturn(_provSI001BuilderMock); //$NON-NLS-1$
      EasyMock.expect(_provSI001BuilderMock.noms(EasyMock.anyObject())).andReturn(_provSI001BuilderMock);
      EasyMock.expect(_provSI001BuilderMock.valeurs(EasyMock.anyObject())).andReturn(_provSI001BuilderMock);
      EasyMock.expect(_provSI001BuilderMock.build()).andReturn(_provSI001Mock);
      EasyMock.expect(_provSI001Mock.execute(EasyMock.anyObject(PEI0018_CommandePfi.class))).andReturn(__podam.manufacturePojoWithFullData(ResponseConnector.class));
      EasyMock.expect(_provSI001Mock.getRetour()).andReturn(RetourFactoryForTU.createNOK(IMegConsts.CAT1, IMegSpiritConsts.LECTURE_INDISPONIBLE, com.bytel.spirit.common.connectors.rpg.Messages.getString("RPGConnector.ConfigServicesCommerciaux.ServicesComCache"), null)); //$NON-NLS-1$

      /* Mock for REX005 */
      EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxy).once();
      EasyMock.expect(_rexProxy.reconciliationCommercialeLireTousParIdReconciliation(EasyMock.anyObject(Tracabilite.class), EasyMock.anyString())).andReturn(new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), Arrays.asList(__podam.manufacturePojoWithFullData(ReconciliationCommerciale.class))));

      /* Mock for REX006 */
      EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxy).once();
      EasyMock.expect(_rexProxy.reconciliationCommercialeEnMasseAcquitterUn(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(ManageReconciliationCommercialeEnMasseRequest.class))).andReturn(new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), null));

      /* Mock for REX007 */
      //EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxy).once();
      //EasyMock.expect(_rexProxy.reconciliationCommercialeModifier(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(CreateOrUpdateReconciliationCommercialeRequest.class))).andReturn(new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), null));

      /* Mock BL4600*/
      PowerMock.expectNew(BL4600_CreerErreurSpiritBuilder.class).andReturn(_bl4600BuilderMock);
      EasyMock.expect(_bl4600BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl4600BuilderMock);
      EasyMock.expect(_bl4600BuilderMock.retour(RetourFactoryForTU.createNOK(IMegConsts.CAT1, IMegSpiritConsts.LECTURE_INDISPONIBLE, com.bytel.spirit.common.connectors.rpg.Messages.getString("RPGConnector.ConfigServicesCommerciaux.ServicesComCache"), null))).andReturn(_bl4600BuilderMock); //$NON-NLS-1$
      EasyMock.expect(_bl4600BuilderMock.build()).andReturn(_bl4600Mock);
      EasyMock.expect(_bl4600Mock.execute(EasyMock.anyObject(PEI0018_CommandePfi.class))).andReturn(null);
      EasyMock.expect(_bl4600Mock.getRetour()).andReturn(RetourFactoryForTU.createOkRetour()).anyTimes();

      // On enregistre le scénario des appels avant de lancer le test
      PowerMock.replayAll();

      _processInstance.initializeContext();
      _processInstance.run(_request);
      _processInstance.continueProcess(_request, tracabilite);
    }
    catch (final RavelException actual)
    {
      fail("Should not append"); //$NON-NLS-1$
    }
    finally
    {
      // On demande à PowerMock de vérifier la stack d'appel en fonction du scénariob
      PowerMock.verifyAll();

      assertEquals(expected.getMarshalledResponseJson(), _request.getResponse().getMarshalledResponseJson());
    }
  }

  /**
   * Tests when the reading of ServicesComCacheLoader is impossible <br>
   *
   * <b>Inputs: </b>Valid inputs but generated error on RPGProxy mock<br>
   * <b>Expected: </b> Retour{CAT1; LECTURE_INDISPONIBLE; Impossible de récupérer le cache ServicesComCacheLoader}
   *
   * @throws Throwable
   *           On unexpected error
   */
  @Test
  public void testPEI0018_CommandePFI_ServicesComCacheLoaderKO_001() throws Throwable
  {
    PhotoPfi infosPfi = __podam.manufacturePojo(PhotoPfi.class); //PhotoPFI to put in donnes Brut of command
    infosPfi.getPortefeuilleServices().setStatut(Statut.ACTIF.name());
    infosPfi.setDemandePhoto(null);

    //initialize Statut of ServiceAccessible - workaround for Podam
    List<com.bytel.spirit.prof.shared.types.json.sti0017.ServiceAccessible> sAccessiblesList = new ArrayList<>();

    com.bytel.spirit.prof.shared.types.json.sti0017.ServiceAccessible sa = new com.bytel.spirit.prof.shared.types.json.sti0017.ServiceAccessible();
    sa.setNoServiceCommercial("6100012"); //$NON-NLS-1$
    sa.setListeIdPointAcces(Arrays.asList("6100012")); //$NON-NLS-1$
    sAccessiblesList.add(sa);

    infosPfi.getPortefeuilleServices().setServicesAccessibles(sAccessiblesList);

    List<com.bytel.spirit.prof.shared.types.abstracts.sti0017.AbstractPointAcces> pointsAcces = new ArrayList<>();// photoPfi.getPortefeuilleServices().getPointsAcces();

    com.bytel.spirit.prof.shared.types.abstracts.sti0017.AbstractPointAcces pAccesVoip = _pfiGenerator.buildPointAccesVoipPortTelephoniqueV1();
    pAccesVoip.setIdentifiantFonctionnelPA("6100012"); //$NON-NLS-1$
    pointsAcces.add(pAccesVoip);
    infosPfi.getPortefeuilleServices().setPointsAcces(pointsAcces);

    final PhotoPfiRequest request = new PhotoPfiRequest();
    request.setPotoPfi(infosPfi);

    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT1, IMegSpiritConsts.LECTURE_INDISPONIBLE, com.bytel.spirit.common.connectors.rpg.Messages.getString("RPGConnector.ConfigServicesCommerciaux.ServicesComCache"), null); //$NON-NLS-1$

    PowerMock.expectNew(BL200_ObtenirServiceCommercialBuilder.class).andReturn(_bl200BuilderMock);
    EasyMock.expect(_bl200BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl200BuilderMock);
    EasyMock.expect(_bl200BuilderMock.clientOperateur("BSS_GP")).andReturn(_bl200BuilderMock); //$NON-NLS-1$
    EasyMock.expect(_bl200BuilderMock.noServiceCommercial("6100012")).andReturn(_bl200BuilderMock); //$NON-NLS-1$
    EasyMock.expect(_bl200BuilderMock.build()).andReturn(_bl200Mock);
    EasyMock.expect(_bl200Mock.execute(EasyMock.anyObject(PEI0018_CommandePfi.class))).andReturn(null);
    EasyMock.expect(_bl200Mock.getRetour()).andReturn(retourExpected);

    //Expected response
    final RequestHeader requestHeader1 = new RequestHeader();
    requestHeader1.setName(IHttpHeadersConsts.X_CLIENT_OPERATEUR);
    requestHeader1.setValue("BSS_GP"); //$NON-NLS-1$
    _request.getRequestHeader().add(requestHeader1);
    _request.setPayload(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(request));

    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    response.setResult("{}"); //$NON-NLS-1$
    final Response expected = new Response(ErrorCode.OK_00200, response);

    try
    {
      _processInstance = new PEI0018_CommandePfi();

      final Set<ConstraintViolation<PhotoPfi>> constraintViolations = new HashSet<>();
      EasyMock.expect(Validation.buildDefaultValidatorFactory()).andReturn(_validationFactoryMock);
      EasyMock.expect(_validationFactoryMock.getValidator()).andReturn(_validationMock);
      EasyMock.expect(_validationMock.validate(EasyMock.anyObject(PhotoPfi.class))).andReturn(constraintViolations);
      _validationFactoryMock.close();

      /* Mock for CMD002 */
      EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdProxy);
      ConnectorResponse<Retour, Nothing> expectedRetourn = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), null);
      EasyMock.expect(_cmdProxy.commandeCreer(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(CreateCommandeRequest.class))).andReturn(expectedRetourn);

      // On enregistre le scénario des appels avant de lancer le test
      PowerMock.replayAll();

      _processInstance.initializeContext();
      _processInstance.run(_request);
    }
    catch (final RavelException actual)
    {
      fail("Should not append"); //$NON-NLS-1$
    }
    finally
    {
      // On demande à PowerMock de vérifier la stack d'appel en fonction du scénariob
      PowerMock.verifyAll();

      assertEquals(expected.getMarshalledResponseJson(), _request.getResponse().getMarshalledResponseJson());
    }
  }

}
