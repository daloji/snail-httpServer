/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PM028.activity;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.easymock.EasyMock;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.bouygtel.commontypes.s3g.v3.EnumTypeStatutServiceAccessible;
import com.bouygtel.refcli.consulterpfi.out.ConsulterPFIOut;
import com.bouygtel.refcli.consulterpfi.out.ConsulterPFIReponseType;
import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.ACManagerUtil;
import com.bytel.ravel.common.utils.MarshallTools;
import com.bytel.ravel.common.utils.Pair;
import com.bytel.ravel.common.utils.RetourFactoryForTU;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.utils.Test_Consts;
import com.bytel.spirit.common.connectors.ink.generated.Dataset;
import com.bytel.spirit.common.connectors.ink.generated.DatasetParam;
import com.bytel.spirit.common.connectors.ink.generated.ProductOrderData;
import com.bytel.spirit.common.connectors.ink.generated.Request;
import com.bytel.spirit.common.connectors.ink.generated.ServiceOrderDataRequest;
import com.bytel.spirit.common.connectors.ink.generated.ServiceOrderRequest;
import com.bytel.spirit.common.shared.misc.ressources.Consts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.prof.connectors.generated.svccomm.TypeAction;
import com.bytel.spirit.prof.connectors.generated.svccomm.TypeParametre;
import com.bytel.spirit.prof.connectors.generated.svccomm.TypeParametres;
import com.bytel.spirit.prof.connectors.generated.svccomm.TypeServiceCommercialKPSA;
import com.bytel.spirit.prof.connectors.generated.svccomm.TypeServiceCommercialMIM;
import com.bytel.spirit.prof.connectors.refclient.meg.REFCLIENT001EnvoyerDemande;
import com.bytel.spirit.prof.connectors.svccomm.SvcCommMimProxy;
import com.bytel.spirit.prof.processes.PM028.ActionProvisionner;
import com.bytel.spirit.prof.processes.PM028.Diagnostic;
import com.bytel.spirit.prof.processes.PM028.PM028ProvisionnerPfi;
import com.bytel.spirit.prof.processes.PM028.Quadruplet;
import com.bytel.spirit.prof.processes.PM028.activity.PM028BL300MimToInk.PM028BL300MimToInkBuilder;
import com.bytel.spirit.prof.processes.generated.provisionnerpfi.ActeMetier;
import com.bytel.spirit.prof.processes.generated.provisionnerpfi.DonneesMetier;
import com.bytel.spirit.prof.processes.generated.provisionnerpfi.LigneGsm;
import com.bytel.spirit.prof.processes.generated.provisionnerpfi.PIVOTREFERENCE;
import com.bytel.spirit.prof.processes.generated.provisionnerpfi.ParamService;
import com.bytel.spirit.prof.processes.generated.provisionnerpfi.ParametreSimpleValorise;
import com.bytel.spirit.prof.processes.generated.provisionnerpfi.PartitionSic;
import com.bytel.spirit.prof.processes.generated.provisionnerpfi.PointAccesStatut;
import com.bytel.spirit.prof.processes.generated.provisionnerpfi.PortefeuilleIndividuel;
import com.bytel.spirit.prof.processes.generated.provisionnerpfi.ProvisionnerPfiIn;
import com.bytel.spirit.prof.processes.generated.provisionnerpfi.ServiceAccessible;
import com.bytel.spirit.prof.processes.generated.provisionnerpfi.ServiceAccessibleStatut;
import com.bytel.spirit.prof.processes.generated.provisionnerpfi.ServiceCommercial;
import com.bytel.spirit.prof.processes.generated.provisionnerpfi.SimLogique;
import com.bytel.spirit.prof.processes.generated.provisionnerpfi.SimLogiqueStatut;
import com.bytel.spirit.prof.processes.generated.provisionnerpfi.St;
import com.bytel.spirit.prof.processes.generated.provisionnerpfi.TypePointAccesCommercial;

/**
 *
 * @author lmerces
 * @version ($Revision$ $Date$)
 */
//Déclaration du runner de test pour lancer les TUs avec le runner PowerMock
@RunWith(PowerMockRunner.class)
//Préparation des classes pour les tests, toutes les classes comportant des méthodes statiques à mocker doivent être présentes dans l'annotation
@PrepareForTest({ SvcCommMimProxy.class })
//To avoid: SecretKeyFactory.getInstance() throws exception for all algorithms in unit tests
@PowerMockIgnore("javax.crypto.*")
public class PM028BL300MimToInkTest
{
  /**
   * EDIFACT_FILE_NAME
   */
  private static final String EDIFACT_FILE_NAME = "EdifactFileName"; //$NON-NLS-1$
  /**
   *
   */
  private static final String FLOW_ID = "cde3ab202e714d88afb92e24b52185ef"; //$NON-NLS-1$
  /**
   * IDTITF
   */
  private static final String IDTITF = "'IWSINFRA1"; //$NON-NLS-1$

  /**
   * PARTITION_SIC
   */
  private static final String PARTITION_SIC = "3"; //$NON-NLS-1$

  /**
   * IDTPFS
   */
  private static final String IDTPFS = "IDTPFS"; //$NON-NLS-1$

  /**
   * IMSI
   */
  private static final String IMSI = "IMSI"; //$NON-NLS-1$

  /**
   *
   */
  private static final String IN_REQUEST_XML = "src/test/resources/provisionnerPfiIn_request.xml"; //$NON-NLS-1$

  /**
   * MESSAGE_TYPE
   */
  private static final String MESSAGE_TYPE = "messageType"; //$NON-NLS-1$

  /**
   * MSISDN
   */
  private static final String MSISDN = "MSISDN"; //$NON-NLS-1$

  /**
   * NOUV MSISDN
   */
  private static final String NOUV_MSISDN = "NOUV_MSISDN"; //$NON-NLS-1$

  /**
   *
   */
  private static final String ORDER_ID = "103.cde3ab202e714d88afb92e24b52185ef.1"; //$NON-NLS-1$

  /**
   * ORIGINATOR
   */
  private static final String ORIGINATOR = "Originator"; //$NON-NLS-1$

  /**
   * SOURCE
   */
  private static final String SOURCE_ID = "103"; //$NON-NLS-1$

  /**
   *
   */
  private static final String ORIGINATOR_VALUE = "'IWSINFRA1"; //$NON-NLS-1$

  /**
   *
   */
  private static final String PROV_VERB = "PROV"; //$NON-NLS-1$

  /**
   * TYPE_LIGNE
   */
  private static final String TYPE_LIGNE = "TYPE_LIGNE"; //$NON-NLS-1$

  /**
   * MY_HEAP_NAME
   */
  private static final String MY_HEAP_NAME = "MyHeapName"; //$NON-NLS-1$

  /**
  *
  */
  private static final String PA_MSISDN = "PA.MSISDN"; //$NON-NLS-1$

  /**
  *
  */
  private static String DEFAULT_IWS_RESSOURCES_INFO = StringConstants.OK + "/" + REFCLIENT001EnvoyerDemande.INCONNU_PFI; //$NON-NLS-1$

  /**
   * Initialization method: Create: - spring context - connectors - service manager
   */
  @BeforeClass
  public static void init()
  {
    ACManagerUtil.resetACManager();
    new ClassPathXmlApplicationContext("classpath:BeansProcessTestMocks.xml"); //$NON-NLS-1$
  }

  /**
   * SvcCommMimConnectorMockHelper
   */
  @MockStrict
  private SvcCommMimProxy _svcCommMimConnector;

  /**
  *
  */
  private PM028ProvisionnerPfi _currentInstance;

  /**
   * Cleans the Connector Mocks responses
   *
   * @throws Exception
   *           On Error
   */
  @Before
  public void beforeTest() throws Exception
  {
    // on réinitialise tous les mocks afin de ne pas avoir d'interférence entre les tests
    PowerMock.resetAll();

    // On initialise toutes les classes à mocker comportant un appel à une méthode statique
    // Dans notre cas on mock statiquemement toutes les classes des activités et des proxys appelés (pour les createContexte et les getInstance)
    PowerMock.mockStaticStrict(SvcCommMimProxy.class);

    // Initialize the context
    _currentInstance = new PM028ProvisionnerPfi();
    _currentInstance.initializeContext();
  }

  /**
   * Test le cas Nominal. <br/>
   * Alors: ServiceAccessibleStatut = INACTIF avec valid IMSI, IdServiceKPSA different de SSBN <br/>
   *
   *
   * <b>Entrées:</b>Entrée valides.<br/>
   * <b>Attendu:</b>Resultat:OK;<br/>
   *
   * @throws RavelException
   *           on error
   */
  @Test
  public void PM028_BL300_MimToInk_test_001() throws RavelException
  {
    Tracabilite tracabilite = new Tracabilite(StringConstants.EMPTY_STRING, Test_Consts.DEFAULT_MSGID, "PROF", "nomPRocessus", "idProcessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    PortefeuilleIndividuel portefeuilleIndividuel = new PortefeuilleIndividuel();
    portefeuilleIndividuel.setId("PFI-1"); //$NON-NLS-1$
    portefeuilleIndividuel.setDateDernierImpact("20160219052345"); //$NON-NLS-1$
    portefeuilleIndividuel.setNoCompte("11700000091"); //$NON-NLS-1$

    Pair<ServiceAccessible, ServiceCommercial> p = createProvInService("2/INACTIF"); //$NON-NLS-1$
    PIVOTREFERENCE pivotreferenceSA = new PIVOTREFERENCE();
    pivotreferenceSA.setIdref(p._first);
    portefeuilleIndividuel.getServiceAccessibles().add(pivotreferenceSA);

    Quadruplet quadruplet = new Quadruplet(portefeuilleIndividuel, "33600300091", "208201700000091", ActionProvisionner.ACTIVER_LIGNES); //$NON-NLS-1$ //$NON-NLS-2$

    ProvisionnerPfiIn provisionnerPfiIn = MarshallTools.unmarshall(ProvisionnerPfiIn.class, new File(IN_REQUEST_XML));

    TypeParametre typeParametre = new TypeParametre();
    typeParametre.setIdParametreKPSA("SPARAM[7]"); //$NON-NLS-1$
    typeParametre.setConstante("constante"); //$NON-NLS-1$

    TypeParametres typeParametres = new TypeParametres();
    typeParametres.getParametres().add(typeParametre);

    TypeServiceCommercialKPSA typeServiceCommercialKPSA = new TypeServiceCommercialKPSA();
    typeServiceCommercialKPSA.setIdServiceKPSA("IdServiceKPSA"); //$NON-NLS-1$
    typeServiceCommercialKPSA.setParametres(typeParametres);

    TypeServiceCommercialMIM typeServiceCommercialMIM = new TypeServiceCommercialMIM();
    typeServiceCommercialMIM.setIdServiceMIM("2"); //$NON-NLS-1$
    typeServiceCommercialMIM.getServiceCommercialKPSAs().add(typeServiceCommercialKPSA);

    //Prepare mock
    EasyMock.expect(SvcCommMimProxy.getInstance()).andReturn(_svcCommMimConnector);
    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, "2")).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(typeServiceCommercialMIM, true)); //$NON-NLS-1$

    // On enregistre le scénario des appels
    PowerMock.replayAll();

    PM028BL300MimToInk currentInstance = new PM028BL300MimToInkBuilder().tracabilite(tracabilite).source(SOURCE_ID).orderid(ORDER_ID).flowid(FLOW_ID).quadrupletProvisionnerPfiIn(quadruplet).consulterPFIOut(new ConsulterPFIOut()).provisionnerPfiIn(provisionnerPfiIn).verbe(Diagnostic.PROVISIONNER_SERVICES.toString()).idtitf(IDTITF).iwsRessourcesInfoParamValue(DEFAULT_IWS_RESSOURCES_INFO).partitionSic(PARTITION_SIC).build();
    Request ret = currentInstance.execute(_currentInstance);

    PowerMock.verifyAll();

    checkResponse(RetourFactoryForTU.createOkRetour(), currentInstance.getRetour());
    checkINKProdResponse(createExpectedRequest(ORDER_ID, "2101700000091", true, PROV_VERB, ORIGINATOR_VALUE, 0, Diagnostic.PROVISIONNER_SERVICES.toString(), "GSMCSC", "GET"), ret); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

  }

  /**
   * Test le cas Nominal. <br/>
   * Alors: ServiceAccessibleStatut = INACTIF avec valid IMSI, IdServiceKPSA different de SSBN , IdParametreMIM pas vide
   * <br/>
   *
   *
   * <b>Entrées:</b>Entrée valides.<br/>
   * <b>Attendu:</b>Resultat:OK;<br/>
   *
   * @throws RavelException
   *           on error
   */
  @Test
  public void PM028_BL300_MimToInk_test_002() throws RavelException
  {
    Tracabilite tracabilite = new Tracabilite(StringConstants.EMPTY_STRING, Test_Consts.DEFAULT_MSGID, "PROF", "nomPRocessus", "idProcessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    PortefeuilleIndividuel portefeuilleIndividuel = new PortefeuilleIndividuel();
    portefeuilleIndividuel.setId("PFI-1"); //$NON-NLS-1$
    portefeuilleIndividuel.setDateDernierImpact("20160219052345"); //$NON-NLS-1$
    portefeuilleIndividuel.setNoCompte("1101700000091"); //$NON-NLS-1$

    Pair<ServiceAccessible, ServiceCommercial> p = createProvInService("2/INACTIF"); //$NON-NLS-1$
    PIVOTREFERENCE pivotreferenceSA = new PIVOTREFERENCE();
    pivotreferenceSA.setIdref(p._first);
    portefeuilleIndividuel.getServiceAccessibles().add(pivotreferenceSA);

    Quadruplet quadruplet = new Quadruplet(portefeuilleIndividuel, "33600300091", "208201700000091", ActionProvisionner.ACTIVER_LIGNES); //$NON-NLS-1$ //$NON-NLS-2$

    ProvisionnerPfiIn provisionnerPfiIn = MarshallTools.unmarshall(ProvisionnerPfiIn.class, new File(IN_REQUEST_XML));

    TypeParametre typeParametre = new TypeParametre();
    typeParametre.setIdParametreKPSA("SPARAM[7]"); //$NON-NLS-1$
    typeParametre.setConstante("constante"); //$NON-NLS-1$
    typeParametre.setIdParametreMIM("6"); //$NON-NLS-1$

    TypeParametres typeParametres = new TypeParametres();
    typeParametres.getParametres().add(typeParametre);

    TypeServiceCommercialKPSA typeServiceCommercialKPSA = new TypeServiceCommercialKPSA();
    typeServiceCommercialKPSA.setIdServiceKPSA("IdServiceKPSA"); //$NON-NLS-1$
    typeServiceCommercialKPSA.setParametres(typeParametres);

    TypeServiceCommercialMIM typeServiceCommercialMIM = new TypeServiceCommercialMIM();
    typeServiceCommercialMIM.setIdServiceMIM("2"); //$NON-NLS-1$
    typeServiceCommercialMIM.getServiceCommercialKPSAs().add(typeServiceCommercialKPSA);

    //Prepare mock
    EasyMock.expect(SvcCommMimProxy.getInstance()).andReturn(_svcCommMimConnector);
    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, "2")).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(typeServiceCommercialMIM, true)); //$NON-NLS-1$

    // On enregistre le scénario des appels
    PowerMock.replayAll();

    PM028BL300MimToInk currentInstance = new PM028BL300MimToInkBuilder().tracabilite(tracabilite).source(SOURCE_ID).orderid(ORDER_ID).flowid(FLOW_ID).quadrupletProvisionnerPfiIn(quadruplet).consulterPFIOut(new ConsulterPFIOut()).provisionnerPfiIn(provisionnerPfiIn).verbe(Diagnostic.PROVISIONNER_SERVICES.toString()).idtitf(IDTITF).iwsRessourcesInfoParamValue(DEFAULT_IWS_RESSOURCES_INFO).partitionSic(PARTITION_SIC).build();
    Request ret = currentInstance.execute(_currentInstance);

    PowerMock.verifyAll();

    checkResponse(RetourFactoryForTU.createOkRetour(), currentInstance.getRetour());
    checkINKProdResponse(createExpectedRequest(ORDER_ID, "2101700000091", true, PROV_VERB, ORIGINATOR_VALUE, 0, Diagnostic.PROVISIONNER_SERVICES.toString(), "GSMCSC", "GET"), ret); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

  }

  /**
   * Test le cas Nominal. <br/>
   * Alors: ServiceAccessibleStatut = INACTIF avec valid IMSI, IdServiceKPSA different de SSBN, IdParametreMIM vide<br/>
   *
   *
   * <b>Entrées:</b>Entrée valides.<br/>
   * <b>Attendu:</b>Resultat:OK;<br/>
   *
   * @throws RavelException
   *           on error
   */
  @Test
  public void PM028_BL300_MimToInk_test_003() throws RavelException
  {
    Tracabilite tracabilite = new Tracabilite(StringConstants.EMPTY_STRING, Test_Consts.DEFAULT_MSGID, "PROF", "nomPRocessus", "idProcessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    PortefeuilleIndividuel portefeuilleIndividuel = new PortefeuilleIndividuel();
    portefeuilleIndividuel.setId("PFI-1"); //$NON-NLS-1$
    portefeuilleIndividuel.setDateDernierImpact("20160219052345"); //$NON-NLS-1$
    portefeuilleIndividuel.setNoCompte("1101700000091"); //$NON-NLS-1$

    Pair<ServiceAccessible, ServiceCommercial> p = createProvInService("2/INACTIF"); //$NON-NLS-1$
    PIVOTREFERENCE pivotreferenceSA = new PIVOTREFERENCE();
    pivotreferenceSA.setIdref(p._first);
    portefeuilleIndividuel.getServiceAccessibles().add(pivotreferenceSA);

    Quadruplet quadruplet = new Quadruplet(portefeuilleIndividuel, "33600300091", "208201700000091", ActionProvisionner.ACTIVER_LIGNES); //$NON-NLS-1$ //$NON-NLS-2$

    ProvisionnerPfiIn provisionnerPfiIn = MarshallTools.unmarshall(ProvisionnerPfiIn.class, new File(IN_REQUEST_XML));

    TypeParametre typeParametre = new TypeParametre();
    typeParametre.setIdParametreKPSA("SPARAM[7]"); //$NON-NLS-1$

    TypeParametres typeParametres = new TypeParametres();
    typeParametres.getParametres().add(typeParametre);

    TypeServiceCommercialKPSA typeServiceCommercialKPSA = new TypeServiceCommercialKPSA();
    typeServiceCommercialKPSA.setIdServiceKPSA("IdServiceKPSA"); //$NON-NLS-1$
    typeServiceCommercialKPSA.setParametres(typeParametres);

    TypeServiceCommercialMIM typeServiceCommercialMIM = new TypeServiceCommercialMIM();
    typeServiceCommercialMIM.setIdServiceMIM("2"); //$NON-NLS-1$
    typeServiceCommercialMIM.getServiceCommercialKPSAs().add(typeServiceCommercialKPSA);

    //Prepare mock
    EasyMock.expect(SvcCommMimProxy.getInstance()).andReturn(_svcCommMimConnector);
    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, "2")).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(typeServiceCommercialMIM, true)); //$NON-NLS-1$

    // On enregistre le scénario des appels
    PowerMock.replayAll();

    PM028BL300MimToInk currentInstance = new PM028BL300MimToInkBuilder().tracabilite(tracabilite).source(SOURCE_ID).orderid(ORDER_ID).flowid(FLOW_ID).quadrupletProvisionnerPfiIn(quadruplet).consulterPFIOut(new ConsulterPFIOut()).provisionnerPfiIn(provisionnerPfiIn).verbe(Diagnostic.PROVISIONNER_SERVICES.toString()).idtitf(IDTITF).iwsRessourcesInfoParamValue(DEFAULT_IWS_RESSOURCES_INFO).partitionSic(PARTITION_SIC).build();
    Request ret = currentInstance.execute(_currentInstance);

    PowerMock.verifyAll();

    checkResponse(RetourFactoryForTU.createOkRetour(), currentInstance.getRetour());
    checkINKProdResponse(createExpectedRequest(ORDER_ID, "2101700000091", true, PROV_VERB, ORIGINATOR_VALUE, 0, Diagnostic.PROVISIONNER_SERVICES.toString(), "GSMCSC", "GET"), ret); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

  }

  /**
   * Test le cas Nominal. <br/>
   * Alors: ServiceAccessibleStatut = INACTIF avec valid IMSI, IdServiceKPSA different de SSBN, commercialKPSA ne matche
   * pas avec SPARAM_REGEX<br/>
   *
   *
   * <b>Entrées:</b>Entrée valides.<br/>
   * <b>Attendu:</b>Resultat:OK;<br/>
   *
   * @throws RavelException
   *           on error
   */
  @Test
  public void PM028_BL300_MimToInk_test_004() throws RavelException
  {
    Tracabilite tracabilite = new Tracabilite(StringConstants.EMPTY_STRING, Test_Consts.DEFAULT_MSGID, "PROF", "nomPRocessus", "idProcessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    PortefeuilleIndividuel portefeuilleIndividuel = new PortefeuilleIndividuel();
    portefeuilleIndividuel.setId("PFI-1"); //$NON-NLS-1$
    portefeuilleIndividuel.setDateDernierImpact("20160219052345"); //$NON-NLS-1$
    portefeuilleIndividuel.setNoCompte("1101700000091"); //$NON-NLS-1$

    Pair<ServiceAccessible, ServiceCommercial> p = createProvInService("2/INACTIF"); //$NON-NLS-1$
    PIVOTREFERENCE pivotreferenceSA = new PIVOTREFERENCE();
    pivotreferenceSA.setIdref(p._first);
    portefeuilleIndividuel.getServiceAccessibles().add(pivotreferenceSA);

    Quadruplet quadruplet = new Quadruplet(portefeuilleIndividuel, "33600300091", "208201700000091", ActionProvisionner.ACTIVER_LIGNES); //$NON-NLS-1$ //$NON-NLS-2$

    ProvisionnerPfiIn provisionnerPfiIn = MarshallTools.unmarshall(ProvisionnerPfiIn.class, new File(IN_REQUEST_XML));

    TypeParametre typeParametre = new TypeParametre();
    typeParametre.setIdParametreKPSA("SPARAM7]"); //$NON-NLS-1$

    TypeParametres typeParametres = new TypeParametres();
    typeParametres.getParametres().add(typeParametre);

    TypeServiceCommercialKPSA typeServiceCommercialKPSA = new TypeServiceCommercialKPSA();
    typeServiceCommercialKPSA.setIdServiceKPSA("IdServiceKPSA"); //$NON-NLS-1$
    typeServiceCommercialKPSA.setParametres(typeParametres);

    TypeServiceCommercialMIM typeServiceCommercialMIM = new TypeServiceCommercialMIM();
    typeServiceCommercialMIM.setIdServiceMIM("2"); //$NON-NLS-1$
    typeServiceCommercialMIM.getServiceCommercialKPSAs().add(typeServiceCommercialKPSA);

    //Prepare mock
    EasyMock.expect(SvcCommMimProxy.getInstance()).andReturn(_svcCommMimConnector);
    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, "2")).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(typeServiceCommercialMIM, true)); //$NON-NLS-1$

    // On enregistre le scénario des appels
    PowerMock.replayAll();

    PM028BL300MimToInk currentInstance = new PM028BL300MimToInkBuilder().tracabilite(tracabilite).source(SOURCE_ID).orderid(ORDER_ID).flowid(FLOW_ID).quadrupletProvisionnerPfiIn(quadruplet).consulterPFIOut(new ConsulterPFIOut()).provisionnerPfiIn(provisionnerPfiIn).verbe(Diagnostic.PROVISIONNER_SERVICES.toString()).idtitf(IDTITF).iwsRessourcesInfoParamValue(DEFAULT_IWS_RESSOURCES_INFO).partitionSic(PARTITION_SIC).build();
    Request ret = currentInstance.execute(_currentInstance);

    PowerMock.verifyAll();

    checkResponse(RetourFactoryForTU.createOkRetour(), currentInstance.getRetour());
    checkINKProdResponse(createExpectedRequest(ORDER_ID, "2101700000091", true, PROV_VERB, ORIGINATOR_VALUE, 0, Diagnostic.PROVISIONNER_SERVICES.toString(), "GSMCSC", "GET"), ret); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

  }

  /**
   * Test le cas Nominal. <br/>
   * Alors: ServiceAccessibleStatut = INACTIF avec valid IMSI, IdServiceKPSA different de SSBN, n'existe pas quelque
   * parametre pour commercialKPSA<br/>
   *
   *
   * <b>Entrées:</b>Entrée valides.<br/>
   * <b>Attendu:</b>Resultat:OK;<br/>
   *
   * @throws RavelException
   *           on error
   */
  @Test
  public void PM028_BL300_MimToInk_test_005() throws RavelException
  {
    Tracabilite tracabilite = new Tracabilite(StringConstants.EMPTY_STRING, Test_Consts.DEFAULT_MSGID, "PROF", "nomPRocessus", "idProcessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    PortefeuilleIndividuel portefeuilleIndividuel = new PortefeuilleIndividuel();
    portefeuilleIndividuel.setId("PFI-1"); //$NON-NLS-1$
    portefeuilleIndividuel.setDateDernierImpact("20160219052345"); //$NON-NLS-1$
    portefeuilleIndividuel.setNoCompte("1101700000091"); //$NON-NLS-1$

    Pair<ServiceAccessible, ServiceCommercial> p = createProvInService("2/INACTIF"); //$NON-NLS-1$
    PIVOTREFERENCE pivotreferenceSA = new PIVOTREFERENCE();
    pivotreferenceSA.setIdref(p._first);
    portefeuilleIndividuel.getServiceAccessibles().add(pivotreferenceSA);

    Quadruplet quadruplet = new Quadruplet(portefeuilleIndividuel, "33600300091", "208201700000091", ActionProvisionner.ACTIVER_LIGNES); //$NON-NLS-1$ //$NON-NLS-2$

    ProvisionnerPfiIn provisionnerPfiIn = MarshallTools.unmarshall(ProvisionnerPfiIn.class, new File(IN_REQUEST_XML));

    TypeAction typeAction = new TypeAction();
    typeAction.setValeur("typeActionValeur"); //$NON-NLS-1$

    TypeServiceCommercialKPSA typeServiceCommercialKPSA = new TypeServiceCommercialKPSA();
    typeServiceCommercialKPSA.setIdServiceKPSA("SSBn"); //$NON-NLS-1$
    typeServiceCommercialKPSA.setAction(typeAction);

    TypeServiceCommercialMIM typeServiceCommercialMIM = new TypeServiceCommercialMIM();
    typeServiceCommercialMIM.setIdServiceMIM("2"); //$NON-NLS-1$
    typeServiceCommercialMIM.getServiceCommercialKPSAs().add(typeServiceCommercialKPSA);

    //Prepare mock
    EasyMock.expect(SvcCommMimProxy.getInstance()).andReturn(_svcCommMimConnector);
    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, "2")).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(typeServiceCommercialMIM, true)); //$NON-NLS-1$

    // On enregistre le scénario des appels
    PowerMock.replayAll();

    PM028BL300MimToInk currentInstance = new PM028BL300MimToInkBuilder().tracabilite(tracabilite).source(SOURCE_ID).orderid(ORDER_ID).flowid(FLOW_ID).quadrupletProvisionnerPfiIn(quadruplet).consulterPFIOut(new ConsulterPFIOut()).provisionnerPfiIn(provisionnerPfiIn).verbe(Diagnostic.PROVISIONNER_SERVICES.toString()).idtitf(IDTITF).iwsRessourcesInfoParamValue(DEFAULT_IWS_RESSOURCES_INFO).partitionSic(PARTITION_SIC).build();
    Request ret = currentInstance.execute(_currentInstance);

    PowerMock.verifyAll();

    checkResponse(RetourFactoryForTU.createOkRetour(), currentInstance.getRetour());
    checkINKProdResponse(createExpectedRequest(ORDER_ID, "2101700000091", true, PROV_VERB, ORIGINATOR_VALUE, 0, Diagnostic.PROVISIONNER_SERVICES.toString(), "GSMCSC", "GET"), ret); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

  }

  /**
   * Test le cas Nominal. <br/>
   * Alors: ServiceAccessibleStatut = INACTIF avec valid IMSI, IdServiceKPSA est du type SSBN<br/>
   *
   *
   * <b>Entrées:</b>Entrée valides.<br/>
   * <b>Attendu:</b>Resultat:OK;<br/>
   *
   * @throws RavelException
   *           on error
   */
  @Test
  public void PM028_BL300_MimToInk_test_006() throws RavelException
  {
    Tracabilite tracabilite = new Tracabilite(StringConstants.EMPTY_STRING, Test_Consts.DEFAULT_MSGID, "PROF", "nomPRocessus", "idProcessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$;

    PortefeuilleIndividuel portefeuilleIndividuel = new PortefeuilleIndividuel();
    portefeuilleIndividuel.setId("PFI-1"); //$NON-NLS-1$
    portefeuilleIndividuel.setDateDernierImpact("20160219052345"); //$NON-NLS-1$
    portefeuilleIndividuel.setNoCompte("1101700000091"); //$NON-NLS-1$

    Pair<ServiceAccessible, ServiceCommercial> p = createProvInService("2/INACTIF"); //$NON-NLS-1$
    PIVOTREFERENCE pivotreferenceSA = new PIVOTREFERENCE();
    pivotreferenceSA.setIdref(p._first);
    portefeuilleIndividuel.getServiceAccessibles().add(pivotreferenceSA);

    Quadruplet quadruplet = new Quadruplet(portefeuilleIndividuel, "33600300091", "208201700000091", ActionProvisionner.ACTIVER_LIGNES); //$NON-NLS-1$ //$NON-NLS-2$

    ProvisionnerPfiIn provisionnerPfiIn = MarshallTools.unmarshall(ProvisionnerPfiIn.class, new File(IN_REQUEST_XML));

    TypeAction typeAction = new TypeAction();
    typeAction.setValeur("typeActionValeur"); //$NON-NLS-1$

    TypeServiceCommercialKPSA typeServiceCommercialKPSA = new TypeServiceCommercialKPSA();
    typeServiceCommercialKPSA.setIdServiceKPSA("SSBn"); //$NON-NLS-1$
    typeServiceCommercialKPSA.setAction(typeAction);

    TypeServiceCommercialMIM typeServiceCommercialMIM = new TypeServiceCommercialMIM();
    typeServiceCommercialMIM.setIdServiceMIM("2"); //$NON-NLS-1$
    typeServiceCommercialMIM.getServiceCommercialKPSAs().add(typeServiceCommercialKPSA);

    //Prepare mock
    EasyMock.expect(SvcCommMimProxy.getInstance()).andReturn(_svcCommMimConnector);
    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, "2")).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(typeServiceCommercialMIM, true)); //$NON-NLS-1$

    // On enregistre le scénario des appels
    PowerMock.replayAll();

    PM028BL300MimToInk currentInstance = new PM028BL300MimToInkBuilder().tracabilite(tracabilite).source(SOURCE_ID).orderid(ORDER_ID).flowid(FLOW_ID).quadrupletProvisionnerPfiIn(quadruplet).consulterPFIOut(new ConsulterPFIOut()).provisionnerPfiIn(provisionnerPfiIn).verbe(Diagnostic.PROVISIONNER_SERVICES.toString()).idtitf(IDTITF).iwsRessourcesInfoParamValue(DEFAULT_IWS_RESSOURCES_INFO).partitionSic(PARTITION_SIC).build();
    Request ret = currentInstance.execute(_currentInstance);

    PowerMock.verifyAll();

    checkResponse(RetourFactoryForTU.createOkRetour(), currentInstance.getRetour());
    checkINKProdResponse(createExpectedRequest(ORDER_ID, "2101700000091", true, PROV_VERB, ORIGINATOR_VALUE, 0, Diagnostic.PROVISIONNER_SERVICES.toString(), "GSMCSC", "GET"), ret); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
  }

  /**
   * Test le cas Nominal. <br/>
   * Alors: ServiceAccessibleStatut = INACTIF avec valid IMSI, IdServiceKPSA different de SSBN<br/>
   *
   *
   * <b>Entrées:</b>Entrée valides.<br/>
   * <b>Attendu:</b>Resultat:OK;<br/>
   *
   * @throws RavelException
   *           on error
   */
  @Test
  public void PM028_BL300_MimToInk_test_007() throws RavelException
  {
    Tracabilite tracabilite = new Tracabilite(StringConstants.EMPTY_STRING, Test_Consts.DEFAULT_MSGID, "PROF", "nomPRocessus", "idProcessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$;

    PortefeuilleIndividuel portefeuilleIndividuel = new PortefeuilleIndividuel();
    portefeuilleIndividuel.setId("PFI-1"); //$NON-NLS-1$
    portefeuilleIndividuel.setDateDernierImpact("20160219052345"); //$NON-NLS-1$
    portefeuilleIndividuel.setNoCompte("1101700000091"); //$NON-NLS-1$

    Pair<ServiceAccessible, ServiceCommercial> p = createProvInService("2/INACTIF"); //$NON-NLS-1$
    PIVOTREFERENCE pivotreferenceSA = new PIVOTREFERENCE();
    pivotreferenceSA.setIdref(p._first);
    portefeuilleIndividuel.getServiceAccessibles().add(pivotreferenceSA);

    Quadruplet quadruplet = new Quadruplet(portefeuilleIndividuel, "33600300091", "208201700000091", ActionProvisionner.ACTIVER_LIGNES); //$NON-NLS-1$ //$NON-NLS-2$

    ProvisionnerPfiIn provisionnerPfiIn = MarshallTools.unmarshall(ProvisionnerPfiIn.class, new File("src/test/resources/provisionnerPfiIn_request2.xml")); //$NON-NLS-1$

    TypeAction typeAction = new TypeAction();
    typeAction.setValeur("typeActionValeur"); //$NON-NLS-1$

    TypeServiceCommercialKPSA typeServiceCommercialKPSA = new TypeServiceCommercialKPSA();
    typeServiceCommercialKPSA.setIdServiceKPSA("SSBn"); //$NON-NLS-1$
    typeServiceCommercialKPSA.setAction(typeAction);

    TypeServiceCommercialMIM typeServiceCommercialMIM = new TypeServiceCommercialMIM();
    typeServiceCommercialMIM.setIdServiceMIM("2"); //$NON-NLS-1$
    typeServiceCommercialMIM.getServiceCommercialKPSAs().add(typeServiceCommercialKPSA);

    //Prepare mock
    EasyMock.expect(SvcCommMimProxy.getInstance()).andReturn(_svcCommMimConnector);
    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, "2")).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(typeServiceCommercialMIM, true)); //$NON-NLS-1$

    // On enregistre le scénario des appels
    PowerMock.replayAll();

    PM028BL300MimToInk currentInstance = new PM028BL300MimToInkBuilder().tracabilite(tracabilite).source(SOURCE_ID).orderid(ORDER_ID).flowid(FLOW_ID).quadrupletProvisionnerPfiIn(quadruplet).consulterPFIOut(new ConsulterPFIOut()).provisionnerPfiIn(provisionnerPfiIn).verbe(Diagnostic.PROVISIONNER_SERVICES.toString()).idtitf(IDTITF).iwsRessourcesInfoParamValue(DEFAULT_IWS_RESSOURCES_INFO).partitionSic(PARTITION_SIC).build();
    Request ret = currentInstance.execute(_currentInstance);

    PowerMock.verifyAll();

    checkResponse(RetourFactoryForTU.createOkRetour(), currentInstance.getRetour());
    checkINKProdResponse(createExpectedRequest(ORDER_ID, "2101700000091", true, PROV_VERB, ORIGINATOR_VALUE, 0, Diagnostic.PROVISIONNER_SERVICES.toString(), "GSMCSC", "GET"), ret); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

  }

  /**
   * Test le cas Nominal. <br/>
   * Alors: ServiceAccessibleStatut = INACTIF avec valid IMSI, IdServiceKPSA different de SSBN<br/>
   *
   *
   * <b>Entrées:</b>Entrée valides.<br/>
   * <b>Attendu:</b>Resultat:OK;<br/>
   *
   * @throws RavelException
   *           on error
   */
  @Test
  public void PM028_BL300_MimToInk_test_008() throws RavelException
  {
    Tracabilite tracabilite = new Tracabilite(StringConstants.EMPTY_STRING, Test_Consts.DEFAULT_MSGID, "PROF", "nomPRocessus", "idProcessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$;

    PortefeuilleIndividuel portefeuilleIndividuel = new PortefeuilleIndividuel();
    portefeuilleIndividuel.setId("PFI-1"); //$NON-NLS-1$
    portefeuilleIndividuel.setDateDernierImpact("20160219052345"); //$NON-NLS-1$
    portefeuilleIndividuel.setNoCompte("1101700000091"); //$NON-NLS-1$

    Pair<ServiceAccessible, ServiceCommercial> p = createProvInService("2/INACTIF"); //$NON-NLS-1$
    PIVOTREFERENCE pivotreferenceSA = new PIVOTREFERENCE();
    pivotreferenceSA.setIdref(p._first);
    portefeuilleIndividuel.getServiceAccessibles().add(pivotreferenceSA);

    Quadruplet quadruplet = new Quadruplet(portefeuilleIndividuel, "33600300091", "208201700000091", ActionProvisionner.ACTIVER_LIGNES); //$NON-NLS-1$ //$NON-NLS-2$

    ProvisionnerPfiIn provisionnerPfiIn = MarshallTools.unmarshall(ProvisionnerPfiIn.class, new File("src/test/resources/provisionnerPfiIn_request3.xml")); //$NON-NLS-1$

    TypeAction typeAction = new TypeAction();
    typeAction.setValeur("typeActionValeur"); //$NON-NLS-1$

    TypeServiceCommercialKPSA typeServiceCommercialKPSA = new TypeServiceCommercialKPSA();
    typeServiceCommercialKPSA.setIdServiceKPSA("SSBn"); //$NON-NLS-1$
    typeServiceCommercialKPSA.setAction(typeAction);

    TypeServiceCommercialMIM typeServiceCommercialMIM = new TypeServiceCommercialMIM();
    typeServiceCommercialMIM.setIdServiceMIM("2"); //$NON-NLS-1$
    typeServiceCommercialMIM.getServiceCommercialKPSAs().add(typeServiceCommercialKPSA);

    //Prepare mock
    EasyMock.expect(SvcCommMimProxy.getInstance()).andReturn(_svcCommMimConnector);
    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, "2")).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(typeServiceCommercialMIM, true)); //$NON-NLS-1$

    // On enregistre le scénario des appels
    PowerMock.replayAll();

    PM028BL300MimToInk currentInstance = new PM028BL300MimToInkBuilder().tracabilite(tracabilite).source(SOURCE_ID).orderid(ORDER_ID).flowid(FLOW_ID).quadrupletProvisionnerPfiIn(quadruplet).consulterPFIOut(new ConsulterPFIOut()).provisionnerPfiIn(provisionnerPfiIn).verbe(Diagnostic.PROVISIONNER_SERVICES.toString()).idtitf(IDTITF).iwsRessourcesInfoParamValue(DEFAULT_IWS_RESSOURCES_INFO).partitionSic(PARTITION_SIC).build();
    Request ret = currentInstance.execute(_currentInstance);

    PowerMock.verifyAll();

    checkResponse(RetourFactoryForTU.createOkRetour(), currentInstance.getRetour());
    checkINKProdResponse(createExpectedRequest(ORDER_ID, "2101700000091", true, PROV_VERB, ORIGINATOR_VALUE, 0, Diagnostic.PROVISIONNER_SERVICES.toString(), "GSMCSC", "GET"), ret); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

  }

  /**
   * Test le cas Nominal. <br/>
   * Alors: ServiceAccessibleStatut = INACTIF avec valid IMSI, IdServiceKPSA different de SSBN<br/>
   *
   *
   * <b>Entrées:</b>Entrée valides.<br/>
   * <b>Attendu:</b>Resultat:OK;<br/>
   *
   * @throws RavelException
   *           on error
   */
  @Test
  public void PM028_BL300_MimToInk_test_009() throws RavelException
  {
    Tracabilite tracabilite = new Tracabilite(StringConstants.EMPTY_STRING, Test_Consts.DEFAULT_MSGID, "PROF", "nomPRocessus", "idProcessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$;

    PortefeuilleIndividuel portefeuilleIndividuel = new PortefeuilleIndividuel();
    portefeuilleIndividuel.setId("PFI-1"); //$NON-NLS-1$
    portefeuilleIndividuel.setDateDernierImpact("20160219052345"); //$NON-NLS-1$
    portefeuilleIndividuel.setNoCompte("11700000091"); //$NON-NLS-1$

    Pair<ServiceAccessible, ServiceCommercial> p = createProvInService("107/ACTIVE"); //$NON-NLS-1$
    PIVOTREFERENCE pivotreferenceSA = new PIVOTREFERENCE();
    pivotreferenceSA.setIdref(p._first);
    portefeuilleIndividuel.getServiceAccessibles().add(pivotreferenceSA);

    Quadruplet quadruplet = new Quadruplet(portefeuilleIndividuel, "33600300091", "208201700000091", ActionProvisionner.ACTIVER_LIGNES); //$NON-NLS-1$ //$NON-NLS-2$

    ProvisionnerPfiIn provisionnerPfiIn = buildProvisionnerPfiIn();

    TypeAction typeAction = new TypeAction();
    typeAction.setValeur("typeActionValeur"); //$NON-NLS-1$

    TypeServiceCommercialKPSA typeServiceCommercialKPSA = new TypeServiceCommercialKPSA();
    typeServiceCommercialKPSA.setIdServiceKPSA("SSBn"); //$NON-NLS-1$
    typeServiceCommercialKPSA.setAction(typeAction);

    TypeServiceCommercialMIM typeServiceCommercialMIM = new TypeServiceCommercialMIM();
    typeServiceCommercialMIM.setIdServiceMIM("107"); //$NON-NLS-1$
    typeServiceCommercialMIM.getServiceCommercialKPSAs().add(typeServiceCommercialKPSA);

    //Prepare mock
    EasyMock.expect(SvcCommMimProxy.getInstance()).andReturn(_svcCommMimConnector);
    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, "107")).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(typeServiceCommercialMIM, true)); //$NON-NLS-1$

    // On enregistre le scénario des appels
    PowerMock.replayAll();

    PM028BL300MimToInk currentInstance = new PM028BL300MimToInkBuilder().tracabilite(tracabilite).source(SOURCE_ID).orderid(ORDER_ID).flowid(FLOW_ID).quadrupletProvisionnerPfiIn(quadruplet).consulterPFIOut(new ConsulterPFIOut()).provisionnerPfiIn(provisionnerPfiIn).verbe(Diagnostic.PROVISIONNER_SERVICES.toString()).idtitf(IDTITF).iwsRessourcesInfoParamValue(DEFAULT_IWS_RESSOURCES_INFO).partitionSic(PARTITION_SIC).build();
    Request ret = currentInstance.execute(_currentInstance);

    PowerMock.verifyAll();

    checkResponse(RetourFactoryForTU.createOkRetour(), currentInstance.getRetour());
    checkINKResponse(createRequestINKResponse("2101700000091"), ret); //$NON-NLS-1$
  }

  /**
   * Test le cas Nominal. <br/>
   * Alors: ServiceAccessibleStatut = INACTIF avec valid IMSI, IdServiceKPSA different de SSBN <br/>
   *
   *
   * <b>Entrées:</b>Entrée valides.<br/>
   * <b>Attendu:</b>Resultat:OK;<br/>
   *
   * @throws RavelException
   *           on error
   * @throws IOException
   *           exception
   */
  @Test
  public void PM028_BL300_MimToInk_test_010() throws RavelException, IOException
  {
    Tracabilite tracabilite = new Tracabilite(StringConstants.EMPTY_STRING, Test_Consts.DEFAULT_MSGID, "PROF", "nomPRocessus", "idProcessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$;

    Quadruplet quadruplet = new Quadruplet(null, "33600300091", "208201700000091", ActionProvisionner.ACTIVER_LIGNES); //$NON-NLS-1$ //$NON-NLS-2$

    String fichier = new String(Files.readAllBytes(Paths.get("src/test/resources/consulterPFIoutTest.xml"))); //$NON-NLS-1$
    ConsulterPFIReponseType consulterPFIReponseType = MarshallTools.unmarshallAndBypassDTDValidation(ConsulterPFIReponseType.class, fichier);

    TypeParametre typeParametre = new TypeParametre();
    typeParametre.setIdParametreKPSA("SPARAM[7]"); //$NON-NLS-1$
    typeParametre.setConstante("constante"); //$NON-NLS-1$
    typeParametre.setIdParametreMIM("3"); //$NON-NLS-1$

    TypeParametres typeParametres = new TypeParametres();
    typeParametres.getParametres().add(typeParametre);

    TypeServiceCommercialKPSA typeServiceCommercialKPSA = new TypeServiceCommercialKPSA();
    typeServiceCommercialKPSA.setIdServiceKPSA("IdServiceKPSA"); //$NON-NLS-1$
    typeServiceCommercialKPSA.setParametres(typeParametres);

    TypeServiceCommercialMIM typeServiceCommercialMIM = new TypeServiceCommercialMIM();
    typeServiceCommercialMIM.setIdServiceMIM("78"); //$NON-NLS-1$
    typeServiceCommercialMIM.getServiceCommercialKPSAs().add(typeServiceCommercialKPSA);

    //Prepare mock
    EasyMock.expect(SvcCommMimProxy.getInstance()).andReturn(_svcCommMimConnector);
    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, "78")).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(typeServiceCommercialMIM, true)); //$NON-NLS-1$

    // On enregistre le scénario des appels
    PowerMock.replayAll();

    PM028BL300MimToInk currentInstance = new PM028BL300MimToInkBuilder().tracabilite(tracabilite).source(SOURCE_ID).orderid(ORDER_ID).flowid(FLOW_ID).quadrupletProvisionnerPfiIn(quadruplet).consulterPFIOut(consulterPFIReponseType.getConsulterPFIOut()).verbe(Diagnostic.RESYNCHRO_SI_NPBT.toString()).idtitf(IDTITF).iwsRessourcesInfoParamValue(DEFAULT_IWS_RESSOURCES_INFO).partitionSic(PARTITION_SIC).build();
    Request ret = currentInstance.execute(_currentInstance);

    PowerMock.verifyAll();

    checkResponse(RetourFactoryForTU.createOkRetour(), currentInstance.getRetour());
    checkINKProdResponse(createExpectedRequest(ORDER_ID, "2109813926364", true, PROV_VERB, ORIGINATOR_VALUE, 0, Diagnostic.RESYNCHRO_SI_NPBT.toString(), "SYNCHRO_SINPBT", "GET"), ret); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

  }

  /**
   * Test pour anomalie 319770
   *
   * @throws RavelException
   *           thrown exception
   */
  @Test
  public void PM028_BL300_MimToInk_test_011() throws RavelException
  {
    Tracabilite tracabilite = new Tracabilite(StringConstants.EMPTY_STRING, Test_Consts.DEFAULT_MSGID, "PROF", "nomPRocessus", "idProcessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$;

    PortefeuilleIndividuel portefeuilleIndividuel = new PortefeuilleIndividuel();
    portefeuilleIndividuel.setId("PFI-1"); //$NON-NLS-1$
    portefeuilleIndividuel.setDateDernierImpact("20160219052345"); //$NON-NLS-1$
    portefeuilleIndividuel.setNoCompte("11700000091"); //$NON-NLS-1$

    Pair<ServiceAccessible, ServiceCommercial> p = createProvInService("2/INACTIF"); //$NON-NLS-1$
    PIVOTREFERENCE pivotreferenceSA = new PIVOTREFERENCE();

    PIVOTREFERENCE pivotrefPA = new PIVOTREFERENCE();
    p._first.setPointAcces(pivotrefPA);
    LigneGsm ligneGsm = new LigneGsm();
    ligneGsm.setMsisdn("+33012345678"); //$NON-NLS-1$
    pivotrefPA.setIdref(ligneGsm);
    pivotreferenceSA.setIdref(p._first);

    portefeuilleIndividuel.getServiceAccessibles().add(pivotreferenceSA);

    Quadruplet quadruplet = new Quadruplet(portefeuilleIndividuel, "33600300091", "208201700000091", ActionProvisionner.ACTIVER_LIGNES); //$NON-NLS-1$ //$NON-NLS-2$

    ProvisionnerPfiIn provisionnerPfiIn = MarshallTools.unmarshall(ProvisionnerPfiIn.class, new File(IN_REQUEST_XML));

    TypeParametre typeParametre = new TypeParametre();
    typeParametre.setIdParametreKPSA("SPARAM[0]"); //$NON-NLS-1$
    typeParametre.setConstante("24"); //$NON-NLS-1$

    TypeParametre typeParametre2 = new TypeParametre();
    typeParametre2.setIdParametreKPSA("MSISDN"); //$NON-NLS-1$

    TypeParametres typeParametres = new TypeParametres();
    typeParametres.getParametres().add(typeParametre);
    typeParametres.getParametres().add(typeParametre2);

    TypeServiceCommercialKPSA typeServiceCommercialKPSA = new TypeServiceCommercialKPSA();
    typeServiceCommercialKPSA.setIdServiceKPSA("PBS62T"); //$NON-NLS-1$
    typeServiceCommercialKPSA.setParametres(typeParametres);

    TypeServiceCommercialMIM typeServiceCommercialMIM = new TypeServiceCommercialMIM();
    typeServiceCommercialMIM.setIdServiceMIM("16"); //$NON-NLS-1$
    typeServiceCommercialMIM.getServiceCommercialKPSAs().add(typeServiceCommercialKPSA);

    //Prepare mock
    EasyMock.expect(SvcCommMimProxy.getInstance()).andReturn(_svcCommMimConnector);
    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, "2")).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(typeServiceCommercialMIM, true)); //$NON-NLS-1$

    // On enregistre le scénario des appels
    PowerMock.replayAll();

    PM028BL300MimToInk currentInstance = new PM028BL300MimToInkBuilder().tracabilite(tracabilite).source(SOURCE_ID).orderid(ORDER_ID).flowid(FLOW_ID).quadrupletProvisionnerPfiIn(quadruplet).provisionnerPfiIn(provisionnerPfiIn).consulterPFIOut(new ConsulterPFIOut()).verbe(Diagnostic.PROVISIONNER_SERVICES.toString()).idtitf(IDTITF).iwsRessourcesInfoParamValue(DEFAULT_IWS_RESSOURCES_INFO).partitionSic(PARTITION_SIC).build();
    Request ret = currentInstance.execute(_currentInstance);

    PowerMock.verifyAll();

    checkResponse(RetourFactoryForTU.createOkRetour(), currentInstance.getRetour());
    checkINKProdResponse(createExpectedRequest(ORDER_ID, "2101700000091", true, PROV_VERB, ORIGINATOR_VALUE, 0, Diagnostic.PROVISIONNER_SERVICES.toString(), "GSMCSC", "GET"), ret); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
  }

  /**
   * Test le cas d'un changement MSISDN <br/>
   *
   * @throws RavelException
   *           on error
   */
  @Test
  public void PM028_BL300_MimToInk_test_012() throws RavelException
  {
    Tracabilite tracabilite = new Tracabilite(StringConstants.EMPTY_STRING, Test_Consts.DEFAULT_MSGID, "PROF", "nomPRocessus", "idProcessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$;

    PortefeuilleIndividuel portefeuilleIndividuel = new PortefeuilleIndividuel();
    portefeuilleIndividuel.setId("PFI-1"); //$NON-NLS-1$
    portefeuilleIndividuel.setDateDernierImpact("20160219052345"); //$NON-NLS-1$
    portefeuilleIndividuel.setNoCompte("11700000091"); //$NON-NLS-1$

    Pair<ServiceAccessible, ServiceCommercial> p = createProvInService("78/INACTIF"); //$NON-NLS-1$
    PIVOTREFERENCE pivotreferenceSA = new PIVOTREFERENCE();

    PIVOTREFERENCE pivotrefPA = new PIVOTREFERENCE();
    p._first.setPointAcces(pivotrefPA);
    LigneGsm ligneGsm = new LigneGsm();
    ligneGsm.setMsisdn("+33012345678"); //$NON-NLS-1$
    ligneGsm.setStatut(PointAccesStatut.RESILIE);
    pivotrefPA.setIdref(ligneGsm);
    pivotreferenceSA.setIdref(p._first);
    portefeuilleIndividuel.getServiceAccessibles().add(pivotreferenceSA);

    portefeuilleIndividuel.getPointAcces().add(pivotrefPA);

    pivotrefPA = new PIVOTREFERENCE();
    p._first.setPointAcces(pivotrefPA);
    ligneGsm = new LigneGsm();
    ligneGsm.setMsisdn("+33012345679"); //$NON-NLS-1$
    ligneGsm.setStatut(PointAccesStatut.ACTIVE);
    pivotrefPA.setIdref(ligneGsm);
    portefeuilleIndividuel.getPointAcces().add(pivotrefPA);

    Quadruplet quadruplet = new Quadruplet(portefeuilleIndividuel, "33600300091", "208201700000091", ActionProvisionner.CHANGER_MSISDN); //$NON-NLS-1$ //$NON-NLS-2$

    ProvisionnerPfiIn provisionnerPfiIn = MarshallTools.unmarshall(ProvisionnerPfiIn.class, new File(IN_REQUEST_XML));

    TypeParametre typeParametre = new TypeParametre();
    typeParametre.setIdParametreKPSA("SPARAM[7]"); //$NON-NLS-1$
    typeParametre.setConstante("constante"); //$NON-NLS-1$
    typeParametre.setIdParametreMIM("3"); //$NON-NLS-1$

    TypeParametres typeParametres = new TypeParametres();
    typeParametres.getParametres().add(typeParametre);

    TypeServiceCommercialKPSA typeServiceCommercialKPSA = new TypeServiceCommercialKPSA();
    typeServiceCommercialKPSA.setIdServiceKPSA("IdServiceKPSA"); //$NON-NLS-1$
    typeServiceCommercialKPSA.setParametres(typeParametres);

    TypeServiceCommercialMIM typeServiceCommercialMIM = new TypeServiceCommercialMIM();
    typeServiceCommercialMIM.setIdServiceMIM("78"); //$NON-NLS-1$
    typeServiceCommercialMIM.getServiceCommercialKPSAs().add(typeServiceCommercialKPSA);

    //Prepare mock
    EasyMock.expect(SvcCommMimProxy.getInstance()).andReturn(_svcCommMimConnector);
    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, "78")).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(typeServiceCommercialMIM, true)); //$NON-NLS-1$

    // On enregistre le scénario des appels
    PowerMock.replayAll();

    PM028BL300MimToInk currentInstance = new PM028BL300MimToInkBuilder().tracabilite(tracabilite).source(SOURCE_ID).orderid(ORDER_ID).flowid(FLOW_ID).quadrupletProvisionnerPfiIn(quadruplet).provisionnerPfiIn(provisionnerPfiIn).verbe(Diagnostic.PROVISIONNER_SERVICES.toString()).idtitf(IDTITF).iwsRessourcesInfoParamValue(DEFAULT_IWS_RESSOURCES_INFO).partitionSic(PARTITION_SIC).build();
    Request ret = currentInstance.execute(_currentInstance);

    PowerMock.verifyAll();

    checkResponse(RetourFactoryForTU.createOkRetour(), currentInstance.getRetour());

    String productName = "GSMCSC"; //$NON-NLS-1$
    Request expectedRequest = createExpectedRequest(ORDER_ID, "2101700000091", true, PROV_VERB, ORIGINATOR_VALUE, 0, Diagnostic.PROVISIONNER_SERVICES.toString(), productName, "GET"); //$NON-NLS-1$ //$NON-NLS-2$

    checkINKProdResponse(expectedRequest, ret);

    //So
    ServiceOrderRequest soExpected = expectedRequest.getSo();
    ServiceOrderRequest soActual = ret.getSo();
    Assert.assertEquals(soExpected.getOrderId(), soActual.getOrderId());

    //SOD
    Assert.assertEquals(soExpected.getSod().getVerb(), soActual.getSod().getVerb());
    Assert.assertNotNull(soActual.getSod().getDataset().getParams());
    Assert.assertTrue(!soActual.getSod().getDataset().getParams().isEmpty());
    Assert.assertEquals("33012345678", getParam(soActual.getSod().getDataset().getParams(), MSISDN).getValue()); //$NON-NLS-1$
    Assert.assertEquals("33012345679", getParam(soActual.getSod().getDataset().getParams(), NOUV_MSISDN).getValue()); //$NON-NLS-1$
    Assert.assertEquals(ORDER_ID + ".msg", getParam(soActual.getSod().getDataset().getParams(), EDIFACT_FILE_NAME).getValue()); //$NON-NLS-1$
    Assert.assertEquals(productName, getParam(soActual.getSod().getDataset().getParams(), MESSAGE_TYPE).getValue());
  }

  /**
   * Test le cas d'un changement IMSI <br/>
   *
   * @throws RavelException
   *           on error
   * @throws IOException
   *           exception
   */
  @Test
  public void PM028_BL300_MimToInk_test_013() throws RavelException, IOException
  {
    Tracabilite tracabilite = new Tracabilite(StringConstants.EMPTY_STRING, Test_Consts.DEFAULT_MSGID, "PROF", "nomPRocessus", "idProcessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$;

    PortefeuilleIndividuel portefeuilleIndividuel = new PortefeuilleIndividuel();
    portefeuilleIndividuel.setId("PFI-1"); //$NON-NLS-1$
    portefeuilleIndividuel.setDateDernierImpact("20160219052345"); //$NON-NLS-1$
    portefeuilleIndividuel.setNoCompte("10054013113"); //$NON-NLS-1$

    Pair<ServiceAccessible, ServiceCommercial> p = createProvInService("78/INACTIF"); //$NON-NLS-1$
    PIVOTREFERENCE pivotreferenceSA = new PIVOTREFERENCE();

    PIVOTREFERENCE pivotrefPA = new PIVOTREFERENCE();
    p._first.setPointAcces(pivotrefPA);
    LigneGsm ligneGsm = new LigneGsm();
    ligneGsm.setMsisdn("+33012345678"); //$NON-NLS-1$
    ligneGsm.setStatut(PointAccesStatut.RESILIE);

    SimLogique simLogique = new SimLogique();
    simLogique.setId("SIM-1"); //$NON-NLS-1$
    simLogique.setStatut(SimLogiqueStatut.RESILIE);
    simLogique.setImsi("208209813926364"); //$NON-NLS-1$
    PIVOTREFERENCE pivotreference = new PIVOTREFERENCE();
    pivotreference.setIdref(simLogique);
    ligneGsm.getSimLogiques().add(pivotreference);

    simLogique = new SimLogique();
    simLogique.setId("SIM-2"); //$NON-NLS-1$
    simLogique.setStatut(SimLogiqueStatut.ACTIVE);
    pivotreference = new PIVOTREFERENCE();
    pivotreference.setIdref(simLogique);
    ligneGsm.getSimLogiques().add(pivotreference);

    pivotrefPA.setIdref(ligneGsm);
    pivotreferenceSA.setIdref(p._first);
    portefeuilleIndividuel.getServiceAccessibles().add(pivotreferenceSA);

    portefeuilleIndividuel.getPointAcces().add(pivotrefPA);

    pivotrefPA = new PIVOTREFERENCE();
    p._first.setPointAcces(pivotrefPA);
    ligneGsm = new LigneGsm();
    ligneGsm.setMsisdn("+33012345679"); //$NON-NLS-1$
    ligneGsm.setStatut(PointAccesStatut.ACTIVE);

    simLogique = new SimLogique();
    simLogique.setId("SIM-1"); //$NON-NLS-1$
    simLogique.setStatut(SimLogiqueStatut.RESILIE);
    simLogique.setImsi("208209813926364"); //$NON-NLS-1$
    pivotreference = new PIVOTREFERENCE();
    pivotreference.setIdref(simLogique);
    ligneGsm.getSimLogiques().add(pivotreference);

    simLogique = new SimLogique();
    simLogique.setId("SIM-2"); //$NON-NLS-1$
    simLogique.setStatut(SimLogiqueStatut.ACTIVE);
    pivotreference = new PIVOTREFERENCE();
    pivotreference.setIdref(simLogique);
    ligneGsm.getSimLogiques().add(pivotreference);

    pivotrefPA.setIdref(ligneGsm);
    portefeuilleIndividuel.getPointAcces().add(pivotrefPA);

    Quadruplet quadruplet = new Quadruplet(portefeuilleIndividuel, "33600300091", "208201700000091", ActionProvisionner.CHANGER_IMSI); //$NON-NLS-1$ //$NON-NLS-2$

    String fichier = new String(Files.readAllBytes(Paths.get("src/test/resources/consulterPFIoutTest3.xml"))); //$NON-NLS-1$
    ConsulterPFIReponseType consulterPFIReponseType = MarshallTools.unmarshallAndBypassDTDValidation(ConsulterPFIReponseType.class, fichier);

    TypeParametre typeParametre = new TypeParametre();
    typeParametre.setIdParametreKPSA("SPARAM[7]"); //$NON-NLS-1$
    typeParametre.setConstante("constante"); //$NON-NLS-1$
    typeParametre.setIdParametreMIM("3"); //$NON-NLS-1$

    TypeParametres typeParametres = new TypeParametres();
    typeParametres.getParametres().add(typeParametre);

    TypeServiceCommercialKPSA typeServiceCommercialKPSA = new TypeServiceCommercialKPSA();
    typeServiceCommercialKPSA.setIdServiceKPSA("IdServiceKPSA"); //$NON-NLS-1$
    typeServiceCommercialKPSA.setParametres(typeParametres);

    TypeServiceCommercialMIM typeServiceCommercialMIM = new TypeServiceCommercialMIM();
    typeServiceCommercialMIM.setIdServiceMIM("78"); //$NON-NLS-1$
    typeServiceCommercialMIM.getServiceCommercialKPSAs().add(typeServiceCommercialKPSA);

    //Prepare mock
    EasyMock.expect(SvcCommMimProxy.getInstance()).andReturn(_svcCommMimConnector);
    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, "78")).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(typeServiceCommercialMIM, true)); //$NON-NLS-1$

    // On enregistre le scénario des appels
    PowerMock.replayAll();

    PM028BL300MimToInk currentInstance = new PM028BL300MimToInkBuilder().tracabilite(tracabilite).source(SOURCE_ID).orderid(ORDER_ID).flowid(FLOW_ID).quadrupletProvisionnerPfiIn(quadruplet).consulterPFIOut(consulterPFIReponseType.getConsulterPFIOut()).provisionnerPfiIn(buildProvisionnerPfiIn()).verbe(ActionProvisionner.CHANGER_IMSI.getAction()).idtitf(IDTITF).iwsRessourcesInfoParamValue(DEFAULT_IWS_RESSOURCES_INFO).partitionSic(PARTITION_SIC).build();
    Request ret = currentInstance.execute(_currentInstance);

    PowerMock.verifyAll();

    checkResponse(RetourFactoryForTU.createOkRetour(), currentInstance.getRetour());

    String customerId = "2101700000091"; //$NON-NLS-1$
    String verbe = "ChangerPointAcces"; //$NON-NLS-1$
    String productName = "GSMCCS"; //$NON-NLS-1$
    Request expectedRequest = createExpectedRequest(ORDER_ID, customerId, true, PROV_VERB, ORIGINATOR_VALUE, 0, verbe, productName, "GET"); //$NON-NLS-1$

    checkINKProdResponse(expectedRequest, ret);

    //So
    ServiceOrderRequest soExpected = expectedRequest.getSo();
    ServiceOrderRequest soActual = ret.getSo();
    Assert.assertEquals(soExpected.getOrderId(), soActual.getOrderId());

    //SOD
    Assert.assertEquals(soExpected.getSod().getVerb(), soActual.getSod().getVerb());
    Assert.assertNotNull(soActual.getSod().getDataset().getParams());
    Assert.assertTrue(!soActual.getSod().getDataset().getParams().isEmpty());
    Assert.assertEquals("208209813926364", getParam(soActual.getSod().getDataset().getParams(), IMSI).getValue()); //$NON-NLS-1$
    Assert.assertEquals(ORDER_ID + ".msg", getParam(soActual.getSod().getDataset().getParams(), EDIFACT_FILE_NAME).getValue()); //$NON-NLS-1$
    Assert.assertEquals(productName, getParam(soActual.getSod().getDataset().getParams(), MESSAGE_TYPE).getValue());
  }

  /**
   * Test le cas de verbe ActiverLignes <br/>
   *
   * @throws RavelException
   *           on error
   * @throws IOException
   *           exception
   */
  @Test
  public void PM028_BL300_MimToInk_test_014() throws RavelException, IOException
  {
    Tracabilite tracabilite = new Tracabilite(StringConstants.EMPTY_STRING, Test_Consts.DEFAULT_MSGID, "PROF", "nomPRocessus", "idProcessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$;

    PortefeuilleIndividuel portefeuilleIndividuel = new PortefeuilleIndividuel();
    portefeuilleIndividuel.setId("PFI-1"); //$NON-NLS-1$
    portefeuilleIndividuel.setDateDernierImpact("20160219052345"); //$NON-NLS-1$
    portefeuilleIndividuel.setNoCompte("10054013113"); //$NON-NLS-1$

    Pair<ServiceAccessible, ServiceCommercial> p = createProvInService("78/INACTIF"); //$NON-NLS-1$
    PIVOTREFERENCE pivotreferenceSA = new PIVOTREFERENCE();

    PIVOTREFERENCE pivotrefPA = new PIVOTREFERENCE();
    p._first.setPointAcces(pivotrefPA);
    LigneGsm ligneGsm = new LigneGsm();
    ligneGsm.setMsisdn("+33012345678"); //$NON-NLS-1$
    ligneGsm.setStatut(PointAccesStatut.RESILIE);

    SimLogique simLogique = new SimLogique();
    simLogique.setId("SIM-1"); //$NON-NLS-1$
    simLogique.setStatut(SimLogiqueStatut.RESILIE);
    simLogique.setImsi("208209813926364"); //$NON-NLS-1$
    PIVOTREFERENCE pivotreference = new PIVOTREFERENCE();
    pivotreference.setIdref(simLogique);
    ligneGsm.getSimLogiques().add(pivotreference);

    simLogique = new SimLogique();
    simLogique.setId("SIM-2"); //$NON-NLS-1$
    simLogique.setStatut(SimLogiqueStatut.ACTIVE);
    pivotreference = new PIVOTREFERENCE();
    pivotreference.setIdref(simLogique);
    ligneGsm.getSimLogiques().add(pivotreference);

    pivotrefPA.setIdref(ligneGsm);
    pivotreferenceSA.setIdref(p._first);
    portefeuilleIndividuel.getServiceAccessibles().add(pivotreferenceSA);

    portefeuilleIndividuel.getPointAcces().add(pivotrefPA);

    pivotrefPA = new PIVOTREFERENCE();
    p._first.setPointAcces(pivotrefPA);
    ligneGsm = new LigneGsm();
    ligneGsm.setMsisdn("+33012345679"); //$NON-NLS-1$
    ligneGsm.setStatut(PointAccesStatut.ACTIVE);

    simLogique = new SimLogique();
    simLogique.setId("SIM-1"); //$NON-NLS-1$
    simLogique.setStatut(SimLogiqueStatut.RESILIE);
    simLogique.setImsi("208209813926364"); //$NON-NLS-1$
    pivotreference = new PIVOTREFERENCE();
    pivotreference.setIdref(simLogique);
    ligneGsm.getSimLogiques().add(pivotreference);

    simLogique = new SimLogique();
    simLogique.setId("SIM-2"); //$NON-NLS-1$
    simLogique.setStatut(SimLogiqueStatut.ACTIVE);
    pivotreference = new PIVOTREFERENCE();
    pivotreference.setIdref(simLogique);
    ligneGsm.getSimLogiques().add(pivotreference);

    pivotrefPA.setIdref(ligneGsm);
    portefeuilleIndividuel.getPointAcces().add(pivotrefPA);

    Quadruplet quadruplet = new Quadruplet(portefeuilleIndividuel, "33600300091", "208201700000091", ActionProvisionner.CHANGER_IMSI); //$NON-NLS-1$ //$NON-NLS-2$

    String fichier = new String(Files.readAllBytes(Paths.get("src/test/resources/consulterPFIoutTest3.xml"))); //$NON-NLS-1$
    ConsulterPFIReponseType consulterPFIReponseType = MarshallTools.unmarshallAndBypassDTDValidation(ConsulterPFIReponseType.class, fichier);

    TypeParametre typeParametre = new TypeParametre();
    typeParametre.setIdParametreKPSA("SPARAM[7]"); //$NON-NLS-1$
    typeParametre.setConstante("constante"); //$NON-NLS-1$
    typeParametre.setIdParametreMIM("3"); //$NON-NLS-1$

    TypeParametres typeParametres = new TypeParametres();
    typeParametres.getParametres().add(typeParametre);

    TypeServiceCommercialKPSA typeServiceCommercialKPSA = new TypeServiceCommercialKPSA();
    typeServiceCommercialKPSA.setIdServiceKPSA("IdServiceKPSA"); //$NON-NLS-1$
    typeServiceCommercialKPSA.setParametres(typeParametres);

    TypeServiceCommercialMIM typeServiceCommercialMIM = new TypeServiceCommercialMIM();
    typeServiceCommercialMIM.setIdServiceMIM("78"); //$NON-NLS-1$
    typeServiceCommercialMIM.getServiceCommercialKPSAs().add(typeServiceCommercialKPSA);

    //Prepare mock
    EasyMock.expect(SvcCommMimProxy.getInstance()).andReturn(_svcCommMimConnector);
    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, "78")).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(typeServiceCommercialMIM, true)); //$NON-NLS-1$

    // On enregistre le scénario des appels
    PowerMock.replayAll();

    PM028BL300MimToInk currentInstance = new PM028BL300MimToInkBuilder().tracabilite(tracabilite).source(SOURCE_ID).orderid(ORDER_ID).flowid(FLOW_ID).quadrupletProvisionnerPfiIn(quadruplet).consulterPFIOut(consulterPFIReponseType.getConsulterPFIOut()).provisionnerPfiIn(buildProvisionnerPfiIn()).verbe(ActionProvisionner.ACTIVER_LIGNES.getAction()).idtitf(IDTITF).iwsRessourcesInfoParamValue(DEFAULT_IWS_RESSOURCES_INFO).partitionSic(PARTITION_SIC).build();
    Request ret = currentInstance.execute(_currentInstance);

    PowerMock.verifyAll();

    checkResponse(RetourFactoryForTU.createOkRetour(), currentInstance.getRetour());

    String customerId = "2101700000091"; //$NON-NLS-1$
    String verbe = "ActiverLignes"; //$NON-NLS-1$
    String productName = "GSMCAP"; //$NON-NLS-1$
    Request expectedRequest = createExpectedRequest(ORDER_ID, customerId, true, PROV_VERB, ORIGINATOR_VALUE, 0, verbe, productName, "GET"); //$NON-NLS-1$

    checkINKProdResponse(expectedRequest, ret);

    //So
    ServiceOrderRequest soExpected = expectedRequest.getSo();
    ServiceOrderRequest soActual = ret.getSo();
    Assert.assertEquals(soExpected.getOrderId(), soActual.getOrderId());

    //SOD
    Assert.assertEquals(soExpected.getSod().getVerb(), soActual.getSod().getVerb());
    Assert.assertNotNull(soActual.getSod().getDataset().getParams());
    Assert.assertTrue(!soActual.getSod().getDataset().getParams().isEmpty());
    Assert.assertEquals("208209813926364", getParam(soActual.getSod().getDataset().getParams(), IMSI).getValue()); //$NON-NLS-1$
    Assert.assertEquals(ORDER_ID + ".msg", getParam(soActual.getSod().getDataset().getParams(), EDIFACT_FILE_NAME).getValue()); //$NON-NLS-1$
    Assert.assertEquals(productName, getParam(soActual.getSod().getDataset().getParams(), MESSAGE_TYPE).getValue());
  }

  /**
   * Test le cas de verbe ActiverLignes <br/>
   *
   * @throws RavelException
   *           on error
   * @throws IOException
   *           exception
   */
  @Test
  public void PM028_BL300_MimToInk_test_015() throws RavelException, IOException
  {
    Tracabilite tracabilite = new Tracabilite(StringConstants.EMPTY_STRING, Test_Consts.DEFAULT_MSGID, "PROF", "nomPRocessus", "idProcessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$;

    PortefeuilleIndividuel portefeuilleIndividuel = new PortefeuilleIndividuel();
    portefeuilleIndividuel.setId("PFI-1"); //$NON-NLS-1$
    portefeuilleIndividuel.setDateDernierImpact("20160219052345"); //$NON-NLS-1$
    portefeuilleIndividuel.setNoCompte("10054013113"); //$NON-NLS-1$

    Pair<ServiceAccessible, ServiceCommercial> p = createProvInService("78/ACTIVE"); //$NON-NLS-1$
    PIVOTREFERENCE pivotreferenceSA = new PIVOTREFERENCE();

    PIVOTREFERENCE pivotrefPA = new PIVOTREFERENCE();
    p._first.setPointAcces(pivotrefPA);
    LigneGsm ligneGsm = new LigneGsm();
    ligneGsm.setMsisdn("+33012345678"); //$NON-NLS-1$
    ligneGsm.setStatut(PointAccesStatut.RESILIE);

    SimLogique simLogique = new SimLogique();
    simLogique.setId("SIM-1"); //$NON-NLS-1$
    simLogique.setStatut(SimLogiqueStatut.RESILIE);
    simLogique.setImsi("208209813926364"); //$NON-NLS-1$
    PIVOTREFERENCE pivotreference = new PIVOTREFERENCE();
    pivotreference.setIdref(simLogique);
    ligneGsm.getSimLogiques().add(pivotreference);

    simLogique = new SimLogique();
    simLogique.setId("SIM-2"); //$NON-NLS-1$
    simLogique.setStatut(SimLogiqueStatut.ACTIVE);
    pivotreference = new PIVOTREFERENCE();
    pivotreference.setIdref(simLogique);
    ligneGsm.getSimLogiques().add(pivotreference);

    pivotrefPA.setIdref(ligneGsm);
    pivotreferenceSA.setIdref(p._first);
    portefeuilleIndividuel.getServiceAccessibles().add(pivotreferenceSA);

    portefeuilleIndividuel.getPointAcces().add(pivotrefPA);

    pivotrefPA = new PIVOTREFERENCE();
    p._first.setPointAcces(pivotrefPA);
    ligneGsm = new LigneGsm();
    ligneGsm.setMsisdn("+33012345679"); //$NON-NLS-1$
    ligneGsm.setStatut(PointAccesStatut.ACTIVE);

    simLogique = new SimLogique();
    simLogique.setId("SIM-1"); //$NON-NLS-1$
    simLogique.setStatut(SimLogiqueStatut.RESILIE);
    simLogique.setImsi("208209813926364"); //$NON-NLS-1$
    pivotreference = new PIVOTREFERENCE();
    pivotreference.setIdref(simLogique);
    ligneGsm.getSimLogiques().add(pivotreference);

    simLogique = new SimLogique();
    simLogique.setId("SIM-2"); //$NON-NLS-1$
    simLogique.setStatut(SimLogiqueStatut.ACTIVE);
    pivotreference = new PIVOTREFERENCE();
    pivotreference.setIdref(simLogique);
    ligneGsm.getSimLogiques().add(pivotreference);

    pivotrefPA.setIdref(ligneGsm);
    portefeuilleIndividuel.getPointAcces().add(pivotrefPA);

    Quadruplet quadruplet = new Quadruplet(portefeuilleIndividuel, "33600300091", "208201700000091", ActionProvisionner.CHANGER_IMSI); //$NON-NLS-1$ //$NON-NLS-2$

    String fichier = new String(Files.readAllBytes(Paths.get("src/test/resources/consulterPFIoutTest3.xml"))); //$NON-NLS-1$
    ConsulterPFIReponseType consulterPFIReponseType = MarshallTools.unmarshallAndBypassDTDValidation(ConsulterPFIReponseType.class, fichier);

    TypeParametre typeParametre = new TypeParametre();
    typeParametre.setIdParametreKPSA("parametre"); //$NON-NLS-1$
    typeParametre.setConstante("constante"); //$NON-NLS-1$
    typeParametre.setIdParametreMIM("3"); //$NON-NLS-1$

    TypeParametres typeParametres = new TypeParametres();
    typeParametres.getParametres().add(typeParametre);

    TypeServiceCommercialKPSA typeServiceCommercialKPSA = new TypeServiceCommercialKPSA();
    typeServiceCommercialKPSA.setIdServiceKPSA("IdServiceKPSA"); //$NON-NLS-1$
    typeServiceCommercialKPSA.setParametres(typeParametres);

    TypeServiceCommercialMIM typeServiceCommercialMIM = new TypeServiceCommercialMIM();
    typeServiceCommercialMIM.setIdServiceMIM("78"); //$NON-NLS-1$
    typeServiceCommercialMIM.getServiceCommercialKPSAs().add(typeServiceCommercialKPSA);

    //Prepare mock
    EasyMock.expect(SvcCommMimProxy.getInstance()).andReturn(_svcCommMimConnector);
    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, "78")).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(typeServiceCommercialMIM, true)); //$NON-NLS-1$

    // On enregistre le scénario des appels
    PowerMock.replayAll();

    PM028BL300MimToInk currentInstance = new PM028BL300MimToInkBuilder().tracabilite(tracabilite).source(SOURCE_ID).orderid(ORDER_ID).flowid(FLOW_ID).quadrupletProvisionnerPfiIn(quadruplet).consulterPFIOut(consulterPFIReponseType.getConsulterPFIOut()).provisionnerPfiIn(buildProvisionnerPfiIn()).verbe(ActionProvisionner.ACTIVER_LIGNES.getAction()).idtitf(IDTITF).iwsRessourcesInfoParamValue(DEFAULT_IWS_RESSOURCES_INFO).partitionSic(PARTITION_SIC).build();
    Request ret = currentInstance.execute(_currentInstance);

    PowerMock.verifyAll();

    checkResponse(RetourFactoryForTU.createOkRetour(), currentInstance.getRetour());

    String customerId = "2101700000091"; //$NON-NLS-1$
    String verbe = "ActiverLignes"; //$NON-NLS-1$
    String productName = "GSMCAP"; //$NON-NLS-1$
    Request expectedRequest = createExpectedRequest(ORDER_ID, customerId, true, PROV_VERB, ORIGINATOR_VALUE, 0, verbe, productName, "GET"); //$NON-NLS-1$

    checkINKProdResponse(expectedRequest, ret);

    //So
    ServiceOrderRequest soExpected = expectedRequest.getSo();
    ServiceOrderRequest soActual = ret.getSo();
    Assert.assertEquals(soExpected.getOrderId(), soActual.getOrderId());

    //SOD
    Assert.assertEquals(soExpected.getSod().getVerb(), soActual.getSod().getVerb());
    Assert.assertNotNull(soActual.getSod().getDataset().getParams());
    Assert.assertTrue(!soActual.getSod().getDataset().getParams().isEmpty());
    Assert.assertEquals("208209813926364", getParam(soActual.getSod().getDataset().getParams(), IMSI).getValue()); //$NON-NLS-1$
    Assert.assertEquals(ORDER_ID + ".msg", getParam(soActual.getSod().getDataset().getParams(), EDIFACT_FILE_NAME).getValue()); //$NON-NLS-1$
    Assert.assertEquals(productName, getParam(soActual.getSod().getDataset().getParams(), MESSAGE_TYPE).getValue());
    Assert.assertEquals("constante", getParam(soActual.getSod().getDataset().getParams(), "IdServiceKPSA.R.parametre").getValue()); //$NON-NLS-1$ //$NON-NLS-2$
  }

  /**
   * Test le cas Nominal. <br/>
   * Alors: ServiceAccessibleStatut = INACTIF avec valid IMSI, IdServiceKPSA different de SSBN <br/>
   *
   *
   * <b>Entrées:</b>Entrée valides.<br/>
   * <b>Attendu:</b>Resultat:OK;<br/>
   *
   * @throws RavelException
   *           on error
   * @throws IOException
   *           exception
   */
  @Test
  public void PM028_BL300_MimToInk_test_016() throws RavelException, IOException
  {
    Tracabilite tracabilite = new Tracabilite(StringConstants.EMPTY_STRING, Test_Consts.DEFAULT_MSGID, "PROF", "nomPRocessus", "idProcessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$;

    Quadruplet quadruplet = new Quadruplet(null, "33600300091", "208201700000091", ActionProvisionner.ACTIVER_LIGNES); //$NON-NLS-1$ //$NON-NLS-2$

    String fichier = new String(Files.readAllBytes(Paths.get("src/test/resources/consulterPFIoutTest.xml"))); //$NON-NLS-1$
    ConsulterPFIReponseType consulterPFIReponseType = MarshallTools.unmarshallAndBypassDTDValidation(ConsulterPFIReponseType.class, fichier);
    ((com.bouygtel.refcli.consulterpfi.out.ServiceAccessible) consulterPFIReponseType.getConsulterPFIOut().getDonneesMetier().getPortefeuilleIndividuel().getServiceAccessibles().get(0).getIdref()).setStatut(EnumTypeStatutServiceAccessible.ACTIVE);

    TypeParametre typeParametre = new TypeParametre();
    typeParametre.setIdParametreKPSA("parametre"); //$NON-NLS-1$
    typeParametre.setConstante("constante"); //$NON-NLS-1$
    typeParametre.setIdParametreMIM("3"); //$NON-NLS-1$

    TypeParametres typeParametres = new TypeParametres();
    typeParametres.getParametres().add(typeParametre);

    TypeServiceCommercialKPSA typeServiceCommercialKPSA = new TypeServiceCommercialKPSA();
    typeServiceCommercialKPSA.setIdServiceKPSA("IdServiceKPSA"); //$NON-NLS-1$
    typeServiceCommercialKPSA.setParametres(typeParametres);

    TypeServiceCommercialMIM typeServiceCommercialMIM = new TypeServiceCommercialMIM();
    typeServiceCommercialMIM.setIdServiceMIM("78"); //$NON-NLS-1$
    typeServiceCommercialMIM.getServiceCommercialKPSAs().add(typeServiceCommercialKPSA);

    //Prepare mock
    EasyMock.expect(SvcCommMimProxy.getInstance()).andReturn(_svcCommMimConnector);
    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, "78")).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(typeServiceCommercialMIM, true)); //$NON-NLS-1$

    // On enregistre le scénario des appels
    PowerMock.replayAll();

    PM028BL300MimToInk currentInstance = new PM028BL300MimToInkBuilder().tracabilite(tracabilite).source(SOURCE_ID).orderid(ORDER_ID).flowid(FLOW_ID).quadrupletProvisionnerPfiIn(quadruplet).consulterPFIOut(consulterPFIReponseType.getConsulterPFIOut()).verbe(Diagnostic.RESYNCHRO_SI_NPBT.toString()).idtitf(IDTITF).iwsRessourcesInfoParamValue(DEFAULT_IWS_RESSOURCES_INFO).partitionSic(PARTITION_SIC).build();
    Request ret = currentInstance.execute(_currentInstance);

    PowerMock.verifyAll();

    checkResponse(RetourFactoryForTU.createOkRetour(), currentInstance.getRetour());
    checkINKProdResponse(createExpectedRequest(ORDER_ID, "2109813926364", true, PROV_VERB, ORIGINATOR_VALUE, 0, Diagnostic.RESYNCHRO_SI_NPBT.toString(), "SYNCHRO_SINPBT", "GET"), ret); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    Assert.assertEquals("1", getParam(ret.getSo().getSod().getDataset().getParams(), "IdServiceKPSA.R.parametre").getValue()); //$NON-NLS-1$ //$NON-NLS-2$
  }

  /**
   * Test le cas Nominal. <br/>
   * Alors: ServiceAccessibleStatut = null avec valid IMSI, IdServiceKPSA different de SSBN <br/>
   *
   *
   * <b>Entrées:</b>Entrée valides.<br/>
   * <b>Attendu:</b>Resultat:OK;<br/>
   *
   * @throws RavelException
   *           on error
   * @throws IOException
   *           exception
   */
  @Test
  public void PM028_BL300_MimToInk_test_017() throws RavelException, IOException
  {
    Tracabilite tracabilite = new Tracabilite(StringConstants.EMPTY_STRING, Test_Consts.DEFAULT_MSGID, "PROF", "nomPRocessus", "idProcessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$;

    Quadruplet quadruplet = new Quadruplet(null, "33600300091", "208201700000091", ActionProvisionner.ACTIVER_LIGNES); //$NON-NLS-1$ //$NON-NLS-2$

    String fichier = new String(Files.readAllBytes(Paths.get("src/test/resources/consulterPFIoutTest.xml"))); //$NON-NLS-1$
    ConsulterPFIReponseType consulterPFIReponseType = MarshallTools.unmarshallAndBypassDTDValidation(ConsulterPFIReponseType.class, fichier);
    ((com.bouygtel.refcli.consulterpfi.out.ServiceAccessible) consulterPFIReponseType.getConsulterPFIOut().getDonneesMetier().getPortefeuilleIndividuel().getServiceAccessibles().get(0).getIdref()).setStatut(null);

    TypeParametre typeParametre = new TypeParametre();
    typeParametre.setIdParametreKPSA("parametre"); //$NON-NLS-1$
    typeParametre.setConstante("constante"); //$NON-NLS-1$
    typeParametre.setIdParametreMIM("3"); //$NON-NLS-1$

    TypeParametres typeParametres = new TypeParametres();
    typeParametres.getParametres().add(typeParametre);

    TypeServiceCommercialKPSA typeServiceCommercialKPSA = new TypeServiceCommercialKPSA();
    typeServiceCommercialKPSA.setIdServiceKPSA("IdServiceKPSA"); //$NON-NLS-1$
    typeServiceCommercialKPSA.setParametres(typeParametres);

    TypeServiceCommercialMIM typeServiceCommercialMIM = new TypeServiceCommercialMIM();
    typeServiceCommercialMIM.setIdServiceMIM("78"); //$NON-NLS-1$
    typeServiceCommercialMIM.getServiceCommercialKPSAs().add(typeServiceCommercialKPSA);

    //Prepare mock
    EasyMock.expect(SvcCommMimProxy.getInstance()).andReturn(_svcCommMimConnector);
    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, "78")).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(typeServiceCommercialMIM, true)); //$NON-NLS-1$

    // On enregistre le scénario des appels
    PowerMock.replayAll();

    PM028BL300MimToInk currentInstance = new PM028BL300MimToInkBuilder().tracabilite(tracabilite).source(SOURCE_ID).orderid(ORDER_ID).flowid(FLOW_ID).quadrupletProvisionnerPfiIn(quadruplet).consulterPFIOut(consulterPFIReponseType.getConsulterPFIOut()).verbe(Diagnostic.RESYNCHRO_SI_NPBT.toString()).idtitf(IDTITF).iwsRessourcesInfoParamValue(DEFAULT_IWS_RESSOURCES_INFO).partitionSic(PARTITION_SIC).build();
    Request ret = currentInstance.execute(_currentInstance);

    PowerMock.verifyAll();

    checkResponse(RetourFactoryForTU.createOkRetour(), currentInstance.getRetour());
    checkINKProdResponse(createExpectedRequest(ORDER_ID, "2109813926364", true, PROV_VERB, ORIGINATOR_VALUE, 0, Diagnostic.RESYNCHRO_SI_NPBT.toString(), "SYNCHRO_SINPBT", "GET"), ret); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    DatasetParam param = null;

    for (DatasetParam ds : ret.getSo().getSod().getDataset().getParams())
    {
      if (ds.getName().startsWith("IdServiceKPSA.") && ds.getName().endsWith(".parametre")) //$NON-NLS-1$//$NON-NLS-2$
      {
        param = ds;
      }
    }

    Assert.assertNull(param);
  }

  /**
   * Test le cas Nominal. <br/>
   * Alors: ServiceAccessibleStatut = null avec valid IMSI, IdServiceKPSA different de SSBN <br/>
   *
   *
   * <b>Entrées:</b>Entrée valides.<br/>
   * <b>Attendu:</b>Resultat:OK;<br/>
   *
   * @throws RavelException
   *           on error
   */
  @Test
  public void PM028_BL300_MimToInk_test_018() throws RavelException
  {
    Tracabilite tracabilite = new Tracabilite(StringConstants.EMPTY_STRING, Test_Consts.DEFAULT_MSGID, "PROF", "nomPRocessus", "idProcessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$;

    PortefeuilleIndividuel portefeuilleIndividuel = new PortefeuilleIndividuel();
    portefeuilleIndividuel.setId("PFI-1"); //$NON-NLS-1$
    portefeuilleIndividuel.setDateDernierImpact("20160219052345"); //$NON-NLS-1$
    portefeuilleIndividuel.setNoCompte("11700000091"); //$NON-NLS-1$

    Pair<ServiceAccessible, ServiceCommercial> p = createProvInService("2/INACTIF"); //$NON-NLS-1$
    p._first.setStatut(null);

    PIVOTREFERENCE pivotreferenceSA = new PIVOTREFERENCE();
    pivotreferenceSA.setIdref(p._first);
    portefeuilleIndividuel.getServiceAccessibles().add(pivotreferenceSA);

    Quadruplet quadruplet = new Quadruplet(portefeuilleIndividuel, "33600300091", "208201700000091", ActionProvisionner.ACTIVER_LIGNES); //$NON-NLS-1$ //$NON-NLS-2$

    ProvisionnerPfiIn provisionnerPfiIn = MarshallTools.unmarshall(ProvisionnerPfiIn.class, new File(IN_REQUEST_XML));

    TypeParametre typeParametre = new TypeParametre();
    typeParametre.setIdParametreKPSA("SPARAM[7]"); //$NON-NLS-1$
    typeParametre.setConstante("constante"); //$NON-NLS-1$

    TypeParametres typeParametres = new TypeParametres();
    typeParametres.getParametres().add(typeParametre);

    TypeServiceCommercialKPSA typeServiceCommercialKPSA = new TypeServiceCommercialKPSA();
    typeServiceCommercialKPSA.setIdServiceKPSA("IdServiceKPSA"); //$NON-NLS-1$
    typeServiceCommercialKPSA.setParametres(typeParametres);

    TypeServiceCommercialMIM typeServiceCommercialMIM = new TypeServiceCommercialMIM();
    typeServiceCommercialMIM.setIdServiceMIM("2"); //$NON-NLS-1$
    typeServiceCommercialMIM.getServiceCommercialKPSAs().add(typeServiceCommercialKPSA);

    //Prepare mock
    EasyMock.expect(SvcCommMimProxy.getInstance()).andReturn(_svcCommMimConnector);
    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, "2")).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(typeServiceCommercialMIM, true)); //$NON-NLS-1$

    // On enregistre le scénario des appels
    PowerMock.replayAll();

    PM028BL300MimToInk currentInstance = new PM028BL300MimToInkBuilder().tracabilite(tracabilite).source(SOURCE_ID).orderid(ORDER_ID).flowid(FLOW_ID).quadrupletProvisionnerPfiIn(quadruplet).consulterPFIOut(new ConsulterPFIOut()).provisionnerPfiIn(provisionnerPfiIn).verbe(Diagnostic.PROVISIONNER_SERVICES.toString()).idtitf(IDTITF).iwsRessourcesInfoParamValue(DEFAULT_IWS_RESSOURCES_INFO).partitionSic(PARTITION_SIC).build();
    Request ret = currentInstance.execute(_currentInstance);

    PowerMock.verifyAll();

    checkResponse(RetourFactoryForTU.createOkRetour(), currentInstance.getRetour());
    checkINKProdResponse(createExpectedRequest(ORDER_ID, "2101700000091", true, PROV_VERB, ORIGINATOR_VALUE, 0, Diagnostic.PROVISIONNER_SERVICES.toString(), "GSMCSC", "GET"), ret); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    Assert.assertEquals("constante", getParam(ret.getSo().getSod().getDataset().getParams(), "IdServiceKPSA.C.SPARAM").getValue()); //$NON-NLS-1$ //$NON-NLS-2$
  }

  /**
   * Test le cas Nominal. <br/>
   * Alors: ServiceAccessibleStatut = SUSPENDU avec valid IMSI, IdServiceKPSA different de SSBN, service avec parametres
   * <br/>
   *
   *
   * <b>Entrées:</b>Entrée valides.<br/>
   * <b>Attendu:</b>Resultat:OK;<br/>
   *
   * @throws RavelException
   *           on error
   */
  @Test
  public void PM028_BL300_MimToInk_test_019() throws RavelException
  {
    Tracabilite tracabilite = new Tracabilite(StringConstants.EMPTY_STRING, Test_Consts.DEFAULT_MSGID, "PROF", "nomPRocessus", "idProcessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$;

    PortefeuilleIndividuel portefeuilleIndividuel = new PortefeuilleIndividuel();
    portefeuilleIndividuel.setId("PFI-1"); //$NON-NLS-1$
    portefeuilleIndividuel.setDateDernierImpact("20160219052345"); //$NON-NLS-1$
    portefeuilleIndividuel.setNoCompte("11700000091"); //$NON-NLS-1$

    Pair<ServiceAccessible, ServiceCommercial> p = createProvInService("2/SUSPENDU"); //$NON-NLS-1$

    PIVOTREFERENCE pivotreferenceSA = new PIVOTREFERENCE();
    pivotreferenceSA.setIdref(p._first);
    portefeuilleIndividuel.getServiceAccessibles().add(pivotreferenceSA);

    Quadruplet quadruplet = new Quadruplet(portefeuilleIndividuel, "33600300091", "208201700000091", ActionProvisionner.SUSPENDRE_LIGNES); //$NON-NLS-1$ //$NON-NLS-2$

    ProvisionnerPfiIn provisionnerPfiIn = MarshallTools.unmarshall(ProvisionnerPfiIn.class, new File(IN_REQUEST_XML));

    provisionnerPfiIn.getDonneesMetier().getPortefeuilleIndividuels().add(portefeuilleIndividuel);

    // SPARAM[7]
    TypeParametre typeParametre = new TypeParametre();
    typeParametre.setIdParametreKPSA("SPARAM[7]"); //$NON-NLS-1$
    typeParametre.setConstante("constante"); //$NON-NLS-1$

    TypeParametres typeParametres = new TypeParametres();
    typeParametres.getParametres().add(typeParametre);

    // SPARAM[2]
    typeParametre = new TypeParametre();
    typeParametre.setIdParametreKPSA("SPARAM[2]"); //$NON-NLS-1$
    typeParametre.setIdParametreMIM("9"); //$NON-NLS-1$
    typeParametres.getParametres().add(typeParametre);

    // 10
    typeParametre = new TypeParametre();
    typeParametre.setIdParametreKPSA("10"); //$NON-NLS-1$
    typeParametre.setIdParametreMIM("test"); //$NON-NLS-1$
    typeParametres.getParametres().add(typeParametre);

    // 15
    typeParametre = new TypeParametre();
    typeParametre.setIdParametreKPSA("15"); //$NON-NLS-1$
    typeParametre.setIdParametreMIM("test"); //$NON-NLS-1$
    typeParametre.setConstante("c15"); //$NON-NLS-1$
    typeParametres.getParametres().add(typeParametre);

    // 20
    typeParametre = new TypeParametre();
    typeParametre.setIdParametreKPSA("20"); //$NON-NLS-1$
    typeParametres.getParametres().add(typeParametre);

    // 25
    typeParametre = new TypeParametre();
    typeParametre.setIdParametreKPSA("25"); //$NON-NLS-1$
    typeParametre.setConstante("c25"); //$NON-NLS-1$
    typeParametres.getParametres().add(typeParametre);

    typeParametres.getParametres().add(typeParametre);

    TypeServiceCommercialKPSA typeServiceCommercialKPSA = new TypeServiceCommercialKPSA();
    typeServiceCommercialKPSA.setIdServiceKPSA("IdServiceKPSA"); //$NON-NLS-1$
    typeServiceCommercialKPSA.setParametres(typeParametres);

    TypeServiceCommercialMIM typeServiceCommercialMIM = new TypeServiceCommercialMIM();
    typeServiceCommercialMIM.setIdServiceMIM("2"); //$NON-NLS-1$
    typeServiceCommercialMIM.getServiceCommercialKPSAs().add(typeServiceCommercialKPSA);

    // Parametre Simple Valorise
    ParametreSimpleValorise psv = new ParametreSimpleValorise();
    psv.setId("PSV-1"); //$NON-NLS-1$
    psv.setValeur("5"); //$NON-NLS-1$

    ParamService ps = new ParamService();
    ps.setIdentifiantParametre("9"); //$NON-NLS-1$

    PIVOTREFERENCE ref = new PIVOTREFERENCE();
    ref.setIdref(ps);

    psv.setParamService(ref);

    ref = new PIVOTREFERENCE();
    ref.setIdref(psv);
    p._first.getParametreSimpleValorises().add(ref);

    //Prepare mock
    EasyMock.expect(SvcCommMimProxy.getInstance()).andReturn(_svcCommMimConnector);
    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, "2")).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(typeServiceCommercialMIM, true)); //$NON-NLS-1$

    // On enregistre le scénario des appels
    PowerMock.replayAll();

    PM028BL300MimToInk currentInstance = new PM028BL300MimToInkBuilder().tracabilite(tracabilite).source(SOURCE_ID).orderid(ORDER_ID).flowid(FLOW_ID).quadrupletProvisionnerPfiIn(quadruplet).consulterPFIOut(new ConsulterPFIOut()).provisionnerPfiIn(provisionnerPfiIn).verbe(ActionProvisionner.PROVISIONNER_SERVICES.getAction()).idtitf(IDTITF).iwsRessourcesInfoParamValue(DEFAULT_IWS_RESSOURCES_INFO).partitionSic(PARTITION_SIC).build();
    Request ret = currentInstance.execute(_currentInstance);

    PowerMock.verifyAll();

    checkResponse(RetourFactoryForTU.createOkRetour(), currentInstance.getRetour());
    checkINKProdResponse(createExpectedRequest(ORDER_ID, "2101700000091", true, PROV_VERB, ORIGINATOR_VALUE, 0, Diagnostic.PROVISIONNER_SERVICES.toString(), "GSMCSC", "GET"), ret); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    //Verification de la valeur du parametre SPARAM[2]

    DatasetParam datasetParam = null;

    for (DatasetParam dp : ret.getSo().getSod().getDataset().getParams())
    {
      if ((dp.getIndex() == 2) && dp.getName().contains("SPARAM")) //$NON-NLS-1$
      {
        datasetParam = dp;
        break;
      }
    }

    Assert.assertNotNull(datasetParam);
    Assert.assertEquals("IdServiceKPSA.S.SPARAM", datasetParam.getName()); //$NON-NLS-1$
    Assert.assertEquals("5", datasetParam.getValue()); //$NON-NLS-1$

    //Verification de la valeur du parametre 10
    datasetParam = getDatasetParamFromRequest(ret, "IdServiceKPSA.S.10"); //$NON-NLS-1$
    Assert.assertNotNull(datasetParam);
    Assert.assertEquals("", datasetParam.getValue()); //$NON-NLS-1$

    //Verification de la valeur du parametre 15
    datasetParam = getDatasetParamFromRequest(ret, "IdServiceKPSA.S.15"); //$NON-NLS-1$
    Assert.assertNotNull(datasetParam);
    Assert.assertEquals("c15", datasetParam.getValue()); //$NON-NLS-1$

    //Verification de la valeur du parametre 20
    datasetParam = getDatasetParamFromRequest(ret, "IdServiceKPSA.S.20"); //$NON-NLS-1$
    Assert.assertNotNull(datasetParam);
    Assert.assertEquals("", datasetParam.getValue()); //$NON-NLS-1$

    //Verification de la valeur du parametre 25
    datasetParam = getDatasetParamFromRequest(ret, "IdServiceKPSA.S.25"); //$NON-NLS-1$
    Assert.assertNotNull(datasetParam);
    Assert.assertEquals("c25", datasetParam.getValue()); //$NON-NLS-1$

  }

  /**
   * Test le cas Nominal. <br/>
   * Alors: ServiceAccessibleStatut = INACTIF avec valid IMSI, IdServiceKPSA different de SSBN, service avec parametres
   * <br/>
   *
   *
   * <b>Entrées:</b>Entrée valides.<br/>
   * <b>Attendu:</b>Resultat:OK;<br/>
   *
   * @throws RavelException
   *           on error
   * @throws IOException
   *           exception
   */
  @Test
  public void PM028_BL300_MimToInk_test_020() throws RavelException, IOException
  {
    Tracabilite tracabilite = new Tracabilite(StringConstants.EMPTY_STRING, Test_Consts.DEFAULT_MSGID, "PROF", "nomPRocessus", "idProcessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$;

    Quadruplet quadruplet = new Quadruplet(null, "33600300091", "208201700000091", ActionProvisionner.ACTIVER_LIGNES); //$NON-NLS-1$ //$NON-NLS-2$

    String fichier = new String(Files.readAllBytes(Paths.get("src/test/resources/consulterPFIoutTest.xml"))); //$NON-NLS-1$
    ConsulterPFIReponseType consulterPFIReponseType = MarshallTools.unmarshallAndBypassDTDValidation(ConsulterPFIReponseType.class, fichier);
    ((com.bouygtel.refcli.consulterpfi.out.ServiceAccessible) consulterPFIReponseType.getConsulterPFIOut().getDonneesMetier().getPortefeuilleIndividuel().getServiceAccessibles().get(0).getIdref()).setStatut(EnumTypeStatutServiceAccessible.ACTIVE);

    TypeParametre typeParametre = new TypeParametre();
    typeParametre.setIdParametreKPSA("parametre"); //$NON-NLS-1$
    typeParametre.setConstante("constante"); //$NON-NLS-1$
    typeParametre.setIdParametreMIM("3"); //$NON-NLS-1$

    TypeParametres typeParametres = new TypeParametres();
    typeParametres.getParametres().add(typeParametre);

    TypeServiceCommercialKPSA typeServiceCommercialKPSA = new TypeServiceCommercialKPSA();
    typeServiceCommercialKPSA.setIdServiceKPSA("IdServiceKPSA"); //$NON-NLS-1$
    typeServiceCommercialKPSA.setParametres(typeParametres);

    TypeServiceCommercialMIM typeServiceCommercialMIM = new TypeServiceCommercialMIM();
    typeServiceCommercialMIM.setIdServiceMIM("78"); //$NON-NLS-1$
    typeServiceCommercialMIM.getServiceCommercialKPSAs().add(typeServiceCommercialKPSA);

    // 10
    typeParametre = new TypeParametre();
    typeParametre.setIdParametreKPSA("10"); //$NON-NLS-1$
    typeParametre.setIdParametreMIM("test"); //$NON-NLS-1$

    typeParametres.getParametres().add(typeParametre);

    // 15
    typeParametre = new TypeParametre();
    typeParametre.setIdParametreKPSA("15"); //$NON-NLS-1$
    typeParametre.setIdParametreMIM("test"); //$NON-NLS-1$
    typeParametre.setConstante("c15"); //$NON-NLS-1$

    typeParametres.getParametres().add(typeParametre);

    // 20
    typeParametre = new TypeParametre();
    typeParametre.setIdParametreKPSA("20"); //$NON-NLS-1$

    typeParametres.getParametres().add(typeParametre);

    // 25
    typeParametre = new TypeParametre();
    typeParametre.setIdParametreKPSA("25"); //$NON-NLS-1$
    typeParametre.setConstante("c25"); //$NON-NLS-1$

    typeParametres.getParametres().add(typeParametre);

    typeServiceCommercialKPSA = new TypeServiceCommercialKPSA();
    typeServiceCommercialKPSA.setIdServiceKPSA("IdServiceKPSA"); //$NON-NLS-1$
    typeServiceCommercialKPSA.setParametres(typeParametres);

    typeServiceCommercialMIM = new TypeServiceCommercialMIM();
    typeServiceCommercialMIM.setIdServiceMIM("2"); //$NON-NLS-1$
    typeServiceCommercialMIM.getServiceCommercialKPSAs().add(typeServiceCommercialKPSA);

    com.bouygtel.refcli.consulterpfi.out.ServiceAccessible sa = ((com.bouygtel.refcli.consulterpfi.out.ServiceAccessible) consulterPFIReponseType.getConsulterPFIOut().getDonneesMetier().getPortefeuilleIndividuel().getServiceAccessibles().get(0).getIdref());

    com.bouygtel.refcli.consulterpfi.out.ParametreSimpleValorise psv = new com.bouygtel.refcli.consulterpfi.out.ParametreSimpleValorise();
    psv.setID("PSV-1"); //$NON-NLS-1$
    psv.setValeur("5"); //$NON-NLS-1$

    com.bouygtel.refcli.consulterpfi.out.ParamService ps = new com.bouygtel.refcli.consulterpfi.out.ParamService();
    ps.setID("PS-1"); //$NON-NLS-1$
    ps.setIdentifiantParametre(BigDecimal.TEN);

    com.bouygtel.commontypes.s3g.v3.PIVOTREFERENCE ref = new com.bouygtel.commontypes.s3g.v3.PIVOTREFERENCE();
    ref.setIdref(ps);

    psv.setParamService(ref);

    ref = new com.bouygtel.commontypes.s3g.v3.PIVOTREFERENCE();
    ref.setIdref(psv);
    sa.getParametreSimpleValorises().add(ref);

    //Prepare mock
    EasyMock.expect(SvcCommMimProxy.getInstance()).andReturn(_svcCommMimConnector);
    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, "78")).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(typeServiceCommercialMIM, true)); //$NON-NLS-1$

    // On enregistre le scénario des appels
    PowerMock.replayAll();

    PM028BL300MimToInk currentInstance = new PM028BL300MimToInkBuilder().tracabilite(tracabilite).source(SOURCE_ID).orderid(ORDER_ID).flowid(FLOW_ID).quadrupletProvisionnerPfiIn(quadruplet).consulterPFIOut(consulterPFIReponseType.getConsulterPFIOut()).verbe(Diagnostic.RESYNCHRO_SI_NPBT.toString()).idtitf(IDTITF).iwsRessourcesInfoParamValue(DEFAULT_IWS_RESSOURCES_INFO).partitionSic(PARTITION_SIC).build();
    Request ret = currentInstance.execute(_currentInstance);

    PowerMock.verifyAll();

    checkResponse(RetourFactoryForTU.createOkRetour(), currentInstance.getRetour());
    checkINKProdResponse(createExpectedRequest(ORDER_ID, "2109813926364", true, PROV_VERB, ORIGINATOR_VALUE, 0, Diagnostic.RESYNCHRO_SI_NPBT.toString(), "SYNCHRO_SINPBT", "GET"), ret); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    Assert.assertEquals("1", getParam(ret.getSo().getSod().getDataset().getParams(), "IdServiceKPSA.R.parametre").getValue()); //$NON-NLS-1$ //$NON-NLS-2$

    //Verification de la valeur du parametre 10

    DatasetParam datasetParam = getDatasetParamFromRequest(ret, "IdServiceKPSA.R.10"); //$NON-NLS-1$

    Assert.assertNotNull(datasetParam);
    Assert.assertEquals("", datasetParam.getValue()); //$NON-NLS-1$

    //Verification de la valeur du parametre 15

    datasetParam = getDatasetParamFromRequest(ret, "IdServiceKPSA.R.15"); //$NON-NLS-1$

    Assert.assertNotNull(datasetParam);
    Assert.assertEquals("c15", datasetParam.getValue()); //$NON-NLS-1$

    //Verification de la valeur du parametre 20

    datasetParam = getDatasetParamFromRequest(ret, "IdServiceKPSA.R.20"); //$NON-NLS-1$

    Assert.assertNotNull(datasetParam);
    Assert.assertEquals("", datasetParam.getValue()); //$NON-NLS-1$

    //Verification de la valeur du parametre 25

    datasetParam = getDatasetParamFromRequest(ret, "IdServiceKPSA.R.25"); //$NON-NLS-1$
    Assert.assertNotNull(datasetParam);
    Assert.assertEquals("c25", datasetParam.getValue()); //$NON-NLS-1$
  }

  /**
   * Test connecteur svccomm en erreur. <br/>
   *
   * <b>Entrées:</b>Entrée valides.<br/>
   * <b>Attendu:</b>Resultat:KO;<br/>
   *
   * @throws RavelException
   *           on error
   * @throws IOException
   *           exception
   */
  @Test
  public void PM028_BL300_MimToInk_test_021() throws RavelException, IOException
  {
    Tracabilite tracabilite = new Tracabilite(StringConstants.EMPTY_STRING, Test_Consts.DEFAULT_MSGID, "PROF", "nomPRocessus", "idProcessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$;

    Quadruplet quadruplet = new Quadruplet(null, "33600300091", "208201700000091", ActionProvisionner.ACTIVER_LIGNES); //$NON-NLS-1$ //$NON-NLS-2$

    String fichier = new String(Files.readAllBytes(Paths.get("src/test/resources/consulterPFIoutTest.xml"))); //$NON-NLS-1$
    ConsulterPFIReponseType consulterPFIReponseType = MarshallTools.unmarshallAndBypassDTDValidation(ConsulterPFIReponseType.class, fichier);
    ((com.bouygtel.refcli.consulterpfi.out.ServiceAccessible) consulterPFIReponseType.getConsulterPFIOut().getDonneesMetier().getPortefeuilleIndividuel().getServiceAccessibles().get(0).getIdref()).setStatut(EnumTypeStatutServiceAccessible.ACTIVE);

    TypeParametre typeParametre = new TypeParametre();
    typeParametre.setIdParametreKPSA("parametre"); //$NON-NLS-1$
    typeParametre.setConstante("constante"); //$NON-NLS-1$
    typeParametre.setIdParametreMIM("3"); //$NON-NLS-1$

    TypeParametres typeParametres = new TypeParametres();
    typeParametres.getParametres().add(typeParametre);

    TypeServiceCommercialKPSA typeServiceCommercialKPSA = new TypeServiceCommercialKPSA();
    typeServiceCommercialKPSA.setIdServiceKPSA("IdServiceKPSA"); //$NON-NLS-1$
    typeServiceCommercialKPSA.setParametres(typeParametres);

    TypeServiceCommercialMIM typeServiceCommercialMIM = new TypeServiceCommercialMIM();
    typeServiceCommercialMIM.setIdServiceMIM("78"); //$NON-NLS-1$
    typeServiceCommercialMIM.getServiceCommercialKPSAs().add(typeServiceCommercialKPSA);

    typeServiceCommercialKPSA = new TypeServiceCommercialKPSA();
    typeServiceCommercialKPSA.setIdServiceKPSA("IdServiceKPSA"); //$NON-NLS-1$
    typeServiceCommercialKPSA.setParametres(typeParametres);

    typeServiceCommercialMIM = new TypeServiceCommercialMIM();
    typeServiceCommercialMIM.setIdServiceMIM("2"); //$NON-NLS-1$
    typeServiceCommercialMIM.getServiceCommercialKPSAs().add(typeServiceCommercialKPSA);

    RavelException e = new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.CNCTOR_00010, "Test"); //$NON-NLS-1$

    //Prepare mock
    EasyMock.expect(SvcCommMimProxy.getInstance()).andReturn(_svcCommMimConnector);
    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, "78")).andThrow(e); //$NON-NLS-1$

    // On enregistre le scénario des appels
    PowerMock.replayAll();

    PM028BL300MimToInk currentInstance = new PM028BL300MimToInkBuilder().tracabilite(tracabilite).source(SOURCE_ID).orderid(ORDER_ID).flowid(FLOW_ID).quadrupletProvisionnerPfiIn(quadruplet).consulterPFIOut(consulterPFIReponseType.getConsulterPFIOut()).verbe(Diagnostic.RESYNCHRO_SI_NPBT.toString()).idtitf(IDTITF).iwsRessourcesInfoParamValue(DEFAULT_IWS_RESSOURCES_INFO).partitionSic(PARTITION_SIC).build();
    Request ret = currentInstance.execute(_currentInstance);

    PowerMock.verifyAll();

    Assert.assertNull(ret);
    Assert.assertNotNull(currentInstance.getRetour());

    Assert.assertEquals("KO", currentInstance.getRetour().getResultat()); //$NON-NLS-1$
    Assert.assertEquals(IMegConsts.CAT1, currentInstance.getRetour().getCategorie());
    Assert.assertEquals(Consts.SERVICE_INDISPONIBLE.toString(), currentInstance.getRetour().getDiagnostic());
    Assert.assertEquals("Test", currentInstance.getRetour().getLibelle()); //$NON-NLS-1$
  }

  /**
   * Test pour evol NPBT-453
   *
   * @throws RavelException
   *           on error
   * @throws RavelException,
   *           on error
   * @throws IOException
   *           on error
   */
  @Test
  public void PM028_BL300_MimToInk_test_022() throws RavelException, IOException
  {
    Tracabilite tracabilite = new Tracabilite(StringConstants.EMPTY_STRING, Test_Consts.DEFAULT_MSGID, "PROF", "nomPRocessus", "idProcessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$;

    PortefeuilleIndividuel portefeuilleIndividuel = new PortefeuilleIndividuel();
    portefeuilleIndividuel.setId("PFI-1"); //$NON-NLS-1$
    portefeuilleIndividuel.setDateDernierImpact("20160219052345"); //$NON-NLS-1$
    portefeuilleIndividuel.setNoCompte("10054013113"); //$NON-NLS-1$

    Pair<ServiceAccessible, ServiceCommercial> p = createProvInService("78/ACTIVE"); //$NON-NLS-1$
    PIVOTREFERENCE pivotreferenceSA = new PIVOTREFERENCE();

    PIVOTREFERENCE pivotrefPA = new PIVOTREFERENCE();
    p._first.setPointAcces(pivotrefPA);
    LigneGsm ligneGsm = new LigneGsm();
    ligneGsm.setMsisdn("+33012345678"); //$NON-NLS-1$
    ligneGsm.setStatut(PointAccesStatut.RESILIE);

    SimLogique simLogique = new SimLogique();
    simLogique.setId("SIM-1"); //$NON-NLS-1$
    simLogique.setStatut(SimLogiqueStatut.RESILIE);
    simLogique.setImsi("208209813926364"); //$NON-NLS-1$
    PIVOTREFERENCE pivotreference = new PIVOTREFERENCE();
    pivotreference.setIdref(simLogique);
    ligneGsm.getSimLogiques().add(pivotreference);

    simLogique = new SimLogique();
    simLogique.setId("SIM-2"); //$NON-NLS-1$
    simLogique.setStatut(SimLogiqueStatut.ACTIVE);
    pivotreference = new PIVOTREFERENCE();
    pivotreference.setIdref(simLogique);
    ligneGsm.getSimLogiques().add(pivotreference);

    pivotrefPA.setIdref(ligneGsm);
    pivotreferenceSA.setIdref(p._first);
    portefeuilleIndividuel.getServiceAccessibles().add(pivotreferenceSA);

    portefeuilleIndividuel.getPointAcces().add(pivotrefPA);

    pivotrefPA = new PIVOTREFERENCE();
    p._first.setPointAcces(pivotrefPA);
    ligneGsm = new LigneGsm();
    ligneGsm.setMsisdn("+33012345679"); //$NON-NLS-1$
    ligneGsm.setStatut(PointAccesStatut.ACTIVE);

    simLogique = new SimLogique();
    simLogique.setId("SIM-1"); //$NON-NLS-1$
    simLogique.setStatut(SimLogiqueStatut.RESILIE);
    simLogique.setImsi("208209813926364"); //$NON-NLS-1$
    pivotreference = new PIVOTREFERENCE();
    pivotreference.setIdref(simLogique);
    ligneGsm.getSimLogiques().add(pivotreference);

    simLogique = new SimLogique();
    simLogique.setId("SIM-2"); //$NON-NLS-1$
    simLogique.setStatut(SimLogiqueStatut.ACTIVE);
    pivotreference = new PIVOTREFERENCE();
    pivotreference.setIdref(simLogique);
    ligneGsm.getSimLogiques().add(pivotreference);

    pivotrefPA.setIdref(ligneGsm);
    portefeuilleIndividuel.getPointAcces().add(pivotrefPA);

    Quadruplet quadruplet = new Quadruplet(portefeuilleIndividuel, "33600300091", "208201700000091", ActionProvisionner.CHANGER_IMSI); //$NON-NLS-1$ //$NON-NLS-2$

    String fichier = new String(Files.readAllBytes(Paths.get("src/test/resources/consulterPFIoutTest3.xml"))); //$NON-NLS-1$
    ConsulterPFIReponseType consulterPFIReponseType = MarshallTools.unmarshallAndBypassDTDValidation(ConsulterPFIReponseType.class, fichier);

    TypeParametre typeParametre = new TypeParametre();
    typeParametre.setIdParametreKPSA("parametre"); //$NON-NLS-1$
    typeParametre.setConstante("constante"); //$NON-NLS-1$
    typeParametre.setIdParametreMIM("3"); //$NON-NLS-1$

    TypeParametres typeParametres = new TypeParametres();
    typeParametres.getParametres().add(typeParametre);

    TypeServiceCommercialKPSA typeServiceCommercialKPSA = new TypeServiceCommercialKPSA();
    typeServiceCommercialKPSA.setIdServiceKPSA("IdServiceKPSA"); //$NON-NLS-1$
    typeServiceCommercialKPSA.setParametres(typeParametres);

    TypeServiceCommercialMIM typeServiceCommercialMIM = new TypeServiceCommercialMIM();
    typeServiceCommercialMIM.setIdServiceMIM("78"); //$NON-NLS-1$
    typeServiceCommercialMIM.getServiceCommercialKPSAs().add(typeServiceCommercialKPSA);

    //Prepare mock
    EasyMock.expect(SvcCommMimProxy.getInstance()).andReturn(_svcCommMimConnector);
    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, "78")).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(typeServiceCommercialMIM, true)); //$NON-NLS-1$

    // On enregistre le scénario des appels
    PowerMock.replayAll();

    PM028BL300MimToInk currentInstance = new PM028BL300MimToInkBuilder().tracabilite(tracabilite).source(SOURCE_ID).orderid(ORDER_ID).flowid(FLOW_ID).quadrupletProvisionnerPfiIn(quadruplet).consulterPFIOut(consulterPFIReponseType.getConsulterPFIOut()).provisionnerPfiIn(buildProvisionnerPfiIn()).verbe(ActionProvisionner.ACTIVER_LIGNES.getAction()).idtitf(IDTITF).iwsRessourcesInfoParamValue(DEFAULT_IWS_RESSOURCES_INFO).partitionSic(PARTITION_SIC).build();
    Request ret = currentInstance.execute(_currentInstance);

    PowerMock.verifyAll();

    checkResponse(RetourFactoryForTU.createOkRetour(), currentInstance.getRetour());

    String customerId = "2101700000091"; //$NON-NLS-1$
    String verbe = "ActiverLignes"; //$NON-NLS-1$
    String productName = "GSMCAP"; //$NON-NLS-1$
    Request expectedRequest = createExpectedRequest(ORDER_ID, customerId, true, PROV_VERB, ORIGINATOR_VALUE, 0, verbe, productName, "GET"); //$NON-NLS-1$

    checkINKProdResponse(expectedRequest, ret);

    //So
    ServiceOrderRequest soExpected = expectedRequest.getSo();
    ServiceOrderRequest soActual = ret.getSo();
    Assert.assertEquals(soExpected.getOrderId(), soActual.getOrderId());

    //SOD
    Assert.assertEquals(soExpected.getSod().getVerb(), soActual.getSod().getVerb());
    Assert.assertNotNull(soActual.getSod().getDataset().getParams());
    Assert.assertTrue(!soActual.getSod().getDataset().getParams().isEmpty());
    Assert.assertEquals("208209813926364", getParam(soActual.getSod().getDataset().getParams(), IMSI).getValue()); //$NON-NLS-1$
    Assert.assertEquals(ORDER_ID + ".msg", getParam(soActual.getSod().getDataset().getParams(), EDIFACT_FILE_NAME).getValue()); //$NON-NLS-1$
    Assert.assertEquals(productName, getParam(soActual.getSod().getDataset().getParams(), MESSAGE_TYPE).getValue());
    Assert.assertEquals("constante", getParam(soActual.getSod().getDataset().getParams(), "IdServiceKPSA.R.parametre").getValue()); //$NON-NLS-1$ //$NON-NLS-2$

    //NPBT-453
    Assert.assertEquals(2, getParamList(soActual.getSod().getDataset().getParams(), PA_MSISDN).size());
    for (DatasetParam param : getParamList(soActual.getSod().getDataset().getParams(), PA_MSISDN))
    {
      if (param.getIndex() == 0)
      {
        Assert.assertEquals("33012345678", param.getValue()); //$NON-NLS-1$
      }
      if (param.getIndex() == 1)
      {
        Assert.assertEquals("33012345679", param.getValue()); //$NON-NLS-1$
      }
    }
    Assert.assertEquals(4, getParamList(soActual.getSod().getDataset().getParams(), MY_HEAP_NAME).size());
  }

  /**
   * Create a ProvisionnerPfiIn base on on PROD exemple
   *
   * @return a {@link ProvisionnerPfiIn} object
   */
  private ProvisionnerPfiIn buildProvisionnerPfiIn()
  {
    ProvisionnerPfiIn provisionnerPfiIn = new ProvisionnerPfiIn();
    PIVOTREFERENCE pivotreference;
    PortefeuilleIndividuel portefeuilleIndividuel;

    //acte metier
    ActeMetier acteMetier = new ActeMetier();
    acteMetier.setDateCreation("20110225101400"); //$NON-NLS-1$
    acteMetier.setIdentifiantActe("INJe6ee05f9dce0408aa205a0ef4ed184a5"); //$NON-NLS-1$
    acteMetier.setPriorite("1"); //$NON-NLS-1$
    PartitionSic partitionSic = new PartitionSic();
    partitionSic.setIdentifiant("1"); //$NON-NLS-1$
    acteMetier.setPartitionSic(partitionSic);
    St st = new St();
    st.setIdentifiant("114"); //$NON-NLS-1$
    acteMetier.setSt(st);
    portefeuilleIndividuel = new PortefeuilleIndividuel();
    portefeuilleIndividuel.setId("PFI-1"); //$NON-NLS-1$
    pivotreference = new PIVOTREFERENCE();
    pivotreference.setIdref(portefeuilleIndividuel);
    acteMetier.getPortefeuilleServices().add(pivotreference);

    //donnesMetier
    DonneesMetier donneesMetier = new DonneesMetier();
    //PortefeuilleIndividuel
    portefeuilleIndividuel = new PortefeuilleIndividuel();
    portefeuilleIndividuel.setId("PFI-1"); //$NON-NLS-1$
    portefeuilleIndividuel.setNoCompte("11700000091"); //$NON-NLS-1$
    portefeuilleIndividuel.setDateDernierImpact("20160215235918"); //$NON-NLS-1$
    portefeuilleIndividuel.getServiceAccessibles().addAll(getServicesAcessiblesPR());

    LigneGsm ligneGsm = new LigneGsm();
    ligneGsm.setId("GSM-1"); //$NON-NLS-1$
    pivotreference = new PIVOTREFERENCE();
    pivotreference.setIdref(ligneGsm);
    portefeuilleIndividuel.getPointAcces().add(pivotreference);

    donneesMetier.getPortefeuilleIndividuels().add(portefeuilleIndividuel);

    //ServicesAcessible
    ServiceCommercial serviceCommercial;
    ServiceAccessible serviceAccessible;

    serviceCommercial = new ServiceCommercial();
    serviceAccessible = new ServiceAccessible();
    serviceAccessible.setId("SA-REF"); //$NON-NLS-1$
    serviceAccessible.setStatut(ServiceAccessibleStatut.ACTIVE);
    serviceCommercial.setId("SC-3"); //$NON-NLS-1$
    pivotreference = new PIVOTREFERENCE();
    pivotreference.setIdref(serviceCommercial);
    serviceAccessible.setServiceCommercial(pivotreference);
    donneesMetier.getServiceAccessibles().add(serviceAccessible);

    serviceCommercial = new ServiceCommercial();
    serviceAccessible = new ServiceAccessible();
    serviceAccessible.setId("SA-REF1"); //$NON-NLS-1$
    serviceAccessible.setStatut(ServiceAccessibleStatut.ACTIVE);
    serviceCommercial.setId("SC-6"); //$NON-NLS-1$
    pivotreference = new PIVOTREFERENCE();
    pivotreference.setIdref(serviceCommercial);
    serviceAccessible.setServiceCommercial(pivotreference);
    donneesMetier.getServiceAccessibles().add(serviceAccessible);

    serviceCommercial = new ServiceCommercial();
    serviceAccessible = new ServiceAccessible();
    serviceAccessible.setId("SA-REF2"); //$NON-NLS-1$
    serviceAccessible.setStatut(ServiceAccessibleStatut.ACTIVE);
    serviceCommercial.setId("SC-7"); //$NON-NLS-1$
    pivotreference = new PIVOTREFERENCE();
    pivotreference.setIdref(serviceCommercial);
    serviceAccessible.setServiceCommercial(pivotreference);
    donneesMetier.getServiceAccessibles().add(serviceAccessible);

    serviceCommercial = new ServiceCommercial();
    serviceAccessible = new ServiceAccessible();
    serviceAccessible.setId("SA-REF3"); //$NON-NLS-1$
    serviceAccessible.setStatut(ServiceAccessibleStatut.ACTIVE);
    serviceCommercial.setId("SC-8"); //$NON-NLS-1$
    pivotreference = new PIVOTREFERENCE();
    pivotreference.setIdref(serviceCommercial);
    serviceAccessible.setServiceCommercial(pivotreference);
    donneesMetier.getServiceAccessibles().add(serviceAccessible);

    serviceCommercial = new ServiceCommercial();
    serviceAccessible = new ServiceAccessible();
    serviceAccessible.setId("SA-REF4"); //$NON-NLS-1$
    serviceAccessible.setStatut(ServiceAccessibleStatut.ACTIVE);
    serviceCommercial.setId("SC-9"); //$NON-NLS-1$
    pivotreference = new PIVOTREFERENCE();
    pivotreference.setIdref(serviceCommercial);
    serviceAccessible.setServiceCommercial(pivotreference);
    donneesMetier.getServiceAccessibles().add(serviceAccessible);

    serviceCommercial = new ServiceCommercial();
    serviceAccessible = new ServiceAccessible();
    serviceAccessible.setId("SA-REF5"); //$NON-NLS-1$
    serviceAccessible.setStatut(ServiceAccessibleStatut.ACTIVE);
    serviceCommercial.setId("SC-10"); //$NON-NLS-1$
    pivotreference = new PIVOTREFERENCE();
    pivotreference.setIdref(serviceCommercial);
    serviceAccessible.setServiceCommercial(pivotreference);
    donneesMetier.getServiceAccessibles().add(serviceAccessible);

    serviceCommercial = new ServiceCommercial();
    serviceAccessible = new ServiceAccessible();
    serviceAccessible.setId("SA-REF6"); //$NON-NLS-1$
    serviceAccessible.setStatut(ServiceAccessibleStatut.ACTIVE);
    serviceCommercial.setId("SC-11"); //$NON-NLS-1$
    pivotreference = new PIVOTREFERENCE();
    pivotreference.setIdref(serviceCommercial);
    serviceAccessible.setServiceCommercial(pivotreference);
    donneesMetier.getServiceAccessibles().add(serviceAccessible);

    serviceCommercial = new ServiceCommercial();
    serviceAccessible = new ServiceAccessible();
    serviceAccessible.setId("SA-REF7"); //$NON-NLS-1$
    serviceAccessible.setStatut(ServiceAccessibleStatut.ACTIVE);
    serviceCommercial.setId("SC-12"); //$NON-NLS-1$
    pivotreference = new PIVOTREFERENCE();
    pivotreference.setIdref(serviceCommercial);
    serviceAccessible.setServiceCommercial(pivotreference);
    donneesMetier.getServiceAccessibles().add(serviceAccessible);

    serviceCommercial = new ServiceCommercial();
    serviceAccessible = new ServiceAccessible();
    serviceAccessible.setId("SA-REF8"); //$NON-NLS-1$
    serviceAccessible.setStatut(ServiceAccessibleStatut.ACTIVE);
    serviceCommercial.setId("SC-13"); //$NON-NLS-1$
    pivotreference = new PIVOTREFERENCE();
    pivotreference.setIdref(serviceCommercial);
    serviceAccessible.setServiceCommercial(pivotreference);
    donneesMetier.getServiceAccessibles().add(serviceAccessible);

    serviceCommercial = new ServiceCommercial();
    serviceAccessible = new ServiceAccessible();
    serviceAccessible.setId("SA-REF9"); //$NON-NLS-1$
    serviceAccessible.setStatut(ServiceAccessibleStatut.ACTIVE);
    serviceCommercial.setId("SC-14"); //$NON-NLS-1$
    pivotreference = new PIVOTREFERENCE();
    pivotreference.setIdref(serviceCommercial);
    serviceAccessible.setServiceCommercial(pivotreference);
    donneesMetier.getServiceAccessibles().add(serviceAccessible);

    serviceCommercial = new ServiceCommercial();
    serviceAccessible = new ServiceAccessible();
    serviceAccessible.setId("SA-REF10"); //$NON-NLS-1$
    serviceAccessible.setStatut(ServiceAccessibleStatut.ACTIVE);
    serviceCommercial.setId("SC-15"); //$NON-NLS-1$
    pivotreference = new PIVOTREFERENCE();
    pivotreference.setIdref(serviceCommercial);
    serviceAccessible.setServiceCommercial(pivotreference);
    donneesMetier.getServiceAccessibles().add(serviceAccessible);

    //ServiceCommercial
    serviceCommercial = new ServiceCommercial();
    serviceCommercial.setId("SC-3"); //$NON-NLS-1$
    serviceCommercial.setNoServiceCommercial("1037"); //$NON-NLS-1$
    donneesMetier.getServiceCommercials().add(serviceCommercial);

    serviceCommercial = new ServiceCommercial();
    serviceCommercial.setId("SC-6"); //$NON-NLS-1$
    serviceCommercial.setNoServiceCommercial("2768"); //$NON-NLS-1$
    donneesMetier.getServiceCommercials().add(serviceCommercial);

    serviceCommercial = new ServiceCommercial();
    serviceCommercial.setId("SC-7"); //$NON-NLS-1$
    serviceCommercial.setNoServiceCommercial("107"); //$NON-NLS-1$
    donneesMetier.getServiceCommercials().add(serviceCommercial);

    serviceCommercial = new ServiceCommercial();
    serviceCommercial.setId("SC-8"); //$NON-NLS-1$
    serviceCommercial.setNoServiceCommercial("9"); //$NON-NLS-1$
    donneesMetier.getServiceCommercials().add(serviceCommercial);

    serviceCommercial = new ServiceCommercial();
    serviceCommercial.setId("SC-9"); //$NON-NLS-1$
    serviceCommercial.setNoServiceCommercial("7"); //$NON-NLS-1$
    donneesMetier.getServiceCommercials().add(serviceCommercial);

    serviceCommercial = new ServiceCommercial();
    serviceCommercial.setId("SC-10"); //$NON-NLS-1$
    serviceCommercial.setNoServiceCommercial("8"); //$NON-NLS-1$
    donneesMetier.getServiceCommercials().add(serviceCommercial);

    serviceCommercial = new ServiceCommercial();
    serviceCommercial.setId("SC-11"); //$NON-NLS-1$
    serviceCommercial.setNoServiceCommercial("5"); //$NON-NLS-1$
    donneesMetier.getServiceCommercials().add(serviceCommercial);

    serviceCommercial = new ServiceCommercial();
    serviceCommercial.setId("SC-12"); //$NON-NLS-1$
    serviceCommercial.setNoServiceCommercial("6"); //$NON-NLS-1$
    donneesMetier.getServiceCommercials().add(serviceCommercial);

    serviceCommercial = new ServiceCommercial();
    serviceCommercial.setId("SC-13"); //$NON-NLS-1$
    serviceCommercial.setNoServiceCommercial("18"); //$NON-NLS-1$
    donneesMetier.getServiceCommercials().add(serviceCommercial);

    serviceCommercial = new ServiceCommercial();
    serviceCommercial.setId("SC-14"); //$NON-NLS-1$
    serviceCommercial.setNoServiceCommercial("17"); //$NON-NLS-1$
    donneesMetier.getServiceCommercials().add(serviceCommercial);

    serviceCommercial = new ServiceCommercial();
    serviceCommercial.setId("SC-15"); //$NON-NLS-1$
    serviceCommercial.setNoServiceCommercial("2767"); //$NON-NLS-1$
    donneesMetier.getServiceCommercials().add(serviceCommercial);

    //ligneGSM
    ligneGsm = new LigneGsm();
    ligneGsm.setId("GSM-1"); //$NON-NLS-1$
    ligneGsm.setIdFonctionnelPA("1"); //$NON-NLS-1$
    ligneGsm.setStatut(PointAccesStatut.ACTIVE);
    TypePointAccesCommercial typePointAccesCommercial = new TypePointAccesCommercial();
    typePointAccesCommercial.setId("TPAC-1"); //$NON-NLS-1$
    typePointAccesCommercial.setNoTypePointAccesCommercial(1);
    pivotreference = new PIVOTREFERENCE();
    pivotreference.setIdref(typePointAccesCommercial);
    ligneGsm.setTypePointAccesCommercial(pivotreference);
    ligneGsm.setMsisdn("+33600300091"); //$NON-NLS-1$
    SimLogique simLogique = new SimLogique();
    simLogique.setId("SIM-1"); //$NON-NLS-1$
    simLogique.setImsi("208201700000091"); //$NON-NLS-1$
    pivotreference = new PIVOTREFERENCE();
    pivotreference.setIdref(simLogique);
    ligneGsm.getSimLogiques().add(pivotreference);
    donneesMetier.getLigneGsms().add(ligneGsm);

    //simLogique
    donneesMetier.getSimLogiques().add(simLogique);

    //typePointAccesCommercial
    donneesMetier.getTypePointAccesCommercials().add(typePointAccesCommercial);

    provisionnerPfiIn.setActeMetier(acteMetier);
    provisionnerPfiIn.setDonneesMetier(donneesMetier);
    return provisionnerPfiIn;

  }

  /**
   * checkINKProdResponse.
   *
   * @param expectedRequest_p
   *          The expectedRequest param
   * @param actualRequest_p
   *          The actualRequest param
   */
  private void checkINKProdResponse(Request expectedRequest_p, Request actualRequest_p)
  {
    //So
    ServiceOrderRequest soExpected = expectedRequest_p.getSo();
    ServiceOrderRequest soActual = actualRequest_p.getSo();
    Assert.assertEquals(soExpected.getOrderId(), soActual.getOrderId());

    //SOD
    Assert.assertEquals(soExpected.getSod().getDomain(), soActual.getSod().getDomain());
    Assert.assertEquals(soExpected.getSod().getVerb(), soActual.getSod().getVerb());
    Assert.assertEquals(StringConstants.EMPTY_STRING, soActual.getSod().getCustomerId());
    Assert.assertEquals(soExpected.getSod().getOriginator(), soActual.getSod().getOriginator());
    Assert.assertEquals(soExpected.getSod().getPriority(), soActual.getSod().getPriority());
    Assert.assertEquals(soExpected.getSod().isDoCheckpoint(), soActual.getSod().isDoCheckpoint());

    //POD
    Assert.assertEquals(soExpected.getPods().get(0).getProductName(), soActual.getPods().get(0).getProductName());
    Assert.assertEquals(soExpected.getPods().get(0).getProductVerb(), soActual.getPods().get(0).getProductVerb());
  }

  /**
   * checkINKResponse.
   *
   * @param expectedRequest_p
   *          The expectedRequest param
   * @param actualRequest_p
   *          The actualRequest param
   */
  private void checkINKResponse(Request expectedRequest_p, Request actualRequest_p)
  {
    //So
    ServiceOrderRequest soExpected = expectedRequest_p.getSo();
    ServiceOrderRequest soActual = actualRequest_p.getSo();
    Assert.assertEquals(soExpected.getOrderId(), soActual.getOrderId());

    //SOD
    Assert.assertEquals(soExpected.getSod().getDomain(), soActual.getSod().getDomain());
    Assert.assertEquals(soExpected.getSod().getVerb(), soActual.getSod().getVerb());
    Assert.assertEquals(StringConstants.EMPTY_STRING, soActual.getSod().getCustomerId());
    Assert.assertEquals(soExpected.getSod().getOriginator(), soActual.getSod().getOriginator());
    Assert.assertEquals(soExpected.getSod().getPriority(), soActual.getSod().getPriority());
    Assert.assertEquals(soExpected.getSod().isDoCheckpoint(), soActual.getSod().isDoCheckpoint());

    //SOD Dataset
    Dataset datasetExpected = soExpected.getSod().getDataset();
    Dataset datasetActual = soActual.getSod().getDataset();

    //IDTPFS
    checkParam(getParam(datasetExpected.getParams(), IDTPFS), getParam(datasetActual.getParams(), IDTPFS));

    //MSISDN
    checkParam(getParam(datasetExpected.getParams(), MSISDN), getParam(datasetActual.getParams(), MSISDN));

    //IMSI
    checkParam(getParam(datasetExpected.getParams(), IMSI), getParam(datasetActual.getParams(), IMSI));

    //EdifactFileName
    checkParam(getParam(datasetExpected.getParams(), EDIFACT_FILE_NAME), getParam(datasetActual.getParams(), EDIFACT_FILE_NAME));

    //messageType
    checkParam(getParam(datasetExpected.getParams(), MESSAGE_TYPE), getParam(datasetActual.getParams(), MESSAGE_TYPE));

    //ORIGINATOR
    checkParam(getParam(datasetExpected.getParams(), ORIGINATOR), getParam(datasetActual.getParams(), ORIGINATOR));

    //TYPE_LIGNE
    checkParam(getParam(datasetExpected.getParams(), TYPE_LIGNE), getParam(datasetActual.getParams(), TYPE_LIGNE));

  }

  /**
   * checkParam.
   *
   * @param expectedParam_p
   *          The expectedParam param
   * @param actualParam_p
   *          The actualParam param
   */
  private void checkParam(DatasetParam expectedParam_p, DatasetParam actualParam_p)
  {
    Assert.assertEquals(expectedParam_p.getName(), actualParam_p.getName());
    Assert.assertEquals(expectedParam_p.getIndex(), actualParam_p.getIndex());
    Assert.assertEquals(expectedParam_p.getValue(), actualParam_p.getValue());
  }

  /**
   * Checks if two <code>Retour</code> objects are equal.
   *
   * @param expected_p
   *          expected <code>Retour</code> object
   * @param actual_p
   *          actual <code>Retour</code> object
   */
  private void checkResponse(Retour expected_p, Retour actual_p)
  {
    Assert.assertEquals(expected_p.getResultat(), actual_p.getResultat());
    Assert.assertEquals(expected_p.getCategorie(), actual_p.getCategorie());
    Assert.assertEquals(expected_p.getDiagnostic(), actual_p.getDiagnostic());
    Assert.assertEquals(expected_p.getLibelle(), actual_p.getLibelle());
  }

  /**
   * createExpectedRequest.
   *
   * @param orderId_p
   *          The orderId param
   * @param customerId_p
   *          The customerId param
   * @param doCheckpoint_p
   *          The doCheckpoint param
   * @param domain_p
   *          The domain param
   * @param originator_p
   *          The originator param
   * @param priority_p
   *          The priority param
   * @param verb_p
   *          The verb param
   * @param podName_p
   *          The podName param
   * @param podVerb_p
   *          The podVerb param
   * @return a {@link Request} object
   */
  private Request createExpectedRequest(String orderId_p, String customerId_p, boolean doCheckpoint_p, String domain_p, String originator_p, int priority_p, String verb_p, String podName_p, String podVerb_p)
  {
    Request request = new Request();
    ServiceOrderRequest so = new ServiceOrderRequest();

    so.setOrderId(orderId_p);

    //SOD
    ServiceOrderDataRequest sod = new ServiceOrderDataRequest();
    sod.setCustomerId(customerId_p);
    sod.setDoCheckpoint(doCheckpoint_p);
    sod.setDomain(domain_p);
    sod.setOriginator(originator_p);
    sod.setPriority(priority_p);
    sod.setVerb(verb_p);

    //POD
    ProductOrderData productOrderData = new ProductOrderData();
    productOrderData.setProductName(podName_p);
    productOrderData.setProductVerb(podVerb_p);

    so.setSod(sod);
    so.getPods().add(productOrderData);

    request.setSo(so);

    return request;

  }

  /**
   *
   * @param service_p
   *          service
   * @return Pair with SA and SC
   */
  private Pair<ServiceAccessible, ServiceCommercial> createProvInService(String service_p)
  {
    ServiceCommercial serviceCommercial;
    ServiceAccessible serviceAccessible;

    String[] tab = service_p.split("/"); //$NON-NLS-1$
    String noSC = tab[0];
    String statut = "ACTIVE"; //$NON-NLS-1$
    if (tab.length == 2)
    {
      statut = tab[1];
    }

    serviceAccessible = new ServiceAccessible();
    serviceAccessible.setId("SA-REF-" + noSC); //$NON-NLS-1$
    serviceAccessible.setStatut(ServiceAccessibleStatut.fromValue(statut));
    serviceCommercial = new ServiceCommercial();
    serviceCommercial.setId("SC-REF-" + noSC); //$NON-NLS-1$
    serviceCommercial.setNoServiceCommercial(noSC);
    PIVOTREFERENCE pivotreference = new PIVOTREFERENCE();
    pivotreference.setIdref(serviceCommercial);
    serviceAccessible.setServiceCommercial(pivotreference);

    return new Pair<ServiceAccessible, ServiceCommercial>(serviceAccessible, serviceCommercial);
  }

  /**
   * createRequestINKResponse
   *
   * @param customerId
   *          the customerId
   *
   * @return a {@link Request} object
   */
  private Request createRequestINKResponse(String customerId)
  {

    Request request = new Request();
    ServiceOrderRequest so = new ServiceOrderRequest();
    so.setOrderId(ORDER_ID);

    ServiceOrderDataRequest serviceOrderDataRequest = new ServiceOrderDataRequest();
    serviceOrderDataRequest.setDomain(PROV_VERB);
    serviceOrderDataRequest.setVerb(Diagnostic.PROVISIONNER_SERVICES.toString());
    serviceOrderDataRequest.setCustomerId(customerId);
    serviceOrderDataRequest.setOriginator(ORIGINATOR_VALUE);
    serviceOrderDataRequest.setPriority(0);
    serviceOrderDataRequest.setDoCheckpoint(true);

    Dataset dataset = new Dataset();
    DatasetParam datasetParam = new DatasetParam();
    datasetParam.setName("SS51.R"); //$NON-NLS-1$
    datasetParam.setIndex(0);
    datasetParam.setValue("true"); //$NON-NLS-1$
    dataset.getParams().add(datasetParam);

    datasetParam = new DatasetParam();
    datasetParam.setName("SS21.R"); //$NON-NLS-1$
    datasetParam.setIndex(0);
    datasetParam.setValue("true"); //$NON-NLS-1$
    dataset.getParams().add(datasetParam);

    datasetParam = new DatasetParam();
    datasetParam.setName("SSB0.R.SPARAM"); //$NON-NLS-1$
    datasetParam.setIndex(0);
    datasetParam.setValue("10"); //$NON-NLS-1$
    dataset.getParams().add(datasetParam);

    datasetParam = new DatasetParam();
    datasetParam.setName("SSB0.R.SPARAM"); //$NON-NLS-1$
    datasetParam.setIndex(1);
    datasetParam.setValue("4"); //$NON-NLS-1$
    dataset.getParams().add(datasetParam);

    datasetParam = new DatasetParam();
    datasetParam.setName("SSB0.R.SPARAM"); //$NON-NLS-1$
    datasetParam.setIndex(2);
    datasetParam.setValue(""); //$NON-NLS-1$
    dataset.getParams().add(datasetParam);

    datasetParam = new DatasetParam();
    datasetParam.setName("SSB0.R.SPARAM"); //$NON-NLS-1$
    datasetParam.setIndex(3);
    datasetParam.setValue("401"); //$NON-NLS-1$
    dataset.getParams().add(datasetParam);

    datasetParam = new DatasetParam();
    datasetParam.setName("SSB0.R.SPARAM"); //$NON-NLS-1$
    datasetParam.setIndex(4);
    datasetParam.setValue("N"); //$NON-NLS-1$
    dataset.getParams().add(datasetParam);

    datasetParam = new DatasetParam();
    datasetParam.setName("SSB0.R"); //$NON-NLS-1$
    datasetParam.setIndex(0);
    datasetParam.setValue("true"); //$NON-NLS-1$
    dataset.getParams().add(datasetParam);

    datasetParam = new DatasetParam();
    datasetParam.setName("SS29.R"); //$NON-NLS-1$
    datasetParam.setIndex(0);
    datasetParam.setValue("true"); //$NON-NLS-1$
    dataset.getParams().add(datasetParam);

    datasetParam = new DatasetParam();
    datasetParam.setName("SS2B.R"); //$NON-NLS-1$
    datasetParam.setIndex(0);
    datasetParam.setValue("true"); //$NON-NLS-1$
    dataset.getParams().add(datasetParam);

    datasetParam = new DatasetParam();
    datasetParam.setName("SS8A.R"); //$NON-NLS-1$
    datasetParam.setIndex(0);
    datasetParam.setValue("true"); //$NON-NLS-1$
    dataset.getParams().add(datasetParam);

    datasetParam = new DatasetParam();
    datasetParam.setName("SS11.R"); //$NON-NLS-1$
    datasetParam.setIndex(0);
    datasetParam.setValue("true"); //$NON-NLS-1$
    dataset.getParams().add(datasetParam);

    datasetParam = new DatasetParam();
    datasetParam.setName("SS2A.R"); //$NON-NLS-1$
    datasetParam.setIndex(0);
    datasetParam.setValue("true"); //$NON-NLS-1$
    dataset.getParams().add(datasetParam);

    datasetParam = new DatasetParam();
    datasetParam.setName("SSB1.R.SPARAM"); //$NON-NLS-1$
    datasetParam.setIndex(0);
    datasetParam.setValue("1000"); //$NON-NLS-1$
    dataset.getParams().add(datasetParam);

    datasetParam = new DatasetParam();
    datasetParam.setName("SSB1.R.SPARAM"); //$NON-NLS-1$
    datasetParam.setIndex(1);
    datasetParam.setValue("4"); //$NON-NLS-1$
    dataset.getParams().add(datasetParam);

    datasetParam = new DatasetParam();
    datasetParam.setName("SSB1.R.SPARAM"); //$NON-NLS-1$
    datasetParam.setIndex(2);
    datasetParam.setValue(""); //$NON-NLS-1$
    dataset.getParams().add(datasetParam);

    datasetParam = new DatasetParam();
    datasetParam.setName("SSB1.R.SPARAM"); //$NON-NLS-1$
    datasetParam.setIndex(3);
    datasetParam.setValue("401"); //$NON-NLS-1$
    dataset.getParams().add(datasetParam);

    datasetParam = new DatasetParam();
    datasetParam.setName("SSB1.R.SPARAM"); //$NON-NLS-1$
    datasetParam.setIndex(4);
    datasetParam.setValue("N"); //$NON-NLS-1$
    dataset.getParams().add(datasetParam);

    datasetParam = new DatasetParam();
    datasetParam.setName("SSB1.R"); //$NON-NLS-1$
    datasetParam.setIndex(0);
    datasetParam.setValue("true"); //$NON-NLS-1$
    dataset.getParams().add(datasetParam);

    datasetParam = new DatasetParam();
    datasetParam.setName("SS12.R.SPARAM"); //$NON-NLS-1$
    datasetParam.setIndex(0);
    datasetParam.setValue("2"); //$NON-NLS-1$
    dataset.getParams().add(datasetParam);

    datasetParam = new DatasetParam();
    datasetParam.setName("SS12.R"); //$NON-NLS-1$
    datasetParam.setIndex(0);
    datasetParam.setValue("true"); //$NON-NLS-1$
    dataset.getParams().add(datasetParam);

    datasetParam = new DatasetParam();
    datasetParam.setName("SS41.R"); //$NON-NLS-1$
    datasetParam.setIndex(0);
    datasetParam.setValue("true"); //$NON-NLS-1$
    dataset.getParams().add(datasetParam);

    datasetParam = new DatasetParam();
    datasetParam.setName("SS42.R"); //$NON-NLS-1$
    datasetParam.setIndex(0);
    datasetParam.setValue("true"); //$NON-NLS-1$
    dataset.getParams().add(datasetParam);

    datasetParam = new DatasetParam();
    datasetParam.setName("IDTDDE"); //$NON-NLS-1$
    datasetParam.setIndex(0);
    datasetParam.setValue(FLOW_ID);
    dataset.getParams().add(datasetParam);

    datasetParam = new DatasetParam();
    datasetParam.setName("IDTPFS"); //$NON-NLS-1$
    datasetParam.setIndex(0);
    datasetParam.setValue("11700000091"); //$NON-NLS-1$
    dataset.getParams().add(datasetParam);

    datasetParam = new DatasetParam();
    datasetParam.setName("MSISDN"); //$NON-NLS-1$
    datasetParam.setIndex(0);
    datasetParam.setValue("33600300091"); //$NON-NLS-1$
    dataset.getParams().add(datasetParam);

    datasetParam = new DatasetParam();
    datasetParam.setName("IMSI"); //$NON-NLS-1$
    datasetParam.setIndex(0);
    datasetParam.setValue("208201700000091"); //$NON-NLS-1$
    dataset.getParams().add(datasetParam);

    datasetParam = new DatasetParam();
    datasetParam.setName("IDTDERIMP"); //$NON-NLS-1$
    datasetParam.setIndex(0);
    datasetParam.setValue("INJe6ee05f9dce0408aa205a0ef4ed184a5"); //$NON-NLS-1$
    dataset.getParams().add(datasetParam);

    datasetParam = new DatasetParam();
    datasetParam.setName("DATDERIMP"); //$NON-NLS-1$
    datasetParam.setIndex(0);
    datasetParam.setValue("20160215235918"); //$NON-NLS-1$
    dataset.getParams().add(datasetParam);

    datasetParam = new DatasetParam();
    datasetParam.setName("Originator"); //$NON-NLS-1$
    datasetParam.setIndex(0);
    datasetParam.setValue("SIFGP"); //$NON-NLS-1$
    dataset.getParams().add(datasetParam);

    datasetParam = new DatasetParam();
    datasetParam.setName("messageType"); //$NON-NLS-1$
    datasetParam.setIndex(0);
    datasetParam.setValue("GSMCSC"); //$NON-NLS-1$
    dataset.getParams().add(datasetParam);

    datasetParam = new DatasetParam();
    datasetParam.setName("idAppelant"); //$NON-NLS-1$
    datasetParam.setIndex(0);
    datasetParam.setValue(SOURCE_ID);
    dataset.getParams().add(datasetParam);

    datasetParam = new DatasetParam();
    datasetParam.setName("trtOrigine"); //$NON-NLS-1$
    datasetParam.setIndex(0);
    datasetParam.setValue("IWS_INFRA"); //$NON-NLS-1$
    dataset.getParams().add(datasetParam);

    datasetParam = new DatasetParam();
    datasetParam.setName("EdifactFileName"); //$NON-NLS-1$
    datasetParam.setIndex(0);
    datasetParam.setValue("103.cde3ab202e714d88afb92e24b52185ef.1.msg"); //$NON-NLS-1$
    dataset.getParams().add(datasetParam);

    datasetParam = new DatasetParam();
    datasetParam.setName("TYPE_LIGNE"); //$NON-NLS-1$
    datasetParam.setIndex(0);
    datasetParam.setValue("mobile"); //$NON-NLS-1$
    dataset.getParams().add(datasetParam);

    datasetParam = new DatasetParam();
    datasetParam.setName(MY_HEAP_NAME);
    datasetParam.setIndex(0);
    datasetParam.setValue("11700000091"); //$NON-NLS-1$
    dataset.getParams().add(datasetParam);

    datasetParam = new DatasetParam();
    datasetParam.setName(MY_HEAP_NAME);
    datasetParam.setIndex(1);
    datasetParam.setValue("33600300091"); //$NON-NLS-1$
    dataset.getParams().add(datasetParam);

    datasetParam = new DatasetParam();
    datasetParam.setName(MY_HEAP_NAME);
    datasetParam.setIndex(2);
    datasetParam.setValue("208201700000091"); //$NON-NLS-1$
    dataset.getParams().add(datasetParam);

    serviceOrderDataRequest.setDataset(dataset);
    so.setSod(serviceOrderDataRequest);

    ProductOrderData pod = new ProductOrderData();
    pod.setProductName("GSMCSC"); //$NON-NLS-1$
    pod.setProductVerb("GET"); //$NON-NLS-1$
    so.getPods().add(pod);

    request.setSo(so);

    return request;
  }

  /**
   * Gets the DatasetParam from the Request
   *
   * @param request
   *          Request
   * @param paramName
   *          DatasetParam name
   * @return DatasetParam
   */
  private DatasetParam getDatasetParamFromRequest(Request request, String paramName)
  {

    for (DatasetParam dp : request.getSo().getSod().getDataset().getParams())
    {
      if (dp.getName().equals(paramName))
      {
        return dp;
      }
    }

    return null;
  }

  /**
   * getParam.
   *
   * @param listParams_p
   *          The listParams
   * @param name_p
   *          The name param
   * @return a {@link DatasetParam} object
   */
  private DatasetParam getParam(List<DatasetParam> listParams_p, String name_p)
  {
    for (DatasetParam datasetParam : listParams_p)
    {
      if (name_p.equals(datasetParam.getName()))
      {
        return datasetParam;
      }
    }

    return null;
  }

  /**
   * get all parameters with the specified name.
   *
   * @param listParams_p
   *          The listParams
   * @param name_p
   *          The name param
   * @return list of {@link DatasetParam} object
   */
  private List<DatasetParam> getParamList(List<DatasetParam> listParams_p, String name_p)
  {
    List<DatasetParam> list = new ArrayList<DatasetParam>();

    for (DatasetParam datasetParam : listParams_p)
    {
      if (name_p.equals(datasetParam.getName()))
      {
        list.add(datasetParam);
      }
    }

    return list;
  }

  /**
   * getServicesAcessiblesPR.
   *
   * @return a {@link Collection} object
   */
  private Collection<? extends PIVOTREFERENCE> getServicesAcessiblesPR()
  {
    List<PIVOTREFERENCE> listPivotRef = new ArrayList<>();
    ServiceAccessible serviceAccessible = new ServiceAccessible();
    serviceAccessible.setId("SA-REF"); //$NON-NLS-1$
    PIVOTREFERENCE pivotreference = new PIVOTREFERENCE();
    pivotreference.setIdref(serviceAccessible);

    listPivotRef.add(pivotreference);

    for (int i = 1; i < 11; i++)
    {
      serviceAccessible = new ServiceAccessible();
      serviceAccessible.setId("SA-REF" + i); //$NON-NLS-1$
      pivotreference = new PIVOTREFERENCE();
      pivotreference.setIdref(serviceAccessible);
      listPivotRef.add(pivotreference);
    }

    return listPivotRef;
  }
}
