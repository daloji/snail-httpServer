/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PM028.activity;

import java.io.File;

import org.easymock.EasyMock;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.bouygtel.refcli.consulterpfi.in.ConsulterPFIIn;
import com.bouygtel.refcli.consulterpfi.out.ConsulterPFIOut;
import com.bouygtel.refcli.consulterpfi.out.ConsulterPFIReponseType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.utils.ACManagerUtil;
import com.bytel.ravel.common.utils.MarshallTools;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.utils.Test_Consts;
import com.bytel.spirit.common.shared.misc.ressources.Consts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.prof.activities.refclient.BL1000_ConsulterRefCli_Test;
import com.bytel.spirit.prof.connectors.generated.svccomm.TypeServiceCommercialMIM;
import com.bytel.spirit.prof.connectors.refclient.RefClientProxy;
import com.bytel.spirit.prof.connectors.svccomm.SvcCommMimProxy;
import com.bytel.spirit.prof.processes.PM028.ActionProvisionner;
import com.bytel.spirit.prof.processes.PM028.Diagnostic;
import com.bytel.spirit.prof.processes.PM028.PM028ProvisionnerPfi;
import com.bytel.spirit.prof.processes.PM028.Quadruplet;
import com.bytel.spirit.prof.processes.PM028.activity.PM028BL100DetecterConsulterPfi.PM028BL100DetecterConsulterPfiBuilder;
import com.bytel.spirit.prof.processes.generated.provisionnerpfi.ProvisionnerPfiIn;

/**
 *
 * @author lmerces
 * @version ($Revision$ $Date$)
 */
//Déclaration du runner de test pour lancer les TUs avec le runner PowerMock
@RunWith(PowerMockRunner.class)
//Préparation des classes pour les tests, toutes les classes comportant des méthodes statiques à mocker doivent être présentes dans l'annotation
@PrepareForTest({ RefClientProxy.class, SvcCommMimProxy.class })
//To avoid: SecretKeyFactory.getInstance() throws exception for all algorithms in unit tests
@PowerMockIgnore("javax.crypto.*")
public class PM028BL100DetecterConsulterPfiTest
{
  /**
  *
  */
  private static final int HTTP_OK = 200;

  /**
  *
  */
  private static final String SERVICES_IN_REQUEST_XML = "src/test/resources/provisionnerPfiIn_request.xml"; //$NON-NLS-1$

  /**
  *
  */
  private static final String CONSULTERPFI_CONNECTOR_ID = "RefClientConnector"; //$NON-NLS-1$

  /**
  *
  */
  @BeforeClass
  public static void init()
  {
    ACManagerUtil.resetACManager();
    new ClassPathXmlApplicationContext("classpath:BeansProcessTestMocks.xml"); //$NON-NLS-1$
  }

  /**
  *
  */
  @MockStrict
  private RefClientProxy _refClientConnector;

  /**
  *
  */
  @MockStrict
  private SvcCommMimProxy _svcCommMimConnector;

  /**
  *
  */
  private PM028ProvisionnerPfi _currentInstance;

  /**
   * Called before each test with the annotation @ Before to clean the connectors.
   */
  @Before
  public void beforeTest()
  {
    // on réinitialise tous les mocks afin de ne pas avoir d'interférence entre les tests
    PowerMock.resetAll();

    // On initialise toutes les classes à mocker comportant un appel à une méthode statique
    // Dans notre cas on mock statiquemement toutes les classes des activités et des proxys appelés (pour les createContexte et les getInstance)
    PowerMock.mockStaticStrict(RefClientProxy.class);
    PowerMock.mockStaticStrict(SvcCommMimProxy.class);

    // Initialize the context
    _currentInstance = new PM028ProvisionnerPfi();
    _currentInstance.initializeContext();
  }

  /**
   * Test DetecterConsulterPFI KO à cause de la consultationRefCli KO/DEF2.
   *
   * @throws RavelException
   *           thrown exception
   */
  @Test
  public void Test_DetecterConsulterPFI_KO_ConsultationRefCli_KO_DEF2() throws RavelException
  {
    Tracabilite tracabilite = new Tracabilite(StringConstants.EMPTY_STRING, Test_Consts.DEFAULT_MSGID, "PROF", "nomPRocessus", "idProcessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    ProvisionnerPfiIn provisionnerPfiIn = MarshallTools.unmarshall(ProvisionnerPfiIn.class, new File(SERVICES_IN_REQUEST_XML));
    TypeServiceCommercialMIM typeServiceCommercialMIM = new TypeServiceCommercialMIM();
    typeServiceCommercialMIM.setEnrichissementRefcliRequis(true);

    //Prepare mock
    EasyMock.expect(SvcCommMimProxy.getInstance()).andReturn(_svcCommMimConnector);
    EasyMock.expectLastCall().anyTimes();
    EasyMock.expect(RefClientProxy.getInstance()).andReturn(_refClientConnector);

    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, "1645")).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(null, false)); //$NON-NLS-1$
    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, "2")).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(typeServiceCommercialMIM, true)); //$NON-NLS-1$

    ConsulterPFIReponseType consulterPFIReponseType = BL1000_ConsulterRefCli_Test.createConsulterPFIReponseTypeResponse_NOK(Consts.DEF_2.toString(), "ERRCODE_1234", "DIAG_ERRCODE_1234"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_refClientConnector.consulterPFI(EasyMock.eq(tracabilite), EasyMock.isA(ConsulterPFIIn.class), EasyMock.eq("RefClientConnector"))).andReturn(new ConnectorResponse<ConsulterPFIReponseType, Integer>(consulterPFIReponseType, HTTP_OK)); //$NON-NLS-1$

    Quadruplet quadruplet = new Quadruplet(provisionnerPfiIn.getDonneesMetier().getPortefeuilleIndividuels().get(0), null, null, ActionProvisionner.ACTIVER_LIGNES);

    // On enregistre le scénario des appels
    PowerMock.replayAll();

    PM028BL100DetecterConsulterPfi pM028BL100DetecterConsulterPFI = new PM028BL100DetecterConsulterPfiBuilder().tracabilite(tracabilite).quadruplet(quadruplet).bouchonRefCli(false).tempsReponseConsulterPfi(0).refCliConnector(CONSULTERPFI_CONNECTOR_ID).build();
    ConsulterPFIOut result = pM028BL100DetecterConsulterPFI.execute(_currentInstance);

    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.KO, pM028BL100DetecterConsulterPFI.getRetour().getResultat());
    Assert.assertEquals(pM028BL100DetecterConsulterPFI.getRetour().getDiagnostic(), "ERRCODE_1234"); //$NON-NLS-1$
    Assert.assertEquals(pM028BL100DetecterConsulterPFI.getRetour().getLibelle(), "DIAG_ERRCODE_1234"); //$NON-NLS-1$
    Assert.assertNull(result);
  }

  /**
   * Test DetecterConsulterPFI OK avec Enrichissement non requis en sortie.
   *
   * @throws RavelException
   *           thrown exception
   */
  @Test
  public void Test_DetecterConsulterPFI_OK_EnrichissementNonRequis() throws RavelException
  {
    Tracabilite tracabilite = new Tracabilite(StringConstants.EMPTY_STRING, Test_Consts.DEFAULT_MSGID, "PROF", "nomPRocessus", "idProcessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    ProvisionnerPfiIn provisionnerPfiIn = MarshallTools.unmarshall(ProvisionnerPfiIn.class, new File(SERVICES_IN_REQUEST_XML));

    //Prepare mock
    EasyMock.expect(SvcCommMimProxy.getInstance()).andReturn(_svcCommMimConnector);
    EasyMock.expectLastCall().anyTimes();

    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, "1645")).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(null, false)); //$NON-NLS-1$
    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, "2")).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(null, false)); //$NON-NLS-1$

    // On enregistre le scénario des appels
    PowerMock.replayAll();

    Quadruplet quadruplet = new Quadruplet(provisionnerPfiIn.getDonneesMetier().getPortefeuilleIndividuels().get(0), null, null, ActionProvisionner.ACTIVER_LIGNES);

    PM028BL100DetecterConsulterPfi pM028BL100DetecterConsulterPFI = new PM028BL100DetecterConsulterPfiBuilder().tracabilite(tracabilite).quadruplet(quadruplet).bouchonRefCli(false).tempsReponseConsulterPfi(0).refCliConnector(CONSULTERPFI_CONNECTOR_ID).build();
    ConsulterPFIOut result = pM028BL100DetecterConsulterPFI.execute(_currentInstance);

    // On enregistre le scénario des appels
    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.OK, pM028BL100DetecterConsulterPFI.getRetour().getResultat());
    Assert.assertNull(result);
  }

  /**
   * Test DetecterConsulterPFI OK avec Enrichissement non requis en sortie.
   *
   * @throws RavelException
   *           thrown exception
   */
  @Test
  public void Test_DetecterConsulterPFI_OK_EnrichissementNonRequis_Action() throws RavelException
  {
    Tracabilite tracabilite = new Tracabilite(StringConstants.EMPTY_STRING, Test_Consts.DEFAULT_MSGID, "PROF", "nomPRocessus", "idProcessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    ProvisionnerPfiIn provisionnerPfiIn = MarshallTools.unmarshall(ProvisionnerPfiIn.class, new File(SERVICES_IN_REQUEST_XML));

    Quadruplet quadruplet = new Quadruplet(provisionnerPfiIn.getDonneesMetier().getPortefeuilleIndividuels().get(0), null, null, ActionProvisionner.SUSPENDRE_LIGNES);

    PM028BL100DetecterConsulterPfi pM028BL100DetecterConsulterPFI = new PM028BL100DetecterConsulterPfiBuilder().tracabilite(tracabilite).quadruplet(quadruplet).bouchonRefCli(false).tempsReponseConsulterPfi(0).refCliConnector(CONSULTERPFI_CONNECTOR_ID).build();
    ConsulterPFIOut result = pM028BL100DetecterConsulterPFI.execute(_currentInstance);

    Assert.assertEquals(StringConstants.OK, pM028BL100DetecterConsulterPFI.getRetour().getResultat());
    Assert.assertNull(result);
  }

  /**
   * Test DetecterConsulterPFI OK avec Enrichissement requis en sortie pour le PFI.
   *
   * @throws RavelException
   *           thrown exception
   */
  @Test
  public void Test_DetecterConsulterPFI_OK_EnrichissementRequis() throws RavelException
  {
    Tracabilite tracabilite = new Tracabilite(StringConstants.EMPTY_STRING, Test_Consts.DEFAULT_MSGID, "PROF", "nomPRocessus", "idProcessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    ProvisionnerPfiIn provisionnerPfiIn = MarshallTools.unmarshall(ProvisionnerPfiIn.class, new File(SERVICES_IN_REQUEST_XML));
    TypeServiceCommercialMIM typeServiceCommercialMIM = new TypeServiceCommercialMIM();
    typeServiceCommercialMIM.setEnrichissementRefcliRequis(true);

    ConsulterPFIReponseType consulterPFIReponseType = BL1000_ConsulterRefCli_Test.createConsulterPFIReponseTypeBasicResponseOK();

    //Prepare mock
    EasyMock.expect(SvcCommMimProxy.getInstance()).andReturn(_svcCommMimConnector);
    EasyMock.expectLastCall().anyTimes();
    EasyMock.expect(RefClientProxy.getInstance()).andReturn(_refClientConnector);

    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, "1645")).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(null, false)); //$NON-NLS-1$
    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, "2")).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(typeServiceCommercialMIM, true)); //$NON-NLS-1$

    EasyMock.expect(_refClientConnector.consulterPFI(EasyMock.eq(tracabilite), EasyMock.isA(ConsulterPFIIn.class), EasyMock.eq("RefClientConnector"))).andReturn(new ConnectorResponse<ConsulterPFIReponseType, Integer>(consulterPFIReponseType, HTTP_OK)); //$NON-NLS-1$

    // On enregistre le scénario des appels
    PowerMock.replayAll();

    Quadruplet quadruplet = new Quadruplet(provisionnerPfiIn.getDonneesMetier().getPortefeuilleIndividuels().get(0), null, null, ActionProvisionner.ACTIVER_LIGNES);

    PM028BL100DetecterConsulterPfi pM028BL100DetecterConsulterPFI = new PM028BL100DetecterConsulterPfiBuilder().tracabilite(tracabilite).quadruplet(quadruplet).bouchonRefCli(false).tempsReponseConsulterPfi(0).refCliConnector(CONSULTERPFI_CONNECTOR_ID).build();
    ConsulterPFIOut result = pM028BL100DetecterConsulterPFI.execute(_currentInstance);

    // On enregistre le scénario des appels
    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.OK, pM028BL100DetecterConsulterPFI.getRetour().getResultat());
    Assert.assertNotNull(result);
    Assert.assertEquals(result, consulterPFIReponseType.getConsulterPFIOut());
  }

  /**
   * Test DetecterConsulterPFI OK avec Enrichissement requis en sortie pour le PFI dans le mode BouchonRefCli.
   *
   * @throws RavelException
   *           thrown exception
   */
  @Test
  public void Test_DetecterConsulterPFI_OK_EnrichissementRequis_BouchonRefCli() throws RavelException
  {
    Tracabilite tracabilite = new Tracabilite(StringConstants.EMPTY_STRING, Test_Consts.DEFAULT_MSGID, "PROF", "nomPRocessus", "idProcessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    ProvisionnerPfiIn provisionnerPfiIn = MarshallTools.unmarshall(ProvisionnerPfiIn.class, new File(SERVICES_IN_REQUEST_XML));
    TypeServiceCommercialMIM typeServiceCommercialMIM = new TypeServiceCommercialMIM();
    typeServiceCommercialMIM.setEnrichissementRefcliRequis(true);

    //Prepare mock
    EasyMock.expect(SvcCommMimProxy.getInstance()).andReturn(_svcCommMimConnector);
    EasyMock.expectLastCall().anyTimes();

    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, "1645")).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(null, false)); //$NON-NLS-1$
    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, "2")).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(typeServiceCommercialMIM, true)); //$NON-NLS-1$

    Quadruplet quadruplet = new Quadruplet(provisionnerPfiIn.getDonneesMetier().getPortefeuilleIndividuels().get(0), null, null, ActionProvisionner.ACTIVER_LIGNES);

    // On enregistre le scénario des appels
    PowerMock.replayAll();

    PM028BL100DetecterConsulterPfi pM028BL100DetecterConsulterPFI = new PM028BL100DetecterConsulterPfiBuilder().tracabilite(tracabilite).quadruplet(quadruplet).bouchonRefCli(true).tempsReponseConsulterPfi(5000).refCliConnector(CONSULTERPFI_CONNECTOR_ID).build();
    ConsulterPFIOut result = pM028BL100DetecterConsulterPFI.execute(_currentInstance);

    // On enregistre le scénario des appels
    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.OK, pM028BL100DetecterConsulterPFI.getRetour().getResultat());
    Assert.assertEquals(Diagnostic.BOUCHON_REFCLI.toString(), pM028BL100DetecterConsulterPFI.getRetour().getDiagnostic());
    Assert.assertNull(result);
  }
}
