/*******************************************************************************
* $Id: PP0306_TraitementErreursSpiritTest.java 21974 2019-05-27 15:37:38Z fbarnabe $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PP0306;

import static org.junit.Assert.assertEquals;

import java.text.MessageFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.reflect.Whitebox;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.data.exchange.generated.RavelRequest.RequestHeader;
import com.bytel.ravel.common.datetime.DateTimeManager;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.request.Parameter;
import com.bytel.ravel.common.factory.request.UrlParameters;
import com.bytel.ravel.common.factory.response.IRavelResponse;
import com.bytel.ravel.common.factory.response.RavelResponseFactory;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.test.JUnitTools;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.utils.ACManagerUtil;
import com.bytel.ravel.common.utils.DateTimeTools.DateTimeFormatPattern;
import com.bytel.ravel.common.utils.Mode;
import com.bytel.ravel.common.utils.Pair;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.RetourFactoryForTU;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.ProcessManager;
import com.bytel.ravel.services.utils.Test_Consts;
import com.bytel.spirit.common.activities.shared.BL5100_CreerActionCorrective;
import com.bytel.spirit.common.activities.shared.BL5100_CreerActionCorrective.BL5100_CreerActionCorrectiveBuilder;
import com.bytel.spirit.common.activities.shared.BL5110_ExecuterActionCorrective;
import com.bytel.spirit.common.activities.shared.BL5110_ExecuterActionCorrective.BL5110_ExecuterActionCorrectiveBuilder;
import com.bytel.spirit.common.connectors.cmd.CMDProxy;
import com.bytel.spirit.common.connectors.rex.REXProxy;
import com.bytel.spirit.common.connectors.rst.RSTProxy;
import com.bytel.spirit.common.connectors.stark.STARKProxy;
import com.bytel.spirit.common.connectors.stark.structs.STARKResponse;
import com.bytel.spirit.common.shared.functional.types.json.action_corrective.ActionCorrective;
import com.bytel.spirit.common.shared.functional.types.json.action_corrective.ActionServiceTechnique;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.BasicResponse;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.ressources.RetourConverter;
import com.bytel.spirit.common.shared.misc.tracabilite.IRefFoncConstants;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.cmd.Statut;
import com.bytel.spirit.common.shared.saab.rex.ErreurSpirit;
import com.bytel.spirit.common.shared.saab.rex.ErreurSpiritStatut;
import com.bytel.spirit.common.shared.saab.rex.request.UpdateErreurSpiritRequest;
import com.bytel.spirit.common.shared.saab.rst.ServiceTechnique;
import com.bytel.spirit.prof.processes.Messages;
import com.bytel.spirit.prof.processes.PP0306.PP0306_TraitementErreursSpirit.ParameterUrl;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 * PP0306_TraitementErreursSpirit Tests class
 *
 * @author lchanyip
 * @version ($Revision: 21974 $ $Date: 2019-05-27 17:37:38 +0200 (lun. 27 mai 2019) $)
 */
@RunWith(PowerMockRunner.class)
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
@PrepareForTest({ PP0306_TraitementErreursSpirit.class, ProcessManager.class, RSTProxy.class, REXProxy.class, STARKProxy.class, CMDProxy.class, BL5100_CreerActionCorrective.class, BL5110_ExecuterActionCorrective.class })
public class PP0306_TraitementErreursSpiritTest
{
  /**
   *
   */
  private static final String PP0306_BL100_TRAITER_ERREUR_SPIRIT = "PP0306_BL100_TraiterErreurSpirit"; //$NON-NLS-1$

  /**
   *
   */
  private static final String PP0306_BL102_APPLIQUER_ACTION_CORRECTIVE = "PP0306_BL102_AppliquerActionCorrective"; //$NON-NLS-1$

  /**
   *
   */
  private static final String PP0306_BL101_IDENTIFIER_ERREUR_SPIRIT_ELIGIBLE = "PP0306_BL101_IdentifierErreurSpiritEligible"; //$NON-NLS-1$

  /**
   *
   */
  private static final String PP0306_BL001_VERIFIER_DONNEES = "PP0306_BL001_VerifierDonnees"; //$NON-NLS-1$

  /**
   *
   */
  private static final String X_REQUEST_ID_TEST = "9fe5b1ca-edc5-4731-a044-acf6ce4bcb26"; //$NON-NLS-1$

  /**
   * Tracabilite
   */
  private static Tracabilite _tracabilite;

  /**
   * Factory de génération des beans
   */
  private static PodamFactory __podam = new PodamFactoryImpl();

  /**
   * SPRING context
   */
  @SuppressWarnings("unused")
  private static ClassPathXmlApplicationContext __context;

  /**
   * The default process name.
   */
  public static final String DEFAULT_PROCESSNAME = "PP0306_TraitementErreursSpirit"; //$NON-NLS-1$

  /**
   * Creation of a parameter
   *
   * @param name_p
   *          The Name
   * @param value_p
   *          The value
   *
   * @return Parameter
   */
  public static Parameter createParameter(String name_p, String value_p)
  {
    return new Parameter(name_p, value_p);
  }

  /**
   * Initialization method: Create: - spring context - connectors - service manager.
   *
   * @throws RavelException
   *           the exception
   */
  @BeforeClass
  public static void executedBeforeAll() throws RavelException
  {
    // désactivation du cache podam
    __podam.getStrategy().setMemoization(false);
    __podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());

    ACManagerUtil.resetACManager();
    __context = new ClassPathXmlApplicationContext("classpath:BeansProcessTestMocks.xml"); //$NON-NLS-1$

    DateTimeManager.getInstance().initialize(Mode.FIXED);
    DateTimeManager.getInstance().setFixedClockAt(DateTimeManager.getInstance().now());

  }

  /**
   * Instance of {@link PP0306_TraitementErreursSpirit}
   */
  private PP0306_TraitementErreursSpirit _processInstance;

  /**
   * REX PRoxy
   */
  @MockStrict
  private REXProxy _rexProxy;

  /**
   * STARK proxy
   */
  @MockStrict
  private STARKProxy _starkProxy;

  /**
   * CMD Proxy
   */
  @MockStrict
  private CMDProxy _cmdProxy;

  /**
   * REX PRoxy
   */
  @MockStrict
  private RSTProxy _rstProxy;

  /**
   * Mock de {@link ProcessManager}
   */
  @MockStrict
  ProcessManager _processManager;

  /**
   * Mock de {@Code BL5100_CreerActionCorrective}
   */
  @MockStrict
  protected BL5100_CreerActionCorrective _bl5100Mock;

  /**
   * Mock de {@Code BL5110_ExecuterActionCorrective}
   */
  @MockStrict
  protected BL5110_ExecuterActionCorrective _bl5110Mock;

  /**
   * executed Before Each test
   *
   * @throws IllegalAccessException
   *           On error
   * @throws NoSuchFieldException
   *           On error
   */
  @Before
  public void executedBeforeEach() throws NoSuchFieldException, IllegalAccessException
  {
    _processInstance = new PP0306_TraitementErreursSpirit();
    _processInstance.initializeContext();

    _tracabilite = new Tracabilite();
    _tracabilite.setIdCorrelationByTel(X_REQUEST_ID_TEST);
    _tracabilite.setIdProcessusSpirit(_processInstance.getIdProcess());
    _tracabilite.setIdCorrelationSpirit(Test_Consts.DEFAULT_MSGID);
    _tracabilite.setNomProcessus(StringConstants.EMPTY_STRING);
    _tracabilite.setNomSysteme(System.getenv("SERVICE")); //$NON-NLS-1$

    ProcessManager.getInstance().getProcessParams().clear();

    // on réinitialise tous les mocks afin de ne pas avoir d'interférence entre les tests
    PowerMock.resetAll();

    PowerMock.mockStatic(RSTProxy.class);
    PowerMock.mockStatic(REXProxy.class);
    PowerMock.mockStatic(STARKProxy.class);
    PowerMock.mockStatic(CMDProxy.class);
    PowerMock.mockStatic(BL5100_CreerActionCorrective.class);
    PowerMock.mockStatic(BL5110_ExecuterActionCorrective.class);
    PowerMock.mockStaticStrict(ProcessManager.class);
  }

  /**
   * <b>Scenario:</b> PI0306_BL001_VerifierDonnees test suite.<br>
   * <b>Input:</b> dateDeb+dateFin ou profondeurRechercheMin<br>
   * <b>Result:</b> Retour OK/NOK
   *
   * @throws Throwable
   *           On error
   */
  @Test
  public void PP0306_BL001_VerifierDonnees_Tests() throws Throwable
  {
    //Process Manager Mock
    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams();
    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    //Test header X-Request-ID not provided
    Request request = prepareRequest(null, null, "xx", null); //$NON-NLS-1$
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();
    Retour bl001Retour = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ, DateTimeFormatPattern.yyyy_dash_MM_dash_dd).fromJson(request.getResponse().getResult(), Retour.class);
    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString("PP0306.HeaderNullOrEmpty"), IHttpHeadersConsts.X_REQUEST_ID)); //$NON-NLS-1$
    assertEquals(expectedRetour, bl001Retour);

    //test invalid profondeurRechercheMin query param
    request = prepareRequest(null, null, "xx", X_REQUEST_ID_TEST); //$NON-NLS-1$
    bl001Retour = Whitebox.invokeMethod(_processInstance, PP0306_BL001_VERIFIER_DONNEES, _tracabilite, request);
    expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString("PP0306.InvalidQueryParamValue"), ParameterUrl.profondeurRecherche.name(), "xx")); //$NON-NLS-1$ //$NON-NLS-2$
    assertEquals(expectedRetour, bl001Retour);

    //test invalid negative profondeurRechercheMin query param value
    request = prepareRequest(null, null, "-10", X_REQUEST_ID_TEST); //$NON-NLS-1$
    bl001Retour = Whitebox.invokeMethod(_processInstance, PP0306_BL001_VERIFIER_DONNEES, _tracabilite, request);
    expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString("PP0306.InvalidQueryParamValue"), ParameterUrl.profondeurRecherche.name(), "-10")); //$NON-NLS-1$ //$NON-NLS-2$
    assertEquals(expectedRetour, bl001Retour);

    //test profondeurRechercheMin query param that exceeds max value
    request = prepareRequest(null, null, "2999", X_REQUEST_ID_TEST); //$NON-NLS-1$
    bl001Retour = Whitebox.invokeMethod(_processInstance, PP0306_BL001_VERIFIER_DONNEES, _tracabilite, request);
    expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString("PP0306.InvalidQueryParamValue"), ParameterUrl.profondeurRecherche.name(), "2999")); //$NON-NLS-1$ //$NON-NLS-2$
    assertEquals(expectedRetour, bl001Retour);

    //test OK with profondeurRechercheMin query param with a valid value
    request = prepareRequest(null, null, "120", X_REQUEST_ID_TEST); //$NON-NLS-1$
    bl001Retour = Whitebox.invokeMethod(_processInstance, PP0306_BL001_VERIFIER_DONNEES, _tracabilite, request);
    expectedRetour = RetourFactoryForTU.createOkRetour();
    assertEquals(expectedRetour, bl001Retour);

    //test missing dateDeb query param
    request = prepareRequest(null, "2018-10-01T22:00", null, X_REQUEST_ID_TEST); //$NON-NLS-1$
    bl001Retour = Whitebox.invokeMethod(_processInstance, PP0306_BL001_VERIFIER_DONNEES, _tracabilite, request);
    expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString("PP0306.QueryParamNotProvided"), ParameterUrl.dateDebut.name())); //$NON-NLS-1$
    assertEquals(expectedRetour, bl001Retour);

    //test empty value for dateDeb query param
    request = prepareRequest(null, "2018-10-01T22:00", null, X_REQUEST_ID_TEST); //$NON-NLS-1$
    bl001Retour = Whitebox.invokeMethod(_processInstance, PP0306_BL001_VERIFIER_DONNEES, _tracabilite, request);
    expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString("PP0306.QueryParamNotProvided"), ParameterUrl.dateDebut.name())); //$NON-NLS-1$
    assertEquals(expectedRetour, bl001Retour);

    //test invalid dateDeb query param value
    request = prepareRequest("xxx", "2018-10-01T22:00", null, X_REQUEST_ID_TEST); //$NON-NLS-1$ //$NON-NLS-2$
    bl001Retour = Whitebox.invokeMethod(_processInstance, PP0306_BL001_VERIFIER_DONNEES, _tracabilite, request);
    expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString("PP0306.InvalidQueryParamValue"), ParameterUrl.dateDebut.name(), "xxx")); //$NON-NLS-1$ //$NON-NLS-2$
    assertEquals(expectedRetour, bl001Retour);

    //test missing dateFin query param
    request = prepareRequest("2018-10-01T22:00", null, null, X_REQUEST_ID_TEST); //$NON-NLS-1$
    bl001Retour = Whitebox.invokeMethod(_processInstance, PP0306_BL001_VERIFIER_DONNEES, _tracabilite, request);
    expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString("PP0306.QueryParamNotProvided"), ParameterUrl.dateFin.name())); //$NON-NLS-1$
    assertEquals(expectedRetour, bl001Retour);

    //test empty value for dateFin query param
    request = prepareRequest("2018-10-01T22:00", "", null, X_REQUEST_ID_TEST); //$NON-NLS-1$ //$NON-NLS-2$
    bl001Retour = Whitebox.invokeMethod(_processInstance, PP0306_BL001_VERIFIER_DONNEES, _tracabilite, request);
    expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString("PP0306.QueryParamNotProvided"), ParameterUrl.dateFin.name())); //$NON-NLS-1$
    assertEquals(expectedRetour, bl001Retour);

    //test invalid dateFin query param value
    request = prepareRequest("2018-10-01T22:00", "yyy", null, X_REQUEST_ID_TEST); //$NON-NLS-1$ //$NON-NLS-2$
    bl001Retour = Whitebox.invokeMethod(_processInstance, PP0306_BL001_VERIFIER_DONNEES, _tracabilite, request);
    expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString("PP0306.InvalidQueryParamValue"), ParameterUrl.dateFin.name(), "yyy")); //$NON-NLS-1$ //$NON-NLS-2$
    assertEquals(expectedRetour, bl001Retour);

    //Test KO with dateFin <= dateDeb
    request = prepareRequest("2018-10-01T22:00", "2018-10-01T20:00", null, X_REQUEST_ID_TEST); //$NON-NLS-1$ //$NON-NLS-2$
    bl001Retour = Whitebox.invokeMethod(_processInstance, PP0306_BL001_VERIFIER_DONNEES, _tracabilite, request);
    expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, Messages.getString("PP0306.InvalidDateDebDateFinQueryParamValue")); //$NON-NLS-1$
    assertEquals(expectedRetour, bl001Retour);

    //test OK with 2 valid dateDeb and dateFin query params
    request = prepareRequest("2018-10-01T21:00", "2018-10-01T22:00", null, X_REQUEST_ID_TEST); //$NON-NLS-1$ //$NON-NLS-2$
    bl001Retour = Whitebox.invokeMethod(_processInstance, PP0306_BL001_VERIFIER_DONNEES, _tracabilite, request);
    expectedRetour = RetourFactoryForTU.createOkRetour();
    assertEquals(expectedRetour, bl001Retour);
  }

  /**
   * <b>Scenario:</b> PP0306_BL100_TraiterErreurSpirit test with an ErreurSpirit object already processed (the RefFonc
   * map contains a previous iderreurspirit).<br>
   * <b>Input: dateDeb, dateFin</b> <br>
   * <b>Result:</b> Retour OK
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PP0306_BL100_TraiterErreurSpirit_Test_Ignore_ErreurSpirit_Already_Processed() throws Exception
  {
    //Set the _processInstance._processContext._filterConfigFile to "src/test/resources/PP0306_ErreurSpirit_filters_test.txt"
    Object context = JUnitTools.getInaccessibleFieldValue(_processInstance, "_processContext");
    JUnitTools.setInaccessibleFieldValue(context, "_filterConfigFile", "src/test/resources/PP0306_ErreurSpirit_filters_test.txt");
    JUnitTools.setInaccessibleFieldValue(context, "_maxProcessingRatePerSec", 10);
    JUnitTools.setInaccessibleFieldValue(context, "_maxProfondeur", 2880);

    JUnitTools.setInaccessibleFieldValue(context, "_xRequestId", X_REQUEST_ID_TEST);

    LocalDateTime dateDeb = LocalDateTime.parse("2018-12-10T11:30", PP0306_TraitementErreursSpirit.InputDateTimeformatter); //$NON-NLS-1$
    LocalDateTime dateFin = LocalDateTime.parse("2018-12-10T12:30", PP0306_TraitementErreursSpirit.InputDateTimeformatter); //$NON-NLS-1$

    //mock REX.erreurSpiritLireTousParStatutPeriod to return OK
    String idErreurSpirit = "test"; //$NON-NLS-1$

    ErreurSpirit erreurSpirit = new ErreurSpirit(idErreurSpirit, RetourConverter.convertToJsonRetour(RetourFactoryForTU.createNOK("CAT-4", "TRAITEMENT_ARRETE", "blablabla Test1")), ErreurSpiritStatut.OUVERT.name(), dateDeb, dateDeb, _tracabilite); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    Tracabilite tracabilite = new Tracabilite();
    Map<String, String> refFonc = new HashMap<>();
    refFonc.put(IRefFoncConstants.ID_ERREUR_SPIRIT, "id1");
    tracabilite.setRefFonc(refFonc);

    erreurSpirit.setTracabilite(tracabilite);
    ConnectorResponse<Retour, List<ErreurSpirit>> expectedResponse = new ConnectorResponse<Retour, List<ErreurSpirit>>(RetourFactoryForTU.createOkRetour(), Arrays.asList(erreurSpirit));
    prepareMockREXerreurSpiritLireTousParStatutPeriod(Tools.formatDateTimeForPAD6003(dateDeb), Tools.formatDateTimeForPAD6003(dateFin), expectedResponse);

    //test
    PowerMock.replayAll();
    Retour bl100Retour = Whitebox.invokeMethod(_processInstance, PP0306_BL100_TRAITER_ERREUR_SPIRIT, _tracabilite, dateDeb, dateFin, false);
    PowerMock.verifyAll();

    assertEquals(RetourFactoryForTU.createOkRetour(), bl100Retour);
  }

  /**
   * <b>Scenario:</b> PP0306_BL100_TraiterErreurSpirit test with an ErreurSpirit that matches a TypeDecision value that
   * is not implemented .<br>
   * <b>Input: dateDeb, dateFin</b> <br>
   * <b>Result:</b> Retour OK
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PP0306_BL100_TraiterErreurSpirit_Test_With_Not_Unknown_TypeDecision() throws Exception
  {
    //Set the _processInstance._processContext._filterConfigFile to "src/test/resources/PP0306_ErreurSpirit_filters_test.txt"
    Object context = JUnitTools.getInaccessibleFieldValue(_processInstance, "_processContext"); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(context, "_filterConfigFile", "src/test/resources/PP0306_ErreurSpirit_filters_test.txt"); //$NON-NLS-1$ //$NON-NLS-2$
    JUnitTools.setInaccessibleFieldValue(context, "_xRequestId", X_REQUEST_ID_TEST); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(context, "_maxProcessingRatePerSec", 10);
    JUnitTools.setInaccessibleFieldValue(context, "_maxProfondeur", 2880);

    LocalDateTime dateDeb = LocalDateTime.parse("2018-12-10T11:30", PP0306_TraitementErreursSpirit.InputDateTimeformatter); //$NON-NLS-1$
    LocalDateTime dateFin = LocalDateTime.parse("2018-12-10T12:30", PP0306_TraitementErreursSpirit.InputDateTimeformatter); //$NON-NLS-1$

    //mock REX.erreurSpiritLireTousParStatutPeriod to return OK
    String idErreurSpirit = "test"; //$NON-NLS-1$

    ErreurSpirit erreurSpirit = new ErreurSpirit(idErreurSpirit, RetourConverter.convertToJsonRetour(RetourFactoryForTU.createNOK("CAT-3", "DONNEE_INCOHERENTE", "test TypeDecision non implemented")), ErreurSpiritStatut.OUVERT.name(), dateDeb, dateDeb, _tracabilite); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    Tracabilite tracabilite = new Tracabilite();
    Map<String, String> refFonc = new HashMap<>();
    String noCompte = "nocompte123"; //$NON-NLS-1$
    String clientOperateur = "cliop123"; //$NON-NLS-1$
    refFonc.put(IRefFoncConstants.NO_COMPTE, noCompte);
    refFonc.put(IRefFoncConstants.CLI_OPE, clientOperateur);
    tracabilite.setRefFonc(refFonc);

    erreurSpirit.setTracabilite(tracabilite);
    ConnectorResponse<Retour, List<ErreurSpirit>> expectedResponse = new ConnectorResponse<Retour, List<ErreurSpirit>>(RetourFactoryForTU.createOkRetour(), Arrays.asList(erreurSpirit));
    prepareMockREXerreurSpiritLireTousParStatutPeriod(Tools.formatDateTimeForPAD6003(dateDeb), Tools.formatDateTimeForPAD6003(dateFin), expectedResponse);

    //test
    PowerMock.replayAll();
    Retour bl100Retour = Whitebox.invokeMethod(_processInstance, PP0306_BL100_TRAITER_ERREUR_SPIRIT, _tracabilite, dateDeb, dateFin, false);
    PowerMock.verifyAll();

    assertEquals(RetourFactoryForTU.createOkRetour(), bl100Retour);
  }

  /**
   * <b>Scenario:</b> PP0306_BL100_TraiterErreurSpirit test with RefFoncMap Null or empty.<br>
   * <b>Input: dateDeb, dateFin</b> <br>
   * <b>Result:</b> Retour OK
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PP0306_BL100_TraiterErreurSpirit_Test_With_RefFoncMapNullorEmpty() throws Exception
  {
    //Set the _processInstance._processContext._filterConfigFile to "src/test/resources/PP0306_ErreurSpirit_filters_test.txt"
    Object context = JUnitTools.getInaccessibleFieldValue(_processInstance, "_processContext"); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(context, "_filterConfigFile", "src/test/resources/PP0306_ErreurSpirit_filters_test.txt"); //$NON-NLS-1$ //$NON-NLS-2$
    JUnitTools.setInaccessibleFieldValue(context, "_xRequestId", X_REQUEST_ID_TEST); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(context, "_maxProcessingRatePerSec", 10);
    JUnitTools.setInaccessibleFieldValue(context, "_maxProfondeur", 2880);

    LocalDateTime dateDeb = LocalDateTime.parse("2018-12-10T11:30", PP0306_TraitementErreursSpirit.InputDateTimeformatter); //$NON-NLS-1$
    LocalDateTime dateFin = LocalDateTime.parse("2018-12-10T12:30", PP0306_TraitementErreursSpirit.InputDateTimeformatter); //$NON-NLS-1$

    //mock REX.erreurSpiritLireTousParStatutPeriod to return OK
    String idErreurSpirit = "test"; //$NON-NLS-1$

    ErreurSpirit erreurSpirit = new ErreurSpirit(idErreurSpirit, RetourConverter.convertToJsonRetour(RetourFactoryForTU.createNOK("CAT-4", "TRAITEMENT_ARRETE", "blablabla Test1")), ErreurSpiritStatut.OUVERT.name(), dateDeb, dateDeb, _tracabilite); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    Tracabilite tracabilite = new Tracabilite();
    Map<String, String> refFonc = new HashMap<>();
    tracabilite.setRefFonc(refFonc); //empty RefFonc map
    erreurSpirit.setTracabilite(tracabilite);
    ConnectorResponse<Retour, List<ErreurSpirit>> expectedResponse = new ConnectorResponse<Retour, List<ErreurSpirit>>(RetourFactoryForTU.createOkRetour(), Arrays.asList(erreurSpirit));
    prepareMockREXerreurSpiritLireTousParStatutPeriod(Tools.formatDateTimeForPAD6003(dateDeb), Tools.formatDateTimeForPAD6003(dateFin), expectedResponse);

    //test
    PowerMock.replayAll();
    Retour bl100Retour = Whitebox.invokeMethod(_processInstance, PP0306_BL100_TRAITER_ERREUR_SPIRIT, _tracabilite, dateDeb, dateFin, false);
    PowerMock.verifyAll();

    assertEquals(RetourFactoryForTU.createOkRetour(), bl100Retour);
  }

  /**
   * <b>Scenario:</b> PP0306_BL100_TraiterErreurSpirit test NOK (Tools.loadFiltersFromConfigFile returns
   * NOK/CAT-4/CONFIGURATION_INVALIDE because the filter file is empty).<br>
   * <b>Input: dateDeb, dateFin</b> <br>
   * <b>Result:</b> Retour OK
   *
   * @throws IllegalAccessException
   *           On error
   * @throws NoSuchFieldException
   *           On error
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PP0306_BL100_TraiterErreurSpirit_TestKO_001() throws Exception
  {
    //Set the _processInstance._processContext._filterConfigFile to "src/test/resources/PP0306_ErreurSpirit_filters_test_empty.txt"
    Object context = JUnitTools.getInaccessibleFieldValue(_processInstance, "_processContext"); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(context, "_filterConfigFile", "src/test/resources/PP0306_ErreurSpirit_filters_test_empty.txt"); //empty file //$NON-NLS-1$ //$NON-NLS-2$
    JUnitTools.setInaccessibleFieldValue(context, "_maxProcessingRatePerSec", 10);
    JUnitTools.setInaccessibleFieldValue(context, "_maxProfondeur", 2880);

    LocalDateTime dateDeb = LocalDateTime.parse("2018-12-10T11:30", PP0306_TraitementErreursSpirit.InputDateTimeformatter); //$NON-NLS-1$
    LocalDateTime dateFin = LocalDateTime.parse("2018-12-10T12:30", PP0306_TraitementErreursSpirit.InputDateTimeformatter); //$NON-NLS-1$

    String error = Messages.getString("PP0306.AucuneDecisionConfiguree"); //$NON-NLS-1$
    Retour expectedRetour = RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, error);

    PowerMock.replayAll();
    Retour bl100Retour = Whitebox.invokeMethod(_processInstance, PP0306_BL100_TRAITER_ERREUR_SPIRIT, _tracabilite, dateDeb, dateFin, false);
    PowerMock.verifyAll();

    assertEquals(expectedRetour, bl100Retour);
  }

  /**
   * <b>Scenario:</b> PP0306_BL100_TraiterErreurSpirit test KO (REX.erreurSpiritLireTousParStatutPeriod returns
   * NOK/CAT-1/LECTURE_INDISPONIBLE).<br>
   * <b>Input: dateDeb, dateFin</b> <br>
   * <b>Result:</b> Retour NOK/CAT-1/LECTURE_INDISPONIBLE
   *
   * @throws IllegalAccessException
   *           On error
   * @throws NoSuchFieldException
   *           On error
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PP0306_BL100_TraiterErreurSpirit_TestKO_002() throws Exception
  {
    //Set the _processInstance._processContext._filterConfigFile to "src/test/resources/PP0306_ErreurSpirit_filters_test.txt"
    Object context = JUnitTools.getInaccessibleFieldValue(_processInstance, "_processContext"); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(context, "_filterConfigFile", "src/test/resources/PP0306_ErreurSpirit_filters_test.txt"); //$NON-NLS-1$ //$NON-NLS-2$
    JUnitTools.setInaccessibleFieldValue(context, "_maxProcessingRatePerSec", 10);
    JUnitTools.setInaccessibleFieldValue(context, "_maxProfondeur", 2880);

    LocalDateTime dateDeb = LocalDateTime.parse("2018-12-10T11:30", PP0306_TraitementErreursSpirit.InputDateTimeformatter); //$NON-NLS-1$
    LocalDateTime dateFin = LocalDateTime.parse("2018-12-10T12:30", PP0306_TraitementErreursSpirit.InputDateTimeformatter); //$NON-NLS-1$

    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT1, IMegSpiritConsts.LECTURE_INDISPONIBLE, "test technical error", null); //$NON-NLS-1$
    ConnectorResponse<Retour, List<ErreurSpirit>> expectedResponse = new ConnectorResponse<Retour, List<ErreurSpirit>>(expectedRetour, null);
    prepareMockREXerreurSpiritLireTousParStatutPeriod(Tools.formatDateTimeForPAD6003(dateDeb), Tools.formatDateTimeForPAD6003(dateFin), expectedResponse);

    PowerMock.replayAll();
    Retour bl100Retour = Whitebox.invokeMethod(_processInstance, PP0306_BL100_TRAITER_ERREUR_SPIRIT, _tracabilite, dateDeb, dateFin, false);
    PowerMock.verifyAll();

    assertEquals(expectedRetour, bl100Retour);
  }

  /**
   * <b>Scenario:</b> PP0306_BL100_TraiterErreurSpirit test KO (PP0306_BL102_AppliquerActionCorrective returns
   * NOK/CAT-1/LECTURE_INDISPONIBLE).<br>
   * <b>Input: dateDeb, dateFin</b> <br>
   * <b>Result:</b> Retour NOK/CAT-1/LECTURE_INDISPONIBLE
   *
   * @throws IllegalAccessException
   *           On error
   * @throws NoSuchFieldException
   *           On error
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PP0306_BL100_TraiterErreurSpirit_TestKO_003() throws Exception
  {
    //Set the _processInstance._processContext._filterConfigFile to "src/test/resources/PP0306_ErreurSpirit_filters_test.txt"
    Object context = JUnitTools.getInaccessibleFieldValue(_processInstance, "_processContext"); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(context, "_filterConfigFile", "src/test/resources/PP0306_ErreurSpirit_filters_test.txt"); //$NON-NLS-1$ //$NON-NLS-2$
    JUnitTools.setInaccessibleFieldValue(context, "_maxProcessingRatePerSec", 10);
    JUnitTools.setInaccessibleFieldValue(context, "_maxProfondeur", 2880);

    LocalDateTime dateDeb = LocalDateTime.parse("2018-12-10T11:30", PP0306_TraitementErreursSpirit.InputDateTimeformatter); //$NON-NLS-1$
    LocalDateTime dateFin = LocalDateTime.parse("2018-12-10T12:30", PP0306_TraitementErreursSpirit.InputDateTimeformatter); //$NON-NLS-1$

    //mock REX.erreurSpiritLireTousParStatutPeriod to return OK
    ErreurSpirit erreurSpirit = new ErreurSpirit("test", RetourConverter.convertToJsonRetour(RetourFactoryForTU.createNOK("CAT-4", "TRAITEMENT_ARRETE", "blablabla Test1")), ErreurSpiritStatut.OUVERT.name(), dateDeb, dateDeb, _tracabilite); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    Tracabilite tracabilite = new Tracabilite();
    Map<String, String> refFonc = new HashMap<>();
    String noCompte = "nocompte123"; //$NON-NLS-1$
    String clientOperateur = "cliop123"; //$NON-NLS-1$
    refFonc.put(IRefFoncConstants.NO_COMPTE, noCompte);
    refFonc.put(IRefFoncConstants.CLI_OPE, clientOperateur);
    tracabilite.setRefFonc(refFonc);
    erreurSpirit.setTracabilite(tracabilite);
    ConnectorResponse<Retour, List<ErreurSpirit>> expectedResponse = new ConnectorResponse<Retour, List<ErreurSpirit>>(RetourFactoryForTU.createOkRetour(), Arrays.asList(erreurSpirit));
    prepareMockREXerreurSpiritLireTousParStatutPeriod(Tools.formatDateTimeForPAD6003(dateDeb), Tools.formatDateTimeForPAD6003(dateFin), expectedResponse);

    //mock RST.serviceTechniqueLireTousParPfiFiltrerInactif to return NOK/CAT-1/LECTURE_INDISPONIBLE
    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT1, IMegSpiritConsts.LECTURE_INDISPONIBLE, "test technical error", null); //$NON-NLS-1$
    ConnectorResponse<Retour, List<ServiceTechnique>> rstResponse = new ConnectorResponse<>(expectedRetour, null);
    prepareMockRSTserviceTechniqueLireTousParPfiFiltrerInactif(clientOperateur, noCompte, rstResponse);

    PowerMock.replayAll();
    Retour bl100Retour = Whitebox.invokeMethod(_processInstance, PP0306_BL100_TRAITER_ERREUR_SPIRIT, _tracabilite, dateDeb, dateFin, false);
    PowerMock.verifyAll();

    assertEquals(expectedRetour, bl100Retour);
  }

  /**
   * <b>Scenario:</b> PP0306_BL100_TraiterErreurSpirit test KO (REX.erreurSpiritModifierStatut returns
   * NOK/CAT-1/MISE_A_JOUR_INDISPONIBLE).<br>
   * <b>Input: dateDeb, dateFin</b> <br>
   * <b>Result:</b> Retour NOK/CAT-1/MISE_A_JOUR_INDISPONIBLE
   *
   * @throws IllegalAccessException
   *           On error
   * @throws NoSuchFieldException
   *           On error
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PP0306_BL100_TraiterErreurSpirit_TestKO_004() throws Exception
  {
    //Set the _processInstance._processContext._filterConfigFile to "src/test/resources/PP0306_ErreurSpirit_filters_test.txt"
    Object context = JUnitTools.getInaccessibleFieldValue(_processInstance, "_processContext"); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(context, "_filterConfigFile", "src/test/resources/PP0306_ErreurSpirit_filters_test.txt"); //$NON-NLS-1$ //$NON-NLS-2$
    JUnitTools.setInaccessibleFieldValue(context, "_xRequestId", X_REQUEST_ID_TEST); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(context, "_maxProcessingRatePerSec", 10);
    JUnitTools.setInaccessibleFieldValue(context, "_maxProfondeur", 2880);

    LocalDateTime dateDeb = LocalDateTime.parse("2018-12-10T11:30", PP0306_TraitementErreursSpirit.InputDateTimeformatter); //$NON-NLS-1$
    LocalDateTime dateFin = LocalDateTime.parse("2018-12-10T12:30", PP0306_TraitementErreursSpirit.InputDateTimeformatter); //$NON-NLS-1$

    //mock REX.erreurSpiritLireTousParStatutPeriod
    String idErreurSpirit = "test"; //$NON-NLS-1$

    ErreurSpirit erreurSpirit = new ErreurSpirit(idErreurSpirit, RetourConverter.convertToJsonRetour(RetourFactoryForTU.createNOK("CAT-4", "TRAITEMENT_ARRETE", "blablabla Test1")), ErreurSpiritStatut.OUVERT.name(), dateDeb, dateDeb, _tracabilite); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    Tracabilite tracabilite = new Tracabilite();
    Map<String, String> refFonc = new HashMap<>();
    String noCompte = "nocompte123"; //$NON-NLS-1$
    String clientOperateur = "cliop123"; //$NON-NLS-1$
    refFonc.put(IRefFoncConstants.NO_COMPTE, noCompte);
    refFonc.put(IRefFoncConstants.CLI_OPE, clientOperateur);
    tracabilite.setRefFonc(refFonc);
    erreurSpirit.setTracabilite(tracabilite);
    ConnectorResponse<Retour, List<ErreurSpirit>> expectedResponse = new ConnectorResponse<Retour, List<ErreurSpirit>>(RetourFactoryForTU.createOkRetour(), Arrays.asList(erreurSpirit));
    prepareMockREXerreurSpiritLireTousParStatutPeriod(Tools.formatDateTimeForPAD6003(dateDeb), Tools.formatDateTimeForPAD6003(dateFin), expectedResponse);

    addToRefFoncMap(_tracabilite, IRefFoncConstants.ID_ERREUR_SPIRIT, idErreurSpirit);

    //mock RST.serviceTechniqueLireTousParPfiFiltrerInactif to return empty list
    Retour retourNOK1 = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "test aucun service trouve", null); //$NON-NLS-1$
    ConnectorResponse<Retour, List<ServiceTechnique>> rstResponse = new ConnectorResponse<>(retourNOK1, null);
    prepareMockRSTserviceTechniqueLireTousParPfiFiltrerInactif(clientOperateur, noCompte, rstResponse);

    //mock BL5100_CreerActionCorrective to return OK
    String idExterne = X_REQUEST_ID_TEST + "-" + idErreurSpirit; //$NON-NLS-1$
    Retour retourOK = RetourFactoryForTU.createOkRetour();
    String expectedIdActionCorrective = "idActionCorrectiveTest"; //$NON-NLS-1$
    prepareBL5100Mock(clientOperateur, noCompte, new ArrayList<>(), retourOK, expectedIdActionCorrective, idExterne);

    //mock BL5110 to return OK
    prepareBL5110Mock(idExterne, expectedIdActionCorrective, retourOK);

    //mock REX.erreurSpiritModifierStatut to return NOK/CAT-1/MISE_A_JOUR_INDISPONIBLE
    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT1, IMegSpiritConsts.MISE_A_JOUR_INDISPONIBLE, "test technical error", null); //$NON-NLS-1$
    ConnectorResponse<Retour, Nothing> pad6003Response = new ConnectorResponse<Retour, Nothing>(expectedRetour, null);
    prepareMockREXerreurSpiritModifierStatut(erreurSpirit.getIdErreurSpirit(), ErreurSpiritStatut.CLOS.name(), pad6003Response);

    //test
    PowerMock.replayAll();
    Retour bl100Retour = Whitebox.invokeMethod(_processInstance, PP0306_BL100_TRAITER_ERREUR_SPIRIT, _tracabilite, dateDeb, dateFin, false);
    PowerMock.verifyAll();

    assertEquals(expectedRetour, bl100Retour);
  }

  /**
   * <b>Scenario:</b> PP0306_BL100_TraiterErreurSpirit test KO (TypeDecision=RELANCER_COMMANDE & idCommande <> null,
   * PE0028_RelancerCommande returns OK, REXProxy.getInstance().erreurSpiritModifierStatut returns KO).<br>
   *
   * <b>Input: valid inputs</b> <br>
   * <b>Result:</b> Retour KO
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PP0306_BL100_TraiterErreurSpirit_TestKO_005() throws Exception
  {
    //Set the _processInstance._processContext._filterConfigFile to "src/test/resources/PP0306_ErreurSpirit_filters_test.txt"
    Object context = JUnitTools.getInaccessibleFieldValue(_processInstance, "_processContext"); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(context, "_filterConfigFile", "src/test/resources/PP0306_ErreurSpirit_filters_test2.txt"); //$NON-NLS-1$ //$NON-NLS-2$
    JUnitTools.setInaccessibleFieldValue(context, "_maxProcessingRatePerSec", 10);
    JUnitTools.setInaccessibleFieldValue(context, "_maxProfondeur", 2880);

    LocalDateTime dateDeb = LocalDateTime.parse("2018-12-10T11:30", PP0306_TraitementErreursSpirit.InputDateTimeformatter); //$NON-NLS-1$
    LocalDateTime dateFin = LocalDateTime.parse("2018-12-10T12:30", PP0306_TraitementErreursSpirit.InputDateTimeformatter); //$NON-NLS-1$

    //mock REX.erreurSpiritLireTousParStatutPeriod to return OK
    ErreurSpirit erreurSpirit = new ErreurSpirit("test", RetourConverter.convertToJsonRetour(RetourFactoryForTU.createNOK("CAT-4", "TRAITEMENT_ARRETE", "blablabla Test1")), ErreurSpiritStatut.OUVERT.name(), dateDeb, dateDeb, _tracabilite); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    Tracabilite tracabilite = new Tracabilite();
    Map<String, String> refFonc = new HashMap<>();
    String noCompte = "nocompte123"; //$NON-NLS-1$
    String clientOperateur = "cliop123"; //$NON-NLS-1$
    String idCommande = "idCmd"; //$NON-NLS-1$
    refFonc.put(IRefFoncConstants.NO_COMPTE, noCompte);
    refFonc.put(IRefFoncConstants.CLI_OPE, clientOperateur);
    refFonc.put(IRefFoncConstants.ID_CMD, idCommande);

    tracabilite.setRefFonc(refFonc);
    erreurSpirit.setTracabilite(tracabilite);

    Retour retourKo = RetourFactory.createNOK("CAT-4", "TRAITEMENT_ARRETE", "libelleTest"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    ConnectorResponse<Retour, Nothing> erreurSpiritModifierStatutResp = new ConnectorResponse<Retour, Nothing>(retourKo, null);

    ConnectorResponse<Retour, List<ErreurSpirit>> expectedResponse = new ConnectorResponse<Retour, List<ErreurSpirit>>(RetourFactoryForTU.createOkRetour(), Arrays.asList(erreurSpirit));
    prepareMockREXerreurSpiritLireTousParStatutPeriod(Tools.formatDateTimeForPAD6003(dateDeb), Tools.formatDateTimeForPAD6003(dateFin), expectedResponse);
    prepareMockPe0028();

    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxy);
    EasyMock.expect(_rexProxy.erreurSpiritModifierStatut(EasyMock.anyObject(), EasyMock.eq(new UpdateErreurSpiritRequest(erreurSpirit.getIdErreurSpirit(), ErreurSpiritStatut.CLOS.name())))).andReturn(erreurSpiritModifierStatutResp);

    PowerMock.replayAll();
    Retour bl100Retour = Whitebox.invokeMethod(_processInstance, PP0306_BL100_TRAITER_ERREUR_SPIRIT, _tracabilite, dateDeb, dateFin, false);
    PowerMock.verifyAll();

    assertEquals(retourKo, bl100Retour);
  }

  /**
   * <b>Scenario:</b> PP0306_BL100_TraiterErreurSpirit test OK.<br>
   * <b>Input: dateDeb, dateFin</b> <br>
   * <b>Result:</b> Retour OK
   *
   * @throws IllegalAccessException
   *           On error
   * @throws NoSuchFieldException
   *           On error
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PP0306_BL100_TraiterErreurSpirit_TestOK() throws Exception
  {
    //Set the _processInstance._processContext._filterConfigFile to "src/test/resources/PP0306_ErreurSpirit_filters_test.txt"
    Object context = JUnitTools.getInaccessibleFieldValue(_processInstance, "_processContext"); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(context, "_filterConfigFile", "src/test/resources/PP0306_ErreurSpirit_filters_test.txt"); //$NON-NLS-1$ //$NON-NLS-2$
    JUnitTools.setInaccessibleFieldValue(context, "_xRequestId", X_REQUEST_ID_TEST); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(context, "_maxProcessingRatePerSec", 10);
    JUnitTools.setInaccessibleFieldValue(context, "_maxProfondeur", 2880);

    LocalDateTime dateDeb = LocalDateTime.parse("2018-12-10T11:30", PP0306_TraitementErreursSpirit.InputDateTimeformatter); //$NON-NLS-1$
    LocalDateTime dateFin = LocalDateTime.parse("2018-12-10T12:30", PP0306_TraitementErreursSpirit.InputDateTimeformatter); //$NON-NLS-1$

    //mock REX.erreurSpiritLireTousParStatutPeriod
    String idErreurSpirit = "test"; //$NON-NLS-1$
    ErreurSpirit erreurSpirit = new ErreurSpirit(idErreurSpirit, RetourConverter.convertToJsonRetour(RetourFactoryForTU.createNOK("CAT-4", "TRAITEMENT_ARRETE", "blablabla Test1")), ErreurSpiritStatut.OUVERT.name(), dateDeb, dateDeb, _tracabilite); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    Tracabilite tracabilite = new Tracabilite();
    Map<String, String> refFonc = new HashMap<>();
    String noCompte = "nocompte123"; //$NON-NLS-1$
    String clientOperateur = "cliop123"; //$NON-NLS-1$
    refFonc.put(IRefFoncConstants.NO_COMPTE, noCompte);
    refFonc.put(IRefFoncConstants.CLI_OPE, clientOperateur);
    tracabilite.setRefFonc(refFonc);
    erreurSpirit.setTracabilite(tracabilite);
    ConnectorResponse<Retour, List<ErreurSpirit>> expectedResponse = new ConnectorResponse<Retour, List<ErreurSpirit>>(RetourFactoryForTU.createOkRetour(), Arrays.asList(erreurSpirit));
    prepareMockREXerreurSpiritLireTousParStatutPeriod(Tools.formatDateTimeForPAD6003(dateDeb), Tools.formatDateTimeForPAD6003(dateFin), expectedResponse);

    addToRefFoncMap(_tracabilite, IRefFoncConstants.ID_ERREUR_SPIRIT, idErreurSpirit);

    //mock RST.serviceTechniqueLireTousParPfiFiltrerInactif to return empty list
    Retour retourNOK1 = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "test aucun service trouve", null); //$NON-NLS-1$
    ConnectorResponse<Retour, List<ServiceTechnique>> rstResponse = new ConnectorResponse<>(retourNOK1, null);
    prepareMockRSTserviceTechniqueLireTousParPfiFiltrerInactif(clientOperateur, noCompte, rstResponse);

    //mock BL5100_CreerActionCorrective to return OK
    String idExterne = X_REQUEST_ID_TEST + "-" + idErreurSpirit; //$NON-NLS-1$
    Retour retourOK = RetourFactoryForTU.createOkRetour();
    String expectedIdActionCorrective = "idActionCorrectiveTest"; //$NON-NLS-1$
    prepareBL5100Mock(clientOperateur, noCompte, new ArrayList<>(), retourOK, expectedIdActionCorrective, idExterne);

    //mock BL5110 to return OK
    prepareBL5110Mock(idExterne, expectedIdActionCorrective, retourOK);

    //mock REX.erreurSpiritModifierStatut to return OK
    ConnectorResponse<Retour, Nothing> pad6003Response = new ConnectorResponse<Retour, Nothing>(retourOK, null);
    prepareMockREXerreurSpiritModifierStatut(erreurSpirit.getIdErreurSpirit(), ErreurSpiritStatut.CLOS.name(), pad6003Response);

    //test
    PowerMock.replayAll();
    Retour bl100Retour = Whitebox.invokeMethod(_processInstance, PP0306_BL100_TRAITER_ERREUR_SPIRIT, _tracabilite, dateDeb, dateFin, false);
    PowerMock.verifyAll();

    assertEquals(retourOK, bl100Retour);
  }

  /**
   * <b>Scenario:</b> PP0306_BL100_TraiterErreurSpirit OK (erreurSpirit.Tracabilite.RefFonc null).<br>
   * <b>Input: dateDeb, dateFin</b> <br>
   * <b>Result:</b> Retour OK
   *
   * @throws IllegalAccessException
   *           On error
   * @throws NoSuchFieldException
   *           On error
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PP0306_BL100_TraiterErreurSpirit_TestOK_002() throws Exception
  {
    //Set the _processInstance._processContext._filterConfigFile to "src/test/resources/PP0306_ErreurSpirit_filters_test.txt"
    Object context = JUnitTools.getInaccessibleFieldValue(_processInstance, "_processContext"); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(context, "_filterConfigFile", "src/test/resources/PP0306_ErreurSpirit_filters_test.txt"); //$NON-NLS-1$ //$NON-NLS-2$
    JUnitTools.setInaccessibleFieldValue(context, "_maxProcessingRatePerSec", 10);
    JUnitTools.setInaccessibleFieldValue(context, "_maxProfondeur", 2880);

    LocalDateTime dateDeb = LocalDateTime.parse("2018-12-10T11:30", PP0306_TraitementErreursSpirit.InputDateTimeformatter); //$NON-NLS-1$
    LocalDateTime dateFin = LocalDateTime.parse("2018-12-10T12:30", PP0306_TraitementErreursSpirit.InputDateTimeformatter); //$NON-NLS-1$

    //mock REX.erreurSpiritLireTousParStatutPeriod
    ErreurSpirit erreurSpirit = new ErreurSpirit("test", RetourConverter.convertToJsonRetour(RetourFactoryForTU.createNOK("CAT-4", "TRAITEMENT_ARRETE", "blablabla Test1")), ErreurSpiritStatut.OUVERT.name(), dateDeb, dateDeb, _tracabilite); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    Tracabilite tracabilite = new Tracabilite();
    erreurSpirit.setTracabilite(tracabilite);
    ConnectorResponse<Retour, List<ErreurSpirit>> expectedResponse = new ConnectorResponse<Retour, List<ErreurSpirit>>(RetourFactoryForTU.createOkRetour(), Arrays.asList(erreurSpirit));
    prepareMockREXerreurSpiritLireTousParStatutPeriod(Tools.formatDateTimeForPAD6003(dateDeb), Tools.formatDateTimeForPAD6003(dateFin), expectedResponse);

    PowerMock.replayAll();
    Retour bl100Retour = Whitebox.invokeMethod(_processInstance, PP0306_BL100_TRAITER_ERREUR_SPIRIT, _tracabilite, dateDeb, dateFin, false);
    PowerMock.verifyAll();

    assertEquals(RetourFactoryForTU.createOkRetour(), bl100Retour);
  }

  /**
   * <b>Scenario:</b> PP0306_BL100_TraiterErreurSpirit test KO (TypeDecision=RELANCER_COMMANDE & idCommande null).<br>
   *
   * <b>Input: valid inputs</b> <br>
   * <b>Result:</b> Retour OK
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PP0306_BL100_TraiterErreurSpirit_TestOK_003() throws Exception
  {
    //Set the _processInstance._processContext._filterConfigFile to "src/test/resources/PP0306_ErreurSpirit_filters_test.txt"
    Object context = JUnitTools.getInaccessibleFieldValue(_processInstance, "_processContext"); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(context, "_filterConfigFile", "src/test/resources/PP0306_ErreurSpirit_filters_test2.txt"); //$NON-NLS-1$ //$NON-NLS-2$
    JUnitTools.setInaccessibleFieldValue(context, "_maxProcessingRatePerSec", 10);
    JUnitTools.setInaccessibleFieldValue(context, "_maxProfondeur", 2880);

    LocalDateTime dateDeb = LocalDateTime.parse("2018-12-10T11:30", PP0306_TraitementErreursSpirit.InputDateTimeformatter); //$NON-NLS-1$
    LocalDateTime dateFin = LocalDateTime.parse("2018-12-10T12:30", PP0306_TraitementErreursSpirit.InputDateTimeformatter); //$NON-NLS-1$

    //mock REX.erreurSpiritLireTousParStatutPeriod to return OK
    ErreurSpirit erreurSpirit = new ErreurSpirit("test", RetourConverter.convertToJsonRetour(RetourFactoryForTU.createNOK("CAT-4", "TRAITEMENT_ARRETE", "blablabla Test1")), ErreurSpiritStatut.OUVERT.name(), dateDeb, dateDeb, _tracabilite); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    Tracabilite tracabilite = new Tracabilite();
    Map<String, String> refFonc = new HashMap<>();
    String noCompte = "nocompte123"; //$NON-NLS-1$
    String clientOperateur = "cliop123"; //$NON-NLS-1$
    refFonc.put(IRefFoncConstants.NO_COMPTE, noCompte);
    refFonc.put(IRefFoncConstants.CLI_OPE, clientOperateur);
    tracabilite.setRefFonc(refFonc);
    erreurSpirit.setTracabilite(tracabilite);

    ConnectorResponse<Retour, List<ErreurSpirit>> expectedResponse = new ConnectorResponse<Retour, List<ErreurSpirit>>(RetourFactoryForTU.createOkRetour(), Arrays.asList(erreurSpirit));
    prepareMockREXerreurSpiritLireTousParStatutPeriod(Tools.formatDateTimeForPAD6003(dateDeb), Tools.formatDateTimeForPAD6003(dateFin), expectedResponse);

    Retour expectedRetour = RetourFactory.createOkRetour();

    PowerMock.replayAll();
    Retour bl100Retour = Whitebox.invokeMethod(_processInstance, PP0306_BL100_TRAITER_ERREUR_SPIRIT, _tracabilite, dateDeb, dateFin, false);
    PowerMock.verifyAll();

    assertEquals(expectedRetour, bl100Retour);
  }

  /**
   * <b>Scenario:</b> PP0306_BL100_TraiterErreurSpirit test KO (TypeDecision=RELANCER_COMMANDE & idCommande <> null,
   * PE0028_RelancerCommande returns OK, REXProxy.getInstance().erreurSpiritModifierStatut returns OK).<br>
   *
   * <b>Input: valid inputs</b> <br>
   * <b>Result:</b> Retour OK
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PP0306_BL100_TraiterErreurSpirit_TestOK_004() throws Exception
  {
    //Set the _processInstance._processContext._filterConfigFile to "src/test/resources/PP0306_ErreurSpirit_filters_test.txt"
    Object context = JUnitTools.getInaccessibleFieldValue(_processInstance, "_processContext"); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(context, "_filterConfigFile", "src/test/resources/PP0306_ErreurSpirit_filters_test2.txt"); //$NON-NLS-1$ //$NON-NLS-2$
    JUnitTools.setInaccessibleFieldValue(context, "_maxProcessingRatePerSec", 10);
    JUnitTools.setInaccessibleFieldValue(context, "_maxProfondeur", 2880);

    LocalDateTime dateDeb = LocalDateTime.parse("2018-12-10T11:30", PP0306_TraitementErreursSpirit.InputDateTimeformatter); //$NON-NLS-1$
    LocalDateTime dateFin = LocalDateTime.parse("2018-12-10T12:30", PP0306_TraitementErreursSpirit.InputDateTimeformatter); //$NON-NLS-1$

    //mock REX.erreurSpiritLireTousParStatutPeriod to return OK
    ErreurSpirit erreurSpirit = new ErreurSpirit("test", RetourConverter.convertToJsonRetour(RetourFactoryForTU.createNOK("CAT-4", "TRAITEMENT_ARRETE", "blablabla Test1")), ErreurSpiritStatut.OUVERT.name(), dateDeb, dateDeb, _tracabilite); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    Tracabilite tracabilite = new Tracabilite();
    Map<String, String> refFonc = new HashMap<>();
    String noCompte = "nocompte123"; //$NON-NLS-1$
    String clientOperateur = "cliop123"; //$NON-NLS-1$
    String idCommande = "idCmd"; //$NON-NLS-1$
    refFonc.put(IRefFoncConstants.NO_COMPTE, noCompte);
    refFonc.put(IRefFoncConstants.CLI_OPE, clientOperateur);
    refFonc.put(IRefFoncConstants.ID_CMD, idCommande);

    tracabilite.setRefFonc(refFonc);
    erreurSpirit.setTracabilite(tracabilite);

    Retour expectedRetour = RetourFactory.createOkRetour();
    ConnectorResponse<Retour, Nothing> erreurSpiritModifierStatutResp = new ConnectorResponse<Retour, Nothing>(expectedRetour, null);

    ConnectorResponse<Retour, List<ErreurSpirit>> expectedResponse = new ConnectorResponse<Retour, List<ErreurSpirit>>(RetourFactoryForTU.createOkRetour(), Arrays.asList(erreurSpirit));
    prepareMockREXerreurSpiritLireTousParStatutPeriod(Tools.formatDateTimeForPAD6003(dateDeb), Tools.formatDateTimeForPAD6003(dateFin), expectedResponse);
    prepareMockPe0028();

    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxy);
    EasyMock.expect(_rexProxy.erreurSpiritModifierStatut(EasyMock.anyObject(), EasyMock.eq(new UpdateErreurSpiritRequest(erreurSpirit.getIdErreurSpirit(), ErreurSpiritStatut.CLOS.name())))).andReturn(erreurSpiritModifierStatutResp);

    PowerMock.replayAll();
    Retour bl100Retour = Whitebox.invokeMethod(_processInstance, PP0306_BL100_TRAITER_ERREUR_SPIRIT, _tracabilite, dateDeb, dateFin, false);
    PowerMock.verifyAll();

    assertEquals(expectedRetour, bl100Retour);
  }

  /**
   * <b>Scenario:</b> PP0306_BL100_TraiterErreurSpirit test KO (TypeDecision=MODIFIER_STATUT_COMMANDE, statut null).<br>
   *
   * <b>Input: valid inputs</b> <br>
   * <b>Result:</b> Retour OK
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PP0306_BL100_TraiterErreurSpirit_TestOK_005() throws Exception
  {
    //Set the _processInstance._processContext._filterConfigFile to "src/test/resources/PP0306_ErreurSpirit_filters_test.txt"
    Object context = JUnitTools.getInaccessibleFieldValue(_processInstance, "_processContext"); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(context, "_filterConfigFile", "src/test/resources/PP0306_ErreurSpirit_filters_test3.txt"); //$NON-NLS-1$ //$NON-NLS-2$
    JUnitTools.setInaccessibleFieldValue(context, "_maxProcessingRatePerSec", 10);
    JUnitTools.setInaccessibleFieldValue(context, "_maxProfondeur", 2880);

    LocalDateTime dateDeb = LocalDateTime.parse("2018-12-10T11:30", PP0306_TraitementErreursSpirit.InputDateTimeformatter); //$NON-NLS-1$
    LocalDateTime dateFin = LocalDateTime.parse("2018-12-10T12:30", PP0306_TraitementErreursSpirit.InputDateTimeformatter); //$NON-NLS-1$

    //mock REX.erreurSpiritLireTousParStatutPeriod to return OK
    ErreurSpirit erreurSpirit = new ErreurSpirit("test", RetourConverter.convertToJsonRetour(RetourFactoryForTU.createNOK("CAT-4", "TRAITEMENT_ARRETE", "blablabla Test1")), ErreurSpiritStatut.OUVERT.name(), dateDeb, dateDeb, _tracabilite); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    Tracabilite tracabilite = new Tracabilite();
    Map<String, String> refFonc = new HashMap<>();
    String noCompte = "nocompte123"; //$NON-NLS-1$
    String clientOperateur = "cliop123"; //$NON-NLS-1$
    String idCommande = "idCmd"; //$NON-NLS-1$
    refFonc.put(IRefFoncConstants.NO_COMPTE, noCompte);
    refFonc.put(IRefFoncConstants.CLI_OPE, clientOperateur);
    refFonc.put(IRefFoncConstants.ID_CMD, idCommande);

    tracabilite.setRefFonc(refFonc);
    erreurSpirit.setTracabilite(tracabilite);

    Retour expectedRetour = RetourFactory.createOkRetour();

    ConnectorResponse<Retour, List<ErreurSpirit>> expectedResponse = new ConnectorResponse<Retour, List<ErreurSpirit>>(RetourFactoryForTU.createOkRetour(), Arrays.asList(erreurSpirit));
    prepareMockREXerreurSpiritLireTousParStatutPeriod(Tools.formatDateTimeForPAD6003(dateDeb), Tools.formatDateTimeForPAD6003(dateFin), expectedResponse);

    PowerMock.replayAll();
    Retour bl100Retour = Whitebox.invokeMethod(_processInstance, PP0306_BL100_TRAITER_ERREUR_SPIRIT, _tracabilite, dateDeb, dateFin, false);
    PowerMock.verifyAll();

    assertEquals(expectedRetour, bl100Retour);
  }

  /**
   * <b>Scenario:</b> PP0306_BL100_TraiterErreurSpirit test KO (TypeDecision=MODIFIER_STATUT_COMMANDE, statut not in
   * (REJETE, TRAITE_NOK, OBSOLETE, INVALIDE, ECHEC) ).<br>
   * <b>Input: valid inputs</b> <br>
   * <b>Result:</b> Retour OK
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PP0306_BL100_TraiterErreurSpirit_TestOK_006() throws Exception
  {
    //Set the _processInstance._processContext._filterConfigFile to "src/test/resources/PP0306_ErreurSpirit_filters_test.txt"
    Object context = JUnitTools.getInaccessibleFieldValue(_processInstance, "_processContext"); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(context, "_filterConfigFile", "src/test/resources/PP0306_ErreurSpirit_filters_test3.txt"); //$NON-NLS-1$ //$NON-NLS-2$
    JUnitTools.setInaccessibleFieldValue(context, "_maxProcessingRatePerSec", 10);
    JUnitTools.setInaccessibleFieldValue(context, "_maxProfondeur", 2880);

    LocalDateTime dateDeb = LocalDateTime.parse("2018-12-10T11:30", PP0306_TraitementErreursSpirit.InputDateTimeformatter); //$NON-NLS-1$
    LocalDateTime dateFin = LocalDateTime.parse("2018-12-10T12:30", PP0306_TraitementErreursSpirit.InputDateTimeformatter); //$NON-NLS-1$

    //mock REX.erreurSpiritLireTousParStatutPeriod to return OK
    ErreurSpirit erreurSpirit = new ErreurSpirit("test", RetourConverter.convertToJsonRetour(RetourFactoryForTU.createNOK("CAT-4", "TRAITEMENT_ARRETE", "blablabla Test1")), ErreurSpiritStatut.OUVERT.name(), dateDeb, dateDeb, _tracabilite); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    Tracabilite tracabilite = new Tracabilite();
    Map<String, String> refFonc = new HashMap<>();
    String noCompte = "nocompte123"; //$NON-NLS-1$
    String clientOperateur = "cliop123"; //$NON-NLS-1$
    String idCommande = "idCmd"; //$NON-NLS-1$
    String statut = "statut"; //$NON-NLS-1$
    refFonc.put(IRefFoncConstants.NO_COMPTE, noCompte);
    refFonc.put(IRefFoncConstants.CLI_OPE, clientOperateur);
    refFonc.put(IRefFoncConstants.ID_CMD, idCommande);
    refFonc.put(IRefFoncConstants.STATUT, statut);

    tracabilite.setRefFonc(refFonc);
    erreurSpirit.setTracabilite(tracabilite);

    Retour expectedRetour = RetourFactory.createOkRetour();
    ConnectorResponse<Retour, Nothing> erreurSpiritModifierStatutResp = new ConnectorResponse<Retour, Nothing>(expectedRetour, null);

    ConnectorResponse<Retour, List<ErreurSpirit>> expectedResponse = new ConnectorResponse<Retour, List<ErreurSpirit>>(RetourFactoryForTU.createOkRetour(), Arrays.asList(erreurSpirit));
    prepareMockREXerreurSpiritLireTousParStatutPeriod(Tools.formatDateTimeForPAD6003(dateDeb), Tools.formatDateTimeForPAD6003(dateFin), expectedResponse);

    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxy);
    EasyMock.expect(_rexProxy.erreurSpiritModifierStatut(EasyMock.anyObject(), EasyMock.eq(new UpdateErreurSpiritRequest(erreurSpirit.getIdErreurSpirit(), ErreurSpiritStatut.CLOS.name())))).andReturn(erreurSpiritModifierStatutResp);

    EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdProxy);
    EasyMock.expect(_cmdProxy.commandeModifierStatut(EasyMock.anyObject(), EasyMock.eq(idCommande), EasyMock.eq(statut), EasyMock.isNull(), EasyMock.isNull())).andReturn(erreurSpiritModifierStatutResp);

    PowerMock.replayAll();
    Retour bl100Retour = Whitebox.invokeMethod(_processInstance, PP0306_BL100_TRAITER_ERREUR_SPIRIT, _tracabilite, dateDeb, dateFin, false);
    PowerMock.verifyAll();

    assertEquals(expectedRetour, bl100Retour);
  }

  /**
   * <b>Scenario:</b> PP0306_BL100_TraiterErreurSpirit test KO (TypeDecision=MODIFIER_STATUT_COMMANDE, statut = REJETE,
   * codeErreur null, libelleErreur null).<br>
   *
   * <b>Input: valid inputs</b> <br>
   * <b>Result:</b> Retour OK
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PP0306_BL100_TraiterErreurSpirit_TestOK_007() throws Exception
  {
    //Set the _processInstance._processContext._filterConfigFile to "src/test/resources/PP0306_ErreurSpirit_filters_test.txt"
    Object context = JUnitTools.getInaccessibleFieldValue(_processInstance, "_processContext"); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(context, "_filterConfigFile", "src/test/resources/PP0306_ErreurSpirit_filters_test3.txt"); //$NON-NLS-1$ //$NON-NLS-2$
    JUnitTools.setInaccessibleFieldValue(context, "_maxProcessingRatePerSec", 10);
    JUnitTools.setInaccessibleFieldValue(context, "_maxProfondeur", 2880);

    LocalDateTime dateDeb = LocalDateTime.parse("2018-12-10T11:30", PP0306_TraitementErreursSpirit.InputDateTimeformatter); //$NON-NLS-1$
    LocalDateTime dateFin = LocalDateTime.parse("2018-12-10T12:30", PP0306_TraitementErreursSpirit.InputDateTimeformatter); //$NON-NLS-1$

    //mock REX.erreurSpiritLireTousParStatutPeriod to return OK
    ErreurSpirit erreurSpirit = new ErreurSpirit("test", RetourConverter.convertToJsonRetour(RetourFactoryForTU.createNOK("CAT-4", "TRAITEMENT_ARRETE", "blablabla Test1")), ErreurSpiritStatut.OUVERT.name(), dateDeb, dateDeb, _tracabilite); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    Tracabilite tracabilite = new Tracabilite();
    Map<String, String> refFonc = new HashMap<>();
    String noCompte = "nocompte123"; //$NON-NLS-1$
    String clientOperateur = "cliop123"; //$NON-NLS-1$
    String idCommande = "idCmd"; //$NON-NLS-1$
    String statut = Statut.REJETE.name();
    refFonc.put(IRefFoncConstants.NO_COMPTE, noCompte);
    refFonc.put(IRefFoncConstants.CLI_OPE, clientOperateur);
    refFonc.put(IRefFoncConstants.ID_CMD, idCommande);
    refFonc.put(IRefFoncConstants.STATUT, statut);

    tracabilite.setRefFonc(refFonc);
    erreurSpirit.setTracabilite(tracabilite);

    Retour expectedRetour = RetourFactory.createOkRetour();

    ConnectorResponse<Retour, List<ErreurSpirit>> expectedResponse = new ConnectorResponse<Retour, List<ErreurSpirit>>(RetourFactoryForTU.createOkRetour(), Arrays.asList(erreurSpirit));
    prepareMockREXerreurSpiritLireTousParStatutPeriod(Tools.formatDateTimeForPAD6003(dateDeb), Tools.formatDateTimeForPAD6003(dateFin), expectedResponse);

    PowerMock.replayAll();
    Retour bl100Retour = Whitebox.invokeMethod(_processInstance, PP0306_BL100_TRAITER_ERREUR_SPIRIT, _tracabilite, dateDeb, dateFin, false);
    PowerMock.verifyAll();

    assertEquals(expectedRetour, bl100Retour);
  }

  /**
   * <b>Scenario:</b> PP0306_BL100_TraiterErreurSpirit test KO (TypeDecision=MODIFIER_STATUT_COMMANDE, statut = REJETE,
   * codeErreur not null, libelleErreur not null, commandeModifierStatut returns OK).<br>
   *
   * <b>Input: valid inputs</b> <br>
   * <b>Result:</b> Retour OK
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PP0306_BL100_TraiterErreurSpirit_TestOK_008() throws Exception
  {
    //Set the _processInstance._processContext._filterConfigFile to "src/test/resources/PP0306_ErreurSpirit_filters_test.txt"
    Object context = JUnitTools.getInaccessibleFieldValue(_processInstance, "_processContext"); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(context, "_filterConfigFile", "src/test/resources/PP0306_ErreurSpirit_filters_test3.txt"); //$NON-NLS-1$ //$NON-NLS-2$
    JUnitTools.setInaccessibleFieldValue(context, "_maxProcessingRatePerSec", 10);
    JUnitTools.setInaccessibleFieldValue(context, "_maxProfondeur", 2880);

    LocalDateTime dateDeb = LocalDateTime.parse("2018-12-10T11:30", PP0306_TraitementErreursSpirit.InputDateTimeformatter); //$NON-NLS-1$
    LocalDateTime dateFin = LocalDateTime.parse("2018-12-10T12:30", PP0306_TraitementErreursSpirit.InputDateTimeformatter); //$NON-NLS-1$

    //mock REX.erreurSpiritLireTousParStatutPeriod to return OK
    ErreurSpirit erreurSpirit = new ErreurSpirit("test", RetourConverter.convertToJsonRetour(RetourFactoryForTU.createNOK("CAT-4", "TRAITEMENT_ARRETE", "blablabla Test1")), ErreurSpiritStatut.OUVERT.name(), dateDeb, dateDeb, _tracabilite); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    Tracabilite tracabilite = new Tracabilite();
    Map<String, String> refFonc = new HashMap<>();
    String noCompte = "nocompte123"; //$NON-NLS-1$
    String clientOperateur = "cliop123"; //$NON-NLS-1$
    String idCommande = "idCmd"; //$NON-NLS-1$
    String statut = Statut.REJETE.name();
    String codeErreur = "404"; //$NON-NLS-1$
    String libelleErreur = "unLibelle"; //$NON-NLS-1$
    refFonc.put(IRefFoncConstants.NO_COMPTE, noCompte);
    refFonc.put(IRefFoncConstants.CLI_OPE, clientOperateur);
    refFonc.put(IRefFoncConstants.ID_CMD, idCommande);
    refFonc.put(IRefFoncConstants.STATUT, statut);
    refFonc.put(IRefFoncConstants.CODE_ERREUR, codeErreur);
    refFonc.put(IRefFoncConstants.LIBELLE_ERREUR, libelleErreur);

    tracabilite.setRefFonc(refFonc);
    erreurSpirit.setTracabilite(tracabilite);

    Retour expectedRetour = RetourFactory.createOkRetour();
    ConnectorResponse<Retour, Nothing> erreurSpiritModifierStatutResp = new ConnectorResponse<Retour, Nothing>(expectedRetour, null);

    ConnectorResponse<Retour, List<ErreurSpirit>> expectedResponse = new ConnectorResponse<Retour, List<ErreurSpirit>>(RetourFactoryForTU.createOkRetour(), Arrays.asList(erreurSpirit));
    prepareMockREXerreurSpiritLireTousParStatutPeriod(Tools.formatDateTimeForPAD6003(dateDeb), Tools.formatDateTimeForPAD6003(dateFin), expectedResponse);

    EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdProxy);
    EasyMock.expect(_cmdProxy.commandeModifierStatut(EasyMock.anyObject(), EasyMock.eq(idCommande), EasyMock.eq(statut), EasyMock.eq(codeErreur), EasyMock.eq(libelleErreur))).andReturn(erreurSpiritModifierStatutResp);

    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxy);
    EasyMock.expect(_rexProxy.erreurSpiritModifierStatut(EasyMock.anyObject(), EasyMock.eq(new UpdateErreurSpiritRequest(erreurSpirit.getIdErreurSpirit(), ErreurSpiritStatut.CLOS.name())))).andReturn(erreurSpiritModifierStatutResp);

    PowerMock.replayAll();
    Retour bl100Retour = Whitebox.invokeMethod(_processInstance, PP0306_BL100_TRAITER_ERREUR_SPIRIT, _tracabilite, dateDeb, dateFin, false);
    PowerMock.verifyAll();

    assertEquals(expectedRetour, bl100Retour);
  }

  /**
   * <b>Scenario:</b> PP0306_BL100_TraiterErreurSpirit test KO (TypeDecision=MODIFIER_STATUT_COMMANDE, statut = REJETE,
   * codeErreur not null, libelleErreur not null, commandeModifierStatut returns KO).<br>
   * <b>Input: valid inputs</b> <br>
   * <b>Result:</b> Retour OK
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PP0306_BL100_TraiterErreurSpirit_TestOK_009() throws Exception
  {
    //Set the _processInstance._processContext._filterConfigFile to "src/test/resources/PP0306_ErreurSpirit_filters_test.txt"
    Object context = JUnitTools.getInaccessibleFieldValue(_processInstance, "_processContext"); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(context, "_filterConfigFile", "src/test/resources/PP0306_ErreurSpirit_filters_test3.txt"); //$NON-NLS-1$ //$NON-NLS-2$
    JUnitTools.setInaccessibleFieldValue(context, "_maxProcessingRatePerSec", 10);
    JUnitTools.setInaccessibleFieldValue(context, "_maxProfondeur", 2880);

    LocalDateTime dateDeb = LocalDateTime.parse("2018-12-10T11:30", PP0306_TraitementErreursSpirit.InputDateTimeformatter); //$NON-NLS-1$
    LocalDateTime dateFin = LocalDateTime.parse("2018-12-10T12:30", PP0306_TraitementErreursSpirit.InputDateTimeformatter); //$NON-NLS-1$

    //mock REX.erreurSpiritLireTousParStatutPeriod to return OK
    ErreurSpirit erreurSpirit = new ErreurSpirit("test", RetourConverter.convertToJsonRetour(RetourFactoryForTU.createNOK("CAT-4", "TRAITEMENT_ARRETE", "blablabla Test1")), ErreurSpiritStatut.OUVERT.name(), dateDeb, dateDeb, _tracabilite); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    Tracabilite tracabilite = new Tracabilite();
    Map<String, String> refFonc = new HashMap<>();
    String noCompte = "nocompte123"; //$NON-NLS-1$
    String clientOperateur = "cliop123"; //$NON-NLS-1$
    String idCommande = "idCmd"; //$NON-NLS-1$
    String statut = Statut.REJETE.name();
    String codeErreur = "404"; //$NON-NLS-1$
    String libelleErreur = "unLibelle"; //$NON-NLS-1$
    refFonc.put(IRefFoncConstants.NO_COMPTE, noCompte);
    refFonc.put(IRefFoncConstants.CLI_OPE, clientOperateur);
    refFonc.put(IRefFoncConstants.ID_CMD, idCommande);
    refFonc.put(IRefFoncConstants.STATUT, statut);
    refFonc.put(IRefFoncConstants.CODE_ERREUR, codeErreur);
    refFonc.put(IRefFoncConstants.LIBELLE_ERREUR, libelleErreur);

    tracabilite.setRefFonc(refFonc);
    erreurSpirit.setTracabilite(tracabilite);

    Retour retourOk = RetourFactory.createOkRetour();
    Retour expectedRetour = RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "TestLibelle"); //$NON-NLS-1$
    ConnectorResponse<Retour, Nothing> erreurSpiritModifierStatutResp = new ConnectorResponse<Retour, Nothing>(expectedRetour, null);

    ConnectorResponse<Retour, List<ErreurSpirit>> expectedResponse = new ConnectorResponse<Retour, List<ErreurSpirit>>(RetourFactoryForTU.createOkRetour(), Arrays.asList(erreurSpirit));
    prepareMockREXerreurSpiritLireTousParStatutPeriod(Tools.formatDateTimeForPAD6003(dateDeb), Tools.formatDateTimeForPAD6003(dateFin), expectedResponse);

    EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdProxy);
    EasyMock.expect(_cmdProxy.commandeModifierStatut(EasyMock.anyObject(), EasyMock.eq(idCommande), EasyMock.eq(statut), EasyMock.eq(codeErreur), EasyMock.eq(libelleErreur))).andReturn(erreurSpiritModifierStatutResp);

    PowerMock.replayAll();
    Retour bl100Retour = Whitebox.invokeMethod(_processInstance, PP0306_BL100_TRAITER_ERREUR_SPIRIT, _tracabilite, dateDeb, dateFin, false);
    PowerMock.verifyAll();

    assertEquals(retourOk, bl100Retour);
  }

  /**
   * <b>Scenario:</b> PP0306_BL100_TraiterErreurSpirit test OK (REX.erreurSpiritLireTousParStatutPeriod returns
   * NOK/CAT-4/DONNEE_INCONNUE).<br>
   * <b>Input: dateDeb, dateFin</b> <br>
   * <b>Result:</b> Retour OK
   *
   * @throws IllegalAccessException
   *           On error
   * @throws NoSuchFieldException
   *           On error
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PP0306_BL100_TraiterErreurSpirit_TestOK_NoDataToProcess() throws Exception
  {
    //Set the _processInstance._processContext._filterConfigFile to "src/test/resources/PP0306_ErreurSpirit_filters_test.txt"
    Object context = JUnitTools.getInaccessibleFieldValue(_processInstance, "_processContext"); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(context, "_filterConfigFile", "src/test/resources/PP0306_ErreurSpirit_filters_test.txt"); //$NON-NLS-1$ //$NON-NLS-2$
    JUnitTools.setInaccessibleFieldValue(context, "_maxProcessingRatePerSec", 10);
    JUnitTools.setInaccessibleFieldValue(context, "_maxProfondeur", 2880);

    LocalDateTime dateDeb = LocalDateTime.parse("2018-12-10T11:30", PP0306_TraitementErreursSpirit.InputDateTimeformatter); //$NON-NLS-1$
    LocalDateTime dateFin = LocalDateTime.parse("2018-12-10T12:30", PP0306_TraitementErreursSpirit.InputDateTimeformatter); //$NON-NLS-1$

    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "Test No Data"); //$NON-NLS-1$
    ConnectorResponse<Retour, List<ErreurSpirit>> expectedResponse = new ConnectorResponse<Retour, List<ErreurSpirit>>(expectedRetour, null);
    prepareMockREXerreurSpiritLireTousParStatutPeriod(Tools.formatDateTimeForPAD6003(dateDeb), Tools.formatDateTimeForPAD6003(dateFin), expectedResponse);

    PowerMock.replayAll();
    Retour bl100Retour = Whitebox.invokeMethod(_processInstance, PP0306_BL100_TRAITER_ERREUR_SPIRIT, _tracabilite, dateDeb, dateFin, false);
    PowerMock.verifyAll();

    assertEquals(RetourFactoryForTU.createOkRetour(), bl100Retour);
  }

  /**
   * <b>Scenario:</b> PP0306_BL101_IdentifierErreurSpiritEligible test suite.<br>
   * <b>Input:</b> ErreurSpirit and a list of filters <br>
   * <b>Result:</b> Retour OK/NOK
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PP0306_BL101_IdentifierErreurSpiritEligible_Tests() throws Exception
  {
    LocalDateTime now = LocalDateTime.now();
    Retour retour = RetourFactoryForTU.createNOK("CAT-4", "PAS_ASSEZ_DE_DONEE", "Test1"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    ErreurSpirit erreurSpirit = new ErreurSpirit("test", RetourConverter.convertToJsonRetour(retour), "statut", now, now, _tracabilite); //$NON-NLS-1$ //$NON-NLS-2$

    //Test 1 NOK/CAT-4/DONNEE_INCONNUE/Traitement ErreurSpirit (idErreurSpirit: {0}): aucune décision automatique n''a été trouvée
    List<Map<String, String>> filtersList = new ArrayList<>();
    Pair<Retour, String> bl101Retour = Whitebox.invokeMethod(_processInstance, PP0306_BL101_IDENTIFIER_ERREUR_SPIRIT_ELIGIBLE, _tracabilite, erreurSpirit, filtersList);
    Retour expectedRetour = RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, MessageFormat.format(Messages.getString("PP0306.AucuneDecisionTrouvee"), erreurSpirit.getIdErreurSpirit())); //$NON-NLS-1$
    assertEquals(expectedRetour, bl101Retour._first);

    //Test 2 NOK/CAT-4/DONNEE_INCONNUE/Traitement ErreurSpirit (idErreurSpirit: {0}): aucune décision automatique n''a été trouvée
    Map<String, String> filter1 = new HashMap<String, String>();
    filter1.put(Tools.FILTRE_CATEGORIE_ATTRIBUTE, "CAT-10"); //$NON-NLS-1$
    filtersList.add(filter1);
    bl101Retour = Whitebox.invokeMethod(_processInstance, PP0306_BL101_IDENTIFIER_ERREUR_SPIRIT_ELIGIBLE, _tracabilite, erreurSpirit, filtersList);
    expectedRetour = RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, MessageFormat.format(Messages.getString("PP0306.AucuneDecisionTrouvee"), erreurSpirit.getIdErreurSpirit())); //$NON-NLS-1$
    assertEquals(expectedRetour, bl101Retour._first);

    //Test OK: matches with filter2 below
    Map<String, String> filter2 = new HashMap<String, String>();
    filter2.put(Tools.FILTRE_CATEGORIE_ATTRIBUTE, "CAT-4"); //$NON-NLS-1$
    filter2.put(Tools.FILTRE_DIAGNOSTIC_ATTRIBUTE, "PAS_ASSEZ_DE_DONEE"); //$NON-NLS-1$
    filter2.put(Tools.FILTRE_LIBELLE_ATTRIBUTE, "Test.*"); //$NON-NLS-1$
    filtersList.add(filter2);
    bl101Retour = Whitebox.invokeMethod(_processInstance, PP0306_BL101_IDENTIFIER_ERREUR_SPIRIT_ELIGIBLE, _tracabilite, erreurSpirit, filtersList);
    expectedRetour = RetourFactory.createOkRetour();
    assertEquals(expectedRetour, bl101Retour._first);
  }

  /**
   * <b>Scenario:</b> PP0306_BL102_AppliquerActionCorrective test KO (technical error when calling
   * RSTProxy.serviceTechniqueLireTousParPfiFiltrerInactif).<br>
   * <b>Input: clienOperateur, noCompte, idErreurSpirit</b> <br>
   * <b>Result:</b> Retour NOK/LECTURE_INDISPONIBLE/test error
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PP0306_BL102_AppliquerActionCorrective_TestKO_001() throws Exception
  {
    String clientOperateur = "cliop1"; //$NON-NLS-1$
    String noCompte = "nomcpt1"; //$NON-NLS-1$
    String idErreurSpirit = "testerr1"; //$NON-NLS-1$

    //test Technical Error when calling RSTProxy.serviceTechniqueLireTousParPfiFiltrerInactif()
    Retour retourNOK = RetourFactoryForTU.createNOK(IMegConsts.CAT1, IMegSpiritConsts.LECTURE_INDISPONIBLE, "test error", null); //$NON-NLS-1$
    ConnectorResponse<Retour, List<ServiceTechnique>> expectedResponse = new ConnectorResponse<>(retourNOK, null);
    prepareMockRSTserviceTechniqueLireTousParPfiFiltrerInactif(clientOperateur, noCompte, expectedResponse);

    PowerMock.replayAll();
    Pair<Retour, String> bl102Retour = Whitebox.invokeMethod(_processInstance, PP0306_BL102_APPLIQUER_ACTION_CORRECTIVE, _tracabilite, clientOperateur, noCompte, idErreurSpirit);
    PowerMock.verifyAll();

    assertEquals(retourNOK, bl102Retour._first);
  }

  /**
   * <b>Scenario:</b> PP0306_BL102_AppliquerActionCorrective test KO (BL5100_CreerActionCorrective returns
   * NOK/CAT-3/ENTREE_INCORRECTE).<br>
   * <b>Input: clienOperateur, noCompte, idErreurSpirit</b> <br>
   * <b>Result:</b> Retour NOK/CAT-3/ENTREE_INCORRECTE
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PP0306_BL102_AppliquerActionCorrective_TestKO_002() throws Exception
  {
    Object context = JUnitTools.getInaccessibleFieldValue(_processInstance, "_processContext"); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(context, "_xRequestId", X_REQUEST_ID_TEST); //$NON-NLS-1$

    String clientOperateur = "cliop1"; //$NON-NLS-1$
    String noCompte = "nomcpt1"; //$NON-NLS-1$
    String idErreurSpirit = "testerr1"; //$NON-NLS-1$
    String idExterne = X_REQUEST_ID_TEST + "-" + idErreurSpirit; //$NON-NLS-1$

    //mock RST.serviceTechniqueLireTousParPfiFiltrerInactif
    Retour retourNOK1 = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "test aucun service trouve", null); //$NON-NLS-1$
    ConnectorResponse<Retour, List<ServiceTechnique>> expectedResponse = new ConnectorResponse<>(retourNOK1, null);
    prepareMockRSTserviceTechniqueLireTousParPfiFiltrerInactif(clientOperateur, noCompte, expectedResponse);

    //mock BL5100_CreerActionCorrective
    Retour retourNOK2 = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ENTREE_INCORRECTE, "test BL5100_CreerActionCorrective error"); //$NON-NLS-1$
    prepareBL5100Mock(clientOperateur, noCompte, new ArrayList<>(), retourNOK2, null, idExterne);

    PowerMock.replayAll();
    Pair<Retour, String> bl102Retour = Whitebox.invokeMethod(_processInstance, PP0306_BL102_APPLIQUER_ACTION_CORRECTIVE, _tracabilite, clientOperateur, noCompte, idErreurSpirit);
    PowerMock.verifyAll();

    assertEquals(retourNOK2, bl102Retour._first);
  }

  /**
   * <b>Scenario:</b> PP0306_BL102_AppliquerActionCorrective test KO (BL5110_executerActionCorrective returns
   * NOK/CAT-4/DONNEE_INCONNUE).<br>
   * <b>Input: clienOperateur, noCompte, idErreurSpirit</b> <br>
   * <b>Result:</b> Retour NOK/CAT-4/DONNEE_INCONNUE
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PP0306_BL102_AppliquerActionCorrective_TestKO_003() throws Exception
  {
    Object context = JUnitTools.getInaccessibleFieldValue(_processInstance, "_processContext"); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(context, "_xRequestId", X_REQUEST_ID_TEST); //$NON-NLS-1$

    String clientOperateur = "cliop1"; //$NON-NLS-1$
    String noCompte = "nomcpt1"; //$NON-NLS-1$
    String idErreurSpirit = "testerr1"; //$NON-NLS-1$
    String idExterne = X_REQUEST_ID_TEST + "-" + idErreurSpirit; //$NON-NLS-1$

    addToRefFoncMap(_tracabilite, IRefFoncConstants.ID_ERREUR_SPIRIT, idErreurSpirit);

    //mock RST.serviceTechniqueLireTousParPfiFiltrerInactif
    Retour retourNOK1 = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "test aucun service trouve", null); //$NON-NLS-1$
    ConnectorResponse<Retour, List<ServiceTechnique>> expectedResponse = new ConnectorResponse<>(retourNOK1, null);
    prepareMockRSTserviceTechniqueLireTousParPfiFiltrerInactif(clientOperateur, noCompte, expectedResponse);

    String idActionCorrective = "idActionCorrectiveTest"; //$NON-NLS-1$
    //mock BL5100_CreerActionCorrective
    Retour retourOK = RetourFactoryForTU.createOkRetour();
    prepareBL5100Mock(clientOperateur, noCompte, new ArrayList<>(), retourOK, idActionCorrective, idExterne);

    //mock BL5110 to return NOK/CAT-4/DONNEE_INCONNUE
    String errMsg = "Test Action corrective not found"; //$NON-NLS-1$
    Retour retourNOK2 = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, errMsg, null);
    prepareBL5110Mock(idExterne, idActionCorrective, retourNOK2);

    PowerMock.replayAll();
    Pair<Retour, String> bl102Retour = Whitebox.invokeMethod(_processInstance, PP0306_BL102_APPLIQUER_ACTION_CORRECTIVE, _tracabilite, clientOperateur, noCompte, idErreurSpirit);
    PowerMock.verifyAll();

    assertEquals(retourNOK2, bl102Retour._first);
  }

  /**
   * <b>Scenario:</b> PP0306_BL102_AppliquerActionCorrective test OK .<br>
   * <b>Input: clienOperateur, noCompte, idErreurSpirit</b> <br>
   * <b>Result:</b> Retour OK
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PP0306_BL102_AppliquerActionCorrective_TestOK() throws Exception
  {
    Object context = JUnitTools.getInaccessibleFieldValue(_processInstance, "_processContext"); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(context, "_xRequestId", X_REQUEST_ID_TEST); //$NON-NLS-1$

    String clientOperateur = "cliop1"; //$NON-NLS-1$
    String noCompte = "nomcpt1"; //$NON-NLS-1$
    String idErreurSpirit = "testerr1"; //$NON-NLS-1$

    addToRefFoncMap(_tracabilite, IRefFoncConstants.ID_ERREUR_SPIRIT, idErreurSpirit);

    //mock RST.serviceTechniqueLireTousParPfiFiltrerInactif to return empty list
    Retour retourNOK1 = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "test aucun service trouve", null); //$NON-NLS-1$
    ConnectorResponse<Retour, List<ServiceTechnique>> expectedResponse = new ConnectorResponse<>(retourNOK1, null);
    prepareMockRSTserviceTechniqueLireTousParPfiFiltrerInactif(clientOperateur, noCompte, expectedResponse);

    String idExterne = X_REQUEST_ID_TEST + "-" + idErreurSpirit; //$NON-NLS-1$
    //mock BL5100_CreerActionCorrective to return OK
    Retour retourOK = RetourFactoryForTU.createOkRetour();
    String expectedIdActionCorrective = "idActionCorrectiveTest"; //$NON-NLS-1$
    prepareBL5100Mock(clientOperateur, noCompte, new ArrayList<>(), retourOK, expectedIdActionCorrective, idExterne);

    //mock BL5110 to return OK
    prepareBL5110Mock(idExterne, expectedIdActionCorrective, retourOK);

    PowerMock.replayAll();
    Pair<Retour, String> bl102Retour = Whitebox.invokeMethod(_processInstance, PP0306_BL102_APPLIQUER_ACTION_CORRECTIVE, _tracabilite, clientOperateur, noCompte, idErreurSpirit);
    PowerMock.verifyAll();

    //make sure we get the IdActionCorrective
    assertEquals(retourOK, bl102Retour._first);
    assertEquals(expectedIdActionCorrective, bl102Retour._second);
  }

  /**
   * <b>Scenario:</b> Config parameter UriPEI0028_RelancerCommande not found.<br>
   * <b>Input:</b> valid input<br>
   * <b>Result:</b> Retour NOK
   *
   * @throws Throwable
   *           On error
   */
  @Test
  public void PP0306_processConfigParams_Tests() throws Throwable
  {
    // Test when param  MAX_PROCESSING_RATE_PER_SEC is null
    //Process Manager Mock
    ConcurrentHashMap<String, Map<String, String>> processParams = new ConcurrentHashMap<>();
    HashMap<String, String> map = new HashMap<>();
    map.put("ERREUR_SPIRIT_FILTERS_CONFIG_FILE", "src/test/resources/PP0306_ErreurSpirit_filters_test.txt"); //$NON-NLS-1$ //$NON-NLS-2$
    map.put("MAX_PROCESSING_RATE_PER_SEC", null); //$NON-NLS-1$
    map.put("UriPEI0028_RelancerCommande", "PEI0028_RelancerCommande"); //$NON-NLS-1$

    processParams.put(StringConstants.EMPTY_STRING, map);
    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    Request request = prepareRequest(null, null, "xx", null); //$NON-NLS-1$
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();
    Retour bl001Retour = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ, DateTimeFormatPattern.yyyy_dash_MM_dash_dd).fromJson(request.getResponse().getResult(), Retour.class);
    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.TRAITEMENT_ARRETE, "Process parameter MAX_PROCESSING_RATE_PER_SEC not found"); //$NON-NLS-1$
    assertEquals(expectedRetour, bl001Retour);

    // Test when param MAX_PROCESSING_RATE_PER_SEC is invalid
    executedBeforeEach();
    //Process Manager Mock
    processParams = new ConcurrentHashMap<>();
    map = new HashMap<>();
    map.put("ERREUR_SPIRIT_FILTERS_CONFIG_FILE", "src/test/resources/PP0306_ErreurSpirit_filters_test.txt"); //$NON-NLS-1$ //$NON-NLS-2$
    map.put("MAX_PROCESSING_RATE_PER_SEC", "invalid"); //$NON-NLS-1$ //$NON-NLS-2$
    map.put("UriPEI0028_RelancerCommande", "PEI0028_RelancerCommande"); //$NON-NLS-1$

    processParams.put(StringConstants.EMPTY_STRING, map);
    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    request = prepareRequest(null, null, "xx", null); //$NON-NLS-1$
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();
    bl001Retour = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ, DateTimeFormatPattern.yyyy_dash_MM_dash_dd).fromJson(request.getResponse().getResult(), Retour.class);
    expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.TRAITEMENT_ARRETE, "Process parameter MAX_PROCESSING_RATE_PER_SEC not valid"); //$NON-NLS-1$
    assertEquals(expectedRetour, bl001Retour);

    // Test when param UriPEI0028_RelancerCommande is null
    executedBeforeEach();
    //Process Manager Mock
    processParams = new ConcurrentHashMap<>();
    map = new HashMap<>();
    map.put("ERREUR_SPIRIT_FILTERS_CONFIG_FILE", "src/test/resources/PP0306_ErreurSpirit_filters_test.txt"); //$NON-NLS-1$ //$NON-NLS-2$
    map.put("MAX_PROCESSING_RATE_PER_SEC", "10"); //$NON-NLS-1$ //$NON-NLS-2$
    map.put("UriPEI0028_RelancerCommande", null); //$NON-NLS-1$

    processParams.put(StringConstants.EMPTY_STRING, map);
    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    request = prepareRequest(null, null, "xx", null); //$NON-NLS-1$
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();
    bl001Retour = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ, DateTimeFormatPattern.yyyy_dash_MM_dash_dd).fromJson(request.getResponse().getResult(), Retour.class);
    expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.TRAITEMENT_ARRETE, "Process parameter UriPEI0028_RelancerCommande not found"); //$NON-NLS-1$
    assertEquals(expectedRetour, bl001Retour);

    // Test when config file path exists but is invalid which makes the file creation fails
    executedBeforeEach();
    //Process Manager Mock
    processParams = new ConcurrentHashMap<>();
    map = new HashMap<>();
    map.put("ERREUR_SPIRIT_FILTERS_CONFIG_FILE", "\0"); //invalid file path //$NON-NLS-1$ //$NON-NLS-2$
    map.put("MAX_PROCESSING_RATE_PER_SEC", "10"); //$NON-NLS-1$ //$NON-NLS-2$
    map.put("MAX_PROFONDEUR_RECHERCHE_MINUTE", "2880"); //$NON-NLS-1$ //$NON-NLS-2$
    map.put("UriPEI0028_RelancerCommande", "PEI0028_RelancerCommande"); //$NON-NLS-1$ //$NON-NLS-2$

    processParams.put(StringConstants.EMPTY_STRING, map);
    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    request = prepareRequest("2018-12-10T11:30", "2018-12-10T12:30", "12", X_REQUEST_ID_TEST); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();
    bl001Retour = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ, DateTimeFormatPattern.yyyy_dash_MM_dash_dd).fromJson(request.getResponse().getResult(), Retour.class);
    expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, "Unable to create file : Invalid file path"); //$NON-NLS-1$
    String hiddenCharactersRegex = "[\\p{Cc}\\p{Cf}\\p{Co}\\p{Cn}]"; //$NON-NLS-1$

    assertEquals(expectedRetour.getResultat(), bl001Retour.getResultat());
    assertEquals(expectedRetour.getCategorie(), bl001Retour.getCategorie());
    assertEquals(expectedRetour.getLibelle().trim(), bl001Retour.getLibelle().trim().replaceAll(hiddenCharactersRegex, StringConstants.EMPTY_STRING));
  }

  /**
   * <b>Scenario:</b> Scénario nominal OK.<br>
   * <b>Input:</b> valid input<br>
   * <b>Result:</b> Retour OK
   *
   * @throws Throwable
   *           En cas d'erreur
   */
  @Test
  public void PP0306_TraitementErreursSpiritTestOK() throws Throwable
  {
    //Process Manager Mock
    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams();
    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    String debut = "2018-12-10T11:30"; //$NON-NLS-1$
    String fin = "2018-12-10T12:30"; //$NON-NLS-1$
    Request request = prepareRequest(debut, fin, null, X_REQUEST_ID_TEST);

    /////////////////////////////////////
    //mock REX.erreurSpiritLireTousParStatutPeriod
    String idErreurSpirit = "test"; //$NON-NLS-1$
    ErreurSpirit erreurSpirit = new ErreurSpirit(idErreurSpirit, RetourConverter.convertToJsonRetour(RetourFactoryForTU.createNOK("CAT-4", "TRAITEMENT_ARRETE", "blablabla Test1")), ErreurSpiritStatut.OUVERT.name(), LocalDateTime.now(), LocalDateTime.now(), _tracabilite); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    Tracabilite tracabilite = new Tracabilite();
    Map<String, String> refFonc = new HashMap<>();
    String noCompte = "nocompte123"; //$NON-NLS-1$
    String clientOperateur = "cliop123"; //$NON-NLS-1$
    refFonc.put(IRefFoncConstants.NO_COMPTE, noCompte);
    refFonc.put(IRefFoncConstants.CLI_OPE, clientOperateur);
    tracabilite.setRefFonc(refFonc);
    erreurSpirit.setTracabilite(tracabilite);
    ConnectorResponse<Retour, List<ErreurSpirit>> expectedResponse = new ConnectorResponse<Retour, List<ErreurSpirit>>(RetourFactoryForTU.createOkRetour(), Arrays.asList(erreurSpirit));

    LocalDateTime dateDeb = LocalDateTime.parse(debut, PP0306_TraitementErreursSpirit.InputDateTimeformatter);
    LocalDateTime dateFin = LocalDateTime.parse(fin, PP0306_TraitementErreursSpirit.InputDateTimeformatter);
    Tracabilite tracabilite2 = new Tracabilite(_tracabilite.getIdCorrelationByTel(), _tracabilite.getIdCorrelationSpirit(), _tracabilite.getNomSysteme(), _tracabilite.getNomProcessus(), _tracabilite.getIdProcessusSpirit(), new HashMap<>(_tracabilite.getRefFonc()));
    prepareMockREXerreurSpiritLireTousParStatutPeriod(tracabilite2, Tools.formatDateTimeForPAD6003(dateDeb), Tools.formatDateTimeForPAD6003(dateFin), expectedResponse);

    addToRefFoncMap(_tracabilite, IRefFoncConstants.ID_ERREUR_SPIRIT, idErreurSpirit);

    //mock RST.serviceTechniqueLireTousParPfiFiltrerInactif to return empty list
    Retour retourNOK1 = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "test aucun service trouve", null); //$NON-NLS-1$
    ConnectorResponse<Retour, List<ServiceTechnique>> rstResponse = new ConnectorResponse<>(retourNOK1, null);
    prepareMockRSTserviceTechniqueLireTousParPfiFiltrerInactif(clientOperateur, noCompte, rstResponse);

    String idExterne = X_REQUEST_ID_TEST + "-" + idErreurSpirit; //$NON-NLS-1$
    String idActionCorrective = "idActionCorrectiveTest"; //$NON-NLS-1$
    //mock BL5100_CreerActionCorrective to return OK
    Retour retourOK = RetourFactoryForTU.createOkRetour();
    String expectedIdActionCorrective = idActionCorrective;
    prepareBL5100Mock(clientOperateur, noCompte, new ArrayList<>(), retourOK, expectedIdActionCorrective, idExterne);

    //mock BL5110 to return OK
    prepareBL5110Mock(idExterne, idActionCorrective, retourOK);

    //mock REX.erreurSpiritModifierStatut to return OK
    ConnectorResponse<Retour, Nothing> pad6003Response = new ConnectorResponse<Retour, Nothing>(retourOK, null);
    prepareMockREXerreurSpiritModifierStatut(erreurSpirit.getIdErreurSpirit(), ErreurSpiritStatut.CLOS.name(), pad6003Response);
    /////////////////////////////////////

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    //Expected response
    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setResult("{\"resultat\":\"OK\"}"); //$NON-NLS-1$
    final Response expected = new Response(ErrorCode.OK_00201, response);
    assertEquals(expected.getMarshalledResponseJson(), request.getResponse().getMarshalledResponseJson());
  }

  /**
   * Add to functional map
   *
   * @param tracabilite_p
   *          The tracabilite
   * @param name_p
   *          The name
   * @param value_p
   *          The name
   */
  private void addToRefFoncMap(Tracabilite tracabilite_p, String name_p, String value_p)
  {
    Map<String, String> map = tracabilite_p.getRefFonc();
    map.put(name_p, value_p);
    tracabilite_p.setRefFonc(map);
  }

  /**
   * Create PP0306_TraitementErreursSpirit process params.
   *
   * @return ConcurrentHashMap<String, Map<String, String>>
   */
  private ConcurrentHashMap<String, Map<String, String>> createProcessParams()
  {
    ConcurrentHashMap<String, Map<String, String>> processParams = new ConcurrentHashMap<>();
    HashMap<String, String> map = new HashMap<>();
    map.put("ERREUR_SPIRIT_FILTERS_CONFIG_FILE", "src/test/resources/PP0306_ErreurSpirit_filters_test.txt"); //$NON-NLS-1$ //$NON-NLS-2$
    map.put("MAX_PROCESSING_RATE_PER_SEC", "10"); //$NON-NLS-1$
    map.put("UriPEI0028_RelancerCommande", "PEI0028_RelancerCommande"); //$NON-NLS-1$ //$NON-NLS-2$
    map.put("MAX_PROFONDEUR_RECHERCHE_MINUTE", "2880"); //$NON-NLS-1$ //$NON-NLS-2$

    processParams.put(StringConstants.EMPTY_STRING, map);
    return processParams;
  }

  /**
   * Mock BL5100_CreerActionCorrective activity
   *
   * @param clientOperateur_p
   *          The client operateur
   * @param noCompte_p
   *          The no compte
   * @param listeActionServiceTechnique_p
   *          The liste action service technique
   * @param expectedRetour_p
   *          The expected retour
   * @param expectedIdActionCorrective_p
   *          The expected id action corrective
   * @param idExterne_p
   *          The id externe
   *
   * @throws Exception
   *           On error
   */
  private void prepareBL5100Mock(String clientOperateur_p, String noCompte_p, List<ActionServiceTechnique> listeActionServiceTechnique_p, Retour expectedRetour_p, String expectedIdActionCorrective_p, String idExterne_p) throws Exception
  {
    final BL5100_CreerActionCorrectiveBuilder builder = new BL5100_CreerActionCorrectiveBuilder();
    Whitebox.setInternalState(builder, "_toBuild", _bl5100Mock); //$NON-NLS-1$
    PowerMock.expectNew(BL5100_CreerActionCorrectiveBuilder.class).andReturn(builder).once();
    _bl5100Mock.setTracabilite(_tracabilite);
    EasyMock.expectLastCall().once();

    ActionCorrective actionCorrective = new ActionCorrective(clientOperateur_p, noCompte_p);
    actionCorrective.setActionsServicesTechniques(listeActionServiceTechnique_p);
    _bl5100Mock.setActionCorrective(actionCorrective);
    EasyMock.expectLastCall().once();
    _bl5100Mock.setIdExterne(idExterne_p);
    EasyMock.expectLastCall().once();

    EasyMock.expect(_bl5100Mock.getTracabilite()).andReturn(_tracabilite).once();
    EasyMock.expect(_bl5100Mock.getIdExterne()).andReturn(idExterne_p).once();
    EasyMock.expect(_bl5100Mock.getActionCorrective()).andReturn(actionCorrective).once();

    EasyMock.expect(_bl5100Mock.execute(EasyMock.anyObject(PP0306_TraitementErreursSpirit.class))).andReturn(expectedIdActionCorrective_p).once();
    EasyMock.expect(_bl5100Mock.getRetour()).andReturn(expectedRetour_p).once();
  }

  /**
   * Mock BL5110_ExecuterActionCorrective activity
   *
   * @param idExterne
   *          The id externe
   * @param idActionCorrective_p
   *          The id action corrective
   * @param expectedRetour_p
   *          The expected retour
   *
   * @throws Exception
   *           On error
   */
  private void prepareBL5110Mock(String idExterne, String idActionCorrective_p, Retour expectedRetour_p) throws Exception
  {
    Tracabilite tracabiliteBL5110 = new Tracabilite(_tracabilite.getIdCorrelationByTel(), idExterne, _tracabilite.getNomSysteme(), _tracabilite.getNomProcessus(), _tracabilite.getIdProcessusSpirit(), new HashMap<>(_tracabilite.getRefFonc()));
    prepareBL5110Mock(tracabiliteBL5110, idActionCorrective_p, expectedRetour_p);
  }

  /**
   * Mock BL5110_ExecuterActionCorrective activity
   *
   * @param tracabilite_p
   *          The tracabilite
   * @param idActionCorrective_p
   *          The id action corrective
   * @param expectedRetour_p
   *          The expected retour
   *
   * @throws Exception
   *           On error
   */
  private void prepareBL5110Mock(Tracabilite tracabilite_p, String idActionCorrective_p, Retour expectedRetour_p) throws Exception
  {
    final BL5110_ExecuterActionCorrectiveBuilder builder = new BL5110_ExecuterActionCorrectiveBuilder();
    Whitebox.setInternalState(builder, "_toBuild", _bl5110Mock); //$NON-NLS-1$
    PowerMock.expectNew(BL5110_ExecuterActionCorrectiveBuilder.class).andReturn(builder).once();
    _bl5110Mock.setTracabilite(tracabilite_p);
    EasyMock.expectLastCall().once();

    _bl5110Mock.setIdActionCorrective(idActionCorrective_p);
    EasyMock.expectLastCall().once();

    EasyMock.expect(_bl5110Mock.getTracabilite()).andReturn(tracabilite_p).once();
    EasyMock.expect(_bl5110Mock.getIdActionCorrective()).andReturn(idActionCorrective_p).once();

    EasyMock.expect(_bl5110Mock.execute(EasyMock.anyObject(PP0306_TraitementErreursSpirit.class))).andReturn(null).once();
    EasyMock.expect(_bl5110Mock.getRetour()).andReturn(expectedRetour_p).once();
  }

  /**
   * Mocks the call to PEI0028_RelancerCommande
   *
   * @throws RavelException
   *           En cas d'erreur
   */
  private void prepareMockPe0028() throws RavelException
  {
    Retour retourOk = RetourFactory.createOkRetour();
    STARKResponse<BasicResponse> starkOk = new STARKResponse<>(202, null);
    starkOk.setResponse(new BasicResponse(RetourConverter.convertToJsonRetour(retourOk)));

    ConnectorResponse<Retour, STARKResponse<BasicResponse>> starkResponse = new ConnectorResponse<Retour, STARKResponse<BasicResponse>>(retourOk, starkOk);

    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxy);
    EasyMock.expect(_starkProxy.sendPostRequest(EasyMock.anyObject(), EasyMock.anyString(), EasyMock.eq(BasicResponse.class), EasyMock.anyObject(), EasyMock.anyObject(), EasyMock.anyObject(), EasyMock.anyObject())).andReturn(starkResponse);
  }

  /**
   * Prepare mock for REX.erreurSpiritLireTousParStatutPeriod
   *
   * @param dateDeb_p
   *          The date debut
   * @param dateFin_p
   *          The date fin
   * @param expectedResponse_p
   *          THe expected response
   *
   * @throws RavelException
   *           On error
   */
  private void prepareMockREXerreurSpiritLireTousParStatutPeriod(String dateDeb_p, String dateFin_p, ConnectorResponse<Retour, List<ErreurSpirit>> expectedResponse_p) throws RavelException
  {
    prepareMockREXerreurSpiritLireTousParStatutPeriod(_tracabilite, dateDeb_p, dateFin_p, expectedResponse_p);
  }

  /**
   * Prepare mock for REX.erreurSpiritLireTousParStatutPeriod
   *
   * @param tracabilite_p
   *          The tracabilite
   * @param dateDeb_p
   *          The date debut
   * @param dateFin_p
   *          The date fin
   * @param expectedResponse_p
   *          The expected reponse
   *
   * @throws RavelException
   *           En cas d'erreur
   */
  private void prepareMockREXerreurSpiritLireTousParStatutPeriod(Tracabilite tracabilite_p, String dateDeb_p, String dateFin_p, ConnectorResponse<Retour, List<ErreurSpirit>> expectedResponse_p) throws RavelException
  {
    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxy);
    EasyMock.expect(_rexProxy.erreurSpiritLireTousParStatutPeriod(tracabilite_p, ErreurSpiritStatut.OUVERT.name(), dateDeb_p, dateFin_p)).andReturn(expectedResponse_p);
  }

  /**
   * Prepare mock for REX.erreurSpiritModifierStatut
   *
   * @param idErreurSpirit_p
   *          The id erreur spirit
   * @param name_p
   *          The name
   * @param connectorResponse_p
   *          The pad6003 reponse
   *
   * @throws RavelException
   *           En cas d'erreur
   */
  private void prepareMockREXerreurSpiritModifierStatut(String idErreurSpirit_p, String name_p, ConnectorResponse<Retour, Nothing> connectorResponse_p) throws RavelException
  {
    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxy);
    UpdateErreurSpiritRequest request = new UpdateErreurSpiritRequest(idErreurSpirit_p, name_p);
    EasyMock.expect(_rexProxy.erreurSpiritModifierStatut(_tracabilite, request)).andReturn(connectorResponse_p);
  }

  /**
   * Prepare mock for RST.serviceTechniqueLireTousParPfiFiltrerInactif
   *
   * @param clientOperateur
   *          The client operateur
   * @param noCompte
   *          The no de compte
   * @param expectedResponse_p
   *          The expected reponse
   *
   * @throws RavelException
   *           En cas d'erreur
   */
  private void prepareMockRSTserviceTechniqueLireTousParPfiFiltrerInactif(String clientOperateur, String noCompte, ConnectorResponse<Retour, List<ServiceTechnique>> expectedResponse_p) throws RavelException
  {
    EasyMock.expect(RSTProxy.getInstance()).andReturn(_rstProxy);
    EasyMock.expect(_rstProxy.serviceTechniqueLireTousParPfi(_tracabilite, clientOperateur, noCompte, null, null)).andReturn(expectedResponse_p);
  }

  /**
   * Prepare request with URL parameters
   *
   * @param dateDeb_p
   *          URL parameter
   * @param dateFin_p
   *          URL parameter
   * @param profondeurRechercheMin_p
   *          URL parameter
   * @param xRequestId_p
   *          The request ID
   *
   * @return GenericRequest to call PEI0028_RelancerCommande
   * @throws RavelException
   *           on error
   */
  private Request prepareRequest(String dateDeb_p, String dateFin_p, String profondeurRechercheMin_p, String xRequestId_p) throws RavelException
  {

    Request request = new Request(DEFAULT_PROCESSNAME, "idProcess", "idClient"); //$NON-NLS-1$ //$NON-NLS-2$
    request.setMsgId(Test_Consts.DEFAULT_MSGID);

    List<Parameter> list = new ArrayList<>();
    UrlParameters urlParametersType = new UrlParameters();

    if (dateDeb_p != null)
    {
      list.add(createParameter(PP0306_TraitementErreursSpirit.ParameterUrl.dateDebut.name(), dateDeb_p));
    }
    if (dateFin_p != null)
    {
      list.add(createParameter(PP0306_TraitementErreursSpirit.ParameterUrl.dateFin.name(), dateFin_p));
    }
    if (profondeurRechercheMin_p != null)
    {
      list.add(createParameter(PP0306_TraitementErreursSpirit.ParameterUrl.profondeurRecherche.name(), profondeurRechercheMin_p));
    }
    request.setUrlParameters(urlParametersType);

    if (xRequestId_p != null)
    {
      final RequestHeader xRequestId = new RequestHeader();
      xRequestId.setName(IHttpHeadersConsts.X_REQUEST_ID);
      xRequestId.setValue(xRequestId_p);
      request.getRequestHeader().addAll(Arrays.asList(xRequestId));
    }

    urlParametersType.setUrlParameters(list);
    request.setUrlParameters(urlParametersType);
    return request;
  }

}
