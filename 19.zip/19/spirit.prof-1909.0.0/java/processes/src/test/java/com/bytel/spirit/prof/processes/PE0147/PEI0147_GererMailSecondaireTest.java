/*******************************************************************************
* $Id: PEI0147_GererMailSecondaireTest.java 16252 2019-01-23 11:44:55Z rrosa $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PE0147;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.bytel.spirit.common.activities.shared.structs.BL3700_Return;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.reflect.Whitebox;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.data.exchange.generated.RavelRequest.RequestHeader;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.response.IRavelResponse;
import com.bytel.ravel.common.factory.response.RavelResponseFactory;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.utils.ACManagerUtil;
import com.bytel.ravel.common.utils.DateTimeTools.DateTimeFormatPattern;
import com.bytel.ravel.common.utils.Pair;
import com.bytel.ravel.common.utils.RetourFactoryForTU;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.net.http.HttpConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.ProcessManager;
import com.bytel.spirit.common.activities.shared.BL3700_RecupererPfiParMail;
import com.bytel.spirit.common.activities.shared.BL3700_RecupererPfiParMail.BL3700_RecupererPfiParMailBuilder;
import com.bytel.spirit.common.activities.shared.BL4600_CreerErreurSpirit;
import com.bytel.spirit.common.activities.shared.BL800_ObtenirSequence;
import com.bytel.spirit.common.activities.shared.BL800_ObtenirSequence.BL800_ObtenirSequenceBuilder;
import com.bytel.spirit.common.activities.shared.structs.BL3700_Return;
import com.bytel.spirit.common.activities.shared.structs.UniqueIdConstant;
import com.bytel.spirit.common.connectors.cmd.CMDProxy;
import com.bytel.spirit.common.connectors.ink.activities.PROV_SI001_LancerOrchestrateur;
import com.bytel.spirit.common.connectors.ink.activities.PROV_SI001_LancerOrchestrateur.PROV_SI001_LancerOrchestrateurBuilder;
import com.bytel.spirit.common.connectors.reftech.ReftechProxy;
import com.bytel.spirit.common.connectors.reftech.structs.ReftechRetour;
import com.bytel.spirit.common.connectors.rex.REXProxy;
import com.bytel.spirit.common.connectors.rpg.RPGProxy;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.error.ReponseErreur;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.IRefFoncConstants;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.cmd.Commande;
import com.bytel.spirit.common.shared.saab.cmd.request.CreateCommandeRequest;
import com.bytel.spirit.common.shared.saab.rex.request.CreateErreurSpiritRequest;
import com.bytel.spirit.common.shared.saab.rpg.PA;
import com.bytel.spirit.common.shared.saab.rpg.PFI;
import com.bytel.spirit.common.shared.saab.rpg.PaTypeCompteAcces;
import com.bytel.spirit.common.shared.saab.rpg.SA;
import com.bytel.spirit.prof.processes.Messages;
import com.bytel.spirit.prof.processes.PE0147.PEI0147_GererMailSecondaire.BL001_VerifierDonneesReturn;
import com.bytel.spirit.prof.shared.types.json.request.ServiceMailGererMailSecondaireRequest;
import com.bytel.spirit.prof.shared.types.json.request.ServiceMailGererMailSecondaireRequest.MailSecondaire;
import com.bytel.spirit.prof.shared.types.json.request.ServiceMailGererMailSecondaireRequest.Statut;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author kbettenc
 * @version ($Revision: 16252 $ $Date: 2019-01-23 12:44:55 +0100 (mer. 23 janv. 2019) $)
 */

@RunWith(PowerMockRunner.class)
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
@PrepareForTest({ PEI0147_GererMailSecondaire.class, CMDProxy.class, ReftechProxy.class, BL800_ObtenirSequenceBuilder.class, BL800_ObtenirSequence.class, RPGProxy.class, BL3700_RecupererPfiParMail.class, BL3700_RecupererPfiParMailBuilder.class, PROV_SI001_LancerOrchestrateur.class, PROV_SI001_LancerOrchestrateurBuilder.class, REXProxy.class, BL4600_CreerErreurSpirit.class })
public class PEI0147_GererMailSecondaireTest
{
  /**
   *
   */
  private static final String PEI0147_BL001_VERIFIER_DONNEES = "PEI0147_BL001_VerifierDonnees"; //$NON-NLS-1$

  /**
   * Tracabilite
   */
  private static Tracabilite _tracabilite;

  /**
   * Factory de génération des beans
   */
  private static PodamFactory __podam = new PodamFactoryImpl();

  /**
   * SPRING context
   */
  private static ClassPathXmlApplicationContext __context;

  /**
   * PEP0147_GERERMAILSECONDAIRE
   */
  private static final String PEP0147_GERERMAILSECONDAIRE = "PEP0147_GererMailSecondaire"; //$NON-NLS-1$

  /**
   * Initialization method: Create: - spring context - connectors - service manager.
   *
   * @throws RavelException
   *           the exception
   */
  @BeforeClass
  public static void init() throws RavelException
  {

    // désactivation du cache podam
    __podam.getStrategy().setMemoization(false);
    __podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());

    ACManagerUtil.resetACManager();
    __context = new ClassPathXmlApplicationContext("classpath:BeansProcessTestMocks.xml"); //$NON-NLS-1$
  }

  /**
  *
  */
  @MockStrict
  private BL3700_RecupererPfiParMailBuilder _bl3700BuilderMock;

  /**
    *
    */
  @MockStrict
  private BL3700_RecupererPfiParMail _bl3700Mock;

  /**
   *
   */
  @MockStrict
  private BL800_ObtenirSequenceBuilder _bl800BuilderMock;

  /**
   *
   */
  @MockStrict
  private BL800_ObtenirSequence _bl800Mock;

  /**
  *
  */
  @MockStrict
  private PROV_SI001_LancerOrchestrateurBuilder _provSI001BuilderMock;

  /**
  *
  */
  @MockStrict
  private PROV_SI001_LancerOrchestrateur _provSI001Mock;

  /**
  *
  */
  @MockStrict
  private CMDProxy _cmdProxy;

  /**
  *
  */
  @MockStrict
  private RPGProxy _rpgDatabaseProxy;
  /**
   *
   */
  @MockStrict
  private ReftechProxy _reftechProxy;

  /**
  *
  */
  @MockStrict
  private REXProxy _rexProxy;

  /**
   * Instance of {@link PEI0147_GererMailSecondaire}
   */
  private PEI0147_GererMailSecondaire _processInstance;

  /**
   * <b>Scenario:</b> Tests non nominal case. The required header X-Client-Operateur is not set.<br>
   * <b>Input:</b> "X-Client-Operateur" not set in headers<br>
   * <b>Result:</b> Retour {KO, CAT-3, NON_RESPECT_STI, Header X-Client-Operateur null ou vide.,
   * PEI0147_BL001_VerifierDonnees}
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PEI0147_BL001_VerifierDonnees_Test_KO_01() throws Exception
  {

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "GESTION MAIL SECONDAIRE"); //$NON-NLS-1$
    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "DOMINGO"); //$NON-NLS-1$

    fillRequestHeaders(request, xRequestId, xProcess, xSource);

    BL001_VerifierDonneesReturn bl001Retour = Whitebox.invokeMethod(_processInstance, PEI0147_BL001_VERIFIER_DONNEES, _tracabilite, request);

    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString("PEI0147.BL001.HeaderNullOrEmpty"), IHttpHeadersConsts.X_CLIENT_OPERATEUR), null); //$NON-NLS-1$

    assertEquals(retourExpected, bl001Retour.getRetour());
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. The required header X-Source is not set.<br>
   * <b>Input:</b> "X-Source" not set in headers<br>
   * <b>Result:</b> Retour {KO, CAT-3, NON_RESPECT_STI, Header X-Source null ou vide., PEI0147_BL001_VerifierDonnees}
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PEI0147_BL001_VerifierDonnees_Test_KO_02() throws Exception
  {

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xClientOperateur = createHeader(IHttpHeadersConsts.X_CLIENT_OPERATEUR, "BSS_GP"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "GESTION MAIL SECONDAIRE"); //$NON-NLS-1$

    fillRequestHeaders(request, xClientOperateur, xRequestId, xProcess);

    BL001_VerifierDonneesReturn bl001Retour = Whitebox.invokeMethod(_processInstance, PEI0147_BL001_VERIFIER_DONNEES, _tracabilite, request);

    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString("PEI0147.BL001.HeaderNullOrEmpty"), IHttpHeadersConsts.X_SOURCE), null); //$NON-NLS-1$

    assertEquals(retourExpected, bl001Retour.getRetour());
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. The required header X-Request-Id is not set.<br>
   * <b>Input:</b> "X-Request-Id" not set in headers<br>
   * <b>Result:</b> Retour {KO, CAT-3, NON_RESPECT_STI, Header X-Request-Id null ou vide.,
   * PEI0147_BL001_VerifierDonnees}
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PEI0147_BL001_VerifierDonnees_Test_KO_03() throws Exception
  {

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xClientOperateur = createHeader(IHttpHeadersConsts.X_CLIENT_OPERATEUR, "BSS_GP"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "GESTION MAIL SECONDAIRE"); //$NON-NLS-1$
    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "DOMINGO"); //$NON-NLS-1$

    fillRequestHeaders(request, xClientOperateur, xProcess, xSource);

    BL001_VerifierDonneesReturn bl001Retour = Whitebox.invokeMethod(_processInstance, PEI0147_BL001_VERIFIER_DONNEES, _tracabilite, request);

    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString("PEI0147.BL001.HeaderNullOrEmpty"), IHttpHeadersConsts.X_REQUEST_ID), null); //$NON-NLS-1$

    assertEquals(retourExpected, bl001Retour.getRetour());
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. The required header X-Process is not set.<br>
   * <b>Input:</b> "X-Process" not set in headers<br>
   * <b>Result:</b> Retour {KO, CAT-3, NON_RESPECT_STI, Header X-Process null ou vide., PEI0147_BL001_VerifierDonnees}
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PEI0147_BL001_VerifierDonnees_Test_KO_04() throws Exception
  {

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xClientOperateur = createHeader(IHttpHeadersConsts.X_CLIENT_OPERATEUR, "BSS_GP"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "DOMINGO"); //$NON-NLS-1$

    fillRequestHeaders(request, xClientOperateur, xRequestId, xSource);

    BL001_VerifierDonneesReturn bl001Retour = Whitebox.invokeMethod(_processInstance, PEI0147_BL001_VERIFIER_DONNEES, _tracabilite, request);

    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString("PEI0147.BL001.HeaderNullOrEmpty"), IHttpHeadersConsts.X_PROCESS), null); //$NON-NLS-1$

    assertEquals(retourExpected, bl001Retour.getRetour());
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. The required field identifiantAcces is not set.<br>
   * <b>Input:</b> "identifiantAcces" not set in the request <br>
   * <b>Result:</b> Retour {KO, CAT-3, NON_RESPECT_STI, Attribut(s) obligatoire(s) manquant(s): [_identifiantAcces],
   * PEI0147_BL001_VerifierDonnees}
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PEI0147_BL001_VerifierDonnees_Test_KO_05() throws Exception
  {

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    fillAllRequestHeaders(request);

    request.setHttpMethod("POST"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    ServiceMailGererMailSecondaireRequest mailSecondaireRequest = buildValidServiceMailGererMailSecondaireRequest();
    mailSecondaireRequest.setIdentifiantAcces(null);//cause validation error
    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(mailSecondaireRequest, ServiceMailGererMailSecondaireRequest.class);

    _tracabilite.setIdCorrelationByTel("RequestId"); //$NON-NLS-1$
    request.setPayload(jSonRequest);

    BL001_VerifierDonneesReturn bl001Retour = Whitebox.invokeMethod(_processInstance, PEI0147_BL001_VERIFIER_DONNEES, _tracabilite, request);

    assertEquals(IMegConsts.CAT3, bl001Retour.getRetour().getCategorie());
    assertEquals(IMegSpiritConsts.NON_RESPECT_STI, bl001Retour.getRetour().getDiagnostic());
    assertEquals("Attribut(s) obligatoire(s) manquant(s): [_identifiantAcces]", bl001Retour.getRetour().getLibelle()); //$NON-NLS-1$
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. The required field mailSecondaire is not set.<br>
   * <b>Input:</b> "mailSecondaire" not set in the request <br>
   * <b>Result:</b> Retour {KO, CAT-3, NON_RESPECT_STI, Attribut(s) obligatoire(s) manquant(s): [_mailSecondaire],
   * PEI0147_BL001_VerifierDonnees}
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PEI0147_BL001_VerifierDonnees_Test_KO_06() throws Exception
  {

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    fillAllRequestHeaders(request);

    request.setHttpMethod("POST"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    ServiceMailGererMailSecondaireRequest mailSecondaireRequest = buildValidServiceMailGererMailSecondaireRequest();
    mailSecondaireRequest.setMailSecondaire(null); // cause validation error

    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(mailSecondaireRequest, ServiceMailGererMailSecondaireRequest.class);

    request.setPayload(jSonRequest);

    _tracabilite.setIdCorrelationByTel("RequestId"); //$NON-NLS-1$
    BL001_VerifierDonneesReturn bl001Retour = Whitebox.invokeMethod(_processInstance, PEI0147_BL001_VERIFIER_DONNEES, _tracabilite, request);

    assertEquals(IMegConsts.CAT3, bl001Retour.getRetour().getCategorie());
    assertEquals(IMegSpiritConsts.NON_RESPECT_STI, bl001Retour.getRetour().getDiagnostic());
    assertEquals("Attribut(s) obligatoire(s) manquant(s): [_mailSecondaire]", bl001Retour.getRetour().getLibelle()); //$NON-NLS-1$
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. The required fields identifiantAcces and mailSecondaire are not set.<br>
   * <b>Input:</b> "identifiantAcces" and "mailSecondaire" not set in the request <br>
   * <b>Result:</b> Retour {KO, CAT-3, NON_RESPECT_STI, Attribut(s) obligatoire(s) manquant(s):
   * [_identifiantAcces][_mailSecondaire], PEI0147_BL001_VerifierDonnees}
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  //  @Test
  public void PEI0147_BL001_VerifierDonnees_Test_KO_07() throws Exception
  {

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    fillAllRequestHeaders(request);

    request.setHttpMethod("POST"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    ServiceMailGererMailSecondaireRequest mailSecondaireRequest = new ServiceMailGererMailSecondaireRequest();

    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(mailSecondaireRequest, ServiceMailGererMailSecondaireRequest.class);

    request.setPayload(jSonRequest);

    BL001_VerifierDonneesReturn bl001Retour = Whitebox.invokeMethod(_processInstance, PEI0147_BL001_VERIFIER_DONNEES, _tracabilite, request);

    assertEquals(IMegConsts.CAT3, bl001Retour.getRetour().getCategorie());
    assertEquals(IMegSpiritConsts.NON_RESPECT_STI, bl001Retour.getRetour().getDiagnostic());
    assertEquals("Attribut(s) obligatoire(s) manquant(s): [_identifiantAcces][_mailSecondaire]", bl001Retour.getRetour().getLibelle()); //$NON-NLS-1$
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. The BL3700 returns KO<br>
   * <b>Input:</b> BL3700 mock KO <br>
   * <b>Result:</b> Retour {KO, CAT-4, MAIL_INCONNU, Mail Principal charles.rock inconnu, PEI0147_BL001_VerifierDonnees}
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PEI0147_BL001_VerifierDonnees_Test_KO_08() throws Exception
  {

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    fillAllRequestHeaders(request);

    request.setHttpMethod("POST"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    ServiceMailGererMailSecondaireRequest mailSecondaireRequest = buildValidServiceMailGererMailSecondaireRequest();

    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(mailSecondaireRequest, ServiceMailGererMailSecondaireRequest.class);

    request.setPayload(jSonRequest);

    _tracabilite.setIdCorrelationByTel("RequestId"); //$NON-NLS-1$
    Retour bl3700Retour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, StringConstants.EMPTY_STRING, null);
    mockBL3700(_tracabilite, mailSecondaireRequest, _processInstance, null, null, bl3700Retour);

    PowerMock.replayAll();
    BL001_VerifierDonneesReturn bl001Retour = Whitebox.invokeMethod(_processInstance, PEI0147_BL001_VERIFIER_DONNEES, _tracabilite, request);
    PowerMock.verify();

    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.MAIL_INCONNU, MessageFormat.format(Messages.getString("PEI0147.BL001.MailPrincipalInconnu"), mailSecondaireRequest.getIdentifiantAcces().getLoginMail()), null); //$NON-NLS-1$

    assertEquals(retourExpected, bl001Retour.getRetour());
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. The RPGProxy returns KO<br>
   * <b>Input:</b> RPGProxy mock KO <br>
   * <b>Result:</b> Retour {KO, CAT-4, MAIL_INCONNU, Mail Principal charles.rock inconnu, PEI0147_BL001_VerifierDonnees}
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PEI0147_BL001_VerifierDonnees_Test_KO_09() throws Exception
  {

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    fillAllRequestHeaders(request);

    request.setHttpMethod("POST"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    ServiceMailGererMailSecondaireRequest mailSecondaireRequest = buildValidServiceMailGererMailSecondaireRequest();

    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(mailSecondaireRequest, ServiceMailGererMailSecondaireRequest.class);

    request.setPayload(jSonRequest);

    //MOCK BL3700
    Retour bl3700Retour = RetourFactoryForTU.createOkRetour();
    String clientOperateur = "BSS_GP"; //$NON-NLS-1$
    String noCompte = "123456789"; //$NON-NLS-1$
    _tracabilite.setIdCorrelationByTel("RequestId"); //$NON-NLS-1$

    mockBL3700(_tracabilite, mailSecondaireRequest, _processInstance, clientOperateur, noCompte, bl3700Retour);

    //MOCK RPGProxy
    createMockRPG(_tracabilite, RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "", null), null, clientOperateur, noCompte); //$NON-NLS-1$

    PowerMock.replayAll();
    BL001_VerifierDonneesReturn bl001Retour = Whitebox.invokeMethod(_processInstance, PEI0147_BL001_VERIFIER_DONNEES, _tracabilite, request);
    PowerMock.verify();

    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.MAIL_INCONNU, MessageFormat.format(Messages.getString("PEI0147.BL001.MailPrincipalInconnu"), mailSecondaireRequest.getIdentifiantAcces().getLoginMail()), null); //$NON-NLS-1$

    assertEquals(retourExpected, bl001Retour.getRetour());
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. The access account of the access point (PA) is null<br>
   * <b>Input:</b> A PFI with no PA of type COMPTE_ACCES <br>
   * <b>Result:</b> Retour {KO, CAT-4, MAIL_INCONNU, Mail Principal charles.rock associé à un point d''accès inexistant
   * ou résilié, PEI0147_BL001_VerifierDonnees}
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PEI0147_BL001_VerifierDonnees_Test_KO_10() throws Exception
  {

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    fillAllRequestHeaders(request);

    request.setHttpMethod("POST"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    ServiceMailGererMailSecondaireRequest mailSecondaireRequest = buildValidServiceMailGererMailSecondaireRequest();

    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(mailSecondaireRequest, ServiceMailGererMailSecondaireRequest.class);

    request.setPayload(jSonRequest);

    Retour retourOK = RetourFactoryForTU.createOkRetour();
    //MOCK BL3700
    String clientOperateur = "BSS_GP"; //$NON-NLS-1$
    String noCompte = "123456789"; //$NON-NLS-1$
    _tracabilite.setIdCorrelationByTel("RequestId"); //$NON-NLS-1$

    mockBL3700(_tracabilite, mailSecondaireRequest, _processInstance, clientOperateur, noCompte, retourOK);

    //MOCK RPGProxy
    createMockRPG(_tracabilite, retourOK, new PFI(), clientOperateur, noCompte);

    PowerMock.replayAll();
    BL001_VerifierDonneesReturn bl001Retour = Whitebox.invokeMethod(_processInstance, PEI0147_BL001_VERIFIER_DONNEES, _tracabilite, request);
    PowerMock.verify();

    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.MAIL_INCONNU, MessageFormat.format(Messages.getString("PEI0147.BL001.MailInexistantOuResilie"), mailSecondaireRequest.getIdentifiantAcces().getLoginMail()), null); //$NON-NLS-1$

    assertEquals(retourExpected, bl001Retour.getRetour());
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. The access account of the access point (PA) is not active<br>
   * <b>Input:</b> A PFI with a PA of type COMPTE_ACCES without the status ACTIF<br>
   * <b>Result:</b> Retour {KO, CAT-4, MAIL_INCONNU, Mail Principal charles.rock associé à un point d''accès inexistant
   * ou résilié, PEI0147_BL001_VerifierDonnees}
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PEI0147_BL001_VerifierDonnees_Test_KO_11() throws Exception
  {

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    fillAllRequestHeaders(request);

    request.setHttpMethod("POST"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    ServiceMailGererMailSecondaireRequest mailSecondaireRequest = buildValidServiceMailGererMailSecondaireRequest();

    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(mailSecondaireRequest, ServiceMailGererMailSecondaireRequest.class);

    request.setPayload(jSonRequest);

    Retour retourOK = RetourFactoryForTU.createOkRetour();
    //MOCK BL3700
    String clientOperateur = "BSS_GP"; //$NON-NLS-1$
    String noCompte = "123456789"; //$NON-NLS-1$
    _tracabilite.setIdCorrelationByTel("RequestId"); //$NON-NLS-1$

    mockBL3700(_tracabilite, mailSecondaireRequest, _processInstance, clientOperateur, noCompte, retourOK);

    //MOCK RPGProxy
    PFI pfi = new PFI();
    List<PA> listpa = new ArrayList<>();
    PaTypeCompteAcces paType = new PaTypeCompteAcces("charles.rock"); //$NON-NLS-1$
    PA pa = new PA(null, "COMPTE_ACCES", com.bytel.spirit.common.shared.saab.rpg.Statut.RESILIE, null, null); //$NON-NLS-1$
    pa.setPaTypeCompteAcces(paType);
    listpa.add(pa);
    pfi.setPa(listpa);
    createMockRPG(_tracabilite, retourOK, pfi, clientOperateur, noCompte);

    PowerMock.replayAll();
    BL001_VerifierDonneesReturn bl001Retour = Whitebox.invokeMethod(_processInstance, PEI0147_BL001_VERIFIER_DONNEES, _tracabilite, request);
    PowerMock.verify();

    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.MAIL_INCONNU, MessageFormat.format(Messages.getString("PEI0147.BL001.MailInexistantOuResilie"), mailSecondaireRequest.getIdentifiantAcces().getLoginMail()), null); //$NON-NLS-1$

    assertEquals(retourExpected, bl001Retour.getRetour());
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. An activation without MAIL commercial service<br>
   * <b>Input:</b> A pfi without SA having Mail commercial service<br>
   * <b>Result:</b> Retour {KO, CAT-4, MAIL_INCONNU, Mail Principal charles.rock à un usage restreint,
   * PEI0147_BL001_VerifierDonnees}
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PEI0147_BL001_VerifierDonnees_Test_KO_12() throws Exception
  {

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    fillAllRequestHeaders(request);

    request.setHttpMethod("POST"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    ServiceMailGererMailSecondaireRequest mailSecondaireRequest = buildValidServiceMailGererMailSecondaireRequest();

    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(mailSecondaireRequest, ServiceMailGererMailSecondaireRequest.class);

    request.setPayload(jSonRequest);

    Retour retourOK = RetourFactoryForTU.createOkRetour();
    //MOCK BL3700
    String clientOperateur = "BSS_GP"; //$NON-NLS-1$
    String noCompte = "123456789"; //$NON-NLS-1$
    _tracabilite.setIdCorrelationByTel("RequestId"); //$NON-NLS-1$

    mockBL3700(_tracabilite, mailSecondaireRequest, _processInstance, clientOperateur, noCompte, retourOK);

    //MOCK RPGProxy
    PFI pfi = new PFI();
    List<PA> listpa = new ArrayList<>();
    PaTypeCompteAcces paType = new PaTypeCompteAcces("charles.rock"); //$NON-NLS-1$
    PA pa = new PA(null, "COMPTE_ACCES", com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, null, null); //$NON-NLS-1$
    pa.setPaTypeCompteAcces(paType);
    listpa.add(pa);
    pfi.setPa(listpa);
    createMockRPG(_tracabilite, retourOK, pfi, clientOperateur, noCompte);

    PowerMock.replayAll();
    BL001_VerifierDonneesReturn bl001Retour = Whitebox.invokeMethod(_processInstance, PEI0147_BL001_VERIFIER_DONNEES, _tracabilite, request);
    PowerMock.verify();

    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.MAIL_INCONNU, MessageFormat.format(Messages.getString("PEI0147.BL001.MailRestreint"), mailSecondaireRequest.getIdentifiantAcces().getLoginMail()), null); //$NON-NLS-1$

    assertEquals(retourExpected, bl001Retour.getRetour());
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. Activation with Mail commercial service not active <br>
   * <b>Input:</b> A pfi with SA having Mail commercial service not active<br>
   * <b>Result:</b> Retour {KO, CAT-4, MAIL_INCONNU, Mail Principal charles.rock à un usage restreint,
   * PEI0147_BL001_VerifierDonnees}
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PEI0147_BL001_VerifierDonnees_Test_KO_13() throws Exception
  {

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    fillAllRequestHeaders(request);

    request.setHttpMethod("POST"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    ServiceMailGererMailSecondaireRequest mailSecondaireRequest = buildValidServiceMailGererMailSecondaireRequest();

    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(mailSecondaireRequest, ServiceMailGererMailSecondaireRequest.class);

    request.setPayload(jSonRequest);

    Retour retourOK = RetourFactoryForTU.createOkRetour();
    //MOCK BL3700
    String clientOperateur = "BSS_GP"; //$NON-NLS-1$
    String noCompte = "123456789"; //$NON-NLS-1$
    _tracabilite.setIdCorrelationByTel("RequestId"); //$NON-NLS-1$

    mockBL3700(_tracabilite, mailSecondaireRequest, _processInstance, clientOperateur, noCompte, retourOK);

    //MOCK RPGProxy
    PFI pfi = new PFI();
    List<PA> listpa = new ArrayList<>();
    PaTypeCompteAcces paType = new PaTypeCompteAcces("charles.rock"); //$NON-NLS-1$
    PA pa = new PA(null, "COMPTE_ACCES", com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, null, null); //$NON-NLS-1$
    pa.setPaTypeCompteAcces(paType);
    listpa.add(pa);
    pfi.setPa(listpa);

    List<SA> listSA = new ArrayList<>();
    SA sa = new SA();
    sa.setNomServiceCommercial("MAIL"); //$NON-NLS-1$
    listSA.add(sa);
    pfi.setSa(listSA);

    createMockRPG(_tracabilite, retourOK, pfi, clientOperateur, noCompte);

    PowerMock.replayAll();
    BL001_VerifierDonneesReturn bl001Retour = Whitebox.invokeMethod(_processInstance, PEI0147_BL001_VERIFIER_DONNEES, _tracabilite, request);
    PowerMock.verify();

    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.MAIL_INCONNU, MessageFormat.format(Messages.getString("PEI0147.BL001.MailRestreint"), mailSecondaireRequest.getIdentifiantAcces().getLoginMail()), null); //$NON-NLS-1$

    assertEquals(retourExpected, bl001Retour.getRetour());
  }

  /**
   * <b>Scenario:</b> Tests nominal case without an activation <br>
   * <b>Input:</b> All valid inputs. The principal mail status is not ACTIF<br>
   * <b>Result:</b> Retour OK
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PEI0147_BL001_VerifierDonnees_Test_OK_01() throws Exception
  {

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    fillAllRequestHeaders(request);

    request.setHttpMethod("POST"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    ServiceMailGererMailSecondaireRequest mailSecondaireRequest = buildValidServiceMailGererMailSecondaireRequest();
    mailSecondaireRequest.getMailSecondaire().setStatut(Statut.RESILIE.name());

    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(mailSecondaireRequest, ServiceMailGererMailSecondaireRequest.class);

    request.setPayload(jSonRequest);

    Retour retourOK = RetourFactoryForTU.createOkRetour();
    //MOCK BL3700
    String clientOperateur = "BSS_GP"; //$NON-NLS-1$
    String noCompte = "123456789"; //$NON-NLS-1$
    _tracabilite.setIdCorrelationByTel("RequestId"); //$NON-NLS-1$

    mockBL3700(_tracabilite, mailSecondaireRequest, _processInstance, clientOperateur, noCompte, retourOK);

    //MOCK RPGProxy
    PFI pfi = new PFI();
    List<PA> listpa = new ArrayList<>();
    PaTypeCompteAcces paType = new PaTypeCompteAcces("charles.rock"); //$NON-NLS-1$
    PA pa = new PA(null, "COMPTE_ACCES", com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, null, null); //$NON-NLS-1$
    pa.setPaTypeCompteAcces(paType);
    listpa.add(pa);
    pfi.setPa(listpa);
    createMockRPG(_tracabilite, retourOK, pfi, clientOperateur, noCompte);

    PowerMock.replayAll();
    BL001_VerifierDonneesReturn bl001Retour = Whitebox.invokeMethod(_processInstance, PEI0147_BL001_VERIFIER_DONNEES, _tracabilite, request);
    PowerMock.verify();

    assertEquals(retourOK, bl001Retour.getRetour());
  }

  /**
   * <b>Scenario:</b> Tests nominal case with an activation <br>
   * <b>Input:</b> All valid inputs. The principal mail status is ACTIF<br>
   * <b>Result:</b> Retour OK
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PEI0147_BL001_VerifierDonnees_Test_OK_02() throws Exception
  {

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    fillAllRequestHeaders(request);

    request.setHttpMethod("POST"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    ServiceMailGererMailSecondaireRequest mailSecondaireRequest = buildValidServiceMailGererMailSecondaireRequest();

    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(mailSecondaireRequest, ServiceMailGererMailSecondaireRequest.class);

    request.setPayload(jSonRequest);

    Retour retourOK = RetourFactoryForTU.createOkRetour();
    //MOCK BL3700
    String clientOperateur = "BSS_GP"; //$NON-NLS-1$
    String noCompte = "123456789"; //$NON-NLS-1$
    _tracabilite.setIdCorrelationByTel("125667889000877"); //$NON-NLS-1$

    mockBL3700(_tracabilite, mailSecondaireRequest, _processInstance, clientOperateur, noCompte, retourOK);

    //MOCK RPGProxy
    PFI pfi = new PFI();
    List<PA> listpa = new ArrayList<>();
    PaTypeCompteAcces paType = new PaTypeCompteAcces("charles.rock"); //$NON-NLS-1$
    PA pa = new PA(null, "COMPTE_ACCES", com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, null, null); //$NON-NLS-1$
    pa.setPaTypeCompteAcces(paType);
    listpa.add(pa);
    pfi.setPa(listpa);

    List<SA> listSA = new ArrayList<>();
    SA sa = new SA();
    sa.setNomServiceCommercial("MAIL"); //$NON-NLS-1$
    sa.setStatut(com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF);
    listSA.add(sa);
    pfi.setSa(listSA);

    createMockRPG(_tracabilite, retourOK, pfi, clientOperateur, noCompte);

    PowerMock.replayAll();
    BL001_VerifierDonneesReturn bl001Retour = Whitebox.invokeMethod(_processInstance, PEI0147_BL001_VERIFIER_DONNEES, _tracabilite, request);
    PowerMock.verify();

    assertEquals(retourOK, bl001Retour.getRetour());
  }

  /**
   * <b>Scenario:</b> Tests case with a Retour KO CAT-3 <br>
   * <b>Input:</b> Retour {KO; CAT-3; NON_RESPECT_STI; "Attribut(s) obligatoire(s) manquant(s):
   * [_identifiantAcces]"}<br>
   * <b>Result:</b> ReponseErreur : Error{NON_RESPECT_STI}, ErrorDescription{"Attribut(s) obligatoire(s) manquant(s):
   * [_identifiantAcces]"}}
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PEI0147_BL002_FormaterReponse_Test_01() throws Exception
  {

    ReponseErreur responseErreurExpected = new ReponseErreur();
    responseErreurExpected.setError(IMegSpiritConsts.NON_RESPECT_STI);
    responseErreurExpected.setErrorDescription(MessageFormat.format(Messages.getString("PEI0147.BL002.ErrorDescription"), "Attribut(s) obligatoire(s) manquant(s): [_identifiantAcces]", IMegSpiritConsts.NON_RESPECT_STI)); //$NON-NLS-1$ //$NON-NLS-2$

    ReponseErreur reponseBL002 = Whitebox.invokeMethod(_processInstance, "PEI0147_BL002_FormaterReponse", _tracabilite, RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, "Attribut(s) obligatoire(s) manquant(s): [_identifiantAcces]", null)); //$NON-NLS-1$ //$NON-NLS-2$

    assertEquals(responseErreurExpected, reponseBL002);
  }

  /**
   * <b>Scenario:</b> Tests case with a Retour KO CAT-4 DONNEE_EXISTANTE <br>
   * <b>Input:</b> Retour {KO; CAT-4; DONNEE_EXISTANTE; "DONNEE_EXISTANTE"}<br>
   * <b>Result:</b> ReponseErreur : Error{MAIL_SECONDAIRE_DEJA_UTILISE}, ErrorDescription{"DONNEE_EXISTANTE"}}
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PEI0147_BL002_FormaterReponse_Test_02() throws Exception
  {

    ReponseErreur responseErreurExpected = new ReponseErreur();
    responseErreurExpected.setError(IMegSpiritConsts.MAIL_SECONDAIRE_DEJA_UTILISE);
    responseErreurExpected.setErrorDescription(MessageFormat.format(Messages.getString("PEI0147.BL002.ErrorDescription"), "DONNEE_EXISTANTE", IMegSpiritConsts.DONNEE_EXISTANTE)); //$NON-NLS-1$ //$NON-NLS-2$

    ReponseErreur reponseBL002 = Whitebox.invokeMethod(_processInstance, "PEI0147_BL002_FormaterReponse", _tracabilite, RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.DONNEE_EXISTANTE, "DONNEE_EXISTANTE", null)); //$NON-NLS-1$ //$NON-NLS-2$

    assertEquals(responseErreurExpected, reponseBL002);
  }

  /**
   * <b>Scenario:</b> Tests case with a Retour KO CAT-4 DONNEE_INVALIDE <br>
   * <b>Input:</b> Retour {KO; CAT-4; DONNEE_INVALIDE; "DONNEE_INVALIDE]"}<br>
   * <b>Result:</b> ReponseErreur : Error{MAIL_SECONDAIRE_DEJA_UTILISE}, ErrorDescription{"Attribut(s) obligatoire(s)
   * manquant(s): [_identifiantAcces]"}}
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PEI0147_BL002_FormaterReponse_Test_03() throws Exception
  {

    ReponseErreur responseErreurExpected = new ReponseErreur();
    responseErreurExpected.setError(IMegSpiritConsts.NON_RESPECT_STI);
    responseErreurExpected.setErrorDescription(MessageFormat.format(Messages.getString("PEI0147.BL002.ErrorDescriptionMailNonReserve"), "DONNEE_INVALIDE", IMegSpiritConsts.DONNEE_INVALIDE)); //$NON-NLS-1$ //$NON-NLS-2$

    ReponseErreur reponseBL002 = Whitebox.invokeMethod(_processInstance, "PEI0147_BL002_FormaterReponse", _tracabilite, RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.DONNEE_INVALIDE, "DONNEE_INVALIDE", null)); //$NON-NLS-1$ //$NON-NLS-2$

    assertEquals(responseErreurExpected, reponseBL002);
  }

  /**
   * <b>Scenario:</b> Tests case with a Retour KO CAT-4 MAIL_INCONNU <br>
   * <b>Input:</b> Retour {KO; CAT-4; MAIL_INCONNU; "Attribut(s) obligatoire(s) manquant(s): [_identifiantAcces]"}<br>
   * <b>Result:</b> ReponseErreur : Error{MAIL_INCONNU}, ErrorDescription{"Attribut(s) obligatoire(s) manquant(s):
   * [_identifiantAcces]"}}
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PEI0147_BL002_FormaterReponse_Test_04() throws Exception
  {

    ReponseErreur responseErreurExpected = new ReponseErreur();
    responseErreurExpected.setError(IMegSpiritConsts.MAIL_INCONNU);
    responseErreurExpected.setErrorDescription(MessageFormat.format(Messages.getString("PEI0147.BL002.ErrorDescription"), "Mail Principal charles.rock inconnu", IMegSpiritConsts.MAIL_INCONNU)); //$NON-NLS-1$ //$NON-NLS-2$

    ReponseErreur reponseBL002 = Whitebox.invokeMethod(_processInstance, "PEI0147_BL002_FormaterReponse", _tracabilite, RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.MAIL_INCONNU, "Mail Principal charles.rock inconnu", null)); //$NON-NLS-1$ //$NON-NLS-2$

    assertEquals(responseErreurExpected, reponseBL002);
  }

  /**
   * <b>Scenario:</b> Tests case with a Retour KO CAT-10 <br>
   * <b>Input:</b> Retour {KO; CAT-10; ERREUR_TECHNIQUE; "ERREUR_TECHNIQUE"}<br>
   * <b>Result:</b> ReponseErreur : Error{ERREUR_INTERNE}, ErrorDescription{"ERREUR_TECHNIQUE"}}
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PEI0147_BL002_FormaterReponse_Test_05() throws Exception
  {

    ReponseErreur responseErreurExpected = new ReponseErreur();
    responseErreurExpected.setError(IMegSpiritConsts.ERREUR_INTERNE);
    responseErreurExpected.setErrorDescription("ERREUR_TECHNIQUE"); //$NON-NLS-1$

    ReponseErreur reponseBL002 = Whitebox.invokeMethod(_processInstance, "PEI0147_BL002_FormaterReponse", _tracabilite, RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegConsts.ERREUR_TECHNIQUE, "ERREUR_TECHNIQUE", null)); //$NON-NLS-1$ //$NON-NLS-2$

    assertEquals(responseErreurExpected, reponseBL002);
  }

  /**
   * Appel PEI0147_BL100_SauvegarderCmd test KO
   *
   * cas ou PEI0147_BL101_PrepareCMd KO
   *
   * @throws Exception
   *           exception
   */
  @Test
  public void PEI0147_BL100_SauvegarderCmd_Test_KO_01() throws Exception
  {

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    fillAllRequestHeaders(request);
    Retour retourBL800 = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegConsts.CONFIGURATION_INVALIDE, "", null); //$NON-NLS-1$
    mockBL800(_tracabilite, "idcmd", retourBL800, _processInstance); //$NON-NLS-1$
    createMockCmd(_tracabilite, retourBL800, null);
    request.setHttpMethod("POST"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    ServiceMailGererMailSecondaireRequest mailSecondaireRequest = buildValidServiceMailGererMailSecondaireRequest();

    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(mailSecondaireRequest, ServiceMailGererMailSecondaireRequest.class);

    request.setPayload(jSonRequest);

    PowerMock.replayAll();
    Pair<Commande, Retour> bl100retour = Whitebox.invokeMethod(_processInstance, "PEI0147_BL100_SauvegarderCmd", _tracabilite, mailSecondaireRequest, "BSS_GP", "nocompte"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PowerMock.verify();

    assertEquals(bl100retour._second.getDiagnostic(), IMegConsts.CONFIGURATION_INVALIDE);
    assertEquals(bl100retour._second.getCategorie(), IMegConsts.CAT2);
    assertEquals(bl100retour._second.getLibelle(), ""); //$NON-NLS-1$
    assertEquals(bl100retour._second.getResultat(), "NOK"); //$NON-NLS-1$
    Commande commande = bl100retour._first;

    String json = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ, DateTimeFormatPattern.yyyy_dash_MM_dash_dd).toJson(mailSecondaireRequest);

    assertEquals(commande.getIdCmd(), "idcmd"); //$NON-NLS-1$
    assertEquals(commande.getStatut(), com.bytel.spirit.common.shared.saab.cmd.Statut.ACQUITTE.name());
    assertEquals(commande.getNatureCommande(), IMegSpiritConsts.GESTION_BOITE_MAIL_SECONDAIRE);
    assertEquals(commande.getIdCmd(), "idcmd"); //$NON-NLS-1$
    assertEquals(commande.getNoCompte(), "nocompte"); //$NON-NLS-1$
    assertEquals(commande.getDonneesBrut(), json);
  }

  /**
   * PEI147_BL100_SauvegarderCmd_Test_OK test PEI147_BL100_SauvegarderCmd cas nominal
   *
   * @throws Exception
   *           exception
   */
  @Test
  public void PEI0147_BL100_SauvegarderCmd_Test_OK() throws Exception
  {

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    fillAllRequestHeaders(request);

    mockBL800(_tracabilite, "idcmd", RetourFactoryForTU.createOkRetour(), _processInstance); //$NON-NLS-1$
    createMockCmd(_tracabilite, RetourFactoryForTU.createOkRetour(), null);
    request.setHttpMethod("POST"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    ServiceMailGererMailSecondaireRequest mailSecondaireRequest = buildValidServiceMailGererMailSecondaireRequest();

    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(mailSecondaireRequest, ServiceMailGererMailSecondaireRequest.class);

    request.setPayload(jSonRequest);

    PowerMock.replayAll();
    Pair<Commande, Retour> bl100retour = Whitebox.invokeMethod(_processInstance, "PEI0147_BL100_SauvegarderCmd", _tracabilite, mailSecondaireRequest, "BSS_GP", "nocompte"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PowerMock.verify();

    assertEquals(bl100retour._second.getDiagnostic(), null);
    assertEquals(bl100retour._second.getCategorie(), null);
    assertEquals(bl100retour._second.getLibelle(), null);
    assertEquals(bl100retour._second.getResultat(), "OK"); //$NON-NLS-1$
    Commande commande = bl100retour._first;

    String json = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ, DateTimeFormatPattern.yyyy_dash_MM_dash_dd).toJson(mailSecondaireRequest);

    assertEquals(commande.getIdCmd(), "idcmd"); //$NON-NLS-1$
    assertEquals(commande.getStatut(), com.bytel.spirit.common.shared.saab.cmd.Statut.ACQUITTE.name());
    assertEquals(commande.getNatureCommande(), IMegSpiritConsts.GESTION_BOITE_MAIL_SECONDAIRE);
    assertEquals(commande.getIdCmd(), "idcmd"); //$NON-NLS-1$
    assertEquals(commande.getNoCompte(), "nocompte"); //$NON-NLS-1$
    assertEquals(commande.getDonneesBrut(), json);

  }

  /**
   * PEI147_BL101_PreparerCmd_Test_OK
   *
   * @throws Exception
   *           exception
   */
  @Test
  public void PEI0147_BL101_PreparerCmd_Test_OK() throws Exception
  {

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    fillAllRequestHeaders(request);

    mockBL800(_tracabilite, "idcmd", RetourFactoryForTU.createOkRetour(), _processInstance); //$NON-NLS-1$

    request.setHttpMethod("POST"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    ServiceMailGererMailSecondaireRequest mailSecondaireRequest = buildValidServiceMailGererMailSecondaireRequest();

    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(mailSecondaireRequest, ServiceMailGererMailSecondaireRequest.class);

    request.setPayload(jSonRequest);

    PowerMock.replayAll();
    Pair<Commande, Retour> bl101retour = Whitebox.invokeMethod(_processInstance, "PEI0147_BL101_PreparerCmd", _tracabilite, mailSecondaireRequest, "BSS_GP", "nocompte"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PowerMock.verify();
    assertEquals(bl101retour._second.getDiagnostic(), null);
    assertEquals(bl101retour._second.getCategorie(), null);
    assertEquals(bl101retour._second.getLibelle(), null);
    assertEquals(bl101retour._second.getResultat(), "OK"); //$NON-NLS-1$
    Commande commande = bl101retour._first;

    String json = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ, DateTimeFormatPattern.yyyy_dash_MM_dash_dd).toJson(mailSecondaireRequest);

    assertEquals(commande.getIdCmd(), "idcmd"); //$NON-NLS-1$
    assertEquals(commande.getStatut(), com.bytel.spirit.common.shared.saab.cmd.Statut.ACQUITTE.name());
    assertEquals(commande.getNatureCommande(), IMegSpiritConsts.GESTION_BOITE_MAIL_SECONDAIRE);
    assertEquals(commande.getIdCmd(), "idcmd"); //$NON-NLS-1$
    assertEquals(commande.getNoCompte(), "nocompte"); //$NON-NLS-1$
    assertEquals(commande.getDonneesBrut(), json);
  }

  /**
   * <b>Scenario:</b> Tests when PEI0147_SI001 is KO<br>
   * <b>Input:</b> PEI0147_SI001 mock KO<br>
   * <b>Result:</b> Retour KO , CAT-1, ERREUR_TECHNIQUE, """}} | after continueProcess: {OK}
   *
   * @throws Exception
   *           on errors
   */
  @Test
  public void PEI0147_KO_01() throws Exception
  {
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    fillAllRequestHeaders(request);

    request.setHttpMethod("POST"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    ServiceMailGererMailSecondaireRequest mailSecondaireRequest = buildValidServiceMailGererMailSecondaireRequest();
    mailSecondaireRequest.getMailSecondaire().setStatut(Statut.RESILIE.name());
    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(mailSecondaireRequest, ServiceMailGererMailSecondaireRequest.class);

    request.setPayload(jSonRequest);

    _tracabilite.setIdCorrelationByTel("125667889000877"); //$NON-NLS-1$

    /*--------------------- BL001 ---------------------*/
    //MOCK BL3700
    Retour retourOK = RetourFactoryForTU.createOkRetour();
    String clientOperateur = "BSS_GP"; //$NON-NLS-1$
    String noCompte = "123456789"; //$NON-NLS-1$

    mockBL3700(_tracabilite, mailSecondaireRequest, _processInstance, clientOperateur, noCompte, retourOK);

    //MOCK RPGProxy
    PFI pfi = new PFI();
    List<PA> listpa = new ArrayList<>();
    PaTypeCompteAcces paType = new PaTypeCompteAcces("charles.rock"); //$NON-NLS-1$
    PA pa = new PA(null, "COMPTE_ACCES", com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, null, null); //$NON-NLS-1$
    pa.setPaTypeCompteAcces(paType);
    listpa.add(pa);
    pfi.setPa(listpa);

    createMockRPG(_tracabilite, retourOK, pfi, clientOperateur, noCompte);

    /*--------------------- BL100 ---------------------*/
    Map<String, String> refFonc = new HashMap<String, String>();
    refFonc.put(IRefFoncConstants.CLI_OPE, clientOperateur);
    refFonc.put(IRefFoncConstants.NO_COMPTE, noCompte);

    //At this point tracabilite has new refFonc
    Tracabilite tracabilite = new Tracabilite(_tracabilite.getIdCorrelationByTel(), _tracabilite.getIdCorrelationSpirit(), _tracabilite.getNomSysteme(), _tracabilite.getNomProcessus(), _tracabilite.getIdProcessusSpirit(), refFonc);
    String idCmd = "idcmd";//$NON-NLS-1$
    mockBL800(tracabilite, idCmd, RetourFactoryForTU.createOkRetour(), _processInstance);
    createMockCmd(tracabilite, retourOK, null);

    /*--------------------- Response ---------------------*/
    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    final Response expected = new Response(ErrorCode.OK_00204, response);

    /*--------------------- continueProcess ---------------------*/
    /*--------------------- PEI0147_SI001 ---------------------*/
    List<String> listsequence = new ArrayList<String>();
    String sequence = clientOperateur + noCompte;
    listsequence.add(sequence);
    Retour retourProvSI001KO = RetourFactoryForTU.createNOK(IMegConsts.CAT1, IMegConsts.ERREUR_TECHNIQUE, StringConstants.EMPTY_STRING, null);
    mockPROV_SI001(tracabilite, retourProvSI001KO, _processInstance, listsequence, 10, IMegSpiritConsts.CONTINUER_PROCESSUS, PEP0147_GERERMAILSECONDAIRE, Arrays.asList(IRefFoncConstants.ID_CMD), Arrays.asList(idCmd));

    Retour retourBL005 = RetourFactoryForTU.createOkRetour();
    ConnectorResponse<Retour, Nothing> resultRex = new ConnectorResponse<Retour, Nothing>(retourBL005, null);
    // Used in BL005
    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxy);
    EasyMock.expect(_rexProxy.erreurSpiritCreer(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(CreateErreurSpiritRequest.class))).andReturn(resultRex);

    PowerMock.expectNew(BL800_ObtenirSequenceBuilder.class).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.code(UniqueIdConstant.ID_ERREUR_SPIRIT)).andReturn(_bl800BuilderMock);

    EasyMock.expect(_bl800BuilderMock.build()).andReturn(_bl800Mock);
    EasyMock.expect(_bl800Mock.execute(_processInstance)).andReturn("cf618db2-ed88-4556-bb0a-3a5c111087a0"); //$NON-NLS-1$
    EasyMock.expect(_bl800Mock.getRetour()).andReturn(RetourFactoryForTU.createOkRetour());

    // Mock configuration ProcessusManager
    HashMap<String, String> map = new HashMap<String, String>();
    map.put("declenchementPEP", "true"); //$NON-NLS-1$ //$NON-NLS-2$
    ProcessManager.getInstance().getProcessParams().put(StringConstants.EMPTY_STRING, map);

    try
    {
      PowerMock.replayAll();
      _processInstance.run(request);
      _processInstance.continueProcess(request, tracabilite);
      PowerMock.verifyAll();
    }
    catch (Throwable exception)
    {
      fail("Should not append : " + exception.getMessage()); //$NON-NLS-1$
    }

    assertEquals(expected.getMarshalledResponse(), request.getResponse().getMarshalledResponse());
    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());
    assertEquals(retourProvSI001KO, _processInstance.getRetour());
  }

  /**
   * <b>Scenario:</b> Nominal case for PEI0147<br>
   * <b>Input:</b> OSSFAI_SI009 return KO -1 <b>Result:</b> Retour OK"}}
   *
   * @throws Exception
   *           on errors
   */
  @Test
  public void PEI0147_KO_02() throws Exception
  {
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    fillAllRequestHeaders(request);

    request.setHttpMethod("POST"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    ServiceMailGererMailSecondaireRequest mailSecondaireRequest = buildValidServiceMailGererMailSecondaireRequest();
    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(mailSecondaireRequest, ServiceMailGererMailSecondaireRequest.class);

    request.setPayload(jSonRequest);

    _tracabilite.setIdCorrelationByTel("125667889000877"); //$NON-NLS-1$

    //Mock Reftech OSSFAI_SI009
    mockReftechConnector(new ReftechRetour(-1, "ERROR Reftech"), mailSecondaireRequest.getMailSecondaire().getMail()); //$NON-NLS-1$
    Retour processRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.DONNEE_EXISTANTE, "ERROR Reftech", "OSSFAI_SI009_ReserveAdresseMailSecondaire"); //$NON-NLS-1$ //$NON-NLS-2$

    /*--------------------- BL001 ---------------------*/
    //MOCK BL3700
    Retour retourOK = RetourFactoryForTU.createOkRetour();
    String clientOperateur = "BSS_GP"; //$NON-NLS-1$
    String noCompte = "123456789"; //$NON-NLS-1$

    mockBL3700(_tracabilite, mailSecondaireRequest, _processInstance, clientOperateur, noCompte, retourOK);

    //MOCK RPGProxy
    PFI pfi = new PFI();
    List<PA> listpa = new ArrayList<>();
    PaTypeCompteAcces paType = new PaTypeCompteAcces("charles.rock"); //$NON-NLS-1$
    PA pa = new PA(null, "COMPTE_ACCES", com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, null, null); //$NON-NLS-1$
    pa.setPaTypeCompteAcces(paType);
    listpa.add(pa);
    pfi.setPa(listpa);

    List<SA> listSA = new ArrayList<>();
    SA sa = new SA();
    sa.setNomServiceCommercial("MAIL"); //$NON-NLS-1$
    sa.setStatut(com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF);
    listSA.add(sa);
    pfi.setSa(listSA);

    createMockRPG(_tracabilite, retourOK, pfi, clientOperateur, noCompte);

    /*--------------------- BL100 ---------------------*/
    Map<String, String> refFonc = new HashMap<String, String>();
    refFonc.put(IRefFoncConstants.CLI_OPE, clientOperateur);
    refFonc.put(IRefFoncConstants.NO_COMPTE, noCompte);

    /*--------------------- Response ---------------------*/
    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);

    ReponseErreur responseErreurExpected = new ReponseErreur();
    responseErreurExpected.setError(IMegSpiritConsts.MAIL_SECONDAIRE_DEJA_UTILISE);
    responseErreurExpected.setErrorDescription("ERROR Reftech ;Diagnostic= " + IMegSpiritConsts.DONNEE_EXISTANTE); //$NON-NLS-1$
    response.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(responseErreurExpected));
    final Response expected = new Response(ErrorCode.KO_00404, response);

    try
    {
      PowerMock.replayAll();
      _processInstance.run(request);
      PowerMock.verifyAll();
    }
    catch (Throwable exception)
    {
      fail("Should not append : " + exception.getMessage()); //$NON-NLS-1$
    }

    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());
    assertEquals(expected.getMarshalledResponseJson(), request.getResponse().getMarshalledResponseJson());
    assertEquals(processRetour.getResultat(), _processInstance.getRetour().getResultat());
    assertEquals(processRetour.getDiagnostic(), _processInstance.getRetour().getDiagnostic());
    assertEquals(processRetour.getLibelle(), _processInstance.getRetour().getLibelle());
  }

  /**
   * <b>Scenario:</b> Nomainal case for PEI0147<br>
   * <b>Input:</b> All valid inputs and declenchementPEP is false (not set)<br>
   * <b>Result:</b> Retour OK"}}
   *
   * @throws Exception
   *           on errors
   */
  @Test
  public void PEI0147_OK_01() throws Exception
  {
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    fillAllRequestHeaders(request);

    request.setHttpMethod("POST"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    ServiceMailGererMailSecondaireRequest mailSecondaireRequest = buildValidServiceMailGererMailSecondaireRequest();
    mailSecondaireRequest.getMailSecondaire().setStatut(Statut.RESILIE.name());
    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(mailSecondaireRequest, ServiceMailGererMailSecondaireRequest.class);

    request.setPayload(jSonRequest);

    _tracabilite.setIdCorrelationByTel("125667889000877"); //$NON-NLS-1$

    /*--------------------- BL001 ---------------------*/
    //MOCK BL3700
    Retour retourOK = RetourFactoryForTU.createOkRetour();
    String clientOperateur = "BSS_GP"; //$NON-NLS-1$
    String noCompte = "123456789"; //$NON-NLS-1$

    mockBL3700(_tracabilite, mailSecondaireRequest, _processInstance, clientOperateur, noCompte, retourOK);

    //MOCK RPGProxy
    PFI pfi = new PFI();
    List<PA> listpa = new ArrayList<>();
    PaTypeCompteAcces paType = new PaTypeCompteAcces("charles.rock"); //$NON-NLS-1$
    PA pa = new PA(null, "COMPTE_ACCES", com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, null, null); //$NON-NLS-1$
    pa.setPaTypeCompteAcces(paType);
    listpa.add(pa);
    pfi.setPa(listpa);

    createMockRPG(_tracabilite, retourOK, pfi, clientOperateur, noCompte);

    /*--------------------- BL100 ---------------------*/
    Map<String, String> refFonc = new HashMap<String, String>();
    refFonc.put(IRefFoncConstants.CLI_OPE, clientOperateur);
    refFonc.put(IRefFoncConstants.NO_COMPTE, noCompte);

    //At this point tracabilite has new refFonc
    Tracabilite tracabilite = new Tracabilite(_tracabilite.getIdCorrelationByTel(), _tracabilite.getIdCorrelationSpirit(), _tracabilite.getNomSysteme(), _tracabilite.getNomProcessus(), _tracabilite.getIdProcessusSpirit(), refFonc);
    mockBL800(tracabilite, "idcmd", RetourFactoryForTU.createOkRetour(), _processInstance); //$NON-NLS-1$
    createMockCmd(tracabilite, retourOK, null);

    /*--------------------- Response ---------------------*/
    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);

    final Response expected = new Response(ErrorCode.OK_00204, response);

    try
    {
      PowerMock.replayAll();
      _processInstance.run(request);
      _processInstance.continueProcess(request, tracabilite);
      PowerMock.verifyAll();
    }
    catch (Throwable exception)
    {
      fail("Should not append : " + exception.getMessage()); //$NON-NLS-1$
    }

    assertEquals(expected.getMarshalledResponseJson(), request.getResponse().getMarshalledResponseJson());
    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());
    assertEquals(retourOK, _processInstance.getRetour());

  }

  /**
   * <b>Scenario:</b> Nominal case for PEI0147<br>
   * <b>Input:</b> All valid inputs and declenchementPEP true<br>
   * <b>Result:</b> Retour OK"}}
   *
   * @throws Exception
   *           on errors
   */
  @Test
  public void PEI0147_OK_02() throws Exception
  {
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    fillAllRequestHeaders(request);

    request.setHttpMethod("POST"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    ServiceMailGererMailSecondaireRequest mailSecondaireRequest = buildValidServiceMailGererMailSecondaireRequest();
    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(mailSecondaireRequest, ServiceMailGererMailSecondaireRequest.class);

    request.setPayload(jSonRequest);

    _tracabilite.setIdCorrelationByTel("125667889000877"); //$NON-NLS-1$

    //Mock Reftech OSSFAI_SI009
    mockReftechConnector(new ReftechRetour(1, null), mailSecondaireRequest.getMailSecondaire().getMail());

    /*--------------------- BL001 ---------------------*/
    //MOCK BL3700
    Retour retourOK = RetourFactoryForTU.createOkRetour();
    String clientOperateur = "BSS_GP"; //$NON-NLS-1$
    String noCompte = "123456789"; //$NON-NLS-1$

    mockBL3700(_tracabilite, mailSecondaireRequest, _processInstance, clientOperateur, noCompte, retourOK);

    //MOCK RPGProxy
    PFI pfi = new PFI();
    List<PA> listpa = new ArrayList<>();
    PaTypeCompteAcces paType = new PaTypeCompteAcces("charles.rock"); //$NON-NLS-1$
    PA pa = new PA(null, "COMPTE_ACCES", com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, null, null); //$NON-NLS-1$
    pa.setPaTypeCompteAcces(paType);
    listpa.add(pa);
    pfi.setPa(listpa);

    List<SA> listSA = new ArrayList<>();
    SA sa = new SA();
    sa.setNomServiceCommercial("MAIL"); //$NON-NLS-1$
    sa.setStatut(com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF);
    listSA.add(sa);
    pfi.setSa(listSA);

    createMockRPG(_tracabilite, retourOK, pfi, clientOperateur, noCompte);

    /*--------------------- BL100 ---------------------*/
    Map<String, String> refFonc = new HashMap<String, String>();
    refFonc.put(IRefFoncConstants.CLI_OPE, clientOperateur);
    refFonc.put(IRefFoncConstants.NO_COMPTE, noCompte);

    //At this point tracabilite has new refFonc
    Tracabilite tracabilite = new Tracabilite(_tracabilite.getIdCorrelationByTel(), _tracabilite.getIdCorrelationSpirit(), _tracabilite.getNomSysteme(), _tracabilite.getNomProcessus(), _tracabilite.getIdProcessusSpirit(), refFonc);
    String idCmd = "idcmd"; //$NON-NLS-1$
    mockBL800(tracabilite, idCmd, RetourFactoryForTU.createOkRetour(), _processInstance);
    createMockCmd(tracabilite, retourOK, null);

    /*--------------------- Response ---------------------*/
    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    final Response expected = new Response(ErrorCode.OK_00204, response);

    /*--------------------- continueProcess ---------------------*/
    /*--------------------- PEI0147_SI001 ---------------------*/
    List<String> listsequence = new ArrayList<String>();
    String sequence = clientOperateur + noCompte;
    listsequence.add(sequence);
    mockPROV_SI001(tracabilite, retourOK, _processInstance, listsequence, 10, IMegSpiritConsts.CONTINUER_PROCESSUS, PEP0147_GERERMAILSECONDAIRE, Arrays.asList(IRefFoncConstants.ID_CMD), Arrays.asList(idCmd));

    // Mock configuration ProcessusManager
    HashMap<String, String> map = new HashMap<String, String>();
    map.put("declenchementPEP", "true"); //$NON-NLS-1$ //$NON-NLS-2$
    ProcessManager.getInstance().getProcessParams().put(StringConstants.EMPTY_STRING, map);

    try
    {
      PowerMock.replayAll();
      _processInstance.run(request);
      _processInstance.continueProcess(request, tracabilite);
      PowerMock.verifyAll();
    }
    catch (Throwable exception)
    {
      fail("Should not append : " + exception.getMessage()); //$NON-NLS-1$
    }

    assertEquals(expected.getMarshalledResponseJson(), request.getResponse().getMarshalledResponseJson());
    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());
    assertEquals(retourOK, _processInstance.getRetour());

  }

  /**
   * <b>Scenario:</b> Tests startProcess with required header X-Client-Operateur not set.<br>
   * <b>Input:</b> "X-Client-Operateur" not set in headers<br>
   * <b>Result:</b><br>
   * <ul>
   * <li>Retour : {KO, CAT-3, NON_RESPECT_STI, Header X-Client-Operateur null ou vide.,
   * PEI0147_BL001_VerifierDonnees}</li>
   * <li>Request Response : Error{NON_RESPECT_STI}, ErrorDescription{"Header X-Client-Operateur null ou
   * vide.;Diagnostic: NON_RESPECT_STI"}}</li>
   * </ul>
   *
   * @throws RavelException
   *           on errors
   */
  @Test
  public void PEI0147_startProcess_BL001_KO_01() throws RavelException
  {
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "GESTION MAIL SECONDAIRE"); //$NON-NLS-1$
    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "DOMINGO"); //$NON-NLS-1$
    RequestHeader xMessageId = createHeader(IHttpHeadersConsts.X_MESSAGE_ID, "msgID123"); //$NON-NLS-1$

    fillRequestHeaders(request, xRequestId, xProcess, xSource, xMessageId);

    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString("PEI0147.BL001.HeaderNullOrEmpty"), IHttpHeadersConsts.X_CLIENT_OPERATEUR), PEI0147_BL001_VERIFIER_DONNEES); //$NON-NLS-1$
    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    ReponseErreur responserreur = new ReponseErreur();
    responserreur.setError(IMegSpiritConsts.NON_RESPECT_STI);
    responserreur.setErrorDescription(MessageFormat.format(Messages.getString("PEI0147.BL002.ErrorDescription"), expectedRetour.getLibelle(), expectedRetour.getDiagnostic())); //$NON-NLS-1$
    response.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(responserreur));

    final Response expected = new Response(ErrorCode.KO_00400, response);

    try
    {
      PowerMock.replayAll();
      _processInstance.run(request);
      PowerMock.verifyAll();
    }
    catch (Throwable exception)
    {
      fail("Should not append : " + exception.getMessage()); //$NON-NLS-1$
    }

    assertEquals(expected.getMarshalledResponseJson(), request.getResponse().getMarshalledResponseJson());
    assertEquals(expectedRetour, _processInstance.getRetour());
  }

  /**
   * <b>Scenario:</b> Tests startProcess with required header X-Source not set.<br>
   * <b>Input:</b> "X-Source" not set in headers<br>
   * <b>Result:</b><br>
   * <ul>
   * <li>Retour : {KO, CAT-3, NON_RESPECT_STI, Header X-Source null ou vide., PEI0147_BL001_VerifierDonnees}</li>
   * <li>Request Response : Error{NON_RESPECT_STI}, ErrorDescription{"Header X-Source null ou vide.;Diagnostic:
   * NON_RESPECT_STI"}}</li>
   * </ul>
   *
   * @throws RavelException
   *           on errors
   */
  @Test
  public void PEI0147_startProcess_BL001_KO_02() throws RavelException
  {
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xClientOperateur = createHeader(IHttpHeadersConsts.X_CLIENT_OPERATEUR, "BSS_GP"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "GESTION MAIL SECONDAIRE"); //$NON-NLS-1$
    RequestHeader xMessageId = createHeader(IHttpHeadersConsts.X_MESSAGE_ID, "msgID123"); //$NON-NLS-1$

    fillRequestHeaders(request, xClientOperateur, xRequestId, xProcess, xMessageId);

    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString("PEI0147.BL001.HeaderNullOrEmpty"), IHttpHeadersConsts.X_SOURCE), PEI0147_BL001_VERIFIER_DONNEES); //$NON-NLS-1$
    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    ReponseErreur responserreur = new ReponseErreur();
    responserreur.setError(IMegSpiritConsts.NON_RESPECT_STI);
    responserreur.setErrorDescription(MessageFormat.format(Messages.getString("PEI0147.BL002.ErrorDescription"), expectedRetour.getLibelle(), expectedRetour.getDiagnostic())); //$NON-NLS-1$
    response.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(responserreur));

    final Response expected = new Response(ErrorCode.KO_00400, response);

    try
    {
      PowerMock.replayAll();
      _processInstance.run(request);
      PowerMock.verifyAll();
    }
    catch (Throwable exception)
    {
      fail("Should not append : " + exception.getMessage()); //$NON-NLS-1$
    }

    assertEquals(expected.getMarshalledResponseJson(), request.getResponse().getMarshalledResponseJson());
    assertEquals(expectedRetour, _processInstance.getRetour());
  }

  /**
   * <b>Scenario:</b> Tests startProcess with required header X-Request-Id not set.<br>
   * <b>Input:</b> "X-Request-Id" not set in headers<br>
   * <b>Result:</b><br>
   * <ul>
   * <li>Retour : {KO, CAT-3, NON_RESPECT_STI, Header X-Request-Id null ou vide., PEI0147_BL001_VerifierDonnees}</li>
   * <li>Request Response : Error{NON_RESPECT_STI}, ErrorDescription{"Header X-Request-Id null ou vide.;Diagnostic:
   * NON_RESPECT_STI"}}</li>
   * </ul>
   *
   * @throws RavelException
   *           on errors
   */
  @Test
  public void PEI0147_startProcess_BL001_KO_03() throws RavelException
  {
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xClientOperateur = createHeader(IHttpHeadersConsts.X_CLIENT_OPERATEUR, "BSS_GP"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "GESTION MAIL SECONDAIRE"); //$NON-NLS-1$
    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "DOMINGO"); //$NON-NLS-1$
    RequestHeader xMessageId = createHeader(IHttpHeadersConsts.X_MESSAGE_ID, "msgID123"); //$NON-NLS-1$

    fillRequestHeaders(request, xClientOperateur, xProcess, xSource, xMessageId);

    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString("PEI0147.BL001.HeaderNullOrEmpty"), IHttpHeadersConsts.X_REQUEST_ID), PEI0147_BL001_VERIFIER_DONNEES); //$NON-NLS-1$
    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    ReponseErreur responserreur = new ReponseErreur();
    responserreur.setError(IMegSpiritConsts.NON_RESPECT_STI);
    responserreur.setErrorDescription(MessageFormat.format(Messages.getString("PEI0147.BL002.ErrorDescription"), expectedRetour.getLibelle(), expectedRetour.getDiagnostic())); //$NON-NLS-1$
    response.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(responserreur));

    final Response expected = new Response(ErrorCode.OK_00200, response);

    try
    {
      PowerMock.replayAll();
      _processInstance.run(request);
      PowerMock.verifyAll();
    }
    catch (Throwable exception)
    {
      fail("Should not append : " + exception.getMessage()); //$NON-NLS-1$
    }

    assertEquals(expected.getMarshalledResponseJson(), request.getResponse().getMarshalledResponseJson());
    assertEquals(expectedRetour, _processInstance.getRetour());
  }

  /**
   * <b>Scenario:</b> Tests startProcess with required header X-Process not set.<br>
   * <b>Input:</b> "X-Process" not set in headers<br>
   * <b>Result:</b><br>
   * <ul>
   * <li>Retour : {KO, CAT-3, NON_RESPECT_STI, Header X-Process null ou vide., PEI0147_BL001_VerifierDonnees}</li>
   * <li>Request Response : Error{NON_RESPECT_STI}, ErrorDescription{"Header X-Process null ou vide.;Diagnostic:
   * NON_RESPECT_STI"}}</li>
   * </ul>
   *
   * @throws RavelException
   *           on errors
   */
  @Test
  public void PEI0147_startProcess_BL001_KO_04() throws RavelException
  {
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xClientOperateur = createHeader(IHttpHeadersConsts.X_CLIENT_OPERATEUR, "BSS_GP"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "DOMINGO"); //$NON-NLS-1$
    RequestHeader xMessageId = createHeader(IHttpHeadersConsts.X_MESSAGE_ID, "msgID123"); //$NON-NLS-1$

    fillRequestHeaders(request, xClientOperateur, xRequestId, xSource, xMessageId);

    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString("PEI0147.BL001.HeaderNullOrEmpty"), IHttpHeadersConsts.X_PROCESS), PEI0147_BL001_VERIFIER_DONNEES); //$NON-NLS-1$
    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    ReponseErreur responserreur = new ReponseErreur();
    responserreur.setError(IMegSpiritConsts.NON_RESPECT_STI);
    responserreur.setErrorDescription(MessageFormat.format(Messages.getString("PEI0147.BL002.ErrorDescription"), expectedRetour.getLibelle(), expectedRetour.getDiagnostic())); //$NON-NLS-1$
    response.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(responserreur));

    final Response expected = new Response(ErrorCode.OK_00200, response);

    try
    {
      PowerMock.replayAll();
      _processInstance.run(request);
      PowerMock.verifyAll();
    }
    catch (Throwable exception)
    {
      fail("Should not append : " + exception.getMessage()); //$NON-NLS-1$
    }

    assertEquals(expected.getMarshalledResponseJson(), request.getResponse().getMarshalledResponseJson());
    assertEquals(expectedRetour, _processInstance.getRetour());

  }

  /**
   * <b>Scenario:</b> Tests startProcess with required field identifiantAcces not set.<br>
   * <b>Input:</b> "identifiantAcces" not set in the request<br>
   * <b>Result:</b><br>
   * <ul>
   * <li>Retour : {KO, CAT-3, NON_RESPECT_STI, Attribut(s) obligatoire(s) manquant(s): [_identifiantAcces],
   * PEI0147_BL001_VerifierDonnees</li>
   * <li>Request Response : Error{NON_RESPECT_STI}, ErrorDescription{"Attribut(s) obligatoire(s) manquant(s):
   * [_identifiantAcces]"}}</li>
   * </ul>
   *
   * @throws RavelException
   *           on errors
   */
  @Test
  public void PEI0147_startProcess_BL001_KO_05() throws RavelException
  {
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    fillAllRequestHeaders(request);

    request.setHttpMethod("POST"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    ServiceMailGererMailSecondaireRequest mailSecondaireRequest = buildValidServiceMailGererMailSecondaireRequest();
    mailSecondaireRequest.setIdentifiantAcces(null);//cause validation error
    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(mailSecondaireRequest, ServiceMailGererMailSecondaireRequest.class);

    request.setPayload(jSonRequest);

    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, "Attribut(s) obligatoire(s) manquant(s): [_identifiantAcces]", PEI0147_BL001_VERIFIER_DONNEES); //$NON-NLS-1$
    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    ReponseErreur responserreur = new ReponseErreur();
    responserreur.setError(IMegSpiritConsts.NON_RESPECT_STI);
    responserreur.setErrorDescription(MessageFormat.format(Messages.getString("PEI0147.BL002.ErrorDescription"), expectedRetour.getLibelle(), expectedRetour.getDiagnostic())); //$NON-NLS-1$
    response.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(responserreur));

    final Response expected = new Response(ErrorCode.OK_00200, response);

    try
    {
      PowerMock.replayAll();
      _processInstance.run(request);
      PowerMock.verifyAll();
    }
    catch (Throwable exception)
    {
      fail("Should not append : " + exception.getMessage()); //$NON-NLS-1$
    }

    assertEquals(expected.getMarshalledResponseJson(), request.getResponse().getMarshalledResponseJson());
    assertEquals(expectedRetour, _processInstance.getRetour());

  }

  /**
   * <b>Scenario:</b> Tests startProcess with required field mailSecondaire not set.<br>
   * <b>Input:</b> "mailSecondaire" not set in the request<br>
   * <b>Result:</b><br>
   * <ul>
   * <li>Retour : {KO, CAT-3, NON_RESPECT_STI, Attribut(s) obligatoire(s) manquant(s): [_mailSecondaire],
   * PEI0147_BL001_VerifierDonnees</li>
   * <li>Request Response : Error{NON_RESPECT_STI}, ErrorDescription{"Attribut(s) obligatoire(s) manquant(s):
   * [_mailSecondaire]"}}</li>
   * </ul>
   *
   * @throws RavelException
   *           on errors
   */
  @Test
  public void PEI0147_startProcess_BL001_KO_06() throws RavelException
  {
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    fillAllRequestHeaders(request);

    request.setHttpMethod("POST"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    ServiceMailGererMailSecondaireRequest mailSecondaireRequest = buildValidServiceMailGererMailSecondaireRequest();
    mailSecondaireRequest.setMailSecondaire(null); // cause validation error
    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(mailSecondaireRequest, ServiceMailGererMailSecondaireRequest.class);

    request.setPayload(jSonRequest);

    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, "Attribut(s) obligatoire(s) manquant(s): [_mailSecondaire]", PEI0147_BL001_VERIFIER_DONNEES); //$NON-NLS-1$
    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    ReponseErreur responserreur = new ReponseErreur();
    responserreur.setError(IMegSpiritConsts.NON_RESPECT_STI);
    responserreur.setErrorDescription(MessageFormat.format(Messages.getString("PEI0147.BL002.ErrorDescription"), expectedRetour.getLibelle(), expectedRetour.getDiagnostic())); //$NON-NLS-1$
    response.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(responserreur));

    final Response expected = new Response(ErrorCode.OK_00200, response);

    try
    {
      PowerMock.replayAll();
      _processInstance.run(request);
      PowerMock.verifyAll();
    }
    catch (Throwable exception)
    {
      fail("Should not append : " + exception.getMessage()); //$NON-NLS-1$
    }

    assertEquals(expected.getMarshalledResponseJson(), request.getResponse().getMarshalledResponseJson());
    assertEquals(expectedRetour, _processInstance.getRetour());

  }

  /**
   * <b>Scenario:</b> Tests startProcess with required fields identifiantAcces and mailSecondaire not set.<br>
   * <b>Input:</b> "identifiantAcces" and "mailSecondaire" not set in the request<br>
   * <b>Result:</b><br>
   * <ul>
   * <li>Retour : {KO, CAT-3, NON_RESPECT_STI, Attribut(s) obligatoire(s)
   * manquant(s):[_identifiantAcces][_mailSecondaire], PEI0147_BL001_VerifierDonnees</li>
   * <li>Request Response : Error{NON_RESPECT_STI}, ErrorDescription{"Attribut(s) obligatoire(s) manquant(s):
   * [_identifiantAcces][_mailSecondaire]"}}</li>
   * </ul>
   *
   * @throws RavelException
   *           on errors
   */
  //  @Test
  public void PEI0147_startProcess_BL001_KO_07() throws RavelException
  {
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    fillAllRequestHeaders(request);

    request.setHttpMethod("POST"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    ServiceMailGererMailSecondaireRequest mailSecondaireRequest = new ServiceMailGererMailSecondaireRequest();
    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(mailSecondaireRequest, ServiceMailGererMailSecondaireRequest.class);

    request.setPayload(jSonRequest);

    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, "Attribut(s) obligatoire(s) manquant(s): [_identifiantAcces][_mailSecondaire]", PEI0147_BL001_VERIFIER_DONNEES); //$NON-NLS-1$
    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    ReponseErreur responserreur = new ReponseErreur();
    responserreur.setError(IMegSpiritConsts.NON_RESPECT_STI);
    responserreur.setErrorDescription(MessageFormat.format(Messages.getString("PEI0147.BL002.ErrorDescription"), expectedRetour.getLibelle(), expectedRetour.getDiagnostic())); //$NON-NLS-1$
    response.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(responserreur));

    final Response expected = new Response(ErrorCode.OK_00200, response);

    try
    {
      PowerMock.replayAll();
      _processInstance.run(request);
      PowerMock.verifyAll();
    }
    catch (Throwable exception)
    {
      fail("Should not append : " + exception.getMessage()); //$NON-NLS-1$
    }

    assertEquals(expected.getMarshalledResponseJson(), request.getResponse().getMarshalledResponseJson());
    assertEquals(expectedRetour, _processInstance.getRetour());

  }

  /**
   * <b>Scenario:</b> Tests startProcess when BL3700 returns KO<br>
   * <b>Input:</b> BL3700 mock KO<br>
   * <b>Result:</b><br>
   * <ul>
   * <li>Retour : {KO, CAT-4, MAIL_INCONNU, Mail Principal charles.rock inconnu, PEI0147_BL001_VerifierDonnees}</li>
   * <li>Request Response : Error{MAIL_INCONNU}, ErrorDescription{"Mail Principal charles.rock inconnu ;Diagnostic=
   * MAIL_INCONNU"}}</li>
   * </ul>
   *
   * @throws Exception
   *           on errors
   */
  @Test
  public void PEI0147_startProcess_BL001_KO_08() throws Exception
  {
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    fillAllRequestHeaders(request);

    request.setHttpMethod("POST"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    ServiceMailGererMailSecondaireRequest mailSecondaireRequest = buildValidServiceMailGererMailSecondaireRequest();
    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(mailSecondaireRequest, ServiceMailGererMailSecondaireRequest.class);

    request.setPayload(jSonRequest);

    _tracabilite.setIdCorrelationByTel("125667889000877"); //$NON-NLS-1$
    Retour bl3700Retour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, StringConstants.EMPTY_STRING, null);
    mockBL3700(_tracabilite, mailSecondaireRequest, _processInstance, null, null, bl3700Retour);

    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.MAIL_INCONNU, MessageFormat.format(Messages.getString("PEI0147.BL001.MailPrincipalInconnu"), mailSecondaireRequest.getIdentifiantAcces().getLoginMail()), PEI0147_BL001_VERIFIER_DONNEES); //$NON-NLS-1$

    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    ReponseErreur responserreur = new ReponseErreur();
    responserreur.setError(IMegSpiritConsts.MAIL_INCONNU);
    responserreur.setErrorDescription(MessageFormat.format(Messages.getString("PEI0147.BL002.ErrorDescription"), expectedRetour.getLibelle(), expectedRetour.getDiagnostic())); //$NON-NLS-1$
    response.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(responserreur));

    final Response expected = new Response(ErrorCode.OK_00200, response);

    try
    {
      PowerMock.replayAll();
      _processInstance.run(request);
      PowerMock.verifyAll();
    }
    catch (Throwable exception)
    {
      fail("Should not append : " + exception.getMessage()); //$NON-NLS-1$
    }

    assertEquals(expected.getMarshalledResponseJson(), request.getResponse().getMarshalledResponseJson());
    assertEquals(expectedRetour, _processInstance.getRetour());

  }

  /**
   * <b>Scenario:</b> Tests startProcess when the access account of the access point (PA) is null<br>
   * <b>Input:</b> A PFI with no PA of type COMPTE_ACCES<br>
   * <b>Result:</b><br>
   * <ul>
   * <li>Retour : {KO, CAT-4, MAIL_INCONNU, Mail Principal charles.rock inconnu, PEI0147_BL001_VerifierDonnees}</li>
   * <li>Request Response : Error{MAIL_INCONNU}, ErrorDescription{"Mail Principal charles.rock inconnu ;Diagnostic=
   * MAIL_INCONNU"}}</li>
   * </ul>
   *
   * @throws Exception
   *           on errors
   */
  @Test
  public void PEI0147_startProcess_BL001_KO_09() throws Exception
  {
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    fillAllRequestHeaders(request);

    request.setHttpMethod("POST"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    ServiceMailGererMailSecondaireRequest mailSecondaireRequest = buildValidServiceMailGererMailSecondaireRequest();
    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(mailSecondaireRequest, ServiceMailGererMailSecondaireRequest.class);

    request.setPayload(jSonRequest);

    _tracabilite.setIdCorrelationByTel("125667889000877"); //$NON-NLS-1$
    //MOCK BL3700
    Retour bl3700Retour = RetourFactoryForTU.createOkRetour();
    String clientOperateur = "BSS_GP"; //$NON-NLS-1$
    String noCompte = "123456789"; //$NON-NLS-1$

    mockBL3700(_tracabilite, mailSecondaireRequest, _processInstance, clientOperateur, noCompte, bl3700Retour);

    //MOCK RPGProxy
    createMockRPG(_tracabilite, RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "", null), null, clientOperateur, noCompte); //$NON-NLS-1$

    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.MAIL_INCONNU, MessageFormat.format(Messages.getString("PEI0147.BL001.MailPrincipalInconnu"), mailSecondaireRequest.getIdentifiantAcces().getLoginMail()), PEI0147_BL001_VERIFIER_DONNEES); //$NON-NLS-1$

    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    ReponseErreur responserreur = new ReponseErreur();
    responserreur.setError(IMegSpiritConsts.MAIL_INCONNU);
    responserreur.setErrorDescription(MessageFormat.format(Messages.getString("PEI0147.BL002.ErrorDescription"), expectedRetour.getLibelle(), expectedRetour.getDiagnostic())); //$NON-NLS-1$
    response.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(responserreur));

    final Response expected = new Response(ErrorCode.OK_00200, response);

    try
    {
      PowerMock.replayAll();
      _processInstance.run(request);
      PowerMock.verifyAll();
    }
    catch (Throwable exception)
    {
      fail("Should not append : " + exception.getMessage()); //$NON-NLS-1$
    }

    assertEquals(expected.getMarshalledResponseJson(), request.getResponse().getMarshalledResponseJson());
    assertEquals(expectedRetour, _processInstance.getRetour());

  }

  /**
   * <b>Scenario:</b> Tests startProcess when RPGProxy returns KO<br>
   * <b>Input:</b> RPGProxy mock KO<br>
   * <b>Result:</b><br>
   * <ul>
   * <li>Retour : {KO, CAT-4, MAIL_INCONNU, Mail Principal charles.rock associé à un point d''accès inexistant ou
   * résilié, PEI0147_BL001_VerifierDonnees}</li>
   * <li>Request Response : Error{MAIL_INCONNU}, ErrorDescription{"Mail Principal charles.rock associé à un point
   * d''accès inexistant ou résilié ;Diagnostic= MAIL_INCONNU"}}</li>
   * </ul>
   *
   * @throws Exception
   *           on errors
   */
  @Test
  public void PEI0147_startProcess_BL001_KO_10() throws Exception
  {
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    fillAllRequestHeaders(request);

    request.setHttpMethod("POST"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    ServiceMailGererMailSecondaireRequest mailSecondaireRequest = buildValidServiceMailGererMailSecondaireRequest();
    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(mailSecondaireRequest, ServiceMailGererMailSecondaireRequest.class);

    request.setPayload(jSonRequest);

    _tracabilite.setIdCorrelationByTel("125667889000877"); //$NON-NLS-1$
    //MOCK BL3700
    Retour retourOK = RetourFactoryForTU.createOkRetour();
    String clientOperateur = "BSS_GP"; //$NON-NLS-1$
    String noCompte = "123456789"; //$NON-NLS-1$

    mockBL3700(_tracabilite, mailSecondaireRequest, _processInstance, clientOperateur, noCompte, retourOK);

    //MOCK RPGProxy
    createMockRPG(_tracabilite, retourOK, new PFI(), clientOperateur, noCompte);

    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.MAIL_INCONNU, MessageFormat.format(Messages.getString("PEI0147.BL001.MailInexistantOuResilie"), mailSecondaireRequest.getIdentifiantAcces().getLoginMail()), PEI0147_BL001_VERIFIER_DONNEES); //$NON-NLS-1$

    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    ReponseErreur responserreur = new ReponseErreur();
    responserreur.setError(IMegSpiritConsts.MAIL_INCONNU);
    responserreur.setErrorDescription(MessageFormat.format(Messages.getString("PEI0147.BL002.ErrorDescription"), expectedRetour.getLibelle(), expectedRetour.getDiagnostic())); //$NON-NLS-1$
    response.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(responserreur));

    final Response expected = new Response(ErrorCode.OK_00200, response);

    try
    {
      PowerMock.replayAll();
      _processInstance.run(request);
      PowerMock.verifyAll();
    }
    catch (Throwable exception)
    {
      fail("Should not append : " + exception.getMessage()); //$NON-NLS-1$
    }

    assertEquals(expected.getMarshalledResponseJson(), request.getResponse().getMarshalledResponseJson());
    assertEquals(expectedRetour, _processInstance.getRetour());

  }

  /**
   * <b>Scenario:</b> Tests startProcess when the access account of the access point (PA) is not active<br>
   * <b>Input:</b> A PFI with a PA of type COMPTE_ACCES without the status ACTIF<br>
   * <b>Result:</b><br>
   * <ul>
   * <li>Retour : {KO, CAT-4, MAIL_INCONNU, Mail Principal charles.rock associé à un point d''accès inexistant ou
   * résilié, PEI0147_BL001_VerifierDonnees}</li>
   * <li>Request Response : Error{MAIL_INCONNU}, ErrorDescription{"Mail Principal charles.rock associé à un point
   * d''accès inexistant ou résilié ;Diagnostic= MAIL_INCONNU"}}</li>
   * </ul>
   *
   * @throws Exception
   *           on errors
   */
  @Test
  public void PEI0147_startProcess_BL001_KO_11() throws Exception
  {
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    fillAllRequestHeaders(request);

    request.setHttpMethod("POST"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    ServiceMailGererMailSecondaireRequest mailSecondaireRequest = buildValidServiceMailGererMailSecondaireRequest();
    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(mailSecondaireRequest, ServiceMailGererMailSecondaireRequest.class);

    request.setPayload(jSonRequest);

    _tracabilite.setIdCorrelationByTel("125667889000877"); //$NON-NLS-1$
    //MOCK BL3700
    Retour retourOK = RetourFactoryForTU.createOkRetour();
    String clientOperateur = "BSS_GP"; //$NON-NLS-1$
    String noCompte = "123456789"; //$NON-NLS-1$

    mockBL3700(_tracabilite, mailSecondaireRequest, _processInstance, clientOperateur, noCompte, retourOK);

    //MOCK RPGProxy
    PFI pfi = new PFI();
    List<PA> listpa = new ArrayList<>();
    PaTypeCompteAcces paType = new PaTypeCompteAcces("charles.rock"); //$NON-NLS-1$
    PA pa = new PA(null, "COMPTE_ACCES", com.bytel.spirit.common.shared.saab.rpg.Statut.RESILIE, null, null); //$NON-NLS-1$
    pa.setPaTypeCompteAcces(paType);
    listpa.add(pa);
    pfi.setPa(listpa);
    createMockRPG(_tracabilite, retourOK, pfi, clientOperateur, noCompte);

    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.MAIL_INCONNU, MessageFormat.format(Messages.getString("PEI0147.BL001.MailInexistantOuResilie"), mailSecondaireRequest.getIdentifiantAcces().getLoginMail()), PEI0147_BL001_VERIFIER_DONNEES); //$NON-NLS-1$

    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    ReponseErreur responserreur = new ReponseErreur();
    responserreur.setError(IMegSpiritConsts.MAIL_INCONNU);
    responserreur.setErrorDescription(MessageFormat.format(Messages.getString("PEI0147.BL002.ErrorDescription"), expectedRetour.getLibelle(), expectedRetour.getDiagnostic())); //$NON-NLS-1$
    response.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(responserreur));

    final Response expected = new Response(ErrorCode.OK_00200, response);

    try
    {
      PowerMock.replayAll();
      _processInstance.run(request);
      PowerMock.verifyAll();
    }
    catch (Throwable exception)
    {
      fail("Should not append : " + exception.getMessage()); //$NON-NLS-1$
    }

    assertEquals(expected.getMarshalledResponseJson(), request.getResponse().getMarshalledResponseJson());
    assertEquals(expectedRetour, _processInstance.getRetour());

  }

  /**
   * <b>Scenario:</b> Tests startProcess for an activation without MAIL commercial service<br>
   * <b>Input:</b> A PFI without SA having Mail commercial service<br>
   * <b>Result:</b><br>
   * <ul>
   * <li>Retour : {KO, CAT-4, MAIL_INCONNU, Mail Principal charles.rock associé à un usage restreint,
   * PEI0147_BL001_VerifierDonnees}</li>
   * <li>Request Response : Error{MAIL_INCONNU}, ErrorDescription{"Mail Principal charles.rock associé à un usage
   * restreint ;Diagnostic= MAIL_INCONNU"}}</li>
   * </ul>
   *
   * @throws Exception
   *           on errors
   */
  @Test
  public void PEI0147_startProcess_BL001_KO_12() throws Exception
  {
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    fillAllRequestHeaders(request);

    request.setHttpMethod("POST"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    ServiceMailGererMailSecondaireRequest mailSecondaireRequest = buildValidServiceMailGererMailSecondaireRequest();
    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(mailSecondaireRequest, ServiceMailGererMailSecondaireRequest.class);

    request.setPayload(jSonRequest);

    _tracabilite.setIdCorrelationByTel("125667889000877"); //$NON-NLS-1$
    //MOCK BL3700
    Retour retourOK = RetourFactoryForTU.createOkRetour();
    String clientOperateur = "BSS_GP"; //$NON-NLS-1$
    String noCompte = "123456789"; //$NON-NLS-1$

    mockBL3700(_tracabilite, mailSecondaireRequest, _processInstance, clientOperateur, noCompte, retourOK);

    //MOCK RPGProxy
    PFI pfi = new PFI();
    List<PA> listpa = new ArrayList<>();
    PaTypeCompteAcces paType = new PaTypeCompteAcces("charles.rock"); //$NON-NLS-1$
    PA pa = new PA(null, "COMPTE_ACCES", com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, null, null); //$NON-NLS-1$
    pa.setPaTypeCompteAcces(paType);
    listpa.add(pa);
    pfi.setPa(listpa);
    createMockRPG(_tracabilite, retourOK, pfi, clientOperateur, noCompte);

    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.MAIL_INCONNU, MessageFormat.format(Messages.getString("PEI0147.BL001.MailRestreint"), mailSecondaireRequest.getIdentifiantAcces().getLoginMail()), PEI0147_BL001_VERIFIER_DONNEES); //$NON-NLS-1$

    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    ReponseErreur responserreur = new ReponseErreur();
    responserreur.setError(IMegSpiritConsts.MAIL_INCONNU);
    responserreur.setErrorDescription(MessageFormat.format(Messages.getString("PEI0147.BL002.ErrorDescription"), expectedRetour.getLibelle(), expectedRetour.getDiagnostic())); //$NON-NLS-1$
    response.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(responserreur));

    final Response expected = new Response(ErrorCode.OK_00200, response);

    try
    {
      PowerMock.replayAll();
      _processInstance.run(request);
      PowerMock.verifyAll();
    }
    catch (Throwable exception)
    {
      fail("Should not append : " + exception.getMessage()); //$NON-NLS-1$
    }

    assertEquals(expected.getMarshalledResponseJson(), request.getResponse().getMarshalledResponseJson());
    assertEquals(expectedRetour, _processInstance.getRetour());

  }

  /**
   * <b>Scenario:</b> Tests startProcess for an activation with MAIL commercial service not active<br>
   * <b>Input:</b> A PFI with SA having Mail commercial service not active<br>
   * <b>Result:</b><br>
   * <ul>
   * <li>Retour : {KO, CAT-4, MAIL_INCONNU, Mail Principal charles.rock associé à un usage restreint,
   * PEI0147_BL001_VerifierDonnees}</li>
   * <li>Request Response : Error{MAIL_INCONNU}, ErrorDescription{"Mail Principal charles.rock associé à un usage
   * restreint ;Diagnostic= MAIL_INCONNU"}}</li>
   * </ul>
   *
   * @throws Exception
   *           on errors
   */
  @Test
  public void PEI0147_startProcess_BL001_KO_13() throws Exception
  {
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    fillAllRequestHeaders(request);

    request.setHttpMethod("POST"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    ServiceMailGererMailSecondaireRequest mailSecondaireRequest = buildValidServiceMailGererMailSecondaireRequest();
    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(mailSecondaireRequest, ServiceMailGererMailSecondaireRequest.class);

    request.setPayload(jSonRequest);

    _tracabilite.setIdCorrelationByTel("125667889000877"); //$NON-NLS-1$
    //MOCK BL3700
    Retour retourOK = RetourFactoryForTU.createOkRetour();
    String clientOperateur = "BSS_GP"; //$NON-NLS-1$
    String noCompte = "123456789"; //$NON-NLS-1$

    mockBL3700(_tracabilite, mailSecondaireRequest, _processInstance, clientOperateur, noCompte, retourOK);

    //MOCK RPGProxy
    PFI pfi = new PFI();
    List<PA> listpa = new ArrayList<>();
    PaTypeCompteAcces paType = new PaTypeCompteAcces("charles.rock"); //$NON-NLS-1$
    PA pa = new PA(null, "COMPTE_ACCES", com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, null, null); //$NON-NLS-1$
    pa.setPaTypeCompteAcces(paType);
    listpa.add(pa);
    pfi.setPa(listpa);

    List<SA> listSA = new ArrayList<>();
    SA sa = new SA();
    sa.setNomServiceCommercial("MAIL"); //$NON-NLS-1$
    listSA.add(sa);
    pfi.setSa(listSA);

    createMockRPG(_tracabilite, retourOK, pfi, clientOperateur, noCompte);

    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.MAIL_INCONNU, MessageFormat.format(Messages.getString("PEI0147.BL001.MailRestreint"), mailSecondaireRequest.getIdentifiantAcces().getLoginMail()), PEI0147_BL001_VERIFIER_DONNEES); //$NON-NLS-1$

    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    ReponseErreur responserreur = new ReponseErreur();
    responserreur.setError(IMegSpiritConsts.MAIL_INCONNU);
    responserreur.setErrorDescription(MessageFormat.format(Messages.getString("PEI0147.BL002.ErrorDescription"), expectedRetour.getLibelle(), expectedRetour.getDiagnostic())); //$NON-NLS-1$
    response.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(responserreur));

    final Response expected = new Response(ErrorCode.OK_00200, response);

    try
    {
      PowerMock.replayAll();
      _processInstance.run(request);
    }
    catch (Throwable exception)
    {
      fail("Should not append : " + exception.getMessage()); //$NON-NLS-1$
    }

    assertEquals(expected.getMarshalledResponseJson(), request.getResponse().getMarshalledResponseJson());
    assertEquals(expectedRetour, _processInstance.getRetour());
  }

  /**
   * Tests startProcess with BL100 KO
   *
   * @throws Exception
   *           on errors
   */
  @Test
  public void PEI0147_startProcess_BL100_KO_01() throws Exception
  {
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    fillAllRequestHeaders(request);

    request.setHttpMethod("POST"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    ServiceMailGererMailSecondaireRequest mailSecondaireRequest = buildValidServiceMailGererMailSecondaireRequest();
    mailSecondaireRequest.getMailSecondaire().setStatut(Statut.RESILIE.name());
    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(mailSecondaireRequest, ServiceMailGererMailSecondaireRequest.class);

    request.setPayload(jSonRequest);

    _tracabilite.setIdCorrelationByTel("125667889000877"); //$NON-NLS-1$

    /*--------------------- BL001 ---------------------*/
    //MOCK BL3700
    Retour retourOK = RetourFactoryForTU.createOkRetour();
    String clientOperateur = "BSS_GP"; //$NON-NLS-1$
    String noCompte = "123456789"; //$NON-NLS-1$

    mockBL3700(_tracabilite, mailSecondaireRequest, _processInstance, clientOperateur, noCompte, retourOK);

    //MOCK RPGProxy
    PFI pfi = new PFI();
    List<PA> listpa = new ArrayList<>();
    PaTypeCompteAcces paType = new PaTypeCompteAcces("charles.rock"); //$NON-NLS-1$
    PA pa = new PA(null, "COMPTE_ACCES", com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, null, null); //$NON-NLS-1$
    pa.setPaTypeCompteAcces(paType);
    listpa.add(pa);
    pfi.setPa(listpa);

    createMockRPG(_tracabilite, retourOK, pfi, clientOperateur, noCompte);

    /*--------------------- BL100 ---------------------*/
    Retour retourBL800 = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegConsts.CONFIGURATION_INVALIDE, "CONFIGURATION_INVALIDE", null); //$NON-NLS-1$
    Map<String, String> refFonc = new HashMap<String, String>();
    refFonc.put(IRefFoncConstants.CLI_OPE, clientOperateur);
    refFonc.put(IRefFoncConstants.NO_COMPTE, noCompte);

    //At this point tracabilite has new refFonc
    Tracabilite tracabilite = new Tracabilite(_tracabilite.getIdCorrelationByTel(), _tracabilite.getIdCorrelationSpirit(), _tracabilite.getNomSysteme(), _tracabilite.getNomProcessus(), _tracabilite.getIdProcessusSpirit(), refFonc);
    mockBL800(tracabilite, "idcmd", retourBL800, _processInstance); //$NON-NLS-1$
    createMockCmd(tracabilite, retourBL800, null);

    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    ReponseErreur responserreur = new ReponseErreur();
    responserreur.setError(IMegSpiritConsts.ERREUR_INTERNE);
    responserreur.setErrorDescription(retourBL800.getLibelle());
    response.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(responserreur));

    final Response expected = new Response(ErrorCode.OK_00200, response);

    try
    {
      PowerMock.replayAll();
      _processInstance.run(request);
      PowerMock.verifyAll();
    }
    catch (Throwable exception)
    {
      fail("Should not append : " + exception.getMessage()); //$NON-NLS-1$
    }

    assertEquals(expected.getMarshalledResponseJson(), request.getResponse().getMarshalledResponseJson());
    assertEquals(retourBL800, _processInstance.getRetour());

  }

  /**
   * Initialization of tests
   *
   */
  @Before
  public void setUp()
  {
    // context initialization
    _processInstance = new PEI0147_GererMailSecondaire();
    _processInstance.initializeContext();

    _processInstance.setMessageId("MSGID123");

    _tracabilite = new Tracabilite();
    _tracabilite.setIdProcessusSpirit(_processInstance.getIdProcess());
    _tracabilite.setIdCorrelationSpirit(null);
    _tracabilite.setIdCorrelationByTel(StringConstants.EMPTY_STRING);
    _tracabilite.setNomProcessus(StringConstants.EMPTY_STRING);
    _tracabilite.setNomSysteme(System.getenv("SERVICE")); //$NON-NLS-1$

    ProcessManager.getInstance().getProcessParams().clear();
    // on réinitialise tous les mocks afin de ne pas avoir d'interférence entre les tests

    PowerMock.resetAll();
    PowerMock.mockStatic(RPGProxy.class);
    PowerMock.mockStatic(BL3700_RecupererPfiParMail.class);
    PowerMock.mockStatic(BL3700_RecupererPfiParMailBuilder.class);
    PowerMock.mockStatic(BL800_ObtenirSequence.class);
    PowerMock.mockStatic(BL800_ObtenirSequenceBuilder.class);
    PowerMock.mockStatic(CMDProxy.class);
    PowerMock.mockStatic(PROV_SI001_LancerOrchestrateur.class);
    PowerMock.mockStatic(PROV_SI001_LancerOrchestrateurBuilder.class);
    PowerMock.mockStatic(ReftechProxy.class);
    PowerMock.mockStatic(REXProxy.class);
  }

  /**
   * Builds a valid {@link ServiceMailGererMailSecondaireRequest} object
   *
   * @return {@link ServiceMailGererMailSecondaireRequest}
   */
  private ServiceMailGererMailSecondaireRequest buildValidServiceMailGererMailSecondaireRequest()
  {
    ServiceMailGererMailSecondaireRequest mailRequest = new ServiceMailGererMailSecondaireRequest();

    ServiceMailGererMailSecondaireRequest.IdentifiantAcces identifiantAcces = new ServiceMailGererMailSecondaireRequest.IdentifiantAcces();
    identifiantAcces.setLoginMail("charles.rock"); //$NON-NLS-1$
    mailRequest.setIdentifiantAcces(identifiantAcces);

    ServiceMailGererMailSecondaireRequest.MailSecondaire mailSecondaire = new MailSecondaire();
    mailSecondaire.setMail("bernard.chevallier"); //$NON-NLS-1$
    mailSecondaire.setStatut(Statut.ACTIF.name());
    mailRequest.setMailSecondaire(mailSecondaire);

    return mailRequest;
  }

  /**
   * Create a new request header
   *
   * @param name
   *          The request header name
   * @param value
   *          The request header value
   * @return the {@link RequestHeader}
   */
  private RequestHeader createHeader(String name, String value)
  {
    RequestHeader requestHeader = new RequestHeader();
    requestHeader.setName(name);
    requestHeader.setValue(value);

    return requestHeader;
  }

  /**
   * Creation du Mock Connecteur CMD
   *
   * @param tracabilite_p
   *          the tracabilite
   * @param retour
   *          retour
   * @param nothing
   *          nothing
   * @throws RavelException
   *           exception
   *
   */
  private void createMockCmd(Tracabilite tracabilite_p, Retour retour, Nothing nothing) throws RavelException
  {
    ConnectorResponse<Retour, Nothing> resultCmd = new ConnectorResponse<Retour, Nothing>(retour, nothing);
    EasyMock.expect(CMDProxy.getInstance()).andReturn(_cmdProxy);
    EasyMock.expect(_cmdProxy.commandeCreer(EasyMock.eq(tracabilite_p), EasyMock.anyObject(CreateCommandeRequest.class))).andReturn(resultCmd);
  }

  /**
   * Creation du Mock Connecteur RPG
   *
   * @param tracabilite_p
   *          tracabilite
   * @param retour_p
   *          retour
   * @param pfi_p
   *          pfi
   * @param operateur_p
   *          operateur
   * @param noCompte_p
   *          nucompte
   * @throws RavelException
   *           exception
   */
  private void createMockRPG(Tracabilite tracabilite_p, Retour retour_p, PFI pfi_p, String operateur_p, String noCompte_p) throws RavelException
  {

    ConnectorResponse<Retour, PFI> expectedResponse = new ConnectorResponse<Retour, PFI>(retour_p, pfi_p);
    EasyMock.expect(RPGProxy.getInstance()).andReturn(_rpgDatabaseProxy);
    EasyMock.expect(_rpgDatabaseProxy.pfiLireUn(tracabilite_p, operateur_p, noCompte_p)).andReturn(expectedResponse);

  }

  /**
   * Fills all the request headers
   *
   * @param request_p
   *          The request
   */
  private void fillAllRequestHeaders(Request request_p)
  {
    RequestHeader xClientOperateur = createHeader(IHttpHeadersConsts.X_CLIENT_OPERATEUR, "BSS_GP"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "DOMINGO"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "GESTION MAIL SECONDAIRE"); //$NON-NLS-1$
    RequestHeader xMessageId = createHeader(IHttpHeadersConsts.X_MESSAGE_ID, "msgID123"); //$NON-NLS-1$

    fillRequestHeaders(request_p, xClientOperateur, xRequestId, xSource, xProcess, xMessageId);
  }

  /**
   * Fills the specified request headers
   *
   * @param request_p
   *          The request
   * @param headers_p
   *          the list of headers to add
   */
  private void fillRequestHeaders(Request request_p, RequestHeader... headers_p)
  {
    request_p.getRequestHeader().addAll(Arrays.asList(headers_p));
  }

  /**
   * @param tracabilite_p
   *          the trace
   * @param mailSecondaireRequest_p
   *          the request
   * @param pei0147_p
   *          the instance of process
   * @param clientOperateur_p
   *          the clientOperateur
   * @param noCompte_p
   *          the noCompte
   * @param retour_p
   *          the retour
   * @throws Exception
   *           on errors
   */
  private void mockBL3700(Tracabilite tracabilite_p, ServiceMailGererMailSecondaireRequest mailSecondaireRequest_p, PEI0147_GererMailSecondaire pei0147_p, String clientOperateur_p, String noCompte_p, Retour retour_p) throws Exception
  {
    PowerMock.expectNew(BL3700_RecupererPfiParMailBuilder.class).andReturn(_bl3700BuilderMock);
    EasyMock.expect(_bl3700BuilderMock.tracabilite(tracabilite_p)).andReturn(_bl3700BuilderMock);
    EasyMock.expect(_bl3700BuilderMock.mail(mailSecondaireRequest_p.getIdentifiantAcces().getLoginMail())).andReturn(_bl3700BuilderMock);
    EasyMock.expect(_bl3700BuilderMock.build()).andReturn(_bl3700Mock);
    EasyMock.expect(_bl3700Mock.execute(pei0147_p)).andReturn(new BL3700_Return(clientOperateur_p, noCompte_p, null));
    EasyMock.expect(_bl3700Mock.getRetour()).andReturn(retour_p);
  }

  /**
   * mockBL800 Mock BL800
   *
   * @param tracabilite_p
   *          the tracabilite
   * @param idCmd_p
   *          idcmd
   * @param retour_p
   *          retour
   * @param pei0147_p
   *          the process instance
   * @throws Exception
   *           exception
   *
   */
  private void mockBL800(Tracabilite tracabilite_p, String idCmd_p, Retour retour_p, PEI0147_GererMailSecondaire pei0147_p) throws Exception
  {
    PowerMock.expectNew(BL800_ObtenirSequenceBuilder.class).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.code(UniqueIdConstant.ID_CMD_GP)).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.tracabilite(tracabilite_p)).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.build()).andReturn(_bl800Mock);
    EasyMock.expect(_bl800Mock.execute(pei0147_p)).andReturn(idCmd_p);
    EasyMock.expect(_bl800Mock.getRetour()).andReturn(retour_p);
  }

  /**
   * mockPROV_SI001 Mock PEI0147_SI001
   *
   * @param tracabilite_p
   *          tracabilite
   * @param retour_p
   *          retour
   * @param pei0147_p
   *          the process instance
   * @param listeCleSequencement_p
   *          listeCleSequencement
   * @param priorite_p
   *          priorite
   * @param type_p
   *          type
   * @param processus_p
   *          process instance
   * @param noms_p
   *          nom
   * @param valeurs_p
   *          valeurs
   * @throws Exception
   *           exception
   *
   */
  private void mockPROV_SI001(Tracabilite tracabilite_p, Retour retour_p, PEI0147_GererMailSecondaire pei0147_p, List<String> listeCleSequencement_p, Integer priorite_p, String type_p, String processus_p, List<String> noms_p, List<String> valeurs_p) throws Exception
  {
    PowerMock.expectNew(PROV_SI001_LancerOrchestrateurBuilder.class).andReturn(_provSI001BuilderMock);
    EasyMock.expect(_provSI001BuilderMock.tracabilite(tracabilite_p)).andReturn(_provSI001BuilderMock);
    EasyMock.expect(_provSI001BuilderMock.cles(listeCleSequencement_p)).andReturn(_provSI001BuilderMock);
    EasyMock.expect(_provSI001BuilderMock.priorite(priorite_p)).andReturn(_provSI001BuilderMock);
    EasyMock.expect(_provSI001BuilderMock.type(type_p)).andReturn(_provSI001BuilderMock);
    EasyMock.expect(_provSI001BuilderMock.processus(processus_p)).andReturn(_provSI001BuilderMock);
    EasyMock.expect(_provSI001BuilderMock.noms(noms_p)).andReturn(_provSI001BuilderMock);
    EasyMock.expect(_provSI001BuilderMock.valeurs(valeurs_p)).andReturn(_provSI001BuilderMock);
    EasyMock.expect(_provSI001BuilderMock.build()).andReturn(_provSI001Mock);
    EasyMock.expect(_provSI001Mock.execute(pei0147_p)).andReturn(null);
    EasyMock.expect(_provSI001Mock.getRetour()).andReturn(retour_p);
  }

  /**
   * Create mock of Connector Reftech
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param retour
   *          Retour
   * @param adressMail_p
   *          Adress mail
   * @throws RavelException
   *           exception
   */
  private void mockReftechConnector(ReftechRetour retour, String adressMail_p) throws RavelException
  {
    ConnectorResponse<ReftechRetour, Nothing> reftechRetour = new ConnectorResponse<>(retour, null);
    EasyMock.expect(ReftechProxy.getInstance()).andReturn(_reftechProxy);
    EasyMock.expect(_reftechProxy.reserveAdresseMailSecondaire(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(adressMail_p))).andReturn(reftechRetour);
  }

}
