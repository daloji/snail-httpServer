/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PM028;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.xml.parsers.ParserConfigurationException;

import org.easymock.EasyMock;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.xml.sax.SAXException;

import com.bouygtel.commontypes.s3g.v3.DescriptionErreur;
import com.bouygtel.commontypes.s3g.v3.EnumOKNOK;
import com.bouygtel.commontypes.s3g.v3.ReponseServicePIVOTTYPEDansFluxCRFonctionnel;
import com.bouygtel.refcli.consulterpfi.in.ConsulterPFIIn;
import com.bouygtel.refcli.consulterpfi.out.ConsulterPFIReponseType;
import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.data.exchange.generated.RavelRequest;
import com.bytel.ravel.common.data.exchange.generated.RavelRequest.RequestHeader;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.request.UrlParameters;
import com.bytel.ravel.common.utils.ACManagerUtil;
import com.bytel.ravel.common.utils.MarshallTools;
import com.bytel.ravel.common.utils.RetourFactoryForTU;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.ProcessManager;
import com.bytel.ravel.services.utils.Test_Consts;
import com.bytel.spirit.common.connectors.ink.IInkConnector;
import com.bytel.spirit.common.connectors.ink.InkProxy;
import com.bytel.spirit.common.connectors.ink.ResponseConnector;
import com.bytel.spirit.common.connectors.oam.FollowUpTable;
import com.bytel.spirit.common.connectors.oam.OAMConnector;
import com.bytel.spirit.common.connectors.oam.OAMProxy;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.ressources.Consts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.prof.connectors.generated.svccomm.TypeParametre;
import com.bytel.spirit.prof.connectors.generated.svccomm.TypeParametres;
import com.bytel.spirit.prof.connectors.generated.svccomm.TypeServiceCommercialKPSA;
import com.bytel.spirit.prof.connectors.generated.svccomm.TypeServiceCommercialMIM;
import com.bytel.spirit.prof.connectors.refclient.RefClientProxy;
import com.bytel.spirit.prof.connectors.svccomm.SvcCommMimProxy;
import com.bytel.spirit.prof.processes.generated.provisionnerpfi.ProvisionnerPfiOut;
import com.bytel.spirit.prof.processes.generated.provisionnerpfi.ReponseTechniqueCodeRetour;

/**
 *
 * @author lmerces
 * @version ($Revision$ $Date$)
 */
//Déclaration du runner de test pour lancer les TUs avec le runner PowerMock
@RunWith(PowerMockRunner.class)
//Préparation des classes pour les tests, toutes les classes comportant des méthodes statiques à mocker doivent être présentes dans l'annotation
@PrepareForTest({ InkProxy.class, OAMProxy.class, RefClientProxy.class, SvcCommMimProxy.class })
//To avoid: SecretKeyFactory.getInstance() throws exception for all algorithms in unit tests
@PowerMockIgnore("javax.crypto.*")
public class PM028ProvisionnerPfiTest
{
  /**
   * The default process name.
   */
  public static final String DEFAULT_PROCESSNAME = "PM028_ProvisionnerPfi"; //$NON-NLS-1$

  /**
   *
   */
  private static List<RequestHeader> _myHeader;

  /**
   *
   */
  private static String _payload;

  /**
   *
   */
  private static final int HTTP_OK = 200;

  /**
   *
   */
  private static final String IDT_DDE = "cde3ab202e714d88afb92e24b52185ef"; //$NON-NLS-1$

  /**
   *
   */
  private static final String SERVICE_MIM_1645 = "1645"; //$NON-NLS-1$

  /**
   * Configuration parameter INK_CONNECTOR_ID
   */
  private static final String INK_CONNECTORID_PARAM = "INK_CONNECTOR_ID"; //$NON-NLS-1$

  /**
  *
  */
  private static final String CONSULTERPFI_CONNECTOR_ID = "CONSULTERPFI_CONNECTOR_ID"; //$NON-NLS-1$

  /**
  *
  */
  private static final String PARTTTION_SIC = "PartitionSic"; //$NON-NLS-1$

  /**
   *
   */
  private static final String FORCERESYNCHROSINPBT = "ForceResynchroSiNpbt"; //$NON-NLS-1$

  /**
   *
   */
  private static final String BOUCHONREFCLI = "BouchonRefCli"; //$NON-NLS-1$

  /**
   *
   * @throws IOException
   *           thrown exception
   * @throws ParserConfigurationException
   *           thrown exception
   * @throws SAXException
   *           thrown exception
   */
  @BeforeClass
  public static void init() throws IOException, SAXException, ParserConfigurationException
  {
    ACManagerUtil.resetACManager();
    new ClassPathXmlApplicationContext("classpath:BeansProcessTestMocks.xml"); //$NON-NLS-1$

    _payload = readFile("src/test/resources/provisionnerPfiIn_request.xml", StandardCharsets.UTF_8); //$NON-NLS-1$
    _myHeader = getHeader("src/test/resources/msgHeader.xml"); //$NON-NLS-1$

    HashMap<String, String> map = new HashMap<String, String>();
    map.put(INK_CONNECTORID_PARAM, "InkConnector"); //$NON-NLS-1$
    map.put(CONSULTERPFI_CONNECTOR_ID, "RefClientConnector"); //$NON-NLS-1$
    map.put(PARTTTION_SIC, "3"); //$NON-NLS-1$
    map.put(FORCERESYNCHROSINPBT, "false"); //$NON-NLS-1$
    map.put(BOUCHONREFCLI, "false"); //$NON-NLS-1$
    ConcurrentHashMap<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.put(StringConstants.EMPTY_STRING, map);
  }

  /**
   *
   * @param path_p
   *          file path
   * @return file content
   * @throws SAXException
   *           thrown exception
   * @throws IOException
   *           thrown exception
   * @throws ParserConfigurationException
   *           thrown exception
   */
  static List<RequestHeader> getHeader(String path_p) throws SAXException, IOException, ParserConfigurationException
  {
    List<RequestHeader> result = new ArrayList<RavelRequest.RequestHeader>();
    RequestHeader header = new RequestHeader();
    header.setName("msgHeader"); //$NON-NLS-1$
    header.setValue(readFile(path_p, StandardCharsets.UTF_8));
    result.add(header);
    return result;

  }

  /**
   *
   * @param path_p
   *          file path
   * @param encoding_p
   *          file encoding
   * @return file content
   * @throws IOException
   *           thrown exception
   */
  static String readFile(String path_p, Charset encoding_p) throws IOException
  {
    byte[] encoded = Files.readAllBytes(Paths.get(path_p));
    return new String(encoded, encoding_p);
  }

  /**
   * Tracabilite
   */
  Tracabilite _tracabilite = new Tracabilite(StringConstants.EMPTY_STRING, Test_Consts.DEFAULT_MSGID, "PROF", "nomPRocessus", "idProcessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$;

  /**
   *
   */
  @MockStrict
  private InkProxy _ink001EnvoyerDemandeInk;

  /**
   *
   */
  @MockStrict
  private OAMProxy _oamConnector;

  /**
   *
   */
  @MockStrict
  private RefClientProxy _refClientConnector;

  /**
   *
   */
  @MockStrict
  private SvcCommMimProxy _svcCommMimConnector;

  /**
   *
   */
  private PM028ProvisionnerPfi _currentInstance;

  /**
   * Called before each test with the annotation @Before to clean the connectors.
   */
  @Before
  public void beforeTest()
  {
    // on réinitialise tous les mocks afin de ne pas avoir d'interférence entre les tests
    PowerMock.resetAll();

    // On initialise toutes les classes à mocker comportant un appel à une méthode statique
    // Dans notre cas on mock statiquemement toutes les classes des activités et des proxys appelés (pour les createContexte et les getInstance)
    PowerMock.mockStaticStrict(InkProxy.class);
    PowerMock.mockStaticStrict(OAMProxy.class);
    PowerMock.mockStaticStrict(RefClientProxy.class);
    PowerMock.mockStaticStrict(SvcCommMimProxy.class);

    // Initialize the context
    _currentInstance = new PM028ProvisionnerPfi();
    _currentInstance.initializeContext();
  }

  /**
   * Return the value of a refFonc element in the refFonc map
   *
   * @param tracabilite_p
   *          tracabilite
   * @param refFoncKey
   *          refFonc key
   * @return the value of the refFonc
   */
  public String getRefFoncFromMap(Tracabilite tracabilite_p, String refFoncKey)
  {
    return tracabilite_p.getRefFonc().get(refFoncKey);
  }

  /**
   * Test codeCauseChangementStatut « ACTIVER_LIGNES »
   *
   * @throws Throwable
   *           thrown throwable
   */
  @Test
  public void PM028_ProvisionnerPfiTest_ActiverLignes() throws Throwable
  {
    FollowUpTable tableSuivi = new FollowUpTable();
    tableSuivi.setIdtDde(IDT_DDE);
    Retour retour = RetourFactoryForTU.createRetour(StringConstants.OK, null, Diagnostic.PROVISIONING.toString(), null, null);

    com.bytel.spirit.common.connectors.ink.generated.Response responseInk = new com.bytel.spirit.common.connectors.ink.generated.Response();
    ResponseConnector responseConnector = new ResponseConnector(responseInk, null);

    //Prepare mock
    EasyMock.expect(SvcCommMimProxy.getInstance()).andReturn(_svcCommMimConnector);
    EasyMock.expectLastCall().anyTimes();
    EasyMock.expect(OAMProxy.getInstance()).andReturn(_oamConnector);
    EasyMock.expectLastCall().anyTimes();
    EasyMock.expect(InkProxy.getInstance()).andReturn(_ink001EnvoyerDemandeInk);

    //Pour PM028_BL001_ControlerDonneesEntree
    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, SERVICE_MIM_1645)).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(new TypeServiceCommercialMIM(), true));
    EasyMock.expect(_oamConnector.insererDemandeSuivi(EasyMock.isA(Tracabilite.class), EasyMock.isA(FollowUpTable.class))).andReturn(new ConnectorResponse<FollowUpTable, Retour>(tableSuivi, retour));

    //Pour PM028_BL100_DetecterConsulterPFI
    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, SERVICE_MIM_1645)).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(null, false));
    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, "2")).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(null, false)); //$NON-NLS-1$

    //Pour PM028_BL300_MimToInk
    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, SERVICE_MIM_1645)).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(null, false));
    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, "2")).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(null, false)); //$NON-NLS-1$

    EasyMock.expect(_oamConnector.mettreAJourDemandeSuivi(EasyMock.isA(Tracabilite.class), EasyMock.isA(FollowUpTable.class))).andReturn(new ConnectorResponse<Integer, Retour>(1, RetourFactoryForTU.createOkRetour()));

    EasyMock.expect(_ink001EnvoyerDemandeInk.envoyerDemandeInk(EasyMock.isA(com.bytel.spirit.common.connectors.ink.generated.Request.class), EasyMock.eq(Test_Consts.DEFAULT_MSGID), EasyMock.eq(IInkConnector.BEAN_ID))).andReturn(new ConnectorResponse<Integer, ResponseConnector>(HTTP_OK, responseConnector));

    // On enregistre le scénario des appels
    PowerMock.replayAll();

    Request request = prepareRequest(readFile("src/test/resources/provisionnerPfiIn_request4.xml", StandardCharsets.UTF_8), _myHeader); //$NON-NLS-1$
    Response response = executeStartProcess(request, DEFAULT_PROCESSNAME);

    PowerMock.verifyAll();

    Assert.assertEquals(null, response.getGenericResponse().getDataType());

    String result = response.getGenericResponse().getResult();
    Assert.assertNotNull(result);
    ProvisionnerPfiOut provisionnerPfiOut = MarshallTools.unmarshall(ProvisionnerPfiOut.class, result);
    Assert.assertEquals(ReponseTechniqueCodeRetour.OK, provisionnerPfiOut.getCodeRetour());
    Assert.assertNull(provisionnerPfiOut.getRaison());
    Assert.assertNull(provisionnerPfiOut.getDiagnostic());
  }

  /**
   * Test pour verifier si le MSISDN dans le ligneGSM est envoyé pour INK.
   *
   * @throws Throwable
   *           thrown exception
   */
  @Test
  public void PM028_ProvisionnerPfiTest_Ano319770() throws Throwable
  {
    String payload = readFile("src/test/resources/provisionnerPfiIn_requestAno319770.xml", StandardCharsets.UTF_8); //$NON-NLS-1$
    List<RequestHeader> myHeader = getHeader("src/test/resources/msgHeaderAno319770.xml"); //$NON-NLS-1$
    Retour retour = RetourFactoryForTU.createRetour("OK", null, Diagnostic.PROVISIONING.toString(), null, null); //$NON-NLS-1$

    TypeServiceCommercialMIM svcComMim = new TypeServiceCommercialMIM();
    TypeServiceCommercialKPSA tsck = new TypeServiceCommercialKPSA();
    tsck.setIdServiceKPSA("PBS62T"); //$NON-NLS-1$
    TypeParametres tparams = new TypeParametres();
    TypeParametre tparamMsisdn = new TypeParametre();
    tparamMsisdn.setIdParametreKPSA("MSISDN"); //$NON-NLS-1$

    TypeParametre tparamSparam0 = new TypeParametre();
    tparamSparam0.setIdParametreKPSA("SPARAM[0]"); //$NON-NLS-1$
    tparamSparam0.setConstante("24"); //$NON-NLS-1$
    tparams.getParametres().add(tparamMsisdn);
    tparams.getParametres().add(tparamSparam0);

    tsck.setParametres(tparams);
    svcComMim.setDescription("Emission de fax"); //$NON-NLS-1$
    svcComMim.getServiceCommercialKPSAs().add(tsck);

    com.bytel.spirit.common.connectors.ink.generated.Response responseInk = new com.bytel.spirit.common.connectors.ink.generated.Response();
    ResponseConnector responseConnector = new ResponseConnector(responseInk, null);

    //Prepare mock
    EasyMock.expect(OAMProxy.getInstance()).andReturn(_oamConnector);
    EasyMock.expectLastCall().anyTimes();
    EasyMock.expect(SvcCommMimProxy.getInstance()).andReturn(_svcCommMimConnector);
    EasyMock.expectLastCall().anyTimes();
    EasyMock.expect(InkProxy.getInstance()).andReturn(_ink001EnvoyerDemandeInk);

    EasyMock.expect(_oamConnector.insererDemandeSuivi(EasyMock.isA(Tracabilite.class), EasyMock.isA(FollowUpTable.class))).andReturn(new ConnectorResponse<FollowUpTable, Retour>(new FollowUpTable(), retour));
    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, "16")).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(svcComMim, true)); //$NON-NLS-1$
    EasyMock.expectLastCall().anyTimes();
    EasyMock.expect(_oamConnector.mettreAJourDemandeSuivi(EasyMock.isA(Tracabilite.class), EasyMock.isA(FollowUpTable.class))).andReturn(new ConnectorResponse<Integer, Retour>(0, RetourFactoryForTU.createOkRetour()));
    EasyMock.expect(_ink001EnvoyerDemandeInk.envoyerDemandeInk(EasyMock.isA(com.bytel.spirit.common.connectors.ink.generated.Request.class), EasyMock.eq(Test_Consts.DEFAULT_MSGID), EasyMock.eq(IInkConnector.BEAN_ID))).andReturn(new ConnectorResponse<Integer, ResponseConnector>(HTTP_OK, responseConnector));

    // On enregistre le scénario des appels
    PowerMock.replayAll();

    //ANO 320432
    Request request = prepareRequest(payload, myHeader);
    Response response = executeStartProcess(request, DEFAULT_PROCESSNAME);

    PowerMock.verifyAll();

    String result = response.getGenericResponse().getResult();
    Assert.assertNotNull(result);
    ProvisionnerPfiOut provisionnerPfiOut = MarshallTools.unmarshall(ProvisionnerPfiOut.class, result);
    Assert.assertEquals(ReponseTechniqueCodeRetour.OK, provisionnerPfiOut.getCodeRetour());
    Assert.assertNull(provisionnerPfiOut.getRaison());
    Assert.assertEquals(null, provisionnerPfiOut.getDiagnostic());
  }

  /**
   * Test cas nominal provisioning KO à cause de l'appel INK KO.
   *
   * @throws Throwable
   *           thrown throwable
   */
  @Test
  public void PM028_ProvisionnerPfiTest_CasNominal_KO_AppelINK_KO() throws Throwable
  {
    FollowUpTable tableSuivi = new FollowUpTable();
    tableSuivi.setIdtDde(IDT_DDE);
    Retour retour = RetourFactoryForTU.createRetour(StringConstants.OK, null, Diagnostic.PROVISIONING.toString(), null, null);

    //Prepare mock
    EasyMock.expect(SvcCommMimProxy.getInstance()).andReturn(_svcCommMimConnector);
    EasyMock.expectLastCall().anyTimes();
    EasyMock.expect(OAMProxy.getInstance()).andReturn(_oamConnector);
    EasyMock.expectLastCall().anyTimes();
    EasyMock.expect(InkProxy.getInstance()).andReturn(_ink001EnvoyerDemandeInk);

    //Pour PM028_BL001_ControlerDonneesEntree
    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, SERVICE_MIM_1645)).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(new TypeServiceCommercialMIM(), true));
    EasyMock.expect(_oamConnector.insererDemandeSuivi(EasyMock.isA(Tracabilite.class), EasyMock.isA(FollowUpTable.class))).andReturn(new ConnectorResponse<FollowUpTable, Retour>(tableSuivi, retour));

    //Pour PM028_BL100_DetecterConsulterPFI
    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, SERVICE_MIM_1645)).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(null, false));
    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, "2")).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(null, false)); //$NON-NLS-1$

    //Pour PM028_BL300_MimToInk
    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, SERVICE_MIM_1645)).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(null, false));
    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, "2")).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(null, false)); //$NON-NLS-1$

    EasyMock.expect(_oamConnector.mettreAJourDemandeSuivi(EasyMock.isA(Tracabilite.class), EasyMock.isA(FollowUpTable.class))).andReturn(new ConnectorResponse<Integer, Retour>(1, RetourFactoryForTU.createOkRetour()));

    RavelException erreur = new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.PRCESS_00002, "Error !!"); //$NON-NLS-1$
    EasyMock.expect(_ink001EnvoyerDemandeInk.envoyerDemandeInk(EasyMock.isA(com.bytel.spirit.common.connectors.ink.generated.Request.class), EasyMock.eq(Test_Consts.DEFAULT_MSGID), EasyMock.eq(IInkConnector.BEAN_ID))).andThrow(erreur);

    // On enregistre le scénario des appels
    PowerMock.replayAll();

    Request request = prepareRequest(_payload, _myHeader);
    Response response = executeStartProcess(request, DEFAULT_PROCESSNAME);

    PowerMock.verifyAll();

    Assert.assertEquals(null, response.getGenericResponse().getDataType());

    String result = response.getGenericResponse().getResult();
    Assert.assertNotNull(result);
    ProvisionnerPfiOut provisionnerPfiOut = MarshallTools.unmarshall(ProvisionnerPfiOut.class, result);
    Assert.assertEquals(ReponseTechniqueCodeRetour.NOK, provisionnerPfiOut.getCodeRetour());
    Assert.assertEquals(Consts.DEF_2.toString(), provisionnerPfiOut.getRaison());
    Assert.assertEquals("REPONSE_SERVEUR_INCORRECTE", provisionnerPfiOut.getDiagnostic()); //$NON-NLS-1$
  }

  /**
   * Test cas nominal provisioning KO car PM028_BL300_MimToInk KO.
   *
   * @throws Throwable
   *           thrown throwable
   */
  @Test
  public void PM028_ProvisionnerPfiTest_CasNominal_KO_BL300MimToInkKO() throws Throwable
  {

    FollowUpTable tableSuivi = new FollowUpTable();
    tableSuivi.setIdtDde(IDT_DDE);
    Retour retour = RetourFactoryForTU.createRetour(StringConstants.OK, null, Diagnostic.PROVISIONING.toString(), null, null);
    RavelException erreur = new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.PRCESS_00002, "Error !!"); //$NON-NLS-1$

    //Prepare mock
    EasyMock.expect(SvcCommMimProxy.getInstance()).andReturn(_svcCommMimConnector);
    EasyMock.expectLastCall().anyTimes();
    EasyMock.expect(OAMProxy.getInstance()).andReturn(_oamConnector);
    EasyMock.expectLastCall().anyTimes();

    //Pour PM028_BL001_ControlerDonneesEntree
    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, SERVICE_MIM_1645)).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(new TypeServiceCommercialMIM(), true));
    EasyMock.expect(_oamConnector.insererDemandeSuivi(EasyMock.isA(Tracabilite.class), EasyMock.isA(FollowUpTable.class))).andReturn(new ConnectorResponse<FollowUpTable, Retour>(tableSuivi, retour));

    //Pour PM028_BL100_DetecterConsulterPFI
    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, SERVICE_MIM_1645)).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(null, false));
    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, "2")).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(null, false)); //$NON-NLS-1$

    //Pour PM028_BL300_MimToInk
    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, SERVICE_MIM_1645)).andThrow(erreur);
    EasyMock.expect(_oamConnector.mettreAJourDemandeSuivi(EasyMock.isA(Tracabilite.class), EasyMock.isA(FollowUpTable.class))).andReturn(new ConnectorResponse<Integer, Retour>(1, RetourFactoryForTU.createOkRetour()));

    // On enregistre le scénario des appels
    PowerMock.replayAll();

    Request request = prepareRequest(_payload, _myHeader);
    Response response = executeStartProcess(request, DEFAULT_PROCESSNAME);

    PowerMock.verifyAll();

    Assert.assertEquals(null, response.getGenericResponse().getDataType());

    String result = response.getGenericResponse().getResult();
    Assert.assertNotNull(result);
    ProvisionnerPfiOut provisionnerPfiOut = MarshallTools.unmarshall(ProvisionnerPfiOut.class, result);
    Assert.assertEquals(ReponseTechniqueCodeRetour.NOK, provisionnerPfiOut.getCodeRetour());
    Assert.assertEquals(Consts.DEF_2.toString(), provisionnerPfiOut.getRaison());
    Assert.assertEquals(Consts.SERVICE_INDISPONIBLE.toString(), provisionnerPfiOut.getDiagnostic());
  }

  /**
   * Test cas nominal provisioning avec enrichissement requis, calcul impact OK (ResynchroSiNpbt) et appels INK OK.
   *
   * @throws Throwable
   *           thrown throwable
   */
  @Test
  public void PM028_ProvisionnerPfiTest_CasNominal_OK_ProvisioningAvecEnrichissementRequis() throws Throwable
  {
    FollowUpTable tableSuivi = new FollowUpTable();
    tableSuivi.setIdtDde(IDT_DDE);
    Retour retour = RetourFactoryForTU.createRetour(StringConstants.OK, null, Diagnostic.PROVISIONING.toString(), null, null);

    TypeServiceCommercialMIM typeServiceCommercialMIM = new TypeServiceCommercialMIM();
    typeServiceCommercialMIM.setEnrichissementRefcliRequis(true);

    ConsulterPFIReponseType consulterPFIReponseType = MarshallTools.unmarshall(ConsulterPFIReponseType.class, new File("src/test/resources/ConsulterPFIReponseType.xml")); //$NON-NLS-1$

    com.bytel.spirit.common.connectors.ink.generated.Response responseInk = new com.bytel.spirit.common.connectors.ink.generated.Response();
    ResponseConnector responseConnector = new ResponseConnector(responseInk, null);

    //Prepare mock
    EasyMock.expect(SvcCommMimProxy.getInstance()).andReturn(_svcCommMimConnector);
    EasyMock.expectLastCall().anyTimes();
    EasyMock.expect(OAMProxy.getInstance()).andReturn(_oamConnector);
    EasyMock.expectLastCall().anyTimes();
    EasyMock.expect(RefClientProxy.getInstance()).andReturn(_refClientConnector);
    EasyMock.expect(InkProxy.getInstance()).andReturn(_ink001EnvoyerDemandeInk);

    //Pour PM028_BL001_ControlerDonneesEntree
    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, SERVICE_MIM_1645)).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(new TypeServiceCommercialMIM(), true));
    EasyMock.expect(_oamConnector.insererDemandeSuivi(EasyMock.isA(Tracabilite.class), EasyMock.isA(FollowUpTable.class))).andReturn(new ConnectorResponse<FollowUpTable, Retour>(tableSuivi, retour));

    //Pour PM028_BL100_DetecterConsulterPFI
    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, SERVICE_MIM_1645)).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(null, false));
    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, "2")).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(typeServiceCommercialMIM, true)); //$NON-NLS-1$

    //Pour PM028_BL300_MimToInk
    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, "1089")).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(null, false)); //$NON-NLS-1$
    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, "107")).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(null, false)); //$NON-NLS-1$
    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, "6")).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(null, false)); //$NON-NLS-1$
    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, "63")).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(null, false)); //$NON-NLS-1$

    EasyMock.expect(_refClientConnector.consulterPFI(EasyMock.isA(Tracabilite.class), EasyMock.isA(ConsulterPFIIn.class), EasyMock.eq("RefClientConnector"))).andReturn(new ConnectorResponse<ConsulterPFIReponseType, Integer>(consulterPFIReponseType, HTTP_OK)); //$NON-NLS-1$

    EasyMock.expect(_oamConnector.mettreAJourDemandeSuivi(EasyMock.isA(Tracabilite.class), EasyMock.isA(FollowUpTable.class))).andReturn(new ConnectorResponse<Integer, Retour>(1, RetourFactoryForTU.createOkRetour()));

    EasyMock.expect(_ink001EnvoyerDemandeInk.envoyerDemandeInk(EasyMock.isA(com.bytel.spirit.common.connectors.ink.generated.Request.class), EasyMock.eq(Test_Consts.DEFAULT_MSGID), EasyMock.eq(IInkConnector.BEAN_ID))).andReturn(new ConnectorResponse<Integer, ResponseConnector>(HTTP_OK, responseConnector));

    // On enregistre le scénario des appels
    PowerMock.replayAll();

    Request request = prepareRequest(_payload, _myHeader);
    Response response = executeStartProcess(request, DEFAULT_PROCESSNAME);

    PowerMock.verifyAll();

    Assert.assertEquals(null, response.getGenericResponse().getDataType());

    String result = response.getGenericResponse().getResult();
    Assert.assertNotNull(result);
    ProvisionnerPfiOut provisionnerPfiOut = MarshallTools.unmarshall(ProvisionnerPfiOut.class, result);
    Assert.assertEquals(provisionnerPfiOut.getCodeRetour(), ReponseTechniqueCodeRetour.OK);
    Assert.assertNull(provisionnerPfiOut.getRaison());
    Assert.assertNull(provisionnerPfiOut.getDiagnostic());
  }

  /**
   * Test cas nominal provisioning sans enrichissement requis et appels INK OK.
   *
   * @throws Throwable
   *           thrown throwable
   */
  @Test
  public void PM028_ProvisionnerPfiTest_CasNominal_OK_ProvisioningSansEnrichissementRequis() throws Throwable
  {
    FollowUpTable tableSuivi = new FollowUpTable();
    tableSuivi.setIdtDde(IDT_DDE);
    Retour retour = RetourFactoryForTU.createRetour(StringConstants.OK, null, Diagnostic.PROVISIONING.toString(), null, null);
    com.bytel.spirit.common.connectors.ink.generated.Response responseInk = new com.bytel.spirit.common.connectors.ink.generated.Response();
    ResponseConnector responseConnector = new ResponseConnector(responseInk, null);

    //Prepare mock
    EasyMock.expect(SvcCommMimProxy.getInstance()).andReturn(_svcCommMimConnector);
    EasyMock.expectLastCall().anyTimes();
    EasyMock.expect(OAMProxy.getInstance()).andReturn(_oamConnector);
    EasyMock.expectLastCall().anyTimes();
    EasyMock.expect(InkProxy.getInstance()).andReturn(_ink001EnvoyerDemandeInk);

    //Pour PM028_BL001_ControlerDonneesEntree
    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, SERVICE_MIM_1645)).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(new TypeServiceCommercialMIM(), true));
    EasyMock.expect(_oamConnector.insererDemandeSuivi(EasyMock.isA(Tracabilite.class), EasyMock.isA(FollowUpTable.class))).andReturn(new ConnectorResponse<FollowUpTable, Retour>(tableSuivi, retour));

    //Pour PM028_BL100_DetecterConsulterPFI
    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, SERVICE_MIM_1645)).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(null, false));
    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, "2")).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(null, false)); //$NON-NLS-1$

    //Pour PM028_BL300_MimToInk
    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, SERVICE_MIM_1645)).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(null, false));
    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, "2")).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(null, false)); //$NON-NLS-1$
    EasyMock.expect(_oamConnector.mettreAJourDemandeSuivi(EasyMock.isA(Tracabilite.class), EasyMock.isA(FollowUpTable.class))).andReturn(new ConnectorResponse<Integer, Retour>(1, RetourFactoryForTU.createOkRetour()));

    EasyMock.expect(_ink001EnvoyerDemandeInk.envoyerDemandeInk(EasyMock.isA(com.bytel.spirit.common.connectors.ink.generated.Request.class), EasyMock.eq(Test_Consts.DEFAULT_MSGID), EasyMock.eq(IInkConnector.BEAN_ID))).andReturn(new ConnectorResponse<Integer, ResponseConnector>(HTTP_OK, responseConnector));

    // On enregistre le scénario des appels
    PowerMock.replayAll();

    Request request = prepareRequest(_payload, _myHeader);
    Response response = executeStartProcess(request, DEFAULT_PROCESSNAME);

    PowerMock.verifyAll();

    Assert.assertEquals(null, response.getGenericResponse().getDataType());

    String result = response.getGenericResponse().getResult();
    Assert.assertNotNull(result);
    ProvisionnerPfiOut provisionnerPfiOut = MarshallTools.unmarshall(ProvisionnerPfiOut.class, result);
    Assert.assertEquals(provisionnerPfiOut.getCodeRetour(), ReponseTechniqueCodeRetour.OK);
    Assert.assertNull(provisionnerPfiOut.getRaison());
    Assert.assertNull(provisionnerPfiOut.getDiagnostic());
  }

  /**
   * Test PM028_BL001_ControlerDonneesEntree KO
   *
   * @throws Throwable
   *           thrown throwable
   */
  @Test
  public void PM028_ProvisionnerPfiTest_ControlerDonneesEntree_KO() throws Throwable
  {
    RavelException ex = new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.PRCESS_00002, "Test error !"); //$NON-NLS-1$

    //Prepare mock
    EasyMock.expect(SvcCommMimProxy.getInstance()).andReturn(_svcCommMimConnector);
    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, SERVICE_MIM_1645)).andThrow(ex);

    // On enregistre le scénario des appels
    PowerMock.replayAll();

    Request request = prepareRequest(_payload, _myHeader);
    Response response = executeStartProcess(request, DEFAULT_PROCESSNAME);

    PowerMock.verifyAll();

    Assert.assertEquals(null, response.getGenericResponse().getDataType());

    String result = response.getGenericResponse().getResult();
    Assert.assertNotNull(result);
    ProvisionnerPfiOut provisionnerPfiOut = MarshallTools.unmarshall(ProvisionnerPfiOut.class, result);
    Assert.assertEquals(provisionnerPfiOut.getCodeRetour(), ReponseTechniqueCodeRetour.NOK);
    Assert.assertEquals(provisionnerPfiOut.getRaison(), Consts.DEF_2.toString());
    Assert.assertEquals(provisionnerPfiOut.getDiagnostic(), Consts.SERVICE_INDISPONIBLE.toString());
  }

  /**
   * Test PM028_BL001_ControlerDonneesEntree OK/AUCUN_PROVISIONNING
   *
   * @throws Throwable
   *           thrown throwable
   */
  @Test
  public void PM028_ProvisionnerPfiTest_ControlerDonneesEntree_OK_AUCUN_PROVISIONNING() throws Throwable
  {
    //Prepare mock
    EasyMock.expect(SvcCommMimProxy.getInstance()).andReturn(_svcCommMimConnector);
    EasyMock.expectLastCall().anyTimes();
    EasyMock.expect(OAMProxy.getInstance()).andReturn(_oamConnector);

    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, SERVICE_MIM_1645)).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(null, false));
    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, "2")).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(null, false)); //$NON-NLS-1$

    EasyMock.expect(_oamConnector.insererDemandeSuivi(EasyMock.isA(Tracabilite.class), EasyMock.isA(FollowUpTable.class))).andReturn(new ConnectorResponse<FollowUpTable, Retour>(new FollowUpTable(), RetourFactoryForTU.createOkRetour()));

    PowerMock.replayAll();

    Request request = prepareRequest(_payload, _myHeader);
    Response response = executeStartProcess(request, DEFAULT_PROCESSNAME);

    PowerMock.verifyAll();

    Assert.assertEquals(null, response.getGenericResponse().getDataType());

    String result = response.getGenericResponse().getResult();
    Assert.assertNotNull(result);
    ProvisionnerPfiOut provisionnerPfiOut = MarshallTools.unmarshall(ProvisionnerPfiOut.class, result);
    Assert.assertEquals(provisionnerPfiOut.getCodeRetour(), ReponseTechniqueCodeRetour.OK);
    Assert.assertNull(provisionnerPfiOut.getRaison());
    Assert.assertEquals(Diagnostic.AUCUN_PROVISIONING.toString(), provisionnerPfiOut.getDiagnostic());
  }

  /**
   * Test PM028_BL001_ControlerDonneesEntree OK/PROVISIONNING mais l'insertion de la demande en base est un doublon déjà
   * traité.
   *
   * @throws Throwable
   *           thrown throwable
   */
  @Test
  public void PM028_ProvisionnerPfiTest_ControlerDonneesEntree_OK_PROVISIONNING_Doublon_Deja_Traite() throws Throwable
  {
    Retour retour = RetourFactoryForTU.createRetour(StringConstants.OK, null, OAMConnector.DOUBLON_DEJA_TRAITE, null, null);

    //Prepare mock
    EasyMock.expect(SvcCommMimProxy.getInstance()).andReturn(_svcCommMimConnector);
    EasyMock.expectLastCall().anyTimes();
    EasyMock.expect(OAMProxy.getInstance()).andReturn(_oamConnector);

    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, SERVICE_MIM_1645)).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(null, false));
    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, "2")).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(null, false)); //$NON-NLS-1$

    EasyMock.expect(_oamConnector.insererDemandeSuivi(EasyMock.isA(Tracabilite.class), EasyMock.isA(FollowUpTable.class))).andReturn(new ConnectorResponse<FollowUpTable, Retour>(new FollowUpTable(), retour));

    PowerMock.replayAll();

    Request request = prepareRequest(_payload, _myHeader);
    Response response = executeStartProcess(request, DEFAULT_PROCESSNAME);

    PowerMock.verifyAll();

    Assert.assertEquals(null, response.getGenericResponse().getDataType());

    String result = response.getGenericResponse().getResult();
    Assert.assertNotNull(result);
    ProvisionnerPfiOut provisionnerPfiOut = MarshallTools.unmarshall(ProvisionnerPfiOut.class, result);
    Assert.assertEquals(provisionnerPfiOut.getCodeRetour(), ReponseTechniqueCodeRetour.OK);
    Assert.assertNull(provisionnerPfiOut.getRaison());
    Assert.assertEquals(Diagnostic.AUCUN_PROVISIONING.toString(), provisionnerPfiOut.getDiagnostic());
  }

  /**
   * Test PM028_BL001_ControlerDonneesEntree OK/PROVISIONNING mais insertion demande en base KO.
   *
   * @throws Throwable
   *           thrown throwable
   */
  @Test
  public void PM028_ProvisionnerPfiTest_ControlerDonneesEntree_OK_PROVISIONNING_InsertionDemande_KO() throws Throwable
  {
    RavelException erreur = new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.PRCESS_00002, "aille !!"); //$NON-NLS-1$

    //Prepare mock
    EasyMock.expect(SvcCommMimProxy.getInstance()).andReturn(_svcCommMimConnector);
    EasyMock.expectLastCall().anyTimes();
    EasyMock.expect(OAMProxy.getInstance()).andReturn(_oamConnector);

    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, SERVICE_MIM_1645)).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(null, false));
    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, "2")).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(null, false)); //$NON-NLS-1$

    EasyMock.expect(_oamConnector.insererDemandeSuivi(EasyMock.isA(Tracabilite.class), EasyMock.isA(FollowUpTable.class))).andThrow(erreur);

    PowerMock.replayAll();

    Request request = prepareRequest(_payload, _myHeader);
    Response response = executeStartProcess(request, DEFAULT_PROCESSNAME);

    PowerMock.verifyAll();

    Assert.assertEquals(null, response.getGenericResponse().getDataType());

    String result = response.getGenericResponse().getResult();
    Assert.assertNotNull(result);
    ProvisionnerPfiOut provisionnerPfiOut = MarshallTools.unmarshall(ProvisionnerPfiOut.class, result);
    Assert.assertEquals(ReponseTechniqueCodeRetour.NOK, provisionnerPfiOut.getCodeRetour());
    Assert.assertEquals(Consts.DEF_2.toString(), provisionnerPfiOut.getRaison());
    Assert.assertEquals(Consts.SERVICE_INDISPONIBLE.toString(), provisionnerPfiOut.getDiagnostic());
  }

  /**
   * Test KO, Diagnostic inattendu.
   *
   * @throws Throwable
   *           thrown throwable
   */
  @Test
  public void PM028_ProvisionnerPfiTest_DiagnosticInattendu() throws Throwable
  {

    FollowUpTable tableSuivi = new FollowUpTable();
    tableSuivi.setIdtDde(IDT_DDE);
    Retour retour = RetourFactoryForTU.createRetour(StringConstants.OK, null, Diagnostic.PROVISIONNER_SERVICES.toString(), null, null);

    //Prepare mock
    EasyMock.expect(SvcCommMimProxy.getInstance()).andReturn(_svcCommMimConnector);
    EasyMock.expectLastCall().anyTimes();
    EasyMock.expect(OAMProxy.getInstance()).andReturn(_oamConnector);
    EasyMock.expectLastCall().anyTimes();

    //Pour PM028_BL001_ControlerDonneesEntree
    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, SERVICE_MIM_1645)).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(new TypeServiceCommercialMIM(), true));
    EasyMock.expect(_oamConnector.insererDemandeSuivi(EasyMock.isA(Tracabilite.class), EasyMock.isA(FollowUpTable.class))).andReturn(new ConnectorResponse<FollowUpTable, Retour>(tableSuivi, retour));

    // On enregistre le scénario des appels
    PowerMock.replayAll();

    Request request = prepareRequest(_payload, _myHeader);
    Response response = executeStartProcess(request, DEFAULT_PROCESSNAME);

    PowerMock.verifyAll();

    Assert.assertEquals(null, response.getGenericResponse().getDataType());

    String result = response.getGenericResponse().getResult();
    Assert.assertNotNull(result);
    ProvisionnerPfiOut provisionnerPfiOut = MarshallTools.unmarshall(ProvisionnerPfiOut.class, result);
    Assert.assertEquals(ReponseTechniqueCodeRetour.NOK, provisionnerPfiOut.getCodeRetour());
    Assert.assertEquals(Consts.DEF_2.toString(), provisionnerPfiOut.getRaison());
    Assert.assertEquals(Diagnostic.PROVISIONNER_SERVICES.toString(), provisionnerPfiOut.getDiagnostic());
  }

  /**
   * Test Provisioning sans donnes metier.
   *
   * @throws Throwable
   *           thrown exception
   */
  @Test
  public void PM028_ProvisionnerPfiTest_DonnesMetierVide() throws Throwable
  {
    String payload = readFile("src/test/resources/provisionnerPfiIn_requestAno320432.xml", StandardCharsets.UTF_8); //$NON-NLS-1$
    List<RequestHeader> myHeader = getHeader("src/test/resources/msgHeaderAno320432.xml"); //$NON-NLS-1$
    FollowUpTable tableSuivi = new FollowUpTable();
    Retour retour = RetourFactoryForTU.createRetour("OK", null, Diagnostic.PROVISIONING.toString(), null, null); //$NON-NLS-1$

    //Prepare mock
    EasyMock.expect(OAMProxy.getInstance()).andReturn(_oamConnector);
    EasyMock.expect(_oamConnector.insererDemandeSuivi(EasyMock.isA(Tracabilite.class), EasyMock.isA(FollowUpTable.class))).andReturn(new ConnectorResponse<FollowUpTable, Retour>(tableSuivi, retour));

    PowerMock.replayAll();

    //ANO 320432
    Request request = prepareRequest(payload, myHeader);
    Response response = executeStartProcess(request, DEFAULT_PROCESSNAME);

    PowerMock.verifyAll();

    String result = response.getGenericResponse().getResult();
    Assert.assertNotNull(result);
    ProvisionnerPfiOut provisionnerPfiOut = MarshallTools.unmarshall(ProvisionnerPfiOut.class, result);
    Assert.assertEquals(ReponseTechniqueCodeRetour.OK, provisionnerPfiOut.getCodeRetour());
    Assert.assertNull(provisionnerPfiOut.getRaison());
    Assert.assertEquals(Diagnostic.AUCUN_PROVISIONING.toString(), provisionnerPfiOut.getDiagnostic());
  }

  /**
   * Test OK, DOUBLON_DEJA_TRAITE.
   *
   * @throws Throwable
   *           thrown throwable
   */
  @Test
  public void PM028_ProvisionnerPfiTest_Doublon_Deja_Traite() throws Throwable
  {

    FollowUpTable tableSuivi = new FollowUpTable();
    tableSuivi.setIdtDde(IDT_DDE);
    Retour retour = RetourFactoryForTU.createRetour(StringConstants.OK, null, Diagnostic.DOUBLON_DEJA_TRAITE.toString(), null, null);

    //Prepare mock
    EasyMock.expect(SvcCommMimProxy.getInstance()).andReturn(_svcCommMimConnector);
    EasyMock.expectLastCall().anyTimes();
    EasyMock.expect(OAMProxy.getInstance()).andReturn(_oamConnector);
    EasyMock.expectLastCall().anyTimes();

    //Pour PM028_BL001_ControlerDonneesEntree
    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, SERVICE_MIM_1645)).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(new TypeServiceCommercialMIM(), true));
    EasyMock.expect(_oamConnector.insererDemandeSuivi(EasyMock.isA(Tracabilite.class), EasyMock.isA(FollowUpTable.class))).andReturn(new ConnectorResponse<FollowUpTable, Retour>(tableSuivi, retour));

    // On enregistre le scénario des appels
    PowerMock.replayAll();

    Request request = prepareRequest(_payload, _myHeader);
    Response response = executeStartProcess(request, DEFAULT_PROCESSNAME);

    PowerMock.verifyAll();

    Assert.assertEquals(null, response.getGenericResponse().getDataType());

    String result = response.getGenericResponse().getResult();
    Assert.assertNotNull(result);
    ProvisionnerPfiOut provisionnerPfiOut = MarshallTools.unmarshall(ProvisionnerPfiOut.class, result);
    Assert.assertEquals(ReponseTechniqueCodeRetour.OK, provisionnerPfiOut.getCodeRetour());
    Assert.assertNull(provisionnerPfiOut.getRaison());
    Assert.assertEquals(Diagnostic.AUCUN_PROVISIONING.toString(), provisionnerPfiOut.getDiagnostic());
  }

  /**
   * Test cas nominal provisioning KO car insererDemandeSuivi KO.
   *
   * @throws Throwable
   *           thrown throwable
   */
  @Test
  public void PM028_ProvisionnerPfiTest_InsererDemandeSuiviKO() throws Throwable
  {

    FollowUpTable tableSuivi = new FollowUpTable();
    tableSuivi.setIdtDde(IDT_DDE);
    Retour retour = RetourFactoryForTU.createRetour(StringConstants.KO, null, null, null, null);

    //Prepare mock
    EasyMock.expect(SvcCommMimProxy.getInstance()).andReturn(_svcCommMimConnector);
    EasyMock.expectLastCall().anyTimes();
    EasyMock.expect(OAMProxy.getInstance()).andReturn(_oamConnector);
    EasyMock.expectLastCall().anyTimes();

    //Pour PM028_BL001_ControlerDonneesEntree
    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, SERVICE_MIM_1645)).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(new TypeServiceCommercialMIM(), true));
    EasyMock.expect(_oamConnector.insererDemandeSuivi(EasyMock.isA(Tracabilite.class), EasyMock.isA(FollowUpTable.class))).andReturn(new ConnectorResponse<FollowUpTable, Retour>(tableSuivi, retour));

    // On enregistre le scénario des appels
    PowerMock.replayAll();

    Request request = prepareRequest(_payload, _myHeader);
    Response response = executeStartProcess(request, DEFAULT_PROCESSNAME);

    PowerMock.verifyAll();

    Assert.assertEquals(null, response.getGenericResponse().getDataType());

    String result = response.getGenericResponse().getResult();
    Assert.assertNotNull(result);
    ProvisionnerPfiOut provisionnerPfiOut = MarshallTools.unmarshall(ProvisionnerPfiOut.class, result);
    Assert.assertEquals(ReponseTechniqueCodeRetour.NOK, provisionnerPfiOut.getCodeRetour());
    Assert.assertEquals(Consts.DEF_2.toString(), provisionnerPfiOut.getRaison());
    Assert.assertEquals(Consts.SERVICE_INDISPONIBLE.toString(), provisionnerPfiOut.getDiagnostic());
  }

  /**
   * Test le cas d'erreur DONNEE_INCOHERENTE, entete de la message vide.
   *
   * @throws Throwable
   *           thrown throwable
   */
  @Test
  public void PM028_ProvisionnerPfiTest_MsgHeaderVide() throws Throwable
  {
    // On enregistre le scénario des appels
    PowerMock.replayAll();

    Request request = prepareRequest(readFile("src/test/resources/provisionnerPfiIn_request4.xml", StandardCharsets.UTF_8), new ArrayList<RequestHeader>()); //$NON-NLS-1$
    Response response = executeStartProcess(request, DEFAULT_PROCESSNAME);

    PowerMock.verifyAll();

    Assert.assertEquals(null, response.getGenericResponse().getDataType());

    String result = response.getGenericResponse().getResult();
    Assert.assertNotNull(result);
    ProvisionnerPfiOut provisionnerPfiOut = MarshallTools.unmarshall(ProvisionnerPfiOut.class, result);
    Assert.assertEquals(ReponseTechniqueCodeRetour.NOK, provisionnerPfiOut.getCodeRetour());
    Assert.assertEquals(Consts.DEF_4.toString(), provisionnerPfiOut.getRaison());
    Assert.assertEquals(Consts.DONNEE_INCOHERENTE.toString(), provisionnerPfiOut.getDiagnostic());
  }

  /**
   * Test Provisioning sans PortefeuilleIndividuels.
   *
   * @throws Throwable
   *           thrown exception
   */
  @Test
  public void PM028_ProvisionnerPfiTest_PortefeuilleIndividuelsVide() throws Throwable
  {
    String payload = readFile("src/test/resources/provisionnerPfiIn_requestAno320432_PortefeuilleVide.xml", StandardCharsets.UTF_8); //$NON-NLS-1$
    List<RequestHeader> myHeader = getHeader("src/test/resources/msgHeaderAno320432.xml"); //$NON-NLS-1$
    FollowUpTable tableSuivi = new FollowUpTable();
    Retour retour = RetourFactoryForTU.createRetour("OK", null, Diagnostic.PROVISIONING.toString(), null, null); //$NON-NLS-1$

    //Prepare mock
    EasyMock.expect(OAMProxy.getInstance()).andReturn(_oamConnector);
    EasyMock.expect(_oamConnector.insererDemandeSuivi(EasyMock.isA(Tracabilite.class), EasyMock.isA(FollowUpTable.class))).andReturn(new ConnectorResponse<FollowUpTable, Retour>(tableSuivi, retour));

    PowerMock.replayAll();

    //ANO 320432
    Request request = prepareRequest(payload, myHeader);
    Response response = executeStartProcess(request, DEFAULT_PROCESSNAME);

    PowerMock.verifyAll();

    String result = response.getGenericResponse().getResult();
    Assert.assertNotNull(result);
    ProvisionnerPfiOut provisionnerPfiOut = MarshallTools.unmarshall(ProvisionnerPfiOut.class, result);
    Assert.assertEquals(ReponseTechniqueCodeRetour.OK, provisionnerPfiOut.getCodeRetour());
    Assert.assertNull(provisionnerPfiOut.getRaison());
    Assert.assertEquals(Diagnostic.AUCUN_PROVISIONING.toString(), provisionnerPfiOut.getDiagnostic());
  }

  /**
   * Test Provisioning avec enrichissement requis mais consultation PFI KO.
   *
   * @throws Throwable
   *           thrown throwable
   */
  @Test
  public void PM028_ProvisionnerPfiTest_Provisioning_Consultation_PFI_KO() throws Throwable
  {
    FollowUpTable tableSuivi = new FollowUpTable();
    Retour retour = RetourFactoryForTU.createRetour("OK", null, Diagnostic.PROVISIONING.toString(), null, null); //$NON-NLS-1$
    RavelException erreur = new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.PRCESS_00002, "aille !!"); //$NON-NLS-1$

    TypeServiceCommercialMIM typeServiceCommercialMIM = new TypeServiceCommercialMIM();
    typeServiceCommercialMIM.setEnrichissementRefcliRequis(true);

    //Prepare mock
    EasyMock.expect(SvcCommMimProxy.getInstance()).andReturn(_svcCommMimConnector);
    EasyMock.expectLastCall().anyTimes();
    EasyMock.expect(OAMProxy.getInstance()).andReturn(_oamConnector);
    EasyMock.expectLastCall().anyTimes();
    EasyMock.expect(RefClientProxy.getInstance()).andReturn(_refClientConnector);

    //Pour PM028_BL001_ControlerDonneesEntree
    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, SERVICE_MIM_1645)).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(new TypeServiceCommercialMIM(), true));
    EasyMock.expect(_oamConnector.insererDemandeSuivi(EasyMock.isA(Tracabilite.class), EasyMock.isA(FollowUpTable.class))).andReturn(new ConnectorResponse<FollowUpTable, Retour>(tableSuivi, retour));

    //Pour PM028_BL100_DetecterConsulterPFI
    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, SERVICE_MIM_1645)).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(null, false));
    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, "2")).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(typeServiceCommercialMIM, true)); //$NON-NLS-1$

    //Pour PM028_BL300_MimToInk
    EasyMock.expect(_refClientConnector.consulterPFI(EasyMock.isA(Tracabilite.class), EasyMock.isA(ConsulterPFIIn.class), EasyMock.eq("RefClientConnector"))).andThrow(erreur); //$NON-NLS-1$

    EasyMock.expect(_oamConnector.mettreAJourDemandeSuivi(EasyMock.isA(Tracabilite.class), EasyMock.isA(FollowUpTable.class))).andReturn(new ConnectorResponse<Integer, Retour>(1, RetourFactoryForTU.createOkRetour()));

    PowerMock.replayAll();

    Request request = prepareRequest(_payload, _myHeader);
    Response response = executeStartProcess(request, DEFAULT_PROCESSNAME);

    PowerMock.verifyAll();

    Assert.assertEquals(null, response.getGenericResponse().getDataType());

    String result = response.getGenericResponse().getResult();
    Assert.assertNotNull(result);
    ProvisionnerPfiOut provisionnerPfiOut = MarshallTools.unmarshall(ProvisionnerPfiOut.class, result);
    Assert.assertEquals(provisionnerPfiOut.getCodeRetour(), ReponseTechniqueCodeRetour.NOK);
    Assert.assertEquals(provisionnerPfiOut.getRaison(), Consts.DEF_2.toString());
    Assert.assertEquals(provisionnerPfiOut.getDiagnostic(), Consts.SERVICE_INDISPONIBLE.toString());
  }

  /**
   * Test cas nominal provisioning avec enrichissement requis mais consultation REFCLI KO/INCONNU_PFI.
   *
   * @throws Throwable
   *           thrown throwable
   */
  @Test
  public void PM028_ProvisionnerPfiTest_ProvisioningAvecEnrichissementRequis_consulterPFI_KO_INCONNU_PFI() throws Throwable
  {
    FollowUpTable tableSuivi = new FollowUpTable();
    tableSuivi.setIdtDde(IDT_DDE);

    Retour retour = RetourFactoryForTU.createRetour(StringConstants.OK, null, Diagnostic.PROVISIONING.toString(), null, null);

    TypeServiceCommercialMIM typeServiceCommercialMIM = new TypeServiceCommercialMIM();
    typeServiceCommercialMIM.setEnrichissementRefcliRequis(true);

    DescriptionErreur descriptionErreur = new DescriptionErreur();
    descriptionErreur.setCode("INCONNU_PFI"); //$NON-NLS-1$

    ReponseServicePIVOTTYPEDansFluxCRFonctionnel reponseServicePIVOTTYPEDansFluxCRFonctionnel = new ReponseServicePIVOTTYPEDansFluxCRFonctionnel();
    reponseServicePIVOTTYPEDansFluxCRFonctionnel.setCodeErreur(EnumOKNOK.NOK);
    reponseServicePIVOTTYPEDansFluxCRFonctionnel.setDiagnostic("Aucun PFI trouve"); //$NON-NLS-1$
    reponseServicePIVOTTYPEDansFluxCRFonctionnel.setRaison(Consts.DEF_4.toString());
    reponseServicePIVOTTYPEDansFluxCRFonctionnel.setDescriptionErreur(descriptionErreur);

    ConsulterPFIReponseType consulterPFIReponseType = new ConsulterPFIReponseType();
    consulterPFIReponseType.setReponseService(reponseServicePIVOTTYPEDansFluxCRFonctionnel);

    com.bytel.spirit.common.connectors.ink.generated.Response responseInk = new com.bytel.spirit.common.connectors.ink.generated.Response();
    ResponseConnector responseConnector = new ResponseConnector(responseInk, null);

    //Prepare mock
    EasyMock.expect(SvcCommMimProxy.getInstance()).andReturn(_svcCommMimConnector);
    EasyMock.expectLastCall().anyTimes();
    EasyMock.expect(OAMProxy.getInstance()).andReturn(_oamConnector);
    EasyMock.expectLastCall().anyTimes();
    EasyMock.expect(InkProxy.getInstance()).andReturn(_ink001EnvoyerDemandeInk);
    EasyMock.expect(RefClientProxy.getInstance()).andReturn(_refClientConnector);
    EasyMock.expectLastCall().anyTimes();

    //Pour PM028_BL001_ControlerDonneesEntree
    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, SERVICE_MIM_1645)).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(new TypeServiceCommercialMIM(), true));
    EasyMock.expect(_oamConnector.insererDemandeSuivi(EasyMock.isA(Tracabilite.class), EasyMock.isA(FollowUpTable.class))).andReturn(new ConnectorResponse<FollowUpTable, Retour>(tableSuivi, retour));

    //Pour PM028_BL100_DetecterConsulterPFI
    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, SERVICE_MIM_1645)).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(null, false));
    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, "2")).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(typeServiceCommercialMIM, true)); //$NON-NLS-1$

    //Pour PM028_BL300_MimToInk
    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, SERVICE_MIM_1645)).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(null, false));
    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, "2")).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(null, false)); //$NON-NLS-1$

    EasyMock.expect(_refClientConnector.consulterPFI(EasyMock.isA(Tracabilite.class), EasyMock.isA(ConsulterPFIIn.class), EasyMock.eq("RefClientConnector"))).andReturn(new ConnectorResponse<ConsulterPFIReponseType, Integer>(consulterPFIReponseType, HTTP_OK)); //$NON-NLS-1$
    EasyMock.expectLastCall().anyTimes();

    EasyMock.expect(_oamConnector.mettreAJourDemandeSuivi(EasyMock.isA(Tracabilite.class), EasyMock.isA(FollowUpTable.class))).andReturn(new ConnectorResponse<Integer, Retour>(1, RetourFactoryForTU.createOkRetour()));

    EasyMock.expect(_ink001EnvoyerDemandeInk.envoyerDemandeInk(EasyMock.isA(com.bytel.spirit.common.connectors.ink.generated.Request.class), EasyMock.eq(Test_Consts.DEFAULT_MSGID), EasyMock.eq(IInkConnector.BEAN_ID))).andReturn(new ConnectorResponse<Integer, ResponseConnector>(HTTP_OK, responseConnector));

    // On enregistre le scénario des appels
    PowerMock.replayAll();

    Request request = prepareRequest(_payload, _myHeader);
    Response response = executeStartProcess(request, DEFAULT_PROCESSNAME);

    PowerMock.verifyAll();

    Assert.assertEquals(null, response.getGenericResponse().getDataType());

    String result = response.getGenericResponse().getResult();
    Assert.assertNotNull(result);
    ProvisionnerPfiOut provisionnerPfiOut = MarshallTools.unmarshall(ProvisionnerPfiOut.class, result);
    Assert.assertEquals(provisionnerPfiOut.getCodeRetour(), ReponseTechniqueCodeRetour.OK);
    Assert.assertNull(provisionnerPfiOut.getRaison());
    Assert.assertNull(provisionnerPfiOut.getDiagnostic());
  }

  /**
   * Add custom headers
   *
   * @param requestHeader_p
   *          request to add headers
   * @param tracabilite_p
   *          object to add headers from
   */
  private void addXHeaders(List<RequestHeader> requestHeader_p, Tracabilite tracabilite_p)
  {
    RequestHeader hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_REQUEST_ID);
    hdr.setValue(tracabilite_p.getIdCorrelationByTel());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_REQUEST_ID_SPIRIT);
    hdr.setValue(tracabilite_p.getIdCorrelationSpirit());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_SOURCE);
    hdr.setValue(tracabilite_p.getNomSysteme());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_PROCESS);
    hdr.setValue(tracabilite_p.getNomProcessus());
    requestHeader_p.add(hdr);

  }

  /**
   * Execute start process.
   *
   * @param request_p
   *          The input request.
   * @param processName_p
   *          The process name.
   * @return The response.
   * @throws Throwable
   *           The throwable.
   */
  private Response executeStartProcess(Request request_p, String processName_p) throws Throwable
  {
    Response ret = null;
    request_p.setOperation(processName_p);
    _currentInstance.run(request_p);
    ret = (Response) request_p.getResponse();
    return ret;
  }

  /**
   *
   * @param payload_p
   *          payload
   * @param myHeader_p
   *          header
   * @return prepared request
   * @throws RavelException
   *           thrown exception
   */
  private Request prepareRequest(String payload_p, List<RequestHeader> myHeader_p) throws RavelException
  {
    Request request = new Request(DEFAULT_PROCESSNAME, "idProcess", "idClient"); //$NON-NLS-1$ //$NON-NLS-2$
    request.setMsgId(Test_Consts.DEFAULT_MSGID);
    request.setPayload(payload_p);

    request.getRequestHeader().addAll(myHeader_p);
    addXHeaders(request.getRequestHeader(), _tracabilite);

    UrlParameters urlParametersType = new UrlParameters();
    request.setUrlParameters(urlParametersType);
    return request;
  }
}
