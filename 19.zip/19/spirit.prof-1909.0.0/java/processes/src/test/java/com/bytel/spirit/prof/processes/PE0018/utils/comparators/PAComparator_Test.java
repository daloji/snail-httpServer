/*******************************************************************************
* $Id: PAComparator_Test.java 17782 2019-02-28 07:32:04Z fbarnabe $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PE0018.utils.comparators;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.spirit.common.shared.saab.cmd.Commande;
import com.bytel.spirit.common.shared.saab.cmd.NatureCommande;
import com.bytel.spirit.common.shared.saab.rpg.ContexteInstallation;
import com.bytel.spirit.common.shared.saab.rpg.InfoBrutBssGp;
import com.bytel.spirit.common.shared.saab.rpg.PA;
import com.bytel.spirit.common.shared.saab.rpg.PFI;
import com.bytel.spirit.common.shared.saab.rpg.PaTypeCompteAcces;
import com.bytel.spirit.common.shared.saab.rpg.PaTypeFax;
import com.bytel.spirit.common.shared.saab.rpg.PaTypeLigneFixe;
import com.bytel.spirit.common.shared.saab.rpg.PaTypeTv;
import com.bytel.spirit.common.shared.saab.rpg.PaTypeVoip;
import com.bytel.spirit.common.shared.saab.rpg.RaccordementCommercial;
import com.bytel.spirit.common.shared.saab.rpg.Statut;
import com.bytel.spirit.prof.processes.PE0018.utils.PFIComparatorUtils;
import com.bytel.spirit.prof.processes.PE0018.utils.TypeModificationEnum;
import com.bytel.spirit.prof.processes.PE0018.utils.TypeObjectCommercialEnum;
import com.bytel.spirit.prof.shared.types.json.PointAccesCompteAcces;
import com.bytel.spirit.prof.shared.types.json.PointAccesFax;
import com.bytel.spirit.prof.shared.types.json.PointAccesLigneFixe;
import com.bytel.spirit.prof.shared.types.json.PointAccesTV;
import com.bytel.spirit.prof.shared.types.json.PointAccesVoip;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author jsantos
 * @version ($Revision: 17782 $ $Date: 2019-02-28 08:32:04 +0100 (jeu. 28 févr. 2019) $)
 */
public class PAComparator_Test implements IModificationPFI_Test
{
  /**
  *
  */
  private static final String ID_CMD = "idCmd"; //$NON-NLS-1$
  /**
  *
  */
  private static final String NO_COMPTE = "noCompte"; //$NON-NLS-1$
  /**
  *
  */
  private static final String CLIENT_OPERATEUR = "clientOperateur"; //$NON-NLS-1$

  /**
   * Factory de génération des beans
   */
  private static PodamFactory __podam;

  /**
   * Initialize before all tests
   *
   * @throws Exception
   *           Exception to be thrown in case of failure
   */
  @BeforeClass
  public static void setUpBeforeClass() throws Exception
  {
    // désactivation du cache podam
    __podam = new PodamFactoryImpl();
    __podam.getStrategy().setMemoization(false);
    __podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());
  }

  /**
   * Test case when is to create a PA
   */
  @Test
  public void testCreationPA_000() throws RavelException
  {
    Commande commande = new Commande();
    commande.setIdCmd(ID_CMD);

    PA paTarget = buildPA("pa1", PointAccesLigneFixe.TYPE); //$NON-NLS-1$
    PFI pfi = new PFI();
    pfi.setClientOperateur(CLIENT_OPERATEUR);
    pfi.setNoCompte(NO_COMPTE);

    PFIComparatorUtils result = new PFIComparatorUtils();
    PAComparator comparator = new PAComparator(pfi, commande, result, LocalDateTime.now());
    comparator.getPFIComparatorUtils().setAddUnchangedObjects(true);
    comparator.getPFIComparatorUtils().setPaTypeList(Arrays.asList("LIGNE_FIXE,VOIP,FAX,COMPTE_ACCES,TV".split(","))); //$NON-NLS-1$ //$NON-NLS-2$
    comparator.compare(null, paTarget);

    //Check EquipementDeclare
    assertEquals(Arrays.asList(paTarget), pfi.getPa());

    //Check ModificationCommercial
    assertEquals(commande.getIdCmd(), result.getMcList().get(0).getIdCmd());
    assertEquals(AbstractComparator.EN_COURS, result.getMcList().get(0).getStatut());
    assertEquals(TypeObjectCommercialEnum.PA.name(), result.getMcList().get(0).getTypeObjetCommercial());
    assertEquals(pfi.getNoCompte(), result.getMcList().get(0).getNoCompte());
    assertEquals(pfi.getClientOperateur(), result.getMcList().get(0).getClientOperateur());
    assertEquals(paTarget.getIdentifiantFonctionnelPA(), result.getMcList().get(0).getIdentifiantFonctionnelPA());

    //Check ElementComparaison
    assertEquals(TypeObjectCommercialEnum.PA.name(), result.getEcList().get(0).getTypeObjetCommercial());
    assertEquals(TypeModificationEnum.CREATION.name(), result.getEcList().get(0).getTypeOperation());
    assertEquals(pfi.getClientOperateur(), result.getEcList().get(0).getClientOperateur());
    assertEquals(pfi.getNoCompte(), result.getEcList().get(0).getNoCompte());
    assertEquals(paTarget.getIdentifiantFonctionnelPA(), result.getEcList().get(0).getIdentifiantFonctionnelPA());
  }

  /**
   * Test case compare multiple creation PAs of different types when only COMPTE_ACCES is actif.
   */
  @Test
  public void testCreationPA_002() throws RavelException
  {
    Commande commande = new Commande();
    PFI pfi = new PFI();
    PA paTargetCompteAcces = new PA("paCompteAcces1", "COMPTE_ACCES", Statut.ACTIF, null, null); //$NON-NLS-1$ //$NON-NLS-2$
    paTargetCompteAcces.setPaTypeCompteAcces(buildPaTypeCompteAcces());
    PA paTargetVoip = new PA("paCompteVoip1", "VOIP", Statut.ACTIF, null, null); //$NON-NLS-1$ //$NON-NLS-2$
    paTargetVoip.setPaTypeVoip(buildPaTypeVoip());
    PFIComparatorUtils result = new PFIComparatorUtils();

    PAComparator comparator = new PAComparator(pfi, commande, result, LocalDateTime.now());
    comparator.getPFIComparatorUtils().setAddUnchangedObjects(true);
    comparator.getPFIComparatorUtils().setPaTypeList(Arrays.asList("COMPTE_ACCES".split(","))); //$NON-NLS-1$ //$NON-NLS-2$
    comparator.compare(null, paTargetCompteAcces);
    comparator.compare(null, paTargetVoip);

    assertEquals(1, pfi.getPa().size());
    assertEquals(paTargetCompteAcces, pfi.getPa().get(0));
    //Check ModificationCommercial
    assertEquals(commande.getIdCmd(), result.getMcList().get(0).getIdCmd());
    assertEquals(AbstractComparator.EN_COURS, result.getMcList().get(0).getStatut());
    assertEquals(TypeObjectCommercialEnum.PA.name(), result.getMcList().get(0).getTypeObjetCommercial());
    assertEquals(pfi.getNoCompte(), result.getMcList().get(0).getNoCompte());
    assertEquals(commande.getClientOperateur(), result.getMcList().get(0).getClientOperateur());
    assertEquals(paTargetCompteAcces.getIdentifiantFonctionnelPA(), result.getMcList().get(0).getIdentifiantFonctionnelPA());
    //Check ElementComparaison
    assertEquals(TypeObjectCommercialEnum.PA.name(), result.getEcList().get(0).getTypeObjetCommercial());
    assertEquals(TypeModificationEnum.CREATION.name(), result.getEcList().get(0).getTypeOperation());
    //    assertEquals(paTargetCompteAcces.getIdentifiantFonctionnelPA(), result.getEcList().get(0).getIdObjetCommercial());
  }

  /**
   * Test case when two PAs are equals
   */
  @Test
  public void testEqualsPA_001() throws RavelException
  {
    Commande commande = new Commande();
    PFI pfi = new PFI();
    PA paSource = buildPA("pa1", PointAccesLigneFixe.TYPE); //$NON-NLS-1$
    PFIComparatorUtils result = new PFIComparatorUtils();
    addPAToPFI(pfi, paSource);
    PAComparator comparator = new PAComparator(pfi, commande, result, LocalDateTime.now());
    comparator.getPFIComparatorUtils().setAddUnchangedObjects(true);
    comparator.getPFIComparatorUtils().setPaTypeList(Arrays.asList("LIGNE_FIXE,VOIP,FAX,COMPTE_ACCES,TV".split(","))); //$NON-NLS-1$ //$NON-NLS-2$
    comparator.compare(paSource, paSource);

    assertEquals(1, pfi.getPa().size());
    //Check ModificationCommercial
    assertEquals(0, result.getMcList().size());
    //Check ElementComparaison
    assertEquals(TypeObjectCommercialEnum.PA.name(), result.getEcList().get(0).getTypeObjetCommercial());
    assertEquals(TypeModificationEnum.AUCUNE.name(), result.getEcList().get(0).getTypeOperation());
    //    assertEquals(paSource.getIdentifiantFonctionnelPA(), result.getEcList().get(0).getIdObjetCommercial());
    assertEquals(0, result.getEcList().get(0).getListeAttributModifie().size());
  }

  /**
   * Test case when two PAs are equals
   */
  @Test
  public void testEqualsPA_002() throws RavelException
  {
    Commande commande = new Commande();
    PFI pfi = new PFI();
    PA paSource = buildPA("pa1", PointAccesLigneFixe.TYPE); //$NON-NLS-1$
    PFIComparatorUtils result = new PFIComparatorUtils();
    addPAToPFI(pfi, paSource);
    PAComparator comparator = new PAComparator(pfi, commande, result, LocalDateTime.now());
    comparator.getPFIComparatorUtils().setAddUnchangedObjects(false);
    comparator.getPFIComparatorUtils().setPaTypeList(Arrays.asList("LIGNE_FIXE,VOIP,FAX,COMPTE_ACCES,TV".split(","))); //$NON-NLS-1$ //$NON-NLS-2$
    comparator.compare(paSource, paSource);

    assertEquals(1, pfi.getPa().size());
    //Check ModificationCommercial
    assertEquals(0, result.getMcList().size());
    //Check ElementComparaison
    assertEquals(0, result.getEcList().size());
  }

  /**
   * Modification of a PA in a PFI from a Commande with NatureCommande MODIFICATION <br>
   *
   * <b>Inputs:</b> Commande with NatureCommande = MODIFICATION \ TypePA = PointAccesLigneFixe \ All PA attributes are
   * differents<br>
   * <b>Expected:</b> Modification done with a complete copy of the PA <br>
   */
  @Test
  public void testModificationPA_MODIFICATION_001() throws RavelException
  {
    Commande commande = new Commande();
    commande.setNatureCommande(NatureCommande.MODIFICATION_PFI.name());

    PFI pfi = new PFI();
    PA paSource = buildPA("pa1", PointAccesLigneFixe.TYPE); //$NON-NLS-1$
    addPAToPFI(pfi, paSource);

    //In order to keep old values
    RaccordementCommercial raccordementCommercialInitial = paSource.getPaTypeLigneFixe().getRaccordementCommercial();
    InfoBrutBssGp infoBrutBssGpInitial = paSource.getPaTypeLigneFixe().getInfoBrutBssGp();
    ContexteInstallation contexteInstallationInitial = paSource.getPaTypeLigneFixe().getContexteInstallation();

    PA paTarget = new PA(null, PointAccesLigneFixe.TYPE, null, null, null);
    paTarget.setIdentifiantFonctionnelPA(paSource.getIdentifiantFonctionnelPA()); //IDs need to be equals
    PaTypeLigneFixe paTypeLigneFixe = new PaTypeLigneFixe();
    paTypeLigneFixe.setDatePriseEnCompteChangementStatut(paSource.getPaTypeLigneFixe().getDatePriseEnCompteChangementStatut());
    paTypeLigneFixe.setIdRaccordement("new_idRaccordement"); //$NON-NLS-1$
    paTypeLigneFixe.setDistance(2);
    paTypeLigneFixe.setVlan("new_vlan"); //$NON-NLS-1$
    paTarget.setPaTypeLigneFixe(paTypeLigneFixe);

    PFIComparatorUtils result = new PFIComparatorUtils();
    PAComparator comparator = new PAComparator(pfi, commande, result, LocalDateTime.now());
    comparator.getPFIComparatorUtils().setAddUnchangedObjects(true);
    comparator.getPFIComparatorUtils().setPaTypeList(Arrays.asList("LIGNE_FIXE,VOIP,FAX,COMPTE_ACCES,TV".split(","))); //$NON-NLS-1$ //$NON-NLS-2$
    comparator.compare(paSource, paTarget);

    //Check PA
    //Assert new values from paTarget
    assertEquals(paTarget.getPaTypeLigneFixe().getDatePriseEnCompteChangementStatut(), pfi.getPa().get(0).getPaTypeLigneFixe().getDatePriseEnCompteChangementStatut());
    assertEquals(paTarget.getPaTypeLigneFixe().getIdRaccordement(), pfi.getPa().get(0).getPaTypeLigneFixe().getIdRaccordement());
    assertEquals(paTarget.getPaTypeLigneFixe().getDistance(), pfi.getPa().get(0).getPaTypeLigneFixe().getDistance());
    assertEquals(paTarget.getPaTypeLigneFixe().getVlan(), pfi.getPa().get(0).getPaTypeLigneFixe().getVlan());

    //Assert unchanged initial values
    assertEquals(raccordementCommercialInitial, pfi.getPa().get(0).getPaTypeLigneFixe().getRaccordementCommercial());
    assertEquals(infoBrutBssGpInitial, pfi.getPa().get(0).getPaTypeLigneFixe().getInfoBrutBssGp());
    assertEquals(contexteInstallationInitial, pfi.getPa().get(0).getPaTypeLigneFixe().getContexteInstallation());
    assertEquals("pa1", pfi.getPa().get(0).getIdentifiantFonctionnelPA()); //$NON-NLS-1$
    assertEquals(IModificationValue_Test.ID_FONCTIONNEL_PA_LIE, pfi.getPa().get(0).getIdentifiantFonctionnelPALie());
    assertNull(pfi.getPa().get(0).getDateCreation());
    assertNotNull(pfi.getPa().get(0).getDateModification());
    assertNull(pfi.getPa().get(0).getPaTypeVoip());
    assertNull(pfi.getPa().get(0).getPaTypeFax());
    assertNull(pfi.getPa().get(0).getPaTypeTv());
    assertNull(pfi.getPa().get(0).getPaTypeCompteAcces());
    assertNull(pfi.getPa().get(0).getPaTypeCompteAccesSecondaire());

    //Check ModificationCommercial
    assertEquals(1, result.getMcList().size());

    //Check ElementComparaison
    assertEquals(TypeObjectCommercialEnum.PA.name(), result.getEcList().get(0).getTypeObjetCommercial());
    assertEquals(TypeModificationEnum.MODIF_ATTR.name(), result.getEcList().get(0).getTypeOperation());
    assertEquals(paTarget.getIdentifiantFonctionnelPA(), result.getEcList().get(0).getIdentifiantFonctionnelPA());
    assertEquals(3, result.getEcList().get(0).getListeAttributModifie().size());
  }

  /**
   * Modification of a PA in a PFI from a Commande with NatureCommande MODIFICATION <br>
   *
   * <b>Inputs:</b> Commande with NatureCommande = MODIFICATION \ TypePA = PointAccesLigneFixe \ PaTypeLigneFixe = null
   * \ All PA attributes are differents<br>
   * <b>Expected:</b> Modification done with a complete copy of the PA <br>
   */
  //  @Test
  public void testModificationPA_MODIFICATION_002() throws RavelException
  {
    Commande commande = new Commande();
    commande.setNatureCommande(NatureCommande.MODIFICATION_PFI.name());

    PFI pfi = new PFI();
    PA paSource = buildPA("pa1", PointAccesLigneFixe.TYPE); //$NON-NLS-1$
    paSource.setPaTypeLigneFixe(null);
    addPAToPFI(pfi, paSource);

    PA paTarget = buildPA("pa2", PointAccesLigneFixe.TYPE); //$NON-NLS-1$
    paTarget.setIdentifiantFonctionnelPA(paSource.getIdentifiantFonctionnelPA()); //IDs need to be equals
    //    paTarget.getPaTypeLigneFixe().setDatePriseEnCompteChangementStatut(paSource.getPaTypeLigneFixe().getDatePriseEnCompteChangementStatut());

    PFIComparatorUtils result = new PFIComparatorUtils();
    PAComparator comparator = new PAComparator(pfi, commande, result, LocalDateTime.now());
    comparator.getPFIComparatorUtils().setAddUnchangedObjects(true);
    comparator.getPFIComparatorUtils().setPaTypeList(Arrays.asList("LIGNE_FIXE,VOIP,FAX,COMPTE_ACCES,TV".split(","))); //$NON-NLS-1$ //$NON-NLS-2$
    comparator.compare(paSource, paTarget);

    //Check PA
    assertFalse(pfi.getPa().contains(paSource));
    assertTrue(pfi.getPa().contains(paTarget));

    //Check ModificationCommercial
    assertEquals(1, result.getMcList().size());

    //Check ElementComparaison
    assertEquals(TypeObjectCommercialEnum.PA.name(), result.getEcList().get(0).getTypeObjetCommercial());
    assertEquals(TypeModificationEnum.MODIF_ATTR.name(), result.getEcList().get(0).getTypeOperation());
    assertEquals(paTarget.getIdentifiantFonctionnelPA(), result.getEcList().get(0).getIdentifiantFonctionnelPA());
    assertEquals(43, result.getEcList().get(0).getListeAttributModifie().size());
  }

  /**
   * Modification of a PA in a PFI from a Commande with NatureCommande MODIFICATION <br>
   *
   * <b>Inputs:</b> Commande with NatureCommande = MODIFICATION \ TypePA = PointAccesCompteAcces \
   * PaTypeCompteAcces.emailLogin = emailLogin<br>
   * <b>Expected:</b> Modification done with a copy of the delta between PA source and target
   * (paTypeCompteAcces.emailLogin = emailLogin)<br>
   */
  @Test
  public void testModificationPA_MODIFICATION_003() throws RavelException
  {
    Commande commande = new Commande();
    commande.setNatureCommande(NatureCommande.MODIFICATION_PFI.name());

    PFI pfi = new PFI();
    PA paSource = buildPA("pa1", PointAccesCompteAcces.TYPE); //$NON-NLS-1$
    addPAToPFI(pfi, paSource);

    PA paTarget = new PA(null, PointAccesCompteAcces.TYPE, null, null, null);
    paTarget.setIdentifiantFonctionnelPA(paSource.getIdentifiantFonctionnelPA()); //IDs need to be equals
    paTarget.setPaTypeCompteAcces(new PaTypeCompteAcces("new_emailLogin")); //$NON-NLS-1$

    PFIComparatorUtils result = new PFIComparatorUtils();
    PAComparator comparator = new PAComparator(pfi, commande, result, LocalDateTime.now());
    comparator.getPFIComparatorUtils().setAddUnchangedObjects(true);
    comparator.getPFIComparatorUtils().setPaTypeList(Arrays.asList("LIGNE_FIXE,VOIP,FAX,COMPTE_ACCES,TV".split(","))); //$NON-NLS-1$ //$NON-NLS-2$
    comparator.compare(paSource, paTarget);

    //Only the EmailLogin from PaTyypeCompteAcces has changed : new value is the one from paTarget
    assertEquals(paTarget.getPaTypeCompteAcces().getEmailLogin(), pfi.getPa().get(0).getPaTypeCompteAcces().getEmailLogin());
    assertEquals("pa1", pfi.getPa().get(0).getIdentifiantFonctionnelPA()); //$NON-NLS-1$
    assertEquals(IModificationValue_Test.ID_FONCTIONNEL_PA_LIE, pfi.getPa().get(0).getIdentifiantFonctionnelPALie());
    assertNull(pfi.getPa().get(0).getDateCreation());
    assertNotNull(pfi.getPa().get(0).getDateModification());
    assertNull(pfi.getPa().get(0).getPaTypeLigneFixe());
    assertNull(pfi.getPa().get(0).getPaTypeVoip());
    assertNull(pfi.getPa().get(0).getPaTypeFax());
    assertNull(pfi.getPa().get(0).getPaTypeTv());
    assertNull(pfi.getPa().get(0).getPaTypeCompteAccesSecondaire());

    //Check ModificationCommercial
    assertEquals(1, result.getMcList().size());

    //Check ElementComparaison
    assertEquals(TypeObjectCommercialEnum.PA.name(), result.getEcList().get(0).getTypeObjetCommercial());
    assertEquals(TypeModificationEnum.MODIF_ATTR.name(), result.getEcList().get(0).getTypeOperation());
    assertEquals(paTarget.getIdentifiantFonctionnelPA(), result.getEcList().get(0).getIdentifiantFonctionnelPA());
    assertEquals(1, result.getEcList().get(0).getListeAttributModifie().size());
  }

  /**
   * Modification of a PA in a PFI from a Commande with NatureCommande MODIFICATION <br>
   *
   * <b>Inputs:</b> Commande with NatureCommande = MODIFICATION \ TypePA = PointAccesCompteAcces \
   * PaTypeCompteAcces.emailLogin = null<br>
   * <b>Expected:</b> No modification done<br>
   */
  @Test
  @Ignore(value = "Useless because if emailLogin==null, then no MODIFICATION")
  public void testModificationPA_MODIFICATION_004() throws RavelException
  {
    Commande commande = new Commande();
    commande.setNatureCommande(NatureCommande.MODIFICATION_PFI.name());

    PFI pfi = new PFI();
    PA paSource = buildPA("pa1", PointAccesCompteAcces.TYPE); //$NON-NLS-1$
    addPAToPFI(pfi, paSource);

    PA paTarget = new PA(null, PointAccesCompteAcces.TYPE, null, null, null);
    paTarget.setIdentifiantFonctionnelPA(paSource.getIdentifiantFonctionnelPA()); //IDs need to be equals
    paTarget.setPaTypeCompteAcces(new PaTypeCompteAcces(null));

    PFIComparatorUtils result = new PFIComparatorUtils();
    PAComparator comparator = new PAComparator(pfi, commande, result, LocalDateTime.now());
    comparator.getPFIComparatorUtils().setAddUnchangedObjects(true);
    comparator.getPFIComparatorUtils().setPaTypeList(Arrays.asList("LIGNE_FIXE,VOIP,FAX,COMPTE_ACCES,TV".split(","))); //$NON-NLS-1$ //$NON-NLS-2$
    comparator.compare(paSource, paTarget);

    //EmailLogin from PaTypeCompteAcces in paTarget is null : no changes for paSource
    assertEquals(paSource, pfi.getPa().get(0));

    //Check ModificationCommercial
    assertEquals(0, result.getMcList().size());

    //Check ElementComparaison
    assertEquals(TypeObjectCommercialEnum.PA.name(), result.getEcList().get(0).getTypeObjetCommercial());
    assertEquals(TypeModificationEnum.AUCUNE.name(), result.getEcList().get(0).getTypeOperation());
    assertEquals(paTarget.getIdentifiantFonctionnelPA(), result.getEcList().get(0).getIdentifiantFonctionnelPA());
    assertEquals(0, result.getEcList().get(0).getListeAttributModifie().size());
  }

  /**
   * Modification of a PA in a PFI from a Commande with NatureCommande MODIFICATION <br>
   *
   * <b>Inputs:</b> Commande with NatureCommande = MODIFICATION \ TypePA = PointAccesTV \ PaTypeTV.idCompteTv =
   * idCompteTv<br>
   * <b>Expected:</b> Modification done with a copy of the delta between PA source and target (PaTypeTV.idCompteTv =
   * idCompteTv)<br>
   */
  @Test
  public void testModificationPA_MODIFICATION_005() throws RavelException
  {
    Commande commande = new Commande();
    commande.setNatureCommande(NatureCommande.MODIFICATION_PFI.name());

    PFI pfi = new PFI();
    PA paSource = buildPA("pa1", PointAccesTV.TYPE); //$NON-NLS-1$
    addPAToPFI(pfi, paSource);

    PA paTarget = new PA(null, PointAccesTV.TYPE, null, null, null);
    paTarget.setIdentifiantFonctionnelPA(paSource.getIdentifiantFonctionnelPA()); //IDs need to be equals
    paTarget.setPaTypeTv(new PaTypeTv("new_idCompteTv", null)); //$NON-NLS-1$

    PFIComparatorUtils result = new PFIComparatorUtils();
    PAComparator comparator = new PAComparator(pfi, commande, result, LocalDateTime.now());
    comparator.getPFIComparatorUtils().setAddUnchangedObjects(true);
    comparator.getPFIComparatorUtils().setPaTypeList(Arrays.asList("LIGNE_FIXE,VOIP,FAX,COMPTE_ACCES,TV".split(","))); //$NON-NLS-1$ //$NON-NLS-2$
    comparator.compare(paSource, paTarget);

    //Only the idCompteTV from PaTypeTV has changed : new value is the one from paTarget
    assertEquals(paTarget.getPaTypeTv().getIdCompteTv(), pfi.getPa().get(0).getPaTypeTv().getIdCompteTv());
    assertEquals(IModificationValue_Test.ID_CONTENU_TV, pfi.getPa().get(0).getPaTypeTv().getIdContenuTv());
    assertEquals("pa1", pfi.getPa().get(0).getIdentifiantFonctionnelPA());
    assertEquals(IModificationValue_Test.ID_FONCTIONNEL_PA_LIE, pfi.getPa().get(0).getIdentifiantFonctionnelPALie());
    assertNull(pfi.getPa().get(0).getDateCreation());
    assertNotNull(pfi.getPa().get(0).getDateModification());

    //Check ModificationCommercial
    assertEquals(1, result.getMcList().size());

    //Check ElementComparaison
    assertEquals(TypeObjectCommercialEnum.PA.name(), result.getEcList().get(0).getTypeObjetCommercial());
    assertEquals(TypeModificationEnum.MODIF_ATTR.name(), result.getEcList().get(0).getTypeOperation());
    assertEquals(paTarget.getIdentifiantFonctionnelPA(), result.getEcList().get(0).getIdentifiantFonctionnelPA());
    assertEquals(1, result.getEcList().get(0).getListeAttributModifie().size());
  }

  /**
   * Modification of a PA in a PFI from a Commande with NatureCommande MODIFICATION <br>
   *
   * <b>Inputs:</b> Commande with NatureCommande = MODIFICATION \ TypePA = PointAccesTV \ PaTypeTV.idContenuTv =
   * idContenuTv<br>
   * <b>Expected:</b> Modification done with a copy of the delta between PA source and target (PaTypeTV.idContenuTv =
   * idContenuTv)<br>
   */
  @Test
  public void testModificationPA_MODIFICATION_006() throws RavelException
  {
    Commande commande = new Commande();
    commande.setNatureCommande(NatureCommande.MODIFICATION_PFI.name());

    PFI pfi = new PFI();
    PA paSource = buildPA("pa1", PointAccesTV.TYPE); //$NON-NLS-1$
    addPAToPFI(pfi, paSource);

    PA paTarget = new PA(null, PointAccesTV.TYPE, null, null, null);
    paTarget.setIdentifiantFonctionnelPA(paSource.getIdentifiantFonctionnelPA()); //IDs need to be equals
    paTarget.setPaTypeTv(new PaTypeTv(null, "new_idContenuTv")); //$NON-NLS-1$

    PFIComparatorUtils result = new PFIComparatorUtils();
    PAComparator comparator = new PAComparator(pfi, commande, result, LocalDateTime.now());
    comparator.getPFIComparatorUtils().setAddUnchangedObjects(true);
    comparator.getPFIComparatorUtils().setPaTypeList(Arrays.asList("LIGNE_FIXE,VOIP,FAX,COMPTE_ACCES,TV".split(","))); //$NON-NLS-1$ //$NON-NLS-2$
    comparator.compare(paSource, paTarget);

    //Check new values from paTarget: only the idContenuTv has changed
    assertEquals(paTarget.getPaTypeTv().getIdContenuTv(), pfi.getPa().get(0).getPaTypeTv().getIdContenuTv());
    assertNotNull(pfi.getPa().get(0).getDateModification());
    //check unchanged values
    assertEquals(IModificationValue_Test.ID_COMPTE_TV, pfi.getPa().get(0).getPaTypeTv().getIdCompteTv());
    assertEquals("pa1", pfi.getPa().get(0).getIdentifiantFonctionnelPA());
    assertEquals(IModificationValue_Test.ID_FONCTIONNEL_PA_LIE, pfi.getPa().get(0).getIdentifiantFonctionnelPALie());
    assertNull(pfi.getPa().get(0).getDateCreation());

    //Check ModificationCommercial
    assertEquals(1, result.getMcList().size());

    //Check ElementComparaison
    assertEquals(TypeObjectCommercialEnum.PA.name(), result.getEcList().get(0).getTypeObjetCommercial());
    assertEquals(TypeModificationEnum.MODIF_ATTR.name(), result.getEcList().get(0).getTypeOperation());
    assertEquals(paTarget.getIdentifiantFonctionnelPA(), result.getEcList().get(0).getIdentifiantFonctionnelPA());
    assertEquals(1, result.getEcList().get(0).getListeAttributModifie().size());
  }

  /**
   * Modification of a PA in a PFI from a Commande with NatureCommande MODIFICATION <br>
   *
   * <b>Inputs:</b> Commande with NatureCommande = MODIFICATION \ TypePA = PointAccesVoip \ PaTypeVoip.numeroTelephone =
   * numeroTelephone<br>
   * <b>Expected:</b> Modification done with a copy of the delta between PA source and target
   * (PaTypeVoip.numeroTelephone = numeroTelephone)<br>
   */
  @Test
  public void testModificationPA_MODIFICATION_007() throws RavelException
  {
    Commande commande = new Commande();
    commande.setNatureCommande(NatureCommande.MODIFICATION_PFI.name());

    PFI pfi = new PFI();
    PA paSource = buildPA("pa1", PointAccesVoip.TYPE); //$NON-NLS-1$
    addPAToPFI(pfi, paSource);

    PA paTarget = new PA(null, PointAccesVoip.TYPE, null, null, null);
    paTarget.setIdentifiantFonctionnelPA(paSource.getIdentifiantFonctionnelPA()); //IDs need to be equals
    paTarget.setPaTypeVoip(new PaTypeVoip("new_numeroTelephone", null, null)); //$NON-NLS-1$

    PFIComparatorUtils result = new PFIComparatorUtils();
    PAComparator comparator = new PAComparator(pfi, commande, result, LocalDateTime.now());
    comparator.getPFIComparatorUtils().setAddUnchangedObjects(true);
    comparator.getPFIComparatorUtils().setPaTypeList(Arrays.asList("LIGNE_FIXE,VOIP,FAX,COMPTE_ACCES,TV".split(","))); //$NON-NLS-1$ //$NON-NLS-2$
    comparator.compare(paSource, paTarget);

    //Check new values from paTarget: only the numeroTelephone has changed
    assertEquals(paTarget.getPaTypeVoip().getNumeroTelephone(), pfi.getPa().get(0).getPaTypeVoip().getNumeroTelephone());
    assertNotNull(pfi.getPa().get(0).getDateModification());
    //Check unchanged values
    assertEquals(IModificationValue_Test.CODE_RIO, pfi.getPa().get(0).getPaTypeVoip().getCodeRio());
    assertEquals(IModificationValue_Test.NUMERO_PORT_TELEPHONIQUE, pfi.getPa().get(0).getPaTypeVoip().getNumeroPortTelephonique().intValue());
    assertEquals("pa1", pfi.getPa().get(0).getIdentifiantFonctionnelPA());
    assertEquals(IModificationValue_Test.ID_FONCTIONNEL_PA_LIE, pfi.getPa().get(0).getIdentifiantFonctionnelPALie());
    assertNull(pfi.getPa().get(0).getDateCreation());

    //Check ModificationCommercial
    assertEquals(1, result.getMcList().size());

    //Check ElementComparaison
    assertEquals(TypeObjectCommercialEnum.PA.name(), result.getEcList().get(0).getTypeObjetCommercial());
    assertEquals(TypeModificationEnum.MODIF_ATTR.name(), result.getEcList().get(0).getTypeOperation());
    assertEquals(paTarget.getIdentifiantFonctionnelPA(), result.getEcList().get(0).getIdentifiantFonctionnelPA());
    assertEquals(1, result.getEcList().get(0).getListeAttributModifie().size());
  }

  /**
   * Modification of a PA in a PFI from a Commande with NatureCommande MODIFICATION <br>
   *
   * <b>Inputs:</b> Commande with NatureCommande = MODIFICATION \ TypePA = PointAccesVoip \ PaTypeVoip.codeRio = codeRio
   * and PaTypeVoip.numeroPortTelephonique = 2<br>
   * <b>Expected:</b> Modification done with a copy of the delta between PA source and target (PaTypeVoip.codeRio =
   * codeRio and PaTypeVoip.numeroPortTelephonique = 2)<br>
   */
  @Test
  public void testModificationPA_MODIFICATION_008() throws RavelException
  {
    Commande commande = new Commande();
    commande.setNatureCommande(NatureCommande.MODIFICATION_PFI.name());

    PFI pfi = new PFI();
    PA paSource = buildPA("pa1", PointAccesVoip.TYPE); //$NON-NLS-1$
    addPAToPFI(pfi, paSource);

    PA paTarget = new PA(null, PointAccesVoip.TYPE, null, null, null);
    paTarget.setIdentifiantFonctionnelPA(paSource.getIdentifiantFonctionnelPA()); //IDs need to be equals
    paTarget.setPaTypeVoip(new PaTypeVoip(null, "new_codeRio", 2)); //$NON-NLS-1$

    PFIComparatorUtils result = new PFIComparatorUtils();
    PAComparator comparator = new PAComparator(pfi, commande, result, LocalDateTime.now());
    comparator.getPFIComparatorUtils().setAddUnchangedObjects(true);
    comparator.getPFIComparatorUtils().setPaTypeList(Arrays.asList("LIGNE_FIXE,VOIP,FAX,COMPTE_ACCES,TV".split(","))); //$NON-NLS-1$ //$NON-NLS-2$
    comparator.compare(paSource, paTarget);

    //Check new values from paTarget: only the codeRio and numeroPortTelephonique from PaTypeVoip
    assertEquals(paTarget.getPaTypeVoip().getCodeRio(), pfi.getPa().get(0).getPaTypeVoip().getCodeRio());
    assertEquals(paTarget.getPaTypeVoip().getNumeroPortTelephonique(), pfi.getPa().get(0).getPaTypeVoip().getNumeroPortTelephonique());
    assertNotNull(pfi.getPa().get(0).getDateModification());
    //Check unchanged values
    assertEquals(IModificationValue_Test.NUMERO_TELEPHONE, pfi.getPa().get(0).getPaTypeVoip().getNumeroTelephone());
    assertEquals("pa1", pfi.getPa().get(0).getIdentifiantFonctionnelPA());
    assertEquals(IModificationValue_Test.ID_FONCTIONNEL_PA_LIE, pfi.getPa().get(0).getIdentifiantFonctionnelPALie());
    assertNull(pfi.getPa().get(0).getDateCreation());

    //Check ModificationCommercial
    assertEquals(1, result.getMcList().size());

    //Check ElementComparaison
    assertEquals(TypeObjectCommercialEnum.PA.name(), result.getEcList().get(0).getTypeObjetCommercial());
    assertEquals(TypeModificationEnum.MODIF_ATTR.name(), result.getEcList().get(0).getTypeOperation());
    assertEquals(paTarget.getIdentifiantFonctionnelPA(), result.getEcList().get(0).getIdentifiantFonctionnelPA());
    assertEquals(2, result.getEcList().get(0).getListeAttributModifie().size());
  }

  /**
   * Modification of a PA in a PFI from a Commande with NatureCommande MODIFICATION <br>
   *
   * <b>Inputs:</b> Commande with NatureCommande = MODIFICATION \ TypePA = PointAccesFax \ All PA attributes are
   * differents<br>
   * <b>Expected:</b> Modification done with a copy of the delta between PA source and target <br>
   */
  @Test
  public void testModificationPA_MODIFICATION_009() throws RavelException
  {
    Commande commande = new Commande();
    commande.setNatureCommande(NatureCommande.MODIFICATION_PFI.name());

    PFI pfi = new PFI();
    PA paSource = buildPA("pa1", PointAccesFax.TYPE); //$NON-NLS-1$
    addPAToPFI(pfi, paSource);

    PA paTarget = new PA(null, PointAccesFax.TYPE, null, null, null);
    paTarget.setIdentifiantFonctionnelPA(paSource.getIdentifiantFonctionnelPA()); //IDs need to be equals
    paTarget.setPaTypeFax(new PaTypeFax("new_numeroTelephone")); //$NON-NLS-1$

    PFIComparatorUtils result = new PFIComparatorUtils();
    PAComparator comparator = new PAComparator(pfi, commande, result, LocalDateTime.now());
    comparator.getPFIComparatorUtils().setAddUnchangedObjects(true);
    comparator.getPFIComparatorUtils().setPaTypeList(Arrays.asList("LIGNE_FIXE,VOIP,FAX,COMPTE_ACCES,TV".split(","))); //$NON-NLS-1$ //$NON-NLS-2$
    comparator.compare(paSource, paTarget);

    //Only the numeroTelephone from PaTypeFax has changed : new value is the one from paTarget
    assertEquals(paTarget.getPaTypeFax().getNumeroTelephone(), pfi.getPa().get(0).getPaTypeFax().getNumeroTelephone());
    assertNotNull(pfi.getPa().get(0).getDateModification());
    //Check unchaned values
    assertEquals("pa1", pfi.getPa().get(0).getIdentifiantFonctionnelPA());
    assertEquals(IModificationValue_Test.ID_FONCTIONNEL_PA_LIE, pfi.getPa().get(0).getIdentifiantFonctionnelPALie());
    assertNull(pfi.getPa().get(0).getDateCreation());
    assertNull(pfi.getPa().get(0).getPaTypeLigneFixe());
    assertNull(pfi.getPa().get(0).getPaTypeVoip());
    assertNull(pfi.getPa().get(0).getPaTypeTv());
    assertNull(pfi.getPa().get(0).getPaTypeCompteAcces());
    assertNull(pfi.getPa().get(0).getPaTypeCompteAccesSecondaire());

    //Check ModificationCommercial
    assertEquals(1, result.getMcList().size());

    //Check ElementComparaison
    assertEquals(TypeObjectCommercialEnum.PA.name(), result.getEcList().get(0).getTypeObjetCommercial());
    assertEquals(TypeModificationEnum.MODIF_ATTR.name(), result.getEcList().get(0).getTypeOperation());
    assertEquals(paTarget.getIdentifiantFonctionnelPA(), result.getEcList().get(0).getIdentifiantFonctionnelPA());
    assertEquals(1, result.getEcList().get(0).getListeAttributModifie().size());
  }

  /**
   * Modification of a PA in a PFI from a Commande with NatureCommande MODIFICATION <br>
   *
   * <b>Inputs:</b> Commande with NatureCommande = MODIFICATION \ TypePA = PointAccesFax \ PaTypeFax = null \ All PA
   * attributes are differents<br>
   * <b>Expected:</b> Modification done with a copy of the delta between PA source and target <br>
   */
  @Test
  @Ignore(value = "Useless because if numeroTelephone==null, then no MODIFICATION")
  public void testModificationPA_MODIFICATION_010() throws RavelException
  {
    Commande commande = new Commande();
    commande.setNatureCommande(NatureCommande.MODIFICATION_PFI.name());

    PFI pfi = new PFI();
    PA paSource = buildPA("pa1", PointAccesFax.TYPE); //$NON-NLS-1$
    addPAToPFI(pfi, paSource);

    PA paTarget = new PA(null, PointAccesFax.TYPE, null, null, null);
    paTarget.setIdentifiantFonctionnelPA(paSource.getIdentifiantFonctionnelPA()); //IDs need to be equals
    paTarget.setPaTypeFax(new PaTypeFax(null));

    PFIComparatorUtils result = new PFIComparatorUtils();
    PAComparator comparator = new PAComparator(pfi, commande, result, LocalDateTime.now());
    comparator.getPFIComparatorUtils().setAddUnchangedObjects(true);
    comparator.getPFIComparatorUtils().setPaTypeList(Arrays.asList("LIGNE_FIXE,VOIP,FAX,COMPTE_ACCES,TV".split(","))); //$NON-NLS-1$ //$NON-NLS-2$
    comparator.compare(paSource, paTarget);

    //numeroTelephone from PaTypeFax in paTarget is null : no changes for paSource
    assertEquals(paSource, pfi.getPa().get(0));

    //Check ModificationCommercial
    assertEquals(0, result.getMcList().size());

    //Check ElementComparaison
    assertEquals(TypeObjectCommercialEnum.PA.name(), result.getEcList().get(0).getTypeObjetCommercial());
    assertEquals(TypeModificationEnum.AUCUNE.name(), result.getEcList().get(0).getTypeOperation());
    assertEquals(paTarget.getIdentifiantFonctionnelPA(), result.getEcList().get(0).getIdentifiantFonctionnelPA());
    assertEquals(0, result.getEcList().get(0).getListeAttributModifie().size());
  }

  /**
   * CAS PATRICE
   *
   * Modification of a PA in a PFI from a Commande with NatureCommande MODIFICATION <br>
   *
   * <b>Inputs:</b> Commande with NatureCommande = MODIFICATION \ TypePA = PointAccesLigneFixe \ Only the distance of
   * the PaTypeLigneFixe in the target is changed (other attributes are null)<br>
   * <b>Expected:</b> Modification done with a copy of the delta between PA source and target (only the distance is
   * changed) <br>
   */
  @Test
  public void testModificationPA_MODIFICATION_011() throws RavelException
  {
    Commande commande = new Commande();
    commande.setNatureCommande(NatureCommande.MODIFICATION_PFI.name());

    PFI pfi = GsonTools.getIso8601Ms().fromJson(
        "{\"clientOperateur\":\"BSS_ENT\",\"noCompte\":\"0712959296\",\"ligneMarche\":\"ENT\",\"datePhoto\":\"2019-02-20T10:05:25.086+0100\",\"titulaire\":{\"typeTitulaire\":\"ENTREPRISE\",\"noPersonne\":\"0712959296\",\"noTel\":\"+33699884202\",\"email\":\"bddd.ddddd@bbox.fr\",\"individu\":{\"civilite\":\"M.\",\"nom\":\"BENIIII\",\"prenom\":\"DODODOD\"},\"entreprise\":{\"noSiren\":\"521152108\",\"raisonSociale\":\"SSSSS-EMPLOI\"},\"dateCreation\":\"2019-02-20T10:05:26.580+0100\",\"dateModification\":\"2019-02-20T10:05:26.580+0100\"},\"listeSA\":[],\"listePA\":[{\"identifiantFonctionnelPA\":\"0712959296\",\"typePA\":\"LIGNE_FIXE\",\"dateCreation\":\"2019-02-20T10:05:26.555+0100\",\"dateModification\":\"2019-02-20T10:05:26.580+0100\",\"paTypeLigneFixe\":{\"contexteInstallation\":{\"typeMes\":\"N\"},\"raccordementCommercial\":{\"accesTechniqueCommercial\":{\"technologieAcces\":\"P2P\",\"codeAccesTechnique\":\"XYZ\"},\"codeNro\":\"SI544520\"},\"distance\":20},\"typeObjetCommercial\":\"PA\",\"statut\":\"ACTIF\"}],\"listeLienSAPA\":[],\"listeEqtDeclare\":[],\"listeLienEqtPA\":[],\"dateCreation\":\"2019-02-20T10:05:26.555+0100\",\"dateModification\":\"2019-02-20T10:05:26.580+0100\",\"typeObjetCommercial\":\"PFI\",\"statut\":\"ACTIF\"}", //$NON-NLS-1$
        PFI.class);
    PA paSource = pfi.getPa().get(0);

    PA paTarget = new PA("0712959296", PointAccesLigneFixe.TYPE, null, null, null); //$NON-NLS-1$
    PaTypeLigneFixe paTypeLigneFixe = new PaTypeLigneFixe();
    paTypeLigneFixe.setDistance(10);
    paTarget.setPaTypeLigneFixe(paTypeLigneFixe);

    PFIComparatorUtils result = new PFIComparatorUtils();
    PAComparator comparator = new PAComparator(pfi, commande, result, LocalDateTime.now());
    comparator.getPFIComparatorUtils().setAddUnchangedObjects(true);
    comparator.getPFIComparatorUtils().setPaTypeList(Arrays.asList("LIGNE_FIXE,VOIP,FAX,COMPTE_ACCES,TV".split(","))); //$NON-NLS-1$ //$NON-NLS-2$
    comparator.compare(paSource, paTarget);

    //Check PA
    assertNull(pfi.getPa().get(0).getPaTypeLigneFixe().getDatePriseEnCompteChangementStatut());
    assertNull(pfi.getPa().get(0).getPaTypeLigneFixe().getIdRaccordement());
    assertEquals(paTarget.getPaTypeLigneFixe().getDistance(), pfi.getPa().get(0).getPaTypeLigneFixe().getDistance());
    assertNull(pfi.getPa().get(0).getPaTypeLigneFixe().getVlan());
    assertEquals(paSource.getPaTypeLigneFixe().getRaccordementCommercial(), pfi.getPa().get(0).getPaTypeLigneFixe().getRaccordementCommercial());
    assertEquals(paSource.getPaTypeLigneFixe().getInfoBrutBssGp(), pfi.getPa().get(0).getPaTypeLigneFixe().getInfoBrutBssGp());
    assertEquals(paSource.getPaTypeLigneFixe().getContexteInstallation(), pfi.getPa().get(0).getPaTypeLigneFixe().getContexteInstallation());
    assertEquals(paSource.getIdentifiantFonctionnelPA(), pfi.getPa().get(0).getIdentifiantFonctionnelPA());
    assertEquals(paSource.getIdentifiantFonctionnelPALie(), pfi.getPa().get(0).getIdentifiantFonctionnelPALie());
    assertEquals(paSource.getDateCreation(), pfi.getPa().get(0).getDateCreation());
    assertEquals(paSource.getDateModification(), pfi.getPa().get(0).getDateModification());
    assertEquals(paSource.getPaTypeVoip(), pfi.getPa().get(0).getPaTypeVoip());
    assertEquals(paSource.getPaTypeFax(), pfi.getPa().get(0).getPaTypeFax());
    assertEquals(paSource.getPaTypeTv(), pfi.getPa().get(0).getPaTypeTv());
    assertEquals(paSource.getPaTypeCompteAcces(), pfi.getPa().get(0).getPaTypeCompteAcces());
    assertEquals(paSource.getPaTypeCompteAccesSecondaire(), pfi.getPa().get(0).getPaTypeCompteAccesSecondaire());

    //Check ModificationCommercial
    assertEquals(1, result.getMcList().size());

    //Check ElementComparaison
    assertEquals(TypeObjectCommercialEnum.PA.name(), result.getEcList().get(0).getTypeObjetCommercial());
    assertEquals(TypeModificationEnum.MODIF_ATTR.name(), result.getEcList().get(0).getTypeOperation());
    assertEquals(paTarget.getIdentifiantFonctionnelPA(), result.getEcList().get(0).getIdentifiantFonctionnelPA());
    assertEquals(1, result.getEcList().get(0).getListeAttributModifie().size());
  }

  /**
   * Modification of a PA in a PFI from a Commande with NatureCommande PHOTO <br>
   *
   * <b>Inputs:</b> Commande with NatureCommande = PHOTO \ TypePA = PointAccesLigneFixe \ All PA attributes are
   * differents<br>
   * <b>Expected:</b> Modification done with a complete copy of the PA <br>
   */
  @Test
  public void testModificationPA_PHOTO_001() throws RavelException
  {
    Commande commande = new Commande();
    commande.setNatureCommande(NatureCommande.PHOTO_PFI.name());

    PFI pfi = new PFI();
    PA paSource = buildPA("pa1", PointAccesLigneFixe.TYPE); //$NON-NLS-1$
    addPAToPFI(pfi, paSource);

    PA paTarget = __podam.manufacturePojoWithFullData(PA.class);
    paTarget.setIdentifiantFonctionnelPA(paSource.getIdentifiantFonctionnelPA()); //IDs need to be equals
    paTarget.setTypePA(PointAccesLigneFixe.TYPE);
    paTarget.setStatut(Statut.ACTIF);
    paTarget.setIdentifiantFonctionnelPALie(IModificationValue_Test.ID_FONCTIONNEL_PA_LIE);
    paTarget.getPaTypeLigneFixe().setDatePriseEnCompteChangementStatut(paSource.getPaTypeLigneFixe().getDatePriseEnCompteChangementStatut());

    PFIComparatorUtils result = new PFIComparatorUtils();
    PAComparator comparator = new PAComparator(pfi, commande, result, LocalDateTime.now());
    comparator.getPFIComparatorUtils().setAddUnchangedObjects(true);
    comparator.getPFIComparatorUtils().setPaTypeList(Arrays.asList("LIGNE_FIXE,VOIP,FAX,COMPTE_ACCES,TV".split(","))); //$NON-NLS-1$ //$NON-NLS-2$
    comparator.compare(paSource, paTarget);

    //Check PA
    assertFalse(pfi.getPa().contains(paSource));
    assertTrue(pfi.getPa().contains(paTarget));

    //Check ModificationCommercial
    assertEquals(1, result.getMcList().size());

    //Check ElementComparaison
    assertEquals(TypeObjectCommercialEnum.PA.name(), result.getEcList().get(0).getTypeObjetCommercial());
    assertEquals(TypeModificationEnum.MODIF_ATTR.name(), result.getEcList().get(0).getTypeOperation());
    assertEquals(paTarget.getIdentifiantFonctionnelPA(), result.getEcList().get(0).getIdentifiantFonctionnelPA());
    assertEquals(40, result.getEcList().get(0).getListeAttributModifie().size());
  }

  /**
   * Modification of a PA in a PFI from a Commande with NatureCommande PHOTO <br>
   *
   * <b>Inputs:</b> Commande with NatureCommande = PHOTO \ TypePA = PointAccesLigneFixe \ PaTypeLigneFixe = null \ All
   * PA attributes are differents<br>
   * <b>Expected:</b> Modification done with a complete copy of the PA <br>
   */
  @Test
  public void testModificationPA_PHOTO_002() throws RavelException
  {
    Commande commande = new Commande();
    commande.setNatureCommande(NatureCommande.PHOTO_PFI.name());

    PFI pfi = new PFI();
    PA paSource = buildPA("pa1", PointAccesLigneFixe.TYPE); //$NON-NLS-1$
    paSource.setPaTypeLigneFixe(null);
    addPAToPFI(pfi, paSource);

    PA paTarget = __podam.manufacturePojoWithFullData(PA.class);
    paTarget.setIdentifiantFonctionnelPA(paSource.getIdentifiantFonctionnelPA()); //IDs need to be equals
    paTarget.setTypePA(PointAccesLigneFixe.TYPE);
    paTarget.setStatut(Statut.ACTIF);
    paTarget.setIdentifiantFonctionnelPALie(IModificationValue_Test.ID_FONCTIONNEL_PA_LIE);

    PFIComparatorUtils result = new PFIComparatorUtils();
    PAComparator comparator = new PAComparator(pfi, commande, result, LocalDateTime.now());
    comparator.getPFIComparatorUtils().setAddUnchangedObjects(true);
    comparator.getPFIComparatorUtils().setPaTypeList(Arrays.asList("LIGNE_FIXE,VOIP,FAX,COMPTE_ACCES,TV".split(","))); //$NON-NLS-1$ //$NON-NLS-2$
    comparator.compare(paSource, paTarget);

    //Check PA
    assertFalse(pfi.getPa().contains(paSource));
    assertTrue(pfi.getPa().contains(paTarget));

    //Check ModificationCommercial
    assertEquals(1, result.getMcList().size());

    //Check ElementComparaison
    assertEquals(TypeObjectCommercialEnum.PA.name(), result.getEcList().get(0).getTypeObjetCommercial());
    assertEquals(TypeModificationEnum.MODIF_ATTR.name(), result.getEcList().get(0).getTypeOperation());
    assertEquals(paTarget.getIdentifiantFonctionnelPA(), result.getEcList().get(0).getIdentifiantFonctionnelPA());
    assertEquals(44, result.getEcList().get(0).getListeAttributModifie().size());
  }

  /**
   * Modification of a PA in a PFI from a Commande with NatureCommande PHOTO <br>
   *
   * <b>Inputs:</b> Commande with NatureCommande = PHOTO \ TypePA = PointAccesCompteAcces \ All PA attributes are
   * differents<br>
   * <b>Expected:</b> Modification done with a complete copy of the PA <br>
   */
  @Test
  public void testModificationPA_PHOTO_003() throws RavelException
  {
    Commande commande = new Commande();
    commande.setNatureCommande(NatureCommande.PHOTO_PFI.name());

    PFI pfi = new PFI();
    PA paSource = buildPA("pa1", PointAccesCompteAcces.TYPE); //$NON-NLS-1$
    addPAToPFI(pfi, paSource);

    PA paTarget = __podam.manufacturePojoWithFullData(PA.class);
    paTarget.setIdentifiantFonctionnelPA(paSource.getIdentifiantFonctionnelPA()); //IDs need to be equals
    paTarget.setTypePA(PointAccesCompteAcces.TYPE);
    paTarget.setStatut(Statut.ACTIF);

    PFIComparatorUtils result = new PFIComparatorUtils();
    PAComparator comparator = new PAComparator(pfi, commande, result, LocalDateTime.now());
    comparator.getPFIComparatorUtils().setAddUnchangedObjects(true);
    comparator.getPFIComparatorUtils().setPaTypeList(Arrays.asList("LIGNE_FIXE,VOIP,FAX,COMPTE_ACCES,TV".split(","))); //$NON-NLS-1$ //$NON-NLS-2$
    comparator.compare(paSource, paTarget);

    //Check PA
    assertFalse(pfi.getPa().contains(paSource));
    assertTrue(pfi.getPa().contains(paTarget));

    //Check ModificationCommercial
    assertEquals(1, result.getMcList().size());

    //Check ElementComparaison
    assertEquals(TypeObjectCommercialEnum.PA.name(), result.getEcList().get(0).getTypeObjetCommercial());
    assertEquals(TypeModificationEnum.MODIF_ATTR.name(), result.getEcList().get(0).getTypeOperation());
    assertEquals(paTarget.getIdentifiantFonctionnelPA(), result.getEcList().get(0).getIdentifiantFonctionnelPA());
    assertEquals(2, result.getEcList().get(0).getListeAttributModifie().size());
  }

  /**
   * Modification of a PA in a PFI from a Commande with NatureCommande PHOTO <br>
   *
   * <b>Inputs:</b> Commande with NatureCommande = PHOTO \ TypePA = PointAccesCompteAcces \ PaTypeCompteAcces = null \
   * All PA attributes are differents<br>
   * <b>Expected:</b> Modification done with a complete copy of the PA <br>
   */
  @Test
  public void testModificationPA_PHOTO_004() throws RavelException
  {
    Commande commande = new Commande();
    commande.setNatureCommande(NatureCommande.PHOTO_PFI.name());

    PFI pfi = new PFI();
    PA paSource = buildPA("pa1", PointAccesCompteAcces.TYPE); //$NON-NLS-1$
    paSource.setPaTypeCompteAcces(null);
    addPAToPFI(pfi, paSource);

    PA paTarget = __podam.manufacturePojoWithFullData(PA.class);
    paTarget.setIdentifiantFonctionnelPA(paSource.getIdentifiantFonctionnelPA()); //IDs need to be equals
    paTarget.setTypePA(PointAccesCompteAcces.TYPE);
    paTarget.setStatut(Statut.ACTIF);

    PFIComparatorUtils result = new PFIComparatorUtils();
    PAComparator comparator = new PAComparator(pfi, commande, result, LocalDateTime.now());
    comparator.getPFIComparatorUtils().setAddUnchangedObjects(true);
    comparator.getPFIComparatorUtils().setPaTypeList(Arrays.asList("LIGNE_FIXE,VOIP,FAX,COMPTE_ACCES,TV".split(","))); //$NON-NLS-1$ //$NON-NLS-2$
    comparator.compare(paSource, paTarget);

    //Check PA
    assertFalse(pfi.getPa().contains(paSource));
    assertTrue(pfi.getPa().contains(paTarget));

    //Check ModificationCommercial
    assertEquals(1, result.getMcList().size());

    //Check ElementComparaison
    assertEquals(TypeObjectCommercialEnum.PA.name(), result.getEcList().get(0).getTypeObjetCommercial());
    assertEquals(TypeModificationEnum.MODIF_ATTR.name(), result.getEcList().get(0).getTypeOperation());
    assertEquals(paTarget.getIdentifiantFonctionnelPA(), result.getEcList().get(0).getIdentifiantFonctionnelPA());
    assertEquals(2, result.getEcList().get(0).getListeAttributModifie().size());
  }

  /**
   * Modification of a PA in a PFI from a Commande with NatureCommande PHOTO <br>
   *
   * <b>Inputs:</b> Commande with NatureCommande = PHOTO \ TypePA = PointAccesTV \ All PA attributes are differents<br>
   * <b>Expected:</b> Modification done with a complete copy of the PA <br>
   */
  @Test
  public void testModificationPA_PHOTO_005() throws RavelException
  {
    Commande commande = new Commande();
    commande.setNatureCommande(NatureCommande.PHOTO_PFI.name());

    PFI pfi = new PFI();
    PA paSource = buildPA("pa1", PointAccesTV.TYPE); //$NON-NLS-1$
    addPAToPFI(pfi, paSource);

    PA paTarget = __podam.manufacturePojoWithFullData(PA.class);
    paTarget.setIdentifiantFonctionnelPA(paSource.getIdentifiantFonctionnelPA()); //IDs need to be equals
    paTarget.setTypePA(PointAccesTV.TYPE);
    paTarget.setStatut(Statut.ACTIF);

    PFIComparatorUtils result = new PFIComparatorUtils();
    PAComparator comparator = new PAComparator(pfi, commande, result, LocalDateTime.now());
    comparator.getPFIComparatorUtils().setAddUnchangedObjects(true);
    comparator.getPFIComparatorUtils().setPaTypeList(Arrays.asList("LIGNE_FIXE,VOIP,FAX,COMPTE_ACCES,TV".split(","))); //$NON-NLS-1$ //$NON-NLS-2$
    comparator.compare(paSource, paTarget);

    //Check PA
    assertFalse(pfi.getPa().contains(paSource));
    assertTrue(pfi.getPa().contains(paTarget));

    //Check ModificationCommercial
    assertEquals(1, result.getMcList().size());

    //Check ElementComparaison
    assertEquals(TypeObjectCommercialEnum.PA.name(), result.getEcList().get(0).getTypeObjetCommercial());
    assertEquals(TypeModificationEnum.MODIF_ATTR.name(), result.getEcList().get(0).getTypeOperation());
    assertEquals(paTarget.getIdentifiantFonctionnelPA(), result.getEcList().get(0).getIdentifiantFonctionnelPA());
    assertEquals(3, result.getEcList().get(0).getListeAttributModifie().size());
  }

  /**
   * Modification of a PA in a PFI from a Commande with NatureCommande PHOTO <br>
   *
   * <b>Inputs:</b> Commande with NatureCommande = PHOTO \ TypePA = PointAccesTV \ PaTypeTV = null \ All PA attributes
   * are differents<br>
   * <b>Expected:</b> Modification done with a complete copy of the PA <br>
   */
  @Test
  public void testModificationPA_PHOTO_006() throws RavelException
  {
    Commande commande = new Commande();
    commande.setNatureCommande(NatureCommande.PHOTO_PFI.name());

    PFI pfi = new PFI();
    PA paSource = buildPA("pa1", PointAccesTV.TYPE); //$NON-NLS-1$
    paSource.setPaTypeTv(null);
    addPAToPFI(pfi, paSource);

    PA paTarget = __podam.manufacturePojoWithFullData(PA.class);
    paTarget.setIdentifiantFonctionnelPA(paSource.getIdentifiantFonctionnelPA()); //IDs need to be equals
    paTarget.setTypePA(PointAccesTV.TYPE);
    paTarget.setStatut(Statut.ACTIF);

    PFIComparatorUtils result = new PFIComparatorUtils();
    PAComparator comparator = new PAComparator(pfi, commande, result, LocalDateTime.now());
    comparator.getPFIComparatorUtils().setAddUnchangedObjects(true);
    comparator.getPFIComparatorUtils().setPaTypeList(Arrays.asList("LIGNE_FIXE,VOIP,FAX,COMPTE_ACCES,TV".split(","))); //$NON-NLS-1$ //$NON-NLS-2$
    comparator.compare(paSource, paTarget);

    //Check PA
    assertFalse(pfi.getPa().contains(paSource));
    assertTrue(pfi.getPa().contains(paTarget));

    //Check ModificationCommercial
    assertEquals(1, result.getMcList().size());

    //Check ElementComparaison
    assertEquals(TypeObjectCommercialEnum.PA.name(), result.getEcList().get(0).getTypeObjetCommercial());
    assertEquals(TypeModificationEnum.MODIF_ATTR.name(), result.getEcList().get(0).getTypeOperation());
    assertEquals(paTarget.getIdentifiantFonctionnelPA(), result.getEcList().get(0).getIdentifiantFonctionnelPA());
    assertEquals(3, result.getEcList().get(0).getListeAttributModifie().size());
  }

  /**
   * Modification of a PA in a PFI from a Commande with NatureCommande PHOTO <br>
   *
   * <b>Inputs:</b> Commande with NatureCommande = PHOTO \ TypePA = PointAccesVoip \ All PA attributes are
   * differents<br>
   * <b>Expected:</b> Modification done with a complete copy of the PA <br>
   */
  @Test
  public void testModificationPA_PHOTO_007() throws RavelException
  {
    Commande commande = new Commande();
    commande.setNatureCommande(NatureCommande.PHOTO_PFI.name());

    PFI pfi = new PFI();
    PA paSource = buildPA("pa1", PointAccesVoip.TYPE); //$NON-NLS-1$
    addPAToPFI(pfi, paSource);

    PA paTarget = __podam.manufacturePojoWithFullData(PA.class);
    paTarget.setIdentifiantFonctionnelPA(paSource.getIdentifiantFonctionnelPA()); //IDs need to be equals
    paTarget.setTypePA(PointAccesVoip.TYPE);
    paTarget.setStatut(Statut.ACTIF);
    paTarget.getPaTypeVoip().setNumeroPortTelephonique(2);//in order to change all attributes in PATypeVoip (portTelephonique is always in constructor)

    PFIComparatorUtils result = new PFIComparatorUtils();
    PAComparator comparator = new PAComparator(pfi, commande, result, LocalDateTime.now());
    comparator.getPFIComparatorUtils().setAddUnchangedObjects(true);
    comparator.getPFIComparatorUtils().setPaTypeList(Arrays.asList("LIGNE_FIXE,VOIP,FAX,COMPTE_ACCES,TV".split(","))); //$NON-NLS-1$ //$NON-NLS-2$
    comparator.compare(paSource, paTarget);

    //Check PA
    assertFalse(pfi.getPa().contains(paSource));
    assertTrue(pfi.getPa().contains(paTarget));

    //Check ModificationCommercial
    assertEquals(1, result.getMcList().size());

    //Check ElementComparaison
    assertEquals(TypeObjectCommercialEnum.PA.name(), result.getEcList().get(0).getTypeObjetCommercial());
    assertEquals(TypeModificationEnum.MODIF_ATTR.name(), result.getEcList().get(0).getTypeOperation());
    assertEquals(paTarget.getIdentifiantFonctionnelPA(), result.getEcList().get(0).getIdentifiantFonctionnelPA());
    assertEquals(4, result.getEcList().get(0).getListeAttributModifie().size());
  }

  /**
   * Modification of a PA in a PFI from a Commande with NatureCommande PHOTO <br>
   *
   * <b>Inputs:</b> Commande with NatureCommande = PHOTO \ TypePA = PointAccesVoip \ PaTypeVoip = null \ All PA
   * attributes are differents<br>
   * <b>Expected:</b> Modification done with a complete copy of the PA <br>
   */
  @Test
  public void testModificationPA_PHOTO_008() throws RavelException
  {
    Commande commande = new Commande();
    commande.setNatureCommande(NatureCommande.PHOTO_PFI.name());

    PFI pfi = new PFI();
    PA paSource = buildPA("pa1", PointAccesVoip.TYPE); //$NON-NLS-1$
    paSource.setPaTypeVoip(null);
    addPAToPFI(pfi, paSource);

    PA paTarget = __podam.manufacturePojoWithFullData(PA.class);
    paTarget.setIdentifiantFonctionnelPA(paSource.getIdentifiantFonctionnelPA()); //IDs need to be equals
    paTarget.setTypePA(PointAccesVoip.TYPE);
    paTarget.setStatut(Statut.ACTIF);
    paTarget.getPaTypeVoip().setNumeroPortTelephonique(2);//in order to change all attributes in PATypeVoip (portTelephonique is always in constructor)

    PFIComparatorUtils result = new PFIComparatorUtils();
    PAComparator comparator = new PAComparator(pfi, commande, result, LocalDateTime.now());
    comparator.getPFIComparatorUtils().setAddUnchangedObjects(true);
    comparator.getPFIComparatorUtils().setPaTypeList(Arrays.asList("LIGNE_FIXE,VOIP,FAX,COMPTE_ACCES,TV".split(","))); //$NON-NLS-1$ //$NON-NLS-2$
    comparator.compare(paSource, paTarget);

    //Check PA
    assertFalse(pfi.getPa().contains(paSource));
    assertTrue(pfi.getPa().contains(paTarget));

    //Check ModificationCommercial
    assertEquals(1, result.getMcList().size());

    //Check ElementComparaison
    assertEquals(TypeObjectCommercialEnum.PA.name(), result.getEcList().get(0).getTypeObjetCommercial());
    assertEquals(TypeModificationEnum.MODIF_ATTR.name(), result.getEcList().get(0).getTypeOperation());
    assertEquals(paTarget.getIdentifiantFonctionnelPA(), result.getEcList().get(0).getIdentifiantFonctionnelPA());
    assertEquals(4, result.getEcList().get(0).getListeAttributModifie().size());
  }

  /**
   * Modification of a PA in a PFI from a Commande with NatureCommande PHOTO <br>
   *
   * <b>Inputs:</b> Commande with NatureCommande = PHOTO \ TypePA = PointAccesFax \ All PA attributes are differents<br>
   * <b>Expected:</b> Modification done with a complete copy of the PA <br>
   */
  @Test
  public void testModificationPA_PHOTO_009() throws RavelException
  {
    Commande commande = new Commande();
    commande.setNatureCommande(NatureCommande.PHOTO_PFI.name());

    PFI pfi = new PFI();
    PA paSource = buildPA("pa1", PointAccesFax.TYPE); //$NON-NLS-1$
    addPAToPFI(pfi, paSource);

    PA paTarget = __podam.manufacturePojoWithFullData(PA.class);
    paTarget.setIdentifiantFonctionnelPA(paSource.getIdentifiantFonctionnelPA()); //IDs need to be equals
    paTarget.setTypePA(PointAccesFax.TYPE);
    paTarget.setStatut(Statut.ACTIF);

    PFIComparatorUtils result = new PFIComparatorUtils();
    PAComparator comparator = new PAComparator(pfi, commande, result, LocalDateTime.now());
    comparator.getPFIComparatorUtils().setAddUnchangedObjects(true);
    comparator.getPFIComparatorUtils().setPaTypeList(Arrays.asList("LIGNE_FIXE,VOIP,FAX,COMPTE_ACCES,TV".split(","))); //$NON-NLS-1$ //$NON-NLS-2$
    comparator.compare(paSource, paTarget);

    //Check PA
    assertFalse(pfi.getPa().contains(paSource));
    assertTrue(pfi.getPa().contains(paTarget));

    //Check ModificationCommercial
    assertEquals(1, result.getMcList().size());

    //Check ElementComparaison
    assertEquals(TypeObjectCommercialEnum.PA.name(), result.getEcList().get(0).getTypeObjetCommercial());
    assertEquals(TypeModificationEnum.MODIF_ATTR.name(), result.getEcList().get(0).getTypeOperation());
    assertEquals(paTarget.getIdentifiantFonctionnelPA(), result.getEcList().get(0).getIdentifiantFonctionnelPA());
    assertEquals(2, result.getEcList().get(0).getListeAttributModifie().size());
  }

  /**
   * Modification of a PA in a PFI from a Commande with NatureCommande PHOTO <br>
   *
   * <b>Inputs:</b> Commande with NatureCommande = PHOTO \ TypePA = PointAccesFax \ PaTypeFax = null \ All PA attributes
   * are differents<br>
   * <b>Expected:</b> Modification done with a complete copy of the PA <br>
   */
  @Test
  public void testModificationPA_PHOTO_010() throws RavelException
  {
    Commande commande = new Commande();
    commande.setNatureCommande(NatureCommande.PHOTO_PFI.name());

    PFI pfi = new PFI();
    PA paSource = buildPA("pa1", PointAccesFax.TYPE); //$NON-NLS-1$
    paSource.setPaTypeFax(null);
    addPAToPFI(pfi, paSource);

    PA paTarget = __podam.manufacturePojoWithFullData(PA.class);
    paTarget.setIdentifiantFonctionnelPA(paSource.getIdentifiantFonctionnelPA()); //IDs need to be equals
    paTarget.setTypePA(PointAccesFax.TYPE);
    paTarget.setStatut(Statut.ACTIF);

    PFIComparatorUtils result = new PFIComparatorUtils();
    PAComparator comparator = new PAComparator(pfi, commande, result, LocalDateTime.now());
    comparator.getPFIComparatorUtils().setAddUnchangedObjects(true);
    comparator.getPFIComparatorUtils().setPaTypeList(Arrays.asList("LIGNE_FIXE,VOIP,FAX,COMPTE_ACCES,TV".split(","))); //$NON-NLS-1$ //$NON-NLS-2$
    comparator.compare(paSource, paTarget);

    //Check PA
    assertFalse(pfi.getPa().contains(paSource));
    assertTrue(pfi.getPa().contains(paTarget));

    //Check ModificationCommercial
    assertEquals(1, result.getMcList().size());

    //Check ElementComparaison
    assertEquals(TypeObjectCommercialEnum.PA.name(), result.getEcList().get(0).getTypeObjetCommercial());
    assertEquals(TypeModificationEnum.MODIF_ATTR.name(), result.getEcList().get(0).getTypeOperation());
    assertEquals(paTarget.getIdentifiantFonctionnelPA(), result.getEcList().get(0).getIdentifiantFonctionnelPA());
    assertEquals(2, result.getEcList().get(0).getListeAttributModifie().size());
  }

  /**
   * Test case when is to delete a PA
   */
  @Test
  public void testSuppressionPA_003() throws RavelException
  {
    Commande commande = new Commande();
    PFI pfi = new PFI();
    PA paSource = buildPA("pa1", PointAccesLigneFixe.TYPE); //$NON-NLS-1$
    PFIComparatorUtils result = new PFIComparatorUtils();
    result.setAddUnchangedObjects(true);
    result.setPaTypeList(Arrays.asList("LIGNE_FIXE,VOIP,FAX,COMPTE_ACCES,TV".split(","))); //$NON-NLS-1$ //$NON-NLS-2$
    addPAToPFI(pfi, paSource);
    PAComparator comparator = new PAComparator(pfi, commande, result, LocalDateTime.now());
    comparator.compare(paSource, null);

    assertEquals(1, pfi.getPa().size());
    assertEquals(Statut.RESILIE, pfi.getPa().get(0).getStatut());
    //Check ModificationCommercial
    assertEquals(commande.getIdCmd(), result.getMcList().get(0).getIdCmd());
    assertEquals(AbstractComparator.EN_COURS, result.getMcList().get(0).getStatut());
    assertEquals(TypeObjectCommercialEnum.PA.name(), result.getMcList().get(0).getTypeObjetCommercial());
    assertEquals(pfi.getNoCompte(), result.getMcList().get(0).getNoCompte());
    assertEquals(commande.getClientOperateur(), result.getMcList().get(0).getClientOperateur());
    assertEquals(paSource.getIdentifiantFonctionnelPA(), result.getMcList().get(0).getIdentifiantFonctionnelPA());
    assertEquals(Statut.RESILIE.name(), result.getMcList().get(0).getStatutCommercialAttendu());
    //Check ElementComparaison
    assertEquals(TypeObjectCommercialEnum.PA.name(), result.getEcList().get(0).getTypeObjetCommercial());
    assertEquals(TypeModificationEnum.SUPPRESSION.name(), result.getEcList().get(0).getTypeOperation());
    //    assertEquals(paSource.getIdentifiantFonctionnelPA(), result.getEcList().get(0).getIdObjetCommercial());
    assertEquals(0, result.getEcList().get(0).getListeAttributModifie().size());
  }

  /**
   * @param pfi
   * @param paSource
   */
  private void addPAToPFI(PFI pfi, PA paSource)
  {
    List<PA> paList = pfi.getPa();
    paList.add(paSource);
    pfi.setPa(paList);
  }

}
