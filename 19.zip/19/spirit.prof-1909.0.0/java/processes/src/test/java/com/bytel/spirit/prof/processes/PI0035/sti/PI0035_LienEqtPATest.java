/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PI0035.sti;

import static org.junit.Assert.assertEquals;

import java.time.LocalDateTime;

import org.junit.BeforeClass;
import org.junit.Test;

import com.bytel.ravel.common.datetime.DateTimeManager;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.spirit.common.shared.saab.rpg.LienEquipementPA;
import com.bytel.spirit.common.shared.saab.rpg.Statut;
import com.bytel.spirit.prof.processes.PI0035.sti.PI0035_LienEqtPa;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author jgregori
 * @version ($Revision$ $Date$)
 */
public class PI0035_LienEqtPATest
{
  /**
   * Factory de génération des beans
   */
  private static PodamFactory __podam = new PodamFactoryImpl();

  /**
   * Initialize before all tests
   */
  @BeforeClass
  public static void setUpBeforeClass()
  {
    // désactivation du cache podam
    __podam.getStrategy().setMemoization(false);
    __podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());

  }

  /**
   * Tests static method {@link PI0035_LienEqtPa#buildFromLienEqtPA(LienEquipementPA)}.
   */
  @Test
  public void testBuildFromLienEqtPA()
  {

    LienEquipementPA lienEqtPA = __podam.manufacturePojo(LienEquipementPA.class);
    PI0035_LienEqtPa pfiCompLienEqtPA = PI0035_LienEqtPa.buildFromLienEqtPA(lienEqtPA);
    PFITestUtils.assertLienEqtPA(lienEqtPA, pfiCompLienEqtPA);

  }

  /**
   * Tests static method {@link PI0035_LienEqtPa#buildFromLienEqtPA(LienEquipementPA)}.
   */
  @Test
  public void testBuildFromLienEqtPA_001()
  {
    LocalDateTime local = DateTimeManager.getInstance().now();
    LienEquipementPA lienEqtPA = new LienEquipementPA("noEquipement", "idFonctionnelPa", Statut.ACTIF, local, local); //$NON-NLS-1$//$NON-NLS-2$
    PI0035_LienEqtPa pfiCompLienEqtPA = PI0035_LienEqtPa.buildFromLienEqtPA(lienEqtPA);
    PI0035_LienEqtPa pfiCompLienEqtPA1 = PI0035_LienEqtPa.buildFromLienEqtPA(lienEqtPA);
    assertEquals(pfiCompLienEqtPA.equals(pfiCompLienEqtPA1), true);

  }
}
