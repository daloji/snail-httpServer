/*******************************************************************************
* $Id: CommandePfiUtilsTest.java 14179 2018-12-06 10:51:40Z fbarnabe $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PE0018;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PowerMockListener;
import org.powermock.core.testlisteners.FieldDefaulter;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.modules.junit4.PowerMockRunnerDelegate;
import org.springframework.test.context.ContextConfiguration;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.test.podam.PodamBytelJUnit4ClassRunner;
import com.bytel.ravel.common.utils.RetourFactoryForTU;
import com.bytel.spirit.common.shared.saab.rpg.CatalogServiceCommercial;
import com.bytel.spirit.common.shared.saab.rpg.Statut;
import com.bytel.spirit.prof.processes.PE0018.utils.CommandePFIUtils;
import com.bytel.spirit.prof.shared.types.abstracts.AbstractPointAcces;
import com.bytel.spirit.prof.shared.types.json.CommandePfi;
import com.bytel.spirit.prof.shared.types.json.PhotoPfi;
import com.bytel.spirit.prof.shared.types.json.PointAccesVoip;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author jiantila
 * @version ($Revision: 14179 $ $Date: 2018-12-06 11:51:40 +0100 (jeu. 06 déc. 2018) $)
 */
@RunWith(PowerMockRunner.class)
@PowerMockListener(FieldDefaulter.class)
@PowerMockRunnerDelegate(PodamBytelJUnit4ClassRunner.class)
@ContextConfiguration("classpath:BeansProcessTestMocks.xml")
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
public class CommandePfiUtilsTest
{

  /**
   * Factory de génération des beans
   */
  private static PodamFactory __podam;

  /**
   * generator data of PFI
   */
  private static PFIFullForTest _pfiGenerator;

  @BeforeClass
  public static void setUpBeforeClass() throws Exception
  {
    // désactivation du cache podam
    __podam = new PodamFactoryImpl();
    __podam.getStrategy().setMemoization(false);
    __podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());

    _pfiGenerator = new PFIFullForTest();
  }

  @Test
  public void testComandUtils_OK_001()
  {
    PhotoPfi infosPfi = __podam.manufacturePojo(PhotoPfi.class); //PhotoPFI to put in donnes Brut of command
    infosPfi.getPortefeuilleServices().setStatut(Statut.ACTIF.name());

    Retour retourExpected = RetourFactoryForTU.createOkRetour();

    //Init the catalogServiceCommercial for the list
    CatalogServiceCommercial catalogServiceCommercial = __podam.manufacturePojo(CatalogServiceCommercial.class);
    catalogServiceCommercial.setClientOperateur(_pfiGenerator.getCommande().getClientOperateur());
    catalogServiceCommercial.setNoServiceCommercial(_pfiGenerator.getNoServiceCommercialConnu());
    catalogServiceCommercial.setTypePA("VOIP"); //$NON-NLS-1$

    //Add the catalogServiceCommercial to the list
    List<CatalogServiceCommercial> listeCatalogServiceComemrcial = new ArrayList<>();
    listeCatalogServiceComemrcial.add(catalogServiceCommercial);
    //initialize Statut of ServiceAccessible - workaround for Podam
    //The SA has the same noServiceCommercial as the catalogServiceCommercial so that it will be found on cache
    List<com.bytel.spirit.prof.shared.types.json.sti0017.ServiceAccessible> sAccessiblesList = new ArrayList<>();

    com.bytel.spirit.prof.shared.types.json.sti0017.ServiceAccessible sa = new com.bytel.spirit.prof.shared.types.json.sti0017.ServiceAccessible();
    sa.setNoServiceCommercial(catalogServiceCommercial.getNoServiceCommercial());
    sa.setListeIdPointAcces(Arrays.asList(catalogServiceCommercial.getNoServiceCommercial()));
    sAccessiblesList.add(sa);

    infosPfi.getPortefeuilleServices().setServicesAccessibles(sAccessiblesList);

    List<com.bytel.spirit.prof.shared.types.abstracts.sti0017.AbstractPointAcces> pointsAcces = new ArrayList<>();

    com.bytel.spirit.prof.shared.types.abstracts.sti0017.AbstractPointAcces pAccesVoip = _pfiGenerator.buildPointAccesVoipPortageV1();
    pAccesVoip.setIdentifiantFonctionnelPA(catalogServiceCommercial.getNoServiceCommercial());
    pointsAcces.add(pAccesVoip);
    infosPfi.getPortefeuilleServices().setPointsAcces(pointsAcces);

    CommandePfi commandpfi = CommandePFIUtils.transformPhotoPfi(infosPfi);

    assertEquals(commandpfi.getDemandePhoto().getIdDemandePhoto(), infosPfi.getDemandePhoto().getIdDemandePhoto());
    assertEquals(commandpfi.getDemandePhoto().getNoComptePFI(), infosPfi.getDemandePhoto().getNoComptePFI());
    assertEquals(commandpfi.getTimestamp(), infosPfi.getTimestamp());
    assertEquals(commandpfi.getPortefeuilleServices().getClientTitulaire().getEmail(), infosPfi.getPortefeuilleServices().getClientTitulaire().getEmail());
    assertEquals(commandpfi.getPortefeuilleServices().getClientTitulaire().getNoPersonne(), infosPfi.getPortefeuilleServices().getClientTitulaire().getNoPersonne());
    assertEquals(commandpfi.getPortefeuilleServices().getClientTitulaire().getEntreprise().getRaisonSociale(), infosPfi.getPortefeuilleServices().getClientTitulaire().getEntreprise().getRaisonSociale());
    assertEquals(commandpfi.getPortefeuilleServices().getClientTitulaire().getEntreprise().getSiren(), infosPfi.getPortefeuilleServices().getClientTitulaire().getEntreprise().getSiren());
    assertEquals(commandpfi.getPortefeuilleServices().getClientTitulaire().getEntreprise().getIndividu().getCivilite(), infosPfi.getPortefeuilleServices().getClientTitulaire().getEntreprise().getIndividu().getCivilite());
    assertEquals(commandpfi.getPortefeuilleServices().getClientTitulaire().getEntreprise().getIndividu().getNom(), infosPfi.getPortefeuilleServices().getClientTitulaire().getEntreprise().getIndividu().getNom());
    assertEquals(commandpfi.getPortefeuilleServices().getClientTitulaire().getEntreprise().getIndividu().getPrenom(), infosPfi.getPortefeuilleServices().getClientTitulaire().getEntreprise().getIndividu().getPrenom());
    assertEquals(commandpfi.getPortefeuilleServices().getClientTitulaire().getIndividu().getCivilite(), infosPfi.getPortefeuilleServices().getClientTitulaire().getIndividu().getCivilite());
    assertEquals(commandpfi.getPortefeuilleServices().getClientTitulaire().getIndividu().getNom(), infosPfi.getPortefeuilleServices().getClientTitulaire().getIndividu().getNom());
    assertEquals(commandpfi.getPortefeuilleServices().getClientTitulaire().getIndividu().getPrenom(), infosPfi.getPortefeuilleServices().getClientTitulaire().getIndividu().getPrenom());

    assertEquals(commandpfi.getPortefeuilleServices().getServicesAccessibles().get(0).getNoServiceAccessible(), infosPfi.getPortefeuilleServices().getServicesAccessibles().get(0).getNoServiceAccessible());
    assertEquals(commandpfi.getPortefeuilleServices().getServicesAccessibles().get(0).getNoServiceCommercial(), infosPfi.getPortefeuilleServices().getServicesAccessibles().get(0).getNoServiceCommercial());
    assertEquals(commandpfi.getPortefeuilleServices().getServicesAccessibles().get(0).getStatut(), infosPfi.getPortefeuilleServices().getServicesAccessibles().get(0).getStatut());
    List<AbstractPointAcces> listpointsAcces = commandpfi.getPortefeuilleServices().getPointsAcces();
    PointAccesVoip abspAccesVoip = (PointAccesVoip) listpointsAcces.get(0);
    com.bytel.spirit.prof.shared.types.json.sti0017.PointAccesVoip accesvoipV1 = (com.bytel.spirit.prof.shared.types.json.sti0017.PointAccesVoip) pAccesVoip;
    assertEquals(abspAccesVoip.getDemandePortage().getCodeRIO(), accesvoipV1.getDemandePortage().getCodeRIO());
    assertEquals(abspAccesVoip.getIdentifiantFonctionnelPA(), accesvoipV1.getIdentifiantFonctionnelPA());
    assertEquals(abspAccesVoip.getIdentifiantFonctionnelPALie(), accesvoipV1.getIdentifiantFonctionnelPALie());
    assertEquals(abspAccesVoip.getNumeroVoip().getNumero(), accesvoipV1.getNumeroVoip().getNumero());
    assertEquals(abspAccesVoip.getStatut(), accesvoipV1.getStatut());

  }

}
