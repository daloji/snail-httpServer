/*
 *                                                             ___o.__
 *                                                         ,oH8888888888o._
 *                                                       dP',88888P'''`8888o.
 *   ____                                              ,8',888888      888888o
 *  |  _ \                                            d8,d888888b    ,d8888888b
 *  | |_) | ___  _   _ _   _  __ _ _   _  ___  ___   ,8PPY8888888boo8888PPPP"'`b
 *  |  _ < / _ \| | | | | | |/ _` | | | |/ _ \/ __|  d8o_                     d8
 *  | |_) | (_) | |_| | |_| | (_| | |_| |  __/\__ \' d888bo.             _ooP d8'
 *  |____/ \___/ \__,_|\__, |\__, |\__,_|\___||___/  d8888888P     ,ooo88888P d8
 *                      __/ | ___/_                  `8M8888P     ,88888888P ,8P
 *                     |___/ |__ |  _  |  _  _  _ __  Y88Y88'    ,888888888' dP
 *                               | (/_ | (/_(_ (_)|||  `8b8P    d8888888888,dP
 *                                                      Y8,   d88888888888P'
 *                                                        `Y=8888888888P'
 *                                                            `''`'''
 *
 *  Systeme $system
 *
 *  (C) Copyright Bouygues Telecom 2018.
 *
 *  Utilisation, reproduction et divulgation interdites
 *  sans autorisation ecrite de Bouygues Telecom.
 *
 *  Projet  : FTTOcmdRacco_Lot3_Rebasing1901
 *  Package : com.bytel.spirit.prof.processes.PI0035.sti
 *  Classe  : PI0035_AccesTechniqueTest
 *  Auteur  : sdiop
 *
 */
package com.bytel.spirit.prof.processes.PI0035.sti;

import com.bytel.spirit.common.shared.saab.res.AccesTechnique;
import org.junit.BeforeClass;
import org.junit.Test;

import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author sdiop
 * @version ($Revision$ $Date$)
 */
public class PI0035_AccesTechniqueTest
{
  /**
   * Factory de génération des beans
   */
  private static PodamFactory __podam = new PodamFactoryImpl();

  /**
   * Initialize before all tests
   */
  @BeforeClass
  public static void setUpBeforeClass()
  {
    // désactivation du cache podam
    __podam.getStrategy().setMemoization(false);
    __podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());

  }

  /**
   * Tests static method {@link PI0035_AccesTechnique#buildFromAccesTechnique(AccesTechnique)}.
   */
  @Test
  public void testbuildFromAccesTechnique()
  {
    AccesTechnique accesTechnique = __podam.manufacturePojo(AccesTechnique.class);
    PI0035_AccesTechnique pi0035_accesTechnique = PI0035_AccesTechnique.buildFromAccesTechnique(accesTechnique);
    PFITestUtils.assertAccesTechnique(accesTechnique, pi0035_accesTechnique);

  }

}
