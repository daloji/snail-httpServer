/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PI0035.sti;

import static org.apache.commons.lang3.StringUtils.isBlank;
import static org.junit.Assert.assertEquals;

import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.validation.ConstraintViolation;

import org.easymock.EasyMockSupport;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.spirit.common.shared.misc.validation.IValidationConst;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author jiantila
 * @version ($Revision$ $Date$)
 */

@RunWith(PowerMockRunner.class)
@PrepareForTest({ PI0035_Ressource.class })
public class PI0035_RessourceTest extends EasyMockSupport
{

  /**
  *
  */
  public static final String VALUE_AUTHORIZED = IValidationConst.FORMAT_ATTRIBUT_NON_RESPECTE;
  /**
  *
  */
  public static final String CONDITIONAL = IValidationConst.ATTRIBUT_COND_INATTENDU;

  /**
  *
  */
  public static final String MANDATORY = IValidationConst.ATTRIBUT_OBLIGATOIRE_MANQUANT;
  /**
   * Factory de génération des beans
   */
  private static PodamFactory __podam = new PodamFactoryImpl();

  /**
   * Initialize before all tests
   */
  @BeforeClass
  public static void setUpBeforeClass()
  {
    // désactivation du cache podam
    __podam.getStrategy().setMemoization(false);
    __podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());
  }

  /**
   * @param constraintValidation_p
   *          constraint
   * @return String
   */
  public String getNameConstraint(final ConstraintViolation<?> constraintValidation_p)
  {
    return Stream.of(constraintValidation_p.getRootBeanClass().getSimpleName(), constraintValidation_p.getPropertyPath().toString()).filter(s -> !isBlank(s)).collect(Collectors.joining(".")); //$NON-NLS-1$
  }

  /**
   * Verification des attributes
   */
  @Test
  public void PI0035_RessourceTest_001_OK()
  {
    com.bytel.spirit.common.shared.saab.res.Ressource ressource = new com.bytel.spirit.common.shared.saab.res.Ressource("idRessource", "typeRessource", "statut"); //$NON-NLS-1$ //$NON-NLS-2$//$NON-NLS-3$
    PI0035_Ressource pi0035Resource = PI0035_Ressource.buildFromRessource(ressource);

    assertEquals(pi0035Resource.getIdRessource(), ressource.getIdRessource());
    assertEquals(pi0035Resource.getTypeRessource(), ressource.getTypeRessource());
    assertEquals(pi0035Resource.getStatut(), ressource.getStatut());
  }
}
