/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PM028.activity;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import org.easymock.EasyMock;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.bytel.ravel.common.utils.ACManagerUtil;
import com.bytel.ravel.common.utils.DateTimeTools;
import com.bytel.ravel.common.utils.DateTimeTools.DateTimeFormatPattern;
import com.bytel.ravel.common.utils.MarshallTools;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.activity.Context;
import com.bytel.ravel.services.utils.Test_Consts;
import com.bytel.spirit.common.connectors.oam.FollowUpTable;
import com.bytel.spirit.common.shared.misc.ressources.Consts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.prof.connectors.generated.svccomm.TypeServiceCommercialMIM;
import com.bytel.spirit.prof.connectors.svccomm.SvcCommMimProxy;
import com.bytel.spirit.prof.processes.PM028.ActionProvisionner;
import com.bytel.spirit.prof.processes.PM028.Diagnostic;
import com.bytel.spirit.prof.processes.PM028.Messages;
import com.bytel.spirit.prof.processes.PM028.PM028ProvisionnerPfi;
import com.bytel.spirit.prof.processes.PM028.Quadruplet;
import com.bytel.spirit.prof.processes.PM028.activity.PM028BL001ControlerDonneesEntree.PM028BL001ControlerDonneesEntreeBuilder;
import com.bytel.spirit.prof.processes.generated.provisionnerpfi.ActeMetier;
import com.bytel.spirit.prof.processes.generated.provisionnerpfi.ComptePayeur;
import com.bytel.spirit.prof.processes.generated.provisionnerpfi.DonneesMetier;
import com.bytel.spirit.prof.processes.generated.provisionnerpfi.EnumActemetierType;
import com.bytel.spirit.prof.processes.generated.provisionnerpfi.EnumStatutPfs;
import com.bytel.spirit.prof.processes.generated.provisionnerpfi.LigneGsm;
import com.bytel.spirit.prof.processes.generated.provisionnerpfi.PIVOTREFERENCE;
import com.bytel.spirit.prof.processes.generated.provisionnerpfi.PartitionSic;
import com.bytel.spirit.prof.processes.generated.provisionnerpfi.PointAccesStatut;
import com.bytel.spirit.prof.processes.generated.provisionnerpfi.PortefeuilleIndividuel;
import com.bytel.spirit.prof.processes.generated.provisionnerpfi.ProvisionnerPfiIn;
import com.bytel.spirit.prof.processes.generated.provisionnerpfi.ServiceAccessible;
import com.bytel.spirit.prof.processes.generated.provisionnerpfi.ServiceCommercial;
import com.bytel.spirit.prof.processes.generated.provisionnerpfi.SimLogique;
import com.bytel.spirit.prof.processes.generated.provisionnerpfi.SimLogiqueStatut;
import com.bytel.spirit.prof.processes.generated.provisionnerpfi.St;

/**
 *
 * @author lmerces
 * @version ($Revision$ $Date$)
 */
//Déclaration du runner de test pour lancer les TUs avec le runner PowerMock
@RunWith(PowerMockRunner.class)
//Préparation des classes pour les tests, toutes les classes comportant des méthodes statiques à mocker doivent être présentes dans l'annotation
@PrepareForTest({ SvcCommMimProxy.class })
//To avoid: SecretKeyFactory.getInstance() throws exception for all algorithms in unit tests
@PowerMockIgnore("javax.crypto.*")
public class PM028BL001ControlerDonneesEntreeTest
{

  /**
   *
   * @author lmerces
   * @version ($Revision$ $Date$)
   */
  class PM028BL001ControlerDonneesEntreeTestContext extends Context
  {
    /**
     *
     */
    private static final long serialVersionUID = -3505345465838053755L;

  }

  /**
   *
   */
  private static final String FLOWID = "cde3ab202e714d88afb92e24b52185ef"; //$NON-NLS-1$

  /**
  *
  */
  private static final String SOURCE = "103"; //$NON-NLS-1$

  /**
   *
   */
  private static final String IDTITF = "'IWSINFRA1"; //$NON-NLS-1$

  /**
  *
  */
  private static final String PARTITION_SIC = "3"; //$NON-NLS-1$

  /**
   *
   */
  private static final String PROVISIONNER_PFI_IN_REQUEST_XML = "src/test/resources/provisionnerPfiIn_request.xml"; //$NON-NLS-1$

  /**
   *
   */
  @BeforeClass
  public static void init()
  {
    ACManagerUtil.resetACManager();
    new ClassPathXmlApplicationContext("classpath:BeansProcessTestMocks.xml"); //$NON-NLS-1$
  }

  /**
   *
   */
  @MockStrict
  private SvcCommMimProxy _svcCommMimConnector;

  /**
  *
  */
  private PM028ProvisionnerPfi _currentInstance;

  /**
   * Called before each test with the annotation @ Before to clean the connectors.
   */
  @Before
  public void beforeTest()
  {
    // on réinitialise tous les mocks afin de ne pas avoir d'interférence entre les tests
    PowerMock.resetAll();

    // On initialise toutes les classes à mocker comportant un appel à une méthode statique
    // Dans notre cas on mock statiquemement toutes les classes des activités et des proxys appelés (pour les createContexte et les getInstance)
    PowerMock.mockStaticStrict(SvcCommMimProxy.class);

    // Initialize the context
    _currentInstance = new PM028ProvisionnerPfi();
    _currentInstance.initializeContext();
  }

  /**
   * Test aux actions disponibles
   *
   * @throws Exception
   *           thrown exception
   */
  @Test
  public void Test_ControlerDonneesEntree_Actions() throws Exception
  {
    Tracabilite tracabilite = new Tracabilite(StringConstants.EMPTY_STRING, Test_Consts.DEFAULT_MSGID, "PROF", "nomPRocessus", "idProcessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    ActionProvisionner actionProvisionner = ActionProvisionner.ACTIVER_LIGNES;
    ProvisionnerPfiIn provisionnerPfiIn = buildProvisionnerPfiIn(EnumStatutPfs.ACTIF, actionProvisionner.getAction(), true, 2, true, true);
    provisionnerPfiIn.getActeMetier().setType(EnumActemetierType.ACTIVATION_CONTRAT);

    //Prepare mock
    EasyMock.expect(SvcCommMimProxy.getInstance()).andReturn(_svcCommMimConnector);
    EasyMock.expectLastCall().anyTimes();

    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, "1645")).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(new TypeServiceCommercialMIM(), true)); //$NON-NLS-1$
    EasyMock.expectLastCall().anyTimes();

    // On enregistre le scénario des appels
    PowerMock.replayAll();

    // Activer lignes
    PM028BL001ControlerDonneesEntree pm028BL001ControlerDonneesEntree = new PM028BL001ControlerDonneesEntreeBuilder().tracabilite(tracabilite).source(SOURCE).flowId(FLOWID).provisionnerPfiIn(provisionnerPfiIn).idtitf(IDTITF).partitionSic(PARTITION_SIC).build();
    ControlerDonneesReponse result = pm028BL001ControlerDonneesEntree.execute(_currentInstance);

    PowerMock.verifyAll();

    List<Quadruplet> listeQuadruplet = result.getListeQuadruplets();
    Assert.assertNotNull(listeQuadruplet);
    Assert.assertFalse(listeQuadruplet.isEmpty());
    Assert.assertEquals(1, listeQuadruplet.size());
    Assert.assertEquals(actionProvisionner, listeQuadruplet.get(0).getActionProvisionner());

    // Reactiver lignes
    actionProvisionner = ActionProvisionner.REACTIVER_LIGNES;
    provisionnerPfiIn = buildProvisionnerPfiIn(EnumStatutPfs.ACTIF, actionProvisionner.getAction(), true, 2, true, true);
    provisionnerPfiIn.getActeMetier().setType(EnumActemetierType.REACTIVATION_CONTRAT);
    pm028BL001ControlerDonneesEntree = new PM028BL001ControlerDonneesEntreeBuilder().tracabilite(tracabilite).source(SOURCE).flowId(FLOWID).provisionnerPfiIn(provisionnerPfiIn).idtitf(IDTITF).partitionSic(PARTITION_SIC).build();
    result = pm028BL001ControlerDonneesEntree.execute(_currentInstance);
    listeQuadruplet = result.getListeQuadruplets();
    Assert.assertEquals(actionProvisionner, listeQuadruplet.get(0).getActionProvisionner());

    // Resilier lignes
    actionProvisionner = ActionProvisionner.RESILIER_LIGNES;
    provisionnerPfiIn = buildProvisionnerPfiIn(EnumStatutPfs.RESILIE, actionProvisionner.getAction(), true, 2, true, true);
    pm028BL001ControlerDonneesEntree = new PM028BL001ControlerDonneesEntreeBuilder().tracabilite(tracabilite).source(SOURCE).flowId(FLOWID).provisionnerPfiIn(provisionnerPfiIn).idtitf(IDTITF).partitionSic(PARTITION_SIC).build();
    result = pm028BL001ControlerDonneesEntree.execute(_currentInstance);
    listeQuadruplet = result.getListeQuadruplets();
    Assert.assertEquals(actionProvisionner, listeQuadruplet.get(0).getActionProvisionner());

    // Suspendre lignes
    actionProvisionner = ActionProvisionner.SUSPENDRE_LIGNES;
    provisionnerPfiIn = buildProvisionnerPfiIn(EnumStatutPfs.SUSPENDU, actionProvisionner.getAction(), true, 2, true, true);
    pm028BL001ControlerDonneesEntree = new PM028BL001ControlerDonneesEntreeBuilder().tracabilite(tracabilite).source(SOURCE).flowId(FLOWID).provisionnerPfiIn(provisionnerPfiIn).idtitf(IDTITF).partitionSic(PARTITION_SIC).build();
    result = pm028BL001ControlerDonneesEntree.execute(_currentInstance);
    listeQuadruplet = result.getListeQuadruplets();
    Assert.assertEquals(actionProvisionner, listeQuadruplet.get(0).getActionProvisionner());

    // Changer MSISDN (couple msisdn resilie / active introuvable)
    actionProvisionner = ActionProvisionner.CHANGER_MSISDN;
    provisionnerPfiIn = buildProvisionnerPfiIn(null, actionProvisionner.getAction(), false, 2, false, true);
    pm028BL001ControlerDonneesEntree = new PM028BL001ControlerDonneesEntreeBuilder().tracabilite(tracabilite).source(SOURCE).flowId(FLOWID).provisionnerPfiIn(provisionnerPfiIn).idtitf(IDTITF).partitionSic(PARTITION_SIC).build();
    result = pm028BL001ControlerDonneesEntree.execute(_currentInstance);
    listeQuadruplet = result.getListeQuadruplets();
    Assert.assertTrue(listeQuadruplet.isEmpty());

    // Changer MSISDN
    actionProvisionner = ActionProvisionner.CHANGER_MSISDN;
    provisionnerPfiIn = buildProvisionnerPfiIn(null, actionProvisionner.getAction(), false, 2, true, true);
    pm028BL001ControlerDonneesEntree = new PM028BL001ControlerDonneesEntreeBuilder().tracabilite(tracabilite).source(SOURCE).flowId(FLOWID).provisionnerPfiIn(provisionnerPfiIn).idtitf(IDTITF).partitionSic(PARTITION_SIC).build();
    result = pm028BL001ControlerDonneesEntree.execute(_currentInstance);
    listeQuadruplet = result.getListeQuadruplets();
    Assert.assertEquals(actionProvisionner, listeQuadruplet.get(0).getActionProvisionner());

    // Changer IMSI (couple simLogique resilie / active introuvable)
    actionProvisionner = ActionProvisionner.CHANGER_IMSI;
    provisionnerPfiIn = buildProvisionnerPfiIn(null, actionProvisionner.getAction(), false, 1, true, false);
    pm028BL001ControlerDonneesEntree = new PM028BL001ControlerDonneesEntreeBuilder().tracabilite(tracabilite).source(SOURCE).flowId(FLOWID).provisionnerPfiIn(provisionnerPfiIn).idtitf(IDTITF).partitionSic(PARTITION_SIC).build();
    result = pm028BL001ControlerDonneesEntree.execute(_currentInstance);
    listeQuadruplet = result.getListeQuadruplets();
    Assert.assertTrue(listeQuadruplet.isEmpty());

    // Changer IMSI
    actionProvisionner = ActionProvisionner.CHANGER_IMSI;
    provisionnerPfiIn = buildProvisionnerPfiIn(null, actionProvisionner.getAction(), false, 1, true, true);
    pm028BL001ControlerDonneesEntree = new PM028BL001ControlerDonneesEntreeBuilder().tracabilite(tracabilite).source(SOURCE).flowId(FLOWID).provisionnerPfiIn(provisionnerPfiIn).idtitf(IDTITF).partitionSic(PARTITION_SIC).build();
    result = pm028BL001ControlerDonneesEntree.execute(_currentInstance);
    listeQuadruplet = result.getListeQuadruplets();
    Assert.assertEquals(actionProvisionner, listeQuadruplet.get(0).getActionProvisionner());

    // Provisionner services
    actionProvisionner = ActionProvisionner.PROVISIONNER_SERVICES;
    provisionnerPfiIn = buildProvisionnerPfiIn(null, actionProvisionner.getAction(), true, 2, true, true);
    pm028BL001ControlerDonneesEntree = new PM028BL001ControlerDonneesEntreeBuilder().tracabilite(tracabilite).source(SOURCE).flowId(FLOWID).provisionnerPfiIn(provisionnerPfiIn).idtitf(IDTITF).partitionSic(PARTITION_SIC).build();
    result = pm028BL001ControlerDonneesEntree.execute(_currentInstance);
    listeQuadruplet = result.getListeQuadruplets();
    Assert.assertEquals(actionProvisionner, listeQuadruplet.get(0).getActionProvisionner());

    // Modifier Jour Facturation
    actionProvisionner = ActionProvisionner.MODIFIER_JOUR_FACTURATION;
    provisionnerPfiIn = buildProvisionnerPfiIn(null, actionProvisionner.getAction(), false, 0, false, true);
    provisionnerPfiIn = addComptePayeurs(provisionnerPfiIn, provisionnerPfiIn.getDonneesMetier().getPortefeuilleIndividuels().get(0), 1);
    pm028BL001ControlerDonneesEntree = new PM028BL001ControlerDonneesEntreeBuilder().tracabilite(tracabilite).source(SOURCE).flowId(FLOWID).provisionnerPfiIn(provisionnerPfiIn).idtitf(IDTITF).partitionSic(PARTITION_SIC).build();
    result = pm028BL001ControlerDonneesEntree.execute(_currentInstance);
    listeQuadruplet = result.getListeQuadruplets();
    Assert.assertEquals(actionProvisionner, listeQuadruplet.get(0).getActionProvisionner());
  }

  /**
   * Test KO Partition sic null
   *
   * @throws Exception
   *           thrown exception
   */
  @Test
  public void Test_ControlerDonneesEntree_KO_PartitionSic() throws Exception
  {
    Tracabilite tracabilite = new Tracabilite(StringConstants.EMPTY_STRING, Test_Consts.DEFAULT_MSGID, "PROF", "nomPRocessus", "idProcessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    ActionProvisionner actionProvisionner = ActionProvisionner.ACTIVER_LIGNES;
    ProvisionnerPfiIn provisionnerPfiIn = buildProvisionnerPfiIn(EnumStatutPfs.ACTIF, actionProvisionner.getAction(), true, 2, true, true);
    provisionnerPfiIn.getActeMetier().setType(EnumActemetierType.ACTIVATION_CONTRAT);

    // Activer lignes
    PM028BL001ControlerDonneesEntree pm028BL001ControlerDonneesEntree = new PM028BL001ControlerDonneesEntreeBuilder().tracabilite(tracabilite).source(SOURCE).flowId(FLOWID).provisionnerPfiIn(provisionnerPfiIn).idtitf(IDTITF).partitionSic("2").build(); //$NON-NLS-1$
    pm028BL001ControlerDonneesEntree.execute(_currentInstance);

    Assert.assertNotNull(pm028BL001ControlerDonneesEntree.getRetour());
    Assert.assertEquals(Messages.getString(Messages.BL001_CONTROLER_DONNEES_ENTREE_DONNEE_INCOHERENTE), pm028BL001ControlerDonneesEntree.getRetour().getLibelle());
    Assert.assertEquals(Consts.DEF_4.toString(), pm028BL001ControlerDonneesEntree.getRetour().getCategorie());
  }

  /**
   * Test KO NoCompte null
   *
   * @throws Exception
   *           thrown exception
   */
  @Test
  public void Test_ControlerDonneesEntree_KO_PfiNoCompte() throws Exception
  {
    Tracabilite tracabilite = new Tracabilite(StringConstants.EMPTY_STRING, Test_Consts.DEFAULT_MSGID, "PROF", "nomPRocessus", "idProcessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    ActionProvisionner actionProvisionner = ActionProvisionner.ACTIVER_LIGNES;
    ProvisionnerPfiIn provisionnerPfiIn = buildProvisionnerPfiIn(EnumStatutPfs.ACTIF, actionProvisionner.getAction(), true, 2, true, true);
    provisionnerPfiIn.getActeMetier().setType(EnumActemetierType.ACTIVATION_CONTRAT);

    provisionnerPfiIn.getDonneesMetier().getPortefeuilleIndividuels().get(0).setNoCompte(null);

    // Activer lignes
    PM028BL001ControlerDonneesEntree pm028BL001ControlerDonneesEntree = new PM028BL001ControlerDonneesEntreeBuilder().tracabilite(tracabilite).source(SOURCE).flowId(FLOWID).provisionnerPfiIn(provisionnerPfiIn).idtitf(IDTITF).partitionSic("3").build(); //$NON-NLS-1$
    pm028BL001ControlerDonneesEntree.execute(_currentInstance);

    Assert.assertNotNull(pm028BL001ControlerDonneesEntree.getRetour());
    Assert.assertEquals(Messages.getString(Messages.BL001_CONTROLER_DONNEES_ENTREE_DONNEE_INCOHERENTE), pm028BL001ControlerDonneesEntree.getRetour().getLibelle());
    Assert.assertEquals(Consts.DEF_4.toString(), pm028BL001ControlerDonneesEntree.getRetour().getCategorie());
  }

  /**
   * Test OK avec aucun PFI à provisionner en sortie.
   *
   * @throws Exception
   *           thrown exception
   */
  @Test
  public void Test_ControlerDonneesEntree_OK_Aucun_Provisionning() throws Exception
  {
    Tracabilite tracabilite = new Tracabilite(StringConstants.EMPTY_STRING, Test_Consts.DEFAULT_MSGID, "PROF", "nomPRocessus", "idProcessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    ProvisionnerPfiIn provisionnerPfiIn = MarshallTools.unmarshall(ProvisionnerPfiIn.class, new File(PROVISIONNER_PFI_IN_REQUEST_XML));

    //Prepare mock
    EasyMock.expect(SvcCommMimProxy.getInstance()).andReturn(_svcCommMimConnector);
    EasyMock.expectLastCall().anyTimes();

    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, "1645")).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(null, false)); //$NON-NLS-1$
    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, "2")).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(null, false)); //$NON-NLS-1$

    // On enregistre le scénario des appels
    PowerMock.replayAll();

    PM028BL001ControlerDonneesEntree pm028BL001ControlerDonneesEntree = new PM028BL001ControlerDonneesEntreeBuilder().tracabilite(tracabilite).source(SOURCE).flowId(FLOWID).provisionnerPfiIn(provisionnerPfiIn).idtitf(IDTITF).partitionSic(PARTITION_SIC).build();
    ControlerDonneesReponse result = pm028BL001ControlerDonneesEntree.execute(_currentInstance);

    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.OK, pm028BL001ControlerDonneesEntree.getRetour().getResultat());
    Assert.assertEquals(Diagnostic.AUCUN_PROVISIONING.toString(), pm028BL001ControlerDonneesEntree.getRetour().getDiagnostic());
    List<Quadruplet> listeQuadruplet = result.getListeQuadruplets();
    Assert.assertNotNull(listeQuadruplet);
    Assert.assertEquals(listeQuadruplet.size(), 0);

    FollowUpTable tableSuivi = result.getFollowUpTable();
    Assert.assertNotNull(tableSuivi);
    Assert.assertEquals(tableSuivi.getIdtDde(), SOURCE + "." + FLOWID); //$NON-NLS-1$
    Assert.assertNotNull(tableSuivi.getDatDebTrt());
    Assert.assertEquals(tableSuivi.getIdtSysTec(), "71"); //$NON-NLS-1$
    Assert.assertNotNull(tableSuivi.getIdtParSic());
    Assert.assertEquals(3, tableSuivi.getIdtParSic().intValue());
    Assert.assertEquals(ActionProvisionner.PROVISIONNER_SERVICES.getAction(), tableSuivi.getNomSvc());
    Assert.assertEquals(IDTITF, tableSuivi.getIdtItf());
    Assert.assertEquals(tableSuivi.getIdtAct(), "401856045"); //$NON-NLS-1$
    Date datecrea = DateTimeTools.toDate(DateTimeFormatPattern.yyyyMMddHHmmss.parse("20150929163703").toLocalDate()); //$NON-NLS-1$
    Assert.assertEquals(tableSuivi.getDatCreact(), datecrea);
    Assert.assertNotNull(tableSuivi.getNbrPfi());
    Assert.assertEquals(tableSuivi.getNbrPfi().intValue(), 1);
    Assert.assertNotNull(tableSuivi.getNbrPfiPro());
    Assert.assertEquals(tableSuivi.getNbrPfiPro().intValue(), 0);

    Assert.assertEquals(StringConstants.OK, tableSuivi.getEtaRcp());
    Assert.assertEquals(tableSuivi.getLibRcp(), "Traitement IWS OK : aucune service a provisionner"); //$NON-NLS-1$
    Assert.assertEquals(StringConstants.OK, tableSuivi.getEtapro());
    Assert.assertEquals(tableSuivi.getLibPro(), "Pas de provisionning necessaire suite a controle donnees entree"); //$NON-NLS-1$
    Assert.assertEquals(tableSuivi.getEtaNtf(), "New"); //$NON-NLS-1$
    Assert.assertEquals(tableSuivi.getTypNtf(), "TRAITE_SANS_IMPACT"); //$NON-NLS-1$

    Assert.assertEquals(true, tableSuivi.getDatFinTrt() != null);
    Assert.assertNull(tableSuivi.getDatNtf());
    Assert.assertNull(tableSuivi.getLibNtf());
  }

  /**
   * Test OK avec 1 PFI à provisionner
   *
   * @throws Exception
   *           thrown exception
   */
  @Test
  public void Test_ControlerDonneesEntree_OK_Provisionning() throws Exception
  {
    Tracabilite tracabilite = new Tracabilite(StringConstants.EMPTY_STRING, Test_Consts.DEFAULT_MSGID, "PROF", "nomPRocessus", "idProcessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    ProvisionnerPfiIn provisionnerPfiIn = MarshallTools.unmarshall(ProvisionnerPfiIn.class, new File(PROVISIONNER_PFI_IN_REQUEST_XML));

    //Prepare mock
    EasyMock.expect(SvcCommMimProxy.getInstance()).andReturn(_svcCommMimConnector);
    EasyMock.expectLastCall().anyTimes();

    EasyMock.expect(_svcCommMimConnector.getServiceCommercialMIM(Test_Consts.DEFAULT_MSGID, "1645")).andReturn(new ConnectorResponse<TypeServiceCommercialMIM, Boolean>(new TypeServiceCommercialMIM(), true)); //$NON-NLS-1$

    // On enregistre le scénario des appels
    PowerMock.replayAll();

    PM028BL001ControlerDonneesEntree pm028BL001ControlerDonneesEntree = new PM028BL001ControlerDonneesEntreeBuilder().tracabilite(tracabilite).source(SOURCE).flowId(FLOWID).provisionnerPfiIn(provisionnerPfiIn).idtitf(IDTITF).partitionSic(PARTITION_SIC).build();
    ControlerDonneesReponse result = pm028BL001ControlerDonneesEntree.execute(_currentInstance);

    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.OK, pm028BL001ControlerDonneesEntree.getRetour().getResultat());
    Assert.assertEquals(Diagnostic.PROVISIONING.toString(), pm028BL001ControlerDonneesEntree.getRetour().getDiagnostic());
    List<Quadruplet> listeQuadruplet = result.getListeQuadruplets();
    Assert.assertNotNull(listeQuadruplet);
    Assert.assertEquals(listeQuadruplet.size(), 1);
    Assert.assertEquals(listeQuadruplet.get(0).getPfi().getNoCompte(), "10001871296"); //$NON-NLS-1$
    Assert.assertNotNull(listeQuadruplet.get(0).getMsisdn());
    Assert.assertEquals(listeQuadruplet.get(0).getMsisdn(), "33600300091"); //$NON-NLS-1$
    Assert.assertNotNull(listeQuadruplet.get(0).getImsi());
    Assert.assertEquals(listeQuadruplet.get(0).getImsi(), "208201700000091"); //$NON-NLS-1$
    FollowUpTable tableSuivi = result.getFollowUpTable();
    Assert.assertNotNull(tableSuivi);
    Assert.assertEquals(tableSuivi.getIdtDde(), SOURCE + "." + FLOWID); //$NON-NLS-1$
    Assert.assertNotNull(tableSuivi.getDatDebTrt());
    Assert.assertEquals(tableSuivi.getIdtSysTec(), "71"); //$NON-NLS-1$
    Assert.assertNotNull(tableSuivi.getIdtParSic());
    Assert.assertEquals(3, tableSuivi.getIdtParSic().intValue());
    Assert.assertEquals(ActionProvisionner.PROVISIONNER_SERVICES.getAction(), tableSuivi.getNomSvc());
    Assert.assertEquals(IDTITF, tableSuivi.getIdtItf());
    Assert.assertEquals(tableSuivi.getIdtAct(), "401856045"); //$NON-NLS-1$
    Date datecrea = DateTimeTools.toDate(DateTimeFormatPattern.yyyyMMddHHmmss.parse("20150929163703").toLocalDate()); //$NON-NLS-1$
    Assert.assertEquals(tableSuivi.getDatCreact(), datecrea);
    Assert.assertNotNull(tableSuivi.getNbrPfi());
    Assert.assertEquals(tableSuivi.getNbrPfi().intValue(), 1);
    Assert.assertNotNull(tableSuivi.getNbrPfiPro());
    Assert.assertEquals(tableSuivi.getNbrPfiPro().intValue(), -1);

    Assert.assertEquals(tableSuivi.getEtaRcp(), "New"); //$NON-NLS-1$
    Assert.assertEquals(tableSuivi.getLibRcp(), "Traitement IWS en cours"); //$NON-NLS-1$

    Assert.assertNull(tableSuivi.getDatFinTrt());
    Assert.assertNull(tableSuivi.getDatNtf());
    Assert.assertNull(tableSuivi.getEtaNtf());
    Assert.assertNull(tableSuivi.getEtapro());
    Assert.assertNull(tableSuivi.getLibNtf());
    Assert.assertNull(tableSuivi.getLibPro());
    Assert.assertNull(tableSuivi.getTypNtf());
  }

  /**
   * Ajout de ComptePayeur au ProvisionnerPfiIn
   *
   * @param provisionnerPfiIn_p
   *          PrivisionnerPfiIn
   * @param pfi
   *          PortefeuilleÎndividuel auquel ajouter les ComptePayeur
   * @param numComptePayeurs
   *          numero de ComptePayeur à ajouter
   * @return a {@link ProvisionnerPfiIn} object
   */
  private ProvisionnerPfiIn addComptePayeurs(ProvisionnerPfiIn provisionnerPfiIn_p, PortefeuilleIndividuel pfi, int numComptePayeurs)
  {
    DonneesMetier donneesMetier = provisionnerPfiIn_p.getDonneesMetier();

    List<ComptePayeur> comptePayeurs = donneesMetier.getComptePayeurs();

    List<PIVOTREFERENCE> pivotReferences = pfi.getComptePayeurs();

    ComptePayeur comptePayeur;
    PIVOTREFERENCE pivotReference;

    for (int i = 0; i < numComptePayeurs; i++)
    {

      comptePayeur = new ComptePayeur();
      comptePayeur.setJourFacturation(10);
      comptePayeurs.add(comptePayeur);

      pivotReference = new PIVOTREFERENCE();
      pivotReference.setIdref(comptePayeur);
      pivotReferences.add(pivotReference);
    }

    return provisionnerPfiIn_p;
  }

  /**
   * Create a ProvisionnerPfiIn
   *
   * @param statut_p
   *          Statut du Pfi
   * @param codeCauseChangementStatut_p
   *          cause du changement de statut du contrat de services
   * @param addServiceAccessibles_p
   *          flag indiquant le rajout (ou non) des services accessibles
   * @param numPointAccesACreer_p
   *          indique le numero de point d'accès à créer
   * @param addPointAccesResilieEtActive_p
   *          flag indiquant si on doit créer points d'accès en état résilié et active
   * @param addSimLogiqueResilieEtActive_p
   *          flag indiquant si on doit créer sim logiques en état résilié et active
   * @return a {@link ProvisionnerPfiIn} object
   */
  private ProvisionnerPfiIn buildProvisionnerPfiIn(EnumStatutPfs statut_p, String codeCauseChangementStatut_p, boolean addServiceAccessibles_p, int numPointAccesACreer_p, boolean addPointAccesResilieEtActive_p, boolean addSimLogiqueResilieEtActive_p)
  {
    ProvisionnerPfiIn provisionnerPfiIn = new ProvisionnerPfiIn();
    PIVOTREFERENCE pivotreference = new PIVOTREFERENCE();

    PortefeuilleIndividuel portefeuilleIndividuel = new PortefeuilleIndividuel();
    portefeuilleIndividuel.setId("PFI-1"); //$NON-NLS-1$
    portefeuilleIndividuel.setStatut(statut_p);
    portefeuilleIndividuel.setCodeCauseChangementStatut(codeCauseChangementStatut_p);
    portefeuilleIndividuel.setNoCompte("123456789"); //$NON-NLS-1$

    //acte metier
    ActeMetier acteMetier = new ActeMetier();
    acteMetier.setDateCreation("20110225101400"); //$NON-NLS-1$
    acteMetier.setIdentifiantActe("INJe6ee05f9dce0408aa205a0ef4ed184a5"); //$NON-NLS-1$
    acteMetier.setPriorite("1"); //$NON-NLS-1$
    PartitionSic partitionSic = new PartitionSic();
    partitionSic.setIdentifiant(PARTITION_SIC);
    acteMetier.setPartitionSic(partitionSic);
    St st = new St();
    st.setIdentifiant("114"); //$NON-NLS-1$
    acteMetier.setSt(st);
    pivotreference = new PIVOTREFERENCE();
    pivotreference.setIdref(portefeuilleIndividuel);
    acteMetier.getPortefeuilleServices().add(pivotreference);

    LigneGsm ligneGsm = null;
    SimLogique simLogique = null;
    for (int i = 0; i < numPointAccesACreer_p; i++)
    {
      ligneGsm = new LigneGsm();
      simLogique = new SimLogique();

      simLogique.setId("SIM-" + (i + 1)); //$NON-NLS-1$
      simLogique.setImsi("20820170000009" + (i + 1)); //$NON-NLS-1$
      simLogique.setStatut(SimLogiqueStatut.ACTIVE);
      pivotreference = new PIVOTREFERENCE();
      pivotreference.setIdref(simLogique);
      ligneGsm.getSimLogiques().add(pivotreference);

      if (addSimLogiqueResilieEtActive_p)
      {
        simLogique = new SimLogique();
        simLogique.setId("SIM-" + (i + 1)); //$NON-NLS-1$
        simLogique.setImsi("20820170000009" + (i + 1)); //$NON-NLS-1$
        simLogique.setStatut(SimLogiqueStatut.RESILIE);
        pivotreference = new PIVOTREFERENCE();
        pivotreference.setIdref(simLogique);
        ligneGsm.getSimLogiques().add(pivotreference);
      }

      ligneGsm.setId("GSM-" + (i + 1)); //$NON-NLS-1$

      if ((i > 0) && addPointAccesResilieEtActive_p)
      {
        ligneGsm.setStatut(PointAccesStatut.RESILIE);
      }
      else
      {
        ligneGsm.setStatut(PointAccesStatut.ACTIVE);
      }
      pivotreference = new PIVOTREFERENCE();
      pivotreference.setIdref(ligneGsm);
      portefeuilleIndividuel.getPointAcces().add(pivotreference);
    }

    if (addServiceAccessibles_p)
    {
      portefeuilleIndividuel.getServiceAccessibles().addAll(getServicesAcessiblesPR());
    }

    //donnesMetier
    DonneesMetier donneesMetier = new DonneesMetier();
    donneesMetier.getPortefeuilleIndividuels().add(portefeuilleIndividuel);
    provisionnerPfiIn.setActeMetier(acteMetier);
    provisionnerPfiIn.setDonneesMetier(donneesMetier);
    return provisionnerPfiIn;

  }

  /**
   * getServicesAcessiblesPR.
   *
   * @return a {@link Collection} object
   */
  private Collection<? extends PIVOTREFERENCE> getServicesAcessiblesPR()
  {
    List<PIVOTREFERENCE> listPivotRef = new ArrayList<>();
    ServiceAccessible serviceAccessible = new ServiceAccessible();
    ServiceCommercial serviceCommercial = new ServiceCommercial();
    serviceAccessible.setId("SA-REF"); //$NON-NLS-1$
    serviceCommercial.setId("SC"); //$NON-NLS-1$
    serviceCommercial.setNoServiceCommercial("1645"); //$NON-NLS-1$
    PIVOTREFERENCE pivotreference = new PIVOTREFERENCE();
    pivotreference.setIdref(serviceCommercial);
    serviceAccessible.setServiceCommercial(pivotreference);
    pivotreference = new PIVOTREFERENCE();
    pivotreference.setIdref(serviceAccessible);

    listPivotRef.add(pivotreference);

    for (int i = 1; i < 11; i++)
    {
      serviceAccessible = new ServiceAccessible();
      serviceCommercial = new ServiceCommercial();
      serviceAccessible.setId("SA-REF" + i); //$NON-NLS-1$
      serviceCommercial.setId("SC-" + i); //$NON-NLS-1$
      serviceCommercial.setNoServiceCommercial("1645"); //$NON-NLS-1$
      pivotreference = new PIVOTREFERENCE();
      pivotreference.setIdref(serviceCommercial);
      serviceAccessible.setServiceCommercial(pivotreference);
      pivotreference = new PIVOTREFERENCE();
      pivotreference.setIdref(serviceAccessible);
      listPivotRef.add(pivotreference);
    }

    return listPivotRef;
  }

}
