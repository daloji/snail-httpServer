/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PI0253;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.easymock.EasyMock;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.test.context.ContextConfiguration;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.data.exchange.generated.RavelRequest.RequestHeader;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.request.Parameter;
import com.bytel.ravel.common.factory.request.UrlParameters;
import com.bytel.ravel.common.factory.response.IRavelResponse;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.utils.ACManagerUtil;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.RetourFactoryForTU;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.utils.Test_Consts;
import com.bytel.spirit.common.activities.shared.BL5240_LibererRessourceRaccordement;
import com.bytel.spirit.common.activities.shared.BL5240_LibererRessourceRaccordement.BL5240_LibererRessourceRaccordementBuilder;
import com.bytel.spirit.common.connectors.rst.RSTProxy;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.RetourConverter;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.TypeObjetCommercial;
import com.bytel.spirit.common.shared.saab.rst.ServiceTechnique;
import com.bytel.spirit.common.shared.saab.rst.StLienAllocationCommercial;
import com.bytel.spirit.common.shared.saab.rst.StPfsGenerique;
import com.bytel.spirit.common.shared.saab.rst.Statut;
import com.bytel.spirit.common.shared.saab.rst.TypeST;
import com.bytel.spirit.prof.processes.PI0253.structs.STI253Response;
import com.bytel.spirit.prof.processes.PI0253.structs.STI253Response.ReponseFonctionnelle;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author rrosa
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@ContextConfiguration("classpath:BeansProcessTestMocks.xml")
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
@PrepareForTest({ PI0253_LibererRessourceRaccordement.class, RSTProxy.class, BL5240_LibererRessourceRaccordement.class, BL5240_LibererRessourceRaccordementBuilder.class })
public class PI0253_LibererRessourceRaccordementTest
{
  /**
   * Tracabilite
   */
  private static Tracabilite _tracabilite;

  /**
   * Factory de génération des beans
   */
  private static PodamFactory __podam = new PodamFactoryImpl();

  /**
   * SPRING context
   */
  @SuppressWarnings("unused")
  private static ClassPathXmlApplicationContext __context;

  /**
   * Initialization method: Create: - spring context - connectors - service manager.
   *
   * @throws RavelException
   *           the exception
   */
  @BeforeClass
  public static void init() throws RavelException
  {
    // désactivation du cache podam
    __podam.getStrategy().setMemoization(false);
    __podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());

    ACManagerUtil.resetACManager();
    __context = new ClassPathXmlApplicationContext("classpath:BeansProcessTestMocks.xml"); //$NON-NLS-1$

  }

  /**
   * RST Proxy
   */
  @MockStrict
  private RSTProxy _rstProxy;

  /**
   * BL5240_LibererRessourceRaccordementBuilder mock
   */
  @MockStrict
  private BL5240_LibererRessourceRaccordementBuilder _bl5240BuilderMock;

  /**
   * BL5240_LibererRessourceRaccordement
   */
  @MockStrict
  private BL5240_LibererRessourceRaccordement _bl5240Mock;

  /**
   * Instance of {@link PI0253_LibererRessourceRaccordement}
   */
  private PI0253_LibererRessourceRaccordement _processInstance;

  /**
   * Test case where both idRessource and idSt are null in request.
   *
   * <b> Expected: </ b> Return NOK (CAT3, ENTREE_INCORRECTE, Non respect du format d'entrée de la STI) <br/>
   *
   * @throws Throwable
   *           in case of error
   */
  @Test
  public void PI0253_LibererRessourceRaccordementTest_001() throws Throwable
  {
    com.bytel.ravel.types.Retour retourExpected = RetourConverter.convertToJsonRetour(RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ENTREE_INCORRECTE, "Paramètre [idRessource] null ou vide dans la requête.", "PI0253_BL001_VerifierDonnees")); //$NON-NLS-1$ //$NON-NLS-2$
    STI253Response expected = new STI253Response(retourExpected);

    ReponseFonctionnelle reponseFonctionnelle = null;
    reponseFonctionnelle = new ReponseFonctionnelle();
    reponseFonctionnelle.setTracabilite(_tracabilite);
    expected.setReponseFonctionnelle(reponseFonctionnelle);

    Request request = prepareRequest(null, null);

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();
    STI253Response actual = GsonTools.getIso8601Ms().fromJson(response.getGenericResponse().getResult(), STI253Response.class);

    assertEquals(ErrorCode.KO_00400, response.getErrorCode());

    Assert.assertNotNull(actual.getReponseFonctionnelle());
    checkRetour(expected.getRetour(), actual.getRetour());

  }

  /**
   * Test case where the BL5240 returns KO CAT-1.
   *
   * <b> Expected: </ b> Return NOK (CAT1) , errorCode = 503<br/>
   *
   * @throws Throwable
   *           in case of error
   */
  @Test
  public void PI0253_LibererRessourceRaccordementTest_0010() throws Throwable
  {
    Retour retourKO = RetourFactoryForTU.createNOK(IMegConsts.CAT1, null, null);

    ServiceTechnique stLAC = new StLienAllocationCommercial("idSt", Statut.INDETERMINE.name(), "clientOperateur", "noCompte", TypeObjetCommercial.PA.name(), "clientOperateur", "noCompte", "idRessource", TypeST.RACCO.name()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$

    ConnectorResponse<Retour, List<ServiceTechnique>> respRst = new ConnectorResponse<>(RetourFactory.createOkRetour(), Arrays.asList(stLAC));

    com.bytel.ravel.types.Retour retourExpected = RetourConverter.convertToJsonRetour(retourKO);
    STI253Response expected = new STI253Response(retourExpected);

    ReponseFonctionnelle reponseFonctionnelle = null;
    reponseFonctionnelle = new ReponseFonctionnelle();
    reponseFonctionnelle.setTracabilite(_tracabilite);
    expected.setReponseFonctionnelle(reponseFonctionnelle);

    Request request = prepareRequest("idRessource", "idSt"); //$NON-NLS-1$ //$NON-NLS-2$

    EasyMock.expect(RSTProxy.getInstance()).andReturn(_rstProxy);
    EasyMock.expect(_rstProxy.serviceTechniqueLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("idSt"))).andReturn(respRst); //$NON-NLS-1$

    //Mock Activity
    PowerMock.expectNew(BL5240_LibererRessourceRaccordementBuilder.class).andReturn(_bl5240BuilderMock);
    EasyMock.expect(_bl5240BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl5240BuilderMock);
    EasyMock.expect(_bl5240BuilderMock.idRessource("idRessource")).andReturn(_bl5240BuilderMock); //$NON-NLS-1$
    EasyMock.expect(_bl5240BuilderMock.idLienAllocation("idSt")).andReturn(_bl5240BuilderMock); //$NON-NLS-1$

    //Build Activity
    EasyMock.expect(_bl5240BuilderMock.build()).andReturn(_bl5240Mock);
    EasyMock.expect(_bl5240Mock.execute(_processInstance)).andReturn(null);
    EasyMock.expect(_bl5240Mock.getRetour()).andReturn(retourKO);

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();
    STI253Response actual = GsonTools.getIso8601Ms().fromJson(response.getGenericResponse().getResult(), STI253Response.class);

    assertEquals(ErrorCode.KO_00503, response.getErrorCode());

    Assert.assertNotNull(actual.getReponseFonctionnelle());
    checkRetour(expected.getRetour(), actual.getRetour());
  }

  /**
   * Test case where the BL5240 returns KO CAT-10.
   *
   * <b> Expected: </ b> Return NOK (CAT10) , errorCode = 500<br/>
   *
   * @throws Throwable
   *           in case of error
   */
  @Test
  public void PI0253_LibererRessourceRaccordementTest_0011() throws Throwable
  {
    Retour retourKO = RetourFactoryForTU.createNOK(IMegConsts.CAT10, null, null);
    StLienAllocationCommercial stLAC = new StLienAllocationCommercial("idSt", Statut.INDETERMINE.name(), "clientOperateur", "noCompte", TypeObjetCommercial.PA.name(), "clientOperateur", "noCompte", "idRessource", TypeST.RACCO.name()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$

    ConnectorResponse<Retour, List<ServiceTechnique>> respRst = new ConnectorResponse<>(RetourFactory.createOkRetour(), Arrays.asList(stLAC));

    com.bytel.ravel.types.Retour retourExpected = RetourConverter.convertToJsonRetour(retourKO);
    STI253Response expected = new STI253Response(retourExpected);

    ReponseFonctionnelle reponseFonctionnelle = null;
    reponseFonctionnelle = new ReponseFonctionnelle();
    reponseFonctionnelle.setTracabilite(_tracabilite);
    expected.setReponseFonctionnelle(reponseFonctionnelle);

    Request request = prepareRequest("idRessource", "idSt"); //$NON-NLS-1$ //$NON-NLS-2$

    EasyMock.expect(RSTProxy.getInstance()).andReturn(_rstProxy);
    EasyMock.expect(_rstProxy.serviceTechniqueLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("idSt"))).andReturn(respRst); //$NON-NLS-1$

    //Mock Activity
    PowerMock.expectNew(BL5240_LibererRessourceRaccordementBuilder.class).andReturn(_bl5240BuilderMock);
    EasyMock.expect(_bl5240BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl5240BuilderMock);
    EasyMock.expect(_bl5240BuilderMock.idRessource("idRessource")).andReturn(_bl5240BuilderMock); //$NON-NLS-1$
    EasyMock.expect(_bl5240BuilderMock.idLienAllocation("idSt")).andReturn(_bl5240BuilderMock); //$NON-NLS-1$

    //Build Activity
    EasyMock.expect(_bl5240BuilderMock.build()).andReturn(_bl5240Mock);
    EasyMock.expect(_bl5240Mock.execute(_processInstance)).andReturn(null);
    EasyMock.expect(_bl5240Mock.getRetour()).andReturn(retourKO);

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();
    STI253Response actual = GsonTools.getIso8601Ms().fromJson(response.getGenericResponse().getResult(), STI253Response.class);

    assertEquals(ErrorCode.KO_00500, response.getErrorCode());

    Assert.assertNotNull(actual.getReponseFonctionnelle());
    checkRetour(expected.getRetour(), actual.getRetour());
  }

  /**
   * Test case where idSt is null in request.
   *
   * <b> Expected: </ b> Return NOK (CAT3, ENTREE_INCORRECTE, Non respect du format d'entrée de la STI) <br/>
   *
   * @throws Throwable
   *           in case of error
   */
  @Test
  public void PI0253_LibererRessourceRaccordementTest_002() throws Throwable
  {
    com.bytel.ravel.types.Retour retourExpected = RetourConverter.convertToJsonRetour(RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ENTREE_INCORRECTE, "Paramètre [idSt] null ou vide dans la requête.", "PI0253_BL001_VerifierDonnees")); //$NON-NLS-1$ //$NON-NLS-2$
    STI253Response expected = new STI253Response(retourExpected);

    ReponseFonctionnelle reponseFonctionnelle = null;
    reponseFonctionnelle = new ReponseFonctionnelle();
    reponseFonctionnelle.setTracabilite(_tracabilite);
    expected.setReponseFonctionnelle(reponseFonctionnelle);

    Request request = prepareRequest("idRessource", null); //$NON-NLS-1$

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();
    STI253Response actual = GsonTools.getIso8601Ms().fromJson(response.getGenericResponse().getResult(), STI253Response.class);

    assertEquals(ErrorCode.KO_00400, response.getErrorCode());

    Assert.assertNotNull(actual.getReponseFonctionnelle());
    checkRetour(expected.getRetour(), actual.getRetour());
  }

  /**
   * Test case where idRessource is null in request.
   *
   * <b> Expected: </ b> Return NOK (CAT3, ENTREE_INCORRECTE, Non respect du format d'entrée de la STI) <br/>
   *
   * @throws Throwable
   *           in case of error
   */
  @Test
  public void PI0253_LibererRessourceRaccordementTest_003() throws Throwable
  {
    com.bytel.ravel.types.Retour retourExpected = RetourConverter.convertToJsonRetour(RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ENTREE_INCORRECTE, "Paramètre [idRessource] null ou vide dans la requête.", "PI0253_BL001_VerifierDonnees")); //$NON-NLS-1$ //$NON-NLS-2$
    STI253Response expected = new STI253Response(retourExpected);

    ReponseFonctionnelle reponseFonctionnelle = null;
    reponseFonctionnelle = new ReponseFonctionnelle();
    reponseFonctionnelle.setTracabilite(_tracabilite);
    expected.setReponseFonctionnelle(reponseFonctionnelle);

    Request request = prepareRequest(null, "idSt"); //$NON-NLS-1$

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();
    STI253Response actual = GsonTools.getIso8601Ms().fromJson(response.getGenericResponse().getResult(), STI253Response.class);

    assertEquals(ErrorCode.KO_00400, response.getErrorCode());

    Assert.assertNotNull(actual.getReponseFonctionnelle());
    checkRetour(expected.getRetour(), actual.getRetour());
  }

  /**
   * Test case where rst.serviceTechniqueLireUn returns KO.
   *
   * <b> Expected: </ b> Return NOK (CAT4, DONNEE_INCONNUE) <br/>
   *
   * @throws Throwable
   *           in case of error
   */
  @Test
  public void PI0253_LibererRessourceRaccordementTest_004() throws Throwable
  {
    Retour retourKO = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, null, "PI0253_BL001_VerifierDonnees"); //$NON-NLS-1$
    com.bytel.ravel.types.Retour retourExpected = RetourConverter.convertToJsonRetour(retourKO);
    STI253Response expected = new STI253Response(retourExpected);

    ReponseFonctionnelle reponseFonctionnelle = null;
    reponseFonctionnelle = new ReponseFonctionnelle();
    reponseFonctionnelle.setTracabilite(_tracabilite);
    expected.setReponseFonctionnelle(reponseFonctionnelle);

    ConnectorResponse<Retour, List<ServiceTechnique>> respRst = new ConnectorResponse<>(retourKO, null);

    Request request = prepareRequest("idRessource", "idSt"); //$NON-NLS-1$ //$NON-NLS-2$

    EasyMock.expect(RSTProxy.getInstance()).andReturn(_rstProxy);
    EasyMock.expect(_rstProxy.serviceTechniqueLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("idSt"))).andReturn(respRst); //$NON-NLS-1$

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();
    STI253Response actual = GsonTools.getIso8601Ms().fromJson(response.getGenericResponse().getResult(), STI253Response.class);

    assertEquals(ErrorCode.KO_00404, response.getErrorCode());

    Assert.assertNotNull(actual.getReponseFonctionnelle());
    checkRetour(expected.getRetour(), actual.getRetour());
  }

  /**
   * Test case where the st returned by the rst.serviceTechniqueLireUn has statut different from INDETERMINE.
   *
   * <b> Expected: </ b> Return NOK (CAT3, DONNEE_INVALIDE) <br/>
   *
   * @throws Throwable
   *           in case of error
   */
  @Test
  public void PI0253_LibererRessourceRaccordementTest_005() throws Throwable
  {
    Retour retourKO = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegConsts.DONNEE_INVALIDE, null, "PI0253_BL001_VerifierDonnees"); //$NON-NLS-1$

    StLienAllocationCommercial stLAC = new StLienAllocationCommercial("idSt", Statut.INACTIF.name(), "clientOperateur", "noCompte", TypeObjetCommercial.PA.name(), "clientOperateur", "noCompte", "idRessource", TypeST.LAC.name()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$

    ConnectorResponse<Retour, List<ServiceTechnique>> respRst = new ConnectorResponse<>(RetourFactory.createOkRetour(), Arrays.asList(stLAC));

    com.bytel.ravel.types.Retour retourExpected = RetourConverter.convertToJsonRetour(retourKO);
    STI253Response expected = new STI253Response(retourExpected);

    ReponseFonctionnelle reponseFonctionnelle = null;
    reponseFonctionnelle = new ReponseFonctionnelle();
    reponseFonctionnelle.setTracabilite(_tracabilite);
    expected.setReponseFonctionnelle(reponseFonctionnelle);

    Request request = prepareRequest("idRessource", "idSt"); //$NON-NLS-1$ //$NON-NLS-2$

    EasyMock.expect(RSTProxy.getInstance()).andReturn(_rstProxy);
    EasyMock.expect(_rstProxy.serviceTechniqueLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("idSt"))).andReturn(respRst); //$NON-NLS-1$

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();
    STI253Response actual = GsonTools.getIso8601Ms().fromJson(response.getGenericResponse().getResult(), STI253Response.class);

    assertEquals(ErrorCode.KO_00400, response.getErrorCode());

    Assert.assertNotNull(actual.getReponseFonctionnelle());
    checkRetour(expected.getRetour(), actual.getRetour());
  }

  /**
   * Test case where the st returned by the rst.serviceTechniqueLireUn has no StLienAllocationCommercial.
   *
   * <b> Expected: </ b> Return NOK (CAT3, ENTREE_INCORRECTE) <br/>
   *
   * @throws Throwable
   *           in case of error
   */
  @Test
  public void PI0253_LibererRessourceRaccordementTest_006() throws Throwable
  {
    Retour retourKO = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ENTREE_INCORRECTE, "Le ST correspondant à l’idSt n'est pas du Type LAC."); //$NON-NLS-1$

    StPfsGenerique stPfsGenerique = new StPfsGenerique("idSt", Statut.INACTIF.name(), "clientOperateur", "noCompte", TypeObjetCommercial.PA.name(), null, null); //$NON-NLS-1$ //$NON-NLS-2$//$NON-NLS-3$
    ConnectorResponse<Retour, List<ServiceTechnique>> respRst = new ConnectorResponse<>(RetourFactory.createOkRetour(), Arrays.asList(stPfsGenerique));

    com.bytel.ravel.types.Retour retourExpected = RetourConverter.convertToJsonRetour(retourKO);
    STI253Response expected = new STI253Response(retourExpected);

    ReponseFonctionnelle reponseFonctionnelle = null;
    reponseFonctionnelle = new ReponseFonctionnelle();
    reponseFonctionnelle.setTracabilite(_tracabilite);
    expected.setReponseFonctionnelle(reponseFonctionnelle);

    Request request = prepareRequest("idRessource", "idSt"); //$NON-NLS-1$ //$NON-NLS-2$

    EasyMock.expect(RSTProxy.getInstance()).andReturn(_rstProxy);
    EasyMock.expect(_rstProxy.serviceTechniqueLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("idSt"))).andReturn(respRst); //$NON-NLS-1$

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();
    STI253Response actual = GsonTools.getIso8601Ms().fromJson(response.getGenericResponse().getResult(), STI253Response.class);

    assertEquals(ErrorCode.KO_00400, response.getErrorCode());

    Assert.assertNotNull(actual.getReponseFonctionnelle());
    checkRetour(expected.getRetour(), actual.getRetour());
  }

  /**
   * Test case where the stLAC returned by the rst.serviceTechniqueLireUn has typeRessource different from RACCO.
   *
   * <b> Expected: </ b> Return NOK (CAT3, DONNEE_INVALIDE) <br/>
   *
   * @throws Throwable
   *           in case of error
   */
  @Test
  public void PI0253_LibererRessourceRaccordementTest_007() throws Throwable
  {
    Retour retourKO = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegConsts.DONNEE_INVALIDE, null, "PI0253_BL001_VerifierDonnees"); //$NON-NLS-1$

    StLienAllocationCommercial stLAC = new StLienAllocationCommercial("idSt", Statut.INDETERMINE.name(), "clientOperateur", "noCompte", TypeObjetCommercial.PA.name(), "clientOperateur", "noCompte", "idRessource", TypeST.LAC.name()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$

    ConnectorResponse<Retour, List<ServiceTechnique>> respRst = new ConnectorResponse<>(RetourFactory.createOkRetour(), Arrays.asList(stLAC));

    com.bytel.ravel.types.Retour retourExpected = RetourConverter.convertToJsonRetour(retourKO);
    STI253Response expected = new STI253Response(retourExpected);

    ReponseFonctionnelle reponseFonctionnelle = null;
    reponseFonctionnelle = new ReponseFonctionnelle();
    reponseFonctionnelle.setTracabilite(_tracabilite);
    expected.setReponseFonctionnelle(reponseFonctionnelle);

    Request request = prepareRequest("idRessource", "idSt"); //$NON-NLS-1$ //$NON-NLS-2$

    EasyMock.expect(RSTProxy.getInstance()).andReturn(_rstProxy);
    EasyMock.expect(_rstProxy.serviceTechniqueLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("idSt"))).andReturn(respRst); //$NON-NLS-1$

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();
    STI253Response actual = GsonTools.getIso8601Ms().fromJson(response.getGenericResponse().getResult(), STI253Response.class);

    assertEquals(ErrorCode.KO_00400, response.getErrorCode());

    Assert.assertNotNull(actual.getReponseFonctionnelle());
    checkRetour(expected.getRetour(), actual.getRetour());
  }

  /**
   * Test case where the stLAC returned by the rst.serviceTechniqueLireUn has idRessource different from the idRessource
   * in the request.
   *
   * <b> Expected: </ b> Return NOK (CAT3, DONNEE_INVALIDE) <br/>
   *
   * @throws Throwable
   *           in case of error
   */
  @Test
  public void PI0253_LibererRessourceRaccordementTest_008() throws Throwable
  {
    Retour retourKO = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegConsts.DONNEE_INVALIDE, null, "PI0253_BL001_VerifierDonnees"); //$NON-NLS-1$

    StLienAllocationCommercial stLAC = new StLienAllocationCommercial("idSt", Statut.INDETERMINE.name(), "clientOperateur", "noCompte", TypeObjetCommercial.PA.name(), "clientOperateur", "noCompte", "idRessource2", TypeST.RACCO.name()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$

    ConnectorResponse<Retour, List<ServiceTechnique>> respRst = new ConnectorResponse<>(RetourFactory.createOkRetour(), Arrays.asList(stLAC));

    com.bytel.ravel.types.Retour retourExpected = RetourConverter.convertToJsonRetour(retourKO);
    STI253Response expected = new STI253Response(retourExpected);

    ReponseFonctionnelle reponseFonctionnelle = null;
    reponseFonctionnelle = new ReponseFonctionnelle();
    reponseFonctionnelle.setTracabilite(_tracabilite);
    expected.setReponseFonctionnelle(reponseFonctionnelle);

    Request request = prepareRequest("idRessource", "idSt"); //$NON-NLS-1$ //$NON-NLS-2$

    EasyMock.expect(RSTProxy.getInstance()).andReturn(_rstProxy);
    EasyMock.expect(_rstProxy.serviceTechniqueLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("idSt"))).andReturn(respRst); //$NON-NLS-1$

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();
    STI253Response actual = GsonTools.getIso8601Ms().fromJson(response.getGenericResponse().getResult(), STI253Response.class);

    assertEquals(ErrorCode.KO_00400, response.getErrorCode());

    Assert.assertNotNull(actual.getReponseFonctionnelle());
    checkRetour(expected.getRetour(), actual.getRetour());
  }

  /**
   * Test case where the stLAC returned by the rst.serviceTechniqueLireUn has typeObjetCommercial different from PA. in
   * the request.
   *
   * <b> Expected: </ b> Return NOK (CAT3, DONNEE_INVALIDE) <br/>
   *
   * @throws Throwable
   *           in case of error
   */
  @Test
  public void PI0253_LibererRessourceRaccordementTest_009() throws Throwable
  {
    Retour retourKO = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegConsts.DONNEE_INVALIDE, null, "PI0253_BL001_VerifierDonnees"); //$NON-NLS-1$

    StLienAllocationCommercial stLAC = new StLienAllocationCommercial("idSt", Statut.INDETERMINE.name(), "clientOperateur", "noCompte", TypeObjetCommercial.SA.name(), "clientOperateur", "noCompte", "idRessource", TypeST.RACCO.name()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$

    ConnectorResponse<Retour, List<ServiceTechnique>> respRst = new ConnectorResponse<>(RetourFactory.createOkRetour(), Arrays.asList(stLAC));

    com.bytel.ravel.types.Retour retourExpected = RetourConverter.convertToJsonRetour(retourKO);
    STI253Response expected = new STI253Response(retourExpected);

    ReponseFonctionnelle reponseFonctionnelle = null;
    reponseFonctionnelle = new ReponseFonctionnelle();
    reponseFonctionnelle.setTracabilite(_tracabilite);
    expected.setReponseFonctionnelle(reponseFonctionnelle);

    Request request = prepareRequest("idRessource", "idSt"); //$NON-NLS-1$ //$NON-NLS-2$

    EasyMock.expect(RSTProxy.getInstance()).andReturn(_rstProxy);
    EasyMock.expect(_rstProxy.serviceTechniqueLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("idSt"))).andReturn(respRst); //$NON-NLS-1$

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();
    STI253Response actual = GsonTools.getIso8601Ms().fromJson(response.getGenericResponse().getResult(), STI253Response.class);

    assertEquals(ErrorCode.KO_00400, response.getErrorCode());

    Assert.assertNotNull(actual.getReponseFonctionnelle());
    checkRetour(expected.getRetour(), actual.getRetour());
  }

  /**
   * Test case OK.
   *
   * <b> Expected: </ b> Return OK, errorCode = 200<br/>
   *
   * @throws Throwable
   *           in case of error
   */
  @Test
  public void PI0253_LibererRessourceRaccordementTest_OK() throws Throwable
  {
    StLienAllocationCommercial stLAC = new StLienAllocationCommercial("idSt", Statut.INDETERMINE.name(), "clientOperateur", "noCompte", TypeObjetCommercial.PA.name(), "clientOperateur", "noCompte", "idRessource", TypeST.RACCO.name()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$

    ConnectorResponse<Retour, List<ServiceTechnique>> respRst = new ConnectorResponse<>(RetourFactory.createOkRetour(), Arrays.asList(stLAC));

    com.bytel.ravel.types.Retour retourExpected = RetourConverter.convertToJsonRetour(RetourFactory.createOkRetour());
    STI253Response expected = new STI253Response(retourExpected);

    ReponseFonctionnelle reponseFonctionnelle = null;
    reponseFonctionnelle = new ReponseFonctionnelle();
    reponseFonctionnelle.setTracabilite(_tracabilite);
    expected.setReponseFonctionnelle(reponseFonctionnelle);

    Request request = prepareRequest("idRessource", "idSt"); //$NON-NLS-1$ //$NON-NLS-2$

    EasyMock.expect(RSTProxy.getInstance()).andReturn(_rstProxy);
    EasyMock.expect(_rstProxy.serviceTechniqueLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("idSt"))).andReturn(respRst); //$NON-NLS-1$

    //Mock Activity
    PowerMock.expectNew(BL5240_LibererRessourceRaccordementBuilder.class).andReturn(_bl5240BuilderMock);
    EasyMock.expect(_bl5240BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl5240BuilderMock);
    EasyMock.expect(_bl5240BuilderMock.idRessource("idRessource")).andReturn(_bl5240BuilderMock); //$NON-NLS-1$
    EasyMock.expect(_bl5240BuilderMock.idLienAllocation("idSt")).andReturn(_bl5240BuilderMock); //$NON-NLS-1$

    //Build Activity
    EasyMock.expect(_bl5240BuilderMock.build()).andReturn(_bl5240Mock);
    EasyMock.expect(_bl5240Mock.execute(_processInstance)).andReturn(null);
    EasyMock.expect(_bl5240Mock.getRetour()).andReturn(RetourFactory.createOkRetour());

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();
    STI253Response actual = GsonTools.getIso8601Ms().fromJson(response.getGenericResponse().getResult(), STI253Response.class);

    assertEquals(ErrorCode.OK_00200, response.getErrorCode());

    Assert.assertNull(actual.getReponseFonctionnelle());
    checkRetour(expected.getRetour(), actual.getRetour());
  }

  /**
   * Sets the test
   */
  @Before
  public void setUp()
  {
    _processInstance = new PI0253_LibererRessourceRaccordement();
    _processInstance.initializeContext();

    _tracabilite = new Tracabilite();
    _tracabilite.setIdCorrelationByTel("125667889000877"); //$NON-NLS-1$
    _tracabilite.setIdProcessusSpirit(_processInstance.getIdProcess());
    _tracabilite.setIdCorrelationSpirit(Test_Consts.DEFAULT_MSGID);
    _tracabilite.setNomProcessus(StringConstants.EMPTY_STRING);
    _tracabilite.setNomSysteme(System.getenv("SERVICE")); //$NON-NLS-1$

    PowerMock.resetAll();
    PowerMock.mockStatic(RSTProxy.class);

  }

  /**
   * Compares 2 retours field by field.
   *
   * @param expected_p
   *          retour expected
   * @param actual_p
   *          retour actual
   */
  private void checkRetour(com.bytel.ravel.types.Retour expected_p, com.bytel.ravel.types.Retour actual_p)
  {
    assertEquals(expected_p.getResultat(), actual_p.getResultat());
    assertEquals(expected_p.getCategorie(), actual_p.getCategorie());
    assertEquals(expected_p.getDiagnostic(), actual_p.getDiagnostic());
    assertEquals(expected_p.getLibelle(), actual_p.getLibelle());
  }

  /**
   * Create a new request header
   *
   * @param name
   *          The request header name
   * @param value
   *          The request header value
   * @return the {@link RequestHeader}
   */
  private RequestHeader createHeader(String name, String value)
  {
    RequestHeader requestHeader = new RequestHeader();
    requestHeader.setName(name);
    requestHeader.setValue(value);

    return requestHeader;
  }

  /**
   * Fills the specified request headers
   *
   * @param request_p
   *          The request
   * @param headers_p
   *          the list of headers to add
   */
  private void fillRequestHeaders(Request request_p, RequestHeader... headers_p)
  {
    request_p.getRequestHeader().addAll(Arrays.asList(headers_p));
  }

  /**
   * Create a Generic Request to call PI0253
   *
   * @param idRessource_p
   *          The idRessource to add to the body
   * @param idSt_p
   *          The idSt to add to the body
   * @return GenericRequest to call PI0253
   * @throws RavelException
   *           on error
   */
  private Request prepareRequest(String idRessource_p, String idSt_p) throws RavelException
  {
    Request request = new Request(PI0253_LibererRessourceRaccordement.class.getSimpleName(), "idProcess", "idClient"); //$NON-NLS-1$ //$NON-NLS-2$
    request.setMsgId(Test_Consts.DEFAULT_MSGID);
    request.setContentType("application/json"); //$NON-NLS-1$

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "IHN_EMUTATION"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "LISTAGE_FIBRES"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$

    fillRequestHeaders(request, xProcess, xSource, xRequestId);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();

    if (idRessource_p != null)
    {
      list.add(new Parameter(PI0253_LibererRessourceRaccordement.ParameterUrl.idRessource.name(), idRessource_p));
    }
    if (idSt_p != null)
    {
      list.add(new Parameter(PI0253_LibererRessourceRaccordement.ParameterUrl.idSt.name(), idSt_p));
    }
    urlParametersType.setUrlParameters(list);
    request.setUrlParameters(urlParametersType);

    return request;
  }

}
