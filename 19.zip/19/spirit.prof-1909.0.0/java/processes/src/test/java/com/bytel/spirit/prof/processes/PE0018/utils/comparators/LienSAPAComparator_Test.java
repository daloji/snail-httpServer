/*******************************************************************************
* $Id: LienSAPAComparator_Test.java 17760 2019-02-27 17:02:37Z kbettenc $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PE0018.utils.comparators;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

import org.junit.Test;

import com.bytel.ravel.common.exception.RavelException;
import com.bytel.spirit.common.shared.saab.cmd.Commande;
import com.bytel.spirit.common.shared.saab.cmd.NatureCommande;
import com.bytel.spirit.common.shared.saab.rpg.LienSAPA;
import com.bytel.spirit.common.shared.saab.rpg.PFI;
import com.bytel.spirit.common.shared.saab.rpg.Statut;
import com.bytel.spirit.prof.processes.PE0018.utils.PFIComparatorUtils;
import com.bytel.spirit.prof.processes.PE0018.utils.TypeModificationEnum;
import com.bytel.spirit.prof.processes.PE0018.utils.TypeObjectCommercialEnum;

/**
 *
 * @author jsantos
 * @version ($Revision: 17760 $ $Date: 2019-02-27 18:02:37 +0100 (mer. 27 févr. 2019) $)
 */
public class LienSAPAComparator_Test implements IModificationPFI_Test
{
  /**
   * Creation of a LienSAPA<br>
   *
   * <b>Inputs:</b> A new LienSAPA<br>
   * <b>Expected:</b> Creation done <br>
   *
   * @throws RavelException
   */
  @Test
  public void testCreationLienEptPA_000() throws RavelException
  {
    Commande commande = new Commande();
    LienSAPA lienSAPATarget = buildLienSAPA();
    PFI pfi = new PFI();
    pfi.setClientOperateur("clientOperateur");
    pfi.setNoCompte("noCompte");
    PFIComparatorUtils result = new PFIComparatorUtils();
    result.addPaAndType(lienSAPATarget.getIdentifiantFonctionnelPA(), "TV");

    LienSAPAComparator comparator = new LienSAPAComparator(pfi, commande, result, LocalDateTime.now());
    comparator.getPFIComparatorUtils().setAddUnchangedObjects(true);
    comparator.getPFIComparatorUtils().setPaTypeList(Arrays.asList("LIGNE_FIXE,VOIP,FAX,COMPTE_ACCES,TV".split(","))); //$NON-NLS-1$ //$NON-NLS-2$
    comparator.compare(null, lienSAPATarget);

    assertEquals(Arrays.asList(lienSAPATarget), pfi.getLienSAPA());
    //Check ModificationCommercial
    assertEquals(commande.getIdCmd(), result.getMcList().get(0).getIdCmd());
    assertEquals(AbstractComparator.EN_COURS, result.getMcList().get(0).getStatut());
    assertEquals(TypeObjectCommercialEnum.LIEN_SA_PA.name(), result.getMcList().get(0).getTypeObjetCommercial());
    assertEquals(pfi.getNoCompte(), result.getMcList().get(0).getNoCompte());
    assertEquals(pfi.getClientOperateur(), result.getMcList().get(0).getClientOperateur());
    assertEquals(lienSAPATarget.getIdentifiantFonctionnelPA(), result.getMcList().get(0).getIdentifiantFonctionnelPA());
    assertEquals(lienSAPATarget.getNoServiceAccessible(), result.getMcList().get(0).getNoServiceAccessible());
    //Check ElementComparaison
    assertEquals(TypeObjectCommercialEnum.LIEN_SA_PA.name(), result.getEcList().get(0).getTypeObjetCommercial());
    assertEquals(TypeModificationEnum.CREATION.name(), result.getEcList().get(0).getTypeOperation());
    assertEquals(pfi.getClientOperateur(), result.getEcList().get(0).getClientOperateur());
    assertEquals(lienSAPATarget.getNoServiceAccessible(), result.getEcList().get(0).getNoServiceAccessible());
    assertEquals(lienSAPATarget.getIdentifiantFonctionnelPA(), result.getEcList().get(0).getIdentifiantFonctionnelPA());
  }

  /**
   * Creation of a LienSAPA<br>
   *
   * <b>Inputs:</b> A new LienSAPA<br>
   * <b>Expected:</b> Creation done <br>
   */
  @Test
  public void testCreationLienEptPA_001() throws RavelException
  {
    Commande commande = new Commande();
    LienSAPA lienSAPATarget = buildLienSAPA();
    PFI pfi = new PFI();
    pfi.setClientOperateur("clientOperateur");
    pfi.setNoCompte("noCompte");
    PFIComparatorUtils result = new PFIComparatorUtils();

    LienSAPAComparator comparator = new LienSAPAComparator(pfi, commande, result, LocalDateTime.now());
    comparator.getPFIComparatorUtils().setAddUnchangedObjects(true);
    comparator.getPFIComparatorUtils().setPaTypeList(Arrays.asList("LIGNE_FIXE,VOIP,FAX,COMPTE_ACCES,TV".split(","))); //$NON-NLS-1$ //$NON-NLS-2$
    comparator.compare(null, lienSAPATarget);

    assertTrue(pfi.getLienSAPA().isEmpty());

    //Check ModificationCommercial
    assertTrue(result.getMcList().isEmpty());
    assertTrue(result.getEcList().isEmpty());
  }

  /**
   * Test case when is to delete a LienSAPA and AddUnchangedObjects is false
   */
  @Test
  public void testEqualsLienEptPA_001() throws RavelException
  {
    Commande commande = new Commande();
    PFI pfi = new PFI();
    LienSAPA lienSAPASource = buildLienSAPA();
    PFIComparatorUtils result = new PFIComparatorUtils();
    result.addPaAndType(lienSAPASource.getIdentifiantFonctionnelPA(), "TV");
    addLienSAPA(pfi, lienSAPASource);
    LienSAPAComparator comparator = new LienSAPAComparator(pfi, commande, result, LocalDateTime.now());
    comparator.getPFIComparatorUtils().setAddUnchangedObjects(false);
    comparator.getPFIComparatorUtils().setPaTypeList(Arrays.asList("LIGNE_FIXE,VOIP,FAX,COMPTE_ACCES,TV".split(","))); //$NON-NLS-1$ //$NON-NLS-2$
    comparator.compare(lienSAPASource, lienSAPASource);

    assertEquals(1, pfi.getLienSAPA().size());
    //Check ModificationCommercial
    assertEquals(0, result.getMcList().size());
    //Check ElementComparaison
    assertEquals(0, result.getEcList().size());
  }

  /**
   * Test case when is to delete a LienSAPA
   */
  @Test
  public void testEqualsLienEptPA_002() throws RavelException
  {
    Commande commande = new Commande();
    PFI pfi = new PFI();
    LienSAPA lienSAPASource = buildLienSAPA();
    PFIComparatorUtils result = new PFIComparatorUtils();
    result.addPaAndType(lienSAPASource.getIdentifiantFonctionnelPA(), "TV");
    addLienSAPA(pfi, lienSAPASource);

    LienSAPAComparator comparator = new LienSAPAComparator(pfi, commande, result, LocalDateTime.now());
    comparator.getPFIComparatorUtils().setAddUnchangedObjects(true);
    comparator.getPFIComparatorUtils().setPaTypeList(Arrays.asList("LIGNE_FIXE,VOIP,FAX,COMPTE_ACCES,TV".split(","))); //$NON-NLS-1$ //$NON-NLS-2$
    comparator.compare(lienSAPASource, lienSAPASource);

    assertEquals(1, pfi.getLienSAPA().size());
    //Check ModificationCommercial
    assertEquals(0, result.getMcList().size());
    //Check ElementComparaison
    assertEquals(TypeObjectCommercialEnum.LIEN_SA_PA.name(), result.getEcList().get(0).getTypeObjetCommercial());
    assertEquals(TypeModificationEnum.AUCUNE.name(), result.getEcList().get(0).getTypeOperation());
    assertEquals(IModificationValue_Test.NO_SERVICE_ACCESSIBLE, result.getEcList().get(0).getNoServiceAccessible());
    assertEquals(IModificationValue_Test.ID_FONCTIONNEL_PA, result.getEcList().get(0).getIdentifiantFonctionnelPA());
    assertEquals(0, result.getEcList().get(0).getListeAttributModifie().size());
  }

  /**
   * Modification of a LienSAPA in a PFI from a Commande with NatureCommande PHOTO <br>
   *
   * <b>Inputs:</b> Commande with NatureCommande = PHOTO <br>
   * <b>Expected:</b> Modification done with a complete copy of the LienSAPA <br>
   */
  @Test
  public void testModificationLienSAPA_001() throws RavelException
  {
    Commande commande = new Commande();
    commande.setNatureCommande(NatureCommande.PHOTO_PFI.name());

    PFI pfi = new PFI();
    LienSAPA lienSAPASource = buildLienSAPA();
    addLienSAPA(pfi, lienSAPASource);

    LienSAPA lienSAPATarget = new LienSAPA();
    lienSAPATarget.setNoServiceAccessible(lienSAPASource.getNoServiceAccessible()); //IDs need to be equals
    lienSAPATarget.setIdentifiantFonctionnelPA(lienSAPASource.getIdentifiantFonctionnelPA()); //IDs need to be equals
    lienSAPATarget.setStatut(Statut.RESILIE); //Force to be different

    PFIComparatorUtils result = new PFIComparatorUtils();
    result.addPaAndType(lienSAPASource.getIdentifiantFonctionnelPA(), "TV");
    result.setPaTypeList(Arrays.asList("LIGNE_FIXE,VOIP,FAX,COMPTE_ACCES,TV".split(","))); //$NON-NLS-1$ //$NON-NLS-2$
    LienSAPAComparator comparator = new LienSAPAComparator(pfi, commande, result, LocalDateTime.now());
    comparator.compare(lienSAPASource, lienSAPATarget);

    //Check EquipementDeclare
    assertFalse(pfi.getLienSAPA().contains(lienSAPASource));
    assertTrue(pfi.getLienSAPA().contains(lienSAPATarget));

    //Check ModificationCommercial
    assertTrue(result.getMcList().isEmpty());

    //Check ElementComparaison
    assertEquals(TypeObjectCommercialEnum.LIEN_SA_PA.name(), result.getEcList().get(0).getTypeObjetCommercial());
    assertEquals(TypeModificationEnum.MODIF_ATTR.name(), result.getEcList().get(0).getTypeOperation());
    assertEquals(lienSAPATarget.getNoServiceAccessible(), result.getEcList().get(0).getNoServiceAccessible());
    assertEquals(1, result.getEcList().get(0).getListeAttributModifie().size());
  }

  /**
   * Modification of a LienSAPA in a PFI from a Commande with NatureCommande MODIFICATION<br>
   *
   * <b>Inputs:</b> Commande with NatureCommande = MODIFICATION / EquipementDeclare with Statut = RESILIE (all the other
   * attributes are null) <br>
   * <b>Expected:</b> Modification done with a copy of the delta between LienSAPA source and target <br>
   */
  @Test
  public void testModificationLienSAPA_002() throws RavelException
  {
    Commande commande = new Commande();
    commande.setNatureCommande(NatureCommande.MODIFICATION_PFI.name());

    PFI pfi = new PFI();
    LienSAPA lienSAPASource = buildLienSAPA();
    addLienSAPA(pfi, lienSAPASource);

    LienSAPA lienSAPATarget = new LienSAPA(null, null, Statut.RESILIE, null, null);

    PFIComparatorUtils result = new PFIComparatorUtils();
    result.addPaAndType(lienSAPASource.getIdentifiantFonctionnelPA(), "TV");
    result.setPaTypeList(Arrays.asList("LIGNE_FIXE,VOIP,FAX,COMPTE_ACCES,TV".split(","))); //$NON-NLS-1$ //$NON-NLS-2$
    LienSAPAComparator comparator = new LienSAPAComparator(pfi, commande, result, LocalDateTime.now());
    comparator.compare(lienSAPASource, lienSAPATarget);

    //Only the status changes (=the one in the target)
    assertEquals(lienSAPATarget.getStatut(), pfi.getLienSAPA().get(0).getStatut());
    assertEquals(IModificationValue_Test.NO_SERVICE_ACCESSIBLE, pfi.getLienSAPA().get(0).getNoServiceAccessible());
    assertEquals(IModificationValue_Test.ID_FONCTIONNEL_PA, pfi.getLienSAPA().get(0).getIdentifiantFonctionnelPA());

    //Check ModificationCommercial
    assertEquals(0, result.getMcList().size());
    //Check ElementComparaison
    assertEquals(TypeObjectCommercialEnum.LIEN_SA_PA.name(), result.getEcList().get(0).getTypeObjetCommercial());
    assertEquals(TypeModificationEnum.MODIF_ATTR.name(), result.getEcList().get(0).getTypeOperation());
    assertNull(result.getEcList().get(0).getNoServiceAccessible());
    assertEquals(1, result.getEcList().get(0).getListeAttributModifie().size());
  }

  /**
   * Deletion of a LienSAPA with Statut ACTIF<br>
   *
   * <b>Inputs:</b> LienSAPA with Statut = ACTIF <br>
   * <b>Expected:</b> The status of LienSAPA source is now RESILIE <br>
   */
  @Test
  public void testSuppressionLienEptPA_001() throws RavelException
  {
    Commande commande = new Commande();
    PFI pfi = new PFI();
    LienSAPA lienSAPASource = buildLienSAPA();
    PFIComparatorUtils result = new PFIComparatorUtils();
    result.addPaAndType(lienSAPASource.getIdentifiantFonctionnelPA(), "TV");
    result.setPaTypeList(Arrays.asList("LIGNE_FIXE,VOIP,FAX,COMPTE_ACCES,TV".split(","))); //$NON-NLS-1$ //$NON-NLS-2$
    addLienSAPA(pfi, lienSAPASource);

    LienSAPAComparator comparator = new LienSAPAComparator(pfi, commande, result, LocalDateTime.now());
    comparator.compare(lienSAPASource, null);

    assertEquals(1, pfi.getLienSAPA().size());
    assertEquals(Statut.RESILIE, pfi.getLienSAPA().get(0).getStatut());

    //Check ModificationCommerciale
    assertEquals(commande.getIdCmd(), result.getMcList().get(0).getIdCmd());
    assertEquals(AbstractComparator.EN_COURS, result.getMcList().get(0).getStatut());
    assertEquals(TypeObjectCommercialEnum.LIEN_SA_PA.name(), result.getMcList().get(0).getTypeObjetCommercial());
    assertEquals(pfi.getNoCompte(), result.getMcList().get(0).getNoCompte());
    assertEquals(commande.getClientOperateur(), result.getMcList().get(0).getClientOperateur());
    assertEquals(IModificationValue_Test.ID_FONCTIONNEL_PA, result.getMcList().get(0).getIdentifiantFonctionnelPA());
    assertEquals(IModificationValue_Test.NO_SERVICE_ACCESSIBLE, result.getMcList().get(0).getNoServiceAccessible());
    assertEquals(Statut.RESILIE.name(), result.getMcList().get(0).getStatutCommercialAttendu());

    //Check ElementComparaison
    assertEquals(TypeObjectCommercialEnum.LIEN_SA_PA.name(), result.getEcList().get(0).getTypeObjetCommercial());
    assertEquals(TypeModificationEnum.SUPPRESSION.name(), result.getEcList().get(0).getTypeOperation());
    assertEquals(0, result.getEcList().get(0).getListeAttributModifie().size());
  }

  /**
   * Deletion of a LienSAPA with Statut RESILIE<br>
   *
   * <b>Inputs:</b> LienSAPA with Statut = RESILIE <br>
   * <b>Expected:</b> The LienSAPA source stays the sames <br>
   */
  @Test
  public void testSuppressionLienEptPA_002() throws RavelException
  {
    Commande commande = new Commande();
    PFI pfi = new PFI();
    LienSAPA lienSAPASource = buildLienSAPA();
    lienSAPASource.setStatut(Statut.RESILIE);
    addLienSAPA(pfi, lienSAPASource);

    PFIComparatorUtils result = new PFIComparatorUtils();
    result.addPaAndType(lienSAPASource.getIdentifiantFonctionnelPA(), "TV");
    result.setPaTypeList(Arrays.asList("LIGNE_FIXE,VOIP,FAX,COMPTE_ACCES,TV".split(","))); //$NON-NLS-1$ //$NON-NLS-2$
    LienSAPAComparator comparator = new LienSAPAComparator(pfi, commande, result, LocalDateTime.now());
    comparator.compare(lienSAPASource, null);

    assertEquals(Arrays.asList(lienSAPASource), pfi.getLienSAPA());

    //Check ModificationCommercial
    assertTrue(result.getMcList().isEmpty());
    assertTrue(result.getEcList().isEmpty());
  }

  /**
   * @param pfi
   * @param LienSAPA
   */
  private void addLienSAPA(PFI pfi, LienSAPA LienSAPA)
  {
    List<LienSAPA> lienEqpPAList = pfi.getLienSAPA();
    lienEqpPAList.add(LienSAPA);
    pfi.setLienSAPA(lienEqpPAList);
  }
}
