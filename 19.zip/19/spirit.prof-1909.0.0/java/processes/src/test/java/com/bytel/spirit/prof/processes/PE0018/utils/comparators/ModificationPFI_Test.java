/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PE0018.utils.comparators;

import static org.junit.Assert.assertEquals;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.junit.Test;

import com.bytel.ravel.common.exception.RavelException;
import com.bytel.spirit.common.shared.saab.cmd.Commande;
import com.bytel.spirit.common.shared.saab.cmd.ModificationCommerciale;
import com.bytel.spirit.common.shared.saab.cmd.NatureCommande;
import com.bytel.spirit.common.shared.saab.rpg.Entreprise;
import com.bytel.spirit.common.shared.saab.rpg.EquipementDeclare;
import com.bytel.spirit.common.shared.saab.rpg.Individu;
import com.bytel.spirit.common.shared.saab.rpg.LienEquipementPA;
import com.bytel.spirit.common.shared.saab.rpg.LienSAPA;
import com.bytel.spirit.common.shared.saab.rpg.PA;
import com.bytel.spirit.common.shared.saab.rpg.PFI;
import com.bytel.spirit.common.shared.saab.rpg.SA;
import com.bytel.spirit.common.shared.saab.rpg.Statut;
import com.bytel.spirit.common.shared.saab.rpg.Titulaire;
import com.bytel.spirit.common.shared.saab.rpg.TypeTitulaire;
import com.bytel.spirit.prof.processes.PE0018.utils.TypeModificationEnum;
import com.bytel.spirit.prof.shared.types.json.PointAccesLigneFixe;

/**
 *
 * @author jgregori
 * @version ($Revision$ $Date$)
 */
public class ModificationPFI_Test implements IModificationPFI_Test
{

  /**
   * Test to compare 2 PFI objects with Changes in EquipementDeclare List. The source has 2 EquipementDeclare to delete.
   * Expected: 2 ModifcationCommercial in the list of ModificationCommercial.
   */
  @Test
  public void testComcompareuipementDeclare_Delete() throws RavelException
  {
    Commande commande = buildCommande();
    EquipementDeclare equip1 = buildEquipementDeclare();
    equip1.setNoEquipement("equip1");
    EquipementDeclare equip2 = buildEquipementDeclare();
    equip2.setNoEquipement("equip2");
    EquipementDeclare equip3 = buildEquipementDeclare();
    equip3.setNoEquipement("equip3");
    PFI source = buildPFI();
    List<EquipementDeclare> equipList = source.getEquipementDeclare();
    equipList.add(equip1);
    equipList.add(equip2);
    equipList.add(equip3);
    source.setEquipementDeclare(equipList);

    PFI target = buildPFI();
    List<EquipementDeclare> paTargetL = target.getEquipementDeclare();
    paTargetL.add(equip1);
    target.setEquipementDeclare(paTargetL);

    PFIComparator pficomp = new PFIComparator(commande, LocalDateTime.now());
    pficomp.getPFIComparatorUtils().setAddUnchangedObjects(true);
    pficomp.getPFIComparatorUtils().setPaTypeList(Arrays.asList("LIGNE_FIXE,VOIP,FAX,COMPTE_ACCES,TV".split(","))); //$NON-NLS-1$ //$NON-NLS-2$
    pficomp.compare(source, target);

    Assert.assertEquals(TypeModificationEnum.SUPPRESSION.name(), getElementComparaisonEq(pficomp._result.getEcList(), "BSS_ENT", "pfi1", "equip2").getTypeOperation());
    Assert.assertEquals(TypeModificationEnum.SUPPRESSION.name(), getElementComparaisonEq(pficomp._result.getEcList(), "BSS_ENT", "pfi1", "equip3").getTypeOperation());
    Assert.assertEquals(Statut.ACTIF, getCommercialObjectByID(source.getEquipementDeclare(), "equip1").getStatut());
    Assert.assertEquals(Statut.RESILIE, getCommercialObjectByID(source.getEquipementDeclare(), "equip2").getStatut());
    Assert.assertEquals(Statut.RESILIE, getCommercialObjectByID(source.getEquipementDeclare(), "equip3").getStatut());
    Assert.assertEquals(2, pficomp._result.getMcList().size()); //is not creation/suppression

  }

  @Test
  public void testComparePFI_00() throws RavelException
  {
    Commande commande = buildCommande();

    PFI source = buildPFIWithLists(1, 3, 2, 3, 2);
    PFI target = buildPFIWithLists(1, 2, 1, 2, 1);

    List<SA> sal = target.getSa();
    sal.addAll(source.getSa());
    target.setSa(sal);

    // 3 PA source + 3 PA target = (PAsource[0] = PAtarget[2] = AUCUNE, PAsource[1] = PAtarget[1] = MODIF, PAsource[2] = SUPPRESSION, PAtarget[0] = CREATION)
    List<PA> pal = target.getPa();
    pal.add(source.getPa().get(0));
    pal.get(1).setIdentifiantFonctionnelPA(source.getPa().get(1).getIdentifiantFonctionnelPA());
    target.setPa(pal);

    // 2 SAPA source + 2 SAPA target
    List<LienSAPA> sapal = target.getLienSAPA();
    sapal.add(source.getLienSAPA().get(0));
    target.setLienSAPA(sapal);

    List<EquipementDeclare> equipl = target.getEquipementDeclare();
    equipl.add(source.getEquipementDeclare().get(0));
    equipl.get(1).setNoEquipement(source.getEquipementDeclare().get(1).getNoEquipement());
    target.setEquipementDeclare(equipl);

    List<LienEquipementPA> equipPa = target.getLienEquipementPA();
    equipPa.add(source.getLienEquipementPA().get(0));
    target.setLienEquipementPA(equipPa);

    PFIComparator pficomp = new PFIComparator(commande, LocalDateTime.now());
    pficomp.getPFIComparatorUtils().setAddUnchangedObjects(true);
    pficomp.getPFIComparatorUtils().setPaTypeList(Arrays.asList("LIGNE_FIXE,VOIP,FAX,COMPTE_ACCES,TV".split(","))); //$NON-NLS-1$ //$NON-NLS-2$
    pficomp.getPFIComparatorUtils().addPaAndType(target.getLienSAPA().get(0).getIdentifiantFonctionnelPA(), "TV");
    pficomp.getPFIComparatorUtils().addPaAndType(target.getLienSAPA().get(1).getIdentifiantFonctionnelPA(), "TV");
    pficomp.getPFIComparatorUtils().addPaAndType(source.getLienSAPA().get(1).getIdentifiantFonctionnelPA(), "TV");
    pficomp.compare(source, target);

    Assert.assertEquals("AUCUNE", getElementComparaisonPFI(pficomp._result.getEcList(), "BSS_ENT", "pfi1").getTypeOperation()); //$NON-NLS-1$ //$NON-NLS-2$
    Assert.assertEquals("CREATION", getElementComparaisonSA(pficomp._result.getEcList(), "BSS_ENT", "pfi1", target.getSa().get(0).getNoServiceAccessible()).getTypeOperation()); //$NON-NLS-1$
    Assert.assertEquals("AUCUNE", getElementComparaisonSA(pficomp._result.getEcList(), "BSS_ENT", "pfi1", target.getSa().get(1).getNoServiceAccessible()).getTypeOperation()); //$NON-NLS-1$

    Assert.assertEquals("CREATION", getElementComparaisonPA(pficomp._result.getEcList(), "BSS_ENT", "pfi1", target.getPa().get(0).getIdentifiantFonctionnelPA()).getTypeOperation()); //$NON-NLS-1$
    Assert.assertEquals("MODIF_ATTR", getElementComparaisonPA(pficomp._result.getEcList(), "BSS_ENT", "pfi1", target.getPa().get(1).getIdentifiantFonctionnelPA()).getTypeOperation()); //$NON-NLS-1$
    Assert.assertEquals("SUPPRESSION", getElementComparaisonPA(pficomp._result.getEcList(), "BSS_ENT", "pfi1", source.getPa().get(1).getIdentifiantFonctionnelPA()).getTypeOperation()); //$NON-NLS-1$
    Assert.assertEquals("AUCUNE", getElementComparaisonPA(pficomp._result.getEcList(), "BSS_ENT", "pfi1", target.getPa().get(2).getIdentifiantFonctionnelPA()).getTypeOperation()); //$NON-NLS-1$

    Assert.assertEquals("CREATION", getElementComparaisonSAPA(pficomp._result.getEcList(), "BSS_ENT", "pfi1", target.getLienSAPA().get(0).getNoServiceAccessible(), target.getLienSAPA().get(0).getIdentifiantFonctionnelPA()).getTypeOperation()); //$NON-NLS-1$
    Assert.assertEquals("AUCUNE", getElementComparaisonSAPA(pficomp._result.getEcList(), "BSS_ENT", "pfi1", target.getLienSAPA().get(1).getNoServiceAccessible(), target.getLienSAPA().get(1).getIdentifiantFonctionnelPA()).getTypeOperation()); //$NON-NLS-1$
    Assert.assertEquals("SUPPRESSION", getElementComparaisonSAPA(pficomp._result.getEcList(), "BSS_ENT", "pfi1", source.getLienSAPA().get(1).getNoServiceAccessible(), source.getLienSAPA().get(1).getIdentifiantFonctionnelPA()).getTypeOperation()); //$NON-NLS-1$

    Assert.assertEquals("CREATION", getElementComparaisonEq(pficomp._result.getEcList(), "BSS_ENT", "pfi1", target.getEquipementDeclare().get(0).getNoEquipement()).getTypeOperation()); //$NON-NLS-1$
    Assert.assertEquals("MODIF_ATTR", getElementComparaisonEq(pficomp._result.getEcList(), "BSS_ENT", "pfi1", target.getEquipementDeclare().get(1).getNoEquipement()).getTypeOperation()); //$NON-NLS-1$
    Assert.assertEquals("SUPPRESSION", getElementComparaisonEq(pficomp._result.getEcList(), "BSS_ENT", "pfi1", source.getEquipementDeclare().get(1).getNoEquipement()).getTypeOperation()); //$NON-NLS-1$
    Assert.assertEquals("AUCUNE", getElementComparaisonEq(pficomp._result.getEcList(), "BSS_ENT", "pfi1", target.getEquipementDeclare().get(2).getNoEquipement()).getTypeOperation()); //$NON-NLS-1$

    Assert.assertEquals("CREATION", getElementComparaisonEqPA(pficomp._result.getEcList(), "BSS_ENT", "pfi1", target.getLienEquipementPA().get(0).getNoEquipement(), target.getLienEquipementPA().get(0).getIdFonctionnelPa()).getTypeOperation()); //$NON-NLS-1$
    Assert.assertEquals("AUCUNE", getElementComparaisonEqPA(pficomp._result.getEcList(), "BSS_ENT", "pfi1", target.getLienEquipementPA().get(1).getNoEquipement(), target.getLienEquipementPA().get(1).getIdFonctionnelPa()).getTypeOperation()); //$NON-NLS-1$
    Assert.assertEquals("SUPPRESSION", getElementComparaisonEqPA(pficomp._result.getEcList(), "BSS_ENT", "pfi1", source.getLienEquipementPA().get(1).getNoEquipement(), source.getLienEquipementPA().get(1).getIdFonctionnelPa()).getTypeOperation()); //$NON-NLS-1$
  }

  /**
   * SPIRIT-129 : La comparaison commerciale d'une commande n'est pas toujours correctement construite <br>
   *
   * Scenario: Compare twice the same PFI:<br>
   * First scenario: Compare 2 PFI objects with changes in all list of attributes.<br>
   * Input: The PFI to be set<br>
   * First result: Suppression of the attributes not present in the target PFI and create the new attributes present in
   * the target<br>
   * Second scenario: Compare 2 PFI objects with changes in all list of attributes.<br>
   * Second result: The attributes present in the PFI already in the state "RESILIE" are not to be considered.<br>
   *
   */
  @Test
  public void testComparePFI_Attributes_Delete() throws RavelException
  {
    Commande commande = buildCommande();
    PFI source = buildPFI();

    SA sa1 = buildSA("sa1");
    List<SA> sal = source.getSa();
    sal.add(sa1);
    source.setSa(sal);

    PA pa1 = buildPA("pa1", PointAccesLigneFixe.TYPE);
    List<PA> pal = source.getPa();
    pal.add(pa1);
    source.setPa(pal);

    LienSAPA lienSAPASource1 = buildLienSAPA();
    lienSAPASource1.setNoServiceAccessible("sa1");
    lienSAPASource1.setIdentifiantFonctionnelPA("pa1");
    List<LienSAPA> lienSAPAList = source.getLienSAPA();
    lienSAPAList.add(lienSAPASource1);
    source.setLienSAPA(lienSAPAList);

    EquipementDeclare equip1 = buildEquipementDeclare();
    equip1.setNoEquipement("eq1"); //$NON-NLS-1$
    List<EquipementDeclare> equiplist = source.getEquipementDeclare();
    equiplist.add(equip1);
    source.setEquipementDeclare(equiplist);

    LienEquipementPA lienEqpPASource1 = buildLienEquipementPA();
    lienEqpPASource1.setNoEquipement("eq1");
    lienEqpPASource1.setIdFonctionnelPa("pa1");

    List<LienEquipementPA> lienEqPaList = source.getLienEquipementPA();
    lienEqPaList.add(lienEqpPASource1);
    source.setLienEquipementPA(lienEqPaList);

    PFI target = buildPFI();
    PA pa2 = buildPA("pa2", PointAccesLigneFixe.TYPE);
    List<PA> paTargetL = target.getPa();
    paTargetL.add(pa2);
    target.setPa(paTargetL);

    PFIComparator pficomp = new PFIComparator(commande, LocalDateTime.now());
    pficomp.getPFIComparatorUtils().setAddUnchangedObjects(true);
    pficomp.getPFIComparatorUtils().setPaTypeList(Arrays.asList("LIGNE_FIXE,VOIP,FAX,COMPTE_ACCES,TV".split(","))); //$NON-NLS-1$ //$NON-NLS-2$
    pficomp.compare(source, target);

    Assert.assertEquals(TypeModificationEnum.SUPPRESSION.name(), getElementComparaisonSA(pficomp._result.getEcList(), "BSS_ENT", "pfi1", "sa1").getTypeOperation());
    Assert.assertEquals(TypeModificationEnum.SUPPRESSION.name(), getElementComparaisonPA(pficomp._result.getEcList(), "BSS_ENT", "pfi1", "pa1").getTypeOperation());
    Assert.assertEquals(TypeModificationEnum.SUPPRESSION.name(), getElementComparaisonSAPA(pficomp._result.getEcList(), "BSS_ENT", "pfi1", "sa1", "pa1").getTypeOperation());
    Assert.assertEquals(TypeModificationEnum.SUPPRESSION.name(), getElementComparaisonEq(pficomp._result.getEcList(), "BSS_ENT", "pfi1", "eq1").getTypeOperation());
    Assert.assertEquals(TypeModificationEnum.SUPPRESSION.name(), getElementComparaisonEqPA(pficomp._result.getEcList(), "BSS_ENT", "pfi1", "eq1", "pa1").getTypeOperation());
    Assert.assertEquals(TypeModificationEnum.CREATION.name(), getElementComparaisonPA(pficomp._result.getEcList(), "BSS_ENT", "pfi1", "pa2").getTypeOperation());

    Assert.assertEquals(Statut.RESILIE, getCommercialObjectByID(source.getSa(), "sa1").getStatut());
    Assert.assertEquals(Statut.RESILIE, getCommercialObjectByID(source.getPa(), "pa1").getStatut());
    Assert.assertEquals(Statut.RESILIE, getCommercialObjectByID(source.getLienSAPA(), "sa1pa1").getStatut());
    Assert.assertEquals(Statut.RESILIE, getCommercialObjectByID(source.getEquipementDeclare(), "eq1").getStatut());
    Assert.assertEquals(Statut.RESILIE, getCommercialObjectByID(source.getLienEquipementPA(), "eq1pa1").getStatut());
    Assert.assertEquals(Statut.ACTIF, getCommercialObjectByID(source.getPa(), "pa2").getStatut());
    Assert.assertEquals(6, pficomp._result.getMcList().size()); //is not creation/suppression

    PFIComparator pficomp2 = new PFIComparator(commande, LocalDateTime.now());
    pficomp2.getPFIComparatorUtils().setAddUnchangedObjects(true);
    pficomp2.getPFIComparatorUtils().setPaTypeList(Arrays.asList("LIGNE_FIXE,VOIP,FAX,COMPTE_ACCES,TV".split(","))); //$NON-NLS-1$ //$NON-NLS-2$

    pficomp2.compare(source, target);
    Assert.assertNull(getElementComparaisonSA(pficomp2._result.getEcList(), "BSS_ENT", "pfi1", "sa1"));
    Assert.assertNull(getElementComparaisonPA(pficomp2._result.getEcList(), "BSS_ENT", "pfi1", "pa1"));
    Assert.assertNull(getElementComparaisonSAPA(pficomp2._result.getEcList(), "BSS_ENT", "pfi1", "sa1", "pa1"));
    Assert.assertNull(getElementComparaisonEq(pficomp2._result.getEcList(), "BSS_ENT", "pfi1", "eq1"));
    Assert.assertNull(getElementComparaisonEqPA(pficomp2._result.getEcList(), "BSS_ENT", "pfi1", "eq1", "pa1"));
    Assert.assertEquals(TypeModificationEnum.AUCUNE.name(), getElementComparaisonPA(pficomp2._result.getEcList(), "BSS_ENT", "pfi1", "pa2").getTypeOperation());

    Assert.assertEquals(Statut.RESILIE, getCommercialObjectByID(source.getSa(), "sa1").getStatut());
    Assert.assertEquals(Statut.RESILIE, getCommercialObjectByID(source.getPa(), "pa1").getStatut());
    Assert.assertEquals(Statut.RESILIE, getCommercialObjectByID(source.getLienSAPA(), "sa1pa1").getStatut());
    Assert.assertEquals(Statut.RESILIE, getCommercialObjectByID(source.getEquipementDeclare(), "eq1").getStatut());
    Assert.assertEquals(Statut.RESILIE, getCommercialObjectByID(source.getLienEquipementPA(), "eq1pa1").getStatut());
    Assert.assertEquals(Statut.ACTIF, getCommercialObjectByID(source.getPa(), "pa2").getStatut());
    Assert.assertEquals(0, pficomp2._result.getMcList().size()); //is not creation/suppression
  }

  /**
   * Test to compare a PFi with a existing empty PFI Expected: The existing PFI should have all of the target PFI
   * commercial objects
   */
  @Test
  public void testComparePFI_Creation() throws RavelException
  {
    Commande commande = buildCommande();
    PFI target = buildPFI();
    PFI source = new PFI();
    PFIComparator pficomp = new PFIComparator(commande, LocalDateTime.now());
    pficomp.compare(source, target);

    Assert.assertEquals("CREATION", getElementComparaisonPFI(pficomp._result.getEcList(), "BSS_ENT", "pfi1").getTypeOperation()); //$NON-NLS-1$ //$NON-NLS-2$
    Assert.assertEquals(1, pficomp._result.getEcList().size());
    Assert.assertEquals(target.getClientOperateur() + target.getNoCompte(), source.getClientOperateur() + source.getNoCompte());
    Assert.assertEquals(target.getTitulaire(), source.getTitulaire());
    Assert.assertEquals(target.getStatut(), source.getStatut());
    Assert.assertEquals(1, pficomp._result.getMcList().size()); //CREATE ModifCo

    assertModificationCommercial(pficomp._result.getMcList().get(0), target); //one ModificationCommercial object is expected
  }

  /**
   * Test to compare two equal PFI
   */
  @Test
  public void testComparePFI_Equals() throws RavelException
  {
    Commande commande = buildCommande();
    PFI source = buildPFI();
    PFI target = buildPFI();

    PFIComparator pficomp = new PFIComparator(commande, LocalDateTime.now());
    pficomp.getPFIComparatorUtils().setAddUnchangedObjects(true);
    pficomp.getPFIComparatorUtils().setPaTypeList(Arrays.asList("LIGNE_FIXE,VOIP,FAX,COMPTE_ACCES,TV".split(","))); //$NON-NLS-1$ //$NON-NLS-2$
    pficomp.compare(source, target);
    Assert.assertEquals("AUCUNE", getElementComparaisonPFI(pficomp._result.getEcList(), "BSS_ENT", "pfi1").getTypeOperation());
    Assert.assertEquals(1, pficomp._result.getEcList().size());

    Assert.assertEquals(0, pficomp._result.getMcList().size()); //is not creation/suppression
  }

  /**
   * Test to compare 2 PFI objects with Changes in EquipementDeclare List. The target has one EquipementDeclare to
   * create Expected: One modificationCommercial object in the list. The source should have a new EquipementDeclare with
   * id equip2
   */

  @Test
  public void testComparePFI_EquipementDeclare_Create() throws RavelException
  {
    Commande commande = buildCommande();
    EquipementDeclare equip1 = buildEquipementDeclare();
    equip1.setNoEquipement("equip1"); //$NON-NLS-1$
    EquipementDeclare equip2 = buildEquipementDeclare();
    equip2.setNoEquipement("equip2"); //$NON-NLS-1$
    PFI source = buildPFI();
    List<EquipementDeclare> equiplist = source.getEquipementDeclare();
    equiplist.add(equip1);
    source.setEquipementDeclare(equiplist);

    PFI target = buildPFI();
    List<EquipementDeclare> equipTargetL = target.getEquipementDeclare();
    equipTargetL.add(equip1);
    equipTargetL.add(equip2);
    target.setEquipementDeclare(equipTargetL);

    PFIComparator pficomp = new PFIComparator(commande, LocalDateTime.now());
    pficomp.getPFIComparatorUtils().setAddUnchangedObjects(true);
    pficomp.getPFIComparatorUtils().setPaTypeList(Arrays.asList("LIGNE_FIXE,VOIP,FAX,COMPTE_ACCES,TV".split(","))); //$NON-NLS-1$ //$NON-NLS-2$
    pficomp.compare(source, target);
    System.out.println(pficomp._result.toString());
    Assert.assertEquals("AUCUNE", getElementComparaisonPFI(pficomp._result.getEcList(), "BSS_ENT", "pfi1").getTypeOperation()); //$NON-NLS-1$//$NON-NLS-2$
    Assert.assertEquals("AUCUNE", getElementComparaisonEq(pficomp._result.getEcList(), "BSS_ENT", "pfi1", "equip1").getTypeOperation()); //$NON-NLS-1$ //$NON-NLS-2$
    Assert.assertEquals("CREATION", getElementComparaisonEq(pficomp._result.getEcList(), "BSS_ENT", "pfi1", "equip2").getTypeOperation()); //$NON-NLS-1$ //$NON-NLS-2$
    Assert.assertNotNull(getCommercialObjectByID(source.getEquipementDeclare(), "equip2")); //$NON-NLS-1$
    Assert.assertEquals(2, source.getEquipementDeclare().size());
    Assert.assertEquals(2, target.getEquipementDeclare().size());
    assertModificationCommercial(pficomp._result.getMcList().get(0), source, getCommercialObjectByID(target.getEquipementDeclare(), "equip2")); //$NON-NLS-1$
  }

  /**
   * Compare 2 PFI with list of many EquipementDeclare objects. Change of type EquipementDeclare MODIF_ATTR in one
   * EquipementDeclare. Check that the list contains all of the EquipementDeclare with AUCUNE except the modified that
   * should be MODIF_ATTR. Check that the PFI respective EC has typeModif AUCNE.
   *
   */
  @Test
  public void testComparePFI_EquipementDeclare_ModifAttr_001() throws RavelException
  {
    int nEquipementDeclare = 1000;

    Commande commande = buildCommande();
    PFI source = buildPFIWithEquipementDeclare(nEquipementDeclare); //PFI with List of EquipementDeclare
    PFI target = buildPFIWithEquipementDeclare(nEquipementDeclare);
    //all elements of each list are different because buildPA use random to generate field values.

    EquipementDeclare targetEquipementDeclare = getCommercialObjectByID(target.getEquipementDeclare(), "equip5"); //$NON-NLS-1$
    targetEquipementDeclare.setStatut(Statut.RESILIE);

    PFIComparator pficomp = new PFIComparator(commande, LocalDateTime.now());
    pficomp.getPFIComparatorUtils().setAddUnchangedObjects(true);
    pficomp.getPFIComparatorUtils().setPaTypeList(Arrays.asList("LIGNE_FIXE,VOIP,FAX,COMPTE_ACCES,TV".split(","))); //$NON-NLS-1$ //$NON-NLS-2$
    pficomp.compare(source, target);
    Assert.assertEquals(nEquipementDeclare, target.getEquipementDeclare().size());
    Assert.assertEquals(nEquipementDeclare, source.getEquipementDeclare().size());
    Assert.assertEquals(Statut.RESILIE, getCommercialObjectByID(source.getEquipementDeclare(), "equip5").getStatut());
    Assert.assertEquals(0, pficomp._result.getMcList().size()); //is not creation/suppression
    Assert.assertEquals(nEquipementDeclare + 1, pficomp._result.getEcList().size());
    //check EC element of PFI
    Assert.assertEquals(TypeModificationEnum.AUCUNE.name(), getElementComparaisonPFI(pficomp._result.getEcList(), source.getClientOperateur(), source.getNoCompte()).getTypeOperation());

    for (int n = 1; n < (nEquipementDeclare + 1); n++)
    {
      Assert.assertEquals(TypeModificationEnum.MODIF_ATTR.name(), getElementComparaisonEq(pficomp._result.getEcList(), source.getClientOperateur(), source.getNoCompte(), "equip" + n).getTypeOperation());

    }
  }

  /**
   * Test to compare 2 PFI objects with Changes in LienEquipementPA List. The target has one LienEquipementPA to create
   * Expected: One modificationCommercial object in the list. The source should have a new LienEquipementPA with id
   * eq2pa2
   */

  @Test
  public void testComparePFI_LienEquipementPA_Create() throws RavelException
  {
    Commande commande = buildCommande();
    PFI pfiSource = buildPFI();
    PFI pfiTarget = buildPFI();

    LienEquipementPA lienEqpPASource1 = buildLienEquipementPA();
    lienEqpPASource1.setNoEquipement("eq1");
    lienEqpPASource1.setIdFonctionnelPa("pa1");

    LienEquipementPA lienEqpPASource2 = buildLienEquipementPA();
    lienEqpPASource2.setNoEquipement("eq2");
    lienEqpPASource2.setIdFonctionnelPa("pa2");

    List<LienEquipementPA> sList = pfiSource.getLienEquipementPA();
    sList.add(lienEqpPASource1);
    pfiSource.setLienEquipementPA(sList);

    List<LienEquipementPA> tList = pfiTarget.getLienEquipementPA();
    tList.add(lienEqpPASource1);
    tList.add(lienEqpPASource2);
    pfiTarget.setLienEquipementPA(tList);

    PFIComparator pficomp = new PFIComparator(commande, LocalDateTime.now());
    pficomp.getPFIComparatorUtils().setAddUnchangedObjects(true);
    pficomp.getPFIComparatorUtils().setPaTypeList(Arrays.asList("LIGNE_FIXE,VOIP,FAX,COMPTE_ACCES,TV".split(","))); //$NON-NLS-1$ //$NON-NLS-2$
    pficomp.compare(pfiSource, pfiTarget);

    Assert.assertEquals(2, pfiSource.getLienEquipementPA().size());
    String lienEqpPASource1Id = lienEqpPASource1.getNoEquipement() + lienEqpPASource1.getIdFonctionnelPa();
    String lienEqpPASource2Id = lienEqpPASource2.getNoEquipement() + lienEqpPASource2.getIdFonctionnelPa();
    Assert.assertNotNull(getCommercialObjectByID(pfiSource.getLienEquipementPA(), lienEqpPASource2Id));
    //check list EC
    Assert.assertEquals(3, pficomp._result.getEcList().size());
    Assert.assertEquals("CREATION", getElementComparaisonEqPA(pficomp._result.getEcList(), "BSS_ENT", "pfi1", lienEqpPASource2.getNoEquipement(), lienEqpPASource2.getIdFonctionnelPa()).getTypeOperation());
    Assert.assertEquals("AUCUNE", getElementComparaisonEqPA(pficomp._result.getEcList(), "BSS_ENT", "pfi1", lienEqpPASource1.getNoEquipement(), lienEqpPASource1.getIdFonctionnelPa()).getTypeOperation());
    Assert.assertEquals("AUCUNE", getElementComparaisonPFI(pficomp._result.getEcList(), pfiSource.getClientOperateur(), pfiSource.getNoCompte()).getTypeOperation());

    //check list MC
    Assert.assertEquals(1, pficomp._result.getMcList().size());
    Assert.assertEquals("LIEN_EQT_PA", pficomp._result.getMcList().get(0).getTypeObjetCommercial());
    Assert.assertEquals("eq2", pficomp._result.getMcList().get(0).getNoEquipement());
    Assert.assertEquals("pa2", pficomp._result.getMcList().get(0).getIdentifiantFonctionnelPA());
  }

  /**
   * Test to compare 2 PFI objects with Changes in LienEquipementPA List. The source has 2 LienEquipementPA to delete.
   * Expected: 2 ModifcationCommercial in the list of ModificationCommercial.
   */
  @Test
  public void testComparePFI_LienEquipementPA_Delete() throws RavelException
  {
    Commande commande = buildCommande();
    LienEquipementPA equip1 = buildLienEquipementPA();
    equip1.setNoEquipement("equip1"); //$NON-NLS-1$
    equip1.setIdFonctionnelPa("pa1"); //$NON-NLS-1$

    LienEquipementPA equip2 = buildLienEquipementPA();
    equip2.setNoEquipement("equip2"); //$NON-NLS-1$
    equip2.setIdFonctionnelPa("pa2"); //$NON-NLS-1$

    LienEquipementPA equip3 = buildLienEquipementPA();
    equip3.setNoEquipement("equip3"); //$NON-NLS-1$
    equip3.setIdFonctionnelPa("pa3"); //$NON-NLS-1$

    PFI source = buildPFI();
    List<LienEquipementPA> equipList = source.getLienEquipementPA();
    equipList.add(equip1);
    equipList.add(equip2);
    equipList.add(equip3);
    source.setLienEquipementPA(equipList);

    PFI target = buildPFI();
    List<LienEquipementPA> paTargetL = target.getLienEquipementPA();
    paTargetL.add(equip1);
    target.setLienEquipementPA(paTargetL);

    PFIComparator pficomp = new PFIComparator(commande, LocalDateTime.now());
    pficomp.getPFIComparatorUtils().setAddUnchangedObjects(true);
    pficomp.getPFIComparatorUtils().setPaTypeList(Arrays.asList("LIGNE_FIXE,VOIP,FAX,COMPTE_ACCES,TV".split(","))); //$NON-NLS-1$ //$NON-NLS-2$
    pficomp.compare(source, target);

    Assert.assertEquals(TypeModificationEnum.SUPPRESSION.name(), getElementComparaisonEqPA(pficomp._result.getEcList(), "BSS_ENT", "pfi1", "equip2", "pa2").getTypeOperation()); //$NON-NLS-1$//$NON-NLS-2$
    Assert.assertEquals(TypeModificationEnum.SUPPRESSION.name(), getElementComparaisonEqPA(pficomp._result.getEcList(), "BSS_ENT", "pfi1", "equip3", "pa3").getTypeOperation()); //$NON-NLS-1$ //$NON-NLS-2$
    Assert.assertEquals(Statut.ACTIF, getCommercialObjectByID(source.getLienEquipementPA(), "equip1" + "pa1").getStatut()); //$NON-NLS-1$ //$NON-NLS-2$
    Assert.assertEquals(Statut.RESILIE, getCommercialObjectByID(source.getLienEquipementPA(), "equip2" + "pa2").getStatut()); //$NON-NLS-1$ //$NON-NLS-2$
    Assert.assertEquals(Statut.RESILIE, getCommercialObjectByID(source.getLienEquipementPA(), "equip3" + "pa3").getStatut()); //$NON-NLS-1$//$NON-NLS-2$
    Assert.assertEquals(2, pficomp._result.getMcList().size()); //is not creation/suppression

  }

  /**
   * Compare 2 PFI with list of many LienEquipementPA objects. Change of type LienEquipementPA MODIF_ATTR in one
   * LienEquipementPA. Check that the list contains all of the LienEquipementPA with AUCUNE except the modified that
   * should be MODIF_ATTR. Check that the PFI respective EC has typeModif AUCNE.
   *
   */
  @Test
  public void testComparePFI_LienEquipementPA_ModifAttr_001() throws RavelException
  {
    int nLienEquipementPA = 6;

    Commande commande = buildCommande();
    PFI source = buildPFIWithLienEquipementPA(nLienEquipementPA); //PFI with List of LienEquipementPA
    PFI target = buildPFIWithLienEquipementPA(nLienEquipementPA);
    //all elements of each list are different because buildLienEquipementPA use random to generate field values.

    for (int n = 1; n < (nLienEquipementPA + 1); n++)
    {
      LienEquipementPA targetEquipemenPA = getCommercialObjectByID(target.getLienEquipementPA(), "equip" + n + "pa" + n); //$NON-NLS-1$
      targetEquipemenPA.setStatut(Statut.RESILIE);
    }

    PFIComparator pficomp = new PFIComparator(commande, LocalDateTime.now());
    pficomp.getPFIComparatorUtils().setAddUnchangedObjects(true);
    pficomp.getPFIComparatorUtils().setPaTypeList(Arrays.asList("LIGNE_FIXE,VOIP,FAX,COMPTE_ACCES,TV".split(","))); //$NON-NLS-1$ //$NON-NLS-2$
    pficomp.compare(source, target);
    Assert.assertEquals(nLienEquipementPA, target.getLienEquipementPA().size());
    Assert.assertEquals(nLienEquipementPA, source.getLienEquipementPA().size());
    Assert.assertEquals(Statut.RESILIE, getCommercialObjectByID(source.getLienEquipementPA(), "equip5pa5").getStatut());
    Assert.assertEquals(0, pficomp._result.getMcList().size()); //is not creation/suppression
    Assert.assertEquals(nLienEquipementPA + 1, pficomp._result.getEcList().size());
    //check EC element of PFI
    Assert.assertEquals(TypeModificationEnum.AUCUNE.name(), getElementComparaisonPFI(pficomp._result.getEcList(), source.getClientOperateur(), source.getNoCompte()).getTypeOperation());

    for (int n = 1; n < (nLienEquipementPA + 1); n++)
    {
      Assert.assertEquals(TypeModificationEnum.MODIF_ATTR.name(), getElementComparaisonEqPA(pficomp._result.getEcList(), "BSS_ENT", "pfi1", "equip" + n, "pa" + n).getTypeOperation());

    }
  }

  @Test
  public void testComparePFI_LienSAPA_Create() throws RavelException
  {
    Commande commande = buildCommande();
    PFI pfiSource = buildPFI();
    PFI pfiTarget = buildPFI();

    LienSAPA lienSAPASource1 = buildLienSAPA();
    lienSAPASource1.setNoServiceAccessible("sa1");
    lienSAPASource1.setIdentifiantFonctionnelPA("pa1");

    LienSAPA lienSAPASource2 = buildLienSAPA();
    lienSAPASource2.setNoServiceAccessible("sa2");
    lienSAPASource2.setIdentifiantFonctionnelPA("pa2");

    List<LienSAPA> sList = pfiSource.getLienSAPA();
    sList.add(lienSAPASource1);
    pfiSource.setLienSAPA(sList);

    List<LienSAPA> tList = pfiTarget.getLienSAPA();
    tList.add(lienSAPASource1);
    tList.add(lienSAPASource2);
    pfiTarget.setLienSAPA(tList);

    PFIComparator pficomp = new PFIComparator(commande, LocalDateTime.now());
    pficomp.getPFIComparatorUtils().setAddUnchangedObjects(true);
    pficomp.getPFIComparatorUtils().setPaTypeList(Arrays.asList("LIGNE_FIXE,VOIP,FAX,COMPTE_ACCES,TV".split(","))); //$NON-NLS-1$ //$NON-NLS-2$
    pficomp.getPFIComparatorUtils().addPaAndType("pa1", "TV");
    pficomp.getPFIComparatorUtils().addPaAndType("pa2", "TV");
    pficomp.compare(pfiSource, pfiTarget);

    Assert.assertEquals(2, pfiSource.getLienSAPA().size());
    String lienSAPASource1Id = lienSAPASource1.getNoServiceAccessible() + lienSAPASource1.getIdentifiantFonctionnelPA();
    String lienSAPASource2Id = lienSAPASource2.getNoServiceAccessible() + lienSAPASource2.getIdentifiantFonctionnelPA();
    Assert.assertNotNull(getCommercialObjectByID(pfiSource.getLienSAPA(), lienSAPASource2Id));
    //check list EC
    Assert.assertEquals(3, pficomp._result.getEcList().size());
    Assert.assertEquals("CREATION", getElementComparaisonSAPA(pficomp._result.getEcList(), "BSS_ENT", "pfi1", lienSAPASource2.getNoServiceAccessible(), lienSAPASource2.getIdentifiantFonctionnelPA()).getTypeOperation());
    Assert.assertEquals("AUCUNE", getElementComparaisonSAPA(pficomp._result.getEcList(), "BSS_ENT", "pfi1", lienSAPASource1.getNoServiceAccessible(), lienSAPASource1.getIdentifiantFonctionnelPA()).getTypeOperation());
    Assert.assertEquals("AUCUNE", getElementComparaisonPFI(pficomp._result.getEcList(), pfiSource.getClientOperateur(), pfiSource.getNoCompte()).getTypeOperation());

    //check list MC
    Assert.assertEquals(1, pficomp._result.getMcList().size());
    Assert.assertEquals("LIEN_SA_PA", pficomp._result.getMcList().get(0).getTypeObjetCommercial());
    Assert.assertEquals("sa2", pficomp._result.getMcList().get(0).getNoServiceAccessible());
    Assert.assertEquals("pa2", pficomp._result.getMcList().get(0).getIdentifiantFonctionnelPA());
  }

  /**
   * Test to compare 2 PFI objects with Changes in LienSAPA List. The source has 2 LienSAPA to delete. Expected: 2
   * ModifcationCommercial in the list of ModificationCommercial.
   */
  @Test
  public void testComparePFI_LienSAPA_Delete() throws RavelException
  {
    Commande commande = buildCommande();
    LienSAPA sapa1 = buildLienSAPA();
    sapa1.setNoServiceAccessible("sa1"); //$NON-NLS-1$
    sapa1.setIdentifiantFonctionnelPA("pa1"); //$NON-NLS-1$

    LienSAPA sapa2 = buildLienSAPA();
    sapa2.setNoServiceAccessible("sa2"); //$NON-NLS-1$
    sapa2.setIdentifiantFonctionnelPA("pa2"); //$NON-NLS-1$

    LienSAPA equip3 = buildLienSAPA();
    equip3.setNoServiceAccessible("sa3"); //$NON-NLS-1$
    equip3.setIdentifiantFonctionnelPA("pa3"); //$NON-NLS-1$

    PFI source = buildPFI();
    List<LienSAPA> sapaList = source.getLienSAPA();
    sapaList.add(sapa1);
    sapaList.add(sapa2);
    sapaList.add(equip3);
    source.setLienSAPA(sapaList);

    PFI target = buildPFI();
    List<LienSAPA> paTargetL = target.getLienSAPA();
    paTargetL.add(sapa1);
    target.setLienSAPA(paTargetL);

    PFIComparator pficomp = new PFIComparator(commande, LocalDateTime.now());
    pficomp.getPFIComparatorUtils().setAddUnchangedObjects(true);
    pficomp.getPFIComparatorUtils().setPaTypeList(Arrays.asList("LIGNE_FIXE,VOIP,FAX,COMPTE_ACCES,TV".split(","))); //$NON-NLS-1$ //$NON-NLS-2$
    pficomp.getPFIComparatorUtils().addPaAndType("pa1", "TV");
    pficomp.getPFIComparatorUtils().addPaAndType("pa2", "TV");
    pficomp.getPFIComparatorUtils().addPaAndType("pa3", "TV");
    pficomp.compare(source, target);

    Assert.assertEquals(TypeModificationEnum.SUPPRESSION.name(), getElementComparaisonSAPA(pficomp._result.getEcList(), "BSS_ENT", "pfi1", "sa2", "pa2").getTypeOperation()); //$NON-NLS-1$//$NON-NLS-2$
    Assert.assertEquals(TypeModificationEnum.SUPPRESSION.name(), getElementComparaisonSAPA(pficomp._result.getEcList(), "BSS_ENT", "pfi1", "sa3", "pa3").getTypeOperation()); //$NON-NLS-1$ //$NON-NLS-2$
    Assert.assertEquals(Statut.ACTIF, getCommercialObjectByID(source.getLienSAPA(), "sa1" + "pa1").getStatut()); //$NON-NLS-1$ //$NON-NLS-2$
    Assert.assertEquals(Statut.RESILIE, getCommercialObjectByID(source.getLienSAPA(), "sa2" + "pa2").getStatut()); //$NON-NLS-1$ //$NON-NLS-2$
    Assert.assertEquals(Statut.RESILIE, getCommercialObjectByID(source.getLienSAPA(), "sa3" + "pa3").getStatut()); //$NON-NLS-1$//$NON-NLS-2$
    Assert.assertEquals(2, pficomp._result.getMcList().size()); //is not creation/suppression

  }

  /**
   * Compare 2 PFI with list of many LienSAPA objects. Change of type LienSAPA MODIF_ATTR in one LienSAPA. Check that
   * the list contains all of the LienSAPA with AUCUNE except the modified that should be MODIF_ATTR. Check that the PFI
   * respective EC has typeModif AUCNE.
   *
   */
  @Test
  public void testComparePFI_LienSAPA_ModifAttr_001() throws RavelException
  {
    int nLienSAPA = 6;

    Commande commande = buildCommande();
    PFI source = buildPFIWithLienSAPA(nLienSAPA); //PFI with List of LienSAPA
    PFI target = buildPFIWithLienSAPA(nLienSAPA);
    //all elements of each list are different because buildSAPA use random to generate field values.

    Map<String, String> mapIdPAType = new HashMap<>();
    for (int n = 1; n < (nLienSAPA + 1); n++)
    {
      LienSAPA targetSAPA = getCommercialObjectByID(target.getLienSAPA(), "sa" + n + "pa" + n); //$NON-NLS-1$
      targetSAPA.setStatut(Statut.RESILIE);
      mapIdPAType.put("pa" + n, "TV");
    }

    PFIComparator pficomp = new PFIComparator(commande, LocalDateTime.now());
    pficomp.getPFIComparatorUtils().setAddUnchangedObjects(true);
    pficomp.getPFIComparatorUtils().setPaTypeList(Arrays.asList("LIGNE_FIXE,VOIP,FAX,COMPTE_ACCES,TV".split(","))); //$NON-NLS-1$ //$NON-NLS-2$
    pficomp.getPFIComparatorUtils().setPaIdAndType(mapIdPAType);
    pficomp.compare(source, target);
    Assert.assertEquals(nLienSAPA, target.getLienSAPA().size());
    Assert.assertEquals(nLienSAPA, source.getLienSAPA().size());
    Assert.assertEquals(Statut.RESILIE, getCommercialObjectByID(source.getLienSAPA(), "sa5pa5").getStatut());
    Assert.assertEquals(0, pficomp._result.getMcList().size()); //is not creation/suppression
    Assert.assertEquals(nLienSAPA + 1, pficomp._result.getEcList().size());
    //check EC element of PFI
    Assert.assertEquals(TypeModificationEnum.AUCUNE.name(), getElementComparaisonPFI(pficomp._result.getEcList(), source.getClientOperateur(), source.getNoCompte()).getTypeOperation());

    for (int n = 1; n < (nLienSAPA + 1); n++)
    {
      Assert.assertEquals(TypeModificationEnum.MODIF_ATTR.name(), getElementComparaisonSAPA(pficomp._result.getEcList(), "BSS_ENT", "pfi1", "sa" + n, "pa" + n).getTypeOperation());

    }
  }

  /**
   * Test to compare 2 PFI objects with modification in the target PFI Statut to RESILIE Expected: The source should be
   * also RESILIE
   */
  @Test
  public void testComparePFI_Modif_Statut() throws RavelException
  {
    Commande commande = buildCommande();
    PFI source = buildPFI();
    PFI target = buildPFI();

    target.setStatut(Statut.RESILIE);
    PFIComparator pficomp = new PFIComparator(commande, LocalDateTime.now());
    pficomp.compare(source, target);
    Assert.assertEquals(1, pficomp._result.getEcList().size());
    Assert.assertEquals("MODIF_ATTR", getElementComparaisonPFI(pficomp._result.getEcList(), "BSS_ENT", "pfi1").getTypeOperation());
    Assert.assertEquals("statut", getElementComparaisonPFI(pficomp._result.getEcList(), "BSS_ENT", "pfi1").getListeAttributModifie().get(0).getNomAttribut());
    Assert.assertEquals("RESILIE", getElementComparaisonPFI(pficomp._result.getEcList(), "BSS_ENT", "pfi1").getListeAttributModifie().get(0).getNouvelleValeur());
    Assert.assertEquals(Statut.RESILIE, source.getStatut());
    Assert.assertEquals(1, pficomp._result.getMcList().size()); //is not creation/suppression
  }

  /**
   * Test to compare 2 PFI objects with modification in target PFI Titulaire Expected: The PFI source should have the
   * target PFI titulaire
   */
  @Test
  public void testComparePFI_Modif_Titulaire_01() throws RavelException
  {
    Commande commande = buildCommande();
    PFI source = buildPFI();
    source.setTitulaire(buildTitulaire());
    PFI target = buildPFI();
    Titulaire newTitulaire = new Titulaire(TypeTitulaire.INDIVIDU, "new_noPersonne", null, null);
    newTitulaire.setEntreprise(new Entreprise("new_noSiren", "new_raisonSociale"));
    newTitulaire.setIndividu(new Individu("Mme", "nom", "prenom"));
    target.setTitulaire(newTitulaire);

    PFIComparator pfiComparator = new PFIComparator(commande, LocalDateTime.now());
    pfiComparator.compare(source, target);

    Assert.assertEquals(target.getTitulaire(), pfiComparator.getPFIResult().getTitulaire());
    Assert.assertEquals(source.getClientOperateur(), pfiComparator.getPFIResult().getClientOperateur());
    Assert.assertEquals(source.getNoCompte(), pfiComparator.getPFIResult().getNoCompte());
    Assert.assertEquals(source.getLigneMarche(), pfiComparator.getPFIResult().getLigneMarche());
    Assert.assertEquals(source.getDatePhoto(), pfiComparator.getPFIResult().getDatePhoto());
    Assert.assertEquals(source.getSa(), pfiComparator.getPFIResult().getSa());
    Assert.assertEquals(source.getPa(), pfiComparator.getPFIResult().getPa());
    Assert.assertEquals(source.getLienSAPA(), pfiComparator.getPFIResult().getLienSAPA());
    Assert.assertEquals(source.getEquipementDeclare(), pfiComparator.getPFIResult().getEquipementDeclare());
    Assert.assertEquals(source.getLienEquipementPA(), pfiComparator.getPFIResult().getLienEquipementPA());
    Assert.assertEquals(source.getDateCreation(), pfiComparator.getPFIResult().getDateCreation());
    Assert.assertEquals(source.getDateModification(), pfiComparator.getPFIResult().getDateModification());

    Assert.assertEquals(1, pfiComparator._result.getMcList().size()); //is not creation/suppression
  }

  /**
   * Test to compare 2 PFI objects with modification in target PFI Titulaire from a Commande with NatureCommande
   * MODIFICATION<br>
   *
   * <b>Inputs:</b> Commande with NatureCommande = MODIFICATION / All attributes are changed, except Titulaire (= null)
   * <br>
   * <b>Expected:</b> Modification done with a copy of the delta between PFI source and target <br>
   */
  @Test
  public void testComparePFI_Modif_Titulaire_02() throws RavelException
  {
    Commande commande = buildCommande();
    commande.setNatureCommande(NatureCommande.MODIFICATION_PFI.name());
    PFI source = buildPFI();
    Titulaire titulaireExpected = source.getTitulaire();

    PFI target = buildPFI();
    target.setClientOperateur("clientOperateur");
    target.setNoCompte("noCompte");
    target.setStatut(Statut.RESILIE);
    target.setLigneMarche("new_ligneMarche");
    target.setDatePhoto(LocalDateTime.now());
    target.setTitulaire(null);

    PFIComparator pfiComparator = new PFIComparator(commande, LocalDateTime.now());
    pfiComparator.compare(source, target);

    Assert.assertEquals(target.getClientOperateur(), pfiComparator.getPFIResult().getClientOperateur());
    Assert.assertEquals(target.getNoCompte(), pfiComparator.getPFIResult().getNoCompte());
    Assert.assertEquals(target.getLigneMarche(), pfiComparator.getPFIResult().getLigneMarche());
    Assert.assertEquals(target.getDatePhoto(), pfiComparator.getPFIResult().getDatePhoto());
    Assert.assertEquals(titulaireExpected, pfiComparator.getPFIResult().getTitulaire());

    Assert.assertEquals(1, pfiComparator._result.getMcList().size()); //is not creation/suppression

    Assert.assertEquals(3, pfiComparator.getECList().get(0).getListeAttributModifie().size());

  }

  /**
   * Test to compare 2 PFI objects with modification in target PFI Titulaire from a Commande with NatureCommande
   * MODIFICATION<br>
   *
   * <b>Inputs:</b> Commande with NatureCommande = MODIFICATION / Only Titulaire is changed (all the other attributes
   * are null). Entreprise and Individu from Titulaire source are null <br>
   * <b>Expected:</b> Modification done with a copy of the delta between PFI source and target <br>
   */
  @Test
  public void testComparePFI_Modif_Titulaire_03() throws RavelException
  {
    Commande commande = buildCommande();
    commande.setNatureCommande(NatureCommande.MODIFICATION_PFI.name());
    PFI source = buildPFI();
    source.getTitulaire().setIndividu(null);
    source.getTitulaire().setEntreprise(null);

    PFI target = new PFI();
    target.setTitulaire(buildTitulaire());
    target.getTitulaire().setNoPersonne("new_noPersonne");
    target.getTitulaire().setNoTel("new_noTel");
    target.getTitulaire().setEmail("new_email");

    PFIComparator pfiComparator = new PFIComparator(commande, LocalDateTime.now());
    pfiComparator.compare(source, target);

    //Check Titulaire
    Assert.assertEquals(target.getTitulaire().getEmail(), pfiComparator.getPFIResult().getTitulaire().getEmail());
    Assert.assertEquals(target.getTitulaire().getNoPersonne(), pfiComparator.getPFIResult().getTitulaire().getNoPersonne());
    Assert.assertEquals(target.getTitulaire().getNoTel(), pfiComparator.getPFIResult().getTitulaire().getNoTel());
    Assert.assertEquals(target.getTitulaire().getEntreprise(), pfiComparator.getPFIResult().getTitulaire().getEntreprise());
    Assert.assertEquals(target.getTitulaire().getIndividu(), pfiComparator.getPFIResult().getTitulaire().getIndividu());

    //Check rest of PFI
    Assert.assertEquals("BSS_ENT", pfiComparator.getPFIResult().getClientOperateur());
    Assert.assertEquals("pfi1", pfiComparator.getPFIResult().getNoCompte());
    Assert.assertEquals(IModificationValue_Test.LIGNE_MARCHE, pfiComparator.getPFIResult().getLigneMarche());

    Assert.assertEquals(1, pfiComparator._result.getMcList().size()); //is not creation/suppression

    Assert.assertEquals(8, pfiComparator.getECList().get(0).getListeAttributModifie().size());
  }

  /**
   * Test to compare 2 PFI objects with modification in target PFI Titulaire from a Commande with NatureCommande
   * MODIFICATION<br>
   *
   * <b>Inputs:</b> Commande with NatureCommande = MODIFICATION / Only Titulaire is changed (all the other attributes
   * are null). Only the civilite is changed for Individu and only noSiren is changed for Entreprise <br>
   * <b>Expected:</b> Modification done with a copy of the delta between PFI source and target <br>
   */
  @Test
  public void testComparePFI_Modif_Titulaire_04() throws RavelException
  {
    Commande commande = buildCommande();
    commande.setNatureCommande(NatureCommande.MODIFICATION_PFI.name());
    PFI source = buildPFI();

    PFI target = new PFI();
    Titulaire titulaire = new Titulaire(TypeTitulaire.INDIVIDU, null, null, null);
    Individu individu = new Individu("civilite", null, null);
    titulaire.setIndividu(individu);
    Entreprise entreprise = new Entreprise("noSiren2", null);
    titulaire.setEntreprise(entreprise);
    target.setTitulaire(titulaire);

    PFIComparator pfiComparator = new PFIComparator(commande, LocalDateTime.now());
    pfiComparator.compare(source, target);

    //Check Titulaire
    Assert.assertEquals(IModificationValue_Test.EMAIL_LOGIN, pfiComparator.getPFIResult().getTitulaire().getEmail());
    Assert.assertEquals(IModificationValue_Test.NO_PERSONNE, pfiComparator.getPFIResult().getTitulaire().getNoPersonne());
    Assert.assertEquals(IModificationValue_Test.NUMERO_TELEPHONE, pfiComparator.getPFIResult().getTitulaire().getNoTel());
    Assert.assertEquals(target.getTitulaire().getIndividu().getCivilite(), pfiComparator.getPFIResult().getTitulaire().getIndividu().getCivilite());
    Assert.assertEquals("Santos", pfiComparator.getPFIResult().getTitulaire().getIndividu().getNom());
    Assert.assertEquals("John", pfiComparator.getPFIResult().getTitulaire().getIndividu().getPrenom());
    Assert.assertEquals(target.getTitulaire().getEntreprise().getNoSiren(), pfiComparator.getPFIResult().getTitulaire().getEntreprise().getNoSiren());
    Assert.assertEquals(IModificationValue_Test.RAISON_SOCIALE, pfiComparator.getPFIResult().getTitulaire().getEntreprise().getRaisonSociale());

    Assert.assertEquals(Statut.ACTIF, pfiComparator.getPFIResult().getStatut());
    Assert.assertEquals("BSS_ENT", pfiComparator.getPFIResult().getClientOperateur());
    Assert.assertEquals("pfi1", pfiComparator.getPFIResult().getNoCompte());
    Assert.assertEquals(IModificationValue_Test.LIGNE_MARCHE, pfiComparator.getPFIResult().getLigneMarche());

    Assert.assertEquals(1, pfiComparator._result.getMcList().size()); //is not creation/suppression

    Assert.assertEquals(2, pfiComparator.getECList().get(0).getListeAttributModifie().size());
  }

  /**
   * Test to compare 2 PFI objects with modification in target PFI Titulaire from a Commande with NatureCommande
   * MODIFICATION<br>
   *
   * <b>Inputs:</b> Commande with NatureCommande = MODIFICATION / Only Titulaire is changed (all the other attributes
   * are null). Only the nom and prenom are changed for Individu and only the raisonSociale is changed for Entreprise
   * <br>
   * <b>Expected:</b> Modification done with a copy of the delta between PFI source and target <br>
   */
  @Test
  public void testComparePFI_Modif_Titulaire_05() throws RavelException
  {
    Commande commande = buildCommande();
    commande.setNatureCommande(NatureCommande.MODIFICATION_PFI.name());
    PFI source = buildPFI();
    source.getTitulaire().setEntreprise(new Entreprise("noSiren", "raisonSociale"));

    PFI target = new PFI();
    target.setClientOperateur(null);
    target.setNoCompte(null);
    target.setStatut(null);
    target.setLigneMarche(null);
    target.setDatePhoto(null);
    Titulaire titulaire = new Titulaire(TypeTitulaire.INDIVIDU, null, null, null);
    Individu individu = new Individu(null, "nom", "prenom");
    titulaire.setIndividu(individu);
    Entreprise entreprise = new Entreprise(null, "raisonSociale2");
    titulaire.setEntreprise(entreprise);
    target.setTitulaire(titulaire);

    PFIComparator pfiComparator = new PFIComparator(commande, LocalDateTime.now());
    pfiComparator.compare(source, target);

    //Check Titulaire
    Assert.assertEquals(IModificationValue_Test.EMAIL_LOGIN, pfiComparator.getPFIResult().getTitulaire().getEmail());
    Assert.assertEquals(IModificationValue_Test.NO_PERSONNE, pfiComparator.getPFIResult().getTitulaire().getNoPersonne());
    Assert.assertEquals(IModificationValue_Test.NUMERO_TELEPHONE, pfiComparator.getPFIResult().getTitulaire().getNoTel());
    Assert.assertEquals("M", pfiComparator.getPFIResult().getTitulaire().getIndividu().getCivilite());
    Assert.assertEquals(target.getTitulaire().getIndividu().getNom(), pfiComparator.getPFIResult().getTitulaire().getIndividu().getNom());
    Assert.assertEquals(target.getTitulaire().getIndividu().getPrenom(), pfiComparator.getPFIResult().getTitulaire().getIndividu().getPrenom());
    Assert.assertEquals(IModificationValue_Test.NO_SIREN, pfiComparator.getPFIResult().getTitulaire().getEntreprise().getNoSiren());
    Assert.assertEquals(target.getTitulaire().getEntreprise().getRaisonSociale(), pfiComparator.getPFIResult().getTitulaire().getEntreprise().getRaisonSociale());

    Assert.assertEquals(Statut.ACTIF, pfiComparator.getPFIResult().getStatut());
    Assert.assertEquals("BSS_ENT", pfiComparator.getPFIResult().getClientOperateur());
    Assert.assertEquals("pfi1", pfiComparator.getPFIResult().getNoCompte());
    Assert.assertEquals(IModificationValue_Test.LIGNE_MARCHE, pfiComparator.getPFIResult().getLigneMarche());

    Assert.assertEquals(1, pfiComparator._result.getMcList().size()); //is not creation/suppression

    Assert.assertEquals(3, pfiComparator.getECList().get(0).getListeAttributModifie().size());
  }

  /**
   * Test to compare 2 PFI objects with modification in target PFI Titulaire from a Commande with NatureCommande
   * SUPPRESSION<br>
   *
   * <b>Inputs:</b> Commande with NatureCommande = SUPPRESSION / Only the status is changed (all the other attributes
   * are null).<br>
   * <b>Expected:</b> Modification done with a copy of the delta between PFI source and target <br>
   */
  @Test
  public void testComparePFI_Modif_Titulaire_06() throws RavelException
  {
    Commande commande = buildCommande();
    commande.setNatureCommande(NatureCommande.SUPPRESSION_PFI.name());
    PFI source = buildPFI();

    PFI target = new PFI();
    target.setStatut(Statut.RESILIE);

    PFIComparator pfiComparator = new PFIComparator(commande, LocalDateTime.now());
    pfiComparator.compare(source, target);

    Assert.assertEquals(target.getStatut(), pfiComparator.getPFIResult().getStatut());
    Assert.assertEquals(buildTitulaire(), pfiComparator.getPFIResult().getTitulaire());
    Assert.assertEquals("BSS_ENT", pfiComparator.getPFIResult().getClientOperateur());
    Assert.assertEquals("pfi1", pfiComparator.getPFIResult().getNoCompte());
    Assert.assertEquals(IModificationValue_Test.LIGNE_MARCHE, pfiComparator.getPFIResult().getLigneMarche());

    assertEquals(1, pfiComparator._result.getEcList().get(0).getListeAttributModifie().size());
  }

  /**
   * Test to compare 2 PFI objects with Changes in SA List. The target has one SA to create Expected: One
   * modificationCommercial object in the list. The source should have a new SA with id sa2
   */

  @Test
  public void testComparePFI_PA_Create() throws RavelException
  {
    Commande commande = buildCommande();
    PA pa1 = buildPA("pa1", PointAccesLigneFixe.TYPE); //$NON-NLS-1$
    PA pa2 = buildPA("pa2", PointAccesLigneFixe.TYPE); //$NON-NLS-1$
    PFI source = buildPFI();
    List<PA> pal = source.getPa();
    pal.add(pa1);
    source.setPa(pal);

    PFI target = buildPFI();//pa1 pa2
    List<PA> paTargetL = target.getPa();
    paTargetL.add(pa1);
    paTargetL.add(pa2);
    target.setPa(paTargetL);

    PFIComparator pficomp = new PFIComparator(commande, LocalDateTime.now());
    pficomp.getPFIComparatorUtils().setAddUnchangedObjects(true);
    pficomp.getPFIComparatorUtils().setPaTypeList(Arrays.asList("LIGNE_FIXE,VOIP,FAX,COMPTE_ACCES,TV".split(","))); //$NON-NLS-1$ //$NON-NLS-2$
    pficomp.compare(source, target);
    Assert.assertEquals("AUCUNE", getElementComparaisonPFI(pficomp._result.getEcList(), "BSS_ENT", "pfi1").getTypeOperation()); //$NON-NLS-1$//$NON-NLS-2$
    Assert.assertEquals("AUCUNE", getElementComparaisonPA(pficomp._result.getEcList(), "BSS_ENT", "pfi1", "pa1").getTypeOperation()); //$NON-NLS-1$ //$NON-NLS-2$
    Assert.assertEquals("CREATION", getElementComparaisonPA(pficomp._result.getEcList(), "BSS_ENT", "pfi1", "pa2").getTypeOperation()); //$NON-NLS-1$ //$NON-NLS-2$
    Assert.assertNotNull(getCommercialObjectByID(source.getPa(), "pa2")); //$NON-NLS-1$
    Assert.assertEquals(2, source.getPa().size());
    Assert.assertEquals(2, target.getPa().size());
    assertModificationCommercial(pficomp._result.getMcList().get(0), source, getCommercialObjectByID(target.getPa(), "pa2")); //$NON-NLS-1$
  }

  /**
   * Test to compare 2 PFI objects with Changes in PA List. The source has 2 PA to delete. Expected: 2
   * ModifcationCommercial in the list of ModificationCommercial.
   */
  @Test
  public void testComparePFI_PA_Delete() throws RavelException
  {
    Commande commande = buildCommande();
    PA pa1 = buildPA("pa1", PointAccesLigneFixe.TYPE);
    PA pa2 = buildPA("pa2", PointAccesLigneFixe.TYPE);
    PA pa3 = buildPA("pa3", PointAccesLigneFixe.TYPE);
    PFI source = buildPFI();
    List<PA> pal = source.getPa();
    pal.add(pa1);
    pal.add(pa2);
    pal.add(pa3);
    source.setPa(pal);

    PFI target = buildPFI();//pa1 pa2
    List<PA> paTargetL = target.getPa();
    paTargetL.add(pa1);
    target.setPa(paTargetL);

    PFIComparator pficomp = new PFIComparator(commande, LocalDateTime.now());
    pficomp.getPFIComparatorUtils().setAddUnchangedObjects(true);
    pficomp.getPFIComparatorUtils().setPaTypeList(Arrays.asList("LIGNE_FIXE,VOIP,FAX,COMPTE_ACCES,TV".split(","))); //$NON-NLS-1$ //$NON-NLS-2$
    pficomp.compare(source, target);

    Assert.assertEquals(TypeModificationEnum.SUPPRESSION.name(), getElementComparaisonPA(pficomp._result.getEcList(), "BSS_ENT", "pfi1", "pa2").getTypeOperation());
    Assert.assertEquals(TypeModificationEnum.SUPPRESSION.name(), getElementComparaisonPA(pficomp._result.getEcList(), "BSS_ENT", "pfi1", "pa3").getTypeOperation());
    Assert.assertEquals(Statut.ACTIF, getCommercialObjectByID(source.getPa(), "pa1").getStatut());
    Assert.assertEquals(Statut.RESILIE, getCommercialObjectByID(source.getPa(), "pa2").getStatut());
    Assert.assertEquals(Statut.RESILIE, getCommercialObjectByID(source.getPa(), "pa3").getStatut());
    Assert.assertEquals(2, pficomp._result.getMcList().size()); //is not creation/suppression

  }

  /**
   * Compare 2 PFI with list of many PA objects. Change of type SA MODIF_ATTR in one SA. Check that the list contains
   * all of the SA with AUCUNE except the modified that should be MODIF_ATTR. Check that the PFI respective EC has
   * typeModif AUCNE.
   *
   */
  @Test
  public void testComparePFI_PA_ModifAttr_001() throws RavelException
  {
    int nPA = 1000;

    Commande commande = buildCommande();
    PFI source = buildPFIWithPA(nPA, PointAccesLigneFixe.TYPE); //PFI with List of 10 SA
    PFI target = buildPFIWithPA(nPA, PointAccesLigneFixe.TYPE);
    //all elements of each list are different because buildPA use random to generate field values.

    PA targetPA = getCommercialObjectByID(target.getPa(), "pa5"); //$NON-NLS-1$
    targetPA.setStatut(Statut.RESILIE);

    PFIComparator pficomp = new PFIComparator(commande, LocalDateTime.now());
    pficomp.getPFIComparatorUtils().setAddUnchangedObjects(true);
    pficomp.getPFIComparatorUtils().setPaTypeList(Arrays.asList("LIGNE_FIXE,VOIP,FAX,COMPTE_ACCES,TV".split(","))); //$NON-NLS-1$ //$NON-NLS-2$
    pficomp.compare(source, target);
    Assert.assertEquals(nPA, target.getPa().size());
    Assert.assertEquals(nPA, source.getPa().size());
    Assert.assertEquals(Statut.RESILIE, getCommercialObjectByID(source.getPa(), "pa5").getStatut());
    Assert.assertEquals(1000, pficomp._result.getMcList().size()); //is not creation/suppression
    Assert.assertEquals(nPA + 1, pficomp._result.getEcList().size());
    //check EC element of PFI
    Assert.assertEquals(TypeModificationEnum.AUCUNE.name(), getElementComparaisonPFI(pficomp._result.getEcList(), source.getClientOperateur(), source.getNoCompte()).getTypeOperation());

    for (int n = 1; n < (nPA + 1); n++)
    {
      Assert.assertEquals(TypeModificationEnum.MODIF_ATTR.name(), getElementComparaisonPA(pficomp._result.getEcList(), source.getClientOperateur(), source.getNoCompte(), "pa" + n).getTypeOperation());

    }
  }

  /**
   * Test to compare 2 PFI objects with Changes in SA List. The target has one SA to create Expected: One
   * modificationCommercial object in the list. The source should have a new SA with id sa2
   */
  @Test
  public void testComparePFI_SA_Create() throws RavelException
  {
    Commande commande = buildCommande();
    PFI source = buildPFIWithSA(1);//id-sa1
    PFI target = buildPFIWithSA(2);//id=sa1, id=sa2

    PFIComparator pficomp = new PFIComparator(commande, LocalDateTime.now());
    pficomp.getPFIComparatorUtils().setAddUnchangedObjects(true);
    pficomp.getPFIComparatorUtils().setPaTypeList(Arrays.asList("LIGNE_FIXE,VOIP,FAX,COMPTE_ACCES,TV".split(","))); //$NON-NLS-1$ //$NON-NLS-2$
    pficomp.compare(source, target);
    Assert.assertEquals("AUCUNE", getElementComparaisonPFI(pficomp._result.getEcList(), "BSS_ENT", "pfi1").getTypeOperation()); //$NON-NLS-1$//$NON-NLS-2$
    Assert.assertEquals("AUCUNE", getElementComparaisonSA(pficomp._result.getEcList(), "BSS_ENT", "pfi1", "sa1").getTypeOperation()); //$NON-NLS-1$ //$NON-NLS-2$
    Assert.assertEquals("AUCUNE", getElementComparaisonSA(pficomp._result.getEcList(), "BSS_ENT", "pfi1", "sa1").getTypeOperation()); //$NON-NLS-1$ //$NON-NLS-2$
    Assert.assertEquals("CREATION", getElementComparaisonSA(pficomp._result.getEcList(), "BSS_ENT", "pfi1", "sa2").getTypeOperation()); //$NON-NLS-1$ //$NON-NLS-2$
    Assert.assertEquals(getCommercialObjectByID(target.getSa(), "sa2"), getCommercialObjectByID(source.getSa(), "sa2")); //$NON-NLS-1$//$NON-NLS-2$
    assertModificationCommercial(pficomp._result.getMcList().get(0), source, getCommercialObjectByID(target.getSa(), "sa2")); //$NON-NLS-1$
  }

  /**
   * Test to compare 2 PFI objects with Changes in SA List. The source has 2 SA to delete. Expected: 2
   * ModifcationCommercial in the list of ModificationCommercial.
   */
  @Test
  public void testComparePFI_SA_Delete() throws RavelException
  {
    Commande commande = buildCommande();
    PFI source = buildPFIWithSA(3);//id-sa1,id=sa2,id=sa3
    PFI target = buildPFIWithSA(1);//id=sa1,

    PFIComparator pficomp = new PFIComparator(commande, LocalDateTime.now());
    pficomp.getPFIComparatorUtils().setAddUnchangedObjects(true);
    pficomp.getPFIComparatorUtils().setPaTypeList(Arrays.asList("LIGNE_FIXE,VOIP,FAX,COMPTE_ACCES,TV".split(","))); //$NON-NLS-1$ //$NON-NLS-2$
    pficomp.compare(source, target);

    Assert.assertEquals(TypeModificationEnum.SUPPRESSION.name(), getElementComparaisonSA(pficomp._result.getEcList(), "BSS_ENT", "pfi1", "sa2").getTypeOperation());
    Assert.assertEquals(TypeModificationEnum.SUPPRESSION.name(), getElementComparaisonSA(pficomp._result.getEcList(), "BSS_ENT", "pfi1", "sa3").getTypeOperation());
    Assert.assertEquals(Statut.ACTIF, getCommercialObjectByID(source.getSa(), "sa1").getStatut());
    Assert.assertEquals(Statut.RESILIE, getCommercialObjectByID(source.getSa(), "sa2").getStatut());
    Assert.assertEquals(Statut.RESILIE, getCommercialObjectByID(source.getSa(), "sa3").getStatut());
    Assert.assertEquals(2, pficomp._result.getMcList().size()); //is not creation/suppression

  }

  /**
   * Compare 2 PFI with list of many SA objects. Change of type SA MODIF_ATTR in one SA. Check that the list contains
   * all of the SA with AUCUNE except the modified that should be MODIF_ATTR. Check that the PFI respective EC has
   * typeModif AUCNE.
   *
   */
  @Test
  public void testComparePFI_SA_ModifAttr_01() throws RavelException
  {
    int nSA = 1000;

    Commande commande = buildCommande();
    PFI source = buildPFIWithSA(nSA); //PFI with List of 10 SA
    PFI target = buildPFIWithSA(nSA);

    SA targetSA = getCommercialObjectByID(target.getSa(), "sa5"); //$NON-NLS-1$
    targetSA.setNomServiceCommercial("sax");

    PFIComparator pficomp = new PFIComparator(commande, LocalDateTime.now());
    pficomp.getPFIComparatorUtils().setAddUnchangedObjects(true);
    pficomp.getPFIComparatorUtils().setPaTypeList(Arrays.asList("LIGNE_FIXE,VOIP,FAX,COMPTE_ACCES,TV".split(","))); //$NON-NLS-1$ //$NON-NLS-2$
    pficomp.compare(source, target);
    Assert.assertEquals(nSA, target.getSa().size());
    Assert.assertEquals(nSA, source.getSa().size());
    Assert.assertEquals("sax", getCommercialObjectByID(source.getSa(), "sa5").getNomServiceCommercial());
    Assert.assertEquals(0, pficomp._result.getMcList().size()); //is not creation/suppression
    Assert.assertEquals(nSA + 1, pficomp._result.getEcList().size());
    //check EC element of PFI
    Assert.assertEquals(TypeModificationEnum.AUCUNE.name(), getElementComparaisonPFI(pficomp._result.getEcList(), source.getClientOperateur(), source.getNoCompte()).getTypeOperation());

    for (int n = 1; n < (nSA + 1); n++)
    {
      if (n == 5)
      {
        Assert.assertEquals(TypeModificationEnum.MODIF_ATTR.name(), getElementComparaisonSA(pficomp._result.getEcList(), "BSS_ENT", "pfi1", "sa5").getTypeOperation());
      }
      else
      {
        Assert.assertEquals(TypeModificationEnum.AUCUNE.name(), getElementComparaisonSA(pficomp._result.getEcList(), "BSS_ENT", "pfi1", "sa" + n).getTypeOperation());
      }
    }
  }

  /**
   * Assert a modificationCommercial object in a PFI creation
   *
   * @param mc
   * @param target
   */
  private void assertModificationCommercial(ModificationCommerciale mc, PFI target)
  {
    Assert.assertEquals("EN_COURS", mc.getStatut());
    Assert.assertEquals("PFI", mc.getTypeObjetCommercial());
    Assert.assertEquals(target.getNoCompte(), mc.getNoCompte());
    Assert.assertEquals(target.getClientOperateur(), mc.getClientOperateur());
    Assert.assertNull(mc.getNoServiceAccessible());
    Assert.assertNull(mc.getNoEquipement());
    Assert.assertNull(mc.getIdentifiantFonctionnelPA());
    Assert.assertNotNull(mc.getDateCreation());

    //TODO: Assert.assertEquals("???", mc.getStatutCommercialAttendu()); //Not in BL 331!!
  }

  /**
   * Assert a modificationCommercial object in a PA creation
   *
   * @param mc
   * @param sourcePFI
   * @param sa
   */
  private void assertModificationCommercial(ModificationCommerciale mc, PFI sourcePFI, EquipementDeclare equip)
  {
    Assert.assertEquals("EN_COURS", mc.getStatut());
    Assert.assertEquals("EQT_DECLARE", mc.getTypeObjetCommercial());
    Assert.assertEquals(sourcePFI.getNoCompte(), mc.getNoCompte());
    Assert.assertEquals(sourcePFI.getClientOperateur(), mc.getClientOperateur());
    Assert.assertNull(mc.getIdentifiantFonctionnelPA());
    Assert.assertEquals(equip.getNoEquipement(), mc.getNoEquipement());
    Assert.assertNotNull(mc.getDateCreation());

    //TODO: Assert.assertEquals("???", mc.getStatutCommercialAttendu()); //Not in BL 331!!
  }

  /**
   * Assert a modificationCommercial object in a PA creation
   *
   * @param mc
   * @param sourcePFI
   * @param sa
   */
  private void assertModificationCommercial(ModificationCommerciale mc, PFI sourcePFI, PA sa)
  {
    Assert.assertEquals("EN_COURS", mc.getStatut());
    Assert.assertEquals("PA", mc.getTypeObjetCommercial());
    Assert.assertEquals(sourcePFI.getNoCompte(), mc.getNoCompte());
    Assert.assertEquals(sourcePFI.getClientOperateur(), mc.getClientOperateur());
    Assert.assertNull(mc.getNoEquipement());
    Assert.assertEquals(sa.getIdentifiantFonctionnelPA(), mc.getIdentifiantFonctionnelPA());
    Assert.assertNotNull(mc.getDateCreation());

    //TODO: Assert.assertEquals("???", mc.getStatutCommercialAttendu()); //Not in BL 331!!
  }

  /**
   * Assert a modificationCommercial object in a SA creation
   *
   * @param mc
   * @param sourcePFI
   * @param sa
   */
  private void assertModificationCommercial(ModificationCommerciale mc, PFI sourcePFI, SA sa)
  {
    Assert.assertEquals("EN_COURS", mc.getStatut());
    Assert.assertEquals("SA", mc.getTypeObjetCommercial());
    Assert.assertEquals(sourcePFI.getNoCompte(), mc.getNoCompte());
    Assert.assertEquals(sourcePFI.getClientOperateur(), mc.getClientOperateur());
    Assert.assertEquals(sa.getNoServiceAccessible(), mc.getNoServiceAccessible());
    Assert.assertNull(mc.getNoEquipement());
    Assert.assertNull(mc.getIdentifiantFonctionnelPA());
    Assert.assertNotNull(mc.getDateCreation());

    //TODO: Assert.assertEquals("???", mc.getStatutCommercialAttendu()); //Not in BL 331!!
  }

}
