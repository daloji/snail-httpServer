/*******************************************************************************
* $Id: LienEquipementPAComparator_Test.java 17760 2019-02-27 17:02:37Z kbettenc $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PE0018.utils.comparators;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

import org.junit.Test;

import com.bytel.spirit.common.shared.saab.cmd.Commande;
import com.bytel.spirit.common.shared.saab.cmd.NatureCommande;
import com.bytel.spirit.common.shared.saab.rpg.LienEquipementPA;
import com.bytel.spirit.common.shared.saab.rpg.PFI;
import com.bytel.spirit.common.shared.saab.rpg.Statut;
import com.bytel.spirit.prof.processes.PE0018.utils.PFIComparatorUtils;
import com.bytel.spirit.prof.processes.PE0018.utils.TypeModificationEnum;
import com.bytel.spirit.prof.processes.PE0018.utils.TypeObjectCommercialEnum;

/**
 *
 * @author jsantos
 * @version ($Revision: 17760 $ $Date: 2019-02-27 18:02:37 +0100 (mer. 27 févr. 2019) $)
 */
public class LienEquipementPAComparator_Test implements IModificationPFI_Test
{
  /**
   * Creation of a LienEquipementPA<br>
   *
   * <b>Inputs:</b> A new LienEquipementPA<br>
   * <b>Expected:</b> Creation done <br>
   */
  @Test
  public void testCreationLienEptPA_000()
  {
    Commande commande = new Commande();
    LienEquipementPA lienEqpPATarget = buildLienEquipementPA();
    PFI pfi = new PFI();
    pfi.setClientOperateur("clientOperateur");
    pfi.setNoCompte("noCompte");
    PFIComparatorUtils result = new PFIComparatorUtils();

    LienEquipementPAComparator comparator = new LienEquipementPAComparator(pfi, commande, result, LocalDateTime.now());
    comparator.compare(null, lienEqpPATarget);

    assertEquals(Arrays.asList(lienEqpPATarget), pfi.getLienEquipementPA());
    //Check ModificationCommercial
    assertEquals(commande.getIdCmd(), result.getMcList().get(0).getIdCmd());
    assertEquals(AbstractComparator.EN_COURS, result.getMcList().get(0).getStatut());
    assertEquals(TypeObjectCommercialEnum.LIEN_EQT_PA.name(), result.getMcList().get(0).getTypeObjetCommercial());
    assertEquals(pfi.getNoCompte(), result.getMcList().get(0).getNoCompte());
    assertEquals(pfi.getClientOperateur(), result.getMcList().get(0).getClientOperateur());
    assertEquals(IModificationValue_Test.ID_FONCTIONNEL_PA, result.getMcList().get(0).getIdentifiantFonctionnelPA());
    assertEquals(IModificationValue_Test.NO_EQUIPEMENT, result.getMcList().get(0).getNoEquipement());
    //Check ElementComparaison
    assertEquals(TypeObjectCommercialEnum.LIEN_EQT_PA.name(), result.getEcList().get(0).getTypeObjetCommercial());
    assertEquals(TypeModificationEnum.CREATION.name(), result.getEcList().get(0).getTypeOperation());
    assertEquals(pfi.getClientOperateur(), result.getEcList().get(0).getClientOperateur());
    assertEquals(IModificationValue_Test.NO_EQUIPEMENT, result.getEcList().get(0).getNoEquipement());
    assertEquals(IModificationValue_Test.ID_FONCTIONNEL_PA, result.getEcList().get(0).getIdentifiantFonctionnelPA());
  }

  /**
   * Test case when is to delete a LienEquipementPA and AddUnchangedObjects is false
   */
  @Test
  public void testEqualsLienEptPA_001()
  {
    Commande commande = new Commande();
    PFI pfi = new PFI();
    LienEquipementPA lienEqpPASource = buildLienEquipementPA();
    PFIComparatorUtils result = new PFIComparatorUtils();
    addLienEquipementPA(pfi, lienEqpPASource);
    LienEquipementPAComparator comparator = new LienEquipementPAComparator(pfi, commande, result, LocalDateTime.now());
    comparator.getPFIComparatorUtils().setAddUnchangedObjects(false);
    comparator.getPFIComparatorUtils().setPaTypeList(Arrays.asList("LIGNE_FIXE,VOIP,FAX,COMPTE_ACCES,TV".split(","))); //$NON-NLS-1$ //$NON-NLS-2$
    comparator.compare(lienEqpPASource, lienEqpPASource);

    assertEquals(1, pfi.getLienEquipementPA().size());
    //Check ModificationCommercial
    assertEquals(0, result.getMcList().size());
    //Check ElementComparaison
    assertEquals(0, result.getEcList().size());
  }

  /**
   * Test case when is to delete a LienEquipementPA
   */
  @Test
  public void testEqualsLienEptPA_002()
  {
    Commande commande = new Commande();
    PFI pfi = new PFI();
    LienEquipementPA lienEqpPASource = buildLienEquipementPA();
    PFIComparatorUtils result = new PFIComparatorUtils();
    addLienEquipementPA(pfi, lienEqpPASource);

    LienEquipementPAComparator comparator = new LienEquipementPAComparator(pfi, commande, result, LocalDateTime.now());
    comparator.getPFIComparatorUtils().setAddUnchangedObjects(true);
    comparator.getPFIComparatorUtils().setPaTypeList(Arrays.asList("LIGNE_FIXE,VOIP,FAX,COMPTE_ACCES,TV".split(","))); //$NON-NLS-1$ //$NON-NLS-2$
    comparator.compare(lienEqpPASource, lienEqpPASource);

    assertEquals(1, pfi.getLienEquipementPA().size());
    //Check ModificationCommercial
    assertEquals(0, result.getMcList().size());
    //Check ElementComparaison
    assertEquals(TypeObjectCommercialEnum.LIEN_EQT_PA.name(), result.getEcList().get(0).getTypeObjetCommercial());
    assertEquals(TypeModificationEnum.AUCUNE.name(), result.getEcList().get(0).getTypeOperation());
    assertEquals(0, result.getEcList().get(0).getListeAttributModifie().size());
  }

  /**
   * Modification of a LienEquipementPA in a PFI from a Commande with NatureCommande PHOTO <br>
   *
   * <b>Inputs:</b> Commande with NatureCommande = PHOTO <br>
   * <b>Expected:</b> Modification done with a complete copy of the LienEquipementPA <br>
   */
  @Test
  public void testModificationLienEquipementPA_001()
  {
    Commande commande = new Commande();
    commande.setNatureCommande(NatureCommande.PHOTO_PFI.name());

    PFI pfi = new PFI();
    LienEquipementPA lienEqpPASource = buildLienEquipementPA();
    addLienEquipementPA(pfi, lienEqpPASource);

    LienEquipementPA lienEqpPATarget = new LienEquipementPA(lienEqpPASource.getNoEquipement(), lienEqpPASource.getIdFonctionnelPa(), Statut.RESILIE, null, null);

    PFIComparatorUtils result = new PFIComparatorUtils();
    LienEquipementPAComparator comparator = new LienEquipementPAComparator(pfi, commande, result, LocalDateTime.now());
    comparator.compare(lienEqpPASource, lienEqpPATarget);

    //Check EquipementDeclare
    assertFalse(pfi.getLienEquipementPA().contains(lienEqpPASource));
    assertTrue(pfi.getLienEquipementPA().contains(lienEqpPATarget));

    //Check ModificationCommercial
    assertTrue(result.getMcList().isEmpty());

    //Check ElementComparaison
    assertEquals(TypeObjectCommercialEnum.LIEN_EQT_PA.name(), result.getEcList().get(0).getTypeObjetCommercial());
    assertEquals(TypeModificationEnum.MODIF_ATTR.name(), result.getEcList().get(0).getTypeOperation());
    assertEquals(lienEqpPATarget.getNoEquipement(), result.getEcList().get(0).getNoEquipement());
    assertEquals(1, result.getEcList().get(0).getListeAttributModifie().size());
  }

  /**
   * Modification of a LienEquipementPA in a PFI from a Commande with NatureCommande MODIFICATION<br>
   *
   * <b>Inputs:</b> Commande with NatureCommande = MODIFICATION / EquipementDeclare with Statut = RESILIE (all the other
   * attributes are null) <br>
   * <b>Expected:</b> Modification done with a copy of the delta between LienEquipementPA source and target <br>
   */
  @Test
  public void testModificationLienEquipementPA_002()
  {
    Commande commande = new Commande();
    commande.setNatureCommande(NatureCommande.MODIFICATION_PFI.name());

    PFI pfi = new PFI();
    LienEquipementPA lienEqpPASource = buildLienEquipementPA();
    addLienEquipementPA(pfi, lienEqpPASource);

    LienEquipementPA lienEqpPATarget = new LienEquipementPA(null, null, Statut.RESILIE, null, null);

    PFIComparatorUtils result = new PFIComparatorUtils();
    LienEquipementPAComparator comparator = new LienEquipementPAComparator(pfi, commande, result, LocalDateTime.now());
    comparator.compare(lienEqpPASource, lienEqpPATarget);

    //Only the status changes (=the one in the target)
    assertEquals(lienEqpPATarget.getStatut(), pfi.getLienEquipementPA().get(0).getStatut());
    assertEquals(IModificationValue_Test.NO_EQUIPEMENT, pfi.getLienEquipementPA().get(0).getNoEquipement());
    assertEquals(IModificationValue_Test.ID_FONCTIONNEL_PA, pfi.getLienEquipementPA().get(0).getIdFonctionnelPa());

    //Check ModificationCommercial
    assertEquals(0, result.getMcList().size());
    //Check ElementComparaison
    assertEquals(TypeObjectCommercialEnum.LIEN_EQT_PA.name(), result.getEcList().get(0).getTypeObjetCommercial());
    assertEquals(TypeModificationEnum.MODIF_ATTR.name(), result.getEcList().get(0).getTypeOperation());
    assertEquals(lienEqpPATarget.getNoEquipement(), result.getEcList().get(0).getNoEquipement());
    assertEquals(1, result.getEcList().get(0).getListeAttributModifie().size());
  }

  /**
   * Deletion of a LienEquipementPA with Statut ACTIF<br>
   *
   * <b>Inputs:</b> LienEquipementPA with Statut = ACTIF <br>
   * <b>Expected:</b> The status of LienEquipementPA source is now RESILIE <br>
   */
  @Test
  public void testSuppressionLienEptPA_001()
  {
    Commande commande = new Commande();
    PFI pfi = new PFI();
    LienEquipementPA lienEqpPASource = buildLienEquipementPA();
    PFIComparatorUtils result = new PFIComparatorUtils();
    addLienEquipementPA(pfi, lienEqpPASource);

    LienEquipementPAComparator comparator = new LienEquipementPAComparator(pfi, commande, result, LocalDateTime.now());
    comparator.compare(lienEqpPASource, null);

    assertEquals(1, pfi.getLienEquipementPA().size());
    assertEquals(Statut.RESILIE, pfi.getLienEquipementPA().get(0).getStatut());

    //Check ModificationCommerciale
    assertEquals(commande.getIdCmd(), result.getMcList().get(0).getIdCmd());
    assertEquals(AbstractComparator.EN_COURS, result.getMcList().get(0).getStatut());
    assertEquals(TypeObjectCommercialEnum.LIEN_EQT_PA.name(), result.getMcList().get(0).getTypeObjetCommercial());
    assertEquals(pfi.getNoCompte(), result.getMcList().get(0).getNoCompte());
    assertEquals(commande.getClientOperateur(), result.getMcList().get(0).getClientOperateur());
    assertEquals(IModificationValue_Test.ID_FONCTIONNEL_PA, result.getMcList().get(0).getIdentifiantFonctionnelPA());
    assertEquals(IModificationValue_Test.NO_EQUIPEMENT, result.getMcList().get(0).getNoEquipement());
    assertEquals(Statut.RESILIE.name(), result.getMcList().get(0).getStatutCommercialAttendu());

    //Check ElementComparaison
    assertEquals(TypeObjectCommercialEnum.LIEN_EQT_PA.name(), result.getEcList().get(0).getTypeObjetCommercial());
    assertEquals(TypeModificationEnum.SUPPRESSION.name(), result.getEcList().get(0).getTypeOperation());
    assertEquals(0, result.getEcList().get(0).getListeAttributModifie().size());
  }

  /**
   * Deletion of a LienEquipementPA with Statut RESILIE<br>
   *
   * <b>Inputs:</b> LienEquipementPA with Statut = RESILIE <br>
   * <b>Expected:</b> The LienEquipementPA source stays the sames <br>
   */
  @Test
  public void testSuppressionLienEptPA_002()
  {
    Commande commande = new Commande();
    PFI pfi = new PFI();
    LienEquipementPA lienEqpPASource = buildLienEquipementPA();
    lienEqpPASource.setStatut(Statut.RESILIE);
    addLienEquipementPA(pfi, lienEqpPASource);

    PFIComparatorUtils result = new PFIComparatorUtils();
    LienEquipementPAComparator comparator = new LienEquipementPAComparator(pfi, commande, result, LocalDateTime.now());
    comparator.compare(lienEqpPASource, null);

    assertEquals(Arrays.asList(lienEqpPASource), pfi.getLienEquipementPA());

    //Check ModificationCommercial
    assertTrue(result.getMcList().isEmpty());
    assertTrue(result.getEcList().isEmpty());
  }

  /**
   * @param pfi
   * @param lienEquipementPA
   */
  private void addLienEquipementPA(PFI pfi, LienEquipementPA lienEquipementPA)
  {
    List<LienEquipementPA> lienEqpPAList = pfi.getLienEquipementPA();
    lienEqpPAList.add(lienEquipementPA);
    pfi.setLienEquipementPA(lienEqpPAList);
  }
}
