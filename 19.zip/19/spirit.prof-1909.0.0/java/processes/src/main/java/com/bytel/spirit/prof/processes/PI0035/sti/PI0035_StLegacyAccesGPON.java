/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PI0035.sti;

import java.time.LocalDateTime;

import com.bytel.ravel.common.json.annotations.RavelLocalDateTimeFormat;
import com.bytel.ravel.common.json.format.impl.IsoShortOffsetDateTimeWithMillis;
import com.bytel.spirit.common.connectors.nrm.structs.NRMInfosRetour;
import com.bytel.spirit.prof.processes.PI0035.structs.TypeServiceTechniqueLegacy;
import com.squareup.moshi.Json;

/**
 *
 * @author mbaptist
 * @version ($Revision$ $Date$)
 */
public class PI0035_StLegacyAccesGPON extends PI0035_ServiceTechniqueLegacy
{
  /**
   *
   */
  private static final long serialVersionUID = 1700774819671488150L;

  /**
   * Builds a new instance of {@link PI0035_StLegacyAccesGPON} from an instance of {@link NRMInfosRetour}
   *
   * @param nrmInfosRetour_p
   *          The instance of {@link NRMInfosRetour}.
   * @param statut_p
   * @param dateCreation_p
   * @param dateModification_p
   * @param nrmId_p
   * @param ossId_p
   * @param ponId_p
   * @return The instance of {@link PI0035_StLegacyAccesGPON}.
   */
  public static PI0035_StLegacyAccesGPON buildFromStLegacyAccesGPON(NRMInfosRetour nrmInfosRetour_p, String statut_p,  LocalDateTime dateCreation_p, LocalDateTime dateModification_p, String nrmId_p, String ossId_p, String ponId_p)
  {
    return new PI0035_StLegacyAccesGPON(statut_p, TypeServiceTechniqueLegacy.ACCES_GPON.name(), dateCreation_p, dateModification_p, //
        nrmId_p, ossId_p, nrmInfosRetour_p.getNomOLT(), nrmInfosRetour_p.getCarte().toString(), ponId_p, nrmInfosRetour_p.getOntId().toString(), //
        nrmInfosRetour_p.getCodeAccesTechnique(), nrmInfosRetour_p.getNumeroSerieOnt(), nrmInfosRetour_p.getDateModificationOnt());
  }

  /**
   * Identifiant de l'accès dans l'OSS Legacy
   */
  @Json(name = "nrmId")
  private String _nrmId;

  /**
   * Pivot de l'accès entre l'OSS legacy et NSF
   */
  @Json(name = "ossId")
  private String _ossId;

  /**
   * Nom de l'OLT où l'accès est provisionné
   */
  @Json(name = "nomOLT")
  private String _nomOLT;

  /**
   * Position de Port sur la carte où l'accès est provisionné
   */
  @Json(name = "carte")
  private String _carte;

  /**
   * Position du Port sur la carte où l'accès est provisionné
   */
  @Json(name = "ponId")
  private String _ponId;

  /**
   * Numéro de l'ONT sur le port
   */
  @Json(name = "ontId")
  private String _ontId;

  /**
   * Offre technique associè à l'accès
   */
  @Json(name = "codeAccesTechnique")
  private String _codeAccesTechnique;

  /**
   * Numéro de série de l'ONT installá chez le client
   */
  @Json(name = "numeroSerieOnt")
  private String _numeroSerieOnt;

  /**
   * Date de derniére modification de l'ONT installé
   */
  @Json(name = "dateModificationOnt")
  @RavelLocalDateTimeFormat(IsoShortOffsetDateTimeWithMillis.class)
  private LocalDateTime _dateModificationOnt;

  /**
   * @param statut_p
   * @param typeServiceTechnique_p
   * @param dateCreation_p
   * @param dateModification_p
   * @param nrmId_p
   * @param ossId_p
   * @param nomOLT_p
   * @param carte_p
   * @param ponId_p
   * @param ontId_p
   * @param codeAccesTechnique_p
   * @param numeroSerieOnt_p
   * @param dateModificationOnt_p
   */
  public PI0035_StLegacyAccesGPON(String statut_p, String typeServiceTechnique_p, LocalDateTime dateCreation_p, LocalDateTime dateModification_p, String nrmId_p, String ossId_p, String nomOLT_p, String carte_p, String ponId_p, String ontId_p, String codeAccesTechnique_p, String numeroSerieOnt_p, LocalDateTime dateModificationOnt_p)
  {
    super(statut_p, typeServiceTechnique_p, dateCreation_p, dateModification_p);
    _nrmId = nrmId_p;
    _ossId = ossId_p;
    _nomOLT = nomOLT_p;
    _carte = carte_p;
    _ponId = ponId_p;
    _ontId = ontId_p;
    _codeAccesTechnique = codeAccesTechnique_p;
    _numeroSerieOnt = numeroSerieOnt_p;
    _dateModificationOnt = dateModificationOnt_p;
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (!super.equals(obj))
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    PI0035_StLegacyAccesGPON other = (PI0035_StLegacyAccesGPON) obj;
    if (_carte == null)
    {
      if (other._carte != null)
      {
        return false;
      }
    }
    else if (!_carte.equals(other._carte))
    {
      return false;
    }
    if (_codeAccesTechnique == null)
    {
      if (other._codeAccesTechnique != null)
      {
        return false;
      }
    }
    else if (!_codeAccesTechnique.equals(other._codeAccesTechnique))
    {
      return false;
    }
    if (_dateModificationOnt == null)
    {
      if (other._dateModificationOnt != null)
      {
        return false;
      }
    }
    else if (!_dateModificationOnt.equals(other._dateModificationOnt))
    {
      return false;
    }
    if (_nomOLT == null)
    {
      if (other._nomOLT != null)
      {
        return false;
      }
    }
    else if (!_nomOLT.equals(other._nomOLT))
    {
      return false;
    }
    if (_nrmId == null)
    {
      if (other._nrmId != null)
      {
        return false;
      }
    }
    else if (!_nrmId.equals(other._nrmId))
    {
      return false;
    }
    if (_numeroSerieOnt == null)
    {
      if (other._numeroSerieOnt != null)
      {
        return false;
      }
    }
    else if (!_numeroSerieOnt.equals(other._numeroSerieOnt))
    {
      return false;
    }
    if (_ontId == null)
    {
      if (other._ontId != null)
      {
        return false;
      }
    }
    else if (!_ontId.equals(other._ontId))
    {
      return false;
    }
    if (_ossId == null)
    {
      if (other._ossId != null)
      {
        return false;
      }
    }
    else if (!_ossId.equals(other._ossId))
    {
      return false;
    }
    if (_ponId == null)
    {
      if (other._ponId != null)
      {
        return false;
      }
    }
    else if (!_ponId.equals(other._ponId))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the carte
   */
  public String getCarte()
  {
    return _carte;
  }

  /**
   * @return the codeAccesTechnique
   */
  public String getCodeAccesTechnique()
  {
    return _codeAccesTechnique;
  }

  /**
   * @return the dateModificationOnt
   */
  public LocalDateTime getDateModificationOnt()
  {
    return _dateModificationOnt;
  }

  /**
   * @return the nomOLT
   */
  public String getNomOLT()
  {
    return _nomOLT;
  }

  /**
   * @return the nrmId
   */
  public String getNrmId()
  {
    return _nrmId;
  }

  /**
   * @return the numeroSerieOnt
   */
  public String getNumeroSerieOnt()
  {
    return _numeroSerieOnt;
  }

  /**
   * @return the ontId
   */
  public String getOntId()
  {
    return _ontId;
  }

  /**
   * @return the ossId
   */
  public String getOssId()
  {
    return _ossId;
  }

  /**
   * @return the ponId
   */
  public String getPonId()
  {
    return _ponId;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = super.hashCode();
    result = (prime * result) + ((_carte == null) ? 0 : _carte.hashCode());
    result = (prime * result) + ((_codeAccesTechnique == null) ? 0 : _codeAccesTechnique.hashCode());
    result = (prime * result) + ((_dateModificationOnt == null) ? 0 : _dateModificationOnt.hashCode());
    result = (prime * result) + ((_nomOLT == null) ? 0 : _nomOLT.hashCode());
    result = (prime * result) + ((_nrmId == null) ? 0 : _nrmId.hashCode());
    result = (prime * result) + ((_numeroSerieOnt == null) ? 0 : _numeroSerieOnt.hashCode());
    result = (prime * result) + ((_ontId == null) ? 0 : _ontId.hashCode());
    result = (prime * result) + ((_ossId == null) ? 0 : _ossId.hashCode());
    result = (prime * result) + ((_ponId == null) ? 0 : _ponId.hashCode());
    return result;
  }

  /**
   * @param carte_p
   *          the carte to set
   */
  public void setCarte(String carte_p)
  {
    _carte = carte_p;
  }

  /**
   * @param codeAccesTechnique_p
   *          the codeAccesTechnique to set
   */
  public void setCodeAccesTechnique(String codeAccesTechnique_p)
  {
    _codeAccesTechnique = codeAccesTechnique_p;
  }

  /**
   * @param dateModificationOnt_p
   *          the dateModificationOnt to set
   */
  public void setDateModificationOnt(LocalDateTime dateModificationOnt_p)
  {
    _dateModificationOnt = dateModificationOnt_p;
  }

  /**
   * @param nomOLT_p
   *          the nomOLT to set
   */
  public void setNomOLT(String nomOLT_p)
  {
    _nomOLT = nomOLT_p;
  }

  /**
   * @param nrmId_p
   *          the nrmId to set
   */
  public void setNrmId(String nrmId_p)
  {
    _nrmId = nrmId_p;
  }

  /**
   * @param numeroSerieOnt_p
   *          the numeroSerieOnt to set
   */
  public void setNumeroSerieOnt(String numeroSerieOnt_p)
  {
    _numeroSerieOnt = numeroSerieOnt_p;
  }

  /**
   * @param ontId_p
   *          the ontId to set
   */
  public void setOntId(String ontId_p)
  {
    _ontId = ontId_p;
  }

  /**
   * @param ossId_p
   *          the ossId to set
   */
  public void setOssId(String ossId_p)
  {
    _ossId = ossId_p;
  }

  /**
   * @param ponId_p
   *          the ponId to set
   */
  public void setPonId(String ponId_p)
  {
    _ponId = ponId_p;
  }

  @Override
  public String toString()
  {
    return "PI0035_StLegacyAccesGPON [_nrmId=" + _nrmId + ", _ossId=" + _ossId + ", _nomOLT=" + _nomOLT + ", _carte=" + _carte + ", _ponId=" + _ponId + ", _ontId=" + _ontId + ", _codeAccesTechnique=" + _codeAccesTechnique + ", _numeroSerieOnt=" + _numeroSerieOnt + ", _dateModificationOnt=" + _dateModificationOnt + ", _dateModification=" + "]";
  }

}
