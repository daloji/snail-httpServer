/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PI0035.sti;

import java.io.Serializable;

import com.squareup.moshi.Json;

/**
 *
 * @author pescudei
 * @version ($Revision$ $Date$)
 */
public class PI0035_DonneesProvisionneesStPfsPnf implements Serializable
{
  /**
   *
   */
  private static final long serialVersionUID = 7586151788152227055L;

  /**
   * Resource noTelephone
   */
  @Json(name = "noTelephone")
  private String _noTelephone;

  /**
   * Resource prefixeRoutage
   */
  @Json(name = "prefixeRoutage")
  private String _prefixeRoutage;

  /**
   * @param noTelephone_p
   * @param prefixeRoutage_p
   */
  public PI0035_DonneesProvisionneesStPfsPnf(String noTelephone_p, String prefixeRoutage_p)
  {
    super();

    _noTelephone = noTelephone_p;
    _prefixeRoutage = prefixeRoutage_p;
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    PI0035_DonneesProvisionneesStPfsPnf other = (PI0035_DonneesProvisionneesStPfsPnf) obj;
    if (_noTelephone == null)
    {
      if (other._noTelephone != null)
      {
        return false;
      }
    }
    else if (!_noTelephone.equals(other._noTelephone))
    {
      return false;
    }
    if (_prefixeRoutage == null)
    {
      if (other._prefixeRoutage != null)
      {
        return false;
      }
    }
    else if (!_prefixeRoutage.equals(other._prefixeRoutage))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the noTelephone
   */
  public String getNoTelephone()
  {
    return _noTelephone;
  }

  /**
   * @return the prefixeRoutage
   */
  public String getPrefixeRoutage()
  {
    return _prefixeRoutage;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_noTelephone == null) ? 0 : _noTelephone.hashCode());
    result = (prime * result) + ((_prefixeRoutage == null) ? 0 : _prefixeRoutage.hashCode());
    return result;
  }

  /**
   * @param noTelephone_p
   *          the noTelephone to set
   */
  public void setNoTelephone(String noTelephone_p)
  {
    _noTelephone = noTelephone_p;
  }

  /**
   * @param prefixeRoutage_p
   *          the prefixeRoutage to set
   */
  public void setPrefixeRoutage(String prefixeRoutage_p)
  {
    _prefixeRoutage = prefixeRoutage_p;
  }

  @Override
  public String toString()
  {
    StringBuilder builder = new StringBuilder();
    builder.append("PI0035_DonneesProvisionneesStPfsPnf [_noTelephone="); //$NON-NLS-1$
    builder.append(_noTelephone);
    builder.append(", _prefixeRoutage="); //$NON-NLS-1$
    builder.append(_prefixeRoutage);
    builder.append("]"); //$NON-NLS-1$
    return builder.toString();
  }
}
