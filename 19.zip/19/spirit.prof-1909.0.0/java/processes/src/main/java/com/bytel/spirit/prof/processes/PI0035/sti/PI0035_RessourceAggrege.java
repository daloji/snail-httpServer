/*
 *                                                             ___o.__
 *                                                         ,oH8888888888o._
 *                                                       dP',88888P'''`8888o.
 *   ____                                              ,8',888888      888888o
 *  |  _ \                                            d8,d888888b    ,d8888888b
 *  | |_) | ___  _   _ _   _  __ _ _   _  ___  ___   ,8PPY8888888boo8888PPPP"'`b
 *  |  _ < / _ \| | | | | | |/ _` | | | |/ _ \/ __|  d8o_                     d8
 *  | |_) | (_) | |_| | |_| | (_| | |_| |  __/\__ \' d888bo.             _ooP d8'
 *  |____/ \___/ \__,_|\__, |\__, |\__,_|\___||___/  d8888888P     ,ooo88888P d8
 *                      __/ | ___/_                  `8M8888P     ,88888888P ,8P
 *                     |___/ |__ |  _  |  _  _  _ __  Y88Y88'    ,888888888' dP
 *                               | (/_ | (/_(_ (_)|||  `8b8P    d8888888888,dP
 *                                                      Y8,   d88888888888P'
 *                                                        `Y=8888888888P'
 *                                                            `''`'''
 *
 *  Systeme $system
 *
 *  (C) Copyright Bouygues Telecom 2018.
 *
 *  Utilisation, reproduction et divulgation interdites
 *  sans autorisation ecrite de Bouygues Telecom.
 *
 *  Projet  : FTTOcmdRacco_Lot3_Rebasing1901
 *  Package : com.bytel.spirit.prof.processes.PI0035.sti
 *  Classe  : PI0035_RessourceAggrege
 *  Auteur  : sdiop
 *
 */

package com.bytel.spirit.prof.processes.PI0035.sti;

import java.io.Serializable;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import com.bytel.spirit.common.shared.misc.validation.IValidationConst;
import com.squareup.moshi.Json;

/**
 *
 * @author sdiop
 * @version ($Revision$ $Date$)
 */
public abstract class PI0035_RessourceAggrege implements Serializable
{
  /**
   *
   */
  private static final long serialVersionUID = 5970310460493640609L;

  /**
   * Type de la Ressource aggrege
   */
  @Json(name = "typeRessourceAggrege")
  @NotNull(message = IValidationConst.ATTRIBUT_OBLIGATOIRE_MANQUANT)
  @Pattern(regexp = "P2P|XDSL", message = IValidationConst.FORMAT_ATTRIBUT_NON_RESPECTE)
  private String _typeRessourceAggrege;

  /**
   * @param typeRessourceAggrege_p
   */
  public PI0035_RessourceAggrege(String typeRessourceAggrege_p)
  {
    this._typeRessourceAggrege = typeRessourceAggrege_p;
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    PI0035_RessourceAggrege other = (PI0035_RessourceAggrege) obj;
    if (_typeRessourceAggrege == null)
    {
      if (other._typeRessourceAggrege != null)
      {
        return false;
      }
    }
    else if (!_typeRessourceAggrege.equals(other._typeRessourceAggrege))
    {
      return false;
    }
    return true;
  }

  /**
   * @return _typeRessourceAggrege
   */
  public String getTypeRessourceAggrege()
  {
    return _typeRessourceAggrege;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_typeRessourceAggrege == null) ? 0 : _typeRessourceAggrege.hashCode());
    return result;
  }

  /**
   * @param typeRessourceAggrege_p
   *          _typeRessourceAggrege
   */
  public void setTypeRessourceAggrege(String typeRessourceAggrege_p)
  {
    _typeRessourceAggrege = typeRessourceAggrege_p;
  }

  @Override
  public String toString()
  {
    StringBuilder builder = new StringBuilder();
    builder.append("PI0035_RessourceAggrege [_typeRessourceAggrege="); //$NON-NLS-1$
    builder.append(_typeRessourceAggrege);
    builder.append("]"); //$NON-NLS-1$
    return builder.toString();
  }
}
