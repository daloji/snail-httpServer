/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PI0035.sti;

import java.io.Serializable;

import com.squareup.moshi.Json;

/**
 *
 *
 * @author pramos
 * @version ($Revision$ $Date$)
 */
public class PI0035_DonneesProvisionneesStPfsEnum implements Serializable
{
  /**
   *
   */
  private static final long serialVersionUID = 4045297528442983449L;

  /**
   * Resource noTelephone
   */
  @Json(name = "noTelephone")
  private String _noTelephone;

  /**
   * Resource prefixeRoutage
   */
  @Json(name = "sipUri")
  private String _sipUri;

  /**
   *
   * @param noTelephone_p
   * @param sipUri_p
   */
  public PI0035_DonneesProvisionneesStPfsEnum(String noTelephone_p, String sipUri_p)
  {
    super();

    _noTelephone = noTelephone_p;
    _sipUri = sipUri_p;
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    PI0035_DonneesProvisionneesStPfsEnum other = (PI0035_DonneesProvisionneesStPfsEnum) obj;
    if (_noTelephone == null)
    {
      if (other._noTelephone != null)
      {
        return false;
      }
    }
    else if (!_noTelephone.equals(other._noTelephone))
    {
      return false;
    }
    if (_sipUri == null)
    {
      if (other._sipUri != null)
      {
        return false;
      }
    }
    else if (!_sipUri.equals(other._sipUri))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the noTelephone
   */
  public String getNoTelephone()
  {
    return _noTelephone;
  }

  /**
   * @return the sipUri
   */
  public String getSipUri()
  {
    return _sipUri;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_noTelephone == null) ? 0 : _noTelephone.hashCode());
    result = (prime * result) + ((_sipUri == null) ? 0 : _sipUri.hashCode());
    return result;
  }

  /**
   * @param noTelephone_p
   *          the noTelephone to set
   */
  public void setNoTelephone(String noTelephone_p)
  {
    _noTelephone = noTelephone_p;
  }

  /**
   * @param sipUri_p
   *          the sipUri to set
   */
  public void setSipUri(String sipUri_p)
  {
    _sipUri = sipUri_p;
  }

  @Override
  public String toString()
  {
    StringBuilder builder = new StringBuilder();
    builder.append("PI0035_DonneesProvisionneesStPfsEnum [_noTelephone="); //$NON-NLS-1$
    builder.append(_noTelephone);
    builder.append(", _sipUri="); //$NON-NLS-1$
    builder.append(_sipUri);
    builder.append("]"); //$NON-NLS-1$
    return builder.toString();
  }
}
