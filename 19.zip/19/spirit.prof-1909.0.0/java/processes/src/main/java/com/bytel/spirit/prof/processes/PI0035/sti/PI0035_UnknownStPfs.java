/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PI0035.sti;

import java.time.LocalDateTime;

import com.bytel.spirit.common.shared.functional.types.json.st.pfs.UnknownStPfs;
import com.bytel.spirit.common.shared.saab.rst.ServiceTechnique;

/**
 *
 * @author jgregori
 * @version ($Revision$ $Date$)
 */

public final class PI0035_UnknownStPfs extends PI0035_AbstractStPfs
{
  /**
   *
   */
  private static final long serialVersionUID = -2638828833409424412L;

  /**
   * Builds a new instance of {@link PI0035_UnknownStPfs} from an instance of {@link ServiceTechnique}
   *
   * @param unknownStPfs_p
   *          The instance of {@link ServiceTechnique}.
   * @return The instance of {@link PI0035_UnknownStPfs}.
   */
  public static PI0035_UnknownStPfs buildFromUnknownStPfs(UnknownStPfs unknownStPfs_p)
  {
    PI0035_UnknownStPfs unknownStPfs = new PI0035_UnknownStPfs(unknownStPfs_p.getIdSt(), unknownStPfs_p.getStatut(), unknownStPfs_p.getDateCreation(), unknownStPfs_p.getDateModification());
    return unknownStPfs;
  }

  /**
   * @param idSt_p
   *          id
   * @param statut_p
   *          statut
   * @param dateCreation_p
   *          date creation
   * @param dateModification_p
   *          date modification
   */
  public PI0035_UnknownStPfs(String idSt_p, String statut_p, LocalDateTime dateCreation_p, LocalDateTime dateModification_p)
  {
    super(idSt_p, statut_p, null, dateCreation_p, dateModification_p);
  }

}
