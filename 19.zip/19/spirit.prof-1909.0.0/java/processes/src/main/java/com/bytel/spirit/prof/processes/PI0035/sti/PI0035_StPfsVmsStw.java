/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PI0035.sti;

import java.time.LocalDateTime;

import com.bytel.spirit.common.shared.functional.types.json.st.pfs.TypePFS;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.vmsstw.StPfsVmsStw;
import com.bytel.spirit.common.shared.saab.rst.ServiceTechnique;
import com.squareup.moshi.Json;

/**
 *
 * @author pescudei
 * @version ($Revision$ $Date$)
 */
public class PI0035_StPfsVmsStw extends PI0035_AbstractStPfs
{
  /**
   *
   */
  private static final long serialVersionUID = 5918338994947706510L;

  /**
   * Builds a new instance of {@link PI0035_StPfsVmsStw} from an instance of {@link ServiceTechnique}
   *
   * @param stPfsVmsStw_p
   *          The instance of {@link ServiceTechnique}.
   * @return The instance of {@link PI0035_StPfsVmsStw}.
   */
  public static PI0035_StPfsVmsStw buildFromStPfsVmsStw(StPfsVmsStw stPfsVmsStw_p)
  {

    PI0035_DonneesIdentificationStPfsVmsStw donneesIdent = new PI0035_DonneesIdentificationStPfsVmsStw(stPfsVmsStw_p.getDonneesIdentificationSTPfsVmsStw().getIdentifiantFonctionnelPa());

    PI0035_DonneesProvisionneesStPfsVmsStw donneesProv = null;
    if (stPfsVmsStw_p.getDonneesProvisionneesSTPfsVmsStw() != null)
    {
      donneesProv = new PI0035_DonneesProvisionneesStPfsVmsStw(stPfsVmsStw_p.getDonneesProvisionneesSTPfsVmsStw().getNoTelephone(), //
          stPfsVmsStw_p.getDonneesProvisionneesSTPfsVmsStw().getTypeUsage(), //
          stPfsVmsStw_p.getDonneesProvisionneesSTPfsVmsStw().getLigneMarche(), //
          stPfsVmsStw_p.getDonneesProvisionneesSTPfsVmsStw().getAdresseMail(), //
          stPfsVmsStw_p.getDonneesProvisionneesSTPfsVmsStw().getNomPrenomUtilisateur());
    }

    return new PI0035_StPfsVmsStw(stPfsVmsStw_p.getIdSt(), stPfsVmsStw_p.getStatut(), stPfsVmsStw_p.getDateCreation(), stPfsVmsStw_p.getDateModification(), donneesIdent, donneesProv);

  }

  /**
   * Donnes Identification
   */
  @Json(name = "donneesIdentification")
  private PI0035_DonneesIdentificationStPfsVmsStw _donneesIdentification;

  /**
   * Donnes Provisionnees
   */
  @Json(name = "donneesProvisionnees")
  private PI0035_DonneesProvisionneesStPfsVmsStw _donneesProvisionnees;

  /**
   * @param idSt_p
   * @param statut_p
   * @param dateCreation_p
   * @param dateModification_p
   * @param donneesIdentification_p
   * @param donneesProvisionnees_p
   */
  public PI0035_StPfsVmsStw(String idSt_p, String statut_p, LocalDateTime dateCreation_p, LocalDateTime dateModification_p, PI0035_DonneesIdentificationStPfsVmsStw donneesIdentification_p, PI0035_DonneesProvisionneesStPfsVmsStw donneesProvisionnees_p)
  {
    super(idSt_p, statut_p, TypePFS.VMS_STW.name(), dateCreation_p, dateModification_p);

    _donneesIdentification = donneesIdentification_p;
    _donneesProvisionnees = donneesProvisionnees_p;
  }

  /**
   * @return the donneesIdentification
   */
  public PI0035_DonneesIdentificationStPfsVmsStw getDonneesIdentification()
  {
    return _donneesIdentification;
  }

  /**
   * @return the donneesProvisionnees
   */
  public PI0035_DonneesProvisionneesStPfsVmsStw getDonneesProvisionnees()
  {
    return _donneesProvisionnees;
  }

  /**
   * @param donneesIdentification_p
   *          the donneesIdentification to set
   */
  public void setDonneesIdentification(PI0035_DonneesIdentificationStPfsVmsStw donneesIdentification_p)
  {
    _donneesIdentification = donneesIdentification_p;
  }

  /**
   * @param donneesProvisionnees_p
   *          the donneesProvisionnees to set
   */
  public void setDonneesProvisionnees(PI0035_DonneesProvisionneesStPfsVmsStw donneesProvisionnees_p)
  {
    _donneesProvisionnees = donneesProvisionnees_p;
  }

  @Override
  public String toString()
  {
    StringBuilder builder = new StringBuilder();
    builder.append("PI0035_StPfsVmsStw [_donneesIdentification="); //$NON-NLS-1$
    builder.append(_donneesIdentification);
    builder.append(", _donneesProvisionnees="); //$NON-NLS-1$
    builder.append(_donneesProvisionnees);
    builder.append(", getCommentaire()="); //$NON-NLS-1$
    builder.append(getCommentaire());
    builder.append(", getDateCreation()="); //$NON-NLS-1$
    builder.append(getDateCreation());
    builder.append(", getDateModification()="); //$NON-NLS-1$
    builder.append(getDateModification());
    builder.append(", getIdSt()="); //$NON-NLS-1$
    builder.append(getIdSt());
    builder.append(", getStatut()="); //$NON-NLS-1$
    builder.append(getStatut());
    builder.append(", getTypeServiceTechnique()="); //$NON-NLS-1$
    builder.append(getTypeServiceTechnique());
    builder.append("]"); //$NON-NLS-1$
    return builder.toString();
  }
}
