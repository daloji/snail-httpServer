/*******************************************************************************
* $Id: AdresseInstallation.java 14018 2018-12-03 16:34:20Z lchanyip $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PI0035.sti;

import java.io.Serializable;

import com.bytel.spirit.common.shared.saab.rpg.AdresseInstallation;
import com.squareup.moshi.Json;

/**
 * AdresseInstallation json class
 *
 * @author lchanyip
 * @version ($Revision: 14018 $ $Date: 2018-12-03 17:34:20 +0100 (lun., 03 déc. 2018) $)
 */
public class PI0035_AdresseInstallation implements Serializable
{

  /**
   * serialVersionUID
   */
  private static final long serialVersionUID = -3864750496135558860L;

  /**
   * Creates a new instance of [{@link PI0035_AdresseInstallation} from an instance of {@link AdresseInstallation}.
   *
   * @param adresseInstallation_p
   *          The AdresseInstallation instance.
   * @return The PI0035_AdresseInstallation instance.
   */
  public static PI0035_AdresseInstallation buildFromAdresseInstallation(AdresseInstallation adresseInstallation_p)
  {
    PI0035_AdresseInstallation adresseInstallation = new PI0035_AdresseInstallation(adresseInstallation_p.getNumero(), adresseInstallation_p.getCodePostal(), adresseInstallation_p.getVille());

    adresseInstallation.setIndiceRepetition(adresseInstallation_p.getIndiceRepetition());
    adresseInstallation.setNomVoie(adresseInstallation_p.getNomVoie());
    adresseInstallation.setCodeInsee(adresseInstallation_p.getCodeInsee());
    adresseInstallation.setCodeRivoli(adresseInstallation_p.getCodeRivoli());
    adresseInstallation.setPorte(adresseInstallation_p.getPorte());
    adresseInstallation.setLogo(adresseInstallation_p.getLogo());
    adresseInstallation.setBatiment(adresseInstallation_p.getBatiment());
    adresseInstallation.setEscalier(adresseInstallation_p.getEscalier());

    adresseInstallation.setEtage(adresseInstallation_p.getEtage());
    adresseInstallation.setPrecedentProprietaire(adresseInstallation_p.getPrecedentProprietaire());
    adresseInstallation.setHexacle(adresseInstallation_p.getHexacle());

    return adresseInstallation;
  }

  /**
   * numero
   */
  @Json(name = "numero")
  private String _numero;

  /**
   * indiceRepetition
   */
  @Json(name = "indiceRepetition")
  private String _indiceRepetition;

  /**
   * nomVoie
   */
  @Json(name = "nomVoie")
  private String _nomVoie;

  /**
   * codePostal
   */
  @Json(name = "codePostal")
  private String _codePostal;

  /**
   * ville
   */
  @Json(name = "ville")
  private String _ville;

  /**
   * codeInsee
   */
  @Json(name = "codeInsee")
  private String _codeInsee;

  /**
   * codeRivoli
   */
  @Json(name = "codeRivoli")
  private String _codeRivoli;

  /**
   * porte
   */
  @Json(name = "porte")
  private String _porte;

  /**
   * logo
   */
  @Json(name = "logo")
  private String _logo;

  /**
   * batiment
   */
  @Json(name = "batiment")
  private String _batiment;

  /**
   * escalier
   */
  @Json(name = "escalier")
  private String _escalier;

  /**
   * etage
   */
  @Json(name = "etage")
  private String _etage;

  /**
   * precedentProprietaire
   */
  @Json(name = "precedentProprietaire")
  private String _precedentProprietaire;

  /**
   * porte
   */
  @Json(name = "hexacle")
  private String _hexacle;

  /**
   * Default constructor
   *
   * @param numero_p
   *          numero
   * @param codePostal_p
   *          codePostal
   * @param ville_p
   *          ville
   */
  public PI0035_AdresseInstallation(String numero_p, String codePostal_p, String ville_p)
  {
    super();
    _numero = numero_p;
    _codePostal = codePostal_p;
    _ville = ville_p;
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    PI0035_AdresseInstallation other = (PI0035_AdresseInstallation) obj;
    if (_batiment == null)
    {
      if (other._batiment != null)
      {
        return false;
      }
    }
    else if (!_batiment.equals(other._batiment))
    {
      return false;
    }
    if (_codeInsee == null)
    {
      if (other._codeInsee != null)
      {
        return false;
      }
    }
    else if (!_codeInsee.equals(other._codeInsee))
    {
      return false;
    }
    if (_codePostal == null)
    {
      if (other._codePostal != null)
      {
        return false;
      }
    }
    else if (!_codePostal.equals(other._codePostal))
    {
      return false;
    }
    if (_codeRivoli == null)
    {
      if (other._codeRivoli != null)
      {
        return false;
      }
    }
    else if (!_codeRivoli.equals(other._codeRivoli))
    {
      return false;
    }
    if (_escalier == null)
    {
      if (other._escalier != null)
      {
        return false;
      }
    }
    else if (!_escalier.equals(other._escalier))
    {
      return false;
    }
    if (_etage == null)
    {
      if (other._etage != null)
      {
        return false;
      }
    }
    else if (!_etage.equals(other._etage))
    {
      return false;
    }
    if (_hexacle == null)
    {
      if (other._hexacle != null)
      {
        return false;
      }
    }
    else if (!_hexacle.equals(other._hexacle))
    {
      return false;
    }
    if (_indiceRepetition == null)
    {
      if (other._indiceRepetition != null)
      {
        return false;
      }
    }
    else if (!_indiceRepetition.equals(other._indiceRepetition))
    {
      return false;
    }
    if (_logo == null)
    {
      if (other._logo != null)
      {
        return false;
      }
    }
    else if (!_logo.equals(other._logo))
    {
      return false;
    }
    if (_nomVoie == null)
    {
      if (other._nomVoie != null)
      {
        return false;
      }
    }
    else if (!_nomVoie.equals(other._nomVoie))
    {
      return false;
    }
    if (_numero == null)
    {
      if (other._numero != null)
      {
        return false;
      }
    }
    else if (!_numero.equals(other._numero))
    {
      return false;
    }
    if (_porte == null)
    {
      if (other._porte != null)
      {
        return false;
      }
    }
    else if (!_porte.equals(other._porte))
    {
      return false;
    }
    if (_precedentProprietaire == null)
    {
      if (other._precedentProprietaire != null)
      {
        return false;
      }
    }
    else if (!_precedentProprietaire.equals(other._precedentProprietaire))
    {
      return false;
    }
    if (_ville == null)
    {
      if (other._ville != null)
      {
        return false;
      }
    }
    else if (!_ville.equals(other._ville))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the batiment
   */
  public String getBatiment()
  {
    return _batiment;
  }

  /**
   * @return the codeInsee
   */
  public String getCodeInsee()
  {
    return _codeInsee;
  }

  /**
   * @return the codePostal
   */
  public String getCodePostal()
  {
    return _codePostal;
  }

  /**
   * @return the codeRivoli
   */
  public String getCodeRivoli()
  {
    return _codeRivoli;
  }

  /**
   * @return the escalier
   */
  public String getEscalier()
  {
    return _escalier;
  }

  /**
   * @return the etage
   */
  public String getEtage()
  {
    return _etage;
  }

  /**
   * @return the hexacle
   */
  public String getHexacle()
  {
    return _hexacle;
  }

  /**
   * @return the indiceRepetition
   */
  public String getIndiceRepetition()
  {
    return _indiceRepetition;
  }

  /**
   * @return the logo
   */
  public String getLogo()
  {
    return _logo;
  }

  /**
   * @return the nomVoie
   */
  public String getNomVoie()
  {
    return _nomVoie;
  }

  /**
   * @return the numero
   */
  public String getNumero()
  {
    return _numero;
  }

  /**
   * @return the porte
   */
  public String getPorte()
  {
    return _porte;
  }

  /**
   * @return the precedentProprietaire
   */
  public String getPrecedentProprietaire()
  {
    return _precedentProprietaire;
  }

  /**
   * @return the ville
   */
  public String getVille()
  {
    return _ville;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_batiment == null) ? 0 : _batiment.hashCode());
    result = (prime * result) + ((_codeInsee == null) ? 0 : _codeInsee.hashCode());
    result = (prime * result) + ((_codePostal == null) ? 0 : _codePostal.hashCode());
    result = (prime * result) + ((_codeRivoli == null) ? 0 : _codeRivoli.hashCode());
    result = (prime * result) + ((_escalier == null) ? 0 : _escalier.hashCode());
    result = (prime * result) + ((_etage == null) ? 0 : _etage.hashCode());
    result = (prime * result) + ((_hexacle == null) ? 0 : _hexacle.hashCode());
    result = (prime * result) + ((_indiceRepetition == null) ? 0 : _indiceRepetition.hashCode());
    result = (prime * result) + ((_logo == null) ? 0 : _logo.hashCode());
    result = (prime * result) + ((_nomVoie == null) ? 0 : _nomVoie.hashCode());
    result = (prime * result) + ((_numero == null) ? 0 : _numero.hashCode());
    result = (prime * result) + ((_porte == null) ? 0 : _porte.hashCode());
    result = (prime * result) + ((_precedentProprietaire == null) ? 0 : _precedentProprietaire.hashCode());
    result = (prime * result) + ((_ville == null) ? 0 : _ville.hashCode());
    return result;
  }

  /**
   * @param batiment_p
   *          the batiment to set
   */
  public void setBatiment(String batiment_p)
  {
    _batiment = batiment_p;
  }

  /**
   * @param codeInsee_p
   *          the codeInsee to set
   */
  public void setCodeInsee(String codeInsee_p)
  {
    _codeInsee = codeInsee_p;
  }

  /**
   * @param codeRivoli_p
   *          the codeRivoli to set
   */
  public void setCodeRivoli(String codeRivoli_p)
  {
    _codeRivoli = codeRivoli_p;
  }

  /**
   * @param escalier_p
   *          the escalier to set
   */
  public void setEscalier(String escalier_p)
  {
    _escalier = escalier_p;
  }

  /**
   * @param etage_p
   *          the etage to set
   */
  public void setEtage(String etage_p)
  {
    _etage = etage_p;
  }

  /**
   * @param hexacle_p
   *          the hexacle to set
   */
  public void setHexacle(String hexacle_p)
  {
    _hexacle = hexacle_p;
  }

  /**
   * @param indiceRepetition_p
   *          the indiceRepetition to set
   */
  public void setIndiceRepetition(String indiceRepetition_p)
  {
    _indiceRepetition = indiceRepetition_p;
  }

  /**
   * @param logo_p
   *          the logo to set
   */
  public void setLogo(String logo_p)
  {
    _logo = logo_p;
  }

  /**
   * @param nomVoie_p
   *          the nomVoie to set
   */
  public void setNomVoie(String nomVoie_p)
  {
    _nomVoie = nomVoie_p;
  }

  /**
   * @param porte_p
   *          the porte to set
   */
  public void setPorte(String porte_p)
  {
    _porte = porte_p;
  }

  /**
   * @param precedentProprietaire_p
   *          the precedentProprietaire to set
   */
  public void setPrecedentProprietaire(String precedentProprietaire_p)
  {
    _precedentProprietaire = precedentProprietaire_p;
  }

  @Override
  public String toString()
  {
    return "AdresseInstallation [_numero=" + _numero + ", _indiceRepetition=" + _indiceRepetition + ", _nomVoie=" + _nomVoie + ", _codePostal=" + _codePostal + ", _ville=" + _ville + ", _codeInsee=" + _codeInsee + ", _codeRivoli=" + _codeRivoli + ", _porte=" + _porte + ", _logo=" + _logo + ", _batiment=" + _batiment + ", _escalier=" + _escalier + ", _etage=" + _etage + ", _precedentProprietaire=" + _precedentProprietaire + ", _hexacle=" + _hexacle + "]"; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$ //$NON-NLS-10$ //$NON-NLS-11$ //$NON-NLS-12$ //$NON-NLS-13$ //$NON-NLS-14$ //$NON-NLS-15$
  }
}
