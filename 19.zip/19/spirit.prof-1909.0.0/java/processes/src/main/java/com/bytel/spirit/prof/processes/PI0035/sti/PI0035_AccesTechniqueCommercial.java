/*
 *                                                             ___o.__
 *                                                         ,oH8888888888o._
 *                                                       dP',88888P'''`8888o.
 *   ____                                              ,8',888888      888888o
 *  |  _ \                                            d8,d888888b    ,d8888888b
 *  | |_) | ___  _   _ _   _  __ _ _   _  ___  ___   ,8PPY8888888boo8888PPPP"'`b
 *  |  _ < / _ \| | | | | | |/ _` | | | |/ _ \/ __|  d8o_                     d8
 *  | |_) | (_) | |_| | |_| | (_| | |_| |  __/\__ \' d888bo.             _ooP d8'
 *  |____/ \___/ \__,_|\__, |\__, |\__,_|\___||___/  d8888888P     ,ooo88888P d8
 *                      __/ | ___/_                  `8M8888P     ,88888888P ,8P
 *                     |___/ |__ |  _  |  _  _  _ __  Y88Y88'    ,888888888' dP
 *                               | (/_ | (/_(_ (_)|||  `8b8P    d8888888888,dP
 *                                                      Y8,   d88888888888P'
 *                                                        `Y=8888888888P'
 *                                                            `''`'''
 *
 *  Systeme $system
 *
 *  (C) Copyright Bouygues Telecom 2018.
 *
 *  Utilisation, reproduction et divulgation interdites
 *  sans autorisation ecrite de Bouygues Telecom.
 *
 *  Projet  : FTTOcmdRacco_Lot3_Rebasing1901
 *  Package : com.bytel.spirit.prof.processes.PI0035.sti
 *  Classe  : PI0035_AccesTechniqueCommercial
 *  Auteur  : sdiop
 *
 */

package com.bytel.spirit.prof.processes.PI0035.sti;

import java.io.Serializable;

import com.bytel.spirit.common.shared.saab.rpg.AccessTechniqueCommercial;
import com.squareup.moshi.Json;

/**
 *
 * @author sdiop
 * @version ($Revision$ $Date$)
 */
public class PI0035_AccesTechniqueCommercial implements Serializable
{
  /**
   *
   */
  private static final long serialVersionUID = 4004704766166251438L;

  /**
   * Creates a new instance of {@link PI0035_AccesTechniqueCommercial} from an instance of
   * {@link AccessTechniqueCommercial}
   *
   * @param accesTechniqueCommercial_p
   *          The instance of {@link AccessTechniqueCommercial}.
   * @return The created instance of {@link PI0035_AccesTechniqueCommercial};
   */
  public static PI0035_AccesTechniqueCommercial buildFromAccesTechniqueCommercial(AccessTechniqueCommercial accesTechniqueCommercial_p)
  {
    return new PI0035_AccesTechniqueCommercial(accesTechniqueCommercial_p.getTechnologieAcces(), accesTechniqueCommercial_p.getCodeAccesTechnique());
  }

  /**
   * Technologies de l'accès réseau
   */
  @Json(name = "technologieAcces")
  private String _technologieAcces;

  /**
   *
   */
  @Json(name = "codeAccesTechnique")
  private String _codeAccesTechnique;

  public PI0035_AccesTechniqueCommercial()
  {
    super();
  }

  public PI0035_AccesTechniqueCommercial(String technologieAcces_p, String codeAccesTechnique_p)
  {
    super();

    this._technologieAcces = technologieAcces_p;
    this._codeAccesTechnique = codeAccesTechnique_p;
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    PI0035_AccesTechniqueCommercial other = (PI0035_AccesTechniqueCommercial) obj;
    if (_codeAccesTechnique == null)
    {
      if (other._codeAccesTechnique != null)
      {
        return false;
      }
    }
    else if (!_codeAccesTechnique.equals(other._codeAccesTechnique))
    {
      return false;
    }
    if (_technologieAcces == null)
    {
      if (other._technologieAcces != null)
      {
        return false;
      }
    }
    else if (!_technologieAcces.equals(other._technologieAcces))
    {
      return false;
    }
    return true;
  }

  /**
   * @return _codeAccesTechnique
   */
  public String getCodeAccesTechnique()
  {
    return _codeAccesTechnique;
  }

  /**
   * @return _technologieAcces
   */
  public String getTechnologieAcces()
  {
    return _technologieAcces;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_codeAccesTechnique == null) ? 0 : _codeAccesTechnique.hashCode());
    result = (prime * result) + ((_technologieAcces == null) ? 0 : _technologieAcces.hashCode());
    return result;
  }

  /**
   * @param codeAccesTechnique_p
   *          _codeAccesTechnique
   */
  public void setCodeAccesTechnique(String codeAccesTechnique_p)
  {
    _codeAccesTechnique = codeAccesTechnique_p;
  }

  /**
   * @param technologieAcces_p
   *          _technologieAcces
   */
  public void setTechnologieAcces(String technologieAcces_p)
  {
    _technologieAcces = technologieAcces_p;
  }

  @Override
  public String toString()
  {
    StringBuilder builder = new StringBuilder();
    builder.append("PI0035_AccesTechniqueCommercial [_technologieAcces="); //$NON-NLS-1$
    builder.append(_technologieAcces);
    builder.append(", _codeAccesTechnique="); //$NON-NLS-1$
    builder.append(_codeAccesTechnique);
    builder.append("]"); //$NON-NLS-1$
    return builder.toString();
  }
}
