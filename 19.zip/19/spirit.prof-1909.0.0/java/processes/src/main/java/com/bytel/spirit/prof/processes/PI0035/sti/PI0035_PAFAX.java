/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PI0035.sti;

import java.time.LocalDateTime;

import com.bytel.spirit.common.shared.saab.rpg.PA;
import com.bytel.spirit.common.shared.saab.rpg.PaTypeFax;
import com.squareup.moshi.Json;

/**
 *
 * @author jiantila
 * @version ($Revision$ $Date$)
 */
public class PI0035_PAFAX extends PI0035_PA
{
  /**
   *
   */
  private static final long serialVersionUID = 3026152455616335445L;

  /**
   * Create a new instance of {@link PI0035_PAFAX} from an instance of PA of type {@link PaTypeFax}.
   *
   * @param pa_p
   *          The PA instance parameter.
   *
   * @return The created {@link PI0035_PAFAX} instance.
   */
  public static PI0035_PAFAX buildFromPAFAX(PA pa_p)
  {
    return new PI0035_PAFAX(pa_p.getIdentifiantFonctionnelPA(), pa_p.getStatut().name(), pa_p.getTypePA(), pa_p.getDateCreation(), pa_p.getDateModification(), pa_p.getPaTypeFax().getNumeroTelephone());
  }

  /**
   * Numéro de la ressource de type "NumeroTelephone" Correspondant dans ce cas à un numéro de téléphone fixe
   *
   */
  @Json(name = "numeroTelephone")
  private String _numeroTelephone;

  /**
   *
   */
  public PI0035_PAFAX()
  {
    super();
  }

  /**
   * @param identifiantFonctionnelPA_p
   * @param statut_p
   * @param typePA_p
   * @param dateCreation_p
   * @param dateModification_p
   * @param numeroTelephone_p
   */
  public PI0035_PAFAX(String identifiantFonctionnelPA_p, String statut_p, String typePA_p, LocalDateTime dateCreation_p, LocalDateTime dateModification_p, String numeroTelephone_p)
  {
    super(identifiantFonctionnelPA_p, statut_p, typePA_p, dateCreation_p, dateModification_p);

    _numeroTelephone = numeroTelephone_p;
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (!super.equals(obj))
    {
      return false;
    }

    if ((obj.getClass() != null) && (getClass() != obj.getClass()))
    {
      return false;
    }
    PI0035_PAFAX other = (PI0035_PAFAX) obj;
    if (_numeroTelephone == null)
    {
      if (other._numeroTelephone != null)
      {
        return false;
      }
    }
    else if (!_numeroTelephone.equals(other._numeroTelephone))
    {
      return false;
    }

    return true;
  }

  /**
   * @return the numeroTelephone
   */
  public String getNumeroTelephone()
  {
    return _numeroTelephone;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = super.hashCode();
    result = (prime * result) + ((_numeroTelephone == null) ? 0 : _numeroTelephone.hashCode());
    return result;
  }

  /**
   * @param numeroTelephone_p
   *          the numeroTelephone to set
   */
  public void setNumeroTelephone(String numeroTelephone_p)
  {
    _numeroTelephone = numeroTelephone_p;
  }

  @Override
  public String toString()
  {
    StringBuilder builder = new StringBuilder();
    builder.append("PI0035_PAFAX [_numeroTelephone=");
    builder.append(_numeroTelephone);
    builder.append(", getDateCreation()=");
    builder.append(getDateCreation());
    builder.append(", getDateModification()=");
    builder.append(getDateModification());
    builder.append(", getIdentifiantFonctionnelPA()=");
    builder.append(getIdentifiantFonctionnelPA());
    builder.append(", getIdentifiantFonctionnelPALie()=");
    builder.append(getIdentifiantFonctionnelPALie());
    builder.append(", getStatut()=");
    builder.append(getStatut());
    builder.append(", getTypePA()=");
    builder.append(getTypePA());
    builder.append("]");
    return builder.toString();
  }
}
