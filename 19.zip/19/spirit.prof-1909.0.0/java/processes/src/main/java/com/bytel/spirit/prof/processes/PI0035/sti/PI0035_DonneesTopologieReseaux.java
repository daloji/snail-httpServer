/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PI0035.sti;

import java.io.Serializable;
import java.util.Set;

import com.bytel.ravel.common.json.annotations.RavelPolymorphism;
import com.bytel.ravel.common.json.annotations.RavelPolymorphismProfil;
import com.bytel.ravel.common.json.annotations.RavelPolymorphisms;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.AbstractStPfs;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.TypePFS;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.fqdn.StPfsFqdn;
import com.bytel.spirit.common.shared.misc.ressources.SpiritConstants;
import com.bytel.spirit.common.shared.saab.res.Fqdn;
import com.bytel.spirit.common.shared.saab.rst.ServiceTechnique;
import com.squareup.moshi.Json;

/**
 *
 * @author pescudei
 * @version ($Revision$ $Date$)
 */

@RavelPolymorphisms({ @RavelPolymorphismProfil( //
    name = SpiritConstants.JSON_PROFILE_STARK, //
    type = "type", //
    value = { //
        @RavelPolymorphism(type = "FQDN", clazz = PI0035_DonneesTopologieReseauxFqdn.class) }) //
})
public class PI0035_DonneesTopologieReseaux implements Serializable
{

  /**
   * Serial ID
   */
  private static final long serialVersionUID = 5794330222643520526L;

  /**
   * Builds a new instance of {@link PI0035_DonneesTopologieReseaux} from an instance of {@link Fqdn}
   *
   * @param fqdn_p
   *          Fqdn
   * @return PI0035_DonneesTopologieReseaux
   */
  public static PI0035_DonneesTopologieReseaux buildFromFqdn(Fqdn fqdn_p)
  {
    return PI0035_DonneesTopologieReseauxFqdn.buildFromFqdn(fqdn_p);
  }

  /**
   * Builds a new instance of {@link PI0035_DonneesTopologieReseaux} from an instance of {@link ServiceTechnique}
   *
   * @param serviceTechnique_p
   *          The instance of {@link ServiceTechnique}.
   * @param statutFQDN_p
   *          Statut
   * @param listeCoeurImsDesservis_p
   *          listeCoeurImsDesservis
   *
   * @return The instance of {@link PI0035_DonneesTopologieReseaux}.
   */
  public static PI0035_DonneesTopologieReseaux buildFromServiceTechnique(ServiceTechnique serviceTechnique_p, String statutFQDN_p, Set<String> listeCoeurImsDesservis_p)
  {
    PI0035_DonneesTopologieReseaux donneesTopologieReseaux;
    TypePFS typePfs = TypePFS.valueOf(AbstractStPfs.class.cast(serviceTechnique_p).getTypePfs());
    switch (typePfs)
    {
      case FQDN:
        donneesTopologieReseaux = PI0035_DonneesTopologieReseauxFqdn.buildFromStFqdn(StPfsFqdn.class.cast(serviceTechnique_p), statutFQDN_p, listeCoeurImsDesservis_p);
        break;
      default:
        return null;
    }
    return donneesTopologieReseaux;
  }

  /**
   * Builds a new instance of {@link PI0035_DonneesTopologieReseaux} from an instance of {@link StPfsFqdn}
   *
   * @param stPfsFqdn_p
   *          The instance of {@link StPfsFqdn}.
   * @param statutFQDN_p
   *          Statut
   * @param listeCoeurImsDesservis_p
   *          listeCoeurImsDesservis
   * @return The instance of {@link PI0035_DonneesTopologieReseaux}.
   */
  public static PI0035_DonneesTopologieReseaux buildFromStPfsFqdn(StPfsFqdn stPfsFqdn_p, String statutFQDN_p, Set<String> listeCoeurImsDesservis_p)
  {
    return PI0035_DonneesTopologieReseauxFqdn.buildFromStFqdn(stPfsFqdn_p, statutFQDN_p, listeCoeurImsDesservis_p);
  }

  /**
   * Type Equipement de la Topologie Reseau
   */
  @Json(name = "type")
  private String _type;

  /**
   * Constructor
   *
   * @param type_p
   *          type
   */
  public PI0035_DonneesTopologieReseaux(String type_p)
  {
    super();
    _type = type_p;
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    PI0035_DonneesTopologieReseaux other = (PI0035_DonneesTopologieReseaux) obj;
    if (_type == null)
    {
      if (other._type != null)
      {
        return false;
      }
    }
    else if (!_type.equals(other._type))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the type
   */
  public String getType()
  {
    return _type;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_type == null) ? 0 : _type.hashCode());
    return result;
  }

  /**
   * @param type_p
   *          the type to set
   */
  public void setType(String type_p)
  {
    _type = type_p;
  }

  @Override
  public String toString()
  {
    StringBuilder builder = new StringBuilder();
    builder.append("PI0035_DonneesTopologieReseaux [_type="); //$NON-NLS-1$
    builder.append(_type);
    builder.append("]"); //$NON-NLS-1$
    return builder.toString();
  }
}
