/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PI0035.sti;

import java.io.Serializable;

import com.squareup.moshi.Json;

/**
 *
 * @author pescudei
 * @version ($Revision$ $Date$)
 */
public class PI0035_DonneesProvisionneesStPfsAcsIad implements Serializable
{
  /**
   *
   */
  private static final long serialVersionUID = -122620294503607561L;

  /**
   * Resource numeroSerie
   */
  @Json(name = "numeroSerie")
  private String _numeroSerie;

  /**
   * Resource nomFabricant
   */
  @Json(name = "nomFabricant")
  private String _nomFabricant;

  /**
   * Resource modele
   */
  @Json(name = "modele")
  private String _modele;

  /**
   * Resource codeEAN
   */
  @Json(name = "codeEAN")
  private String _codeEAN;

  /**
   * Resource adresseMacModem
   */
  @Json(name = "adresseMacModem")
  private String _adresseMacModem;

  /**
   * Resource adresseMacMta
   */
  @Json(name = "adresseMacMta")
  private String _adresseMacMta;

  /**
   * Resource adresseMacGateway
   */
  @Json(name = "adresseMacGateway")
  private String _adresseMacGateway;

  /**
   * Resource configurationIms
   */
  @Json(name = "configurationIms")
  private PI0035_DonneesImsIad _configurationIms;

  /**
   * @param numeroSerie_p
   * @param nomFabricant_p
   * @param modele_p
   * @param codeEAN_p
   * @param adresseMacModem_p
   * @param adresseMacMta_p
   * @param adresseMacGateway_p
   * @param configurationIms_p
   */
  public PI0035_DonneesProvisionneesStPfsAcsIad(String numeroSerie_p, String nomFabricant_p, String modele_p, String codeEAN_p, String adresseMacModem_p, String adresseMacMta_p, String adresseMacGateway_p, PI0035_DonneesImsIad configurationIms_p)
  {
    super();
    _numeroSerie = numeroSerie_p;
    _nomFabricant = nomFabricant_p;
    _modele = modele_p;
    _codeEAN = codeEAN_p;
    _adresseMacModem = adresseMacModem_p;
    _adresseMacMta = adresseMacMta_p;
    _adresseMacGateway = adresseMacGateway_p;
    _configurationIms = configurationIms_p;
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    PI0035_DonneesProvisionneesStPfsAcsIad other = (PI0035_DonneesProvisionneesStPfsAcsIad) obj;
    if (_adresseMacGateway == null)
    {
      if (other._adresseMacGateway != null)
      {
        return false;
      }
    }
    else if (!_adresseMacGateway.equals(other._adresseMacGateway))
    {
      return false;
    }
    if (_adresseMacModem == null)
    {
      if (other._adresseMacModem != null)
      {
        return false;
      }
    }
    else if (!_adresseMacModem.equals(other._adresseMacModem))
    {
      return false;
    }
    if (_adresseMacMta == null)
    {
      if (other._adresseMacMta != null)
      {
        return false;
      }
    }
    else if (!_adresseMacMta.equals(other._adresseMacMta))
    {
      return false;
    }
    if (_codeEAN == null)
    {
      if (other._codeEAN != null)
      {
        return false;
      }
    }
    else if (!_codeEAN.equals(other._codeEAN))
    {
      return false;
    }
    if (_configurationIms == null)
    {
      if (other._configurationIms != null)
      {
        return false;
      }
    }
    else if (!_configurationIms.equals(other._configurationIms))
    {
      return false;
    }
    if (_modele == null)
    {
      if (other._modele != null)
      {
        return false;
      }
    }
    else if (!_modele.equals(other._modele))
    {
      return false;
    }
    if (_nomFabricant == null)
    {
      if (other._nomFabricant != null)
      {
        return false;
      }
    }
    else if (!_nomFabricant.equals(other._nomFabricant))
    {
      return false;
    }
    if (_numeroSerie == null)
    {
      if (other._numeroSerie != null)
      {
        return false;
      }
    }
    else if (!_numeroSerie.equals(other._numeroSerie))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the adresseMacGateway
   */
  public String getAdresseMacGateway()
  {
    return _adresseMacGateway;
  }

  /**
   * @return the adresseMacModem
   */
  public String getAdresseMacModem()
  {
    return _adresseMacModem;
  }

  /**
   * @return the adresseMacMta
   */
  public String getAdresseMacMta()
  {
    return _adresseMacMta;
  }

  /**
   * @return the codeEAN
   */
  public String getCodeEAN()
  {
    return _codeEAN;
  }

  /**
   * @return the configurationIms
   */
  public PI0035_DonneesImsIad getConfigurationIms()
  {
    return _configurationIms;
  }

  /**
   * @return the modele
   */
  public String getModele()
  {
    return _modele;
  }

  /**
   * @return the nomFabricant
   */
  public String getNomFabricant()
  {
    return _nomFabricant;
  }

  /**
   * @return the numeroSerie
   */
  public String getNumeroSerie()
  {
    return _numeroSerie;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_adresseMacGateway == null) ? 0 : _adresseMacGateway.hashCode());
    result = (prime * result) + ((_adresseMacModem == null) ? 0 : _adresseMacModem.hashCode());
    result = (prime * result) + ((_adresseMacMta == null) ? 0 : _adresseMacMta.hashCode());
    result = (prime * result) + ((_codeEAN == null) ? 0 : _codeEAN.hashCode());
    result = (prime * result) + ((_configurationIms == null) ? 0 : _configurationIms.hashCode());
    result = (prime * result) + ((_modele == null) ? 0 : _modele.hashCode());
    result = (prime * result) + ((_nomFabricant == null) ? 0 : _nomFabricant.hashCode());
    result = (prime * result) + ((_numeroSerie == null) ? 0 : _numeroSerie.hashCode());
    return result;
  }

  /**
   * @param adresseMacGateway_p
   *          the adresseMacGateway to set
   */
  public void setAdresseMacGateway(String adresseMacGateway_p)
  {
    _adresseMacGateway = adresseMacGateway_p;
  }

  /**
   * @param adresseMacModem_p
   *          the adresseMacModem to set
   */
  public void setAdresseMacModem(String adresseMacModem_p)
  {
    _adresseMacModem = adresseMacModem_p;
  }

  /**
   * @param adresseMacMta_p
   *          the adresseMacMta to set
   */
  public void setAdresseMacMta(String adresseMacMta_p)
  {
    _adresseMacMta = adresseMacMta_p;
  }

  /**
   * @param codeEAN_p
   *          the codeEAN to set
   */
  public void setCodeEAN(String codeEAN_p)
  {
    _codeEAN = codeEAN_p;
  }

  /**
   * @param configurationIms_p
   *          the configurationIms to set
   */
  public void setConfigurationIms(PI0035_DonneesImsIad configurationIms_p)
  {
    _configurationIms = configurationIms_p;
  }

  /**
   * @param modele_p
   *          the modele to set
   */
  public void setModele(String modele_p)
  {
    _modele = modele_p;
  }

  /**
   * @param nomFabricant_p
   *          the nomFabricant to set
   */
  public void setNomFabricant(String nomFabricant_p)
  {
    _nomFabricant = nomFabricant_p;
  }

  /**
   * @param numeroSerie_p
   *          the numeroSerie to set
   */
  public void setNumeroSerie(String numeroSerie_p)
  {
    _numeroSerie = numeroSerie_p;
  }

  @Override
  public String toString()
  {
    StringBuilder builder = new StringBuilder();
    builder.append("PI0035_DonneesProvisionneesStPfsAcsIad [_numeroSerie="); //$NON-NLS-1$
    builder.append(_numeroSerie);
    builder.append(", _nomFabricant="); //$NON-NLS-1$
    builder.append(_nomFabricant);
    builder.append(", _modele="); //$NON-NLS-1$
    builder.append(_modele);
    builder.append(", _codeEAN="); //$NON-NLS-1$
    builder.append(_codeEAN);
    builder.append(", _adresseMacModem="); //$NON-NLS-1$
    builder.append(_adresseMacModem);
    builder.append(", _adresseMacMta="); //$NON-NLS-1$
    builder.append(_adresseMacMta);
    builder.append(", _adresseMacGateway="); //$NON-NLS-1$
    builder.append(_adresseMacGateway);
    builder.append(", _configurationIms="); //$NON-NLS-1$
    builder.append(_configurationIms);
    builder.append("]"); //$NON-NLS-1$
    return builder.toString();
  }
}
