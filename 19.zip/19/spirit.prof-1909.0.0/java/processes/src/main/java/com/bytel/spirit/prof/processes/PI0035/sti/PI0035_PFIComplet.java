/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PI0035.sti;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.bytel.spirit.common.shared.saab.rpg.EquipementDeclare;
import com.bytel.spirit.common.shared.saab.rpg.LienEquipementPA;
import com.bytel.spirit.common.shared.saab.rpg.LienSAPA;
import com.bytel.spirit.common.shared.saab.rpg.PA;
import com.bytel.spirit.common.shared.saab.rpg.PFI;
import com.bytel.spirit.common.shared.saab.rpg.SA;
import com.squareup.moshi.Json;

/**
 *
 * @author jiantila
 * @version ($Revision$ $Date$)
 */
public class PI0035_PFIComplet implements Serializable
{
  /**
   *
   */
  private static final long serialVersionUID = -3999727371591013648L;

  /**
   * Builds a new instance of {@link PI0035_PFIComplet} from an instance of {@link PFI}.
   *
   * @param pfi_p
   *          The instance of {@link PFI}.
   * @return The instance of {@link PI0035_PFIComplet}.
   */
  public static PI0035_PFIComplet buildFromPFI(PFI pfi_p)
  {
    //PI0035_BL100_Recuperer - Mapping of PFI
    PI0035_PFI pfiSimple = PI0035_PFI.buildFromPFI(pfi_p);
    PI0035_PFIComplet pfiComplet = new PI0035_PFIComplet(pfiSimple);

    //PI0035_BL100_Recuperer - Mapping of SA list
    List<PI0035_SA> saList = pfiComplet.getSa();
    for (SA sa : pfi_p.getSa())
    {
      PI0035_SA pfiCompletSA = PI0035_SA.buildFromSA(sa);
      saList.add(pfiCompletSA);
    }
    pfiComplet.setSa(saList);

    //PI0035_BL100_Recuperer - Mapping of PA list
    List<PI0035_PA> paList = pfiComplet.getPa();
    for (PA pa : pfi_p.getPa())
    {
      PI0035_PA pfiCompletPA = PI0035_PA.buildFromPA(pa);
      paList.add(pfiCompletPA);
    }
    pfiComplet.setPa(paList);

    //PI0035_BL100_Recuperer - Mapping of Equipement Déclarés
    List<PI0035_EquipementDeclare> eqtDeclareList = pfiComplet.getEqtDeclare();
    for (EquipementDeclare eqtDeclare : pfi_p.getEquipementDeclare())
    {
      PI0035_EquipementDeclare pfiCompletEqtDeclare = PI0035_EquipementDeclare.buildFromEquipementDeclare(eqtDeclare);
      eqtDeclareList.add(pfiCompletEqtDeclare);
    }
    pfiComplet.setEqtDeclare(eqtDeclareList);

    //PI0035_BL100_Recuperer - Mapping of LienSAPA
    List<PI0035_LienSaPa> lienSaPaList = pfiComplet.getLienSaPa();
    for (LienSAPA lienSAPA : pfi_p.getLienSAPA())
    {
      PI0035_LienSaPa pfiCompletLienSapa = PI0035_LienSaPa.buildFromLienSAPA(lienSAPA);
      lienSaPaList.add(pfiCompletLienSapa);
    }
    pfiComplet.setLienSaPa(lienSaPaList);

    //PI0035_BL100_Recuperer - Mapping of LienEqtPA
    List<PI0035_LienEqtPa> lienEqtPaList = pfiComplet.getLienEqtPa();
    for (LienEquipementPA lienEqtPA : pfi_p.getLienEquipementPA())
    {
      PI0035_LienEqtPa pfiCompletLienEqtPa = PI0035_LienEqtPa.buildFromLienEqtPA(lienEqtPA);
      lienEqtPaList.add(pfiCompletLienEqtPa);
    }
    pfiComplet.setLienEqtPa(lienEqtPaList);

    return pfiComplet;
  }

  /**
   * Portefeuille individuel
   */
  @Json(name = "pfi")
  private PI0035_PFI _pfi;

  /**
   * Liste des SA
   */
  @Json(name = "sa")
  private List<PI0035_SA> _sa;

  /**
   * Liste des PA
   */
  @Json(name = "pa")
  private List<PI0035_PA> _pa;

  /**
   * Liste des liens SA-PA
   */
  @Json(name = "lienSaPa")
  private List<PI0035_LienSaPa> _lienSaPa;

  /**
   * Liste des Equipements déclarés
   */
  @Json(name = "eqtDeclare")
  private List<PI0035_EquipementDeclare> _eqtDeclare;

  /**
   * Liste des liens Eqt-PA
   */
  @Json(name = "lienEqtPa")
  private List<PI0035_LienEqtPa> _lienEqtPa;

  /**
   * Liste des modifications commerciales
   */
  @Json(name = "modificationCommerciale")
  private List<PI0035_ModificationCommerciale> _modificationCommerciale;

  /**
   * Liste des modifications techniques
   */
  @Json(name = "modificationTechnique")
  private List<PI0035_ModificationTechnique> _modificationTechnique;

  /**
   * Liste des Services Techniques
   */
  @Json(name = "st")
  private List<PI0035_ServiceTechnique> _st;

  /**
   * Liste des Services Techniques Legacy
   */
  @Json(name = "stLegacy")
  private List<PI0035_ServiceTechniqueLegacy> _stLegacy;

  /**
   * Liste des Donnes Topologie Reseaux
   */
  @Json(name = "donneesTopologieReseaux")
  private List<PI0035_DonneesTopologieReseaux> _donneesTopologieReseaux;

  /**
   * Liste des ressources allouées
   */
  @Json(name = "ressource")
  private List<PI0035_Ressource> _ressource;

  /**
   * Liste Index de recherche contenant des clés de recherche
   */
  @Json(name = "indexRecherche")
  private List<PI0035_IndexRecherche> _indexRecherche;

  /**
   *
   */
  public PI0035_PFIComplet()
  {
    super();
  }

  /**
   * @param pfi_p
   */
  public PI0035_PFIComplet(PI0035_PFI pfi_p)
  {
    super();

    _pfi = pfi_p;
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    PI0035_PFIComplet other = (PI0035_PFIComplet) obj;
    if (_donneesTopologieReseaux == null)
    {
      if (other._donneesTopologieReseaux != null)
      {
        return false;
      }
    }
    else if (!_donneesTopologieReseaux.equals(other._donneesTopologieReseaux))
    {
      return false;
    }
    if (_eqtDeclare == null)
    {
      if (other._eqtDeclare != null)
      {
        return false;
      }
    }
    else if (!_eqtDeclare.equals(other._eqtDeclare))
    {
      return false;
    }
    if (_indexRecherche == null)
    {
      if (other._indexRecherche != null)
      {
        return false;
      }
    }
    else if (!_indexRecherche.equals(other._indexRecherche))
    {
      return false;
    }
    if (_lienEqtPa == null)
    {
      if (other._lienEqtPa != null)
      {
        return false;
      }
    }
    else if (!_lienEqtPa.equals(other._lienEqtPa))
    {
      return false;
    }
    if (_lienSaPa == null)
    {
      if (other._lienSaPa != null)
      {
        return false;
      }
    }
    else if (!_lienSaPa.equals(other._lienSaPa))
    {
      return false;
    }
    if (_modificationCommerciale == null)
    {
      if (other._modificationCommerciale != null)
      {
        return false;
      }
    }
    else if (!_modificationCommerciale.equals(other._modificationCommerciale))
    {
      return false;
    }
    if (_modificationTechnique == null)
    {
      if (other._modificationTechnique != null)
      {
        return false;
      }
    }
    else if (!_modificationTechnique.equals(other._modificationTechnique))
    {
      return false;
    }
    if (_pa == null)
    {
      if (other._pa != null)
      {
        return false;
      }
    }
    else if (!_pa.equals(other._pa))
    {
      return false;
    }
    if (_pfi == null)
    {
      if (other._pfi != null)
      {
        return false;
      }
    }
    else if (!_pfi.equals(other._pfi))
    {
      return false;
    }
    if (_ressource == null)
    {
      if (other._ressource != null)
      {
        return false;
      }
    }
    else if (!_ressource.equals(other._ressource))
    {
      return false;
    }
    if (_sa == null)
    {
      if (other._sa != null)
      {
        return false;
      }
    }
    else if (!_sa.equals(other._sa))
    {
      return false;
    }
    if (_st == null)
    {
      if (other._st != null)
      {
        return false;
      }
    }
    else if (!_st.equals(other._st))
    {
      return false;
    }
    if (_stLegacy == null)
    {
      if (other._stLegacy != null)
      {
        return false;
      }
    }
    else if (!_stLegacy.equals(other._stLegacy))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the donneesTopologieReseaux
   */
  public List<PI0035_DonneesTopologieReseaux> getDonneesTopologieReseaux()
  {
    return _donneesTopologieReseaux != null ? new ArrayList<>(_donneesTopologieReseaux) : new ArrayList<>();
  }

  /**
   * @return the eqtDeclare
   */
  public List<PI0035_EquipementDeclare> getEqtDeclare()
  {
    return _eqtDeclare != null ? new ArrayList<>(_eqtDeclare) : new ArrayList<>();
  }

  /**
   * @return the indexRecherche
   */
  public List<PI0035_IndexRecherche> getIndexRecherche()
  {
    return _indexRecherche != null ? new ArrayList<>(_indexRecherche) : new ArrayList<>();
  }

  /**
   * @return the lienEqtPa
   */
  public List<PI0035_LienEqtPa> getLienEqtPa()
  {
    return _lienEqtPa != null ? new ArrayList<>(_lienEqtPa) : new ArrayList<>();
  }

  /**
   * @return the lienSaPa
   */
  public List<PI0035_LienSaPa> getLienSaPa()
  {
    return _lienSaPa != null ? new ArrayList<>(_lienSaPa) : new ArrayList<>();
  }

  /**
   * @return the modificationCommerciale
   */
  public List<PI0035_ModificationCommerciale> getModificationCommerciale()
  {
    return _modificationCommerciale != null ? new ArrayList<>(_modificationCommerciale) : new ArrayList<>();
  }

  /**
   * @return the modificationTechnique
   */
  public List<PI0035_ModificationTechnique> getModificationTechnique()
  {
    return _modificationTechnique != null ? new ArrayList<>(_modificationTechnique) : new ArrayList<>();
  }

  /**
   * @return the pa
   */
  public List<PI0035_PA> getPa()
  {
    return _pa != null ? new ArrayList<>(_pa) : new ArrayList<>();
  }

  /**
   * @return the pfi
   */
  public PI0035_PFI getPfi()
  {
    return _pfi;
  }

  /**
   * @return the ressource
   */
  public List<PI0035_Ressource> getRessource()
  {
    return _ressource != null ? new ArrayList<>(_ressource) : new ArrayList<>();
  }

  /**
   * @return the sa
   */
  public List<PI0035_SA> getSa()
  {
    return _sa != null ? new ArrayList<>(_sa) : new ArrayList<>();
  }

  /**
   * @return the st
   */
  public List<PI0035_ServiceTechnique> getSt()
  {
    return _st != null ? new ArrayList<>(_st) : new ArrayList<>();
  }

  /**
   * @return the stLegacy
   */
  public List<PI0035_ServiceTechniqueLegacy> getStLegacy()
  {
    return _stLegacy != null ? new ArrayList<>(_stLegacy) : new ArrayList<>();
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_donneesTopologieReseaux == null) ? 0 : _donneesTopologieReseaux.hashCode());
    result = (prime * result) + ((_eqtDeclare == null) ? 0 : _eqtDeclare.hashCode());
    result = (prime * result) + ((_indexRecherche == null) ? 0 : _indexRecherche.hashCode());
    result = (prime * result) + ((_lienEqtPa == null) ? 0 : _lienEqtPa.hashCode());
    result = (prime * result) + ((_lienSaPa == null) ? 0 : _lienSaPa.hashCode());
    result = (prime * result) + ((_modificationCommerciale == null) ? 0 : _modificationCommerciale.hashCode());
    result = (prime * result) + ((_modificationTechnique == null) ? 0 : _modificationTechnique.hashCode());
    result = (prime * result) + ((_pa == null) ? 0 : _pa.hashCode());
    result = (prime * result) + ((_pfi == null) ? 0 : _pfi.hashCode());
    result = (prime * result) + ((_ressource == null) ? 0 : _ressource.hashCode());
    result = (prime * result) + ((_sa == null) ? 0 : _sa.hashCode());
    result = (prime * result) + ((_st == null) ? 0 : _st.hashCode());
    result = (prime * result) + ((_stLegacy == null) ? 0 : _stLegacy.hashCode());
    return result;
  }

  /**
   * @param donneesTopologieReseaux_p
   *          the donneesTopologieReseaux to set
   */
  public void setDonneesTopologieReseaux(List<PI0035_DonneesTopologieReseaux> donneesTopologieReseaux_p)
  {
    _donneesTopologieReseaux = donneesTopologieReseaux_p != null ? new ArrayList<>(donneesTopologieReseaux_p) : new ArrayList<>();
  }

  /**
   * @param eqtDeclare_p
   *          the eqtDeclare to set
   */
  public void setEqtDeclare(List<PI0035_EquipementDeclare> eqtDeclare_p)
  {
    _eqtDeclare = eqtDeclare_p != null ? new ArrayList<>(eqtDeclare_p) : new ArrayList<>();
  }

  /**
   * @param indexRecherche_p
   *          the indexRecherche to set
   */
  public void setIndexRecherche(List<PI0035_IndexRecherche> indexRecherche_p)
  {
    _indexRecherche = indexRecherche_p != null ? new ArrayList<>(indexRecherche_p) : new ArrayList<>();
  }

  /**
   * @param lienEqtPa_p
   *          the lienEqtPa to set
   */
  public void setLienEqtPa(List<PI0035_LienEqtPa> lienEqtPa_p)
  {
    _lienEqtPa = lienEqtPa_p != null ? new ArrayList<>(lienEqtPa_p) : new ArrayList<>();
  }

  /**
   * @param lienSaPa_p
   *          the lienSaPa to set
   */
  public void setLienSaPa(List<PI0035_LienSaPa> lienSaPa_p)
  {
    _lienSaPa = lienSaPa_p != null ? new ArrayList<>(lienSaPa_p) : new ArrayList<>();
  }

  /**
   * @param modificationCommerciale_p
   *          the modificationCommerciale to set
   */
  public void setModificationCommerciale(List<PI0035_ModificationCommerciale> modificationCommerciale_p)
  {
    _modificationCommerciale = modificationCommerciale_p != null ? new ArrayList<>(modificationCommerciale_p) : new ArrayList<>();
  }

  /**
   * @param modificationTechnique_p
   *          the modificationTechnique to set
   */
  public void setModificationTechnique(List<PI0035_ModificationTechnique> modificationTechnique_p)
  {
    _modificationTechnique = modificationTechnique_p != null ? new ArrayList<>(modificationTechnique_p) : new ArrayList<>();
  }

  /**
   * @param pa_p
   *          the pa to set
   */
  public void setPa(List<PI0035_PA> pa_p)
  {
    _pa = pa_p != null ? new ArrayList<>(pa_p) : new ArrayList<>();
  }

  /**
   * @param pfi_p
   *          the pfi to set
   */
  public void setPfi(PI0035_PFI pfi_p)
  {
    _pfi = pfi_p;
  }

  /**
   * @param ressource_p
   *          the ressource to set
   */
  public void setRessource(List<PI0035_Ressource> ressource_p)
  {
    _ressource = ressource_p != null ? new ArrayList<>(ressource_p) : new ArrayList<>();
  }

  /**
   * @param sa_p
   *          the sa to set
   */
  public void setSa(List<PI0035_SA> sa_p)
  {
    _sa = sa_p != null ? new ArrayList<>(sa_p) : new ArrayList<>();
  }

  /**
   * @param st_p
   *          the st to set
   */
  public void setSt(List<PI0035_ServiceTechnique> st_p)
  {
    _st = st_p != null ? new ArrayList<>(st_p) : new ArrayList<>();
  }

  /**
   * @param stLegacy_p
   *          the stLegacy to set
   */
  public void setStLegacy(List<PI0035_ServiceTechniqueLegacy> stLegacy_p)
  {
    _stLegacy = stLegacy_p != null ? new ArrayList<>(stLegacy_p) : new ArrayList<>();
  }

  @Override
  public String toString()
  {
    StringBuilder builder = new StringBuilder();
    builder.append("PI0035_PFIComplet [_pfi="); //$NON-NLS-1$
    builder.append(_pfi);
    builder.append(", _sa="); //$NON-NLS-1$
    builder.append(_sa);
    builder.append(", _pa="); //$NON-NLS-1$
    builder.append(_pa);
    builder.append(", _lienSaPa="); //$NON-NLS-1$
    builder.append(_lienSaPa);
    builder.append(", _eqtDeclare="); //$NON-NLS-1$
    builder.append(_eqtDeclare);
    builder.append(", _lienEqtPa="); //$NON-NLS-1$
    builder.append(_lienEqtPa);
    builder.append(", _modificationCommerciale="); //$NON-NLS-1$
    builder.append(_modificationCommerciale);
    builder.append(", _modificationTechnique="); //$NON-NLS-1$
    builder.append(_modificationTechnique);
    builder.append(", _st="); //$NON-NLS-1$
    builder.append(_st);
    builder.append(", _stLegacy="); //$NON-NLS-1$
    builder.append(_stLegacy);
    builder.append(", _donneesTopologieReseaux="); //$NON-NLS-1$
    builder.append(_donneesTopologieReseaux);
    builder.append(", _ressource="); //$NON-NLS-1$
    builder.append(_ressource);
    builder.append(", _indexRecherche="); //$NON-NLS-1$
    builder.append(_indexRecherche);
    builder.append("]"); //$NON-NLS-1$
    return builder.toString();
  }
}
