/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PI0035.sti;

import com.bytel.spirit.common.shared.functional.types.json.st.pfs.IDonneesProvisionnees;
import com.squareup.moshi.Json;

/**
 *
 * @author jgregori
 * @version ($Revision$ $Date$)
 */
public class PI0035_DonneesProvisionneesSTPfsOlt implements IDonneesProvisionnees
{
  /**
   *
   */
  private static final long serialVersionUID = 6932012713945472441L;

  /**
   * Code of provisioned technical access
   */
  @Json(name = "codeAccesTechnique")
  private String _codeAccesTechnique;

  /**
   * Access VLAN to the Bytel Backbone
   */
  @Json(name = "vlan")
  private String _vlan;

  /**
   * ONT serial number
   */
  @Json(name = "snOnt")
  private String _snOnt;

  /**
   * @param codeAccesTechnique_p
   * @param vlan_p
   * @param snOnt_p
   */
  public PI0035_DonneesProvisionneesSTPfsOlt(String codeAccesTechnique_p, String vlan_p, final String snOnt_p)
  {
    super();
    _codeAccesTechnique = codeAccesTechnique_p;
    _vlan = vlan_p;
    _snOnt = snOnt_p;
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    PI0035_DonneesProvisionneesSTPfsOlt other = (PI0035_DonneesProvisionneesSTPfsOlt) obj;
    if (_codeAccesTechnique == null)
    {
      if (other._codeAccesTechnique != null)
      {
        return false;
      }
    }
    else if (!_codeAccesTechnique.equals(other._codeAccesTechnique))
    {
      return false;
    }
    if (_vlan == null)
    {
      if (other._vlan != null)
      {
        return false;
      }
    }
    else if (!_vlan.equals(other._vlan))
    {
      return false;
    }
    if (_snOnt == null)
    {
      if (other._snOnt != null)
      {
        return false;
      }
    }
    else if (!_snOnt.equals(other._snOnt))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the codeAccesTechnique
   */
  public String getCodeAccesTechnique()
  {
    return _codeAccesTechnique;
  }

  /**
   * @return the snOnt
   */
  public String getSnOnt()
  {
    return _snOnt;
  }

  /**
   * @return the vlan
   */
  public String getVlan()
  {
    return _vlan;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_codeAccesTechnique == null) ? 0 : _codeAccesTechnique.hashCode());
    result = (prime * result) + ((_vlan == null) ? 0 : _vlan.hashCode());
    result = (prime * result) + ((_snOnt == null) ? 0 : _snOnt.hashCode());
    return result;
  }

  /**
   * @param codeAccesTechnique_p
   *          the codeAccesTechnique to set
   */
  public void setCodeAccesTechnique(String codeAccesTechnique_p)
  {
    _codeAccesTechnique = codeAccesTechnique_p;
  }

  /**
   * @param snOnt_p
   *          the snOnt to set
   */
  public void setSnOnt(String snOnt_p)
  {
    _snOnt = snOnt_p;
  }

  /**
   * @param vlan_p
   *          the vlan to set
   */
  public void setVlan(String vlan_p)
  {
    _vlan = vlan_p;
  }

  @Override
  public String toString()
  {
    StringBuilder builder = new StringBuilder();
    builder.append("PI0035_DonneesProvisionneesSTPfsOlt [_codeAccesTechnique="); //$NON-NLS-1$
    builder.append(_codeAccesTechnique);
    builder.append(", _vlan="); //$NON-NLS-1$
    builder.append(_vlan);
    builder.append(", _snOnt="); //$NON-NLS-1$
    builder.append(_snOnt);
    builder.append("]"); //$NON-NLS-1$
    return builder.toString();
  }
}
