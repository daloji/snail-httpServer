/*
 *                                                             ___o.__
 *                                                         ,oH8888888888o._
 *                                                       dP',88888P'''`8888o.
 *   ____                                              ,8',888888      888888o
 *  |  _ \                                            d8,d888888b    ,d8888888b
 *  | |_) | ___  _   _ _   _  __ _ _   _  ___  ___   ,8PPY8888888boo8888PPPP"'`b
 *  |  _ < / _ \| | | | | | |/ _` | | | |/ _ \/ __|  d8o_                     d8
 *  | |_) | (_) | |_| | |_| | (_| | |_| |  __/\__ \' d888bo.             _ooP d8'
 *  |____/ \___/ \__,_|\__, |\__, |\__,_|\___||___/  d8888888P     ,ooo88888P d8
 *                      __/ | ___/_                  `8M8888P     ,88888888P ,8P
 *                     |___/ |__ |  _  |  _  _  _ __  Y88Y88'    ,888888888' dP
 *                               | (/_ | (/_(_ (_)|||  `8b8P    d8888888888,dP
 *                                                      Y8,   d88888888888P'
 *                                                        `Y=8888888888P'
 *                                                            `''`'''
 *
 *  Systeme $system
 *
 *  (C) Copyright Bouygues Telecom 2018.
 *
 *  Utilisation, reproduction et divulgation interdites
 *  sans autorisation ecrite de Bouygues Telecom.
 *
 *  Projet  : FTTOcmdRacco_Lot3_Rebasing1901
 *  Package : com.bytel.spirit.prof.processes.PI0035.sti
 *  Classe  : PI0035_RessourceRaccordement
 *  Auteur  : sdiop
 *
 */

package com.bytel.spirit.prof.processes.PI0035.sti;

import java.time.LocalDateTime;

import com.bytel.ravel.common.json.annotations.RavelPolymorphism;
import com.bytel.ravel.common.json.annotations.RavelPolymorphismProfil;
import com.bytel.ravel.common.json.annotations.RavelPolymorphisms;
import com.bytel.spirit.common.shared.misc.ressources.SpiritConstants;
import com.bytel.spirit.common.shared.saab.res.Ressource;
import com.squareup.moshi.Json;

/**
 *
 * @author sdiop
 * @version ($Revision$ $Date$)
 */
@RavelPolymorphisms({ //
    @RavelPolymorphismProfil( //
        name = SpiritConstants.JSON_PROFILE_STARK, //
        type = "typeRaccordement", //
        defaultClass = PI0035_RessourceRaccordement.class, //
        value = { //
            @RavelPolymorphism(type = "P2P", clazz = PI0035_RessourceRaccordementP2P.class), //
        }) //
})
public class PI0035_RessourceRaccordement extends PI0035_Ressource
{
  /**
   *
   */
  private static final long serialVersionUID = 9060381578256446394L;

  /**
   * Creates a new instance of {@link PI0035_RessourceRaccordement} from an instance of {@link Ressource} with
   * getTypeRessource 'RACCO'
   *
   * @param ressource_p
   *          The instance of {@link Ressource}.
   * @return The created instance of {@link PI0035_RessourceRaccordement};
   */
  public static PI0035_RessourceRaccordement buildFromRessource(Ressource ressource_p)
  {
    PI0035_RessourceRaccordement ressourceRaccordement = new PI0035_RessourceRaccordement(ressource_p.getIdRessource(), ressource_p.getTypeRessource(), ressource_p.getStatut(), ressource_p.getIdSt(), ressource_p.getDateCreation(), ressource_p.getDateModification());
    if (null != ressource_p.getRessourceRaccordement())
    {
      ressourceRaccordement.setTypeRaccordement(ressource_p.getRessourceRaccordement().getTypeRaccordement());
      ressourceRaccordement.setNomNR(ressource_p.getRessourceRaccordement().getNomNR());
      ressourceRaccordement.setAdresseDonnee(PI0035_AdresseDonnee.buildFromAdresseDonnee(ressource_p.getRessourceRaccordement().getAdresseDonnee()));
      ressourceRaccordement.setIdRessourceLie(ressource_p.getIdRessourceLie());
    }
    return ressourceRaccordement;
  }

  /**
   * Indique le type de techno du raccordement
   */
  @Json(name = "typeRaccordement")
  private String _typeRaccordement;

  /**
   * Adresse du raccordement
   */
  @Json(name = "adresseDonnee")
  private PI0035_AdresseDonnee _adresseDonnee;

  /**
   * En xDSL : Utile uniquement pour passer la commande de construction pour AXIONE_ENT ; sa validité n’est valable que
   * lors du passage de commande (cf. un nom NRA orange peut changer)
   *
   * En P2P : Obligatoire
   */
  @Json(name = "nomNR")
  private String _nomNR;

  /**
   * Identifiant de la Ressource Raccordement recyclé
   */
  @Json(name = "idRessourceLie")
  private String _idRessourceLie;

  /**
   * Acces Technique provisionné
   */
  @Json(name = "accesTechnique")
  private PI0035_AccesTechnique _accesTechnique;

  /**
   * Default contructor
   */
  public PI0035_RessourceRaccordement()
  {
    super();
  }

  /**
   * Constructor
   *
   * @param idRessource_p
   * @param typeRessource_p
   * @param statut_p
   * @param idST_p
   * @param dateCreation_p
   * @param dateModification_p
   */
  public PI0035_RessourceRaccordement(String idRessource_p, String typeRessource_p, String statut_p, String idST_p, LocalDateTime dateCreation_p, LocalDateTime dateModification_p)
  {
    super(idRessource_p, typeRessource_p, statut_p, idST_p, dateCreation_p, dateModification_p);
  }

  /**
   * Constructor
   * 
   * @param idRessource_p
   * @param typeRessource_p
   * @param statut_p
   * @param idST_p
   * @param dateCreation_p
   * @param dateModification_p
   * @param typeRaccordement_p
   * @param adresseDonnee_p
   * @param nomNR_p
   * @param idRessourceLie_p
   * @param accesTechnique_p
   */
  public PI0035_RessourceRaccordement(String idRessource_p, String typeRessource_p, String statut_p, String idST_p, LocalDateTime dateCreation_p, LocalDateTime dateModification_p, String typeRaccordement_p, PI0035_AdresseDonnee adresseDonnee_p, String nomNR_p, String idRessourceLie_p, PI0035_AccesTechnique accesTechnique_p)
  {
    super(idRessource_p, typeRessource_p, statut_p, idST_p, dateCreation_p, dateModification_p);

    _typeRaccordement = typeRaccordement_p;
    _adresseDonnee = adresseDonnee_p;
    _nomNR = nomNR_p;
    _idRessourceLie = idRessourceLie_p;
    _accesTechnique = accesTechnique_p;
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (!super.equals(obj))
    {
      return false;
    }
    if (getClass() != obj.getClass()) // NOSONAR
    {
      return false;
    }
    PI0035_RessourceRaccordement other = (PI0035_RessourceRaccordement) obj;
    if (_accesTechnique == null)
    {
      if (other._accesTechnique != null)
      {
        return false;
      }
    }
    else if (!_accesTechnique.equals(other._accesTechnique))
    {
      return false;
    }
    if (_adresseDonnee == null)
    {
      if (other._adresseDonnee != null)
      {
        return false;
      }
    }
    else if (!_adresseDonnee.equals(other._adresseDonnee))
    {
      return false;
    }
    if (_idRessourceLie == null)
    {
      if (other._idRessourceLie != null)
      {
        return false;
      }
    }
    else if (!_idRessourceLie.equals(other._idRessourceLie))
    {
      return false;
    }
    if (_nomNR == null)
    {
      if (other._nomNR != null)
      {
        return false;
      }
    }
    else if (!_nomNR.equals(other._nomNR))
    {
      return false;
    }
    if (_typeRaccordement == null)
    {
      if (other._typeRaccordement != null)
      {
        return false;
      }
    }
    else if (!_typeRaccordement.equals(other._typeRaccordement))
    {
      return false;
    }
    return true;
  }

  /**
   * @return _accesTechnique
   */
  public PI0035_AccesTechnique getAccesTechnique()
  {
    return _accesTechnique;
  }

  /**
   * @return _adresseDonnee
   */
  public PI0035_AdresseDonnee getAdresseDonnee()
  {
    return _adresseDonnee;
  }

  /**
   * @return _idRessourceLie
   */
  public String getIdRessourceLie()
  {
    return _idRessourceLie;
  }

  /**
   * @return _nomNR
   */
  public String getNomNR()
  {
    return _nomNR;
  }

  /**
   * @return _typeRaccordement
   */
  public String getTypeRaccordement()
  {
    return _typeRaccordement;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = super.hashCode();
    result = (prime * result) + ((_accesTechnique == null) ? 0 : _accesTechnique.hashCode());
    result = (prime * result) + ((_adresseDonnee == null) ? 0 : _adresseDonnee.hashCode());
    result = (prime * result) + ((_idRessourceLie == null) ? 0 : _idRessourceLie.hashCode());
    result = (prime * result) + ((_nomNR == null) ? 0 : _nomNR.hashCode());
    result = (prime * result) + ((_typeRaccordement == null) ? 0 : _typeRaccordement.hashCode());
    return result;
  }

  /**
   * @param accesTechnique_p
   *          _accesTechnique
   */
  public void setAccesTechnique(PI0035_AccesTechnique accesTechnique_p)
  {
    _accesTechnique = accesTechnique_p;
  }

  /**
   * @param adresseDonnee_p
   *          _adresseDonnee
   */
  public void setAdresseDonnee(PI0035_AdresseDonnee adresseDonnee_p)
  {
    _adresseDonnee = adresseDonnee_p;
  }

  /**
   * @param idRessourceLie_p
   *          _idRessourceLie
   */
  public void setIdRessourceLie(String idRessourceLie_p)
  {
    _idRessourceLie = idRessourceLie_p;
  }

  /**
   * @param nomNR_p
   *          _nomNR
   */
  public void setNomNR(String nomNR_p)
  {
    _nomNR = nomNR_p;
  }

  /**
   * @param typeRaccordement_p
   *          _typeRaccordement
   */
  public void setTypeRaccordement(String typeRaccordement_p)
  {
    _typeRaccordement = typeRaccordement_p;
  }

  @Override
  public String toString()
  {
    StringBuilder builder = new StringBuilder();
    builder.append("PI0035_RessourceRaccordement [_typeRaccordement="); //$NON-NLS-1$
    builder.append(_typeRaccordement);
    builder.append(", _adresseDonnee="); //$NON-NLS-1$
    builder.append(_adresseDonnee);
    builder.append(", _nomNR="); //$NON-NLS-1$
    builder.append(_nomNR);
    builder.append(", _idRessourceRecycle="); //$NON-NLS-1$
    builder.append(_idRessourceLie);
    builder.append(", _accesTechnique="); //$NON-NLS-1$
    builder.append(_accesTechnique);
    builder.append(", getDateCreation()="); //$NON-NLS-1$
    builder.append(getDateCreation());
    builder.append(", getDateModification()="); //$NON-NLS-1$
    builder.append(getDateModification());
    builder.append(", getIdRessource()="); //$NON-NLS-1$
    builder.append(getIdRessource());
    builder.append(", getIdST()="); //$NON-NLS-1$
    builder.append(getIdST());
    builder.append(", getStatut()="); //$NON-NLS-1$
    builder.append(getStatut());
    builder.append(", getTypeRessource()="); //$NON-NLS-1$
    builder.append(getTypeRessource());
    builder.append("]"); //$NON-NLS-1$
    return builder.toString();
  }
}
