/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PI0035.sti;

import java.io.Serializable;
import java.time.LocalDateTime;

import com.bytel.ravel.common.json.annotations.RavelLocalDateTimeFormat;
import com.bytel.ravel.common.json.format.impl.IsoShortOffsetDateTimeWithMillis;
import com.bytel.spirit.common.shared.saab.rpg.PFI;
import com.squareup.moshi.Json;

/**
 *
 * @author jiantila
 * @version ($Revision$ $Date$)
 */
public class PI0035_PFI implements Serializable
{
  /**
   *
   */
  private static final long serialVersionUID = -7127822414745092568L;

  /**
   * Builds a new instance of {@link PI0035_PFI} from an instance of {@link PFI}.
   *
   * @param pfi_p
   *          The PFI instance parameter.
   * @return The created PFISimple instance.
   */
  public static PI0035_PFI buildFromPFI(PFI pfi_p)
  {

    PI0035_Titulaire titulaire = PI0035_Titulaire.buildFromTitulaire(pfi_p.getTitulaire()); // Map PFI.Titulaire into PFISimple.Titulaire

    return new PI0035_PFI(pfi_p.getClientOperateur(), pfi_p.getNoCompte(), pfi_p.getStatut().name(), pfi_p.getLigneMarche(), titulaire, pfi_p.getDateCreation(), pfi_p.getDateModification());

  }

  /**
   * client operateur
   */
  @Json(name = "clientOperateur")
  private String _clientOperateur;

  /**
   * no compte
   */
  @Json(name = "noCompte")
  private String _noCompte;

  /**
   * statut
   */
  @Json(name = "statut")
  private String _statut;

  /**
   * ligne marche
   */
  @Json(name = "ligneMarche")
  private String _ligneMarche;

  /**
   * Titulaire
   */
  @Json(name = "titulaire")
  private PI0035_Titulaire _titulaire;

  /**
   * Date de creation
   */
  @Json(name = "dateCreation")
  @RavelLocalDateTimeFormat(IsoShortOffsetDateTimeWithMillis.class)
  private LocalDateTime _dateCreation;

  /**
   * Date de Modification
   */
  @Json(name = "dateModification")
  @RavelLocalDateTimeFormat(IsoShortOffsetDateTimeWithMillis.class)
  private LocalDateTime _dateModification;

  /**
   *
   */
  public PI0035_PFI()
  {
    super();
  }

  /**
   * @param clientOperateur_p
   * @param noCompte_p
   * @param statut_p
   * @param ligneMarche_p
   * @param titulaire_p
   * @param dateCreation_p
   * @param dateModification_p
   */
  public PI0035_PFI(String clientOperateur_p, String noCompte_p, String statut_p, String ligneMarche_p, PI0035_Titulaire titulaire_p, LocalDateTime dateCreation_p, LocalDateTime dateModification_p)
  {
    super();
    _clientOperateur = clientOperateur_p;
    _noCompte = noCompte_p;
    _statut = statut_p;
    _ligneMarche = ligneMarche_p;
    _titulaire = titulaire_p;
    _dateCreation = dateCreation_p;
    _dateModification = dateModification_p;
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    PI0035_PFI other = (PI0035_PFI) obj;
    if (_clientOperateur == null)
    {
      if (other._clientOperateur != null)
      {
        return false;
      }
    }
    else if (!_clientOperateur.equals(other._clientOperateur))
    {
      return false;
    }
    if (_dateCreation == null)
    {
      if (other._dateCreation != null)
      {
        return false;
      }
    }
    else if (!_dateCreation.equals(other._dateCreation))
    {
      return false;
    }
    if (_dateModification == null)
    {
      if (other._dateModification != null)
      {
        return false;
      }
    }
    else if (!_dateModification.equals(other._dateModification))
    {
      return false;
    }
    if (_ligneMarche == null)
    {
      if (other._ligneMarche != null)
      {
        return false;
      }
    }
    else if (!_ligneMarche.equals(other._ligneMarche))
    {
      return false;
    }
    if (_noCompte == null)
    {
      if (other._noCompte != null)
      {
        return false;
      }
    }
    else if (!_noCompte.equals(other._noCompte))
    {
      return false;
    }
    if (_statut == null)
    {
      if (other._statut != null)
      {
        return false;
      }
    }
    else if (!_statut.equals(other._statut))
    {
      return false;
    }
    if (_titulaire == null)
    {
      if (other._titulaire != null)
      {
        return false;
      }
    }
    else if (!_titulaire.equals(other._titulaire))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the clientOperateur
   */
  public String getClientOperateur()
  {
    return _clientOperateur;
  }

  /**
   * @return the dateCreation
   */
  public LocalDateTime getDateCreation()
  {
    return _dateCreation;
  }

  /**
   * @return the dateModification
   */
  public LocalDateTime getDateModification()
  {
    return _dateModification;
  }

  /**
   * @return the ligneMarche
   */
  public String getLigneMarche()
  {
    return _ligneMarche;
  }

  /**
   * @return the noCompte
   */
  public String getNoCompte()
  {
    return _noCompte;
  }

  /**
   * @return the statut
   */
  public String getStatut()
  {
    return _statut;
  }

  /**
   * @return the titulaire
   */
  public PI0035_Titulaire getTitulaire()
  {
    return _titulaire;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_clientOperateur == null) ? 0 : _clientOperateur.hashCode());
    result = (prime * result) + ((_dateCreation == null) ? 0 : _dateCreation.hashCode());
    result = (prime * result) + ((_dateModification == null) ? 0 : _dateModification.hashCode());
    result = (prime * result) + ((_ligneMarche == null) ? 0 : _ligneMarche.hashCode());
    result = (prime * result) + ((_noCompte == null) ? 0 : _noCompte.hashCode());
    result = (prime * result) + ((_statut == null) ? 0 : _statut.hashCode());
    result = (prime * result) + ((_titulaire == null) ? 0 : _titulaire.hashCode());
    return result;
  }

  /**
   * @param clientOperateur_p
   *          the clientOperateur to set
   */
  public void setClientOperateur(String clientOperateur_p)
  {
    _clientOperateur = clientOperateur_p;
  }

  /**
   * @param dateCreation_p
   *          the dateCreation to set
   */
  public void setDateCreation(LocalDateTime dateCreation_p)
  {
    _dateCreation = dateCreation_p;
  }

  /**
   * @param dateModification_p
   *          the dateModification to set
   */
  public void setDateModification(LocalDateTime dateModification_p)
  {
    _dateModification = dateModification_p;
  }

  /**
   * @param ligneMarche_p
   *          the ligneMarche to set
   */
  public void setLigneMarche(String ligneMarche_p)
  {
    _ligneMarche = ligneMarche_p;
  }

  /**
   * @param noCompte_p
   *          the noCompte to set
   */
  public void setNoCompte(String noCompte_p)
  {
    _noCompte = noCompte_p;
  }

  /**
   * @param statut_p
   *          the statut to set
   */
  public void setStatut(String statut_p)
  {
    _statut = statut_p;
  }

  /**
   * @param titulaire_p
   *          the titulaire to set
   */
  public void setTitulaire(PI0035_Titulaire titulaire_p)
  {
    _titulaire = titulaire_p;
  }

  @Override
  public String toString()
  {
    StringBuilder builder = new StringBuilder();
    builder.append("PI0035_PFI [_clientOperateur="); //$NON-NLS-1$
    builder.append(_clientOperateur);
    builder.append(", _noCompte="); //$NON-NLS-1$
    builder.append(_noCompte);
    builder.append(", _statut="); //$NON-NLS-1$
    builder.append(_statut);
    builder.append(", _ligneMarche="); //$NON-NLS-1$
    builder.append(_ligneMarche);
    builder.append(", _titulaire="); //$NON-NLS-1$
    builder.append(_titulaire);
    builder.append(", _dateCreation="); //$NON-NLS-1$
    builder.append(_dateCreation);
    builder.append(", _dateModification="); //$NON-NLS-1$
    builder.append(_dateModification);
    builder.append("]"); //$NON-NLS-1$
    return builder.toString();
  }
}
