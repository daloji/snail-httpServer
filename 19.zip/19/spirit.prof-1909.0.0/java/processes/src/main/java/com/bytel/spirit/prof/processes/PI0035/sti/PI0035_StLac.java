/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PI0035.sti;

import java.time.LocalDateTime;

import com.bytel.spirit.common.shared.saab.TypeObjetCommercial;
import com.bytel.spirit.common.shared.saab.rst.ServiceTechnique;
import com.bytel.spirit.common.shared.saab.rst.StLienAllocationCommercial;
import com.squareup.moshi.Json;

/**
 *
 * @author jgregori
 * @version ($Revision$ $Date$)
 */
public class PI0035_StLac extends PI0035_ServiceTechnique
{
  /**
   *
   */
  private static final long serialVersionUID = -8158110623759925792L;

  /**
   * Builds a new instance of {@link PI0035_StLac} from an instance of {@link ServiceTechnique}
   *
   * @param st_p
   *          The instance of {@link ServiceTechnique}.
   * @return The instance of {@link PI0035_StLac}.
   */
  public static PI0035_StLac buildFromSTLAC(ServiceTechnique st_p)
  {
    StLienAllocationCommercial stLac = StLienAllocationCommercial.class.cast(st_p);
    return new PI0035_StLac(stLac.getIdSt(), stLac.getStatut(), stLac.getTypeServiceTechnique(), stLac.getTypeObjetCommercial(), stLac.getOcNoServiceAccessible(), stLac.getOcIdentifiantFonctionnelPA(), stLac.getOcNoEquipement(), stLac.getTypeRessource(), stLac.getIdRessource(), stLac.getDateCreation(), stLac.getDateModification());
  }

  /**
   * typeObjetCommercial
   */
  @Json(name = "typeObjetCommercial")
  private String _typeObjetCommercial;

  /**
   * noServiceAccessible
   */
  @Json(name = "noServiceAccessible")
  private String _noServiceAccessible;

  /**
   * ocIdentifiantFonctionnelPA
   */
  @Json(name = "identifiantFonctionnelPA")
  private String _identifiantFonctionnelPA;

  /**
   * ocNoEquipement
   */
  @Json(name = "noEquipement")
  private String _noEquipement;

  /**
   * typeRessource
   */
  @Json(name = "typeRessource")
  private String _typeRessource;

  /**
   * idRessource
   */
  @Json(name = "idRessource")
  private String _idRessource;

  /**
   * @param idSt_p
   * @param statut_p
   * @param typeServiceTechnique_p
   * @param typeObjetCommercial_p
   * @param noServiceAccessible_p
   * @param identifiantFonctionnelPA_p
   * @param noEquipement_p
   * @param typeRessource_p
   * @param idRessource_p
   * @param dateCreation_p
   * @param dateModification_p
   */
  public PI0035_StLac(String idSt_p, String statut_p, String typeServiceTechnique_p, String typeObjetCommercial_p, String noServiceAccessible_p, String identifiantFonctionnelPA_p, String noEquipement_p, String typeRessource_p, String idRessource_p, LocalDateTime dateCreation_p, LocalDateTime dateModification_p)
  {
    super(idSt_p, statut_p, typeServiceTechnique_p, dateCreation_p, dateModification_p);

    _typeObjetCommercial = typeObjetCommercial_p;
    if (TypeObjetCommercial.SA.name().equals(typeObjetCommercial_p) || TypeObjetCommercial.LIEN_SA_PA.name().equals(typeObjetCommercial_p))
    {
      _noServiceAccessible = noServiceAccessible_p;
    }
    if (TypeObjetCommercial.PA.name().equals(typeObjetCommercial_p) || TypeObjetCommercial.LIEN_SA_PA.name().equals(typeObjetCommercial_p) || TypeObjetCommercial.LIEN_EQT_PA.name().equals(typeObjetCommercial_p))
    {
      _identifiantFonctionnelPA = identifiantFonctionnelPA_p;
    }
    if (TypeObjetCommercial.EQT_DECLARE.name().equals(typeObjetCommercial_p) || TypeObjetCommercial.LIEN_EQT_PA.name().equals(typeObjetCommercial_p))
    {
      _noEquipement = noEquipement_p;
    }
    _typeRessource = typeRessource_p;
    _idRessource = idRessource_p;
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    PI0035_StLac other = (PI0035_StLac) obj;
    if (_idRessource == null)
    {
      if (other._idRessource != null)
      {
        return false;
      }
    }
    else if (!_idRessource.equals(other._idRessource))
    {
      return false;
    }

    if (_identifiantFonctionnelPA == null)
    {
      if (other._identifiantFonctionnelPA != null)
      {
        return false;
      }
    }
    else if (!_identifiantFonctionnelPA.equals(other._identifiantFonctionnelPA))
    {
      return false;
    }

    if (_noEquipement == null)
    {
      if (other._noEquipement != null)
      {
        return false;
      }
    }
    else if (!_noEquipement.equals(other._noEquipement))
    {
      return false;
    }
    if (_noServiceAccessible == null)
    {
      if (other._noServiceAccessible != null)
      {
        return false;
      }
    }
    else if (!_noServiceAccessible.equals(other._noServiceAccessible))
    {
      return false;
    }
    if (_typeObjetCommercial == null)
    {
      if (other._typeObjetCommercial != null)
      {
        return false;
      }
    }
    else if (!_typeObjetCommercial.equals(other._typeObjetCommercial))
    {
      return false;
    }
    if (_typeRessource == null)
    {
      if (other._typeRessource != null)
      {
        return false;
      }
    }
    else if (!_typeRessource.equals(other._typeRessource))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the idRessource
   */
  public String getIdRessource()
  {
    return _idRessource;
  }

  /**
   * @return the noEquipement
   */
  public String getNoEquipement()
  {
    return _noEquipement;
  }

  /**
   * @return the noServiceAccessible
   */
  public String getNoServiceAccessible()
  {
    return _noServiceAccessible;
  }

  /**
   * @return the typeObjetCommercial
   */
  public String getTypeObjetCommercial()
  {
    return _typeObjetCommercial;
  }

  /**
   * @return the typeRessource
   */
  public String getTypeRessource()
  {
    return _typeRessource;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_idRessource == null) ? 0 : _idRessource.hashCode());
    result = (prime * result) + ((_noEquipement == null) ? 0 : _noEquipement.hashCode());
    result = (prime * result) + ((_noServiceAccessible == null) ? 0 : _noServiceAccessible.hashCode());
    result = (prime * result) + ((_typeObjetCommercial == null) ? 0 : _typeObjetCommercial.hashCode());
    result = (prime * result) + ((_typeRessource == null) ? 0 : _typeRessource.hashCode());
    return result;
  }

  /**
   * @param identifiantFonctionnelPA_p
   *          the identifiantFonctionnelPA to set
   */
  public void setIdentifiantFonctionnelPA(String identifiantFonctionnelPA_p)
  {
    _identifiantFonctionnelPA = identifiantFonctionnelPA_p;
  }

  /**
   * @param noEquipement_p
   *          the noEquipement to set
   */
  public void setNoEquipement(String noEquipement_p)
  {
    _noEquipement = noEquipement_p;
  }

  /**
   * @param noServiceAccessible_p
   *          the ocNoServiceAccessible to set
   */
  public void setNoServiceAccessible(String noServiceAccessible_p)
  {
    _noServiceAccessible = noServiceAccessible_p;
  }

  @Override
  public String toString()
  {
    StringBuilder builder = new StringBuilder();
    builder.append("PI0035_StLac [_typeObjetCommercial="); //$NON-NLS-1$
    builder.append(_typeObjetCommercial);
    builder.append(", _noServiceAccessible="); //$NON-NLS-1$
    builder.append(_noServiceAccessible);
    builder.append(", _identifiantFonctionnelPA="); //$NON-NLS-1$
    builder.append(_identifiantFonctionnelPA);
    builder.append(", _noEquipement="); //$NON-NLS-1$
    builder.append(_noEquipement);
    builder.append(", _typeRessource="); //$NON-NLS-1$
    builder.append(_typeRessource);
    builder.append(", _idRessource="); //$NON-NLS-1$
    builder.append(_idRessource);
    builder.append(", getCommentaire()="); //$NON-NLS-1$
    builder.append(getCommentaire());
    builder.append(", getDateCreation()="); //$NON-NLS-1$
    builder.append(getDateCreation());
    builder.append(", getDateModification()="); //$NON-NLS-1$
    builder.append(getDateModification());
    builder.append(", getIdSt()="); //$NON-NLS-1$
    builder.append(getIdSt());
    builder.append(", getStatut()="); //$NON-NLS-1$
    builder.append(getStatut());
    builder.append(", getTypeServiceTechnique()="); //$NON-NLS-1$
    builder.append(getTypeServiceTechnique());
    builder.append("]"); //$NON-NLS-1$
    return builder.toString();
  }
}
