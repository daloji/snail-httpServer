/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PI0035.sti;

import java.io.Serializable;

import com.squareup.moshi.Json;

/**
 *
 * @author jiantila
 * @version ($Revision$ $Date$)
 */
public class PI0035_Entreprise implements Serializable
{
  /**
   *
   */
  private static final long serialVersionUID = -1395606642898596184L;

  /**
   * Raison social du client titulaire de type Entreprise
   */
  @Json(name = "raisonSociale")
  private String _raisonSociale;

  /**
   * Numéro de siren du client titulaire de type Entreprise
   */
  @Json(name = "noSiren")
  private String _noSiren;

  /**
   *
   */
  public PI0035_Entreprise()
  {
    super();
  }

  /**
   * @param raisonSociale_p
   */
  public PI0035_Entreprise(String raisonSociale_p)
  {
    super();

    _raisonSociale = raisonSociale_p;
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    PI0035_Entreprise other = (PI0035_Entreprise) obj;
    if (_noSiren == null)
    {
      if (other._noSiren != null)
      {
        return false;
      }
    }
    else if (!_noSiren.equals(other._noSiren))
    {
      return false;
    }
    if (_raisonSociale == null)
    {
      if (other._raisonSociale != null)
      {
        return false;
      }
    }
    else if (!_raisonSociale.equals(other._raisonSociale))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the noSiren
   */
  public String getNoSiren()
  {
    return _noSiren;
  }

  /**
   * @return the raisonSociale
   */
  public String getRaisonSociale()
  {
    return _raisonSociale;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_noSiren == null) ? 0 : _noSiren.hashCode());
    result = (prime * result) + ((_raisonSociale == null) ? 0 : _raisonSociale.hashCode());
    return result;
  }

  /**
   * @param noSiren_p
   *          the noSiren to set
   */
  public void setNoSiren(String noSiren_p)
  {
    _noSiren = noSiren_p;
  }

  /**
   * @param raisonSociale_p
   *          the raisonSociale to set
   */
  public void setRaisonSociale(String raisonSociale_p)
  {
    _raisonSociale = raisonSociale_p;
  }

  @Override
  public String toString()
  {
    StringBuilder builder = new StringBuilder();
    builder.append("PI0035_Entreprise [_raisonSociale="); //$NON-NLS-1$
    builder.append(_raisonSociale);
    builder.append(", _noSiren="); //$NON-NLS-1$
    builder.append(_noSiren);
    builder.append("]"); //$NON-NLS-1$
    return builder.toString();
  }
}
