/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PI0035.sti;

import java.io.Serializable;

import com.bytel.spirit.common.shared.saab.rpg.InfoBrutBssEnt;
import com.squareup.moshi.Json;

/**
 *
 * @author jiantila
 * @version ($Revision$ $Date$)
 */
public class PI0035_InfoBruteBssENT implements Serializable
{
  /**
   *
   */
  private static final long serialVersionUID = 32610615359815959L;

  /**
   * Creates a new instance of [{@link PI0035_InfoBruteBssENT} from an instance of {@link InfoBrutBssEnt}.
   *
   * @param infoBruteBssEnt_p
   *          The InfoBrutBssEnt instance.
   * @return The PFICompletInfoBruteBssENT instance.
   */
  public static PI0035_InfoBruteBssENT buildFromInfoBrutBssEnt(InfoBrutBssEnt infoBruteBssEnt_p)
  {
    PI0035_InfoBruteBssENT infoBruteBssEnt = new PI0035_InfoBruteBssENT(infoBruteBssEnt_p.getCodeOffre());
    infoBruteBssEnt.setNdi(infoBruteBssEnt_p.getNdi());
    infoBruteBssEnt.setNdiActif(infoBruteBssEnt_p.getNdiActif());
    infoBruteBssEnt.setNdiAssocie(infoBruteBssEnt_p.getNdiAssocie());
    infoBruteBssEnt.setNdiVoisin(infoBruteBssEnt_p.getNdiVoisin());
    return infoBruteBssEnt;
  }

  /**
   * Code de l'offre technique
   */
  @Json(name = "codeOffre")
  private String _codeOffre;

  /**
   *
   * Numéro de Désignation d'Installation
   */
  @Json(name = "ndi")
  private String _ndi;

  /**
   *
   * Indique si le NDI est actif (vrai) ou
   */
  @Json(name = "ndiActif")
  private Boolean _ndiActif;

  /**
   *
   * Numéro de Désignation d'Installation proche de l'installation à créer.
   */
  @Json(name = "ndiAssocie")
  private String _ndiAssocie;

  /**
   *
   * Indique si la valeur contenue dans le champ ndiAssocie est celui d'un voisin (true) ou un ndiAssocie (false)
   */
  @Json(name = "ndiVoisin")
  private Boolean _ndiVoisin;

  /**
   *
   */
  public PI0035_InfoBruteBssENT()
  {
    super();
  }

  /**
   * @param codeOffre_p
   */
  public PI0035_InfoBruteBssENT(String codeOffre_p)
  {
    super();

    _codeOffre = codeOffre_p;
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    PI0035_InfoBruteBssENT other = (PI0035_InfoBruteBssENT) obj;
    if (_codeOffre == null)
    {
      if (other._codeOffre != null)
      {
        return false;
      }
    }
    else if (!_codeOffre.equals(other._codeOffre))
    {
      return false;
    }
    if (_ndi == null)
    {
      if (other._ndi != null)
      {
        return false;
      }
    }
    else if (!_ndi.equals(other._ndi))
    {
      return false;
    }
    if (_ndiActif == null)
    {
      if (other._ndiActif != null)
      {
        return false;
      }
    }
    else if (!_ndiActif.equals(other._ndiActif))
    {
      return false;
    }
    if (_ndiAssocie == null)
    {
      if (other._ndiAssocie != null)
      {
        return false;
      }
    }
    else if (!_ndiAssocie.equals(other._ndiAssocie))
    {
      return false;
    }
    if (_ndiVoisin == null)
    {
      if (other._ndiVoisin != null)
      {
        return false;
      }
    }
    else if (!_ndiVoisin.equals(other._ndiVoisin))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the codeOffre
   */
  public String getCodeOffre()
  {
    return _codeOffre;
  }

  /**
   * @return the ndi
   */
  public String getNdi()
  {
    return _ndi;
  }

  /**
   * @return the ndiActif
   */
  public Boolean getNdiActif()
  {
    return _ndiActif;
  }

  /**
   * @return the ndiAssocie
   */
  public String getNdiAssocie()
  {
    return _ndiAssocie;
  }

  /**
   * @return the ndiVoisin
   */
  public Boolean getNdiVoisin()
  {
    return _ndiVoisin;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_codeOffre == null) ? 0 : _codeOffre.hashCode());
    result = (prime * result) + ((_ndi == null) ? 0 : _ndi.hashCode());
    result = (prime * result) + ((_ndiActif == null) ? 0 : _ndiActif.hashCode());
    result = (prime * result) + ((_ndiAssocie == null) ? 0 : _ndiAssocie.hashCode());
    result = (prime * result) + ((_ndiVoisin == null) ? 0 : _ndiVoisin.hashCode());
    return result;
  }

  /**
   * @return the ndiActif
   */
  public boolean isNdiActif()
  {
    return _ndiActif;
  }

  /**
   * @return the ndiVoisin
   */
  public Boolean isNdiVoisin()
  {
    return _ndiVoisin;
  }

  /**
   * @param codeOffre_p
   *          the codeOffre to set
   */
  public void setCodeOffre(String codeOffre_p)
  {
    _codeOffre = codeOffre_p;
  }

  /**
   * @param ndi_p
   *          the ndi to set
   */
  public void setNdi(String ndi_p)
  {
    _ndi = ndi_p;
  }

  /**
   * @param ndiActif_p
   *          the ndiActif to set
   */
  public void setNdiActif(Boolean ndiActif_p)
  {
    _ndiActif = ndiActif_p;
  }

  /**
   * @param ndiAssocie_p
   *          the ndiAssocie to set
   */
  public void setNdiAssocie(String ndiAssocie_p)
  {
    _ndiAssocie = ndiAssocie_p;
  }

  /**
   * @param ndiVoisin_p
   *          the ndiVoisin to set
   */
  public void setNdiVoisin(Boolean ndiVoisin_p)
  {
    _ndiVoisin = ndiVoisin_p;
  }

  @Override
  public String toString()
  {
    StringBuilder builder = new StringBuilder();
    builder.append("PI0035_InfoBruteBssENT [_codeOffre="); //$NON-NLS-1$
    builder.append(_codeOffre);
    builder.append(", _ndi="); //$NON-NLS-1$
    builder.append(_ndi);
    builder.append(", _ndiActif="); //$NON-NLS-1$
    builder.append(_ndiActif);
    builder.append(", _ndiAssocie="); //$NON-NLS-1$
    builder.append(_ndiAssocie);
    builder.append(", _ndiVoisin="); //$NON-NLS-1$
    builder.append(_ndiVoisin);
    builder.append("]"); //$NON-NLS-1$
    return builder.toString();
  }
}
