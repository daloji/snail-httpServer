/*
 *                                                             ___o.__
 *                                                         ,oH8888888888o._
 *                                                       dP',88888P'''`8888o.
 *   ____                                              ,8',888888      888888o
 *  |  _ \                                            d8,d888888b    ,d8888888b
 *  | |_) | ___  _   _ _   _  __ _ _   _  ___  ___   ,8PPY8888888boo8888PPPP"'`b
 *  |  _ < / _ \| | | | | | |/ _` | | | |/ _ \/ __|  d8o_                     d8
 *  | |_) | (_) | |_| | |_| | (_| | |_| |  __/\__ \' d888bo.             _ooP d8'
 *  |____/ \___/ \__,_|\__, |\__, |\__,_|\___||___/  d8888888P     ,ooo88888P d8
 *                      __/ | ___/_                  `8M8888P     ,88888888P ,8P
 *                     |___/ |__ |  _  |  _  _  _ __  Y88Y88'    ,888888888' dP
 *                               | (/_ | (/_(_ (_)|||  `8b8P    d8888888888,dP
 *                                                      Y8,   d88888888888P'
 *                                                        `Y=8888888888P'
 *                                                            `''`'''
 *
 *  Systeme $system
 *
 *  (C) Copyright Bouygues Telecom 2018.
 *
 *  Utilisation, reproduction et divulgation interdites
 *  sans autorisation ecrite de Bouygues Telecom.
 *
 *  Projet  : FTTOcmdRacco_Lot3_Rebasing1901
 *  Package : com.bytel.spirit.prof.processes.PI0035.sti
 *  Classe  : PI0035_AccesTechnique
 *  Auteur  : sdiop
 *
 */

package com.bytel.spirit.prof.processes.PI0035.sti;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.bytel.spirit.common.shared.saab.res.AccesTechnique;
import com.squareup.moshi.Json;

/**
 *
 * @author sdiop
 * @version ($Revision$ $Date$)
 */
public class PI0035_AccesTechnique implements Serializable
{
  /**
   *
   */
  private static final long serialVersionUID = 4004704766166251438L;

  /**
   * Creates a new instance of {@link PI0035_AccesTechnique} from an instance of {@link AccesTechnique}
   *
   * @param accesTechnique_p
   *          The instance of {@link AccesTechnique}.
   * @return The created instance of {@link PI0035_AccesTechnique};
   */
  public static PI0035_AccesTechnique buildFromAccesTechnique(AccesTechnique accesTechnique_p)
  {
    return new PI0035_AccesTechnique(accesTechnique_p.getCodeAccesTechnique(), accesTechnique_p.getGammeTechno(), accesTechnique_p.getCouverture(), accesTechnique_p.getNormeTechno(), accesTechnique_p.getLigneMarche(), accesTechnique_p.getTechno(), accesTechnique_p.getDebitDescendantMax(), accesTechnique_p.getDebitMontantMax());
  }

  /**
   * Identifiant fonctionnel
   */
  @Json(name = "codeAccesTechnique")
  private String _codeAccesTechnique;

  /**
   * Indique la ligne de marché
   */
  @Json(name = "ligneMarche")
  private String _ligneMarche;

  /**
   * Gamme de la technologie xDSL
   */
  @Json(name = "gammeTechno")
  private String _gammeTechno;

  /**
   * Technologie
   */
  @Json(name = "techno")
  private String _techno;

  /**
   * Indique le referentiel d’adresse associé
   */
  @Json(name = "couverture")
  private String _couverture;
  /**
   * Norme de la technologie : permet d’aiguiller l’éligibilité vers les bonnes ressources
   */
  @Json(name = "normeTechno")
  private String _normeTechno;

  /**
   * Débit descendant maximal Remarque: En ko
   */
  @Json(name = "debitDescendantMax")
  private Float _debitDescendantMax;

  /**
   * Débit montant maximal Remarque: En ko
   */
  @Json(name = "debitMontantMax")
  private Float _debitMontantMax;

  /**
   * Liste des GTR compatible avec l’Acces Technique Remarque : L’ajout d’une nouvelle valeur a des implications
   * fonctionnelles
   */
  @Json(name = "gtrCompatible")
  private List<String> _gtrCompatible;

  /**
   * Liste des flux TV compatible
   */
  @Json(name = "fluxTvCompatible")
  private List<String> _fluxTvCompatible;

  /**
   * @param codeAccesTechnique_p
   * @param ligneMarche_p
   * @param techno_p
   * @param debitDescendantMax_p
   * @param debitMontantMax_p
   */
  public PI0035_AccesTechnique(String codeAccesTechnique_p, String ligneMarche_p, String techno_p, Float debitDescendantMax_p, Float debitMontantMax_p)
  {
    super();

    _codeAccesTechnique = codeAccesTechnique_p;
    _ligneMarche = ligneMarche_p;
    _techno = techno_p;
    _debitDescendantMax = debitDescendantMax_p;
    _debitMontantMax = debitMontantMax_p;
  }

  /**
   * @param codeAccesTechnique_p
   * @param gammeTechno_p
   * @param couverture_p
   * @param normeTechno_p
   * @param ligneMarche_p
   * @param techno_p
   * @param debitDescendantMax_p
   * @param debitMontantMax_p
   */
  public PI0035_AccesTechnique(String codeAccesTechnique_p, String gammeTechno_p, String couverture_p, String normeTechno_p, String ligneMarche_p, String techno_p, Float debitDescendantMax_p, Float debitMontantMax_p)
  {
    super();

    _codeAccesTechnique = codeAccesTechnique_p;
    _gammeTechno = gammeTechno_p;
    _couverture = couverture_p;
    _normeTechno = normeTechno_p;
    _ligneMarche = ligneMarche_p;
    _techno = techno_p;
    _debitDescendantMax = debitDescendantMax_p;
    _debitMontantMax = debitMontantMax_p;
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    PI0035_AccesTechnique other = (PI0035_AccesTechnique) obj;
    if (_codeAccesTechnique == null)
    {
      if (other._codeAccesTechnique != null)
      {
        return false;
      }
    }
    else if (!_codeAccesTechnique.equals(other._codeAccesTechnique))
    {
      return false;
    }
    if (_couverture == null)
    {
      if (other._couverture != null)
      {
        return false;
      }
    }
    else if (!_couverture.equals(other._couverture))
    {
      return false;
    }
    if (_debitDescendantMax == null)
    {
      if (other._debitDescendantMax != null)
      {
        return false;
      }
    }
    else if (!_debitDescendantMax.equals(other._debitDescendantMax))
    {
      return false;
    }
    if (_debitMontantMax == null)
    {
      if (other._debitMontantMax != null)
      {
        return false;
      }
    }
    else if (!_debitMontantMax.equals(other._debitMontantMax))
    {
      return false;
    }
    if (_fluxTvCompatible == null)
    {
      if (other._fluxTvCompatible != null)
      {
        return false;
      }
    }
    else if (!_fluxTvCompatible.equals(other._fluxTvCompatible))
    {
      return false;
    }
    if (_gammeTechno == null)
    {
      if (other._gammeTechno != null)
      {
        return false;
      }
    }
    else if (!_gammeTechno.equals(other._gammeTechno))
    {
      return false;
    }
    if (_gtrCompatible == null)
    {
      if (other._gtrCompatible != null)
      {
        return false;
      }
    }
    else if (!_gtrCompatible.equals(other._gtrCompatible))
    {
      return false;
    }
    if (_ligneMarche == null)
    {
      if (other._ligneMarche != null)
      {
        return false;
      }
    }
    else if (!_ligneMarche.equals(other._ligneMarche))
    {
      return false;
    }
    if (_normeTechno == null)
    {
      if (other._normeTechno != null)
      {
        return false;
      }
    }
    else if (!_normeTechno.equals(other._normeTechno))
    {
      return false;
    }
    if (_techno == null)
    {
      if (other._techno != null)
      {
        return false;
      }
    }
    else if (!_techno.equals(other._techno))
    {
      return false;
    }
    return true;
  }

  /**
   * @return _codeAccesTechnique
   */
  public String getCodeAccesTechnique()
  {
    return _codeAccesTechnique;
  }

  /**
   * @return _couverture
   */
  public String getCouverture()
  {
    return _couverture;
  }

  /**
   * @return _debitDescendantMax
   */
  public Float getDebitDescendantMax()
  {
    return _debitDescendantMax;
  }

  /**
   * @return _debitMontantMax
   */
  public Float getDebitMontantMax()
  {
    return _debitMontantMax;
  }

  /**
   * @return _fluxTvCompatible
   */
  public List<String> getFluxTvCompatible()
  {
    return _fluxTvCompatible != null ? new ArrayList<>(_fluxTvCompatible) : new ArrayList<>();

  }

  /**
   * @return _gammeTechno
   */
  public String getGammeTechno()
  {
    return _gammeTechno;
  }

  /**
   * @return _gtrCompatible
   */
  public List<String> getGtrCompatible()
  {
    return _gtrCompatible != null ? new ArrayList<>(_gtrCompatible) : new ArrayList<>();

  }

  /**
   * @return _ligneMarche
   */
  public String getLigneMarche()
  {
    return _ligneMarche;
  }

  /**
   * @return _normeTechno
   */
  public String getNormeTechno()
  {
    return _normeTechno;
  }

  /**
   * @return _techno
   */
  public String getTechno()
  {
    return _techno;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_codeAccesTechnique == null) ? 0 : _codeAccesTechnique.hashCode());
    result = (prime * result) + ((_couverture == null) ? 0 : _couverture.hashCode());
    result = (prime * result) + ((_debitDescendantMax == null) ? 0 : _debitDescendantMax.hashCode());
    result = (prime * result) + ((_debitMontantMax == null) ? 0 : _debitMontantMax.hashCode());
    result = (prime * result) + ((_fluxTvCompatible == null) ? 0 : _fluxTvCompatible.hashCode());
    result = (prime * result) + ((_gammeTechno == null) ? 0 : _gammeTechno.hashCode());
    result = (prime * result) + ((_gtrCompatible == null) ? 0 : _gtrCompatible.hashCode());
    result = (prime * result) + ((_ligneMarche == null) ? 0 : _ligneMarche.hashCode());
    result = (prime * result) + ((_normeTechno == null) ? 0 : _normeTechno.hashCode());
    result = (prime * result) + ((_techno == null) ? 0 : _techno.hashCode());
    return result;
  }

  /**
   * @param codeAccesTechnique_p
   *          _codeAccesTechnique
   */
  public void setCodeAccesTechnique(String codeAccesTechnique_p)
  {
    _codeAccesTechnique = codeAccesTechnique_p;
  }

  /**
   * @param couverture_p
   *          _couverture
   */
  public void setCouverture(String couverture_p)
  {
    _couverture = couverture_p;
  }

  /**
   * @param debitDescendantMax_p
   *          _debitDescendantMax
   */
  public void setDebitDescendantMax(Float debitDescendantMax_p)
  {
    _debitDescendantMax = debitDescendantMax_p;
  }

  /**
   * @param debitMontantMax_p
   *          _debitMontantMax
   */
  public void setDebitMontantMax(Float debitMontantMax_p)
  {
    _debitMontantMax = debitMontantMax_p;
  }

  /**
   * @param fluxTvCompatible_p
   *          _fluxTvCompatible
   */
  public void setFluxTvCompatible(List<String> fluxTvCompatible_p)
  {
    _fluxTvCompatible = fluxTvCompatible_p != null ? new ArrayList<>(fluxTvCompatible_p) : new ArrayList<>();
  }

  /**
   * @param gammeTechno_p
   *          _gammeTechno
   */
  public void setGammeTechno(String gammeTechno_p)
  {
    _gammeTechno = gammeTechno_p;
  }

  /**
   * @param gtrCompatible_p
   *          _gtrCompatible
   */
  public void setGtrCompatible(List<String> gtrCompatible_p)
  {
    _gtrCompatible = gtrCompatible_p != null ? new ArrayList<>(gtrCompatible_p) : new ArrayList<>();

  }

  /**
   * @param ligneMarche_p
   *          _ligneMarche
   */
  public void setLigneMarche(String ligneMarche_p)
  {
    _ligneMarche = ligneMarche_p;
  }

  /**
   * @param normeTechno_p
   *          _normeTechno
   */
  public void setNormeTechno(String normeTechno_p)
  {
    _normeTechno = normeTechno_p;
  }

  /**
   * @param techno_p
   *          _techno
   */
  public void setTechno(String techno_p)
  {
    _techno = techno_p;
  }

  @Override
  public String toString()
  {
    StringBuilder builder = new StringBuilder();
    builder.append("PI0035_AccesTechnique [_codeAccesTechnique="); //$NON-NLS-1$
    builder.append(_codeAccesTechnique);
    builder.append(", _ligneMarche="); //$NON-NLS-1$
    builder.append(_ligneMarche);
    builder.append(", _gammeTechno="); //$NON-NLS-1$
    builder.append(_gammeTechno);
    builder.append(", _techno="); //$NON-NLS-1$
    builder.append(_techno);
    builder.append(", _couverture="); //$NON-NLS-1$
    builder.append(_couverture);
    builder.append(", _normeTechno="); //$NON-NLS-1$
    builder.append(_normeTechno);
    builder.append(", _debitDescendantMax="); //$NON-NLS-1$
    builder.append(_debitDescendantMax);
    builder.append(", _debitMontantMax="); //$NON-NLS-1$
    builder.append(_debitMontantMax);
    builder.append(", _gtrCompatible="); //$NON-NLS-1$
    builder.append(_gtrCompatible);
    builder.append(", _fluxTvCompatible="); //$NON-NLS-1$
    builder.append(_fluxTvCompatible);
    builder.append("]"); //$NON-NLS-1$
    return builder.toString();
  }
}
