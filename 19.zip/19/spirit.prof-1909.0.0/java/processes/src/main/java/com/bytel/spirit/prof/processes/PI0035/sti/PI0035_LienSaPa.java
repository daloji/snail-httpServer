/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PI0035.sti;

import java.io.Serializable;
import java.time.LocalDateTime;

import com.bytel.ravel.common.json.annotations.RavelLocalDateTimeFormat;
import com.bytel.ravel.common.json.format.impl.IsoShortOffsetDateTimeWithMillis;
import com.bytel.spirit.common.shared.saab.rpg.LienSAPA;
import com.squareup.moshi.Json;

/**
 *
 * @author jiantila
 * @version ($Revision$ $Date$)
 */
public class PI0035_LienSaPa implements Serializable
{

  /**
   *
   */
  private static final long serialVersionUID = 1670889056290254654L;

  /**
   * Builds a new instance of {@link PI0035_LienSaPa} from an instance of {@link LienSAPA}.
   *
   * @param lienSAPA_p
   *          The instance of {@link LienSAPA}
   * @return The created instance of {@link PI0035_LienSaPa}.
   */
  public static PI0035_LienSaPa buildFromLienSAPA(LienSAPA lienSAPA_p)
  {
    return new PI0035_LienSaPa(lienSAPA_p.getNoServiceAccessible(), lienSAPA_p.getIdentifiantFonctionnelPA(), lienSAPA_p.getStatut().name(), lienSAPA_p.getDateCreation(), lienSAPA_p.getDateModification());
  }

  /**
   * Identifiant unique du SA lié
   */
  @Json(name = "noServiceAccessible")
  private String _noServiceAccessible;

  /**
   * Identifiant unique du PA lié
   */
  @Json(name = "identifiantFonctionnelPA")
  private String _identifiantFonctionnelPA;

  /**
   * Statut
   */
  @Json(name = "statut")
  private String _statut;
  /**
   * Date de creation
   */
  @Json(name = "dateCreation")
  @RavelLocalDateTimeFormat(IsoShortOffsetDateTimeWithMillis.class)
  private LocalDateTime _dateCreation;

  /**
   * Date de Modification
   */
  @Json(name = "dateModification")
  @RavelLocalDateTimeFormat(IsoShortOffsetDateTimeWithMillis.class)
  private LocalDateTime _dateModification;

  /**
   *
   */
  public PI0035_LienSaPa()
  {
    super();
  }

  /**
   * @param noServiceAccessible_p
   * @param identifiantFonctionnelPA_p
   * @param statut_p
   * @param dateCreation_p
   * @param dateModification_p
   */
  public PI0035_LienSaPa(String noServiceAccessible_p, String identifiantFonctionnelPA_p, String statut_p, LocalDateTime dateCreation_p, LocalDateTime dateModification_p)
  {
    super();

    _noServiceAccessible = noServiceAccessible_p;
    _identifiantFonctionnelPA = identifiantFonctionnelPA_p;
    _statut = statut_p;
    _dateCreation = dateCreation_p;
    _dateModification = dateModification_p;
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    PI0035_LienSaPa other = (PI0035_LienSaPa) obj;
    if (_dateCreation == null)
    {
      if (other._dateCreation != null)
      {
        return false;
      }
    }
    else if (!_dateCreation.equals(other._dateCreation))
    {
      return false;
    }
    if (_dateModification == null)
    {
      if (other._dateModification != null)
      {
        return false;
      }
    }
    else if (!_dateModification.equals(other._dateModification))
    {
      return false;
    }
    if (_identifiantFonctionnelPA == null)
    {
      if (other._identifiantFonctionnelPA != null)
      {
        return false;
      }
    }
    else if (!_identifiantFonctionnelPA.equals(other._identifiantFonctionnelPA))
    {
      return false;
    }
    if (_noServiceAccessible == null)
    {
      if (other._noServiceAccessible != null)
      {
        return false;
      }
    }
    else if (!_noServiceAccessible.equals(other._noServiceAccessible))
    {
      return false;
    }
    if (_statut == null)
    {
      if (other._statut != null)
      {
        return false;
      }
    }
    else if (!_statut.equals(other._statut))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the dateCreation
   */
  public LocalDateTime getDateCreation()
  {
    return _dateCreation;
  }

  /**
   * @return the dateModification
   */
  public LocalDateTime getDateModification()
  {
    return _dateModification;
  }

  /**
   * @return the identifiantFonctionnelPA
   */
  public String getIdentifiantFonctionnelPA()
  {
    return _identifiantFonctionnelPA;
  }

  /**
   * @return the noServiceAccessible
   */
  public String getNoServiceAccessible()
  {
    return _noServiceAccessible;
  }

  /**
   * @return the statut
   */
  public String getStatut()
  {
    return _statut;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_dateCreation == null) ? 0 : _dateCreation.hashCode());
    result = (prime * result) + ((_dateModification == null) ? 0 : _dateModification.hashCode());
    result = (prime * result) + ((_identifiantFonctionnelPA == null) ? 0 : _identifiantFonctionnelPA.hashCode());
    result = (prime * result) + ((_noServiceAccessible == null) ? 0 : _noServiceAccessible.hashCode());
    result = (prime * result) + ((_statut == null) ? 0 : _statut.hashCode());
    return result;
  }

  /**
   * @param dateCreation_p
   *          the dateCreation to set
   */
  public void setDateCreation(LocalDateTime dateCreation_p)
  {
    _dateCreation = dateCreation_p;
  }

  /**
   * @param dateModification_p
   *          the dateModification to set
   */
  public void setDateModification(LocalDateTime dateModification_p)
  {
    _dateModification = dateModification_p;
  }

  /**
   * @param identifiantFonctionnelPA_p
   *          the identifiantFonctionnelPA to set
   */
  public void setIdentifiantFonctionnelPA(String identifiantFonctionnelPA_p)
  {
    _identifiantFonctionnelPA = identifiantFonctionnelPA_p;
  }

  /**
   * @param noServiceAccessible_p
   *          the noServiceAccessible to set
   */
  public void setNoServiceAccessible(String noServiceAccessible_p)
  {
    _noServiceAccessible = noServiceAccessible_p;
  }

  /**
   * @param statut_p
   *          the statut to set
   */
  public void setStatut(String statut_p)
  {
    _statut = statut_p;
  }

  @Override
  public String toString()
  {
    StringBuilder builder = new StringBuilder();
    builder.append("PI0035_LienSaPa [_noServiceAccessible="); //$NON-NLS-1$
    builder.append(_noServiceAccessible);
    builder.append(", _identifiantFonctionnelPA="); //$NON-NLS-1$
    builder.append(_identifiantFonctionnelPA);
    builder.append(", _statut="); //$NON-NLS-1$
    builder.append(_statut);
    builder.append(", _dateCreation="); //$NON-NLS-1$
    builder.append(_dateCreation);
    builder.append(", _dateModification="); //$NON-NLS-1$
    builder.append(_dateModification);
    builder.append("]"); //$NON-NLS-1$
    return builder.toString();
  }
}
