/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PE0147;

import java.text.MessageFormat;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.data.exchange.generated.RavelRequest;
import com.bytel.ravel.common.datetime.DateTimeManager;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionTools;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.response.IRavelResponse;
import com.bytel.ravel.common.factory.response.RavelResponseFactory;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.DateTimeTools.DateTimeFormatPattern;
import com.bytel.ravel.common.utils.Pair;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.net.http.HttpConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.aspectJ.LogContinueProcess;
import com.bytel.ravel.services.aspectJ.LogProcessBL;
import com.bytel.ravel.services.aspectJ.LogStartProcess;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.AbstractBLReturn;
import com.bytel.ravel.services.process.MandatoryProcessState;
import com.bytel.ravel.services.process.activity.Context;
import com.bytel.spirit.common.activities.ossfai.OSSFAI_SI009_ReserveAdresseMailSecondaire;
import com.bytel.spirit.common.activities.ossfai.OSSFAI_SI009_ReserveAdresseMailSecondaire.OSSFAI_SI009_ReserveAdresseMailSecondaireBuilder;
import com.bytel.spirit.common.activities.shared.BL1700_AjouterRefFonc;
import com.bytel.spirit.common.activities.shared.BL1700_AjouterRefFonc.BL1700_AjouterRefFoncBuilder;
import com.bytel.spirit.common.activities.shared.BL3700_RecupererPfiParMail;
import com.bytel.spirit.common.activities.shared.BL3700_RecupererPfiParMail.BL3700_RecupererPfiParMailBuilder;
import com.bytel.spirit.common.activities.shared.BL4600_CreerErreurSpirit;
import com.bytel.spirit.common.activities.shared.BL4600_CreerErreurSpirit.BL4600_CreerErreurSpiritBuilder;
import com.bytel.spirit.common.activities.shared.BL800_ObtenirSequence;
import com.bytel.spirit.common.activities.shared.structs.BL3700_Return;
import com.bytel.spirit.common.activities.shared.structs.UniqueIdConstant;
import com.bytel.spirit.common.connectors.cmd.CMDProxy;
import com.bytel.spirit.common.connectors.ink.activities.PROV_SI001_LancerOrchestrateur;
import com.bytel.spirit.common.connectors.ink.activities.PROV_SI001_LancerOrchestrateur.PROV_SI001_LancerOrchestrateurBuilder;
import com.bytel.spirit.common.connectors.rpg.RPGProxy;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.error.ReponseErreur;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.processes.SpiritProcessSkeleton;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.IRefFoncConstants;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.cmd.Commande;
import com.bytel.spirit.common.shared.saab.cmd.request.CreateCommandeRequest;
import com.bytel.spirit.common.shared.saab.rpg.PA;
import com.bytel.spirit.common.shared.saab.rpg.PFI;
import com.bytel.spirit.common.shared.saab.rpg.SA;
import com.bytel.spirit.common.shared.saab.rpg.Statut;
import com.bytel.spirit.common.shared.saab.rpg.TypePA;
import com.bytel.spirit.common.shared.types.json.validation.IMessageFormatKeys;
import com.bytel.spirit.common.shared.utils.PFIFilter;
import com.bytel.spirit.common.shared.utils.PFIFilterOption;
import com.bytel.spirit.common.shared.utils.PFIUtils;
import com.bytel.spirit.prof.processes.Messages;
import com.bytel.spirit.prof.shared.types.json.request.ServiceMailGererMailSecondaireRequest;

/**
 *
 * @author jgregori
 * @version ($Revision$ $Date$)
 */
public class PEI0147_GererMailSecondaire extends SpiritProcessSkeleton
{
  /**
   * Process context
   *
   * @author jgregori
   * @version ($Revision$ $Date$)
   */
  public static final class PEI0147_GererMailSecondaireContext extends Context
  {
    /**
     * The Generated UID.
     */
    private static final long serialVersionUID = -9195894367216220017L;

    /**
     * The retour
     */
    private Retour _retour;

    /**
     *
     */
    private ServiceMailGererMailSecondaireRequest _gererMailSecondaireRequest;

    /**
     * reponseErreur startprocess
     */
    private ReponseErreur _responseErreur;
    /**
     * The commande
     */
    private Commande _commande;

    /**
    *
    */
    private boolean _declenchementPep;

    /**
     * The listeCleSequencement
     */
    private List<String> _listeCleSequencement;

    /***
     * Contains the next step to execute. Initialized with the first step to execute.
     */
    private State _state = State.PEI0147_BL001;

    /**
     * The clientOperateur from header
     */
    private String _xClientOperateur;

    /**
     * @return the commande
     */
    public Commande getCommande()
    {
      return _commande;
    }

    /**
     * @return the gererMailSecondaireRequest
     */
    public ServiceMailGererMailSecondaireRequest getGererMailSecondaireRequest()
    {
      return _gererMailSecondaireRequest;
    }

    /**
     * @return the listeCleSequencement
     */
    public List<String> getListeCleSequencement()
    {
      if (_listeCleSequencement != null)
      {
        return new ArrayList<>(_listeCleSequencement);
      }
      return new ArrayList<>();
    }

    /**
     * @return the responseErreur
     */
    public ReponseErreur getResponseErreur()
    {
      return _responseErreur;
    }

    /**
     * @return the retour
     */
    public Retour getRetour()
    {
      return _retour;
    }

    /**
     * @return the state
     */
    public State getState()
    {
      return _state;
    }

    /**
     * @return the clientOperateur
     */
    public String getXClientOperateur()
    {
      return _xClientOperateur;
    }

    /**
     * @return the declenchementPep
     */
    public boolean isDeclenchementPep()
    {
      return _declenchementPep;
    }

    /**
     * @param commande_p
     *          the commande to set
     */
    public void setCommande(Commande commande_p)
    {
      _commande = commande_p;
    }

    /**
     * @param declenchementPep_p
     *          the declenchementPep to set
     */
    public void setDeclenchementPep(boolean declenchementPep_p)
    {
      _declenchementPep = declenchementPep_p;
    }

    /**
     * @param gererMailSecondaireRequest_p
     *          the gererMailSecondaireRequest to set
     */
    public void setGererMailSecondaireRequest(ServiceMailGererMailSecondaireRequest gererMailSecondaireRequest_p)
    {
      _gererMailSecondaireRequest = gererMailSecondaireRequest_p;
    }

    /**
     * @param listeCleSequencement_p
     *          the listeCleSequencement to set
     */
    public void setListeCleSequencement(List<String> listeCleSequencement_p)
    {
      if (listeCleSequencement_p != null)
      {
        _listeCleSequencement = new ArrayList<>(listeCleSequencement_p);
      }
      else
      {
        _listeCleSequencement = new ArrayList<>();
      }
    }

    /**
     * @param responseErreur_p
     *          the responseErreur to set
     */
    public void setResponseErreur(ReponseErreur responseErreur_p)
    {
      _responseErreur = responseErreur_p;
    }

    /**
     * @param retour_p
     *          the retour to set
     */
    public void setRetour(Retour retour_p)
    {
      _retour = retour_p;
    }

    /**
     * @param state_p
     *          the state to set
     */
    public void setState(State state_p)
    {
      _state = state_p;
    }

    /**
     * @param xClientOperateur_p
     *          the clientOperateur to set
     */
    public void setXClientOperateur(String xClientOperateur_p)
    {
      _xClientOperateur = xClientOperateur_p;
    }
  }

  /**
   * The Enum containing all process states
   *
   * @author jgregori
   * @version ($Revision$ $Date$)
   */
  public enum State
  {
    /**
     * PEI0147_BL001_VerifierDonnes
     */
    PEI0147_BL001(MandatoryProcessState.PRC_START, false, false),
    /**
     * OSS_FAI_SI009_spiritReserveMailSeecondaire
     */
    PEI0147_SI009(MandatoryProcessState.PRC_RUNNING, false, false),
    /**
     * PEI0142_BL100_SauveGarderCommande
     */
    PEI0147_BL100(MandatoryProcessState.PRC_RUNNING, false, false),
    /**
     * PEI0147_BL002_FormaterReponse
     */
    PEI0147_BL002(MandatoryProcessState.PRC_RUNNING, false, false),
    /**
     * PROV_SI001_LancerOrchestrateur
     */
    PEI0147_SI001(MandatoryProcessState.PRC_RUNNING, false, true),
    /**
     * PEI0147_BL005_GererErreurPROSPER
     */
    PEI0147_BL005(MandatoryProcessState.PRC_RUNNING, false, false),
    /**
     * Terminal state.
     */
    ENDED(MandatoryProcessState.PRC_STOP, false, false);

    /**
     * Technical state associated.
     */
    protected MandatoryProcessState _technicalState = MandatoryProcessState.PRC_START;

    /**
     * The asynchronous state.
     */
    protected boolean _asynchronousState = false;

    /**
     * Replayable state.
     */
    protected boolean _replayableState = false;

    /**
     * Constructor.
     *
     * @param technicalState_p
     *          The {@link MandatoryProcessState} associated
     * @param replayable_p
     *          is replayable state
     * @param asynchronous_p
     *          is asynchronous state
     */
    private State(final MandatoryProcessState technicalState_p, boolean replayable_p, boolean asynchronous_p)
    {
      _technicalState = technicalState_p;
      _replayableState = replayable_p;
      _asynchronousState = asynchronous_p;
    }
  }

  /**
   * Defines the structure of the returned object in PEI0147_BL001_VerifierDonnes
   *
   * @author kbettenc
   * @version ($Revision$ $Date$)
   */
  static class BL001_VerifierDonneesReturn extends AbstractBLReturn
  {

    /**
     *
     */
    private static final long serialVersionUID = -5785298431451984689L;

    /**
     * The clientOperateur
     */
    private String _clientOperateur;

    /**
     * The account number
     */
    private String _noCompte;

    /**
     * The status
     */
    private String _statut;

    /**
     * The main mail address
     */
    private String _mailPrincipal;

    /**
     * The secondary mail address
     */
    private String _mailSecondaire;

    /**
     * The trace
     */
    private Tracabilite _tracabilite;

    /**
     * @param retour_p
     *          retour
     */
    public BL001_VerifierDonneesReturn(Retour retour_p)
    {
      super(retour_p);
    }

    /**
     * @param retour_p
     *          The Retour object
     * @param clientOperateur_p
     *          The clientOperateur
     * @param noCompte_p
     *          The account number
     * @param statut_p
     *          The status
     * @param mailPrincipal_p
     *          The main mail address
     * @param mailSecondaire_p
     *          The secondary mail address
     * @param tracabilite_p
     *          The trace
     */
    public BL001_VerifierDonneesReturn(Retour retour_p, String clientOperateur_p, String noCompte_p, String statut_p, String mailPrincipal_p, String mailSecondaire_p, Tracabilite tracabilite_p)
    {
      super(retour_p);
      _clientOperateur = clientOperateur_p;
      _noCompte = noCompte_p;
      _statut = statut_p;
      _mailPrincipal = mailPrincipal_p;
      _mailSecondaire = mailSecondaire_p;
      _tracabilite = tracabilite_p;
    }

    /**
     * @return the clientOperateur
     */
    public String getClientOperateur()
    {
      return _clientOperateur;
    }

    /**
     * @return the mailPrincipal
     */
    public String getMailPrincipal()
    {
      return _mailPrincipal;
    }

    /**
     * @return the mailSecondaire
     */
    public String getMailSecondaire()
    {
      return _mailSecondaire;
    }

    /**
     * @return the noCompte
     */
    public String getNoCompte()
    {
      return _noCompte;
    }

    /**
     * @return the statut
     */
    public String getStatut()
    {
      return _statut;
    }

    /**
     * @return the tracabilite
     */
    public Tracabilite getTracabilite()
    {
      return _tracabilite;
    }
  }

  /**
   * Constant for SA name MAIL
   */
  private static final String SA_MAIL = "MAIL"; //$NON-NLS-1$

  /**
   *
   */
  private static final long serialVersionUID = -3724459517342674317L;

  /**
   * PEP0147_GERERMAILSECONDAIRE
   */
  private static final String PEP0147_GERERMAILSECONDAIRE = "PEP0147_GererMailSecondaire"; //$NON-NLS-1$

  /**
   * DECLENCHEMENT_PEP
   */
  private static final String DECLENCHEMENT_PEP = "declenchementPEP"; //$NON-NLS-1$

  /**
   * The process context.
   */
  private PEI0147_GererMailSecondaireContext _processContext;

  @Override
  public String createDefaultFunctionalResponse(Retour retour_p) throws RavelException
  {
    return ""; //$NON-NLS-1$
  }

  @Override
  public String getInternalState()
  {
    return _processContext.getState().toString();
  }

  @Override
  public Duration getSleepTime()
  {
    return Duration.ofMinutes(0);
  }

  @Override
  public MandatoryProcessState getTechnicalState()
  {
    return _processContext.getState()._technicalState;
  }

  @Override
  public void initializeContext()
  {
    _processContext = new PEI0147_GererMailSecondaireContext();
  }

  @Override
  public boolean isAsynchronous()
  {
    return _processContext.getState()._asynchronousState;

  }

  @Override
  public boolean isReplayable()
  {
    return _processContext.getState()._replayableState;
  }

  @Override
  @LogContinueProcess
  protected void continueProcess(Request request_p, Tracabilite tracabilite_p) throws RavelException
  {
    Retour retour = RetourFactory.createNOK(IMegConsts.CAT1, IMegConsts.ERREUR_TECHNIQUE, ""); //$NON-NLS-1$
    if (State.PEI0147_SI001.equals(_processContext.getState()))
    {
      if ((_processContext.getResponseErreur() == null) && _processContext.isDeclenchementPep())
      {
        final List<String> keys = Arrays.asList(IRefFoncConstants.ID_CMD);
        final List<String> values = Arrays.asList(_processContext.getCommande().getIdCmd());

        PROV_SI001_LancerOrchestrateur provSI001 = new PROV_SI001_LancerOrchestrateurBuilder().tracabilite(tracabilite_p) //set tracabilite
            .cles(_processContext.getCommande().getListeCleSequencement())//set cles
            .priorite(10) //set priority
            .type(IMegSpiritConsts.CONTINUER_PROCESSUS) //set action type
            .processus(PEP0147_GERERMAILSECONDAIRE)//set PEP process name
            .noms(keys) //set key names
            .valeurs(values) //set values
            .build();
        provSI001.execute(this);

        retour = provSI001.getRetour();
      }
      else
      {
        retour = RetourFactory.createOkRetour();
      }

      _processContext.setState(State.PEI0147_BL005);
      PEI0147_BL005_GererErreurPROSPER(tracabilite_p, retour);
    }
    _processContext.setState(State.ENDED);
    setRetour(retour);
  }

  @Override
  protected void exitKOMetroLog(String reason_p)
  {
    // Not required for now in Ravel

  }

  /**
   * get Config parameters in the processContext
   */
  protected void getConfigParam()
  {
    String declenchement = getConfigParameter(DECLENCHEMENT_PEP);
    if ((declenchement != null) && !StringConstants.EMPTY_STRING.equals(declenchement))
    {
      boolean declench = Boolean.parseBoolean(declenchement);
      _processContext.setDeclenchementPep(declench);
    }
    else
    {
      _processContext.setDeclenchementPep(false);
    }

  }

  @Override
  protected void startMetroLog()
  {
    // Not required for now in Ravel

  }

  @Override
  @LogStartProcess
  protected void startProcess(Request request_p, Tracabilite tracabilite_p) throws RavelException
  {
    try
    {
      getConfigParam();

      _processContext.setState(State.PEI0147_BL001);
      BL001_VerifierDonneesReturn bl001Retour = PEI0147_BL001_VerifierDonnees(tracabilite_p, request_p);
      _processContext.setRetour(bl001Retour.getRetour());

      if (isRetourOK(bl001Retour.getRetour()))
      {
        if (Statut.ACTIF.name().equals(bl001Retour.getStatut()))
        {
          _processContext.setState(State.PEI0147_SI009);
          OSSFAI_SI009_ReserveAdresseMailSecondaire ossfai_SI009 = new OSSFAI_SI009_ReserveAdresseMailSecondaireBuilder().tracabilite(tracabilite_p).adresseMail(bl001Retour.getMailSecondaire()).build();
          ossfai_SI009.execute(this);
          _processContext.setRetour(ossfai_SI009.getRetour());
        }

        if (isRetourOK(_processContext.getRetour()))
        {
          _processContext.setState(State.PEI0147_BL100);
          Pair<Commande, Retour> bl100 = PEI0147_BL100_SauvegarderCmd(tracabilite_p, _processContext.getGererMailSecondaireRequest(), bl001Retour.getClientOperateur(), bl001Retour.getNoCompte());
          if (isRetourOK(bl100._second))
          {
            _processContext.setCommande(bl100._first);
          }
          _processContext.setRetour(bl100._second);
        }
      }
    }
    catch (Exception ex)
    {
      Retour retour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, ex.getMessage());
      _processContext.setRetour(retour);
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, ex));
    }
    finally
    {
      _processContext.setState(State.PEI0147_BL002);
      ReponseErreur bl002Retour = PEI0147_BL002_FormaterReponse(tracabilite_p, _processContext.getRetour());

      syncResponse(request_p, tracabilite_p, bl002Retour);

      setRetour(_processContext.getRetour());
      _processContext.setState(State.PEI0147_SI001);
    }
  }

  /**
   * Verification contrainte sur l'objet Request
   *
   * @param tracabilite_p
   *          tracabilité
   * @param serviceGererMailSecondaireRequest_p
   *          serviceGererMailSecondaireRequest_p
   * @return retour
   */
  private Retour checkConstraintOnRequest(Tracabilite tracabilite_p, ServiceMailGererMailSecondaireRequest serviceGererMailSecondaireRequest_p)
  {
    Retour retour = RetourFactory.createOkRetour();

    if (serviceGererMailSecondaireRequest_p != null)
    {
      ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
      Validator validator = factory.getValidator();
      Set<ConstraintViolation<ServiceMailGererMailSecondaireRequest>> constraintViolations = validator.validate(serviceGererMailSecondaireRequest_p);
      if (!constraintViolations.isEmpty())
      {
        StringBuilder requiredAttrSb = new StringBuilder();
        StringBuilder formatErrAttrSb = new StringBuilder();
        StringBuilder invalidAttrSb = new StringBuilder();
        for (ConstraintViolation<ServiceMailGererMailSecondaireRequest> c : constraintViolations)
        {
          if (IMessageFormatKeys.REQUIRED_FILED.equals(c.getMessage()))
          {
            requiredAttrSb.append("[").append(c.getPropertyPath()).append("]"); //$NON-NLS-1$ //$NON-NLS-2$
          }
          if (IMessageFormatKeys.INVALID_FORMAT.equals(c.getMessage()))
          {
            formatErrAttrSb.append("[").append(c.getPropertyPath()).append("]"); //$NON-NLS-1$ //$NON-NLS-2$
          }
          if (IMessageFormatKeys.INVALID_FIELD_VALUE.equals(c.getMessage()))
          {
            invalidAttrSb.append("[").append(c.getPropertyPath()).append("]"); //$NON-NLS-1$ //$NON-NLS-2$
          }
        }
        StringBuilder validationMessageSb = new StringBuilder();
        if (StringTools.isNotNullOrEmpty(requiredAttrSb.toString()))
        {
          validationMessageSb.append(MessageFormat.format(Messages.getString(IMessageFormatKeys.REQUIRED_FILED), requiredAttrSb.toString()));
        }
        if (StringTools.isNotNullOrEmpty(formatErrAttrSb.toString()))
        {
          validationMessageSb.append(MessageFormat.format(Messages.getString(IMessageFormatKeys.INVALID_FORMAT), formatErrAttrSb.toString()));
        }
        if (StringTools.isNotNullOrEmpty(invalidAttrSb.toString()))
        {
          validationMessageSb.append(MessageFormat.format(Messages.getString(IMessageFormatKeys.INVALID_FIELD_VALUE), invalidAttrSb.toString()));
        }

        RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, validationMessageSb.toString()));
        retour = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, validationMessageSb.toString());

      }
      factory.close();
    }
    return retour;
  }

  /**
   * @param tracabilite_p
   *          The trace
   * @param request_p
   *          The request
   *
   * @return The retour
   */
  private Retour checkHeaders(Tracabilite tracabilite_p, final Request request_p)
  {
    String clientOperateur = null;
    String source = null;
    String process = null;

    for (RavelRequest.RequestHeader header : request_p.getRequestHeader())
    {
      if (IHttpHeadersConsts.X_CLIENT_OPERATEUR.equalsIgnoreCase(header.getName()))
      {
        clientOperateur = header.getValue();
      }
      else if (IHttpHeadersConsts.X_PROCESS.equalsIgnoreCase(header.getName()))
      {
        process = header.getValue();
      }
      else if (IHttpHeadersConsts.X_SOURCE.equalsIgnoreCase(header.getName()))
      {
        source = header.getValue();
      }
    }

    if (StringTools.isNullOrEmpty(clientOperateur))
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, MessageFormat.format(Messages.getString("PEI0147.BL001.HeaderNullOrEmpty"), IHttpHeadersConsts.X_CLIENT_OPERATEUR))); //$NON-NLS-1$
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString("PEI0147.BL001.HeaderNullOrEmpty"), IHttpHeadersConsts.X_CLIENT_OPERATEUR)); //$NON-NLS-1$
    }
    if (StringTools.isNullOrEmpty(source))
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, MessageFormat.format(Messages.getString("PEI0147.BL001.HeaderNullOrEmpty"), IHttpHeadersConsts.X_SOURCE))); //$NON-NLS-1$
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString("PEI0147.BL001.HeaderNullOrEmpty"), IHttpHeadersConsts.X_SOURCE)); //$NON-NLS-1$
    }
    if (StringTools.isNullOrEmpty(process))
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, MessageFormat.format(Messages.getString("PEI0147.BL001.HeaderNullOrEmpty"), IHttpHeadersConsts.X_PROCESS))); //$NON-NLS-1$
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString("PEI0147.BL001.HeaderNullOrEmpty"), IHttpHeadersConsts.X_PROCESS)); //$NON-NLS-1$
    }
    if (StringTools.isNullOrEmpty(tracabilite_p.getIdCorrelationByTel()))
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, MessageFormat.format(Messages.getString("PEI0147.BL001.HeaderNullOrEmpty"), IHttpHeadersConsts.X_REQUEST_ID))); //$NON-NLS-1$
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString("PEI0147.BL001.HeaderNullOrEmpty"), IHttpHeadersConsts.X_REQUEST_ID)); //$NON-NLS-1$
    }
    if (StringTools.isNullOrEmpty(getMessageId()))
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, MessageFormat.format(Messages.getString("PEI0147.BL001.HeaderNullOrEmpty"), IHttpHeadersConsts.X_MESSAGE_ID))); //$NON-NLS-1$
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString("PEI0147.BL001.HeaderNullOrEmpty"), IHttpHeadersConsts.X_MESSAGE_ID)); //$NON-NLS-1$
    }

    _processContext.setXClientOperateur(clientOperateur);

    return RetourFactory.createOkRetour();
  }

  /**
   *
   * @param tracabilite_p
   *          The trace
   * @param request_p
   *          The request
   * @return
   *
   * @throws RavelException
   *           on errors
   */
  @LogProcessBL
  private BL001_VerifierDonneesReturn PEI0147_BL001_VerifierDonnees(Tracabilite tracabilite_p, final Request request_p) throws RavelException
  {
    Retour retour = RetourFactory.createOkRetour();
    ServiceMailGererMailSecondaireRequest gererMailSecondaireRequest = null;

    /*---------- Vérification headers et STI ----------*/
    try
    {
      retour = checkHeaders(tracabilite_p, request_p);

      //check STI
      if (isRetourOK(retour))
      {
        gererMailSecondaireRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ, DateTimeFormatPattern.yyyy_dash_MM_dash_dd).fromJson(request_p.getPayload(), ServiceMailGererMailSecondaireRequest.class);
        retour = checkConstraintOnRequest(tracabilite_p, gererMailSecondaireRequest);
      }
    }
    catch (Exception e)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, Messages.getString("PEI0147.BL001.StiError") + "\\n" + ExceptionTools.getStringStackTrace(e))); //$NON-NLS-1$ //$NON-NLS-2$
      retour = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, Messages.getString("PEI0147.BL001.StiError")); //$NON-NLS-1$
    }

    if (!RetourFactory.isRetourOK(retour) || (gererMailSecondaireRequest == null))
    {
      return new BL001_VerifierDonneesReturn(retour);
    }

    _processContext.setGererMailSecondaireRequest(gererMailSecondaireRequest);

    /*---------- Récupération des données pour la sortie ----------*/
    String mailPrincipal = gererMailSecondaireRequest.getIdentifiantAcces().getLoginMail();
    String mailSecondaire = gererMailSecondaireRequest.getMailSecondaire().getMail();
    String statut = gererMailSecondaireRequest.getMailSecondaire().getStatut();

    BL3700_RecupererPfiParMail bl3700 = new BL3700_RecupererPfiParMailBuilder().tracabilite(tracabilite_p).mail(mailPrincipal).build();
    BL3700_Return bl3700Return = bl3700.execute(this);
    retour = bl3700.getRetour();

    PFI pfi = null;

    String clientOperateur = null;
    String noCompte = null;

    if (isRetourOK(retour))
    {
      clientOperateur = bl3700Return.getClientOperateur();
      noCompte = bl3700Return.getNoCompte();

      ConnectorResponse<Retour, PFI> rpg = RPGProxy.getInstance().pfiLireUn(tracabilite_p, clientOperateur, noCompte);
      retour = rpg._first;
      pfi = rpg._second;
    }

    if (!isRetourOK(retour))
    {
      if (IMegConsts.DONNEE_INCONNUE.equals(retour.getDiagnostic()))
      {
        retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.MAIL_INCONNU, MessageFormat.format(Messages.getString("PEI0147.BL001.MailPrincipalInconnu"), mailPrincipal)); //$NON-NLS-1$
      }
      return new BL001_VerifierDonneesReturn(retour);
    }

    if (pfi != null)
    {
      //Find PA COMPTE_ACCES in the PFI PA list
      List<PA> paCompteAccesList = PFIUtils.filterPA(pfi, new PFIFilter(PFIFilterOption.TYPE_PA, TypePA.COMPTE_ACCES.name()), new PFIFilter(PFIFilterOption.STATUT, Statut.ACTIF.name()));

      if (paCompteAccesList.isEmpty()) //PA not found
      {
        retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.MAIL_INCONNU, MessageFormat.format(Messages.getString("PEI0147.BL001.MailInexistantOuResilie"), mailPrincipal)); //$NON-NLS-1$
        return new BL001_VerifierDonneesReturn(retour, clientOperateur, noCompte, statut, mailPrincipal, mailSecondaire, tracabilite_p);
      }

      //only for activation
      if (Statut.ACTIF.name().equals(statut))
      {
        List<SA> saMailList = PFIUtils.filterSA(pfi, new PFIFilter(PFIFilterOption.NOM_SA, SA_MAIL), new PFIFilter(PFIFilterOption.STATUT, Statut.ACTIF.name()));

        //SA Mail not found
        if (saMailList.isEmpty())
        {
          retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.MAIL_INCONNU, MessageFormat.format(Messages.getString("PEI0147.BL001.MailRestreint"), mailPrincipal)); //$NON-NLS-1$
        }
      }
    }

    Map<String, String> refFonc = new HashMap<>();
    refFonc.put(IRefFoncConstants.CLI_OPE, clientOperateur);
    refFonc.put(IRefFoncConstants.NO_COMPTE, noCompte);
    BL1700_AjouterRefFonc bl1700 = new BL1700_AjouterRefFoncBuilder().tracabilite(tracabilite_p).refFonc(refFonc).build();
    bl1700.execute(this);

    return new BL001_VerifierDonneesReturn(retour, clientOperateur, noCompte, statut, mailPrincipal, mailSecondaire, tracabilite_p);
  }

  /**
   * Format response to the client
   *
   * @param retour_p
   *          Result of bl001.
   * @param tracabilite_p
   *          Tracabilite
   * @return retour
   */
  @LogProcessBL
  private ReponseErreur PEI0147_BL002_FormaterReponse(Tracabilite tracabilite_p, Retour retour_p)
  {
    ReponseErreur response = null;
    if (!isRetourOK(retour_p))
    {
      response = new ReponseErreur();
      switch (retour_p.getCategorie())
      {
        case IMegConsts.CAT3:
          response.setError(IMegSpiritConsts.NON_RESPECT_STI);
          response.setErrorDescription(MessageFormat.format(Messages.getString("PEI0147.BL002.ErrorDescription"), retour_p.getLibelle(), retour_p.getDiagnostic())); //$NON-NLS-1$
          break;
        case IMegConsts.CAT4:
          switch (retour_p.getDiagnostic())
          {
            case IMegSpiritConsts.COMMANDE_EXISTANTE:
              // ok
              break;
            case IMegSpiritConsts.DONNEE_EXISTANTE:
              response.setError(IMegSpiritConsts.MAIL_SECONDAIRE_DEJA_UTILISE);
              response.setErrorDescription(MessageFormat.format(Messages.getString("PEI0147.BL002.ErrorDescription"), retour_p.getLibelle(), retour_p.getDiagnostic())); //$NON-NLS-1$
              break;
            case IMegSpiritConsts.DONNEE_INVALIDE:
              response.setError(IMegSpiritConsts.NON_RESPECT_STI);
              response.setErrorDescription(MessageFormat.format(Messages.getString("PEI0147.BL002.ErrorDescriptionMailNonReserve"), retour_p.getLibelle(), retour_p.getDiagnostic())); //$NON-NLS-1$
              break;
            case IMegSpiritConsts.MAIL_INCONNU:
              response.setError(IMegSpiritConsts.MAIL_INCONNU);
              response.setErrorDescription(MessageFormat.format(Messages.getString("PEI0147.BL002.ErrorDescription"), retour_p.getLibelle(), retour_p.getDiagnostic())); //$NON-NLS-1$
              break;
          }
          break;
        default:
          response.setError(IMegSpiritConsts.ERREUR_INTERNE);
          response.setErrorDescription(retour_p.getLibelle());
          break;
      }
      _processContext.setResponseErreur(response);
    }

    return response;
  }

  /**
   * BL005
   *
   * @param retour_p
   *          The Retour
   * @return If retour.resultat == NOK BL4600 -> retour, else -> the Retour
   * @throws RavelException
   */
  @LogProcessBL
  private Retour PEI0147_BL005_GererErreurPROSPER(Tracabilite tracabilite_p, final Retour retour_p) throws RavelException
  {
    if (StringConstants.NOK.equals(retour_p.getResultat()))
    {
      // call activite BL4600
      BL4600_CreerErreurSpirit bl4600 = new BL4600_CreerErreurSpiritBuilder().tracabilite(tracabilite_p).retour(retour_p).build();
      bl4600.execute(this);
      return bl4600.getRetour();
    }
    return retour_p;
  }

  /**
   * PEI0147_BL100_SauvegarderCmd
   *
   * @param tracabilite_p
   *          tracabilite
   * @param serviceMailSecondaire_p
   *          ServiceMailGererMailSecondaireRequest
   * @param clientOperateur_p
   *          clientOperateur
   * @param noCompte_p
   *          compte
   * @return
   * @throws RavelException
   *           exception when error
   */
  @LogProcessBL
  private Pair<Commande, Retour> PEI0147_BL100_SauvegarderCmd(Tracabilite tracabilite_p, final ServiceMailGererMailSecondaireRequest serviceMailSecondaire_p, String clientOperateur_p, String noCompte_p) throws RavelException
  {

    Retour retour = null;
    Pair<Commande, Retour> retourBL101 = PEI0147_BL101_PreparerCmd(tracabilite_p, serviceMailSecondaire_p, clientOperateur_p, noCompte_p);
    Commande commande = retourBL101._first;
    retour = retourBL101._second;
    if (commande != null)
    {
      CMDProxy cmdCommand = CMDProxy.getInstance();
      CreateCommandeRequest createCommandRequest = new CreateCommandeRequest(commande);
      ConnectorResponse<Retour, Nothing> resultCmd = cmdCommand.commandeCreer(tracabilite_p, createCommandRequest);
      retour = resultCmd._first;
      if (isRetourOK(retour))
      {

        Map<String, String> refFonc = new HashMap<>();
        refFonc.put(IRefFoncConstants.ID_CMD, commande.getIdCmd());
        BL1700_AjouterRefFonc bl1700 = new BL1700_AjouterRefFonc.BL1700_AjouterRefFoncBuilder()//initialize builder
            .tracabilite(tracabilite_p).refFonc(refFonc).build();
        bl1700.execute(this);
      }
    }
    Pair<Commande, Retour> retourBL100 = new Pair<Commande, Retour>(commande, retour);
    return retourBL100;

  }

  /**
   * PEI147_BL101_PreparerCmd
   *
   * @param tracabilite_p
   *          tracabilite
   * @param serviceMailSecondaire_p
   *          the serviceMailSecondaire
   * @param noCompte_p
   *          noCompte
   * @return
   * @throws RavelException
   *           Exception
   */
  @LogProcessBL
  private Pair<Commande, Retour> PEI0147_BL101_PreparerCmd(Tracabilite tracabilite_p, final ServiceMailGererMailSecondaireRequest serviceMailSecondaire_p, String clientOperateur_p, String noCompte_p) throws RavelException
  {

    Pair<Commande, Retour> retourBL101 = null;
    BL800_ObtenirSequence bl800 = new BL800_ObtenirSequence.BL800_ObtenirSequenceBuilder().code(UniqueIdConstant.ID_CMD_GP).tracabilite(tracabilite_p).build();
    String idCmd = bl800.execute(this);
    Retour retour = bl800.getRetour();
    Commande commande = new Commande();
    commande.setIdCmd(idCmd);

    LocalDateTime localDate = DateTimeManager.getInstance().now();

    commande.setIdExterne(tracabilite_p.getIdCorrelationByTel() + "-" + getMessageId()); //idCorrelationBytel = X-Request-Id (required header) //$NON-NLS-1$
    commande.setDateCommande(localDate);
    commande.setNatureCommande(IMegSpiritConsts.GESTION_BOITE_MAIL_SECONDAIRE);
    commande.setStatut(com.bytel.spirit.common.shared.saab.cmd.Statut.ACQUITTE.name());
    String json = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ, DateTimeFormatPattern.yyyy_dash_MM_dash_dd).toJson(serviceMailSecondaire_p);
    commande.setDonneesBrut(json);
    commande.setDateAcquittement(DateTimeManager.getInstance().now());
    commande.setNoCompte(noCompte_p);
    commande.setClientOperateur(clientOperateur_p);
    List<String> listsequence = new ArrayList<String>();
    String sequence = clientOperateur_p + noCompte_p;
    listsequence.add(sequence);
    commande.setListeCleSequencement(listsequence);
    retourBL101 = new Pair<Commande, Retour>(commande, retour);

    return retourBL101;
  }

  /**
   * send a sync response for requester.
   *
   * @param request_p
   *          The request object
   * @param tracabilite_p
   *          Tracabilite
   * @param reponserreur_p
   *          the reponserreur
   */
  private void syncResponse(Request request_p, Tracabilite tracabilite_p, ReponseErreur reponserreur_p)
  {
    if (request_p != null)
    {
      IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
      Response rsp = null;

      if (reponserreur_p != null)
      {
        ravelResponse.setDataType(HttpConstants.CONTENT_TYPE_JSON);
        ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(reponserreur_p));
        ErrorCode errorCode = ErrorCode.KO_00500; //Unknown error

        if (IMegSpiritConsts.NON_RESPECT_STI.equals(reponserreur_p.getError()))
        {
          errorCode = ErrorCode.KO_00400;
        }
        else if (IMegSpiritConsts.MAIL_SECONDAIRE_DEJA_UTILISE.equals(reponserreur_p.getError()) || IMegSpiritConsts.MAIL_INCONNU.equals(reponserreur_p.getError()))
        {
          errorCode = ErrorCode.KO_00404;
        }

        rsp = new Response(errorCode, ravelResponse);

      }
      else
      {
        //Add empty Json in case OK
        ravelResponse.setDataType(HttpConstants.CONTENT_TYPE_JSON);
        rsp = new Response(ErrorCode.OK_00204, ravelResponse);
      }

      request_p.setResponse(rsp);
      //log response
      SpiritLogEvent logEvent = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, "PEI0147 response"); //$NON-NLS-1$
      logEvent.addField(IMegConsts.RESULTAT, ravelResponse.getResult(), false);
      RavelLogger.log(logEvent);

    }
  }
}
