/*******************************************************************************
* $Id: PI0035_StPfsHSSFixe.java 23286 2019-06-28 09:38:54Z jgregori $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PI0035.sti;

import java.time.LocalDateTime;

import com.bytel.spirit.common.shared.functional.types.json.st.pfs.TypePFS;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.hssfixe.StPfsHSSFixe;
import com.squareup.moshi.Json;

/**
 *
 * @author kbettenc
 * @version ($Revision: 23286 $ $Date: 2019-06-28 11:38:54 +0200 (ven. 28 juin 2019) $)
 */
public class PI0035_StPfsHSSFixe extends PI0035_AbstractStPfs
{

  /**
   *
   */
  private static final long serialVersionUID = -1677447848059495794L;

  /**
   * Builds a new instance of {@link PI0035_StPfsHSSFixe} from an instance of {@link StPfsHSSFixe}
   *
   * @param stPfsHSSFixe_p
   *          The instance of {@link StPfsHSSFixe}.
   * @return The instance of {@link PI0035_StPfsHSSFixe}.
   */
  public static PI0035_StPfsHSSFixe buildFromStPfsHSSFixe(StPfsHSSFixe stPfsHSSFixe_p)
  {
    PI0035_DonneesIdentificationStPfsHSSFixe donneesIdentificationStPfsHSSFixe = new PI0035_DonneesIdentificationStPfsHSSFixe(stPfsHSSFixe_p.getDonneesIdentificationStPfsHSSFixe().getIdentifiantFonctionnelPA());

    PI0035_DonneesProvisionneesStPfsHSSFixe donneesProvisionneesStPfsHSSFixe = null;
    if (stPfsHSSFixe_p.getDonneesProvisionneesStPfsHSSFixe() != null)
    {
      donneesProvisionneesStPfsHSSFixe = new PI0035_DonneesProvisionneesStPfsHSSFixe(stPfsHSSFixe_p.getDonneesProvisionneesStPfsHSSFixe().getIdCompteIms(), //
          stPfsHSSFixe_p.getDonneesProvisionneesStPfsHSSFixe().getNoTelephone(), //
          stPfsHSSFixe_p.getDonneesProvisionneesStPfsHSSFixe().getTypeUsage(), //
          stPfsHSSFixe_p.getDonneesProvisionneesStPfsHSSFixe().getImpiFixe(), //
          stPfsHSSFixe_p.getDonneesProvisionneesStPfsHSSFixe().getMotDePasseIms(), //
          stPfsHSSFixe_p.getDonneesProvisionneesStPfsHSSFixe().getSipUri(), //
          stPfsHSSFixe_p.getDonneesProvisionneesStPfsHSSFixe().getTelUri(), //
          stPfsHSSFixe_p.getDonneesProvisionneesStPfsHSSFixe().getNomPrenomCourt(), //
          stPfsHSSFixe_p.getDonneesProvisionneesStPfsHSSFixe().getCodeInsee());
    }

    return new PI0035_StPfsHSSFixe(stPfsHSSFixe_p.getIdSt(), stPfsHSSFixe_p.getStatut(), stPfsHSSFixe_p.getDateCreation(), stPfsHSSFixe_p.getDateModification(), donneesIdentificationStPfsHSSFixe, donneesProvisionneesStPfsHSSFixe);
  }

  /**
   * Donnes Identification
   */
  @Json(name = "donneesIdentification")
  private PI0035_DonneesIdentificationStPfsHSSFixe _donneesIdentification;

  /**
   * Donnes Provisionnees
   */
  @Json(name = "donneesProvisionnees")
  private PI0035_DonneesProvisionneesStPfsHSSFixe _donneesProvisionnees;

  /**
   * @param idSt_p
   * @param statut_p
   * @param dateCreation_p
   * @param dateModification_p
   * @param donneesIdentificationStPfsHSSFixe_p
   * @param donneesProvisionneesStPfsHSSFixe_p
   */
  public PI0035_StPfsHSSFixe(String idSt_p, String statut_p, LocalDateTime dateCreation_p, LocalDateTime dateModification_p, PI0035_DonneesIdentificationStPfsHSSFixe donneesIdentificationStPfsHSSFixe_p, PI0035_DonneesProvisionneesStPfsHSSFixe donneesProvisionneesStPfsHSSFixe_p)
  {
    super(idSt_p, statut_p, TypePFS.HSS_FIXE.name(), dateCreation_p, dateModification_p);
    _donneesIdentification = donneesIdentificationStPfsHSSFixe_p;
    _donneesProvisionnees = donneesProvisionneesStPfsHSSFixe_p;
  }

  /**
   * @return the donneesIdentification
   */
  public PI0035_DonneesIdentificationStPfsHSSFixe getDonneesIdentification()
  {
    return _donneesIdentification;
  }

  /**
   * @return the donneesProvisionnees
   */
  public PI0035_DonneesProvisionneesStPfsHSSFixe getDonneesProvisionnees()
  {
    return _donneesProvisionnees;
  }

  /**
   * @param donneesIdentification_p
   *          the donneesIdentification to set
   */
  public void setDonneesIdentification(PI0035_DonneesIdentificationStPfsHSSFixe donneesIdentification_p)
  {
    _donneesIdentification = donneesIdentification_p;
  }

  /**
   * @param donneesProvisionnees_p
   *          the donneesProvisionnees to set
   */
  public void setDonneesProvisionnees(PI0035_DonneesProvisionneesStPfsHSSFixe donneesProvisionnees_p)
  {
    _donneesProvisionnees = donneesProvisionnees_p;
  }

  @Override
  public String toString()
  {
    StringBuilder builder = new StringBuilder();
    builder.append("PI0035_StPfsHSSFixe [_donneesIdentification="); //$NON-NLS-1$
    builder.append(_donneesIdentification);
    builder.append(", _donneesProvisionnees="); //$NON-NLS-1$
    builder.append(_donneesProvisionnees);
    builder.append(", getCommentaire()="); //$NON-NLS-1$
    builder.append(getCommentaire());
    builder.append(", getDateCreation()="); //$NON-NLS-1$
    builder.append(getDateCreation());
    builder.append(", getDateModification()="); //$NON-NLS-1$
    builder.append(getDateModification());
    builder.append(", getIdSt()="); //$NON-NLS-1$
    builder.append(getIdSt());
    builder.append(", getStatut()="); //$NON-NLS-1$
    builder.append(getStatut());
    builder.append(", getTypeServiceTechnique()="); //$NON-NLS-1$
    builder.append(getTypeServiceTechnique());
    builder.append("]"); //$NON-NLS-1$
    return builder.toString();
  }
}
