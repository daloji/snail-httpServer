/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PI0035.sti;

import java.io.Serializable;
import java.time.LocalDateTime;

import javax.validation.constraints.NotNull;

import com.bytel.ravel.common.json.annotations.RavelLocalDateTimeFormat;
import com.bytel.ravel.common.json.format.impl.IsoShortOffsetDateTimeWithMillis;
import com.bytel.spirit.common.shared.saab.cmd.ModificationTechnique;
import com.squareup.moshi.Json;

/**
 *
 * @author jgregori
 * @version ($Revision$ $Date$)
 */
public class PI0035_ModificationTechnique implements Serializable
{

  /**
   *
   */
  private static final long serialVersionUID = -1047837669414258963L;

  /**
   * @param modTech_p
   * @return
   */
  public static PI0035_ModificationTechnique builfFromModificationTechnique(ModificationTechnique modTech_p)
  {
    PI0035_ModificationTechnique modTech = new PI0035_ModificationTechnique(modTech_p.getIdModificationTechnique(), modTech_p.getStatut(), modTech_p.getIdCmd(), modTech_p.getDateCreation(), modTech_p.getDateModification());
    modTech.setIdSt(modTech_p.getIdSt());
    return modTech;
  }

  /**
   * Identifier of ModificationTechnique
   */
  @Json(name = "idModificationTechnique")
  private String _idModificationTechnique;

  /**
   * Statut of ModificationTechnique
   */
  @Json(name = "statut")
  private String _statut;

  /**
   * Identifier of command
   */
  @Json(name = "idCmd")
  private String _idCmd;

  /**
   * Identifier of ServiceTechnique
   */
  @Json(name = "idSt")
  private String _idSt;

  /**
   * Date of creation
   */
  @Json(name = "dateCreation")
  @RavelLocalDateTimeFormat(IsoShortOffsetDateTimeWithMillis.class)
  private LocalDateTime _dateCreation;

  /**
   * Date of modification
   */
  @Json(name = "dateModification")
  @RavelLocalDateTimeFormat(IsoShortOffsetDateTimeWithMillis.class)
  private LocalDateTime _dateModification;

  /**
   *
   */
  public PI0035_ModificationTechnique()
  {
    super();
  }

  /**
   * @param idModificationTechnique_p
   * @param statut_p
   * @param idCmd_p
   * @param dateCreation_p
   * @param dateModification_p
   */
  public PI0035_ModificationTechnique(@NotNull(message = "Validation.RequiredField") String idModificationTechnique_p, @NotNull(message = "Validation.RequiredField") String statut_p, @NotNull(message = "Validation.RequiredField") String idCmd_p, @NotNull(message = "Validation.RequiredField") LocalDateTime dateCreation_p, @NotNull(message = "Validation.RequiredField") LocalDateTime dateModification_p)
  {
    super();

    _idModificationTechnique = idModificationTechnique_p;
    _statut = statut_p;
    _idCmd = idCmd_p;
    _dateCreation = dateCreation_p;
    _dateModification = dateModification_p;
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    PI0035_ModificationTechnique other = (PI0035_ModificationTechnique) obj;
    if (_dateCreation == null)
    {
      if (other._dateCreation != null)
      {
        return false;
      }
    }
    else if (!_dateCreation.equals(other._dateCreation))
    {
      return false;
    }
    if (_dateModification == null)
    {
      if (other._dateModification != null)
      {
        return false;
      }
    }
    else if (!_dateModification.equals(other._dateModification))
    {
      return false;
    }
    if (_idCmd == null)
    {
      if (other._idCmd != null)
      {
        return false;
      }
    }
    else if (!_idCmd.equals(other._idCmd))
    {
      return false;
    }
    if (_idModificationTechnique == null)
    {
      if (other._idModificationTechnique != null)
      {
        return false;
      }
    }
    else if (!_idModificationTechnique.equals(other._idModificationTechnique))
    {
      return false;
    }
    if (_idSt == null)
    {
      if (other._idSt != null)
      {
        return false;
      }
    }
    else if (!_idSt.equals(other._idSt))
    {
      return false;
    }
    if (_statut == null)
    {
      if (other._statut != null)
      {
        return false;
      }
    }
    else if (!_statut.equals(other._statut))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the dateCreation
   */
  public LocalDateTime getDateCreation()
  {
    return _dateCreation;
  }

  /**
   * @return the dateModification
   */
  public LocalDateTime getDateModification()
  {
    return _dateModification;
  }

  /**
   * @return the idCmd
   */
  public String getIdCmd()
  {
    return _idCmd;
  }

  /**
   * @return the idModificationTechnique
   */
  public String getIdModificationTechnique()
  {
    return _idModificationTechnique;
  }

  /**
   * @return the idSt
   */
  public String getIdSt()
  {
    return _idSt;
  }

  /**
   * @return the statut
   */
  public String getStatut()
  {
    return _statut;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_dateCreation == null) ? 0 : _dateCreation.hashCode());
    result = (prime * result) + ((_dateModification == null) ? 0 : _dateModification.hashCode());
    result = (prime * result) + ((_idCmd == null) ? 0 : _idCmd.hashCode());
    result = (prime * result) + ((_idModificationTechnique == null) ? 0 : _idModificationTechnique.hashCode());
    result = (prime * result) + ((_idSt == null) ? 0 : _idSt.hashCode());
    result = (prime * result) + ((_statut == null) ? 0 : _statut.hashCode());
    return result;
  }

  /**
   * @param dateCreation_p
   *          the dateCreation to set
   */
  public void setDateCreation(LocalDateTime dateCreation_p)
  {
    _dateCreation = dateCreation_p;
  }

  /**
   * @param dateModification_p
   *          the dateModification to set
   */
  public void setDateModification(LocalDateTime dateModification_p)
  {
    _dateModification = dateModification_p;
  }

  /**
   * @param idCmd_p
   *          the idCmd to set
   */
  public void setIdCmd(String idCmd_p)
  {
    _idCmd = idCmd_p;
  }

  /**
   * @param idModificationTechnique_p
   *          the idModificationTechnique to set
   */
  public void setIdModificationTechnique(String idModificationTechnique_p)
  {
    _idModificationTechnique = idModificationTechnique_p;
  }

  /**
   * @param idSt_p
   *          the idSt to set
   */
  public void setIdSt(String idSt_p)
  {
    _idSt = idSt_p;
  }

  /**
   * @param statut_p
   *          the statut to set
   */
  public void setStatut(String statut_p)
  {
    _statut = statut_p;
  }

  @Override
  public String toString()
  {
    StringBuilder builder = new StringBuilder();
    builder.append("PI0035_ModificationTechnique [_idModificationTechnique="); //$NON-NLS-1$
    builder.append(_idModificationTechnique);
    builder.append(", _statut="); //$NON-NLS-1$
    builder.append(_statut);
    builder.append(", _idCmd="); //$NON-NLS-1$
    builder.append(_idCmd);
    builder.append(", _idSt="); //$NON-NLS-1$
    builder.append(_idSt);
    builder.append(", _dateCreation="); //$NON-NLS-1$
    builder.append(_dateCreation);
    builder.append(", _dateModification="); //$NON-NLS-1$
    builder.append(_dateModification);
    builder.append("]"); //$NON-NLS-1$
    return builder.toString();
  }
}
