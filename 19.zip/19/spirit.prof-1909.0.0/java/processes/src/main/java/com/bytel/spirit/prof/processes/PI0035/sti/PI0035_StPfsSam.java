/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PI0035.sti;

import java.time.LocalDateTime;

import com.bytel.spirit.common.shared.functional.types.json.st.pfs.TypePFS;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.sam.StPfsSam;
import com.bytel.spirit.common.shared.saab.rst.ServiceTechnique;
import com.squareup.moshi.Json;

/**
 *
 * @author pescudei
 * @version ($Revision$ $Date$)
 */
public class PI0035_StPfsSam extends PI0035_AbstractStPfs
{
  /**
   *
   */
  private static final long serialVersionUID = -2638573367373560885L;

  /**
   * Builds a new instance of {@link PI0035_StPfsSam} from an instance of {@link ServiceTechnique}
   *
   * @param stPfsSam_p
   *          The instance of {@link ServiceTechnique}.
   * @return The instance of {@link PI0035_StPfsSam}.
   */
  public static PI0035_StPfsSam buildFromStPfsSam(StPfsSam stPfsSam_p)
  {

    PI0035_DonneesIdentificationStPfsSam donneesIdent = new PI0035_DonneesIdentificationStPfsSam(stPfsSam_p.getDonneesIdentificationStPfsSam().getIdentifiantFonctionnelPa());

    PI0035_DonneesProvisionneesStPfsSam donneesProv = null;
    if (stPfsSam_p.getDonneesProvisionneesStPfsSam() != null)
    {
      donneesProv = new PI0035_DonneesProvisionneesStPfsSam(stPfsSam_p.getDonneesProvisionneesStPfsSam().getIdCompteIms(), //
          stPfsSam_p.getDonneesProvisionneesStPfsSam().getNoTelephone(), //
          stPfsSam_p.getDonneesProvisionneesStPfsSam().getTypeUsage(), //
          stPfsSam_p.getDonneesProvisionneesStPfsSam().getImpiFixe(), //
          stPfsSam_p.getDonneesProvisionneesStPfsSam().getMotDePasseIms(), //
          stPfsSam_p.getDonneesProvisionneesStPfsSam().getSipUri(), //
          stPfsSam_p.getDonneesProvisionneesStPfsSam().getTelUri(), //
          stPfsSam_p.getDonneesProvisionneesStPfsSam().getNom(), //
          stPfsSam_p.getDonneesProvisionneesStPfsSam().getPrenom(), //
          stPfsSam_p.getDonneesProvisionneesStPfsSam().getNomPrenomCourt(), //
          stPfsSam_p.getDonneesProvisionneesStPfsSam().getNiveauRestriction(), //
          stPfsSam_p.getDonneesProvisionneesStPfsSam().getNotificationSuspension(), //
          stPfsSam_p.getDonneesProvisionneesStPfsSam().getOptionAppelSurTaxes());
    }
    return new PI0035_StPfsSam(stPfsSam_p.getIdSt(), stPfsSam_p.getStatut(), stPfsSam_p.getDateCreation(), stPfsSam_p.getDateModification(), donneesIdent, donneesProv);
  }

  /**
   * Donnees Identification
   */
  @Json(name = "donneesIdentification")
  private PI0035_DonneesIdentificationStPfsSam _donneesIdentification;

  /**
   * Donnees Provisionnees
   */
  @Json(name = "donneesProvisionnees")
  private PI0035_DonneesProvisionneesStPfsSam _donneesProvisionnees;

  /**
   * @param idSt_p
   * @param statut_p
   * @param dateCreation_p
   * @param dateModification_p
   * @param donneesIdentification_p
   * @param donneesProvisionnees_p
   */
  public PI0035_StPfsSam(String idSt_p, String statut_p, LocalDateTime dateCreation_p, LocalDateTime dateModification_p, PI0035_DonneesIdentificationStPfsSam donneesIdentification_p, PI0035_DonneesProvisionneesStPfsSam donneesProvisionnees_p)
  {
    super(idSt_p, statut_p, TypePFS.SAM.name(), dateCreation_p, dateModification_p);

    _donneesIdentification = donneesIdentification_p;
    _donneesProvisionnees = donneesProvisionnees_p;

  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (!super.equals(obj))
    {
      return false;
    }
    if (getClass() != obj.getClass()) // NOSONAR
    {
      return false;
    }
    PI0035_StPfsSam other = (PI0035_StPfsSam) obj;
    if (_donneesIdentification == null)
    {
      if (other._donneesIdentification != null)
      {
        return false;
      }
    }
    else if (!_donneesIdentification.equals(other._donneesIdentification))
    {
      return false;
    }
    if (_donneesProvisionnees == null)
    {
      if (other._donneesProvisionnees != null)
      {
        return false;
      }
    }
    else if (!_donneesProvisionnees.equals(other._donneesProvisionnees))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the donneesIdentification
   */
  public PI0035_DonneesIdentificationStPfsSam getDonneesIdentification()
  {
    return _donneesIdentification;
  }

  /**
   * @return the donneesProvisionnes
   */
  public PI0035_DonneesProvisionneesStPfsSam getDonneesProvisionnees()
  {
    return _donneesProvisionnees;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = super.hashCode();
    result = (prime * result) + ((_donneesIdentification == null) ? 0 : _donneesIdentification.hashCode());
    result = (prime * result) + ((_donneesProvisionnees == null) ? 0 : _donneesProvisionnees.hashCode());
    return result;
  }

  /**
   * @param donneesIdentification_p
   *          the donneesIdentification to set
   */
  public void setDonneesIdentification(PI0035_DonneesIdentificationStPfsSam donneesIdentification_p)
  {
    _donneesIdentification = donneesIdentification_p;
  }

  /**
   * @param donneesProvisionnees_p
   *          the donneesProvisionnes to set
   */
  public void setDonneesProvisionnees(PI0035_DonneesProvisionneesStPfsSam donneesProvisionnees_p)
  {
    _donneesProvisionnees = donneesProvisionnees_p;
  }

  @Override
  public String toString()
  {
    StringBuilder builder = new StringBuilder();
    builder.append("PI0035_StPfsSam [_donneesIdentification="); //$NON-NLS-1$
    builder.append(_donneesIdentification);
    builder.append(", _donneesProvisionnees="); //$NON-NLS-1$
    builder.append(_donneesProvisionnees);
    builder.append(", getCommentaire()="); //$NON-NLS-1$
    builder.append(getCommentaire());
    builder.append(", getDateCreation()="); //$NON-NLS-1$
    builder.append(getDateCreation());
    builder.append(", getDateModification()="); //$NON-NLS-1$
    builder.append(getDateModification());
    builder.append(", getIdSt()="); //$NON-NLS-1$
    builder.append(getIdSt());
    builder.append(", getStatut()="); //$NON-NLS-1$
    builder.append(getStatut());
    builder.append(", getTypeServiceTechnique()="); //$NON-NLS-1$
    builder.append(getTypeServiceTechnique());
    builder.append("]"); //$NON-NLS-1$
    return builder.toString();
  }
}
