/*******************************************************************************
* $Id: PI0035_DonneesIdentificationStPfsTASFixe.java 23286 2019-06-28 09:38:54Z jgregori $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PI0035.sti;

import java.io.Serializable;

import com.squareup.moshi.Json;

/**
 *
 * @author kbettenc
 * @version ($Revision: 23286 $ $Date: 2019-06-28 11:38:54 +0200 (ven. 28 juin 2019) $)
 */
public class PI0035_DonneesIdentificationStPfsTASFixe implements Serializable
{

  /**
   *
   */
  private static final long serialVersionUID = -275370223707567756L;
  /**
   * Identifiant Fonctionnel PA
   */
  @Json(name = "identifiantFonctionnelPA")
  private String _identifiantFonctionnelPA;

  /**
   * @param identifiantFonctionnelPa_p
   */
  public PI0035_DonneesIdentificationStPfsTASFixe(final String identifiantFonctionnelPa_p)
  {
    super();
    _identifiantFonctionnelPA = identifiantFonctionnelPa_p;
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    PI0035_DonneesIdentificationStPfsTASFixe other = (PI0035_DonneesIdentificationStPfsTASFixe) obj;
    if (_identifiantFonctionnelPA == null)
    {
      if (other._identifiantFonctionnelPA != null)
      {
        return false;
      }
    }
    else if (!_identifiantFonctionnelPA.equals(other._identifiantFonctionnelPA))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the identifiantFonctionnelPA
   */
  public String getIdentifiantFonctionnelPA()
  {
    return _identifiantFonctionnelPA;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_identifiantFonctionnelPA == null) ? 0 : _identifiantFonctionnelPA.hashCode());
    return result;
  }

  /**
   * @param identifiantFonctionnelPA_p
   *          the identifiantFonctionnelPA to set
   */
  public void setIdentifiantFonctionnelPA(String identifiantFonctionnelPA_p)
  {
    _identifiantFonctionnelPA = identifiantFonctionnelPA_p;
  }

  @Override
  public String toString()
  {
    StringBuilder builder = new StringBuilder();
    builder.append("PI0035_DonneesIdentificationStPfsTASFixe [_identifiantFonctionnelPA="); //$NON-NLS-1$
    builder.append(_identifiantFonctionnelPA);
    builder.append("]"); //$NON-NLS-1$
    return builder.toString();
  }

}
