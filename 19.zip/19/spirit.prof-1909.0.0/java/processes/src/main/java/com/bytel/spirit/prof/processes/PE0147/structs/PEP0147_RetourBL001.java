/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PE0147.structs;

import java.io.Serializable;

import com.bytel.spirit.common.shared.saab.cmd.Commande;

/**
 *
 * @author mbaptist
 * @version ($Revision$ $Date$)
 */
public class PEP0147_RetourBL001 implements Serializable
{

  /**
   *
   */
  private static final long serialVersionUID = -2580372775298206104L;

  /**
   * @return the serialversionuid
   */
  public static long getSerialversionuid()
  {
    return serialVersionUID;
  }

  /**
   * Commande associée
   */
  Commande _commandeGP;

  /**
   * Statut du mail
   */
  String _statut;

  /**
   * Statut du mail à traiter
   */
  String _mail;

  public PEP0147_RetourBL001()
  {
    super();
  }

  public PEP0147_RetourBL001(Commande commande_p, String statut_p, String mail_p)
  {
    super();
    _commandeGP = commande_p;
    _statut = statut_p;
    _mail = mail_p;
  }

  /**
   * @return the CommandeGP
   */
  public Commande getCommandeGP()
  {
    return _commandeGP;
  }

  /**
   * @return the mail
   */
  public String getMail()
  {
    return _mail;
  }

  /**
   * @return the statut
   */
  public String getStatut()
  {
    return _statut;
  }

  /**
   * @param commandeGP_p
   *          the commandeGP to set
   */
  public void setCommandeGP(Commande commandeGP_p)
  {
    _commandeGP = commandeGP_p;
  }

  /**
   * @param mail_p
   *          the mail to set
   */
  public void setMail(String mail_p)
  {
    _mail = mail_p;
  }

  /**
   * @param sStatut_p
   *          the sStatut to set
   */
  public void setStatut(String statut_p)
  {
    _statut = statut_p;
  }
}
