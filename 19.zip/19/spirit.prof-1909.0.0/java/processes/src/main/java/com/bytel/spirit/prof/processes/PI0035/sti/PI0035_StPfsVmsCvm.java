/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PI0035.sti;

import java.time.LocalDateTime;

import com.bytel.spirit.common.shared.functional.types.json.st.pfs.TypePFS;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.vmscvm.StPfsVmsCvm;
import com.bytel.spirit.common.shared.saab.rst.ServiceTechnique;
import com.squareup.moshi.Json;

/**
 *
 * @author mbaptist
 * @version ($Revision$ $Date$)
 */
public class PI0035_StPfsVmsCvm extends PI0035_AbstractStPfs
{

  /**
   *
   */
  private static final long serialVersionUID = 1L;

  /**
   * Builds a new instance of {@link PI0035_StPfsVmsCvm} from an instance of {@link ServiceTechnique}
   *
   * @param stPfsVmsCvm_p
   *          The instance of {@link ServiceTechnique}.
   * @return The instance of {@link PI0035_StPfsVmsCvm}.
   */
  public static PI0035_StPfsVmsCvm buildFromStPfsVmsCvm(StPfsVmsCvm stPfsVmsCvm_p)
  {

    PI0035_DonneesIdentificationStPfsVmsCvm donneesIdent = new PI0035_DonneesIdentificationStPfsVmsCvm(stPfsVmsCvm_p.getDonneesIdentificationSTPfsVmsCvm().getIdentifiantFonctionnelPa());

    PI0035_DonneesProvisionneesStPfsVmsCvm donneesProv = null;
    if (stPfsVmsCvm_p.getDonneesProvisionneesSTPfsVmsCvm() != null)
    {
      donneesProv = new PI0035_DonneesProvisionneesStPfsVmsCvm(stPfsVmsCvm_p.getDonneesProvisionneesSTPfsVmsCvm().getNoTelephone(), //
          stPfsVmsCvm_p.getDonneesProvisionneesSTPfsVmsCvm().getTypeUsage(), //
          stPfsVmsCvm_p.getDonneesProvisionneesSTPfsVmsCvm().getLigneMarche(), //
          stPfsVmsCvm_p.getDonneesProvisionneesSTPfsVmsCvm().getAdresseMail(), //
          stPfsVmsCvm_p.getDonneesProvisionneesSTPfsVmsCvm().getNomPrenomUtilisateur());
    }

    return new PI0035_StPfsVmsCvm(stPfsVmsCvm_p.getIdSt(), stPfsVmsCvm_p.getStatut(), stPfsVmsCvm_p.getDateCreation(), stPfsVmsCvm_p.getDateModification(), donneesIdent, donneesProv);

  }

  /**
   * Donnes Identification
   */
  @Json(name = "donneesIdentification")
  private PI0035_DonneesIdentificationStPfsVmsCvm _donneesIdentification;

  /**
   * Donnes Provisionnees
   */
  @Json(name = "donneesProvisionnees")
  private PI0035_DonneesProvisionneesStPfsVmsCvm _donneesProvisionnees;

  /**
   * @param idSt_p
   * @param statut_p
   * @param dateCreation_p
   * @param dateModification_p
   * @param donneesIdentification_p
   * @param donneesProvisionnees_p
   */
  public PI0035_StPfsVmsCvm(String idSt_p, String statut_p, LocalDateTime dateCreation_p, LocalDateTime dateModification_p, PI0035_DonneesIdentificationStPfsVmsCvm donneesIdentification_p, PI0035_DonneesProvisionneesStPfsVmsCvm donneesProvisionnees_p)
  {
    super(idSt_p, statut_p, TypePFS.VMS_CVM.name(), dateCreation_p, dateModification_p);

    _donneesIdentification = donneesIdentification_p;
    _donneesProvisionnees = donneesProvisionnees_p;
  }

  /**
   * @return the donneesIdentification
   */
  public PI0035_DonneesIdentificationStPfsVmsCvm getDonneesIdentification()
  {
    return _donneesIdentification;
  }

  /**
   * @return the donneesProvisionnees
   */
  public PI0035_DonneesProvisionneesStPfsVmsCvm getDonneesProvisionnees()
  {
    return _donneesProvisionnees;
  }

  /**
   * @param donneesIdentification_p
   *          the donneesIdentification to set
   */
  public void setDonneesIdentification(PI0035_DonneesIdentificationStPfsVmsCvm donneesIdentification_p)
  {
    _donneesIdentification = donneesIdentification_p;
  }

  /**
   * @param donneesProvisionnees_p
   *          the donneesProvisionnees to set
   */
  public void setDonneesProvisionnees(PI0035_DonneesProvisionneesStPfsVmsCvm donneesProvisionnees_p)
  {
    _donneesProvisionnees = donneesProvisionnees_p;
  }

  @Override
  public String toString()
  {
    StringBuilder builder = new StringBuilder();
    builder.append("PI0035_StPfsVmsCvm [_donneesIdentification="); //$NON-NLS-1$
    builder.append(_donneesIdentification);
    builder.append(", _donneesProvisionnees="); //$NON-NLS-1$
    builder.append(_donneesProvisionnees);
    builder.append(", getCommentaire()="); //$NON-NLS-1$
    builder.append(getCommentaire());
    builder.append(", getDateCreation()="); //$NON-NLS-1$
    builder.append(getDateCreation());
    builder.append(", getDateModification()="); //$NON-NLS-1$
    builder.append(getDateModification());
    builder.append(", getIdSt()="); //$NON-NLS-1$
    builder.append(getIdSt());
    builder.append(", getStatut()="); //$NON-NLS-1$
    builder.append(getStatut());
    builder.append(", getTypeServiceTechnique()="); //$NON-NLS-1$
    builder.append(getTypeServiceTechnique());
    builder.append("]"); //$NON-NLS-1$
    return builder.toString();
  }
}
