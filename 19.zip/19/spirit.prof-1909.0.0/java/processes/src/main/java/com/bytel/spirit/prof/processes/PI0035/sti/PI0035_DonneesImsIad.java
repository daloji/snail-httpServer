/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PI0035.sti;

import java.io.Serializable;

import com.bytel.spirit.common.shared.functional.types.json.st.pfs.acsiad.DonneesImsIad;
import com.squareup.moshi.Json;

/**
 *
 * @author pescudei
 * @version ($Revision$ $Date$)
 */
public class PI0035_DonneesImsIad implements Serializable
{
  /**
   *
   */
  private static final long serialVersionUID = -5563398457401140899L;

  /**
   * Domaine IMS
   */
  @Json(name = "domaineIms")
  private String _domaineIms;

  /**
   * Proxy IMS
   */
  @Json(name = "nomFQDN")
  private String _nomFQDN;

  /**
   * Identité privée du service Voip activé sur le numéro port FXS1
   */
  @Json(name = "impiPortVoix1")
  private String _impiPortVoix1;

  /**
   * Mot de passe du service Voip activé sur le numéro port FXS1
   */
  @Json(name = "motDePassePortVoix1")
  private String _motDePassePortVoix1;

  /**
   * Identité publique {TelUri} du service Voip activé sur le numéro port FXS1
   */
  @Json(name = "telUriPortVoix1")
  private String _telUriPortVoix1;

  /**
   * Identité privée du service Voip activé sur le numéro port FXS2
   */
  @Json(name = "impiPortVoix2")
  private String _impiPortVoix2;

  /**
   * Mot de passe du service Voip activé sur le numéro port FXS2
   */
  @Json(name = "motDePassePortVoix2")
  private String _motDePassePortVoix2;

  /**
   * Identité publique {TelUri} du service Voip activé sur le numéro port FXS2
   */
  @Json(name = "telUriPortVoix2")
  private String _telUriPortVoix2;

  /**
   * @param donneesImsIad_p
   */
  public PI0035_DonneesImsIad(DonneesImsIad donneesImsIad_p)
  {
    super();
    _domaineIms = donneesImsIad_p.getDomaineIms();
    _nomFQDN = donneesImsIad_p.getNomFQDN();
    _impiPortVoix1 = donneesImsIad_p.getImpiPortVoix1();
    _motDePassePortVoix1 = donneesImsIad_p.getMotDePassePortVoix1();
    _telUriPortVoix1 = donneesImsIad_p.getTelUriPortVoix1();
    _impiPortVoix2 = donneesImsIad_p.getImpiPortVoix2();
    _motDePassePortVoix2 = donneesImsIad_p.getMotDePassePortVoix2();
    _telUriPortVoix2 = donneesImsIad_p.getTelUriPortVoix2();
  }

  /**
   * @param domaineIms_p
   * @param nomFQDN_p
   * @param impiPortVoix1_p
   * @param motDePassePortVoix1_p
   * @param telUriPortVoix1_p
   * @param impiPortVoix2_p
   * @param motDePassePortVoix2_p
   * @param telUriPortVoix2_p
   */
  public PI0035_DonneesImsIad(String domaineIms_p, String nomFQDN_p, String impiPortVoix1_p, String motDePassePortVoix1_p, String telUriPortVoix1_p, String impiPortVoix2_p, String motDePassePortVoix2_p, String telUriPortVoix2_p)
  {
    super();
    _domaineIms = domaineIms_p;
    _nomFQDN = nomFQDN_p;
    _impiPortVoix1 = impiPortVoix1_p;
    _motDePassePortVoix1 = motDePassePortVoix1_p;
    _telUriPortVoix1 = telUriPortVoix1_p;
    _impiPortVoix2 = impiPortVoix2_p;
    _motDePassePortVoix2 = motDePassePortVoix2_p;
    _telUriPortVoix2 = telUriPortVoix2_p;
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    PI0035_DonneesImsIad other = (PI0035_DonneesImsIad) obj;
    if (_domaineIms == null)
    {
      if (other._domaineIms != null)
      {
        return false;
      }
    }
    else if (!_domaineIms.equals(other._domaineIms))
    {
      return false;
    }
    if (_impiPortVoix1 == null)
    {
      if (other._impiPortVoix1 != null)
      {
        return false;
      }
    }
    else if (!_impiPortVoix1.equals(other._impiPortVoix1))
    {
      return false;
    }
    if (_impiPortVoix2 == null)
    {
      if (other._impiPortVoix2 != null)
      {
        return false;
      }
    }
    else if (!_impiPortVoix2.equals(other._impiPortVoix2))
    {
      return false;
    }
    if (_motDePassePortVoix1 == null)
    {
      if (other._motDePassePortVoix1 != null)
      {
        return false;
      }
    }
    else if (!_motDePassePortVoix1.equals(other._motDePassePortVoix1))
    {
      return false;
    }
    if (_motDePassePortVoix2 == null)
    {
      if (other._motDePassePortVoix2 != null)
      {
        return false;
      }
    }
    else if (!_motDePassePortVoix2.equals(other._motDePassePortVoix2))
    {
      return false;
    }
    if (_nomFQDN == null)
    {
      if (other._nomFQDN != null)
      {
        return false;
      }
    }
    else if (!_nomFQDN.equals(other._nomFQDN))
    {
      return false;
    }
    if (_telUriPortVoix1 == null)
    {
      if (other._telUriPortVoix1 != null)
      {
        return false;
      }
    }
    else if (!_telUriPortVoix1.equals(other._telUriPortVoix1))
    {
      return false;
    }
    if (_telUriPortVoix2 == null)
    {
      if (other._telUriPortVoix2 != null)
      {
        return false;
      }
    }
    else if (!_telUriPortVoix2.equals(other._telUriPortVoix2))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the domaineIms
   */
  public String getDomaineIms()
  {
    return _domaineIms;
  }

  /**
   * @return the impiPortVoix1
   */
  public String getImpiPortVoix1()
  {
    return _impiPortVoix1;
  }

  /**
   * @return the impiPortVoix2
   */
  public String getImpiPortVoix2()
  {
    return _impiPortVoix2;
  }

  /**
   * @return the motDePassePortVoix1
   */
  public String getMotDePassePortVoix1()
  {
    return _motDePassePortVoix1;
  }

  /**
   * @return the motDePassePortVoix2
   */
  public String getMotDePassePortVoix2()
  {
    return _motDePassePortVoix2;
  }

  /**
   * @return the nomFQDN
   */
  public String getnomFQDN()
  {
    return _nomFQDN;
  }

  /**
   * @return the telUriPortVoix1
   */
  public String getTelUriPortVoix1()
  {
    return _telUriPortVoix1;
  }

  /**
   * @return the telUriPortVoix2
   */
  public String getTelUriPortVoix2()
  {
    return _telUriPortVoix2;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_domaineIms == null) ? 0 : _domaineIms.hashCode());
    result = (prime * result) + ((_impiPortVoix1 == null) ? 0 : _impiPortVoix1.hashCode());
    result = (prime * result) + ((_impiPortVoix2 == null) ? 0 : _impiPortVoix2.hashCode());
    result = (prime * result) + ((_motDePassePortVoix1 == null) ? 0 : _motDePassePortVoix1.hashCode());
    result = (prime * result) + ((_motDePassePortVoix2 == null) ? 0 : _motDePassePortVoix2.hashCode());
    result = (prime * result) + ((_nomFQDN == null) ? 0 : _nomFQDN.hashCode());
    result = (prime * result) + ((_telUriPortVoix1 == null) ? 0 : _telUriPortVoix1.hashCode());
    result = (prime * result) + ((_telUriPortVoix2 == null) ? 0 : _telUriPortVoix2.hashCode());
    return result;
  }

  /**
   * @param domaineIms_p
   *          the domaineIms to set
   */
  public void setDomaineIms(String domaineIms_p)
  {
    _domaineIms = domaineIms_p;
  }

  /**
   * @param impiPortVoix1_p
   *          the impiPortVoix1 to set
   */
  public void setImpiPortVoix1(String impiPortVoix1_p)
  {
    _impiPortVoix1 = impiPortVoix1_p;
  }

  /**
   * @param impiPortVoix2_p
   *          the impiPortVoix2 to set
   */
  public void setImpiPortVoix2(String impiPortVoix2_p)
  {
    _impiPortVoix2 = impiPortVoix2_p;
  }

  /**
   * @param motDePassePortVoix1_p
   *          the motDePassePortVoix1 to set
   */
  public void setMotDePassePortVoix1(String motDePassePortVoix1_p)
  {
    _motDePassePortVoix1 = motDePassePortVoix1_p;
  }

  /**
   * @param motDePassePortVoix2_p
   *          the motDePassePortVoix2 to set
   */
  public void setMotDePassePortVoix2(String motDePassePortVoix2_p)
  {
    _motDePassePortVoix2 = motDePassePortVoix2_p;
  }

  /**
   * @param nomFQDN_p
   *          the nomFQDN to set
   */
  public void setnomFQDN(String nomFQDN_p)
  {
    _nomFQDN = nomFQDN_p;
  }

  /**
   * @param telUriPortVoix1_p
   *          the telUriPortVoix1 to set
   */
  public void setTelUriPortVoix1(String telUriPortVoix1_p)
  {
    _telUriPortVoix1 = telUriPortVoix1_p;
  }

  /**
   * @param telUriPortVoix2_p
   *          the telUriPortVoix2 to set
   */
  public void setTelUriPortVoix2(String telUriPortVoix2_p)
  {
    _telUriPortVoix2 = telUriPortVoix2_p;
  }

  @Override
  public String toString()
  {
    StringBuilder builder = new StringBuilder();
    builder.append("PI0035_DonneesImsIad [_domaineIms="); //$NON-NLS-1$
    builder.append(_domaineIms);
    builder.append(", _nomFQDN="); //$NON-NLS-1$
    builder.append(_nomFQDN);
    builder.append(", _impiPortVoix1="); //$NON-NLS-1$
    builder.append(_impiPortVoix1);
    builder.append(", _motDePassePortVoix1="); //$NON-NLS-1$
    builder.append(_motDePassePortVoix1);
    builder.append(", _telUriPortVoix1="); //$NON-NLS-1$
    builder.append(_telUriPortVoix1);
    builder.append(", _impiPortVoix2="); //$NON-NLS-1$
    builder.append(_impiPortVoix2);
    builder.append(", _motDePassePortVoix2="); //$NON-NLS-1$
    builder.append(_motDePassePortVoix2);
    builder.append(", _telUriPortVoix2="); //$NON-NLS-1$
    builder.append(_telUriPortVoix2);
    builder.append("]"); //$NON-NLS-1$
    return builder.toString();
  }
}
