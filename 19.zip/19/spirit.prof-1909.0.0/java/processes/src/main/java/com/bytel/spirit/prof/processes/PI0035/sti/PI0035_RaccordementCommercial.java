/*
 *                                                             ___o.__
 *                                                         ,oH8888888888o._
 *                                                       dP',88888P'''`8888o.
 *   ____                                              ,8',888888      888888o
 *  |  _ \                                            d8,d888888b    ,d8888888b
 *  | |_) | ___  _   _ _   _  __ _ _   _  ___  ___   ,8PPY8888888boo8888PPPP"'`b
 *  |  _ < / _ \| | | | | | |/ _` | | | |/ _ \/ __|  d8o_                     d8
 *  | |_) | (_) | |_| | |_| | (_| | |_| |  __/\__ \' d888bo.             _ooP d8'
 *  |____/ \___/ \__,_|\__, |\__, |\__,_|\___||___/  d8888888P     ,ooo88888P d8
 *                      __/ | ___/_                  `8M8888P     ,88888888P ,8P
 *                     |___/ |__ |  _  |  _  _  _ __  Y88Y88'    ,888888888' dP
 *                               | (/_ | (/_(_ (_)|||  `8b8P    d8888888888,dP
 *                                                      Y8,   d88888888888P'
 *                                                        `Y=8888888888P'
 *                                                            `''`'''
 *
 *  Systeme $system
 *
 *  (C) Copyright Bouygues Telecom 2018.
 *
 *  Utilisation, reproduction et divulgation interdites
 *  sans autorisation ecrite de Bouygues Telecom.
 *
 *  Projet  : FTTOcmdRacco_Lot3_Rebasing1901
 *  Package : com.bytel.spirit.prof.processes.PI0035.sti
 *  Classe  : PI0035_RaccordementCommercial
 *  Auteur  : sdiop
 *
 */

package com.bytel.spirit.prof.processes.PI0035.sti;

import java.io.Serializable;

import com.bytel.spirit.common.shared.saab.rpg.RaccordementCommercial;
import com.squareup.moshi.Json;

/**
 *
 * @author sdiop
 * @version ($Revision$ $Date$)
 */
public class PI0035_RaccordementCommercial implements Serializable
{
  /**
   *
   */
  private static final long serialVersionUID = 7184030916283458209L;

  /**
   * Creates a new instance of {@link PI0035_RaccordementCommercial} from an instance of {@link RaccordementCommercial}
   *
   * @param raccordementCommercial_p
   *          The instance of {@link RaccordementCommercial}.
   * @return The created instance of {@link PI0035_RaccordementCommercial};
   */
  public static PI0035_RaccordementCommercial buildFromRaccordementCommercial(RaccordementCommercial raccordementCommercial_p)
  {
    PI0035_AccesTechniqueCommercial accesTechniqueCommercial = null;
    if (null != raccordementCommercial_p.getAccesTechniqueCommercial())
    {
      accesTechniqueCommercial = PI0035_AccesTechniqueCommercial.buildFromAccesTechniqueCommercial(raccordementCommercial_p.getAccesTechniqueCommercial());
    }
    return new PI0035_RaccordementCommercial(accesTechniqueCommercial, raccordementCommercial_p.getCodeNro());
  }

  /**
   * Accès technique caractérisant le raccordement commercial du client
   */
  @Json(name = "accesTechniqueCommercial")
  private PI0035_AccesTechniqueCommercial _accesTechniqueCommercial;

  /**
   * Accès technique caractérisant le raccordement commercial du client
   */
  @Json(name = "codeNro")
  private String _codeNro;

  /**
   * DEfault constructor
   */
  public PI0035_RaccordementCommercial()
  {
    super();
  }

  /**
   * Constructor
   *
   * @param accesTechniqueCommercial_p
   * @param codeNro_p
   */
  public PI0035_RaccordementCommercial(PI0035_AccesTechniqueCommercial accesTechniqueCommercial_p, String codeNro_p)
  {
    super();

    this._accesTechniqueCommercial = accesTechniqueCommercial_p;
    this._codeNro = codeNro_p;
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    PI0035_RaccordementCommercial other = (PI0035_RaccordementCommercial) obj;
    if (_accesTechniqueCommercial == null)
    {
      if (other._accesTechniqueCommercial != null)
      {
        return false;
      }
    }
    else if (!_accesTechniqueCommercial.equals(other._accesTechniqueCommercial))
    {
      return false;
    }
    if (_codeNro == null)
    {
      if (other._codeNro != null)
      {
        return false;
      }
    }
    else if (!_codeNro.equals(other._codeNro))
    {
      return false;
    }
    return true;
  }

  /**
   * @return _accesTechniqueCommercial
   */
  public PI0035_AccesTechniqueCommercial getAccesTechniqueCommercial()
  {
    return _accesTechniqueCommercial;
  }

  /**
   * @return _codeNro
   */
  public String getCodeNro()
  {
    return _codeNro;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_accesTechniqueCommercial == null) ? 0 : _accesTechniqueCommercial.hashCode());
    result = (prime * result) + ((_codeNro == null) ? 0 : _codeNro.hashCode());
    return result;
  }

  /**
   * @param accesTechniqueCommercial_p
   *          _accesTechniqueCommercial
   */
  public void setAccesTechniqueCommercial(PI0035_AccesTechniqueCommercial accesTechniqueCommercial_p)
  {
    _accesTechniqueCommercial = accesTechniqueCommercial_p;
  }

  /**
   * @param codeNro_p
   *          _codeNro
   */
  public void setCodeNro(String codeNro_p)
  {
    _codeNro = codeNro_p;
  }

  @Override
  public String toString()
  {
    StringBuilder builder = new StringBuilder();
    builder.append("PI0035_RaccordementCommercial [_accesTechniqueCommercial="); //$NON-NLS-1$
    builder.append(_accesTechniqueCommercial);
    builder.append(", _codeNro="); //$NON-NLS-1$
    builder.append(_codeNro);
    builder.append("]"); //$NON-NLS-1$
    return builder.toString();
  }
}
