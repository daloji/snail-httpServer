/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PI0035.sti;

import java.time.LocalDateTime;

import com.bytel.spirit.common.shared.saab.rpg.PA;
import com.bytel.spirit.common.shared.saab.rpg.PaTypeTv;
import com.squareup.moshi.Json;

/**
 *
 * @author jiantila
 * @version ($Revision$ $Date$)
 */
public class PI0035_PATV extends PI0035_PA
{
  /**
   *
   */
  private static final long serialVersionUID = -6276211878729962600L;

  /**
   * Creates a new instance of {@link PI0035_PATV} from an instance of {@link PA} of type {@link PaTypeTv}
   *
   * @param pa_p
   *          The instance of {@link PA}.
   * @return The instance of {@link PI0035_PATV}.
   */
  public static PI0035_PATV buildFromPATV(PA pa_p)
  {
    return new PI0035_PATV(pa_p.getIdentifiantFonctionnelPA(), pa_p.getStatut().name(), pa_p.getTypePA(), pa_p.getPaTypeTv().getIdCompteTv(), pa_p.getPaTypeTv().getIdContenuTv(), pa_p.getDateCreation(), pa_p.getDateModification());
  }

  /**
   * Identifiant de la ressource de type compteTV
   *
   */
  @Json(name = "compteTV")
  private String _compteTV;

  /**
   * Identifiant permettant la continuité des usages sur plusieurs comptes TV
   *
   */
  @Json(name = "idContenuTV")
  private String _idContenuTV;

  /**
   *
   */
  public PI0035_PATV()
  {
    super();
  }

  /**
   * @param identifiantFonctionnelPA_p
   * @param statut_p
   * @param typePA_p
   * @param compteTV_p
   * @param idContenuTV_p
   * @param dateCreation_p
   * @param dateModification_p
   */
  public PI0035_PATV(String identifiantFonctionnelPA_p, String statut_p, String typePA_p, String compteTV_p, String idContenuTV_p, LocalDateTime dateCreation_p, LocalDateTime dateModification_p)
  {
    super(identifiantFonctionnelPA_p, statut_p, typePA_p, dateCreation_p, dateModification_p);

    _compteTV = compteTV_p;
    _idContenuTV = idContenuTV_p;
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (!super.equals(obj))
    {
      return false;
    }
    if ((obj.getClass() != null) && (getClass() != obj.getClass()))
    {
      return false;
    }
    PI0035_PATV other = (PI0035_PATV) obj;
    if (_compteTV == null)
    {
      if (other._compteTV != null)
      {
        return false;
      }
    }
    else if (!_compteTV.equals(other._compteTV))
    {
      return false;
    }
    if (_idContenuTV == null)
    {
      if (other._idContenuTV != null)
      {
        return false;
      }
    }
    else if (!_idContenuTV.equals(other._idContenuTV))
    {
      return false;
    }

    return true;
  }

  /**
   * @return the compteTV
   */
  public String getCompteTV()
  {
    return _compteTV;
  }

  /**
   * @return the idContenuTV
   */
  public String getIdContenuTV()
  {
    return _idContenuTV;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = super.hashCode();
    result = (prime * result) + ((_compteTV == null) ? 0 : _compteTV.hashCode());
    result = (prime * result) + ((_idContenuTV == null) ? 0 : _idContenuTV.hashCode());
    return result;
  }

  /**
   * @param compteTV_p
   *          the compteTV to set
   */
  public void setCompteTV(String compteTV_p)
  {
    _compteTV = compteTV_p;
  }

  /**
   * @param idContenuTV_p
   *          the idContenuTV to set
   */
  public void setIdContenuTV(String idContenuTV_p)
  {
    _idContenuTV = idContenuTV_p;
  }

  @Override
  public String toString()
  {
    StringBuilder builder = new StringBuilder();
    builder.append("PI0035_PATV [_compteTV="); //$NON-NLS-1$
    builder.append(_compteTV);
    builder.append(", _idContenuTV="); //$NON-NLS-1$
    builder.append(_idContenuTV);
    builder.append(", getDateCreation()="); //$NON-NLS-1$
    builder.append(getDateCreation());
    builder.append(", getDateModification()="); //$NON-NLS-1$
    builder.append(getDateModification());
    builder.append(", getIdentifiantFonctionnelPA()="); //$NON-NLS-1$
    builder.append(getIdentifiantFonctionnelPA());
    builder.append(", getIdentifiantFonctionnelPALie()="); //$NON-NLS-1$
    builder.append(getIdentifiantFonctionnelPALie());
    builder.append(", getStatut()="); //$NON-NLS-1$
    builder.append(getStatut());
    builder.append(", getTypePA()="); //$NON-NLS-1$
    builder.append(getTypePA());
    builder.append("]"); //$NON-NLS-1$
    return builder.toString();
  }
}
