/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PI0035.sti;

import java.io.Serializable;
import java.time.LocalDateTime;

import com.bytel.ravel.common.json.annotations.RavelLocalDateTimeFormat;
import com.bytel.ravel.common.json.format.impl.IsoShortOffsetDateTimeWithMillis;
import com.bytel.spirit.common.shared.saab.rpg.Titulaire;
import com.bytel.spirit.common.shared.saab.rpg.TypeTitulaire;
import com.squareup.moshi.Json;

/**
 *
 * @author jiantila
 * @version ($Revision$ $Date$)
 */

public class PI0035_Titulaire implements Serializable
{
  /**
   *
   */
  private static final long serialVersionUID = 669040094851102025L;

  /**
   * Builds a new instance of {@link PI0035_Titulaire} from a {@link Titulaire} instance.
   *
   * @param titulaire_p
   *          The titulaire parameter
   * @return The created instance of {@link PI0035_Titulaire}
   */
  public static PI0035_Titulaire buildFromTitulaire(Titulaire titulaire_p)

  {
    PI0035_Titulaire titulaire = new PI0035_Titulaire(titulaire_p.getTypeTitulaire().name(), titulaire_p.getNoPersonne(), titulaire_p.getDateCreation(), titulaire_p.getDateModification());
    titulaire.setNoTel(titulaire_p.getNoTel());
    titulaire.setEmail(titulaire_p.getEmail());

    if ((TypeTitulaire.ENTREPRISE == titulaire_p.getTypeTitulaire()) && (titulaire_p.getEntreprise() != null))
    {
      PI0035_Entreprise entreprise = new PI0035_Entreprise(titulaire_p.getEntreprise().getRaisonSociale());
      entreprise.setNoSiren(titulaire_p.getEntreprise().getNoSiren());
      titulaire.setEntreprise(entreprise);
    }
    if (titulaire_p.getIndividu() != null)
    {
      PI0035_Individu individu = new PI0035_Individu(titulaire_p.getIndividu().getCivilite(), titulaire_p.getIndividu().getNom(), titulaire_p.getIndividu().getPrenom());
      titulaire.setIndividu(individu);
    }

    return titulaire;
  }

  /**
   * client operateur
   */
  @Json(name = "typeTitulaire")
  private String _typeTitulaire;

  /**
   * no personne
   */
  @Json(name = "noPersonne")
  private String _noPersonne;

  /**
   * no tel
   */
  @Json(name = "noTel")
  private String _noTel;

  /**
   * email
   */
  @Json(name = "email")
  private String _email;

  /**
   * individu
   */
  @Json(name = "individu")
  private PI0035_Individu _individu;

  /**
   * Entreprise
   */
  @Json(name = "entreprise")
  private PI0035_Entreprise _entreprise;

  /**
   * date Creation
   */
  @Json(name = "dateCreation")
  @RavelLocalDateTimeFormat(IsoShortOffsetDateTimeWithMillis.class)
  private LocalDateTime _dateCreation;

  /**
   * date Modification
   */
  @Json(name = "dateModification")
  @RavelLocalDateTimeFormat(IsoShortOffsetDateTimeWithMillis.class)
  private LocalDateTime _dateModification;

  /**
   *
   */
  public PI0035_Titulaire()
  {
    super();
  }

  /**
   * @param typeTitulaire_p
   * @param noPersonne_p
   * @param dateCreation_p
   * @param dateModification_p
   */
  public PI0035_Titulaire(String typeTitulaire_p, String noPersonne_p, LocalDateTime dateCreation_p, LocalDateTime dateModification_p)
  {
    super();

    _typeTitulaire = typeTitulaire_p;
    _noPersonne = noPersonne_p;
    _dateCreation = dateCreation_p;
    _dateModification = dateModification_p;
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    PI0035_Titulaire other = (PI0035_Titulaire) obj;
    if (_dateCreation == null)
    {
      if (other._dateCreation != null)
      {
        return false;
      }
    }
    else if (!_dateCreation.equals(other._dateCreation))
    {
      return false;
    }
    if (_dateModification == null)
    {
      if (other._dateModification != null)
      {
        return false;
      }
    }
    else if (!_dateModification.equals(other._dateModification))
    {
      return false;
    }
    if (_email == null)
    {
      if (other._email != null)
      {
        return false;
      }
    }
    else if (!_email.equals(other._email))
    {
      return false;
    }
    if (_entreprise == null)
    {
      if (other._entreprise != null)
      {
        return false;
      }
    }
    else if (!_entreprise.equals(other._entreprise))
    {
      return false;
    }
    if (_individu == null)
    {
      if (other._individu != null)
      {
        return false;
      }
    }
    else if (!_individu.equals(other._individu))
    {
      return false;
    }
    if (_noPersonne == null)
    {
      if (other._noPersonne != null)
      {
        return false;
      }
    }
    else if (!_noPersonne.equals(other._noPersonne))
    {
      return false;
    }
    if (_noTel == null)
    {
      if (other._noTel != null)
      {
        return false;
      }
    }
    else if (!_noTel.equals(other._noTel))
    {
      return false;
    }
    if (_typeTitulaire == null)
    {
      if (other._typeTitulaire != null)
      {
        return false;
      }
    }
    else if (!_typeTitulaire.equals(other._typeTitulaire))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the dateCreation
   */
  public LocalDateTime getDateCreation()
  {
    return _dateCreation;
  }

  /**
   * @return the dateModification
   */
  public LocalDateTime getDateModification()
  {
    return _dateModification;
  }

  /**
   * @return the email
   */
  public String getEmail()
  {
    return _email;
  }

  /**
   * @return the entreprise
   */
  public PI0035_Entreprise getEntreprise()
  {
    return _entreprise;
  }

  /**
   * @return the individu
   */
  public PI0035_Individu getIndividu()
  {
    return _individu;
  }

  /**
   * @return the noPersonne
   */
  public String getNoPersonne()
  {
    return _noPersonne;
  }

  /**
   * @return the noTel
   */
  public String getNoTel()
  {
    return _noTel;
  }

  /**
   * @return the typeTitulaire
   */
  public String getTypeTitulaire()
  {
    return _typeTitulaire;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_dateCreation == null) ? 0 : _dateCreation.hashCode());
    result = (prime * result) + ((_dateModification == null) ? 0 : _dateModification.hashCode());
    result = (prime * result) + ((_email == null) ? 0 : _email.hashCode());
    result = (prime * result) + ((_entreprise == null) ? 0 : _entreprise.hashCode());
    result = (prime * result) + ((_individu == null) ? 0 : _individu.hashCode());
    result = (prime * result) + ((_noPersonne == null) ? 0 : _noPersonne.hashCode());
    result = (prime * result) + ((_noTel == null) ? 0 : _noTel.hashCode());
    result = (prime * result) + ((_typeTitulaire == null) ? 0 : _typeTitulaire.hashCode());
    return result;
  }

  /**
   * @param dateCreation_p
   *          the dateCreation to set
   */
  public void setDateCreation(LocalDateTime dateCreation_p)
  {
    _dateCreation = dateCreation_p;
  }

  /**
   * @param dateModification_p
   *          the dateModification to set
   */
  public void setDateModification(LocalDateTime dateModification_p)
  {
    _dateModification = dateModification_p;
  }

  /**
   * @param email_p
   *          the email to set
   */
  public void setEmail(String email_p)
  {
    _email = email_p;
  }

  /**
   * @param entreprise_p
   *          the entreprise to set
   */
  public void setEntreprise(PI0035_Entreprise entreprise_p)
  {
    _entreprise = entreprise_p;
  }

  /**
   * @param individu_p
   *          the individu to set
   */
  public void setIndividu(PI0035_Individu individu_p)
  {
    _individu = individu_p;
  }

  /**
   * @param noPersonne_p
   *          the noPersonne to set
   */
  public void setNoPersonne(String noPersonne_p)
  {
    _noPersonne = noPersonne_p;
  }

  /**
   * @param noTel_p
   *          the noTel to set
   */
  public void setNoTel(String noTel_p)
  {
    _noTel = noTel_p;
  }

  /**
   * @param typeTitulaire_p
   *          the typeTitulaire to set
   */
  public void setTypeTitulaire(String typeTitulaire_p)
  {
    _typeTitulaire = typeTitulaire_p;
  }

  @Override
  public String toString()
  {
    StringBuilder builder = new StringBuilder();
    builder.append("PI0035_Titulaire [_typeTitulaire="); //$NON-NLS-1$
    builder.append(_typeTitulaire);
    builder.append(", _noPersonne="); //$NON-NLS-1$
    builder.append(_noPersonne);
    builder.append(", _noTel="); //$NON-NLS-1$
    builder.append(_noTel);
    builder.append(", _email="); //$NON-NLS-1$
    builder.append(_email);
    builder.append(", _individu="); //$NON-NLS-1$
    builder.append(_individu);
    builder.append(", _entreprise="); //$NON-NLS-1$
    builder.append(_entreprise);
    builder.append(", _dateCreation="); //$NON-NLS-1$
    builder.append(_dateCreation);
    builder.append(", _dateModification="); //$NON-NLS-1$
    builder.append(_dateModification);
    builder.append("]"); //$NON-NLS-1$
    return builder.toString();
  }
}
