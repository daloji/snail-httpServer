/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PI0035.sti;

import java.time.LocalDateTime;

import com.bytel.spirit.common.shared.functional.types.json.st.pfs.TypePFS;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.mail.StPfsMail;
import com.bytel.spirit.common.shared.saab.rst.ServiceTechnique;
import com.squareup.moshi.Json;

/**
 *
 * @author jgregori
 * @version ($Revision$ $Date$)
 */
public class PI0035_StPfsMail extends PI0035_AbstractStPfs
{
  /**
   *
   */
  private static final long serialVersionUID = -3939790242381830808L;

  /**
   * Builds a new instance of {@link PI0035_StPfsMail} from an instance of {@link ServiceTechnique}
   *
   * @param stPfsMail_p
   *          The instance of {@link ServiceTechnique}.
   * @return The instance of {@link PI0035_StPfsMail}.
   */
  public static PI0035_StPfsMail buildFromSTPFSMail(StPfsMail stPfsMail_p)
  {

    PI0035_DonneesIdentificationSTPfsMail donneesIdent = new PI0035_DonneesIdentificationSTPfsMail(stPfsMail_p.getDonneesIdentificationStPfsMail().getTypeServiceMail(), stPfsMail_p.getDonneesIdentificationStPfsMail().getIdCompteMail());

    PI0035_DonneesProvisionneesSTPfsMail donneesProv = null;
    if (stPfsMail_p.getDonneesProvisionneesStPfsMail() != null)
    {
      donneesProv = new PI0035_DonneesProvisionneesSTPfsMail(stPfsMail_p.getDonneesProvisionneesStPfsMail().getAdresseMail(), stPfsMail_p.getDonneesProvisionneesStPfsMail().getTaillePieceJointe(), stPfsMail_p.getDonneesProvisionneesStPfsMail().getVolumeBoite(), stPfsMail_p.getDonneesProvisionneesStPfsMail().getNiveauRestriction());
      donneesProv.setIdCompteMailPrincipal(stPfsMail_p.getDonneesProvisionneesStPfsMail().getIdCompteMailPrincipal());
    }

    PI0035_StPfsMail stpfsMail = new PI0035_StPfsMail(stPfsMail_p.getIdSt(), stPfsMail_p.getStatut(), stPfsMail_p.getDateCreation(), stPfsMail_p.getDateModification(), donneesIdent, donneesProv);
    return stpfsMail;
  }

  /**
   * Donnees Identification
   */
  @Json(name = "donneesIdentification")
  private PI0035_DonneesIdentificationSTPfsMail _donneesIdentification;

  /**
   * Donnees Provisionnees
   */
  @Json(name = "donneesProvisionnees")
  private PI0035_DonneesProvisionneesSTPfsMail _donneesProvisionnees;

  /**
   * @param idSt_p
   * @param statut_p
   * @param dateCreation_p
   * @param dateModification_p
   * @param donneesIdentification_p
   * @param donneesProvisionnees_p
   */
  public PI0035_StPfsMail(String idSt_p, String statut_p, LocalDateTime dateCreation_p, LocalDateTime dateModification_p, PI0035_DonneesIdentificationSTPfsMail donneesIdentification_p, PI0035_DonneesProvisionneesSTPfsMail donneesProvisionnees_p)
  {
    super(idSt_p, statut_p, TypePFS.MAIL.name(), dateCreation_p, dateModification_p);

    _donneesIdentification = donneesIdentification_p;
    _donneesProvisionnees = donneesProvisionnees_p;

  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (!super.equals(obj))
    {
      return false;
    }
    if (getClass() != obj.getClass()) // NOSONAR
    {
      return false;
    }
    PI0035_StPfsMail other = (PI0035_StPfsMail) obj;
    if (_donneesIdentification == null)
    {
      if (other._donneesIdentification != null)
      {
        return false;
      }
    }
    else if (!_donneesIdentification.equals(other._donneesIdentification))
    {
      return false;
    }
    if (_donneesProvisionnees == null)
    {
      if (other._donneesProvisionnees != null)
      {
        return false;
      }
    }
    else if (!_donneesProvisionnees.equals(other._donneesProvisionnees))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the donneesIdentification
   */
  public PI0035_DonneesIdentificationSTPfsMail getDonneesIdentification()
  {
    return _donneesIdentification;
  }

  /**
   * @return the donneesProvisionnes
   */
  public PI0035_DonneesProvisionneesSTPfsMail getDonneesProvisionnees()
  {
    return _donneesProvisionnees;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = super.hashCode();
    result = (prime * result) + ((_donneesIdentification == null) ? 0 : _donneesIdentification.hashCode());
    result = (prime * result) + ((_donneesProvisionnees == null) ? 0 : _donneesProvisionnees.hashCode());
    return result;
  }

  /**
   * @param donneesIdentification_p
   *          the donneesIdentification to set
   */
  public void setDonneesIdentification(PI0035_DonneesIdentificationSTPfsMail donneesIdentification_p)
  {
    _donneesIdentification = donneesIdentification_p;
  }

  /**
   * @param donneesProvisionnes_p
   *          the donneesProvisionnes to set
   */
  public void setDonneesProvisionnees(PI0035_DonneesProvisionneesSTPfsMail donneesProvisionnees_p)
  {
    _donneesProvisionnees = donneesProvisionnees_p;
  }

  @Override
  public String toString()
  {
    StringBuilder builder = new StringBuilder();
    builder.append("PI0035_StPfsMail [_donneesIdentification="); //$NON-NLS-1$
    builder.append(_donneesIdentification);
    builder.append(", _donneesProvisionnees="); //$NON-NLS-1$
    builder.append(_donneesProvisionnees);
    builder.append(", getCommentaire()="); //$NON-NLS-1$
    builder.append(getCommentaire());
    builder.append(", getDateCreation()="); //$NON-NLS-1$
    builder.append(getDateCreation());
    builder.append(", getDateModification()="); //$NON-NLS-1$
    builder.append(getDateModification());
    builder.append(", getIdSt()="); //$NON-NLS-1$
    builder.append(getIdSt());
    builder.append(", getStatut()="); //$NON-NLS-1$
    builder.append(getStatut());
    builder.append(", getTypeServiceTechnique()="); //$NON-NLS-1$
    builder.append(getTypeServiceTechnique());
    builder.append("]"); //$NON-NLS-1$
    return builder.toString();
  }
}
