/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PI0035.sti;

import java.io.Serializable;
import java.time.LocalDateTime;

import javax.validation.constraints.Size;

import com.bytel.ravel.common.json.annotations.RavelLocalDateTimeFormat;
import com.bytel.ravel.common.json.annotations.RavelPolymorphism;
import com.bytel.ravel.common.json.annotations.RavelPolymorphismProfil;
import com.bytel.ravel.common.json.annotations.RavelPolymorphisms;
import com.bytel.ravel.common.json.format.impl.IsoShortOffsetDateTimeWithMillis;
import com.bytel.spirit.common.shared.misc.ressources.SpiritConstants;
import com.bytel.spirit.common.shared.misc.validation.IValidationConst;
import com.bytel.spirit.common.shared.saab.res.Ressource;
import com.squareup.moshi.Json;

/**
 *
 * @author jiantila
 * @version ($Revision$ $Date$)
 */
@RavelPolymorphisms({ //
    @RavelPolymorphismProfil( //
        name = SpiritConstants.JSON_PROFILE_STARK, //
        type = "typeRessource", //
        defaultClass = PI0035_Ressource.class, //
        value = { //
            @RavelPolymorphism(type = "RACCO", clazz = PI0035_RessourceRaccordement.class), //
        }) //
})
public class PI0035_Ressource implements Serializable
{
  /**
   *
   */
  private static final long serialVersionUID = 9060381578256446394L;

  /**
   * @param ressource_p
   * @return
   */
  public static PI0035_Ressource buildFromRessource(Ressource ressource_p)
  {
    return new PI0035_Ressource(ressource_p.getIdRessource(), ressource_p.getTypeRessource(), ressource_p.getStatut(), ressource_p.getIdSt(), ressource_p.getDateCreation(), ressource_p.getDateModification());
  }

  /**
   * Identifiant de la Ressource
   */
  @Json(name = "idRessource")
  private String _idRessource;

  /**
   * Type de la Ressource
   */
  @Json(name = "typeRessource")
  private String _typeRessource;

  /**
   * Statut de la Ressource
   */
  @Json(name = "statut")
  private String _statut;

  /**
   * Statut de la Ressource
   */
  @Json(name = "idST")
  @Size(min = 1, max = 20, message = IValidationConst.FORMAT_ATTRIBUT_NON_RESPECTE)
  private String _idST;

  /**
   * Date de creation
   */
  @Json(name = "dateCreation")
  @RavelLocalDateTimeFormat(IsoShortOffsetDateTimeWithMillis.class)
  private LocalDateTime _dateCreation;

  /**
   * Date de Modification
   */
  @Json(name = "dateModification")
  @RavelLocalDateTimeFormat(IsoShortOffsetDateTimeWithMillis.class)
  private LocalDateTime _dateModification;

  /**
   *
   */
  public PI0035_Ressource()
  {
    super();
  }

  /**
   * @param idRessource_p
   * @param typeRessource_p
   * @param statut_p
   * @param dateCreation_p
   * @param dateModification_p
   */
  public PI0035_Ressource(String idRessource_p, String typeRessource_p, String statut_p, LocalDateTime dateCreation_p, LocalDateTime dateModification_p)
  {
    super();

    _idRessource = idRessource_p;
    _typeRessource = typeRessource_p;
    _statut = statut_p;
    _dateCreation = dateCreation_p;
    _dateModification = dateModification_p;
  }

  /**
   * @param idRessource_p
   * @param typeRessource_p
   * @param statut_p
   * @param dateCreation_p
   * @param dateModification_p
   */
  public PI0035_Ressource(String idRessource_p, String typeRessource_p, String statut_p, String idST_p, LocalDateTime dateCreation_p, LocalDateTime dateModification_p)
  {
    super();

    _idRessource = idRessource_p;
    _typeRessource = typeRessource_p;
    _statut = statut_p;
    _idST = idST_p;
    _dateCreation = dateCreation_p;
    _dateModification = dateModification_p;
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    PI0035_Ressource other = (PI0035_Ressource) obj;
    if (_dateCreation == null)
    {
      if (other._dateCreation != null)
      {
        return false;
      }
    }
    else if (!_dateCreation.equals(other._dateCreation))
    {
      return false;
    }
    if (_dateModification == null)
    {
      if (other._dateModification != null)
      {
        return false;
      }
    }
    else if (!_dateModification.equals(other._dateModification))
    {
      return false;
    }
    if (_idRessource == null)
    {
      if (other._idRessource != null)
      {
        return false;
      }
    }
    else if (!_idRessource.equals(other._idRessource))
    {
      return false;
    }
    if (_idST == null)
    {
      if (other._idST != null)
      {
        return false;
      }
    }
    else if (!_idST.equals(other._idST))
    {
      return false;
    }
    if (_statut == null)
    {
      if (other._statut != null)
      {
        return false;
      }
    }
    else if (!_statut.equals(other._statut))
    {
      return false;
    }
    if (_typeRessource == null)
    {
      if (other._typeRessource != null)
      {
        return false;
      }
    }
    else if (!_typeRessource.equals(other._typeRessource))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the dateCreation
   */
  public LocalDateTime getDateCreation()
  {
    return _dateCreation;
  }

  /**
   * @return the dateModification
   */
  public LocalDateTime getDateModification()
  {
    return _dateModification;
  }

  /**
   * @return the idRessource
   */
  public String getIdRessource()
  {
    return _idRessource;
  }

  /**
   * @return the idST
   */
  public String getIdST()
  {
    return _idST;
  }

  /**
   * @return the statut
   */
  public String getStatut()
  {
    return _statut;
  }

  /**
   * @return the typeRessource
   */
  public String getTypeRessource()
  {
    return _typeRessource;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_dateCreation == null) ? 0 : _dateCreation.hashCode());
    result = (prime * result) + ((_dateModification == null) ? 0 : _dateModification.hashCode());
    result = (prime * result) + ((_idRessource == null) ? 0 : _idRessource.hashCode());
    result = (prime * result) + ((_idST == null) ? 0 : _idST.hashCode());
    result = (prime * result) + ((_statut == null) ? 0 : _statut.hashCode());
    result = (prime * result) + ((_typeRessource == null) ? 0 : _typeRessource.hashCode());
    return result;
  }

  /**
   * @param dateCreation_p
   *          the dateCreation to set
   */
  public void setDateCreation(LocalDateTime dateCreation_p)
  {
    _dateCreation = dateCreation_p;
  }

  /**
   * @param dateModification_p
   *          the dateModification to set
   */
  public void setDateModification(LocalDateTime dateModification_p)
  {
    _dateModification = dateModification_p;
  }

  /**
   * @param idRessource_p
   *          the idRessource to set
   */
  public void setIdRessource(String idRessource_p)
  {
    _idRessource = idRessource_p;
  }

  /**
   * @param idST_p
   *          the idST to set
   */
  public void setIdST(String idST_p)
  {
    _idST = idST_p;
  }

  /**
   * @param statut_p
   *          the statut to set
   */
  public void setStatut(String statut_p)
  {
    _statut = statut_p;
  }

  /**
   * @param typeRessource_p
   *          the typeRessource to set
   */
  public void setTypeRessource(String typeRessource_p)
  {
    _typeRessource = typeRessource_p;
  }

  @Override
  public String toString()
  {
    StringBuilder builder = new StringBuilder();
    builder.append("PI0035_Ressource [_idRessource="); //$NON-NLS-1$
    builder.append(_idRessource);
    builder.append(", _typeRessource="); //$NON-NLS-1$
    builder.append(_typeRessource);
    builder.append(", _statut="); //$NON-NLS-1$
    builder.append(_statut);
    builder.append(", _idST="); //$NON-NLS-1$
    builder.append(_idST);
    builder.append(", _dateCreation="); //$NON-NLS-1$
    builder.append(_dateCreation);
    builder.append(", _dateModification="); //$NON-NLS-1$
    builder.append(_dateModification);
    builder.append("]"); //$NON-NLS-1$
    return builder.toString();
  }
}
