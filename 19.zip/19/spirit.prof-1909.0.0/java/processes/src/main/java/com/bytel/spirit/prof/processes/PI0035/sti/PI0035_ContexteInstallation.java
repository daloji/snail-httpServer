/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PI0035.sti;

import java.io.Serializable;
import java.time.LocalDateTime;

import com.bytel.ravel.common.json.annotations.RavelLocalDateTimeFormat;
import com.bytel.ravel.common.json.format.impl.IsoShortOffsetDateTimeWithMillis;
import com.bytel.spirit.common.shared.saab.rpg.ContexteInstallation;
import com.squareup.moshi.Json;

/**
 *
 * @author jiantila
 * @version ($Revision$ $Date$)
 */
public class PI0035_ContexteInstallation implements Serializable
{
  /**
   *
   */
  private static final long serialVersionUID = 58326288329314999L;

  /**
   * Creates an instance of {@link PI0035_ContexteInstallation} from an instance of {@link ContexteInstallation}.
   *
   * @param contexteInstallation_p
   *          The {@link ContexteInstallation} instance.
   * @return The {@link PI0035_ContexteInstallation} instance.
   */
  public static PI0035_ContexteInstallation buildFromContexteInstallation(ContexteInstallation contexteInstallation_p)
  {
    PI0035_ContexteInstallation contexteInstallation = new PI0035_ContexteInstallation();
    contexteInstallation.setIdMandat(contexteInstallation_p.getIdMandat());
    contexteInstallation.setTypeMes(contexteInstallation_p.getTypeMes());
    contexteInstallation.setDateClient(contexteInstallation_p.getDateClient());
    contexteInstallation.setCreneauClient(contexteInstallation_p.getCreneauClient());
    contexteInstallation.setIdRdv(contexteInstallation_p.getIdRdv());
    contexteInstallation.setPrestataire(contexteInstallation_p.getPrestataire());
    contexteInstallation.setCommentaire(contexteInstallation_p.getCommentaire());
    return contexteInstallation;
  }

  /**
   * Référence du mandat à fournir au partenaire
   */
  @Json(name = "idMandat")
  private String _idMandat;

  /**
   * Marqueur de rendez-vous
   */
  @Json(name = "typeMes")
  private String _typeMes;

  /**
   * Date de RDV
   */
  @Json(name = "dateCreation")
  @RavelLocalDateTimeFormat(IsoShortOffsetDateTimeWithMillis.class)
  private LocalDateTime _dateClient;

  /**
   *
   */
  @Json(name = "creneauClient")
  private String _creneauClient;

  /**
   * Référence de rendez-vous
   */
  @Json(name = "idRdv")
  private String _idRdv;

  /**
   * Référence du prestataire pour l'installation
   */
  @Json(name = "prestataire")
  private String _prestataire;

  /**
   * Informations sur l'installation
   */
  @Json(name = "commentaire")
  private String _commentaire;

  /**
   *
   */
  public PI0035_ContexteInstallation()
  {
    super();
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    PI0035_ContexteInstallation other = (PI0035_ContexteInstallation) obj;
    if (_commentaire == null)
    {
      if (other._commentaire != null)
      {
        return false;
      }
    }
    else if (!_commentaire.equals(other._commentaire))
    {
      return false;
    }
    if (_creneauClient == null)
    {
      if (other._creneauClient != null)
      {
        return false;
      }
    }
    else if (!_creneauClient.equals(other._creneauClient))
    {
      return false;
    }
    if (_dateClient == null)
    {
      if (other._dateClient != null)
      {
        return false;
      }
    }
    else if (!_dateClient.equals(other._dateClient))
    {
      return false;
    }
    if (_idMandat == null)
    {
      if (other._idMandat != null)
      {
        return false;
      }
    }
    else if (!_idMandat.equals(other._idMandat))
    {
      return false;
    }
    if (_idRdv == null)
    {
      if (other._idRdv != null)
      {
        return false;
      }
    }
    else if (!_idRdv.equals(other._idRdv))
    {
      return false;
    }
    if (_prestataire == null)
    {
      if (other._prestataire != null)
      {
        return false;
      }
    }
    else if (!_prestataire.equals(other._prestataire))
    {
      return false;
    }
    if (_typeMes == null)
    {
      if (other._typeMes != null)
      {
        return false;
      }
    }
    else if (!_typeMes.equals(other._typeMes))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the commentaire
   */
  public String getCommentaire()
  {
    return _commentaire;
  }

  /**
   * @return the creneauClient
   */
  public String getCreneauClient()
  {
    return _creneauClient;
  }

  /**
   * @return the dateClient
   */
  public LocalDateTime getDateClient()
  {
    return _dateClient;
  }

  /**
   * @return the idMandat
   */
  public String getIdMandat()
  {
    return _idMandat;
  }

  /**
   * @return the idRdv
   */
  public String getIdRdv()
  {
    return _idRdv;
  }

  /**
   * @return the prestataire
   */
  public String getPrestataire()
  {
    return _prestataire;
  }

  /**
   * @return the typeMes
   */
  public String getTypeMes()
  {
    return _typeMes;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_commentaire == null) ? 0 : _commentaire.hashCode());
    result = (prime * result) + ((_creneauClient == null) ? 0 : _creneauClient.hashCode());
    result = (prime * result) + ((_dateClient == null) ? 0 : _dateClient.hashCode());
    result = (prime * result) + ((_idMandat == null) ? 0 : _idMandat.hashCode());
    result = (prime * result) + ((_idRdv == null) ? 0 : _idRdv.hashCode());
    result = (prime * result) + ((_prestataire == null) ? 0 : _prestataire.hashCode());
    result = (prime * result) + ((_typeMes == null) ? 0 : _typeMes.hashCode());
    return result;
  }

  /**
   * @param commentaire_p
   *          the commentaire to set
   */
  public void setCommentaire(String commentaire_p)
  {
    _commentaire = commentaire_p;
  }

  /**
   * @param creneauClient_p
   *          the creneauClient to set
   */
  public void setCreneauClient(String creneauClient_p)
  {
    _creneauClient = creneauClient_p;
  }

  /**
   * @param dateClient_p
   *          the dateClient to set
   */
  public void setDateClient(LocalDateTime dateClient_p)
  {
    _dateClient = dateClient_p;
  }

  /**
   * @param idMandat_p
   *          the idMandat to set
   */
  public void setIdMandat(String idMandat_p)
  {
    _idMandat = idMandat_p;
  }

  /**
   * @param idRdv_p
   *          the idRdv to set
   */
  public void setIdRdv(String idRdv_p)
  {
    _idRdv = idRdv_p;
  }

  /**
   * @param prestataire_p
   *          the prestataire to set
   */
  public void setPrestataire(String prestataire_p)
  {
    _prestataire = prestataire_p;
  }

  /**
   * @param typeMes_p
   *          the typeMes to set
   */
  public void setTypeMes(String typeMes_p)
  {
    _typeMes = typeMes_p;
  }

  @Override
  public String toString()
  {
    StringBuilder builder = new StringBuilder();
    builder.append("PI0035_ContexteInstallation [_idMandat="); //$NON-NLS-1$
    builder.append(_idMandat);
    builder.append(", _typeMes="); //$NON-NLS-1$
    builder.append(_typeMes);
    builder.append(", _dateClient="); //$NON-NLS-1$
    builder.append(_dateClient);
    builder.append(", _creneauClient="); //$NON-NLS-1$
    builder.append(_creneauClient);
    builder.append(", _idRdv="); //$NON-NLS-1$
    builder.append(_idRdv);
    builder.append(", _prestataire="); //$NON-NLS-1$
    builder.append(_prestataire);
    builder.append(", _commentaire="); //$NON-NLS-1$
    builder.append(_commentaire);
    builder.append("]"); //$NON-NLS-1$
    return builder.toString();
  }
}
