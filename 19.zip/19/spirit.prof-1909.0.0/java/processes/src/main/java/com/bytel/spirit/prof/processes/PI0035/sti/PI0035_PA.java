/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PI0035.sti;

import java.io.Serializable;
import java.time.LocalDateTime;

import com.bytel.ravel.common.json.annotations.RavelLocalDateTimeFormat;
import com.bytel.ravel.common.json.annotations.RavelPolymorphism;
import com.bytel.ravel.common.json.annotations.RavelPolymorphismProfil;
import com.bytel.ravel.common.json.annotations.RavelPolymorphisms;
import com.bytel.ravel.common.json.format.impl.IsoShortOffsetDateTimeWithMillis;
import com.bytel.spirit.common.shared.misc.ressources.SpiritConstants;
import com.bytel.spirit.common.shared.saab.rpg.PA;
import com.bytel.spirit.common.shared.saab.rpg.TypePA;
import com.squareup.moshi.Json;

/**
 *
 * @author jiantila
 * @version ($Revision$ $Date$)
 */
@RavelPolymorphisms({ @RavelPolymorphismProfil( //
    name = SpiritConstants.JSON_PROFILE_STARK, //
    type = "typePA", //
    value = { //
        @RavelPolymorphism(type = "COMPTE_ACCES", clazz = PI0035_PACompteAcces.class), //
        @RavelPolymorphism(type = "COMPTE_ACCES_SECONDAIRE", clazz = PI0035_PACompteAccesSecondaire.class), //
        @RavelPolymorphism(type = "FAX", clazz = PI0035_PAFAX.class), //
        @RavelPolymorphism(type = "LIGNE_FIXE", clazz = PI0035_PALigneFixe.class), //
        @RavelPolymorphism(type = "TV", clazz = PI0035_PATV.class), //
        @RavelPolymorphism(type = "VOIP", clazz = PI0035_PAVoip.class) //
    }) //
}) //
public class PI0035_PA implements Serializable
{

  /**
   *
   */
  private static final long serialVersionUID = 2012517633778259619L;

  /**
   * Creates a new instance of {@link PI0035_PA} from an instance of type {@link PA}
   *
   * @param pa_p
   *          The {@link PA} instance
   * @return The {@link PI0035_PA} instance.
   */
  public static PI0035_PA buildFromPA(PA pa_p)
  {

    PI0035_PA pa = null;
    TypePA typePA = TypePA.valueOf(pa_p.getTypePA()); // typePA is required, so no exception here
    switch (typePA)
    {
      case COMPTE_ACCES:
        pa = PI0035_PACompteAcces.buildFromPACA(pa_p);
        break;
      case COMPTE_ACCES_SECONDAIRE:
        pa = PI0035_PACompteAccesSecondaire.buildFromPACAS(pa_p);
        break;
      case FAX:
        pa = PI0035_PAFAX.buildFromPAFAX(pa_p);
        break;
      case LIGNE_FIXE:
        pa = PI0035_PALigneFixe.buildFromPALigneFixe(pa_p);
        break;
      case TV:
        pa = PI0035_PATV.buildFromPATV(pa_p);
        break;
      case VOIP:
        pa = PI0035_PAVoip.buildFromPAVoip(pa_p);
        break;
    }
    if (pa != null)
    {
      //set optional attributs
      pa.setIdentifiantFonctionnelPALie(pa_p.getIdentifiantFonctionnelPALie());
    }

    return pa;
  }

  /**
   * Identifiant unique du PA pour un PFI fourni par le client opérateur
   */
  @Json(name = "identifiantFonctionnelPA")
  private String _identifiantFonctionnelPA;

  /**
   * Statut de l'objet commercial attendu par le client opérateur
   */
  @Json(name = "statut")
  private String _statut;

  /**
   * Type de Point d'Accès
   */
  @Json(name = "typePA")
  private String _typePA;

  /**
   * Identifiant unique du PA
   */
  @Json(name = "identifiantFonctionnelPALie")
  private String _identifiantFonctionnelPALie;

  /**
   * Date de creation
   */
  @Json(name = "dateCreation")
  @RavelLocalDateTimeFormat(IsoShortOffsetDateTimeWithMillis.class)
  private LocalDateTime _dateCreation;

  /**
   * Date de Modification
   */
  @Json(name = "dateModification")
  @RavelLocalDateTimeFormat(IsoShortOffsetDateTimeWithMillis.class)
  private LocalDateTime _dateModification;

  /**
   *
   */
  public PI0035_PA()
  {
    super();
  }

  /**
   * Constructor with required fields.
   *
   * @param identifiantFonctionnelPA_p
   *          identifiantFonctionnelPA
   * @param statut_p
   *          statut
   * @param typePA_p
   *          typePA
   * @param dateCreation_p
   *          dateCreation
   * @param dateModification_p
   *          dateModification
   */
  public PI0035_PA(String identifiantFonctionnelPA_p, String statut_p, String typePA_p, LocalDateTime dateCreation_p, LocalDateTime dateModification_p)
  {
    super();

    _identifiantFonctionnelPA = identifiantFonctionnelPA_p;
    _statut = statut_p;
    _typePA = typePA_p;
    _dateCreation = dateCreation_p;
    _dateModification = dateModification_p;
  }

  @Override
  public boolean equals(Object obj_p)
  {
    if (this == obj_p)
    {
      return true;
    }
    if (obj_p == null)
    {
      return false;
    }
    if (getClass() != obj_p.getClass())
    {
      return false;
    }
    PI0035_PA other = (PI0035_PA) obj_p;
    if (_dateCreation == null)
    {
      if (other._dateCreation != null)
      {
        return false;
      }
    }
    else if (!_dateCreation.equals(other._dateCreation))
    {
      return false;
    }

    if (_dateModification == null)
    {
      if (other._dateModification != null)
      {
        return false;
      }
    }
    else if (!_dateModification.equals(other._dateModification))
    {
      return false;
    }

    if (_identifiantFonctionnelPA == null)
    {
      if (other._identifiantFonctionnelPA != null)
      {
        return false;
      }
    }
    else if (!_identifiantFonctionnelPA.equals(other._identifiantFonctionnelPA))
    {
      return false;
    }

    if (_identifiantFonctionnelPALie == null)
    {
      if (other._identifiantFonctionnelPALie != null)
      {
        return false;
      }
    }
    else if (!_identifiantFonctionnelPALie.equals(other._identifiantFonctionnelPALie))
    {
      return false;
    }

    if (_statut == null)
    {
      if (other._statut != null)
      {
        return false;
      }
    }
    else if (!_statut.equals(other._statut))
    {
      return false;
    }

    if (_typePA == null)
    {
      if (other._typePA != null)
      {
        return false;
      }
    }
    else if (!_typePA.equals(other._typePA))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the dateCreation
   */
  public LocalDateTime getDateCreation()
  {
    return _dateCreation;
  }

  /**
   * @return the dateModification
   */
  public LocalDateTime getDateModification()
  {
    return _dateModification;
  }

  /**
   * @return the identifiantFonctionnelPA
   */
  public String getIdentifiantFonctionnelPA()
  {
    return _identifiantFonctionnelPA;
  }

  /**
   * @return the identifiantFonctionnelPALie
   */
  public String getIdentifiantFonctionnelPALie()
  {
    return _identifiantFonctionnelPALie;
  }

  /**
   * @return the statut
   */
  public String getStatut()
  {
    return _statut;
  }

  /**
   * @return the typePA
   */
  public String getTypePA()
  {
    return _typePA;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_identifiantFonctionnelPA == null) ? 0 : _identifiantFonctionnelPA.hashCode());
    result = (prime * result) + ((_identifiantFonctionnelPALie == null) ? 0 : _identifiantFonctionnelPALie.hashCode());
    result = (prime * result) + ((_statut == null) ? 0 : _statut.hashCode());
    result = (prime * result) + ((_typePA == null) ? 0 : _typePA.hashCode());
    result = (prime * result) + ((_dateCreation == null) ? 0 : _dateCreation.hashCode());
    result = (prime * result) + ((_dateModification == null) ? 0 : _dateModification.hashCode());

    return result;
  }

  /**
   * @param dateCreation_p
   *          the dateCreation to set
   */
  public void setDateCreation(LocalDateTime dateCreation_p)
  {
    _dateCreation = dateCreation_p;
  }

  /**
   * @param dateModification_p
   *          the dateModification to set
   */
  public void setDateModification(LocalDateTime dateModification_p)
  {
    _dateModification = dateModification_p;
  }

  /**
   * @param identifiantFonctionnelPA_p
   *          the identifiantFonctionnelPA to set
   */
  public void setIdentifiantFonctionnelPA(String identifiantFonctionnelPA_p)
  {
    _identifiantFonctionnelPA = identifiantFonctionnelPA_p;
  }

  /**
   * @param identifiantFonctionnelPALie_p
   *          the identifiantFonctionnelPALie to set
   */
  public void setIdentifiantFonctionnelPALie(String identifiantFonctionnelPALie_p)
  {
    _identifiantFonctionnelPALie = identifiantFonctionnelPALie_p;
  }

  /**
   * @param statut_p
   *          the statut to set
   */
  public void setStatut(String statut_p)
  {
    _statut = statut_p;
  }

  /**
   * @param typePA_p
   *          the typePA to set
   */
  public void setTypePA(String typePA_p)
  {
    _typePA = typePA_p;
  }

  @Override
  public String toString()
  {
    StringBuilder builder = new StringBuilder();
    builder.append("PI0035_PA [_identifiantFonctionnelPA="); //$NON-NLS-1$
    builder.append(_identifiantFonctionnelPA);
    builder.append(", _statut="); //$NON-NLS-1$
    builder.append(_statut);
    builder.append(", _typePA="); //$NON-NLS-1$
    builder.append(_typePA);
    builder.append(", _identifiantFonctionnelPALie="); //$NON-NLS-1$
    builder.append(_identifiantFonctionnelPALie);
    builder.append(", _dateCreation="); //$NON-NLS-1$
    builder.append(_dateCreation);
    builder.append(", _dateModification="); //$NON-NLS-1$
    builder.append(_dateModification);
    builder.append("]"); //$NON-NLS-1$
    return builder.toString();
  }
}
