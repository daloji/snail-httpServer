/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PI0035.sti;

import java.io.Serializable;

import com.bytel.spirit.common.shared.saab.res.AdresseDonnee;
import com.squareup.moshi.Json;

/**
 *
 * @author jiantila
 * @version ($Revision$ $Date$)
 */
public class PI0035_AdresseDonnee implements Serializable
{
  /**
   *
   */
  private static final long serialVersionUID = 1549164644720072865L;

  /**
   * @param adresseDonnee_p
   * @return
   */
  public static PI0035_AdresseDonnee buildFromAdresseDonnee(AdresseDonnee adresseDonnee_p)
  {
    if (adresseDonnee_p != null)
    {
      return new PI0035_AdresseDonnee(adresseDonnee_p.getVoie(), adresseDonnee_p.getCodeRivoli(), adresseDonnee_p.getCodeInsee(), adresseDonnee_p.getCommune());
    }
    return null;
  }

  /**
   * Numéro dans la voie Peut contenir bis, ter
   */
  @Json(name = "numero")
  private String _numero;

  /**
   * Résidence, Ensemble
   */
  @Json(name = "ensemble")
  private String _ensemble;

  /**
   *
   */
  @Json(name = "batiment")
  private String _batiment;

  /**
   *
   */
  @Json(name = "escalier")
  private String _escalier;

  /**
   *
   */
  @Json(name = "etage")
  private String _etage;

  /**
  *
  */
  @Json(name = "porte")
  private String _porte;

  /**
   * Logo France Telecom
   */
  @Json(name = "logoft")
  private String _logoft;

  /**
   * Nom de la voie
   */
  @Json(name = "voie")
  private String _voie;

  /**
   * Code RIVOLI de la voie
   */
  @Json(name = "codeRivoli")
  private String _codeRivoli;

  /**
   * Code HEXACLE du numéro dans la voie
   */
  @Json(name = "codeHexacle")
  private String _codeHexacle;

  /**
   * Code INSEE de la commune
   */
  @Json(name = "codeInsee")
  private String _codeInsee;

  /**
   * Code Postal de la commune
   */
  @Json(name = "codePostal")
  private String _codePostal;

  /**
   * Code Postal de la commune
   */
  @Json(name = "commune")
  private String _commune;

  /**
   *
   */
  public PI0035_AdresseDonnee()
  {
    super();
  }

  /**
   * @param voie_p
   * @param codeRivoli_p
   * @param codeInsee_p
   * @param commune_p
   */
  public PI0035_AdresseDonnee(String voie_p, String codeRivoli_p, String codeInsee_p, String commune_p)
  {
    super();
    _voie = voie_p;
    _codeRivoli = codeRivoli_p;
    _codeInsee = codeInsee_p;
    _commune = commune_p;
  }

  @Override
  public boolean equals(Object obj_p)
  {
    if (this == obj_p)
    {
      return true;
    }
    if (obj_p == null)
    {
      return false;
    }
    if (getClass() != obj_p.getClass())
    {
      return false;
    }
    PI0035_AdresseDonnee other = (PI0035_AdresseDonnee) obj_p;
    if (_numero == null)
    {
      if (other._numero != null)
      {
        return false;
      }
    }
    else if (!_numero.equals(other._numero))
    {
      return false;
    }

    if (_batiment == null)
    {
      if (other._batiment != null)
      {
        return false;
      }
    }
    else if (!_batiment.equals(other._batiment))
    {
      return false;
    }

    if (_codeHexacle == null)
    {
      if (other._codeHexacle != null)
      {
        return false;
      }
    }
    else if (!_codeHexacle.equals(other._codeHexacle))
    {
      return false;
    }

    if (_codeInsee == null)
    {
      if (other._codeInsee != null)
      {
        return false;
      }
    }
    else if (!_codeInsee.equals(other._codeInsee))
    {
      return false;
    }

    if (_codePostal == null)
    {
      if (other._codePostal != null)
      {
        return false;
      }
    }
    else if (!_codePostal.equals(other._codePostal))
    {
      return false;
    }

    if (_codeRivoli == null)
    {
      if (other._codeRivoli != null)
      {
        return false;
      }
    }
    else if (!_codeRivoli.equals(other._codeRivoli))
    {
      return false;
    }

    if (_commune == null)
    {
      if (other._commune != null)
      {
        return false;
      }
    }
    else if (!_commune.equals(other._commune))
    {
      return false;
    }

    if (_ensemble == null)
    {
      if (other._ensemble != null)
      {
        return false;
      }
    }
    else if (!_ensemble.equals(other._ensemble))
    {
      return false;
    }

    if (_escalier == null)
    {
      if (other._escalier != null)
      {
        return false;
      }
    }
    else if (!_escalier.equals(other._escalier))
    {
      return false;
    }

    if (_etage == null)
    {
      if (other._etage != null)
      {
        return false;
      }
    }
    else if (!_etage.equals(other._etage))
    {
      return false;
    }

    if (_logoft == null)
    {
      if (other._logoft != null)
      {
        return false;
      }
    }
    else if (!_logoft.equals(other._logoft))
    {
      return false;
    }

    if (_porte == null)
    {
      if (other._porte != null)
      {
        return false;
      }
    }
    else if (!_porte.equals(other._porte))
    {
      return false;
    }

    if (_voie == null)
    {
      if (other._voie != null)
      {
        return false;
      }
    }
    else if (!_voie.equals(other._voie))
    {
      return false;
    }

    return true;
  }

  /**
   * @return the batiment
   */
  public String getBatiment()
  {
    return _batiment;
  }

  /**
   * @return the codeHexacle
   */
  public String getCodeHexacle()
  {
    return _codeHexacle;
  }

  /**
   * @return the codeInsee
   */
  public String getCodeInsee()
  {
    return _codeInsee;
  }

  /**
   * @return the codePostal
   */
  public String getCodePostal()
  {
    return _codePostal;
  }

  /**
   * @return the codeRivoli
   */
  public String getCodeRivoli()
  {
    return _codeRivoli;
  }

  /**
   * @return the commune
   */
  public String getCommune()
  {
    return _commune;
  }

  /**
   * @return the ensemble
   */
  public String getEnsemble()
  {
    return _ensemble;
  }

  /**
   * @return the escalier
   */
  public String getEscalier()
  {
    return _escalier;
  }

  /**
   * @return the etage
   */
  public String getEtage()
  {
    return _etage;
  }

  /**
   * @return the logoft
   */
  public String getLogoft()
  {
    return _logoft;
  }

  /**
   * @return the numero
   */
  public String getNumero()
  {
    return _numero;
  }

  /**
   * @return the porte
   */
  public String getPorte()
  {
    return _porte;
  }

  /**
   * @return the voie
   */
  public String getVoie()
  {
    return _voie;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_batiment == null) ? 0 : _batiment.hashCode());
    result = (prime * result) + ((_codeHexacle == null) ? 0 : _codeHexacle.hashCode());

    result = (prime * result) + ((_codeInsee == null) ? 0 : _codeInsee.hashCode());

    result = (prime * result) + ((_codePostal == null) ? 0 : _codePostal.hashCode());
    result = (prime * result) + ((_codeRivoli == null) ? 0 : _codeRivoli.hashCode());
    result = (prime * result) + ((_commune == null) ? 0 : _commune.hashCode());
    result = (prime * result) + ((_ensemble == null) ? 0 : _ensemble.hashCode());
    result = (prime * result) + ((_escalier == null) ? 0 : _escalier.hashCode());
    result = (prime * result) + ((_etage == null) ? 0 : _etage.hashCode());
    result = (prime * result) + ((_logoft == null) ? 0 : _logoft.hashCode());
    result = (prime * result) + ((_numero == null) ? 0 : _numero.hashCode());

    result = (prime * result) + ((_voie == null) ? 0 : _voie.hashCode());
    result = (prime * result) + ((_porte == null) ? 0 : _porte.hashCode());

    return result;
  }

  /**
   * @param batiment_p
   *          the batiment to set
   */
  public void setBatiment(String batiment_p)
  {
    _batiment = batiment_p;
  }

  /**
   * @param codeHexacle_p
   *          the codeHexacle to set
   */
  public void setCodeHexacle(String codeHexacle_p)
  {
    _codeHexacle = codeHexacle_p;
  }

  /**
   * @param codeInsee_p
   *          the codeInsee to set
   */
  public void setCodeInsee(String codeInsee_p)
  {
    _codeInsee = codeInsee_p;
  }

  /**
   * @param codePostal_p
   *          the codePostal to set
   */
  public void setCodePostal(String codePostal_p)
  {
    _codePostal = codePostal_p;
  }

  /**
   * @param codeRivoli_p
   *          the codeRivoli to set
   */
  public void setCodeRivoli(String codeRivoli_p)
  {
    _codeRivoli = codeRivoli_p;
  }

  /**
   * @param commune_p
   *          the commune to set
   */
  public void setCommune(String commune_p)
  {
    _commune = commune_p;
  }

  /**
   * @param ensemble_p
   *          the ensemble to set
   */
  public void setEnsemble(String ensemble_p)
  {
    _ensemble = ensemble_p;
  }

  /**
   * @param escalier_p
   *          the escalier to set
   */
  public void setEscalier(String escalier_p)
  {
    _escalier = escalier_p;
  }

  /**
   * @param etage_p
   *          the etage to set
   */
  public void setEtage(String etage_p)
  {
    _etage = etage_p;
  }

  /**
   * @param logoft_p
   *          the logoft to set
   */
  public void setLogoft(String logoft_p)
  {
    _logoft = logoft_p;
  }

  /**
   * @param numero_p
   *          the numero to set
   */
  public void setNumero(String numero_p)
  {
    _numero = numero_p;
  }

  /**
   * @param porte_p
   *          the porte to set
   */
  public void setPorte(String porte_p)
  {
    _porte = porte_p;
  }

  /**
   * @param voie_p
   *          the voie to set
   */
  public void setVoie(String voie_p)
  {
    _voie = voie_p;
  }

  @Override
  public String toString()
  {
    StringBuilder builder = new StringBuilder();
    builder.append("PI0035_AdresseDonnee [_numero="); //$NON-NLS-1$
    builder.append(_numero);
    builder.append(", _ensemble="); //$NON-NLS-1$
    builder.append(_ensemble);
    builder.append(", _batiment="); //$NON-NLS-1$
    builder.append(_batiment);
    builder.append(", _escalier="); //$NON-NLS-1$
    builder.append(_escalier);
    builder.append(", _etage="); //$NON-NLS-1$
    builder.append(_etage);
    builder.append(", _porte="); //$NON-NLS-1$
    builder.append(_porte);
    builder.append(", _logoft="); //$NON-NLS-1$
    builder.append(_logoft);
    builder.append(", _voie="); //$NON-NLS-1$
    builder.append(_voie);
    builder.append(", _codeRivoli="); //$NON-NLS-1$
    builder.append(_codeRivoli);
    builder.append(", _codeHexacle="); //$NON-NLS-1$
    builder.append(_codeHexacle);
    builder.append(", _codeInsee="); //$NON-NLS-1$
    builder.append(_codeInsee);
    builder.append(", _codePostal="); //$NON-NLS-1$
    builder.append(_codePostal);
    builder.append(", _commune="); //$NON-NLS-1$
    builder.append(_commune);
    builder.append("]"); //$NON-NLS-1$
    return builder.toString();
  }
}
