/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PI0035.sti;

import java.time.LocalDateTime;

import com.bytel.ravel.common.json.annotations.RavelPolymorphism;
import com.bytel.ravel.common.json.annotations.RavelPolymorphismProfil;
import com.bytel.ravel.common.json.annotations.RavelPolymorphisms;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.AbstractStPfs;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.TypePFS;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.UnknownStPfs;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.acsiad.StPfsAcsIad;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.clf.StPfsClf;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.fqdn.StPfsFqdn;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.hssfixe.StPfsHSSFixe;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.mail.StPfsMail;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.olt.StPfsOlt;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.pfs_enum.StPfsEnum;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.pnf.StPfsPnf;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.sam.StPfsSam;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.tasfixe.StPfsTASFixe;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.vmscvm.StPfsVmsCvm;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.vmsstw.StPfsVmsStw;
import com.bytel.spirit.common.shared.misc.ressources.SpiritConstants;
import com.bytel.spirit.common.shared.saab.rst.ServiceTechnique;
import com.bytel.spirit.common.shared.saab.rst.TypeST;
import com.squareup.moshi.Json;

/**
 *
 * @author jgregori
 * @version ($Revision$ $Date$)
 */

@RavelPolymorphisms({ //
    @RavelPolymorphismProfil( //
        name = SpiritConstants.JSON_PROFILE_STARK, //
        type = "typePfs", //
        defaultClass = PI0035_UnknownStPfs.class, //
        value = { //
            @RavelPolymorphism(type = "MAIL", clazz = PI0035_StPfsMail.class), //
            @RavelPolymorphism(type = "OLT", clazz = PI0035_StPfsOlt.class), //
            @RavelPolymorphism(type = "SAM", clazz = PI0035_StPfsSam.class), //
            @RavelPolymorphism(type = "CLF", clazz = PI0035_StPfsClf.class), //
            @RavelPolymorphism(type = "PNF", clazz = PI0035_StPfsPnf.class), //
            @RavelPolymorphism(type = "VMS_STW", clazz = PI0035_StPfsVmsStw.class), //
            @RavelPolymorphism(type = "ACS_IAD", clazz = PI0035_StPfsAcsIad.class), //
            @RavelPolymorphism(type = "FQDN", clazz = PI0035_StPfsFqdn.class), //
            @RavelPolymorphism(type = "ENUM", clazz = PI0035_StPfsEnum.class), //
            @RavelPolymorphism(type = "HSS_FIXE", clazz = PI0035_StPfsHSSFixe.class), //
            @RavelPolymorphism(type = "TAS_FIXE", clazz = PI0035_StPfsTASFixe.class) //
        }) //
})
public abstract class PI0035_AbstractStPfs extends PI0035_ServiceTechnique
{
  /**
   *
   */
  private static final long serialVersionUID = 5586390816760461690L;

  /**
   * Builds a new instance of {@link PI0035_AbstractStPfs} from an instance of {@link ServiceTechnique}
   *
   * @param st_p
   *          The instance of {@link ServiceTechnique}.
   * @return The instance of {@link PI0035_AbstractStPfs}.
   */
  public static PI0035_ServiceTechnique buildFromSTPFS(ServiceTechnique st_p)
  {
    TypePFS typePfs = TypePFS.valueOf(AbstractStPfs.class.cast(st_p).getTypePfs());
    PI0035_ServiceTechnique stPfs = null;

    if (typePfs == null)
    {
      return PI0035_UnknownStPfs.buildFromUnknownStPfs(UnknownStPfs.class.cast(st_p));
    }

    switch (typePfs)
    {
      case MAIL:
        stPfs = PI0035_StPfsMail.buildFromSTPFSMail(StPfsMail.class.cast(st_p));
        break;
      case OLT:
        stPfs = PI0035_StPfsOlt.buildFromSTPfsOlt(StPfsOlt.class.cast(st_p));
        break;
      case SAM:
        stPfs = PI0035_StPfsSam.buildFromStPfsSam(StPfsSam.class.cast(st_p));
        break;
      case CLF:
        stPfs = PI0035_StPfsClf.buildFromStPfsClf(StPfsClf.class.cast(st_p));
        break;
      case PNF:
        stPfs = PI0035_StPfsPnf.buildFromStPfsPnf(StPfsPnf.class.cast(st_p));
        break;
      case VMS_STW:
        stPfs = PI0035_StPfsVmsStw.buildFromStPfsVmsStw(StPfsVmsStw.class.cast(st_p));
        break;
      case ACS_IAD:
        stPfs = PI0035_StPfsAcsIad.buildFromStPfsAcsIad(StPfsAcsIad.class.cast(st_p));
        break;
      case FQDN:
        stPfs = PI0035_StPfsFqdn.buildFromStPfsFqdn(StPfsFqdn.class.cast(st_p));
        break;
      case ENUM:
        stPfs = PI0035_StPfsEnum.buildFromStPfsEnum(StPfsEnum.class.cast(st_p));
        break;
      case VMS_CVM:
        stPfs = PI0035_StPfsVmsCvm.buildFromStPfsVmsCvm(StPfsVmsCvm.class.cast(st_p));
        break;
      case HSS_FIXE:
        stPfs = PI0035_StPfsHSSFixe.buildFromStPfsHSSFixe(StPfsHSSFixe.class.cast(st_p));
        break;
      case TAS_FIXE:
        stPfs = PI0035_StPfsTASFixe.buildFromStPfsTASFixe(StPfsTASFixe.class.cast(st_p));
        break;

      default:
        stPfs = PI0035_UnknownStPfs.buildFromUnknownStPfs(UnknownStPfs.class.cast(st_p));
        break;
    }

    return stPfs;
  }

  /**
   * typePfs
   */
  @Json(name = "typePfs")
  private String _typePfs;

  /**
   * @param idSt_p
   *          id
   * @param statut_p
   *          statut
   * @param typePfs_p
   *          type pfs
   * @param dateCreation_p
   *          date creation
   * @param dateModification_p
   *          date modification
   */
  public PI0035_AbstractStPfs(String idSt_p, String statut_p, String typePfs_p, LocalDateTime dateCreation_p, LocalDateTime dateModification_p)
  {
    super(idSt_p, statut_p, TypeST.PFS.name(), dateCreation_p, dateModification_p);

    _typePfs = typePfs_p;
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (!super.equals(obj))
    {
      return false;
    }
    if (getClass() != obj.getClass()) // NOSONAR
    {
      return false;
    }
    PI0035_AbstractStPfs other = (PI0035_AbstractStPfs) obj;
    if (_typePfs == null)
    {
      if (other._typePfs != null)
      {
        return false;
      }
    }
    else if (!_typePfs.equals(other._typePfs))
    {
      return false;
    }
    return true;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = super.hashCode();
    result = (prime * result) + ((_typePfs == null) ? 0 : _typePfs.hashCode());
    return result;
  }

  @Override
  public String toString()
  {
    StringBuilder builder = new StringBuilder();
    builder.append("PI0035_AbstractStPfs [_typePfs="); //$NON-NLS-1$
    builder.append(_typePfs);
    builder.append(", getCommentaire()="); //$NON-NLS-1$
    builder.append(getCommentaire());
    builder.append(", getDateCreation()="); //$NON-NLS-1$
    builder.append(getDateCreation());
    builder.append(", getDateModification()="); //$NON-NLS-1$
    builder.append(getDateModification());
    builder.append(", getIdSt()="); //$NON-NLS-1$
    builder.append(getIdSt());
    builder.append(", getStatut()="); //$NON-NLS-1$
    builder.append(getStatut());
    builder.append(", getTypeServiceTechnique()="); //$NON-NLS-1$
    builder.append(getTypeServiceTechnique());
    builder.append("]"); //$NON-NLS-1$
    return builder.toString();
  }
}
