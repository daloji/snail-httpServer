/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PE0147;

import java.text.MessageFormat;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.datetime.DateTimeManager;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.response.IRavelResponse;
import com.bytel.ravel.common.factory.response.RavelResponseFactory;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.DateTimeTools.DateTimeFormatPattern;
import com.bytel.ravel.common.utils.Pair;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.aspectJ.LogContinueProcess;
import com.bytel.ravel.services.aspectJ.LogProcessBL;
import com.bytel.ravel.services.aspectJ.LogStartProcess;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.MandatoryProcessState;
import com.bytel.ravel.services.process.activity.Context;
import com.bytel.spirit.common.activities.shared.BL1700_AjouterRefFonc;
import com.bytel.spirit.common.activities.shared.BL4600_CreerErreurSpirit;
import com.bytel.spirit.common.activities.shared.BL4600_CreerErreurSpirit.BL4600_CreerErreurSpiritBuilder;
import com.bytel.spirit.common.activities.shared.BL800_ObtenirSequence;
import com.bytel.spirit.common.activities.shared.structs.UniqueIdConstant;
import com.bytel.spirit.common.connectors.cmd.CMDProxy;
import com.bytel.spirit.common.connectors.rpg.RPGProxy;
import com.bytel.spirit.common.shared.saab.cmd.Commande;
import com.bytel.spirit.common.shared.saab.cmd.ModificationCommerciale;
import com.bytel.spirit.common.shared.saab.cmd.Statut;
import com.bytel.spirit.common.shared.saab.cmd.StatutCommercialAttendu;
import com.bytel.spirit.common.shared.saab.cmd.request.CreateModificationCommercialeRequest;
import com.bytel.spirit.common.shared.saab.rpg.PA;
import com.bytel.spirit.common.shared.saab.rpg.PFI;
import com.bytel.spirit.common.shared.saab.rpg.PaTypeCompteAccesSecondaire;
import com.bytel.spirit.common.shared.saab.rpg.TypePA;
import com.bytel.spirit.common.shared.saab.rpg.request.CreatePfiRequest;
import com.bytel.spirit.common.shared.saab.TypeObjetCommercial;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.processes.SpiritProcessSkeleton;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.ressources.RetourConverter;
import com.bytel.spirit.common.shared.misc.tracabilite.IRefFoncConstants;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.prof.processes.Messages;
import com.bytel.spirit.prof.processes.PE0147.structs.PEP0147_Retour;
import com.bytel.spirit.prof.processes.PE0147.structs.PEP0147_Retour.ReponseFonctionnelle;
import com.bytel.spirit.prof.processes.PE0147.structs.PEP0147_RetourBL001;
import com.bytel.spirit.prof.shared.types.json.CommandeId;
import com.bytel.spirit.prof.shared.types.json.request.ServiceMailGererMailSecondaireRequest;

/**
 *
 * @author mbaptist
 * @version ($Revision$ $Date$)
 */
public class PEP0147_GererMailSecondaire extends SpiritProcessSkeleton
{
  /**
   * Process context
   *
   *
   */
  public static final class PEP0147_GererMailSecondaireContext extends Context
  {

    /**
     *
     */
    private static final long serialVersionUID = -5857715653447250296L;

    /**
     * ReponseFonctionnelle
     */
    private ReponseFonctionnelle _reponsefonctionnel;

    /**
     * Retour
     */
    private Retour _retour;
    /***
     * Contains the next step to execute. Initialized with the first step to execute.
     */
    private State _state = State.PEP0147_BL001;

    /**
     * @return the reponsefonctionnel
     */
    public ReponseFonctionnelle getReponsefonctionnel()
    {
      return _reponsefonctionnel;
    }

    /**
     * @return the retour
     */
    public Retour getRetour()
    {
      return _retour;
    }

    /**
     * @return the state
     */
    public State getState()
    {
      return _state;
    }

    /**
     * @param reponsefonctionnel_p
     *          the reponsefonctionnel to set
     */
    public void setReponsefonctionnel(ReponseFonctionnelle reponsefonctionnel_p)
    {
      _reponsefonctionnel = reponsefonctionnel_p;
    }

    /**
     * @param retour_p
     *          the retour to set
     */
    public void setRetour(Retour retour_p)
    {
      _retour = retour_p;
    }

    /**
     * @param state_p
     *          the state to set
     */
    public void setState(State state_p)
    {
      _state = state_p;
    }
  }

  /**
   * The enum containing all process states
   *
   * @author mbaptist
   * @version ($revision$ $Date$)
   */
  public enum State
  {
    /**
     * PEI0147_BL001_VerifierDonnes
     */
    PEP0147_BL001(MandatoryProcessState.PRC_START, false, false),
    /**
     * PEP0147_BL100_RecupererPfi
     */
    PEP0147_BL100(MandatoryProcessState.PRC_RUNNING, false, false),
    /**
     * PEP0147_BL200_CreerMailSecondaire
     */
    PEP0147_BL200(MandatoryProcessState.PRC_RUNNING, false, false),
    /**
     * PEP0147_BL300_ResilierMailSecondaire
     */
    PEP0147_BL300(MandatoryProcessState.PRC_RUNNING, false, false),
    /**
     * PEP0147_BL002_FormaterReponse
     */
    PEP0147_BL002(MandatoryProcessState.PRC_RUNNING, false, false),
    /**
     * PEP0147_BL005_GererErreurPROSPER
     */
    PEP0147_BL005(MandatoryProcessState.PRC_RUNNING, true, true),
    /**
     * Terminal state
     */
    ENDED(MandatoryProcessState.PRC_STOP, false, false);

    /**
     * Technical state associated.
     */
    protected MandatoryProcessState _technicalState = MandatoryProcessState.PRC_START;

    /**
     * The asynchronousState = false;
     */
    protected boolean _asynchronousState = false;

    /**
     * Replayed
     */
    protected boolean _replayableState = false;

    /**
     * Constructor.
     *
     * @param technicalState_p
     *          The {@link MandatoryProcessState} associated
     * @param replayable_p
     *          is replayable state
     * @param asynchronous_p
     *          is asynchronous state
     */
    private State(final MandatoryProcessState technicalState_p, boolean replayable_p, boolean asynchronous_p)
    {
      _technicalState = technicalState_p;
      _replayableState = replayable_p;
      _asynchronousState = asynchronous_p;
    }
  }

  /**
   *
   */
  private static final long serialVersionUID = 5928390333289184369L;

  /**
   * The process context.
   */
  private PEP0147_GererMailSecondaireContext _processContext;

  @Override
  public String createDefaultFunctionalResponse(Retour retour_p) throws RavelException
  {
    return StringConstants.EMPTY_STRING;
  }

  @Override
  public String getInternalState()
  {
    return _processContext.getState().toString();
  }

  @Override
  public Duration getSleepTime()
  {
    return Duration.ofMinutes(0);
  }

  @Override
  public MandatoryProcessState getTechnicalState()
  {
    return _processContext.getState()._technicalState;
  }

  @Override
  public void initializeContext()
  {
    _processContext = new PEP0147_GererMailSecondaireContext();
  }

  @Override
  public boolean isAsynchronous()
  {
    return _processContext.getState()._asynchronousState;
  }

  @Override
  public boolean isReplayable()
  {
    return _processContext.getState()._replayableState;
  }

  @Override
  @LogContinueProcess
  protected void continueProcess(Request request_p, Tracabilite tracabilite_p) throws RavelException
  {
    Retour retour = _processContext.getRetour();
    if (State.PEP0147_BL005.equals(_processContext.getState()))
    {

      retour = PEP0147_BL005_GererErreurPROSPER(tracabilite_p, retour);
    }
    _processContext.setState(State.ENDED);
    setRetour(retour);
  }

  @Override
  protected void exitKOMetroLog(String reason_p)
  {
    // Not required for now in Ravel

  }

  @Override
  protected void startMetroLog()
  {
    // Not required for now in Ravel

  }

  @Override
  @LogStartProcess
  protected void startProcess(Request request_p, Tracabilite tracabilite_p) throws RavelException
  {
    Retour retour = RetourFactory.createOkRetour();
    PFI pfi = null;
    try
    {
      final CommandeId commandeId = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).fromJson(request_p.getPayload(), CommandeId.class);
      String idCmd = commandeId.getValue();
      _processContext.setState(State.PEP0147_BL001);
      Pair<Retour, PEP0147_RetourBL001> retourBL001 = PEP0147_BL001_VerifierDonnees(tracabilite_p, idCmd);
      retour = retourBL001._first;
      PEP0147_RetourBL001 objBL001 = retourBL001._second;
      if (isRetourOK(retour))
      {
        String statut = objBL001.getStatut();
        String mail = objBL001.getMail();
        Commande cmd = objBL001.getCommandeGP();
        _processContext.setState(State.PEP0147_BL100);
        Pair<Retour, PFI> retourBL100 = PEP0147_BL100_RecupererPFI(tracabilite_p, cmd);
        retour = retourBL100._first;
        pfi = retourBL100._second;
        if (isRetourOK(retour))
        {

          if (com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF.name().equals(statut))
          {
            _processContext.setState(State.PEP0147_BL200);
            retour = PEP0147_BL200_CreerMailSecondaire(tracabilite_p, pfi, mail, cmd);
          }
          if (com.bytel.spirit.common.shared.saab.rpg.Statut.RESILIE.name().equals(statut))
          {
            _processContext.setState(State.PEP0147_BL300);
            retour = PEP0147_BL300_ResilierMailSecondaire(tracabilite_p, pfi, mail, cmd);
          }
          if (isRetourOK(retour))
          {
            ConnectorResponse<Retour, Nothing> connectorResponse = CMDProxy.getInstance().commandeModifierStatut(tracabilite_p, idCmd, Statut.EN_COURS.name(), StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
            retour = connectorResponse._first;
          }
        }
      }
    }
    catch (Exception ex)
    {
      retour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, ex.getMessage());
      _processContext.setRetour(retour);
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, ex));
    }
    finally
    {
      _processContext.setState(State.PEP0147_BL002);
      _processContext.setRetour(retour);
      PEP0147_Retour pepRetour = PEP0147_BL002_FormaterReponse(tracabilite_p, retour, pfi);
      syncResponse(request_p, tracabilite_p, pepRetour);
      _processContext.setReponsefonctionnel(pepRetour.getReponseFonctionnelle());
      setRetour(retour);
      _processContext.setState(State.PEP0147_BL005);
    }
  }

  /**
   *
   * @param tracabilite_p
   *          Object {@code Tracabilite}
   * @param idCmd_p
   *          Id commande
   * @return Pair<Retour, PEP0147_RetourBL001>
   * @throws RavelException
   *           On errors
   *
   */
  @LogProcessBL
  private Pair<Retour, PEP0147_RetourBL001> PEP0147_BL001_VerifierDonnees(Tracabilite tracabilite_p, String idCmd_p) throws RavelException
  {

    Map<String, String> refFonc = new HashMap<>();
    refFonc.put(IRefFoncConstants.ID_CMD, idCmd_p);
    BL1700_AjouterRefFonc bl1700 = new BL1700_AjouterRefFonc.BL1700_AjouterRefFoncBuilder().tracabilite(tracabilite_p).refFonc(refFonc).build();
    bl1700.execute(this);

    ConnectorResponse<Retour, Commande> retourCMD = CMDProxy.getInstance().commandeLireUn(tracabilite_p, idCmd_p);
    Retour retour = retourCMD._first;
    Commande commande = retourCMD._second;
    PEP0147_RetourBL001 pep0147_RetourBL001 = new PEP0147_RetourBL001();

    if (isRetourOK(retour))
    {
      if (!Statut.ACQUITTE.toString().equals(commande.getStatut()))
      {
        retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.DONNEE_INVALIDE, MessageFormat.format(Messages.getString("PEP0147.CommandeNonTraitee"), retourCMD._second.getIdCmd(), retourCMD._second.getStatut())); //$NON-NLS-1$
        RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, Messages.getString("PEP0147.CommandeNonTraitee"))); //$NON-NLS-1$
      }
      else
      {
        ServiceMailGererMailSecondaireRequest gererMailSecondaireRequest = GsonTools.getIso8601Ms().fromJson(commande.getDonneesBrut(), ServiceMailGererMailSecondaireRequest.class);

        pep0147_RetourBL001.setStatut(gererMailSecondaireRequest.getMailSecondaire().getStatut());
        pep0147_RetourBL001.setMail(gererMailSecondaireRequest.getMailSecondaire().getMail());
        pep0147_RetourBL001.setCommandeGP(commande);
      }
    }

    return new Pair<>(retour, pep0147_RetourBL001);
  }

  /**
   * @param tracabilite_p
   *          Tracabilite
   * @param retour_p
   *          Retour
   * @param pfi_p
   *          PFI
   * @return PEP0147_Retour
   */
  @LogProcessBL
  private PEP0147_Retour PEP0147_BL002_FormaterReponse(Tracabilite tracabilite_p, Retour retour_p, PFI pfi_p)
  {
    PEP0147_Retour pep0147_Retour = new PEP0147_Retour(RetourConverter.convertToJsonRetour(retour_p));

    ReponseFonctionnelle reponseFonctionnelle = null;
    if (isRetourOK(retour_p))
    {
      if (pfi_p != null)
      {
        reponseFonctionnelle = new ReponseFonctionnelle();
        reponseFonctionnelle.setClientOperateur(pfi_p.getClientOperateur());
        reponseFonctionnelle.setNoCompte(pfi_p.getNoCompte());

        pep0147_Retour.setReponseFonctionnelle(reponseFonctionnelle);
      }
    }

    return pep0147_Retour;
  }

  /**
   * @param tracabilite_p
   * @param retour_p
   * @return
   * @throws RavelException
   */
  @LogProcessBL
  private Retour PEP0147_BL005_GererErreurPROSPER(Tracabilite tracabilite_p, Retour retour_p) throws RavelException
  {
    if (StringConstants.NOK.equals(retour_p.getResultat()))
    {
      // call activite BL4600
      BL4600_CreerErreurSpirit bl4600 = new BL4600_CreerErreurSpiritBuilder().tracabilite(tracabilite_p).retour(retour_p).build();
      bl4600.execute(this);
      return bl4600.getRetour();
    }
    return retour_p;
  }

  /**
   *
   * @param tracabilite_p
   *          Object {@code Tracabilite}
   * @param commande_p
   *          The Commande
   * @return Pair<Retour, PFI>
   * @throws RavelException
   *           On errors
   *
   */
  @LogProcessBL
  private Pair<Retour, PFI> PEP0147_BL100_RecupererPFI(Tracabilite tracabilite_p, Commande commande_p) throws RavelException
  {
    ConnectorResponse<Retour, PFI> rpg = RPGProxy.getInstance().pfiLireUn(tracabilite_p, commande_p.getClientOperateur(), commande_p.getNoCompte());
    return new Pair<Retour, PFI>(rpg._first, rpg._second);
  }

  /**
   * PEP0147_BL200_CreerMailSecondaire
   *
   * @param tracabilite_p
   *          tracabilite
   * @param pfi_p
   *          pfi
   * @param adresseMail_p
   *          adressemail
   * @param commande_p
   *          commande
   * @return
   * @throws RavelException
   *           exception
   */
  @LogProcessBL
  private Retour PEP0147_BL200_CreerMailSecondaire(Tracabilite tracabilite_p, PFI pfi_p, String adresseMail_p, Commande commande_p) throws RavelException
  {
    Retour retour = RetourFactory.createOkRetour();
    PA oPaca = null;
    PA opacas = null;

    // on recherche en même temps le PA COMPTE ACCES et le PA COMPTE ACCES SECONDAIRE
    for (PA pa : pfi_p.getPa())
    {
      if (TypePA.COMPTE_ACCES.name().equals(pa.getTypePA()) && (com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF == pa.getStatut()))
      {
        oPaca = pa;
      }

      if (pa.getPaTypeCompteAccesSecondaire() != null)
      {

        if (TypePA.COMPTE_ACCES_SECONDAIRE.name().equals(pa.getTypePA()) && adresseMail_p.equals(pa.getPaTypeCompteAccesSecondaire().getLoginEmail()))
        {
          opacas = pa;
        }
      }
    }

    // si PA compte ACCES  trouvé
    if (oPaca != null)
    {
      LocalDateTime currentDateTime = LocalDateTime.now();
      // si PA compte ACCES SECONDAIRE trouvé avec l'adresse mail
      if (opacas != null)
      {
        opacas.setStatut(com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF);
        opacas.setDateModification(currentDateTime);
      }
      else
      {
        // si PA compte ACCES SECONDAIRE non trouvé avec l'adresse mail on l'a crée

        BL800_ObtenirSequence bl800 = new BL800_ObtenirSequence.BL800_ObtenirSequenceBuilder().tracabilite(tracabilite_p).code(UniqueIdConstant.ID_PA_COMPTE_ACCES_SECONDAIRE).build();
        String idPa = bl800.execute(this);

        //creation du PA
        opacas = new PA(idPa, TypePA.COMPTE_ACCES_SECONDAIRE.name(), com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, currentDateTime, currentDateTime);
        PaTypeCompteAccesSecondaire typaSecondaire = new PaTypeCompteAccesSecondaire(adresseMail_p);
        typaSecondaire.setIgnorerReconciliationInterne(false);
        opacas.setPaTypeCompteAccesSecondaire(typaSecondaire);
        opacas.setTypeObjetCommercial("PA"); //$NON-NLS-1$
        opacas.setIdentifiantFonctionnelPA(idPa);
        opacas.setIdentifiantFonctionnelPALie(oPaca.getIdentifiantFonctionnelPA());
        opacas.setTypePA(TypePA.COMPTE_ACCES_SECONDAIRE.name());
        //add new created PA to the PFI PA list
        List<PA> paList = pfi_p.getPa();
        paList.add(opacas);
        pfi_p.setPa(paList);
        pfi_p.setDateModification(currentDateTime);
      }

      BL800_ObtenirSequence bl800 = new BL800_ObtenirSequence.BL800_ObtenirSequenceBuilder().tracabilite(tracabilite_p).code(UniqueIdConstant.ID_MOD_COM).build();
      String idModifComm = bl800.execute(this);
      //Creation modification commercial;
      ModificationCommerciale modComm = new ModificationCommerciale();
      modComm.setIdModificationCommerciale(idModifComm);
      modComm.setStatut(Statut.EN_COURS.name());
      modComm.setStatutCommercialAttendu(com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF.name());
      modComm.setTypeObjetCommercial("PA"); //$NON-NLS-1$
      modComm.setIdentifiantFonctionnelPA(opacas.getIdentifiantFonctionnelPA());
      modComm.setIdCmd(commande_p.getIdCmd());
      modComm.setClientOperateur(commande_p.getClientOperateur());
      modComm.setNoCompte(commande_p.getNoCompte());
      modComm.setDateCreation(currentDateTime);
      modComm.setDateModification(currentDateTime);

      List<ModificationCommerciale> listModComm = new ArrayList<>();
      listModComm.add(modComm);

      CreateModificationCommercialeRequest creerModComRequest = new CreateModificationCommercialeRequest(commande_p.getIdCmd(), listModComm);
      ConnectorResponse<Retour, Nothing> cmdRetour = CMDProxy.getInstance().modificationCommercialeCreerListe(tracabilite_p, creerModComRequest);
      retour = cmdRetour._first;

      if (isRetourOK(retour))
      {
        CreatePfiRequest createPFI = new CreatePfiRequest(pfi_p);
        ConnectorResponse<Retour, Nothing> rpgRetour = RPGProxy.getInstance().pfiEcrire(tracabilite_p, createPFI);
        retour = rpgRetour._first;
      }

    }
    else
    {
      retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, Messages.getString("PEP0147.BL200.PAinconnu")); //$NON-NLS-1$

    }
    return retour;
  }

  /**
   * PEP0147_BL300_ResilierMailSecondaire
   *
   * @param tracabilite_p
   *          tracabilite
   * @param pfi_p
   *          pfi
   * @param adresseMail_p
   *          adressemail
   * @param commande_p
   *          commande
   * @return
   * @throws RavelException
   *           exception
   */
  @LogProcessBL
  private Retour PEP0147_BL300_ResilierMailSecondaire(Tracabilite tracabilite_p, PFI pfi_p, String adresseMail_p, Commande commande_p) throws RavelException
  {
    CreateModificationCommercialeRequest createcommande = null;
    Retour retour = RetourFactory.createOkRetour();
    PA opacas = null;

    // on recherche  PA compte ACCES SECONDAIRE avec l'adresse mail
    for (PA pa : pfi_p.getPa())
    {
      if (TypePA.COMPTE_ACCES_SECONDAIRE.name().equals(pa.getTypePA()) && (pa.getPaTypeCompteAccesSecondaire() != null) && adresseMail_p.equals(pa.getPaTypeCompteAccesSecondaire().getLoginEmail()))
      {
        opacas = pa;
      }
    }

    if (opacas != null)
    {
      LocalDateTime dateModification = DateTimeManager.getInstance().now();

      opacas.setStatut(com.bytel.spirit.common.shared.saab.rpg.Statut.RESILIE);
      opacas.setDateModification(dateModification);

      pfi_p.setDateModification(dateModification);
      //Creation modification commerciale

      BL800_ObtenirSequence bl800 = new BL800_ObtenirSequence.BL800_ObtenirSequenceBuilder().tracabilite(tracabilite_p).code(UniqueIdConstant.ID_MOD_COM).build();
      String idComm = bl800.execute(this);
      ModificationCommerciale modComm = new ModificationCommerciale();
      modComm.setIdModificationCommerciale(idComm);
      modComm.setStatut(Statut.EN_COURS.name());
      modComm.setStatutCommercialAttendu(StatutCommercialAttendu.RESILIE.name());
      modComm.setIdCmd(commande_p.getIdCmd());
      modComm.setTypeObjetCommercial(TypeObjetCommercial.PA.name());
      modComm.setIdentifiantFonctionnelPA(opacas.getIdentifiantFonctionnelPA());
      modComm.setClientOperateur(commande_p.getClientOperateur());
      modComm.setNoCompte(commande_p.getNoCompte());

      List<ModificationCommerciale> listModification = new ArrayList<>();
      listModification.add(modComm);
      createcommande = new CreateModificationCommercialeRequest(commande_p.getIdCmd(), listModification);
      ConnectorResponse<Retour, Nothing> retourCMD = CMDProxy.getInstance().modificationCommercialeCreerListe(tracabilite_p, createcommande);
      retour = retourCMD._first;

      if (isRetourOK(retour))
      {
        CreatePfiRequest createpfi = new CreatePfiRequest(pfi_p);
        ConnectorResponse<Retour, Nothing> retourRPG = RPGProxy.getInstance().pfiEcrire(tracabilite_p, createpfi);
        retour = retourRPG._first;
      }

    }

    return retour;
  }

  /**
   * send a sync response for requester.
   *
   * @param request_p
   *          The request object
   * @param tracabilite_p
   *          Tracabilite
   * @param retourPep_p
   *          the retourPEP
   */
  private void syncResponse(Request request_p, Tracabilite tracabilite_p, PEP0147_Retour retourPep_p)
  {
    if (request_p != null)
    {
      IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
      Response rsp = null;

      if (retourPep_p != null)
      {
        ravelResponse.setDataType("application/json"); //$NON-NLS-1$
        ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(retourPep_p));
        Retour retour = RetourConverter.convertFromJsonRetour(retourPep_p.getRetour());
        if (isRetourOK(retour))
        {
          rsp = new Response(ErrorCode.OK_00200, ravelResponse);
        }
        else
        {
          rsp = new Response(ErrorCode.KO_00400, ravelResponse);
        }

      }
      else
      {
        rsp = new Response(ErrorCode.KO_00400, ravelResponse);
      }

      request_p.setResponse(rsp);
      //log response
      SpiritLogEvent logEvent = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, "PEP0147 response"); //$NON-NLS-1$
      logEvent.addField(IMegConsts.RESULTAT, ravelResponse.getResult(), false);
      RavelLogger.log(logEvent);

    }
  }
}
