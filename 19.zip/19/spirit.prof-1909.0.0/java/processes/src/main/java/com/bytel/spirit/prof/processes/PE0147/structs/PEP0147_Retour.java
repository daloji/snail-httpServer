/*******************************************************************************
* $Id: PEP0147_Retour.java 6688 2018-06-04 12:19:03Z fbarnabe $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PE0147.structs;

import com.bytel.ravel.types.Retour;
import com.bytel.spirit.common.shared.misc.ressources.BasicResponse;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Class used to return a Json response in PEP0147
 *
 * @author kbettenc
 * @version ($Revision: 6688 $ $Date: 2018-06-04 14:19:03 +0200 (lun. 04 juin 2018) $)
 */
public class PEP0147_Retour extends BasicResponse
{

  /**
   * ReponseFonctionnelle
   *
   * @author kbettenc
   * @version ($Revision: 6688 $ $Date: 2018-06-04 14:19:03 +0200 (lun. 04 juin 2018) $)
   */
  public static class ReponseFonctionnelle
  {
    /**
     * clientOperateur
     */
    @SerializedName("clientOperateur")
    @Expose
    private String _clientOperateur;
    /**
     * noCompte
     */
    @SerializedName("noCompte")
    @Expose
    private String _noCompte;

    /**
     * @return the clientOperateur
     */
    public String getClientOperateur()
    {
      return _clientOperateur;
    }

    /**
     * @return the noCompte
     */
    public String getNoCompte()
    {
      return _noCompte;
    }

    /**
     * @param clientOperateur_p
     *          the clientOperateur to set
     */
    public void setClientOperateur(String clientOperateur_p)
    {
      _clientOperateur = clientOperateur_p;
    }

    /**
     * @param noCompte_p
     *          the noCompte to set
     */
    public void setNoCompte(String noCompte_p)
    {
      _noCompte = noCompte_p;
    }

  }

  /**
   * serialVersionUID
   */
  private static final long serialVersionUID = -2618242132132952977L;

  /**
   * reponseFonctionnelle
   */
  @SerializedName("reponseFonctionnelle")
  @Expose
  private ReponseFonctionnelle _reponseFonctionnelle;

  /**
   * Constructor
   *
   * @param retour_p
   *          json Retour object
   */
  public PEP0147_Retour(Retour retour_p)
  {
    super(retour_p);
  }

  /**
   * @return the reponseFonctionnelle
   */
  public ReponseFonctionnelle getReponseFonctionnelle()
  {
    return _reponseFonctionnelle;
  }

  /**
   * @param reponseFonctionnelle_p
   *          the reponseFonctionnelle to set
   */
  public void setReponseFonctionnelle(ReponseFonctionnelle reponseFonctionnelle_p)
  {
    _reponseFonctionnelle = reponseFonctionnelle_p;
  }
}
