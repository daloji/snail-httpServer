/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PI0035.sti;

import java.time.LocalDateTime;

import com.bytel.spirit.common.activities.ossfai.structs.si025.ServiceTechniqueEquipementLegacy;
import com.bytel.spirit.prof.processes.PI0035.structs.TypeServiceTechniqueLegacy;
import com.squareup.moshi.Json;

/**
 *
 * @author pescudei
 * @version ($Revision$ $Date$)
 */
public class PI0035_StLegacyEquipementModem extends PI0035_ServiceTechniqueLegacy
{
  /**
   * Serial ID
   */
  private static final long serialVersionUID = -6234011283444023596L;

  /**
   * Builds a new instance of {@link PI0035_StLegacyEquipementModem} from an instance of
   * {@link ServiceTechniqueEquipementLegacy}
   *
   * @param stLegacy_p
   *          The instance of {@link ServiceTechniqueEquipementLegacy}.
   * @return The instance of {@link PI0035_StLegacyEquipementModem}.
   */
  public static PI0035_StLegacyEquipementModem buildFromStLegacyEquipementModem(ServiceTechniqueEquipementLegacy stLegacy_p)
  {
    return new PI0035_StLegacyEquipementModem(stLegacy_p.getNumeroSerie(), //
        stLegacy_p.getStatut(), //
        TypeServiceTechniqueLegacy.EQUIPEMENT_MODEM.name(), //
        stLegacy_p.getDateCreation(), stLegacy_p.getDateModification(), //
        stLegacy_p.getModem() != null ? stLegacy_p.getModem().getNoCompteCourt() : null, //
        (stLegacy_p.getModem() != null) && (stLegacy_p.getModem().getConfigurationIms() != null) ? new PI0035_DonneesImsIad(stLegacy_p.getModem().getConfigurationIms()) : null);
  }

  /**
   * numeroSerie
   */
  @Json(name = "numeroSerie")
  private String _numeroSerie;

  /**
   * noCompteCourt
   */
  @Json(name = "noCompteCourt")
  private String _noCompteCourt;

  /**
   * configurationIms
   */
  @Json(name = "configurationIms")
  private PI0035_DonneesImsIad _configurationIms;

  /**
   * @param numeroSerie_p
   * @param statut_p
   * @param typeServiceTechnique_p
   * @param dateCreation_p
   * @param dateModification_p
   * @param numeroSerie_p
   * @param noCompteCourt_p
   * @param configurationIms_p
   */
  public PI0035_StLegacyEquipementModem(String numeroSerie_p, String statut_p, String typeServiceTechnique_p, LocalDateTime dateCreation_p, LocalDateTime dateModification_p, String noCompteCourt_p, PI0035_DonneesImsIad configurationIms_p)
  {
    super(statut_p, typeServiceTechnique_p, dateCreation_p, dateModification_p);

    _numeroSerie = numeroSerie_p;
    _noCompteCourt = noCompteCourt_p;
    _configurationIms = configurationIms_p;

  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (!super.equals(obj))
    {
      return false;
    }
    if (getClass() != obj.getClass()) // NOSONAR
    {
      return false;
    }
    PI0035_StLegacyEquipementModem other = (PI0035_StLegacyEquipementModem) obj;
    if (_configurationIms == null)
    {
      if (other._configurationIms != null)
      {
        return false;
      }
    }
    else if (!_configurationIms.equals(other._configurationIms))
    {
      return false;
    }
    if (_noCompteCourt == null)
    {
      if (other._noCompteCourt != null)
      {
        return false;
      }
    }
    else if (!_noCompteCourt.equals(other._noCompteCourt))
    {
      return false;
    }
    if (_numeroSerie == null)
    {
      if (other._numeroSerie != null)
      {
        return false;
      }
    }
    else if (!_numeroSerie.equals(other._numeroSerie))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the configurationIms
   */
  public PI0035_DonneesImsIad getConfigurationIms()
  {
    return _configurationIms;
  }

  /**
   * @return the noCompteCourt
   */
  public String getNoCompteCourt()
  {
    return _noCompteCourt;
  }

  /**
   * @return the numeroSerie
   */
  public final String getNumeroSerie()
  {
    return _numeroSerie;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = super.hashCode();
    result = (prime * result) + ((_configurationIms == null) ? 0 : _configurationIms.hashCode());
    result = (prime * result) + ((_noCompteCourt == null) ? 0 : _noCompteCourt.hashCode());
    result = (prime * result) + ((_numeroSerie == null) ? 0 : _numeroSerie.hashCode());
    return result;
  }

  /**
   * @param configurationIms_p
   *          the configurationIms to set
   */
  public void setConfigurationIms(PI0035_DonneesImsIad configurationIms_p)
  {
    _configurationIms = configurationIms_p;
  }

  /**
   * @param noCompteCourt_p
   *          the noCompteCourt to set
   */
  public void setNoCompteCourt(String noCompteCourt_p)
  {
    _noCompteCourt = noCompteCourt_p;
  }

  /**
   * @param numeroSerie_p
   *          the numeroSerie to set
   */
  public void setNumeroSerie(final String numeroSerie_p)
  {
    _numeroSerie = numeroSerie_p;
  }

  @Override
  public String toString()
  {
    StringBuilder builder = new StringBuilder();
    builder.append("PI0035_StLegacyEquipementModem [_numeroSerie="); //$NON-NLS-1$
    builder.append(_numeroSerie);
    builder.append(", _noCompteCourt="); //$NON-NLS-1$
    builder.append(_noCompteCourt);
    builder.append(", _configurationIms="); //$NON-NLS-1$
    builder.append(_configurationIms);
    builder.append(", getCommentaire()="); //$NON-NLS-1$
    builder.append(getCommentaire());
    builder.append(", getDateCreation()="); //$NON-NLS-1$
    builder.append(getDateCreation());
    builder.append(", getDateModification()="); //$NON-NLS-1$
    builder.append(getDateModification());
    builder.append(", getStatut()="); //$NON-NLS-1$
    builder.append(getStatut());
    builder.append(", getTypeServiceTechnique()="); //$NON-NLS-1$
    builder.append(getTypeServiceTechnique());
    builder.append("]"); //$NON-NLS-1$
    return builder.toString();
  }
}
