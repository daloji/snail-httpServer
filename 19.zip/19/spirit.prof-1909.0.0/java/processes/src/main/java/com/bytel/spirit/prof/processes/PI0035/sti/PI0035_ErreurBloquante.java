/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PI0035.sti;

import java.io.Serializable;

import com.squareup.moshi.Json;

/**
 *
 * @author jgregori
 * @version ($Revision$ $Date$)
 */
public class PI0035_ErreurBloquante implements Serializable
{
  /**
   *
   */
  private static final long serialVersionUID = 8358999767020045800L;

  /**
   * Type
   */
  @Json(name = "type")
  private String _type;

  /**
   * Libelle
   */
  @Json(name = "libelle")
  private String _libelle;

  /**
   *
   * @param type_p
   *          type
   * @param libelle_p
   *          libelle
   */
  public PI0035_ErreurBloquante(String type_p, String libelle_p)
  {
    super();
    _type = type_p;
    _libelle = libelle_p;
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    PI0035_ErreurBloquante other = (PI0035_ErreurBloquante) obj;
    if (_libelle == null)
    {
      if (other._libelle != null)
      {
        return false;
      }
    }
    else if (!_libelle.equals(other._libelle))
    {
      return false;
    }
    if (_type == null)
    {
      if (other._type != null)
      {
        return false;
      }
    }
    else if (!_type.equals(other._type))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the libelle
   */
  public String getLibelle()
  {
    return _libelle;
  }

  /**
   * @return the type
   */
  public String getType()
  {
    return _type;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_libelle == null) ? 0 : _libelle.hashCode());
    result = (prime * result) + ((_type == null) ? 0 : _type.hashCode());
    return result;
  }

  /**
   * @param libelle_p
   *          the libelle to set
   */
  public void setLibelle(String libelle_p)
  {
    _libelle = libelle_p;
  }

  /**
   * @param type_p
   *          the type to set
   */
  public void setType(String type_p)
  {
    _type = type_p;
  }

  @Override
  public String toString()
  {
    StringBuilder builder = new StringBuilder();
    builder.append("PI0035_ErreurBloquante [_type="); //$NON-NLS-1$
    builder.append(_type);
    builder.append(", _libelle="); //$NON-NLS-1$
    builder.append(_libelle);
    builder.append("]"); //$NON-NLS-1$
    return builder.toString();
  }
}
