/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PI0035.sti;

import java.io.Serializable;

import com.bytel.spirit.common.shared.functional.types.json.st.pfs.vmsstw.DonneesIdentificationSTPfsVmsStw;
import com.squareup.moshi.Json;

/**
 *
 * @author pescudei
 * @version ($Revision$ $Date$)
 */
public class PI0035_DonneesIdentificationStPfsVmsStw implements Serializable
{
  /**
   *
   */
  private static final long serialVersionUID = 1808714574642310793L;
  /**
   * Ressource identifiantFonctionnelPA
   */
  @Json(name = "identifiantFonctionnelPA")
  private String _identifiantFonctionnelPA;

  /**
   * @param identifiantFonctionnelPa_p
   */
  public PI0035_DonneesIdentificationStPfsVmsStw(String identifiantFonctionnelPa_p)
  {
    super();

    _identifiantFonctionnelPA = identifiantFonctionnelPa_p;
  }

  /**
   * Build PI0035_DonnesIdentificationSTPfsMail from {@code DonnesIdentificationSTPfsMail}
   *
   * @param donneesIdentification_p
   *          DonnesIdentificationSTPfsMail instance
   * @return PI0035_DonnesIdentificationSTPfsMail instance
   */
  public PI0035_DonneesIdentificationStPfsVmsStw buildFromDonneesIdentificationStPfsVmsStw(DonneesIdentificationSTPfsVmsStw donneesIdentification_p)
  {
    return new PI0035_DonneesIdentificationStPfsVmsStw(donneesIdentification_p.getIdentifiantFonctionnelPa());
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    PI0035_DonneesIdentificationStPfsVmsStw other = (PI0035_DonneesIdentificationStPfsVmsStw) obj;
    if (_identifiantFonctionnelPA == null)
    {
      if (other._identifiantFonctionnelPA != null)
      {
        return false;
      }
    }
    else if (!_identifiantFonctionnelPA.equals(other._identifiantFonctionnelPA))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the identifiantFonctionnelPA
   */
  public String getIdentifiantFonctionnelPA()
  {
    return _identifiantFonctionnelPA;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_identifiantFonctionnelPA == null) ? 0 : _identifiantFonctionnelPA.hashCode());
    return result;
  }

  /**
   * @param identifiantFonctionnelPa_p
   *          the identifiantFonctionnelPa to set
   */
  public void setIdentifiantFonctionnelPA(String identifiantFonctionnelPa_p)
  {
    _identifiantFonctionnelPA = identifiantFonctionnelPa_p;
  }

  @Override
  public String toString()
  {
    StringBuilder builder = new StringBuilder();
    builder.append("PI0035_DonneesIdentificationStPfsVmsStw [_identifiantFonctionnelPA="); //$NON-NLS-1$
    builder.append(_identifiantFonctionnelPA);
    builder.append("]"); //$NON-NLS-1$
    return builder.toString();
  }
}
