/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PI0035.sti;

import java.time.LocalDateTime;

import com.bytel.spirit.common.shared.functional.types.json.st.pfs.TypePFS;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.fqdn.StPfsFqdn;
import com.squareup.moshi.Json;

/**
 *
 * @author pescudei
 * @version ($Revision$ $Date$)
 */
public class PI0035_StPfsFqdn extends PI0035_AbstractStPfs
{
  /**
   * Serial ID
   */
  private static final long serialVersionUID = -8515972989592276122L;

  /**
   * Builds a new instance of {@link PI0035_StPfsFqdn} from an instance of {@link StPfsFqdn}
   *
   * @param stPfsFqdn_p
   *          The instance of {@link StPfsFqdn}.
   * @return The instance of {@link PI0035_StPfsFqdn}.
   */
  public static PI0035_StPfsFqdn buildFromStPfsFqdn(StPfsFqdn stPfsFqdn_p)
  {
    PI0035_DonneesIdentificationStPfsFqdn donneesIdent = new PI0035_DonneesIdentificationStPfsFqdn(stPfsFqdn_p.getDonneesIdentificationSTPfsFqdn().getNomFQDN());
    PI0035_DonneesProvisionneesStPfsFqdn donneesProv = null;
    if (stPfsFqdn_p.getDonneesProvisionneesSTPfsFqdn() != null)
    {
      donneesProv = new PI0035_DonneesProvisionneesStPfsFqdn(stPfsFqdn_p.getDonneesProvisionneesSTPfsFqdn().getNombreSession());
    }
    return new PI0035_StPfsFqdn(stPfsFqdn_p.getIdSt(), stPfsFqdn_p.getStatut(), stPfsFqdn_p.getDateCreation(), stPfsFqdn_p.getDateModification(), donneesIdent, donneesProv);

  }

  /**
   * Donnes Identification
   */
  @Json(name = "donneesIdentification")
  private PI0035_DonneesIdentificationStPfsFqdn _donneesIdentification;

  /**
   * Donnes Provisionnees
   */
  @Json(name = "donneesProvisionnees")
  private PI0035_DonneesProvisionneesStPfsFqdn _donneesProvisionnees;

  /**
   * @param idSt_p
   * @param statut_p
   * @param dateCreation_p
   * @param dateModification_p
   * @param donneesIdentification_p
   * @param donneesProvisionnees_p
   */
  public PI0035_StPfsFqdn(String idSt_p, String statut_p, LocalDateTime dateCreation_p, LocalDateTime dateModification_p, PI0035_DonneesIdentificationStPfsFqdn donneesIdentification_p, PI0035_DonneesProvisionneesStPfsFqdn donneesProvisionnees_p)
  {
    super(idSt_p, statut_p, TypePFS.FQDN.name(), dateCreation_p, dateModification_p);

    _donneesIdentification = donneesIdentification_p;
    _donneesProvisionnees = donneesProvisionnees_p;
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (!super.equals(obj))
    {
      return false;
    }
    if (getClass() != obj.getClass()) // NOSONAR
    {
      return false;
    }
    PI0035_StPfsFqdn other = (PI0035_StPfsFqdn) obj;
    if (_donneesIdentification == null)
    {
      if (other._donneesIdentification != null)
      {
        return false;
      }
    }
    else if (!_donneesIdentification.equals(other._donneesIdentification))
    {
      return false;
    }
    if (_donneesProvisionnees == null)
    {
      if (other._donneesProvisionnees != null)
      {
        return false;
      }
    }
    else if (!_donneesProvisionnees.equals(other._donneesProvisionnees))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the donneesIdentification
   */
  public PI0035_DonneesIdentificationStPfsFqdn getDonneesIdentification()
  {
    return _donneesIdentification;
  }

  /**
   * @return the donneesProvisionnees
   */
  public PI0035_DonneesProvisionneesStPfsFqdn getDonneesProvisionnees()
  {
    return _donneesProvisionnees;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = super.hashCode();
    result = (prime * result) + ((_donneesIdentification == null) ? 0 : _donneesIdentification.hashCode());
    result = (prime * result) + ((_donneesProvisionnees == null) ? 0 : _donneesProvisionnees.hashCode());
    return result;
  }

  /**
   * @param donneesIdentification_p
   *          the donneesIdentification to set
   */
  public void setDonneesIdentification(PI0035_DonneesIdentificationStPfsFqdn donneesIdentification_p)
  {
    _donneesIdentification = donneesIdentification_p;
  }

  /**
   * @param donneesProvisionnees_p
   *          the donneesProvisionnees to set
   */
  public void setDonneesProvisionnees(PI0035_DonneesProvisionneesStPfsFqdn donneesProvisionnees_p)
  {
    _donneesProvisionnees = donneesProvisionnees_p;
  }

  @Override
  public String toString()
  {
    StringBuilder builder = new StringBuilder();
    builder.append("PI0035_StPfsFqdn [_donneesIdentification="); //$NON-NLS-1$
    builder.append(_donneesIdentification);
    builder.append(", _donneesProvisionnees="); //$NON-NLS-1$
    builder.append(_donneesProvisionnees);
    builder.append(", getCommentaire()="); //$NON-NLS-1$
    builder.append(getCommentaire());
    builder.append(", getDateCreation()="); //$NON-NLS-1$
    builder.append(getDateCreation());
    builder.append(", getDateModification()="); //$NON-NLS-1$
    builder.append(getDateModification());
    builder.append(", getIdSt()="); //$NON-NLS-1$
    builder.append(getIdSt());
    builder.append(", getStatut()="); //$NON-NLS-1$
    builder.append(getStatut());
    builder.append(", getTypeServiceTechnique()="); //$NON-NLS-1$
    builder.append(getTypeServiceTechnique());
    builder.append("]"); //$NON-NLS-1$
    return builder.toString();
  }
}
