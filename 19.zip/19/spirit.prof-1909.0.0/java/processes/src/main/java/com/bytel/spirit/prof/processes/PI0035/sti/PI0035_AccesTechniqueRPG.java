/*******************************************************************************
* $Id: AccesTechnique.java 14018 2018-12-03 16:34:20Z lchanyip $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PI0035.sti;

import java.io.Serializable;

import com.bytel.spirit.common.shared.saab.rpg.AccesTechnique;
import com.squareup.moshi.Json;

/**
 * AccesTechnique json class
 *
 * @author lchanyip
 * @version ($Revision: 14018 $ $Date: 2018-12-03 17:34:20 +0100 (lun., 03 déc. 2018) $)
 */
public class PI0035_AccesTechniqueRPG implements Serializable
{

  /**
   * serialVersionUID
   */
  private static final long serialVersionUID = -8810113776327297509L;

  /**
   * Creates a new instance of [{@link PI0035_AccesTechniqueRPG} from an instance of {@link AccesTechnique}.
   *
   * @param AccesTechnique_p
   *          The AccesTechnique instance.
   * @return The PI0035_AccesTechniqueRPG instance.
   */
  public static PI0035_AccesTechniqueRPG buildFromAccesTechnique(AccesTechnique accesTechnique_p)
  {
    PI0035_AccesTechniqueRPG accesTechnique = new PI0035_AccesTechniqueRPG(accesTechnique_p.getTechnologieAcces(), accesTechnique_p.getIdProfilTechnique());

    accesTechnique.setIdOperateurCollecte(accesTechnique_p.getIdOperateurCollecte());
    accesTechnique.setCodeOperateurImmeuble(accesTechnique_p.getCodeOperateurImmeuble());
    accesTechnique.setTypeDegroupage(accesTechnique_p.getTypeDegroupage());

    return accesTechnique;
  }

  /**
   * technologieAcces
   */
  @Json(name = "technologieAcces")
  private String _technologieAcces;

  /**
   * idProfilTechnique
   */
  @Json(name = "idProfilTechnique")
  private String _idProfilTechnique;

  /**
   * idOperateurCollecte
   */
  @Json(name = "idOperateurCollecte")
  private String _idOperateurCollecte;

  /**
   * codeOperateurImmeuble
   */
  @Json(name = "codeOperateurImmeuble")
  private String _codeOperateurImmeuble;

  /**
   * typeDegroupage
   */
  @Json(name = "typeDegroupage")
  private String _typeDegroupage;

  /**
   * Default constructor
   *
   * @param technologieAcces_p
   *          technologieAcces
   * @param idProfilTechnique_p
   *          idProfilTechnique
   */
  public PI0035_AccesTechniqueRPG(String technologieAcces_p, String idProfilTechnique_p)
  {
    _technologieAcces = technologieAcces_p;
    _idProfilTechnique = idProfilTechnique_p;
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    PI0035_AccesTechniqueRPG other = (PI0035_AccesTechniqueRPG) obj;
    if (_codeOperateurImmeuble == null)
    {
      if (other._codeOperateurImmeuble != null)
      {
        return false;
      }
    }
    else if (!_codeOperateurImmeuble.equals(other._codeOperateurImmeuble))
    {
      return false;
    }
    if (_idOperateurCollecte == null)
    {
      if (other._idOperateurCollecte != null)
      {
        return false;
      }
    }
    else if (!_idOperateurCollecte.equals(other._idOperateurCollecte))
    {
      return false;
    }
    if (_idProfilTechnique == null)
    {
      if (other._idProfilTechnique != null)
      {
        return false;
      }
    }
    else if (!_idProfilTechnique.equals(other._idProfilTechnique))
    {
      return false;
    }
    if (_technologieAcces == null)
    {
      if (other._technologieAcces != null)
      {
        return false;
      }
    }
    else if (!_technologieAcces.equals(other._technologieAcces))
    {
      return false;
    }
    if (_typeDegroupage == null)
    {
      if (other._typeDegroupage != null)
      {
        return false;
      }
    }
    else if (!_typeDegroupage.equals(other._typeDegroupage))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the codeOperateurImmeuble
   */
  public String getCodeOperateurImmeuble()
  {
    return _codeOperateurImmeuble;
  }

  /**
   * @return the idOperateurCollecte
   */
  public String getIdOperateurCollecte()
  {
    return _idOperateurCollecte;
  }

  /**
   * @return the idProfilTechnique
   */
  public String getIdProfilTechnique()
  {
    return _idProfilTechnique;
  }

  /**
   * @return the technologieAcces
   */
  public String getTechnologieAcces()
  {
    return _technologieAcces;
  }

  /**
   * @return the typeDegroupage
   */
  public String getTypeDegroupage()
  {
    return _typeDegroupage;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_codeOperateurImmeuble == null) ? 0 : _codeOperateurImmeuble.hashCode());
    result = (prime * result) + ((_idOperateurCollecte == null) ? 0 : _idOperateurCollecte.hashCode());
    result = (prime * result) + ((_idProfilTechnique == null) ? 0 : _idProfilTechnique.hashCode());
    result = (prime * result) + ((_technologieAcces == null) ? 0 : _technologieAcces.hashCode());
    result = (prime * result) + ((_typeDegroupage == null) ? 0 : _typeDegroupage.hashCode());
    return result;
  }

  /**
   * @param codeOperateurImmeuble_p
   *          the codeOperateurImmeuble to set
   */
  public void setCodeOperateurImmeuble(String codeOperateurImmeuble_p)
  {
    _codeOperateurImmeuble = codeOperateurImmeuble_p;
  }

  /**
   * @param idOperateurCollecte_p
   *          the idOperateurCollecte to set
   */
  public void setIdOperateurCollecte(String idOperateurCollecte_p)
  {
    _idOperateurCollecte = idOperateurCollecte_p;
  }

  /**
   * @param typeDegroupage_p
   *          the typeDegroupage to set
   */
  public void setTypeDegroupage(String typeDegroupage_p)
  {
    _typeDegroupage = typeDegroupage_p;
  }

  @Override
  public String toString()
  {
    return "AccesTechnique [_technologieAcces=" + _technologieAcces + ", _idProfilTechnique=" + _idProfilTechnique + ", _idOperateurCollecte=" + _idOperateurCollecte + ", _codeOperateurImmeuble=" + _codeOperateurImmeuble + ", _typeDegroupage=" + _typeDegroupage + "]"; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
  }

}
