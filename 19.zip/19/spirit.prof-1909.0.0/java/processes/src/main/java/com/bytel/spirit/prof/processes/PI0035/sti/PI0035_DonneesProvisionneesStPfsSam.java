/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PI0035.sti;

import java.io.Serializable;

import com.squareup.moshi.Json;

/**
 *
 * @author pescudei
 * @version ($Revision$ $Date$)
 */
public class PI0035_DonneesProvisionneesStPfsSam implements Serializable
{
  /**
   *
   */
  private static final long serialVersionUID = 3090828515462738906L;

  /**
   * Resource idCompteIms
   */
  @Json(name = "idCompteIms")
  private String _idCompteIms;

  /**
   * Resource noTelephone
   */
  @Json(name = "noTelephone")
  private String _noTelephone;

  /**
   * Type Usage
   */
  @Json(name = "typeUsage")
  private String _typeUsage;

  /**
   * Resource impiFixe
   */
  @Json(name = "impiFixe")
  private String _impiFixe;

  /**
   * Resource motDePasseIms
   */
  @Json(name = "motDePasseIms")
  private String _motDePasseIms;

  /**
   * Resource sipUri
   */
  @Json(name = "sipUri")
  private String _sipUri;

  /**
   * Resource telUri
   */
  @Json(name = "telUri")
  private String _telUri;

  /**
   * Nom
   */
  @Json(name = "nom")
  private String _nom;

  /**
   * Nom
   */
  @Json(name = "prenom")
  private String _prenom;

  /**
   * nomPrenomCourt
   */
  @Json(name = "nomPrenomCourt")
  private String _nomPrenomCourt;

  /**
   * niveauRestriction
   */
  @Json(name = "niveauRestriction")
  private String _niveauRestriction;

  /**
   * notificationSuspension
   */
  @Json(name = "notificationSuspension")
  private String _notificationSuspension;

  /**
   * optionAppelSurTaxes
   */
  @Json(name = "optionAppelSurTaxes")
  private String _optionAppelSurTaxes;

  /**
   * @param idCompteIms_p
   * @param noTelephone_p
   * @param typeUsage_p
   * @param impiFixe_p
   * @param motDePasseIms_p
   * @param sipUri_p
   * @param telUri_p
   * @param nom_p
   * @param prenom_p
   * @param nomPrenomCourt_p
   * @param niveauRestriction_p
   * @param optionAppelSurTaxes_p
   */
  public PI0035_DonneesProvisionneesStPfsSam(String idCompteIms_p, String noTelephone_p, String typeUsage_p, String impiFixe_p, String motDePasseIms_p, String sipUri_p, String telUri_p, String nom_p, String prenom_p, String nomPrenomCourt_p, String niveauRestriction_p, String notificationSupension_p, String optionAppelSurTaxes_p)
  {
    super();

    _idCompteIms = idCompteIms_p;
    _noTelephone = noTelephone_p;
    _typeUsage = typeUsage_p;
    _impiFixe = impiFixe_p;
    _motDePasseIms = motDePasseIms_p;
    _sipUri = sipUri_p;
    _telUri = telUri_p;
    _nom = nom_p;
    _prenom = prenom_p;
    _nomPrenomCourt = nomPrenomCourt_p;
    _niveauRestriction = niveauRestriction_p;
    _notificationSuspension = notificationSupension_p;
    _optionAppelSurTaxes = optionAppelSurTaxes_p;
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    PI0035_DonneesProvisionneesStPfsSam other = (PI0035_DonneesProvisionneesStPfsSam) obj;
    if (_idCompteIms == null)
    {
      if (other._idCompteIms != null)
      {
        return false;
      }
    }
    else if (!_idCompteIms.equals(other._idCompteIms))
    {
      return false;
    }
    if (_impiFixe == null)
    {
      if (other._impiFixe != null)
      {
        return false;
      }
    }
    else if (!_impiFixe.equals(other._impiFixe))
    {
      return false;
    }
    if (_motDePasseIms == null)
    {
      if (other._motDePasseIms != null)
      {
        return false;
      }
    }
    else if (!_motDePasseIms.equals(other._motDePasseIms))
    {
      return false;
    }
    if (_niveauRestriction == null)
    {
      if (other._niveauRestriction != null)
      {
        return false;
      }
    }
    else if (!_niveauRestriction.equals(other._niveauRestriction))
    {
      return false;
    }
    if (_noTelephone == null)
    {
      if (other._noTelephone != null)
      {
        return false;
      }
    }
    else if (!_noTelephone.equals(other._noTelephone))
    {
      return false;
    }
    if (_nom == null)
    {
      if (other._nom != null)
      {
        return false;
      }
    }
    else if (!_nom.equals(other._nom))
    {
      return false;
    }
    if (_nomPrenomCourt == null)
    {
      if (other._nomPrenomCourt != null)
      {
        return false;
      }
    }
    else if (!_nomPrenomCourt.equals(other._nomPrenomCourt))
    {
      return false;
    }
    if (_notificationSuspension == null)
    {
      if (other._notificationSuspension != null)
      {
        return false;
      }
    }
    else if (!_notificationSuspension.equals(other._notificationSuspension))
    {
      return false;
    }
    if (_optionAppelSurTaxes == null)
    {
      if (other._optionAppelSurTaxes != null)
      {
        return false;
      }
    }
    else if (!_optionAppelSurTaxes.equals(other._optionAppelSurTaxes))
    {
      return false;
    }
    if (_prenom == null)
    {
      if (other._prenom != null)
      {
        return false;
      }
    }
    else if (!_prenom.equals(other._prenom))
    {
      return false;
    }
    if (_sipUri == null)
    {
      if (other._sipUri != null)
      {
        return false;
      }
    }
    else if (!_sipUri.equals(other._sipUri))
    {
      return false;
    }
    if (_telUri == null)
    {
      if (other._telUri != null)
      {
        return false;
      }
    }
    else if (!_telUri.equals(other._telUri))
    {
      return false;
    }
    if (_typeUsage == null)
    {
      if (other._typeUsage != null)
      {
        return false;
      }
    }
    else if (!_typeUsage.equals(other._typeUsage))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the idCompteIms
   */
  public String getIdCompteIms()
  {
    return _idCompteIms;
  }

  /**
   * @return the impiFixe
   */
  public String getImpiFixe()
  {
    return _impiFixe;
  }

  /**
   * @return the motDePasseIms
   */
  public String getMotDePasseIms()
  {
    return _motDePasseIms;
  }

  /**
   * @return the niveauRestriction
   */
  public String getNiveauRestriction()
  {
    return _niveauRestriction;
  }

  /**
   * @return value of _nom
   */
  public String getNom()
  {
    return _nom;
  }

  /**
   * @return value of _nomPrenomCourt
   */
  public String getNomPrenomCourt()
  {
    return _nomPrenomCourt;
  }

  /**
   * @return the noTelephone
   */
  public String getNoTelephone()
  {
    return _noTelephone;
  }

  /**
   * @return the notificationSupension
   */
  public String getNotificationSupension()
  {
    return _notificationSuspension;
  }

  /**
   * @return value of _optionAppelSurTaxes
   */
  public String getOptionAppelSurTaxes()
  {
    return _optionAppelSurTaxes;
  }

  /**
   * @return value of _prenom
   */
  public String getPrenom()
  {
    return _prenom;
  }

  /**
   * @return the sipUri
   */
  public String getSipUri()
  {
    return _sipUri;
  }

  /**
   * @return the telUri
   */
  public String getTelUri()
  {
    return _telUri;
  }

  /**
   * @return the typeService
   */
  public String getTypeUsage()
  {
    return _typeUsage;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_idCompteIms == null) ? 0 : _idCompteIms.hashCode());
    result = (prime * result) + ((_impiFixe == null) ? 0 : _impiFixe.hashCode());
    result = (prime * result) + ((_motDePasseIms == null) ? 0 : _motDePasseIms.hashCode());
    result = (prime * result) + ((_niveauRestriction == null) ? 0 : _niveauRestriction.hashCode());
    result = (prime * result) + ((_noTelephone == null) ? 0 : _noTelephone.hashCode());
    result = (prime * result) + ((_nom == null) ? 0 : _nom.hashCode());
    result = (prime * result) + ((_nomPrenomCourt == null) ? 0 : _nomPrenomCourt.hashCode());
    result = (prime * result) + ((_notificationSuspension == null) ? 0 : _notificationSuspension.hashCode());
    result = (prime * result) + ((_optionAppelSurTaxes == null) ? 0 : _optionAppelSurTaxes.hashCode());
    result = (prime * result) + ((_prenom == null) ? 0 : _prenom.hashCode());
    result = (prime * result) + ((_sipUri == null) ? 0 : _sipUri.hashCode());
    result = (prime * result) + ((_telUri == null) ? 0 : _telUri.hashCode());
    result = (prime * result) + ((_typeUsage == null) ? 0 : _typeUsage.hashCode());
    return result;
  }

  /**
   * @param idCompteIms_p
   *          the idCompteIms to set
   */
  public void setIdCompteIms(String idCompteIms_p)
  {
    _idCompteIms = idCompteIms_p;
  }

  /**
   * @param impiFixe_p
   *          the impiFixe to set
   */
  public void setImpiFixe(String impiFixe_p)
  {
    _impiFixe = impiFixe_p;
  }

  /**
   * @param motDePasseIms_p
   *          the motDePasseIms to set
   */
  public void setMotDePasseIms(String motDePasseIms_p)
  {
    _motDePasseIms = motDePasseIms_p;
  }

  /**
   * @param niveauRestriction_p
   *          the niveauRestriction to set
   */
  public void setNiveauRestriction(String niveauRestriction_p)
  {
    _niveauRestriction = niveauRestriction_p;
  }

  /**
   * @param nom_p
   *          The _nom to set.
   */
  public void setNom(String nom_p)
  {
    _nom = nom_p;
  }

  /**
   * @param nomPrenomCourt_p
   *          The _nomPrenomCourt to set.
   */
  public void setNomPrenomCourt(String nomPrenomCourt_p)
  {
    _nomPrenomCourt = nomPrenomCourt_p;
  }

  /**
   * @param noTelephone_p
   *          the noTelephone to set
   */
  public void setNoTelephone(String noTelephone_p)
  {
    _noTelephone = noTelephone_p;
  }

  /**
   * @param notificationSupension_p
   *          the notificationSupension to set
   */
  public void setNotificationSupension(String notificationSupension_p)
  {
    _notificationSuspension = notificationSupension_p;
  }

  /**
   * @param optionAppelSurTaxes_p
   *          The _optionAppelSurTaxes to set.
   */
  public void setOptionAppelSurTaxes(String optionAppelSurTaxes_p)
  {
    _optionAppelSurTaxes = optionAppelSurTaxes_p;
  }

  /**
   * @param prenom_p
   *          The _prenom to set.
   */
  public void setPrenom(String prenom_p)
  {
    _prenom = prenom_p;
  }

  /**
   * @param sipUri_p
   *          the sipUri to set
   */
  public void setSipUri(String sipUri_p)
  {
    _sipUri = sipUri_p;
  }

  /**
   * @param telUri_p
   *          the telUri to set
   */
  public void setTelUri(String telUri_p)
  {
    _telUri = telUri_p;
  }

  /**
   * @param typeUsage_p
   *          the typeService to set
   */
  public void setTypeUsage(String typeUsage_p)
  {
    _typeUsage = typeUsage_p;
  }

  @Override
  public String toString()
  {
    StringBuilder builder = new StringBuilder();
    builder.append("PI0035_DonneesProvisionneesStPfsSam [_idCompteIms="); //$NON-NLS-1$
    builder.append(_idCompteIms);
    builder.append(", _noTelephone="); //$NON-NLS-1$
    builder.append(_noTelephone);
    builder.append(", _typeUsage="); //$NON-NLS-1$
    builder.append(_typeUsage);
    builder.append(", _impiFixe="); //$NON-NLS-1$
    builder.append(_impiFixe);
    builder.append(", _motDePasseIms="); //$NON-NLS-1$
    builder.append(_motDePasseIms);
    builder.append(", _sipUri="); //$NON-NLS-1$
    builder.append(_sipUri);
    builder.append(", _telUri="); //$NON-NLS-1$
    builder.append(_telUri);
    builder.append(", _nom="); //$NON-NLS-1$
    builder.append(_nom);
    builder.append(", _prenom="); //$NON-NLS-1$
    builder.append(_prenom);
    builder.append(", _nomPrenomCourt="); //$NON-NLS-1$
    builder.append(_nomPrenomCourt);
    builder.append(", _niveauRestriction="); //$NON-NLS-1$
    builder.append(_niveauRestriction);
    builder.append(", _notificationSupension="); //$NON-NLS-1$
    builder.append(_notificationSuspension);
    builder.append(", _optionAppelSurTaxes="); //$NON-NLS-1$
    builder.append(_optionAppelSurTaxes);
    builder.append("]"); //$NON-NLS-1$
    return builder.toString();
  }
}
