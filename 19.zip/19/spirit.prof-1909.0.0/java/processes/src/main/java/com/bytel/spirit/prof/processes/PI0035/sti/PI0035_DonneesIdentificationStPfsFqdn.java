/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PI0035.sti;

import java.io.Serializable;

import com.bytel.spirit.common.shared.functional.types.json.st.pfs.fqdn.DonneesIdentificationSTPfsFqdn;
import com.squareup.moshi.Json;

/**
 *
 * @author pescudei
 * @version ($Revision$ $Date$)
 */
public class PI0035_DonneesIdentificationStPfsFqdn implements Serializable
{
  /**
   * Serial ID
   */
  private static final long serialVersionUID = -8368854827812911051L;

  /**
   * nomFQDN
   */
  @Json(name = "nomFQDN")
  private String _nomFQDN;

  /**
   * @param nomFQDN_p
   */
  public PI0035_DonneesIdentificationStPfsFqdn(String nomFQDN_p)
  {
    super();

    _nomFQDN = nomFQDN_p;
  }

  /**
   * Build PI0035_DonneesIdentificationStPfsFqdn from {@code DonneesIdentificationSTPfsFqdn}
   *
   * @param donneesIdentification_p
   *          DonneesIdentificationSTPfsFqdn instance
   * @return PI0035_DonneesIdentificationStPfsFqdn instance
   */
  public PI0035_DonneesIdentificationStPfsFqdn buildFromDonneesIdentificationStPfsFqdn(DonneesIdentificationSTPfsFqdn donneesIdentification_p)
  {
    return new PI0035_DonneesIdentificationStPfsFqdn(donneesIdentification_p.getNomFQDN());
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    PI0035_DonneesIdentificationStPfsFqdn other = (PI0035_DonneesIdentificationStPfsFqdn) obj;
    if (_nomFQDN == null)
    {
      if (other._nomFQDN != null)
      {
        return false;
      }
    }
    else if (!_nomFQDN.equals(other._nomFQDN))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the nomFQDN
   */
  public String getNomFQDN()
  {
    return _nomFQDN;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_nomFQDN == null) ? 0 : _nomFQDN.hashCode());
    return result;
  }

  /**
   * @param nomFQDN_p
   *          the nomFQDN to set
   */
  public void setNomFQDN(String nomFQDN_p)
  {
    _nomFQDN = nomFQDN_p;
  }

  @Override
  public String toString()
  {
    StringBuilder builder = new StringBuilder();
    builder.append("PI0035_DonneesIdentificationStPfsFqdn [_nomFQDN="); //$NON-NLS-1$
    builder.append(_nomFQDN);
    builder.append("]"); //$NON-NLS-1$
    return builder.toString();
  }
}
