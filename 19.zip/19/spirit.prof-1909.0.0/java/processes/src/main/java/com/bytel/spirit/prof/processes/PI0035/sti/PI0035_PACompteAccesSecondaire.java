/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PI0035.sti;

import java.time.LocalDateTime;

import com.bytel.spirit.common.shared.saab.rpg.PA;
import com.bytel.spirit.common.shared.saab.rpg.PaTypeCompteAccesSecondaire;
import com.squareup.moshi.Json;

/**
 *
 * @author jiantila
 * @version ($Revision$ $Date$)
 */
public class PI0035_PACompteAccesSecondaire extends PI0035_PA
{
  /**
   *
   */
  private static final long serialVersionUID = -2001449051726818488L;

  /**
   * Create a new instance of {@link PI0035_PACompteAccesSecondaire} from an instance of PA of type
   * {@link PaTypeCompteAccesSecondaire}.
   *
   * @param pa_p
   *          The PA instance parameter.
   * @return The created {@link PI0035_PACompteAccesSecondaire} instance.
   */
  public static PI0035_PACompteAccesSecondaire buildFromPACAS(PA pa_p)
  {
    return new PI0035_PACompteAccesSecondaire(pa_p.getIdentifiantFonctionnelPA(), pa_p.getStatut().name(), pa_p.getTypePA(), pa_p.getPaTypeCompteAccesSecondaire().getLoginEmail(), pa_p.getPaTypeCompteAccesSecondaire().isIgnorerReconciliationInterne(), pa_p.getDateCreation(), pa_p.getDateModification());
  }

  /**
   * Numéro de la ressource de type "NumeroTelephone" Correspondant dans ce cas à un numéro de téléphone fixe
   *
   */
  @Json(name = "loginEmail")
  private String _loginEmail;

  /**
   * Flag bloquant l'application des règles de provisionning
   */
  @Json(name = "ignorerReconciliationInterne")
  private Boolean _ignorerReconciliationInterne = false;

  /**
   *
   */
  public PI0035_PACompteAccesSecondaire()
  {
    super();
  }

  /**
   * @param identifiantFonctionnelPA_p
   * @param statut_p
   * @param typePA_p
   * @param loginEmail_p
   * @param ignorerReconciliationInterne_p
   * @param dateCreation_p
   * @param dateModification_p
   */
  public PI0035_PACompteAccesSecondaire(String identifiantFonctionnelPA_p, String statut_p, String typePA_p, String loginEmail_p, Boolean ignorerReconciliationInterne_p, LocalDateTime dateCreation_p, LocalDateTime dateModification_p)
  {
    super(identifiantFonctionnelPA_p, statut_p, typePA_p, dateCreation_p, dateModification_p);

    _loginEmail = loginEmail_p;
    _ignorerReconciliationInterne = ignorerReconciliationInterne_p;
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (!super.equals(obj))
    {
      return false;
    }

    if ((obj.getClass() != null) && (getClass() != obj.getClass()))
    {
      return false;
    }
    PI0035_PACompteAccesSecondaire other = (PI0035_PACompteAccesSecondaire) obj;
    if (_ignorerReconciliationInterne == null)
    {
      if (other._ignorerReconciliationInterne != null)
      {
        return false;
      }
    }
    else if (!_ignorerReconciliationInterne.equals(other._ignorerReconciliationInterne))
    {
      return false;
    }
    if (_loginEmail == null)
    {
      if (other._loginEmail != null)
      {
        return false;
      }
    }
    else if (!_loginEmail.equals(other._loginEmail))
    {
      return false;
    }

    return true;
  }

  /**
   * @return the ignorerReconciliationInterne
   */
  public Boolean getIgnorerReconciliationInterne()
  {
    return _ignorerReconciliationInterne;
  }

  /**
   * @return the loginEmail
   */
  public String getLoginEmail()
  {
    return _loginEmail;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = super.hashCode();
    result = (prime * result) + ((_ignorerReconciliationInterne == null) ? 0 : _ignorerReconciliationInterne.hashCode());
    result = (prime * result) + ((_loginEmail == null) ? 0 : _loginEmail.hashCode());
    return result;
  }

  /**
   * @param ignorerReconciliationInterne_p
   *          the ignorerReconciliationInterne to set
   */
  public void setIgnorerReconciliationInterne(Boolean ignorerReconciliationInterne_p)
  {
    _ignorerReconciliationInterne = ignorerReconciliationInterne_p;
  }

  /**
   * @param loginEmail_p
   *          the loginEmail to set
   */
  public void setLoginEmail(String loginEmail_p)
  {
    _loginEmail = loginEmail_p;
  }

  @Override
  public String toString()
  {
    StringBuilder builder = new StringBuilder();
    builder.append("PI0035_PACompteAccesSecondaire [_loginEmail="); //$NON-NLS-1$
    builder.append(_loginEmail);
    builder.append(", _ignorerReconciliationInterne="); //$NON-NLS-1$
    builder.append(_ignorerReconciliationInterne);
    builder.append(", getDateCreation()="); //$NON-NLS-1$
    builder.append(getDateCreation());
    builder.append(", getDateModification()="); //$NON-NLS-1$
    builder.append(getDateModification());
    builder.append(", getIdentifiantFonctionnelPA()="); //$NON-NLS-1$
    builder.append(getIdentifiantFonctionnelPA());
    builder.append(", getIdentifiantFonctionnelPALie()="); //$NON-NLS-1$
    builder.append(getIdentifiantFonctionnelPALie());
    builder.append(", getStatut()="); //$NON-NLS-1$
    builder.append(getStatut());
    builder.append(", getTypePA()="); //$NON-NLS-1$
    builder.append(getTypePA());
    builder.append("]"); //$NON-NLS-1$
    return builder.toString();
  }
}
