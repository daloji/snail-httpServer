/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PI0035.sti;

import java.time.LocalDateTime;

import javax.validation.constraints.NotNull;

import com.bytel.spirit.common.shared.misc.validation.IValidationConst;
import com.bytel.spirit.common.shared.saab.rpg.PA;
import com.bytel.spirit.common.shared.saab.rpg.PaTypeCompteAcces;
import com.squareup.moshi.Json;

/**
 *
 * @author jiantila
 * @version ($Revision$ $Date$)
 */
public class PI0035_PACompteAcces extends PI0035_PA
{
  /**
   *
   */
  private static final long serialVersionUID = 502381396610680771L;

  /**
   * Create a new instance of {@link PI0035_PACompteAcces} from an instance of PA of type {@link PaTypeCompteAcces}
   *
   * @param pa_p
   * @return
   */
  public static PI0035_PACompteAcces buildFromPACA(PA pa_p)
  {
    return new PI0035_PACompteAcces(pa_p.getIdentifiantFonctionnelPA(), pa_p.getStatut().name(), pa_p.getTypePA(), pa_p.getDateCreation(), pa_p.getDateModification(), pa_p.getPaTypeCompteAcces().getEmailLogin());
  }

  /**
   * Numéro de la ressource de type "NumeroTelephone" Correspondant dans ce cas à un numéro de téléphone fixe
   *
   */
  @Json(name = "loginEmail")
  private String _loginEmail;

  /**
   *
   */
  public PI0035_PACompteAcces()
  {
    super();
  }

  /**
   * @param loginEmail_p
   */
  public PI0035_PACompteAcces(@NotNull(message = IValidationConst.ATTRIBUT_OBLIGATOIRE_MANQUANT) String loginEmail_p)
  {
    super();

    _loginEmail = loginEmail_p;
  }

  /**
   * @param identifiantFonctionnelPA_p
   * @param statut_p
   * @param typePA_p
   * @param dateCreation_p
   * @param dateModification_p
   * @param loginEmail_p
   */
  public PI0035_PACompteAcces(String identifiantFonctionnelPA_p, String statut_p, String typePA_p, LocalDateTime dateCreation_p, LocalDateTime dateModification_p, @NotNull(message = IValidationConst.ATTRIBUT_OBLIGATOIRE_MANQUANT) String loginEmail_p)
  {
    super(identifiantFonctionnelPA_p, statut_p, typePA_p, dateCreation_p, dateModification_p);

    _loginEmail = loginEmail_p;
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (!super.equals(obj))
    {
      return false;
    }

    if ((obj.getClass() != null) && (getClass() != obj.getClass()))
    {
      return false;
    }
    PI0035_PACompteAcces other = (PI0035_PACompteAcces) obj;
    if (_loginEmail == null)
    {
      if (other._loginEmail != null)
      {
        return false;
      }
    }
    else if (!_loginEmail.equals(other._loginEmail))
    {
      return false;
    }

    return true;
  }

  /**
   * @return the loginEmail
   */
  public String getLoginEmail()
  {
    return _loginEmail;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = super.hashCode();
    result = (prime * result) + ((_loginEmail == null) ? 0 : _loginEmail.hashCode());
    return result;
  }

  /**
   * @param loginEmail_p
   *          the loginEmail to set
   */
  public void setLoginEmail(String loginEmail_p)
  {
    _loginEmail = loginEmail_p;
  }

  @Override
  public String toString()
  {
    StringBuilder builder = new StringBuilder();
    builder.append("PI0035_PACompteAcces [_loginEmail="); //$NON-NLS-1$
    builder.append(_loginEmail);
    builder.append(", getDateCreation()="); //$NON-NLS-1$
    builder.append(getDateCreation());
    builder.append(", getDateModification()="); //$NON-NLS-1$
    builder.append(getDateModification());
    builder.append(", getIdentifiantFonctionnelPA()="); //$NON-NLS-1$
    builder.append(getIdentifiantFonctionnelPA());
    builder.append(", getIdentifiantFonctionnelPALie()="); //$NON-NLS-1$
    builder.append(getIdentifiantFonctionnelPALie());
    builder.append(", getStatut()="); //$NON-NLS-1$
    builder.append(getStatut());
    builder.append(", getTypePA()="); //$NON-NLS-1$
    builder.append(getTypePA());
    builder.append("]"); //$NON-NLS-1$
    return builder.toString();
  }
}
