/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PI0035.sti;

import java.io.Serializable;

import com.squareup.moshi.Json;

/**
 *
 * @author pescudei
 * @version ($Revision$ $Date$)
 */
public class PI0035_DonneesProvisionneesStPfsFqdn implements Serializable
{
  /**
   * Serial ID
   */
  private static final long serialVersionUID = 2248991294927170924L;
  /**
   * Resource nombreSession
   */
  @Json(name = "nombreSession")
  private int _nombreSession;

  /**
   * @param nombreSession_p
   *          nombreSession
   */
  public PI0035_DonneesProvisionneesStPfsFqdn(int nombreSession_p)
  {
    super();
    _nombreSession = nombreSession_p;
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    PI0035_DonneesProvisionneesStPfsFqdn other = (PI0035_DonneesProvisionneesStPfsFqdn) obj;
    if (_nombreSession != other._nombreSession)
    {
      return false;
    }
    return true;
  }

  /**
   * @return the nombreSession
   */
  public int getNombreSession()
  {
    return _nombreSession;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + _nombreSession;
    return result;
  }

  /**
   * @param nombreSession_p
   *          the nombreSession to set
   */
  public void setNombreSession(int nombreSession_p)
  {
    _nombreSession = nombreSession_p;
  }

  @Override
  public String toString()
  {
    StringBuilder builder = new StringBuilder();
    builder.append("PI0035_DonneesProvisionneesStPfsFqdn [_nombreSession="); //$NON-NLS-1$
    builder.append(_nombreSession);
    builder.append("]"); //$NON-NLS-1$
    return builder.toString();
  }
}
