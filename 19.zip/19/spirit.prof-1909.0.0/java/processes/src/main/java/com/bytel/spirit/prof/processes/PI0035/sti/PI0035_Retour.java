/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PI0035.sti;

import java.util.ArrayList;
import java.util.List;

import com.bytel.ravel.types.Retour;
import com.bytel.spirit.common.shared.misc.ressources.BasicResponse;
import com.squareup.moshi.Json;

/**
 *
 * @author jgregori
 * @version ($Revision$ $Date$)
 */
public class PI0035_Retour extends BasicResponse
{
  /**
   * ReponseFonctionnelle
   *
   * @author jgregori
   * @version ($Revision$ $Date$)
   */
  public static class ReponseFonctionnelle
  {
    /**
     * pficomplet
     */
    @Json(name = "pfiComplet")
    private PI0035_PFIComplet _pfiComplet;

    /**
     * erreurBloquante
     */
    @Json(name = "erreurBloquante")
    private List<PI0035_ErreurBloquante> _erreurBloquante;

    @Override
    public boolean equals(Object obj)
    {
      if (this == obj)
      {
        return true;
      }
      if (obj == null)
      {
        return false;
      }
      if (getClass() != obj.getClass())
      {
        return false;
      }
      ReponseFonctionnelle other = (ReponseFonctionnelle) obj;
      if (_erreurBloquante == null)
      {
        if (other._erreurBloquante != null)
        {
          return false;
        }
      }
      else if (!_erreurBloquante.equals(other._erreurBloquante))
      {
        return false;
      }
      if (_pfiComplet == null)
      {
        if (other._pfiComplet != null)
        {
          return false;
        }
      }
      else if (!_pfiComplet.equals(other._pfiComplet))
      {
        return false;
      }
      return true;
    }

    /**
     * @return the erreurBloquante
     */
    public List<PI0035_ErreurBloquante> getErreurBloquante()
    {
      return _erreurBloquante != null ? new ArrayList<>(_erreurBloquante) : new ArrayList<>();
    }

    /**
     * @return the pfiComplet
     */
    public PI0035_PFIComplet getPfiComplet()
    {
      return _pfiComplet;
    }

    @Override
    public int hashCode()
    {
      final int prime = 31;
      int result = 1;
      result = (prime * result) + ((_erreurBloquante == null) ? 0 : _erreurBloquante.hashCode());
      result = (prime * result) + ((_pfiComplet == null) ? 0 : _pfiComplet.hashCode());
      return result;
    }

    /**
     * @param erreurBloquante_p
     *          the erreurBloquante to set
     */
    public void setErreurBloquante(List<PI0035_ErreurBloquante> erreurBloquante_p)
    {
      _erreurBloquante = erreurBloquante_p != null ? new ArrayList<>(erreurBloquante_p) : new ArrayList<>();
    }

    /**
     * @param pfiComplet_p
     *          the pfiComplet to set
     */
    public void setPfiComplet(PI0035_PFIComplet pfiComplet_p)
    {
      _pfiComplet = pfiComplet_p;
    }

    @Override
    public String toString()
    {
      StringBuilder builder = new StringBuilder();
      builder.append("ReponseFonctionnelle [_pfiComplet="); //$NON-NLS-1$
      builder.append(_pfiComplet);
      builder.append(", _erreurBloquante="); //$NON-NLS-1$
      builder.append(_erreurBloquante);
      builder.append("]"); //$NON-NLS-1$
      return builder.toString();
    }
  }

  /**
   *
   */
  private static final long serialVersionUID = -1604283309763266834L;

  /**
   * reponseFonctionnelle
   */
  @Json(name = "reponseFonctionnelle")
  private ReponseFonctionnelle _reponseFonctionnelle;

  /**
   * Public constructor
   *
   * @param retour_p
   *          retour
   */
  public PI0035_Retour(Retour retour_p)
  {
    super(retour_p);
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (!super.equals(obj))
    {
      return false;
    }
    if (getClass() != obj.getClass()) // NOSONAR
    {
      return false;
    }
    PI0035_Retour other = (PI0035_Retour) obj;
    if (_reponseFonctionnelle == null)
    {
      if (other._reponseFonctionnelle != null)
      {
        return false;
      }
    }
    else if (!_reponseFonctionnelle.equals(other._reponseFonctionnelle))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the reponseFonctionnelle
   */
  public ReponseFonctionnelle getReponseFonctionnelle()
  {
    return _reponseFonctionnelle;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = super.hashCode();
    result = (prime * result) + ((_reponseFonctionnelle == null) ? 0 : _reponseFonctionnelle.hashCode());
    return result;
  }

  /**
   * @param reponseFonctionnelle_p
   *          the reponseFonctionnelle to set
   */
  public void setReponseFonctionnelle(ReponseFonctionnelle reponseFonctionnelle_p)
  {
    _reponseFonctionnelle = reponseFonctionnelle_p;
  }

  @Override
  public String toString()
  {
    StringBuilder builder = new StringBuilder();
    builder.append("PI0035_Retour [_reponseFonctionnelle="); //$NON-NLS-1$
    builder.append(_reponseFonctionnelle);
    builder.append(", getRetour()="); //$NON-NLS-1$
    builder.append(getRetour());
    builder.append("]"); //$NON-NLS-1$
    return builder.toString();
  }
}
