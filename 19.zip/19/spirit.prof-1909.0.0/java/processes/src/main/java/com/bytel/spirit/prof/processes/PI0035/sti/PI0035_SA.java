/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PI0035.sti;

import java.io.Serializable;
import java.time.LocalDateTime;

import com.bytel.ravel.common.json.annotations.RavelLocalDateTimeFormat;
import com.bytel.ravel.common.json.format.impl.IsoShortOffsetDateTimeWithMillis;
import com.bytel.spirit.common.shared.saab.rpg.SA;
import com.squareup.moshi.Json;

/**
 *
 * @author jiantila
 * @version ($Revision$ $Date$)
 */
public class PI0035_SA implements Serializable
{
  /**
   *
   */
  private static final long serialVersionUID = -2329841357874023561L;

  /**
   * Creates a new instance of type {@link PI0035_SA} from an instance of type {@link SA}.
   *
   * @param sa_p
   *          The {@link SA} instance.
   * @return The {@link PI0035_SA} instance.
   */
  public static PI0035_SA buildFromSA(SA sa_p)
  {
    return new PI0035_SA(sa_p.getNoServiceAccessible(), sa_p.getStatut().name(), sa_p.getNoServiceCommercial(), sa_p.getCategorieServiceCommercial(), sa_p.getNomServiceCommercial(), sa_p.getDateCreation(), sa_p.getDateModification());
  }

  /**
   * identifiant unique du SA pour un PFI
   */
  @Json(name = "noServiceAccessible")
  private String _noServiceAccessible;

  /**
   * Statut de l'objet commercial attendu par le client operateur
   */
  @Json(name = "statut")
  private String _statut;

  /**
   * Numero du service commercial
   */
  @Json(name = "noServiceCommercial")
  private String _noServiceCommercial;

  /**
   * libelle du service du service commercial
   */
  @Json(name = "categorieServiceCommercial")
  private String _categorieServiceCommercial;

  /**
   * Catégorie du Service Commercial.Les valeurs connues sont définies dans la liste des services commerciaux
   */
  @Json(name = "nomServiceCommercial")
  private String _nomServiceCommercial;

  /**
   * Date de creation
   */
  @Json(name = "dateCreation")
  @RavelLocalDateTimeFormat(IsoShortOffsetDateTimeWithMillis.class)
  private LocalDateTime _dateCreation;

  /**
   * Date de Modification
   */
  @Json(name = "dateModification")
  @RavelLocalDateTimeFormat(IsoShortOffsetDateTimeWithMillis.class)
  private LocalDateTime _dateModification;

  /**
   *
   */
  public PI0035_SA()
  {
    super();
  }

  /**
   * @param noServiceAccessible_p
   * @param statut_p
   * @param noServiceCommercial_p
   * @param categorieServiceCommercial_p
   * @param nomServiceCommercial_p
   * @param dateCreation_p
   * @param dateModification_p
   */
  public PI0035_SA(String noServiceAccessible_p, String statut_p, String noServiceCommercial_p, String categorieServiceCommercial_p, String nomServiceCommercial_p, LocalDateTime dateCreation_p, LocalDateTime dateModification_p)
  {
    super();

    _noServiceAccessible = noServiceAccessible_p;
    _statut = statut_p;
    _noServiceCommercial = noServiceCommercial_p;
    _categorieServiceCommercial = categorieServiceCommercial_p;
    _nomServiceCommercial = nomServiceCommercial_p;
    _dateCreation = dateCreation_p;
    _dateModification = dateModification_p;
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    PI0035_SA other = (PI0035_SA) obj;
    if (_categorieServiceCommercial == null)
    {
      if (other._categorieServiceCommercial != null)
      {
        return false;
      }
    }
    else if (!_categorieServiceCommercial.equals(other._categorieServiceCommercial))
    {
      return false;
    }
    if (_dateCreation == null)
    {
      if (other._dateCreation != null)
      {
        return false;
      }
    }
    else if (!_dateCreation.equals(other._dateCreation))
    {
      return false;
    }
    if (_dateModification == null)
    {
      if (other._dateModification != null)
      {
        return false;
      }
    }
    else if (!_dateModification.equals(other._dateModification))
    {
      return false;
    }
    if (_noServiceAccessible == null)
    {
      if (other._noServiceAccessible != null)
      {
        return false;
      }
    }
    else if (!_noServiceAccessible.equals(other._noServiceAccessible))
    {
      return false;
    }
    if (_noServiceCommercial == null)
    {
      if (other._noServiceCommercial != null)
      {
        return false;
      }
    }
    else if (!_noServiceCommercial.equals(other._noServiceCommercial))
    {
      return false;
    }
    if (_nomServiceCommercial == null)
    {
      if (other._nomServiceCommercial != null)
      {
        return false;
      }
    }
    else if (!_nomServiceCommercial.equals(other._nomServiceCommercial))
    {
      return false;
    }
    if (_statut == null)
    {
      if (other._statut != null)
      {
        return false;
      }
    }
    else if (!_statut.equals(other._statut))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the categorieServiceCommercial
   */
  public String getCategorieServiceCommercial()
  {
    return _categorieServiceCommercial;
  }

  /**
   * @return the dateCreation
   */
  public LocalDateTime getDateCreation()
  {
    return _dateCreation;
  }

  /**
   * @return the dateModification
   */
  public LocalDateTime getDateModification()
  {
    return _dateModification;
  }

  /**
   * @return the nomServiceCommercial
   */
  public String getNomServiceCommercial()
  {
    return _nomServiceCommercial;
  }

  /**
   * @return the noServiceAccessible
   */
  public String getNoServiceAccessible()
  {
    return _noServiceAccessible;
  }

  /**
   * @return the noServiceCommercial
   */
  public String getNoServiceCommercial()
  {
    return _noServiceCommercial;
  }

  /**
   * @return the statut
   */
  public String getStatut()
  {
    return _statut;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_categorieServiceCommercial == null) ? 0 : _categorieServiceCommercial.hashCode());
    result = (prime * result) + ((_dateCreation == null) ? 0 : _dateCreation.hashCode());
    result = (prime * result) + ((_dateModification == null) ? 0 : _dateModification.hashCode());
    result = (prime * result) + ((_noServiceAccessible == null) ? 0 : _noServiceAccessible.hashCode());
    result = (prime * result) + ((_noServiceCommercial == null) ? 0 : _noServiceCommercial.hashCode());
    result = (prime * result) + ((_nomServiceCommercial == null) ? 0 : _nomServiceCommercial.hashCode());
    result = (prime * result) + ((_statut == null) ? 0 : _statut.hashCode());
    return result;
  }

  /**
   * @param categorieServiceCommercial_p
   *          the categorieServiceCommercial to set
   */
  public void setCategorieServiceCommercial(String categorieServiceCommercial_p)
  {
    _categorieServiceCommercial = categorieServiceCommercial_p;
  }

  /**
   * @param dateCreation_p
   *          the dateCreation to set
   */
  public void setDateCreation(LocalDateTime dateCreation_p)
  {
    _dateCreation = dateCreation_p;
  }

  /**
   * @param dateModification_p
   *          the dateModification to set
   */
  public void setDateModification(LocalDateTime dateModification_p)
  {
    _dateModification = dateModification_p;
  }

  /**
   * @param nomServiceCommercial_p
   *          the nomServiceCommercial to set
   */
  public void setNomServiceCommercial(String nomServiceCommercial_p)
  {
    _nomServiceCommercial = nomServiceCommercial_p;
  }

  /**
   * @param noServiceAccessible_p
   *          the noServiceAccessible to set
   */
  public void setNoServiceAccessible(String noServiceAccessible_p)
  {
    _noServiceAccessible = noServiceAccessible_p;
  }

  /**
   * @param noServiceCommercial_p
   *          the noServiceCommercial to set
   */
  public void setNoServiceCommercial(String noServiceCommercial_p)
  {
    _noServiceCommercial = noServiceCommercial_p;
  }

  /**
   * @param statut_p
   *          the statut to set
   */
  public void setStatut(String statut_p)
  {
    _statut = statut_p;
  }

  @Override
  public String toString()
  {
    StringBuilder builder = new StringBuilder();
    builder.append("PI0035_SA [_noServiceAccessible="); //$NON-NLS-1$
    builder.append(_noServiceAccessible);
    builder.append(", _statut="); //$NON-NLS-1$
    builder.append(_statut);
    builder.append(", _noServiceCommercial="); //$NON-NLS-1$
    builder.append(_noServiceCommercial);
    builder.append(", _categorieServiceCommercial="); //$NON-NLS-1$
    builder.append(_categorieServiceCommercial);
    builder.append(", _nomServiceCommercial="); //$NON-NLS-1$
    builder.append(_nomServiceCommercial);
    builder.append(", _dateCreation="); //$NON-NLS-1$
    builder.append(_dateCreation);
    builder.append(", _dateModification="); //$NON-NLS-1$
    builder.append(_dateModification);
    builder.append("]"); //$NON-NLS-1$
    return builder.toString();
  }
}
