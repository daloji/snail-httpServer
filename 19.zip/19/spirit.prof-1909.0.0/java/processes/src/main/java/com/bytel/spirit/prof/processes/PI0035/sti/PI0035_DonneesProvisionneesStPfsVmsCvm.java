/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PI0035.sti;

import java.io.Serializable;

import com.squareup.moshi.Json;

/**
 *
 * @author mbaptist
 * @version ($Revision$ $Date$)
 */
public class PI0035_DonneesProvisionneesStPfsVmsCvm implements Serializable
{

  /**
   *
   */
  private static final long serialVersionUID = 1L;

  /**
   * Resource noTelephone
   */
  @Json(name = "noTelephone")
  private String _noTelephone;

  /**
   * typeUsage
   */
  @Json(name = "typeUsage")
  private String _typeUsage;

  /**
   * ligneMarche
   */
  @Json(name = "ligneMarche")
  private String _ligneMarche;

  /**
   * Resource adresseMail
   */
  @Json(name = "adresseMail")
  private String _adresseMail;

  /**
   * Resource nomPrenomUtilisateur
   */
  @Json(name = "nomPrenomUtilisateur")
  private String _nomPrenomUtilisateur;

  /**
   * @param noTelephone_p
   * @param typeUsage_p
   * @param ligneMarche_p
   * @param adresseMail_p
   * @param nomPrenomUtilisateur_p
   */
  public PI0035_DonneesProvisionneesStPfsVmsCvm(String noTelephone_p, String typeUsage_p, String ligneMarche_p, String adresseMail_p, String nomPrenomUtilisateur_p)
  {
    super();

    _noTelephone = noTelephone_p;
    _typeUsage = typeUsage_p;
    _ligneMarche = ligneMarche_p;
    _adresseMail = adresseMail_p;
    _nomPrenomUtilisateur = nomPrenomUtilisateur_p;
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    PI0035_DonneesProvisionneesStPfsVmsCvm other = (PI0035_DonneesProvisionneesStPfsVmsCvm) obj;
    if (_adresseMail == null)
    {
      if (other._adresseMail != null)
      {
        return false;
      }
    }
    else if (!_adresseMail.equals(other._adresseMail))
    {
      return false;
    }
    if (_ligneMarche == null)
    {
      if (other._ligneMarche != null)
      {
        return false;
      }
    }
    else if (!_ligneMarche.equals(other._ligneMarche))
    {
      return false;
    }
    if (_noTelephone == null)
    {
      if (other._noTelephone != null)
      {
        return false;
      }
    }
    else if (!_noTelephone.equals(other._noTelephone))
    {
      return false;
    }
    if (_nomPrenomUtilisateur == null)
    {
      if (other._nomPrenomUtilisateur != null)
      {
        return false;
      }
    }
    else if (!_nomPrenomUtilisateur.equals(other._nomPrenomUtilisateur))
    {
      return false;
    }
    if (_typeUsage == null)
    {
      if (other._typeUsage != null)
      {
        return false;
      }
    }
    else if (!_typeUsage.equals(other._typeUsage))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the adresseMail
   */
  public String getAdresseMail()
  {
    return _adresseMail;
  }

  /**
   * @return the ligneMarche
   */
  public String getLigneMarche()
  {
    return _ligneMarche;
  }

  /**
   * @return the nomPrenomUtilisateur
   */
  public String getNomPrenomUtilisateur()
  {
    return _nomPrenomUtilisateur;
  }

  /**
   * @return the noTelephone
   */
  public String getNoTelephone()
  {
    return _noTelephone;
  }

  /**
   * @return the typeMessagerie
   */
  public String getTypeUsage()
  {
    return _typeUsage;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_adresseMail == null) ? 0 : _adresseMail.hashCode());
    result = (prime * result) + ((_ligneMarche == null) ? 0 : _ligneMarche.hashCode());
    result = (prime * result) + ((_noTelephone == null) ? 0 : _noTelephone.hashCode());
    result = (prime * result) + ((_nomPrenomUtilisateur == null) ? 0 : _nomPrenomUtilisateur.hashCode());
    result = (prime * result) + ((_typeUsage == null) ? 0 : _typeUsage.hashCode());
    return result;
  }

  /**
   * @param adresseMail_p
   *          the adresseMail to set
   */
  public void setAdresseMail(String adresseMail_p)
  {
    _adresseMail = adresseMail_p;
  }

  /**
   * @param ligneMarche_p
   *          the ligneMarche to set
   */
  public void setLigneMarche(String ligneMarche_p)
  {
    _ligneMarche = ligneMarche_p;
  }

  /**
   * @param nomPrenomUtilisateur_p
   *          the nomPrenomUtilisateur to set
   */
  public void setNomPrenomUtilisateur(String nomPrenomUtilisateur_p)
  {
    _nomPrenomUtilisateur = nomPrenomUtilisateur_p;
  }

  /**
   * @param noTelephone_p
   *          the noTelephone to set
   */
  public void setNoTelephone(String noTelephone_p)
  {
    _noTelephone = noTelephone_p;
  }

  /**
   * @param typeUsage_p
   *          the typeMessagerie to set
   */
  public void setTypeUsage(String typeUsage_p)
  {
    _typeUsage = typeUsage_p;
  }

  @Override
  public String toString()
  {
    StringBuilder builder = new StringBuilder();
    builder.append("PI0035_DonneesProvisionneesStPfsVmsCvm [_noTelephone="); //$NON-NLS-1$
    builder.append(_noTelephone);
    builder.append(", _typeUsage="); //$NON-NLS-1$
    builder.append(_typeUsage);
    builder.append(", _ligneMarche="); //$NON-NLS-1$
    builder.append(_ligneMarche);
    builder.append(", _adresseMail="); //$NON-NLS-1$
    builder.append(_adresseMail);
    builder.append(", _nomPrenomUtilisateur="); //$NON-NLS-1$
    builder.append(_nomPrenomUtilisateur);
    builder.append("]"); //$NON-NLS-1$
    return builder.toString();
  }
}
