/*******************************************************************************
* $Id: PI0035_StPfsTASFixe.java 23286 2019-06-28 09:38:54Z jgregori $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PI0035.sti;

import java.time.LocalDateTime;

import com.bytel.spirit.common.shared.functional.types.json.st.pfs.TypePFS;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.tasfixe.StPfsTASFixe;
import com.squareup.moshi.Json;

/**
 *
 * @author kbettenc
 * @version ($Revision: 23286 $ $Date: 2019-06-28 11:38:54 +0200 (ven. 28 juin 2019) $)
 */
public class PI0035_StPfsTASFixe extends PI0035_AbstractStPfs
{

  /**
   *
   */
  private static final long serialVersionUID = -1677447848059495794L;

  /**
   * Builds a new instance of {@link PI0035_StPfsTASFixe} from an instance of {@link StPfsTASFixe}
   *
   * @param stPfsTASFixe_p
   *          The instance of {@link StPfsTASFixe}.
   * @return The instance of {@link PI0035_StPfsTASFixe}.
   */
  public static PI0035_StPfsTASFixe buildFromStPfsTASFixe(StPfsTASFixe stPfsTASFixe_p)
  {
    PI0035_DonneesIdentificationStPfsTASFixe donneesIdentificationStPfsTASFixe = new PI0035_DonneesIdentificationStPfsTASFixe(stPfsTASFixe_p.getDonneesIdentificationStPfsTASFixe().getIdentifiantFonctionnelPA());

    PI0035_DonneesProvisionneesStPfsTASFixe donneesProvisionneesStPfsTASFixe = null;
    if (stPfsTASFixe_p.getDonneesProvisionneesStPfsTASFixe() != null)
    {
      donneesProvisionneesStPfsTASFixe = new PI0035_DonneesProvisionneesStPfsTASFixe(stPfsTASFixe_p.getDonneesProvisionneesStPfsTASFixe().getNoTelephone(), //
          stPfsTASFixe_p.getDonneesProvisionneesStPfsTASFixe().getTypeUsage(), //
          stPfsTASFixe_p.getDonneesProvisionneesStPfsTASFixe().getNiveauRestriction(), //
          stPfsTASFixe_p.getDonneesProvisionneesStPfsTASFixe().getNotificationSuspension(), //
          stPfsTASFixe_p.getDonneesProvisionneesStPfsTASFixe().getOptionAppelSurTaxes(), //
          stPfsTASFixe_p.getDonneesProvisionneesStPfsTASFixe().getNom(), //
          stPfsTASFixe_p.getDonneesProvisionneesStPfsTASFixe().getPrenom(), //
          stPfsTASFixe_p.getDonneesProvisionneesStPfsTASFixe().getNomPrenomCourt());
    }

    return new PI0035_StPfsTASFixe(stPfsTASFixe_p.getIdSt(), stPfsTASFixe_p.getStatut(), stPfsTASFixe_p.getDateCreation(), stPfsTASFixe_p.getDateModification(), donneesIdentificationStPfsTASFixe, donneesProvisionneesStPfsTASFixe);
  }

  /**
   * Donnes Identification
   */
  @Json(name = "donneesIdentification")
  private PI0035_DonneesIdentificationStPfsTASFixe _donneesIdentification;

  /**
   * Donnes Provisionnees
   */
  @Json(name = "donneesProvisionnees")
  private PI0035_DonneesProvisionneesStPfsTASFixe _donneesProvisionnees;

  /**
   * @param idSt_p
   * @param statut_p
   * @param dateCreation_p
   * @param dateModification_p
   * @param donneesIdentificationStPfsTASFixe_p
   * @param donneesProvisionneesStPfsTASFixe_p
   */
  public PI0035_StPfsTASFixe(String idSt_p, String statut_p, LocalDateTime dateCreation_p, LocalDateTime dateModification_p, PI0035_DonneesIdentificationStPfsTASFixe donneesIdentificationStPfsTASFixe_p, PI0035_DonneesProvisionneesStPfsTASFixe donneesProvisionneesStPfsTASFixe_p)
  {
    super(idSt_p, statut_p, TypePFS.TAS_FIXE.name(), dateCreation_p, dateModification_p);
    _donneesIdentification = donneesIdentificationStPfsTASFixe_p;
    _donneesProvisionnees = donneesProvisionneesStPfsTASFixe_p;
  }

  /**
   * @return the donneesIdentification
   */
  public PI0035_DonneesIdentificationStPfsTASFixe getDonneesIdentification()
  {
    return _donneesIdentification;
  }

  /**
   * @return the donneesProvisionnees
   */
  public PI0035_DonneesProvisionneesStPfsTASFixe getDonneesProvisionnees()
  {
    return _donneesProvisionnees;
  }

  /**
   * @param donneesIdentification_p
   *          the donneesIdentification to set
   */
  public void setDonneesIdentification(PI0035_DonneesIdentificationStPfsTASFixe donneesIdentification_p)
  {
    _donneesIdentification = donneesIdentification_p;
  }

  /**
   * @param donneesProvisionnees_p
   *          the donneesProvisionnees to set
   */
  public void setDonneesProvisionnees(PI0035_DonneesProvisionneesStPfsTASFixe donneesProvisionnees_p)
  {
    _donneesProvisionnees = donneesProvisionnees_p;
  }

  @Override
  public String toString()
  {
    StringBuilder builder = new StringBuilder();
    builder.append("PI0035_StPfsTASFixe [_donneesIdentification="); //$NON-NLS-1$
    builder.append(_donneesIdentification);
    builder.append(", _donneesProvisionnees="); //$NON-NLS-1$
    builder.append(_donneesProvisionnees);
    builder.append(", getCommentaire()="); //$NON-NLS-1$
    builder.append(getCommentaire());
    builder.append(", getDateCreation()="); //$NON-NLS-1$
    builder.append(getDateCreation());
    builder.append(", getDateModification()="); //$NON-NLS-1$
    builder.append(getDateModification());
    builder.append(", getIdSt()="); //$NON-NLS-1$
    builder.append(getIdSt());
    builder.append(", getStatut()="); //$NON-NLS-1$
    builder.append(getStatut());
    builder.append(", getTypeServiceTechnique()="); //$NON-NLS-1$
    builder.append(getTypeServiceTechnique());
    builder.append("]"); //$NON-NLS-1$
    return builder.toString();
  }

}
