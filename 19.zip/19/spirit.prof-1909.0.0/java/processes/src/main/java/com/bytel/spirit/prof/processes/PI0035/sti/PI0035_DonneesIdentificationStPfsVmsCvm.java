/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.processes.PI0035.sti;

import java.io.Serializable;

import com.bytel.spirit.common.shared.functional.types.json.st.pfs.vmscvm.DonneesIdentificationSTPfsVmsCvm;
import com.squareup.moshi.Json;

/**
 *
 * @author mbaptist
 * @version ($Revision$ $Date$)
 */
public class PI0035_DonneesIdentificationStPfsVmsCvm implements Serializable
{

  /**
   *
   */
  private static final long serialVersionUID = 1L;

  /**
   * Ressource identifiantFonctionnelPa
   */
  @Json(name = "identifiantFonctionnelPA")
  private String _identifiantFonctionnelPa;

  /**
   * @param identifiantFonctionnelPa_p
   */
  public PI0035_DonneesIdentificationStPfsVmsCvm(String identifiantFonctionnelPa_p)
  {
    super();

    _identifiantFonctionnelPa = identifiantFonctionnelPa_p;
  }

  /**
   * Build PI0035_DonnesIdentificationSTPfsMail from {@code DonnesIdentificationSTPfsMail}
   *
   * @param donneesIdentification_p
   *          DonnesIdentificationSTPfsMail instance
   * @return PI0035_DonnesIdentificationSTPfsMail instance
   */
  public PI0035_DonneesIdentificationStPfsVmsCvm buildFromDonneesIdentificationStPfsVmsCvm(DonneesIdentificationSTPfsVmsCvm donneesIdentification_p)
  {
    return new PI0035_DonneesIdentificationStPfsVmsCvm(donneesIdentification_p.getIdentifiantFonctionnelPa());
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    PI0035_DonneesIdentificationStPfsVmsCvm other = (PI0035_DonneesIdentificationStPfsVmsCvm) obj;
    if (_identifiantFonctionnelPa == null)
    {
      if (other._identifiantFonctionnelPa != null)
      {
        return false;
      }
    }
    else if (!_identifiantFonctionnelPa.equals(other._identifiantFonctionnelPa))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the identifiantFonctionnelPa
   */
  public String getIdentifiantFonctionnelPa()
  {
    return _identifiantFonctionnelPa;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_identifiantFonctionnelPa == null) ? 0 : _identifiantFonctionnelPa.hashCode());
    return result;
  }

  /**
   * @param identifiantFonctionnelPa_p
   *          the identifiantFonctionnelPa to set
   */
  public void setIdentifiantFonctionnelPa(String identifiantFonctionnelPa_p)
  {
    _identifiantFonctionnelPa = identifiantFonctionnelPa_p;
  }

  @Override
  public String toString()
  {
    StringBuilder builder = new StringBuilder();
    builder.append("PI0035_DonneesIdentificationStPfsVmsCvm [_identifiantFonctionnelPa="); //$NON-NLS-1$
    builder.append(_identifiantFonctionnelPa);
    builder.append("]"); //$NON-NLS-1$
    return builder.toString();
  }
}
