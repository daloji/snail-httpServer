/*******************************************************************************
* $Id: BL1000_ConsulterRefCli_Test.java 35893 2017-05-15 11:08:45Z fcabral $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.activities.refclient;

import org.easymock.EasyMock;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.bouygtel.commontypes.s3g.v3.DescriptionErreur;
import com.bouygtel.commontypes.s3g.v3.EnumOKNOK;
import com.bouygtel.commontypes.s3g.v3.ReponseServicePIVOTTYPEDansFluxCRFonctionnel;
import com.bouygtel.refcli.consulterpfi.in.ConsulterPFIIn;
import com.bouygtel.refcli.consulterpfi.out.ConsulterPFIOut;
import com.bouygtel.refcli.consulterpfi.out.ConsulterPFIReponseType;
import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.ACManagerUtil;
import com.bytel.ravel.common.utils.RetourFactoryForTU;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.IActivityCaller;
import com.bytel.ravel.services.process.activity.Context;
import com.bytel.ravel.services.utils.Test_Consts;
import com.bytel.spirit.common.shared.misc.ressources.Consts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.prof.activities.refclient.BL1000_ConsulterRefCli.BL1000_ConsulterRefCliBuilder;
import com.bytel.spirit.prof.connectors.refclient.RefClientProxy;
import com.bytel.spirit.prof.connectors.refclient.meg.REFCLIENT001EnvoyerDemande;

/**
 *
 * @author lchanyip
 * @version ($Revision: 35893 $ $Date: 2017-05-15 13:08:45 +0200 (lun., 15 mai 2017) $)
 */
//Déclaration du runner de test pour lancer les TUs avec le runner PowerMock
@RunWith(PowerMockRunner.class)
//Préparation des classes pour les tests, toutes les classes comportant des méthodes statiques à mocker doivent être présentes dans l'annotation
@PrepareForTest({ RefClientProxy.class })
//To avoid: SecretKeyFactory.getInstance() throws exception for all algorithms in unit tests
@PowerMockIgnore("javax.crypto.*")
public class BL1000_ConsulterRefCli_Test
{
  /**
   *
   * @author lmerces
   * @version ($Revision$ $Date$)
   */
  private class ActivityCallerTest implements IActivityCaller
  {
    /**
     *
     */
    public ActivityCallerTest()
    {
      // TODO Auto-generated constructor stub
    }

    @Override
    public Request getContinueProcessData() throws RavelException
    {
      // TODO Auto-generated method stub
      return null;
    }

    @Override
    public String getIdProcess()
    {
      // TODO Auto-generated method stub
      return null;
    }

    @Override
    public String getMsgId()
    {
      // TODO Auto-generated method stub
      return null;
    }

    @Override
    public String getName()
    {
      // TODO Auto-generated method stub
      return null;
    }

    @Override
    public void interrupt()
    {
      // TODO Auto-generated method stub
    }

    @Override
    public boolean mustStop()
    {
      // TODO Auto-generated method stub
      return false;
    }
  }

  /**
   *
   * @author lchanyip
   * @version ($Revision: 35893 $ $Date: 2017-05-15 13:08:45 +0200 (lun., 15 mai 2017) $)
   */
  class BL1000_ConsulterRefCliTestContext extends Context
  {
    /**
     * Generated UID
     */
    private static final long serialVersionUID = -3388364659139621236L;
  }

  /**
   *
   */
  private static final String IMSI = "123456789012345"; //$NON-NLS-1$

  /**
   *
   */
  private static final String MSISDN = "33633445566"; //$NON-NLS-1$

  /**
   *
   */
  private static final String PFI_NOCOMPTE = "11700000091"; //$NON-NLS-1$

  /**
  *
  */
  private static final String CONSULTERPFI_CONNECTOR_ID = "RefClientConnector"; //$NON-NLS-1$

  /**
   * @param imsi_p
   *          imsi
   * @return {@link ConsulterPFIIn}
   */
  public static ConsulterPFIIn createConsulterPFIInByIMSI(String imsi_p)
  {
    ConsulterPFIIn consulterPFIInByImsi = new ConsulterPFIIn();
    com.bouygtel.refcli.consulterpfi.in.SimLogique sl = new com.bouygtel.refcli.consulterpfi.in.SimLogique();
    sl.setImsi(imsi_p);
    consulterPFIInByImsi.setSimLogique(sl);
    return consulterPFIInByImsi;
  }

  /**
   * @param msisdn_p
   *          msisdn
   * @return {@link ConsulterPFIIn}
   */
  public static ConsulterPFIIn createConsulterPFIInByMSISDN(String msisdn_p)
  {
    ConsulterPFIIn consulterPFIInByMsisdn = new ConsulterPFIIn();
    com.bouygtel.refcli.consulterpfi.in.Msisdn msisdn = new com.bouygtel.refcli.consulterpfi.in.Msisdn();
    msisdn.setMsisdn(msisdn_p);
    consulterPFIInByMsisdn.setMsisdn(msisdn);
    return consulterPFIInByMsisdn;
  }

  /**
   * @param pfiNocompte_p
   *          noCompte
   * @return {@link ConsulterPFIIn}
   */
  public static ConsulterPFIIn createConsulterPFIInByPFI(String pfiNocompte_p)
  {
    ConsulterPFIIn consulterPFIInByPfi = new ConsulterPFIIn();
    com.bouygtel.refcli.consulterpfi.in.PortefeuilleIndividuel pfi = new com.bouygtel.refcli.consulterpfi.in.PortefeuilleIndividuel();
    pfi.setNoCompte(pfiNocompte_p);
    consulterPFIInByPfi.setPortefeuilleIndividuel(pfi);
    return consulterPFIInByPfi;
  }

  /**
   * @return {@link ConsulterPFIReponseType}
   */
  public static ConsulterPFIReponseType createConsulterPFIReponseTypeBasicResponseOK()
  {
    ConsulterPFIReponseType consulterPFIReponseType = new ConsulterPFIReponseType();
    ConsulterPFIOut consulterPFIOut = new ConsulterPFIOut();
    consulterPFIReponseType.setConsulterPFIOut(consulterPFIOut);
    ReponseServicePIVOTTYPEDansFluxCRFonctionnel responseService = new ReponseServicePIVOTTYPEDansFluxCRFonctionnel();
    responseService.setCodeErreur(EnumOKNOK.OK);
    consulterPFIReponseType.setReponseService(responseService);
    return consulterPFIReponseType;
  }

  /**
   * @param raison
   *          raison
   * @param errCode
   *          errCode
   * @param errDiag
   *          errDiag
   * @return {@link ConsulterPFIReponseType}
   */
  public static ConsulterPFIReponseType createConsulterPFIReponseTypeResponse_NOK(String raison, String errCode, String errDiag)
  {
    ConsulterPFIReponseType consulterPFIReponseType = new ConsulterPFIReponseType();
    consulterPFIReponseType.setConsulterPFIOut(null);
    ReponseServicePIVOTTYPEDansFluxCRFonctionnel responseService = new ReponseServicePIVOTTYPEDansFluxCRFonctionnel();
    responseService.setCodeErreur(EnumOKNOK.NOK);
    responseService.setRaison(raison);
    DescriptionErreur descriptionErreur = new DescriptionErreur();
    descriptionErreur.setCode(errCode);
    responseService.setDescriptionErreur(descriptionErreur);
    responseService.setDiagnostic(errDiag);
    consulterPFIReponseType.setReponseService(responseService);
    return consulterPFIReponseType;
  }

  /**
   * init
   */
  @BeforeClass
  public static void init()
  {
    ACManagerUtil.resetACManager();
    new ClassPathXmlApplicationContext("classpath:BeansProcessTestMocks.xml"); //$NON-NLS-1$
  }

  /**
   *
   */
  @MockStrict
  private RefClientProxy _refClientConnector;

  /**
   * Called before each test with the annotation @ Before to clean the connectors.
   */
  @Before
  public void beforeTest()
  {
    // on réinitialise tous les mocks afin de ne pas avoir d'interférence entre les tests
    PowerMock.resetAll();

    // On initialise toutes les classes à mocker comportant un appel à une méthode statique
    // Dans notre cas on mock statiquemement toutes les classes des activités et des proxys appelés (pour les createContexte et les getInstance)
    PowerMock.mockStaticStrict(RefClientProxy.class);
  }

  /**
   * Test KO (erreur technique) d'une consultation par IMSI.
   *
   * @throws RavelException
   *           exception
   */
  @Test
  public void BL1000_ConsulterRefCli_Test_ConsultByIMSI_KO_ErrTech() throws RavelException
  {
    Tracabilite tracabilite = new Tracabilite(StringConstants.EMPTY_STRING, Test_Consts.DEFAULT_MSGID, "PROF", "nomPRocessus", "idProcessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$;

    //Prepare mock
    EasyMock.expect(RefClientProxy.getInstance()).andReturn(_refClientConnector);
    EasyMock.expectLastCall().anyTimes();

    EasyMock.expect(_refClientConnector.consulterPFI(EasyMock.eq(tracabilite), EasyMock.isA(ConsulterPFIIn.class), EasyMock.eq(CONSULTERPFI_CONNECTOR_ID))).andReturn(new ConnectorResponse<ConsulterPFIReponseType, Integer>(createConsulterPFIReponseTypeResponse_NOK(null, REFCLIENT001EnvoyerDemande.INCONNU_PFI, null), 200));
    EasyMock.expect(_refClientConnector.consulterPFI(EasyMock.eq(tracabilite), EasyMock.isA(ConsulterPFIIn.class), EasyMock.eq(CONSULTERPFI_CONNECTOR_ID))).andReturn(new ConnectorResponse<ConsulterPFIReponseType, Integer>(createConsulterPFIReponseTypeResponse_NOK(null, REFCLIENT001EnvoyerDemande.INCONNU_PFI, null), 200));
    EasyMock.expect(_refClientConnector.consulterPFI(EasyMock.eq(tracabilite), EasyMock.isA(ConsulterPFIIn.class), EasyMock.eq(CONSULTERPFI_CONNECTOR_ID))).andReturn(new ConnectorResponse<ConsulterPFIReponseType, Integer>(null, 500));

    PowerMock.replayAll();

    BL1000_ConsulterRefCli iws_BL1000_ConsulterRefCli = new BL1000_ConsulterRefCliBuilder().tracabilite(tracabilite).pfsNoCompte(PFI_NOCOMPTE).msisdn(MSISDN).imsi(IMSI).refCliConnectorId(CONSULTERPFI_CONNECTOR_ID).build();
    ConsulterPFIOut result = iws_BL1000_ConsulterRefCli.execute(new ActivityCallerTest());

    PowerMock.verifyAll();

    Assert.assertEquals(iws_BL1000_ConsulterRefCli.getRetour().getResultat(), "KO"); //$NON-NLS-1$
    Assert.assertEquals(iws_BL1000_ConsulterRefCli.getRetour().getCategorie(), IMegConsts.CAT1);
    Assert.assertEquals(iws_BL1000_ConsulterRefCli.getRetour().getDiagnostic(), Consts.SERVICE_INDISPONIBLE.toString());
    Assert.assertEquals(iws_BL1000_ConsulterRefCli.getRetour().getLibelle(), "Erreur REFCLIENT : Code HTTP =500, Raison = service indisponible  reessayer ulterieurement"); //$NON-NLS-1$
    Assert.assertNull(result);
  }

  /**
   * Consultation par IMSI NOK avec une autre raison que DEF-2. Retourne KO/CAT-3.
   *
   * @throws RavelException
   *           exception
   */
  @Test
  public void BL1000_ConsulterRefCli_Test_ConsultByIMSI_NOK_Autre() throws RavelException
  {
    Tracabilite tracabilite = new Tracabilite(StringConstants.EMPTY_STRING, Test_Consts.DEFAULT_MSGID, "PROF", "nomPRocessus", "idProcessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$;

    ConsulterPFIReponseType consulterPFIReponseType = createConsulterPFIReponseTypeResponse_NOK(Consts.DEF_10.toString(), "ERRCODE xxx", "DIAG_ERRCODE xxx"); //$NON-NLS-1$ //$NON-NLS-2$

    //Prepare mock
    EasyMock.expect(RefClientProxy.getInstance()).andReturn(_refClientConnector);
    EasyMock.expectLastCall().anyTimes();

    EasyMock.expect(_refClientConnector.consulterPFI(EasyMock.eq(tracabilite), EasyMock.isA(ConsulterPFIIn.class), EasyMock.eq(CONSULTERPFI_CONNECTOR_ID))).andReturn(new ConnectorResponse<ConsulterPFIReponseType, Integer>(createConsulterPFIReponseTypeResponse_NOK(null, REFCLIENT001EnvoyerDemande.INCONNU_PFI, null), 200));
    EasyMock.expect(_refClientConnector.consulterPFI(EasyMock.eq(tracabilite), EasyMock.isA(ConsulterPFIIn.class), EasyMock.eq(CONSULTERPFI_CONNECTOR_ID))).andReturn(new ConnectorResponse<ConsulterPFIReponseType, Integer>(createConsulterPFIReponseTypeResponse_NOK(null, REFCLIENT001EnvoyerDemande.INCONNU_PFI, null), 200));
    EasyMock.expect(_refClientConnector.consulterPFI(EasyMock.eq(tracabilite), EasyMock.isA(ConsulterPFIIn.class), EasyMock.eq(CONSULTERPFI_CONNECTOR_ID))).andReturn(new ConnectorResponse<ConsulterPFIReponseType, Integer>(consulterPFIReponseType, 200));

    PowerMock.replayAll();

    BL1000_ConsulterRefCli iws_BL1000_ConsulterRefCli = new BL1000_ConsulterRefCliBuilder().tracabilite(tracabilite).pfsNoCompte(PFI_NOCOMPTE).msisdn(MSISDN).imsi(IMSI).refCliConnectorId(CONSULTERPFI_CONNECTOR_ID).build();
    ConsulterPFIOut result = iws_BL1000_ConsulterRefCli.execute(new ActivityCallerTest());

    PowerMock.verifyAll();

    Assert.assertEquals(iws_BL1000_ConsulterRefCli.getRetour().getResultat(), "KO"); //$NON-NLS-1$
    Assert.assertEquals(iws_BL1000_ConsulterRefCli.getRetour().getCategorie(), IMegConsts.CAT3);
    Assert.assertEquals(iws_BL1000_ConsulterRefCli.getRetour().getDiagnostic(), Consts.DEF_10.toString() + "/ERRCODE xxx"); //$NON-NLS-1$
    Assert.assertEquals(iws_BL1000_ConsulterRefCli.getRetour().getLibelle(), "DIAG_ERRCODE xxx"); //$NON-NLS-1$
    Assert.assertNull(result);
  }

  /**
   * Consultation par IMSI NOK/raison DEF-2. Retourne KO/CAT-1.
   *
   * @throws RavelException
   *           exception
   */
  @Test
  public void BL1000_ConsulterRefCli_Test_ConsultByIMSI_NOK_DEF2() throws RavelException
  {
    Tracabilite tracabilite = new Tracabilite(StringConstants.EMPTY_STRING, Test_Consts.DEFAULT_MSGID, "PROF", "nomPRocessus", "idProcessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$;

    ConsulterPFIReponseType consulterPFIReponseType = createConsulterPFIReponseTypeResponse_NOK(Consts.DEF_2.toString(), "ERRCODE_1234", "DIAG_ERRCODE_1234"); //$NON-NLS-1$ //$NON-NLS-2$

    //Prepare mock
    EasyMock.expect(RefClientProxy.getInstance()).andReturn(_refClientConnector);
    EasyMock.expectLastCall().anyTimes();

    EasyMock.expect(_refClientConnector.consulterPFI(EasyMock.eq(tracabilite), EasyMock.isA(ConsulterPFIIn.class), EasyMock.eq(CONSULTERPFI_CONNECTOR_ID))).andReturn(new ConnectorResponse<ConsulterPFIReponseType, Integer>(createConsulterPFIReponseTypeResponse_NOK(null, REFCLIENT001EnvoyerDemande.INCONNU_PFI, null), 200));
    EasyMock.expect(_refClientConnector.consulterPFI(EasyMock.eq(tracabilite), EasyMock.isA(ConsulterPFIIn.class), EasyMock.eq(CONSULTERPFI_CONNECTOR_ID))).andReturn(new ConnectorResponse<ConsulterPFIReponseType, Integer>(createConsulterPFIReponseTypeResponse_NOK(null, REFCLIENT001EnvoyerDemande.INCONNU_PFI, null), 200));
    EasyMock.expect(_refClientConnector.consulterPFI(EasyMock.eq(tracabilite), EasyMock.isA(ConsulterPFIIn.class), EasyMock.eq(CONSULTERPFI_CONNECTOR_ID))).andReturn(new ConnectorResponse<ConsulterPFIReponseType, Integer>(consulterPFIReponseType, 200));

    PowerMock.replayAll();

    BL1000_ConsulterRefCli iws_BL1000_ConsulterRefCli = new BL1000_ConsulterRefCliBuilder().tracabilite(tracabilite).pfsNoCompte(PFI_NOCOMPTE).msisdn(MSISDN).imsi(IMSI).refCliConnectorId(CONSULTERPFI_CONNECTOR_ID).build();
    ConsulterPFIOut result = iws_BL1000_ConsulterRefCli.execute(new ActivityCallerTest());

    PowerMock.verifyAll();

    Assert.assertEquals(iws_BL1000_ConsulterRefCli.getRetour().getResultat(), "KO"); //$NON-NLS-1$
    Assert.assertEquals(iws_BL1000_ConsulterRefCli.getRetour().getCategorie(), IMegConsts.CAT1);
    Assert.assertEquals(iws_BL1000_ConsulterRefCli.getRetour().getDiagnostic(), "ERRCODE_1234"); //$NON-NLS-1$
    Assert.assertEquals(iws_BL1000_ConsulterRefCli.getRetour().getLibelle(), "DIAG_ERRCODE_1234"); //$NON-NLS-1$
    Assert.assertNull(result);
  }

  /**
   * Consultation par IMSI inexistant (NOK/INCONNU_PFI). Retourne KO/CAT-3/INCONNU_PFI.
   *
   * @throws RavelException
   *           exception
   */
  @Test
  public void BL1000_ConsulterRefCli_Test_ConsultByIMSI_NOK_INCONNU_PFI() throws RavelException
  {
    Tracabilite tracabilite = new Tracabilite(StringConstants.EMPTY_STRING, Test_Consts.DEFAULT_MSGID, "PROF", "nomPRocessus", "idProcessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$;

    ConsulterPFIReponseType consulterPFIReponseType = createConsulterPFIReponseTypeResponse_NOK(null, REFCLIENT001EnvoyerDemande.INCONNU_PFI, null);

    //Prepare mock
    EasyMock.expect(RefClientProxy.getInstance()).andReturn(_refClientConnector);
    EasyMock.expectLastCall().anyTimes();

    EasyMock.expect(_refClientConnector.consulterPFI(EasyMock.eq(tracabilite), EasyMock.isA(ConsulterPFIIn.class), EasyMock.eq(CONSULTERPFI_CONNECTOR_ID))).andReturn(new ConnectorResponse<ConsulterPFIReponseType, Integer>(createConsulterPFIReponseTypeResponse_NOK(null, REFCLIENT001EnvoyerDemande.INCONNU_PFI, null), 200));
    EasyMock.expect(_refClientConnector.consulterPFI(EasyMock.eq(tracabilite), EasyMock.isA(ConsulterPFIIn.class), EasyMock.eq(CONSULTERPFI_CONNECTOR_ID))).andReturn(new ConnectorResponse<ConsulterPFIReponseType, Integer>(createConsulterPFIReponseTypeResponse_NOK(null, REFCLIENT001EnvoyerDemande.INCONNU_PFI, null), 200));
    EasyMock.expect(_refClientConnector.consulterPFI(EasyMock.eq(tracabilite), EasyMock.isA(ConsulterPFIIn.class), EasyMock.eq(CONSULTERPFI_CONNECTOR_ID))).andReturn(new ConnectorResponse<ConsulterPFIReponseType, Integer>(consulterPFIReponseType, 200));

    PowerMock.replayAll();

    BL1000_ConsulterRefCli iws_BL1000_ConsulterRefCli = new BL1000_ConsulterRefCliBuilder().tracabilite(tracabilite).pfsNoCompte(PFI_NOCOMPTE).msisdn(MSISDN).imsi(IMSI).refCliConnectorId(CONSULTERPFI_CONNECTOR_ID).build();
    ConsulterPFIOut result = iws_BL1000_ConsulterRefCli.execute(new ActivityCallerTest());

    PowerMock.verifyAll();

    Assert.assertEquals(iws_BL1000_ConsulterRefCli.getRetour().getResultat(), "KO"); //$NON-NLS-1$
    Assert.assertEquals(iws_BL1000_ConsulterRefCli.getRetour().getCategorie(), IMegConsts.CAT3);
    Assert.assertEquals(iws_BL1000_ConsulterRefCli.getRetour().getDiagnostic(), "INCONNU_PFI"); //$NON-NLS-1$
    Assert.assertEquals(iws_BL1000_ConsulterRefCli.getRetour().getLibelle(), "Erreur REFCLIENT : PFI inexistant"); //$NON-NLS-1$
    Assert.assertNull(result);
  }

  /**
   * Test OK d'une consultation par IMSI avec le client trouvé (la recherche par PFI et par MSISDN n'ont pas permis de
   * trouver le client)
   *
   * @throws RavelException
   *           exception
   */
  @Test
  public void BL1000_ConsulterRefCli_Test_ConsultByIMSI_OK() throws RavelException
  {
    Tracabilite tracabilite = new Tracabilite(StringConstants.EMPTY_STRING, Test_Consts.DEFAULT_MSGID, "PROF", "nomPRocessus", "idProcessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$;

    //Prepare mock
    EasyMock.expect(RefClientProxy.getInstance()).andReturn(_refClientConnector);
    EasyMock.expectLastCall().anyTimes();

    EasyMock.expect(_refClientConnector.consulterPFI(EasyMock.eq(tracabilite), EasyMock.isA(ConsulterPFIIn.class), EasyMock.eq(CONSULTERPFI_CONNECTOR_ID))).andReturn(new ConnectorResponse<ConsulterPFIReponseType, Integer>(createConsulterPFIReponseTypeResponse_NOK(null, REFCLIENT001EnvoyerDemande.INCONNU_PFI, null), 200));
    EasyMock.expect(_refClientConnector.consulterPFI(EasyMock.eq(tracabilite), EasyMock.isA(ConsulterPFIIn.class), EasyMock.eq(CONSULTERPFI_CONNECTOR_ID))).andReturn(new ConnectorResponse<ConsulterPFIReponseType, Integer>(createConsulterPFIReponseTypeResponse_NOK(null, REFCLIENT001EnvoyerDemande.INCONNU_PFI, null), 200));
    EasyMock.expect(_refClientConnector.consulterPFI(EasyMock.eq(tracabilite), EasyMock.isA(ConsulterPFIIn.class), EasyMock.eq(CONSULTERPFI_CONNECTOR_ID))).andReturn(new ConnectorResponse<ConsulterPFIReponseType, Integer>(createConsulterPFIReponseTypeBasicResponseOK(), 200));

    PowerMock.replayAll();

    BL1000_ConsulterRefCli iws_BL1000_ConsulterRefCli = new BL1000_ConsulterRefCliBuilder().tracabilite(tracabilite).pfsNoCompte(PFI_NOCOMPTE).msisdn(MSISDN).imsi(IMSI).refCliConnectorId(CONSULTERPFI_CONNECTOR_ID).build();
    ConsulterPFIOut result = iws_BL1000_ConsulterRefCli.execute(new ActivityCallerTest());

    PowerMock.verifyAll();

    checkResponse(iws_BL1000_ConsulterRefCli.getRetour(), RetourFactoryForTU.createOkRetour());
    Assert.assertNotNull(result);
  }

  /**
   * Test KO (erreur technique) d'une consultation par MSISDN.
   *
   * @throws RavelException
   *           exception
   */
  @Test
  public void BL1000_ConsulterRefCli_Test_ConsultByMSISDN_KO_ErrTech() throws RavelException
  {
    Tracabilite tracabilite = new Tracabilite(StringConstants.EMPTY_STRING, Test_Consts.DEFAULT_MSGID, "PROF", "nomPRocessus", "idProcessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$;

    //Prepare mock
    EasyMock.expect(RefClientProxy.getInstance()).andReturn(_refClientConnector);
    EasyMock.expectLastCall().anyTimes();

    EasyMock.expect(_refClientConnector.consulterPFI(EasyMock.eq(tracabilite), EasyMock.isA(ConsulterPFIIn.class), EasyMock.eq(CONSULTERPFI_CONNECTOR_ID))).andReturn(new ConnectorResponse<ConsulterPFIReponseType, Integer>(createConsulterPFIReponseTypeResponse_NOK(null, REFCLIENT001EnvoyerDemande.INCONNU_PFI, null), 200));
    EasyMock.expect(_refClientConnector.consulterPFI(EasyMock.eq(tracabilite), EasyMock.isA(ConsulterPFIIn.class), EasyMock.eq(CONSULTERPFI_CONNECTOR_ID))).andReturn(new ConnectorResponse<ConsulterPFIReponseType, Integer>(null, 500));

    PowerMock.replayAll();

    BL1000_ConsulterRefCli iws_BL1000_ConsulterRefCli = new BL1000_ConsulterRefCliBuilder().tracabilite(tracabilite).pfsNoCompte(PFI_NOCOMPTE).msisdn(MSISDN).imsi(null).refCliConnectorId(CONSULTERPFI_CONNECTOR_ID).build();
    ConsulterPFIOut result = iws_BL1000_ConsulterRefCli.execute(new ActivityCallerTest());

    PowerMock.verifyAll();

    Assert.assertEquals(iws_BL1000_ConsulterRefCli.getRetour().getResultat(), "KO"); //$NON-NLS-1$
    Assert.assertEquals(iws_BL1000_ConsulterRefCli.getRetour().getCategorie(), IMegConsts.CAT1);
    Assert.assertEquals(iws_BL1000_ConsulterRefCli.getRetour().getDiagnostic(), Consts.SERVICE_INDISPONIBLE.toString());
    Assert.assertEquals(iws_BL1000_ConsulterRefCli.getRetour().getLibelle(), "Erreur REFCLIENT : Code HTTP =500, Raison = service indisponible  reessayer ulterieurement"); //$NON-NLS-1$
    Assert.assertNull(result);
  }

  /**
   * Consultation par MSISDN NOK avec une autre raison que DEF-2. Retourne KO/CAT-3.
   *
   * @throws RavelException
   *           exception
   */
  @Test
  public void BL1000_ConsulterRefCli_Test_ConsultByMSISDN_NOK_Autre() throws RavelException
  {
    Tracabilite tracabilite = new Tracabilite(StringConstants.EMPTY_STRING, Test_Consts.DEFAULT_MSGID, "PROF", "nomPRocessus", "idProcessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$;

    ConsulterPFIReponseType consulterPFIReponseType = createConsulterPFIReponseTypeResponse_NOK(Consts.DEF_10.toString(), "ERRCODE xxx", "DIAG_ERRCODE xxx"); //$NON-NLS-1$ //$NON-NLS-2$

    //Prepare mock
    EasyMock.expect(RefClientProxy.getInstance()).andReturn(_refClientConnector);
    EasyMock.expectLastCall().anyTimes();

    EasyMock.expect(_refClientConnector.consulterPFI(EasyMock.eq(tracabilite), EasyMock.isA(ConsulterPFIIn.class), EasyMock.eq(CONSULTERPFI_CONNECTOR_ID))).andReturn(new ConnectorResponse<ConsulterPFIReponseType, Integer>(createConsulterPFIReponseTypeResponse_NOK(null, REFCLIENT001EnvoyerDemande.INCONNU_PFI, null), 200));
    EasyMock.expect(_refClientConnector.consulterPFI(EasyMock.eq(tracabilite), EasyMock.isA(ConsulterPFIIn.class), EasyMock.eq(CONSULTERPFI_CONNECTOR_ID))).andReturn(new ConnectorResponse<ConsulterPFIReponseType, Integer>(consulterPFIReponseType, 200));

    PowerMock.replayAll();

    BL1000_ConsulterRefCli iws_BL1000_ConsulterRefCli = new BL1000_ConsulterRefCliBuilder().tracabilite(tracabilite).pfsNoCompte(PFI_NOCOMPTE).msisdn(MSISDN).imsi(null).refCliConnectorId(CONSULTERPFI_CONNECTOR_ID).build();
    ConsulterPFIOut result = iws_BL1000_ConsulterRefCli.execute(new ActivityCallerTest());

    PowerMock.verifyAll();

    Assert.assertEquals(iws_BL1000_ConsulterRefCli.getRetour().getResultat(), "KO"); //$NON-NLS-1$
    Assert.assertEquals(iws_BL1000_ConsulterRefCli.getRetour().getCategorie(), IMegConsts.CAT3);
    Assert.assertEquals(iws_BL1000_ConsulterRefCli.getRetour().getDiagnostic(), Consts.DEF_10.toString() + "/ERRCODE xxx"); //$NON-NLS-1$
    Assert.assertEquals(iws_BL1000_ConsulterRefCli.getRetour().getLibelle(), "DIAG_ERRCODE xxx"); //$NON-NLS-1$
    Assert.assertNull(result);
  }

  /**
   * Consultation par MSISDN NOK/raison DEF-2. Retourne KO/CAT-1.
   *
   * @throws RavelException
   *           exception
   */
  @Test
  public void BL1000_ConsulterRefCli_Test_ConsultByMSISDN_NOK_DEF2() throws RavelException
  {
    Tracabilite tracabilite = new Tracabilite(StringConstants.EMPTY_STRING, Test_Consts.DEFAULT_MSGID, "PROF", "nomPRocessus", "idProcessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$;

    ConsulterPFIReponseType consulterPFIReponseType = createConsulterPFIReponseTypeResponse_NOK(Consts.DEF_2.toString(), "ERRCODE_1234", "DIAG_ERRCODE_1234"); //$NON-NLS-1$ //$NON-NLS-2$

    //Prepare mock
    EasyMock.expect(RefClientProxy.getInstance()).andReturn(_refClientConnector);
    EasyMock.expectLastCall().anyTimes();

    EasyMock.expect(_refClientConnector.consulterPFI(EasyMock.eq(tracabilite), EasyMock.isA(ConsulterPFIIn.class), EasyMock.eq(CONSULTERPFI_CONNECTOR_ID))).andReturn(new ConnectorResponse<ConsulterPFIReponseType, Integer>(createConsulterPFIReponseTypeResponse_NOK(null, REFCLIENT001EnvoyerDemande.INCONNU_PFI, null), 200));
    EasyMock.expect(_refClientConnector.consulterPFI(EasyMock.eq(tracabilite), EasyMock.isA(ConsulterPFIIn.class), EasyMock.eq(CONSULTERPFI_CONNECTOR_ID))).andReturn(new ConnectorResponse<ConsulterPFIReponseType, Integer>(consulterPFIReponseType, 200));

    PowerMock.replayAll();

    BL1000_ConsulterRefCli iws_BL1000_ConsulterRefCli = new BL1000_ConsulterRefCliBuilder().tracabilite(tracabilite).pfsNoCompte(PFI_NOCOMPTE).msisdn(MSISDN).imsi(null).refCliConnectorId(CONSULTERPFI_CONNECTOR_ID).build();
    ConsulterPFIOut result = iws_BL1000_ConsulterRefCli.execute(new ActivityCallerTest());

    PowerMock.verifyAll();

    Assert.assertEquals(iws_BL1000_ConsulterRefCli.getRetour().getResultat(), "KO"); //$NON-NLS-1$
    Assert.assertEquals(iws_BL1000_ConsulterRefCli.getRetour().getCategorie(), IMegConsts.CAT1);
    Assert.assertEquals(iws_BL1000_ConsulterRefCli.getRetour().getDiagnostic(), "ERRCODE_1234"); //$NON-NLS-1$
    Assert.assertEquals(iws_BL1000_ConsulterRefCli.getRetour().getLibelle(), "DIAG_ERRCODE_1234"); //$NON-NLS-1$
    Assert.assertNull(result);
  }

  /**
   * Consultation par msisdn inexistant (NOK/INCONNU_PFI). Retourne KO/CAT-3/INCONNU_PFI.
   *
   * @throws RavelException
   *           exception
   */
  @Test
  public void BL1000_ConsulterRefCli_Test_ConsultByMSISDN_NOK_INCONNU_PFI() throws RavelException
  {
    Tracabilite tracabilite = new Tracabilite(StringConstants.EMPTY_STRING, Test_Consts.DEFAULT_MSGID, "PROF", "nomPRocessus", "idProcessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    ConsulterPFIReponseType consulterPFIReponseType = createConsulterPFIReponseTypeResponse_NOK(null, REFCLIENT001EnvoyerDemande.INCONNU_PFI, null);

    //Prepare mock
    EasyMock.expect(RefClientProxy.getInstance()).andReturn(_refClientConnector);
    EasyMock.expectLastCall().anyTimes();

    EasyMock.expect(_refClientConnector.consulterPFI(EasyMock.eq(tracabilite), EasyMock.isA(ConsulterPFIIn.class), EasyMock.eq(CONSULTERPFI_CONNECTOR_ID))).andReturn(new ConnectorResponse<ConsulterPFIReponseType, Integer>(createConsulterPFIReponseTypeResponse_NOK(null, REFCLIENT001EnvoyerDemande.INCONNU_PFI, null), 200));
    EasyMock.expect(_refClientConnector.consulterPFI(EasyMock.eq(tracabilite), EasyMock.isA(ConsulterPFIIn.class), EasyMock.eq(CONSULTERPFI_CONNECTOR_ID))).andReturn(new ConnectorResponse<ConsulterPFIReponseType, Integer>(consulterPFIReponseType, 200));

    PowerMock.replayAll();

    BL1000_ConsulterRefCli iws_BL1000_ConsulterRefCli = new BL1000_ConsulterRefCliBuilder().tracabilite(tracabilite).pfsNoCompte(PFI_NOCOMPTE).msisdn(MSISDN).imsi(null).refCliConnectorId(CONSULTERPFI_CONNECTOR_ID).build();
    ConsulterPFIOut result = iws_BL1000_ConsulterRefCli.execute(new ActivityCallerTest());

    PowerMock.verifyAll();

    Assert.assertEquals(iws_BL1000_ConsulterRefCli.getRetour().getResultat(), "KO"); //$NON-NLS-1$
    Assert.assertEquals(iws_BL1000_ConsulterRefCli.getRetour().getCategorie(), IMegConsts.CAT3);
    Assert.assertEquals(iws_BL1000_ConsulterRefCli.getRetour().getDiagnostic(), "INCONNU_PFI"); //$NON-NLS-1$
    Assert.assertEquals(iws_BL1000_ConsulterRefCli.getRetour().getLibelle(), "Erreur REFCLIENT : PFI inexistant"); //$NON-NLS-1$
    Assert.assertNull(result);
  }

  /**
   * Test OK d'une consultation par MSISDN avec le client trouvé (la recherche par PFI n'a pas permis de trouver le
   * client)
   *
   * @throws RavelException
   *           exception
   */
  @Test
  public void BL1000_ConsulterRefCli_Test_ConsultByMSISDN_OK() throws RavelException
  {
    Tracabilite tracabilite = new Tracabilite(StringConstants.EMPTY_STRING, Test_Consts.DEFAULT_MSGID, "PROF", "nomPRocessus", "idProcessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$;

    //Prepare mock
    EasyMock.expect(RefClientProxy.getInstance()).andReturn(_refClientConnector);
    EasyMock.expectLastCall().anyTimes();

    EasyMock.expect(_refClientConnector.consulterPFI(EasyMock.eq(tracabilite), EasyMock.isA(ConsulterPFIIn.class), EasyMock.eq(CONSULTERPFI_CONNECTOR_ID))).andReturn(new ConnectorResponse<ConsulterPFIReponseType, Integer>(createConsulterPFIReponseTypeResponse_NOK(null, REFCLIENT001EnvoyerDemande.INCONNU_PFI, null), 200));
    EasyMock.expect(_refClientConnector.consulterPFI(EasyMock.eq(tracabilite), EasyMock.isA(ConsulterPFIIn.class), EasyMock.eq(CONSULTERPFI_CONNECTOR_ID))).andReturn(new ConnectorResponse<ConsulterPFIReponseType, Integer>(createConsulterPFIReponseTypeBasicResponseOK(), 200));

    PowerMock.replayAll();

    BL1000_ConsulterRefCli iws_BL1000_ConsulterRefCli = new BL1000_ConsulterRefCliBuilder().tracabilite(tracabilite).pfsNoCompte(PFI_NOCOMPTE).msisdn(MSISDN).imsi(null).refCliConnectorId(CONSULTERPFI_CONNECTOR_ID).build();
    ConsulterPFIOut result = iws_BL1000_ConsulterRefCli.execute(new ActivityCallerTest());

    PowerMock.verifyAll();

    checkResponse(iws_BL1000_ConsulterRefCli.getRetour(), RetourFactoryForTU.createOkRetour());
    Assert.assertNotNull(result);
  }

  /**
   * Test KO (erreur technique) d'une consultation par PFI.
   *
   * @throws RavelException
   *           exception
   */
  @Test
  public void BL1000_ConsulterRefCli_Test_ConsultByPFI_KO_ErrTech() throws RavelException
  {
    Tracabilite tracabilite = new Tracabilite(StringConstants.EMPTY_STRING, Test_Consts.DEFAULT_MSGID, "PROF", "nomPRocessus", "idProcessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$;

    //Prepare mock
    EasyMock.expect(RefClientProxy.getInstance()).andReturn(_refClientConnector);
    EasyMock.expect(_refClientConnector.consulterPFI(EasyMock.eq(tracabilite), EasyMock.isA(ConsulterPFIIn.class), EasyMock.eq(CONSULTERPFI_CONNECTOR_ID))).andReturn(new ConnectorResponse<ConsulterPFIReponseType, Integer>(null, 500));

    PowerMock.replayAll();

    BL1000_ConsulterRefCli iws_BL1000_ConsulterRefCli = new BL1000_ConsulterRefCliBuilder().tracabilite(tracabilite).pfsNoCompte(PFI_NOCOMPTE).refCliConnectorId(CONSULTERPFI_CONNECTOR_ID).build();
    ConsulterPFIOut result = iws_BL1000_ConsulterRefCli.execute(new ActivityCallerTest());

    PowerMock.verifyAll();

    Assert.assertEquals(iws_BL1000_ConsulterRefCli.getRetour().getResultat(), "KO"); //$NON-NLS-1$
    Assert.assertEquals(iws_BL1000_ConsulterRefCli.getRetour().getCategorie(), IMegConsts.CAT1);
    Assert.assertEquals(iws_BL1000_ConsulterRefCli.getRetour().getDiagnostic(), Consts.SERVICE_INDISPONIBLE.toString());
    Assert.assertEquals(iws_BL1000_ConsulterRefCli.getRetour().getLibelle(), "Erreur REFCLIENT : Code HTTP =500, Raison = service indisponible  reessayer ulterieurement"); //$NON-NLS-1$
    Assert.assertNull(result);
  }

  /**
   * Consultation d'un PFI NOK avec une autre raison que DEF-2. Retourne KO/CAT-3.
   *
   * @throws RavelException
   *           exception
   */
  @Test
  public void BL1000_ConsulterRefCli_Test_ConsultByPFI_NOK_Autre() throws RavelException
  {
    Tracabilite tracabilite = new Tracabilite(StringConstants.EMPTY_STRING, Test_Consts.DEFAULT_MSGID, "PROF", "nomPRocessus", "idProcessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$;
    ConsulterPFIReponseType consulterPFIReponseType = createConsulterPFIReponseTypeResponse_NOK(Consts.DEF_10.toString(), "ERRCODE xxx", "DIAG_ERRCODE xxx"); //$NON-NLS-1$ //$NON-NLS-2$

    //Prepare mock
    EasyMock.expect(RefClientProxy.getInstance()).andReturn(_refClientConnector);

    EasyMock.expect(_refClientConnector.consulterPFI(EasyMock.eq(tracabilite), EasyMock.isA(ConsulterPFIIn.class), EasyMock.eq(CONSULTERPFI_CONNECTOR_ID))).andReturn(new ConnectorResponse<ConsulterPFIReponseType, Integer>(consulterPFIReponseType, 200));

    PowerMock.replayAll();

    BL1000_ConsulterRefCli iws_BL1000_ConsulterRefCli = new BL1000_ConsulterRefCliBuilder().tracabilite(tracabilite).pfsNoCompte(PFI_NOCOMPTE).refCliConnectorId(CONSULTERPFI_CONNECTOR_ID).build();
    ConsulterPFIOut result = iws_BL1000_ConsulterRefCli.execute(new ActivityCallerTest());

    PowerMock.verifyAll();

    Assert.assertEquals(iws_BL1000_ConsulterRefCli.getRetour().getResultat(), "KO"); //$NON-NLS-1$
    Assert.assertEquals(iws_BL1000_ConsulterRefCli.getRetour().getCategorie(), IMegConsts.CAT3);
    Assert.assertEquals(iws_BL1000_ConsulterRefCli.getRetour().getDiagnostic(), Consts.DEF_10.toString() + "/ERRCODE xxx"); //$NON-NLS-1$
    Assert.assertEquals(iws_BL1000_ConsulterRefCli.getRetour().getLibelle(), "DIAG_ERRCODE xxx"); //$NON-NLS-1$
    Assert.assertNull(result);
  }

  /**
   * Consultation d'un PFI NOK/raison DEF-2. Retourne KO/CAT-1.
   *
   * @throws RavelException
   *           exception
   */
  @Test
  public void BL1000_ConsulterRefCli_Test_ConsultByPFI_NOK_DEF2() throws RavelException
  {
    Tracabilite tracabilite = new Tracabilite(StringConstants.EMPTY_STRING, Test_Consts.DEFAULT_MSGID, "PROF", "nomPRocessus", "idProcessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$;
    ConsulterPFIReponseType consulterPFIReponseType = createConsulterPFIReponseTypeResponse_NOK(Consts.DEF_2.toString(), "ERRCODE_1234", "DIAG_ERRCODE_1234"); //$NON-NLS-1$ //$NON-NLS-2$

    //Prepare mock
    EasyMock.expect(RefClientProxy.getInstance()).andReturn(_refClientConnector);

    EasyMock.expect(_refClientConnector.consulterPFI(EasyMock.eq(tracabilite), EasyMock.isA(ConsulterPFIIn.class), EasyMock.eq(CONSULTERPFI_CONNECTOR_ID))).andReturn(new ConnectorResponse<ConsulterPFIReponseType, Integer>(consulterPFIReponseType, 200));

    PowerMock.replayAll();

    BL1000_ConsulterRefCli iws_BL1000_ConsulterRefCli = new BL1000_ConsulterRefCliBuilder().tracabilite(tracabilite).pfsNoCompte(PFI_NOCOMPTE).refCliConnectorId(CONSULTERPFI_CONNECTOR_ID).build();
    ConsulterPFIOut result = iws_BL1000_ConsulterRefCli.execute(new ActivityCallerTest());

    PowerMock.verifyAll();

    Assert.assertEquals(iws_BL1000_ConsulterRefCli.getRetour().getResultat(), "KO"); //$NON-NLS-1$
    Assert.assertEquals(iws_BL1000_ConsulterRefCli.getRetour().getCategorie(), IMegConsts.CAT1);
    Assert.assertEquals(iws_BL1000_ConsulterRefCli.getRetour().getDiagnostic(), "ERRCODE_1234"); //$NON-NLS-1$
    Assert.assertEquals(iws_BL1000_ConsulterRefCli.getRetour().getLibelle(), "DIAG_ERRCODE_1234"); //$NON-NLS-1$
    Assert.assertNull(result);
  }

  /**
   * Consultation d'un PFI inexistant (NOK/INCONNU_PFI). Retourne KO/CAT-3/INCONNU_PFI.
   *
   * @throws RavelException
   *           exception
   */
  @Test
  public void BL1000_ConsulterRefCli_Test_ConsultByPFI_NOK_INCONNU_PFI() throws RavelException
  {
    Tracabilite tracabilite = new Tracabilite(StringConstants.EMPTY_STRING, Test_Consts.DEFAULT_MSGID, "PROF", "nomPRocessus", "idProcessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$;

    ConsulterPFIReponseType consulterPFIReponseType = createConsulterPFIReponseTypeResponse_NOK(null, REFCLIENT001EnvoyerDemande.INCONNU_PFI, null);

    //Prepare mock
    EasyMock.expect(RefClientProxy.getInstance()).andReturn(_refClientConnector);

    EasyMock.expect(_refClientConnector.consulterPFI(EasyMock.eq(tracabilite), EasyMock.isA(ConsulterPFIIn.class), EasyMock.eq(CONSULTERPFI_CONNECTOR_ID))).andReturn(new ConnectorResponse<ConsulterPFIReponseType, Integer>(consulterPFIReponseType, 200));

    PowerMock.replayAll();

    BL1000_ConsulterRefCli iws_BL1000_ConsulterRefCli = new BL1000_ConsulterRefCliBuilder().tracabilite(tracabilite).pfsNoCompte(PFI_NOCOMPTE).refCliConnectorId(CONSULTERPFI_CONNECTOR_ID).build();
    ConsulterPFIOut result = iws_BL1000_ConsulterRefCli.execute(new ActivityCallerTest());

    PowerMock.verifyAll();

    Assert.assertEquals(iws_BL1000_ConsulterRefCli.getRetour().getResultat(), "KO"); //$NON-NLS-1$
    Assert.assertEquals(iws_BL1000_ConsulterRefCli.getRetour().getCategorie(), IMegConsts.CAT3);
    Assert.assertEquals(iws_BL1000_ConsulterRefCli.getRetour().getDiagnostic(), "INCONNU_PFI"); //$NON-NLS-1$
    Assert.assertEquals(iws_BL1000_ConsulterRefCli.getRetour().getLibelle(), "Erreur REFCLIENT : PFI inexistant"); //$NON-NLS-1$
    Assert.assertNull(result);
  }

  /**
   * Test OK d'une consultation par PFI avec le client trouvé.
   *
   * @throws RavelException
   *           exception
   */
  @Test
  public void BL1000_ConsulterRefCli_Test_ConsultByPFI_OK() throws RavelException
  {
    Tracabilite tracabilite = new Tracabilite(StringConstants.EMPTY_STRING, Test_Consts.DEFAULT_MSGID, "PROF", "nomPRocessus", "idProcessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$;

    ConsulterPFIReponseType consulterPFIReponseType = createConsulterPFIReponseTypeBasicResponseOK();

    //Prepare mock
    EasyMock.expect(RefClientProxy.getInstance()).andReturn(_refClientConnector);

    EasyMock.expect(_refClientConnector.consulterPFI(EasyMock.eq(tracabilite), EasyMock.isA(ConsulterPFIIn.class), EasyMock.eq(CONSULTERPFI_CONNECTOR_ID))).andReturn(new ConnectorResponse<ConsulterPFIReponseType, Integer>(consulterPFIReponseType, 200));

    PowerMock.replayAll();

    BL1000_ConsulterRefCli iws_BL1000_ConsulterRefCli = new BL1000_ConsulterRefCliBuilder().tracabilite(tracabilite).pfsNoCompte(PFI_NOCOMPTE).refCliConnectorId(CONSULTERPFI_CONNECTOR_ID).build();
    ConsulterPFIOut result = iws_BL1000_ConsulterRefCli.execute(new ActivityCallerTest());

    PowerMock.verifyAll();

    checkResponse(iws_BL1000_ConsulterRefCli.getRetour(), RetourFactoryForTU.createOkRetour());
    Assert.assertNotNull(result);
  }

  /**
   * Checks if two <code>Retour</code> objects are equal.
   *
   * @param expected_p
   *          expected <code>Retour</code> object
   * @param actual_p
   *          actual <code>Retour</code> object
   */
  private void checkResponse(Retour expected_p, Retour actual_p)
  {
    Assert.assertEquals(expected_p.getResultat(), actual_p.getResultat());
    Assert.assertEquals(expected_p.getCategorie(), actual_p.getCategorie());
    Assert.assertEquals(expected_p.getDiagnostic(), actual_p.getDiagnostic());
    Assert.assertEquals(expected_p.getLibelle(), actual_p.getLibelle());
  }
}
