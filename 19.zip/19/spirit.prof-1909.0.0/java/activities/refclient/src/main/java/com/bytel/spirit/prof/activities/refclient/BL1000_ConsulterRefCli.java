/*******************************************************************************
* $Id: BL1000_ConsulterRefCli.java 35893 2017-05-15 11:08:45Z fcabral $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.prof.activities.refclient;

import java.text.MessageFormat;

import com.bouygtel.refcli.consulterpfi.in.ConsulterPFIIn;
import com.bouygtel.refcli.consulterpfi.out.ConsulterPFIOut;
import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.services.aspectJ.LogActivity;
import com.bytel.ravel.services.connector.tools.MSISDNTools;
import com.bytel.ravel.services.process.IActivityCaller;
import com.bytel.ravel.services.process.activity.BuiltActivityContext;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.Consts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.prof.connectors.refclient.meg.REFCLIENT001EnvoyerDemande;
import com.bytel.spirit.prof.connectors.refclient.meg.REFCLIENT001EnvoyerDemande.REFCLIENT001EnvoyerDemandeBuilder;

/**
 * Activité de consultation RefCli à partir d'un PFS NoCompte, d'un msisdn et d'un imsi.
 *
 * @author lchanyip
 * @version ($Revision: 35893 $ $Date: 2017-05-15 13:08:45 +0200 (lun., 15 mai 2017) $)
 */
public class BL1000_ConsulterRefCli extends BuiltActivityContext<ConsulterPFIOut>
{
  /**
   *
   * @author lmerces
   * @version ($Revision$ $Date$)
   */
  public final static class BL1000_ConsulterRefCliBuilder
  {
    /**
     * object to build
     */
    BL1000_ConsulterRefCli _builder;

    /**
     * The constructor
     */
    public BL1000_ConsulterRefCliBuilder()
    {
      _builder = new BL1000_ConsulterRefCli();
    }

    /**
     * @return BL1000_ConsulterRefCli
     */
    public BL1000_ConsulterRefCli build()
    {
      if ((_builder.getTracabilite() == null) || (_builder.getPfsNoCompte() == null) || (_builder.getRefCliConnector() == null))
      {
        // PARAMETRE INVALIDE
        Retour retour = RetourFactory.createKO(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, "Parametre d'entree de l'activite non renseignee"); //$NON-NLS-1$
        _builder.setRetour(retour);
      }
      return _builder;
    }

    /**
     * @param imsi_p
     *          imsi
     * @return BL1000_ConsulterRefCliBuilder
     */
    public BL1000_ConsulterRefCliBuilder imsi(String imsi_p)
    {
      _builder.setImsi(imsi_p);
      return this;
    }

    /**
     * @param msisdn_p
     *          msisdn
     * @return BL1000_ConsulterRefCliBuilder
     */
    public BL1000_ConsulterRefCliBuilder msisdn(String msisdn_p)
    {
      _builder.setMsisdn(msisdn_p);
      return this;
    }

    /**
     * @param pfsNoCompte_p
     *          The pfs no compte
     * @return BL1000_ConsulterRefCliBuilder
     */
    public BL1000_ConsulterRefCliBuilder pfsNoCompte(String pfsNoCompte_p)
    {
      _builder.setPfsNoCompte(pfsNoCompte_p);
      return this;
    }

    /**
     * @param refCliConnectorId_p
     *          imsi
     * @return BL1000_ConsulterRefCliBuilder
     */
    public BL1000_ConsulterRefCliBuilder refCliConnectorId(String refCliConnectorId_p)
    {
      _builder.setRefCliConnector(refCliConnectorId_p);
      return this;
    }

    /**
     * @param tracabilite_p
     *          The tracability
     * @return BL1000_ConsulterRefCliBuilder
     */
    public BL1000_ConsulterRefCliBuilder tracabilite(Tracabilite tracabilite_p)
    {
      _builder.setTracabilite(tracabilite_p);
      return this;
    }
  }

  /**
   * Definition of all execution steps.
   *
   * @author lchanyip
   * @version ($Revision: 35893 $ $Date: 2017-05-15 13:08:45 +0200 (lun., 15 mai 2017) $)
   */
  private enum Step
  {
    /**
     * first step to execute.
     */
    First,

    /**
     * if all steps have been executed.
     */
    End
  }

  /**
   *
   */
  private static final long serialVersionUID = -5473593332499266141L;

  /**
   * PFS NoCompte
   */
  private String _pfsNoCompte;

  /**
   * msisdn
   */
  private String _msisdn;

  /**
   * imsi
   */
  private String _imsi;

  /**
   * connector id
   */
  private String _refCliConnector;

  /**
   * Contains the new step to execute
   */
  private Step _nextStep = Step.First;

  /**
   * the msgId
   */
  private Tracabilite _tracabilite;

  @Override
  @LogActivity
  public ConsulterPFIOut executeNextStep(IActivityCaller callingProcess_p) throws RavelException
  {
    ConsulterPFIOut response = null;
    // Always use a switch/case to define and to chain all steps to execute !
    // Chaining two steps is done by updating the _nextStep variable.
    switch (_nextStep)
    {
      case First:
        response = consulterRefCli(callingProcess_p);
        _nextStep = Step.End;
        break;
      default:
        break;
    }

    return response;
  }

  /**
   * @return the imsi
   */
  public String getImsi()
  {
    return _imsi;
  }

  /**
   * @return the msisdn
   */
  public String getMsisdn()
  {
    return _msisdn;
  }

  /**
   * @return the pfsNoCompte
   */
  public String getPfsNoCompte()
  {
    return _pfsNoCompte;
  }

  /**
   * @return the refCliConnector
   */
  public String getRefCliConnector()
  {
    return _refCliConnector;
  }

  /**
   * @return the tracabilite
   */
  public Tracabilite getTracabilite()
  {
    return _tracabilite;
  }

  @Override
  public boolean isEndStep()
  {
    return _nextStep == Step.End;
  }

  /**
   * @param imsi_p
   *          the imsi to set
   */
  public void setImsi(String imsi_p)
  {
    _imsi = imsi_p;
  }

  /**
   * @param msisdn_p
   *          the msisdn to set
   */
  public void setMsisdn(String msisdn_p)
  {
    _msisdn = msisdn_p;
  }

  /**
   * @param pfsNoCompte_p
   *          the pfsNoCompte to set
   */
  public void setPfsNoCompte(String pfsNoCompte_p)
  {
    _pfsNoCompte = pfsNoCompte_p;
  }

  /**
   * @param refCliConnector_p
   *          the refCliConnector to set
   */
  public void setRefCliConnector(String refCliConnector_p)
  {
    _refCliConnector = refCliConnector_p;
  }

  /**
   * @param tracabilite_p
   *          the tracabilite to set
   */
  public void setTracabilite(Tracabilite tracabilite_p)
  {
    _tracabilite = tracabilite_p;
  }

  /**
   * Consultation par IMSI
   *
   * @param callingProcess_p
   *          process appelant
   * @return un objet ConsulterPFIOut
   * @throws RavelException
   *           en cas d'erreur inattendue
   */
  private ConsulterPFIOut consultByImsi(IActivityCaller callingProcess_p) throws RavelException
  {
    RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, _tracabilite, MessageFormat.format(Messages.getString("BL1000_ConsulterRefCli.ConsultationMsg"), "IMSI", _imsi))); //$NON-NLS-1$ //$NON-NLS-2$

    ConsulterPFIIn consulterPFIInByImsi = new ConsulterPFIIn();
    com.bouygtel.refcli.consulterpfi.in.SimLogique sl = new com.bouygtel.refcli.consulterpfi.in.SimLogique();
    sl.setImsi(_imsi);
    consulterPFIInByImsi.setSimLogique(sl);

    REFCLIENT001EnvoyerDemande envoyerDemandeREFCLIENT = new REFCLIENT001EnvoyerDemandeBuilder().tracabilite(_tracabilite).consulterPFIIn(consulterPFIInByImsi).connectorId(_refCliConnector).build();
    ConsulterPFIOut response = envoyerDemandeREFCLIENT.execute(callingProcess_p);
    setRetour(envoyerDemandeREFCLIENT.getRetour());
    return response;
  }

  /**
   * Consultation par MSISDN
   *
   * @param callingProcess_p
   *          process appelant
   * @return un objet ConsulterPFIOut
   * @throws RavelException
   *           en cas d'erreur inattendue
   */
  private ConsulterPFIOut consultByMsisdn(IActivityCaller callingProcess_p) throws RavelException
  {
    RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, _tracabilite, MessageFormat.format(Messages.getString("BL1000_ConsulterRefCli.ConsultationMsg"), "MSISDN", _msisdn))); //$NON-NLS-1$ //$NON-NLS-2$

    ConsulterPFIIn consulterPFIInByMsisdn = new ConsulterPFIIn();
    com.bouygtel.refcli.consulterpfi.in.Msisdn msisdn = new com.bouygtel.refcli.consulterpfi.in.Msisdn();
    msisdn.setMsisdn(MSISDNTools.convertTo11(_msisdn));
    consulterPFIInByMsisdn.setMsisdn(msisdn);

    REFCLIENT001EnvoyerDemande envoyerDemandeREFCLIENT = new REFCLIENT001EnvoyerDemandeBuilder().tracabilite(_tracabilite).consulterPFIIn(consulterPFIInByMsisdn).connectorId(_refCliConnector).build();
    ConsulterPFIOut response = envoyerDemandeREFCLIENT.execute(callingProcess_p);
    setRetour(envoyerDemandeREFCLIENT.getRetour());
    return response;
  }

  /**
   * Consultation par PFI
   *
   * @param callingProcess_p
   *          process appelant
   * @return un objet ConsulterPFIOut
   * @throws RavelException
   *           en cas d'erreur inattendue
   */
  private ConsulterPFIOut consultByPfi(IActivityCaller callingProcess_p) throws RavelException
  {
    RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, _tracabilite, MessageFormat.format(Messages.getString("BL1000_ConsulterRefCli.ConsultationMsg"), "PFI", _pfsNoCompte))); //$NON-NLS-1$ //$NON-NLS-2$

    ConsulterPFIIn consulterPFIInByPfi = new ConsulterPFIIn();
    com.bouygtel.refcli.consulterpfi.in.PortefeuilleIndividuel pfi = new com.bouygtel.refcli.consulterpfi.in.PortefeuilleIndividuel();
    pfi.setNoCompte(_pfsNoCompte);
    consulterPFIInByPfi.setPortefeuilleIndividuel(pfi);

    REFCLIENT001EnvoyerDemande envoyerDemandeREFCLIENT = new REFCLIENT001EnvoyerDemandeBuilder().tracabilite(_tracabilite).consulterPFIIn(consulterPFIInByPfi).connectorId(_refCliConnector).build();
    ConsulterPFIOut response = envoyerDemandeREFCLIENT.execute(callingProcess_p);
    setRetour(envoyerDemandeREFCLIENT.getRetour());
    return response;
  }

  /**
   * Consultation du client sur le refcli
   *
   * @param callingProcess_p
   *          calling process
   * @return un objet ConsulterPFIOut
   */
  private ConsulterPFIOut consulterRefCli(IActivityCaller callingProcess_p)
  {
    Retour defaultRetourKO = RetourFactory.createKO(IMegConsts.CAT1, Consts.SERVICE_INDISPONIBLE.toString(), "Unexpected error"); //$NON-NLS-1$
    setRetour(defaultRetourKO);

    ConsulterPFIOut response = null;
    try
    {
      //Consultation par PFSNocompte en premier
      response = consultByPfi(callingProcess_p);
      if (StringConstants.OK.equals(getRetour().getResultat()))
      {
        //client trouvé
        return response;
      }

      //ici, retour KO
      if (REFCLIENT001EnvoyerDemande.INCONNU_PFI.equals(getRetour().getDiagnostic()))
      {
        if (_msisdn != null)
        {
          RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, _tracabilite, MessageFormat.format(Messages.getString("BL1000_ConsulterRefCli.ClientIntrouvableMsg"), "pfi", "msisdn"))); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
          return returnConsultByMsisdn(callingProcess_p);
        }
        else if (_imsi != null)
        {
          RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, _tracabilite, MessageFormat.format(Messages.getString("BL1000_ConsulterRefCli.ClientIntrouvableMsg"), "pfi", "imsi"))); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
          return consultByImsi(callingProcess_p);
        }
        else
        {
          return response;
        }
      }

      // ici, si on a autre chose que INCONNU_PFI, on retourne le retour KO
      return null;
    }
    catch (RavelException exception)
    {
      //impossible
      exception.printStackTrace();
    }

    return response;
  }

  /**
   * Return pair du ConsultByMsisdn
   *
   * @param callingProcess_p
   *          calling process
   * @return un objet ConsulterPFIOut
   */
  private ConsulterPFIOut returnConsultByMsisdn(IActivityCaller callingProcess_p)
  {
    Retour defaultRetourKO = RetourFactory.createKO(IMegConsts.CAT1, Consts.SERVICE_INDISPONIBLE.toString(), "Unexpected error"); //$NON-NLS-1$
    setRetour(defaultRetourKO);
    ConsulterPFIOut response = null;
    try
    {
      response = consultByMsisdn(callingProcess_p);

      if (StringConstants.OK.equals(getRetour().getResultat()))
      {
        //client trouvé
        return response;
      }

      //ici, retour KO
      if (REFCLIENT001EnvoyerDemande.INCONNU_PFI.equals(getRetour().getDiagnostic()))
      {
        RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, _tracabilite, MessageFormat.format(Messages.getString("BL1000_ConsulterRefCli.ClientIntrouvableMsg"), "msisdn", "imsi"))); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

        if (_imsi != null)
        {
          return consultByImsi(callingProcess_p);
        }
        return response;
      }
    }
    catch (RavelException exception)
    {
      exception.printStackTrace();
    }
    //ici, si on a autre chose que INCONNU_PFI, on retourne le retour KO
    return null;
  }
}
