/*******************************************************************************
 * $Id: Messages.java 35091 2017-04-07 12:24:59Z vloureir $
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.prof.activities.refclient;

import java.util.MissingResourceException;
import java.util.ResourceBundle;

/**
 *
 *
 * @author lchanyip
 * @version ($Revision: 35091 $ $Date: 2017-04-07 14:24:59 +0200 (ven., 07 avr. 2017) $)
 */
public class Messages
{
  /**
   * the BUNDLE_NAME.
   */
  private static final String BUNDLE_NAME = "com.bytel.spirit.prof.activities.refclient.messages"; //$NON-NLS-1$

  /**
   * the RESOURCE_BUNDLE.
   */
  private static final ResourceBundle RESOURCE_BUNDLE = ResourceBundle.getBundle(BUNDLE_NAME);

  /**
   * get the value.
   *
   * @param key
   *          the key
   * @return the value
   */
  public static String getString(String key)
  {
    try
    {
      return RESOURCE_BUNDLE.getString(key);
    }
    catch (MissingResourceException e)
    {
      return '!' + key + '!';
    }
  }

  /**
   * Default constructor.
   */
  private Messages()
  {
  }
}
