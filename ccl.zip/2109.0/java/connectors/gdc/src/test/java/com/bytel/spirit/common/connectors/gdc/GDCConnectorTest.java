/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.gdc;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLRecoverableException;
import java.sql.SQLTimeoutException;
import java.util.List;

import org.apache.tomcat.jdbc.pool.DataSource;
import org.apache.tomcat.jdbc.pool.PoolExhaustedException;
import org.apache.tomcat.jdbc.pool.PoolProperties;
import org.easymock.Capture;
import org.easymock.EasyMock;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockNice;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.conf.generated.Param;
import com.bytel.ravel.common.encryption.DESKeyManager;
import com.bytel.ravel.common.encryption.PasswordDecrypter;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.services.conf.connector.generated.Connector;
import com.bytel.ravel.services.connector.AbstractDBConnector;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.shared.functional.types.functional.mediaBox.PfeSvc;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author mbaptist
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({ DESKeyManager.class, PasswordDecrypter.class, Connection.class, DataSource.class, AbstractDBConnector.class, CallableStatement.class })
@PowerMockIgnore("javax.management.*")
public class GDCConnectorTest
{
  /**
   * t READ_TIMEOUT_SEC value
   */
  private static final int READ_TIMEOUT_SEC = 20;

  /**
   * READ_TIMEOUT_SEC_UDC value
   */
  private static final int READ_TIMEOUT_SEC_UDC = 1800;

  /**
   * Standard parameter name in PS call for Resultat.
   */
  private static final String RETOUR_RESULTAT = "Retour_Resultat"; //$NON-NLS-1$

  /**
   * Standard parameter name in PS call for Libelle.
   */
  public static final String RETOUR_LIBELLE = "Retour_Libelle"; //$NON-NLS-1$
  /**
   * Standard parameter name in PS call for Diagnostic.
   */
  public static final String RETOUR_DIAGNOSTIC = "Retour_Diagnostic"; //$NON-NLS-1$

  /**
   * Standard parameter name in PS call for Categorie.
   */
  public static final String RETOUR_CATEGORIE = "Retour_Categorie"; //$NON-NLS-1$

  /**
   * Holds the configuration for the current connector
   */
  private static Connector _connectorConfig;

  /**
   * Datasource mock
   */
  @MockNice
  DataSource _datasource;

  /**
   * Connection mock
   */
  @MockNice
  Connection _connection;

  /**
   * CallableStatement mock
   */
  @MockNice
  CallableStatement _callableStatement;

  /**
   * Manages the DES encryption keys and features
   */

  /**
   * ResultSet mock
   */
  @MockNice
  ResultSet _resultSet;

  /**
   * Current connector
   */
  private GDCConnector _connector;

  //  @SuppressWarnings("unused")
  //  private static DESKeyManager _desKeyManager;

  /**
   * Connector instance
   */
  private GDCConnector _gdcConnector;

  /**
   * Factory to generate beans
   */
  private PodamFactory _podam = new PodamFactoryImpl();

  /**
   * @throws Exception
   */
  @Before
  public void setup() throws Exception
  {
    _connector = new GDCConnector();

    _connectorConfig = new Connector();

    _connectorConfig.setName("GDCConnector"); //$NON-NLS-1$
    _connectorConfig.setType("client"); //$NON-NLS-1$
    _connectorConfig.setClazz("com.bytel.ressources.services.connector.gdc.GDCConnector"); //$NON-NLS-1$
    _connectorConfig.setEnabled(true);
    Param dbConnectionString = new Param();
    Param dbUsername = new Param();
    Param dbPassword = new Param();
    Param poolSize = new Param();
    Param connectTimeoutSec = new Param();
    Param readTimeoutSec = new Param();

    dbConnectionString.setName("DB_CONNECTIONSTRING"); //$NON-NLS-1$
    dbConnectionString.setValue("jdbc:oracle:thin:@172.22.76.129:1531:PPR0N0D3"); //$NON-NLS-1$
    dbUsername.setName("DB_USERNAME"); //$NON-NLS-1$
    dbUsername.setValue("DEV14GDC"); //$NON-NLS-1$
    dbPassword.setName("DB_PASSWORD"); //$NON-NLS-1$
    dbPassword.setValue("nO118qBYuJEgsoOMyJ3uHw=="); //$NON-NLS-1$
    poolSize.setName("POOLSIZE"); //$NON-NLS-1$
    poolSize.setValue("15"); //$NON-NLS-1$
    connectTimeoutSec.setName("CONNECT_TIMEOUT_SEC"); //$NON-NLS-1$
    connectTimeoutSec.setValue("4"); //$NON-NLS-1$
    readTimeoutSec.setName("READ_TIMEOUT_SEC"); //$NON-NLS-1$
    readTimeoutSec.setValue("1"); //$NON-NLS-1$

    _connectorConfig.getParam().add(dbConnectionString);
    _connectorConfig.getParam().add(dbUsername);
    _connectorConfig.getParam().add(dbPassword);
    _connectorConfig.getParam().add(poolSize);
    _connectorConfig.getParam().add(connectTimeoutSec);
    _connectorConfig.getParam().add(readTimeoutSec);

    PowerMock.resetAll();
    PowerMock.mockStaticNice(PasswordDecrypter.class);
    PowerMock.mockStaticNice(DESKeyManager.class);

    EasyMock.expect(PasswordDecrypter.decrypt("0l7HRwWTfUwgsoOMyJ3uHw==")).andReturn("DEVPWD").anyTimes(); //$NON-NLS-1$ //$NON-NLS-2$
    PowerMock.replay(PasswordDecrypter.class);

    // Setup connection mock
    PowerMock.expectNew(DataSource.class, EasyMock.anyObject(PoolProperties.class)).andReturn(_datasource);
    EasyMock.expect(_datasource.getConnection()).andReturn(_connection).anyTimes();
    PowerMock.replay(DataSource.class);
    PowerMock.replay(_datasource);

    // Load config
    _connector.loadConnectorConfiguration(_connectorConfig);
  }

  /**
   * Cas non Nominal
   *
   * @throws RavelException
   *           exception
   * @throws SQLTimeOutException
   */
  @Test
  public void test_checkPfiMigre_1() throws RavelException, SQLException
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    _gdcConnector = new GDCConnector();
    String pfi = "1109813914224"; //$NON-NLS-1$

    // Setup statement mock
    Capture<String> pfi_capture = Capture.newInstance();

    EasyMock.expect(_connection.prepareCall(String.format("{call %s(?,?,?,?,?,?) }", "PG_IWSRESSOURCES.P_002_CHECK_PFI_MIGRE"))).andReturn(_callableStatement); //$NON-NLS-1$ //$NON-NLS-2$
    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    EasyMock.expectLastCall();

    _callableStatement.setString(EasyMock.eq("pfi_p"), EasyMock.capture(pfi_capture)); //$NON-NLS-1$
    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.execute()).andThrow(new SQLTimeoutException("Something terrible happened")); //$NON-NLS-1$

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<Boolean, Retour> response = _connector.checkPfiMigre(tracabilite, pfi);

    // Asserts

    //Assert.assertFalse(response._first);

    Assert.assertEquals("KO", response._second.getResultat()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, response._second.getCategorie());
    assertNotNull(response._second.getLibelle());
    assertEquals("SELECT_FAILED", response._second.getDiagnostic()); //$NON-NLS-1$
  }

  /**
   * Cas non Nominal
   *
   * @throws RavelException
   *           exception
   * @throws PoolExhaustedException
   */
  @Test
  public void test_checkPfiMigre_2() throws RavelException, SQLException
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    _gdcConnector = new GDCConnector();
    String pfi = "1109813914224"; //$NON-NLS-1$

    // Setup statement mock
    Capture<String> pfi_capture = Capture.newInstance();

    EasyMock.expect(_connection.prepareCall(String.format("{call %s(?,?,?,?,?,?) }", "PG_IWSRESSOURCES.P_002_CHECK_PFI_MIGRE"))).andReturn(_callableStatement); //$NON-NLS-1$ //$NON-NLS-2$
    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    EasyMock.expectLastCall();

    _callableStatement.setString(EasyMock.eq("pfi_p"), EasyMock.capture(pfi_capture)); //$NON-NLS-1$
    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.execute()).andThrow(new PoolExhaustedException("Something terrible happened")); //$NON-NLS-1$

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<Boolean, Retour> response = _connector.checkPfiMigre(tracabilite, pfi);

    // Asserts

    //Assert.assertFalse(response._first);

    Assert.assertEquals("KO", response._second.getResultat()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, response._second.getCategorie());
    assertNotNull(response._second.getLibelle());
    assertEquals("SESSION_UNAVAILABLE", response._second.getDiagnostic()); //$NON-NLS-1$
  }

  /**
   * Cas non Nominal
   *
   * @throws RavelException
   *           exception
   * @throws SQLRecoverableException
   */
  @Test
  public void test_checkPfiMigre_3() throws RavelException, SQLException
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    _gdcConnector = new GDCConnector();
    String pfi = "1109813914224"; //$NON-NLS-1$

    // Setup statement mock
    Capture<String> pfi_capture = Capture.newInstance();

    EasyMock.expect(_connection.prepareCall(String.format("{call %s(?,?,?,?,?,?) }", "PG_IWSRESSOURCES.P_002_CHECK_PFI_MIGRE"))).andReturn(_callableStatement); //$NON-NLS-1$ //$NON-NLS-2$
    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    EasyMock.expectLastCall();

    _callableStatement.setString(EasyMock.eq("pfi_p"), EasyMock.capture(pfi_capture)); //$NON-NLS-1$
    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.execute()).andThrow(new SQLRecoverableException("Something terrible happened")); //$NON-NLS-1$

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<Boolean, Retour> response = _connector.checkPfiMigre(tracabilite, pfi);

    // Asserts

    //Assert.assertFalse(response._first);

    Assert.assertEquals("KO", response._second.getResultat()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, response._second.getCategorie());
    assertNotNull(response._second.getLibelle());
    assertEquals("CONNEXION_FAILED", response._second.getDiagnostic()); //$NON-NLS-1$
  }

  /**
   * Cas Nominal returns False
   *
   * @throws RavelException
   *           exception
   * @throws SQLException
   */
  @Test
  public void test_checkPfiMigre_KO() throws RavelException, SQLException
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    _gdcConnector = new GDCConnector();
    String pfi = "1109813914224"; //$NON-NLS-1$

    // Setup statement mock
    Capture<String> pfi_capture = Capture.newInstance();

    EasyMock.expect(_connection.prepareCall(String.format("{call %s(?,?,?,?,?,?) }", "PG_IWSRESSOURCES.P_002_CHECK_PFI_MIGRE"))).andReturn(_callableStatement); //$NON-NLS-1$ //$NON-NLS-2$
    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    EasyMock.expectLastCall();

    _callableStatement.setString(EasyMock.eq("pfi_p"), EasyMock.capture(pfi_capture)); //$NON-NLS-1$
    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.getString(RETOUR_RESULTAT)).andReturn("KO"); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString(RETOUR_CATEGORIE)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_DIAGNOSTIC)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_LIBELLE)).andReturn(null);

    EasyMock.expect(_callableStatement.getObject("po_RESULT")).andReturn(false); //$NON-NLS-1$

    EasyMock.expect(_resultSet.next()).andReturn(true);

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<Boolean, Retour> response = _connector.checkPfiMigre(tracabilite, pfi);

    // Asserts
    Boolean resultat = response._first;

    Assert.assertFalse(resultat);

    Assert.assertEquals("KO", response._second.getResultat()); //$NON-NLS-1$
    assertEquals(null, response._second.getCategorie());
    assertEquals(null, response._second.getLibelle());
    assertEquals(null, response._second.getDiagnostic());
  }

  /**
   * Cas Nominal returns True
   *
   * @throws RavelException
   *           exception
   * @throws SQLException
   */
  @Test
  public void test_checkPfiMigre_OK() throws RavelException, SQLException
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    _gdcConnector = new GDCConnector();
    String pfi = "1109813914224"; //$NON-NLS-1$

    // Setup statement mock
    Capture<String> pfi_capture = Capture.newInstance();

    EasyMock.expect(_connection.prepareCall(String.format("{call %s(?,?,?,?,?,?) }", "PG_IWSRESSOURCES.P_002_CHECK_PFI_MIGRE"))).andReturn(_callableStatement); //$NON-NLS-1$ //$NON-NLS-2$
    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    EasyMock.expectLastCall();

    _callableStatement.setString(EasyMock.eq("pfi_p"), EasyMock.capture(pfi_capture)); //$NON-NLS-1$
    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.getString(RETOUR_RESULTAT)).andReturn("OK"); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString(RETOUR_CATEGORIE)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_DIAGNOSTIC)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_LIBELLE)).andReturn(null);

    EasyMock.expect(_callableStatement.getObject("po_RESULT")).andReturn(true); //$NON-NLS-1$

    EasyMock.expect(_resultSet.next()).andReturn(true);

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<Boolean, Retour> response = _connector.checkPfiMigre(tracabilite, pfi);

    // Asserts
    Boolean resultat = response._first;

    Assert.assertTrue(resultat);

    Assert.assertEquals("OK", response._second.getResultat()); //$NON-NLS-1$
    assertEquals(null, response._second.getCategorie());
    assertEquals(null, response._second.getLibelle());
    assertEquals(null, response._second.getDiagnostic());
  }

  /**
   * Cas Nominal
   *
   * @throws RavelException
   *           exception
   * @throws SQLException
   */
  @Test
  public void test_ps001ConsultListePfFromPfi() throws RavelException, SQLException
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    _gdcConnector = new GDCConnector();
    String pfi = "1109813914224"; //$NON-NLS-1$

    // Setup statement mock
    Capture<String> pfi_capture = Capture.newInstance();

    EasyMock.expect(_connection.prepareCall(String.format("{call %s(?,?,?,?,?,?) }", "PG_IWSRESSOURCES.P_001_GET_LISTEPF_FROM_PFI"))).andReturn(_callableStatement); //$NON-NLS-1$ //$NON-NLS-2$
    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    EasyMock.expectLastCall();

    _callableStatement.setString(EasyMock.eq("pfi_p"), EasyMock.capture(pfi_capture)); //$NON-NLS-1$
    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.getString(RETOUR_RESULTAT)).andReturn("OK"); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString(RETOUR_CATEGORIE)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_DIAGNOSTIC)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_LIBELLE)).andReturn(null);

    EasyMock.expect(_callableStatement.getObject("po_RESULT")).andReturn(_resultSet); //$NON-NLS-1$

    EasyMock.expect(_resultSet.next()).andReturn(true);
    EasyMock.expect(_resultSet.getString("DCPPLTFRM")).andReturn("DCPPLTFRM"); //$NON-NLS-1$ //$NON-NLS-2$

    EasyMock.expect(_resultSet.next()).andReturn(false);

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<List<String>, Retour> response = _connector.gdc001ConsultListePfFromPfi(tracabilite, pfi);

    // Asserts
    List<String> resultat = response._first;

    Assert.assertNotNull(resultat);
    Assert.assertTrue(!resultat.isEmpty());

    Assert.assertEquals("DCPPLTFRM", resultat.get(0)); //$NON-NLS-1$
    Assert.assertEquals("OK", response._second.getResultat()); //$NON-NLS-1$
    assertEquals(null, response._second.getCategorie());
    assertEquals(null, response._second.getLibelle());
    assertEquals(null, response._second.getDiagnostic());
  }

  /**
   * Cas non Nominal
   *
   * @throws RavelException
   *           exception
   * @throws SQLException
   */
  @Test
  public void test_ps001ConsultListePfFromPfi_2() throws RavelException, SQLException
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    _gdcConnector = new GDCConnector();
    String pfi = "1109813914224"; //$NON-NLS-1$

    // Setup statement mock
    Capture<String> pfi_capture = Capture.newInstance();

    EasyMock.expect(_connection.prepareCall(String.format("{call %s(?,?,?,?,?,?) }", "PG_IWSRESSOURCES.P_001_GET_LISTEPF_FROM_PFI"))).andReturn(_callableStatement); //$NON-NLS-1$ //$NON-NLS-2$
    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    EasyMock.expectLastCall();

    _callableStatement.setString(EasyMock.eq("pfi_p"), EasyMock.capture(pfi_capture)); //$NON-NLS-1$
    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.getString(RETOUR_RESULTAT)).andReturn("NOK"); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString(RETOUR_CATEGORIE)).andReturn(IMegConsts.CAT1);
    EasyMock.expect(_callableStatement.getString(RETOUR_DIAGNOSTIC)).andReturn("NOT FOUND"); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString(RETOUR_LIBELLE)).andReturn("Erreur GDC"); //$NON-NLS-1$

    EasyMock.expect(_callableStatement.getObject("po_RESULT")).andReturn(_resultSet); //$NON-NLS-1$

    EasyMock.expect(_resultSet.next()).andReturn(true);
    EasyMock.expect(_resultSet.getString("DCPPLTFRM")).andReturn("DCPPLTFRM"); //$NON-NLS-1$ //$NON-NLS-2$

    EasyMock.expect(_resultSet.next()).andReturn(false);

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<List<String>, Retour> response = _connector.gdc001ConsultListePfFromPfi(tracabilite, pfi);

    // Asserts
    List<String> resultat = response._first;

    Assert.assertTrue(resultat.isEmpty());

    Assert.assertEquals("NOK", response._second.getResultat()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, response._second.getCategorie());
    assertEquals("Erreur GDC", response._second.getLibelle()); //$NON-NLS-1$
    assertEquals("NOT FOUND", response._second.getDiagnostic()); //$NON-NLS-1$
  }

  /**
   * Cas non Nominal
   *
   * @throws RavelException
   *           exception
   * @throws SQLException
   */
  @Test
  public void test_ps001ConsultListePfFromPfi_3() throws RavelException, SQLException
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    _gdcConnector = new GDCConnector();
    String pfi = "1109813914224"; //$NON-NLS-1$

    // Setup statement mock
    Capture<String> pfi_capture = Capture.newInstance();

    EasyMock.expect(_connection.prepareCall(String.format("{call %s(?,?,?,?,?,?) }", "PG_IWSRESSOURCES.P_001_GET_LISTEPF_FROM_PFI"))).andReturn(_callableStatement); //$NON-NLS-1$ //$NON-NLS-2$
    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    EasyMock.expectLastCall();

    _callableStatement.setString(EasyMock.eq("pfi_p"), EasyMock.capture(pfi_capture)); //$NON-NLS-1$
    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.getString(RETOUR_RESULTAT)).andReturn("NOK"); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString(RETOUR_CATEGORIE)).andReturn(IMegConsts.CAT1);
    EasyMock.expect(_callableStatement.getString(RETOUR_DIAGNOSTIC)).andReturn("NOT FOUND"); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString(RETOUR_LIBELLE)).andReturn("Erreur GDC"); //$NON-NLS-1$

    EasyMock.expect(_callableStatement.getObject("po_RESULT")).andReturn(_resultSet); //$NON-NLS-1$

    EasyMock.expect(_resultSet.next()).andReturn(true);
    EasyMock.expect(_resultSet.getString("DCPPLTFRM")).andReturn("DCPPLTFRM"); //$NON-NLS-1$ //$NON-NLS-2$

    EasyMock.expect(_resultSet.next()).andReturn(false);

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<List<String>, Retour> response = _connector.gdc001ConsultListePfFromPfi(tracabilite, pfi);

    // Asserts
    List<String> resultat = response._first;

    Assert.assertTrue(resultat.isEmpty());

    Assert.assertEquals("NOK", response._second.getResultat()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, response._second.getCategorie());
    assertEquals("Erreur GDC", response._second.getLibelle()); //$NON-NLS-1$
    assertEquals("NOT FOUND", response._second.getDiagnostic()); //$NON-NLS-1$
  }

  /**
   * Cas non Nominal
   *
   * @throws RavelException
   *           exception
   * @throws SQLException
   */
  @Test
  public void test_ps001ConsultListePfFromPfi_4() throws RavelException, SQLException
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    _gdcConnector = new GDCConnector();
    String pfi = "1109813914224"; //$NON-NLS-1$

    EasyMock.expect(_connection.prepareCall(String.format("{call %s(?,?,?,?,?,?) }", "PG_IWSRESSOURCES.P_001_GET_LISTEPF_FROM_PFI"))).andThrow(new SQLTimeoutException("Something terrible happened")); //$NON-NLS-1$//$NON-NLS-2$ //$NON-NLS-3$

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<List<String>, Retour> response = _connector.gdc001ConsultListePfFromPfi(tracabilite, pfi);

    // Asserts
    List<String> resultat = response._first;

    Assert.assertNull(resultat);

    Assert.assertEquals("KO", response._second.getResultat()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, response._second.getCategorie());
    assertNotNull(response._second.getLibelle());
    assertEquals("SELECT_FAILED", response._second.getDiagnostic()); //$NON-NLS-1$
  }

  /**
   * Cas non Nominal
   *
   * @throws RavelException
   *           exception
   * @throws SQLException
   */
  @Test
  public void test_ps001ConsultListePfFromPfi_5() throws RavelException, SQLException
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    _gdcConnector = new GDCConnector();
    String pfi = "1109813914224"; //$NON-NLS-1$

    // Setup statement mock
    Capture<String> pfi_capture = Capture.newInstance();

    EasyMock.expect(_connection.prepareCall(String.format("{call %s(?,?,?,?,?,?) }", "PG_IWSRESSOURCES.P_001_GET_LISTEPF_FROM_PFI"))).andReturn(_callableStatement); //$NON-NLS-1$ //$NON-NLS-2$
    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    EasyMock.expectLastCall();

    _callableStatement.setString(EasyMock.eq("pfi_p"), EasyMock.capture(pfi_capture)); //$NON-NLS-1$
    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.getString(RETOUR_RESULTAT)).andReturn("NOK"); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString(RETOUR_CATEGORIE)).andReturn(IMegConsts.CAT1);
    EasyMock.expect(_callableStatement.getString(RETOUR_DIAGNOSTIC)).andReturn("NOT FOUND"); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString(RETOUR_LIBELLE)).andReturn("Erreur GDC"); //$NON-NLS-1$

    EasyMock.expect(_callableStatement.getObject("po_RESULT")).andThrow(new PoolExhaustedException("Something terrible happened")); //$NON-NLS-1$ //$NON-NLS-2$//$NON-NLS-2

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<List<String>, Retour> response = _connector.gdc001ConsultListePfFromPfi(tracabilite, pfi);

    // Asserts
    List<String> resultat = response._first;

    Assert.assertNull(resultat);

    Assert.assertEquals("KO", response._second.getResultat()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, response._second.getCategorie());
    assertNotNull(response._second.getLibelle());
    assertEquals("SESSION_UNAVAILABLE", response._second.getDiagnostic()); //$NON-NLS-1$
  }

  /**
   * Cas non Nominal
   *
   * @throws RavelException
   *           exception
   * @throws SQLException
   */
  @Test
  public void test_ps001ConsultListePfFromPfi_6() throws RavelException, SQLException
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    _gdcConnector = new GDCConnector();
    String pfi = "1109813914224"; //$NON-NLS-1$

    // Setup statement mock
    Capture<String> pfi_capture = Capture.newInstance();

    EasyMock.expect(_connection.prepareCall(String.format("{call %s(?,?,?,?,?,?) }", "PG_IWSRESSOURCES.P_001_GET_LISTEPF_FROM_PFI"))).andReturn(_callableStatement); //$NON-NLS-1$ //$NON-NLS-2$
    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    EasyMock.expectLastCall();

    _callableStatement.setString(EasyMock.eq("pfi_p"), EasyMock.capture(pfi_capture)); //$NON-NLS-1$
    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.getString(RETOUR_RESULTAT)).andReturn("NOK"); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString(RETOUR_CATEGORIE)).andReturn(IMegConsts.CAT1);
    EasyMock.expect(_callableStatement.getString(RETOUR_DIAGNOSTIC)).andReturn("NOT FOUND"); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString(RETOUR_LIBELLE)).andReturn("Erreur GDC"); //$NON-NLS-1$

    EasyMock.expect(_callableStatement.execute()).andThrow(new SQLRecoverableException("Something terrible happened")); //$NON-NLS-1$

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<List<String>, Retour> response = _connector.gdc001ConsultListePfFromPfi(tracabilite, pfi);

    // Asserts
    List<String> resultat = response._first;

    Assert.assertNull(resultat);

    Assert.assertEquals("KO", response._second.getResultat()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, response._second.getCategorie());
    assertNotNull(response._second.getLibelle());
    assertEquals("CONNEXION_FAILED", response._second.getDiagnostic()); //$NON-NLS-1$
  }

  /**
   * Cas non Nominal
   *
   * @throws RavelException
   *           exception
   * @throws RavelException,
   *           SQLException
   */
  @Test
  public void test_migrerPfiGdcStwVersVstw_1() throws RavelException, SQLException
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    _gdcConnector = new GDCConnector();
    PfeSvc pfeSvc = new PfeSvc();
    pfeSvc.setIdPfi("sIdPfi");//$NON-NLS-1$
    pfeSvc.setIdtDerMod("MIGRER_LOT_BOITE_4587");//$NON-NLS-1$

    // Setup statement mock

    EasyMock.expect(_connection.prepareCall("{call PG_MIGSTW.PR_MIGRER_PFS_STW(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$ //$NON-NLS-2$
    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    EasyMock.expectLastCall();

    _callableStatement.setString("pi_PFI", pfeSvc.getIdPfi()); //$NON-NLS-1$
    _callableStatement.setString("pi_IDTDERMOD", pfeSvc.getIdtDerMod()); //$NON-NLS-1$

    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.execute()).andThrow(new SQLTimeoutException("Something terrible happened")); //$NON-NLS-1$

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<Nothing, Retour> response = _connector.migrerPfiGdcStwVersVstw(tracabilite, pfeSvc);

    // Asserts
    Assert.assertEquals("KO", response._second.getResultat()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, response._second.getCategorie());
    assertEquals("SELECT_FAILED", response._second.getDiagnostic()); //$NON-NLS-1$
    assertNull(response._first);
  }

  /**
   * Cas non Nominal
   *
   * @throws RavelException
   *           exception
   * @throws PoolExhaustedException
   */
  @Test
  public void test_migrerPfiGdcStwVersVstw_2() throws RavelException, SQLException
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    _gdcConnector = new GDCConnector();
    PfeSvc pfeSvc = new PfeSvc();
    pfeSvc.setIdPfi("sIdPfi");//$NON-NLS-1$
    pfeSvc.setIdtDerMod("MIGRER_LOT_BOITE_4587");//$NON-NLS-1$

    // Setup statement mock

    EasyMock.expect(_connection.prepareCall("{call PG_MIGSTW.PR_MIGRER_PFS_STW(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$ //$NON-NLS-2$
    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    EasyMock.expectLastCall();

    _callableStatement.setString("pi_PFI", pfeSvc.getIdPfi()); //$NON-NLS-1$
    _callableStatement.setString("pi_IDTDERMOD", pfeSvc.getIdtDerMod()); //$NON-NLS-1$
    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.execute()).andThrow(new PoolExhaustedException("Something terrible happened")); //$NON-NLS-1$

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<Nothing, Retour> response = _connector.migrerPfiGdcStwVersVstw(tracabilite, pfeSvc);

    // Asserts
    Assert.assertEquals("KO", response._second.getResultat()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, response._second.getCategorie());
    assertEquals("SESSION_UNAVAILABLE", response._second.getDiagnostic()); //$NON-NLS-1$
    assertNull(response._first);
  }

  /**
   * Cas non Nominal
   *
   * @throws RavelException
   *           exception
   * @throws SQLRecoverableException
   */
  @Test
  public void test_migrerPfiGdcStwVersVstw_3() throws RavelException, SQLException
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    _gdcConnector = new GDCConnector();
    PfeSvc pfeSvc = new PfeSvc();
    pfeSvc.setIdPfi("sIdPfi");//$NON-NLS-1$
    pfeSvc.setIdtDerMod("MIGRER_LOT_BOITE_4587");//$NON-NLS-1$

    // Setup statement mock

    EasyMock.expect(_connection.prepareCall("{call PG_MIGSTW.PR_MIGRER_PFS_STW(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$ //$NON-NLS-2$
    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    EasyMock.expectLastCall();

    _callableStatement.setString("pi_PFI", pfeSvc.getIdPfi()); //$NON-NLS-1$
    _callableStatement.setString("pi_IDTDERMOD", pfeSvc.getIdtDerMod()); //$NON-NLS-1$
    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.execute()).andThrow(new SQLRecoverableException("Something terrible happened")); //$NON-NLS-1$

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<Nothing, Retour> response = _connector.migrerPfiGdcStwVersVstw(tracabilite, pfeSvc);

    // Asserts
    Assert.assertEquals("KO", response._second.getResultat()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, response._second.getCategorie());
    assertEquals("CONNEXION_FAILED", response._second.getDiagnostic()); //$NON-NLS-1$
    assertNull(response._first);
  }

  /**
   * Cas Nominal returns False
   *
   * @throws RavelException
   *           exception
   * @throws SQLException
   */
  @Test
  public void test_migrerPfiGdcStwVersVstw_KO() throws RavelException, SQLException
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    _gdcConnector = new GDCConnector();
    PfeSvc pfeSvc = new PfeSvc();
    pfeSvc.setIdPfi("sIdPfi");//$NON-NLS-1$
    pfeSvc.setIdtDerMod("MIGRER_LOT_BOITE_4587");//$NON-NLS-1$

    // Setup statement mock

    EasyMock.expect(_connection.prepareCall("{call PG_MIGSTW.PR_MIGRER_PFS_STW(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$ //$NON-NLS-2$
    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    EasyMock.expectLastCall();

    _callableStatement.setString("pi_PFI", pfeSvc.getIdPfi()); //$NON-NLS-1$
    _callableStatement.setString("pi_IDTDERMOD", pfeSvc.getIdtDerMod()); //$NON-NLS-1$
    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.getString(RETOUR_RESULTAT)).andReturn("NOK"); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString(RETOUR_CATEGORIE)).andReturn(IMegSpiritConsts.CAT2);
    EasyMock.expect(_callableStatement.getString(RETOUR_DIAGNOSTIC)).andReturn(IMegSpiritConsts.SERVICE_INDISPONIBLE);
    EasyMock.expect(_callableStatement.getString(RETOUR_LIBELLE)).andReturn(IMegSpiritConsts.LIBELLE);

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<Nothing, Retour> response = _connector.migrerPfiGdcStwVersVstw(tracabilite, pfeSvc);

    // Asserts
    Assert.assertEquals("NOK", response._second.getResultat()); //$NON-NLS-1$
    assertEquals(IMegSpiritConsts.CAT2, response._second.getCategorie());
    assertEquals(IMegSpiritConsts.SERVICE_INDISPONIBLE, response._second.getDiagnostic());
    assertEquals(IMegSpiritConsts.LIBELLE, response._second.getLibelle());

    assertNull(response._first);
  }

  /**
   * Cas Nominal returns True
   *
   * @throws RavelException
   *           exception
   * @throws SQLException
   */
  @Test
  public void test_migrerPfiGdcStwVersVstw_OK() throws RavelException, SQLException
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    _gdcConnector = new GDCConnector();
    PfeSvc pfeSvc = new PfeSvc();
    pfeSvc.setIdPfi("sIdPfi");//$NON-NLS-1$
    pfeSvc.setIdtDerMod("MIGRER_LOT_BOITE_4587");//$NON-NLS-1$

    // Setup statement mock

    EasyMock.expect(_connection.prepareCall("{call PG_MIGSTW.PR_MIGRER_PFS_STW(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$ //$NON-NLS-2$
    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    EasyMock.expectLastCall();

    _callableStatement.setString("pi_PFI", pfeSvc.getIdPfi()); //$NON-NLS-1$
    _callableStatement.setString("pi_IDTDERMOD", pfeSvc.getIdtDerMod()); //$NON-NLS-1$
    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.getString(RETOUR_RESULTAT)).andReturn("OK"); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString(RETOUR_CATEGORIE)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_DIAGNOSTIC)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_LIBELLE)).andReturn(null);

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<Nothing, Retour> response = _connector.migrerPfiGdcStwVersVstw(tracabilite, pfeSvc);

    // Asserts
    Assert.assertEquals("OK", response._second.getResultat()); //$NON-NLS-1$
    assertNull(response._second.getCategorie());
    assertNull(response._second.getLibelle());
    assertNull(response._second.getDiagnostic());
    assertNull(response._second.getLibelle());
    assertNull(response._first);
  }

  /**
   * Cas non Nominal
   *
   * @throws RavelException
   *           exception
   * @throws RavelException,
   *           SQLException
   */
  @Test
  public void test_annulerMigrerPfiGdcStwVersVstw_1() throws RavelException, SQLException
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    _gdcConnector = new GDCConnector();
    PfeSvc pfeSvc = new PfeSvc();
    pfeSvc.setIdPfi("sIdPfi");//$NON-NLS-1$
    pfeSvc.setIdtDerMod("MIGRER_LOT_BOITE_4587");//$NON-NLS-1$

    // Setup statement mock

    EasyMock.expect(_connection.prepareCall("{call PG_MIGSTW.PR_ANNULER_MIGSTW(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$ //$NON-NLS-2$
    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    EasyMock.expectLastCall();

    _callableStatement.setString("pi_PFI", pfeSvc.getIdPfi()); //$NON-NLS-1$
    _callableStatement.setString("pi_IDTDERMOD", pfeSvc.getIdtDerMod()); //$NON-NLS-1$

    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.execute()).andThrow(new SQLTimeoutException("Something terrible happened")); //$NON-NLS-1$

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<Nothing, Retour> response = _connector.annulerMigrerPfiGdcStwVersVstw(tracabilite, pfeSvc);

    // Asserts
    Assert.assertEquals("KO", response._second.getResultat()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, response._second.getCategorie());
    assertEquals("SELECT_FAILED", response._second.getDiagnostic()); //$NON-NLS-1$
    assertNull(response._first);
  }

  /**
   * Cas non Nominal
   *
   * @throws RavelException
   *           exception
   * @throws PoolExhaustedException
   */
  @Test
  public void test_annulerMigrerPfiGdcStwVersVstw_2() throws RavelException, SQLException
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    _gdcConnector = new GDCConnector();
    PfeSvc pfeSvc = new PfeSvc();
    pfeSvc.setIdPfi("sIdPfi");//$NON-NLS-1$
    pfeSvc.setIdtDerMod("MIGRER_LOT_BOITE_4587");//$NON-NLS-1$

    // Setup statement mock

    EasyMock.expect(_connection.prepareCall("{call PG_MIGSTW.PR_ANNULER_MIGSTW(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$ //$NON-NLS-2$
    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    EasyMock.expectLastCall();

    _callableStatement.setString("pi_PFI", pfeSvc.getIdPfi()); //$NON-NLS-1$
    _callableStatement.setString("pi_IDTDERMOD", pfeSvc.getIdtDerMod()); //$NON-NLS-1$
    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.execute()).andThrow(new PoolExhaustedException("Something terrible happened")); //$NON-NLS-1$

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<Nothing, Retour> response = _connector.annulerMigrerPfiGdcStwVersVstw(tracabilite, pfeSvc);

    // Asserts
    Assert.assertEquals("KO", response._second.getResultat()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, response._second.getCategorie());
    assertEquals("SESSION_UNAVAILABLE", response._second.getDiagnostic()); //$NON-NLS-1$
    assertNull(response._first);
  }

  /**
   * Cas non Nominal
   *
   * @throws RavelException
   *           exception
   * @throws SQLRecoverableException
   */
  @Test
  public void test_annulerMigrerPfiGdcStwVersVstw_3() throws RavelException, SQLException
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    _gdcConnector = new GDCConnector();
    PfeSvc pfeSvc = new PfeSvc();
    pfeSvc.setIdPfi("sIdPfi");//$NON-NLS-1$
    pfeSvc.setIdtDerMod("MIGRER_LOT_BOITE_4587");//$NON-NLS-1$

    // Setup statement mock

    EasyMock.expect(_connection.prepareCall("{call PG_MIGSTW.PR_ANNULER_MIGSTW(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$ //$NON-NLS-2$
    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    EasyMock.expectLastCall();

    _callableStatement.setString("pi_PFI", pfeSvc.getIdPfi()); //$NON-NLS-1$
    _callableStatement.setString("pi_IDTDERMOD", pfeSvc.getIdtDerMod()); //$NON-NLS-1$
    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.execute()).andThrow(new SQLRecoverableException("Something terrible happened")); //$NON-NLS-1$

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<Nothing, Retour> response = _connector.annulerMigrerPfiGdcStwVersVstw(tracabilite, pfeSvc);

    // Asserts
    Assert.assertEquals("KO", response._second.getResultat()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, response._second.getCategorie());
    assertEquals("CONNEXION_FAILED", response._second.getDiagnostic()); //$NON-NLS-1$
    assertNull(response._first);
  }

  /**
   * Cas Nominal returns False
   *
   * @throws RavelException
   *           exception
   * @throws SQLException
   */
  @Test
  public void test_annulerMigrerPfiGdcStwVersVstw_KO() throws RavelException, SQLException
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    _gdcConnector = new GDCConnector();
    PfeSvc pfeSvc = new PfeSvc();
    pfeSvc.setIdPfi("sIdPfi");//$NON-NLS-1$
    pfeSvc.setIdtDerMod("MIGRER_LOT_BOITE_4587");//$NON-NLS-1$

    // Setup statement mock

    EasyMock.expect(_connection.prepareCall("{call PG_MIGSTW.PR_ANNULER_MIGSTW(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$ //$NON-NLS-2$
    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    EasyMock.expectLastCall();

    _callableStatement.setString("pi_PFI", pfeSvc.getIdPfi()); //$NON-NLS-1$
    _callableStatement.setString("pi_IDTDERMOD", pfeSvc.getIdtDerMod()); //$NON-NLS-1$
    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.getString(RETOUR_RESULTAT)).andReturn("NOK"); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString(RETOUR_CATEGORIE)).andReturn(IMegSpiritConsts.CAT2);
    EasyMock.expect(_callableStatement.getString(RETOUR_DIAGNOSTIC)).andReturn(IMegSpiritConsts.SERVICE_INDISPONIBLE);
    EasyMock.expect(_callableStatement.getString(RETOUR_LIBELLE)).andReturn(IMegSpiritConsts.LIBELLE);

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<Nothing, Retour> response = _connector.annulerMigrerPfiGdcStwVersVstw(tracabilite, pfeSvc);

    // Asserts
    Assert.assertEquals("NOK", response._second.getResultat()); //$NON-NLS-1$
    assertEquals(IMegSpiritConsts.CAT2, response._second.getCategorie());
    assertEquals(IMegSpiritConsts.SERVICE_INDISPONIBLE, response._second.getDiagnostic());
    assertEquals(IMegSpiritConsts.LIBELLE, response._second.getLibelle());
    assertNull(response._first);
  }

  /**
   * Cas Nominal returns True
   *
   * @throws RavelException
   *           exception
   * @throws SQLException
   */
  @Test
  public void test_annulerMigrerPfiGdcStwVersVstw_OK() throws RavelException, SQLException
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    _gdcConnector = new GDCConnector();
    PfeSvc pfeSvc = new PfeSvc();
    pfeSvc.setIdPfi("sIdPfi");//$NON-NLS-1$
    pfeSvc.setIdtDerMod("MIGRER_LOT_BOITE_4587");//$NON-NLS-1$

    // Setup statement mock

    EasyMock.expect(_connection.prepareCall("{call PG_MIGSTW.PR_ANNULER_MIGSTW(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$ //$NON-NLS-2$
    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    EasyMock.expectLastCall();

    _callableStatement.setString("pi_PFI", pfeSvc.getIdPfi()); //$NON-NLS-1$
    _callableStatement.setString("pi_IDTDERMOD", pfeSvc.getIdtDerMod()); //$NON-NLS-1$
    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.getString(RETOUR_RESULTAT)).andReturn("OK"); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString(RETOUR_CATEGORIE)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_DIAGNOSTIC)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_LIBELLE)).andReturn(null);

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<Nothing, Retour> response = _connector.annulerMigrerPfiGdcStwVersVstw(tracabilite, pfeSvc);

    // Asserts
    Assert.assertEquals("OK", response._second.getResultat()); //$NON-NLS-1$
    assertNull(response._second.getCategorie());
    assertNull(response._second.getLibelle());
    assertNull(response._second.getDiagnostic());
    assertNull(response._second.getLibelle());
    assertNull(response._first);
  }

  /**
   * Cas non Nominal
   *
   * @throws RavelException
   *           exception
   * @throws RavelException,
   *           SQLException
   */
  @Test
  public void test_inhiberPfiGdcStw_1() throws RavelException, SQLException
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    _gdcConnector = new GDCConnector();
    PfeSvc pfeSvc = new PfeSvc();
    pfeSvc.setIdPfi("sIdPfi");//$NON-NLS-1$
    pfeSvc.setIdtDerMod("MIGRER_LOT_BOITE_4587");//$NON-NLS-1$

    // Setup statement mock

    EasyMock.expect(_connection.prepareCall("{call PG_MIGSTW.PR_INHIBER_ST_VMS(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$ //$NON-NLS-2$
    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    EasyMock.expectLastCall();

    _callableStatement.setString("pi_PFI", pfeSvc.getIdPfi()); //$NON-NLS-1$
    _callableStatement.setString("pi_IDTDERMOD", pfeSvc.getIdtDerMod()); //$NON-NLS-1$

    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.execute()).andThrow(new SQLTimeoutException("Something terrible happened")); //$NON-NLS-1$

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<Nothing, Retour> response = _connector.inhiberPfiGdcStw(tracabilite, pfeSvc);

    // Asserts
    Assert.assertEquals("KO", response._second.getResultat()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, response._second.getCategorie());
    assertEquals("SELECT_FAILED", response._second.getDiagnostic()); //$NON-NLS-1$
    assertNull(response._first);
  }

  /**
   * Cas non Nominal
   *
   * @throws RavelException
   *           exception
   * @throws PoolExhaustedException
   */
  @Test
  public void test_inhiberPfiGdcStw_2() throws RavelException, SQLException
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    _gdcConnector = new GDCConnector();
    PfeSvc pfeSvc = new PfeSvc();
    pfeSvc.setIdPfi("sIdPfi");//$NON-NLS-1$
    pfeSvc.setIdtDerMod("MIGRER_LOT_BOITE_4587");//$NON-NLS-1$

    // Setup statement mock

    EasyMock.expect(_connection.prepareCall("{call PG_MIGSTW.PR_INHIBER_ST_VMS(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$ //$NON-NLS-2$
    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    EasyMock.expectLastCall();

    _callableStatement.setString("pi_PFI", pfeSvc.getIdPfi()); //$NON-NLS-1$
    _callableStatement.setString("pi_IDTDERMOD", pfeSvc.getIdtDerMod()); //$NON-NLS-1$
    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.execute()).andThrow(new PoolExhaustedException("Something terrible happened")); //$NON-NLS-1$

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<Nothing, Retour> response = _connector.inhiberPfiGdcStw(tracabilite, pfeSvc);

    // Asserts
    Assert.assertEquals("KO", response._second.getResultat()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, response._second.getCategorie());
    assertEquals("SESSION_UNAVAILABLE", response._second.getDiagnostic()); //$NON-NLS-1$
    assertNull(response._first);
  }

  /**
   * Cas non Nominal
   *
   * @throws RavelException
   *           exception
   * @throws SQLRecoverableException
   */
  @Test
  public void test_inhiberPfiGdcStw_3() throws RavelException, SQLException
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    _gdcConnector = new GDCConnector();
    PfeSvc pfeSvc = new PfeSvc();
    pfeSvc.setIdPfi("sIdPfi");//$NON-NLS-1$
    pfeSvc.setIdtDerMod("MIGRER_LOT_BOITE_4587");//$NON-NLS-1$

    // Setup statement mock

    EasyMock.expect(_connection.prepareCall("{call PG_MIGSTW.PR_INHIBER_ST_VMS(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$ //$NON-NLS-2$
    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    EasyMock.expectLastCall();

    _callableStatement.setString("pi_PFI", pfeSvc.getIdPfi()); //$NON-NLS-1$
    _callableStatement.setString("pi_IDTDERMOD", pfeSvc.getIdtDerMod()); //$NON-NLS-1$
    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.execute()).andThrow(new SQLRecoverableException("Something terrible happened")); //$NON-NLS-1$

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<Nothing, Retour> response = _connector.inhiberPfiGdcStw(tracabilite, pfeSvc);

    // Asserts
    Assert.assertEquals("KO", response._second.getResultat()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, response._second.getCategorie());
    assertEquals("CONNEXION_FAILED", response._second.getDiagnostic()); //$NON-NLS-1$
    assertNull(response._first);
  }

  /**
   * Cas Nominal returns False
   *
   * @throws RavelException
   *           exception
   * @throws SQLException
   */
  @Test
  public void test_inhiberPfiGdcStw_KO() throws RavelException, SQLException
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    _gdcConnector = new GDCConnector();
    PfeSvc pfeSvc = new PfeSvc();
    pfeSvc.setIdPfi("sIdPfi");//$NON-NLS-1$
    pfeSvc.setIdtDerMod("MIGRER_LOT_BOITE_4587");//$NON-NLS-1$

    // Setup statement mock

    EasyMock.expect(_connection.prepareCall("{call PG_MIGSTW.PR_INHIBER_ST_VMS(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$ //$NON-NLS-2$
    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    EasyMock.expectLastCall();

    _callableStatement.setString("pi_PFI", pfeSvc.getIdPfi()); //$NON-NLS-1$
    _callableStatement.setString("pi_IDTDERMOD", pfeSvc.getIdtDerMod()); //$NON-NLS-1$
    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.getString(RETOUR_RESULTAT)).andReturn("NOK"); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString(RETOUR_CATEGORIE)).andReturn(IMegSpiritConsts.CAT2);
    EasyMock.expect(_callableStatement.getString(RETOUR_DIAGNOSTIC)).andReturn(IMegSpiritConsts.SERVICE_INDISPONIBLE);
    EasyMock.expect(_callableStatement.getString(RETOUR_LIBELLE)).andReturn(IMegSpiritConsts.LIBELLE);

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<Nothing, Retour> response = _connector.inhiberPfiGdcStw(tracabilite, pfeSvc);

    // Asserts
    Assert.assertEquals("NOK", response._second.getResultat()); //$NON-NLS-1$
    assertEquals(IMegSpiritConsts.CAT2, response._second.getCategorie());
    assertEquals(IMegSpiritConsts.SERVICE_INDISPONIBLE, response._second.getDiagnostic());
    assertEquals(IMegSpiritConsts.LIBELLE, response._second.getLibelle());

    assertNull(response._first);
  }

  /**
   * Cas Nominal returns True
   *
   * @throws RavelException
   *           exception
   * @throws SQLException
   */
  @Test
  public void test_inhiberPfiGdcStw_OK() throws RavelException, SQLException
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    _gdcConnector = new GDCConnector();
    PfeSvc pfeSvc = new PfeSvc();
    pfeSvc.setIdPfi("sIdPfi");//$NON-NLS-1$
    pfeSvc.setIdtDerMod("MIGRER_LOT_BOITE_4587");//$NON-NLS-1$

    // Setup statement mock

    EasyMock.expect(_connection.prepareCall("{call PG_MIGSTW.PR_INHIBER_ST_VMS(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$ //$NON-NLS-2$
    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    EasyMock.expectLastCall();

    _callableStatement.setString("pi_PFI", pfeSvc.getIdPfi()); //$NON-NLS-1$
    _callableStatement.setString("pi_IDTDERMOD", pfeSvc.getIdtDerMod()); //$NON-NLS-1$
    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.getString(RETOUR_RESULTAT)).andReturn("OK"); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString(RETOUR_CATEGORIE)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_DIAGNOSTIC)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_LIBELLE)).andReturn(null);

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<Nothing, Retour> response = _connector.inhiberPfiGdcStw(tracabilite, pfeSvc);

    // Asserts
    Assert.assertEquals("OK", response._second.getResultat()); //$NON-NLS-1$
    assertNull(response._second.getCategorie());
    assertNull(response._second.getLibelle());
    assertNull(response._second.getDiagnostic());
    assertNull(response._second.getLibelle());

    assertNull(response._first);
  }
}