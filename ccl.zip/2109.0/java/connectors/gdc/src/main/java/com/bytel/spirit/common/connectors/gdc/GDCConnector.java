/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.gdc;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLRecoverableException;
import java.sql.SQLTimeoutException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.tomcat.jdbc.pool.PoolExhaustedException;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.conf.generated.Param;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionTools;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.services.conf.connector.generated.Connector;
import com.bytel.ravel.services.connector.AbstractDBConnector;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.shared.functional.types.functional.mediaBox.PfeSvc;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

import oracle.jdbc.OracleTypes;

/**
 *
 * @author mbaptist
 * @version ($Revision$ $Date$)
 */
public class GDCConnector extends AbstractDBConnector implements IGDCConnector
{
  /**
   * Defines all mandatory parameters read from configuration file.
   *
   * @author $Author: tpatrici $
   * @version ($Revision: 35074 $ $Date: 2017-04-06 14:05:39 +0100 (jeu., 06 avr. 2017) $)
   */
  private enum ParameterName
  {
    /**
     * The URL parameter.
     */
    DB_CONNECTIONSTRING,

    /**
     * The PASSWORD parameter.
     */
    DB_PASSWORD,

    /**
     * The LOGIN parameter.
     */
    DB_USERNAME,

    /**
     * The POOLSIZE parameter.
     */
    POOLSIZE,

    /**
     * Connect timeout in sec
     */
    CONNECT_TIMEOUT_SEC,

    /**
     * read timeout in sec
     */
    READ_TIMEOUT_SEC
  }

  public interface ISQLStatement
  {
    String PR_MIGRER_PFS_STW = "{call PG_MIGSTW.PR_MIGRER_PFS_STW(?,?,?,?,?,?) }"; //$NON-NLS-1$
    String PR_ANNULER_MIGSTW = "{call PG_MIGSTW.PR_ANNULER_MIGSTW(?,?,?,?,?,?) }"; //$NON-NLS-1$
    String PR_INHIBER_ST_VMS = "{call PG_MIGSTW.PR_INHIBER_ST_VMS(?,?,?,?,?,?) }"; //$NON-NLS-1$
  }

  public interface IMethodName
  {
    String PR_MIGRER_PFS_STW = "PG_MIGSTW.PR_MIGRER_PFS_STW"; //$NON-NLS-1$
    String PR_ANNULER_MIGSTW = "PG_MIGSTW.PR_ANNULER_MIGSTW"; //$NON-NLS-1$
    String PR_INHIBER_ST_VMS = "PG_MIGSTW.PR_INHIBER_ST_VMS"; //$NON-NLS-1$
  }
  /**
   * Connection failed
   */
  private static final String CONNEXION_FAILED = "CONNEXION_FAILED"; //$NON-NLS-1$

  /**
   * Failure during select
   */
  private static final String SELECT_FAILED = "SELECT_FAILED"; //$NON-NLS-1$

  /**
   * Session is unavailable
   */
  private static final String SESSION_UNAVAILABLE = "SESSION_UNAVAILABLE"; //$NON-NLS-1$

  /**
   * datasource connection properties
   */
  private static final String CONNECTION_PROPERTIES = "oracle.net.CONNECT_TIMEOUT=%d;oracle.jdbc.ReadTimeout=%d"; //$NON-NLS-1$

  /**
   * Connect timeout in seconds
   */
  private int _connectTimeoutSec;

  /**
   * Parameters read from configuration.
   */
  private Map<ParameterName, String> _parameters = new HashMap<>();

  /**
   * Read timeout in seconds
   */
  private int _readTimeoutSec;

  @Override
  public ConnectorResponse<Boolean, Retour> checkPfiMigre(Tracabilite tracabilite_p, String pfi_p) throws RavelException
  {
    final String methodName = "PG_IWSRESSOURCES.P_002_CHECK_PFI_MIGRE"; //$NON-NLS-1$
    Connection con = null;
    _dsReadLock.lock();
    ResultSet rs = null;
    CallableStatement cs = null;

    try
    {
      con = _datasource.getConnection();

      cs = con.prepareCall(String.format("{call %s(?,?,?,?,?,?) }", methodName)); //$NON-NLS-1$
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("pi_PFI", pfi_p); //$NON-NLS-1$

      cs.registerOutParameter("po_RESULT", OracleTypes.BIT); //$NON-NLS-1$
      cs.registerOutParameter("Retour_Resultat", OracleTypes.NVARCHAR); //$NON-NLS-1$
      cs.registerOutParameter("Retour_Categorie", OracleTypes.NVARCHAR); //$NON-NLS-1$
      cs.registerOutParameter("Retour_Diagnostic", OracleTypes.NVARCHAR); //$NON-NLS-1$
      cs.registerOutParameter("Retour_Libelle", OracleTypes.NVARCHAR); //$NON-NLS-1$

      cs.execute();
      Boolean res = false;

      res = (Boolean) cs.getObject("po_RESULT"); //$NON-NLS-1$
      Retour retour = getRetour(cs);

      SpiritLogEvent outputLog = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, methodName);
      outputLog.addField("Retour", retour, false); //$NON-NLS-1$
      RavelLogger.log(outputLog);

      return new ConnectorResponse<>(res, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("PFI:").append(pfi_p).toString()); //$NON-NLS-1$

      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SELECT_FAILED, MessageFormat.format(Messages.getString("GDCConnector.ERREUR_GDC_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("PFI:").append(pfi_p).toString()); //$NON-NLS-1$

      //no sessions/connections available in the connection pool
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("GDCConnector.ERREUR_GDC_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("PFI:").append(pfi_p).toString()); //$NON-NLS-1$

      // when not able to connect
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("GDCConnector.ERREUR_GDC_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append("PFI:").append(pfi_p).toString()); //$NON-NLS-1$
    }
    finally
    {
      close(rs, cs, con);
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<List<String>, Retour> gdc001ConsultListePfFromPfi(Tracabilite tracabilite_p, String pfi_p) throws RavelException
  {
    final String methodName = "PG_IWSRESSOURCES.P_001_GET_LISTEPF_FROM_PFI"; //$NON-NLS-1$
    ResultSet rs = null;
    Connection con = null;
    CallableStatement cs = null;
    _dsReadLock.lock();
    try
    {
      con = _datasource.getConnection();

      cs = con.prepareCall(String.format("{call %s(?,?,?,?,?,?) }", methodName)); //$NON-NLS-1$
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("pi_PFI", pfi_p); //$NON-NLS-1$

      cs.registerOutParameter("po_RESULT", OracleTypes.CURSOR); //$NON-NLS-1$
      cs.registerOutParameter("Retour_Resultat", OracleTypes.NVARCHAR); //$NON-NLS-1$
      cs.registerOutParameter("Retour_Categorie", OracleTypes.NVARCHAR); //$NON-NLS-1$
      cs.registerOutParameter("Retour_Diagnostic", OracleTypes.NVARCHAR); //$NON-NLS-1$
      cs.registerOutParameter("Retour_Libelle", OracleTypes.NVARCHAR); //$NON-NLS-1$

      cs.execute();
      List<String> ptfList = new ArrayList<>();

      Retour retour = getRetour(cs);

      rs = (ResultSet) cs.getObject("po_RESULT"); //$NON-NLS-1$

      if (StringConstants.OK.equals(retour.getResultat()) && (rs != null))
      {
        while (rs.next())
        {
          ptfList.add(rs.getString("DCPPLTFRM")); //$NON-NLS-1$
        }
      }

      SpiritLogEvent outputLog = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, methodName);
      outputLog.addField("Retour", retour, false); //$NON-NLS-1$
      RavelLogger.log(outputLog);

      return new ConnectorResponse<>(ptfList, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("PFI:").append(pfi_p).toString()); //$NON-NLS-1$

      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SELECT_FAILED, MessageFormat.format(Messages.getString("GDCConnector.ERREUR_GDC_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("PFI:").append(pfi_p).toString()); //$NON-NLS-1$

      //no sessions/connections available in the connection pool
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("GDCConnector.ERREUR_GDC_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("PFI:").append(pfi_p).toString()); //$NON-NLS-1$

      // when not able to connect
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("GDCConnector.ERREUR_GDC_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append("PFI:").append(pfi_p).toString()); //$NON-NLS-1$
    }
    finally
    {
      close(rs, cs, con);
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<Nothing, Retour> migrerPfiGdcStwVersVstw(Tracabilite tracabilite_p, PfeSvc pfeSvc_p) throws RavelException
  {
    Connection con = null;
    CallableStatement cs = null;
    _dsReadLock.lock();
    try
    {
      con = _datasource.getConnection();

      cs = con.prepareCall(ISQLStatement.PR_MIGRER_PFS_STW); //$NON-NLS-1$
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("pi_PFI", pfeSvc_p.getIdPfi()); //$NON-NLS-1$
      cs.setString("pi_IDTDERMOD", pfeSvc_p.getIdtDerMod()); //$NON-NLS-1$

      cs.registerOutParameter("Retour_Resultat", OracleTypes.NVARCHAR); //$NON-NLS-1$
      cs.registerOutParameter("Retour_Categorie", OracleTypes.NVARCHAR); //$NON-NLS-1$
      cs.registerOutParameter("Retour_Diagnostic", OracleTypes.NVARCHAR); //$NON-NLS-1$
      cs.registerOutParameter("Retour_Libelle", OracleTypes.NVARCHAR);//$NON-NLS-1$

      cs.execute();

      Retour retour = getRetour(cs);

      SpiritLogEvent outputLog = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, IMethodName.PR_MIGRER_PFS_STW);
      outputLog.addField("Retour", retour, false); //$NON-NLS-1$
      RavelLogger.log(outputLog);

      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, IMethodName.PR_MIGRER_PFS_STW, "sIdPfi:" + pfeSvc_p.getIdPfi() + ", sIdtDerMod" + pfeSvc_p.getIdtDerMod()); //$NON-NLS-1$

      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SELECT_FAILED, MessageFormat.format(Messages.getString("GDCConnector.ERREUR_GDC_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, IMethodName.PR_MIGRER_PFS_STW, "sIdPfi:" + pfeSvc_p.getIdPfi() + ", sIdtDerMod" + pfeSvc_p.getIdtDerMod()); //$NON-NLS-1$

      //no sessions/connections available in the connection pool
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("GDCConnector.ERREUR_GDC_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, IMethodName.PR_MIGRER_PFS_STW, "sIdPfi:" + pfeSvc_p.getIdPfi() + ", sIdtDerMod" + pfeSvc_p.getIdtDerMod()); //$NON-NLS-1$

      // when not able to connect
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("GDCConnector.ERREUR_GDC_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, IMethodName.PR_MIGRER_PFS_STW, "sIdPfi:" + pfeSvc_p.getIdPfi() + ", sIdtDerMod" + pfeSvc_p.getIdtDerMod()); //$NON-NLS-1$
    }
    finally
    {
      close(null, cs, con);
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<Nothing, Retour> annulerMigrerPfiGdcStwVersVstw(Tracabilite tracabilite_p, PfeSvc pfeSvc_p) throws RavelException
  {
    Connection con = null;
    CallableStatement cs = null;
    _dsReadLock.lock();
    try
    {
      con = _datasource.getConnection();

      cs = con.prepareCall(ISQLStatement.PR_ANNULER_MIGSTW); //$NON-NLS-1$
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("pi_PFI", pfeSvc_p.getIdPfi()); //$NON-NLS-1$
      cs.setString("pi_IDTDERMOD", pfeSvc_p.getIdtDerMod()); //$NON-NLS-1$

      cs.registerOutParameter("Retour_Resultat", OracleTypes.NVARCHAR); //$NON-NLS-1$
      cs.registerOutParameter("Retour_Categorie", OracleTypes.NVARCHAR); //$NON-NLS-1$
      cs.registerOutParameter("Retour_Diagnostic", OracleTypes.NVARCHAR); //$NON-NLS-1$
      cs.registerOutParameter("Retour_Libelle", OracleTypes.NVARCHAR);//$NON-NLS-1$

      cs.execute();

      Retour retour = getRetour(cs);

      SpiritLogEvent outputLog = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, IMethodName.PR_ANNULER_MIGSTW);
      outputLog.addField("Retour", retour, false); //$NON-NLS-1$
      RavelLogger.log(outputLog);

      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, IMethodName.PR_ANNULER_MIGSTW, "sIdPfi:" + pfeSvc_p.getIdPfi() + ", sIdtDerMod" + pfeSvc_p.getIdtDerMod()); //$NON-NLS-1$

      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SELECT_FAILED, MessageFormat.format(Messages.getString("GDCConnector.ERREUR_GDC_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, IMethodName.PR_ANNULER_MIGSTW, "sIdPfi:" + pfeSvc_p.getIdPfi() + ", sIdtDerMod" + pfeSvc_p.getIdtDerMod()); //$NON-NLS-1$

      //no sessions/connections available in the connection pool
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("GDCConnector.ERREUR_GDC_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, IMethodName.PR_ANNULER_MIGSTW, "sIdPfi:" + pfeSvc_p.getIdPfi() + ", sIdtDerMod" + pfeSvc_p.getIdtDerMod()); //$NON-NLS-1$

      // when not able to connect
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("GDCConnector.ERREUR_GDC_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, IMethodName.PR_ANNULER_MIGSTW, "sIdPfi:" + pfeSvc_p.getIdPfi() + ", sIdtDerMod" + pfeSvc_p.getIdtDerMod()); //$NON-NLS-1$
    }
    finally
    {
      close(null, cs, con);
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<Nothing, Retour> inhiberPfiGdcStw(Tracabilite tracabilite_p, PfeSvc pfeSvc_p) throws RavelException
  {
    Connection con = null;
    CallableStatement cs = null;
    _dsReadLock.lock();
    try
    {
      con = _datasource.getConnection();

      cs = con.prepareCall(ISQLStatement.PR_INHIBER_ST_VMS); //$NON-NLS-1$
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("pi_PFI", pfeSvc_p.getIdPfi()); //$NON-NLS-1$
      cs.setString("pi_IDTDERMOD", pfeSvc_p.getIdtDerMod()); //$NON-NLS-1$

      cs.registerOutParameter("Retour_Resultat", OracleTypes.NVARCHAR); //$NON-NLS-1$
      cs.registerOutParameter("Retour_Categorie", OracleTypes.NVARCHAR); //$NON-NLS-1$
      cs.registerOutParameter("Retour_Diagnostic", OracleTypes.NVARCHAR); //$NON-NLS-1$
      cs.registerOutParameter("Retour_Libelle", OracleTypes.NVARCHAR);//$NON-NLS-1$

      cs.execute();

      Retour retour = getRetour(cs);

      SpiritLogEvent outputLog = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, IMethodName.PR_MIGRER_PFS_STW);
      outputLog.addField("Retour", retour, false); //$NON-NLS-1$
      RavelLogger.log(outputLog);

      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, IMethodName.PR_INHIBER_ST_VMS, "sIdPfi:" + pfeSvc_p.getIdPfi() + ", sIdtDerMod" + pfeSvc_p.getIdtDerMod()); //$NON-NLS-1$

      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SELECT_FAILED, MessageFormat.format(Messages.getString("GDCConnector.ERREUR_GDC_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, IMethodName.PR_INHIBER_ST_VMS, "sIdPfi:" + pfeSvc_p.getIdPfi() + ", sIdtDerMod" + pfeSvc_p.getIdtDerMod()); //$NON-NLS-1$

      //no sessions/connections available in the connection pool
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("GDCConnector.ERREUR_GDC_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, IMethodName.PR_INHIBER_ST_VMS, "sIdPfi:" + pfeSvc_p.getIdPfi() + ", sIdtDerMod" + pfeSvc_p.getIdtDerMod()); //$NON-NLS-1$

      // when not able to connect
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("GDCConnector.ERREUR_GDC_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, IMethodName.PR_INHIBER_ST_VMS, "sIdPfi:" + pfeSvc_p.getIdPfi() + ", sIdtDerMod" + pfeSvc_p.getIdtDerMod()); //$NON-NLS-1$
    }
    finally
    {
      close(null, cs, con);
      _dsReadLock.unlock();
    }
  }

  @Override
  public String getConfigParameter(String connectorID_p, String paramName_p) throws RavelException
  {
    return _parameters.get(ParameterName.valueOf(paramName_p));
  }

  @Override
  public void loadConnectorConfiguration(Connector connector_p) throws RavelException
  {
    // Read parameters.
    _name = connector_p.getName();
    _enabled = connector_p.isEnabled();
    for (Param parameter : connector_p.getParam())
    {
      ParameterName parameterName = ParameterName.valueOf(parameter.getName().toUpperCase());
      if (parameterName != null)
      {
        _parameters.put(parameterName, parameter.getValue());
      }
    }

    // Check parameters
    String connectionString = _parameters.get(ParameterName.DB_CONNECTIONSTRING);
    if ((connectionString == null) || connectionString.isEmpty())
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(Messages.getString("GDCConnector.MissingParameter"), _name, ParameterName.DB_CONNECTIONSTRING.toString())); //$NON-NLS-1$
    }
    String dbUserName = _parameters.get(ParameterName.DB_USERNAME);
    if ((dbUserName == null) || dbUserName.isEmpty())
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(Messages.getString("GDCConnector.MissingParameter"), _name, ParameterName.DB_USERNAME.toString())); //$NON-NLS-1$
    }
    String dbPassword = _parameters.get(ParameterName.DB_PASSWORD);
    if ((dbPassword == null) || dbPassword.isEmpty())
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(Messages.getString("GDCConnector.MissingParameter"), _name, ParameterName.DB_PASSWORD.toString())); //$NON-NLS-1$
    }
    String poolSize = _parameters.get(ParameterName.POOLSIZE);

    String connectTimeoutSec = _parameters.get(ParameterName.CONNECT_TIMEOUT_SEC);
    if (StringTools.isNullOrEmpty(connectTimeoutSec))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(Messages.getString("GDCConnector.MissingParameter"), _name, ParameterName.CONNECT_TIMEOUT_SEC.toString())); //$NON-NLS-1$
    }

    int connectTimeoutMilliSec = 0;
    try
    {
      connectTimeoutMilliSec = Integer.parseInt(connectTimeoutSec) * 1000;
    }
    catch (NumberFormatException e)
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00021, MessageFormat.format(Messages.getString("GDCConnector.InvalidParameter"), _name, ParameterName.CONNECT_TIMEOUT_SEC.toString())); //$NON-NLS-1$
    }

    String readTimeoutSec = _parameters.get(ParameterName.READ_TIMEOUT_SEC);
    if (StringTools.isNullOrEmpty(readTimeoutSec))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(Messages.getString("GDCConnector.MissingParameter"), _name, ParameterName.READ_TIMEOUT_SEC.toString())); //$NON-NLS-1$
    }

    try
    {
      _readTimeoutSec = Integer.parseInt(readTimeoutSec);
    }
    catch (NumberFormatException e)
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00021, MessageFormat.format(Messages.getString("GDCConnector.InvalidParameter"), _name, ParameterName.READ_TIMEOUT_SEC.toString())); //$NON-NLS-1$
    }

    createDataSource(connectionString, dbUserName, dbPassword, poolSize, DatabaseType.ORACLE);
    _datasource.setConnectionProperties(String.format(CONNECTION_PROPERTIES, connectTimeoutMilliSec, _readTimeoutSec * 1000));
  }

  /**
   * Build a log entry and throws an {@link RavelException} for a technical problem.
   *
   * @param exc_p
   *          The {@link Exception} raised
   * @param tracabilite_p
   *          The current Tracabilite
   * @param spName_p
   *          The stored procedure name in which the fault was raised.
   * @param inputs_p
   *          A string representing input data of the stored procedure.
   * @return RavelException The technical exception.
   */
  private RavelException buildTechnicalException(Exception exc_p, Tracabilite tracabilite_p, String spName_p, String inputs_p)
  {
    final String message = buildTechnicalMessage(exc_p, tracabilite_p, spName_p, inputs_p);

    return new RavelException(ExceptionType.PFS_EXCEPTION, ErrorCode.CNCTOR_00010, message, IGDCConnector.BEAN_ID, exc_p);
  }

  /**
   * Build a log entry for a technical problem.
   *
   * @param exc_p
   *          The {@link Exception} raised
   * @param tracabilite_p
   *          The current Tracabilite
   * @param spName_p
   *          The stored procedure name in which the fault was raised.
   * @param inputs_p
   *          A string representing input data of the stored procedure.
   * @return String The message of technical exception.
   */
  private String buildTechnicalMessage(Exception exc_p, Tracabilite tracabilite_p, String spName_p, String inputs_p)
  {
    final String message = new StringBuilder().append(MessageFormat.format(Messages.getString("GDCConnector.TechnicalExceptionMessage"), spName_p, 0, exc_p.getLocalizedMessage())).append(ExceptionTools.getExceptionLineAndFile(exc_p)) // add fileName and line number of the exception //$NON-NLS-1$
        .toString();

    RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, message));

    return message;
  }
}