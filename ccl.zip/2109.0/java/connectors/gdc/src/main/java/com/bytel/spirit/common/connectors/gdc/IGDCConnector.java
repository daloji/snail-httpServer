/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.gdc;

import com.bytel.ravel.services.connector.IConnector;

/**
 *
 * @author mbaptist
 * @version ($Revision$ $Date$)
 */
public interface IGDCConnector extends IConnector, IGDC
{
  /**
   * The id to retrieve the connector.
   */
  public String BEAN_ID = "GDCConnector"; //$NON-NLS-1$
}