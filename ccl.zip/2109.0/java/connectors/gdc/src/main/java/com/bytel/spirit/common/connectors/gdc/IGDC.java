/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.gdc;

import java.util.List;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.shared.functional.types.functional.mediaBox.PfeSvc;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

/**
 *
 * @author mbaptist
 * @version ($Revision$ $Date$)
 */
public interface IGDC
{
  /**
   * Retourne liste de plateforme à partir d'un PFI
   *
   * @param tracabilite_p
   *          le Tracabilite
   * @param pfi_p
   *          le PFI associé aux plateformes
   * @return Plateformes list
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  ConnectorResponse<List<String>, Retour> gdc001ConsultListePfFromPfi(Tracabilite tracabilite_p, String pfi_p) throws RavelException;

  /**
   * @param tracabilite_p
   * @param pfi_p
   * @return
   * @throws RavelException
   */
  ConnectorResponse<Boolean, Retour> checkPfiMigre(Tracabilite tracabilite_p, String pfi_p) throws RavelException;

  /**
   * Ce connecteur permet d'inhiber dans le référentiel GDC, table PFESVC, l'entrée associée à la messagerie STW d'un
   * abonné mobile identifié par son identifiant PFI (portefeuille individuel de services). L'inhibition consiste à
   * préfixer l'identifiant de PFI avec le caractère 'M' afin qu'elle ne soit plus vue comme attachée au portefeuille
   * individuel de services de l'abonné lorsque la messagerie de l'abonné a été migrée avec succès vers la nouvelle
   * messagerie VSTW.
   *
   * @param tracabilite_p
   * @param pfeSvc_p
   * @return
   * @throws RavelException
   */
  ConnectorResponse<Nothing, Retour> migrerPfiGdcStwVersVstw(Tracabilite tracabilite_p, PfeSvc pfeSvc_p) throws RavelException;

  /**
   * Ce connecteur permet d'annuler pour un abonné mobile identifié par son identifiant de PFI la migration de la
   * messagerie STW vers la messagerie VSTW. L'annulation consiste à supprimer l'entrée créée pour VSTW (à désinhiber
   * l'entrée pour la messagerie STW. L'inhibition avait consisté à préfixer l'identifiant de PFI de l'entrée pour STW
   * avec le caractère 'M' afin qu'elle ne soit plus vue comme attachée au portefeuille individuel de services de l'abonné
   * lorsque la messagerie de l'abonné a été migrée avec succès vers la nouvelle messagerie VSTW.
   *
   * @param tracabilite_p
   * @param pfeSvc_p
   * @return
   * @throws RavelException
   */
  ConnectorResponse<Nothing, Retour> annulerMigrerPfiGdcStwVersVstw(Tracabilite tracabilite_p, PfeSvc pfeSvc_p) throws RavelException;

  /**
   * Ce connecteur permet d'inhiber dans le référentiel GDC, table PFESVC, l'entrée associée à la messagerie STW d'un
   * abonné mobile identifié par son identifiant PFI (portefeuille individuel de services). L'inhibition consiste à
   * préfixer l'identifiant de PFI avec le caractère 'M' afin qu'elle ne soit plus vue comme attachée au portefeuille
   * individuel de services de l'abonné lorsque la messagerie de l'abonné a été migrée avec succès vers la nouvelle
   * messagerie VSTW.
   *
   * @param tracabilite_p
   * @param pfeSvc_p
   * @return
   * @throws RavelException
   */
  ConnectorResponse<Nothing, Retour> inhiberPfiGdcStw(Tracabilite tracabilite_p, PfeSvc pfeSvc_p) throws RavelException;
}