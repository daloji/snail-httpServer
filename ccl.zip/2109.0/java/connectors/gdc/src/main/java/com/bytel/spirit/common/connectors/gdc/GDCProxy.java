/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.gdc;

import java.util.List;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.probes.AvgDoubleCollectorItem;
import com.bytel.ravel.common.probes.AvgFlowPerSecondCollector;
import com.bytel.ravel.common.probes.RavelProbeConfigurationManager;
import com.bytel.ravel.services.connector.BaseDBProxy;
import com.bytel.ravel.services.connector.ConnectorExecution;
import com.bytel.ravel.services.connector.ConnectorManager;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.shared.functional.types.functional.mediaBox.PfeSvc;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

/**
 *
 * @author mbaptist
 * @version ($Revision$ $Date$)
 */
public class GDCProxy extends BaseDBProxy implements IGDC
{
  /**
   * Proxy instance.
   */
  private static final GDCProxy _instance = new GDCProxy();

  /**
   * Gets the single instance of GDCProxy.
   *
   * @return The proxy instance.
   */
  public static GDCProxy getInstance()
  {
    return GDCProxy._instance;
  }

  /**
   * Probe: measure the average execution time of the ps001ConsultListePfFromPfi call per second.
   */
  protected AvgFlowPerSecondCollector _avg_ps001ConsultListePfFromPfi_call_counter;
  /**
   * Probe: measure the average execution time of the ps001ConsultListePfFromPfi operation.
   */
  protected AvgDoubleCollectorItem _avg_ps001ConsultListePfFromPfi_ExecTime;

  /**
   * Probe: measure the average execution time of the ps001ConsultListePfFromPfi call per second.
   */
  protected AvgFlowPerSecondCollector _avg_checkPfiMigre_call_counter;
  /**
   * Probe: measure the average execution time of the ps001ConsultListePfFromPfi operation.
   */
  protected AvgDoubleCollectorItem _avg_checkPfiMigre_ExecTime;

  /**
   * Probe: measure the average execution time of the migrerPfiGdcStwVersVstw call per second.
   */
  protected AvgFlowPerSecondCollector _avg_migrerPfiGdcStwVersVstw_call_counter;
  /**
   * Probe: measure the average execution time of the migrerPfiGdcStwVersVstw operation.
   */
  protected AvgDoubleCollectorItem _avg_migrerPfiGdcStwVersVstw_ExecTime;

  /**
   * Probe: measure the average execution time of the annulerMigrerPfiGdcStwVersVstw call per second.
   */
  protected AvgFlowPerSecondCollector _avg_annulerMigrerPfiGdcStwVersVstw_call_counter;
  /**
   * Probe: measure the average execution time of the annulerMigrerPfiGdcStwVersVstw operation.
   */
  protected AvgDoubleCollectorItem _avg_annulerMigrerPfiGdcStwVersVstw_ExecTime;
  /**
   * Probe: measure the average execution time of the inhiberPfiGdcStw call per second.
   */
  protected AvgFlowPerSecondCollector _avg_inhiberPfiGdcStw_call_counter;
  /**
   * Probe: measure the average execution time of the inhiberPfiGdcStw operation.
   */
  protected AvgDoubleCollectorItem _avg_inhiberPfiGdcStw_ExecTime;

  /**
   * Default constructor.
   */
  public GDCProxy()
  {
    // probes
    _avg_ps001ConsultListePfFromPfi_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_ps001ConsultListePfFromPfi_call_per_second", "GDCProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_ps001ConsultListePfFromPfi_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_ps001ConsultListePfFromPfi_ExecTime", "GDCProxy"); //$NON-NLS-1$ //$NON-NLS-2$

    _avg_checkPfiMigre_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_CheckPfiMigre_call_per_second", "GDCProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_checkPfiMigre_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_CheckPfiMigre_ExecTime", "GDCProxy"); //$NON-NLS-1$ //$NON-NLS-2$

    _avg_migrerPfiGdcStwVersVstw_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_migrerPfiGdcStwVersVstw_call_per_second", "GDCProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_migrerPfiGdcStwVersVstw_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_migrerPfiGdcStwVersVstw_ExecTime", "GDCProxy"); //$NON-NLS-1$ //$NON-NLS-2$

    _avg_annulerMigrerPfiGdcStwVersVstw_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_annulerMigrerPfiGdcStwVersVstw_call_per_second", "GDCProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_annulerMigrerPfiGdcStwVersVstw_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_annulerMigrerPfiGdcStwVersVstw_ExecTime", "GDCProxy"); //$NON-NLS-1$ //$NON-NLS-2$

    _avg_inhiberPfiGdcStw_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_inhiberPfiGdcStw_call_per_second", "GDCProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_inhiberPfiGdcStw_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_inhiberPfiGdcStw_ExecTime", "GDCProxy"); //$NON-NLS-1$ //$NON-NLS-2$
  }

  @Override
  public ConnectorResponse<Boolean, Retour> checkPfiMigre(Tracabilite tracabilite_p, String pfi_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Boolean, Retour>>(IGDCConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Boolean, Retour> run() throws RavelException
      {
        IGDCConnector gdcConnector = (IGDCConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        // probes
        _avg_checkPfiMigre_call_counter.measure();
        //probes
        long startTime = System.currentTimeMillis();

        ConnectorResponse<Boolean, Retour> response;

        try
        {
          response = gdcConnector.checkPfiMigre(tracabilite_p, pfi_p);
        }
        finally
        {
          Long endTime = System.currentTimeMillis();
          //probes
          _avg_checkPfiMigre_ExecTime.updateAvgValue(endTime - startTime);
        }

        return response;
      }

    });
  }

  @Override
  public ConnectorResponse<List<String>, Retour> gdc001ConsultListePfFromPfi(Tracabilite tracabilite_p, String pfi_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<List<String>, Retour>>(IGDCConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<List<String>, Retour> run() throws RavelException
      {
        IGDCConnector gdcConnector = (IGDCConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        // probes
        _avg_ps001ConsultListePfFromPfi_call_counter.measure();
        //probes
        long startTime = System.currentTimeMillis();

        ConnectorResponse<List<String>, Retour> response;

        try
        {
          response = gdcConnector.gdc001ConsultListePfFromPfi(tracabilite_p, pfi_p);
        }
        finally
        {
          Long endTime = System.currentTimeMillis();
          //probes
          _avg_ps001ConsultListePfFromPfi_ExecTime.updateAvgValue(endTime - startTime);
        }

        return response;
      }

    });
  }

  @Override
  public ConnectorResponse<Nothing, Retour> migrerPfiGdcStwVersVstw(Tracabilite tracabilite_p, PfeSvc pfeSvc_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Nothing, Retour>>(IGDCConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Nothing, Retour> run() throws RavelException
      {
        IGDCConnector gdcConnector = (IGDCConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        // probes
        _avg_migrerPfiGdcStwVersVstw_call_counter.measure();
        //probes
        long startTime = System.currentTimeMillis();

        ConnectorResponse<Nothing, Retour> response;

        try
        {
          response = gdcConnector.migrerPfiGdcStwVersVstw(tracabilite_p, pfeSvc_p);
        }
        finally
        {
          Long endTime = System.currentTimeMillis();
          //probes
          _avg_migrerPfiGdcStwVersVstw_ExecTime.updateAvgValue(endTime - startTime);
        }

        return response;
      }

    });
  }

  @Override
  public ConnectorResponse<Nothing, Retour> annulerMigrerPfiGdcStwVersVstw(Tracabilite tracabilite_p, PfeSvc pfeSvc_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Nothing, Retour>>(IGDCConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Nothing, Retour> run() throws RavelException
      {
        IGDCConnector gdcConnector = (IGDCConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        // probes
        _avg_annulerMigrerPfiGdcStwVersVstw_call_counter.measure();
        //probes
        long startTime = System.currentTimeMillis();

        ConnectorResponse<Nothing, Retour> response;

        try
        {
          response = gdcConnector.annulerMigrerPfiGdcStwVersVstw(tracabilite_p, pfeSvc_p);
        }
        finally
        {
          Long endTime = System.currentTimeMillis();
          //probes
          _avg_annulerMigrerPfiGdcStwVersVstw_ExecTime.updateAvgValue(endTime - startTime);
        }

        return response;
      }

    });
  }

  @Override
  public ConnectorResponse<Nothing, Retour> inhiberPfiGdcStw(Tracabilite tracabilite_p, PfeSvc pfeSvc_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Nothing, Retour>>(IGDCConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Nothing, Retour> run() throws RavelException
      {
        IGDCConnector gdcConnector = (IGDCConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        // probes
        _avg_inhiberPfiGdcStw_call_counter.measure();
        //probes
        long startTime = System.currentTimeMillis();

        ConnectorResponse<Nothing, Retour> response;

        try
        {
          response = gdcConnector.inhiberPfiGdcStw(tracabilite_p, pfeSvc_p);
        }
        finally
        {
          Long endTime = System.currentTimeMillis();
          //probes
          _avg_inhiberPfiGdcStw_ExecTime.updateAvgValue(endTime - startTime);
        }

        return response;
      }

    });
  }

}