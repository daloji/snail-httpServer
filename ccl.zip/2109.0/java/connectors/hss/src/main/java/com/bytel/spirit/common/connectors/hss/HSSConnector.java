/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.hss;

import java.security.GeneralSecurityException;
import java.text.MessageFormat;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.StringJoiner;

import javax.net.ssl.SSLContext;

import com.bytel.ravel.common.conf.generated.Param;
import com.bytel.ravel.common.encryption.PasswordDecrypter;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionTools;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.services.conf.connector.generated.Connector;
import com.bytel.ravel.services.connector.AbstractConnector;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.connectors.hss.structs.EtatEnum;
import com.bytel.spirit.common.connectors.hss.structs.ServicesHSSE;
import com.bytel.spirit.common.connectors.hss.structs.StHsseBarringRoa;
import com.bytel.spirit.common.connectors.hss.structs.StHsseNam;
import com.bytel.spirit.common.connectors.hss.structs.StHssePdpContext;
import com.bytel.spirit.common.connectors.hss.structs.StHsseUser;
import com.bytel.spirit.common.connectors.hss.structs.StHssiSubscriberSvcProf;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.unboundid.ldap.sdk.BindResult;
import com.unboundid.ldap.sdk.ExtendedResult;
import com.unboundid.ldap.sdk.LDAPConnection;
import com.unboundid.ldap.sdk.LDAPConnectionOptions;
import com.unboundid.ldap.sdk.LDAPConnectionPool;
import com.unboundid.ldap.sdk.LDAPException;
import com.unboundid.ldap.sdk.LDAPSearchException;
import com.unboundid.ldap.sdk.ResultCode;
import com.unboundid.ldap.sdk.SearchResult;
import com.unboundid.ldap.sdk.SearchResultEntry;
import com.unboundid.ldap.sdk.SearchScope;
import com.unboundid.ldap.sdk.SimpleBindRequest;
import com.unboundid.ldap.sdk.StartTLSPostConnectProcessor;
import com.unboundid.ldap.sdk.extensions.StartTLSExtendedRequest;
import com.unboundid.util.ssl.SSLUtil;
import com.unboundid.util.ssl.TrustAllTrustManager;

/**
 * HSS connector that implements LDAP(StartTLS) operations.
 *
 * @author jjoly
 * @version ($Revision$ $Date$)
 */
public class HSSConnector extends AbstractConnector implements IHSSConnector
{
  /**
   * The enumeration ParameterName. <br>
   * Names of the parameters for the connector. <br>
   * Parameter values should be defined in the connectors configuration file.
   */
  private enum ParameterName
  {
    /**
     * Ldap server host
     */
    HOST,

    /**
     * Ldap server port
     */
    PORT,

    /**
     * Connection pool size
     */
    POOLSIZE,

    /**
     * STARTTLS extended operation to secure connections
     */
    STARTTLS,

    /**
     * LDAPSEARCH HSSE base dn
     */
    LDAPSEARCH_HSSE_BASE_DN,

    /**
     * LDAPSEARCH HSSE filter
     */
    LDAPSEARCH_HSSE_FILTER,

    /**
     * LDAPSEARCH HSSE attributes
     */
    LDAPSEARCH_HSSE_ATTRIBUTES,

    /**
     * LDAPSEARCH HSSI base dn
     */
    LDAPSEARCH_HSSI_BASE_DN,

    /**
     * LDAPSEARCH HSSI filter
     */
    LDAPSEARCH_HSSI_FILTER,

    /**
     * LDAPSEARCH HSSI attributes
     */
    LDAPSEARCH_HSSI_ATTRIBUTES,

    /**
     * Bind DN for simple authentication
     */
    BIND_DN,

    /**
     * Bind pwd for simple authentication
     */
    BIND_PASSWORD,

    /**
     * ldapsearch timeout in ms
     */
    CONNECT_TIMEOUT_MS,

    /**
     * Timeout
     */
    RESPONSE_TIMEOUT_MS;
  }

  /**
   * Constant EsmIndividualDefaultContextID for parameter ST_HSSE_USER
   */
  private static final String ATTR_NAME_DEFCONTEXTID = "HSS-EsmIndividualDefaultContextID"; //$NON-NLS-1$

  /**
   * Constant EsmLocationState for parameter ST_HSSE_USER
   */
  private static final String ATTR_NAME_LOCATION_STATE = "HSS-EsmLocationState"; //$NON-NLS-1$

  /**
   * Constant EsmMmeAddress for parameter ST_HSSE_USER
   */
  private static final String ATTR_NAME_MME_ADDRESS = "HSS-EsmMmeAddress"; //$NON-NLS-1$

  /**
   * Constant EsmOdb for parameter ST_HSSE_USER
   */
  private static final String ATTR_NAME_ODB = "HSS-EsmOdb"; //$NON-NLS-1$

  /**
   * Constant EsmDynPdnGwInfo for parameter ST_HSSE_USER
   */
  private static final String ATTR_NAME_PDN_GATEWAYS = "HSS-EsmDynPdnGwInfo"; //$NON-NLS-1$

  /**
   * Constant PROFILE_ID for parameter ST_HSSE_USER
   */
  private static final String PARAM_NAME_PROFILE_ID = "PROFILE_ID"; //$NON-NLS-1$

  /**
   * Constant EsmIndividualContextIdList for parameter ST_HSSE_PDPCONTEXT
   */
  private static final String ATTR_NAME_CONTEXTID = "HSS-EsmIndividualContextIdList"; //$NON-NLS-1$

  /**
   * Constant EsmAccessRestrictions for parameter ST_HSSE_NAM
   */
  private static final String ATTR_NAME_ACCESSRSTR = "HSS-EsmAccessRestrictions"; //$NON-NLS-1$

  /**
   * Constant EsmRoamingRestriction for parameter ST_HSSE_BARRING_ROA
   */
  private static final String ATTR_NAME_ROAMINGRSTR = "HSS-EsmRoamingRestriction"; //$NON-NLS-1$

  /**
   * Constant EsmRoamingAllowed for parameter ST_HSSE_BARRING_ROA
   */
  private static final String ATTR_NAME_ROAMINGALLWD = "HSS-EsmRoamingAllowed"; //$NON-NLS-1$

  /**
   * Constant ConfiguredServiceProfiles ConfiguredServiceProfiles for parameter ST_HSSI_SUBSCRIBER_SVC_Prof
   */
  private static final String ATT_NAME_HSS_CONFIGURED_SERVICE_PROFILES = "HSS-ConfiguredServiceProfiles"; //$NON-NLS-1$

  /**
   * The loaded connector parameters.
   */
  private Map<ParameterName, String> _parameters = new EnumMap<>(ParameterName.class);

  /**
   * LDAP server host
   */
  private String _host;

  /**
   * LDAP server non secured port (389 by default)
   */
  private Integer _port;

  /**
   * BIND password for simple authentication
   */
  private String _bindPassword;

  /**
   * BIND DN for simple authentication
   */
  private String _bindDn;

  /**
   * LDAP connection pool size
   */
  private Integer _poolSize;

  /**
   * true if connections must be secured by sending the extended STARTTLS request, false for unsecured connections.
   */
  private Boolean _startTLS;

  /**
   * LDAP connection pool
   */
  private LDAPConnectionPool _pool;

  /**
   * Connect timeout in ms
   */
  private Integer _connectTimeout;

  /**
   * Response timeout in ms
   */
  private Long _responseTimeout;

  /**
   * LDAPSEARCH hsse base dn
   */
  private String _ldapSearchHsseBaseDn;

  /**
   * LDAPSEARCH hsse filter
   */
  private String _ldapSearchHsseFilter;

  /**
   * LDAPSEARCH hssi base dn
   */
  private String _ldapSearchHssiBaseDn;

  /**
   * LDAPSEARCH hssi filter
   */
  private String _ldapSearchHssiFilter;

  @Override
  public void clean() throws RavelException
  {
    if (_pool != null)
    {
      /**
       * Closes this connection pool. All connections currently held in the pool that are not in use will be closed, and
       * any outstanding connections will be automatically closed when they are released back to the pool.
       */
      _pool.close();
    }
  }

  @Override
  public ConnectorResponse<ServicesHSSE, Boolean> consulterProfilHSSE(final Tracabilite tracabilite_p, final String imsi_p) throws RavelException
  {
    final StHsseUser stHsseUser = new StHsseUser();
    stHsseUser.setEtat(EtatEnum.INACTIF);

    final StHssePdpContext stHssePdpContext = new StHssePdpContext();
    stHssePdpContext.setEtat(EtatEnum.INACTIF);

    final StHsseNam stHsseNam = new StHsseNam();
    stHsseNam.setEtat(EtatEnum.INACTIF);

    final StHsseBarringRoa stHsseBarringRoa = new StHsseBarringRoa();
    stHsseBarringRoa.setEtat(EtatEnum.INACTIF);

    // Retrieves an LDAP connection from the pool.
    try (LDAPConnection connection = _pool.getConnection())
    {
      final String baseDN = MessageFormat.format(_ldapSearchHsseBaseDn, imsi_p, imsi_p);
      final SearchResult searchResult = connection.search(baseDN, SearchScope.SUB, _ldapSearchHsseFilter);
      if (!ResultCode.SUCCESS.equals(searchResult.getResultCode()))
      {
        throw new LDAPSearchException(searchResult);
      }

      // Récupération de l'objet HSS-EsmUser
      final SearchResultEntry searchResultEntry = searchResult.getSearchEntry(baseDN);
      if (searchResultEntry != null)
      {
        //S T_HSSE_USER
        if (searchResultEntry.hasAttribute(ATTR_NAME_DEFCONTEXTID) || searchResultEntry.hasAttribute(ATTR_NAME_LOCATION_STATE) || searchResultEntry.hasAttribute(ATTR_NAME_MME_ADDRESS) || searchResultEntry.hasAttribute(ATTR_NAME_ODB) || searchResultEntry.hasAttribute(ATTR_NAME_PDN_GATEWAYS) || searchResultEntry.hasAttribute(PARAM_NAME_PROFILE_ID))
        {
          stHsseUser.setEtat(EtatEnum.ACTIF);
          stHsseUser.setDefContextId(searchResultEntry.getAttributeValue(ATTR_NAME_DEFCONTEXTID));
          stHsseUser.setLocationState(searchResultEntry.getAttributeValue(ATTR_NAME_LOCATION_STATE));
          stHsseUser.setMmeAddress(searchResultEntry.getAttributeValue(ATTR_NAME_MME_ADDRESS));
          stHsseUser.setOdb(searchResultEntry.getAttributeValue(ATTR_NAME_ODB));
          stHsseUser.setPdnGateways(searchResultEntry.getAttributeValue(ATTR_NAME_PDN_GATEWAYS));
          stHsseUser.setProfileId(searchResultEntry.getAttributeValue(PARAM_NAME_PROFILE_ID));
        }

        // ST_HSSE_PDPCONTEXT
        if (searchResultEntry.hasAttribute(ATTR_NAME_CONTEXTID))
        {
          final StringJoiner joiner = new StringJoiner(" "); //$NON-NLS-1$
          for (String contextId : searchResultEntry.getAttributeValues(ATTR_NAME_CONTEXTID))
          {
            joiner.add(contextId);
          }

          stHssePdpContext.setEtat(EtatEnum.ACTIF);
          stHssePdpContext.setContextId(joiner.toString());
        }

        // ST_HSSE_NAM
        if (searchResultEntry.hasAttribute(ATTR_NAME_ACCESSRSTR))
        {
          stHsseNam.setEtat(EtatEnum.ACTIF);
          stHsseNam.setAccessrstr(searchResultEntry.getAttributeValue(ATTR_NAME_ACCESSRSTR));
        }

        // ST_HSSE_BARRING_ROA
        if (searchResultEntry.hasAttribute(ATTR_NAME_ROAMINGRSTR) || searchResultEntry.hasAttribute(ATTR_NAME_ROAMINGALLWD))
        {
          stHsseBarringRoa.setEtat(EtatEnum.ACTIF);
          stHsseBarringRoa.setRoamingAllowed(searchResultEntry.getAttributeValue(ATTR_NAME_ROAMINGALLWD));
          stHsseBarringRoa.setRoamingRestriction(searchResultEntry.getAttributeValue(ATTR_NAME_ROAMINGRSTR));
        }
      }

      return new ConnectorResponse<>(new ServicesHSSE(stHsseUser, stHssePdpContext, stHsseNam, stHsseBarringRoa), true);
    }
    catch (final LDAPSearchException exception)
    {
      if (ResultCode.NO_SUCH_OBJECT.equals(exception.getResultCode()))
      {
        RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, MessageFormat.format(Messages.getString("HSSConnector.imsiNotFound"), imsi_p))); //$NON-NLS-1$
        return new ConnectorResponse<>(new ServicesHSSE(stHsseUser, stHssePdpContext, stHsseNam, stHsseBarringRoa), false);
      }

      throw buildTechnicalException(exception, tracabilite_p, "consulterProfilHSSE"); //$NON-NLS-1$
    }
    catch (final LDAPException exception)
    {
      throw buildTechnicalException(exception, tracabilite_p, "consulterProfilHSSE"); //$NON-NLS-1$
    }
  }

  @Override
  public ConnectorResponse<StHssiSubscriberSvcProf, Boolean> consulterProfilHSSI(final Tracabilite tracabilite_p, final String subscriberId_p) throws RavelException
  {
    final StHssiSubscriberSvcProf stHssiSubscriberSvcProf = new StHssiSubscriberSvcProf();
    stHssiSubscriberSvcProf.setEtat(EtatEnum.INACTIF);

    // Retrieves an LDAP connection from the pool.
    try (LDAPConnection connection = _pool.getConnection())
    {
      String baseDN = MessageFormat.format(_ldapSearchHssiBaseDn, subscriberId_p);
      SearchResult searchResult = connection.search(baseDN, SearchScope.SUB, _ldapSearchHssiFilter);
      if (!ResultCode.SUCCESS.equals(searchResult.getResultCode()))
      {
        throw new LDAPSearchException(searchResult);
      }

      // Récupération de l'objet HSS-EsmUser
      final List<SearchResultEntry> searchResultEntries = searchResult.getSearchEntries();
      if (searchResultEntries != null)
      {
        for (SearchResultEntry searchResultEntry : searchResultEntries)
        {
          // ST_HSSE_USER
          if (searchResultEntry.hasAttribute(ATT_NAME_HSS_CONFIGURED_SERVICE_PROFILES))
          {
            stHssiSubscriberSvcProf.setEtat(EtatEnum.ACTIF);
            stHssiSubscriberSvcProf.setCfgSvcProfile1(searchResultEntry.getAttributeValue(ATT_NAME_HSS_CONFIGURED_SERVICE_PROFILES));
            break;
          }
        }
      }

      return new ConnectorResponse<>(stHssiSubscriberSvcProf, true);
    }
    catch (final LDAPSearchException exception)
    {
      if (ResultCode.NO_SUCH_OBJECT.equals(exception.getResultCode()))
      {
        RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, MessageFormat.format(Messages.getString("HSSConnector.subscriberIDNotFound"), subscriberId_p))); //$NON-NLS-1$
        return new ConnectorResponse<>(stHssiSubscriberSvcProf, false);
      }

      throw buildTechnicalException(exception, tracabilite_p, "consulterProfilHSSI"); //$NON-NLS-1$
    }
    catch (final LDAPException exception)
    {
      throw buildTechnicalException(exception, tracabilite_p, "consulterProfilHSSI"); //$NON-NLS-1$
    }
  }

  @Override
  public String getConfigParameter(final String connectorID_p, final String paramName_p) throws RavelException
  {
    // TODO Auto-generated method stub
    return null;
  }

  @Override
  public void loadConnectorConfiguration(final Connector connector_p) throws RavelException
  {
    _name = connector_p.getName();
    _enabled = connector_p.isEnabled();

    for (Param parameter : connector_p.getParam())
    {
      final ParameterName parameterName = ParameterName.valueOf(parameter.getName().toUpperCase());
      if (parameterName != null)
      {
        _parameters.put(parameterName, parameter.getValue());
      }
    }

    try
    {
      checkParameters();
      createLDAPConnectionPool();
    }
    catch (final Exception ex)
    {
      throw new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(Messages.getString("HSSConnector.INITIALIZE_ERROR"), ex.getMessage())); //$NON-NLS-1$
    }
  }

  /**
   * Build a log entry and throws an {@link RavelException} for a technical problem.
   *
   * @param exception_p
   *          exception from connector Hss
   * @param tracabilite_
   *          The tracabilite
   * @param method_p
   *          The method name in which the fault was raised.
   * @return The {@link RavelException} built
   */
  private RavelException buildTechnicalException(final Exception exception_p, final Tracabilite tracabilite_, final String method_p)
  {
    final String message = MessageFormat.format(Messages.getString("HSSConnector.TechnicalExceptionMessage"), method_p, StringConstants.EMPTY_STRING, exception_p.getMessage()); //$NON-NLS-1$
    RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_, message + ExceptionTools.getExceptionLineAndFile(exception_p)));
    RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_, Messages.getString("HSSConnector.ExceptionType") + exception_p.getClass().toString())); //$NON-NLS-1$
    RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_, new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, "Technical Exception", exception_p))); //$NON-NLS-1$

    return new RavelException(ExceptionType.CONNECTOR_DATA_VALIDATION_ERROR, ErrorCode.CNCTOR_00010, message, IHSSConnector.BEAN_ID, exception_p);
  }

  /**
   * Check the configuration parameters.
   *
   * @throws RavelException
   *           if a parameter is missing or invalid
   *
   */
  private void checkParameters() throws RavelException
  {
    final Set<ParameterName> parametersKeys = _parameters.keySet();
    if (!parametersKeys.contains(ParameterName.HOST))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(Messages.getString("HSSConnector.MissingParameter"), _name, ParameterName.HOST.toString())); //$NON-NLS-1$
    }
    _host = _parameters.get(ParameterName.HOST);

    if (!parametersKeys.contains(ParameterName.PORT))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(Messages.getString("HSSConnector.MissingParameter"), _name, ParameterName.PORT.toString())); //$NON-NLS-1$
    }

    try
    {
      _port = Integer.parseInt(_parameters.get(ParameterName.PORT));
      if (_port <= 0)
      {
        throw new NumberFormatException();
      }
    }
    catch (final NumberFormatException ex)
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(Messages.getString("HSSConnector.InvalidParamValue"), _parameters.get(ParameterName.PORT), ParameterName.PORT.toString(), "integer value expected")); //$NON-NLS-1$ //$NON-NLS-2$
    }

    if (!parametersKeys.contains(ParameterName.POOLSIZE))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(Messages.getString("HSSConnector.MissingParameter"), _name, ParameterName.POOLSIZE.toString())); //$NON-NLS-1$
    }

    try
    {
      _poolSize = Integer.parseInt(_parameters.get(ParameterName.POOLSIZE));
      if (_poolSize <= 0)
      {
        throw new NumberFormatException();
      }
    }
    catch (final NumberFormatException ex)
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(Messages.getString("HSSConnector.InvalidParamValue"), _parameters.get(ParameterName.POOLSIZE), ParameterName.POOLSIZE.toString(), "integer value expected")); //$NON-NLS-1$ //$NON-NLS-2$
    }

    if (!parametersKeys.contains(ParameterName.STARTTLS))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(Messages.getString("HSSConnector.MissingParameter"), _name, ParameterName.STARTTLS.toString())); //$NON-NLS-1$
    }

    _startTLS = Boolean.parseBoolean(_parameters.get(ParameterName.STARTTLS));

    if (!parametersKeys.contains(ParameterName.LDAPSEARCH_HSSE_BASE_DN))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(Messages.getString("HSSConnector.MissingParameter"), _name, ParameterName.LDAPSEARCH_HSSE_BASE_DN.toString())); //$NON-NLS-1$
    }
    _ldapSearchHsseBaseDn = _parameters.get(ParameterName.LDAPSEARCH_HSSE_BASE_DN);

    if (!parametersKeys.contains(ParameterName.LDAPSEARCH_HSSE_FILTER))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(Messages.getString("HSSConnector.MissingParameter"), _name, ParameterName.LDAPSEARCH_HSSE_FILTER.toString())); //$NON-NLS-1$
    }
    _ldapSearchHsseFilter = _parameters.get(ParameterName.LDAPSEARCH_HSSE_FILTER);

    if (!parametersKeys.contains(ParameterName.LDAPSEARCH_HSSI_BASE_DN))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(Messages.getString("HSSConnector.MissingParameter"), _name, ParameterName.LDAPSEARCH_HSSI_BASE_DN.toString())); //$NON-NLS-1$
    }
    _ldapSearchHssiBaseDn = _parameters.get(ParameterName.LDAPSEARCH_HSSI_BASE_DN);

    if (!parametersKeys.contains(ParameterName.LDAPSEARCH_HSSI_FILTER))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(Messages.getString("HSSConnector.MissingParameter"), _name, ParameterName.LDAPSEARCH_HSSI_FILTER.toString())); //$NON-NLS-1$
    }
    _ldapSearchHssiFilter = _parameters.get(ParameterName.LDAPSEARCH_HSSI_FILTER);

    if (!parametersKeys.contains(ParameterName.BIND_DN))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(Messages.getString("HSSConnector.MissingParameter"), _name, ParameterName.BIND_DN.toString())); //$NON-NLS-1$
    }
    _bindDn = _parameters.get(ParameterName.BIND_DN);

    if (!parametersKeys.contains(ParameterName.BIND_PASSWORD))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(Messages.getString("HSSConnector.MissingParameter"), _name, ParameterName.BIND_PASSWORD.toString())); //$NON-NLS-1$
    }

    try
    {
      _bindPassword = PasswordDecrypter.decrypt(_parameters.get(ParameterName.BIND_PASSWORD));
    }
    catch (Exception ex)
    {
      throw new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.CNCTOR_00010, Messages.getString("HSSConnector.PasswordError")); //$NON-NLS-1$
    }

    if (!parametersKeys.contains(ParameterName.CONNECT_TIMEOUT_MS))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(Messages.getString("HSSConnector.MissingParameter"), _name, ParameterName.CONNECT_TIMEOUT_MS.toString())); //$NON-NLS-1$
    }

    try
    {
      _connectTimeout = Integer.parseInt(_parameters.get(ParameterName.CONNECT_TIMEOUT_MS));
      if (_connectTimeout <= 0)
      {
        throw new NumberFormatException();
      }
    }
    catch (final NumberFormatException ex)
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(Messages.getString("HSSConnector.InvalidParamValue"), _parameters.get(ParameterName.CONNECT_TIMEOUT_MS), ParameterName.CONNECT_TIMEOUT_MS.toString(), "positive integer value expected")); //$NON-NLS-1$ //$NON-NLS-2$
    }

    if (!parametersKeys.contains(ParameterName.RESPONSE_TIMEOUT_MS))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(Messages.getString("HSSConnector.MissingParameter"), _name, ParameterName.RESPONSE_TIMEOUT_MS.toString())); //$NON-NLS-1$
    }

    try
    {
      _responseTimeout = Long.parseLong(_parameters.get(ParameterName.RESPONSE_TIMEOUT_MS));
      if (_responseTimeout <= 0L)
      {
        throw new NumberFormatException();
      }
    }
    catch (final NumberFormatException ex)
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(Messages.getString("HSSConnector.InvalidParamValue"), _parameters.get(ParameterName.RESPONSE_TIMEOUT_MS), ParameterName.RESPONSE_TIMEOUT_MS.toString(), "positive integer value expected")); //$NON-NLS-1$ //$NON-NLS-2$
    }
  }

  /**
   * Open connections and create the pool.
   *
   * @throws GeneralSecurityException
   *           If a problem occurs while creating or initializing the SSL context.
   * @throws LDAPException
   *           If a problem occurs while attempting to connect to the specified server.
   *
   */
  private void createLDAPConnectionPool() throws GeneralSecurityException, LDAPException
  {
    final LDAPConnectionOptions opt = new LDAPConnectionOptions();
    opt.setConnectTimeoutMillis(_connectTimeout);
    opt.setAbandonOnTimeout(true); // By default, no abandon request will be sent
    opt.setResponseTimeoutMillis(_responseTimeout);

    // Establish an insecure connection to the directory server.
    try (LDAPConnection connection = new LDAPConnection(opt, _host, _port))
    {
      // Configure an SSLUtil instance and use it to obtain an SSLContext.
      final SSLUtil sslUtil = new SSLUtil(new TrustAllTrustManager());
      final SSLContext sslContext = sslUtil.createSSLContext();
      if (_startTLS)
      {
        // Use the StartTLS extended operation to secure the connection.
        final ExtendedResult startTLSResult = connection.processExtendedOperation(new StartTLSExtendedRequest(sslContext));
        if (!ResultCode.SUCCESS.equals(startTLSResult.getResultCode()))
        {
          throw new LDAPException(startTLSResult);
        }
      }

      // Send the bind request for simple authentication
      final BindResult bindResult = connection.bind(new SimpleBindRequest(_bindDn, _bindPassword));
      if (!ResultCode.SUCCESS.equals(bindResult.getResultCode()))
      {
        throw new LDAPException(bindResult);
      }

      if (_startTLS)
      {
        // Create a connection pool that will secure its connections with StartTLS.
        StartTLSPostConnectProcessor startTLSProcessor = new StartTLSPostConnectProcessor(sslContext);
        _pool = new LDAPConnectionPool(connection, 1, _poolSize, startTLSProcessor);
      }
      else
      {
        // Create a connection pool with unsecured connections
        _pool = new LDAPConnectionPool(connection, _poolSize);
      }
    }
  }
}
