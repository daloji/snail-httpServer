/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.hss;

import java.time.Duration;
import java.time.Instant;

import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.probes.AvgDoubleCollectorItem;
import com.bytel.ravel.common.probes.AvgFlowPerSecondCollector;
import com.bytel.ravel.common.probes.RavelProbeConfigurationManager;
import com.bytel.ravel.services.connector.BaseProxy;
import com.bytel.ravel.services.connector.ConnectorExecution;
import com.bytel.ravel.services.connector.ConnectorManager;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.connectors.hss.structs.ServicesHSSE;
import com.bytel.spirit.common.connectors.hss.structs.StHssiSubscriberSvcProf;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

/**
 * HSS connector proxy
 *
 * @author jjoly
 * @version ($Revision$ $Date$)
 */
public class HSSProxy extends BaseProxy implements IHSS
{

  /**
   * Proxy instance.
   */
  private static final HSSProxy _instance = new HSSProxy();

  /**
   * Gets the single instance of HSSProxy.
   *
   * @return The proxy instance.
   */
  public static HSSProxy getInstance()
  {
    return HSSProxy._instance;
  }

  /**
   * Probe: measure the average number of consulterProfilHSSE call per second.
   */
  protected AvgFlowPerSecondCollector _avg_consulterProfilHSSE_call_counter;

  /**
   * Probe: measure the average execution time of the consultDonnesClientHSSE operation.
   */
  protected AvgDoubleCollectorItem _avg_consulterProfilHSSE_ExecTime;

  /**
   * Probe: measure the average number of consulterProfilHSSI call per second.
   */
  protected AvgFlowPerSecondCollector _avg_consulterProfilHSSI_call_counter;

  /**
   * Probe: measure the average execution time of the consultDonnesClientHSSI operation.
   */
  protected AvgDoubleCollectorItem _avg_consulterProfilHSSI_ExecTime;

  /**
   * Default constructor.
   */
  public HSSProxy()
  {
    // probes
    _avg_consulterProfilHSSE_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_consulterProfilHSSE_call_counter", "HSSProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_consulterProfilHSSE_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_consulterProfilHSSE_ExecTime", "HSSProxy"); //$NON-NLS-1$ //$NON-NLS-2$

    _avg_consulterProfilHSSI_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_consulterProfilHSSI_call_counter", "HSSProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_consulterProfilHSSI_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_consulterProfilHSSI_ExecTime", "HSSProxy"); //$NON-NLS-1$ //$NON-NLS-2$
  }

  @Override
  public ConnectorResponse<ServicesHSSE, Boolean> consulterProfilHSSE(final Tracabilite tracabilite_p, final String imsi_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<ServicesHSSE, Boolean>>(IHSSConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<ServicesHSSE, Boolean> run() throws RavelException
      {
        IHSSConnector hssConnector = (IHSSConnector) ConnectorManager.getInstance().getConnector(_connectorId);

        _avg_consulterProfilHSSE_call_counter.measure();

        final Instant startTime = Instant.now();
        try
        {
          return hssConnector.consulterProfilHSSE(tracabilite_p, imsi_p);
        }
        finally
        {
          final Instant endTime = Instant.now();

          _avg_consulterProfilHSSE_ExecTime.updateAvgValue(Duration.between(startTime, endTime).toMillis());
        }
      }
    });
  }

  @Override
  public ConnectorResponse<StHssiSubscriberSvcProf, Boolean> consulterProfilHSSI(final Tracabilite tracabilite_p, final String subscriberID_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<StHssiSubscriberSvcProf, Boolean>>(IHSSConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<StHssiSubscriberSvcProf, Boolean> run() throws RavelException
      {
        IHSSConnector hssConnector = (IHSSConnector) ConnectorManager.getInstance().getConnector(_connectorId);

        _avg_consulterProfilHSSI_call_counter.measure();

        final Instant startTime = Instant.now();
        try
        {
          return hssConnector.consulterProfilHSSI(tracabilite_p, subscriberID_p);
        }
        finally
        {
          final Instant endTime = Instant.now();

          _avg_consulterProfilHSSI_ExecTime.updateAvgValue(Duration.between(startTime, endTime).toMillis());
        }
      }
    });
  }
}
