/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.hss.structs;

/**
 *
 * @author jjoly
 * @version ($Revision$ $Date$)
 */
public enum EtatEnum
{
  /**
   * ACTIF
   */
  ACTIF,
  /**
   * INACTIF
   */
  INACTIF;
}
