/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.hss.structs;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 *
 * @author dmonteir
 * @version ($Revision$ $Date$)
 */
public final class StHssePdpContext implements Serializable
{
  /**
   * Generated UID
   */
  private static final long serialVersionUID = 4025951805074398063L;

  /**
   * ST_HSSE_PDPCONTEXT
   */
  @SerializedName("etat")
  @Expose
  private EtatEnum _etat;

  /**
   * CONTEXTID
   */
  @SerializedName("CONTEXTID")
  @Expose
  private String _contextId;

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    StHssePdpContext other = (StHssePdpContext) obj;
    if (_contextId == null)
    {
      if (other._contextId != null)
      {
        return false;
      }
    }
    else if (!_contextId.equals(other._contextId))
    {
      return false;
    }
    if (_etat != other._etat)
    {
      return false;
    }
    return true;
  }

  /**
   * @return the contextId
   */
  public String getContextId()
  {
    return _contextId;
  }

  /**
   * @return the etat
   */
  public EtatEnum getEtat()
  {
    return _etat;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_contextId == null) ? 0 : _contextId.hashCode());
    result = (prime * result) + ((_etat == null) ? 0 : _etat.hashCode());
    return result;
  }

  /**
   * @param contextId_p
   *          the contextId to set
   */
  public void setContextId(String contextId_p)
  {
    _contextId = contextId_p;
  }

  /**
   * @param etat_p
   *          the etat to set
   */
  public void setEtat(EtatEnum etat_p)
  {
    _etat = etat_p;
  }

  @Override
  public String toString()
  {
    StringBuilder builder = new StringBuilder();
    builder.append("StHssePdpContext [_etat="); //$NON-NLS-1$
    builder.append(_etat);
    builder.append(", _contextId="); //$NON-NLS-1$
    builder.append(_contextId);
    builder.append("]"); //$NON-NLS-1$
    return builder.toString();
  }
}
