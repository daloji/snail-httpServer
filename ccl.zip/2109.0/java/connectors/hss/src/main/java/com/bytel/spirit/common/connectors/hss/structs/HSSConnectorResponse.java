/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.hss.structs;

import java.io.Serializable;

import com.bytel.spirit.common.shared.misc.ressources.RetourTechnique;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 *
 * @author jjoly
 * @version ($Revision$ $Date$)
 */
public final class HSSConnectorResponse implements Serializable
{
  /**
   * Generated UID
   */
  private static final long serialVersionUID = 8983922132888101839L;

  /**
   * RetourTechnique
   */
  @SerializedName("retourTechnique")
  @Expose
  private RetourTechnique _retourTechnique;

  /**
   * Services
   */
  @SerializedName("Services")
  @Expose
  private Services _services;

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    HSSConnectorResponse other = (HSSConnectorResponse) obj;
    if (_retourTechnique == null)
    {
      if (other._retourTechnique != null)
      {
        return false;
      }
    }
    else if (!_retourTechnique.equals(other._retourTechnique))
    {
      return false;
    }
    if (_services == null)
    {
      if (other._services != null)
      {
        return false;
      }
    }
    else if (!_services.equals(other._services))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the retourTechnique
   */
  public RetourTechnique getRetourTechnique()
  {
    return _retourTechnique;
  }

  /**
   * @return the services
   */
  public Services getServices()
  {
    return _services;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_retourTechnique == null) ? 0 : _retourTechnique.hashCode());
    result = (prime * result) + ((_services == null) ? 0 : _services.hashCode());
    return result;
  }

  /**
   * @param retourTechnique_p
   *          the retourTechnique to set
   */
  public void setRetourTechnique(RetourTechnique retourTechnique_p)
  {
    _retourTechnique = retourTechnique_p;
  }

  /**
   * @param services_p
   *          the services to set
   */
  public void setServices(Services services_p)
  {
    _services = services_p;
  }

  @Override
  public String toString()
  {
    StringBuilder builder = new StringBuilder();
    builder.append("HSSConnectorResponse [_services=");
    builder.append(_services);
    builder.append("]");
    return builder.toString();
  }
}
