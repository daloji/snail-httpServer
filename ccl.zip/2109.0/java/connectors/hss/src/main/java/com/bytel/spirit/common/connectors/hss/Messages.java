package com.bytel.spirit.common.connectors.hss;

import java.util.MissingResourceException;
import java.util.ResourceBundle;

/**
 *
 * @author jjoly
 * @version ($Revision$ $Date$)
 */
public final class Messages
{
  /**
   * BUNDLE_NAME
   */
  private static final String BUNDLE_NAME = "com.bytel.spirit.common.connectors.hss.messages"; //$NON-NLS-1$

  /**
   * RESOURCE_BUNDLE
   */
  private static final ResourceBundle RESOURCE_BUNDLE = ResourceBundle.getBundle(Messages.BUNDLE_NAME);

  /**
   * Gets the string.
   *
   * @param key_p
   *          the key
   * @return the value
   */
  public static String getString(String key_p)
  {
    try
    {
      return Messages.RESOURCE_BUNDLE.getString(key_p);
    }
    catch (final MissingResourceException e)
    {
      return '!' + key_p + '!';
    }
  }

  /**
   * Default constructor
   */
  private Messages()
  {
    // Nothing to do
  }
}
