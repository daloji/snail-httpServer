/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.hss.structs;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 *
 * @author jjoly
 * @version ($Revision$ $Date$)
 */
public final class StHsseUser implements Serializable
{
  /**
   * Generated UID
   */
  private static final long serialVersionUID = -5461208210268953491L;

  /**
   * ST_HSSE_USER
   */
  @SerializedName("etat")
  @Expose
  private EtatEnum _etat;

  /**
   * DEFCONTEXTID
   */
  @SerializedName("DEFCONTEXTID")
  @Expose
  private String _defContextId;

  /**
   * LOCATION STATE
   */
  @SerializedName("LOCATION STATE")
  @Expose
  private String _locationState;

  /**
   * MME ADDRESS
   */
  @SerializedName("MME ADDRESS")
  @Expose
  private String _mmeAddress;

  /**
   * ODB
   */
  @SerializedName("ODB")
  @Expose
  private String _odb;

  /**
   * PDN GATEWAYS
   */
  @SerializedName("PDN GATEWAYS")
  @Expose
  String _pdnGateways;

  /**
   * PROFILE_ID
   */
  @SerializedName("PROFILE_ID")
  @Expose
  String _profileId;

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    StHsseUser other = (StHsseUser) obj;
    if (_defContextId == null)
    {
      if (other._defContextId != null)
      {
        return false;
      }
    }
    else if (!_defContextId.equals(other._defContextId))
    {
      return false;
    }
    if (_etat != other._etat)
    {
      return false;
    }
    if (_locationState == null)
    {
      if (other._locationState != null)
      {
        return false;
      }
    }
    else if (!_locationState.equals(other._locationState))
    {
      return false;
    }
    if (_mmeAddress == null)
    {
      if (other._mmeAddress != null)
      {
        return false;
      }
    }
    else if (!_mmeAddress.equals(other._mmeAddress))
    {
      return false;
    }
    if (_odb == null)
    {
      if (other._odb != null)
      {
        return false;
      }
    }
    else if (!_odb.equals(other._odb))
    {
      return false;
    }
    if (_pdnGateways == null)
    {
      if (other._pdnGateways != null)
      {
        return false;
      }
    }
    else if (!_pdnGateways.equals(other._pdnGateways))
    {
      return false;
    }
    if (_profileId == null)
    {
      if (other._profileId != null)
      {
        return false;
      }
    }
    else if (!_profileId.equals(other._profileId))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the defContextId
   */
  public String getDefContextId()
  {
    return _defContextId;
  }

  /**
   * @return the etat
   */
  public EtatEnum getEtat()
  {
    return _etat;
  }

  /**
   * @return the locationState
   */
  public String getLocationState()
  {
    return _locationState;
  }

  /**
   * @return the mmeAddress
   */
  public String getMmeAddress()
  {
    return _mmeAddress;
  }

  /**
   * @return the odb
   */
  public String getOdb()
  {
    return _odb;
  }

  /**
   * @return the pdnGateways
   */
  public String getPdnGateways()
  {
    return _pdnGateways;
  }

  /**
   * @return the profileId
   */
  public String getProfileId()
  {
    return _profileId;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_defContextId == null) ? 0 : _defContextId.hashCode());
    result = (prime * result) + ((_etat == null) ? 0 : _etat.hashCode());
    result = (prime * result) + ((_locationState == null) ? 0 : _locationState.hashCode());
    result = (prime * result) + ((_mmeAddress == null) ? 0 : _mmeAddress.hashCode());
    result = (prime * result) + ((_odb == null) ? 0 : _odb.hashCode());
    result = (prime * result) + ((_pdnGateways == null) ? 0 : _pdnGateways.hashCode());
    result = (prime * result) + ((_profileId == null) ? 0 : _profileId.hashCode());
    return result;
  }

  /**
   * @param defContextId_p
   *          the defContextId to set
   */
  public void setDefContextId(String defContextId_p)
  {
    _defContextId = defContextId_p;
  }

  /**
   * @param etat_p
   *          the etat to set
   */
  public void setEtat(EtatEnum etat_p)
  {
    _etat = etat_p;
  }

  /**
   * @param locationState_p
   *          the locationState to set
   */
  public void setLocationState(String locationState_p)
  {
    _locationState = locationState_p;
  }

  /**
   * @param mmeAddress_p
   *          the mmeAddress to set
   */
  public void setMmeAddress(String mmeAddress_p)
  {
    _mmeAddress = mmeAddress_p;
  }

  /**
   * @param odb_p
   *          the odb to set
   */
  public void setOdb(String odb_p)
  {
    _odb = odb_p;
  }

  /**
   * @param pdnGateways_p
   *          the pdnGateways to set
   */
  public void setPdnGateways(String pdnGateways_p)
  {
    _pdnGateways = pdnGateways_p;
  }

  /**
   * @param profileId_p
   *          the profileId to set
   */
  public void setProfileId(String profileId_p)
  {
    _profileId = profileId_p;
  }

  @Override
  public String toString()
  {
    StringBuilder builder = new StringBuilder();
    builder.append("StHsseUser [_etat="); //$NON-NLS-1$
    builder.append(_etat);
    builder.append(", _defContextId="); //$NON-NLS-1$
    builder.append(_defContextId);
    builder.append(", _locationState="); //$NON-NLS-1$
    builder.append(_locationState);
    builder.append(", _mmeAddress="); //$NON-NLS-1$
    builder.append(_mmeAddress);
    builder.append(", _odb="); //$NON-NLS-1$
    builder.append(_odb);
    builder.append(", _pdnGateways="); //$NON-NLS-1$
    builder.append(_pdnGateways);
    builder.append(", _profileId="); //$NON-NLS-1$
    builder.append(_profileId);
    builder.append("]"); //$NON-NLS-1$
    return builder.toString();
  }
}
