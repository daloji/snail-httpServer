/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.hss;

import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.connectors.hss.structs.ServicesHSSE;
import com.bytel.spirit.common.connectors.hss.structs.StHssiSubscriberSvcProf;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

/**
 * The Interface IHSS for HSS platform connection
 *
 * @author jjoly
 * @version ($Revision$ $Date$)
 */
public interface IHSS
{
  /**
   * Consultation du profil HSSE
   *
   * @param tracabilite_p
   *          The tracabilite
   * @param imsi_p
   *          imsi du client
   * @return The Services information and a Retour object with the result.
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   *
   */
  public ConnectorResponse<ServicesHSSE, Boolean> consulterProfilHSSE(final Tracabilite tracabilite_p, final String imsi_p) throws RavelException;

  /**
   * Consultation du profil HSSI
   *
   * @param tracabilite_p
   *          The tracabilite
   * @param subscriberID_p
   *          Subscriber ID du client
   * @return StHssiSubscriberSvcProf object
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   *
   */
  public ConnectorResponse<StHssiSubscriberSvcProf, Boolean> consulterProfilHSSI(final Tracabilite tracabilite_p, final String subscriberID_p) throws RavelException;
}
