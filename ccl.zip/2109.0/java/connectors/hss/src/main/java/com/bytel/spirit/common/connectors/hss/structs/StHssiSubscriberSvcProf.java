/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.hss.structs;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 *
 * @author jjoly
 * @version ($Revision$ $Date$)
 */
public final class StHssiSubscriberSvcProf implements Serializable
{
  /**
   * Generated UID
   */
  private static final long serialVersionUID = 4650758811787834741L;

  /**
   * ST_HSSI_SUBSCRIBER_SVC_PROF
   */
  @SerializedName("etat")
  @Expose
  private EtatEnum _etat;

  /**
   * CFG_SVC_PROFILE_1
   */
  @SerializedName("CFG_SVC_PROFILE_1")
  @Expose
  private String _cfgSvcProfile1;

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    StHssiSubscriberSvcProf other = (StHssiSubscriberSvcProf) obj;
    if (_cfgSvcProfile1 == null)
    {
      if (other._cfgSvcProfile1 != null)
      {
        return false;
      }
    }
    else if (!_cfgSvcProfile1.equals(other._cfgSvcProfile1))
    {
      return false;
    }
    if (_etat != other._etat)
    {
      return false;
    }
    return true;
  }

  /**
   * @return the cfgSvcProfile1
   */
  public String getCfgSvcProfile1()
  {
    return _cfgSvcProfile1;
  }

  /**
   * @return the etat
   */
  public EtatEnum getEtat()
  {
    return _etat;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_cfgSvcProfile1 == null) ? 0 : _cfgSvcProfile1.hashCode());
    result = (prime * result) + ((_etat == null) ? 0 : _etat.hashCode());
    return result;
  }

  /**
   * @param cfgSvcProfile1_p
   *          the cfgSvcProfile1 to set
   */
  public void setCfgSvcProfile1(String cfgSvcProfile1_p)
  {
    _cfgSvcProfile1 = cfgSvcProfile1_p;
  }

  /**
   * @param etat_p
   *          the etat to set
   */
  public void setEtat(EtatEnum etat_p)
  {
    _etat = etat_p;
  }

  @Override
  public String toString()
  {
    StringBuilder builder = new StringBuilder();
    builder.append("StHssiSubscriberSvcProf [_etat="); //$NON-NLS-1$
    builder.append(_etat);
    builder.append(", _cfgSvcProfile1="); //$NON-NLS-1$
    builder.append(_cfgSvcProfile1);
    builder.append("]"); //$NON-NLS-1$
    return builder.toString();
  }
}
