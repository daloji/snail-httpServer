/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.hss.structs;

/**
 *
 * @author jjoly
 * @version ($Revision$ $Date$)
 */
public final class ServicesHSSE
{
  /**
   * ST_HSSE_USER
   */
  private StHsseUser _stHsseUser;
  /**
   * ST_HSSE_PDPCONTEXT
   */
  private StHssePdpContext _stHssePdpContext;
  /**
   * ST_HSSE_NAM
   */
  private StHsseNam _stHsseNam;
  /**
   * ST_HSSE_BARRING_ROA
   */
  private StHsseBarringRoa _stHsseBarringRoa;

  /**
   * Default constructor
   *
   * @param stHsseUser_p
   *          a ST_HSSE_USER service
   * @param stHssePdpContext_p
   *          a ST_HSSE_PDPCONTEXT service
   * @param stHsseNam_p
   *          a ST_HSSE_NAM service
   * @param stHsseBarringRoa_p
   *          a ST_HSSE_BARRING_ROA service
   */
  public ServicesHSSE(StHsseUser stHsseUser_p, StHssePdpContext stHssePdpContext_p, StHsseNam stHsseNam_p, StHsseBarringRoa stHsseBarringRoa_p)
  {
    _stHsseUser = stHsseUser_p;
    _stHssePdpContext = stHssePdpContext_p;
    _stHsseNam = stHsseNam_p;
    _stHsseBarringRoa = stHsseBarringRoa_p;
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    ServicesHSSE other = (ServicesHSSE) obj;
    if (_stHsseBarringRoa == null)
    {
      if (other._stHsseBarringRoa != null)
      {
        return false;
      }
    }
    else if (!_stHsseBarringRoa.equals(other._stHsseBarringRoa))
    {
      return false;
    }
    if (_stHsseNam == null)
    {
      if (other._stHsseNam != null)
      {
        return false;
      }
    }
    else if (!_stHsseNam.equals(other._stHsseNam))
    {
      return false;
    }
    if (_stHssePdpContext == null)
    {
      if (other._stHssePdpContext != null)
      {
        return false;
      }
    }
    else if (!_stHssePdpContext.equals(other._stHssePdpContext))
    {
      return false;
    }
    if (_stHsseUser == null)
    {
      if (other._stHsseUser != null)
      {
        return false;
      }
    }
    else if (!_stHsseUser.equals(other._stHsseUser))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the stHsseBarringRoa
   */
  public StHsseBarringRoa getStHsseBarringRoa()
  {
    return _stHsseBarringRoa;
  }

  /**
   * @return the stHsseNam
   */
  public StHsseNam getStHsseNam()
  {
    return _stHsseNam;
  }

  /**
   * @return the stHssePdpContext
   */
  public StHssePdpContext getStHssePdpContext()
  {
    return _stHssePdpContext;
  }

  /**
   * @return the stHsseUser
   */
  public StHsseUser getStHsseUser()
  {
    return _stHsseUser;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_stHsseBarringRoa == null) ? 0 : _stHsseBarringRoa.hashCode());
    result = (prime * result) + ((_stHsseNam == null) ? 0 : _stHsseNam.hashCode());
    result = (prime * result) + ((_stHssePdpContext == null) ? 0 : _stHssePdpContext.hashCode());
    result = (prime * result) + ((_stHsseUser == null) ? 0 : _stHsseUser.hashCode());
    return result;
  }

  /**
   * @param stHsseBarringRoa_p
   *          the stHsseBarringRoa to set
   */
  public final void setStHsseBarringRoa(StHsseBarringRoa stHsseBarringRoa_p)
  {
    _stHsseBarringRoa = stHsseBarringRoa_p;
  }

  /**
   * @param stHsseNam_p
   *          the stHsseNam to set
   */
  public final void setStHsseNam(StHsseNam stHsseNam_p)
  {
    _stHsseNam = stHsseNam_p;
  }

  /**
   * @param stHssePdpContext_p
   *          the stHssePdpContext to set
   */
  public final void setStHssePdpContext(StHssePdpContext stHssePdpContext_p)
  {
    _stHssePdpContext = stHssePdpContext_p;
  }

  /**
   * @param stHsseUser_p
   *          the stHsseUser to set
   */
  public final void setStHsseUser(StHsseUser stHsseUser_p)
  {
    _stHsseUser = stHsseUser_p;
  }

  @Override
  public String toString()
  {
    StringBuilder builder = new StringBuilder();
    builder.append("ServicesHSSE [_stHsseUser="); //$NON-NLS-1$
    builder.append(_stHsseUser);
    builder.append(", _stHssePdpContext="); //$NON-NLS-1$
    builder.append(_stHssePdpContext);
    builder.append(", _stHsseNam="); //$NON-NLS-1$
    builder.append(_stHsseNam);
    builder.append(", _stHsseBarringRoa="); //$NON-NLS-1$
    builder.append(_stHsseBarringRoa);
    builder.append("]"); //$NON-NLS-1$
    return builder.toString();
  }
}
