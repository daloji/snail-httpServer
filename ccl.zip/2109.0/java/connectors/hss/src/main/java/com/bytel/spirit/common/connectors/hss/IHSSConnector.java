/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.hss;

import com.bytel.ravel.services.connector.IConnector;

/**
 *
 * @author jjoly
 * @version ($Revision$ $Date$)
 */
public interface IHSSConnector extends IConnector, IHSS
{
  /**
   * The id to retrieve the connector.
   */
  public String BEAN_ID = "HSSConnector"; //$NON-NLS-1$
}
