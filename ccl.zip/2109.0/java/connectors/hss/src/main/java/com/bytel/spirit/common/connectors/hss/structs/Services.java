/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.hss.structs;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 *
 * @author jjoly
 * @version ($Revision$ $Date$)
 */
public final class Services implements Serializable
{
  /**
   * Generated UID
   */
  private static final long serialVersionUID = -2939362618491704222L;

  /**
   * ST_HSSE_USER
   */
  @SerializedName("ST_HSSE_USER")
  @Expose
  private StHsseUser _stHsseUser;

  /**
   * ST_HSSE_PDPCONTEXT
   */
  @SerializedName("ST_HSSE_PDPCONTEXT")
  @Expose
  private StHssePdpContext _stHssePdpContext;

  /**
   * ST_HSSE_NAM
   */
  @SerializedName("ST_HSSE_NAM")
  @Expose
  private StHsseNam _stHsseNam;

  /**
   * ST_HSSE_BARRING_ROA
   */
  @SerializedName("ST_HSSE_BARRING_ROA")
  @Expose
  private StHsseBarringRoa _stHsseBarringRoa;

  /**
   * ST_HSSI_SUBSCRIBER_SVC_PROF
   */
  @SerializedName("ST_HSSI_SUBSCRIBER_SVC_PROF")
  @Expose
  private StHssiSubscriberSvcProf _stHssiSubscriberSvcProf;

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    Services other = (Services) obj;
    if (_stHsseBarringRoa == null)
    {
      if (other._stHsseBarringRoa != null)
      {
        return false;
      }
    }
    else if (!_stHsseBarringRoa.equals(other._stHsseBarringRoa))
    {
      return false;
    }
    if (_stHsseNam == null)
    {
      if (other._stHsseNam != null)
      {
        return false;
      }
    }
    else if (!_stHsseNam.equals(other._stHsseNam))
    {
      return false;
    }
    if (_stHssePdpContext == null)
    {
      if (other._stHssePdpContext != null)
      {
        return false;
      }
    }
    else if (!_stHssePdpContext.equals(other._stHssePdpContext))
    {
      return false;
    }
    if (_stHsseUser == null)
    {
      if (other._stHsseUser != null)
      {
        return false;
      }
    }
    else if (!_stHsseUser.equals(other._stHsseUser))
    {
      return false;
    }
    if (_stHssiSubscriberSvcProf == null)
    {
      if (other._stHssiSubscriberSvcProf != null)
      {
        return false;
      }
    }
    else if (!_stHssiSubscriberSvcProf.equals(other._stHssiSubscriberSvcProf))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the stHsseBarringRoa
   */
  public StHsseBarringRoa getStHsseBarringRoa()
  {
    return _stHsseBarringRoa;
  }

  /**
   * @return the stHsseNam
   */
  public StHsseNam getStHsseNam()
  {
    return _stHsseNam;
  }

  /**
   * @return the stHssePdpContext
   */
  public StHssePdpContext getStHssePdpContext()
  {
    return _stHssePdpContext;
  }

  /**
   * @return the stHsseUser
   */
  public StHsseUser getStHsseUser()
  {
    return _stHsseUser;
  }

  /**
   * @return the stHssiSubscriberSvcProf
   */
  public StHssiSubscriberSvcProf getStHssiSubscriberSvcProf()
  {
    return _stHssiSubscriberSvcProf;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_stHsseBarringRoa == null) ? 0 : _stHsseBarringRoa.hashCode());
    result = (prime * result) + ((_stHsseNam == null) ? 0 : _stHsseNam.hashCode());
    result = (prime * result) + ((_stHssePdpContext == null) ? 0 : _stHssePdpContext.hashCode());
    result = (prime * result) + ((_stHsseUser == null) ? 0 : _stHsseUser.hashCode());
    result = (prime * result) + ((_stHssiSubscriberSvcProf == null) ? 0 : _stHssiSubscriberSvcProf.hashCode());
    return result;
  }

  /**
   * @param stHsseBarringRoa_p
   *          the stHsseBarringRoa to set
   */
  public void setStHsseBarringRoa(StHsseBarringRoa stHsseBarringRoa_p)
  {
    _stHsseBarringRoa = stHsseBarringRoa_p;
  }

  /**
   * @param stHsseNam_p
   *          the stHsseNam to set
   */
  public void setStHsseNam(StHsseNam stHsseNam_p)
  {
    _stHsseNam = stHsseNam_p;
  }

  /**
   * @param stHssePdpContext_p
   *          the stHssePdpContext to set
   */
  public void setStHssePdpContext(StHssePdpContext stHssePdpContext_p)
  {
    _stHssePdpContext = stHssePdpContext_p;
  }

  /**
   * @param stHsseUser_p
   *          the stHsseUser to set
   */
  public void setStHsseUser(StHsseUser stHsseUser_p)
  {
    _stHsseUser = stHsseUser_p;
  }

  /**
   * @param stHssiSubscriberSvcProf_p
   *          the stHssiSubscriberSvcProf to set
   */
  public void setStHssiSubscriberSvcProf(StHssiSubscriberSvcProf stHssiSubscriberSvcProf_p)
  {
    _stHssiSubscriberSvcProf = stHssiSubscriberSvcProf_p;
  }

  @Override
  public String toString()
  {
    StringBuilder builder = new StringBuilder();
    builder.append("Services [_stHsseUser="); //$NON-NLS-1$
    builder.append(_stHsseUser);
    builder.append(", _stHssePdpContext="); //$NON-NLS-1$
    builder.append(_stHssePdpContext);
    builder.append(", _stHsseNam="); //$NON-NLS-1$
    builder.append(_stHsseNam);
    builder.append(", _stHsseBarringRoa="); //$NON-NLS-1$
    builder.append(_stHsseBarringRoa);
    builder.append(", _stHssiSubscriberSvcProf="); //$NON-NLS-1$
    builder.append(_stHssiSubscriberSvcProf);
    builder.append("]"); //$NON-NLS-1$
    return builder.toString();
  }
}
