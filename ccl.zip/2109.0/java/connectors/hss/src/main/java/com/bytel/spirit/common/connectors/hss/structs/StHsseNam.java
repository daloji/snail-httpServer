/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.hss.structs;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 *
 * @author jjoly
 * @version ($Revision$ $Date$)
 */
public final class StHsseNam implements Serializable
{
  /**
   * Generated UID
   */
  private static final long serialVersionUID = -3975268167819166783L;

  /**
   * ST_HSSE_NAM
   */
  @SerializedName("etat")
  @Expose
  private EtatEnum _etat;

  /**
   * ACCESSRSTR
   */
  @SerializedName("ACCESSRSTR")
  @Expose
  private String _accessrstr;

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    StHsseNam other = (StHsseNam) obj;
    if (_accessrstr == null)
    {
      if (other._accessrstr != null)
      {
        return false;
      }
    }
    else if (!_accessrstr.equals(other._accessrstr))
    {
      return false;
    }
    if (_etat != other._etat)
    {
      return false;
    }
    return true;
  }

  /**
   * @return the accessrstr
   */
  public String getAccessrstr()
  {
    return _accessrstr;
  }

  /**
   * @return the etat
   */
  public EtatEnum getEtat()
  {
    return _etat;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_accessrstr == null) ? 0 : _accessrstr.hashCode());
    result = (prime * result) + ((_etat == null) ? 0 : _etat.hashCode());
    return result;
  }

  /**
   * @param accessrstr_p
   *          the accessrstr to set
   */
  public void setAccessrstr(String accessrstr_p)
  {
    _accessrstr = accessrstr_p;
  }

  /**
   * @param etat_p
   *          the etat to set
   */
  public void setEtat(EtatEnum etat_p)
  {
    _etat = etat_p;
  }

  @Override
  public String toString()
  {
    StringBuilder builder = new StringBuilder();
    builder.append("StHsseNam [_etat="); //$NON-NLS-1$
    builder.append(_etat);
    builder.append(", _accessrstr="); //$NON-NLS-1$
    builder.append(_accessrstr);
    builder.append("]"); //$NON-NLS-1$
    return builder.toString();
  }
}
