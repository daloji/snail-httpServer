/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.hss.structs;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 *
 * @author jjoly
 * @version ($Revision$ $Date$)
 */
public final class StHsseBarringRoa implements Serializable
{
  /**
   * Generated UID
   */
  private static final long serialVersionUID = 606517371765586641L;

  /**
   * ST_HSSE_BARRING_ROA
   */
  @SerializedName("etat")
  @Expose
  private EtatEnum _etat;

  /**
   * ROAMINGALLOWED
   */
  @SerializedName("ROAMINGALLOWED")
  @Expose
  private String _roamingAllowed;

  /**
   * ROAMINGRESTRICTION
   */
  @SerializedName("ROAMINGRESTRICTION")
  @Expose
  private String _roamingRestriction;

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    StHsseBarringRoa other = (StHsseBarringRoa) obj;
    if (_etat != other._etat)
    {
      return false;
    }
    if (_roamingAllowed == null)
    {
      if (other._roamingAllowed != null)
      {
        return false;
      }
    }
    else if (!_roamingAllowed.equals(other._roamingAllowed))
    {
      return false;
    }
    if (_roamingRestriction == null)
    {
      if (other._roamingRestriction != null)
      {
        return false;
      }
    }
    else if (!_roamingRestriction.equals(other._roamingRestriction))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the etat
   */
  public EtatEnum getEtat()
  {
    return _etat;
  }

  /**
   * @return the roamingAllowed
   */
  public String getRoamingAllowed()
  {
    return _roamingAllowed;
  }

  /**
   * @return the roamingRestriction
   */
  public String getRoamingRestriction()
  {
    return _roamingRestriction;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_etat == null) ? 0 : _etat.hashCode());
    result = (prime * result) + ((_roamingAllowed == null) ? 0 : _roamingAllowed.hashCode());
    result = (prime * result) + ((_roamingRestriction == null) ? 0 : _roamingRestriction.hashCode());
    return result;
  }

  /**
   * @param etat_p
   *          the etat to set
   */
  public void setEtat(EtatEnum etat_p)
  {
    _etat = etat_p;
  }

  /**
   * @param roamingAllowed_p
   *          the roamingAllowed to set
   */
  public void setRoamingAllowed(String roamingAllowed_p)
  {
    _roamingAllowed = roamingAllowed_p;
  }

  /**
   * @param roamingRestriction_p
   *          the roamingRestriction to set
   */
  public void setRoamingRestriction(String roamingRestriction_p)
  {
    _roamingRestriction = roamingRestriction_p;
  }

  @Override
  public String toString()
  {
    StringBuilder builder = new StringBuilder();
    builder.append("StHsseBarringRoa [_etat="); //$NON-NLS-1$
    builder.append(_etat);
    builder.append(", _roamingAllowed="); //$NON-NLS-1$
    builder.append(_roamingAllowed);
    builder.append(", _roamingRestriction="); //$NON-NLS-1$
    builder.append(_roamingRestriction);
    builder.append("]"); //$NON-NLS-1$
    return builder.toString();
  }
}
