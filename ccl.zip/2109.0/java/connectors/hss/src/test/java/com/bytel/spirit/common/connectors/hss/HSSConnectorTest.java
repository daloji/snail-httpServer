/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.hss;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;

import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PowerMockListener;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.testlisteners.FieldDefaulter;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.modules.junit4.PowerMockRunnerDelegate;
import org.powermock.reflect.Whitebox;
import org.springframework.test.context.ContextConfiguration;

import com.bytel.ravel.common.conf.generated.Param;
import com.bytel.ravel.common.encryption.PasswordDecrypter;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.test.podam.PodamBytelJUnit4ClassRunner;
import com.bytel.ravel.common.utils.Pair;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.services.conf.connector.generated.Connector;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.connectors.hss.structs.EtatEnum;
import com.bytel.spirit.common.connectors.hss.structs.ServicesHSSE;
import com.bytel.spirit.common.connectors.hss.structs.StHsseBarringRoa;
import com.bytel.spirit.common.connectors.hss.structs.StHsseNam;
import com.bytel.spirit.common.connectors.hss.structs.StHssePdpContext;
import com.bytel.spirit.common.connectors.hss.structs.StHsseUser;
import com.bytel.spirit.common.connectors.hss.structs.StHssiSubscriberSvcProf;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.unboundid.ldap.sdk.BindResult;
import com.unboundid.ldap.sdk.ExtendedResult;
import com.unboundid.ldap.sdk.LDAPConnection;
import com.unboundid.ldap.sdk.LDAPConnectionOptions;
import com.unboundid.ldap.sdk.LDAPConnectionPool;
import com.unboundid.ldap.sdk.LDAPException;
import com.unboundid.ldap.sdk.LDAPSearchException;
import com.unboundid.ldap.sdk.PostConnectProcessor;
import com.unboundid.ldap.sdk.ResultCode;
import com.unboundid.ldap.sdk.SearchResult;
import com.unboundid.ldap.sdk.SearchResultEntry;
import com.unboundid.ldap.sdk.SearchScope;
import com.unboundid.ldap.sdk.SimpleBindRequest;
import com.unboundid.ldap.sdk.StartTLSPostConnectProcessor;
import com.unboundid.ldap.sdk.extensions.StartTLSExtendedRequest;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author jjoly
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PowerMockListener(FieldDefaulter.class)
@PowerMockRunnerDelegate(PodamBytelJUnit4ClassRunner.class)
@ContextConfiguration("classpath:BeansConnectorTestMocks.xml")
@PowerMockIgnore({ "javax.crypto.*", "javax.security.*", "javax.net.*", "javax.net.ssl.*", "javax.management.*", "com.unboundid.util.ssl.*" })
@PrepareForTest({ HSSConnector.class, PasswordDecrypter.class, LDAPConnectionPool.class, LDAPConnection.class, SearchResult.class, SearchResultEntry.class })
public final class HSSConnectorTest
{
  /**
   * Defines all parameters from config file.
   *
   * @author jjoly
   * @version ($Revision$ $Date$)
   */
  private enum ParameterName
  {
    /**
     * Ldap server host
     */
    HOST,

    /**
     * Ldap server port
     */
    PORT,

    /**
     * Connection pool size
     */
    POOLSIZE,

    /**
     * STARTTLS extended operation to secure connections
     */
    STARTTLS,

    /**
     * LDAPSEARCH HSSE base dn
     */
    LDAPSEARCH_HSSE_BASE_DN,

    /**
     * LDAPSEARCH HSSE filter
     */
    LDAPSEARCH_HSSE_FILTER,

    /**
     * LDAPSEARCH HSSE attributes
     */
    LDAPSEARCH_HSSE_ATTRIBUTES,

    /**
     * LDAPSEARCH HSSI base dn
     */
    LDAPSEARCH_HSSI_BASE_DN,

    /**
     * LDAPSEARCH HSSI filter
     */
    LDAPSEARCH_HSSI_FILTER,

    /**
     * LDAPSEARCH HSSI attributes
     */
    LDAPSEARCH_HSSI_ATTRIBUTES,

    /**
     * Bind DN for simple authentication
     */
    BIND_DN,

    /**
     * Bind pwd for simple authentication
     */
    BIND_PASSWORD,

    /**
     * ldapsearch timeout in ms
     */
    CONNECT_TIMEOUT_MS,

    /**
     * Timeout
     */
    RESPONSE_TIMEOUT_MS;
  }

  /**
   * Factory to generate beans
   */
  private static PodamFactory __podam;

  /**
   * LDAP server host
   */
  private static Param __host;

  /**
   * LDAP server non secured port (389 by default)
   */
  private static Param __port;

  /**
   * LDAP connection pool size
   */
  private static Param __poolSize;

  /**
   * true if connections must be secured by sending the extended STARTTLS request, false for unsecured connections.
   */
  private static Param __startTLS;

  /**
   * LDAPSEARCH hsse base dn
   */
  private static Param __ldapSearchHsseBaseDn;

  /**
   * LDAPSEARCH hsse filter
   */
  private static Param __ldapSearchHsseFilter;

  /**
   * LDAPSEARCH hsse attributes
   */
  private static Param __ldapSearchHsseAttributes;

  /**
   * LDAPSEARCH hssi base dn
   */
  private static Param __ldapSearchHssiBaseDn;
  /**
   * LDAPSEARCH hssi filter
   */
  private static Param __ldapSearchHssiFilter;

  /**
   * LDAPSEARCH hssi attributes
   */
  private static Param __ldapSearchHssiAttributes;

  /**
   * BIND DN for simple authentication
   */
  private static Param __bindDn;

  /**
   * BIND password for simple authentication
   */
  private static Param __bindPassword;

  /**
   * Connect timeout in ms
   */
  private static Param __connectTimeout;

  /**
   * Response timeout in ms
   */
  private static Param __responseTimeout;

  /**
   * Code IMSI
   */
  private static String __imsi;

  /**
   * Subscriber identifier
   */
  private static String __subscriberId;

  /**
   * Initialize before all tests
   *
   * @throws Exception
   *           Exception to be thrown in case of failure
   */
  @BeforeClass
  public static void setUpBeforeClass() throws Exception
  {
    __podam = new PodamFactoryImpl();
    __podam.getStrategy().setMemoization(false);
    __podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());

    __host = new Param();
    __host.setName(ParameterName.HOST.toString());
    __host.setValue(__podam.manufacturePojo(String.class));

    __port = new Param();
    __port.setName(ParameterName.PORT.toString());
    __port.setValue(String.valueOf(Math.abs(__podam.manufacturePojo(Integer.class))));

    __bindPassword = new Param();
    __bindPassword.setName(ParameterName.BIND_PASSWORD.toString());
    __bindPassword.setValue(__podam.manufacturePojo(String.class));

    __bindDn = new Param();
    __bindDn.setName(ParameterName.BIND_DN.toString());
    __bindDn.setValue("administratorName=npbt01,nodeName=jambala"); //$NON-NLS-1$

    __poolSize = new Param();
    __poolSize.setName(ParameterName.POOLSIZE.toString());
    __poolSize.setValue(String.valueOf(Math.abs(__podam.manufacturePojo(Integer.class))));

    __startTLS = new Param();
    __startTLS.setName(ParameterName.STARTTLS.toString());
    __startTLS.setValue("true"); //$NON-NLS-1$

    __connectTimeout = new Param();
    __connectTimeout.setName(ParameterName.CONNECT_TIMEOUT_MS.toString());
    __connectTimeout.setValue(String.valueOf(Math.abs(__podam.manufacturePojo(Integer.class))));

    __responseTimeout = new Param();
    __responseTimeout.setName(ParameterName.RESPONSE_TIMEOUT_MS.toString());
    __responseTimeout.setValue(String.valueOf(Math.abs(__podam.manufacturePojo(Long.class))));

    __ldapSearchHsseBaseDn = new Param();
    __ldapSearchHsseBaseDn.setName(ParameterName.LDAPSEARCH_HSSE_BASE_DN.toString());
    __ldapSearchHsseBaseDn.setValue("HSS-EsmImsi={0},HSS-EsmSubscriptionId={1},HSS-EsmSubscriptionContainerName=HSS-EsmSubscriptionContainer,applicationName=HSS_ESM,nodeName=jambala"); //$NON-NLS-1$

    __ldapSearchHsseFilter = new Param();
    __ldapSearchHsseFilter.setName(ParameterName.LDAPSEARCH_HSSE_FILTER.toString());
    __ldapSearchHsseFilter.setValue("objectClass=HSS-EsmUser"); //$NON-NLS-1$

    __ldapSearchHsseAttributes = new Param();
    __ldapSearchHsseAttributes.setName(ParameterName.LDAPSEARCH_HSSE_ATTRIBUTES.toString());
    __ldapSearchHsseAttributes.setValue(__podam.manufacturePojo(String.class));

    __ldapSearchHssiBaseDn = new Param();
    __ldapSearchHssiBaseDn.setName(ParameterName.LDAPSEARCH_HSSI_BASE_DN.toString());
    __ldapSearchHssiBaseDn.setValue("HSS-SubscriberID={0},HSS-SubscriberContainerName=HSS-Subscribers,applicationName=HSS,nodeName=jambala"); //$NON-NLS-1$

    __ldapSearchHssiFilter = new Param();
    __ldapSearchHssiFilter.setName(ParameterName.LDAPSEARCH_HSSI_FILTER.toString());
    __ldapSearchHssiFilter.setValue("objectClass=HSS-SubscriberServiceProfile"); //$NON-NLS-1$

    __ldapSearchHssiAttributes = new Param();
    __ldapSearchHssiAttributes.setName(ParameterName.LDAPSEARCH_HSSI_ATTRIBUTES.toString());
    __ldapSearchHssiAttributes.setValue(__podam.manufacturePojo(String.class));

    __imsi = __podam.manufacturePojo(String.class);
    __subscriberId = __podam.manufacturePojo(String.class);
  }

  /**
   * The mock of object {@Code LDAPConnectionPool}
   */
  @MockStrict
  private LDAPConnectionPool _ldapConnectionPoolMock;

  /**
   * The mock of object {@Code LDAPConnection}
   */
  @MockStrict
  private LDAPConnection _ldapConnectionMock;

  /**
   * The mock of object {@Code SearchResult}
   */
  @MockStrict
  private SearchResult _searchResultMock;

  /**
   * The mock of object {@Code SearchResultEntry}
   */
  @MockStrict
  private SearchResultEntry _searchResultEntryMock;

  /**
   * The mock of object {@Code Tracabilite}
   */
  private Tracabilite _tracabiliteMock;

  /**
   * Connecteur en tests
   */
  private HSSConnector _instance;

  /**
   * Exception has been thrown
   */
  private boolean _exception;

  /**
   * Initialisation avant chaque test
   *
   * @throws Exception
   *           remontée pendant la modification du connecteur
   */
  @Before
  public void beforeTest() throws Exception
  {
    _exception = false;
    _instance = new HSSConnector();
    _tracabiliteMock = null;

    PowerMock.resetAll();

    PowerMock.mockStaticStrict(PasswordDecrypter.class);
  }

  /**
   * Test le cas où l'appel à la méthode "consulterProfilHSSE" provoque une exception LDAPSearchException.<br/>
   *
   * <b>Entrées:</b><br/>
   * <b>Attendu:</b><br/>
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void test_consulterProfilHSSE_001() throws Exception
  {
    final StHsseUser stHsseUser = new StHsseUser();
    stHsseUser.setEtat(EtatEnum.INACTIF);

    final StHssePdpContext stHssePdpContext = new StHssePdpContext();
    stHssePdpContext.setEtat(EtatEnum.INACTIF);

    final StHsseNam stHsseNam = new StHsseNam();
    stHsseNam.setEtat(EtatEnum.INACTIF);

    final StHsseBarringRoa stHsseBarringRoa = new StHsseBarringRoa();
    stHsseBarringRoa.setEtat(EtatEnum.INACTIF);

    final String message = __podam.manufacturePojo(String.class);
    final LDAPSearchException exception = new LDAPSearchException(ResultCode.NO_SUCH_OBJECT, message);
    final ConnectorResponse<ServicesHSSE, Boolean> expected = new ConnectorResponse<>(new ServicesHSSE(stHsseUser, stHssePdpContext, stHsseNam, stHsseBarringRoa), false);
    Pair<ServicesHSSE, Boolean> actual = null;

    final String baseDn = MessageFormat.format(__ldapSearchHsseBaseDn.getValue(), __imsi, __imsi);

    try
    {
      EasyMock.expect(_ldapConnectionPoolMock.getConnection()).andReturn(_ldapConnectionMock).once();
      EasyMock.expect(_ldapConnectionMock.search(baseDn, SearchScope.SUB, __ldapSearchHsseFilter.getValue())).andThrow(exception).once();

      _ldapConnectionMock.close();
      EasyMock.expectLastCall().andVoid().once();

      PowerMock.replayAll();

      Whitebox.setInternalState(_instance, "_pool", _ldapConnectionPoolMock); //$NON-NLS-1$
      Whitebox.setInternalState(_instance, "_ldapSearchHsseBaseDn", __ldapSearchHsseBaseDn.getValue()); //$NON-NLS-1$
      Whitebox.setInternalState(_instance, "_ldapSearchHsseFilter", __ldapSearchHsseFilter.getValue()); //$NON-NLS-1$
      actual = _instance.consulterProfilHSSE(_tracabiliteMock, __imsi);
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test le cas où l'appel à la méthode "consulterProfilHSSE" remonte BUSY.<br/>
   *
   * <b>Entrées:</b><br/>
   * <b>Attendu:</b><br/>
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void test_consulterProfilHSSE_002() throws Exception
  {
    final String message = __podam.manufacturePojo(String.class);
    final LDAPSearchException exception = new LDAPSearchException(ResultCode.CANCELED, message);
    final RavelException expected = new RavelException(ExceptionType.CONNECTOR_DATA_VALIDATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(Messages.getString("HSSConnector.TechnicalExceptionMessage"), "consulterProfilHSSE", StringConstants.EMPTY_STRING, exception.getMessage()), IHSSConnector.BEAN_ID, exception); //$NON-NLS-1$ //$NON-NLS-2$

    final String baseDn = MessageFormat.format(__ldapSearchHsseBaseDn.getValue(), __imsi, __imsi);

    try
    {
      EasyMock.expect(_ldapConnectionPoolMock.getConnection()).andReturn(_ldapConnectionMock).once();
      EasyMock.expect(_ldapConnectionMock.search(baseDn, SearchScope.SUB, __ldapSearchHsseFilter.getValue())).andReturn(_searchResultMock).once();
      EasyMock.expect(_searchResultMock.getResultCode()).andReturn(ResultCode.BUSY).once();
      PowerMock.expectNew(LDAPSearchException.class, new Class[] { SearchResult.class }, _searchResultMock).andThrow(exception).once();

      _ldapConnectionMock.close();
      EasyMock.expectLastCall().andVoid().once();

      PowerMock.replayAll();

      Whitebox.setInternalState(_instance, "_pool", _ldapConnectionPoolMock); //$NON-NLS-1$
      Whitebox.setInternalState(_instance, "_ldapSearchHsseBaseDn", __ldapSearchHsseBaseDn.getValue()); //$NON-NLS-1$
      Whitebox.setInternalState(_instance, "_ldapSearchHsseFilter", __ldapSearchHsseFilter.getValue()); //$NON-NLS-1$
      _instance.consulterProfilHSSE(_tracabiliteMock, __imsi);
    }
    catch (final RavelException actual)
    {
      _exception = true;

      assertEquals(expected.getFunctionalError(), actual.getFunctionalError());
      assertEquals(expected.getExceptionType(), actual.getExceptionType());
      assertEquals(expected.getErrorCode(), actual.getErrorCode());
      assertEquals(expected.getSourceComponentName(), actual.getSourceComponentName());
      assertEquals(expected.getMessage(), actual.getMessage());
    }
    finally
    {
      PowerMock.verifyAll();

      assertTrue(_exception);

      assertNotNull(_instance);
    }
  }

  /**
   * Test le cas où l'appel à la méthode "getSearchEntry" provoque une exception LDAPException.<br/>
   *
   * <b>Entrées:</b>SearchResultEntry's list is empty<br/>
   * <b>Attendu:</b><br/>
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void test_consulterProfilHSSE_003() throws Exception
  {
    final String message = __podam.manufacturePojo(String.class);
    final LDAPException exception = new LDAPException(ResultCode.CANCELED, message);
    final RavelException expected = new RavelException(ExceptionType.CONNECTOR_DATA_VALIDATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(Messages.getString("HSSConnector.TechnicalExceptionMessage"), "consulterProfilHSSE", StringConstants.EMPTY_STRING, exception.getMessage()), IHSSConnector.BEAN_ID, exception); //$NON-NLS-1$ //$NON-NLS-2$

    final String baseDn = MessageFormat.format(__ldapSearchHsseBaseDn.getValue(), __imsi, __imsi);

    try
    {
      EasyMock.expect(_ldapConnectionPoolMock.getConnection()).andReturn(_ldapConnectionMock).once();
      EasyMock.expect(_ldapConnectionMock.search(baseDn, SearchScope.SUB, __ldapSearchHsseFilter.getValue())).andReturn(_searchResultMock).once();
      EasyMock.expect(_searchResultMock.getResultCode()).andReturn(ResultCode.SUCCESS).once();
      EasyMock.expect(_searchResultMock.getSearchEntry(baseDn)).andThrow(exception).once();

      _ldapConnectionMock.close();
      EasyMock.expectLastCall().andVoid().once();

      PowerMock.replayAll();

      Whitebox.setInternalState(_instance, "_pool", _ldapConnectionPoolMock); //$NON-NLS-1$
      Whitebox.setInternalState(_instance, "_ldapSearchHsseBaseDn", __ldapSearchHsseBaseDn.getValue()); //$NON-NLS-1$
      Whitebox.setInternalState(_instance, "_ldapSearchHsseFilter", __ldapSearchHsseFilter.getValue()); //$NON-NLS-1$
      _instance.consulterProfilHSSE(_tracabiliteMock, __imsi);
    }
    catch (final RavelException actual)
    {
      _exception = true;

      assertEquals(expected.getFunctionalError(), actual.getFunctionalError());
      assertEquals(expected.getExceptionType(), actual.getExceptionType());
      assertEquals(expected.getErrorCode(), actual.getErrorCode());
      assertEquals(expected.getSourceComponentName(), actual.getSourceComponentName());
      assertEquals(expected.getMessage(), actual.getMessage());
    }
    finally
    {
      PowerMock.verifyAll();

      assertTrue(_exception);

      assertNotNull(_instance);
    }
  }

  /**
   * Test le cas où l'appel à la méthode "getSearchEntry" retourne "null".<br/>
   *
   * <b>Entrées:</b>SearchResultEntry's list is empty<br/>
   * <b>Attendu:</b><br/>
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void test_consulterProfilHSSE_004() throws Exception
  {
    final String message = __podam.manufacturePojo(String.class);
    final LDAPSearchException exception = new LDAPSearchException(ResultCode.NO_SUCH_OBJECT, message);
    final RavelException expected = new RavelException(ExceptionType.CONNECTOR_DATA_VALIDATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(Messages.getString("HSSConnector.TechnicalExceptionMessage"), "consulterProfilHSSE", StringConstants.EMPTY_STRING, exception.getMessage()), IHSSConnector.BEAN_ID, exception); //$NON-NLS-1$ //$NON-NLS-2$

    final String baseDn = MessageFormat.format(__ldapSearchHsseBaseDn.getValue(), __imsi, __imsi);

    try
    {
      EasyMock.expect(_ldapConnectionPoolMock.getConnection()).andReturn(_ldapConnectionMock).once();
      EasyMock.expect(_ldapConnectionMock.search(baseDn, SearchScope.SUB, __ldapSearchHsseFilter.getValue())).andReturn(_searchResultMock).once();
      EasyMock.expect(_searchResultMock.getResultCode()).andReturn(ResultCode.SUCCESS).once();
      EasyMock.expect(_searchResultMock.getSearchEntry(baseDn)).andReturn(null).once();

      _ldapConnectionMock.close();
      EasyMock.expectLastCall().andVoid().once();

      PowerMock.replayAll();

      Whitebox.setInternalState(_instance, "_pool", _ldapConnectionPoolMock); //$NON-NLS-1$
      Whitebox.setInternalState(_instance, "_ldapSearchHsseBaseDn", __ldapSearchHsseBaseDn.getValue()); //$NON-NLS-1$
      Whitebox.setInternalState(_instance, "_ldapSearchHsseFilter", __ldapSearchHsseFilter.getValue()); //$NON-NLS-1$
      _instance.consulterProfilHSSE(_tracabiliteMock, __imsi);
    }
    catch (final RavelException actual)
    {
      _exception = true;

      assertEquals(expected.getFunctionalError(), actual.getFunctionalError());
      assertEquals(expected.getExceptionType(), actual.getExceptionType());
      assertEquals(expected.getErrorCode(), actual.getErrorCode());
      assertEquals(expected.getSourceComponentName(), actual.getSourceComponentName());
      assertEquals(expected.getMessage(), actual.getMessage());
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);
    }
  }

  /**
   * Test le cas où l'appel à la méthode "consulterProfilHSSE" provoque une exception LDAPSearchException.<br/>
   *
   * <b>Entrées:</b><br/>
   * <b>Attendu:</b><br/>
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void test_consulterProfilHSSE_005() throws Exception
  {
    final StHsseUser stHsseUser = new StHsseUser();
    stHsseUser.setEtat(EtatEnum.INACTIF);

    final StHssePdpContext stHssePdpContext = new StHssePdpContext();
    stHssePdpContext.setEtat(EtatEnum.INACTIF);

    final StHsseNam stHsseNam = new StHsseNam();
    stHsseNam.setEtat(EtatEnum.INACTIF);

    final StHsseBarringRoa stHsseBarringRoa = new StHsseBarringRoa();
    stHsseBarringRoa.setEtat(EtatEnum.INACTIF);

    final ConnectorResponse<ServicesHSSE, Boolean> expected = new ConnectorResponse<>(new ServicesHSSE(stHsseUser, stHssePdpContext, stHsseNam, stHsseBarringRoa), true);
    Pair<ServicesHSSE, Boolean> actual = null;

    final String baseDn = MessageFormat.format(__ldapSearchHsseBaseDn.getValue(), __imsi, __imsi);

    try
    {
      EasyMock.expect(_ldapConnectionPoolMock.getConnection()).andReturn(_ldapConnectionMock).once();
      EasyMock.expect(_ldapConnectionMock.search(baseDn, SearchScope.SUB, __ldapSearchHsseFilter.getValue())).andReturn(_searchResultMock).once();
      EasyMock.expect(_searchResultMock.getResultCode()).andReturn(ResultCode.SUCCESS).once();
      EasyMock.expect(_searchResultMock.getSearchEntry(baseDn)).andReturn(_searchResultEntryMock).once();

      EasyMock.expect(_searchResultEntryMock.hasAttribute("HSS-EsmIndividualDefaultContextID")).andReturn(false).once(); //$NON-NLS-1$
      EasyMock.expect(_searchResultEntryMock.hasAttribute("HSS-EsmLocationState")).andReturn(false).once(); //$NON-NLS-1$
      EasyMock.expect(_searchResultEntryMock.hasAttribute("HSS-EsmMmeAddress")).andReturn(false).once(); //$NON-NLS-1$
      EasyMock.expect(_searchResultEntryMock.hasAttribute("HSS-EsmOdb")).andReturn(false).once(); //$NON-NLS-1$
      EasyMock.expect(_searchResultEntryMock.hasAttribute("HSS-EsmDynPdnGwInfo")).andReturn(false).once(); //$NON-NLS-1$
      EasyMock.expect(_searchResultEntryMock.hasAttribute("PROFILE_ID")).andReturn(false).once(); //$NON-NLS-1$

      EasyMock.expect(_searchResultEntryMock.hasAttribute("HSS-EsmIndividualContextIdList")).andReturn(false).once(); //$NON-NLS-1$

      EasyMock.expect(_searchResultEntryMock.hasAttribute("HSS-EsmAccessRestrictions")).andReturn(false).once(); //$NON-NLS-1$

      EasyMock.expect(_searchResultEntryMock.hasAttribute("HSS-EsmRoamingRestriction")).andReturn(false).once(); //$NON-NLS-1$
      EasyMock.expect(_searchResultEntryMock.hasAttribute("HSS-EsmRoamingAllowed")).andReturn(false).once(); //$NON-NLS-1$

      _ldapConnectionMock.close();
      EasyMock.expectLastCall().andVoid().once();

      PowerMock.replayAll();

      Whitebox.setInternalState(_instance, "_pool", _ldapConnectionPoolMock); //$NON-NLS-1$
      Whitebox.setInternalState(_instance, "_ldapSearchHsseBaseDn", __ldapSearchHsseBaseDn.getValue()); //$NON-NLS-1$
      Whitebox.setInternalState(_instance, "_ldapSearchHsseFilter", __ldapSearchHsseFilter.getValue()); //$NON-NLS-1$
      actual = _instance.consulterProfilHSSE(_tracabiliteMock, __imsi);
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test nominale.<br/>
   *
   * <b>Entrées:</b><br/>
   * <b>Attendu:</b><br/>
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void test_consulterProfilHSSE_006() throws Exception
  {
    final StHsseUser stHsseUser = new StHsseUser();
    stHsseUser.setEtat(EtatEnum.ACTIF);
    stHsseUser.setDefContextId("HSS-EsmIndividualDefaultContextID"); //$NON-NLS-1$
    stHsseUser.setLocationState("HSS-EsmLocationState"); //$NON-NLS-1$
    stHsseUser.setMmeAddress("HSS-EsmMmeAddress"); //$NON-NLS-1$
    stHsseUser.setOdb("HSS-EsmOdb"); //$NON-NLS-1$
    stHsseUser.setPdnGateways("HSS-EsmDynPdnGwInfo"); //$NON-NLS-1$
    stHsseUser.setProfileId("PROFILE_ID"); //$NON-NLS-1$

    final StHssePdpContext stHssePdpContext = new StHssePdpContext();
    stHssePdpContext.setEtat(EtatEnum.ACTIF);
    stHssePdpContext.setContextId(""); //$NON-NLS-1$

    final StHsseNam stHsseNam = new StHsseNam();
    stHsseNam.setEtat(EtatEnum.ACTIF);
    stHsseNam.setAccessrstr("HSS-EsmAccessRestrictions"); //$NON-NLS-1$

    final StHsseBarringRoa stHsseBarringRoa = new StHsseBarringRoa();
    stHsseBarringRoa.setEtat(EtatEnum.ACTIF);
    stHsseBarringRoa.setRoamingAllowed("HSS-EsmRoamingAllowed"); //$NON-NLS-1$
    stHsseBarringRoa.setRoamingRestriction("HSS-EsmRoamingAllowed"); //$NON-NLS-1$

    final ConnectorResponse<ServicesHSSE, Boolean> expected = new ConnectorResponse<>(new ServicesHSSE(stHsseUser, stHssePdpContext, stHsseNam, stHsseBarringRoa), true);
    Pair<ServicesHSSE, Boolean> actual = null;

    final String baseDn = MessageFormat.format(__ldapSearchHsseBaseDn.getValue(), __imsi, __imsi);

    try
    {
      EasyMock.expect(_ldapConnectionPoolMock.getConnection()).andReturn(_ldapConnectionMock).once();
      EasyMock.expect(_ldapConnectionMock.search(baseDn, SearchScope.SUB, __ldapSearchHsseFilter.getValue())).andReturn(_searchResultMock).once();
      EasyMock.expect(_searchResultMock.getResultCode()).andReturn(ResultCode.SUCCESS).once();
      EasyMock.expect(_searchResultMock.getSearchEntry(baseDn)).andReturn(_searchResultEntryMock).once();

      EasyMock.expect(_searchResultEntryMock.hasAttribute("HSS-EsmIndividualDefaultContextID")).andReturn(true).once(); //$NON-NLS-1$
      EasyMock.expect(_searchResultEntryMock.getAttributeValue("HSS-EsmIndividualDefaultContextID")).andReturn(stHsseUser.getDefContextId()); //$NON-NLS-1$
      EasyMock.expect(_searchResultEntryMock.getAttributeValue("HSS-EsmLocationState")).andReturn(stHsseUser.getLocationState()); //$NON-NLS-1$
      EasyMock.expect(_searchResultEntryMock.getAttributeValue("HSS-EsmMmeAddress")).andReturn(stHsseUser.getMmeAddress()); //$NON-NLS-1$
      EasyMock.expect(_searchResultEntryMock.getAttributeValue("HSS-EsmOdb")).andReturn(stHsseUser.getOdb()); //$NON-NLS-1$
      EasyMock.expect(_searchResultEntryMock.getAttributeValue("HSS-EsmDynPdnGwInfo")).andReturn(stHsseUser.getPdnGateways()); //$NON-NLS-1$
      EasyMock.expect(_searchResultEntryMock.getAttributeValue("PROFILE_ID")).andReturn(stHsseUser.getProfileId()); //$NON-NLS-1$

      EasyMock.expect(_searchResultEntryMock.hasAttribute("HSS-EsmIndividualContextIdList")).andReturn(true).once(); //$NON-NLS-1$
      EasyMock.expect(_searchResultEntryMock.getAttributeValues("HSS-EsmIndividualContextIdList")).andReturn(new String[] {}); //$NON-NLS-1$

      EasyMock.expect(_searchResultEntryMock.hasAttribute("HSS-EsmAccessRestrictions")).andReturn(true).once(); //$NON-NLS-1$
      EasyMock.expect(_searchResultEntryMock.getAttributeValue("HSS-EsmAccessRestrictions")).andReturn(stHsseNam.getAccessrstr()); //$NON-NLS-1$

      EasyMock.expect(_searchResultEntryMock.hasAttribute("HSS-EsmRoamingRestriction")).andReturn(true).once(); //$NON-NLS-1$
      EasyMock.expect(_searchResultEntryMock.getAttributeValue("HSS-EsmRoamingAllowed")).andReturn(stHsseBarringRoa.getRoamingAllowed()); //$NON-NLS-1$
      EasyMock.expect(_searchResultEntryMock.getAttributeValue("HSS-EsmRoamingRestriction")).andReturn(stHsseBarringRoa.getRoamingRestriction()); //$NON-NLS-1$

      _ldapConnectionMock.close();
      EasyMock.expectLastCall().andVoid().once();

      PowerMock.replayAll();

      Whitebox.setInternalState(_instance, "_pool", _ldapConnectionPoolMock); //$NON-NLS-1$
      Whitebox.setInternalState(_instance, "_ldapSearchHsseBaseDn", __ldapSearchHsseBaseDn.getValue()); //$NON-NLS-1$
      Whitebox.setInternalState(_instance, "_ldapSearchHsseFilter", __ldapSearchHsseFilter.getValue()); //$NON-NLS-1$
      actual = _instance.consulterProfilHSSE(_tracabiliteMock, __imsi);
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test le cas où l'appel à la méthode "consulterProfilHSSI" provoque une exception LDAPSearchException.<br/>
   *
   * <b>Entrées:</b><br/>
   * <b>Attendu:</b><br/>
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void test_consulterProfilHSSI_001() throws Exception
  {
    final StHssiSubscriberSvcProf stHssiSubscriberSvcProf = new StHssiSubscriberSvcProf();
    stHssiSubscriberSvcProf.setEtat(EtatEnum.INACTIF);

    final String message = __podam.manufacturePojo(String.class);
    final LDAPSearchException exception = new LDAPSearchException(ResultCode.NO_SUCH_OBJECT, message);
    final ConnectorResponse<StHssiSubscriberSvcProf, Boolean> expected = new ConnectorResponse<>(stHssiSubscriberSvcProf, false);
    Pair<StHssiSubscriberSvcProf, Boolean> actual = null;

    final String baseDn = MessageFormat.format(__ldapSearchHssiBaseDn.getValue(), __subscriberId);

    try
    {
      EasyMock.expect(_ldapConnectionPoolMock.getConnection()).andReturn(_ldapConnectionMock).once();
      EasyMock.expect(_ldapConnectionMock.search(baseDn, SearchScope.SUB, __ldapSearchHssiFilter.getValue())).andThrow(exception).once();

      _ldapConnectionMock.close();
      EasyMock.expectLastCall().andVoid().once();

      PowerMock.replayAll();

      Whitebox.setInternalState(_instance, "_pool", _ldapConnectionPoolMock); //$NON-NLS-1$
      Whitebox.setInternalState(_instance, "_ldapSearchHssiBaseDn", __ldapSearchHssiBaseDn.getValue()); //$NON-NLS-1$
      Whitebox.setInternalState(_instance, "_ldapSearchHssiFilter", __ldapSearchHssiFilter.getValue()); //$NON-NLS-1$
      actual = _instance.consulterProfilHSSI(_tracabiliteMock, __subscriberId);
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test le cas où l'appel à la méthode "consulterProfilHSSI" remonte BUSY.<br/>
   *
   * <b>Entrées:</b><br/>
   * <b>Attendu:</b><br/>
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void test_consulterProfilHSSI_002() throws Exception
  {
    final String message = __podam.manufacturePojo(String.class);
    final LDAPSearchException exception = new LDAPSearchException(ResultCode.CANCELED, message);
    final RavelException expected = new RavelException(ExceptionType.CONNECTOR_DATA_VALIDATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(Messages.getString("HSSConnector.TechnicalExceptionMessage"), "consulterProfilHSSI", StringConstants.EMPTY_STRING, exception.getMessage()), IHSSConnector.BEAN_ID, exception); //$NON-NLS-1$ //$NON-NLS-2$

    final String baseDn = MessageFormat.format(__ldapSearchHssiBaseDn.getValue(), __subscriberId);

    try
    {
      EasyMock.expect(_ldapConnectionPoolMock.getConnection()).andReturn(_ldapConnectionMock).once();
      EasyMock.expect(_ldapConnectionMock.search(baseDn, SearchScope.SUB, __ldapSearchHssiFilter.getValue())).andReturn(_searchResultMock).once();
      EasyMock.expect(_searchResultMock.getResultCode()).andReturn(ResultCode.BUSY).once();
      PowerMock.expectNew(LDAPSearchException.class, new Class[] { SearchResult.class }, _searchResultMock).andThrow(exception).once();

      _ldapConnectionMock.close();
      EasyMock.expectLastCall().andVoid().once();

      PowerMock.replayAll();

      Whitebox.setInternalState(_instance, "_pool", _ldapConnectionPoolMock); //$NON-NLS-1$
      Whitebox.setInternalState(_instance, "_ldapSearchHssiBaseDn", __ldapSearchHssiBaseDn.getValue()); //$NON-NLS-1$
      Whitebox.setInternalState(_instance, "_ldapSearchHssiFilter", __ldapSearchHssiFilter.getValue()); //$NON-NLS-1$
      _instance.consulterProfilHSSI(_tracabiliteMock, __subscriberId);
    }
    catch (final RavelException actual)
    {
      _exception = true;

      assertEquals(expected.getFunctionalError(), actual.getFunctionalError());
      assertEquals(expected.getExceptionType(), actual.getExceptionType());
      assertEquals(expected.getErrorCode(), actual.getErrorCode());
      assertEquals(expected.getSourceComponentName(), actual.getSourceComponentName());
      assertEquals(expected.getMessage(), actual.getMessage());
    }
    finally
    {
      PowerMock.verifyAll();

      assertTrue(_exception);

      assertNotNull(_instance);
    }
  }

  /**
   * Test le cas où l'appel à la méthode "getSearchEntries" retourne "null".<br/>
   *
   * <b>Entrées:</b>SearchResultEntry's list is empty<br/>
   * <b>Attendu:</b><br/>
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void test_consulterProfilHSSI_003() throws Exception
  {
    final StHssiSubscriberSvcProf stHssiSubscriberSvcProf = new StHssiSubscriberSvcProf();
    stHssiSubscriberSvcProf.setEtat(EtatEnum.INACTIF);

    final ConnectorResponse<StHssiSubscriberSvcProf, Boolean> expected = new ConnectorResponse<>(stHssiSubscriberSvcProf, true);
    Pair<StHssiSubscriberSvcProf, Boolean> actual = null;

    final String baseDn = MessageFormat.format(__ldapSearchHssiBaseDn.getValue(), __subscriberId);

    try
    {
      EasyMock.expect(_ldapConnectionPoolMock.getConnection()).andReturn(_ldapConnectionMock).once();
      EasyMock.expect(_ldapConnectionMock.search(baseDn, SearchScope.SUB, __ldapSearchHssiFilter.getValue())).andReturn(_searchResultMock).once();
      EasyMock.expect(_searchResultMock.getResultCode()).andReturn(ResultCode.SUCCESS).once();
      EasyMock.expect(_searchResultMock.getSearchEntries()).andReturn(null).once();

      _ldapConnectionMock.close();
      EasyMock.expectLastCall().andVoid().once();

      PowerMock.replayAll();

      Whitebox.setInternalState(_instance, "_pool", _ldapConnectionPoolMock); //$NON-NLS-1$
      Whitebox.setInternalState(_instance, "_ldapSearchHssiBaseDn", __ldapSearchHssiBaseDn.getValue()); //$NON-NLS-1$
      Whitebox.setInternalState(_instance, "_ldapSearchHssiFilter", __ldapSearchHssiFilter.getValue()); //$NON-NLS-1$
      actual = _instance.consulterProfilHSSI(_tracabiliteMock, __subscriberId);
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test le cas où l'appel à la méthode "getSearchEntry" retourne un veteur vide.<br/>
   *
   * <b>Entrées:</b>SearchResultEntry's list is empty<br/>
   * <b>Attendu:</b><br/>
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void test_consulterProfilHSSI_004() throws Exception
  {
    final StHssiSubscriberSvcProf stHssiSubscriberSvcProf = new StHssiSubscriberSvcProf();
    stHssiSubscriberSvcProf.setEtat(EtatEnum.INACTIF);

    final ConnectorResponse<StHssiSubscriberSvcProf, Boolean> expected = new ConnectorResponse<>(stHssiSubscriberSvcProf, true);
    Pair<StHssiSubscriberSvcProf, Boolean> actual = null;

    final String baseDn = MessageFormat.format(__ldapSearchHssiBaseDn.getValue(), __subscriberId);

    try
    {
      EasyMock.expect(_ldapConnectionPoolMock.getConnection()).andReturn(_ldapConnectionMock).once();
      EasyMock.expect(_ldapConnectionMock.search(baseDn, SearchScope.SUB, __ldapSearchHssiFilter.getValue())).andReturn(_searchResultMock).once();
      EasyMock.expect(_searchResultMock.getResultCode()).andReturn(ResultCode.SUCCESS).once();
      EasyMock.expect(_searchResultMock.getSearchEntries()).andReturn(new ArrayList<>()).once();

      _ldapConnectionMock.close();
      EasyMock.expectLastCall().andVoid().once();

      PowerMock.replayAll();

      Whitebox.setInternalState(_instance, "_pool", _ldapConnectionPoolMock); //$NON-NLS-1$
      Whitebox.setInternalState(_instance, "_ldapSearchHssiBaseDn", __ldapSearchHssiBaseDn.getValue()); //$NON-NLS-1$
      Whitebox.setInternalState(_instance, "_ldapSearchHssiFilter", __ldapSearchHssiFilter.getValue()); //$NON-NLS-1$
      actual = _instance.consulterProfilHSSI(_tracabiliteMock, __subscriberId);
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test le cas où l'appel à la méthode "getSearchEntry" retourne un veteur vide.<br/>
   *
   * <b>Entrées:</b>SearchResultEntry's list is empty<br/>
   * <b>Attendu:</b><br/>
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void test_consulterProfilHSSI_005() throws Exception
  {
    final StHssiSubscriberSvcProf stHssiSubscriberSvcProf = new StHssiSubscriberSvcProf();
    stHssiSubscriberSvcProf.setEtat(EtatEnum.INACTIF);

    final ConnectorResponse<StHssiSubscriberSvcProf, Boolean> expected = new ConnectorResponse<>(stHssiSubscriberSvcProf, true);
    Pair<StHssiSubscriberSvcProf, Boolean> actual = null;

    final String baseDn = MessageFormat.format(__ldapSearchHssiBaseDn.getValue(), __subscriberId);

    try
    {
      EasyMock.expect(_ldapConnectionPoolMock.getConnection()).andReturn(_ldapConnectionMock).once();
      EasyMock.expect(_ldapConnectionMock.search(baseDn, SearchScope.SUB, __ldapSearchHssiFilter.getValue())).andReturn(_searchResultMock).once();
      EasyMock.expect(_searchResultMock.getResultCode()).andReturn(ResultCode.SUCCESS).once();
      EasyMock.expect(_searchResultMock.getSearchEntries()).andReturn(Arrays.asList(_searchResultEntryMock)).once();

      EasyMock.expect(_searchResultEntryMock.hasAttribute("HSS-ConfiguredServiceProfiles")).andReturn(false).once(); //$NON-NLS-1$

      _ldapConnectionMock.close();
      EasyMock.expectLastCall().andVoid().once();

      PowerMock.replayAll();

      Whitebox.setInternalState(_instance, "_pool", _ldapConnectionPoolMock); //$NON-NLS-1$
      Whitebox.setInternalState(_instance, "_ldapSearchHssiBaseDn", __ldapSearchHssiBaseDn.getValue()); //$NON-NLS-1$
      Whitebox.setInternalState(_instance, "_ldapSearchHssiFilter", __ldapSearchHssiFilter.getValue()); //$NON-NLS-1$
      actual = _instance.consulterProfilHSSI(_tracabiliteMock, __subscriberId);
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test le cas où l'appel à la méthode "getSearchEntry" retourne un veteur vide.<br/>
   *
   * <b>Entrées:</b>SearchResultEntry's list is empty<br/>
   * <b>Attendu:</b><br/>
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void test_consulterProfilHSSI_006() throws Exception
  {
    final StHssiSubscriberSvcProf stHssiSubscriberSvcProf = new StHssiSubscriberSvcProf();
    stHssiSubscriberSvcProf.setEtat(EtatEnum.ACTIF);
    stHssiSubscriberSvcProf.setCfgSvcProfile1("HSS-ConfiguredServiceProfiles"); //$NON-NLS-1$

    final ConnectorResponse<StHssiSubscriberSvcProf, Boolean> expected = new ConnectorResponse<>(stHssiSubscriberSvcProf, true);
    Pair<StHssiSubscriberSvcProf, Boolean> actual = null;

    final String baseDn = MessageFormat.format(__ldapSearchHssiBaseDn.getValue(), __subscriberId);

    try
    {
      EasyMock.expect(_ldapConnectionPoolMock.getConnection()).andReturn(_ldapConnectionMock).once();
      EasyMock.expect(_ldapConnectionMock.search(baseDn, SearchScope.SUB, __ldapSearchHssiFilter.getValue())).andReturn(_searchResultMock).once();
      EasyMock.expect(_searchResultMock.getResultCode()).andReturn(ResultCode.SUCCESS).once();
      EasyMock.expect(_searchResultMock.getSearchEntries()).andReturn(Arrays.asList(_searchResultEntryMock)).once();

      EasyMock.expect(_searchResultEntryMock.hasAttribute("HSS-ConfiguredServiceProfiles")).andReturn(true).once(); //$NON-NLS-1$
      EasyMock.expect(_searchResultEntryMock.getAttributeValue("HSS-ConfiguredServiceProfiles")).andReturn(stHssiSubscriberSvcProf.getCfgSvcProfile1()).once(); //$NON-NLS-1$

      _ldapConnectionMock.close();
      EasyMock.expectLastCall().andVoid().once();

      PowerMock.replayAll();

      Whitebox.setInternalState(_instance, "_pool", _ldapConnectionPoolMock); //$NON-NLS-1$
      Whitebox.setInternalState(_instance, "_ldapSearchHssiBaseDn", __ldapSearchHssiBaseDn.getValue()); //$NON-NLS-1$
      Whitebox.setInternalState(_instance, "_ldapSearchHssiFilter", __ldapSearchHssiFilter.getValue()); //$NON-NLS-1$
      actual = _instance.consulterProfilHSSI(_tracabiliteMock, __subscriberId);
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test le cas où ParameterName.HOST n'est pas present.<br/>
   *
   * <b>Entrées:</b><br/>
   * <b>Attendu:</b>RavelException <br/>
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void test_loadConnectorConfiguration_001() throws Exception
  {
    final Exception exception = new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(Messages.getString("HSSConnector.MissingParameter"), IHSSConnector.BEAN_ID, ParameterName.HOST.toString())); //$NON-NLS-1$
    final RavelException expected = new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(Messages.getString("HSSConnector.INITIALIZE_ERROR"), exception.getMessage())); //$NON-NLS-1$

    final Connector connector = new Connector();
    connector.setName(IHSSConnector.BEAN_ID);
    connector.getParam().addAll(new ArrayList<>());

    try
    {
      PowerMock.replayAll();

      _instance.loadConnectorConfiguration(connector);
    }
    catch (final RavelException actual)
    {
      _exception = true;

      assertEquals(expected.getFunctionalError(), actual.getFunctionalError());
      assertEquals(expected.getExceptionType(), actual.getExceptionType());
      assertEquals(expected.getErrorCode(), actual.getErrorCode());
      assertEquals(expected.getSourceComponentName(), actual.getSourceComponentName());
      assertEquals(expected.getMessage(), actual.getMessage());
    }
    finally
    {
      PowerMock.verifyAll();

      assertTrue(_exception);

      assertNotNull(_instance);
      assertEquals(Boolean.FALSE, Whitebox.getInternalState(_instance, "_enabled")); //$NON-NLS-1$
      assertEquals(IHSSConnector.BEAN_ID, Whitebox.getInternalState(_instance, "_name")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_host")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_port")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_bindPassword")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_bindDn")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_poolSize")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_startTLS")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_connectTimeout")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_responseTimeout")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_ldapSearchHsseBaseDn")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_ldapSearchHsseFilter")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_ldapSearchHssiBaseDn")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_ldapSearchHssiFilter")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_pool")); //$NON-NLS-1$
    }
  }

  /**
   * Test le cas où ParameterName.PORT n'est pas présent.<br/>
   *
   * <b>Entrées:</b><br/>
   * <b>Attendu:</b>RavelException <br/>
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void test_loadConnectorConfiguration_002() throws Exception
  {
    final Exception exception = new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(Messages.getString("HSSConnector.MissingParameter"), IHSSConnector.BEAN_ID, ParameterName.PORT.toString())); //$NON-NLS-1$
    final RavelException expected = new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(Messages.getString("HSSConnector.INITIALIZE_ERROR"), exception.getMessage())); //$NON-NLS-1$

    final Connector connector = new Connector();
    connector.setName(IHSSConnector.BEAN_ID);
    connector.getParam().addAll(Arrays.asList(__host));

    try
    {
      PowerMock.replayAll();

      _instance.loadConnectorConfiguration(connector);
    }
    catch (final RavelException actual)
    {
      _exception = true;

      assertEquals(expected.getFunctionalError(), actual.getFunctionalError());
      assertEquals(expected.getExceptionType(), actual.getExceptionType());
      assertEquals(expected.getErrorCode(), actual.getErrorCode());
      assertEquals(expected.getSourceComponentName(), actual.getSourceComponentName());
      assertEquals(expected.getMessage(), actual.getMessage());
    }
    finally
    {
      PowerMock.verifyAll();

      assertTrue(_exception);

      assertNotNull(_instance);
      assertEquals(Boolean.FALSE, Whitebox.getInternalState(_instance, "_enabled")); //$NON-NLS-1$
      assertEquals(IHSSConnector.BEAN_ID, Whitebox.getInternalState(_instance, "_name")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_host")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_port")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_bindPassword")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_bindDn")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_poolSize")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_startTLS")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_connectTimeout")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_responseTimeout")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_ldapSearchHsseBaseDn")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_ldapSearchHsseFilter")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_ldapSearchHssiBaseDn")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_ldapSearchHssiFilter")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_pool")); //$NON-NLS-1$
    }
  }

  /**
   * Test le cas où ParameterName.PORT n'est pas un entier positif.<br/>
   *
   * <b>Entrées:</b><br/>
   * <b>Attendu:</b>RavelException <br/>
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void test_loadConnectorConfiguration_003() throws Exception
  {
    final Param port = new Param();
    port.setName(ParameterName.PORT.toString());
    port.setValue(__podam.manufacturePojo(String.class));
    final Exception exception = new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(Messages.getString("HSSConnector.InvalidParamValue"), port.getValue(), port.getName(), "integer value expected")); //$NON-NLS-1$ //$NON-NLS-2$
    final RavelException expected = new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(Messages.getString("HSSConnector.INITIALIZE_ERROR"), exception.getMessage())); //$NON-NLS-1$

    final Connector connector = new Connector();
    connector.setName(IHSSConnector.BEAN_ID);
    connector.getParam().addAll(Arrays.asList(__host, port));

    try
    {
      PowerMock.replayAll();

      _instance.loadConnectorConfiguration(connector);
    }
    catch (final RavelException actual)
    {
      _exception = true;

      assertEquals(expected.getFunctionalError(), actual.getFunctionalError());
      assertEquals(expected.getExceptionType(), actual.getExceptionType());
      assertEquals(expected.getErrorCode(), actual.getErrorCode());
      assertEquals(expected.getSourceComponentName(), actual.getSourceComponentName());
      assertEquals(expected.getMessage(), actual.getMessage());
    }
    finally
    {
      PowerMock.verifyAll();

      assertTrue(_exception);

      assertNotNull(_instance);
      assertEquals(Boolean.FALSE, Whitebox.getInternalState(_instance, "_enabled")); //$NON-NLS-1$
      assertEquals(IHSSConnector.BEAN_ID, Whitebox.getInternalState(_instance, "_name")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_host")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_port")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_bindPassword")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_bindDn")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_poolSize")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_startTLS")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_connectTimeout")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_responseTimeout")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_ldapSearchHsseBaseDn")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_ldapSearchHsseFilter")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_ldapSearchHssiBaseDn")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_ldapSearchHssiFilter")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_pool")); //$NON-NLS-1$
    }
  }

  /**
   * Test le cas où ParameterName.PORT n'est pas un entier positif.<br/>
   *
   * <b>Entrées:</b><br/>
   * <b>Attendu:</b>RavelException <br/>
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void test_loadConnectorConfiguration_004() throws Exception
  {
    final Param port = new Param();
    port.setName(ParameterName.PORT.toString());
    port.setValue("-" + Math.abs(__podam.manufacturePojo(Integer.class))); //$NON-NLS-1$
    final Exception exception = new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(Messages.getString("HSSConnector.InvalidParamValue"), port.getValue(), port.getName(), "integer value expected")); //$NON-NLS-1$ //$NON-NLS-2$
    final RavelException expected = new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(Messages.getString("HSSConnector.INITIALIZE_ERROR"), exception.getMessage())); //$NON-NLS-1$

    final Connector connector = new Connector();
    connector.setName(IHSSConnector.BEAN_ID);
    connector.getParam().addAll(Arrays.asList(__host, port));

    try
    {
      PowerMock.replayAll();

      _instance.loadConnectorConfiguration(connector);
    }
    catch (final RavelException actual)
    {
      _exception = true;

      assertEquals(expected.getFunctionalError(), actual.getFunctionalError());
      assertEquals(expected.getExceptionType(), actual.getExceptionType());
      assertEquals(expected.getErrorCode(), actual.getErrorCode());
      assertEquals(expected.getSourceComponentName(), actual.getSourceComponentName());
      assertEquals(expected.getMessage(), actual.getMessage());
    }
    finally
    {
      PowerMock.verifyAll();

      assertTrue(_exception);

      assertNotNull(_instance);
      assertEquals(Boolean.FALSE, Whitebox.getInternalState(_instance, "_enabled")); //$NON-NLS-1$
      assertEquals(IHSSConnector.BEAN_ID, Whitebox.getInternalState(_instance, "_name")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_host")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_port")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_bindPassword")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_bindDn")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_poolSize")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_startTLS")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_connectTimeout")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_responseTimeout")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_ldapSearchHsseBaseDn")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_ldapSearchHsseFilter")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_ldapSearchHssiBaseDn")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_ldapSearchHssiFilter")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_pool")); //$NON-NLS-1$
    }
  }

  /**
   * Test le cas où ParameterName.POOLSIZE n'est pas présent.<br/>
   *
   * <b>Entrées:</b><br/>
   * <b>Attendu:</b>RavelException <br/>
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void test_loadConnectorConfiguration_005() throws Exception
  {
    final Exception exception = new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(Messages.getString("HSSConnector.MissingParameter"), IHSSConnector.BEAN_ID, ParameterName.POOLSIZE.toString())); //$NON-NLS-1$
    final RavelException expected = new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(Messages.getString("HSSConnector.INITIALIZE_ERROR"), exception.getMessage())); //$NON-NLS-1$

    final Connector connector = new Connector();
    connector.setName(IHSSConnector.BEAN_ID);
    connector.getParam().addAll(Arrays.asList(__host, __port));

    try
    {
      PowerMock.replayAll();

      _instance.loadConnectorConfiguration(connector);
    }
    catch (final RavelException actual)
    {
      _exception = true;

      assertEquals(expected.getFunctionalError(), actual.getFunctionalError());
      assertEquals(expected.getExceptionType(), actual.getExceptionType());
      assertEquals(expected.getErrorCode(), actual.getErrorCode());
      assertEquals(expected.getSourceComponentName(), actual.getSourceComponentName());
      assertEquals(expected.getMessage(), actual.getMessage());
    }
    finally
    {
      PowerMock.verifyAll();

      assertTrue(_exception);

      assertNotNull(_instance);
      assertEquals(Boolean.FALSE, Whitebox.getInternalState(_instance, "_enabled")); //$NON-NLS-1$
      assertEquals(IHSSConnector.BEAN_ID, Whitebox.getInternalState(_instance, "_name")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_host")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_port")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_bindPassword")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_bindDn")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_poolSize")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_startTLS")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_connectTimeout")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_responseTimeout")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_ldapSearchHsseBaseDn")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_ldapSearchHsseFilter")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_ldapSearchHssiBaseDn")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_ldapSearchHssiFilter")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_pool")); //$NON-NLS-1$
    }
  }

  /**
   * Test le cas où ParameterName.POOLSIZE n'est pas un entier.<br/>
   *
   * <b>Entrées:</b><br/>
   * <b>Attendu:</b>RavelException <br/>
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void test_loadConnectorConfiguration_006() throws Exception
  {
    final Param poolSize = new Param();
    poolSize.setName(ParameterName.POOLSIZE.toString());
    poolSize.setValue(__podam.manufacturePojo(String.class));
    final Exception exception = new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(Messages.getString("HSSConnector.InvalidParamValue"), poolSize.getValue(), poolSize.getName(), "integer value expected")); //$NON-NLS-1$ //$NON-NLS-2$
    final RavelException expected = new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(Messages.getString("HSSConnector.INITIALIZE_ERROR"), exception.getMessage())); //$NON-NLS-1$

    final Connector connector = new Connector();
    connector.setName(IHSSConnector.BEAN_ID);
    connector.getParam().addAll(Arrays.asList(__host, __port, poolSize));

    try
    {
      PowerMock.replayAll();

      _instance.loadConnectorConfiguration(connector);
    }
    catch (final RavelException actual)
    {
      _exception = true;

      assertEquals(expected.getFunctionalError(), actual.getFunctionalError());
      assertEquals(expected.getExceptionType(), actual.getExceptionType());
      assertEquals(expected.getErrorCode(), actual.getErrorCode());
      assertEquals(expected.getSourceComponentName(), actual.getSourceComponentName());
      assertEquals(expected.getMessage(), actual.getMessage());
    }
    finally
    {
      PowerMock.verifyAll();

      assertTrue(_exception);

      assertNotNull(_instance);
      assertEquals(Boolean.FALSE, Whitebox.getInternalState(_instance, "_enabled")); //$NON-NLS-1$
      assertEquals(IHSSConnector.BEAN_ID, Whitebox.getInternalState(_instance, "_name")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_host")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_port")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_bindPassword")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_bindDn")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_poolSize")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_startTLS")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_connectTimeout")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_responseTimeout")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_ldapSearchHsseBaseDn")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_ldapSearchHsseFilter")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_ldapSearchHssiBaseDn")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_ldapSearchHssiFilter")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_pool")); //$NON-NLS-1$
    }
  }

  /**
   * Test le cas où ParameterName.POOLSIZE n'est pas un entier positif.<br/>
   *
   * <b>Entrées:</b><br/>
   * <b>Attendu:</b>RavelException <br/>
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void test_loadConnectorConfiguration_007() throws Exception
  {
    final Param poolSize = new Param();
    poolSize.setName(ParameterName.POOLSIZE.toString());
    poolSize.setValue("-" + Math.abs(__podam.manufacturePojo(Integer.class))); //$NON-NLS-1$
    final Exception exception = new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(Messages.getString("HSSConnector.InvalidParamValue"), poolSize.getValue(), poolSize.getName(), "integer value expected")); //$NON-NLS-1$ //$NON-NLS-2$
    final RavelException expected = new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(Messages.getString("HSSConnector.INITIALIZE_ERROR"), exception.getMessage())); //$NON-NLS-1$

    final Connector connector = new Connector();
    connector.setName(IHSSConnector.BEAN_ID);
    connector.getParam().addAll(Arrays.asList(__host, __port, poolSize));

    try
    {
      PowerMock.replayAll();

      _instance.loadConnectorConfiguration(connector);
    }
    catch (final RavelException actual)
    {
      _exception = true;

      assertEquals(expected.getFunctionalError(), actual.getFunctionalError());
      assertEquals(expected.getExceptionType(), actual.getExceptionType());
      assertEquals(expected.getErrorCode(), actual.getErrorCode());
      assertEquals(expected.getSourceComponentName(), actual.getSourceComponentName());
      assertEquals(expected.getMessage(), actual.getMessage());
    }
    finally
    {
      PowerMock.verifyAll();

      assertTrue(_exception);

      assertNotNull(_instance);
      assertEquals(Boolean.FALSE, Whitebox.getInternalState(_instance, "_enabled")); //$NON-NLS-1$
      assertEquals(IHSSConnector.BEAN_ID, Whitebox.getInternalState(_instance, "_name")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_host")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_port")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_bindPassword")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_bindDn")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_poolSize")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_startTLS")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_connectTimeout")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_responseTimeout")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_ldapSearchHsseBaseDn")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_ldapSearchHsseFilter")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_ldapSearchHssiBaseDn")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_ldapSearchHssiFilter")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_pool")); //$NON-NLS-1$
    }
  }

  /**
   * Test le cas où ParameterName.STARTTLS n'est pas présent.<br/>
   *
   * <b>Entrées:</b><br/>
   * <b>Attendu:</b>RavelException <br/>
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void test_loadConnectorConfiguration_008() throws Exception
  {
    final Exception exception = new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(Messages.getString("HSSConnector.MissingParameter"), IHSSConnector.BEAN_ID, ParameterName.STARTTLS.toString())); //$NON-NLS-1$
    final RavelException expected = new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(Messages.getString("HSSConnector.INITIALIZE_ERROR"), exception.getMessage())); //$NON-NLS-1$

    final Connector connector = new Connector();
    connector.setName(IHSSConnector.BEAN_ID);
    connector.getParam().addAll(Arrays.asList(__host, __port, __poolSize));

    try
    {
      PowerMock.replayAll();

      _instance.loadConnectorConfiguration(connector);
    }
    catch (final RavelException actual)
    {
      _exception = true;

      assertEquals(expected.getFunctionalError(), actual.getFunctionalError());
      assertEquals(expected.getExceptionType(), actual.getExceptionType());
      assertEquals(expected.getErrorCode(), actual.getErrorCode());
      assertEquals(expected.getSourceComponentName(), actual.getSourceComponentName());
      assertEquals(expected.getMessage(), actual.getMessage());
    }
    finally
    {
      PowerMock.verifyAll();

      assertTrue(_exception);

      assertNotNull(_instance);
      assertEquals(Boolean.FALSE, Whitebox.getInternalState(_instance, "_enabled")); //$NON-NLS-1$
      assertEquals(IHSSConnector.BEAN_ID, Whitebox.getInternalState(_instance, "_name")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_host")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_port")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_bindPassword")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_bindDn")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_poolSize")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_startTLS")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_connectTimeout")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_responseTimeout")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_ldapSearchHsseBaseDn")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_ldapSearchHsseFilter")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_ldapSearchHssiBaseDn")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_ldapSearchHssiFilter")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_pool")); //$NON-NLS-1$
    }
  }

  /**
   * Test le cas où ParameterName.LDAPSEARCH_HSSE_BASE_DN n'est pas présent.<br/>
   *
   * <b>Entrées:</b><br/>
   * <b>Attendu:</b>RavelException <br/>
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void test_loadConnectorConfiguration_009() throws Exception
  {
    final Exception exception = new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(Messages.getString("HSSConnector.MissingParameter"), IHSSConnector.BEAN_ID, ParameterName.LDAPSEARCH_HSSE_BASE_DN.toString())); //$NON-NLS-1$
    final RavelException expected = new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(Messages.getString("HSSConnector.INITIALIZE_ERROR"), exception.getMessage())); //$NON-NLS-1$

    final Connector connector = new Connector();
    connector.setName(IHSSConnector.BEAN_ID);
    connector.getParam().addAll(Arrays.asList(__host, __port, __poolSize, __startTLS));

    try
    {
      PowerMock.replayAll();

      _instance.loadConnectorConfiguration(connector);
    }
    catch (final RavelException actual)
    {
      _exception = true;

      assertEquals(expected.getFunctionalError(), actual.getFunctionalError());
      assertEquals(expected.getExceptionType(), actual.getExceptionType());
      assertEquals(expected.getErrorCode(), actual.getErrorCode());
      assertEquals(expected.getSourceComponentName(), actual.getSourceComponentName());
      assertEquals(expected.getMessage(), actual.getMessage());
    }
    finally
    {
      PowerMock.verifyAll();

      assertTrue(_exception);

      assertNotNull(_instance);
      assertEquals(Boolean.FALSE, Whitebox.getInternalState(_instance, "_enabled")); //$NON-NLS-1$
      assertEquals(IHSSConnector.BEAN_ID, Whitebox.getInternalState(_instance, "_name")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_host")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_port")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_bindPassword")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_bindDn")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_poolSize")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_startTLS")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_connectTimeout")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_responseTimeout")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_ldapSearchHsseBaseDn")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_ldapSearchHsseFilter")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_ldapSearchHssiBaseDn")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_ldapSearchHssiFilter")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_pool")); //$NON-NLS-1$
    }
  }

  /**
   * Test le cas où ParameterName.LDAPSEARCH_HSSE_FILTER n'est pas présent.<br/>
   *
   * <b>Entrées:</b><br/>
   * <b>Attendu:</b>RavelException <br/>
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void test_loadConnectorConfiguration_010() throws Exception
  {
    final Exception exception = new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(Messages.getString("HSSConnector.MissingParameter"), IHSSConnector.BEAN_ID, ParameterName.LDAPSEARCH_HSSE_FILTER.toString())); //$NON-NLS-1$
    final RavelException expected = new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(Messages.getString("HSSConnector.INITIALIZE_ERROR"), exception.getMessage())); //$NON-NLS-1$

    final Connector connector = new Connector();
    connector.setName(IHSSConnector.BEAN_ID);
    connector.getParam().addAll(Arrays.asList(__host, __port, __poolSize, __startTLS, __ldapSearchHsseBaseDn));

    try
    {
      PowerMock.replayAll();

      _instance.loadConnectorConfiguration(connector);
    }
    catch (final RavelException actual)
    {
      _exception = true;

      assertEquals(expected.getFunctionalError(), actual.getFunctionalError());
      assertEquals(expected.getExceptionType(), actual.getExceptionType());
      assertEquals(expected.getErrorCode(), actual.getErrorCode());
      assertEquals(expected.getSourceComponentName(), actual.getSourceComponentName());
      assertEquals(expected.getMessage(), actual.getMessage());
    }
    finally
    {
      PowerMock.verifyAll();

      assertTrue(_exception);

      assertNotNull(_instance);
      assertEquals(Boolean.FALSE, Whitebox.getInternalState(_instance, "_enabled")); //$NON-NLS-1$
      assertEquals(IHSSConnector.BEAN_ID, Whitebox.getInternalState(_instance, "_name")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_host")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_port")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_bindPassword")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_bindDn")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_poolSize")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_startTLS")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_connectTimeout")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_responseTimeout")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_ldapSearchHsseBaseDn")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_ldapSearchHsseFilter")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_ldapSearchHssiBaseDn")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_ldapSearchHssiFilter")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_pool")); //$NON-NLS-1$
    }
  }

  /**
   * Test le cas où ParameterName.LDAPSEARCH_HSSI_BASE_DN n'est pas présent.<br/>
   *
   * <b>Entrées:</b><br/>
   * <b>Attendu:</b>RavelException <br/>
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void test_loadConnectorConfiguration_011() throws Exception
  {
    final Exception exception = new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(Messages.getString("HSSConnector.MissingParameter"), IHSSConnector.BEAN_ID, ParameterName.LDAPSEARCH_HSSI_BASE_DN.toString())); //$NON-NLS-1$
    final RavelException expected = new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(Messages.getString("HSSConnector.INITIALIZE_ERROR"), exception.getMessage())); //$NON-NLS-1$

    final Connector connector = new Connector();
    connector.setName(IHSSConnector.BEAN_ID);
    connector.getParam().addAll(Arrays.asList(__host, __port, __poolSize, __startTLS, __ldapSearchHsseBaseDn, __ldapSearchHsseFilter));

    try
    {
      PowerMock.replayAll();

      _instance.loadConnectorConfiguration(connector);
    }
    catch (final RavelException actual)
    {
      _exception = true;

      assertEquals(expected.getFunctionalError(), actual.getFunctionalError());
      assertEquals(expected.getExceptionType(), actual.getExceptionType());
      assertEquals(expected.getErrorCode(), actual.getErrorCode());
      assertEquals(expected.getSourceComponentName(), actual.getSourceComponentName());
      assertEquals(expected.getMessage(), actual.getMessage());
    }
    finally
    {
      PowerMock.verifyAll();

      assertTrue(_exception);

      assertNotNull(_instance);
      assertEquals(Boolean.FALSE, Whitebox.getInternalState(_instance, "_enabled")); //$NON-NLS-1$
      assertEquals(IHSSConnector.BEAN_ID, Whitebox.getInternalState(_instance, "_name")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_host")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_port")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_bindPassword")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_bindDn")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_poolSize")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_startTLS")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_connectTimeout")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_responseTimeout")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_ldapSearchHsseBaseDn")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_ldapSearchHsseFilter")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_ldapSearchHssiBaseDn")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_ldapSearchHssiFilter")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_pool")); //$NON-NLS-1$
    }
  }

  /**
   * Test le cas où ParameterName.LDAPSEARCH_HSSI_FILTER n'est pas présent.<br/>
   *
   * <b>Entrées:</b><br/>
   * <b>Attendu:</b>RavelException <br/>
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void test_loadConnectorConfiguration_012() throws Exception
  {
    final Exception exception = new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(Messages.getString("HSSConnector.MissingParameter"), IHSSConnector.BEAN_ID, ParameterName.LDAPSEARCH_HSSI_FILTER.toString())); //$NON-NLS-1$
    final RavelException expected = new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(Messages.getString("HSSConnector.INITIALIZE_ERROR"), exception.getMessage())); //$NON-NLS-1$

    final Connector connector = new Connector();
    connector.setName(IHSSConnector.BEAN_ID);
    connector.getParam().addAll(Arrays.asList(__host, __port, __poolSize, __startTLS, __ldapSearchHsseBaseDn, __ldapSearchHsseFilter, __ldapSearchHssiBaseDn));

    try
    {
      PowerMock.replayAll();

      _instance.loadConnectorConfiguration(connector);
    }
    catch (final RavelException actual)
    {
      _exception = true;

      assertEquals(expected.getFunctionalError(), actual.getFunctionalError());
      assertEquals(expected.getExceptionType(), actual.getExceptionType());
      assertEquals(expected.getErrorCode(), actual.getErrorCode());
      assertEquals(expected.getSourceComponentName(), actual.getSourceComponentName());
      assertEquals(expected.getMessage(), actual.getMessage());
    }
    finally
    {
      PowerMock.verifyAll();

      assertTrue(_exception);

      assertNotNull(_instance);
      assertEquals(Boolean.FALSE, Whitebox.getInternalState(_instance, "_enabled")); //$NON-NLS-1$
      assertEquals(IHSSConnector.BEAN_ID, Whitebox.getInternalState(_instance, "_name")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_host")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_port")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_bindPassword")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_bindDn")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_poolSize")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_startTLS")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_connectTimeout")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_responseTimeout")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_ldapSearchHsseBaseDn")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_ldapSearchHsseFilter")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_ldapSearchHssiBaseDn")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_ldapSearchHssiFilter")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_pool")); //$NON-NLS-1$
    }
  }

  /**
   * Test le cas où ParameterName.BIND_DN n'est pas présent.<br/>
   *
   * <b>Entrées:</b><br/>
   * <b>Attendu:</b>RavelException <br/>
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void test_loadConnectorConfiguration_013() throws Exception
  {
    final Exception exception = new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(Messages.getString("HSSConnector.MissingParameter"), IHSSConnector.BEAN_ID, ParameterName.BIND_DN.toString())); //$NON-NLS-1$
    final RavelException expected = new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(Messages.getString("HSSConnector.INITIALIZE_ERROR"), exception.getMessage())); //$NON-NLS-1$

    final Connector connector = new Connector();
    connector.setName(IHSSConnector.BEAN_ID);
    connector.getParam().addAll(Arrays.asList(__host, __port, __poolSize, __startTLS, __ldapSearchHsseBaseDn, __ldapSearchHsseFilter, __ldapSearchHssiBaseDn, __ldapSearchHssiFilter));

    try
    {
      PowerMock.replayAll();

      _instance.loadConnectorConfiguration(connector);
    }
    catch (final RavelException actual)
    {
      _exception = true;

      assertEquals(expected.getFunctionalError(), actual.getFunctionalError());
      assertEquals(expected.getExceptionType(), actual.getExceptionType());
      assertEquals(expected.getErrorCode(), actual.getErrorCode());
      assertEquals(expected.getSourceComponentName(), actual.getSourceComponentName());
      assertEquals(expected.getMessage(), actual.getMessage());
    }
    finally
    {
      PowerMock.verifyAll();

      assertTrue(_exception);

      assertNotNull(_instance);
      assertEquals(Boolean.FALSE, Whitebox.getInternalState(_instance, "_enabled")); //$NON-NLS-1$
      assertEquals(IHSSConnector.BEAN_ID, Whitebox.getInternalState(_instance, "_name")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_host")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_port")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_bindPassword")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_bindDn")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_poolSize")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_startTLS")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_connectTimeout")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_responseTimeout")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_ldapSearchHsseBaseDn")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_ldapSearchHsseFilter")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_ldapSearchHssiBaseDn")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_ldapSearchHssiFilter")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_pool")); //$NON-NLS-1$
    }
  }

  /**
   * Test le cas où ParameterName.BIND_PASSWORD n'est pas présent.<br/>
   *
   * <b>Entrées:</b><br/>
   * <b>Attendu:</b>RavelException <br/>
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void test_loadConnectorConfiguration_014() throws Exception
  {
    final Exception exception = new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(Messages.getString("HSSConnector.MissingParameter"), IHSSConnector.BEAN_ID, ParameterName.BIND_PASSWORD.toString())); //$NON-NLS-1$
    final RavelException expected = new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(Messages.getString("HSSConnector.INITIALIZE_ERROR"), exception.getMessage())); //$NON-NLS-1$

    final Connector connector = new Connector();
    connector.setName(IHSSConnector.BEAN_ID);
    connector.getParam().addAll(Arrays.asList(__host, __port, __poolSize, __startTLS, __ldapSearchHsseBaseDn, __ldapSearchHsseFilter, __ldapSearchHssiBaseDn, __ldapSearchHssiFilter, __bindDn));

    try
    {
      PowerMock.replayAll();

      _instance.loadConnectorConfiguration(connector);
    }
    catch (final RavelException actual)
    {
      _exception = true;

      assertEquals(expected.getFunctionalError(), actual.getFunctionalError());
      assertEquals(expected.getExceptionType(), actual.getExceptionType());
      assertEquals(expected.getErrorCode(), actual.getErrorCode());
      assertEquals(expected.getSourceComponentName(), actual.getSourceComponentName());
      assertEquals(expected.getMessage(), actual.getMessage());
    }
    finally
    {
      PowerMock.verifyAll();

      assertTrue(_exception);

      assertNotNull(_instance);
      assertEquals(Boolean.FALSE, Whitebox.getInternalState(_instance, "_enabled")); //$NON-NLS-1$
      assertEquals(IHSSConnector.BEAN_ID, Whitebox.getInternalState(_instance, "_name")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_host")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_port")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_bindPassword")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_bindDn")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_poolSize")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_startTLS")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_connectTimeout")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_responseTimeout")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_ldapSearchHsseBaseDn")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_ldapSearchHsseFilter")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_ldapSearchHssiBaseDn")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_ldapSearchHssiFilter")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_pool")); //$NON-NLS-1$
    }
  }

  /**
   * Test le cas où ParameterName.BIND_PASSWORD n'est pas décryptable.<br/>
   *
   * <b>Entrées:</b><br/>
   * <b>Attendu:</b>RavelException <br/>
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void test_loadConnectorConfiguration_015() throws Exception
  {
    final Exception exception = new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.CNCTOR_00010, Messages.getString("HSSConnector.PasswordError")); //$NON-NLS-1$
    final RavelException expected = new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(Messages.getString("HSSConnector.INITIALIZE_ERROR"), exception.getMessage())); //$NON-NLS-1$

    final Connector connector = new Connector();
    connector.setName(IHSSConnector.BEAN_ID);
    connector.getParam().addAll(Arrays.asList(__host, __port, __poolSize, __startTLS, __ldapSearchHsseBaseDn, __ldapSearchHsseFilter, __ldapSearchHssiBaseDn, __ldapSearchHssiFilter, __bindDn, __bindPassword));

    try
    {
      EasyMock.expect(PasswordDecrypter.decrypt(__bindPassword.getValue())).andThrow(new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.CNCTOR_00010, "Error in PasswordDecrypter.Decrypt(): InvalidKeyException !")).once(); //$NON-NLS-1$

      PowerMock.replayAll();

      _instance.loadConnectorConfiguration(connector);
    }
    catch (final RavelException actual)
    {
      _exception = true;

      assertEquals(expected.getFunctionalError(), actual.getFunctionalError());
      assertEquals(expected.getExceptionType(), actual.getExceptionType());
      assertEquals(expected.getErrorCode(), actual.getErrorCode());
      assertEquals(expected.getSourceComponentName(), actual.getSourceComponentName());
      assertEquals(expected.getMessage(), actual.getMessage());
    }
    finally
    {
      PowerMock.verifyAll();

      assertTrue(_exception);

      assertNotNull(_instance);
      assertEquals(Boolean.FALSE, Whitebox.getInternalState(_instance, "_enabled")); //$NON-NLS-1$
      assertEquals(IHSSConnector.BEAN_ID, Whitebox.getInternalState(_instance, "_name")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_host")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_port")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_bindPassword")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_bindDn")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_poolSize")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_startTLS")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_connectTimeout")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_responseTimeout")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_ldapSearchHsseBaseDn")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_ldapSearchHsseFilter")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_ldapSearchHssiBaseDn")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_ldapSearchHssiFilter")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_pool")); //$NON-NLS-1$
    }
  }

  /**
   * Test le cas où ParameterName.CONNECT_TIMEOUT_MS n'est pas présent.<br/>
   *
   * <b>Entrées:</b><br/>
   * <b>Attendu:</b>RavelException <br/>
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void test_loadConnectorConfiguration_016() throws Exception
  {
    final Exception exception = new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(Messages.getString("HSSConnector.MissingParameter"), IHSSConnector.BEAN_ID, ParameterName.CONNECT_TIMEOUT_MS.toString())); //$NON-NLS-1$
    final RavelException expected = new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(Messages.getString("HSSConnector.INITIALIZE_ERROR"), exception.getMessage())); //$NON-NLS-1$

    final Connector connector = new Connector();
    connector.setName(IHSSConnector.BEAN_ID);
    connector.getParam().addAll(Arrays.asList(__host, __port, __poolSize, __startTLS, __ldapSearchHsseBaseDn, __ldapSearchHsseFilter, __ldapSearchHssiBaseDn, __ldapSearchHssiFilter, __bindDn, __bindPassword));

    try
    {
      EasyMock.expect(PasswordDecrypter.decrypt(__bindPassword.getValue())).andReturn(__bindPassword.getValue()).once();

      PowerMock.replayAll();

      _instance.loadConnectorConfiguration(connector);
    }
    catch (final RavelException actual)
    {
      _exception = true;

      assertEquals(expected.getFunctionalError(), actual.getFunctionalError());
      assertEquals(expected.getExceptionType(), actual.getExceptionType());
      assertEquals(expected.getErrorCode(), actual.getErrorCode());
      assertEquals(expected.getSourceComponentName(), actual.getSourceComponentName());
      assertEquals(expected.getMessage(), actual.getMessage());
    }
    finally
    {
      PowerMock.verifyAll();

      assertTrue(_exception);

      assertNotNull(_instance);
      assertEquals(Boolean.FALSE, Whitebox.getInternalState(_instance, "_enabled")); //$NON-NLS-1$
      assertEquals(IHSSConnector.BEAN_ID, Whitebox.getInternalState(_instance, "_name")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_host")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_port")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_bindPassword")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_bindDn")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_poolSize")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_startTLS")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_connectTimeout")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_responseTimeout")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_ldapSearchHsseBaseDn")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_ldapSearchHsseFilter")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_ldapSearchHssiBaseDn")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_ldapSearchHssiFilter")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_pool")); //$NON-NLS-1$
    }
  }

  /**
   * Test le cas où ParameterName.CONNECT_TIMEOUT_MS n'est pas un entier.<br/>
   *
   * <b>Entrées:</b><br/>
   * <b>Attendu:</b>RavelException <br/>
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void test_loadConnectorConfiguration_017() throws Exception
  {
    final Param connectTimeout = new Param();
    connectTimeout.setName(ParameterName.CONNECT_TIMEOUT_MS.toString());
    connectTimeout.setValue(__podam.manufacturePojo(String.class));
    final Exception exception = new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(Messages.getString("HSSConnector.InvalidParamValue"), connectTimeout.getValue(), connectTimeout.getName(), "positive integer value expected")); //$NON-NLS-1$ //$NON-NLS-2$
    final RavelException expected = new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(Messages.getString("HSSConnector.INITIALIZE_ERROR"), exception.getMessage())); //$NON-NLS-1$

    final Connector connector = new Connector();
    connector.setName(IHSSConnector.BEAN_ID);
    connector.getParam().addAll(Arrays.asList(__host, __port, __poolSize, __startTLS, __ldapSearchHsseBaseDn, __ldapSearchHsseFilter, __ldapSearchHssiBaseDn, __ldapSearchHssiFilter, __bindDn, __bindPassword, connectTimeout));

    try
    {
      EasyMock.expect(PasswordDecrypter.decrypt(__bindPassword.getValue())).andReturn(__bindPassword.getValue()).once();

      PowerMock.replayAll();

      _instance.loadConnectorConfiguration(connector);
    }
    catch (final RavelException actual)
    {
      _exception = true;

      assertEquals(expected.getFunctionalError(), actual.getFunctionalError());
      assertEquals(expected.getExceptionType(), actual.getExceptionType());
      assertEquals(expected.getErrorCode(), actual.getErrorCode());
      assertEquals(expected.getSourceComponentName(), actual.getSourceComponentName());
      assertEquals(expected.getMessage(), actual.getMessage());
    }
    finally
    {
      PowerMock.verifyAll();

      assertTrue(_exception);

      assertNotNull(_instance);
      assertEquals(Boolean.FALSE, Whitebox.getInternalState(_instance, "_enabled")); //$NON-NLS-1$
      assertEquals(IHSSConnector.BEAN_ID, Whitebox.getInternalState(_instance, "_name")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_host")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_port")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_bindPassword")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_bindDn")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_poolSize")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_startTLS")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_connectTimeout")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_responseTimeout")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_ldapSearchHsseBaseDn")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_ldapSearchHsseFilter")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_ldapSearchHssiBaseDn")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_ldapSearchHssiFilter")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_pool")); //$NON-NLS-1$
    }
  }

  /**
   * Test le cas où ParameterName.CONNECT_TIMEOUT_MS n'est pas un entier positif.<br/>
   *
   * <b>Entrées:</b><br/>
   * <b>Attendu:</b>RavelException <br/>
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void test_loadConnectorConfiguration_018() throws Exception
  {
    final Param connectTimeout = new Param();
    connectTimeout.setName(ParameterName.CONNECT_TIMEOUT_MS.toString());
    connectTimeout.setValue("-" + Math.abs(__podam.manufacturePojo(Integer.class))); //$NON-NLS-1$
    final Exception exception = new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(Messages.getString("HSSConnector.InvalidParamValue"), connectTimeout.getValue(), connectTimeout.getName(), "positive integer value expected")); //$NON-NLS-1$ //$NON-NLS-2$
    final RavelException expected = new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(Messages.getString("HSSConnector.INITIALIZE_ERROR"), exception.getMessage())); //$NON-NLS-1$

    final Connector connector = new Connector();
    connector.setName(IHSSConnector.BEAN_ID);
    connector.getParam().addAll(Arrays.asList(__host, __port, __poolSize, __startTLS, __ldapSearchHsseBaseDn, __ldapSearchHsseFilter, __ldapSearchHssiBaseDn, __ldapSearchHssiFilter, __bindDn, __bindPassword, connectTimeout));

    try
    {
      EasyMock.expect(PasswordDecrypter.decrypt(__bindPassword.getValue())).andReturn(__bindPassword.getValue()).once();

      PowerMock.replayAll();

      _instance.loadConnectorConfiguration(connector);
    }
    catch (final RavelException actual)
    {
      _exception = true;

      assertEquals(expected.getFunctionalError(), actual.getFunctionalError());
      assertEquals(expected.getExceptionType(), actual.getExceptionType());
      assertEquals(expected.getErrorCode(), actual.getErrorCode());
      assertEquals(expected.getSourceComponentName(), actual.getSourceComponentName());
      assertEquals(expected.getMessage(), actual.getMessage());
    }
    finally
    {
      PowerMock.verifyAll();

      assertTrue(_exception);

      assertNotNull(_instance);
      assertEquals(Boolean.FALSE, Whitebox.getInternalState(_instance, "_enabled")); //$NON-NLS-1$
      assertEquals(IHSSConnector.BEAN_ID, Whitebox.getInternalState(_instance, "_name")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_host")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_port")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_bindPassword")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_bindDn")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_poolSize")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_startTLS")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_connectTimeout")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_responseTimeout")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_ldapSearchHsseBaseDn")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_ldapSearchHsseFilter")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_ldapSearchHssiBaseDn")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_ldapSearchHssiFilter")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_pool")); //$NON-NLS-1$
    }
  }

  /**
   * Test le cas où ParameterName.RESPONSE_TIMEOUT_MS n'est pas présent.<br/>
   *
   * <b>Entrées:</b><br/>
   * <b>Attendu:</b>RavelException <br/>
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void test_loadConnectorConfiguration_019() throws Exception
  {
    final Exception exception = new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(Messages.getString("HSSConnector.MissingParameter"), IHSSConnector.BEAN_ID, ParameterName.RESPONSE_TIMEOUT_MS.toString())); //$NON-NLS-1$
    final RavelException expected = new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(Messages.getString("HSSConnector.INITIALIZE_ERROR"), exception.getMessage())); //$NON-NLS-1$

    final Connector connector = new Connector();
    connector.setName(IHSSConnector.BEAN_ID);
    connector.getParam().addAll(Arrays.asList(__host, __port, __poolSize, __startTLS, __ldapSearchHsseBaseDn, __ldapSearchHsseFilter, __ldapSearchHssiBaseDn, __ldapSearchHssiFilter, __bindDn, __bindPassword, __connectTimeout));

    try
    {
      EasyMock.expect(PasswordDecrypter.decrypt(__bindPassword.getValue())).andReturn(__bindPassword.getValue()).once();

      PowerMock.replayAll();

      _instance.loadConnectorConfiguration(connector);
    }
    catch (final RavelException actual)
    {
      _exception = true;

      assertEquals(expected.getFunctionalError(), actual.getFunctionalError());
      assertEquals(expected.getExceptionType(), actual.getExceptionType());
      assertEquals(expected.getErrorCode(), actual.getErrorCode());
      assertEquals(expected.getSourceComponentName(), actual.getSourceComponentName());
      assertEquals(expected.getMessage(), actual.getMessage());
    }
    finally
    {
      PowerMock.verifyAll();

      assertTrue(_exception);

      assertNotNull(_instance);
      assertEquals(Boolean.FALSE, Whitebox.getInternalState(_instance, "_enabled")); //$NON-NLS-1$
      assertEquals(IHSSConnector.BEAN_ID, Whitebox.getInternalState(_instance, "_name")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_host")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_port")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_bindPassword")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_bindDn")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_poolSize")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_startTLS")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_connectTimeout")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_responseTimeout")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_ldapSearchHsseBaseDn")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_ldapSearchHsseFilter")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_ldapSearchHssiBaseDn")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_ldapSearchHssiFilter")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_pool")); //$NON-NLS-1$
    }
  }

  /**
   * Test le cas où ParameterName.RESPONSE_TIMEOUT_MS n'est pas un entier.<br/>
   *
   * <b>Entrées:</b><br/>
   * <b>Attendu:</b>RavelException <br/>
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void test_loadConnectorConfiguration_020() throws Exception
  {
    final Param responseTimeout = new Param();
    responseTimeout.setName(ParameterName.RESPONSE_TIMEOUT_MS.toString());
    responseTimeout.setValue(__podam.manufacturePojo(String.class));
    final Exception exception = new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(Messages.getString("HSSConnector.InvalidParamValue"), responseTimeout.getValue(), responseTimeout.getName(), "positive integer value expected")); //$NON-NLS-1$ //$NON-NLS-2$
    final RavelException expected = new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(Messages.getString("HSSConnector.INITIALIZE_ERROR"), exception.getMessage())); //$NON-NLS-1$

    final Connector connector = new Connector();
    connector.setName(IHSSConnector.BEAN_ID);
    connector.getParam().addAll(Arrays.asList(__host, __port, __poolSize, __startTLS, __ldapSearchHsseBaseDn, __ldapSearchHsseFilter, __ldapSearchHssiBaseDn, __ldapSearchHssiFilter, __bindDn, __bindPassword, __connectTimeout, responseTimeout));

    try
    {
      EasyMock.expect(PasswordDecrypter.decrypt(__bindPassword.getValue())).andReturn(__bindPassword.getValue()).once();

      PowerMock.replayAll();

      _instance.loadConnectorConfiguration(connector);
    }
    catch (final RavelException actual)
    {
      _exception = true;

      assertEquals(expected.getFunctionalError(), actual.getFunctionalError());
      assertEquals(expected.getExceptionType(), actual.getExceptionType());
      assertEquals(expected.getErrorCode(), actual.getErrorCode());
      assertEquals(expected.getSourceComponentName(), actual.getSourceComponentName());
      assertEquals(expected.getMessage(), actual.getMessage());
    }
    finally
    {
      PowerMock.verifyAll();

      assertTrue(_exception);

      assertNotNull(_instance);
      assertEquals(Boolean.FALSE, Whitebox.getInternalState(_instance, "_enabled")); //$NON-NLS-1$
      assertEquals(IHSSConnector.BEAN_ID, Whitebox.getInternalState(_instance, "_name")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_host")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_port")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_bindPassword")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_bindDn")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_poolSize")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_startTLS")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_connectTimeout")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_responseTimeout")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_ldapSearchHsseBaseDn")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_ldapSearchHsseFilter")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_ldapSearchHssiBaseDn")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_ldapSearchHssiFilter")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_pool")); //$NON-NLS-1$
    }
  }

  /**
   * Test le cas où ParameterName.RESPONSE_TIMEOUT_MS n'est pas un entier positif.<br/>
   *
   * <b>Entrées:</b><br/>
   * <b>Attendu:</b>RavelException <br/>
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void test_loadConnectorConfiguration_021() throws Exception
  {
    final Param responseTimeout = new Param();
    responseTimeout.setName(ParameterName.RESPONSE_TIMEOUT_MS.toString());
    responseTimeout.setValue("-" + Math.abs(__podam.manufacturePojo(Integer.class))); //$NON-NLS-1$
    final Exception exception = new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(Messages.getString("HSSConnector.InvalidParamValue"), responseTimeout.getValue(), responseTimeout.getName(), "positive integer value expected")); //$NON-NLS-1$ //$NON-NLS-2$
    final RavelException expected = new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(Messages.getString("HSSConnector.INITIALIZE_ERROR"), exception.getMessage())); //$NON-NLS-1$

    final Connector connector = new Connector();
    connector.setName(IHSSConnector.BEAN_ID);
    connector.getParam().addAll(Arrays.asList(__host, __port, __poolSize, __startTLS, __ldapSearchHsseBaseDn, __ldapSearchHsseFilter, __ldapSearchHssiBaseDn, __ldapSearchHssiFilter, __bindDn, __bindPassword, __connectTimeout, responseTimeout));

    try
    {
      EasyMock.expect(PasswordDecrypter.decrypt(__bindPassword.getValue())).andReturn(__bindPassword.getValue()).once();

      PowerMock.replayAll();

      _instance.loadConnectorConfiguration(connector);
    }
    catch (final RavelException actual)
    {
      _exception = true;

      assertEquals(expected.getFunctionalError(), actual.getFunctionalError());
      assertEquals(expected.getExceptionType(), actual.getExceptionType());
      assertEquals(expected.getErrorCode(), actual.getErrorCode());
      assertEquals(expected.getSourceComponentName(), actual.getSourceComponentName());
      assertEquals(expected.getMessage(), actual.getMessage());
    }
    finally
    {
      PowerMock.verifyAll();

      assertTrue(_exception);

      assertNotNull(_instance);
      assertEquals(Boolean.FALSE, Whitebox.getInternalState(_instance, "_enabled")); //$NON-NLS-1$
      assertEquals(IHSSConnector.BEAN_ID, Whitebox.getInternalState(_instance, "_name")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_host")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_port")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_bindPassword")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_bindDn")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_poolSize")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_startTLS")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_connectTimeout")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_responseTimeout")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_ldapSearchHsseBaseDn")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_ldapSearchHsseFilter")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_ldapSearchHssiBaseDn")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_ldapSearchHssiFilter")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_pool")); //$NON-NLS-1$
    }
  }

  /**
   * Test le cas où le retour de l'appel à "processExtendedOperation" est KO.<br/>
   *
   * <b>Entrées:</b><br/>
   * <b>Attendu:</b>RavelException <br/>
   *
   * @throws Exception
   *           on error
   */
  @Ignore("JJY - Gèle temporaire")
  @Test
  public void test_loadConnectorConfiguration_022() throws Exception
  {
    final String message = __podam.manufacturePojo(String.class);
    final RavelException expected = new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(Messages.getString("HSSConnector.INITIALIZE_ERROR"), message)); //$NON-NLS-1$

    final Connector connector = new Connector();
    connector.setName(IHSSConnector.BEAN_ID);
    connector.getParam().addAll(Arrays.asList(__host, __port, __poolSize, __startTLS, __ldapSearchHsseBaseDn, __ldapSearchHsseFilter, __ldapSearchHssiBaseDn, __ldapSearchHssiFilter, __bindDn, __bindPassword, __connectTimeout, __responseTimeout));

    final ExtendedResult extendedResult = __podam.manufacturePojo(ExtendedResult.class);
    Whitebox.setInternalState(extendedResult, "resultCode", ResultCode.CONNECT_ERROR); //$NON-NLS-1$
    Whitebox.setInternalState(extendedResult, "diagnosticMessage", message); //$NON-NLS-1$

    try
    {
      EasyMock.expect(PasswordDecrypter.decrypt(__bindPassword.getValue())).andReturn(__bindPassword.getValue()).once();
      PowerMock.expectNew(LDAPConnection.class, new Class[] { LDAPConnectionOptions.class, String.class, int.class }, EasyMock.anyObject(LDAPConnectionOptions.class), EasyMock.eq(__host.getValue()), EasyMock.eq(Integer.valueOf(__port.getValue()))).andReturn(_ldapConnectionMock).once();
      EasyMock.expect(_ldapConnectionMock.processExtendedOperation(EasyMock.anyObject(StartTLSExtendedRequest.class))).andReturn(extendedResult).once();

      PowerMock.replayAll();

      _instance.loadConnectorConfiguration(connector);
    }
    catch (final RavelException actual)
    {
      _exception = true;

      assertEquals(expected.getFunctionalError(), actual.getFunctionalError());
      assertEquals(expected.getExceptionType(), actual.getExceptionType());
      assertEquals(expected.getErrorCode(), actual.getErrorCode());
      assertEquals(expected.getSourceComponentName(), actual.getSourceComponentName());
      assertEquals(expected.getMessage(), actual.getMessage());
    }
    finally
    {
      PowerMock.verifyAll();

      assertTrue(_exception);

      assertNotNull(_instance);
      assertEquals(Boolean.FALSE, Whitebox.getInternalState(_instance, "_enabled")); //$NON-NLS-1$
      assertEquals(IHSSConnector.BEAN_ID, Whitebox.getInternalState(_instance, "_name")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_host")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_port")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_bindPassword")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_bindDn")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_poolSize")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_startTLS")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_connectTimeout")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_responseTimeout")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_ldapSearchHsseBaseDn")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_ldapSearchHsseFilter")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_ldapSearchHssiBaseDn")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_ldapSearchHssiFilter")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_pool")); //$NON-NLS-1$
    }
  }

  /**
   * Test le cas où le retour de l'appel à "bind" est KO.<br/>
   *
   * <b>Entrées:</b><br/>
   * <b>Attendu:</b>RavelException <br/>
   *
   * @throws Exception
   *           on error
   */
  @Ignore("JJY - Gèle temporaire")
  @Test
  public void test_loadConnectorConfiguration_023() throws Exception
  {
    final String message = __podam.manufacturePojo(String.class);
    final RavelException expected = new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(Messages.getString("HSSConnector.INITIALIZE_ERROR"), message)); //$NON-NLS-1$

    final Connector connector = new Connector();
    connector.setName(IHSSConnector.BEAN_ID);
    connector.getParam().addAll(Arrays.asList(__host, __port, __poolSize, __startTLS, __ldapSearchHsseBaseDn, __ldapSearchHsseFilter, __ldapSearchHssiBaseDn, __ldapSearchHssiFilter, __bindDn, __bindPassword, __connectTimeout, __responseTimeout));

    final ExtendedResult extendedResult = __podam.manufacturePojo(ExtendedResult.class);
    Whitebox.setInternalState(extendedResult, "resultCode", ResultCode.SUCCESS); //$NON-NLS-1$
    Whitebox.setInternalState(extendedResult, "diagnosticMessage", StringConstants.EMPTY_STRING); //$NON-NLS-1$

    final BindResult bindResult = __podam.manufacturePojo(BindResult.class);
    Whitebox.setInternalState(bindResult, "resultCode", ResultCode.BUSY); //$NON-NLS-1$
    Whitebox.setInternalState(bindResult, "diagnosticMessage", message); //$NON-NLS-1$

    try
    {
      EasyMock.expect(PasswordDecrypter.decrypt(__bindPassword.getValue())).andReturn(__bindPassword.getValue()).once();
      PowerMock.expectNew(LDAPConnection.class, new Class[] { LDAPConnectionOptions.class, String.class, int.class }, EasyMock.anyObject(LDAPConnectionOptions.class), EasyMock.eq(__host.getValue()), EasyMock.eq(Integer.valueOf(__port.getValue()))).andReturn(_ldapConnectionMock).once();
      EasyMock.expect(_ldapConnectionMock.processExtendedOperation(EasyMock.anyObject(StartTLSExtendedRequest.class))).andReturn(extendedResult).once();
      EasyMock.expect(_ldapConnectionMock.bind(EasyMock.anyObject(SimpleBindRequest.class))).andReturn(bindResult).once();

      PowerMock.replayAll();

      _instance.loadConnectorConfiguration(connector);
    }
    catch (final RavelException actual)
    {
      _exception = true;

      assertEquals(expected.getFunctionalError(), actual.getFunctionalError());
      assertEquals(expected.getExceptionType(), actual.getExceptionType());
      assertEquals(expected.getErrorCode(), actual.getErrorCode());
      assertEquals(expected.getSourceComponentName(), actual.getSourceComponentName());
      assertEquals(expected.getMessage(), actual.getMessage());
    }
    finally
    {
      PowerMock.verifyAll();

      assertTrue(_exception);

      assertNotNull(_instance);
      assertEquals(Boolean.FALSE, Whitebox.getInternalState(_instance, "_enabled")); //$NON-NLS-1$
      assertEquals(IHSSConnector.BEAN_ID, Whitebox.getInternalState(_instance, "_name")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_host")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_port")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_bindPassword")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_bindDn")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_poolSize")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_startTLS")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_connectTimeout")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_responseTimeout")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_ldapSearchHsseBaseDn")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_ldapSearchHsseFilter")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_ldapSearchHssiBaseDn")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_ldapSearchHssiFilter")); //$NON-NLS-1$
      assertNull(Whitebox.getInternalState(_instance, "_pool")); //$NON-NLS-1$
    }
  }

  /**
   * Test nominal.<br/>
   *
   * <b>Entrées:</b><br/>
   * <b>Attendu:</b><br/>
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void test_loadConnectorConfiguration_024() throws Exception
  {
    final Connector connector = new Connector();
    connector.setName(IHSSConnector.BEAN_ID);
    connector.getParam().addAll(Arrays.asList(__host, __port, __poolSize, __startTLS, __ldapSearchHsseBaseDn, __ldapSearchHsseFilter, __ldapSearchHssiBaseDn, __ldapSearchHssiFilter, __bindDn, __bindPassword, __connectTimeout, __responseTimeout));

    final ExtendedResult extendedResult = __podam.manufacturePojo(ExtendedResult.class);
    Whitebox.setInternalState(extendedResult, "resultCode", ResultCode.SUCCESS); //$NON-NLS-1$
    Whitebox.setInternalState(extendedResult, "diagnosticMessage", StringConstants.EMPTY_STRING); //$NON-NLS-1$

    final BindResult bindResult = __podam.manufacturePojo(BindResult.class);
    Whitebox.setInternalState(bindResult, "resultCode", ResultCode.SUCCESS); //$NON-NLS-1$
    Whitebox.setInternalState(bindResult, "diagnosticMessage", StringConstants.EMPTY_STRING); //$NON-NLS-1$

    try
    {
      EasyMock.expect(PasswordDecrypter.decrypt(__bindPassword.getValue())).andReturn(__bindPassword.getValue()).once();
      PowerMock.expectNew(LDAPConnection.class, new Class[] { LDAPConnectionOptions.class, String.class, int.class }, EasyMock.anyObject(LDAPConnectionOptions.class), EasyMock.eq(__host.getValue()), EasyMock.eq(Integer.valueOf(__port.getValue()))).andReturn(_ldapConnectionMock).once();
      EasyMock.expect(_ldapConnectionMock.processExtendedOperation(EasyMock.anyObject(StartTLSExtendedRequest.class))).andReturn(extendedResult).once();
      EasyMock.expect(_ldapConnectionMock.bind(EasyMock.anyObject(SimpleBindRequest.class))).andReturn(bindResult).once();

      PowerMock.expectNew(LDAPConnectionPool.class, new Class[] { LDAPConnection.class, int.class, int.class, PostConnectProcessor.class }, EasyMock.anyObject(LDAPConnection.class), EasyMock.eq(1), EasyMock.eq(Integer.valueOf(__poolSize.getValue())), EasyMock.anyObject(StartTLSPostConnectProcessor.class)).andReturn(_ldapConnectionPoolMock).once();

      _ldapConnectionMock.close();
      EasyMock.expectLastCall().andVoid().once();

      PowerMock.replayAll();

      _instance.loadConnectorConfiguration(connector);
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);
      assertEquals(Boolean.FALSE, Whitebox.getInternalState(_instance, "_enabled")); //$NON-NLS-1$
      assertEquals(IHSSConnector.BEAN_ID, Whitebox.getInternalState(_instance, "_name")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_host")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_port")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_bindPassword")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_bindDn")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_poolSize")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_startTLS")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_connectTimeout")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_responseTimeout")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_ldapSearchHsseBaseDn")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_ldapSearchHsseFilter")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_ldapSearchHssiBaseDn")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_ldapSearchHssiFilter")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_pool")); //$NON-NLS-1$
    }
  }

  /**
   * Test nominal.<br/>
   *
   * <b>Entrées:</b><br/>
   * <b>Attendu:</b><br/>
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void test_loadConnectorConfiguration_025() throws Exception
  {
    final Param startTLS = new Param();
    startTLS.setName(ParameterName.STARTTLS.toString());
    startTLS.setValue("false"); //$NON-NLS-1$

    final Connector connector = new Connector();
    connector.setName(IHSSConnector.BEAN_ID);
    connector.getParam().addAll(Arrays.asList(__host, __port, __poolSize, startTLS, __ldapSearchHsseBaseDn, __ldapSearchHsseFilter, __ldapSearchHssiBaseDn, __ldapSearchHssiFilter, __bindDn, __bindPassword, __connectTimeout, __responseTimeout));

    final ExtendedResult extendedResult = __podam.manufacturePojo(ExtendedResult.class);
    Whitebox.setInternalState(extendedResult, "resultCode", ResultCode.SUCCESS); //$NON-NLS-1$
    Whitebox.setInternalState(extendedResult, "diagnosticMessage", StringConstants.EMPTY_STRING); //$NON-NLS-1$

    final BindResult bindResult = __podam.manufacturePojo(BindResult.class);
    Whitebox.setInternalState(bindResult, "resultCode", ResultCode.SUCCESS); //$NON-NLS-1$
    Whitebox.setInternalState(bindResult, "diagnosticMessage", StringConstants.EMPTY_STRING); //$NON-NLS-1$

    try
    {
      EasyMock.expect(PasswordDecrypter.decrypt(__bindPassword.getValue())).andReturn(__bindPassword.getValue()).once();
      PowerMock.expectNew(LDAPConnection.class, new Class[] { LDAPConnectionOptions.class, String.class, int.class }, EasyMock.anyObject(LDAPConnectionOptions.class), EasyMock.eq(__host.getValue()), EasyMock.eq(Integer.valueOf(__port.getValue()))).andReturn(_ldapConnectionMock).once();
      EasyMock.expect(_ldapConnectionMock.bind(EasyMock.anyObject(SimpleBindRequest.class))).andReturn(bindResult).once();

      PowerMock.expectNew(LDAPConnectionPool.class, new Class[] { LDAPConnection.class, int.class }, EasyMock.anyObject(LDAPConnection.class), EasyMock.eq(Integer.valueOf(__poolSize.getValue()))).andReturn(_ldapConnectionPoolMock).once();

      _ldapConnectionMock.close();
      EasyMock.expectLastCall().andVoid().once();

      PowerMock.replayAll();

      _instance.loadConnectorConfiguration(connector);
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);
      assertEquals(Boolean.FALSE, Whitebox.getInternalState(_instance, "_enabled")); //$NON-NLS-1$
      assertEquals(IHSSConnector.BEAN_ID, Whitebox.getInternalState(_instance, "_name")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_host")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_port")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_bindPassword")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_bindDn")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_poolSize")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_startTLS")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_connectTimeout")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_responseTimeout")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_ldapSearchHsseBaseDn")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_ldapSearchHsseFilter")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_ldapSearchHssiBaseDn")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_ldapSearchHssiFilter")); //$NON-NLS-1$
      assertNotNull(Whitebox.getInternalState(_instance, "_pool")); //$NON-NLS-1$
    }
  }
}
