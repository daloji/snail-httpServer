/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.hss;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.text.MessageFormat;
import java.time.LocalDateTime;
import java.util.UUID;

import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PowerMockListener;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.testlisteners.FieldDefaulter;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.modules.junit4.PowerMockRunnerDelegate;
import org.powermock.reflect.Whitebox;
import org.springframework.test.context.ContextConfiguration;

import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.probes.AvgDoubleCollectorItem;
import com.bytel.ravel.common.probes.AvgFlowPerSecondCollector;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.test.podam.PodamBytelJUnit4ClassRunner;
import com.bytel.ravel.common.utils.Pair;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.services.connector.ConnectorManager;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.connectors.hss.structs.ServicesHSSE;
import com.bytel.spirit.common.connectors.hss.structs.StHssiSubscriberSvcProf;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author jjoly
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PowerMockListener(FieldDefaulter.class)
@PowerMockRunnerDelegate(PodamBytelJUnit4ClassRunner.class)
@ContextConfiguration("classpath:BeansConnectorTestMocks.xml")
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
@PrepareForTest({ HSSProxy.class, ConnectorManager.class, LocalDateTime.class, UUID.class })
public final class HSSProxyTest
{
  /**
   * Factory to generate beans
   */
  private static PodamFactory __podam;

  /**
   * The current timestamp
   */
  static LocalDateTime __now;

  /**
   * Universal Unique IDentifier
   */
  static UUID __uuid;

  /**
   * The boolean
   */
  private static Boolean __boolean;

  /**
   * the IMSI
   */
  private static String __imsi;

  /**
   * The subscriber identifier
   */
  private static String __subscriberId;

  /**
   * The service HSSE
   */
  private static ServicesHSSE __service;

  /**
   * The subscriber of service Prof
   */
  private static StHssiSubscriberSvcProf __subscriber;

  /**
   * Initialize before all tests
   *
   * @throws Exception
   *           Exception to be thrown in case of failure
   */
  @BeforeClass
  public static void setUpBeforeClass() throws Exception
  {
    __podam = new PodamFactoryImpl();
    __podam.getStrategy().setMemoization(false);
    __podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());

    __now = LocalDateTime.of(2016, 8, 25, 12, 0, 0, 0);
    __uuid = UUID.fromString("1d505df9-8c31-4712-bb6c-1510794e9bc2"); //$NON-NLS-1$

    __imsi = __podam.manufacturePojoWithFullData(String.class);
    __subscriberId = __podam.manufacturePojoWithFullData(String.class);
    __boolean = __podam.manufacturePojoWithFullData(Boolean.class);
    __service = __podam.manufacturePojoWithFullData(ServicesHSSE.class);
    __subscriber = __podam.manufacturePojoWithFullData(StHssiSubscriberSvcProf.class);
  }

  /**
   * The mock object {@code AvgFlowPerSecondCollector}
   */
  @MockStrict
  AvgFlowPerSecondCollector _avgCallCounterMock;

  /**
   * The mock object {@code AvgDoubleCollectorItem}
   */
  @MockStrict
  AvgDoubleCollectorItem _avgExecTimeMock;

  /**
   * The mock object {@code ConnectorManager}
   */
  @MockStrict
  private ConnectorManager _connectorManagerMock;

  /**
   * The mock object {@code IsymantecConnector}
   */
  @MockStrict
  private IHSSConnector _hssConnectorMock;

  /**
   * The mock of object {@Code Tracabilite}
   */
  @MockStrict
  private Tracabilite _tracabiliteMock;

  /**
   * Object {@code AbstractConnectorCallTask} to evaluate
   */
  private HSSProxy _instance;

  /**
   * Exception has been thrown
   */
  private boolean _exception;

  /**
   * Initialization of tests
   *
   * @throws Exception
   *           Exception to be thrown in case of failure
   */
  @Before
  public void setUp() throws Exception
  {
    _exception = false;
    _instance = HSSProxy.getInstance();

    PowerMock.resetAll();

    PowerMock.mockStaticStrict(UUID.class);
    PowerMock.mockStaticStrict(LocalDateTime.class);
    PowerMock.mockStaticStrict(ConnectorManager.class);
  }

  /**
   * Test method for {@link com.bytel.spirit.common.connectors.hss.HSSProxy#getInstance()}.
   */
  @Test
  public final void testHSSProxy_000()
  {
    PowerMock.replayAll();

    Whitebox.setInternalState(_instance, "_avg_consulterProfilHSSE_ExecTime", _avgExecTimeMock); //$NON-NLS-1$
    Whitebox.setInternalState(_instance, "_avg_consulterProfilHSSE_call_counter", _avgCallCounterMock); //$NON-NLS-1$
    Whitebox.setInternalState(_instance, "_avg_consulterProfilHSSI_ExecTime", _avgExecTimeMock); //$NON-NLS-1$
    Whitebox.setInternalState(_instance, "_avg_consulterProfilHSSI_call_counter", _avgCallCounterMock); //$NON-NLS-1$

    PowerMock.verifyAll();

    assertNotNull(_instance);
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.common.connectors.hss.HSSProxy#consulterProfilHSSE(com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite, java.lang.String)}
   * .<br/>
   *
   * <b>Input:</b>All input are valid but exception appear when connector is search<br/>
   * <b>Expected:</b>KO<br/>
   *
   * @throws Exception
   *           On errors
   */
  @Test
  public final void testHSSProxy_001() throws Exception
  {
    final RavelException expected = new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.MGRCTR_00002, MessageFormat.format(com.bytel.ravel.services.connector.Messages.getString("ConnectorManager.UnknownConnector"), IHSSConnector.BEAN_ID)); //$NON-NLS-1$

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).once();
      EasyMock.expect(_connectorManagerMock.getConnector(IHSSConnector.BEAN_ID)).andThrow(new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.MGRCTR_00002, MessageFormat.format(com.bytel.ravel.services.connector.Messages.getString("ConnectorManager.UnknownConnector"), IHSSConnector.BEAN_ID))).once(); //$NON-NLS-1$

      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).once();
      EasyMock.expect(_connectorManagerMock.getConnector(IHSSConnector.BEAN_ID)).andReturn(_hssConnectorMock).once();
      EasyMock.expect(_hssConnectorMock.isEnabled()).andReturn(true);

      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).once();
      _connectorManagerMock.disable(IHSSConnector.BEAN_ID);
      EasyMock.expectLastCall().andVoid();

      PowerMock.replayAll();

      Whitebox.setInternalState(_instance, "_avg_consulterProfilHSSE_call_counter", _avgCallCounterMock); //$NON-NLS-1$
      Whitebox.setInternalState(_instance, "_avg_consulterProfilHSSE_ExecTime", _avgExecTimeMock); //$NON-NLS-1$
      _instance.consulterProfilHSSE(_tracabiliteMock, __imsi);
    }
    catch (final RavelException actual)
    {
      _exception = true;

      assertEquals(expected.getFunctionalError(), actual.getFunctionalError());
      assertEquals(expected.getExceptionType(), actual.getExceptionType());
      assertEquals(expected.getErrorCode(), actual.getErrorCode());
      assertEquals(expected.getSourceComponentName(), actual.getSourceComponentName());
      assertEquals(expected.getMessage(), actual.getMessage());
    }
    finally
    {
      PowerMock.verifyAll();

      assertTrue(_exception);

      assertNotNull(_instance);
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.common.connectors.hss.HSSProxy#consulterProfilHSSE(com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite, java.lang.String)}
   * .<br/>
   *
   * <b>Input:</b>All input are valid but exception appear<br/>
   * <b>Expected:</b>KO<br/>
   *
   * @throws Exception
   *           On errors
   */
  @Test
  public final void testHSSProxy_002() throws Exception
  {
    final RavelException expected = new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.MGRCTR_00002, MessageFormat.format(Messages.getString("QipEnumConnector.TechnicalExceptionMessage"), StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING)); //$NON-NLS-1$

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).once();
      EasyMock.expect(_connectorManagerMock.getConnector(IHSSConnector.BEAN_ID)).andReturn(_hssConnectorMock).once();

      _avgCallCounterMock.measure();
      EasyMock.expectLastCall().andVoid().once();

      EasyMock.expect(_hssConnectorMock.consulterProfilHSSE(_tracabiliteMock, __imsi)).andThrow(new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.MGRCTR_00002, MessageFormat.format(Messages.getString("QipEnumConnector.TechnicalExceptionMessage"), StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING))).once(); //$NON-NLS-1$

      _avgExecTimeMock.updateAvgValue(EasyMock.geq(0L));
      EasyMock.expectLastCall().andVoid().once();

      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).once();
      EasyMock.expect(_connectorManagerMock.getConnector(IHSSConnector.BEAN_ID)).andReturn(_hssConnectorMock).once();
      EasyMock.expect(_hssConnectorMock.isEnabled()).andReturn(true);

      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).once();
      _connectorManagerMock.disable(IHSSConnector.BEAN_ID);
      EasyMock.expectLastCall().andVoid();

      PowerMock.replayAll();

      Whitebox.setInternalState(_instance, "_avg_consulterProfilHSSE_call_counter", _avgCallCounterMock); //$NON-NLS-1$
      Whitebox.setInternalState(_instance, "_avg_consulterProfilHSSE_ExecTime", _avgExecTimeMock); //$NON-NLS-1$
      _instance.consulterProfilHSSE(_tracabiliteMock, __imsi);
    }
    catch (final RavelException actual)
    {
      _exception = true;

      assertEquals(expected.getFunctionalError(), actual.getFunctionalError());
      assertEquals(expected.getExceptionType(), actual.getExceptionType());
      assertEquals(expected.getErrorCode(), actual.getErrorCode());
      assertEquals(expected.getSourceComponentName(), actual.getSourceComponentName());
      assertEquals(expected.getMessage(), actual.getMessage());
    }
    finally
    {
      PowerMock.verifyAll();

      assertTrue(_exception);

      assertNotNull(_instance);
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.common.connectors.hss.HSSProxy#consulterProfilHSSE(com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite, java.lang.String)}
   * .<br/>
   *
   * <b>Input:</b>All input are valid but exception appear<br/>
   * <b>Expected:</b>KO<br/>
   *
   * @throws Exception
   *           On errors
   */
  @Test
  public final void testHSSProxy_003() throws Exception
  {
    final ConnectorResponse<ServicesHSSE, Boolean> expected = new ConnectorResponse<>(__service, __boolean);
    Pair<ServicesHSSE, Boolean> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).once();
      EasyMock.expect(_connectorManagerMock.getConnector(IHSSConnector.BEAN_ID)).andReturn(_hssConnectorMock).once();

      _avgCallCounterMock.measure();
      EasyMock.expectLastCall().andVoid().once();

      EasyMock.expect(_hssConnectorMock.consulterProfilHSSE(_tracabiliteMock, __imsi)).andReturn(new ConnectorResponse<>(__service, __boolean)).once();

      _avgExecTimeMock.updateAvgValue(EasyMock.geq(0L));
      EasyMock.expectLastCall().andVoid().once();

      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).once();
      EasyMock.expect(_connectorManagerMock.getConnector(IHSSConnector.BEAN_ID)).andReturn(_hssConnectorMock).once();
      EasyMock.expect(_hssConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      Whitebox.setInternalState(_instance, "_avg_consulterProfilHSSE_call_counter", _avgCallCounterMock); //$NON-NLS-1$
      Whitebox.setInternalState(_instance, "_avg_consulterProfilHSSE_ExecTime", _avgExecTimeMock); //$NON-NLS-1$
      actual = _instance.consulterProfilHSSE(_tracabiliteMock, __imsi);
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.common.connectors.hss.HSSProxy#consulterProfilHSSI(com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite, java.lang.String)}
   * .<br/>
   *
   * <b>Input:</b>All input are valid<br/>
   * <b>Expected:</b>OK<br/>
   *
   * @throws Exception
   *           On errors
   */
  @Test
  public final void testHSSProxy_004() throws Exception
  {
    final RavelException expected = new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.MGRCTR_00002, MessageFormat.format(com.bytel.ravel.services.connector.Messages.getString("ConnectorManager.UnknownConnector"), IHSSConnector.BEAN_ID)); //$NON-NLS-1$

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).once();
      EasyMock.expect(_connectorManagerMock.getConnector(IHSSConnector.BEAN_ID)).andThrow(new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.MGRCTR_00002, MessageFormat.format(com.bytel.ravel.services.connector.Messages.getString("ConnectorManager.UnknownConnector"), IHSSConnector.BEAN_ID))).once(); //$NON-NLS-1$

      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).once();
      EasyMock.expect(_connectorManagerMock.getConnector(IHSSConnector.BEAN_ID)).andReturn(_hssConnectorMock).once();
      EasyMock.expect(_hssConnectorMock.isEnabled()).andReturn(true);

      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).once();
      _connectorManagerMock.disable(IHSSConnector.BEAN_ID);
      EasyMock.expectLastCall().andVoid();

      PowerMock.replayAll();

      Whitebox.setInternalState(_instance, "_avg_consulterProfilHSSI_call_counter", _avgCallCounterMock); //$NON-NLS-1$
      Whitebox.setInternalState(_instance, "_avg_consulterProfilHSSI_ExecTime", _avgExecTimeMock); //$NON-NLS-1$
      _instance.consulterProfilHSSI(_tracabiliteMock, __subscriberId);
    }
    catch (final RavelException actual)
    {
      _exception = true;

      assertEquals(expected.getFunctionalError(), actual.getFunctionalError());
      assertEquals(expected.getExceptionType(), actual.getExceptionType());
      assertEquals(expected.getErrorCode(), actual.getErrorCode());
      assertEquals(expected.getSourceComponentName(), actual.getSourceComponentName());
      assertEquals(expected.getMessage(), actual.getMessage());
    }
    finally
    {
      PowerMock.verifyAll();

      assertTrue(_exception);

      assertNotNull(_instance);
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.common.connectors.hss.HSSProxy#consulterProfilHSSI(com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite, java.lang.String)}
   * .<br/>
   *
   * <b>Input:</b>All input are valid<br/>
   * <b>Expected:</b>OK<br/>
   *
   * @throws Exception
   *           On errors
   */
  @Test
  public final void testHSSProxy_005() throws Exception
  {
    final RavelException expected = new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.MGRCTR_00002, MessageFormat.format(Messages.getString("HSSConnector.TechnicalExceptionMessage"), StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING)); //$NON-NLS-1$

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).once();
      EasyMock.expect(_connectorManagerMock.getConnector(IHSSConnector.BEAN_ID)).andReturn(_hssConnectorMock).once();

      _avgCallCounterMock.measure();
      EasyMock.expectLastCall().andVoid().once();

      EasyMock.expect(_hssConnectorMock.consulterProfilHSSI(_tracabiliteMock, __subscriberId)).andThrow(new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.MGRCTR_00002, MessageFormat.format(Messages.getString("HSSConnector.TechnicalExceptionMessage"), StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING))).once(); //$NON-NLS-1$

      _avgExecTimeMock.updateAvgValue(EasyMock.geq(0L));
      EasyMock.expectLastCall().andVoid().once();

      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).once();
      EasyMock.expect(_connectorManagerMock.getConnector(IHSSConnector.BEAN_ID)).andReturn(_hssConnectorMock).once();
      EasyMock.expect(_hssConnectorMock.isEnabled()).andReturn(true);

      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).once();
      _connectorManagerMock.disable(IHSSConnector.BEAN_ID);
      EasyMock.expectLastCall().andVoid();

      PowerMock.replayAll();

      Whitebox.setInternalState(_instance, "_avg_consulterProfilHSSI_call_counter", _avgCallCounterMock); //$NON-NLS-1$
      Whitebox.setInternalState(_instance, "_avg_consulterProfilHSSI_ExecTime", _avgExecTimeMock); //$NON-NLS-1$
      _instance.consulterProfilHSSI(_tracabiliteMock, __subscriberId);
    }
    catch (final RavelException actual)
    {
      _exception = true;

      assertEquals(expected.getFunctionalError(), actual.getFunctionalError());
      assertEquals(expected.getExceptionType(), actual.getExceptionType());
      assertEquals(expected.getErrorCode(), actual.getErrorCode());
      assertEquals(expected.getSourceComponentName(), actual.getSourceComponentName());
      assertEquals(expected.getMessage(), actual.getMessage());
    }
    finally
    {
      PowerMock.verifyAll();

      assertTrue(_exception);

      assertNotNull(_instance);
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.common.connectors.hss.HSSProxy#consulterProfilHSSI(com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite, java.lang.String)}
   * .<br/>
   *
   * <b>Input:</b>All input are valid<br/>
   * <b>Expected:</b>OK<br/>
   *
   * @throws Exception
   *           On errors
   */
  @Test
  public final void testHSSProxy_006() throws Exception
  {
    final ConnectorResponse<StHssiSubscriberSvcProf, Boolean> expected = new ConnectorResponse<>(__subscriber, __boolean);
    Pair<StHssiSubscriberSvcProf, Boolean> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).once();
      EasyMock.expect(_connectorManagerMock.getConnector(IHSSConnector.BEAN_ID)).andReturn(_hssConnectorMock).once();

      _avgCallCounterMock.measure();
      EasyMock.expectLastCall().andVoid().once();

      EasyMock.expect(_hssConnectorMock.consulterProfilHSSI(_tracabiliteMock, __subscriberId)).andReturn(new ConnectorResponse<>(__subscriber, __boolean)).once();

      _avgExecTimeMock.updateAvgValue(EasyMock.geq(0L));
      EasyMock.expectLastCall().andVoid().once();

      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).once();
      EasyMock.expect(_connectorManagerMock.getConnector(IHSSConnector.BEAN_ID)).andReturn(_hssConnectorMock).once();
      EasyMock.expect(_hssConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      Whitebox.setInternalState(_instance, "_avg_consulterProfilHSSI_call_counter", _avgCallCounterMock); //$NON-NLS-1$
      Whitebox.setInternalState(_instance, "_avg_consulterProfilHSSI_ExecTime", _avgExecTimeMock); //$NON-NLS-1$
      actual = _instance.consulterProfilHSSI(_tracabiliteMock, __subscriberId);
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }
}
