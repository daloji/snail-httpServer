/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.reftech;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.apache.tomcat.jdbc.pool.DataSource;
import org.easymock.EasyMock;
import org.easymock.EasyMockSupport;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockNice;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.conf.generated.Param;
import com.bytel.ravel.common.datetime.DateTimeManager;
import com.bytel.ravel.common.encryption.PasswordDecrypter;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.test.JUnitTools;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.utils.DateTimeTools;
import com.bytel.ravel.common.utils.Pair;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.services.conf.connector.generated.Connector;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.connectors.reftech.structs.ConsulterNumeroRetour;
import com.bytel.spirit.common.connectors.reftech.structs.Numero;
import com.bytel.spirit.common.connectors.reftech.structs.Numero.NumeroBuilder;
import com.bytel.spirit.common.connectors.reftech.structs.ReftechRetour;
import com.bytel.spirit.common.connectors.reftech.structs.RessourceAdressEmail;
import com.bytel.spirit.common.connectors.reftech.structs.ServiceTechniquePpp;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 * @author jpais
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({ PasswordDecrypter.class })
@PowerMockIgnore("javax.management.*")
public class ReftechConnectorTest extends EasyMockSupport
{
  /**
   * Connector to test
   */
  private ReftechConnector _connector = new ReftechConnector();

  /**
   * Factory to generate beans
   */
  private PodamFactory _podam = new PodamFactoryImpl();

  @MockNice
  DataSource _dataSource;

  @MockNice
  Connection _connection;

  @MockNice
  CallableStatement _callableStatement;

  /**
   * ActiverConfConnexionFTTH KO
   *
   * @throws Exception
   */
  @Test
  public void activerConfConnexionFTTH_KO() throws Exception
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);

    // Setup statement mock
    _callableStatement.setString(EasyMock.eq(1), EasyMock.eq("identifiantCircuit")); //$NON-NLS-1$
    _callableStatement.setLong(EasyMock.eq(2), EasyMock.eq(10));
    _callableStatement.setString(EasyMock.eq(3), EasyMock.eq("idSession")); //$NON-NLS-1$
    _callableStatement.setString(EasyMock.eq(4), EasyMock.eq("idRaccordement")); //$NON-NLS-1$
    _callableStatement.setString(EasyMock.eq(5), EasyMock.eq("adresseIpv4Surf")); //$NON-NLS-1$
    _callableStatement.setString(EasyMock.eq(6), EasyMock.eq("passerelleIpv4Surf")); //$NON-NLS-1$
    _callableStatement.setString(EasyMock.eq(7), EasyMock.eq("masqueSousReseauIpv4Surf")); //$NON-NLS-1$
    _callableStatement.setString(EasyMock.eq(8), EasyMock.eq("adresseIpv4Partagee")); //$NON-NLS-1$
    _callableStatement.setString(EasyMock.eq(9), EasyMock.eq("adresseIpv6Prefixe")); //$NON-NLS-1$
    _callableStatement.setString(EasyMock.eq(10), EasyMock.eq("adresseIpv6Wan")); //$NON-NLS-1$

    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.getString(11)).andReturn(StringConstants.KO);
    EasyMock.expect(_callableStatement.getString(12)).andReturn(IMegConsts.CAT2);
    EasyMock.expect(_callableStatement.getString(13)).andReturn(IMegConsts.DONNEE_INCONNUE);
    EasyMock.expect(_callableStatement.getString(14)).andReturn("erreur"); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall(ReftechConnector.PKG_SPIRIT_ACTIVER_CONF)).andReturn(_callableStatement);
    PowerMock.replay(_connection);

    ConnectorResponse<Retour, Nothing> response = _connector.activerConfConnexionFTTH(tracabilite, "identifiantCircuit", 10L, "idSession", "idRaccordement", "adresseIpv4Surf", "passerelleIpv4Surf", "masqueSousReseauIpv4Surf", "adresseIpv4Partagee", "adresseIpv6Prefixe", "adresseIpv6Wan"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$//$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$

    Assert.assertEquals(RetourFactory.createKO(IMegConsts.CAT2, IMegConsts.DONNEE_INCONNUE, "erreur"), response._first); //$NON-NLS-1$

  }

  /**
   * Nominal ActiverConfConnexionFTTH
   *
   * @throws Exception
   */
  @Test
  public void activerConfConnexionFTTH_OK() throws Exception
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);

    // Setup statement mock
    _callableStatement.setString(EasyMock.eq(1), EasyMock.eq("identifiantCircuit")); //$NON-NLS-1$
    _callableStatement.setLong(EasyMock.eq(2), EasyMock.eq(10));
    _callableStatement.setString(EasyMock.eq(3), EasyMock.eq("idSession")); //$NON-NLS-1$
    _callableStatement.setString(EasyMock.eq(4), EasyMock.eq("idRaccordement")); //$NON-NLS-1$
    _callableStatement.setString(EasyMock.eq(5), EasyMock.eq("adresseIpv4Surf")); //$NON-NLS-1$
    _callableStatement.setString(EasyMock.eq(6), EasyMock.eq("passerelleIpv4Surf")); //$NON-NLS-1$
    _callableStatement.setString(EasyMock.eq(7), EasyMock.eq("masqueSousReseauIpv4Surf")); //$NON-NLS-1$
    _callableStatement.setString(EasyMock.eq(8), EasyMock.eq("adresseIpv4Partagee")); //$NON-NLS-1$
    _callableStatement.setString(EasyMock.eq(9), EasyMock.eq("adresseIpv6Prefixe")); //$NON-NLS-1$
    _callableStatement.setString(EasyMock.eq(10), EasyMock.eq("adresseIpv6Wan")); //$NON-NLS-1$

    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.getString(11)).andReturn(StringConstants.OK);
    EasyMock.expect(_callableStatement.getString(12)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(13)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(13)).andReturn(null);
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall(ReftechConnector.PKG_SPIRIT_ACTIVER_CONF)).andReturn(_callableStatement);
    PowerMock.replay(_connection);

    ConnectorResponse<Retour, Nothing> response = _connector.activerConfConnexionFTTH(tracabilite, "identifiantCircuit", 10L, "idSession", "idRaccordement", "adresseIpv4Surf", "passerelleIpv4Surf", "masqueSousReseauIpv4Surf", "adresseIpv4Partagee", "adresseIpv6Prefixe", "adresseIpv6Wan"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$//$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$

    Assert.assertEquals(RetourFactory.createOkRetour(), response._first);

  }

  /**
   * Non nominal test consulterNumero KO
   *
   * @throws Exception
   */
  @Test
  public void consulterNumeroTest_KO() throws Exception
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    String numero = "336582346423"; //$NON-NLS-1$

    // Setup statement mock
    _callableStatement.setString(EasyMock.eq(1), EasyMock.eq(numero));
    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.getString(7)).andReturn(StringConstants.NOK);
    PowerMock.replay(_callableStatement);

    ConsulterNumeroRetour retourExpected = new ConsulterNumeroRetour();

    EasyMock.expect(_connection.prepareCall(ReftechConnector.PKG_SPIRIT_CONSULTER_NUMERO)).andReturn(_callableStatement);
    PowerMock.replay(_connection);

    ConnectorResponse<ReftechRetour, ConsulterNumeroRetour> response = _connector.consulterNumero(tracabilite, numero);

    Assert.assertEquals(new Integer(0), response._first.getCodeRetour());
    Assert.assertEquals(StringConstants.NOK, response._first.getLibelleErreur());
    Assert.assertEquals(retourExpected, response._second);
  }

  /**
   * Nominal test consulterNumero OK
   *
   * @throws Exception
   */
  @Test
  public void consulterNumeroTest_OK() throws Exception
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    String numero = "336582346423"; //$NON-NLS-1$
    int statut = 56;
    int propose = 1;
    long ticket = 12345678903213421L;
    java.util.Date dateUtilEtat = new java.util.Date(System.currentTimeMillis());
    Timestamp dateEtat = new Timestamp(dateUtilEtat.getTime());
    dateEtat.getTime();
    // Setup statement mock
    _callableStatement.setString(EasyMock.eq(1), EasyMock.eq(numero));
    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.getInt(2)).andReturn(statut);
    EasyMock.expect(_callableStatement.getInt(3)).andReturn(propose);
    EasyMock.expect(_callableStatement.getTimestamp(4)).andReturn(dateEtat);
    EasyMock.expect(_callableStatement.getLong(5)).andReturn(ticket);
    EasyMock.expect(_callableStatement.getInt(6)).andReturn(1);
    EasyMock.expect(_callableStatement.getString(7)).andReturn(StringConstants.OK);
    PowerMock.replay(_callableStatement);

    LocalDateTime localTime = DateTimeTools.toLocalDateTime(dateUtilEtat);
    ConsulterNumeroRetour retourExpected = new ConsulterNumeroRetour(statut, propose, ticket, localTime);

    EasyMock.expect(_connection.prepareCall(ReftechConnector.PKG_SPIRIT_CONSULTER_NUMERO)).andReturn(_callableStatement);
    PowerMock.replay(_connection);

    ConnectorResponse<ReftechRetour, ConsulterNumeroRetour> response = _connector.consulterNumero(tracabilite, numero);

    Assert.assertEquals(new Integer(1), response._first.getCodeRetour());
    Assert.assertEquals(StringConstants.OK, response._first.getLibelleErreur());
    Assert.assertEquals(retourExpected, response._second);
  }

  /**
   * Nominal test modifierTypePortabilite OK
   *
   * @throws Exception
   */
  @Test
  public void declarerNumeroPortaEntrantTest_OK() throws Exception
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    String numero = "0198765432"; //$NON-NLS-1$
    String typeNumero = "typeNumero"; //$NON-NLS-1$
    String etat = "etat"; //$NON-NLS-1$

    String libelleErreur = "Action Réalisée avec Succès"; //$NON-NLS-1$

    // Setup statement mock
    _callableStatement.setString(EasyMock.eq(1), EasyMock.eq(numero));
    EasyMock.expectLastCall();
    _callableStatement.setString(EasyMock.eq(2), EasyMock.eq(typeNumero));
    EasyMock.expectLastCall();
    _callableStatement.setString(EasyMock.eq(3), EasyMock.eq(etat));
    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.getInt(4)).andReturn(1);
    EasyMock.expect(_callableStatement.getString(5)).andReturn(libelleErreur);
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall(ReftechConnector.PKG_SPIRIT_DECLARER_NUMERO_PORTA_ENTRANT)).andReturn(_callableStatement);
    PowerMock.replay(_connection);

    ConnectorResponse<ReftechRetour, Nothing> response = _connector.declarerNumeroPortaEntrant(tracabilite, numero, typeNumero, etat);

    Assert.assertEquals(new Integer(1), response._first.getCodeRetour());
    Assert.assertEquals(libelleErreur, response._first.getLibelleErreur());
    Assert.assertNull(response._second);
  }

  /**
   * Nominal test lireRessourceAdresseEmail OK
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void lireRessourceAdresseEmailTest_OK() throws Exception
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    String adressMail = "email@email.fr"; //$NON-NLS-1$
    String statut = "56"; //$NON-NLS-1$
    String stlac_ID = "56"; //$NON-NLS-1$
    int ticket = 123;
    java.util.Date dateUtilEtat = new java.util.Date(System.currentTimeMillis());
    Timestamp dateEtat = new Timestamp(dateUtilEtat.getTime());
    dateEtat.getTime();

    java.util.Date dateUtilEcheance = new java.util.Date(System.currentTimeMillis());
    Timestamp dateEcheance = new Timestamp(dateUtilEcheance.getTime());
    dateEcheance.getTime();

    // Setup statement mock
    _callableStatement.setString(EasyMock.eq(1), EasyMock.eq(adressMail));
    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.getString(2)).andReturn(statut);
    EasyMock.expect(_callableStatement.getInt(3)).andReturn(ticket);
    EasyMock.expect(_callableStatement.getTimestamp(4)).andReturn(dateEtat);
    EasyMock.expect(_callableStatement.getString(5)).andReturn(stlac_ID);
    EasyMock.expect(_callableStatement.getTimestamp(6)).andReturn(dateEcheance);
    EasyMock.expect(_callableStatement.getInt(7)).andReturn(1);
    EasyMock.expect(_callableStatement.getString(8)).andReturn(StringConstants.OK);
    PowerMock.replay(_callableStatement);

    LocalDateTime localTimeEtat = DateTimeTools.toLocalDateTime(dateUtilEtat);
    LocalDateTime localTimeEcheance = DateTimeTools.toLocalDateTime(dateUtilEcheance);
    RessourceAdressEmail ressourceAdressEmail = new RessourceAdressEmail(stlac_ID, localTimeEtat, localTimeEcheance, ticket, statut);

    EasyMock.expect(_connection.prepareCall(ReftechConnector.PKG_SPIRIT_LIRE_RESSOURCE_ADRESSE_EMAIL)).andReturn(_callableStatement);
    PowerMock.replay(_connection);

    ConnectorResponse<ReftechRetour, RessourceAdressEmail> response = _connector.lireRessourceAdresseEmail(tracabilite, adressMail);

    Assert.assertEquals(new Integer(1), response._first.getCodeRetour());
    Assert.assertEquals(StringConstants.OK, response._first.getLibelleErreur());
    Assert.assertEquals(ressourceAdressEmail, response._second);
  }

  /**
   * Nominal test lireRessourceNoTelephone OK
   *
   * @throws Exception
   */
  @Test
  public void lireRessourceNoTelephoneTest_OK() throws Exception
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    String noTelephone = "981114124214"; //$NON-NLS-1$
    String statut = "statut"; //$NON-NLS-1$
    String idStLienAllocation = "idStLienAllocation"; //$NON-NLS-1$

    // Setup statement mock
    _callableStatement.setString(EasyMock.eq(1), EasyMock.eq(noTelephone));
    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.getString(2)).andReturn(statut);
    EasyMock.expect(_callableStatement.getString(3)).andReturn(idStLienAllocation);
    EasyMock.expect(_callableStatement.getInt(4)).andReturn(1);
    EasyMock.expect(_callableStatement.getString(5)).andReturn(StringConstants.OK);
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall(ReftechConnector.PKG_SPIRIT_LIRE_RESSOURCE_NO_TELEPHONE)).andReturn(_callableStatement);
    PowerMock.replay(_connection);

    ConnectorResponse<ReftechRetour, Pair<String, String>> response = _connector.lireRessourceNoTelephone(tracabilite, noTelephone);

    Assert.assertEquals(new Integer(1), response._first.getCodeRetour());
    Assert.assertEquals(StringConstants.OK, response._first.getLibelleErreur());
    Assert.assertEquals(new Pair<>(statut, idStLienAllocation), response._second);
  }

  /**
   * Nominal test lireRessourceNoTelephoneV2 OK
   *
   * @throws Exception
   */
  @Test
  public void lireRessourceNoTelephoneV2Test_OK() throws Exception
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    String noTelephone = "981114124214"; //$NON-NLS-1$
    String statut = "statut"; //$NON-NLS-1$
    String ticket = "ticket"; //$NON-NLS-1$
    String typeNumero = "typeNumero"; //$NON-NLS-1$
    String idStLienAllocation = "idStLienAllocation"; //$NON-NLS-1$

    java.util.Date dateUtilEtat = new java.util.Date(System.currentTimeMillis());
    Date dateEtat = new Date(dateUtilEtat.getTime());
    Timestamp dateEtatStamp = new Timestamp(dateEtat.getTime());
    LocalDateTime localTime = DateTimeTools.toLocalDateTime(dateUtilEtat);

    LocalDateTime dateFinReservation = DateTimeManager.getInstance().now().plusDays(1);
    Timestamp dateFinReservationTimestamp = Timestamp.valueOf(dateFinReservation);

    String typePortabilite = "typePortabilite"; //$NON-NLS-1$

    Numero numero = new NumeroBuilder() //
        .dateEtat(localTime) //
        .etat(statut) //
        .idStLienAllocation(idStLienAllocation) //
        .numero(noTelephone) //
        .ticket(ticket) //
        .typeNumero(typeNumero) //
        .dateFinReservation(dateFinReservation) //
        .typePortabilite(typePortabilite) //
        .build();

    // Setup statement mock
    _callableStatement.setString(EasyMock.eq(1), EasyMock.eq(noTelephone));
    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.getString(2)).andReturn(statut);
    EasyMock.expect(_callableStatement.getString(3)).andReturn(idStLienAllocation);
    EasyMock.expect(_callableStatement.getTimestamp(4)).andReturn(dateEtatStamp);
    EasyMock.expect(_callableStatement.getString(5)).andReturn(ticket);
    EasyMock.expect(_callableStatement.getString(6)).andReturn(typeNumero);
    EasyMock.expect(_callableStatement.getTimestamp(7)).andReturn(dateFinReservationTimestamp);
    EasyMock.expect(_callableStatement.getString(8)).andReturn(typePortabilite);
    EasyMock.expect(_callableStatement.getInt(9)).andReturn(1);
    EasyMock.expect(_callableStatement.getString(10)).andReturn(StringConstants.OK);
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall(ReftechConnector.PKG_SPIRIT_LIRE_RESSOURCE_NO_TELEPHONE_V2)).andReturn(_callableStatement);
    PowerMock.replay(_connection);

    ConnectorResponse<ReftechRetour, Numero> response = _connector.lireRessourceNoTelephoneV2(tracabilite, noTelephone);

    Assert.assertEquals(new Integer(1), response._first.getCodeRetour());
    Assert.assertEquals(StringConstants.OK, response._first.getLibelleErreur());
    Assert.assertEquals(numero, response._second);
  }

  /**
   * Nominal test lireServiceTechniquePpp OK
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void lireServiceTechniquePpp_OK() throws Exception
  {
    // Prepare call params
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    String srvId = "srvId_Test"; //$NON-NLS-1$

    // Prepare values from db
    String statut = "statut_Test"; //$NON-NLS-1$
    String comentaire = "comentaire_Test"; //$NON-NLS-1$
    String identifiantPpp = "identifiantPpp_Test"; //$NON-NLS-1$
    String motDePassePpp = "motDePassePpp_Test"; //$NON-NLS-1$

    // Setup statement mock
    _callableStatement.setString(1, srvId);
    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.getString(2)).andReturn(statut);
    EasyMock.expect(_callableStatement.getString(3)).andReturn(comentaire);
    EasyMock.expect(_callableStatement.getString(4)).andReturn(identifiantPpp);
    EasyMock.expect(_callableStatement.getString(5)).andReturn(motDePassePpp);

    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall(ReftechConnector.PKG_SPIRIT_LIRE_SERVICE_TECHNIQUE_PPP)).andReturn(_callableStatement);
    PowerMock.replay(_connection);

    ConnectorResponse<ServiceTechniquePpp, Nothing> response = _connector.lireServiceTechniquePpp(tracabilite, srvId);

    // Prepare expected ServiceTechniquePpp
    ServiceTechniquePpp expectedServiceTechniquePpp = new ServiceTechniquePpp("statut_Test", //$NON-NLS-1$
        "comentaire_Test", //$NON-NLS-1$
        "identifiantPpp_Test", //$NON-NLS-1$
        "motDePassePpp_Test"); //$NON-NLS-1$

    Assert.assertEquals(expectedServiceTechniquePpp, response._first);
  }

  /**
   ** Test load configuration without DB_CONNECTIONSTRING.
   */
  @Test
  public void loadConnectorConfigurationTest_KO1()
  {
    final Connector connector = new Connector();
    connector.setName("ReftechConnector"); //$NON-NLS-1$
    List<Param> paramList = new ArrayList<>();

    Param param = new Param();
    param.setName(ReftechConnector.ParameterName.DB_CONNECTIONSTRING.name());
    param.setValue(""); //$NON-NLS-1$
    paramList.add(param);

    connector.getParam().addAll(paramList);

    try
    {
      _connector.loadConnectorConfiguration(connector);
    }
    catch (RavelException e_p)
    {
      Assert.assertEquals(ExceptionType.INVALID_CONFIGURATION, e_p.getExceptionType());
      Assert.assertEquals(ErrorCode.CNCTOR_00020, e_p.getErrorCode());
      Assert.assertEquals("Connector 'ReftechConnector': The DB_CONNECTIONSTRING parameter is missing.", e_p.getMessage()); //$NON-NLS-1$
    }
  }

  /**
   ** Test load configuration without DB_USERNAME.
   */
  @Test
  public void loadConnectorConfigurationTest_KO2()
  {
    final Connector connector = new Connector();
    connector.setName("ReftechConnector"); //$NON-NLS-1$

    List<Param> paramList = new ArrayList<>();

    Param param = new Param();
    param.setName(ReftechConnector.ParameterName.DB_CONNECTIONSTRING.name());
    param.setValue("connectiongString"); //$NON-NLS-1$
    paramList.add(param);

    param = new Param();
    param.setName(ReftechConnector.ParameterName.DB_USERNAME.name());
    param.setValue(""); //$NON-NLS-1$
    paramList.add(param);

    connector.getParam().addAll(paramList);

    try
    {
      _connector.loadConnectorConfiguration(connector);
    }
    catch (RavelException e_p)
    {
      Assert.assertEquals(ExceptionType.INVALID_CONFIGURATION, e_p.getExceptionType());
      Assert.assertEquals(ErrorCode.CNCTOR_00020, e_p.getErrorCode());
      Assert.assertEquals("Connector 'ReftechConnector': The DB_USERNAME parameter is missing.", e_p.getMessage()); //$NON-NLS-1$
    }
  }

  /**
   ** Test load configuration without DB_PASSWORD.
   */
  @Test
  public void loadConnectorConfigurationTest_KO3()
  {
    final Connector connector = new Connector();
    connector.setName("ReftechConnector"); //$NON-NLS-1$

    List<Param> paramList = new ArrayList<>();

    Param param = new Param();
    param.setName(ReftechConnector.ParameterName.DB_CONNECTIONSTRING.name());
    param.setValue("connectiongString"); //$NON-NLS-1$
    paramList.add(param);

    param = new Param();
    param.setName(ReftechConnector.ParameterName.DB_USERNAME.name());
    param.setValue("TEST"); //$NON-NLS-1$
    paramList.add(param);

    param = new Param();
    param.setName(ReftechConnector.ParameterName.DB_PASSWORD.name());
    param.setValue(""); //$NON-NLS-1$
    paramList.add(param);

    connector.getParam().addAll(paramList);

    try
    {
      _connector.loadConnectorConfiguration(connector);
    }
    catch (RavelException e_p)
    {
      Assert.assertEquals(ExceptionType.INVALID_CONFIGURATION, e_p.getExceptionType());
      Assert.assertEquals(ErrorCode.CNCTOR_00020, e_p.getErrorCode());
      Assert.assertEquals("Connector 'ReftechConnector': The DB_PASSWORD parameter is missing.", e_p.getMessage()); //$NON-NLS-1$

    }
  }

  /**
   * Test load configuration with all parameters OK
   *
   * @throws RavelException
   */
  @Test
  public void loadConnectorConfigurationTest_OK() throws RavelException
  {
    final Connector connector = new Connector();
    List<Param> paramList = new ArrayList<>();

    Param param = new Param();
    param.setName(ReftechConnector.ParameterName.DB_CONNECTIONSTRING.name());
    param.setValue("connectiongString"); //$NON-NLS-1$
    paramList.add(param);

    param = new Param();
    param.setName(ReftechConnector.ParameterName.DB_USERNAME.name());
    param.setValue("TEST"); //$NON-NLS-1$
    paramList.add(param);

    param = new Param();
    param.setName(ReftechConnector.ParameterName.DB_PASSWORD.name());
    param.setValue("EmoEOmWbGT/DKV9ZjcD/3A=="); //$NON-NLS-1$
    paramList.add(param);

    param = new Param();
    param.setName(ReftechConnector.ParameterName.POOLSIZE.name());
    param.setValue(String.valueOf(20));
    paramList.add(param);

    param = new Param();
    param.setName(ReftechConnector.ParameterName.CONNECT_TIMEOUT_SEC.name());
    param.setValue(String.valueOf(5));
    paramList.add(param);

    param = new Param();
    param.setName(ReftechConnector.ParameterName.READ_TIMEOUT_SEC.name());
    param.setValue(String.valueOf(30));
    paramList.add(param);

    param = new Param();
    param.setName(ReftechConnector.ParameterName.QUERY_TIMEOUT_SEC.name());
    param.setValue(String.valueOf(600));
    paramList.add(param);

    connector.getParam().addAll(paramList);

    _connector.loadConnectorConfiguration(connector);
  }

  /**
   * Nominal test modifierStatutAdressMail OK
   *
   * @throws Exception
   */
  @Test
  public void modifierStatutAdressMailTest_OK() throws Exception
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    String adresseMail = "test@test.com"; //$NON-NLS-1$
    String statut = "ALLOUE"; //$NON-NLS-1$
    String idStLienAllocation = "123456789"; //$NON-NLS-1$

    // Setup statement mock
    _callableStatement.setString(EasyMock.eq(1), EasyMock.eq(adresseMail));
    EasyMock.expectLastCall();
    _callableStatement.setString(EasyMock.eq(2), EasyMock.eq(statut));
    EasyMock.expectLastCall();
    _callableStatement.setString(EasyMock.eq(3), EasyMock.eq(idStLienAllocation));
    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.getInt(4)).andReturn(1);
    EasyMock.expect(_callableStatement.getString(5)).andReturn(StringConstants.OK);
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall(ReftechConnector.PKG_SPIRIT_MODIFIER_STATUT_ADRESS_MAIL)).andReturn(_callableStatement);
    PowerMock.replay(_connection);

    ConnectorResponse<ReftechRetour, Nothing> response = _connector.modifierStatutAdressMail(tracabilite, adresseMail, statut, idStLienAllocation);

    Assert.assertEquals(new Integer(1), response._first.getCodeRetour());
    Assert.assertEquals(StringConstants.OK, response._first.getLibelleErreur());
    Assert.assertNull(response._second);
  }

  /**
   * Nominal test modifierStatutNoTelephone OK
   *
   * @throws Exception
   */
  @Test
  public void modifierStatutNoTelephoneTest_OK() throws Exception
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    String noTelephone = "0198765432"; //$NON-NLS-1$
    String statut = "ALLOUE"; //$NON-NLS-1$
    String idStLienAllocation = "123456789"; //$NON-NLS-1$
    String libelleErreur = "Action Réalisée avec Succès"; //$NON-NLS-1$

    // Setup statement mock
    _callableStatement.setString(EasyMock.eq(1), EasyMock.eq(noTelephone));
    EasyMock.expectLastCall();
    _callableStatement.setString(EasyMock.eq(2), EasyMock.eq(statut));
    EasyMock.expectLastCall();
    _callableStatement.setString(EasyMock.eq(3), EasyMock.eq(idStLienAllocation));
    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.getInt(4)).andReturn(1);
    EasyMock.expect(_callableStatement.getString(5)).andReturn(libelleErreur);
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall(ReftechConnector.PKG_SPIRIT_MODIFIER_STATUT_NO_TELEPHONE)).andReturn(_callableStatement);
    PowerMock.replay(_connection);

    ConnectorResponse<ReftechRetour, Nothing> response = _connector.modifierStatutNoTelephone(tracabilite, noTelephone, statut, idStLienAllocation);

    Assert.assertEquals(new Integer(1), response._first.getCodeRetour());
    Assert.assertEquals(libelleErreur, response._first.getLibelleErreur());
    Assert.assertNull(response._second);
  }

  /**
   * Nominal test modifierTypePortabilite OK
   *
   * @throws Exception
   */
  @Test
  public void modifierTypePortabiliteTest_OK() throws Exception
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    String numero = "0198765432"; //$NON-NLS-1$
    String typeNumero = "typeNumero"; //$NON-NLS-1$
    String typePortabilite = "typePortabilite"; //$NON-NLS-1$

    String libelleErreur = "Action Réalisée avec Succès"; //$NON-NLS-1$

    // Setup statement mock
    _callableStatement.setString(EasyMock.eq(1), EasyMock.eq(numero));
    EasyMock.expectLastCall();
    _callableStatement.setString(EasyMock.eq(2), EasyMock.eq(typeNumero));
    EasyMock.expectLastCall();
    _callableStatement.setString(EasyMock.eq(3), EasyMock.eq(typePortabilite));
    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.getInt(4)).andReturn(1);
    EasyMock.expect(_callableStatement.getString(5)).andReturn(libelleErreur);
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall(ReftechConnector.PKG_SPIRIT_MODIFIER_TYPE_PORTABILITE)).andReturn(_callableStatement);
    PowerMock.replay(_connection);

    ConnectorResponse<ReftechRetour, Nothing> response = _connector.modifierTypePortabilite(tracabilite, numero, typeNumero, typePortabilite);

    Assert.assertEquals(new Integer(1), response._first.getCodeRetour());
    Assert.assertEquals(libelleErreur, response._first.getLibelleErreur());
    Assert.assertNull(response._second);
  }

  /**
   * Nominal test PurgeEmailGele OK
   *
   * @throws Exception
   */
  @Test
  public void purgeEmailGeleTest_OK() throws Exception
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    String adresseMail = "test@test.com"; //$NON-NLS-1$

    // Setup statement mock
    _callableStatement.setString(EasyMock.eq(1), EasyMock.eq(adresseMail));
    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.getInt(2)).andReturn(1);
    EasyMock.expect(_callableStatement.getString(3)).andReturn(StringConstants.OK);
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall(ReftechConnector.PKG_SPIRIT_PURGE_EMAIL_GELE)).andReturn(_callableStatement);
    PowerMock.replay(_connection);

    ConnectorResponse<ReftechRetour, Nothing> response = _connector.purgeEmailGele(tracabilite, adresseMail);

    Assert.assertEquals(new Integer(1), response._first.getCodeRetour());
    Assert.assertEquals(StringConstants.OK, response._first.getLibelleErreur());
    Assert.assertNull(response._second);
  }

  /**
   * Nominal test recupererCompteMailParAdrMail OK
   *
   * @throws Exception
   */
  @Test
  public void recupererCompteMailParAdrMailTest_OK() throws Exception
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    String adresseMail = "test@test.com"; //$NON-NLS-1$

    // Setup statement mock
    _callableStatement.setString(EasyMock.eq(1), EasyMock.eq(adresseMail));
    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.getInt(2)).andReturn(123456789);
    EasyMock.expect(_callableStatement.getInt(3)).andReturn(1);
    EasyMock.expect(_callableStatement.getString(4)).andReturn(StringConstants.OK);
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall(ReftechConnector.PKG_SPIRIT_RECUPERER_COMPTE_MAIL_PAR_ADR_MAIL)).andReturn(_callableStatement);
    PowerMock.replay(_connection);

    ConnectorResponse<ReftechRetour, Integer> response = _connector.recupererCompteMailParAdrMail(tracabilite, adresseMail);

    Assert.assertEquals(new Integer(1), response._first.getCodeRetour());
    Assert.assertEquals(StringConstants.OK, response._first.getLibelleErreur());
    Assert.assertEquals(new Integer(123456789), response._second);
  }

  /**
   * Nominal test reserveAdresseMailSecondaire OK
   *
   * @throws Exception
   */
  @Test
  public void reserveAdresseMailSecondaireTest_OK() throws Exception
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    String adresseMail = "test@test.com"; //$NON-NLS-1$

    // Setup statement mock
    _callableStatement.setString(EasyMock.eq(1), EasyMock.eq(adresseMail));
    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.getInt(2)).andReturn(1);
    EasyMock.expect(_callableStatement.getString(3)).andReturn(StringConstants.OK);
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall(ReftechConnector.PKG_SPIRIT_RESERVE_ADRESSE_MAIL_SECONDAIRE)).andReturn(_callableStatement);
    PowerMock.replay(_connection);

    ConnectorResponse<ReftechRetour, Nothing> response = _connector.reserveAdresseMailSecondaire(tracabilite, adresseMail);

    Assert.assertEquals(new Integer(1), response._first.getCodeRetour());
    Assert.assertEquals(StringConstants.OK, response._first.getLibelleErreur());
    Assert.assertNull(response._second);
  }

  @Before
  public void setUp() throws Exception
  {
    _podam.getStrategy().setMemoization(false);
    _podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());

    PowerMock.mockStatic(PasswordDecrypter.class);
    EasyMock.expect(_dataSource.getConnection()).andReturn(_connection).anyTimes();
    PowerMock.replay(_dataSource);

    JUnitTools.setInaccessibleFieldValue(_connector, "_datasource", _dataSource); //$NON-NLS-1$

  }

  /**
   * Nominal supprimerConfConnexionFTTH
   *
   * @throws Exception
   */
  @Test
  public void supprimerConfConnexionFTTH_K0() throws Exception
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    String adresseMail = "test@test.com"; //$NON-NLS-1$

    // Setup statement mock
    _callableStatement.setString(EasyMock.eq(1), EasyMock.eq(adresseMail));
    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.getString(2)).andReturn(StringConstants.KO);
    EasyMock.expect(_callableStatement.getString(3)).andReturn(IMegConsts.CAT2);
    EasyMock.expect(_callableStatement.getString(4)).andReturn(IMegConsts.DONNEE_INCONNUE);
    EasyMock.expect(_callableStatement.getString(5)).andReturn("erreur"); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall(ReftechConnector.PKG_SPIRIT_SUPPRIMER_CONF)).andReturn(_callableStatement);
    PowerMock.replay(_connection);

    ConnectorResponse<Retour, Nothing> response = _connector.supprimerConfConnexionFTTH(tracabilite, "identifiantCircuit"); //$NON-NLS-1$

    Assert.assertEquals(RetourFactory.createKO(IMegConsts.CAT2, IMegConsts.DONNEE_INCONNUE, "erreur"), response._first); //$NON-NLS-1$
    Assert.assertNull(response._second);
  }

  /**
   * Nominal supprimerConfConnexionFTTH
   *
   * @throws Exception
   */
  @Test
  public void supprimerConfConnexionFTTH_OK() throws Exception
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    String adresseMail = "test@test.com"; //$NON-NLS-1$

    // Setup statement mock
    _callableStatement.setString(EasyMock.eq(1), EasyMock.eq(adresseMail));
    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.getString(2)).andReturn(StringConstants.OK);
    EasyMock.expect(_callableStatement.getString(3)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(4)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(5)).andReturn(null);
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall(ReftechConnector.PKG_SPIRIT_SUPPRIMER_CONF)).andReturn(_callableStatement);
    PowerMock.replay(_connection);

    ConnectorResponse<Retour, Nothing> response = _connector.supprimerConfConnexionFTTH(tracabilite, "identifiantCircuit"); //$NON-NLS-1$

    Assert.assertEquals(RetourFactory.createOkRetour(), response._first);
    Assert.assertNull(response._second);
  }
}
