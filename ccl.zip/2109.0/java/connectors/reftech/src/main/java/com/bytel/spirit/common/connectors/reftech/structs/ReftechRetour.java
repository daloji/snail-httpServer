/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.reftech.structs;

import java.io.Serializable;
import java.util.Objects;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * @author jpais
 * @version ($Revision$ $Date$)
 */
public class ReftechRetour implements Serializable
{
  private static final long serialVersionUID = -257423512943094894L;

  /**
   * codeRetour attribute
   */
  @SerializedName("codeRetour")
  @Expose
  private Integer _codeRetour;

  /**
   * libelleErreur attribute
   */
  @SerializedName("libelleErreur")
  @Expose
  private String _libelleErreur;

  /**
   * Default constructor.
   * 
   * @param codeRetour_p
   * @param libelleErreur_p
   */
  public ReftechRetour(Integer codeRetour_p, String libelleErreur_p)
  {
    _codeRetour = codeRetour_p;
    _libelleErreur = libelleErreur_p;
  }

  /**
   * @return value of _codeRetour
   */
  public Integer getCodeRetour()
  {
    return _codeRetour;
  }

  /**
   * @param codeRetour_p
   *          The _codeRetour to set.
   */
  public void setCodeRetour(Integer codeRetour_p)
  {
    _codeRetour = codeRetour_p;
  }

  /**
   * @return value of _libelleErreur
   */
  public String getLibelleErreur()
  {
    return _libelleErreur;
  }

  /**
   * @param libelleErreur_p
   *          The _libelleErreur to set.
   */
  public void setLibelleErreur(String libelleErreur_p)
  {
    _libelleErreur = libelleErreur_p;
  }

  @Override
  public boolean equals(Object o_p)
  {
    if (this == o_p)
      return true;
    if (o_p == null || getClass() != o_p.getClass())
      return false;
    ReftechRetour that = (ReftechRetour) o_p;
    return Objects.equals(_codeRetour, that._codeRetour) && Objects.equals(_libelleErreur, that._libelleErreur);
  }

  @Override
  public int hashCode()
  {

    return Objects.hash(_codeRetour, _libelleErreur);
  }
}
