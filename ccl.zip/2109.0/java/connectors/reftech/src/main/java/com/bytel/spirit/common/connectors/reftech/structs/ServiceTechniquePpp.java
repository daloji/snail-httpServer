/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.reftech.structs;

import java.io.Serializable;
import java.util.Objects;

/**
 * @author rafcosta
 * @version ($Revision$ $Date$)
 */
public class ServiceTechniquePpp implements Serializable
{
  /** Generated SerialVersionUID */
  private static final long serialVersionUID = -2574866361045069261L;

  /** Statut */
  private String _statut;

  /** Commentaire */
  private String _commentaire;

  /** Identifiant PPP */
  private String _identifiantPpp;

  /** Mot de Passe PPP */
  private String _motDePassePpp;

  public ServiceTechniquePpp(String statut_p, String commentaire_p, String identifiantPpp_p, String motDePassePpp_p)
  {
    _statut = statut_p;
    _commentaire = commentaire_p;
    _identifiantPpp = identifiantPpp_p;
    _motDePassePpp = motDePassePpp_p;
  }

  @Override
  public boolean equals(Object o_p)
  {
    if (this == o_p)
    {
      return true;
    }
    if (o_p == null || getClass() != o_p.getClass())
    {
      return false;
    }
    ServiceTechniquePpp that = (ServiceTechniquePpp) o_p;
    return Objects.equals(_statut, that._statut) && Objects.equals(_commentaire, that._commentaire) && Objects.equals(_identifiantPpp, that._identifiantPpp) && Objects.equals(_motDePassePpp, that._motDePassePpp);
  }

  /**
   * @return value of _commentaire
   */
  public String getCommentaire()
  {
    return _commentaire;
  }

  /**
   * @return value of _identifiantPpp
   */
  public String getIdentifiantPpp()
  {
    return _identifiantPpp;
  }

  /**
   * @return value of _motDePassePpp
   */
  public String getMotDePassePpp()
  {
    return _motDePassePpp;
  }

  /**
   * @return value of _statut
   */
  public String getStatut()
  {
    return _statut;
  }

  @Override
  public int hashCode()
  {
    return Objects.hash(_statut, _commentaire, _identifiantPpp, _motDePassePpp);
  }

  /**
   * @param commentaire_p
   *          The _commentaire to set.
   */
  public void setCommentaire(String commentaire_p)
  {
    _commentaire = commentaire_p;
  }

  /**
   * @param identifiantPpp_p
   *          The _identifiantPpp to set.
   */
  public void setIdentifiantPpp(String identifiantPpp_p)
  {
    _identifiantPpp = identifiantPpp_p;
  }

  /**
   * @param motDePassePpp_p
   *          The _motDePassePpp to set.
   */
  public void setMotDePassePpp(String motDePassePpp_p)
  {
    _motDePassePpp = motDePassePpp_p;
  }

  /**
   * @param statut_p
   *          The _statut to set.
   */
  public void setStatut(String statut_p)
  {
    _statut = statut_p;
  }
}
