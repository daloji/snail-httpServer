/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.reftech;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.probes.AvgDoubleCollectorItem;
import com.bytel.ravel.common.probes.AvgFlowPerSecondCollector;
import com.bytel.ravel.common.probes.RavelProbeConfigurationManager;
import com.bytel.ravel.common.utils.Pair;
import com.bytel.ravel.services.connector.BaseProxy;
import com.bytel.ravel.services.connector.ConnectorExecution;
import com.bytel.ravel.services.connector.ConnectorManager;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.connectors.reftech.structs.ConsulterNumeroRetour;
import com.bytel.spirit.common.connectors.reftech.structs.Numero;
import com.bytel.spirit.common.connectors.reftech.structs.ReftechRetour;
import com.bytel.spirit.common.connectors.reftech.structs.RessourceAdressEmail;
import com.bytel.spirit.common.connectors.reftech.structs.ServiceTechniquePpp;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

/**
 * @author jpais
 * @version ($Revision$ $Date$)
 */
public final class ReftechProxy extends BaseProxy implements IReftech
{
  /**
   * Proxy name.
   */
  private static final String PROXY_NAME = "ReftechProxy"; //$NON-NLS-1$

  /**
   * Proxy instance.
   */
  private static ReftechProxy _instance = new ReftechProxy();

  /**
   * @return The proxy instance.
   */
  public static ReftechProxy getInstance()
  {
    return _instance;
  }

  /**
   * For probe to count the amount of call to the purgeEmailGele operation
   */
  AvgFlowPerSecondCollector _avg_purgeEmailGele_call_counter;

  /**
   * For probe to count the execution time of call to the purgeEmailGele operation
   */
  AvgDoubleCollectorItem _avg_purgeEmailGele_ExecTime;

  /**
   * For probe to count the amount of call to the reserveAdresseMailSecondaire operation
   */
  AvgFlowPerSecondCollector _avg_reserveAdresseMailSecondaire_call_counter;

  /**
   * For probe to count the execution time of call to the reserveAdresseMailSecondaire operation
   */
  AvgDoubleCollectorItem _avg_creserveAdresseMailSecondaire_ExecTime;

  /**
   * For probe to count the amount of call to the modifierStatutAdressMail operation
   */
  AvgFlowPerSecondCollector _avg_modifierStatutAdressMail_call_counter;

  /**
   * For probe to count the execution time of call to the modifierStatutAdressMail operation
   */
  AvgDoubleCollectorItem _avg_modifierStatutAdressMail_ExecTime;

  /**
   * For probe to count the amount of call to the modifierStatutNoTelephone operation
   */
  AvgFlowPerSecondCollector _avg_modifierStatutNoTelephone_call_counter;

  /**
   * For probe to count the execution time of call to the modifierStatutNoTelephone operation
   */
  AvgDoubleCollectorItem _avg_modifierStatutNoTelephone_ExecTime;

  /**
   * For probe to count the amount of call to the lireRessourceNoTelephone operation
   */
  AvgFlowPerSecondCollector _avg_lireRessourceNoTelephone_call_counter;

  /**
   * For probe to count the execution time of call to the lireRessourceNoTelephone operation
   */
  AvgDoubleCollectorItem _avg_lireRessourceNoTelephone_ExecTime;

  /**
   * For probe to count the amount of call to the recupererCompteMailParAdrMail operation
   */
  AvgFlowPerSecondCollector _avg_recupererCompteMailParAdrMail_call_counter;

  /**
   * For probe to count the execution time of call to the recupererCompteMailParAdrMail operation
   */
  AvgDoubleCollectorItem _avg_recupererCompteMailParAdrMail_ExecTime;

  /**
   * For probe to count the amount of call to the consulterNumero operation
   */
  AvgFlowPerSecondCollector _avg_consulterNumero_call_counter;

  /**
   * For probe to count the execution time of call to the consulterNumero operation
   */
  AvgDoubleCollectorItem _avg_consulterNumero_ExecTime;

  /**
   * For probe to count the amount of call to the modifierTypePortabilite operation
   */
  AvgFlowPerSecondCollector _avg_modifierTypePortabilite_call_counter;

  /**
   * For probe to count the execution time of call to the modifierTypePortabilite operation
   */
  AvgDoubleCollectorItem _avg_modifierTypePortabilite_ExecTime;

  /**
   * For probe to count the amount of call to the declarerNumeroPortaEntrant operation
   */
  AvgFlowPerSecondCollector _avg_declarerNumeroPortaEntrant_call_counter;

  /**
   * For probe to count the execution time of call to the declarerNumeroPortaEntrant operation
   */
  AvgDoubleCollectorItem _avg_declarerNumeroPortaEntrant_ExecTime;

  /**
   * For probe to count the amount of call to the lireRessourceAdresseEmail operation
   */
  AvgFlowPerSecondCollector _avg_lireRessourceAdresseEmail_call_counter;

  /**
   * For probe to count the execution time of call to the lireRessourceAdresseEmail operation
   */
  AvgDoubleCollectorItem _avg_lireRessourceAdresseEmail_ExecTime;

  /**
   * For probe to count the amount of call to the lireServiceTechniquePpp operation
   */
  AvgFlowPerSecondCollector _avg_lireServiceTechniquePpp_call_counter;

  /**
   * For probe to count the execution time of call to the lireServiceTechniquePpp operation
   */
  AvgDoubleCollectorItem _avg_lireServiceTechniquePpp_ExecTime;

  /**
   * For probe to count the amount of call to the activerConfConnexionFTTH operation
   */
  AvgFlowPerSecondCollector _avg_activerConfConnexionFTTH_call_counter;

  /**
   * For probe to count the execution time of call to the activerConfConnexionFTTH operation
   */
  AvgDoubleCollectorItem _avg_activerConfConnexionFTTH_ExecTime;

  /**
   * For probe to count the amount of call to the supprimerConfConnexionFTTH operation
   */
  AvgFlowPerSecondCollector _avg_supprimerConfConnexionFTTH_call_counter;

  /**
   * For probe to count the execution time of call to the supprimerConfConnexionFTTH operation
   */
  AvgDoubleCollectorItem _avg_supprimerConfConnexionFTTH_ExecTime;

  /**
   * Constructor
   */
  private ReftechProxy()
  {
    _avg_reserveAdresseMailSecondaire_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_reserveAdresseMailSecondaire_call_counter", PROXY_NAME); //$NON-NLS-1$
    _avg_creserveAdresseMailSecondaire_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_reserveAdresseMailSecondaire_ExecTime", PROXY_NAME); //$NON-NLS-1$
    _avg_modifierStatutAdressMail_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_modifierStatutAdressMail_call_counter", PROXY_NAME); //$NON-NLS-1$
    _avg_modifierStatutAdressMail_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_modifierStatutAdressMail_ExecTime", PROXY_NAME); //$NON-NLS-1$
    _avg_modifierStatutNoTelephone_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_modifierStatutNoTelephone_call_counter", PROXY_NAME); //$NON-NLS-1$
    _avg_modifierStatutNoTelephone_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_modifierStatutNoTelephone_ExecTime", PROXY_NAME); //$NON-NLS-1$
    _avg_recupererCompteMailParAdrMail_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_recupererCompteMailParAdrMail_call_counter", PROXY_NAME); //$NON-NLS-1$
    _avg_recupererCompteMailParAdrMail_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_recupererCompteMailParAdrMail_ExecTime", PROXY_NAME); //$NON-NLS-1$
    _avg_lireRessourceNoTelephone_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_lireRessourceNoTelephone_call_counter", PROXY_NAME); //$NON-NLS-1$
    _avg_lireRessourceNoTelephone_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_lireRessourceNoTelephone_ExecTime", PROXY_NAME); //$NON-NLS-1$
    _avg_consulterNumero_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_consulterNumero_call_counter", PROXY_NAME); //$NON-NLS-1$
    _avg_consulterNumero_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_consulterNumero_ExecTime", PROXY_NAME); //$NON-NLS-1$
    _avg_lireRessourceAdresseEmail_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_lireRessourceAdresseEmail_call_counter", PROXY_NAME); //$NON-NLS-1$
    _avg_lireRessourceAdresseEmail_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_lireRessourceAdresseEmail_ExecTime", PROXY_NAME); //$NON-NLS-1$
    _avg_modifierTypePortabilite_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_modifierTypePortabilite_call_counter", PROXY_NAME); //$NON-NLS-1$
    _avg_modifierTypePortabilite_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_modifierTypePortabilite_ExecTime", PROXY_NAME); //$NON-NLS-1$
    _avg_declarerNumeroPortaEntrant_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_declarerNumeroPortaEntrant_call_counter", PROXY_NAME); //$NON-NLS-1$
    _avg_declarerNumeroPortaEntrant_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_declarerNumeroPortaEntrant_ExecTime", PROXY_NAME); //$NON-NLS-1$
    _avg_purgeEmailGele_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_purgeEmailGele_call_counter", PROXY_NAME); //$NON-NLS-1$
    _avg_purgeEmailGele_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_purgeEmailGele_ExecTime", PROXY_NAME); //$NON-NLS-1$
    _avg_lireServiceTechniquePpp_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_lireServiceTechniquePpp_call_counter", PROXY_NAME); //$NON-NLS-1$
    _avg_lireServiceTechniquePpp_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_lireServiceTechniquePpp_ExecTime", PROXY_NAME); //$NON-NLS-1$
    _avg_activerConfConnexionFTTH_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_activerConfConnexionFTTH_call_counter", PROXY_NAME); //$NON-NLS-1$
    _avg_activerConfConnexionFTTH_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_activerConfConnexionFTTH_call_counter_ExecTime", PROXY_NAME); //$NON-NLS-1$
    _avg_supprimerConfConnexionFTTH_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_supprimerConfConnexionFTTH_call_counter", PROXY_NAME); //$NON-NLS-1$
    _avg_supprimerConfConnexionFTTH_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_supprimerConfConnexionFTTH_ExecTime", PROXY_NAME); //$NON-NLS-1$

  }

  @Override
  public ConnectorResponse<Retour, Nothing> activerConfConnexionFTTH(Tracabilite tracabilite_p, String identifiantCircuit_p, long srvId_p, String idSession_p, String idRaccordement_p, String adresseIpv4Surf_p, String passerelleIpv4Surf_p, String masqueSousReseauIpv4Surf_p, String adresseIpv4Partagee_p, String adresseIpv6Prefixe_p, String adresseIpv6Wan_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IReftechConnector.BEAN_ID)
    {

      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        IReftechConnector irexConnector = (IReftechConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_activerConfConnexionFTTH_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return irexConnector.activerConfConnexionFTTH(tracabilite_p, identifiantCircuit_p, srvId_p, idSession_p, idRaccordement_p, adresseIpv4Surf_p, passerelleIpv4Surf_p, masqueSousReseauIpv4Surf_p, adresseIpv4Partagee_p, adresseIpv6Prefixe_p, adresseIpv6Wan_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_activerConfConnexionFTTH_ExecTime.updateAvgValue(endTime - startTime);
        }
      }

    });
  }

  @Override
  public ConnectorResponse<ReftechRetour, ConsulterNumeroRetour> consulterNumero(Tracabilite tracabilite_p, String numero_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<ReftechRetour, ConsulterNumeroRetour>>(IReftechConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<ReftechRetour, ConsulterNumeroRetour> run() throws RavelException
      {
        IReftechConnector irexConnector = (IReftechConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_reserveAdresseMailSecondaire_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return irexConnector.consulterNumero(tracabilite_p, numero_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_creserveAdresseMailSecondaire_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<ReftechRetour, Nothing> declarerNumeroPortaEntrant(Tracabilite tracabilite_p, String numero_p, String typeNumero_p, String etat_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<ReftechRetour, Nothing>>(IReftechConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<ReftechRetour, Nothing> run() throws RavelException
      {
        IReftechConnector irexConnector = (IReftechConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_declarerNumeroPortaEntrant_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return irexConnector.declarerNumeroPortaEntrant(tracabilite_p, numero_p, typeNumero_p, etat_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_declarerNumeroPortaEntrant_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<ReftechRetour, RessourceAdressEmail> lireRessourceAdresseEmail(Tracabilite tracabilite_p, String adresseMail_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<ReftechRetour, RessourceAdressEmail>>(IReftechConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<ReftechRetour, RessourceAdressEmail> run() throws RavelException
      {
        IReftechConnector irexConnector = (IReftechConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_lireRessourceAdresseEmail_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return irexConnector.lireRessourceAdresseEmail(tracabilite_p, adresseMail_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_lireRessourceAdresseEmail_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<ReftechRetour, Pair<String, String>> lireRessourceNoTelephone(Tracabilite tracabilite_p, String noTelephone_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<ReftechRetour, Pair<String, String>>>(IReftechConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<ReftechRetour, Pair<String, String>> run() throws RavelException
      {
        IReftechConnector irexConnector = (IReftechConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_lireRessourceNoTelephone_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return irexConnector.lireRessourceNoTelephone(tracabilite_p, noTelephone_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_lireRessourceNoTelephone_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<ReftechRetour, Numero> lireRessourceNoTelephoneV2(final Tracabilite tracabilite_p, final String noTelephone_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<ReftechRetour, Numero>>(IReftechConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<ReftechRetour, Numero> run() throws RavelException
      {
        IReftechConnector irexConnector = (IReftechConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_lireRessourceNoTelephone_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return irexConnector.lireRessourceNoTelephoneV2(tracabilite_p, noTelephone_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_lireRessourceNoTelephone_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<ServiceTechniquePpp, Nothing> lireServiceTechniquePpp(Tracabilite tracabilite_p, String srvId_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<ServiceTechniquePpp, Nothing>>(IReftechConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<ServiceTechniquePpp, Nothing> run() throws RavelException
      {
        IReftechConnector irexConnector = (IReftechConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_lireServiceTechniquePpp_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return irexConnector.lireServiceTechniquePpp(tracabilite_p, srvId_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_lireServiceTechniquePpp_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<ReftechRetour, Nothing> modifierStatutAdressMail(Tracabilite tracabilite_p, String adresseMail_p, String statut_p, String idStLienAllocation_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<ReftechRetour, Nothing>>(IReftechConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<ReftechRetour, Nothing> run() throws RavelException
      {
        IReftechConnector irexConnector = (IReftechConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_modifierStatutAdressMail_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return irexConnector.modifierStatutAdressMail(tracabilite_p, adresseMail_p, statut_p, idStLienAllocation_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_modifierStatutAdressMail_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<ReftechRetour, Nothing> modifierStatutNoTelephone(Tracabilite tracabilite_p, String noTelephone_p, String statut_p, String idStLienAllocation_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<ReftechRetour, Nothing>>(IReftechConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<ReftechRetour, Nothing> run() throws RavelException
      {
        IReftechConnector irexConnector = (IReftechConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_modifierStatutNoTelephone_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return irexConnector.modifierStatutNoTelephone(tracabilite_p, noTelephone_p, statut_p, idStLienAllocation_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_modifierStatutNoTelephone_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<ReftechRetour, Nothing> modifierTypePortabilite(Tracabilite tracabilite_p, String numero_p, String typeNumero_p, String typePortabilite_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<ReftechRetour, Nothing>>(IReftechConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<ReftechRetour, Nothing> run() throws RavelException
      {
        IReftechConnector irexConnector = (IReftechConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_modifierTypePortabilite_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return irexConnector.modifierTypePortabilite(tracabilite_p, numero_p, typeNumero_p, typePortabilite_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_modifierTypePortabilite_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<ReftechRetour, Nothing> purgeEmailGele(Tracabilite tracabilite_p, String adresseMail_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<ReftechRetour, Nothing>>(IReftechConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<ReftechRetour, Nothing> run() throws RavelException
      {
        IReftechConnector irexConnector = (IReftechConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_purgeEmailGele_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return irexConnector.purgeEmailGele(tracabilite_p, adresseMail_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_purgeEmailGele_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<ReftechRetour, Integer> recupererCompteMailParAdrMail(Tracabilite tracabilite_p, String adresseMail_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<ReftechRetour, Integer>>(IReftechConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<ReftechRetour, Integer> run() throws RavelException
      {
        IReftechConnector irexConnector = (IReftechConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_recupererCompteMailParAdrMail_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return irexConnector.recupererCompteMailParAdrMail(tracabilite_p, adresseMail_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_recupererCompteMailParAdrMail_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<ReftechRetour, Nothing> reserveAdresseMailSecondaire(Tracabilite tracabilite_p, String adresseMail_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<ReftechRetour, Nothing>>(IReftechConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<ReftechRetour, Nothing> run() throws RavelException
      {
        IReftechConnector irexConnector = (IReftechConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_reserveAdresseMailSecondaire_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return irexConnector.reserveAdresseMailSecondaire(tracabilite_p, adresseMail_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_creserveAdresseMailSecondaire_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> supprimerConfConnexionFTTH(Tracabilite tracabilite_p, String identifiantCircuit_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IReftechConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        IReftechConnector irexConnector = (IReftechConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_supprimerConfConnexionFTTH_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return irexConnector.supprimerConfConnexionFTTH(tracabilite_p, identifiantCircuit_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_supprimerConfConnexionFTTH_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }
}
