/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.reftech.structs;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 *
 * @author jrolao
 * @version ($Revision$ $Date$)
 */
public class RessourceAdressEmail implements Serializable
{
  /**
  * Serial UID
  */
  private static final long serialVersionUID = 6293556155742427837L;

  /**
   * STLAC_ID
   */
  private String _stLacId;

  /**
   * Date de dernière modification du numéro dans les référentiels du ST OSS FAI
   */
  private LocalDateTime _dateEtat;

  /**
   * Date de Echeance
   */
  private LocalDateTime _dateEcheance;

  /**
   * Identifiant du ticket de proposition / réservation. <br />
   * Normallement uniquement applicable pour les etats PROPOSE et RESERVE <br />
   * Mais il est susceptible d'être présent pour les autres états. <br />
   */
  private int _ticket;

  /**
   * Le statut
   */
  private String _statut;

  /**
   * Default constructor
   */
  public RessourceAdressEmail()
  {
    // Nothing to do
  }

  /**
   * @param stLacId_p
   *          STLAC_ID
   * @param dateEtat_p
   *          La dateEtat
   * @param dateEcheance_p
   *          La dateEcheance
   * @param ticket_p
   *          Ticket de la ressource
   * @param statut_p
   *          Statut de la ressource
   */
  public RessourceAdressEmail(String stLacId_p, LocalDateTime dateEtat_p, LocalDateTime dateEcheance_p, int ticket_p, String statut_p)
  {
    _stLacId = stLacId_p;
    _dateEtat = dateEtat_p;
    _dateEcheance = dateEcheance_p;
    _ticket = ticket_p;
    _statut = statut_p;
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    RessourceAdressEmail other = (RessourceAdressEmail) obj;
    if (_dateEcheance == null)
    {
      if (other._dateEcheance != null)
      {
        return false;
      }
    }
    else if (!_dateEcheance.equals(other._dateEcheance))
    {
      return false;
    }
    if (_dateEtat == null)
    {
      if (other._dateEtat != null)
      {
        return false;
      }
    }
    else if (!_dateEtat.equals(other._dateEtat))
    {
      return false;
    }
    if (_statut == null)
    {
      if (other._statut != null)
      {
        return false;
      }
    }
    else if (!_statut.equals(other._statut))
    {
      return false;
    }
    if (_stLacId == null)
    {
      if (other._stLacId != null)
      {
        return false;
      }
    }
    else if (!_stLacId.equals(other._stLacId))
    {
      return false;
    }
    if (_ticket != other._ticket)
    {
      return false;
    }
    return true;
  }

  /**
   * @return the dateEcheance
   */
  public LocalDateTime getDateEcheance()
  {
    return _dateEcheance;
  }

  /**
   * @return the dateEtat
   */
  public LocalDateTime getDateEtat()
  {
    return _dateEtat;
  }

  /**
   * @return the statut
   */
  public String getStatut()
  {
    return _statut;
  }

  /**
   * @return the stlac_ID
   */
  public String getStLacId()
  {
    return _stLacId;
  }

  /**
   * @return the ticket
   */
  public int getTicket()
  {
    return _ticket;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_dateEcheance == null) ? 0 : _dateEcheance.hashCode());
    result = (prime * result) + ((_dateEtat == null) ? 0 : _dateEtat.hashCode());
    result = (prime * result) + ((_statut == null) ? 0 : _statut.hashCode());
    result = (prime * result) + ((_stLacId == null) ? 0 : _stLacId.hashCode());
    result = (prime * result) + _ticket;
    return result;
  }

  /**
   * @param dateEcheance_p
   *          the dateEcheance to set
   */
  public void setDateEcheance(LocalDateTime dateEcheance_p)
  {
    _dateEcheance = dateEcheance_p;
  }

  /**
   * @param dateEtat_p
   *          the dateEtat to set
   */
  public void setDateEtat(LocalDateTime dateEtat_p)
  {
    _dateEtat = dateEtat_p;
  }

  /**
   * @param statut_p
   *          the statut to set
   */
  public void setStatut(String statut_p)
  {
    _statut = statut_p;
  }

  /**
   * @param stLacId_p
   *          the stlac_ID to set
   */
  public void setStLacId(String stLacId_p)
  {
    _stLacId = stLacId_p;
  }

  /**
   * @param ticket_p
   *          the ticket to set
   */
  public void setTicket(int ticket_p)
  {
    _ticket = ticket_p;
  }

  @Override
  public String toString()
  {
    return "RessourceAdressEmail [stlac_ID=" + _stLacId + ", dateEtat=" + _dateEtat + ", dateEcheance=" + _dateEcheance + ", ticket=" + _ticket + ", statut=" + _statut + "]";
  }
}
