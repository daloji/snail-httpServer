/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.reftech;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.utils.Pair;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.connectors.reftech.structs.ConsulterNumeroRetour;
import com.bytel.spirit.common.connectors.reftech.structs.Numero;
import com.bytel.spirit.common.connectors.reftech.structs.ReftechRetour;
import com.bytel.spirit.common.connectors.reftech.structs.RessourceAdressEmail;
import com.bytel.spirit.common.connectors.reftech.structs.ServiceTechniquePpp;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

/**
 * @author jpais
 * @version ($Revision$ $Date$)
 */
public interface IReftech
{
  /**
   * activation Config FTTH
   *
   * @param tracabilite_p
   *          tracabilte
   * @param identifiantCircuit_p
   *          identifiant Circuit
   * @param srvId_p
   *          serv id
   * @param idSession_p
   *          id session
   * @param idRaccordement_p
   *          id Raccordement
   * @param adresseIpv4Surf_p
   *          adress IPV4
   * @param passerelleIpv4Surf_p
   *          passerellet IPv4
   * @param masqueSousReseauIpv4Surf_p
   *          masque sous reseau
   * @param adresseIpv4Partagee_p
   *          adresse Ipv4
   * @param adresseIpv6Prefixe_p
   *          adresse Ipv6
   * @param adresseIpv6Wan_p
   *          adresse Ipv6
   * @return ConnectorResponse<ReftechRetour, Nothing>
   * @throws RavelException
   *           exception
   */
  public ConnectorResponse<Retour, Nothing> activerConfConnexionFTTH(Tracabilite tracabilite_p, String identifiantCircuit_p, long srvId_p, String idSession_p, String idRaccordement_p, String adresseIpv4Surf_p, String passerelleIpv4Surf_p, String masqueSousReseauIpv4Surf_p, String adresseIpv4Partagee_p, String adresseIpv6Prefixe_p, String adresseIpv6Wan_p) throws RavelException;

  /**
   * Permettant de consulter le numero à modifier.
   *
   * @param tracabilite_p
   *          La traçabilité
   * @param numero_p
   *          Numero à modifier
   * @return
   * @throws RavelException
   */
  public ConnectorResponse<ReftechRetour, ConsulterNumeroRetour> consulterNumero(Tracabilite tracabilite_p, String numero_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          La traçabilité
   * @param numero_p
   *          Le Numero
   * @param typeNumero_p
   *          Le Type Numero
   * @param etat_p
   *          L'Etat
   * @return ConnectorResponse<ReftechRetour, Nothing>
   * @throws RavelException
   *           on error
   */
  public ConnectorResponse<ReftechRetour, Nothing> declarerNumeroPortaEntrant(Tracabilite tracabilite_p, String numero_p, String typeNumero_p, String etat_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          La traçabilité
   * @param adresseMail_p
   *          Adresse Mail
   * @return ConnectorResponse<ReftechRetour, RessourceAdressEmail>
   * @throws RavelException
   *           on error
   */
  public ConnectorResponse<ReftechRetour, RessourceAdressEmail> lireRessourceAdresseEmail(Tracabilite tracabilite_p, String adresseMail_p) throws RavelException;

  /**
   * Permettant de recuperer une ressource avec son numero de telephone sur la chaine Legacy.
   *
   * @param tracabilite_p
   *          La traçabilité
   * @param noTelephone_p
   *          Le numero Telephone
   * @return ConnectorResponse<ReftechRetour, Pair<statut, idStLienAllocation>>
   * @throws RavelException
   */
  public ConnectorResponse<ReftechRetour, Pair<String, String>> lireRessourceNoTelephone(Tracabilite tracabilite_p, String noTelephone_p) throws RavelException;

  /**
   * Permettant de recuperer une ressource avec son numero de telephone sur la chaine Legacy.
   *
   * @param tracabilite_p
   *          La traçabilité
   * @param noTelephone_p
   *          Le numero Telephone
   * @return ConnectorResponse<ReftechRetour, Numero>
   * @throws RavelException
   */
  public ConnectorResponse<ReftechRetour, Numero> lireRessourceNoTelephoneV2(Tracabilite tracabilite_p, String noTelephone_p) throws RavelException;

  /**
   * Permettant de recuperer une service technique PPP.
   *
   * @param tracabilite_p
   *          La traçabilité
   * @param srvId_p
   *          Le srvId
   * @return ConnectorResponse<ServiceTechniquePpp, Nothing>
   * @throws RavelException
   */
  public ConnectorResponse<ServiceTechniquePpp, Nothing> lireServiceTechniquePpp(Tracabilite tracabilite_p, String srvId_p) throws RavelException;

  /**
   * Permettant de modifier le statut de la ressource Mail sur la chaine Legacy.
   *
   * @param tracabilite_p
   *          La traçabilité
   * @param adresseMail_p
   *          Adresse Mail secondaire à réserver
   * @param statut_p
   *          Statut de la Ressource (ALLOUE, QUARANTAINE)
   * @param idStLienAllocation_p
   *          Identifiant du Service Technique SPIRIT
   * @return
   * @throws RavelException
   */
  public ConnectorResponse<ReftechRetour, Nothing> modifierStatutAdressMail(Tracabilite tracabilite_p, String adresseMail_p, String statut_p, String idStLienAllocation_p) throws RavelException;

  /**
   * Permettant de modifier le statut du numero de telephone sur la chaine Legacy.
   *
   * @param tracabilite_p
   *          La traçabilité
   * @param noTelephone_p
   *          Le numero Telephone
   * @param statut_p
   *          Statut cible
   * @param idStLienAllocation_p
   *          Identifiant du service Technique
   * @return ConnectorResponse<ReftechRetour, Nothing>
   * @throws RavelException
   */
  public ConnectorResponse<ReftechRetour, Nothing> modifierStatutNoTelephone(Tracabilite tracabilite_p, String noTelephone_p, String statut_p, String idStLienAllocation_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          La traçabilité
   * @param numero_p
   *          Le numero Telephone
   * @param typeNumero_p
   *          Le type numero Telephone
   * @param typePortabilite_p
   *          Le type Portabilite
   * @return ConnectorResponse<ReftechRetour, Nothing>
   * @throws RavelException
   *           on error
   */
  public ConnectorResponse<ReftechRetour, Nothing> modifierTypePortabilite(Tracabilite tracabilite_p, String numero_p, String typeNumero_p, String typePortabilite_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          La Traçabilité
   * @param adresseMail_p
   *          Adresse Mail
   * @return ConnectorResponse<ReftechRetour, Nothing>
   * @throws RavelException
   *           on error
   */
  public ConnectorResponse<ReftechRetour, Nothing> purgeEmailGele(Tracabilite tracabilite_p, String adresseMail_p) throws RavelException;

  /**
   * Pour récupérer l’identifiant de la boite mail à partir d’une adresse mail sur la chaine Legacy.
   *
   * @param tracabilite_p
   *          La traçabilité
   * @param adresseMail_p
   *          Adresse Mail secondaire à réserver
   * @return
   * @throws RavelException
   */
  public ConnectorResponse<ReftechRetour, Integer> recupererCompteMailParAdrMail(Tracabilite tracabilite_p, String adresseMail_p) throws RavelException;

  /**
   * Permettant de réserver un mail secondaire sur la chaine Legacy.
   *
   * @param tracabilite_p
   *          La traçabilitéadresseIpv6Wan
   * @param adresseMail_p
   *          Adresse Mail secondaire à réserver
   * @return
   * @throws RavelException
   */
  public ConnectorResponse<ReftechRetour, Nothing> reserveAdresseMailSecondaire(Tracabilite tracabilite_p, String adresseMail_p) throws RavelException;

  /**
   * Suppressuin conf Connexion
   *
   * @param tracabilite_p
   *          tracabilite
   * @param identifiantCircuit_p
   *          identifiant Circuit
   * @return
   * @throws RavelException
   */
  public ConnectorResponse<Retour, Nothing> supprimerConfConnexionFTTH(Tracabilite tracabilite_p, String identifiantCircuit_p) throws RavelException;
}
