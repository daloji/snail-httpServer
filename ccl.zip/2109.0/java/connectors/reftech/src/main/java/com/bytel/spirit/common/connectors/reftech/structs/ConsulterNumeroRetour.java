package com.bytel.spirit.common.connectors.reftech.structs;

import java.io.Serializable;
import java.time.LocalDateTime;

import com.google.gson.annotations.Expose;

/**
 * @author mbaptist
 * @version ($Revision$ $Date$)
 */
public class ConsulterNumeroRetour implements Serializable
{

  /**
   *
   */
  private static final long serialVersionUID = -8468393820765225776L;

  /**
   * numero
   */
  @Expose
  private int _statut;

  /**
   *
   */
  @Expose
  private int _propose;

  /**
   *
   */
  @Expose
  private long _ticket;

  /**
  *
  */
  @Expose
  private LocalDateTime _dateEtat;

  /**
   *
   */
  public ConsulterNumeroRetour()
  {
    // default
  }

  /**
   * Constructor
   *
   * @param statut_p
   *          Statut de la ressource
   * @param propose_p
   *          La propose
   * @param ticket_p
   *          Ticket de la ressource
   * @param dateEtat_p
   *          La dateEtat
   */
  public ConsulterNumeroRetour(int statut_p, int propose_p, long ticket_p, LocalDateTime dateEtat_p)
  {
    _statut = statut_p;
    _propose = propose_p;
    _ticket = ticket_p;
    _dateEtat = dateEtat_p;
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    ConsulterNumeroRetour other = (ConsulterNumeroRetour) obj;
    if (_dateEtat == null)
    {
      if (other._dateEtat != null)
      {
        return false;
      }
    }
    else if (!_dateEtat.equals(other._dateEtat))
    {
      return false;
    }
    if (_propose != other._propose)
    {
      return false;
    }
    if (_statut != other._statut)
    {
      return false;
    }
    if (_ticket != other._ticket)
    {
      return false;
    }
    return true;
  }

  /**
   * @return the dateEtat
   */
  public LocalDateTime getDateEtat()
  {
    return _dateEtat;
  }

  /**
   * @return _propose
   */
  public int getPropose()
  {
    return _propose;
  }

  /**
   * @return _statut
   */
  public int getStatut()
  {
    return _statut;
  }

  /**
   * @return _ticket
   */
  public long getTicket()
  {
    return _ticket;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_dateEtat == null) ? 0 : _dateEtat.hashCode());
    result = (prime * result) + _propose;
    result = (prime * result) + _statut;
    result = (prime * result) + (int) (_ticket ^ (_ticket >>> 32));
    return result;
  }

  /**
   * @param dateEtat_p
   *          the dateEtat to set
   */
  public void setDateEtat(LocalDateTime dateEtat_p)
  {
    _dateEtat = dateEtat_p;
  }

  /**
   * @param propose_p
   */
  public void setPropose(int propose_p)
  {
    this._propose = propose_p;
  }

  /**
   * @param statut_p
   */
  public void setStatut(int statut_p)
  {
    this._statut = statut_p;
  }

  /**
   * @param ticket_p
   */
  public void setTicket(long ticket_p)
  {
    this._ticket = ticket_p;
  }

  @Override
  public String toString()
  {
    return "ConsulterNumeroRetour [_statut=" + _statut + ", _propose=" + _propose + ", _ticket=" + _ticket + ", _dateEtat=" + _dateEtat + "]"; //$NON-NLS-1$//$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
  }

}
