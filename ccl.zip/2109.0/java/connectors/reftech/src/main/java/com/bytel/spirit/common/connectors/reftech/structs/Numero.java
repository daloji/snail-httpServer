/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.reftech.structs;

import static java.util.Objects.isNull;
import static org.apache.commons.lang3.StringUtils.isBlank;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Objects;

/**
 * @author mbaptist
 * @version ($Revision$ $Date$)
 */
public final class Numero implements Serializable
{
  /**
   *
   * @author jjoly
   * @version ($Revision$ $Date$)
   */
  public static final class NumeroBuilder
  {
    /**
     * object to build
     */
    Numero _toBuild;

    /**
     *
     */
    public NumeroBuilder()
    {
      _toBuild = new Numero();
    }

    /**
     * build
     *
     * @return return activity
     */
    public Numero build()
    {
      // Check MANDATORY parameters and build
      if (isBlank(_toBuild.getNumero()) || //
          (isNull(_toBuild.getTypeNumero()) && !TypeNumero.FIXE.equals(_toBuild.getTypeNumero())) || //
          isNull(_toBuild.getEtat()) || //
          isNull(_toBuild.getDateEtat()))
      {
        // TODO _toBuild.setRetour(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, Messages.getString("InvalidParam"))); //$NON-NLS-1$
      }

      return _toBuild;
    }

    /**
     * @param dateEtat_p
     *          date of statut
     * @return an instance of {@link NumeroBuilder}
     */
    public NumeroBuilder dateEtat(final LocalDateTime dateEtat_p)
    {
      _toBuild.setDateEtat(dateEtat_p);
      return this;
    }

    /**
     * @param dateFinReservation_p
     *          the dateFinReservation.
     * @return an instance of {@link NumeroBuilder}
     */
    public NumeroBuilder dateFinReservation(final LocalDateTime dateFinReservation_p)
    {
      _toBuild.setDateFinReservation(dateFinReservation_p);
      return this;
    }

    /**
     * @param etat_p
     *          Ressource statut
     * @return an instance of {@link NumeroBuilder}
     *
     */
    public NumeroBuilder etat(final String etat_p)
    {
      _toBuild.setEtat(etat_p);
      return this;
    }

    /**
     * @param idStLienAllocation_p
     *          Commercial ST link id
     * @return an instance of {@link NumeroBuilder}
     */
    public NumeroBuilder idStLienAllocation(final String idStLienAllocation_p)
    {
      _toBuild.setIdStLienAllocation(idStLienAllocation_p);
      return this;
    }

    /**
     * @param numero_p
     *          number
     * @return an instance of {@link NumeroBuilder}
     */
    public NumeroBuilder numero(final String numero_p)
    {
      _toBuild.setNumero(numero_p);
      return this;
    }

    /**
     * @param ticket_p
     *          Ticket id for proposition / reservation
     * @return an instance of {@link NumeroBuilder}
     */
    public NumeroBuilder ticket(final String ticket_p)
    {
      _toBuild.setTicket(ticket_p);
      return this;
    }

    /**
     * @param typeNumero_p
     *          Type of number
     * @return an instance of {@link NumeroBuilder}
     */
    public NumeroBuilder typeNumero(final String typeNumero_p)
    {
      _toBuild.setTypeNumero(typeNumero_p);
      return this;
    }

    /**
     * @param typePortabilite_p
     *          the typePortabilite.
     * @return an instance of {@link NumeroBuilder}
     */
    public NumeroBuilder typePortabilite(final String typePortabilite_p)
    {
      _toBuild.setTypePortabilite(typePortabilite_p);
      return this;
    }
  }

  /**
   *
   */
  private static final long serialVersionUID = 6293556155742427837L;
  /**
   * Numéro
   */
  private String _numero;

  /**
   * Type du numéro
   */
  private String _typeNumero;

  /**
   * Etat de la Ressource
   */
  private String _etat;

  /**
   * Date de dernière modification du numéro dans les référentiels du ST OSS FAI
   */
  private LocalDateTime _dateEtat;

  /**
   * Identifiant du ticket de proposition / réservation. <br />
   * Normallement uniquement applicable pour les etats PROPOSE et RESERVE <br />
   * Mais il est susceptible d'être présent pour les autres états. <br />
   */
  private String _ticket;

  /**
   * Identifiant du ST Lien d'Allocation Commercial si l'allocation du numéro a été initié par SPIRIT
   */
  private String _idStLienAllocation;

  /**
   * Date de la fin de reservation d’un numero à l’état réservé, si le numero n’est pas au statut 3 elle sera NULL.
   */
  private LocalDateTime _dateFinReservation;

  /**
   * Type of portability.
   */
  private String _typePortabilite;

  /**
   * Recopy constructor
   *
   * @param object_p
   *          The object {@Code Numero} to recopy
   */
  public Numero(final Numero object_p)
  {
    super();

    _numero = object_p.getNumero();
    _typeNumero = object_p.getTypeNumero();
    _etat = object_p.getEtat();
    _dateEtat = object_p.getDateEtat();
    _ticket = object_p.getTicket();
    _idStLienAllocation = object_p.getIdStLienAllocation();
    _dateFinReservation = object_p.getDateFinReservation();
    _typePortabilite = object_p.getTypePortabilite();
  }

  /**
   * Default constructor
   */
  Numero()
  {
    super();

    // Nothing to do
  }

  @Override
  public boolean equals(Object object_p)
  {
    if (this == object_p)
    {
      return true;
    }

    if (isNull(object_p) || //
        (getClass() != object_p.getClass()))
    {
      return false;
    }

    final Numero numero = Numero.class.cast(object_p);
    return Objects.equals(_numero, numero.getNumero()) && //
        Objects.equals(_typeNumero, numero.getTypeNumero()) && //
        Objects.equals(_etat, numero.getEtat()) && //
        Objects.equals(_dateEtat, numero.getDateEtat()) && //
        Objects.equals(_ticket, numero.getTicket()) && //
        Objects.equals(_idStLienAllocation, numero.getIdStLienAllocation()) && //
        Objects.equals(_dateFinReservation, numero.getDateFinReservation()) && //
        Objects.equals(_typePortabilite, numero.getTypePortabilite());
  }

  /**
   * @return the dateEtat
   */
  public final LocalDateTime getDateEtat()
  {
    return _dateEtat;
  }

  /**
   * @return value of _dateFinReservation
   */
  public LocalDateTime getDateFinReservation()
  {
    return _dateFinReservation;
  }

  /**
   * @return the etat
   */
  public final String getEtat()
  {
    return _etat;
  }

  /**
   * @return the idStLienAllocation
   */
  public final String getIdStLienAllocation()
  {
    return _idStLienAllocation;
  }

  /**
   * @return the numero
   */
  public final String getNumero()
  {
    return _numero;
  }

  /**
   * @return the ticket
   */
  public final String getTicket()
  {
    return _ticket;
  }

  /**
   * @return the typeNumero
   */
  public final String getTypeNumero()
  {
    return _typeNumero;
  }

  /**
   * @return value of _typePortabilite
   */
  public String getTypePortabilite()
  {
    return _typePortabilite;
  }

  @Override
  public int hashCode()
  {
    return Objects.hash(_numero, _typeNumero, _etat, _dateEtat, _ticket, _idStLienAllocation, _dateFinReservation, _typePortabilite);
  }

  /**
   * @param dateEtat_p
   *          the dateEtat to set
   */
  public void setDateEtat(final LocalDateTime dateEtat_p)
  {
    _dateEtat = dateEtat_p;
  }

  /**
   * @param dateFinReservation_p
   *          The _dateFinReservation to set.
   */
  public void setDateFinReservation(LocalDateTime dateFinReservation_p)
  {
    _dateFinReservation = dateFinReservation_p;
  }

  /**
   * @param etat_p
   *          the etat to set
   */
  public void setEtat(final String etat_p)
  {
    _etat = etat_p;
  }

  /**
   * @param idStLienAllocation_p
   *          the idStLienAllocation to set
   */
  public final void setIdStLienAllocation(final String idStLienAllocation_p)
  {
    _idStLienAllocation = idStLienAllocation_p;
  }

  /**
   * @param numero_p
   *          the numero to set
   */
  public void setNumero(final String numero_p)
  {
    _numero = numero_p;
  }

  /**
   * @param ticket_p
   *          the ticket to set
   */
  public void setTicket(final String ticket_p)
  {
    _ticket = ticket_p;
  }

  /**
   * @param typeNumero_p
   *          the typeNumero to set
   */
  public void setTypeNumero(final String typeNumero_p)
  {
    _typeNumero = typeNumero_p;
  }

  /**
   * @param typePortabilite_p
   *          The _typePortabilite to set.
   */
  public void setTypePortabilite(String typePortabilite_p)
  {
    _typePortabilite = typePortabilite_p;
  }

  @Override
  public String toString()
  {
    return "Numero [_numero=" //$NON-NLS-1$
        + _numero + ", _typeNumero=" //$NON-NLS-1$
        + _typeNumero + ", _etat=" //$NON-NLS-1$
        + _etat + ", _dateEtat=" //$NON-NLS-1$
        + _dateEtat + ", _ticket=" //$NON-NLS-1$
        + _ticket + ", _idStLienAllocation=" //$NON-NLS-1$
        + _idStLienAllocation + ", _dateFinReservation=" //$NON-NLS-1$
        + _dateFinReservation + ", _typePortabilite=" //$NON-NLS-1$
        + _typePortabilite + "]"; //$NON-NLS-1$
  }
}
