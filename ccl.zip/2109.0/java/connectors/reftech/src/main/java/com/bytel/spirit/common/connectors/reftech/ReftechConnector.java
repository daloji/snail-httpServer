/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.reftech;

import static java.util.Objects.isNull;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.text.MessageFormat;
import java.util.HashMap;
import java.util.Map;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionTools;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.utils.DateTimeTools;
import com.bytel.ravel.common.utils.Pair;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.services.conf.connector.generated.Connector;
import com.bytel.ravel.services.connector.AbstractDBConnector;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.connectors.reftech.structs.ConsulterNumeroRetour;
import com.bytel.spirit.common.connectors.reftech.structs.Numero;
import com.bytel.spirit.common.connectors.reftech.structs.Numero.NumeroBuilder;
import com.bytel.spirit.common.connectors.reftech.structs.ReftechRetour;
import com.bytel.spirit.common.connectors.reftech.structs.RessourceAdressEmail;
import com.bytel.spirit.common.connectors.reftech.structs.ServiceTechniquePpp;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

/**
 * @author jpais
 * @version ($Revision$ $Date$)
 */
public class ReftechConnector extends AbstractDBConnector implements IReftechConnector
{
  /**
   * Defines all mandatory parameters read from config file.
   *
   * @author jpais
   * @version ($Revision$ $Date$)
   */
  protected enum ParameterName
  {
    /** The URL parameter */
    DB_CONNECTIONSTRING,
    /** The LOGIN parameter */
    DB_USERNAME,
    /** The PASSWORD parameter */
    DB_PASSWORD,
    /** The POOLSIZE parameter */
    POOLSIZE,
    /** Connect timeout in sec */
    CONNECT_TIMEOUT_SEC,
    /** read timeout in sec */
    READ_TIMEOUT_SEC,
    /** query timeout in sec */
    QUERY_TIMEOUT_SEC
  }

  /** The constant for MESSAGE_MISSING_CONFIGURATION_PARAMETER */
  private static final String MESSAGE_MISSING_CONFIGURATION_PARAMETER = Messages.getString("ReftechConnector.MissingConfigurationParameter"); //$NON-NLS-1$
  /** The constant for MESSAGE_INVALID_CONFIGURATION_PARAMETER */
  private static final String MESSAGE_INVALID_CONFIGURATION_PARAMETER = Messages.getString("ReftechConnector.InvalidConfigurationParameter"); //$NON-NLS-1$

  /** datasource connection properties */
  private final static String CONNECTION_PROPERTIES = "oracle.net.CONNECT_TIMEOUT=%d;oracle.jdbc.ReadTimeout=%d"; //$NON-NLS-1$

  /** The constant for PKG_SPIRIT_RESERVE_ADRESSE_MAIL_SECONDAIRE */
  protected static final String PKG_SPIRIT_RESERVE_ADRESSE_MAIL_SECONDAIRE = "{call PKG_SPIRIT.reserveAdresseMailSecondaire (?,?,?)}"; //$NON-NLS-1$
  /** The constant for PKG_SPIRIT_MODIFIER_STATUT_ADRESS_MAIL */
  protected static final String PKG_SPIRIT_MODIFIER_STATUT_ADRESS_MAIL = "{call PKG_SPIRIT.modifierStatutAdresseMail (?,?,?,?,?)}"; //$NON-NLS-1$
  /** The constant for PKG_SPIRIT_MODIFIER_STATUT_NO_TELEPHONE */
  protected static final String PKG_SPIRIT_MODIFIER_STATUT_NO_TELEPHONE = "{call PKG_SPIRIT.modifierStatutNoTelephone (?,?,?,?,?)}"; //$NON-NLS-1$
  /** The constant for PKG_SPIRIT_LIRE_RESSOURCE_NO_TELEPHONE */
  protected static final String PKG_SPIRIT_LIRE_RESSOURCE_NO_TELEPHONE = "{call PKG_SPIRIT.lireRessourceNoTelephone (?,?,?,?,?)}"; //$NON-NLS-1$
  /** The constant for PKG_SPIRIT_LIRE_RESSOURCE_NO_TELEPHONE_V2 */
  protected static final String PKG_SPIRIT_LIRE_RESSOURCE_NO_TELEPHONE_V2 = "{call PKG_SPIRIT.lireRessourceNoTelephoneV2 (?,?,?,?,?,?,?,?,?,?)}"; //$NON-NLS-1$
  /** The constant for PKG_SPIRIT_RECUPERER_COMPTE_MAIL_PAR_ADR_MAIL */
  protected static final String PKG_SPIRIT_RECUPERER_COMPTE_MAIL_PAR_ADR_MAIL = "{call PKG_SPIRIT.recupererCompteMailParAdrMail (?,?,?,?)}"; //$NON-NLS-1$
  /** The constant for PKG_SPIRIT_CONSULTER_NUMERO */
  protected static final String PKG_SPIRIT_CONSULTER_NUMERO = "{call PKG_SPIRIT.consulterNumero (?,?,?,?,?,?,?)}"; //$NON-NLS-1$
  /** The constant for PKG_SPIRIT_PURGE_EMAIL_GELE */
  protected static final String PKG_SPIRIT_PURGE_EMAIL_GELE = "{call PKG_SPIRIT.purgeEmailGele (?,?,?)}"; //$NON-NLS-1$
  /** The constant for PKG_SPIRIT_PURGE_EMAIL_GELE */
  protected static final String PKG_SPIRIT_MODIFIER_TYPE_PORTABILITE = "{call PKG_SPIRIT.modifierTypePortabilite (?,?,?,?,?)}"; //$NON-NLS-1$
  /** The constant for PKG_SPIRIT_DECLARER_NUMERO_PORTA_ENTRANT */
  protected static final String PKG_SPIRIT_DECLARER_NUMERO_PORTA_ENTRANT = "{call PKG_SPIRIT.declarerNumeroPortaEntrant (?,?,?,?,?)}"; //$NON-NLS-1$
  /** The constant for PKG_SPIRIT_DECLARER_NUMERO_PORTA_ENTRANT */
  protected static final String PKG_SPIRIT_LIRE_RESSOURCE_ADRESSE_EMAIL = "{call PKG_SPIRIT.lireRessourceAdresseEmail (?,?,?,?,?,?,?,?)}"; //$NON-NLS-1$
  /** The constant for PKG_SPIRIT_LIRE_SERVICE_TECHNIQUE_PPP */
  protected static final String PKG_SPIRIT_LIRE_SERVICE_TECHNIQUE_PPP = "{call PKG_SPIRIT.lireServiceTechniquePpp (?,?,?,?,?)}"; //$NON-NLS-1$
  /** The constant for PKG_SPIRIT_ACTIVER_CONF */
  protected static final String PKG_SPIRIT_ACTIVER_CONF = "{call PKG_SPIRIT.activer_conf_cnx_ftth (?,?,?,?,?,?,?,?,?,?,?,?,?,?)}"; //$NON-NLS-1$
  /** The constant for PKG_SPIRIT_ACTIVER_CONF */
  protected static final String PKG_SPIRIT_SUPPRIMER_CONF = "{call PKG_SPIRIT.supprimer_conf_cnx_ftth(?,?,?,?,?)}"; //$NON-NLS-1$
  /** Parameters read from configuration. */
  private Map<ReftechConnector.ParameterName, String> _parameters = new HashMap<>(0);

  /** Connect timeout in seconds */
  private int _connectTimeoutMilliSec;
  /** Read timeout in seconds */
  private int _readTimeoutSec;
  /** Query timeout in seconds */
  private int _queryTimeoutSec;

  @Override
  public ConnectorResponse<Retour, Nothing> activerConfConnexionFTTH(Tracabilite tracabilite_p, String identifiantCircuit_p, long srvId_p, String idSession_p, String idRaccordement_p, String adresseIpv4Surf_p, String passerelleIpv4Surf_p, String masqueSousReseauIpv4Surf_p, String adresseIpv4Partagee_p, String adresseIpv6Prefixe_p, String adresseIpv6Wan_p) throws RavelException
  {
    // lock
    _dsReadLock.lock();
    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall(PKG_SPIRIT_ACTIVER_CONF))
    {
      cs.setQueryTimeout(_queryTimeoutSec);

      // Input parameters
      cs.setString(1, identifiantCircuit_p);
      cs.setLong(2, srvId_p);
      cs.setString(3, idSession_p);
      cs.setString(4, idRaccordement_p);
      cs.setString(5, adresseIpv4Surf_p);
      cs.setString(6, passerelleIpv4Surf_p);
      cs.setString(7, masqueSousReseauIpv4Surf_p);
      cs.setString(8, adresseIpv4Partagee_p);
      cs.setString(9, adresseIpv6Prefixe_p);
      cs.setString(10, adresseIpv6Wan_p);

      // Output parameters
      cs.registerOutParameter(11, Types.VARCHAR); //resultat
      cs.registerOutParameter(12, Types.VARCHAR);//categorie
      cs.registerOutParameter(13, Types.VARCHAR);//diagnostic
      cs.registerOutParameter(14, Types.VARCHAR);//libelle
      // Execute the stored procedure
      cs.execute();

      // Get output parameters
      Retour retour = new Retour();
      retour.setResultat(cs.getString(11));
      retour.setCategorie(cs.getString(12));
      retour.setDiagnostic(cs.getString(13));
      retour.setLibelle(cs.getString(14));

      return new ConnectorResponse<Retour, Nothing>(retour, null);
    }
    catch (SQLException exception)
    {
      throw buildTechnicalException(exception, tracabilite_p, "activerConfConnexionFTTH"); //$NON-NLS-1$
    }
    finally
    {
      // unlock
      _dsReadLock.unlock();
    }

  }

  @Override
  public ConnectorResponse<ReftechRetour, ConsulterNumeroRetour> consulterNumero(Tracabilite tracabilite_p, String numero_p) throws RavelException
  {
    // lock
    _dsReadLock.lock();

    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall(PKG_SPIRIT_CONSULTER_NUMERO))
    {
      // Set timeout
      cs.setQueryTimeout(_queryTimeoutSec);

      // Input parameters
      cs.setString(1, numero_p);

      // Output parameters
      cs.registerOutParameter(2, Types.INTEGER); //statut
      cs.registerOutParameter(3, Types.INTEGER);//propose
      cs.registerOutParameter(4, Types.TIMESTAMP); //dateEtat
      cs.registerOutParameter(5, Types.INTEGER); //ticket
      cs.registerOutParameter(6, Types.INTEGER); //codeRetour
      cs.registerOutParameter(7, Types.VARCHAR); //libelleErreur

      // Execute the stored procedure
      cs.execute();

      // Get output parameters
      ConsulterNumeroRetour consulterNumeroRetour = new ConsulterNumeroRetour();
      consulterNumeroRetour.setStatut(cs.getInt(2));
      consulterNumeroRetour.setPropose(cs.getInt(3));

      Timestamp dateEtat = cs.getTimestamp(4);
      if (dateEtat != null)
      {
        consulterNumeroRetour.setDateEtat(DateTimeTools.ofEpochMilli(dateEtat.getTime()));
      }

      consulterNumeroRetour.setTicket(cs.getLong(5));

      Integer codeRetour = cs.getInt(6);
      String libelleErreur = cs.getString(7);

      return new ConnectorResponse<>(new ReftechRetour(codeRetour, libelleErreur), consulterNumeroRetour);
    }
    catch (SQLException exception)
    {
      throw buildTechnicalException(exception, tracabilite_p, "consulterNumero"); //$NON-NLS-1$
    }
    finally
    {
      // unlock
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<ReftechRetour, Nothing> declarerNumeroPortaEntrant(Tracabilite tracabilite_p, String numero_p, String typeNumero_p, String etat_p) throws RavelException
  {
    // lock
    _dsReadLock.lock();

    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall(PKG_SPIRIT_DECLARER_NUMERO_PORTA_ENTRANT))
    {
      // Set timeout
      cs.setQueryTimeout(_queryTimeoutSec);

      // Input parameters
      cs.setString(1, numero_p);
      cs.setString(2, typeNumero_p);
      cs.setString(3, etat_p);

      // Output parameters
      cs.registerOutParameter(4, Types.INTEGER);
      cs.registerOutParameter(5, Types.VARCHAR);

      // Execute the stored procedure
      cs.execute();

      // Get output parameters
      Integer codeRetour = cs.getInt(4);
      String libelleErreur = cs.getString(5);

      return new ConnectorResponse<>(new ReftechRetour(codeRetour, libelleErreur), null);
    }
    catch (SQLException exception)
    {
      throw buildTechnicalException(exception, tracabilite_p, "declarerNumeroPortaEntrant"); //$NON-NLS-1$
    }
    finally
    {
      // unlock
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<ReftechRetour, RessourceAdressEmail> lireRessourceAdresseEmail(Tracabilite tracabilite_p, String adresseMail_p) throws RavelException
  {
    // lock
    _dsReadLock.lock();

    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall(PKG_SPIRIT_LIRE_RESSOURCE_ADRESSE_EMAIL))
    {
      // Set timeout
      cs.setQueryTimeout(_queryTimeoutSec);

      // Input parameters
      cs.setString(1, adresseMail_p);

      // Output parameters
      cs.registerOutParameter(2, Types.VARCHAR); //Statut
      cs.registerOutParameter(3, Types.INTEGER); //Ticket
      cs.registerOutParameter(4, Types.TIMESTAMP); //dateEtat
      cs.registerOutParameter(5, Types.VARCHAR); //STLAC_ID
      cs.registerOutParameter(6, Types.TIMESTAMP); //DateEcheance
      cs.registerOutParameter(7, Types.INTEGER); //codeRetour
      cs.registerOutParameter(8, Types.VARCHAR); //libelleErreur

      // Execute the stored procedure
      cs.execute();

      // Get output parameters
      RessourceAdressEmail ressourceAdressEmail = new RessourceAdressEmail();
      ressourceAdressEmail.setStatut(cs.getString(2));
      ressourceAdressEmail.setTicket(cs.getInt(3));

      Timestamp dateEtat = cs.getTimestamp(4);
      if (dateEtat != null)
      {
        ressourceAdressEmail.setDateEtat(DateTimeTools.ofEpochMilli(dateEtat.getTime()));
      }

      ressourceAdressEmail.setStLacId(cs.getString(5));

      Timestamp dateEcheance = cs.getTimestamp(6);
      if (dateEcheance != null)
      {
        ressourceAdressEmail.setDateEcheance(DateTimeTools.ofEpochMilli(dateEcheance.getTime()));
      }

      Integer codeRetour = cs.getInt(7);
      String libelleErreur = cs.getString(8);

      return new ConnectorResponse<>(new ReftechRetour(codeRetour, libelleErreur), ressourceAdressEmail);
    }
    catch (SQLException exception)
    {
      throw buildTechnicalException(exception, tracabilite_p, "lireRessourceAdresseEmail"); //$NON-NLS-1$
    }
    finally
    {
      // unlock
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<ReftechRetour, Pair<String, String>> lireRessourceNoTelephone(Tracabilite tracabilite_p, String noTelephone_p) throws RavelException
  {
    // lock
    _dsReadLock.lock();

    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall(PKG_SPIRIT_LIRE_RESSOURCE_NO_TELEPHONE))
    {
      // Set timeout
      cs.setQueryTimeout(_queryTimeoutSec);

      // Input parameters
      cs.setString(1, noTelephone_p);

      // Output parameters
      cs.registerOutParameter(2, Types.VARCHAR);
      cs.registerOutParameter(3, Types.VARCHAR);
      cs.registerOutParameter(4, Types.INTEGER);
      cs.registerOutParameter(5, Types.VARCHAR);

      // Execute the stored procedure
      cs.execute();

      // Get output parameters
      Integer codeRetour = cs.getInt(4);
      String libelleErreur = cs.getString(5);
      // Pair of Statut, IdStLienAllocation
      Pair<String, String> retour = new Pair<>(cs.getString(2), cs.getString(3));

      return new ConnectorResponse<>(new ReftechRetour(codeRetour, libelleErreur), retour);
    }
    catch (SQLException exception)
    {
      throw buildTechnicalException(exception, tracabilite_p, "lireRessourceNoTelephone"); //$NON-NLS-1$
    }
    finally
    {
      // unlock
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<ReftechRetour, Numero> lireRessourceNoTelephoneV2(final Tracabilite tracabilite_p, final String noTelephone_p) throws RavelException
  {
    // lock
    _dsReadLock.lock();

    try (Connection con = _datasource.getConnection(); //
        CallableStatement cs = con.prepareCall(PKG_SPIRIT_LIRE_RESSOURCE_NO_TELEPHONE_V2))
    {
      // Set timeout
      cs.setQueryTimeout(_queryTimeoutSec);

      // Input parameters
      cs.setString(1, noTelephone_p);

      // Output parameters
      cs.registerOutParameter(2, Types.VARCHAR);
      cs.registerOutParameter(3, Types.VARCHAR);
      cs.registerOutParameter(4, Types.TIMESTAMP);
      cs.registerOutParameter(5, Types.VARCHAR);
      cs.registerOutParameter(6, Types.VARCHAR);
      cs.registerOutParameter(7, Types.TIMESTAMP);
      cs.registerOutParameter(8, Types.VARCHAR);
      cs.registerOutParameter(9, Types.INTEGER);
      cs.registerOutParameter(10, Types.VARCHAR);

      // Execute the stored procedure
      cs.execute();

      // Get output parameters
      final String statut = cs.getString(2);
      final String idStLienAllocation = cs.getString(3);
      final Timestamp dateEtat = cs.getTimestamp(4);
      final String ticket = cs.getString(5);
      final String typeNumero = cs.getString(6);
      final Timestamp dateFinReservation = cs.getTimestamp(7);
      final String typePortabilite = cs.getString(8);
      final Integer codeRetour = cs.getInt(9);
      final String libelleErreur = cs.getString(10);

      final Numero numero = new NumeroBuilder() //
          .dateEtat(isNull(dateEtat) ? null : dateEtat.toLocalDateTime()) //
          .etat(statut) //
          .idStLienAllocation(idStLienAllocation) //
          .numero(noTelephone_p) //
          .ticket(ticket) //
          .typeNumero(typeNumero) //
          .dateFinReservation(isNull(dateFinReservation) ? null : dateFinReservation.toLocalDateTime()) //
          .typePortabilite(typePortabilite) //
          .build();
      return new ConnectorResponse<>(new ReftechRetour(codeRetour, libelleErreur), numero);
    }
    catch (final SQLException exception)
    {
      throw buildTechnicalException(exception, tracabilite_p, "lireRessourceNoTelephone_V2"); //$NON-NLS-1$
    }
    finally
    {
      // unlock
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<ServiceTechniquePpp, Nothing> lireServiceTechniquePpp(final Tracabilite tracabilite_p, final String srvId_p) throws RavelException
  {
    // lock
    _dsReadLock.lock();

    try (Connection con = _datasource.getConnection(); //
        CallableStatement cs = con.prepareCall(PKG_SPIRIT_LIRE_SERVICE_TECHNIQUE_PPP))
    {
      // Set timeout
      cs.setQueryTimeout(_queryTimeoutSec);

      // Input parameters
      cs.setString(1, srvId_p);

      // Output parameters
      cs.registerOutParameter(2, Types.VARCHAR); // Statut
      cs.registerOutParameter(3, Types.VARCHAR); // Commentaire
      cs.registerOutParameter(4, Types.VARCHAR); // IdentifiantPpp
      cs.registerOutParameter(5, Types.VARCHAR); // MotDePassePpp

      // Execute the stored procedure
      cs.execute();

      // Get output parameters
      final String statut = cs.getString(2);
      final String comentaire = cs.getString(3);
      final String identifiantPpp = cs.getString(4);
      final String motDePassePpp = cs.getString(5);

      final ServiceTechniquePpp serviceTechniquePpp = new ServiceTechniquePpp(statut, comentaire, identifiantPpp, motDePassePpp);

      return new ConnectorResponse<>(serviceTechniquePpp, null);
    }
    catch (final SQLException exception)
    {
      throw buildTechnicalException(exception, tracabilite_p, "lireServiceTechniquePpp"); //$NON-NLS-1$
    }
    finally
    {
      // unlock
      _dsReadLock.unlock();
    }
  }

  @Override
  public void loadConnectorConfiguration(Connector connector_p) throws RavelException
  {
    // Read parameters.
    _name = connector_p.getName();
    _enabled = connector_p.isEnabled();

    // Get parameters
    connector_p.getParam().forEach(p -> _parameters.put(ParameterName.valueOf(p.getName().toUpperCase()), p.getValue()));

    // Check parameters

    // Get DB_CONNECTIONSTRING
    String connectionString = _parameters.get(ParameterName.DB_CONNECTIONSTRING);
    if (StringTools.isNullOrEmpty(connectionString))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, _name, ParameterName.DB_CONNECTIONSTRING.toString()));
    }

    // Get DB_USERNAME
    String dbUserName = _parameters.get(ParameterName.DB_USERNAME);
    if (StringTools.isNullOrEmpty(dbUserName))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, _name, ParameterName.DB_USERNAME.toString()));
    }

    // Get DB_PASSWORD
    String dbPassword = _parameters.get(ParameterName.DB_PASSWORD);
    if (StringTools.isNullOrEmpty(dbPassword))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, _name, ParameterName.DB_PASSWORD.toString()));
    }

    // Get POOLSIZE
    String poolSize = _parameters.get(ParameterName.POOLSIZE);

    // Get CONNECT_TIMEOUT_SEC
    String connectTimeoutSec = _parameters.get(ParameterName.CONNECT_TIMEOUT_SEC);
    if (StringTools.isNullOrEmpty(connectTimeoutSec))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, _name, ParameterName.CONNECT_TIMEOUT_SEC.toString()));
    }
    try
    {
      _connectTimeoutMilliSec = Integer.parseInt(connectTimeoutSec) * 1000;
    }
    catch (NumberFormatException e)
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00021, MessageFormat.format(MESSAGE_INVALID_CONFIGURATION_PARAMETER, _name, ParameterName.CONNECT_TIMEOUT_SEC.toString()));
    }

    // Get READ_TIMEOUT_SEC
    String readTimeoutSec = _parameters.get(ParameterName.READ_TIMEOUT_SEC);
    if (StringTools.isNullOrEmpty(readTimeoutSec))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, _name, ParameterName.READ_TIMEOUT_SEC.toString()));
    }
    try
    {
      _readTimeoutSec = Integer.parseInt(readTimeoutSec) * 1000;
    }
    catch (NumberFormatException e)
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00021, MessageFormat.format(MESSAGE_INVALID_CONFIGURATION_PARAMETER, _name, ParameterName.READ_TIMEOUT_SEC.toString()));
    }

    // Get QUERY_TIMEOUT_SEC
    String queryTimeoutSec = _parameters.get(ParameterName.QUERY_TIMEOUT_SEC);
    if (StringTools.isNullOrEmpty(queryTimeoutSec))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, _name, ParameterName.QUERY_TIMEOUT_SEC.toString()));
    }
    try
    {
      _queryTimeoutSec = Integer.parseInt(queryTimeoutSec) * 1000;
    }
    catch (NumberFormatException e)
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00021, MessageFormat.format(MESSAGE_INVALID_CONFIGURATION_PARAMETER, _name, ParameterName.QUERY_TIMEOUT_SEC.toString()));
    }

    // Create data source
    createDataSource(connectionString, dbUserName, dbPassword, poolSize, DatabaseType.ORACLE);
    _datasource.setConnectionProperties(String.format(CONNECTION_PROPERTIES, _connectTimeoutMilliSec, _readTimeoutSec));

  }

  @Override
  public ConnectorResponse<ReftechRetour, Nothing> modifierStatutAdressMail(Tracabilite tracabilite_p, String adresseMail_p, String statut_p, String idStLienAllocation_p) throws RavelException
  {
    // lock
    _dsReadLock.lock();

    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall(PKG_SPIRIT_MODIFIER_STATUT_ADRESS_MAIL))
    {
      // Set timeout
      cs.setQueryTimeout(_queryTimeoutSec);

      // Input parameters
      cs.setString(1, adresseMail_p);
      cs.setString(2, statut_p);
      cs.setString(3, idStLienAllocation_p);

      // Output parameters
      cs.registerOutParameter(4, Types.INTEGER);
      cs.registerOutParameter(5, Types.VARCHAR);

      // Execute the stored procedure
      cs.execute();

      // Get output parameters
      Integer codeRetour = cs.getInt(4);
      String libelleErreur = cs.getString(5);

      return new ConnectorResponse<>(new ReftechRetour(codeRetour, libelleErreur), null);
    }
    catch (SQLException exception)
    {
      throw buildTechnicalException(exception, tracabilite_p, "modifierStatutAdressMail"); //$NON-NLS-1$
    }
    finally
    {
      // unlock
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<ReftechRetour, Nothing> modifierStatutNoTelephone(Tracabilite tracabilite_p, String noTelephone_p, String statut_p, String idStLienAllocation_p) throws RavelException
  {
    // lock
    _dsReadLock.lock();

    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall(PKG_SPIRIT_MODIFIER_STATUT_NO_TELEPHONE))
    {
      // Set timeout
      cs.setQueryTimeout(_queryTimeoutSec);

      // Input parameters
      cs.setString(1, noTelephone_p);
      cs.setString(2, statut_p);
      cs.setString(3, idStLienAllocation_p);

      // Output parameters
      cs.registerOutParameter(4, Types.INTEGER);
      cs.registerOutParameter(5, Types.VARCHAR);

      // Execute the stored procedure
      cs.execute();

      // Get output parameters
      Integer codeRetour = cs.getInt(4);
      String libelleErreur = cs.getString(5);

      return new ConnectorResponse<>(new ReftechRetour(codeRetour, libelleErreur), null);
    }
    catch (SQLException exception)
    {
      throw buildTechnicalException(exception, tracabilite_p, "modifierStatutNoTelephone"); //$NON-NLS-1$
    }
    finally
    {
      // unlock
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<ReftechRetour, Nothing> modifierTypePortabilite(Tracabilite tracabilite_p, String numero_p, String typeNumero_p, String typePortabilite_p) throws RavelException
  {
    // lock
    _dsReadLock.lock();

    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall(PKG_SPIRIT_MODIFIER_TYPE_PORTABILITE))
    {
      // Set timeout
      cs.setQueryTimeout(_queryTimeoutSec);

      // Input parameters
      cs.setString(1, numero_p);
      cs.setString(2, typeNumero_p);
      cs.setString(3, typePortabilite_p);

      // Output parameters
      cs.registerOutParameter(4, Types.INTEGER);
      cs.registerOutParameter(5, Types.VARCHAR);

      // Execute the stored procedure
      cs.execute();

      // Get output parameters
      Integer codeRetour = cs.getInt(4);
      String libelleErreur = cs.getString(5);

      return new ConnectorResponse<>(new ReftechRetour(codeRetour, libelleErreur), null);
    }
    catch (SQLException exception)
    {
      throw buildTechnicalException(exception, tracabilite_p, "modifierTypePortabilite"); //$NON-NLS-1$
    }
    finally
    {
      // unlock
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<ReftechRetour, Nothing> purgeEmailGele(Tracabilite tracabilite_p, String adresseMail_p) throws RavelException
  {
    // lock
    _dsReadLock.lock();

    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall(PKG_SPIRIT_PURGE_EMAIL_GELE))
    {
      // Set timeout
      cs.setQueryTimeout(_queryTimeoutSec);

      // Input parameters
      cs.setString(1, adresseMail_p);

      // Output parameters
      cs.registerOutParameter(2, Types.INTEGER);
      cs.registerOutParameter(3, Types.VARCHAR);

      // Execute the stored procedure
      cs.execute();

      // Get output parameters
      Integer codeRetour = cs.getInt(2);
      String libelleErreur = cs.getString(3);

      return new ConnectorResponse<>(new ReftechRetour(codeRetour, libelleErreur), null);
    }
    catch (SQLException exception)
    {
      throw buildTechnicalException(exception, tracabilite_p, "PurgeEmailGele"); //$NON-NLS-1$
    }
    finally
    {
      // unlock
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<ReftechRetour, Integer> recupererCompteMailParAdrMail(Tracabilite tracabilite_p, String adresseMail_p) throws RavelException
  {
    // lock
    _dsReadLock.lock();

    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall(PKG_SPIRIT_RECUPERER_COMPTE_MAIL_PAR_ADR_MAIL))
    {
      // Set timeout
      cs.setQueryTimeout(_queryTimeoutSec);

      // Input parameters
      cs.setString(1, adresseMail_p);

      // Output parameters
      cs.registerOutParameter(2, Types.INTEGER);
      cs.registerOutParameter(3, Types.INTEGER);
      cs.registerOutParameter(4, Types.VARCHAR);

      // Execute the stored procedure
      cs.execute();

      // Get output parameters
      Integer idCompteMail = cs.getInt(2);
      Integer codeRetour = cs.getInt(3);
      String libelleErreur = cs.getString(4);

      return new ConnectorResponse<>(new ReftechRetour(codeRetour, libelleErreur), idCompteMail);
    }
    catch (SQLException exception)
    {
      throw buildTechnicalException(exception, tracabilite_p, "recupererCompteMailParAdrMail"); //$NON-NLS-1$
    }
    finally
    {
      // unlock
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<ReftechRetour, Nothing> reserveAdresseMailSecondaire(Tracabilite tracabilite_p, String adresseMail_p) throws RavelException
  {
    // lock
    _dsReadLock.lock();

    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall(PKG_SPIRIT_RESERVE_ADRESSE_MAIL_SECONDAIRE))
    {
      // Set timeout
      cs.setQueryTimeout(_queryTimeoutSec);

      // Input parameters
      cs.setString(1, adresseMail_p);

      // Output parameters
      cs.registerOutParameter(2, Types.INTEGER);
      cs.registerOutParameter(3, Types.VARCHAR);

      // Execute the stored procedure
      cs.execute();

      // Get output parameters
      Integer codeRetour = cs.getInt(2);
      String libelleErreur = cs.getString(3);

      return new ConnectorResponse<>(new ReftechRetour(codeRetour, libelleErreur), null);
    }
    catch (SQLException exception)
    {
      throw buildTechnicalException(exception, tracabilite_p, "reserveAdresseMailSecondaire"); //$NON-NLS-1$
    }
    finally
    {
      // unlock
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<Retour, Nothing> supprimerConfConnexionFTTH(Tracabilite tracabilite_p, String identifiantCircuit_p) throws RavelException
  {
    // lock
    _dsReadLock.lock();
    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall(PKG_SPIRIT_SUPPRIMER_CONF))
    {
      cs.setQueryTimeout(_queryTimeoutSec);

      // Input parameters
      cs.setString(1, identifiantCircuit_p);

      // Output parameters
      // Output parameters
      cs.registerOutParameter(2, Types.VARCHAR); //resultat
      cs.registerOutParameter(3, Types.VARCHAR);//categorie
      cs.registerOutParameter(4, Types.VARCHAR);//diagnostic
      cs.registerOutParameter(5, Types.VARCHAR);//libelle
      // Execute the stored procedure
      cs.execute();

      // Get output parameters
      Retour retour = new Retour();
      retour.setResultat(cs.getString(2));
      retour.setCategorie(cs.getString(3));
      retour.setDiagnostic(cs.getString(4));
      retour.setLibelle(cs.getString(5));

      return new ConnectorResponse<Retour, Nothing>(retour, null);
    }
    catch (SQLException exception)
    {
      throw buildTechnicalException(exception, tracabilite_p, "supprimerConfConnexionFTTH"); //$NON-NLS-1$
    }
    finally
    {
      // unlock
      _dsReadLock.unlock();
    }

  }

  /**
   * Build a log entry and throws an {@link RavelException} for a technical problem.
   *
   * @param exc_p
   *          The {@link Exception} raised
   * @param tracabilite_p
   *          The traçabilite
   * @param method_p
   *          The method name in which the fault was raised.
   * @return RavelException The technical exception.
   */
  private RavelException buildTechnicalException(Exception exc_p, Tracabilite tracabilite_p, String method_p)
  {
    String message = MessageFormat.format(Messages.getString("ReftechConnector.TechnicalExceptionMessage"), //$NON-NLS-1$
        method_p, exc_p.getClass().getSimpleName(), exc_p.getMessage());
    // add fileName and line number of the exception
    message += ExceptionTools.getExceptionLineAndFile(exc_p);
    RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, message));
    return new RavelException(ExceptionType.DATABASE_ERROR, ErrorCode.CNCTOR_00010, message, IReftechConnector.BEAN_ID, exc_p);
  }
}
