/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.reftech;

import com.bytel.ravel.services.connector.IConnector;

/**
 * Interface of IREXConnector that defines the BEAN_ID
 * 
 * @author jpais
 * @version ($Revision$ $Date$)
 */
public interface IReftechConnector extends IReftech, IConnector
{
  /**
   * The id to retrieve the connector.
   */
  public String BEAN_ID = "ReftechConnector"; //$NON-NLS-1$
}
