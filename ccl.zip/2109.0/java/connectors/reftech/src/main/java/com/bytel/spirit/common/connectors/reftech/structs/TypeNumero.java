/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.reftech.structs;

/**
 * @author mbaptist
 * @version ($Revision$ $Date$)
 */
public final class TypeNumero
{
  /**
   * FIXE
   */
  public static final String FIXE = "FIXE"; //$NON-NLS-1$

  /**
   * VOIX
   */
  public static final String VOIX = "VOIX"; //$NON-NLS-1$

  /**
   * FAX
   */
  public static final String FAX = "FAX"; //$NON-NLS-1$

  /**
   *
   */
  private TypeNumero()
  {
    // do nothing
  }
}
