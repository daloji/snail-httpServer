/*******************************************************************************
* $Id: AideCommandeFTELConnectorTest.java 50618 2021-04-14 09:51:39Z mlebihan $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connector.oi.aidecommande;

import static java.util.Objects.nonNull;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.ws.rs.core.MultivaluedHashMap;
import javax.ws.rs.core.MultivaluedMap;

import org.easymock.EasyMock;
import org.easymock.IArgumentMatcher;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.bytel.ravel.common.traceability.AbstractTraceability;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.connector.oi.CodeRetour;
import com.bytel.spirit.common.connector.oi.OIConnectorTestHelper;
import com.bytel.spirit.common.connector.oi.aidecommande.structs.structureverticale.StructureReponse;
import com.bytel.spirit.common.connector.oi.aidecommande.structs.structureverticale.batiment.Batiment;
import com.bytel.spirit.common.connector.oi.aidecommande.structs.structureverticale.escalier.Escalier;
import com.bytel.spirit.common.connector.oi.aidecommande.structs.structureverticale.pm.Brassage;
import com.bytel.spirit.common.connector.oi.aidecommande.structs.structureverticale.pm.EmplacementPm;
import com.bytel.spirit.common.generated.configfluxOI.ConfigFluxOI;
import com.bytel.spirit.common.generated.ws.ftth.aidecommande.ftel.BatimentType;
import com.bytel.spirit.common.generated.ws.ftth.aidecommande.ftel.EscalierType;
import com.bytel.spirit.common.generated.ws.ftth.aidecommande.ftel.EtageType;
import com.bytel.spirit.common.generated.ws.ftth.aidecommande.ftel.ObtentionStructureAdresseDemandeSoap;
import com.bytel.spirit.common.generated.ws.ftth.aidecommande.ftel.ObtentionStructureAdresseReponseSoap;

/**
 *
 * @author jstrub
 * @version ($Revision: 50618 $ $Date: 2021-04-14 11:51:39 +0200 (mer. 14 avril 2021) $)
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({ AideCommandeFTELConnector.class })
@PowerMockIgnore({ "com.sun.*", "org.w3c.*", "javax.xml.*" })
public class AideCommandeFTELConnectorTest extends AbstractAideCommandeConnectorTest
{

  /**
   *
   * @author jstrub
   * @version ($Revision: 50618 $ $Date: 2021-04-14 11:51:39 +0200 (mer. 14 avril 2021) $)
   */
  private final static class RequestMatcher implements IArgumentMatcher
  {
    /** */
    private ConfigFluxOI _config;
    /** */
    private String _hexacle = null;
    /** */
    private String _imb = null;
    /** */
    private String _referencePTO = null;
    /** */
    private String _codeInsee = null;
    /** */
    private String _codeRivoli = null;
    /** */
    private Integer _numeroVoie = null;
    /** */
    private String _complementVoie = null;

    /**
     * @param config_p
     *          config
     * @param type_p
     *          hexacle || IMB || referencePTO
     *
     * @param i_p
     *          int
     */
    public RequestMatcher(ConfigFluxOI config_p, String type_p, int i_p)
    {
      _config = config_p;
      if (i_p == 1)
      {
        _hexacle = type_p;
      }
      else if (i_p == 2)
      {
        _imb = type_p;
      }
      else if (i_p == 3)
      {
        _referencePTO = type_p;
      }
    }

    /**
     * @param config_p
     *          config
     * @param codeInsee_p
     *          code INSEE
     * @param codeRivoli_p
     *          code RIVOLI
     * @param numeroVoie_p
     *          numero voie
     * @param complementVoie_p
     *          complement voie
     */
    public RequestMatcher(ConfigFluxOI config_p, String codeInsee_p, String codeRivoli_p, Integer numeroVoie_p, String complementVoie_p)
    {
      _config = config_p;
      _codeInsee = codeInsee_p;
      _codeRivoli = codeRivoli_p;
      _numeroVoie = numeroVoie_p;
      _complementVoie = complementVoie_p;
    }

    @Override
    public void appendTo(StringBuffer buffer_p)
    {
      // Nothing to do
    }

    @Override
    public boolean matches(Object argument_p)
    {
      if (!ObtentionStructureAdresseDemandeSoap.class.isInstance(argument_p))
      {
        return false;
      }

      ObtentionStructureAdresseDemandeSoap request = (ObtentionStructureAdresseDemandeSoap) argument_p;
      Assert.assertEquals(_config.getConnexionTechnique().getIdentite().getNom(), request.getEntete().getOperateurCommercial().getNom());
      Assert.assertEquals(_config.getConnexionTechnique().getIdentite().getIdentifiant(), request.getEntete().getOperateurCommercial().getIdentifiant());
      Assert.assertEquals(_config.getConnexionTechnique().getWsdl().getVersion(), request.getEntete().getVersionWS());
      Assert.assertNotNull(request.getEntete().getHorodatageRequete());

      if (_hexacle != null)
      {
        Assert.assertEquals(_hexacle, request.getReferenceAdresse().getReferenceHexacle());
      }
      else if (_imb != null)
      {
        Assert.assertEquals(_imb, request.getReferenceAdresse().getIdentifiantImmeuble());
      }
      else if (_referencePTO != null)
      {
        Assert.assertEquals(_referencePTO, request.getReferenceAdresse().getReferencePTO());
      }
      else
      {
        Assert.assertEquals(_codeInsee, request.getReferenceAdresse().getReferenceRivoli().getCodeInsee());
        Assert.assertEquals(_codeRivoli, request.getReferenceAdresse().getReferenceRivoli().getCodeRivoli());
        Assert.assertEquals(_numeroVoie.intValue(), request.getReferenceAdresse().getReferenceRivoli().getNumeroVoie().intValue());
        Assert.assertEquals(_complementVoie, request.getReferenceAdresse().getReferenceRivoli().getComplementNumeroVoie());
      }

      return true;
    }
  }

  /**
   * @param config_p
   *          config
   * @param string_p
   *          hexacle || IMB || referencePTO
   * @param i_p
   *          int
   * @return null
   */
  public static ObtentionStructureAdresseDemandeSoap eqRequest(ConfigFluxOI config_p, String string_p, int i_p)
  {
    EasyMock.reportMatcher(new RequestMatcher(config_p, string_p, i_p));
    return null;
  }

  /**
   * @param config_p
   *          config
   * @param codeInsee_p
   *          code INSEE
   * @param codeRivoli_p
   *          code RIVOLI
   * @param numeroVoie_p
   *          numero voie
   * @param complementVoie_p
   *          complement voie
   * @return null
   */
  public static ObtentionStructureAdresseDemandeSoap eqRequest(ConfigFluxOI config_p, String codeInsee_p, String codeRivoli_p, Integer numeroVoie_p, String complementVoie_p)
  {
    EasyMock.reportMatcher(new RequestMatcher(config_p, codeInsee_p, codeRivoli_p, numeroVoie_p, complementVoie_p));
    return null;
  }

  @Test
  @Override
  public void testLoadConfiguration() throws Exception
  {
    AideCommandeFTELConnector connector = new AideCommandeFTELConnector();
    OIConnectorTestHelper.initConnector(connector);
    Assert.assertTrue(connector.isEnabled());
  }

  @Test
  @Override
  public void testMappingsWithHexacle() throws Exception
  {
    // Create random beans
    ConfigFluxOI mockConfig = _podam.manufacturePojo(ConfigFluxOI.class);
    String hexacle = _podam.manufacturePojo(String.class);
    ObtentionStructureAdresseReponseSoap mockResp = _podam.manufacturePojo(ObtentionStructureAdresseReponseSoap.class);

    // configure mock
    AideCommandeFTELConnector connector = PowerMock.createNicePartialMock(AideCommandeFTELConnector.class, PRIVATE_MOCKED_METHOD);

    PowerMock.expectPrivate(connector, PRIVATE_MOCKED_METHOD, //expected method
        new Class[] { AbstractTraceability.class, Boolean.TYPE, Boolean.TYPE, String.class, String.class, String.class, List.class, MultivaluedMap.class, Map.class, Object[].class }, //parameter types
        EasyMock.anyObject(AbstractTraceability.class), EasyMock.anyBoolean(), EasyMock.anyBoolean(), EasyMock.eq(SOAP_METHOD), EasyMock.eq(null), EasyMock.eq(null), EasyMock.eq(null), EasyMock.eq(createHeaders()), EasyMock.eq(null), eqRequest(mockConfig, hexacle, 1)).andReturn(mockResp);

    // Execute test
    PowerMock.replayAll();
    ConnectorResponse<StructureReponse, CodeRetour> result = connector.obtenirStructureVerticaleByHexacle(_tracabilite, mockConfig, hexacle, createHeaders());
    PowerMock.verifyAll();

    checkResponseMapping(mockResp, result);
  }

  @Test
  @Override
  public void testMappingsWithIMB() throws Exception
  {
    // Create random beans
    ConfigFluxOI mockConfig = _podam.manufacturePojo(ConfigFluxOI.class);
    String imb = _podam.manufacturePojo(String.class);
    ObtentionStructureAdresseReponseSoap mockResp = _podam.manufacturePojo(ObtentionStructureAdresseReponseSoap.class);

    // configure mock
    AideCommandeFTELConnector connector = PowerMock.createNicePartialMock(AideCommandeFTELConnector.class, PRIVATE_MOCKED_METHOD);

    PowerMock.expectPrivate(connector, PRIVATE_MOCKED_METHOD, //expected method
        new Class[] { AbstractTraceability.class, Boolean.TYPE, Boolean.TYPE, String.class, String.class, String.class, List.class, MultivaluedMap.class, Map.class, Object[].class }, //parameter types
        EasyMock.anyObject(AbstractTraceability.class), EasyMock.anyBoolean(), EasyMock.anyBoolean(), EasyMock.eq(SOAP_METHOD), EasyMock.eq(null), EasyMock.eq(null), EasyMock.eq(null), EasyMock.eq(createHeaders()), EasyMock.eq(null), eqRequest(mockConfig, imb, 2)).andReturn(mockResp);

    // Execute test
    PowerMock.replayAll();
    ConnectorResponse<StructureReponse, CodeRetour> result = connector.obtenirStructureVerticaleByIMB(_tracabilite, mockConfig, imb, createHeaders());
    PowerMock.verifyAll();

    checkResponseMapping(mockResp, result);
  }

  @Test
  @Override
  public void testMappingsWithPTO() throws Exception
  {
    // Create random beans
    ConfigFluxOI mockConfig = _podam.manufacturePojo(ConfigFluxOI.class);
    String referencePTO = _podam.manufacturePojo(String.class);
    ObtentionStructureAdresseReponseSoap mockResp = _podam.manufacturePojo(ObtentionStructureAdresseReponseSoap.class);

    // configure mock
    AideCommandeFTELConnector connector = PowerMock.createNicePartialMock(AideCommandeFTELConnector.class, PRIVATE_MOCKED_METHOD);

    PowerMock.expectPrivate(connector, PRIVATE_MOCKED_METHOD, //expected method
        new Class[] { AbstractTraceability.class, Boolean.TYPE, Boolean.TYPE, String.class, String.class, String.class, List.class, MultivaluedMap.class, Map.class, Object[].class }, //parameter types
        EasyMock.anyObject(AbstractTraceability.class), EasyMock.anyBoolean(), EasyMock.anyBoolean(), EasyMock.eq(SOAP_METHOD), EasyMock.eq(null), EasyMock.eq(null), EasyMock.eq(null), EasyMock.eq(createHeaders()), EasyMock.eq(null), eqRequest(mockConfig, referencePTO, 3)).andReturn(mockResp);

    // Execute test
    PowerMock.replayAll();
    ConnectorResponse<StructureReponse, CodeRetour> result = connector.obtenirStructureVerticaleByPTO(_tracabilite, mockConfig, referencePTO, createHeaders());
    PowerMock.verifyAll();

    checkResponseMapping(mockResp, result);
  }

  @Test
  @Override
  public void testMappingsWithPTODefaultPmValues() throws Exception
  {
    // Create random beans
    ConfigFluxOI mockConfig = _podam.manufacturePojo(ConfigFluxOI.class);
    String referencePTO = _podam.manufacturePojo(String.class);
    ObtentionStructureAdresseReponseSoap mockResp = _podam.manufacturePojo(ObtentionStructureAdresseReponseSoap.class);

    mockResp.getStructureDetaillee().getBatiments().get(0).getEscaliers().get(0).getEtages().get(0).getPm().setResponsableBrassage(null);
    mockResp.getStructureDetaillee().getBatiments().get(0).getEscaliers().get(0).getEtages().get(0).getPm().setTypeEmplacementPM(null);

    // configure mock
    AideCommandeFTELConnector connector = PowerMock.createNicePartialMock(AideCommandeFTELConnector.class, PRIVATE_MOCKED_METHOD);

    PowerMock.expectPrivate(connector, PRIVATE_MOCKED_METHOD, //expected method
        new Class[] { AbstractTraceability.class, Boolean.TYPE, Boolean.TYPE, String.class, String.class, String.class, List.class, MultivaluedMap.class, Map.class, Object[].class }, //parameter types
        EasyMock.anyObject(AbstractTraceability.class), EasyMock.anyBoolean(), EasyMock.anyBoolean(), EasyMock.eq(SOAP_METHOD), EasyMock.eq(null), EasyMock.eq(null), EasyMock.eq(null), EasyMock.eq(createHeaders()), EasyMock.eq(null), eqRequest(mockConfig, referencePTO, 3)).andReturn(mockResp);

    // Execute test
    PowerMock.replayAll();
    ConnectorResponse<StructureReponse, CodeRetour> result = connector.obtenirStructureVerticaleByPTO(_tracabilite, mockConfig, referencePTO, createHeaders());
    PowerMock.verifyAll();

    checkResponseMapping(mockResp, result);

    // Assert default values for EmplacementPm and Brassage were set in PM
    Assert.assertEquals(EmplacementPm.PME, result._first.getBatiments().get(0).getEscaliers().get(0).getEtages().get(0).getPm().getTypeEmplacementPM());
    Assert.assertEquals(Brassage.OI, result._first.getBatiments().get(0).getEscaliers().get(0).getEtages().get(0).getPm().getResponsableBrassage());
  }

  @Test
  @Override
  public void testMappingsWithQuadruplet() throws Exception
  {
    // Create random beans
    ConfigFluxOI mockConfig = _podam.manufacturePojo(ConfigFluxOI.class);
    String codeInsee = _podam.manufacturePojo(String.class);
    String codeRivoli = _podam.manufacturePojo(String.class);
    Integer numeroVoie = _podam.manufacturePojo(Integer.class);
    String complementVoie = _podam.manufacturePojo(String.class);
    ObtentionStructureAdresseReponseSoap mockResp = _podam.manufacturePojo(ObtentionStructureAdresseReponseSoap.class);

    // configure mock
    AideCommandeFTELConnector connector = PowerMock.createNicePartialMock(AideCommandeFTELConnector.class, PRIVATE_MOCKED_METHOD);

    PowerMock.expectPrivate(connector, PRIVATE_MOCKED_METHOD, //expected method
        new Class[] { AbstractTraceability.class, Boolean.TYPE, Boolean.TYPE, String.class, String.class, String.class, List.class, MultivaluedMap.class, Map.class, Object[].class }, //parameter types
        EasyMock.anyObject(AbstractTraceability.class), EasyMock.anyBoolean(), EasyMock.anyBoolean(), EasyMock.eq(SOAP_METHOD), EasyMock.eq(null), EasyMock.eq(null), EasyMock.eq(null), EasyMock.eq(createHeaders()), EasyMock.eq(null), eqRequest(mockConfig, codeInsee, codeRivoli, numeroVoie, complementVoie)).andReturn(mockResp);

    // Execute test
    PowerMock.replayAll();
    ConnectorResponse<StructureReponse, CodeRetour> result = connector.obtenirStructureVerticale(_tracabilite, mockConfig, codeInsee, codeRivoli, numeroVoie, complementVoie, createHeaders());
    PowerMock.verifyAll();

    checkResponseMapping(mockResp, result);
  }

  /**
   * @param expected_p
   *          response with expected value
   * @param result_p
   *          result to check
   */
  private void checkResponseMapping(ObtentionStructureAdresseReponseSoap expected_p, ConnectorResponse<StructureReponse, CodeRetour> result_p)
  {
    Assert.assertEquals(expected_p.getCodeRetour().getCodeRetour(), result_p._second.getCodeRetour().intValue());
    Assert.assertEquals(expected_p.getCodeRetour().getCodeErreur(), result_p._second.getCodeErreur());
    Assert.assertEquals(expected_p.getCodeRetour().getLibelleErreur(), result_p._second.getLibelleErreur());

    if (nonNull(expected_p.getStructureDetaillee()) && //
        nonNull(expected_p.getStructureDetaillee().getBatiments()))
    {

      for (BatimentType mockBatiment : expected_p.getStructureDetaillee().getBatiments())
      {
        Optional<Batiment> resultBatiment = result_p._first.getBatiments().stream().filter(b -> b.getReferenceBatiment().equals(mockBatiment.getReferenceBatiment())).findFirst();
        Assert.assertTrue(resultBatiment.isPresent());

        for (EscalierType mockEscalier : mockBatiment.getEscaliers())
        {
          Optional<Escalier> resultEscalier = resultBatiment.get().getEscaliers().stream().filter(e -> e.getReference().equals(mockEscalier.getReference())).findFirst();
          Assert.assertTrue(resultEscalier.isPresent());

          for (EtageType mockEtage : mockEscalier.getEtages())
          {
            Assert.assertTrue(resultEscalier.get().getEtages().stream().anyMatch(et -> et.getReference().equals(mockEtage.getReference())));
          }
        }
      }
    }
  }

  /**
   * Create the headers.
   *
   * @return the headers map.
   */
  private MultivaluedMap<String, String> createHeaders()
  {
    MultivaluedMap<String, String> headers = new MultivaluedHashMap<>();
    headers.add("NAME_0", "VALUE_0"); //$NON-NLS-1$ //$NON-NLS-2$
    headers.add("NAME_1", "VALUE_1"); //$NON-NLS-1$ //$NON-NLS-2$

    return headers;
  }

}
