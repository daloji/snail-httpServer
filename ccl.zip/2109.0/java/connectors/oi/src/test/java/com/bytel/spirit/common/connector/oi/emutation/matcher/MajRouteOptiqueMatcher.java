/*******************************************************************************
* $Id: MajRouteOptiqueMatcher.java 11330 2018-10-10 07:35:02Z jstrub $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connector.oi.emutation.matcher;

import org.junit.Assert;

import com.bytel.spirit.common.connector.oi.emutation.structs.MAJRouteOptique;
import com.bytel.spirit.common.generated.configfluxOI.ConfigFluxOI;
import com.bytel.spirit.common.generated.ws.ftth.emutation.MiseAJourRouteOptique;

/**
 *
 * @author jstrub
 * @version ($Revision: 11330 $ $Date: 2018-10-10 09:35:02 +0200 (mer. 10 oct. 2018) $)
 */
public class MajRouteOptiqueMatcher extends EmutationMatcher
{
  /** */
  private MAJRouteOptique _majRouteOptique = null;

  /**
   * @param config_p
   *          config
   * @param majRouteOptique_p
   *          MAJ route optique
   */
  public MajRouteOptiqueMatcher(ConfigFluxOI config_p, MAJRouteOptique majRouteOptique_p)
  {
    super(config_p);
    _majRouteOptique = majRouteOptique_p;
  }

  @Override
  public void appendTo(StringBuffer buffer_p)
  {
    // Nothing to do
  }

  @Override
  public boolean matches(Object argument_p)
  {
    if (!MiseAJourRouteOptique.class.isInstance(argument_p))
    {
      return false;
    }

    MiseAJourRouteOptique request = (MiseAJourRouteOptique) argument_p;
    Assert.assertEquals(_majRouteOptique.getIdentifiantFibre(), request.getIdentifiantFibre());
    Assert.assertEquals(_majRouteOptique.getMotifMutation(), request.getMotifMutation().value());
    Assert.assertEquals(_majRouteOptique.getPorte(), request.getPorteTerrain());
    Assert.assertEquals(_majRouteOptique.getReferencePrise(), request.getReferencePrise());

    // Complement CMD
    if (_majRouteOptique.getComplementAdresseCmd() != null)
    {
      Assert.assertEquals(_majRouteOptique.getComplementAdresseCmd().getBatiment(), request.getBatiment());
      Assert.assertEquals(_majRouteOptique.getComplementAdresseCmd().getEscalier(), request.getEscalier());
      Assert.assertEquals(_majRouteOptique.getComplementAdresseCmd().getEtage(), request.getEtage());
    }

    // Complement Terrain
    if (_majRouteOptique.getComplementAdresseTerrain() != null)
    {
      Assert.assertEquals(_majRouteOptique.getComplementAdresseTerrain().getBatiment(), request.getBatimentTerrain());
      Assert.assertEquals(_majRouteOptique.getComplementAdresseTerrain().getEscalier(), request.getEscalierTerrain());
      Assert.assertEquals(_majRouteOptique.getComplementAdresseTerrain().getEtage(), request.getEtageTerrain());
    }

    // Reference Adresse
    if (_majRouteOptique.getReferencesAdresse() != null)
    {
      Assert.assertEquals(_majRouteOptique.getReferencesAdresse().getHexacle(), request.getReferenceAdresse().getReferenceHexacle());
      Assert.assertEquals(_majRouteOptique.getReferencesAdresse().getIdentifiantImmeuble(), request.getReferenceAdresse().getIdentifiantImmeuble());

      if (_majRouteOptique.getReferencesAdresse().getHexacleVoie() != null)
      {
        Assert.assertEquals(_majRouteOptique.getReferencesAdresse().getHexacleVoie().getCodeHexaclevoie(), request.getReferenceAdresse().getReferenceHexacleVoie().getCodeHexacleVoie());
        Assert.assertEquals(_majRouteOptique.getReferencesAdresse().getHexacleVoie().getComplementNumeroVoie(), request.getReferenceAdresse().getReferenceHexacleVoie().getComplementNumeroVoie());
        Assert.assertEquals(_majRouteOptique.getReferencesAdresse().getHexacleVoie().getNumeroVoie().intValue(), request.getReferenceAdresse().getReferenceHexacleVoie().getNumeroVoie().intValue());
      }

      if (_majRouteOptique.getReferencesAdresse().getReferenceGeographique() != null)
      {
        Assert.assertEquals(_majRouteOptique.getReferencesAdresse().getReferenceGeographique().getCoordonneesX(), request.getReferenceAdresse().getReferenceGeographique().getCoordonneesX());
        Assert.assertEquals(_majRouteOptique.getReferencesAdresse().getReferenceGeographique().getCoordonneesY(), request.getReferenceAdresse().getReferenceGeographique().getCoordonneesY());
        Assert.assertEquals(_majRouteOptique.getReferencesAdresse().getReferenceGeographique().getTypeProjection(), request.getReferenceAdresse().getReferenceGeographique().getTypeProjection());
      }

      if (_majRouteOptique.getReferencesAdresse().getRivoli() != null)
      {
        Assert.assertEquals(_majRouteOptique.getReferencesAdresse().getRivoli().getCodeInsee(), request.getReferenceAdresse().getReferenceRivoli().getCodeInsee());
        Assert.assertEquals(_majRouteOptique.getReferencesAdresse().getRivoli().getCodeRivoli(), request.getReferenceAdresse().getReferenceRivoli().getCodeRivoli());
        Assert.assertEquals(_majRouteOptique.getReferencesAdresse().getRivoli().getComplementNumeroVoie(), request.getReferenceAdresse().getReferenceRivoli().getComplementNumeroVoie());
        Assert.assertEquals(_majRouteOptique.getReferencesAdresse().getRivoli().getNumeroVoie().intValue(), request.getReferenceAdresse().getReferenceRivoli().getNumeroVoie().intValue());
      }
    }

    return super.matches(request.getEntete());
  }
}