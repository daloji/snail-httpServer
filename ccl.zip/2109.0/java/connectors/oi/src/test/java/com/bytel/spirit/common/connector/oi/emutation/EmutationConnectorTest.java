/*******************************************************************************
* $Id: EmutationConnectorTest.java 50618 2021-04-14 09:51:39Z mlebihan $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connector.oi.emutation;

import java.net.ConnectException;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import javax.ws.rs.core.MultivaluedMap;

import org.apache.cxf.endpoint.Client;
import org.apache.cxf.interceptor.Interceptor;
import org.easymock.EasyMock;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.bytel.ravel.common.test.JUnitTools;
import com.bytel.ravel.common.test.podam.JavaTimeManufacturer;
import com.bytel.ravel.common.traceability.AbstractTraceability;
import com.bytel.ravel.common.utils.Mode;
import com.bytel.ravel.common.uuid.UUIDManager;
import com.bytel.ravel.net.loadbalancing.ILoadBalancer;
import com.bytel.ravel.net.loadbalancing.URLBalancedElement;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.connector.pools.soap.SoapConnectorPool;
import com.bytel.ravel.services.connector.pools.soap.SoapInstance;
import com.bytel.spirit.common.connector.oi.CodeRetour;
import com.bytel.spirit.common.connector.oi.CodeRetour.CodeRetourConsts;
import com.bytel.spirit.common.connector.oi.OIConnectorTestHelper;
import com.bytel.spirit.common.connector.oi.emutation.matcher.ConsultationFibreMatcher;
import com.bytel.spirit.common.connector.oi.emutation.matcher.MajRouteOptiqueMatcher;
import com.bytel.spirit.common.connector.oi.emutation.matcher.RecherchePBOMatcher;
import com.bytel.spirit.common.connector.oi.emutation.structs.ComplementAdresse;
import com.bytel.spirit.common.connector.oi.emutation.structs.Fibre;
import com.bytel.spirit.common.connector.oi.emutation.structs.Fibres;
import com.bytel.spirit.common.connector.oi.emutation.structs.MAJRouteOptique;
import com.bytel.spirit.common.connector.oi.emutation.structs.MAJRouteOptique.MAJRouteOptiqueBuilder;
import com.bytel.spirit.common.connector.oi.emutation.structs.MAJRouteOptiqueResponse;
import com.bytel.spirit.common.connector.oi.emutation.structs.PBO;
import com.bytel.spirit.common.connector.oi.emutation.structs.PBOs;
import com.bytel.spirit.common.generated.configfluxOI.ConfigFluxOI;
import com.bytel.spirit.common.generated.ws.ftth.emutation.ConsultationFibres;
import com.bytel.spirit.common.generated.ws.ftth.emutation.ConsultationFibresFault;
import com.bytel.spirit.common.generated.ws.ftth.emutation.ConsultationFibresFaultCodeErreur;
import com.bytel.spirit.common.generated.ws.ftth.emutation.ConsultationFibresFaultLibelleErreur;
import com.bytel.spirit.common.generated.ws.ftth.emutation.ConsultationFibresResponse;
import com.bytel.spirit.common.generated.ws.ftth.emutation.DefaultFault;
import com.bytel.spirit.common.generated.ws.ftth.emutation.EmutationConsultationFibresFaultMessage;
import com.bytel.spirit.common.generated.ws.ftth.emutation.EmutationDefaultFaultMessage;
import com.bytel.spirit.common.generated.ws.ftth.emutation.EmutationFunctionalFaultMessage;
import com.bytel.spirit.common.generated.ws.ftth.emutation.EmutationMiseAJourRouteOptiqueFaultMessage;
import com.bytel.spirit.common.generated.ws.ftth.emutation.EmutationTechnicalFaultMessage;
import com.bytel.spirit.common.generated.ws.ftth.emutation.FibreType;
import com.bytel.spirit.common.generated.ws.ftth.emutation.FunctionalFault;
import com.bytel.spirit.common.generated.ws.ftth.emutation.FunctionalFaultCodeErreur;
import com.bytel.spirit.common.generated.ws.ftth.emutation.FunctionalFaultLibelleErreur;
import com.bytel.spirit.common.generated.ws.ftth.emutation.MiseAJourRouteOptique;
import com.bytel.spirit.common.generated.ws.ftth.emutation.MiseAJourRouteOptiqueFault;
import com.bytel.spirit.common.generated.ws.ftth.emutation.MiseAJourRouteOptiqueFaultCodeErreur;
import com.bytel.spirit.common.generated.ws.ftth.emutation.MiseAJourRouteOptiqueFaultLibelleErreur;
import com.bytel.spirit.common.generated.ws.ftth.emutation.MiseAJourRouteOptiqueResponse;
import com.bytel.spirit.common.generated.ws.ftth.emutation.PboType;
import com.bytel.spirit.common.generated.ws.ftth.emutation.RecherchePBO;
import com.bytel.spirit.common.generated.ws.ftth.emutation.RecherchePBOResponse;
import com.bytel.spirit.common.generated.ws.ftth.emutation.RouteOptique;
import com.bytel.spirit.common.generated.ws.ftth.emutation.TechnicalFault;
import com.bytel.spirit.common.generated.ws.ftth.emutation.TechnicalFaultCodeErreur;
import com.bytel.spirit.common.generated.ws.ftth.emutation.TechnicalFaultLibelleErreur;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author jstrub
 * @version ($Revision: 50618 $ $Date: 2021-04-14 11:51:39 +0200 (mer. 14 avril 2021) $)
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({ EmutationConnector.class, ILoadBalancer.class })
@PowerMockIgnore({ "com.sun.*", "org.w3c.*", "javax.xml.*" })
public class EmutationConnectorTest
{

  /** Private mocked methods. */
  private static final String PRIVATE_MOCKED_METHOD = "send"; //$NON-NLS-1$

  /** SOAP Method recherchePBO. */
  private static final String RECHERCHE_PBO_SOAP_METHOD = "RecherchePBO"; //$NON-NLS-1$
  /** SOAP Method consultationFibres. */
  private static final String CONSULTATION_FIBRES_SOAP_METHOD = "ConsultationFibres"; //$NON-NLS-1$
  /** SOAP Method miseAJourRouteOptique. */
  private static final String MISE_A_JOUR_ROUTE_OPTIQUE_SOAP_METHOD = "MiseAJourRouteOptique"; //$NON-NLS-1$

  /**
   * Before class
   */
  @BeforeClass
  public static void beforeClass()
  {
    UUIDManager.getInstance().initialize(Mode.FIXED);
    UUIDManager.getInstance().setFixedUUID(UUID.fromString("1cd9a170-bc3b-47fa-a004-359274538021")); //$NON-NLS-1$
  }

  /**
   * @param config_p
   *          config
   * @param referencePM_p
   *          reference PM
   * @param referencePBO_p
   *          reference PBO
   * @return null
   */
  private static ConsultationFibres checkConsultationFibres(ConfigFluxOI config_p, String referencePM_p, String referencePBO_p)
  {
    EasyMock.reportMatcher(new ConsultationFibreMatcher(config_p, referencePM_p, referencePBO_p));
    return null;
  }

  /**
   * @param config_p
   *          config
   * @param majRouteOptique_p
   *          MAJ route optique
   * @return null
   */
  private static MiseAJourRouteOptique checkMajRouteOptique(ConfigFluxOI config_p, MAJRouteOptique majRouteOptique_p)
  {
    EasyMock.reportMatcher(new MajRouteOptiqueMatcher(config_p, majRouteOptique_p));
    return null;
  }

  /**
   * @param config_p
   *          config
   * @param refPrestationPrise_p
   *          reference prestation prise
   * @return null
   */
  private static RecherchePBO checkRecherchePBO(ConfigFluxOI config_p, String refPrestationPrise_p)
  {
    EasyMock.reportMatcher(new RecherchePBOMatcher(config_p, refPrestationPrise_p));
    return null;
  }

  /** bean Factory generation */
  private PodamFactory _podam;

  /** tracabilite */
  private Tracabilite _tracabilite;

  /** tracabilite */
  private ConfigFluxOI _config;

  /** connector */
  private EmutationConnector _connector;

  /** Mock {@link ILoadBalancer} */
  @MockStrict
  ILoadBalancer<URLBalancedElement> _loadBalancerMock;

  /** Mock {@link URLBalancedElement} */
  @MockStrict
  URLBalancedElement _urlBalancedElementMock;

  /** Mock of connectors pool HTTP */
  @MockStrict
  @SuppressWarnings("rawtypes")
  Hashtable<String, SoapConnectorPool> _connectorPoolMock;

  /** Mock {@link SoapConnectorPool} */
  @MockStrict
  @SuppressWarnings("rawtypes")
  SoapConnectorPool _soapConnectorPoolMock;

  /** Mock {@link SoapInstance} */
  @MockStrict
  @SuppressWarnings("rawtypes")
  SoapInstance _soapInstanceMock;

  /** Mock {@link Client} */
  @MockStrict
  Client _soapInstanceMockClient;

  /**
   * Common test initialization
   */
  @Before
  public void before()
  {
    _podam = new PodamFactoryImpl();
    _podam.getStrategy().setMemoization(false);
    JavaTimeManufacturer.registerPodamFactory(_podam);
    OIConnectorTestHelper.registerBigIntegerManufacturer(_podam);

    _tracabilite = _podam.manufacturePojo(Tracabilite.class);
    _config = _podam.manufacturePojo(ConfigFluxOI.class);

    _connector = PowerMock.createNicePartialMock(EmutationConnector.class, PRIVATE_MOCKED_METHOD);
  }

  /**
   * Test nominal pour l'opération consultationFibres
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void testConsultationFibres_OK() throws Exception
  {
    // Create random beans
    ConsultationFibresResponse mockResp = _podam.manufacturePojo(ConsultationFibresResponse.class);
    String referencePM = _podam.manufacturePojo(String.class);
    String referencePBO = _podam.manufacturePojo(String.class);
    String refPrestationPrise = _podam.manufacturePojo(String.class);

    // configure mock
    PowerMock
        .expectPrivate(_connector, PRIVATE_MOCKED_METHOD, //expected method
            new Class[] { AbstractTraceability.class, Boolean.TYPE, Boolean.TYPE, //
                String.class, String.class, String.class, // 
                List.class, MultivaluedMap.class, Map.class, Object[].class }, //parameter types
            EasyMock.anyObject(AbstractTraceability.class), EasyMock.anyBoolean(), EasyMock.anyBoolean(), //
            EasyMock.eq(CONSULTATION_FIBRES_SOAP_METHOD), EasyMock.eq(null), EasyMock.eq(null), // 
            EasyMock.eq(null), EasyMock.eq(null), EasyMock.eq(null), checkConsultationFibres(_config, referencePM, referencePBO)) //
        .andReturn(mockResp);

    // Execute test
    PowerMock.replayAll();
    ConnectorResponse<Fibres, CodeRetour> result = _connector.consultationFibres(_tracabilite, _config, referencePM, referencePBO, refPrestationPrise);
    PowerMock.verifyAll();

    // Check result
    Assert.assertEquals(CodeRetourConsts.OK, result._second.getCodeRetour());
    for (FibreType mockFibre : mockResp.getFibres().getFibres())
    {
      Optional<Fibre> resultFibre = result._first.getFibres().stream().filter(f -> f.getIdentifiantFibre() == mockFibre.getIdentifiantFibre()).findFirst();
      Assert.assertTrue(resultFibre.isPresent());
      Assert.assertEquals(mockFibre.getReferenceCablePBO(), resultFibre.get().getReferenceCablePBO());
      Assert.assertEquals(mockFibre.getInformationFibrePBO(), resultFibre.get().getInformationFibrePBO());
      Assert.assertEquals(mockFibre.getInformationTubePBO(), resultFibre.get().getInformationTubePBO());
      Assert.assertEquals(mockFibre.getEtatFibre().value(), resultFibre.get().getEtatFibre());
      Assert.assertEquals(mockFibre.getReferencePrise(), resultFibre.get().getReferencePrise());
    }
  }

  /**
   * Test nominal pour l'opération consultationFibres
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void testConsultationFibres_SpecificFaultMessage() throws Exception
  {
    // Create random beans
    ConsultationFibresFault fault = new ConsultationFibresFault();
    fault.setCodeErreur(ConsultationFibresFaultCodeErreur.I_01);
    fault.setLibelleErreur(ConsultationFibresFaultLibelleErreur.IDENTIFIANT_PBO_COUPLE_REFERENCE_PM_REFERENCE_PBO_INTROUVABLE);
    EmutationConsultationFibresFaultMessage mockFault = new EmutationConsultationFibresFaultMessage(_podam.manufacturePojo(String.class), fault);

    String referencePM = _podam.manufacturePojo(String.class);
    String referencePBO = _podam.manufacturePojo(String.class);
    String refPrestationPrise = _podam.manufacturePojo(String.class);

    // Setup advanced connector mocking
    _connector = new EmutationConnector();
    setupAdvancedMock();

    // configure mock
    EasyMock.expect(_soapInstanceMockClient.invoke(EasyMock.eq(CONSULTATION_FIBRES_SOAP_METHOD), checkConsultationFibres(_config, referencePM, referencePBO))).andThrow(mockFault);

    // Execute test
    PowerMock.replayAll();
    ConnectorResponse<Fibres, CodeRetour> result = _connector.consultationFibres(_tracabilite, _config, referencePM, referencePBO, refPrestationPrise);
    PowerMock.verifyAll();

    // Check result
    Assert.assertEquals(CodeRetourConsts.PROBLEME_FONCTIONNEL, result._second.getCodeRetour());
    Assert.assertEquals(mockFault.getFaultInfo().getCodeErreur().value(), result._second.getCodeErreur());
    Assert.assertEquals(mockFault.getFaultInfo().getLibelleErreur().value(), result._second.getLibelleErreur());
  }

  /**
   * Test de chargement d'une configuration de test et tentative d'envoie : on attend une ConnectException, ce qui
   * permet de valider la configuration CXF. (cf. configuration spécifique dans la génération des classes JAXWS
   * positionnée dans le pom.xml de generated).
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void testLoadConfiguration() throws Exception
  {
    EmutationConnector connector = new EmutationConnector();
    OIConnectorTestHelper.initConnector(connector);
    Assert.assertTrue(connector.isEnabled());

    MAJRouteOptiqueBuilder builder = new MAJRouteOptiqueBuilder();
    builder.motifMutation("Commande HOTLINE"); //$NON-NLS-1$
    builder.identifiantFibre(_podam.manufacturePojo(String.class));
    try
    {
      connector.miseAJourRouteOptique(_tracabilite, _config, builder.build());
    }
    catch (Exception exception)
    {
      Assert.assertTrue(ConnectException.class.isInstance(exception.getCause().getCause()));
    }
  }

  /**
   * @throws Exception
   *           on error
   */
  @Test
  public void testMajRouteOptique_OK() throws Exception
  {
    // Create random beans
    MiseAJourRouteOptiqueResponse mockResp = _podam.manufacturePojo(MiseAJourRouteOptiqueResponse.class);
    MAJRouteOptiqueBuilder requestBuilder = _podam.manufacturePojo(MAJRouteOptiqueBuilder.class);
    // motif mutation présent dans l'enum définit dans le WSDL
    requestBuilder.motifMutation("Fibre occupée"); //$NON-NLS-1$
    requestBuilder.identifiantFibre(_podam.manufacturePojo(String.class));
    requestBuilder.porte(_podam.manufacturePojo(String.class));
    requestBuilder.referencePrise(_podam.manufacturePojo(String.class));
    requestBuilder.complementAdresseCmd(_podam.manufacturePojo(ComplementAdresse.class));
    requestBuilder.complementAdresseTerrain(_podam.manufacturePojo(ComplementAdresse.class));
    requestBuilder.referencesAdresse(null);

    MAJRouteOptique request = requestBuilder.build();

    // configure mock
    PowerMock
        .expectPrivate(_connector, PRIVATE_MOCKED_METHOD, //expected method
            new Class[] { AbstractTraceability.class, Boolean.TYPE, Boolean.TYPE, //
                String.class, String.class, String.class, //
                List.class, MultivaluedMap.class, Map.class, Object[].class }, //parameter types
            EasyMock.anyObject(AbstractTraceability.class), EasyMock.anyBoolean(), EasyMock.anyBoolean(), //
            EasyMock.eq(MISE_A_JOUR_ROUTE_OPTIQUE_SOAP_METHOD), EasyMock.eq(null), EasyMock.eq(null), //
            EasyMock.eq(null), EasyMock.eq(null), EasyMock.eq(null), checkMajRouteOptique(_config, request)) //
        .andReturn(mockResp);

    // Execute test
    PowerMock.replayAll();
    ConnectorResponse<MAJRouteOptiqueResponse, CodeRetour> result = _connector.miseAJourRouteOptique(_tracabilite, _config, request);
    PowerMock.verifyAll();

    // Check result
    Assert.assertEquals(CodeRetourConsts.OK, result._second.getCodeRetour());
    Assert.assertEquals(mockResp.getNumeroDecharge(), result._first.getNumeroDecharge());
    Assert.assertEquals(mockResp.getReferencePBO(), result._first.getReferencePBO());
    Assert.assertEquals(mockResp.getReferencePM(), result._first.getReferencePM());
    Assert.assertEquals(mockResp.getReferencePMT(), result._first.getReferencePMT());
    Assert.assertEquals(mockResp.getReferencePrise(), result._first.getReferencePrise());
    for (RouteOptique mockRoute : mockResp.getRoutesOptiques().getRoutesOptiques())
    {
      Optional<com.bytel.spirit.common.connector.oi.emutation.structs.RouteOptique> resultRoute = result._first.getRoutesOptiques().stream().filter(p -> p.getReferenceCablePBO() == mockRoute.getReferenceCablePBO()).findFirst();
      Assert.assertTrue(resultRoute.isPresent());

      Assert.assertEquals(mockRoute.getConnecteurPriseCouleur(), resultRoute.get().getConnecteurPriseCouleur());
      Assert.assertEquals(mockRoute.getConnecteurPriseNumero(), resultRoute.get().getConnecteurPriseNumero().intValue());
      Assert.assertEquals(mockRoute.getInformationFibrePBO(), resultRoute.get().getInformationFibrePBO());
      Assert.assertEquals(mockRoute.getInformationTubePBO(), resultRoute.get().getInformationTubePBO());
      Assert.assertEquals(mockRoute.getOC(), resultRoute.get().getOc());
      Assert.assertEquals(mockRoute.getReferenceCablePBO(), resultRoute.get().getReferenceCablePBO());
      Assert.assertEquals(mockRoute.getPositionPm().getInfoFibreModulePM(), resultRoute.get().getPositionPM().getInfoFibreModulePM());
      Assert.assertEquals(mockRoute.getPositionPm().getInfoTubeModulePM(), resultRoute.get().getPositionPM().getInfoTubeModulePM());
      Assert.assertEquals(mockRoute.getPositionPm().getNomModulePM(), resultRoute.get().getPositionPM().getNomModulePM());
      Assert.assertEquals(mockRoute.getPositionPm().getPositionModulePM(), resultRoute.get().getPositionPM().getPositionModulePM());
      Assert.assertEquals(mockRoute.getPositionPm().getReferenceCableModulePM(), resultRoute.get().getPositionPM().getReferenceCableModulePM());
    }
  }

  /**
   * @throws Exception
   *           on error
   */
  @Test
  public void testMajRouteOptique_SpecificFault() throws Exception
  {
    MiseAJourRouteOptiqueFault fault = new MiseAJourRouteOptiqueFault();
    fault.setCodeErreur(MiseAJourRouteOptiqueFaultCodeErreur.C_01);
    fault.setLibelleErreur(MiseAJourRouteOptiqueFaultLibelleErreur.ADRESSE_INEXISTANTE_DANS_LE_RÉFÉRENTIEL_DE_L_OI);
    EmutationMiseAJourRouteOptiqueFaultMessage mockFault = new EmutationMiseAJourRouteOptiqueFaultMessage(_podam.manufacturePojo(String.class), fault);

    MAJRouteOptiqueBuilder requestBuilder = _podam.manufacturePojo(MAJRouteOptiqueBuilder.class);
    // motif mutation présent dans l'enum définit dans le WSDL
    requestBuilder.motifMutation("Fibre occupée"); //$NON-NLS-1$
    requestBuilder.identifiantFibre(_podam.manufacturePojo(String.class));
    MAJRouteOptique request = requestBuilder.build();

    // Setup advanced connector mocking
    _connector = new EmutationConnector();
    setupAdvancedMock();

    // configure mock
    EasyMock.expect(_soapInstanceMockClient.invoke(EasyMock.eq(MISE_A_JOUR_ROUTE_OPTIQUE_SOAP_METHOD), checkMajRouteOptique(_config, request))).andThrow(mockFault);

    // Execute test
    PowerMock.replayAll();
    ConnectorResponse<MAJRouteOptiqueResponse, CodeRetour> result = _connector.miseAJourRouteOptique(_tracabilite, _config, request);
    PowerMock.verifyAll();

    // Check result
    Assert.assertEquals(CodeRetourConsts.PROBLEME_FONCTIONNEL, result._second.getCodeRetour());
    Assert.assertEquals(mockFault.getFaultInfo().getCodeErreur().value(), result._second.getCodeErreur());
    Assert.assertEquals(mockFault.getFaultInfo().getLibelleErreur().value(), result._second.getLibelleErreur());
  }

  /**
   * Test nominal pour l'opération recherchePBO
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void testRecherchePBO_CommonFault_Default() throws Exception
  {
    EmutationDefaultFaultMessage mockFault = new EmutationDefaultFaultMessage(_podam.manufacturePojo(String.class), _podam.manufacturePojo(DefaultFault.class));
    String refPrestationPrise = _podam.manufacturePojo(String.class);

    // Setup advanced connector mocking
    _connector = new EmutationConnector();
    setupAdvancedMock();

    // configure mock
    EasyMock.expect(_soapInstanceMockClient.invoke(EasyMock.eq(RECHERCHE_PBO_SOAP_METHOD), checkRecherchePBO(_config, refPrestationPrise))).andThrow(mockFault);

    // Execute test
    PowerMock.replayAll();
    ConnectorResponse<PBOs, CodeRetour> result = _connector.recherchePBO(_tracabilite, _config, refPrestationPrise);
    PowerMock.verifyAll();

    // Check result
    Assert.assertEquals(CodeRetourConsts.PROBLEME_TECHNIQUE, result._second.getCodeRetour());
    Assert.assertEquals(mockFault.getFaultInfo().getCodeErreur(), result._second.getCodeErreur());
    Assert.assertEquals(mockFault.getFaultInfo().getLibelleErreur(), result._second.getLibelleErreur());
  }

  /**
   * Test nominal pour l'opération recherchePBO
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void testRecherchePBO_CommonFault_Functional() throws Exception
  {
    FunctionalFault fault = new FunctionalFault();
    fault.setCodeErreur(FunctionalFaultCodeErreur.S_02);
    fault.setLibelleErreur(FunctionalFaultLibelleErreur.RECHERCHE_OU_MUTATION_IMPOSSIBLE_PAS_D_ACCÈS_LIVRÉ_NI_EN_COURS_DE_LIVRAISON_POUR_CETTE_RÉFÉRENCE);
    EmutationFunctionalFaultMessage mockFault = new EmutationFunctionalFaultMessage(_podam.manufacturePojo(String.class), fault);
    String refPrestationPrise = _podam.manufacturePojo(String.class);

    // Setup advanced connector mocking
    _connector = new EmutationConnector();
    setupAdvancedMock();

    // configure mock
    EasyMock.expect(_soapInstanceMockClient.invoke(EasyMock.eq(RECHERCHE_PBO_SOAP_METHOD), checkRecherchePBO(_config, refPrestationPrise))).andThrow(mockFault);

    // Execute test
    PowerMock.replayAll();
    ConnectorResponse<PBOs, CodeRetour> result = _connector.recherchePBO(_tracabilite, _config, refPrestationPrise);
    PowerMock.verifyAll();

    // Check result
    Assert.assertEquals(CodeRetourConsts.PROBLEME_FONCTIONNEL, result._second.getCodeRetour());
    Assert.assertEquals(mockFault.getFaultInfo().getCodeErreur().value(), result._second.getCodeErreur());
    Assert.assertEquals(mockFault.getFaultInfo().getLibelleErreur().value(), result._second.getLibelleErreur());
  }

  /**
   * Test nominal pour l'opération recherchePBO
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void testRecherchePBO_CommonFault_Technical() throws Exception
  {
    TechnicalFault fault = new TechnicalFault();
    fault.setCodeErreur(TechnicalFaultCodeErreur.S_01);
    fault.setLibelleErreur(TechnicalFaultLibelleErreur.ERREUR_SERVEUR);
    EmutationTechnicalFaultMessage mockFault = new EmutationTechnicalFaultMessage(_podam.manufacturePojo(String.class), fault);
    String refPrestationPrise = _podam.manufacturePojo(String.class);

    // Setup advanced connector mocking
    _connector = new EmutationConnector();
    setupAdvancedMock();

    // configure mock
    EasyMock.expect(_soapInstanceMockClient.invoke(EasyMock.eq(RECHERCHE_PBO_SOAP_METHOD), checkRecherchePBO(_config, refPrestationPrise))).andThrow(mockFault);

    // Execute test
    PowerMock.replayAll();
    ConnectorResponse<PBOs, CodeRetour> result = _connector.recherchePBO(_tracabilite, _config, refPrestationPrise);
    PowerMock.verifyAll();

    // Check result
    Assert.assertEquals(CodeRetourConsts.PROBLEME_TECHNIQUE, result._second.getCodeRetour());
    Assert.assertEquals(mockFault.getFaultInfo().getCodeErreur().value(), result._second.getCodeErreur());
    Assert.assertEquals(mockFault.getFaultInfo().getLibelleErreur().value(), result._second.getLibelleErreur());
  }

  /**
   * Test nominal pour l'opération recherchePBO
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void testRecherchePBO_OK() throws Exception
  {
    // Create random beans
    RecherchePBOResponse mockResp = _podam.manufacturePojo(RecherchePBOResponse.class);
    String refPrestationPrise = _podam.manufacturePojo(String.class);

    // configure mock
    PowerMock
        .expectPrivate(_connector, PRIVATE_MOCKED_METHOD, //expected method
            new Class[] { AbstractTraceability.class, Boolean.TYPE, Boolean.TYPE, //
                String.class, String.class, String.class, //
                List.class, MultivaluedMap.class, Map.class, Object[].class }, //parameter types
            EasyMock.anyObject(AbstractTraceability.class), EasyMock.anyBoolean(), EasyMock.anyBoolean(), //
            EasyMock.eq(RECHERCHE_PBO_SOAP_METHOD), EasyMock.eq(null), EasyMock.eq(null), //
            EasyMock.eq(null), EasyMock.eq(null), EasyMock.eq(null), checkRecherchePBO(_config, refPrestationPrise)) //
        .andReturn(mockResp);

    // Execute test
    PowerMock.replayAll();
    ConnectorResponse<PBOs, CodeRetour> result = _connector.recherchePBO(_tracabilite, _config, refPrestationPrise);
    PowerMock.verifyAll();

    // Check result
    Assert.assertEquals(CodeRetourConsts.OK, result._second.getCodeRetour());
    for (PboType pbo : mockResp.getListePBO().getPbos())
    {
      Optional<PBO> resultPbo = result._first.getPbos().stream().filter(p -> p.getReferencePBO() == pbo.getReferencePBO()).findFirst();
      Assert.assertTrue(resultPbo.isPresent());
      Assert.assertEquals(pbo.getLocalisationPBO(), resultPbo.get().getAdressePBO().getReferencesAdresse().getAdresseLibre());
      Assert.assertEquals(pbo.getNaturePBO(), resultPbo.get().getNaturePBO());
      Assert.assertEquals(pbo.getReferencePM(), resultPbo.get().getReferencePM());
      Assert.assertEquals(pbo.getNombreFibresDisponibles(), resultPbo.get().getNombreFibresDisponibles());
    }
  }

  /**
   * Test nominal pour l'opération recherchePBO
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void testTilPBO_OK() throws Exception
  {
    EmutationConnector tilConnector = new EmutationConnector();
    OIConnectorTestHelper.initConnector(tilConnector, "http://localhost:9998/emutation"); //$NON-NLS-1$
    Assert.assertTrue(tilConnector.isEnabled());

    try
    {
      Tracabilite tracabilite = new Tracabilite();
      tracabilite.setIdCorrelationSpirit("idQuiDoitApparaitre"); //$NON-NLS-1$
      tracabilite.setMessageId("idInattendu1"); //$NON-NLS-1$
      ConnectorResponse<PBOs, CodeRetour> result = tilConnector.recherchePBO(tracabilite, _config, "refPP1234"); //$NON-NLS-1$

      Assert.assertEquals(CodeRetourConsts.OK, result._second.getCodeRetour());
    }
    catch (Exception exception)
    {
      // If you are here, your SOAP TIL instance isn't active at the http url you've set.
      // But test won't break for that.
      Assert.assertTrue(ConnectException.class.isInstance(exception.getCause().getCause()));
    }
  }

  /**
   * @throws Exception
   *           on error
   */
  @SuppressWarnings({ "unchecked" })
  private void setupAdvancedMock() throws Exception
  {
    OIConnectorTestHelper.initConnector(_connector);

    String urlBalancedElementName = _podam.manufacturePojo(String.class);
    String urlBalancedElementDescription = _podam.manufacturePojo(String.class);

    EasyMock.expect(_loadBalancerMock.chooseBalancedElement()).andReturn(_urlBalancedElementMock);
    EasyMock.expect(_urlBalancedElementMock.getName()).andReturn(urlBalancedElementName);
    EasyMock.expect(_urlBalancedElementMock.getDescription()).andReturn(urlBalancedElementDescription);
    EasyMock.expect(_urlBalancedElementMock.getName()).andReturn(urlBalancedElementName);
    EasyMock.expect(_connectorPoolMock.get(urlBalancedElementName)).andReturn(_soapConnectorPoolMock);
    EasyMock.expect(_soapConnectorPoolMock.borrowObject()).andReturn(_soapInstanceMock);
    EasyMock.expect(_soapInstanceMock.getClient()).andReturn(_soapInstanceMockClient);

    _soapConnectorPoolMock.returnObject(EasyMock.anyObject());
    EasyMock.expectLastCall();

    JUnitTools.setInaccessibleFieldValue(_connector, "_loadBalancer", _loadBalancerMock); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_connectorPool", _connectorPoolMock); //$NON-NLS-1$

    EasyMock.expect(_soapInstanceMockClient.getInInterceptors()).andReturn(new ArrayList<Interceptor<?>>());
    EasyMock.expect(_soapInstanceMockClient.getOutInterceptors()).andReturn(new ArrayList<Interceptor<?>>());
  }
}
