/*******************************************************************************
* $Id: AideCommandeAltitudeConnectorTest.java 42744 2020-10-26 13:02:33Z jbrites $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connector.oi.altitude;

import java.lang.reflect.Field;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.easymock.EasyMock;
import org.joda.time.LocalDate;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.net.rest.RestInstance;
import com.bytel.ravel.services.connector.RESTRequest;

/**
 * Test Altitude Service.
 *
 * @author mlebihan
 * @version ($Revision: 42744 $ $Date: 2020-10-26 14:02:33 +0100 (lun. 26 oct. 2020) $)
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({ AltitudeAuthentService.class, RestCaller.class })
@PowerMockIgnore({ "com.sun.*", "org.w3c.*", "javax.xml.*" })
public class AltitudeServiceTest
{
  /** For get(RestInstance restInstance, RESTRequest restRequest_p) method call. */
  private static String GET = "get"; //$NON-NLS-1$

  /** Authentification service. */
  private AltitudeAuthentService _authentService;

  /** Rest Caller Mock. */
  private RestCaller _restCallerMock;

  /**
   * Initialize AltitudeAuthentService with a global REST destination.
   *
   * @throws Exception
   *           if field _restCaller cannot be set with the mock.
   */
  @Before
  public void beforeTest() throws Exception
  {
    _authentService = new AltitudeAuthentService("restAltitude", "http://test.no.no//", "ocLogin", "ocPassword", 10, null, null, null, 8180, null, false); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$)

    // Create a mock that :
    // 1) Invokes RestCaller(String name_p, String completeUrl_p, int timeout_p, String proxyLogin_p, String proxyPassword_p,
    //    String proxyHost_p, int proxyPort_p, String secureSocketProtocol_p, boolean disableCnCheck_p) constructor.
    Class<?>[] constructorTypes = { String.class, String.class, Integer.TYPE, String.class, String.class, String.class, //
        Integer.TYPE, String.class, Boolean.TYPE };
    Object[] constructorArguments = { "restAltitude", "http://test.no.no//", 10, null, null, null, 8180, null, false }; //$NON-NLS-1$ //$NON-NLS-2$

    // 2) Mocks only get(RestInstance restInstance, RESTRequest restRequest_p) method.
    Class<?>[] getTypes = { RestInstance.class, RESTRequest.class };
    _restCallerMock = PowerMock.createNicePartialMock(RestCaller.class, GET, getTypes, constructorArguments, constructorTypes);

    Assert.assertNotNull("RestCaller Mock not initialized", _restCallerMock); //$NON-NLS-1$

    Field authentServiceRestCallerMember = _authentService.getClass().getDeclaredField("_restCaller"); //$NON-NLS-1$
    authentServiceRestCallerMember.setAccessible(true);
    authentServiceRestCallerMember.set(_authentService, _restCallerMock);
  }

  /**
   * NOK : An empty JSON is returned.
   *
   * @throws Exception
   *           if a trouble happens.
   */
  @Test
  public void testAltitudeService_NOK_EmptyJson() throws Exception
  {
    String jsonAltitudeToken = ""; //$NON-NLS-1$

    Response ok = Response.ok(jsonAltitudeToken).build();
    PowerMock.expectPrivate(_restCallerMock, GET, (RestInstance) EasyMock.anyObject(), (RESTRequest) EasyMock.anyObject()).andReturn(ok);

    PowerMock.replayAll();

    try
    {
      _authentService.getAccessToken();
      Assert.fail("Empty Json received must throw a RavelException"); //$NON-NLS-1$
    }
    catch (RavelException exception)
    {
      Assert.assertEquals("Empty Json received must throw a RavelException with the good message", // //$NON-NLS-1$
          "Empty JSON response received from REST call restAltitude.", exception.getMessage()); //$NON-NLS-1$
    }

    PowerMock.verifyAll();
  }

  /**
   * NOK : Any http problem happens.
   *
   * @throws Exception
   *           if a trouble happens.
   */
  @Test
  public void testAltitudeService_NOK_HttpProblem() throws Exception
  {
    PowerMock.expectPrivate(_restCallerMock, GET, (RestInstance) EasyMock.anyObject(), (RESTRequest) EasyMock.anyObject()) //
        .andThrow(new IllegalStateException("Server is down at the moment.")); //$NON-NLS-1$

    PowerMock.replayAll();

    try
    {
      _authentService.getAccessToken();
      Assert.fail("A General HTTP problem must throw a RavelException"); //$NON-NLS-1$
    }
    catch (RavelException exception)
    {
      Assert.assertTrue("A General HTTP problem must throw a RavelException with the good message", // //$NON-NLS-1$
          exception.getMessage().startsWith("Unable to send REST call restAltitude or to receive response from it ")); //$NON-NLS-1$
    }

    PowerMock.verifyAll();
  }

  /**
   * NOK : An internal error happens.
   *
   * @throws Exception
   *           if a trouble happens.
   */
  @Test
  public void testAltitudeService_NOK_InternalServerError() throws Exception
  {
    Response internalServerError = Response.status(Status.INTERNAL_SERVER_ERROR.getStatusCode()).build();
    PowerMock.expectPrivate(_restCallerMock, GET, (RestInstance) EasyMock.anyObject(), (RESTRequest) EasyMock.anyObject()).andReturn(internalServerError);

    PowerMock.replayAll();

    try
    {
      _authentService.getAccessToken();
      Assert.fail("Internal Server Error must throw a RavelException"); //$NON-NLS-1$
    }
    catch (RavelException exception)
    {
      Assert.assertEquals("Internal Server Error must throw a RavelException with the good message", // //$NON-NLS-1$
          "Internal server error during REST call restAltitude.", exception.getMessage()); //$NON-NLS-1$
    }

    PowerMock.verifyAll();
  }

  /**
   * NOK : An invalid JSON is returned.
   *
   * @throws Exception
   *           if a trouble happens.
   */
  @Test
  public void testAltitudeService_NOK_InvalidJson() throws Exception
  {
    String jsonAltitudeToken = "{ \"value\": \"742509\", \"expire\": \"204-1-01T20:47:12.7871699+02:00\", \"oc\": \"Son of the OC\", \"error\": null }"; //$NON-NLS-1$

    Response ok = Response.ok(jsonAltitudeToken).build();
    PowerMock.expectPrivate(_restCallerMock, GET, (RestInstance) EasyMock.anyObject(), (RESTRequest) EasyMock.anyObject()).andReturn(ok);

    PowerMock.replayAll();

    try
    {
      _authentService.getAccessToken();
      Assert.fail("Invalid Json received must throw a RavelException"); //$NON-NLS-1$
    }
    catch (RavelException exception)
    {
      Assert.assertTrue("Invalid Json received must throw a RavelException with the good message", // //$NON-NLS-1$
          exception.getMessage().startsWith("Invalid JSON content received from REST call restAltitude,")); //$NON-NLS-1$
    }

    PowerMock.verifyAll();
  }

  /**
   * NOK : Another kind of entity than the one expected has been returned.
   *
   * @throws Exception
   *           if a trouble happens.
   */
  @Test
  public void testAltitudeService_NOK_UnexpectedEntity() throws Exception
  {
    Response wrongEntity = Response.ok(LocalDate.now()).build();
    PowerMock.expectPrivate(_restCallerMock, GET, (RestInstance) EasyMock.anyObject(), (RESTRequest) EasyMock.anyObject()).andReturn(wrongEntity);

    PowerMock.replayAll();

    try
    {
      _authentService.getAccessToken();
      Assert.fail("A wrong entity returned must throw a RavelException"); //$NON-NLS-1$
    }
    catch (RavelException exception)
    {
      Assert.assertTrue("A wrong entity returned must throw a RavelException with the good message", // //$NON-NLS-1$
          exception.getMessage().startsWith("Unable to extract entity object from REST restAltitude call response")); //$NON-NLS-1$
    }

    PowerMock.verifyAll();
  }

  /**
   * OK : Test that when after a valid token is given, a clearInvalidToken() cause it to be renewed at the next call
   * even if it is not expired.
   *
   * @throws Exception
   *           if a trouble happens.
   */
  @Test
  public void testAltitudeService_OK_ClearInvalidToken() throws Exception
  {
    // First, a not expired token will be returned by the service.
    String jsonValidAltitudeToken = "{ \"value\": \"742507\", \"expire\": \"2040-10-01T20:47:12.7871699+02:00\", \"oc\": \"Son of the OC\", \"error\": null }"; //$NON-NLS-1$
    Response firstExpiredAltitudeToken = Response.ok(jsonValidAltitudeToken).build();
    PowerMock.expectPrivate(_restCallerMock, GET, (RestInstance) EasyMock.anyObject(), (RESTRequest) EasyMock.anyObject()).andReturn(firstExpiredAltitudeToken);

    // Another call to the getAccesToken() is expected as we will clear the previous token.
    String jsonAnotherAltitudeToken = "{ \"value\": \"742508\", \"expire\": \"2041-10-01T20:47:12.7871699+02:00\", \"oc\": \"Son of the OC\", \"error\": null }"; //$NON-NLS-1$
    Response anotherAltitudeToken = Response.ok(jsonAnotherAltitudeToken).build();
    PowerMock.expectPrivate(_restCallerMock, GET, (RestInstance) EasyMock.anyObject(), (RESTRequest) EasyMock.anyObject()).andReturn(anotherAltitudeToken);

    PowerMock.replayAll();

    Assert.assertEquals("The first token expected has not been returned.", "742507", _authentService.getAccessToken()); //$NON-NLS-1$ //$NON-NLS-2$
    _authentService.cleanInvalidToken();
    Assert.assertEquals("The other token expected after a call to clearInvalidToken() has not been returned.", "742508", _authentService.getAccessToken()); //$NON-NLS-1$ //$NON-NLS-2$

    PowerMock.verifyAll();
  }

  /**
   * OK : Test that when the current token is still active service doesn't attempt to renew it.
   *
   * @throws Exception
   *           if a trouble happens.
   */
  @Test
  public void testAltitudeService_OK_KeepValid() throws Exception
  {
    // getAccesToken() returns a token that will be valid for a long time.
    String jsonValidAltitudeToken = "{ \"value\": \"742509\", \"expire\": \"2040-10-01T20:47:12.7871699+02:00\", \"oc\": \"Son of the OC\", \"error\": null }"; //$NON-NLS-1$
    Response validAltitudeToken = Response.ok(jsonValidAltitudeToken).build();
    PowerMock.expectPrivate(_restCallerMock, GET, (RestInstance) EasyMock.anyObject(), (RESTRequest) EasyMock.anyObject()).andReturn(validAltitudeToken);

    PowerMock.replayAll();

    Assert.assertEquals("The valid token expected has not been returned.", "742509", _authentService.getAccessToken()); //$NON-NLS-1$ //$NON-NLS-2$

    try
    {
      _authentService.getAccessToken();
    }
    catch (RuntimeException e)
    {
      // Fails if a second attempt happens because the mock doesn't expected it.
      Assert.fail("Another call to the REST service has been attempted but the first token returned was still valid."); //$NON-NLS-1$
    }

    PowerMock.verifyAll();
  }

  /**
   * OK : Test that when the token is expired it is renewed.
   *
   * @throws Exception
   *           if a trouble happens.
   */
  @Test
  public void testAltitudeService_OK_RenewToken() throws Exception
  {
    // First, a token will be returned by the service. We have put a expire timestamp in the past.
    String jsonExpiredAltitudeToken = "{ \"value\": \"742507\", \"expire\": \"1967-10-01T20:47:12.7871699+02:00\", \"oc\": \"Grandfather of the OC\", \"error\": null }"; //$NON-NLS-1$
    Response firstExpiredAltitudeToken = Response.ok(jsonExpiredAltitudeToken).build();
    PowerMock.expectPrivate(_restCallerMock, GET, (RestInstance) EasyMock.anyObject(), (RESTRequest) EasyMock.anyObject()).andReturn(firstExpiredAltitudeToken);

    // Another call to the getAccesToken() has to return this new token.
    String jsonRenewedAltitudeToken = "{ \"value\": \"742508\", \"expire\": \"2040-10-01T20:47:12.7871699+02:00\", \"oc\": \"Son of the OC\", \"error\": null }"; //$NON-NLS-1$
    Response renewedAltitudeToken = Response.ok(jsonRenewedAltitudeToken).build();
    PowerMock.expectPrivate(_restCallerMock, GET, (RestInstance) EasyMock.anyObject(), (RESTRequest) EasyMock.anyObject()).andReturn(renewedAltitudeToken);

    PowerMock.replayAll();

    Assert.assertEquals("The first token expected has not been returned.", "742507", _authentService.getAccessToken()); //$NON-NLS-1$ //$NON-NLS-2$
    Assert.assertEquals("The renewed token expected has not been returned.", "742508", _authentService.getAccessToken()); //$NON-NLS-1$ //$NON-NLS-2$

    PowerMock.verifyAll();
  }

  /**
   * OK : Test that the wished token is returned when all is Ok.
   *
   * @throws Exception
   *           if a trouble happens.
   */
  @Test
  public void testAltitudeService_OK_SingleCall() throws Exception
  {
    String jsonAltitudeToken = "{ \"value\": \"742506\", \"expire\": \"2020-10-01T20:47:12.7871699+02:00\", \"oc\": \"Quadrigramme de l’OC\", \"error\": null }"; //$NON-NLS-1$

    Response ok = Response.ok(jsonAltitudeToken).build();
    PowerMock.expectPrivate(_restCallerMock, GET, (RestInstance) EasyMock.anyObject(), (RESTRequest) EasyMock.anyObject()).andReturn(ok);

    PowerMock.replayAll();

    Assert.assertEquals("The expected token has not been returned.", "742506", _authentService.getAccessToken()); //$NON-NLS-1$ //$NON-NLS-2$

    PowerMock.verifyAll();
  }

}
