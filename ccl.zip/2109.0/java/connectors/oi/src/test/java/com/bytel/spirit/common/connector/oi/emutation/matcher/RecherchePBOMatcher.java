/*******************************************************************************
* $Id: RecherchePBOMatcher.java 11167 2018-10-04 14:59:46Z jstrub $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connector.oi.emutation.matcher;

import org.junit.Assert;

import com.bytel.spirit.common.generated.configfluxOI.ConfigFluxOI;
import com.bytel.spirit.common.generated.ws.ftth.emutation.RecherchePBO;

/**
 *
 * @author jstrub
 * @version ($Revision: 11167 $ $Date: 2018-10-04 16:59:46 +0200 (jeu. 04 oct. 2018) $)
 */
public class RecherchePBOMatcher extends EmutationMatcher
{
  /** */
  private String _refPrestationPrise = null;

  /**
   * @param config_p
   *          config
   * @param refPrestationPrise_p
   *          reference prestation prise
   */
  public RecherchePBOMatcher(ConfigFluxOI config_p, String refPrestationPrise_p)
  {
    super(config_p);
    _refPrestationPrise = refPrestationPrise_p;
  }

  @Override
  public void appendTo(StringBuffer buffer_p)
  {
    // FIXME Nothing to do
  }

  @Override
  public boolean matches(Object argument_p)
  {
    if (!RecherchePBO.class.isInstance(argument_p))
    {
      return false;
    }
    RecherchePBO request = (RecherchePBO) argument_p;
    Assert.assertEquals(_refPrestationPrise, request.getReferencePrestationPrise());

    return super.matches(request.getEntete());
  }
}