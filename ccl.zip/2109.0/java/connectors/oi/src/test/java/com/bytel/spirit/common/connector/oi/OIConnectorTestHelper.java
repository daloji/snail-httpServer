/*******************************************************************************
* $Id: OIConnectorTestHelper.java 50618 2021-04-14 09:51:39Z mlebihan $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connector.oi;

import java.lang.reflect.Type;
import java.math.BigInteger;
import java.util.Random;

import com.bytel.ravel.common.conf.generated.LoadBalancer;
import com.bytel.ravel.common.conf.generated.Param;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.services.conf.connector.generated.Connector;
import com.bytel.ravel.services.conf.connector.generated.URL;
import com.bytel.ravel.services.conf.connector.generated.URLS;
import com.bytel.ravel.services.connector.AbstractSOAPConnector;
import com.bytel.spirit.common.shared.misc.connectors.AbstractSpiritSOAPConnector;

import uk.co.jemos.podam.api.AttributeMetadata;
import uk.co.jemos.podam.api.DataProviderStrategy;
import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.typeManufacturers.TypeTypeManufacturerImpl;

/**
 *
 * @author jstrub
 * @version ($Revision: 50618 $ $Date: 2021-04-14 11:51:39 +0200 (mer. 14 avril 2021) $)
 */
public final class OIConnectorTestHelper
{

  /**
   * Init a connector
   *
   * @param connector_p
   *          connector to init
   * @throws RavelException
   *           on error
   */
  public static void initConnector(AbstractSpiritSOAPConnector connector_p) throws RavelException
  {
    final Connector connectorConf = new Connector();
    connectorConf.setName("dummy-connector"); //$NON-NLS-1$
    connectorConf.setEnabled(true);
    connectorConf.setURLS(generateURLS(null));

    connector_p.loadConnectorConfiguration(connectorConf);
  }

  /**
   * Init a connector
   *
   * @param connector_p
   *          connector to init
   * @param accessPoint_p
   *          Access point. If null, default http://localhost:56666 will be set.
   * @throws RavelException
   *           on error
   */
  public static void initConnector(AbstractSpiritSOAPConnector connector_p, String accessPoint_p) throws RavelException
  {
    final Connector connectorConf = new Connector();
    connectorConf.setName("dummy-connector"); //$NON-NLS-1$
    connectorConf.setEnabled(true);
    connectorConf.setURLS(generateURLS(accessPoint_p));

    connector_p.loadConnectorConfiguration(connectorConf);
  }

  /**
   * Register BigInteger manufacturer
   *
   * @param podam_p
   *          podam
   */
  public static void registerBigIntegerManufacturer(PodamFactory podam_p)
  {
    podam_p.getStrategy().addOrReplaceTypeManufacturer(BigInteger.class, new TypeTypeManufacturerImpl()
    {
      private Random _random = new Random(System.currentTimeMillis());

      @Override
      public Object getType(DataProviderStrategy strategy, AttributeMetadata attributeMetadata, java.util.Map<String, Type> genericTypesArgumentsMap)
      {
        return BigInteger.valueOf(_random.nextLong());
      }
    });
  }

  /**
   * Génération du LoadBalancer minimal pour passer {@link AbstractSOAPConnector#loadConnectorConfiguration(Connector)}
   *
   * @return {@link LoadBalancer}
   */
  private static LoadBalancer generateLoadBalancer()
  {
    final LoadBalancer loadBalancer = new LoadBalancer();
    Param timer = new Param();
    timer.setName("TIMER"); //$NON-NLS-1$
    timer.setValue("30000"); //$NON-NLS-1$
    loadBalancer.getParam().add(timer);
    loadBalancer.setType("RoundRobin"); //$NON-NLS-1$
    return loadBalancer;
  }

  /**
   * Génération du URL minimal pour passer {@link AbstractSOAPConnector#loadConnectorConfiguration(Connector)}
   *
   * @param accessPoint_p
   *          Can be null and a default one, http://localhost:56666, will be set.
   * @return {@link URL}
   */
  private static URL generateURL(String accessPoint_p)
  {
    final URL url = new URL();
    url.setName("urlName"); //$NON-NLS-1$
    url.setAccessPoint(accessPoint_p != null ? accessPoint_p : "http://localhost:56666"); //$NON-NLS-1$

    Param param = new Param();
    param.setName("PROXY_ENABLED"); //$NON-NLS-1$
    param.setValue(String.valueOf(false));
    url.getParam().add(param);

    param = new Param();
    param.setName("TIMEOUT"); //$NON-NLS-1$
    param.setValue("30000"); //$NON-NLS-1$
    url.getParam().add(param);

    param = new Param();
    param.setName("BASIC_AUTHENT"); //$NON-NLS-1$
    param.setValue(String.valueOf(false));
    url.getParam().add(param);

    param = new Param();
    param.setName("CONNECTION_TIMEOUT"); //$NON-NLS-1$
    param.setValue("30000"); //$NON-NLS-1$
    url.getParam().add(param);

    param = new Param();
    param.setName("RECEIVE_TIMEOUT"); //$NON-NLS-1$
    param.setValue("30000"); //$NON-NLS-1$
    url.getParam().add(param);

    return url;
  }

  /**
   * Generates URLs with a single entry for an access point.
   *
   * @param accessPoint_p
   *          Can be null and a default one, http://localhost:56666, will be set.
   * @return URLS
   */
  private static URLS generateURLS(String accessPoint_p)
  {
    final URLS urls = new URLS();
    urls.setLoadBalancer(generateLoadBalancer());
    urls.getURL().add(generateURL(accessPoint_p));
    return urls;
  }

  /**
   * Private constructor
   */
  private OIConnectorTestHelper()
  {

  }
}
