/*******************************************************************************
* $Id: AbstractAideCommandeConnectorTest.java 42744 2020-10-26 13:02:33Z jbrites $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connector.oi.aidecommande;

import org.junit.Before;

import com.bytel.ravel.common.test.podam.JavaTimeManufacturer;
import com.bytel.spirit.common.connector.oi.OIConnectorTestHelper;
import com.bytel.spirit.common.connector.oi.aidecommande.structs.structureverticale.StructureReponse;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author jstrub
 * @version ($Revision: 42744 $ $Date: 2020-10-26 14:02:33 +0100 (lun. 26 oct. 2020) $)
 */
public abstract class AbstractAideCommandeConnectorTest
{

  /** Private mocked methods. */
  protected static final String PRIVATE_MOCKED_METHOD = "send"; //$NON-NLS-1$
  /** Expected SOAP method. */
  protected static final String SOAP_METHOD = "obtentionStructureAdresseOperation"; //$NON-NLS-1$

  /** bean Factory generation */
  protected PodamFactory _podam;

  /** tracabilite */
  protected Tracabilite _tracabilite;

  /**
   * Common test initialization
   */
  @Before
  public void before()
  {
    _podam = new PodamFactoryImpl();
    _podam.getStrategy().setMemoization(false);
    JavaTimeManufacturer.registerPodamFactory(_podam);
    OIConnectorTestHelper.registerBigIntegerManufacturer(_podam);

    _tracabilite = _podam.manufacturePojo(Tracabilite.class);
  }

  /**
   * Test correct connector configuration loading (load-balancing init, CXF Proxy creation, ...)
   *
   * @throws Exception
   *           on test error
   */
  public abstract void testLoadConfiguration() throws Exception;

  /**
   * Test correct mappings between partner specific format and internal {@link StructureReponse} definition, for a
   * request with an hexacle.
   *
   * @throws Exception
   *           on test error
   */
  public abstract void testMappingsWithHexacle() throws Exception;

  /**
   * Test correct mappings between partner specific format and internal {@link StructureReponse} definition, for a
   * request with an IMB.
   *
   * @throws Exception
   *           on test error
   */
  public abstract void testMappingsWithIMB() throws Exception;

  /**
   * Test correct mappings between partner specific format and internal {@link StructureReponse} definition, for a
   * request with an IMB.
   *
   * @throws Exception
   *           on test error
   */
  public abstract void testMappingsWithPTO() throws Exception;

  /**
   * Test correct mappings between partner specific format and internal {@link StructureReponse} definition, for a
   * request with an PTO. OI does not send valid values for Brassage and EmplacementPmType
   *
   * @throws Exception
   *           on test error
   */
  public abstract void testMappingsWithPTODefaultPmValues() throws Exception;

  /**
   * Test correct mappings between partner specific format and internal {@link StructureReponse} definition, for a
   * request with a quadruplet.
   *
   * @throws Exception
   *           on test error
   */
  public abstract void testMappingsWithQuadruplet() throws Exception;

}
