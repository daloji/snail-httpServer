/*******************************************************************************
* $Id: ConsultationFibreMatcher.java 11167 2018-10-04 14:59:46Z jstrub $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connector.oi.emutation.matcher;

import org.junit.Assert;

import com.bytel.spirit.common.generated.configfluxOI.ConfigFluxOI;
import com.bytel.spirit.common.generated.ws.ftth.emutation.ConsultationFibres;

/**
 *
 * @author jstrub
 * @version ($Revision: 11167 $ $Date: 2018-10-04 16:59:46 +0200 (jeu. 04 oct. 2018) $)
 */
public class ConsultationFibreMatcher extends EmutationMatcher
{
  /** */
  private String _referencePM = null;
  /** */
  private String _referencePBO = null;

  /**
   * @param config_p
   *          config
   * @param referencePM_p
   *          reference PM
   * @param referencePBO_p
   *          reference PBO
   */
  public ConsultationFibreMatcher(ConfigFluxOI config_p, String referencePM_p, String referencePBO_p)
  {
    super(config_p);
    _referencePM = referencePM_p;
    _referencePBO = referencePBO_p;
  }

  @Override
  public void appendTo(StringBuffer buffer_p)
  {
    // FIXME Nothing to do
  }

  @Override
  public boolean matches(Object argument_p)
  {
    if (!ConsultationFibres.class.isInstance(argument_p))
    {
      return false;
    }
    ConsultationFibres request = (ConsultationFibres) argument_p;
    Assert.assertEquals(_referencePM, request.getReferencePM());
    Assert.assertEquals(_referencePBO, request.getReferencePBO());

    return super.matches(request.getEntete());
  }
}