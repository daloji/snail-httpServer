/*******************************************************************************
* $Id: EmutationMatcher.java 11358 2018-10-10 09:53:40Z jstrub $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connector.oi.emutation.matcher;

import org.easymock.IArgumentMatcher;
import org.junit.Assert;

import com.bytel.spirit.common.generated.configfluxOI.ConfigFluxOI;
import com.bytel.spirit.common.generated.ws.ftth.emutation.EnteteRequeteType;

/**
 *
 * @author jstrub
 * @version ($Revision: 11358 $ $Date: 2018-10-10 11:53:40 +0200 (mer. 10 oct. 2018) $)
 */
public class EmutationMatcher implements IArgumentMatcher
{
  /** */
  private ConfigFluxOI _config;

  /**
   * @param config_p
   *          config
   */
  public EmutationMatcher(ConfigFluxOI config_p)
  {
    _config = config_p;
  }

  @Override
  public void appendTo(StringBuffer buffer_p)
  {
    // FIXME Nothing to do
  }

  @Override
  public boolean matches(Object argument_p)
  {
    if (!EnteteRequeteType.class.isInstance(argument_p))
    {
      return false;
    }

    EnteteRequeteType entete = (EnteteRequeteType) argument_p;
    Assert.assertEquals(_config.getConnexionTechnique().getIdentite().getNom(), entete.getOperateurCommercial().getNom());
    Assert.assertEquals(_config.getConnexionTechnique().getIdentite().getIdentifiant(), entete.getOperateurCommercial().getIdentifiant());
    Assert.assertEquals(_config.getConnexionTechnique().getWsdl().getVersion(), entete.getVersionWS());
    Assert.assertNotNull(entete.getHorodatageRequete());
    // Calculated from python :
    // import uuid
    // uuid.uuid5(uuid.uuid5(uuid.NAMESPACE_DNS, 'ravel.bouyguestelecom.fr'), '1cd9a170-bc3b-47fa-a004-359274538021')
    Assert.assertEquals("4d696150-5015-5f69-8ee5-e2f4cc91e83f", entete.getIdentifiantRequete()); //$NON-NLS-1$

    return true;
  }
}