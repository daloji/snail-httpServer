
package com.bytel.spirit.common.connector.oi.aidecommande.structs.structureverticale.etage;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

import com.bytel.spirit.common.connector.oi.aidecommande.structs.structureverticale.ligne.LigneFTTH;
import com.bytel.spirit.common.connector.oi.aidecommande.structs.structureverticale.pm.Pm;

/**
 * @author jpais
 * @version ($Revision$ $Date$)
 */
public class Etage implements Serializable
{
  /**
   *
   * @author jpais
   * @version ($Revision: 10997 $ $Date: 2018-10-01 17:27:30 +0200 (Mon, 01 Oct 2018) $)
   */
  public static final class EtageBuilder
  {
    /** Access field {@link Etage#_reference} */
    private String _reference;
    /** Access field {@link Etage#_nombreLocauxFTTH} */
    private Integer _nombreLocauxFTTH;
    /** Access field {@link Etage#_nombreLignesActives} */
    private Integer _nombreLignesActives;
    /** Access field {@link Etage#_nombreLignesExistantes} */
    private Integer _nombreLignesExistantes;
    /** Access field {@link Etage#_refPriseCommandeObligatoire} */
    private boolean _refPriseCommandeObligatoire;
    /** Access field {@link Etage#_listePbos} */
    private List<Pbo> _listePbos;
    /** Access field {@link Etage#_pm} */
    private Pm _pm;
    /** Access field {@link Etage#_listeLignesFTTHs} */
    private List<LigneFTTH> _listeLignesFTTHs;

    /**
     * Default Constructor
     */
    public EtageBuilder()
    {
      _listePbos = new ArrayList<>();
      _listeLignesFTTHs = new ArrayList<>();
    }

    /**
     * @return a built {@link Etage}
     */
    public Etage build()
    {
      Etage etage = new Etage(_reference, _nombreLignesActives, _nombreLignesExistantes, _refPriseCommandeObligatoire, _listePbos, _pm);
      etage.setNombreLocauxFTTH(_nombreLocauxFTTH);
      etage.setListeLignesFTTHs(_listeLignesFTTHs);
      return etage;
    }

    /**
     * @param listeLignesFTTHs_p
     *          ligneFTTH to add
     * @return an instance of {@link EtageBuilder}
     */
    public EtageBuilder listeLignesFTTHs(List<LigneFTTH> listeLignesFTTHs_p)
    {
      if (listeLignesFTTHs_p != null)
      {
        _listeLignesFTTHs.addAll(listeLignesFTTHs_p);
      }
      return this;
    }

    /**
     * @param listePbos_p
     *          pbos to add
     * @return an instance of {@link EtageBuilder}
     */
    public EtageBuilder listePbos(List<Pbo> listePbos_p)
    {
      if (listePbos_p != null)
      {
        _listePbos.addAll(listePbos_p);
      }
      return this;
    }

    /**
     * @param nombreLignesActives_p
     *          the reference to set
     * @return an instance of {@link EtageBuilder}
     */
    public EtageBuilder nombreLignesActives(Integer nombreLignesActives_p)
    {
      _nombreLignesActives = nombreLignesActives_p;
      return this;
    }

    /**
     * @param nombreLignesExistantes_p
     *          the reference to set
     * @return an instance of {@link EtageBuilder}
     */
    public EtageBuilder nombreLignesExistantes(Integer nombreLignesExistantes_p)
    {
      _nombreLignesExistantes = nombreLignesExistantes_p;
      return this;
    }

    /**
     * @param nombreLocauxFTTH_p
     *          the reference to set
     * @return an instance of {@link EtageBuilder}
     */
    public EtageBuilder nombreLocauxFTTH(Integer nombreLocauxFTTH_p)
    {
      _nombreLocauxFTTH = nombreLocauxFTTH_p;
      return this;
    }

    /**
     * @param pm_p
     *          the reference to set
     * @return an instance of {@link EtageBuilder}
     */
    public EtageBuilder pm(Pm pm_p)
    {
      _pm = pm_p;
      return this;
    }

    /**
     * @param refPriseCommandeObligatoire_p
     *          the reference to set
     * @return an instance of {@link EtageBuilder}
     */
    public EtageBuilder refPriseCommandeObligatoire(boolean refPriseCommandeObligatoire_p)
    {
      _refPriseCommandeObligatoire = refPriseCommandeObligatoire_p;
      return this;
    }

    /**
     * @param reference_p
     *          the reference to set
     * @return an instance of {@link EtageBuilder}
     */
    public EtageBuilder reference(String reference_p)
    {
      _reference = reference_p;
      return this;
    }
  }

  /** Serial UID */
  private static final long serialVersionUID = -5086288048922241911L;

  /**
   * Nom de l’étage tel que présent dans les bases de données de l’OI.
   */
  private String _reference;

  /**
   * Nombre de locaux FTTH référencés à l’étage par l’OI.
   */
  private Integer _nombreLocauxFTTH;

  /**
   * Nombre de lignes FTTH référencées à l’étage par l’OI réputées actives, à savoir ayant fait l’objet d’une mise en
   * service par un OC et n’ayant pas fait l’objet d’une résiliation par le même OC.
   */
  private Integer _nombreLignesActives;

  /**
   * Nombre de lignes FTTH référencées à l’étage par l’OI réputées construites.
   */
  private Integer _nombreLignesExistantes;

  /**
   * Ce champ booléen permet de préciser si l’OC est obligé de donner une référence de prise (PTO) dans sa commande
   * d’accès à cet étage pour qu’elle soit acceptée par l’OI.
   */
  private boolean _refPriseCommandeObligatoire;

  /**
   * Liste des PBO pouvant desservir l’étage.
   */
  private List<Pbo> _listePbos;

  /**
   * Ce champ permet de préciser la référence du PM, la référence éventuelle du PM Technique, le type de PM ainsi que les
   * conditions de brassages et de raccordements de l’OI.
   */
  private Pm _pm;

  /**
   * Liste des lignes FTTH à l’étage, tous statuts confondus
   */
  private List<LigneFTTH> _listeLignesFTTHs;

  /**
   * Default constructor
   * 
   * @param reference_p
   * @param nombreLignesActives_p
   * @param nombreLignesExistantes_p
   * @param refPriseCommandeObligatoire_p
   * @param listePbos_p
   * @param pm_p
   */
  public Etage(String reference_p, Integer nombreLignesActives_p, Integer nombreLignesExistantes_p, boolean refPriseCommandeObligatoire_p, List<Pbo> listePbos_p, Pm pm_p)
  {
    _reference = reference_p;
    _nombreLignesActives = nombreLignesActives_p;
    _nombreLignesExistantes = nombreLignesExistantes_p;
    _refPriseCommandeObligatoire = refPriseCommandeObligatoire_p;
    _listePbos = listePbos_p == null ? Collections.emptyList() : new ArrayList<>(listePbos_p);
    _pm = pm_p;
  }

  @Override
  public boolean equals(Object o_p)
  {
    if (this == o_p)
    {
      return true;
    }
    if (o_p == null || getClass() != o_p.getClass())
    {
      return false;
    }
    Etage etage = (Etage) o_p;
    return _refPriseCommandeObligatoire == etage._refPriseCommandeObligatoire && _reference.equals(etage._reference) && Objects.equals(_nombreLocauxFTTH, etage._nombreLocauxFTTH) && _nombreLignesActives.equals(etage._nombreLignesActives) && _nombreLignesExistantes.equals(etage._nombreLignesExistantes) && _listePbos.equals(etage._listePbos) && _pm.equals(etage._pm) && Objects.equals(_listeLignesFTTHs, etage._listeLignesFTTHs);
  }

  /**
   * @return value of listeLignesFTTHs
   */
  public List<LigneFTTH> getListeLignesFTTHs()
  {
    return _listeLignesFTTHs == null ? null : new ArrayList<>(_listeLignesFTTHs);
  }

  /**
   * @return value of listePbos
   */
  public List<Pbo> getListePbos()
  {
    return _listePbos == null ? null : new ArrayList<>(_listePbos);
  }

  /**
   * @return value of nombreLignesActives
   */
  public Integer getNombreLignesActives()
  {
    return _nombreLignesActives;
  }

  /**
   * @return value of nombreLignesExistantes
   */
  public Integer getNombreLignesExistantes()
  {
    return _nombreLignesExistantes;
  }

  /**
   * @return value of nombreLocauxFTTH
   */
  public Integer getNombreLocauxFTTH()
  {
    return _nombreLocauxFTTH;
  }

  /**
   * @return value of pm
   */
  public Pm getPm()
  {
    return _pm;
  }

  /**
   * @return value of reference
   */
  public String getReference()
  {
    return _reference;
  }

  @Override
  public int hashCode()
  {
    return Objects.hash(_reference, _nombreLocauxFTTH, _nombreLignesActives, _nombreLignesExistantes, _refPriseCommandeObligatoire, _listePbos, _pm, _listeLignesFTTHs);
  }

  /**
   * @return value of refPriseCommandeObligatoire
   */
  public boolean isRefPriseCommandeObligatoire()
  {
    return _refPriseCommandeObligatoire;
  }

  /**
   * @param listeLignesFTTHs_p
   *          The listeLignesFTTHs to set.
   */
  public void setListeLignesFTTHs(List<LigneFTTH> listeLignesFTTHs_p)
  {
    _listeLignesFTTHs = listeLignesFTTHs_p == null ? null : new ArrayList<>(listeLignesFTTHs_p);
  }

  /**
   * @param listePbos_p
   *          The listePbos to set.
   */
  public void setListePbos(List<Pbo> listePbos_p)
  {
    _listePbos = listePbos_p == null ? null : new ArrayList<>(listePbos_p);
  }

  /**
   * @param nombreLignesActives_p
   *          The nombreLignesActives to set.
   */
  public void setNombreLignesActives(Integer nombreLignesActives_p)
  {
    _nombreLignesActives = nombreLignesActives_p;
  }

  /**
   * @param nombreLignesExistantes_p
   *          The nombreLignesExistantes to set.
   */
  public void setNombreLignesExistantes(Integer nombreLignesExistantes_p)
  {
    _nombreLignesExistantes = nombreLignesExistantes_p;
  }

  /**
   * @param nombreLocauxFTTH_p
   *          The nombreLocauxFTTH to set.
   */
  public void setNombreLocauxFTTH(Integer nombreLocauxFTTH_p)
  {
    _nombreLocauxFTTH = nombreLocauxFTTH_p;
  }

  /**
   * @param pm_p
   *          The pm to set.
   */
  public void setPm(Pm pm_p)
  {
    _pm = pm_p;
  }

  /**
   * @param refPriseCommandeObligatoire_p
   *          The refPriseCommandeObligatoire to set.
   */
  public void setRefPriseCommandeObligatoire(boolean refPriseCommandeObligatoire_p)
  {
    _refPriseCommandeObligatoire = refPriseCommandeObligatoire_p;
  }

  /**
   * @param reference_p
   *          The reference to set.
   */
  public void setReference(String reference_p)
  {
    _reference = reference_p;
  }
}
