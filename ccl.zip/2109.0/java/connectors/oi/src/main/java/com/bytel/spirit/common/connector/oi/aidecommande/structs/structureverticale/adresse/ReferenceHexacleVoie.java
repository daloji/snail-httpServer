
package com.bytel.spirit.common.connector.oi.aidecommande.structs.structureverticale.adresse;

import java.io.Serializable;
import java.util.Objects;

/**
 * @author jpais
 * @version ($Revision$ $Date$)
 */
public class ReferenceHexacleVoie implements Serializable
{
  /**
   * Serial UID
   */
  private static final long serialVersionUID = -7883639871099157386L;

  /**
   * Code Hexaclé du 0 de la voie identifiant la voie et la commune sur laquelle se trouve l’adresse ciblée.
   */
  private String _codeHexacleVoie;

  /**
   * Numéro attribué à l’adresse ciblée dans la demande.
   */
  private Integer _numeroVoie;

  /**
   * Identique à ce qui est publié dans le CR MAD.
   */
  private String _complementNumeroVoie;

  /**
   * Default constructor
   * 
   * @param codeHexacleVoie_p
   * @param numeroVoie_p
   */
  public ReferenceHexacleVoie(String codeHexacleVoie_p, Integer numeroVoie_p)
  {
    _codeHexacleVoie = codeHexacleVoie_p;
    _numeroVoie = numeroVoie_p;
  }

  @Override
  public boolean equals(Object o_p)
  {
    if (this == o_p)
    {
      return true;
    }
    if (o_p == null || getClass() != o_p.getClass())
    {
      return false;
    }
    ReferenceHexacleVoie that = (ReferenceHexacleVoie) o_p;
    return _codeHexacleVoie.equals(that._codeHexacleVoie) && _numeroVoie.equals(that._numeroVoie) && Objects.equals(_complementNumeroVoie, that._complementNumeroVoie);
  }

  /**
   * @return value of codeHexacleVoie
   */
  public String getCodeHexacleVoie()
  {
    return _codeHexacleVoie;
  }

  /**
   * @return value of complementNumeroVoie
   */
  public String getComplementNumeroVoie()
  {
    return _complementNumeroVoie;
  }

  /**
   * @return value of numeroVoie
   */
  public Integer getNumeroVoie()
  {
    return _numeroVoie;
  }

  @Override
  public int hashCode()
  {
    return Objects.hash(_codeHexacleVoie, _numeroVoie, _complementNumeroVoie);
  }

  /**
   * @param codeHexacleVoie_p
   *          The codeHexacleVoie to set.
   */
  public void setCodeHexacleVoie(String codeHexacleVoie_p)
  {
    _codeHexacleVoie = codeHexacleVoie_p;
  }

  /**
   * @param complementNumeroVoie_p
   *          The complementNumeroVoie to set.
   */
  public void setComplementNumeroVoie(String complementNumeroVoie_p)
  {
    _complementNumeroVoie = complementNumeroVoie_p;
  }

  /**
   * @param numeroVoie_p
   *          The numeroVoie to set.
   */
  public void setNumeroVoie(Integer numeroVoie_p)
  {
    _numeroVoie = numeroVoie_p;
  }
}
