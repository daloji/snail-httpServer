/*******************************************************************************
* $Id: AbstractAideCommandeConnector.java 30622 2020-01-22 18:13:10Z jpais $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connector.oi.aidecommande;

import javax.ws.rs.core.MultivaluedMap;

import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.connector.oi.CodeRetour;
import com.bytel.spirit.common.connector.oi.aidecommande.structs.structureverticale.StructureReponse;
import com.bytel.spirit.common.generated.configfluxOI.ConfigFluxOI;
import com.bytel.spirit.common.shared.misc.connectors.AbstractSpiritSOAPConnector;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

/**
 * Implémentation abstraite de {@link AbstractSpiritSOAPConnector} dédiée aux connecteurs OI pour les web-services
 * d'aide à la commande.
 *
 * @author jstrub
 * @version ($Revision: 30622 $ $Date: 2020-01-22 19:13:10 +0100 (mer. 22 janv. 2020) $)
 */
public abstract class AbstractAideCommandeConnector extends AbstractSpiritSOAPConnector
{

  /** SOAP Method obtentionStructureAdresseOperation. */
  protected static final String OBTENTION_STRUCTURE_ADRESSE_SOAP_METHOD = "obtentionStructureAdresseOperation"; //$NON-NLS-1$

  @Override
  public String getConfigParameter(String connectorID_p, String paramName_p) throws RavelException
  {
    // Nothing to do
    return null;
  }

  /**
   * Recherche structure verticale selon le quadruplet
   *
   * @param tracabilite_p
   *          objet de tracabilité Spirit
   * @param config_p
   *          OI configuration
   * @param codeInsee_p
   *          code INSEE
   * @param codeRivoli_p
   *          code Rivoli
   * @param numeroVoie_p
   *          numero de Voie
   * @param complementNumeroVoie_p
   *          complement numero de voie facultatif
   * @param headers_p
   *          The headers added to the request.
   * @return représentation interne d'une {@link StructureReponse} et {@link CodeRetour} associé à la réponse
   * @throws RavelException
   *           exception lors de l'échange SOAP
   */
  public abstract ConnectorResponse<StructureReponse, CodeRetour> obtenirStructureVerticale(Tracabilite tracabilite_p, ConfigFluxOI config_p, String codeInsee_p, String codeRivoli_p, Integer numeroVoie_p, String complementNumeroVoie_p, MultivaluedMap<String, String> headers_p) throws RavelException;

  /**
   * Recherche structure verticale selon l'hexacle
   *
   * @param tracabilite_p
   *          objet de tracabilité Spirit
   * @param config_p
   *          OI configuration
   * @param hexacle_p
   *          hexacle
   * @param headers_p
   *          The headers added to the request.
   * @return représentation interne d'une {@link StructureReponse} et {@link CodeRetour} associé à la réponse
   * @throws RavelException
   *           exception lors de l'échange SOAP
   */
  public abstract ConnectorResponse<StructureReponse, CodeRetour> obtenirStructureVerticaleByHexacle(Tracabilite tracabilite_p, ConfigFluxOI config_p, String hexacle_p, MultivaluedMap<String, String> headers_p) throws RavelException;

  /**
   * Recherche structure verticale selon l'IMB
   *
   * @param tracabilite_p
   *          objet de tracabilité Spirit
   * @param config_p
   *          OI configuration
   * @param imb_p
   *          IMB
   * @param headers_p
   *          The headers added to the request.
   * @return représentation interne d'une {@link StructureReponse} et {@link CodeRetour} associé à la réponse
   * @throws RavelException
   *           exception lors de l'échange SOAP
   */
  public abstract ConnectorResponse<StructureReponse, CodeRetour> obtenirStructureVerticaleByIMB(Tracabilite tracabilite_p, ConfigFluxOI config_p, String imb_p, MultivaluedMap<String, String> headers_p) throws RavelException;

  /**
   * Recherche structure verticale selon l'Reference PTO
   *
   * @param tracabilite_p
   *          objet de tracabilité Spirit
   * @param config_p
   *
   *          OI configuration
   * @param referencePTO_p
   *          Reference PTO
   * @param headers_p
   *          The headers added to the request.
   * @return représentation interne d'une {@link StructureReponse} et {@link CodeRetour} associé à la réponse
   * @throws RavelException
   *           exception lors de l'échange SOAP
   */
  public abstract ConnectorResponse<StructureReponse, CodeRetour> obtenirStructureVerticaleByPTO(Tracabilite tracabilite_p, ConfigFluxOI config_p, String referencePTO_p, MultivaluedMap<String, String> headers_p) throws RavelException;

}
