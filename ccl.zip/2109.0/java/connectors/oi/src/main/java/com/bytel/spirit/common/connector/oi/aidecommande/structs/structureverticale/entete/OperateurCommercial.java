
package com.bytel.spirit.common.connector.oi.aidecommande.structs.structureverticale.entete;

import java.io.Serializable;
import java.util.Objects;

/**
 * @author jpais
 * @version ($Revision$ $Date$)
 */
public class OperateurCommercial implements Serializable
{
  /** Serial UID */
  private static final long serialVersionUID = 6208696496738532796L;

  /**
   * Le nom de l’OC attendu sera défini par l’OI dans son contrat d’interface.
   */
  private String _nom;

  /**
   * Identifiant de l’OC. Nombre d’occurrences de ce champ ≥ 0.
   */
  private String _identifiant;

  /**
   * Default constructor
   * 
   * @param nom_p
   */
  public OperateurCommercial(String nom_p)
  {
    _nom = nom_p;
  }

  @Override
  public boolean equals(Object o_p)
  {
    if (this == o_p)
    {
      return true;
    }
    if (o_p == null || getClass() != o_p.getClass())
    {
      return false;
    }
    OperateurCommercial that = (OperateurCommercial) o_p;
    return _nom.equals(that._nom) && Objects.equals(_identifiant, that._identifiant);
  }

  /**
   * @return value of identifiant
   */
  public String getIdentifiant()
  {
    return _identifiant;
  }

  /**
   * @return value of nom
   */
  public String getNom()
  {
    return _nom;
  }

  @Override
  public int hashCode()
  {
    return Objects.hash(_nom, _identifiant);
  }

  /**
   * @param identifiant_p
   *          The identifiant to set.
   */
  public void setIdentifiant(String identifiant_p)
  {
    _identifiant = identifiant_p;
  }

  /**
   * @param nom_p
   *          The nom to set.
   */
  public void setNom(String nom_p)
  {
    _nom = nom_p;
  }
}
