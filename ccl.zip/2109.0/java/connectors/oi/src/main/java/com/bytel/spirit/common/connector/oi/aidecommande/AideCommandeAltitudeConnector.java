/*******************************************************************************
* $Id: AideCommandeAltitudeConnector.java 49850 2021-03-25 18:34:34Z jjoly $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connector.oi.aidecommande;

import static java.util.Objects.nonNull;

import java.io.Serializable;
import java.math.BigInteger;
import java.text.MessageFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.core.MultivaluedMap;
import javax.xml.bind.JAXBElement;

import org.apache.commons.collections4.CollectionUtils;

import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.services.conf.connector.generated.Connector;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.connector.oi.CodeRetour;
import com.bytel.spirit.common.connector.oi.CodeRetour.CodeRetourConsts;
import com.bytel.spirit.common.connector.oi.Messages;
import com.bytel.spirit.common.connector.oi.aidecommande.structs.structureverticale.StructureReponse;
import com.bytel.spirit.common.connector.oi.aidecommande.structs.structureverticale.StructureReponse.StructureReponseBuilder;
import com.bytel.spirit.common.connector.oi.aidecommande.structs.structureverticale.adresse.ReferenceAdresseReponse;
import com.bytel.spirit.common.connector.oi.aidecommande.structs.structureverticale.adresse.ReferenceHexacleVoie;
import com.bytel.spirit.common.connector.oi.aidecommande.structs.structureverticale.adresse.ReferenceRivoli;
import com.bytel.spirit.common.connector.oi.aidecommande.structs.structureverticale.batiment.Batiment;
import com.bytel.spirit.common.connector.oi.aidecommande.structs.structureverticale.batiment.Batiment.BatimentBuilder;
import com.bytel.spirit.common.connector.oi.aidecommande.structs.structureverticale.batiment.CoordonneesGeographiques;
import com.bytel.spirit.common.connector.oi.aidecommande.structs.structureverticale.batiment.EtatBatiment;
import com.bytel.spirit.common.connector.oi.aidecommande.structs.structureverticale.escalier.Escalier;
import com.bytel.spirit.common.connector.oi.aidecommande.structs.structureverticale.escalier.Escalier.EscalierBuilder;
import com.bytel.spirit.common.connector.oi.aidecommande.structs.structureverticale.etage.Etage;
import com.bytel.spirit.common.connector.oi.aidecommande.structs.structureverticale.etage.Etage.EtageBuilder;
import com.bytel.spirit.common.connector.oi.aidecommande.structs.structureverticale.etage.Pbo;
import com.bytel.spirit.common.connector.oi.aidecommande.structs.structureverticale.ligne.LigneFTTH;
import com.bytel.spirit.common.connector.oi.aidecommande.structs.structureverticale.ligne.Local;
import com.bytel.spirit.common.connector.oi.aidecommande.structs.structureverticale.ligne.Prise;
import com.bytel.spirit.common.connector.oi.aidecommande.structs.structureverticale.ligne.StatutLigneFTTH;
import com.bytel.spirit.common.connector.oi.aidecommande.structs.structureverticale.pm.Brassage;
import com.bytel.spirit.common.connector.oi.aidecommande.structs.structureverticale.pm.EmplacementPm;
import com.bytel.spirit.common.connector.oi.aidecommande.structs.structureverticale.pm.Pm;
import com.bytel.spirit.common.generated.configfluxOI.ConfigFluxOI;
import com.bytel.spirit.common.generated.ws.ftth.aidecommande.altitude.BatimentType;
import com.bytel.spirit.common.generated.ws.ftth.aidecommande.altitude.EnteteRequeteType;
import com.bytel.spirit.common.generated.ws.ftth.aidecommande.altitude.EscalierType;
import com.bytel.spirit.common.generated.ws.ftth.aidecommande.altitude.EtageType;
import com.bytel.spirit.common.generated.ws.ftth.aidecommande.altitude.LigneFTTHListeType;
import com.bytel.spirit.common.generated.ws.ftth.aidecommande.altitude.LigneFTTHType;
import com.bytel.spirit.common.generated.ws.ftth.aidecommande.altitude.ListePboType;
import com.bytel.spirit.common.generated.ws.ftth.aidecommande.altitude.LocalType;
import com.bytel.spirit.common.generated.ws.ftth.aidecommande.altitude.ObtentionStructureAdresseDemandeSoap;
import com.bytel.spirit.common.generated.ws.ftth.aidecommande.altitude.ObtentionStructureAdresseReponseSoap;
import com.bytel.spirit.common.generated.ws.ftth.aidecommande.altitude.ObtentionStructureAdresseWSDLPortType;
import com.bytel.spirit.common.generated.ws.ftth.aidecommande.altitude.OperateurCommercialType;
import com.bytel.spirit.common.generated.ws.ftth.aidecommande.altitude.PboType;
import com.bytel.spirit.common.generated.ws.ftth.aidecommande.altitude.PriseType;
import com.bytel.spirit.common.generated.ws.ftth.aidecommande.altitude.ReferenceAdresseDemandeType;
import com.bytel.spirit.common.generated.ws.ftth.aidecommande.altitude.ReferenceHexacleVoieType;
import com.bytel.spirit.common.generated.ws.ftth.aidecommande.altitude.ReferenceRivoliType;
import com.bytel.spirit.common.generated.ws.ftth.aidecommande.altitude.StatutLigneFTTHType;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

/**
 * Implémentation concrète de {@link AbstractAideCommandeConnector} dédiée au connecteur OI pour les web-services d'aide
 * à la commande spécifique au partenaire Altitude.
 *
 * @author jstrub
 * @version ($Revision: 49850 $ $Date: 2021-03-25 19:34:34 +0100 (jeu. 25 mars 2021) $)
 */
public final class AideCommandeAltitudeConnector extends AbstractAideCommandeConnector
{

  @Override
  public void loadConnectorConfiguration(Connector connector_p) throws RavelException
  {
    // Configuration CXF
    setServiceInterfaceClass(ObtentionStructureAdresseWSDLPortType.class);
    super.loadConnectorConfiguration(connector_p);
  }

  @Override
  public ConnectorResponse<StructureReponse, CodeRetour> obtenirStructureVerticale(Tracabilite tracabilite_p, ConfigFluxOI config_p, String codeInsee_p, String codeRivoli_p, Integer numeroVoie_p, String complementNumeroVoie_p, MultivaluedMap<String, String> headers_p) throws RavelException
  {
    ReferenceRivoliType rivoli = new ReferenceRivoliType();
    rivoli.setCodeInsee(codeInsee_p);
    rivoli.setCodeRivoli(codeRivoli_p);
    rivoli.setNumeroVoie(BigInteger.valueOf(numeroVoie_p));
    if (complementNumeroVoie_p != null)
    {
      rivoli.setComplementNumeroVoie(complementNumeroVoie_p);
    }

    ReferenceAdresseDemandeType reference = new ReferenceAdresseDemandeType();
    reference.setReferenceRivoli(rivoli);

    ObtentionStructureAdresseDemandeSoap request = new ObtentionStructureAdresseDemandeSoap();
    request.setEntete(createEntete(config_p));
    request.setReferenceAdresse(reference);

    return obtenirStructureVerticale(tracabilite_p, request, headers_p);
  }

  @Override
  public ConnectorResponse<StructureReponse, CodeRetour> obtenirStructureVerticaleByHexacle(Tracabilite tracabilite_p, ConfigFluxOI config_p, String hexacle_p, MultivaluedMap<String, String> headers_p) throws RavelException
  {
    ReferenceAdresseDemandeType reference = new ReferenceAdresseDemandeType();
    reference.setReferenceHexacle(hexacle_p);

    ObtentionStructureAdresseDemandeSoap request = new ObtentionStructureAdresseDemandeSoap();
    request.setEntete(createEntete(config_p));
    request.setReferenceAdresse(reference);

    return obtenirStructureVerticale(tracabilite_p, request, headers_p);
  }

  @Override
  public ConnectorResponse<StructureReponse, CodeRetour> obtenirStructureVerticaleByIMB(Tracabilite tracabilite_p, ConfigFluxOI config_p, String imb_p, MultivaluedMap<String, String> headers_p) throws RavelException
  {
    ReferenceAdresseDemandeType reference = new ReferenceAdresseDemandeType();
    reference.setIdentifiantImmeuble(imb_p);

    ObtentionStructureAdresseDemandeSoap request = new ObtentionStructureAdresseDemandeSoap();
    request.setEntete(createEntete(config_p));
    request.setReferenceAdresse(reference);

    return obtenirStructureVerticale(tracabilite_p, request, headers_p);
  }

  @Override
  public ConnectorResponse<StructureReponse, CodeRetour> obtenirStructureVerticaleByPTO(Tracabilite tracabilite_p, ConfigFluxOI config_p, String referencePTO_p, MultivaluedMap<String, String> headers_p) throws RavelException
  {
    ReferenceAdresseDemandeType reference = new ReferenceAdresseDemandeType();
    reference.setReferencePTO(referencePTO_p);

    ObtentionStructureAdresseDemandeSoap request = new ObtentionStructureAdresseDemandeSoap();
    request.setEntete(createEntete(config_p));
    request.setReferenceAdresse(reference);

    return obtenirStructureVerticale(tracabilite_p, request, headers_p);
  }

  /**
   * Cree l'entete SOAP à partir de la configuration OI.
   *
   * @param config_p
   *          OI configuration
   * @return entete emutation
   */
  private EnteteRequeteType createEntete(ConfigFluxOI config_p)
  {
    EnteteRequeteType entete = new EnteteRequeteType();
    entete.setHorodatageRequete(LocalDateTime.now());

    OperateurCommercialType oc = new OperateurCommercialType();
    oc.setNom(config_p.getConnexionTechnique().getIdentite().getNom());
    oc.setIdentifiant(config_p.getConnexionTechnique().getIdentite().getIdentifiant());
    entete.setOperateurCommercial(oc);

    entete.setVersionWS(config_p.getConnexionTechnique().getWsdl().getVersion());

    return entete;
  }

  /**
   * Déclenchement de l'appel et mapping de la réponse SOAP vers structure interne.
   *
   * @param tracabilite_p
   *          objet de tracabilité
   * @param request_p
   *          requete SOAP
   * @param headers_p
   *          The headers added to the request.
   * @return représentation interne d'une {@link StructureReponse} et {@link CodeRetour} associé à la réponse
   * @throws RavelException
   *           exception lors de l'échange SOAP
   */
  private ConnectorResponse<StructureReponse, CodeRetour> obtenirStructureVerticale(Tracabilite tracabilite_p, ObtentionStructureAdresseDemandeSoap request_p, MultivaluedMap<String, String> headers_p) throws RavelException
  {
    ObtentionStructureAdresseReponseSoap response = sendRequest(tracabilite_p, OBTENTION_STRUCTURE_ADRESSE_SOAP_METHOD, null, null, headers_p, null, request_p);
    CodeRetour retour = new CodeRetour(CodeRetourConsts.OK);
    if (response.getCodeRetour() != null)
    {
      retour = new CodeRetour(response.getCodeRetour().getCodeRetour(), response.getCodeRetour().getCodeErreur(), response.getCodeRetour().getLibelleErreur());
    }

    // Build reference adresse
    ReferenceAdresseReponse referenceAdresseReponse = null;
    if (nonNull(response.getStructureDetaillee()) && //
        nonNull(response.getStructureDetaillee().getAdresse()))
    {
      referenceAdresseReponse = new ReferenceAdresseReponse();
      referenceAdresseReponse.setReferenceHexacle(response.getStructureDetaillee().getAdresse().getReferenceHexacle());

      if (CollectionUtils.isNotEmpty(response.getStructureDetaillee().getAdresse().getReferenceRivolisAndReferenceHexacleVoies()))
      {
        for (Serializable reference : response.getStructureDetaillee().getAdresse().getReferenceRivolisAndReferenceHexacleVoies())
        {
          if (reference instanceof ReferenceRivoliType)
          {
            // Build reference Rivoli
            ReferenceRivoli referenceRivoli = new ReferenceRivoli(((ReferenceRivoliType) reference).getCodeInsee(), //
                ((ReferenceRivoliType) reference).getCodeRivoli(), //
                ((ReferenceRivoliType) reference).getNumeroVoie().intValue());
            referenceAdresseReponse.setReferenceRivoli(referenceRivoli);
          }
          else if (reference instanceof ReferenceHexacleVoieType)
          {
            // Build reference Hexacle Voie
            ReferenceHexacleVoie referenceHexacleVoie = new ReferenceHexacleVoie(((ReferenceHexacleVoieType) reference).getCodeHexacleVoie(), //
                ((ReferenceHexacleVoieType) reference).getNumeroVoie().intValue());
            referenceAdresseReponse.setReferenceHexacleVoie(referenceHexacleVoie);
          }
        }
      }
    }

    // Build batiments
    List<Batiment> batiments = new ArrayList<>();
    if (response.getStructureDetaillee() != null)
    {
      for (BatimentType batimentSoap : response.getStructureDetaillee().getBatiments())
      {
        List<Escalier> escaliers = new ArrayList<>();
        for (EscalierType escalierSoap : batimentSoap.getEscaliers())
        {
          List<Etage> etages = new ArrayList<>();
          for (EtageType etageSoap : escalierSoap.getEtages())
          {
            // Build Pbo list
            List<Pbo> pbos = null;
            if (CollectionUtils.isNotEmpty(etageSoap.getListePbos()))
            {
              pbos = new ArrayList<>();

              for (ListePboType listePboType : etageSoap.getListePbos())
              {
                for (PboType pboType : listePboType.getPbos())
                {
                  Pbo pbo = new Pbo(pboType.getReferencePBO());
                  pbo.setTypePbo(pboType.getTypePbo());
                  pbo.setTypeRaccoPbPTO(pboType.getTypeRaccoPbPTO());
                  pbos.add(pbo);
                }
              }
            }

            // Build Pm
            Pm pm = null;
            if (etageSoap.getPm() != null)
            {
              pm = new Pm(etageSoap.getPm().getReferencePM(), //
                  etageSoap.getPm().getReferencePMT(), //
                  EmplacementPm.valueOf(etageSoap.getPm().getTypeEmplacementPM() != null ? etageSoap.getPm().getTypeEmplacementPM().value() : EmplacementPm.PME.name()), //
                  Brassage.valueOf(etageSoap.getPm().getResponsableBrassage() != null ? etageSoap.getPm().getResponsableBrassage().value() : Brassage.OI.name()));

              if (etageSoap.getPm().getTypeEmplacementPM() == null)
              {
                RavelLogger.log(new SpiritLogEvent(LogSeverity.INFO, tracabilite_p, MessageFormat.format(Messages.getString("AideCommandeConnector.defaultEmplacementPmType"), etageSoap.getPm().getReferencePM())));
              }
              if (etageSoap.getPm().getResponsableBrassage() == null)
              {
                RavelLogger.log(new SpiritLogEvent(LogSeverity.INFO, tracabilite_p, MessageFormat.format(Messages.getString("AideCommandeConnector.defaultBrassage"), etageSoap.getPm().getReferencePM())));
              }
            }

            // Build LignesFtth list
            List<LigneFTTH> ligneFTTHS = null;
            if (CollectionUtils.isNotEmpty(etageSoap.getListeLignesFTTHs()))
            {
              ligneFTTHS = new ArrayList<>();

              for (LigneFTTHListeType ligneFTTHListeType : etageSoap.getListeLignesFTTHs())
              {
                for (LigneFTTHType ligneFTTHType : ligneFTTHListeType.getLigneFTTHs())
                {
                  // Build Prise
                  Prise prise = null;
                  // Build Local
                  Local local = null;

                  if (CollectionUtils.isNotEmpty(ligneFTTHType.getPrisesAndLocals()))
                  {
                    for (Serializable prisesAndLocal : ligneFTTHType.getPrisesAndLocals())
                    {
                      if (prisesAndLocal instanceof PriseType)
                      {
                        prise = new Prise();

                        for (JAXBElement<?> ptosAndStatutsAndPrisePromoteur : ((PriseType) prisesAndLocal).getReferencePTOsAndStatutLigneFTTHsAndReferencePrisePromoteurs())
                        {
                          if (ptosAndStatutsAndPrisePromoteur.getName() != null)
                          {
                            if ("referencePTO".equals(ptosAndStatutsAndPrisePromoteur.getName().getLocalPart())) //$NON-NLS-1$
                            {
                              prise.setReferencePTO((String) ptosAndStatutsAndPrisePromoteur.getValue());
                            }
                            if ("referencePrisePromoteur".equals(ptosAndStatutsAndPrisePromoteur.getName().getLocalPart())) //$NON-NLS-1$
                            {
                              prise.setReferencePrisePromoteur((String) ptosAndStatutsAndPrisePromoteur.getValue());
                            }
                            if ("statutLigneFTTH".equals(ptosAndStatutsAndPrisePromoteur.getName().getLocalPart())) //$NON-NLS-1$
                            {
                              StatutLigneFTTHType statutLigneFTTHType = (StatutLigneFTTHType) ptosAndStatutsAndPrisePromoteur.getValue();
                              StatutLigneFTTH statutLigneFTTH = new StatutLigneFTTH(statutLigneFTTHType.isExistant(), statutLigneFTTHType.isRaccordable(), statutLigneFTTHType.isCommercialisable(), statutLigneFTTHType.isActif(), statutLigneFTTHType.isRompu());
                              prise.setStatutLigneFTTH(statutLigneFTTH);
                            }
                          }
                        }

                        prise.setEtiquetteAPoser(((PriseType) prisesAndLocal).getEtiquetteAPoser());
                        prise.setReferencePBO(((PriseType) prisesAndLocal).getReferencePBO());
                      }
                      else if (prisesAndLocal instanceof LocalType)
                      {
                        local = new Local();
                        local.setLocalisationLocalOC(((LocalType) prisesAndLocal).getLocalisationLocalOC());
                        local.setLocalisationLocalOI(((LocalType) prisesAndLocal).getLocalisationLocalOI());
                      }
                    }

                  }
                  if (prise != null)
                  {
                    ligneFTTHS.add(new LigneFTTH(prise, local));
                  }
                }
              }
            }

            Etage etage = new EtageBuilder()//
                .reference(etageSoap.getReference())//
                .nombreLocauxFTTH(etageSoap.getNombreLocauxFTTH() != null ? etageSoap.getNombreLocauxFTTH().intValue() : null)//
                .nombreLignesActives(etageSoap.getNombreLignesActives() != null ? etageSoap.getNombreLignesActives().intValue() : null)//
                .nombreLignesExistantes(etageSoap.getNombreLignesExistantes() != null ? etageSoap.getNombreLignesExistantes().intValue() : null)//
                .refPriseCommandeObligatoire(etageSoap.isRefPriseCommandeObligatoire()) //
                .listePbos(pbos)//
                .pm(pm)//
                .listeLignesFTTHs(ligneFTTHS)//
                .build();
            etages.add(etage);
          }
          // Build Escaliers
          escaliers.add(new EscalierBuilder().reference(escalierSoap.getReference()).etages(etages).build());
        }

        // Build CoordonneesGeographiques
        CoordonneesGeographiques coordonneesGeographiques = null;
        if (batimentSoap.getReferenceGeographique() != null)
        {
          coordonneesGeographiques = new CoordonneesGeographiques();
          coordonneesGeographiques.setTypeProjection(batimentSoap.getReferenceGeographique().getTypeProjection());
          coordonneesGeographiques.setCoordonneeImmeubleX(batimentSoap.getReferenceGeographique().getCoordonneeImmeubleX());
          coordonneesGeographiques.setCoordonneeImmeubleY(batimentSoap.getReferenceGeographique().getCoordonneeImmeubleY());
        }
        // Build Batiments
        batiments.add(new BatimentBuilder()//
            .referenceBatiment(batimentSoap.getReferenceBatiment())//
            .referenceGeographique(coordonneesGeographiques)//
            .referenceBAN(batimentSoap.getReferenceBAN())//
            .identifiantImmeuble(batimentSoap.getIdentifiantImmeuble())//
            .nombreLogementsImmeuble(batimentSoap.getNombreLogementsImmeuble() != null ? batimentSoap.getNombreLogementsImmeuble().intValue() : null)//
            .etatBatiment(batimentSoap.getEtatBatiment() != null ? EtatBatiment.fromValue(batimentSoap.getEtatBatiment().value()) : null)//
            .conditionsSyndic(batimentSoap.getConditionsSyndic())//
            .dateDebutAcceptationCmdAcces(batimentSoap.getDateDebutAcceptationCmdAcces() != null ? batimentSoap.getDateDebutAcceptationCmdAcces().toLocalDate() : null)//
            .dateDebutFournitureCRCmdAcces(batimentSoap.getDateDebutFournitureCRCmdAcces() != null ? batimentSoap.getDateDebutFournitureCRCmdAcces().toLocalDate() : null)//
            .escaliers(escaliers)//
            .build());
      }
    }

    return new ConnectorResponse<>(new StructureReponseBuilder().adresse(referenceAdresseReponse).batiments(batiments).build(), retour);
  }

}
