
package com.bytel.spirit.common.connector.oi.aidecommande.structs.structureverticale.ligne;

import java.io.Serializable;
import java.util.Objects;

/**
 * @author jpais
 * @version ($Revision$ $Date$)
 */
public class LigneFTTH implements Serializable
{
  /** Serial UID */
  private static final long serialVersionUID = -3597496033722118069L;

  /**
   * Informations relatives à la prise
   */
  private Prise _prise;

  /**
   * Informations relatives au local
   */
  private Local _local;

  /**
   * Default constructor
   * 
   * @param prise_p
   * @param local_p
   */
  public LigneFTTH(Prise prise_p, Local local_p)
  {
    _prise = prise_p;
    _local = local_p;
  }

  @Override
  public boolean equals(Object o_p)
  {
    if (this == o_p)
    {
      return true;
    }
    if (o_p == null || getClass() != o_p.getClass())
    {
      return false;
    }
    LigneFTTH that = (LigneFTTH) o_p;
    return Objects.equals(_prise, that._prise) && Objects.equals(_local, that._local);
  }

  /**
   * @return value of locals
   */
  public Local getLocal()
  {
    return _local;
  }

  /**
   * @return value of prises
   */
  public Prise getPrise()
  {
    return _prise;
  }

  @Override
  public int hashCode()
  {
    return Objects.hash(_prise, _local);
  }

  /**
   * @param local_p
   *          The locals to set.
   */
  public void setLocal(Local local_p)
  {
    _local = local_p;
  }

  /**
   * @param prise_p
   *          The prises to set.
   */
  public void setPrise(Prise prise_p)
  {
    _prise = prise_p;
  }
}
