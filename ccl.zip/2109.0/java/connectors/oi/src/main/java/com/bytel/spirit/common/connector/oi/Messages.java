/*******************************************************************************
 * $Id:
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connector.oi;

import java.util.MissingResourceException;
import java.util.ResourceBundle;

/**
 *
 * @author jjoly
 * @version ($Revision: 10997 $ $Date: 2018-10-01 17:27:30 +0200 (lun. 01 oct. 2018) $)
 */
public final class Messages
{
  /**
   * Bundle name.
   */
  private static final String BUNDLE_NAME = "com.bytel.spirit.common.connector.oi.messages"; //$NON-NLS-1$

  /**
   * Resources bundle.
   */
  private static final ResourceBundle RESOURCE_BUNDLE = ResourceBundle.getBundle(Messages.BUNDLE_NAME);

  /**
   * Gets a message for a key.
   *
   * @param key
   *          key of the message to get
   * @return a message
   */
  public static String getString(String key)
  {
    try
    {
      return Messages.RESOURCE_BUNDLE.getString(key);
    }
    catch (MissingResourceException e)
    {
      return '!' + key + '!';
    }
  }

  /**
   * Default constructor
   */
  private Messages()
  {
    // Nothing to do
  }
}
