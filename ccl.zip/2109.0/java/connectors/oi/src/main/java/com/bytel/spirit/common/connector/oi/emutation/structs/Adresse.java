/*******************************************************************************
* $Id: Adresse.java 11074 2018-10-03 10:03:43Z jstrub $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connector.oi.emutation.structs;

/**
 *
 * @author jstrub
 * @version ($Revision: 11074 $ $Date: 2018-10-03 12:03:43 +0200 (mer. 03 oct. 2018) $)
 */
public final class Adresse
{

  /**
   * Builder to build {@link Adresse}.
   */
  public static final class AdresseBuilder
  {

    /** The references adresse. */
    private ReferencesAdresse _referencesAdresse;
    /** The code postal. */
    private String _codePostal;
    /** The commune. */
    private String _commune;
    /** The type voie. */
    private String _typeVoie;
    /** The libelle voie. */
    private String _libelleVoie;
    /** The numero voie. */
    private String _numeroVoie;
    /** The complement numero. */
    private String _complementNumero;

    /**
     * Builder method of the builder.
     *
     * @return built class
     */
    public Adresse build()
    {
      return new Adresse(_referencesAdresse, _codePostal, _commune, _typeVoie, _libelleVoie, _numeroVoie, _complementNumero);
    }

    /**
     * Builder method for _codePostal parameter.
     *
     * @param codePostal_p
     *          field to set
     * @return builder
     */
    public AdresseBuilder codePostal(String codePostal_p)
    {
      this._codePostal = codePostal_p;
      return this;
    }

    /**
     * Builder method for _commune parameter.
     *
     * @param commune_p
     *          field to set
     * @return builder
     */
    public AdresseBuilder commune(String commune_p)
    {
      this._commune = commune_p;
      return this;
    }

    /**
     * Builder method for _complementNumero parameter.
     *
     * @param complementNumero_p
     *          field to set
     * @return builder
     */
    public AdresseBuilder complementNumero(String complementNumero_p)
    {
      this._complementNumero = complementNumero_p;
      return this;
    }

    /**
     * Builder method for _libelleVoie parameter.
     *
     * @param libelleVoie_p
     *          field to set
     * @return builder
     */
    public AdresseBuilder libelleVoie(String libelleVoie_p)
    {
      this._libelleVoie = libelleVoie_p;
      return this;
    }

    /**
     * Builder method for _numeroVoie parameter.
     *
     * @param numeroVoie_p
     *          field to set
     * @return builder
     */
    public AdresseBuilder numeroVoie(String numeroVoie_p)
    {
      this._numeroVoie = numeroVoie_p;
      return this;
    }

    /**
     * Builder method for _referencesAdresse parameter.
     *
     * @param referencesAdresse_p
     *          field to set
     * @return builder
     */
    public AdresseBuilder referencesAdresse(ReferencesAdresse referencesAdresse_p)
    {
      this._referencesAdresse = referencesAdresse_p;
      return this;
    }

    /**
     * Builder method for _typeVoie parameter.
     *
     * @param typeVoie_p
     *          field to set
     * @return builder
     */
    public AdresseBuilder typeVoie(String typeVoie_p)
    {
      this._typeVoie = typeVoie_p;
      return this;
    }
  }

  /** The references adresse. */
  private final ReferencesAdresse _referencesAdresse;
  /** The code postal. */
  private final String _codePostal;
  /** The commune. */
  private final String _commune;
  /** The type voie. */
  private final String _typeVoie;
  /** The libelle voie. */
  private final String _libelleVoie;
  /** The numero voie. */
  private final String _numeroVoie;
  /** The complement numero. */
  private final String _complementNumero;

  /**
   * @param referencesAdresse_p
   *          the referencesAdresse
   * @param codePostal_p
   *          the codePostal
   * @param commune_p
   *          the commune
   * @param typeVoie_p
   *          the typeVoie
   * @param libelleVoie_p
   *          the libelleVoie
   * @param numeroVoie_p
   *          the numeroVoie
   * @param complementNumero_p
   *          the complementNumero
   */
  public Adresse(ReferencesAdresse referencesAdresse_p, String codePostal_p, String commune_p, String typeVoie_p, String libelleVoie_p, String numeroVoie_p, String complementNumero_p)
  {
    _referencesAdresse = referencesAdresse_p;
    _codePostal = codePostal_p;
    _commune = commune_p;
    _typeVoie = typeVoie_p;
    _libelleVoie = libelleVoie_p;
    _numeroVoie = numeroVoie_p;
    _complementNumero = complementNumero_p;
  }

  /**
   * @return the codePostal
   */
  public String getCodePostal()
  {
    return _codePostal;
  }

  /**
   * @return the commune
   */
  public String getCommune()
  {
    return _commune;
  }

  /**
   * @return the complementNumero
   */
  public String getComplementNumero()
  {
    return _complementNumero;
  }

  /**
   * @return the libelleVoie
   */
  public String getLibelleVoie()
  {
    return _libelleVoie;
  }

  /**
   * @return the numeroVoie
   */
  public String getNumeroVoie()
  {
    return _numeroVoie;
  }

  /**
   * @return the referencesAdresse
   */
  public ReferencesAdresse getReferencesAdresse()
  {
    return _referencesAdresse;
  }

  /**
   * @return the typeVoie
   */
  public String getTypeVoie()
  {
    return _typeVoie;
  }

}
