/*******************************************************************************
* $Id: PositionPM.java 11545 2018-10-12 14:12:21Z mfreire $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connector.oi.emutation.structs;

/**
 *
 * @author jstrub
 * @version ($Revision: 11545 $ $Date: 2018-10-12 16:12:21 +0200 (ven. 12 oct. 2018) $)
 */
public class PositionPM
{
  /**
   * Builder to build {@link PositionPM}.
   */
  public static final class PositionPMBuilder
  {

    /** The nomModulePM. */
    private String _nomModulePM;
    /** The positionModulePM. */
    private String _positionModulePM;
    /** The referenceCableModulePM. */
    private String _referenceCableModulePM;
    /** The infoTubeModulePM. */
    private String _infoTubeModulePM;
    /** The infoFibreModulePM. */
    private String _infoFibreModulePM;

    /**
     * Builder method of the builder.
     *
     * @return built class
     */
    public PositionPM build()
    {
      return new PositionPM(_nomModulePM, _positionModulePM, _referenceCableModulePM, _infoTubeModulePM, _infoFibreModulePM);
    }

    /**
     * Builder method for _infoFibreModulePM parameter.
     *
     * @param infoFibreModulePM_p
     *          field to set
     * @return builder
     */
    public PositionPMBuilder infoFibreModulePM(String infoFibreModulePM_p)
    {
      this._infoFibreModulePM = infoFibreModulePM_p;
      return this;
    }

    /**
     * Builder method for _infoTubeModulePM parameter.
     *
     * @param infoTubeModulePM_p
     *          field to set
     * @return builder
     */
    public PositionPMBuilder infoTubeModulePM(String infoTubeModulePM_p)
    {
      this._infoTubeModulePM = infoTubeModulePM_p;
      return this;
    }

    /**
     * Builder method for _nomModulePM parameter.
     *
     * @param nomModulePM_p
     *          field to set
     * @return builder
     */
    public PositionPMBuilder nomModulePM(String nomModulePM_p)
    {
      this._nomModulePM = nomModulePM_p;
      return this;
    }

    /**
     * Builder method for _positionModulePM parameter.
     *
     * @param positionModulePM_p
     *          field to set
     * @return builder
     */
    public PositionPMBuilder positionModulePM(String positionModulePM_p)
    {
      this._positionModulePM = positionModulePM_p;
      return this;
    }

    /**
     * Builder method for _referenceCableModulePM parameter.
     *
     * @param referenceCableModulePM_p
     *          field to set
     * @return builder
     */
    public PositionPMBuilder referenceCableModulePM(String referenceCableModulePM_p)
    {
      this._referenceCableModulePM = referenceCableModulePM_p;
      return this;
    }
  }

  /** The nomModulePM. */
  private final String _nomModulePM;
  /** The positionModulePM. */
  private final String _positionModulePM;
  /** The referenceCableModulePM. */
  private final String _referenceCableModulePM;
  /** The infoTubeModulePM. */
  private final String _infoTubeModulePM;
  /** The infoFibreModulePM. */
  private final String _infoFibreModulePM;

  /**
   * @param nomModulePM_p
   *          the nomModulePM
   * @param positionModulePM_p
   *          the positionModulePM
   * @param referenceCableModulePM_p
   *          the referenceCableModulePM
   * @param infoTubeModulePM_p
   *          the infoTubeModulePM
   * @param infoFibreModulePM_p
   *          the infoFibreModulePM
   */
  public PositionPM(String nomModulePM_p, String positionModulePM_p, String referenceCableModulePM_p, String infoTubeModulePM_p, String infoFibreModulePM_p)
  {
    _nomModulePM = nomModulePM_p;
    _positionModulePM = positionModulePM_p;
    _referenceCableModulePM = referenceCableModulePM_p;
    _infoTubeModulePM = infoTubeModulePM_p;
    _infoFibreModulePM = infoFibreModulePM_p;
  }

  /**
   * @return the infoFibreModulePM
   */
  public String getInfoFibreModulePM()
  {
    return _infoFibreModulePM;
  }

  /**
   * @return the infoTubeModulePM
   */
  public String getInfoTubeModulePM()
  {
    return _infoTubeModulePM;
  }

  /**
   * @return the nomModulePM
   */
  public String getNomModulePM()
  {
    return _nomModulePM;
  }

  /**
   * @return the positionModulePM
   */
  public String getPositionModulePM()
  {
    return _positionModulePM;
  }

  /**
   * @return the referenceCableModulePM
   */
  public String getReferenceCableModulePM()
  {
    return _referenceCableModulePM;
  }

}
