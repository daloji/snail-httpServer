
package com.bytel.spirit.common.connector.oi.aidecommande.structs.structureverticale.ligne;

import java.io.Serializable;
import java.util.Objects;

/**
 * @author jpais
 * @version ($Revision$ $Date$)
 */
public class Prise implements Serializable
{
  /** Serial UID */
  private static final long serialVersionUID = 1222483399512318240L;

  /**
   * Référence de la PTO telle que présente dans les bases de données de l’OI.
   */
  private String _referencePTO;

  /**
   * Référence temporaire définie par le promoteur dans les immeubles neufs afin d’identifier la DTIO à la construction et
   * telle que présente dans les bases de données de l’OI.
   */
  private String _referencePrisePromoteur;

  /**
   * Ce champ permet de préciser les statuts de la Ligne FTTH construite.
   */
  private StatutLigneFTTH _statutLigneFTTH;

  /**
   * Dans le cas de DTIO (posée par le promoteur) jamais utilisé, l’OI précise si l’OC doit intervenir dans le Local FTTH
   * pour poser l’étiquette de la PTO non gérée par le constructeur de l’immeuble ayant déployé l’infrastructure optique.
   */
  private String _etiquetteAPoser;

  /**
   * Référence du PBO auquel la ligne FTTH est rattachée.
   */
  private String _referencePBO;

  @Override
  public boolean equals(Object o_p)
  {
    if (this == o_p)
    {
      return true;
    }
    if (o_p == null || getClass() != o_p.getClass())
    {
      return false;
    }
    Prise prise = (Prise) o_p;
    return Objects.equals(_referencePTO, prise._referencePTO) && Objects.equals(_referencePrisePromoteur, prise._referencePrisePromoteur) && _statutLigneFTTH.equals(prise._statutLigneFTTH) && Objects.equals(_etiquetteAPoser, prise._etiquetteAPoser) && Objects.equals(_referencePBO, prise._referencePBO);
  }

  /**
   * @return value of etiquetteAPoser
   */
  public String getEtiquetteAPoser()
  {
    return _etiquetteAPoser;
  }

  /**
   * @return value of referencePBO
   */
  public String getReferencePBO()
  {
    return _referencePBO;
  }

  /**
   * @return value of referencePTO
   */
  public String getReferencePTO()
  {
    return _referencePTO;
  }

  /**
   * @return value of referencePrisePromoteur
   */
  public String getReferencePrisePromoteur()
  {
    return _referencePrisePromoteur;
  }

  /**
   * @return value of statutLigneFTTH
   */
  public StatutLigneFTTH getStatutLigneFTTH()
  {
    return _statutLigneFTTH;
  }

  @Override
  public int hashCode()
  {
    return Objects.hash(_referencePTO, _referencePrisePromoteur, _statutLigneFTTH, _etiquetteAPoser, _referencePBO);
  }

  /**
   * @param etiquetteAPoser_p
   *          The etiquetteAPoser to set.
   */
  public void setEtiquetteAPoser(String etiquetteAPoser_p)
  {
    _etiquetteAPoser = etiquetteAPoser_p;
  }

  /**
   * @param referencePBO_p
   *          The referencePBO to set.
   */
  public void setReferencePBO(String referencePBO_p)
  {
    _referencePBO = referencePBO_p;
  }

  /**
   * @param referencePTO_p
   *          The referencePTO to set.
   */
  public void setReferencePTO(String referencePTO_p)
  {
    _referencePTO = referencePTO_p;
  }

  /**
   * @param referencePrisePromoteur_p
   *          The referencePrisePromoteur to set.
   */
  public void setReferencePrisePromoteur(String referencePrisePromoteur_p)
  {
    _referencePrisePromoteur = referencePrisePromoteur_p;
  }

  /**
   * @param statutLigneFTTH_p
   *          The statutLigneFTTH to set.
   */
  public void setStatutLigneFTTH(StatutLigneFTTH statutLigneFTTH_p)
  {
    _statutLigneFTTH = statutLigneFTTH_p;
  }
}
