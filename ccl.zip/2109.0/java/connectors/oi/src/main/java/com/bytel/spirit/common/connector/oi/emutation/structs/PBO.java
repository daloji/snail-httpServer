/*******************************************************************************
* $Id: PBO.java 11074 2018-10-03 10:03:43Z jstrub $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connector.oi.emutation.structs;

/**
 *
 * @author jstrub
 * @version ($Revision: 11074 $ $Date: 2018-10-03 12:03:43 +0200 (mer. 03 oct. 2018) $)
 */
public final class PBO
{
  /**
   *
   * @author jstrub
   * @version ($Revision: 11074 $ $Date: 2018-10-03 12:03:43 +0200 (mer. 03 oct. 2018) $)
   */
  public static final class PBOBuilder
  {

    /** Reference PM. */
    private String _referencePM;
    /** Reference PBO. */
    private String _referencePBO;
    /** Adresse PBO. */
    private Adresse _adressePBO;
    /** Structure PBO. */
    private ComplementAdresse _structurePBO;
    /** Nombre fibres disponibles. */
    private Integer _nombreFibresDisponibles;
    /** Nature PBO. */
    private String _naturePBO;

    /**
     * Default Constructor
     */
    public PBOBuilder()
    {
      //Nothing to do
    }

    /**
     * @param adressePBO_p
     *          the localisationPBO
     * @return an instance of {@link PBOBuilder}
     */
    public PBOBuilder adressePBO(Adresse adressePBO_p)
    {
      _adressePBO = adressePBO_p;
      return this;
    }

    /**
     * @return a built {@link PBOs}
     */
    public PBO build()
    {
      return new PBO(_referencePM, _referencePBO, _adressePBO, _structurePBO, _nombreFibresDisponibles, _naturePBO);
    }

    /**
     * @param naturePBO_p
     *          the naturePBO
     * @return an instance of {@link PBOBuilder}
     */
    public PBOBuilder naturePBO(String naturePBO_p)
    {
      _naturePBO = naturePBO_p;
      return this;
    }

    /**
     * @param nombreFibresDisponibles_p
     *          the nombreFibresDisponibles
     * @return an instance of {@link PBOBuilder}
     */
    public PBOBuilder nombreFibresDisponibles(Integer nombreFibresDisponibles_p)
    {
      _nombreFibresDisponibles = nombreFibresDisponibles_p;
      return this;
    }

    /**
     * @param referencePBO_p
     *          the referencePBO
     * @return an instance of {@link PBOBuilder}
     */
    public PBOBuilder referencePBO(String referencePBO_p)
    {
      _referencePBO = referencePBO_p;
      return this;
    }

    /**
     * @param referencePM_p
     *          the referencePM
     * @return an instance of {@link PBOBuilder}
     */
    public PBOBuilder referencePM(String referencePM_p)
    {
      _referencePM = referencePM_p;
      return this;
    }

    /**
     * @param structurePBO_p
     *          the structurePBO
     * @return an instance of {@link PBOBuilder}
     */
    public PBOBuilder structurePBO(ComplementAdresse structurePBO_p)
    {
      _structurePBO = structurePBO_p;
      return this;
    }

  }

  /** Reference PM. */
  private final String _referencePM;
  /** Reference PBO. */
  private final String _referencePBO;
  /** Adresse PBO. */
  private final Adresse _adressePBO;
  /** Structure PBO. */
  private final ComplementAdresse _structurePBO;
  /** Nombre fibres disponibles. */
  private final Integer _nombreFibresDisponibles;
  /** Nature PBO. */
  private final String _naturePBO;

  /**
   * @param referencePM_p
   *          the referencePM
   * @param referencePBO_p
   *          the referencePBO
   * @param adressePBO_p
   *          the adressePBO
   * @param structurePBO_p
   *          the structurePBO
   * @param nombreFibresDisponibles_p
   *          the nombreFibresDisponibles
   * @param naturePBO_p
   *          the naturePBO
   */
  public PBO(String referencePM_p, String referencePBO_p, Adresse adressePBO_p, ComplementAdresse structurePBO_p, Integer nombreFibresDisponibles_p, String naturePBO_p)
  {
    _referencePM = referencePM_p;
    _referencePBO = referencePBO_p;
    _adressePBO = adressePBO_p;
    _structurePBO = structurePBO_p;
    _nombreFibresDisponibles = nombreFibresDisponibles_p;
    _naturePBO = naturePBO_p;
  }

  /**
   * @return the adressePBO
   */
  public Adresse getAdressePBO()
  {
    return _adressePBO;
  }

  /**
   * @return the naturePBO
   */
  public String getNaturePBO()
  {
    return _naturePBO;
  }

  /**
   * @return the nombreFibresDisponibles
   */
  public Integer getNombreFibresDisponibles()
  {
    return _nombreFibresDisponibles;
  }

  /**
   * @return the referencePBO
   */
  public String getReferencePBO()
  {
    return _referencePBO;
  }

  /**
   * @return the referencePM
   */
  public String getReferencePM()
  {
    return _referencePM;
  }

  /**
   * @return the structurePBO
   */
  public ComplementAdresse getStructurePBO()
  {
    return _structurePBO;
  }

}
