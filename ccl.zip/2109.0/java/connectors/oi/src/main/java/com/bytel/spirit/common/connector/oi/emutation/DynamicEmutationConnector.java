/*******************************************************************************
* $Id: DynamicEmutationConnector.java 21025 2019-05-06 09:27:37Z fbarnabe $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connector.oi.emutation;

import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.services.connector.AbstractDynamicSoapConnector;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.connector.SoapDynamicConfig;
import com.bytel.spirit.common.connector.oi.AbstractDynamicOIConnector;
import com.bytel.spirit.common.connector.oi.CodeRetour;
import com.bytel.spirit.common.connector.oi.emutation.structs.Fibres;
import com.bytel.spirit.common.connector.oi.emutation.structs.MAJRouteOptique;
import com.bytel.spirit.common.connector.oi.emutation.structs.MAJRouteOptiqueResponse;
import com.bytel.spirit.common.connector.oi.emutation.structs.PBOs;
import com.bytel.spirit.common.generated.configfluxOI.ConfigFluxOI;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

/**
 * Implémentation concrète de {@link AbstractDynamicSoapConnector} dédiée aux connecteurs OI pour les web-services
 * d'aide à la commande.
 *
 * @author jjoly
 * @version ($Revision: 21025 $ $Date: 2019-05-06 11:27:37 +0200 (lun. 06 mai 2019) $)
 */
public final class DynamicEmutationConnector extends AbstractDynamicOIConnector<EmutationConnector>
{

  /**
   * Consultation fibre, dynamique selon le partenaire, via les références PM et PBO.
   *
   * @param tracabilite_p
   *          objet de tracabilité Spirit
   * @param config_p
   *          objet de configuration dynamique SOAP
   * @param referencePM_p
   *          reference PM
   * @param referencePBO_p
   *          reference PBO
   * @param refPrestationPrise_p
   *          reference prestation prise
   * @return représentation interne d'une {@link Fibres} et {@link CodeRetour} associé à la réponse
   * @throws RavelException
   *           exception lors de l'échange SOAP
   */
  public ConnectorResponse<Fibres, CodeRetour> consultationFibres(Tracabilite tracabilite_p, ConfigFluxOI config_p, String referencePM_p, String referencePBO_p, String refPrestationPrise_p) throws RavelException
  {
    SoapDynamicConfig soapConfig = createSoapDynamicConfig(config_p);
    EmutationConnector connector = getSubConnector(soapConfig);

    return connector.consultationFibres(tracabilite_p, config_p, referencePM_p, referencePBO_p, refPrestationPrise_p);
  }

  /**
   * Mise à jour d'une route optique, dynamique selon le partenaire, via un objet structuré majRouteOptique
   *
   * @param tracabilite_p
   *          objet de tracabilité Spirit
   * @param config_p
   *          objet de configuration dynamique SOAP
   * @param majRouteOptique_p
   *          objet structuré majRouteOptique
   * @return le numéro de décharge et {@link CodeRetour} associé à la réponse
   * @throws RavelException
   *           exception lors de l'échange SOAP
   */
  public ConnectorResponse<MAJRouteOptiqueResponse, CodeRetour> miseAJourRouteOptique(Tracabilite tracabilite_p, ConfigFluxOI config_p, MAJRouteOptique majRouteOptique_p) throws RavelException
  {
    SoapDynamicConfig soapConfig = createSoapDynamicConfig(config_p);
    EmutationConnector connector = getSubConnector(soapConfig);

    return connector.miseAJourRouteOptique(tracabilite_p, config_p, majRouteOptique_p);
  }

  /**
   * Recherche de la liste des PBO, dynamique selon le partenaire, via une référence de prestation
   *
   * @param tracabilite_p
   *          objet de tracabilité Spirit
   * @param config_p
   *          objet de configuration dynamique SOAP
   * @param refPrestationPrise_p
   *          référence de la prestation
   * @return représentation interne d'une {@link PBOs} et {@link CodeRetour} associé à la réponse
   * @throws RavelException
   *           exception lors de l'échange SOAP
   */
  public ConnectorResponse<PBOs, CodeRetour> recherchePBO(Tracabilite tracabilite_p, ConfigFluxOI config_p, String refPrestationPrise_p) throws RavelException
  {
    SoapDynamicConfig soapConfig = createSoapDynamicConfig(config_p);
    EmutationConnector connector = getSubConnector(soapConfig);

    return connector.recherchePBO(tracabilite_p, config_p, refPrestationPrise_p);
  }
}
