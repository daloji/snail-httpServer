/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connector.oi.altitude;

import java.io.Serializable;
import java.time.LocalDateTime;

import com.bytel.ravel.common.json.annotations.RavelLocalDateTimeFormat;
import com.bytel.ravel.common.json.format.impl.Rfc3339LocalDateTimeNano;
import com.squareup.moshi.Json;

/**
 * Authentification token for Altitude.
 *
 * @author mlebihan
 * @version ($Revision$ $Date$)
 */
public class AltitudeToken implements Serializable
{
  /** Serial UID */
  private static final long serialVersionUID = -8828387254288211525L;

  /** Value. */
  @Json(name = "value")
  private String _value;

  /** (format pour la (de)sérialisation "2020-10-01T20:47:12.7871699+02:00") */
  @Json(name = "expire")
  @RavelLocalDateTimeFormat(value = Rfc3339LocalDateTimeNano.class)
  private LocalDateTime _expire;

  /** Operateur commercial */
  @Json(name = "oc")
  private String _oc;

  /** Error . */
  @Json(name = "error")
  private String _error;

  /**
   * Return error.
   *
   * @return the error
   */
  public String getError()
  {
    return _error;
  }

  /**
   * Return the token expiration date/time.
   *
   * @return the expiration date/time.
   */
  public LocalDateTime getExpire()
  {
    return _expire;
  }

  /**
   * Return operateur commercial.
   *
   * @return operateur commercial
   */
  public String getOc()
  {
    return _oc;
  }

  /**
   * Returns the token value.
   *
   * @return the value
   */
  public String getValue()
  {
    return _value;
  }

  /**
   * set the error.
   *
   * @param error_p
   *          the error to set
   */
  public void setError(String error_p)
  {
    _error = error_p;
  }

  /**
   * Set the expiration date time of the token.
   *
   * @param expire_p
   *          the expire to set
   */
  public void setExpire(LocalDateTime expire_p)
  {
    _expire = expire_p;
  }

  /**
   * Set operateur commercial.
   *
   * @param oc_p
   *          Operateur commercial.
   */
  public void setOc(String oc_p)
  {
    _oc = oc_p;
  }

  /**
   * Set the token value.
   *
   * @param value_p
   *          Token value.
   */
  public void setValue(String value_p)
  {
    _value = value_p;
  }
}
