/*******************************************************************************
 * $Id:
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connector.oi;

import java.time.Duration;
import java.time.Instant;

import javax.ws.rs.core.MultivaluedMap;

import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.probes.AvgDoubleCollectorItem;
import com.bytel.ravel.common.probes.AvgFlowPerSecondCollector;
import com.bytel.ravel.common.probes.RavelProbeConfigurationManager;
import com.bytel.ravel.services.connector.BaseProxy;
import com.bytel.ravel.services.connector.ConnectorExecution;
import com.bytel.ravel.services.connector.ConnectorManager;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.connector.IAuthentService;
import com.bytel.ravel.services.connector.IConnector;
import com.bytel.ravel.services.connector.SoapDynamicConfig;
import com.bytel.spirit.common.connector.oi.aidecommande.DynamicAideCommandeConnector;
import com.bytel.spirit.common.connector.oi.aidecommande.structs.structureverticale.StructureReponse;
import com.bytel.spirit.common.connector.oi.emutation.DynamicEmutationConnector;
import com.bytel.spirit.common.connector.oi.emutation.structs.Fibres;
import com.bytel.spirit.common.connector.oi.emutation.structs.MAJRouteOptique;
import com.bytel.spirit.common.connector.oi.emutation.structs.MAJRouteOptiqueResponse;
import com.bytel.spirit.common.connector.oi.emutation.structs.PBOs;
import com.bytel.spirit.common.generated.configfluxOI.ConfigFluxOI;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

/**
 * Defines a proxy to easily access OI connectors.
 *
 * @author jstrub
 * @version ($Revision: 44733 $ $Date: 2020-12-11 16:15:54 +0100 (ven. 11 déc. 2020) $)
 */
public final class OIProxy extends BaseProxy
{
  /**
   * Allow one Emutation Retry in case of expired token
   *
   * @param <C>
   *          connector class.
   * @param <R>
   *          Carried object.
   */
  @FunctionalInterface
  interface IConnectorMethod<C extends IConnector, R>
  {
    /**
     * Perform a connector call that handles one retry in case of Emutation expired token.
     *
     * @param connector
     *          Connector to call.
     * @return Return of the connector method.
     * @throws RavelException
     *           if a problem happens with the connector.
     */
    ConnectorResponse<R, CodeRetour> oneRetry(C connector) throws RavelException;
  }

  /** Probes category. */
  private static final String PROBES_CATEGORY = "OIProxy"; //$NON-NLS-1$

  /** Constant name of Emutation dynamic connector. */
  private static final String EMUTATION_DYNAMIC_CONNECTOR_NAME = "OI_Emutation_Dynamic"; //$NON-NLS-1$

  /** Constant name of "aide à la commande" dynamic connector. */
  private static final String AIDE_COMMANDE_DYNAMIC_CONNECTOR_NAME = "OI_AideCommande_Dynamic"; //$NON-NLS-1$

  /** Error code depicting a token expired in Emutation. */
  private static final String EMUATION_ERROR_CODE_TOKEN_EXPIRED = "S023"; //$NON-NLS-1$

  /** Proxy instance. */
  private static OIProxy _instance = new OIProxy();

  /**
   * To access the proxy instance.
   *
   * @return The proxy instance
   */
  public static OIProxy getInstance()
  {
    return OIProxy._instance;
  }

  /** Probe: measure the average number of consultationFibres call per second. */
  AvgFlowPerSecondCollector _avg_oi_consultationFibres_call_counter;

  /** Probe: measure the average execution time of the consultationFibres operation. */
  AvgDoubleCollectorItem _avg_oi_consultationFibres_ExecTime;
  /** Probe: measure the average number of miseAJourRouteOptique call per second. */
  AvgFlowPerSecondCollector _avg_oi_miseAJourRouteOptique_call_counter;

  /** Probe: measure the average execution time of the miseAJourRouteOptique operation. */
  AvgDoubleCollectorItem _avg_oi_miseAJourRouteOptique_ExecTime;
  /** Probe: measure the average number of obtenirStructureVerticale call per second. */
  AvgFlowPerSecondCollector _avg_oi_obtenirStructureVerticale_call_counter;

  /** Probe: measure the average execution time of the obtenirStructureVerticale operation. */
  AvgDoubleCollectorItem _avg_oi_obtenirStructureVerticale_ExecTime;
  /** Probe: measure the average number of recherchePBO call per second. */
  AvgFlowPerSecondCollector _avg_oi_recherchePBO_call_counter;

  /** Probe: measure the average execution time of the recherchePBO operation. */
  AvgDoubleCollectorItem _avg_oi_recherchePBO_ExecTime;

  /**
   * Default private constructor.
   */
  private OIProxy()
  {
    // probes
    _avg_oi_consultationFibres_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_oi_consultationFibres_per_second", PROBES_CATEGORY); //$NON-NLS-1$
    _avg_oi_consultationFibres_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_oi_consultationFibres_ExecTime", PROBES_CATEGORY); //$NON-NLS-1$

    _avg_oi_obtenirStructureVerticale_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_oi_obtenirStructureVerticale_per_second", PROBES_CATEGORY); //$NON-NLS-1$
    _avg_oi_obtenirStructureVerticale_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_oi_obtenirStructureVerticale_ExecTime", PROBES_CATEGORY); //$NON-NLS-1$

    _avg_oi_recherchePBO_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_oi_recherchePBO_per_second", PROBES_CATEGORY); //$NON-NLS-1$
    _avg_oi_recherchePBO_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_oi_recherchePBO_ExecTime", PROBES_CATEGORY); //$NON-NLS-1$

    _avg_oi_miseAJourRouteOptique_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_oi_miseAJourRouteOptique_call_counter", PROBES_CATEGORY); //$NON-NLS-1$
    _avg_oi_miseAJourRouteOptique_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_oi_miseAJourRouteOptique_ExecTime", PROBES_CATEGORY); //$NON-NLS-1$
  }

  /**
   * Consultation fibre, dynamique selon le partenaire, via les références PM et PBO.
   *
   * @param tracabilite_p
   *          objet de tracabilité Spirit
   * @param config_p
   *          objet de configuration dynamique SOAP
   * @param referencePM_p
   *          reference PM
   * @param referencePBO_p
   *          reference PBO
   * @param refPrestationPrise_p
   *          refPrestationPrise
   * @return représentation interne d'une {@link Fibres} et {@link CodeRetour} associé à la réponse
   * @throws RavelException
   *           exception lors de l'échange SOAP
   */
  public ConnectorResponse<Fibres, CodeRetour> consultationFibres(Tracabilite tracabilite_p, ConfigFluxOI config_p, String referencePM_p, String referencePBO_p, String refPrestationPrise_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Fibres, CodeRetour>>(EMUTATION_DYNAMIC_CONNECTOR_NAME)
    {
      @Override
      public ConnectorResponse<Fibres, CodeRetour> run() throws RavelException
      {
        DynamicEmutationConnector emutationConnector = (DynamicEmutationConnector) ConnectorManager.getInstance().getConnector(_connectorId);

        // probe
        _avg_oi_consultationFibres_call_counter.measure();
        final Instant startTime = Instant.now();

        try
        {
          return oneRetry((DynamicEmutationConnector c) -> //
          c.consultationFibres(tracabilite_p, config_p, referencePM_p, referencePBO_p, refPrestationPrise_p), //
              emutationConnector, config_p, tracabilite_p, _connectorId);
        }
        finally
        {
          final Instant endTime = Instant.now();
          // probe
          _avg_oi_consultationFibres_ExecTime.updateAvgValue(Duration.between(startTime, endTime).toMillis());
        }
      }
    });
  }

  /**
   * Get an authentification service from a configuration and a connector id.
   *
   * @param config_p
   *          Configuration.
   * @param connectorId_p
   *          Connector id.
   * @return Authentification service.
   * @throws RavelException
   *           If a trouble happens.
   */
  public IAuthentService getAuthentService(SoapDynamicConfig config_p, String connectorId_p) throws RavelException
  {
    DynamicEmutationConnector emutationConnector = (DynamicEmutationConnector) ConnectorManager.getInstance().getConnector(connectorId_p);
    return emutationConnector.getAuthentService(config_p);
  }

  /**
   * Mise à jour d'une route optique, dynamique selon le partenaire, via un objet structuré majRouteOptique
   *
   * @param tracabilite_p
   *          objet de tracabilité Spirit
   * @param config_p
   *          objet de configuration dynamique SOAP
   * @param majRouteOptique_p
   *          objet structuré majRouteOptique
   * @return le numéro de décharge et {@link CodeRetour} associé à la réponse
   * @throws RavelException
   *           exception lors de l'échange SOAP
   */
  public ConnectorResponse<MAJRouteOptiqueResponse, CodeRetour> miseAJourRouteOptique(Tracabilite tracabilite_p, ConfigFluxOI config_p, MAJRouteOptique majRouteOptique_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<MAJRouteOptiqueResponse, CodeRetour>>(EMUTATION_DYNAMIC_CONNECTOR_NAME)
    {
      @Override
      public ConnectorResponse<MAJRouteOptiqueResponse, CodeRetour> run() throws RavelException
      {
        DynamicEmutationConnector emutationConnector = (DynamicEmutationConnector) ConnectorManager.getInstance().getConnector(_connectorId);

        // probe
        _avg_oi_miseAJourRouteOptique_call_counter.measure();
        final Instant startTime = Instant.now();

        try
        {
          return oneRetry((DynamicEmutationConnector c) -> //
          c.miseAJourRouteOptique(tracabilite_p, config_p, majRouteOptique_p), //
              emutationConnector, config_p, tracabilite_p, _connectorId);
        }
        finally
        {
          final Instant endTime = Instant.now();
          // probe
          _avg_oi_miseAJourRouteOptique_ExecTime.updateAvgValue(Duration.between(startTime, endTime).toMillis());
        }
      }
    });
  }

  /**
   * Recherche d'une structure verticale, dynamique selon le partenaire, via un quadruplet
   *
   * @param tracabilite_p
   *          objet de tracabilité Spirit
   * @param config_p
   *          objet de configuration dynamique SOAP
   * @param codeInsee_p
   *          code INSEE
   * @param codeRivoli_p
   *          code Rivoli
   * @param numeroVoie_p
   *          numero de Voie
   * @param complementNumeroVoie_p
   *          complement numero de voie facultatif
   * @param headers_p
   *          The headers added to the request.
   * @return représentation interne d'une {@link StructureReponse} et {@link CodeRetour} associé à la réponse
   * @throws RavelException
   *           exception lors de l'échange SOAP
   */
  public ConnectorResponse<StructureReponse, CodeRetour> obtenirStructureVerticale(final Tracabilite tracabilite_p, final ConfigFluxOI config_p, final String codeInsee_p, final String codeRivoli_p, final Integer numeroVoie_p, final String complementNumeroVoie_p, MultivaluedMap<String, String> headers_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<StructureReponse, CodeRetour>>(AIDE_COMMANDE_DYNAMIC_CONNECTOR_NAME)
    {
      @Override
      public ConnectorResponse<StructureReponse, CodeRetour> run() throws RavelException
      {
        DynamicAideCommandeConnector aideCommandeConnector = (DynamicAideCommandeConnector) ConnectorManager.getInstance().getConnector(_connectorId);

        // probe
        _avg_oi_obtenirStructureVerticale_call_counter.measure();
        final Instant startTime = Instant.now();

        try
        {
          return aideCommandeConnector.obtenirStructureVerticale(tracabilite_p, config_p, codeInsee_p, codeRivoli_p, numeroVoie_p, complementNumeroVoie_p, headers_p);
        }
        finally
        {
          final Instant endTime = Instant.now();
          // probe
          _avg_oi_obtenirStructureVerticale_ExecTime.updateAvgValue(Duration.between(startTime, endTime).toMillis());
        }
      }
    });
  }

  /**
   * Recherche d'une structure verticale, dynamique selon le partenaire, via une hexacle
   *
   * @param tracabilite_p
   *          objet de tracabilité Spirit
   * @param config_p
   *          objet de configuration dynamique SOAP
   * @param hexacle_p
   *          hexacle
   * @param headers_p
   *          The headers added to the request.
   * @return représentation interne d'une {@link StructureReponse} et {@link CodeRetour} associé à la réponse
   * @throws RavelException
   *           exception lors de l'échange SOAP
   */
  public ConnectorResponse<StructureReponse, CodeRetour> obtenirStructureVerticaleByHexacle(final Tracabilite tracabilite_p, final ConfigFluxOI config_p, String hexacle_p, MultivaluedMap<String, String> headers_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<StructureReponse, CodeRetour>>(AIDE_COMMANDE_DYNAMIC_CONNECTOR_NAME)
    {
      @Override
      public ConnectorResponse<StructureReponse, CodeRetour> run() throws RavelException
      {
        DynamicAideCommandeConnector aideCommandeConnector = (DynamicAideCommandeConnector) ConnectorManager.getInstance().getConnector(_connectorId);

        // probe
        _avg_oi_obtenirStructureVerticale_call_counter.measure();
        final Instant startTime = Instant.now();

        try
        {
          return aideCommandeConnector.obtenirStructureVerticaleByHexacle(tracabilite_p, config_p, hexacle_p, headers_p);
        }
        finally
        {
          final Instant endTime = Instant.now();
          // probe
          _avg_oi_obtenirStructureVerticale_ExecTime.updateAvgValue(Duration.between(startTime, endTime).toMillis());
        }
      }
    });
  }

  /**
   * Recherche d'une structure verticale, dynamique selon le partenaire, via une IMB
   *
   * @param tracabilite_p
   *          objet de tracabilité Spirit
   * @param config_p
   *          objet de configuration dynamique SOAP
   * @param imb_p
   *          IMB
   * @param headers_p
   *          The headers added to the request.
   * @return représentation interne d'une {@link StructureReponse} et {@link CodeRetour} associé à la réponse
   * @throws RavelException
   *           exception lors de l'échange SOAP
   */
  public ConnectorResponse<StructureReponse, CodeRetour> obtenirStructureVerticaleByIMB(final Tracabilite tracabilite_p, final ConfigFluxOI config_p, String imb_p, MultivaluedMap<String, String> headers_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<StructureReponse, CodeRetour>>(AIDE_COMMANDE_DYNAMIC_CONNECTOR_NAME)
    {
      @Override
      public ConnectorResponse<StructureReponse, CodeRetour> run() throws RavelException
      {
        DynamicAideCommandeConnector aideCommandeConnector = (DynamicAideCommandeConnector) ConnectorManager.getInstance().getConnector(_connectorId);

        // probe
        _avg_oi_obtenirStructureVerticale_call_counter.measure();
        final Instant startTime = Instant.now();

        try
        {
          return aideCommandeConnector.obtenirStructureVerticaleByIMB(tracabilite_p, config_p, imb_p, headers_p);
        }
        finally
        {
          final Instant endTime = Instant.now();
          // probe
          _avg_oi_obtenirStructureVerticale_ExecTime.updateAvgValue(Duration.between(startTime, endTime).toMillis());
        }
      }
    });
  }

  /**
   * Recherche d'une structure verticale, dynamique selon le partenaire, via une Reference PTO
   *
   * @param tracabilite_p
   *          objet de tracabilité Spirit
   * @param config_p
   *          objet de configuration dynamique SOAP
   * @param referencePTO_p
   *          reference PTO
   * @param headers_p
   *          The headers added to the request.
   * @return représentation interne d'une {@link StructureReponse} et {@link CodeRetour} associé à la réponse
   * @throws RavelException
   *           exception lors de l'échange SOAP
   */
  public ConnectorResponse<StructureReponse, CodeRetour> obtenirStructureVerticaleByPTO(final Tracabilite tracabilite_p, final ConfigFluxOI config_p, String referencePTO_p, MultivaluedMap<String, String> headers_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<StructureReponse, CodeRetour>>(AIDE_COMMANDE_DYNAMIC_CONNECTOR_NAME)
    {
      @Override
      public ConnectorResponse<StructureReponse, CodeRetour> run() throws RavelException
      {
        DynamicAideCommandeConnector aideCommandeConnector = (DynamicAideCommandeConnector) ConnectorManager.getInstance().getConnector(_connectorId);

        // probe
        _avg_oi_obtenirStructureVerticale_call_counter.measure();
        final Instant startTime = Instant.now();

        try
        {
          return aideCommandeConnector.obtenirStructureVerticaleByPTO(tracabilite_p, config_p, referencePTO_p, headers_p);
        }
        finally
        {
          final Instant endTime = Instant.now();
          // probe
          _avg_oi_obtenirStructureVerticale_ExecTime.updateAvgValue(Duration.between(startTime, endTime).toMillis());
        }
      }
    });
  }

  /**
   * Recherche de la liste des PBO, dynamique selon le partenaire, via une référence de prestation
   *
   * @param tracabilite_p
   *          objet de tracabilité Spirit
   * @param config_p
   *          objet de configuration dynamique SOAP
   * @param refPrestationPrise_p
   *          référence de la prestation
   * @return représentation interne d'une {@link PBOs} et {@link CodeRetour} associé à la réponse
   * @throws RavelException
   *           exception lors de l'échange SOAP
   */
  public ConnectorResponse<PBOs, CodeRetour> recherchePBO(final Tracabilite tracabilite_p, final ConfigFluxOI config_p, final String refPrestationPrise_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<PBOs, CodeRetour>>(EMUTATION_DYNAMIC_CONNECTOR_NAME)
    {
      @Override
      public ConnectorResponse<PBOs, CodeRetour> run() throws RavelException
      {
        DynamicEmutationConnector emutationConnector = (DynamicEmutationConnector) ConnectorManager.getInstance().getConnector(_connectorId);

        // probe
        _avg_oi_recherchePBO_call_counter.measure();
        final Instant startTime = Instant.now();

        try
        {
          return oneRetry((DynamicEmutationConnector c) -> //
          c.recherchePBO(tracabilite_p, config_p, refPrestationPrise_p), //
              emutationConnector, config_p, tracabilite_p, _connectorId);
        }
        finally
        {
          final Instant endTime = Instant.now();
          // probe
          _avg_oi_recherchePBO_ExecTime.updateAvgValue(Duration.between(startTime, endTime).toMillis());
        }
      }
    });
  }

  /**
   * Perform a connector call, and handle the case of emutation token expired :<br>
   * then, the authentification service is retrived, it's token cleared, and a sigle retry is done.
   *
   * @param connectorMethod
   *          Connector method called.
   * @param connector
   *          Connector to use.
   * @param config_p
   *          ConfigFluxOI Connector configuration to convert to SoapDynamicConfig, if needed.
   * @param tracabilite_p
   *          Tracability.
   * @param connectorId_p
   *          Connector id.
   * @return ConnectorResponse.
   * @throws RavelException
   *           if a trouble happens.
   */
  <C extends IConnector, R> ConnectorResponse<R, CodeRetour> oneRetry(IConnectorMethod<C, R> connectorMethod, C connector, final ConfigFluxOI config_p, final Tracabilite tracabilite_p, String connectorId_p) throws RavelException
  {
    ConnectorResponse<R, CodeRetour> connectorResponse = connectorMethod.oneRetry(connector);

    // Detect if Emutation token has expired.
    if (EMUATION_ERROR_CODE_TOKEN_EXPIRED.equals(connectorResponse._second.getCodeErreur()))
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, "Emutation token has expired. Retrying.")); //$NON-NLS-1$
      SoapDynamicConfig soapDynamicConfig = AbstractDynamicOIConnector.createSoapDynamicConfig(config_p);

      // We expect retrieving the authentification service that once gave us that token. If we can't, we're leaving in error.
      OIProxy oi = OIProxy.getInstance();
      IAuthentService authentService = oi.getAuthentService(soapDynamicConfig, connectorId_p);

      if (authentService == null)
      {
        String message = "Error : unable to retrieve the Authentification Service that provided now expired token."; //$NON-NLS-1$
        RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, message));
        return connectorResponse;
      }

      // That authentification service found, it's token is cleaned to be renewed in the next and unique retry we're doing.
      authentService.cleanInvalidToken();
      connectorResponse = connectorMethod.oneRetry(connector);
    }

    return connectorResponse;
  }
}
