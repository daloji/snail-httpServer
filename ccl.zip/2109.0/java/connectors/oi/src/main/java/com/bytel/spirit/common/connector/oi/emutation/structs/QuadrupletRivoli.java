/*******************************************************************************
* $Id: QuadrupletRivoli.java 11545 2018-10-12 14:12:21Z mfreire $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connector.oi.emutation.structs;

import java.io.Serializable;

/**
 *
 * @author jstrub
 * @version ($Revision: 11545 $ $Date: 2018-10-12 16:12:21 +0200 (ven. 12 oct. 2018) $)
 */
public final class QuadrupletRivoli implements Serializable
{
  /**
   * Builder to build {@link QuadrupletRivoli}.
   */
  public static final class QuadrupletRivoliBuilder
  {
    /** Code INSEE. */
    private String _codeInsee;
    /** Code Rivoli. */
    private String _codeRivoli;
    /** Numero voie. */
    private Integer _numeroVoie;
    /** Complement voie. */
    private String _complementNumeroVoie;

    /**
     * Default Constructor
     */
    public QuadrupletRivoliBuilder()
    {
      //Nothing to do
    }

    /**
     * Builder method of the builder.
     *
     * @return built class
     */
    public QuadrupletRivoli build()
    {
      return new QuadrupletRivoli(_codeInsee, _codeRivoli, _numeroVoie, _complementNumeroVoie);
    }

    /**
     * Builder method for _codeInsee parameter.
     *
     * @param codeInsee_p
     *          field to set
     * @return builder
     */
    public QuadrupletRivoliBuilder codeInsee(String codeInsee_p)
    {
      this._codeInsee = codeInsee_p;
      return this;
    }

    /**
     * Builder method for _codeRivoli parameter.
     *
     * @param codeRivoli_p
     *          field to set
     * @return builder
     */
    public QuadrupletRivoliBuilder codeRivoli(String codeRivoli_p)
    {
      this._codeRivoli = codeRivoli_p;
      return this;
    }

    /**
     * Builder method for _complementNumeroVoie parameter.
     *
     * @param complementNumeroVoie_p
     *          field to set
     * @return builder
     */
    public QuadrupletRivoliBuilder complementNumeroVoie(String complementNumeroVoie_p)
    {
      this._complementNumeroVoie = complementNumeroVoie_p;
      return this;
    }

    /**
     * Builder method for _numeroVoie parameter.
     *
     * @param numeroVoie_p
     *          field to set
     * @return builder
     */
    public QuadrupletRivoliBuilder numeroVoie(Integer numeroVoie_p)
    {
      this._numeroVoie = numeroVoie_p;
      return this;
    }
  }

  /** Unique Serial Identifier */
  private static final long serialVersionUID = -4352585437130411024L;

  /** Code INSEE. */
  private final String _codeInsee;
  /** Code Rivoli. */
  private final String _codeRivoli;
  /** Numero voie. */
  private final Integer _numeroVoie;
  /** Complement voie. */
  private final String _complementNumeroVoie;

  /**
   * @param codeInsee_p
   *          the codeInsee
   * @param codeRivoli_p
   *          the codeRivoli
   * @param numeroVoie_p
   *          the numeroVoie
   * @param complementNumeroVoie_p
   *          the complementNumeroVoie
   */
  public QuadrupletRivoli(String codeInsee_p, String codeRivoli_p, Integer numeroVoie_p, String complementNumeroVoie_p)
  {
    _codeInsee = codeInsee_p;
    _codeRivoli = codeRivoli_p;
    _numeroVoie = numeroVoie_p;
    _complementNumeroVoie = complementNumeroVoie_p;
  }

  /**
   * @return the codeInsee
   */
  public String getCodeInsee()
  {
    return _codeInsee;
  }

  /**
   * @return the codeRivoli
   */
  public String getCodeRivoli()
  {
    return _codeRivoli;
  }

  /**
   * @return the complementNumeroVoie
   */
  public String getComplementNumeroVoie()
  {
    return _complementNumeroVoie;
  }

  /**
   * @return the numeroVoie
   */
  public Integer getNumeroVoie()
  {
    return _numeroVoie;
  }

}
