/*******************************************************************************
* $Id: HexacleVoie.java 11075 2018-10-03 11:23:06Z jstrub $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connector.oi.emutation.structs;

import java.io.Serializable;

/**
 *
 * @author jstrub
 * @version ($Revision: 11075 $ $Date: 2018-10-03 13:23:06 +0200 (mer. 03 oct. 2018) $)
 */
public final class HexacleVoie implements Serializable
{
  /**
   * Builder to build {@link HexacleVoie}.
   */
  public static final class HexacleVoieBuilder
  {
    /** Code Hexacle voie. */
    private String _codeHexaclevoie;
    /** Numero voie. */
    private Integer _numeroVoie;
    /** Complement voie. */
    private String _complementNumeroVoie;

    /**
     * Default constructor
     */
    public HexacleVoieBuilder()
    {
      // Nothing to do
    }

    /**
     * Builder method of the builder.
     *
     * @return built class
     */
    public HexacleVoie build()
    {
      return new HexacleVoie(_codeHexaclevoie, _numeroVoie, _complementNumeroVoie);
    }

    /**
     * Builder method for _codeHexaclevoie parameter.
     *
     * @param codeHexaclevoie_p
     *          field to set
     * @return builder
     */
    public HexacleVoieBuilder codeHexaclevoie(String codeHexaclevoie_p)
    {
      this._codeHexaclevoie = codeHexaclevoie_p;
      return this;
    }

    /**
     * Builder method for _complementNumeroVoie parameter.
     *
     * @param complementNumeroVoie_p
     *          field to set
     * @return builder
     */
    public HexacleVoieBuilder complementNumeroVoie(String complementNumeroVoie_p)
    {
      this._complementNumeroVoie = complementNumeroVoie_p;
      return this;
    }

    /**
     * Builder method for _numeroVoie parameter.
     *
     * @param numeroVoie_p
     *          field to set
     * @return builder
     */
    public HexacleVoieBuilder numeroVoie(Integer numeroVoie_p)
    {
      this._numeroVoie = numeroVoie_p;
      return this;
    }
  }

  /** Unique Serial Identifier */
  private static final long serialVersionUID = -8088083667211349270L;

  /** Code Hexacle voie. */
  private final String _codeHexaclevoie;
  /** Numero voie. */
  private final Integer _numeroVoie;
  /** Complement voie. */
  private final String _complementNumeroVoie;

  /**
   * @param codeHexaclevoie_p
   *          the codeHexaclevoie
   * @param numeroVoie_p
   *          the numeroVoie
   * @param complementNumeroVoie_p
   *          the complementNumeroVoie
   */
  public HexacleVoie(String codeHexaclevoie_p, Integer numeroVoie_p, String complementNumeroVoie_p)
  {
    _codeHexaclevoie = codeHexaclevoie_p;
    _numeroVoie = numeroVoie_p;
    _complementNumeroVoie = complementNumeroVoie_p;
  }

  /**
   * @return the codeHexaclevoie
   */
  public String getCodeHexaclevoie()
  {
    return _codeHexaclevoie;
  }

  /**
   * @return the complementNumeroVoie
   */
  public String getComplementNumeroVoie()
  {
    return _complementNumeroVoie;
  }

  /**
   * @return the numeroVoie
   */
  public Integer getNumeroVoie()
  {
    return _numeroVoie;
  }

}
