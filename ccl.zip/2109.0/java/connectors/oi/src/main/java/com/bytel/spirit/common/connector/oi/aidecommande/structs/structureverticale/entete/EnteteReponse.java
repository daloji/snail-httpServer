package com.bytel.spirit.common.connector.oi.aidecommande.structs.structureverticale.entete;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Objects;

/**
 * @author jpais
 * @version ($Revision$ $Date$)
 */
public class EnteteReponse implements Serializable
{
  /** Serial UID */
  private static final long serialVersionUID = -6819535137354595616L;

  /**
   * Numéro de version du Web service
   */
  private String _versionWS;

  /**
   * Date d’émission de la requête
   */
  private LocalDateTime _horodatageRequete;

  /**
   * Date d’émission de la réponse à la demande.
   */
  private LocalDateTime _horodatageReponse;

  /**
   * Identification de l’OC émetteur de la demande.
   */
  private OperateurCommercial _operateurCommercial;

  /**
   * Identifiant de la réponse permettant la réémission en cas d’échec.
   */
  private Integer _identifiantReponse;

  /**
   * Default constructor.
   * 
   * @param versionWS_p
   * @param horodatageRequete_p
   * @param horodatageReponse_p
   * @param operateurCommercial_p
   * @param identifiantReponse_p
   */
  public EnteteReponse(String versionWS_p, LocalDateTime horodatageRequete_p, LocalDateTime horodatageReponse_p, OperateurCommercial operateurCommercial_p, Integer identifiantReponse_p)
  {
    _versionWS = versionWS_p;
    _horodatageRequete = horodatageRequete_p;
    _horodatageReponse = horodatageReponse_p;
    _operateurCommercial = operateurCommercial_p;
    _identifiantReponse = identifiantReponse_p;
  }

  @Override
  public boolean equals(Object o_p)
  {
    if (this == o_p)
    {
      return true;
    }
    if (o_p == null || getClass() != o_p.getClass())
    {
      return false;
    }
    EnteteReponse that = (EnteteReponse) o_p;
    return _versionWS.equals(that._versionWS) && _horodatageRequete.equals(that._horodatageRequete) && _horodatageReponse.equals(that._horodatageReponse) && _operateurCommercial.equals(that._operateurCommercial) && _identifiantReponse.equals(that._identifiantReponse);
  }

  /**
   * @return value of horodatageReponse
   */
  public LocalDateTime getHorodatageReponse()
  {
    return _horodatageReponse;
  }

  /**
   * @return value of horodatageRequete
   */
  public LocalDateTime getHorodatageRequete()
  {
    return _horodatageRequete;
  }

  /**
   * @return value of identifiantReponse
   */
  public Integer getIdentifiantReponse()
  {
    return _identifiantReponse;
  }

  /**
   * @return value of operateurCommercial
   */
  public OperateurCommercial getOperateurCommercial()
  {
    return _operateurCommercial;
  }

  /**
   * @return value of versionWS
   */
  public String getVersionWS()
  {
    return _versionWS;
  }

  @Override
  public int hashCode()
  {
    return Objects.hash(_versionWS, _horodatageRequete, _horodatageReponse, _operateurCommercial, _identifiantReponse);
  }

  /**
   * @param horodatageReponse_p
   *          The horodatageReponse to set.
   */
  public void setHorodatageReponse(LocalDateTime horodatageReponse_p)
  {
    _horodatageReponse = horodatageReponse_p;
  }

  /**
   * @param horodatageRequete_p
   *          The horodatageRequete to set.
   */
  public void setHorodatageRequete(LocalDateTime horodatageRequete_p)
  {
    _horodatageRequete = horodatageRequete_p;
  }

  /**
   * @param identifiantReponse_p
   *          The identifiantReponse to set.
   */
  public void setIdentifiantReponse(Integer identifiantReponse_p)
  {
    _identifiantReponse = identifiantReponse_p;
  }

  /**
   * @param operateurCommercial_p
   *          The operateurCommercial to set.
   */
  public void setOperateurCommercial(OperateurCommercial operateurCommercial_p)
  {
    _operateurCommercial = operateurCommercial_p;
  }

  /**
   * @param versionWS_p
   *          The versionWS to set.
   */
  public void setVersionWS(String versionWS_p)
  {
    _versionWS = versionWS_p;
  }
}
