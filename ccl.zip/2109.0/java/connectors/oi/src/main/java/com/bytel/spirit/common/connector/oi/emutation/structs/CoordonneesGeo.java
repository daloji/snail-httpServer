/*******************************************************************************
* $Id: CoordonneesGeo.java 11075 2018-10-03 11:23:06Z jstrub $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connector.oi.emutation.structs;

import java.io.Serializable;

/**
 *
 * @author jstrub
 * @version ($Revision: 11075 $ $Date: 2018-10-03 13:23:06 +0200 (mer. 03 oct. 2018) $)
 */
public final class CoordonneesGeo implements Serializable
{
  /**
   * Builder to build {@link CoordonneesGeo}.
   */
  public static final class CoordonneesGeoBuilder
  {
    /** Type projection. */
    private String _typeProjection;
    /** Coordonnees X. */
    private String _coordonneesX;
    /** Coordonnees Y. */
    private String _coordonneesY;

    /**
     * Default Constructor
     */
    public CoordonneesGeoBuilder()
    {
      //Nothing to do
    }

    /**
     * Builder method of the builder.
     *
     * @return built class
     */
    public CoordonneesGeo build()
    {
      return new CoordonneesGeo(_typeProjection, _coordonneesX, _coordonneesY);
    }

    /**
     * Builder method for _coordonneesX parameter.
     *
     * @param coordonneesX_p
     *          field to set
     * @return builder
     */
    public CoordonneesGeoBuilder coordonneesX(String coordonneesX_p)
    {
      this._coordonneesX = coordonneesX_p;
      return this;
    }

    /**
     * Builder method for _coordonneesY parameter.
     *
     * @param coordonneesY_p
     *          field to set
     * @return builder
     */
    public CoordonneesGeoBuilder coordonneesY(String coordonneesY_p)
    {
      this._coordonneesY = coordonneesY_p;
      return this;
    }

    /**
     * Builder method for _typeProjection parameter.
     *
     * @param typeProjection_p
     *          field to set
     * @return builder
     */
    public CoordonneesGeoBuilder typeProjection(String typeProjection_p)
    {
      this._typeProjection = typeProjection_p;
      return this;
    }
  }

  /** Unique Serial Identifier */
  private static final long serialVersionUID = 202026334174861965L;

  /** Type projection. */
  private final String _typeProjection;
  /** Coordonnees X. */
  private final String _coordonneesX;
  /** Coordonnees Y. */
  private final String _coordonneesY;

  /**
   * @param typeProjection_p
   *          the typeProjection
   * @param coordonneesX_p
   *          the coordonneesX
   * @param coordonneesY_p
   *          the coordonneesY
   */
  public CoordonneesGeo(String typeProjection_p, String coordonneesX_p, String coordonneesY_p)
  {
    _typeProjection = typeProjection_p;
    _coordonneesX = coordonneesX_p;
    _coordonneesY = coordonneesY_p;
  }

  /**
   * @return the coordonneesX
   */
  public String getCoordonneesX()
  {
    return _coordonneesX;
  }

  /**
   * @return the coordonneesY
   */
  public String getCoordonneesY()
  {
    return _coordonneesY;
  }

  /**
   * @return the typeProjection
   */
  public String getTypeProjection()
  {
    return _typeProjection;
  }

}
