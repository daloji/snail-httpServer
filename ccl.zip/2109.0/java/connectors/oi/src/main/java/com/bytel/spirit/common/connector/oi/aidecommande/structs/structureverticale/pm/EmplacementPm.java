
package com.bytel.spirit.common.connector.oi.aidecommande.structs.structureverticale.pm;

/**
 * @author jpais
 * @version ($Revision$ $Date$)
 */
public enum EmplacementPm
{
  PME, PMI;

  public static EmplacementPm fromValue(String v)
  {
    return valueOf(v);
  }

  public String value()
  {
    return name();
  }

}
