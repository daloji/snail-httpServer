/*******************************************************************************
* $Id: RouteOptique.java 11545 2018-10-12 14:12:21Z mfreire $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connector.oi.emutation.structs;

/**
 *
 * @author jstrub
 * @version ($Revision: 11545 $ $Date: 2018-10-12 16:12:21 +0200 (ven. 12 oct. 2018) $)
 */
public class RouteOptique
{

  /**
   * Builder to build {@link RouteOptique}.
   */
  public static final class RouteOptiqueBuilder
  {

    /** The OC. */
    private String _oc;
    /** The positionPM. */
    private PositionPM _positionPM;
    /** The referenceCablePBO. */
    private String _referenceCablePBO;
    /** The informationTubePBO. */
    private String _informationTubePBO;
    /** The informationFibrePBO. */
    private String _informationFibrePBO;
    /** The connecteurPriseNumero. */
    private Integer _connecteurPriseNumero;
    /** The connecteurPriseCouleur. */
    private String _connecteurPriseCouleur;

    /**
     * Builder method of the builder.
     *
     * @return built class
     */
    public RouteOptique build()
    {
      return new RouteOptique(_oc, _positionPM, _referenceCablePBO, _informationTubePBO, _informationFibrePBO, _connecteurPriseNumero, _connecteurPriseCouleur);
    }

    /**
     * Builder method for _connecteurPriseCouleur parameter.
     *
     * @param connecteurPriseCouleur_p
     *          field to set
     * @return builder
     */
    public RouteOptiqueBuilder connecteurPriseCouleur(String connecteurPriseCouleur_p)
    {
      this._connecteurPriseCouleur = connecteurPriseCouleur_p;
      return this;
    }

    /**
     * Builder method for _connecteurPriseNumero parameter.
     *
     * @param connecteurPriseNumero_p
     *          field to set
     * @return builder
     */
    public RouteOptiqueBuilder connecteurPriseNumero(Integer connecteurPriseNumero_p)
    {
      this._connecteurPriseNumero = connecteurPriseNumero_p;
      return this;
    }

    /**
     * Builder method for _informationFibrePBO parameter.
     *
     * @param informationFibrePBO_p
     *          field to set
     * @return builder
     */
    public RouteOptiqueBuilder informationFibrePBO(String informationFibrePBO_p)
    {
      this._informationFibrePBO = informationFibrePBO_p;
      return this;
    }

    /**
     * Builder method for _informationTubePBO parameter.
     *
     * @param informationTubePBO_p
     *          field to set
     * @return builder
     */
    public RouteOptiqueBuilder informationTubePBO(String informationTubePBO_p)
    {
      this._informationTubePBO = informationTubePBO_p;
      return this;
    }

    /**
     * Builder method for _oc parameter.
     *
     * @param oc_p
     *          field to set
     * @return builder
     */
    public RouteOptiqueBuilder oc(String oc_p)
    {
      this._oc = oc_p;
      return this;
    }

    /**
     * Builder method for _positionPM parameter.
     *
     * @param positionPM_p
     *          field to set
     * @return builder
     */
    public RouteOptiqueBuilder positionPM(PositionPM positionPM_p)
    {
      this._positionPM = positionPM_p;
      return this;
    }

    /**
     * Builder method for _referenceCablePBO parameter.
     *
     * @param referenceCablePBO_p
     *          field to set
     * @return builder
     */
    public RouteOptiqueBuilder referenceCablePBO(String referenceCablePBO_p)
    {
      this._referenceCablePBO = referenceCablePBO_p;
      return this;
    }
  }

  /** The OC. */
  private final String _oc;
  /** The positionPM. */
  private final PositionPM _positionPM;
  /** The referenceCablePBO. */
  private final String _referenceCablePBO;
  /** The informationTubePBO. */
  private final String _informationTubePBO;
  /** The informationFibrePBO. */
  private final String _informationFibrePBO;
  /** The connecteurPriseNumero. */
  private final Integer _connecteurPriseNumero;
  /** The connecteurPriseCouleur. */
  private final String _connecteurPriseCouleur;

  /**
   * @param oc_p
   *          the OC
   * @param positionPM_p
   *          the positionPM
   * @param referenceCablePBO_p
   *          the referenceCablePBO
   * @param informationTubePBO_p
   *          the informationTubePBO
   * @param informationFibrePBO_p
   *          the informationFibrePBO
   * @param connecteurPriseNumero_p
   *          the connecteurPriseNumero
   * @param connecteurPriseCouleur_p
   *          the connecteurPriseCouleur
   */
  public RouteOptique(String oc_p, PositionPM positionPM_p, String referenceCablePBO_p, String informationTubePBO_p, String informationFibrePBO_p, Integer connecteurPriseNumero_p, String connecteurPriseCouleur_p)
  {
    _oc = oc_p;
    _positionPM = positionPM_p;
    _referenceCablePBO = referenceCablePBO_p;
    _informationTubePBO = informationTubePBO_p;
    _informationFibrePBO = informationFibrePBO_p;
    _connecteurPriseNumero = connecteurPriseNumero_p;
    _connecteurPriseCouleur = connecteurPriseCouleur_p;
  }

  /**
   * @return the connecteurPriseCouleur
   */
  public String getConnecteurPriseCouleur()
  {
    return _connecteurPriseCouleur;
  }

  /**
   * @return the connecteurPriseNumero
   */
  public Integer getConnecteurPriseNumero()
  {
    return _connecteurPriseNumero;
  }

  /**
   * @return the informationFibrePBO
   */
  public String getInformationFibrePBO()
  {
    return _informationFibrePBO;
  }

  /**
   * @return the informationTubePBO
   */
  public String getInformationTubePBO()
  {
    return _informationTubePBO;
  }

  /**
   * @return the oc
   */
  public String getOc()
  {
    return _oc;
  }

  /**
   * @return the positionPM
   */
  public PositionPM getPositionPM()
  {
    return _positionPM;
  }

  /**
   * @return the referenceCablePBO
   */
  public String getReferenceCablePBO()
  {
    return _referenceCablePBO;
  }

}
