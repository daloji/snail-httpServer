
package com.bytel.spirit.common.connector.oi.aidecommande.structs.structureverticale.batiment;

import java.io.Serializable;
import java.util.Objects;

/**
 * @author jpais
 * @version ($Revision$ $Date$)
 */
public class CoordonneesGeographiques implements Serializable
{
  /** Serial UID */
  private static final long serialVersionUID = -1067268215453715865L;

  /**
   * Ce champ permet de renseigner le type de projection géographique utilisé, de manière identique à celui publié par
   * l’OI dans l’IPE et le CR MAD
   */
  private String _typeProjection;

  /**
   * La valeur doit être donnée dans le même format que l’IPE.
   */
  private String _coordonneeImmeubleX;

  /**
   * La valeur doit être donnée dans le même format que l’IPE.
   */
  private String _coordonneeImmeubleY;

  @Override
  public boolean equals(Object o_p)
  {
    if (this == o_p)
    {
      return true;
    }
    if (o_p == null || getClass() != o_p.getClass())
    {
      return false;
    }
    CoordonneesGeographiques that = (CoordonneesGeographiques) o_p;
    return Objects.equals(_typeProjection, that._typeProjection) && Objects.equals(_coordonneeImmeubleX, that._coordonneeImmeubleX) && Objects.equals(_coordonneeImmeubleY, that._coordonneeImmeubleY);
  }

  /**
   * @return value of coordonneeImmeubleX
   */
  public String getCoordonneeImmeubleX()
  {
    return _coordonneeImmeubleX;
  }

  /**
   * @return value of coordonneeImmeubleY
   */
  public String getCoordonneeImmeubleY()
  {
    return _coordonneeImmeubleY;
  }

  /**
   * @return value of typeProjection
   */
  public String getTypeProjection()
  {
    return _typeProjection;
  }

  @Override
  public int hashCode()
  {
    return Objects.hash(_typeProjection, _coordonneeImmeubleX, _coordonneeImmeubleY);
  }

  /**
   * @param coordonneeImmeubleX_p
   *          The coordonneeImmeubleX to set.
   */
  public void setCoordonneeImmeubleX(String coordonneeImmeubleX_p)
  {
    _coordonneeImmeubleX = coordonneeImmeubleX_p;
  }

  /**
   * @param coordonneeImmeubleY_p
   *          The coordonneeImmeubleY to set.
   */
  public void setCoordonneeImmeubleY(String coordonneeImmeubleY_p)
  {
    _coordonneeImmeubleY = coordonneeImmeubleY_p;
  }

  /**
   * @param typeProjection_p
   *          The typeProjection to set.
   */
  public void setTypeProjection(String typeProjection_p)
  {
    _typeProjection = typeProjection_p;
  }
}
