/*******************************************************************************
* $Id: ComplementAdresse.java 11075 2018-10-03 11:23:06Z jstrub $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connector.oi.emutation.structs;

import java.io.Serializable;

/**
 *
 * @author jstrub
 * @version ($Revision: 11075 $ $Date: 2018-10-03 13:23:06 +0200 (mer. 03 oct. 2018) $)
 */
public final class ComplementAdresse implements Serializable
{

  /**
   * Builder to build {@link ComplementAdresse}.
   */
  public static final class ComplementAdresseBuilder
  {
    /** Batiment. */
    private String _batiment;
    /** Escalier. */
    private String _escalier;
    /** Etage. */
    private String _etage;

    /**
     * Default constructor
     */
    public ComplementAdresseBuilder()
    {
      //Nothing to do
    }

    /**
     * Builder method for batiment parameter.
     *
     * @param batiment_p
     *          field to set
     * @return builder
     */
    public ComplementAdresseBuilder batiment(String batiment_p)
    {
      this._batiment = batiment_p;
      return this;
    }

    /**
     * Builder method of the builder.
     *
     * @return built class
     */
    public ComplementAdresse build()
    {
      return new ComplementAdresse(_batiment, _escalier, _etage);
    }

    /**
     * Builder method for escalier parameter.
     *
     * @param escalier_p
     *          field to set
     * @return builder
     */
    public ComplementAdresseBuilder escalier(String escalier_p)
    {
      this._escalier = escalier_p;
      return this;
    }

    /**
     * Builder method for etage parameter.
     *
     * @param etage_p
     *          field to set
     * @return builder
     */
    public ComplementAdresseBuilder etage(String etage_p)
    {
      this._etage = etage_p;
      return this;
    }
  }

  /** Unique Serial Identifier */
  private static final long serialVersionUID = 4097909597731235736L;

  /** Batiment. */
  private final String _batiment;
  /** Escalier. */
  private final String _escalier;
  /** Etage. */
  private final String _etage;

  /**
   * @param batiment_p
   *          the batiment
   * @param escalier_p
   *          the escalier
   * @param etage_p
   *          the etage
   */
  public ComplementAdresse(String batiment_p, String escalier_p, String etage_p)
  {
    super();
    _batiment = batiment_p;
    _escalier = escalier_p;
    _etage = etage_p;
  }

  /**
   * @return the batiment
   */
  public String getBatiment()
  {
    return _batiment;
  }

  /**
   * @return the escalier
   */
  public String getEscalier()
  {
    return _escalier;
  }

  /**
   * @return the etage
   */
  public String getEtage()
  {
    return _etage;
  }

}
