/*******************************************************************************
* $Id: AbstractDynamicOIConnector.java 54850 2021-07-28 10:58:02Z jbrites $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connector.oi;

import java.text.MessageFormat;

import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.services.connector.AbstractDynamicSoapConnector;
import com.bytel.ravel.services.connector.AbstractSOAPConnector;
import com.bytel.ravel.services.connector.SoapDynamicConfig;
import com.bytel.spirit.common.generated.configfluxOI.ConfigFluxOI;
import com.bytel.spirit.common.generated.configfluxOI.ConnexionTechnique;
import com.bytel.spirit.common.generated.configfluxOI.ConnexionTechnique.Proxy;
import com.bytel.spirit.common.shared.misc.connectors.AbstractSpiritSOAPConnector;

/**
 * @author jstrub
 * @version ($Revision: 54850 $ $Date: 2021-07-28 12:58:02 +0200 (mer. 28 juil. 2021) $)
 * @param <T>
 *          type of sub-connectors
 */
public abstract class AbstractDynamicOIConnector<T extends AbstractSpiritSOAPConnector> extends AbstractDynamicSoapConnector<T>
{
  /**
   * Create a dynamic SOAP configuration from the {@link ConfigFluxOI} object.
   *
   * @param configFluxPartenaire_p
   *          the {@link ConfigFluxOI} object
   * @return the ready to use {@link SoapDynamicConfig}
   * @throws RavelException
   *           thrown upon error while casting connectorClass
   */
  @SuppressWarnings("unchecked")
  protected static SoapDynamicConfig createSoapDynamicConfig(ConfigFluxOI configFluxPartenaire_p) throws RavelException
  {
    SoapDynamicConfig config = new SoapDynamicConfig();

    ConnexionTechnique connexion = configFluxPartenaire_p.getConnexionTechnique();
    if ((connexion == null) || (connexion.getUrl() == null) || connexion.getUrl().isEmpty())
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00010, MessageFormat.format(Messages.getString("AbstractOIActivity.missingConnexionOrURL"), configFluxPartenaire_p.getNomPartenaire(), configFluxPartenaire_p.getCodeFlux())); //$NON-NLS-1$
    }

    // Configure mandatory params
    config.setName(connexion.getUuid());
    config.setUrls(connexion.getUrl().toArray(new String[connexion.getUrl().size()]));
    try
    {
      // Unchecked cast : suppressed warning
      config.setConnectorClass((Class<? extends AbstractSOAPConnector>) Class.forName(connexion.getConnectorClass()));
    }
    catch (Exception exception)
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00010, MessageFormat.format(Messages.getString("AbstractOIActivity.wrongConnectorClass"), configFluxPartenaire_p.getNomPartenaire(), configFluxPartenaire_p.getCodeFlux()), exception); //$NON-NLS-1$
    }

    // Configure timeouts
    config.setConnectTimeOut(connexion.getConnectTimeout() == null ? null : connexion.getConnectTimeout().intValue());
    config.setReceiveTimeOut(connexion.getReceiveTimeout() == null ? null : connexion.getReceiveTimeout().intValue());

    // Configure basic-auth
    if (connexion.getBasicAuth() != null)
    {
      config.setBasicAuth(true);
      config.setLogin(connexion.getBasicAuth().getLogin());
      config.setPassword(connexion.getBasicAuth().getPassword());
    }

    // Configure Proxy
    Proxy proxy = connexion.getProxy();
    if (proxy != null)
    {
      config.setProxyHost(proxy.getHost());
      config.setProxyPort(proxy.getPort() == null ? null : proxy.getPort().intValue());
      config.setProxyLogin(proxy.getLogin());
      config.setProxyPassword(proxy.getPassword());
    }

    config.setAuthentService(toRavel(configFluxPartenaire_p.getConnexionTechnique().getAuthentService()));
    return config;
  }

  /**
   * Convert a ConfigFluxOI AuthentService to a Ravel AuthentService.
   *
   * @param oiAuthent
   *          Config Flux OI Authentification service.
   * @return Ravel Authentification service.
   */
  private static com.bytel.ravel.services.conf.connector.generated.AuthentService toRavel(com.bytel.spirit.common.generated.configfluxOI.AuthentService oiAuthent)
  {
    if (oiAuthent == null)
    {
      return null;
    }

    com.bytel.ravel.services.conf.connector.generated.AuthentService ravelAuthent = new com.bytel.ravel.services.conf.connector.generated.AuthentService();
    ravelAuthent.setGrantType(oiAuthent.getGrantType());
    ravelAuthent.setName(oiAuthent.getName());
    ravelAuthent.setType(oiAuthent.getType());

    if (oiAuthent.getURL() != null)
    {
      com.bytel.ravel.services.conf.connector.generated.URL ravelURL = new com.bytel.ravel.services.conf.connector.generated.URL();
      ravelURL.setAccessPoint(oiAuthent.getURL().getAccessPoint());
      ravelURL.setName(oiAuthent.getURL().getName());

      if (oiAuthent.getURL().getParam() != null)
      {
        oiAuthent.getURL().getParam().forEach(p -> {
          com.bytel.ravel.common.conf.generated.Param ravelParam = new com.bytel.ravel.common.conf.generated.Param();
          ravelParam.setName(p.getName());
          ravelParam.setValue(p.getValue());
          ravelURL.getParam().add(ravelParam);
        });
      }

      com.bytel.spirit.common.generated.configfluxOI.BalancedElement oiBalancedElement = oiAuthent.getURL().getBalancedElement();

      if (oiBalancedElement != null)
      {
        com.bytel.ravel.services.conf.connector.generated.BalancedElement ravelBalancedElement = new com.bytel.ravel.services.conf.connector.generated.BalancedElement();
        ravelBalancedElement.setClazz(oiBalancedElement.getClazz());

        if (oiBalancedElement.getParam() != null)
        {
          oiBalancedElement.getParam().forEach(p -> {
            com.bytel.ravel.common.conf.generated.Param ravelParam = new com.bytel.ravel.common.conf.generated.Param();
            ravelParam.setName(p.getName());
            ravelParam.setValue(p.getValue());
            ravelBalancedElement.getParam().add(ravelParam);
          });

          ravelURL.setBalancedElement(ravelBalancedElement);
        }
      }

      ravelAuthent.setURL(ravelURL);
    }

    return ravelAuthent;
  }
}
