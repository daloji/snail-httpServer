/*******************************************************************************
* $Id: PBOs.java 10997 2018-10-01 15:27:30Z jstrub $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connector.oi.emutation.structs;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 *
 * @author jstrub
 * @version ($Revision: 10997 $ $Date: 2018-10-01 17:27:30 +0200 (lun. 01 oct. 2018) $)
 */
public final class PBOs
{
  /**
   *
   * @author jstrub
   * @version ($Revision: 10997 $ $Date: 2018-10-01 17:27:30 +0200 (lun. 01 oct. 2018) $)
   */
  public static final class PBOsBuilder
  {

    /** List of PBO. */
    private final List<PBO> _pbos;

    /**
     * Default Constructor
     */
    public PBOsBuilder()
    {
      _pbos = new ArrayList<>();
    }

    /**
     * @return a built {@link PBOs}
     */
    public PBOs build()
    {
      return new PBOs(_pbos);
    }

    /**
     * @param pbo_p
     *          pbos to add
     * @return an instance of {@link PBOsBuilder}
     */
    public PBOsBuilder pbos(List<PBO> pbo_p)
    {
      if (pbo_p != null)
      {
        _pbos.addAll(pbo_p);
      }

      return this;
    }

  }

  /** List of PBO. */
  private final List<PBO> _pbos;

  /**
   * @param pbos_p
   *          the pbos
   */
  public PBOs(List<PBO> pbos_p)
  {
    if (pbos_p != null)
    {
      _pbos = Collections.unmodifiableList(pbos_p);
    }
    else
    {
      _pbos = null;
    }
  }

  /**
   * @return the pbos
   */
  public List<PBO> getPbos()
  {
    if (_pbos == null)
    {
      return new ArrayList<>();
    }
    return Collections.unmodifiableList(_pbos);
  }

}
