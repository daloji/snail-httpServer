
package com.bytel.spirit.common.connector.oi.aidecommande.structs;

import com.bytel.spirit.common.connector.oi.CodeRetour;
import com.bytel.spirit.common.connector.oi.aidecommande.structs.structureverticale.StructureReponse;
import com.bytel.spirit.common.connector.oi.aidecommande.structs.structureverticale.entete.EnteteReponse;

import java.io.Serializable;
import java.util.Objects;

/**
 * @author jpais
 * @version ($Revision$ $Date$)
 */
public class ObtentionStructureAdresseReponse implements Serializable
{
  /** Serial UID */
  private static final long serialVersionUID = 920648534886849938L;

  /**
   * Entête de la réponse à la demande contenant la version du web service, l’horodatage de la requête à laquelle
   * correspond la réponse, l’horodatage de la réponse, un identifiant de réponse et l’identification de l’OC émetteur de
   * la demande initiale.
   */
  private EnteteReponse _entete;

  /**
   * Code précisant le résultat de la requête et le type de cas d’erreur le cas échéant.
   */
  private CodeRetour _codeRetour;

  /**
   * Code de l’opérateur d’immeuble
   */
  private String _codeOI;

  /**
   * Ce champ permet de préciser si l’immeuble a été mis à disposition ou non et donc si la structure peut être fournie ou
   * non.
   */
  private Boolean _etatImmeuble;

  /**
   * Description de la structure de l’adresse si cette dernière est disponible dans le webservice, à savoir codeRetour = 0
   * et etatImmeuble = true.
   */
  private StructureReponse _structureDetaillee;

  /**
   * Default constructor
   * 
   * @param entete_p
   * @param codeRetour_p
   */
  public ObtentionStructureAdresseReponse(EnteteReponse entete_p, CodeRetour codeRetour_p)
  {
    _entete = entete_p;
    _codeRetour = codeRetour_p;
  }

  @Override
  public boolean equals(Object o_p)
  {
    if (this == o_p)
    {
      return true;
    }
    if (o_p == null || getClass() != o_p.getClass())
    {
      return false;
    }
    ObtentionStructureAdresseReponse that = (ObtentionStructureAdresseReponse) o_p;
    return _entete.equals(that._entete) && _codeRetour.equals(that._codeRetour) && Objects.equals(_codeOI, that._codeOI) && Objects.equals(_etatImmeuble, that._etatImmeuble) && Objects.equals(_structureDetaillee, that._structureDetaillee);
  }

  /**
   * @return value of codeOI
   */
  public String getCodeOI()
  {
    return _codeOI;
  }

  /**
   * @return value of codeRetour
   */
  public CodeRetour getCodeRetour()
  {
    return _codeRetour;
  }

  /**
   * @return value of entete
   */
  public EnteteReponse getEntete()
  {
    return _entete;
  }

  /**
   * @return value of etatImmeuble
   */
  public Boolean getEtatImmeuble()
  {
    return _etatImmeuble;
  }

  /**
   * @return value of structureDetaillee
   */
  public StructureReponse getStructureDetaillee()
  {
    return _structureDetaillee;
  }

  @Override
  public int hashCode()
  {
    return Objects.hash(_entete, _codeRetour, _codeOI, _etatImmeuble, _structureDetaillee);
  }

  /**
   * @param codeOI_p
   *          The codeOI to set.
   */
  public void setCodeOI(String codeOI_p)
  {
    _codeOI = codeOI_p;
  }

  /**
   * @param codeRetour_p
   *          The codeRetour to set.
   */
  public void setCodeRetour(CodeRetour codeRetour_p)
  {
    _codeRetour = codeRetour_p;
  }

  /**
   * @param entete_p
   *          The entete to set.
   */
  public void setEntete(EnteteReponse entete_p)
  {
    _entete = entete_p;
  }

  /**
   * @param etatImmeuble_p
   *          The etatImmeuble to set.
   */
  public void setEtatImmeuble(Boolean etatImmeuble_p)
  {
    _etatImmeuble = etatImmeuble_p;
  }

  /**
   * @param structureDetaillee_p
   *          The structureDetaillee to set.
   */
  public void setStructureDetaillee(StructureReponse structureDetaillee_p)
  {
    _structureDetaillee = structureDetaillee_p;
  }
}
