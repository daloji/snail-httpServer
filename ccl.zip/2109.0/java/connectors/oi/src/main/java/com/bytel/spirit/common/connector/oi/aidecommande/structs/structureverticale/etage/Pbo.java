
package com.bytel.spirit.common.connector.oi.aidecommande.structs.structureverticale.etage;

import java.io.Serializable;
import java.util.Objects;

/**
 * @author jpais
 * @version ($Revision$ $Date$)
 */
public class Pbo implements Serializable
{
  /** Serial UID */
  private static final long serialVersionUID = -7144839611804883997L;

  /**
   * Référence du PBO pouvant desservir l’étage. La référence d’un PBO peut ne pas être unique sur le parc historique de
   * l’OI. Dans ce cas, c’est son association à la référence PM qui rendra le duo unique.
   */
  private String _referencePBO;

  /**
   * Ce champ précise la localisation du PBO.
   */
  private String _typePbo;

  /**
   * Ce champ précise la nature des travaux entre le PBO et la PTO.
   */
  private String _typeRaccoPbPTO;

  /**
   * Default constructor
   * 
   * @param referencePBO_p
   */
  public Pbo(String referencePBO_p)
  {
    _referencePBO = referencePBO_p;
  }

  @Override
  public boolean equals(Object o_p)
  {
    if (this == o_p)
    {
      return true;
    }
    if (o_p == null || getClass() != o_p.getClass())
    {
      return false;
    }
    Pbo pbo = (Pbo) o_p;
    return _referencePBO.equals(pbo._referencePBO) && Objects.equals(_typePbo, pbo._typePbo) && Objects.equals(_typeRaccoPbPTO, pbo._typeRaccoPbPTO);
  }

  /**
   * @return value of referencePBO
   */
  public String getReferencePBO()
  {
    return _referencePBO;
  }

  /**
   * @return value of typePbo
   */
  public String getTypePbo()
  {
    return _typePbo;
  }

  /**
   * @return value of typeRaccoPbPTO
   */
  public String getTypeRaccoPbPTO()
  {
    return _typeRaccoPbPTO;
  }

  @Override
  public int hashCode()
  {
    return Objects.hash(_referencePBO, _typePbo, _typeRaccoPbPTO);
  }

  /**
   * @param referencePBO_p
   *          The referencePBO to set.
   */
  public void setReferencePBO(String referencePBO_p)
  {
    _referencePBO = referencePBO_p;
  }

  /**
   * @param typePbo_p
   *          The typePbo to set.
   */
  public void setTypePbo(String typePbo_p)
  {
    _typePbo = typePbo_p;
  }

  /**
   * @param typeRaccoPbPTO_p
   *          The typeRaccoPbPTO to set.
   */
  public void setTypeRaccoPbPTO(String typeRaccoPbPTO_p)
  {
    _typeRaccoPbPTO = typeRaccoPbPTO_p;
  }
}
