
package com.bytel.spirit.common.connector.oi.aidecommande.structs.structureverticale.ligne;

import java.io.Serializable;
import java.util.Objects;

/**
 * @author jpais
 * @version ($Revision$ $Date$)
 */
public class StatutLigneFTTH implements Serializable
{
  /** Serial UID */
  private static final long serialVersionUID = 8798354270097568645L;

  /**
   * true : ligne existante false : ligne à construire
   */
  private boolean _existant;

  /**
   * true : ligne raccordable false : ligne non raccordable
   */
  private boolean _raccordable;

  /**
   * true : ligne commercialisable false : ligne non commercialisable
   */
  private boolean _commercialisable;

  /**
   * true : ligne active false : ligne non active
   */
  private boolean _actif;

  /**
   * true ligne rompue false : ligne non rompue
   */
  private boolean _rompu;

  /**
   * Default constructor
   * 
   * @param existant_p
   * @param raccordable_p
   * @param commercialisable_p
   * @param actif_p
   * @param rompu_p
   */
  public StatutLigneFTTH(boolean existant_p, boolean raccordable_p, boolean commercialisable_p, boolean actif_p, boolean rompu_p)
  {
    _existant = existant_p;
    _raccordable = raccordable_p;
    _commercialisable = commercialisable_p;
    _actif = actif_p;
    _rompu = rompu_p;
  }

  @Override
  public boolean equals(Object o_p)
  {
    if (this == o_p)
    {
      return true;
    }
    if (o_p == null || getClass() != o_p.getClass())
    {
      return false;
    }
    StatutLigneFTTH that = (StatutLigneFTTH) o_p;
    return _existant == that._existant && _raccordable == that._raccordable && _commercialisable == that._commercialisable && _actif == that._actif && _rompu == that._rompu;
  }

  @Override
  public int hashCode()
  {
    return Objects.hash(_existant, _raccordable, _commercialisable, _actif, _rompu);
  }

  /**
   * @return value of actif
   */
  public boolean isActif()
  {
    return _actif;
  }

  /**
   * @return value of commercialisable
   */
  public boolean isCommercialisable()
  {
    return _commercialisable;
  }

  /**
   * @return value of existant
   */
  public boolean isExistant()
  {
    return _existant;
  }

  /**
   * @return value of raccordable
   */
  public boolean isRaccordable()
  {
    return _raccordable;
  }

  /**
   * @return value of rompu
   */
  public boolean isRompu()
  {
    return _rompu;
  }

  /**
   * @param actif_p
   *          The actif to set.
   */
  public void setActif(boolean actif_p)
  {
    _actif = actif_p;
  }

  /**
   * @param commercialisable_p
   *          The commercialisable to set.
   */
  public void setCommercialisable(boolean commercialisable_p)
  {
    _commercialisable = commercialisable_p;
  }

  /**
   * @param existant_p
   *          The existant to set.
   */
  public void setExistant(boolean existant_p)
  {
    _existant = existant_p;
  }

  /**
   * @param raccordable_p
   *          The raccordable to set.
   */
  public void setRaccordable(boolean raccordable_p)
  {
    _raccordable = raccordable_p;
  }

  /**
   * @param rompu_p
   *          The rompu to set.
   */
  public void setRompu(boolean rompu_p)
  {
    _rompu = rompu_p;
  }
}
