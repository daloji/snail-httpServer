/*******************************************************************************
* $Id: MAJRouteOptique.java 36070 2020-05-12 08:06:39Z fbarnabe $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connector.oi.emutation.structs;

import java.io.Serializable;

/**
 *
 * @author jstrub
 * @version ($Revision: 36070 $ $Date: 2020-05-12 10:06:39 +0200 (mar. 12 mai 2020) $)
 */
public final class MAJRouteOptique implements Serializable
{
  /**
   *
   * @author jstrub
   * @version ($Revision: 36070 $ $Date: 2020-05-12 10:06:39 +0200 (mar. 12 mai 2020) $)
   */
  public static final class MAJRouteOptiqueBuilder
  {

    /** Reference prise. */
    private String _referencePrise;
    /** Identifiant fibre. */
    private String _identifiantFibre;
    /** Identifiant fibre. */
    private String _refPrestationPrise;
    /** Motif mutation. */
    private String _motifMutation;
    /** References adresse. */
    private ReferencesAdresse _referencesAdresse;
    /** Complemenent adresse cmd. */
    private ComplementAdresse _complementAdresseCmd;
    /** Complemenent adresse terrain. */
    private ComplementAdresse _complementAdresseTerrain;
    /** Porte. */
    private String _porte;

    /**
     * Default Constructor
     */
    public MAJRouteOptiqueBuilder()
    {
      // Nothing to do
    }

    /**
     * @return a built {@link PBOs}
     */
    public MAJRouteOptique build()
    {
      return new MAJRouteOptique(_referencePrise, _identifiantFibre, _motifMutation, _referencesAdresse, _complementAdresseCmd, _complementAdresseTerrain, _porte, _refPrestationPrise);
    }

    /**
     * @param complementAdresseCmd_p
     *          the complementAdresseCmd
     * @return an instance of {@link MAJRouteOptiqueBuilder}
     */
    public MAJRouteOptiqueBuilder complementAdresseCmd(ComplementAdresse complementAdresseCmd_p)
    {
      _complementAdresseCmd = complementAdresseCmd_p;
      return this;
    }

    /**
     * @param complementAdresseTerrain_p
     *          the complementAdresseTerrain
     * @return an instance of {@link MAJRouteOptiqueBuilder}
     */
    public MAJRouteOptiqueBuilder complementAdresseTerrain(ComplementAdresse complementAdresseTerrain_p)
    {
      _complementAdresseTerrain = complementAdresseTerrain_p;
      return this;
    }

    /**
     * @param identifiantFibre_p
     *          the identifiantFibre
     * @return an instance of {@link MAJRouteOptiqueBuilder}
     */
    public MAJRouteOptiqueBuilder identifiantFibre(String identifiantFibre_p)
    {
      _identifiantFibre = identifiantFibre_p;
      return this;
    }

    /**
     * @param motifMutation_p
     *          the motifMutation
     * @return an instance of {@link MAJRouteOptiqueBuilder}
     */
    public MAJRouteOptiqueBuilder motifMutation(String motifMutation_p)
    {
      _motifMutation = motifMutation_p;
      return this;
    }

    /**
     * @param porte_p
     *          the porte
     * @return an instance of {@link MAJRouteOptiqueBuilder}
     */
    public MAJRouteOptiqueBuilder porte(String porte_p)
    {
      _porte = porte_p;
      return this;
    }

    /**
     * @param referencePrise_p
     *          the referencePrise
     * @return an instance of {@link MAJRouteOptiqueBuilder}
     */
    public MAJRouteOptiqueBuilder referencePrise(String referencePrise_p)
    {
      _referencePrise = referencePrise_p;
      return this;
    }

    /**
     * @param referencesAdresse_p
     *          the referencesAdresse
     * @return an instance of {@link MAJRouteOptiqueBuilder}
     */
    public MAJRouteOptiqueBuilder referencesAdresse(ReferencesAdresse referencesAdresse_p)
    {
      _referencesAdresse = referencesAdresse_p;
      return this;
    }

    /**
     * @param refPrestationPrise_p
     *          the refPrestationPrise
     * @return an instance of {@link MAJRouteOptiqueBuilder}
     */
    public MAJRouteOptiqueBuilder refPrestationPrise(String refPrestationPrise_p)
    {
      _refPrestationPrise = refPrestationPrise_p;
      return this;
    }

  }

  /** Unique Serial Identifier */
  private static final long serialVersionUID = 4009050280429265308L;

  /** Reference prise. */
  private final String _referencePrise;
  /** Identifiant fibre. */
  private final String _identifiantFibre;
  /** Motif mutation. */
  private final String _motifMutation;
  /** References adresse. */
  private final ReferencesAdresse _referencesAdresse;
  /** Complemenent adresse cmd. */
  private final ComplementAdresse _complementAdresseCmd;
  /** Complemenent adresse terrain. */
  private final ComplementAdresse _complementAdresseTerrain;
  /** Porte. */
  private final String _porte;
  /** Identifiant fibre. */
  private String _refPrestationPrise;

  /**
   * @param referencePrise_p
   *          the referencePrise
   * @param identifiantFibre_p
   *          the identifiantFibre
   * @param motifMutation_p
   *          the motifMutation
   * @param referencesAdresse_p
   *          the referencesAdresse
   * @param complementAdresseCmd_p
   *          the complementAdresseCmd
   * @param complementAdresseTerrain_p
   *          the complementAdresseTerrain
   * @param porte_p
   *          the porte
   * @param refPrestationPrise_p
   *          refPrestationPrise
   */
  public MAJRouteOptique(String referencePrise_p, String identifiantFibre_p, String motifMutation_p, ReferencesAdresse referencesAdresse_p, ComplementAdresse complementAdresseCmd_p, ComplementAdresse complementAdresseTerrain_p, String porte_p, String refPrestationPrise_p)
  {
    _referencePrise = referencePrise_p;
    _identifiantFibre = identifiantFibre_p;
    _motifMutation = motifMutation_p;
    _referencesAdresse = referencesAdresse_p;
    _complementAdresseCmd = complementAdresseCmd_p;
    _complementAdresseTerrain = complementAdresseTerrain_p;
    _porte = porte_p;
    _refPrestationPrise = refPrestationPrise_p;
  }

  /**
   * @return the complementAdresseCmd
   */
  public ComplementAdresse getComplementAdresseCmd()
  {
    return _complementAdresseCmd;
  }

  /**
   * @return the complementAdresseTerrain
   */
  public ComplementAdresse getComplementAdresseTerrain()
  {
    return _complementAdresseTerrain;
  }

  /**
   * @return the identifiantFibre
   */
  public String getIdentifiantFibre()
  {
    return _identifiantFibre;
  }

  /**
   * @return the motifMutation
   */
  public String getMotifMutation()
  {
    return _motifMutation;
  }

  /**
   * @return the porte
   */
  public String getPorte()
  {
    return _porte;
  }

  /**
   * @return the referencePrise
   */
  public String getReferencePrise()
  {
    return _referencePrise;
  }

  /**
   * @return the referencesAdresse
   */
  public ReferencesAdresse getReferencesAdresse()
  {
    return _referencesAdresse;
  }

  /**
   * @return the referencePrise
   */
  public String getRefPrestationPrise()
  {
    return _refPrestationPrise;
  }

}
