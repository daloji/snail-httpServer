/*******************************************************************************
* $Id: Fibre.java 10957 2018-09-28 10:12:37Z jstrub $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connector.oi.emutation.structs;

/**
 *
 * @author jstrub
 * @version ($Revision: 10957 $ $Date: 2018-09-28 12:12:37 +0200 (ven. 28 sept. 2018) $)
 */
public final class Fibre
{
  /**
   *
   * @author jstrub
   * @version ($Revision: 10957 $ $Date: 2018-09-28 12:12:37 +0200 (ven. 28 sept. 2018) $)
   */
  public static final class FibreBuilder
  {

    /** Identifiant fibre. */
    private String _identifiantFibre;
    /** Reference cable PBO. */
    private String _referenceCablePBO;
    /** Information tube PBO. */
    private String _informationTubePBO;
    /** Information fibre PBO. */
    private String _informationFibrePBO;
    /** Etat fibre. */
    private String _etatFibre;
    /** Reference prise. */
    private String _referencePrise;

    /**
     * Default Constructor
     */
    public FibreBuilder()
    {
      //Nothing to do
    }

    /**
     * @return a built {@link PBOs}
     */
    public Fibre build()
    {
      return new Fibre(_identifiantFibre, _referenceCablePBO, _informationTubePBO, _informationFibrePBO, _etatFibre, _referencePrise);
    }

    /**
     * @param etatFibre_p
     *          the etatFibre
     * @return an instance of {@link FibreBuilder}
     */
    public FibreBuilder etatFibre(String etatFibre_p)
    {
      _etatFibre = etatFibre_p;
      return this;
    }

    /**
     * @param identifiantFibre_p
     *          the identifiantFibre
     * @return an instance of {@link FibreBuilder}
     */
    public FibreBuilder identifiantFibre(String identifiantFibre_p)
    {
      _identifiantFibre = identifiantFibre_p;
      return this;
    }

    /**
     * @param informationFibrePBO_p
     *          the informationFibrePBO
     * @return an instance of {@link FibreBuilder}
     */
    public FibreBuilder informationFibrePBO(String informationFibrePBO_p)
    {
      _informationFibrePBO = informationFibrePBO_p;
      return this;
    }

    /**
     * @param informationTubePBO_p
     *          the informationTubePBO
     * @return an instance of {@link FibreBuilder}
     */
    public FibreBuilder informationTubePBO(String informationTubePBO_p)
    {
      _informationTubePBO = informationTubePBO_p;
      return this;
    }

    /**
     * @param referenceCablePBO_p
     *          the referenceCablePBO
     * @return an instance of {@link FibreBuilder}
     */
    public FibreBuilder referenceCablePBO(String referenceCablePBO_p)
    {
      _referenceCablePBO = referenceCablePBO_p;
      return this;
    }

    /**
     * @param referencePrise_p
     *          the referencePrise
     * @return an instance of {@link FibreBuilder}
     */
    public FibreBuilder referencePrise(String referencePrise_p)
    {
      _referencePrise = referencePrise_p;
      return this;
    }

  }

  /** Identifiant fibre. */
  private final String _identifiantFibre;
  /** Reference cable PBO. */
  private final String _referenceCablePBO;
  /** Information tube PBO. */
  private final String _informationTubePBO;
  /** Information fibre PBO. */
  private final String _informationFibrePBO;
  /** Etat fibre. */
  private final String _etatFibre;
  /** Reference prise. */
  private final String _referencePrise;

  /**
   * @param identifiantFibre_p
   *          the identifiantFibre
   * @param referenceCablePBO_p
   *          thereferenceCablePBO
   * @param informationTubePBO_p
   *          the informationTubePBO
   * @param informationFibrePBO_p
   *          the informationFibrePBO
   * @param etatFibre_p
   *          the etatFibre
   * @param referencePrise_p
   *          the referencePrise
   */
  public Fibre(String identifiantFibre_p, String referenceCablePBO_p, String informationTubePBO_p, String informationFibrePBO_p, String etatFibre_p, String referencePrise_p)
  {
    _identifiantFibre = identifiantFibre_p;
    _referenceCablePBO = referenceCablePBO_p;
    _informationTubePBO = informationTubePBO_p;
    _informationFibrePBO = informationFibrePBO_p;
    _etatFibre = etatFibre_p;
    _referencePrise = referencePrise_p;
  }

  /**
   * @return the etatFibre
   */
  public String getEtatFibre()
  {
    return _etatFibre;
  }

  /**
   * @return the identifiantFibre
   */
  public String getIdentifiantFibre()
  {
    return _identifiantFibre;
  }

  /**
   * @return the informationFibrePBO
   */
  public String getInformationFibrePBO()
  {
    return _informationFibrePBO;
  }

  /**
   * @return the informationTubePBO
   */
  public String getInformationTubePBO()
  {
    return _informationTubePBO;
  }

  /**
   * @return the referenceCablePBO
   */
  public String getReferenceCablePBO()
  {
    return _referenceCablePBO;
  }

  /**
   * @return the referencePrise
   */
  public String getReferencePrise()
  {
    return _referencePrise;
  }

}
