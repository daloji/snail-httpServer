
package com.bytel.spirit.common.connector.oi.aidecommande.structs.structureverticale.adresse;

import java.io.Serializable;
import java.util.Objects;

/**
 * @author jpais
 * @version ($Revision$ $Date$)
 */
public class ReferenceRivoli implements Serializable
{
  /** SErial UID */
  private static final long serialVersionUID = -251864630602665835L;

  /**
   * Code Insee de la commune correspondant à l’adresse ciblée.
   */
  private String _codeInsee;

  /**
   * Code Rivoli identifiant généralement la voie sur laquelle se trouve l’adresse ciblée.
   */
  private String _codeRivoli;

  /**
   * Numéro attribué à l’adresse ciblée dans la demande.
   */
  private Integer _numeroVoie;

  /**
   * Identique à ce qui est publié dans le CR MAD.
   */
  private String _complementNumeroVoie;

  /**
   * Default Constructor
   * 
   * @param codeInsee_p
   * @param codeRivoli_p
   * @param numeroVoie_p
   */
  public ReferenceRivoli(String codeInsee_p, String codeRivoli_p, Integer numeroVoie_p)
  {
    _codeInsee = codeInsee_p;
    _codeRivoli = codeRivoli_p;
    _numeroVoie = numeroVoie_p;
  }

  @Override
  public boolean equals(Object o_p)
  {
    if (this == o_p)
    {
      return true;
    }
    if (o_p == null || getClass() != o_p.getClass())
    {
      return false;
    }
    ReferenceRivoli that = (ReferenceRivoli) o_p;
    return _codeInsee.equals(that._codeInsee) && _codeRivoli.equals(that._codeRivoli) && _numeroVoie.equals(that._numeroVoie) && Objects.equals(_complementNumeroVoie, that._complementNumeroVoie);
  }

  /**
   * @return value of codeInsee
   */
  public String getCodeInsee()
  {
    return _codeInsee;
  }

  /**
   * @return value of codeRivoli
   */
  public String getCodeRivoli()
  {
    return _codeRivoli;
  }

  /**
   * @return value of complementNumeroVoie
   */
  public String getComplementNumeroVoie()
  {
    return _complementNumeroVoie;
  }

  /**
   * @return value of numeroVoie
   */
  public Integer getNumeroVoie()
  {
    return _numeroVoie;
  }

  @Override
  public int hashCode()
  {
    return Objects.hash(_codeInsee, _codeRivoli, _numeroVoie, _complementNumeroVoie);
  }

  /**
   * @param codeInsee_p
   *          The codeInsee to set.
   */
  public void setCodeInsee(String codeInsee_p)
  {
    _codeInsee = codeInsee_p;
  }

  /**
   * @param codeRivoli_p
   *          The codeRivoli to set.
   */
  public void setCodeRivoli(String codeRivoli_p)
  {
    _codeRivoli = codeRivoli_p;
  }

  /**
   * @param complementNumeroVoie_p
   *          The complementNumeroVoie to set.
   */
  public void setComplementNumeroVoie(String complementNumeroVoie_p)
  {
    _complementNumeroVoie = complementNumeroVoie_p;
  }

  /**
   * @param numeroVoie_p
   *          The numeroVoie to set.
   */
  public void setNumeroVoie(Integer numeroVoie_p)
  {
    _numeroVoie = numeroVoie_p;
  }
}
