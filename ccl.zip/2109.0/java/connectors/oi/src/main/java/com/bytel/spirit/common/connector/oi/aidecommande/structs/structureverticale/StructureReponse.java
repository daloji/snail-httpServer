
package com.bytel.spirit.common.connector.oi.aidecommande.structs.structureverticale;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

import com.bytel.spirit.common.connector.oi.aidecommande.structs.structureverticale.adresse.ReferenceAdresseReponse;
import com.bytel.spirit.common.connector.oi.aidecommande.structs.structureverticale.batiment.Batiment;
import com.bytel.spirit.common.shared.functional.types.ErreurOI;

/**
 * @author jpais
 * @version ($Revision$ $Date$)
 */
public class StructureReponse implements Serializable
{
  /**
   *
   * @author jstrub
   * @version ($Revision: 10997 $ $Date: 2018-10-01 17:27:30 +0200 (Mon, 01 Oct 2018) $)
   */
  public static final class StructureReponseBuilder
  {
    /** Identifiants. */
    private ReferenceAdresseReponse _adresse;

    /** StructureVerticale's batiments. */
    private List<Batiment> _batiments;

    /**
     * Default Constructor
     */
    public StructureReponseBuilder()
    {
      _adresse = new ReferenceAdresseReponse();
      _batiments = new ArrayList<>();
    }

    public StructureReponseBuilder adresse(ReferenceAdresseReponse adresse_p)
    {
      _adresse = adresse_p;
      return this;
    }

    /**
     * @param batiments_p
     *          batiments to add
     * @return an instance of {@link StructureReponseBuilder}
     */
    public StructureReponseBuilder batiments(List<Batiment> batiments_p)
    {
      if (batiments_p != null)
      {
        _batiments.addAll(batiments_p);
      }
      return this;
    }

    /**
     * @return a built {@link StructureReponse}
     */
    public StructureReponse build()
    {
      return new StructureReponse(_adresse, _batiments);
    }

  }

  /** Serial UID */
  private static final long serialVersionUID = -169146206046378782L;

  /**
   * Identifiants (Hexaclé, code rivoli…) de l’adresse liés à la demande.
   */
  private ReferenceAdresseReponse _adresse;

  /**
   * Dans le cas bâtiment non défini et notamment dans le cas, le bâtiment est nommé « NA» par défaut.
   */
  private List<Batiment> _batiments;

  /** Info sur l'erreur remontée par l'OI */
  private ErreurOI _erreurOI;

  /**
   * Default constructor.
   *
   * @param adresse_p
   * @param batiments_p
   */
  public StructureReponse(ReferenceAdresseReponse adresse_p, List<Batiment> batiments_p)
  {
    _adresse = adresse_p;
    _batiments = batiments_p == null ? Collections.emptyList() : new ArrayList<>(batiments_p);
  }

  /**
   * NOK constructor.
   *
   * @param erreurOI_p
   */
  public StructureReponse(ErreurOI erreurOI_p)
  {
    _batiments = Collections.emptyList();
    _erreurOI = erreurOI_p;
  }

  @Override
  public boolean equals(Object o_p)
  {
    if (this == o_p)
    {
      return true;
    }
    if (o_p == null || getClass() != o_p.getClass())
    {
      return false;
    }
    StructureReponse that = (StructureReponse) o_p;
    return Objects.equals(_adresse, that._adresse) && Objects.equals(_batiments, that._batiments) && Objects.equals(_erreurOI, that._erreurOI);
  }

  /**
   * @return value of adresse
   */
  public ReferenceAdresseReponse getAdresse()
  {
    return _adresse;
  }

  /**
   * @return value of batiments
   */
  public List<Batiment> getBatiments()
  {
    return _batiments == null ? null : new ArrayList<>(_batiments);
  }

  /**
   * @return value of _erreurOI
   */
  public ErreurOI getErreurOI()
  {
    return _erreurOI;
  }

  @Override
  public int hashCode()
  {
    return Objects.hash(_adresse, _batiments, _erreurOI);
  }

  /**
   * @param adresse_p
   *          The adresse to set.
   */
  public void setAdresse(ReferenceAdresseReponse adresse_p)
  {
    _adresse = adresse_p;
  }

  /**
   * @param batiments_p
   *          The batiments to set.
   */
  public void setBatiments(List<Batiment> batiments_p)
  {
    _batiments = batiments_p == null ? null : new ArrayList<>(batiments_p);
  }

  /**
   * @param erreurOI_p
   *          The _erreurOI to set.
   */
  public void setErreurOI(ErreurOI erreurOI_p)
  {
    _erreurOI = erreurOI_p;
  }
}
