
package com.bytel.spirit.common.connector.oi.aidecommande.structs.structureverticale.escalier;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

import com.bytel.spirit.common.connector.oi.aidecommande.structs.structureverticale.etage.Etage;

/**
 * @author jpais
 * @version ($Revision$ $Date$)
 */
public class Escalier implements Serializable
{
  /**
   *
   * @author jpais
   * @version ($Revision: 10997 $ $Date: 2018-10-01 17:27:30 +0200 (Mon, 01 Oct 2018) $)
   */
  public static final class EscalierBuilder
  {
    /** Access field {@link Escalier#_etages} */
    private final List<Etage> _etages;

    /** Access field {@link Escalier#_reference} */
    private String _reference;

    /**
     * Default Constructor
     */
    public EscalierBuilder()
    {
      _etages = new ArrayList<>();
    }

    /**
     * @return a built {@link Escalier}
     */
    public Escalier build()
    {
      return new Escalier(_reference, _etages);
    }

    /**
     * @param reference_p
     *          the reference to set
     * @return an instance of {@link EscalierBuilder}
     */
    public EscalierBuilder reference(String reference_p)
    {
      _reference = reference_p;
      return this;
    }

    /**
     * @param etages_p
     *          escaliers to add
     * @return an instance of {@link EscalierBuilder}
     */
    public EscalierBuilder etages(List<Etage> etages_p)
    {
      if (etages_p != null)
      {
        _etages.addAll(etages_p);
      }
      return this;
    }
  }

  /** Serial UID */
  private static final long serialVersionUID = -5754839284784194225L;

  /**
   * Nom de l’escalier tel que présent dans les bases de données de l’OI.
   */
  private String _reference;

  /**
   * Nombre d’occurrence de ce champ illimité.
   */
  private List<Etage> _etages;

  /**
   * Default constructor.
   * 
   * @param reference_p
   * @param etages_p
   */
  public Escalier(String reference_p, List<Etage> etages_p)
  {
    _reference = reference_p;
    _etages = etages_p == null ? Collections.emptyList() : new ArrayList<>(etages_p);
  }

  @Override
  public boolean equals(Object o_p)
  {
    if (this == o_p)
    {
      return true;
    }
    if (o_p == null || getClass() != o_p.getClass())
    {
      return false;
    }
    Escalier that = (Escalier) o_p;
    return _reference.equals(that._reference) && _etages.equals(that._etages);
  }

  /**
   * @return value of etages
   */
  public List<Etage> getEtages()
  {
    return _etages == null ? null : new ArrayList<>(_etages);
  }

  /**
   * @return value of reference
   */
  public String getReference()
  {
    return _reference;
  }

  @Override
  public int hashCode()
  {
    return Objects.hash(_reference, _etages);
  }

  /**
   * @param etages_p
   *          The etages to set.
   */
  public void setEtages(List<Etage> etages_p)
  {
    _etages = etages_p == null ? null : new ArrayList<>(etages_p);
  }

  /**
   * @param reference_p
   *          The reference to set.
   */
  public void setReference(String reference_p)
  {
    _reference = reference_p;
  }
}
