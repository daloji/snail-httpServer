
package com.bytel.spirit.common.connector.oi.aidecommande.structs.structureverticale.pm;

/**
 * @author jpais
 * @version ($Revision$ $Date$)
 */
public enum Brassage
{
  OC, OI;

  public static Brassage fromValue(String v)
  {
    return valueOf(v);
  }

  public String value()
  {
    return name();
  }

}
