/*******************************************************************************
* $Id: MAJRouteOptiqueResponse.java 11545 2018-10-12 14:12:21Z mfreire $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connector.oi.emutation.structs;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 *
 * @author jstrub
 * @version ($Revision: 11545 $ $Date: 2018-10-12 16:12:21 +0200 (ven. 12 oct. 2018) $)
 */
public class MAJRouteOptiqueResponse
{

  /**
   * Builder to build {@link MAJRouteOptiqueResponse}.
   */
  public static final class MAJRouteOptiqueResponseBuilder
  {

    /** The numeroDecharge. */
    private String _numeroDecharge;
    /** The routesOptiques. */
    private List<RouteOptique> _routesOptiques;
    /** The referencePrise. */
    private String _referencePrise;
    /** The referencePM. */
    private String _referencePM;
    /** The referencePMT. */
    private String _referencePMT;
    /** The referencePBO. */
    private String _referencePBO;

    /**
     * Default Constructor
     */
    public MAJRouteOptiqueResponseBuilder()
    {
      _routesOptiques = new ArrayList<>();
    }

    /**
     * Builder method of the builder.
     *
     * @return built class
     */
    public MAJRouteOptiqueResponse build()
    {
      return new MAJRouteOptiqueResponse(_numeroDecharge, _routesOptiques, _referencePrise, _referencePM, _referencePMT, _referencePBO);
    }

    /**
     * Builder method for _numeroDecharge parameter.
     *
     * @param numeroDecharge_p
     *          field to set
     * @return builder
     */
    public MAJRouteOptiqueResponseBuilder numeroDecharge(String numeroDecharge_p)
    {
      this._numeroDecharge = numeroDecharge_p;
      return this;
    }

    /**
     * Builder method for _referencePBO parameter.
     *
     * @param referencePBO_p
     *          field to set
     * @return builder
     */
    public MAJRouteOptiqueResponseBuilder referencePBO(String referencePBO_p)
    {
      this._referencePBO = referencePBO_p;
      return this;
    }

    /**
     * Builder method for _referencePM parameter.
     *
     * @param referencePM_p
     *          field to set
     * @return builder
     */
    public MAJRouteOptiqueResponseBuilder referencePM(String referencePM_p)
    {
      this._referencePM = referencePM_p;
      return this;
    }

    /**
     * Builder method for _referencePMT parameter.
     *
     * @param referencePMT_p
     *          field to set
     * @return builder
     */
    public MAJRouteOptiqueResponseBuilder referencePMT(String referencePMT_p)
    {
      this._referencePMT = referencePMT_p;
      return this;
    }

    /**
     * Builder method for _referencePrise parameter.
     *
     * @param referencePrise_p
     *          field to set
     * @return builder
     */
    public MAJRouteOptiqueResponseBuilder referencePrise(String referencePrise_p)
    {
      this._referencePrise = referencePrise_p;
      return this;
    }

    /**
     * Builder method for _routesOptiques parameter.
     *
     * @param routesOptiques_p
     *          field to set
     * @return builder
     */
    public MAJRouteOptiqueResponseBuilder routesOptiques(List<RouteOptique> routesOptiques_p)
    {
      if (routesOptiques_p != null)
      {
        this._routesOptiques.addAll(routesOptiques_p);
      }
      return this;
    }
  }

  /** The numeroDecharge. */
  private final String _numeroDecharge;
  /** The routesOptiques. */
  private final List<RouteOptique> _routesOptiques;
  /** The referencePrise. */
  private final String _referencePrise;
  /** The referencePM. */
  private final String _referencePM;
  /** The referencePMT. */
  private final String _referencePMT;
  /** The referencePBO. */
  private final String _referencePBO;

  /**
   * @param numeroDecharge_p
   *          the numeroDecharge
   * @param routesOptiques_p
   *          the routesOptiques
   * @param referencePrise_p
   *          the referencePrise
   * @param referencePM_p
   *          the referencePM
   * @param referencePMT_p
   *          the referencePMT
   * @param referencePBO_p
   *          the referencePBO
   */
  public MAJRouteOptiqueResponse(String numeroDecharge_p, List<RouteOptique> routesOptiques_p, String referencePrise_p, String referencePM_p, String referencePMT_p, String referencePBO_p)
  {
    _numeroDecharge = numeroDecharge_p;
    if (routesOptiques_p != null)
    {
      _routesOptiques = Collections.unmodifiableList(routesOptiques_p);
    }
    else
    {
      _routesOptiques = null;
    }
    _referencePrise = referencePrise_p;
    _referencePM = referencePM_p;
    _referencePMT = referencePMT_p;
    _referencePBO = referencePBO_p;
  }

  /**
   * @return the numeroDecharge
   */
  public String getNumeroDecharge()
  {
    return _numeroDecharge;
  }

  /**
   * @return the referencePBO
   */
  public String getReferencePBO()
  {
    return _referencePBO;
  }

  /**
   * @return the referencePM
   */
  public String getReferencePM()
  {
    return _referencePM;
  }

  /**
   * @return the referencePMT
   */
  public String getReferencePMT()
  {
    return _referencePMT;
  }

  /**
   * @return the referencePrise
   */
  public String getReferencePrise()
  {
    return _referencePrise;
  }

  /**
   * @return the routesOptiques
   */
  public List<RouteOptique> getRoutesOptiques()
  {
    if (_routesOptiques == null)
    {
      return new ArrayList<>();
    }

    return Collections.unmodifiableList(_routesOptiques);
  }

}
