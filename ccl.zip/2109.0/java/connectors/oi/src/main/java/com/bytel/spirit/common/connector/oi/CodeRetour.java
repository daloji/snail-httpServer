/*******************************************************************************
* $Id: CodeRetour.java 30024 2020-01-07 15:13:18Z jpais $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connector.oi;

/**
 *
 * @author jjoly
 * @version ($Revision: 30024 $ $Date: 2020-01-07 16:13:18 +0100 (mar. 07 janv. 2020) $)
 */
public final class CodeRetour
{
  /**
   *
   * @author jjoly
   * @version ($Revision: 30024 $ $Date: 2020-01-07 16:13:18 +0100 (mar. 07 janv. 2020) $)
   */
  public static final class CodeRetourConsts
  {
    /**
     * Traitement de la requête ok
     */
    public final static Integer OK = 0;

    /**
     * traitement de la requête incorrecte : problème fonctionnel
     */
    public final static Integer PROBLEME_FONCTIONNEL = 1;

    /**
     * traitement de la requête incorrecte : problème syntaxique
     */
    public final static Integer PROBLEME_SYNTAXIQUE = 2;

    /**
     * traitement de la requête incorrecte : problème technique
     */
    public final static Integer PROBLEME_TECHNIQUE = 3;

    /**
     * Default constructor
     */
    private CodeRetourConsts()
    {
      // Noithing to do
    }
  }

  /**
   * Code précisant le résultat de la requête et le type de cas d'erreur le cas échéant
   */
  private Integer _codeRetour;

  /**
   * Code de la première erreur rencontrée
   */
  private String _codeErreur;

  /**
   * Libellé du CodeErreur
   */
  private String _libelleErreur;

  /**
   * Constructor of recopy
   *
   * @param codeRetour_p
   *          Object to recopy
   */
  public CodeRetour(final CodeRetour codeRetour_p)
  {
    _codeRetour = codeRetour_p.getCodeRetour();
    _codeErreur = codeRetour_p.getCodeErreur();
    _libelleErreur = codeRetour_p.getLibelleErreur();
  }

  /**
   * Constructor
   *
   * @param codeRetour_p
   *          Code précisant le résultat de la requête et le type de cas d'erreur le cas échéant
   */
  public CodeRetour(final Integer codeRetour_p)
  {
    _codeRetour = codeRetour_p;
  }

  /**
   * Constructor
   *
   * @param codeRetour_p
   *          Code précisant le résultat de la requête et le type de cas d'erreur le cas échéant
   * @param codeErreur_p
   *          Code de la première erreur rencontrée
   * @param libelleErreur_p
   *          Libellé du CodeErreur
   */
  public CodeRetour(final Integer codeRetour_p, final String codeErreur_p, final String libelleErreur_p)
  {
    _codeRetour = codeRetour_p;
    _codeErreur = codeErreur_p;
    _libelleErreur = libelleErreur_p;
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    CodeRetour other = (CodeRetour) obj;
    if (_codeErreur == null)
    {
      if (other._codeErreur != null)
      {
        return false;
      }
    }
    else if (!_codeErreur.equals(other._codeErreur))
    {
      return false;
    }
    if (_codeRetour == null)
    {
      if (other._codeRetour != null)
      {
        return false;
      }
    }
    else if (!_codeRetour.equals(other._codeRetour))
    {
      return false;
    }
    if (_libelleErreur == null)
    {
      if (other._libelleErreur != null)
      {
        return false;
      }
    }
    else if (!_libelleErreur.equals(other._libelleErreur))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the codeErreur
   */
  public final String getCodeErreur()
  {
    return _codeErreur;
  }

  /**
   * @return the codeRetour
   */
  public final Integer getCodeRetour()
  {
    return _codeRetour;
  }

  /**
   * @return the libelleErreur
   */
  public final String getLibelleErreur()
  {
    return _libelleErreur;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_codeErreur == null) ? 0 : _codeErreur.hashCode());
    result = (prime * result) + ((_codeRetour == null) ? 0 : _codeRetour.hashCode());
    result = (prime * result) + ((_libelleErreur == null) ? 0 : _libelleErreur.hashCode());
    return result;
  }

  /**
   * @param codeErreur_p
   *          the codeErreur to set
   */
  public final void setCodeErreur(final String codeErreur_p)
  {
    _codeErreur = codeErreur_p;
  }

  /**
   * @param codeRetour_p
   *          the codeRetour to set
   */
  public final void setCodeRetour(final Integer codeRetour_p)
  {
    _codeRetour = codeRetour_p;
  }

  /**
   * @param libelleErreur_p
   *          the libelleErreur to set
   */
  public final void setLibelleErreur(final String libelleErreur_p)
  {
    _libelleErreur = libelleErreur_p;
  }

  @Override
  public String toString()
  {
    StringBuilder builder = new StringBuilder();
    builder.append("CodeRetour [_codeRetour="); //$NON-NLS-1$
    builder.append(_codeRetour);
    builder.append(", _codeErreur="); //$NON-NLS-1$
    builder.append(_codeErreur);
    builder.append(", _libelleErreur="); //$NON-NLS-1$
    builder.append(_libelleErreur);
    builder.append("]"); //$NON-NLS-1$
    return builder.toString();
  }
}
