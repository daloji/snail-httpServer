/*******************************************************************************
* $Id: ReferencesAdresse.java 11545 2018-10-12 14:12:21Z mfreire $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connector.oi.emutation.structs;

import java.io.Serializable;

/**
 *
 * @author jstrub
 * @version ($Revision: 11545 $ $Date: 2018-10-12 16:12:21 +0200 (ven. 12 oct. 2018) $)
 */
public final class ReferencesAdresse implements Serializable
{

  /**
   * Builder to build {@link ReferencesAdresse}.
   */
  public static final class ReferencesAdresseBuilder
  {
    /** Hexacle. */
    private String _hexacle;
    /** Rivoli. */
    private QuadrupletRivoli _rivoli;
    /** Hexacle voie. */
    private HexacleVoie _hexacleVoie;
    /** Reference geographique. */
    private CoordonneesGeo _referenceGeographique;
    /** Identifiant immeuble. */
    private String _identifiantImmeuble;
    /** Adresse libre. */
    private String _adresseLibre;

    /**
     * Default constructor
     */
    public ReferencesAdresseBuilder()
    {
      // Nothing to do
    }

    /**
     * Builder method for _adresseLibre parameter.
     *
     * @param adresseLibre_p
     *          field to set
     * @return builder
     */
    public ReferencesAdresseBuilder adresseLibre(String adresseLibre_p)
    {
      this._adresseLibre = adresseLibre_p;
      return this;
    }

    /**
     * Builder method of the builder.
     *
     * @return built class
     */
    public ReferencesAdresse build()
    {
      return new ReferencesAdresse(_hexacle, _rivoli, _hexacleVoie, _referenceGeographique, _identifiantImmeuble, _adresseLibre);
    }

    /**
     * Builder method for _hexacle parameter.
     *
     * @param hexacle_p
     *          field to set
     * @return builder
     */
    public ReferencesAdresseBuilder hexacle(String hexacle_p)
    {
      this._hexacle = hexacle_p;
      return this;
    }

    /**
     * Builder method for _hexacleVoie parameter.
     *
     * @param hexacleVoie_p
     *          field to set
     * @return builder
     */
    public ReferencesAdresseBuilder hexacleVoie(HexacleVoie hexacleVoie_p)
    {
      this._hexacleVoie = hexacleVoie_p;
      return this;
    }

    /**
     * Builder method for _identifiantImmeuble parameter.
     *
     * @param identifiantImmeuble_p
     *          field to set
     * @return builder
     */
    public ReferencesAdresseBuilder identifiantImmeuble(String identifiantImmeuble_p)
    {
      this._identifiantImmeuble = identifiantImmeuble_p;
      return this;
    }

    /**
     * Builder method for _referenceGeographique parameter.
     *
     * @param referenceGeographique_p
     *          field to set
     * @return builder
     */
    public ReferencesAdresseBuilder referenceGeographique(CoordonneesGeo referenceGeographique_p)
    {
      this._referenceGeographique = referenceGeographique_p;
      return this;
    }

    /**
     * Builder method for _rivoli parameter.
     *
     * @param rivoli_p
     *          field to set
     * @return builder
     */
    public ReferencesAdresseBuilder rivoli(QuadrupletRivoli rivoli_p)
    {
      this._rivoli = rivoli_p;
      return this;
    }
  }

  /** Unique Serial Identifier */
  private static final long serialVersionUID = 1632977315248578022L;

  /** Hexacle. */
  private final String _hexacle;
  /** Rivoli. */
  private final QuadrupletRivoli _rivoli;
  /** Hexacle voie. */
  private final HexacleVoie _hexacleVoie;
  /** Reference geographique. */
  private final CoordonneesGeo _referenceGeographique;
  /** Identifiant immeuble. */
  private final String _identifiantImmeuble;
  /** Adresse libre. */
  private final String _adresseLibre;

  /**
   * @param hexacle_p
   *          the hexacle
   * @param rivoli_p
   *          the rivoli
   * @param hexacleVoie_p
   *          the hexacleVoie
   * @param referenceGeographique_p
   *          the referenceGeographique
   * @param identifiantImmeuble_p
   *          the identifiantImmeuble
   * @param adresseLibre_p
   *          the adresseLibre
   */
  public ReferencesAdresse(String hexacle_p, QuadrupletRivoli rivoli_p, HexacleVoie hexacleVoie_p, CoordonneesGeo referenceGeographique_p, String identifiantImmeuble_p, String adresseLibre_p)
  {
    _hexacle = hexacle_p;
    _rivoli = rivoli_p;
    _hexacleVoie = hexacleVoie_p;
    _referenceGeographique = referenceGeographique_p;
    _identifiantImmeuble = identifiantImmeuble_p;
    _adresseLibre = adresseLibre_p;
  }

  /**
   * @return the adresseLibre
   */
  public String getAdresseLibre()
  {
    return _adresseLibre;
  }

  /**
   * @return the hexacle
   */
  public String getHexacle()
  {
    return _hexacle;
  }

  /**
   * @return the hexacleVoie
   */
  public HexacleVoie getHexacleVoie()
  {
    return _hexacleVoie;
  }

  /**
   * @return the identifiantImmeuble
   */
  public String getIdentifiantImmeuble()
  {
    return _identifiantImmeuble;
  }

  /**
   * @return the referenceGeographique
   */
  public CoordonneesGeo getReferenceGeographique()
  {
    return _referenceGeographique;
  }

  /**
   * @return the rivoli
   */
  public QuadrupletRivoli getRivoli()
  {
    return _rivoli;
  }

}
