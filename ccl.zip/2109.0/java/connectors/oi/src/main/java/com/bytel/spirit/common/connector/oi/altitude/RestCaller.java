/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connector.oi.altitude;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.MessageFormat;
import java.util.Objects;
import java.util.stream.Collectors;

import javax.ws.rs.core.MultivaluedHashMap;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionTools;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.log.event.SystemLogEvent;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.net.rest.RestInstance;
import com.bytel.ravel.services.connector.RESTRequest;
import com.bytel.spirit.common.shared.functional.types.json.RavelJsonTools;

/**
 * REST Caller (for authentication).
 * 
 * @author mlebihan
 * @version ($Revision$ $Date$)
 */
public class RestCaller
{
  /** Proxy Login. */
  private String _proxyLogin;

  /** Proxy Password. */
  private String _proxyPassword;

  /** Proxy Host. */
  private String _proxyHost;

  /** Proxy Port. */
  private int _proxyPort;

  /** Timeout. */
  private int _timeout;

  /** Secure socket protocol. */
  private String _secureSocketProtocol;

  /** Disable CN checks. */
  private boolean _disableCnCheck;

  /** URL. */
  private URL _url;

  /** Name of this REST connection. */
  private String _name;

  /**
   * Construct an Altitude Authentifcation Service.
   *
   * @param name_p
   *          Name of that REST connection.
   * @param completeUrl_p
   *          Complete URL of the REST service.
   * @param timeout_p
   *          Timeout.
   * @param proxyLogin_p
   *          Proxy Login.
   * @param proxyPassword_p
   *          Proxy password.
   * @param proxyHost_p
   *          Proxy host.
   * @param proxyPort_p
   *          Proxy port.
   * @param secureSocketProtocol_p
   *          SecureSocket protocol.
   * @param disableCnCheck_p
   *          Disable CN check if true.
   * @throws MalformedURLException
   *           if url is malformed.
   */
  public RestCaller(String name_p, String completeUrl_p, int timeout_p, //
      String proxyLogin_p, String proxyPassword_p, String proxyHost_p, int proxyPort_p, String secureSocketProtocol_p, //
      boolean disableCnCheck_p) throws MalformedURLException
  {
    _proxyLogin = proxyLogin_p;
    _proxyPassword = proxyPassword_p;
    _proxyHost = proxyHost_p;
    _proxyPort = proxyPort_p;
    _timeout = timeout_p;
    _secureSocketProtocol = secureSocketProtocol_p;
    _disableCnCheck = disableCnCheck_p;
    _url = new URL(completeUrl_p);
    _name = name_p;
  }

  /**
   * Get the entity from the response.
   *
   * @param response_p
   *          HTTP response
   * @return Instance of {@link String}
   * @throws RavelException
   *           if the entity cannot be extracted from the response.
   */
  public String getEntityFromResponse(Response response_p) throws RavelException
  {
    Objects.requireNonNull(response_p, "REST response from which extract entity cannot be null."); //$NON-NLS-1$

    try
    {
      Object o = response_p.getEntity();

      // Allow InputStream response, containing lines of text.
      if (o instanceof InputStream)
      {
        InputStream returnStream = (InputStream) response_p.getEntity();
        return new BufferedReader(new InputStreamReader(returnStream)).lines().collect(Collectors.joining(StringConstants.EMPTY_STRING));
      }

      // Allow a String.
      if (o instanceof String)
      {
        return (String) o;
      }

      String format = "Unable to extract entity object from REST {1} call response. Response is an object of class {0} and not one of String or InputStream (containing lines of a String) expected."; //$NON-NLS-1$
      StringBuilder message = new StringBuilder(MessageFormat.format(format, o != null ? o.getClass().getSimpleName() : null, _name));

      RavelException ex = new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, message.toString());
      RavelLogger.log(new SystemLogEvent(LogSeverity.WARNING, null, ex)); // No msgId.
      throw ex;
    }
    catch (RuntimeException exception)
    {
      String format = "Unable to extract entity object from REST {1} call response : ''{0}''."; //$NON-NLS-1$
      StringBuilder message = new StringBuilder(MessageFormat.format(format, exception.getMessage(), _name));
      message.append(ExceptionTools.getExceptionLineAndFile(exception));

      RavelException ex = new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, message.toString());
      RavelLogger.log(new SystemLogEvent(LogSeverity.WARNING, null, ex)); // No msgId.
      throw ex;
    }
  }

  /**
   * Send a REST request and receive a generic response.
   *
   * @param restRequest_p
   *          REST Request
   * @return response
   * @throws RavelException
   *           if an internal REST server error occurs, or if the send or receive operation of the REST call fails.
   */
  public Response send(RESTRequest restRequest_p) throws RavelException
  {
    Objects.requireNonNull(restRequest_p, "Cannot send a null REST request."); //$NON-NLS-1$
    RestInstance restInstance = restInstance();

    try
    {
      // Override REST instance timeout if request ask so.
      if (restRequest_p.getTimeout() != -1)
      {
        restInstance.setReceiveTimeout(restRequest_p.getTimeout());
      }

      // Perform the REST GET operation.
      Response result = get(restInstance, restRequest_p);

      //INTERNAL SERVER ERROR test server is UP
      if ((result != null) && (Status.INTERNAL_SERVER_ERROR.getStatusCode() == result.getStatus()))
      {
        String message = MessageFormat.format("Internal server error during REST call {0}.", _name); //$NON-NLS-1$

        RavelException ex = new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, message);
        RavelLogger.log(new SystemLogEvent(LogSeverity.WARNING, message)); // No msgId.
        throw ex;
      }

      return result;
    }
    catch (RuntimeException exception)
    {
      String format = "Unable to send REST call {0} or to receive response from it : ''{1}''."; //$NON-NLS-1$
      StringBuilder message = new StringBuilder(MessageFormat.format(format, _name, exception.getMessage()));
      message.append(ExceptionTools.getExceptionLineAndFile(exception));

      RavelException ex = new RavelException(ExceptionType.HTTP_CONNECTION_ERROR, ErrorCode.CNCTOR_00010, message.toString());
      RavelLogger.log(new SystemLogEvent(LogSeverity.ERROR, null, message.toString()));
      RavelLogger.log(new SystemLogEvent(LogSeverity.DEBUG, null, ex)); // No msgId.
      throw ex;
    }
  }

  /**
   * Send a request and receive a response from REST call, then parse it to deserialize it into an object.
   *
   * @param restRequest
   *          REST request.
   * @param responseObjectClass
   *          Class of the object to extract from the json response.
   * @return Object returned by the rest Request.
   * @throws RavelException
   *           if an internal REST server error occurs, or if the send or receive operation of the REST call fails, or
   *           if the entity cannot be extracted from the response, or if the JSON received from the REST call is not
   *           parsable or cannot be converted to the wished object, or if the JSON received from the REST call is
   *           empty.
   */
  public <C> C sendAndReceiveFromJson(RESTRequest restRequest, Class<C> responseObjectClass) throws RavelException
  {
    Objects.requireNonNull(restRequest, "REST request to send and from whom receive an object cannot be null."); //$NON-NLS-1$
    Objects.requireNonNull(responseObjectClass, "The class of the entity object extracted from the REST response cannot be null."); //$NON-NLS-1$

    Response response = send(restRequest);
    String jsonResponse = getEntityFromResponse(response);

    // The JSON received cannot be empty or null.
    if (StringTools.isNullOrEmpty(jsonResponse))
    {
      String message = MessageFormat.format("Empty JSON response received from REST call {0}.", _name); //$NON-NLS-1$

      RavelException ex = new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, message);
      RavelLogger.log(new SystemLogEvent(LogSeverity.WARNING, null, ex)); // No msgId.
      throw ex;
    }

    // Attempt to deserialize the JSON received to an object of the wished class.
    try
    {
      return RavelJsonTools.getInstance().fromJson(jsonResponse, responseObjectClass);
    }
    catch (RavelException exception)
    {
      String format = "Invalid JSON content received from REST call {2}, that cannot be parsed or resolved to an object of class {0} : ''{1}''."; //$NON-NLS-1$
      StringBuilder message = new StringBuilder(MessageFormat.format(format, responseObjectClass.getSimpleName(), exception.getMessage(), _name));
      message.append(ExceptionTools.getExceptionLineAndFile(exception));

      RavelException ex = new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, message.toString());
      RavelLogger.log(new SystemLogEvent(LogSeverity.WARNING, null, ex)); // No msgId.
      throw ex;
    }
  }

  /**
   * Perform the concrete REST call with a GET method.
   *
   * @param restInstance
   *          Rest instance.
   * @param restRequest_p
   *          Request.
   * @return JAX-RS Response.
   */
  private Response get(RestInstance restInstance, RESTRequest restRequest_p)
  {
    return restInstance.get(restRequest_p.getPath(), new MultivaluedHashMap<String, String>(restRequest_p.getHeaders()), restRequest_p.getQueryParameters());
  }

  /**
   * Return a REST instance.
   *
   * @return Rest instance.
   */
  private RestInstance restInstance()
  {
    RestInstance restInstance = new RestInstance(_url.toString());
    restInstance.setReceiveTimeout(_timeout);

    // Set the proxy parameters if the proxy host is filled.
    if (StringTools.isNotNullOrEmpty(_proxyHost))
    {
      restInstance.setProxy(_proxyLogin, _proxyPassword, _proxyHost, _proxyPort);
    }

    // Set the secure socket protocol parameters if defined.
    if (StringTools.isNotNullOrEmpty(_secureSocketProtocol))
    {
      restInstance.setSecureSocketProtocol(_secureSocketProtocol, _disableCnCheck);
    }

    return restInstance;
  }
}
