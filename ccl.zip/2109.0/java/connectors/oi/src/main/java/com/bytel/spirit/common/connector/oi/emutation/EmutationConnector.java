/*******************************************************************************
* $Id: EmutationConnector.java 42468 2020-10-20 14:22:26Z fbarnabe $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connector.oi.emutation;

import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.common.uuid.UUIDManager;
import com.bytel.ravel.services.conf.connector.generated.Connector;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.connector.oi.CodeRetour;
import com.bytel.spirit.common.connector.oi.CodeRetour.CodeRetourConsts;
import com.bytel.spirit.common.connector.oi.emutation.structs.Adresse.AdresseBuilder;
import com.bytel.spirit.common.connector.oi.emutation.structs.ComplementAdresse;
import com.bytel.spirit.common.connector.oi.emutation.structs.CoordonneesGeo;
import com.bytel.spirit.common.connector.oi.emutation.structs.Fibre;
import com.bytel.spirit.common.connector.oi.emutation.structs.Fibre.FibreBuilder;
import com.bytel.spirit.common.connector.oi.emutation.structs.Fibres;
import com.bytel.spirit.common.connector.oi.emutation.structs.Fibres.FibresBuilder;
import com.bytel.spirit.common.connector.oi.emutation.structs.HexacleVoie;
import com.bytel.spirit.common.connector.oi.emutation.structs.MAJRouteOptique;
import com.bytel.spirit.common.connector.oi.emutation.structs.MAJRouteOptiqueResponse;
import com.bytel.spirit.common.connector.oi.emutation.structs.MAJRouteOptiqueResponse.MAJRouteOptiqueResponseBuilder;
import com.bytel.spirit.common.connector.oi.emutation.structs.PBO;
import com.bytel.spirit.common.connector.oi.emutation.structs.PBO.PBOBuilder;
import com.bytel.spirit.common.connector.oi.emutation.structs.PBOs;
import com.bytel.spirit.common.connector.oi.emutation.structs.PBOs.PBOsBuilder;
import com.bytel.spirit.common.connector.oi.emutation.structs.PositionPM.PositionPMBuilder;
import com.bytel.spirit.common.connector.oi.emutation.structs.QuadrupletRivoli;
import com.bytel.spirit.common.connector.oi.emutation.structs.ReferencesAdresse;
import com.bytel.spirit.common.connector.oi.emutation.structs.ReferencesAdresse.ReferencesAdresseBuilder;
import com.bytel.spirit.common.connector.oi.emutation.structs.RouteOptique.RouteOptiqueBuilder;
import com.bytel.spirit.common.generated.configfluxOI.ConfigFluxOI;
import com.bytel.spirit.common.generated.ws.ftth.emutation.ConsultationFibres;
import com.bytel.spirit.common.generated.ws.ftth.emutation.ConsultationFibresResponse;
import com.bytel.spirit.common.generated.ws.ftth.emutation.CoordonneesGeographiquesType;
import com.bytel.spirit.common.generated.ws.ftth.emutation.Emutation;
import com.bytel.spirit.common.generated.ws.ftth.emutation.EmutationConsultationFibresFaultMessage;
import com.bytel.spirit.common.generated.ws.ftth.emutation.EmutationDefaultFaultMessage;
import com.bytel.spirit.common.generated.ws.ftth.emutation.EmutationFunctionalFaultMessage;
import com.bytel.spirit.common.generated.ws.ftth.emutation.EmutationMiseAJourRouteOptiqueFaultMessage;
import com.bytel.spirit.common.generated.ws.ftth.emutation.EmutationTechnicalFaultMessage;
import com.bytel.spirit.common.generated.ws.ftth.emutation.EnteteRequeteType;
import com.bytel.spirit.common.generated.ws.ftth.emutation.FibreType;
import com.bytel.spirit.common.generated.ws.ftth.emutation.MiseAJourRouteOptique;
import com.bytel.spirit.common.generated.ws.ftth.emutation.MiseAJourRouteOptiqueResponse;
import com.bytel.spirit.common.generated.ws.ftth.emutation.MotifMutationType;
import com.bytel.spirit.common.generated.ws.ftth.emutation.OperateurCommercialType;
import com.bytel.spirit.common.generated.ws.ftth.emutation.PboType;
import com.bytel.spirit.common.generated.ws.ftth.emutation.RecherchePBO;
import com.bytel.spirit.common.generated.ws.ftth.emutation.RecherchePBOResponse;
import com.bytel.spirit.common.generated.ws.ftth.emutation.ReferenceAdresseDemandeType;
import com.bytel.spirit.common.generated.ws.ftth.emutation.ReferenceHexacleVoieType;
import com.bytel.spirit.common.generated.ws.ftth.emutation.ReferenceRivoliType;
import com.bytel.spirit.common.generated.ws.ftth.emutation.RouteOptique;
import com.bytel.spirit.common.shared.misc.connectors.AbstractSpiritSOAPConnector;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

/**
 * Implémentation concrète de {@link AbstractSpiritSOAPConnector} dédiée aux connecteurs OI pour les web-services
 * eMutation.
 *
 * @author jstrub
 * @version ($Revision: 42468 $ $Date: 2020-10-20 16:22:26 +0200 (mar. 20 oct. 2020) $)
 */
public final class EmutationConnector extends AbstractSpiritSOAPConnector
{
  /** SOAP Method recherchePBO. */
  private static final String RECHERCHE_PBO_SOAP_METHOD = "RecherchePBO"; //$NON-NLS-1$
  /** SOAP Method consultationFibres. */
  private static final String CONSULTATION_FIBRES_SOAP_METHOD = "ConsultationFibres"; //$NON-NLS-1$
  /** SOAP Method miseAJourRouteOptique. */
  private static final String MISE_A_JOUR_ROUTE_OPTIQUE_SOAP_METHOD = "MiseAJourRouteOptique"; //$NON-NLS-1$

  /**
   * Consultation fibre, via les références PM et PBO.
   *
   * @param tracabilite_p
   *          objet de tracabilité Spirit
   * @param config_p
   *          OI configuration
   * @param referencePM_p
   *          reference PM
   * @param referencePBO_p
   *          reference PBO
   * @param refPrestationPrise_p
   *          reference prestation prise
   * @return représentation interne d'une {@link Fibres} et {@link CodeRetour} associé à la réponse
   * @throws RavelException
   *           exception lors de l'échange SOAP
   */
  public ConnectorResponse<Fibres, CodeRetour> consultationFibres(Tracabilite tracabilite_p, ConfigFluxOI config_p, String referencePM_p, String referencePBO_p, String refPrestationPrise_p) throws RavelException
  {
    ConsultationFibres request = new ConsultationFibres();
    request.setEntete(createEntete(config_p));

    request.setReferencePBO(referencePBO_p);
    request.setReferencePM(referencePM_p);
    request.setReferencePrestationPrise(refPrestationPrise_p);

    try
    {
      ConsultationFibresResponse response = sendRequest(tracabilite_p, CONSULTATION_FIBRES_SOAP_METHOD, request);

      List<Fibre> fibres = new ArrayList<>();
      for (FibreType fibreSoap : response.getFibres().getFibres())
      {
        FibreBuilder builder = new FibreBuilder();

        builder.etatFibre(fibreSoap.getEtatFibre().value());
        builder.identifiantFibre(fibreSoap.getIdentifiantFibre());
        builder.informationFibrePBO(fibreSoap.getInformationFibrePBO());
        builder.informationTubePBO(fibreSoap.getInformationTubePBO());
        builder.referenceCablePBO(fibreSoap.getReferenceCablePBO());
        builder.referencePrise(fibreSoap.getReferencePrise());

        fibres.add(builder.build());
      }

      return new ConnectorResponse<>(new FibresBuilder().fibres(fibres).build(), new CodeRetour(CodeRetourConsts.OK));

    }
    catch (RavelException exception)
    {
      // Specific fault handling
      if (EmutationConsultationFibresFaultMessage.class.isInstance(exception.getCause()))
      {
        EmutationConsultationFibresFaultMessage fault = (EmutationConsultationFibresFaultMessage) exception.getCause();
        if (fault.getFaultInfo() != null)
        {
          String code = fault.getFaultInfo().getCodeErreur().value();
          String libelle = fault.getFaultInfo().getLibelleErreur().value();
          return new ConnectorResponse<>(null, new CodeRetour(CodeRetourConsts.PROBLEME_FONCTIONNEL, code, libelle));
        }
      }

      // Common fault handling
      CodeRetour commonCodeRetour = handleCommonFault(exception);
      if (commonCodeRetour != null)
      {
        return new ConnectorResponse<>(null, commonCodeRetour);
      }

      // Rethrow if no error response
      throw exception;
    }
  }

  @Override
  public String getConfigParameter(String connectorID_p, String paramName_p) throws RavelException
  {
    // Nothing to do
    return null;
  }

  @Override
  public void loadConnectorConfiguration(Connector connector_p) throws RavelException
  {
    setServiceInterfaceClass(Emutation.class);
    super.loadConnectorConfiguration(connector_p);
  }

  /**
   * Mise à jour d'une route optique, via un objet structuré majRouteOptique
   *
   * @param tracabilite_p
   *          objet de tracabilité Spirit
   * @param config_p
   *          OI configuration
   * @param majRouteOptique_p
   *          objet structuré majRouteOptique
   * @return le numéro de décharge et {@link CodeRetour} associé à la réponse
   * @throws RavelException
   *           exception lors de l'échange SOAP
   */
  public ConnectorResponse<MAJRouteOptiqueResponse, CodeRetour> miseAJourRouteOptique(Tracabilite tracabilite_p, ConfigFluxOI config_p, MAJRouteOptique majRouteOptique_p) throws RavelException
  {
    MiseAJourRouteOptique request = mapMajRouteOptiqueRequest(config_p, majRouteOptique_p);

    try
    {
      MiseAJourRouteOptiqueResponse soapResponse = sendRequest(tracabilite_p, MISE_A_JOUR_ROUTE_OPTIQUE_SOAP_METHOD, request);
      MAJRouteOptiqueResponseBuilder responseBuilder = new MAJRouteOptiqueResponseBuilder();
      responseBuilder.numeroDecharge(soapResponse.getNumeroDecharge());
      responseBuilder.referencePBO(soapResponse.getReferencePBO());
      responseBuilder.referencePM(soapResponse.getReferencePM());
      responseBuilder.referencePMT(soapResponse.getReferencePMT());
      responseBuilder.referencePrise(soapResponse.getReferencePrise());

      List<com.bytel.spirit.common.connector.oi.emutation.structs.RouteOptique> routes = new ArrayList<>();
      for (RouteOptique soapRoute : soapResponse.getRoutesOptiques().getRoutesOptiques())
      {
        RouteOptiqueBuilder routeBuilder = new RouteOptiqueBuilder();
        routeBuilder.connecteurPriseCouleur(soapRoute.getConnecteurPriseCouleur());
        routeBuilder.connecteurPriseNumero(soapRoute.getConnecteurPriseNumero());
        routeBuilder.informationFibrePBO(soapRoute.getInformationFibrePBO());
        routeBuilder.informationTubePBO(soapRoute.getInformationTubePBO());
        routeBuilder.referenceCablePBO(soapRoute.getReferenceCablePBO());
        routeBuilder.oc(soapRoute.getOC());

        if (soapRoute.getPositionPm() != null)
        {
          PositionPMBuilder positionBuilder = new PositionPMBuilder();
          positionBuilder.infoFibreModulePM(soapRoute.getPositionPm().getInfoFibreModulePM());
          positionBuilder.infoTubeModulePM(soapRoute.getPositionPm().getInfoTubeModulePM());
          positionBuilder.nomModulePM(soapRoute.getPositionPm().getNomModulePM());
          positionBuilder.positionModulePM(soapRoute.getPositionPm().getPositionModulePM());
          positionBuilder.referenceCableModulePM(soapRoute.getPositionPm().getReferenceCableModulePM());
          routeBuilder.positionPM(positionBuilder.build());
        }

        routes.add(routeBuilder.build());
      }
      responseBuilder.routesOptiques(routes);

      return new ConnectorResponse<>(responseBuilder.build(), new CodeRetour(CodeRetourConsts.OK));

    }
    catch (RavelException exception)
    {
      // Specific fault handling
      if (EmutationMiseAJourRouteOptiqueFaultMessage.class.isInstance(exception.getCause()))
      {
        EmutationMiseAJourRouteOptiqueFaultMessage fault = (EmutationMiseAJourRouteOptiqueFaultMessage) exception.getCause();
        if (fault.getFaultInfo() != null)
        {
          String code = fault.getFaultInfo().getCodeErreur().value();
          String libelle = fault.getFaultInfo().getLibelleErreur().value();
          return new ConnectorResponse<>(null, new CodeRetour(CodeRetourConsts.PROBLEME_FONCTIONNEL, code, libelle));
        }
      }

      // Common fault handling
      CodeRetour commonCodeRetour = handleCommonFault(exception);
      if (commonCodeRetour != null)
      {
        return new ConnectorResponse<>(null, commonCodeRetour);
      }

      // Rethrow if no error response
      throw exception;
    }
  }

  /**
   * Recherche de la liste des PBO, via une référence de prestation
   *
   * @param tracabilite_p
   *          objet de tracabilité Spirit
   * @param config_p
   *          OI configuration
   * @param refPrestationPrise_p
   *          référence de la prestation
   * @return représentation interne d'une {@link PBOs} et {@link CodeRetour} associé à la réponse
   * @throws RavelException
   *           exception lors de l'échange SOAP
   */
  public ConnectorResponse<PBOs, CodeRetour> recherchePBO(Tracabilite tracabilite_p, ConfigFluxOI config_p, String refPrestationPrise_p) throws RavelException
  {
    RecherchePBO request = new RecherchePBO();
    request.setEntete(createEntete(config_p));

    request.setReferencePrestationPrise(refPrestationPrise_p);

    try
    {
      RecherchePBOResponse response = sendRequest(tracabilite_p, RECHERCHE_PBO_SOAP_METHOD, request);

      List<PBO> pbos = new ArrayList<>();
      for (PboType pboSoap : response.getListePBO().getPbos())
      {
        PBOBuilder pboBuilder = new PBOBuilder();
        pboBuilder.naturePBO(pboSoap.getNaturePBO());
        pboBuilder.nombreFibresDisponibles(pboSoap.getNombreFibresDisponibles());
        pboBuilder.referencePBO(pboSoap.getReferencePBO());
        pboBuilder.referencePM(pboSoap.getReferencePM());

        if ((pboSoap.getLocalisationPBO() != null) && !pboSoap.getLocalisationPBO().isEmpty())
        {
          pboBuilder.adressePBO(new AdresseBuilder().referencesAdresse(new ReferencesAdresseBuilder().adresseLibre(pboSoap.getLocalisationPBO()).build()).build());
        }

        pbos.add(pboBuilder.build());
      }

      return new ConnectorResponse<>(new PBOsBuilder().pbos(pbos).build(), new CodeRetour(CodeRetourConsts.OK));

    }
    catch (RavelException exception)
    {
      // Common fault handling
      CodeRetour commonCodeRetour = handleCommonFault(exception);
      if (commonCodeRetour != null)
      {
        return new ConnectorResponse<>(null, commonCodeRetour);
      }

      // Rethrow if no error response
      throw exception;
    }
  }

  /**
   * Cree l'entete SOAP à partir de la configuration OI.
   *
   * @param config_p
   *          OI configuration
   * @return entete emutation
   */
  private EnteteRequeteType createEntete(ConfigFluxOI config_p)
  {
    EnteteRequeteType entete = new EnteteRequeteType();
    entete.setHorodatageRequete(LocalDateTime.now());
    entete.setIdentifiantRequete(UUIDManager.getInstance().getSafeUUIDv5().toString());

    OperateurCommercialType oc = new OperateurCommercialType();
    oc.setNom(config_p.getConnexionTechnique().getIdentite().getNom());
    oc.setIdentifiant(config_p.getConnexionTechnique().getIdentite().getIdentifiant());
    entete.setOperateurCommercial(oc);

    entete.setVersionWS(config_p.getConnexionTechnique().getWsdl().getVersion());

    return entete;
  }

  /**
   * Common fault handling.
   *
   * @param exception
   *          the catched exception
   * @return a common error, or null
   */
  private CodeRetour handleCommonFault(RavelException exception)
  {
    if (EmutationFunctionalFaultMessage.class.isInstance(exception.getCause()))
    {
      EmutationFunctionalFaultMessage fault = (EmutationFunctionalFaultMessage) exception.getCause();
      if (fault.getFaultInfo() != null)
      {
        String code = fault.getFaultInfo().getCodeErreur().value();
        String libelle = StringConstants.EMPTY_STRING;
        if (fault.getFaultInfo().getLibelleErreur() != null)
        {
          libelle = fault.getFaultInfo().getLibelleErreur().value();
        }
        return new CodeRetour(CodeRetourConsts.PROBLEME_FONCTIONNEL, code, libelle);
      }
    }

    else if (EmutationTechnicalFaultMessage.class.isInstance(exception.getCause()))
    {
      EmutationTechnicalFaultMessage fault = (EmutationTechnicalFaultMessage) exception.getCause();
      if (fault.getFaultInfo() != null)
      {
        String code = fault.getFaultInfo().getCodeErreur().value();
        String libelle = fault.getFaultInfo().getLibelleErreur().value();
        return new CodeRetour(CodeRetourConsts.PROBLEME_TECHNIQUE, code, libelle);
      }
    }

    else if (EmutationDefaultFaultMessage.class.isInstance(exception.getCause()))
    {
      EmutationDefaultFaultMessage fault = (EmutationDefaultFaultMessage) exception.getCause();
      if (fault.getFaultInfo() != null)
      {
        String code = fault.getFaultInfo().getCodeErreur();
        String libelle = fault.getFaultInfo().getLibelleErreur();
        return new CodeRetour(CodeRetourConsts.PROBLEME_TECHNIQUE, code, libelle);
      }
    }

    // if cause doesn't match a known fault, return null
    return null;
  }

  /**
   * @param config_p
   *          OI configuration
   * @param majRouteOptique_p
   *          objet structuré majRouteOptique
   * @return objet SOAP MiseAJourRouteOptique
   */
  private MiseAJourRouteOptique mapMajRouteOptiqueRequest(ConfigFluxOI config_p, MAJRouteOptique majRouteOptique_p)
  {
    MiseAJourRouteOptique request = new MiseAJourRouteOptique();
    request.setEntete(createEntete(config_p));

    request.setIdentifiantFibre(majRouteOptique_p.getIdentifiantFibre());
    request.setPorteTerrain(majRouteOptique_p.getPorte());
    request.setReferencePrise(majRouteOptique_p.getReferencePrise());
    request.setReferencePrestationPrise(majRouteOptique_p.getRefPrestationPrise());

    // La STI indique explicitement la liste des motifs valides ; ces motifs STI correspondent à l'enum SOAP
    // Une IllegalArgumentException sera levée si le motif fourni (String) ne correspond pas !
    request.setMotifMutation(MotifMutationType.fromValue(majRouteOptique_p.getMotifMutation()));

    if (majRouteOptique_p.getReferencesAdresse() != null)
    {
      ReferencesAdresse adresse = majRouteOptique_p.getReferencesAdresse();
      ReferenceAdresseDemandeType adresseSoap = new ReferenceAdresseDemandeType();
      adresseSoap.setIdentifiantImmeuble(adresse.getIdentifiantImmeuble());
      adresseSoap.setReferenceHexacle(adresse.getHexacle());
      // adresse.getAdresseLibre() non mappée

      if (adresse.getRivoli() != null)
      {
        QuadrupletRivoli rivoli = adresse.getRivoli();
        ReferenceRivoliType rivoliSoap = new ReferenceRivoliType();
        rivoliSoap.setCodeInsee(rivoli.getCodeInsee());
        rivoliSoap.setCodeRivoli(rivoli.getCodeRivoli());
        rivoliSoap.setComplementNumeroVoie(rivoli.getComplementNumeroVoie());
        rivoliSoap.setNumeroVoie(BigInteger.valueOf(rivoli.getNumeroVoie()));
        adresseSoap.setReferenceRivoli(rivoliSoap);
      }

      if (adresse.getHexacleVoie() != null)
      {
        HexacleVoie hexacleVoie = adresse.getHexacleVoie();
        ReferenceHexacleVoieType hexacleVoieSoap = new ReferenceHexacleVoieType();
        hexacleVoieSoap.setCodeHexacleVoie(hexacleVoie.getCodeHexaclevoie());
        hexacleVoieSoap.setComplementNumeroVoie(hexacleVoie.getComplementNumeroVoie());
        hexacleVoieSoap.setNumeroVoie(BigInteger.valueOf(hexacleVoie.getNumeroVoie()));
        adresseSoap.setReferenceHexacleVoie(hexacleVoieSoap);
      }

      if (adresse.getReferenceGeographique() != null)
      {
        CoordonneesGeo geo = adresse.getReferenceGeographique();
        CoordonneesGeographiquesType geoSoap = new CoordonneesGeographiquesType();
        geoSoap.setTypeProjection(geo.getTypeProjection());
        geoSoap.setCoordonneesX(Float.parseFloat(geo.getCoordonneesX()));
        geoSoap.setCoordonneesY(Float.parseFloat(geo.getCoordonneesY()));
        adresseSoap.setReferenceGeographique(geoSoap);
      }
      request.setReferenceAdresse(adresseSoap);
    }

    if (majRouteOptique_p.getComplementAdresseCmd() != null)
    {
      ComplementAdresse complementCmd = majRouteOptique_p.getComplementAdresseCmd();
      request.setBatiment(complementCmd.getBatiment());
      request.setEscalier(complementCmd.getEscalier());
      request.setEtage(complementCmd.getEtage());
    }

    if (majRouteOptique_p.getComplementAdresseTerrain() != null)
    {
      ComplementAdresse complementTerrain = majRouteOptique_p.getComplementAdresseTerrain();
      request.setBatimentTerrain(complementTerrain.getBatiment());
      request.setEscalierTerrain(complementTerrain.getEscalier());
      request.setEtageTerrain(complementTerrain.getEtage());
    }

    return request;
  }

}
