
package com.bytel.spirit.common.connector.oi.aidecommande.structs.structureverticale.ligne;

import java.io.Serializable;
import java.util.Objects;

/**
 * @author jpais
 * @version ($Revision$ $Date$)
 */
public class Local implements Serializable
{
  /** Serial UID */
  private static final long serialVersionUID = -2779640351323686633L;

  /**
   * Ce champ permet, le cas échéant, d’identifier le local à l’étage (par exemple : « porte de gauche »).
   */
  protected String _localisationLocalOI;

  /**
   * Ce champ permet, le cas échéant, de restituer l’information communiquée par l’OC ayant effectué le raccordement.
   */
  protected String _localisationLocalOC;

  @Override
  public boolean equals(Object o_p)
  {
    if (this == o_p)
    {
      return true;
    }
    if (o_p == null || getClass() != o_p.getClass())
    {
      return false;
    }
    Local local = (Local) o_p;
    return Objects.equals(_localisationLocalOI, local._localisationLocalOI) && Objects.equals(_localisationLocalOC, local._localisationLocalOC);
  }

  /**
   * @return value of localisationLocalOC
   */
  public String getLocalisationLocalOC()
  {
    return _localisationLocalOC;
  }

  /**
   * @return value of localisationLocalOI
   */
  public String getLocalisationLocalOI()
  {
    return _localisationLocalOI;
  }

  @Override
  public int hashCode()
  {
    return Objects.hash(_localisationLocalOI, _localisationLocalOC);
  }

  /**
   * @param localisationLocalOC_p
   *          The localisationLocalOC to set.
   */
  public void setLocalisationLocalOC(String localisationLocalOC_p)
  {
    _localisationLocalOC = localisationLocalOC_p;
  }

  /**
   * @param localisationLocalOI_p
   *          The localisationLocalOI to set.
   */
  public void setLocalisationLocalOI(String localisationLocalOI_p)
  {
    _localisationLocalOI = localisationLocalOI_p;
  }
}
