
package com.bytel.spirit.common.connector.oi.aidecommande.structs.structureverticale.batiment;

/**
 * @author jpais
 * @version ($Revision$ $Date$)
 */
public enum EtatBatiment
{

  NON_RACCORDABLE("NON RACCORDABLE"), RACCORDABLE("RACCORDABLE"), COMMERCIALISABLE("COMMERCIALISABLE");

  public static EtatBatiment fromValue(String v)
  {
    for (EtatBatiment c : EtatBatiment.values())
    {
      if (c._value.equals(v))
      {
        return c;
      }
    }
    throw new IllegalArgumentException(v);
  }

  private final String _value;

  EtatBatiment(String v)
  {
    _value = v;
  }

  public String value()
  {
    return _value;
  }

}
