
package com.bytel.spirit.common.connector.oi.aidecommande.structs.structureverticale.adresse;

import java.io.Serializable;
import java.util.Objects;

/**
 * @author jpais
 * @version ($Revision$ $Date$)
 */
public class ReferenceAdresseReponse implements Serializable
{
  /** Serial UID */
  private static final long serialVersionUID = 5713087677788428399L;

  /**
   * Référence Hexaclé.
   */
  private String _referenceHexacle;

  /**
   * Référence Rivoli
   */
  private ReferenceRivoli _referenceRivoli;

  /**
   * Description de l’adresse par le triplet code hexaclé du 0 de la voie, numéro et, s’il existe, complément de voie.
   */
  private ReferenceHexacleVoie _referenceHexacleVoie;

  @Override
  public boolean equals(Object o_p)
  {
    if (this == o_p)
    {
      return true;
    }
    if (o_p == null || getClass() != o_p.getClass())
    {
      return false;
    }
    ReferenceAdresseReponse that = (ReferenceAdresseReponse) o_p;
    return Objects.equals(_referenceHexacle, that._referenceHexacle) && Objects.equals(_referenceRivoli, that._referenceRivoli) && Objects.equals(_referenceHexacleVoie, that._referenceHexacleVoie);
  }

  /**
   * @return value of referenceHexacle
   */
  public String getReferenceHexacle()
  {
    return _referenceHexacle;
  }

  /**
   * @return value of referenceHexacleVoie
   */
  public ReferenceHexacleVoie getReferenceHexacleVoie()
  {
    return _referenceHexacleVoie;
  }

  /**
   * @return value of referenceRivoli
   */
  public ReferenceRivoli getReferenceRivoli()
  {
    return _referenceRivoli;
  }

  @Override
  public int hashCode()
  {
    return Objects.hash(_referenceHexacle, _referenceRivoli, _referenceHexacleVoie);
  }

  /**
   * @param referenceHexacle_p
   *          The referenceHexacle to set.
   */
  public void setReferenceHexacle(String referenceHexacle_p)
  {
    _referenceHexacle = referenceHexacle_p;
  }

  /**
   * @param referenceHexacleVoie_p
   *          The referenceHexacleVoie to set.
   */
  public void setReferenceHexacleVoie(ReferenceHexacleVoie referenceHexacleVoie_p)
  {
    _referenceHexacleVoie = referenceHexacleVoie_p;
  }

  /**
   * @param referenceRivoli_p
   *          The referenceRivoli to set.
   */
  public void setReferenceRivoli(ReferenceRivoli referenceRivoli_p)
  {
    _referenceRivoli = referenceRivoli_p;
  }
}
