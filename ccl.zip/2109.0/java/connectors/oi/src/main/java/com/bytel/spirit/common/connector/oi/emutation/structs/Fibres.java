/*******************************************************************************
* $Id: Fibres.java 10997 2018-10-01 15:27:30Z jstrub $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connector.oi.emutation.structs;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 *
 * @author jstrub
 * @version ($Revision: 10997 $ $Date: 2018-10-01 17:27:30 +0200 (lun. 01 oct. 2018) $)
 */
public final class Fibres
{
  /**
   *
   * @author jstrub
   * @version ($Revision: 10997 $ $Date: 2018-10-01 17:27:30 +0200 (lun. 01 oct. 2018) $)
   */
  public static final class FibresBuilder
  {

    /** List of Fibre. */
    private List<Fibre> _fibres;

    /**
     * Default Constructor
     */
    public FibresBuilder()
    {
      _fibres = new ArrayList<>();
    }

    /**
     * @return a built {@link PBOs}
     */
    public Fibres build()
    {
      return new Fibres(_fibres);
    }

    /**
     * @param fibres_p
     *          fibres to add
     * @return an instance of {@link FibresBuilder}
     */
    public FibresBuilder fibres(List<Fibre> fibres_p)
    {
      if (fibres_p != null)
      {
        _fibres.addAll(fibres_p);
      }
      return this;
    }

  }

  /** List of Fibre. */
  private final List<Fibre> _fibres;

  /**
   * @param fibres_p
   *          the fibres.
   */
  public Fibres(List<Fibre> fibres_p)
  {
    if (fibres_p != null)
    {
      _fibres = Collections.unmodifiableList(fibres_p);
    }
    else
    {
      _fibres = null;
    }
  }

  /**
   * @return the fibres
   */
  public List<Fibre> getFibres()
  {
    if (_fibres == null)
    {
      return new ArrayList<>();
    }
    return Collections.unmodifiableList(_fibres);
  }

}
