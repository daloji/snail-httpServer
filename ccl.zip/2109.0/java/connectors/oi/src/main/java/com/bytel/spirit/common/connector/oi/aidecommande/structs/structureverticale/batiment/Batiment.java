
package com.bytel.spirit.common.connector.oi.aidecommande.structs.structureverticale.batiment;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

import com.bytel.spirit.common.connector.oi.aidecommande.structs.structureverticale.escalier.Escalier;

/**
 * @author jpais
 * @version ($Revision$ $Date$)
 */
public class Batiment implements Serializable
{
  /**
   *
   * @author jpais
   * @version ($Revision: 10997 $ $Date: 2018-10-01 17:27:30 +0200 (Mon, 01 Oct 2018) $)
   */
  public static final class BatimentBuilder
  {
    /** Access field {@link Batiment#_escaliers} */
    private final List<Escalier> _escaliers;

    /** Access field {@link Batiment#_referenceBatiment} */
    private String _referenceBatiment;

    /** Access field {@link Batiment#_referenceGeographique} */
    private CoordonneesGeographiques _referenceGeographique;

    /** Access field {@link Batiment#_referenceBAN} */
    private String _referenceBAN;

    /** Access field {@link Batiment#_identifiantImmeuble} */
    private String _identifiantImmeuble;

    /** Access field {@link Batiment#_nombreLogementsImmeuble} */
    private Integer _nombreLogementsImmeuble;

    /** Access field {@link Batiment#_etatBatiment} */
    private EtatBatiment _etatBatiment;

    /** Access field {@link Batiment#_conditionsSyndic} */
    private String _conditionsSyndic;

    /** Access field {@link Batiment#_dateDebutAcceptationCmdAcces} */
    private LocalDate _dateDebutAcceptationCmdAcces;

    /** Access field {@link Batiment#_dateDebutFournitureCRCmdAcces} */
    private LocalDate _dateDebutFournitureCRCmdAcces;

    /**
     * Default Constructor
     */
    public BatimentBuilder()
    {
      _escaliers = new ArrayList<>();
    }

    /**
     * @return a built {@link Batiment}
     */
    public Batiment build()
    {
      Batiment batiment = new Batiment(_referenceBatiment, _nombreLogementsImmeuble, _etatBatiment, _escaliers);
      batiment.setReferenceGeographique(_referenceGeographique);
      batiment.setReferenceBAN(_referenceBAN);
      batiment.setIdentifiantImmeuble(_identifiantImmeuble);
      batiment.setConditionsSyndic(_conditionsSyndic);
      batiment.setDateDebutAcceptationCmdAcces(_dateDebutAcceptationCmdAcces);
      batiment.setDateDebutFournitureCRCmdAcces(_dateDebutFournitureCRCmdAcces);
      return batiment;
    }

    /**
     * @param conditionsSyndic_p
     *          the reference to set
     * @return an instance of {@link BatimentBuilder}
     */
    public BatimentBuilder conditionsSyndic(String conditionsSyndic_p)
    {
      _conditionsSyndic = conditionsSyndic_p;
      return this;
    }

    /**
     * @param dateDebutAcceptationCmdAcces_p
     *          the reference to set
     * @return an instance of {@link BatimentBuilder}
     */
    public BatimentBuilder dateDebutAcceptationCmdAcces(LocalDate dateDebutAcceptationCmdAcces_p)
    {
      _dateDebutAcceptationCmdAcces = dateDebutAcceptationCmdAcces_p;
      return this;
    }

    /**
     * @param dateDebutFournitureCRCmdAcces_p
     *          the reference to set
     * @return an instance of {@link BatimentBuilder}
     */
    public BatimentBuilder dateDebutFournitureCRCmdAcces(LocalDate dateDebutFournitureCRCmdAcces_p)
    {
      _dateDebutFournitureCRCmdAcces = dateDebutFournitureCRCmdAcces_p;
      return this;
    }

    /**
     * @param escaliers_p
     *          escaliers to add
     * @return an instance of {@link BatimentBuilder}
     */
    public BatimentBuilder escaliers(List<Escalier> escaliers_p)
    {
      if (escaliers_p != null)
      {
        _escaliers.addAll(escaliers_p);
      }
      return this;
    }

    /**
     * @param etatBatiment_p
     *          the reference to set
     * @return an instance of {@link BatimentBuilder}
     */
    public BatimentBuilder etatBatiment(EtatBatiment etatBatiment_p)
    {
      _etatBatiment = etatBatiment_p;
      return this;
    }

    /**
     * @param identifiantImmeuble_p
     *          the reference to set
     * @return an instance of {@link BatimentBuilder}
     */
    public BatimentBuilder identifiantImmeuble(String identifiantImmeuble_p)
    {
      _identifiantImmeuble = identifiantImmeuble_p;
      return this;
    }

    /**
     * @param nombreLogementsImmeuble_p
     *          the reference to set
     * @return an instance of {@link BatimentBuilder}
     */
    public BatimentBuilder nombreLogementsImmeuble(Integer nombreLogementsImmeuble_p)
    {
      _nombreLogementsImmeuble = nombreLogementsImmeuble_p;
      return this;
    }

    /**
     * @param referenceBAN_p
     *          the reference to set
     * @return an instance of {@link BatimentBuilder}
     */
    public BatimentBuilder referenceBAN(String referenceBAN_p)
    {
      _referenceBAN = referenceBAN_p;
      return this;
    }

    /**
     * @param referenceBatiment_p
     *          the reference to set
     * @return an instance of {@link BatimentBuilder}
     */
    public BatimentBuilder referenceBatiment(String referenceBatiment_p)
    {
      _referenceBatiment = referenceBatiment_p;
      return this;
    }

    /**
     * @param referenceGeographique_p
     *          the reference to set
     * @return an instance of {@link BatimentBuilder}
     */
    public BatimentBuilder referenceGeographique(CoordonneesGeographiques referenceGeographique_p)
    {
      _referenceGeographique = referenceGeographique_p;
      return this;
    }

  }

  /** Serial UID */
  private static final long serialVersionUID = -8828387254288211514L;

  /**
   * Référence du bâtiment tel que présent dans les bases de données de l’OI.
   */
  private String _referenceBatiment;

  /**
   * Coordonnées géographiques de l’immeuble.
   */
  private CoordonneesGeographiques _referenceGeographique;

  /**
   * Champ unique défini par le projet BAN.
   */
  private String _referenceBAN;

  /**
   * Identifiant de l’immeuble dans le SI de l’OI. Correspond à la colonne IdentifiantImmeuble de l’IPE.
   */
  private String _identifiantImmeuble;

  /**
   * Nombre de logements de l’immeuble.
   */
  private Integer _nombreLogementsImmeuble;

  /**
   * Ce champ fournit l’état de déploiement et de commercialisation des lignes FTTH associées au bâtiment.
   */
  private EtatBatiment _etatBatiment;

  /**
   * Ce champ précise les conditions de raccordement du client autorisées par le syndic ou le propriétaire. Chaque
   * opérateur détaille sa typologie de raccordements.
   */
  private String _conditionsSyndic;

  /**
   * C’est la date à partir de laquelle l’OC peut envoyer une commande d'accès à l'OI sans qu'elle soit rejetée pour motif
   * d'envoi prématuré.
   */
  private LocalDate _dateDebutAcceptationCmdAcces;

  /**
   * Correspond à la date d’envoi au plus tôt des CR Cmd d’accès par l'OI à l'OC.
   */
  private LocalDate _dateDebutFournitureCRCmdAcces;

  /**
   * Nombre d’occurrence de ce champ illimité.
   */
  private List<Escalier> _escaliers;

  /**
   * Default constructor
   * 
   * @param referenceBatiment_p
   * @param nombreLogementsImmeuble_p
   * @param etatBatiment_p
   * @param escaliers_p
   */
  public Batiment(String referenceBatiment_p, Integer nombreLogementsImmeuble_p, EtatBatiment etatBatiment_p, List<Escalier> escaliers_p)
  {
    _referenceBatiment = referenceBatiment_p;
    _nombreLogementsImmeuble = nombreLogementsImmeuble_p;
    _etatBatiment = etatBatiment_p;
    _escaliers = escaliers_p == null ? Collections.emptyList() : new ArrayList<>(escaliers_p);
  }

  @Override
  public boolean equals(Object o_p)
  {
    if (this == o_p)
    {
      return true;
    }
    if (o_p == null || getClass() != o_p.getClass())
    {
      return false;
    }
    Batiment that = (Batiment) o_p;
    return _referenceBatiment.equals(that._referenceBatiment) && Objects.equals(_referenceGeographique, that._referenceGeographique) && Objects.equals(_referenceBAN, that._referenceBAN) && Objects.equals(_identifiantImmeuble, that._identifiantImmeuble) && _nombreLogementsImmeuble.equals(that._nombreLogementsImmeuble) && _etatBatiment == that._etatBatiment && Objects.equals(_conditionsSyndic, that._conditionsSyndic) && Objects.equals(_dateDebutAcceptationCmdAcces, that._dateDebutAcceptationCmdAcces) && Objects.equals(_dateDebutFournitureCRCmdAcces, that._dateDebutFournitureCRCmdAcces) && _escaliers.equals(that._escaliers);
  }

  /**
   * @return value of conditionsSyndic
   */
  public String getConditionsSyndic()
  {
    return _conditionsSyndic;
  }

  /**
   * @return value of dateDebutAcceptationCmdAcces
   */
  public LocalDate getDateDebutAcceptationCmdAcces()
  {
    return _dateDebutAcceptationCmdAcces;
  }

  /**
   * @return value of dateDebutFournitureCRCmdAcces
   */
  public LocalDate getDateDebutFournitureCRCmdAcces()
  {
    return _dateDebutFournitureCRCmdAcces;
  }

  /**
   * @return value of escaliers
   */
  public List<Escalier> getEscaliers()
  {
    return _escaliers == null ? null : new ArrayList<>(_escaliers);
  }

  /**
   * @return value of etatBatiment
   */
  public EtatBatiment getEtatBatiment()
  {
    return _etatBatiment;
  }

  /**
   * @return value of identifiantImmeuble
   */
  public String getIdentifiantImmeuble()
  {
    return _identifiantImmeuble;
  }

  /**
   * @return value of nombreLogementsImmeuble
   */
  public Integer getNombreLogementsImmeuble()
  {
    return _nombreLogementsImmeuble;
  }

  /**
   * @return value of referenceBAN
   */
  public String getReferenceBAN()
  {
    return _referenceBAN;
  }

  /**
   * @return value of referenceBatiment
   */
  public String getReferenceBatiment()
  {
    return _referenceBatiment;
  }

  /**
   * @return value of referenceGeographique
   */
  public CoordonneesGeographiques getReferenceGeographique()
  {
    return _referenceGeographique;
  }

  @Override
  public int hashCode()
  {
    return Objects.hash(_referenceBatiment, _referenceGeographique, _referenceBAN, _identifiantImmeuble, _nombreLogementsImmeuble, _etatBatiment, _conditionsSyndic, _dateDebutAcceptationCmdAcces, _dateDebutFournitureCRCmdAcces, _escaliers);
  }

  /**
   * @param conditionsSyndic_p
   *          The conditionsSyndic to set.
   */
  public void setConditionsSyndic(String conditionsSyndic_p)
  {
    _conditionsSyndic = conditionsSyndic_p;
  }

  /**
   * @param dateDebutAcceptationCmdAcces_p
   *          The dateDebutAcceptationCmdAcces to set.
   */
  public void setDateDebutAcceptationCmdAcces(LocalDate dateDebutAcceptationCmdAcces_p)
  {
    _dateDebutAcceptationCmdAcces = dateDebutAcceptationCmdAcces_p;
  }

  /**
   * @param dateDebutFournitureCRCmdAcces_p
   *          The dateDebutFournitureCRCmdAcces to set.
   */
  public void setDateDebutFournitureCRCmdAcces(LocalDate dateDebutFournitureCRCmdAcces_p)
  {
    _dateDebutFournitureCRCmdAcces = dateDebutFournitureCRCmdAcces_p;
  }

  /**
   * @param escaliers_p
   *          The escaliers to set.
   */
  public void setEscaliers(List<Escalier> escaliers_p)
  {
    _escaliers = escaliers_p == null ? null : new ArrayList<>(escaliers_p);
  }

  /**
   * @param etatBatiment_p
   *          The etatBatiment to set.
   */
  public void setEtatBatiment(EtatBatiment etatBatiment_p)
  {
    _etatBatiment = etatBatiment_p;
  }

  /**
   * @param identifiantImmeuble_p
   *          The identifiantImmeuble to set.
   */
  public void setIdentifiantImmeuble(String identifiantImmeuble_p)
  {
    _identifiantImmeuble = identifiantImmeuble_p;
  }

  /**
   * @param nombreLogementsImmeuble_p
   *          The nombreLogementsImmeuble to set.
   */
  public void setNombreLogementsImmeuble(Integer nombreLogementsImmeuble_p)
  {
    _nombreLogementsImmeuble = nombreLogementsImmeuble_p;
  }

  /**
   * @param referenceBAN_p
   *          The referenceBAN to set.
   */
  public void setReferenceBAN(String referenceBAN_p)
  {
    _referenceBAN = referenceBAN_p;
  }

  /**
   * @param referenceBatiment_p
   *          The referenceBatiment to set.
   */
  public void setReferenceBatiment(String referenceBatiment_p)
  {
    _referenceBatiment = referenceBatiment_p;
  }

  /**
   * @param referenceGeographique_p
   *          The referenceGeographique to set.
   */
  public void setReferenceGeographique(CoordonneesGeographiques referenceGeographique_p)
  {
    _referenceGeographique = referenceGeographique_p;
  }
}
