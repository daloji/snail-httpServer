
package com.bytel.spirit.common.connector.oi.aidecommande.structs.structureverticale.pm;

import java.io.Serializable;
import java.util.Objects;

/**
 * @author jpais
 * @version ($Revision$ $Date$)
 */
public class Pm implements Serializable
{
  /** Serial UID */
  private static final long serialVersionUID = 2526641201889226522L;

  /**
   * Référence du point de mutualisation (PM de regroupement dans le cas de multiples PM Techniques).
   */
  private String _referencePM;

  /**
   * Référence du PM technique.
   */
  private String _referencePMT;

  /**
   * Le type simple de ce champ EmplacementPmType correspond à un « string » limité aux deux valeurs suivantes
   */
  private EmplacementPm _typeEmplacementPM;

  /**
   * Détermine qui est responsable du brassage au PM.
   */
  private Brassage _responsableBrassage;

  /**
   * Identifiant du lien PM-PRDM unique et à dissocier de l’identifiant des liens optiques commandés éventuellement par un
   * OC.
   */
  private String _identifiantLienPMPRDM;

  /**
   * Identifiant du PRDM unique.
   */
  private String _identifiantPRDM;

  /**
   * Default constructor.
   * 
   * @param referencePM_p
   * @param referencePMT_p
   * @param typeEmplacementPM_p
   * @param responsableBrassage_p
   */
  public Pm(String referencePM_p, String referencePMT_p, EmplacementPm typeEmplacementPM_p, Brassage responsableBrassage_p)
  {
    _referencePM = referencePM_p;
    _referencePMT = referencePMT_p;
    _typeEmplacementPM = typeEmplacementPM_p;
    _responsableBrassage = responsableBrassage_p;
  }

  @Override
  public boolean equals(Object o_p)
  {
    if (this == o_p)
    {
      return true;
    }
    if (o_p == null || getClass() != o_p.getClass())
    {
      return false;
    }
    Pm pm = (Pm) o_p;
    return _referencePM.equals(pm._referencePM) && _referencePMT.equals(pm._referencePMT) && _typeEmplacementPM == pm._typeEmplacementPM && _responsableBrassage == pm._responsableBrassage && Objects.equals(_identifiantLienPMPRDM, pm._identifiantLienPMPRDM) && Objects.equals(_identifiantPRDM, pm._identifiantPRDM);
  }

  /**
   * @return value of identifiantLienPMPRDM
   */
  public String getIdentifiantLienPMPRDM()
  {
    return _identifiantLienPMPRDM;
  }

  /**
   * @return value of identifiantPRDM
   */
  public String getIdentifiantPRDM()
  {
    return _identifiantPRDM;
  }

  /**
   * @return value of referencePM
   */
  public String getReferencePM()
  {
    return _referencePM;
  }

  /**
   * @return value of referencePMT
   */
  public String getReferencePMT()
  {
    return _referencePMT;
  }

  /**
   * @return value of responsableBrassage
   */
  public Brassage getResponsableBrassage()
  {
    return _responsableBrassage;
  }

  /**
   * @return value of typeEmplacementPM
   */
  public EmplacementPm getTypeEmplacementPM()
  {
    return _typeEmplacementPM;
  }

  @Override
  public int hashCode()
  {
    return Objects.hash(_referencePM, _referencePMT, _typeEmplacementPM, _responsableBrassage, _identifiantLienPMPRDM, _identifiantPRDM);
  }

  /**
   * @param identifiantLienPMPRDM_p
   *          The identifiantLienPMPRDM to set.
   */
  public void setIdentifiantLienPMPRDM(String identifiantLienPMPRDM_p)
  {
    _identifiantLienPMPRDM = identifiantLienPMPRDM_p;
  }

  /**
   * @param identifiantPRDM_p
   *          The identifiantPRDM to set.
   */
  public void setIdentifiantPRDM(String identifiantPRDM_p)
  {
    _identifiantPRDM = identifiantPRDM_p;
  }

  /**
   * @param referencePM_p
   *          The referencePM to set.
   */
  public void setReferencePM(String referencePM_p)
  {
    _referencePM = referencePM_p;
  }

  /**
   * @param referencePMT_p
   *          The referencePMT to set.
   */
  public void setReferencePMT(String referencePMT_p)
  {
    _referencePMT = referencePMT_p;
  }

  /**
   * @param responsableBrassage_p
   *          The responsableBrassage to set.
   */
  public void setResponsableBrassage(Brassage responsableBrassage_p)
  {
    _responsableBrassage = responsableBrassage_p;
  }

  /**
   * @param typeEmplacementPM_p
   *          The typeEmplacementPM to set.
   */
  public void setTypeEmplacementPM(EmplacementPm typeEmplacementPM_p)
  {
    _typeEmplacementPM = typeEmplacementPM_p;
  }
}
