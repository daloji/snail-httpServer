/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connector.oi.altitude;

import java.net.MalformedURLException;
import java.text.MessageFormat;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.core.MultivaluedMap;

import org.apache.commons.lang.StringUtils;

import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.log.event.SystemLogEvent;
import com.bytel.ravel.services.connector.IAuthentService;
import com.bytel.ravel.services.connector.RESTRequest;

/**
 * Altitude Authentication Service.
 *
 * @author mlebihan
 * @version ($Revision$ $Date$)
 */
public class AltitudeAuthentService implements IAuthentService
{
  /** Token altitude. */
  private AltitudeToken _altitudeToken = null;

  /** Altitude login. */
  private String _login;

  /** Altitude password. */
  private String _password;

  /** URL of the authentication REST service. */
  private String _url;

  /** REST Caller. */
  private RestCaller _restCaller;

  /**
   * Construct an Altitude Authentifcation Service.
   *
   * @param name_p
   *          Name of that REST connection.
   * @param completeUrl_p
   *          Complete URL of the REST service.
   * @param login_p
   *          Login.
   * @param password_p
   *          Password.
   * @param timeout_p
   *          Timeout.
   * @param proxyLogin_p
   *          Proxy Login.
   * @param proxyPassword_p
   *          Proxy password.
   * @param proxyHost_p
   *          Proxy host.
   * @param proxyPort_p
   *          Proxy port.
   * @param secureSocketProtocol_p
   *          SecureSocket protocol.
   * @param disableCnCheck_p
   *          Disable CN check if true.
   * @throws MalformedURLException
   *           if url is malformed.
   */
  public AltitudeAuthentService(String name_p, String completeUrl_p, String login_p, String password_p, int timeout_p, //
      String proxyLogin_p, String proxyPassword_p, String proxyHost_p, int proxyPort_p, String secureSocketProtocol_p, //
      boolean disableCnCheck_p) throws MalformedURLException
  {
    _restCaller = new RestCaller(name_p, completeUrl_p, timeout_p, proxyLogin_p, proxyPassword_p, proxyHost_p, proxyPort_p, secureSocketProtocol_p, disableCnCheck_p);
    _login = login_p;
    _password = password_p;
    _url = completeUrl_p;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void cleanInvalidToken()
  {
    _altitudeToken = null;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void completeSecurityInformation(MultivaluedMap<String, String> headers_p, Map<String, String> queryParams_p) throws RavelException
  {
    String token = getAccessToken(); // Always get token before tokenType
    String type = getTokenType();

    // add authorization header
    headers_p.add("Authorization", type + " " + token); //$NON-NLS-1$//$NON-NLS-2$
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public synchronized String getAccessToken() throws RavelException
  {
    // Check token
    if (_altitudeToken != null)
    {
      LocalDateTime now = LocalDateTime.now();

      if (now.isBefore(_altitudeToken.getExpire()))
      {
        return _altitudeToken.getValue();
      }
    }
    else
    {
      String format = "There''s no access token for {0} yet. Asking for one..."; //$NON-NLS-1$
      String message = MessageFormat.format(format, getClass().getSimpleName());

      RavelLogger.log(new SystemLogEvent(LogSeverity.DEBUG, message));
    }

    // Create REST request with login, password.
    Map<String, String> parameters = new HashMap<>();
    parameters.put("login", _login); //$NON-NLS-1$
    parameters.put("password", _password); //$NON-NLS-1$

    RESTRequest request = new RESTRequest();
    request.setQueryParameters(parameters);
    request.setPath(_url);

    _altitudeToken = _restCaller.sendAndReceiveFromJson(request, AltitudeToken.class);

    // if the returned token holds an error message, we consider it invalid and clear it.
    if (StringUtils.isNotBlank(_altitudeToken.getError()))
    {
      String format = "Altitude partner encountered a problem during token delivery, and authentication is reset : {0}"; //$NON-NLS-1$
      String message = MessageFormat.format(format, _altitudeToken.getError());

      RavelException ex = new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, message);
      RavelLogger.log(new SystemLogEvent(LogSeverity.WARNING, null, ex)); // No msgId.
      cleanInvalidToken();

      throw ex;
    }

    String format2 = "Token received for {0} : expiration date : {1}."; //$NON-NLS-1$
    String dateExpiration = _altitudeToken.getExpire() != null ? _altitudeToken.getExpire().toString() : null;
    String message2 = MessageFormat.format(format2, getClass().getSimpleName(), dateExpiration);

    RavelLogger.log(new SystemLogEvent(LogSeverity.DEBUG, message2));

    return _altitudeToken.getValue();
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public String getTokenType()
  {
    return "Bearer"; //$NON-NLS-1$
  }
}
