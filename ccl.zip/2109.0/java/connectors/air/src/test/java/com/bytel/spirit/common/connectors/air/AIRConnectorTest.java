/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.air;

import java.io.ByteArrayInputStream;
import java.text.MessageFormat;
import java.util.Arrays;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.cxf.jaxrs.impl.ResponseBuilderImpl;
import org.easymock.Capture;
import org.easymock.EasyMock;
import org.easymock.EasyMockSupport;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.conf.generated.LoadBalancer;
import com.bytel.ravel.common.conf.generated.Param;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.test.JUnitTools;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.net.loadbalancing.ILoadBalancer;
import com.bytel.ravel.net.loadbalancing.URLBalancedElement;
import com.bytel.ravel.net.rest.RestConnectorPool;
import com.bytel.ravel.net.rest.RestInstance;
import com.bytel.ravel.services.conf.connector.generated.Connector;
import com.bytel.ravel.services.conf.connector.generated.URL;
import com.bytel.ravel.services.conf.connector.generated.URLS;
import com.bytel.ravel.services.connector.AbstractRESTConnector;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.BasicResponse;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.ressources.RetourConverter;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.air.IndexRecherchePfi;
import com.bytel.spirit.common.shared.saab.air.request.CreateIndexRecherchePfiRequest;
import com.bytel.spirit.common.shared.saab.air.response.GetIndexRecherchePfiResponse;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author jgregori
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({})
public class AIRConnectorTest extends EasyMockSupport
{
  /**
   * Path for get pad7001
   */
  private static final String PAD7001_PATH_PARAM = "/indexRechercherPfi"; //$NON-NLS-1$

  /**
   * Type
   */
  private static final String TYPE_QUERY_PARAM = "type"; //$NON-NLS-1$
  /**
   * Valeur
   */
  private static final String VALEUR_QUERY_PARAM = "valeur"; //$NON-NLS-1$

  /**
   * clientOperateur
   */
  private static final String CLIENT_OPERATEUR_QUERY_PARAM = "clientOperateur";
  /**
   * noCompte
   */
  private static final String NO_COMPTE_QUERY_PARAM = "noCompte";

  /**
   * Connector to test
   */
  private AIRConnector _connector;

  /**
   * Factory to generate beans
   */
  private PodamFactory _podam = new PodamFactoryImpl();

  /**
   * Mock {@link ILoadBalancer}
   */
  @MockStrict
  ILoadBalancer<URLBalancedElement> _loadBalancerMock;

  /**
   * Mock {@link URLBalancedElement}
   */
  @MockStrict
  URLBalancedElement _urlBalancedElementMock;

  /**
   * Mock of connectors pool HTTP
   */
  @MockStrict
  Hashtable<String, RestConnectorPool> _connectorPoolMock;

  /**
   * Mock {@link RestConnectorPool}
   */
  @MockStrict
  RestConnectorPool _restConnectorPoolMock;

  /**
   * Mock {@link RestInstance}
   */
  @MockStrict
  RestInstance _restInstanceMock;
  /**
   * Path for indexRechercherPfi
   */
  private String _indexRechercherPfiUrl;

  /**
   * Initialize before tests
   *
   * @throws Exception
   *           Thrown in case of error during switch in attributes of parent class
   */
  @Before
  public void beforeTest() throws Exception
  {
    _podam.getStrategy().setMemoization(false);
    _podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());

    _connector = new AIRConnector();
    _indexRechercherPfiUrl = PAD7001_PATH_PARAM;

    JUnitTools.setInaccessibleFieldValue(_connector, "_loadBalancer", _loadBalancerMock); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_connectorPool", _connectorPoolMock); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_indexRechercherPfiUrl", _indexRechercherPfiUrl); //$NON-NLS-1$

    PowerMock.resetAll();
  }

  /**
   * @throws Exception
   *           Exception
   */
  @Test
  public void test_loadConnectorConfiguration_OK_01() throws Exception
  {
    final Connector connector = new Connector();

    Param param = new Param();
    param.setName("PAD7001_IndexRechercherPfi"); //$NON-NLS-1$
    param.setValue(_indexRechercherPfiUrl);
    connector.getParam().add(param);

    connector.setURLS(generateURLS());

    // test
    _connector.loadConnectorConfiguration(connector);

    // assertions
    Assert.assertEquals(_indexRechercherPfiUrl, JUnitTools.getInaccessibleFieldValue(_connector, "_indexRechercherPfiUrl")); //$NON-NLS-1$
  }

  /**
   * Test the method {@link AIRConnector#indexRechercherPfiEcrire(Tracabilite, CreateIndexRecherchePfiRequest)}
   * httpStatus 200, with retour KO
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testIndexRecherchePfiCreer_KO_002() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    IndexRecherchePfi indexRecherchePfi = _podam.manufacturePojo(IndexRecherchePfi.class);

    CreateIndexRecherchePfiRequest indexRecherchePfiRequest = new CreateIndexRecherchePfiRequest(indexRecherchePfi);

    final Retour retour = RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.DONNEE_INDISPONIBLE, StringConstants.EMPTY_STRING);
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(basicResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(_indexRechercherPfiUrl), EasyMock.capture(headersCapture), EasyMock.eq(GsonTools.getIso8601Ms().toJson(indexRecherchePfiRequest)), EasyMock.isNull())).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.indexRechercherPfiEcrire(tracabilite, indexRecherchePfiRequest);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method
   * {@link AIRConnector#indexRechercherPfiEcrire(Tracabilite, com.bytel.spirit.common.saab.air.types.request.CreateIndexRecherchePfiRequest)}
   * httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testIndexRecherchePfiCreer_OK_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    IndexRecherchePfi indexRecherchePfi = _podam.manufacturePojo(IndexRecherchePfi.class);

    CreateIndexRecherchePfiRequest indexRecherchePfiRequest = new CreateIndexRecherchePfiRequest(indexRecherchePfi);

    final Retour retour = RetourFactory.createOkRetour();
    final String partnerResponse = "{\"retour\":" + GsonTools.getIso8601Ms().toJson(retour) + "}"; //$NON-NLS-1$//$NON-NLS-2$

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(_indexRechercherPfiUrl), EasyMock.capture(headersCapture), EasyMock.eq(GsonTools.getIso8601Ms().toJson(indexRecherchePfiRequest)), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.indexRechercherPfiEcrire(tracabilite, indexRecherchePfiRequest);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture);

    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
  }

  /**
   * Test the method {@link AIRConnector#indexRechercherPfiLireTousParCleRecherche(Tracabilite, String, String)} retur
   * KO DONNE_INCONNUE
   *
   * @throws Exception
   */
  @Test
  public void testIndexRecherchePfiLireTousParCleRecherche_KO_004() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final String type = "ADRESSE_MAIL"; //$NON-NLS-1$
    final String valeur = "teste@teste.fr"; //$NON-NLS-1$

    final Retour retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, MessageFormat.format("indexRechercherPfi (type:{0}, valeur{1}) inconnu", type, valeur)); //$NON-NLS-1$
    final String partnerResponse = "{\"retour\":" + GsonTools.getIso8601Ms().toJson(retour) + "}"; //$NON-NLS-1$//$NON-NLS-2$

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_indexRechercherPfiUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<IndexRecherchePfi>> result = _connector.indexRechercherPfiLireTousParCleRecherche(tracabilite, type, valeur);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, TYPE_QUERY_PARAM, type, VALEUR_QUERY_PARAM, valeur);
    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
    Assert.assertEquals(0, result._second.size());
  }

  /**
   * Test the method {@link AIRConnector#indexRechercherPfiLireTousParCleRecherche(Tracabilite, String, String)}
   * httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testIndexRecherchePfiLireTousParCleRecherche_OK_003() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final String type = "ADRESSE_MAIL"; //$NON-NLS-1$
    final String valeur = "teste@teste.fr"; //$NON-NLS-1$

    IndexRecherchePfi indexRecherchePfi = _podam.manufacturePojo(IndexRecherchePfi.class);
    List<IndexRecherchePfi> listIndexRecherchePfi = Arrays.asList(indexRecherchePfi);
    final Retour retour = RetourFactory.createOkRetour();
    GetIndexRecherchePfiResponse indexRecherchePfiResponse = new GetIndexRecherchePfiResponse(RetourConverter.convertToJsonRetour(retour), listIndexRecherchePfi);
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(indexRecherchePfiResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_indexRechercherPfiUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<IndexRecherchePfi>> result = _connector.indexRechercherPfiLireTousParCleRecherche(tracabilite, type, valeur);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, TYPE_QUERY_PARAM, type, VALEUR_QUERY_PARAM, valeur);
    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
    Assert.assertNotNull(result._second);
    Assert.assertEquals(indexRecherchePfi, result._second.get(0));

  }

  /**
   * Test the method {@link AIRConnector#indexRechercherPfiLireUn(Tracabilite, String, String)} return 200 OK
   * DONNE_INCONNUE
   *
   * @throws Exception
   */
  @Test
  public void testIndexRechercherPfiLireUn_KO_006() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final String clientOperateur = RandomStringUtils.randomAlphanumeric(5);
    final String noCompte = RandomStringUtils.randomAlphanumeric(5);
    final Retour retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, MessageFormat.format("indexRecherchePfi (clientOperateur:{0}, noCompte:{1}) inconnue", clientOperateur, noCompte)); //$NON-NLS-1$
    GetIndexRecherchePfiResponse indexRecherchePfiResponse = new GetIndexRecherchePfiResponse(RetourConverter.convertToJsonRetour(retour), null);

    final String partnerResponse = GsonTools.getIso8601Ms().toJson(indexRecherchePfiResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_indexRechercherPfiUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<IndexRecherchePfi>> result = _connector.indexRechercherPfiLireUn(tracabilite, clientOperateur, noCompte);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, CLIENT_OPERATEUR_QUERY_PARAM, clientOperateur, NO_COMPTE_QUERY_PARAM, noCompte);
    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
    Assert.assertEquals(0, result._second.size());
  }

  /**
   * Test the method {@link AIRConnector#indexRechercherPfiLireUn(Tracabilite, String, String)} return 200 OK
   *
   * @throws Exception
   */
  @Test
  public void testIndexRechercherPfiLireUn_OK_005() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final String clientOperateur = RandomStringUtils.randomAlphanumeric(5);
    final String noCompte = RandomStringUtils.randomAlphanumeric(5);
    IndexRecherchePfi indexRecherchePfi = _podam.manufacturePojo(IndexRecherchePfi.class);
    List<IndexRecherchePfi> listIndexRecherchePfi = Arrays.asList(indexRecherchePfi);
    final Retour retour = RetourFactory.createOkRetour();
    GetIndexRecherchePfiResponse indexRecherchePfiResponse = new GetIndexRecherchePfiResponse(RetourConverter.convertToJsonRetour(retour), listIndexRecherchePfi);

    final String partnerResponse = GsonTools.getIso8601Ms().toJson(indexRecherchePfiResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_indexRechercherPfiUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<IndexRecherchePfi>> result = _connector.indexRechercherPfiLireUn(tracabilite, clientOperateur, noCompte);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, CLIENT_OPERATEUR_QUERY_PARAM, clientOperateur, NO_COMPTE_QUERY_PARAM, noCompte);
    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
    Assert.assertEquals(1, result._second.size());
  }

  /**
   * Test the method {@link AIRConnector#indexRechercherPfiSupprimer(Tracabilite, String, String)} return 200 OK
   * DONNES_INCONNUE
   *
   * @throws Exception
   */
  @Test
  public void testIndexRechercherPfiSupprimer_KO_007() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final String clientOperateur = RandomStringUtils.randomAlphanumeric(5);
    final String noCompte = RandomStringUtils.randomAlphanumeric(5);
    final Retour retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, MessageFormat.format("indexRecherchePfi (clientOperateur:{0}, noCompte{1})", clientOperateur, noCompte)); //$NON-NLS-1$
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(basicResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();
    Capture<String> bodyCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.delete(EasyMock.eq(_indexRechercherPfiUrl), EasyMock.capture(headersCapture), EasyMock.capture(bodyCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.indexRechercherPfiSupprimer(tracabilite, clientOperateur, noCompte);

    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, CLIENT_OPERATEUR_QUERY_PARAM, clientOperateur, NO_COMPTE_QUERY_PARAM, noCompte);
    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);

  }

  /**
   * Test the method {@link AIRConnector#indexRechercherPfiSupprimer(Tracabilite, String, String)} return 200 OK
   *
   * @throws Exception
   */
  @Test
  public void testIndexRechercherPfiSupprimer_OK_006() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final String clientOperateur = RandomStringUtils.randomAlphanumeric(5);
    final String noCompte = RandomStringUtils.randomAlphanumeric(5);
    final Retour retour = RetourFactory.createOkRetour();
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(basicResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();
    Capture<String> bodyCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.delete(EasyMock.eq(_indexRechercherPfiUrl), EasyMock.capture(headersCapture), EasyMock.capture(bodyCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.indexRechercherPfiSupprimer(tracabilite, clientOperateur, noCompte);

    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, CLIENT_OPERATEUR_QUERY_PARAM, clientOperateur, NO_COMPTE_QUERY_PARAM, noCompte);
    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);

  }

  /**
   * Check the query params in rest send request method
   *
   * @param queryParams
   *          the actual query params
   * @param expected_p
   *          list of expected query params strings key1 value1 key2 value2...keyN valueN
   */
  private void checkQueryParams(Capture<Map<String, String>> queryParams, String... expected_p)
  {
    if (expected_p == null)
    {
      Assert.assertNull(queryParams.getValue());
    }
    else
    {
      Assert.assertEquals(0, expected_p.length % 2);
      for (int i = 0; i < expected_p.length; i = i + 2)
      {
        Assert.assertEquals(expected_p[i + 1], queryParams.getValue().get(expected_p[i]));
      }
    }
  }

  /**
   * Génération du LoadBalancer minimal pour passer {@link AbstractRESTConnector#loadConnectorConfiguration(Connector)}
   *
   * @return {@link LoadBalancer}
   */
  private LoadBalancer generateLoadBalancer()
  {
    final LoadBalancer loadBalancer = new LoadBalancer();
    Param timer = new Param();
    timer.setName("TIMER"); //$NON-NLS-1$
    timer.setValue("30"); //$NON-NLS-1$
    loadBalancer.getParam().add(timer);
    loadBalancer.setType("RoundRobin"); //$NON-NLS-1$
    return loadBalancer;
  }

  /**
   * Génération du URL minimal pour passer {@link AbstractRESTConnector#loadConnectorConfiguration(Connector)}
   *
   * @return {@link URL}
   */
  private URL generateURL()
  {
    final URL url = new URL();
    url.setName("urlName"); //$NON-NLS-1$
    url.setAccessPoint("http://localhost:8888"); //$NON-NLS-1$
    Param param = new Param();
    param.setName("PROXY_ENABLED"); //$NON-NLS-1$
    param.setValue(String.valueOf(false));
    url.getParam().add(param);
    param = new Param();
    param.setName("TIMEOUT"); //$NON-NLS-1$
    param.setValue("30"); //$NON-NLS-1$
    url.getParam().add(param);

    return url;
  }

  /**
   * @return URLS
   */
  private URLS generateURLS()
  {
    final URLS urls = new URLS();
    urls.setLoadBalancer(generateLoadBalancer());
    urls.getURL().add(generateURL());
    return urls;
  }

  /**
   * prepare mock scenario to initialize method sendRequest from AbstractRestConnector
   *
   * @throws Exception
   *           Thrown in case of error
   */
  private void initializeMocksForSendRequest() throws Exception
  {
    final String urlBalancedElementName = RandomStringUtils.randomAlphanumeric(45);
    final String urlBalancedElementDescription = RandomStringUtils.randomAlphabetic(9);

    EasyMock.expect(_loadBalancerMock.chooseBalancedElement()).andReturn(_urlBalancedElementMock);
    EasyMock.expect(_urlBalancedElementMock.getName()).andReturn(urlBalancedElementName);
    EasyMock.expect(_urlBalancedElementMock.getDescription()).andReturn(urlBalancedElementDescription);
    EasyMock.expect(_urlBalancedElementMock.getName()).andReturn(urlBalancedElementName);
    EasyMock.expect(_connectorPoolMock.get(urlBalancedElementName)).andReturn(_restConnectorPoolMock);
    EasyMock.expect(_restConnectorPoolMock.borrowObject()).andReturn(_restInstanceMock);
    _restInstanceMock.setReceiveTimeout(0);
  }
}
