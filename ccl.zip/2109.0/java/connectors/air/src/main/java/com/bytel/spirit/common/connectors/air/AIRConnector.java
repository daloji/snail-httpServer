/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.air;

import java.text.MessageFormat;
import java.util.HashMap;
import java.util.List;

import javax.ws.rs.HttpMethod;
import javax.ws.rs.core.Response;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.conf.generated.Param;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.services.conf.connector.generated.Connector;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.connector.RESTRequest.RESTRequestBuilder;
import com.bytel.spirit.common.shared.misc.connectors.AbstractInternalRESTConnector;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.BasicResponse;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.ressources.RetourConverter;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.air.IndexRecherchePfi;
import com.bytel.spirit.common.shared.saab.air.request.CreateIndexRecherchePfiRequest;
import com.bytel.spirit.common.shared.saab.air.response.GetIndexRecherchePfiResponse;

/**
 *
 * @author jgregori
 * @version ($Revision$ $Date$)
 */
public class AIRConnector extends AbstractInternalRESTConnector implements IAIRConnector
{
  /**
   * Parameter for PAD7001 operation
   */
  public static final String PAD7001_PATH_PARAM = "PAD7001_IndexRechercherPfi"; //$NON-NLS-1$
  /**
   * The constant for MissingConfigurationParameter
   */
  private static final String MESSAGE_MISSING_CONFIGURATION_PARAMETER = Messages.getString("AIRConnector.MissingConfigurationParameter"); //$NON-NLS-1$
  /**
   * The constant for JsonErrorMessage
   */
  private static final String MESSAGE_JSON_ERROR_MESSAGE = Messages.getString("AIRConnector.JsonErrorMessage"); //$NON-NLS-1$

  /**
   * The constant for indexRecherchePfiEcrire service
   */
  private static final String METHOD_NAME_INDEX_RECHERCHE_PFI_ECRIRE = "indexRecherchePfiEcrire"; //$NON-NLS-1$
  /**
   * The constant for indexRecherchePfiSupprimer service
   */
  private static final String METHOD_NAME_INDEX_RECHERCHE_PFI_SUPPRIMER = "indexRecherchePfiSupprimer"; //$NON-NLS-1$

  /**
   * The constant for indexRecherchePfiLireUn service
   */
  private static final String METHOD_NAME_INDEX_RECHERCHE_PFI_LIRE_UN = "indexRecherchePfiLireUn"; //$NON-NLS-1$
  /**
   * The constant for indexRecherchePfiLireTousParCleRecherche service
   */
  private static final String METHOD_NAME_INDEX_RECHERCHE_PFI_LIRE_TOUS_PAR_CLE_RECHERCHE = "indexRecherchePfiLireTousParCleRecherche"; //$NON-NLS-1$
  /**
   * The constant for clientOperateur param
   */
  private static final String PARAM_CLIENT_OPERATEUR = "clientOperateur"; //$NON-NLS-1$

  /**
   * The constant for noCompte param
   */
  private static final String PARAM_NO_COMPTE = "noCompte"; //$NON-NLS-1$

  /**
   * The constant for type param
   */
  private static final String PARAM_TYPE = "type"; //$NON-NLS-1$

  /**
   * The constant for valeur param
   */
  private static final String PARAM_VALEUR = "valeur"; //$NON-NLS-1$

  /**
   * Path for indexRechercherPfi
   */
  private String _indexRechercherPfiUrl;

  @Override
  public String getConfigParameter(String connectorID_p, String paramName_p) throws RavelException
  {
    return null;
  }

  @Override
  public ConnectorResponse<Retour, Nothing> indexRechercherPfiEcrire(Tracabilite tracabilite_p, CreateIndexRecherchePfiRequest request_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_indexRechercherPfiUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD7001_PATH_PARAM));
      }

      // Call SAAB
      final Response response;
      try
      {
        RESTRequestBuilder restRequestBuilder = new RESTRequestBuilder();
        restRequestBuilder.httpMethod(HttpMethod.POST).traceability(tracabilite_p).method(METHOD_NAME_INDEX_RECHERCHE_PFI_ECRIRE).headers(SPIRIT_STARK_REQUEST_HEADER).path(_indexRechercherPfiUrl).request(request_p);
        response = sendRequest(restRequestBuilder.build());
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content to a JSON string
      String jsonResponse = getContent(response, METHOD_NAME_INDEX_RECHERCHE_PFI_ECRIRE, tracabilite_p);

      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }

      BasicResponse basicResponse = GsonTools.getIso8601Ms().fromJson(jsonResponse, BasicResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(basicResponse.getRetour());

      return new ConnectorResponse<>(retour, null);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }

  }

  @Override
  public ConnectorResponse<Retour, List<IndexRecherchePfi>> indexRechercherPfiLireTousParCleRecherche(Tracabilite tracabilite_p, String type_p, String valeur_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_indexRechercherPfiUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD7001_PATH_PARAM));
      }

      // Build query parameters
      HashMap<String, String> queryParams = new HashMap<>();

      if (StringTools.isNotNullOrEmpty(type_p) && StringTools.isNotNullOrEmpty(valeur_p))
      {
        queryParams.put(PARAM_TYPE, type_p);
        queryParams.put(PARAM_VALEUR, valeur_p);
      }

      // Call SAAB
      final Response response;
      try
      {
        RESTRequestBuilder restRequestBuilder = new RESTRequestBuilder();
        restRequestBuilder.httpMethod(HttpMethod.GET).traceability(tracabilite_p).method(METHOD_NAME_INDEX_RECHERCHE_PFI_LIRE_TOUS_PAR_CLE_RECHERCHE).headers(SPIRIT_STARK_REQUEST_HEADER).path(_indexRechercherPfiUrl).queryParameter(queryParams);
        response = sendRequest(restRequestBuilder.build());
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content to a JSON string
      String jsonResponse = getContent(response, METHOD_NAME_INDEX_RECHERCHE_PFI_LIRE_TOUS_PAR_CLE_RECHERCHE, tracabilite_p);

      // Verify response
      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }

      GetIndexRecherchePfiResponse getIndexRecherchePfiResponse = GsonTools.getIso8601Ms().fromJson(jsonResponse, GetIndexRecherchePfiResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(getIndexRecherchePfiResponse.getRetour());
      List<IndexRecherchePfi> listeIndexRecherchePfi = getIndexRecherchePfiResponse.getListeIndexRecherchePfi();

      return new ConnectorResponse<>(retour, listeIndexRecherchePfi);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, List<IndexRecherchePfi>> indexRechercherPfiLireUn(Tracabilite tracabilite_p, String clientOperateur_p, String noCompte_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_indexRechercherPfiUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD7001_PATH_PARAM));
      }

      // Build query parameters
      HashMap<String, String> queryParams = new HashMap<>();

      if (StringTools.isNotNullOrEmpty(clientOperateur_p) && StringTools.isNotNullOrEmpty(noCompte_p))
      {
        queryParams.put(PARAM_CLIENT_OPERATEUR, clientOperateur_p);
        queryParams.put(PARAM_NO_COMPTE, noCompte_p);
      }

      // Call SAAB
      final Response response;
      try
      {
        RESTRequestBuilder restRequestBuilder = new RESTRequestBuilder();
        restRequestBuilder.httpMethod(HttpMethod.GET).traceability(tracabilite_p).method(METHOD_NAME_INDEX_RECHERCHE_PFI_LIRE_UN).headers(SPIRIT_STARK_REQUEST_HEADER).path(_indexRechercherPfiUrl).queryParameter(queryParams);
        response = sendRequest(restRequestBuilder.build());
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content to a JSON string
      String jsonResponse = getContent(response, METHOD_NAME_INDEX_RECHERCHE_PFI_LIRE_UN, tracabilite_p);

      // Verify response
      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }

      GetIndexRecherchePfiResponse getIndexRecherchePfiResponse = GsonTools.getIso8601Ms().fromJson(jsonResponse, GetIndexRecherchePfiResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(getIndexRecherchePfiResponse.getRetour());
      List<IndexRecherchePfi> listeIndexRecherchePfi = getIndexRecherchePfiResponse.getListeIndexRecherchePfi();

      return new ConnectorResponse<>(retour, listeIndexRecherchePfi);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, Nothing> indexRechercherPfiSupprimer(Tracabilite tracabilite_p, String clientOperateur_p, String noCompte_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_indexRechercherPfiUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD7001_PATH_PARAM));
      }

      // Build query parameters
      HashMap<String, String> queryParams = new HashMap<>();

      if (StringTools.isNotNullOrEmpty(clientOperateur_p) && StringTools.isNotNullOrEmpty(noCompte_p))
      {
        queryParams.put(PARAM_CLIENT_OPERATEUR, clientOperateur_p);
        queryParams.put(PARAM_NO_COMPTE, noCompte_p);
      }
      // Call SAAB
      final Response response;
      try
      {
        RESTRequestBuilder restRequestBuilder = new RESTRequestBuilder();
        restRequestBuilder.httpMethod(HttpMethod.DELETE).traceability(tracabilite_p).method(METHOD_NAME_INDEX_RECHERCHE_PFI_SUPPRIMER).headers(SPIRIT_STARK_REQUEST_HEADER).path(_indexRechercherPfiUrl).queryParameter(queryParams);
        response = sendRequest(restRequestBuilder.build());
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content to a JSON string
      String jsonResponse = getContent(response, METHOD_NAME_INDEX_RECHERCHE_PFI_SUPPRIMER, tracabilite_p);

      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }

      BasicResponse basicResponse = GsonTools.getIso8601Ms().fromJson(jsonResponse, BasicResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(basicResponse.getRetour());

      return new ConnectorResponse<>(retour, null);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public void loadConnectorConfiguration(Connector connector_p) throws RavelException
  {
    super.loadConnectorConfiguration(connector_p);

    // Get and validate specific configuration parameters
    for (Param param : connector_p.getParam())
    {
      switch (param.getName())
      {
        case PAD7001_PATH_PARAM:
          _indexRechercherPfiUrl = param.getValue();
          break;
        default:
          break;
      }
    }

  }

}
