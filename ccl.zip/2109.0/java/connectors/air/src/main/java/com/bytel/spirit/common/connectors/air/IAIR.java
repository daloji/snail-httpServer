/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.air;

import java.util.List;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.air.IndexRecherchePfi;
import com.bytel.spirit.common.shared.saab.air.request.CreateIndexRecherchePfiRequest;

/**
 *
 * @author jgregori
 * @version ($Revision$ $Date$)
 */
public interface IAIR
{

  /**
   * Create one IndexRechercherPfi
   *
   * @param tracabilite_p
   *          The Tracabilite
   * @param request_p
   *          The CreateIndexRecherchePfiRequest request
   * @return The retour
   * @throws RavelException
   *           Thrown if any errors occurred
   */
  public ConnectorResponse<Retour, Nothing> indexRechercherPfiEcrire(Tracabilite tracabilite_p, CreateIndexRecherchePfiRequest request_p) throws RavelException;

  /**
   * Get list of IndexRecherchePfi par cle recherche
   *
   * @param tracabilite_p
   *          The Tracabilite
   * @param type_p
   *          Type of cle recherche
   * @param valeur_p
   *          Valeur of cle recherche
   * @return The retour and the list of IndexRecherchePfi
   * @throws RavelException
   *           Thrown if any errors occurred
   */
  public ConnectorResponse<Retour, List<IndexRecherchePfi>> indexRechercherPfiLireTousParCleRecherche(Tracabilite tracabilite_p, String type_p, String valeur_p) throws RavelException;

  /**
   * Get list of IndexRecherchePfi (with one element) par clientOperateur et noCompte
   *
   * @param tracabilite_p
   *          The Tracabilite
   * @param clientOperateur_p
   *          The clientOperateur
   * @param noCompte_p
   *          The noCompte
   * @return The retour and the list of IndexRecherchePfi
   * @throws RavelException
   *           Thrown if any errors occurred
   */
  public ConnectorResponse<Retour, List<IndexRecherchePfi>> indexRechercherPfiLireUn(Tracabilite tracabilite_p, String clientOperateur_p, String noCompte_p) throws RavelException;

  /**
   * Deletes one IndexRechercherPfi
   *
   * @param tracabilite_p
   *          The Tracabilite
   * @param clientOperateur_p
   *          The clientOperateur
   * @param noCompte_p
   *          The noCompte
   * @return The retour
   * @throws RavelException
   *           Thrown if any errors occurred
   */
  public ConnectorResponse<Retour, Nothing> indexRechercherPfiSupprimer(Tracabilite tracabilite_p, String clientOperateur_p, String noCompte_p) throws RavelException;

}
