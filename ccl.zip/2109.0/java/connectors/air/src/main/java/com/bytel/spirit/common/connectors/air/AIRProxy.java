/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.air;

import java.util.List;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.probes.AvgDoubleCollectorItem;
import com.bytel.ravel.common.probes.AvgFlowPerSecondCollector;
import com.bytel.ravel.common.probes.RavelProbeConfigurationManager;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.services.connector.BaseProxy;
import com.bytel.ravel.services.connector.ConnectorExecution;
import com.bytel.ravel.services.connector.ConnectorManager;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.air.IndexRecherchePfi;
import com.bytel.spirit.common.shared.saab.air.request.CreateIndexRecherchePfiRequest;

/**
 *
 * @author jgregori
 * @version ($Revision$ $Date$)
 */
public final class AIRProxy extends BaseProxy implements IAIR
{
  /**
   * Proxy instance.
   */
  private static AIRProxy _instance = new AIRProxy();

  /**
   * @return The proxy instance.
   */
  public static AIRProxy getInstance()
  {
    return _instance;
  }

  /**
   * For probe to count the amount of call to the indexRecherchePfiEcrire operation
   */
  AvgFlowPerSecondCollector _avg_indexRecherchePfiEcrire_call_counter;
  /**
   * For probe to count the execution time of call to the indexRecherchePfiEcrire operation
   */
  AvgDoubleCollectorItem _avg_indexRecherchePfiEcrire_ExecTime;

  /**
   * For probe to count the amount of call to the indexRecherchePfiLireUn operation
   */
  AvgFlowPerSecondCollector _avg_indexRecherchePfiLireUn_call_counter;
  /**
   * For probe to count the execution time of call to the indexRecherchePfiLireUn operation
   */
  AvgDoubleCollectorItem _avg_indexRecherchePfiLireUn_ExecTime;

  /**
   * For probe to count the amount of call to the indexRecherchePfiLireTousParCleRecherche operation
   */
  AvgFlowPerSecondCollector _avg_indexRecherchePfiLireTousParCleRecherche_call_counter;
  /**
   * For probe to count the execution time of call to the indexRecherchePfiLireTousParCleRecherche operation
   */
  AvgDoubleCollectorItem _avg_indexRecherchePfiLireTousParCleRecherche_ExecTime;

  /**
   * For probe to count the amount of call to the indexRecherchePfiSupprimer operation
   */
  AvgFlowPerSecondCollector _avg_indexRecherchePfiSupprimer_call_counter;
  /**
   * For probe to count the execution time of call to the indexRecherchePfiSupprimer operation
   */
  AvgDoubleCollectorItem _avg_indexRecherchePfiSupprimer_ExecTime;

  /**
   * private Constructor
   */
  private AIRProxy()
  {
    _avg_indexRecherchePfiEcrire_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_indexRecherchePfiEcrire_call_counter", "AIRProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_indexRecherchePfiEcrire_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_indexRecherchePfiEcrire_ExecTime", "AIRProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_indexRecherchePfiLireUn_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_indexRecherchePfiLireUn_call_counter", "AIRProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_indexRecherchePfiLireUn_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_indexRecherchePfiLireUn_ExecTime", "AIRProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_indexRecherchePfiLireTousParCleRecherche_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_indexRecherchePfiLireTousParCleRecherche_call_counter", "AIRProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_indexRecherchePfiLireTousParCleRecherche_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_indexRecherchePfiLireTousParCleRecherche_ExecTime", "AIRProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_indexRecherchePfiSupprimer_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_indexRecherchePfiSupprimer_call_counter", "AIRProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_indexRecherchePfiSupprimer_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_indexRecherchePfiSupprimer_ExecTime", "AIRProxy"); //$NON-NLS-1$//$NON-NLS-2$

  }

  @Override
  public ConnectorResponse<Retour, Nothing> indexRechercherPfiEcrire(Tracabilite tracabilite_p, CreateIndexRecherchePfiRequest request_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IAIRConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        IAIRConnector iairConnector = null;
        try
        {
          iairConnector = (IAIRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          // Retour NOK
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_indexRecherchePfiEcrire_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return iairConnector.indexRechercherPfiEcrire(tracabilite_p, request_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_indexRecherchePfiEcrire_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, List<IndexRecherchePfi>> indexRechercherPfiLireTousParCleRecherche(Tracabilite tracabilite_p, String type_p, String valeur_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, List<IndexRecherchePfi>>>(IAIRConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, List<IndexRecherchePfi>> run() throws RavelException
      {
        IAIRConnector iairConnector = null;
        try
        {
          iairConnector = (IAIRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          // Retour NOK
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_indexRecherchePfiLireTousParCleRecherche_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return iairConnector.indexRechercherPfiLireTousParCleRecherche(tracabilite_p, type_p, valeur_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_indexRecherchePfiLireTousParCleRecherche_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, List<IndexRecherchePfi>> indexRechercherPfiLireUn(Tracabilite tracabilite_p, String clientOperateur_p, String noCompte_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, List<IndexRecherchePfi>>>(IAIRConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, List<IndexRecherchePfi>> run() throws RavelException
      {
        IAIRConnector iairConnector = null;
        try
        {
          iairConnector = (IAIRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          // Retour NOK
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_indexRecherchePfiLireUn_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return iairConnector.indexRechercherPfiLireUn(tracabilite_p, clientOperateur_p, noCompte_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_indexRecherchePfiLireUn_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> indexRechercherPfiSupprimer(Tracabilite tracabilite_p, String clientOperateur_p, String noCompte_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IAIRConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        IAIRConnector iairConnector = null;
        try
        {
          iairConnector = (IAIRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          // Retour NOK
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_indexRecherchePfiSupprimer_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return iairConnector.indexRechercherPfiSupprimer(tracabilite_p, clientOperateur_p, noCompte_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_indexRecherchePfiSupprimer_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

}
