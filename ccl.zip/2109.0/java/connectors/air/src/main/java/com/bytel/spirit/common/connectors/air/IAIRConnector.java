/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.air;

import com.bytel.ravel.services.connector.IConnector;

/**
 *
 * @author jgregori
 * @version ($Revision$ $Date$)
 */
public interface IAIRConnector extends IAIR, IConnector
{

  /**
   * The id to retrieve the connector.
   */
  public String BEAN_ID = "AIRConnector"; //$NON-NLS-1$
}
