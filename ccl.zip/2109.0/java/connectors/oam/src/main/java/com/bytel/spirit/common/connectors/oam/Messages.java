package com.bytel.spirit.common.connectors.oam;

import java.text.MessageFormat;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

/**
 * Messages
 *
 * @author $Author$
 * @version ($Revision: 24858 $ $Date: 2019-08-05 14:09:27 +0200 (lun. 05 août 2019) $)
 */
public final class Messages
{

  /**
   * DOUBLON_NON_TROUVE_ERR_MSG
   */
  public static final String DOUBLON_NON_TROUVE_ERR_MSG = "OAMConnector.DoublonNonTrouveErrMsg"; //$NON-NLS-1$
  /**
   * ERREUR_OAM_AUCUNE_SESSION
   */
  public static final String ERREUR_OAM_AUCUNE_SESSION = "OAMConnector.ERREUR_OAM_AUCUNE_SESSION"; //$NON-NLS-1$

  /**
   * ERREUR_OAM_BASE_OAM_INCOHERENTE
   */
  public static final String ERREUR_OAM_BASE_OAM_INCOHERENTE = "OAMConnector.ERREUR_OAM_BASE_OAM_INCOHERENTE"; //$NON-NLS-1$
  /**
   * ERREUR_OAM_DEMANDE_A_METTRE_A_JOUR_INEXISTANTE
   */
  public static final String ERREUR_OAM_DEMANDE_A_METTRE_A_JOUR_INEXISTANTE = "OAMConnector.ERREUR_OAM_DEMANDE_A_METTRE_A_JOUR_INEXISTANTE"; //$NON-NLS-1$
  /**
   * ERREUR_OAM_TIMEOUT_CONNEXION
   */
  public static final String ERREUR_OAM_TIMEOUT_CONNEXION = "OAMConnector.ERREUR_OAM_TIMEOUT_CONNEXION"; //$NON-NLS-1$
  /**
   * ERREUR_OAM_TIMEOUT_SUR_NON_REPONSE
   */
  public static final String ERREUR_OAM_TIMEOUT_SUR_NON_REPONSE = "OAMConnector.ERREUR_OAM_TIMEOUT_SUR_NON_REPONSE"; //$NON-NLS-1$
  /**
   * ERREUR_REQUEST_ID_INTROUVABLE
   */
  public static final String ERREUR_REQUEST_ID_INTROUVABLE = "OAMConnector.ERREUR_REQUEST_ID_INTROUVABLE"; //$NON-NLS-1$
  /**
   * EXCEPTION
   */
  public static final String EXCEPTION = "OAMConnector.ExceptionMessage";//$NON-NLS-1$
  /**
   * INVALID_PARAMETER
   */
  public static final String INVALID_PARAMETER = "OAMConnector.InvalidParameter"; //$NON-NLS-1$
  /**
   * MISSING_PARAMETER
   */
  public static final String MISSING_PARAMETER = "OAMConnector.MissingParameter";//$NON-NLS-1$

  /**
   * TECHNICAL_EXCEPTION
   */
  public static final String TECHNICAL_EXCEPTION = "OAMConnector.TechnicalExceptionMessage";//$NON-NLS-1$
  /**
   * WARNING_OAM_DOUBLON_ACTE_METIER
   */
  public static final String WARNING_OAM_DOUBLON_ACTE_METIER = "OAMConnector.WARNING_OAM_DOUBLON_ACTE_METIER"; //$NON-NLS-1$

  /**
   * WARNING_OAM_DOUBLON_DEMANDE
   */
  public static final String WARNING_OAM_DOUBLON_DEMANDE = "OAMConnector.WARNING_OAM_DOUBLON_DEMANDE"; //$NON-NLS-1$

  /**
   * BUNDLE_NAME
   */
  private static final String BUNDLE_NAME = "com.bytel.spirit.common.connectors.oam.messages"; //$NON-NLS-1$
  /**
   *
   */
  private static final ResourceBundle RESOURCE_BUNDLE = ResourceBundle.getBundle(Messages.BUNDLE_NAME);

  /**
   * Gets the string.
   *
   * @param key_p
   *          the key
   * @return the value
   */
  public static String getString(String key_p)
  {
    try
    {
      return Messages.RESOURCE_BUNDLE.getString(key_p);
    }
    catch (MissingResourceException e)
    {
      return '!' + key_p + '!';
    }
  }

  /**
   * Returns a message formatted with the supplied pattern and arguments
   *
   * @param pattern_p
   *          pattern
   * @param arguments_p
   *          arguments
   * @return String
   */
  public static String getString(String pattern_p, Object... arguments_p)
  {
    return MessageFormat.format(pattern_p, arguments_p);
  }

  /**
   *
   */
  private Messages()
  {
  }
}
