/*******************************************************************************
 * $Id: IOAM.java 39986 2020-08-14 10:14:05Z lmerces $
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.oam;

import java.time.LocalDateTime;
import java.util.List;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

/**
 * The Interface IOAM for OAM DB operations.
 *
 * @author $Author$
 * @version ($Revision: 39986 $ $Date: 2020-08-14 12:14:05 +0200 (ven. 14 août 2020) $)
 */
public interface IOAM
{
  /**
   * Invocation of the stored procedure P_ConsulterDemandesAAcquitter . Gets n entries in OAM table DE_SDS by IDTITF and
   * where notification state is New or KOTech
   *
   * @param tracabilite_p
   *          tracabilite
   * @param nbMaxEntrees_p
   *          Max entries to be returned
   * @param sIdtItf_p
   *          Client instance to search (IDTITF)
   * @param iTimeOut_p
   *          Response timeout in seconds
   *
   * @return A list of max FolowUpTable, older entries first
   *
   * @throws RavelException
   *           exception thrown
   */
  ConnectorResponse<List<FollowUpTable>, Retour> consulterDemandesAAcquitter(Tracabilite tracabilite_p, final int nbMaxEntrees_p, final String sIdtItf_p, final int iTimeOut_p) throws RavelException;

  /**
   * Invocation of the stored procedure PG_SPIRIT.P_GET_LAST_PROV_REQUEST.
   *
   * @param tracabilite_p
   *          tracabilite
   * @param msisdn_p
   *          msisdn instance to search
   *
   * @return the last called request
   *
   * @throws RavelException
   *           exception thrown
   */
  ConnectorResponse<OamRequest, Retour> consultLastProvisioningRequestFromMsisdn(Tracabilite tracabilite_p, final String msisdn_p) throws RavelException;

  /**
   * Invocation of the stored procedure P_001_C_LastProvRequest. Gets 1 request in OAM_REQUEST table OAM by
   * SUBSCRIBER_ID and where the request is the last called request.
   *
   * @param tracabilite_p
   *          tracabilite
   * @param pfi_p
   *          pfi instance to search
   *
   * @return the last called request
   *
   * @throws RavelException
   *           exception thrown
   */
  ConnectorResponse<OamRequest, Retour> consultLastProvisioningRequestFromPfi(Tracabilite tracabilite_p, final String pfi_p) throws RavelException;

  /**
   * @param tracabilite_p
   * @param requestId_p
   * @return
   * @throws RavelException
   */
  ConnectorResponse<OamRequest, Retour> getOamRequest(Tracabilite tracabilite_p, String requestId_p) throws RavelException;

  /**
   * Invocation of the stored procedure P_GET_OAM_REQUEST_ORIGINATOR.
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param demandeur_p
   *          the demandeur.
   * @param statut_p
   *          the statut.
   * @param dateDebut_p
   *          the dateDebut.
   * @param dateFin_p
   *          the dateFin.
   *
   * @return a ConnectorResponse<List<OamRequest>, Retour>.
   *
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<List<OamRequest>, Retour> getOamRequestOriginator(Tracabilite tracabilite_p, final String demandeur_p, final String statut_p, final LocalDateTime dateDebut_p, final LocalDateTime dateFin_p) throws RavelException;

  /**
   * @param tracabilite_p
   * @param requestId_p
   * @return
   * @throws RavelException
   */
  ConnectorResponse<String, Retour> getRequestIccid(Tracabilite tracabilite_p, String requestId_p) throws RavelException;

  /**
   * Invocation of the stored procedure P_InsererDemandeSuivi . Inserts request in OAM table DE_SDS.
   *
   * @param tracabilite_p
   *          tracabilite
   * @param tableSuivi_p
   *          Data to be stored in the table DE_SDS
   * @return response from the stored procedure
   * @throws RavelException
   *           exception thrown
   */
  ConnectorResponse<FollowUpTable, Retour> insererDemandeSuivi(Tracabilite tracabilite_p, final FollowUpTable tableSuivi_p) throws RavelException;

  /**
   * Invocation of the stored procedure P_INS_REQUEST . Inserts request in OAM table OAM_REQUEST.
   *
   * @param tracabilite_p
   *          tracabilite
   * @param requestId_p
   *          requestId
   * @param orderId_p
   *          orderId
   * @param inDateTime_p
   *          inDateTime
   * @param outDateTime_p
   *          outDateTime
   * @param originator_p
   *          originator
   * @param status_p
   *          status
   * @param priority_p
   *          priority
   * @param verb_p
   *          verb
   * @param customSim_p
   *          customSim
   * @param errorMsg_p
   *          errorMsg
   * @return response from the stored procedure
   * @throws RavelException
   *           exception
   */
  ConnectorResponse<Nothing, Retour> insererRequest(Tracabilite tracabilite_p, String requestId_p, String orderId_p, LocalDateTime inDateTime_p, LocalDateTime outDateTime_p, String originator_p, String status_p, int priority_p, String verb_p, String customSim_p, String errorMsg_p) throws RavelException;

  /**
   * Invocation of the stored procedure P_MettreAJourDemandeSuivi . Updates a request in OAM table DE_SDS.
   *
   * @param tracabilite_p
   *          tracabilite
   * @param tableSuivi_p
   *          Data to be stored in the table DE_SDS
   * @return response from the stored procedure
   * @throws RavelException
   *           exception thrown
   */
  ConnectorResponse<Integer, Retour> mettreAJourDemandeSuivi(Tracabilite tracabilite_p, final FollowUpTable tableSuivi_p) throws RavelException;

  /**
   *
   * @param tracabilite_p
   * @param requestId_p
   * @param outDateTime_p
   * @param originator_p
   * @param status_p
   * @param customSim_p
   * @param errorMsg_p
   * @return ConnectorResponse<Nothing, Retour>
   * @throws RavelException
   */
  ConnectorResponse<Nothing, Retour> mettreAJourMsgErreurDansRequest(Tracabilite tracabilite_p, String requestId_p, LocalDateTime outDateTime_p, String originator_p, String status_p, String customSim_p, String errorMsg_p) throws RavelException;

  /**
   *
   * @param tracabilite_p
   * @param requestId_p
   * @param outDateTime_p
   * @param originator_p
   * @param status_p
   * @param customSim_p
   * @return ConnectorResponse<Nothing, Retour>
   * @throws RavelException
   */
  ConnectorResponse<Nothing, Retour> mettreAJourRequest(Tracabilite tracabilite_p, String requestId_p, LocalDateTime outDateTime_p, String originator_p, String status_p, String customSim_p) throws RavelException;

  /**
   * @param tracabilite_p
   * @param requestId_p
   * @param originator_p
   * @param status_p
   * @param outDateTime_p
   * @param verb_p
   * @return
   * @throws RavelException
   */
  ConnectorResponse<Nothing, Retour> mettreAJourRequest(Tracabilite tracabilite_p, String requestId_p, String originator_p, String status_p, LocalDateTime outDateTime_p, String verb_p) throws RavelException;
}
