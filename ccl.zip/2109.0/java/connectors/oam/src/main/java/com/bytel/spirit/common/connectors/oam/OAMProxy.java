/*******************************************************************************
 * $Id: OAMProxy.java 39986 2020-08-14 10:14:05Z lmerces $
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.oam;

import java.time.LocalDateTime;
import java.util.List;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.probes.AvgDoubleCollectorItem;
import com.bytel.ravel.common.probes.AvgFlowPerSecondCollector;
import com.bytel.ravel.common.probes.RavelProbeConfigurationManager;
import com.bytel.ravel.services.connector.BaseDBProxy;
import com.bytel.ravel.services.connector.ConnectorExecution;
import com.bytel.ravel.services.connector.ConnectorManager;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

/**
 * Proxy for the OAM connector
 *
 * @author $Author$
 * @version ($Revision: 39986 $ $Date: 2020-08-14 12:14:05 +0200 (ven. 14 août 2020) $)
 */
public class OAMProxy extends BaseDBProxy implements IOAM
{
  /**
   * Proxy instance.
   */
  private static final OAMProxy INSTANCE = new OAMProxy();

  /**
   * Gets the single instance of OAMProxy.
   *
   * @return The OAM proxy instance.
   */
  public static OAMProxy getInstance()
  {
    return OAMProxy.INSTANCE;
  }

  /**
   * Probe: measure the average number of InsererDemandSuivi calls per second.
   */
  protected AvgFlowPerSecondCollector _avg_psInsererDemandSuivi_call_counter;

  /**
   * Probe: measure the average execution time of the InsererDemandSuivi operation.
   */
  protected AvgDoubleCollectorItem _avg_psInsererDemandSuivi_ExecTime;

  /**
   * Probe: measure the average number of MettreAJourDemandSuivi calls per second.
   */
  protected AvgFlowPerSecondCollector _avg_psMettreAJourDemandSuivi_call_counter;

  /**
   * Probe: measure the average execution time of the MettreAJourDemandSuivi operation.
   */
  protected AvgDoubleCollectorItem _avg_psMettreAJourDemandSuivi_ExecTime;

  /**
   * Probe: measure the average number of ConsulterDemandesAAcquitter calls per second.
   */
  protected AvgFlowPerSecondCollector _avg_psConsulterDemandesAAcquitter_call_counter;

  /**
   * Probe: measure the average execution time of the ConsulterDemandesAAcquitter operation
   */
  protected AvgDoubleCollectorItem _avg_psConsulterDemandesAAcquitter_ExecTime;

  /**
   * Probe: measure the average number of consultLastProvisioningRequestFromPfi calls per second.
   */
  protected AvgFlowPerSecondCollector _avg_psConsultLastProvisioningRequestFromPfi_call_counter;

  /**
   * Probe: measure the average execution time of the consultLastProvisioningRequestFromPfi operation
   */
  protected AvgDoubleCollectorItem _avg_psConsultLastProvisioningRequestFromPfi_ExecTime;

  /**
   * Probe: measure the average number of consultLastProvisioningRequestFromMsisdn calls per second.
   */
  protected AvgFlowPerSecondCollector _avg_psConsultLastProvisioningRequestFromMsisdn_call_counter;

  /**
   * Probe: measure the average execution time of the consultLastProvisioningRequestFromMsisdn operation
   */
  protected AvgDoubleCollectorItem _avg_psConsultLastProvisioningRequestFromMsisdn_ExecTime;

  /**
   * Probe: measure the average number of insererRequest calls per second.
   */
  protected AvgFlowPerSecondCollector _avg_psInsererRequest_call_counter;

  /**
   * Probe: measure the average execution time of the insererRequest operation
   */
  protected AvgDoubleCollectorItem _avg_psInsererRequest_ExecTime;

  /**
   * Probe: measure the average number of mettreAJourRequest calls per second.
   */
  protected AvgFlowPerSecondCollector _avg_psMettreAJourRequest_call_counter;

  /**
   * Probe: measure the average execution time of the mettreAJourRequest operation
   */
  protected AvgDoubleCollectorItem _avg_psMettreAJourRequest_ExecTime;

  /**
   * Probe: measure the average number of getRequestIccid calls per second.
   */
  protected AvgFlowPerSecondCollector _avg_psGetRequestIccid_call_counter;

  /**
   * Probe: measure the average execution time of the getRequestIccid operation
   */
  protected AvgDoubleCollectorItem _avg_psGetRequestIccid_ExecTime;

  /**
   * Probe: measure the average number of getOamRequest calls per second.
   */
  protected AvgFlowPerSecondCollector _avg_psGetOamRequest_call_counter;

  /**
   * Probe: measure the average execution time of the getOamRequest operation
   */
  protected AvgDoubleCollectorItem _avg_psGetOamRequest_ExecTime;

  /**
   * Default constructor.
   */
  public OAMProxy()
  {
    // probes
    RavelProbeConfigurationManager manager = RavelProbeConfigurationManager.getInstance();
    String proxyName = "OAMProxy"; //$NON-NLS-1$
    _avg_psInsererDemandSuivi_call_counter = manager.createAvgFlowPerSecondCollector("Avg_psInsererDemandSuivi_call_per_second", proxyName); //$NON-NLS-1$
    _avg_psInsererDemandSuivi_ExecTime = manager.createAvgDoubleCollectorItem("Avg_psInsererDemandSuivi_ExecTime", proxyName); //$NON-NLS-1$
    _avg_psMettreAJourDemandSuivi_call_counter = manager.createAvgFlowPerSecondCollector("Avg_psMettreAJourDemandSuivi_call_per_second", proxyName); //$NON-NLS-1$
    _avg_psMettreAJourDemandSuivi_ExecTime = manager.createAvgDoubleCollectorItem("Avg_psMettreAJourDemandSuivi_ExecTime", proxyName); //$NON-NLS-1$
    _avg_psConsulterDemandesAAcquitter_call_counter = manager.createAvgFlowPerSecondCollector("Avg_psConsulterDemandesAAcquitter_call_per_second", proxyName); //$NON-NLS-1$
    _avg_psConsulterDemandesAAcquitter_ExecTime = manager.createAvgDoubleCollectorItem("Avg_psConsulterDemandesAAcquitter_ExecTime", proxyName); //$NON-NLS-1$
    _avg_psConsultLastProvisioningRequestFromPfi_call_counter = manager.createAvgFlowPerSecondCollector("Avg_psConsultLastProvisioningRequestFromPfi_call_per_second", proxyName); //$NON-NLS-1$
    _avg_psConsultLastProvisioningRequestFromPfi_ExecTime = manager.createAvgDoubleCollectorItem("Avg_psConsultLastProvisioningRequestFromPfi_ExecTime", proxyName); //$NON-NLS-1$
    _avg_psConsultLastProvisioningRequestFromMsisdn_call_counter = manager.createAvgFlowPerSecondCollector("Avg_psConsultLastProvisioningRequestFromMsisdn_call_per_second", proxyName); //$NON-NLS-1$
    _avg_psConsultLastProvisioningRequestFromMsisdn_ExecTime = manager.createAvgDoubleCollectorItem("Avg_psConsultLastProvisioningRequestFromMsisdn_ExecTime", proxyName); //$NON-NLS-1$
    _avg_psInsererRequest_call_counter = manager.createAvgFlowPerSecondCollector("Avg_psInsererRequest_call_counter", proxyName); //$NON-NLS-1$
    _avg_psInsererRequest_ExecTime = manager.createAvgDoubleCollectorItem("Avg_psInsererRequest_ExecTime", proxyName); //$NON-NLS-1$
    _avg_psMettreAJourRequest_call_counter = manager.createAvgFlowPerSecondCollector("Avg_psMettreAJourRequest_call_counter", proxyName); //$NON-NLS-1$
    _avg_psMettreAJourRequest_ExecTime = manager.createAvgDoubleCollectorItem("Avg_psMettreAJourRequest_ExecTime", proxyName); //$NON-NLS-1$
    _avg_psGetRequestIccid_call_counter = manager.createAvgFlowPerSecondCollector("Avg_psGetRequestIccid_call_counter", proxyName); //$NON-NLS-1$
    _avg_psGetRequestIccid_ExecTime = manager.createAvgDoubleCollectorItem("Avg_psGetRequestIccid_ExecTime", proxyName); //$NON-NLS-1$
    _avg_psGetOamRequest_call_counter = manager.createAvgFlowPerSecondCollector("Avg_psGetOamRequest_call_counter", proxyName); //$NON-NLS-1$
    _avg_psGetOamRequest_ExecTime = manager.createAvgDoubleCollectorItem("Avg_psGetOamRequest_ExecTime", proxyName); //$NON-NLS-1$
  }

  @Override
  public ConnectorResponse<List<FollowUpTable>, Retour> consulterDemandesAAcquitter(Tracabilite tracabilite_p, int nbMaxEntrees_p, String sIdtItf_p, int iTimeOut_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<List<FollowUpTable>, Retour>>(IOAMConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<List<FollowUpTable>, Retour> run() throws RavelException
      {
        IOAMConnector oamConnector = (IOAMConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_psConsulterDemandesAAcquitter_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          ConnectorResponse<List<FollowUpTable>, Retour> response = oamConnector.consulterDemandesAAcquitter(tracabilite_p, nbMaxEntrees_p, sIdtItf_p, iTimeOut_p);
          return response;
        }
        finally
        {
          Long endTime = System.currentTimeMillis();
          _avg_psConsulterDemandesAAcquitter_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<OamRequest, Retour> consultLastProvisioningRequestFromMsisdn(Tracabilite tracabilite_p, String msisdn_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<OamRequest, Retour>>(IOAMConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<OamRequest, Retour> run() throws RavelException
      {
        IOAMConnector oamConnector = (IOAMConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_psConsultLastProvisioningRequestFromMsisdn_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return oamConnector.consultLastProvisioningRequestFromMsisdn(tracabilite_p, msisdn_p);
        }
        finally
        {
          Long endTime = System.currentTimeMillis();
          _avg_psConsultLastProvisioningRequestFromMsisdn_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<OamRequest, Retour> consultLastProvisioningRequestFromPfi(Tracabilite tracabilite_p, String pfi_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<OamRequest, Retour>>(IOAMConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<OamRequest, Retour> run() throws RavelException
      {
        IOAMConnector oamConnector = (IOAMConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_psConsultLastProvisioningRequestFromPfi_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return oamConnector.consultLastProvisioningRequestFromPfi(tracabilite_p, pfi_p);
        }
        finally
        {
          Long endTime = System.currentTimeMillis();
          _avg_psConsultLastProvisioningRequestFromPfi_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<OamRequest, Retour> getOamRequest(Tracabilite tracabilite_p, String requestId_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<OamRequest, Retour>>(IOAMConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<OamRequest, Retour> run() throws RavelException
      {
        IOAMConnector oamConnector = (IOAMConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_psGetOamRequest_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return oamConnector.getOamRequest(tracabilite_p, requestId_p);
        }
        finally
        {
          Long endTime = System.currentTimeMillis();
          _avg_psGetOamRequest_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<List<OamRequest>, Retour> getOamRequestOriginator(Tracabilite tracabilite_p, final String demandeur_p, final String statut_p, final LocalDateTime dateDebut_p, final LocalDateTime dateFin_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<List<OamRequest>, Retour>>(IOAMConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<List<OamRequest>, Retour> run() throws RavelException
      {
        IOAMConnector oamConnector = (IOAMConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_psGetOamRequest_call_counter.measure();
        long startTime = System.currentTimeMillis();

        try
        {
          return oamConnector.getOamRequestOriginator(tracabilite_p, demandeur_p, statut_p, dateDebut_p, dateFin_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_psGetOamRequest_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<String, Retour> getRequestIccid(Tracabilite tracabilite_p, String requestId_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<String, Retour>>(IOAMConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<String, Retour> run() throws RavelException
      {
        IOAMConnector oamConnector = (IOAMConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_psGetRequestIccid_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return oamConnector.getRequestIccid(tracabilite_p, requestId_p);
        }
        finally
        {
          Long endTime = System.currentTimeMillis();
          _avg_psGetRequestIccid_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<FollowUpTable, Retour> insererDemandeSuivi(Tracabilite tracabilite_p, final FollowUpTable tableSuivi_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<FollowUpTable, Retour>>(IOAMConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<FollowUpTable, Retour> run() throws RavelException
      {
        IOAMConnector oamConnector = (IOAMConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_psInsererDemandSuivi_call_counter.measure();
        long startTime = System.currentTimeMillis();

        try
        {
          ConnectorResponse<FollowUpTable, Retour> response = oamConnector.insererDemandeSuivi(tracabilite_p, tableSuivi_p);
          return response;
        }
        finally
        {
          Long endTime = System.currentTimeMillis();
          _avg_psInsererDemandSuivi_ExecTime.updateAvgValue(endTime - startTime);
        }

      }
    });
  }

  @Override
  public ConnectorResponse<Nothing, Retour> insererRequest(Tracabilite tracabilite_p, String requestId_p, String orderId_p, LocalDateTime inDateTime_p, LocalDateTime outDateTime_p, String originator_p, String status_p, int priority_p, String verb_p, String customSim_p, String errorMSG_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Nothing, Retour>>(IOAMConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Nothing, Retour> run() throws RavelException
      {
        IOAMConnector oamConnector = (IOAMConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_psInsererRequest_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          ConnectorResponse<Nothing, Retour> response = oamConnector.insererRequest(tracabilite_p, requestId_p, orderId_p, inDateTime_p, outDateTime_p, originator_p, status_p, priority_p, verb_p, customSim_p, errorMSG_p);
          return response;
        }
        finally
        {
          Long endTime = System.currentTimeMillis();
          _avg_psInsererRequest_ExecTime.updateAvgValue(endTime - startTime);
        }

      }
    });
  }

  @Override
  public ConnectorResponse<Integer, Retour> mettreAJourDemandeSuivi(Tracabilite tracabilite_p, final FollowUpTable tableSuivi_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Integer, Retour>>(IOAMConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Integer, Retour> run() throws RavelException
      {
        IOAMConnector oamConnector = (IOAMConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_psMettreAJourDemandSuivi_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          ConnectorResponse<Integer, Retour> response = oamConnector.mettreAJourDemandeSuivi(tracabilite_p, tableSuivi_p);
          return response;
        }
        finally
        {
          Long endTime = System.currentTimeMillis();
          _avg_psMettreAJourDemandSuivi_ExecTime.updateAvgValue(endTime - startTime);
        }

      }
    });
  }

  @Override
  public ConnectorResponse<Nothing, Retour> mettreAJourMsgErreurDansRequest(Tracabilite tracabilite_p, String requestId_p, LocalDateTime outDateTime_p, String originator_p, String status_p, String customSim_p, String errorMsg_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Nothing, Retour>>(IOAMConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Nothing, Retour> run() throws RavelException
      {
        IOAMConnector oamConnector = (IOAMConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_psMettreAJourRequest_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return oamConnector.mettreAJourMsgErreurDansRequest(tracabilite_p, requestId_p, outDateTime_p, originator_p, status_p, customSim_p, errorMsg_p);
        }
        finally
        {
          Long endTime = System.currentTimeMillis();
          _avg_psMettreAJourRequest_ExecTime.updateAvgValue(endTime - startTime);
        }

      }
    });
  }

  @Override
  public ConnectorResponse<Nothing, Retour> mettreAJourRequest(Tracabilite tracabilite_p, String requestId_p, LocalDateTime outDateTime_p, String originator_p, String status_p, String customSim_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Nothing, Retour>>(IOAMConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Nothing, Retour> run() throws RavelException
      {
        IOAMConnector oamConnector = (IOAMConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_psMettreAJourRequest_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return oamConnector.mettreAJourRequest(tracabilite_p, requestId_p, outDateTime_p, originator_p, status_p, customSim_p);
        }
        finally
        {
          Long endTime = System.currentTimeMillis();
          _avg_psMettreAJourRequest_ExecTime.updateAvgValue(endTime - startTime);
        }

      }
    });
  }

  @Override
  public ConnectorResponse<Nothing, Retour> mettreAJourRequest(Tracabilite tracabilite_p, String requestId_p, String originator_p, String status_p, LocalDateTime outDateTime_p, String verb_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Nothing, Retour>>(IOAMConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Nothing, Retour> run() throws RavelException
      {
        IOAMConnector oamConnector = (IOAMConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_psMettreAJourRequest_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return oamConnector.mettreAJourRequest(tracabilite_p, requestId_p, originator_p, status_p, outDateTime_p, verb_p);
        }
        finally
        {
          Long endTime = System.currentTimeMillis();
          _avg_psMettreAJourRequest_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }
}
