/*******************************************************************************
 * $Id: OAMConnector.java 43196 2020-11-03 13:11:36Z jjoly $
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.oam;

import static java.util.Objects.nonNull;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLRecoverableException;
import java.sql.SQLTimeoutException;
import java.sql.Timestamp;
import java.text.MessageFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.apache.tomcat.jdbc.pool.PoolExhaustedException;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.conf.generated.Param;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionTools;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.services.conf.connector.generated.Connector;
import com.bytel.ravel.services.connector.AbstractDBConnector;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

import oracle.jdbc.OracleTypes;

/**
 * Connector OAM.
 *
 * @author $Author$
 * @version ($Revision: 43196 $ $Date: 2020-11-03 14:11:36 +0100 (mar. 03 nov. 2020) $)
 */
public class OAMConnector extends AbstractDBConnector implements IOAMConnector
{
  /**
   * Defines all mandatory parameters read from configuration file.
   *
   * @author $Author$
   * @version ($Revision: 43196 $ $Date: 2020-11-03 14:11:36 +0100 (mar. 03 nov. 2020) $)
   */
  protected enum ParameterName
  {
    /** Connect timeout parameter, in seconds. */
    CONNECT_TIMEOUT_SEC,

    /** The URL parameter. */
    DB_CONNECTIONSTRING,

    /** The PASSWORD parameter. */
    DB_PASSWORD,

    /** The USERNAME parameter. */
    DB_USERNAME,

    /** The POOLSIZE parameter. */
    POOLSIZE,

    /** Read timeout parameter, in seconds. */
    READ_TIMEOUT_SEC
  }

  /**
   * Table DE_DSD fields.
   *
   * @author vborrego
   *
   */
  private enum TableDeSDSFields
  {
    /** */
    DATCREACT,

    /** */
    DATDEBTRT,

    /** */
    DATFINTRT,

    /** */
    DATNTF,

    /** */
    ETANTF,

    /** */
    ETAPRO,

    /** */
    ETARCP,

    /** */
    IN_IDTACT,

    /** */
    IDTACT,

    /** */
    IN_IDTDDE,

    /** */
    IDTDDE,

    /** */
    IDTITF,

    /** */
    IDTPARSIC,

    /** */
    IDTSYSTEC,

    /** */
    LIBNTF,

    /** */
    LIBPRO,

    /** */
    LIBRCP,

    /** */
    NBRPFI,

    /** */
    NBRPFIPRO,

    /** */
    NOMSVC,

    /** */
    TYPNTF
  }

  /** Constant for DEMANDE_NON_UNIQUE. */
  public static final String DEMANDE_NON_UNIQUE = "DEMANDE_NON_UNIQUE"; //$NON-NLS-1$

  /** Constant for DOUBLON_A_RETRAITER. */
  public static final String DOUBLON_A_RETRAITER = "DOUBLON_A_RETRAITER"; //$NON-NLS-1$

  /** Constant for DOUBLON_DEJA_TRAITE. */
  public static final String DOUBLON_DEJA_TRAITE = "DOUBLON_DEJA_TRAITE"; //$NON-NLS-1$

  /** Constant for DOUBLON_NON_TROUVE. */
  public static final String DOUBLON_NON_TROUVE = "DOUBLON_NON_TROUVE"; //$NON-NLS-1$

  /** Constant for ECHEC CONNEXION. */
  public static final String ECHEC_CONNEXION = "ECHEC_CONNEXION"; //$NON-NLS-1$

  /** Constant for ECHEC_INSERTION. */
  public static final String ECHEC_INSERTION = "ECHEC_INSERTION"; //$NON-NLS-1$

  /** Constant for ENTREE_INEXISTANTE. */
  public static final String ENTREE_INEXISTANTE = "ENTREE_INEXISTANTE"; //$NON-NLS-1$

  /** Constant for INDISPONIBILITE_SESSION. */
  public static final String INDISPONIBILITE_SESSION = "INDISPONIBILITE_SESSION"; //$NON-NLS-1$

  /** Constant for DOUBLON_TROUVE. */
  private static final String DOUBLON_TROUVE = "DOUBLON_TROUVE"; //$NON-NLS-1$

  /** Constant for TIMEOUT_CONSULTATION. */
  private static final String TIMEOUT_CONSULTATION = "TIMEOUT_CONSULTATION"; //$NON-NLS-1$

  /** Constant for ONE_SECOND_IN_MILLISECONDS. */
  private static final int ONE_SECOND_IN_MILLISECONDS = 1000;

  /** Constant for datasource connection properties. */
  private static final String CONNECTION_PROPERTIES = "oracle.net.CONNECT_TIMEOUT=%d;oracle.jdbc.ReadTimeout=%d"; //$NON-NLS-1$

  /** Parameters read from configuration. */
  private Map<ParameterName, String> _parameters = new HashMap<>();

  /** Connect timeout in seconds. */
  private int _connectTimeoutSec;

  /** Read timeout in seconds. */
  private int _readTimeoutSec;

  @Override
  public ConnectorResponse<List<FollowUpTable>, Retour> consulterDemandesAAcquitter(Tracabilite tracabilite_p, int nbMaxEntrees_p, String sIdtItf_p, int iTimeOut_p) throws RavelException
  {
    ResultSet rs = null;
    Connection con = null;

    _dsReadLock.lock();
    final String methodName = "PG_IWSRESSOURCES.P_ConsulterDemandesAAcquitter"; //$NON-NLS-1$

    try
    {
      con = _datasource.getConnection();
      CallableStatement cs = con.prepareCall(String.format("{call %s(?,?,?,?,?,?,?) }", methodName)); //$NON-NLS-1$
      cs.setQueryTimeout(iTimeOut_p);

      cs.setInt("iNbMaxEntrees_p", nbMaxEntrees_p); //$NON-NLS-1$
      cs.setString("sIdtItf_p", sIdtItf_p); //$NON-NLS-1$

      cs.registerOutParameter("cursorx", OracleTypes.CURSOR); //$NON-NLS-1$
      cs.registerOutParameter("Retour_Resultat", OracleTypes.NVARCHAR); //$NON-NLS-1$
      cs.registerOutParameter("Retour_Categorie", OracleTypes.NVARCHAR); //$NON-NLS-1$
      cs.registerOutParameter("Retour_Diagnostic", OracleTypes.NVARCHAR); //$NON-NLS-1$
      cs.registerOutParameter("Retour_Libelle", OracleTypes.NVARCHAR); //$NON-NLS-1$

      cs.execute();

      rs = (ResultSet) cs.getObject("cursorx"); //$NON-NLS-1$

      List<FollowUpTable> requestToNotifList = mapResultSetToFollowUpTable(rs);

      Retour retour = getRetour(cs);

      return new ConnectorResponse<>(requestToNotifList, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, e.getMessage());

      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, TIMEOUT_CONSULTATION, MessageFormat.format(Messages.getString(Messages.ERREUR_OAM_TIMEOUT_SUR_NON_REPONSE), iTimeOut_p));
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, e.getMessage());

      // No sessions/connections available in the connection pool
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INDISPONIBILITE_SESSION, Messages.getString(Messages.ERREUR_OAM_AUCUNE_SESSION));
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, e.getMessage());

      // When unable to connect
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, ECHEC_CONNEXION, MessageFormat.format(Messages.getString(Messages.ERREUR_OAM_TIMEOUT_CONNEXION), _connectTimeoutSec));
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, e.getMessage());
    }
    finally
    {
      close(rs, con);
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<OamRequest, Retour> consultLastProvisioningRequestFromMsisdn(Tracabilite tracabilite_p, String msisdn_p) throws RavelException
  {
    ResultSet resultSet = null;
    Connection connection = null;

    _dsReadLock.lock();
    final String methodName = "PG_SPIRIT.P_GET_LAST_PROV_REQUEST"; //$NON-NLS-1$

    try
    {
      connection = _datasource.getConnection();

      CallableStatement callableStatement = connection.prepareCall(String.format("{call %s(?,?,?,?,?,?) }", methodName)); //$NON-NLS-1$
      callableStatement.setQueryTimeout(_readTimeoutSec);

      callableStatement.setString("pi_msisdn", msisdn_p); //$NON-NLS-1$

      callableStatement.registerOutParameter("po_RESULT", OracleTypes.CURSOR); //$NON-NLS-1$
      callableStatement.registerOutParameter("Retour_Resultat", OracleTypes.NVARCHAR); //$NON-NLS-1$
      callableStatement.registerOutParameter("Retour_Categorie", OracleTypes.NVARCHAR); //$NON-NLS-1$
      callableStatement.registerOutParameter("Retour_Diagnostic", OracleTypes.NVARCHAR); //$NON-NLS-1$
      callableStatement.registerOutParameter("Retour_Libelle", OracleTypes.NVARCHAR); //$NON-NLS-1$

      callableStatement.execute();

      resultSet = (ResultSet) callableStatement.getObject("po_RESULT"); //$NON-NLS-1$

      OamRequest reqOAM = null;
      if ((resultSet != null) && (resultSet.next()))
      {
        reqOAM = new OamRequest(resultSet);
      }

      Retour retour = getRetour(callableStatement);

      return new ConnectorResponse<>(reqOAM, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, e.getMessage());

      // When insert takes too long
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, ECHEC_INSERTION, MessageFormat.format(Messages.getString(Messages.ERREUR_OAM_TIMEOUT_SUR_NON_REPONSE), _readTimeoutSec));
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, e.getMessage());

      // No sessions/connections available in the connection pool
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INDISPONIBILITE_SESSION, Messages.getString(Messages.ERREUR_OAM_AUCUNE_SESSION));
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, e.getMessage());

      // When unable to connect
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, ECHEC_CONNEXION, MessageFormat.format(Messages.getString(Messages.ERREUR_OAM_TIMEOUT_CONNEXION), _connectTimeoutSec));
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, e.getMessage());
    }
    finally
    {
      close(resultSet, connection);
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<OamRequest, Retour> consultLastProvisioningRequestFromPfi(Tracabilite tracabilite_p, final String pfi_p) throws RavelException
  {
    ResultSet resultSet = null;
    Connection connection = null;

    _dsReadLock.lock();
    final String methodName = "PG_IWSRESSOURCES.P_001_C_LastProvRequest"; //$NON-NLS-1$

    try
    {
      connection = _datasource.getConnection();

      CallableStatement callableStatement = connection.prepareCall(String.format("{call %s(?,?,?,?,?,?) }", methodName)); //$NON-NLS-1$
      callableStatement.setQueryTimeout(_readTimeoutSec);

      callableStatement.setString("pi_SUBSCRIBER_ID", pfi_p); //$NON-NLS-1$

      callableStatement.registerOutParameter("po_RESULT", OracleTypes.CURSOR); //$NON-NLS-1$
      callableStatement.registerOutParameter("Retour_Resultat", OracleTypes.NVARCHAR); //$NON-NLS-1$
      callableStatement.registerOutParameter("Retour_Categorie", OracleTypes.NVARCHAR); //$NON-NLS-1$
      callableStatement.registerOutParameter("Retour_Diagnostic", OracleTypes.NVARCHAR); //$NON-NLS-1$
      callableStatement.registerOutParameter("Retour_Libelle", OracleTypes.NVARCHAR); //$NON-NLS-1$

      callableStatement.execute();

      resultSet = (ResultSet) callableStatement.getObject("po_RESULT"); //$NON-NLS-1$

      OamRequest reqOAM = null;
      if ((resultSet != null) && (resultSet.next()))
      {
        reqOAM = new OamRequest(resultSet);
      }

      Retour retour = getRetour(callableStatement);

      return new ConnectorResponse<>(reqOAM, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, e.getMessage());

      // When insert takes too long
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, ECHEC_INSERTION, MessageFormat.format(Messages.getString(Messages.ERREUR_OAM_TIMEOUT_SUR_NON_REPONSE), _readTimeoutSec));
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, e.getMessage());

      // No sessions/connections available in the connection pool
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INDISPONIBILITE_SESSION, Messages.getString(Messages.ERREUR_OAM_AUCUNE_SESSION));
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, e.getMessage());

      // When unable to connect
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, ECHEC_CONNEXION, MessageFormat.format(Messages.getString(Messages.ERREUR_OAM_TIMEOUT_CONNEXION), _connectTimeoutSec));
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, e.getMessage());
    }
    finally
    {
      close(resultSet, connection);
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<OamRequest, Retour> getOamRequest(Tracabilite tracabilite_p, String requestId_p) throws RavelException
  {
    ResultSet resultSet = null;
    Connection connection = null;

    _dsReadLock.lock();
    final String methodName = "PG_SPIRIT.P_GET_OAM_REQUEST"; //$NON-NLS-1$

    try
    {
      connection = _datasource.getConnection();

      CallableStatement callableStatement = connection.prepareCall(String.format("{call %s(?,?,?,?,?,?) }", methodName)); //$NON-NLS-1$
      callableStatement.setQueryTimeout(_readTimeoutSec);

      callableStatement.setString("pi_requestId", requestId_p); //$NON-NLS-1$

      callableStatement.registerOutParameter("po_RESULT", OracleTypes.CURSOR); //$NON-NLS-1$
      callableStatement.registerOutParameter("Retour_Resultat", OracleTypes.NVARCHAR); //$NON-NLS-1$
      callableStatement.registerOutParameter("Retour_Categorie", OracleTypes.NVARCHAR); //$NON-NLS-1$
      callableStatement.registerOutParameter("Retour_Diagnostic", OracleTypes.NVARCHAR); //$NON-NLS-1$
      callableStatement.registerOutParameter("Retour_Libelle", OracleTypes.NVARCHAR); //$NON-NLS-1$

      callableStatement.execute();

      resultSet = (ResultSet) callableStatement.getObject("po_RESULT"); //$NON-NLS-1$

      OamRequest reqOAM = null;

      if ((resultSet != null) && (resultSet.next()))
      {
        reqOAM = new OamRequest(resultSet);
      }

      Retour retour = getRetour(callableStatement);

      return new ConnectorResponse<>(reqOAM, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, e.getMessage());

      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, ECHEC_INSERTION, MessageFormat.format(Messages.getString(Messages.ERREUR_OAM_TIMEOUT_SUR_NON_REPONSE), _readTimeoutSec));
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, e.getMessage());

      // No sessions/connections available in the connection pool
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INDISPONIBILITE_SESSION, Messages.getString(Messages.ERREUR_OAM_AUCUNE_SESSION));
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, e.getMessage());

      // When unable to connect
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, ECHEC_CONNEXION, MessageFormat.format(Messages.getString(Messages.ERREUR_OAM_TIMEOUT_CONNEXION), _connectTimeoutSec));
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, e.getMessage());
    }
    finally
    {
      close(resultSet, connection);
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<List<OamRequest>, Retour> getOamRequestOriginator(Tracabilite tracabilite_p, final String demandeur_p, final String statut_p, final LocalDateTime dateDebut_p, final LocalDateTime dateFin_p) throws RavelException
  {
    ResultSet resultSet = null;
    Connection connection = null;

    _dsReadLock.lock();
    final String methodName = "PG_SPIRIT.P_GET_OAM_REQUEST_ORIGINATOR"; //$NON-NLS-1$

    try
    {
      connection = _datasource.getConnection();

      CallableStatement callableStatement = connection.prepareCall(String.format("{call %s(?,?,?,?,?,?,?,?,?) }", methodName)); //$NON-NLS-1$
      callableStatement.setQueryTimeout(_readTimeoutSec);

      callableStatement.setString("pi_originator", demandeur_p); //$NON-NLS-1$
      callableStatement.setString("pi_status", statut_p); //$NON-NLS-1$
      callableStatement.setTimestamp("pi_dateDebut", Timestamp.valueOf(dateDebut_p)); //$NON-NLS-1$
      callableStatement.setTimestamp("pi_dateFin", Timestamp.valueOf(dateFin_p)); //$NON-NLS-1$

      callableStatement.registerOutParameter("po_RESULT", OracleTypes.CURSOR); //$NON-NLS-1$
      callableStatement.registerOutParameter("Retour_Resultat", OracleTypes.NVARCHAR); //$NON-NLS-1$
      callableStatement.registerOutParameter("Retour_Categorie", OracleTypes.NVARCHAR); //$NON-NLS-1$
      callableStatement.registerOutParameter("Retour_Diagnostic", OracleTypes.NVARCHAR); //$NON-NLS-1$
      callableStatement.registerOutParameter("Retour_Libelle", OracleTypes.NVARCHAR); //$NON-NLS-1$

      callableStatement.execute();

      resultSet = (ResultSet) callableStatement.getObject("po_RESULT"); //$NON-NLS-1$

      List<OamRequest> oamRequestList = new ArrayList<>();

      if (resultSet != null)
      {
        while (resultSet.next())
        {
          oamRequestList.add(new OamRequest(resultSet));
        }
      }

      Retour retour = getRetour(callableStatement);

      return new ConnectorResponse<>(oamRequestList, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, e.getMessage());

      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, ECHEC_INSERTION, MessageFormat.format(Messages.getString(Messages.ERREUR_OAM_TIMEOUT_SUR_NON_REPONSE), _readTimeoutSec));
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, e.getMessage());

      // No sessions/connections available in the connection pool
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INDISPONIBILITE_SESSION, Messages.getString(Messages.ERREUR_OAM_AUCUNE_SESSION));
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, e.getMessage());

      // When unable to connect
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, ECHEC_CONNEXION, MessageFormat.format(Messages.getString(Messages.ERREUR_OAM_TIMEOUT_CONNEXION), _connectTimeoutSec));
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, e.getMessage());
    }
    finally
    {
      close(resultSet, connection);
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<String, Retour> getRequestIccid(Tracabilite tracabilite_p, String requestId_p) throws RavelException
  {
    Connection connection = null;

    _dsReadLock.lock();
    final String methodName = "PG_SPIRIT.P_GET_REQUEST_ICCID"; //$NON-NLS-1$

    try
    {
      connection = _datasource.getConnection();

      CallableStatement callableStatement = connection.prepareCall(String.format("{call %s(?,?,?,?,?,?) }", methodName)); //$NON-NLS-1$
      callableStatement.setQueryTimeout(_readTimeoutSec);

      callableStatement.setString("pi_requestId", requestId_p); //$NON-NLS-1$

      callableStatement.registerOutParameter("po_ICCID", OracleTypes.VARCHAR); //$NON-NLS-1$
      callableStatement.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      callableStatement.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      callableStatement.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      callableStatement.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      callableStatement.execute();

      Retour retour = getRetour(callableStatement);
      String iccid = callableStatement.getString("po_ICCID"); //$NON-NLS-1$

      SpiritLogEvent outputLog = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, methodName);
      outputLog.addField("Retour", retour, false); //$NON-NLS-1$
      RavelLogger.log(outputLog);
      return new ConnectorResponse<>(iccid, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, "requestId:" + requestId_p); //$NON-NLS-1$

      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, ECHEC_INSERTION, MessageFormat.format(Messages.getString(Messages.ERREUR_OAM_TIMEOUT_SUR_NON_REPONSE), _readTimeoutSec));
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, "requestId:" + requestId_p); //$NON-NLS-1$

      //no sessions/connections available in the connection pool
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INDISPONIBILITE_SESSION, Messages.getString(Messages.ERREUR_OAM_AUCUNE_SESSION));
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, "requestId:" + requestId_p); //$NON-NLS-1$

      // when not able to connect
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, ECHEC_CONNEXION, MessageFormat.format(Messages.getString(Messages.ERREUR_OAM_TIMEOUT_CONNEXION), _connectTimeoutSec));
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, "requestId:" + requestId_p); //$NON-NLS-1$
    }
    finally
    {
      close(null, connection);
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<FollowUpTable, Retour> insererDemandeSuivi(Tracabilite tracabilite_p, FollowUpTable tableSuivi_p) throws RavelException
  {
    ResultSet resultSet = null;
    Connection connection = null;

    _dsReadLock.lock();
    final String methodName = "PG_IWSRESSOURCES.P_InsererDemandeSuivi"; //$NON-NLS-1$

    try
    {
      connection = _datasource.getConnection();

      CallableStatement callableStatement = connection.prepareCall(String.format("{call %s(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) }", methodName)); //$NON-NLS-1$
      callableStatement.setQueryTimeout(_readTimeoutSec);

      callableStatement.setString(TableDeSDSFields.IN_IDTDDE.name(), tableSuivi_p.getIdtDde());
      callableStatement.setString(TableDeSDSFields.NOMSVC.name(), tableSuivi_p.getNomSvc());
      callableStatement.setString(TableDeSDSFields.IDTSYSTEC.name(), tableSuivi_p.getIdtSysTec());
      callableStatement.setInt(TableDeSDSFields.IDTPARSIC.name(), tableSuivi_p.getIdtParSic());
      callableStatement.setString(TableDeSDSFields.IN_IDTACT.name(), tableSuivi_p.getIdtAct());
      callableStatement.setTimestamp(TableDeSDSFields.DATCREACT.name(), Timestamp.valueOf(tableSuivi_p.getDatCreact()));
      callableStatement.setString(TableDeSDSFields.IDTITF.name(), tableSuivi_p.getIdtItf());
      callableStatement.setInt(TableDeSDSFields.NBRPFI.name(), tableSuivi_p.getNbrPfi());
      callableStatement.setInt(TableDeSDSFields.NBRPFIPRO.name(), tableSuivi_p.getNbrPfiPro());
      callableStatement.setTimestamp(TableDeSDSFields.DATDEBTRT.name(), Timestamp.valueOf((tableSuivi_p.getDatDebTrt())));
      callableStatement.setString(TableDeSDSFields.ETARCP.name(), tableSuivi_p.getEtaRcp());
      callableStatement.setString(TableDeSDSFields.LIBRCP.name(), tableSuivi_p.getLibRcp());

      // optional fields
      callableStatement.setTimestamp(TableDeSDSFields.DATFINTRT.name(), null);
      if (tableSuivi_p.getDatFinTrt() != null)
      {
        callableStatement.setTimestamp(TableDeSDSFields.DATFINTRT.name(), Timestamp.valueOf(tableSuivi_p.getDatFinTrt()));
      }

      callableStatement.setString(TableDeSDSFields.ETAPRO.name(), null);
      if (tableSuivi_p.getEtapro() != null)
      {
        callableStatement.setString(TableDeSDSFields.ETAPRO.name(), tableSuivi_p.getEtapro());
      }

      callableStatement.setString(TableDeSDSFields.LIBPRO.name(), null);
      if (tableSuivi_p.getLibPro() != null)
      {
        callableStatement.setString(TableDeSDSFields.LIBPRO.name(), tableSuivi_p.getLibPro());
      }

      callableStatement.setString(TableDeSDSFields.ETANTF.name(), null);
      if (tableSuivi_p.getEtaNtf() != null)
      {
        callableStatement.setString(TableDeSDSFields.ETANTF.name(), tableSuivi_p.getEtaNtf());
      }

      callableStatement.setString(TableDeSDSFields.LIBNTF.name(), null);
      if (tableSuivi_p.getLibNtf() != null)
      {
        callableStatement.setString(TableDeSDSFields.LIBNTF.name(), tableSuivi_p.getLibNtf());
      }

      callableStatement.setString(TableDeSDSFields.TYPNTF.name(), null);
      if (tableSuivi_p.getTypNtf() != null)
      {
        callableStatement.setString(TableDeSDSFields.TYPNTF.name(), tableSuivi_p.getTypNtf());
      }

      callableStatement.setTimestamp(TableDeSDSFields.DATNTF.name(), null);
      if (tableSuivi_p.getDatNtf() != null)
      {
        callableStatement.setTimestamp(TableDeSDSFields.DATNTF.name(), Timestamp.valueOf(tableSuivi_p.getDatNtf()));
      }

      callableStatement.registerOutParameter("po_RESULT", OracleTypes.CURSOR); //$NON-NLS-1$
      callableStatement.registerOutParameter("Retour_Resultat", OracleTypes.NVARCHAR); //$NON-NLS-1$
      callableStatement.registerOutParameter("Retour_Categorie", OracleTypes.NVARCHAR); //$NON-NLS-1$
      callableStatement.registerOutParameter("Retour_Diagnostic", OracleTypes.NVARCHAR); //$NON-NLS-1$
      callableStatement.registerOutParameter("Retour_Libelle", OracleTypes.NVARCHAR); //$NON-NLS-1$

      callableStatement.execute();

      resultSet = (ResultSet) callableStatement.getObject("po_RESULT"); //$NON-NLS-1$
      List<FollowUpTable> listeTableSuivi = mapResultSetToFollowUpTable(resultSet);

      Retour retour = getRetour(callableStatement);
      if (StringConstants.KO.equals(retour.getResultat()))
      {
        if (!DOUBLON_TROUVE.equals(retour.getDiagnostic()))
        {
          //autre erreur !
          return new ConnectorResponse<>(null, retour);
        }

        //ici, doublon détecté

        if (listeTableSuivi.isEmpty())
        {
          //cas exceptionnel: la demande qui aurait dû être remontée par la procédure n'existe plus car vient d'être supprimée par un script de purge
          retour = RetourFactory.createKO(IMegConsts.CAT3, DOUBLON_NON_TROUVE, Messages.getString(Messages.DOUBLON_NON_TROUVE_ERR_MSG));
          return new ConnectorResponse<>(null, retour);
        }
        //Ano 320440
        if (listeTableSuivi.size() >= 1)
        {
          //ici, on a récupéré l'enregistrement en base
          FollowUpTable existingTableSuivi = listeTableSuivi.get(0);

          if (!StringConstants.OK.equals(existingTableSuivi.getEtaRcp()) && !StringConstants.OK.equals(existingTableSuivi.getEtapro()))
          {
            retour.setResultat(StringConstants.OK);
            retour.setDiagnostic(DOUBLON_A_RETRAITER);
          }
          else
          {
            retour.setResultat(StringConstants.OK);
            retour.setDiagnostic(DOUBLON_DEJA_TRAITE);
          }

          if (existingTableSuivi.getIdtDde().equals(tableSuivi_p.getIdtDde()))
          {
            retour.setLibelle(Messages.getString(Messages.WARNING_OAM_DOUBLON_DEMANDE));
          }
          else
          {
            retour.setLibelle(Messages.getString(Messages.WARNING_OAM_DOUBLON_ACTE_METIER));
          }

          return new ConnectorResponse<>(existingTableSuivi, retour);
        }
      }

      //ici, la demande a été inserée avec succès !
      retour.setDiagnostic("PROVISIONING"); //$NON-NLS-1$
      return new ConnectorResponse<>(tableSuivi_p, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, e.getMessage());

      // when insert takes too long
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, ECHEC_INSERTION, MessageFormat.format(Messages.getString(Messages.ERREUR_OAM_TIMEOUT_SUR_NON_REPONSE), _readTimeoutSec));
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, e.getMessage());

      //no sessions/connections available in the connection pool
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INDISPONIBILITE_SESSION, Messages.getString(Messages.ERREUR_OAM_AUCUNE_SESSION));
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, e.getMessage());

      // when not able to connect
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, ECHEC_CONNEXION, MessageFormat.format(Messages.getString(Messages.ERREUR_OAM_TIMEOUT_CONNEXION), _connectTimeoutSec));
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, e.getMessage());
    }
    finally
    {
      close(resultSet, connection);
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<Nothing, Retour> insererRequest(Tracabilite tracabilite_p, String requestId_p, String orderId_p, LocalDateTime inDateTime_p, LocalDateTime outDateTime_p, String originator_p, String status_p, int priority_p, String verb_p, String customSim_p, String errorMSG_p) throws RavelException
  {
    Connection connection = null;

    _dsReadLock.lock();
    final String methodName = "PG_SPIRIT.P_INS_REQUEST"; //$NON-NLS-1$

    try
    {
      connection = _datasource.getConnection();

      CallableStatement callableStatement = connection.prepareCall(String.format("{call %s(?,?,?,?,?,?,?,?,?,?,?,?,?,?) }", methodName)); //$NON-NLS-1$
      callableStatement.setQueryTimeout(_readTimeoutSec);

      callableStatement.setString("pi_requestId", requestId_p); //$NON-NLS-1$
      callableStatement.setString("pi_orderId", orderId_p); //$NON-NLS-1$
      callableStatement.setTimestamp("pi_inDateTime", Timestamp.valueOf(inDateTime_p)); //$NON-NLS-1$
      callableStatement.setTimestamp("pi_outDateTime", outDateTime_p != null ? Timestamp.valueOf(outDateTime_p) : null); //$NON-NLS-1$
      callableStatement.setString("pi_originator", originator_p); //$NON-NLS-1$
      callableStatement.setString("pi_status", status_p); //$NON-NLS-1$
      callableStatement.setInt("pi_priority", priority_p); //$NON-NLS-1$
      callableStatement.setString("pi_verb", verb_p); //$NON-NLS-1$
      callableStatement.setString("pi_customSim", customSim_p); //$NON-NLS-1$
      callableStatement.setString("pi_errorMsg", errorMSG_p); //$NON-NLS-1$
      callableStatement.registerOutParameter("Retour_Resultat", OracleTypes.NVARCHAR); //$NON-NLS-1$
      callableStatement.registerOutParameter("Retour_Categorie", OracleTypes.NVARCHAR); //$NON-NLS-1$
      callableStatement.registerOutParameter("Retour_Diagnostic", OracleTypes.NVARCHAR); //$NON-NLS-1$
      callableStatement.registerOutParameter("Retour_Libelle", OracleTypes.NVARCHAR); //$NON-NLS-1$

      callableStatement.execute();

      Retour retour = getRetour(callableStatement);

      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, e.getMessage());

      // when insert takes too long
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, ECHEC_INSERTION, MessageFormat.format(Messages.getString(Messages.ERREUR_OAM_TIMEOUT_SUR_NON_REPONSE), _readTimeoutSec));
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, e.getMessage());

      //no sessions/connections available in the connection pool
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INDISPONIBILITE_SESSION, Messages.getString(Messages.ERREUR_OAM_AUCUNE_SESSION));
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, e.getMessage());

      // when not able to connect
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, ECHEC_CONNEXION, MessageFormat.format(Messages.getString(Messages.ERREUR_OAM_TIMEOUT_CONNEXION), _connectTimeoutSec));
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, e.getMessage());
    }
    finally
    {
      close(null, connection);
      _dsReadLock.unlock();
    }
  }

  @Override
  public void loadConnectorConfiguration(Connector connector_p) throws RavelException
  {
    // Read parameters.
    _name = connector_p.getName();
    _enabled = connector_p.isEnabled();

    for (Param parameter : connector_p.getParam())
    {
      ParameterName parameterName = ParameterName.valueOf(parameter.getName().toUpperCase());
      _parameters.put(parameterName, parameter.getValue());
    }

    // Check parameters
    String connectionString = _parameters.get(ParameterName.DB_CONNECTIONSTRING);
    if (StringTools.isNullOrEmpty(connectionString))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(Messages.getString(Messages.MISSING_PARAMETER), _name, ParameterName.DB_CONNECTIONSTRING.toString()));
    }

    String dbUserName = _parameters.get(ParameterName.DB_USERNAME);
    if (StringTools.isNullOrEmpty(dbUserName))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(Messages.getString(Messages.MISSING_PARAMETER), _name, ParameterName.DB_USERNAME.toString()));
    }

    String dbPassword = _parameters.get(ParameterName.DB_PASSWORD);
    if (StringTools.isNullOrEmpty(dbPassword))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(Messages.getString(Messages.MISSING_PARAMETER), _name, ParameterName.DB_PASSWORD.toString()));
    }

    String poolSize = _parameters.get(ParameterName.POOLSIZE);

    String connectTimeoutSec = _parameters.get(ParameterName.CONNECT_TIMEOUT_SEC);
    if (StringTools.isNullOrEmpty(connectTimeoutSec))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(Messages.getString(Messages.MISSING_PARAMETER), _name, ParameterName.CONNECT_TIMEOUT_SEC.toString()));
    }
    try
    {
      _connectTimeoutSec = Integer.parseInt(connectTimeoutSec);
    }
    catch (NumberFormatException e)
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00021, MessageFormat.format(Messages.getString(Messages.INVALID_PARAMETER), _name, _parameters.get(ParameterName.CONNECT_TIMEOUT_SEC)));
    }

    String readTimeoutSec = _parameters.get(ParameterName.READ_TIMEOUT_SEC);
    if (StringTools.isNullOrEmpty(readTimeoutSec))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(Messages.getString(Messages.MISSING_PARAMETER), _name, ParameterName.READ_TIMEOUT_SEC.toString()));
    }
    try
    {
      _readTimeoutSec = Integer.parseInt(readTimeoutSec);
    }
    catch (NumberFormatException e)
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00021, MessageFormat.format(Messages.getString(Messages.INVALID_PARAMETER), _name, _parameters.get(ParameterName.READ_TIMEOUT_SEC)));
    }
    createDataSource(connectionString, dbUserName, dbPassword, poolSize, DatabaseType.ORACLE);
    _datasource.setConnectionProperties(String.format(CONNECTION_PROPERTIES, _connectTimeoutSec * ONE_SECOND_IN_MILLISECONDS, _readTimeoutSec * ONE_SECOND_IN_MILLISECONDS));
  }

  @Override
  public ConnectorResponse<Integer, Retour> mettreAJourDemandeSuivi(Tracabilite tracabilite_p, FollowUpTable tableSuivi_p) throws RavelException
  {
    Connection connection = null;

    _dsReadLock.lock();
    final String methodName = "PG_IWSRESSOURCES.P_MettreAJourDemandeSuivi"; //$NON-NLS-1$

    try
    {
      connection = _datasource.getConnection();

      CallableStatement callableStatement = connection.prepareCall(String.format("{call %s(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) }", methodName)); //$NON-NLS-1$
      callableStatement.setQueryTimeout(_readTimeoutSec);

      // mandatory
      callableStatement.setString("IDTDDE_p", tableSuivi_p.getIdtDde()); //$NON-NLS-1$

      // optional fields
      callableStatement.setString("NOMSVC_p", null); //$NON-NLS-1$
      if (tableSuivi_p.getNomSvc() != null)
      {
        callableStatement.setString("NOMSVC_p", tableSuivi_p.getNomSvc()); //$NON-NLS-1$
      }

      callableStatement.setString("IDTSYSTEC_p", null); //$NON-NLS-1$
      if (tableSuivi_p.getIdtSysTec() != null)
      {
        callableStatement.setString("IDTSYSTEC_p", tableSuivi_p.getIdtSysTec()); //$NON-NLS-1$
      }

      callableStatement.setObject("IDTPARSIC_p", null); //$NON-NLS-1$
      if (tableSuivi_p.getIdtParSic() != null)
      {
        callableStatement.setInt("IDTPARSIC_p", tableSuivi_p.getIdtParSic()); //$NON-NLS-1$
      }

      callableStatement.setString("IDTACT_p", null); //$NON-NLS-1$
      if (tableSuivi_p.getIdtAct() != null)
      {
        callableStatement.setString("IDTACT_p", tableSuivi_p.getIdtAct()); //$NON-NLS-1$
      }

      callableStatement.setTimestamp("DATCREACT_p", null); //$NON-NLS-1$
      if (tableSuivi_p.getDatCreact() != null)
      {
        callableStatement.setTimestamp("DATCREACT_p", Timestamp.valueOf(tableSuivi_p.getDatCreact())); //$NON-NLS-1$
      }

      callableStatement.setString("IDTITF_p", null); //$NON-NLS-1$
      if (tableSuivi_p.getIdtItf() != null)
      {
        callableStatement.setString("IDTITF_p", tableSuivi_p.getIdtItf()); //$NON-NLS-1$
      }

      callableStatement.setObject("NBRPFI_p", null); //$NON-NLS-1$
      if (tableSuivi_p.getNbrPfi() != null)
      {
        callableStatement.setInt("NBRPFI_p", tableSuivi_p.getNbrPfi()); //$NON-NLS-1$
      }

      callableStatement.setObject("NBRPFIPRO_p", null); //$NON-NLS-1$
      if (tableSuivi_p.getNbrPfiPro() != null)
      {
        callableStatement.setInt("NBRPFIPRO_p", tableSuivi_p.getNbrPfiPro()); //$NON-NLS-1$
      }

      callableStatement.setTimestamp("DATDEBTRT_p", null); //$NON-NLS-1$
      if (tableSuivi_p.getDatDebTrt() != null)
      {
        callableStatement.setTimestamp("DATDEBTRT_p", Timestamp.valueOf(tableSuivi_p.getDatDebTrt())); //$NON-NLS-1$
      }

      callableStatement.setString("ETARCP_p", null); //$NON-NLS-1$
      if (tableSuivi_p.getEtaRcp() != null)
      {
        callableStatement.setString("ETARCP_p", tableSuivi_p.getEtaRcp()); //$NON-NLS-1$
      }

      callableStatement.setString("LIBRCP_p", null); //$NON-NLS-1$
      if (tableSuivi_p.getLibRcp() != null)
      {
        callableStatement.setString("LIBRCP_p", tableSuivi_p.getLibRcp()); //$NON-NLS-1$
      }

      callableStatement.setTimestamp("DATFINTRT_p", null); //$NON-NLS-1$
      if (tableSuivi_p.getDatFinTrt() != null)
      {
        callableStatement.setTimestamp("DATFINTRT_p", Timestamp.valueOf(tableSuivi_p.getDatFinTrt())); //$NON-NLS-1$
      }

      callableStatement.setString("ETAPRO_p", null); //$NON-NLS-1$
      if (tableSuivi_p.getEtapro() != null)
      {
        callableStatement.setString("ETAPRO_p", tableSuivi_p.getEtapro()); //$NON-NLS-1$
      }

      callableStatement.setString("LIBPRO_p", null); //$NON-NLS-1$
      if (tableSuivi_p.getLibPro() != null)
      {
        callableStatement.setString("LIBPRO_p", tableSuivi_p.getLibPro()); //$NON-NLS-1$
      }

      callableStatement.setString("ETANTF_p", null); //$NON-NLS-1$
      if (tableSuivi_p.getEtaNtf() != null)
      {
        callableStatement.setString("ETANTF_p", tableSuivi_p.getEtaNtf()); //$NON-NLS-1$
      }

      callableStatement.setString("LIBNTF_p", null); //$NON-NLS-1$
      if (tableSuivi_p.getLibNtf() != null)
      {
        callableStatement.setString("LIBNTF_p", tableSuivi_p.getLibNtf()); //$NON-NLS-1$
      }

      callableStatement.setString("TYPNTF_p", null); //$NON-NLS-1$
      if (tableSuivi_p.getTypNtf() != null)
      {
        callableStatement.setString("TYPNTF_p", tableSuivi_p.getTypNtf()); //$NON-NLS-1$
      }

      callableStatement.setTimestamp("DATNTF_p", null); //$NON-NLS-1$
      if (tableSuivi_p.getDatNtf() != null)
      {
        callableStatement.setTimestamp("DATNTF_p", Timestamp.valueOf(tableSuivi_p.getDatNtf())); //$NON-NLS-1$
      }

      callableStatement.registerOutParameter("NrRows", OracleTypes.NUMBER); //$NON-NLS-1$
      callableStatement.registerOutParameter("Retour_Resultat", OracleTypes.NVARCHAR); //$NON-NLS-1$
      callableStatement.registerOutParameter("Retour_Categorie", OracleTypes.NVARCHAR); //$NON-NLS-1$
      callableStatement.registerOutParameter("Retour_Diagnostic", OracleTypes.NVARCHAR); //$NON-NLS-1$
      callableStatement.registerOutParameter("Retour_Libelle", OracleTypes.NVARCHAR); //$NON-NLS-1$

      callableStatement.execute();

      int nrRows = callableStatement.getInt("NrRows"); //$NON-NLS-1$
      Retour retour = getRetour(callableStatement);

      if (1 != nrRows)
      {
        if (0 == nrRows)
        {
          retour = RetourFactory.createKO(IMegConsts.CAT3, ENTREE_INEXISTANTE, Messages.getString(Messages.ERREUR_OAM_DEMANDE_A_METTRE_A_JOUR_INEXISTANTE));
        }
        else if (nrRows > 1)
        {
          retour = RetourFactory.createKO(IMegConsts.CAT3, DEMANDE_NON_UNIQUE, MessageFormat.format(Messages.getString(Messages.ERREUR_OAM_BASE_OAM_INCOHERENTE), nrRows, tableSuivi_p.getIdtDde()));
        }
      }

      return new ConnectorResponse<>(nrRows, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, "timeout:" + _readTimeoutSec); //$NON-NLS-1$

      // when insert takes too long
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, ECHEC_INSERTION, MessageFormat.format(Messages.getString(Messages.ERREUR_OAM_TIMEOUT_SUR_NON_REPONSE), _readTimeoutSec));
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, "timeout:" + _readTimeoutSec); //$NON-NLS-1$

      //no sessions/connections available in the connection pool
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INDISPONIBILITE_SESSION, Messages.getString(Messages.ERREUR_OAM_AUCUNE_SESSION));
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, "timeout:" + _readTimeoutSec); //$NON-NLS-1$

      // when not able to connect
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, ECHEC_CONNEXION, MessageFormat.format(Messages.getString(Messages.ERREUR_OAM_TIMEOUT_CONNEXION), _connectTimeoutSec));
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, "timeout:" + _readTimeoutSec); //$NON-NLS-1$
    }
    finally
    {
      close(null, connection);
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<Nothing, Retour> mettreAJourMsgErreurDansRequest(Tracabilite tracabilite_p, String requestId_p, LocalDateTime outDateTime_p, String originator_p, String status_p, String customSim_p, String errorMsg_p)
  {
    final String methodName = "PG_SPIRIT.P_MAJ_REQUEST3"; //$NON-NLS-1$

    final String data = "REQUESTID:" + requestId_p + "OUTDATETIME:" + outDateTime_p + "ORIGINATOR:" + originator_p + "STATUS:" + status_p + "CUSTOMSIM:" + customSim_p + "ERROR_MSG:" + errorMsg_p; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$

    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall(String.format("{call %s(?,?,?,?,?,?,?,?,?,?) }", methodName))) //$NON-NLS-1$
    {
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("pi_REQUESTID", requestId_p); //$NON-NLS-1$
      cs.setTimestamp("pi_OUTDATETIME", Timestamp.valueOf(outDateTime_p)); //$NON-NLS-1$
      cs.setString("pi_ORIGINATOR", originator_p); //$NON-NLS-1$
      cs.setString("pi_STATUS", status_p); //$NON-NLS-1$
      cs.setString("pi_CUSTOMSIM", customSim_p); //$NON-NLS-1$
      cs.setString("pi_ERRORMSG", errorMsg_p); //$NON-NLS-1$

      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();

      Retour retour = getRetour(cs);
      SpiritLogEvent outputLog = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, methodName);

      outputLog.addField("Retour", retour, false); //$NON-NLS-1$
      RavelLogger.log(outputLog);
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, data);
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, ECHEC_INSERTION, MessageFormat.format(Messages.getString(Messages.ERREUR_OAM_TIMEOUT_SUR_NON_REPONSE), _readTimeoutSec));

      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, data);
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INDISPONIBILITE_SESSION, Messages.getString(Messages.ERREUR_OAM_AUCUNE_SESSION));

      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, data);
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, ECHEC_CONNEXION, MessageFormat.format(Messages.getString(Messages.ERREUR_OAM_TIMEOUT_CONNEXION), _connectTimeoutSec));

      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, data);
    }

    return null;
  }

  @Override
  public ConnectorResponse<Nothing, Retour> mettreAJourRequest(Tracabilite tracabilite_p, String requestId_p, LocalDateTime outDateTime_p, String originator_p, String status_p, String customSim_p)
  {
    final String methodName = "PG_SPIRIT.P_MAJ_REQUEST"; //$NON-NLS-1$

    final String data = "REQUESTID:" + requestId_p + "OUTDATETIME:" + outDateTime_p + "ORIGINATOR:" + originator_p + "STATUS:" + status_p + "CUSTOMSIM:" + customSim_p; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$

    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall(String.format("{call %s(?,?,?,?,?,?,?,?,?) }", methodName))) //$NON-NLS-1$
    {
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("pi_REQUESTID", requestId_p); //$NON-NLS-1$
      cs.setTimestamp("pi_OUTDATETIME", Timestamp.valueOf(outDateTime_p)); //$NON-NLS-1$
      cs.setString("pi_ORIGINATOR", originator_p); //$NON-NLS-1$
      cs.setString("pi_STATUS", status_p); //$NON-NLS-1$
      cs.setString("pi_CUSTOMSIM", customSim_p); //$NON-NLS-1$

      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();

      Retour retour = getRetour(cs);
      SpiritLogEvent outputLog = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, methodName);

      outputLog.addField("Retour", retour, false); //$NON-NLS-1$
      RavelLogger.log(outputLog);
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, data);
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, ECHEC_INSERTION, MessageFormat.format(Messages.getString(Messages.ERREUR_OAM_TIMEOUT_SUR_NON_REPONSE), _readTimeoutSec));

      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, data);
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INDISPONIBILITE_SESSION, Messages.getString(Messages.ERREUR_OAM_AUCUNE_SESSION));

      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, data);
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, ECHEC_CONNEXION, MessageFormat.format(Messages.getString(Messages.ERREUR_OAM_TIMEOUT_CONNEXION), _connectTimeoutSec));

      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, data);
    }

    return null;
  }

  @Override
  public ConnectorResponse<Nothing, Retour> mettreAJourRequest(Tracabilite tracabilite_p, String requestId_p, String originator_p, String status_p, LocalDateTime outDateTime_p, String verb_p)
  {
    final String methodName = "PG_SPIRIT.P_MAJ_REQUEST2"; //$NON-NLS-1$

    final String data = "REQUESTID:" + requestId_p + "OUTDATETIME:" + outDateTime_p + "ORIGINATOR:" + originator_p + "STATUS:" + status_p + "VERB:" + verb_p; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$

    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall(String.format("{call %s(?,?,?,?,?,?,?,?,?) }", methodName))) //$NON-NLS-1$
    {
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("pi_REQUESTID", requestId_p); //$NON-NLS-1$
      cs.setTimestamp("pi_OUTDATETIME", Timestamp.valueOf(outDateTime_p)); //$NON-NLS-1$
      cs.setString("pi_ORIGINATOR", originator_p); //$NON-NLS-1$
      cs.setString("pi_STATUS", status_p); //$NON-NLS-1$
      cs.setString("pi_VERB", verb_p); //$NON-NLS-1$

      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();

      Retour retour = getRetour(cs);
      SpiritLogEvent outputLog = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, methodName);

      outputLog.addField("Retour", retour, false); //$NON-NLS-1$
      RavelLogger.log(outputLog);
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, data);
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, ECHEC_INSERTION, MessageFormat.format(Messages.getString(Messages.ERREUR_OAM_TIMEOUT_SUR_NON_REPONSE), _readTimeoutSec));

      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, data);
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INDISPONIBILITE_SESSION, Messages.getString(Messages.ERREUR_OAM_AUCUNE_SESSION));

      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, data);
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, ECHEC_CONNEXION, MessageFormat.format(Messages.getString(Messages.ERREUR_OAM_TIMEOUT_CONNEXION), _connectTimeoutSec));

      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, data);
    }

    return null;
  }

  /**
   * Close the {@link ResultSet} then the {@link Connection}. Each <code>null</code> parameter is ignored. SQLExceptions
   * raised are ignored.
   *
   * @param resultSet_p
   *          The {@link ResultSet} to close. Can be <code>null</code>.
   * @param connection_p
   *          The {@link Connection} to close. Can be <code>null</code>.
   */
  protected void close(ResultSet resultSet_p, Connection connection_p)
  {
    if (resultSet_p != null)
    {
      try
      {
        resultSet_p.close();
      }
      catch (SQLException e)
      {
        //nothing to do
      }
    }

    if (connection_p != null)
    {
      try
      {
        connection_p.close();
      }
      catch (SQLException e)
      {
        //nothing to do
      }
    }
  }

  /**
   * Throws an {@link RavelException} for a technical problem.
   *
   * @param exc_p
   *          The {@link SQLException} raised
   * @param tracabilite_p
   *          tracabilite
   * @param spName_p
   *          The stored procedure name in which the fault was raised.
   * @param inputs_p
   *          A string representing input data of the stored procedure.
   * @return RavelException The technical exception.
   */
  private RavelException buildTechnicalException(SQLException exc_p, Tracabilite tracabilite_p, String spName_p, String inputs_p)
  {
    final String message = buildTechnicalMessage(exc_p, tracabilite_p, spName_p, inputs_p);

    return new RavelException(ExceptionType.PFS_EXCEPTION, ErrorCode.CNCTOR_00010, message, IOAMConnector.BEAN_ID, exc_p);
  }

  /**
   * Build a log entry for a technical problem.
   *
   * @param exc_p
   *          The {@link Exception} raised
   * @param tracabilite_p
   *          tracabilite
   * @param spName_p
   *          The stored procedure name in which the fault was raised.
   * @param inputs_p
   *          A string representing input data of the stored procedure.
   * @return RavelException The technical exception.
   */
  private String buildTechnicalMessage(SQLException exc_p, Tracabilite tracabilite_p, String spName_p, String inputs_p)
  {
    final String message = MessageFormat.format(Messages.getString(Messages.TECHNICAL_EXCEPTION), spName_p, exc_p.getErrorCode(), exc_p.getLocalizedMessage()) + ExceptionTools.getExceptionLineAndFile(exc_p); // add fileName and line number of the exception

    RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, inputs_p));
    RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, message));

    return message;
  }

  /**
   * Maps the results from the result set to a object {@link FollowUpTable}
   *
   * @param resultset_p
   *          the {@link ResultSet} to map
   * @return a list of FollowupTable
   * @throws SQLException
   *           thrown exception
   */
  private List<FollowUpTable> mapResultSetToFollowUpTable(final ResultSet resultset_p) throws SQLException
  {
    final List<FollowUpTable> liste = new ArrayList<>();
    if (nonNull(resultset_p))
    {
      while (resultset_p.next())
      {
        liste.add(new FollowUpTable() //
            .withIdtDde(resultset_p.getString(TableDeSDSFields.IDTDDE.name())) //
            .withNomSvc(resultset_p.getString(TableDeSDSFields.NOMSVC.name())) //
            .withIdtSysTec(resultset_p.getString(TableDeSDSFields.IDTSYSTEC.name())) //
            .withIdtParSic(resultset_p.getInt(TableDeSDSFields.IDTPARSIC.name())) //
            .withIdtAct(resultset_p.getString(TableDeSDSFields.IDTACT.name())) //
            .withDatCreact(Optional.ofNullable(resultset_p.getTimestamp(TableDeSDSFields.DATCREACT.name()))) //
            .withIdtItf(resultset_p.getString(TableDeSDSFields.IDTITF.name())) //
            .withNbrPfi(resultset_p.getInt(TableDeSDSFields.NBRPFI.name())) //
            .withNbrPfiPro(resultset_p.getInt(TableDeSDSFields.NBRPFIPRO.name())) //
            .withDatDebTrt(Optional.ofNullable(resultset_p.getTimestamp(TableDeSDSFields.DATDEBTRT.name()))) //
            .withEtaRcp(resultset_p.getString(TableDeSDSFields.ETARCP.name())) //
            .withLibRcp(resultset_p.getString(TableDeSDSFields.LIBRCP.name())) //
            .withDatFinTrt(Optional.ofNullable(resultset_p.getTimestamp(TableDeSDSFields.DATFINTRT.name()))) //
            .withEtapro(resultset_p.getString(TableDeSDSFields.ETAPRO.name())) //
            .withLibPro(resultset_p.getString(TableDeSDSFields.LIBPRO.name())) //
            .withEtaNtf(resultset_p.getString(TableDeSDSFields.ETANTF.name())) //
            .withLibNtf(resultset_p.getString(TableDeSDSFields.LIBNTF.name())) //
            .withTypNtf(resultset_p.getString(TableDeSDSFields.TYPNTF.name())) //
            .withDatNtf(Optional.ofNullable(resultset_p.getTimestamp(TableDeSDSFields.DATNTF.name()))));
      }
    }

    return liste;
  }
}
