/*******************************************************************************
* $Id: OamRequest.java 29154 2019-11-29 11:14:13Z jgregori $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.oam;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

/**
 * Object that contains information of a table line of the OAM_REQUEST table from database OAM. List of Service orders
 * (SO) treated by NPBT
 *
 * @author tvanlier
 * @version ($Revision: 29154 $ $Date: 2019-11-29 12:14:13 +0100 (ven. 29 nov. 2019) $)
 */
public class OamRequest
{

  /**
   * Table OAMrequest fields
   *
   * @author tvanlier
   *
   */
  private enum OAMRequestField
  {
    /**
    *
    */
    REQUEST_ID,

    /**
    *
    */
    ORDER_ID,

    /**
    *
    */
    IN_DATE_TIME,

    /**
    *
    */
    OUT_DATE_TIME,

    /**
    *
    */
    ORIGINATOR,

    /**
    *
    */
    SUBSCRIBER_ID,

    /**
    *
    */
    STATUS,

    /**
    *
    */
    RB_STATUS,

    /**
    *
    */
    PRIORITY,

    /**
    *
    */
    VERB,

    /**
    *
    */
    LAST_LOCATION,

    /**
    *
    */
    KPSA_NODE,

    /**
    *
    */
    BATCH_ID,

    /**
    *
    */
    CUSTOM_1,

    /**
    *
    */
    CUSTOM_2,

    /**
    *
    */
    CUSTOM_3,

    /**
    *
    */
    CUSTOM_4,

    /**
    *
    */
    CUSTOM_5,

    /**
    *
    */
    CUSTOM_6,

    /**
    *
    */
    CUSTOM_7,

    /**
    *
    */
    CUSTOM_8,

    /**
    *
    */
    CUSTOM_9,

    /**
    *
    */
    CUSTOM_10,

    /**
    *
    */
    CUSTOM_11,

    /**
    *
    */
    RESPONSE,

    /**
    *
    */
    ERROR_MSG,

    /**
    *
    */
    IMPACTED_NTWK_ELTS,

    /**
    *
    */
    APPLICANT_USER,

    /**
    *
    */
    APPLICANT_TRT
  }

  /**
   * Request ID (required)
   */
  private String _request_Id;
  /**
   * Service order ID in kpsa (required)
   */
  private String _order_Id;
  /**
   * starting date of SO (state 'NEW') (optional)
   */
  private Date _in_Time_Date;
  /**
   * ending date of SO (state 'OK') (optional)
   */
  private Date _out_Time_Date;
  /**
   * Origin of the SO (depending on the Client Adapter example : NOMAD1 or BSCS_FP) (optional)
   */
  private String _originator;
  /**
   * Client ID (Pfi that encode LM and IMSI). Not used for client's SO sequencing. (optional)
   */
  private String _suscriber_Id;
  /**
   * Request State (new/InQueue/Partial/Failed/OK) (optional)
   */
  private String _status;
  /**
   * Not used
   */
  private String _rb_Status;
  /**
   * SO Priority (-19 to 17, with 17 the most priority) (18&19 are priority non-sequences/clients flux ) (optional)
   */
  private Integer _priority;
  /**
   * Type of SO (optional)
   */
  private String _verb;
  /**
   *
   * Last location (Driver: start of request treatment, SOP:provisioning in progress, POP: provisioning ending,
   * Rejeu_Emission_LB: stuck at LB, Responder: response in progress, FinTraitement_OK: response done,
   * Queue_Equpt_Indispo: stuck at unavailable equipment, KOFUNC_A_TRAITER: waiting of trtKoFonc/ack LM, KOFuncQueue:
   * waiting trtKoFonc/purge, FinTraitement_KOFunc: end of KOFonc treatment)' (optional)
   */
  private String _last_Location;
  /**
   * ID of the node which worked on the SO (optional)
   */
  private String _kpsa_Node;
  /**
   * not used
   */
  private String _batch_ID;
  /**
   * IMSI (optional)
   */
  private String _custom_1;
  /**
   * MSISDN (optional)
   */
  private String _custom_2;
  /**
   * End of provisioning date (optional)
   */
  private Date _custom_3;
  /**
   * not available equipments list (optional)
   */
  private String _custom_4;
  /**
   * new IMSI in case of access point change (optional)
   */
  private String _custom_5;
  /**
   * new MSISDN in case of access point change (optional)
   */
  private String _custom_6;
  /**
   * Error type (Func:Fonctionnelle, Tech:Technique) (optional)
   */
  private String _custom_7;
  /**
   * ID of the service that called the provisioning need (empty if no service) (optional)
   */
  private String _custom_8;
  /**
   * Indicator of obsolescence of this provisioning need compared to previous need or sync. Empty if none. (optional)
   */
  private String _custom_9;
  /**
   * PFI XT Number (optional)
   */
  private String _custom_10;
  /**
   * New PFI XT number (in case or owner change) (optional)
   */
  private String _custom_11;
  /**
   * not used
   */
  private String _response;
  /**
   * Error message (failed,...) or "TRAITE_AVEC_SUCCES" (OK) (optional)
   */
  private String _error_Msg;
  /**
   * List of impacted platforms (optional)
   */
  private String _impacted_NTWK_ELTS;
  /**
   * Caller ID (optional)
   */
  private String _applicant_User;
  /**
   * Origin treatment of the caller (optional)
   */
  private String _applicant_Trt;

  /**
   * No Args Constructor
   */
  public OamRequest()
  {
    // No Args Cosntructor
  }

  /**
   * Constructor
   *
   * @param resultSet
   *          the ResultSet
   * @throws SQLException
   *           on error
   */
  public OamRequest(ResultSet resultSet) throws SQLException
  {
    _request_Id = resultSet.getString(OAMRequestField.REQUEST_ID.name());
    _order_Id = resultSet.getString(OAMRequestField.ORDER_ID.name());

    if (resultSet.getTimestamp(OAMRequestField.IN_DATE_TIME.name()) != null)
    {
      _in_Time_Date = new Date(resultSet.getTimestamp(OAMRequestField.IN_DATE_TIME.name()).getTime());
    }

    if (resultSet.getTimestamp(OAMRequestField.OUT_DATE_TIME.name()) != null)
    {
      _out_Time_Date = new Date(resultSet.getTimestamp(OAMRequestField.OUT_DATE_TIME.name()).getTime());
    }

    _originator = resultSet.getString(OAMRequestField.ORIGINATOR.name());
    _suscriber_Id = resultSet.getString(OAMRequestField.SUBSCRIBER_ID.name());
    _status = resultSet.getString(OAMRequestField.STATUS.name());
    _rb_Status = resultSet.getString(OAMRequestField.RB_STATUS.name());
    _priority = resultSet.getInt(OAMRequestField.PRIORITY.name());
    _verb = resultSet.getString(OAMRequestField.VERB.name());
    _last_Location = resultSet.getString(OAMRequestField.LAST_LOCATION.name());
    _kpsa_Node = resultSet.getString(OAMRequestField.KPSA_NODE.name());
    _batch_ID = resultSet.getString(OAMRequestField.BATCH_ID.name());
    _custom_1 = resultSet.getString(OAMRequestField.CUSTOM_1.name());
    _custom_2 = resultSet.getString(OAMRequestField.CUSTOM_2.name());

    if (resultSet.getTimestamp(OAMRequestField.CUSTOM_3.name()) != null)
    {
      _custom_3 = new Date(resultSet.getTimestamp(OAMRequestField.CUSTOM_3.name()).getTime());
    }

    _custom_4 = resultSet.getString(OAMRequestField.CUSTOM_4.name());
    _custom_5 = resultSet.getString(OAMRequestField.CUSTOM_5.name());
    _custom_6 = resultSet.getString(OAMRequestField.CUSTOM_6.name());
    _custom_7 = resultSet.getString(OAMRequestField.CUSTOM_7.name());
    _custom_8 = resultSet.getString(OAMRequestField.CUSTOM_8.name());
    _custom_9 = resultSet.getString(OAMRequestField.CUSTOM_9.name());
    _custom_10 = resultSet.getString(OAMRequestField.CUSTOM_10.name());
    _custom_11 = resultSet.getString(OAMRequestField.CUSTOM_11.name());
    _response = resultSet.getString(OAMRequestField.RESPONSE.name());
    _error_Msg = resultSet.getString(OAMRequestField.ERROR_MSG.name());
    _impacted_NTWK_ELTS = resultSet.getString(OAMRequestField.IMPACTED_NTWK_ELTS.name());
    _applicant_User = resultSet.getString(OAMRequestField.APPLICANT_USER.name());
    _applicant_Trt = resultSet.getString(OAMRequestField.APPLICANT_TRT.name());
  }

  /**
   * Gets Origin treatment of the caller
   *
   * @return Origin treatment of the caller
   */
  public String getApplicantTrt()
  {
    return _applicant_Trt;
  }

  /**
   * Gets Caller ID
   *
   * @return Caller ID
   */
  public String getApplicantUser()
  {
    return _applicant_User;
  }

  /**
   * Gets batch ID
   *
   * @return BatchID not used
   */
  public String getBatchID()
  {
    return _batch_ID;
  }

  /**
   * Gets IMS
   *
   * @return IMSI
   */
  public String getCustom1()
  {
    return _custom_1;
  }

  /**
   * Gets PFI XT Number
   *
   * @return PFI XT Number
   */
  public String getCustom10()
  {
    return _custom_10;
  }

  /**
   * Gets New PFI XT number (in case or owner change)
   *
   * @return New PFI XT number (in case or owner change)
   */
  public String getCustom11()
  {
    return _custom_11;
  }

  /**
   * Gets MSISDN
   *
   * @return MSISDN
   */
  public String getCustom2()
  {
    return _custom_2;
  }

  /**
   * Gets End of provisioning date
   *
   * @return End of provisioning date
   */
  public Date getCustom3()
  {
    if (_custom_3 != null)
    {
      return (Date) _custom_3.clone();
    }

    return null;
  }

  /**
   * Gets not available equipments list
   *
   * @return not available equipments list
   */
  public String getCustom4()
  {
    return _custom_4;
  }

  /**
   * Gets new IMSI in case of access point change
   *
   * @return new IMSI in case of access point change
   */
  public String getCustom5()
  {
    return _custom_5;
  }

  /**
   * Gets new MSISDN in case of access point change
   *
   * @return new MSISDN in case of access point change
   */
  public String getCustom6()
  {
    return _custom_6;
  }

  /**
   * Gets Error type (Func:Fonctionnelle, Tech:Technique)
   *
   * @return Error type (Func:Fonctionnelle, Tech:Technique)
   */
  public String getCustom7()
  {
    return _custom_7;
  }

  /**
   * Gets ID of the service that called the provisioning need (empty if no service)
   *
   * @return ID of the service that called the provisioning need (empty if no service)
   */
  public String getCustom8()
  {
    return _custom_8;
  }

  /**
   * Gets Indicator of obsolescence of this provisioning need compared to previous need or sync. Empty if none.
   *
   * @return Indicator of obsolescence of this provisioning need compared to previous need or sync. Empty if none.
   */
  public String getCustom9()
  {
    return _custom_9;
  }

  /**
   * Gets Error message (failed,...) or "TRAITE_AVEC_SUCCES" (OK)
   *
   * @return Error message (failed,...) or "TRAITE_AVEC_SUCCES" (OK)
   */
  public String getErrorMsg()
  {
    return _error_Msg;
  }

  /**
   * Gets List of impacted platforms
   *
   * @return List of impacted platforms
   */
  public String getImpactedNtwkElts()
  {
    return _impacted_NTWK_ELTS;
  }

  /**
   * Gets starting date of SO (state 'NEW')
   *
   * @return starting date of SO (state 'NEW')
   */
  public Date getInTimeDate()
  {
    if (_in_Time_Date != null)
    {
      return (Date) _in_Time_Date.clone();
    }

    return null;
  }

  /**
   * Gets ID of the node which worked on the SO
   *
   * @return ID of the node which worked on the SO
   */
  public String getkpsaNode()
  {
    return _kpsa_Node;
  }

  /**
   * Gets Last location
   *
   * @return Last location
   */
  public String getLastLocation()
  {
    return _last_Location;
  }

  /**
   * Gets Service order ID in kpsa
   *
   * @return Service order ID in kpsa
   */
  public String getOrderId()
  {
    return _order_Id;
  }

  /**
   * Gets Origin of the SO (depending on the Client Adapter example : NOMAD1 or BSCS_FP)
   *
   * @return Origin of the SO (depending on the Client Adapter example : NOMAD1 or BSCS_FP)
   */
  public String getOriginator()
  {
    return _originator;
  }

  /**
   * Gets ending date of SO (state 'OK')
   *
   * @return ending date of SO (state 'OK')
   */
  public Date getOutTimeDate()
  {
    if (_out_Time_Date != null)
    {
      return (Date) _out_Time_Date.clone();
    }

    return null;
  }

  /**
   * Gets SO Priority (-19 to 17, with 17 the most priority) (18&19 are priority non-sequences/clients flux )
   *
   * @return SO Priority (-19 to 17, with 17 the most priority) (18&19 are priority non-sequences/clients flux )
   */
  public Integer getPriority()
  {
    return _priority;
  }

  /**
   * Gets RB State
   *
   * @return RB State Not used
   */
  public String getRbStatus()
  {
    return _rb_Status;
  }

  //getters
  /**
   * Gets Request ID
   *
   * @return Request ID
   */
  public String getRequestId()
  {
    return _request_Id;
  }

  /**
   * Gets Response
   *
   * @return Response not used
   */
  public String getResponse()
  {
    return _response;
  }

  /**
   * Gets Request State (new/InQueue/Partial/Failed/OK)
   *
   * @return Request State (new/InQueue/Partial/Failed/OK)
   */
  public String getStatus()
  {
    return _status;
  }

  /**
   * Gets Client ID (Pfi that encode LM and IMSI). Not used for client's SO sequencing.
   *
   * @return Client ID (Pfi that encode LM and IMSI). Not used for client's SO sequencing.
   */
  public String getSuscriberId()
  {
    return _suscriber_Id;
  }

  /**
   * Gets Type of SO
   *
   * @return Type of SO
   */
  public String getVerb()
  {
    return _verb;
  }

  /**
   * Sets Origin treatment of the caller
   *
   * @param applicant_Trt_p
   *          Origin treatment of the caller
   */
  public void setApplicantTrt(String applicant_Trt_p)
  {
    _applicant_Trt = applicant_Trt_p;
  }

  /**
   * Sets Caller ID
   *
   * @param applicant_User_p
   *          Caller ID
   */
  public void setApplicantUser(String applicant_User_p)
  {
    _applicant_User = applicant_User_p;
  }

  /**
   * Sets batch ID
   *
   * @param batch_ID_p
   *          BatchID not used
   */
  public void setBatchID(String batch_ID_p)
  {
    _batch_ID = batch_ID_p;
  }

  /**
   * Sets IMS
   *
   * @param custom_1_p
   *          IMSI
   */
  public void setCustom1(String custom_1_p)
  {
    _custom_1 = custom_1_p;
  }

  /**
   * Sets PFI XT Number
   *
   * @param custom_10_p
   *          PFI XT Number
   */
  public void setCustom10(String custom_10_p)
  {
    _custom_10 = custom_10_p;
  }

  /**
   * Sets New PFI XT number (in case or owner change)
   *
   * @param custom_11_p
   *          New PFI XT number (in case or owner change)
   */
  public void setCustom11(String custom_11_p)
  {
    _custom_11 = custom_11_p;
  }

  /**
   * Sets MSISDN
   *
   * @param custom_2_p
   *          MSISDN
   */
  public void setCustom2(String custom_2_p)
  {
    _custom_2 = custom_2_p;
  }

  /**
   * Sets End of provisioning date
   *
   * @param custom_3_p
   *          End of provisioning date
   */
  public void setCustom3(Date custom_3_p)
  {
    if (custom_3_p != null)
    {
      _custom_3 = (Date) custom_3_p.clone();
    }
  }

  /**
   * Sets not available equipments list
   *
   * @param custom_4_p
   *          not available equipments list
   */
  public void setCustom4(String custom_4_p)
  {
    _custom_4 = custom_4_p;
  }

  /**
   * Sets new IMSI in case of access point change
   *
   * @param custom_5_p
   *          new IMSI in case of access point change
   */
  public void setCustom5(String custom_5_p)
  {
    _custom_5 = custom_5_p;
  }

  /**
   * Sets new MSISDN in case of access point change
   *
   * @param custom_6_p
   *          new MSISDN in case of access point change
   */
  public void setCustom6(String custom_6_p)
  {
    _custom_6 = custom_6_p;
  }

  /**
   * Sets Error type (Func:Fonctionnelle, Tech:Technique)
   *
   * @param custom_7_p
   *          Error type (Func:Fonctionnelle, Tech:Technique)
   */
  public void setCustom7(String custom_7_p)
  {
    _custom_7 = custom_7_p;
  }

  /**
   * Sets ID of the service that called the provisioning need (empty if no service)
   *
   * @param custom_8_p
   *          ID of the service that called the provisioning need (empty if no service)
   */
  public void setCustom8(String custom_8_p)
  {
    _custom_8 = custom_8_p;
  }

  /**
   * Sets Indicator of obsolescence of this provisioning need compared to previous need or sync. Empty if none.
   *
   * @param custom_9_p
   *          Indicator of obsolescence of this provisioning need compared to previous need or sync. Empty if none.
   */
  public void setCustom9(String custom_9_p)
  {
    _custom_9 = custom_9_p;
  }

  /**
   * Sets Error message (failed,...) or "TRAITE_AVEC_SUCCES" (OK)
   *
   * @param error_Msg_p
   *          Error message (failed,...) or "TRAITE_AVEC_SUCCES" (OK)
   */
  public void setErrorMsg(String error_Msg_p)
  {
    _error_Msg = error_Msg_p;
  }

  /**
   * Sets List of impacted platforms
   *
   * @param impacted_NTWK_ELTS_p
   *          List of impacted platforms
   */
  public void setImpactedNtwkElts(String impacted_NTWK_ELTS_p)
  {
    _impacted_NTWK_ELTS = impacted_NTWK_ELTS_p;
  }

  /**
   * Sets starting date of SO (state 'NEW')
   *
   * @param in_Time_Date_p
   *          starting date of SO (state 'NEW')
   */
  public void setInTimeDate(Date in_Time_Date_p)
  {
    if (in_Time_Date_p != null)
    {
      _in_Time_Date = (Date) in_Time_Date_p.clone();
    }
  }

  /**
   * Sets ID of the node which worked on the SO
   *
   * @param kpsa_Node_p
   *          ID of the node which worked on the SO
   */
  public void setkpsaNode(String kpsa_Node_p)
  {
    _kpsa_Node = kpsa_Node_p;
  }

  /**
   * Sets Last location
   *
   * @param last_Location_p
   *          Last location
   */
  public void setLastLocation(String last_Location_p)
  {
    _last_Location = last_Location_p;
  }

  /**
   * Sets Service order ID in kpsa
   *
   * @param order_Id_p
   *          Service order ID in kpsa
   */
  public void setOrderId(String order_Id_p)
  {
    _order_Id = order_Id_p;
  }

  /**
   * Sets Origin of the SO (depending on the Client Adapter example : NOMAD1 or BSCS_FP)
   *
   * @param originator_p
   *          Origin of the SO (depending on the Client Adapter example : NOMAD1 or BSCS_FP)
   */
  public void setOriginator(String originator_p)
  {
    _originator = originator_p;
  }

  /**
   * Sets ending date of SO (state 'OK')
   *
   * @param out_Time_Date_p
   *          ending date of SO (state 'OK')
   */
  public void setOutTimeDate(Date out_Time_Date_p)
  {
    if (out_Time_Date_p != null)
    {
      _out_Time_Date = (Date) out_Time_Date_p.clone();
    }
  }

  /**
   * Sets SO Priority (-19 to 17, with 17 the most priority) (18&19 are priority non-sequences/clients flux_p )
   *
   * @param priority_p
   *          SO Priority (-19 to 17, with 17 the most priority) (18&19 are priority non-sequences/clients flux_p )
   */
  public void setPriority(Integer priority_p)
  {
    _priority = priority_p;
  }

  /**
   * Sets RB State
   *
   * @param rb_Status_p
   *          RB State Not used
   */
  public void setRbStatus(String rb_Status_p)
  {
    _rb_Status = rb_Status_p;
  }

  //setters
  /**
   * Sets Request ID
   *
   * @param request_Id_p
   *          Request ID
   */
  public void setRequestId(String request_Id_p)
  {
    _request_Id = request_Id_p;
  }

  /**
   * Sets Response
   *
   * @param response_p
   *          Response not used
   */
  public void setResponse(String response_p)
  {
    _response = response_p;
  }

  /**
   * Sets Request State (new/InQueue/Partial/Failed/OK)
   *
   * @param status_p
   *          Request State (new/InQueue/Partial/Failed/OK)
   */
  public void setStatus(String status_p)
  {
    _status = status_p;
  }

  /**
   * Sets Client ID (Pfi that encode LM and IMSI). Not used for client's SO sequencing.
   *
   * @param suscriber_Id_p
   *          Client ID (Pfi that encode LM and IMSI). Not used for client's SO sequencing.
   */
  public void setSuscriberId(String suscriber_Id_p)
  {
    _suscriber_Id = suscriber_Id_p;
  }

  /**
   * Sets Type of SO
   *
   * @param verb_p
   *          Type of SO
   */
  public void setVerb(String verb_p)
  {
    _verb = verb_p;
  }

}