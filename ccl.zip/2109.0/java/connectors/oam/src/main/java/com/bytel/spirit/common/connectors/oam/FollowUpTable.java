/*******************************************************************************
 * $Id: FollowUpTable.java 43398 2020-11-06 13:08:33Z jjoly $
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.oam;

import static java.util.Objects.hash;
import static java.util.Objects.isNull;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Objects;
import java.util.Optional;

import javax.validation.constraints.NotNull;

/**
 * Stores information about table DE_SDS (table to follow services requests) from database OAM.
 *
 * @author $Author$
 * @version ($Revision: 43398 $ $Date: 2020-11-06 14:08:33 +0100 (ven. 06 nov. 2020) $)
 */
public final class FollowUpTable
{
  /**
   * Creation date for the act (required)
   */
  private LocalDateTime _datCreact;

  /**
   * Treatment start date (required)
   */
  private LocalDateTime _datDebTrt;

  /**
   * Treatment end date (optional)
   */
  private LocalDateTime _datFinTrt;

  /**
   * Last notification date (optional)
   */
  private LocalDateTime _datNtf;

  /**
   * Last notification state for end of treatment (optional)
   */
  private String _etaNtf;

  /**
   * Provisioning state (optional)
   */
  private String _etapro;

  /**
   * Reception state (required)
   */
  private String _etaRcp;

  /**
   * Act identifier for the request (required)
   */
  private String _idtAct;

  /**
   * Service request identifier (INFRA identifier) (required)
   */
  private String _idtDde;

  /**
   * Treatment instance identifier for the request (required)
   */
  private String _idtItf;

  /**
   * SIC partition identifier (required)
   */
  private Integer _idtParSic;

  /**
   * Technical system identifier that created the request (required)
   */
  private String _idtSysTec;

  /**
   * Message associated with the last changed notification state (optional)
   */
  private String _libNtf;

  /**
   * Message associated with the last changed provisioning state (optional)
   */
  private String _libPro;

  /**
   * Message associated with the last changed reception state (required)
   */
  private String _libRcp;

  /**
   * Request PFI number (required)
   */
  private Integer _nbrPfi;

  /**
   * PFI number to provision in the request (required)
   */
  private Integer _nbrPfiPro;

  /**
   * Called service name by NPBT (required)
   */
  private String _nomSvc;

  /**
   * Notification type (optional)
   */
  private String _typNtf;

  /**
   * Default constructor
   */
  public FollowUpTable()
  {
    super();
  }

  /**
   * Recopy constructor
   *
   * @param object_p
   *          The object {@link FollowUpTable} to recopy
   */
  public FollowUpTable(final FollowUpTable object_p)
  {
    super();

    _datCreact = object_p.getDatCreact();
    _datDebTrt = object_p.getDatDebTrt();
    _datFinTrt = object_p.getDatFinTrt();
    _datNtf = object_p.getDatNtf();
    _etaNtf = object_p.getEtaNtf();
    _etapro = object_p.getEtapro();
    _etaRcp = object_p.getEtaRcp();
    _idtAct = object_p.getIdtAct();
    _idtDde = object_p.getIdtDde();
    _idtItf = object_p.getIdtItf();
    _idtParSic = object_p.getIdtParSic();
    _idtSysTec = object_p.getIdtSysTec();
    _libNtf = object_p.getLibNtf();
    _libPro = object_p.getLibPro();
    _libRcp = object_p.getLibRcp();
    _nbrPfi = object_p.getNbrPfi();
    _nbrPfiPro = object_p.getNbrPfiPro();
    _nomSvc = object_p.getNomSvc();
    _typNtf = object_p.getTypNtf();
  }

  @Override
  public final boolean equals(final Object object_p)
  {
    if (this == object_p)
    {
      return true;
    }

    if (isNull(object_p) || //
        (!getClass().equals(object_p.getClass())))
    {
      return false;
    }

    final FollowUpTable other = FollowUpTable.class.cast(object_p);
    return Objects.equals(_datCreact, other.getDatCreact()) //
        && Objects.equals(_datDebTrt, other.getDatDebTrt()) //
        && Objects.equals(_datFinTrt, other.getDatFinTrt()) //
        && Objects.equals(_datNtf, other.getDatNtf()) //
        && Objects.equals(_etaNtf, other.getEtaNtf()) //
        && Objects.equals(_etapro, other.getEtapro()) //
        && Objects.equals(_etaRcp, other.getEtaRcp()) //
        && Objects.equals(_idtAct, other.getIdtAct()) //
        && Objects.equals(_idtDde, other.getIdtDde()) //
        && Objects.equals(_idtItf, other.getIdtItf()) //
        && Objects.equals(_idtParSic, other.getIdtParSic()) //
        && Objects.equals(_idtSysTec, other.getIdtSysTec()) //
        && Objects.equals(_libNtf, other.getLibNtf()) //
        && Objects.equals(_libPro, other.getLibPro()) //
        && Objects.equals(_libRcp, other.getLibRcp()) //
        && Objects.equals(_nbrPfi, other.getNbrPfi()) //
        && Objects.equals(_nbrPfiPro, other.getNbrPfiPro()) //
        && Objects.equals(_nomSvc, other.getNomSvc()) //
        && Objects.equals(_typNtf, other.getTypNtf());
  }

  /**
   * Gets creation date for the act
   *
   * @return the creation date for the act
   */
  public final LocalDateTime getDatCreact()
  {
    return _datCreact;
  }

  /**
   * Gets treatment start date
   *
   * @return the treatment start date
   */
  public final LocalDateTime getDatDebTrt()
  {
    return _datDebTrt;
  }

  /**
   * Gets treatment end date
   *
   * @return the treatment end date
   */
  public final LocalDateTime getDatFinTrt()
  {
    return _datFinTrt;
  }

  /**
   * Gets last notification date
   *
   * @return the last notification date
   */
  public final LocalDateTime getDatNtf()
  {
    return _datNtf;
  }

  /**
   * Gets last notification state for end of treatment
   *
   * @return the last notification state for end of treatment
   */
  public final String getEtaNtf()
  {
    return _etaNtf;
  }

  /**
   * Gets provisioning state
   *
   * @return the provisioning state
   */
  public final String getEtapro()
  {
    return _etapro;
  }

  /**
   * Gets reception state
   *
   * @return the reception state
   */
  public final String getEtaRcp()
  {
    return _etaRcp;
  }

  /**
   * Gets act identifier for the request
   *
   *
   * @return the act identifier for the request
   */
  public final String getIdtAct()
  {
    return _idtAct;
  }

  /**
   * Gets service request identifier (INFRA identifier)
   *
   * @return the service request identifier (INFRA identifier)
   */
  public final String getIdtDde()
  {
    return _idtDde;
  }

  /**
   * Gets treatment instance identifier for the request
   *
   * @return the treatment instance identifier for the request
   */
  public final String getIdtItf()
  {
    return _idtItf;
  }

  /**
   * Gets SIC partition identifier
   *
   * @return the SIC partition identifier
   */
  public final Integer getIdtParSic()
  {
    return _idtParSic;
  }

  /**
   * Gets technical system identifier that created the request
   *
   * @return the technical system identifier that created the request
   */
  public final String getIdtSysTec()
  {
    return _idtSysTec;
  }

  /**
   * Gets message associated with the last changed notification state
   *
   * @return the message associated with the last changed notification state
   */
  public final String getLibNtf()
  {
    return _libNtf;
  }

  /**
   * Gets message associated with the last changed provisioning state
   *
   * @return the message associated with the last changed provisioning state
   */
  public final String getLibPro()
  {
    return _libPro;
  }

  /**
   * Gets message associated with the last changed reception state
   *
   * @return the message associated with the last changed reception state
   */
  public final String getLibRcp()
  {
    return _libRcp;
  }

  /**
   * Gets request PFI number
   *
   * @return the request PFI number
   */
  public final Integer getNbrPfi()
  {
    return _nbrPfi;
  }

  /**
   * Gets PFI number to provision in the request
   *
   *
   * @return the PFI number to provision in the request
   */
  public final Integer getNbrPfiPro()
  {
    return _nbrPfiPro;
  }

  /**
   * Gets called service name by NPBT
   *
   * @return the called service name by NPBT
   */
  public final String getNomSvc()
  {
    return _nomSvc;
  }

  /**
   * Gets the Notification type
   *
   * @return the Notification type
   */
  public final String getTypNtf()
  {
    return _typNtf;
  }

  @Override
  public final int hashCode()
  {
    return hash(_datCreact, _datDebTrt, _datFinTrt, _datNtf, _etaNtf, _etapro, _etaRcp, _idtAct, _idtDde, _idtItf, _idtParSic, _idtSysTec, _libNtf, _libPro, _libRcp, _nbrPfi, _nbrPfiPro, _nomSvc, _typNtf);
  }

  /**
   * Sets creation date for the act
   *
   * @param datCreact_p
   *          the creation date for the act to set
   */
  public void setDatCreact(@NotNull final LocalDateTime datCreact_p)
  {
    _datCreact = datCreact_p;
  }

  /**
   * Sets treatment start date
   *
   * @param datDebTrt_p
   *          the treatment start date to set
   */
  public void setDatDebTrt(@NotNull final LocalDateTime datDebTrt_p)
  {
    _datDebTrt = datDebTrt_p;
  }

  /**
   * Sets treatment end date
   *
   * @param datFinTrt_p
   *          the treatment end date to set
   */
  public void setDatFinTrt(final LocalDateTime datFinTrt_p)
  {
    _datFinTrt = datFinTrt_p;
  }

  /**
   * Sets last notification state for end of treatment
   *
   * @param datNtf_p
   *          the last notification state for end of treatment to set
   */
  public void setDatNtf(final LocalDateTime datNtf_p)
  {
    _datNtf = datNtf_p;
  }

  /**
   * Sets last notification state for end of treatment
   *
   * @param etaNtf_p
   *          the last notification state for end of treatment to set
   */
  public void setEtaNtf(@NotNull final String etaNtf_p)
  {
    _etaNtf = etaNtf_p;
  }

  /**
   * Sets provisioning state
   *
   * @param etapro_p
   *          the provisioning state to set
   */
  public void setEtapro(@NotNull final String etapro_p)
  {
    _etapro = etapro_p;
  }

  /**
   * Sets reception state
   *
   * @param etaRcp_p
   *          the reception state to set
   */
  public void setEtaRcp(@NotNull final String etaRcp_p)
  {
    _etaRcp = etaRcp_p;
  }

  /**
   * Sets act identifier for the request
   *
   * @param idtAct_p
   *          the act identifier for the request to set
   */
  public void setIdtAct(@NotNull final String idtAct_p)
  {
    _idtAct = idtAct_p;
  }

  /**
   * Sets Service request identifier (INFRA identifier)
   *
   * @param idtDde_p
   *          the service request identifier to set
   */
  public void setIdtDde(@NotNull final String idtDde_p)
  {
    _idtDde = idtDde_p;
  }

  /**
   * Sets treatment instance identifier for the request
   *
   * @param idtItf_p
   *          the treatment instance identifier for the request to set
   */
  public void setIdtItf(@NotNull final String idtItf_p)
  {
    _idtItf = idtItf_p;
  }

  /**
   * Sets SIC partition identifier
   *
   * @param idtParSic_p
   *          the SIC partition identifier to set
   */
  public void setIdtParSic(@NotNull final Integer idtParSic_p)
  {
    _idtParSic = idtParSic_p;
  }

  /**
   * Sets technical system identifier that created the request
   *
   * @param idtSysTec_p
   *          the technical system identifier that created the request to set
   */
  public void setIdtSysTec(@NotNull final String idtSysTec_p)
  {
    _idtSysTec = idtSysTec_p;
  }

  /**
   * Sets message associated with the last changed notification state
   *
   * @param libNtf_p
   *          the message associated with the last changed notification state to set
   */
  public void setLibNtf(@NotNull final String libNtf_p)
  {
    _libNtf = libNtf_p;
  }

  /**
   * Sets message associated with the last changed provisioning state
   *
   * @param libPro_p
   *          the message associated with the last changed provisioning state to set
   */
  public void setLibPro(@NotNull final String libPro_p)
  {
    _libPro = libPro_p;
  }

  /**
   * Sets message associated with the last changed reception state
   *
   * @param libRcp_p
   *          the message associated with the last changed reception state to set
   */
  public void setLibRcp(@NotNull final String libRcp_p)
  {
    _libRcp = libRcp_p;
  }

  /**
   * Sets request PFI number
   *
   * @param nbrPfi_p
   *          the request PFI number to set
   */
  public void setNbrPfi(@NotNull final Integer nbrPfi_p)
  {
    _nbrPfi = nbrPfi_p;
  }

  /**
   * Sets PFI number to provision in the request
   *
   * @param nbrPfiPro_p
   *          the PFI number to provision in the request to set
   */
  public void setNbrPfiPro(@NotNull final Integer nbrPfiPro_p)
  {
    _nbrPfiPro = nbrPfiPro_p;
  }

  /**
   * Sets called service name by NPBT
   *
   * @param nomSvc_p
   *          the called service name by NPBT to set
   */
  public void setNomSvc(@NotNull final String nomSvc_p)
  {
    _nomSvc = nomSvc_p;
  }

  /**
   * Sets the notification type
   *
   * @param typNtf_p
   *          the Notification type to set
   */
  public void setTypNtf(@NotNull final String typNtf_p)
  {
    _typNtf = typNtf_p;
  }

  @Override
  public final String toString()
  {
    return new StringBuilder() //
        .append("FollowUpTable [_datCreact=") //$NON-NLS-1$
        .append(_datCreact) //
        .append(", _datDebTrt=") //$NON-NLS-1$
        .append(_datDebTrt) //
        .append(", _datFinTrt=") //$NON-NLS-1$
        .append(_datFinTrt) //
        .append(", _datNtf=") //$NON-NLS-1$
        .append(_datNtf) //
        .append(", _etaNtf=") //$NON-NLS-1$
        .append(_etaNtf) //
        .append(", _etapro=") //$NON-NLS-1$
        .append(_etapro) //
        .append(", _etaRcp=") //$NON-NLS-1$
        .append(_etaRcp) //
        .append(", _idtAct=") //$NON-NLS-1$
        .append(_idtAct) //
        .append(", _idtDde=") //$NON-NLS-1$
        .append(_idtDde) //
        .append(", _idtItf=") //$NON-NLS-1$
        .append(_idtItf) //
        .append(", _idtParSic=") //$NON-NLS-1$
        .append(_idtParSic) //
        .append(", _idtSysTec=") //$NON-NLS-1$
        .append(_idtSysTec) //
        .append(", _libNtf=") //$NON-NLS-1$
        .append(_libNtf) //
        .append(", _libPro=") //$NON-NLS-1$
        .append(_libPro) //
        .append(", _libRcp=") //$NON-NLS-1$
        .append(_libRcp) //
        .append(", _nbrPfi=") //$NON-NLS-1$
        .append(_nbrPfi) //
        .append(", _nbrPfiPro=") //$NON-NLS-1$
        .append(_nbrPfiPro) //
        .append(", _nomSvc=") //$NON-NLS-1$
        .append(_nomSvc) //
        .append(", _typNtf=") //$NON-NLS-1$
        .append(_typNtf) //
        .append("]") //$NON-NLS-1$
        .toString();
  }

  /**
   * Sets creation date for the act
   *
   * @param datCreact_p
   *          the creation date for the act to set
   * @return The current handler
   * @note Support of fluentAPI
   */
  public final FollowUpTable withDatCreact(@NotNull final LocalDateTime datCreact_p)
  {
    _datCreact = datCreact_p;
    return this;
  }

  /**
   * Sets creation date for the act
   *
   * @param datCreact_p
   *          the creation date for the act to set
   * @return The current handler
   * @note Support of fluentAPI
   */
  public final FollowUpTable withDatCreact(@NotNull final Optional<Timestamp> datCreact_p)
  {
    _datCreact = datCreact_p.map(Timestamp::toLocalDateTime).orElse(null);
    return this;
  }

  /**
   * Sets treatment start date
   *
   * @param datDebTrt_p
   *          the treatment start date to set
   * @return The current handler
   * @note Support of fluentAPI
   */
  public final FollowUpTable withDatDebTrt(@NotNull final LocalDateTime datDebTrt_p)
  {
    _datDebTrt = datDebTrt_p;
    return this;
  }

  /**
   * Sets treatment start date
   *
   * @param datDebTrt_p
   *          the treatment start date to set
   * @return The current handler
   * @note Support of fluentAPI
   */
  public final FollowUpTable withDatDebTrt(@NotNull final Optional<Timestamp> datDebTrt_p)
  {
    _datDebTrt = datDebTrt_p.map(Timestamp::toLocalDateTime).orElse(null);
    return this;
  }

  /**
   * Sets treatment end date
   *
   * @param datFinTrt_p
   *          the treatment end date to set
   * @return The current handler
   * @note Support of fluentAPI
   */
  public final FollowUpTable withDatFinTrt(@NotNull final LocalDateTime datFinTrt_p)
  {
    _datFinTrt = datFinTrt_p;
    return this;
  }

  /**
   * Sets treatment end date
   *
   * @param datFinTrt_p
   *          the treatment end date to set
   * @return The current handler
   * @note Support of fluentAPI
   */
  public final FollowUpTable withDatFinTrt(@NotNull final Optional<Timestamp> datFinTrt_p)
  {
    _datFinTrt = datFinTrt_p.map(Timestamp::toLocalDateTime).orElse(null);
    return this;
  }

  /**
   * Sets last notification state for end of treatment
   *
   * @param datNtf_p
   *          the last notification state for end of treatment to set
   * @return The current handler
   * @note Support of fluentAPI
   */
  public final FollowUpTable withDatNtf(@NotNull final LocalDateTime datNtf_p)
  {
    _datNtf = datNtf_p;
    return this;
  }

  /**
   * Sets last notification state for end of treatment
   *
   * @param datNtf_p
   *          the last notification state for end of treatment to set
   * @return The current handler
   * @note Support of fluentAPI
   */
  public final FollowUpTable withDatNtf(@NotNull final Optional<Timestamp> datNtf_p)
  {
    _datNtf = datNtf_p.map(Timestamp::toLocalDateTime).orElse(null);
    return this;
  }

  /**
   * Sets last notification state for end of treatment
   *
   * @param etaNtf_p
   *          the last notification state for end of treatment to set
   * @return The current handler
   * @note Support of fluentAPI
   */
  public final FollowUpTable withEtaNtf(@NotNull final String etaNtf_p)
  {
    _etaNtf = etaNtf_p;
    return this;
  }

  /**
   * Sets provisioning state
   *
   * @param etapro_p
   *          the provisioning state to set
   * @return The current handler
   * @note Support of fluentAPI
   */
  public final FollowUpTable withEtapro(@NotNull final String etapro_p)
  {
    _etapro = etapro_p;
    return this;
  }

  /**
   * Sets reception state
   *
   * @param etaRcp_p
   *          the reception state to set
   * @return The current handler
   * @note Support of fluentAPI
   */
  public final FollowUpTable withEtaRcp(@NotNull final String etaRcp_p)
  {
    _etaRcp = etaRcp_p;
    return this;
  }

  /**
   * Sets act identifier for the request
   *
   * @param idtAct_p
   *          the act identifier for the request to set
   * @return The current handler
   * @note Support of fluentAPI
   */
  public final FollowUpTable withIdtAct(@NotNull final String idtAct_p)
  {
    _idtAct = idtAct_p;
    return this;
  }

  /**
   * Sets Service request identifier (INFRA identifier)
   *
   * @param idtDde_p
   *          the service request identifier to set
   * @return The current handler
   * @note Support of fluentAPI
   */
  public final FollowUpTable withIdtDde(@NotNull final String idtDde_p)
  {
    _idtDde = idtDde_p;
    return this;
  }

  /**
   * Sets treatment instance identifier for the request
   *
   * @param idtItf_p
   *          the treatment instance identifier for the request to set
   * @return The current handler
   * @note Support of fluentAPI
   */
  public final FollowUpTable withIdtItf(@NotNull final String idtItf_p)
  {
    _idtItf = idtItf_p;
    return this;
  }

  /**
   * Sets SIC partition identifier
   *
   * @param idtParSic_p
   *          the SIC partition identifier to set
   * @return The current handler
   * @note Support of fluentAPI
   */
  public final FollowUpTable withIdtParSic(@NotNull final Integer idtParSic_p)
  {
    _idtParSic = idtParSic_p;
    return this;
  }

  /**
   * Sets technical system identifier that created the request
   *
   * @param idtSysTec_p
   *          the technical system identifier that created the request to set
   * @return The current handler
   * @note Support of fluentAPI
   */
  public final FollowUpTable withIdtSysTec(@NotNull final String idtSysTec_p)
  {
    _idtSysTec = idtSysTec_p;
    return this;
  }

  /**
   * Sets message associated with the last changed notification state
   *
   * @param libNtf_p
   *          the message associated with the last changed notification state to set
   * @return The current handler
   * @note Support of fluentAPI
   */
  public final FollowUpTable withLibNtf(@NotNull final String libNtf_p)
  {
    _libNtf = libNtf_p;
    return this;
  }

  /**
   * Sets message associated with the last changed provisioning state
   *
   * @param libPro_p
   *          the message associated with the last changed provisioning state to set
   * @return The current handler
   * @note Support of fluentAPI
   */
  public final FollowUpTable withLibPro(@NotNull final String libPro_p)
  {
    _libPro = libPro_p;
    return this;
  }

  /**
   * Sets message associated with the last changed reception state
   *
   * @param libRcp_p
   *          the message associated with the last changed reception state to set
   * @return The current handler
   * @note Support of fluentAPI
   */
  public final FollowUpTable withLibRcp(@NotNull final String libRcp_p)
  {
    _libRcp = libRcp_p;
    return this;
  }

  /**
   * Sets request PFI number
   *
   * @param nbrPfi_p
   *          the request PFI number to set
   * @return The current handler
   * @note Support of fluentAPI
   */
  public final FollowUpTable withNbrPfi(@NotNull final Integer nbrPfi_p)
  {
    _nbrPfi = nbrPfi_p;
    return this;
  }

  /**
   * Sets PFI number to provision in the request
   *
   * @param nbrPfiPro_p
   *          the PFI number to provision in the request to set
   * @return The current handler
   * @note Support of fluentAPI
   */
  public final FollowUpTable withNbrPfiPro(@NotNull final Integer nbrPfiPro_p)
  {
    _nbrPfiPro = nbrPfiPro_p;
    return this;
  }

  /**
   * Sets called service name by NPBT
   *
   * @param nomSvc_p
   *          the called service name by NPBT to set
   * @return The current handler
   * @note Support of fluentAPI
   */
  public final FollowUpTable withNomSvc(@NotNull final String nomSvc_p)
  {
    _nomSvc = nomSvc_p;
    return this;
  }

  /**
   * Sets the notification type
   *
   * @param typNtf_p
   *          the Notification type to set
   * @return The current handler
   * @note Support of fluentAPI
   */
  public final FollowUpTable withTypNtf(@NotNull final String typNtf_p)
  {
    _typNtf = typNtf_p;
    return this;
  }
}
