/*******************************************************************************
 * $Id: IOAMConnector.java 8437 2018-07-27 08:00:17Z kbettenc $
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.oam;

import com.bytel.ravel.services.connector.IConnector;

/**
 * Adds the Connector ID to the IOAM interface
 *
 * @author $Author$
 * @version ($Revision: 8437 $ $Date: 2018-07-27 10:00:17 +0200 (ven. 27 juil. 2018) $)
 */
public interface IOAMConnector extends IConnector, IOAM
{
  /**
   * The id to retrieve the connector.
   */
  String BEAN_ID = "OAMConnector"; //$NON-NLS-1$
}
