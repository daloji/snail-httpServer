/*******************************************************************************
 * $Id: OAMConnectorTest.java 43196 2020-11-03 13:11:36Z jjoly $
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.oam;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLRecoverableException;
import java.sql.SQLTimeoutException;
import java.sql.Timestamp;
import java.text.MessageFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.locks.Lock;

import org.apache.tomcat.jdbc.pool.DataSource;
import org.apache.tomcat.jdbc.pool.PoolExhaustedException;
import org.easymock.EasyMock;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockNice;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.conf.generated.Param;
import com.bytel.ravel.common.datetime.DateTimeManager;
import com.bytel.ravel.common.encryption.DESKeyManager;
import com.bytel.ravel.common.encryption.PasswordDecrypter;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionTools;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.test.JUnitTools;
import com.bytel.ravel.common.utils.DateTimeTools;
import com.bytel.ravel.common.utils.RetourFactoryForTU;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.services.conf.connector.generated.Connector;
import com.bytel.ravel.services.connector.AbstractDBConnector;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

import oracle.jdbc.OracleTypes;

/**
 * Tests for OAM connector
 *
 * @author $Author$
 * @version ($Revision: 43196 $ $Date: 2020-11-03 14:11:36 +0100 (mar. 03 nov. 2020) $)
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({ DESKeyManager.class, PasswordDecrypter.class, Connection.class, DataSource.class })
@PowerMockIgnore("javax.management.*")
public class OAMConnectorTest
{
  private static class OamRequestFields
  {
    /** Constant for REQUEST_ID. */
    private static final String REQUEST_ID = "REQUEST_ID"; //$NON-NLS-1$

    /** Constant for ORDER_ID. */
    private static final String ORDER_ID = "ORDER_ID"; //$NON-NLS-1$

    /** Constant for CUSTOM_1. */
    private static final String CUSTOM_1 = "CUSTOM_1"; //$NON-NLS-1$

    /** Constant for VERB. */
    private static final String VERB = "VERB"; //$NON-NLS-1$
  }

  private static class OamRequestValues
  {
    /** Constant for REQUEST_ID_VALUE. */
    private static final String REQUEST_ID_VALUE = "REQUEST_ID_VALUE"; //$NON-NLS-1$

    /** Constant for ORORDER_ID_VALUEDER_ID. */
    private static final String ORDER_ID_VALUE = "ORDER_ID_VALUE"; //$NON-NLS-1$

    /** Constant for ICCID. */
    private static final String ICCID = "ICCID"; //$NON-NLS-1$

    /** Constant for VERB_VALUE. */
    private static final String VERB_VALUE = "VERB_VALUE"; //$NON-NLS-1$
  }

  /**
   * Table DE_DSD fields.
   *
   * @author vborrego
   *
   */
  private enum TableDeSDSFields
  {
    /** */
    DATCREACT,

    /** */
    DATDEBTRT,

    /** */
    DATFINTRT,

    /** */
    DATNTF,

    /** */
    ETANTF,

    /** */
    ETAPRO,

    /** */
    ETARCP,

    /** */
    IN_IDTACT,

    /** */
    IDTACT,

    /** */
    IN_IDTDDE,

    /** */
    IDTDDE,

    /** */
    IDTITF,

    /** */
    IDTPARSIC,

    /** */
    IDTSYSTEC,

    /** */
    LIBNTF,

    /** */
    LIBPRO,

    /** */
    LIBRCP,

    /** */
    NBRPFI,

    /** */
    NBRPFIPRO,

    /** */
    NOMSVC,

    /** */
    TYPNTF
  }

  /**
  *
  */
  private static final int NBRPFI = 1234;

  /** Constant for ECHEC_INSERTION. */
  private static final String ECHEC_INSERTION = "ECHEC_INSERTION"; //$NON-NLS-1$

  /** Constant for ECHEC CONNEXION. */
  private static final String ECHEC_CONNEXION = "ECHEC_CONNEXION"; //$NON-NLS-1$

  /** Constant for INDISPONIBILITE_SESSION. */
  private static final String INDISPONIBILITE_SESSION = "INDISPONIBILITE_SESSION"; //$NON-NLS-1$

  /**
   * Current connector
   */
  private OAMConnector _connector;

  /**
   * Mock de {@link Lock}
   */
  @MockStrict
  Lock _dsReadLockMock;

  /**
   * Mock de {@link DataSource}
   */
  @MockNice
  DataSource _datasourceMock;

  /**
   * Mock de {@link Connection}
   */
  @MockNice
  Connection _connectionMock;

  /**
   * Mock de {@link CallableStatement}
   */
  @MockNice
  CallableStatement _callableStatementMock;

  /**
   * Mock de {@link ResultSet}
   */
  @MockNice
  ResultSet _resultSetMock;

  /**
   * @throws SQLException
   *           on error.
   */
  @Test
  public void consulterDemandesAAcquitter() throws SQLException
  {
    int nbMaxEntrees = 5;
    String sIdtItf = "BATCH"; //$NON-NLS-1$
    int iTimeOut = 5;
    _dsReadLockMock.lock();
    EasyMock.expect(_connectionMock.prepareCall("{call PG_IWSRESSOURCES.P_ConsulterDemandesAAcquitter(?,?,?,?,?,?,?) }")).andReturn(_callableStatementMock); //$NON-NLS-1$

    try
    {
      PowerMock.replay(_resultSetMock);

      _callableStatementMock.setQueryTimeout(iTimeOut);
      _callableStatementMock.setString("sIdtItf_p", sIdtItf); //$NON-NLS-1$
      _callableStatementMock.setInt("iNbMaxEntrees_p", nbMaxEntrees); //$NON-NLS-1$

      _callableStatementMock.registerOutParameter("cursorx", OracleTypes.CURSOR); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("Retour_Resultat", OracleTypes.NVARCHAR); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("Retour_Categorie", OracleTypes.NVARCHAR); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("Retour_Diagnostic", OracleTypes.NVARCHAR); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("Retour_Libelle", OracleTypes.NVARCHAR); //$NON-NLS-1$

      EasyMock.expect(_callableStatementMock.execute()).andReturn(true);
      EasyMock.expect(_callableStatementMock.getObject("cursorx")).andReturn(_resultSetMock); //$NON-NLS-1$
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_RESULTAT)).andReturn(StringConstants.OK);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_CATEGORIE)).andReturn(null);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_DIAGNOSTIC)).andReturn(null);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_LIBELLE)).andReturn(null);
      _resultSetMock.close();
      _connectionMock.close();

      PowerMock.replay(_callableStatementMock, _connectionMock, _resultSetMock);
      ConnectorResponse<List<FollowUpTable>, Retour> resp = _connector.consulterDemandesAAcquitter(new Tracabilite(), nbMaxEntrees, sIdtItf, iTimeOut);
      PowerMock.verify(_callableStatementMock, _connectionMock, _resultSetMock);

      Assert.assertEquals(StringConstants.OK, resp._second.getResultat());
      assertNull(resp._second.getDiagnostic());

    }
    catch (RavelException exception)
    {
      exception.printStackTrace();
    }

  }

  /**
   * @throws SQLException
   *           on error.
   */
  @Test
  public void consultLastProvisioningRequestFromMsisdn() throws SQLException
  {
    String msisdn = "33600300016"; //$NON-NLS-1$
    _dsReadLockMock.lock();
    EasyMock.expect(_connectionMock.prepareCall("{call PG_SPIRIT.P_GET_LAST_PROV_REQUEST(?,?,?,?,?,?) }")).andReturn(_callableStatementMock); //$NON-NLS-1$

    try
    {
      PowerMock.replay(_resultSetMock);

      _callableStatementMock.setQueryTimeout(1);
      _callableStatementMock.setString("pi_msisdn", msisdn); //$NON-NLS-1$

      _callableStatementMock.registerOutParameter("po_RESULT", OracleTypes.CURSOR); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("Retour_Resultat", OracleTypes.NVARCHAR); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("Retour_Categorie", OracleTypes.NVARCHAR); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("Retour_Diagnostic", OracleTypes.NVARCHAR); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("Retour_Libelle", OracleTypes.NVARCHAR); //$NON-NLS-1$

      EasyMock.expect(_callableStatementMock.execute()).andReturn(true);
      EasyMock.expect(_callableStatementMock.getObject("po_RESULT")).andReturn(_resultSetMock); //$NON-NLS-1$
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_RESULTAT)).andReturn(StringConstants.OK);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_CATEGORIE)).andReturn(null);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_DIAGNOSTIC)).andReturn(null);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_LIBELLE)).andReturn(null);
      _resultSetMock.close();
      _connectionMock.close();

      PowerMock.replay(_callableStatementMock, _connectionMock, _resultSetMock);
      ConnectorResponse<OamRequest, Retour> resp = _connector.consultLastProvisioningRequestFromMsisdn(new Tracabilite(), msisdn);
      PowerMock.verify(_callableStatementMock, _connectionMock, _resultSetMock);

      Assert.assertEquals(StringConstants.OK, resp._second.getResultat());
      assertNull(resp._second.getDiagnostic());

    }
    catch (RavelException exception)
    {
      exception.printStackTrace();
    }

  }

  /**
   * @throws SQLException
   *           on error.
   */
  @Test
  public void consultLastProvisioningRequestFromPfi() throws SQLException
  {
    String pfi = "5555"; //$NON-NLS-1$
    _dsReadLockMock.lock();
    EasyMock.expect(_connectionMock.prepareCall("{call PG_IWSRESSOURCES.P_001_C_LastProvRequest(?,?,?,?,?,?) }")).andReturn(_callableStatementMock); //$NON-NLS-1$

    try
    {
      PowerMock.replay(_resultSetMock);

      _callableStatementMock.setQueryTimeout(1);
      _callableStatementMock.setString("pi_SUBSCRIBER_ID", pfi); //$NON-NLS-1$

      _callableStatementMock.registerOutParameter("po_RESULT", OracleTypes.CURSOR); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("Retour_Resultat", OracleTypes.NVARCHAR); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("Retour_Categorie", OracleTypes.NVARCHAR); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("Retour_Diagnostic", OracleTypes.NVARCHAR); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("Retour_Libelle", OracleTypes.NVARCHAR); //$NON-NLS-1$

      EasyMock.expect(_callableStatementMock.execute()).andReturn(true);
      EasyMock.expect(_callableStatementMock.getObject("po_RESULT")).andReturn(_resultSetMock); //$NON-NLS-1$
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_RESULTAT)).andReturn(StringConstants.OK);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_CATEGORIE)).andReturn(null);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_DIAGNOSTIC)).andReturn(null);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_LIBELLE)).andReturn(null);
      _resultSetMock.close();
      _connectionMock.close();

      PowerMock.replay(_callableStatementMock, _connectionMock, _resultSetMock);
      ConnectorResponse<OamRequest, Retour> resp = _connector.consultLastProvisioningRequestFromPfi(new Tracabilite(), pfi);
      PowerMock.verify(_callableStatementMock, _connectionMock, _resultSetMock);

      Assert.assertEquals(StringConstants.OK, resp._second.getResultat());
      assertNull(resp._second.getDiagnostic());

    }
    catch (RavelException exception)
    {
      exception.printStackTrace();
    }

  }

  /**
   * Test getOamRequestOriginator OK.
   *
   * @throws Exception
   *           on unexpected error (technical exception for instance).
   */
  @Test
  public void getOamRequestOriginator_test_001_OK() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String originator = "originator"; //$NON-NLS-1$
    String status = "status"; //$NON-NLS-1$
    LocalDateTime dateDebut = DateTimeTools.toLocalDateTime(Timestamp.valueOf("2017-02-06 14:16:39.78")); //$NON-NLS-1$
    LocalDateTime dateFin = DateTimeTools.toLocalDateTime(Timestamp.valueOf("2017-02-06 14:16:50.00")); //$NON-NLS-1$

    // Expected result
    OamRequest oamRequest = new OamRequest();
    oamRequest.setRequestId(OamRequestValues.REQUEST_ID_VALUE);
    oamRequest.setOrderId(OamRequestValues.ORDER_ID_VALUE);
    oamRequest.setCustom1(OamRequestValues.ICCID);
    oamRequest.setVerb(OamRequestValues.VERB_VALUE);

    List<OamRequest> expectedResult = new ArrayList<>();
    expectedResult.add(oamRequest);

    Retour expectedRetour = RetourFactoryForTU.createOkRetour();

    // Prepare mocks
    EasyMock.expect(_connectionMock.prepareCall("{call PG_SPIRIT.P_GET_OAM_REQUEST_ORIGINATOR(?,?,?,?,?,?,?,?,?) }")).andReturn(_callableStatementMock); //$NON-NLS-1$
    PowerMock.replay(_connectionMock);

    EasyMock.expect(_callableStatementMock.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$
    EasyMock.expect(_callableStatementMock.getObject("po_RESULT")).andReturn(_resultSetMock); //$NON-NLS-1$
    PowerMock.replay(_callableStatementMock);

    EasyMock.expect(_resultSetMock.next()).andReturn(true);
    EasyMock.expect(_resultSetMock.getString(OamRequestFields.REQUEST_ID)).andReturn(OamRequestValues.REQUEST_ID_VALUE);
    EasyMock.expect(_resultSetMock.getString(OamRequestFields.ORDER_ID)).andReturn(OamRequestValues.ORDER_ID_VALUE);
    EasyMock.expect(_resultSetMock.getString(OamRequestFields.CUSTOM_1)).andReturn(OamRequestValues.ICCID);
    EasyMock.expect(_resultSetMock.getString(OamRequestFields.VERB)).andReturn(OamRequestValues.VERB_VALUE);
    EasyMock.expect(_resultSetMock.next()).andReturn(false);
    PowerMock.replay(_resultSetMock);

    // Call connector
    ConnectorResponse<List<OamRequest>, Retour> connectorResponse = _connector.getOamRequestOriginator(tracabilite, originator, status, dateDebut, dateFin);

    PowerMock.verify(_callableStatementMock);
    PowerMock.verify(_connectionMock);
    PowerMock.verify(_resultSetMock);

    // Asserts
    assertEquals(expectedResult.size(), connectorResponse._first.size());
    assertEquals(expectedResult.get(0).getRequestId(), connectorResponse._first.get(0).getRequestId());
    assertEquals(expectedResult.get(0).getOrderId(), connectorResponse._first.get(0).getOrderId());
    assertEquals(expectedResult.get(0).getCustom1(), connectorResponse._first.get(0).getCustom1());
    assertEquals(expectedResult.get(0).getVerb(), connectorResponse._first.get(0).getVerb());

    assertEquals(expectedRetour, connectorResponse._second);
  }

  /**
   * Test getOamRequestOriginator KO.
   *
   * @throws Exception
   *           on unexpected error (technical exception for instance).
   */
  @Test
  public void getOamRequestOriginator_test_002_KO() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String originator = "originator"; //$NON-NLS-1$
    String status = "status"; //$NON-NLS-1$
    LocalDateTime dateDebut = DateTimeTools.toLocalDateTime(Timestamp.valueOf("2017-02-06 14:16:39.78")); //$NON-NLS-1$
    LocalDateTime dateFin = DateTimeTools.toLocalDateTime(Timestamp.valueOf("2017-02-06 14:16:50.00")); //$NON-NLS-1$

    // Expected result
    Retour expectedRetour = RetourFactoryForTU.createKO(IMegConsts.CATEGORIE, IMegConsts.DIAGNOSTIC, IMegConsts.LIBELLE, null);

    // Prepare mocks
    EasyMock.expect(_connectionMock.prepareCall("{call PG_SPIRIT.P_GET_OAM_REQUEST_ORIGINATOR(?,?,?,?,?,?,?,?,?) }")).andReturn(_callableStatementMock); //$NON-NLS-1$
    PowerMock.replay(_connectionMock);

    EasyMock.expect(_callableStatementMock.getString("Retour_Resultat")).andReturn(StringConstants.KO); //$NON-NLS-1$
    EasyMock.expect(_callableStatementMock.getString("Retour_Categorie")).andReturn(IMegConsts.CATEGORIE); //$NON-NLS-1$
    EasyMock.expect(_callableStatementMock.getString("Retour_Diagnostic")).andReturn(IMegConsts.DIAGNOSTIC); //$NON-NLS-1$
    EasyMock.expect(_callableStatementMock.getString("Retour_Libelle")).andReturn(IMegConsts.LIBELLE); //$NON-NLS-1$
    EasyMock.expect(_callableStatementMock.getObject("po_RESULT")).andReturn(_resultSetMock); //$NON-NLS-1$
    PowerMock.replay(_callableStatementMock);

    EasyMock.expect(_resultSetMock.next()).andReturn(false);
    PowerMock.replay(_resultSetMock);

    // Call connector
    ConnectorResponse<List<OamRequest>, Retour> connectorResponse = _connector.getOamRequestOriginator(tracabilite, originator, status, dateDebut, dateFin);

    PowerMock.verify(_callableStatementMock);
    PowerMock.verify(_connectionMock);
    PowerMock.verify(_resultSetMock);

    // Asserts
    assertEquals(0, connectorResponse._first.size());
    assertEquals(expectedRetour, connectorResponse._second);
  }

  /**
   * Test getOamRequestOriginator SQLTimeoutException.
   *
   * @throws Exception
   *           on unexpected error (technical exception for instance).
   */
  @Test
  public void getOamRequestOriginator_test_003_KO() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String originator = "originator"; //$NON-NLS-1$
    String status = "status"; //$NON-NLS-1$
    LocalDateTime dateDebut = DateTimeTools.toLocalDateTime(Timestamp.valueOf("2017-02-06 14:16:39.78")); //$NON-NLS-1$
    LocalDateTime dateFin = DateTimeTools.toLocalDateTime(Timestamp.valueOf("2017-02-06 14:16:50.00")); //$NON-NLS-1$

    // Expected result
    Retour expectedRetour = RetourFactoryForTU.createKO(IMegConsts.CAT1, ECHEC_INSERTION, MessageFormat.format(Messages.getString(Messages.ERREUR_OAM_TIMEOUT_SUR_NON_REPONSE), 1), null);

    // Prepare mocks
    SQLTimeoutException sqlTimeoutException = new SQLTimeoutException(StringConstants.EMPTY_STRING);

    EasyMock.expect(_connectionMock.prepareCall("{call PG_SPIRIT.P_GET_OAM_REQUEST_ORIGINATOR(?,?,?,?,?,?,?,?,?) }")).andThrow(sqlTimeoutException); //$NON-NLS-1$
    PowerMock.replay(_connectionMock);

    // Call connector
    ConnectorResponse<List<OamRequest>, Retour> connectorResponse = _connector.getOamRequestOriginator(tracabilite, originator, status, dateDebut, dateFin);

    PowerMock.verify(_connectionMock);

    // Asserts
    assertNull(connectorResponse._first);
    assertEquals(expectedRetour, connectorResponse._second);
  }

  /**
   * Test getOamRequestOriginator PoolExhaustedException.
   *
   * @throws Exception
   *           on unexpected error (technical exception for instance).
   */
  @Test
  public void getOamRequestOriginator_test_004_KO() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String originator = "originator"; //$NON-NLS-1$
    String status = "status"; //$NON-NLS-1$
    LocalDateTime dateDebut = DateTimeTools.toLocalDateTime(Timestamp.valueOf("2017-02-06 14:16:39.78")); //$NON-NLS-1$
    LocalDateTime dateFin = DateTimeTools.toLocalDateTime(Timestamp.valueOf("2017-02-06 14:16:50.00")); //$NON-NLS-1$

    // Expected result
    Retour expectedRetour = RetourFactoryForTU.createKO(IMegConsts.CAT1, INDISPONIBILITE_SESSION, Messages.getString(Messages.ERREUR_OAM_AUCUNE_SESSION), null);

    // Prepare mocks
    PoolExhaustedException poolExhaustedException = new PoolExhaustedException(StringConstants.EMPTY_STRING);

    EasyMock.expect(_connectionMock.prepareCall("{call PG_SPIRIT.P_GET_OAM_REQUEST_ORIGINATOR(?,?,?,?,?,?,?,?,?) }")).andThrow(poolExhaustedException); //$NON-NLS-1$
    PowerMock.replay(_connectionMock);

    // Call connector
    ConnectorResponse<List<OamRequest>, Retour> connectorResponse = _connector.getOamRequestOriginator(tracabilite, originator, status, dateDebut, dateFin);

    PowerMock.verify(_connectionMock);

    // Asserts
    assertNull(connectorResponse._first);
    assertEquals(expectedRetour, connectorResponse._second);
  }

  /**
   * Test getOamRequestOriginator SQLRecoverableException.
   *
   * @throws Exception
   *           on unexpected error (technical exception for instance).
   */
  @Test
  public void getOamRequestOriginator_test_005_KO() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String originator = "originator"; //$NON-NLS-1$
    String status = "status"; //$NON-NLS-1$
    LocalDateTime dateDebut = DateTimeTools.toLocalDateTime(Timestamp.valueOf("2017-02-06 14:16:39.78")); //$NON-NLS-1$
    LocalDateTime dateFin = DateTimeTools.toLocalDateTime(Timestamp.valueOf("2017-02-06 14:16:50.00")); //$NON-NLS-1$

    // Expected result
    Retour expectedRetour = RetourFactoryForTU.createKO(IMegConsts.CAT1, ECHEC_CONNEXION, MessageFormat.format(Messages.getString(Messages.ERREUR_OAM_TIMEOUT_CONNEXION), 4), null);

    // Prepare mocks
    SQLRecoverableException sqlRecoverableException = new SQLRecoverableException(StringConstants.EMPTY_STRING);

    EasyMock.expect(_connectionMock.prepareCall("{call PG_SPIRIT.P_GET_OAM_REQUEST_ORIGINATOR(?,?,?,?,?,?,?,?,?) }")).andThrow(sqlRecoverableException); //$NON-NLS-1$
    PowerMock.replay(_connectionMock);

    // Call connector
    ConnectorResponse<List<OamRequest>, Retour> connectorResponse = _connector.getOamRequestOriginator(tracabilite, originator, status, dateDebut, dateFin);

    PowerMock.verify(_connectionMock);

    // Asserts
    assertNull(connectorResponse._first);
    assertEquals(expectedRetour, connectorResponse._second);
  }

  /**
   * Test getOamRequestOriginator SQLException.
   *
   * @throws Exception
   *           on unexpected error (technical exception for instance).
   */
  @Test
  public void getOamRequestOriginator_test_006_KO() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String originator = "originator"; //$NON-NLS-1$
    String status = "status"; //$NON-NLS-1$
    LocalDateTime dateDebut = DateTimeTools.toLocalDateTime(Timestamp.valueOf("2017-02-06 14:16:39.78")); //$NON-NLS-1$
    LocalDateTime dateFin = DateTimeTools.toLocalDateTime(Timestamp.valueOf("2017-02-06 14:16:50.00")); //$NON-NLS-1$

    // Prepare mocks
    final SQLException sqlException = new SQLException(StringConstants.EMPTY_STRING);

    EasyMock.expect(_connectionMock.prepareCall("{call PG_SPIRIT.P_GET_OAM_REQUEST_ORIGINATOR(?,?,?,?,?,?,?,?,?) }")).andThrow(sqlException); //$NON-NLS-1$
    PowerMock.replay(_connectionMock);

    // Expected result
    final String message = MessageFormat.format(Messages.getString(Messages.TECHNICAL_EXCEPTION), "PG_SPIRIT.P_GET_OAM_REQUEST_ORIGINATOR", sqlException.getErrorCode(), sqlException.getLocalizedMessage()) + ExceptionTools.getExceptionLineAndFile(sqlException); //$NON-NLS-1$
    RavelException expectedException = new RavelException(ExceptionType.PFS_EXCEPTION, ErrorCode.CNCTOR_00010, message, IOAMConnector.BEAN_ID, sqlException);

    // Call connector
    RavelException actualException = null;

    try
    {
      _connector.getOamRequestOriginator(tracabilite, originator, status, dateDebut, dateFin);
    }
    catch (RavelException e)
    {
      actualException = e;
    }

    PowerMock.verify(_connectionMock);

    // Asserts
    assertEquals(expectedException, actualException);
  }

  /**
   * Test inserts with constrains violations DOUBLON_A_RETRAITER
   *
   * @throws SQLException
   *           thrown SQL exception
   */
  @Test
  public void insererDemandeSuiviKO() throws SQLException
  {
    try
    {

      FollowUpTable followUpTable = new FollowUpTable();

      LocalDateTime date = LocalDateTime.now();
      followUpTable.setIdtDde("IDTDDE1"); //$NON-NLS-1$
      followUpTable.setNomSvc("NomSvc"); //$NON-NLS-1$
      followUpTable.setIdtSysTec("IdtSysTec"); //$NON-NLS-1$
      followUpTable.setIdtParSic(1);
      followUpTable.setIdtAct("IdAct"); //$NON-NLS-1$
      followUpTable.setDatCreact(date);
      followUpTable.setIdtItf("IdtItf"); //$NON-NLS-1$
      followUpTable.setNbrPfi(NBRPFI);
      followUpTable.setNbrPfiPro(NBRPFI);
      followUpTable.setDatDebTrt(date);
      followUpTable.setDatFinTrt(date);
      followUpTable.setEtaRcp("EtaRcp"); //$NON-NLS-1$
      followUpTable.setLibRcp("LibRcp"); //$NON-NLS-1$
      followUpTable.setEtapro("Etapro"); //$NON-NLS-1$
      followUpTable.setLibPro("LibPro"); //$NON-NLS-1$
      followUpTable.setEtaNtf("EtaNtf"); //$NON-NLS-1$
      followUpTable.setLibNtf("LibNtf"); //$NON-NLS-1$
      followUpTable.setTypNtf("TypNtf"); //$NON-NLS-1$
      followUpTable.setDatNtf(date);

      //Mocks
      EasyMock.expect(_connectionMock.prepareCall("{call PG_IWSRESSOURCES.P_InsererDemandeSuivi(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) }")).andReturn(_callableStatementMock); //$NON-NLS-1$
      _callableStatementMock.setQueryTimeout(1);
      _callableStatementMock.setString(TableDeSDSFields.IN_IDTDDE.name(), followUpTable.getIdtDde());
      _callableStatementMock.setString(TableDeSDSFields.NOMSVC.name(), followUpTable.getNomSvc());
      _callableStatementMock.setString(TableDeSDSFields.IDTSYSTEC.name(), followUpTable.getIdtSysTec());
      _callableStatementMock.setInt(TableDeSDSFields.IDTPARSIC.name(), followUpTable.getIdtParSic());
      _callableStatementMock.setString(TableDeSDSFields.IN_IDTACT.name(), followUpTable.getIdtAct());
      _callableStatementMock.setTimestamp(TableDeSDSFields.DATCREACT.name(), Timestamp.valueOf(followUpTable.getDatCreact()));
      _callableStatementMock.setString(TableDeSDSFields.IDTITF.name(), followUpTable.getIdtItf());
      _callableStatementMock.setInt(TableDeSDSFields.NBRPFI.name(), followUpTable.getNbrPfi());
      _callableStatementMock.setInt(TableDeSDSFields.NBRPFIPRO.name(), followUpTable.getNbrPfiPro());
      _callableStatementMock.setTimestamp(TableDeSDSFields.DATDEBTRT.name(), Timestamp.valueOf(followUpTable.getDatDebTrt()));
      _callableStatementMock.setString(TableDeSDSFields.ETARCP.name(), followUpTable.getEtaRcp());
      _callableStatementMock.setString(TableDeSDSFields.LIBRCP.name(), followUpTable.getLibRcp());

      _callableStatementMock.setTimestamp(TableDeSDSFields.DATFINTRT.name(), null);
      if (followUpTable.getDatFinTrt() != null)
      {
        _callableStatementMock.setTimestamp(TableDeSDSFields.DATFINTRT.name(), Timestamp.valueOf(followUpTable.getDatFinTrt()));
      }

      _callableStatementMock.setString(TableDeSDSFields.ETAPRO.name(), null);
      if (followUpTable.getEtapro() != null)
      {
        _callableStatementMock.setString(TableDeSDSFields.ETAPRO.name(), followUpTable.getEtapro());
      }

      _callableStatementMock.setString(TableDeSDSFields.LIBPRO.name(), null);
      if (followUpTable.getLibPro() != null)
      {
        _callableStatementMock.setString(TableDeSDSFields.LIBPRO.name(), followUpTable.getLibPro());
      }

      _callableStatementMock.setString(TableDeSDSFields.ETANTF.name(), null);
      if (followUpTable.getEtaNtf() != null)
      {
        _callableStatementMock.setString(TableDeSDSFields.ETANTF.name(), followUpTable.getEtaNtf());
      }

      _callableStatementMock.setString(TableDeSDSFields.LIBNTF.name(), null);
      if (followUpTable.getLibNtf() != null)
      {
        _callableStatementMock.setString(TableDeSDSFields.LIBNTF.name(), followUpTable.getLibNtf());
      }

      _callableStatementMock.setString(TableDeSDSFields.TYPNTF.name(), null);
      if (followUpTable.getTypNtf() != null)
      {
        _callableStatementMock.setString(TableDeSDSFields.TYPNTF.name(), followUpTable.getTypNtf());
      }

      _callableStatementMock.setTimestamp(TableDeSDSFields.DATNTF.name(), null);
      if (followUpTable.getDatNtf() != null)
      {
        _callableStatementMock.setTimestamp(TableDeSDSFields.DATNTF.name(), Timestamp.valueOf(followUpTable.getDatNtf()));
      }

      _callableStatementMock.registerOutParameter("po_RESULT", OracleTypes.CURSOR); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("Retour_Resultat", OracleTypes.NVARCHAR); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("Retour_Categorie", OracleTypes.NVARCHAR); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("Retour_Diagnostic", OracleTypes.NVARCHAR); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("Retour_Libelle", OracleTypes.NVARCHAR); //$NON-NLS-1$

      EasyMock.expect(_callableStatementMock.execute()).andReturn(true);
      EasyMock.expect(_callableStatementMock.getObject("po_RESULT")).andReturn(_resultSetMock); //$NON-NLS-1$
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_RESULTAT)).andReturn(StringConstants.KO);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_CATEGORIE)).andReturn(null);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_DIAGNOSTIC)).andReturn(null);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_LIBELLE)).andReturn(null);
      _resultSetMock.close();
      _connectionMock.close();

      PowerMock.replay(_callableStatementMock, _connectionMock, _resultSetMock);
      ConnectorResponse<FollowUpTable, Retour> resp1 = _connector.insererDemandeSuivi(new Tracabilite(), followUpTable);
      PowerMock.verify(_callableStatementMock, _connectionMock, _resultSetMock);

      Assert.assertEquals(StringConstants.KO, resp1._second.getResultat());
      assertNull(resp1._second.getDiagnostic());
      assertNull(resp1._first);
    }
    catch (RavelException exception)
    {
      exception.printStackTrace();
    }

  }

  /**
   * Test inserts with constrains violations DOUBLON_A_RETRAITER
   *
   * @throws SQLException
   *           thrown SQL exception
   */
  @Test
  public void insererDemandeSuiviOK() throws SQLException
  {
    try
    {

      FollowUpTable followUpTable = new FollowUpTable();

      LocalDateTime date = LocalDateTime.now();
      followUpTable.setIdtDde("IDTDDE1"); //$NON-NLS-1$
      followUpTable.setNomSvc("NomSvc"); //$NON-NLS-1$
      followUpTable.setIdtSysTec("IdtSysTec"); //$NON-NLS-1$
      followUpTable.setIdtParSic(1);
      followUpTable.setIdtAct("IdAct"); //$NON-NLS-1$
      followUpTable.setDatCreact(date);
      followUpTable.setIdtItf("IdtItf"); //$NON-NLS-1$
      followUpTable.setNbrPfi(NBRPFI);
      followUpTable.setNbrPfiPro(NBRPFI);
      followUpTable.setDatDebTrt(date);
      followUpTable.setDatFinTrt(null);
      followUpTable.setEtaRcp("EtaRcp"); //$NON-NLS-1$
      followUpTable.setLibRcp("LibRcp"); //$NON-NLS-1$
      followUpTable.setEtapro("Etapro"); //$NON-NLS-1$
      followUpTable.setLibPro("LibPro"); //$NON-NLS-1$
      followUpTable.setEtaNtf("EtaNtf"); //$NON-NLS-1$
      followUpTable.setLibNtf("LibNtf"); //$NON-NLS-1$
      followUpTable.setTypNtf("TypNtf"); //$NON-NLS-1$
      followUpTable.setDatNtf(null);

      //Mocks
      EasyMock.expect(_connectionMock.prepareCall("{call PG_IWSRESSOURCES.P_InsererDemandeSuivi(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) }")).andReturn(_callableStatementMock); //$NON-NLS-1$
      _callableStatementMock.setQueryTimeout(1);
      _callableStatementMock.setString(TableDeSDSFields.IN_IDTDDE.name(), followUpTable.getIdtDde());
      _callableStatementMock.setString(TableDeSDSFields.NOMSVC.name(), followUpTable.getNomSvc());
      _callableStatementMock.setString(TableDeSDSFields.IDTSYSTEC.name(), followUpTable.getIdtSysTec());
      _callableStatementMock.setInt(TableDeSDSFields.IDTPARSIC.name(), followUpTable.getIdtParSic());
      _callableStatementMock.setString(TableDeSDSFields.IN_IDTACT.name(), followUpTable.getIdtAct());
      _callableStatementMock.setTimestamp(TableDeSDSFields.DATCREACT.name(), Timestamp.valueOf(followUpTable.getDatCreact()));
      _callableStatementMock.setString(TableDeSDSFields.IDTITF.name(), followUpTable.getIdtItf());
      _callableStatementMock.setInt(TableDeSDSFields.NBRPFI.name(), followUpTable.getNbrPfi());
      _callableStatementMock.setInt(TableDeSDSFields.NBRPFIPRO.name(), followUpTable.getNbrPfiPro());
      _callableStatementMock.setTimestamp(TableDeSDSFields.DATDEBTRT.name(), Timestamp.valueOf(followUpTable.getDatDebTrt()));
      _callableStatementMock.setString(TableDeSDSFields.ETARCP.name(), followUpTable.getEtaRcp());
      _callableStatementMock.setString(TableDeSDSFields.LIBRCP.name(), followUpTable.getLibRcp());

      _callableStatementMock.setTimestamp(TableDeSDSFields.DATFINTRT.name(), null);
      if (followUpTable.getDatFinTrt() != null)
      {
        _callableStatementMock.setTimestamp(TableDeSDSFields.DATFINTRT.name(), Timestamp.valueOf(followUpTable.getDatFinTrt()));
      }

      _callableStatementMock.setString(TableDeSDSFields.ETAPRO.name(), null);
      if (followUpTable.getEtapro() != null)
      {
        _callableStatementMock.setString(TableDeSDSFields.ETAPRO.name(), followUpTable.getEtapro());
      }

      _callableStatementMock.setString(TableDeSDSFields.LIBPRO.name(), null);
      if (followUpTable.getLibPro() != null)
      {
        _callableStatementMock.setString(TableDeSDSFields.LIBPRO.name(), followUpTable.getLibPro());
      }

      _callableStatementMock.setString(TableDeSDSFields.ETANTF.name(), null);
      if (followUpTable.getEtaNtf() != null)
      {
        _callableStatementMock.setString(TableDeSDSFields.ETANTF.name(), followUpTable.getEtaNtf());
      }

      _callableStatementMock.setString(TableDeSDSFields.LIBNTF.name(), null);
      if (followUpTable.getLibNtf() != null)
      {
        _callableStatementMock.setString(TableDeSDSFields.LIBNTF.name(), followUpTable.getLibNtf());
      }

      _callableStatementMock.setString(TableDeSDSFields.TYPNTF.name(), null);
      if (followUpTable.getTypNtf() != null)
      {
        _callableStatementMock.setString(TableDeSDSFields.TYPNTF.name(), followUpTable.getTypNtf());
      }

      _callableStatementMock.setTimestamp(TableDeSDSFields.DATNTF.name(), null);
      if (followUpTable.getDatNtf() != null)
      {
        _callableStatementMock.setTimestamp(TableDeSDSFields.DATNTF.name(), Timestamp.valueOf(followUpTable.getDatNtf()));
      }

      _callableStatementMock.registerOutParameter("po_RESULT", OracleTypes.CURSOR); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("Retour_Resultat", OracleTypes.NVARCHAR); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("Retour_Categorie", OracleTypes.NVARCHAR); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("Retour_Diagnostic", OracleTypes.NVARCHAR); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("Retour_Libelle", OracleTypes.NVARCHAR); //$NON-NLS-1$

      EasyMock.expect(_callableStatementMock.execute()).andReturn(true);
      EasyMock.expect(_callableStatementMock.getObject("po_RESULT")).andReturn(_resultSetMock); //$NON-NLS-1$
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_RESULTAT)).andReturn(StringConstants.OK);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_CATEGORIE)).andReturn(IMegConsts.CAT3);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_DIAGNOSTIC)).andReturn(OAMConnector.DOUBLON_A_RETRAITER);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_LIBELLE)).andReturn(Messages.getString(Messages.WARNING_OAM_DOUBLON_ACTE_METIER));
      _resultSetMock.close();
      _connectionMock.close();

      PowerMock.replay(_callableStatementMock, _connectionMock, _resultSetMock);
      ConnectorResponse<FollowUpTable, Retour> resp1 = _connector.insererDemandeSuivi(new Tracabilite(), followUpTable);
      PowerMock.verify(_callableStatementMock, _connectionMock, _resultSetMock);

      Assert.assertEquals(StringConstants.OK, resp1._second.getResultat());
      Assert.assertEquals(IMegConsts.CAT3, resp1._second.getCategorie());
      Assert.assertEquals("PROVISIONING", resp1._second.getDiagnostic()); //$NON-NLS-1$

    }
    catch (RavelException exception)
    {
      exception.printStackTrace();
    }

  }

  /**
   * Test KO insererRequest
   *
   * @throws SQLException
   *           thrown SQL exception
   */
  @Test
  public void insererRequestKO() throws SQLException
  {
    try
    {
      LocalDateTime inDate = DateTimeManager.getInstance().now();
      LocalDateTime outDate = DateTimeManager.getInstance().now();

      //Mocks
      EasyMock.expect(_connectionMock.prepareCall("{call PG_SPIRIT.P_INS_REQUEST(?,?,?,?,?,?,?,?,?,?,?,?,?,?) }")).andReturn(_callableStatementMock); //$NON-NLS-1$
      _callableStatementMock.setQueryTimeout(1);
      _callableStatementMock.setString("pi_requestId", "requestId"); //$NON-NLS-1$ //$NON-NLS-2$
      _callableStatementMock.setString("pi_orderId", "orderId"); //$NON-NLS-1$ //$NON-NLS-2$
      _callableStatementMock.setTimestamp("pi_inDateTime", Timestamp.valueOf(inDate)); //$NON-NLS-1$
      _callableStatementMock.setTimestamp("pi_outDateTime", Timestamp.valueOf(outDate)); //$NON-NLS-1$
      _callableStatementMock.setString("pi_originator", "originator"); //$NON-NLS-1$ //$NON-NLS-2$
      _callableStatementMock.setString("pi_status", null); //$NON-NLS-1$
      _callableStatementMock.setInt("pi_priority", 1); //$NON-NLS-1$
      _callableStatementMock.setString("pi_verb", "verb"); //$NON-NLS-1$ //$NON-NLS-2$
      _callableStatementMock.setString("pi_customSim", "customSim1"); //$NON-NLS-1$ //$NON-NLS-2$
      _callableStatementMock.setString("pi_errorMsg", null); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("Retour_Resultat", OracleTypes.NVARCHAR); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("Retour_Categorie", OracleTypes.NVARCHAR); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("Retour_Diagnostic", OracleTypes.NVARCHAR); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("Retour_Libelle", OracleTypes.NVARCHAR); //$NON-NLS-1$

      EasyMock.expect(_callableStatementMock.execute()).andReturn(true);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_RESULTAT)).andReturn(StringConstants.KO);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_CATEGORIE)).andReturn(IMegConsts.CAT3);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_DIAGNOSTIC)).andReturn(OAMConnector.DOUBLON_A_RETRAITER);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_LIBELLE)).andReturn(Messages.getString(Messages.WARNING_OAM_DOUBLON_ACTE_METIER));

      _connectionMock.close();

      PowerMock.replay(_callableStatementMock, _connectionMock);
      ConnectorResponse<Nothing, Retour> resp1 = _connector.insererRequest(new Tracabilite(), "requestId", "orderId", inDate, outDate, "originator", null, 1, "verb", "customSim1", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
      PowerMock.verify(_callableStatementMock, _connectionMock);

      Assert.assertEquals(StringConstants.KO, resp1._second.getResultat());
      Assert.assertEquals(IMegConsts.CAT3, resp1._second.getCategorie());
      Assert.assertEquals(OAMConnector.DOUBLON_A_RETRAITER, resp1._second.getDiagnostic());

    }
    catch (RavelException exception)
    {
      exception.printStackTrace();
    }

  }

  /**
   * Test KO insererRequest
   *
   * @throws SQLException
   *           thrown SQL exception
   */
  @Test
  public void insererRequestKO_ERRORMSG() throws SQLException
  {
    try
    {
      LocalDateTime inDate = DateTimeManager.getInstance().now();
      LocalDateTime outDate = DateTimeManager.getInstance().now();

      //Mocks
      EasyMock.expect(_connectionMock.prepareCall("{call PG_SPIRIT.P_INS_REQUEST(?,?,?,?,?,?,?,?,?,?,?,?,?,?) }")).andReturn(_callableStatementMock); //$NON-NLS-1$
      _callableStatementMock.setQueryTimeout(1);
      _callableStatementMock.setString("pi_requestId", "requestId"); //$NON-NLS-1$ //$NON-NLS-2$
      _callableStatementMock.setString("pi_orderId", "orderId"); //$NON-NLS-1$ //$NON-NLS-2$
      _callableStatementMock.setTimestamp("pi_inDateTime", Timestamp.valueOf(inDate)); //$NON-NLS-1$
      _callableStatementMock.setTimestamp("pi_outDateTime", Timestamp.valueOf(outDate)); //$NON-NLS-1$
      _callableStatementMock.setString("pi_originator", "originator"); //$NON-NLS-1$ //$NON-NLS-2$
      _callableStatementMock.setString("pi_status", null); //$NON-NLS-1$
      _callableStatementMock.setInt("pi_priority", 1); //$NON-NLS-1$
      _callableStatementMock.setString("pi_verb", "verb"); //$NON-NLS-1$ //$NON-NLS-2$
      _callableStatementMock.setString("pi_customSim", "customSim1"); //$NON-NLS-1$ //$NON-NLS-2$
      _callableStatementMock.setString("pi_errorMsg", "errorMsg"); //$NON-NLS-1$ //$NON-NLS-2$
      _callableStatementMock.registerOutParameter("Retour_Resultat", OracleTypes.NVARCHAR); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("Retour_Categorie", OracleTypes.NVARCHAR); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("Retour_Diagnostic", OracleTypes.NVARCHAR); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("Retour_Libelle", OracleTypes.NVARCHAR); //$NON-NLS-1$

      EasyMock.expect(_callableStatementMock.execute()).andReturn(true);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_RESULTAT)).andReturn(StringConstants.KO);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_CATEGORIE)).andReturn(IMegConsts.CAT3);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_DIAGNOSTIC)).andReturn(OAMConnector.DOUBLON_A_RETRAITER);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_LIBELLE)).andReturn(Messages.getString(Messages.WARNING_OAM_DOUBLON_ACTE_METIER));

      _connectionMock.close();

      PowerMock.replay(_callableStatementMock, _connectionMock);
      ConnectorResponse<Nothing, Retour> resp1 = _connector.insererRequest(new Tracabilite(), "requestId", "orderId", inDate, outDate, "originator", null, 1, "verb", "customSim1", "errorMsg"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
      PowerMock.verify(_callableStatementMock, _connectionMock);

      Assert.assertEquals(StringConstants.KO, resp1._second.getResultat());
      Assert.assertEquals(IMegConsts.CAT3, resp1._second.getCategorie());
      Assert.assertEquals(OAMConnector.DOUBLON_A_RETRAITER, resp1._second.getDiagnostic());

    }
    catch (RavelException exception)
    {
      exception.printStackTrace();
    }

  }

  /**
   * Test Ok insererRequest
   *
   * @throws SQLException
   *           thrown SQL exception
   */
  @Test
  public void insererRequestOK() throws SQLException
  {
    try
    {
      LocalDateTime inDate = DateTimeManager.getInstance().now();

      //Mocks
      EasyMock.expect(_connectionMock.prepareCall("{call PG_SPIRIT.P_INS_REQUEST(?,?,?,?,?,?,?,?,?,?,?,?,?,?) }")).andReturn(_callableStatementMock); //$NON-NLS-1$
      _callableStatementMock.setString("pi_requestId", "requestId"); //$NON-NLS-1$ //$NON-NLS-2$
      _callableStatementMock.setString("pi_orderId", "orderId"); //$NON-NLS-1$ //$NON-NLS-2$
      _callableStatementMock.setTimestamp("pi_inDateTime", Timestamp.valueOf(inDate)); //$NON-NLS-1$
      _callableStatementMock.setTimestamp("pi_outDateTime", null); //$NON-NLS-1$
      _callableStatementMock.setString("pi_originator", "originator"); //$NON-NLS-1$ //$NON-NLS-2$
      _callableStatementMock.setString("pi_status", "status"); //$NON-NLS-1$ //$NON-NLS-2$
      _callableStatementMock.setInt("pi_priority", 1); //$NON-NLS-1$
      _callableStatementMock.setString("pi_verb", "verb"); //$NON-NLS-1$ //$NON-NLS-2$
      _callableStatementMock.setString("pi_customSim", "customSim1"); //$NON-NLS-1$ //$NON-NLS-2$
      _callableStatementMock.setString("pi_errorMsg", null); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("Retour_Resultat", OracleTypes.NVARCHAR); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("Retour_Categorie", OracleTypes.NVARCHAR); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("Retour_Diagnostic", OracleTypes.NVARCHAR); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("Retour_Libelle", OracleTypes.NVARCHAR); //$NON-NLS-1$

      EasyMock.expect(_callableStatementMock.execute()).andReturn(true);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_RESULTAT)).andReturn(StringConstants.OK);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_CATEGORIE)).andReturn(null);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_DIAGNOSTIC)).andReturn(null);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_LIBELLE)).andReturn(null);
      _connectionMock.close();

      PowerMock.replay(_callableStatementMock, _connectionMock);
      ConnectorResponse<Nothing, Retour> resp1 = _connector.insererRequest(new Tracabilite(), "requestId", "orderId", inDate, null, "originator", "status", 1, "verb", "customSim1", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
      PowerMock.verify(_callableStatementMock, _connectionMock);

      Assert.assertEquals(StringConstants.OK, resp1._second.getResultat());
    }
    catch (RavelException exception)
    {
      exception.printStackTrace();
    }

  }

  /**
   * Test Ok insererRequest
   *
   * @throws SQLException
   *           thrown SQL exception
   */
  @Test
  public void insererRequestOK_ERRORMSG() throws SQLException
  {
    try
    {
      LocalDateTime inDate = DateTimeManager.getInstance().now();

      //Mocks
      EasyMock.expect(_connectionMock.prepareCall("{call PG_SPIRIT.P_INS_REQUEST(?,?,?,?,?,?,?,?,?,?,?,?,?,?) }")).andReturn(_callableStatementMock); //$NON-NLS-1$
      _callableStatementMock.setString("pi_requestId", "requestId"); //$NON-NLS-1$ //$NON-NLS-2$
      _callableStatementMock.setString("pi_orderId", "orderId"); //$NON-NLS-1$ //$NON-NLS-2$
      _callableStatementMock.setTimestamp("pi_inDateTime", Timestamp.valueOf(inDate)); //$NON-NLS-1$
      _callableStatementMock.setTimestamp("pi_outDateTime", null); //$NON-NLS-1$
      _callableStatementMock.setString("pi_originator", "originator"); //$NON-NLS-1$ //$NON-NLS-2$
      _callableStatementMock.setString("pi_status", "status"); //$NON-NLS-1$ //$NON-NLS-2$
      _callableStatementMock.setInt("pi_priority", 1); //$NON-NLS-1$
      _callableStatementMock.setString("pi_verb", "verb"); //$NON-NLS-1$ //$NON-NLS-2$
      _callableStatementMock.setString("pi_customSim", "customSim1"); //$NON-NLS-1$ //$NON-NLS-2$
      _callableStatementMock.setString("pi_errorMsg", "errorMsg"); //$NON-NLS-1$ //$NON-NLS-2$
      _callableStatementMock.registerOutParameter("Retour_Resultat", OracleTypes.NVARCHAR); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("Retour_Categorie", OracleTypes.NVARCHAR); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("Retour_Diagnostic", OracleTypes.NVARCHAR); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("Retour_Libelle", OracleTypes.NVARCHAR); //$NON-NLS-1$

      EasyMock.expect(_callableStatementMock.execute()).andReturn(true);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_RESULTAT)).andReturn(StringConstants.OK);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_CATEGORIE)).andReturn(null);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_DIAGNOSTIC)).andReturn(null);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_LIBELLE)).andReturn(null);
      _connectionMock.close();

      PowerMock.replay(_callableStatementMock, _connectionMock);
      ConnectorResponse<Nothing, Retour> resp1 = _connector.insererRequest(new Tracabilite(), "requestId", "orderId", inDate, null, "originator", "status", 1, "verb", "customSim1", "errorMsg"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$
      PowerMock.verify(_callableStatementMock, _connectionMock);

      Assert.assertEquals(StringConstants.OK, resp1._second.getResultat());
    }
    catch (RavelException exception)
    {
      exception.printStackTrace();
    }

  }

  /**
   * Test update on existing record
   *
   * @throws SQLException
   *           thrown sql exception
   */
  @Test
  public void mettreAJourDemandeSuiviKODemandeNonUnique() throws SQLException
  {
    _dsReadLockMock.lock();
    int numRows = 2;

    try
    {
      FollowUpTable tableSuivi = new FollowUpTable();
      tableSuivi.setIdtDde("123456"); //$NON-NLS-1$
      tableSuivi.setNomSvc("nomsvcaass"); //$NON-NLS-1$
      tableSuivi.setIdtSysTec("idtsystecasd"); //$NON-NLS-1$
      tableSuivi.setIdtParSic(2);
      tableSuivi.setIdtAct("idtactasd"); //$NON-NLS-1$
      tableSuivi.setDatCreact(LocalDateTime.of(2000, 1, 31, 0, 0));
      tableSuivi.setIdtItf("idtitfasd"); //$NON-NLS-1$
      tableSuivi.setNbrPfi(2);
      tableSuivi.setNbrPfiPro(2);
      tableSuivi.setDatDebTrt(LocalDateTime.of(2000, 1, 31, 0, 0));
      tableSuivi.setDatFinTrt(LocalDateTime.of(2000, 1, 31, 0, 0));
      tableSuivi.setEtaRcp("etarcpasd"); //$NON-NLS-1$
      tableSuivi.setLibRcp("librcpasd"); //$NON-NLS-1$
      tableSuivi.setEtapro("etaproasd"); //$NON-NLS-1$
      tableSuivi.setLibPro("libproasd"); //$NON-NLS-1$
      tableSuivi.setDatFinTrt(LocalDateTime.of(2000, 1, 31, 0, 0));
      tableSuivi.setEtaNtf("etantfasd"); //$NON-NLS-1$
      tableSuivi.setLibNtf("libntfasd"); //$NON-NLS-1$
      tableSuivi.setTypNtf("typntfasd"); //$NON-NLS-1$
      tableSuivi.setDatNtf(LocalDateTime.of(2000, 1, 31, 0, 0));

      //Mocks
      EasyMock.expect(_connectionMock.prepareCall("{call PG_IWSRESSOURCES.P_MettreAJourDemandeSuivi(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) }")).andReturn(_callableStatementMock); //$NON-NLS-1$
      _callableStatementMock.setQueryTimeout(1);
      _callableStatementMock.setString("IDTDDE_p", tableSuivi.getIdtDde()); //$NON-NLS-1$
      _callableStatementMock.setString("NOMSVC_p", tableSuivi.getNomSvc()); //$NON-NLS-1$
      _callableStatementMock.setString("IDTSYSTEC_p", tableSuivi.getIdtSysTec()); //$NON-NLS-1$
      _callableStatementMock.setInt("IDTPARSIC_p", tableSuivi.getIdtParSic()); //$NON-NLS-1$
      _callableStatementMock.setString("IDTACT_p", tableSuivi.getIdtAct()); //$NON-NLS-1$
      _callableStatementMock.setTimestamp("DATCREACT_p", Timestamp.valueOf(tableSuivi.getDatCreact())); //$NON-NLS-1$
      _callableStatementMock.setString("IDTITF_p", tableSuivi.getIdtItf()); //$NON-NLS-1$
      _callableStatementMock.setInt("NBRPFI_p", tableSuivi.getNbrPfi()); //$NON-NLS-1$
      _callableStatementMock.setInt("NBRPFIPRO_p", tableSuivi.getNbrPfiPro()); //$NON-NLS-1$
      _callableStatementMock.setTimestamp("DATDEBTRT_p", Timestamp.valueOf(tableSuivi.getDatDebTrt())); //$NON-NLS-1$
      _callableStatementMock.setString("ETARCP_p", tableSuivi.getEtaRcp()); //$NON-NLS-1$
      _callableStatementMock.setString("LIBRCP_p", tableSuivi.getLibRcp()); //$NON-NLS-1$
      _callableStatementMock.setTimestamp("DATFINTRT_p", Timestamp.valueOf(tableSuivi.getDatFinTrt())); //$NON-NLS-1$
      _callableStatementMock.setString("ETAPRO_p", tableSuivi.getEtapro()); //$NON-NLS-1$
      _callableStatementMock.setString("LIBPRO_p", tableSuivi.getLibPro()); //$NON-NLS-1$
      _callableStatementMock.setString("ETANTF_p", tableSuivi.getEtaNtf()); //$NON-NLS-1$
      _callableStatementMock.setString("LIBNTF_p", tableSuivi.getLibNtf()); //$NON-NLS-1$
      _callableStatementMock.setString("TYPNTF_p", tableSuivi.getTypNtf()); //$NON-NLS-1$
      _callableStatementMock.setTimestamp("DATNTF_p", Timestamp.valueOf(tableSuivi.getDatNtf())); //$NON-NLS-1$

      _callableStatementMock.registerOutParameter("NrRows", OracleTypes.NUMBER); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("Retour_Resultat", OracleTypes.NVARCHAR); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("Retour_Categorie", OracleTypes.NVARCHAR); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("Retour_Diagnostic", OracleTypes.NVARCHAR); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("Retour_Libelle", OracleTypes.NVARCHAR); //$NON-NLS-1$

      EasyMock.expect(_callableStatementMock.execute()).andReturn(true);
      EasyMock.expect(_callableStatementMock.getInt("NrRows")).andReturn(numRows); //$NON-NLS-1$
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_RESULTAT)).andReturn(StringConstants.OK);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_CATEGORIE)).andReturn(IMegConsts.CAT3);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_DIAGNOSTIC)).andReturn(OAMConnector.DOUBLON_A_RETRAITER);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_LIBELLE)).andReturn(Messages.getString(Messages.WARNING_OAM_DOUBLON_ACTE_METIER));
      _connectionMock.close();
      _dsReadLockMock.unlock();

      PowerMock.replay(_callableStatementMock, _connectionMock, _resultSetMock);
      ConnectorResponse<Integer, Retour> resp = _connector.mettreAJourDemandeSuivi(new Tracabilite(), tableSuivi);
      PowerMock.verify(_callableStatementMock, _connectionMock, _resultSetMock);

      Assert.assertEquals(StringConstants.KO, resp._second.getResultat());
      Assert.assertEquals(IMegConsts.CAT3, resp._second.getCategorie());
      Assert.assertEquals("DEMANDE_NON_UNIQUE", resp._second.getDiagnostic()); //$NON-NLS-1$
      Assert.assertEquals(MessageFormat.format(Messages.getString(Messages.ERREUR_OAM_BASE_OAM_INCOHERENTE), numRows, tableSuivi.getIdtDde()), resp._second.getLibelle());
      Assert.assertEquals(new Integer(2), resp._first);
    }
    catch (RavelException exception)
    {
      exception.printStackTrace();
    }
  }

  /**
   * Test update on existing record
   *
   * @throws SQLException
   *           thrown sql exception
   */
  @Test
  public void mettreAJourDemandeSuiviKOEntreeInexistente() throws SQLException
  {
    _dsReadLockMock.lock();
    int numRows = 0;

    try
    {
      FollowUpTable tableSuivi = new FollowUpTable();
      tableSuivi.setIdtDde("123456"); //$NON-NLS-1$
      tableSuivi.setNomSvc("nomsvcaass"); //$NON-NLS-1$
      tableSuivi.setIdtSysTec("idtsystecasd"); //$NON-NLS-1$
      tableSuivi.setIdtParSic(2);
      tableSuivi.setIdtAct("idtactasd"); //$NON-NLS-1$
      tableSuivi.setDatCreact(LocalDateTime.of(2000, 1, 31, 0, 0));
      tableSuivi.setIdtItf("idtitfasd"); //$NON-NLS-1$
      tableSuivi.setNbrPfi(2);
      tableSuivi.setNbrPfiPro(2);
      tableSuivi.setDatDebTrt(LocalDateTime.of(2000, 1, 31, 0, 0));
      tableSuivi.setDatFinTrt(LocalDateTime.of(2000, 1, 31, 0, 0));
      tableSuivi.setEtaRcp("etarcpasd"); //$NON-NLS-1$
      tableSuivi.setLibRcp("librcpasd"); //$NON-NLS-1$
      tableSuivi.setEtapro("etaproasd"); //$NON-NLS-1$
      tableSuivi.setLibPro("libproasd"); //$NON-NLS-1$
      tableSuivi.setDatFinTrt(LocalDateTime.of(2000, 1, 31, 0, 0));
      tableSuivi.setEtaNtf("etantfasd"); //$NON-NLS-1$
      tableSuivi.setLibNtf("libntfasd"); //$NON-NLS-1$
      tableSuivi.setTypNtf("typntfasd"); //$NON-NLS-1$
      tableSuivi.setDatNtf(LocalDateTime.of(2000, 1, 31, 0, 0));

      //Mocks
      EasyMock.expect(_connectionMock.prepareCall("{call PG_IWSRESSOURCES.P_MettreAJourDemandeSuivi(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) }")).andReturn(_callableStatementMock); //$NON-NLS-1$
      _callableStatementMock.setQueryTimeout(1);
      _callableStatementMock.setString("IDTDDE_p", tableSuivi.getIdtDde()); //$NON-NLS-1$
      _callableStatementMock.setString("NOMSVC_p", tableSuivi.getNomSvc()); //$NON-NLS-1$
      _callableStatementMock.setString("IDTSYSTEC_p", tableSuivi.getIdtSysTec()); //$NON-NLS-1$
      _callableStatementMock.setInt("IDTPARSIC_p", tableSuivi.getIdtParSic()); //$NON-NLS-1$
      _callableStatementMock.setString("IDTACT_p", tableSuivi.getIdtAct()); //$NON-NLS-1$
      _callableStatementMock.setTimestamp("DATCREACT_p", Timestamp.valueOf(tableSuivi.getDatCreact())); //$NON-NLS-1$
      _callableStatementMock.setString("IDTITF_p", tableSuivi.getIdtItf()); //$NON-NLS-1$
      _callableStatementMock.setInt("NBRPFI_p", tableSuivi.getNbrPfi()); //$NON-NLS-1$
      _callableStatementMock.setInt("NBRPFIPRO_p", tableSuivi.getNbrPfiPro()); //$NON-NLS-1$
      _callableStatementMock.setTimestamp("DATDEBTRT_p", Timestamp.valueOf(tableSuivi.getDatDebTrt())); //$NON-NLS-1$
      _callableStatementMock.setString("ETARCP_p", tableSuivi.getEtaRcp()); //$NON-NLS-1$
      _callableStatementMock.setString("LIBRCP_p", tableSuivi.getLibRcp()); //$NON-NLS-1$
      _callableStatementMock.setTimestamp("DATFINTRT_p", Timestamp.valueOf(tableSuivi.getDatFinTrt())); //$NON-NLS-1$
      _callableStatementMock.setString("ETAPRO_p", tableSuivi.getEtapro()); //$NON-NLS-1$
      _callableStatementMock.setString("LIBPRO_p", tableSuivi.getLibPro()); //$NON-NLS-1$
      _callableStatementMock.setString("ETANTF_p", tableSuivi.getEtaNtf()); //$NON-NLS-1$
      _callableStatementMock.setString("LIBNTF_p", tableSuivi.getLibNtf()); //$NON-NLS-1$
      _callableStatementMock.setString("TYPNTF_p", tableSuivi.getTypNtf()); //$NON-NLS-1$
      _callableStatementMock.setTimestamp("DATNTF_p", Timestamp.valueOf(tableSuivi.getDatNtf())); //$NON-NLS-1$

      _callableStatementMock.registerOutParameter("NrRows", OracleTypes.NUMBER); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("Retour_Resultat", OracleTypes.NVARCHAR); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("Retour_Categorie", OracleTypes.NVARCHAR); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("Retour_Diagnostic", OracleTypes.NVARCHAR); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("Retour_Libelle", OracleTypes.NVARCHAR); //$NON-NLS-1$

      EasyMock.expect(_callableStatementMock.execute()).andReturn(true);
      EasyMock.expect(_callableStatementMock.getInt("NrRows")).andReturn(numRows); //$NON-NLS-1$
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_RESULTAT)).andReturn(StringConstants.OK);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_CATEGORIE)).andReturn(IMegConsts.CAT3);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_DIAGNOSTIC)).andReturn(OAMConnector.DOUBLON_A_RETRAITER);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_LIBELLE)).andReturn(Messages.getString(Messages.WARNING_OAM_DOUBLON_ACTE_METIER));
      _connectionMock.close();
      _dsReadLockMock.unlock();

      PowerMock.replay(_callableStatementMock, _connectionMock, _resultSetMock);
      ConnectorResponse<Integer, Retour> resp = _connector.mettreAJourDemandeSuivi(new Tracabilite(), tableSuivi);
      PowerMock.verify(_callableStatementMock, _connectionMock, _resultSetMock);

      Assert.assertEquals(StringConstants.KO, resp._second.getResultat());
      Assert.assertEquals(IMegConsts.CAT3, resp._second.getCategorie());
      Assert.assertEquals("ENTREE_INEXISTANTE", resp._second.getDiagnostic()); //$NON-NLS-1$
      Assert.assertEquals(Messages.getString(Messages.ERREUR_OAM_DEMANDE_A_METTRE_A_JOUR_INEXISTANTE), resp._second.getLibelle());
      Assert.assertEquals(new Integer(0), resp._first);
    }
    catch (RavelException exception)
    {
      exception.printStackTrace();
    }
  }

  /**
   * @throws Exception
   *           on error.
   */
  @Before
  public void setup() throws Exception
  {
    _connector = new OAMConnector();

    Connector _connectorConfig = new Connector();
    _connectorConfig.setName("OAMConnector"); //$NON-NLS-1$
    _connectorConfig.setType("client"); //$NON-NLS-1$
    _connectorConfig.setClazz("com.bytel.ressources.services.connector.oam.OAMConnector"); //$NON-NLS-1$
    _connectorConfig.setEnabled(true);
    Param dbConnectionString = new Param();
    Param dbUsername = new Param();
    Param dbPassword = new Param();
    Param poolSize = new Param();
    Param connectTimeoutSec = new Param();
    Param readTimeoutSec = new Param();

    dbConnectionString.setName("DB_CONNECTIONSTRING"); //$NON-NLS-1$
    dbConnectionString.setValue("jdbc:oracle:thin:@172.22.76.129:1531:PPR0N1D2"); //$NON-NLS-1$
    dbUsername.setName("DB_USERNAME"); //$NON-NLS-1$
    dbUsername.setValue("DEV19GDR"); //$NON-NLS-1$
    dbPassword.setName("DB_PASSWORD"); //$NON-NLS-1$
    dbPassword.setValue("0l7HRwWTfUwgsoOMyJ3uHw=="); //$NON-NLS-1$
    poolSize.setName("POOLSIZE"); //$NON-NLS-1$
    poolSize.setValue("15"); //$NON-NLS-1$
    connectTimeoutSec.setName("CONNECT_TIMEOUT_SEC"); //$NON-NLS-1$
    connectTimeoutSec.setValue("4"); //$NON-NLS-1$
    readTimeoutSec.setName("READ_TIMEOUT_SEC"); //$NON-NLS-1$
    readTimeoutSec.setValue("1"); //$NON-NLS-1$

    _connectorConfig.getParam().add(dbConnectionString);
    _connectorConfig.getParam().add(dbUsername);
    _connectorConfig.getParam().add(dbPassword);
    _connectorConfig.getParam().add(poolSize);
    _connectorConfig.getParam().add(connectTimeoutSec);
    _connectorConfig.getParam().add(readTimeoutSec);

    PowerMock.resetAll();
    PowerMock.mockStaticNice(PasswordDecrypter.class);
    PowerMock.mockStaticNice(DESKeyManager.class);

    // Load config
    _connector.loadConnectorConfiguration(_connectorConfig);
    JUnitTools.setInaccessibleFieldValue(_connector, "_datasource", _datasourceMock); //$NON-NLS-1$

    // Setup connection mock
    EasyMock.expect(_datasourceMock.getConnection()).andReturn(_connectionMock).anyTimes();
    PowerMock.replay(_datasourceMock);

  }

  /**
   * @throws SQLException
   *           on error.
   */
  @Test
  public void test_getOamRequest_OK() throws SQLException
  {
    String requestId = "5555"; //$NON-NLS-1$
    _dsReadLockMock.lock();
    EasyMock.expect(_connectionMock.prepareCall("{call PG_SPIRIT.P_GET_OAM_REQUEST(?,?,?,?,?,?) }")).andReturn(_callableStatementMock); //$NON-NLS-1$

    try
    {
      PowerMock.replay(_resultSetMock);

      _callableStatementMock.setQueryTimeout(1);
      _callableStatementMock.setString("pi_requestId", requestId); //$NON-NLS-1$

      _callableStatementMock.registerOutParameter("po_RESULT", OracleTypes.CURSOR); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("Retour_Resultat", OracleTypes.NVARCHAR); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("Retour_Categorie", OracleTypes.NVARCHAR); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("Retour_Diagnostic", OracleTypes.NVARCHAR); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("Retour_Libelle", OracleTypes.NVARCHAR); //$NON-NLS-1$

      EasyMock.expect(_callableStatementMock.execute()).andReturn(true);
      EasyMock.expect(_callableStatementMock.getObject("po_RESULT")).andReturn(_resultSetMock); //$NON-NLS-1$
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_RESULTAT)).andReturn(StringConstants.OK);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_CATEGORIE)).andReturn(null);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_DIAGNOSTIC)).andReturn(null);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_LIBELLE)).andReturn(null);
      _resultSetMock.close();
      _connectionMock.close();

      PowerMock.replay(_callableStatementMock, _connectionMock, _resultSetMock);
      ConnectorResponse<OamRequest, Retour> resp = _connector.getOamRequest(new Tracabilite(), requestId);
      PowerMock.verify(_callableStatementMock, _connectionMock, _resultSetMock);

      Assert.assertEquals(StringConstants.OK, resp._second.getResultat());
      assertNull(resp._second.getDiagnostic());

    }
    catch (RavelException exception)
    {
      exception.printStackTrace();
    }

  }

  /**
   * Test mettreAJourRequest KO : SQLTimeoutException thrown
   *
   * @throws Exception
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_getRequestIccid_KO_001() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String requestId = "requestId"; //$NON-NLS-1$

    EasyMock.expect(_connectionMock.prepareCall("{call PG_SPIRIT.P_GET_REQUEST_ICCID(?,?,?,?,?,?) }")).andThrow(new SQLTimeoutException()); //$NON-NLS-1$
    PowerMock.replay(_connectionMock);

    // Call connector
    ConnectorResponse<String, Retour> connectorResponse = _connector.getRequestIccid(tracabilite, requestId);

    // Asserts
    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, connectorResponse._second.getCategorie());
    assertEquals(MessageFormat.format(Messages.getString(Messages.ERREUR_OAM_TIMEOUT_SUR_NON_REPONSE), 1), connectorResponse._second.getLibelle());
    assertEquals(OAMConnector.ECHEC_INSERTION, connectorResponse._second.getDiagnostic());

  }

  /**
   * Test mettreAJourRequest KO : PoolExhaustedException thrown
   *
   * @throws Exception
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_getRequestIccid_KO_002() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String requestId = "requestId"; //$NON-NLS-1$

    EasyMock.expect(_connectionMock.prepareCall("{call PG_SPIRIT.P_GET_REQUEST_ICCID(?,?,?,?,?,?) }")).andThrow(new PoolExhaustedException()); //$NON-NLS-1$
    PowerMock.replay(_connectionMock);

    // Call connector
    ConnectorResponse<String, Retour> connectorResponse = _connector.getRequestIccid(tracabilite, requestId);

    // Asserts
    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, connectorResponse._second.getCategorie());
    assertEquals(Messages.getString(Messages.ERREUR_OAM_AUCUNE_SESSION), connectorResponse._second.getLibelle());
    assertEquals(OAMConnector.INDISPONIBILITE_SESSION, connectorResponse._second.getDiagnostic());

  }

  /**
   * Test mettreAJourRequest KO : SQLRecoverableException thrown
   *
   * @throws Exception
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_getRequestIccid_KO_003() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String requestId = "requestId"; //$NON-NLS-1$

    EasyMock.expect(_connectionMock.prepareCall("{call PG_SPIRIT.P_GET_REQUEST_ICCID(?,?,?,?,?,?) }")).andThrow(new SQLRecoverableException()); //$NON-NLS-1$
    PowerMock.replay(_connectionMock);

    // Call connector
    ConnectorResponse<String, Retour> connectorResponse = _connector.getRequestIccid(tracabilite, requestId);

    // Asserts
    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, connectorResponse._second.getCategorie());
    assertEquals(MessageFormat.format(Messages.getString(Messages.ERREUR_OAM_TIMEOUT_CONNEXION), 4), connectorResponse._second.getLibelle());
    assertEquals(OAMConnector.ECHEC_CONNEXION, connectorResponse._second.getDiagnostic());

  }

  /**
   * Test getRequestIccid KO : call to stored procedure returns KO
   *
   * @throws Exception
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_getRequestIccid_KO_004() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String requestId = "requestId"; //$NON-NLS-1$

    // Setup mocks
    EasyMock.expect(_callableStatementMock.getString("Retour_Resultat")).andReturn(StringConstants.KO); //$NON-NLS-1$
    PowerMock.replay(_callableStatementMock);

    EasyMock.expect(_connectionMock.prepareCall("{call PG_SPIRIT.P_GET_REQUEST_ICCID(?,?,?,?,?,?) }")).andReturn(_callableStatementMock); //$NON-NLS-1$
    PowerMock.replay(_connectionMock);

    // Call connector
    ConnectorResponse<String, Retour> connectorResponse = _connector.getRequestIccid(tracabilite, requestId);

    // Asserts
    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
  }

  /**
   * Test getRequestIccid OK
   *
   * @throws Exception
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_getRequestIccid_OK() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String requestId = "requestId"; //$NON-NLS-1$

    // Setup mocks
    EasyMock.expect(_callableStatementMock.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$
    EasyMock.expect(_callableStatementMock.getString("po_ICCID")).andReturn("iccid"); //$NON-NLS-1$ //$NON-NLS-2$
    PowerMock.replay(_callableStatementMock);

    EasyMock.expect(_connectionMock.prepareCall("{call PG_SPIRIT.P_GET_REQUEST_ICCID(?,?,?,?,?,?) }")).andReturn(_callableStatementMock); //$NON-NLS-1$
    PowerMock.replay(_connectionMock);

    // Call connector
    ConnectorResponse<String, Retour> connectorResponse = _connector.getRequestIccid(tracabilite, requestId);
    // Asserts
    assertEquals("OK", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals("iccid", connectorResponse._first); //$NON-NLS-1$

  }

  /**
   * Test mettreAJourMsgErreurDansRequest KO : SQLTimeoutException thrown
   *
   * @throws Exception
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_mettreAJourMsgErreurDansRequest_KO_001() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String requestId = "requestId"; //$NON-NLS-1$
    LocalDateTime outDateTime = DateTimeTools.toLocalDateTime(Timestamp.valueOf("2017-02-06 14:16:39.78")); //$NON-NLS-1$
    String originator = "originator"; //$NON-NLS-1$
    String status = "status"; //$NON-NLS-1$
    String customSim = "customSim"; //$NON-NLS-1$
    String errorMsg = "errorMsg";

    EasyMock.expect(_connectionMock.prepareCall("{call PG_SPIRIT.P_MAJ_REQUEST3(?,?,?,?,?,?,?,?,?,?) }")).andThrow(new SQLTimeoutException()); //$NON-NLS-1$
    PowerMock.replay(_connectionMock);

    // Call connector
    ConnectorResponse<Nothing, Retour> connectorResponse = _connector.mettreAJourMsgErreurDansRequest(tracabilite, requestId, outDateTime, originator, status, customSim, errorMsg);

    // Asserts
    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, connectorResponse._second.getCategorie());
    assertEquals(MessageFormat.format(Messages.getString(Messages.ERREUR_OAM_TIMEOUT_SUR_NON_REPONSE), 1), connectorResponse._second.getLibelle());
    assertEquals(OAMConnector.ECHEC_INSERTION, connectorResponse._second.getDiagnostic());

  }

  /**
   * Test mettreAJourMsgErreurDansRequest KO : PoolExhaustedException thrown
   *
   * @throws Exception
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_mettreAJourMsgErreurDansRequest_KO_002() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String requestId = "requestId"; //$NON-NLS-1$
    LocalDateTime outDateTime = DateTimeTools.toLocalDateTime(Timestamp.valueOf("2017-02-06 14:16:39.78")); //$NON-NLS-1$
    String originator = "originator"; //$NON-NLS-1$
    String status = "status"; //$NON-NLS-1$
    String customSim = "customSim"; //$NON-NLS-1$
    String errorMsg = "errorMsg";

    EasyMock.expect(_connectionMock.prepareCall("{call PG_SPIRIT.P_MAJ_REQUEST3(?,?,?,?,?,?,?,?,?,?) }")).andThrow(new PoolExhaustedException()); //$NON-NLS-1$
    PowerMock.replay(_connectionMock);

    // Call connector
    ConnectorResponse<Nothing, Retour> connectorResponse = _connector.mettreAJourMsgErreurDansRequest(tracabilite, requestId, outDateTime, originator, status, customSim, errorMsg);

    // Asserts
    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, connectorResponse._second.getCategorie());
    assertEquals(Messages.getString(Messages.ERREUR_OAM_AUCUNE_SESSION), connectorResponse._second.getLibelle());
    assertEquals(OAMConnector.INDISPONIBILITE_SESSION, connectorResponse._second.getDiagnostic());

  }

  /**
   * Test mettreAJourMsgErreurDansRequest KO : SQLRecoverableException thrown
   *
   * @throws Exception
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_mettreAJourMsgErreurDansRequest_KO_003() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String requestId = "requestId"; //$NON-NLS-1$
    LocalDateTime outDateTime = DateTimeTools.toLocalDateTime(Timestamp.valueOf("2017-02-06 14:16:39.78")); //$NON-NLS-1$
    String originator = "originator"; //$NON-NLS-1$
    String status = "status"; //$NON-NLS-1$
    String customSim = "customSim"; //$NON-NLS-1$
    String errorMsg = "errorMsg";

    EasyMock.expect(_connectionMock.prepareCall("{call PG_SPIRIT.P_MAJ_REQUEST3(?,?,?,?,?,?,?,?,?,?) }")).andThrow(new SQLRecoverableException()); //$NON-NLS-1$
    PowerMock.replay(_connectionMock);

    // Call connector
    ConnectorResponse<Nothing, Retour> connectorResponse = _connector.mettreAJourMsgErreurDansRequest(tracabilite, requestId, outDateTime, originator, status, customSim, errorMsg);

    // Asserts
    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, connectorResponse._second.getCategorie());
    assertEquals(MessageFormat.format(Messages.getString(Messages.ERREUR_OAM_TIMEOUT_CONNEXION), 4), connectorResponse._second.getLibelle());
    assertEquals(OAMConnector.ECHEC_CONNEXION, connectorResponse._second.getDiagnostic());

  }

  /**
   * Test mettreAJourMsgErreurDansRequest KO : SQLException thrown
   *
   * @throws SQLException
   *           exception
   */
  @Test
  public void test_mettreAJourMsgErreurDansRequest_KO_004() throws SQLException
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String requestId = "requestId"; //$NON-NLS-1$
    //LocalDateTime outDateTime = DateTimeTools.toLocalDateTime(Timestamp.valueOf("2017-02-06 14:16:39.78")); //$NON-NLS-1$
    LocalDateTime outDateTime = DateTimeManager.getInstance().now();
    String originator = "originator"; //$NON-NLS-1$
    String status = "status"; //$NON-NLS-1$
    String customSim = "customSim"; //$NON-NLS-1$
    String errorMsg = "errorMsg";

    EasyMock.expect(_connectionMock.prepareCall("{call PG_SPIRIT.P_MAJ_REQUEST3(?,?,?,?,?,?,?,?,?,?) }")).andThrow(new SQLException()); //$NON-NLS-1$
    PowerMock.replay(_connectionMock);

    // Call connector
    ConnectorResponse<Nothing, Retour> response = _connector.mettreAJourMsgErreurDansRequest(tracabilite, requestId, outDateTime, originator, status, customSim, errorMsg);
    assertNull(response);
  }

  /**
   * Test mettreAJourMsgErreurDansRequest KO : call to stocked procedure returns KO
   *
   * @throws Exception
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_mettreAJourMsgErreurDansRequest_KO_005() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String requestId = "requestId"; //$NON-NLS-1$
    LocalDateTime outDateTime = DateTimeTools.toLocalDateTime(Timestamp.valueOf("2017-02-06 14:16:39.78")); //$NON-NLS-1$
    String originator = "originator"; //$NON-NLS-1$
    String status = "status"; //$NON-NLS-1$
    String customSim = "customSim"; //$NON-NLS-1$
    String errorMsg = "errorMsg";

    // Setup mocks
    EasyMock.expect(_callableStatementMock.getString("Retour_Resultat")).andReturn(StringConstants.KO); //$NON-NLS-1$
    PowerMock.replay(_callableStatementMock);

    EasyMock.expect(_connectionMock.prepareCall("{call PG_SPIRIT.P_MAJ_REQUEST3(?,?,?,?,?,?,?,?,?,?) }")).andReturn(_callableStatementMock); //$NON-NLS-1$
    PowerMock.replay(_connectionMock);

    // Call connector
    ConnectorResponse<Nothing, Retour> connectorResponse = _connector.mettreAJourMsgErreurDansRequest(tracabilite, requestId, outDateTime, originator, status, customSim, errorMsg);

    // Asserts
    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertNull(connectorResponse._second.getCategorie());
    assertNull(connectorResponse._second.getLibelle());
    assertNull(connectorResponse._second.getDiagnostic());
  }

  /**
   * Test mettreAJourMsgErreurDansRequest OK
   *
   * @throws Exception
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_mettreAJourMsgErreurDansRequest_OK() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String requestId = "requestId"; //$NON-NLS-1$
    LocalDateTime outDateTime = DateTimeTools.toLocalDateTime(Timestamp.valueOf("2017-02-06 14:16:39.78")); //$NON-NLS-1$
    String originator = "originator"; //$NON-NLS-1$
    String status = "status"; //$NON-NLS-1$
    String customSim = "customSim"; //$NON-NLS-1$
    String errorMsg = "errorMsg";

    // Setup mocks
    EasyMock.expect(_callableStatementMock.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$
    EasyMock.expect(_callableStatementMock.getObject("po_RESULT")).andReturn(_resultSetMock); //$NON-NLS-1$
    PowerMock.replay(_callableStatementMock);

    EasyMock.expect(_connectionMock.prepareCall("{call PG_SPIRIT.P_MAJ_REQUEST3(?,?,?,?,?,?,?,?,?,?) }")).andReturn(_callableStatementMock); //$NON-NLS-1$
    PowerMock.replay(_connectionMock);

    // Call connector
    ConnectorResponse<Nothing, Retour> connectorResponse = _connector.mettreAJourMsgErreurDansRequest(tracabilite, requestId, outDateTime, originator, status, customSim, errorMsg);

    // Asserts
    assertEquals("OK", connectorResponse._second.getResultat()); //$NON-NLS-1$
  }

  /**
   * Test mettreAJourRequest KO : SQLTimeoutException thrown
   *
   * @throws Exception
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_mettreAJourRequest_KO_001() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String requestId = "requestId"; //$NON-NLS-1$
    LocalDateTime outDateTime = DateTimeTools.toLocalDateTime(Timestamp.valueOf("2017-02-06 14:16:39.78")); //$NON-NLS-1$
    String originator = "originator"; //$NON-NLS-1$
    String status = "status"; //$NON-NLS-1$
    String customSim = "customSim"; //$NON-NLS-1$

    EasyMock.expect(_connectionMock.prepareCall("{call PG_SPIRIT.P_MAJ_REQUEST(?,?,?,?,?,?,?,?,?) }")).andThrow(new SQLTimeoutException()); //$NON-NLS-1$
    PowerMock.replay(_connectionMock);

    // Call connector
    ConnectorResponse<Nothing, Retour> connectorResponse = _connector.mettreAJourRequest(tracabilite, requestId, outDateTime, originator, status, customSim);

    // Asserts
    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, connectorResponse._second.getCategorie());
    assertEquals(MessageFormat.format(Messages.getString(Messages.ERREUR_OAM_TIMEOUT_SUR_NON_REPONSE), 1), connectorResponse._second.getLibelle());
    assertEquals(OAMConnector.ECHEC_INSERTION, connectorResponse._second.getDiagnostic());

  }

  /**
   * Test mettreAJourRequest KO : PoolExhaustedException thrown
   *
   * @throws Exception
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_mettreAJourRequest_KO_002() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String requestId = "requestId"; //$NON-NLS-1$
    LocalDateTime outDateTime = DateTimeTools.toLocalDateTime(Timestamp.valueOf("2017-02-06 14:16:39.78")); //$NON-NLS-1$
    String originator = "originator"; //$NON-NLS-1$
    String status = "status"; //$NON-NLS-1$
    String customSim = "customSim"; //$NON-NLS-1$

    EasyMock.expect(_connectionMock.prepareCall("{call PG_SPIRIT.P_MAJ_REQUEST(?,?,?,?,?,?,?,?,?) }")).andThrow(new PoolExhaustedException()); //$NON-NLS-1$
    PowerMock.replay(_connectionMock);

    // Call connector
    ConnectorResponse<Nothing, Retour> connectorResponse = _connector.mettreAJourRequest(tracabilite, requestId, outDateTime, originator, status, customSim);

    // Asserts
    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, connectorResponse._second.getCategorie());
    assertEquals(Messages.getString(Messages.ERREUR_OAM_AUCUNE_SESSION), connectorResponse._second.getLibelle());
    assertEquals(OAMConnector.INDISPONIBILITE_SESSION, connectorResponse._second.getDiagnostic());

  }

  /**
   * Test mettreAJourRequest KO : SQLRecoverableException thrown
   *
   * @throws Exception
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_mettreAJourRequest_KO_003() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String requestId = "requestId"; //$NON-NLS-1$
    LocalDateTime outDateTime = DateTimeTools.toLocalDateTime(Timestamp.valueOf("2017-02-06 14:16:39.78")); //$NON-NLS-1$
    String originator = "originator"; //$NON-NLS-1$
    String status = "status"; //$NON-NLS-1$
    String customSim = "customSim"; //$NON-NLS-1$

    EasyMock.expect(_connectionMock.prepareCall("{call PG_SPIRIT.P_MAJ_REQUEST(?,?,?,?,?,?,?,?,?) }")).andThrow(new SQLRecoverableException()); //$NON-NLS-1$
    PowerMock.replay(_connectionMock);

    // Call connector
    ConnectorResponse<Nothing, Retour> connectorResponse = _connector.mettreAJourRequest(tracabilite, requestId, outDateTime, originator, status, customSim);

    // Asserts
    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, connectorResponse._second.getCategorie());
    assertEquals(MessageFormat.format(Messages.getString(Messages.ERREUR_OAM_TIMEOUT_CONNEXION), 4), connectorResponse._second.getLibelle());
    assertEquals(OAMConnector.ECHEC_CONNEXION, connectorResponse._second.getDiagnostic());

  }

  /**
   * Test mettreAJourRequest KO : SQLException thrown
   *
   * @throws SQLException
   *           exception
   */
  @Test
  public void test_mettreAJourRequest_KO_004() throws SQLException
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String requestId = "requestId"; //$NON-NLS-1$
    //LocalDateTime outDateTime = DateTimeTools.toLocalDateTime(Timestamp.valueOf("2017-02-06 14:16:39.78")); //$NON-NLS-1$
    LocalDateTime outDateTime = DateTimeManager.getInstance().now();
    String originator = "originator"; //$NON-NLS-1$
    String status = "status"; //$NON-NLS-1$
    String customSim = "customSim"; //$NON-NLS-1$

    EasyMock.expect(_connectionMock.prepareCall("{call PG_SPIRIT.P_MAJ_REQUEST(?,?,?,?,?,?,?,?,?) }")).andThrow(new SQLException()); //$NON-NLS-1$
    PowerMock.replay(_connectionMock);

    // Call connector
    ConnectorResponse<Nothing, Retour> response = _connector.mettreAJourRequest(tracabilite, requestId, outDateTime, originator, status, customSim);
    assertNull(response);
  }

  /**
   * Test mettreAJourRequest KO : call to stocked procedure returns KO
   *
   * @throws Exception
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_mettreAJourRequest_KO_005() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String requestId = "requestId"; //$NON-NLS-1$
    LocalDateTime outDateTime = DateTimeTools.toLocalDateTime(Timestamp.valueOf("2017-02-06 14:16:39.78")); //$NON-NLS-1$
    String originator = "originator"; //$NON-NLS-1$
    String status = "status"; //$NON-NLS-1$
    String customSim = "customSim"; //$NON-NLS-1$

    // Setup mocks
    EasyMock.expect(_callableStatementMock.getString("Retour_Resultat")).andReturn(StringConstants.KO); //$NON-NLS-1$
    PowerMock.replay(_callableStatementMock);

    EasyMock.expect(_connectionMock.prepareCall("{call PG_SPIRIT.P_MAJ_REQUEST(?,?,?,?,?,?,?,?,?) }")).andReturn(_callableStatementMock); //$NON-NLS-1$
    PowerMock.replay(_connectionMock);

    // Call connector
    ConnectorResponse<Nothing, Retour> connectorResponse = _connector.mettreAJourRequest(tracabilite, requestId, outDateTime, originator, status, customSim);

    // Asserts
    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertNull(connectorResponse._second.getCategorie());
    assertNull(connectorResponse._second.getLibelle());
    assertNull(connectorResponse._second.getDiagnostic());
  }

  /**
   * Test mettreAJourRequest OK
   *
   * @throws Exception
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_mettreAJourRequest_OK() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String requestId = "requestId"; //$NON-NLS-1$
    LocalDateTime outDateTime = DateTimeTools.toLocalDateTime(Timestamp.valueOf("2017-02-06 14:16:39.78")); //$NON-NLS-1$
    String originator = "originator"; //$NON-NLS-1$
    String status = "status"; //$NON-NLS-1$
    String customSim = "customSim"; //$NON-NLS-1$

    // Setup mocks
    EasyMock.expect(_callableStatementMock.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$
    EasyMock.expect(_callableStatementMock.getObject("po_RESULT")).andReturn(_resultSetMock); //$NON-NLS-1$
    PowerMock.replay(_callableStatementMock);

    EasyMock.expect(_connectionMock.prepareCall("{call PG_SPIRIT.P_MAJ_REQUEST(?,?,?,?,?,?,?,?,?) }")).andReturn(_callableStatementMock); //$NON-NLS-1$
    PowerMock.replay(_connectionMock);

    // Call connector
    ConnectorResponse<Nothing, Retour> connectorResponse = _connector.mettreAJourRequest(tracabilite, requestId, outDateTime, originator, status, customSim);

    // Asserts
    assertEquals("OK", connectorResponse._second.getResultat()); //$NON-NLS-1$
  }

  /**
   * Test to mettreAJourRequest KO
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_mettreAJourRequest2_KO_001() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String requestId = "requestId"; //$NON-NLS-1$
    LocalDateTime outDateTime = DateTimeTools.toLocalDateTime(Timestamp.valueOf("2017-02-06 14:16:39.78")); //$NON-NLS-1$
    String originator = "originator"; //$NON-NLS-1$
    String status = "status"; //$NON-NLS-1$
    String verb = "verb"; //$NON-NLS-1$

    EasyMock.expect(_connectionMock.prepareCall("{call PG_SPIRIT.P_MAJ_REQUEST2(?,?,?,?,?,?,?,?,?) }")).andThrow(new SQLTimeoutException()); //$NON-NLS-1$
    PowerMock.replay(_connectionMock);

    // Call connector
    ConnectorResponse<Nothing, Retour> connectorResponse = _connector.mettreAJourRequest(tracabilite, requestId, originator, status, outDateTime, verb);
    // Asserts
    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, connectorResponse._second.getCategorie());
    assertEquals(MessageFormat.format(Messages.getString(Messages.ERREUR_OAM_TIMEOUT_SUR_NON_REPONSE), 1), connectorResponse._second.getLibelle());
    assertEquals(OAMConnector.ECHEC_INSERTION, connectorResponse._second.getDiagnostic());

  }

  /**
   * Test to mettreAJourRequest KO
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_mettreAJourRequest2_KO_002() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String requestId = "requestId"; //$NON-NLS-1$
    LocalDateTime outDateTime = DateTimeTools.toLocalDateTime(Timestamp.valueOf("2017-02-06 14:16:39.78")); //$NON-NLS-1$
    String originator = "originator"; //$NON-NLS-1$
    String status = "status"; //$NON-NLS-1$
    String verb = "verb"; //$NON-NLS-1$

    EasyMock.expect(_connectionMock.prepareCall("{call PG_SPIRIT.P_MAJ_REQUEST2(?,?,?,?,?,?,?,?,?) }")).andThrow(new PoolExhaustedException()); //$NON-NLS-1$
    PowerMock.replay(_connectionMock);

    // Call connector
    ConnectorResponse<Nothing, Retour> connectorResponse = _connector.mettreAJourRequest(tracabilite, requestId, originator, status, outDateTime, verb);

    // Asserts
    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, connectorResponse._second.getCategorie());
    assertEquals(Messages.getString(Messages.ERREUR_OAM_AUCUNE_SESSION), connectorResponse._second.getLibelle());
    assertEquals(OAMConnector.INDISPONIBILITE_SESSION, connectorResponse._second.getDiagnostic());

  }

  /**
   * Test to mettreAJourRequest KO
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_mettreAJourRequest2_KO_003() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String requestId = "requestId"; //$NON-NLS-1$
    LocalDateTime outDateTime = DateTimeTools.toLocalDateTime(Timestamp.valueOf("2017-02-06 14:16:39.78")); //$NON-NLS-1$
    String originator = "originator"; //$NON-NLS-1$
    String status = "status"; //$NON-NLS-1$
    String verb = "verb"; //$NON-NLS-1$

    EasyMock.expect(_connectionMock.prepareCall("{call PG_SPIRIT.P_MAJ_REQUEST2(?,?,?,?,?,?,?,?,?) }")).andThrow(new SQLRecoverableException()); //$NON-NLS-1$
    PowerMock.replay(_connectionMock);

    // Call connector
    ConnectorResponse<Nothing, Retour> connectorResponse = _connector.mettreAJourRequest(tracabilite, requestId, originator, status, outDateTime, verb);

    // Asserts
    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, connectorResponse._second.getCategorie());
    assertEquals(MessageFormat.format(Messages.getString(Messages.ERREUR_OAM_TIMEOUT_CONNEXION), 4), connectorResponse._second.getLibelle());
    assertEquals(OAMConnector.ECHEC_CONNEXION, connectorResponse._second.getDiagnostic());

  }

  /**
   * Test to mettreAJourRequest KO
   *
   * @throws SQLException
   *           exception
   */
  @Test
  public void test_mettreAJourRequest2_KO_004() throws SQLException
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String requestId = "requestId"; //$NON-NLS-1$
    LocalDateTime outDateTime = DateTimeTools.toLocalDateTime(Timestamp.valueOf("2017-02-06 14:16:39.78")); //$NON-NLS-1$
    String originator = "originator"; //$NON-NLS-1$
    String status = "status"; //$NON-NLS-1$
    String verb = "verb"; //$NON-NLS-1$

    EasyMock.expect(_connectionMock.prepareCall("{call PG_SPIRIT.P_MAJ_REQUEST2(?,?,?,?,?,?,?,?,?) }")).andThrow(new SQLException()); //$NON-NLS-1$
    PowerMock.replay(_connectionMock);

    // Call connector
    ConnectorResponse<Nothing, Retour> connectorResponse = _connector.mettreAJourRequest(tracabilite, requestId, originator, status, outDateTime, verb);
    assertNull(connectorResponse);
  }

  /**
   * Test to mettreAJourRequest KO
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_mettreAJourRequest2_KO_005() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String requestId = "requestId"; //$NON-NLS-1$
    LocalDateTime outDateTime = DateTimeTools.toLocalDateTime(Timestamp.valueOf("2017-02-06 14:16:39.78")); //$NON-NLS-1$
    String originator = "originator"; //$NON-NLS-1$
    String status = "status"; //$NON-NLS-1$
    String verb = "verb"; //$NON-NLS-1$

    // Setup mocks
    EasyMock.expect(_callableStatementMock.getString("Retour_Resultat")).andReturn(StringConstants.KO); //$NON-NLS-1$
    PowerMock.replay(_callableStatementMock);

    EasyMock.expect(_connectionMock.prepareCall("{call PG_SPIRIT.P_MAJ_REQUEST2(?,?,?,?,?,?,?,?,?) }")).andReturn(_callableStatementMock); //$NON-NLS-1$
    PowerMock.replay(_connectionMock);

    // Call connector
    ConnectorResponse<Nothing, Retour> connectorResponse = _connector.mettreAJourRequest(tracabilite, requestId, originator, status, outDateTime, verb);

    // Asserts
    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertNull(connectorResponse._second.getCategorie());
    assertNull(connectorResponse._second.getLibelle());
    assertNull(connectorResponse._second.getDiagnostic());
  }

  /**
   * Test to mettreAJourRequest OK
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_mettreAJourRequest2_OK() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String requestId = "requestId"; //$NON-NLS-1$
    LocalDateTime outDateTime = DateTimeTools.toLocalDateTime(Timestamp.valueOf("2017-02-06 14:16:39.78")); //$NON-NLS-1$
    String originator = "originator"; //$NON-NLS-1$
    String status = "status"; //$NON-NLS-1$
    String customSim = "customSim"; //$NON-NLS-1$

    // Setup mocks
    EasyMock.expect(_callableStatementMock.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$
    EasyMock.expect(_callableStatementMock.getObject("po_RESULT")).andReturn(_resultSetMock); //$NON-NLS-1$
    PowerMock.replay(_callableStatementMock);

    EasyMock.expect(_connectionMock.prepareCall("{call PG_SPIRIT.P_MAJ_REQUEST(?,?,?,?,?,?,?,?,?) }")).andReturn(_callableStatementMock); //$NON-NLS-1$
    PowerMock.replay(_connectionMock);

    // Call connector
    ConnectorResponse<Nothing, Retour> connectorResponse = _connector.mettreAJourRequest(tracabilite, requestId, outDateTime, originator, status, customSim);

    // Asserts
    assertEquals("OK", connectorResponse._second.getResultat()); //$NON-NLS-1$
  }
}
