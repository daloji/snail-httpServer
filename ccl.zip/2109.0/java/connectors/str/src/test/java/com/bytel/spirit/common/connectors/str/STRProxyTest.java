/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.str;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockListener;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.testlisteners.FieldDefaulter;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.reflect.Whitebox;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.probes.AvgDoubleCollectorItem;
import com.bytel.ravel.common.probes.AvgFlowPerSecondCollector;
import com.bytel.ravel.common.utils.Pair;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.services.connector.ConnectorManager;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.connectors.str.structs.Parpntacc;
import com.bytel.spirit.common.connectors.str.structs.ResultContratEtPartition;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author pbarata
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PowerMockListener(FieldDefaulter.class)
@PrepareForTest({ ConnectorManager.class, STRProxy.class })
public class STRProxyTest
{

  /**
   * The tracabilite object
   */
  private static Tracabilite _tracabilite;

  /**
   * The NoTelephone
   */
  private static String _noTelephone;

  /**
   *
   */
  private static String _partition;

  /**
   * Factory to generate beans
   */
  private static PodamFactory _podam = new PodamFactoryImpl();

  /**
   * Initialize before all tests
   *
   * @throws Exception
   *           Exception to be thrown in case of failure
   */
  @BeforeClass
  public static void setUpBeforeClass() throws Exception
  {

    _tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    _noTelephone = _podam.manufacturePojo(String.class);
    _partition = _podam.manufacturePojo(String.class);

  }

  /**
   * The mock object {@code ConnectorManager}
   */
  @MockStrict
  private ConnectorManager _connectorManagerMock;

  /**
   * The mock object {@code ISTRConnector}
   */
  @MockStrict
  private ISTRConnector _STRConnectorMock;

  /**
   * Object {@code STRProxy} to evaluate
   */
  private STRProxy _instance;

  /**
   * Exception has been thrown
   */
  private boolean _exception;

  /**
   * The mock object {@code AvgFlowPerSecondCollector}
   */
  @MockStrict
  AvgFlowPerSecondCollector _avgCallCounterMock;

  /**
   * The mock object {@code AvgDoubleCollectorItem}
   */
  @MockStrict
  AvgDoubleCollectorItem _avgExecTimeMock;

  /**
   * Test with a RavelException at getConnector for recupererNoContratParNoTelephone
   *
   * @throws Exception
   *           exception
   */
  @Test
  public final void STRProxyTest_001() throws Exception
  {
    final ConnectorResponse<ResultContratEtPartition, Retour> expected = new ConnectorResponse<>(null, RetourFactory.createKO(IMegConsts.CAT1, IMegConsts.ACCES_DONNEES_INDISPONIBLE, "StringTest")); //$NON-NLS-1$
    ConnectorResponse<ResultContratEtPartition, Retour> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(3);
      EasyMock.expect(_connectorManagerMock.getConnector(ISTRConnector.BEAN_ID)).andThrow(new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.MGRCTR_00002, "StringTest")).once(); //$NON-NLS-1$

      EasyMock.expect(_connectorManagerMock.getConnector(ISTRConnector.BEAN_ID)).andReturn(_STRConnectorMock).once();
      EasyMock.expect(_STRConnectorMock.isEnabled()).andReturn(true);

      _connectorManagerMock.disable(ISTRConnector.BEAN_ID);
      EasyMock.expectLastCall().andVoid();

      PowerMock.replayAll();

      _instance = STRProxy.getInstance();
      actual = _instance.recupererNoContratParNoTelephone(_tracabilite, _noTelephone);
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }

  }

  /**
   * Test with a RavelException at recupererNoContratParNoTelephone call for recupererNoContratParNoTelephone
   *
   * @throws Exception
   *           exception
   */
  @Test
  public final void STRProxyTest_002() throws Exception
  {

    final ConnectorResponse<ResultContratEtPartition, Retour> expected = new ConnectorResponse<>(null, RetourFactory.createKO(IMegConsts.CAT1, IMegConsts.ACCES_DONNEES_INDISPONIBLE, "StringTest")); //$NON-NLS-1$
    ConnectorResponse<ResultContratEtPartition, Retour> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(3);
      EasyMock.expect(_connectorManagerMock.getConnector(ISTRConnector.BEAN_ID)).andReturn(_STRConnectorMock).once();

      _avgCallCounterMock.measure();
      EasyMock.expectLastCall().andVoid().once();

      EasyMock.expect(_STRConnectorMock.recupererNoContratParNoTelephone(_tracabilite, _noTelephone)).andThrow(new RavelException(ExceptionType.PFS_EXCEPTION, ErrorCode.CNCTOR_00010, "StringTest", ISTRConnector.BEAN_ID, new SQLException(StringConstants.EMPTY_STRING))); //$NON-NLS-1$

      _avgExecTimeMock.updateAvgValue(EasyMock.geq(0L));
      EasyMock.expectLastCall().andVoid().once();

      EasyMock.expect(_connectorManagerMock.getConnector(ISTRConnector.BEAN_ID)).andReturn(_STRConnectorMock).once();
      EasyMock.expect(_STRConnectorMock.isEnabled()).andReturn(true);

      _connectorManagerMock.disable(ISTRConnector.BEAN_ID);
      EasyMock.expectLastCall().andVoid();

      PowerMock.replayAll();

      _instance = STRProxy.getInstance();
      Whitebox.setInternalState(_instance, "_avg_psRecupererNoContratParNoTelephone_call_counter", _avgCallCounterMock); //$NON-NLS-1$
      Whitebox.setInternalState(_instance, "_avg_psRecupererNoContratParNoTelephone_ExecTime", _avgExecTimeMock); //$NON-NLS-1$
      actual = _instance.recupererNoContratParNoTelephone(_tracabilite, _noTelephone);
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // Assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }

  }

  /**
   * Nominal test for recupererNoContratParNoTelephone
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public final void STRProxyTest_003() throws Exception
  {
    final Retour retour = RetourFactory.createOkRetour();
    final ConnectorResponse<ResultContratEtPartition, Retour> expected = new ConnectorResponse<>(new ResultContratEtPartition(_noTelephone, _partition), retour);
    ConnectorResponse<ResultContratEtPartition, Retour> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(ISTRConnector.BEAN_ID)).andReturn(_STRConnectorMock).once();

      _avgCallCounterMock.measure();
      EasyMock.expectLastCall().andVoid().once();

      EasyMock.expect(_STRConnectorMock.recupererNoContratParNoTelephone(_tracabilite, _noTelephone)).andReturn(new ConnectorResponse<>(new ResultContratEtPartition(_noTelephone, _partition), retour));

      _avgExecTimeMock.updateAvgValue(EasyMock.geq(0L));
      EasyMock.expectLastCall().andVoid().once();

      EasyMock.expect(_connectorManagerMock.getConnector(ISTRConnector.BEAN_ID)).andReturn(_STRConnectorMock).once();
      EasyMock.expect(_STRConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = STRProxy.getInstance();
      Whitebox.setInternalState(_instance, "_avg_psRecupererNoContratParNoTelephone_call_counter", _avgCallCounterMock); //$NON-NLS-1$
      Whitebox.setInternalState(_instance, "_avg_psRecupererNoContratParNoTelephone_ExecTime", _avgExecTimeMock); //$NON-NLS-1$
      actual = _instance.recupererNoContratParNoTelephone(_tracabilite, _noTelephone);
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test with a RavelException at getConnector for recupererTypeVms
   *
   * @throws Exception
   *           exception
   */
  @Test
  public final void STRProxyTest_004() throws Exception
  {
    final Pair<String, Retour> expected = new ConnectorResponse<>(null, RetourFactory.createKO(IMegConsts.CAT1, IMegConsts.ACCES_DONNEES_INDISPONIBLE, "StringTest")); //$NON-NLS-1$
    Pair<String, Retour> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(3);
      EasyMock.expect(_connectorManagerMock.getConnector(ISTRConnector.BEAN_ID)).andThrow(new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.MGRCTR_00002, "StringTest")).once(); //$NON-NLS-1$

      EasyMock.expect(_connectorManagerMock.getConnector(ISTRConnector.BEAN_ID)).andReturn(_STRConnectorMock).once();
      EasyMock.expect(_STRConnectorMock.isEnabled()).andReturn(true);

      _connectorManagerMock.disable(ISTRConnector.BEAN_ID);
      EasyMock.expectLastCall().andVoid();

      PowerMock.replayAll();

      _instance = STRProxy.getInstance();
      actual = _instance.recupererTypeVms(_tracabilite, _noTelephone);
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }

  }

  /**
   * Test with a RavelException at recupererTypeVms call for recupererTypeVms
   *
   * @throws Exception
   *           exception
   */
  @Test
  public final void STRProxyTest_005() throws Exception
  {

    final Pair<String, Retour> expected = new ConnectorResponse<>(null, RetourFactory.createKO(IMegConsts.CAT1, IMegConsts.ACCES_DONNEES_INDISPONIBLE, "StringTest")); //$NON-NLS-1$
    Pair<String, Retour> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(3);
      EasyMock.expect(_connectorManagerMock.getConnector(ISTRConnector.BEAN_ID)).andReturn(_STRConnectorMock).once();

      _avgCallCounterMock.measure();
      EasyMock.expectLastCall().andVoid().once();

      EasyMock.expect(_STRConnectorMock.recupererTypeVms(_tracabilite, _noTelephone)).andThrow(new RavelException(ExceptionType.PFS_EXCEPTION, ErrorCode.CNCTOR_00010, "StringTest", ISTRConnector.BEAN_ID, new SQLException(StringConstants.EMPTY_STRING))); //$NON-NLS-1$

      _avgExecTimeMock.updateAvgValue(EasyMock.geq(0L));
      EasyMock.expectLastCall().andVoid().once();

      EasyMock.expect(_connectorManagerMock.getConnector(ISTRConnector.BEAN_ID)).andReturn(_STRConnectorMock).once();
      EasyMock.expect(_STRConnectorMock.isEnabled()).andReturn(true);

      _connectorManagerMock.disable(ISTRConnector.BEAN_ID);
      EasyMock.expectLastCall().andVoid();

      PowerMock.replayAll();

      _instance = STRProxy.getInstance();
      Whitebox.setInternalState(_instance, "_avg_psRecupererTypeVms_call_counter", _avgCallCounterMock); //$NON-NLS-1$
      Whitebox.setInternalState(_instance, "_avg_psRecupererTypeVms_ExecTime", _avgExecTimeMock); //$NON-NLS-1$
      actual = _instance.recupererTypeVms(_tracabilite, _noTelephone);
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // Assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }

  }

  /**
   * Nominal test for recupererTypeVms
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public final void STRProxyTest_006() throws Exception
  {
    final Retour retour = RetourFactory.createOkRetour();
    final Pair<String, Retour> expected = new ConnectorResponse<>(_noTelephone, retour);
    Pair<String, Retour> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(ISTRConnector.BEAN_ID)).andReturn(_STRConnectorMock).once();

      _avgCallCounterMock.measure();
      EasyMock.expectLastCall().andVoid().once();

      EasyMock.expect(_STRConnectorMock.recupererTypeVms(_tracabilite, _noTelephone)).andReturn(new ConnectorResponse<>(_noTelephone, retour));

      _avgExecTimeMock.updateAvgValue(EasyMock.geq(0L));
      EasyMock.expectLastCall().andVoid().once();

      EasyMock.expect(_connectorManagerMock.getConnector(ISTRConnector.BEAN_ID)).andReturn(_STRConnectorMock).once();
      EasyMock.expect(_STRConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = STRProxy.getInstance();
      Whitebox.setInternalState(_instance, "_avg_psRecupererTypeVms_call_counter", _avgCallCounterMock); //$NON-NLS-1$
      Whitebox.setInternalState(_instance, "_avg_psRecupererTypeVms_ExecTime", _avgExecTimeMock); //$NON-NLS-1$
      actual = _instance.recupererTypeVms(_tracabilite, _noTelephone);
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test with a RavelException at getConnector for getParpntaccByPfi
   *
   * @throws Exception
   *           exception
   */
  @Test
  public final void STRProxyTest_007() throws Exception
  {
    final Pair<List<Parpntacc>, Retour> expected = new ConnectorResponse<>(null, RetourFactory.createKO(IMegConsts.CAT1, IMegConsts.ACCES_DONNEES_INDISPONIBLE, "StringTest")); //$NON-NLS-1$
    Pair<List<Parpntacc>, Retour> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(3);
      EasyMock.expect(_connectorManagerMock.getConnector(ISTRConnector.BEAN_ID)).andThrow(new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.MGRCTR_00002, "StringTest")).once(); //$NON-NLS-1$

      EasyMock.expect(_connectorManagerMock.getConnector(ISTRConnector.BEAN_ID)).andReturn(_STRConnectorMock).once();
      EasyMock.expect(_STRConnectorMock.isEnabled()).andReturn(true);

      _connectorManagerMock.disable(ISTRConnector.BEAN_ID);
      EasyMock.expectLastCall().andVoid();

      PowerMock.replayAll();

      _instance = STRProxy.getInstance();
      actual = _instance.getParpntaccByPfi(_tracabilite, "pfi"); //NON-NLS
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test with a RavelException at getParpntaccByPfi call for getParpntaccByPfi
   *
   * @throws Exception
   *           exception
   */
  @Test
  public final void STRProxyTest_008() throws Exception
  {

    final Pair<List<Parpntacc>, Retour> expected = new ConnectorResponse<>(null, RetourFactory.createKO(IMegConsts.CAT1, IMegConsts.ACCES_DONNEES_INDISPONIBLE, "StringTest")); //$NON-NLS-1$
    Pair<List<Parpntacc>, Retour> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(3);
      EasyMock.expect(_connectorManagerMock.getConnector(ISTRConnector.BEAN_ID)).andReturn(_STRConnectorMock).once();

      _avgCallCounterMock.measure();
      EasyMock.expectLastCall().andVoid().once();

      EasyMock.expect(_STRConnectorMock.getParpntaccByPfi(_tracabilite, "pfi")).andThrow(new RavelException(ExceptionType.PFS_EXCEPTION, ErrorCode.CNCTOR_00010, "StringTest", ISTRConnector.BEAN_ID, new SQLException(StringConstants.EMPTY_STRING))); //$NON-NLS-1$

      _avgExecTimeMock.updateAvgValue(EasyMock.geq(0L));
      EasyMock.expectLastCall().andVoid().once();

      EasyMock.expect(_connectorManagerMock.getConnector(ISTRConnector.BEAN_ID)).andReturn(_STRConnectorMock).once();
      EasyMock.expect(_STRConnectorMock.isEnabled()).andReturn(true);

      _connectorManagerMock.disable(ISTRConnector.BEAN_ID);
      EasyMock.expectLastCall().andVoid();

      PowerMock.replayAll();

      _instance = STRProxy.getInstance();
      Whitebox.setInternalState(_instance, "_avg_psGetParpntaccByPfi_call_counter", _avgCallCounterMock); //$NON-NLS-1$
      Whitebox.setInternalState(_instance, "_avg_psGetParpntaccByPfi_ExecTime", _avgExecTimeMock); //$NON-NLS-1$
      actual = _instance.getParpntaccByPfi(_tracabilite, "pfi"); //NON-NLS
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // Assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Nominal test for getParpntaccByPfi
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public final void STRProxyTest_009() throws Exception
  {
    final Retour retour = RetourFactory.createOkRetour();

    Parpntacc parpntacc = new Parpntacc();
    parpntacc.setIdentifiantParpntacc(1L);
    parpntacc.setPfi("pfi"); //NON-NLS
    List<Parpntacc> parpntaccList = new ArrayList<>();
    parpntaccList.add(parpntacc);

    final Pair<List<Parpntacc>, Retour> expected = new ConnectorResponse<>(parpntaccList, retour);
    Pair<List<Parpntacc>, Retour> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(ISTRConnector.BEAN_ID)).andReturn(_STRConnectorMock).once();

      _avgCallCounterMock.measure();
      EasyMock.expectLastCall().andVoid().once();

      EasyMock.expect(_STRConnectorMock.getParpntaccByPfi(_tracabilite, "pfi")).andReturn(new ConnectorResponse<>(parpntaccList, retour)); //NON-NLS

      _avgExecTimeMock.updateAvgValue(EasyMock.geq(0L));
      EasyMock.expectLastCall().andVoid().once();

      EasyMock.expect(_connectorManagerMock.getConnector(ISTRConnector.BEAN_ID)).andReturn(_STRConnectorMock).once();
      EasyMock.expect(_STRConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = STRProxy.getInstance();
      Whitebox.setInternalState(_instance, "_avg_psGetParpntaccByPfi_call_counter", _avgCallCounterMock); //$NON-NLS-1$
      Whitebox.setInternalState(_instance, "_avg_psGetParpntaccByPfi_ExecTime", _avgExecTimeMock); //$NON-NLS-1$
      actual = _instance.getParpntaccByPfi(_tracabilite, "pfi"); //NON-NLS
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Initialization of tests
   *
   * @throws Exception
   *           Exception to be thrown in case of failure
   */
  @Before
  public void setUp() throws Exception
  {
    PowerMock.resetAll();
    PowerMock.mockStaticStrict(ConnectorManager.class);
  }
}
