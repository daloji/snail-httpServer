/*******************************************************************************
* $Id: STRConnectorTest.java 51044 2021-04-23 08:25:04Z fbarnabe $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.str;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLRecoverableException;
import java.sql.SQLTimeoutException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.apache.tomcat.jdbc.pool.DataSource;
import org.apache.tomcat.jdbc.pool.PoolExhaustedException;
import org.apache.tomcat.jdbc.pool.PoolProperties;
import org.easymock.Capture;
import org.easymock.EasyMock;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockNice;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.conf.generated.Param;
import com.bytel.ravel.common.encryption.DESKeyManager;
import com.bytel.ravel.common.encryption.PasswordDecrypter;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.services.conf.connector.generated.Connector;
import com.bytel.ravel.services.connector.AbstractDBConnector;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.connectors.str.IDataCallBack.DataCallBackReturn;
import com.bytel.spirit.common.connectors.str.structs.AuditUDCHEMSCMP;
import com.bytel.spirit.common.connectors.str.structs.AuditUDCHEMSPDP;
import com.bytel.spirit.common.connectors.str.structs.AuditUDCHEMSSDP;
import com.bytel.spirit.common.connectors.str.structs.DonneesClient;
import com.bytel.spirit.common.connectors.str.structs.InfoProfil;
import com.bytel.spirit.common.connectors.str.structs.LigneMarcheData;
import com.bytel.spirit.common.connectors.str.structs.LineStatusData;
import com.bytel.spirit.common.connectors.str.structs.MigrerStaStwVersVstwResponse;
import com.bytel.spirit.common.connectors.str.structs.ParamSrvTech;
import com.bytel.spirit.common.connectors.str.structs.Parpntacc;
import com.bytel.spirit.common.connectors.str.structs.ResultAuditHEMSCMP;
import com.bytel.spirit.common.connectors.str.structs.ResultAuditHEMSPDP;
import com.bytel.spirit.common.connectors.str.structs.ResultAuditHEMSSDP;
import com.bytel.spirit.common.connectors.str.structs.ResultContratEtPartition;
import com.bytel.spirit.common.connectors.str.structs.ServiceTechniqueSTR;
import com.bytel.spirit.common.connectors.str.structs.TSMData;
import com.bytel.spirit.common.shared.functional.types.functional.mediaBox.StMediaBox;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

/**
 * Tests for STR connector
 *
 * @author $Author: fcabral $
 * @version ($Revision: 51044 $ $Date: 2021-04-23 10:25:04 +0200 (ven. 23 avril 2021) $)
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({ DESKeyManager.class, PasswordDecrypter.class, Connection.class, DataSource.class, AbstractDBConnector.class })
public class STRConnectorTest
{
  /**
   * READ_TIMEOUT_SEC value
   */
  private static final int READ_TIMEOUT_SEC = 20;

  /**
   * READ_TIMEOUT_SEC_UDC value
   */
  private static final int READ_TIMEOUT_SEC_UDC = 1800;

  /**
   * Standard parameter name in PS call for Resultat.
   */
  private static final String RETOUR_RESULTAT = "Retour_Resultat"; //$NON-NLS-1$

  /**
   * Standard parameter name in PS call for Libelle.
   */
  public static final String RETOUR_LIBELLE = "Retour_Libelle"; //$NON-NLS-1$
  /**
   * Standard parameter name in PS call for Diagnostic.
   */
  public static final String RETOUR_DIAGNOSTIC = "Retour_Diagnostic"; //$NON-NLS-1$

  /**
   * Standard parameter name in PS call for Categorie.
   */
  public static final String RETOUR_CATEGORIE = "Retour_Categorie"; //$NON-NLS-1$

  /**
   * Current connector
   */
  private STRConnector _connector;

  /**
   * Datasource mock
   */
  @MockNice
  DataSource _datasource;

  /**
   * Connection mock
   */
  @MockNice
  Connection _connection;

  /**
   * CallableStatement mock
   */
  @MockNice
  CallableStatement _callableStatement;

  /**
   * ResultSet mock
   */
  @MockNice
  ResultSet _resultSet;

  /**
   * @throws Exception
   *           on error
   */
  @Before
  public void setup() throws Exception
  {
    _connector = new STRConnector();

    Connector _connectorConfig = new Connector();

    _connectorConfig.setName("STRConnector"); //$NON-NLS-1$
    _connectorConfig.setType("client"); //$NON-NLS-1$
    _connectorConfig.setClazz("com.bytel.ressources.ihm.connectors.str.STRConnector"); //$NON-NLS-1$
    _connectorConfig.setEnabled(true);
    Param dbConnectionString = new Param();
    Param dbUsername = new Param();
    Param dbPassword = new Param();
    Param poolSize = new Param();
    Param connectTimeoutSec = new Param();
    Param readTimeoutSec = new Param();
    Param readTimeoutSecAuditUDC = new Param();

    dbConnectionString.setName("DB_CONNECTIONSTRING"); //$NON-NLS-1$
    dbConnectionString.setValue("jdbc:oracle:thin:@localhost:1531:PPR0N0D3"); //$NON-NLS-1$
    dbUsername.setName("DB_USERNAME"); //$NON-NLS-1$
    dbUsername.setValue("DEVSTR"); //$NON-NLS-1$
    dbPassword.setName("DB_PASSWORD"); //$NON-NLS-1$
    dbPassword.setValue("0l7HRwWTfUwgsoOMyJ3uHw=="); //$NON-NLS-1$
    poolSize.setName("POOLSIZE"); //$NON-NLS-1$
    poolSize.setValue("30"); //$NON-NLS-1$

    connectTimeoutSec.setName(STRConnector.ParameterName.CONNECT_TIMEOUT_SEC.name());
    connectTimeoutSec.setValue("5"); //$NON-NLS-1$

    readTimeoutSec.setName(STRConnector.ParameterName.READ_TIMEOUT_SEC.name());
    readTimeoutSec.setValue(Integer.toString(READ_TIMEOUT_SEC));

    readTimeoutSecAuditUDC.setName(STRConnector.ParameterName.READ_TIMEOUT_SEC_AUDIT_UDC.name());
    readTimeoutSecAuditUDC.setValue("1800"); //$NON-NLS-1$

    _connectorConfig.getParam().add(dbConnectionString);
    _connectorConfig.getParam().add(dbUsername);
    _connectorConfig.getParam().add(dbPassword);
    _connectorConfig.getParam().add(poolSize);
    _connectorConfig.getParam().add(connectTimeoutSec);
    _connectorConfig.getParam().add(readTimeoutSec);
    _connectorConfig.getParam().add(readTimeoutSecAuditUDC);

    PowerMock.resetAll();
    PowerMock.mockStaticNice(PasswordDecrypter.class);
    PowerMock.mockStaticNice(DESKeyManager.class);

    EasyMock.expect(PasswordDecrypter.decrypt("0l7HRwWTfUwgsoOMyJ3uHw==")).andReturn("DEVPWD").anyTimes(); //$NON-NLS-1$ //$NON-NLS-2$
    PowerMock.replay(PasswordDecrypter.class);

    // Setup connection mock
    PowerMock.expectNew(DataSource.class, EasyMock.anyObject(PoolProperties.class)).andReturn(_datasource);
    EasyMock.expect(_datasource.getConnection()).andReturn(_connection).anyTimes();
    PowerMock.replay(DataSource.class);
    PowerMock.replay(_datasource);

    // Load config
    _connector.loadConnectorConfiguration(_connectorConfig);

  }

  /**
   * Test technical exception
   *
   * @throws SQLException
   *           on error
   */
  @Test
  public void testBuildTechnicalException() throws SQLException
  {
    // Request variables

    String imsi = "208209813902647"; //$NON-NLS-1$

    // Setup statement mock
    EasyMock.expect(_connection.prepareCall("{call PG_IWSRESSOURCES.P_003_CONSULT_LIGNE_MARCHE(?,?,?,?,?,?,?) }")).andThrow(new SQLException("testException")); //$NON-NLS-1$ //$NON-NLS-2$

    PowerMock.replayAll();

    // Call connector
    boolean exceptionOcurred = false;

    ConnectorResponse<List<LigneMarcheData>, Retour> response = null;

    try
    {
      response = _connector.consultLigneDeMarche(null, imsi, null);
    }
    catch (RavelException exception)
    {
      exceptionOcurred = true;
      Assert.assertTrue(exception.getMessage().startsWith("Technical Exception in STRConnector during PG_IWSRESSOURCES.P_003_CONSULT_LIGNE_MARCHE call: code(0) reason(testException)")); //$NON-NLS-1$
    }

    // Asserts
    Assert.assertTrue(exceptionOcurred);
    Assert.assertNull(response);
  }

  /**
   * Test the invocation for the stored procedure in STR_004_UPCCGetPFIFromMSISDN
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void testInvocationSTR004() throws Exception
  {
    // Request variables

    String msisdn = "33762111481"; //$NON-NLS-1$

    // Setup statement mock

    EasyMock.expect(_connection.prepareCall("{call PG_IWSRESSOURCES.P_UPCC_GET_PFI_FROM_MSISDN(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    EasyMock.expectLastCall();

    _callableStatement.setString("pi_MSISDN", msisdn); //$NON-NLS-1$
    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.getString(RETOUR_RESULTAT)).andReturn("OK"); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString(RETOUR_CATEGORIE)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_DIAGNOSTIC)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_LIBELLE)).andReturn(null);

    EasyMock.expect(_callableStatement.getObject("po_RESULT")).andReturn(_resultSet); //$NON-NLS-1$

    EasyMock.expect(_resultSet.next()).andReturn(true);
    EasyMock.expect(_resultSet.getString("PFI")).andReturn("1109813901431"); //$NON-NLS-1$ //$NON-NLS-2$

    EasyMock.expect(_resultSet.next()).andReturn(false);

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<String, Retour> res = _connector.upccGetPFIFromMSISDN(null, msisdn);

    // Asserts
    assertEquals(res._first, "1109813901431"); //$NON-NLS-1$
    assertEquals(res.getError().getResultat(), StringConstants.OK);

  }

  /**
   * Test the invocation for the stored procedure in STR_005_UPCCGetIMSIFromPFI
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void testInvocationSTR005() throws Exception
  {
    // Request variables

    String pfi = "1109813901431"; //$NON-NLS-1$

    // Setup statement mock
    EasyMock.expect(_connection.prepareCall("{call PG_IWSRESSOURCES.P_UPCC_GET_IMSI_FROM_PFI(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    EasyMock.expectLastCall();

    _callableStatement.setString("pi_PFI", pfi); //$NON-NLS-1$
    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.getString(RETOUR_RESULTAT)).andReturn("OK"); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString(RETOUR_CATEGORIE)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_DIAGNOSTIC)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_LIBELLE)).andReturn(null);

    EasyMock.expect(_callableStatement.getObject("po_RESULT")).andReturn(_resultSet); //$NON-NLS-1$

    EasyMock.expect(_resultSet.next()).andReturn(true);
    EasyMock.expect(_resultSet.getString("IMSI")).andReturn("208209813900741"); //$NON-NLS-1$ //$NON-NLS-2$

    EasyMock.expect(_resultSet.next()).andReturn(false);

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<String, Retour> res = _connector.upccGetIMSIFromPFI(null, pfi);

    // Asserts
    Assert.assertEquals("208209813900741", res._first); //$NON-NLS-1$
    assertEquals(res.getError().getResultat(), StringConstants.OK);
  }

  /**
   * Test the invocation for the stored procedure in STR_006_UPCCGetIDTPFSFromPFI
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void testInvocationSTR006() throws Exception
  {
    // Request variables

    String pfi = "1109813901431"; //$NON-NLS-1$

    // Setup statement mock
    EasyMock.expect(_connection.prepareCall("{call PG_IWSRESSOURCES.P_UPCC_GET_IDTPFS_FROM_PFI(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    EasyMock.expectLastCall();

    _callableStatement.setString("pi_PFI", pfi); //$NON-NLS-1$
    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.getString(RETOUR_RESULTAT)).andReturn("OK"); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString(RETOUR_CATEGORIE)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_DIAGNOSTIC)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_LIBELLE)).andReturn(null);

    EasyMock.expect(_callableStatement.getObject("po_RESULT")).andReturn(_resultSet); //$NON-NLS-1$

    EasyMock.expect(_resultSet.next()).andReturn(true);
    EasyMock.expect(_resultSet.getString("IDTPFS")).andReturn("10054007016"); //$NON-NLS-1$ //$NON-NLS-2$

    EasyMock.expect(_resultSet.next()).andReturn(false);

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<String, Retour> res = _connector.upccGetIDTPFSFromPFI(null, pfi);

    // Asserts
    Assert.assertEquals("10054007016", res._first); //$NON-NLS-1$
    assertEquals(res.getError().getResultat(), StringConstants.OK);
  }

  /**
   * Test the invocation for the stored procedure in STR_007_GetTSMDataByMSISDN
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void testInvocationSTR007() throws Exception
  {
    // Request variables

    String msisdn = "33762111481"; //$NON-NLS-1$

    // Setup statement mock
    EasyMock.expect(_connection.prepareCall("{call PG_IWSRESSOURCES.P_001_GET_TSM_DATA(?,?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    EasyMock.expectLastCall();

    _callableStatement.setString("pi_VALUE", msisdn); //$NON-NLS-1$
    EasyMock.expectLastCall();
    _callableStatement.setString("pi_TYPE", "MSISDN"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.getString(RETOUR_RESULTAT)).andReturn("OK"); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString(RETOUR_CATEGORIE)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_DIAGNOSTIC)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_LIBELLE)).andReturn(null);

    EasyMock.expect(_callableStatement.getObject("po_RESULT")).andReturn(_resultSet); //$NON-NLS-1$

    EasyMock.expect(_resultSet.next()).andReturn(true);
    EasyMock.expect(_resultSet.getString("ALIAS")).andReturn("110054007016"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("ICCID")).andReturn("8933209805139011535"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("CARTEPROFILE")).andReturn("16.00"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("LINESTATUS")).andReturn("ACTIVATED"); //$NON-NLS-1$ //$NON-NLS-2$

    EasyMock.expect(_resultSet.next()).andReturn(false);

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<List<TSMData>, Retour> res = _connector.getTSMDataByMSISDN(null, msisdn);

    // Asserts
    Assert.assertEquals("110054007016", res._first.get(0).getAlias()); //$NON-NLS-1$
    Assert.assertEquals("8933209805139011535", res._first.get(0).getIccid()); //$NON-NLS-1$
    Assert.assertEquals("16.00", res._first.get(0).getCarteprofile()); //$NON-NLS-1$
    Assert.assertEquals("ACTIVATED", res._first.get(0).getLinestatus()); //$NON-NLS-1$

    assertEquals(res.getError().getResultat(), StringConstants.OK);
  }

  /**
   * Test the invocation for the stored procedure in STR_008_GetTSMDataByIMSI
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void testInvocationSTR008() throws Exception
  {
    // Request variables

    String imsi = "208209813900741"; //$NON-NLS-1$

    // Setup statement mock
    EasyMock.expect(_connection.prepareCall("{call PG_IWSRESSOURCES.P_001_GET_TSM_DATA(?,?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    EasyMock.expectLastCall();

    _callableStatement.setString("pi_VALUE", imsi); //$NON-NLS-1$
    EasyMock.expectLastCall();
    _callableStatement.setString("pi_TYPE", "IMSI"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.getString(RETOUR_RESULTAT)).andReturn("OK"); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString(RETOUR_CATEGORIE)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_DIAGNOSTIC)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_LIBELLE)).andReturn(null);

    EasyMock.expect(_callableStatement.getObject("po_RESULT")).andReturn(_resultSet); //$NON-NLS-1$

    EasyMock.expect(_resultSet.next()).andReturn(true);
    EasyMock.expect(_resultSet.getString("ALIAS")).andReturn("110054007016"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("ICCID")).andReturn("8933209805139011535"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("CARTEPROFILE")).andReturn("16.00"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("LINESTATUS")).andReturn("ACTIVATED"); //$NON-NLS-1$ //$NON-NLS-2$

    EasyMock.expect(_resultSet.next()).andReturn(false);

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<List<TSMData>, Retour> res = _connector.getTSMDataByIMSI(null, "123456"); //$NON-NLS-1$

    // Asserts
    Assert.assertEquals("110054007016", res._first.get(0).getAlias()); //$NON-NLS-1$
    Assert.assertEquals("8933209805139011535", res._first.get(0).getIccid()); //$NON-NLS-1$
    Assert.assertEquals("16.00", res._first.get(0).getCarteprofile()); //$NON-NLS-1$
    Assert.assertEquals("ACTIVATED", res._first.get(0).getLinestatus()); //$NON-NLS-1$

    assertEquals(res.getError().getResultat(), StringConstants.OK);
  }

  /**
   * Test the invocation for the stored procedure in STR_011_GetPFIFromIMSI
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void testInvocationSTR009() throws Exception
  {
    // Request variables
    String imsi = "208209813900741"; //$NON-NLS-1$

    // Setup statement mock
    EasyMock.expect(_connection.prepareCall("{call PG_IWSRESSOURCES.P_GET_PFI_FROM_IMSI(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    EasyMock.expectLastCall();

    _callableStatement.setString("pi_IMSI", imsi); //$NON-NLS-1$
    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.getString(RETOUR_RESULTAT)).andReturn("OK"); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString(RETOUR_CATEGORIE)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_DIAGNOSTIC)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_LIBELLE)).andReturn(null);

    EasyMock.expect(_callableStatement.getObject("po_RESULT")).andReturn(_resultSet); //$NON-NLS-1$

    EasyMock.expect(_resultSet.next()).andReturn(true);
    EasyMock.expect(_resultSet.getString("PFI")).andReturn("1109813901431"); //$NON-NLS-1$ //$NON-NLS-2$

    EasyMock.expect(_resultSet.next()).andReturn(false);

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<String, Retour> res = _connector.getPFIFromIMSI(null, imsi);

    // Asserts
    Assert.assertEquals("1109813901431", res._first); //$NON-NLS-1$
    assertEquals(res.getError().getResultat(), StringConstants.OK);
  }

  /**
   * Test the invocation for the stored procedure in STR_012_GetMSISDNFromPFI
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void testInvocationSTR010() throws Exception
  {
    // Request variables
    String pfi = "1109813901431"; //$NON-NLS-1$

    // Setup statement mock
    EasyMock.expect(_connection.prepareCall("{call PG_IWSRESSOURCES.P_GET_MSISDN_FROM_PFI(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    EasyMock.expectLastCall();

    _callableStatement.setString("pi_PFI", pfi); //$NON-NLS-1$
    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.getString(RETOUR_RESULTAT)).andReturn("OK"); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString(RETOUR_CATEGORIE)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_DIAGNOSTIC)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_LIBELLE)).andReturn(null);

    EasyMock.expect(_callableStatement.getObject("po_RESULT")).andReturn(_resultSet); //$NON-NLS-1$

    EasyMock.expect(_resultSet.next()).andReturn(true);
    EasyMock.expect(_resultSet.getString("valpar")).andReturn("33762112176"); //$NON-NLS-1$ //$NON-NLS-2$

    EasyMock.expect(_resultSet.next()).andReturn(false);

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<String, Retour> res = _connector.getMSISDNFromPFI(null, pfi);

    // Asserts
    Assert.assertEquals("33762112176", res._first); //$NON-NLS-1$
    assertEquals(res.getError().getResultat(), StringConstants.OK);
  }

  /**
   * Test the invocation for the stored procedure in STR_013_GetMSISDNBDUOFromPFI
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void testInvocationSTR011() throws Exception
  {
    // Request variables
    String pfi = "1109813901431"; //$NON-NLS-1$

    // Setup statement mock
    EasyMock.expect(_connection.prepareCall("{call PG_IWSRESSOURCES.P_GET_MSISDN_BDUO_FROM_PFI(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    EasyMock.expectLastCall();

    _callableStatement.setString("pi_PFI", pfi); //$NON-NLS-1$
    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.getString(RETOUR_RESULTAT)).andReturn("OK"); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString(RETOUR_CATEGORIE)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_DIAGNOSTIC)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_LIBELLE)).andReturn(null);

    EasyMock.expect(_callableStatement.getObject("po_RESULT")).andReturn(_resultSet); //$NON-NLS-1$

    EasyMock.expect(_resultSet.next()).andReturn(true);
    EasyMock.expect(_resultSet.getString("valpar")).andReturn("33600310360"); //$NON-NLS-1$ //$NON-NLS-2$

    EasyMock.expect(_resultSet.next()).andReturn(false);

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<String, Retour> res = _connector.getMSISDNBDUOFromPFI(null, "1109813902627"); //$NON-NLS-1$

    // Asserts
    Assert.assertEquals("33600310360", res._first); //$NON-NLS-1$
    assertEquals(res.getError().getResultat(), StringConstants.OK);
  }

  /**
   * Test the invocation for the stored procedure in STR_014_GetSVCTECACCFromPFI
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void testInvocationSTR012() throws Exception
  {
    // Request variables
    String pfi = "1109813901431"; //$NON-NLS-1$

    // Setup statement mock
    EasyMock.expect(_connection.prepareCall("{call PG_IWSRESSOURCES.P_004_GET_SVCTECACC_FROM_PFI(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    EasyMock.expectLastCall().times(2);

    _callableStatement.setString("pi_PFI", pfi); //$NON-NLS-1$
    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.getString(RETOUR_RESULTAT)).andReturn("OK"); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString(RETOUR_CATEGORIE)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_DIAGNOSTIC)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_LIBELLE)).andReturn(null);

    EasyMock.expect(_callableStatement.getObject("po_RESULT")).andReturn(_resultSet); //$NON-NLS-1$

    // Service technique 1
    EasyMock.expect(_resultSet.next()).andReturn(true);
    EasyMock.expect(_resultSet.getLong("PK_SRV_TECH")).andReturn(5200368622L); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getString("NOM_SRV_TECH")).andReturn("ST_PCRF_VOIP"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getBoolean("IND_PRM_SUPPL")).andReturn(false); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getBoolean("SUSPENDU")).andReturn(false); //$NON-NLS-1$

    EasyMock.expect(_resultSet.getString("NOM_PRM1")).andReturn("MSISDN"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("VAL_PRM1")).andReturn("33762126963"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("NOM_PRM2")).andReturn("STATUS"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("VAL_PRM2")).andReturn("TRUE"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("NOM_PRM3")).andReturn(null); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getString("VAL_PRM3")).andReturn(null); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getString("NOM_PRM4")).andReturn(null); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getString("VAL_PRM4")).andReturn(null); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getString("NOM_PRM5")).andReturn(null); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getString("VAL_PRM5")).andReturn(null); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getString("NOM_PRM6")).andReturn(null); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getString("VAL_PRM6")).andReturn(null); //$NON-NLS-1$

    // Service technique 2
    EasyMock.expect(_resultSet.next()).andReturn(true);
    EasyMock.expect(_resultSet.getLong("PK_SRV_TECH")).andReturn(5200368348L); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getString("NOM_SRV_TECH")).andReturn("ST_HLR_PDPCONTEXT"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getBoolean("IND_PRM_SUPPL")).andReturn(true); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getBoolean("SUSPENDU")).andReturn(false); //$NON-NLS-1$

    EasyMock.expect(_resultSet.getString("NOM_PRM1")).andReturn("MSISDN"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("VAL_PRM1")).andReturn("33762125095"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("NOM_PRM2")).andReturn("APNID"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("VAL_PRM2")).andReturn("10"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("NOM_PRM3")).andReturn("ADRESSE_IP"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("VAL_PRM3")).andReturn("0"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("NOM_PRM4")).andReturn("PDPTY"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("VAL_PRM4")).andReturn("IPV4"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("NOM_PRM5")).andReturn("EQOSID"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("VAL_PRM5")).andReturn("401"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("NOM_PRM6")).andReturn("VPAA"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("VAL_PRM6")).andReturn("NO"); //$NON-NLS-1$ //$NON-NLS-2$

    // Get extra params

    EasyMock.expect(_connection.prepareCall("{call PG_IWSRESSOURCES.P_005_GET_PARSVCTECACC(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setLong("pi_Fk_Svctecacc", 5200368348L); //$NON-NLS-1$
    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.getString(RETOUR_RESULTAT)).andReturn("OK"); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString(RETOUR_CATEGORIE)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_DIAGNOSTIC)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_LIBELLE)).andReturn(null);

    EasyMock.expect(_callableStatement.getObject("po_RESULT")).andReturn(_resultSet); //$NON-NLS-1$

    EasyMock.expect(_resultSet.next()).andReturn(true);
    EasyMock.expect(_resultSet.getString("NOM_PRM")).andReturn("PDPID"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("VAL_PRM")).andReturn("1"); //$NON-NLS-1$ //$NON-NLS-2$

    EasyMock.expect(_resultSet.next()).andReturn(true);
    EasyMock.expect(_resultSet.getString("NOM_PRM")).andReturn("EPDPIND"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("VAL_PRM")).andReturn("NO"); //$NON-NLS-1$ //$NON-NLS-2$

    EasyMock.expect(_resultSet.next()).andReturn(false);

    EasyMock.expect(_resultSet.next()).andReturn(false);

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<List<ServiceTechniqueSTR>, Retour> res = _connector.getSVCTECACCFromPFI(null, pfi);

    // Asserts
    Assert.assertNotNull(res._first);
    Assert.assertTrue(!res._first.isEmpty());
    Assert.assertEquals(2, res._first.size());
    assertEquals(res.getError().getResultat(), StringConstants.OK);

    // Service technique 1
    ServiceTechniqueSTR srvtec = res._first.get(0);

    Assert.assertEquals(5200368622L, srvtec.getIdSrvTech());
    Assert.assertEquals("ST_PCRF_VOIP", srvtec.getNomSrvTech()); //$NON-NLS-1$
    Assert.assertEquals(6, srvtec.getListParam().size());
    Assert.assertFalse(srvtec.hasParamSuppl());
    Assert.assertFalse(srvtec.isSuspendu());

    ParamSrvTech param = srvtec.getListParam().get(0);
    Assert.assertEquals("MSISDN", param.getNom()); //$NON-NLS-1$
    Assert.assertEquals("33762126963", param.getValeur()); //$NON-NLS-1$

    param = srvtec.getListParam().get(1);
    Assert.assertEquals("STATUS", param.getNom()); //$NON-NLS-1$
    Assert.assertEquals("TRUE", param.getValeur()); //$NON-NLS-1$

    for (int i = 2; i < 6; i++)
    {
      param = srvtec.getListParam().get(i);
      Assert.assertNull(param.getNom());
      Assert.assertNull(param.getValeur());
    }

    // Service technique 2
    srvtec = res._first.get(1);

    Assert.assertEquals(5200368348L, srvtec.getIdSrvTech());
    Assert.assertEquals("ST_HLR_PDPCONTEXT", srvtec.getNomSrvTech()); //$NON-NLS-1$
    Assert.assertEquals(8, srvtec.getListParam().size());
    Assert.assertTrue(srvtec.hasParamSuppl());
    Assert.assertFalse(srvtec.isSuspendu());

    param = srvtec.getListParam().get(0);
    Assert.assertEquals("MSISDN", param.getNom()); //$NON-NLS-1$
    Assert.assertEquals("33762125095", param.getValeur()); //$NON-NLS-1$

    param = srvtec.getListParam().get(1);
    Assert.assertEquals("APNID", param.getNom()); //$NON-NLS-1$
    Assert.assertEquals("10", param.getValeur()); //$NON-NLS-1$

    param = srvtec.getListParam().get(2);
    Assert.assertEquals("ADRESSE_IP", param.getNom()); //$NON-NLS-1$
    Assert.assertEquals("0", param.getValeur()); //$NON-NLS-1$

    param = srvtec.getListParam().get(3);
    Assert.assertEquals("PDPTY", param.getNom()); //$NON-NLS-1$
    Assert.assertEquals("IPV4", param.getValeur()); //$NON-NLS-1$

    param = srvtec.getListParam().get(4);
    Assert.assertEquals("EQOSID", param.getNom()); //$NON-NLS-1$
    Assert.assertEquals("401", param.getValeur()); //$NON-NLS-1$

    param = srvtec.getListParam().get(5);
    Assert.assertEquals("VPAA", param.getNom()); //$NON-NLS-1$
    Assert.assertEquals("NO", param.getValeur()); //$NON-NLS-1$

    param = srvtec.getListParam().get(6);
    Assert.assertEquals("PDPID", param.getNom()); //$NON-NLS-1$
    Assert.assertEquals("1", param.getValeur()); //$NON-NLS-1$

    param = srvtec.getListParam().get(7);
    Assert.assertEquals("EPDPIND", param.getNom()); //$NON-NLS-1$
    Assert.assertEquals("NO", param.getValeur()); //$NON-NLS-1$
  }

  /**
   * Test the invocation for the stored procedure in STR_015_GetPARSVCTECACC
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void testInvocationSTR013() throws Exception
  {
    // Request variables
    long idSrvTec = 5200368348L;

    // Setup statement mock
    EasyMock.expect(_connection.prepareCall("{call PG_IWSRESSOURCES.P_005_GET_PARSVCTECACC(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setLong("pi_Fk_Svctecacc", idSrvTec); //$NON-NLS-1$
    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.getString(RETOUR_RESULTAT)).andReturn("OK"); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString(RETOUR_CATEGORIE)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_DIAGNOSTIC)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_LIBELLE)).andReturn(null);

    EasyMock.expect(_callableStatement.getObject("po_RESULT")).andReturn(_resultSet); //$NON-NLS-1$

    EasyMock.expect(_resultSet.next()).andReturn(true);
    EasyMock.expect(_resultSet.getString("NOM_PRM")).andReturn("PDPID"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("VAL_PRM")).andReturn("1"); //$NON-NLS-1$ //$NON-NLS-2$

    EasyMock.expect(_resultSet.next()).andReturn(true);
    EasyMock.expect(_resultSet.getString("NOM_PRM")).andReturn("EPDPIND"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("VAL_PRM")).andReturn("NO"); //$NON-NLS-1$ //$NON-NLS-2$

    EasyMock.expect(_resultSet.next()).andReturn(false);

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<List<ParamSrvTech>, Retour> res = _connector.getPARSVCTECACC(null, 5200368348l);

    // Asserts
    Assert.assertNotNull(res._first);
    Assert.assertTrue(!res._first.isEmpty());
    Assert.assertEquals(2, res._first.size());
    assertEquals(res.getError().getResultat(), StringConstants.OK);

    ParamSrvTech param = res._first.get(0);
    Assert.assertEquals("PDPID", param.getNom()); //$NON-NLS-1$
    Assert.assertEquals("1", param.getValeur()); //$NON-NLS-1$

    param = res._first.get(1);
    Assert.assertEquals("EPDPIND", param.getNom()); //$NON-NLS-1$
    Assert.assertEquals("NO", param.getValeur()); //$NON-NLS-1$
  }

  /**
   * Test the invocation for the stored procedure in STR_016_GetCustomerIdentity
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void testInvocationSTR014() throws Exception
  {
    // Request variables
    String msisdn = "33762112176"; //$NON-NLS-1$
    String pfi = "1109813900722"; //$NON-NLS-1$
    String imsi = "208209813900722"; //$NON-NLS-1$

    // Setup statement mock
    EasyMock.expect(_connection.prepareCall("{call PG_IWSRESSOURCES.P_006_GET_CUSTOMER_IDENTITY(?,?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    EasyMock.expectLastCall();

    _callableStatement.setString("pi_MSISDN", msisdn); //$NON-NLS-1$
    EasyMock.expectLastCall();
    _callableStatement.setString("pi_IMSI", imsi); //$NON-NLS-1$
    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.getString(RETOUR_RESULTAT)).andReturn("OK"); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString(RETOUR_CATEGORIE)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_DIAGNOSTIC)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_LIBELLE)).andReturn(null);

    EasyMock.expect(_callableStatement.getObject("po_RESULT")).andReturn(_resultSet); //$NON-NLS-1$

    EasyMock.expect(_resultSet.next()).andReturn(true);
    EasyMock.expect(_resultSet.getString("PFI")).andReturn(pfi); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getString("MSISDN")).andReturn(msisdn); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getString("NUMTEL")).andReturn(null); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getString("IMSI")).andReturn(imsi); //$NON-NLS-1$

    EasyMock.expect(_resultSet.next()).andReturn(false);

    PowerMock.replayAll();

    //Call connector
    ConnectorResponse<DonneesClient, Retour> res = _connector.getCustomerIdentity(null, msisdn, null);

    // Asserts
    Assert.assertNotNull(res._first);
    Assert.assertEquals(msisdn, res._first.getMsisdn());
    Assert.assertEquals(pfi, res._first.getPfi());
    Assert.assertEquals(imsi, res._first.getImsi());
    Assert.assertNull(res._first.getNumtel());

    assertEquals(res.getError().getResultat(), StringConstants.OK);
  }

  /**
   * Test the invocation for the stored procedure in STR_017_InsertUDCHEMSSDP
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void testInvocationSTR015() throws Exception
  {
    // Request variables
    List<AuditUDCHEMSSDP> donnees = new ArrayList<AuditUDCHEMSSDP>();

    String msisdn = "337621"; //$NON-NLS-1$
    String imsi = "208209813900722"; //$NON-NLS-1$

    for (int i = 0; i < 20; i++)
    {
      donnees.add(new AuditUDCHEMSSDP(msisdn + i, imsi, null, null));
    }

    // Setup statement mock
    PreparedStatement preparedStatement = PowerMock.createNiceMock(PreparedStatement.class);

    EasyMock.expect(_connection.prepareStatement("INSERT INTO AUDIT_UDC_HEMSSDP (PK_UDC_HEMSSDP, MSISDN, IMSI, NAM, AMSISDN) VALUES (SQ_UDC_HEMSSDP_01.NEXTVAL,?,?,?,?)")).andReturn(preparedStatement); //$NON-NLS-1$

    preparedStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    EasyMock.expectLastCall();

    int c = 0;
    for (int i = 0; i < 20; i++)
    {
      preparedStatement.setString(++c, msisdn + i);
      EasyMock.expectLastCall();
      preparedStatement.setString(++c, imsi);
      EasyMock.expectLastCall();
      preparedStatement.setString(++c, null);
      EasyMock.expectLastCall();
      preparedStatement.setString(++c, null);
      EasyMock.expectLastCall();
    }

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<Boolean, Retour> res = _connector.insertUDCHEMSSDP(null, donnees, 1000);

    // Asserts
    Assert.assertNotNull(res._first);
    Assert.assertTrue(res._first);
    Assert.assertEquals("OK", res._second.getResultat()); //$NON-NLS-1$

    AuditUDCHEMSSDP ob1 = new AuditUDCHEMSSDP(msisdn, imsi, "0", "3376212"); //$NON-NLS-1$ //$NON-NLS-2$
    AuditUDCHEMSSDP ob2 = new AuditUDCHEMSSDP(msisdn, imsi, "0", "3376212"); //$NON-NLS-1$ //$NON-NLS-2$

    Assert.assertTrue(ob1.equals(ob2));
  }

  /**
   * Test the invocation for the stored procedure in STR_018_InsertUDCHEMSPDP
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void testInvocationSTR016() throws Exception
  {
    // Request variables
    List<AuditUDCHEMSPDP> donnees = new ArrayList<AuditUDCHEMSPDP>();

    String msisdn = "337621"; //$NON-NLS-1$
    String imsi = "208209813900722"; //$NON-NLS-1$

    for (int i = 0; i < 20; i++)
    {
      donnees.add(new AuditUDCHEMSPDP(msisdn + i, imsi, null, null, null, null));
    }

    // Setup statement mock
    PreparedStatement preparedStatement = PowerMock.createNiceMock(PreparedStatement.class);

    EasyMock.expect(_connection.prepareStatement("INSERT INTO AUDIT_UDC_HEMSPDP (PK_UDC_HEMSPDP, MSISDN, IMSI, APNID, EQOSID, PDPID, EPDPIND) VALUES (SQ_UDC_HEMSPDP_01.NEXTVAL,?,?,?,?,?,?)")).andReturn(preparedStatement); //$NON-NLS-1$

    preparedStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    EasyMock.expectLastCall();

    int c = 0;
    for (int i = 0; i < 20; i++)
    {
      preparedStatement.setString(++c, msisdn + i);
      EasyMock.expectLastCall();
      preparedStatement.setString(++c, imsi);
      EasyMock.expectLastCall();
    }

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<Boolean, Retour> res = _connector.insertUDCHEMSPDP(null, donnees, 1000);

    // Asserts
    Assert.assertNotNull(res._first);
    Assert.assertTrue(res._first);
    Assert.assertEquals("OK", res._second.getResultat()); //$NON-NLS-1$
  }

  /**
   * Test the invocation for the stored procedure in STR_019_InsertUDCHEMSCMP
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void testInvocationSTR017() throws Exception
  {
    // Request variables
    List<AuditUDCHEMSCMP> donnees = new ArrayList<AuditUDCHEMSCMP>();

    String msisdn = "337621"; //$NON-NLS-1$

    for (int i = 0; i < 20; i++)
    {
      donnees.add(new AuditUDCHEMSCMP(msisdn + i, null));
    }

    // Setup statement mock
    PreparedStatement preparedStatement = PowerMock.createNiceMock(PreparedStatement.class);

    EasyMock.expect(_connection.prepareStatement("INSERT INTO AUDIT_UDC_HEMSCMP (MSISDN, EOICK) VALUES (?,?)")).andReturn(preparedStatement); //$NON-NLS-1$

    preparedStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    EasyMock.expectLastCall();

    int c = 0;
    for (int i = 0; i < 20; i++)
    {
      preparedStatement.setString(++c, msisdn + i);
      EasyMock.expectLastCall();
    }

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<Boolean, Retour> res = _connector.insertUDCHEMSCMP(null, donnees, 1000);

    // Asserts
    Assert.assertNotNull(res._first);
    Assert.assertTrue(res._first);
    Assert.assertEquals("OK", res._second.getResultat()); //$NON-NLS-1$
  }

  /**
   * Test the invocation for the stored procedure in STR_020_GetSTRHEMSSDP
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void testInvocationSTR018() throws Exception
  {
    // Request variables
    String imsi = "2"; //$NON-NLS-1$

    //Setup statement mock
    EasyMock.expect(_connection.prepareCall("{call PG_IWSRESSOURCES.P_011_GET_STR_HEMSSDP(?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    EasyMock.expectLastCall();

    _callableStatement.setString("pi_IMSI", imsi); //$NON-NLS-1$
    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.getString(RETOUR_RESULTAT)).andReturn("OK"); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString(RETOUR_CATEGORIE)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_DIAGNOSTIC)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_LIBELLE)).andReturn(null);

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<Boolean, Retour> res = _connector.getSTRHEMSSDP(null, imsi);

    // Asserts
    Assert.assertNotNull(res._first);
    Assert.assertTrue(res._first);
    Assert.assertEquals("OK", res._second.getResultat()); //$NON-NLS-1$
  }

  /**
   * Test the invocation for the stored procedure in P_014_GET_STR_HEMSPDP
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void testInvocationSTR020() throws Exception
  {
    // Request variables
    String imsi = "208209813919250"; //$NON-NLS-1$

    // Setup statement mock
    EasyMock.expect(_connection.prepareCall("{call PG_IWSRESSOURCES.P_014_GET_STR_HEMSPDP(?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    EasyMock.expectLastCall();

    _callableStatement.setString("pi_IMSI", imsi); //$NON-NLS-1$
    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.getString(RETOUR_RESULTAT)).andReturn("OK"); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString(RETOUR_CATEGORIE)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_DIAGNOSTIC)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_LIBELLE)).andReturn(null);

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<Boolean, Retour> res = _connector.getSTRHEMSPDP(null, imsi);

    // Asserts
    Assert.assertTrue(res._first);
    Assert.assertEquals("OK", res._second.getResultat()); //$NON-NLS-1$
  }

  /**
   * Test the invocation for the stored procedure in P_015_GET_STR_HEMSCMP
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void testInvocationSTR021() throws Exception
  {

    // Setup Statement mock
    EasyMock.expect(_connection.prepareCall("{call PG_IWSRESSOURCES.P_015_GET_STR_HEMSCMP(?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.getString(RETOUR_RESULTAT)).andReturn("OK"); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString(RETOUR_CATEGORIE)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_DIAGNOSTIC)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_LIBELLE)).andReturn(null);

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<Boolean, Retour> res = _connector.getSTRHEMSCMP(null);

    // Asserts
    Assert.assertTrue(res._first);
    Assert.assertEquals("OK", res._second.getResultat()); //$NON-NLS-1$
  }

  /**
   * Test the invocation for the stored procedure in P_018_GET_PFI_FROM_MSISDN
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void testInvocationSTR026() throws Exception
  {
    // Request variables
    String msisdn = "33762106916"; //$NON-NLS-1$

    // Setup statement mock
    EasyMock.expect(_connection.prepareCall("{call PG_IWSRESSOURCES.P_018_GET_PFI_FROM_MSISDN(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    PowerMock.expectLastCall();

    _callableStatement.setString("pi_MSISDN", msisdn); //$NON-NLS-1$
    PowerMock.expectLastCall();

    EasyMock.expect(_callableStatement.getString(RETOUR_RESULTAT)).andReturn("OK"); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString(RETOUR_CATEGORIE)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_DIAGNOSTIC)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_LIBELLE)).andReturn(null);

    EasyMock.expect(_callableStatement.getObject("po_RESULT")).andReturn(_resultSet); //$NON-NLS-1$

    EasyMock.expect(_resultSet.next()).andReturn(true);
    EasyMock.expect(_resultSet.getString("PFI")).andReturn("1109813900722"); //$NON-NLS-1$ //$NON-NLS-2$

    EasyMock.expect(_resultSet.next()).andReturn(false);

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<String, Retour> res = _connector.getPfiFromMsisdn(null, msisdn);

    // Asserts
    Assert.assertEquals("OK", res._second.getResultat()); //$NON-NLS-1$
    Assert.assertNotNull(res._first);
    Assert.assertEquals("1109813900722", res._first); //$NON-NLS-1$
  }

  /**
   * Test the invocation for the stored procedure in P_016_AUDIT_HEMSCMP
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void testInvocationSTR027() throws Exception
  {

    // Setup statement mock
    EasyMock.expect(_connection.prepareCall("{call PG_IWSRESSOURCES.P_016_AUDIT_HEMSCMP(?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC_UDC);
    PowerMock.expectLastCall();

    EasyMock.expect(_callableStatement.getString(RETOUR_RESULTAT)).andReturn("OK"); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString(RETOUR_CATEGORIE)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_DIAGNOSTIC)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_LIBELLE)).andReturn(null);

    EasyMock.expect(_callableStatement.getObject("po_RESULT")).andReturn(_resultSet); //$NON-NLS-1$

    EasyMock.expect(_resultSet.next()).andReturn(true);
    EasyMock.expect(_resultSet.getTimestamp("DATEEVENT")).andReturn(new Timestamp(0)); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getString("MSISDN_UDC")).andReturn("33762106916"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("MSISDN_NPBT")).andReturn("33762106917"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("EOICK_UDC")).andReturn("1"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("EOICK_NPBT")).andReturn("0"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("MESSAGE")).andReturn("msg"); //$NON-NLS-1$ //$NON-NLS-2$

    EasyMock.expect(_resultSet.next()).andReturn(false);

    IDataCallBack callbackMock = PowerMock.createMock(IDataCallBack.class);

    Capture<Object> capture = EasyMock.newCapture();
    EasyMock.expect(callbackMock.processData(EasyMock.capture(capture))).andReturn(DataCallBackReturn.STOP);

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<Integer, Retour> res = _connector.auditHEMSCMP(null, callbackMock);

    PowerMock.verifyAll();

    // Asserts
    Assert.assertEquals("OK", res._second.getResultat()); //$NON-NLS-1$
    Assert.assertNotNull(res._first);
    Assert.assertEquals(new Integer(1), res._first);

    ResultAuditHEMSCMP result = (ResultAuditHEMSCMP) capture.getValue();

    Assert.assertEquals(new Date(0), result.getDateEvent());
    Assert.assertEquals("33762106916", result.getMsisdnUDC()); //$NON-NLS-1$
    Assert.assertEquals("33762106917", result.getMsisdnNPBT()); //$NON-NLS-1$
    Assert.assertEquals("1", result.getEoickUDC()); //$NON-NLS-1$
    Assert.assertEquals("0", result.getEoickNPBT()); //$NON-NLS-1$
    Assert.assertEquals("msg", result.getMessage()); //$NON-NLS-1$
  }

  /**
   * Test the invocation for the stored procedure in P_016_AUDIT_HEMSCMP
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void testInvocationSTR027_KO() throws Exception
  {
    // SQLTimeoutException

    // Setup statement mock
    EasyMock.expect(_connection.prepareCall("{call PG_IWSRESSOURCES.P_016_AUDIT_HEMSCMP(?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC_UDC);
    PowerMock.expectLastCall();

    _callableStatement.execute();
    PowerMock.expectLastCall().andThrow(new SQLTimeoutException());

    IDataCallBack callbackMock = PowerMock.createMock(IDataCallBack.class);

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<Integer, Retour> res = _connector.auditHEMSCMP(null, callbackMock);

    PowerMock.verifyAll();

    // Asserts
    Assert.assertEquals("KO", res._second.getResultat()); //$NON-NLS-1$
    Assert.assertNull(res._first);

    // Reset Mocks
    setup();

    // PoolExhaustedException

    // Setup statement mock
    EasyMock.expect(_connection.prepareCall("{call PG_IWSRESSOURCES.P_016_AUDIT_HEMSCMP(?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC_UDC);
    PowerMock.expectLastCall();

    _callableStatement.execute();
    PowerMock.expectLastCall().andThrow(new PoolExhaustedException());

    callbackMock = PowerMock.createMock(IDataCallBack.class);

    PowerMock.replayAll();

    // Call connector
    res = _connector.auditHEMSCMP(null, callbackMock);

    PowerMock.verifyAll();

    // Asserts
    Assert.assertEquals("KO", res._second.getResultat()); //$NON-NLS-1$
    Assert.assertNull(res._first);

    // Reset Mocks
    setup();

    // SQLRecoverableException

    // Setup statement mock
    EasyMock.expect(_connection.prepareCall("{call PG_IWSRESSOURCES.P_016_AUDIT_HEMSCMP(?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC_UDC);
    PowerMock.expectLastCall();

    _callableStatement.execute();
    PowerMock.expectLastCall().andThrow(new SQLRecoverableException());

    callbackMock = PowerMock.createMock(IDataCallBack.class);

    PowerMock.replayAll();

    // Call connector
    res = _connector.auditHEMSCMP(null, callbackMock);

    PowerMock.verifyAll();

    // Asserts
    Assert.assertEquals("KO", res._second.getResultat()); //$NON-NLS-1$
    Assert.assertNull(res._first);

  }

  /**
   * Test the invocation for the stored procedure in PG_IWSRESSOURCES.P_012_AUDIT_HEMSSDP
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void testInvocationSTR028() throws Exception
  {

    // Setup statement mock
    EasyMock.expect(_connection.prepareCall("{call PG_IWSRESSOURCES.P_012_AUDIT_HEMSSDP(?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC_UDC);
    PowerMock.expectLastCall();

    EasyMock.expect(_callableStatement.getString(RETOUR_RESULTAT)).andReturn("OK"); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString(RETOUR_CATEGORIE)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_DIAGNOSTIC)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_LIBELLE)).andReturn(null);

    EasyMock.expect(_callableStatement.getObject("po_RESULT")).andReturn(_resultSet); //$NON-NLS-1$

    EasyMock.expect(_resultSet.next()).andReturn(true);
    EasyMock.expect(_resultSet.getTimestamp("DATEEVENT")).andReturn(new Timestamp(0)); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getString("MSISDN_UDC")).andReturn("33762106916"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("MSISDN_NPBT")).andReturn("33762106917"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("IMSI_UDC")).andReturn("208209813919250"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("IMSI_NPBT")).andReturn("208209813919251"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("NAM_UDC")).andReturn("1"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("NAM_NPBT")).andReturn("0"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("AMSISDN_UDC")).andReturn("33762106918"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("AMSISDN_NPBT")).andReturn("33762106919"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("MESSAGE")).andReturn("msg"); //$NON-NLS-1$ //$NON-NLS-2$

    EasyMock.expect(_resultSet.next()).andReturn(false);

    IDataCallBack callbackMock = PowerMock.createMock(IDataCallBack.class);

    Capture<Object> capture = EasyMock.newCapture();
    EasyMock.expect(callbackMock.processData(EasyMock.capture(capture))).andReturn(DataCallBackReturn.STOP);

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<Integer, Retour> res = _connector.auditHEMSSDP(null, callbackMock);

    PowerMock.verifyAll();

    // Asserts
    Assert.assertEquals("OK", res._second.getResultat()); //$NON-NLS-1$
    Assert.assertNotNull(res._first);
    Assert.assertEquals(new Integer(1), res._first);

    ResultAuditHEMSSDP result = (ResultAuditHEMSSDP) capture.getValue();

    Assert.assertEquals(new Date(0), result.getDateEvent());
    Assert.assertEquals("33762106916", result.getMsisdnUDC()); //$NON-NLS-1$
    Assert.assertEquals("33762106917", result.getMsisdnNPBT()); //$NON-NLS-1$
    Assert.assertEquals("208209813919250", result.getImsiUDC()); //$NON-NLS-1$
    Assert.assertEquals("208209813919251", result.getImsiNPBT()); //$NON-NLS-1$
    Assert.assertEquals("1", result.getNamUDC()); //$NON-NLS-1$
    Assert.assertEquals("0", result.getNamNPBT()); //$NON-NLS-1$
    Assert.assertEquals("33762106918", result.getAmsisdnUDC()); //$NON-NLS-1$
    Assert.assertEquals("33762106919", result.getAmsisdnNPBT()); //$NON-NLS-1$
    Assert.assertEquals("msg", result.getMessage()); //$NON-NLS-1$
  }

  /**
   * Test the invocation for the stored procedure in PG_IWSRESSOURCES.P_012_AUDIT_HEMSSDP
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void testInvocationSTR028_KO() throws Exception
  {
    // SQLTimeoutException

    // Setup statement mock
    EasyMock.expect(_connection.prepareCall("{call PG_IWSRESSOURCES.P_012_AUDIT_HEMSSDP(?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC_UDC);
    PowerMock.expectLastCall();

    _callableStatement.execute();
    PowerMock.expectLastCall().andThrow(new SQLTimeoutException());

    IDataCallBack callbackMock = PowerMock.createMock(IDataCallBack.class);

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<Integer, Retour> res = _connector.auditHEMSSDP(null, callbackMock);

    PowerMock.verifyAll();

    // Asserts
    Assert.assertEquals("KO", res._second.getResultat()); //$NON-NLS-1$
    Assert.assertNull(res._first);

    // Reset Mocks
    setup();

    // PoolExhaustedException

    // Setup statement mock
    EasyMock.expect(_connection.prepareCall("{call PG_IWSRESSOURCES.P_012_AUDIT_HEMSSDP(?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC_UDC);
    PowerMock.expectLastCall();

    _callableStatement.execute();
    PowerMock.expectLastCall().andThrow(new PoolExhaustedException());

    callbackMock = PowerMock.createMock(IDataCallBack.class);

    PowerMock.replayAll();

    // Call connector
    res = _connector.auditHEMSSDP(null, callbackMock);

    PowerMock.verifyAll();

    // Asserts
    Assert.assertEquals("KO", res._second.getResultat()); //$NON-NLS-1$
    Assert.assertNull(res._first);

    // Reset Mocks
    setup();

    // SQLRecoverableException

    // Setup statement mock
    EasyMock.expect(_connection.prepareCall("{call PG_IWSRESSOURCES.P_012_AUDIT_HEMSSDP(?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC_UDC);
    PowerMock.expectLastCall();

    _callableStatement.execute();
    PowerMock.expectLastCall().andThrow(new SQLRecoverableException());

    callbackMock = PowerMock.createMock(IDataCallBack.class);

    PowerMock.replayAll();

    // Call connector
    res = _connector.auditHEMSSDP(null, callbackMock);

    PowerMock.verifyAll();

    // Asserts
    Assert.assertEquals("KO", res._second.getResultat()); //$NON-NLS-1$
    Assert.assertNull(res._first);
  }

  /**
   * Test the invocation for the stored procedure in PG_IWSRESSOURCES.P_017_AUDIT_HEMSPDP
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void testInvocationSTR029() throws Exception
  {

    // Setup statement mock
    EasyMock.expect(_connection.prepareCall("{call PG_IWSRESSOURCES.P_017_AUDIT_HEMSPDP(?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC_UDC);
    PowerMock.expectLastCall();

    EasyMock.expect(_callableStatement.getString(RETOUR_RESULTAT)).andReturn("OK"); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString(RETOUR_CATEGORIE)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_DIAGNOSTIC)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_LIBELLE)).andReturn(null);

    EasyMock.expect(_callableStatement.getObject("po_RESULT")).andReturn(_resultSet); //$NON-NLS-1$

    EasyMock.expect(_resultSet.next()).andReturn(true);
    EasyMock.expect(_resultSet.getTimestamp("DATEEVENT")).andReturn(new Timestamp(0)); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getString("MSISDN_UDC")).andReturn("33762106916"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("MSISDN_NPBT")).andReturn("33762106917"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("IMSI_UDC")).andReturn("208209813919250"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("IMSI_NPBT")).andReturn("208209813919251"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("APNID_UDC")).andReturn("51243"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("APNID_NPBT")).andReturn("51244"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("PDPID_UDC")).andReturn("51245"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("PDPID_NPBT")).andReturn("51246"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("EPDPIND_UDC")).andReturn("1"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("EPDPIND_NPBT")).andReturn("2"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("MESSAGE")).andReturn("msg"); //$NON-NLS-1$ //$NON-NLS-2$

    EasyMock.expect(_resultSet.next()).andReturn(false);

    IDataCallBack callbackMock = PowerMock.createMock(IDataCallBack.class);

    Capture<Object> capture = EasyMock.newCapture();
    EasyMock.expect(callbackMock.processData(EasyMock.capture(capture))).andReturn(DataCallBackReturn.STOP);

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<Integer, Retour> res = _connector.auditHEMSPDP(null, callbackMock);

    PowerMock.verifyAll();

    // Asserts
    Assert.assertEquals("OK", res._second.getResultat()); //$NON-NLS-1$
    Assert.assertNotNull(res._first);
    Assert.assertEquals(new Integer(1), res._first);

    ResultAuditHEMSPDP result = (ResultAuditHEMSPDP) capture.getValue();

    Assert.assertEquals(new Date(0), result.getDateEvent());
    Assert.assertEquals("33762106916", result.getMsisdnUDC()); //$NON-NLS-1$
    Assert.assertEquals("33762106917", result.getMsisdnNPBT()); //$NON-NLS-1$
    Assert.assertEquals("208209813919250", result.getImsiUDC()); //$NON-NLS-1$
    Assert.assertEquals("208209813919251", result.getImsiNPBT()); //$NON-NLS-1$
    Assert.assertEquals("51243", result.getApnidUDC()); //$NON-NLS-1$
    Assert.assertEquals("51244", result.getApnidNPBT()); //$NON-NLS-1$
    Assert.assertEquals("51245", result.getPdpidUDC()); //$NON-NLS-1$
    Assert.assertEquals("51246", result.getPdpidNPBT()); //$NON-NLS-1$
    Assert.assertEquals("1", result.getEpdpindUDC()); //$NON-NLS-1$
    Assert.assertEquals("2", result.getEpdpindNPBT()); //$NON-NLS-1$
    Assert.assertEquals("msg", result.getMessage()); //$NON-NLS-1$
  }

  /**
   * Test the invocation for the stored procedure in PG_IWSRESSOURCES.P_017_AUDIT_HEMSPDP
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void testInvocationSTR029_KO() throws Exception
  {
    // SQLTimeoutException

    // Setup statement mock
    EasyMock.expect(_connection.prepareCall("{call PG_IWSRESSOURCES.P_017_AUDIT_HEMSPDP(?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC_UDC);
    PowerMock.expectLastCall();

    _callableStatement.execute();
    PowerMock.expectLastCall().andThrow(new SQLTimeoutException());

    IDataCallBack callbackMock = PowerMock.createMock(IDataCallBack.class);

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<Integer, Retour> res = _connector.auditHEMSPDP(null, callbackMock);

    PowerMock.verifyAll();

    // Asserts
    Assert.assertEquals("KO", res._second.getResultat()); //$NON-NLS-1$
    Assert.assertNull(res._first);

    // Reset Mocks
    setup();

    // PoolExhaustedException

    // Setup statement mock
    EasyMock.expect(_connection.prepareCall("{call PG_IWSRESSOURCES.P_017_AUDIT_HEMSPDP(?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC_UDC);
    PowerMock.expectLastCall();

    _callableStatement.execute();
    PowerMock.expectLastCall().andThrow(new PoolExhaustedException());

    callbackMock = PowerMock.createMock(IDataCallBack.class);

    PowerMock.replayAll();

    // Call connector
    res = _connector.auditHEMSPDP(null, callbackMock);

    PowerMock.verifyAll();

    // Asserts
    Assert.assertEquals("KO", res._second.getResultat()); //$NON-NLS-1$
    Assert.assertNull(res._first);

    // Reset Mocks
    setup();

    // SQLRecoverableException

    // Setup statement mock
    EasyMock.expect(_connection.prepareCall("{call PG_IWSRESSOURCES.P_017_AUDIT_HEMSPDP(?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC_UDC);
    PowerMock.expectLastCall();

    _callableStatement.execute();
    PowerMock.expectLastCall().andThrow(new SQLRecoverableException());

    callbackMock = PowerMock.createMock(IDataCallBack.class);

    PowerMock.replayAll();

    // Call connector
    res = _connector.auditHEMSPDP(null, callbackMock);

    PowerMock.verifyAll();

    // Asserts
    Assert.assertEquals("KO", res._second.getResultat()); //$NON-NLS-1$
    Assert.assertNull(res._first);
  }

  /**
   * Test the invocation for the stored procedure in P_015_GET_STR_HEMSCMP
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void testInvocationSTR030() throws Exception
  {
    List<InfoProfil> result = new ArrayList<InfoProfil>();

    // Setup Statement mock
    EasyMock.expect(_connection.prepareCall("{call PG_REPORTING_GDS.PR_EXT_PROFILS_PIRELLI(?)}")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.getString(RETOUR_RESULTAT)).andReturn("OK"); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString(RETOUR_CATEGORIE)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_DIAGNOSTIC)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_LIBELLE)).andReturn(null);

    EasyMock.expect(_callableStatement.getObject("po_RESULT")).andReturn(_resultSet); //$NON-NLS-1$

    EasyMock.expect(_resultSet.next()).andReturn(true);
    EasyMock.expect(_resultSet.getString(1)).andReturn("ligneMarche"); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getString(2)).andReturn("nomeProfile"); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getInt(3)).andReturn(1);

    InfoProfil infoProfil = new InfoProfil("ligneMarche", "nomeProfile", 1); //$NON-NLS-1$ //$NON-NLS-2$
    result.add(infoProfil);

    EasyMock.expect(_resultSet.next()).andReturn(false);

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<List<InfoProfil>, Retour> res = _connector.getProfilsPirelliParLM(new Tracabilite());

    // Asserts
    Assert.assertEquals(res._first.get(0).getLigneMarche(), result.get(0).getLigneMarche());
    Assert.assertEquals(res._first.get(0).getNomProfil(), result.get(0).getNomProfil());
    Assert.assertEquals(res._first.get(0).getNombre(), result.get(0).getNombre());
    Assert.assertEquals("OK", res._second.getResultat()); //$NON-NLS-1$
  }

  /**
   * Test the invocation for the stored procedure in PR_EXT_PROFILS_PIRELLI With exception
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void testInvocationSTR030_KO() throws Exception
  {
    // SQLTimeoutException

    // Setup statement mock
    EasyMock.expect(_connection.prepareCall("{call PG_REPORTING_GDS.PR_EXT_PROFILS_PIRELLI(?)}")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    PowerMock.expectLastCall();

    _callableStatement.execute();
    PowerMock.expectLastCall().andThrow(new SQLTimeoutException());

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<List<InfoProfil>, Retour> res = _connector.getProfilsPirelliParLM(new Tracabilite());

    PowerMock.verifyAll();

    // Asserts
    Assert.assertEquals("KO", res._second.getResultat()); //$NON-NLS-1$
    Assert.assertNull(res._first);

    // Reset Mocks
    setup();

    // PoolExhaustedException

    // Setup statement mock
    EasyMock.expect(_connection.prepareCall("{call PG_REPORTING_GDS.PR_EXT_PROFILS_PIRELLI(?)}")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    PowerMock.expectLastCall();

    _callableStatement.execute();
    PowerMock.expectLastCall().andThrow(new PoolExhaustedException());

    //callbackMock = PowerMock.createMock(IDataCallBack.class);

    PowerMock.replayAll();

    // Call connector
    res = _connector.getProfilsPirelliParLM(new Tracabilite());

    PowerMock.verifyAll();

    // Asserts
    Assert.assertEquals("KO", res._second.getResultat()); //$NON-NLS-1$
    Assert.assertNull(res._first);

    // Reset Mocks
    setup();

    // SQLRecoverableException

    // Setup statement mock
    EasyMock.expect(_connection.prepareCall("{call PG_REPORTING_GDS.PR_EXT_PROFILS_PIRELLI(?)}")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    PowerMock.expectLastCall();

    _callableStatement.execute();
    PowerMock.expectLastCall().andThrow(new SQLRecoverableException());

    //callbackMock = PowerMock.createMock(IDataCallBack.class);

    PowerMock.replayAll();

    // Call connector
    res = _connector.getProfilsPirelliParLM(new Tracabilite());

    PowerMock.verifyAll();

    // Asserts
    Assert.assertEquals("KO", res._second.getResultat()); //$NON-NLS-1$
    Assert.assertNull(res._first);

    // Reset Mocks
    setup();

    // SQLException

    // Setup statement mock
    EasyMock.expect(_connection.prepareCall("{call PG_REPORTING_GDS.PR_EXT_PROFILS_PIRELLI(?)}")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    PowerMock.expectLastCall();

    _callableStatement.execute();
    PowerMock.expectLastCall().andThrow(new SQLException());

    PowerMock.replayAll();

    // Call connector
    try
    {
      res = _connector.getProfilsPirelliParLM(new Tracabilite());
    }
    catch (RavelException exception)
    {
      Assert.assertTrue(exception.getMessage().startsWith("Technical Exception in STRConnector during")); //$NON-NLS-1$
    }

    PowerMock.verifyAll();

    // Asserts
    Assert.assertEquals("KO", res._second.getResultat()); //$NON-NLS-1$
    Assert.assertNull(res._first);

  }

  /**
   * Test the invocation for the stored procedure in P_015_GET_STR_HEMSCMP
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void testInvocationSTR031() throws Exception
  {
    List<InfoProfil> result = new ArrayList<InfoProfil>();

    // Setup Statement mock
    EasyMock.expect(_connection.prepareCall("{call PG_REPORTING_GDS.PR_EXT_PROFILS_THEPOLICE(?)}")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.getString(RETOUR_RESULTAT)).andReturn("OK"); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString(RETOUR_CATEGORIE)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_DIAGNOSTIC)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_LIBELLE)).andReturn(null);

    EasyMock.expect(_callableStatement.getObject("po_RESULT")).andReturn(_resultSet); //$NON-NLS-1$

    EasyMock.expect(_resultSet.next()).andReturn(true);
    EasyMock.expect(_resultSet.getString(1)).andReturn("ligneMarche"); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getString(2)).andReturn("nomeProfile"); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getInt(3)).andReturn(1);

    InfoProfil infoProfil = new InfoProfil("ligneMarche", "nomeProfile", 1); //$NON-NLS-1$ //$NON-NLS-2$
    result.add(infoProfil);

    EasyMock.expect(_resultSet.next()).andReturn(false);

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<List<InfoProfil>, Retour> res = _connector.getProfilsThePoliceParLM(new Tracabilite());

    // Asserts
    Assert.assertEquals(res._first.get(0).getLigneMarche(), result.get(0).getLigneMarche());
    Assert.assertEquals(res._first.get(0).getNomProfil(), result.get(0).getNomProfil());
    Assert.assertEquals(res._first.get(0).getNombre(), result.get(0).getNombre());
    Assert.assertEquals("OK", res._second.getResultat()); //$NON-NLS-1$
  }

  /**
   * Test the invocation for the stored procedure in PR_EXT_PROFILS_THEPOLICE With exception
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void testInvocationSTR031_KO() throws Exception
  {
    // SQLTimeoutException

    // Setup statement mock
    EasyMock.expect(_connection.prepareCall("{call PG_REPORTING_GDS.PR_EXT_PROFILS_THEPOLICE(?)}")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    PowerMock.expectLastCall();

    _callableStatement.execute();
    PowerMock.expectLastCall().andThrow(new SQLTimeoutException());

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<List<InfoProfil>, Retour> res = _connector.getProfilsThePoliceParLM(new Tracabilite());

    PowerMock.verifyAll();

    // Asserts
    Assert.assertEquals("KO", res._second.getResultat()); //$NON-NLS-1$
    Assert.assertNull(res._first);

    // Reset Mocks
    setup();

    // PoolExhaustedException

    // Setup statement mock
    EasyMock.expect(_connection.prepareCall("{call PG_REPORTING_GDS.PR_EXT_PROFILS_THEPOLICE(?)}")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    PowerMock.expectLastCall();

    _callableStatement.execute();
    PowerMock.expectLastCall().andThrow(new PoolExhaustedException());

    //callbackMock = PowerMock.createMock(IDataCallBack.class);

    PowerMock.replayAll();

    // Call connector
    res = _connector.getProfilsThePoliceParLM(new Tracabilite());

    PowerMock.verifyAll();

    // Asserts
    Assert.assertEquals("KO", res._second.getResultat()); //$NON-NLS-1$
    Assert.assertNull(res._first);

    // Reset Mocks
    setup();

    // SQLRecoverableException

    // Setup statement mock
    EasyMock.expect(_connection.prepareCall("{call PG_REPORTING_GDS.PR_EXT_PROFILS_THEPOLICE(?)}")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    PowerMock.expectLastCall();

    _callableStatement.execute();
    PowerMock.expectLastCall().andThrow(new SQLRecoverableException());

    //callbackMock = PowerMock.createMock(IDataCallBack.class);

    PowerMock.replayAll();

    // Call connector
    res = _connector.getProfilsThePoliceParLM(new Tracabilite());

    PowerMock.verifyAll();

    // Asserts
    Assert.assertEquals("KO", res._second.getResultat()); //$NON-NLS-1$
    Assert.assertNull(res._first);

    // Reset Mocks
    setup();

    // SQLException

    // Setup statement mock
    EasyMock.expect(_connection.prepareCall("{call PG_REPORTING_GDS.PR_EXT_PROFILS_THEPOLICE(?)}")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    PowerMock.expectLastCall();

    _callableStatement.execute();
    PowerMock.expectLastCall().andThrow(new SQLException());

    //callbackMock = PowerMock.createMock(IDataCallBack.class);

    PowerMock.replayAll();

    // Call connector
    try
    {
      res = _connector.getProfilsThePoliceParLM(new Tracabilite());
    }
    catch (RavelException exception)
    {
      Assert.assertTrue(exception.getMessage().startsWith("Technical Exception in STRConnector during")); //$NON-NLS-1$
    }

    PowerMock.verifyAll();

    // Asserts
    Assert.assertEquals("KO", res._second.getResultat()); //$NON-NLS-1$
    Assert.assertNull(res._first);

  }

  /**
   * Test the invocation for the stored procedure in GET_NOCONTRAT_FROM_MSISDN
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void testInvocationSTR037() throws Exception
  {
    // Request variables

    String noTelephone = "33762111481"; //$NON-NLS-1$

    // Setup statement mock

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.GET_NOCONTRAT_FROM_MSISDN(?,?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    EasyMock.expectLastCall();

    _callableStatement.setString("pi_MSISDN", noTelephone); //$NON-NLS-1$
    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.getString("po_NOCONTRAT")).andReturn("1109813901431"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_callableStatement.getString("po_partitionSic")).andReturn("GP"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_callableStatement.getString(RETOUR_RESULTAT)).andReturn("OK"); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString(RETOUR_CATEGORIE)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_DIAGNOSTIC)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_LIBELLE)).andReturn(null);

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<ResultContratEtPartition, Retour> res = _connector.recupererNoContratParNoTelephone(null, noTelephone);

    // Asserts
    assertEquals(res._first.getNumContrat(), "1109813901431"); //$NON-NLS-1$
    assertEquals(res._first.getPartition(), "GP"); //$NON-NLS-1$
    assertEquals(res.getError().getResultat(), StringConstants.OK);

  }

  /**
   * Test the invocation for the stored procedure in GET_NOCONTRAT_FROM_MSISDN With exception
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void testInvocationSTR037_KO() throws Exception
  {

    // Request variables

    String noTelephone = "33762111481"; //$NON-NLS-1$

    // SQLTimeoutException

    // Setup statement mock
    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.GET_NOCONTRAT_FROM_MSISDN(?,?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    PowerMock.expectLastCall();

    _callableStatement.execute();
    PowerMock.expectLastCall().andThrow(new SQLTimeoutException());

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<ResultContratEtPartition, Retour> res = _connector.recupererNoContratParNoTelephone(null, noTelephone);

    PowerMock.verifyAll();

    // Asserts
    Assert.assertEquals("KO", res._second.getResultat()); //$NON-NLS-1$
    Assert.assertNull(res._first);

    // Reset Mocks
    setup();

    // PoolExhaustedException

    // Setup statement mock
    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.GET_NOCONTRAT_FROM_MSISDN(?,?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    PowerMock.expectLastCall();

    _callableStatement.execute();
    PowerMock.expectLastCall().andThrow(new PoolExhaustedException());

    //callbackMock = PowerMock.createMock(IDataCallBack.class);

    PowerMock.replayAll();

    // Call connector
    res = _connector.recupererNoContratParNoTelephone(null, noTelephone);

    PowerMock.verifyAll();

    // Asserts
    Assert.assertEquals("KO", res._second.getResultat()); //$NON-NLS-1$
    Assert.assertNull(res._first);

    // Reset Mocks
    setup();

    // SQLRecoverableException

    // Setup statement mock
    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.GET_NOCONTRAT_FROM_MSISDN(?,?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    PowerMock.expectLastCall();

    _callableStatement.execute();
    PowerMock.expectLastCall().andThrow(new SQLRecoverableException());

    //callbackMock = PowerMock.createMock(IDataCallBack.class);

    PowerMock.replayAll();

    // Call connector
    res = _connector.recupererNoContratParNoTelephone(null, noTelephone);

    PowerMock.verifyAll();

    // Asserts
    Assert.assertEquals("KO", res._second.getResultat()); //$NON-NLS-1$
    Assert.assertNull(res._first);

    // Reset Mocks
    setup();

    // SQLException

    // Setup statement mock
    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.GET_NOCONTRAT_FROM_MSISDN(?,?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    PowerMock.expectLastCall();

    _callableStatement.execute();
    PowerMock.expectLastCall().andThrow(new SQLException());

    //callbackMock = PowerMock.createMock(IDataCallBack.class);

    PowerMock.replayAll();

    // Call connector
    try
    {
      res = _connector.recupererNoContratParNoTelephone(null, noTelephone);
    }
    catch (RavelException exception)
    {
      Assert.assertTrue(exception.getMessage().startsWith("Technical Exception in STRConnector during")); //$NON-NLS-1$
    }

    PowerMock.verifyAll();

    // Asserts
    Assert.assertEquals("KO", res._second.getResultat()); //$NON-NLS-1$
    Assert.assertNull(res._first);

  }

  /**
   * Test the invocation for the stored procedure in GET_NOCONTRAT_FROM_MSISDN when return is Null
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void testInvocationSTR037_Null() throws Exception
  {
    // Request variables

    String noTelephone = "33762111481"; //$NON-NLS-1$

    // Setup statement mock

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.GET_NOCONTRAT_FROM_MSISDN(?,?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    EasyMock.expectLastCall();

    _callableStatement.setString("pi_MSISDN", noTelephone); //$NON-NLS-1$
    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.getString("po_NOCONTRAT")).andReturn(null); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString("po_partitionSic")).andReturn(null); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString(RETOUR_RESULTAT)).andReturn("OK"); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString(RETOUR_CATEGORIE)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_DIAGNOSTIC)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_LIBELLE)).andReturn(null);

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<ResultContratEtPartition, Retour> res = _connector.recupererNoContratParNoTelephone(null, noTelephone);

    // Asserts
    assertEquals(res._first.getNumContrat(), null);
    assertEquals(res._first.getPartition(), null);
    assertEquals(res.getError().getResultat(), StringConstants.OK);

  }

  /**
   * Test the invocation for the stored procedure in GET_TYPE_VMS_FROM_MSISDN
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void testInvocationSTR038() throws Exception
  {
    // Request variables

    String noTelephone = "33762111481"; //$NON-NLS-1$

    // Setup statement mock

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.GET_TYPE_VMS_FROM_MSISDN(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    EasyMock.expectLastCall();

    _callableStatement.setString("pi_MSISDN", noTelephone); //$NON-NLS-1$
    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.getString("po_TYPEPFS")).andReturn("CVM"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_callableStatement.getString(RETOUR_RESULTAT)).andReturn("OK"); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString(RETOUR_CATEGORIE)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_DIAGNOSTIC)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_LIBELLE)).andReturn(null);

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<String, Retour> res = _connector.recupererTypeVms(null, noTelephone);

    // Asserts
    assertEquals(res._first, "CVM"); //$NON-NLS-1$
    assertEquals(res.getError().getResultat(), StringConstants.OK);

  }

  /**
   * Test the invocation for the stored procedure in GET_TYPE_VMS_FROM_MSISDN With exception
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void testInvocationSTR038_KO() throws Exception
  {

    // Request variables

    String noTelephone = "33762111481"; //$NON-NLS-1$

    // SQLTimeoutException

    // Setup statement mock
    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.GET_TYPE_VMS_FROM_MSISDN(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    PowerMock.expectLastCall();

    _callableStatement.execute();
    PowerMock.expectLastCall().andThrow(new SQLTimeoutException());

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<String, Retour> res = _connector.recupererTypeVms(null, noTelephone);

    PowerMock.verifyAll();

    // Asserts
    Assert.assertEquals("KO", res._second.getResultat()); //$NON-NLS-1$
    Assert.assertNull(res._first);

    // Reset Mocks
    setup();

    // PoolExhaustedException

    // Setup statement mock
    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.GET_TYPE_VMS_FROM_MSISDN(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    PowerMock.expectLastCall();

    _callableStatement.execute();
    PowerMock.expectLastCall().andThrow(new PoolExhaustedException());

    //callbackMock = PowerMock.createMock(IDataCallBack.class);

    PowerMock.replayAll();

    // Call connector
    res = _connector.recupererTypeVms(null, noTelephone);

    PowerMock.verifyAll();

    // Asserts
    Assert.assertEquals("KO", res._second.getResultat()); //$NON-NLS-1$
    Assert.assertNull(res._first);

    // Reset Mocks
    setup();

    // SQLRecoverableException

    // Setup statement mock
    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.GET_TYPE_VMS_FROM_MSISDN(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    PowerMock.expectLastCall();

    _callableStatement.execute();
    PowerMock.expectLastCall().andThrow(new SQLRecoverableException());

    //callbackMock = PowerMock.createMock(IDataCallBack.class);

    PowerMock.replayAll();

    // Call connector
    res = _connector.recupererTypeVms(null, noTelephone);

    PowerMock.verifyAll();

    // Asserts
    Assert.assertEquals("KO", res._second.getResultat()); //$NON-NLS-1$
    Assert.assertNull(res._first);

    // Reset Mocks
    setup();

    // SQLException

    // Setup statement mock
    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.GET_TYPE_VMS_FROM_MSISDN(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    PowerMock.expectLastCall();

    _callableStatement.execute();
    PowerMock.expectLastCall().andThrow(new SQLException());

    //callbackMock = PowerMock.createMock(IDataCallBack.class);

    PowerMock.replayAll();

    // Call connector
    try
    {
      res = _connector.recupererTypeVms(null, noTelephone);
    }
    catch (RavelException exception)
    {
      Assert.assertTrue(exception.getMessage().startsWith("Technical Exception in STRConnector during")); //$NON-NLS-1$
    }

    PowerMock.verifyAll();

    // Asserts
    Assert.assertEquals("KO", res._second.getResultat()); //$NON-NLS-1$
    Assert.assertNull(res._first);

  }

  /**
   * Test the invocation for the stored procedure in GET_TYPE_VMS_FROM_MSISDN when return is Null
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void testInvocationSTR038_Null() throws Exception
  {
    // Request variables

    String noTelephone = "33762111481"; //$NON-NLS-1$

    // Setup statement mock

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.GET_TYPE_VMS_FROM_MSISDN(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    EasyMock.expectLastCall();

    _callableStatement.setString("pi_MSISDN", noTelephone); //$NON-NLS-1$
    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.getString("po_TYPEVMS")).andReturn(null); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString(RETOUR_RESULTAT)).andReturn("OK"); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString(RETOUR_CATEGORIE)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_DIAGNOSTIC)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_LIBELLE)).andReturn(null);

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<String, Retour> res = _connector.recupererTypeVms(null, noTelephone);

    // Asserts
    assertEquals(res._first, null);
    assertEquals(res.getError().getResultat(), StringConstants.OK);

  }

  /**
   * Test the invocation for the stored procedure in STR_113_CHECK_PARPNTACC_FromVP_False
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void testInvocationSTR113_False() throws Exception
  {
    // Request variables
    String imsi = "3"; //$NON-NLS-1$

    // Setup statement mock
    EasyMock.expect(_connection.prepareCall("{call PG_IWSRESSOURCES.P_013_CHECK_PARPNTACC_FromVP(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    PowerMock.expectLastCall();

    _callableStatement.setString("pi_IMSI", imsi); //$NON-NLS-1$
    PowerMock.expectLastCall();

    EasyMock.expect(_callableStatement.getString(RETOUR_RESULTAT)).andReturn("OK"); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString(RETOUR_CATEGORIE)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_DIAGNOSTIC)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_LIBELLE)).andReturn(null);

    EasyMock.expect(_callableStatement.getObject("po_RESULT")).andReturn(Boolean.FALSE); //$NON-NLS-1$

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<Boolean, Retour> res = _connector.checkPARPNTACCFromVP(null, imsi);

    // Asserts
    Assert.assertFalse(res._first);
  }

  /**
   * Test the invocation for the stored procedure in STR_113_CHECK_PARPNTACC_FromVP
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void testInvocationSTR113_KO() throws Exception
  {
    // SQLTimeoutException

    // Request variables
    String imsi = "208209813919250"; //$NON-NLS-1$

    // Setup statement mock
    EasyMock.expect(_connection.prepareCall("{call PG_IWSRESSOURCES.P_013_CHECK_PARPNTACC_FromVP(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    PowerMock.expectLastCall();

    _callableStatement.execute();
    PowerMock.expectLastCall().andThrow(new SQLTimeoutException());

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<Boolean, Retour> res = _connector.checkPARPNTACCFromVP(null, imsi);

    // Asserts
    Assert.assertEquals("KO", res._second.getResultat()); //$NON-NLS-1$
    Assert.assertNull(res._first);

    // Reset Mocks
    setup();

    // PoolExhaustedException

    // Setup statement mock
    EasyMock.expect(_connection.prepareCall("{call PG_IWSRESSOURCES.P_013_CHECK_PARPNTACC_FromVP(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    PowerMock.expectLastCall();

    _callableStatement.execute();
    PowerMock.expectLastCall().andThrow(new PoolExhaustedException());

    PowerMock.replayAll();

    // Call connector
    res = _connector.checkPARPNTACCFromVP(null, imsi);

    // Asserts
    Assert.assertEquals("KO", res._second.getResultat()); //$NON-NLS-1$
    Assert.assertNull(res._first);

    // Reset Mocks
    setup();

    // SQLRecoverableException

    // Setup statement mock
    EasyMock.expect(_connection.prepareCall("{call PG_IWSRESSOURCES.P_013_CHECK_PARPNTACC_FromVP(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    PowerMock.expectLastCall();

    _callableStatement.execute();
    PowerMock.expectLastCall().andThrow(new SQLRecoverableException());

    PowerMock.replayAll();

    // Call connector
    res = _connector.checkPARPNTACCFromVP(null, imsi);

    // Asserts
    Assert.assertEquals("KO", res._second.getResultat()); //$NON-NLS-1$
    Assert.assertNull(res._first);
  }

  /**
   * Test the invocation for the stored procedure in STR_113_CHECK_PARPNTACC_FromVP_OK
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void testInvocationSTR113_OK() throws Exception
  {
    // Request variables
    String imsi = "208209813919250"; //$NON-NLS-1$

    // Setup statement mock
    EasyMock.expect(_connection.prepareCall("{call PG_IWSRESSOURCES.P_013_CHECK_PARPNTACC_FromVP(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    PowerMock.expectLastCall();

    _callableStatement.setString("pi_IMSI", imsi); //$NON-NLS-1$
    PowerMock.expectLastCall();

    EasyMock.expect(_callableStatement.getString(RETOUR_RESULTAT)).andReturn("OK"); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString(RETOUR_CATEGORIE)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_DIAGNOSTIC)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_LIBELLE)).andReturn(null);

    EasyMock.expect(_callableStatement.getObject("po_RESULT")).andReturn(Boolean.TRUE); //$NON-NLS-1$

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<Boolean, Retour> res = _connector.checkPARPNTACCFromVP(null, imsi);

    // Asserts
    Assert.assertTrue(res._first);
  }

  /**
   * Test the invocation for the truncate table
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void testTruncateTable() throws Exception
  {
    // Request variables
    String commande = "HEMSPDP"; //$NON-NLS-1$

    // Setup statement mock
    PreparedStatement preparedStatement = PowerMock.createNiceMock(PreparedStatement.class);

    EasyMock.expect(_connection.prepareStatement("TRUNCATE TABLE AUDIT_UDC_" + commande)).andReturn(preparedStatement); //$NON-NLS-1$

    preparedStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    PowerMock.expectLastCall();

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<Boolean, Retour> res = _connector.truncateTableAuditUDC(null, commande);

    // Asserts
    Assert.assertTrue(res._first);
  }

  /**
   * Test to STR_010_ConsultLigneMarche
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void test_ConsultLigneMarche() throws Exception
  {
    // Request variables

    String imsi = "208209813902647"; //$NON-NLS-1$
    String msisdn = "33762110988"; //$NON-NLS-1$

    // Setup statement mock
    // Request by IMSI
    Capture<String> imsiCapture1 = Capture.newInstance();
    Capture<String> msisdnCapture1 = Capture.newInstance();

    EasyMock.expect(_connection.prepareCall("{call PG_IWSRESSOURCES.P_003_CONSULT_LIGNE_MARCHE(?,?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    EasyMock.expectLastCall();

    _callableStatement.setString(EasyMock.eq("pi_IMSI"), EasyMock.capture(imsiCapture1)); //$NON-NLS-1$
    EasyMock.expectLastCall();
    _callableStatement.setString(EasyMock.eq("pi_MSISDN"), EasyMock.capture(msisdnCapture1)); //$NON-NLS-1$
    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.getString(RETOUR_RESULTAT)).andReturn("OK"); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString(RETOUR_CATEGORIE)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_DIAGNOSTIC)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_LIBELLE)).andReturn(null);

    EasyMock.expect(_callableStatement.getObject("po_RESULT")).andReturn(_resultSet); //$NON-NLS-1$

    EasyMock.expect(_resultSet.next()).andReturn(true);
    EasyMock.expect(_resultSet.getString("LIGNE_MARCHE")).andReturn("1"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("IMSI")).andReturn(imsi); //$NON-NLS-1$

    EasyMock.expect(_resultSet.next()).andReturn(false);

    // Request by MSISDN
    Capture<String> imsiCapture2 = Capture.newInstance();
    Capture<String> msisdnCapture2 = Capture.newInstance();

    EasyMock.expect(_connection.prepareCall("{call PG_IWSRESSOURCES.P_003_CONSULT_LIGNE_MARCHE(?,?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    EasyMock.expectLastCall();

    _callableStatement.setString(EasyMock.eq("pi_IMSI"), EasyMock.capture(imsiCapture2)); //$NON-NLS-1$
    EasyMock.expectLastCall();
    _callableStatement.setString(EasyMock.eq("pi_MSISDN"), EasyMock.capture(msisdnCapture2)); //$NON-NLS-1$
    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.getString(RETOUR_RESULTAT)).andReturn("OK"); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString(RETOUR_CATEGORIE)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_DIAGNOSTIC)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_LIBELLE)).andReturn(null);

    EasyMock.expect(_callableStatement.getObject("po_RESULT")).andReturn(_resultSet); //$NON-NLS-1$

    EasyMock.expect(_resultSet.next()).andReturn(true);
    EasyMock.expect(_resultSet.getString("LIGNE_MARCHE")).andReturn("1"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("IMSI")).andReturn(imsi); //$NON-NLS-1$

    EasyMock.expect(_resultSet.next()).andReturn(false);

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<List<LigneMarcheData>, Retour> response = _connector.consultLigneDeMarche(null, imsi, null);

    // Asserts
    Assert.assertEquals(imsi, imsiCapture1.getValue());
    Assert.assertNull(msisdnCapture1.getValue());

    List<LigneMarcheData> resultat = response._first;

    Assert.assertNotNull(resultat);
    Assert.assertTrue(!resultat.isEmpty());

    Assert.assertEquals("1", resultat.get(0).getLigneMarche()); //$NON-NLS-1$
    Assert.assertEquals(imsi, resultat.get(0).getImsi());
    Assert.assertEquals("OK", response._second.getResultat()); //$NON-NLS-1$
    assertEquals(null, response._second.getCategorie());
    assertEquals(null, response._second.getLibelle());
    assertEquals(null, response._second.getDiagnostic());

    // Call connector
    response = _connector.consultLigneDeMarche(null, null, msisdn);

    // Asserts
    Assert.assertEquals(msisdn, msisdnCapture2.getValue());
    Assert.assertNull(imsiCapture2.getValue());

    resultat = response._first;

    Assert.assertNotNull(resultat);
    Assert.assertTrue(!resultat.isEmpty());

    Assert.assertEquals("1", resultat.get(0).getLigneMarche()); //$NON-NLS-1$
    Assert.assertEquals(imsi, resultat.get(0).getImsi());
    Assert.assertEquals("OK", response._second.getResultat()); //$NON-NLS-1$
    assertEquals(null, response._second.getCategorie());
    assertEquals(null, response._second.getLibelle());
    assertEquals(null, response._second.getDiagnostic());
  }

  /**
   * Test to STR_009_ConsultLineStatus
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void test_ConsultLineStatus() throws Exception
  {
    // Request variables

    String imsi = "208209813900741"; //$NON-NLS-1$
    String msisdn = "33762110988"; //$NON-NLS-1$

    // Setup statement mocks
    // Request by IMSI
    Capture<String> imsiCapture1 = Capture.newInstance();
    Capture<String> msisdnCapture1 = Capture.newInstance();

    EasyMock.expect(_connection.prepareCall("{call PG_IWSRESSOURCES.P_002_CONSULT_LINE_STATUS(?,?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    EasyMock.expectLastCall();

    _callableStatement.setString(EasyMock.eq("pi_IMSI"), EasyMock.capture(imsiCapture1)); //$NON-NLS-1$
    EasyMock.expectLastCall();
    _callableStatement.setString(EasyMock.eq("pi_MSISDN"), EasyMock.capture(msisdnCapture1)); //$NON-NLS-1$
    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.getString(RETOUR_RESULTAT)).andReturn("OK"); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString(RETOUR_CATEGORIE)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_DIAGNOSTIC)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_LIBELLE)).andReturn(null);

    EasyMock.expect(_callableStatement.getObject("po_RESULT")).andReturn(_resultSet); //$NON-NLS-1$

    EasyMock.expect(_resultSet.next()).andReturn(true);
    EasyMock.expect(_resultSet.getString("LINESTATUS")).andReturn("ACTIF"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("ALIAS")).andReturn("110037372196"); //$NON-NLS-1$ //$NON-NLS-2$

    EasyMock.expect(_resultSet.next()).andReturn(false);

    // Request by MSISDN
    Capture<String> imsiCapture2 = Capture.newInstance();
    Capture<String> msisdnCapture2 = Capture.newInstance();

    EasyMock.expect(_connection.prepareCall("{call PG_IWSRESSOURCES.P_002_CONSULT_LINE_STATUS(?,?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    EasyMock.expectLastCall();

    _callableStatement.setString(EasyMock.eq("pi_IMSI"), EasyMock.capture(imsiCapture2)); //$NON-NLS-1$
    EasyMock.expectLastCall();
    _callableStatement.setString(EasyMock.eq("pi_MSISDN"), EasyMock.capture(msisdnCapture2)); //$NON-NLS-1$
    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.getString(RETOUR_RESULTAT)).andReturn("OK"); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString(RETOUR_CATEGORIE)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_DIAGNOSTIC)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_LIBELLE)).andReturn(null);

    EasyMock.expect(_callableStatement.getObject("po_RESULT")).andReturn(_resultSet); //$NON-NLS-1$

    EasyMock.expect(_resultSet.next()).andReturn(true);
    EasyMock.expect(_resultSet.getString("LINESTATUS")).andReturn("ACTIF"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("ALIAS")).andReturn("110054008505"); //$NON-NLS-1$ //$NON-NLS-2$

    EasyMock.expect(_resultSet.next()).andReturn(false);

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<List<LineStatusData>, Retour> response = _connector.consultLineStatus(null, imsi, null);

    // Asserts
    Assert.assertEquals(imsi, imsiCapture1.getValue());
    Assert.assertNull(msisdnCapture1.getValue());

    List<LineStatusData> lsdList = response._first;

    Assert.assertNotNull(lsdList);

    Assert.assertEquals(1, lsdList.size());

    Assert.assertEquals("ACTIF", lsdList.get(0).getLineStatus()); //$NON-NLS-1$
    Assert.assertEquals("110037372196", lsdList.get(0).getAlias()); //$NON-NLS-1$

    Assert.assertEquals("OK", response._second.getResultat()); //$NON-NLS-1$
    assertEquals(null, response._second.getCategorie());
    assertEquals(null, response._second.getLibelle());
    assertEquals(null, response._second.getDiagnostic());

    // Call connector
    response = _connector.consultLineStatus(null, null, msisdn);

    // Asserts
    Assert.assertEquals(msisdn, msisdnCapture2.getValue());
    Assert.assertNull(imsiCapture2.getValue());

    lsdList = response._first;

    Assert.assertNotNull(lsdList);

    Assert.assertEquals(1, lsdList.size());

    Assert.assertEquals("ACTIF", lsdList.get(0).getLineStatus()); //$NON-NLS-1$
    Assert.assertEquals("110054008505", lsdList.get(0).getAlias()); //$NON-NLS-1$

    Assert.assertEquals("OK", response._second.getResultat()); //$NON-NLS-1$
    assertEquals(null, response._second.getCategorie());
    assertEquals(null, response._second.getLibelle());
    assertEquals(null, response._second.getDiagnostic());
  }

  /**
   * Test the invocation for the stored procedure in P_GET_PARPNTACC_BY_PFI with exceptions
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void test_GetParpntaccByPfi_Exceptions() throws Exception
  {
    // Request variables
    String pfi = "pfiValue"; //$NON-NLS-1$

    // SQLTimeoutException
    // Setup statement mock
    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_PARPNTACC_BY_PFI(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    PowerMock.expectLastCall();

    _callableStatement.execute();
    PowerMock.expectLastCall().andThrow(new SQLTimeoutException());

    // Call connector
    PowerMock.replayAll();
    ConnectorResponse<List<Parpntacc>, Retour> res = _connector.getParpntaccByPfi(null, pfi);
    PowerMock.verifyAll();

    // Asserts
    Assert.assertEquals("KO", res._second.getResultat()); //$NON-NLS-1$
    Assert.assertNull(res._first);

    // Reset Mocks
    setup();

    // PoolExhaustedException
    // Setup statement mock
    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_PARPNTACC_BY_PFI(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    PowerMock.expectLastCall();

    _callableStatement.execute();
    PowerMock.expectLastCall().andThrow(new PoolExhaustedException());

    // Call connector
    PowerMock.replayAll();
    res = _connector.getParpntaccByPfi(null, pfi);
    PowerMock.verifyAll();

    // Asserts
    Assert.assertEquals("KO", res._second.getResultat()); //$NON-NLS-1$
    Assert.assertNull(res._first);

    // Reset Mocks
    setup();

    // SQLRecoverableException
    // Setup statement mock
    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_PARPNTACC_BY_PFI(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    PowerMock.expectLastCall();

    _callableStatement.execute();
    PowerMock.expectLastCall().andThrow(new SQLRecoverableException());

    // Call connector
    PowerMock.replayAll();
    res = _connector.getParpntaccByPfi(null, pfi);
    PowerMock.verifyAll();

    // Asserts
    Assert.assertEquals("KO", res._second.getResultat()); //$NON-NLS-1$
    Assert.assertNull(res._first);

    // Reset Mocks
    setup();

    // SQLException
    // Setup statement mock
    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_PARPNTACC_BY_PFI(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    PowerMock.expectLastCall();

    _callableStatement.execute();
    PowerMock.expectLastCall().andThrow(new SQLException());

    // Call connector
    PowerMock.replayAll();
    try
    {
      res = _connector.getParpntaccByPfi(null, pfi);
    }
    catch (RavelException exception)
    {
      Assert.assertTrue(exception.getMessage().startsWith("Technical Exception in STRConnector during")); //$NON-NLS-1$
    }
    PowerMock.verifyAll();

    // Asserts
    Assert.assertEquals("KO", res._second.getResultat()); //$NON-NLS-1$
    Assert.assertNull(res._first);
  }

  /**
   * Test the invocation for the stored procedure in GET_TYPE_VMS_FROM_MSISDN
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void test_GetPrapntaccByPfi_OK() throws Exception
  {
    // Request variables
    String pfi = "pfiValue"; //$NON-NLS-1$

    // Setup statement mock
    Date now = new Date(System.currentTimeMillis());

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_PARPNTACC_BY_PFI(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    EasyMock.expectLastCall();

    Capture<String> pfiCapture = Capture.newInstance();
    _callableStatement.setString(EasyMock.eq("pi_PFI"), EasyMock.capture(pfiCapture)); //$NON-NLS-1$
    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.getString(RETOUR_RESULTAT)).andReturn("OK"); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString(RETOUR_CATEGORIE)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_DIAGNOSTIC)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_LIBELLE)).andReturn(null);

    EasyMock.expect(_callableStatement.getObject("po_RESULT")).andReturn(_resultSet); //$NON-NLS-1$ //$NON-NLS-2$

    EasyMock.expect(_resultSet.next()).andReturn(true);
    EasyMock.expect(_resultSet.getLong("PK_PARPNTACC")).andReturn(1L); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getString("PFI")).andReturn("pfiValue"); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getString("IDTPNTACC")).andReturn("id_point_acces"); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getInt("FK_TYPPNTACCGEN")).andReturn(1); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getInt("FK_TYPPNTACCCOM")).andReturn(2); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getString("TCN")).andReturn("technologieValue"); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getString("NOMPAR")).andReturn("nomParValue"); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getString("VALPAR")).andReturn("valParValue"); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getString("IDTDERMOD")).andReturn("id_derniere_modif"); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getString("ACTDERMOD")).andReturn("acte_derniere_modif"); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getDate("DATDERMOD")).andReturn(now); //$NON-NLS-1$
    EasyMock.expect(_resultSet.next()).andReturn(false);

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<List<Parpntacc>, Retour> res = _connector.getParpntaccByPfi(null, pfi);

    // Asserts
    Assert.assertEquals(pfi, pfiCapture.getValue());

    List<Parpntacc> parpntaccList = res._first;

    Assert.assertNotNull(parpntaccList);

    Assert.assertEquals(1, parpntaccList.size());

    Assert.assertEquals(Long.valueOf("1"), parpntaccList.get(0).getIdentifiantParpntacc()); //$NON-NLS-1$
    Assert.assertEquals("pfiValue", parpntaccList.get(0).getPfi()); //$NON-NLS-1$
    Assert.assertEquals("id_point_acces", parpntaccList.get(0).getIdentifiantPointAcces()); //$NON-NLS-1$
    Assert.assertEquals(Integer.valueOf("1"), parpntaccList.get(0).getTypePointAccesGenerique()); //$NON-NLS-1$
    Assert.assertEquals(Integer.valueOf("2"), parpntaccList.get(0).getTypePointAccesCommercial()); //$NON-NLS-1$
    Assert.assertEquals("technologieValue", parpntaccList.get(0).getTechnologie()); //$NON-NLS-1$
    Assert.assertEquals("nomParValue", parpntaccList.get(0).getNomParametre()); //$NON-NLS-1$
    Assert.assertEquals("valParValue", parpntaccList.get(0).getValParametre()); //$NON-NLS-1$
    Assert.assertEquals("id_derniere_modif", parpntaccList.get(0).getIdentifiantDerniereModification()); //$NON-NLS-1$
    Assert.assertEquals("acte_derniere_modif", parpntaccList.get(0).getActeDerniereModification()); //$NON-NLS-1$
    Assert.assertEquals(new Timestamp(now.getTime()).toLocalDateTime(), parpntaccList.get(0).getDateDerniereModification()); //$NON-NLS-1$

    Assert.assertEquals(StringConstants.OK, res._second.getResultat());
    assertEquals(null, res._second.getCategorie());
    assertEquals(null, res._second.getLibelle());
    assertEquals(null, res._second.getDiagnostic());
  }

  /**
   * Test the invocation for the stored procedure in PG_MIGSTW.PR_MIGSTW with exceptions
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void test_migrerStaStwVersVstw_Exceptions() throws Exception
  {
    // Request variables
    StMediaBox stMediaBox = new StMediaBox("+1234567890", "0"); //$NON-NLS-1$
    stMediaBox.setProfileId("1");
    stMediaBox.setMboxBlockedState("Y"); //$NON-NLS-1$
    stMediaBox.setMboxBlockedReason("MIGRATION"); //$NON-NLS-1$
    stMediaBox.setMboxBlockedBy("ADMINISTRATOR"); //$NON-NLS-1$
    stMediaBox.setMwiState("Y");//$NON-NLS-1$
    stMediaBox.setIdtDerMod("IdtDerMod");//$NON-NLS-1$

    // SQLTimeoutException
    // Setup statement mock
    EasyMock.expect(_connection.prepareCall("{call PG_MIGSTW.PR_MIGSTW(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    PowerMock.expectLastCall();

    _callableStatement.execute();
    PowerMock.expectLastCall().andThrow(new SQLTimeoutException());

    // Call connector
    PowerMock.replayAll();
    ConnectorResponse<MigrerStaStwVersVstwResponse, Retour> res = _connector.migrerStaStwVersVstw(null, stMediaBox);
    PowerMock.verifyAll();

    // Asserts
    Assert.assertEquals("KO", res._second.getResultat()); //$NON-NLS-1$
    Assert.assertNull(res._first);

    // Reset Mocks
    setup();

    // PoolExhaustedException
    // Setup statement mock
    EasyMock.expect(_connection.prepareCall("{call PG_MIGSTW.PR_MIGSTW(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    PowerMock.expectLastCall();

    _callableStatement.execute();
    PowerMock.expectLastCall().andThrow(new PoolExhaustedException());

    // Call connector
    PowerMock.replayAll();
    res = _connector.migrerStaStwVersVstw(null, stMediaBox);
    PowerMock.verifyAll();

    // Asserts
    Assert.assertEquals("KO", res._second.getResultat()); //$NON-NLS-1$
    Assert.assertNull(res._first);

    // Reset Mocks
    setup();

    // SQLRecoverableException
    // Setup statement mock
    EasyMock.expect(_connection.prepareCall("{call PG_MIGSTW.PR_MIGSTW(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    PowerMock.expectLastCall();

    _callableStatement.execute();
    PowerMock.expectLastCall().andThrow(new SQLRecoverableException());

    // Call connector
    PowerMock.replayAll();
    res = _connector.migrerStaStwVersVstw(null, stMediaBox);
    PowerMock.verifyAll();

    // Asserts
    Assert.assertEquals("KO", res._second.getResultat()); //$NON-NLS-1$
    Assert.assertNull(res._first);

    // Reset Mocks
    setup();

    // SQLException
    // Setup statement mock
    EasyMock.expect(_connection.prepareCall("{call PG_MIGSTW.PR_MIGSTW(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    PowerMock.expectLastCall();

    _callableStatement.execute();
    PowerMock.expectLastCall().andThrow(new SQLException());

    // Call connector
    PowerMock.replayAll();
    try
    {
      res = _connector.migrerStaStwVersVstw(null, stMediaBox);
    }
    catch (RavelException exception)
    {
      Assert.assertTrue(exception.getMessage().startsWith("Technical Exception in STRConnector during")); //$NON-NLS-1$
    }
    PowerMock.verifyAll();

    // Asserts
    Assert.assertEquals("KO", res._second.getResultat()); //$NON-NLS-1$
    Assert.assertNull(res._first);
  }

  /**
   * Test the invocation for the stored procedure in PG_MIGSTW.PR_MIGSTW
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void test_migrerStaStwVersVstw_OK() throws Exception
  {
    // Request variables
    StMediaBox stMediaBox = new StMediaBox("+1234567890", "0"); //$NON-NLS-1$
    stMediaBox.setProfileId("1");
    stMediaBox.setMboxBlockedState("Y"); //$NON-NLS-1$
    stMediaBox.setMboxBlockedReason("MIGRATION"); //$NON-NLS-1$
    stMediaBox.setMboxBlockedBy("ADMINISTRATOR"); //$NON-NLS-1$
    stMediaBox.setMwiState("Y");//$NON-NLS-1$
    stMediaBox.setIdtDerMod("IdtDerMod");//$NON-NLS-1$

    // Setup statement mock
    EasyMock.expect(_connection.prepareCall("{call PG_MIGSTW.PR_MIGSTW(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    EasyMock.expectLastCall();

    _callableStatement.setString("pi_noTelephone", stMediaBox.getNoTelephone()); //$NON-NLS-1$
    _callableStatement.setInt("pi_pkMsisdn", Integer.parseInt(stMediaBox.getPkMsisdn())); //$NON-NLS-1$
    _callableStatement.setString("pi_PROFILEID", stMediaBox.getProfileId()); //$NON-NLS-1$
    _callableStatement.setString("pi_MBOXBLOCKEDSTATE", stMediaBox.getMboxBlockedState()); //$NON-NLS-1$
    _callableStatement.setString("pi_MWIVOIPSTATE", stMediaBox.getMwiState()); //$NON-NLS-1$
    _callableStatement.setString("pi_MBOXBLOCKEDBY", stMediaBox.getMboxBlockedBy()); //$NON-NLS-1$
    _callableStatement.setString("pi_MBOXBLOCKEDREASON", stMediaBox.getMboxBlockedReason()); //$NON-NLS-1$
    _callableStatement.setString("pi_IDTDERMOD", stMediaBox.getIdtDerMod()); //$NON-NLS-1$

    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.getString("po_pfi")).andReturn("idPfi"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_callableStatement.getString("po_eoickStw")).andReturn("eoickStw"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_callableStatement.getString("po_eoickVstw")).andReturn("eoickVstw"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_callableStatement.getString(RETOUR_RESULTAT)).andReturn("OK"); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString(RETOUR_CATEGORIE)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_DIAGNOSTIC)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_LIBELLE)).andReturn(null);

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<MigrerStaStwVersVstwResponse, Retour> res = _connector.migrerStaStwVersVstw(null, stMediaBox);

    // Asserts
    assertEquals(res._first.getIdPfi(), "idPfi"); //$NON-NLS-1$
    assertEquals(res._first.getEoickStw(), "eoickStw"); //$NON-NLS-1$
    assertEquals(res._first.getEoickVstw(), "eoickVstw"); //$NON-NLS-1$
    assertEquals(res.getError().getResultat(), StringConstants.OK);
  }

  /**
   * Test the invocation for the stored procedure in PG_MIGSTW.PR_INHIBER_ST_VMS with exceptions
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void test_inhiberStaStw_Exceptions() throws Exception
  {
    // Request variables
    String noTelephone = "+33156784589";//$NON-NLS-1$
    String idtDerMod = "MIGRER_LOT_BOITE_4587";//$NON-NLS-1$

    // SQLTimeoutException
    // Setup statement mock
    EasyMock.expect(_connection.prepareCall("{call PG_MIGSTW.PR_INHIBER_ST_VMS(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    PowerMock.expectLastCall();

    _callableStatement.execute();
    PowerMock.expectLastCall().andThrow(new SQLTimeoutException());

    // Call connector
    PowerMock.replayAll();
    ConnectorResponse<Nothing, Retour> res = _connector.inhiberStaStw(null, noTelephone, idtDerMod);
    PowerMock.verifyAll();

    // Asserts
    Assert.assertEquals("KO", res._second.getResultat()); //$NON-NLS-1$
    Assert.assertNull(res._first);

    // Reset Mocks
    setup();

    // PoolExhaustedException
    // Setup statement mock
    EasyMock.expect(_connection.prepareCall("{call PG_MIGSTW.PR_INHIBER_ST_VMS(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    PowerMock.expectLastCall();

    _callableStatement.execute();
    PowerMock.expectLastCall().andThrow(new PoolExhaustedException());

    // Call connector
    PowerMock.replayAll();
    res = _connector.inhiberStaStw(null, noTelephone, idtDerMod);
    PowerMock.verifyAll();

    // Asserts
    Assert.assertEquals("KO", res._second.getResultat()); //$NON-NLS-1$
    Assert.assertNull(res._first);

    // Reset Mocks
    setup();

    // SQLRecoverableException
    // Setup statement mock
    EasyMock.expect(_connection.prepareCall("{call PG_MIGSTW.PR_INHIBER_ST_VMS(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    PowerMock.expectLastCall();

    _callableStatement.execute();
    PowerMock.expectLastCall().andThrow(new SQLRecoverableException());

    // Call connector
    PowerMock.replayAll();
    res = _connector.inhiberStaStw(null, noTelephone, idtDerMod);
    PowerMock.verifyAll();

    // Asserts
    Assert.assertEquals("KO", res._second.getResultat()); //$NON-NLS-1$
    Assert.assertNull(res._first);

    // Reset Mocks
    setup();

    // SQLException
    // Setup statement mock
    EasyMock.expect(_connection.prepareCall("{call PG_MIGSTW.PR_INHIBER_ST_VMS(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    PowerMock.expectLastCall();

    _callableStatement.execute();
    PowerMock.expectLastCall().andThrow(new SQLException());

    // Call connector
    PowerMock.replayAll();
    try
    {
      res = _connector.inhiberStaStw(null, noTelephone, idtDerMod);
    }
    catch (RavelException exception)
    {
      Assert.assertTrue(exception.getMessage().startsWith("Technical Exception in STRConnector during")); //$NON-NLS-1$
    }
    PowerMock.verifyAll();

    // Asserts
    Assert.assertEquals("KO", res._second.getResultat()); //$NON-NLS-1$
    Assert.assertNull(res._first);
  }

  /**
   * Test the invocation for the stored procedure in PG_MIGSTW.PR_INHIBER_ST_VMS
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void test_inhiberStaStw_OK() throws Exception
  {
    // Request variables
    String noTelephone = "+33156784589";//$NON-NLS-1$
    String idtDerMod = "MIGRER_LOT_BOITE_4587";//$NON-NLS-1$

    // Setup statement mock
    EasyMock.expect(_connection.prepareCall("{call PG_MIGSTW.PR_INHIBER_ST_VMS(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    EasyMock.expectLastCall();

    _callableStatement.setString("pi_noTelephone", noTelephone); //$NON-NLS-1$
    _callableStatement.setString("pi_IDTDERMOD", idtDerMod); //$NON-NLS-1$

    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.getString(RETOUR_RESULTAT)).andReturn("OK"); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString(RETOUR_CATEGORIE)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_DIAGNOSTIC)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_LIBELLE)).andReturn(null);

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<Nothing, Retour> res = _connector.inhiberStaStw(null, noTelephone, idtDerMod);

    // Asserts
    assertNull(res._first); //$NON-NLS-1$
    assertEquals(res.getError().getResultat(), StringConstants.OK);
  }

  /**
   * Test the invocation for the stored procedure in PG_MIGSTW.PR_INHIBER_ST_VMS with exceptions
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void test_annulerMigrerStaStwVersVstw_Exceptions() throws Exception
  {
    // Request variables
    String noTelephone = "+33156784589";//$NON-NLS-1$
    String idtDerMod = "MIGRER_LOT_BOITE_4587";//$NON-NLS-1$

    // SQLTimeoutException
    // Setup statement mock
    EasyMock.expect(_connection.prepareCall("{call PG_MIGSTW.PR_ANNULER_MIGSTW(?,?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    PowerMock.expectLastCall();

    _callableStatement.execute();
    PowerMock.expectLastCall().andThrow(new SQLTimeoutException());

    // Call connector
    PowerMock.replayAll();
    ConnectorResponse<String, Retour> res = _connector.annulerMigrerStaStwVersVstw(null, noTelephone, idtDerMod);
    PowerMock.verifyAll();

    // Asserts
    Assert.assertEquals("KO", res._second.getResultat()); //$NON-NLS-1$
    Assert.assertNull(res._first);

    // Reset Mocks
    setup();

    // PoolExhaustedException
    // Setup statement mock
    EasyMock.expect(_connection.prepareCall("{call PG_MIGSTW.PR_ANNULER_MIGSTW(?,?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    PowerMock.expectLastCall();

    _callableStatement.execute();
    PowerMock.expectLastCall().andThrow(new PoolExhaustedException());

    // Call connector
    PowerMock.replayAll();
    res = _connector.annulerMigrerStaStwVersVstw(null, noTelephone, idtDerMod);
    PowerMock.verifyAll();

    // Asserts
    Assert.assertEquals("KO", res._second.getResultat()); //$NON-NLS-1$
    Assert.assertNull(res._first);

    // Reset Mocks
    setup();

    // SQLRecoverableException
    // Setup statement mock
    EasyMock.expect(_connection.prepareCall("{call PG_MIGSTW.PR_ANNULER_MIGSTW(?,?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    PowerMock.expectLastCall();

    _callableStatement.execute();
    PowerMock.expectLastCall().andThrow(new SQLRecoverableException());

    // Call connector
    PowerMock.replayAll();
    res = _connector.annulerMigrerStaStwVersVstw(null, noTelephone, idtDerMod);
    PowerMock.verifyAll();

    // Asserts
    Assert.assertEquals("KO", res._second.getResultat()); //$NON-NLS-1$
    Assert.assertNull(res._first);

    // Reset Mocks
    setup();

    // SQLException
    // Setup statement mock
    EasyMock.expect(_connection.prepareCall("{call PG_MIGSTW.PR_ANNULER_MIGSTW(?,?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    PowerMock.expectLastCall();

    _callableStatement.execute();
    PowerMock.expectLastCall().andThrow(new SQLException());

    // Call connector
    PowerMock.replayAll();
    try
    {
      res = _connector.annulerMigrerStaStwVersVstw(null, noTelephone, idtDerMod);
    }
    catch (RavelException exception)
    {
      Assert.assertTrue(exception.getMessage().startsWith("Technical Exception in STRConnector during")); //$NON-NLS-1$
    }
    PowerMock.verifyAll();

    // Asserts
    Assert.assertEquals("KO", res._second.getResultat()); //$NON-NLS-1$
    Assert.assertNull(res._first);
  }

  /**
   * Test the invocation for the stored procedure in PG_MIGSTW.PR_INHIBER_ST_VMS
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void test_annulerMigrerStaStwVersVstw_OK() throws Exception
  {
    // Request variables
    String noTelephone = "+33156784589";//$NON-NLS-1$
    String idtDerMod = "MIGRER_LOT_BOITE_4587";//$NON-NLS-1$

    // Setup statement mock
    EasyMock.expect(_connection.prepareCall("{call PG_MIGSTW.PR_ANNULER_MIGSTW(?,?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$

    _callableStatement.setQueryTimeout(READ_TIMEOUT_SEC);
    EasyMock.expectLastCall();

    _callableStatement.setString("pi_noTelephone", noTelephone); //$NON-NLS-1$
    _callableStatement.setString("pi_IDTDERMOD", idtDerMod); //$NON-NLS-1$

    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.getString("po_eoickStw")).andReturn("eoickStw"); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString(RETOUR_RESULTAT)).andReturn("OK"); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString(RETOUR_CATEGORIE)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_DIAGNOSTIC)).andReturn(null);
    EasyMock.expect(_callableStatement.getString(RETOUR_LIBELLE)).andReturn(null);

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<String, Retour> res = _connector.annulerMigrerStaStwVersVstw(null, noTelephone, idtDerMod);

    // Asserts
    assertEquals(res._first, "eoickStw"); //$NON-NLS-1$
    assertEquals(res.getError().getResultat(), StringConstants.OK);
  }
}
