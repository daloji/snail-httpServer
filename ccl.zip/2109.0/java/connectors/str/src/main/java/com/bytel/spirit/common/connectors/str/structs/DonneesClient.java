/*******************************************************************************
* $Id: DonneesClient.java 8367 2018-07-25 17:01:34Z kbettenc $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.str.structs;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author lmerces
 * @version ($Revision: 8367 $ $Date: 2018-07-25 19:01:34 +0200 (mer. 25 juil. 2018) $)
 */
public class DonneesClient
{
  /**
   * Nom de la colonne PFI
   */
  private static final String COLUMN_PFI_PRM = "PFI"; //$NON-NLS-1$

  /**
   * Nom de la colonne MSISDN
   */
  private static final String COLUMN_MSISDN_PRM = "MSISDN"; //$NON-NLS-1$

  /**
   * Nom de la colonne NUMTEL
   */
  private static final String COLUMN_NUMTEL_PRM = "NUMTEL"; //$NON-NLS-1$

  /**
   * Nom de la colonne IMSI
   */
  private static final String COLUMN_IMSI_PRM = "IMSI"; //$NON-NLS-1$

  /**
   * PFI
   */
  private String _pfi;

  /**
   * MSISDN
   */
  private String _msisdn;

  /**
   * NUMTEL
   */
  private String _numtel;

  /**
   * IMSI
   */
  private String _imsi;

  /**
   *
   */
  public DonneesClient()
  {
    super();
  }

  /**
   * Constructeur
   *
   * @param rs
   *          The ResultSet to get the value of DonneesClient from
   * @throws SQLException
   *           on error
   */
  public DonneesClient(ResultSet rs) throws SQLException
  {
    this._pfi = rs.getString(COLUMN_PFI_PRM);
    this._msisdn = rs.getString(COLUMN_MSISDN_PRM);
    this._numtel = rs.getString(COLUMN_NUMTEL_PRM);
    this._imsi = rs.getString(COLUMN_IMSI_PRM);
  }

  /**
   * @return the imsi
   */
  public String getImsi()
  {
    return _imsi;
  }

  /**
   * @return the msisdn
   */
  public String getMsisdn()
  {
    return _msisdn;
  }

  /**
   * @return the numtel
   */
  public String getNumtel()
  {
    return _numtel;
  }

  /**
   * @return the pfi
   */
  public String getPfi()
  {
    return _pfi;
  }

  /**
   * @param imsi_p
   *          the imsi to set
   */
  public void setImsi(String imsi_p)
  {
    _imsi = imsi_p;
  }

  /**
   * @param msisdn_p
   *          the msisdn to set
   */
  public void setMsisdn(String msisdn_p)
  {
    _msisdn = msisdn_p;
  }

  /**
   * @param numtel_p
   *          the numtel to set
   */
  public void setNumtel(String numtel_p)
  {
    _numtel = numtel_p;
  }

  /**
   * @param pfi_p
   *          the pfi to set
   */
  public void setPfi(String pfi_p)
  {
    _pfi = pfi_p;
  }
}
