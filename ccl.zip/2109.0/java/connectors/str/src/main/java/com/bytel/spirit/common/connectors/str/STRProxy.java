/*******************************************************************************
* $Id: STRProxy.java 51044 2021-04-23 08:25:04Z fbarnabe $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.str;

import java.util.List;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.probes.AvgDoubleCollectorItem;
import com.bytel.ravel.common.probes.AvgFlowPerSecondCollector;
import com.bytel.ravel.common.probes.RavelProbeConfigurationManager;
import com.bytel.ravel.services.connector.BaseDBProxy;
import com.bytel.ravel.services.connector.ConnectorExecution;
import com.bytel.ravel.services.connector.ConnectorManager;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.connectors.str.structs.AuditUDCHEMSCMP;
import com.bytel.spirit.common.connectors.str.structs.AuditUDCHEMSPDP;
import com.bytel.spirit.common.connectors.str.structs.AuditUDCHEMSSDP;
import com.bytel.spirit.common.connectors.str.structs.DonneesClient;
import com.bytel.spirit.common.connectors.str.structs.InfoProfil;
import com.bytel.spirit.common.connectors.str.structs.LigneMarcheData;
import com.bytel.spirit.common.connectors.str.structs.LineStatusData;
import com.bytel.spirit.common.connectors.str.structs.MigrerStaStwVersVstwResponse;
import com.bytel.spirit.common.connectors.str.structs.ParamSrvTech;
import com.bytel.spirit.common.connectors.str.structs.Parpntacc;
import com.bytel.spirit.common.connectors.str.structs.ResultContratEtPartition;
import com.bytel.spirit.common.connectors.str.structs.ServiceTechniqueSTR;
import com.bytel.spirit.common.connectors.str.structs.TSMData;
import com.bytel.spirit.common.shared.functional.types.functional.mediaBox.StMediaBox;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

/**
 * Proxy for the STR connector
 *
 * @author $Author: fcabral $
 * @version ($Revision: 51044 $ $Date: 2021-04-23 10:25:04 +0200 (ven. 23 avril 2021) $)
 */
public class STRProxy extends BaseDBProxy implements ISTR
{
  /**
   * Proxy instance.
   */
  private static final STRProxy INSTANCE = new STRProxy();

  /**
   * Gets the single instance of STRProxy.
   *
   * @return The STR proxy instance.
   */
  public static STRProxy getInstance()
  {
    return STRProxy.INSTANCE;
  }

  /**
   * Probe: measure the average number of STRGetPFIFromMSISDN calls per second.
   */
  protected AvgFlowPerSecondCollector _avg_psSTR004UPCCGetPFIFromMSISDN_call_counter;

  /**
   * Probe: measure the average execution time of the STRGetPFIFromMSISDN operation.
   */
  protected AvgDoubleCollectorItem _avg_psSTR004UPCCPFIFromMSISDN_ExecTime;

  /**
   * Probe: measure the average number of UPCCGetIMSIFromPFI calls per second.
   */
  protected AvgFlowPerSecondCollector _avg_psSTR005UPCCGetIMSIFromPFI_call_counter;

  /**
   * Probe: measure the average execution time of the UPCCGetIMSIFromPFI operation.
   */
  protected AvgDoubleCollectorItem _avg_psSTR005UPCCGetIMSIFromPFI_ExecTime;

  /**
   * Probe: measure the average number of UPCCGetIDTPFSFromPFI calls per second.
   */
  protected AvgFlowPerSecondCollector _avg_psSTR006UPCCGetIDTPFSFromPFI_call_counter;

  /**
   * Probe: measure the average execution time of the UPCCGetIDTPFSFromPFI operation.
   */
  protected AvgDoubleCollectorItem _avg_psSTR006UPCCGetIDTPFSFromPFI_ExecTime;

  /**
   * Probe: measure the average number of STR007GetTSMDataByMSISDN calls per second.
   */
  protected AvgFlowPerSecondCollector _avg_psSTR007GetTSMDataByMSISDN_call_counter;

  /**
   * Probe: measure the average execution time of the STR007GetTSMDataByMSISDN operation.
   */
  protected AvgDoubleCollectorItem _avg_psSTR007GetTSMDataByMSISDN_ExecTime;

  /**
   * Probe: measure the average number of STR008GetTSMDataByIMSI calls per second.
   */
  protected AvgFlowPerSecondCollector _avg_psSTR008GetTSMDataByIMSI_call_counter;

  /**
   * Probe: measure the average execution time of the STR008GetTSMDataByIMSI operation.
   */
  protected AvgDoubleCollectorItem _avg_psSTR008GetTSMDataByIMSI_ExecTime;

  /**
   * Probe: measure the average number of ConsultLineStatus calls per second.
   */
  protected AvgFlowPerSecondCollector _avg_psSTR009ConsultLineStatus_call_counter;

  /**
   * Probe: measure the average execution time of the ConsultLineStatus operation.
   */
  protected AvgDoubleCollectorItem _avg_psSTR009ConsultLineStatus_ExecTime;

  /**
   * Probe: measure the average number of ConsultLigneDeMarche calls per second.
   */
  protected AvgFlowPerSecondCollector _avg_psSTR010ConsultLigneDeMarche_call_counter;

  /**
   * Probe: measure the average execution time of the ConsultLigneDeMarche operation.
   */
  protected AvgDoubleCollectorItem _avg_psSTR010ConsultLigneDeMarche_ExecTime;

  /**
   * Probe: measure the average number of GetPFIFromIMSI calls per second.
   */
  protected AvgFlowPerSecondCollector _avg_psSTR011GetPFIFromIMSI_call_counter;

  /**
   * Probe: measure the average execution time of the GetPFIFromIMSI operation.
   */
  protected AvgDoubleCollectorItem _avg_psSTR011GetPFIFromIMSI_ExecTime;

  /**
   * Probe: measure the average number of GetMSISDNFromPFI calls per second.
   */
  protected AvgFlowPerSecondCollector _avg_psSTR012GetMSISDNFromPFI_call_counter;

  /**
   * Probe: measure the average execution time of the GetMSISDNFromPFI operation.
   */
  protected AvgDoubleCollectorItem _avg_psSTR012GetMSISDNFromPFI_ExecTime;

  /**
   * Probe: measure the average number of GetMSISDNBDUOFromPFI calls per second.
   */
  protected AvgFlowPerSecondCollector _avg_psSTR013GetMSISDNBDUOFromPFI_call_counter;

  /**
   * Probe: measure the average execution time of the GetMSISDNBDUOFromPFI operation.
   */
  protected AvgDoubleCollectorItem _avg_psSTR013GetMSISDNBDUOFromPFI_ExecTime;

  /**
   * Probe: measure the average number of GetSVCTECACCFromPFI calls per second.
   */
  protected AvgFlowPerSecondCollector _avg_psSTR014GetSVCTECACCFromPFI_call_counter;

  /**
   * Probe: measure the average execution time of the GetSVCTECACCFromPFI operation.
   */
  protected AvgDoubleCollectorItem _avg_psSTR014GetSVCTECACCFromPFI_ExecTime;

  /**
   * Probe: measure the average number of GetPARSVCTECACC calls per second.
   */
  protected AvgFlowPerSecondCollector _avg_psSTR015GetPARSVCTECACC_call_counter;

  /**
   * Probe: measure the average execution time of the GetSVCTECACCFromPFI operation.
   */
  protected AvgDoubleCollectorItem _avg_psSTR015GetPARSVCTECACC_ExecTime;

  /**
   * Probe: measure the average number of GetCustomerIdentity calls per second.
   */
  protected AvgFlowPerSecondCollector _avg_psSTR016GetCustomerIdentity_call_counter;

  /**
   * Probe: measure the average execution time of the GetCustomerIdentity operation.
   */
  protected AvgDoubleCollectorItem _avg_psSTR016GetCustomerIdentity_ExecTime;

  /**
   * Probe: measure the average number of CHECK_PARAPNTACC_FromVP calls per second.
   */
  protected AvgFlowPerSecondCollector _avg_psSTR113CHECK_PARAPNTACC_FromVP_call_counter;

  /**
   * Probe: measure the average execution time of the CHECK_PARAPNTACC_FromVP operation.
   */
  protected AvgDoubleCollectorItem _avg_psSTR113CHECK_PARAPNTACC_FromVP_ExecTime;

  /**
   * Probe: measure the average number of InsertUDCHEMSSDP calls per second.
   */
  protected AvgFlowPerSecondCollector _avg_psSTR017InsertUDCHEMSSDP_call_counter;

  /**
   * Probe: measure the average execution time of the InsertUDCHEMSSDP operation.
   */
  protected AvgDoubleCollectorItem _avg_psSTR017InsertUDCHEMSSDP_ExecTime;

  /**
   * Probe: measure the average number of InsertUDCHEMSPDP calls per second.
   */
  protected AvgFlowPerSecondCollector _avg_psSTR018InsertUDCHEMSPDP_call_counter;

  /**
   * Probe: measure the average execution time of the InsertUDCHEMSPDP operation.
   */
  protected AvgDoubleCollectorItem _avg_psSTR018InsertUDCHEMSPDP_ExecTime;

  /**
   * Probe: measure the average number of InsertUDCHEMSCMP calls per second.
   */
  protected AvgFlowPerSecondCollector _avg_psSTR019InsertUDCHEMSCMP_call_counter;

  /**
   * Probe: measure the average execution time of the InsertUDCHEMSCMP operation.
   */
  protected AvgDoubleCollectorItem _avg_psSTR019InsertUDCHEMSCMP_ExecTime;

  /**
   * Probe: measure the average number of GetSTRHEMSSDP calls per second.
   */
  protected AvgFlowPerSecondCollector _avg_psSTR020GetSTRHEMSSDP_call_counter;

  /**
   * Probe: measure the average execution time of the GetSTRHEMSSDP operation.
   */
  protected AvgDoubleCollectorItem _avg_psSTR020GetSTRHEMSSDP_ExecTime;

  /**
   * Probe: measure the average number of AuditHEMSSDP calls per second.
   */
  protected AvgFlowPerSecondCollector _avg_psSTR021AuditHEMSSDP_call_counter;

  /**
   * Probe: measure the average execution time of the AuditHEMSSDP operation.
   */
  protected AvgDoubleCollectorItem _avg_psSTR021AuditHEMSSDP_ExecTime;

  /**
   * Probe: measure the average number of GetSTRHEMSSDP calls per second.
   */
  protected AvgFlowPerSecondCollector _avg_psSTR022GetSTRHEMSPDP_call_counter;

  /**
   * Probe: measure the average execution time of the GetSTRHEMSSDP operation.
   */
  protected AvgDoubleCollectorItem _avg_psSTR022GetSTRHEMSPDP_ExecTime;

  /**
   * Probe: measure the average number of GetSTRHEMSCMP calls per second.
   */
  protected AvgFlowPerSecondCollector _avg_psSTR023GetSTRHEMSCMP_call_counter;

  /**
   * Probe: measure the average execution time of the GetSTRHEMSCMP operation.
   */
  protected AvgDoubleCollectorItem _avg_psSTR023GetSTRHEMSCMP_ExecTime;

  /**
   * Probe: measure the average number of AuditHEMSCMP calls per second.
   */
  protected AvgFlowPerSecondCollector _avg_psSTR024AuditHEMSCMP_call_counter;

  /**
   * Probe: measure the average execution time of the AuditHEMSCMP operation.
   */
  protected AvgDoubleCollectorItem _avg_psSTR024AuditHEMSCMP_ExecTime;

  /**
   * Probe: measure the average number of AuditHEMSPDP calls per second.
   */
  protected AvgFlowPerSecondCollector _avg_psSTR025AuditHEMSPDP_call_counter;

  /**
   * Probe: measure the average execution time of the AuditHEMSPDP operation.
   */
  protected AvgDoubleCollectorItem _avg_psSTR025AuditHEMSPDP_ExecTime;

  /**
   * Probe: measure the average number of STR_026_GetPfiFromMsisdn calls per second
   */
  protected AvgFlowPerSecondCollector _avg_psSTR026GetPfiFromMsisdn_call_counter;

  /**
   * Probe: measure the average execution time of the STR_026_GetPfiFromMsisdn operation
   */
  protected AvgDoubleCollectorItem _avg_psSTR026GetPfiFromMsisdn_ExecTime;

  /**
   * Probe: measure the average number of TruncateTableAuditUDC calls per second.
   */
  protected AvgFlowPerSecondCollector _avg_truncateTableAuditUDC_call_counter;

  /**
   * Probe: measure the average execution time of the truncateTableAuditUDC operation.
   */
  protected AvgDoubleCollectorItem _avg_truncateTableAuditUDC_ExecTime;

  /**
   * Probe: measure the average number of GetProfilsPirelliParLM calls per second.
   */
  protected AvgFlowPerSecondCollector _avg_psGetProfilsPirelliParLM_call_counter;

  /**
   * Probe: measure the average execution time of the GetProfilsPirelliParLM operation.
   */
  protected AvgDoubleCollectorItem _avg_psGetProfilsPirelliParLM_ExecTime;

  /**
   * Probe: measure the average number of GetProfilsThePoliceParLM calls per second.
   */
  protected AvgFlowPerSecondCollector _avg_psGetProfilsThePoliceParLM_call_counter;

  /**
   * Probe: measure the average execution time of the GetProfilsThePoliceParLM operation.
   */
  protected AvgDoubleCollectorItem _avg_psGetProfilsThePoliceParLM_ExecTime;

  /**
   * Probe: measure the average number of RecupererNoContratParNoTelephone calls per second.
   */
  protected AvgFlowPerSecondCollector _avg_psRecupererNoContratParNoTelephone_call_counter;

  /**
   * Probe: measure the average execution time of the RecupererNoContratParNoTelephone operation.
   */
  protected AvgDoubleCollectorItem _avg_psRecupererNoContratParNoTelephone_ExecTime;

  /**
   * Probe: measure the average number of RecupererTypeVms calls per second.
   */
  protected AvgFlowPerSecondCollector _avg_psRecupererTypeVms_call_counter;

  /**
   * Probe: measure the average execution time of the RecupererTypeVms operation.
   */
  protected AvgDoubleCollectorItem _avg_psRecupererTypeVms_ExecTime;

  /**
   * Probe: measure the average number of GetParpntaccByPfi calls per second.
   */
  protected AvgFlowPerSecondCollector _avg_psGetParpntaccByPfi_call_counter;

  /**
   * Probe: measure the average execution time of the GetParpntaccByPfi operation.
   */
  protected AvgDoubleCollectorItem _avg_psGetParpntaccByPfi_ExecTime;

  /**
   * Probe: measure the average number of migrerStaStwVersVstw calls per second.
   */
  protected AvgFlowPerSecondCollector _avg_migrerStaStwVersVstw_call_counter;

  /**
   * Probe: measure the average execution time of the migrerStaStwVersVstw operation.
   */
  protected AvgDoubleCollectorItem _avg_migrerStaStwVersVstw_ExecTime;

  /**
   * Probe: measure the average number of inhiberStaStw calls per second.
   */
  protected AvgFlowPerSecondCollector _avg_inhiberStaStw_call_counter;

  /**
   * Probe: measure the average execution time of the inhiberStaStw operation.
   */
  protected AvgDoubleCollectorItem _avg_inhiberStaStw_ExecTime;

  /**
   * Probe: measure the average number of annulerMigrerStaStwVersVstw calls per second.
   */
  protected AvgFlowPerSecondCollector _avg_annulerMigrerStaStwVersVstw_call_counter;

  /**
   * Probe: measure the average execution time of the annulerMigrerStaStwVersVstw operation.
   */
  protected AvgDoubleCollectorItem _avg_annulerMigrerStaStwVersVstw_ExecTime;

  /**
   * Default constructor.
   */
  public STRProxy()
  {
    // probes
    RavelProbeConfigurationManager manager = RavelProbeConfigurationManager.getInstance();
    String proxyName = STRProxy.class.getSimpleName();
    _avg_psSTR004UPCCGetPFIFromMSISDN_call_counter = manager.createAvgFlowPerSecondCollector("Avg_psSTR004UPCCGetPFIFromMSISDN_call_per_second", proxyName); //$NON-NLS-1$
    _avg_psSTR004UPCCPFIFromMSISDN_ExecTime = manager.createAvgDoubleCollectorItem("Avg_psSTR004UPCCGetPFIFromMSISDN_ExecTime", proxyName); //$NON-NLS-1$

    _avg_psSTR005UPCCGetIMSIFromPFI_call_counter = manager.createAvgFlowPerSecondCollector("Avg_psSTR005UPCCGetIMSIFromPFI_call_per_second", proxyName); //$NON-NLS-1$
    _avg_psSTR005UPCCGetIMSIFromPFI_ExecTime = manager.createAvgDoubleCollectorItem("Avg_psSTR005UPCCGetIMSIFromPFI_ExecTime", proxyName); //$NON-NLS-1$

    _avg_psSTR006UPCCGetIDTPFSFromPFI_call_counter = manager.createAvgFlowPerSecondCollector("Avg_psSTR006UPCCGetIDTPFSFromPFI_call_per_second", proxyName); //$NON-NLS-1$
    _avg_psSTR006UPCCGetIDTPFSFromPFI_ExecTime = manager.createAvgDoubleCollectorItem("Avg_psSTR006UPCCGetIDTPFSFromPFI_ExecTime", proxyName); //$NON-NLS-1$

    _avg_psSTR007GetTSMDataByMSISDN_call_counter = manager.createAvgFlowPerSecondCollector("Avg_psSTR007GetTSMDataByMSISDN_call_per_second", proxyName); //$NON-NLS-1$
    _avg_psSTR007GetTSMDataByMSISDN_ExecTime = manager.createAvgDoubleCollectorItem("Avg_psSTR007GetTSMDataByMSISDN_ExecTime", proxyName); //$NON-NLS-1$

    _avg_psSTR008GetTSMDataByIMSI_call_counter = manager.createAvgFlowPerSecondCollector("Avg_psSTR008GetTSMDataByIMSI_call_per_second", proxyName); //$NON-NLS-1$
    _avg_psSTR008GetTSMDataByIMSI_ExecTime = manager.createAvgDoubleCollectorItem("Avg_psSTR008GetTSMDataByIMSI_ExecTime", proxyName); //$NON-NLS-1$

    _avg_psSTR009ConsultLineStatus_call_counter = manager.createAvgFlowPerSecondCollector("Avg_psSTR009ConsultLineStatus_call_per_second", proxyName); //$NON-NLS-1$
    _avg_psSTR009ConsultLineStatus_ExecTime = manager.createAvgDoubleCollectorItem("Avg_psSTR009ConsultLineStatus_ExecTime", proxyName); //$NON-NLS-1$

    _avg_psSTR010ConsultLigneDeMarche_call_counter = manager.createAvgFlowPerSecondCollector("Avg_psSTR010ConsultLigneDeMarche_call_per_second", proxyName); //$NON-NLS-1$
    _avg_psSTR010ConsultLigneDeMarche_ExecTime = manager.createAvgDoubleCollectorItem("Avg_psSTR010ConsultLigneDeMarche_ExecTime", proxyName); //$NON-NLS-1$

    _avg_psSTR011GetPFIFromIMSI_call_counter = manager.createAvgFlowPerSecondCollector("Avg_psSTR011GetPFIFromIMSI_call_per_second", proxyName); //$NON-NLS-1$
    _avg_psSTR011GetPFIFromIMSI_ExecTime = manager.createAvgDoubleCollectorItem("Avg_psSTR011GetPFIFromIMSI_ExecTime", proxyName); //$NON-NLS-1$

    _avg_psSTR012GetMSISDNFromPFI_call_counter = manager.createAvgFlowPerSecondCollector("Avg_psSTR012GetMSISDNFromPFI_call_per_second", proxyName); //$NON-NLS-1$
    _avg_psSTR012GetMSISDNFromPFI_ExecTime = manager.createAvgDoubleCollectorItem("Avg_psSTR012GetMSISDNFromPFI_ExecTime", proxyName); //$NON-NLS-1$

    _avg_psSTR013GetMSISDNBDUOFromPFI_call_counter = manager.createAvgFlowPerSecondCollector("Avg_psSTR013GetMSISDNBDUOFromPFI_call_per_second", proxyName); //$NON-NLS-1$
    _avg_psSTR013GetMSISDNBDUOFromPFI_ExecTime = manager.createAvgDoubleCollectorItem("Avg_psSTR013GetMSISDNBDUOFromPFI_ExecTime", proxyName); //$NON-NLS-1$

    _avg_psSTR014GetSVCTECACCFromPFI_call_counter = manager.createAvgFlowPerSecondCollector("Avg_psSTR014GetSVCTECACCFromPFI_call_per_second", proxyName); //$NON-NLS-1$
    _avg_psSTR014GetSVCTECACCFromPFI_ExecTime = manager.createAvgDoubleCollectorItem("Avg_psSTR014GetSVCTECACCFromPFI_ExecTime", proxyName); //$NON-NLS-1$

    _avg_psSTR015GetPARSVCTECACC_call_counter = manager.createAvgFlowPerSecondCollector("Avg_psSTR015GetPARSVCTECACC_call_per_second", proxyName); //$NON-NLS-1$
    _avg_psSTR015GetPARSVCTECACC_ExecTime = manager.createAvgDoubleCollectorItem("Avg_psSTR015GetPARSVCTECACC_ExecTime", proxyName); //$NON-NLS-1$

    _avg_psSTR015GetPARSVCTECACC_call_counter = manager.createAvgFlowPerSecondCollector("Avg_psSTR015GetPARSVCTECACC_call_per_second", proxyName); //$NON-NLS-1$
    _avg_psSTR015GetPARSVCTECACC_ExecTime = manager.createAvgDoubleCollectorItem("Avg_psSTR015GetPARSVCTECACC_ExecTime", proxyName); //$NON-NLS-1$

    _avg_psSTR016GetCustomerIdentity_call_counter = manager.createAvgFlowPerSecondCollector("Avg_psSTR016GetCustomerIdentity_call_per_second", proxyName); //$NON-NLS-1$
    _avg_psSTR016GetCustomerIdentity_ExecTime = manager.createAvgDoubleCollectorItem("Avg_psSTR016GetCustomerIdentity_ExecTime", proxyName); //$NON-NLS-1$

    _avg_psSTR113CHECK_PARAPNTACC_FromVP_call_counter = manager.createAvgFlowPerSecondCollector("Avg_psSTR113CHECK_PARAPNTACC_FromVP_call_per_second", proxyName); //$NON-NLS-1$
    _avg_psSTR113CHECK_PARAPNTACC_FromVP_ExecTime = manager.createAvgDoubleCollectorItem("Avg_psSTR113CHECK_PARAPNTACC_FromVP_ExecTime", proxyName); //$NON-NLS-1$

    _avg_psSTR017InsertUDCHEMSSDP_call_counter = manager.createAvgFlowPerSecondCollector("Avg_psSTR017InsertUDCHEMSSDP_call_per_second", proxyName); //$NON-NLS-1$
    _avg_psSTR017InsertUDCHEMSSDP_ExecTime = manager.createAvgDoubleCollectorItem("Avg_psSTR017InsertUDCHEMSSDP_ExecTime", proxyName); //$NON-NLS-1$

    _avg_psSTR018InsertUDCHEMSPDP_call_counter = manager.createAvgFlowPerSecondCollector("Avg_psSTR018InsertUDCHEMSPDP_call_per_second", proxyName); //$NON-NLS-1$
    _avg_psSTR018InsertUDCHEMSPDP_ExecTime = manager.createAvgDoubleCollectorItem("Avg_psSTR018InsertUDCHEMSPDP_ExecTime", proxyName); //$NON-NLS-1$

    _avg_psSTR019InsertUDCHEMSCMP_call_counter = manager.createAvgFlowPerSecondCollector("Avg_psSTR019InsertUDCHEMSCMP_call_per_second", proxyName); //$NON-NLS-1$
    _avg_psSTR019InsertUDCHEMSCMP_ExecTime = manager.createAvgDoubleCollectorItem("Avg_psSTR019InsertUDCHEMSCMP_ExecTime", proxyName); //$NON-NLS-1$

    _avg_psSTR020GetSTRHEMSSDP_call_counter = manager.createAvgFlowPerSecondCollector("Avg_psSTR020GetSTRHEMSSDP_call_per_second", proxyName); //$NON-NLS-1$
    _avg_psSTR020GetSTRHEMSSDP_ExecTime = manager.createAvgDoubleCollectorItem("Avg_psSTR020GetSTRHEMSSDP_ExecTime", proxyName); //$NON-NLS-1$

    _avg_psSTR021AuditHEMSSDP_call_counter = manager.createAvgFlowPerSecondCollector("Avg_psSTR021AuditHEMSSDP_call_per_second", proxyName); //$NON-NLS-1$
    _avg_psSTR021AuditHEMSSDP_ExecTime = manager.createAvgDoubleCollectorItem("Avg_psSTR021AuditHEMSSDP_ExecTime", proxyName); //$NON-NLS-1$

    _avg_psSTR022GetSTRHEMSPDP_call_counter = manager.createAvgFlowPerSecondCollector("Avg_psSTR022GetSTRHEMSPDP_call_per_second", proxyName); //$NON-NLS-1$
    _avg_psSTR022GetSTRHEMSPDP_ExecTime = manager.createAvgDoubleCollectorItem("Avg_psSTR022GetSTRHEMSPDP_ExecTime", proxyName); //$NON-NLS-1$

    _avg_psSTR023GetSTRHEMSCMP_call_counter = manager.createAvgFlowPerSecondCollector("Avg_psSTR023GetSTRHEMSCMP_call_per_second", proxyName); //$NON-NLS-1$
    _avg_psSTR023GetSTRHEMSCMP_ExecTime = manager.createAvgDoubleCollectorItem("Avg_psSTR023GetSTRHEMSCMP_ExecTime", proxyName); //$NON-NLS-1$

    _avg_psSTR024AuditHEMSCMP_call_counter = manager.createAvgFlowPerSecondCollector("Avg_psSTR024AuditHEMSCMP_call_per_second", proxyName); //$NON-NLS-1$
    _avg_psSTR024AuditHEMSCMP_ExecTime = manager.createAvgDoubleCollectorItem("Avg_psSTR024AuditHEMSCMP_ExecTime", proxyName); //$NON-NLS-1$

    _avg_psSTR025AuditHEMSPDP_call_counter = manager.createAvgFlowPerSecondCollector("Avg_psSTR025AuditHEMSPDP_call_per_second", proxyName); //$NON-NLS-1$
    _avg_psSTR025AuditHEMSPDP_ExecTime = manager.createAvgDoubleCollectorItem("Avg_psSTR025AuditHEMSPDP_ExecTime", proxyName); //$NON-NLS-1$

    _avg_psSTR026GetPfiFromMsisdn_call_counter = manager.createAvgFlowPerSecondCollector("Avg_psSTR026GetPfiFromMsisdn_call_per_second", proxyName); //$NON-NLS-1$
    _avg_psSTR026GetPfiFromMsisdn_ExecTime = manager.createAvgDoubleCollectorItem("Avg_psSTR026GetPfiFromMsisdn_ExecTime", proxyName); //$NON-NLS-1$

    _avg_truncateTableAuditUDC_call_counter = manager.createAvgFlowPerSecondCollector("Avg_STRtruncateTableAuditUDC_call_per_second", proxyName); //$NON-NLS-1$
    _avg_truncateTableAuditUDC_ExecTime = manager.createAvgDoubleCollectorItem("Avg_STRtruncateTableAuditUDC_ExecTime", proxyName); //$NON-NLS-1$

    _avg_psGetProfilsPirelliParLM_call_counter = manager.createAvgFlowPerSecondCollector("Avg_psGetProfilsPirelliParLM_call_per_second", proxyName); //$NON-NLS-1$
    _avg_psGetProfilsPirelliParLM_ExecTime = manager.createAvgDoubleCollectorItem("Avg_psGetProfilsPirelliParLM_ExecTime", proxyName); //$NON-NLS-1$

    _avg_psGetProfilsThePoliceParLM_call_counter = manager.createAvgFlowPerSecondCollector("Avg_psGetProfilsThePoliceParLM_call_per_second", proxyName); //$NON-NLS-1$
    _avg_psGetProfilsThePoliceParLM_ExecTime = manager.createAvgDoubleCollectorItem("Avg_psGetProfilsThePoliceParLM_ExecTime", proxyName); //$NON-NLS-1$

    _avg_psRecupererNoContratParNoTelephone_call_counter = manager.createAvgFlowPerSecondCollector("Avg_psRecupererNoContratParNoTelephone_call_per_second", proxyName); //$NON-NLS-1$
    _avg_psRecupererNoContratParNoTelephone_ExecTime = manager.createAvgDoubleCollectorItem("Avg_psRecupererNoContratParNoTelephone_ExecTime", proxyName); //$NON-NLS-1$

    _avg_psRecupererTypeVms_call_counter = manager.createAvgFlowPerSecondCollector("Avg_psRecupererTypeVms_call_per_second", proxyName); //$NON-NLS-1$
    _avg_psRecupererTypeVms_ExecTime = manager.createAvgDoubleCollectorItem("Avg_psRecupererTypeVms_ExecTime", proxyName); //$NON-NLS-1$

    _avg_psGetParpntaccByPfi_call_counter = manager.createAvgFlowPerSecondCollector("Avg_psGetParpntaccByPfi_call_per_second", proxyName); //NON-NLS
    _avg_psGetParpntaccByPfi_ExecTime = manager.createAvgDoubleCollectorItem("Avg_psGetParpntaccByPfi_ExecTime", proxyName); //NON-NLS

    _avg_migrerStaStwVersVstw_call_counter = manager.createAvgFlowPerSecondCollector("Avg_migrerStaStwVersVstw_call_per_second", proxyName); //NON-NLS
    _avg_migrerStaStwVersVstw_ExecTime = manager.createAvgDoubleCollectorItem("Avg_migrerStaStwVersVstw_ExecTime", proxyName); //NON-NLS

    _avg_inhiberStaStw_call_counter = manager.createAvgFlowPerSecondCollector("Avg_inhiberStaStw_call_per_second", proxyName); //NON-NLS
    _avg_inhiberStaStw_ExecTime = manager.createAvgDoubleCollectorItem("Avg_inhiberStaStw_ExecTime", proxyName); //NON-NLS

    _avg_annulerMigrerStaStwVersVstw_call_counter = manager.createAvgFlowPerSecondCollector("Avg_annulerMigrerStaStwVersVstw_call_per_second", proxyName); //NON-NLS
    _avg_annulerMigrerStaStwVersVstw_ExecTime = manager.createAvgDoubleCollectorItem("Avg_annulerMigrerStaStwVersVstw_ExecTime", proxyName); //NON-NLS

  }

  @Override
  public ConnectorResponse<Integer, Retour> auditHEMSCMP(Tracabilite tracabilite_p, IDataCallBack dataCallBack_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Integer, Retour>>(ISTRConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Integer, Retour> run() throws RavelException
      {
        ISTRConnector connector = (ISTRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_psSTR024AuditHEMSCMP_call_counter.measure();
        long startTime = System.currentTimeMillis();

        try
        {
          ConnectorResponse<Integer, Retour> response = connector.auditHEMSCMP(tracabilite_p, dataCallBack_p);
          return response;
        }
        finally
        {
          Long endTime = System.currentTimeMillis();
          _avg_psSTR024AuditHEMSCMP_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Integer, Retour> auditHEMSPDP(Tracabilite tracabilite_p, IDataCallBack dataCallBack_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Integer, Retour>>(ISTRConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Integer, Retour> run() throws RavelException
      {
        ISTRConnector connector = (ISTRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_psSTR025AuditHEMSPDP_call_counter.measure();
        long startTime = System.currentTimeMillis();

        try
        {
          ConnectorResponse<Integer, Retour> response = connector.auditHEMSPDP(tracabilite_p, dataCallBack_p);
          return response;
        }
        finally
        {
          Long endTime = System.currentTimeMillis();
          _avg_psSTR025AuditHEMSPDP_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Integer, Retour> auditHEMSSDP(Tracabilite tracabilite_p, IDataCallBack dataCallBack_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Integer, Retour>>(ISTRConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Integer, Retour> run() throws RavelException
      {
        ISTRConnector connector = (ISTRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_psSTR021AuditHEMSSDP_call_counter.measure();
        long startTime = System.currentTimeMillis();

        try
        {
          ConnectorResponse<Integer, Retour> response = connector.auditHEMSSDP(tracabilite_p, dataCallBack_p);
          return response;
        }
        finally
        {
          Long endTime = System.currentTimeMillis();
          _avg_psSTR021AuditHEMSSDP_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Boolean, Retour> checkPARPNTACCFromVP(Tracabilite tracabilite_p, String imsi_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Boolean, Retour>>(ISTRConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Boolean, Retour> run() throws RavelException
      {
        ISTRConnector connector = (ISTRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_psSTR113CHECK_PARAPNTACC_FromVP_call_counter.measure();
        long startTime = System.currentTimeMillis();

        try
        {
          ConnectorResponse<Boolean, Retour> response = connector.checkPARPNTACCFromVP(tracabilite_p, imsi_p);
          return response;
        }
        finally
        {
          Long endTime = System.currentTimeMillis();
          _avg_psSTR113CHECK_PARAPNTACC_FromVP_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<List<LigneMarcheData>, Retour> consultLigneDeMarche(Tracabilite tracabilite_p, String imsi_p, String msisdn_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<List<LigneMarcheData>, Retour>>(ISTRConnector.BEAN_ID)
    {

      @Override
      public ConnectorResponse<List<LigneMarcheData>, Retour> run() throws RavelException
      {
        ISTRConnector connector = (ISTRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_psSTR010ConsultLigneDeMarche_call_counter.measure();
        long startTime = System.currentTimeMillis();

        try
        {
          return connector.consultLigneDeMarche(tracabilite_p, imsi_p, msisdn_p);
        }
        finally
        {
          Long endTime = System.currentTimeMillis();
          _avg_psSTR010ConsultLigneDeMarche_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<List<LineStatusData>, Retour> consultLineStatus(Tracabilite tracabilite_p, String imsi_p, String msisdn_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<List<LineStatusData>, Retour>>(ISTRConnector.BEAN_ID)
    {

      @Override
      public ConnectorResponse<List<LineStatusData>, Retour> run() throws RavelException
      {
        ISTRConnector connector = (ISTRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_psSTR009ConsultLineStatus_call_counter.measure();
        long startTime = System.currentTimeMillis();

        try
        {
          ConnectorResponse<List<LineStatusData>, Retour> response = connector.consultLineStatus(tracabilite_p, imsi_p, msisdn_p);
          return response;
        }
        finally
        {
          Long endTime = System.currentTimeMillis();
          _avg_psSTR009ConsultLineStatus_ExecTime.updateAvgValue(endTime - startTime);
        }

      }
    });
  }

  @Override
  public ConnectorResponse<DonneesClient, Retour> getCustomerIdentity(Tracabilite tracabilite_p, String msisdn_p, String imsi_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<DonneesClient, Retour>>(ISTRConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<DonneesClient, Retour> run() throws RavelException
      {
        ISTRConnector connector = (ISTRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_psSTR016GetCustomerIdentity_call_counter.measure();
        long startTime = System.currentTimeMillis();

        try
        {
          ConnectorResponse<DonneesClient, Retour> response = connector.getCustomerIdentity(tracabilite_p, msisdn_p, imsi_p);
          return response;
        }
        finally
        {
          Long endTime = System.currentTimeMillis();
          _avg_psSTR016GetCustomerIdentity_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<String, Retour> getMSISDNBDUOFromPFI(Tracabilite tracabilite_p, String pfi_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<String, Retour>>(ISTRConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<String, Retour> run() throws RavelException
      {
        ISTRConnector connector = (ISTRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_psSTR013GetMSISDNBDUOFromPFI_call_counter.measure();
        long startTime = System.currentTimeMillis();

        try
        {
          ConnectorResponse<String, Retour> response = connector.getMSISDNBDUOFromPFI(tracabilite_p, pfi_p);
          return response;
        }
        finally
        {
          Long endTime = System.currentTimeMillis();
          _avg_psSTR013GetMSISDNBDUOFromPFI_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<String, Retour> getMSISDNFromPFI(Tracabilite tracabilite_p, String pfi_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<String, Retour>>(ISTRConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<String, Retour> run() throws RavelException
      {
        ISTRConnector connector = (ISTRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_psSTR012GetMSISDNFromPFI_call_counter.measure();
        long startTime = System.currentTimeMillis();

        try
        {
          ConnectorResponse<String, Retour> response = connector.getMSISDNFromPFI(tracabilite_p, pfi_p);
          return response;
        }
        finally
        {
          Long endTime = System.currentTimeMillis();
          _avg_psSTR012GetMSISDNFromPFI_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<List<ParamSrvTech>, Retour> getPARSVCTECACC(Tracabilite tracabilite_p, long idSrvTech_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<List<ParamSrvTech>, Retour>>(ISTRConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<List<ParamSrvTech>, Retour> run() throws RavelException
      {
        ISTRConnector connector = (ISTRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_psSTR015GetPARSVCTECACC_call_counter.measure();
        long startTime = System.currentTimeMillis();

        try
        {
          ConnectorResponse<List<ParamSrvTech>, Retour> response = connector.getPARSVCTECACC(tracabilite_p, idSrvTech_p);
          return response;
        }
        finally
        {
          Long endTime = System.currentTimeMillis();
          _avg_psSTR015GetPARSVCTECACC_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<String, Retour> getPFIFromIMSI(Tracabilite tracabilite_p, String imsi_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<String, Retour>>(ISTRConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<String, Retour> run() throws RavelException
      {
        ISTRConnector connector = (ISTRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_psSTR011GetPFIFromIMSI_call_counter.measure();
        long startTime = System.currentTimeMillis();

        try
        {
          ConnectorResponse<String, Retour> response = connector.getPFIFromIMSI(tracabilite_p, imsi_p);
          return response;
        }
        finally
        {
          Long endTime = System.currentTimeMillis();
          _avg_psSTR011GetPFIFromIMSI_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override public ConnectorResponse<List<Parpntacc>, Retour> getParpntaccByPfi(Tracabilite tracabilite_p, String pfi_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<List<Parpntacc>, Retour>>(ISTRConnector.BEAN_ID)
    {
      @Override public ConnectorResponse<List<Parpntacc>, Retour> run() throws RavelException
      {
        ISTRConnector connector = (ISTRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_psGetParpntaccByPfi_call_counter.measure();
        long startTime = System.currentTimeMillis();

        try
        {
          ConnectorResponse<List<Parpntacc>, Retour> response = connector.getParpntaccByPfi(tracabilite_p, pfi_p);
          return response;
        }
        finally
        {
          Long endTime = System.currentTimeMillis();
          _avg_psGetParpntaccByPfi_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<String, Retour> getPfiFromMsisdn(Tracabilite tracabilite_p, String msisdn_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<String, Retour>>(ISTRConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<String, Retour> run() throws RavelException
      {
        ISTRConnector connector = (ISTRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_psSTR026GetPfiFromMsisdn_call_counter.measure();
        long startTime = System.currentTimeMillis();

        try
        {
          ConnectorResponse<String, Retour> response = connector.getPfiFromMsisdn(tracabilite_p, msisdn_p);
          return response;
        }
        finally
        {
          Long endTime = System.currentTimeMillis();
          _avg_psSTR026GetPfiFromMsisdn_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<List<InfoProfil>, Retour> getProfilsPirelliParLM(Tracabilite tracabilite_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<List<InfoProfil>, Retour>>(ISTRConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<List<InfoProfil>, Retour> run() throws RavelException
      {
        ISTRConnector connector = (ISTRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_psGetProfilsPirelliParLM_call_counter.measure();
        long startTime = System.currentTimeMillis();

        try
        {
          ConnectorResponse<List<InfoProfil>, Retour> response = connector.getProfilsPirelliParLM(tracabilite_p);
          return response;
        }
        finally
        {
          Long endTime = System.currentTimeMillis();
          _avg_psGetProfilsPirelliParLM_ExecTime.updateAvgValue(endTime - startTime);
        }

      }
    });
  }

  @Override
  public ConnectorResponse<List<InfoProfil>, Retour> getProfilsThePoliceParLM(Tracabilite tracabilite_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<List<InfoProfil>, Retour>>(ISTRConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<List<InfoProfil>, Retour> run() throws RavelException
      {
        ISTRConnector connector = (ISTRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_psGetProfilsThePoliceParLM_call_counter.measure();
        long startTime = System.currentTimeMillis();

        try
        {
          ConnectorResponse<List<InfoProfil>, Retour> response = connector.getProfilsThePoliceParLM(tracabilite_p);
          return response;
        }
        finally
        {
          Long endTime = System.currentTimeMillis();
          _avg_psGetProfilsThePoliceParLM_ExecTime.updateAvgValue(endTime - startTime);
        }

      }
    });
  }

  @Override
  public ConnectorResponse<Boolean, Retour> getSTRHEMSCMP(Tracabilite tracabilite_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Boolean, Retour>>(ISTRConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Boolean, Retour> run() throws RavelException
      {
        ISTRConnector connector = (ISTRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_psSTR023GetSTRHEMSCMP_call_counter.measure();
        long startTime = System.currentTimeMillis();

        try
        {
          ConnectorResponse<Boolean, Retour> response = connector.getSTRHEMSCMP(tracabilite_p);
          return response;
        }
        finally
        {
          Long endTime = System.currentTimeMillis();
          _avg_psSTR023GetSTRHEMSCMP_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Boolean, Retour> getSTRHEMSPDP(Tracabilite tracabilite_p, String imsi_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Boolean, Retour>>(ISTRConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Boolean, Retour> run() throws RavelException
      {
        ISTRConnector connector = (ISTRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_psSTR022GetSTRHEMSPDP_call_counter.measure();
        long startTime = System.currentTimeMillis();

        try
        {
          ConnectorResponse<Boolean, Retour> response = connector.getSTRHEMSPDP(tracabilite_p, imsi_p);
          return response;
        }
        finally
        {
          Long endTime = System.currentTimeMillis();
          _avg_psSTR022GetSTRHEMSPDP_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Boolean, Retour> getSTRHEMSSDP(Tracabilite tracabilite_p, String imsi_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Boolean, Retour>>(ISTRConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Boolean, Retour> run() throws RavelException
      {
        ISTRConnector connector = (ISTRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_psSTR020GetSTRHEMSSDP_call_counter.measure();
        long startTime = System.currentTimeMillis();

        try
        {
          ConnectorResponse<Boolean, Retour> response = connector.getSTRHEMSSDP(tracabilite_p, imsi_p);
          return response;
        }
        finally
        {
          Long endTime = System.currentTimeMillis();
          _avg_psSTR020GetSTRHEMSSDP_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<List<ServiceTechniqueSTR>, Retour> getSVCTECACCFromPFI(Tracabilite tracabilite_p, String pfi_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<List<ServiceTechniqueSTR>, Retour>>(ISTRConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<List<ServiceTechniqueSTR>, Retour> run() throws RavelException
      {
        ISTRConnector connector = (ISTRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_psSTR014GetSVCTECACCFromPFI_call_counter.measure();
        long startTime = System.currentTimeMillis();

        try
        {
          ConnectorResponse<List<ServiceTechniqueSTR>, Retour> response = connector.getSVCTECACCFromPFI(tracabilite_p, pfi_p);
          return response;
        }
        finally
        {
          Long endTime = System.currentTimeMillis();
          _avg_psSTR014GetSVCTECACCFromPFI_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<List<TSMData>, Retour> getTSMDataByIMSI(Tracabilite tracabilite_p, String imsi_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<List<TSMData>, Retour>>(ISTRConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<List<TSMData>, Retour> run() throws RavelException
      {
        ISTRConnector connector = (ISTRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_psSTR008GetTSMDataByIMSI_call_counter.measure();
        long startTime = System.currentTimeMillis();

        try
        {
          ConnectorResponse<List<TSMData>, Retour> response = connector.getTSMDataByIMSI(tracabilite_p, imsi_p);
          return response;
        }
        finally
        {
          Long endTime = System.currentTimeMillis();
          _avg_psSTR008GetTSMDataByIMSI_ExecTime.updateAvgValue(endTime - startTime);
        }

      }
    });
  }

  @Override
  public ConnectorResponse<List<TSMData>, Retour> getTSMDataByMSISDN(Tracabilite tracabilite_p, String msisdn_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<List<TSMData>, Retour>>(ISTRConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<List<TSMData>, Retour> run() throws RavelException
      {
        ISTRConnector connector = (ISTRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_psSTR007GetTSMDataByMSISDN_call_counter.measure();
        long startTime = System.currentTimeMillis();

        try
        {
          ConnectorResponse<List<TSMData>, Retour> response = connector.getTSMDataByMSISDN(tracabilite_p, msisdn_p);
          return response;
        }
        finally
        {
          Long endTime = System.currentTimeMillis();
          _avg_psSTR007GetTSMDataByMSISDN_ExecTime.updateAvgValue(endTime - startTime);
        }

      }
    });
  }

  @Override
  public ConnectorResponse<Boolean, Retour> insertUDCHEMSCMP(Tracabilite tracabilite_p, List<AuditUDCHEMSCMP> listAuditUDCHEMSCMP_p, int batchSize) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Boolean, Retour>>(ISTRConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Boolean, Retour> run() throws RavelException
      {
        ISTRConnector connector = (ISTRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_psSTR019InsertUDCHEMSCMP_call_counter.measure();
        long startTime = System.currentTimeMillis();

        try
        {
          ConnectorResponse<Boolean, Retour> response = connector.insertUDCHEMSCMP(tracabilite_p, listAuditUDCHEMSCMP_p, batchSize);
          return response;
        }
        finally
        {
          Long endTime = System.currentTimeMillis();
          _avg_psSTR019InsertUDCHEMSCMP_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Boolean, Retour> insertUDCHEMSPDP(Tracabilite tracabilite_p, List<AuditUDCHEMSPDP> listAuditUDCHemSPDP_p, int batchSize) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Boolean, Retour>>(ISTRConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Boolean, Retour> run() throws RavelException
      {
        ISTRConnector connector = (ISTRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_psSTR018InsertUDCHEMSPDP_call_counter.measure();
        long startTime = System.currentTimeMillis();

        try
        {
          ConnectorResponse<Boolean, Retour> response = connector.insertUDCHEMSPDP(tracabilite_p, listAuditUDCHemSPDP_p, batchSize);
          return response;
        }
        finally
        {
          Long endTime = System.currentTimeMillis();
          _avg_psSTR018InsertUDCHEMSPDP_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Boolean, Retour> insertUDCHEMSSDP(Tracabilite tracabilite_p, List<AuditUDCHEMSSDP> listAuditUDCHemSSDP_p, int batchSize) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Boolean, Retour>>(ISTRConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Boolean, Retour> run() throws RavelException
      {
        ISTRConnector connector = (ISTRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_psSTR017InsertUDCHEMSSDP_call_counter.measure();
        long startTime = System.currentTimeMillis();

        try
        {
          ConnectorResponse<Boolean, Retour> response = connector.insertUDCHEMSSDP(tracabilite_p, listAuditUDCHemSSDP_p, batchSize);
          return response;
        }
        finally
        {
          Long endTime = System.currentTimeMillis();
          _avg_psSTR017InsertUDCHEMSSDP_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<ResultContratEtPartition, Retour> recupererNoContratParNoTelephone(Tracabilite tracabilite_p, String noTelephone_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<ResultContratEtPartition, Retour>>(ISTRConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<ResultContratEtPartition, Retour> run() throws RavelException
      {
        ISTRConnector connector = (ISTRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_psRecupererNoContratParNoTelephone_call_counter.measure();
        long startTime = System.currentTimeMillis();

        try
        {
          ConnectorResponse<ResultContratEtPartition, Retour> response = connector.recupererNoContratParNoTelephone(tracabilite_p, noTelephone_p);
          return response;
        }
        finally
        {
          Long endTime = System.currentTimeMillis();
          _avg_psRecupererNoContratParNoTelephone_ExecTime.updateAvgValue(endTime - startTime);
        }

      }

    });
  }

  @Override
  public ConnectorResponse<String, Retour> recupererTypeVms(Tracabilite tracabilite_p, String noTelephone_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<String, Retour>>(ISTRConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<String, Retour> run() throws RavelException
      {
        ISTRConnector connector = (ISTRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_psRecupererTypeVms_call_counter.measure();
        long startTime = System.currentTimeMillis();

        try
        {
          ConnectorResponse<String, Retour> response = connector.recupererTypeVms(tracabilite_p, noTelephone_p);
          return response;
        }
        finally
        {
          Long endTime = System.currentTimeMillis();
          _avg_psRecupererTypeVms_ExecTime.updateAvgValue(endTime - startTime);
        }

      }

    });
  }

  @Override
  public ConnectorResponse<Boolean, Retour> truncateTableAuditUDC(Tracabilite tracabilite_p, String commande_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Boolean, Retour>>(ISTRConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Boolean, Retour> run() throws RavelException
      {
        ISTRConnector connector = (ISTRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_truncateTableAuditUDC_call_counter.measure();
        long startTime = System.currentTimeMillis();

        try
        {
          ConnectorResponse<Boolean, Retour> response = connector.truncateTableAuditUDC(tracabilite_p, commande_p);
          return response;
        }
        finally
        {
          Long endTime = System.currentTimeMillis();
          _avg_truncateTableAuditUDC_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<String, Retour> upccGetIDTPFSFromPFI(Tracabilite tracabilite_p, String pfi_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<String, Retour>>(ISTRConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<String, Retour> run() throws RavelException
      {
        ISTRConnector connector = (ISTRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_psSTR006UPCCGetIDTPFSFromPFI_call_counter.measure();
        long startTime = System.currentTimeMillis();

        try
        {
          ConnectorResponse<String, Retour> response = connector.upccGetIDTPFSFromPFI(tracabilite_p, pfi_p);
          return response;
        }
        finally
        {
          Long endTime = System.currentTimeMillis();
          _avg_psSTR006UPCCGetIDTPFSFromPFI_ExecTime.updateAvgValue(endTime - startTime);
        }

      }
    });
  }

  @Override
  public ConnectorResponse<String, Retour> upccGetIMSIFromPFI(Tracabilite tracabilite_p, String pfi_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<String, Retour>>(ISTRConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<String, Retour> run() throws RavelException
      {
        ISTRConnector connector = (ISTRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_psSTR005UPCCGetIMSIFromPFI_call_counter.measure();
        long startTime = System.currentTimeMillis();

        try
        {
          ConnectorResponse<String, Retour> response = connector.upccGetIMSIFromPFI(tracabilite_p, pfi_p);
          return response;
        }
        finally
        {
          Long endTime = System.currentTimeMillis();
          _avg_psSTR005UPCCGetIMSIFromPFI_ExecTime.updateAvgValue(endTime - startTime);
        }

      }
    });
  }

  @Override
  public ConnectorResponse<String, Retour> upccGetPFIFromMSISDN(Tracabilite tracabilite_p, String msisdn_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<String, Retour>>(ISTRConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<String, Retour> run() throws RavelException
      {
        ISTRConnector connector = (ISTRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_psSTR004UPCCGetPFIFromMSISDN_call_counter.measure();
        long startTime = System.currentTimeMillis();

        try
        {
          ConnectorResponse<String, Retour> response = connector.upccGetPFIFromMSISDN(tracabilite_p, msisdn_p);
          return response;
        }
        finally
        {
          Long endTime = System.currentTimeMillis();
          _avg_psSTR004UPCCPFIFromMSISDN_ExecTime.updateAvgValue(endTime - startTime);
        }

      }
    });
  }

  @Override
  public ConnectorResponse<MigrerStaStwVersVstwResponse, Retour> migrerStaStwVersVstw(Tracabilite tracabilite_p, StMediaBox stmediaBox_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<MigrerStaStwVersVstwResponse, Retour>>(ISTRConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<MigrerStaStwVersVstwResponse, Retour> run() throws RavelException
      {
        ISTRConnector connector = (ISTRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_migrerStaStwVersVstw_call_counter.measure();
        long startTime = System.currentTimeMillis();

        try
        {
          ConnectorResponse<MigrerStaStwVersVstwResponse, Retour> response = connector.migrerStaStwVersVstw(tracabilite_p, stmediaBox_p);
          return response;
        }
        finally
        {
          Long endTime = System.currentTimeMillis();
          _avg_migrerStaStwVersVstw_ExecTime.updateAvgValue(endTime - startTime);
        }

      }
    });
  }

  @Override
  public ConnectorResponse<Nothing, Retour> inhiberStaStw(Tracabilite tracabilite_p, String noTelephone_p, String idtDerMod_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Nothing, Retour>>(ISTRConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Nothing, Retour> run() throws RavelException
      {
        ISTRConnector connector = (ISTRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_inhiberStaStw_call_counter.measure();
        long startTime = System.currentTimeMillis();

        try
        {
          ConnectorResponse<Nothing, Retour> response = connector.inhiberStaStw(tracabilite_p, noTelephone_p, idtDerMod_p);
          return response;
        }
        finally
        {
          Long endTime = System.currentTimeMillis();
          _avg_inhiberStaStw_ExecTime.updateAvgValue(endTime - startTime);
        }

      }
    });
  }

  @Override
  public ConnectorResponse<String, Retour> annulerMigrerStaStwVersVstw(Tracabilite tracabilite_p, String noTelephone_p, String idtDerMod_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<String, Retour>>(ISTRConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<String, Retour> run() throws RavelException
      {
        ISTRConnector connector = (ISTRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_annulerMigrerStaStwVersVstw_call_counter.measure();
        long startTime = System.currentTimeMillis();

        try
        {
          ConnectorResponse<String, Retour> response = connector.annulerMigrerStaStwVersVstw(tracabilite_p, noTelephone_p, idtDerMod_p);
          return response;
        }
        finally
        {
          Long endTime = System.currentTimeMillis();
          _avg_annulerMigrerStaStwVersVstw_ExecTime.updateAvgValue(endTime - startTime);
        }

      }
    });
  }

}
