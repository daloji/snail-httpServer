/*******************************************************************************
* $Id: AuditUDCHEMSPDP.java 8367 2018-07-25 17:01:34Z kbettenc $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.str.structs;

/**
 *
 * @author lmerces
 * @version ($Revision: 8367 $ $Date: 2018-07-25 19:01:34 +0200 (mer. 25 juil. 2018) $)
 */
public class AuditUDCHEMSPDP
{
  /**
   * MSISDN
   */
  private String _msisdn;

  /**
   * IMSI
   */
  private String _imsi;

  /**
   * APNID
   */
  private Integer _apnid;

  /**
   * EQOSID
   */
  private Integer _eqosid;

  /**
   * PDPID
   */
  private Integer _pdpid;

  /**
   * EPDPIND
   */
  private String _epdpind;

  /**
   * Constructor
   */
  public AuditUDCHEMSPDP()
  {
    super();
  }

  /**
   * Constructor
   *
   * @param msisdn_p
   *          MSISDN
   * @param imsi_p
   *          IMSI
   * @param apnid_p
   *          APNID
   * @param eqosid_p
   *          EQOSID
   * @param pdpid_p
   *          PDPIP
   * @param epdpind_p
   *          EPDPIND
   */
  public AuditUDCHEMSPDP(String msisdn_p, String imsi_p, Integer apnid_p, Integer eqosid_p, Integer pdpid_p, String epdpind_p)
  {
    super();
    _msisdn = msisdn_p;
    _imsi = imsi_p;
    _apnid = apnid_p;
    _eqosid = eqosid_p;
    _pdpid = pdpid_p;
    _epdpind = epdpind_p;
  }

  /**
   * @return the apnid
   */
  public Integer getApnid()
  {
    return _apnid;
  }

  /**
   * @return the epdpind
   */
  public String getEpdpind()
  {
    return _epdpind;
  }

  /**
   * @return the eqosid
   */
  public Integer getEqosid()
  {
    return _eqosid;
  }

  /**
   * @return the imsi
   */
  public String getImsi()
  {
    return _imsi;
  }

  /**
   * @return the msisdn
   */
  public String getMsisdn()
  {
    return _msisdn;
  }

  /**
   * @return the pdpid
   */
  public Integer getPdpid()
  {
    return _pdpid;
  }

  /**
   * @param apnid_p
   *          the apnid to set
   */
  public void setApnid(Integer apnid_p)
  {
    _apnid = apnid_p;
  }

  /**
   * @param epdpind_p
   *          the epdpind to set
   */
  public void setEpdpind(String epdpind_p)
  {
    _epdpind = epdpind_p;
  }

  /**
   * @param eqosid_p
   *          the eqosid to set
   */
  public void setEqosid(Integer eqosid_p)
  {
    _eqosid = eqosid_p;
  }

  /**
   * @param imsi_p
   *          the imsi to set
   */
  public void setImsi(String imsi_p)
  {
    _imsi = imsi_p;
  }

  /**
   * @param msisdn_p
   *          the msisdn to set
   */
  public void setMsisdn(String msisdn_p)
  {
    _msisdn = msisdn_p;
  }

  /**
   * @param pdpid_p
   *          the pdpid to set
   */
  public void setPdpid(Integer pdpid_p)
  {
    _pdpid = pdpid_p;
  }
}
