/*******************************************************************************
* $Id: STRConnector.java 51044 2021-04-23 08:25:04Z fbarnabe $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.str;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLRecoverableException;
import java.sql.SQLTimeoutException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.tomcat.jdbc.pool.PoolExhaustedException;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.conf.generated.Param;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionTools;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.services.conf.connector.generated.Connector;
import com.bytel.ravel.services.connector.AbstractDBConnector;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.connectors.str.IDataCallBack.DataCallBackReturn;
import com.bytel.spirit.common.connectors.str.structs.AuditUDCHEMSCMP;
import com.bytel.spirit.common.connectors.str.structs.AuditUDCHEMSPDP;
import com.bytel.spirit.common.connectors.str.structs.AuditUDCHEMSSDP;
import com.bytel.spirit.common.connectors.str.structs.DonneesClient;
import com.bytel.spirit.common.connectors.str.structs.InfoProfil;
import com.bytel.spirit.common.connectors.str.structs.LigneMarcheData;
import com.bytel.spirit.common.connectors.str.structs.LineStatusData;
import com.bytel.spirit.common.connectors.str.structs.MigrerStaStwVersVstwResponse;
import com.bytel.spirit.common.connectors.str.structs.ParamSrvTech;
import com.bytel.spirit.common.connectors.str.structs.Parpntacc;
import com.bytel.spirit.common.connectors.str.structs.ResultAuditHEMSCMP;
import com.bytel.spirit.common.connectors.str.structs.ResultAuditHEMSPDP;
import com.bytel.spirit.common.connectors.str.structs.ResultAuditHEMSSDP;
import com.bytel.spirit.common.connectors.str.structs.ResultContratEtPartition;
import com.bytel.spirit.common.connectors.str.structs.ServiceTechniqueSTR;
import com.bytel.spirit.common.connectors.str.structs.TSMData;
import com.bytel.spirit.common.shared.functional.types.functional.mediaBox.StMediaBox;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

import oracle.jdbc.OracleTypes;

/**
 * Connector STR
 *
 * @author $Author: fcabral $
 * @version ($Revision: 51044 $ $Date: 2021-04-23 10:25:04 +0200 (ven. 23 avril 2021) $)
 */
public class STRConnector extends AbstractDBConnector implements ISTRConnector
{
  /**
   * Defines all mandatory parameters read from configuration file.
   *
   * @author $Author: fcabral $
   * @version ($Revision: 51044 $ $Date: 2021-04-23 10:25:04 +0200 (ven. 23 avril 2021) $)
   */
  protected enum ParameterName
  {
    /**
     * Connect timeout in second
     */
    CONNECT_TIMEOUT_SEC,

    /**
     * The URL parameter.
     */
    DB_CONNECTIONSTRING,

    /**
     * The PASSWORD parameter.
     */
    DB_PASSWORD,

    /**
     * The LOGIN parameter.
     */
    DB_USERNAME,

    /**
     * The POOLSIZE parameter.
     */
    POOLSIZE,

    /**
     * read timeout in second
     */
    READ_TIMEOUT_SEC,

    /**
     * read timeout in second for method STR_024_GetSTRHEMSCMP
     */
    READ_TIMEOUT_SEC_AUDIT_UDC
  }

  public interface ISQLStatement
  {
    String PG_MIGSTW_PR_MIGSTW = "{call PG_MIGSTW.PR_MIGSTW(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) }"; //$NON-NLS-1$
    String PR_INHIBER_ST_VMS = "{call PG_MIGSTW.PR_INHIBER_ST_VMS(?,?,?,?,?,?) }"; //$NON-NLS-1$
    String PR_ANNULER_MIGSTW = "{call PG_MIGSTW.PR_ANNULER_MIGSTW(?,?,?,?,?,?,?) }"; //$NON-NLS-1$
  }

  public interface IMethodName
  {
    String PG_MIGSTW_PR_MIGSTW = "PG_MIGSTW.PR_MIGSTW"; //$NON-NLS-1$
    String PR_INHIBER_ST_VMS = "PG_MIGSTW.PR_INHIBER_ST_VMS"; //$NON-NLS-1$
    String PR_ANNULER_MIGSTW = "PG_MIGSTW.PR_ANNULER_MIGSTW "; //$NON-NLS-1$

  }
  /**
   * Connection failed
   */
  public static final String CONNEXION_FAILED = "CONNEXION_FAILED"; //$NON-NLS-1$

  /**
   * Epic failure during insertion
   */
  public static final String INSERTION_FAILED = "INSERTION_FAILED"; //$NON-NLS-1$

  /**
   * Epic failure during select
   */
  public static final String SELECT_FAILED = "SELECT_FAILED"; //$NON-NLS-1$

  /**
   * Session is unavailable
   */
  public static final String SESSION_UNAVAILABLE = "SESSION_UNAVAILABLE"; //$NON-NLS-1$

  /**
   * Session is unavailable
   */
  public static final String SERVICE_TIERS_INDISPONIBLE = "SERVICE_TIERS_INDISPONIBLE"; //$NON-NLS-1$

  /**
   * Connect timeout in seconds
   */
  private int _connectTimeoutSec;

  /**
   * Parameters read from configuration.
   */
  private Map<ParameterName, String> _parameters = new HashMap<>();

  /**
   * Read timeout in seconds
   */
  private int _readTimeoutSec;

  /**
   * Read timeout in seconds for method STR_024_GetSTRHEMSCMP
   */
  private int _readTimeoutSecAuditUDC;

  @Override
  public ConnectorResponse<Integer, Retour> auditHEMSCMP(Tracabilite tracabilite_p, IDataCallBack dataCallBack_p) throws RavelException
  {
    Connection con = null;
    ResultSet rs = null;
    final String methodName = "PG_IWSRESSOURCES.P_016_AUDIT_HEMSCMP"; //$NON-NLS-1$
    _dsReadLock.lock();

    try
    {
      con = _datasource.getConnection();

      RavelLogger.log(new SpiritLogEvent(LogSeverity.INFO, tracabilite_p, methodName));

      CallableStatement cs = con.prepareCall("{call PG_IWSRESSOURCES.P_016_AUDIT_HEMSCMP(?,?,?,?,?) }"); //$NON-NLS-1$
      cs.setQueryTimeout(_readTimeoutSecAuditUDC);

      cs.registerOutParameter("po_RESULT", OracleTypes.CURSOR); //$NON-NLS-1$
      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();

      Retour retour = getRetour(cs);

      rs = (ResultSet) cs.getObject("po_RESULT"); //$NON-NLS-1$

      int nbLines = 0;
      ResultAuditHEMSCMP data = null;

      if (StringConstants.OK.equals(retour.getResultat()) && (rs != null))
      {
        boolean stop = false;
        while (rs.next() && !stop)
        {
          nbLines++;
          data = new ResultAuditHEMSCMP(rs);

          if (dataCallBack_p != null)
          {
            DataCallBackReturn callBackReturn = dataCallBack_p.processData(data);
            if (DataCallBackReturn.STOP.equals(callBackReturn))
            {
              stop = true;
            }
          }
        }
      }

      return new ConnectorResponse<Integer, Retour>(nbLines, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, "No input parameters"); //$NON-NLS-1$

      // when select takes too long
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SELECT_FAILED, MessageFormat.format(Messages.getString("STRConnector.ERREUR_STR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSecAuditUDC)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, "No input parameters"); //$NON-NLS-1$

      //no sessions/connections available in the connection pool
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("STRConnector.ERREUR_STR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, "No input parameters"); //$NON-NLS-1$

      // when not able to connect
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("STRConnector.ERREUR_STR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, "No input parameters"); //$NON-NLS-1$
    }
    catch (Exception e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, null);
    }
    finally
    {
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<Integer, Retour> auditHEMSPDP(Tracabilite tracabilite_p, IDataCallBack dataCallBack_p) throws RavelException
  {
    Connection con = null;
    ResultSet rs = null;
    final String methodName = "PG_IWSRESSOURCES.P_017_AUDIT_HEMSPDP"; //$NON-NLS-1$
    _dsReadLock.lock();

    try
    {
      con = _datasource.getConnection();

      RavelLogger.log(new SpiritLogEvent(LogSeverity.INFO, tracabilite_p, methodName));

      CallableStatement cs = con.prepareCall("{call PG_IWSRESSOURCES.P_017_AUDIT_HEMSPDP(?,?,?,?,?) }"); //$NON-NLS-1$
      cs.setQueryTimeout(_readTimeoutSecAuditUDC);

      cs.registerOutParameter("po_RESULT", OracleTypes.CURSOR); //$NON-NLS-1$
      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();

      Retour retour = getRetour(cs);

      rs = (ResultSet) cs.getObject("po_RESULT"); //$NON-NLS-1$

      int nbLines = 0;
      ResultAuditHEMSPDP data = null;

      if (StringConstants.OK.equals(retour.getResultat()) && (rs != null))
      {
        boolean stop = false;
        while (rs.next() && !stop)
        {
          nbLines++;
          data = new ResultAuditHEMSPDP(rs);

          if (dataCallBack_p != null)
          {
            DataCallBackReturn callBackReturn = dataCallBack_p.processData(data);
            if (DataCallBackReturn.STOP.equals(callBackReturn))
            {
              stop = true;
            }
          }
        }
      }

      return new ConnectorResponse<Integer, Retour>(nbLines, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, "No input parameters"); //$NON-NLS-1$

      // when select takes too long
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SELECT_FAILED, MessageFormat.format(Messages.getString("STRConnector.ERREUR_STR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSecAuditUDC)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, "No input parameters"); //$NON-NLS-1$

      //no sessions/connections available in the connection pool
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("STRConnector.ERREUR_STR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, "No input parameters"); //$NON-NLS-1$

      // when not able to connect
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("STRConnector.ERREUR_STR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, "No input parameters"); //$NON-NLS-1$
    }
    catch (Exception e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, null);
    }
    finally
    {
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<Integer, Retour> auditHEMSSDP(Tracabilite tracabilite_p, IDataCallBack dataCallBack_p) throws RavelException
  {
    Connection con = null;
    ResultSet rs = null;
    final String methodName = "PG_IWSRESSOURCES.P_012_AUDIT_HEMSSDP"; //$NON-NLS-1$
    _dsReadLock.lock();

    try
    {
      con = _datasource.getConnection();

      RavelLogger.log(new SpiritLogEvent(LogSeverity.INFO, tracabilite_p, methodName));

      CallableStatement cs = con.prepareCall("{call PG_IWSRESSOURCES.P_012_AUDIT_HEMSSDP(?,?,?,?,?) }"); //$NON-NLS-1$
      cs.setQueryTimeout(_readTimeoutSecAuditUDC);

      cs.registerOutParameter("po_RESULT", OracleTypes.CURSOR); //$NON-NLS-1$
      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();

      Retour retour = getRetour(cs);

      rs = (ResultSet) cs.getObject("po_RESULT"); //$NON-NLS-1$

      int nbLines = 0;
      ResultAuditHEMSSDP data = null;

      if (StringConstants.OK.equals(retour.getResultat()) && (rs != null))
      {
        boolean stop = false;
        while (rs.next() && !stop)
        {
          nbLines++;
          data = new ResultAuditHEMSSDP(rs);

          if (dataCallBack_p != null)
          {
            DataCallBackReturn callBackReturn = dataCallBack_p.processData(data);
            if (DataCallBackReturn.STOP.equals(callBackReturn))
            {
              stop = true;
            }
          }
        }
      }

      return new ConnectorResponse<Integer, Retour>(nbLines, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, "No input parameters"); //$NON-NLS-1$

      // when select takes too long
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SELECT_FAILED, MessageFormat.format(Messages.getString("STRConnector.ERREUR_STR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSecAuditUDC)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, "No input parameters"); //$NON-NLS-1$

      //no sessions/connections available in the connection pool
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("STRConnector.ERREUR_STR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, "No input parameters"); //$NON-NLS-1$

      // when not able to connect
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("STRConnector.ERREUR_STR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, "No input parameters"); //$NON-NLS-1$
    }
    catch (Exception e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, null);
    }
    finally
    {
      close(rs, con);
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<Boolean, Retour> checkPARPNTACCFromVP(Tracabilite tracabilite_p, String imsi_p) throws RavelException
  {

    Connection con = null;
    final String methodName = "PG_IWSRESSOURCES.P_013_CHECK_PARPNTACC_FromVP"; //$NON-NLS-1$
    try
    {
      con = _datasource.getConnection();
      CallableStatement cs = con.prepareCall("{call PG_IWSRESSOURCES.P_013_CHECK_PARPNTACC_FromVP(?,?,?,?,?,?) }"); //$NON-NLS-1$
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("pi_IMSI", imsi_p); //$NON-NLS-1$

      cs.registerOutParameter("po_RESULT", OracleTypes.BIT); //$NON-NLS-1$
      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();
      Boolean res = false;

      res = (Boolean) cs.getObject("po_RESULT"); //$NON-NLS-1$
      Retour retour = getRetour(cs);
      return new ConnectorResponse<>(res, retour);

    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("pi_IMSI:").append(imsi_p).toString()); //$NON-NLS-1$

      // when insert takes too long
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, MessageFormat.format(Messages.getString("STRConnector.ERREUR_STR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("pi_IMSI:").append(imsi_p).toString()); //$NON-NLS-1$

      //no sessions/connections available in the connection pool
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("STRConnector.ERREUR_STR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("pi_IMSI:").append(imsi_p).toString()); //$NON-NLS-1$

      // when not able to connect
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("STRConnector.ERREUR_STR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append("pi_IMSI:").append(imsi_p).toString()); //$NON-NLS-1$
    }
    catch (Exception e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, null);
    }
    finally
    {
      close(null, con);
    }
  }

  @Override
  public ConnectorResponse<List<LigneMarcheData>, Retour> consultLigneDeMarche(Tracabilite tracabilite_p, String imsi_p, String msisdn_p) throws RavelException
  {
    Connection con = null;
    ResultSet rs = null;
    final String methodName = "PG_IWSRESSOURCES.P_003_CONSULT_LIGNE_MARCHE"; //$NON-NLS-1$
    _dsReadLock.lock();

    try
    {
      con = _datasource.getConnection();
      CallableStatement cs = con.prepareCall("{call PG_IWSRESSOURCES.P_003_CONSULT_LIGNE_MARCHE(?,?,?,?,?,?,?) }"); //$NON-NLS-1$
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("pi_IMSI", imsi_p); //$NON-NLS-1$
      cs.setString("pi_MSISDN", msisdn_p); //$NON-NLS-1$

      cs.registerOutParameter("po_RESULT", OracleTypes.CURSOR); //$NON-NLS-1$
      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();
      List<LigneMarcheData> resultat = new ArrayList<LigneMarcheData>();

      Retour retour = getRetour(cs);

      rs = (ResultSet) cs.getObject("po_RESULT"); //$NON-NLS-1$

      if (StringConstants.OK.equals(retour.getResultat()) && (rs != null))
      {
        while (rs.next())
        {
          resultat.add(new LigneMarcheData(rs));
        }
      }

      return new ConnectorResponse<List<LigneMarcheData>, Retour>(resultat, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("pi_IMSI:").append(imsi_p).append(",pi_MSISDN:").append(msisdn_p).toString()); //$NON-NLS-1$//$NON-NLS-2$

      // when select takes too long
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SELECT_FAILED, MessageFormat.format(Messages.getString("STRConnector.ERREUR_STR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("pi_IMSI:").append(imsi_p).append(",pi_MSISDN:").append(msisdn_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$

      //no sessions/connections available in the connection pool
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("STRConnector.ERREUR_STR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("pi_IMSI:").append(imsi_p).append(",pi_MSISDN:").append(msisdn_p).toString()); //$NON-NLS-1$//$NON-NLS-2$

      // when not able to connect
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("STRConnector.ERREUR_STR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append("pi_IMSI:").append(imsi_p).append(",pi_MSISDN:").append(msisdn_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$
    }
    catch (Exception e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, null);
    }
    finally
    {
      close(rs, con);
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<List<LineStatusData>, Retour> consultLineStatus(Tracabilite tracabilite_p, String imsi_p, String msisdn_p) throws RavelException
  {
    Connection con = null;
    ResultSet rs = null;
    final String methodName = "PG_IWSRESSOURCES.P_002_CONSULT_LINE_STATUS"; //$NON-NLS-1$
    _dsReadLock.lock();

    try
    {
      con = _datasource.getConnection();
      CallableStatement cs = con.prepareCall("{call PG_IWSRESSOURCES.P_002_CONSULT_LINE_STATUS(?,?,?,?,?,?,?) }"); //$NON-NLS-1$
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("pi_IMSI", imsi_p); //$NON-NLS-1$
      cs.setString("pi_MSISDN", msisdn_p); //$NON-NLS-1$

      cs.registerOutParameter("po_RESULT", OracleTypes.CURSOR); //$NON-NLS-1$
      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();
      List<LineStatusData> lsdList = new ArrayList<LineStatusData>();

      Retour retour = getRetour(cs);

      rs = (ResultSet) cs.getObject("po_RESULT"); //$NON-NLS-1$

      if (StringConstants.OK.equals(retour.getResultat()) && (rs != null))
      {
        while (rs.next())
        {
          lsdList.add(new LineStatusData(rs));
        }
      }

      return new ConnectorResponse<List<LineStatusData>, Retour>(lsdList, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("pi_IMSI:").append(imsi_p).append(",pi_MSISDN:").append(msisdn_p).toString()); //$NON-NLS-1$//$NON-NLS-2$

      // when select takes too long
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SELECT_FAILED, MessageFormat.format(Messages.getString("STRConnector.ERREUR_STR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("pi_IMSI:").append(imsi_p).append(",pi_MSISDN:").append(msisdn_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$

      //no sessions/connections available in the connection pool
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("STRConnector.ERREUR_STR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("pi_IMSI:").append(imsi_p).append(",pi_MSISDN:").append(msisdn_p).toString()); //$NON-NLS-1$//$NON-NLS-2$

      // when not able to connect
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("STRConnector.ERREUR_STR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append("pi_IMSI:").append(imsi_p).append(",pi_MSISDN:").append(msisdn_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$
    }
    catch (Exception e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, null);
    }
    finally
    {
      close(rs, con);
      _dsReadLock.unlock();
    }

  }

  @Override
  public ConnectorResponse<DonneesClient, Retour> getCustomerIdentity(Tracabilite tracabilite_p, String msisdn_p, String imsi_p) throws RavelException
  {
    Connection con = null;
    ResultSet rs = null;
    final String methodName = "PG_IWSRESSOURCES.P_006_GET_CUSTOMER_IDENTITY"; //$NON-NLS-1$
    try
    {
      con = _datasource.getConnection();
      CallableStatement cs = con.prepareCall("{call PG_IWSRESSOURCES.P_006_GET_CUSTOMER_IDENTITY(?,?,?,?,?,?,?) }"); //$NON-NLS-1$
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("pi_MSISDN", msisdn_p); //$NON-NLS-1$
      cs.setString("pi_IMSI", imsi_p); //$NON-NLS-1$

      cs.registerOutParameter("po_RESULT", OracleTypes.CURSOR); //$NON-NLS-1$
      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();
      DonneesClient donneesClient = null;

      Retour retour = getRetour(cs);
      rs = (ResultSet) cs.getObject("po_RESULT"); //$NON-NLS-1$
      if (StringConstants.OK.equals(retour.getResultat()) && (rs != null))
      {
        if (rs.next())
        {
          donneesClient = new DonneesClient(rs);
        }
      }

      return new ConnectorResponse<>(donneesClient, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("pi_MSISDN:").append(msisdn_p).append("pi_IMSI:").append(imsi_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$

      // when insert takes too long
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, MessageFormat.format(Messages.getString("STRConnector.ERREUR_STR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("pi_MSISDN:").append(msisdn_p).append("pi_IMSI:").append(imsi_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$

      //no sessions/connections available in the connection pool
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("STRConnector.ERREUR_STR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("pi_MSISDN:").append(msisdn_p).append("pi_IMSI:").append(imsi_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$

      // when not able to connect
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("STRConnector.ERREUR_STR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append("pi_MSISDN:").append(msisdn_p).append("pi_IMSI:").append(imsi_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$
    }
    catch (Exception e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, null);
    }
    finally
    {
      close(rs, con);
    }
  }

  @Override
  public ConnectorResponse<String, Retour> getMSISDNBDUOFromPFI(Tracabilite tracabilite_p, String pfi_p) throws RavelException
  {
    Connection con = null;
    ResultSet rs = null;
    final String methodName = "PG_IWSRESSOURCES.P_GET_MSISDN_BDUO_FROM_PFI"; //$NON-NLS-1$
    try
    {
      con = _datasource.getConnection();
      CallableStatement cs = con.prepareCall("{call PG_IWSRESSOURCES.P_GET_MSISDN_BDUO_FROM_PFI(?,?,?,?,?,?) }"); //$NON-NLS-1$
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("pi_PFI", pfi_p); //$NON-NLS-1$

      cs.registerOutParameter("po_RESULT", OracleTypes.CURSOR); //$NON-NLS-1$
      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();
      String msisdnBDUO = null;

      Retour retour = getRetour(cs);
      rs = (ResultSet) cs.getObject("po_RESULT"); //$NON-NLS-1$
      if (StringConstants.OK.equals(retour.getResultat()) && (rs != null))
      {
        if (rs.next())
        {
          msisdnBDUO = rs.getString("valpar"); //$NON-NLS-1$
        }
      }

      return new ConnectorResponse<>(msisdnBDUO, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("pi_PFI:").append(pfi_p).toString()); //$NON-NLS-1$

      // when insert takes too long
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, MessageFormat.format(Messages.getString("STRConnector.ERREUR_STR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("pi_PFI:").append(pfi_p).toString()); //$NON-NLS-1$

      //no sessions/connections available in the connection pool
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("STRConnector.ERREUR_STR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("pi_PFI:").append(pfi_p).toString()); //$NON-NLS-1$

      // when not able to connect
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("STRConnector.ERREUR_STR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append("pi_PFI:").append(pfi_p).toString()); //$NON-NLS-1$
    }
    catch (Exception e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, null);
    }
    finally
    {
      close(rs, con);
    }
  }

  @Override
  public ConnectorResponse<String, Retour> getMSISDNFromPFI(Tracabilite tracabilite_p, String pfi_p) throws RavelException
  {
    Connection con = null;
    ResultSet rs = null;
    final String methodName = "PG_IWSRESSOURCES.P_GET_MSISDN_FROM_PFI"; //$NON-NLS-1$
    try
    {
      con = _datasource.getConnection();
      CallableStatement cs = con.prepareCall("{call PG_IWSRESSOURCES.P_GET_MSISDN_FROM_PFI(?,?,?,?,?,?) }"); //$NON-NLS-1$
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("pi_PFI", pfi_p); //$NON-NLS-1$

      cs.registerOutParameter("po_RESULT", OracleTypes.CURSOR); //$NON-NLS-1$
      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();
      String msisdn = null;

      Retour retour = getRetour(cs);
      rs = (ResultSet) cs.getObject("po_RESULT"); //$NON-NLS-1$
      if (StringConstants.OK.equals(retour.getResultat()) && (rs != null))
      {
        if (rs.next())
        {
          msisdn = rs.getString("valpar"); //$NON-NLS-1$
        }
      }

      return new ConnectorResponse<>(msisdn, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("pi_PFI:").append(pfi_p).toString()); //$NON-NLS-1$

      // when insert takes too long
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, MessageFormat.format(Messages.getString("STRConnector.ERREUR_STR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("pi_PFI:").append(pfi_p).toString()); //$NON-NLS-1$

      //no sessions/connections available in the connection pool
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("STRConnector.ERREUR_STR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("pi_PFI:").append(pfi_p).toString()); //$NON-NLS-1$

      // when not able to connect
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("STRConnector.ERREUR_STR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append("pi_PFI:").append(pfi_p).toString()); //$NON-NLS-1$
    }
    catch (Exception e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, null);
    }
    finally
    {
      close(rs, con);
    }
  }

  @Override
  public ConnectorResponse<List<ParamSrvTech>, Retour> getPARSVCTECACC(Tracabilite tracabilite_p, long idSrvTech_p) throws RavelException
  {
    Connection con = null;
    ResultSet rs = null;
    final String methodName = "PG_IWSRESSOURCES.P_005_GET_PARSVCTECACC"; //$NON-NLS-1$
    _dsReadLock.lock();

    try
    {
      con = _datasource.getConnection();
      CallableStatement cs = con.prepareCall("{call PG_IWSRESSOURCES.P_005_GET_PARSVCTECACC(?,?,?,?,?,?) }"); //$NON-NLS-1$
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setLong("pi_Fk_Svctecacc", idSrvTech_p); //$NON-NLS-1$

      cs.registerOutParameter("po_RESULT", OracleTypes.CURSOR); //$NON-NLS-1$
      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();
      List<ParamSrvTech> resultat = new ArrayList<ParamSrvTech>();

      Retour retour = getRetour(cs);

      rs = (ResultSet) cs.getObject("po_RESULT"); //$NON-NLS-1$

      if (StringConstants.OK.equals(retour.getResultat()) && (rs != null))
      {
        while (rs.next())
        {
          resultat.add(new ParamSrvTech(rs));
        }
      }

      return new ConnectorResponse<List<ParamSrvTech>, Retour>(resultat, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("pi_Fk_Svctecacc:").append(idSrvTech_p).toString()); //$NON-NLS-1$

      // when select takes too long
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SELECT_FAILED, MessageFormat.format(Messages.getString("STRConnector.ERREUR_STR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("pi_Fk_Svctecacc:").append(idSrvTech_p).toString()); //$NON-NLS-1$

      //no sessions/connections available in the connection pool
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("STRConnector.ERREUR_STR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("pi_Fk_Svctecacc:").append(idSrvTech_p).toString()); //$NON-NLS-1$

      // when not able to connect
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("STRConnector.ERREUR_STR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append("pi_Fk_Svctecacc:").append(idSrvTech_p).toString()); //$NON-NLS-1$
    }
    catch (Exception e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, null);
    }
    finally
    {
      close(rs, con);
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<String, Retour> getPFIFromIMSI(Tracabilite tracabilite_p, String imsi_p) throws RavelException
  {
    Connection con = null;
    ResultSet rs = null;
    final String methodName = "PG_IWSRESSOURCES.P_GET_PFI_FROM_IMSI"; //$NON-NLS-1$
    try
    {
      con = _datasource.getConnection();
      CallableStatement cs = con.prepareCall("{call PG_IWSRESSOURCES.P_GET_PFI_FROM_IMSI(?,?,?,?,?,?) }"); //$NON-NLS-1$
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("pi_IMSI", imsi_p); //$NON-NLS-1$

      cs.registerOutParameter("po_RESULT", OracleTypes.CURSOR); //$NON-NLS-1$
      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();
      String pfi = null;

      Retour retour = getRetour(cs);
      rs = (ResultSet) cs.getObject("po_RESULT"); //$NON-NLS-1$
      if (StringConstants.OK.equals(retour.getResultat()) && (rs != null))
      {
        if (rs.next())
        {
          pfi = rs.getString("PFI"); //$NON-NLS-1$
        }
      }

      return new ConnectorResponse<>(pfi, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("pi_IMSI:").append(imsi_p).toString()); //$NON-NLS-1$

      // when insert takes too long
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, MessageFormat.format(Messages.getString("STRConnector.ERREUR_STR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("pi_IMSI:").append(imsi_p).toString()); //$NON-NLS-1$

      //no sessions/connections available in the connection pool
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("STRConnector.ERREUR_STR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("pi_IMSI:").append(imsi_p).toString()); //$NON-NLS-1$

      // when not able to connect
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("STRConnector.ERREUR_STR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append("pi_IMSI:").append(imsi_p).toString()); //$NON-NLS-1$
    }
    catch (Exception e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, null);
    }
    finally
    {
      close(rs, con);
    }
  }

  @Override
  public ConnectorResponse<List<Parpntacc>, Retour> getParpntaccByPfi(Tracabilite tracabilite_p, String pfi_p) throws RavelException
  {
    List<Parpntacc> result = new ArrayList<>();

    Connection con = null;
    ResultSet rs = null;
    final String methodName = "P_GET_PARPNTACC_BY_PFI"; //$NON-NLS-1$

    try
    {
      con = _datasource.getConnection();
      CallableStatement cs = con.prepareCall("{call PG_SPIRIT.P_GET_PARPNTACC_BY_PFI(?,?,?,?,?,?) }"); //$NON-NLS-1$
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("pi_PFI", pfi_p); //$NON-NLS-1$

      cs.registerOutParameter("po_RESULT", OracleTypes.CURSOR); //$NON-NLS-1$
      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();

      Retour retour = getRetour(cs);

      rs = (ResultSet) cs.getObject("po_RESULT"); //$NON-NLS-1$
      if (StringConstants.OK.equals(retour.getResultat()) && rs != null)
      {
        Parpntacc parpntacc = null;
        while (rs.next())
        {
          parpntacc = new Parpntacc(rs);
          result.add(parpntacc);
        }
      }

      return new ConnectorResponse<>(result, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("pi_PFI:").append(pfi_p).toString()); //$NON-NLS-1$

      // when insert takes too long
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, Messages.getString("STRConnector.ERREUR_STR_TIMEOUT_SUR_NON_REPONSE", _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("pi_PFI:").append(pfi_p).toString()); //$NON-NLS-1$

      //no sessions/connections available in the connection pool
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("STRConnector.ERREUR_STR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("pi_PFI:").append(pfi_p).toString()); //$NON-NLS-1$

      // when not able to connect
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("STRConnector.ERREUR_STR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append("pi_PFI:").append(pfi_p).toString()); //$NON-NLS-1$
    }
    catch (Exception e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, null);
    }
    finally
    {
      close(rs, con);
    }
  }

  @Override
  public ConnectorResponse<String, Retour> getPfiFromMsisdn(Tracabilite tracabilite_p, String msisdn_p) throws RavelException
  {
    Connection con = null;
    ResultSet rs = null;
    final String methodName = "PG_IWSRESSOURCES.P_018_GET_PFI_FROM_MSISDN"; //$NON-NLS-1$
    try
    {
      con = _datasource.getConnection();
      CallableStatement cs = con.prepareCall("{call PG_IWSRESSOURCES.P_018_GET_PFI_FROM_MSISDN(?,?,?,?,?,?) }"); //$NON-NLS-1$
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("pi_MSISDN", msisdn_p); //$NON-NLS-1$

      cs.registerOutParameter("po_RESULT", OracleTypes.CURSOR); //$NON-NLS-1$
      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();
      String pfi = null;

      Retour retour = getRetour(cs);
      rs = (ResultSet) cs.getObject("po_RESULT"); //$NON-NLS-1$
      if (StringConstants.OK.equals(retour.getResultat()) && (rs != null))
      {
        if (rs.next())
        {
          pfi = rs.getString("PFI"); //$NON-NLS-1$
        }
      }

      return new ConnectorResponse<>(pfi, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("pi_MSISDN:").append(msisdn_p).toString()); //$NON-NLS-1$

      // when insert takes too long
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SELECT_FAILED, MessageFormat.format(Messages.getString("STRConnector.ERREUR_STR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("pi_MSISDN:").append(msisdn_p).toString()); //$NON-NLS-1$

      //no sessions/connections available in the connection pool
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("STRConnector.ERREUR_STR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("pi_MSISDN:").append(msisdn_p).toString()); //$NON-NLS-1$

      // when not able to connect
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("STRConnector.ERREUR_STR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append("pi_MSISDN:").append(msisdn_p).toString()); //$NON-NLS-1$
    }
    catch (Exception e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, null);
    }
    finally
    {
      close(rs, con);
    }
  }

  @Override
  public ConnectorResponse<List<InfoProfil>, Retour> getProfilsPirelliParLM(Tracabilite tracabilite_p) throws RavelException
  {
    List<InfoProfil> result = new ArrayList<InfoProfil>();

    final String methodName = "PR_EXT_PROFILS_PIRELLI"; //$NON-NLS-1$
    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall("{call PG_REPORTING_GDS.PR_EXT_PROFILS_PIRELLI(?)}")) //$NON-NLS-1$
    {
      cs.setQueryTimeout(_readTimeoutSec);
      cs.registerOutParameter("po_RESULT", OracleTypes.CURSOR); //$NON-NLS-1$

      cs.execute();

      ResultSet rs = (ResultSet) cs.getObject("po_RESULT"); //$NON-NLS-1$
      if (rs != null)
      {
        InfoProfil infoProfil = null;
        while (rs.next())
        {
          infoProfil = new InfoProfil(rs);
          result.add(infoProfil);
        }
      }

      Retour retour = RetourFactory.createOkRetour();
      return new ConnectorResponse<>(result, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, "No input parameters"); //$NON-NLS-1$

      // when insert takes too long
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, Messages.getString("STRConnector.ERREUR_STR_TIMEOUT_SUR_NON_REPONSE", _readTimeoutSecAuditUDC)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, "No input parameters"); //$NON-NLS-1$

      //no sessions/connections available in the connection pool
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("STRConnector.ERREUR_STR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, "No input parameters"); //$NON-NLS-1$

      // when not able to connect
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, Messages.getString("STRConnector.ERREUR_STR_TIMEOUT_CONNEXION", _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, "No input parameters"); //$NON-NLS-1$
    }
  }

  @Override
  public ConnectorResponse<List<InfoProfil>, Retour> getProfilsThePoliceParLM(Tracabilite tracabilite_p) throws RavelException
  {
    List<InfoProfil> result = new ArrayList<InfoProfil>();

    final String methodName = "PR_EXT_PROFILS_THEPOLICE"; //$NON-NLS-1$
    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall("{call PG_REPORTING_GDS.PR_EXT_PROFILS_THEPOLICE(?)}")) //$NON-NLS-1$
    {
      cs.setQueryTimeout(_readTimeoutSec);
      cs.registerOutParameter("po_RESULT", OracleTypes.CURSOR); //$NON-NLS-1$
      cs.execute();

      ResultSet rs = (ResultSet) cs.getObject("po_RESULT"); //$NON-NLS-1$
      if (rs != null)
      {
        InfoProfil infoProfil = null;
        while (rs.next())
        {
          infoProfil = new InfoProfil(rs);
          result.add(infoProfil);
        }
      }

      Retour retour = RetourFactory.createOkRetour();
      return new ConnectorResponse<>(result, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, "No input parameters"); //$NON-NLS-1$

      // when insert takes too long
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, Messages.getString("STRConnector.ERREUR_STR_TIMEOUT_SUR_NON_REPONSE", _readTimeoutSecAuditUDC)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, "No input parameters"); //$NON-NLS-1$

      //no sessions/connections available in the connection pool
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("STRConnector.ERREUR_STR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, "No input parameters"); //$NON-NLS-1$

      // when not able to connect
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, Messages.getString("STRConnector.ERREUR_STR_TIMEOUT_CONNEXION", _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, "No input parameters"); //$NON-NLS-1$
    }
  }

  @Override
  public ConnectorResponse<Boolean, Retour> getSTRHEMSCMP(Tracabilite tracabilite_p) throws RavelException
  {
    Connection con = null;
    final String methodName = "PG_IWSRESSOURCES.P_015_GET_STR_HEMSCMP"; //$NON-NLS-1$
    try
    {
      con = _datasource.getConnection();

      RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, methodName));

      CallableStatement cs = con.prepareCall("{call PG_IWSRESSOURCES.P_015_GET_STR_HEMSCMP(?,?,?,?) }"); //$NON-NLS-1$
      cs.setQueryTimeout(_readTimeoutSecAuditUDC);

      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();

      Retour retour = getRetour(cs);

      return new ConnectorResponse<>(Boolean.TRUE, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, "No input parameters"); //$NON-NLS-1$

      // when insert takes too long
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, Messages.getString("STRConnector.ERREUR_STR_TIMEOUT_SUR_NON_REPONSE", _readTimeoutSecAuditUDC)); //$NON-NLS-1$
      return new ConnectorResponse<>(Boolean.FALSE, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, "No input parameters"); //$NON-NLS-1$

      //no sessions/connections available in the connection pool
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("STRConnector.ERREUR_STR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(Boolean.FALSE, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, "No input parameters"); //$NON-NLS-1$

      // when not able to connect
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, Messages.getString("STRConnector.ERREUR_STR_TIMEOUT_CONNEXION", _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(Boolean.FALSE, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, "No input parameters"); //$NON-NLS-1$
    }
    catch (Exception e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, null);
    }
    finally
    {
      close(null, con);
    }
  }

  @Override
  public ConnectorResponse<Boolean, Retour> getSTRHEMSPDP(Tracabilite tracabilite_p, String imsi_p) throws RavelException
  {
    Connection con = null;
    final String methodName = "PG_IWSRESSOURCES.P_014_GET_STR_HEMSPDP"; //$NON-NLS-1$
    try
    {
      con = _datasource.getConnection();

      SpiritLogEvent inputLog = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, methodName);
      inputLog.addField("pi_IMSI", imsi_p, false); //$NON-NLS-1$
      RavelLogger.log(inputLog);

      CallableStatement cs = con.prepareCall("{call PG_IWSRESSOURCES.P_014_GET_STR_HEMSPDP(?,?,?,?,?) }"); //$NON-NLS-1$
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("pi_IMSI", imsi_p); //$NON-NLS-1$

      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();

      Retour retour = getRetour(cs);

      return new ConnectorResponse<>(Boolean.TRUE, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("pi_IMSI:").append(imsi_p).toString()); //$NON-NLS-1$

      // when insert takes too long
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, Messages.getString("STRConnector.ERREUR_STR_TIMEOUT_SUR_NON_REPONSE", _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(Boolean.FALSE, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("pi_IMSI:").append(imsi_p).toString()); //$NON-NLS-1$

      //no sessions/connections available in the connection pool
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("STRConnector.ERREUR_STR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(Boolean.FALSE, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("pi_IMSI:").append(imsi_p).toString()); //$NON-NLS-1$

      // when not able to connect
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, Messages.getString("STRConnector.ERREUR_STR_TIMEOUT_CONNEXION", _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(Boolean.FALSE, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append("pi_IMSI:").append(imsi_p).toString()); //$NON-NLS-1$
    }
    catch (Exception e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, null);
    }
    finally
    {
      close(null, con);
    }
  }

  @Override
  public ConnectorResponse<Boolean, Retour> getSTRHEMSSDP(Tracabilite tracabilite_p, String imsi_p) throws RavelException
  {
    Connection con = null;
    final String methodName = "PG_IWSRESSOURCES.P_011_GET_STR_HEMSSDP"; //$NON-NLS-1$
    try
    {
      con = _datasource.getConnection();

      SpiritLogEvent inputLog = new SpiritLogEvent(LogSeverity.INFO, tracabilite_p, methodName);
      inputLog.addField("pi_IMSI", imsi_p, false); //$NON-NLS-1$
      RavelLogger.log(inputLog);

      CallableStatement cs = con.prepareCall("{call PG_IWSRESSOURCES.P_011_GET_STR_HEMSSDP(?,?,?,?,?) }"); //$NON-NLS-1$
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("pi_IMSI", imsi_p); //$NON-NLS-1$

      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();

      Retour retour = getRetour(cs);

      return new ConnectorResponse<>(Boolean.TRUE, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("pi_IMSI:").append(imsi_p).toString()); //$NON-NLS-1$

      // when insert takes too long
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, Messages.getString("STRConnector.ERREUR_STR_TIMEOUT_SUR_NON_REPONSE", _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(Boolean.FALSE, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("pi_IMSI:").append(imsi_p).toString()); //$NON-NLS-1$

      //no sessions/connections available in the connection pool
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("STRConnector.ERREUR_STR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(Boolean.FALSE, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("pi_IMSI:").append(imsi_p).toString()); //$NON-NLS-1$

      // when not able to connect
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, Messages.getString("STRConnector.ERREUR_STR_TIMEOUT_CONNEXION", _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(Boolean.FALSE, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append("pi_IMSI:").append(imsi_p).toString()); //$NON-NLS-1$
    }
    catch (Exception e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, null);
    }
    finally
    {
      close(null, con);
    }
  }

  @Override
  public ConnectorResponse<List<ServiceTechniqueSTR>, Retour> getSVCTECACCFromPFI(Tracabilite tracabilite_p, String pfi_p) throws RavelException
  {
    Connection con = null;
    ResultSet rs = null;
    final String methodName = "PG_IWSRESSOURCES.P_004_GET_SVCTECACC_FROM_PFI"; //$NON-NLS-1$
    _dsReadLock.lock();

    try
    {
      con = _datasource.getConnection();
      CallableStatement cs = con.prepareCall("{call PG_IWSRESSOURCES.P_004_GET_SVCTECACC_FROM_PFI(?,?,?,?,?,?) }"); //$NON-NLS-1$
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("pi_PFI", pfi_p); //$NON-NLS-1$

      cs.registerOutParameter("po_RESULT", OracleTypes.CURSOR); //$NON-NLS-1$
      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();
      List<ServiceTechniqueSTR> resultat = new ArrayList<ServiceTechniqueSTR>();
      List<ParamSrvTech> additionalParams = null;

      Retour retour = getRetour(cs);

      rs = (ResultSet) cs.getObject("po_RESULT"); //$NON-NLS-1$

      if (StringConstants.OK.equals(retour.getResultat()) && (rs != null))
      {
        while (rs.next())
        {
          ServiceTechniqueSTR serviceTechniqueSTR = new ServiceTechniqueSTR(rs);
          if (serviceTechniqueSTR.hasParamSuppl())
          {
            additionalParams = serviceTechniqueSTR.getListParam();
            additionalParams.addAll(getPARSVCTECACC(tracabilite_p, serviceTechniqueSTR.getIdSrvTech())._first);
            serviceTechniqueSTR.setListParam(additionalParams);
          }

          resultat.add(serviceTechniqueSTR);
        }
      }

      return new ConnectorResponse<List<ServiceTechniqueSTR>, Retour>(resultat, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("pi_PFI:").append(pfi_p).toString()); //$NON-NLS-1$

      // when select takes too long
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SELECT_FAILED, MessageFormat.format(Messages.getString("STRConnector.ERREUR_STR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("pi_PFI:").append(pfi_p).toString()); //$NON-NLS-1$

      //no sessions/connections available in the connection pool
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("STRConnector.ERREUR_STR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("pi_PFI:").append(pfi_p).toString()); //$NON-NLS-1$

      // when not able to connect
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("STRConnector.ERREUR_STR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append("pi_PFI:").append(pfi_p).toString()); //$NON-NLS-1$
    }
    catch (Exception e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, null);
    }
    finally
    {
      close(rs, con);
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<List<TSMData>, Retour> getTSMDataByIMSI(Tracabilite tracabilite_p, String imsi_p) throws RavelException
  {
    Connection con = null;
    ResultSet rs = null;
    final String methodName = "PG_IWSRESSOURCES.P_001_GET_TSM_DATA"; //$NON-NLS-1$
    try
    {
      con = _datasource.getConnection();
      CallableStatement cs = con.prepareCall("{call PG_IWSRESSOURCES.P_001_GET_TSM_DATA(?,?,?,?,?,?,?) }"); //$NON-NLS-1$
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("pi_VALUE", imsi_p); //$NON-NLS-1$
      cs.setString("pi_TYPE", "IMSI"); //$NON-NLS-1$ //$NON-NLS-2$

      cs.registerOutParameter("po_RESULT", OracleTypes.CURSOR); //$NON-NLS-1$
      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();
      List<TSMData> tsmdataList = new ArrayList<TSMData>();

      Retour retour = getRetour(cs);
      rs = (ResultSet) cs.getObject("po_RESULT"); //$NON-NLS-1$

      if (StringConstants.OK.equals(retour.getResultat()) && (rs != null))
      {
        while (rs.next())
        {
          tsmdataList.add(new TSMData(rs));
        }
      }

      return new ConnectorResponse<>(tsmdataList, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("pi_IMSI:").append(imsi_p).toString()); //$NON-NLS-1$

      // when insert takes too long
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, MessageFormat.format(Messages.getString("STRConnector.ERREUR_STR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("pi_IMSI:").append(imsi_p).toString()); //$NON-NLS-1$

      //no sessions/connections available in the connection pool
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("STRConnector.ERREUR_STR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("pi_IMSI:").append(imsi_p).toString()); //$NON-NLS-1$

      // when not able to connect
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("STRConnector.ERREUR_STR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append("pi_IMSI:").append(imsi_p).toString()); //$NON-NLS-1$
    }
    catch (Exception e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, null);
    }
    finally
    {
      close(rs, con);
    }
  }

  @Override
  public ConnectorResponse<List<TSMData>, Retour> getTSMDataByMSISDN(Tracabilite tracabilite_p, String msisdn_p) throws RavelException
  {
    Connection con = null;
    ResultSet rs = null;
    final String methodName = "PG_IWSRESSOURCES.P_001_GET_TSM_DATA"; //$NON-NLS-1$
    try
    {
      con = _datasource.getConnection();
      CallableStatement cs = con.prepareCall("{call PG_IWSRESSOURCES.P_001_GET_TSM_DATA(?,?,?,?,?,?,?) }"); //$NON-NLS-1$
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("pi_VALUE", msisdn_p); //$NON-NLS-1$
      cs.setString("pi_TYPE", "MSISDN"); //$NON-NLS-1$ //$NON-NLS-2$

      cs.registerOutParameter("po_RESULT", OracleTypes.CURSOR); //$NON-NLS-1$
      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();
      List<TSMData> tsmdataList = new ArrayList<TSMData>();

      Retour retour = getRetour(cs);
      rs = (ResultSet) cs.getObject("po_RESULT"); //$NON-NLS-1$

      if (StringConstants.OK.equals(retour.getResultat()) && (rs != null))
      {
        while (rs.next())
        {
          tsmdataList.add(new TSMData(rs));
        }
      }

      return new ConnectorResponse<>(tsmdataList, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("pi_MSISDN:").append(msisdn_p).toString()); //$NON-NLS-1$

      // when insert takes too long
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, MessageFormat.format(Messages.getString("STRConnector.ERREUR_STR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("pi_MSISDN:").append(msisdn_p).toString()); //$NON-NLS-1$

      //no sessions/connections available in the connection pool
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("STRConnector.ERREUR_STR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("pi_MSISDN:").append(msisdn_p).toString()); //$NON-NLS-1$

      // when not able to connect
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("STRConnector.ERREUR_STR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append("pi_MSISDN:").append(msisdn_p).toString()); //$NON-NLS-1$
    }
    catch (Exception e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, null);
    }
    finally
    {
      close(rs, con);
    }
  }

  @Override
  public ConnectorResponse<Boolean, Retour> insertUDCHEMSCMP(Tracabilite tracabilite_p, List<AuditUDCHEMSCMP> listAuditUDCHEMSCMP_p, int batchSize_p) throws RavelException
  {
    Connection con = null;
    PreparedStatement ps = null;
    AuditUDCHEMSCMP auditUDCHEMSCMP = new AuditUDCHEMSCMP();

    final String methodName = "INSERT INTO AUDIT_UDC_HEMSCMP"; //$NON-NLS-1$
    try
    {
      con = _datasource.getConnection();

      SpiritLogEvent inputLog = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, methodName);
      inputLog.addField("listAuditUDCHEMSCMP", listAuditUDCHEMSCMP_p.size() + " records", false); //$NON-NLS-1$ //$NON-NLS-2$
      inputLog.addField("batchSize", batchSize_p, false); //$NON-NLS-1$
      RavelLogger.log(inputLog);

      ps = con.prepareStatement("INSERT INTO AUDIT_UDC_HEMSCMP (MSISDN, EOICK) VALUES (?,?)"); //$NON-NLS-1$
      ps.setQueryTimeout(_readTimeoutSec);

      int count = 0;
      int i = 0;

      con.setAutoCommit(false);
      for (Iterator<AuditUDCHEMSCMP> iterator = listAuditUDCHEMSCMP_p.iterator(); iterator.hasNext();)
      {
        i = 0;
        auditUDCHEMSCMP = iterator.next();

        ps.setString(++i, auditUDCHEMSCMP.getMsisdn());

        if (auditUDCHEMSCMP.getEoick() != null)
        {
          ps.setLong(++i, auditUDCHEMSCMP.getEoick());
        }
        else
        {
          ps.setNull(++i, OracleTypes.NUMBER);
        }

        ps.addBatch();

        if ((++count % batchSize_p) == 0)
        {
          ps.executeBatch();
          con.commit();
        }
      }
      ps.executeBatch();
      con.commit();

      return new ConnectorResponse<>(Boolean.TRUE, RetourFactory.createOkRetour());
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("pi_MSISDN:").append(auditUDCHEMSCMP.getMsisdn()).append("pi_EOICK:").append(auditUDCHEMSCMP.getEoick()).toString()); //$NON-NLS-1$ //$NON-NLS-2$

      // when insert takes too long
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, MessageFormat.format(Messages.getString("STRConnector.ERREUR_STR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(Boolean.FALSE, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("pi_MSISDN:").append(auditUDCHEMSCMP.getMsisdn()).append("pi_EOICK:").append(auditUDCHEMSCMP.getEoick()).toString()); //$NON-NLS-1$ //$NON-NLS-2$

      //no sessions/connections available in the connection pool
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("STRConnector.ERREUR_STR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(Boolean.FALSE, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("pi_MSISDN:").append(auditUDCHEMSCMP.getMsisdn()).append("pi_EOICK:").append(auditUDCHEMSCMP.getEoick()).toString()); //$NON-NLS-1$ //$NON-NLS-2$

      // when not able to connect
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("STRConnector.ERREUR_STR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(Boolean.FALSE, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append("pi_MSISDN:").append(auditUDCHEMSCMP.getMsisdn()).append("pi_EOICK:").append(auditUDCHEMSCMP.getEoick()).toString()); //$NON-NLS-1$ //$NON-NLS-2$
    }
    catch (Exception e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, null);
    }
    finally
    {
      closeConnection(ps, con);
    }
  }

  @Override
  public ConnectorResponse<Boolean, Retour> insertUDCHEMSPDP(Tracabilite tracabilite_p, List<AuditUDCHEMSPDP> listAuditUDCHEMSPDP_p, int batchSize_p) throws RavelException
  {
    Connection con = null;
    PreparedStatement ps = null;
    AuditUDCHEMSPDP auditUDCHEMSPDP = new AuditUDCHEMSPDP();

    final String methodName = "INSERT INTO AUDIT_UDC_HEMSPDP"; //$NON-NLS-1$
    try
    {
      con = _datasource.getConnection();

      SpiritLogEvent inputLog = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, methodName);
      inputLog.addField("listAuditUDCHEMSPDP", listAuditUDCHEMSPDP_p.size() + " records", false); //$NON-NLS-1$ //$NON-NLS-2$
      inputLog.addField("batchSize", batchSize_p, false); //$NON-NLS-1$
      RavelLogger.log(inputLog);

      ps = con.prepareStatement("INSERT INTO AUDIT_UDC_HEMSPDP (PK_UDC_HEMSPDP, MSISDN, IMSI, APNID, EQOSID, PDPID, EPDPIND) VALUES (SQ_UDC_HEMSPDP_01.NEXTVAL,?,?,?,?,?,?)"); //$NON-NLS-1$
      ps.setQueryTimeout(_readTimeoutSec);

      int count = 0;
      int i = 0;

      con.setAutoCommit(false);
      for (Iterator<AuditUDCHEMSPDP> iterator = listAuditUDCHEMSPDP_p.iterator(); iterator.hasNext();)
      {
        i = 0;
        auditUDCHEMSPDP = iterator.next();

        ps.setString(++i, auditUDCHEMSPDP.getMsisdn());
        ps.setString(++i, auditUDCHEMSPDP.getImsi());

        if (auditUDCHEMSPDP.getApnid() != null)
        {
          ps.setInt(++i, auditUDCHEMSPDP.getApnid());
        }
        else
        {
          ps.setNull(++i, OracleTypes.NUMBER);
        }

        if (auditUDCHEMSPDP.getEqosid() != null)
        {
          ps.setInt(++i, auditUDCHEMSPDP.getEqosid());
        }
        else
        {
          ps.setNull(++i, OracleTypes.NUMBER);
        }

        if (auditUDCHEMSPDP.getPdpid() != null)
        {
          ps.setInt(++i, auditUDCHEMSPDP.getPdpid());
        }
        else
        {
          ps.setNull(++i, OracleTypes.NUMBER);
        }

        ps.setString(++i, auditUDCHEMSPDP.getEpdpind());

        ps.addBatch();

        if ((++count % batchSize_p) == 0)
        {
          ps.executeBatch();
          con.commit();
        }
      }
      ps.executeBatch();
      con.commit();

      return new ConnectorResponse<>(Boolean.TRUE, RetourFactory.createOkRetour());
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("pi_MSISDN:").append(auditUDCHEMSPDP.getMsisdn()).append("pi_IMSI:").append(auditUDCHEMSPDP.getImsi()).append("pi_APNID:").append(auditUDCHEMSPDP.getApnid()).append("pi_EQOSID:").append(auditUDCHEMSPDP.getEqosid()).append("pi_PDPID:").append(auditUDCHEMSPDP.getPdpid()).append("pi_EPDPIND:").append(auditUDCHEMSPDP.getEpdpind()).toString()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$

      // when insert takes too long
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, MessageFormat.format(Messages.getString("STRConnector.ERREUR_STR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(Boolean.FALSE, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("pi_MSISDN:").append(auditUDCHEMSPDP.getMsisdn()).append("pi_IMSI:").append(auditUDCHEMSPDP.getImsi()).append("pi_APNID:").append(auditUDCHEMSPDP.getApnid()).append("pi_EQOSID:").append(auditUDCHEMSPDP.getEqosid()).append("pi_PDPID:").append(auditUDCHEMSPDP.getPdpid()).append("pi_EPDPIND:").append(auditUDCHEMSPDP.getEpdpind()).toString()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$

      //no sessions/connections available in the connection pool
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("STRConnector.ERREUR_STR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(Boolean.FALSE, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("pi_MSISDN:").append(auditUDCHEMSPDP.getMsisdn()).append("pi_IMSI:").append(auditUDCHEMSPDP.getImsi()).append("pi_APNID:").append(auditUDCHEMSPDP.getApnid()).append("pi_EQOSID:").append(auditUDCHEMSPDP.getEqosid()).append("pi_PDPID:").append(auditUDCHEMSPDP.getPdpid()).append("pi_EPDPIND:").append(auditUDCHEMSPDP.getEpdpind()).toString()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$

      // when not able to connect
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("STRConnector.ERREUR_STR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(Boolean.FALSE, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append("pi_MSISDN:").append(auditUDCHEMSPDP.getMsisdn()).append("pi_IMSI:").append(auditUDCHEMSPDP.getImsi()).append("pi_APNID:").append(auditUDCHEMSPDP.getApnid()).append("pi_EQOSID:").append(auditUDCHEMSPDP.getEqosid()).append("pi_PDPID:").append(auditUDCHEMSPDP.getPdpid()).append("pi_EPDPIND:").append(auditUDCHEMSPDP.getEpdpind()).toString()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    }
    catch (Exception e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, null);
    }
    finally
    {
      closeConnection(ps, con);
    }
  }

  @Override
  public ConnectorResponse<Boolean, Retour> insertUDCHEMSSDP(Tracabilite tracabilite_p, List<AuditUDCHEMSSDP> listAuditUDCHEMSSDP_p, int batchSize_p) throws RavelException
  {
    Connection con = null;
    PreparedStatement ps = null;
    AuditUDCHEMSSDP auditUDCHEMSSDP = new AuditUDCHEMSSDP();

    final String methodName = "INSERT INTO AUDIT_UDC_HEMSSDP"; //$NON-NLS-1$
    try
    {
      con = _datasource.getConnection();

      SpiritLogEvent inputLog = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, methodName);
      inputLog.addField("listAuditUDCHEMSSDP", listAuditUDCHEMSSDP_p.size() + " records", false); //$NON-NLS-1$ //$NON-NLS-2$
      inputLog.addField("batchSize", batchSize_p, false); //$NON-NLS-1$
      RavelLogger.log(inputLog);

      ps = con.prepareStatement("INSERT INTO AUDIT_UDC_HEMSSDP (PK_UDC_HEMSSDP, MSISDN, IMSI, NAM, AMSISDN) VALUES (SQ_UDC_HEMSSDP_01.NEXTVAL,?,?,?,?)"); //$NON-NLS-1$
      ps.setQueryTimeout(_readTimeoutSec);

      int count = 0;
      int i = 0;

      con.setAutoCommit(false);
      for (Iterator<AuditUDCHEMSSDP> iterator = listAuditUDCHEMSSDP_p.iterator(); iterator.hasNext();)
      {
        i = 0;
        auditUDCHEMSSDP = iterator.next();

        ps.setString(++i, auditUDCHEMSSDP.getMsisdn());
        ps.setString(++i, auditUDCHEMSSDP.getImsi());
        ps.setString(++i, auditUDCHEMSSDP.getNam());
        ps.setString(++i, auditUDCHEMSSDP.getAmsisdn());

        ps.addBatch();

        if ((++count % batchSize_p) == 0)
        {
          ps.executeBatch();
          con.commit();
        }
      }
      ps.executeBatch();
      con.commit();

      return new ConnectorResponse<>(Boolean.TRUE, RetourFactory.createOkRetour());
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("pi_MSISDN:").append(auditUDCHEMSSDP.getMsisdn()).append("pi_IMSI:").append(auditUDCHEMSSDP.getImsi()).append("pi_NAM:").append(auditUDCHEMSSDP.getNam()).append("pi_AMSISDN:").append(auditUDCHEMSSDP.getAmsisdn()).toString()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$

      // when insert takes too long
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, MessageFormat.format(Messages.getString("STRConnector.ERREUR_STR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(Boolean.FALSE, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("pi_MSISDN:").append(auditUDCHEMSSDP.getMsisdn()).append("pi_IMSI:").append(auditUDCHEMSSDP.getImsi()).append("pi_NAM:").append(auditUDCHEMSSDP.getNam()).append("pi_AMSISDN:").append(auditUDCHEMSSDP.getAmsisdn()).toString()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$

      //no sessions/connections available in the connection pool
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("STRConnector.ERREUR_STR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(Boolean.FALSE, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("pi_MSISDN:").append(auditUDCHEMSSDP.getMsisdn()).append("pi_IMSI:").append(auditUDCHEMSSDP.getImsi()).append("pi_NAM:").append(auditUDCHEMSSDP.getNam()).append("pi_AMSISDN:").append(auditUDCHEMSSDP.getAmsisdn()).toString()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$

      // when not able to connect
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("STRConnector.ERREUR_STR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(Boolean.FALSE, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append("pi_MSISDN:").append(auditUDCHEMSSDP.getMsisdn()).append("pi_IMSI:").append(auditUDCHEMSSDP.getImsi()).append("pi_NAM:").append(auditUDCHEMSSDP.getNam()).append("pi_AMSISDN:").append(auditUDCHEMSSDP.getAmsisdn()).toString()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    }
    catch (Exception e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, null);
    }
    finally
    {
      closeConnection(ps, con);
    }
  }

  @Override
  public void loadConnectorConfiguration(Connector connector_p) throws RavelException
  {

    // Read parameters.
    _name = connector_p.getName();
    _enabled = connector_p.isEnabled();
    for (Param parameter : connector_p.getParam())
    {
      ParameterName parameterName = ParameterName.valueOf(parameter.getName().toUpperCase());
      if (parameterName != null)
      {
        _parameters.put(parameterName, parameter.getValue());
      }
    }

    // Check parameters
    String connectionString = _parameters.get(ParameterName.DB_CONNECTIONSTRING);
    if (StringTools.isNullOrEmpty(connectionString))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, Messages.getString("STRConnector.MissingParameter", _name, ParameterName.DB_CONNECTIONSTRING.toString())); //$NON-NLS-1$
    }

    String dbUserName = _parameters.get(ParameterName.DB_USERNAME);
    if (StringTools.isNullOrEmpty(dbUserName))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, Messages.getString("STRConnector.MissingParameter", _name, ParameterName.DB_USERNAME.toString())); //$NON-NLS-1$
    }

    String dbPassword = _parameters.get(ParameterName.DB_PASSWORD);
    if (StringTools.isNullOrEmpty(dbPassword))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, Messages.getString("STRConnector.MissingParameter", _name, ParameterName.DB_PASSWORD.toString())); //$NON-NLS-1$
    }

    String poolSize = _parameters.get(ParameterName.POOLSIZE);

    String connectTimeoutSec = _parameters.get(ParameterName.CONNECT_TIMEOUT_SEC);
    if (StringTools.isNullOrEmpty(connectTimeoutSec))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, Messages.getString("STRConnector.MissingParameter", _name, ParameterName.CONNECT_TIMEOUT_SEC.toString())); //$NON-NLS-1$
    }
    try
    {
      _connectTimeoutSec = Integer.parseInt(connectTimeoutSec);
    }
    catch (NumberFormatException e)
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00021, Messages.getString("STRConnector.InvalidParameter", _name, _parameters.get(ParameterName.CONNECT_TIMEOUT_SEC))); //$NON-NLS-1$
    }

    String readTimeoutSec = _parameters.get(ParameterName.READ_TIMEOUT_SEC);
    if (StringTools.isNullOrEmpty(readTimeoutSec))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, Messages.getString("STRConnector.MissingParameter", _name, ParameterName.READ_TIMEOUT_SEC.toString())); //$NON-NLS-1$
    }
    try
    {
      _readTimeoutSec = Integer.parseInt(readTimeoutSec);
    }
    catch (NumberFormatException e)
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00021, Messages.getString("STRConnector.InvalidParameter", _name, _parameters.get(ParameterName.READ_TIMEOUT_SEC))); //$NON-NLS-1$
    }

    String readTimeoutSecAuditUDC = _parameters.get(ParameterName.READ_TIMEOUT_SEC_AUDIT_UDC);
    if (StringTools.isNullOrEmpty(readTimeoutSecAuditUDC))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, Messages.getString("STRConnector.MissingParameter", _name, ParameterName.READ_TIMEOUT_SEC_AUDIT_UDC.toString())); //$NON-NLS-1$
    }
    try
    {
      _readTimeoutSecAuditUDC = Integer.parseInt(readTimeoutSecAuditUDC);
    }
    catch (NumberFormatException e)
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00021, Messages.getString("STRConnector.InvalidParameter", _name, _parameters.get(ParameterName.READ_TIMEOUT_SEC_AUDIT_UDC))); //$NON-NLS-1$
    }

    createDataSource(connectionString, dbUserName, dbPassword, poolSize, DatabaseType.ORACLE);
  }

  @Override
  public ConnectorResponse<ResultContratEtPartition, Retour> recupererNoContratParNoTelephone(Tracabilite tracabilite_p, String noTelephone_p) throws RavelException
  {
    Connection con = null;
    String methodName = "PG_SPIRIT.GET_NOCONTRAT_FROM_MSISDN"; //$NON-NLS-1$

    _dsReadLock.lock();

    try
    {
      con = _datasource.getConnection();
      CallableStatement cs = con.prepareCall("{call " + methodName + "(?,?,?,?,?,?,?) }"); //$NON-NLS-1$ //$NON-NLS-2$
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("pi_MSISDN", noTelephone_p); //$NON-NLS-1$
      cs.registerOutParameter("po_NOCONTRAT", OracleTypes.NVARCHAR); //$NON-NLS-1$
      cs.registerOutParameter("po_partitionSic", OracleTypes.NVARCHAR); //$NON-NLS-1$
      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();

      String noContrat = null;
      String noPartition = null;

      Retour retour = getRetour(cs);
      noContrat = cs.getString("po_NOCONTRAT"); //$NON-NLS-1$

      noPartition = cs.getString("po_partitionSic"); //$NON-NLS-1$

      SpiritLogEvent outputLog = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, methodName);
      outputLog.addField("Retour", retour, false); //$NON-NLS-1$

      if (noContrat != null)
      {
        outputLog.addField("po_NOCONTRAT", noContrat, false); //$NON-NLS-1$
      }
      RavelLogger.log(outputLog);

      return new ConnectorResponse<>(new ResultContratEtPartition(noContrat, noPartition), retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("NoTelephone:").append(noTelephone_p).toString()); //$NON-NLS-1$

      // when takes too long
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, MessageFormat.format(Messages.getString("STRConnector.ERREUR_STR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("NoTelephone:").append(noTelephone_p).toString()); //$NON-NLS-1$

      //no sessions/connections available in the connection pool
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("STRConnector.ERREUR_STR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("NoTelephone:").append(noTelephone_p).toString()); //$NON-NLS-1$

      // when not able to connect
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("STRConnector.ERREUR_STR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append("NoTelephone:").append(noTelephone_p).toString()); //$NON-NLS-1$
    }
    finally
    {
      close(null, con);
      _dsReadLock.unlock();
    }

  }

  @Override
  public ConnectorResponse<String, Retour> recupererTypeVms(Tracabilite tracabilite_p, String noTelephone_p) throws RavelException
  {
    Connection con = null;
    String methodName = "PG_SPIRIT.GET_TYPE_VMS_FROM_MSISDN"; //$NON-NLS-1$

    _dsReadLock.lock();

    try
    {
      con = _datasource.getConnection();
      CallableStatement cs = con.prepareCall("{call " + methodName + "(?,?,?,?,?,?) }"); //$NON-NLS-1$ //$NON-NLS-2$
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("pi_MSISDN", noTelephone_p); //$NON-NLS-1$
      cs.registerOutParameter("po_TYPEPFS", OracleTypes.NVARCHAR); //$NON-NLS-1$
      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();

      String typeVms = null;

      Retour retour = getRetour(cs);
      typeVms = cs.getString("po_TYPEPFS"); //$NON-NLS-1$

      SpiritLogEvent outputLog = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, methodName);
      outputLog.addField("Retour", retour, false); //$NON-NLS-1$

      if (typeVms != null)
      {
        outputLog.addField("po_TYPEPFS", typeVms, false); //$NON-NLS-1$
      }
      RavelLogger.log(outputLog);

      return new ConnectorResponse<>(typeVms, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, "NoTelephone:" + noTelephone_p); //$NON-NLS-1$

      // when takes too long
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, MessageFormat.format(Messages.getString("STRConnector.ERREUR_STR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, "NoTelephone:" + noTelephone_p); //$NON-NLS-1$

      //no sessions/connections available in the connection pool
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("STRConnector.ERREUR_STR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, "NoTelephone:" + noTelephone_p); //$NON-NLS-1$

      // when not able to connect
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("STRConnector.ERREUR_STR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, "NoTelephone:" + noTelephone_p); //$NON-NLS-1$
    }
    finally
    {
      close(null, con);
      _dsReadLock.unlock();
    }

  }

  @Override
  public ConnectorResponse<Boolean, Retour> truncateTableAuditUDC(Tracabilite tracabilite_p, String commande_p) throws RavelException
  {
    Connection con = null;
    PreparedStatement ps = null;

    final String methodName = "TRUNCATE TABLE AUDIT_UDC_" + commande_p; //$NON-NLS-1$
    try
    {
      con = _datasource.getConnection();

      SpiritLogEvent inputLog = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, methodName);
      RavelLogger.log(inputLog);

      ps = con.prepareStatement(methodName);
      ps.setQueryTimeout(_readTimeoutSec);
      ps.executeUpdate();

      return new ConnectorResponse<>(Boolean.TRUE, RetourFactory.createOkRetour());
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, "No input parameters"); //$NON-NLS-1$

      // when insert takes too long
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, MessageFormat.format(Messages.getString("STRConnector.ERREUR_STR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(Boolean.FALSE, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, "No input parameters"); //$NON-NLS-1$

      //no sessions/connections available in the connection pool
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("STRConnector.ERREUR_STR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(Boolean.FALSE, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, "No input parameters"); //$NON-NLS-1$

      // when not able to connect
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("STRConnector.ERREUR_STR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(Boolean.FALSE, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, "No input parameters"); //$NON-NLS-1$
    }
    catch (Exception e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, null);
    }
    finally
    {
      closeConnection(ps, con);
    }
  }

  @Override
  public ConnectorResponse<String, Retour> upccGetIDTPFSFromPFI(Tracabilite tracabilite_p, String pfi_p) throws RavelException
  {
    Connection con = null;
    ResultSet rs = null;
    final String methodName = "PG_IWSRESSOURCES.P_UPCC_GET_IDTPFS_FROM_PFI"; //$NON-NLS-1$
    try
    {
      con = _datasource.getConnection();
      CallableStatement cs = con.prepareCall("{call PG_IWSRESSOURCES.P_UPCC_GET_IDTPFS_FROM_PFI(?,?,?,?,?,?) }"); //$NON-NLS-1$
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("pi_PFI", pfi_p); //$NON-NLS-1$

      cs.registerOutParameter("po_RESULT", OracleTypes.CURSOR); //$NON-NLS-1$
      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();
      String idtpfs = null;

      Retour retour = getRetour(cs);
      rs = (ResultSet) cs.getObject("po_RESULT"); //$NON-NLS-1$
      if (StringConstants.OK.equals(retour.getResultat()) && (rs != null))
      {
        if (rs.next())
        {
          idtpfs = rs.getString("IDTPFS"); //$NON-NLS-1$
        }
      }

      return new ConnectorResponse<>(idtpfs, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("pi_PFI:").append(pfi_p).toString()); //$NON-NLS-1$

      // when insert takes too long
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, MessageFormat.format(Messages.getString("STRConnector.ERREUR_STR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("pi_PFI:").append(pfi_p).toString()); //$NON-NLS-1$

      //no sessions/connections available in the connection pool
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("STRConnector.ERREUR_STR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("pi_PFI:").append(pfi_p).toString()); //$NON-NLS-1$

      // when not able to connect
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("STRConnector.ERREUR_STR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append("pi_PFI:").append(pfi_p).toString()); //$NON-NLS-1$
    }
    catch (Exception e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, null);
    }
    finally
    {
      close(rs, con);
    }
  }

  @Override
  public ConnectorResponse<String, Retour> upccGetIMSIFromPFI(Tracabilite tracabilite_p, String pfi_p) throws RavelException
  {
    Connection con = null;
    ResultSet rs = null;
    final String methodName = "PG_IWSRESSOURCES.P_UPCC_GET_IMSI_FROM_PFI"; //$NON-NLS-1$
    try
    {
      con = _datasource.getConnection();
      CallableStatement cs = con.prepareCall("{call PG_IWSRESSOURCES.P_UPCC_GET_IMSI_FROM_PFI(?,?,?,?,?,?) }"); //$NON-NLS-1$
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("pi_PFI", pfi_p); //$NON-NLS-1$

      cs.registerOutParameter("po_RESULT", OracleTypes.CURSOR); //$NON-NLS-1$
      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();
      String imsi = null;

      Retour retour = getRetour(cs);
      rs = (ResultSet) cs.getObject("po_RESULT"); //$NON-NLS-1$
      if (StringConstants.OK.equals(retour.getResultat()) && (rs != null))
      {
        if (rs.next())
        {
          imsi = rs.getString("IMSI"); //$NON-NLS-1$
        }
      }

      return new ConnectorResponse<>(imsi, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("pi_PFI:").append(pfi_p).toString()); //$NON-NLS-1$

      // when insert takes too long
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, Messages.getString("STRConnector.ERREUR_STR_TIMEOUT_SUR_NON_REPONSE", _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("pi_PFI:").append(pfi_p).toString()); //$NON-NLS-1$

      //no sessions/connections available in the connection pool
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("STRConnector.ERREUR_STR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("pi_PFI:").append(pfi_p).toString()); //$NON-NLS-1$

      // when not able to connect
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, Messages.getString("STRConnector.ERREUR_STR_TIMEOUT_CONNEXION", _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append("pi_PFI:").append(pfi_p).toString()); //$NON-NLS-1$
    }
    catch (Exception e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, null);
    }
    finally
    {
      close(rs, con);
    }
  }

  @Override
  public ConnectorResponse<String, Retour> upccGetPFIFromMSISDN(Tracabilite tracabilite_p, String msisdn_p) throws RavelException
  {
    Connection con = null;
    ResultSet rs = null;
    final String methodName = "PG_IWSRESSOURCES.P_UPCC_GET_PFI_FROM_MSISDN"; //$NON-NLS-1$
    try
    {
      con = _datasource.getConnection();
      CallableStatement cs = con.prepareCall("{call PG_IWSRESSOURCES.P_UPCC_GET_PFI_FROM_MSISDN(?,?,?,?,?,?) }"); //$NON-NLS-1$
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("pi_MSISDN", msisdn_p); //$NON-NLS-1$

      cs.registerOutParameter("po_RESULT", OracleTypes.CURSOR); //$NON-NLS-1$
      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();
      String pfi = null;

      Retour retour = getRetour(cs);
      rs = (ResultSet) cs.getObject("po_RESULT"); //$NON-NLS-1$
      if (StringConstants.OK.equals(retour.getResultat()) && (rs != null))
      {
        if (rs.next())
        {
          pfi = rs.getString("PFI"); //$NON-NLS-1$
        }
      }

      return new ConnectorResponse<>(pfi, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("pi_MSISDN:").append(msisdn_p).toString()); //$NON-NLS-1$

      // when insert takes too long
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, MessageFormat.format(Messages.getString("STRConnector.ERREUR_STR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("pi_MSISDN:").append(msisdn_p).toString()); //$NON-NLS-1$

      //no sessions/connections available in the connection pool
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("STRConnector.ERREUR_STR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("pi_MSISDN:").append(msisdn_p).toString()); //$NON-NLS-1$

      // when not able to connect
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("STRConnector.ERREUR_STR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append("pi_MSISDN:").append(msisdn_p).toString()); //$NON-NLS-1$
    }
    catch (Exception e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, null);
    }
    finally
    {
      close(rs, con);
    }
  }

  @Override
  public ConnectorResponse<MigrerStaStwVersVstwResponse, Retour> migrerStaStwVersVstw(Tracabilite tracabilite_p, StMediaBox stmediaBox_p) throws RavelException
  {
    Connection con = null;

    _dsReadLock.lock();
    try
    {
      con = _datasource.getConnection();
      CallableStatement cs = con.prepareCall(ISQLStatement.PG_MIGSTW_PR_MIGSTW); //$NON-NLS-1$
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("pi_noTelephone", stmediaBox_p.getNoTelephone()); //$NON-NLS-1$
      cs.setInt("pi_pkMsisdn", Integer.parseInt(stmediaBox_p.getPkMsisdn())); //$NON-NLS-1$
      cs.setString("pi_PROFILEID", stmediaBox_p.getProfileId()); //$NON-NLS-1$
      cs.setString("pi_MBOXBLOCKEDSTATE", stmediaBox_p.getMboxBlockedState()); //$NON-NLS-1$
      cs.setString("pi_MWIVOIPSTATE", stmediaBox_p.getMwiState()); //$NON-NLS-1$
      cs.setString("pi_MBOXBLOCKEDBY", stmediaBox_p.getMboxBlockedBy()); //$NON-NLS-1$
      cs.setString("pi_MBOXBLOCKEDREASON", stmediaBox_p.getMboxBlockedReason()); //$NON-NLS-1$
      cs.setString("pi_IDTDERMOD", stmediaBox_p.getIdtDerMod()); //$NON-NLS-1$

      cs.registerOutParameter("po_pfi", OracleTypes.VARCHAR); //$NON-NLS-1$
      cs.registerOutParameter("po_eoickStw", OracleTypes.VARCHAR); //$NON-NLS-1$
      cs.registerOutParameter("po_eoickVstw", OracleTypes.VARCHAR); //$NON-NLS-1$
      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();

      MigrerStaStwVersVstwResponse migrerStaStwVersVstwResponse = new MigrerStaStwVersVstwResponse();

      Retour retour = getRetour(cs);
      migrerStaStwVersVstwResponse.setIdPfi(cs.getString("po_pfi")); //$NON-NLS-1$
      migrerStaStwVersVstwResponse.setEoickStw(cs.getString("po_eoickStw")); //$NON-NLS-1$
      migrerStaStwVersVstwResponse.setEoickVstw(cs.getString("po_eoickVstw")); //$NON-NLS-1$

      SpiritLogEvent outputLog = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, IMethodName.PG_MIGSTW_PR_MIGSTW);
      outputLog.addField("Retour", retour, false); //$NON-NLS-1$

      if (migrerStaStwVersVstwResponse.getIdPfi() != null)
      {
        outputLog.addField("po_pfi", migrerStaStwVersVstwResponse.getIdPfi(), false); //$NON-NLS-1$
      }
      RavelLogger.log(outputLog);

      return new ConnectorResponse<>(migrerStaStwVersVstwResponse, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, IMethodName.PG_MIGSTW_PR_MIGSTW, "StMediaBox:" + stmediaBox_p); //$NON-NLS-1$

      // when takes too long
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, MessageFormat.format(Messages.getString("STRConnector.ERREUR_STR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, IMethodName.PG_MIGSTW_PR_MIGSTW, "StMediaBox:" + stmediaBox_p); //$NON-NLS-1$

      //no sessions/connections available in the connection pool
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("STRConnector.ERREUR_STR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, IMethodName.PG_MIGSTW_PR_MIGSTW, "StMediaBox:" + stmediaBox_p); //$NON-NLS-1$

      // when not able to connect
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("STRConnector.ERREUR_STR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, IMethodName.PG_MIGSTW_PR_MIGSTW, "StMediaBox:" + stmediaBox_p); //$NON-NLS-1$
    }
    finally
    {
      close(null, con);
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<Nothing, Retour> inhiberStaStw(Tracabilite tracabilite_p, String noTelephone_p, String idtDerMod_p) throws RavelException
  {
    Connection con = null;

    _dsReadLock.lock();
    try
    {
      con = _datasource.getConnection();
      CallableStatement cs = con.prepareCall(ISQLStatement.PR_INHIBER_ST_VMS); //$NON-NLS-1$
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("pi_noTelephone", noTelephone_p); //$NON-NLS-1$
      cs.setString("pi_IDTDERMOD", idtDerMod_p); //$NON-NLS-1$

      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();

      Retour retour = getRetour(cs);

      SpiritLogEvent outputLog = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, IMethodName.PR_INHIBER_ST_VMS);
      outputLog.addField("Retour", retour, false); //$NON-NLS-1$

      RavelLogger.log(outputLog);

      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, IMethodName.PR_INHIBER_ST_VMS, "noTelephone:" + noTelephone_p + ", sIdtDerMod" + idtDerMod_p); //$NON-NLS-1$

      // when takes too long
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, MessageFormat.format(Messages.getString("STRConnector.ERREUR_STR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, IMethodName.PR_INHIBER_ST_VMS, "noTelephone:" + noTelephone_p + ", sIdtDerMod" + idtDerMod_p); //$NON-NLS-1$

      //no sessions/connections available in the connection pool
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("STRConnector.ERREUR_STR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, IMethodName.PR_INHIBER_ST_VMS, "noTelephone:" + noTelephone_p + ", sIdtDerMod" + idtDerMod_p); //$NON-NLS-1$

      // when not able to connect
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("STRConnector.ERREUR_STR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, IMethodName.PR_INHIBER_ST_VMS, "noTelephone:" + noTelephone_p + ", sIdtDerMod" + idtDerMod_p); //$NON-NLS-1$
    }
    finally
    {
      close(null, con);
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<String, Retour> annulerMigrerStaStwVersVstw(Tracabilite tracabilite_p, String noTelephone_p, String idtDerMod_p) throws RavelException
  {
    Connection con = null;

    _dsReadLock.lock();
    try
    {
      con = _datasource.getConnection();
      CallableStatement cs = con.prepareCall(ISQLStatement.PR_ANNULER_MIGSTW); //$NON-NLS-1$
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("pi_noTelephone", noTelephone_p); //$NON-NLS-1$
      cs.setString("pi_IDTDERMOD", idtDerMod_p); //$NON-NLS-1$

      cs.registerOutParameter("po_eoickStw", OracleTypes.VARCHAR); //$NON-NLS-1$
      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();

      Retour retour = getRetour(cs);
      String eoickStw = cs.getString("po_eoickStw");//$NON-NLS-1$

      SpiritLogEvent outputLog = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, IMethodName.PR_ANNULER_MIGSTW);
      outputLog.addField("Retour", retour, false); //$NON-NLS-1$

      RavelLogger.log(outputLog);

      return new ConnectorResponse<>(eoickStw, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, IMethodName.PR_ANNULER_MIGSTW, "noTelephone:" + noTelephone_p + ", sIdtDerMod" + idtDerMod_p); //$NON-NLS-1$

      // when takes too long
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, MessageFormat.format(Messages.getString("STRConnector.ERREUR_STR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, IMethodName.PR_ANNULER_MIGSTW, "noTelephone:" + noTelephone_p + ", sIdtDerMod" + idtDerMod_p); //$NON-NLS-1$

      //no sessions/connections available in the connection pool
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("STRConnector.ERREUR_STR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, IMethodName.PR_ANNULER_MIGSTW, "noTelephone:" + noTelephone_p + ", sIdtDerMod" + idtDerMod_p); //$NON-NLS-1$

      // when not able to connect
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("STRConnector.ERREUR_STR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, IMethodName.PR_ANNULER_MIGSTW, "noTelephone:" + noTelephone_p + ", sIdtDerMod" + idtDerMod_p); //$NON-NLS-1$
    }
    finally
    {
      close(null, con);
      _dsReadLock.unlock();
    }
  }

  /**
   * Close the {@link ResultSet} then the {@link Connection}. Each <code>null</code> parameter is ignored. SQLExceptions
   * raised are logged.
   *
   * @param resultSet_p
   *          The {@link ResultSet} to close. Can be <code>null</code>.
   * @param connection_p
   *          The {@link Connection} to close. Can be <code>null</code>.
   */
  protected void close(ResultSet resultSet_p, Connection connection_p)
  {
    if (resultSet_p != null)
    {
      try
      {
        resultSet_p.close();
      }
      catch (SQLException e)
      {
        RavelLogger.log(new SpiritLogEvent(LogSeverity.WARNING, MessageFormat.format(Messages.getString("STRConnector.ErrorClosingResultset"), e.getMessage()))); //$NON-NLS-1$
      }
    }
    if (connection_p != null)
    {
      try
      {
        connection_p.close();
      }
      catch (SQLException e)
      {
        RavelLogger.log(new SpiritLogEvent(LogSeverity.WARNING, MessageFormat.format(Messages.getString("STRConnector.ErrorClosingConnection"), e.getMessage()))); //$NON-NLS-1$
      }
    }
  }

  /**
   * Throws an {@link RavelException} for a technical problem.
   *
   * @param exc_p
   *          The {@link Exception} raised
   * @param tracabilite_p
   *          Tracabilite
   * @param spName_p
   *          The stored procedure name in which the fault was raised.
   * @param inputs_p
   *          A string representing input data of the stored procedure.
   * @return RavelException The technical exception.
   */
  private RavelException buildTechnicalException(Exception exc_p, Tracabilite tracabilite_p, String spName_p, String inputs_p)
  {
    final String message = buildTechnicalMessage(exc_p, tracabilite_p, spName_p, inputs_p);

    return new RavelException(ExceptionType.PFS_EXCEPTION, ErrorCode.CNCTOR_00010, message, ISTRConnector.BEAN_ID, exc_p);
  }

  /**
   * Build a log entry for a technical problem.
   *
   * @param exc_p
   *          The {@link Exception} raised
   * @param tracabilite_p
   *          Tracabilite
   * @param spName_p
   *          The stored procedure name in which the fault was raised.
   * @param inputs_p
   *          A string representing input data of the stored procedure.
   * @return String The technical message.
   */
  private String buildTechnicalMessage(Exception exc_p, Tracabilite tracabilite_p, String spName_p, String inputs_p)
  {
    final String message = new StringBuilder().append(MessageFormat.format(Messages.getString("STRConnector.TechnicalExceptionMessage"), spName_p, 0, exc_p.getLocalizedMessage())).append(ExceptionTools.getExceptionLineAndFile(exc_p)) // add fileName and line number of the exception //$NON-NLS-1$
        .toString();

    RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, message));

    return message;
  }

  /**
   * Close DB Connection
   *
   * @param preparedStatement_p
   *          prepared statement
   * @param connection_p
   *          connection
   */
  private void closeConnection(PreparedStatement preparedStatement_p, Connection connection_p)
  {
    if (preparedStatement_p != null)
    {
      try
      {
        preparedStatement_p.close();
      }
      catch (SQLException exception)
      {
        RavelLogger.log(new SpiritLogEvent(LogSeverity.WARNING, MessageFormat.format(Messages.getString("STRConnector.ErrorClosingPreparedStatement"), exception.getMessage()))); //$NON-NLS-1$
      }
    }

    if (connection_p != null)
    {
      try
      {
        connection_p.setAutoCommit(true);
        connection_p.close();
      }
      catch (SQLException exception)
      {
        RavelLogger.log(new SpiritLogEvent(LogSeverity.WARNING, MessageFormat.format(Messages.getString("STRConnector.ErrorClosingConnection"), exception.getMessage()))); //$NON-NLS-1$
      }
    }
  }
}
