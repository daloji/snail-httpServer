/*******************************************************************************
* $Id: TSMData.java 8367 2018-07-25 17:01:34Z kbettenc $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.str.structs;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Stores data for TSMData related with the command HMESPDP. <br/>
 *
 * @author tpatrici
 *
 */
public class TSMData
{
  /**
   *
   * @author lmerces
   * @version ($Revision: 8367 $ $Date: 2018-07-25 19:01:34 +0200 (mer. 25 juil. 2018) $)
   */
  public enum Fields
  {
    /**
     *
     */
    ALIAS,
    /**
    *
    */
    ICCID,
    /**
    *
    */
    CARTEPROFILE,
    /**
    *
    */
    LINESTATUS
  }

  /**
   * Field to store ALIAS
   */
  private String _alias;
  /**
   * Field to store ICCID
   */
  private String _iccid;
  /**
   * Field to store CarteProfile
   */
  private String _carteprofile;
  /**
   * Field to store linestatus
   */
  private String _linestatus;

  /**
   * Constructor
   */
  public TSMData()
  {
    super();
  }

  /**
   * Constructor
   *
   * @param rs_p
   *          resultset
   * @throws SQLException
   *           exception
   */
  public TSMData(ResultSet rs_p) throws SQLException
  {
    _alias = rs_p.getString(TSMData.Fields.ALIAS.name());
    _iccid = rs_p.getString(TSMData.Fields.ICCID.name());
    _carteprofile = rs_p.getString(TSMData.Fields.CARTEPROFILE.name());
    _linestatus = rs_p.getString(TSMData.Fields.LINESTATUS.name());
  }

  /**
   * @return the alias
   */
  public String getAlias()
  {
    return _alias;
  }

  /**
   * @return the carteprofile
   */
  public String getCarteprofile()
  {
    return _carteprofile;
  }

  /**
   * @return the iccid
   */
  public String getIccid()
  {
    return _iccid;
  }

  /**
   * @return the linestatus
   */
  public String getLinestatus()
  {
    return _linestatus;
  }

  /**
   * @param alias_p
   *          the alias to set
   */
  public void setAlias(String alias_p)
  {
    this._alias = alias_p;
  }

  /**
   * @param carteprofile_p
   *          the carteprofile to set
   */
  public void setCarteprofile(String carteprofile_p)
  {
    this._carteprofile = carteprofile_p;
  }

  /**
   * @param iccid_p
   *          the iccid to set
   */
  public void setIccid(String iccid_p)
  {
    this._iccid = iccid_p;
  }

  /**
   * @param linestatus_p
   *          the linestatus to set
   */
  public void setLinestatus(String linestatus_p)
  {
    this._linestatus = linestatus_p;
  }
}
