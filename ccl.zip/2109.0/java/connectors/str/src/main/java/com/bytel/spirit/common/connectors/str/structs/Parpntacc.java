/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.str.structs;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;

/**
 * @author sfernand
 * @version ($Revision$ $Date$)
 */
public class Parpntacc
{
  /**
   * Nom de la colonne IdentifiantParpntacc
   */
  private static final String COLUMN_ID_PARPNTACC_PRM = "PK_PARPNTACC"; //$NON-NLS-1$

  /**
   * Nom de la colonne PFI
   */
  private static final String COLUMN_PFI_PRM = "PFI"; //$NON-NLS-1$

  /**
   * Nom de la colonne IdentifiantPointAcces
   */
  private static final String COLUMN_ID_POINTACCES_PRM = "IDTPNTACC"; //$NON-NLS-1$

  /**
   * Nom de la colonne TypePointAccesGenerique
   */
  private static final String COLUMN_TYPE_POINTACCESGENERIQUE_PRM = "FK_TYPPNTACCGEN"; //$NON-NLS-1$

  /**
   * Nom de la colonne TypePointAccesCommercial
   */
  private static final String COLUMN_TYPE_POINTACCESCOMMERCIAL_PRM = "FK_TYPPNTACCCOM"; //$NON-NLS-1$

  /**
   * Nom de la colonne Technologie
   */
  private static final String COLUMN_TECHNOLOGIE_PRM = "TCN"; //$NON-NLS-1$

  /**
   * Nom de la colonne NomParametre
   */
  private static final String COLUMN_NOMPARAMETRE_PRM = "NOMPAR"; //$NON-NLS-1$

  /**
   * Nom de la colonne ValParametre
   */
  private static final String COLUMN_VALPARAMETRE_PRM = "VALPAR"; //$NON-NLS-1$

  /**
   * Nom de la colonne IdentifiantDerniereModification
   */
  private static final String COLUMN_ID_DERNIEREMODIF_PRM = "IDTDERMOD"; //$NON-NLS-1$

  /**
   * Nom de la colonne ActeDerniereModification
   */
  private static final String COLUMN_ACTE_DERNIEREMODIF_PRM = "ACTDERMOD"; //$NON-NLS-1$

  /**
   * Nom de la colonne DateDerniereModification
   */
  private static final String COLUMN_DATE_DERNIEREMODIF_PRM = "DATDERMOD"; //$NON-NLS-1$

  /**
   * IdentifiantParpntacc
   */
  private Long _identifiantParpntacc;

  /**
   * Pfi
   */
  private String _pfi;

  /**
   * IdentifiantPointAcces
   */
  private String _identifiantPointAcces;

  /**
   * TypePointAccesGenerique
   */
  private Integer _typePointAccesGenerique;

  /**
   * TypePointAccesCommercial
   */
  private Integer _typePointAccesCommercial;

  /**
   * Technologie
   */
  private String _technologie;

  /**
   * NomParametre
   */
  private String _nomParametre;

  /**
   * ValParametre
   */
  private String _valParametre;

  /**
   * IdentifiantDerniereModification
   */
  private String _identifiantDerniereModification;

  /**
   * ActeDerniereModification;
   */
  private String _acteDerniereModification;

  /**
   * DateDerniereModification
   */
  private LocalDateTime _dateDerniereModification;

  /**
   * Contructor
   */
  public Parpntacc()
  {
    super();
  }

  /**
   * Constructeur
   *
   * @param rs
   *          The ResultSet to get the value of DonneesClient from
   * @throws SQLException
   *           on error
   */
  public Parpntacc(ResultSet rs) throws SQLException
  {
    this._identifiantParpntacc = rs.getLong(COLUMN_ID_PARPNTACC_PRM);
    this._pfi = rs.getString(COLUMN_PFI_PRM);
    this._identifiantPointAcces = rs.getString(COLUMN_ID_POINTACCES_PRM);
    this._typePointAccesGenerique = rs.getInt(COLUMN_TYPE_POINTACCESGENERIQUE_PRM);
    this._typePointAccesCommercial = rs.getInt(COLUMN_TYPE_POINTACCESCOMMERCIAL_PRM);
    this._technologie = rs.getString(COLUMN_TECHNOLOGIE_PRM);
    this._nomParametre = rs.getString(COLUMN_NOMPARAMETRE_PRM);
    this._valParametre = rs.getString(COLUMN_VALPARAMETRE_PRM);
    this._identifiantDerniereModification = rs.getString(COLUMN_ID_DERNIEREMODIF_PRM);
    this._acteDerniereModification = rs.getString(COLUMN_ACTE_DERNIEREMODIF_PRM);
    this._dateDerniereModification = new Timestamp(rs.getDate(COLUMN_DATE_DERNIEREMODIF_PRM).getTime()).toLocalDateTime();
  }

  /**
   * @return value of _acteDerniereModification
   */
  public String getActeDerniereModification()
  {
    return _acteDerniereModification;
  }

  /**
   * @return value of _dateDerniereModification
   */
  public LocalDateTime getDateDerniereModification()
  {
    return _dateDerniereModification;
  }

  /**
   * @return value of _identifiantDerniereModification
   */
  public String getIdentifiantDerniereModification()
  {
    return _identifiantDerniereModification;
  }

  /**
   * @return value of _identifiantParpntacc
   */
  public Long getIdentifiantParpntacc()
  {
    return _identifiantParpntacc;
  }

  /**
   * @return value of _identifiantPointAcces
   */
  public String getIdentifiantPointAcces()
  {
    return _identifiantPointAcces;
  }

  /**
   * @return value of _nomParametre
   */
  public String getNomParametre()
  {
    return _nomParametre;
  }

  /**
   * @return value of _pfi
   */
  public String getPfi()
  {
    return _pfi;
  }

  /**
   * @return value of _technologie
   */
  public String getTechnologie()
  {
    return _technologie;
  }

  /**
   * @return value of _typePointAccesCommercial
   */
  public Integer getTypePointAccesCommercial()
  {
    return _typePointAccesCommercial;
  }

  /**
   * @return value of _typePointAccesGenerique
   */
  public Integer getTypePointAccesGenerique()
  {
    return _typePointAccesGenerique;
  }

  /**
   * @return value of _valParametre
   */
  public String getValParametre()
  {
    return _valParametre;
  }

  /**
   * @param acteDerniereModification_p
   *          The _acteDerniereModification to set.
   */
  public void setActeDerniereModification(String acteDerniereModification_p)
  {
    _acteDerniereModification = acteDerniereModification_p;
  }

  /**
   * @param dateDerniereModification_p
   *          The _dateDerniereModification to set.
   */
  public void setDateDerniereModification(LocalDateTime dateDerniereModification_p)
  {
    _dateDerniereModification = dateDerniereModification_p;
  }

  /**
   * @param identifiantDerniereModification_p
   *          The _identifiantDerniereModification to set.
   */
  public void setIdentifiantDerniereModification(String identifiantDerniereModification_p)
  {
    _identifiantDerniereModification = identifiantDerniereModification_p;
  }

  /**
   * @param identifiantParpntacc_p
   *          The _identifiantParpntacc to set.
   */
  public void setIdentifiantParpntacc(Long identifiantParpntacc_p)
  {
    _identifiantParpntacc = identifiantParpntacc_p;
  }

  /**
   * @param identifiantPointAcces_p
   *          The _identifiantPointAcces to set.
   */
  public void setIdentifiantPointAcces(String identifiantPointAcces_p)
  {
    _identifiantPointAcces = identifiantPointAcces_p;
  }

  /**
   * @param nomParametre_p
   *          The _nomParametre to set.
   */
  public void setNomParametre(String nomParametre_p)
  {
    _nomParametre = nomParametre_p;
  }

  /**
   * @param pfi_p
   *          The _pfi to set.
   */
  public void setPfi(String pfi_p)
  {
    _pfi = pfi_p;
  }

  /**
   * @param technologie_p
   *          The _technologie to set.
   */
  public void setTechnologie(String technologie_p)
  {
    _technologie = technologie_p;
  }

  /**
   * @param typePointAccesCommercial_p
   *          The _typePointAccesCommercial to set.
   */
  public void setTypePointAccesCommercial(Integer typePointAccesCommercial_p)
  {
    _typePointAccesCommercial = typePointAccesCommercial_p;
  }

  /**
   * @param typePointAccesGenerique_p
   *          The _typePointAccesGenerique to set.
   */
  public void setTypePointAccesGenerique(Integer typePointAccesGenerique_p)
  {
    _typePointAccesGenerique = typePointAccesGenerique_p;
  }

  /**
   * @param valParametre_p
   *          The _valParametre to set.
   */
  public void setValParametre(String valParametre_p)
  {
    _valParametre = valParametre_p;
  }
}
