/*******************************************************************************
* $Id: AuditUDCHEMSSDP.java 8367 2018-07-25 17:01:34Z kbettenc $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.str.structs;

/**
 *
 * @author lmerces
 * @version ($Revision: 8367 $ $Date: 2018-07-25 19:01:34 +0200 (mer. 25 juil. 2018) $)
 */
public class AuditUDCHEMSSDP
{
  /**
   * MSISDN
   */
  private String _msisdn;

  /**
   * IMSI
   */
  private String _imsi;

  /**
   * NAM
   */
  private String _nam;

  /**
   * AMSISDN
   */
  private String _amsisdn;

  /**
   * Constructor
   */
  public AuditUDCHEMSSDP()
  {
    super();
  }

  /**
   * Constructor
   *
   * @param msisdn_p
   *          MSISDN
   * @param imsi_p
   *          IMSI
   * @param nam_p
   *          NAM
   * @param amsisdn_p
   *          AMSISDN
   */
  public AuditUDCHEMSSDP(String msisdn_p, String imsi_p, String nam_p, String amsisdn_p)
  {
    super();
    _msisdn = msisdn_p;
    _imsi = imsi_p;
    _nam = nam_p;
    _amsisdn = amsisdn_p;
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    AuditUDCHEMSSDP other = (AuditUDCHEMSSDP) obj;
    if (_amsisdn == null)
    {
      if (other._amsisdn != null)
      {
        return false;
      }
    }
    else if (!_amsisdn.equals(other._amsisdn))
    {
      return false;
    }
    if (_imsi == null)
    {
      if (other._imsi != null)
      {
        return false;
      }
    }
    else if (!_imsi.equals(other._imsi))
    {
      return false;
    }
    if (_msisdn == null)
    {
      if (other._msisdn != null)
      {
        return false;
      }
    }
    else if (!_msisdn.equals(other._msisdn))
    {
      return false;
    }
    if (_nam == null)
    {
      if (other._nam != null)
      {
        return false;
      }
    }
    else if (!_nam.equals(other._nam))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the amsisdn
   */
  public String getAmsisdn()
  {
    return _amsisdn;
  }

  /**
   * @return the imsi
   */
  public String getImsi()
  {
    return _imsi;
  }

  /**
   * @return the msisdn
   */
  public String getMsisdn()
  {
    return _msisdn;
  }

  /**
   * @return the nam
   */
  public String getNam()
  {
    return _nam;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_amsisdn == null) ? 0 : _amsisdn.hashCode());
    result = (prime * result) + ((_imsi == null) ? 0 : _imsi.hashCode());
    result = (prime * result) + ((_msisdn == null) ? 0 : _msisdn.hashCode());
    result = (prime * result) + ((_nam == null) ? 0 : _nam.hashCode());
    return result;
  }

  /**
   * @param amsisdn_p
   *          the amsisdn to set
   */
  public void setAmsisdn(String amsisdn_p)
  {
    _amsisdn = amsisdn_p;
  }

  /**
   * @param imsi_p
   *          the imsi to set
   */
  public void setImsi(String imsi_p)
  {
    _imsi = imsi_p;
  }

  /**
   * @param msisdn_p
   *          the msisdn to set
   */
  public void setMsisdn(String msisdn_p)
  {
    _msisdn = msisdn_p;
  }

  /**
   * @param nam_p
   *          the nam to set
   */
  public void setNam(String nam_p)
  {
    _nam = nam_p;
  }
}
