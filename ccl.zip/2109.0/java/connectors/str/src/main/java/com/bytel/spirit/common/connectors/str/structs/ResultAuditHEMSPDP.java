/*******************************************************************************
* $Id: ResultAuditHEMSPDP.java 8367 2018-07-25 17:01:34Z kbettenc $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.str.structs;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

/**
 *
 * @author lmerces
 * @version ($Revision: 8367 $ $Date: 2018-07-25 19:01:34 +0200 (mer. 25 juil. 2018) $)
 */
public class ResultAuditHEMSPDP
{
  /**
   * Field PK_RESULT_HEMSSDP name
   */
  public static final String FIELD_ID = "PK_RESULT_HEMSPDP"; //$NON-NLS-1$

  /**
   * Field DATEEVENT name
   */
  public static final String FIELD_DATE_EVENT = "DATEEVENT"; //$NON-NLS-1$

  /**
   * Field MSISDN_UDC name
   */
  public static final String FIELD_MSISDN_UDC = "MSISDN_UDC"; //$NON-NLS-1$

  /**
   * Field MSISDN_NPBT name
   */
  public static final String FIELD_MSISDN_NPBT = "MSISDN_NPBT"; //$NON-NLS-1$

  /**
   * Field IMSI_UDC name
   */
  public static final String FIELD_IMSI_UDC = "IMSI_UDC"; //$NON-NLS-1$

  /**
   * Field IMSI_NPBT name
   */
  public static final String FIELD_IMSI_NPBT = "IMSI_NPBT"; //$NON-NLS-1$

  /**
   * Field APNID_UDC name
   */
  public static final String FIELD_APNID_UDC = "APNID_UDC"; //$NON-NLS-1$

  /**
   * Field APNID_NPBT name
   */
  public static final String FIELD_APNID_NPBT = "APNID_NPBT"; //$NON-NLS-1$

  /**
   * Field EQOSID_UDC name
   */
  public static final String FIELD_EQOSID_UDC = "EQOSID_UDC"; //$NON-NLS-1$

  /**
   * Field EQOSID_NPBT name
   */
  public static final String FIELD_EQOSID_NPBT = "EQOSID_NPBT"; //$NON-NLS-1$

  /**
   * Field PDPID_UDC name
   */
  public static final String FIELD_PDPID_UDC = "PDPID_UDC"; //$NON-NLS-1$

  /**
   * Field PDPID_NPBT name
   */
  public static final String FIELD_PDPID_NPBT = "PDPID_NPBT"; //$NON-NLS-1$

  /**
   * Field EPDPIND_UDC name
   */
  public static final String FIELD_EPDPIND_UDC = "EPDPIND_UDC"; //$NON-NLS-1$

  /**
   * Field EPDPIND_NPBT name
   */
  public static final String FIELD_EPDPIND_NPBT = "EPDPIND_NPBT"; //$NON-NLS-1$

  /**
   * Field MESSAGE name
   */
  public static final String FIELD_MESSAGE = "MESSAGE"; //$NON-NLS-1$

  /**
   * ID
   */
  private Long _id;

  /**
   * Date Event
   */
  private Date _dateEvent;

  /**
   * MSISDN UDC
   */
  private String _msisdnUDC;

  /**
   * MSISDN NPBT
   */
  private String _msisdnNPBT;

  /**
   * IMSI UDC
   */
  private String _imsiUDC;

  /**
   * IMSI NPBT
   */
  private String _imsiNPBT;

  /**
   * APNID UDC
   */
  private String _apnidUDC;

  /**
   * APNID NPBT
   */
  private String _apnidNPBT;

  /**
   * EQOSID UDC
   */
  private String _eqosidUDC;

  /**
   * EQOSID NPBT
   */
  private String _eqosidNPBT;

  /**
   * PDPID UDC
   */
  private String _pdpidUDC;

  /**
   * PDPID NPBT
   */
  private String _pdpidNPBT;

  /**
   * EPDPIND UDC
   */
  private String _epdpindUDC;

  /**
   * EPDPIND NPBT
   */
  private String _epdpindNPBT;

  /**
   * Message
   */
  private String _message;

  /**
   * Constructor
   */
  public ResultAuditHEMSPDP()
  {
    super();
  }

  /**
   * Constructor
   *
   * @param rs_p
   *          resultset
   * @throws SQLException
   *           exception
   */
  public ResultAuditHEMSPDP(ResultSet rs_p) throws SQLException
  {
    this._dateEvent = rs_p.getTimestamp(ResultAuditHEMSPDP.FIELD_DATE_EVENT);
    this._msisdnUDC = rs_p.getString(ResultAuditHEMSPDP.FIELD_MSISDN_UDC);
    this._msisdnNPBT = rs_p.getString(ResultAuditHEMSPDP.FIELD_MSISDN_NPBT);
    this._imsiUDC = rs_p.getString(ResultAuditHEMSPDP.FIELD_IMSI_UDC);
    this._imsiNPBT = rs_p.getString(ResultAuditHEMSPDP.FIELD_IMSI_NPBT);
    this._apnidUDC = rs_p.getString(ResultAuditHEMSPDP.FIELD_APNID_UDC);
    this._apnidNPBT = rs_p.getString(ResultAuditHEMSPDP.FIELD_APNID_NPBT);
    this._eqosidUDC = rs_p.getString(ResultAuditHEMSPDP.FIELD_EQOSID_UDC);
    this._eqosidNPBT = rs_p.getString(ResultAuditHEMSPDP.FIELD_EQOSID_NPBT);
    this._pdpidUDC = rs_p.getString(ResultAuditHEMSPDP.FIELD_PDPID_UDC);
    this._pdpidNPBT = rs_p.getString(ResultAuditHEMSPDP.FIELD_PDPID_NPBT);
    this._epdpindUDC = rs_p.getString(ResultAuditHEMSPDP.FIELD_EPDPIND_UDC);
    this._epdpindNPBT = rs_p.getString(ResultAuditHEMSPDP.FIELD_EPDPIND_NPBT);
    this._message = rs_p.getString(ResultAuditHEMSPDP.FIELD_MESSAGE);
  }

  /**
   * @return the apnidNPBT
   */
  public String getApnidNPBT()
  {
    return _apnidNPBT;
  }

  /**
   * @return the apnidUDC
   */
  public String getApnidUDC()
  {
    return _apnidUDC;
  }

  /**
   * @return the dateEvent
   */
  public Date getDateEvent()
  {
    return _dateEvent == null ? null : new Date(_dateEvent.getTime());
  }

  /**
   * @return the epdpindNPBT
   */
  public String getEpdpindNPBT()
  {
    return _epdpindNPBT;
  }

  /**
   * @return the epdpindUDC
   */
  public String getEpdpindUDC()
  {
    return _epdpindUDC;
  }

  /**
   * @return the eqosidNPBT
   */
  public String getEqosidNPBT()
  {
    return _eqosidNPBT;
  }

  /**
   * @return the eqosidUDC
   */
  public String getEqosidUDC()
  {
    return _eqosidUDC;
  }

  /**
   * @return the id
   */
  public Long getId()
  {
    return _id;
  }

  /**
   * @return the imsiNPBT
   */
  public String getImsiNPBT()
  {
    return _imsiNPBT;
  }

  /**
   * @return the imsiUDC
   */
  public String getImsiUDC()
  {
    return _imsiUDC;
  }

  /**
   * @return the message
   */
  public String getMessage()
  {
    return _message;
  }

  /**
   * @return the msisdnNPBT
   */
  public String getMsisdnNPBT()
  {
    return _msisdnNPBT;
  }

  /**
   * @return the msisdnUDC
   */
  public String getMsisdnUDC()
  {
    return _msisdnUDC;
  }

  /**
   * @return the pdpidNPBT
   */
  public String getPdpidNPBT()
  {
    return _pdpidNPBT;
  }

  /**
   * @return the pdpidUDC
   */
  public String getPdpidUDC()
  {
    return _pdpidUDC;
  }

  /**
   * @param apnidNPBT_p
   *          the apnidNPBT to set
   */
  public void setApnidNPBT(String apnidNPBT_p)
  {
    _apnidNPBT = apnidNPBT_p;
  }

  /**
   * @param apnidUDC_p
   *          the apnidUDC to set
   */
  public void setApnidUDC(String apnidUDC_p)
  {
    _apnidUDC = apnidUDC_p;
  }

  /**
   * @param dateEvent_p
   *          the dateEvent to set
   */
  public void setDateEvent(Date dateEvent_p)
  {
    _dateEvent = dateEvent_p == null ? null : new Date(dateEvent_p.getTime());
  }

  /**
   * @param epdpindNPBT_p
   *          the epdpindNPBT to set
   */
  public void setEpdpindNPBT(String epdpindNPBT_p)
  {
    _epdpindNPBT = epdpindNPBT_p;
  }

  /**
   * @param epdpindUDC_p
   *          the epdpindUDC to set
   */
  public void setEpdpindUDC(String epdpindUDC_p)
  {
    _epdpindUDC = epdpindUDC_p;
  }

  /**
   * @param eqosidNPBT_p
   *          the eqosidNPBT to set
   */
  public void setEqosidNPBT(String eqosidNPBT_p)
  {
    _eqosidNPBT = eqosidNPBT_p;
  }

  /**
   * @param eqosidUDC_p
   *          the eqosidUDC to set
   */
  public void setEqosidUDC(String eqosidUDC_p)
  {
    _eqosidUDC = eqosidUDC_p;
  }

  /**
   * @param id_p
   *          the id to set
   */
  public void setId(Long id_p)
  {
    _id = id_p;
  }

  /**
   * @param imsiNPBT_p
   *          the imsiNPBT to set
   */
  public void setImsiNPBT(String imsiNPBT_p)
  {
    _imsiNPBT = imsiNPBT_p;
  }

  /**
   * @param imsiUDC_p
   *          the imsiUDC to set
   */
  public void setImsiUDC(String imsiUDC_p)
  {
    _imsiUDC = imsiUDC_p;
  }

  /**
   * @param message_p
   *          the message to set
   */
  public void setMessage(String message_p)
  {
    _message = message_p;
  }

  /**
   * @param msisdnNPBT_p
   *          the msisdnNPBT to set
   */
  public void setMsisdnNPBT(String msisdnNPBT_p)
  {
    _msisdnNPBT = msisdnNPBT_p;
  }

  /**
   * @param msisdnUDC_p
   *          the msisdnUDC to set
   */
  public void setMsisdnUDC(String msisdnUDC_p)
  {
    _msisdnUDC = msisdnUDC_p;
  }

  /**
   * @param pdpidNPBT_p
   *          the pdpidNPBT to set
   */
  public void setPdpidNPBT(String pdpidNPBT_p)
  {
    _pdpidNPBT = pdpidNPBT_p;
  }

  /**
   * @param pdpidUDC_p
   *          the pdpidUDC to set
   */
  public void setPdpidUDC(String pdpidUDC_p)
  {
    _pdpidUDC = pdpidUDC_p;
  }
}
