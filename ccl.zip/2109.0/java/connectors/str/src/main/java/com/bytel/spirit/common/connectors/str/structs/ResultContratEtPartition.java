/*******************************************************************************
* $Id: ResultContratEtPartition.java 22585 2019-06-11 13:32:20Z fbarnabe $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.str.structs;

import java.io.Serializable;

/**
 *
 * @author jiantila
 * @version ($Revision: 22585 $ $Date: 2019-06-11 15:32:20 +0200 (mar. 11 juin 2019) $)
 */
public class ResultContratEtPartition implements Serializable
{

  /**
   *
   */
  private static final long serialVersionUID = 1L;

  /**
   *
   */
  private String _numContrat;

  /**
   *
   */
  private String _partition;

  /**
   * Constructor
   *
   * @param numContrat_p
   *          num contract
   * @param partition
   *          partition
   */
  public ResultContratEtPartition(String numContrat_p, String partition)
  {
    _numContrat = numContrat_p;
    _partition = partition;
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    ResultContratEtPartition other = (ResultContratEtPartition) obj;
    if (_numContrat == null)
    {
      if (other._numContrat != null)
      {
        return false;
      }
    }
    else if (!_numContrat.equals(other._numContrat))
    {
      return false;
    }
    if (_partition == null)
    {
      if (other._partition != null)
      {
        return false;
      }
    }
    else if (!_partition.equals(other._partition))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the numContrat
   */
  public String getNumContrat()
  {
    return _numContrat;
  }

  /**
   * @return the partition
   */
  public String getPartition()
  {
    return _partition;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_numContrat == null) ? 0 : _numContrat.hashCode());
    result = (prime * result) + ((_partition == null) ? 0 : _partition.hashCode());
    return result;
  }

  /**
   * @param numContrat_p
   *          the numContrat to set
   */
  public void setNumContrat(String numContrat_p)
  {
    _numContrat = numContrat_p;
  }

  /**
   * @param partition_p
   *          the partition to set
   */
  public void setPartition(String partition_p)
  {
    _partition = partition_p;
  }

  @Override
  public String toString()
  {
    return "ResultContratEtPartition [_numContrat=" + _numContrat + ", _partition=" + _partition + "]"; //$NON-NLS-1$//$NON-NLS-2$ //$NON-NLS-3$
  }

}
