/*******************************************************************************
* $Id: ResultAuditHEMSSDP.java 8367 2018-07-25 17:01:34Z kbettenc $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.str.structs;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

/**
 *
 * @author lmerces
 * @version ($Revision: 8367 $ $Date: 2018-07-25 19:01:34 +0200 (mer. 25 juil. 2018) $)
 */
public class ResultAuditHEMSSDP
{
  /**
   * Field PK_RESULT_HEMSSDP name
   */
  public static final String FIELD_ID = "PK_RESULT_HEMSSDP"; //$NON-NLS-1$

  /**
   * Field DATEEVENT name
   */
  public static final String FIELD_DATE_EVENT = "DATEEVENT"; //$NON-NLS-1$

  /**
   * Field MSISDN_UDC name
   */
  public static final String FIELD_MSISDN_UDC = "MSISDN_UDC"; //$NON-NLS-1$

  /**
   * Field MSISDN_NPBT name
   */
  public static final String FIELD_MSISDN_NPBT = "MSISDN_NPBT"; //$NON-NLS-1$

  /**
   * Field IMSI_UDC name
   */
  public static final String FIELD_IMSI_UDC = "IMSI_UDC"; //$NON-NLS-1$

  /**
   * Field IMSI_NPBT name
   */
  public static final String FIELD_IMSI_NPBT = "IMSI_NPBT"; //$NON-NLS-1$

  /**
   * Field NAM_UDC name
   */
  public static final String FIELD_NAM_UDC = "NAM_UDC"; //$NON-NLS-1$

  /**
   * Field NAM_NPBT name
   */
  public static final String FIELD_NAM_NPBT = "NAM_NPBT"; //$NON-NLS-1$

  /**
   * Field AMSISDN_UDC name
   */
  public static final String FIELD_AMSISDN_UDC = "AMSISDN_UDC"; //$NON-NLS-1$

  /**
   * Field AMSISDN_NPBT name
   */
  public static final String FIELD_AMSISDN_NPBT = "AMSISDN_NPBT"; //$NON-NLS-1$

  /**
   * Field MESSAGE name
   */
  public static final String FIELD_MESSAGE = "MESSAGE"; //$NON-NLS-1$

  /**
   * ID
   */
  private Long _id;

  /**
   * Date Event
   */
  private Date _dateEvent;

  /**
   * MSISDN UDC
   */
  private String _msisdnUDC;

  /**
   * MSISDN NPBT
   */
  private String _msisdnNPBT;

  /**
   * IMSI UDC
   */
  private String _imsiUDC;

  /**
   * IMSI NPBT
   */
  private String _imsiNPBT;

  /**
   * NAM UDC
   */
  private String _namUDC;

  /**
   * NAM NPBT
   */
  private String _namNPBT;

  /**
   * AMSISDN UDC
   */
  private String _amsisdnUDC;

  /**
   * AMSISDN NPBT
   */
  private String _amsisdnNPBT;

  /**
   * Message
   */
  private String _message;

  /**
   * Constructor
   */
  public ResultAuditHEMSSDP()
  {
    super();
  }

  /**
   * Constructor
   *
   * @param rs_p
   *          resultset
   * @throws SQLException
   *           exception
   */
  public ResultAuditHEMSSDP(ResultSet rs_p) throws SQLException
  {
    this._dateEvent = rs_p.getTimestamp(ResultAuditHEMSSDP.FIELD_DATE_EVENT);
    this._msisdnUDC = rs_p.getString(ResultAuditHEMSSDP.FIELD_MSISDN_UDC);
    this._msisdnNPBT = rs_p.getString(ResultAuditHEMSSDP.FIELD_MSISDN_NPBT);
    this._imsiUDC = rs_p.getString(ResultAuditHEMSSDP.FIELD_IMSI_UDC);
    this._imsiNPBT = rs_p.getString(ResultAuditHEMSSDP.FIELD_IMSI_NPBT);
    this._namUDC = rs_p.getString(ResultAuditHEMSSDP.FIELD_NAM_UDC);
    this._namNPBT = rs_p.getString(ResultAuditHEMSSDP.FIELD_NAM_NPBT);
    this._amsisdnUDC = rs_p.getString(ResultAuditHEMSSDP.FIELD_AMSISDN_UDC);
    this._amsisdnNPBT = rs_p.getString(ResultAuditHEMSSDP.FIELD_AMSISDN_NPBT);
    this._message = rs_p.getString(ResultAuditHEMSSDP.FIELD_MESSAGE);

  }

  /**
   * @return the amsisdnNPBT
   */
  public String getAmsisdnNPBT()
  {
    return _amsisdnNPBT;
  }

  /**
   * @return the amsisdnUDC
   */
  public String getAmsisdnUDC()
  {
    return _amsisdnUDC;
  }

  /**
   * @return the dateEvent
   */
  public Date getDateEvent()
  {
    return _dateEvent == null ? null : new Date(_dateEvent.getTime());
  }

  /**
   * @return the id
   */
  public Long getId()
  {
    return _id;
  }

  /**
   * @return the imsiNPBT
   */
  public String getImsiNPBT()
  {
    return _imsiNPBT;
  }

  /**
   * @return the imsiUDC
   */
  public String getImsiUDC()
  {
    return _imsiUDC;
  }

  /**
   * @return the message
   */
  public String getMessage()
  {
    return _message;
  }

  /**
   * @return the msisdnNPBT
   */
  public String getMsisdnNPBT()
  {
    return _msisdnNPBT;
  }

  /**
   * @return the msisdnUDC
   */
  public String getMsisdnUDC()
  {
    return _msisdnUDC;
  }

  /**
   * @return the namNPBT
   */
  public String getNamNPBT()
  {
    return _namNPBT;
  }

  /**
   * @return the namUDC
   */
  public String getNamUDC()
  {
    return _namUDC;
  }

  /**
   * @param amsisdnNPBT_p
   *          the amsisdnNPBT to set
   */
  public void setAmsisdnNPBT(String amsisdnNPBT_p)
  {
    _amsisdnNPBT = amsisdnNPBT_p;
  }

  /**
   * @param amsisdnUDC_p
   *          the amsisdnUDC to set
   */
  public void setAmsisdnUDC(String amsisdnUDC_p)
  {
    _amsisdnUDC = amsisdnUDC_p;
  }

  /**
   * @param dateEvent_p
   *          the dateEvent to set
   */
  public void setDateEvent(Date dateEvent_p)
  {
    _dateEvent = dateEvent_p == null ? null : new Date(dateEvent_p.getTime());
  }

  /**
   * @param id_p
   *          the id to set
   */
  public void setId(Long id_p)
  {
    _id = id_p;
  }

  /**
   * @param imsiNPBT_p
   *          the imsiNPBT to set
   */
  public void setImsiNPBT(String imsiNPBT_p)
  {
    _imsiNPBT = imsiNPBT_p;
  }

  /**
   * @param imsiUDC_p
   *          the imsiUDC to set
   */
  public void setImsiUDC(String imsiUDC_p)
  {
    _imsiUDC = imsiUDC_p;
  }

  /**
   * @param message_p
   *          the message to set
   */
  public void setMessage(String message_p)
  {
    _message = message_p;
  }

  /**
   * @param msisdnNPBT_p
   *          the msisdnNPBT to set
   */
  public void setMsisdnNPBT(String msisdnNPBT_p)
  {
    _msisdnNPBT = msisdnNPBT_p;
  }

  /**
   * @param msisdnUDC_p
   *          the msisdnUDC to set
   */
  public void setMsisdnUDC(String msisdnUDC_p)
  {
    _msisdnUDC = msisdnUDC_p;
  }

  /**
   * @param namNPBT_p
   *          the namNPBT to set
   */
  public void setNamNPBT(String namNPBT_p)
  {
    _namNPBT = namNPBT_p;
  }

  /**
   * @param namUDC_p
   *          the namUDC to set
   */
  public void setNamUDC(String namUDC_p)
  {
    _namUDC = namUDC_p;
  }
}
