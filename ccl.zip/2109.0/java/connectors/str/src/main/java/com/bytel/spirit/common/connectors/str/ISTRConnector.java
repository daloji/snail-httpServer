/*******************************************************************************
* $Id: ISTRConnector.java 8367 2018-07-25 17:01:34Z kbettenc $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.str;

import com.bytel.ravel.services.connector.IConnector;

/**
 * Adds the Connector ID to the ISTR interface
 *
 * @author $Author: dmonteir $
 * @version ($Revision: 8367 $ $Date: 2018-07-25 19:01:34 +0200 (mer. 25 juil. 2018) $)
 */
public interface ISTRConnector extends IConnector, ISTR
{
  /**
   * The id to retrieve the connector.
   */
  String BEAN_ID = "STRConnector"; //$NON-NLS-1$
}
