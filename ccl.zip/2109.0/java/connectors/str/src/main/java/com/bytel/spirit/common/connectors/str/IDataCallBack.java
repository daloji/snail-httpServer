/*******************************************************************************
* $Id: IDataCallBack.java 8367 2018-07-25 17:01:34Z kbettenc $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.str;

import com.bytel.ravel.common.exception.RavelException;

/**
 *
 * @author lmerces
 * @version ($Revision: 8367 $ $Date: 2018-07-25 19:01:34 +0200 (mer. 25 juil. 2018) $)
 */
public interface IDataCallBack
{

  /**
   *
   * @author lmerces
   * @version ($Revision: 8367 $ $Date: 2018-07-25 19:01:34 +0200 (mer. 25 juil. 2018) $)
   */
  public enum DataCallBackReturn
  {
    /**
     * the data processing should continue
     */
    CONTINUE,
    /**
     * the data processing should stop
     */
    STOP
  }

  /**
   * @param data_p
   *          data
   * @return {@link DataCallBackReturn}
   * @throws RavelException
   *           exception
   */
  public DataCallBackReturn processData(Object data_p) throws RavelException;
}
