/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.str.structs;

import java.io.Serializable;
import java.util.Objects;

/**
 * @author hgoncalv
 * @version ($Revision$ $Date$)
 */
public class MigrerStaStwVersVstwResponse implements Serializable
{
  private static final long serialVersionUID = 6267685293295075361L;

  /**
   *
   */
  private String _idPfi;

  /**
   *
   */
  private String _eoickStw;

  /**
   *
   */
  private String _eoickVstw;

  /**
   * @return value of _idPfi.
   */
  public String getIdPfi()
  {
    return _idPfi;
  }

  /**
   * @param idPfi_p
   *          the _idPfi to set.
   */
  public void setIdPfi(String idPfi_p)
  {
    _idPfi = idPfi_p;
  }

  /**
   * @return value of _eoickStw.
   */
  public String getEoickStw()
  {
    return _eoickStw;
  }

  /**
   * @param eoickStw_p
   *          the _eoickStw to set.
   */
  public void setEoickStw(String eoickStw_p)
  {
    _eoickStw = eoickStw_p;
  }

  /**
   * @return value of _eoickVstw.
   */
  public String getEoickVstw()
  {
    return _eoickVstw;
  }

  /**
   * @param eoickVstw_p
   *          the _eoickVstw to set.
   */
  public void setEoickVstw(String eoickVstw_p)
  {
    _eoickVstw = eoickVstw_p;
  }

  @Override
  public boolean equals(Object o_p)
  {
    if (this == o_p)
    {
      return true;
    }
    if (o_p == null || getClass() != o_p.getClass())
    {
      return false;
    }
    MigrerStaStwVersVstwResponse that = (MigrerStaStwVersVstwResponse) o_p;
    return Objects.equals(_idPfi, that._idPfi) && Objects.equals(_eoickStw, that._eoickStw) && Objects.equals(_eoickVstw, that._eoickVstw);
  }

  @Override
  public int hashCode()
  {
    return Objects.hash(_idPfi, _eoickStw, _eoickVstw);
  }

  @Override
  public String toString()
  {
    return "MigrerStaStwVersVstwResponse [" + "_idPfi=" + _idPfi + ", _eoickStw=" + _eoickStw + ", _eoickVstw=" + _eoickVstw + "]";
  }
}
