/*******************************************************************************
* $Id: AuditUDCHEMSCMP.java 8367 2018-07-25 17:01:34Z kbettenc $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.str.structs;

/**
 *
 * @author lmerces
 * @version ($Revision: 8367 $ $Date: 2018-07-25 19:01:34 +0200 (mer. 25 juil. 2018) $)
 */
public class AuditUDCHEMSCMP
{
  /**
   * MSISDN
   */
  private String _msisdn;

  /**
   * EOICK
   */
  private Integer _eoick;

  /**
   * Constructor
   */
  public AuditUDCHEMSCMP()
  {
    super();
  }

  /**
   * Constructor
   *
   * @param msisdn_p
   *          MSISDN
   * @param eoick_p
   *          EOICK
   */
  public AuditUDCHEMSCMP(String msisdn_p, Integer eoick_p)
  {
    super();
    _msisdn = msisdn_p;
    _eoick = eoick_p;
  }

  /**
   * @return the eoick
   */
  public Integer getEoick()
  {
    return _eoick;
  }

  /**
   * @return the msisdn
   */
  public String getMsisdn()
  {
    return _msisdn;
  }

  /**
   * @param eoick_p
   *          the eoick to set
   */
  public void setEoick(Integer eoick_p)
  {
    _eoick = eoick_p;
  }

  /**
   * @param msisdn_p
   *          the msisdn to set
   */
  public void setMsisdn(String msisdn_p)
  {
    _msisdn = msisdn_p;
  }
}
