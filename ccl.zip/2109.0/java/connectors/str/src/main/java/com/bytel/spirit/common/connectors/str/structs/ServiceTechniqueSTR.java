/*******************************************************************************
* $Id: ServiceTechniqueSTR.java 8367 2018-07-25 17:01:34Z kbettenc $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.str.structs;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author lmerces
 * @version ($Revision: 8367 $ $Date: 2018-07-25 19:01:34 +0200 (mer. 25 juil. 2018) $)
 */
public class ServiceTechniqueSTR
{
  /**
   * Nom de la colonne PK_SRV_TECH
   */
  private static final String COLUMN_PK_SRV_TECH = "PK_SRV_TECH"; //$NON-NLS-1$

  /**
   * Nom de la colonne NOM_SRV_TECH
   */
  private static final String COLUMN_NOM_SRV_TECH = "NOM_SRV_TECH"; //$NON-NLS-1$

  /**
   * Nom de la colonne IND_PRM_SUPPL
   */
  private static final String COLUMN_IND_PRM_SUPPL = "IND_PRM_SUPPL"; //$NON-NLS-1$

  /**
   * Nom de la colonne SUSPENDU
   */
  private static final String COLUMN_SUSPENDU = "SUSPENDU"; //$NON-NLS-1$

  /**
   * Identifiant du Service Technique
   */
  private long _idSrvTech;

  /**
   * Nom du Service Technique
   */
  private String _nomSrvTech;

  /**
   * Indicateur de la présence de Paramètres Supplémentaire
   */
  private boolean _indParamSuppl;

  /**
   * Indicateur de Suspension du Client
   */
  private boolean _suspendu;

  /**
   * Liste des Paramètres du Service Technique
   */
  private List<ParamSrvTech> _listParam = new ArrayList<ParamSrvTech>();

  /**
   * Constructor
   */
  public ServiceTechniqueSTR()
  {
    super();
  }

  /**
   * Constructor
   *
   * @param idSrvTech_p
   *          Identifiant du Service Technique
   * @param nomSrvTech_p
   *          Nom du Service Technique
   * @param indParamSuppl_p
   *          Indicateur de la présence de Paramètres Supplémentaire
   * @param suspendu_p
   *          Indicateur de Suspension du Client
   * @param listParam_p
   *          Liste des Paramètres du Service Technique
   */
  public ServiceTechniqueSTR(long idSrvTech_p, String nomSrvTech_p, boolean indParamSuppl_p, boolean suspendu_p, List<ParamSrvTech> listParam_p)
  {
    super();
    _idSrvTech = idSrvTech_p;
    _nomSrvTech = nomSrvTech_p;
    _indParamSuppl = indParamSuppl_p;
    _suspendu = suspendu_p;
    _listParam = listParam_p == null ? null : new ArrayList<>(listParam_p);
  }

  /**
   * Constructeur
   *
   * @param rs
   *          The ResultSet to get the value of ServiceTechniqueSTR from
   * @throws SQLException
   *           on error
   */
  public ServiceTechniqueSTR(ResultSet rs) throws SQLException
  {
    this._idSrvTech = rs.getLong(COLUMN_PK_SRV_TECH);
    this._nomSrvTech = rs.getString(COLUMN_NOM_SRV_TECH);
    this._indParamSuppl = rs.getBoolean(COLUMN_IND_PRM_SUPPL);
    this._suspendu = rs.getBoolean(COLUMN_SUSPENDU);

    for (int i = 1; i <= 6; i++)
    {
      this._listParam.add(new ParamSrvTech(rs.getString(ParamSrvTech.COLUMN_NOM_PRM + i), rs.getString(ParamSrvTech.COLUMN_VAL_PRM + i)));
    }
  }

  /**
   * @return the idSrvTech
   */
  public long getIdSrvTech()
  {
    return _idSrvTech;
  }

  /**
   * @return the listParam
   */
  public List<ParamSrvTech> getListParam()
  {
    return _listParam == null ? null : new ArrayList<>(_listParam);
  }

  /**
   * @return the nomSrvTech
   */
  public String getNomSrvTech()
  {
    return _nomSrvTech;
  }

  /**
   * @return the indParamSuppl
   */
  public boolean hasParamSuppl()
  {
    return _indParamSuppl;
  }

  /**
   * @return the suspendu
   */
  public boolean isSuspendu()
  {
    return _suspendu;
  }

  /**
   * @param idSrvTech_p
   *          the idSrvTech to set
   */
  public void setIdSrvTech(long idSrvTech_p)
  {
    _idSrvTech = idSrvTech_p;
  }

  /**
   * @param indParamSuppl_p
   *          the indParamSuppl to set
   */
  public void setIndParamSuppl(boolean indParamSuppl_p)
  {
    _indParamSuppl = indParamSuppl_p;
  }

  /**
   * @param listParam_p
   *          the listParam to set
   */
  public void setListParam(List<ParamSrvTech> listParam_p)
  {
    _listParam = listParam_p == null ? null : new ArrayList<>(listParam_p);
  }

  /**
   * @param nomSrvTech_p
   *          the nomSrvTech to set
   */
  public void setNomSrvTech(String nomSrvTech_p)
  {
    _nomSrvTech = nomSrvTech_p;
  }

  /**
   * @param suspendu_p
   *          the suspendu to set
   */
  public void setSuspendu(boolean suspendu_p)
  {
    _suspendu = suspendu_p;
  }
}
