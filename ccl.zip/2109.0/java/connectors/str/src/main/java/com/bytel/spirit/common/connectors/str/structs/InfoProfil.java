/*******************************************************************************
* $Id: InfoProfil.java 10641 2018-09-24 10:37:06Z jalmeida $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.str.structs;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author jalmeida
 * @version ($Revision: 10641 $ $Date: 2018-09-24 12:37:06 +0200 (lun. 24 sept. 2018) $)
 */
public class InfoProfil
{
  /**
   *
   */
  private String _ligneMarche;

  /**
   *
   */
  private String _nomProfil;

  /**
   *
   */
  private int _nombre;

  /**
   * Constructor
   */
  public InfoProfil()
  {
    //Empty constructor
  }

  /**
   * Constructor with ResultSet
   *
   * @param resultSet
   *          The ResultSet
   * @throws SQLException
   *           Throws Exception
   */
  public InfoProfil(ResultSet resultSet) throws SQLException
  {
    _ligneMarche = resultSet.getString(1);
    _nomProfil = resultSet.getString(2);
    _nombre = resultSet.getInt(3);
  }

  /**
   * Constructor with parameters
   *
   * @param ligneMarche
   *          ligne de Marche
   * @param nomProfil
   *          nom du Profil
   * @param nombre
   *          nombre
   */
  public InfoProfil(String ligneMarche, String nomProfil, int nombre)
  {
    _ligneMarche = ligneMarche;
    _nomProfil = nomProfil;
    _nombre = nombre;
  }

  /**
   * @return the ligneMarche
   */
  public String getLigneMarche()
  {
    return _ligneMarche;
  }

  /**
   * @return the nombre
   */
  public int getNombre()
  {
    return _nombre;
  }

  /**
   * @return the nomProfil
   */
  public String getNomProfil()
  {
    return _nomProfil;
  }

  /**
   * @param ligneMarche_p
   *          the ligneMarche to set
   */
  public void setLigneMarche(String ligneMarche_p)
  {
    _ligneMarche = ligneMarche_p;
  }

  /**
   * @param nombre_p
   *          the nombre to set
   */
  public void setNombre(int nombre_p)
  {
    _nombre = nombre_p;
  }

  /**
   * @param nomProfil_p
   *          the nomProfil to set
   */
  public void setNomProfil(String nomProfil_p)
  {
    _nomProfil = nomProfil_p;
  }
}
