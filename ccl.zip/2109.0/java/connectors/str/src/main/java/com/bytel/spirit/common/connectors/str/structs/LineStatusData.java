/*******************************************************************************
* $Id: LineStatusData.java 8367 2018-07-25 17:01:34Z kbettenc $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.str.structs;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author fcabral
 * @version ($Revision: 8367 $ $Date: 2018-07-25 19:01:34 +0200 (mer. 25 juil. 2018) $)
 */
public class LineStatusData
{
  /**
   * Field LineStatus name
   */
  public static final String FIELD_LINESTATUS = "LINESTATUS"; //$NON-NLS-1$
  /**
   * Field Alias name
   */
  public static final String FIELD_ALIAS = "ALIAS"; //$NON-NLS-1$

  /**
   * Field to store LineStatus
   */
  private String _lineStatus;
  /**
   * Field to store Alias
   */
  private String _alias;

  /**
   * @param rs
   *          The ResultSet to get the value of LineStatus and Alias from
   * @throws SQLException
   *           on error
   */
  public LineStatusData(ResultSet rs) throws SQLException
  {
    _lineStatus = rs.getString(FIELD_LINESTATUS);
    _alias = rs.getString(FIELD_ALIAS);
  }

  /**
   * @param lineStatus_p
   *          the LineStatus value
   * @param alias_p
   *          the Alias value
   */
  public LineStatusData(String lineStatus_p, String alias_p)
  {
    _lineStatus = lineStatus_p;
    _alias = alias_p;
  }

  /**
   * @return the alias
   */
  public String getAlias()
  {
    return _alias;
  }

  /**
   * @return the lineStatus
   */
  public String getLineStatus()
  {
    return _lineStatus;
  }

  /**
   * @param alias_p
   *          the alias to set
   */
  public void setAlias(String alias_p)
  {
    _alias = alias_p;
  }

  /**
   * @param lineStatus_p
   *          the lineStatus to set
   */
  public void setLineStatus(String lineStatus_p)
  {
    _lineStatus = lineStatus_p;
  }

}
