/*******************************************************************************
* $Id: LigneMarcheData.java 8367 2018-07-25 17:01:34Z kbettenc $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.str.structs;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author lmerces
 * @version ($Revision: 8367 $ $Date: 2018-07-25 19:01:34 +0200 (mer. 25 juil. 2018) $)
 */
public class LigneMarcheData
{
  /**
   * Field LIGNE_MARCHE name
   */
  public static final String FIELD_LIGNE_MARCHE = "LIGNE_MARCHE"; //$NON-NLS-1$

  /**
   * Field LIGNE_MARCHE name
   */
  public static final String FIELD_IMSI = "IMSI"; //$NON-NLS-1$

  /**
   * ligneMarche
   */
  private String _ligneMarche = null;

  /**
   * imsi
   */
  private String _imsi = null;

  /**
   * @param rs
   *          The ResultSet to get the value of LigneMarche from
   * @throws SQLException
   *           on error
   */
  public LigneMarcheData(ResultSet rs) throws SQLException
  {
    _ligneMarche = rs.getString(FIELD_LIGNE_MARCHE);
    _imsi = rs.getString(FIELD_IMSI);
  }

  /**
   * @param lineMarche_p
   *          the LineMarche value
   * @param imsi_p
   *          the imsi value
   */
  public LigneMarcheData(String lineMarche_p, String imsi_p)
  {
    _ligneMarche = lineMarche_p;
    _imsi = imsi_p;
  }

  /**
   * @return the imsi
   */
  public String getImsi()
  {
    return _imsi;
  }

  /**
   * @return the ligneMarche
   */
  public String getLigneMarche()
  {
    return _ligneMarche;
  }

  /**
   * @param imsi_p
   *          the imsi to set
   */
  public void setImsi(String imsi_p)
  {
    _imsi = imsi_p;
  }

  /**
   * @param ligneMarche_p
   *          the ligneMarche to set
   */
  public void setLigneMarche(String ligneMarche_p)
  {
    _ligneMarche = ligneMarche_p;
  }
}
