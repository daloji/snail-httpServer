/*******************************************************************************
* $Id: ParamSrvTech.java 8367 2018-07-25 17:01:34Z kbettenc $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.str.structs;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author lmerces
 * @version ($Revision: 8367 $ $Date: 2018-07-25 19:01:34 +0200 (mer. 25 juil. 2018) $)
 */
public class ParamSrvTech
{
  /**
   * Nom de la colonne NOM_PRM
   */
  protected static final String COLUMN_NOM_PRM = "NOM_PRM"; //$NON-NLS-1$

  /**
   * Nom de la colonne VAL_PRM
   */
  protected static final String COLUMN_VAL_PRM = "VAL_PRM"; //$NON-NLS-1$

  /**
   * Nom du Paramètre
   */
  private String _nom;

  /**
   * Valeur du Paramètre
   */
  private String _valeur;

  /**
   * Constructeur
   *
   * @param rs
   *          The ResultSet to get the value of ParamSrvTech from
   * @throws SQLException
   *           on error
   */
  public ParamSrvTech(ResultSet rs) throws SQLException
  {
    this._nom = rs.getString(COLUMN_NOM_PRM);
    this._valeur = rs.getString(COLUMN_VAL_PRM);
  }

  /**
   * Constructeur
   *
   * @param nom_p
   *          Nom du Paramètre
   * @param valeur_p
   *          Valeur du Paramètre
   */
  public ParamSrvTech(final String nom_p, final String valeur_p)
  {
    this._nom = nom_p;
    this._valeur = valeur_p;
  }

  /**
   * @return the nom
   */
  public String getNom()
  {
    return _nom;
  }

  /**
   * @return the valeur
   */
  public String getValeur()
  {
    return _valeur;
  }

  /**
   * @param nom_p
   *          the nom to set
   */
  public void setNom(String nom_p)
  {
    _nom = nom_p;
  }

  /**
   * @param valeur_p
   *          the valeur to set
   */
  public void setValeur(String valeur_p)
  {
    _valeur = valeur_p;
  }
}
