/*******************************************************************************
* $Id: ISTR.java 51044 2021-04-23 08:25:04Z fbarnabe $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.str;

import java.util.List;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.connectors.str.structs.AuditUDCHEMSCMP;
import com.bytel.spirit.common.connectors.str.structs.AuditUDCHEMSPDP;
import com.bytel.spirit.common.connectors.str.structs.AuditUDCHEMSSDP;
import com.bytel.spirit.common.connectors.str.structs.DonneesClient;
import com.bytel.spirit.common.connectors.str.structs.InfoProfil;
import com.bytel.spirit.common.connectors.str.structs.LigneMarcheData;
import com.bytel.spirit.common.connectors.str.structs.LineStatusData;
import com.bytel.spirit.common.connectors.str.structs.MigrerStaStwVersVstwResponse;
import com.bytel.spirit.common.connectors.str.structs.ParamSrvTech;
import com.bytel.spirit.common.connectors.str.structs.Parpntacc;
import com.bytel.spirit.common.connectors.str.structs.ResultContratEtPartition;
import com.bytel.spirit.common.connectors.str.structs.ServiceTechniqueSTR;
import com.bytel.spirit.common.connectors.str.structs.TSMData;
import com.bytel.spirit.common.shared.functional.types.functional.mediaBox.StMediaBox;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

/**
 * The Interface ISTR for STR DB operations.
 *
 * @author $Author: fcabral $
 * @version ($Revision: 51044 $ $Date: 2021-04-23 10:25:04 +0200 (ven. 23 avril 2021) $)
 */
public interface ISTR
{
  /**
   * Invocation of the stored procedure « <b>P_016_AUDIT_HEMSCMP</b> »
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param dataCallBack_p
   *          data callback
   * @return response from the stored procedure
   * @throws RavelException
   *           exception thrown
   */
  ConnectorResponse<Integer, Retour> auditHEMSCMP(Tracabilite tracabilite_p, IDataCallBack dataCallBack_p) throws RavelException;

  /**
   * Invocation of the stored procedure « <b>P_017_AUDIT_HEMSPDP</b> »
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param dataCallBack_p
   *          data callback
   * @return response from the stored procedure
   * @throws RavelException
   *           exception thrown
   */
  ConnectorResponse<Integer, Retour> auditHEMSPDP(Tracabilite tracabilite_p, IDataCallBack dataCallBack_p) throws RavelException;

  /**
   * Invocation of the stored procedure « <b>P_012_AUDIT_HEMSSDP</b> »
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param dataCallBack_p
   *          data callback
   * @return response from the stored procedure
   * @throws RavelException
   *           exception thrown
   */
  ConnectorResponse<Integer, Retour> auditHEMSSDP(Tracabilite tracabilite_p, IDataCallBack dataCallBack_p) throws RavelException;

  /**
   * Invocation of the stored procedure « <b>P_013_CHECK_PARAPNTACCC_FromVP</b> »
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param imsi_p
   *          IMSI
   * @return response from the stored procedure
   * @throws RavelException
   *           exception thrown
   */
  ConnectorResponse<Boolean, Retour> checkPARPNTACCFromVP(Tracabilite tracabilite_p, String imsi_p) throws RavelException;

  /**
   * Invocation of the stored procedure P_003_CONSULT_LIGNE_MARCHE
   *
   * @param tracabilite_p
   *          Ravel Message Id
   * @param imsi_p
   *          The IMSI, not null if we want to search by IMSI else null
   * @param msisdn_p
   *          The MSISDN, not null if we want to search by MSISDN else null
   *
   * @return response from the stored procedure
   * @throws RavelException
   *           on error
   */
  ConnectorResponse<List<LigneMarcheData>, Retour> consultLigneDeMarche(Tracabilite tracabilite_p, String imsi_p, String msisdn_p) throws RavelException;

  /**
   * Invocation of the stored procedure P_002_CONSULT_LINE_STATUS
   *
   * @param tracabilite_p
   *          Ravel Message Id
   * @param imsi_p
   *          The IMSI, not null if we want to search by IMSI else null
   * @param msisdn_p
   *          The MSISDN, not null if we want to search by MSISDN else null
   *
   * @return response from the stored procedure
   * @throws RavelException
   *           on error
   */
  ConnectorResponse<List<LineStatusData>, Retour> consultLineStatus(Tracabilite tracabilite_p, String imsi_p, String msisdn_p) throws RavelException;

  /**
   * Invocation of the stored procedure « <b>P_006_GET_CUSTOMER_IDENTITY</b> »
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param msisdn_p
   *          MSISDN
   * @param imsi_p
   *          IMSI
   * @return response from the stored procedure
   * @throws RavelException
   *           exception thrown
   */
  ConnectorResponse<DonneesClient, Retour> getCustomerIdentity(Tracabilite tracabilite_p, String msisdn_p, String imsi_p) throws RavelException;

  /**
   * Invocation of the stored procedure « <b>P_GET_MSISDN_BDUO_FROM_PFI</b> »
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param pfi_p
   *          the PFI parameter
   * @return response from the stored procedure
   * @throws RavelException
   *           exception thrown
   */
  ConnectorResponse<String, Retour> getMSISDNBDUOFromPFI(Tracabilite tracabilite_p, String pfi_p) throws RavelException;

  /**
   * Invocation of the stored procedure « <b>P_GET_MSISDN_FROM_PFI</b> »
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param pfi_p
   *          the PFI parameter
   * @return response from the stored procedure
   * @throws RavelException
   *           exception thrown
   */
  ConnectorResponse<String, Retour> getMSISDNFromPFI(Tracabilite tracabilite_p, String pfi_p) throws RavelException;

  /**
   * Invocation of the stored procedure « <b>P_005_GET_PARSVCTECACC</b> »
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param idSrvTech_p
   *          the Tech Service Id parameter
   * @return response from the stored procedure
   * @throws RavelException
   *           exception thrown
   */
  ConnectorResponse<List<ParamSrvTech>, Retour> getPARSVCTECACC(Tracabilite tracabilite_p, long idSrvTech_p) throws RavelException;

  /**
   * Invocation of the stored procedure « <b>P_GET_PFI_FROM_IMSI</b> »
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param imsi_p
   *          the IMSI parameter
   * @return response from the stored procedure
   * @throws RavelException
   *           exception thrown
   */
  ConnectorResponse<String, Retour> getPFIFromIMSI(Tracabilite tracabilite_p, String imsi_p) throws RavelException;

  /**
   *
   * Invocation of a stored procedure « <b>P_GET_PARPNTACC_BY_PFI</b> »
   *
   * @param tracabilite_p
   *          Ravel Message Id
   * @param pfi_p
   *          The pfi parameter
   * @return response from a stored procedure
   * @throws RavelException
   *           exception thrown
   */
  ConnectorResponse<List<Parpntacc>, Retour> getParpntaccByPfi(Tracabilite tracabilite_p, String pfi_p) throws RavelException;

  /**
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param msisdn_p
   *          the MSISDN parameter
   * @return response from the stored procedure
   * @throws RavelException
   *           exception thrown
   */
  ConnectorResponse<String, Retour> getPfiFromMsisdn(Tracabilite tracabilite_p, String msisdn_p) throws RavelException;

  /**
   * Invocation of the stored procedure « <b>PR_EXT_PROFILS_PIRELLI</b> »
   *
   * @param tracabilite_p
   *          Tracabilite
   * @return response from the stored procedure
   * @throws RavelException
   *           exception thrown
   */
  ConnectorResponse<List<InfoProfil>, Retour> getProfilsPirelliParLM(Tracabilite tracabilite_p) throws RavelException;

  /**
   * Invocation of the stored procedure « <b>PR_EXT_PROFILS_THEPOLICE</b> »
   *
   * @param tracabilite_p
   *          Tracabilite
   * @return response from the stored procedure
   * @throws RavelException
   *           exception thrown
   */
  ConnectorResponse<List<InfoProfil>, Retour> getProfilsThePoliceParLM(Tracabilite tracabilite_p) throws RavelException;

  /**
   * Invocation of the stored procedure « <b>P_015_GET_STR_HEMSCMP</b> »
   *
   * @param tracabilite_p
   *          Tracabilite
   * @return response from the stored procedure
   * @throws RavelException
   *           exception thrown
   */
  ConnectorResponse<Boolean, Retour> getSTRHEMSCMP(Tracabilite tracabilite_p) throws RavelException;

  /**
   * Invocation of the stored procedure « <b>P_014_GET_STR_HEMSPDP</b> »
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param imsi_p
   *          IMSI
   * @return response from the stored procedure
   * @throws RavelException
   *           exception thrown
   */
  ConnectorResponse<Boolean, Retour> getSTRHEMSPDP(Tracabilite tracabilite_p, String imsi_p) throws RavelException;

  /**
   * Invocation of the stored procedure « <b>P_011_GET_STR_HEMSSDP</b> »
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param imsi_p
   *          IMSI
   * @return response from the stored procedure
   * @throws RavelException
   *           exception thrown
   */
  ConnectorResponse<Boolean, Retour> getSTRHEMSSDP(Tracabilite tracabilite_p, String imsi_p) throws RavelException;

  /**
   * Invocation of the stored procedure « <b>P_004_GET_SVCTECACC_FROM_PFI</b> »
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param pfi_p
   *          the PFI parameter
   * @return response from the stored procedure
   * @throws RavelException
   *           exception thrown
   */
  ConnectorResponse<List<ServiceTechniqueSTR>, Retour> getSVCTECACCFromPFI(Tracabilite tracabilite_p, String pfi_p) throws RavelException;

  /**
   *
   * Invocation of a stored procedure to get the TSMDATA by the IMSI
   *
   * @param tracabilite_p
   *          Ravel Message Id
   * @param imsi_p
   *          The IMSI parameter
   * @return response from a stored procedure
   * @throws RavelException
   *           exception thrown
   */
  ConnectorResponse<List<TSMData>, Retour> getTSMDataByIMSI(Tracabilite tracabilite_p, String imsi_p) throws RavelException;

  /**
   *
   * Invocation of a stored procedure to get the TSMDATA by the MSISDN
   *
   * @param tracabilite_p
   *          Ravel Message Id
   * @param msisdn_p
   *          The MSISDN parameter
   * @return response from a stored procedure
   * @throws RavelException
   *           exception thrown
   */
  ConnectorResponse<List<TSMData>, Retour> getTSMDataByMSISDN(Tracabilite tracabilite_p, String msisdn_p) throws RavelException;

  /**
   * Invocation of the stored procedure « <b>P_009_INSERT_UDC_HEMSCMP</b> »
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param listAuditUDCHEMSCMP_p
   *          Liste de données à insérer
   * @param batchSize_p
   *          batch size
   * @return response from the stored procedure
   * @throws RavelException
   *           exception thrown
   */
  ConnectorResponse<Boolean, Retour> insertUDCHEMSCMP(Tracabilite tracabilite_p, List<AuditUDCHEMSCMP> listAuditUDCHEMSCMP_p, int batchSize_p) throws RavelException;

  /**
   * Invocation of the stored procedure « <b>P_008_INSERT_UDC_HEMSPDP</b> »
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param listAuditUDCHEMSPDP_p
   *          Liste de données à insérer
   * @param batchSize_p
   *          batch size
   * @return response from the stored procedure
   * @throws RavelException
   *           exception thrown
   */
  ConnectorResponse<Boolean, Retour> insertUDCHEMSPDP(Tracabilite tracabilite_p, List<AuditUDCHEMSPDP> listAuditUDCHEMSPDP_p, int batchSize_p) throws RavelException;

  /**
   * Invocation of the stored procedure « <b>P_007_INSERT_UDC_HEMSSDP</b> »
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param listAuditUDCHEMSSDP_p
   *          Liste de données à insérer
   * @param batchSize_p
   *          batch size
   * @return response from the stored procedure
   * @throws RavelException
   *           exception thrown
   */
  ConnectorResponse<Boolean, Retour> insertUDCHEMSSDP(Tracabilite tracabilite_p, List<AuditUDCHEMSSDP> listAuditUDCHEMSSDP_p, int batchSize_p) throws RavelException;

  /**
   *
   * Invocation of a stored procedure to get the numéro de contrat of portefeuille de service from an msisdn
   *
   * @param tracabilite_p
   *          Ravel Message Id
   * @param noTelephone_p
   *          The noTelephone parameter
   * @return response from a stored procedure
   * @throws RavelException
   *           exception thrown
   */
  ConnectorResponse<ResultContratEtPartition, Retour> recupererNoContratParNoTelephone(Tracabilite tracabilite_p, String noTelephone_p) throws RavelException;

  /**
   * Ce connecteur permet de determiner si une boite de messagerie de type VMS est provisionnée vu du référentiel STR de
   * NPBT (référentiel des services techniques) et dans le cas ou une boite est trouvée, sur quel type de VMS elle est vue
   * provisionnée.
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param noTelephone_p
   *          NoTelephone
   * @return response from a stored procedure
   * @throws RavelException
   *           On error
   */
  ConnectorResponse<String, Retour> recupererTypeVms(Tracabilite tracabilite_p, String noTelephone_p) throws RavelException;

  /**
   * Truncates a table audit UDC
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param commande_p
   *          commande
   * @return response from the execution
   * @throws RavelException
   *           exception thrown
   */
  ConnectorResponse<Boolean, Retour> truncateTableAuditUDC(Tracabilite tracabilite_p, String commande_p) throws RavelException;

  /**
   *
   * Invocation of a stored procedure to get the pfi of the an IDTPFS
   *
   * @param tracabilite_p
   *          Ravel Message Id
   * @param pfi_p
   *          The pfi parameter
   * @return response from a stored procedure
   * @throws RavelException
   *           exception thrown
   */
  ConnectorResponse<String, Retour> upccGetIDTPFSFromPFI(Tracabilite tracabilite_p, String pfi_p) throws RavelException;

  /**
   *
   * Invocation of a stored procedure to get the pfi of the an imsi
   *
   * @param tracabilite_p
   *          Ravel Message Id
   * @param pfi_p
   *          The pfi parameter
   * @return response from a stored procedure
   * @throws RavelException
   *           exception thrown
   */
  ConnectorResponse<String, Retour> upccGetIMSIFromPFI(Tracabilite tracabilite_p, String pfi_p) throws RavelException;

  /**
   *
   * Invocation of a stored procedure to get the pfi of the an msisdn
   *
   * @param tracabilite_p
   *          Ravel Message Id
   * @param msisdn_p
   *          The msisdn parameter
   * @return response from a stored procedure
   * @throws RavelException
   *           exception thrown
   */
  ConnectorResponse<String, Retour> upccGetPFIFromMSISDN(Tracabilite tracabilite_p, String msisdn_p) throws RavelException;

  /**
   *
   * Ce connecteur permet de créer une entrée dans le référentiel STR pour une boite messagerie migrée de la PFS STW vers
   * la PFS VSTW
   *
   * @param tracabilite_p
   *          Ravel Message Id
   * @param stmediaBox_p
   *          The StMediaBox parameter
   * @return response from a stored procedure
   * @throws RavelException
   *           exception thrown
   */
  ConnectorResponse<MigrerStaStwVersVstwResponse, Retour> migrerStaStwVersVstw(Tracabilite tracabilite_p, StMediaBox stmediaBox_p) throws RavelException;

  /**
   *
   * Ce connecteur permet d'inhiber dans le référentiel STR tous les services techniques associés à la messagerie STW d'un
   * abonné mobile identifié par son numéro * téléphone (MSISDN). Les services concernés sont tous ceux dont le nom
   * commence par 'ST_VMS'.
   *
   * @param tracabilite_p
   *          Ravel Message Id
   * @param noTelephone_p
   *          The sNoTelephone parameter
   * @param idtDerMod_p
   *          The sIdtDerMod parameter
   * @return response from a stored procedure
   * @throws RavelException
   *           exception thrown
   */
  ConnectorResponse<Nothing, Retour> inhiberStaStw(Tracabilite tracabilite_p, String noTelephone_p, String idtDerMod_p) throws RavelException;

  /**
   *
   * Ce connecteur permet d'annuler pour un abonné mobile identifié par son numéro téléphone (MSISDN) la migration des
   * services techniques associés à la messagerie STW vers celui de la messagerie VSTW. L'annulation consiste à supprimer
   * le service technique ST_VMS_MEDIABOX créé lors de la migration pour VSTW et à désinhiber tous les services techniques
   * associés à la messagerie STW. Les services inhibés concernés sont tous ceux dont le nom commence par 'ST_VMS'.
   *
   * @param tracabilite_p
   *          Ravel Message Id
   * @param noTelephone_p
   *          The sNoTelephone parameter
   * @param idtDerMod_p
   *          The sIdtDerMod parameter
   * @return response from a stored procedure
   * @throws RavelException
   *           exception thrown
   */
  ConnectorResponse<String, Retour> annulerMigrerStaStwVersVstw(Tracabilite tracabilite_p, String noTelephone_p, String idtDerMod_p) throws RavelException;
}
