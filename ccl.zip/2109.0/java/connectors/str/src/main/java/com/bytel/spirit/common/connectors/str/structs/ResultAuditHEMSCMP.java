/*******************************************************************************
* $Id: ResultAuditHEMSCMP.java 8367 2018-07-25 17:01:34Z kbettenc $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.str.structs;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

/**
 *
 * @author lmerces
 * @version ($Revision: 8367 $ $Date: 2018-07-25 19:01:34 +0200 (mer. 25 juil. 2018) $)
 */
public class ResultAuditHEMSCMP
{
  /**
   * Field PK_RESULT_HEMSSDP name
   */
  public static final String FIELD_ID = "PK_RESULT_HEMSCMP"; //$NON-NLS-1$

  /**
   * Field DATEEVENT name
   */
  public static final String FIELD_DATE_EVENT = "DATEEVENT"; //$NON-NLS-1$

  /**
   * Field MSISDN_UDC name
   */
  public static final String FIELD_MSISDN_UDC = "MSISDN_UDC"; //$NON-NLS-1$

  /**
   * Field MSISDN_NPBT name
   */
  public static final String FIELD_MSISDN_NPBT = "MSISDN_NPBT"; //$NON-NLS-1$

  /**
   * Field EOICK_UDC name
   */
  public static final String FIELD_EOICK_UDC = "EOICK_UDC"; //$NON-NLS-1$

  /**
   * Field EOICK_NPBT name
   */
  public static final String FIELD_EOICK_NPBT = "EOICK_NPBT"; //$NON-NLS-1$

  /**
   * Field MESSAGE name
   */
  public static final String FIELD_MESSAGE = "MESSAGE"; //$NON-NLS-1$

  /**
   * ID
   */
  private Long _id;

  /**
   * Date Event
   */
  private Date _dateEvent;

  /**
   * MSISDN UDC
   */
  private String _msisdnUDC;

  /**
   * MSISDN NPBT
   */
  private String _msisdnNPBT;

  /**
   * EOICK UDC
   */
  private String _eoickUDC;

  /**
   * EOICK NPBT
   */
  private String _eoickNPBT;

  /**
   * Message
   */
  private String _message;

  /**
   * Constructor
   */
  public ResultAuditHEMSCMP()
  {
    super();
  }

  /**
   * Constructor
   *
   * @param rs_p
   *          resultset
   * @throws SQLException
   *           exception
   */
  public ResultAuditHEMSCMP(ResultSet rs_p) throws SQLException
  {
    this._dateEvent = rs_p.getTimestamp(ResultAuditHEMSCMP.FIELD_DATE_EVENT);
    this._msisdnUDC = rs_p.getString(ResultAuditHEMSCMP.FIELD_MSISDN_UDC);
    this._msisdnNPBT = rs_p.getString(ResultAuditHEMSCMP.FIELD_MSISDN_NPBT);
    this._eoickUDC = rs_p.getString(ResultAuditHEMSCMP.FIELD_EOICK_UDC);
    this._eoickNPBT = rs_p.getString(ResultAuditHEMSCMP.FIELD_EOICK_NPBT);
    this._message = rs_p.getString(ResultAuditHEMSCMP.FIELD_MESSAGE);
  }

  /**
   * @return the dateEvent
   */
  public Date getDateEvent()
  {
    return _dateEvent == null ? null : new Date(_dateEvent.getTime());
  }

  /**
   * @return the eoickNPBT
   */
  public String getEoickNPBT()
  {
    return _eoickNPBT;
  }

  /**
   * @return the eoickUDC
   */
  public String getEoickUDC()
  {
    return _eoickUDC;
  }

  /**
   * @return the id
   */
  public Long getId()
  {
    return _id;
  }

  /**
   * @return the message
   */
  public String getMessage()
  {
    return _message;
  }

  /**
   * @return the msisdnNPBT
   */
  public String getMsisdnNPBT()
  {
    return _msisdnNPBT;
  }

  /**
   * @return the msisdnUDC
   */
  public String getMsisdnUDC()
  {
    return _msisdnUDC;
  }

  /**
   * @param dateEvent_p
   *          the dateEvent to set
   */
  public void setDateEvent(Date dateEvent_p)
  {
    _dateEvent = dateEvent_p == null ? null : new Date(dateEvent_p.getTime());
  }

  /**
   * @param eoickNPBT_p
   *          the eoickNPBT to set
   */
  public void setEoickNPBT(String eoickNPBT_p)
  {
    _eoickNPBT = eoickNPBT_p;
  }

  /**
   * @param eoickUDC_p
   *          the eoickUDC to set
   */
  public void setEoickUDC(String eoickUDC_p)
  {
    _eoickUDC = eoickUDC_p;
  }

  /**
   * @param id_p
   *          the id to set
   */
  public void setId(Long id_p)
  {
    _id = id_p;
  }

  /**
   * @param message_p
   *          the message to set
   */
  public void setMessage(String message_p)
  {
    _message = message_p;
  }

  /**
   * @param msisdnNPBT_p
   *          the msisdnNPBT to set
   */
  public void setMsisdnNPBT(String msisdnNPBT_p)
  {
    _msisdnNPBT = msisdnNPBT_p;
  }

  /**
   * @param msisdnUDC_p
   *          the msisdnUDC to set
   */
  public void setMsisdnUDC(String msisdnUDC_p)
  {
    _msisdnUDC = msisdnUDC_p;
  }
}
