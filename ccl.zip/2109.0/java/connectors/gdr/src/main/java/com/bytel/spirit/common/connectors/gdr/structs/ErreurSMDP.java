/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.gdr.structs;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;

import com.bytel.ravel.common.utils.DateTimeTools;

/**
 *
 * @author lmerces
 * @version ($Revision$ $Date$)
 */
public class ErreurSMDP
{
  /**
   * Identifiant de la requete
   */
  String _requestId;

  /**
   * Numero de serie de la carte
   */
  String _iccid;

  /**
   * Etat de la sim en erreur
   */
  String _etatErreur;

  /**
   * Date de l'erreur
   */
  LocalDateTime _dateErreur;

  /**
   * Identifiant de la derniere modification
   */
  String _idtDerMod;

  /**
   * Statut d'erreur de la requete
   */
  String _etatRequete;

  /**
   * Entite en erreur
   */
  String _entiteErreur;

  /**
   * Raison de l'erreur
   */
  String _raisonErreur;

  /**
   * Message d'erreur
   */
  String _libelleErreur;

  /**
   *
   */
  public ErreurSMDP()
  {
    super();
  }

  /**
   * @param rs_p
   *          result set
   * @throws SQLException
   *           SQLException
   */
  public ErreurSMDP(ResultSet rs_p) throws SQLException
  {
    super();
    _requestId = rs_p.getString("REQUEST_ID"); //$NON-NLS-1$
    _iccid = rs_p.getString("ICCID"); //$NON-NLS-1$
    _etatErreur = rs_p.getString("ETAT_ERREUR"); //$NON-NLS-1$
    _dateErreur = DateTimeTools.toLocalDateTime(rs_p.getTimestamp("DAT")); //$NON-NLS-1$
    _idtDerMod = rs_p.getString("IDTDERMOD"); //$NON-NLS-1$
    _etatRequete = rs_p.getString("ETAT_REQUETE"); //$NON-NLS-1$
    _entiteErreur = rs_p.getString("ENTITE_ERREUR"); //$NON-NLS-1$
    _raisonErreur = rs_p.getString("RAISON_ERREUR"); //$NON-NLS-1$
    _libelleErreur = rs_p.getString("LIBELLE_ERREUR"); //$NON-NLS-1$
  }

  /**
   * @param requestId_p
   * @param iccid_p
   * @param etatErreur_p
   * @param dateErreur_p
   * @param idtDerMod_p
   * @param etatRequete_p
   * @param entiteErreur_p
   * @param raisonErreur_p
   * @param libelleErreur_p
   */
  public ErreurSMDP(String requestId_p, String iccid_p, String etatErreur_p, LocalDateTime dateErreur_p, String idtDerMod_p, String etatRequete_p, String entiteErreur_p, String raisonErreur_p, String libelleErreur_p)
  {
    super();
    _requestId = requestId_p;
    _iccid = iccid_p;
    _etatErreur = etatErreur_p;
    _dateErreur = dateErreur_p;
    _idtDerMod = idtDerMod_p;
    _etatRequete = etatRequete_p;
    _entiteErreur = entiteErreur_p;
    _raisonErreur = raisonErreur_p;
    _libelleErreur = libelleErreur_p;
  }

  /**
   * @return the date
   */
  public LocalDateTime getDateErreur()
  {
    return _dateErreur;
  }

  /**
   * @return the entiteErreur
   */
  public String getEntiteErreur()
  {
    return _entiteErreur;
  }

  /**
   * @return the etatErreur
   */
  public String getEtatErreur()
  {
    return _etatErreur;
  }

  /**
   * @return the etatRequete
   */
  public String getEtatRequete()
  {
    return _etatRequete;
  }

  /**
   * @return the iccid
   */
  public String getIccid()
  {
    return _iccid;
  }

  /**
   * @return the idtDerMod
   */
  public String getIdtDerMod()
  {
    return _idtDerMod;
  }

  /**
   * @return the libelleErreur
   */
  public String getLibelleErreur()
  {
    return _libelleErreur;
  }

  /**
   * @return the raisonErreur
   */
  public String getRaisonErreur()
  {
    return _raisonErreur;
  }

  /**
   * @return the requestId
   */
  public String getRequestId()
  {
    return _requestId;
  }

  /**
   * @param date_p
   *          the date to set
   */
  public void setDate(LocalDateTime dateErreur_p)
  {
    _dateErreur = dateErreur_p;
  }

  /**
   * @param entiteErreur_p
   *          the entiteErreur to set
   */
  public void setEntiteErreur(String entiteErreur_p)
  {
    _entiteErreur = entiteErreur_p;
  }

  /**
   * @param etatErreur_p
   *          the etatErreur to set
   */
  public void setEtatErreur(String etatErreur_p)
  {
    _etatErreur = etatErreur_p;
  }

  /**
   * @param etatRequete_p
   *          the etatRequete to set
   */
  public void setEtatRequete(String etatRequete_p)
  {
    _etatRequete = etatRequete_p;
  }

  /**
   * @param iccid_p
   *          the iccid to set
   */
  public void setIccid(String iccid_p)
  {
    _iccid = iccid_p;
  }

  /**
   * @param idtDerMod_p
   *          the idtDerMod to set
   */
  public void setIdtDerMod(String idtDerMod_p)
  {
    _idtDerMod = idtDerMod_p;
  }

  /**
   * @param libelleErreur_p
   *          the libelleErreur to set
   */
  public void setLibelleErreur(String libelleErreur_p)
  {
    _libelleErreur = libelleErreur_p;
  }

  /**
   * @param raisonErreur_p
   *          the raisonErreur to set
   */
  public void setRaisonErreur(String raisonErreur_p)
  {
    _raisonErreur = raisonErreur_p;
  }

  /**
   * @param requestId_p
   *          the requestId to set
   */
  public void setRequestId(String requestId_p)
  {
    _requestId = requestId_p;
  }
}
