/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.gdr;

import java.time.LocalDateTime;
import java.util.List;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.probes.AvgDoubleCollectorItem;
import com.bytel.ravel.common.probes.AvgFlowPerSecondCollector;
import com.bytel.ravel.common.probes.RavelProbeConfigurationManager;
import com.bytel.ravel.services.connector.BaseDBProxy;
import com.bytel.ravel.services.connector.ConnectorExecution;
import com.bytel.ravel.services.connector.ConnectorManager;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.connectors.gdr.structs.BYTPRD;
import com.bytel.spirit.common.connectors.gdr.structs.CMDSIM;
import com.bytel.spirit.common.connectors.gdr.structs.CarteProfileData;
import com.bytel.spirit.common.connectors.gdr.structs.DURMSI;
import com.bytel.spirit.common.connectors.gdr.structs.ErreurSMDP;
import com.bytel.spirit.common.connectors.gdr.structs.HISETASIM;
import com.bytel.spirit.common.connectors.gdr.structs.ICallbackLireSim;
import com.bytel.spirit.common.connectors.gdr.structs.MSISDN;
import com.bytel.spirit.common.connectors.gdr.structs.PRF;
import com.bytel.spirit.common.connectors.gdr.structs.SUIVISMDP;
import com.bytel.spirit.common.connectors.gdr.structs.Sim;
import com.bytel.spirit.common.connectors.gdr.structs.StatistiqueEsim;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

/**
 *
 * @author $Author$
 * @version ($Revision$ $Date$)
 */
public class GDRProxy extends BaseDBProxy implements IGDR
{
  /**
   * Proxy instance.
   */
  private static final GDRProxy _instance = new GDRProxy();

  /**
   * Gets the single instance of GDRProxy.
   *
   * @return The proxy instance.
   */
  public static GDRProxy getInstance()
  {
    return GDRProxy._instance;
  }

  /**
   * Probe: measure the average execution time of the getProfilElectriqueParIdentifiant call per second.
   */
  protected AvgFlowPerSecondCollector _avg_getProfilElectriqueParIdentifiant_call_counter;

  /**
   * Probe: measure the average execution time of the getProfilElectriqueParIdentifiant operation.
   */
  protected AvgDoubleCollectorItem _avg_getProfilElectriqueParIdentifiant_ExecTime;

  /**
   * Probe: measure the average execution time of the getSimsNonPreProvisionnes call per second.
   */
  protected AvgFlowPerSecondCollector _avg_getSimsNonPreProvisionnes_call_counter;

  /**
   * Probe: measure the average execution time of the getSimsNonPreProvisionnes operation.
   */
  protected AvgDoubleCollectorItem _avg_getSimsNonPreProvisionnes_ExecTime;

  /**
   * Probe: measure the average execution time of the updateSimEtatMoc call per second.
   */
  protected AvgFlowPerSecondCollector _avg_updateSimEtatMoc_call_counter;

  /**
   * Probe: measure the average execution time of the updateSimEtatMoc operation.
   */
  protected AvgDoubleCollectorItem _avg_updateSimEtatMoc_ExecTime;

  /**
   * Probe: measure the average execution time of the psCheckEtatSimBatch call per second.
   */
  protected AvgFlowPerSecondCollector _avg_psCheckEtatSimBatch_call_counter;

  /**
   * Probe: measure the average execution time of the psCheckEtatSimBatch operation.
   */
  protected AvgDoubleCollectorItem _avg_psCheckEtatSimBatch_ExecTime;

  /**
   * Probe: measure the average execution time of the psConsultEtatBatch call per second.
   */
  protected AvgFlowPerSecondCollector _avg_psConsultEtatBatch_call_counter;

  /**
   * Probe: measure the average execution time of the psConsultEtatBatch operation.
   */
  protected AvgDoubleCollectorItem _avg_psConsultEtatBatch_ExecTime;

  /**
   * Probe: measure the average execution time of the psConsultSimBatch
   */
  protected AvgFlowPerSecondCollector _avg_psConsultSimBatch_call_counter;

  /**
   * Probe: measure the average execution time of the psConsultSimBatch
   */
  protected AvgDoubleCollectorItem _avg_psConsultSimBatch_ExecTime;

  /**
   * Probe: measure the average execution time of the psMajEtatBatch
   */
  protected AvgFlowPerSecondCollector _avg_psMajEtatBatch_call_counter;

  /**
   * Probe: measure the average execution time of the psMajEtatBatch
   */
  protected AvgDoubleCollectorItem _avg_psMajEtatBatch_ExecTime;

  /**
   * Probe: measure the average execution time of the psMettreAJourSIM
   */
  protected AvgFlowPerSecondCollector _avg_psMettreAJourSIM_call_counter;

  /**
   * Probe: measure the average execution time of the psMettreAJourSIM
   */
  protected AvgDoubleCollectorItem _avg_psMettreAJourSIM_ExecTime;

  /**
   * Probe: measure the average execution time of the psMiseADispositionSimBatch
   */
  protected AvgFlowPerSecondCollector _avg_psMiseADispositionSimBatch_call_counter;

  /**
   * Probe: measure the average execution time of the psMiseADispositionSimBatch
   */
  protected AvgDoubleCollectorItem _avg_psMiseADispositionSimBatch_ExecTime;

  /**
   * Probe: measure the average execution time of the psRechercheInformationsICCID call per second.
   */
  protected AvgFlowPerSecondCollector _avg_psRechercheInformationsICCID_call_counter;

  /**
   * Probe: measure the average execution time of the psRechercheInformationsICCID operation.
   */
  protected AvgDoubleCollectorItem _avg_psRechercheInformationsICCID_ExecTime;

  /**
   * Probe: measure the average execution time of the psRechercheInformationsIMSI call per second.
   */
  protected AvgFlowPerSecondCollector _avg_psRechercheInformationsIMSI_call_counter;

  /**
   * Probe: measure the average execution time of the psRechercheInformationsIMSI operation.
   */
  protected AvgDoubleCollectorItem _avg_psRechercheInformationsIMSI_ExecTime;

  /**
   * Probe: measure the average execution time of the ps001ConsultTYPEMSISDNFROMType call per second.
   */
  protected AvgFlowPerSecondCollector _avg_ps001ConsultTYPEMSISDNFROMType_call_counter;

  /**
   * Probe: measure the average execution time of the ps001ConsultTYPEMSISDNFROMType operation.
   */
  protected AvgDoubleCollectorItem _avg_ps001ConsultTYPEMSISDNFROMType_ExecTime;

  /**
   * Probe: measure the average execution time of the ps001ConsultTYPEMSISDNFROMType call per second.
   */
  protected AvgFlowPerSecondCollector _avg_ps002ReserveMSISDNFROMModeCritere_call_counter;

  /**
   * Probe: measure the average execution time of the ps001ConsultTYPEMSISDNFROMType operation.
   */
  protected AvgDoubleCollectorItem _avg_ps002ReserveMSISDNFROMModeCritere_ExecTime;

  /**
   * Probe: measure the average execution time of the ps003ResiliationMSISDN call per second.
   */
  protected AvgFlowPerSecondCollector _avg_ps003ResiliationMSISDN_call_counter;

  /**
   * Probe: measure the average execution time of the ps001ConsultTYPEMSISDNFROMType operation.
   */
  protected AvgDoubleCollectorItem _avg_ps003ResiliationMSISDN_ExecTime;

  /**
   * Probe: measure the average execution time of the ps004GetIMSIFromICCID call per second.
   */
  protected AvgFlowPerSecondCollector _avg_ps004GetIMSIFromICCID_call_counter;

  /**
   * Probe: measure the average execution time of the ps004GetIMSIFromICCID operation.
   */
  protected AvgDoubleCollectorItem _avg_ps004GetIMSIFromICCID_ExecTime;

  /**
   * Probe: measure the average execution time of the ps005ConsultCarteProfile call per second.
   */
  protected AvgFlowPerSecondCollector _avg_ps005ConsultCarteProfile_call_counter;

  /**
   * Probe: measure the average execution time of the ps005ConsultCarteProfile operation.
   */
  protected AvgDoubleCollectorItem _avg_ps005ConsultCarteProfile_ExectTime;

  /**
   * Probe: measure the average execution time of the ps006ConsultMSISDN call per second.
   */
  protected AvgFlowPerSecondCollector _avg_ps006ConsultMSISDN_call_counter;

  /**
   * Probe: measure the average execution time of the ps006ConsultMSISDN operation.
   */
  protected AvgDoubleCollectorItem _avg_ps006ConsultMSISDN_ExecTime;

  /**
   * Probe: measure the average execution time of the ps007ConsultDureeQuarantaine call per second.
   */
  protected AvgFlowPerSecondCollector _avg_ps007ConsultDureeQuarantaine_call_counter;

  /**
   * Probe: measure the average execution time of the ps007ConsultDureeQuarantaine operation.
   */
  protected AvgDoubleCollectorItem _avg_ps007ConsultDureeQuarantaine_ExecTime;

  /**
   * Probe: measure the average execution time of the ps008ConsultLatestHistoriqueEtatMSISDN call per second.
   */
  protected AvgFlowPerSecondCollector _avg_ps008ConsultLatestHistoriqueEtatMSISDN_call_counter;

  /**
   * Probe: measure the average execution time of the ps008ConsultLatestHistoriqueEtatMSISDN operation.
   */
  protected AvgDoubleCollectorItem _avg_ps008ConsultLatestHistoriqueEtatMSISDN_ExecTime;

  /**
   * Probe: measure the average execution time of the ps009GetICCIDFromIMSI call per second.
   */
  protected AvgFlowPerSecondCollector _avg_ps009GetICCIDFromIMSI_call_counter;

  /**
   * Probe: measure the average execution time of the ps009GetICCIDFromIMSI operation.
   */
  protected AvgDoubleCollectorItem _avg_ps009GetICCIDFromIMSI_ExecTime;

  /**
   * Probe: measure the average execution time of the ps010ReattribuerMSISDN call per second.
   */
  protected AvgFlowPerSecondCollector _avg_ps010ReattribuerMSISDN_call_counter;

  /**
   * Probe: measure the average execution time of the ps010ReattribuerMSISDN operation.
   */
  protected AvgDoubleCollectorItem _avg_ps010ReattribuerMSISDN_ExecTime;

  /**
   * Probe: measure the average execution time of the ps009GetICCIDFromIMSI call per second.
   */
  protected AvgFlowPerSecondCollector _avg_ps012GetICCIDFromIMSI_call_counter;

  /**
   * Probe: measure the average execution time of the ps009GetICCIDFromIMSI operation.
   */
  protected AvgDoubleCollectorItem _avg_ps012GetICCIDFromIMSI_ExecTime;

  /**
   * Probe: measure the average execution time of the ps011UpdateSIMFromICCID call per second.
   */
  protected AvgFlowPerSecondCollector _avg_ps011UpdateSIMFromICCID_call_counter;

  /**
   * Probe: measure the average execution time of the ps011UpdateSIMFromICCID operation.
   */
  protected AvgDoubleCollectorItem _avg_ps011UpdateSIMFromICCID_ExecTime;

  /**
   * Probe: measure the average execution time of the ps013UpdateEtatMSISDN call per second.
   */
  protected AvgFlowPerSecondCollector _avg_ps013UpdateEtatMSISDN_call_counter;

  /**
   * Probe: measure the average execution time of the ps013UpdateEtatMSISDN operation.
   */
  protected AvgDoubleCollectorItem _avg_ps013UpdateEtatMSISDN_ExecTime;

  /**
   * Probe: measure the average execution time of the ps014GetIdentifiantsCommande call per second.
   */
  protected AvgFlowPerSecondCollector _avg_ps014GetIdentifiantsCommande_call_counter;

  /**
   * Probe: measure the average execution time of the ps014GetIdentifiantsCommande operation.
   */
  protected AvgDoubleCollectorItem _avg_ps014GetIdentifiantsCommande_ExecTime;

  /**
   * Probe: measure the average execution time of the ps015GetProfileType call per second.
   */
  protected AvgFlowPerSecondCollector _avg_ps015GetProfileType_call_counter;

  /**
   * Probe: measure the average execution time of the ps015GetProfileType operation.
   */
  protected AvgDoubleCollectorItem _avg_ps015GetProfileType_ExecTime;

  /**
   * Probe: measure the average execution time of the ps016GetIccidsParldtCmd call per second.
   */
  protected AvgFlowPerSecondCollector _avg_ps016GetIccidsParldtCmd_call_counter;

  /**
   * Probe: measure the average execution time of the ps016GetIccidsParldtCmd operation.
   */
  protected AvgDoubleCollectorItem _avg_ps016GetIccidsParldtCmd_ExecTime;

  /**
   * Probe: measure the average execution time of the ps017GetDateDerniereEchec call per second.
   */
  protected AvgFlowPerSecondCollector _avg_ps017GetDateDerniereEchec_call_counter;

  /**
   * Probe: measure the average execution time of the ps017GetDateDerniereEchec operation.
   */
  protected AvgDoubleCollectorItem _avg_ps017GetDateDerniereEchec_ExecTime;

  /**
   * Probe: measure the average execution time of the ps018SetDateDerniere call per second.
   *
   */
  protected AvgFlowPerSecondCollector _avg_ps018SetDateDerniereEchec_call_counter;

  /**
   * Probe: measure the average execution time of the ps018SetDateDerniere operation.
   */
  protected AvgDoubleCollectorItem _avg_ps018SetDateDerniereEchec_ExecTime;

  /**
   * Probe: measure the average execution time of the ps019UpdateSimDownload call per second.
   *
   */
  protected AvgFlowPerSecondCollector _avg_ps019UpdateSimDownload_call_counter;

  /**
   * Probe: measure the average execution time of the ps019UpdateSimDownload operation.
   */
  protected AvgDoubleCollectorItem _avg_ps019UpdateSimDownload_ExecTime;

  /**
   * Probe: measure the average execution time of the ps020UpdateQuantity call per second.
   */
  protected AvgFlowPerSecondCollector _avg_ps020UpdateQuantity_call_counter;

  /**
   * Probe: measure the average execution time of the ps020UpdateQuantity operation.
   */
  protected AvgDoubleCollectorItem _avg_ps020UpdateQuantity_ExecTime;

  /**
   * Probe: measure the average execution time of the countMsisdnBytelActifs call per second.
   */
  protected AvgFlowPerSecondCollector _avg_countMsisdnBytelActifs_call_counter;

  /**
   * Probe: measure the average execution time of the countMsisdnBytelActifs operation.
   */
  protected AvgDoubleCollectorItem _avg_countMsisdnBytelActifs_ExecTime;

  /**
   * Probe: measure the average execution time of the ps021GetCommandesNonNotifies call per second.
   *
   */
  protected AvgFlowPerSecondCollector _avg_ps021GetCommandesNonNotifies_call_counter;

  /**
   * Probe: measure the average execution time of the ps021GetCommandesNonNotifies operation.
   */
  protected AvgDoubleCollectorItem _avg_ps021GetCommandesNonNotifies_ExecTime;

  /**
   * Probe: measure the average execution time of the ps022GetCommande call per second.
   */
  protected AvgFlowPerSecondCollector _avg_ps022GetCommande_call_counter;

  /**
   * Probe: measure the average execution time of the ps022GetCommande operation.
   */
  protected AvgDoubleCollectorItem _avg_ps022GetCommande_ExecTime;

  /**
   * Probe: measure the average execution time of the ps023UpdateEnvoiCmdSim call per second.
   */
  protected AvgFlowPerSecondCollector _avg_ps023UpdateEnvoiCmdSim_call_counter;

  /**
   * Probe: measure the average execution time of the ps023UpdateEnvoiCmdSim operation.
   */
  protected AvgDoubleCollectorItem _avg_ps023UpdateEnvoiCmdSim_ExecTime;

  /**
   * Probe: measure the average execution time of the ps024GetBytprd call per second.
   */
  protected AvgFlowPerSecondCollector _avg_ps024GetBytprd_call_counter;

  /**
   * Probe: measure the average execution time of the ps024GetBytprd operation.
   */
  protected AvgDoubleCollectorItem _avg_ps024GetBytprd_ExecTime;

  /**
   * Probe: measure the average execution time of the ps025GetSUIVISMDP call per second.
   */
  protected AvgFlowPerSecondCollector _avg_ps025GetSUIVISMDP_call_counter;

  /**
   * Probe: measure the average execution time of the ps025GetSUIVISMDP operation.
   */
  protected AvgDoubleCollectorItem _avg_ps025GetSUIVISMDP_ExecTime;

  /**
   * Probe: measure the average execution time of the ps025GetSUIVISMDP call per second.
   */
  protected AvgFlowPerSecondCollector _avg_ps026EnregistrerEnvoiFichier_call_counter;

  /**
   * Probe: measure the average execution time of the ps025GetSUIVISMDP operation.
   */
  protected AvgDoubleCollectorItem _avg_ps026EnregistrerEnvoiFichier_ExecTime;

  /**
   * Probe: measure the average execution time of the ps025GetSUIVISMDP call per second.
   */
  protected AvgFlowPerSecondCollector _avg_ps027GetSUIVISMDPDernierEchec_call_counter;

  /**
   * Probe: measure the average execution time of the ps025GetSUIVISMDP operation.
   */
  protected AvgDoubleCollectorItem _avg_ps027GetSUIVISMDPDernierEchec_ExecTime;

  /**
   * Probe: measure the average execution time of the psMettreAJourSIMNotif
   */
  protected AvgFlowPerSecondCollector _avg_psMettreAJourSIMNotif_call_counter;

  /**
   * Probe: measure the average execution time of the psMettreAJourSIMNotif
   */
  protected AvgDoubleCollectorItem _avg_psMettreAJourSIMNotif_ExecTime;

  /**
   * Probe: measure the average execution time of the psCheckEtatSimBatch call per second.
   */
  protected AvgFlowPerSecondCollector _avg_psGetStatistiquesEsim_call_counter;

  /**
   * Probe: measure the average execution time of the psCheckEtatSimBatch operation.
   */
  protected AvgDoubleCollectorItem _avg_psGetStatistiquesEsim_ExecTime;

  /**
   * Probe: measure the average execution time of the compterEtatESim call per second.
   */
  protected AvgFlowPerSecondCollector _avg_compterEtatESim_call_counter;

  /**
   * Probe: measure the average execution time of the compterEtatESim operation.
   */
  protected AvgDoubleCollectorItem _avg_compterEtatESim_ExecTime;

  /**
   * Probe: measure the average execution time of the updateSimEtatMocImsi call per second.
   */
  protected AvgFlowPerSecondCollector _avg_updateSimEtatMocImsi_call_counter;

  /**
   * Probe: measure the average execution time of the updateSimEtatMocImsi operation.
   */
  protected AvgDoubleCollectorItem _avg_updateSimEtatMocImsi_ExecTime;

  /**
   * Probe: measure the average execution time of the getSimByGnc call per second.
   */
  protected AvgFlowPerSecondCollector _avg_getSimByGnc_call_counter;

  /**
   * Probe: measure the average execution time of the getSimByGnc operation.
   */
  protected AvgDoubleCollectorItem _avg_getSimByGnc_ExecTime;

  /**
   * Probe: measure the average execution time of the updateSimRessource call per second.
   */
  protected AvgFlowPerSecondCollector _avg_updateSimRessource_call_counter;

  /**
   * Probe: measure the average execution time of the updateSimRessource operation.
   */
  protected AvgDoubleCollectorItem _avg_updateSimRessource_ExecTime;

  /**
   * Probe: measure the average execution time of the getSimByIccidOrImsi call per second.
   */
  protected AvgFlowPerSecondCollector _avg_getSimByIccidOrImsi_call_counter;

  /**
   * Probe: measure the average execution time of the getSimV2ByIccidOrImsi call per second.
   */
  protected AvgFlowPerSecondCollector _avg_getSimV2ByIccidOrImsi_call_counter;

  /**
   * Probe: measure the average execution time of the getSimByIccidOrImsi operation.
   */
  protected AvgDoubleCollectorItem _avg_getSimByIccidOrImsi_ExecTime;
  /**
   * Probe: measure the average execution time of the getSimV2ByIccidOrImsi operation.
   */
  protected AvgDoubleCollectorItem _avg_getSimV2ByIccidOrImsi_ExecTime;

  /**
   * Probe: measure the average execution time of the getPRFByIdtPrf call per second.
   */
  protected AvgFlowPerSecondCollector _avg_getPRFByIdtPrf_call_counter;

  /**
   * Probe: measure the average execution time of the getPRFByIdtPrf operation.
   */
  protected AvgDoubleCollectorItem _avg_getPRFByIdtPrf_ExecTime;

  /**
   * Probe: measure the average execution time of the getInstanceClienteSim call per second.
   */
  protected AvgFlowPerSecondCollector _avg_getInstanceClienteSim_call_counter;

  /**
   * Probe: measure the average execution time of the getInstanceClienteSim operation.
   */
  protected AvgDoubleCollectorItem _avg_getInstanceClienteSim_ExecTime;

  /**
   * Probe: measure the average execution time of the insertErreurSmdp call per second.
   */
  protected AvgFlowPerSecondCollector _avg_insertErreurSmdp_call_counter;

  /**
   * Probe: measure the average execution time of the insertErreurSmdp operation.
   */
  protected AvgDoubleCollectorItem _avg_insertErreurSmdp_ExecTime;

  /**
   * Probe: measure the average execution time of the getErreurSmdpByIccid call per second.
   */
  protected AvgFlowPerSecondCollector _avg_getErreurSmdpByIccid_call_counter;

  /**
   * Probe: measure the average execution time of the getErreurSmdpByIccid operation.
   */
  protected AvgDoubleCollectorItem _avg_getErreurSmdpByIccid_ExecTime;

  /**
   * Probe: measure the average execution time of the getHisetaSimByIdtSim call per second.
   */
  protected AvgFlowPerSecondCollector _avg_getHisetaSimByIdtSim_call_counter;

  /**
   * Probe: measure the average execution time of the getHisetaSimByIdtSim operation.
   */
  protected AvgDoubleCollectorItem _avg_getHisetaSimByIdtSim_ExecTime;

  /**
   * Probe: measure the average execution time of the getSIMDistribuables call per second.
   */
  protected AvgFlowPerSecondCollector _avg_getSIMDistribuables_call_counter;

  /**
   * Probe: measure the average execution time of the getSIMDistribuables operation.
   */
  protected AvgDoubleCollectorItem _avg_getSIMDistribuables_ExecTime;

  /**
   * Probe: measure the average execution time of the getSIMDistribuables call per second.
   */
  protected AvgFlowPerSecondCollector _avg_mettreAJourSIMNotifAppro_call_counter;

  /**
   * Probe: measure the average execution time of the getSIMDistribuables operation.
   */
  protected AvgDoubleCollectorItem _avg_mettreAJourSIMNotifAppro_ExecTime;

  /** Probe: measure the average execution time of the getEsimProfileStatus call per second. */
  protected AvgFlowPerSecondCollector _avg_getEsimProfileStatus_call_counter;

  /** Probe: measure the average execution time of the getEsimProfileStatus operation. */
  protected AvgDoubleCollectorItem _avg_getEsimProfileStatus_execTime;

  /**
   * Default constructor.
   */
  public GDRProxy()
  {
    // probes
    _avg_psRechercheInformationsIMSI_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_psRechercheInformationsIMSI_call_per_second", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_psRechercheInformationsIMSI_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_psRechercheInformationsIMSI_ExecTime", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$

    _avg_psRechercheInformationsICCID_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_psRechercheInformationsICCID_call_per_second", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_psRechercheInformationsICCID_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_psRechercheInformationsICCID_ExecTime", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$

    _avg_psConsultEtatBatch_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_psConsultEtatBatch_call_per_second", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_psConsultEtatBatch_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_psConsultEtatBatch_ExecTime", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$

    _avg_psCheckEtatSimBatch_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_psCheckEtatSimBatch_call_per_second", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_psCheckEtatSimBatch_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_psCheckEtatSimBatch_ExecTime", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$

    _avg_psMiseADispositionSimBatch_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_psMiseADispositionSimBatch_call_per_second", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_psMiseADispositionSimBatch_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_psMiseADispositionSimBatch_ExecTime", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$

    _avg_psConsultSimBatch_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_psConsultSimBatch_call_per_second", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_psConsultSimBatch_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_psConsultSimBatch_ExecTime", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$

    _avg_psMajEtatBatch_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_psMajEtatBatch_call_per_second", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_psMajEtatBatch_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_psMajEtatBatch_ExecTime", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$

    _avg_psMettreAJourSIM_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_psMettreAJourSIM_call_per_second", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_psMettreAJourSIM_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_psmettreAJourSIM_ExecTime", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$

    _avg_ps001ConsultTYPEMSISDNFROMType_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_ps001ConsultTYPEMSISDNFROMType_call_per_second", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_ps001ConsultTYPEMSISDNFROMType_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_ps001ConsultTYPEMSISDNFROMType_ExecTime", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$

    _avg_ps002ReserveMSISDNFROMModeCritere_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_ps002ReserveMSISDNFROMModeCritere_call_per_second", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_ps002ReserveMSISDNFROMModeCritere_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_ps002ReserveMSISDNFROMModeCritere_ExecTime", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$

    _avg_ps003ResiliationMSISDN_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_ps003ResiliationMSISDN_call_per_second", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_ps003ResiliationMSISDN_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_ps003ResiliationMSISDN_ExecTime", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$

    _avg_ps004GetIMSIFromICCID_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_ps004GetIMSIFromICCID_call_per_second", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_ps004GetIMSIFromICCID_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_ps004GetIMSIFromICCID_ExecTime", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$

    _avg_ps005ConsultCarteProfile_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_ps005ConsultCarteProfile_call_per_second", "GDRProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_ps005ConsultCarteProfile_ExectTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_ps005ConsultCarteProfile_ExecTime", "GDRProxy"); //$NON-NLS-1$//$NON-NLS-2$

    _avg_ps006ConsultMSISDN_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_ps006ConsultMSISDN_call_per_second", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_ps006ConsultMSISDN_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_ps006ConsultMSISDN_ExecTime", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$

    _avg_ps007ConsultDureeQuarantaine_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_ps007ConsultDureeQuarantaine_call_per_second", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_ps007ConsultDureeQuarantaine_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_ps007ConsultDureeQuarantaine_ExecTime", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$

    _avg_ps008ConsultLatestHistoriqueEtatMSISDN_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_ps008ConsultLatestHistoriqueEtatMSISDN_call_per_second", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_ps008ConsultLatestHistoriqueEtatMSISDN_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_ps008ConsultLatestHistoriqueEtatMSISDN_ExecTime", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$

    _avg_ps009GetICCIDFromIMSI_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_ps009GetICCIDFromIMSI_call_per_second", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_ps009GetICCIDFromIMSI_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_ps009GetICCIDFromIMSI_ExecTime", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$

    _avg_ps010ReattribuerMSISDN_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_ps010ReattribuerMSISDN_call_per_second", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_ps010ReattribuerMSISDN_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_ps010ReattribuerMSISDN_ExecTime", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$

    _avg_ps012GetICCIDFromIMSI_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_ps009GetICCIDFromIMSI2_call_per_second", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_ps012GetICCIDFromIMSI_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_ps009GetICCIDFromIMSI2_ExecTime", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$

    _avg_ps011UpdateSIMFromICCID_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_ps011UpdateSIMFromICCID_call_per_second", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_ps011UpdateSIMFromICCID_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_ps011UpdateSIMFromICCID_ExecTime", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$

    _avg_ps013UpdateEtatMSISDN_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_ps013UpdateEtatMSISDN_call_per_second", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_ps013UpdateEtatMSISDN_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_ps013UpdateEtatMSISDN_ExecTime", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$

    _avg_ps014GetIdentifiantsCommande_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_ps014GetIdentifiantsCommande_call_per_second", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_ps014GetIdentifiantsCommande_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_ps014GetIdentifiantsCommande_ExecTime", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$

    _avg_ps015GetProfileType_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_ps015GetProfileType_call_per_second", "GDRProxy");//$NON-NLS-1$ //$NON-NLS-2$
    _avg_ps015GetProfileType_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_ps015GetProfileType_ExecTime", "GDRProxy");//$NON-NLS-1$ //$NON-NLS-2$

    _avg_ps016GetIccidsParldtCmd_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_ps016GetIccidsParldtCmd_call_per_second", "GDRProxy");//$NON-NLS-1$ //$NON-NLS-2$
    _avg_ps016GetIccidsParldtCmd_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_ps016GetIccidsParldtCmd_ExecTime", "GDRProxy");//$NON-NLS-1$ //$NON-NLS-2$

    _avg_ps017GetDateDerniereEchec_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_ps017GetDateDerniereEchec_call_per_second", "GDRProxy");//$NON-NLS-1$ //$NON-NLS-2$
    _avg_ps017GetDateDerniereEchec_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_ps017GetDateDerniereEchecN_ExecTime", "GDRProxy");//$NON-NLS-1$ //$NON-NLS-2$

    _avg_ps018SetDateDerniereEchec_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_ps018SetDateDerniereEchec_call_per_second", "GDRProxy");//$NON-NLS-1$ //$NON-NLS-2$
    _avg_ps018SetDateDerniereEchec_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_ps018SetDateDerniereEchec_ExecTime", "GDRProxy");//$NON-NLS-1$ //$NON-NLS-2$

    _avg_ps019UpdateSimDownload_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_ps019UpdateSimDownload_call_per_second", "GDRProxy");//$NON-NLS-1$ //$NON-NLS-2$
    _avg_ps019UpdateSimDownload_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_ps019UpdateSimDownload_ExecTime", "GDRProxy");//$NON-NLS-1$ //$NON-NLS-2$

    _avg_ps020UpdateQuantity_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_ps020UpdateQuantity_call_per_second", "GDRProxy");//$NON-NLS-1$ //$NON-NLS-2$
    _avg_ps020UpdateQuantity_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_ps020UpdateQuantity_ExecTime", "GDRProxy");//$NON-NLS-1$ //$NON-NLS-2$

    _avg_countMsisdnBytelActifs_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_countMsisdnBytelActifs_call_per_second", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_countMsisdnBytelActifs_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_countMsisdnBytelActifs_ExecTime", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$

    _avg_ps021GetCommandesNonNotifies_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_ps021GetCommandesNonNotifies_call_per_second", "GDRProxy");//$NON-NLS-1$ //$NON-NLS-2$
    _avg_ps021GetCommandesNonNotifies_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_ps021GetCommandesNonNotifies_ExecTime", "GDRProxy");//$NON-NLS-1$ //$NON-NLS-2$

    _avg_ps022GetCommande_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_ps022GetCommande_call_per_second", "GDRProxy");//$NON-NLS-1$ //$NON-NLS-2$
    _avg_ps022GetCommande_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_ps022GetCommande_ExecTime", "GDRProxy");//$NON-NLS-1$ //$NON-NLS-2$

    _avg_ps023UpdateEnvoiCmdSim_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_ps023UpdateEnvoiCmdSim_call_per_second", "GDRProxy");//$NON-NLS-1$ //$NON-NLS-2$
    _avg_ps023UpdateEnvoiCmdSim_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_ps023UpdateEnvoiCmdSim_ExecTime", "GDRProxy");//$NON-NLS-1$ //$NON-NLS-2$

    _avg_ps024GetBytprd_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_ps024GetBytprd_call_per_second", "GDRProxy");//$NON-NLS-1$ //$NON-NLS-2$
    _avg_ps024GetBytprd_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_ps024GetBytprd_ExecTime", "GDRProxy");//$NON-NLS-1$ //$NON-NLS-2$

    _avg_ps025GetSUIVISMDP_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_ps025GetSUIVISMDP_call_per_second", "GDRProxy");//$NON-NLS-1$ //$NON-NLS-2$
    _avg_ps025GetSUIVISMDP_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_ps025GetSUIVISMDP_ExecTime", "GDRProxy");//$NON-NLS-1$ //$NON-NLS-2$

    _avg_ps026EnregistrerEnvoiFichier_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_ps026EnregistrerEnvoiFichier_call_per_second", "GDRProxy");//$NON-NLS-1$ //$NON-NLS-2$
    _avg_ps026EnregistrerEnvoiFichier_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_ps026EnregistrerEnvoiFichier_ExecTime", "GDRProxy");//$NON-NLS-1$ //$NON-NLS-2$

    _avg_ps027GetSUIVISMDPDernierEchec_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_ps027GetSUIVISMDPDernierEchec_call_per_second", "GDRProxy");//$NON-NLS-1$ //$NON-NLS-2$
    _avg_ps027GetSUIVISMDPDernierEchec_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_ps027GetSUIVISMDPDernierEchec_ExecTime", "GDRProxy");//$NON-NLS-1$ //$NON-NLS-2$

    _avg_psMettreAJourSIMNotif_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_psMettreAJourSIMNotif_call_per_second", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_psMettreAJourSIMNotif_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_psmettreAJourSIMNotif_ExecTime", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$

    _avg_compterEtatESim_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_compterEtatESim_call_per_second", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_compterEtatESim_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_compterEtatESim_ExecTime", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$

    _avg_psGetStatistiquesEsim_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_psGetStatistiquesEsim_call_per_second", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_psGetStatistiquesEsim_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_psGetStatistiquesEsim_ExecTime", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$

    _avg_getProfilElectriqueParIdentifiant_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_getProfilElectriqueParIdentifiant_call_per_second", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_getProfilElectriqueParIdentifiant_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_getProfilElectriqueParIdentifiant_ExecTime", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$

    _avg_getSimsNonPreProvisionnes_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_getSimsNonPreProvisionnes_call_per_second", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_getSimsNonPreProvisionnes_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_getSimsNonPreProvisionnes_ExecTime", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$

    _avg_updateSimEtatMoc_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_updateSimEtatMoc_call_per_second", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_updateSimEtatMoc_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_updateSimEtatMoc_ExecTime", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$

    _avg_updateSimEtatMocImsi_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_updateSimEtatMocImsi_call_per_second", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_updateSimEtatMocImsi_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_updateSimEtatMocImsi_ExecTime", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$

    _avg_getSimByGnc_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_getSimByGnc_call_per_second", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_getSimByGnc_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_getSimByGnc_ExecTime", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$

    _avg_updateSimRessource_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_updateSimRessource_call_per_second", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_updateSimRessource_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_updateSimRessource_ExecTime", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$

    _avg_getSimByIccidOrImsi_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_getSimByIccidOrImsi_call_per_second", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_getSimByIccidOrImsi_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_getSimByIccidOrImsi_ExecTime", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$

    _avg_getSimV2ByIccidOrImsi_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_getSimV2ByIccidOrImsi_call_per_second", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_getSimV2ByIccidOrImsi_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_getSimV2ByIccidOrImsi_ExecTime", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$

    _avg_getPRFByIdtPrf_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_getPRFByIdtPrf_call_per_second", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_getPRFByIdtPrf_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_getPRFByIdtPrf_ExecTime", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$

    _avg_getInstanceClienteSim_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_getInstanceClienteSim_call_per_second", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_getInstanceClienteSim_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_getInstanceClienteSim_ExecTime", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$

    _avg_insertErreurSmdp_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_insertErreurSmdp_call_per_second", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_insertErreurSmdp_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_insertErreurSmdp_ExecTime", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$

    _avg_getErreurSmdpByIccid_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_getErreurSmdpByIccid_call_per_second", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_getErreurSmdpByIccid_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_getErreurSmdpByIccid_ExecTime", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$

    _avg_getHisetaSimByIdtSim_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_getHisetaSimByIdtSim_call_per_second", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_getHisetaSimByIdtSim_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_getHisetaSimByIdtSim_ExecTime", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$

    _avg_getSIMDistribuables_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_getSIMDistribuables_call_per_second", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_getSIMDistribuables_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_getSIMDistribuables_ExecTime", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$

    _avg_mettreAJourSIMNotifAppro_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_mettreAJourSIMNotifAppro_call_per_second", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_mettreAJourSIMNotifAppro_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_mettreAJourSIMNotifAppro_ExecTime", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$

    _avg_getEsimProfileStatus_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_getEsimProfileStatus_call_per_second", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_getEsimProfileStatus_execTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_getEsimProfileStatus_execTime", "GDRProxy"); //$NON-NLS-1$ //$NON-NLS-2$
  }

  @Override
  public ConnectorResponse<Long, Retour> checkEtatSimBatch(Tracabilite tracabilite_p, final long idBatch_p, final String listeTypeSim_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Long, Retour>>(IGDRConnector.BEAN_ID)
    {
      // @Override
      @Override
      public ConnectorResponse<Long, Retour> run() throws RavelException
      {
        IGDRConnector gdrConnector = (IGDRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        // probes
        _avg_psCheckEtatSimBatch_call_counter.measure();
        // probes
        long startTime = System.currentTimeMillis();
        ConnectorResponse<Long, Retour> response = gdrConnector.checkEtatSimBatch(tracabilite_p, idBatch_p, listeTypeSim_p);
        long endTime = System.currentTimeMillis();
        // probes
        _avg_psCheckEtatSimBatch_ExecTime.updateAvgValue(endTime - startTime);
        // probes
        return response;
      }
    });
  }

  @Override
  public ConnectorResponse<Nothing, Retour> compterEtatESim(Tracabilite tracabilite_p, List<Integer> peConsumer_p, List<Integer> peM2M_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Nothing, Retour>>(IGDRConnector.BEAN_ID)
    {
      // @Override
      @Override
      public ConnectorResponse<Nothing, Retour> run() throws RavelException
      {
        IGDRConnector gdrConnector = (IGDRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        // probes
        _avg_compterEtatESim_call_counter.measure();
        // probes
        long startTime = System.currentTimeMillis();

        ConnectorResponse<Nothing, Retour> response;

        try
        {
          response = gdrConnector.compterEtatESim(tracabilite_p, peConsumer_p, peM2M_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          // probes
          _avg_compterEtatESim_ExecTime.updateAvgValue(endTime - startTime);
        }

        return response;
      }
    });
  }

  @Override
  public ConnectorResponse<String, Retour> consultEtatBatch(Tracabilite tracabilite_p, final long idBatch_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<String, Retour>>(IGDRConnector.BEAN_ID)
    {
      // @Override
      @Override
      public ConnectorResponse<String, Retour> run() throws RavelException
      {
        IGDRConnector gdrConnector = (IGDRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        // probes
        _avg_psConsultEtatBatch_call_counter.measure();
        // probes
        long startTime = System.currentTimeMillis();

        ConnectorResponse<String, Retour> response;

        try
        {
          response = gdrConnector.consultEtatBatch(tracabilite_p, idBatch_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          // probes
          _avg_psConsultEtatBatch_ExecTime.updateAvgValue(endTime - startTime);
        }

        return response;
      }
    });
  }

  @Override
  public ConnectorResponse<ConsultSimBatch, Retour> consultSimBatch(Tracabilite tracabilite_p, final long idBatch_p, final String etasim_p, final String listeTypeSim_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<ConsultSimBatch, Retour>>(IGDRConnector.BEAN_ID)
    {
      // @Override
      @Override
      public ConnectorResponse<ConsultSimBatch, Retour> run() throws RavelException
      {
        IGDRConnector gdrConnector = (IGDRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        // probes
        _avg_psConsultSimBatch_call_counter.measure();
        // probes
        long startTime = System.currentTimeMillis();

        ConnectorResponse<ConsultSimBatch, Retour> response;

        try
        {
          response = gdrConnector.consultSimBatch(tracabilite_p, idBatch_p, etasim_p, listeTypeSim_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          // probes
          _avg_psConsultSimBatch_ExecTime.updateAvgValue(endTime - startTime);
        }

        return response;
      }
    });
  }

  @Override
  public ConnectorResponse<Integer, Retour> countMsisdnBytelActifs(Tracabilite tracabilite_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Integer, Retour>>(IGDRConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Integer, Retour> run() throws RavelException
      {
        IGDRConnector gdrConnector = (IGDRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        // probes
        _avg_countMsisdnBytelActifs_call_counter.measure();
        //probes
        long startTime = System.currentTimeMillis();

        ConnectorResponse<Integer, Retour> response;

        try
        {
          response = gdrConnector.countMsisdnBytelActifs(tracabilite_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          //probes
          _avg_countMsisdnBytelActifs_ExecTime.updateAvgValue(endTime - startTime);
        }

        return response;
      }

    });
  }

  @Override
  public ConnectorResponse<List<ErreurSMDP>, Retour> getErreurSmdpByIccid(Tracabilite tracabilite_p, String iccid_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<List<ErreurSMDP>, Retour>>(IGDRConnector.BEAN_ID)
    {
      // @Override
      @Override
      public ConnectorResponse<List<ErreurSMDP>, Retour> run() throws RavelException
      {
        IGDRConnector gdrConnector = (IGDRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        // probes
        _avg_getErreurSmdpByIccid_call_counter.measure();
        // probes
        long startTime = System.currentTimeMillis();

        ConnectorResponse<List<ErreurSMDP>, Retour> response;

        try
        {
          response = gdrConnector.getErreurSmdpByIccid(tracabilite_p, iccid_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          // probes
          _avg_getErreurSmdpByIccid_ExecTime.updateAvgValue(endTime - startTime);
        }

        return response;
      }
    });
  }

  @Override
  public ConnectorResponse<List<HISETASIM>, Retour> getHisetaSimByIdtSim(Tracabilite tracabilite_p, String idtSim_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<List<HISETASIM>, Retour>>(IGDRConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<List<HISETASIM>, Retour> run() throws RavelException
      {
        IGDRConnector gdrConnector = (IGDRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        // probes
        _avg_getHisetaSimByIdtSim_call_counter.measure();
        // probes
        long startTime = System.currentTimeMillis();

        ConnectorResponse<List<HISETASIM>, Retour> response;

        try
        {
          response = gdrConnector.getHisetaSimByIdtSim(tracabilite_p, idtSim_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          // probes
          _avg_getHisetaSimByIdtSim_ExecTime.updateAvgValue(endTime - startTime);
        }

        return response;
      }
    });
  }

  @Override
  public ConnectorResponse<String, Retour> getInstanceClienteSim(Tracabilite tracabilite_p, String idtsim_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<String, Retour>>(IGDRConnector.BEAN_ID)
    {
      // @Override
      @Override
      public ConnectorResponse<String, Retour> run() throws RavelException
      {
        IGDRConnector gdrConnector = (IGDRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        // probes
        _avg_getInstanceClienteSim_call_counter.measure();
        // probes
        long startTime = System.currentTimeMillis();

        ConnectorResponse<String, Retour> response;

        try
        {
          response = gdrConnector.getInstanceClienteSim(tracabilite_p, idtsim_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          // probes
          _avg_getInstanceClienteSim_ExecTime.updateAvgValue(endTime - startTime);
        }

        return response;
      }
    });
  }

  @Override
  public ConnectorResponse<PRF, Retour> getPRFByIdtPrf(Tracabilite tracabilite_p, String idtprf_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<PRF, Retour>>(IGDRConnector.BEAN_ID)
    {
      // @Override
      @Override
      public ConnectorResponse<PRF, Retour> run() throws RavelException
      {
        IGDRConnector gdrConnector = (IGDRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        // probes
        _avg_getPRFByIdtPrf_call_counter.measure();
        // probes
        long startTime = System.currentTimeMillis();

        ConnectorResponse<PRF, Retour> response;

        try
        {
          response = gdrConnector.getPRFByIdtPrf(tracabilite_p, idtprf_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          // probes
          _avg_getPRFByIdtPrf_ExecTime.updateAvgValue(endTime - startTime);
        }

        return response;
      }
    });
  }

  @Override
  public ConnectorResponse<String, Retour> getProfilElectriqueParIdentifiant(Tracabilite tracabilite_p, String idtprf_p, String typprf_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<String, Retour>>(IGDRConnector.BEAN_ID)
    {
      // @Override
      @Override
      public ConnectorResponse<String, Retour> run() throws RavelException
      {
        IGDRConnector gdrConnector = (IGDRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        // probes
        _avg_getProfilElectriqueParIdentifiant_call_counter.measure();
        // probes
        long startTime = System.currentTimeMillis();

        ConnectorResponse<String, Retour> response;

        try
        {
          response = gdrConnector.getProfilElectriqueParIdentifiant(tracabilite_p, idtprf_p, typprf_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          // probes
          _avg_getProfilElectriqueParIdentifiant_ExecTime.updateAvgValue(endTime - startTime);
        }

        return response;
      }
    });
  }

  @Override
  public ConnectorResponse<List<Sim>, Retour> getSimByGnc(Tracabilite tracabilite_p, String gnc_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<List<Sim>, Retour>>(IGDRConnector.BEAN_ID)
    {
      // @Override
      @Override
      public ConnectorResponse<List<Sim>, Retour> run() throws RavelException
      {
        IGDRConnector gdrConnector = (IGDRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        // probes
        _avg_getSimByGnc_call_counter.measure();
        // probes
        long startTime = System.currentTimeMillis();

        ConnectorResponse<List<Sim>, Retour> response;

        try
        {
          response = gdrConnector.getSimByGnc(tracabilite_p, gnc_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          // probes
          _avg_getSimByGnc_ExecTime.updateAvgValue(endTime - startTime);
        }

        return response;
      }
    });
  }

  @Override
  public ConnectorResponse<Sim, Retour> getSimByIccidOrImsi(Tracabilite tracabilite_p, String iccid_p, String imsi_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Sim, Retour>>(IGDRConnector.BEAN_ID)
    {
      // @Override
      @Override
      public ConnectorResponse<Sim, Retour> run() throws RavelException
      {
        IGDRConnector gdrConnector = (IGDRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        // probes
        _avg_getSimV2ByIccidOrImsi_call_counter.measure();
        // probes
        long startTime = System.currentTimeMillis();

        ConnectorResponse<Sim, Retour> response;

        try
        {
          response = gdrConnector.getSimByIccidOrImsi(tracabilite_p, iccid_p, imsi_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          // probes
          _avg_getSimByIccidOrImsi_ExecTime.updateAvgValue(endTime - startTime);
        }

        return response;
      }
    });
  }

  @Override
  public ConnectorResponse<List<Sim>, Retour> getSIMDistribuables(Tracabilite tracabilite_p, List<Integer> typeSimANotifier_p, Integer nbSimToTreat_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<List<Sim>, Retour>>(IGDRConnector.BEAN_ID)
    {
      // @Override
      @Override
      public ConnectorResponse<List<Sim>, Retour> run() throws RavelException
      {
        IGDRConnector gdrConnector = (IGDRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        // probes
        _avg_getSIMDistribuables_call_counter.measure();
        // probes
        long startTime = System.currentTimeMillis();

        ConnectorResponse<List<Sim>, Retour> response;

        try
        {
          response = gdrConnector.getSIMDistribuables(tracabilite_p, typeSimANotifier_p, nbSimToTreat_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          // probes
          _avg_getSIMDistribuables_ExecTime.updateAvgValue(endTime - startTime);
        }

        return response;
      }
    });
  }

  @Override
  public ConnectorResponse<List<Sim>, Retour> getSimsNonPreProvisionnes(Tracabilite tracabilite_p, String idtCmd_p, String etatMoc_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<List<Sim>, Retour>>(IGDRConnector.BEAN_ID)
    {
      // @Override
      @Override
      public ConnectorResponse<List<Sim>, Retour> run() throws RavelException
      {
        IGDRConnector gdrConnector = (IGDRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        // probes
        _avg_getSimsNonPreProvisionnes_call_counter.measure();
        // probes
        long startTime = System.currentTimeMillis();

        ConnectorResponse<List<Sim>, Retour> response;

        try
        {
          response = gdrConnector.getSimsNonPreProvisionnes(tracabilite_p, idtCmd_p, etatMoc_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          // probes
          _avg_getSimsNonPreProvisionnes_ExecTime.updateAvgValue(endTime - startTime);
        }

        return response;
      }
    });
  }

  @Override
  public ConnectorResponse<List<StatistiqueEsim>, Retour> getStatistiquesEsim(Tracabilite tracabilite_p, String periodicite_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<List<StatistiqueEsim>, Retour>>(IGDRConnector.BEAN_ID)
    {
      // @Override
      @Override
      public ConnectorResponse<List<StatistiqueEsim>, Retour> run() throws RavelException
      {
        IGDRConnector gdrConnector = (IGDRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        // probes
        _avg_psGetStatistiquesEsim_call_counter.measure();
        // probes
        long startTime = System.currentTimeMillis();

        ConnectorResponse<List<StatistiqueEsim>, Retour> response;

        try
        {
          response = gdrConnector.getStatistiquesEsim(tracabilite_p, periodicite_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          // probes
          _avg_psGetStatistiquesEsim_ExecTime.updateAvgValue(endTime - startTime);
        }

        return response;
      }
    });
  }

  @Override
  public ConnectorResponse<Nothing, Retour> insertErreurSmdp(Tracabilite tracabilite_p, String iccid_p, String requestid_p, String etaterreur_p, LocalDateTime dat_p, String idtdermod_p, String etatrequete_p, String entiteerreur_p, String raisonerreur_p, String libelleerreur_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Nothing, Retour>>(IGDRConnector.BEAN_ID)
    {
      // @Override
      @Override
      public ConnectorResponse<Nothing, Retour> run() throws RavelException
      {
        IGDRConnector gdrConnector = (IGDRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        // probes
        _avg_insertErreurSmdp_call_counter.measure();
        // probes
        long startTime = System.currentTimeMillis();

        ConnectorResponse<Nothing, Retour> response;

        try
        {
          response = gdrConnector.insertErreurSmdp(tracabilite_p, iccid_p, requestid_p, etaterreur_p, dat_p, idtdermod_p, etatrequete_p, entiteerreur_p, raisonerreur_p, libelleerreur_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          // probes
          _avg_insertErreurSmdp_ExecTime.updateAvgValue(endTime - startTime);
        }

        return response;
      }
    });
  }

  @Override
  public ConnectorResponse<String, Retour> majEtatBatch(Tracabilite tracabilite_p, final long idBatch_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<String, Retour>>(IGDRConnector.BEAN_ID)
    {
      // @Override
      @Override
      public ConnectorResponse<String, Retour> run() throws RavelException
      {
        IGDRConnector gdrConnector = (IGDRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        // probes
        _avg_psMajEtatBatch_call_counter.measure();
        // probes
        long startTime = System.currentTimeMillis();

        ConnectorResponse<String, Retour> response;

        try
        {
          response = gdrConnector.majEtatBatch(tracabilite_p, idBatch_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          // probes
          _avg_psMajEtatBatch_ExecTime.updateAvgValue(endTime - startTime);
        }

        return response;
      }
    });
  }

  @Override
  public ConnectorResponse<String, Retour> mettreAJourSIM(Tracabilite tracabilite_p, final String iccid_p, final String etatSmdp_p, final String statutTelechargement_p, final String objetModification_p, final String timestamp_p, final String eid_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<String, Retour>>(IGDRConnector.BEAN_ID)
    {
      // @Override
      @Override
      public ConnectorResponse<String, Retour> run() throws RavelException
      {
        IGDRConnector gdrConnector = (IGDRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        // probes
        _avg_psMettreAJourSIM_call_counter.measure();
        // probes
        long startTime = System.currentTimeMillis();

        ConnectorResponse<String, Retour> response;

        try
        {
          response = gdrConnector.mettreAJourSIM(tracabilite_p, iccid_p, etatSmdp_p, statutTelechargement_p, objetModification_p, timestamp_p, eid_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          // probes
          _avg_psMettreAJourSIM_ExecTime.updateAvgValue(endTime - startTime);
        }

        return response;
      }
    });
  }

  @Override
  public ConnectorResponse<String, Retour> mettreAJourSIMNotif(Tracabilite tracabilite_p, String iccid_p, String etatSmdp_p, String identifiantAction_p, String objetModification_p, String datEta_p, String statutNotif_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<String, Retour>>(IGDRConnector.BEAN_ID)
    {
      // @Override
      @Override
      public ConnectorResponse<String, Retour> run() throws RavelException
      {
        IGDRConnector gdrConnector = (IGDRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        // probes
        _avg_psMettreAJourSIMNotif_call_counter.measure();
        // probes
        long startTime = System.currentTimeMillis();

        ConnectorResponse<String, Retour> response;

        try
        {
          response = gdrConnector.mettreAJourSIMNotif(tracabilite_p, iccid_p, etatSmdp_p, identifiantAction_p, objetModification_p, datEta_p, statutNotif_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          // probes
          _avg_psMettreAJourSIMNotif_ExecTime.updateAvgValue(endTime - startTime);
        }

        return response;
      }
    });
  }

  @Override
  public ConnectorResponse<Nothing, Retour> mettreAJourSIMNotifAppro(Tracabilite tracabilite_p, String iccid_p, String notifAppro_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Nothing, Retour>>(IGDRConnector.BEAN_ID)
    {
      // @Override
      @Override
      public ConnectorResponse<Nothing, Retour> run() throws RavelException
      {
        IGDRConnector gdrConnector = (IGDRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        // probes
        _avg_mettreAJourSIMNotifAppro_call_counter.measure();
        // probes
        long startTime = System.currentTimeMillis();

        ConnectorResponse<Nothing, Retour> response;

        try
        {
          response = gdrConnector.mettreAJourSIMNotifAppro(tracabilite_p, iccid_p, notifAppro_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          // probes
          _avg_mettreAJourSIMNotifAppro_ExecTime.updateAvgValue(endTime - startTime);
        }

        return response;
      }
    });
  }

  @Override
  public ConnectorResponse<String, Retour> miseADispositionSimBatch(Tracabilite tracabilite_p, final long idBatch_p, final String listeTypeSim_p, final String instanceCliente_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<String, Retour>>(IGDRConnector.BEAN_ID)
    {
      // @Override
      @Override
      public ConnectorResponse<String, Retour> run() throws RavelException
      {
        IGDRConnector gdrConnector = (IGDRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        // probes
        _avg_psMiseADispositionSimBatch_call_counter.measure();
        // probes
        long startTime = System.currentTimeMillis();

        ConnectorResponse<String, Retour> response;

        try
        {
          response = gdrConnector.miseADispositionSimBatch(tracabilite_p, idBatch_p, listeTypeSim_p, instanceCliente_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          // probes
          _avg_psMiseADispositionSimBatch_ExecTime.updateAvgValue(endTime - startTime);
        }

        return response;
      }
    });
  }

  @Override
  public ConnectorResponse<TypeMsisdn, Retour> ps001ConsultTYPEMSIFROMType(Tracabilite tracabilite_p, final Integer typeMsisdn_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<TypeMsisdn, Retour>>(IGDRConnector.BEAN_ID)
    {
      // @Override
      @Override
      public ConnectorResponse<TypeMsisdn, Retour> run() throws RavelException
      {
        IGDRConnector gdrConnector = (IGDRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        // probes
        _avg_ps001ConsultTYPEMSISDNFROMType_call_counter.measure();
        // probes
        long startTime = System.currentTimeMillis();

        ConnectorResponse<TypeMsisdn, Retour> response;

        try
        {
          response = gdrConnector.ps001ConsultTYPEMSIFROMType(tracabilite_p, typeMsisdn_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          // probes
          _avg_ps001ConsultTYPEMSISDNFROMType_ExecTime.updateAvgValue(endTime - startTime);
        }

        return response;
      }
    });
  }

  @Override
  public ConnectorResponse<List<MSISDN>, Retour> ps002ReserveMSISDNFROMModeCritere(Tracabilite tracabilite_p, final String instanceCliente_p, final Integer nbMsisdn_p, final String mode_p, final Integer typeMsisdn_p, final Integer critereRecherche_p, final Integer typeReservation_p, final String etatCible_p, final String dureeReservation_p, final int dureeReservationTemporaire_p, final String idReservationMSISDN_p, String idtdermod_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<List<MSISDN>, Retour>>(IGDRConnector.BEAN_ID)
    {
      // @Override
      @Override
      public ConnectorResponse<List<MSISDN>, Retour> run() throws RavelException
      {
        IGDRConnector gdrConnector = (IGDRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        // probes
        _avg_ps002ReserveMSISDNFROMModeCritere_call_counter.measure();
        // probes
        long startTime = System.currentTimeMillis();

        ConnectorResponse<List<MSISDN>, Retour> response;

        try
        {
          response = gdrConnector.ps002ReserveMSISDNFROMModeCritere(tracabilite_p, instanceCliente_p, nbMsisdn_p, mode_p, typeMsisdn_p, critereRecherche_p, typeReservation_p, etatCible_p, dureeReservation_p, dureeReservationTemporaire_p, idReservationMSISDN_p, idtdermod_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          // probes
          _avg_ps002ReserveMSISDNFROMModeCritere_ExecTime.updateAvgValue(endTime - startTime);
        }

        return response;
      }
    });
  }

  @Override
  public ConnectorResponse<String, Retour> ps003ResiliationMSISDN(Tracabilite tracabilite_p, final String msisdn_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<String, Retour>>(IGDRConnector.BEAN_ID)
    {
      // @Override
      @Override
      public ConnectorResponse<String, Retour> run() throws RavelException
      {
        IGDRConnector gdrConnector = (IGDRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        // probes
        _avg_ps003ResiliationMSISDN_call_counter.measure();
        // probes
        long startTime = System.currentTimeMillis();

        ConnectorResponse<String, Retour> response;

        try
        {
          response = gdrConnector.ps003ResiliationMSISDN(tracabilite_p, msisdn_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          // probes
          _avg_ps003ResiliationMSISDN_ExecTime.updateAvgValue(endTime - startTime);
        }

        return response;
      }
    });
  }

  @Override
  public ConnectorResponse<String, Retour> ps004GetIMSIFromICCID(Tracabilite tracabilite_p, String iccid_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<String, Retour>>(IGDRConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<String, Retour> run() throws RavelException
      {
        IGDRConnector gdrConnector = (IGDRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        // probes
        _avg_ps004GetIMSIFromICCID_call_counter.measure();
        //probes
        long startTime = System.currentTimeMillis();

        ConnectorResponse<String, Retour> response;

        try
        {
          response = gdrConnector.ps004GetIMSIFromICCID(tracabilite_p, iccid_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          //probes
          _avg_ps004GetIMSIFromICCID_ExecTime.updateAvgValue(endTime - startTime);
        }

        return response;
      }

    });
  }

  @Override
  public ConnectorResponse<List<CarteProfileData>, Retour> ps005ConsultCarteProfile(Tracabilite tracabilite_p, String iccid_p, String imsi_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<List<CarteProfileData>, Retour>>(IGDRConnector.BEAN_ID)
    {

      @Override
      public ConnectorResponse<List<CarteProfileData>, Retour> run() throws RavelException
      {
        IGDRConnector gdrConnector = (IGDRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        // probes
        _avg_ps005ConsultCarteProfile_call_counter.measure();
        // probes
        long startTime = System.currentTimeMillis();

        ConnectorResponse<List<CarteProfileData>, Retour> response;

        try
        {
          response = gdrConnector.ps005ConsultCarteProfile(tracabilite_p, iccid_p, imsi_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          // probes
          _avg_ps005ConsultCarteProfile_ExectTime.updateAvgValue(endTime - startTime);
        }

        return response;
      }

    });
  }

  @Override
  public ConnectorResponse<MSISDN, Retour> ps006ConsultMSISDN(Tracabilite tracabilite_p, String msisdn_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<MSISDN, Retour>>(IGDRConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<MSISDN, Retour> run() throws RavelException
      {
        IGDRConnector gdrConnector = (IGDRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        // probes
        _avg_ps006ConsultMSISDN_call_counter.measure();
        //probes
        long startTime = System.currentTimeMillis();

        ConnectorResponse<MSISDN, Retour> response;

        try
        {
          response = gdrConnector.ps006ConsultMSISDN(tracabilite_p, msisdn_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          //probes
          _avg_ps006ConsultMSISDN_ExecTime.updateAvgValue(endTime - startTime);
        }

        return response;
      }

    });
  }

  @Override
  public ConnectorResponse<DURMSI, Retour> ps007ConsultDureeQuarantaine(Tracabilite tracabilite_p, Integer typeMSISDN_p, String instanceCliente_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<DURMSI, Retour>>(IGDRConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<DURMSI, Retour> run() throws RavelException
      {
        IGDRConnector gdrConnector = (IGDRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        // probes
        _avg_ps007ConsultDureeQuarantaine_call_counter.measure();
        //probes
        long startTime = System.currentTimeMillis();

        ConnectorResponse<DURMSI, Retour> response;

        try
        {
          response = gdrConnector.ps007ConsultDureeQuarantaine(tracabilite_p, typeMSISDN_p, instanceCliente_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          //probes
          _avg_ps007ConsultDureeQuarantaine_ExecTime.updateAvgValue(endTime - startTime);
        }

        return response;
      }

    });
  }

  @Override
  public ConnectorResponse<String, Retour> ps008ConsultLatestHistoriqueEtatMSISDN(Tracabilite tracabilite_p, String numtel_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<String, Retour>>(IGDRConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<String, Retour> run() throws RavelException
      {
        IGDRConnector gdrConnector = (IGDRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        // probes
        _avg_ps008ConsultLatestHistoriqueEtatMSISDN_call_counter.measure();
        //probes
        long startTime = System.currentTimeMillis();

        ConnectorResponse<String, Retour> response;

        try
        {
          response = gdrConnector.ps008ConsultLatestHistoriqueEtatMSISDN(tracabilite_p, numtel_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          //probes
          _avg_ps008ConsultLatestHistoriqueEtatMSISDN_ExecTime.updateAvgValue(endTime - startTime);
        }

        return response;
      }

    });
  }

  @Override
  public ConnectorResponse<String, Retour> ps009GetICCIDFromIMSI(Tracabilite tracabilite_p, String imsi_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<String, Retour>>(IGDRConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<String, Retour> run() throws RavelException
      {
        IGDRConnector gdrConnector = (IGDRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        // probes
        _avg_ps009GetICCIDFromIMSI_call_counter.measure();
        //probes
        long startTime = System.currentTimeMillis();

        ConnectorResponse<String, Retour> response;

        try
        {
          response = gdrConnector.ps009GetICCIDFromIMSI(tracabilite_p, imsi_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          //probes
          _avg_ps009GetICCIDFromIMSI_ExecTime.updateAvgValue(endTime - startTime);
        }

        return response;
      }

    });
  }

  @Override
  public ConnectorResponse<String, Retour> ps010ReattribuerMSISDN(Tracabilite tracabilite_p, long numtel_p, String etatCibleMsisdn_p, String etatCibleCom_p, String etatCiblePorta_p, Integer objetModification_p, String instanceCliente_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<String, Retour>>(IGDRConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<String, Retour> run() throws RavelException
      {
        IGDRConnector gdrConnector = (IGDRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        // probes
        _avg_ps010ReattribuerMSISDN_call_counter.measure();
        //probes
        long startTime = System.currentTimeMillis();

        ConnectorResponse<String, Retour> response;

        try
        {
          response = gdrConnector.ps010ReattribuerMSISDN(tracabilite_p, numtel_p, etatCibleMsisdn_p, etatCibleCom_p, etatCiblePorta_p, objetModification_p, instanceCliente_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          //probes
          _avg_ps010ReattribuerMSISDN_ExecTime.updateAvgValue(endTime - startTime);
        }

        return response;
      }

    });
  }

  @Override
  public ConnectorResponse<String, Retour> ps011UpdateSIMFromICCID(Tracabilite tracabilite_p, String iccid_p, String etatSimCible_p, Integer objetModification_p, String etatComCible_p, String etatPorCible_p, String identifiantModif_p, String instanceCliente_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<String, Retour>>(IGDRConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<String, Retour> run() throws RavelException
      {
        IGDRConnector gdrConnector = (IGDRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        // probes
        _avg_ps011UpdateSIMFromICCID_call_counter.measure();
        //probes
        long startTime = System.currentTimeMillis();

        ConnectorResponse<String, Retour> response;

        try
        {
          response = gdrConnector.ps011UpdateSIMFromICCID(tracabilite_p, iccid_p, etatSimCible_p, objetModification_p, etatComCible_p, etatPorCible_p, identifiantModif_p, instanceCliente_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          //probes
          _avg_ps011UpdateSIMFromICCID_ExecTime.updateAvgValue(endTime - startTime);
        }

        return response;
      }

    });
  }

  @Override
  public ConnectorResponse<Sim, Retour> ps012GetICCIDFromIMSI(Tracabilite tracabilite_p, String imsi_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Sim, Retour>>(IGDRConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Sim, Retour> run() throws RavelException
      {
        IGDRConnector gdrConnector = (IGDRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        // probes
        _avg_ps012GetICCIDFromIMSI_call_counter.measure();
        //probes
        long startTime = System.currentTimeMillis();

        ConnectorResponse<Sim, Retour> response;

        try
        {
          response = gdrConnector.ps012GetICCIDFromIMSI(tracabilite_p, imsi_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          //probes
          _avg_ps012GetICCIDFromIMSI_ExecTime.updateAvgValue(endTime - startTime);
        }

        return response;
      }

    });
  }

  @Override
  public ConnectorResponse<Boolean, Retour> ps013UpdateEtatMsisdn(Tracabilite tracabilite_p, Long numtel_p, String etatCibleMsisdn_p, Integer idtAcnMsi_p, String instanceCliente_p, String idtdermod_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Boolean, Retour>>(IGDRConnector.BEAN_ID)
    {
      // @Override
      @Override
      public ConnectorResponse<Boolean, Retour> run() throws RavelException
      {
        IGDRConnector gdrConnector = (IGDRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        // probes
        _avg_ps013UpdateEtatMSISDN_call_counter.measure();
        // probes
        long startTime = System.currentTimeMillis();

        ConnectorResponse<Boolean, Retour> response;

        try
        {
          response = gdrConnector.ps013UpdateEtatMsisdn(tracabilite_p, numtel_p, etatCibleMsisdn_p, idtAcnMsi_p, instanceCliente_p, idtdermod_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          // probes
          _avg_ps013UpdateEtatMSISDN_ExecTime.updateAvgValue(endTime - startTime);
        }

        return response;
      }
    });
  }

  @Override
  public ConnectorResponse<List<String>, Retour> ps014GetIdentifiantsCommande(Tracabilite tracabilite_p, String idtprfele_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<List<String>, Retour>>(IGDRConnector.BEAN_ID)
    {
      // @Override
      @Override
      public ConnectorResponse<List<String>, Retour> run() throws RavelException
      {
        IGDRConnector gdrConnector = (IGDRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        // probes
        _avg_ps014GetIdentifiantsCommande_call_counter.measure();
        // probes
        long startTime = System.currentTimeMillis();

        ConnectorResponse<List<String>, Retour> response;

        try
        {
          response = gdrConnector.ps014GetIdentifiantsCommande(tracabilite_p, idtprfele_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          // probes
          _avg_ps014GetIdentifiantsCommande_ExecTime.updateAvgValue(endTime - startTime);
        }

        return response;
      }
    });
  }

  @Override
  public ConnectorResponse<String, Retour> ps015GetProfileType(Tracabilite tracabilite_p, String idtprf_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<String, Retour>>(IGDRConnector.BEAN_ID)
    {
      // @Override
      @Override
      public ConnectorResponse<String, Retour> run() throws RavelException
      {
        IGDRConnector gdrConnector = (IGDRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        // probes
        _avg_ps015GetProfileType_call_counter.measure();
        // probes
        long startTime = System.currentTimeMillis();

        ConnectorResponse<String, Retour> response;

        try
        {
          response = gdrConnector.ps015GetProfileType(tracabilite_p, idtprf_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          // probes
          _avg_ps015GetProfileType_ExecTime.updateAvgValue(endTime - startTime);
        }

        return response;
      }
    });
  }

  @Override
  public ConnectorResponse<List<String>, Retour> ps016GetIccidsParldtCmd(Tracabilite tracabilite_p, String idtcmd_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<List<String>, Retour>>(IGDRConnector.BEAN_ID)
    {
      // @Override
      @Override
      public ConnectorResponse<List<String>, Retour> run() throws RavelException
      {
        IGDRConnector gdrConnector = (IGDRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        // probes
        _avg_ps016GetIccidsParldtCmd_call_counter.measure();
        // probes
        long startTime = System.currentTimeMillis();

        ConnectorResponse<List<String>, Retour> response;

        try
        {
          response = gdrConnector.ps016GetIccidsParldtCmd(tracabilite_p, idtcmd_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          // probes
          _avg_ps016GetIccidsParldtCmd_ExecTime.updateAvgValue(endTime - startTime);
        }

        return response;
      }
    });
  }

  @Override
  public ConnectorResponse<LocalDateTime, Retour> ps017GetDateDerniereEchec(Tracabilite tracabilite_p, String idtcmd_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<LocalDateTime, Retour>>(IGDRConnector.BEAN_ID)
    {
      // @Override
      @Override
      public ConnectorResponse<LocalDateTime, Retour> run() throws RavelException
      {
        IGDRConnector gdrConnector = (IGDRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        // probes
        _avg_ps017GetDateDerniereEchec_call_counter.measure();
        // probes
        long startTime = System.currentTimeMillis();

        ConnectorResponse<LocalDateTime, Retour> response;

        try
        {
          response = gdrConnector.ps017GetDateDerniereEchec(tracabilite_p, idtcmd_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          // probes
          _avg_ps017GetDateDerniereEchec_ExecTime.updateAvgValue(endTime - startTime);
        }

        return response;
      }
    });
  }

  @Override
  public ConnectorResponse<Nothing, Retour> ps018SetDateDerniereEchec(Tracabilite tracabilite_p, String idtcmd_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Nothing, Retour>>(IGDRConnector.BEAN_ID)
    {
      // @Override
      @Override
      public ConnectorResponse<Nothing, Retour> run() throws RavelException
      {
        IGDRConnector gdrConnector = (IGDRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        // probes
        _avg_ps018SetDateDerniereEchec_call_counter.measure();
        // probes
        long startTime = System.currentTimeMillis();

        ConnectorResponse<Nothing, Retour> response;

        try
        {
          response = gdrConnector.ps018SetDateDerniereEchec(tracabilite_p, idtcmd_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          // probes
          _avg_ps018SetDateDerniereEchec_ExecTime.updateAvgValue(endTime - startTime);
        }

        return response;
      }
    });
  }

  @Override
  public ConnectorResponse<Nothing, Retour> ps019UpdateSimDownload(Tracabilite tracabilite_p, String iccid_p, String idtacnsim_p, String idtdermod_p, String etasmdp_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Nothing, Retour>>(IGDRConnector.BEAN_ID)
    {
      // @Override
      @Override
      public ConnectorResponse<Nothing, Retour> run() throws RavelException
      {
        IGDRConnector gdrConnector = (IGDRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        // probes
        _avg_ps019UpdateSimDownload_call_counter.measure();
        // probes
        long startTime = System.currentTimeMillis();

        ConnectorResponse<Nothing, Retour> response;

        try
        {
          response = gdrConnector.ps019UpdateSimDownload(tracabilite_p, iccid_p, idtacnsim_p, idtdermod_p, etasmdp_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          // probes
          _avg_ps019UpdateSimDownload_ExecTime.updateAvgValue(endTime - startTime);
        }

        return response;
      }
    });
  }

  @Override
  public ConnectorResponse<Nothing, Retour> ps020UpdateQuantity(Tracabilite tracabilite_p, String idtcmd_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Nothing, Retour>>(IGDRConnector.BEAN_ID)
    {
      // @Override
      @Override
      public ConnectorResponse<Nothing, Retour> run() throws RavelException
      {
        IGDRConnector gdrConnector = (IGDRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        // probes
        _avg_ps020UpdateQuantity_call_counter.measure();
        // probes
        long startTime = System.currentTimeMillis();

        ConnectorResponse<Nothing, Retour> response;

        try
        {
          response = gdrConnector.ps020UpdateQuantity(tracabilite_p, idtcmd_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          // probes
          _avg_ps020UpdateQuantity_ExecTime.updateAvgValue(endTime - startTime);
        }

        return response;
      }
    });
  }

  @Override
  public ConnectorResponse<List<CMDSIM>, Retour> ps021GetCommandesNonNotifies(Tracabilite tracabilite_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<List<CMDSIM>, Retour>>(IGDRConnector.BEAN_ID)
    {

      // @Override
      @Override
      public ConnectorResponse<List<CMDSIM>, Retour> run() throws RavelException
      {
        IGDRConnector gdrConnector = (IGDRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        // probes
        _avg_ps021GetCommandesNonNotifies_call_counter.measure();
        // probes
        long startTime = System.currentTimeMillis();

        ConnectorResponse<List<CMDSIM>, Retour> response;

        try
        {
          response = gdrConnector.ps021GetCommandesNonNotifies(tracabilite_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          // probes
          _avg_ps021GetCommandesNonNotifies_ExecTime.updateAvgValue(endTime - startTime);
        }

        return response;
      }
    });
  }

  @Override
  public ConnectorResponse<CMDSIM, Retour> ps022GetCommande(Tracabilite tracabilite_p, String idtcmd_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<CMDSIM, Retour>>(IGDRConnector.BEAN_ID)
    {

      // @Override
      @Override
      public ConnectorResponse<CMDSIM, Retour> run() throws RavelException
      {
        IGDRConnector gdrConnector = (IGDRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        // probes
        _avg_ps022GetCommande_call_counter.measure();
        // probes
        long startTime = System.currentTimeMillis();

        ConnectorResponse<CMDSIM, Retour> response;

        try
        {
          response = gdrConnector.ps022GetCommande(tracabilite_p, idtcmd_p);

        }
        finally
        {
          long endTime = System.currentTimeMillis();
          // probes
          _avg_ps022GetCommande_ExecTime.updateAvgValue(endTime - startTime);
        }

        return response;
      }
    });
  }

  @Override
  public ConnectorResponse<Nothing, Retour> ps023UpdateEnvoiCmdSim(Tracabilite tracabilite_p, String idtcmd_p, String envoinotifsap_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Nothing, Retour>>(IGDRConnector.BEAN_ID)
    {

      // @Override
      @Override
      public ConnectorResponse<Nothing, Retour> run() throws RavelException
      {
        IGDRConnector gdrConnector = (IGDRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        // probes
        _avg_ps023UpdateEnvoiCmdSim_call_counter.measure();
        // probes
        long startTime = System.currentTimeMillis();

        ConnectorResponse<Nothing, Retour> response;

        try
        {
          response = gdrConnector.ps023UpdateEnvoiCmdSim(tracabilite_p, idtcmd_p, envoinotifsap_p);

        }
        finally
        {
          long endTime = System.currentTimeMillis();
          // probes
          _avg_ps023UpdateEnvoiCmdSim_ExecTime.updateAvgValue(endTime - startTime);
        }

        return response;
      }
    });
  }

  @Override
  public ConnectorResponse<List<BYTPRD>, Retour> ps024GetBytprd(Tracabilite tracabilite_p, String gnc_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<List<BYTPRD>, Retour>>(IGDRConnector.BEAN_ID)
    {

      // @Override
      @Override
      public ConnectorResponse<List<BYTPRD>, Retour> run() throws RavelException
      {
        IGDRConnector gdrConnector = (IGDRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        // probes
        _avg_ps024GetBytprd_call_counter.measure();
        // probes
        long startTime = System.currentTimeMillis();

        ConnectorResponse<List<BYTPRD>, Retour> response;

        try
        {
          response = gdrConnector.ps024GetBytprd(tracabilite_p, gnc_p);

        }
        finally
        {
          long endTime = System.currentTimeMillis();
          // probes
          _avg_ps024GetBytprd_ExecTime.updateAvgValue(endTime - startTime);
        }

        return response;
      }
    });
  }

  @Override
  public ConnectorResponse<List<SUIVISMDP>, Retour> ps025GetSUIVISMDP(Tracabilite tracabilite_p, String idtcmd_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<List<SUIVISMDP>, Retour>>(IGDRConnector.BEAN_ID)
    {

      // @Override
      @Override
      public ConnectorResponse<List<SUIVISMDP>, Retour> run() throws RavelException
      {
        IGDRConnector gdrConnector = (IGDRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        // probes
        _avg_ps025GetSUIVISMDP_call_counter.measure();
        // probes
        long startTime = System.currentTimeMillis();

        ConnectorResponse<List<SUIVISMDP>, Retour> response;

        try
        {
          response = gdrConnector.ps025GetSUIVISMDP(tracabilite_p, idtcmd_p);

        }
        finally
        {
          long endTime = System.currentTimeMillis();
          // probes
          _avg_ps025GetSUIVISMDP_ExecTime.updateAvgValue(endTime - startTime);
        }

        return response;
      }
    });
  }

  @Override
  public ConnectorResponse<Nothing, Retour> ps026EnregistrerEnvoiFichier(Tracabilite tracabilite_p, String idtcmd_p, String nomfichier_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Nothing, Retour>>(IGDRConnector.BEAN_ID)
    {

      // @Override
      @Override
      public ConnectorResponse<Nothing, Retour> run() throws RavelException
      {
        IGDRConnector gdrConnector = (IGDRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        // probes
        _avg_ps026EnregistrerEnvoiFichier_call_counter.measure();
        // probes
        long startTime = System.currentTimeMillis();

        ConnectorResponse<Nothing, Retour> response;

        try
        {
          response = gdrConnector.ps026EnregistrerEnvoiFichier(tracabilite_p, idtcmd_p, nomfichier_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          // probes
          _avg_ps026EnregistrerEnvoiFichier_ExecTime.updateAvgValue(endTime - startTime);
        }

        return response;
      }
    });
  }

  @Override
  public ConnectorResponse<SUIVISMDP, Retour> ps027GetSUIVISMDPDernierEchec(Tracabilite tracabilite_p, String idtcmd_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<SUIVISMDP, Retour>>(IGDRConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<SUIVISMDP, Retour> run() throws RavelException
      {
        IGDRConnector gdrConnector = (IGDRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        // probes
        _avg_ps027GetSUIVISMDPDernierEchec_call_counter.measure();
        // probes
        long startTime = System.currentTimeMillis();

        ConnectorResponse<SUIVISMDP, Retour> response;

        try
        {
          response = gdrConnector.ps027GetSUIVISMDPDernierEchec(tracabilite_p, idtcmd_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          // probes
          _avg_ps027GetSUIVISMDPDernierEchec_ExecTime.updateAvgValue(endTime - startTime);
        }

        return response;
      }
    });
  }

  @Override
  public ConnectorResponse<InfoSIM, Retour> rechercheInformationsICCID(Tracabilite tracabilite_p, final long iccid_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<InfoSIM, Retour>>(IGDRConnector.BEAN_ID)
    {
      // @Override
      @Override
      public ConnectorResponse<InfoSIM, Retour> run() throws RavelException
      {
        IGDRConnector gdrConnector = (IGDRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        // probes
        _avg_psRechercheInformationsICCID_call_counter.measure();
        // probes
        long startTime = System.currentTimeMillis();

        ConnectorResponse<InfoSIM, Retour> response;

        try
        {
          response = gdrConnector.rechercheInformationsICCID(tracabilite_p, iccid_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          // probes
          _avg_psRechercheInformationsICCID_ExecTime.updateAvgValue(endTime - startTime);
        }

        return response;

      }
    });
  }

  @Override
  public ConnectorResponse<InfoSIM, Retour> rechercheInformationsIMSI(Tracabilite tracabilite_p, final long imsi_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<InfoSIM, Retour>>(IGDRConnector.BEAN_ID)
    {
      // @Override
      @Override
      public ConnectorResponse<InfoSIM, Retour> run() throws RavelException
      {
        IGDRConnector gdrConnector = (IGDRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        // probes
        _avg_psRechercheInformationsIMSI_call_counter.measure();
        // probes
        long startTime = System.currentTimeMillis();

        ConnectorResponse<InfoSIM, Retour> response;

        try
        {
          response = gdrConnector.rechercheInformationsIMSI(tracabilite_p, imsi_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          // probes
          _avg_psRechercheInformationsIMSI_ExecTime.updateAvgValue(endTime - startTime);
        }

        return response;
      }
    });
  }

  @Override
  public ConnectorResponse<Nothing, Retour> updateSimEtatMoc(Tracabilite tracabilite_p, String pe_p, String etatMoc_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Nothing, Retour>>(IGDRConnector.BEAN_ID)
    {
      // @Override
      @Override
      public ConnectorResponse<Nothing, Retour> run() throws RavelException
      {
        IGDRConnector gdrConnector = (IGDRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        // probes
        _avg_updateSimEtatMoc_call_counter.measure();
        // probes
        long startTime = System.currentTimeMillis();

        ConnectorResponse<Nothing, Retour> response;

        try
        {
          response = gdrConnector.updateSimEtatMoc(tracabilite_p, pe_p, etatMoc_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          // probes
          _avg_updateSimEtatMoc_ExecTime.updateAvgValue(endTime - startTime);
        }

        return response;
      }
    });
  }

  @Override
  public ConnectorResponse<Nothing, Retour> updateSimEtatMocImsi(Tracabilite tracabilite_p, String imsi_p, String etatMoc_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Nothing, Retour>>(IGDRConnector.BEAN_ID)
    {
      // @Override
      @Override
      public ConnectorResponse<Nothing, Retour> run() throws RavelException
      {
        IGDRConnector gdrConnector = (IGDRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        // probes
        _avg_updateSimEtatMocImsi_call_counter.measure();
        // probes
        long startTime = System.currentTimeMillis();

        ConnectorResponse<Nothing, Retour> response;

        try
        {
          response = gdrConnector.updateSimEtatMocImsi(tracabilite_p, imsi_p, etatMoc_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          // probes
          _avg_updateSimEtatMocImsi_ExecTime.updateAvgValue(endTime - startTime);
        }

        return response;
      }
    });
  }

  @Override
  public ConnectorResponse<Nothing, Retour> updateSimRessource(Tracabilite tracabilite_p, String iccid_p, String etaSim_p, Long idtAcnSim_p, String idtDermod_p, String idtist_p, String etasmdp_p, String etatNotif_p, String policyEtat_p, String policyHabilitation_p, String eid_p, String smsrid_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Nothing, Retour>>(IGDRConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Nothing, Retour> run() throws RavelException
      {
        IGDRConnector gdrConnector = (IGDRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        // probes
        _avg_updateSimRessource_call_counter.measure();
        // probes
        long startTime = System.currentTimeMillis();

        ConnectorResponse<Nothing, Retour> response;

        try
        {
          response = gdrConnector.updateSimRessource(tracabilite_p, iccid_p, etaSim_p, idtAcnSim_p, idtDermod_p, idtist_p, etasmdp_p, etatNotif_p, policyEtat_p, policyHabilitation_p, eid_p, smsrid_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          // probes
          _avg_updateSimRessource_ExecTime.updateAvgValue(endTime - startTime);
        }

        return response;
      }
    });
  }

  @Override
  public ConnectorResponse<Nothing, Retour> getEsimProfileStatus(Tracabilite tracabilite_p, String typeSim_p, String profileType_p, ICallbackLireSim callback_p, int listSize_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Nothing, Retour>>(IGDRConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Nothing, Retour> run() throws RavelException
      {
        IGDRConnector gdrConnector = (IGDRConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        
        // Take care of the probes
        _avg_updateSimRessource_call_counter.measure();
        long startTime = System.currentTimeMillis();

        ConnectorResponse<Nothing, Retour> response;

        try
        {
          response = gdrConnector.getEsimProfileStatus(tracabilite_p, typeSim_p, profileType_p, callback_p, listSize_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_updateSimRessource_ExecTime.updateAvgValue(endTime - startTime);
        }

        return response;
      }
    });
  }
}
