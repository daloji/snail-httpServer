/*******************************************************************************
* $Id: GDRPGReportingGDS.java 17031 2019-02-12 11:19:48Z lmerces $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.gdr.utils;

import static com.bytel.spirit.common.connectors.gdr.utils.GDRConnectorConstants.CONNEXION_FAILED;
import static com.bytel.spirit.common.connectors.gdr.utils.GDRConnectorConstants.SELECT_FAILED;
import static com.bytel.spirit.common.connectors.gdr.utils.GDRConnectorConstants.SESSION_UNAVAILABLE;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.SQLRecoverableException;
import java.sql.SQLTimeoutException;
import java.text.MessageFormat;

import org.apache.tomcat.jdbc.pool.DataSource;
import org.apache.tomcat.jdbc.pool.PoolExhaustedException;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.connectors.gdr.Messages;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

import oracle.jdbc.OracleTypes;

/**
 *
 * @author lmerces
 * @version ($Revision: 17031 $ $Date: 2019-02-12 12:19:48 +0100 (mar. 12 févr. 2019) $)
 */
public class GDRPGReportingGDS extends GDRConnectorUtils
{
  /**
   * Datasource
   */
  private DataSource _datasource;

  /**
   * Read timeout in seconds
   */
  private int _readTimeoutSec;

  /**
   * Connect timeout in seconds
   */
  private int _connectTimeoutSec;

  /**
   * @param datasource_p
   *          datasource
   * @param readTimeoutSec_p
   *          readTimeoutSec
   * @param connectTimeoutSec_p
   *          connectTimeoutSec
   */
  public GDRPGReportingGDS(DataSource datasource_p, int readTimeoutSec_p, int connectTimeoutSec_p)
  {
    super();
    _datasource = datasource_p;
    _readTimeoutSec = readTimeoutSec_p;
    _connectTimeoutSec = connectTimeoutSec_p;
  }

  /**
   * Count Msisdn Bytel Actifs
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @return {@link ConnectorResponse}
   * @throws RavelException
   *           exception
   */
  public ConnectorResponse<Integer, Retour> countMsisdnBytelActifs(Tracabilite tracabilite_p) throws RavelException
  {
    final String methodName = "PG_REPORTING_GDS.PR_EXT_MSISDN_BYTEL_ACTIFS"; //$NON-NLS-1$
    try (Connection con = _datasource.getConnection(); CallableStatement callableStatement = con.prepareCall("{call PG_REPORTING_GDS.PR_EXT_MSISDN_BYTEL_ACTIFS(?)}")) //$NON-NLS-1$
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.INFO, tracabilite_p, methodName));
      callableStatement.setQueryTimeout(_readTimeoutSec);

      callableStatement.registerOutParameter(1, OracleTypes.NUMBER);
      callableStatement.execute();
      int count = callableStatement.getInt(1);

      Retour retour = RetourFactory.createOkRetour();
      SpiritLogEvent outputLog = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, methodName);
      outputLog.addField("Retour", retour, false); //$NON-NLS-1$
      RavelLogger.log(outputLog);
      return new ConnectorResponse<>(count, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, "No input parameters"); //$NON-NLS-1$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SELECT_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, "No input parameters"); //$NON-NLS-1$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("GDRConnector.ERREUR_GDR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, "No input parameters"); //$NON-NLS-1$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, "No input parameters"); //$NON-NLS-1$
    }
  }
}
