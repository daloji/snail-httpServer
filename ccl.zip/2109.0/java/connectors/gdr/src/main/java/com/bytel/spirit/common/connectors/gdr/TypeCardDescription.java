/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.gdr;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>
 * Java class for LibelleTypeCarte.
 *
 * <p>
 * The following schema fragment specifies the expected content contained within this class.
 * <p>
 *
 * <pre>
 * &lt;simpleType name="LibelleTypeCarte">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="ISO"/>
 *     &lt;enumeration value="PLUG-IN"/>
 *     &lt;enumeration value="UNIVERSEL"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 *
 * @author lmerces
 * @version ($Revision$ $Date$)
 */
@XmlType(name = "LibelleTypeCarte")
@XmlEnum
public enum TypeCardDescription
{

  /**
   * ISO
   */
  ISO("ISO"), //$NON-NLS-1$

  /**
   * PLUG_IN
   */
  @XmlEnumValue("PLUG-IN")
  PLUG_IN("PLUG-IN"), //$NON-NLS-1$

  /**
   * UNIVERSEL
   */
  UNIVERSEL("UNIVERSEL"); //$NON-NLS-1$

  /**
   * @param v_p
   *          v
   * @return enum
   */
  public static TypeCardDescription fromValue(String v_p)
  {
    for (TypeCardDescription c : TypeCardDescription.values())
    {
      if (c._value.equals(v_p))
      {
        return c;
      }
    }
    throw new IllegalArgumentException(v_p);
  }

  /**
   * value
   */
  private final String _value;

  /**
   * @param v_p
   *          v
   */
  TypeCardDescription(String v_p)
  {
    _value = v_p;
  }

  /**
   * @return value
   */
  public String value()
  {
    return _value;
  }

}
