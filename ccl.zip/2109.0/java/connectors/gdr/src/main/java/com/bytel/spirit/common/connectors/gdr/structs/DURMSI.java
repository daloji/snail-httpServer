/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.gdr.structs;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author lmerces
 * @version ($Revision$ $Date$)
 */
public class DURMSI
{
  /**
   * Constant with the value of the Table Column for TYPMSI
   */
  public static final String TYPMSI = "TYPMSI"; //$NON-NLS-1$

  /**
   * Constant with the value of the Table Column for TYPIST
   */
  public static final String TYPIST = "TYPIST"; //$NON-NLS-1$

  /**
   * Constant with the value of the Table Column for DUR040
   */
  public static final String DUR040 = "DUR040"; //$NON-NLS-1$

  /**
   * Type du MSISDN
   */
  private Integer _typeMSISDN;

  /**
   * Type de l'instance
   */
  private String _typeInstance;

  /**
   * Durée de quarantaine
   */
  private Integer _dureeQuarantaine;

  /**
   * Constructor
   *
   * @param typeMSISDN_p
   *          Type du MSISDN
   * @param typeInstance_p
   *          Type de l'instance
   * @param dureeQuarantaine_p
   *          Durée de quarantaine
   */
  public DURMSI(Integer typeMSISDN_p, String typeInstance_p, Integer dureeQuarantaine_p)
  {
    _typeMSISDN = typeMSISDN_p;
    _typeInstance = typeInstance_p;
    _dureeQuarantaine = dureeQuarantaine_p;
  }

  /**
   * Create a new instance DURMSI from a ResultSet
   *
   * @param rs
   *          ResultSet
   * @throws SQLException
   *           exception
   */
  public DURMSI(ResultSet rs) throws SQLException
  {
    super();
    this._typeMSISDN = rs.getObject(TYPMSI) != null ? rs.getInt(TYPMSI) : null;
    this._typeInstance = rs.getString(TYPIST);
    this._dureeQuarantaine = rs.getObject(DUR040) != null ? rs.getInt(DUR040) : null;

  }

  /**
   * @return the dureeQuarantaine
   */
  public Integer getDureeQuarantaine()
  {
    return _dureeQuarantaine;
  }

  /**
   * @return the typeInstance
   */
  public String getTypeInstance()
  {
    return _typeInstance;
  }

  /**
   * @return the typeMSISDN
   */
  public Integer getTypeMSISDN()
  {
    return _typeMSISDN;
  }

  /**
   * @param dureeQuarantaine_p
   *          the dureeQuarantaine to set
   */
  public void setDureeQuarantaine(Integer dureeQuarantaine_p)
  {
    _dureeQuarantaine = dureeQuarantaine_p;
  }

  /**
   * @param typeInstance_p
   *          the typeInstance to set
   */
  public void setTypeInstance(String typeInstance_p)
  {
    _typeInstance = typeInstance_p;
  }

  /**
   * @param typeMSISDN_p
   *          the typeMSISDN to set
   */
  public void setTypeMSISDN(Integer typeMSISDN_p)
  {
    _typeMSISDN = typeMSISDN_p;
  }

  @Override
  public String toString()
  {
    return "[durmsi > _typeMSISDN=" + _typeMSISDN + ", _typeInstance=" + _typeInstance + ", _dureeQuarantaine=" + _dureeQuarantaine + "]"; //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$ //$NON-NLS-4$
  }
}
