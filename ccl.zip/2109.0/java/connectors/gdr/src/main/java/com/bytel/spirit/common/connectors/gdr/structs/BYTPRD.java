/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.gdr.structs;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

/**
 *
 * @author jramos
 * @version ($Revision$ $Date$)
 */
public class BYTPRD
{

  /**
   *
   */
  Long _gnc;
  /**
   *
   */
  String _typGNC;
  /**
   *
   */
  String _idtARTWRK;
  /**
   *
   */
  Long _idtPRFELC;

  /**
   *
   */
  Long _idtPRFGRF;
  /**
   *
   */
  String _idtFAB;
  /**
   *
   */
  Long _idtSIMCLA;
  /**
   *
   */
  Long _typSIM;
  /**
   *
   */
  String _idtUSASIM;
  /**
   *
   */
  String _codARTSAP;
  /**
   *
   */
  String _libARTSAP;
  /**
   *
   */
  String _debTRAMSI;
  /**
   *
   */
  String _finTRAMSI;
  /**
   *
   */
  Date _datFINVAL;
  /**
   *
   */
  Long _idtOPE;

  /**
   *
   */
  public BYTPRD()
  {
    // TODO Auto-generated constructor stub
  }

  /**
   * @param gnc_p
   * @param typGNC_p
   * @param idtARTWRK_p
   * @param idtPRFELC_p
   * @param idtPRFGRF_p
   * @param idtFAB_p
   * @param idtSIMCLA_p
   * @param typSIM_p
   * @param idtUSASIM_p
   * @param codARTSAP_p
   * @param libARTSAP_p
   * @param debTRAMSI_p
   * @param finTRAMSI_p
   * @param datFINVAL_p
   * @param idtOPE_p
   */
  @SuppressWarnings("javadoc")
  public BYTPRD(Long gnc_p, String typGNC_p, String idtARTWRK_p, Long idtPRFELC_p, Long idtPRFGRF_p, String idtFAB_p, Long idtSIMCLA_p, Long typSIM_p, String idtUSASIM_p, String codARTSAP_p, String libARTSAP_p, String debTRAMSI_p, String finTRAMSI_p, Date datFINVAL_p, Long idtOPE_p)
  {
    super();
    _gnc = gnc_p;
    _typGNC = typGNC_p;
    _idtARTWRK = idtARTWRK_p;
    _idtPRFELC = idtPRFELC_p;
    _idtPRFGRF = idtPRFGRF_p;
    _idtFAB = idtFAB_p;
    _idtSIMCLA = idtSIMCLA_p;
    _typSIM = typSIM_p;
    _idtUSASIM = idtUSASIM_p;
    _codARTSAP = codARTSAP_p;
    _libARTSAP = libARTSAP_p;
    _debTRAMSI = debTRAMSI_p;
    _finTRAMSI = finTRAMSI_p;
    _datFINVAL = datFINVAL_p;
    _idtOPE = idtOPE_p;
  }

  /**
   * @param rs_p
   *          ResultSet
   * @throws SQLException
   *           Exception
   *
   */
  public BYTPRD(ResultSet rs_p) throws SQLException
  {
    super();
    _gnc = rs_p.getLong("GNC"); //$NON-NLS-1$
    _typGNC = rs_p.getString("TYPGNC"); //$NON-NLS-1$
    _idtARTWRK = rs_p.getString("IDTARTWRK"); //$NON-NLS-1$
    _idtPRFELC = rs_p.getLong("IDTPRFELC"); //$NON-NLS-1$
    _idtPRFGRF = rs_p.getLong("IDTPRFGRF"); //$NON-NLS-1$
    _idtFAB = rs_p.getString("IDTFAB"); //$NON-NLS-1$
    _idtSIMCLA = rs_p.getLong("IDTSIMCLA"); //$NON-NLS-1$
    _typSIM = rs_p.getLong("TYPSIM"); //$NON-NLS-1$
    _idtUSASIM = rs_p.getString("IDTUSASIM"); //$NON-NLS-1$
    _codARTSAP = rs_p.getString("CODARTSAP"); //$NON-NLS-1$
    _libARTSAP = rs_p.getString("LIBARTSAP"); //$NON-NLS-1$
    _debTRAMSI = rs_p.getString("DEBTRAMSI"); //$NON-NLS-1$
    _finTRAMSI = rs_p.getString("FINTRAMSI"); //$NON-NLS-1$
    _datFINVAL = rs_p.getDate("DATFINVAL"); //$NON-NLS-1$

    _idtOPE = rs_p.getLong("IDTOPE"); //$NON-NLS-1$
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    BYTPRD other = (BYTPRD) obj;
    if (_codARTSAP == null)
    {
      if (other._codARTSAP != null)
      {
        return false;
      }
    }
    else if (!_codARTSAP.equals(other._codARTSAP))
    {
      return false;
    }
    if (_datFINVAL == null)
    {
      if (other._datFINVAL != null)
      {
        return false;
      }
    }
    else if (!_datFINVAL.equals(other._datFINVAL))
    {
      return false;
    }
    if (_debTRAMSI == null)
    {
      if (other._debTRAMSI != null)
      {
        return false;
      }
    }
    else if (!_debTRAMSI.equals(other._debTRAMSI))
    {
      return false;
    }
    if (_finTRAMSI == null)
    {
      if (other._finTRAMSI != null)
      {
        return false;
      }
    }
    else if (!_finTRAMSI.equals(other._finTRAMSI))
    {
      return false;
    }
    if (_gnc == null)
    {
      if (other._gnc != null)
      {
        return false;
      }
    }
    else if (!_gnc.equals(other._gnc))
    {
      return false;
    }
    if (_idtARTWRK == null)
    {
      if (other._idtARTWRK != null)
      {
        return false;
      }
    }
    else if (!_idtARTWRK.equals(other._idtARTWRK))
    {
      return false;
    }
    if (_idtFAB == null)
    {
      if (other._idtFAB != null)
      {
        return false;
      }
    }
    else if (!_idtFAB.equals(other._idtFAB))
    {
      return false;
    }
    if (_idtOPE == null)
    {
      if (other._idtOPE != null)
      {
        return false;
      }
    }
    else if (!_idtOPE.equals(other._idtOPE))
    {
      return false;
    }
    if (_idtPRFELC == null)
    {
      if (other._idtPRFELC != null)
      {
        return false;
      }
    }
    else if (!_idtPRFELC.equals(other._idtPRFELC))
    {
      return false;
    }
    if (_idtPRFGRF == null)
    {
      if (other._idtPRFGRF != null)
      {
        return false;
      }
    }
    else if (!_idtPRFGRF.equals(other._idtPRFGRF))
    {
      return false;
    }
    if (_idtSIMCLA == null)
    {
      if (other._idtSIMCLA != null)
      {
        return false;
      }
    }
    else if (!_idtSIMCLA.equals(other._idtSIMCLA))
    {
      return false;
    }
    if (_idtUSASIM == null)
    {
      if (other._idtUSASIM != null)
      {
        return false;
      }
    }
    else if (!_idtUSASIM.equals(other._idtUSASIM))
    {
      return false;
    }
    if (_libARTSAP == null)
    {
      if (other._libARTSAP != null)
      {
        return false;
      }
    }
    else if (!_libARTSAP.equals(other._libARTSAP))
    {
      return false;
    }
    if (_typGNC == null)
    {
      if (other._typGNC != null)
      {
        return false;
      }
    }
    else if (!_typGNC.equals(other._typGNC))
    {
      return false;
    }
    if (_typSIM == null)
    {
      if (other._typSIM != null)
      {
        return false;
      }
    }
    else if (!_typSIM.equals(other._typSIM))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the codARTSAP
   */
  public String getCodARTSAP()
  {
    return _codARTSAP;
  }

  /**
   * @return the datFINVAL
   */
  public Date getDatFINVAL()
  {
    return _datFINVAL;
  }

  /**
   * @return the debTRAMSI
   */
  public String getDebTRAMSI()
  {
    return _debTRAMSI;
  }

  /**
   * @return the finTRAMSI
   */
  public String getFinTRAMSI()
  {
    return _finTRAMSI;
  }

  /**
   * @return the gnc
   */
  public Long getGnc()
  {
    return _gnc;
  }

  /**
   * @return the idtARTWRK
   */
  public String getIdtARTWRK()
  {
    return _idtARTWRK;
  }

  /**
   * @return the idtFAB
   */
  public String getIdtFAB()
  {
    return _idtFAB;
  }

  /**
   * @return the idtOPE
   */
  public Long getIdtOPE()
  {
    return _idtOPE;
  }

  /**
   * @return the idtPRFELC
   */
  public Long getIdtPRFELC()
  {
    return _idtPRFELC;
  }

  /**
   * @return the idtPRFGRF
   */
  public Long getIdtPRFGRF()
  {
    return _idtPRFGRF;
  }

  /**
   * @return the idtSIMCLA
   */
  public Long getIdtSIMCLA()
  {
    return _idtSIMCLA;
  }

  /**
   * @return the idtUSASIM
   */
  public String getIdtUSASIM()
  {
    return _idtUSASIM;
  }

  /**
   * @return the libARTSAP
   */
  public String getLibARTSAP()
  {
    return _libARTSAP;
  }

  /**
   * @return the typGNC
   */
  public String getTypGNC()
  {
    return _typGNC;
  }

  /**
   * @return the typSIM
   */
  public Long getTypSIM()
  {
    return _typSIM;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_codARTSAP == null) ? 0 : _codARTSAP.hashCode());
    result = (prime * result) + ((_datFINVAL == null) ? 0 : _datFINVAL.hashCode());
    result = (prime * result) + ((_debTRAMSI == null) ? 0 : _debTRAMSI.hashCode());
    result = (prime * result) + ((_finTRAMSI == null) ? 0 : _finTRAMSI.hashCode());
    result = (prime * result) + ((_gnc == null) ? 0 : _gnc.hashCode());
    result = (prime * result) + ((_idtARTWRK == null) ? 0 : _idtARTWRK.hashCode());
    result = (prime * result) + ((_idtFAB == null) ? 0 : _idtFAB.hashCode());
    result = (prime * result) + ((_idtOPE == null) ? 0 : _idtOPE.hashCode());
    result = (prime * result) + ((_idtPRFELC == null) ? 0 : _idtPRFELC.hashCode());
    result = (prime * result) + ((_idtPRFGRF == null) ? 0 : _idtPRFGRF.hashCode());
    result = (prime * result) + ((_idtSIMCLA == null) ? 0 : _idtSIMCLA.hashCode());
    result = (prime * result) + ((_idtUSASIM == null) ? 0 : _idtUSASIM.hashCode());
    result = (prime * result) + ((_libARTSAP == null) ? 0 : _libARTSAP.hashCode());
    result = (prime * result) + ((_typGNC == null) ? 0 : _typGNC.hashCode());
    result = (prime * result) + ((_typSIM == null) ? 0 : _typSIM.hashCode());
    return result;
  }

  /**
   * @param codARTSAP_p
   *          the codARTSAP to set
   */
  public void setCodARTSAP(String codARTSAP_p)
  {
    _codARTSAP = codARTSAP_p;
  }

  /**
   * @param datFINVAL_p
   *          the datFINVAL to set
   */
  public void setDatFINVAL(Date datFINVAL_p)
  {
    _datFINVAL = datFINVAL_p;
  }

  /**
   * @param debTRAMSI_p
   *          the debTRAMSI to set
   */
  public void setDebTRAMSI(String debTRAMSI_p)
  {
    _debTRAMSI = debTRAMSI_p;
  }

  /**
   * @param finTRAMSI_p
   *          the finTRAMSI to set
   */
  public void setFinTRAMSI(String finTRAMSI_p)
  {
    _finTRAMSI = finTRAMSI_p;
  }

  /**
   * @param gnc_p
   *          the gnc to set
   */
  public void setGnc(Long gnc_p)
  {
    _gnc = gnc_p;
  }

  /**
   * @param idtARTWRK_p
   *          the idtARTWRK to set
   */
  public void setIdtARTWRK(String idtARTWRK_p)
  {
    _idtARTWRK = idtARTWRK_p;
  }

  /**
   * @param idtFAB_p
   *          the idtFAB to set
   */
  public void setIdtFAB(String idtFAB_p)
  {
    _idtFAB = idtFAB_p;
  }

  /**
   * @param idtOPE_p
   *          the idtOPE to set
   */
  public void setIdtOPE(Long idtOPE_p)
  {
    _idtOPE = idtOPE_p;
  }

  /**
   * @param idtPRFELC_p
   *          the idtPRFELC to set
   */
  public void setIdtPRFELC(Long idtPRFELC_p)
  {
    _idtPRFELC = idtPRFELC_p;
  }

  /**
   * @param idtPRFGRF_p
   *          the idtPRFGRF to set
   */
  public void setIdtPRFGRF(Long idtPRFGRF_p)
  {
    _idtPRFGRF = idtPRFGRF_p;
  }

  /**
   * @param idtSIMCLA_p
   *          the idtSIMCLA to set
   */
  public void setIdtSIMCLA(Long idtSIMCLA_p)
  {
    _idtSIMCLA = idtSIMCLA_p;
  }

  /**
   * @param idtUSASIM_p
   *          the idtUSASIM to set
   */
  public void setIdtUSASIM(String idtUSASIM_p)
  {
    _idtUSASIM = idtUSASIM_p;
  }

  /**
   * @param libARTSAP_p
   *          the libARTSAP to set
   */
  public void setLibARTSAP(String libARTSAP_p)
  {
    _libARTSAP = libARTSAP_p;
  }

  /**
   * @param typGNC_p
   *          the typGNC to set
   */
  public void setTypGNC(String typGNC_p)
  {
    _typGNC = typGNC_p;
  }

  /**
   * @param typSIM_p
   *          the typSIM to set
   */
  public void setTypSIM(Long typSIM_p)
  {
    _typSIM = typSIM_p;
  }

}
