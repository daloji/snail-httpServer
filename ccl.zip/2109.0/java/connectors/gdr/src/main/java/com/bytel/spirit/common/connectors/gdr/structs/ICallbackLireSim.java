/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.gdr.structs;

import java.util.List;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

/**
 * @author acorreia
 * @version ($Revision$ $Date$)
 */
public interface ICallbackLireSim
{
  /**
   * Consume method that will receive a list of the eSim profiles.
   *
   * @param tracabilite_p
   *          tracabilite object
   * @param simList_p
   *          the list of {@link Sim}.
   * @return the retour.
   * @throws RavelException
   *           on error.
   */
  Retour consume(Tracabilite tracabilite_p, List<Sim> simList_p) throws RavelException;
}
