/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.gdr.structs;

import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import com.bytel.spirit.common.connectors.gdr.structs.enumeration.EtatSMDP;
import com.bytel.spirit.common.connectors.gdr.structs.enumeration.EtatSim;
import com.bytel.spirit.common.connectors.gdr.structs.enumeration.InstanceCliente;
import com.bytel.spirit.common.connectors.gdr.structs.enumeration.PolicyAction;
import com.bytel.spirit.common.connectors.gdr.structs.enumeration.PolicyQualification;
import com.bytel.spirit.common.connectors.gdr.structs.jsonadapter.DateFormatAdapter;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.annotations.SerializedName;

/**
 *
 * @author dangelis
 * @version ($Revision$ $Date$)
 */
// FIXME: FIX THE NAMES OF THE VARIABLES, EQUALS, ...
public class Sim implements Serializable
{
  private static final long serialVersionUID = 5262846192100853491L;

  /** idtsim */
  private transient Long _idtsim;

  /** idthlr */
  private transient Long _idthlr;

  /** idtcmd */
  private transient Long _idtcmd;

  /** etasim */
  @SerializedName("etatSim")
  @Expose
  private EtatSim _etasim;

  /** idtacnsim */
  private transient Long _idtacnsim;

  /** dateta */
  @SerializedName("dateEtat")
  @Expose
  @JsonAdapter(DateFormatAdapter.class)
  private Date _dateta;

  /** sim */
  @SerializedName("iccid")
  @Expose
  private String _sim;

  /** ims */
  @SerializedName("imsi")
  @Expose
  private String _ims;

  /** pin */
  @SerializedName("codePin1")
  @Expose
  private Long _pin;

  /** pin002 */
  @SerializedName("codePin2")
  @Expose
  private Long _pin002;

  /** puk */
  @SerializedName("codePuk1")
  @Expose
  private Long _puk;

  /** puk002 */
  @SerializedName("codePuk2")
  @Expose
  private Long _puk002;

  /** cleki */
  private transient String _cleki;

  /** codam */
  private transient String _codam;

  /** typsim */
  @SerializedName("typeSim")
  @Expose
  private Long _typsim;

  /** etacom */
  private transient String _etacom;

  /** etaprt */
  private transient String _etaprt;

  /** idtdermod */
  private transient String _idtdermod;

  /** cleota */
  private transient String _cleota;

  /** instanceCliente */
  @SerializedName("instanceCliente")
  @Expose
  private InstanceCliente _instanceCliente;

  /** etatSmdp */
  @SerializedName("etatPfsEsim")
  @Expose
  private EtatSMDP _etasmdp;

  /** etatNotif */
  @SerializedName("etatNotifPfsEsim")
  @Expose
  private String _etanotif;

  /** profilElectrique */
  @SerializedName("profilElectrique")
  @Expose
  private String _profilElectrique;

  /** typeProfile */
  @SerializedName("typeProfile")
  @Expose
  private String _typeProfile;

  /** eid */
  @SerializedName("eid")
  @Expose
  private String _eid;

  /** smsrId */
  @SerializedName("smsrId")
  @Expose
  private String _smsrId;

  /** Activable */
  @SerializedName("activable")
  @Expose
  private String _activable;

  /** typageReseau */
  @SerializedName("typageReseau")
  @Expose
  private String _typageReseau;

  /** policies */
  @SerializedName("policies")
  @Expose
  private Policy _policies;

  /**
   *
   */
  public Sim()
  {
    super();
    // TODO Auto-generated constructor stub
  }

  /**
   * @param idtsim_p
   *          idtsim
   * @param idthlr_p
   *          idthlr
   * @param idtcmd_p
   *          idtcmd
   * @param etasim_p
   *          etasim
   * @param idtacnsim_p
   *          idtacnsim
   * @param dateta_p
   *          dateta
   * @param sim_p
   *          sim
   * @param ims_p
   *          ims
   * @param pin_p
   *          pin
   * @param pin002_p
   *          pin002
   * @param puk_p
   *          puk
   * @param puk002_p
   *          puk002
   * @param cleki_p
   *          cleki
   * @param codam_p
   *          codam
   * @param typsim_p
   *          typsim
   * @param etacom_p
   *          etacom
   * @param etaprt_p
   *          etaprt
   * @param idtdermod_p
   *          idtdermod
   * @param cleota_p
   *          cleota
   */
  public Sim(Long idtsim_p, Long idthlr_p, Long idtcmd_p, EtatSim etasim_p, Long idtacnsim_p, Date dateta_p, String sim_p, String ims_p, Long pin_p, Long pin002_p, Long puk_p, Long puk002_p, String cleki_p, String codam_p, Long typsim_p, String etacom_p, String etaprt_p, String idtdermod_p, String cleota_p)
  {
    super();
    this._idtsim = idtsim_p;
    this._idthlr = idthlr_p;
    this._idtcmd = idtcmd_p;
    this._etasim = etasim_p;
    this._idtacnsim = idtacnsim_p;

    if (dateta_p != null)
    {
      this._dateta = (Date) dateta_p.clone();
    }

    this._sim = sim_p;
    this._ims = ims_p;
    this._pin = pin_p;
    this._pin002 = pin002_p;
    this._puk = puk_p;
    this._puk002 = puk002_p;
    this._cleki = cleki_p;
    this._codam = codam_p;
    this._typsim = typsim_p;
    this._etacom = etacom_p;
    this._etaprt = etaprt_p;
    this._idtdermod = idtdermod_p;
    this._cleota = cleota_p;
  }

  /**
   * @param idtsim_p
   *          idtsim
   * @param idthlr_p
   *          idthlr
   * @param idtcmd_p
   *          idtcmd
   * @param etasim_p
   *          etasim
   * @param idtacnsim_p
   *          idtacnsim
   * @param dateta_p
   *          dateta
   * @param sim_p
   *          sim
   * @param ims_p
   *          ims
   * @param pin_p
   *          pin
   * @param pin002_p
   *          pin002
   * @param puk_p
   *          puk
   * @param puk002_p
   *          puk002
   * @param cleki_p
   *          cleki
   * @param codam_p
   *          codam
   * @param typsim_p
   *          typsim
   * @param etacom_p
   *          etacom
   * @param etaprt_p
   *          etaprt
   * @param idtdermod_p
   *          idtdermod
   * @param cleota_p
   *          cleota
   * @param instanceCliente_p
   *          instanceCliente
   * @param etasmdp_p
   *          etasmdp
   * @param etanotif_p
   *          etanotif
   * @param profilElectrique_p
   *          profilElectrique
   * @param typeProfile_p
   *          typeProfile
   * @param eid_p
   *          eid
   * @param smsrId_p
   *          smsrId
   * @param policies_p
   *          policies
   * @param activable_p
   *          activable
   * @param typageReseau_p
   *          typageReseau
   */
  public Sim(Long idtsim_p, Long idthlr_p, Long idtcmd_p, EtatSim etasim_p, Long idtacnsim_p, Date dateta_p, String sim_p, String ims_p, Long pin_p, Long pin002_p, Long puk_p, Long puk002_p, String cleki_p, String codam_p, Long typsim_p, String etacom_p, String etaprt_p, String idtdermod_p, String cleota_p, InstanceCliente instanceCliente_p, EtatSMDP etasmdp_p, String etanotif_p, String profilElectrique_p, String typeProfile_p, String eid_p, String smsrId_p, Policy policies_p, String activable_p, String typageReseau_p)
  {
    this._idtsim = idtsim_p;
    this._idthlr = idthlr_p;
    this._idtcmd = idtcmd_p;
    this._etasim = etasim_p;
    this._idtacnsim = idtacnsim_p;
    if (dateta_p != null)
    {
      this._dateta = (Date) dateta_p.clone();
    }
    this._sim = sim_p;
    this._ims = ims_p;
    this._pin = pin_p;
    this._pin002 = pin002_p;
    this._puk = puk_p;
    this._puk002 = puk002_p;
    this._cleki = cleki_p;
    this._codam = codam_p;
    this._typsim = typsim_p;
    this._etacom = etacom_p;
    this._etaprt = etaprt_p;
    this._idtdermod = idtdermod_p;
    this._cleota = cleota_p;
    this._instanceCliente = instanceCliente_p;
    this._etasmdp = etasmdp_p;
    this._etanotif = etanotif_p;
    this._profilElectrique = profilElectrique_p;
    this._typeProfile = typeProfile_p;
    this._eid = eid_p;
    this._smsrId = smsrId_p;
    this._policies = policies_p;
    this._activable = activable_p;
    this._typageReseau = typageReseau_p;
  }

  /**
   * @param rs_p
   *          rs
   * @throws SQLException
   *           exception
   */
  public Sim(ResultSet rs_p) throws SQLException
  {
    this._idtsim = rs_p.getLong("IDTSIM"); //$NON-NLS-1$
    this._idthlr = rs_p.getLong("IDTHLR"); //$NON-NLS-1$
    this._idtcmd = rs_p.getLong("IDTCMD"); //$NON-NLS-1$
    this._etasim = EtatSim.fromString(rs_p.getString("ETASIM")); //$NON-NLS-1$
    this._etasmdp = EtatSMDP.fromString(rs_p.getString("ETASMDP")); //$NON-NLS-1$
    this._etanotif = rs_p.getString("ETANOTIF"); //$NON-NLS-1$
    this._idtacnsim = rs_p.getLong("IDTACNSIM"); //$NON-NLS-1$
    this._dateta = rs_p.getTimestamp("DATETA"); //$NON-NLS-1$
    this._sim = rs_p.getString("SIM"); //$NON-NLS-1$
    this._ims = rs_p.getString("IMS"); //$NON-NLS-1$
    this._pin = rs_p.getLong("PIN"); //$NON-NLS-1$
    this._pin002 = rs_p.getLong("PIN002"); //$NON-NLS-1$
    this._puk = rs_p.getLong("PUK"); //$NON-NLS-1$
    this._puk002 = rs_p.getLong("PUK002"); //$NON-NLS-1$
    this._cleki = rs_p.getString("CLEKI_"); //$NON-NLS-1$
    this._codam = rs_p.getString("CODADM"); //$NON-NLS-1$
    this._typsim = rs_p.getLong("TYPSIM"); //$NON-NLS-1$
    this._etacom = rs_p.getString("ETACOM"); //$NON-NLS-1$
    this._etaprt = rs_p.getString("ETAPRT"); //$NON-NLS-1$
    this._idtdermod = rs_p.getString("IDTDERMOD"); //$NON-NLS-1$
    this._cleota = rs_p.getString("CLEOTA"); //$NON-NLS-1$
    this._eid = rs_p.getString("EID"); //$NON-NLS-1$

    PolicyAction action = PolicyAction.fromString(rs_p.getString("POLICYETAT")); //$NON-NLS-1$
    PolicyQualification qualification = PolicyQualification.fromString(rs_p.getString("POLICYHABILITATION")); //$NON-NLS-1$

    if (action != null || qualification != null)
    {
      this._policies = new Policy();
      this._policies.setAction(action);
      this._policies.setQualification(qualification);
    }

    this._smsrId = rs_p.getString("SMSRID"); //$NON-NLS-1$
  }

  @Override
  public boolean equals(Object o)
  {
    if (this == o)
    {
      return true;
    }
    if (o == null)
    {
      return false;
    }
    if (getClass() != o.getClass())
    {
      return false;
    }
    Sim sim = (Sim) o;

    if (_idtsim != null ? !_idtsim.equals(sim._idtsim) : sim._idtsim != null)
    {
      return false;
    }
    if (_idthlr != null ? !_idthlr.equals(sim._idthlr) : sim._idthlr != null)
    {
      return false;
    }
    if (_idtcmd != null ? !_idtcmd.equals(sim._idtcmd) : sim._idtcmd != null)
    {
      return false;
    }
    if (_etasim != sim._etasim)
    {
      return false;
    }
    if (_idtacnsim != null ? !_idtacnsim.equals(sim._idtacnsim) : sim._idtacnsim != null)
    {
      return false;
    }
    if (_dateta != null ? !_dateta.equals(sim._dateta) : sim._dateta != null)
    {
      return false;
    }
    if (_sim != null ? !_sim.equals(sim._sim) : sim._sim != null)
    {
      return false;
    }
    if (_ims != null ? !_ims.equals(sim._ims) : sim._ims != null)
    {
      return false;
    }
    if (_pin != null ? !_pin.equals(sim._pin) : sim._pin != null)
    {
      return false;
    }
    if (_pin002 != null ? !_pin002.equals(sim._pin002) : sim._pin002 != null)
    {
      return false;
    }
    if (_puk != null ? !_puk.equals(sim._puk) : sim._puk != null)
    {
      return false;
    }
    if (_puk002 != null ? !_puk002.equals(sim._puk002) : sim._puk002 != null)
    {
      return false;
    }
    if (_cleki != null ? !_cleki.equals(sim._cleki) : sim._cleki != null)
    {
      return false;
    }
    if (_codam != null ? !_codam.equals(sim._codam) : sim._codam != null)
    {
      return false;
    }
    if (_typsim != null ? !_typsim.equals(sim._typsim) : sim._typsim != null)
    {
      return false;
    }
    if (_etacom != null ? !_etacom.equals(sim._etacom) : sim._etacom != null)
    {
      return false;
    }
    if (_etaprt != null ? !_etaprt.equals(sim._etaprt) : sim._etaprt != null)
    {
      return false;
    }
    if (_idtdermod != null ? !_idtdermod.equals(sim._idtdermod) : sim._idtdermod != null)
    {
      return false;
    }
    if (_cleota != null ? !_cleota.equals(sim._cleota) : sim._cleota != null)
    {
      return false;
    }
    if (_instanceCliente != sim._instanceCliente)
    {
      return false;
    }
    if (_etasmdp != sim._etasmdp)
    {
      return false;
    }
    if (_etanotif != null ? !_etanotif.equals(sim._etanotif) : sim._etanotif != null)
    {
      return false;
    }
    if (_profilElectrique != null ? !_profilElectrique.equals(sim._profilElectrique) : sim._profilElectrique != null)
    {
      return false;
    }
    if (_typeProfile != null ? !_typeProfile.equals(sim._typeProfile) : sim._typeProfile != null)
    {
      return false;
    }
    if (_eid != null ? !_eid.equals(sim._eid) : sim._eid != null)
    {
      return false;
    }
    if (_smsrId != null ? !_smsrId.equals(sim._smsrId) : sim._smsrId != null)
    {
      return false;
    }
    if (_activable != null ? !_activable.equals(sim._activable) : sim._activable != null)
    {
      return false;
    }
    if (_typageReseau != null ? !_typageReseau.equals(sim._typageReseau) : sim._typageReseau != null)
    {
      return false;
    }
    return _policies != null ? _policies.equals(sim._policies) : sim._policies == null;
  }

  /**
   * @return _activable
   */
  public String getActivable()
  {
    return _activable;
  }

  /**
   * @return the cleki
   */
  public String getCleki()
  {
    return _cleki;
  }

  /**
   * @return the cleota
   */
  public String getCleota()
  {
    return _cleota;
  }

  /**
   * @return the codam
   */
  public String getCodam()
  {
    return _codam;
  }

  /**
   * @return the dateta
   */
  public Date getDateta()
  {
    if (_dateta != null)
    {
      return (Date) _dateta.clone();
    }

    return null;
  }

  /**
   * @return _eid
   */
  public String getEid()
  {
    return _eid;
  }

  /**
   * @return the etacom
   */
  public String getEtacom()
  {
    return _etacom;
  }

  /**
   * @return _etanotif
   */
  public String getEtanotif()
  {
    return _etanotif;
  }

  /**
   * @return the etaprt
   */
  public String getEtaprt()
  {
    return _etaprt;
  }

  /**
   * @return the etasim
   */
  public EtatSim getEtasim()
  {
    return _etasim;
  }

  /**
   * @return _etasmdp
   */
  public EtatSMDP getEtasmdp()
  {
    return _etasmdp;
  }

  /**
   * @return the idtacnsim
   */
  public Long getIdtacnsim()
  {
    return _idtacnsim;
  }

  /**
   * @return the idtcmd
   */
  public Long getIdtcmd()
  {
    return _idtcmd;
  }

  /**
   * @return the idtdermod
   */
  public String getIdtdermod()
  {
    return _idtdermod;
  }

  /**
   * @return the idthlr
   */
  public Long getIdthlr()
  {
    return _idthlr;
  }

  /**
   * @return the idtsim
   */
  public Long getIdtsim()
  {
    return _idtsim;
  }

  /**
   * @return the ims
   */
  public String getIms()
  {
    return _ims;
  }

  /**
   * @return _instanceCliente
   */
  public InstanceCliente getInstanceCliente()
  {
    return _instanceCliente;
  }

  /**
   * @return the pin
   */
  public Long getPin()
  {
    return _pin;
  }

  /**
   * @return the pin002
   */
  public Long getPin002()
  {
    return _pin002;
  }

  /**
   * @return _policies
   */
  public Policy getPolicies()
  {
    return _policies;
  }

  /**
   * @return _profilElectrique
   */
  public String getProfilElectrique()
  {
    return _profilElectrique;
  }

  /**
   * @return the puk
   */
  public Long getPuk()
  {
    return _puk;
  }

  /**
   * @return the puk002
   */
  public Long getPuk002()
  {
    return _puk002;
  }

  /**
   * @return the sim
   */
  public String getSim()
  {
    return _sim;
  }

  /**
   * @return _smsrId
   */
  public String getSmsrId()
  {
    return _smsrId;
  }

  /**
   * @return the typageReseau
   */
  public String getTypageReseau()
  {
    return _typageReseau;
  }

  /**
   * @return _typeProfile
   */
  public String getTypeProfile()
  {
    return _typeProfile;
  }

  /**
   * @return the typsim
   */
  public Long getTypsim()
  {
    return _typsim;
  }

  @Override
  public int hashCode()
  {
    int result = _idtsim != null ? _idtsim.hashCode() : 0;
    result = (31 * result) + (_idthlr != null ? _idthlr.hashCode() : 0);
    result = (31 * result) + (_idtcmd != null ? _idtcmd.hashCode() : 0);
    result = (31 * result) + (_etasim != null ? _etasim.hashCode() : 0);
    result = (31 * result) + (_idtacnsim != null ? _idtacnsim.hashCode() : 0);
    result = (31 * result) + (_dateta != null ? _dateta.hashCode() : 0);
    result = (31 * result) + (_sim != null ? _sim.hashCode() : 0);
    result = (31 * result) + (_ims != null ? _ims.hashCode() : 0);
    result = (31 * result) + (_pin != null ? _pin.hashCode() : 0);
    result = (31 * result) + (_pin002 != null ? _pin002.hashCode() : 0);
    result = (31 * result) + (_puk != null ? _puk.hashCode() : 0);
    result = (31 * result) + (_puk002 != null ? _puk002.hashCode() : 0);
    result = (31 * result) + (_cleki != null ? _cleki.hashCode() : 0);
    result = (31 * result) + (_codam != null ? _codam.hashCode() : 0);
    result = (31 * result) + (_typsim != null ? _typsim.hashCode() : 0);
    result = (31 * result) + (_etacom != null ? _etacom.hashCode() : 0);
    result = (31 * result) + (_etaprt != null ? _etaprt.hashCode() : 0);
    result = (31 * result) + (_idtdermod != null ? _idtdermod.hashCode() : 0);
    result = (31 * result) + (_cleota != null ? _cleota.hashCode() : 0);
    result = (31 * result) + (_instanceCliente != null ? _instanceCliente.hashCode() : 0);
    result = (31 * result) + (_etasmdp != null ? _etasmdp.hashCode() : 0);
    result = (31 * result) + (_etanotif != null ? _etanotif.hashCode() : 0);
    result = (31 * result) + (_profilElectrique != null ? _profilElectrique.hashCode() : 0);
    result = (31 * result) + (_typeProfile != null ? _typeProfile.hashCode() : 0);
    result = (31 * result) + (_eid != null ? _eid.hashCode() : 0);
    result = (31 * result) + (_smsrId != null ? _smsrId.hashCode() : 0);
    result = (31 * result) + (_activable != null ? _activable.hashCode() : 0);
    result = (31 * result) + (_typageReseau != null ? _typageReseau.hashCode() : 0);
    result = (31 * result) + (_policies != null ? _policies.hashCode() : 0);
    return result;
  }

  /**
   * @param activable_p
   *          _activable
   */
  public void setActivable(String activable_p)
  {
    _activable = activable_p;
  }

  /**
   * @param cleki_p
   *          the cleki to set
   */
  public void setCleki(String cleki_p)
  {
    _cleki = cleki_p;
  }

  /**
   * @param cleota_p
   *          the cleota to set
   */
  public void setCleota(String cleota_p)
  {
    _cleota = cleota_p;
  }

  /**
   * @param codam_p
   *          the codam to set
   */
  public void setCodam(String codam_p)
  {
    _codam = codam_p;
  }

  /**
   * @param dateta_p
   *          the dateta to set
   */
  public void setDateta(Date dateta_p)
  {
    if (dateta_p != null)
    {
      _dateta = (Date) dateta_p.clone();
    }
  }

  /**
   * @param eid_p
   *          _eid
   */
  public void setEid(String eid_p)
  {
    _eid = eid_p;
  }

  /**
   * @param etacom_p
   *          the etacom to set
   */
  public void setEtacom(String etacom_p)
  {
    _etacom = etacom_p;
  }

  /**
   * @param etanotif_p
   *          _etanotif
   */
  public void setEtanotif(String etanotif_p)
  {
    _etanotif = etanotif_p;
  }

  /**
   * @param etaprt_p
   *          the etaprt to set
   */
  public void setEtaprt(String etaprt_p)
  {
    _etaprt = etaprt_p;
  }

  /**
   * @param etasim_p
   *          the etasim to set
   */
  public void setEtasim(EtatSim etasim_p)
  {
    _etasim = etasim_p;
  }

  /**
   * @param etasmdp_p
   *          _etasmdp
   */
  public void setEtasmdp(EtatSMDP etasmdp_p)
  {
    _etasmdp = etasmdp_p;
  }

  /**
   * @param idtacnsim_p
   *          the idtacnsim to set
   */
  public void setIdtacnsim(Long idtacnsim_p)
  {
    _idtacnsim = idtacnsim_p;
  }

  /**
   * @param idtcmd_p
   *          the idtcmd to set
   */
  public void setIdtcmd(Long idtcmd_p)
  {
    _idtcmd = idtcmd_p;
  }

  /**
   * @param idtdermod_p
   *          the idtdermod to set
   */
  public void setIdtdermod(String idtdermod_p)
  {
    _idtdermod = idtdermod_p;
  }

  /**
   * @param idthlr_p
   *          the idthlr to set
   */
  public void setIdthlr(Long idthlr_p)
  {
    _idthlr = idthlr_p;
  }

  /**
   * @param idtsim_p
   *          the idtsim to set
   */
  public void setIdtsim(Long idtsim_p)
  {
    _idtsim = idtsim_p;
  }

  /**
   * @param ims_p
   *          the ims to set
   */
  public void setIms(String ims_p)
  {
    _ims = ims_p;
  }

  /**
   * @param instanceCliente_p
   *          _instanceCliente
   */
  public void setInstanceCliente(InstanceCliente instanceCliente_p)
  {
    _instanceCliente = instanceCliente_p;
  }

  /**
   * @param pin_p
   *          the pin to set
   */
  public void setPin(Long pin_p)
  {
    _pin = pin_p;
  }

  /**
   * @param pin002_p
   *          the pin002 to set
   */
  public void setPin002(Long pin002_p)
  {
    _pin002 = pin002_p;
  }

  /**
   * @param policies_p
   *          _policies
   */
  public void setPolicies(Policy policies_p)
  {
    _policies = policies_p;
  }

  /**
   * @param profilElectrique_p
   *          _profilElectrique
   */
  public void setProfilElectrique(String profilElectrique_p)
  {
    _profilElectrique = profilElectrique_p;
  }

  /**
   * @param puk_p
   *          the puk to set
   */
  public void setPuk(Long puk_p)
  {
    _puk = puk_p;
  }

  /**
   * @param puk002_p
   *          the puk002 to set
   */
  public void setPuk002(Long puk002_p)
  {
    _puk002 = puk002_p;
  }

  /**
   * @param sim_p
   *          the sim to set
   */
  public void setSim(String sim_p)
  {
    _sim = sim_p;
  }

  /**
   * @param smsrId_p
   *          _smsrId
   */
  public void setSmsrId(String smsrId_p)
  {
    _smsrId = smsrId_p;
  }

  /**
   * @param typageReseau_p
   *          the typageReseau to set
   */
  public void setTypageReseau(String typageReseau_p)
  {
    _typageReseau = typageReseau_p;
  }

  /**
   * @param typeProfile_p
   *          _typeProfile
   */
  public void setTypeProfile(String typeProfile_p)
  {
    _typeProfile = typeProfile_p;
  }

  /**
   * @param typsim_p
   *          the typsim to set
   */
  public void setTypsim(Long typsim_p)
  {
    _typsim = typsim_p;
  }

  @Override
  public String toString()
  {
    final StringBuffer sb = new StringBuffer("Sim ["); //$NON-NLS-1$
    sb.append("_idtsim=").append(_idtsim); //$NON-NLS-1$
    sb.append(", _idthlr=").append(_idthlr); //$NON-NLS-1$
    sb.append(", _idtcmd=").append(_idtcmd); //$NON-NLS-1$
    sb.append(", _etasim=").append(_etasim); //$NON-NLS-1$
    sb.append(", _idtacnsim=").append(_idtacnsim); //$NON-NLS-1$
    sb.append(", _dateta=").append(_dateta); //$NON-NLS-1$
    sb.append(", _sim='").append(_sim).append('\''); //$NON-NLS-1$
    sb.append(", _ims='").append(_ims).append('\''); //$NON-NLS-1$
    sb.append(", _pin=").append(_pin); //$NON-NLS-1$
    sb.append(", _pin002=").append(_pin002); //$NON-NLS-1$
    sb.append(", _puk=").append(_puk); //$NON-NLS-1$
    sb.append(", _puk002=").append(_puk002); //$NON-NLS-1$
    sb.append(", _cleki='").append(_cleki).append('\''); //$NON-NLS-1$
    sb.append(", _codam='").append(_codam).append('\''); //$NON-NLS-1$
    sb.append(", _typsim=").append(_typsim); //$NON-NLS-1$
    sb.append(", _etacom='").append(_etacom).append('\''); //$NON-NLS-1$
    sb.append(", _etaprt='").append(_etaprt).append('\''); //$NON-NLS-1$
    sb.append(", _idtdermod='").append(_idtdermod).append('\''); //$NON-NLS-1$
    sb.append(", _cleota='").append(_cleota).append('\''); //$NON-NLS-1$
    sb.append(", _instanceCliente=").append(_instanceCliente); //$NON-NLS-1$
    sb.append(", _etasmdp=").append(_etasmdp); //$NON-NLS-1$
    sb.append(", _etanotif='").append(_etanotif).append('\''); //$NON-NLS-1$
    sb.append(", _profilElectrique='").append(_profilElectrique).append('\''); //$NON-NLS-1$
    sb.append(", _typeProfile='").append(_typeProfile).append('\''); //$NON-NLS-1$
    sb.append(", _eid='").append(_eid).append('\''); //$NON-NLS-1$
    sb.append(", _smsrId='").append(_smsrId).append('\''); //$NON-NLS-1$
    sb.append(", _activable='").append(_activable).append('\''); //$NON-NLS-1$
    sb.append(", _typageReseau='").append(_typageReseau).append('\''); //$NON-NLS-1$
    sb.append(", _policies=").append(_policies); //$NON-NLS-1$
    sb.append(']');
    return sb.toString();
  }
}
