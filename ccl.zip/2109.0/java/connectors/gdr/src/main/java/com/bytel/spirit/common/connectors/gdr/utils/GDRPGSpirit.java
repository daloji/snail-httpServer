/*******************************************************************************
* $Id: GDRPGSpirit.java 50527 2021-04-13 08:41:26Z jpais $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.gdr.utils;

import static com.bytel.spirit.common.connectors.gdr.utils.GDRConnectorConstants.CONNEXION_FAILED;
import static com.bytel.spirit.common.connectors.gdr.utils.GDRConnectorConstants.INSERTION_FAILED;
import static com.bytel.spirit.common.connectors.gdr.utils.GDRConnectorConstants.PO_RESULT;
import static com.bytel.spirit.common.connectors.gdr.utils.GDRConnectorConstants.RETOUR_CATEGORIE;
import static com.bytel.spirit.common.connectors.gdr.utils.GDRConnectorConstants.RETOUR_DIAGNOSTIC;
import static com.bytel.spirit.common.connectors.gdr.utils.GDRConnectorConstants.RETOUR_LIBELLE;
import static com.bytel.spirit.common.connectors.gdr.utils.GDRConnectorConstants.RETOUR_RESULTAT;
import static com.bytel.spirit.common.connectors.gdr.utils.GDRConnectorConstants.SELECT_FAILED;
import static com.bytel.spirit.common.connectors.gdr.utils.GDRConnectorConstants.SESSION_UNAVAILABLE;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLRecoverableException;
import java.sql.SQLTimeoutException;
import java.sql.Timestamp;
import java.text.MessageFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import com.bytel.spirit.common.connectors.gdr.structs.Policy;
import com.bytel.spirit.common.connectors.gdr.structs.enumeration.EtatSMDP;
import com.bytel.spirit.common.connectors.gdr.structs.enumeration.PolicyAction;
import com.bytel.spirit.common.connectors.gdr.structs.enumeration.PolicyQualification;
import org.apache.tomcat.jdbc.pool.DataSource;
import org.apache.tomcat.jdbc.pool.PoolExhaustedException;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.DateTimeTools;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.connectors.gdr.Messages;
import com.bytel.spirit.common.connectors.gdr.structs.BYTPRD;
import com.bytel.spirit.common.connectors.gdr.structs.CMDSIM;
import com.bytel.spirit.common.connectors.gdr.structs.ErreurSMDP;
import com.bytel.spirit.common.connectors.gdr.structs.HISETASIM;
import com.bytel.spirit.common.connectors.gdr.structs.ICallbackLireSim;
import com.bytel.spirit.common.connectors.gdr.structs.PRF;
import com.bytel.spirit.common.connectors.gdr.structs.SUIVISMDP;
import com.bytel.spirit.common.connectors.gdr.structs.Sim;
import com.bytel.spirit.common.connectors.gdr.structs.StatistiqueEsim;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

import oracle.jdbc.OracleConnection;
import oracle.jdbc.OracleTypes;
import oracle.sql.ARRAY;
import oracle.sql.ArrayDescriptor;

/**
 *
 * @author lmerces
 * @version ($Revision: 50527 $ $Date: 2021-04-13 10:41:26 +0200 (mar. 13 avril 2021) $)
 */
public class GDRPGSpirit extends GDRConnectorUtils
{
  /**
   * Datasource
   */
  private DataSource _datasource;

  /**
   * ArrayDescriptorFactory
   */
  private ArrayDescriptorFactory _arrayDescriptionFactory;

  /**
   * Read timeout in seconds
   */
  private int _readTimeoutSec;

  /**
   * Connect timeout in seconds
   */
  private int _connectTimeoutSec;

  /**
   * @param datasource_p
   *          datasource
   * @param readTimeoutSec_p
   *          readTimeoutSec
   * @param connectTimeoutSec_p
   *          connectTimeoutSec
   * @param factory_p
   *          arrayDescriptionFactory
   */
  public GDRPGSpirit(DataSource datasource_p, int readTimeoutSec_p, int connectTimeoutSec_p, ArrayDescriptorFactory factory_p)
  {
    super();
    _datasource = datasource_p;
    _readTimeoutSec = readTimeoutSec_p;
    _connectTimeoutSec = connectTimeoutSec_p;
    _arrayDescriptionFactory = factory_p;
  }

  /**
   * Invocation of the stored procedure PG_SPIRIT.P_COMPTERETATESIM.
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param peConsumer_p
   *          the peConsumer
   * @param peM2M_p
   *          the peM2M
   * @return {@link ConnectorResponse}
   * @throws RavelException
   *           exception
   */
  public ConnectorResponse<Nothing, Retour> compterEtatESim(Tracabilite tracabilite_p, List<Integer> peConsumer_p, List<Integer> peM2M_p) throws RavelException
  {
    final String methodName = "PG_SPIRIT.P_COMPTERETATESIM"; //$NON-NLS-1$

    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall("{call PG_SPIRIT.P_COMPTERETATESIM(?,?,?,?,?,?) }")) //$NON-NLS-1$
    {
      cs.setQueryTimeout(_readTimeoutSec);

      OracleConnection oracleConnection = con.unwrap(oracle.jdbc.OracleConnection.class);
      ArrayDescriptor arrayDescriptor = _arrayDescriptionFactory.makeArrayDescriptor("TABLE_NUMBER", oracleConnection); //$NON-NLS-1$
      ARRAY arrayConsumer = _arrayDescriptionFactory.createARRAY(arrayDescriptor, oracleConnection, peConsumer_p.toArray());
      ARRAY arrayM2M = _arrayDescriptionFactory.createARRAY(arrayDescriptor, oracleConnection, peM2M_p.toArray());

      cs.setObject("pi_GencodPE_Consumer", arrayConsumer); //$NON-NLS-1$
      cs.setObject("pi_GencodPE_M2M", arrayM2M); //$NON-NLS-1$

      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();

      Retour retour = getRetour(cs);
      SpiritLogEvent outputLog = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, methodName);

      outputLog.addField("Retour", retour, false); //$NON-NLS-1$
      RavelLogger.log(outputLog);

      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("PECONSUMER:").append(peConsumer_p).append("PEM2M:").append(peM2M_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("PECONSUMER:").append(peConsumer_p).append("PEM2M:").append(peM2M_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("GDRConnector.ERREUR_GDR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("PECONSUMER:").append(peConsumer_p).append("PEM2M:").append(peM2M_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("PECONSUMER:").append(peConsumer_p).append("PEM2M:").append(peM2M_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$
    }
    return null;
  }

  /**
   *
   * @param tracabilite_p
   *          tracabilite
   * @param iccid_p
   *          iccid
   * @return ConnectorResponse<List<ErreurSMDP>, Retour>
   * @throws RavelException
   *           on exception
   */
  public ConnectorResponse<List<ErreurSMDP>, Retour> getErreurSmdpByIccid(Tracabilite tracabilite_p, String iccid_p) throws RavelException
  {
    final String methodName = "PG_SPIRIT.P_GET_ERREURSMDP_BY_ICCID"; //$NON-NLS-1$

    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall(String.format("{call %s(?,?,?,?,?,?) }", methodName))) //$NON-NLS-1$
    {
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("pi_iccid", iccid_p); //$NON-NLS-1$

      cs.registerOutParameter(PO_RESULT, OracleTypes.CURSOR);
      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();

      Retour retour = getRetour(cs);
      List<ErreurSMDP> erreurSMDPList = new ArrayList<>();
      ResultSet rs = (ResultSet) cs.getObject(PO_RESULT);

      if (StringConstants.OK.equals(retour.getResultat()) && (rs != null))
      {
        while (rs.next())
        {
          erreurSMDPList.add(new ErreurSMDP(rs));
        }
      }

      SpiritLogEvent outputLog = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, methodName);
      outputLog.addField("Retour", retour, false); //$NON-NLS-1$
      RavelLogger.log(outputLog);
      return new ConnectorResponse<>(erreurSMDPList, retour);
    }

    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("ICCID:").append(iccid_p) //$NON-NLS-1$
          .toString());
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("ICCID:").append(iccid_p) //$NON-NLS-1$
          .toString());
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("GDRConnector.ERREUR_GDR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("ICCID:").append(iccid_p) //$NON-NLS-1$
          .toString());
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append("ICCID:").append(iccid_p) //$NON-NLS-1$
          .toString());
    }
  }

  /**
   * Get a list of profiles eSim from GDR.
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param typeSim_p
   *          the type of Sim.
   * @param profileType_p
   *          the type of profile.
   * @param callback_p
   *          the callback.
   * @param listSize_p
   *          the size of the list returned by the callback.
   * @return a pair with Nothing and the Retour. (Needs to be a pair)
   * @throws RavelException
   *           on error.
   */
  public ConnectorResponse<Nothing, Retour> getEsimProfileStatus(Tracabilite tracabilite_p, String typeSim_p, String profileType_p, ICallbackLireSim callback_p, int listSize_p) throws RavelException
  {
    final String inputs = "typeSim:" + typeSim_p //$NON-NLS-1$
        + "profileType:" + profileType_p; //$NON-NLS-1$

    final String methodName = "PG_SPIRIT.P_GET_ESIM_PROFIL_STATUS"; //$NON-NLS-1$

    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall(String.format("{call %s(?,?,?,?,?,?,?)}", methodName))) //$NON-NLS-1$
    {
      // Set the parameters and call the procedure
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("pi_typeSim", typeSim_p); //$NON-NLS-1$
      cs.setString("pi_profileType", profileType_p); //$NON-NLS-1$
      cs.registerOutParameter(PO_RESULT, OracleTypes.CURSOR);
      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();

      Retour retour = getRetour(cs);

      // Log the retour from the procedure
      SpiritLogEvent outputLog = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, methodName);
      outputLog.addField("Retour", retour, false); //$NON-NLS-1$
      RavelLogger.log(outputLog);

      // When successful, build the lists of sims
      if (RetourFactory.isRetourOK(retour))
      {
        ResultSet rs = (ResultSet) cs.getObject(PO_RESULT);

        List<Sim> simList = new ArrayList<>();

        while (rs.next())
        {
          // Create a Sim
          Sim sim = new Sim();
          sim.setSim(rs.getString("ICCID")); //$NON-NLS-1$
          sim.setTypeProfile(rs.getString("PROFILE_TYPE")); //$NON-NLS-1$
          sim.setEtasmdp(EtatSMDP.fromString(rs.getString("ETAT_PROFIL"))); //$NON-NLS-1$
          sim.setEtanotif(rs.getString("ETAT_NOTIF")); //$NON-NLS-1$
          sim.setDateta(rs.getTimestamp("DATETA")); //$NON-NLS-1$
          sim.setEid(rs.getString("EID")); //$NON-NLS-1$

          String policyEtat = rs.getString("POLICYETAT"); //$NON-NLS-1$
          String policyHabilitation = rs.getString("POLICYHABILITATION"); //$NON-NLS-1$

          sim.setPolicies(new Policy(null, PolicyAction.fromString(policyEtat), PolicyQualification.fromString(policyHabilitation)));

          simList.add(sim);

          // Send the list to the callback
          if (simList.size() == listSize_p)
          {
            retour = callback_p.consume(tracabilite_p, simList);

            if (RetourFactory.isRetourNOK(retour))
            {
              // TODO: CONNECTOR_RESPONSE
              return new ConnectorResponse<>(null, retour);
            }

            simList.clear();
          }
        }

        // The last case, because the list might not get full
        if (!simList.isEmpty())
        {
          retour = callback_p.consume(tracabilite_p, simList);

          if (RetourFactory.isRetourNOK(retour))
          {
            return new ConnectorResponse<>(null, retour);
          }
        }
      }

      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, inputs);
      Retour retour = RetourFactory.createNOK(IMegConsts.CAT1, INSERTION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, inputs);
      Retour retour = RetourFactory.createNOK(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("GDRConnector.ERREUR_GDR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, inputs);
      Retour retour = RetourFactory.createNOK(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, inputs);
    }
  }

  /**
   * @return the factory
   */
  public ArrayDescriptorFactory getFactory()
  {
    return _arrayDescriptionFactory;
  }

  /**
   * @param tracabilite_p
   *          the tracabilite_p
   * @param idtSim_p
   *          the idtSim
   * @return {@link ConnectorResponse}
   * @throws RavelException
   *           exception
   */
  public ConnectorResponse<List<HISETASIM>, Retour> getHisetaSimByIdtSim(Tracabilite tracabilite_p, String idtSim_p) throws RavelException
  {
    final String methodName = "PG_SPIRIT.P_GET_HISETASIM_BY_IDTSIM"; //$NON-NLS-1$

    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall(String.format("{call %s(?,?,?,?,?,?) }", methodName))) //$NON-NLS-1$
    {
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("pi_idtsim", idtSim_p); //$NON-NLS-1$

      cs.registerOutParameter(PO_RESULT, OracleTypes.CURSOR);
      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();

      Retour retour = getRetour(cs);
      List<HISETASIM> hisetasimList = new ArrayList<>();
      ResultSet rs = (ResultSet) cs.getObject(PO_RESULT);

      if (StringConstants.OK.equals(retour.getResultat()) && (rs != null))
      {
        while (rs.next())
        {
          hisetasimList.add(new HISETASIM(rs));
        }

        if (!hisetasimList.isEmpty())
        {
          hisetasimList.sort(Comparator.comparing(HISETASIM::getDateChangementEtatPlateforme));
        }
      }

      SpiritLogEvent outputLog = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, methodName);
      outputLog.addField("Retour", retour, false); //$NON-NLS-1$
      RavelLogger.log(outputLog);
      return new ConnectorResponse<>(hisetasimList, retour);
    }

    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IDTSIM:").append(idtSim_p) //$NON-NLS-1$
          .toString());
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IDTSIM:").append(idtSim_p) //$NON-NLS-1$
          .toString());
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("GDRConnector.ERREUR_GDR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IDTSIM:").append(idtSim_p) //$NON-NLS-1$
          .toString());
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append("IDTSIM:").append(idtSim_p) //$NON-NLS-1$
          .toString());
    }
  }

  /**
   *
   * @param tracabilite_p
   * @param idtsim_p
   * @return ConnectorResponse<String, Retour>
   * @throws RavelException
   */
  public ConnectorResponse<String, Retour> getInstanceClienteSim(Tracabilite tracabilite_p, String idtsim_p) throws RavelException
  {
    final String methodName = "PG_SPIRIT.P_GET_INSTANCECLIENTE_SIM"; //$NON-NLS-1$

    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall(String.format("{call %s(?,?,?,?,?,?) }", methodName))) //$NON-NLS-1$
    {
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("pi_idtsim", idtsim_p); //$NON-NLS-1$

      cs.registerOutParameter("po_idtist", OracleTypes.VARCHAR); //$NON-NLS-1$
      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();

      Retour retour = getRetour(cs);
      String idtIST = cs.getString("po_idtist"); //$NON-NLS-1$

      SpiritLogEvent outputLog = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, methodName);
      outputLog.addField("Retour", retour, false); //$NON-NLS-1$
      RavelLogger.log(outputLog);
      return new ConnectorResponse<>(idtIST, retour);
    }

    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IDTSIM:").append(idtsim_p) //$NON-NLS-1$
          .toString());
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IDTSIM:").append(idtsim_p) //$NON-NLS-1$
          .toString());
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("GDRConnector.ERREUR_GDR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IDTSIM:").append(idtsim_p) //$NON-NLS-1$
          .toString());
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append("IDTSIM:").append(idtsim_p) //$NON-NLS-1$
          .toString());
    }
  }

  /**
   *
   * @param tracabilite_p
   * @param idtprf_p
   * @return ConnectorResponse<PRF, Retour>
   * @throws RavelException
   */
  public ConnectorResponse<PRF, Retour> getPRFByIdtPrf(Tracabilite tracabilite_p, String idtprf_p) throws RavelException
  {
    final String methodName = "PG_SPIRIT.P_GET_PRF_BY_IDTPRF"; //$NON-NLS-1$

    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall(String.format("{call %s(?,?,?,?,?,?) }", methodName))) //$NON-NLS-1$
    {
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("pi_idtprf", idtprf_p); //$NON-NLS-1$

      cs.registerOutParameter(PO_RESULT, OracleTypes.CURSOR);
      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();

      Retour retour = getRetour(cs);
      PRF prf = null;

      ResultSet rs = (ResultSet) cs.getObject(PO_RESULT);
      if (StringConstants.OK.equals(retour.getResultat()) && (rs != null) && rs.next())
      {
        prf = new PRF(rs);
      }
      SpiritLogEvent outputLog = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, methodName);
      outputLog.addField("Retour", retour, false); //$NON-NLS-1$
      RavelLogger.log(outputLog);
      return new ConnectorResponse<>(prf, retour);
    }

    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IDTPRF:").append(idtprf_p) //$NON-NLS-1$
          .toString());
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IDTPRF:").append(idtprf_p) //$NON-NLS-1$
          .toString());
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("GDRConnector.ERREUR_GDR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IDTPRF:").append(idtprf_p) //$NON-NLS-1$
          .toString());
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append("IDTPRF:").append(idtprf_p) //$NON-NLS-1$
          .toString());
    }
  }

  /**
   * Get Profil Electrique Par Identifiant
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param idtprf_p
   *          idtprf
   * @param typprf_p
   *          typprf
   * @return {@link ConnectorResponse}
   * @throws RavelException
   *           exception
   */
  public ConnectorResponse<String, Retour> getProfilElectriqueParIdentifiant(Tracabilite tracabilite_p, String idtprf_p, String typprf_p) throws RavelException
  {
    final String methodName = "PG_SPIRIT.P_GET_PE_IDTPRF_TYPPRF"; //$NON-NLS-1$
    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall("{call PG_SPIRIT.P_GET_PE_IDTPRF_TYPPRF(?,?,?,?,?,?,?) }")) //$NON-NLS-1$
    {
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("pi_IDTPRF", idtprf_p); //$NON-NLS-1$
      cs.setString("pi_TYPPRF", typprf_p); //$NON-NLS-1$
      cs.registerOutParameter("po_PE", OracleTypes.VARCHAR); //$NON-NLS-1$

      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();

      Retour retour = getRetour(cs);

      String poPE = cs.getString("po_PE"); //$NON-NLS-1$

      SpiritLogEvent outputLog = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, methodName);
      outputLog.addField("Retour", retour, false); //$NON-NLS-1$
      RavelLogger.log(outputLog);
      return new ConnectorResponse<>(poPE, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IDTPRF:").append(idtprf_p).append("TYPPRF:").append(typprf_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IDTPRF:").append(idtprf_p).append("TYPPRF:").append(typprf_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("GDRConnector.ERREUR_GDR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IDTPRF:").append(idtprf_p).append("TYPPRF:").append(typprf_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append("IDTPRF:").append(idtprf_p).append("TYPPRF:").append(typprf_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$
    }
  }

  /**
   *
   * @param tracabilite_p
   * @param typeSimANotifier_p
   * @param nbSimATraiter
   * @return ConnectorResponse<List<Sim>, Retour>
   * @throws RavelException
   */
  public ConnectorResponse<List<Sim>, Retour> getSIMDistribuables(Tracabilite tracabilite_p, List<Integer> typeSimANotifier_p, Integer nbSimATraiter_p) throws RavelException
  {
    final String methodName = "PG_SPIRIT.P_GET_SIM_DISTRIBUABLES"; //$NON-NLS-1$

    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall(String.format("{call %s(?,?,?,?,?,?,?) }", methodName))) //$NON-NLS-1$
    {
      cs.setQueryTimeout(_readTimeoutSec);

      OracleConnection oracleConnection = con.unwrap(oracle.jdbc.OracleConnection.class);
      ArrayDescriptor arrayDescriptor = _arrayDescriptionFactory.makeArrayDescriptor("TABLE_NUMBER", oracleConnection); //$NON-NLS-1$
      ARRAY arrayTypeSimANotifier = _arrayDescriptionFactory.createARRAY(arrayDescriptor, oracleConnection, typeSimANotifier_p.toArray());

      cs.setObject("pi_typeSimANotifier", arrayTypeSimANotifier); //$NON-NLS-1$
      cs.setInt("pi_nbSimATraiter", nbSimATraiter_p); //$NON-NLS-1$

      cs.registerOutParameter(PO_RESULT, OracleTypes.CURSOR);
      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();

      Retour retour = getRetour(cs);
      List<Sim> simList = new ArrayList<>();

      ResultSet rs = (ResultSet) cs.getObject(PO_RESULT);
      if (StringConstants.OK.equals(retour.getResultat()) && (rs != null))
      {
        while (rs.next())
        {
          simList.add(new Sim(rs));
        }
      }
      SpiritLogEvent outputLog = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, methodName);
      outputLog.addField("Retour", retour, false); //$NON-NLS-1$
      RavelLogger.log(outputLog);
      return new ConnectorResponse<>(simList, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("TypeSimANotifier:").append(typeSimANotifier_p).append("NbSimATraiter").append(nbSimATraiter_p) //$NON-NLS-1$ //$NON-NLS-2$
          .toString());
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("TypeSimANotifier:").append(typeSimANotifier_p).append("NbSimATraiter").append(nbSimATraiter_p) //$NON-NLS-1$ //$NON-NLS-2$
          .toString());
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("GDRConnector.ERREUR_GDR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("TypeSimANotifier:").append(typeSimANotifier_p).append("NbSimATraiter").append(nbSimATraiter_p) //$NON-NLS-1$ //$NON-NLS-2$
          .toString());
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append("TypeSimANotifier:").append(typeSimANotifier_p).append("NbSimATraiter").append(nbSimATraiter_p) //$NON-NLS-1$ //$NON-NLS-2$
          .toString());
    }
  }

  /**
   *
   * @param tracabilite_p
   * @param gnc_p
   * @return ConnectorResponse<List<Sim>, Retour>
   * @throws RavelException
   */
  public ConnectorResponse<List<Sim>, Retour> getSimByGnc(Tracabilite tracabilite_p, String gnc_p) throws RavelException
  {
    final String methodName = "PG_SPIRIT.P_GET_SIMS_BY_GNC"; //$NON-NLS-1$

    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall(String.format("{call %s(?,?,?,?,?,?) }", methodName))) //$NON-NLS-1$
    {
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("pi_GNC", gnc_p); //$NON-NLS-1$

      cs.registerOutParameter(PO_RESULT, OracleTypes.CURSOR);
      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();

      Retour retour = getRetour(cs);
      List<Sim> simList = new ArrayList<>();

      ResultSet rs = (ResultSet) cs.getObject(PO_RESULT);
      if (StringConstants.OK.equals(retour.getResultat()) && (rs != null))
      {
        while (rs.next())
        {
          simList.add(new Sim(rs));
        }
      }
      SpiritLogEvent outputLog = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, methodName);
      outputLog.addField("Retour", retour, false); //$NON-NLS-1$
      RavelLogger.log(outputLog);
      return new ConnectorResponse<>(simList, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("GNC:").append(gnc_p) //$NON-NLS-1$
          .toString());
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("GNC:").append(gnc_p) //$NON-NLS-1$
          .toString());
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("GDRConnector.ERREUR_GDR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("GNC:").append(gnc_p) //$NON-NLS-1$
          .toString());
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append("GNC:").append(gnc_p) //$NON-NLS-1$
          .toString());
    }
  }

  /**
   *
   * @param tracabilite_p
   * @param iccid_p
   * @param imsi_p
   * @return ConnectorResponse<Sim, Retour>
   * @throws RavelException
   */
  public ConnectorResponse<Sim, Retour> getSimByIccidOrImsi(Tracabilite tracabilite_p, String iccid_p, String imsi_p) throws RavelException
  {
    final String methodName = "PG_SPIRIT.P_GET_SIM_FROM_ICCID_IMSI"; //$NON-NLS-1$

    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall(String.format("{call %s(?,?,?,?,?,?,?) }", methodName))) //$NON-NLS-1$
    {
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("pi_ICCID", iccid_p); //$NON-NLS-1$
      cs.setString("pi_IMSI", imsi_p); //$NON-NLS-1$

      cs.registerOutParameter(PO_RESULT, OracleTypes.CURSOR);
      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();

      Retour retour = getRetour(cs);
      Sim sim = null;

      ResultSet rs = (ResultSet) cs.getObject(PO_RESULT);
      if (StringConstants.OK.equals(retour.getResultat()) && (rs != null) && rs.next())
      {
        sim = new Sim(rs);
      }
      SpiritLogEvent outputLog = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, methodName);
      outputLog.addField("Retour", retour, false); //$NON-NLS-1$
      RavelLogger.log(outputLog);
      return new ConnectorResponse<>(sim, retour);
    }

    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("ICCID:").append(iccid_p) //$NON-NLS-1$
          .append("IMSI:").append(imsi_p) //$NON-NLS-1$
          .toString());
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("ICCID:").append(iccid_p) //$NON-NLS-1$
          .append("IMSI:").append(imsi_p) //$NON-NLS-1$
          .toString());
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("GDRConnector.ERREUR_GDR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("ICCID:").append(iccid_p) //$NON-NLS-1$
          .append("IMSI:").append(imsi_p) //$NON-NLS-1$
          .toString());
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append("ICCID:").append(iccid_p) //$NON-NLS-1$
          .append("IMSI:").append(imsi_p) //$NON-NLS-1$
          .toString());
    }
  }

  /**
   * Get Sims Non Pre Provisionnes
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param idtCmd_p
   *          idtCmd
   * @param etatMoc_p
   *          etatMoc
   * @return {@link ConnectorResponse}
   * @throws RavelException
   *           exception
   */
  public ConnectorResponse<List<Sim>, Retour> getSimsNonPreProvisionnes(Tracabilite tracabilite_p, String idtCmd_p, String etatMoc_p) throws RavelException
  {
    final String methodName = "PG_SPIRIT.P_GET_SIM_IDTCMD"; //$NON-NLS-1$
    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall("{call PG_SPIRIT.P_GET_SIM_IDTCMD(?,?,?,?,?,?,?) }")) //$NON-NLS-1$
    {
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("pi_IDTCMD", idtCmd_p); //$NON-NLS-1$
      cs.setString("pi_ETATMOC", etatMoc_p); //$NON-NLS-1$
      cs.registerOutParameter(PO_RESULT, OracleTypes.CURSOR);

      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();

      Retour retour = getRetour(cs);

      List<Sim> simList = new ArrayList<>();

      ResultSet rs = (ResultSet) cs.getObject(PO_RESULT);
      if (StringConstants.OK.equals(retour.getResultat()) && (rs != null))
      {
        while (rs.next())
        {
          simList.add(new Sim(rs));
        }
      }

      SpiritLogEvent outputLog = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, methodName);
      outputLog.addField("Retour", retour, false); //$NON-NLS-1$
      RavelLogger.log(outputLog);
      return new ConnectorResponse<>(simList, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IDTCMD:").append(idtCmd_p).append("ETATMOC:").append(etatMoc_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IDTCMD:").append(idtCmd_p).append("ETATMOC:").append(etatMoc_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("GDRConnector.ERREUR_GDR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IDTCMD:").append(idtCmd_p).append("ETATMOC:").append(etatMoc_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append("IDTCMD:").append(idtCmd_p).append("ETATMOC:").append(etatMoc_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$
    }
  }

  /**
   * Get statistiques Esim
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param periodicite_p
   *          periodicite
   * @return {@link ConnectorResponse}
   * @throws RavelException
   *           exception
   */
  public ConnectorResponse<List<StatistiqueEsim>, Retour> getStatistiquesEsim(Tracabilite tracabilite_p, String periodicite_p) throws RavelException
  {
    final String methodName = "PG_SPIRIT.P_GET_STATISTIQUESESIM"; //$NON-NLS-1$
    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall("{call PG_SPIRIT.P_GET_STATISTIQUESESIM(?,?,?,?,?,?) }")) //$NON-NLS-1$
    {
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("pi_Periodicite", periodicite_p); //$NON-NLS-1$
      cs.registerOutParameter(PO_RESULT, OracleTypes.CURSOR);

      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();

      Retour retour = getRetour(cs);

      List<StatistiqueEsim> statsEsimList = new ArrayList<>();

      ResultSet rs = (ResultSet) cs.getObject(PO_RESULT);
      if (StringConstants.OK.equals(retour.getResultat()) && (rs != null))
      {
        while (rs.next())
        {
          statsEsimList.add(new StatistiqueEsim(rs));
        }
      }

      SpiritLogEvent outputLog = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, methodName);
      outputLog.addField("Retour", retour, false); //$NON-NLS-1$
      RavelLogger.log(outputLog);
      return new ConnectorResponse<>(statsEsimList, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("periodicite:").append(periodicite_p).toString()); //$NON-NLS-1$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("periodicite:").append(periodicite_p).toString()); //$NON-NLS-1$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("GDRConnector.ERREUR_GDR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("periodicite:").append(periodicite_p).toString()); //$NON-NLS-1$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append("periodicite:").append(periodicite_p).toString()); //$NON-NLS-1$
    }
  }

  /**
   * Insert Erreur Smdp.
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param iccid_p
   *          iccid
   * @param requestid_p
   *          requestid
   * @param etaterreur_p
   *          etaterreur
   * @param dat_p
   *          dat
   * @param idtdermod_p
   *          idtdermod
   * @param etatrequete_p
   *          etatrequete
   * @param entiteerreur_p
   *          entiteerreur
   * @param raisonerreur_p
   *          raisonerreur
   * @param libelleerreur_p
   *          libelleerreur
   * @return {@link ConnectorResponse}
   * @throws RavelException
   *           exception
   */
  public ConnectorResponse<Nothing, Retour> insertErreurSmdp(Tracabilite tracabilite_p, String iccid_p, String requestid_p, String etaterreur_p, LocalDateTime dat_p, String idtdermod_p, String etatrequete_p, String entiteerreur_p, String raisonerreur_p, String libelleerreur_p) throws RavelException
  {
    final String methodName = "PG_SPIRIT.P_INS_ERREUR_SMDP"; //$NON-NLS-1$
    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall("{call PG_SPIRIT.P_INS_ERREUR_SMDP(?,?,?,?,?,?,?,?,?,?,?,?,?) }")) //$NON-NLS-1$
    {
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("pi_ICCID", iccid_p); //$NON-NLS-1$
      cs.setString("pi_REQUESTID", requestid_p); //$NON-NLS-1$
      cs.setString("pi_ETATERREUR", etaterreur_p); //$NON-NLS-1$
      cs.setTimestamp("pi_DAT", Timestamp.valueOf(dat_p)); //$NON-NLS-1$
      cs.setString("pi_IDTDERMOD", idtdermod_p); //$NON-NLS-1$
      cs.setString("pi_ETATREQUETE", etatrequete_p); //$NON-NLS-1$
      cs.setString("pi_ENTITEERREUR", entiteerreur_p); //$NON-NLS-1$
      cs.setString("pi_RAISONERREUR", raisonerreur_p); //$NON-NLS-1$
      cs.setString("pi_LIBELLEERREUR", libelleerreur_p); //$NON-NLS-1$

      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();

      Retour retour = getRetour(cs);
      SpiritLogEvent outputLog = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, methodName);

      outputLog.addField("Retour", retour, false); //$NON-NLS-1$
      RavelLogger.log(outputLog);
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, //
          new StringBuilder().append("ICCID:").append(iccid_p) // //$NON-NLS-1$
              .append("REQUESTID:").append(requestid_p) // //$NON-NLS-1$
              .append("ETATERREUR:").append(etaterreur_p) // //$NON-NLS-1$
              .append("DAT:").append(dat_p) // //$NON-NLS-1$
              .append("IDTDERMOD:").append(idtdermod_p) // //$NON-NLS-1$
              .append("ETATREQUETE:").append(etatrequete_p) // //$NON-NLS-1$
              .append("ENTITEERREUR:").append(entiteerreur_p) // //$NON-NLS-1$
              .append("RAISONERREUR:").append(raisonerreur_p) // //$NON-NLS-1$
              .append("LIBELLEERREUR:").append(libelleerreur_p) // //$NON-NLS-1$
              .toString());
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, //
          new StringBuilder().append("ICCID:").append(iccid_p) // //$NON-NLS-1$
              .append("REQUESTID:").append(requestid_p) // //$NON-NLS-1$
              .append("ETATERREUR:").append(etaterreur_p) // //$NON-NLS-1$
              .append("DAT:").append(dat_p) // //$NON-NLS-1$
              .append("IDTDERMOD:").append(idtdermod_p) // //$NON-NLS-1$
              .append("ETATREQUETE:").append(etatrequete_p) // //$NON-NLS-1$
              .append("ENTITEERREUR:").append(entiteerreur_p) // //$NON-NLS-1$
              .append("RAISONERREUR:").append(raisonerreur_p) // //$NON-NLS-1$
              .append("LIBELLEERREUR:").append(libelleerreur_p) // //$NON-NLS-1$
              .toString());
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("GDRConnector.ERREUR_GDR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, //
          new StringBuilder().append("ICCID:").append(iccid_p) // //$NON-NLS-1$
              .append("REQUESTID:").append(requestid_p) // //$NON-NLS-1$
              .append("ETATERREUR:").append(etaterreur_p) // //$NON-NLS-1$
              .append("DAT:").append(dat_p) // //$NON-NLS-1$
              .append("IDTDERMOD:").append(idtdermod_p) // //$NON-NLS-1$
              .append("ETATREQUETE:").append(etatrequete_p) // //$NON-NLS-1$
              .append("ENTITEERREUR:").append(entiteerreur_p) // //$NON-NLS-1$
              .append("RAISONERREUR:").append(raisonerreur_p) // //$NON-NLS-1$
              .append("LIBELLEERREUR:").append(libelleerreur_p) // //$NON-NLS-1$
              .toString());
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, //
          new StringBuilder().append("ICCID:").append(iccid_p) // //$NON-NLS-1$
              .append("REQUESTID:").append(requestid_p) // //$NON-NLS-1$
              .append("ETATERREUR:").append(etaterreur_p) // //$NON-NLS-1$
              .append("DAT:").append(dat_p) // //$NON-NLS-1$
              .append("IDTDERMOD:").append(idtdermod_p) // //$NON-NLS-1$
              .append("ETATREQUETE:").append(etatrequete_p) // //$NON-NLS-1$
              .append("ENTITEERREUR:").append(entiteerreur_p) // //$NON-NLS-1$
              .append("RAISONERREUR:").append(raisonerreur_p) // //$NON-NLS-1$
              .append("LIBELLEERREUR:").append(libelleerreur_p) // //$NON-NLS-1$
              .toString());
    }
  }

  /**
   * Mettre a jour SIM
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param iccid_p
   *          iccid
   * @param etatSmdp_p
   *          etatSmdp
   * @param statutTelechargement_p
   *          statutTelechargement
   * @param objetModification_p
   *          objetModification
   * @param timestamp_p
   *          the timestamp
   * @param eid_p
   *          eid
   * @return {@link ConnectorResponse}
   * @throws RavelException
   *           exception
   */
  public ConnectorResponse<String, Retour> mettreAJourSIM(Tracabilite tracabilite_p, String iccid_p, String etatSmdp_p, String statutTelechargement_p, String objetModification_p, String timestamp_p, String eid_p) throws RavelException
  {
    final String methodName = "PG_SPIRIT.P_MAJ_SIM"; //$NON-NLS-1$

    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall("{call PG_SPIRIT.P_MAJ_SIM(?,?,?,?,?,?,?,?,?,?) }")) //$NON-NLS-1$
    {
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("pi_Iccid", iccid_p); //$NON-NLS-1$
      cs.setString("pi_etatSmdp", etatSmdp_p); //$NON-NLS-1$
      cs.setString("pi_statutTelechargement", statutTelechargement_p); //$NON-NLS-1$
      cs.setString("pi_objetModification", objetModification_p); //$NON-NLS-1$
      cs.setString("pi_datEta", timestamp_p); //$NON-NLS-1$
      cs.setString("pi_eid", eid_p); //$NON-NLS-1$

      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();

      Retour retour = getRetour(cs);
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("Iccid:").append(iccid_p).append(" etatSmdp:").append(etatSmdp_p).append(" statutTelechargement:").append(statutTelechargement_p).append(" objetModification:").append(objetModification_p).append(" timestamp:").append(timestamp_p).append(" eid:").append(eid_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("Iccid:").append(iccid_p).append(" etatSmdp:").append(etatSmdp_p).append(" statutTelechargement:").append(statutTelechargement_p).append(" objetModification:").append(objetModification_p).append(" timestamp:").append(timestamp_p).append(" eid:").append(eid_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("GDRConnector.ERREUR_GDR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("Iccid:").append(iccid_p).append(" etatSmdp:").append(etatSmdp_p).append(" statutTelechargement:").append(statutTelechargement_p).append(" objetModification:").append(objetModification_p).append(" timestamp:").append(timestamp_p).append(" eid:").append(eid_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append("Iccid:").append(iccid_p).append(" etatSmdp:").append(etatSmdp_p).append(" statutTelechargement:").append(statutTelechargement_p).append(" objetModification:").append(objetModification_p).append(" timestamp:").append(timestamp_p).append(" eid:").append(eid_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    }
  }

  /**
   * Mettre a jour SIM notif
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param iccid_p
   *          iccid
   * @param etatSmdp_p
   *          etatSmdp
   * @param identifiantAction_p
   *          identifiantAction
   * @param objetModification_p
   *          objetModification
   * @param datEta_p
   *          datEta
   * @param statutNotif_p
   *          statutNotification
   * @return {@link ConnectorResponse}
   * @throws RavelException
   *           exception
   */
  public ConnectorResponse<String, Retour> mettreAJourSIMNotif(Tracabilite tracabilite_p, String iccid_p, String etatSmdp_p, String identifiantAction_p, String objetModification_p, String datEta_p, String statutNotif_p) throws RavelException
  {
    final String methodName = "PG_SPIRIT.P_MAJ_SIM_NOTIF"; //$NON-NLS-1$

    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall("{call PG_SPIRIT.P_MAJ_SIM_NOTIF(?,?,?,?,?,?,?,?,?,?)}")) //$NON-NLS-1$
    {
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("pi_Iccid", iccid_p); //$NON-NLS-1$
      cs.setString("pi_etatSmdp", etatSmdp_p); //$NON-NLS-1$
      cs.setString("pi_identifiantAction", identifiantAction_p); //$NON-NLS-1$
      cs.setString("pi_objetModification", objetModification_p); //$NON-NLS-1$
      cs.setString("pi_datEta", datEta_p); //$NON-NLS-1$
      cs.setString("pi_statutTelechargement", statutNotif_p); //$NON-NLS-1$
      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();

      Retour retour = getRetour(cs);
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("Iccid:").append(iccid_p).append(" etatSmdp:").append(etatSmdp_p).append(" identifiantAction:").append(identifiantAction_p).append(" objetModification:").append(objetModification_p).append(" datEta:").append(datEta_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("Iccid:").append(iccid_p).append(" etatSmdp:").append(etatSmdp_p).append(" identifiantAction:").append(identifiantAction_p).append(" objetModification:").append(objetModification_p).append(" datEta:").append(datEta_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("GDRConnector.ERREUR_GDR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("Iccid:").append(iccid_p).append(" etatSmdp:").append(etatSmdp_p).append(" identifiantAction:").append(identifiantAction_p).append(" objetModification:").append(objetModification_p).append(" datEta:").append(datEta_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append("Iccid:").append(iccid_p).append(" etatSmdp:").append(etatSmdp_p).append(" identifiantAction:").append(identifiantAction_p).append(" objetModification:").append(objetModification_p).append(" datEta:").append(datEta_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
    }
  }

  /**
   * Update SIM notif appro
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param iccid_p
   *          iccid
   * @param notifAppro_p
   *          notifAppro
   *
   * @return {@link ConnectorResponse}
   * @throws RavelException
   *           exception
   */
  public ConnectorResponse<Nothing, Retour> mettreAJourSIMNotifAppro(Tracabilite tracabilite_p, String iccid_p, String notifAppro_p) throws RavelException
  {
    final String methodName = "PG_SPIRIT.P_MAJ_SIM_NOTIFAPPRO"; //$NON-NLS-1$

    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall("{call PG_SPIRIT.P_MAJ_SIM_NOTIFAPPRO(?,?,?,?,?,?) }")) //$NON-NLS-1$
    {
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("pi_ICCID", iccid_p); //$NON-NLS-1$
      cs.setString("pi_notifAppro", notifAppro_p); //$NON-NLS-1$

      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();

      Retour retour = getRetour(cs);
      SpiritLogEvent outputLog = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, methodName);

      outputLog.addField("Retour", retour, false); //$NON-NLS-1$
      RavelLogger.log(outputLog);
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("ICCID:").append(iccid_p).append("NOTIFAPPRO:").append(notifAppro_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("ICCID:").append(iccid_p).append("NOTIFAPPRO:").append(notifAppro_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("GDRConnector.ERREUR_GDR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("ICCID:").append(iccid_p).append("NOTIFAPPRO:").append(notifAppro_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("ICCID:").append(iccid_p).append("NOTIFAPPRO:").append(notifAppro_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$
    }
    return null;
  }

  /**
   * Get identifiants Commande
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param idtprfele_p
   *          idtprfele
   * @return {@link ConnectorResponse}
   * @throws RavelException
   *           exception
   */
  public ConnectorResponse<List<String>, Retour> ps014GetIdentifiantsCommande(Tracabilite tracabilite_p, String idtprfele_p) throws RavelException
  {
    List<String> retList = new ArrayList<>();

    final String methodName = "PG_SPIRIT.P_GET_IDS_COMMANDE"; //$NON-NLS-1$
    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall("{call PG_SPIRIT.P_GET_IDS_COMMANDE(?,?,?,?,?,?) }")) //$NON-NLS-1$
    {
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("pi_IDTPRFELE", idtprfele_p); //$NON-NLS-1$

      cs.registerOutParameter(PO_RESULT, OracleTypes.CURSOR);
      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();
      Retour retour = getRetour(cs);

      ResultSet rs = (ResultSet) cs.getObject(PO_RESULT);
      if (StringConstants.OK.equals(retour.getResultat()) && (rs != null))
      {
        while (rs.next())
        {
          retList.add(rs.getString("IDTCMD")); //$NON-NLS-1$
        }
      }
      SpiritLogEvent outputLog = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, methodName);
      outputLog.addField("Retour", retour, false); //$NON-NLS-1$
      RavelLogger.log(outputLog);
      return new ConnectorResponse<>(retList, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IDTPRFELE:").append(idtprfele_p).toString()); //$NON-NLS-1$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_SUR_NON_REPONSE", _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IDTPRFELE:").append(idtprfele_p).toString()); //$NON-NLS-1$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("GDRConnector.ERREUR_GDR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IDTPRFELE:").append(idtprfele_p).toString()); //$NON-NLS-1$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_CONNEXION", _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append("IDTPRFELE:").append(idtprfele_p).toString()); //$NON-NLS-1$
    }
  }

  /**
   * Get profile type
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param idtprf_p
   *          idtprf
   * @return {@link ConnectorResponse}
   * @throws RavelException
   *           exception
   */
  public ConnectorResponse<String, Retour> ps015GetProfileType(Tracabilite tracabilite_p, String idtprf_p) throws RavelException
  {
    String retProfileType = null;

    final String methodName = "PG_SPIRIT.P_GET_PROFILETYPE"; //$NON-NLS-1$
    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall("{call PG_SPIRIT.P_GET_PROFILETYPE(?,?,?,?,?,?) }")) //$NON-NLS-1$
    {
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("pi_IDTPRF", idtprf_p); //$NON-NLS-1$

      cs.registerOutParameter(PO_RESULT, OracleTypes.CURSOR);
      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();

      Retour retour = getRetour(cs);

      ResultSet rs = (ResultSet) cs.getObject(PO_RESULT);
      if (StringConstants.OK.equals(retour.getResultat()) && (rs != null) && rs.next())
      {
        retProfileType = rs.getString("PROFILETYPE"); //$NON-NLS-1$
      }
      SpiritLogEvent outputLog = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, methodName);
      outputLog.addField("Retour", retour, false); //$NON-NLS-1$
      RavelLogger.log(outputLog);
      return new ConnectorResponse<>(retProfileType, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IDTPRF:").append(idtprf_p).toString()); //$NON-NLS-1$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_SUR_NON_REPONSE", _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IDTPRF:").append(idtprf_p).toString()); //$NON-NLS-1$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("GDRConnector.ERREUR_GDR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IDTPRF:").append(idtprf_p).toString()); //$NON-NLS-1$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_CONNEXION", _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append("IDTPRF:").append(idtprf_p).toString()); //$NON-NLS-1$
    }
  }

  /**
   * Get iccids par idtCmd
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param idtcmd_p
   *          idtcmd
   * @return {@link ConnectorResponse}
   * @throws RavelException
   *           exception
   */
  public ConnectorResponse<List<String>, Retour> ps016GetIccidsParldtCmd(Tracabilite tracabilite_p, String idtcmd_p) throws RavelException
  {
    List<String> retList = new ArrayList<>();

    final String methodName = "PG_SPIRIT.P_GET_ICCIDS_IDTCMD"; //$NON-NLS-1$
    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall("{call PG_SPIRIT.P_GET_ICCIDS_IDTCMD(?,?,?,?,?,?) }")) //$NON-NLS-1$
    {
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("pi_IDTCMD", idtcmd_p); //$NON-NLS-1$

      cs.registerOutParameter(PO_RESULT, OracleTypes.CURSOR);
      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();
      Retour retour = getRetour(cs);

      ResultSet rs = (ResultSet) cs.getObject(PO_RESULT);
      if (StringConstants.OK.equals(retour.getResultat()) && (rs != null))
      {
        while (rs.next())
        {
          retList.add(rs.getString("SIM")); //$NON-NLS-1$
        }
      }
      SpiritLogEvent outputLog = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, methodName);

      outputLog.addField("Retour", retour, false); //$NON-NLS-1$
      RavelLogger.log(outputLog);
      return new ConnectorResponse<>(retList, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IDTCMD:").append(idtcmd_p).toString()); //$NON-NLS-1$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_SUR_NON_REPONSE", _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IDTCMD:").append(idtcmd_p).toString()); //$NON-NLS-1$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("GDRConnector.ERREUR_GDR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IDTCMD:").append(idtcmd_p).toString()); //$NON-NLS-1$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_CONNEXION", _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append("IDTCMD:").append(idtcmd_p).toString()); //$NON-NLS-1$
    }
  }

  /**
   * Get date derniere echec
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param idtcmd_p
   *          idtcmd
   * @return {@link ConnectorResponse}
   * @throws RavelException
   *           exception
   */
  public ConnectorResponse<LocalDateTime, Retour> ps017GetDateDerniereEchec(Tracabilite tracabilite_p, String idtcmd_p) throws RavelException
  {
    LocalDateTime retDate = null;

    final String methodName = "PG_SPIRIT.P_GET_DERNIER_ECHEC_SUIVI_SMDP"; //$NON-NLS-1$
    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall("{call PG_SPIRIT.P_GET_DERNIER_ECHEC_SUIVI_SMDP(?,?,?,?,?,?) }")) //$NON-NLS-1$
    {
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("pi_IDTCMD", idtcmd_p); //$NON-NLS-1$

      cs.registerOutParameter(PO_RESULT, OracleTypes.CURSOR);
      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();
      Retour retour = getRetour(cs);

      ResultSet rs = (ResultSet) cs.getObject(PO_RESULT);
      if (StringConstants.OK.equals(retour.getResultat()) && (rs != null) && rs.next())
      {
        retDate = DateTimeTools.toLocalDateTime(rs.getTimestamp("DATEDERNIERECHEC")); //$NON-NLS-1$

      }
      SpiritLogEvent outputLog = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, methodName);

      outputLog.addField("Retour", retour, false); //$NON-NLS-1$
      RavelLogger.log(outputLog);
      return new ConnectorResponse<>(retDate, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IDTCMD:").append(idtcmd_p).toString()); //$NON-NLS-1$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_SUR_NON_REPONSE", _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IDTCMD:").append(idtcmd_p).toString()); //$NON-NLS-1$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("GDRConnector.ERREUR_GDR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IDTCMD:").append(idtcmd_p).toString()); //$NON-NLS-1$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_CONNEXION", _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append("IDTCMD:").append(idtcmd_p).toString()); //$NON-NLS-1$
    }
  }

  /**
   * Set date derniere echec
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param idtcmd_p
   *          idtcmd
   * @return {@link ConnectorResponse}
   * @throws RavelException
   *           exception
   */
  public ConnectorResponse<Nothing, Retour> ps018SetDateDerniereEchec(Tracabilite tracabilite_p, String idtcmd_p) throws RavelException
  {
    final String methodName = "PG_SPIRIT.P_MAJ_IDTCMD_SUIVI_SMDP"; //$NON-NLS-1$
    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall("{call PG_SPIRIT.P_MAJ_IDTCMD_SUIVI_SMDP(?,?,?,?,?) }")) //$NON-NLS-1$
    {
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("pi_IDTCMD", idtcmd_p); //$NON-NLS-1$

      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();

      Retour retour = getRetour(cs);
      SpiritLogEvent outputLog = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, methodName);

      outputLog.addField("Retour", retour, false); //$NON-NLS-1$
      RavelLogger.log(outputLog);
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IDTCMD:").append(idtcmd_p).toString()); //$NON-NLS-1$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_SUR_NON_REPONSE", _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IDTCMD:").append(idtcmd_p).toString()); //$NON-NLS-1$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("GDRConnector.ERREUR_GDR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IDTCMD:").append(idtcmd_p).toString()); //$NON-NLS-1$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_CONNEXION", _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append("IDTCMD:").append(idtcmd_p).toString()); //$NON-NLS-1$
    }
  }

  /**
   * Update SIM download
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param iccid_p
   *          iccid
   * @param idtacnsim_p
   *          idtacnsim
   * @param idtdermod_p
   *          idtdermod
   * @param etasmdp_p
   *          etasmdp
   * @return {@link ConnectorResponse}
   * @throws RavelException
   *           exception
   */
  public ConnectorResponse<Nothing, Retour> ps019UpdateSimDownload(Tracabilite tracabilite_p, String iccid_p, String idtacnsim_p, String idtdermod_p, String etasmdp_p) throws RavelException
  {
    final String methodName = "PG_SPIRIT.P_MAJ_SIM_DOWNLOAD"; //$NON-NLS-1$

    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall("{call PG_SPIRIT.P_MAJ_SIM_DOWNLOAD(?,?,?,?,?,?,?,?) }")) //$NON-NLS-1$
    {
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("pi_ICCID", iccid_p); //$NON-NLS-1$
      cs.setString("pi_IDTACNSIM", idtacnsim_p); //$NON-NLS-1$
      cs.setString("pi_IDTDERMOD", idtdermod_p); //$NON-NLS-1$
      cs.setString("pi_ETASMDP", etasmdp_p); //$NON-NLS-1$

      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();

      Retour retour = getRetour(cs);
      SpiritLogEvent outputLog = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, methodName);

      outputLog.addField("Retour", retour, false); //$NON-NLS-1$
      RavelLogger.log(outputLog);
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IDTACNSIM:").append(idtacnsim_p).append("IDTDERMOD:").append(idtdermod_p).append("ETATSMDP:").append(etasmdp_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IDTACNSIM:").append(idtacnsim_p).append("IDTDERMOD:").append(idtdermod_p).append("ETATSMDP:").append(etasmdp_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("GDRConnector.ERREUR_GDR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IDTACNSIM:").append(idtacnsim_p).append("IDTDERMOD:").append(idtdermod_p).append("ETATSMDP:").append(etasmdp_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IDTACNSIM:").append(idtacnsim_p).append("IDTDERMOD:").append(idtdermod_p).append("ETATSMDP:").append(etasmdp_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    }
    return null;
  }

  /**
   * Update quantity
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param idtcmd_p
   *          idtcmd
   * @return {@link ConnectorResponse}
   * @throws RavelException
   *           exception
   */
  public ConnectorResponse<Nothing, Retour> ps020UpdateQuantity(Tracabilite tracabilite_p, String idtcmd_p) throws RavelException
  {
    final String methodName = "PG_SPIRIT.P_MAJ_QUANT_SUIVI_SMDP"; //$NON-NLS-1$

    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall("{call PG_SPIRIT.P_MAJ_QUANT_SUIVI_SMDP(?,?,?,?,?) }")) //$NON-NLS-1$
    {
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("pi_IDTCMD", idtcmd_p); //$NON-NLS-1$

      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();

      Retour retour = getRetour(cs);
      SpiritLogEvent outputLog = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, methodName);

      outputLog.addField("Retour", retour, false); //$NON-NLS-1$
      RavelLogger.log(outputLog);

      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IDTCMD:").append(idtcmd_p).toString()); //$NON-NLS-1$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IDTCMD:").append(idtcmd_p).toString()); //$NON-NLS-1$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("GDRConnector.ERREUR_GDR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IDTCMD:").append(idtcmd_p).toString()); //$NON-NLS-1$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IDTCMD:").append(idtcmd_p).toString()); //$NON-NLS-1$
    }
    return null;
  }

  /**
   * Get Commandes non notifies
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @return {@link ConnectorResponse}
   * @throws RavelException
   *           exception
   */
  public ConnectorResponse<List<CMDSIM>, Retour> ps021GetCommandesNonNotifies(Tracabilite tracabilite_p) throws RavelException
  {
    final String methodName = "PG_SPIRIT.P_GET_CMDNONNOTIFIE"; //$NON-NLS-1$

    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall(String.format("{call %s(?,?,?,?,?) }", methodName))) //$NON-NLS-1$
    {
      cs.setQueryTimeout(_readTimeoutSec);

      cs.registerOutParameter(PO_RESULT, OracleTypes.CURSOR);
      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();
      List<CMDSIM> cmdSIMList = new ArrayList<>();

      Retour retour = getRetour(cs);

      ResultSet rs = (ResultSet) cs.getObject(PO_RESULT);
      if (StringConstants.OK.equals(retour.getResultat()) && (rs != null))
      {
        while (rs.next())
        {
          cmdSIMList.add(new CMDSIM(rs));
        }
      }
      SpiritLogEvent outputLog = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, methodName);
      outputLog.addField("Retour", retour, false); //$NON-NLS-1$
      RavelLogger.log(outputLog);
      return new ConnectorResponse<>(cmdSIMList, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("ps021GetCommandesNonNotifies").toString()); //$NON-NLS-1$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SELECT_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("ps021GetCommandesNonNotifies").toString()); //$NON-NLS-1$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("GDRConnector.ERREUR_GDR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("ps021GetCommandesNonNotifies").toString()); //$NON-NLS-1$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append("ps021GetCommandesNonNotifies").toString()); //$NON-NLS-1$
    }
  }

  /**
   * Get commande
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param idtcmd_p
   *          idtcmd
   * @return {@link ConnectorResponse}
   * @throws RavelException
   *           exception
   */
  public ConnectorResponse<CMDSIM, Retour> ps022GetCommande(Tracabilite tracabilite_p, String idtcmd_p) throws RavelException
  {
    final String methodName = "PG_SPIRIT.P_GET_COMMANDE"; //$NON-NLS-1$

    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall("{call PG_SPIRIT.P_GET_COMMANDE(?,?,?,?,?,?) }")) //$NON-NLS-1$
    {
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("pi_IDTCMD", idtcmd_p); //$NON-NLS-1$

      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(PO_RESULT, OracleTypes.CURSOR);

      cs.execute();

      Retour retour = getRetour(cs);
      CMDSIM cmdsim = null;

      ResultSet rs = (ResultSet) cs.getObject(PO_RESULT);
      if (StringConstants.OK.equals(retour.getResultat()) && (rs != null) && rs.next())
      {
        cmdsim = new CMDSIM(rs);
      }
      SpiritLogEvent outputLog = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, methodName);

      outputLog.addField("Retour", retour, false); //$NON-NLS-1$
      RavelLogger.log(outputLog);

      return new ConnectorResponse<>(cmdsim, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IDTCMD:").append(idtcmd_p).toString()); //$NON-NLS-1$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SELECT_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IDTCMD:").append(idtcmd_p).toString()); //$NON-NLS-1$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("GDRConnector.ERREUR_GDR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IDTCMD:").append(idtcmd_p).toString()); //$NON-NLS-1$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append("IDTCMD:").append(idtcmd_p).toString()); //$NON-NLS-1$
    }
  }

  /**
   * Update envoi CMDSIM
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param idtcmd_p
   *          idtcmd
   * @param envoinotifsap_p
   *          envoiNotifSap
   * @return {@link ConnectorResponse}
   * @throws RavelException
   *           exception
   */
  public ConnectorResponse<Nothing, Retour> ps023UpdateEnvoiCmdSim(Tracabilite tracabilite_p, String idtcmd_p, String envoinotifsap_p) throws RavelException
  {
    final String methodName = "PG_SPIRIT.P_MAJ_ENVOI_CMDSIM"; //$NON-NLS-1$

    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall("{call PG_SPIRIT.P_MAJ_ENVOI_CMDSIM(?,?,?,?,?,?) }")) //$NON-NLS-1$
    {
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("pi_IDTCMD", idtcmd_p); //$NON-NLS-1$
      cs.setString("pi_ENVOINOTIFSAP", envoinotifsap_p); //$NON-NLS-1$

      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();

      Retour retour = getRetour(cs);
      SpiritLogEvent outputLog = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, methodName);

      outputLog.addField("Retour", retour, false); //$NON-NLS-1$
      RavelLogger.log(outputLog);

      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IDTCMD:").append(idtcmd_p).append("ENVOINOTIFSAP:").append(envoinotifsap_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IDTCMD:").append(idtcmd_p).append("ENVOINOTIFSAP:").append(envoinotifsap_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("GDRConnector.ERREUR_GDR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IDTCMD:").append(idtcmd_p).append("ENVOINOTIFSAP:").append(envoinotifsap_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IDTCMD:").append(idtcmd_p).append("ENVOINOTIFSAP:").append(envoinotifsap_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$
    }
    return null;
  }

  /**
   * Get Bytprd
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param gnc_p
   *          gnc
   * @return {@link ConnectorResponse}
   * @throws RavelException
   *           exception
   */
  public ConnectorResponse<List<BYTPRD>, Retour> ps024GetBytprd(Tracabilite tracabilite_p, String gnc_p) throws RavelException
  {
    final String methodName = "PG_SPIRIT.P_GET_BYTPRD"; //$NON-NLS-1$

    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall("{call PG_SPIRIT.P_GET_BYTPRD(?,?,?,?,?,?) }")) //$NON-NLS-1$
    {
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("pi_GNC", gnc_p); //$NON-NLS-1$

      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(PO_RESULT, OracleTypes.CURSOR);

      cs.execute();

      Retour retour = getRetour(cs);
      List<BYTPRD> bytprdList = new ArrayList<>();

      ResultSet rs = (ResultSet) cs.getObject(PO_RESULT);
      if (StringConstants.OK.equals(retour.getResultat()) && (rs != null))
      {
        while (rs.next())
        {
          bytprdList.add(new BYTPRD(rs));
        }
      }
      SpiritLogEvent outputLog = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, methodName);
      outputLog.addField("Retour", retour, false); //$NON-NLS-1$
      RavelLogger.log(outputLog);

      return new ConnectorResponse<>(bytprdList, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("GNC:").append(gnc_p).toString()); //$NON-NLS-1$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SELECT_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("GNC:").append(gnc_p).toString()); //$NON-NLS-1$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("GDRConnector.ERREUR_GDR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("GNC:").append(gnc_p).toString()); //$NON-NLS-1$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append("GNC:").append(gnc_p).toString()); //$NON-NLS-1$
    }
  }

  /**
   * Get Suivi SMDP
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param idtcmd_p
   *          idtcmd
   * @return {@link ConnectorResponse}
   * @throws RavelException
   *           exception
   */
  public ConnectorResponse<List<SUIVISMDP>, Retour> ps025GetSUIVISMDP(Tracabilite tracabilite_p, String idtcmd_p) throws RavelException
  {
    final String methodName = "PG_SPIRIT.P_GET_IDTCMD_SUIVI_SMDP"; //$NON-NLS-1$

    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall(String.format("{call %s(?,?,?,?,?,?) }", methodName))) //$NON-NLS-1$
    {
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("pi_IDTCMD", idtcmd_p); //$NON-NLS-1$

      cs.registerOutParameter(PO_RESULT, OracleTypes.CURSOR);
      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();
      List<SUIVISMDP> suiviSMDPList = new ArrayList<>();

      Retour retour = getRetour(cs);

      ResultSet rs = (ResultSet) cs.getObject(PO_RESULT);
      if (StringConstants.OK.equals(retour.getResultat()) && (rs != null))
      {
        while (rs.next())
        {
          suiviSMDPList.add(new SUIVISMDP(rs));
        }
      }
      SpiritLogEvent outputLog = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, methodName);
      outputLog.addField("Retour", retour, false); //$NON-NLS-1$
      RavelLogger.log(outputLog);
      return new ConnectorResponse<>(suiviSMDPList, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("ps025GetSUIVISMDP").toString()); //$NON-NLS-1$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SELECT_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("ps025GetSUIVISMDP").toString()); //$NON-NLS-1$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("GDRConnector.ERREUR_GDR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("ps025GetSUIVISMDP").toString()); //$NON-NLS-1$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append("ps025GetSUIVISMDP").toString()); //$NON-NLS-1$
    }
  }

  /**
   * Enregistrer envoi fichier
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param idtcmd_p
   *          idtcmd
   * @param nomfichier_p
   *          nomFichier
   * @return {@link ConnectorResponse}
   * @throws RavelException
   *           exception
   */
  public ConnectorResponse<Nothing, Retour> ps026EnregistrerEnvoiFichier(Tracabilite tracabilite_p, String idtcmd_p, String nomfichier_p) throws RavelException
  {
    final String methodName = "PG_SPIRIT.P_ENREGISTRER_ENVOI_FICHIER"; //$NON-NLS-1$

    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall("{call PG_SPIRIT.P_ENREGISTRER_ENVOI_FICHIER(?,?,?,?,?,?) }")) //$NON-NLS-1$
    {
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("pi_IDTCMD", idtcmd_p); //$NON-NLS-1$
      cs.setString("pi_NOMFICHIER", nomfichier_p); //$NON-NLS-1$

      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();

      Retour retour = getRetour(cs);
      SpiritLogEvent outputLog = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, methodName);

      outputLog.addField("Retour", retour, false); //$NON-NLS-1$
      RavelLogger.log(outputLog);

      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IDTCMD:").append(idtcmd_p).append("NOMFICHEIR:").append(nomfichier_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IDTCMD:").append(idtcmd_p).append("NOMFICHEIR:").append(nomfichier_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("GDRConnector.ERREUR_GDR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IDTCMD:").append(idtcmd_p).append("NOMFICHEIR:").append(nomfichier_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IDTCMD:").append(idtcmd_p).append("NOMFICHEIR:").append(nomfichier_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$
    }
    return null;
  }

  /**
   * Get Suivi SMDP dernier echec
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param idtcmd_p
   *          idtcmd
   * @return {@link ConnectorResponse}
   * @throws RavelException
   *           exception
   */
  public ConnectorResponse<SUIVISMDP, Retour> ps027GetSUIVISMDPDernierEchec(Tracabilite tracabilite_p, String idtcmd_p) throws RavelException
  {
    final String methodName = "PG_SPIRIT.P_GET_DERNIER_ECHEC_SUIVI_SMDP"; //$NON-NLS-1$

    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall(String.format("{call %s(?,?,?,?,?,?) }", methodName))) //$NON-NLS-1$
    {
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("pi_IDTCMD", idtcmd_p); //$NON-NLS-1$

      cs.registerOutParameter(PO_RESULT, OracleTypes.CURSOR);
      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();

      Retour retour = getRetour(cs);
      SUIVISMDP suiviSMDP = null;

      ResultSet rs = (ResultSet) cs.getObject(PO_RESULT);
      if (StringConstants.OK.equals(retour.getResultat()) && (rs != null))
      {
        while (rs.next())
        {
          suiviSMDP = new SUIVISMDP(rs);
        }
      }
      SpiritLogEvent outputLog = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, methodName);
      outputLog.addField("Retour", retour, false); //$NON-NLS-1$
      RavelLogger.log(outputLog);
      return new ConnectorResponse<>(suiviSMDP, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("ps027GetSUIVISMDPDernierEchec").toString()); //$NON-NLS-1$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SELECT_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("ps027GetSUIVISMDPDernierEchec").toString()); //$NON-NLS-1$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("GDRConnector.ERREUR_GDR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("ps027GetSUIVISMDPDernierEchec").toString()); //$NON-NLS-1$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append("ps027GetSUIVISMDPDernierEchec").toString()); //$NON-NLS-1$
    }
  }

  /**
   * @param factory_p
   *          the factory to set
   */
  public void setFactory(ArrayDescriptorFactory factory_p)
  {
    _arrayDescriptionFactory = factory_p;
  }

  /**
   * Update Sim Etat Moc
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param pe_p
   *          pe
   * @param etatMoc_p
   *          etatMoc
   * @return {@link ConnectorResponse}
   * @throws RavelException
   *           exception
   */
  public ConnectorResponse<Nothing, Retour> updateSimEtatMoc(Tracabilite tracabilite_p, String pe_p, String etatMoc_p) throws RavelException
  {
    final String methodName = "PG_SPIRIT.P_MAJ_PREPROVMOC_PE"; //$NON-NLS-1$
    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall("{call PG_SPIRIT.P_MAJ_PREPROVMOC_PE(?,?,?,?,?,?) }")) //$NON-NLS-1$
    {
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("pi_PE", pe_p); //$NON-NLS-1$
      cs.setString("pi_ETATMOC", etatMoc_p); //$NON-NLS-1$

      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();

      Retour retour = getRetour(cs);
      SpiritLogEvent outputLog = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, methodName);

      outputLog.addField("Retour", retour, false); //$NON-NLS-1$
      RavelLogger.log(outputLog);
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("PE:").append(pe_p).append("ETATMOC:").append(etatMoc_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("PE:").append(pe_p).append("ETATMOC:").append(etatMoc_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("GDRConnector.ERREUR_GDR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("PE:").append(pe_p).append("ETATMOC:").append(etatMoc_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append("PE:").append(pe_p).append("ETATMOC:").append(etatMoc_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$
    }
  }

  /**
   * Update Sim Etat Moc
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param imsi_p
   *          imsi
   * @param etatMoc_p
   *          etatMoc
   * @return {@link ConnectorResponse}
   * @throws RavelException
   *           exception
   */
  public ConnectorResponse<Nothing, Retour> updateSimEtatMocImsi(Tracabilite tracabilite_p, String imsi_p, String etatMoc_p) throws RavelException
  {
    final String methodName = "PG_SPIRIT.P_MAJ_PREPROVMOC_IMSI"; //$NON-NLS-1$
    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall("{call PG_SPIRIT.P_MAJ_PREPROVMOC_IMSI(?,?,?,?,?,?) }")) //$NON-NLS-1$
    {
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("pi_IMSI", imsi_p); //$NON-NLS-1$
      cs.setString("pi_ETATMOC", etatMoc_p); //$NON-NLS-1$

      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();

      Retour retour = getRetour(cs);
      SpiritLogEvent outputLog = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, methodName);

      outputLog.addField("Retour", retour, false); //$NON-NLS-1$
      RavelLogger.log(outputLog);
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IMSI:").append(imsi_p).append("ETATMOC:").append(etatMoc_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IMSI:").append(imsi_p).append("ETATMOC:").append(etatMoc_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("GDRConnector.ERREUR_GDR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IMSI:").append(imsi_p).append("ETATMOC:").append(etatMoc_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append("IMSI:").append(imsi_p).append("ETATMOC:").append(etatMoc_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$
    }
  }

  /**
   * @param tracabilite_p
   * @param iccid_p
   * @param etaSim_p
   * @param idtAcnSim_p
   * @param idtDermod_p
   * @param idtist_p
   * @param etasmdp_p
   * @param etatNotif_p
   * @param policyEtat_p
   * @param policyHabilitation_p
   * @param eid_p
   * @param smsrid_p
   * @return ConnectorResponse<Nothing, Retour>
   * @throws RavelException
   */
  public ConnectorResponse<Nothing, Retour> updateSimRessource(Tracabilite tracabilite_p, String iccid_p, String etaSim_p, Long idtAcnSim_p, String idtDermod_p, String idtist_p, String etasmdp_p, String etatNotif_p, String policyEtat_p, String policyHabilitation_p, String eid_p, String smsrid_p) throws RavelException
  {
    final String inputs = "ICCID:" + iccid_p //$NON-NLS-1$
        + "ETASIM:" + etaSim_p //$NON-NLS-1$
        + "IDTACNSIM:" + idtAcnSim_p //$NON-NLS-1$
        + "IDTDERMOD:" + idtDermod_p //$NON-NLS-1$
        + "IDTIST:" + idtist_p //$NON-NLS-1$
        + "ETASMDP:" + etasmdp_p //$NON-NLS-1$
        + "ETANOTIF:" + etatNotif_p //$NON-NLS-1$
        + "POLICYETAT:" + policyEtat_p //$NON-NLS-1$
        + "POLICYHABILITATION:" + policyHabilitation_p //$NON-NLS-1$
        + "SMSRID:" + smsrid_p; //$NON-NLS-1$

    final String methodName = "PG_SPIRIT.P_MAJ_SIM_RESSOURCE"; //$NON-NLS-1$

    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall(String.format("{call %s(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) }", methodName))) //$NON-NLS-1$
    {
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("pi_ICCID", iccid_p); //$NON-NLS-1$
      cs.setString("pi_ETASIM", etaSim_p); //$NON-NLS-1$
      cs.setLong("pi_IDTACNSIM", idtAcnSim_p); //$NON-NLS-1$
      cs.setString("pi_IDTDERMOD", idtDermod_p); //$NON-NLS-1$
      cs.setString("pi_IDTIST", idtist_p); //$NON-NLS-1$
      cs.setString("pi_ETASMDP", etasmdp_p); //$NON-NLS-1$
      cs.setString("pi_ETATNOTIF", etatNotif_p); //$NON-NLS-1$
      cs.setString("pi_POLICYETAT", policyEtat_p); //$NON-NLS-1$
      cs.setString("pi_POLICYHABILITATION", policyHabilitation_p); //$NON-NLS-1$
      cs.setString("pi_EID", eid_p); //$NON-NLS-1$
      cs.setString("pi_SMSRID", smsrid_p); //$NON-NLS-1$
      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();

      Retour retour = getRetour(cs);
      SpiritLogEvent outputLog = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, methodName);

      outputLog.addField("Retour", retour, false); //$NON-NLS-1$
      RavelLogger.log(outputLog);
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, inputs);
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, inputs);
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("GDRConnector.ERREUR_GDR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, inputs);
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, inputs);
    }
  }
}
