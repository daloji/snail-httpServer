/*******************************************************************************
* $Id: GDRPGIWSRessources.java 17031 2019-02-12 11:19:48Z lmerces $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.gdr.utils;

import static com.bytel.spirit.common.connectors.gdr.utils.GDRConnectorConstants.CONNEXION_FAILED;
import static com.bytel.spirit.common.connectors.gdr.utils.GDRConnectorConstants.INSERTION_FAILED;
import static com.bytel.spirit.common.connectors.gdr.utils.GDRConnectorConstants.PO_RESULT;
import static com.bytel.spirit.common.connectors.gdr.utils.GDRConnectorConstants.RETOUR_CATEGORIE;
import static com.bytel.spirit.common.connectors.gdr.utils.GDRConnectorConstants.RETOUR_DIAGNOSTIC;
import static com.bytel.spirit.common.connectors.gdr.utils.GDRConnectorConstants.RETOUR_LIBELLE;
import static com.bytel.spirit.common.connectors.gdr.utils.GDRConnectorConstants.RETOUR_RESULTAT;
import static com.bytel.spirit.common.connectors.gdr.utils.GDRConnectorConstants.SELECT_FAILED;
import static com.bytel.spirit.common.connectors.gdr.utils.GDRConnectorConstants.SESSION_UNAVAILABLE;
import static com.bytel.spirit.common.connectors.gdr.utils.GDRConnectorConstants.TYPMSISDN;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLRecoverableException;
import java.sql.SQLTimeoutException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.tomcat.jdbc.pool.DataSource;
import org.apache.tomcat.jdbc.pool.PoolExhaustedException;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.common.utils.StringTools.PaddingDirection;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.connectors.gdr.ConsultSimBatch;
import com.bytel.spirit.common.connectors.gdr.Messages;
import com.bytel.spirit.common.connectors.gdr.SimRecord;
import com.bytel.spirit.common.connectors.gdr.TypeMsisdn;
import com.bytel.spirit.common.connectors.gdr.structs.CarteProfileData;
import com.bytel.spirit.common.connectors.gdr.structs.DURMSI;
import com.bytel.spirit.common.connectors.gdr.structs.MSISDN;
import com.bytel.spirit.common.connectors.gdr.structs.Sim;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

import oracle.jdbc.OracleTypes;

/**
 *
 * @author lmerces
 * @version ($Revision: 17031 $ $Date: 2019-02-12 12:19:48 +0100 (mar. 12 févr. 2019) $)
 */
public class GDRPGIWSRessources extends GDRConnectorUtils
{
  /**
   * Datasource
   */
  private DataSource _datasource;

  /**
   * Read timeout in seconds
   */
  private int _readTimeoutSec;

  /**
   * Connect timeout in seconds
   */
  private int _connectTimeoutSec;

  /**
   * @param datasource_p
   *          datasource
   * @param readTimeoutSec_p
   *          readTimeoutSec
   * @param connectTimeoutSec_p
   *          connectTimeoutSec
   */
  public GDRPGIWSRessources(DataSource datasource_p, int readTimeoutSec_p, int connectTimeoutSec_p)
  {
    super();
    _datasource = datasource_p;
    _readTimeoutSec = readTimeoutSec_p;
    _connectTimeoutSec = connectTimeoutSec_p;
  }

  /**
   * Invocation of the stored procedure P_CONSULT_ETAT_BATCH. Check state Sim Batch.
   *
   * @param tracabilite_p
   *          la tracabilite
   * @param idBatch_p
   *          idBatch
   * @param listeTypeSim_p
   *          listeTypeSim
   * @return {@link ConnectorResponse}
   * @throws RavelException
   *           exception
   */
  public ConnectorResponse<Long, Retour> checkEtatSimBatch(Tracabilite tracabilite_p, long idBatch_p, String listeTypeSim_p) throws RavelException
  {
    final String methodName = "PG_IWSRESSOURCES.P_CHECK_ETATSIM_BATCH"; //$NON-NLS-1$

    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall("{call PG_IWSRESSOURCES.P_CHECK_ETATSIM_BATCH(?,?,?,?,?,?,?) }")) //$NON-NLS-1$
    {
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setLong("pi_IDBATCH", idBatch_p); //$NON-NLS-1$
      cs.setString("pi_ListeTypeSim", listeTypeSim_p); //$NON-NLS-1$
      cs.registerOutParameter("po_ExisteSimIncoherent", OracleTypes.INTEGER); //$NON-NLS-1$
      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();

      Long existeSimIncoherent = cs.getLong("po_ExisteSimIncoherent"); //$NON-NLS-1$
      Retour retour = getRetour(cs);
      return new ConnectorResponse<>(existeSimIncoherent, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IDBATCH:").append(idBatch_p).append(" LISTETYPESIM:").append(listeTypeSim_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, MessageFormat.format(Messages.getString("ERREUR_GDR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IDBATCH:").append(idBatch_p).append(" LISTETYPESIM:").append(listeTypeSim_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("ERREUR_GDR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IDBATCH:").append(idBatch_p).append(" LISTETYPESIM:").append(listeTypeSim_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("ERREUR_GDR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append("IDBATCH:").append(idBatch_p).append(" LISTETYPESIM:").append(listeTypeSim_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$
    }
  }

  /**
   * Consult etat batch
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param idBatch_p
   *          idBatch
   * @return {@link ConnectorResponse}
   * @throws RavelException
   *           exception
   */
  public ConnectorResponse<String, Retour> consultEtatBatch(Tracabilite tracabilite_p, long idBatch_p) throws RavelException
  {
    final String methodName = "PG_IWSRESSOURCES.P_CONSULT_ETAT_BATCH"; //$NON-NLS-1$

    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall("{call PG_IWSRESSOURCES.P_CONSULT_ETAT_BATCH(?,?,?,?,?,?) }")) //$NON-NLS-1$
    {
      cs.setQueryTimeout(_readTimeoutSec);
      cs.setLong("pi_IDBATCH", idBatch_p); //$NON-NLS-1$
      cs.registerOutParameter("po_ETACMD", OracleTypes.NVARCHAR); //$NON-NLS-1$
      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();

      String etacmd = cs.getString("po_ETACMD"); //$NON-NLS-1$
      Retour retour = getRetour(cs);
      return new ConnectorResponse<>(etacmd, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IDBATCH:").append(idBatch_p).toString()); //$NON-NLS-1$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, MessageFormat.format(Messages.getString("ERREUR_GDR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IDBATCH:").append(idBatch_p).toString()); //$NON-NLS-1$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("ERREUR_GDR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IDBATCH:").append(idBatch_p).toString()); //$NON-NLS-1$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("ERREUR_GDR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append("IDBATCH:").append(idBatch_p).toString()); //$NON-NLS-1$
    }
  }

  /**
   * Consult SIM Batch
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param idBatch_p
   *          idBatch
   * @param etasim_p
   *          etaSim
   * @param listeTypeSim_p
   *          listeTypeSim
   * @return {@link ConnectorResponse}
   * @throws RavelException
   *           exception
   */
  public ConnectorResponse<ConsultSimBatch, Retour> consultSimBatch(Tracabilite tracabilite_p, long idBatch_p, String etasim_p, String listeTypeSim_p) throws RavelException
  {
    final String methodName = "PG_IWSRESSOURCES.P_CONSULT_SIM_BATCH"; //$NON-NLS-1$

    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall("{call PG_IWSRESSOURCES.P_CONSULT_SIM_BATCH(?,?,?,?,?,?,?,?) }")) //$NON-NLS-1$
    {
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setLong("pi_IDBATCH", idBatch_p); //$NON-NLS-1$
      cs.setString("pi_ListeTypeSim", listeTypeSim_p); //$NON-NLS-1$
      cs.setString("pi_ETASIM", etasim_p); //$NON-NLS-1$

      cs.registerOutParameter(PO_RESULT, OracleTypes.CURSOR);
      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();

      Retour retour = getRetour(cs);
      ConsultSimBatch csb = new ConsultSimBatch();
      ArrayList<SimRecord> listRecs = new ArrayList<>();

      ResultSet rs = (ResultSet) cs.getObject(PO_RESULT);
      while (rs.next())
      {
        mapSimrecordResults(rs, listRecs);
      }

      SimRecord recs[] = new SimRecord[listRecs.size()];
      csb.setSimRecords(listRecs.toArray(recs));
      return new ConnectorResponse<>(csb, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IDBATCH:").append(idBatch_p).append(" LISTETYPESIM:").append(listeTypeSim_p).append(" ETASIM:").append(etasim_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IDBATCH:").append(idBatch_p).append(" LISTETYPESIM:").append(listeTypeSim_p).append(" ETASIM:").append(etasim_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("GDRConnector.ERREUR_GDR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IDBATCH:").append(idBatch_p).append(" LISTETYPESIM:").append(listeTypeSim_p).append(" ETASIM:").append(etasim_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append("IDBATCH:").append(idBatch_p).append(" LISTETYPESIM:").append(listeTypeSim_p).append(" ETASIM:").append(etasim_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    }
  }

  /**
   * MAJ etat batch
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param idBatch_p
   *          idBatch
   * @return {@link ConnectorResponse}
   * @throws RavelException
   *           exception
   */
  public ConnectorResponse<String, Retour> majEtatBatch(Tracabilite tracabilite_p, long idBatch_p) throws RavelException
  {
    final String methodName = "PG_IWSRESSOURCES.P_MAJ_ETAT_BATCH"; //$NON-NLS-1$

    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall("{call PG_IWSRESSOURCES.P_MAJ_ETAT_BATCH(?,?,?,?,?) }")) //$NON-NLS-1$
    {
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setLong("pi_IDBATCH", idBatch_p); //$NON-NLS-1$

      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();

      Retour retour = getRetour(cs);
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IDBATCH:").append(idBatch_p).toString()); //$NON-NLS-1$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, MessageFormat.format(Messages.getString("ERREUR_GDR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IDBATCH:").append(idBatch_p).toString()); //$NON-NLS-1$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("ERREUR_GDR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IDBATCH:").append(idBatch_p).toString()); //$NON-NLS-1$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("ERREUR_GDR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append("IDBATCH:").append(idBatch_p).toString()); //$NON-NLS-1$
    }
  }

  /**
   * Mise a disposition batch
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param idBatch_p
   *          idBatch
   * @param listeTypeSim_p
   *          listeTypeSim
   * @param instanceCliente_p
   *          instanceCliente
   * @return {@link ConnectorResponse}
   * @throws RavelException
   *           exception
   */
  public ConnectorResponse<String, Retour> miseADispositionSimBatch(Tracabilite tracabilite_p, long idBatch_p, String listeTypeSim_p, String instanceCliente_p) throws RavelException
  {
    final String methodName = "PG_IWSRESSOURCES.P_MISE_A_DISPOSITION_SIM_BATCH"; //$NON-NLS-1$

    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall("{call PG_IWSRESSOURCES.P_MISE_A_DISPOSITION_SIM_BATCH(?,?,?,?,?,?,?) }")) //$NON-NLS-1$
    {
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setLong("pi_IDBATCH", idBatch_p); //$NON-NLS-1$
      cs.setString("pi_ListeTypeSim", listeTypeSim_p); //$NON-NLS-1$
      cs.setString("pi_InstanceCliente", instanceCliente_p); //$NON-NLS-1$

      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();

      Retour retour = getRetour(cs);
      return new ConnectorResponse<>(null, retour);

    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IDBATCH:").append(idBatch_p).append(" LISTETYPESIM:").append(listeTypeSim_p).append(" INSTANCECLIENTE:").append(instanceCliente_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IDBATCH:").append(idBatch_p).append(" LISTETYPESIM:").append(listeTypeSim_p).append(" INSTANCECLIENTE:").append(instanceCliente_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("GDRConnector.ERREUR_GDR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IDBATCH:").append(idBatch_p).append(" LISTETYPESIM:").append(listeTypeSim_p).append(" INSTANCECLIENTE:").append(instanceCliente_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append("IDBATCH:").append(idBatch_p).append(" LISTETYPESIM:").append(listeTypeSim_p).append(" INSTANCECLIENTE:").append(instanceCliente_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    }
  }

  /**
   * Consult TypeMSI from Type
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param typeMsisdn_p
   *          typeMsisdn
   * @return {@link ConnectorResponse}
   * @throws RavelException
   *           exception
   */
  public ConnectorResponse<TypeMsisdn, Retour> ps001ConsultTYPEMSIFROMType(Tracabilite tracabilite_p, Integer typeMsisdn_p) throws RavelException
  {
    final String methodName = "PG_IWSRESSOURCES.P_001_Consult_TYPMSI_FROM_Type"; //$NON-NLS-1$

    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall("{call PG_IWSRESSOURCES.P_001_Consult_TYPMSI_FROM_Type(?,?,?,?,?,?) }")) //$NON-NLS-1$
    {

      SpiritLogEvent inputLog = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, "P_001_Consult_TYPMSI_FROM_Type"); //$NON-NLS-1$
      inputLog.addField(TYPMSISDN, typeMsisdn_p, false);
      RavelLogger.log(inputLog);

      cs.setQueryTimeout(_readTimeoutSec);

      cs.setInt(TYPMSISDN, typeMsisdn_p);

      cs.registerOutParameter("cursorx", OracleTypes.CURSOR); //$NON-NLS-1$
      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();

      TypeMsisdn typeMsisdn = null;

      Retour retour = getRetour(cs);

      ResultSet rs = (ResultSet) cs.getObject("cursorx");
      if (rs.next())
      {
        typeMsisdn = new TypeMsisdn(rs);
      }

      SpiritLogEvent outputLog = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, "P_001_Consult_TYPMSI_FROM_Type"); //$NON-NLS-1$
      outputLog.addField("Retour", retour, false); //$NON-NLS-1$

      if (typeMsisdn != null)
      {
        outputLog.addField("TypeMsisdn", typeMsisdn.toString(), false); //$NON-NLS-1$
      }
      RavelLogger.log(outputLog);

      return new ConnectorResponse<>(typeMsisdn, retour);

    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("TYPMSI:").append(typeMsisdn_p).toString()); //$NON-NLS-1$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("TYPMSI:").append(typeMsisdn_p).toString()); //$NON-NLS-1$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("GDRConnector.ERREUR_GDR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("TYPMSI:").append(typeMsisdn_p).toString()); //$NON-NLS-1$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append("TYPMSI:").append(typeMsisdn_p).toString()); //$NON-NLS-1$
    }
  }

  /**
   * Reserve MSISDN from mode Critere
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param instanceCliente_p
   *          instanceCliente
   * @param nbMsisdn_p
   *          nbMsisdn
   * @param mode_p
   *          mode
   * @param typeMsisdn_p
   *          typeMsisdn
   * @param critereRecherche_p
   *          critereRecherche
   * @param typeReservation_p
   *          typeReservation
   * @param etatCible_p
   *          etatCible
   * @param dureeReservation_p
   *          dureeReservation
   * @param dureeReservationTemporaire_p
   *          dureeReservationTemporaire
   * @param idReservationMSISDN_p
   *          idReservationMSISDN
   * @param idtdermod_p
   *          idtdermod
   * @return {@link ConnectorResponse}
   * @throws RavelException
   *           exception
   */
  public ConnectorResponse<List<MSISDN>, Retour> ps002ReserveMSISDNFROMModeCritere(Tracabilite tracabilite_p, String instanceCliente_p, Integer nbMsisdn_p, String mode_p, Integer typeMsisdn_p, Integer critereRecherche_p, Integer typeReservation_p, String etatCible_p, String dureeReservation_p, int dureeReservationTemporaire_p, String idReservationMSISDN_p, String idtdermod_p) throws RavelException
  {
    final String methodName = "PG_IWSRESSOURCES.P_002_Reserve_MSISDN_FROM_Mode"; //$NON-NLS-1$

    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall("{call PG_IWSRESSOURCES.P_002_Reserve_MSISDN_FROM_Mode(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}")) //$NON-NLS-1$
    {
      SpiritLogEvent inputLog = new SpiritLogEvent(LogSeverity.INFO, tracabilite_p, "P_002_Reserve_MSISDN_FROM_Mode"); //$NON-NLS-1$
      inputLog.addField("InstanceCliente", instanceCliente_p, false); //$NON-NLS-1$
      inputLog.addField("NbMsisdn", nbMsisdn_p, false); //$NON-NLS-1$
      inputLog.addField("Mode", mode_p, false); //$NON-NLS-1$
      inputLog.addField("TypeMsisdn", typeMsisdn_p, false); //$NON-NLS-1$
      inputLog.addField("CritereRecherche", critereRecherche_p, false); //$NON-NLS-1$
      inputLog.addField("TypeReservation", typeReservation_p, false); //$NON-NLS-1$
      inputLog.addField("EtatCible", etatCible_p, false); //$NON-NLS-1$
      inputLog.addField("DureeReservation", dureeReservation_p, false); //$NON-NLS-1$
      inputLog.addField("IdReservationMSISDN", idReservationMSISDN_p, false); //$NON-NLS-1$
      inputLog.addField("Idtdermod", idtdermod_p, false); //$NON-NLS-1$
      RavelLogger.log(inputLog);

      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("pi_InstanceCliente", instanceCliente_p); //$NON-NLS-1$
      cs.setInt("pi_NbMsisdn", nbMsisdn_p); //$NON-NLS-1$
      cs.setString("pi_Mode", mode_p); //$NON-NLS-1$
      cs.setInt("pi_TypeMsisdn", typeMsisdn_p); //$NON-NLS-1$
      cs.setInt("pi_CritereRecherche", critereRecherche_p); //$NON-NLS-1$
      cs.setInt("pi_TypeReservation", typeReservation_p); //$NON-NLS-1$
      cs.setString("pi_EtatCible", etatCible_p); //$NON-NLS-1$
      cs.setString("pi_DureeReservation", dureeReservation_p); //$NON-NLS-1$
      cs.setString("pi_IdReservationMSISDN", idReservationMSISDN_p); //$NON-NLS-1$
      cs.setInt("pi_DureeTemporaire", dureeReservationTemporaire_p); //$NON-NLS-1$
      cs.setString("pi_Idtdermod", idtdermod_p); //$NON-NLS-1$

      cs.registerOutParameter("po_Cursorx", OracleTypes.CURSOR); //$NON-NLS-1$
      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();

      List<MSISDN> msisdnList = new ArrayList<>();

      Retour retour = getRetour(cs);

      ResultSet rs = (ResultSet) cs.getObject("po_Cursorx");
      if (StringConstants.OK.equals(retour.getResultat()) && (rs != null))
      {
        while (rs.next())
        {
          MSISDN msisdn = new MSISDN(rs);
          msisdnList.add(msisdn);
        }
      }

      SpiritLogEvent outputLog = new SpiritLogEvent(LogSeverity.INFO, tracabilite_p, "P_002_Reserve_MSISDN_FROM_Mode"); //$NON-NLS-1$
      outputLog.addField("Retour", retour, false); //$NON-NLS-1$
      RavelLogger.log(outputLog);

      return new ConnectorResponse<>(msisdnList, retour);

    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("InstanceCliente:").append(instanceCliente_p).append(" | NbMsisdn:").append(nbMsisdn_p).append(" | Mode:").append(mode_p).append(" | TypeMsisdn").append(typeMsisdn_p).append(" | CritereRecherche:").append(critereRecherche_p).append(" | TypeReservation:").append(typeReservation_p).append(" | EtatCible:").append(etatCible_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$

      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("InstanceCliente:").append(instanceCliente_p).append(" | NbMsisdn:").append(nbMsisdn_p).append(" | Mode:").append(mode_p).append(" | TypeMsisdn").append(typeMsisdn_p).append(" | CritereRecherche:").append(critereRecherche_p).append(" | TypeReservation:").append(typeReservation_p).append(" | EtatCible:").append(etatCible_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$

      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("GDRConnector.ERREUR_GDR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("InstanceCliente:").append(instanceCliente_p).append(" | NbMsisdn:").append(nbMsisdn_p).append(" | Mode:").append(mode_p).append(" | TypeMsisdn").append(typeMsisdn_p).append(" | CritereRecherche:").append(critereRecherche_p).append(" | TypeReservation:").append(typeReservation_p).append(" | EtatCible:").append(etatCible_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$

      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append("InstanceCliente:").append(instanceCliente_p).append(" | NbMsisdn:").append(nbMsisdn_p).append(" | Mode:").append(mode_p).append(" | TypeMsisdn").append(typeMsisdn_p).append(" | CritereRecherche:").append(critereRecherche_p).append(" | TypeReservation:").append(typeReservation_p).append(" | EtatCible:").append(etatCible_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$
    }
    catch (NumberFormatException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append("InstanceCliente:").append(instanceCliente_p).append(" | NbMsisdn:").append(nbMsisdn_p).append(" | Mode:").append(mode_p).append(" | TypeMsisdn").append(typeMsisdn_p).append(" | CritereRecherche:").append(critereRecherche_p).append(" | TypeReservation:").append(typeReservation_p).append(" | EtatCible:").append(etatCible_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$
    }
  }

  /**
   * Resiliation MSISDN
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param msisdn_p
   *          msisdn
   * @return {@link ConnectorResponse}
   * @throws RavelException
   *           exception
   */
  public ConnectorResponse<String, Retour> ps003ResiliationMSISDN(Tracabilite tracabilite_p, String msisdn_p) throws RavelException
  {
    final String methodName = "PG_IWSRESSOURCES.P_003_Resiliation_MSISDN"; //$NON-NLS-1$

    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall("{call PG_IWSRESSOURCES.P_003_Resiliation_MSISDN(?,?,?,?,?,?) }")) //$NON-NLS-1$
    {
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("pi_MSISDN", msisdn_p); //$NON-NLS-1$

      cs.registerOutParameter("Etat_Final", OracleTypes.NVARCHAR); //$NON-NLS-1$
      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();
      Retour retour = getRetour(cs);
      String etatFinal = cs.getString("Etat_Final"); //$NON-NLS-1$

      SpiritLogEvent outputLog = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, "P_003_Resiliation_MSISDN"); //$NON-NLS-1$
      outputLog.addField("Retour", retour, false); //$NON-NLS-1$
      if (StringConstants.OK.equals(retour.getResultat()))
      {
        outputLog.addField("Etat_Final", etatFinal, false); //$NON-NLS-1$
      }
      RavelLogger.log(outputLog);

      return new ConnectorResponse<>(etatFinal, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("MSISDN:").append(msisdn_p).toString()); //$NON-NLS-1$

      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("MSISDN:").append(msisdn_p).toString()); //$NON-NLS-1$

      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("GDRConnector.ERREUR_GDR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("MSISDN:").append(msisdn_p).toString()); //$NON-NLS-1$

      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append("MSISDN:").append(msisdn_p).toString()); //$NON-NLS-1$
    }
  }

  /**
   * Get IMSI from ICCID
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param iccid_p
   *          iccid
   * @return {@link ConnectorResponse}
   * @throws RavelException
   *           exception
   */
  public ConnectorResponse<String, Retour> ps004GetIMSIFromICCID(Tracabilite tracabilite_p, String iccid_p) throws RavelException
  {
    final String methodName = "PG_IWSRESSOURCES.P_004_GetIMSIFromICCID"; //$NON-NLS-1$

    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall("{call PG_IWSRESSOURCES.P_004_GetIMSIFromICCID(?,?,?,?,?,?) }")) //$NON-NLS-1$
    {
      cs.setQueryTimeout(_readTimeoutSec);
      cs.setString("pi_ICCID", iccid_p); //$NON-NLS-1$
      cs.registerOutParameter("po_IMSI", OracleTypes.NVARCHAR); //$NON-NLS-1$
      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();

      Retour retour = getRetour(cs);
      String imsi = cs.getString("po_IMSI"); //$NON-NLS-1$

      SpiritLogEvent outputLog = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, methodName);
      outputLog.addField("Retour", retour, false); //$NON-NLS-1$

      if (StringConstants.OK.equals(retour.getResultat()))
      {
        outputLog.addField("po_IMSI", imsi, false); //$NON-NLS-1$
      }
      RavelLogger.log(outputLog);

      return new ConnectorResponse<>(imsi, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("ICCID:").append(iccid_p).toString()); //$NON-NLS-1$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SELECT_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("ICCID:").append(iccid_p).toString()); //$NON-NLS-1$

      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("GDRConnector.ERREUR_GDR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("ICCID:").append(iccid_p).toString()); //$NON-NLS-1$

      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append("ICCID:").append(iccid_p).toString()); //$NON-NLS-1$
    }
  }

  /**
   * Consult Carte Profile
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param iccid_p
   *          iccid
   * @param imsi_p
   *          imsi
   * @return {@link ConnectorResponse}
   * @throws RavelException
   *           exception
   */
  public ConnectorResponse<List<CarteProfileData>, Retour> ps005ConsultCarteProfile(Tracabilite tracabilite_p, String iccid_p, String imsi_p) throws RavelException
  {
    final String methodName = "PG_IWSRESSOURCES.P_005_CONSULT_CARTE_PROFILE"; //$NON-NLS-1$
    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall(String.format("{call %s(?,?,?,?,?,?,?) }", methodName))) //$NON-NLS-1$
    {
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("pi_ICCID", iccid_p); //$NON-NLS-1$
      cs.setString("pi_IMSI", imsi_p); //$NON-NLS-1$

      cs.registerOutParameter(PO_RESULT, OracleTypes.CURSOR);
      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();
      List<CarteProfileData> cpdList = new ArrayList<>();

      Retour retour = getRetour(cs);

      ResultSet rs = (ResultSet) cs.getObject(PO_RESULT);
      if (StringConstants.OK.equals(retour.getResultat()) && (rs != null))
      {
        while (rs.next())
        {
          cpdList.add(new CarteProfileData(rs));
        }
      }

      return new ConnectorResponse<>(cpdList, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("ICCID:").append(iccid_p).append(" ,IMSI:").append(imsi_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SELECT_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("ICCID:").append(iccid_p).append(" ,IMSI:").append(imsi_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$

      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("GDRConnector.ERREUR_GDR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("ICCID:").append(iccid_p).append(" ,IMSI:").append(imsi_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$

      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append("ICCID:").append(iccid_p).toString()); //$NON-NLS-1$
    }
  }

  /**
   * Consult MSISDN
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param msisdn_p
   *          msisdn
   * @return {@link ConnectorResponse}
   * @throws RavelException
   *           exception
   */
  public ConnectorResponse<MSISDN, Retour> ps006ConsultMSISDN(Tracabilite tracabilite_p, String msisdn_p) throws RavelException
  {
    final String methodName = "PG_IWSRESSOURCES.P_006_Consult_MSISDN"; //$NON-NLS-1$

    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall("{call PG_IWSRESSOURCES.P_006_Consult_MSISDN(?,?,?,?,?,?) }")) //$NON-NLS-1$
    {
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("pi_NUMTEL", msisdn_p); //$NON-NLS-1$

      cs.registerOutParameter(PO_RESULT, OracleTypes.CURSOR);

      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();

      Retour retour = getRetour(cs);
      MSISDN msisdn = null;

      ResultSet rs = (ResultSet) cs.getObject(PO_RESULT);
      if (StringConstants.OK.equals(retour.getResultat()) && (rs != null))
      {
        while (rs.next())
        {
          long msisdn_c = rs.getLong("NUMTEL"); //$NON-NLS-1$
          int msisdnType_c = rs.getInt("TYPMSI"); //$NON-NLS-1$
          int identifiantHlr_c = rs.getInt("IDTHLR"); //$NON-NLS-1$
          String commande_c = rs.getString("IDTCMDMSI"); //$NON-NLS-1$
          int identifiantInterne_c = rs.getInt("IDTACNMSI"); //$NON-NLS-1$
          String etatProvMsisdn_c = rs.getString("ETAMSI"); //$NON-NLS-1$
          Date dateDernierChangement_c = new Date(rs.getTimestamp("DATETA").getTime()); //$NON-NLS-1$
          int dernierDigits_c = rs.getInt("DRNDGT"); //$NON-NLS-1$
          String etatHlr_c = rs.getString("ETAHLR"); //$NON-NLS-1$
          String etatCommercial_c = rs.getString("ETACOM"); //$NON-NLS-1$
          String etatPortabilite_c = rs.getString("ETAPRT"); //$NON-NLS-1$
          String idtdermod_c = rs.getString("IDTDERMOD"); //$NON-NLS-1$
          msisdn = new MSISDN(msisdn_c, msisdnType_c, identifiantHlr_c, commande_c, identifiantInterne_c, etatProvMsisdn_c, dateDernierChangement_c, dernierDigits_c, etatHlr_c, etatCommercial_c, etatPortabilite_c, idtdermod_c);
        }
      }

      SpiritLogEvent outputLog = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, methodName);
      outputLog.addField("Retour", retour, false); //$NON-NLS-1$

      if (msisdn != null)
      {
        outputLog.addField("pi_NUMTEL", msisdn.getMsisdn().toString(), false); //$NON-NLS-1$
      }
      else if (StringConstants.OK.equals(retour.getResultat()))
      {
        retour.setResultat(StringConstants.KO);
        retour.setCategorie(IMegConsts.CAT3);
        retour.setDiagnostic("DONNEE_INCONNUE"); //$NON-NLS-1$
        retour.setLibelle("Le MSISDN " + msisdn_p + " en entree n'est pas connu"); //$NON-NLS-1$ //$NON-NLS-2$
      }
      RavelLogger.log(outputLog);

      return new ConnectorResponse<>(msisdn, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("MSISDN:").append(msisdn_p).toString()); //$NON-NLS-1$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SELECT_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("MSISDN:").append(msisdn_p).toString()); //$NON-NLS-1$

      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("GDRConnector.ERREUR_GDR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("MSISDN:").append(msisdn_p).toString()); //$NON-NLS-1$

      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append("MSISDN:").append(msisdn_p).toString()); //$NON-NLS-1$
    }
  }

  /**
   * Consult duree quarantaine
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param typeMSISDN_p
   *          typeMSISDN
   * @param instanceCliente_p
   *          instanceCliente
   * @return {@link ConnectorResponse}
   * @throws RavelException
   *           exception
   */
  public ConnectorResponse<DURMSI, Retour> ps007ConsultDureeQuarantaine(Tracabilite tracabilite_p, Integer typeMSISDN_p, String instanceCliente_p) throws RavelException
  {
    final String methodName = "PG_IWSRESSOURCES.P_007_CONSULT_DUREE_QUAR"; //$NON-NLS-1$

    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall("{call PG_IWSRESSOURCES.P_007_CONSULT_DUREE_QUAR(?,?,?,?,?,?,?) }")) //$NON-NLS-1$
    {
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setInt("pi_TYPMSI", typeMSISDN_p); //$NON-NLS-1$
      cs.setString("pi_IDTIST", instanceCliente_p); //$NON-NLS-1$

      cs.registerOutParameter(PO_RESULT, OracleTypes.CURSOR);

      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();

      Retour retour = getRetour(cs);
      DURMSI durmsi = null;

      ResultSet rs = (ResultSet) cs.getObject(PO_RESULT);
      if (StringConstants.OK.equals(retour.getResultat()) && (rs != null))
      {
        while (rs.next())
        {
          durmsi = new DURMSI(rs);
        }
      }

      SpiritLogEvent outputLog = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, methodName);
      outputLog.addField("Retour", retour, false); //$NON-NLS-1$

      if (StringConstants.OK.equals(retour.getResultat()) && (durmsi != null))
      {
        outputLog.addField("durmsi", durmsi.toString(), false); //$NON-NLS-1$
      }
      RavelLogger.log(outputLog);

      return new ConnectorResponse<>(durmsi, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("typeMSISDN:").append(typeMSISDN_p).append(", instanceCliente:").append(instanceCliente_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SELECT_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("typeMSISDN:").append(typeMSISDN_p).append(", instanceCliente:").append(instanceCliente_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$

      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("GDRConnector.ERREUR_GDR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("typeMSISDN:").append(typeMSISDN_p).append(", instanceCliente:").append(instanceCliente_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$

      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append("typeMSISDN:").append(typeMSISDN_p).append(", instanceCliente:").append(instanceCliente_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$
    }
  }

  /**
   * Consult latest historique etat MSISDN
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param numtel_p
   *          numtel
   * @return {@link ConnectorResponse}
   * @throws RavelException
   *           exception
   */
  public ConnectorResponse<String, Retour> ps008ConsultLatestHistoriqueEtatMSISDN(Tracabilite tracabilite_p, String numtel_p) throws RavelException
  {
    final String methodName = "PG_IWSRESSOURCES.P_008_ConsultLastHistEtaMSISDN"; //$NON-NLS-1$

    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall("{call PG_IWSRESSOURCES.P_008_ConsultLastHistEtaMSISDN(?,?,?,?,?,?) }")) //$NON-NLS-1$
    {
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("pi_NUMTEL", numtel_p); //$NON-NLS-1$

      cs.registerOutParameter("po_IDTIST", OracleTypes.NVARCHAR); //$NON-NLS-1$

      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();

      Retour retour = getRetour(cs);
      String instanceClient = cs.getString("po_IDTIST"); //$NON-NLS-1$

      SpiritLogEvent outputLog = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, methodName);
      outputLog.addField("Retour", retour, false); //$NON-NLS-1$

      if (instanceClient != null)
      {
        outputLog.addField("po_IDTIST", instanceClient, false); //$NON-NLS-1$
      }
      RavelLogger.log(outputLog);

      return new ConnectorResponse<>(instanceClient, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("NUMTEL:").append(numtel_p).toString()); //$NON-NLS-1$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SELECT_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("NUMTEL:").append(numtel_p).toString()); //$NON-NLS-1$

      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("GDRConnector.ERREUR_GDR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("NUMTEL:").append(numtel_p).toString()); //$NON-NLS-1$

      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append("NUMTEL:").append(numtel_p).toString()); //$NON-NLS-1$
    }
  }

  /**
   * Get ICCID from IMSI
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param imsi_p
   *          imsi
   * @return {@link ConnectorResponse}
   * @throws RavelException
   *           exception
   */
  public ConnectorResponse<String, Retour> ps009GetICCIDFromIMSI(Tracabilite tracabilite_p, String imsi_p) throws RavelException
  {
    final String methodName = "PG_IWSRESSOURCES.P_009_GetICCIDFromIMSI"; //$NON-NLS-1$

    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall("{call PG_IWSRESSOURCES.P_009_GetICCIDFromIMSI(?,?,?,?,?,?) }")) //$NON-NLS-1$
    {
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("pi_IMSI", imsi_p); //$NON-NLS-1$

      cs.registerOutParameter("po_ICCID", OracleTypes.NVARCHAR); //$NON-NLS-1$

      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();

      Retour retour = getRetour(cs);
      String iccid = cs.getString("po_ICCID"); //$NON-NLS-1$

      SpiritLogEvent outputLog = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, methodName);
      outputLog.addField("Retour", retour, false); //$NON-NLS-1$

      if (StringConstants.OK.equals(retour.getResultat()))
      {
        outputLog.addField("po_ICCID", iccid, false); //$NON-NLS-1$
      }
      RavelLogger.log(outputLog);

      return new ConnectorResponse<>(iccid, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IMSI:").append(imsi_p).toString()); //$NON-NLS-1$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SELECT_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IMSI:").append(imsi_p).toString()); //$NON-NLS-1$

      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("GDRConnector.ERREUR_GDR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IMSI:").append(imsi_p).toString()); //$NON-NLS-1$

      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append("IMSI:").append(imsi_p).toString()); //$NON-NLS-1$
    }
  }

  /**
   * Reattribuer MSISDN
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param numtel_p
   *          numtel
   * @param etatCibleMsisdn_p
   *          etatCibleMsisdn
   * @param etatCibleCom_p
   *          etatCibleCom
   * @param etatCiblePorta_p
   *          etatCiblePorta
   * @param objetModification_p
   *          objetModification
   * @param instanceCliente_p
   *          instanceCliente
   * @return {@link ConnectorResponse}
   * @throws RavelException
   *           exception
   */
  public ConnectorResponse<String, Retour> ps010ReattribuerMSISDN(Tracabilite tracabilite_p, long numtel_p, String etatCibleMsisdn_p, String etatCibleCom_p, String etatCiblePorta_p, Integer objetModification_p, String instanceCliente_p) throws RavelException
  {
    final String methodName = "PG_IWSRESSOURCES.P_010_ReattribuerMSISDN"; //$NON-NLS-1$

    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall("{call PG_IWSRESSOURCES.P_010_ReattribuerMSISDN(?,?,?,?,?,?,?,?,?,?) }")) //$NON-NLS-1$
    {
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setLong("pi_Numtel", numtel_p); //$NON-NLS-1$
      cs.setString("pi_EtatCibleMsisdn", etatCibleMsisdn_p); //$NON-NLS-1$
      cs.setString("pi_EtatCibleCom", etatCibleCom_p); //$NON-NLS-1$
      cs.setString("pi_EtatCiblePorta", etatCiblePorta_p); //$NON-NLS-1$
      cs.setInt("pi_ObjetModification", objetModification_p); //$NON-NLS-1$
      cs.setString("pi_InstanceCliente", instanceCliente_p); //$NON-NLS-1$

      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();

      Retour retour = getRetour(cs);

      SpiritLogEvent outputLog = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, methodName);
      outputLog.addField("Retour", retour, false); //$NON-NLS-1$
      RavelLogger.log(outputLog);

      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("NUMTEL:").append(numtel_p).toString()); //$NON-NLS-1$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SELECT_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("NUMTEL:").append(numtel_p).toString()); //$NON-NLS-1$

      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("GDRConnector.ERREUR_GDR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("NUMTEL:").append(numtel_p).toString()); //$NON-NLS-1$

      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append("NUMTEL:").append(numtel_p).toString()); //$NON-NLS-1$
    }
  }

  /**
   * Update SIM from ICCID
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param iccid_p
   *          iccid
   * @param etatSimCible_p
   *          etatSimCible
   * @param objetModification_p
   *          objetModification
   * @param etatComCible_p
   *          etatComCible
   * @param etatPorCible_p
   *          etatPorCible
   * @param identifiantModif_p
   *          identifiantModif
   * @param instanceCliente_p
   *          instanceCliente
   * @return {@link ConnectorResponse}
   * @throws RavelException
   *           exception
   */
  public ConnectorResponse<String, Retour> ps011UpdateSIMFromICCID(Tracabilite tracabilite_p, String iccid_p, String etatSimCible_p, Integer objetModification_p, String etatComCible_p, String etatPorCible_p, String identifiantModif_p, String instanceCliente_p) throws RavelException
  {
    final String methodName = "PG_IWSRESSOURCES.P_011_UpdateSimFromIccid"; //$NON-NLS-1$

    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall("{call PG_IWSRESSOURCES.P_011_UpdateSimFromIccid(?,?,?,?,?,?,?,?,?,?,?) }")) //$NON-NLS-1$
    {
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("pi_Iccid", iccid_p); //$NON-NLS-1$
      cs.setString("pi_EtatSimCible", etatSimCible_p); //$NON-NLS-1$
      cs.setInt("pi_ObjetModification", objetModification_p); //$NON-NLS-1$
      cs.setString("pi_EtatComCible", etatComCible_p); //$NON-NLS-1$
      cs.setString("pi_EtatPorCible", etatPorCible_p); //$NON-NLS-1$
      cs.setString("pi_IdentifiantModif", identifiantModif_p); //$NON-NLS-1$
      cs.setString("pi_InstanceCliente", instanceCliente_p); //$NON-NLS-1$

      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();

      Retour retour = getRetour(cs);

      SpiritLogEvent outputLog = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, methodName);
      outputLog.addField("Retour", retour, false); //$NON-NLS-1$
      RavelLogger.log(outputLog);

      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("ICCID:").append(iccid_p).toString()); //$NON-NLS-1$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SELECT_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("ICCID:").append(iccid_p).toString()); //$NON-NLS-1$

      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("GDRConnector.ERREUR_GDR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("ICCID:").append(iccid_p).toString()); //$NON-NLS-1$

      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append("ICCID:").append(iccid_p).toString()); //$NON-NLS-1$
    }
  }

  /**
   * Get ICCID From IMSI
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param imsi_p
   *          imsi
   * @return {@link ConnectorResponse}
   * @throws RavelException
   *           exception
   */
  public ConnectorResponse<Sim, Retour> ps012GetICCIDFromIMSI(Tracabilite tracabilite_p, String imsi_p) throws RavelException
  {
    final String methodName = "PG_IWSRESSOURCES.P_012_GetICCIDFromIMSI"; //$NON-NLS-1$

    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall("{call PG_IWSRESSOURCES.P_012_GetICCIDFromIMSI(?,?,?,?,?,?) }")) //$NON-NLS-1$
    {
      cs.setQueryTimeout(_readTimeoutSec);
      cs.setString("pi_IMSI", imsi_p); //$NON-NLS-1$

      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(PO_RESULT, OracleTypes.CURSOR);

      cs.execute();

      Retour retour = getRetour(cs);
      ResultSet rs = (ResultSet) cs.getObject(PO_RESULT);
      Sim sim = null;
      SpiritLogEvent outputLog = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, methodName);
      if (StringConstants.OK.equals(retour.getResultat()) && (rs != null))
      {
        if (rs.next())
        {
          sim = new Sim(rs);

        }

        if (sim != null)
        {
          outputLog.addField("po_ICCID", sim.getSim(), false);//$NON-NLS-1$
        }
      }

      outputLog.addField("Retour", retour, false); //$NON-NLS-1$
      RavelLogger.log(outputLog);

      return new ConnectorResponse<>(sim, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IMSI:").append(imsi_p).toString()); //$NON-NLS-1$

      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SELECT_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IMSI:").append(imsi_p).toString()); //$NON-NLS-1$

      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("GDRConnector.ERREUR_GDR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("IMSI:").append(imsi_p).toString()); //$NON-NLS-1$

      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append("IMSI:").append(imsi_p).toString()); //$NON-NLS-1$
    }
  }

  /**
   * Update etat MSISDN
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param numtel_p
   *          numtel
   * @param etatCibleMsisdn_p
   *          etatCibleMsisdn
   * @param idtAcnMsi_p
   *          idtAcnMsi
   * @param instanceCliente_p
   *          instanceCliente
   * @param idtdermod_p
   *          idtdermod
   * @return {@link ConnectorResponse}
   * @throws RavelException
   *           exception
   */
  public ConnectorResponse<Boolean, Retour> ps013UpdateEtatMsisdn(Tracabilite tracabilite_p, Long numtel_p, String etatCibleMsisdn_p, Integer idtAcnMsi_p, String instanceCliente_p, String idtdermod_p) throws RavelException
  {
    final String methodName = "PG_IWSRESSOURCES.P_013_Update_EtatMsisdn"; //$NON-NLS-1$

    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall("{call PG_IWSRESSOURCES.P_013_Update_EtatMsisdn(?,?,?,?,?,?,?,?,?) }")) //$NON-NLS-1$
    {
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setLong("pi_Numtel", numtel_p); //$NON-NLS-1$
      cs.setString("pi_EtatCibleMsisdn", etatCibleMsisdn_p); //$NON-NLS-1$
      cs.setInt("pi_IdtAcnMsi", idtAcnMsi_p); //$NON-NLS-1$
      cs.setString("pi_InstanceCliente", instanceCliente_p); //$NON-NLS-1$
      cs.setString("pi_Idtdermod", idtdermod_p); //$NON-NLS-1$

      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();

      Retour retour = getRetour(cs);

      SpiritLogEvent outputLog = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, methodName);
      outputLog.addField("Retour", retour, false); //$NON-NLS-1$
      RavelLogger.log(outputLog);

      return new ConnectorResponse<>(true, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("NUMTEL:").append(numtel_p).toString()); //$NON-NLS-1$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SELECT_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_SUR_NON_REPONSE"), _readTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(false, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("NUMTEL:").append(numtel_p).toString()); //$NON-NLS-1$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("GDRConnector.ERREUR_GDR_AUCUNE_SESSION")); //$NON-NLS-1$
      return new ConnectorResponse<>(false, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("NUMTEL:").append(numtel_p).toString()); //$NON-NLS-1$
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_CONNEXION"), _connectTimeoutSec)); //$NON-NLS-1$
      return new ConnectorResponse<>(false, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append("NUMTEL:").append(numtel_p).toString()); //$NON-NLS-1$
    }
  }

  /**
   * Build a log entry and throws an {@link RavelException} for a technical problem.
   *
   * @param rs
   *          resulset
   * @param listRecs_p
   *          list
   * @throws SQLException
   *           exception
   */
  private void mapSimrecordResults(ResultSet rs, ArrayList<SimRecord> listRecs_p) throws SQLException
  {
    SimRecord simRecord = new SimRecord();
    simRecord.setSim(rs.getString("sim")); //$NON-NLS-1$
    simRecord.setIdthlr(rs.getLong("idthlr"));//$NON-NLS-1$
    simRecord.setIdtcmd(rs.getLong("idtcmd"));//$NON-NLS-1$
    simRecord.setEtasim(rs.getString("etasim"));//$NON-NLS-1$
    simRecord.setIms(rs.getString("ims"));//$NON-NLS-1$
    simRecord.setPin(padToLeft(String.valueOf(rs.getLong("pin")), 4));//$NON-NLS-1$
    simRecord.setPin002(padToLeft(String.valueOf(rs.getLong("pin002")), 4));//$NON-NLS-1$
    simRecord.setPuk(padToLeft(String.valueOf(rs.getLong("puk")), 8));//$NON-NLS-1$
    simRecord.setPuk002(padToLeft(String.valueOf(rs.getLong("puk002")), 8));//$NON-NLS-1$
    String codadm = rs.getString("codadm"); //$NON-NLS-1$
    if (codadm == null)
    {
      codadm = StringConstants.EMPTY_STRING;
    }
    simRecord.setCodadm(codadm);
    simRecord.setSimpoh(rs.getString("simpoh"));//$NON-NLS-1$
    simRecord.setIdtfab(rs.getString("idtfab"));//$NON-NLS-1$
    simRecord.setNomcrt(rs.getString("nomcrt"));//$NON-NLS-1$
    simRecord.setGnc(rs.getString("gnc"));//$NON-NLS-1$
    simRecord.setIdtprfele(rs.getLong("idtprfele"));//$NON-NLS-1$
    simRecord.setIdtprfgra(rs.getLong("idtprfgra"));//$NON-NLS-1$
    simRecord.setIdtcla(rs.getLong("idtcla"));//$NON-NLS-1$
    simRecord.setIdtart(rs.getString("idtart"));//$NON-NLS-1$
    String debsim = rs.getString("debsim"); //$NON-NLS-1$
    if (debsim == null)
    {
      debsim = StringConstants.EMPTY_STRING;
    }
    simRecord.setDebsim(debsim);
    String debims = rs.getString("debims"); //$NON-NLS-1$
    if (debims == null)
    {
      debims = StringConstants.EMPTY_STRING;
    }
    simRecord.setDebims(debims);
    simRecord.setQtecmd(rs.getLong("qtecmd"));//$NON-NLS-1$
    simRecord.setEtacmd(rs.getString("etacmd"));//$NON-NLS-1$
    String cletrp = rs.getString("cletrp"); //$NON-NLS-1$
    if (cletrp == null)
    {
      cletrp = StringConstants.EMPTY_STRING;
    }
    simRecord.setCletrp(cletrp);
    String cmtcmd = rs.getString("cmtcmd"); //$NON-NLS-1$
    if (cmtcmd == null)
    {
      cmtcmd = StringConstants.EMPTY_STRING;
    }
    simRecord.setCmtcmd(cmtcmd);
    listRecs_p.add(simRecord);
  }

  /**
   * adds '0' to the String until it is 8 char long
   *
   * @param codePinPuk_p
   *          The String to be completed
   * @param len
   *          The total length
   * @return The String with additional zeros on the left
   */
  private String padToLeft(String codePinPuk_p, int len)
  {
    return StringTools.pad(codePinPuk_p, len, PaddingDirection.LEFT, '0');
  }
}
