/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.gdr.structs;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;

import com.bytel.ravel.common.utils.DateTimeTools;
import com.bytel.spirit.common.connectors.gdr.structs.enumeration.EtatSMDP;
import com.bytel.spirit.common.connectors.gdr.structs.enumeration.PolicyAction;
import com.bytel.spirit.common.connectors.gdr.structs.enumeration.PolicyQualification;

/**
 *
 * @author lmerces
 * @version ($Revision$ $Date$)
 */
public class HISETASIM
{
  /**
   * Constant with the value of the Table Column for IDTSIM
   */
  public static final String IDTSIM = "IDTSIM"; //$NON-NLS-1$

  /**
   * Constant with the value of the Table Column for IDTSIM
   */
  public static final String IDTACNSIM = "IDTACNSIM"; //$NON-NLS-1$

  /**
   * Constant with the value of the Table Column for ETASIM
   */
  public static final String ETASIM = "ETASIM"; //$NON-NLS-1$

  /**
   * Constant with the value of the Table Column for IDTIST
   */
  public static final String IDTIST = "IDTIST"; //$NON-NLS-1$

  /**
   * Constant with the value of the Table Column for DAT
   */
  public static final String DAT = "DAT"; //$NON-NLS-1$

  /**
   * Constant with the value of the Table Column for ETASMDP
   */
  public static final String ETASMDP = "ETASMDP"; //$NON-NLS-1$

  /**
   * Constant with the value of the Table Column for ETANOTIF
   */
  public static final String ETANOTIF = "ETANOTIF"; //$NON-NLS-1$

  /**
   * Constant with the value of the Table Column for POLICYETAT
   */
  public static final String POLICYETAT = "POLICYETAT"; //$NON-NLS-1$

  /**
   * Constant with the value of the Table Column for POLICYHABILITATION
   */
  public static final String POLICYHABILITATION = "POLICYHABILITATION"; //$NON-NLS-1$

  /**
   * Identifiant interne de la SIM
   */
  String _idtSim;

  /**
   * Identifiant de l'action sur le MSISDN
   */
  Long _idtAcnSim;

  /**
   * Etat de la SIM
   */
  String _etaSim;

  /**
   * Identifiant de l'instance client
   */
  String _idtIst;

  /**
   * Date du changement d'etat
   */
  LocalDateTime _dateChangementEtatPlateforme;

  /**
   * Etat de la SIM sur le SMDP ou SMDP+
   */
  EtatSMDP _etaSmdp;

  /**
   * Etat de la notification de telechargement de la SIM
   */
  String _etaNotif;

  /**
   * Etat sur lequel porte la policyRule (action)
   */
  PolicyAction _policyEtat;

  /**
   * Action possible sur l'état de la policyRule (qualification)
   */
  PolicyQualification _policyHabilitation;

  /**
   * Constructor
   */
  public HISETASIM()
  {
    super();
  }

  /**
   * Create a new instance HISETASIM from a ResultSet
   *
   * @param rs
   *          ResultSet with the information
   * @throws SQLException
   *           in error SQL
   */
  public HISETASIM(ResultSet rs) throws SQLException
  {
    super();
    this._idtSim = rs.getString(HISETASIM.IDTSIM);
    this._idtAcnSim = rs.getLong(HISETASIM.IDTACNSIM);
    this._etaSim = rs.getString(HISETASIM.ETASIM);
    this._idtIst = rs.getString(HISETASIM.IDTIST);
    this._dateChangementEtatPlateforme = DateTimeTools.toLocalDateTime(rs.getTimestamp(HISETASIM.DAT));
    this._etaSmdp = EtatSMDP.fromString(rs.getString(HISETASIM.ETASMDP));
    this._etaNotif = rs.getString(HISETASIM.ETANOTIF);
    this._policyEtat = PolicyAction.fromString(rs.getString(HISETASIM.POLICYETAT));
    this._policyHabilitation = PolicyQualification.fromString(rs.getString(HISETASIM.POLICYHABILITATION));
  }

  /**
   * @param idtSim_p
   *          the idtSim
   * @param idtAcnSim_p
   *          the idtAcnSim
   * @param etaSim_p
   *          the etaSim
   * @param idtIst_p
   *          the idtIst
   * @param dateChangementEtatPlateforme_p
   *          the dateChangementEtatPlateforme
   * @param etaSmdp_p
   *          the etaSmdp
   * @param etaNotif_p
   *          the etaNotif
   * @param policyEtat_p
   *          the policyEtat
   * @param policyHabilitation_p
   *          the policyHabilitation
   */
  public HISETASIM(String idtSim_p, Long idtAcnSim_p, String etaSim_p, String idtIst_p, LocalDateTime dateChangementEtatPlateforme_p, EtatSMDP etaSmdp_p, String etaNotif_p, PolicyAction policyEtat_p, PolicyQualification policyHabilitation_p)
  {
    super();
    this._idtSim = idtSim_p;
    this._idtAcnSim = idtAcnSim_p;
    this._etaSim = etaSim_p;
    this._idtIst = idtIst_p;
    this._dateChangementEtatPlateforme = dateChangementEtatPlateforme_p;
    this._etaSmdp = etaSmdp_p;
    this._etaNotif = etaNotif_p;
    this._policyEtat = policyEtat_p;
    this._policyHabilitation = policyHabilitation_p;
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    HISETASIM other = (HISETASIM) obj;
    if (_dateChangementEtatPlateforme == null)
    {
      if (other._dateChangementEtatPlateforme != null)
      {
        return false;
      }
    }
    else if (!_dateChangementEtatPlateforme.equals(other._dateChangementEtatPlateforme))
    {
      return false;
    }
    if (_etaNotif == null)
    {
      if (other._etaNotif != null)
      {
        return false;
      }
    }
    else if (!_etaNotif.equals(other._etaNotif))
    {
      return false;
    }
    if (_etaSim == null)
    {
      if (other._etaSim != null)
      {
        return false;
      }
    }
    else if (!_etaSim.equals(other._etaSim))
    {
      return false;
    }
    if (_etaSmdp != other._etaSmdp)
    {
      return false;
    }
    if (_idtAcnSim == null)
    {
      if (other._idtAcnSim != null)
      {
        return false;
      }
    }
    else if (!_idtAcnSim.equals(other._idtAcnSim))
    {
      return false;
    }
    if (_idtIst == null)
    {
      if (other._idtIst != null)
      {
        return false;
      }
    }
    else if (!_idtIst.equals(other._idtIst))
    {
      return false;
    }
    if (_idtSim == null)
    {
      if (other._idtSim != null)
      {
        return false;
      }
    }
    else if (!_idtSim.equals(other._idtSim))
    {
      return false;
    }
    if (_policyEtat != other._policyEtat)
    {
      return false;
    }
    if (_policyHabilitation != other._policyHabilitation)
    {
      return false;
    }
    return true;
  }

  /**
   * @return the dateChangementEtatPlateforme
   */
  public LocalDateTime getDateChangementEtatPlateforme()
  {
    return _dateChangementEtatPlateforme;
  }

  /**
   * @return the etaNotif
   */
  public String getEtaNotif()
  {
    return _etaNotif;
  }

  /**
   * @return the etaSim
   */
  public String getEtaSim()
  {
    return _etaSim;
  }

  /**
   * @return the etaSmdp
   */
  public EtatSMDP getEtaSmdp()
  {
    return _etaSmdp;
  }

  /**
   * @return the idtAcnSim
   */
  public Long getIdtAcnSim()
  {
    return _idtAcnSim;
  }

  /**
   * @return the idtIst
   */
  public String getIdtIst()
  {
    return _idtIst;
  }

  /**
   * @return the idtSim
   */
  public String getIdtSim()
  {
    return _idtSim;
  }

  /**
   * @return the policyEtat
   */
  public PolicyAction getPolicyEtat()
  {
    return _policyEtat;
  }

  /**
   * @return the policyHabilitation
   */
  public PolicyQualification getPolicyHabilitation()
  {
    return _policyHabilitation;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_dateChangementEtatPlateforme == null) ? 0 : _dateChangementEtatPlateforme.hashCode());
    result = (prime * result) + ((_etaNotif == null) ? 0 : _etaNotif.hashCode());
    result = (prime * result) + ((_etaSim == null) ? 0 : _etaSim.hashCode());
    result = (prime * result) + ((_etaSmdp == null) ? 0 : _etaSmdp.hashCode());
    result = (prime * result) + ((_idtAcnSim == null) ? 0 : _idtAcnSim.hashCode());
    result = (prime * result) + ((_idtIst == null) ? 0 : _idtIst.hashCode());
    result = (prime * result) + ((_idtSim == null) ? 0 : _idtSim.hashCode());
    result = (prime * result) + ((_policyEtat == null) ? 0 : _policyEtat.hashCode());
    result = (prime * result) + ((_policyHabilitation == null) ? 0 : _policyHabilitation.hashCode());
    return result;
  }

  /**
   * @param dateChangementEtatPlateforme_p
   *          the dateChangementEtatPlateforme to set
   */
  public void setDateChangementEtatPlateforme(LocalDateTime dateChangementEtatPlateforme_p)
  {
    _dateChangementEtatPlateforme = dateChangementEtatPlateforme_p;
  }

  /**
   * @param etaNotif_p
   *          the etaNotif to set
   */
  public void setEtaNotif(String etaNotif_p)
  {
    _etaNotif = etaNotif_p;
  }

  /**
   * @param etaSim_p
   *          the etaSim to set
   */
  public void setEtaSim(String etaSim_p)
  {
    _etaSim = etaSim_p;
  }

  /**
   * @param etaSmdp_p
   *          the etaSmdp to set
   */
  public void setEtaSmdp(EtatSMDP etaSmdp_p)
  {
    _etaSmdp = etaSmdp_p;
  }

  /**
   * @param idtAcnSim_p
   *          the idtAcnSim to set
   */
  public void setIdtAcnSim(Long idtAcnSim_p)
  {
    _idtAcnSim = idtAcnSim_p;
  }

  /**
   * @param idtIst_p
   *          the idtIst to set
   */
  public void setIdtIst(String idtIst_p)
  {
    _idtIst = idtIst_p;
  }

  /**
   * @param idtSim_p
   *          the idtSim to set
   */
  public void setIdtSim(String idtSim_p)
  {
    _idtSim = idtSim_p;
  }

  /**
   * @param policyEtat_p
   *          the policyEtat to set
   */
  public void setPolicyEtat(PolicyAction policyEtat_p)
  {
    _policyEtat = policyEtat_p;
  }

  /**
   * @param policyHabilitation_p
   *          the policyHabilitation to set
   */
  public void setPolicyHabilitation(PolicyQualification policyHabilitation_p)
  {
    _policyHabilitation = policyHabilitation_p;
  }

  @Override
  public String toString()
  {
    return "HISETASIM [_idtSim=" + _idtSim + ", _idtAcnSim=" + _idtAcnSim + ", _etaSim=" + _etaSim + ", _idtIst=" + _idtIst + ", _dateChangementEtatPlateforme=" + _dateChangementEtatPlateforme + ", _etaSmdp=" + _etaSmdp + ", _etaNotif=" + _etaNotif + ", _policyEtat=" + _policyEtat + ", _policyHabilitation=" + _policyHabilitation + "]"; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$ //$NON-NLS-10$
  }
}
