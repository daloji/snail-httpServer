/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.gdr.structs;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

/**
 *
 * @author dmonteir
 * @version ($Revision$ $Date$)
 */
public class MSISDN
{

  /**
   * Constant with the value of the Table Column for NUMTEL
   */
  public static final String NUMTEL = "NUMTEL"; //$NON-NLS-1$

  /**
   * Constant with the value of the Table Column for TYPMSI
   */
  public static final String TYPMSI = "TYPMSI"; //$NON-NLS-1$

  /**
   * Constant with the value of the Table Column for IDTHLR
   */
  public static final String IDTHLR = "IDTHLR"; //$NON-NLS-1$

  /**
   * Constant with the value of the Table Column for IDTCMDMSI
   */
  public static final String IDTCMDMSI = "IDTCMDMSI"; //$NON-NLS-1$

  /**
   * Constant with the value of the Table Column for IDTACNMSI
   */
  public static final String IDTACNMSI = "IDTACNMSI"; //$NON-NLS-1$

  /**
   * Constant with the value of the Table Column for ETAMSI
   */
  public static final String ETAMSI = "ETAMSI"; //$NON-NLS-1$

  /**
   * Constant with the value of the Table Column for DATETA
   */
  public static final String DATETA = "DATETA"; //$NON-NLS-1$

  /**
   * Constant with the value of the Table Column for DRNDGT
   */
  public static final String DRNDGT = "DRNDGT"; //$NON-NLS-1$

  /**
   * Constant with the value of the Table Column for ETAHLR
   */
  public static final String ETAHLR = "ETAHLR"; //$NON-NLS-1$

  /**
   * Constant with the value of the Table Column for ETACOM
   */
  public static final String ETACOM = "ETACOM"; //$NON-NLS-1$

  /**
   * Constant with the value of the Table Column for ETAPRT
   */
  public static final String ETAPRT = "ETAPRT"; //$NON-NLS-1$

  /**
   * Constant with the value of the Table Column for IDTDERMOD
   */
  public static final String IDTDERMOD = "IDTDERMOD"; //$NON-NLS-1$

  /**
   * MSISDN param
   */
  Long _msisdn;

  /**
   * Identifiant du type de MSISDN
   */
  Integer _msisdnType;

  /**
   * Identifiant du HLR (cf. table HLR)
   */
  Integer _identifiantHlr;

  /**
   * Reference de la commande
   */
  String _commande;

  /**
   * Identifiant interne (cf. table ACNMSI)
   */
  Integer _identifiantInterne;

  /**
   * Etat de provisioning du MSISDN (cf. table ETAMSI)
   */
  String _etatProvMsisdn;

  /**
   * Date du dernier changement d etat
   */
  Date _dateDernierChangement;

  /**
   * 4 derniers Digits du MSISDN
   */
  Integer _dernierDigits;

  /**
   * Etat du HLR (marque non utilisee en interne dans le P3G)
   */
  String _etatHlr;

  /**
   * Etat commercial (cf. table ETACOM)
   */
  String _etatCommercial;

  /**
   * Etat de portabilite (cf. table ETAPRT)
   */
  String _etatPortabilite;

  /**
   * idtdermod
   */
  String _idtdermod;

  /**
   * Default Constructor
   */
  public MSISDN()
  {
    //do nothing
  }

  /**
   * @param msisdn_p
   *          the msisdn
   * @param msisdnType_p
   *          the msisdnType
   * @param identifiantHlr_p
   *          the identifiantHlr
   * @param commande_p
   *          the commande
   * @param identifiantInterne_p
   *          the identifiantInterne
   * @param etatProvMsisdn_p
   *          the etatProvMsisdn
   * @param dateDernierChangement_p
   *          the dateDernierChangement
   * @param dernierDigits_p
   *          the dernierDigits
   * @param etatHlr_p
   *          the etatHlr
   * @param etatCommercial_p
   *          the etatCommercial
   * @param etatPortabilite_p
   *          the etatPortabilite
   * @param idtdermod_p
   *          the idtdermod
   */
  public MSISDN(Long msisdn_p, Integer msisdnType_p, Integer identifiantHlr_p, String commande_p, Integer identifiantInterne_p, String etatProvMsisdn_p, Date dateDernierChangement_p, Integer dernierDigits_p, String etatHlr_p, String etatCommercial_p, String etatPortabilite_p, String idtdermod_p)
  {
    super();
    this._msisdn = msisdn_p;
    this._msisdnType = msisdnType_p;
    this._identifiantHlr = identifiantHlr_p;
    this._commande = commande_p;
    this._identifiantInterne = identifiantInterne_p;
    this._etatProvMsisdn = etatProvMsisdn_p;
    this._dateDernierChangement = dateDernierChangement_p;
    this._dernierDigits = dernierDigits_p;
    this._etatHlr = etatHlr_p;
    this._etatCommercial = etatCommercial_p;
    this._etatPortabilite = etatPortabilite_p;
    this._idtdermod = idtdermod_p;
  }

  /**
   * Create a new instance Msisdn from a ResultSet
   *
   * @param rs
   *          ResultSet with the information
   * @throws SQLException
   *           in error SQL
   */
  public MSISDN(ResultSet rs) throws SQLException
  {
    super();
    this._msisdn = rs.getLong(MSISDN.NUMTEL);
    this._msisdnType = rs.getInt(MSISDN.TYPMSI);
    this._identifiantHlr = rs.getInt(MSISDN.IDTHLR);
    this._commande = rs.getString(MSISDN.IDTCMDMSI);
    this._identifiantInterne = rs.getInt(MSISDN.IDTACNMSI);
    this._etatProvMsisdn = rs.getString(MSISDN.ETAMSI);
    this._dateDernierChangement = new Date(rs.getTimestamp(MSISDN.DATETA).getTime());
    this._dernierDigits = rs.getInt(MSISDN.DRNDGT);
    this._etatHlr = rs.getString(MSISDN.ETAHLR);
    this._etatCommercial = rs.getString(MSISDN.ETACOM);
    this._etatPortabilite = rs.getString(MSISDN.ETAPRT);
    this._idtdermod = rs.getString(MSISDN.IDTDERMOD);
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    MSISDN other = (MSISDN) obj;
    if (_msisdn == null)
    {
      if (other._msisdn != null)
      {
        return false;
      }
    }
    else if (!_msisdn.equals(other._msisdn))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the commande
   */
  public String getCommande()
  {
    return _commande;
  }

  /**
   * @return the dateDernierChangement
   */
  public Date getDateDernierChangement()
  {
    return _dateDernierChangement;
  }

  /**
   * @return the dernierDigits
   */
  public Integer getDernierDigits()
  {
    return _dernierDigits;
  }

  /**
   * @return the etatCommercial
   */
  public String getEtatCommercial()
  {
    return _etatCommercial;
  }

  /**
   * @return the etatHlr
   */
  public String getEtatHlr()
  {
    return _etatHlr;
  }

  /**
   * @return the etatPortabilite
   */
  public String getEtatPortabilite()
  {
    return _etatPortabilite;
  }

  /**
   * @return the etatProvMsisdn
   */
  public String getEtatProvMsisdn()
  {
    return _etatProvMsisdn;
  }

  /**
   * @return the identifiantHlr
   */
  public Integer getIdentifiantHlr()
  {
    return _identifiantHlr;
  }

  /**
   * @return the identifiantInterne
   */
  public Integer getIdentifiantInterne()
  {
    return _identifiantInterne;
  }

  /**
   * @return the idtdermod
   */
  public String getIdtdermod()
  {
    return _idtdermod;
  }

  /**
   * @return the msisdn
   */
  public Long getMsisdn()
  {
    return _msisdn;
  }

  /**
   * @return the msisdnType
   */
  public Integer getMsisdnType()
  {
    return _msisdnType;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_msisdn == null) ? 0 : _msisdn.hashCode());
    return result;
  }

  /**
   * @param commande_p
   *          the commande to set
   */
  public void setCommande(String commande_p)
  {
    _commande = commande_p;
  }

  /**
   * @param dateDernierChangement_p
   *          the dateDernierChangement to set
   */
  public void setDateDernierChangement(Date dateDernierChangement_p)
  {
    _dateDernierChangement = dateDernierChangement_p;
  }

  /**
   * @param dernierDigits_p
   *          the dernierDigits to set
   */
  public void setDernierDigits(Integer dernierDigits_p)
  {
    _dernierDigits = dernierDigits_p;
  }

  /**
   * @param etatCommercial_p
   *          the etatCommercial to set
   */
  public void setEtatCommercial(String etatCommercial_p)
  {
    _etatCommercial = etatCommercial_p;
  }

  /**
   * @param etatHlr_p
   *          the etatHlr to set
   */
  public void setEtatHlr(String etatHlr_p)
  {
    _etatHlr = etatHlr_p;
  }

  /**
   * @param etatPortabilite_p
   *          the etatPortabilite to set
   */
  public void setEtatPortabilite(String etatPortabilite_p)
  {
    _etatPortabilite = etatPortabilite_p;
  }

  /**
   * @param etatProvMsisdn_p
   *          the etatProvMsisdn to set
   */
  public void setEtatProvMsisdn(String etatProvMsisdn_p)
  {
    _etatProvMsisdn = etatProvMsisdn_p;
  }

  /**
   * @param identifiantHlr_p
   *          the identifiantHlr to set
   */
  public void setIdentifiantHlr(Integer identifiantHlr_p)
  {
    _identifiantHlr = identifiantHlr_p;
  }

  /**
   * @param identifiantInterne_p
   *          the identifiantInterne to set
   */
  public void setIdentifiantInterne(Integer identifiantInterne_p)
  {
    _identifiantInterne = identifiantInterne_p;
  }

  /**
   * @param idtdermod_p
   *          the idtdermod to set
   */
  public void setIdtdermod(String idtdermod_p)
  {
    _idtdermod = idtdermod_p;
  }

  /**
   * @param msisdn_p
   *          the msisdn to set
   */
  public void setMsisdn(Long msisdn_p)
  {
    _msisdn = msisdn_p;
  }

  /**
   * @param msisdnType_p
   *          the msisdnType to set
   */
  public void setMsisdnType(Integer msisdnType_p)
  {
    _msisdnType = msisdnType_p;
  }

  @Override
  public String toString()
  {
    return "[_msisdn=" + _msisdn + ", _msisdnType=" + _msisdnType + ", _identifiantHlr=" + _identifiantHlr + ", _commande=" + _commande + ", _identifiantInterne=" + _identifiantInterne + ", _etatProvMsisdn=" + _etatProvMsisdn + ", _dateDernierChangement=" + _dateDernierChangement + ", _dernierDigits=" + _dernierDigits + ", _etatHlr=" + _etatHlr + ", _etatCommercial=" + _etatCommercial + ", _etatPortabilite=" + _etatPortabilite + ", _idtdermod=" + _idtdermod + "]"; //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$//$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$ //$NON-NLS-10$ //$NON-NLS-11$ //$NON-NLS-12$ //$NON-NLS-13$
  }

}
