/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/

package com.bytel.spirit.common.connectors.gdr;

/**
 *
 * @author $Author$
 * @version ($Revision$ $Date$)
 */
public class SimRecord
{
  /** cletrp */
  private String _cletrp;

  /** cmtcmd */
  private String _cmtcmd;

  /** codadm */
  private String _codadm;

  /** debims */
  private String _debims;

  /** debsim */
  private String _debsim;

  /** etacmd */
  private String _etacmd;

  /** etasim */
  private String _etasim;

  /** gnc */
  private String _gnc;

  /** idtart */
  private String _idtart;

  /** idtcla */
  private Long _idtcla;

  /** idtcmd */
  private Long _idtcmd;

  /** idtfab */
  private String _idtfab;

  /** idthlr */
  private Long _idthlr;

  /** idtprfele */
  private Long _idtprfele;

  /** idtprfgra */
  private Long _idtprfgra;

  /** ims */
  private String _ims;

  /** nomcrt */
  private String _nomcrt;

  /** pin */
  private String _pin;

  /** pin002 */
  private String _pin002;

  /** puk */
  private String _puk;

  /** puk002 */
  private String _puk002;

  /** qtecmd */
  private Long _qtecmd;

  /** sim */
  private String _sim;

  /** simpoh */
  private String _simpoh;

  /**
   * @return the cletrp
   */
  public String getCletrp()
  {
    return _cletrp;
  }

  /**
   * @return the cmtcmd
   */
  public String getCmtcmd()
  {
    return _cmtcmd;
  }

  /**
   * @return the codadm
   */
  public String getCodadm()
  {
    return _codadm;
  }

  /**
   * @return the debims
   */
  public String getDebims()
  {
    return _debims;
  }

  /**
   * @return the debsim
   */
  public String getDebsim()
  {
    return _debsim;
  }

  /**
   * @return the etacmd
   */
  public String getEtacmd()
  {
    return _etacmd;
  }

  /**
   * @return the etasim
   */
  public String getEtasim()
  {
    return _etasim;
  }

  /**
   * @return the gnc
   */
  public String getGnc()
  {
    return _gnc;
  }

  /**
   * @return the idtart
   */
  public String getIdtart()
  {
    return _idtart;
  }

  /**
   * @return the idtcla
   */
  public Long getIdtcla()
  {
    return _idtcla;
  }

  /**
   * @return the idtcmd
   */
  public Long getIdtcmd()
  {
    return _idtcmd;
  }

  /**
   * @return the idtfab
   */
  public String getIdtfab()
  {
    return _idtfab;
  }

  /**
   * @return the idthlr
   */
  public Long getIdthlr()
  {
    return _idthlr;
  }

  /**
   * @return the idtprfele
   */
  public Long getIdtprfele()
  {
    return _idtprfele;
  }

  /**
   * @return the idtprfgra
   */
  public Long getIdtprfgra()
  {
    return _idtprfgra;
  }

  /**
   * @return the ims
   */
  public String getIms()
  {
    return _ims;
  }

  /**
   * @return the nomcrt
   */
  public String getNomcrt()
  {
    return _nomcrt;
  }

  /**
   * @return the pin
   */
  public String getPin()
  {
    return _pin;
  }

  /**
   * @return the pin002
   */
  public String getPin002()
  {
    return _pin002;
  }

  /**
   * @return the puk
   */
  public String getPuk()
  {
    return _puk;
  }

  /**
   * @return the puk002
   */
  public String getPuk002()
  {
    return _puk002;
  }

  /**
   * @return the qtecmd
   */
  public Long getQtecmd()
  {
    return _qtecmd;
  }

  /**
   * @return the sim
   */
  public String getSim()
  {
    return _sim;
  }

  /**
   * @return the simpoh
   */
  public String getSimpoh()
  {
    return _simpoh;
  }

  /**
   * @param cletrp_p
   *          the cletrp to set
   */
  public void setCletrp(String cletrp_p)
  {
    _cletrp = cletrp_p;
  }

  /**
   * @param cmtcmd_p
   *          the cmtcmd to set
   */
  public void setCmtcmd(String cmtcmd_p)
  {
    _cmtcmd = cmtcmd_p;
  }

  /**
   * @param codadm_p
   *          the codadm to set
   */
  public void setCodadm(String codadm_p)
  {
    _codadm = codadm_p;
  }

  /**
   * @param debims_p
   *          the debims to set
   */
  public void setDebims(String debims_p)
  {
    _debims = debims_p;
  }

  /**
   * @param debsim_p
   *          the debsim to set
   */
  public void setDebsim(String debsim_p)
  {
    _debsim = debsim_p;
  }

  /**
   * @param etacmd_p
   *          the etacmd to set
   */
  public void setEtacmd(String etacmd_p)
  {
    _etacmd = etacmd_p;
  }

  /**
   * @param etasim_p
   *          the etasim to set
   */
  public void setEtasim(String etasim_p)
  {
    _etasim = etasim_p;
  }

  /**
   * @param gnc_p
   *          the gnc to set
   */
  public void setGnc(String gnc_p)
  {
    _gnc = gnc_p;
  }

  /**
   * @param idtart_p
   *          the idtart to set
   */
  public void setIdtart(String idtart_p)
  {
    _idtart = idtart_p;
  }

  /**
   * @param idtcla_p
   *          the idtcla to set
   */
  public void setIdtcla(Long idtcla_p)
  {
    _idtcla = idtcla_p;
  }

  /**
   * @param idtcmd_p
   *          the idtcmd to set
   */
  public void setIdtcmd(Long idtcmd_p)
  {
    _idtcmd = idtcmd_p;
  }

  /**
   * @param idtfab_p
   *          the idtfab to set
   */
  public void setIdtfab(String idtfab_p)
  {
    _idtfab = idtfab_p;
  }

  /**
   * @param idthlr_p
   *          the idthlr to set
   */
  public void setIdthlr(Long idthlr_p)
  {
    _idthlr = idthlr_p;
  }

  /**
   * @param idtprfele_p
   *          the idtprfele to set
   */
  public void setIdtprfele(Long idtprfele_p)
  {
    _idtprfele = idtprfele_p;
  }

  /**
   * @param idtprfgra_p
   *          the idtprfgra to set
   */
  public void setIdtprfgra(Long idtprfgra_p)
  {
    _idtprfgra = idtprfgra_p;
  }

  /**
   * @param ims_p
   *          the ims to set
   */
  public void setIms(String ims_p)
  {
    _ims = ims_p;
  }

  /**
   * @param nomcrt_p
   *          the nomcrt to set
   */
  public void setNomcrt(String nomcrt_p)
  {
    _nomcrt = nomcrt_p;
  }

  /**
   * @param pin_p
   *          the pin to set
   */
  public void setPin(String pin_p)
  {
    _pin = pin_p;
  }

  /**
   * @param pin002_p
   *          the pin002 to set
   */
  public void setPin002(String pin002_p)
  {
    _pin002 = pin002_p;
  }

  /**
   * @param puk_p
   *          the puk to set
   */
  public void setPuk(String puk_p)
  {
    _puk = puk_p;
  }

  /**
   * @param puk002_p
   *          the puk002 to set
   */
  public void setPuk002(String puk002_p)
  {
    _puk002 = puk002_p;
  }

  /**
   * @param qtecmd_p
   *          the qtecmd to set
   */
  public void setQtecmd(Long qtecmd_p)
  {
    _qtecmd = qtecmd_p;
  }

  /**
   * @param sim_p
   *          the sim to set
   */
  public void setSim(String sim_p)
  {
    _sim = sim_p;
  }

  /**
   * @param simpoh_p
   *          the simpoh to set
   */
  public void setSimpoh(String simpoh_p)
  {
    _simpoh = simpoh_p;
  }

  @Override
  public String toString()
  {
    String format = "%s;%d;%d;%s;%s;%s;%s;%s;%s;%s;%s;%s;%s;%s;%d;%d;%d;%s;%s;%s;%d;%s;%s;%s"; //$NON-NLS-1$
    return String.format(format, _sim, _idthlr, _idtcmd, _etasim, _ims, _pin, _pin002, _puk, _puk002, _codadm, _simpoh, _idtfab, _nomcrt, _gnc, _idtprfele, _idtprfgra, _idtcla, _idtart, _debsim, _debims, _qtecmd, _etacmd, _cletrp, _cmtcmd);
  }
}
