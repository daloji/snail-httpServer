/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.gdr;

import java.text.MessageFormat;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.conf.generated.Param;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.services.conf.connector.generated.Connector;
import com.bytel.ravel.services.connector.AbstractDBConnector;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.connectors.gdr.structs.BYTPRD;
import com.bytel.spirit.common.connectors.gdr.structs.CMDSIM;
import com.bytel.spirit.common.connectors.gdr.structs.CarteProfileData;
import com.bytel.spirit.common.connectors.gdr.structs.DURMSI;
import com.bytel.spirit.common.connectors.gdr.structs.ErreurSMDP;
import com.bytel.spirit.common.connectors.gdr.structs.HISETASIM;
import com.bytel.spirit.common.connectors.gdr.structs.ICallbackLireSim;
import com.bytel.spirit.common.connectors.gdr.structs.MSISDN;
import com.bytel.spirit.common.connectors.gdr.structs.PRF;
import com.bytel.spirit.common.connectors.gdr.structs.SUIVISMDP;
import com.bytel.spirit.common.connectors.gdr.structs.Sim;
import com.bytel.spirit.common.connectors.gdr.structs.StatistiqueEsim;
import com.bytel.spirit.common.connectors.gdr.utils.ArrayDescriptorFactory;
import com.bytel.spirit.common.connectors.gdr.utils.GDRPGIWSRessources;
import com.bytel.spirit.common.connectors.gdr.utils.GDRPGRechercheInfo;
import com.bytel.spirit.common.connectors.gdr.utils.GDRPGReportingGDS;
import com.bytel.spirit.common.connectors.gdr.utils.GDRPGSpirit;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

/**
 * @author $Author$
 * @version ($Revision$ $Date$)
 */
public class GDRConnector extends AbstractDBConnector implements IGDRConnector
{
  /**
   * Defines all mandatory parameters read from configuration file.
   *
   * @author $Author$
   * @version ($Revision$ $Date$)
   */
  private enum ParameterName
  {
    /** The URL parameter. */
    DB_CONNECTIONSTRING,

    /** The PASSWORD parameter. */
    DB_PASSWORD,

    /** The LOGIN parameter. */
    DB_USERNAME,

    /** The POOLSIZE parameter. */
    POOLSIZE,

    /** Connect timeout in sec */
    CONNECT_TIMEOUT_SEC,

    /** read timeout in sec */
    READ_TIMEOUT_SEC
  }

  /**
   * datasource connection properties
   */
  private final static String CONNECTION_PROPERTIES = "oracle.net.CONNECT_TIMEOUT=%d;oracle.jdbc.ReadTimeout=%d"; //$NON-NLS-1$

  /**
   * Connect timeout in seconds
   */
  private int _connectTimeoutSec;

  /**
   * Parameters read from configuration.
   */
  private Map<ParameterName, String> _parameters = new HashMap<>();

  /**
   * Read timeout in seconds
   */
  private int _readTimeoutSec;

  /**
   * package PG_IWSRESSOURCES
   */
  private GDRPGIWSRessources _pgIWSRessources;

  /**
   * package PG_RECHERCHE_INFO
   */
  private GDRPGRechercheInfo _pgRechercheInfo;

  /**
   * package PG_REPORTING_GDS
   */
  private GDRPGReportingGDS _pgReportingGDS;

  /**
   * package PG_SPIRIT
   */
  private GDRPGSpirit _pgSpirit;

  /**
   * ArrayDescriptorFactory
   */
  private ArrayDescriptorFactory _arrayDescriptionFactory;

  @Override
  public ConnectorResponse<Long, Retour> checkEtatSimBatch(Tracabilite tracabilite_p, long idBatch_p, String listeTypeSim_p) throws RavelException
  {
    _dsReadLock.lock();

    try
    {
      return _pgIWSRessources.checkEtatSimBatch(tracabilite_p, idBatch_p, listeTypeSim_p);
    }
    finally
    {
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<Nothing, Retour> compterEtatESim(Tracabilite tracabilite_p, List<Integer> peConsumer_p, List<Integer> peM2M_p) throws RavelException
  {
    _dsReadLock.lock();

    try
    {
      return _pgSpirit.compterEtatESim(tracabilite_p, peConsumer_p, peM2M_p);
    }
    finally
    {
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<String, Retour> consultEtatBatch(Tracabilite tracabilite_p, long idBatch_p) throws RavelException
  {
    _dsReadLock.lock();

    try
    {
      return _pgIWSRessources.consultEtatBatch(tracabilite_p, idBatch_p);
    }
    finally
    {
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<ConsultSimBatch, Retour> consultSimBatch(Tracabilite tracabilite_p, long idBatch_p, String etasim_p, String listeTypeSim_p) throws RavelException
  {
    _dsReadLock.lock();

    try
    {
      return _pgIWSRessources.consultSimBatch(tracabilite_p, idBatch_p, etasim_p, listeTypeSim_p);
    }
    finally
    {
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<Integer, Retour> countMsisdnBytelActifs(Tracabilite tracabilite_p) throws RavelException
  {
    _dsReadLock.lock();

    try
    {
      return _pgReportingGDS.countMsisdnBytelActifs(tracabilite_p);
    }
    finally
    {
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<List<ErreurSMDP>, Retour> getErreurSmdpByIccid(Tracabilite tracabilite_p, String iccid_p) throws RavelException
  {
    _dsReadLock.lock();

    try
    {
      return _pgSpirit.getErreurSmdpByIccid(tracabilite_p, iccid_p);
    }
    finally
    {
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<List<HISETASIM>, Retour> getHisetaSimByIdtSim(Tracabilite tracabilite_p, String idtSim_p) throws RavelException
  {
    _dsReadLock.lock();

    try
    {
      return _pgSpirit.getHisetaSimByIdtSim(tracabilite_p, idtSim_p);
    }
    finally
    {
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<String, Retour> getInstanceClienteSim(Tracabilite tracabilite_p, String idtsim_p) throws RavelException
  {
    _dsReadLock.lock();

    try
    {
      return _pgSpirit.getInstanceClienteSim(tracabilite_p, idtsim_p);
    }
    finally
    {
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<PRF, Retour> getPRFByIdtPrf(Tracabilite tracabilite_p, String idtprf_p) throws RavelException
  {
    _dsReadLock.lock();

    try
    {
      return _pgSpirit.getPRFByIdtPrf(tracabilite_p, idtprf_p);
    }
    finally
    {
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<String, Retour> getProfilElectriqueParIdentifiant(Tracabilite tracabilite_p, String idtprf_p, String typprf_p) throws RavelException
  {
    _dsReadLock.lock();

    try
    {
      return _pgSpirit.getProfilElectriqueParIdentifiant(tracabilite_p, idtprf_p, typprf_p);
    }
    finally
    {
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<List<Sim>, Retour> getSimByGnc(Tracabilite tracabilite_p, String gnc_p) throws RavelException
  {
    _dsReadLock.lock();

    try
    {
      return _pgSpirit.getSimByGnc(tracabilite_p, gnc_p);
    }
    finally
    {
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<Sim, Retour> getSimByIccidOrImsi(Tracabilite tracabilite_p, String iccid_p, String imsi_p) throws RavelException
  {
    _dsReadLock.lock();

    try
    {
      return _pgSpirit.getSimByIccidOrImsi(tracabilite_p, iccid_p, imsi_p);
    }
    finally
    {
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<List<Sim>, Retour> getSIMDistribuables(Tracabilite tracabilite_p, List<Integer> typeSimANotifier_p, Integer nbSimToTreat_p) throws RavelException
  {
    _dsReadLock.lock();

    try
    {
      return _pgSpirit.getSIMDistribuables(tracabilite_p, typeSimANotifier_p, nbSimToTreat_p);
    }
    finally
    {
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<List<Sim>, Retour> getSimsNonPreProvisionnes(Tracabilite tracabilite_p, String idtCmd_p, String etatMoc_p) throws RavelException
  {
    _dsReadLock.lock();

    try
    {
      return _pgSpirit.getSimsNonPreProvisionnes(tracabilite_p, idtCmd_p, etatMoc_p);
    }
    finally
    {
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<List<StatistiqueEsim>, Retour> getStatistiquesEsim(Tracabilite tracabilite_p, String periodicite_p) throws RavelException
  {
    _dsReadLock.lock();

    try
    {
      return _pgSpirit.getStatistiquesEsim(tracabilite_p, periodicite_p);
    }
    finally
    {
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<Nothing, Retour> insertErreurSmdp(Tracabilite tracabilite_p, String iccid_p, String requestid_p, String etaterreur_p, LocalDateTime dat_p, String idtdermod_p, String etatrequete_p, String entiteerreur_p, String raisonerreur_p, String libelleerreur_p) throws RavelException
  {
    _dsReadLock.lock();

    try
    {
      return _pgSpirit.insertErreurSmdp(tracabilite_p, iccid_p, requestid_p, etaterreur_p, dat_p, idtdermod_p, etatrequete_p, entiteerreur_p, raisonerreur_p, libelleerreur_p);
    }
    finally
    {
      _dsReadLock.unlock();
    }
  }

  @Override
  public void loadConnectorConfiguration(Connector connector_p) throws RavelException
  {
    _name = connector_p.getName();
    _enabled = connector_p.isEnabled();
    for (Param parameter : connector_p.getParam())
    {
      ParameterName parameterName = ParameterName.valueOf(parameter.getName().toUpperCase());
      if (parameterName != null)
      {
        _parameters.put(parameterName, parameter.getValue());
      }
    }

    // Check parameters
    String connectionString = _parameters.get(ParameterName.DB_CONNECTIONSTRING);
    if ((connectionString == null) || connectionString.isEmpty())
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(Messages.getString("GDRConnector.MissingParameter"), _name, ParameterName.DB_CONNECTIONSTRING.toString())); //$NON-NLS-1$
    }
    String dbUserName = _parameters.get(ParameterName.DB_USERNAME);
    if ((dbUserName == null) || dbUserName.isEmpty())
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(Messages.getString("GDRConnector.MissingParameter"), _name, ParameterName.DB_USERNAME.toString())); //$NON-NLS-1$
    }
    String dbPassword = _parameters.get(ParameterName.DB_PASSWORD);
    if ((dbPassword == null) || dbPassword.isEmpty())
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(Messages.getString("GDRConnector.MissingParameter"), _name, ParameterName.DB_PASSWORD.toString())); //$NON-NLS-1$
    }
    String poolSize = _parameters.get(ParameterName.POOLSIZE);

    String connectTimeoutSec = _parameters.get(ParameterName.CONNECT_TIMEOUT_SEC);
    if (StringTools.isNullOrEmpty(connectTimeoutSec))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(Messages.getString("GDRConnector.MissingParameter"), _name, ParameterName.CONNECT_TIMEOUT_SEC.toString())); //$NON-NLS-1$
    }

    int connectTimeoutMilliSec = 0;
    try
    {
      _connectTimeoutSec = Integer.parseInt(connectTimeoutSec);
      connectTimeoutMilliSec = Integer.parseInt(connectTimeoutSec) * 1000;
    }
    catch (NumberFormatException e)
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00021, MessageFormat.format(Messages.getString("GDRConnector.InvalidParameter"), _name, ParameterName.CONNECT_TIMEOUT_SEC.toString())); //$NON-NLS-1$
    }

    String readTimeoutSec = _parameters.get(ParameterName.READ_TIMEOUT_SEC);
    if (StringTools.isNullOrEmpty(readTimeoutSec))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(Messages.getString("GDRConnector.MissingParameter"), _name, ParameterName.READ_TIMEOUT_SEC.toString())); //$NON-NLS-1$
    }

    try
    {
      _readTimeoutSec = Integer.parseInt(readTimeoutSec);
    }
    catch (NumberFormatException e)
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00021, MessageFormat.format(Messages.getString("GDRConnector.InvalidParameter"), _name, ParameterName.READ_TIMEOUT_SEC.toString())); //$NON-NLS-1$
    }

    createDataSource(connectionString, dbUserName, dbPassword, poolSize, DatabaseType.ORACLE);
    _datasource.setConnectionProperties(String.format(CONNECTION_PROPERTIES, connectTimeoutMilliSec, _readTimeoutSec * 1000));
    _arrayDescriptionFactory = new ArrayDescriptorFactory();

    _pgIWSRessources = new GDRPGIWSRessources(_datasource, _readTimeoutSec, _connectTimeoutSec);
    _pgRechercheInfo = new GDRPGRechercheInfo(_datasource, _readTimeoutSec, _connectTimeoutSec);
    _pgReportingGDS = new GDRPGReportingGDS(_datasource, _readTimeoutSec, _connectTimeoutSec);
    _pgSpirit = new GDRPGSpirit(_datasource, _readTimeoutSec, _connectTimeoutSec, _arrayDescriptionFactory);
  }

  @Override
  public ConnectorResponse<String, Retour> majEtatBatch(Tracabilite tracabilite_p, long idBatch_p) throws RavelException
  {
    _dsReadLock.lock();

    try
    {
      return _pgIWSRessources.majEtatBatch(tracabilite_p, idBatch_p);
    }
    finally
    {
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<String, Retour> mettreAJourSIM(Tracabilite tracabilite_p, String iccid_p, String etatSmdp_p, String statutTelechargement_p, String objetModification_p, String timestamp_p, String eid_p) throws RavelException
  {
    _dsReadLock.lock();

    try
    {
      return _pgSpirit.mettreAJourSIM(tracabilite_p, iccid_p, etatSmdp_p, statutTelechargement_p, objetModification_p, timestamp_p, eid_p);
    }
    finally
    {
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<String, Retour> mettreAJourSIMNotif(Tracabilite tracabilite_p, String iccid_p, String etatSmdp_p, String identifiantAction_p, String objetModification_p, String datEta_p, String statutNotif_p) throws RavelException
  {
    _dsReadLock.lock();

    try
    {
      return _pgSpirit.mettreAJourSIMNotif(tracabilite_p, iccid_p, etatSmdp_p, identifiantAction_p, objetModification_p, datEta_p, statutNotif_p);
    }
    finally
    {
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<Nothing, Retour> mettreAJourSIMNotifAppro(Tracabilite tracabilite_p, String iccid_p, String notifAppro_p) throws RavelException
  {
    _dsReadLock.lock();

    try
    {
      return _pgSpirit.mettreAJourSIMNotifAppro(tracabilite_p, iccid_p, notifAppro_p);
    }
    finally
    {
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<String, Retour> miseADispositionSimBatch(Tracabilite tracabilite_p, long idBatch_p, String listeTypeSim_p, String instanceCliente_p) throws RavelException
  {
    _dsReadLock.lock();

    try
    {
      return _pgIWSRessources.miseADispositionSimBatch(tracabilite_p, idBatch_p, listeTypeSim_p, instanceCliente_p);
    }
    finally
    {
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<TypeMsisdn, Retour> ps001ConsultTYPEMSIFROMType(Tracabilite tracabilite_p, Integer typeMsisdn_p) throws RavelException
  {
    _dsReadLock.lock();

    try
    {
      return _pgIWSRessources.ps001ConsultTYPEMSIFROMType(tracabilite_p, typeMsisdn_p);
    }
    finally
    {
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<List<MSISDN>, Retour> ps002ReserveMSISDNFROMModeCritere(Tracabilite tracabilite_p, String instanceCliente_p, Integer nbMsisdn_p, String mode_p, Integer typeMsisdn_p, Integer critereRecherche_p, Integer typeReservation_p, String etatCible_p, String dureeReservation_p, int dureeReservationTemporaire_p, String idReservationMSISDN_p, String idtdermod_p) throws RavelException
  {
    _dsReadLock.lock();

    try
    {
      return _pgIWSRessources.ps002ReserveMSISDNFROMModeCritere(tracabilite_p, instanceCliente_p, nbMsisdn_p, mode_p, typeMsisdn_p, critereRecherche_p, typeReservation_p, etatCible_p, dureeReservation_p, dureeReservationTemporaire_p, idReservationMSISDN_p, idtdermod_p);
    }
    finally
    {
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<String, Retour> ps003ResiliationMSISDN(Tracabilite tracabilite_p, String msisdn_p) throws RavelException
  {
    _dsReadLock.lock();

    try
    {
      return _pgIWSRessources.ps003ResiliationMSISDN(tracabilite_p, msisdn_p);
    }
    finally
    {
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<String, Retour> ps004GetIMSIFromICCID(Tracabilite tracabilite_p, String iccid_p) throws RavelException
  {
    _dsReadLock.lock();

    try
    {
      return _pgIWSRessources.ps004GetIMSIFromICCID(tracabilite_p, iccid_p);
    }
    finally
    {
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<List<CarteProfileData>, Retour> ps005ConsultCarteProfile(Tracabilite tracabilite_p, String iccid_p, String imsi_p) throws RavelException
  {
    _dsReadLock.lock();

    try
    {
      return _pgIWSRessources.ps005ConsultCarteProfile(tracabilite_p, iccid_p, imsi_p);
    }
    finally
    {
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<MSISDN, Retour> ps006ConsultMSISDN(Tracabilite tracabilite_p, String msisdn_p) throws RavelException
  {
    _dsReadLock.lock();

    try
    {
      return _pgIWSRessources.ps006ConsultMSISDN(tracabilite_p, msisdn_p);
    }
    finally
    {
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<DURMSI, Retour> ps007ConsultDureeQuarantaine(Tracabilite tracabilite_p, Integer typeMSISDN_p, String instanceCliente_p) throws RavelException
  {
    _dsReadLock.lock();

    try
    {
      return _pgIWSRessources.ps007ConsultDureeQuarantaine(tracabilite_p, typeMSISDN_p, instanceCliente_p);
    }
    finally
    {
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<String, Retour> ps008ConsultLatestHistoriqueEtatMSISDN(Tracabilite tracabilite_p, String numtel_p) throws RavelException
  {
    _dsReadLock.lock();

    try
    {
      return _pgIWSRessources.ps008ConsultLatestHistoriqueEtatMSISDN(tracabilite_p, numtel_p);
    }
    finally
    {
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<String, Retour> ps009GetICCIDFromIMSI(Tracabilite tracabilite_p, String imsi_p) throws RavelException
  {
    _dsReadLock.lock();

    try
    {
      return _pgIWSRessources.ps009GetICCIDFromIMSI(tracabilite_p, imsi_p);
    }
    finally
    {
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<String, Retour> ps010ReattribuerMSISDN(Tracabilite tracabilite_p, long numtel_p, String etatCibleMsisdn_p, String etatCibleCom_p, String etatCiblePorta_p, Integer objetModification_p, String instanceCliente_p) throws RavelException
  {
    _dsReadLock.lock();

    try
    {
      return _pgIWSRessources.ps010ReattribuerMSISDN(tracabilite_p, numtel_p, etatCibleMsisdn_p, etatCibleCom_p, etatCiblePorta_p, objetModification_p, instanceCliente_p);
    }
    finally
    {
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<String, Retour> ps011UpdateSIMFromICCID(Tracabilite tracabilite_p, String iccid_p, String etatSimCible_p, Integer objetModification_p, String etatComCible_p, String etatPorCible_p, String identifiantModif_p, String instanceCliente_p) throws RavelException
  {
    _dsReadLock.lock();

    try
    {
      return _pgIWSRessources.ps011UpdateSIMFromICCID(tracabilite_p, iccid_p, etatSimCible_p, objetModification_p, etatComCible_p, etatPorCible_p, identifiantModif_p, instanceCliente_p);
    }
    finally
    {
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<Sim, Retour> ps012GetICCIDFromIMSI(Tracabilite tracabilite_p, String imsi_p) throws RavelException
  {
    _dsReadLock.lock();

    try
    {
      return _pgIWSRessources.ps012GetICCIDFromIMSI(tracabilite_p, imsi_p);
    }
    finally
    {
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<Boolean, Retour> ps013UpdateEtatMsisdn(Tracabilite tracabilite_p, Long numtel_p, String etatCibleMsisdn_p, Integer idtAcnMsi_p, String instanceCliente_p, String idtdermod_p) throws RavelException
  {
    _dsReadLock.lock();

    try
    {
      return _pgIWSRessources.ps013UpdateEtatMsisdn(tracabilite_p, numtel_p, etatCibleMsisdn_p, idtAcnMsi_p, instanceCliente_p, idtdermod_p);
    }
    finally
    {
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<List<String>, Retour> ps014GetIdentifiantsCommande(Tracabilite tracabilite_p, String idtprfele_p) throws RavelException
  {
    _dsReadLock.lock();

    try
    {
      return _pgSpirit.ps014GetIdentifiantsCommande(tracabilite_p, idtprfele_p);
    }
    finally
    {
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<String, Retour> ps015GetProfileType(Tracabilite tracabilite_p, String idtprf_p) throws RavelException
  {
    _dsReadLock.lock();

    try
    {
      return _pgSpirit.ps015GetProfileType(tracabilite_p, idtprf_p);
    }
    finally
    {
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<List<String>, Retour> ps016GetIccidsParldtCmd(Tracabilite tracabilite_p, String idtcmd_p) throws RavelException
  {
    _dsReadLock.lock();

    try
    {
      return _pgSpirit.ps016GetIccidsParldtCmd(tracabilite_p, idtcmd_p);
    }
    finally
    {
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<LocalDateTime, Retour> ps017GetDateDerniereEchec(Tracabilite tracabilite_p, String idtcmd_p) throws RavelException
  {
    _dsReadLock.lock();

    try
    {
      return _pgSpirit.ps017GetDateDerniereEchec(tracabilite_p, idtcmd_p);
    }
    finally
    {
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<Nothing, Retour> ps018SetDateDerniereEchec(Tracabilite tracabilite_p, String idtcmd_p) throws RavelException
  {
    _dsReadLock.lock();

    try
    {
      return _pgSpirit.ps018SetDateDerniereEchec(tracabilite_p, idtcmd_p);
    }
    finally
    {
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<Nothing, Retour> ps019UpdateSimDownload(Tracabilite tracabilite_p, String iccid_p, String idtacnsim_p, String idtdermod_p, String etasmdp_p) throws RavelException
  {
    _dsReadLock.lock();

    try
    {
      return _pgSpirit.ps019UpdateSimDownload(tracabilite_p, iccid_p, idtacnsim_p, idtdermod_p, etasmdp_p);
    }
    finally
    {
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<Nothing, Retour> ps020UpdateQuantity(Tracabilite tracabilite_p, String idtcmd_p) throws RavelException
  {
    _dsReadLock.lock();

    try
    {
      return _pgSpirit.ps020UpdateQuantity(tracabilite_p, idtcmd_p);
    }
    finally
    {
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<List<CMDSIM>, Retour> ps021GetCommandesNonNotifies(Tracabilite tracabilite_p) throws RavelException
  {
    _dsReadLock.lock();

    try
    {
      return _pgSpirit.ps021GetCommandesNonNotifies(tracabilite_p);
    }
    finally
    {
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<CMDSIM, Retour> ps022GetCommande(Tracabilite tracabilite_p, String idtcmd_p) throws RavelException
  {
    _dsReadLock.lock();

    try
    {
      return _pgSpirit.ps022GetCommande(tracabilite_p, idtcmd_p);
    }
    finally
    {
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<Nothing, Retour> ps023UpdateEnvoiCmdSim(Tracabilite tracabilite_p, String idtcmd_p, String envoinotifsap_p) throws RavelException
  {
    _dsReadLock.lock();

    try
    {
      return _pgSpirit.ps023UpdateEnvoiCmdSim(tracabilite_p, idtcmd_p, envoinotifsap_p);
    }
    finally
    {
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<List<BYTPRD>, Retour> ps024GetBytprd(Tracabilite tracabilite_p, String gnc_p) throws RavelException
  {
    _dsReadLock.lock();

    try
    {
      return _pgSpirit.ps024GetBytprd(tracabilite_p, gnc_p);
    }
    finally
    {
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<List<SUIVISMDP>, Retour> ps025GetSUIVISMDP(Tracabilite tracabilite_p, String idtcmd_p) throws RavelException
  {
    _dsReadLock.lock();

    try
    {
      return _pgSpirit.ps025GetSUIVISMDP(tracabilite_p, idtcmd_p);
    }
    finally
    {
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<Nothing, Retour> ps026EnregistrerEnvoiFichier(Tracabilite tracabilite_p, String idtcmd_p, String nomfichier_p) throws RavelException
  {
    _dsReadLock.lock();

    try
    {
      return _pgSpirit.ps026EnregistrerEnvoiFichier(tracabilite_p, idtcmd_p, nomfichier_p);
    }
    finally
    {
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<SUIVISMDP, Retour> ps027GetSUIVISMDPDernierEchec(Tracabilite tracabilite_p, String idtcmd_p) throws RavelException
  {
    _dsReadLock.lock();

    try
    {
      return _pgSpirit.ps027GetSUIVISMDPDernierEchec(tracabilite_p, idtcmd_p);
    }
    finally
    {
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<InfoSIM, Retour> rechercheInformationsICCID(Tracabilite tracabilite_p, long iccid_p) throws RavelException
  {
    _dsReadLock.lock();

    try
    {
      return _pgRechercheInfo.rechercheInformationsICCID(tracabilite_p, iccid_p);
    }
    finally
    {
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<InfoSIM, Retour> rechercheInformationsIMSI(Tracabilite tracabilite_p, long imsi_p) throws RavelException
  {
    _dsReadLock.lock();

    try
    {
      return _pgRechercheInfo.rechercheInformationsIMSI(tracabilite_p, imsi_p);
    }
    finally
    {
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<Nothing, Retour> updateSimEtatMoc(Tracabilite tracabilite_p, String pe_p, String etatMoc_p) throws RavelException
  {
    _dsReadLock.lock();

    try
    {
      return _pgSpirit.updateSimEtatMoc(tracabilite_p, pe_p, etatMoc_p);
    }
    finally
    {
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<Nothing, Retour> updateSimEtatMocImsi(Tracabilite tracabilite_p, String imsi_p, String etatMoc_p) throws RavelException
  {
    _dsReadLock.lock();

    try
    {
      return _pgSpirit.updateSimEtatMocImsi(tracabilite_p, imsi_p, etatMoc_p);
    }
    finally
    {
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<Nothing, Retour> updateSimRessource(Tracabilite tracabilite_p, String iccid_p, String etaSim_p, Long idtAcnSim_p, String idtDermod_p, String idtist_p, String etasmdp_p, String etatNotif_p, String policyEtat_p, String policyHabilitation_p, String eid_p, String smsrid_p) throws RavelException
  {
    _dsReadLock.lock();

    try
    {
      return _pgSpirit.updateSimRessource(tracabilite_p, iccid_p, etaSim_p, idtAcnSim_p, idtDermod_p, idtist_p, etasmdp_p, etatNotif_p, policyEtat_p, policyHabilitation_p, eid_p, smsrid_p);
    }
    finally
    {
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<Nothing, Retour> getEsimProfileStatus(Tracabilite tracabilite_p, String typeSim_p, String profileType_p, ICallbackLireSim callback_p, int listSize_p) throws RavelException
  {
    _dsReadLock.lock();

    try
    {
      return _pgSpirit.getEsimProfileStatus(tracabilite_p, typeSim_p, profileType_p, callback_p, listSize_p);
    }
    finally
    {
      _dsReadLock.unlock();
    }
  }
}