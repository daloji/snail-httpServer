/*
 *                                                             ___o.__
 *                                                         ,oH8888888888o._
 *                                                       dP',88888P'''`8888o.
 *   ____                                              ,8',888888      888888o
 *  |  _ \                                            d8,d888888b    ,d8888888b
 *  | |_) | ___  _   _ _   _  __ _ _   _  ___  ___   ,8PPY8888888boo8888PPPP"'`b
 *  |  _ < / _ \| | | | | | |/ _` | | | |/ _ \/ __|  d8o_                     d8
 *  | |_) | (_) | |_| | |_| | (_| | |_| |  __/\__ \' d888bo.             _ooP d8'
 *  |____/ \___/ \__,_|\__, |\__, |\__,_|\___||___/  d8888888P     ,ooo88888P d8
 *                      __/ | ___/_                  `8M8888P     ,88888888P ,8P
 *                     |___/ |__ |  _  |  _  _  _ __  Y88Y88'    ,888888888' dP
 *                               | (/_ | (/_(_ (_)|||  `8b8P    d8888888888,dP
 *                                                      Y8,   d88888888888P'
 *                                                        `Y=8888888888P'
 *                                                            `''`'''
 *
 *  Systeme $system
 *
 *  (C) Copyright Bouygues Telecom 2019.
 *
 *  Utilisation, reproduction et divulgation interdites
 *  sans autorisation ecrite de Bouygues Telecom.
 *
 *  Projet  : GestionM2M
 *  Package : $package
 *  Classe  : $class
 *  Auteur  : $author
 *
 */

package com.bytel.spirit.common.connectors.gdr.structs.enumeration;

import com.bytel.ravel.common.utils.StringTools;

/**
 *
 * @author $author
 * @version ($Revision$ $Date$)
 */
public enum InstanceCliente
{
  ENT1("M2M"), PPN1, PPN2, PPN3, PPN4, GP1("FNB"); //$NON-NLS-1$ //$NON-NLS-2$

  /**
   * Returns an object {@link InstanceCliente} from a String
   *
   * @param value_p
   *          instanceCliente
   * @return {@link InstanceCliente}
   */
  public static InstanceCliente fromString(String value_p)
  {
    if (!StringTools.isNullOrEmpty(value_p))
    {
      for (InstanceCliente instanceCliente : InstanceCliente.values())
      {
        if (instanceCliente.name().equalsIgnoreCase(value_p))
        {
          return instanceCliente;
        }
      }
    }
    return null;
  }

  /**
   *
   */
  private final String _ligneMarche;

  /**
   *
   */
  private InstanceCliente()
  {
    _ligneMarche = null;
  }

  /**
   * @param ligneMarche_p
   *          ligneMarche
   */
  InstanceCliente(String ligneMarche_p)
  {
    _ligneMarche = ligneMarche_p;
  }

  /**
   * @return the ligneMarche
   */
  public String getLigneMarche()
  {
    return _ligneMarche;
  }
}
