/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.gdr;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;

/**
 * Activable
 *
 * @author lmerces
 * @version ($Revision$ $Date$)
 */
@XmlType(name = "Activable")
@XmlEnum
public enum Activable
{

  /**
   *
   */
  N,

  /**
   *
   */
  O;

  /**
   * @param v_p
   *          v
   * @return enum
   */
  public static Activable fromValue(String v_p)
  {
    return valueOf(v_p);
  }

  /**
   * @return name
   */
  public String value()
  {
    return name();
  }

}
