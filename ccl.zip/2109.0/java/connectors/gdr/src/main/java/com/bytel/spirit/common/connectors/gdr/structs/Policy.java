/*
 *                                                             ___o.__
 *                                                         ,oH8888888888o._
 *                                                       dP',88888P'''`8888o.
 *   ____                                              ,8',888888      888888o
 *  |  _ \                                            d8,d888888b    ,d8888888b
 *  | |_) | ___  _   _ _   _  __ _ _   _  ___  ___   ,8PPY8888888boo8888PPPP"'`b
 *  |  _ < / _ \| | | | | | |/ _` | | | |/ _ \/ __|  d8o_                     d8
 *  | |_) | (_) | |_| | |_| | (_| | |_| |  __/\__ \' d888bo.             _ooP d8'
 *  |____/ \___/ \__,_|\__, |\__, |\__,_|\___||___/  d8888888P     ,ooo88888P d8
 *                      __/ | ___/_                  `8M8888P     ,88888888P ,8P
 *                     |___/ |__ |  _  |  _  _  _ __  Y88Y88'    ,888888888' dP
 *                               | (/_ | (/_(_ (_)|||  `8b8P    d8888888888,dP
 *                                                      Y8,   d88888888888P'
 *                                                        `Y=8888888888P'
 *                                                            `''`'''
 *
 *  Systeme $system
 *
 *  (C) Copyright Bouygues Telecom 2019.
 *
 *  Utilisation, reproduction et divulgation interdites
 *  sans autorisation ecrite de Bouygues Telecom.
 *
 *  Projet  : GestionM2M
 *  Package : $package
 *  Classe  : $class
 *  Auteur  : $author
 *
 */

package com.bytel.spirit.common.connectors.gdr.structs;

import com.bytel.spirit.common.connectors.gdr.structs.enumeration.PolicyAction;
import com.bytel.spirit.common.connectors.gdr.structs.enumeration.PolicyQualification;
import com.bytel.spirit.common.connectors.gdr.structs.enumeration.PolicySubject;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

/**
 *
 * @author $author
 * @version ($Revision$ $Date$)
 */
public class Policy implements Serializable
{
    /**
     * Generated UID
     */
    private static final long serialVersionUID = 5461208534921026891L;

    /** subject */
    @SerializedName("subject")
    @Expose
    private PolicySubject _subject;

    /** action */
    @SerializedName("action")
    @Expose
    private PolicyAction _action;

    /** qualification */
    @SerializedName("qualification")
    @Expose
    private PolicyQualification _qualification;

    /**
     *
     */
    public Policy()
    {
        /*
         * Default construct
         */
    }

    public Policy(PolicySubject subject_p, PolicyAction action_p, PolicyQualification qualification_p)
    {
        _subject = subject_p;
        _action = action_p;
        _qualification = qualification_p;
    }

    /**
     * @return _subject
     */
    public PolicySubject getSubject()
    {
        return _subject;
    }

    /**
     * @param subject_p _subject
     */
    public void setSubject(PolicySubject subject_p)
    {
        _subject = subject_p;
    }

    /**
     * @return _action
     */
    public PolicyAction getAction()
    {
        return _action;
    }

    /**
     * @param action_p _action
     */
    public void setAction(PolicyAction action_p)
    {
        _action = action_p;
    }

    /**
     * @return _qualification
     */
    public PolicyQualification getQualification()
    {
        return _qualification;
    }

    /**
     * @param qualification_p _qualification
     */
    public void setQualification(PolicyQualification qualification_p)
    {
        _qualification = qualification_p;
    }

    @Override
    public boolean equals(Object o)
    {
        if (this == o) return true;
        if (o == null)
        {
            return false;
        }
        if (getClass() != o.getClass())
        {
            return false;
        }
        Policy policy = (Policy) o;

        if (_subject != policy._subject) return false;
        if (_action != policy._action) return false;
        return _qualification == policy._qualification;
    }

    @Override
    public int hashCode()
    {
        int result = _subject != null ? _subject.hashCode() : 0;
        result = 31 * result + (_action != null ? _action.hashCode() : 0);
        result = 31 * result + (_qualification != null ? _qualification.hashCode() : 0);
        return result;
    }

    @Override
    public String toString()
    {
        final StringBuffer sb = new StringBuffer("Policy[");
        sb.append("_subject=").append(_subject);
        sb.append(", _action=").append(_action);
        sb.append(", _qualification=").append(_qualification);
        sb.append(']');
        return sb.toString();
    }
}
