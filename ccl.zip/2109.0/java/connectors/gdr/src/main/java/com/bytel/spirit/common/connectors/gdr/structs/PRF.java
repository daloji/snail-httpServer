/*
 *                                                             ___o.__
 *                                                         ,oH8888888888o._
 *                                                       dP',88888P'''`8888o.
 *   ____                                              ,8',888888      888888o
 *  |  _ \                                            d8,d888888b    ,d8888888b
 *  | |_) | ___  _   _ _   _  __ _ _   _  ___  ___   ,8PPY8888888boo8888PPPP"'`b
 *  |  _ < / _ \| | | | | | |/ _` | | | |/ _ \/ __|  d8o_                     d8
 *  | |_) | (_) | |_| | |_| | (_| | |_| |  __/\__ \' d888bo.             _ooP d8'
 *  |____/ \___/ \__,_|\__, |\__, |\__,_|\___||___/  d8888888P     ,ooo88888P d8
 *                      __/ | ___/_                  `8M8888P     ,88888888P ,8P
 *                     |___/ |__ |  _  |  _  _  _ __  Y88Y88'    ,888888888' dP
 *                               | (/_ | (/_(_ (_)|||  `8b8P    d8888888888,dP
 *                                                      Y8,   d88888888888P'
 *                                                        `Y=8888888888P'
 *                                                            `''`'''
 *
 *  Systeme $system
 *
 *  (C) Copyright Bouygues Telecom 2019.
 *
 *  Utilisation, reproduction et divulgation interdites
 *  sans autorisation ecrite de Bouygues Telecom.
 *
 *  Projet  : GestionM2M
 *  Package : $package
 *  Classe  : $class
 *  Auteur  : $author
 *
 */

package com.bytel.spirit.common.connectors.gdr.structs;

import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import com.bytel.ravel.common.utils.StringTools;

/**
 *
 * @author $author
 * @version ($Revision$ $Date$)
 */
public class PRF implements Serializable
{
  /**
   * Generated UID
   */
  private static final long serialVersionUID = -5434921026120856891L;

  /** IDTPRF */
  private Long _idtPRF;

  /** PROFILETYPE */
  private String _profileType;

  /** TYPPRF */
  private String _typPRF;

  /** REFPRF */
  private String _refPRF;

  /** RELPRF */
  private String _relPRF;

  /** ALGAUT */
  private Long _algaut;

  /** TYPRES */
  private String _typeRES;

  /** IDTRES */
  private String _idtRES;

  /** DATFINVAL */
  private Date _datFinVal;

  /** SEUIL */
  private Long _seuil;

  /**
   *
   */
  public PRF()
  {
    /*
    Default Construct
     */
  }

  /**
   *
   * @param idtPRF_p
   * @param profileType_p
   * @param typPRF_p
   * @param refPRF_p
   * @param relPRF_p
   * @param algaut_p
   * @param typeRES_p
   * @param idtRES_p
   * @param datFinVal_p
   * @param seuil_p
   */
  public PRF(Long idtPRF_p, String profileType_p, String typPRF_p, String refPRF_p, String relPRF_p, Long algaut_p, String typeRES_p, String idtRES_p, Date datFinVal_p, Long seuil_p)
  {
    _idtPRF = idtPRF_p;
    _profileType = profileType_p;
    _typPRF = typPRF_p;
    _refPRF = refPRF_p;
    _relPRF = relPRF_p;
    _algaut = algaut_p;
    _typeRES = typeRES_p;
    _idtRES = idtRES_p;
    if (datFinVal_p != null)
    {
      _datFinVal = (Date) datFinVal_p.clone();
    }
    _seuil = seuil_p;
  }

  /**
   *
   * @param rs_p
   * @throws SQLException
   */
  public PRF(ResultSet rs_p) throws SQLException
  {
    this._idtPRF = rs_p.getLong("IDTPRF"); //$NON-NLS-1$
    this._profileType = rs_p.getString("PROFILETYPE"); //$NON-NLS-1$
    this._typPRF = rs_p.getString("TYPPRF"); //$NON-NLS-1$
    this._refPRF = rs_p.getString("REFPRF"); //$NON-NLS-1$
    this._relPRF = rs_p.getString("RELPRF"); //$NON-NLS-1$
    this._algaut = rs_p.getLong("ALGAUT"); //$NON-NLS-1$
    this._typeRES = rs_p.getString("TYPRES"); //$NON-NLS-1$
    this._idtRES = rs_p.getString("IDTRES"); //$NON-NLS-1$
    this._datFinVal = rs_p.getTimestamp("DATFINVAL"); //$NON-NLS-1$
    this._seuil = rs_p.getLong("SEUIL"); //$NON-NLS-1$
  }

  @Override
  public boolean equals(Object o)
  {
    if (this == o)
    {
      return true;
    }
    if (o == null)
    {
      return false;
    }
    if (getClass() != o.getClass())
    {
      return false;
    }
    PRF prf = (PRF) o;

    if (_idtPRF != null ? !_idtPRF.equals(prf._idtPRF) : prf._idtPRF != null)
    {
      return false;
    }
    if (_profileType != null ? !_profileType.equals(prf._profileType) : prf._profileType != null)
    {
      return false;
    }
    if (_typPRF != null ? !_typPRF.equals(prf._typPRF) : prf._typPRF != null)
    {
      return false;
    }
    if (_refPRF != null ? !_refPRF.equals(prf._refPRF) : prf._refPRF != null)
    {
      return false;
    }
    if (_relPRF != null ? !_relPRF.equals(prf._relPRF) : prf._relPRF != null)
    {
      return false;
    }
    if (_algaut != null ? !_algaut.equals(prf._algaut) : prf._algaut != null)
    {
      return false;
    }
    if (_typeRES != null ? !_typeRES.equals(prf._typeRES) : prf._typeRES != null)
    {
      return false;
    }
    if (_idtRES != null ? !_idtRES.equals(prf._idtRES) : prf._idtRES != null)
    {
      return false;
    }
    if (_datFinVal != null ? !_datFinVal.equals(prf._datFinVal) : prf._datFinVal != null)
    {
      return false;
    }
    return _seuil != null ? _seuil.equals(prf._seuil) : prf._seuil == null;
  }

  /**
   * @return _algaut
   */
  public Long getAlgaut()
  {
    return _algaut;
  }

  /**
   * @return _datFinVal
   */
  public Date getDatFinVal()
  {
    if (_datFinVal != null)
    {
      return (Date) _datFinVal.clone();
    }

    return null;
  }

  /**
   * @return _idtPRF
   */
  public Long getIdtPRF()
  {
    return _idtPRF;
  }

  /**
   * @return _idtRES
   */
  public String getIdtRES()
  {
    return _idtRES;
  }

  /**
   *
   * @return
   */
  public String getProfilElectrique()
  {
    if (StringTools.isNotNullOrEmpty(_refPRF) && StringTools.isNotNullOrEmpty(_relPRF))
    {
      return _refPRF + "." + _relPRF; //$NON-NLS-1$
    }
    return null;
  }

  /**
   * @return _profileType
   */
  public String getProfileType()
  {
    return _profileType;
  }

  /**
   * @return _refPRF
   */
  public String getRefPRF()
  {
    return _refPRF;
  }

  /**
   * @return _relPRF
   */
  public String getRelPRF()
  {
    return _relPRF;
  }

  /**
   * @return _seuil
   */
  public Long getSeuil()
  {
    return _seuil;
  }

  /**
   * @return _typeRES
   */
  public String getTypeRES()
  {
    return _typeRES;
  }

  /**
   * @return _typPRF
   */
  public String getTypPRF()
  {
    return _typPRF;
  }

  @Override
  public int hashCode()
  {
    int result = _idtPRF != null ? _idtPRF.hashCode() : 0;
    result = (31 * result) + (_profileType != null ? _profileType.hashCode() : 0);
    result = (31 * result) + (_typPRF != null ? _typPRF.hashCode() : 0);
    result = (31 * result) + (_refPRF != null ? _refPRF.hashCode() : 0);
    result = (31 * result) + (_relPRF != null ? _relPRF.hashCode() : 0);
    result = (31 * result) + (_algaut != null ? _algaut.hashCode() : 0);
    result = (31 * result) + (_typeRES != null ? _typeRES.hashCode() : 0);
    result = (31 * result) + (_idtRES != null ? _idtRES.hashCode() : 0);
    result = (31 * result) + (_datFinVal != null ? _datFinVal.hashCode() : 0);
    result = (31 * result) + (_seuil != null ? _seuil.hashCode() : 0);
    return result;
  }

  /**
   * @param algaut_p
   *          _algaut
   */
  public void setAlgaut(Long algaut_p)
  {
    _algaut = algaut_p;
  }

  /**
   * @param datFinVal_p
   *          _datFinVal
   */
  public void setDatFinVal(Date datFinVal_p)
  {
    if (datFinVal_p != null)
    {
      _datFinVal = (Date) datFinVal_p.clone();
    }
  }

  /**
   * @param idtPRF_p
   *          _idtPRF
   */
  public void setIdtPRF(Long idtPRF_p)
  {
    _idtPRF = idtPRF_p;
  }

  /**
   * @param idtRES_p
   *          _idtRES
   */
  public void setIdtRES(String idtRES_p)
  {
    _idtRES = idtRES_p;
  }

  /**
   * @param profileType_p
   *          _profileType
   */
  public void setProfileType(String profileType_p)
  {
    _profileType = profileType_p;
  }

  /**
   * @param refPRF_p
   *          _refPRF
   */
  public void setRefPRF(String refPRF_p)
  {
    _refPRF = refPRF_p;
  }

  /**
   * @param relPRF_p
   *          _relPRF
   */
  public void setRelPRF(String relPRF_p)
  {
    _relPRF = relPRF_p;
  }

  /**
   * @param seuil_p
   *          _seuil
   */
  public void setSeuil(Long seuil_p)
  {
    _seuil = seuil_p;
  }

  /**
   * @param typeRES_p
   *          _typeRES
   */
  public void setTypeRES(String typeRES_p)
  {
    _typeRES = typeRES_p;
  }

  /**
   * @param typPRF_p
   *          _typPRF
   */
  public void setTypPRF(String typPRF_p)
  {
    _typPRF = typPRF_p;
  }

  @Override
  public String toString()
  {
    final StringBuffer sb = new StringBuffer("PRF ["); //$NON-NLS-1$
    sb.append("_idtPRF=").append(_idtPRF); //$NON-NLS-1$
    sb.append(", _profileType='").append(_profileType).append('\''); //$NON-NLS-1$
    sb.append(", _typPRF='").append(_typPRF).append('\''); //$NON-NLS-1$
    sb.append(", _refPRF='").append(_refPRF).append('\''); //$NON-NLS-1$
    sb.append(", _relPRF='").append(_relPRF).append('\''); //$NON-NLS-1$
    sb.append(", _algaut=").append(_algaut); //$NON-NLS-1$
    sb.append(", _typeRES='").append(_typeRES).append('\''); //$NON-NLS-1$
    sb.append(", _idtRES=").append(_idtRES); //$NON-NLS-1$
    sb.append(", _datFinVal=").append(_datFinVal); //$NON-NLS-1$
    sb.append(", _seuil=").append(_seuil); //$NON-NLS-1$
    sb.append(']');
    return sb.toString();
  }
}
