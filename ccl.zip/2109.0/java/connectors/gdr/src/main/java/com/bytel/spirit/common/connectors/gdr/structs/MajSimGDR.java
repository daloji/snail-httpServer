/*******************************************************************************
* $Id: MajSimGDR.java 28818 2019-11-21 15:20:39Z pramos $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.gdr.structs;

/**
 *
 * @author kbettenc
 * @version ($Revision: 28818 $ $Date: 2019-11-21 16:20:39 +0100 (jeu. 21 nov. 2019) $)
 */
public class MajSimGDR
{

  /**
   * The notificationPointId
   */
  private String _notificationPointId;

  /**
   * The notificationPointStatus
   */
  private String _notificationPointStatus;

  /**
   * The etasmdp
   */
  private String _etasmdp;

  /**
   * The statutTElechargement
   */
  private String _statutTelechargement;

  /**
   * The etatProfilPlateforme
   */
  private String _etatProfilPlateforme;

  /**
   *
   */
  public MajSimGDR()
  {
    // TODO Auto-generated constructor stub
  }

  /**
   * @param notificationPointId_p
   * @param notificationPointStatus_p
   * @param etasmdp_p
   * @param statutTelechargement_p
   */
  public MajSimGDR(String notificationPointId_p, String notificationPointStatus_p, String etasmdp_p, String statutTelechargement_p)
  {
    super();
    _notificationPointId = notificationPointId_p;
    _notificationPointStatus = notificationPointStatus_p;
    _etasmdp = etasmdp_p;
    _statutTelechargement = statutTelechargement_p;
  }

  /**
   * @param notificationPointId_p
   * @param notificationPointStatus_p
   * @param etasmdp_p
   * @param statutTelechargement_p
   * @param etatProfilPlateforme_p
   */
  public MajSimGDR(String notificationPointId_p, String notificationPointStatus_p, String etasmdp_p, String statutTelechargement_p, String etatProfilPlateforme_p)
  {
    super();
    _notificationPointId = notificationPointId_p;
    _notificationPointStatus = notificationPointStatus_p;
    _etasmdp = etasmdp_p;
    _statutTelechargement = statutTelechargement_p;
    _etatProfilPlateforme = etatProfilPlateforme_p;
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    MajSimGDR other = (MajSimGDR) obj;
    if (_etasmdp == null)
    {
      if (other._etasmdp != null)
      {
        return false;
      }
    }
    else if (!_etasmdp.equals(other._etasmdp))
    {
      return false;
    }
    if (_etatProfilPlateforme == null)
    {
      if (other._etatProfilPlateforme != null)
      {
        return false;
      }
    }
    else if (!_etatProfilPlateforme.equals(other._etatProfilPlateforme))
    {
      return false;
    }
    if (_notificationPointId == null)
    {
      if (other._notificationPointId != null)
      {
        return false;
      }
    }
    else if (!_notificationPointId.equals(other._notificationPointId))
    {
      return false;
    }
    if (_notificationPointStatus == null)
    {
      if (other._notificationPointStatus != null)
      {
        return false;
      }
    }
    else if (!_notificationPointStatus.equals(other._notificationPointStatus))
    {
      return false;
    }
    if (_statutTelechargement == null)
    {
      if (other._statutTelechargement != null)
      {
        return false;
      }
    }
    else if (!_statutTelechargement.equals(other._statutTelechargement))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the etasmdp
   */
  public String getEtasmdp()
  {
    return _etasmdp;
  }

  /**
   * @return the etatProfilPlateforme
   */
  public String getEtatProfilPlateforme()
  {
    return _etatProfilPlateforme;
  }

  /**
   * @return the notificationPointId
   */
  public String getNotificationPointId()
  {
    return _notificationPointId;
  }

  /**
   * @return the notificationPointStatus
   */
  public String getNotificationPointStatus()
  {
    return _notificationPointStatus;
  }

  /**
   * @return the statutTelechargement
   */
  public String getStatutTelechargement()
  {
    return _statutTelechargement;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_etasmdp == null) ? 0 : _etasmdp.hashCode());
    result = (prime * result) + ((_etatProfilPlateforme == null) ? 0 : _etatProfilPlateforme.hashCode());
    result = (prime * result) + ((_notificationPointId == null) ? 0 : _notificationPointId.hashCode());
    result = (prime * result) + ((_notificationPointStatus == null) ? 0 : _notificationPointStatus.hashCode());
    result = (prime * result) + ((_statutTelechargement == null) ? 0 : _statutTelechargement.hashCode());
    return result;
  }

  /**
   * @param etasmdp_p
   *          the etasmdp to set
   */
  public void setEtasmdp(String etasmdp_p)
  {
    _etasmdp = etasmdp_p;
  }

  /**
   * @param etatProfilPlateforme_p
   *          the etatProfilPlateforme to set
   */
  public void setEtatProfilPlateforme(String etatProfilPlateforme_p)
  {
    _etatProfilPlateforme = etatProfilPlateforme_p;
  }

  /**
   * @param notificationPointId_p
   *          the notificationPointId to set
   */
  public void setNotificationPointId(String notificationPointId_p)
  {
    _notificationPointId = notificationPointId_p;
  }

  /**
   * @param notificationPointStatus_p
   *          the notificationPointStatus to set
   */
  public void setNotificationPointStatus(String notificationPointStatus_p)
  {
    _notificationPointStatus = notificationPointStatus_p;
  }

  /**
   * @param statutTelechargement_p
   *          the statutTelechargement to set
   */
  public void setStatutTelechargement(String statutTelechargement_p)
  {
    _statutTelechargement = statutTelechargement_p;
  }

}
