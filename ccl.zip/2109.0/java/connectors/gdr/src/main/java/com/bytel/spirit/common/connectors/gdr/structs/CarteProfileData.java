/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.gdr.structs;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author fcabral
 * @version ($Revision$ $Date$)
 */
public class CarteProfileData
{
  /**
   * Field ICCID name
   */
  public static final String FIELD_ICCID = "ICCID"; //$NON-NLS-1$

  /**
   * Field CarteProfile name
   */
  public static final String FIELD_CARTE_PROFILE = "CarteProfile"; //$NON-NLS-1$

  /**
   * Field CarteProfile name
   */
  public static final String FIELD_ETAT_SMDP = "ETASMDP"; //$NON-NLS-1$

  /**
   * Field to store the ICCID
   */
  private String _iccid;

  /**
   * Field to store the CarteProfile
   */
  private String _carteProfile;

  /**
   * Field to store the EtatSmdp
   */
  private String _etatSmdp;

  /**
   * @param rs_p
   *          The ResultSet to get the value of ICCID, CarteProfile and EtatSmdp from
   * @throws SQLException
   *           on error
   */
  public CarteProfileData(ResultSet rs_p) throws SQLException
  {
    _iccid = rs_p.getString(FIELD_ICCID);
    _carteProfile = rs_p.getString(FIELD_CARTE_PROFILE);
    _etatSmdp = rs_p.getString(FIELD_ETAT_SMDP);
  }

  /**
   * @param iccid_p
   *          the ICCID value
   * @param carteProfile_p
   *          the CarteProfile value
   * @param etatSmdp_p
   *          the EtatSmdp value
   */
  public CarteProfileData(String iccid_p, String carteProfile_p, String etatSmdp_p)
  {
    _iccid = iccid_p;
    _carteProfile = carteProfile_p;
    _etatSmdp = etatSmdp_p;
  }

  /**
   * @return the carteProfile
   */
  public String getCarteProfile()
  {
    return _carteProfile;
  }

  /**
   * @return the etatSmdp
   */
  public String getEtatSmdp()
  {
    return _etatSmdp;
  }

  /**
   * @return the iccid
   */
  public String getIccid()
  {
    return _iccid;
  }

  /**
   * @param carteProfile_p
   *          the carteProfile to set
   */
  public void setCarteProfile(String carteProfile_p)
  {
    _carteProfile = carteProfile_p;
  }

  /**
   * @param etatSmdp_p
   *          the etatSmdp to set
   */
  public void setEtatSmdp(String etatSmdp_p)
  {
    _etatSmdp = etatSmdp_p;
  }

  /**
   * @param iccid_p
   *          the iccid to set
   */
  public void setIccid(String iccid_p)
  {
    _iccid = iccid_p;
  }

}
