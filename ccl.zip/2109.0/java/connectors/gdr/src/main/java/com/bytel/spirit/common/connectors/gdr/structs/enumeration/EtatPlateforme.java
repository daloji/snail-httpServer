/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.gdr.structs.enumeration;

import com.bytel.ravel.common.utils.StringTools;

/**
 *
 * @author lmerces
 * @version ($Revision$ $Date$)
 */
public enum EtatPlateforme
{
  /**
   *
   */
  ACTIF("enable", "Profil actif ok"), //$NON-NLS-1$ //$NON-NLS-2$
  /**
  *
  */
  DOWNLOAD_ACTIF("downloadEnable", null), //$NON-NLS-1$

  /**
  *
  */
  DOWNLOAD_INACTIF("downloadDisable", null), //$NON-NLS-1$

  /**
   *
   */
  INACTIF("disable", "Profil inactif ok"), //$NON-NLS-1$ //$NON-NLS-2$

  /**
   *
   */
  INSTALLE(null, "Profil installe ok"), //$NON-NLS-1$

  /**
   *
   */
  INSTALLATION_EN_ERREUR(null, "Profil installe ko"), //$NON-NLS-1$

  /**
   *
   */
  PUBLIE("release", null), //$NON-NLS-1$

  /**
   *
   */
  SUPPRIME("delete", "Profil supprime ok"), //$NON-NLS-1$ //$NON-NLS-2$

  /**
   *
   */
  TELECHARGE(null, "Profil telecharge ok"), //$NON-NLS-1$

  /**
   *
   */
  TELECHARGE_EN_ERREUR(null, "Profil telecharge ko"); //$NON-NLS-1$

  /**
   * Returns a String from an etat notif
   *
   * @param value_p
   *          value
   * @return the name of the enum
   */
  public static String fromEtatNotif(String value_p)
  {
    if (!StringTools.isNullOrEmpty(value_p))
    {
      for (EtatPlateforme etatPlateforme : EtatPlateforme.values())
      {
        if (StringTools.isNotNullOrEmpty(etatPlateforme.getEtatNotif()) && etatPlateforme.getEtatNotif().equalsIgnoreCase(value_p))
        {
          return etatPlateforme.name();
        }
      }
    }
    return null;
  }

  /**
   * Returns a String from an etat smdp
   *
   * @param value_p
   *          value
   * @return the name of the enum
   */
  public static String fromEtatSmdp(String value_p)
  {
    if (!StringTools.isNullOrEmpty(value_p))
    {
      for (EtatPlateforme etatPlateforme : EtatPlateforme.values())
      {
        if (StringTools.isNotNullOrEmpty(etatPlateforme.getEtatSmdp()) && etatPlateforme.getEtatSmdp().equalsIgnoreCase(value_p))
        {
          return etatPlateforme.name();
        }
      }
    }
    return null;
  }

  /**
   * @param value_p
   *          value
   * @return {@link EtatSMDP}
   */
  public static EtatPlateforme fromString(String value_p)
  {
    if (!StringTools.isNullOrEmpty(value_p))
    {
      for (EtatPlateforme etatPlateforme : EtatPlateforme.values())
      {
        if (StringTools.isNotNullOrEmpty(etatPlateforme.getEtatSmdp()) && etatPlateforme.getEtatSmdp().equalsIgnoreCase(value_p))
        {
          return etatPlateforme;
        }
        if (StringTools.isNotNullOrEmpty(etatPlateforme.getEtatNotif()) && etatPlateforme.getEtatNotif().equalsIgnoreCase(value_p))
        {
          return etatPlateforme;
        }
      }
    }
    return null;
  }

  /**
  *
  */
  private final String _etatSmdp;

  /**
  *
  */
  private final String _etatNotif;

  /**
   * @param etatSmdp_p
   *          etatSmdp
   * @param etatNotif_p
   *          etatNotif
   */
  EtatPlateforme(String etatSmdp_p, String etatNotif_p)
  {
    _etatSmdp = etatSmdp_p;
    _etatNotif = etatNotif_p;
  }

  /**
   * @return the etatNotif
   */
  public String getEtatNotif()
  {
    return _etatNotif;
  }

  /**
   * @return the etatSmdp
   */
  public String getEtatSmdp()
  {
    return _etatSmdp;
  }
}
