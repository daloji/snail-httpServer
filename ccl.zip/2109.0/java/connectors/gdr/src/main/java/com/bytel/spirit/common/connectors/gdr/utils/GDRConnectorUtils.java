/*******************************************************************************
* $Id: GDRConnectorUtils.java 14439 2018-12-11 11:32:44Z lmerces $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.gdr.utils;

import static com.bytel.spirit.common.connectors.gdr.utils.GDRConnectorConstants.FAILURE_INTERNAL_PORTABILITY;
import static com.bytel.spirit.common.connectors.gdr.utils.GDRConnectorConstants.SIM_STATE_DISTRIBUTED;
import static com.bytel.spirit.common.connectors.gdr.utils.GDRConnectorConstants.SIM_STATE_ERROR;
import static com.bytel.spirit.common.connectors.gdr.utils.GDRConnectorConstants.SIM_STATE_ONGOING_PORTABILITY;

import java.math.BigInteger;
import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.MessageFormat;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionTools;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.services.connector.AbstractDBConnector;
import com.bytel.spirit.common.connectors.gdr.Activable;
import com.bytel.spirit.common.connectors.gdr.IGDRConnector;
import com.bytel.spirit.common.connectors.gdr.InfoSIM;
import com.bytel.spirit.common.connectors.gdr.Messages;
import com.bytel.spirit.common.connectors.gdr.ReturnCode;
import com.bytel.spirit.common.connectors.gdr.TypeCardDescription;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

/**
 *
 * @author lmerces
 * @version ($Revision: 14439 $ $Date: 2018-12-11 12:32:44 +0100 (mar. 11 déc. 2018) $)
 */
public class GDRConnectorUtils
{
  /**
   * Build a log entry and throws an {@link RavelException} for a technical problem.
   *
   * @param exc_p
   *          The {@link Exception} raised
   * @param tracabilite_p
   *          The current MsgId
   * @param spName_p
   *          The stored procedure name in which the fault was raised.
   * @param inputs_p
   *          A string representing input data of the stored procedure.
   * @return RavelException The technical exception.
   */
  public static RavelException buildTechnicalException(Exception exc_p, Tracabilite tracabilite_p, String spName_p, String inputs_p)
  {
    final String message = buildTechnicalMessage(exc_p, tracabilite_p, spName_p, inputs_p);
    return new RavelException(ExceptionType.PFS_EXCEPTION, ErrorCode.CNCTOR_00010, message, IGDRConnector.BEAN_ID, exc_p);
  }

  /**
   * Build a log entry for a technical problem.
   *
   * @param exc_p
   *          The {@link Exception} raised
   * @param tracabilite_p
   *          The current MsgId
   * @param spName_p
   *          The stored procedure name in which the fault was raised.
   * @param inputs_p
   *          A string representing input data of the stored procedure.
   * @return String The message of technical exception.
   */
  public static String buildTechnicalMessage(Exception exc_p, Tracabilite tracabilite_p, String spName_p, String inputs_p)
  {
    final String message;
    if (exc_p instanceof SQLException)
    {
      final SQLException exc = SQLException.class.cast(exc_p);
      message = new StringBuilder().append(MessageFormat.format(Messages.getString("GDRConnector.TechnicalExceptionMessage"), spName_p, exc.getErrorCode(), exc.getLocalizedMessage())).append(ExceptionTools.getExceptionLineAndFile(exc_p)).toString(); //$NON-NLS-1$
    }
    else
    {
      message = new StringBuilder().append(MessageFormat.format(Messages.getString("GDRConnector.TechnicalExceptionMessage"), spName_p, exc_p.getMessage(), exc_p.getLocalizedMessage())).append(ExceptionTools.getExceptionLineAndFile(exc_p)).toString(); //$NON-NLS-1$
    }
    RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, message));
    return message;
  }

  /**
   * Retrieve out parameters named Retour_Resultat, Retour_Diagnostic, Retour_Categorie & Retour_Libelle to build the
   * {@link Retour} object. If a parameter does not exist, an exception is raised.
   *
   * @param cs_p
   *          The {@link CallableStatement} from which the {@link Retour} data must be retreived.
   * @return The {@link Retour} objet.
   * @throws SQLException
   *           see {@link CallableStatement#getString(String)}
   */
  public static Retour getRetour(CallableStatement cs_p) throws SQLException
  {
    return RetourFactory.createRetour(cs_p.getString(AbstractDBConnector.RETOUR_RESULTAT), cs_p.getString(AbstractDBConnector.RETOUR_CATEGORIE), cs_p.getString(AbstractDBConnector.RETOUR_DIAGNOSTIC), cs_p.getString(AbstractDBConnector.RETOUR_LIBELLE));
  }

  /**
   * Map values from the result set to an InformationsSim object
   *
   * @param tracabilite_p
   *          The current MsgId
   * @param informationSim_p
   *          object to be mapped
   * @param resultSet_p
   *          result set obtained from the stored procedure
   * @throws SQLException
   *           exception thrown while reading the result set
   */
  protected void mapValuesFromResultSet(Tracabilite tracabilite_p, InfoSIM informationSim_p, ResultSet resultSet_p) throws SQLException
  {
    informationSim_p.setCodeRetourSecondaire(ReturnCode.OK);
    informationSim_p.setImsi(resultSet_p.getLong(1));
    informationSim_p.setIccid(resultSet_p.getLong(2));

    informationSim_p.setHlr(BigInteger.valueOf(resultSet_p.getLong(3)));

    if (resultSet_p.getString(4) != null)
    {
      informationSim_p.setTypeGencod(resultSet_p.getString(4));
    }
    else
    {
      informationSim_p.setTypeGencod(StringConstants.EMPTY_STRING);
    }
    informationSim_p.setCodePin1(String.valueOf(resultSet_p.getLong(5)));
    informationSim_p.setCodePin2(String.valueOf(resultSet_p.getLong(6)));
    informationSim_p.setCodePuk1(String.valueOf(resultSet_p.getLong(7)));
    informationSim_p.setCodePuk2(String.valueOf(resultSet_p.getLong(8)));
    informationSim_p.setTypeCarte(BigInteger.valueOf(resultSet_p.getLong(9)));

    // sets the description for the card type
    try
    {
      TypeCardDescription enumLibelleTypeCarte = TypeCardDescription.fromValue(resultSet_p.getString(12));
      informationSim_p.setLibelleTypeCarte(enumLibelleTypeCarte);
    }
    catch (IllegalArgumentException e)
    {
      String errorMessage = MessageFormat.format(Messages.getString("GDRConnector.ErrorCardTypeDescription"), resultSet_p.getString(12)); //$NON-NLS-1$
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, errorMessage));
    }

    informationSim_p.setProfilElectrique(resultSet_p.getString(10));
    informationSim_p.setTypeSim(BigInteger.valueOf(resultSet_p.getInt(13)));
    informationSim_p.setTypageReseau(BigInteger.valueOf(resultSet_p.getInt(15)));

    final int identifiantAction = resultSet_p.getInt(14);
    String simState = resultSet_p.getString(11);
    Activable activated;

    if (simState.equals(SIM_STATE_ERROR) && (identifiantAction == FAILURE_INTERNAL_PORTABILITY))
    {
      simState = SIM_STATE_ONGOING_PORTABILITY;
      activated = Activable.O; // O -> yes
    }
    else if (simState.equals(SIM_STATE_DISTRIBUTED) || simState.equals(SIM_STATE_ONGOING_PORTABILITY))
    {
      activated = Activable.O; // O -> yes
    }
    else
    {
      activated = Activable.N; // N -> No
    }
    informationSim_p.setActivable(activated);
    informationSim_p.setEtatSim(simState);
  }
}
