/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.gdr.structs.enumeration;

import java.util.Arrays;
import java.util.stream.IntStream;

/**
 * Support enum defined in PE0304 STI. Used in PE0304_SimV2 object.
 *
 * @author jgregori
 * @version ($Revision$ $Date$)
 */
public enum Support
{
  /**
   *
   */
  ESIM(5),
  /**
  *
  */
  ESIM_PHYSIQUE(6),
  /**
  *
  */
  FICTIF(4),
  /**
  *
  */
  SIM_PHYSIQUE(1, 2, 3);

  /**
   * @param value_p
   *          value
   * @return {@link Support}
   */
  public static Support fromTypeSim(int value_p)
  {
    for (Support support : Support.values())
    {
      if (IntStream.of(support._typeSim).anyMatch(x -> x == value_p))
      {
        return support;
      }
    }
    return null;
  }

  /**
   *
   */
  private int[] _typeSim;

  /**
   * @param typeSim_p
   *          typeSim
   *
   */
  private Support(int... typeSim_p)
  {
    _typeSim = typeSim_p != null ? Arrays.copyOf(typeSim_p, typeSim_p.length) : null;
  }

}
