/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.gdr;

import java.time.LocalDateTime;
import java.util.List;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.connectors.gdr.structs.BYTPRD;
import com.bytel.spirit.common.connectors.gdr.structs.CMDSIM;
import com.bytel.spirit.common.connectors.gdr.structs.CarteProfileData;
import com.bytel.spirit.common.connectors.gdr.structs.DURMSI;
import com.bytel.spirit.common.connectors.gdr.structs.ErreurSMDP;
import com.bytel.spirit.common.connectors.gdr.structs.HISETASIM;
import com.bytel.spirit.common.connectors.gdr.structs.ICallbackLireSim;
import com.bytel.spirit.common.connectors.gdr.structs.MSISDN;
import com.bytel.spirit.common.connectors.gdr.structs.PRF;
import com.bytel.spirit.common.connectors.gdr.structs.SUIVISMDP;
import com.bytel.spirit.common.connectors.gdr.structs.Sim;
import com.bytel.spirit.common.connectors.gdr.structs.StatistiqueEsim;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

/**
 * The Interface IGDR for GDR (Gestion de ressources) DB operations.
 *
 * @author $Author$
 * @version ($Revision$ $Date$)
 */
public interface IGDR
{
  /**
   * Invocation of the stored procedure P_CONSULT_ETAT_BATCH. Check state Sim Batch.
   *
   * @param tracabilite_p
   *          la tracabilite
   * @param idBatch_p
   * @param listeTypeSim_p
   * @return
   * @throws RavelException
   */
  public ConnectorResponse<Long, Retour> checkEtatSimBatch(Tracabilite tracabilite_p, long idBatch_p, String listeTypeSim_p) throws RavelException;

  /**
   * Invocation of the stored procedure P_CONSULT_ETAT_BATCH. Search batch state.
   *
   * @param tracabilite_p
   * @param idBatch_p
   * @return
   * @throws RavelException
   */
  public ConnectorResponse<String, Retour> consultEtatBatch(Tracabilite tracabilite_p, long idBatch_p) throws RavelException;

  /**
   * Invocation of the stored procedure P_CONSULT_SIM_BATCH.
   *
   * @param tracabilite_p
   *          la tracabilite
   * @param idBatch_p
   * @param etasim_p
   * @param listeTypeSim_p
   * @return
   * @throws RavelException
   */
  public ConnectorResponse<ConsultSimBatch, Retour> consultSimBatch(Tracabilite tracabilite_p, long idBatch_p, String etasim_p, String listeTypeSim_p) throws RavelException;

  /**
   * Invocation of the stored procedure P_MAJ_ETAT_BATCH. Search batch state.
   *
   * @param tracabilite_p
   *          la tracabilite
   * @param idBatch_p
   * @return
   * @throws RavelException
   */
  public ConnectorResponse<String, Retour> majEtatBatch(Tracabilite tracabilite_p, long idBatch_p) throws RavelException;

  /**
   * Invocation of the stored procedure P_MISE_A_DISPOSITION_SIM_BATCH.
   *
   * @param tracabilite_p
   *          la tracabilite
   * @param idBatch_p
   * @param listeTypeSim_p
   * @param instanceCliente_p
   * @return
   * @throws RavelException
   */
  public ConnectorResponse<String, Retour> miseADispositionSimBatch(Tracabilite tracabilite_p, long idBatch_p, String listeTypeSim_p, String instanceCliente_p) throws RavelException;

  /**
   * Consult TYPE MSISDN FROM Type.
   *
   * @param tracabilite_p
   *          la tracabilite
   * @param typeMsisdn_p
   *          Type identifier MSISDN
   * @return The TypeMsisdn information and a Retour object with the result.
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  public ConnectorResponse<TypeMsisdn, Retour> ps001ConsultTYPEMSIFROMType(Tracabilite tracabilite_p, Integer typeMsisdn_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          la tracabilite
   * @param instanceCliente_p
   *          The instanceCliente
   * @param nbMsisdn_p
   *          The nbMsisdn
   * @param mode_p
   *          The mode
   * @param typeMsisdn_p
   *          The typeMsisdn
   * @param critereRecherche_p
   *          The critereRecherche
   * @param typeReservation_p
   *          The typeReservation
   * @param etatCible_p
   *          The etatCible
   * @param dureeReservation_p
   *          The dureeReservation
   * @param idReservationMSISDN_p
   *          The idReservationMSISDN
   * @return The List of Msisdn and Retour object with the result
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  public ConnectorResponse<List<MSISDN>, Retour> ps002ReserveMSISDNFROMModeCritere(Tracabilite tracabilite_p, final String instanceCliente_p, final Integer nbMsisdn_p, final String mode_p, final Integer typeMsisdn_p, final Integer critereRecherche_p, final Integer typeReservation_p, final String etatCible_p, final String dureeReservation_p, final int dureeReservationTemporaire_p, final String idReservationMSISDN_p, String idtdermod) throws RavelException;

  /**
   * Résiliation d'un MSISDN.
   *
   * @param tracabilite_p
   *          la tracabilite
   * @param msisdn_p
   *          MSISDN à résilier
   * @return un string: l'état de la résiliation
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  public ConnectorResponse<String, Retour> ps003ResiliationMSISDN(Tracabilite tracabilite_p, String msisdn_p) throws RavelException;

  /**
   * Retourne un IMSI a partir d'un ICCID
   *
   * @param tracabilite_p
   *          la tracabilite
   * @param iccid_p
   *          ICCID a rechercher
   *
   * @return le IMSI
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  public ConnectorResponse<String, Retour> ps004GetIMSIFromICCID(Tracabilite tracabilite_p, String iccid_p) throws RavelException;

  /**
   * Invocation of the stored procedure P_005_CONSULT_CARTE_PROFILE. Search carte profile info by ICCID or IMSI
   *
   * @param tracabilite_p
   *          la racabilite
   * @param iccid_p
   *          The ICCID, not null if we want to search by ICCID else null
   * @param imsi_p
   *          The IMSI, not null if we want to search by IMSI else null
   * @return The information about carte profile
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  public ConnectorResponse<List<CarteProfileData>, Retour> ps005ConsultCarteProfile(Tracabilite tracabilite_p, String iccid_p, String imsi_p) throws RavelException;

  /**
   * Retourne l'objet MSISDN a partir d'un MSISDN (NUMTEL)
   *
   * @param tracabilite_p
   *          la tracabilite
   * @param msisdn_p
   *          NUMTEL a rechercher
   *
   * @return MSISDN
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  public ConnectorResponse<MSISDN, Retour> ps006ConsultMSISDN(Tracabilite tracabilite_p, String msisdn_p) throws RavelException;

  /**
   * Restitue l'objet DURMSI à partir d'un typeMSISDN et une instanceCliente
   *
   * @param tracabilite_p
   *          la tracabilite
   * @param typeMSISDN_p
   *          Type du MSISDN
   * @param instanceCliente_p
   *          Identifiant de l'instance client
   * @return DURMSI
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  public ConnectorResponse<DURMSI, Retour> ps007ConsultDureeQuarantaine(Tracabilite tracabilite_p, Integer typeMSISDN_p, String instanceCliente_p) throws RavelException;

  /**
   * Retourne l'instance cliente a partir d'un MSISDN (NUMTEL)
   *
   * @param tracabilite_p
   *          la tracabilite
   * @param numtel_p
   *          NUMTEL a rechercher
   *
   * @return instanceCliente
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  public ConnectorResponse<String, Retour> ps008ConsultLatestHistoriqueEtatMSISDN(Tracabilite tracabilite_p, String numtel_p) throws RavelException;

  /**
   * Retourne un ICCID a partir d'un IMSI
   *
   * @param tracabilite_p
   *          la tracabilite
   * @param imsi_p
   *          IMSI a rechercher
   *
   * @return le ICCID
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  public ConnectorResponse<String, Retour> ps009GetICCIDFromIMSI(Tracabilite tracabilite_p, String imsi_p) throws RavelException;

  /**
   * Invocation of the stored procedure P_010_ReattribuerMSISDN.
   *
   * @param tracabilite_p
   *          la tracabilite
   * @param numtel_p
   *          numtel a rechercher
   * @param etatCibleMsisdn_p
   *          etatCibleMsisdn maj
   * @param etatCibleCom_p
   *          etatCibleCom maj
   * @param etatCiblePorta_p
   *          etatCiblePorta maj
   * @param objetModification_p
   *          objetModification maj
   * @param instanceCliente_p
   *          instanceCliente maj
   *
   * @return The information about the SIM {@link Retour}.
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  public ConnectorResponse<String, Retour> ps010ReattribuerMSISDN(Tracabilite tracabilite_p, long numtel_p, String etatCibleMsisdn_p, String etatCibleCom_p, String etatCiblePorta_p, Integer objetModification_p, String instanceCliente_p) throws RavelException;

  /**
   * Invocation of the stored procedure PS_0009GetICCIDFromIMSI2 . Search information by IMSI
   *
   * @param tracabilite_p
   *          la tracabilite
   * @param imsi_p
   * @return Sim avec info de la table GDR SIM
   * @throws RavelException
   */

  public ConnectorResponse<Sim, Retour> ps012GetICCIDFromIMSI(Tracabilite tracabilite_p, String imsi_p) throws RavelException;

  /**
   * Invocation of the stored procedure P_013_Udpate_EtatMsisdn
   *
   * @param tracabilite_p
   *          la tracabilite
   * @param numtel_p
   *          NUMTEL a rechercher
   * @param etatCibleMsisdn_p
   *          etatCibleMsisdn
   * @param idtAcnMsi_p
   *          idtAcnMsi
   * @param instanceCliente_p
   *          instanceCliente
   * @param idtdermod_p
   *          IDTDERMOD
   *
   * @return Retour
   * @throws RavelException
   */
  public ConnectorResponse<Boolean, Retour> ps013UpdateEtatMsisdn(Tracabilite tracabilite_p, Long numtel_p, String etatCibleMsisdn_p, Integer idtAcnMsi_p, String instanceCliente_p, String idtdermod_p) throws RavelException;

  /**
   * Invocation of the stored procedure P_GDR_Recherche_Info_ICCID. Search information by SIM ICCID.
   *
   * @param tracabilite_p
   *          la tracabilite
   * @param iccid_p
   *          ICCID a rechercher
   *
   * @return The information about the SIM {@link Retour}.
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */

  public ConnectorResponse<InfoSIM, Retour> rechercheInformationsICCID(Tracabilite tracabilite_p, long iccid_p) throws RavelException;

  /**
   * Invocation of the stored procedure P_GDR_Recherche_Info_IMSI. Search information by IMSI.
   *
   * @param tracabilite_p
   *          la tracabilite
   * @param imsi_p
   *          IMSI a rechercher
   *
   * @return The information about the SIM {@link Retour}.
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  public ConnectorResponse<InfoSIM, Retour> rechercheInformationsIMSI(Tracabilite tracabilite_p, long imsi_p) throws RavelException;

  /**
   * Invocation of the stored procedure PG_SPIRIT.P_COMPTERETATESIM.
   *
   * @param tracabilite_p
   *          la tracabilite
   * @param peConsumer_p
   *          the peConsumer
   * @param peM2M_p
   *          the peM2M_p
   * @return {@link ConnectorResponse}
   * @throws RavelException
   *           in case of error
   */
  ConnectorResponse<Nothing, Retour> compterEtatESim(Tracabilite tracabilite_p, List<Integer> peConsumer_p, List<Integer> peM2M_p) throws RavelException;

  /**
   * Invocation of the stored procedure PG_REPORTING_GDS.PR_EXT_MSISDN_BYTEL_ACTIFS. Count IMSI.
   *
   * @param tracabilite_p
   *          la tracabilite
   * @return The count of actifs Integer.
   * @throws RavelException
   */
  ConnectorResponse<Integer, Retour> countMsisdnBytelActifs(Tracabilite tracabilite_p) throws RavelException;

  /**
   * Get Erreur Smdp by Iccid
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param iccid_p
   *          iccid
   * @return {@link ConnectorResponse}
   * @throws RavelException
   *           exception
   */
  ConnectorResponse<List<ErreurSMDP>, Retour> getErreurSmdpByIccid(Tracabilite tracabilite_p, String iccid_p) throws RavelException;

  /**
   * Get Hisetasim by IdtSim
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param idtSim_p
   *          idtSim
   * @return {@link ConnectorResponse}
   * @throws RavelException
   *           exception
   */
  ConnectorResponse<List<HISETASIM>, Retour> getHisetaSimByIdtSim(Tracabilite tracabilite_p, String idtSim_p) throws RavelException;

  /**
   *
   * @param tracabilite_p
   * @param idtsim_p
   * @return
   * @throws RavelException
   */
  ConnectorResponse<String, Retour> getInstanceClienteSim(Tracabilite tracabilite_p, String idtsim_p) throws RavelException;

  /**
   *
   * @param tracabilite_p
   * @param idtprf_p
   * @return
   * @throws RavelException
   */
  ConnectorResponse<PRF, Retour> getPRFByIdtPrf(Tracabilite tracabilite_p, String idtprf_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param idtprf_p
   *          idtprf
   * @param typprf_p
   *          typprf
   * @return {@link ConnectorResponse}
   * @throws RavelException
   *           exception
   */
  ConnectorResponse<String, Retour> getProfilElectriqueParIdentifiant(Tracabilite tracabilite_p, String idtprf_p, String typprf_p) throws RavelException;

  /**
   *
   * @param tracabilite_p
   * @param gnc_p
   * @return {@link ConnectorResponse}
   * @throws RavelException
   */
  ConnectorResponse<List<Sim>, Retour> getSimByGnc(Tracabilite tracabilite_p, String gnc_p) throws RavelException;

  /**
   *
   * @param tracabilite_p
   * @param iccid_p
   * @param imsi_p
   * @return {@link ConnectorResponse}
   * @throws RavelException
   */
  ConnectorResponse<Sim, Retour> getSimByIccidOrImsi(Tracabilite tracabilite_p, String iccid_p, String imsi_p) throws RavelException;

  /**
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param typeSimANotifier_p
   *          typeSimANotifier
   * @param nbSimToTreat_p
   *          nbSimToTreat
   * @return {@link ConnectorResponse}
   * @throws RavelException
   *           on error
   */
  ConnectorResponse<List<Sim>, Retour> getSIMDistribuables(Tracabilite tracabilite_p, List<Integer> typeSimANotifier_p, Integer nbSimToTreat_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param idtCmd_p
   *          idtCmd
   * @param etatMoc_p
   *          etatMoc
   * @return {@link ConnectorResponse}
   * @throws RavelException
   *           exception
   */
  ConnectorResponse<List<Sim>, Retour> getSimsNonPreProvisionnes(Tracabilite tracabilite_p, String idtCmd_p, String etatMoc_p) throws RavelException;

  /**
   * Get statistiques Esim
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param periodicite_p
   *          periodicite
   * @return {@link ConnectorResponse}
   * @throws RavelException
   *           exception
   */
  ConnectorResponse<List<StatistiqueEsim>, Retour> getStatistiquesEsim(Tracabilite tracabilite_p, String periodicite_p) throws RavelException;

  /**
   * Insert Erreur Smdp.
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param iccid_p
   *          iccid
   * @param requestid_p
   *          requestid
   * @param etaterreur_p
   *          etaterreur
   * @param dat_p
   *          dat
   * @param idtdermod_p
   *          idtdermod
   * @param etatrequete_p
   *          etatrequete
   * @param entiteerreur_p
   *          entiteerreur
   * @param raisonerreur_p
   *          raisonerreur
   * @param libelleerreur_p
   *          libelleerreur
   * @return {@link ConnectorResponse}
   * @throws RavelException
   *           exception
   */
  ConnectorResponse<Nothing, Retour> insertErreurSmdp(Tracabilite tracabilite_p, String iccid_p, String requestid_p, String etaterreur_p, LocalDateTime dat_p, String idtdermod_p, String etatrequete_p, String entiteerreur_p, String raisonerreur_p, String libelleerreur_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          tracabilite
   * @param iccid_p
   *          iccid
   * @param etatSmdp_p
   *          etatsmdp
   * @param statutTelechargement_p
   *          statut
   * @param objetModification_p
   *          object modification
   * @param timestamp_p
   *          the timestamp
   * @param eid_p
   *          eid
   * @return {@link ConnectorResponse}
   * @throws RavelException
   *           exception
   */
  ConnectorResponse<String, Retour> mettreAJourSIM(Tracabilite tracabilite_p, String iccid_p, String etatSmdp_p, String statutTelechargement_p, String objetModification_p, String timestamp_p, String eid_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          tracabilite
   * @param iccid_p
   *          iccid
   * @param etatSmdp_p
   *          etatSmdp
   * @param identifiantAction_p
   *          identifiantAction
   * @param objetModification_p
   *          objetModification
   * @param datEta_p
   *          datEta
   * @param statutNotif_p
   *          statutNotif
   * @return ConnectorResponse<String, Retour>
   * @throws RavelException
   *           On Error
   */
  ConnectorResponse<String, Retour> mettreAJourSIMNotif(Tracabilite tracabilite_p, String iccid_p, String etatSmdp_p, String identifiantAction_p, String objetModification_p, String datEta_p, String statutNotif_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param iccid_p
   *          iccid
   * @param notifAppro_p
   *          notifAppro
   * @return {@link ConnectorResponse}
   * @throws RavelException
   *           on error
   */
  ConnectorResponse<Nothing, Retour> mettreAJourSIMNotifAppro(Tracabilite tracabilite_p, String iccid_p, String notifAppro_p) throws RavelException;

  /**
   * Invocation of the stored procedure P_010_ReattribuerMSISDN.
   *
   * @param tracabilite_p
   *          la tracabilite
   * @param iccid_p
   *          iccid a mettre à jour
   * @param etatSimCible_p
   *          etatSimCible
   * @param objetModification_p
   *          objetModification
   * @param etatComCible_p
   *          etatComCible
   * @param etatPorCible_p
   *          etatPorCible
   * @param identifiantModif_p
   *          identifiantModif
   * @param instanceCliente_p
   *          instanceCliente
   * @return Retour
   * @throws RavelException
   *           instanceCliente_p
   */
  ConnectorResponse<String, Retour> ps011UpdateSIMFromICCID(Tracabilite tracabilite_p, String iccid_p, String etatSimCible_p, Integer objetModification_p, String etatComCible_p, String etatPorCible_p, String identifiantModif_p, String instanceCliente_p) throws RavelException;

  /**
   * @param tracabilite_p
   * @param idtprfele_p
   * @return
   * @throws RavelException
   */
  ConnectorResponse<List<String>, Retour> ps014GetIdentifiantsCommande(Tracabilite tracabilite_p, String idtprfele_p) throws RavelException;

  /**
   * @param tracabilite_p
   * @param idtprf_p
   * @return
   * @throws RavelException
   */
  ConnectorResponse<String, Retour> ps015GetProfileType(Tracabilite tracabilite_p, String idtprf_p) throws RavelException;

  /**
   * @param tracabilite_p
   * @param idtcmd_p
   * @return
   * @throws RavelException
   */
  ConnectorResponse<List<String>, Retour> ps016GetIccidsParldtCmd(Tracabilite tracabilite_p, String idtcmd_p) throws RavelException;

  /**
   * @param tracabilite_p
   * @param idtcmd_p
   * @return
   * @throws RavelException
   */
  ConnectorResponse<LocalDateTime, Retour> ps017GetDateDerniereEchec(Tracabilite tracabilite_p, String idtcmd_p) throws RavelException;

  /**
   * @param tracabilite_p
   * @param idtcmd_p
   * @return
   * @throws RavelException
   */
  ConnectorResponse<Nothing, Retour> ps018SetDateDerniereEchec(Tracabilite tracabilite_p, String idtcmd_p) throws RavelException;

  /**
   * @param tracabilite_p
   * @param idtacnsim_p
   * @param idtdermod_p
   * @param etasmdp_p
   * @return
   * @throws RavelException
   */
  ConnectorResponse<Nothing, Retour> ps019UpdateSimDownload(Tracabilite tracabilite_p, String iccid_p, String idtacnsim_p, String idtdermod_p, String etasmdp_p) throws RavelException;

  /**
   * @param tracabilite_p
   * @param idtcmd_p
   * @return
   * @throws RavelException
   */
  ConnectorResponse<Nothing, Retour> ps020UpdateQuantity(Tracabilite tracabilite_p, String idtcmd_p) throws RavelException;

  /**
   * @param tracabilite_p
   * @param idtcmd_p
   * @return
   * @throws RavelException
   */
  ConnectorResponse<List<CMDSIM>, Retour> ps021GetCommandesNonNotifies(Tracabilite tracabilite_p) throws RavelException;

  /**
   * @param tracabilite_p
   * @param idtcmd_p
   * @return
   * @throws RavelException
   */
  ConnectorResponse<CMDSIM, Retour> ps022GetCommande(Tracabilite tracabilite_p, String idtcmd_p) throws RavelException;

  /**
   * @param tracabilite_p
   * @param idtcmd_p
   * @param envoinotifsap_p
   * @return
   * @throws RavelException
   */
  ConnectorResponse<Nothing, Retour> ps023UpdateEnvoiCmdSim(Tracabilite tracabilite_p, String idtcmd_p, String envoinotifsap_p) throws RavelException;

  /**
   * @param tracabilite_p
   * @param gnc_p
   * @return
   * @throws RavelException
   */
  ConnectorResponse<List<BYTPRD>, Retour> ps024GetBytprd(Tracabilite tracabilite_p, String gnc_p) throws RavelException;

  /**
   * @param tracabilite_p
   * @return
   * @throws RavelException
   */
  ConnectorResponse<List<SUIVISMDP>, Retour> ps025GetSUIVISMDP(Tracabilite tracabilite_p, String idtcmd_p) throws RavelException;

  /**
   * @param tracabilite_p
   * @param idtcmd_p
   * @param nomfichier_p
   * @return
   * @throws RavelException
   */
  ConnectorResponse<Nothing, Retour> ps026EnregistrerEnvoiFichier(Tracabilite tracabilite_p, String idtcmd_p, String nomfichier_p) throws RavelException;

  /**
   * @param tracabilite_p
   * @param idtcmd_p
   * @return
   * @throws RavelException
   */
  ConnectorResponse<SUIVISMDP, Retour> ps027GetSUIVISMDPDernierEchec(Tracabilite tracabilite_p, String idtcmd_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param pe_p
   *          pe
   * @param etatMoc_p
   *          etatMoc
   * @return {@link ConnectorResponse}
   * @throws RavelException
   *           exception
   */
  ConnectorResponse<Nothing, Retour> updateSimEtatMoc(Tracabilite tracabilite_p, String pe_p, String etatMoc_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param imsi_p
   *          imsi
   * @param etatMoc_p
   *          etatMoc
   * @return {@link ConnectorResponse}
   * @throws RavelException
   *           exception
   */
  ConnectorResponse<Nothing, Retour> updateSimEtatMocImsi(Tracabilite tracabilite_p, String imsi_p, String etatMoc_p) throws RavelException;

  /**
   * @param tracabilite_p
   * @param iccid_p
   * @param etaSim_p
   * @param idtAcnSim_p
   * @param idtDermod_p
   * @param idtist_p
   * @param etasmdp_p
   * @param etatNotif_p
   * @param policyEtat_p
   * @param policyHabilitation_p
   * @param eid_p
   * @param smsrid_p
   * @return {@link ConnectorResponse}
   * @throws RavelException
   */
  ConnectorResponse<Nothing, Retour> updateSimRessource(Tracabilite tracabilite_p, String iccid_p, String etaSim_p, Long idtAcnSim_p, String idtDermod_p, String idtist_p, String etasmdp_p, String etatNotif_p, String policyEtat_p, String policyHabilitation_p, String eid_p, String smsrid_p) throws RavelException;

  /**
   * Get a list of profiles eSim from GDR.
   *
   * @param tracabilite_p the tracabilite.
   * @param typeSim_p the type of Sim.
   * @param profileType_p the type of profile.
   * @param callback_p the callback.
   * @param listSize_p the size of the list returned by the callback.
   * @return a pair with Nothing and the Retour. (Needs to be a pair)
   * @throws RavelException on error.
   */
  ConnectorResponse<Nothing, Retour> getEsimProfileStatus(Tracabilite tracabilite_p, String typeSim_p, String profileType_p, ICallbackLireSim callback_p, int listSize_p) throws RavelException;
}
