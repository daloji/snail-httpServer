/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.gdr.utils;

import java.sql.Connection;
import java.sql.SQLException;

import oracle.jdbc.OracleConnection;
import oracle.sql.ARRAY;
import oracle.sql.ArrayDescriptor;

/**
 *
 * @author rrosa
 * @version ($Revision$ $Date$)
 */
public class ArrayDescriptorFactory
{
  /**
   * @param arrayDescriptor
   * @param conn
   * @param object
   * @return
   * @throws SQLException
   */
  public ARRAY createARRAY(ArrayDescriptor arrayDescriptor, OracleConnection conn, Object object) throws SQLException
  {
    return new ARRAY(arrayDescriptor, conn, object);
  }

  /**
   * @param name
   * @param connection
   * @return
   * @throws SQLException
   */
  public ArrayDescriptor makeArrayDescriptor(String name, Connection connection) throws SQLException
  {
    return ArrayDescriptor.createDescriptor(name, connection);
  }
}