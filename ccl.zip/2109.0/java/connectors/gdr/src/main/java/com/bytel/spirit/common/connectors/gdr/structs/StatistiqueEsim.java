/*******************************************************************************
* $Id: StatistiqueEsim.java 17197 2019-02-15 08:58:29Z vloureir $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.gdr.structs;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

/**
 *
 * @author asoares
 * @version ($Revision: 17197 $ $Date: 2019-02-15 09:58:29 +0100 (ven. 15 févr. 2019) $)
 */
public class StatistiqueEsim
{
  /**
   * Constant with the value of the Table Column for DATECOMPTAGE
   */
  public static final String DATECOMPTAGE = "DATECOMPTAGE"; //$NON-NLS-1$

  /**
   * Constant with the value of the Table Column for TYPECOMPTAGE
   */
  public static final String TYPECOMPTAGE = "TYPECOMPTAGE"; //$NON-NLS-1$

  /**
   * Constant with the value of the Table Column for GENCOD
   */
  public static final String GENCOD = "GENCOD"; //$NON-NLS-1$

  /**
   * Constant with the value of the Table Column for PROFILELECTRIQUE
   */
  public static final String PROFILELECTRIQUE = "PROFILELECTRIQUE"; //$NON-NLS-1$

  /**
   * Constant with the value of the Table Column for CODEARTICLESAP
   */
  public static final String CODEARTICLESAP = "CODEARTICLESAP"; //$NON-NLS-1$

  /**
   * Constant with the value of the Table Column for PROFILETYPE
   */
  public static final String PROFILETYPE = "PROFILETYPE"; //$NON-NLS-1$

  /**
   * Constant with the value of the Table Column for ENCARTEUR
   */
  public static final String ENCARTEUR = "ENCARTEUR"; //$NON-NLS-1$

  /**
   * Constant with the value of the Table Column for QUANTITE
   */
  public static final String QUANTITE = "QUANTITE"; //$NON-NLS-1$

  /**
   * Constant with the value of the Table Column for ALERTE
   */
  public static final String ALERTE = "ALERTE"; //$NON-NLS-1$

  /**
   * Date utilisée pour la recherche de l'iccid
   */
  private Date _dateComptage;

  /**
   * Type de comptage effectué
   */
  private String _typeComptage;

  /**
   * Gencod
   */
  private Long _gencod;

  /**
   * Profil electrique au format xy.za
   */
  private String _profilElectrique;

  /**
   * Code article SAP
   */
  private String _codeArticleSAP;

  /**
   * Type d'utilisation de profil
   */
  private String _profileType;

  /**
   * Fournisseur de la carte eSim
   */
  private String _encarteur;

  /**
   * Nombre de eSim
   */
  private int _quantite;

  /**
   * Comparaison avec le seuil présent dans la table PRF
   */
  private String _alert;

  /**
   * @param dateComptage_p
   *          The date comptage
   * @param typeComptage_p
   *          The type comptage
   * @param gencod_p
   *          The gencod
   * @param profilElectrique_p
   *          The profil electrique
   * @param codeArticleSAP_p
   *          The code article SAP
   * @param profileType_p
   *          The profile type
   * @param encarteur_p
   *          The encarteur
   * @param quantite_p
   *          The quantite
   * @param alert_p
   *          The alert
   */
  public StatistiqueEsim(Date dateComptage_p, String typeComptage_p, Long gencod_p, String profilElectrique_p, String codeArticleSAP_p, String profileType_p, String encarteur_p, int quantite_p, String alert_p)
  {
    super();

    if (dateComptage_p != null)
    {
      this._dateComptage = (Date) dateComptage_p.clone();
    }
    _typeComptage = typeComptage_p;
    _gencod = gencod_p;
    _profilElectrique = profilElectrique_p;
    _codeArticleSAP = codeArticleSAP_p;
    _profileType = profileType_p;
    _encarteur = encarteur_p;
    _quantite = quantite_p;
    _alert = alert_p;
  }

  /**
   * Create a new instance StatistiqueEsim from a ResultSet
   *
   * @param rs
   *          ResultSet
   * @throws SQLException
   *           exception
   */
  public StatistiqueEsim(ResultSet rs) throws SQLException
  {
    super();
    _dateComptage = rs.getTimestamp(DATECOMPTAGE);
    _typeComptage = rs.getString(TYPECOMPTAGE);
    _gencod = rs.getBigDecimal(GENCOD) != null ? rs.getLong(GENCOD) : null;
    _profilElectrique = rs.getString(PROFILELECTRIQUE);
    _codeArticleSAP = rs.getString(CODEARTICLESAP);
    _profileType = rs.getString(PROFILETYPE);
    _encarteur = rs.getString(ENCARTEUR);
    _quantite = rs.getInt(QUANTITE);
    _alert = rs.getString(ALERTE);
  }

  /**
   * @return the alert
   */
  public String getAlert()
  {
    return _alert;
  }

  /**
   * @return the codeArticleSAP
   */
  public String getCodeArticleSAP()
  {
    return _codeArticleSAP;
  }

  /**
   * @return the dateComptage
   */
  public Date getDateComptage()
  {
    if (_dateComptage != null)
    {
      return (Date) _dateComptage.clone();
    }

    return null;
  }

  /**
   * @return the encarteur
   */
  public String getEncarteur()
  {
    return _encarteur;
  }

  /**
   * @return the gencod
   */
  public Long getGencod()
  {
    return _gencod;
  }

  /**
   * @return the profilElectrique
   */
  public String getProfilElectrique()
  {
    return _profilElectrique;
  }

  /**
   * @return the profileType
   */
  public String getProfileType()
  {
    return _profileType;
  }

  /**
   * @return the quantite
   */
  public int getQuantite()
  {
    return _quantite;
  }

  /**
   * @return the typeComptage
   */
  public String getTypeComptage()
  {
    return _typeComptage;
  }

  /**
   * @param alert_p
   *          the alert to set
   */
  public void setAlert(String alert_p)
  {
    _alert = alert_p;
  }

  /**
   * @param codeArticleSAP_p
   *          the codeArticleSAP to set
   */
  public void setCodeArticleSAP(String codeArticleSAP_p)
  {
    _codeArticleSAP = codeArticleSAP_p;
  }

  /**
   * @param dateComptage_p
   *          the dateComptage to set
   */
  public void setDateComptage(Date dateComptage_p)
  {
    if (dateComptage_p != null)
    {
      _dateComptage = (Date) dateComptage_p.clone();
    }
  }

  /**
   * @param encarteur_p
   *          the encarteur to set
   */
  public void setEncarteur(String encarteur_p)
  {
    _encarteur = encarteur_p;
  }

  /**
   * @param gencod_p
   *          the gencod to set
   */
  public void setGencod(Long gencod_p)
  {
    _gencod = gencod_p;
  }

  /**
   * @param profilElectrique_p
   *          the profilElectrique to set
   */
  public void setProfilElectrique(String profilElectrique_p)
  {
    _profilElectrique = profilElectrique_p;
  }

  /**
   * @param profileType_p
   *          the profileType to set
   */
  public void setProfileType(String profileType_p)
  {
    _profileType = profileType_p;
  }

  /**
   * @param quantite_p
   *          the quantite to set
   */
  public void setQuantite(int quantite_p)
  {
    _quantite = quantite_p;
  }

  /**
   * @param typeComptage_p
   *          the typeComptage to set
   */
  public void setTypeComptage(String typeComptage_p)
  {
    _typeComptage = typeComptage_p;
  }

  @Override
  public String toString()
  {
    return "StatistiqueEsim [_dateComptage=" + _dateComptage + ", _typeComptage=" + _typeComptage + ", _gencod=" + _gencod + ", _profilElectrique=" + _profilElectrique + ", _codeArticleSAP=" + _codeArticleSAP + ", _profileType=" + _profileType + ", _encarteur=" + _encarteur + ", _quantite=" + _quantite + ", _alert=" + _alert + "]"; //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$ //$NON-NLS-10$
  }
}
