/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.gdr.structs;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

/**
 *
 * @author jramos
 * @version ($Revision$ $Date$)
 */
public class CMDSIM
{

  /**
   *
   */
  Long _idtCMD;
  /**
   *
   */
  String _idtFAB;
  /**
   *
   */
  Long _gnc;
  /**
   *
   */
  Long _idtPRFELE;
  /**
   *
   */
  Long _idtPRFGRA;
  /**
   *
   */
  Long _idtCLA;
  /**
   *
   */
  String _idtART;
  /**
   *
   */
  Long _simPOH;
  /**
   *
   */
  String _debIMS;
  /**
   *
   */
  String _debSIM;
  /**
   *
   */
  Long _qteCMD;
  /**
   *
   */
  String _etaCMD;
  /**
   *
   */
  String _cleTRP;
  /**
   *
   */
  String _cmtCMD;
  /**
   *
   */
  String _uat;
  /**
   *
   */
  String _numCMDSAP;
  /**
   *
   */
  Long _typSIM;
  /**
   *
   */
  String _idTUSASIM;
  /**
   *
   */
  Date _datLIVPRV;
  /**
   *
   */
  Date _datLIV;
  /**
   *
   */
  Date _datKIT;
  /**
   *
   */
  String _etaLOG;
  /**
   *
   */
  String _etaPRO;
  /**
   *
   */
  String _envoiNOTIFSAP;

  /**
   *
   */
  public CMDSIM()
  {
    // TODO Auto-generated constructor stub
  }

  /**
   * @param idtCMD_p
   * @param idtFAB_p
   * @param gnc_p
   * @param idtPRFELE_p
   * @param idtPRFGRA_p
   * @param idtCLA_p
   * @param idtART_p
   * @param simPOH_p
   * @param debIMS_p
   * @param debSIM_p
   * @param qteCMD_p
   * @param etaCMD_p
   * @param cleTRP_p
   * @param cmtCMD_p
   * @param uat_p
   * @param numCMDSAP_p
   * @param typSIM_p
   * @param idTUSASIM_p
   * @param datLIVPRV_p
   * @param datLIV_p
   * @param datKIT_p
   * @param etaLOG_p
   * @param etaPRO_p
   * @param envoiNOTIFSAP_p
   */
  @SuppressWarnings("javadoc")
  public CMDSIM(Long idtCMD_p, String idtFAB_p, Long gnc_p, Long idtPRFELE_p, Long idtPRFGRA_p, Long idtCLA_p, String idtART_p, Long simPOH_p, String debIMS_p, String debSIM_p, Long qteCMD_p, String etaCMD_p, String cleTRP_p, String cmtCMD_p, String uat_p, String numCMDSAP_p, Long typSIM_p, String idTUSASIM_p, Date datLIVPRV_p, Date datLIV_p, Date datKIT_p, String etaLOG_p, String etaPRO_p, String envoiNOTIFSAP_p)
  {
    super();
    _idtCMD = idtCMD_p;
    _idtFAB = idtFAB_p;
    _gnc = gnc_p;
    _idtPRFELE = idtPRFELE_p;
    _idtPRFGRA = idtPRFGRA_p;
    _idtCLA = idtCLA_p;
    _idtART = idtART_p;
    _simPOH = simPOH_p;
    _debIMS = debIMS_p;
    _debSIM = debSIM_p;
    _qteCMD = qteCMD_p;
    _etaCMD = etaCMD_p;
    _cleTRP = cleTRP_p;
    _cmtCMD = cmtCMD_p;
    _uat = uat_p;
    _numCMDSAP = numCMDSAP_p;
    _typSIM = typSIM_p;
    _idTUSASIM = idTUSASIM_p;
    _datLIVPRV = datLIVPRV_p;
    _datLIV = datLIV_p;
    _datKIT = datKIT_p;
    _etaLOG = etaLOG_p;
    _etaPRO = etaPRO_p;
    _envoiNOTIFSAP = envoiNOTIFSAP_p;
  }

  /**
   * @param rs_p
   *          ResultSet
   * @throws SQLException
   *           SQLException
   */
  public CMDSIM(ResultSet rs_p) throws SQLException
  {
    super();
    _idtCMD = rs_p.getLong("IDTCMD"); //$NON-NLS-1$
    _idtFAB = rs_p.getString("IDTFAB"); //$NON-NLS-1$
    _gnc = rs_p.getLong("GNC"); //$NON-NLS-1$
    _idtPRFELE = rs_p.getLong("IDTPRFELE"); //$NON-NLS-1$
    _idtPRFGRA = rs_p.getLong("IDTPRFGRA"); //$NON-NLS-1$
    _idtCLA = rs_p.getLong("IDTCLA"); //$NON-NLS-1$
    _idtART = rs_p.getString("IDTART"); //$NON-NLS-1$
    _simPOH = rs_p.getLong("SIMPOH"); //$NON-NLS-1$
    _debIMS = rs_p.getString("DEBIMS"); //$NON-NLS-1$
    _debSIM = rs_p.getString("DEBSIM"); //$NON-NLS-1$
    _qteCMD = rs_p.getLong("QTECMD"); //$NON-NLS-1$
    _etaCMD = rs_p.getString("ETACMD"); //$NON-NLS-1$
    _cleTRP = rs_p.getString("CLETRP"); //$NON-NLS-1$
    _cmtCMD = rs_p.getString("CMTCMD"); //$NON-NLS-1$
    _uat = rs_p.getString("UAT"); //$NON-NLS-1$
    _numCMDSAP = rs_p.getString("NUMCMDSAP"); //$NON-NLS-1$
    _typSIM = rs_p.getLong("TYPSIM"); //$NON-NLS-1$
    _idTUSASIM = rs_p.getString("IDTUSASIM"); //$NON-NLS-1$
    _datLIVPRV = rs_p.getDate("DATLIVPRV"); //$NON-NLS-1$
    _datLIV = rs_p.getDate("DATLIV"); //$NON-NLS-1$
    _datKIT = rs_p.getDate("DATKIT"); //$NON-NLS-1$
    _etaLOG = rs_p.getString("ETALOG"); //$NON-NLS-1$
    _etaPRO = rs_p.getString("ETAPRO"); //$NON-NLS-1$
    _envoiNOTIFSAP = rs_p.getString("ENVOINOTIFSAP"); //$NON-NLS-1$
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    CMDSIM other = (CMDSIM) obj;
    if (_cleTRP == null)
    {
      if (other._cleTRP != null)
      {
        return false;
      }
    }
    else if (!_cleTRP.equals(other._cleTRP))
    {
      return false;
    }
    if (_cmtCMD == null)
    {
      if (other._cmtCMD != null)
      {
        return false;
      }
    }
    else if (!_cmtCMD.equals(other._cmtCMD))
    {
      return false;
    }
    if (_datKIT == null)
    {
      if (other._datKIT != null)
      {
        return false;
      }
    }
    else if (!_datKIT.equals(other._datKIT))
    {
      return false;
    }
    if (_datLIV == null)
    {
      if (other._datLIV != null)
      {
        return false;
      }
    }
    else if (!_datLIV.equals(other._datLIV))
    {
      return false;
    }
    if (_datLIVPRV == null)
    {
      if (other._datLIVPRV != null)
      {
        return false;
      }
    }
    else if (!_datLIVPRV.equals(other._datLIVPRV))
    {
      return false;
    }
    if (_debIMS == null)
    {
      if (other._debIMS != null)
      {
        return false;
      }
    }
    else if (!_debIMS.equals(other._debIMS))
    {
      return false;
    }
    if (_debSIM == null)
    {
      if (other._debSIM != null)
      {
        return false;
      }
    }
    else if (!_debSIM.equals(other._debSIM))
    {
      return false;
    }
    if (_envoiNOTIFSAP == null)
    {
      if (other._envoiNOTIFSAP != null)
      {
        return false;
      }
    }
    else if (!_envoiNOTIFSAP.equals(other._envoiNOTIFSAP))
    {
      return false;
    }
    if (_etaCMD == null)
    {
      if (other._etaCMD != null)
      {
        return false;
      }
    }
    else if (!_etaCMD.equals(other._etaCMD))
    {
      return false;
    }
    if (_etaLOG == null)
    {
      if (other._etaLOG != null)
      {
        return false;
      }
    }
    else if (!_etaLOG.equals(other._etaLOG))
    {
      return false;
    }
    if (_etaPRO == null)
    {
      if (other._etaPRO != null)
      {
        return false;
      }
    }
    else if (!_etaPRO.equals(other._etaPRO))
    {
      return false;
    }
    if (_gnc == null)
    {
      if (other._gnc != null)
      {
        return false;
      }
    }
    else if (!_gnc.equals(other._gnc))
    {
      return false;
    }
    if (_idTUSASIM == null)
    {
      if (other._idTUSASIM != null)
      {
        return false;
      }
    }
    else if (!_idTUSASIM.equals(other._idTUSASIM))
    {
      return false;
    }
    if (_idtART == null)
    {
      if (other._idtART != null)
      {
        return false;
      }
    }
    else if (!_idtART.equals(other._idtART))
    {
      return false;
    }
    if (_idtCLA == null)
    {
      if (other._idtCLA != null)
      {
        return false;
      }
    }
    else if (!_idtCLA.equals(other._idtCLA))
    {
      return false;
    }
    if (_idtCMD == null)
    {
      if (other._idtCMD != null)
      {
        return false;
      }
    }
    else if (!_idtCMD.equals(other._idtCMD))
    {
      return false;
    }
    if (_idtFAB == null)
    {
      if (other._idtFAB != null)
      {
        return false;
      }
    }
    else if (!_idtFAB.equals(other._idtFAB))
    {
      return false;
    }
    if (_idtPRFELE == null)
    {
      if (other._idtPRFELE != null)
      {
        return false;
      }
    }
    else if (!_idtPRFELE.equals(other._idtPRFELE))
    {
      return false;
    }
    if (_idtPRFGRA == null)
    {
      if (other._idtPRFGRA != null)
      {
        return false;
      }
    }
    else if (!_idtPRFGRA.equals(other._idtPRFGRA))
    {
      return false;
    }
    if (_numCMDSAP == null)
    {
      if (other._numCMDSAP != null)
      {
        return false;
      }
    }
    else if (!_numCMDSAP.equals(other._numCMDSAP))
    {
      return false;
    }
    if (_qteCMD == null)
    {
      if (other._qteCMD != null)
      {
        return false;
      }
    }
    else if (!_qteCMD.equals(other._qteCMD))
    {
      return false;
    }
    if (_simPOH == null)
    {
      if (other._simPOH != null)
      {
        return false;
      }
    }
    else if (!_simPOH.equals(other._simPOH))
    {
      return false;
    }
    if (_typSIM == null)
    {
      if (other._typSIM != null)
      {
        return false;
      }
    }
    else if (!_typSIM.equals(other._typSIM))
    {
      return false;
    }
    if (_uat == null)
    {
      if (other._uat != null)
      {
        return false;
      }
    }
    else if (!_uat.equals(other._uat))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the cleTRP
   */
  public String getCleTRP()
  {
    return _cleTRP;
  }

  /**
   * @return the cmtCMD
   */
  public String getCmtCMD()
  {
    return _cmtCMD;
  }

  /**
   * @return the datKIT
   */
  public Date getDatKIT()
  {
    return _datKIT;
  }

  /**
   * @return the datLIV
   */
  public Date getDatLIV()
  {
    return _datLIV;
  }

  /**
   * @return the datLIVPRV
   */
  public Date getDatLIVPRV()
  {
    return _datLIVPRV;
  }

  /**
   * @return the debIMS
   */
  public String getDebIMS()
  {
    return _debIMS;
  }

  /**
   * @return the debSIM
   */
  public String getDebSIM()
  {
    return _debSIM;
  }

  /**
   * @return the envoiNOTIFSAP
   */
  public String getEnvoiNOTIFSAP()
  {
    return _envoiNOTIFSAP;
  }

  /**
   * @return the etaCMD
   */
  public String getEtaCMD()
  {
    return _etaCMD;
  }

  /**
   * @return the etaLOG
   */
  public String getEtaLOG()
  {
    return _etaLOG;
  }

  /**
   * @return the etaPRO
   */
  public String getEtaPRO()
  {
    return _etaPRO;
  }

  /**
   * @return the gnc
   */
  public Long getGnc()
  {
    return _gnc;
  }

  /**
   * @return the idtART
   */
  public String getIdtART()
  {
    return _idtART;
  }

  /**
   * @return the idtCLA
   */
  public Long getIdtCLA()
  {
    return _idtCLA;
  }

  /**
   * @return the idtCMD
   */
  public Long getIdtCMD()
  {
    return _idtCMD;
  }

  /**
   * @return the idtFAB
   */
  public String getIdtFAB()
  {
    return _idtFAB;
  }

  /**
   * @return the idtPRFELE
   */
  public Long getIdtPRFELE()
  {
    return _idtPRFELE;
  }

  /**
   * @return the idtPRFGRA
   */
  public Long getIdtPRFGRA()
  {
    return _idtPRFGRA;
  }

  /**
   * @return the idTUSASIM
   */
  public String getIdTUSASIM()
  {
    return _idTUSASIM;
  }

  /**
   * @return the numCMDSAP
   */
  public String getNumCMDSAP()
  {
    return _numCMDSAP;
  }

  /**
   * @return the qteCMD
   */
  public Long getQteCMD()
  {
    return _qteCMD;
  }

  /**
   * @return the simPOH
   */
  public Long getSimPOH()
  {
    return _simPOH;
  }

  /**
   * @return the typSIM
   */
  public Long getTypSIM()
  {
    return _typSIM;
  }

  /**
   * @return the uat
   */
  public String getUat()
  {
    return _uat;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_cleTRP == null) ? 0 : _cleTRP.hashCode());
    result = (prime * result) + ((_cmtCMD == null) ? 0 : _cmtCMD.hashCode());
    result = (prime * result) + ((_datKIT == null) ? 0 : _datKIT.hashCode());
    result = (prime * result) + ((_datLIV == null) ? 0 : _datLIV.hashCode());
    result = (prime * result) + ((_datLIVPRV == null) ? 0 : _datLIVPRV.hashCode());
    result = (prime * result) + ((_debIMS == null) ? 0 : _debIMS.hashCode());
    result = (prime * result) + ((_debSIM == null) ? 0 : _debSIM.hashCode());
    result = (prime * result) + ((_envoiNOTIFSAP == null) ? 0 : _envoiNOTIFSAP.hashCode());
    result = (prime * result) + ((_etaCMD == null) ? 0 : _etaCMD.hashCode());
    result = (prime * result) + ((_etaLOG == null) ? 0 : _etaLOG.hashCode());
    result = (prime * result) + ((_etaPRO == null) ? 0 : _etaPRO.hashCode());
    result = (prime * result) + ((_gnc == null) ? 0 : _gnc.hashCode());
    result = (prime * result) + ((_idTUSASIM == null) ? 0 : _idTUSASIM.hashCode());
    result = (prime * result) + ((_idtART == null) ? 0 : _idtART.hashCode());
    result = (prime * result) + ((_idtCLA == null) ? 0 : _idtCLA.hashCode());
    result = (prime * result) + ((_idtCMD == null) ? 0 : _idtCMD.hashCode());
    result = (prime * result) + ((_idtFAB == null) ? 0 : _idtFAB.hashCode());
    result = (prime * result) + ((_idtPRFELE == null) ? 0 : _idtPRFELE.hashCode());
    result = (prime * result) + ((_idtPRFGRA == null) ? 0 : _idtPRFGRA.hashCode());
    result = (prime * result) + ((_numCMDSAP == null) ? 0 : _numCMDSAP.hashCode());
    result = (prime * result) + ((_qteCMD == null) ? 0 : _qteCMD.hashCode());
    result = (prime * result) + ((_simPOH == null) ? 0 : _simPOH.hashCode());
    result = (prime * result) + ((_typSIM == null) ? 0 : _typSIM.hashCode());
    result = (prime * result) + ((_uat == null) ? 0 : _uat.hashCode());
    return result;
  }

  /**
   * @param cleTRP_p
   *          the cleTRP to set
   */
  public void setCleTRP(String cleTRP_p)
  {
    _cleTRP = cleTRP_p;
  }

  /**
   * @param cmtCMD_p
   *          the cmtCMD to set
   */
  public void setCmtCMD(String cmtCMD_p)
  {
    _cmtCMD = cmtCMD_p;
  }

  /**
   * @param datKIT_p
   *          the datKIT to set
   */
  public void setDatKIT(Date datKIT_p)
  {
    _datKIT = datKIT_p;
  }

  /**
   * @param datLIV_p
   *          the datLIV to set
   */
  public void setDatLIV(Date datLIV_p)
  {
    _datLIV = datLIV_p;
  }

  /**
   * @param datLIVPRV_p
   *          the datLIVPRV to set
   */
  public void setDatLIVPRV(Date datLIVPRV_p)
  {
    _datLIVPRV = datLIVPRV_p;
  }

  /**
   * @param debIMS_p
   *          the debIMS to set
   */
  public void setDebIMS(String debIMS_p)
  {
    _debIMS = debIMS_p;
  }

  /**
   * @param debSIM_p
   *          the debSIM to set
   */
  public void setDebSIM(String debSIM_p)
  {
    _debSIM = debSIM_p;
  }

  /**
   * @param envoiNOTIFSAP_p
   *          the envoiNOTIFSAP to set
   */
  public void setEnvoiNOTIFSAP(String envoiNOTIFSAP_p)
  {
    _envoiNOTIFSAP = envoiNOTIFSAP_p;
  }

  /**
   * @param etaCMD_p
   *          the etaCMD to set
   */
  public void setEtaCMD(String etaCMD_p)
  {
    _etaCMD = etaCMD_p;
  }

  /**
   * @param etaLOG_p
   *          the etaLOG to set
   */
  public void setEtaLOG(String etaLOG_p)
  {
    _etaLOG = etaLOG_p;
  }

  /**
   * @param etaPRO_p
   *          the etaPRO to set
   */
  public void setEtaPRO(String etaPRO_p)
  {
    _etaPRO = etaPRO_p;
  }

  /**
   * @param gnc_p
   *          the gnc to set
   */
  public void setGnc(Long gnc_p)
  {
    _gnc = gnc_p;
  }

  /**
   * @param idtART_p
   *          the idtART to set
   */
  public void setIdtART(String idtART_p)
  {
    _idtART = idtART_p;
  }

  /**
   * @param idtCLA_p
   *          the idtCLA to set
   */
  public void setIdtCLA(Long idtCLA_p)
  {
    _idtCLA = idtCLA_p;
  }

  /**
   * @param idtCMD_p
   *          the idtCMD to set
   */
  public void setIdtCMD(Long idtCMD_p)
  {
    _idtCMD = idtCMD_p;
  }

  /**
   * @param idtFAB_p
   *          the idtFAB to set
   */
  public void setIdtFAB(String idtFAB_p)
  {
    _idtFAB = idtFAB_p;
  }

  /**
   * @param idtPRFELE_p
   *          the idtPRFELE to set
   */
  public void setIdtPRFELE(Long idtPRFELE_p)
  {
    _idtPRFELE = idtPRFELE_p;
  }

  /**
   * @param idtPRFGRA_p
   *          the idtPRFGRA to set
   */
  public void setIdtPRFGRA(Long idtPRFGRA_p)
  {
    _idtPRFGRA = idtPRFGRA_p;
  }

  /**
   * @param idTUSASIM_p
   *          the idTUSASIM to set
   */
  public void setIdTUSASIM(String idTUSASIM_p)
  {
    _idTUSASIM = idTUSASIM_p;
  }

  /**
   * @param numCMDSAP_p
   *          the numCMDSAP to set
   */
  public void setNumCMDSAP(String numCMDSAP_p)
  {
    _numCMDSAP = numCMDSAP_p;
  }

  /**
   * @param qteCMD_p
   *          the qteCMD to set
   */
  public void setQteCMD(Long qteCMD_p)
  {
    _qteCMD = qteCMD_p;
  }

  /**
   * @param simPOH_p
   *          the simPOH to set
   */
  public void setSimPOH(Long simPOH_p)
  {
    _simPOH = simPOH_p;
  }

  /**
   * @param typSIM_p
   *          the typSIM to set
   */
  public void setTypSIM(Long typSIM_p)
  {
    _typSIM = typSIM_p;
  }

  /**
   * @param uat_p
   *          the uat to set
   */
  public void setUat(String uat_p)
  {
    _uat = uat_p;
  }

}
