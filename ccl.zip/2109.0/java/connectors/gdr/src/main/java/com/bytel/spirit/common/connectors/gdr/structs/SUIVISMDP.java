/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.gdr.structs;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

/**
 *
 * @author jramos
 * @version ($Revision$ $Date$)
 */
public class SUIVISMDP
{

  /**
   * idtcmd
   */
  Long _idtcmd;

  /**
   * datederniermaj
   */
  Date _datederniermaj;
  /**
   * datedernierechec
   */
  Date _datedernierechec;
  /**
   * quantite
   */
  Long _quantite;
  /**
   * datetraitement
   */
  Date _datetraitement;

  /**
   *
   */
  public SUIVISMDP()
  {
    // TODO Auto-generated constructor stub
  }

  /**
   * @param idtcmd_p
   *          idtcmd
   * @param datederniermaj_p
   *          datederniermaj
   * @param datedernierechec_p
   *          datedernierechec
   * @param quantite_p
   *          quantite
   * @param datetraitement_p
   *          datetraitement
   */
  public SUIVISMDP(Long idtcmd_p, Date datederniermaj_p, Date datedernierechec_p, Long quantite_p, Date datetraitement_p)
  {
    super();
    _idtcmd = idtcmd_p;
    _datederniermaj = datederniermaj_p;
    _datedernierechec = datedernierechec_p;
    _quantite = quantite_p;
    _datetraitement = datetraitement_p;
  }

  /**
   * @param rs_p
   *          Resultset
   * @throws SQLException
   *           Exception
   */
  public SUIVISMDP(ResultSet rs_p) throws SQLException
  {
    _idtcmd = rs_p.getLong("IDTCMD"); //$NON-NLS-1$

    _datederniermaj = rs_p.getDate("DATEDERNIERMAJ"); //$NON-NLS-1$

    _datederniermaj = rs_p.getDate("DATEDERNIERECHEC"); //$NON-NLS-1$

    _quantite = rs_p.getLong("QUANTITE"); //$NON-NLS-1$

    _datederniermaj = rs_p.getDate("DATETRAITEMENT"); //$NON-NLS-1$

  }

  /**
   * @return the datedernierechec
   */
  public Date getDatedernierechec()
  {
    return _datedernierechec;
  }

  /**
   * @return the datederniermaj
   */
  public Date getDatederniermaj()
  {
    return _datederniermaj;
  }

  /**
   * @return the datetraitement
   */
  public Date getDatetraitement()
  {
    return _datetraitement;
  }

  /**
   * @return the idtcmd
   */
  public Long getIdtcmd()
  {
    return _idtcmd;
  }

  /**
   * @return the quantite
   */
  public Long getQuantite()
  {
    return _quantite;
  }

  /**
   * @param datedernierechec_p
   *          the datedernierechec to set
   */
  public void setDatedernierechec(Date datedernierechec_p)
  {
    _datedernierechec = datedernierechec_p;
  }

  /**
   * @param datederniermaj_p
   *          the datederniermaj to set
   */
  public void setDatederniermaj(Date datederniermaj_p)
  {
    _datederniermaj = datederniermaj_p;
  }

  /**
   * @param datetraitement_p
   *          the datetraitement to set
   */
  public void setDatetraitement(Date datetraitement_p)
  {
    _datetraitement = datetraitement_p;
  }

  /**
   * @param idtcmd_p
   *          the idtcmd to set
   */
  public void setIdtcmd(Long idtcmd_p)
  {
    _idtcmd = idtcmd_p;
  }

  /**
   * @param quantite_p
   *          the quantite to set
   */
  public void setQuantite(Long quantite_p)
  {
    _quantite = quantite_p;
  }

}
