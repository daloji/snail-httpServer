/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.gdr.structs.enumeration;

import com.bytel.ravel.common.utils.StringTools;

/**
 *
 * @author lmerces
 * @version ($Revision$ $Date$)
 */
public enum EtaCom
{
  /**
   * Suspension de la ressource <b>« S »</b>
   */
  SUSPENSION("S"), //$NON-NLS-1$

  /**
   * Resiliation de la ressource <b>« R »</b>
   */
  RESILIATION("R"); //$NON-NLS-1$

  /**
   * @param value_p
   *          value
   * @return {@link EtaCom}
   */
  public static EtaCom fromString(String value_p)
  {
    if (!StringTools.isNullOrEmpty(value_p))
    {
      for (EtaCom etaCom : EtaCom.values())
      {
        if (etaCom._value.equalsIgnoreCase(value_p))
        {
          return etaCom;
        }
      }
    }

    return null;
  }

  /**
   * value
   */
  private final String _value;

  /**
   * Constructor
   *
   * @param value_p
   *          value
   */
  EtaCom(String value_p)
  {
    _value = value_p;
  }

  /**
   * @return the value
   */
  public String getValue()
  {
    return _value;
  }
}
