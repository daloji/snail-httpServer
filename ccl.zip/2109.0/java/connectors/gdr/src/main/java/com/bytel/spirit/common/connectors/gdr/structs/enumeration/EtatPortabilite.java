/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.gdr.structs.enumeration;

import com.bytel.ravel.common.utils.StringTools;

/**
 *
 * @author lmerces
 * @version ($Revision$ $Date$)
 */
public enum EtatPortabilite
{
  /**
   * Portabilite externe <b>« E »</b>
   */
  PORTABILITE_EXTERNE("E"), //$NON-NLS-1$

  /**
   * Portabilite interne <b>« I »</b>
   */
  PORTABILITE_INTERNE("I"), //$NON-NLS-1$
  
  /**
   * Portabilite en attente <b>« N »</b>
   */
  PORTABILITE_EN_ATTENTE("N"), //$NON-NLS-1$
  
  /**
   * Portabilite transitoire (externe et interne) <b>« T »</b>
   */
  PORTABILITE_TRANSITOIRE("T"); //$NON-NLS-1$

  /**
   * @param value_p
   *          value
   * @return {@link EtatPortabilite}
   */
  public static EtatPortabilite fromString(String value_p)
  {
    if (!StringTools.isNullOrEmpty(value_p))
    {
      for (EtatPortabilite etaPrt : EtatPortabilite.values())
      {
        if (etaPrt._value.equalsIgnoreCase(value_p))
        {
          return etaPrt;
        }
      }
    }

    return null;
  }

  /**
   * value
   */
  private final String _value;

  /**
   * Constructor
   *
   * @param value_p
   *          value
   */
  EtatPortabilite(String value_p)
  {
    _value = value_p;
  }

  /**
   * @return the value
   */
  public String getValue()
  {
    return _value;
  }
}
