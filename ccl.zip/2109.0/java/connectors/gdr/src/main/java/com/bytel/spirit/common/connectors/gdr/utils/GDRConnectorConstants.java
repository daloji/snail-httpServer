/*******************************************************************************
* $Id: GDRConnectorConstants.java 14439 2018-12-11 11:32:44Z lmerces $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.gdr.utils;

import com.bytel.ravel.services.connector.AbstractDBConnector;

/**
 *
 * @author lmerces
 * @version ($Revision: 14439 $ $Date: 2018-12-11 12:32:44 +0100 (mar. 11 déc. 2018) $)
 */
public final class GDRConnectorConstants
{
  /**
  *
  */
  public static final String PO_RESULT = "po_RESULT"; //$NON-NLS-1$

  /**
   * Connection failed
   */
  public static final String CONNEXION_FAILED = "CONNEXION_FAILED"; //$NON-NLS-1$

  /**
   * Epic failure during insertion
   */
  public static final String INSERTION_FAILED = "INSERTION_FAILED"; //$NON-NLS-1$

  /**
   * Failure during select
   */
  public static final String SELECT_FAILED = "SELECT_FAILED"; //$NON-NLS-1$

  /**
   * Session is unavailable
   */
  public static final String SESSION_UNAVAILABLE = "SESSION_UNAVAILABLE"; //$NON-NLS-1$

  /**
   * RETOUR_RESULTAT
   */
  public static final String RETOUR_RESULTAT = AbstractDBConnector.RETOUR_RESULTAT;

  /**
   * RETOUR_CATEGORIE
   */
  public static final String RETOUR_CATEGORIE = AbstractDBConnector.RETOUR_CATEGORIE;

  /**
   * RETOUR_DIAGNOSTIC
   */
  public static final String RETOUR_DIAGNOSTIC = AbstractDBConnector.RETOUR_DIAGNOSTIC;

  /**
   * RETOUR_LIBELLE
   */
  public static final String RETOUR_LIBELLE = AbstractDBConnector.RETOUR_LIBELLE;

  /**
   * Failure of internal portability
   */
  public static final int FAILURE_INTERNAL_PORTABILITY = 30;

  /**
   * State, SIM distributed
   */
  public static final String SIM_STATE_DISTRIBUTED = "r"; //$NON-NLS-1$

  /**
   * State, SIM with error
   */
  public static final String SIM_STATE_ERROR = "e"; //$NON-NLS-1$

  /**
   * State, SIM will be ported
   */
  public static final String SIM_STATE_ONGOING_PORTABILITY = "y"; //$NON-NLS-1$

  /**
   * Constant with the value of the Table Column for TYPMSI
   */
  public static final String TYPMSISDN = "TYPMSISDN"; //$NON-NLS-1$

  /**
   *
   */
  private GDRConnectorConstants()
  {
  }
}
