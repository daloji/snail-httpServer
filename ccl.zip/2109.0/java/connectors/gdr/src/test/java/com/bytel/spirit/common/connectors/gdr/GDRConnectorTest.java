/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.gdr;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLRecoverableException;
import java.sql.SQLTimeoutException;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import org.apache.tomcat.jdbc.pool.DataSource;
import org.apache.tomcat.jdbc.pool.PoolExhaustedException;
import org.easymock.Capture;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockNice;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.conf.generated.Param;
import com.bytel.ravel.common.encryption.DESKeyManager;
import com.bytel.ravel.common.encryption.PasswordDecrypter;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.test.JUnitTools;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.services.conf.connector.generated.Connector;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.connectors.gdr.structs.CarteProfileData;
import com.bytel.spirit.common.connectors.gdr.structs.DURMSI;
import com.bytel.spirit.common.connectors.gdr.structs.MSISDN;
import com.bytel.spirit.common.connectors.gdr.structs.Sim;
import com.bytel.spirit.common.connectors.gdr.structs.enumeration.EtatSim;
import com.bytel.spirit.common.connectors.gdr.utils.ArrayDescriptorFactory;
import com.bytel.spirit.common.connectors.gdr.utils.GDRPGIWSRessources;
import com.bytel.spirit.common.connectors.gdr.utils.GDRPGRechercheInfo;
import com.bytel.spirit.common.connectors.gdr.utils.GDRPGReportingGDS;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

/**
 *
 * @author $Author$
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({ DESKeyManager.class, PasswordDecrypter.class, Connection.class, DataSource.class, GDRPGIWSRessources.class, ArrayDescriptorFactory.class })
@PowerMockIgnore("javax.management.*") //$NON-NLS-1$
public class GDRConnectorTest
{
  private GDRConnector _connector;

  private GDRPGIWSRessources _pgIWSRessources;

  private GDRPGRechercheInfo _pgRechercheInfo;

  private GDRPGReportingGDS _pgReportingGDS;

  @MockNice
  DataSource _datasource;

  @MockNice
  Connection _connection;

  @MockNice
  CallableStatement _callableStatement;

  @MockNice
  ResultSet _resultSet;

  @MockNice
  ArrayDescriptorFactory _arrayDescriptionFactory;

  /**
   * Test to countMsisdnBytelActifs Fail with SQLException
   * 
   * @throws Exception
   *           on error.
   */
  @Test(expected = RavelException.class)
  public void countMsisdnBytelActifsFail_001() throws Exception
  {
    // Exception
    SQLException sqlException = new SQLException();
    // Request
    Tracabilite tracabilite = new Tracabilite();
    // Setup mocks
    EasyMock.expect(_callableStatement.execute()).andThrow(sqlException);
    PowerMock.replay(_callableStatement);
    EasyMock.expect(_connection.prepareCall("{call PG_REPORTING_GDS.PR_EXT_MSISDN_BYTEL_ACTIFS(?)}")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);
    ConnectorResponse<Integer, Retour> connectorResponse = _pgReportingGDS.countMsisdnBytelActifs(tracabilite);
    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
  }

  /**
   * Test to countMsisdnBytelActifs Fail with SQLTimeoutException
   * 
   * @throws Exception
   *           on error.
   */
  @Test
  public void countMsisdnBytelActifsFail_002() throws Exception
  {
    // Exception
    SQLTimeoutException sqlTimeoutException = new SQLTimeoutException();
    // Request
    Tracabilite tracabilite = new Tracabilite();
    // Setup mocks
    EasyMock.expect(_callableStatement.execute()).andThrow(sqlTimeoutException);
    PowerMock.replay(_callableStatement);
    EasyMock.expect(_connection.prepareCall("{call PG_REPORTING_GDS.PR_EXT_MSISDN_BYTEL_ACTIFS(?)}")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);
    ConnectorResponse<Integer, Retour> connectorResponse = _connector.countMsisdnBytelActifs(tracabilite);
    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
  }

  /**
   * Test to countMsisdnBytelActifs Fail with PoolExhaustedException
   * 
   * @throws Exception
   *           on error.
   */
  @Test
  public void countMsisdnBytelActifsFail_003() throws Exception
  {
    // Exception
    PoolExhaustedException poolExhaustedException = new PoolExhaustedException();
    // Request
    Tracabilite tracabilite = new Tracabilite();
    // Setup mocks
    EasyMock.expect(_callableStatement.execute()).andThrow(poolExhaustedException);
    PowerMock.replay(_callableStatement);
    EasyMock.expect(_connection.prepareCall("{call PG_REPORTING_GDS.PR_EXT_MSISDN_BYTEL_ACTIFS(?)}")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);
    ConnectorResponse<Integer, Retour> connectorResponse = _connector.countMsisdnBytelActifs(tracabilite);
    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
  }

  /**
   * Test to countMsisdnBytelActifs Fail with SQLRecoverableException
   * 
   * @throws Exception
   *           on error.
   */
  @Test
  public void countMsisdnBytelActifsFail_004() throws Exception
  {
    // Exception
    SQLRecoverableException sqlRecoverableException = new SQLRecoverableException();
    // Request
    Tracabilite tracabilite = new Tracabilite();
    // Setup mocks
    EasyMock.expect(_callableStatement.execute()).andThrow(sqlRecoverableException);
    PowerMock.replay(_callableStatement);
    EasyMock.expect(_connection.prepareCall("{call PG_REPORTING_GDS.PR_EXT_MSISDN_BYTEL_ACTIFS(?)}")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);
    ConnectorResponse<Integer, Retour> connectorResponse = _connector.countMsisdnBytelActifs(tracabilite);
    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
  }

  /**
   * Test to countMsisdnBytelActifs success
   * 
   * @throws Exception
   *           on error.
   */
  @Test
  public void countMsisdnBytelActifsSuccess() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    // Setup mocks

    EasyMock.expect(_callableStatement.getInt(1)).andReturn(500);
    PowerMock.replay(_callableStatement);
    EasyMock.expect(_connection.prepareCall("{call PG_REPORTING_GDS.PR_EXT_MSISDN_BYTEL_ACTIFS(?)}")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    ConnectorResponse<Integer, Retour> connectorResponse = _pgReportingGDS.countMsisdnBytelActifs(tracabilite);
    assertEquals(new Integer(500), connectorResponse._first);
    assertEquals(StringConstants.OK, connectorResponse._second.getResultat());
  }

  /**
   * @throws Exception
   *           on error.
   */
  @Before
  public void setup() throws Exception
  {
    _connector = new GDRConnector();

    Connector _connectorConfig = new Connector();
    _connectorConfig.setName("GDRConnector"); //$NON-NLS-1$
    _connectorConfig.setType("client"); //$NON-NLS-1$
    _connectorConfig.setClazz("com.bytel.ressources.services.connector.gdr.GDRConnector"); //$NON-NLS-1$
    _connectorConfig.setEnabled(true);
    Param dbConnectionString = new Param();
    Param dbUsername = new Param();
    Param dbPassword = new Param();
    Param poolSize = new Param();
    Param connectTimeoutSec = new Param();
    Param readTimeoutSec = new Param();

    dbConnectionString.setName("DB_CONNECTIONSTRING"); //$NON-NLS-1$
    dbConnectionString.setValue("jdbc:oracle:thin:@172.22.76.129:1531:PPR0N1D2"); //$NON-NLS-1$
    dbUsername.setName("DB_USERNAME"); //$NON-NLS-1$
    dbUsername.setValue("DEV19GDR"); //$NON-NLS-1$
    dbPassword.setName("DB_PASSWORD"); //$NON-NLS-1$
    dbPassword.setValue("0l7HRwWTfUwgsoOMyJ3uHw=="); //$NON-NLS-1$
    poolSize.setName("POOLSIZE"); //$NON-NLS-1$
    poolSize.setValue("15"); //$NON-NLS-1$
    connectTimeoutSec.setName("CONNECT_TIMEOUT_SEC"); //$NON-NLS-1$
    connectTimeoutSec.setValue("4"); //$NON-NLS-1$
    readTimeoutSec.setName("READ_TIMEOUT_SEC"); //$NON-NLS-1$
    readTimeoutSec.setValue("1"); //$NON-NLS-1$

    _connectorConfig.getParam().add(dbConnectionString);
    _connectorConfig.getParam().add(dbUsername);
    _connectorConfig.getParam().add(dbPassword);
    _connectorConfig.getParam().add(poolSize);
    _connectorConfig.getParam().add(connectTimeoutSec);
    _connectorConfig.getParam().add(readTimeoutSec);

    PowerMock.resetAll();
    PowerMock.mockStaticNice(PasswordDecrypter.class);
    PowerMock.mockStaticNice(DESKeyManager.class);

    // Load config
    _connector.loadConnectorConfiguration(_connectorConfig);
    JUnitTools.setInaccessibleFieldValue(_connector, "_datasource", _datasource); //$NON-NLS-1$

    // Setup connection mock
    EasyMock.expect(_datasource.getConnection()).andReturn(_connection).anyTimes();
    PowerMock.replay(_datasource);

    _pgIWSRessources = new GDRPGIWSRessources(_datasource, 1, 4);
    _pgRechercheInfo = new GDRPGRechercheInfo(_datasource, 1, 4);
    _pgReportingGDS = new GDRPGReportingGDS(_datasource, 1, 4);
  }

  /**
   * Test to search for an existing batchId (idtCmd)
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void testBatchStateForExistingBatchId() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    long idBatch = 12669;

    // Setup mocks
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString("po_ETACMD")).andReturn("c"); //$NON-NLS-1$ //$NON-NLS-2$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_IWSRESSOURCES.P_CONSULT_ETAT_BATCH(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<String, Retour> connectorResponse = _pgIWSRessources.consultEtatBatch(tracabilite, idBatch);

    // Assert
    assertEquals("c", connectorResponse._first); //$NON-NLS-1$
    assertEquals("OK", connectorResponse._second.getResultat());//$NON-NLS-1$
    assertEquals(null, connectorResponse._second.getCategorie());
    assertEquals(null, connectorResponse._second.getLibelle());
    assertEquals(null, connectorResponse._second.getDiagnostic());
  }

  /**
   * Test to search for an non existing batchId (idtCmd)
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void testBatchStateForNonExistingBatchId() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    long idBatch = 112212669;

    // Setup mocks
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.KO); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString("Retour_Categorie")).andReturn("DEF-4"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_callableStatement.getString("Retour_Diagnostic")).andReturn(IMegConsts.ACCES_DONNEES_INDISPONIBLE); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString("Retour_Libelle")).andReturn("Le batch " + idBatch + " n'existe pas"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_IWSRESSOURCES.P_CONSULT_ETAT_BATCH(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<String, Retour> connectorResponse = _pgIWSRessources.consultEtatBatch(tracabilite, idBatch);

    // Asserts
    assertEquals(null, connectorResponse._first);
    assertEquals("KO", connectorResponse._second.getResultat());//$NON-NLS-1$
    assertEquals("DEF-4", connectorResponse._second.getCategorie());//$NON-NLS-1$
    assertEquals("Le batch 112212669 n'existe pas", connectorResponse._second.getLibelle());//$NON-NLS-1$
    assertEquals("ACCES_DONNEES_INDISPONIBLE", connectorResponse._second.getDiagnostic());//$NON-NLS-1$
  }

  /**
   * Test to check Sim state search for an existing batchId (idtCmd)
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void testCheckSimForExistingBatchId() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    long idBatch = 12669;

    // Setup mocks
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getLong("po_ExisteSimIncoherent")).andReturn(1L); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_IWSRESSOURCES.P_CHECK_ETATSIM_BATCH(?,?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<Long, Retour> connectorResponse = _pgIWSRessources.checkEtatSimBatch(tracabilite, idBatch, "1");//$NON-NLS-1$

    // Assert
    assertEquals(1, connectorResponse._first.longValue());
    assertEquals("OK", connectorResponse._second.getResultat());//$NON-NLS-1$
    assertEquals(null, connectorResponse._second.getCategorie());
    assertEquals(null, connectorResponse._second.getLibelle());
    assertEquals(null, connectorResponse._second.getDiagnostic());
  }

  /**
   * Test to check Sim state search for non existing batchId (idtCmd)
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void testCheckSimForNonExistingBatchId() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    long idBatch = 112212669;

    // Setup mocks
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getLong("po_ExisteSimIncoherent")).andReturn(0L); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_IWSRESSOURCES.P_CHECK_ETATSIM_BATCH(?,?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<Long, Retour> connectorResponse = _pgIWSRessources.checkEtatSimBatch(tracabilite, idBatch, "1");//$NON-NLS-1$

    // Assert
    assertEquals(0, connectorResponse._first.longValue());
    assertEquals("OK", connectorResponse._second.getResultat());//$NON-NLS-1$
    assertEquals(null, connectorResponse._second.getCategorie());
    assertEquals(null, connectorResponse._second.getLibelle());
    assertEquals(null, connectorResponse._second.getDiagnostic());
  }

  /**
   * Test consult Sim batch
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void testConsultSimBatch() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    long idBatch = 12669;

    // Setup mocks
    EasyMock.expect(_resultSet.next()).andReturn(true);
    EasyMock.expect(_resultSet.getInt(EasyMock.anyInt())).andReturn(1).anyTimes();
    EasyMock.expect(_resultSet.getString("sim")).andReturn("8933209805139069871"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString(EasyMock.anyString())).andReturn("1").anyTimes(); //$NON-NLS-1$
    PowerMock.replay(_resultSet);

    Capture<String> imsiCapture = Capture.newInstance();
    _callableStatement.setString(EasyMock.eq("IMSI"), EasyMock.capture(imsiCapture)); //$NON-NLS-1$
    EasyMock.expectLastCall();
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getObject("po_RESULT")).andReturn(_resultSet); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_IWSRESSOURCES.P_CONSULT_SIM_BATCH(?,?,?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<ConsultSimBatch, Retour> connectorResponse = _pgIWSRessources.consultSimBatch(tracabilite, idBatch, "a", "1");//$NON-NLS-1$ //$NON-NLS-2$

    // Asserts
    assertEquals(1, connectorResponse._first.getSimRecords().length);
    assertEquals("8933209805139069871", connectorResponse._first.getSimRecords()[0].getSim()); //$NON-NLS-1$
    assertEquals("OK", connectorResponse._second.getResultat());//$NON-NLS-1$
    assertEquals(null, connectorResponse._second.getCategorie());
    assertEquals(null, connectorResponse._second.getLibelle());
    assertEquals(null, connectorResponse._second.getDiagnostic());
  }

  /**
   * Test to search for an ICCID
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void testICCID() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();

    // Setup mocks
    EasyMock.expect(_resultSet.next()).andReturn(true);
    EasyMock.expect(_resultSet.getInt(EasyMock.anyInt())).andReturn(1).anyTimes();
    EasyMock.expect(_resultSet.getLong(1)).andReturn(208209813988492L);
    EasyMock.expect(_resultSet.getLong(2)).andReturn(8933209805139884923L);
    EasyMock.expect(_resultSet.getString(11)).andReturn("e"); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getString(12)).andReturn("ISO"); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getString(EasyMock.anyString())).andReturn("1").anyTimes(); //$NON-NLS-1$
    PowerMock.replay(_resultSet);

    Capture<String> imsiCapture = Capture.newInstance();
    _callableStatement.setString(EasyMock.eq("IMSI"), EasyMock.capture(imsiCapture)); //$NON-NLS-1$
    EasyMock.expectLastCall();
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getObject("cursorx")).andReturn(_resultSet); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_RECHERCHE_INFO.P_Recherche_Info_ICCID(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<InfoSIM, Retour> connectorResponse = _pgRechercheInfo.rechercheInformationsICCID(tracabilite, 8933209805139884923L);

    // Asserts
    assertEquals(8933209805139884923L, connectorResponse._first.getIccid().longValue());
    assertEquals(208209813988492L, connectorResponse._first.getImsi().longValue());
    assertEquals("OK", connectorResponse._second.getResultat());//$NON-NLS-1$
  }

  /**
   * Test to search for an IMSI
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void testIMSISearch() throws Exception
  {
    // Request
    long imsi = 208209813988992L;

    Tracabilite tracabilite = new Tracabilite();

    // Setup mocks
    EasyMock.expect(_resultSet.next()).andReturn(true);
    EasyMock.expect(_resultSet.getInt(EasyMock.anyInt())).andReturn(1).anyTimes();
    EasyMock.expect(_resultSet.getLong(1)).andReturn(208209813988992L);
    EasyMock.expect(_resultSet.getLong(2)).andReturn(8933209805139889922L);
    EasyMock.expect(_resultSet.getString(12)).andReturn("ISO"); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getString(11)).andReturn("e"); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getString(EasyMock.anyString())).andReturn("1").anyTimes(); //$NON-NLS-1$
    PowerMock.replay(_resultSet);

    Capture<String> imsiCapture = Capture.newInstance();
    _callableStatement.setString(EasyMock.eq("IMSI"), EasyMock.capture(imsiCapture)); //$NON-NLS-1$
    EasyMock.expectLastCall();
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getObject("cursorx")).andReturn(_resultSet); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_RECHERCHE_INFO.P_Recherche_Info_IMSI(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<InfoSIM, Retour> connectorResponse = _pgRechercheInfo.rechercheInformationsIMSI(tracabilite, imsi);

    // Asserts
    assertEquals(String.valueOf(imsi), imsiCapture.getValue());

    assertEquals(8933209805139889922L, connectorResponse._first.getIccid().longValue());
    assertEquals(208209813988992L, connectorResponse._first.getImsi().longValue());
    assertEquals("OK", connectorResponse._second.getResultat());//$NON-NLS-1$
  }

  /**
   * Test update state sim batch
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void testMajEtatSimBatch() throws Exception
  {
    // Request variables
    Tracabilite tracabilite = new Tracabilite();
    long idBatch = 12669;

    // Setup mocks
    Capture<Long> piIDBATCHCapture = Capture.newInstance();
    _callableStatement.setLong(EasyMock.eq("pi_IDBATCH"), EasyMock.captureLong(piIDBATCHCapture)); //$NON-NLS-1$
    EasyMock.expectLastCall();
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_IWSRESSOURCES.P_MAJ_ETAT_BATCH(?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<String, Retour> connectorResponse = _pgIWSRessources.majEtatBatch(tracabilite, idBatch);

    // Asserts
    assertEquals(new Long(idBatch), piIDBATCHCapture.getValue());
    assertEquals(null, connectorResponse._first);
    assertEquals(null, connectorResponse._second.getCategorie());
    assertEquals(null, connectorResponse._second.getLibelle());
    assertEquals(null, connectorResponse._second.getDiagnostic());
  }

  /**
   * Test to Mise a disposition for an existing batchId (idtCmd)
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void testMiseADispositionForExistingBatchId() throws Exception
  {
    // Request variables
    Tracabilite tracabilite = new Tracabilite();
    long idBatch = 12669;

    // Setup mocks
    Capture<Long> piIDBATCHCapture = Capture.newInstance();
    Capture<String> piListeTypeSimCapture = Capture.newInstance();
    Capture<String> piInstanceClienteCapture = Capture.newInstance();
    _callableStatement.setLong(EasyMock.eq("pi_IDBATCH"), EasyMock.captureLong(piIDBATCHCapture)); //$NON-NLS-1$
    _callableStatement.setString(EasyMock.eq("pi_ListeTypeSim"), EasyMock.capture(piListeTypeSimCapture)); //$NON-NLS-1$
    _callableStatement.setString(EasyMock.eq("pi_InstanceCliente"), EasyMock.capture(piInstanceClienteCapture)); //$NON-NLS-1$
    EasyMock.expectLastCall();
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_IWSRESSOURCES.P_MISE_A_DISPOSITION_SIM_BATCH(?,?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<String, Retour> connectorResponse = _pgIWSRessources.miseADispositionSimBatch(tracabilite, idBatch, "1", "1");//$NON-NLS-1$ //$NON-NLS-2$

    // Asserts
    assertEquals(new Long(idBatch), piIDBATCHCapture.getValue());
    assertEquals("1", piListeTypeSimCapture.getValue()); //$NON-NLS-1$
    assertEquals("1", piInstanceClienteCapture.getValue()); //$NON-NLS-1$
    assertEquals(null, connectorResponse._first);
    assertEquals("OK", connectorResponse._second.getResultat());//$NON-NLS-1$
    assertEquals(null, connectorResponse._second.getCategorie());
    assertEquals(null, connectorResponse._second.getLibelle());
    assertEquals(null, connectorResponse._second.getDiagnostic());
  }

  /**
   * Test to Mise a disposition for an non existing batchId (idtCmd)
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void testMiseADispositionForNonExistingBatchId() throws Exception
  {
    // Request variables
    Tracabilite tracabilite = null;
    long idBatch = 112212669;

    // Setup mocks
    Capture<Long> piIDBATCHCapture = Capture.newInstance();
    Capture<String> piListeTypeSimCapture = Capture.newInstance();
    Capture<String> piInstanceClienteCapture = Capture.newInstance();

    _callableStatement.setLong(EasyMock.eq("pi_IDBATCH"), EasyMock.captureLong(piIDBATCHCapture)); //$NON-NLS-1$
    EasyMock.expectLastCall();
    _callableStatement.setString(EasyMock.eq("pi_ListeTypeSim"), EasyMock.capture(piListeTypeSimCapture)); //$NON-NLS-1$
    EasyMock.expectLastCall();
    _callableStatement.setString(EasyMock.eq("pi_InstanceCliente"), EasyMock.capture(piInstanceClienteCapture)); //$NON-NLS-1$
    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_IWSRESSOURCES.P_MISE_A_DISPOSITION_SIM_BATCH(?,?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<String, Retour> connectorResponse = _pgIWSRessources.miseADispositionSimBatch(tracabilite, idBatch, "1", "1");//$NON-NLS-1$ //$NON-NLS-2$

    // Asserts
    assertEquals(new Long(idBatch), piIDBATCHCapture.getValue());
    assertEquals("1", piListeTypeSimCapture.getValue()); //$NON-NLS-1$
    assertEquals("1", piInstanceClienteCapture.getValue()); //$NON-NLS-1$
    assertEquals(null, connectorResponse._first);
    assertEquals("OK", connectorResponse._second.getResultat());//$NON-NLS-1$
    assertEquals(null, connectorResponse._second.getCategorie());
    assertEquals(null, connectorResponse._second.getLibelle());
    assertEquals(null, connectorResponse._second.getDiagnostic());
  }

  /**
   * Test to P_003_Resiliation_MSISDN with a given unknown msisdn<br/>
   *
   * <b>Entrées:</b>MSISDN=0624558844<br/>
   * <b>Attendu:</b>Retour=KO/CAT-3/DONNEE_INCONNUE<br/>
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void test_P_003_Resiliation_MSISDN_NOT_FOUND() throws Exception
  {
    // Request variables
    Tracabilite tracabilite = new Tracabilite();
    String msisdn = "0624558844"; //$NON-NLS-1$

    // Setup statement mock
    Capture<String> msisdnCapture = Capture.newInstance();
    _callableStatement.setString(EasyMock.eq("pi_MSISDN"), EasyMock.capture(msisdnCapture)); //$NON-NLS-1$
    EasyMock.expectLastCall();
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.KO); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString("Retour_Categorie")).andReturn(IMegConsts.CAT3); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString("Retour_Diagnostic")).andReturn(IMegConsts.DONNEE_INCONNUE); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString("Retour_Libelle")).andReturn("Le MSISDN 0624558844 n'est pas présent."); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_callableStatement.getString("Etat_Final")).andReturn(StringConstants.OK); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_IWSRESSOURCES.P_003_Resiliation_MSISDN(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<String, Retour> connectorResponse = _pgIWSRessources.ps003ResiliationMSISDN(tracabilite, msisdn);

    // Asserts
    assertEquals(msisdn, msisdnCapture.getValue());
    assertEquals("KO", connectorResponse._second.getResultat());//$NON-NLS-1$
    assertEquals("CAT-3", connectorResponse._second.getCategorie()); //$NON-NLS-1$
    assertEquals("Le MSISDN 0624558844 n'est pas présent.", connectorResponse._second.getLibelle()); //$NON-NLS-1$
    assertEquals("DONNEE_INCONNUE", connectorResponse._second.getDiagnostic()); //$NON-NLS-1$
  }

  /**
   * Test to P_003_Resiliation_MSISDN with a "Résilié" MSISDN<br/>
   *
   * <b>Entrées:</b>MSISDN=762130712<br/>
   * <b>Attendu:</b>Retour=OK, Etat_Final=Résilié<br/>
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void test_P_003_Resiliation_MSISDN_RESILIE() throws Exception
  {
    // Request variables
    Tracabilite tracabilite = new Tracabilite();
    String msisdn = "762130712"; //$NON-NLS-1$

    // Setup statement mock
    Capture<String> msisdnCapture = Capture.newInstance();
    _callableStatement.setString(EasyMock.eq("pi_MSISDN"), EasyMock.capture(msisdnCapture)); //$NON-NLS-1$
    EasyMock.expectLastCall();
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString("Etat_Final")).andReturn("Résilié"); //$NON-NLS-1$ //$NON-NLS-2$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_IWSRESSOURCES.P_003_Resiliation_MSISDN(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<String, Retour> connectorResponse = _pgIWSRessources.ps003ResiliationMSISDN(tracabilite, msisdn);

    assertEquals("OK", connectorResponse._second.getResultat());//$NON-NLS-1$
    assertEquals(null, connectorResponse._second.getCategorie());
    assertEquals(null, connectorResponse._second.getLibelle());
    assertEquals(null, connectorResponse._second.getDiagnostic());
    assertEquals("Résilié", connectorResponse._first);//$NON-NLS-1$
  }

  /**
   * Test to ps001ConsultTYPEMSISDNFROMType.<br/>
   *
   * <b>Entrées:</b>TYPEMSI = 99<br/>
   * <b>Attendu:</b>Retour=OK<br/>
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void test_ps001ConsultTYPEMSFROMType() throws Exception
  {
    // Request variables
    Tracabilite tracabilite = new Tracabilite();
    int typmsi = 99;

    // Setup mocks
    EasyMock.expect(_resultSet.next()).andReturn(true);
    EasyMock.expect(_resultSet.getInt(TypeMsisdn.TYPMSI)).andReturn(99);
    EasyMock.expect(_resultSet.getString(TypeMsisdn.LIBTYPMSI)).andReturn("Tranche de reserve pour les MVNO"); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getObject(TypeMsisdn.DURRSV)).andReturn(TypeMsisdn.DURRSV);
    EasyMock.expect(_resultSet.getInt(TypeMsisdn.DURRSV)).andReturn(16);
    EasyMock.expect(_resultSet.getString(TypeMsisdn.GENAUT)).andReturn("X"); //$NON-NLS-1$
    PowerMock.replay(_resultSet);

    Capture<String> msisdnCapture = Capture.newInstance();
    _callableStatement.setString(EasyMock.eq("pi_MSISDN"), EasyMock.capture(msisdnCapture)); //$NON-NLS-1$
    EasyMock.expectLastCall();
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString("Etat_Final")).andReturn("Résilié"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_callableStatement.getObject("cursorx")).andReturn(_resultSet); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_IWSRESSOURCES.P_001_Consult_TYPMSI_FROM_Type(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<TypeMsisdn, Retour> connectorResponse = _pgIWSRessources.ps001ConsultTYPEMSIFROMType(tracabilite, typmsi);

    // Asserts
    TypeMsisdn typeMsisdnExpected = new TypeMsisdn(99, "Tranche de reserve pour les MVNO", null, 16, true); //$NON-NLS-1$
    assertEquals(typeMsisdnExpected, connectorResponse._first);

    assertEquals("OK", connectorResponse._second.getResultat());//$NON-NLS-1$
    assertEquals(null, connectorResponse._second.getCategorie());
    assertEquals(null, connectorResponse._second.getLibelle());
    assertEquals(null, connectorResponse._second.getDiagnostic());
  }

  /**
   * Test to ps002ReserveMSISDNFROMModeCritere.<br/>
   *
   * <b>Entrées:</b>instanceClient = "GP1", nbMsisdn = 1, mode = "DEFAULT", typeMsisdn = 7, critereRecherche = 762130780,
   * typeReservation = 10 , etatCible = "i" <br/>
   * <b>Attendu:</b>Retour=OK<br/>
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void test_ps002ReserveMSISDNFROMModeCritere_DEFAULT() throws Exception
  {
    // Request variables
    Tracabilite tracabilite = new Tracabilite();
    String instanceClient = "GP1"; //$NON-NLS-1$
    Integer nbMsisdn = 1;
    String mode = "DEFAULT"; //$NON-NLS-1$
    Integer typeMsisdn = 7;
    Integer critereRecherche = 762130780;
    Integer typeReservation = 1;
    String etatCible = "i"; //$NON-NLS-1$
    String dureeReservation_p = null;
    int dureeReservationTemporaire = 0;
    String idReservationMSISDN_p = "20170127150919264"; //$NON-NLS-1$

    // Setup mocks
    EasyMock.expect(_resultSet.next()).andReturn(true);
    EasyMock.expect(_resultSet.getLong(MSISDN.NUMTEL)).andReturn(762132722L);
    EasyMock.expect(_resultSet.getInt(MSISDN.TYPMSI)).andReturn(7);
    EasyMock.expect(_resultSet.getInt(MSISDN.IDTHLR)).andReturn(98);
    EasyMock.expect(_resultSet.getInt(MSISDN.IDTACNMSI)).andReturn(10);
    EasyMock.expect(_resultSet.getString(MSISDN.ETAMSI)).andReturn("i"); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getInt(MSISDN.DRNDGT)).andReturn(2722);
    EasyMock.expect(_resultSet.getTimestamp(MSISDN.DATETA)).andReturn(new Timestamp(new Date().getTime()));
    PowerMock.replay(_resultSet);

    Capture<String> msisdnCapture = Capture.newInstance();
    _callableStatement.setString(EasyMock.eq("pi_MSISDN"), EasyMock.capture(msisdnCapture)); //$NON-NLS-1$
    EasyMock.expectLastCall();
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString("Etat_Final")).andReturn("Résilié"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_callableStatement.getObject("po_Cursorx")).andReturn(_resultSet); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_IWSRESSOURCES.P_002_Reserve_MSISDN_FROM_Mode(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<List<MSISDN>, Retour> connectorResponse = _pgIWSRessources.ps002ReserveMSISDNFROMModeCritere(tracabilite, instanceClient, nbMsisdn, mode, typeMsisdn, critereRecherche, typeReservation, etatCible, dureeReservation_p, dureeReservationTemporaire, idReservationMSISDN_p, null);

    // Asserts
    MSISDN msisdnExpected = new MSISDN(762132722L, 7, 98, null, 10, "i", null, 2722, null, null, null, null); //$NON-NLS-1$
    MSISDN msisdnReceived = connectorResponse._first.get(0);

    assertEquals(msisdnExpected, msisdnReceived);
    assertEquals("OK", connectorResponse._second.getResultat());//$NON-NLS-1$
    assertEquals(null, connectorResponse._second.getCategorie());
    assertEquals(null, connectorResponse._second.getLibelle());
    assertEquals(null, connectorResponse._second.getDiagnostic());
  }

  /**
   * Test to ps002ReserveMSISDNFROMModeCritere.<br/>
   *
   * <b>Entrées:</b>instanceClient = "GP1", nbMsisdn = 1, mode = "FULL", typeMsisdn = 7, critereRecherche = 762130780,
   * typeReservation = 10 , etatCible = "i" <br/>
   * <b>Attendu:</b>Retour=OK<br/>
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void test_ps002ReserveMSISDNFROMModeCritere_FULL() throws Exception
  {
    // Request variables
    Tracabilite tracabilite = new Tracabilite();
    String instanceClient = "GP1"; //$NON-NLS-1$
    Integer nbMsisdn = 1;
    String mode = "FULL"; //$NON-NLS-1$
    Integer typeMsisdn = 7;
    Integer critereRecherche = 762130756;
    Integer typeReservation = 15;
    String etatCible = "i"; //$NON-NLS-1$
    String dureeReservation_p = null;
    int dureeReservationTemporaire = 0;

    // Setup mocks
    EasyMock.expect(_resultSet.next()).andReturn(true);
    EasyMock.expect(_resultSet.getLong(MSISDN.NUMTEL)).andReturn(762130756L);
    EasyMock.expect(_resultSet.getInt(MSISDN.TYPMSI)).andReturn(7);
    EasyMock.expect(_resultSet.getInt(MSISDN.IDTHLR)).andReturn(98);
    EasyMock.expect(_resultSet.getInt(MSISDN.IDTACNMSI)).andReturn(10);
    EasyMock.expect(_resultSet.getString(MSISDN.ETAMSI)).andReturn("i"); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getInt(MSISDN.DRNDGT)).andReturn(732);
    EasyMock.expect(_resultSet.getTimestamp(MSISDN.DATETA)).andReturn(new Timestamp(new Date().getTime()));
    PowerMock.replay(_resultSet);

    Capture<String> msisdnCapture = Capture.newInstance();
    _callableStatement.setString(EasyMock.eq("pi_MSISDN"), EasyMock.capture(msisdnCapture)); //$NON-NLS-1$
    EasyMock.expectLastCall();
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString("Etat_Final")).andReturn("Résilié"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_callableStatement.getObject("po_Cursorx")).andReturn(_resultSet); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_IWSRESSOURCES.P_002_Reserve_MSISDN_FROM_Mode(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<List<MSISDN>, Retour> connectorResponse = _pgIWSRessources.ps002ReserveMSISDNFROMModeCritere(tracabilite, instanceClient, nbMsisdn, mode, typeMsisdn, critereRecherche, typeReservation, etatCible, dureeReservation_p, dureeReservationTemporaire, null, null);

    // Asserts
    MSISDN msisdnExpected = new MSISDN(762130756L, 7, 98, null, 10, "i", null, 732, null, null, null, null); //$NON-NLS-1$
    MSISDN msisdnReceived = connectorResponse._first.get(0);

    assertEquals(msisdnExpected, msisdnReceived);
    assertEquals("OK", connectorResponse._second.getResultat());//$NON-NLS-1$
    assertEquals(null, connectorResponse._second.getCategorie());
    assertEquals(null, connectorResponse._second.getLibelle());
    assertEquals(null, connectorResponse._second.getDiagnostic());
  }

  /**
   * Test to ps002ReserveMSISDNFROMModeCritere.<br/>
   *
   * <b>Entrées:</b>instanceClient = "GP1", nbMsisdn = 1, mode = "LAST_DIGITS", typeMsisdn = 7, critereRecherche =
   * 762130780, typeReservation = 10 , etatCible = "i" <br/>
   * <b>Attendu:</b>Retour=OK<br/>
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void test_ps002ReserveMSISDNFROMModeCritere_LAST_DIGITS() throws Exception
  {
    // Request variables
    Tracabilite tracabilite = new Tracabilite();
    String instanceClient = "GP1"; //$NON-NLS-1$
    Integer nbMsisdn = 1;
    String mode = "LAST_DIGITS"; //$NON-NLS-1$
    Integer typeMsisdn = 7;
    Integer critereRecherche = 9068;
    Integer typeReservation = 15;
    String etatCible = "i"; //$NON-NLS-1$
    String dureeReservation_p = null;
    int dureeReservationTemporaire = 0;

    // Setup mocks
    EasyMock.expect(_resultSet.next()).andReturn(true);
    EasyMock.expect(_resultSet.getLong(MSISDN.NUMTEL)).andReturn(762139068L);
    EasyMock.expect(_resultSet.getInt(MSISDN.TYPMSI)).andReturn(7);
    EasyMock.expect(_resultSet.getInt(MSISDN.IDTHLR)).andReturn(98);
    EasyMock.expect(_resultSet.getInt(MSISDN.IDTACNMSI)).andReturn(10);
    EasyMock.expect(_resultSet.getString(MSISDN.ETAMSI)).andReturn("i"); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getInt(MSISDN.DRNDGT)).andReturn(732);
    EasyMock.expect(_resultSet.getTimestamp(MSISDN.DATETA)).andReturn(new Timestamp(new Date().getTime()));
    PowerMock.replay(_resultSet);

    Capture<String> msisdnCapture = Capture.newInstance();
    _callableStatement.setString(EasyMock.eq("pi_MSISDN"), EasyMock.capture(msisdnCapture)); //$NON-NLS-1$
    EasyMock.expectLastCall();
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString("Etat_Final")).andReturn("Résilié"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_callableStatement.getObject("po_Cursorx")).andReturn(_resultSet); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_IWSRESSOURCES.P_002_Reserve_MSISDN_FROM_Mode(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<List<MSISDN>, Retour> connectorResponse = _pgIWSRessources.ps002ReserveMSISDNFROMModeCritere(tracabilite, instanceClient, nbMsisdn, mode, typeMsisdn, critereRecherche, typeReservation, etatCible, dureeReservation_p, dureeReservationTemporaire, null, null);

    // Asserts
    MSISDN msisdnExpected = new MSISDN(762139068L, 7, 98, null, 10, "i", new Date(), 732, null, null, null, null); //$NON-NLS-1$
    MSISDN msisdnReceived = connectorResponse._first.get(0);

    assertEquals(msisdnExpected, msisdnReceived);
    assertEquals("OK", connectorResponse._second.getResultat());//$NON-NLS-1$
    assertEquals(null, connectorResponse._second.getCategorie());
    assertEquals(null, connectorResponse._second.getLibelle());
    assertEquals(null, connectorResponse._second.getDiagnostic());
  }

  /**
   * Test to ps002ReserveMSISDNFROMModeCritere.<br/>
   *
   * <b>Entrées:</b>instanceClient = "GP1", nbMsisdn = 1, mode = "MIN_MAX", typeMsisdn = 7, critereRecherche = 762130780,
   * typeReservation = 10 , etatCible = "i" <br/>
   * <b>Attendu:</b>Retour=OK<br/>
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void test_ps002ReserveMSISDNFROMModeCritere_MIN_MAX() throws Exception
  {
    // Request variables
    Tracabilite tracabilite = new Tracabilite();
    String instanceClient = "GP1"; //$NON-NLS-1$
    Integer nbMsisdn = 1;
    String mode = "MIN_MAX"; //$NON-NLS-1$
    Integer typeMsisdn = 7;
    Integer critereRecherche = 7621;
    Integer typeReservation = 10;
    String etatCible = "i"; //$NON-NLS-1$
    String dureeReservation_p = null;
    int dureeReservationTemporaire = 0;

    // Setup mocks
    EasyMock.expect(_resultSet.next()).andReturn(true);
    EasyMock.expect(_resultSet.getLong(MSISDN.NUMTEL)).andReturn(762130732L);
    EasyMock.expect(_resultSet.getInt(MSISDN.TYPMSI)).andReturn(7);
    EasyMock.expect(_resultSet.getInt(MSISDN.IDTHLR)).andReturn(98);
    EasyMock.expect(_resultSet.getInt(MSISDN.IDTACNMSI)).andReturn(10);
    EasyMock.expect(_resultSet.getString(MSISDN.ETAMSI)).andReturn("i"); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getInt(MSISDN.DRNDGT)).andReturn(732);
    EasyMock.expect(_resultSet.getTimestamp(MSISDN.DATETA)).andReturn(new Timestamp(new Date().getTime()));
    PowerMock.replay(_resultSet);

    Capture<String> msisdnCapture = Capture.newInstance();
    _callableStatement.setString(EasyMock.eq("pi_MSISDN"), EasyMock.capture(msisdnCapture)); //$NON-NLS-1$
    EasyMock.expectLastCall();
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString("Etat_Final")).andReturn("Résilié"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_callableStatement.getObject("po_Cursorx")).andReturn(_resultSet); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_IWSRESSOURCES.P_002_Reserve_MSISDN_FROM_Mode(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<List<MSISDN>, Retour> connectorResponse = _pgIWSRessources.ps002ReserveMSISDNFROMModeCritere(tracabilite, instanceClient, nbMsisdn, mode, typeMsisdn, critereRecherche, typeReservation, etatCible, dureeReservation_p, dureeReservationTemporaire, null, null);

    //Asserts
    MSISDN msisdnExpected = new MSISDN(762130732L, 7, 98, null, 10, "i", new Date(), 732, null, null, null, null); //$NON-NLS-1$
    MSISDN msisdnReceived = connectorResponse._first.get(0);

    assertEquals(msisdnExpected, msisdnReceived);
    assertEquals("OK", connectorResponse._second.getResultat());//$NON-NLS-1$
    assertEquals(null, connectorResponse._second.getCategorie());
    assertEquals(null, connectorResponse._second.getLibelle());
    assertEquals(null, connectorResponse._second.getDiagnostic());

  }

  /**
   * Test to P_004_GetIMSIFromICCID
   *
   * <b>Entrées:</b>pi_ICCID = 8933209805139306257 <b>Attendu:</b>Retour=OK<br/>
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_ps004GetIMSIFromICCID() throws Exception
  {
    //8933209805139306257 -> 208209813930625
    Tracabilite tracabilite = new Tracabilite();
    String iccid = "8933209805139306257"; //$NON-NLS-1$
    String imsiExpected = "208209813930625"; //$NON-NLS-1$

    // Setup statement mock
    Capture<String> msisdnCapture = Capture.newInstance();
    _callableStatement.setString(EasyMock.eq("pi_MSISDN"), EasyMock.capture(msisdnCapture)); //$NON-NLS-1$
    EasyMock.expectLastCall();
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString("Etat_Final")).andReturn("Résilié"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_callableStatement.getString("po_IMSI")).andReturn(imsiExpected); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_IWSRESSOURCES.P_004_GetIMSIFromICCID(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<String, Retour> connectorResponse = _pgIWSRessources.ps004GetIMSIFromICCID(tracabilite, iccid);

    // Asserts
    String imsiReceived = connectorResponse._first;
    assertEquals(imsiExpected, imsiReceived);
    assertEquals("OK", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(null, connectorResponse._second.getCategorie());
    assertEquals(null, connectorResponse._second.getLibelle());
    assertEquals(null, connectorResponse._second.getDiagnostic());
  }

  /**
   * Test to P_005_CONSULT_CARTE_PROFILE
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_ps005ConsultCarteProfile() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String iccid = "8933209805139889427"; //$NON-NLS-1$
    String imsi = "208209813911939"; //$NON-NLS-1$

    // Setup mocks
    EasyMock.expect(_resultSet.next()).andReturn(true);
    EasyMock.expect(_resultSet.getString("ICCID")).andReturn("8933209805139889427"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("CarteProfile")).andReturn("16.27"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("ETASMDP")).andReturn("ACTIF"); //$NON-NLS-1$ //$NON-NLS-2$
    PowerMock.replay(_resultSet);

    Capture<String> piICCIDCapture = Capture.newInstance();
    Capture<String> piIMSICapture = Capture.newInstance();
    _callableStatement.setString(EasyMock.eq("pi_ICCID"), EasyMock.capture(piICCIDCapture)); //$NON-NLS-1$
    _callableStatement.setString(EasyMock.eq("pi_IMSI"), EasyMock.capture(piIMSICapture)); //$NON-NLS-1$
    EasyMock.expectLastCall();
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getObject("po_RESULT")).andReturn(_resultSet); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_IWSRESSOURCES.P_005_CONSULT_CARTE_PROFILE(?,?,?,?,?,?,?) }")).andReturn(_callableStatement).times(2); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<List<CarteProfileData>, Retour> connectorResponse = _pgIWSRessources.ps005ConsultCarteProfile(tracabilite, iccid, null);
    List<CarteProfileData> cpdList = connectorResponse._first;

    // Asserts
    assertNotNull(cpdList);
    assertEquals(1, cpdList.size());
    assertEquals(iccid, piICCIDCapture.getValue());
    assertNull(piIMSICapture.getValue());
    assertEquals("8933209805139889427", cpdList.get(0).getIccid()); //$NON-NLS-1$
    assertEquals("16.27", cpdList.get(0).getCarteProfile()); //$NON-NLS-1$
    assertEquals("ACTIF", cpdList.get(0).getEtatSmdp()); //$NON-NLS-1$

    assertEquals("OK", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(null, connectorResponse._second.getCategorie());
    assertEquals(null, connectorResponse._second.getLibelle());
    assertEquals(null, connectorResponse._second.getDiagnostic());

    // Reset mocks
    PowerMock.reset(_resultSet);
    PowerMock.reset(_callableStatement);
    PowerMock.reset(_connection);

    // Setup mocks
    EasyMock.expect(_resultSet.next()).andReturn(true);
    EasyMock.expect(_resultSet.getString("ICCID")).andReturn("8933209805139119395"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("CarteProfile")).andReturn("16.27"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("ETASMDP")).andReturn("ACTIF"); //$NON-NLS-1$ //$NON-NLS-2$
    PowerMock.replay(_resultSet);

    piICCIDCapture = Capture.newInstance();
    piIMSICapture = Capture.newInstance();
    _callableStatement.setString(EasyMock.eq("pi_ICCID"), EasyMock.capture(piICCIDCapture)); //$NON-NLS-1$
    _callableStatement.setString(EasyMock.eq("pi_IMSI"), EasyMock.capture(piIMSICapture)); //$NON-NLS-1$
    EasyMock.expectLastCall();
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getObject("po_RESULT")).andReturn(_resultSet); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_IWSRESSOURCES.P_005_CONSULT_CARTE_PROFILE(?,?,?,?,?,?,?) }")).andReturn(_callableStatement).times(2); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector 2nd time
    connectorResponse = _pgIWSRessources.ps005ConsultCarteProfile(tracabilite, null, imsi);

    cpdList = connectorResponse._first;

    assertNull(iccid, piICCIDCapture.getValue());
    assertEquals(imsi, piIMSICapture.getValue());
    assertNotNull(cpdList);
    assertEquals(1, cpdList.size());
    assertEquals("8933209805139119395", cpdList.get(0).getIccid()); //$NON-NLS-1$
    assertEquals("16.27", cpdList.get(0).getCarteProfile()); //$NON-NLS-1$
    assertEquals("ACTIF", cpdList.get(0).getEtatSmdp()); //$NON-NLS-1$

    assertEquals("OK", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(null, connectorResponse._second.getCategorie());
    assertEquals(null, connectorResponse._second.getLibelle());
    assertEquals(null, connectorResponse._second.getDiagnostic());
  }

  /**
   * Test to P_006_Consult_MSISDN
   *
   * <b>Entrées:</b>pi_NUMTEL = 762140236 <b>Attendu:762140236</b>Retour=OK<br/>
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_ps006ConsultMSISDN() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String msisdn = "762140236"; //$NON-NLS-1$

    // Setup statement mock
    EasyMock.expect(_resultSet.next()).andReturn(true);
    EasyMock.expect(_resultSet.getTimestamp("DATETA")).andReturn(new Timestamp(1L)); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getLong("NUMTEL")).andReturn(Long.parseLong(msisdn)); //$NON-NLS-1$
    PowerMock.replay(_resultSet);

    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getObject("po_RESULT")).andReturn(_resultSet); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_IWSRESSOURCES.P_006_Consult_MSISDN(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<MSISDN, Retour> connectorResponse = _pgIWSRessources.ps006ConsultMSISDN(tracabilite, msisdn);

    // Asserts
    String msisdnReceived = connectorResponse._first.getMsisdn().toString();
    assertEquals(msisdn, msisdnReceived);
    assertEquals("OK", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(null, connectorResponse._second.getCategorie());
    assertEquals(null, connectorResponse._second.getLibelle());
    assertEquals(null, connectorResponse._second.getDiagnostic());
  }

  /**
   * Test to P_007_CONSULT_DUREE_QUAR
   *
   * @throws RavelException
   *           exception
   */
  @Test
  public void test_ps007ConsultDureeQuarantaine() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    Integer typeMSISDN = 25;
    String instanceCliente = "ENT1"; //$NON-NLS-1$
    Integer dureeQuarantaine = 50;

    // Setup statement mock
    EasyMock.expect(_resultSet.next()).andReturn(true);
    EasyMock.expect(_resultSet.getObject("TYPMSI")).andReturn(typeMSISDN); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getObject("DUR040")).andReturn(dureeQuarantaine); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getInt("TYPMSI")).andReturn(typeMSISDN); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getInt("DUR040")).andReturn(dureeQuarantaine); //$NON-NLS-1$
    PowerMock.replay(_resultSet);

    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getObject("po_RESULT")).andReturn(_resultSet); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_IWSRESSOURCES.P_007_CONSULT_DUREE_QUAR(?,?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<DURMSI, Retour> connectorResponse = _pgIWSRessources.ps007ConsultDureeQuarantaine(tracabilite, typeMSISDN, instanceCliente);

    // Asserts
    assertEquals(typeMSISDN, connectorResponse._first.getTypeMSISDN());
    assertEquals(dureeQuarantaine, connectorResponse._first.getDureeQuarantaine());
    assertEquals(StringConstants.OK, connectorResponse._second.getResultat());
    assertNull(connectorResponse._second.getCategorie());
    assertNull(connectorResponse._second.getLibelle());
    assertNull(connectorResponse._second.getDiagnostic());
  }

  /**
   * Test to P_008_ConsultLastHistEtaMSISDN
   *
   * <b>Entrées:</b>pi_NUMTEL = 762110100 <b>Attendu:</b>Retour=OK<br/>
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_ps008ConsultLatestHistoriqueEtatMSISDN() throws Exception
  {
    Tracabilite tracabilite = new Tracabilite();
    String numtel = "762110100"; //$NON-NLS-1$
    String instanceClientExpected = "GP1"; //$NON-NLS-1$

    // Setup mocks
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString("po_IDTIST")).andReturn(instanceClientExpected); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_IWSRESSOURCES.P_008_ConsultLastHistEtaMSISDN(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<String, Retour> connectorResponse = _pgIWSRessources.ps008ConsultLatestHistoriqueEtatMSISDN(tracabilite, numtel);

    String instanceClientReceived = connectorResponse._first;

    assertEquals(instanceClientExpected, instanceClientReceived);

    assertEquals("OK", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(null, connectorResponse._second.getCategorie());
    assertEquals(null, connectorResponse._second.getLibelle());
    assertEquals(null, connectorResponse._second.getDiagnostic());
  }

  /**
   * Test to P_009_GetICCIDFromIMSI KO
   *
   * <b>Entrées:</b>pi_IMSI = x </br>
   * <b>Attendu:</b>Retour=KO Categorie = CAT-3 Diagnostic = DONNEE_INCONNUE Libelle = L'IMSI x n'est pas présent.<br/>
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_ps009GetICCIDFromIMSI_KO() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String imsi = "x"; //$NON-NLS-1$

    // Setup mocks
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.KO); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString("Retour_Categorie")).andReturn(IMegConsts.CAT3); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString("Retour_Diagnostic")).andReturn(IMegConsts.DONNEE_INCONNUE); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString("Retour_Libelle")).andReturn("L'IMSI x n'est pas présent."); //$NON-NLS-1$ //$NON-NLS-2$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_IWSRESSOURCES.P_009_GetICCIDFromIMSI(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<String, Retour> connectorResponse = _pgIWSRessources.ps009GetICCIDFromIMSI(tracabilite, imsi);

    // Assertions
    String iccidReceived = connectorResponse._first;
    assertEquals(null, iccidReceived);
    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT3, connectorResponse._second.getCategorie());
    assertEquals("DONNEE_INCONNUE", connectorResponse._second.getDiagnostic()); //$NON-NLS-1$
    assertEquals("L'IMSI x n'est pas présent.", connectorResponse._second.getLibelle()); //$NON-NLS-1$
  }

  /**
   * Test to P_009_GetICCIDFromIMSI OK
   *
   * <b>Entrées:</b>pi_IMSI = 208209813930625 <b>Attendu:</b>Retour=OK<br/>
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_ps009GetICCIDFromIMSI_OK() throws Exception
  {
    //208209813930625 -> 8933209805139306257
    Tracabilite tracabilite = new Tracabilite();
    String imsi = "208209813930625"; //$NON-NLS-1$
    String iccidExpected = "8933209805139306257"; //$NON-NLS-1$

    // Setup mocks
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString("po_ICCID")).andReturn(iccidExpected); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_IWSRESSOURCES.P_009_GetICCIDFromIMSI(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<String, Retour> connectorResponse = _pgIWSRessources.ps009GetICCIDFromIMSI(tracabilite, imsi);

    String iccidReceived = connectorResponse._first;

    // Asserts
    assertEquals(iccidExpected, iccidReceived);
    assertEquals("OK", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(null, connectorResponse._second.getCategorie());
    assertEquals(null, connectorResponse._second.getLibelle());
    assertEquals(null, connectorResponse._second.getDiagnostic());
  }

  /**
   * Test to ps010ReattribuerMSISDN OK
   *
   * <b>Entrées:</b>pi_NUMTEL = 762139548 <b>Attendu:</b>Retour=OK<br/>
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_ps010ReattribuerMSISDN_OK() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    long numtel = 762139548L;
    String etatCibleMsisdn = "D"; //$NON-NLS-1$
    String etatCibleCom = "R"; //$NON-NLS-1$
    String etatCiblePorta = ""; //$NON-NLS-1$
    Integer objetModification = 81;
    String instanceCliente = "GP1"; //$NON-NLS-1$

    // Setup mocks
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_IWSRESSOURCES.P_010_ReattribuerMSISDN(?,?,?,?,?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<String, Retour> connectorResponse = _pgIWSRessources.ps010ReattribuerMSISDN(tracabilite, numtel, etatCibleMsisdn, etatCibleCom, etatCiblePorta, objetModification, instanceCliente);

    // Asserts
    assertEquals("OK", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(null, connectorResponse._second.getCategorie());
    assertEquals(null, connectorResponse._second.getLibelle());
    assertEquals(null, connectorResponse._second.getDiagnostic());
  }

  /**
   * Test to ps002ReserveMSISDNFROMModeCritere.<br/>
   *
   * <b>Entrées:</b>instanceClient = "GP1", nbMsisdn = 1, mode = "DEFAULT", typeMsisdn = 7, critereRecherche = 762130780,
   * typeReservation = 10 , etatCible = "i" dureeReservation ="temporaire"<br/>
   * <b>Attendu:</b>Retour=OK<br/>
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void test_ps011ReserveMSISDNFROMModeCritere_DEFAULT() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String instanceClient = "GP1"; //$NON-NLS-1$
    Integer nbMsisdn = 1;
    String mode = "DEFAULT"; //$NON-NLS-1$
    Integer typeMsisdn = 7;
    Integer critereRecherche = 762130780;
    Integer typeReservation = 1;
    String etatCible = "i"; //$NON-NLS-1$
    String dureeReservation_p = "temporaire"; //$NON-NLS-1$
    int dureeReservationTemporaire = 0;
    String idReservationMSISDN_p = "20170127150919264"; //$NON-NLS-1$
    String idtdermod = "PM002 ReservationMsisdn"; //$NON-NLS-1$

    // Setup statement mock
    EasyMock.expect(_resultSet.next()).andReturn(true);
    EasyMock.expect(_resultSet.getLong(MSISDN.NUMTEL)).andReturn(new Long(critereRecherche));
    EasyMock.expect(_resultSet.getInt(MSISDN.TYPMSI)).andReturn(7);
    EasyMock.expect(_resultSet.getInt(MSISDN.IDTHLR)).andReturn(98);
    EasyMock.expect(_resultSet.getString(MSISDN.IDTCMDMSI)).andReturn(idReservationMSISDN_p);
    EasyMock.expect(_resultSet.getInt(MSISDN.IDTACNMSI)).andReturn(nbMsisdn);
    EasyMock.expect(_resultSet.getString(MSISDN.ETAMSI)).andReturn("i"); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getInt(MSISDN.DRNDGT)).andReturn(732);
    EasyMock.expect(_resultSet.getTimestamp(MSISDN.DATETA)).andReturn(new Timestamp(new Date().getTime()));
    PowerMock.replay(_resultSet);

    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getObject("po_Cursorx")).andReturn(_resultSet); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_IWSRESSOURCES.P_002_Reserve_MSISDN_FROM_Mode(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<List<MSISDN>, Retour> connectorResponse = _pgIWSRessources.ps002ReserveMSISDNFROMModeCritere(tracabilite, instanceClient, nbMsisdn, mode, typeMsisdn, critereRecherche, typeReservation, etatCible, dureeReservation_p, dureeReservationTemporaire, idReservationMSISDN_p, idtdermod);

    // Assertions
    MSISDN msisdnExpected = new MSISDN(762130780L, 7, 98, "20170127150919264", 1, "i", new Date(), 780, "X", null, null, "NOMAD1_FP_GSMCAP_374.msg_5109813984354_NPBT"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    MSISDN msisdnReceived = connectorResponse._first.get(0);

    assertEquals(msisdnExpected, msisdnReceived);
    assertEquals("OK", connectorResponse._second.getResultat());//$NON-NLS-1$
    assertEquals(null, connectorResponse._second.getCategorie());
    assertEquals(null, connectorResponse._second.getLibelle());
    assertEquals(null, connectorResponse._second.getDiagnostic());
  }

  /**
   * Test to P_011_UpdateSimFromIccid OK
   *
   * <b>Entrées:</b>pi_iccid = 8933209805139961051 <b>Attendu:</b>Retour=OK<br/>
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_ps011UpdateSIMFromICCID() throws Exception
  {
    Tracabilite tracabilite = new Tracabilite();
    String iccid = "8933209805139961051"; //$NON-NLS-1$
    String etatSimCible = "r"; //$NON-NLS-1$
    Integer objetModification = 48;
    String etatComCible = null;
    String etatPorCible = null;
    String identifiantModif = "PM016"; //$NON-NLS-1$
    String instanceCliente = "GP1"; //$NON-NLS-1$

    // Setup mocks
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_IWSRESSOURCES.P_011_UpdateSimFromIccid(?,?,?,?,?,?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<String, Retour> connectorResponse = _pgIWSRessources.ps011UpdateSIMFromICCID(tracabilite, iccid, etatSimCible, objetModification, etatComCible, etatPorCible, identifiantModif, instanceCliente);

    assertEquals("OK", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(null, connectorResponse._second.getCategorie());
    assertEquals(null, connectorResponse._second.getLibelle());
    assertEquals(null, connectorResponse._second.getDiagnostic());
    assertNull(connectorResponse._first);
  }

  /**
   * Test to P_009_GetICCIDFromIMSI2 KO
   *
   * <b>Entrées:</b>pi_IMSI = x </br>
   * <b>Attendu:</b>Retour=KO Categorie = CAT-3 Diagnostic = DONNEE_INCONNUE Libelle = L'IMSI x n'est pas présent.<br/>
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_ps012GetICCIDFromIMSI_KO() throws Exception
  {
    Tracabilite tracabilite = new Tracabilite();
    String imsi = "x"; //$NON-NLS-1$

    // Setup mocks
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.KO); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString("Retour_Categorie")).andReturn(IMegConsts.CAT3); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString("Retour_Diagnostic")).andReturn(IMegConsts.DONNEE_INCONNUE); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString("Retour_Libelle")).andReturn("L'IMSI x n'est pas présent."); //$NON-NLS-1$ //$NON-NLS-2$

    EasyMock.expect(_callableStatement.getObject("po_RESULT")).andReturn(_resultSet); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_IWSRESSOURCES.P_012_GetICCIDFromIMSI(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<Sim, Retour> connectorResponse = _pgIWSRessources.ps012GetICCIDFromIMSI(tracabilite, imsi);

    Sim sim = connectorResponse._first;

    assertEquals(null, sim);

    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT3, connectorResponse._second.getCategorie());
    assertEquals("DONNEE_INCONNUE", connectorResponse._second.getDiagnostic()); //$NON-NLS-1$
    assertEquals("L'IMSI x n'est pas présent.", connectorResponse._second.getLibelle()); //$NON-NLS-1$
  }

  /**
   * Test to P_009_GetICCIDFromIMSI OK
   *
   * <b>Entrées:</b>pi_IMSI = 208209813930625 <b>Attendu:</b>Retour=OK<br/>
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_ps012GetICCIDFromIMSI_OK() throws Exception
  {
    //208209813930625 -> 8933209805139306257
    Tracabilite tracabilite = new Tracabilite();
    String imsi = "208209813930625"; //$NON-NLS-1$

    // Setup mocks
    EasyMock.expect(_resultSet.next()).andReturn(true);
    EasyMock.expect(_resultSet.getInt(EasyMock.anyInt())).andReturn(1).anyTimes();
    EasyMock.expect(_resultSet.getLong("IDTSIM")).andReturn(95061926L); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getLong("IDTHLR")).andReturn(98L); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getString("SIM")).andReturn("8933209805139306257"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("ETASIM")).andReturn("a"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString(EasyMock.anyString())).andReturn("1").anyTimes(); //$NON-NLS-1$
    PowerMock.replay(_resultSet);

    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getObject("po_RESULT")).andReturn(_resultSet); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_IWSRESSOURCES.P_012_GetICCIDFromIMSI(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<Sim, Retour> connectorResponse = _pgIWSRessources.ps012GetICCIDFromIMSI(tracabilite, imsi);

    //  Sim sim_expected=new Sim(95061926L,98L,19372L,"a",5L,);
    Sim sim = connectorResponse._first;

    assertEquals(Long.valueOf(95061926L), sim.getIdtsim());
    assertEquals(Long.valueOf(98L), sim.getIdthlr());
    assertEquals(EtatSim.ACTIVE, sim.getEtasim());
    assertEquals("8933209805139306257", sim.getSim()); //$NON-NLS-1$

    assertEquals("OK", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(null, connectorResponse._second.getCategorie());
    assertEquals(null, connectorResponse._second.getLibelle());
    assertEquals(null, connectorResponse._second.getDiagnostic());
  }

  /**
   * Test to P_013_Update_EtatMsisdn OK
   *
   * <b>Entrées:</b>numtel = 762139204 <b>Attendu:</b>Retour=OK<br/>
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_ps013UpdateEtatMsisdn() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    Long numtel = 762139204L;
    String etatCibleMsisdn = "i"; //$NON-NLS-1$
    Integer idtAcnMsi = 24;
    String instanceCliente = "GP1"; //$NON-NLS-1$
    String idtdermod = null;

    // Setup mocks
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_IWSRESSOURCES.P_013_Update_EtatMsisdn(?,?,?,?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<Boolean, Retour> connectorResponse = _pgIWSRessources.ps013UpdateEtatMsisdn(tracabilite, numtel, etatCibleMsisdn, idtAcnMsi, instanceCliente, idtdermod);

    // Asserts
    assertEquals("OK", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(null, connectorResponse._second.getCategorie());
    assertEquals(null, connectorResponse._second.getLibelle());
    assertEquals(null, connectorResponse._second.getDiagnostic());
    assertTrue(connectorResponse._first);
  }
}
