/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.gdr;

import static com.bytel.spirit.common.connectors.gdr.structs.StatistiqueEsim.ALERTE;
import static com.bytel.spirit.common.connectors.gdr.structs.StatistiqueEsim.CODEARTICLESAP;
import static com.bytel.spirit.common.connectors.gdr.structs.StatistiqueEsim.DATECOMPTAGE;
import static com.bytel.spirit.common.connectors.gdr.structs.StatistiqueEsim.ENCARTEUR;
import static com.bytel.spirit.common.connectors.gdr.structs.StatistiqueEsim.GENCOD;
import static com.bytel.spirit.common.connectors.gdr.structs.StatistiqueEsim.PROFILELECTRIQUE;
import static com.bytel.spirit.common.connectors.gdr.structs.StatistiqueEsim.PROFILETYPE;
import static com.bytel.spirit.common.connectors.gdr.structs.StatistiqueEsim.QUANTITE;
import static com.bytel.spirit.common.connectors.gdr.structs.StatistiqueEsim.TYPECOMPTAGE;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLRecoverableException;
import java.sql.SQLTimeoutException;
import java.sql.Timestamp;
import java.text.MessageFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.tomcat.jdbc.pool.DataSource;
import org.apache.tomcat.jdbc.pool.PoolExhaustedException;
import org.easymock.Capture;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockNice;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.conf.generated.Param;
import com.bytel.ravel.common.datetime.DateTimeManager;
import com.bytel.ravel.common.encryption.DESKeyManager;
import com.bytel.ravel.common.encryption.PasswordDecrypter;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.test.JUnitTools;
import com.bytel.ravel.common.utils.DateTimeTools;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.services.conf.connector.generated.Connector;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.connectors.gdr.structs.BYTPRD;
import com.bytel.spirit.common.connectors.gdr.structs.CMDSIM;
import com.bytel.spirit.common.connectors.gdr.structs.ErreurSMDP;
import com.bytel.spirit.common.connectors.gdr.structs.HISETASIM;
import com.bytel.spirit.common.connectors.gdr.structs.PRF;
import com.bytel.spirit.common.connectors.gdr.structs.Policy;
import com.bytel.spirit.common.connectors.gdr.structs.SUIVISMDP;
import com.bytel.spirit.common.connectors.gdr.structs.Sim;
import com.bytel.spirit.common.connectors.gdr.structs.StatistiqueEsim;
import com.bytel.spirit.common.connectors.gdr.structs.enumeration.EtatSMDP;
import com.bytel.spirit.common.connectors.gdr.structs.enumeration.EtatSim;
import com.bytel.spirit.common.connectors.gdr.structs.enumeration.PolicyAction;
import com.bytel.spirit.common.connectors.gdr.structs.enumeration.PolicyQualification;
import com.bytel.spirit.common.connectors.gdr.utils.ArrayDescriptorFactory;
import com.bytel.spirit.common.connectors.gdr.utils.GDRPGIWSRessources;
import com.bytel.spirit.common.connectors.gdr.utils.GDRPGSpirit;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

import oracle.jdbc.OracleConnection;
import oracle.sql.ARRAY;
import oracle.sql.ArrayDescriptor;

/**
 *
 * @author $Author$
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({ DESKeyManager.class, PasswordDecrypter.class, Connection.class, DataSource.class, GDRPGIWSRessources.class, ArrayDescriptorFactory.class })
@PowerMockIgnore("javax.management.*") //$NON-NLS-1$
public class GDRPGSpiritTest
{
  public static final String CONNEXION_FAILED = "CONNEXION_FAILED"; //$NON-NLS-1$
  public static final String INSERTION_FAILED = "INSERTION_FAILED"; //$NON-NLS-1$
  public static final String SESSION_UNAVAILABLE = "SESSION_UNAVAILABLE"; //$NON-NLS-1$

  @MockNice
  DataSource _datasource;

  @MockNice
  Connection _connection;

  @MockNice
  CallableStatement _callableStatement;

  @MockNice
  ResultSet _resultSet;

  @MockNice
  ArrayDescriptorFactory _arrayDescriptionFactory;

  private GDRConnector _connector;

  private GDRPGSpirit _pgSpirit;

  /**
   * @throws Exception on error.
   */
  @Before
  public void setup() throws Exception
  {
    _connector = new GDRConnector();

    Connector _connectorConfig = new Connector();
    _connectorConfig.setName("GDRConnector"); //$NON-NLS-1$
    _connectorConfig.setType("client"); //$NON-NLS-1$
    _connectorConfig.setClazz("com.bytel.ressources.services.connector.gdr.GDRConnector"); //$NON-NLS-1$
    _connectorConfig.setEnabled(true);
    Param dbConnectionString = new Param();
    Param dbUsername = new Param();
    Param dbPassword = new Param();
    Param poolSize = new Param();
    Param connectTimeoutSec = new Param();
    Param readTimeoutSec = new Param();

    dbConnectionString.setName("DB_CONNECTIONSTRING"); //$NON-NLS-1$
    dbConnectionString.setValue("jdbc:oracle:thin:@172.22.76.129:1531:PPR0N1D2"); //$NON-NLS-1$
    dbUsername.setName("DB_USERNAME"); //$NON-NLS-1$
    dbUsername.setValue("DEV19GDR"); //$NON-NLS-1$
    dbPassword.setName("DB_PASSWORD"); //$NON-NLS-1$
    dbPassword.setValue("0l7HRwWTfUwgsoOMyJ3uHw=="); //$NON-NLS-1$
    poolSize.setName("POOLSIZE"); //$NON-NLS-1$
    poolSize.setValue("15"); //$NON-NLS-1$
    connectTimeoutSec.setName("CONNECT_TIMEOUT_SEC"); //$NON-NLS-1$
    connectTimeoutSec.setValue("4"); //$NON-NLS-1$
    readTimeoutSec.setName("READ_TIMEOUT_SEC"); //$NON-NLS-1$
    readTimeoutSec.setValue("1"); //$NON-NLS-1$

    _connectorConfig.getParam().add(dbConnectionString);
    _connectorConfig.getParam().add(dbUsername);
    _connectorConfig.getParam().add(dbPassword);
    _connectorConfig.getParam().add(poolSize);
    _connectorConfig.getParam().add(connectTimeoutSec);
    _connectorConfig.getParam().add(readTimeoutSec);

    PowerMock.resetAll();
    PowerMock.mockStaticNice(PasswordDecrypter.class);
    PowerMock.mockStaticNice(DESKeyManager.class);

    // Load config
    _connector.loadConnectorConfiguration(_connectorConfig);
    JUnitTools.setInaccessibleFieldValue(_connector, "_datasource", _datasource); //$NON-NLS-1$

    // Setup connection mock
    EasyMock.expect(_datasource.getConnection()).andReturn(_connection).anyTimes();
    PowerMock.replay(_datasource);

    _pgSpirit = new GDRPGSpirit(_datasource, 1, 4, _arrayDescriptionFactory);
  }

  /**
   * Test to compterEtatESim Fail with SQLException.
   *
   * @throws Exception
   *           in case of error
   */
  @Test
  public void test_compterEtatESimFail_001() throws Exception
  {
    List<Integer> peConsumer = Arrays.asList(1, 2, 3);
    List<Integer> peM2M = Arrays.asList(4, 5, 6);
    Tracabilite tracabilite = new Tracabilite();

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_COMPTERETATESIM(?,?,?,?,?,?) }")).andThrow(new SQLException()); //$NON-NLS-1$
    PowerMock.replay(_connection);

    ConnectorResponse<Nothing, Retour> connectorResponse = new ConnectorResponse<>(null, null);
    try
    {
      connectorResponse = _pgSpirit.compterEtatESim(tracabilite, peConsumer, peM2M);
    }
    catch (Exception ex)
    {
      assertEquals(null, connectorResponse._second);
      String errorMessage = "Technical Exception in GDRConnector during PG_SPIRIT.P_COMPTERETATESIM call: code(0) reason(null) at GDRPGSpirit.java"; //$NON-NLS-1$
      assertTrue(ex.getMessage().contains(errorMessage));
    }
  }

  /**
   * Test to compterEtatESim Fail with SQLTimeoutException.
   *
   * @throws Exception
   *           in case of error
   */
  @Test
  public void test_compterEtatESimFail_002() throws Exception
  {
    List<Integer> peConsumer = Arrays.asList(1, 2, 3);
    List<Integer> peM2M = Arrays.asList(4, 5, 6);
    Tracabilite tracabilite = new Tracabilite();

    Retour retourExpected = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_SUR_NON_REPONSE"), 1)); //$NON-NLS-1$

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_COMPTERETATESIM(?,?,?,?,?,?) }")).andThrow(new SQLTimeoutException()); //$NON-NLS-1$
    PowerMock.replay(_connection);

    ConnectorResponse<Nothing, Retour> connectorResponse = new ConnectorResponse<>(null, null);
    try
    {
      connectorResponse = _pgSpirit.compterEtatESim(tracabilite, peConsumer, peM2M);
    }
    catch (Exception ex)
    {
      assertEquals(retourExpected, connectorResponse._second);
      String errorMessage = "Technical Exception in GDRConnector during PG_SPIRIT.P_COMPTERETATESIM call: code(0) reason(null) at GDRPGSpirit.java"; //$NON-NLS-1$
      assertTrue(ex.getMessage().contains(errorMessage));
    }
  }

  /**
   * Test to compterEtatESim Fail with PoolExhaustedException.
   *
   * @throws Exception
   *           in case of error
   */
  @Test
  public void test_compterEtatESimFail_003() throws Exception
  {
    List<Integer> peConsumer = Arrays.asList(1, 2, 3);
    List<Integer> peM2M = Arrays.asList(4, 5, 6);
    Tracabilite tracabilite = new Tracabilite();

    Retour retourExpected = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("GDRConnector.ERREUR_GDR_AUCUNE_SESSION")); //$NON-NLS-1$

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_COMPTERETATESIM(?,?,?,?,?,?) }")).andThrow(new PoolExhaustedException()); //$NON-NLS-1$
    PowerMock.replay(_connection);

    ConnectorResponse<Nothing, Retour> connectorResponse = new ConnectorResponse<>(null, null);
    try
    {
      connectorResponse = _pgSpirit.compterEtatESim(tracabilite, peConsumer, peM2M);
    }
    catch (Exception ex)
    {
      assertEquals(retourExpected, connectorResponse._second);
      String errorMessage = "Technical Exception in GDRConnector during PG_SPIRIT.P_COMPTERETATESIM call: code(0) reason(null) at GDRPGSpirit.java"; //$NON-NLS-1$
      assertTrue(ex.getMessage().contains(errorMessage));
    }
  }

  /**
   * Test to compterEtatESim Fail with SQLRecoverableException.
   *
   * @throws Exception
   *           in case of error
   */
  @Test
  public void test_compterEtatESimFail_004() throws Exception
  {
    List<Integer> peConsumer = Arrays.asList(1, 2, 3);
    List<Integer> peM2M = Arrays.asList(4, 5, 6);
    Tracabilite tracabilite = new Tracabilite();

    Retour retourExpected = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("GDRConnector.ERREUR_GDR_AUCUNE_SESSION")); //$NON-NLS-1$

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_COMPTERETATESIM(?,?,?,?,?,?) }")).andThrow(new SQLRecoverableException()); //$NON-NLS-1$
    PowerMock.replay(_connection);

    ConnectorResponse<Nothing, Retour> connectorResponse = new ConnectorResponse<>(null, null);
    try
    {
      connectorResponse = _pgSpirit.compterEtatESim(tracabilite, peConsumer, peM2M);
    }
    catch (Exception ex)
    {
      assertEquals(retourExpected, connectorResponse._second);
      String errorMessage = "Technical Exception in GDRConnector during PG_SPIRIT.P_COMPTERETATESIM call: code(0) reason(null) at GDRPGSpirit.java"; //$NON-NLS-1$
      assertTrue(ex.getMessage().contains(errorMessage));
    }
  }

  /**
   * Test to compterEtatESim OK.
   *
   * @throws Exception
   *           in case of error
   */
  @Test
  public void test_compterEtatESimOK() throws Exception
  {
    List<Integer> peConsumer = Arrays.asList(1, 2, 3);
    List<Integer> peM2M = Arrays.asList(4, 5, 6);
    Tracabilite tracabilite = new Tracabilite();

    // Setup mocks
    OracleConnection oracleConnection = EasyMock.createMock(OracleConnection.class);
    ArrayDescriptor arrayDescriptor = EasyMock.createMock(ArrayDescriptor.class);
    ARRAY array = EasyMock.createMock(ARRAY.class);

    EasyMock.expect(_connection.unwrap(OracleConnection.class)).andReturn(oracleConnection).times(4);
    EasyMock.replay(oracleConnection);

    EasyMock.expect(_arrayDescriptionFactory.makeArrayDescriptor(EasyMock.eq("TABLE_NUMBER"), EasyMock.eq(oracleConnection))).andReturn(arrayDescriptor); //$NON-NLS-1$
    EasyMock.expect(_arrayDescriptionFactory.createARRAY(EasyMock.eq(arrayDescriptor), EasyMock.eq(oracleConnection), EasyMock.eq(peConsumer.toArray()))).andReturn(array);
    EasyMock.expect(_arrayDescriptionFactory.createARRAY(EasyMock.eq(arrayDescriptor), EasyMock.eq(oracleConnection), EasyMock.eq(peM2M.toArray()))).andReturn(array);

    EasyMock.replay(_arrayDescriptionFactory);
    EasyMock.replay(arrayDescriptor);

    _callableStatement.setObject(EasyMock.eq("pi_GencodPE_Consumer"), EasyMock.eq(ARRAY.class)); //$NON-NLS-1$
    _callableStatement.setObject(EasyMock.eq("pi_GencodPE_M2M"), EasyMock.eq(ARRAY.class)); //$NON-NLS-1$

    EasyMock.expectLastCall();
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_COMPTERETATESIM(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    ConnectorResponse<Nothing, Retour> connectorResponse = _pgSpirit.compterEtatESim(tracabilite, peConsumer, peM2M);

    // Asserts
    assertEquals(RetourFactory.createOkRetour(), connectorResponse._second);
  }

  /**
   * Test KO of getErreurSmdpByIccid
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_getErreurSmdpByIccid_KO_001() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String iccid = "iccid"; //$NON-NLS-1$

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_ERREURSMDP_BY_ICCID(?,?,?,?,?,?) }")).andThrow(new SQLTimeoutException()); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<List<ErreurSMDP>, Retour> connectorResponse = _pgSpirit.getErreurSmdpByIccid(tracabilite, iccid);

    // Asserts
    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, connectorResponse._second.getCategorie());
    assertEquals(MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_SUR_NON_REPONSE"), 1), connectorResponse._second.getLibelle()); //$NON-NLS-1$
    assertEquals(INSERTION_FAILED, connectorResponse._second.getDiagnostic());

  }

  /**
   * Test KO of getErreurSmdpByIccid
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_getErreurSmdpByIccid_KO_002() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String iccid = "iccid"; //$NON-NLS-1$

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_ERREURSMDP_BY_ICCID(?,?,?,?,?,?) }")).andThrow(new PoolExhaustedException()); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<List<ErreurSMDP>, Retour> connectorResponse = _pgSpirit.getErreurSmdpByIccid(tracabilite, iccid);

    // Asserts
    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, connectorResponse._second.getCategorie());
    assertEquals(Messages.getString("GDRConnector.ERREUR_GDR_AUCUNE_SESSION"), connectorResponse._second.getLibelle()); //$NON-NLS-1$
    assertEquals(SESSION_UNAVAILABLE, connectorResponse._second.getDiagnostic());

  }

  /**
   * Test KO of getErreurSmdpByIccid
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_getErreurSmdpByIccid_KO_003() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String iccid = "iccid"; //$NON-NLS-1$

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_ERREURSMDP_BY_ICCID(?,?,?,?,?,?) }")).andThrow(new SQLRecoverableException()); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<List<ErreurSMDP>, Retour> connectorResponse = _pgSpirit.getErreurSmdpByIccid(tracabilite, iccid);

    // Asserts
    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, connectorResponse._second.getCategorie());
    assertEquals(MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_CONNEXION"), 4), connectorResponse._second.getLibelle()); //$NON-NLS-1$
    assertEquals(CONNEXION_FAILED, connectorResponse._second.getDiagnostic());

  }

  /**
   * Test KO of getErreurSmdpByIccid
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test(expected = RavelException.class)
  public void test_getErreurSmdpByIccid_KO_004() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String iccid = "iccid"; //$NON-NLS-1$

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_ERREURSMDP_BY_ICCID(?,?,?,?,?,?) }")).andThrow(new SQLException()); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    _pgSpirit.getErreurSmdpByIccid(tracabilite, iccid);

  }

  /**
   * Test KO of getErreurSmdpByIccid
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_getErreurSmdpByIccid_KO_005() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String iccid = "iccid"; //$NON-NLS-1$

    // Setup mocks
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.KO); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_ERREURSMDP_BY_ICCID(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<List<ErreurSMDP>, Retour> connectorResponse = _pgSpirit.getErreurSmdpByIccid(tracabilite, iccid);

    // Asserts
    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertNull(connectorResponse._second.getCategorie());
    assertNull(connectorResponse._second.getLibelle());
    assertNull(connectorResponse._second.getDiagnostic());

  }

  /**
   * Test OK of getErreurSmdpByIccid
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_getErreurSmdpByIccid_OK() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String iccid = "iccid"; //$NON-NLS-1$
    Timestamp dateta = new Timestamp(new Date().getTime());

    // Setup mocks
    EasyMock.expect(_resultSet.next()).andReturn(true).andReturn(true).andReturn(false);
    EasyMock.expect(_resultSet.getString("REQUEST_ID")).andReturn("REQUEST_ID").times(2); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("ICCID")).andReturn(iccid).times(2); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getString("ETAT_ERREUR")).andReturn("ETAT_ERREUR").times(2); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getTimestamp("DAT")).andReturn(dateta).times(2); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getString("IDTDERMOD")).andReturn("IDTDERMOD").times(2); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("ETAT_REQUETE")).andReturn("ETAT_REQUETE").times(2); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("ENTITE_ERREUR")).andReturn("ENTITE_ERREUR").times(2); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("RAISON_ERREUR")).andReturn("RAISON_ERREUR").times(2); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("LIBELLE_ERREUR")).andReturn("LIBELLE_ERREUR").times(2); //$NON-NLS-1$ //$NON-NLS-2$

    PowerMock.replay(_resultSet);

    // Setup mocks
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getObject("po_RESULT")).andReturn(_resultSet); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_ERREURSMDP_BY_ICCID(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<List<ErreurSMDP>, Retour> connectorResponse = _pgSpirit.getErreurSmdpByIccid(tracabilite, iccid);
    ErreurSMDP erreurSMDP1 = new ErreurSMDP("REQUEST_ID_1", iccid, "ETAT_ERREUR", DateTimeTools.toLocalDateTime(dateta), "IDTDERMOD", "ETAT_REQUETE", "ENTITE_ERREUR", "RAISON_ERREUR", "LIBELLE_ERREUR"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$
    ErreurSMDP erreurSMDP2 = new ErreurSMDP("REQUEST_ID_2", iccid, "ETAT_ERREUR", DateTimeTools.toLocalDateTime(dateta), "IDTDERMOD", "ETAT_REQUETE", "ENTITE_ERREUR", "RAISON_ERREUR", "LIBELLE_ERREUR"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$

    List<ErreurSMDP> expectedErreurSMDPList = new ArrayList<>(Arrays.asList(erreurSMDP1, erreurSMDP2));

    // Asserts
    assertEquals("OK", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(expectedErreurSMDPList.size(), connectorResponse._first.size());
    assertEquals(expectedErreurSMDPList.get(1).getIccid(), connectorResponse._first.get(1).getIccid());

  }

  /**
   * Test KO of getHisetaSimByIdtSim
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_getHisetaSimByIdtSim_KO_001() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String idtSim = "idtSim"; //$NON-NLS-1$

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_HISETASIM_BY_IDTSIM(?,?,?,?,?,?) }")).andThrow(new SQLTimeoutException()); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<List<HISETASIM>, Retour> connectorResponse = _pgSpirit.getHisetaSimByIdtSim(tracabilite, idtSim);

    // Asserts
    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, connectorResponse._second.getCategorie());
    assertEquals(MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_SUR_NON_REPONSE"), 1), connectorResponse._second.getLibelle()); //$NON-NLS-1$
    assertEquals(INSERTION_FAILED, connectorResponse._second.getDiagnostic());

  }

  /**
   * Test KO of getHisetaSimByIdtSim
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_getHisetaSimByIdtSim_KO_002() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String idtSim = "idtSim"; //$NON-NLS-1$

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_HISETASIM_BY_IDTSIM(?,?,?,?,?,?) }")).andThrow(new PoolExhaustedException()); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<List<HISETASIM>, Retour> connectorResponse = _pgSpirit.getHisetaSimByIdtSim(tracabilite, idtSim);

    // Asserts
    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, connectorResponse._second.getCategorie());
    assertEquals(Messages.getString("GDRConnector.ERREUR_GDR_AUCUNE_SESSION"), connectorResponse._second.getLibelle()); //$NON-NLS-1$
    assertEquals(SESSION_UNAVAILABLE, connectorResponse._second.getDiagnostic());

  }

  /**
   * Test KO of getHisetaSimByIdtSim
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_getHisetaSimByIdtSim_KO_003() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String idtSim = "idtSim"; //$NON-NLS-1$

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_HISETASIM_BY_IDTSIM(?,?,?,?,?,?) }")).andThrow(new SQLRecoverableException()); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<List<HISETASIM>, Retour> connectorResponse = _pgSpirit.getHisetaSimByIdtSim(tracabilite, idtSim);

    // Asserts
    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, connectorResponse._second.getCategorie());
    assertEquals(MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_CONNEXION"), 4), connectorResponse._second.getLibelle()); //$NON-NLS-1$
    assertEquals(CONNEXION_FAILED, connectorResponse._second.getDiagnostic());

  }

  /**
   * Test KO of getHisetaSimByIdtSim
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test(expected = RavelException.class)
  public void test_getHisetaSimByIdtSim_KO_004() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String idtSim = "idtSim"; //$NON-NLS-1$

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_HISETASIM_BY_IDTSIM(?,?,?,?,?,?) }")).andThrow(new SQLException()); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    _pgSpirit.getHisetaSimByIdtSim(tracabilite, idtSim);

  }

  /**
   * Test KO of getHisetaSimByIdtSim
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_getHisetaSimByIdtSim_KO_005() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String idtSim = "idtSim"; //$NON-NLS-1$

    // Setup mocks
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.KO); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_HISETASIM_BY_IDTSIM(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<List<HISETASIM>, Retour> connectorResponse = _pgSpirit.getHisetaSimByIdtSim(tracabilite, idtSim);

    // Asserts
    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertNull(connectorResponse._second.getCategorie());
    assertNull(connectorResponse._second.getLibelle());
    assertNull(connectorResponse._second.getDiagnostic());

  }

  /**
   * Test OK of getHisetaSimByIdtSim
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_getHisetaSimByIdtSim_OK() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String idtSim = "idtSim"; //$NON-NLS-1$
    Calendar cal = Calendar.getInstance();
    cal.set(Calendar.YEAR, 2019);
    cal.set(Calendar.MONTH, Calendar.SEPTEMBER);
    cal.set(Calendar.DAY_OF_MONTH, 10);
    Date dat = cal.getTime();
    Timestamp datEta2 = new Timestamp(dat.getTime());
    cal.set(Calendar.DAY_OF_MONTH, 9);
    dat = cal.getTime();
    Timestamp datEta1 = new Timestamp(dat.getTime());
    cal.set(Calendar.DAY_OF_MONTH, 11);
    dat = cal.getTime();
    Timestamp datEta3 = new Timestamp(dat.getTime());

    // Setup mocks
    EasyMock.expect(_resultSet.next()).andReturn(true).andReturn(true).andReturn(true).andReturn(false);
    EasyMock.expect(_resultSet.getString("IDTSIM")).andReturn(idtSim).times(3); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getLong("IDTACNSIM")).andReturn(1L).times(3); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getString("ETASIM")).andReturn("ETASIM").times(3); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("IDTIST")).andReturn("IDTIST").times(3); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getTimestamp("DAT")).andReturn(datEta2); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getTimestamp("DAT")).andReturn(datEta1); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getTimestamp("DAT")).andReturn(datEta3); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getString("ETASMDP")).andReturn("ENABLE").times(3); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("ETANOTIF")).andReturn("ETANOTIF").times(3); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("POLICYETAT")).andReturn("ENABLE").times(3); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("POLICYHABILITATION")).andReturn("AUTO_DELETE").times(3); //$NON-NLS-1$ //$NON-NLS-2$

    PowerMock.replay(_resultSet);

    // Setup mocks
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getObject("po_RESULT")).andReturn(_resultSet); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_HISETASIM_BY_IDTSIM(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<List<HISETASIM>, Retour> connectorResponse = _pgSpirit.getHisetaSimByIdtSim(tracabilite, idtSim);
    HISETASIM hisetasim1 = new HISETASIM(idtSim, 1L, "ETASIM", "IDTIST", DateTimeTools.toLocalDateTime(datEta3), EtatSMDP.fromString("ENABLE"), "ETANOTIF", PolicyAction.fromString("ENABLE"), PolicyQualification.fromString("AUTO_DELETE")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    HISETASIM hisetasim2 = new HISETASIM(idtSim, 1L, "ETASIM", "IDTIST", DateTimeTools.toLocalDateTime(datEta2), EtatSMDP.fromString("ENABLE"), "ETANOTIF", PolicyAction.fromString("ENABLE"), PolicyQualification.fromString("AUTO_DELETE")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    HISETASIM hisetasim3 = new HISETASIM(idtSim, 1L, "ETASIM", "IDTIST", DateTimeTools.toLocalDateTime(datEta1), EtatSMDP.fromString("ENABLE"), "ETANOTIF", PolicyAction.fromString("ENABLE"), PolicyQualification.fromString("AUTO_DELETE")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$

    List<HISETASIM> expectedHisetatsimList = new ArrayList<>(Arrays.asList(hisetasim1, hisetasim2, hisetasim3));

    // Asserts
    assertEquals("OK", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(expectedHisetatsimList.size(), connectorResponse._first.size());
    assertEquals(expectedHisetatsimList.get(1).getIdtSim(), connectorResponse._first.get(1).getIdtSim());
    //assert the sorting by date
    assertEquals(expectedHisetatsimList.get(2).getDateChangementEtatPlateforme(), connectorResponse._first.get(0).getDateChangementEtatPlateforme());
    assertEquals(expectedHisetatsimList.get(1).getDateChangementEtatPlateforme(), connectorResponse._first.get(1).getDateChangementEtatPlateforme());
    assertEquals(expectedHisetatsimList.get(0).getDateChangementEtatPlateforme(), connectorResponse._first.get(2).getDateChangementEtatPlateforme());
  }

  /**
   * Test to getInstanceClienteSim KO
   *
   *
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_getInstanceClienteSim_KO_001() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String idtsim = "idtsim"; //$NON-NLS-1$

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_INSTANCECLIENTE_SIM(?,?,?,?,?,?) }")).andThrow(new SQLTimeoutException()); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<String, Retour> connectorResponse = _pgSpirit.getInstanceClienteSim(tracabilite, idtsim);

    // Asserts
    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, connectorResponse._second.getCategorie());
    assertEquals(MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_SUR_NON_REPONSE"), 1), connectorResponse._second.getLibelle()); //$NON-NLS-1$
    assertEquals(INSERTION_FAILED, connectorResponse._second.getDiagnostic());

  }

  /**
   * Test to getInstanceClienteSim KO
   *
   *
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_getInstanceClienteSim_KO_002() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String idtsim = "idtsim"; //$NON-NLS-1$

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_INSTANCECLIENTE_SIM(?,?,?,?,?,?) }")).andThrow(new PoolExhaustedException()); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<String, Retour> connectorResponse = _pgSpirit.getInstanceClienteSim(tracabilite, idtsim);

    // Asserts
    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, connectorResponse._second.getCategorie());
    assertEquals(Messages.getString("GDRConnector.ERREUR_GDR_AUCUNE_SESSION"), connectorResponse._second.getLibelle()); //$NON-NLS-1$
    assertEquals(SESSION_UNAVAILABLE, connectorResponse._second.getDiagnostic());

  }

  /**
   * Test to getInstanceClienteSim KO
   *
   *
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_getInstanceClienteSim_KO_003() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String idtsim = "idtsim"; //$NON-NLS-1$

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_INSTANCECLIENTE_SIM(?,?,?,?,?,?) }")).andThrow(new SQLRecoverableException()); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<String, Retour> connectorResponse = _pgSpirit.getInstanceClienteSim(tracabilite, idtsim);

    // Asserts
    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, connectorResponse._second.getCategorie());
    assertEquals(MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_CONNEXION"), 4), connectorResponse._second.getLibelle()); //$NON-NLS-1$
    assertEquals(CONNEXION_FAILED, connectorResponse._second.getDiagnostic());

  }

  /**
   * Test to getInstanceClienteSim KO
   *
   *
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test(expected = RavelException.class)
  public void test_getInstanceClienteSim_KO_004() throws Exception
  {// Request
    Tracabilite tracabilite = new Tracabilite();
    String idtsim = "idtsim"; //$NON-NLS-1$

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_INSTANCECLIENTE_SIM(?,?,?,?,?,?) }")).andThrow(new SQLException()); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    _pgSpirit.getInstanceClienteSim(tracabilite, idtsim);

  }

  /**
   * Test to getInstanceClienteSim KO
   *
   *
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_getInstanceClienteSim_KO_005() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String idtsim = "idtsim"; //$NON-NLS-1$

    // Setup mocks
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.KO); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_INSTANCECLIENTE_SIM(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<String, Retour> connectorResponse = _pgSpirit.getInstanceClienteSim(tracabilite, idtsim);

    // Asserts
    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertNull(connectorResponse._second.getCategorie());
    assertNull(connectorResponse._second.getLibelle());
    assertNull(connectorResponse._second.getDiagnostic());

  }

  /**
   * Test to getInstanceClienteSim OK
   *
   *
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_getInstanceClienteSim_OK() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String idtsim = "idtsim"; //$NON-NLS-1$

    // Setup mocks

    // Setup mocks
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString("po_idtist")).andReturn("IDTIST"); //$NON-NLS-1$ //$NON-NLS-2$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_INSTANCECLIENTE_SIM(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<String, Retour> connectorResponse = _pgSpirit.getInstanceClienteSim(tracabilite, idtsim);

    // Asserts
    assertEquals("OK", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals("IDTIST", connectorResponse._first); //$NON-NLS-1$

  }

  /**
   * Test to getPRFByIdtPrf KO
   *
   *
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_getPRFByIdtPrf_KO_001() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String idtprf = "idtprf"; //$NON-NLS-1$

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_PRF_BY_IDTPRF(?,?,?,?,?,?) }")).andThrow(new SQLTimeoutException()); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<PRF, Retour> connectorResponse = _pgSpirit.getPRFByIdtPrf(tracabilite, idtprf);

    // Asserts
    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, connectorResponse._second.getCategorie());
    assertEquals(MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_SUR_NON_REPONSE"), 1), connectorResponse._second.getLibelle()); //$NON-NLS-1$
    assertEquals(INSERTION_FAILED, connectorResponse._second.getDiagnostic());

  }

  /**
   * Test to getPRFByIdtPrf KO
   *
   *
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_getPRFByIdtPrf_KO_002() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String idtprf = "idtprf"; //$NON-NLS-1$

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_PRF_BY_IDTPRF(?,?,?,?,?,?) }")).andThrow(new PoolExhaustedException()); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<PRF, Retour> connectorResponse = _pgSpirit.getPRFByIdtPrf(tracabilite, idtprf);

    // Asserts
    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, connectorResponse._second.getCategorie());
    assertEquals(Messages.getString("GDRConnector.ERREUR_GDR_AUCUNE_SESSION"), connectorResponse._second.getLibelle()); //$NON-NLS-1$
    assertEquals(SESSION_UNAVAILABLE, connectorResponse._second.getDiagnostic());

  }

  /**
   * Test to getPRFByIdtPrf KO
   *
   *
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_getPRFByIdtPrf_KO_003() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String idtprf = "idtprf"; //$NON-NLS-1$

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_PRF_BY_IDTPRF(?,?,?,?,?,?) }")).andThrow(new SQLRecoverableException()); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<PRF, Retour> connectorResponse = _pgSpirit.getPRFByIdtPrf(tracabilite, idtprf);

    // Asserts
    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, connectorResponse._second.getCategorie());
    assertEquals(MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_CONNEXION"), 4), connectorResponse._second.getLibelle()); //$NON-NLS-1$
    assertEquals(CONNEXION_FAILED, connectorResponse._second.getDiagnostic());

  }

  /**
   * Test to getPRFByIdtPrf KO
   *
   *
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test(expected = RavelException.class)
  public void test_getPRFByIdtPrf_KO_004() throws Exception
  {// Request
    Tracabilite tracabilite = new Tracabilite();
    String idtprf = "idtprf"; //$NON-NLS-1$

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_PRF_BY_IDTPRF(?,?,?,?,?,?) }")).andThrow(new SQLException()); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    _pgSpirit.getPRFByIdtPrf(tracabilite, idtprf);

  }

  /**
   * Test to getPRFByIdtPrf KO
   *
   *
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_getPRFByIdtPrf_KO_005() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String idtprf = "idtprf"; //$NON-NLS-1$

    // Setup mocks
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.KO); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_PRF_BY_IDTPRF(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<PRF, Retour> connectorResponse = _pgSpirit.getPRFByIdtPrf(tracabilite, idtprf);

    // Asserts
    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertNull(connectorResponse._second.getCategorie());
    assertNull(connectorResponse._second.getLibelle());
    assertNull(connectorResponse._second.getDiagnostic());

  }

  /**
   * Test to getPRFByIdtPrf OK
   *
   *
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_getPRFByIdtPrf_OK() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String idtprf = "idtprf"; //$NON-NLS-1$

    Long currentTime = System.currentTimeMillis();

    // Setup mocks
    EasyMock.expect(_resultSet.next()).andReturn(true);
    EasyMock.expect(_resultSet.getLong("IDTPRF")).andReturn(123L); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getString("PROFILETYPE")).andReturn("PROFILETYPE"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("TYPPRF")).andReturn("TYPPRF"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("REFPRF")).andReturn("REFPRF"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("RELPRF")).andReturn("RELPRF"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getLong("ALGAUT")).andReturn(0L); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getString("TYPRES")).andReturn("TYPRES"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("IDTRES")).andReturn("2G"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getTimestamp("DATFINVAL")).andReturn(new Timestamp(currentTime)); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getLong("SEUIL")).andReturn(123L); //$NON-NLS-1$

    PowerMock.replay(_resultSet);

    // Setup mocks
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getObject("po_RESULT")).andReturn(_resultSet); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_PRF_BY_IDTPRF(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<PRF, Retour> connectorResponse = _pgSpirit.getPRFByIdtPrf(tracabilite, idtprf);

    PRF prf = new PRF(123L, "PROFILETYPE", "TYPPRF", "REFPRF", "RELPRF", 0L, "TYPRES", "2G", new Date(currentTime), 123L); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$

    // Asserts
    assertEquals("OK", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(prf, connectorResponse._first);
    assertEquals(prf.getProfilElectrique(), connectorResponse._first.getProfilElectrique());

  }

  /**
   * Test to getSimByGnc KO
   *
   *
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_getSimByGnc_KO_001() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String idtcmd = "idtcmd"; //$NON-NLS-1$

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_SIMS_BY_GNC(?,?,?,?,?,?) }")).andThrow(new SQLTimeoutException()); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<List<Sim>, Retour> connectorResponse = _pgSpirit.getSimByGnc(tracabilite, idtcmd);

    // Asserts
    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, connectorResponse._second.getCategorie());
    assertEquals(MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_SUR_NON_REPONSE"), 1), connectorResponse._second.getLibelle()); //$NON-NLS-1$
    assertEquals(INSERTION_FAILED, connectorResponse._second.getDiagnostic());

  }

  /**
   * Test to getSimByGnc KO
   *
   *
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_getSimByGnc_KO_002() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String idtcmd = "idtcmd"; //$NON-NLS-1$

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_SIMS_BY_GNC(?,?,?,?,?,?) }")).andThrow(new PoolExhaustedException()); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<List<Sim>, Retour> connectorResponse = _pgSpirit.getSimByGnc(tracabilite, idtcmd);

    // Asserts
    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, connectorResponse._second.getCategorie());
    assertEquals(Messages.getString("GDRConnector.ERREUR_GDR_AUCUNE_SESSION"), connectorResponse._second.getLibelle()); //$NON-NLS-1$
    assertEquals(SESSION_UNAVAILABLE, connectorResponse._second.getDiagnostic());

  }

  /**
   * Test to getSimByGnc KO
   *
   *
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_getSimByGnc_KO_003() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String idtcmd = "idtcmd"; //$NON-NLS-1$

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_SIMS_BY_GNC(?,?,?,?,?,?) }")).andThrow(new SQLRecoverableException()); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<List<Sim>, Retour> connectorResponse = _pgSpirit.getSimByGnc(tracabilite, idtcmd);

    // Asserts
    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, connectorResponse._second.getCategorie());
    assertEquals(MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_CONNEXION"), 4), connectorResponse._second.getLibelle()); //$NON-NLS-1$
    assertEquals(CONNEXION_FAILED, connectorResponse._second.getDiagnostic());

  }

  /**
   * Test to getSimByGnc KO
   *
   *
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test(expected = RavelException.class)
  public void test_getSimByGnc_KO_004() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String idtcmd = "idtcmd"; //$NON-NLS-1$

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_SIMS_BY_GNC(?,?,?,?,?,?) }")).andThrow(new SQLException()); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    _pgSpirit.getSimByGnc(tracabilite, idtcmd);

  }

  /**
   * Test to getSimByGnc KO
   *
   *
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_getSimByGnc_KO_005() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String idtcmd = "idtcmd"; //$NON-NLS-1$

    // Setup mocks
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.KO); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_SIMS_BY_GNC(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<List<Sim>, Retour> connectorResponse = _pgSpirit.getSimByGnc(tracabilite, idtcmd);

    // Asserts
    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertNull(connectorResponse._second.getCategorie());
    assertNull(connectorResponse._second.getLibelle());
    assertNull(connectorResponse._second.getDiagnostic());

  }

  /**
   * Test to getSimByGnc OK
   *
   *
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_getSimByGnc_OK() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String idtcmd = "idtcmd"; //$NON-NLS-1$
    Timestamp dateta = new Timestamp(new Date().getTime());
    Sim sim1 = new Sim(123L, 123L, 123L, EtatSim.DESACTIVEE, 123L, dateta, "SIM", //$NON-NLS-1$
        "IMS", //$NON-NLS-1$
        123L, 123L, 123L, 123L, "CLEKI_", //$NON-NLS-1$
        "CODADM", //$NON-NLS-1$
        123L, "ETACOM", //$NON-NLS-1$
        "ETAPRT", //$NON-NLS-1$
        "IDTDERMOD", //$NON-NLS-1$
        "CLEOTA", //$NON-NLS-1$
        null, EtatSMDP.DELETE, "ETANOTIF", //$NON-NLS-1$
        null, null, "EID", //$NON-NLS-1$
        "SMSRID", //$NON-NLS-1$
        new Policy(null, PolicyAction.DISABLE, PolicyQualification.NOT_ALLOWED), null, null);
    Sim sim2 = new Sim(123L, 123L, 123L, EtatSim.PURGEE, 123L, dateta, "SIM", //$NON-NLS-1$
        "IMS", //$NON-NLS-1$
        123L, 123L, 123L, 123L, "CLEKI_", //$NON-NLS-1$
        "CODADM", //$NON-NLS-1$
        123L, "ETACOM", //$NON-NLS-1$
        "ETAPRT", //$NON-NLS-1$
        "IDTDERMOD", //$NON-NLS-1$
        "CLEOTA", //$NON-NLS-1$
        null, EtatSMDP.DOWNLOAD_DISABLE, "", //$NON-NLS-1$
        null, null, null, null, new Policy(null, PolicyAction.ENABLE, PolicyQualification.AUTO_DELETE), null, null);

    List<Sim> expectedSimList = new ArrayList<>(Arrays.asList(sim1, sim2));
    // Setup mocks
    EasyMock.expect(_resultSet.next()).andReturn(true).andReturn(true).andReturn(false);
    EasyMock.expect(_resultSet.getLong("IDTSIM")).andReturn(123L).times(2); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getLong("IDTHLR")).andReturn(123L).times(2); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getLong("IDTCMD")).andReturn(123L).times(2); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getLong("IDTACNSIM")).andReturn(123L).times(2); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getTimestamp("DATETA")).andReturn(dateta).times(2); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getString("SIM")).andReturn("SIM").times(2); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("IMS")).andReturn("IMS").times(2); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getLong("PIN")).andReturn(123L).times(2); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getLong("PIN002")).andReturn(123L).times(2); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getLong("PUK")).andReturn(123L).times(2); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getLong("PUK002")).andReturn(123L).times(2); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getString("CLEKI_")).andReturn("CLEKI_").times(2); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("CODADM")).andReturn("CODADM").times(2); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getLong("TYPSIM")).andReturn(123L).times(2); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getString("ETACOM")).andReturn("ETACOM").times(2); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("ETAPRT")).andReturn("ETAPRT").times(2); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("IDTDERMOD")).andReturn("IDTDERMOD").times(2); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("CLEOTA")).andReturn("CLEOTA").times(2); //$NON-NLS-1$ //$NON-NLS-2$

    EasyMock.expect(_resultSet.getString("ETASIM")).andReturn("D").andReturn("M"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    EasyMock.expect(_resultSet.getString("ETASMDP")).andReturn("delete").andReturn("downloadDisable"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    EasyMock.expect(_resultSet.getString("ETANOTIF")).andReturn("ETANOTIF").andReturn(""); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    EasyMock.expect(_resultSet.getString("EID")).andReturn("EID").andReturn(null); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("POLICYETAT")).andReturn("DISABLE").andReturn("ENABLE"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    EasyMock.expect(_resultSet.getString("POLICYHABILITATION")).andReturn("Not-Allowed").andReturn("Auto-Delete"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    EasyMock.expect(_resultSet.getString("SMSRID")).andReturn("SMSRID").andReturn(null); //$NON-NLS-1$ //$NON-NLS-2$

    PowerMock.replay(_resultSet);

    // Setup mocks
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getObject("po_RESULT")).andReturn(_resultSet); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_SIMS_BY_GNC(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<List<Sim>, Retour> connectorResponse = _pgSpirit.getSimByGnc(tracabilite, idtcmd);

    // Asserts
    assertEquals("OK", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(expectedSimList.size(), connectorResponse._first.size());
    assertEquals(expectedSimList, connectorResponse._first);

  }

  /**
   * Test to getSimByIccidOrImsi KO
   *
   *
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_getSimByIccidOrImsi_KO_001() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String iccid = "iccid"; //$NON-NLS-1$
    String imsi = "imsi"; //$NON-NLS-1$

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_SIM_FROM_ICCID_IMSI(?,?,?,?,?,?,?) }")).andThrow(new SQLTimeoutException()); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<Sim, Retour> connectorResponse = _pgSpirit.getSimByIccidOrImsi(tracabilite, iccid, imsi);

    // Asserts
    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, connectorResponse._second.getCategorie());
    assertEquals(MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_SUR_NON_REPONSE"), 1), connectorResponse._second.getLibelle()); //$NON-NLS-1$
    assertEquals(INSERTION_FAILED, connectorResponse._second.getDiagnostic());

  }

  /**
   * Test to getSimByIccidOrImsi KO
   *
   *
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_getSimByIccidOrImsi_KO_002() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String iccid = "iccid"; //$NON-NLS-1$
    String imsi = "imsi"; //$NON-NLS-1$

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_SIM_FROM_ICCID_IMSI(?,?,?,?,?,?,?) }")).andThrow(new PoolExhaustedException()); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<Sim, Retour> connectorResponse = _pgSpirit.getSimByIccidOrImsi(tracabilite, iccid, imsi);

    // Asserts
    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, connectorResponse._second.getCategorie());
    assertEquals(Messages.getString("GDRConnector.ERREUR_GDR_AUCUNE_SESSION"), connectorResponse._second.getLibelle()); //$NON-NLS-1$
    assertEquals(SESSION_UNAVAILABLE, connectorResponse._second.getDiagnostic());

  }

  /**
   * Test to getSimByIccidOrImsi KO
   *
   *
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_getSimByIccidOrImsi_KO_003() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String iccid = "iccid"; //$NON-NLS-1$
    String imsi = "imsi"; //$NON-NLS-1$

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_SIM_FROM_ICCID_IMSI(?,?,?,?,?,?,?) }")).andThrow(new SQLRecoverableException()); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<Sim, Retour> connectorResponse = _pgSpirit.getSimByIccidOrImsi(tracabilite, iccid, imsi);

    // Asserts
    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, connectorResponse._second.getCategorie());
    assertEquals(MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_CONNEXION"), 4), connectorResponse._second.getLibelle()); //$NON-NLS-1$
    assertEquals(CONNEXION_FAILED, connectorResponse._second.getDiagnostic());

  }

  /**
   * Test to getSimByIccidOrImsi KO
   *
   *
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test(expected = RavelException.class)
  public void test_getSimByIccidOrImsi_KO_004() throws Exception
  {// Request
    Tracabilite tracabilite = new Tracabilite();
    String iccid = "iccid"; //$NON-NLS-1$
    String imsi = "imsi"; //$NON-NLS-1$

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_SIM_FROM_ICCID_IMSI(?,?,?,?,?,?,?) }")).andThrow(new SQLException()); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    _pgSpirit.getSimByIccidOrImsi(tracabilite, iccid, imsi);

  }

  /**
   * Test to getSimByIccidOrImsi KO
   *
   *
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_getSimByIccidOrImsi_KO_005() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String iccid = "iccid"; //$NON-NLS-1$
    String imsi = "imsi"; //$NON-NLS-1$

    // Setup mocks
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.KO); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_SIM_FROM_ICCID_IMSI(?,?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<Sim, Retour> connectorResponse = _pgSpirit.getSimByIccidOrImsi(tracabilite, iccid, imsi);

    // Asserts
    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertNull(connectorResponse._second.getCategorie());
    assertNull(connectorResponse._second.getLibelle());
    assertNull(connectorResponse._second.getDiagnostic());

  }

  /**
   * Test to getSimByIccidOrImsi OK
   *
   *
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_getSimByIccidOrImsi_OK() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String iccid = "iccid"; //$NON-NLS-1$
    String imsi = "imsi"; //$NON-NLS-1$
    Timestamp dateta = new Timestamp(new Date().getTime());
    Sim sim = new Sim(123L, 123L, 123L, EtatSim.DESACTIVEE, 123L, dateta, "SIM", //$NON-NLS-1$
        "IMS", //$NON-NLS-1$
        123L, 123L, 123L, 123L, "CLEKI_", //$NON-NLS-1$
        "CODADM", //$NON-NLS-1$
        123L, "ETACOM", //$NON-NLS-1$
        "ETAPRT", //$NON-NLS-1$
        "IDTDERMOD", //$NON-NLS-1$
        "CLEOTA", //$NON-NLS-1$
        null, EtatSMDP.DELETE, "ETANOTIF", //$NON-NLS-1$
        null, null, "EID", //$NON-NLS-1$
        null, new Policy(null, PolicyAction.DISABLE, PolicyQualification.NOT_ALLOWED), null, null);

    // Setup mocks
    EasyMock.expect(_resultSet.next()).andReturn(true).andReturn(true);
    EasyMock.expect(_resultSet.getLong("IDTSIM")).andReturn(123L); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getLong("IDTHLR")).andReturn(123L); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getLong("IDTCMD")).andReturn(123L); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getLong("IDTACNSIM")).andReturn(123L); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getTimestamp("DATETA")).andReturn(dateta); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getString("SIM")).andReturn("SIM"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("IMS")).andReturn("IMS"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getLong("PIN")).andReturn(123L); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getLong("PIN002")).andReturn(123L); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getLong("PUK")).andReturn(123L); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getLong("PUK002")).andReturn(123L); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getString("CLEKI_")).andReturn("CLEKI_"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("CODADM")).andReturn("CODADM"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getLong("TYPSIM")).andReturn(123L); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getString("ETACOM")).andReturn("ETACOM"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("ETAPRT")).andReturn("ETAPRT"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("IDTDERMOD")).andReturn("IDTDERMOD"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("CLEOTA")).andReturn("CLEOTA"); //$NON-NLS-1$ //$NON-NLS-2$

    EasyMock.expect(_resultSet.getString("ETASIM")).andReturn("D"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("ETASMDP")).andReturn("delete"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("ETANOTIF")).andReturn("ETANOTIF"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("EID")).andReturn("EID"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("POLICYETAT")).andReturn("DISABLE"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("POLICYHABILITATION")).andReturn("Not-Allowed"); //$NON-NLS-1$ //$NON-NLS-2$

    PowerMock.replay(_resultSet);

    // Setup mocks
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getObject("po_RESULT")).andReturn(_resultSet); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_SIM_FROM_ICCID_IMSI(?,?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<Sim, Retour> connectorResponse = _pgSpirit.getSimByIccidOrImsi(tracabilite, iccid, imsi);

    // Asserts
    assertEquals("OK", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(sim, connectorResponse._first);

  }

  /**
   * Test to getSIMDistribuables KO
   *
   * @throws Exception
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_getSIMDistribuables_NOK_001() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    List<Integer> typeSimANotifier = Arrays.asList(1, 2, 3);
    Integer nbSimToTreat = 3;

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_SIM_DISTRIBUABLES(?,?,?,?,?,?,?) }")).andThrow(new SQLTimeoutException()); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<List<Sim>, Retour> connectorResponse = _pgSpirit.getSIMDistribuables(tracabilite, typeSimANotifier, nbSimToTreat);

    // Asserts
    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, connectorResponse._second.getCategorie());
    assertEquals(MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_SUR_NON_REPONSE"), 1), connectorResponse._second.getLibelle()); //$NON-NLS-1$
    assertEquals(INSERTION_FAILED, connectorResponse._second.getDiagnostic());

  }

  /**
   * Test to getSIMDistribuables KO
   *
   * @throws Exception
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_getSIMDistribuables_NOK_002() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    List<Integer> typeSimANotifier = Arrays.asList(1, 2, 3);
    Integer nbSimToTreat = 3;

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_SIM_DISTRIBUABLES(?,?,?,?,?,?,?) }")).andThrow(new PoolExhaustedException()); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<List<Sim>, Retour> connectorResponse = _pgSpirit.getSIMDistribuables(tracabilite, typeSimANotifier, nbSimToTreat);

    // Asserts
    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, connectorResponse._second.getCategorie());
    assertEquals(Messages.getString("GDRConnector.ERREUR_GDR_AUCUNE_SESSION"), connectorResponse._second.getLibelle()); //$NON-NLS-1$
    assertEquals(SESSION_UNAVAILABLE, connectorResponse._second.getDiagnostic());

  }

  /**
   * Test to getSIMDistribuables KO
   *
   * @throws Exception
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_getSIMDistribuables_NOK_003() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    List<Integer> typeSimANotifier = Arrays.asList(1, 2, 3);
    Integer nbSimToTreat = 3;

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_SIM_DISTRIBUABLES(?,?,?,?,?,?,?) }")).andThrow(new SQLRecoverableException()); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<List<Sim>, Retour> connectorResponse = _pgSpirit.getSIMDistribuables(tracabilite, typeSimANotifier, nbSimToTreat);

    // Asserts
    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, connectorResponse._second.getCategorie());
    assertEquals(MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_CONNEXION"), 4), connectorResponse._second.getLibelle()); //$NON-NLS-1$
    assertEquals(CONNEXION_FAILED, connectorResponse._second.getDiagnostic());

  }

  /**
   * Test to getSIMDistribuables KO
   *
   * @throws Exception
   *           On unexpected error (technical exception for instance).
   */
  @Test(expected = RavelException.class)
  public void test_getSIMDistribuables_NOK_004() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    List<Integer> typeSimANotifier = Arrays.asList(1, 2, 3);
    Integer nbSimToTreat = 3;

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_SIM_DISTRIBUABLES(?,?,?,?,?,?,?) }")).andThrow(new SQLException()); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    _pgSpirit.getSIMDistribuables(tracabilite, typeSimANotifier, nbSimToTreat);

  }

  /**
   * Test to getSIMDistribuables OK.
   *
   * @throws Exception
   *           in case of error
   */
  @Test
  public void test_getSIMDistribuables_OK() throws Exception
  {
    Tracabilite tracabilite = new Tracabilite();
    List<Integer> typeSimANotifier = Arrays.asList(1, 2, 3);
    Integer nbSimToTreat = 3;

    // Setup mocks
    OracleConnection oracleConnection = EasyMock.createMock(OracleConnection.class);
    ArrayDescriptor arrayDescriptor = EasyMock.createMock(ArrayDescriptor.class);
    ARRAY array = EasyMock.createMock(ARRAY.class);

    EasyMock.expect(_connection.unwrap(OracleConnection.class)).andReturn(oracleConnection).times(1);
    EasyMock.replay(oracleConnection);

    EasyMock.expect(_arrayDescriptionFactory.makeArrayDescriptor(EasyMock.eq("TABLE_NUMBER"), EasyMock.eq(oracleConnection))).andReturn(arrayDescriptor); //$NON-NLS-1$
    EasyMock.expect(_arrayDescriptionFactory.createARRAY(EasyMock.eq(arrayDescriptor), EasyMock.eq(oracleConnection), EasyMock.eq(typeSimANotifier.toArray()))).andReturn(array);

    EasyMock.replay(_arrayDescriptionFactory);
    EasyMock.replay(arrayDescriptor);

    _callableStatement.setObject(EasyMock.eq("pi_typeSimANotifier"), EasyMock.eq(ARRAY.class)); //$NON-NLS-1$

    EasyMock.expectLastCall();
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_SIM_DISTRIBUABLES(?,?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    ConnectorResponse<List<Sim>, Retour> connectorResponse = _pgSpirit.getSIMDistribuables(tracabilite, typeSimANotifier, nbSimToTreat);

    // Asserts
    assertEquals(RetourFactory.createOkRetour(), connectorResponse._second);
  }

  /**
   * Test to mettreAJourSIMNotifAppro NOK
   *
   * @throws Exception
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_mettreAJourSIMNotifApproNOK() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String iccid = "iccid"; //$NON-NLS-1$
    String notifAppro = "notifAppro"; //$NON-NLS-1$

    // Setup mocks
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.KO); //$NON-NLS-1$

    PowerMock.replay(_callableStatement);
    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_MAJ_SIM_NOTIFAPPRO(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<Nothing, Retour> connectorResponse = _pgSpirit.mettreAJourSIMNotifAppro(tracabilite, iccid, notifAppro);
    // Asserts
    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(null, connectorResponse._second.getCategorie());
    assertEquals(null, connectorResponse._second.getLibelle());
    assertEquals(null, connectorResponse._second.getDiagnostic());
  }

  /**
   * Test to mettreAJourSIMNotifAppro OK
   *
   * @throws Exception
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_mettreAJourSIMNotifApproOK() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String iccid = "iccid"; //$NON-NLS-1$
    String notifAppro = "notifAppro"; //$NON-NLS-1$

    // Setup mocks
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$

    PowerMock.replay(_callableStatement);
    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_MAJ_SIM_NOTIFAPPRO(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<Nothing, Retour> connectorResponse = _pgSpirit.mettreAJourSIMNotifAppro(tracabilite, iccid, notifAppro);

    // Asserts
    assertEquals("OK", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(null, connectorResponse._second.getCategorie());
    assertEquals(null, connectorResponse._second.getLibelle());
    assertEquals(null, connectorResponse._second.getDiagnostic());
  }

  /**
   * Test to ps014GetIdentifiantsCommande KO
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_ps014GetIdentifiantsCommandeKO() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String idtprfele = "idtprfele"; //$NON-NLS-1$

    // Setup mocks
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.KO); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_IDS_COMMANDE(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<List<String>, Retour> connectorResponse = _pgSpirit.ps014GetIdentifiantsCommande(tracabilite, idtprfele);

    // Asserts
    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(null, connectorResponse._second.getCategorie());
    assertEquals(null, connectorResponse._second.getLibelle());
    assertEquals(null, connectorResponse._second.getDiagnostic());
    assertEquals(0, connectorResponse._first.size());
  }

  /**
   * Test to ps014GetIdentifiantsCommande OK
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_ps014GetIdentifiantsCommandeOK() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String idtprfele = "idtprfele"; //$NON-NLS-1$

    // Setup mocks
    EasyMock.expect(_resultSet.next()).andReturn(true);
    EasyMock.expect(_resultSet.getString("IDTCMD")).andReturn("a"); //$NON-NLS-1$ //$NON-NLS-2$
    PowerMock.replay(_resultSet);

    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getObject("po_RESULT")).andReturn(_resultSet); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_IDS_COMMANDE(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<List<String>, Retour> connectorResponse = _pgSpirit.ps014GetIdentifiantsCommande(tracabilite, idtprfele);

    // Asserts
    assertEquals("OK", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(null, connectorResponse._second.getCategorie());
    assertEquals(null, connectorResponse._second.getLibelle());
    assertEquals(null, connectorResponse._second.getDiagnostic());
    assertEquals(1, connectorResponse._first.size());
  }

  /**
   * Test to ps014GetIdentifiantsCommande KO PoolExhaustedException
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_ps014GetIdentifiantsCommandePoolExhaustedException() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String idtprfele = "idtprfele"; //$NON-NLS-1$

    // Setup mocks
    EasyMock.expect(_resultSet.next()).andReturn(true);
    EasyMock.expect(_resultSet.getString("pi_IDTPRFELE")).andReturn("a"); //$NON-NLS-1$ //$NON-NLS-2$
    PowerMock.replay(_resultSet);

    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getObject("po_RESULT")).andReturn(_resultSet); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_IDS_COMMANDE(?,?,?,?,?,?) }")).andThrow(new PoolExhaustedException()); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<List<String>, Retour> connectorResponse = _pgSpirit.ps014GetIdentifiantsCommande(tracabilite, idtprfele);

    // Asserts
    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, connectorResponse._second.getCategorie());
    assertEquals("SESSION_UNAVAILABLE", connectorResponse._second.getDiagnostic()); //$NON-NLS-1$
  }

  /**
   * Test to ps014GetIdentifiantsCommande KO SQLRecoverableException
   *
   * @throws Exception on error.
   */
  @Test
  public void test_ps014GetIdentifiantsCommandeSQLRecoverableException() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String idtprfele = "idtprfele"; //$NON-NLS-1$

    // Setup mocks
    EasyMock.expect(_resultSet.next()).andReturn(true);
    EasyMock.expect(_resultSet.getString("pi_IDTPRFELE")).andReturn("a"); //$NON-NLS-1$ //$NON-NLS-2$
    PowerMock.replay(_resultSet);

    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getObject("po_RESULT")).andReturn(_resultSet); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_IDS_COMMANDE(?,?,?,?,?,?) }")).andThrow(new SQLRecoverableException()); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<List<String>, Retour> connectorResponse = _pgSpirit.ps014GetIdentifiantsCommande(tracabilite, idtprfele);

    // Asserts
    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, connectorResponse._second.getCategorie());
    assertEquals("CONNEXION_FAILED", connectorResponse._second.getDiagnostic()); //$NON-NLS-1$
  }

  /**
   * Test to ps014GetIdentifiantsCommande KO SQLTimeoutException
   *
   *
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_ps014GetIdentifiantsCommandeSQLTimeoutException() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String idtprfele = "idtprfele"; //$NON-NLS-1$

    // Setup mocks
    EasyMock.expect(_resultSet.next()).andReturn(true);
    EasyMock.expect(_resultSet.getString("pi_IDTPRFELE")).andReturn("a"); //$NON-NLS-1$ //$NON-NLS-2$
    PowerMock.replay(_resultSet);

    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getObject("po_RESULT")).andReturn(_resultSet); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_IDS_COMMANDE(?,?,?,?,?,?) }")).andThrow(new SQLTimeoutException()); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<List<String>, Retour> connectorResponse = _pgSpirit.ps014GetIdentifiantsCommande(tracabilite, idtprfele);

    // Asserts
    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, connectorResponse._second.getCategorie());
    assertEquals("INSERTION_FAILED", connectorResponse._second.getDiagnostic()); //$NON-NLS-1$
  }

  /**
   * Test to ps015GetProfileType KO
   *
   *
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_ps015GetProfileTypeKO() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String idtprf = "idtprf"; //$NON-NLS-1$

    // Setup mocks
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.KO); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString("PROFILETYPE")).andReturn("a"); //$NON-NLS-1$ //$NON-NLS-2$
    PowerMock.replay(_callableStatement);
    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_PROFILETYPE(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<String, Retour> connectorResponse = _pgSpirit.ps015GetProfileType(tracabilite, idtprf);

    // Asserts
    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(null, connectorResponse._second.getCategorie());
    assertEquals(null, connectorResponse._second.getLibelle());
    assertEquals(null, connectorResponse._second.getDiagnostic());
  }

  /**
   * Test to ps015GetProfileType OK
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_ps015GetProfileTypeOK() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String idtprf = "idtprf"; //$NON-NLS-1$

    // Setup mocks
    EasyMock.expect(_resultSet.next()).andReturn(true);
    EasyMock.expect(_resultSet.getString("PROFILETYPE")).andReturn("a"); //$NON-NLS-1$ //$NON-NLS-2$
    PowerMock.replay(_resultSet);

    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getObject("po_RESULT")).andReturn(_resultSet); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_PROFILETYPE(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<String, Retour> connectorResponse = _pgSpirit.ps015GetProfileType(tracabilite, idtprf);

    // Asserts
    assertEquals("OK", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(null, connectorResponse._second.getCategorie());
    assertEquals(null, connectorResponse._second.getLibelle());
    assertEquals(null, connectorResponse._second.getDiagnostic());
    assertEquals("a", connectorResponse._first); //$NON-NLS-1$
  }

  /**
   * Test to ps016GetIccidsParldtCmd KO
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_ps016GetIccidsParldtCmdKO() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String IDTCMD = "idtcmd"; //$NON-NLS-1$

    // Setup mocks
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.KO); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_ICCIDS_IDTCMD(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<List<String>, Retour> connectorResponse = _pgSpirit.ps016GetIccidsParldtCmd(tracabilite, IDTCMD);

    // Asserts
    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(null, connectorResponse._second.getCategorie());
    assertEquals(null, connectorResponse._second.getLibelle());
    assertEquals(null, connectorResponse._second.getDiagnostic());
    assertEquals(0, connectorResponse._first.size());
  }

  /**
   * Test to ps016GetIccidsParldtCmd OK
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_ps016GetIccidsParldtCmdOK() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String IDTCMD = "idtcmd"; //$NON-NLS-1$

    // Setup mocks
    EasyMock.expect(_resultSet.next()).andReturn(true);
    EasyMock.expect(_resultSet.getString("SIM")).andReturn("a"); //$NON-NLS-1$ //$NON-NLS-2$
    PowerMock.replay(_resultSet);

    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getObject("po_RESULT")).andReturn(_resultSet); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_ICCIDS_IDTCMD(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<List<String>, Retour> connectorResponse = _pgSpirit.ps016GetIccidsParldtCmd(tracabilite, IDTCMD);

    // Asserts
    assertEquals("OK", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(null, connectorResponse._second.getCategorie());
    assertEquals(null, connectorResponse._second.getLibelle());
    assertEquals(null, connectorResponse._second.getDiagnostic());
    assertEquals(1, connectorResponse._first.size());
  }

  /**
   * Test to ps015GetProfileType KO
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_ps017GetDateDerniereEchecKO() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String IDTCMD = "idtcmd"; //$NON-NLS-1$

    // Setup mocks
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.KO); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getObject("po_RESULT")).andReturn(null); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_DERNIER_ECHEC_SUIVI_SMDP(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<LocalDateTime, Retour> connectorResponse = _pgSpirit.ps017GetDateDerniereEchec(tracabilite, IDTCMD);

    // Asserts
    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(null, connectorResponse._second.getCategorie());
    assertEquals(null, connectorResponse._second.getLibelle());
    assertEquals(null, connectorResponse._second.getDiagnostic());
    assertNull(connectorResponse._first);
  }

  /**
   * Test to ps015GetProfileType OK
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_ps017GetDateDerniereEchecOK() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String IDTCMD = "idtcmd"; //$NON-NLS-1$

    EasyMock.expect(_resultSet.next()).andReturn(true);
    EasyMock.expect(_resultSet.getTimestamp("DATEDERNIERECHEC")).andReturn(Timestamp.valueOf("2017-02-06 14:16:39.78")); //$NON-NLS-1$ //$NON-NLS-2$
    PowerMock.replay(_resultSet);

    // Setup mocks

    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getObject("po_RESULT")).andReturn(_resultSet); //$NON-NLS-1$

    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_DERNIER_ECHEC_SUIVI_SMDP(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<LocalDateTime, Retour> connectorResponse = _pgSpirit.ps017GetDateDerniereEchec(tracabilite, IDTCMD);

    // Asserts
    assertEquals("OK", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(null, connectorResponse._second.getCategorie());
    assertEquals(null, connectorResponse._second.getLibelle());
    assertEquals(null, connectorResponse._second.getDiagnostic());
    assertEquals(DateTimeTools.toLocalDateTime(Timestamp.valueOf("2017-02-06 14:16:39.78")), connectorResponse._first); //$NON-NLS-1$
  }

  /**
   * Test to ps018SetDateDerniereEchec KO
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_ps018SetDateDerniereEchecKO() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String idtcmd = "idtprf"; //$NON-NLS-1$

    // Setup mocks
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.KO); //$NON-NLS-1$

    PowerMock.replay(_callableStatement);
    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_MAJ_IDTCMD_SUIVI_SMDP(?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<Nothing, Retour> connectorResponse = _pgSpirit.ps018SetDateDerniereEchec(tracabilite, idtcmd);

    // Asserts
    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(null, connectorResponse._second.getCategorie());
    assertEquals(null, connectorResponse._second.getLibelle());
    assertEquals(null, connectorResponse._second.getDiagnostic());
  }

  /**
   * Test to ps018SetDateDerniereEchec OK
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_ps018SetDateDerniereEchecOK() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String idtcmd = "idtprf"; //$NON-NLS-1$

    // Setup mocks
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$

    PowerMock.replay(_callableStatement);
    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_MAJ_IDTCMD_SUIVI_SMDP(?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<Nothing, Retour> connectorResponse = _pgSpirit.ps018SetDateDerniereEchec(tracabilite, idtcmd);

    // Asserts
    assertEquals("OK", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(null, connectorResponse._second.getCategorie());
    assertEquals(null, connectorResponse._second.getLibelle());
    assertEquals(null, connectorResponse._second.getDiagnostic());
  }

  /**
   * Test to ps019UpdateSimDownload KO
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_ps019UpdateSimDownloadKO() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String idtcmd = "idtprf"; //$NON-NLS-1$
    String idtacnsim = "idtacnsim"; //$NON-NLS-1$
    String idtdermod = "idtdermod"; //$NON-NLS-1$
    String etasmdp = "etatmdp"; //$NON-NLS-1$

    // Setup mocks
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.KO); //$NON-NLS-1$

    PowerMock.replay(_callableStatement);
    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_MAJ_SIM_DOWNLOAD(?,?,?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<Nothing, Retour> connectorResponse = _pgSpirit.ps019UpdateSimDownload(tracabilite, "iccid", "idtacnsim", "idtdermod", "etasmdp"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    // Asserts
    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(null, connectorResponse._second.getCategorie());
    assertEquals(null, connectorResponse._second.getLibelle());
    assertEquals(null, connectorResponse._second.getDiagnostic());
  }

  /**
   * Test to ps019UpdateSimDownload OK
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_ps019UpdateSimDownloadOK() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String idtcmd = "idtprf"; //$NON-NLS-1$

    // Setup mocks
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$

    PowerMock.replay(_callableStatement);
    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_MAJ_SIM_DOWNLOAD(?,?,?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<Nothing, Retour> connectorResponse = _pgSpirit.ps019UpdateSimDownload(tracabilite, "iccid", "idtacnsim", "idtdermod", "etasmdp"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$

    // Asserts
    assertEquals("OK", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(null, connectorResponse._second.getCategorie());
    assertEquals(null, connectorResponse._second.getLibelle());
    assertEquals(null, connectorResponse._second.getDiagnostic());
  }

  /**
   * Test to ps020UpdateQuantity KO
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_ps020UpdateQuantityKO() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String idtcmd = "idtcmd"; //$NON-NLS-1$

    // Setup mocks
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.KO); //$NON-NLS-1$

    PowerMock.replay(_callableStatement);
    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_MAJ_QUANT_SUIVI_SMDP(?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<Nothing, Retour> connectorResponse = _pgSpirit.ps020UpdateQuantity(tracabilite, idtcmd);
    // Asserts
    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(null, connectorResponse._second.getCategorie());
    assertEquals(null, connectorResponse._second.getLibelle());
    assertEquals(null, connectorResponse._second.getDiagnostic());
  }

  /**
   * Test to ps020UpdateQuantity OK
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_ps020UpdateQuantityOK() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String idtcmd = "idtcmd"; //$NON-NLS-1$

    // Setup mocks
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$

    PowerMock.replay(_callableStatement);
    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_MAJ_QUANT_SUIVI_SMDP(?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<Nothing, Retour> connectorResponse = _pgSpirit.ps020UpdateQuantity(tracabilite, idtcmd);

    // Asserts
    assertEquals("OK", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(null, connectorResponse._second.getCategorie());
    assertEquals(null, connectorResponse._second.getLibelle());
    assertEquals(null, connectorResponse._second.getDiagnostic());
  }

  /**
   * Test to ps021GetCommandesNonNotifies KO
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_ps021GetCommandesNonNotifiesKO() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();

    // Setup mocks
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.KO); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_CMDNONNOTIFIE(?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<List<CMDSIM>, Retour> connectorResponse = _pgSpirit.ps021GetCommandesNonNotifies(tracabilite);

    // Asserts
    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(null, connectorResponse._second.getCategorie());
    assertEquals(null, connectorResponse._second.getLibelle());
    assertEquals(null, connectorResponse._second.getDiagnostic());
    assertEquals(0, connectorResponse._first.size());
  }

  /**
   * Test to ps021GetCommandesNonNotifies OK
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_ps021GetCommandesNonNotifiesOK() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String idtprfele = "idtprfele"; //$NON-NLS-1$

    // Setup mocks
    EasyMock.expect(_resultSet.next()).andReturn(true);
    EasyMock.expect(_resultSet.getLong("IDTCMD")).andReturn(12345L); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getString("IDTFAB")).andReturn("IDTFAB"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getLong("GNC")).andReturn(1L); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getLong("IDTPRFELE")).andReturn(2L); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getLong("IDTPRFGRA")).andReturn(3L); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getLong("IDTCLA")).andReturn(4L); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getString("IDTART")).andReturn("IDTART"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getLong("SIMPOH")).andReturn(5L); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getString("DEBIMS")).andReturn("DEBIMS"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("DEBSIM")).andReturn("DEBSIM"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getLong("QTECMD")).andReturn(1000L); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getString("ETACMD")).andReturn("ETACMD"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("CLETRP")).andReturn("CLETRP"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("CMTCMD")).andReturn("CMTCMD"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("UAT")).andReturn("UAT"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("NUMCMDSAP")).andReturn("NUMCMDSAP"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getLong("TYPSIM")).andReturn(2000L); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getString("IDTUSASIM")).andReturn("IDTUSASIM"); //$NON-NLS-1$ //$NON-NLS-2$

    EasyMock.expect(_resultSet.getTimestamp("DATLIVPRV")).andReturn(new Timestamp(new Date().getTime())); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getTimestamp("DATLIV")).andReturn(new Timestamp(new Date().getTime())); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getTimestamp("DATKIT")).andReturn(new Timestamp(new Date().getTime())); //$NON-NLS-1$

    EasyMock.expect(_resultSet.getString("ETALOG")).andReturn("ETALOG"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("ETAPRO")).andReturn("ETAPRO"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("ENVOINOTIFSAP")).andReturn("ENVOINOTIFSAP"); //$NON-NLS-1$ //$NON-NLS-2$

    PowerMock.replay(_resultSet);

    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getObject("po_RESULT")).andReturn(_resultSet); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_CMDNONNOTIFIE(?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<List<CMDSIM>, Retour> connectorResponse = _pgSpirit.ps021GetCommandesNonNotifies(tracabilite);

    // Asserts
    assertEquals("OK", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(null, connectorResponse._second.getCategorie());
    assertEquals(null, connectorResponse._second.getLibelle());
    assertEquals(null, connectorResponse._second.getDiagnostic());
    assertEquals(1, connectorResponse._first.size());
    assertEquals((Long) 12345L, connectorResponse._first.get(0).getIdtCMD());
  }

  /**
   * Test to ps022GetCommande KO
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_ps022GetCommandeKO() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String idtcmd = "idtprf"; //$NON-NLS-1$

    // Setup mocks
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.KO); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_COMMANDE(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<CMDSIM, Retour> connectorResponse = _pgSpirit.ps022GetCommande(tracabilite, idtcmd);

    // Asserts
    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(null, connectorResponse._second.getCategorie());
    assertEquals(null, connectorResponse._second.getLibelle());
    assertEquals(null, connectorResponse._second.getDiagnostic());
  }

  /**
   * Test to ps022GetCommande OK
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_ps022GetCommandeOK() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String idtcmd = "idtcmd"; //$NON-NLS-1$

    // Setup mocks
    EasyMock.expect(_resultSet.next()).andReturn(true);
    EasyMock.expect(_resultSet.getLong("IDTCMD")).andReturn(12345L); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getString("IDTFAB")).andReturn("IDTFAB"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getLong("GNC")).andReturn(1L); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getLong("IDTPRFELE")).andReturn(2L); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getLong("IDTPRFGRA")).andReturn(3L); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getLong("IDTCLA")).andReturn(4L); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getString("IDTART")).andReturn("IDTART"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getLong("SIMPOH")).andReturn(5L); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getString("DEBIMS")).andReturn("DEBIMS"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("DEBSIM")).andReturn("DEBSIM"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getLong("QTECMD")).andReturn(1000L); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getString("ETACMD")).andReturn("ETACMD"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("CLETRP")).andReturn("CLETRP"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("CMTCMD")).andReturn("CMTCMD"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("UAT")).andReturn("UAT"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("NUMCMDSAP")).andReturn("NUMCMDSAP"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getLong("TYPSIM")).andReturn(2000L); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getString("IDTUSASIM")).andReturn("IDTUSASIM"); //$NON-NLS-1$ //$NON-NLS-2$

    EasyMock.expect(_resultSet.getTimestamp("DATLIVPRV")).andReturn(new Timestamp(new Date().getTime())); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getTimestamp("DATLIV")).andReturn(new Timestamp(new Date().getTime())); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getTimestamp("DATKIT")).andReturn(new Timestamp(new Date().getTime())); //$NON-NLS-1$

    EasyMock.expect(_resultSet.getString("ETALOG")).andReturn("ETALOG"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("ETAPRO")).andReturn("ETAPRO"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("ENVOINOTIFSAP")).andReturn("ENVOINOTIFSAP"); //$NON-NLS-1$ //$NON-NLS-2$

    PowerMock.replay(_resultSet);

    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getObject("po_RESULT")).andReturn(_resultSet); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_COMMANDE(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<CMDSIM, Retour> connectorResponse = _pgSpirit.ps022GetCommande(tracabilite, idtcmd);

    // Asserts
    assertEquals("OK", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(null, connectorResponse._second.getCategorie());
    assertEquals(null, connectorResponse._second.getLibelle());
    assertEquals(null, connectorResponse._second.getDiagnostic());
    assertEquals((Long) 12345L, connectorResponse._first.getIdtCMD());
  }

  /**
   * Test to ps023UpdateEnvoiCmdSim KO
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_ps023UpdateEnvoiCmdSimKO() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String idtcmd = "idtcmd"; //$NON-NLS-1$
    String envoinotifsap = "envoinotifsap"; //$NON-NLS-1$

    // Setup mocks
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.KO); //$NON-NLS-1$

    PowerMock.replay(_callableStatement);
    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_MAJ_ENVOI_CMDSIM(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<Nothing, Retour> connectorResponse = _pgSpirit.ps023UpdateEnvoiCmdSim(tracabilite, idtcmd, envoinotifsap);
    // Asserts
    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(null, connectorResponse._second.getCategorie());
    assertEquals(null, connectorResponse._second.getLibelle());
    assertEquals(null, connectorResponse._second.getDiagnostic());
  }

  /**
   * Test to ps023UpdateEnvoiCmdSim OK
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_ps023UpdateEnvoiCmdSimOK() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String idtcmd = "idtcmd"; //$NON-NLS-1$
    String envoinotifsap = "envoinotifsap"; //$NON-NLS-1$

    // Setup mocks
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$

    PowerMock.replay(_callableStatement);
    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_MAJ_ENVOI_CMDSIM(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<Nothing, Retour> connectorResponse = _pgSpirit.ps023UpdateEnvoiCmdSim(tracabilite, idtcmd, envoinotifsap);

    // Asserts
    assertEquals("OK", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(null, connectorResponse._second.getCategorie());
    assertEquals(null, connectorResponse._second.getLibelle());
    assertEquals(null, connectorResponse._second.getDiagnostic());
  }

  /**
   * Test to ps024GetBytprd KO
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_ps024GetBytprdKO() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String gnc = "gnc"; //$NON-NLS-1$

    // Setup mocks
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.KO); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_BYTPRD(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<List<BYTPRD>, Retour> connectorResponse = _pgSpirit.ps024GetBytprd(tracabilite, gnc);

    // Asserts
    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(null, connectorResponse._second.getCategorie());
    assertEquals(null, connectorResponse._second.getLibelle());
    assertEquals(null, connectorResponse._second.getDiagnostic());
  }

  /**
   * Test to ps024GetBytprd OK
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_ps024GetBytprdOK() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String gnc = "gnc"; //$NON-NLS-1$

    // Setup mocks
    EasyMock.expect(_resultSet.next()).andReturn(true);
    EasyMock.expect(_resultSet.getLong("GNC")).andReturn(1L); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getString("TYPGNC")).andReturn("TYPGNC"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("IDTARTWRK")).andReturn("IDTARTWRK"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getLong("IDTPRFELC")).andReturn(1L); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getLong("IDTPRFGRF")).andReturn(1L); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getString("IDTFAB")).andReturn("IDTFAB"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getLong("IDTSIMCLA")).andReturn(1L); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getString("TYPSIM")).andReturn("TYPSIM"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("IDTUSASIM")).andReturn("IDTUSASIM"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("CODARTSAP")).andReturn("CODARTSAP"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("LIBARTSAP")).andReturn("LIBARTSAP"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("DEBTRAMSI")).andReturn("DEBTRAMSI"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("FINTRAMSI")).andReturn("FINTRAMSI"); //$NON-NLS-1$ //$NON-NLS-2$

    EasyMock.expect(_resultSet.getTimestamp("DATFINVAL")).andReturn(new Timestamp(new Date().getTime())); //$NON-NLS-1$

    EasyMock.expect(_resultSet.getLong("IDTOPE")).andReturn(1L); //$NON-NLS-1$

    PowerMock.replay(_resultSet);

    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getObject("po_RESULT")).andReturn(_resultSet); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_BYTPRD(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<List<BYTPRD>, Retour> connectorResponse = _pgSpirit.ps024GetBytprd(tracabilite, gnc);

    // Asserts
    assertEquals("OK", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(null, connectorResponse._second.getCategorie());
    assertEquals(null, connectorResponse._second.getLibelle());
    assertEquals(null, connectorResponse._second.getDiagnostic());
    assertEquals((Long) 1L, connectorResponse._first.get(0).getGnc());
  }

  /**
   * Test to ps025GetSUIVISMDP KO
   *
   *
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_ps025GetSUIVISMDPKO() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String idtcmd = "idtcmd"; //$NON-NLS-1$

    // Setup mocks
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.KO); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_IDTCMD_SUIVI_SMDP(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<List<SUIVISMDP>, Retour> connectorResponse = _pgSpirit.ps025GetSUIVISMDP(tracabilite, idtcmd);

    // Asserts
    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(null, connectorResponse._second.getCategorie());
    assertEquals(null, connectorResponse._second.getLibelle());
    assertEquals(null, connectorResponse._second.getDiagnostic());
  }

  /**
   * Test to ps025GetSUIVISMDP OK
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_ps025GetSUIVISMDPOK() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String idtcmd = "IDTCMD"; //$NON-NLS-1$

    // Setup mocks
    EasyMock.expect(_resultSet.next()).andReturn(true);

    EasyMock.expect(_resultSet.getLong("IDTCMD")).andReturn(8933209616440009542L); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getTimestamp("DATEDERNIERMAJ")).andReturn(new Timestamp(new Date().getTime())); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getTimestamp("DATEDERNIERECHEC")).andReturn(new Timestamp(new Date().getTime())); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getLong("QUANTITE")).andReturn(100L); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getTimestamp("DATETRAITEMENT")).andReturn(new Timestamp(new Date().getTime())); //$NON-NLS-1$

    PowerMock.replay(_resultSet);

    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getObject("po_RESULT")).andReturn(_resultSet); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_IDTCMD_SUIVI_SMDP(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<List<SUIVISMDP>, Retour> connectorResponse = _pgSpirit.ps025GetSUIVISMDP(tracabilite, idtcmd);

    // Asserts
    assertEquals("OK", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(null, connectorResponse._second.getCategorie());
    assertEquals(null, connectorResponse._second.getLibelle());
    assertEquals(null, connectorResponse._second.getDiagnostic());
    assertEquals(8933209616440009542L, connectorResponse._first.get(0).getIdtcmd().longValue());
  }

  /**
   * Test to ps026EnresgistrerEnvoiFichier KO
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_ps026EnresgistrerEnvoiFichierKO() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String idtcmd = "idtcmd"; //$NON-NLS-1$
    String nomficheir = "nomfichier"; //$NON-NLS-1$

    // Setup mocks
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.KO); //$NON-NLS-1$

    PowerMock.replay(_callableStatement);
    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_ENREGISTRER_ENVOI_FICHIER(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<Nothing, Retour> connectorResponse = _pgSpirit.ps026EnregistrerEnvoiFichier(tracabilite, idtcmd, nomficheir);
    // Asserts
    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(null, connectorResponse._second.getCategorie());
    assertEquals(null, connectorResponse._second.getLibelle());
    assertEquals(null, connectorResponse._second.getDiagnostic());
  }

  /**
   * Test to ps026EnresgistrerEnvoiFichier OK
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_ps026EnresgistrerEnvoiFichierOK() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String idtcmd = "idtcmd"; //$NON-NLS-1$
    String nomficheir = "nomfichier"; //$NON-NLS-1$

    // Setup mocks
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$

    PowerMock.replay(_callableStatement);
    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_ENREGISTRER_ENVOI_FICHIER(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<Nothing, Retour> connectorResponse = _pgSpirit.ps026EnregistrerEnvoiFichier(tracabilite, idtcmd, nomficheir);

    // Asserts
    assertEquals("OK", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(null, connectorResponse._second.getCategorie());
    assertEquals(null, connectorResponse._second.getLibelle());
    assertEquals(null, connectorResponse._second.getDiagnostic());
  }

  /**
   * Test to ps025GetSUIVISMDP KO
   *
   *
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_ps027GetSUIVISMDPDernierEchecKO() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String idtcmd = "idtcmd"; //$NON-NLS-1$

    // Setup mocks
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.KO); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_DERNIER_ECHEC_SUIVI_SMDP(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<SUIVISMDP, Retour> connectorResponse = _pgSpirit.ps027GetSUIVISMDPDernierEchec(tracabilite, idtcmd);

    // Asserts
    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(null, connectorResponse._second.getCategorie());
    assertEquals(null, connectorResponse._second.getLibelle());
    assertEquals(null, connectorResponse._second.getDiagnostic());
  }

  /**
   * Test to ps025GetSUIVISMDP OK
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_ps027GetSUIVISMDPDernierEchecOK() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String idtcmd = "IDTCMD"; //$NON-NLS-1$

    // Setup mocks
    EasyMock.expect(_resultSet.next()).andReturn(true);

    EasyMock.expect(_resultSet.getLong("IDTCMD")).andReturn(8933209616440009542L); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getTimestamp("DATEDERNIERMAJ")).andReturn(new Timestamp(new Date().getTime())); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getTimestamp("DATEDERNIERECHEC")).andReturn(new Timestamp(new Date().getTime())); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getLong("QUANTITE")).andReturn(100L); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getTimestamp("DATETRAITEMENT")).andReturn(new Timestamp(new Date().getTime())); //$NON-NLS-1$

    PowerMock.replay(_resultSet);

    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getObject("po_RESULT")).andReturn(_resultSet); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_DERNIER_ECHEC_SUIVI_SMDP(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<SUIVISMDP, Retour> connectorResponse = _pgSpirit.ps027GetSUIVISMDPDernierEchec(tracabilite, idtcmd);

    // Asserts
    assertEquals("OK", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(null, connectorResponse._second.getCategorie());
    assertEquals(null, connectorResponse._second.getLibelle());
    assertEquals(null, connectorResponse._second.getDiagnostic());
    assertEquals(8933209616440009542L, connectorResponse._first.getIdtcmd().longValue());
    assertEquals((Long) 100L, connectorResponse._first.getQuantite());
  }

  /**
   * Test to updateSimRessource KO
   *
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_updateSimRessource_KO_001() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String iccid = "iccid"; //$NON-NLS-1$
    String etaSim = "etaSim"; //$NON-NLS-1$
    Long idtAcnSim = 123L;
    String idtDermod = "idtDermod"; //$NON-NLS-1$
    String idtist = "idtist"; //$NON-NLS-1$
    String etasmdp = "etasmdp"; //$NON-NLS-1$
    String etatNotif = "etatNotif"; //$NON-NLS-1$
    String policyEtat = "policyEtat"; //$NON-NLS-1$
    String policyHabilitation = "policyHabilitation"; //$NON-NLS-1$
    String eid = "eid"; //$NON-NLS-1$
    String smsrid = "smsrid"; //$NON-NLS-1$

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_MAJ_SIM_RESSOURCE(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) }")).andThrow(new SQLTimeoutException()); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<Nothing, Retour> connectorResponse = _pgSpirit.updateSimRessource(tracabilite, iccid, etaSim, idtAcnSim, idtDermod, idtist, etasmdp, etatNotif, policyEtat, policyHabilitation, eid, smsrid);

    // Asserts
    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, connectorResponse._second.getCategorie());
    assertEquals(MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_SUR_NON_REPONSE"), 1), connectorResponse._second.getLibelle()); //$NON-NLS-1$
    assertEquals(INSERTION_FAILED, connectorResponse._second.getDiagnostic());
  }

  /**
   * Test to updateSimRessource KO
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_updateSimRessource_KO_002() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String iccid = "iccid"; //$NON-NLS-1$
    String etaSim = "etaSim"; //$NON-NLS-1$
    Long idtAcnSim = 123L;
    String idtDermod = "idtDermod"; //$NON-NLS-1$
    String idtist = "idtist"; //$NON-NLS-1$
    String etasmdp = "etasmdp"; //$NON-NLS-1$
    String etatNotif = "etatNotif"; //$NON-NLS-1$
    String policyEtat = "policyEtat"; //$NON-NLS-1$
    String policyHabilitation = "policyHabilitation"; //$NON-NLS-1$
    String eid = "eid"; //$NON-NLS-1$
    String smsrid = "smsrid"; //$NON-NLS-1$

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_MAJ_SIM_RESSOURCE(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) }")).andThrow(new PoolExhaustedException()); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<Nothing, Retour> connectorResponse = _pgSpirit.updateSimRessource(tracabilite, iccid, etaSim, idtAcnSim, idtDermod, idtist, etasmdp, etatNotif, policyEtat, policyHabilitation, eid, smsrid);

    // Asserts
    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, connectorResponse._second.getCategorie());
    assertEquals(Messages.getString("GDRConnector.ERREUR_GDR_AUCUNE_SESSION"), connectorResponse._second.getLibelle()); //$NON-NLS-1$
    assertEquals(SESSION_UNAVAILABLE, connectorResponse._second.getDiagnostic());
  }

  /**
   * Test to updateSimRessource KO
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_updateSimRessource_KO_003() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String iccid = "iccid"; //$NON-NLS-1$
    String etaSim = "etaSim"; //$NON-NLS-1$
    Long idtAcnSim = 123L;
    String idtDermod = "idtDermod"; //$NON-NLS-1$
    String idtist = "idtist"; //$NON-NLS-1$
    String etasmdp = "etasmdp"; //$NON-NLS-1$
    String etatNotif = "etatNotif"; //$NON-NLS-1$
    String policyEtat = "policyEtat"; //$NON-NLS-1$
    String policyHabilitation = "policyHabilitation"; //$NON-NLS-1$
    String eid = "eid"; //$NON-NLS-1$
    String smsrid = "smsrid"; //$NON-NLS-1$

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_MAJ_SIM_RESSOURCE(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) }")).andThrow(new SQLRecoverableException()); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<Nothing, Retour> connectorResponse = _pgSpirit.updateSimRessource(tracabilite, iccid, etaSim, idtAcnSim, idtDermod, idtist, etasmdp, etatNotif, policyEtat, policyHabilitation, eid, smsrid);

    // Asserts
    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, connectorResponse._second.getCategorie());
    assertEquals(MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_CONNEXION"), 4), connectorResponse._second.getLibelle()); //$NON-NLS-1$
    assertEquals(CONNEXION_FAILED, connectorResponse._second.getDiagnostic());
  }

  /**
   * Test to updateSimRessource KO
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test(expected = RavelException.class)
  public void test_updateSimRessource_KO_004() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String iccid = "iccid"; //$NON-NLS-1$
    String etaSim = "etaSim"; //$NON-NLS-1$
    Long idtAcnSim = 123L;
    String idtDermod = "idtDermod"; //$NON-NLS-1$
    String idtist = "idtist"; //$NON-NLS-1$
    String etasmdp = "etasmdp"; //$NON-NLS-1$
    String etatNotif = "etatNotif"; //$NON-NLS-1$
    String policyEtat = "policyEtat"; //$NON-NLS-1$
    String policyHabilitation = "policyHabilitation"; //$NON-NLS-1$
    String eid = "eid"; //$NON-NLS-1$
    String smsrid = "smsrid"; //$NON-NLS-1$

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_MAJ_SIM_RESSOURCE(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) }")).andThrow(new SQLException()); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    _pgSpirit.updateSimRessource(tracabilite, iccid, etaSim, idtAcnSim, idtDermod, idtist, etasmdp, etatNotif, policyEtat, policyHabilitation, eid, smsrid);
  }

  /**
   * Test to updateSimRessource KO
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_updateSimRessource_KO_005() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String iccid = "iccid"; //$NON-NLS-1$
    String etaSim = "etaSim"; //$NON-NLS-1$
    Long idtAcnSim = 123L;
    String idtDermod = "idtDermod"; //$NON-NLS-1$
    String idtist = "idtist"; //$NON-NLS-1$
    String etasmdp = "etasmdp"; //$NON-NLS-1$
    String etatNotif = "etatNotif"; //$NON-NLS-1$
    String policyEtat = "policyEtat"; //$NON-NLS-1$
    String policyHabilitation = "policyHabilitation"; //$NON-NLS-1$
    String eid = "eid"; //$NON-NLS-1$
    String smsrid = "smsrid"; //$NON-NLS-1$

    // Setup mocks
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.KO); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_MAJ_SIM_RESSOURCE(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<Nothing, Retour> connectorResponse = _pgSpirit.updateSimRessource(tracabilite, iccid, etaSim, idtAcnSim, idtDermod, idtist, etasmdp, etatNotif, policyEtat, policyHabilitation, eid, smsrid);

    // Asserts
    assertEquals("KO", connectorResponse._second.getResultat()); //$NON-NLS-1$
    assertNull(connectorResponse._second.getCategorie());
    assertNull(connectorResponse._second.getLibelle());
    assertNull(connectorResponse._second.getDiagnostic());
  }

  /**
   * Test to updateSimRessource OK
   *
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  @Test
  public void test_updateSimRessource_OK() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String iccid = "iccid"; //$NON-NLS-1$
    String etaSim = "etaSim"; //$NON-NLS-1$
    Long idtAcnSim = 123L;
    String idtDermod = "idtDermod"; //$NON-NLS-1$
    String idtist = "idtist"; //$NON-NLS-1$
    String etasmdp = "etasmdp"; //$NON-NLS-1$
    String etatNotif = "etatNotif"; //$NON-NLS-1$
    String policyEtat = "policyEtat"; //$NON-NLS-1$
    String policyHabilitation = "policyHabilitation"; //$NON-NLS-1$
    String eid = "eid"; //$NON-NLS-1$
    String smsrid = "smsrid"; //$NON-NLS-1$

    // Setup mocks
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getObject("po_RESULT")).andReturn(_resultSet); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_MAJ_SIM_RESSOURCE(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<Nothing, Retour> connectorResponse = _pgSpirit.updateSimRessource(tracabilite, iccid, etaSim, idtAcnSim, idtDermod, idtist, etasmdp, etatNotif, policyEtat, policyHabilitation, eid, smsrid);

    // Asserts
    assertEquals("OK", connectorResponse._second.getResultat()); //$NON-NLS-1$
  }

  /**
   * GetProfilElectriqueParIdentifiant KO test<br/>
   *
   * <b>Entrées:</b>No results<br/>
   * <b>Attendu:</b>Retour=KO<br/>
   *
   * @throws Exception
   *           On unexpected error
   */
  @Test
  public void testGetProfilElectriqueParIdentifiant_KO_01() throws Exception
  {
    // Request variables
    Tracabilite tracabilite = new Tracabilite();
    String idtprf_p = "idtprf_p"; //$NON-NLS-1$
    String typprf_p = "typprf_p"; //$NON-NLS-1$

    // Setup mocks
    Capture<String> piIdtPrf = Capture.newInstance();
    _callableStatement.setString(EasyMock.eq("pi_IDTPRF"), EasyMock.capture(piIdtPrf)); //$NON-NLS-1$

    Capture<String> piTypePrf = Capture.newInstance();
    _callableStatement.setString(EasyMock.eq("pi_TYPPRF"), EasyMock.capture(piTypePrf)); //$NON-NLS-1$

    EasyMock.expectLastCall();
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.KO); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_PE_IDTPRF_TYPPRF(?,?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<String, Retour> connectorResponse = _pgSpirit.getProfilElectriqueParIdentifiant(tracabilite, idtprf_p, typprf_p);

    // Asserts
    assertEquals(idtprf_p, piIdtPrf.getValue());
    assertEquals(typprf_p, piTypePrf.getValue());

    assertEquals(null, connectorResponse._first);
    assertEquals(IMegConsts.KO, connectorResponse._second.getResultat());
    assertNull(connectorResponse._second.getCategorie());
    assertNull(connectorResponse._second.getLibelle());
    assertNull(connectorResponse._second.getDiagnostic());
  }

  /**
   * SQL Timeout Exception<br/>
   *
   * <b>Entrées:</b>SQL Timeout Exception<br/>
   * <b>Attendu:</b>Retour=KO<br/>
   *
   * @throws Exception
   *           On unexpected error
   */
  @Test
  public void testGetProfilElectriqueParIdentifiant_KO_02() throws Exception
  {
    // Request variables
    Tracabilite tracabilite = new Tracabilite();
    String idtprf_p = "idtprf_p"; //$NON-NLS-1$
    String typprf_p = "typprf_p"; //$NON-NLS-1$

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_PE_IDTPRF_TYPPRF(?,?,?,?,?,?,?) }")).andThrow(new SQLTimeoutException()); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<String, Retour> connectorResponse = _pgSpirit.getProfilElectriqueParIdentifiant(tracabilite, idtprf_p, typprf_p);

    // Asserts
    Retour retourExpected = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_SUR_NON_REPONSE"), 1)); //$NON-NLS-1$

    assertNull(connectorResponse._first);
    assertEquals(retourExpected, connectorResponse._second);
  }

  /**
   * Pool Exhausted Exception<br/>
   *
   * <b>Entrées:</b>Pool Exhausted Exception<br/>
   * <b>Attendu:</b>Retour=KO<br/>
   *
   * @throws Exception
   *           On unexpected error
   */
  @Test
  public void testGetProfilElectriqueParIdentifiant_KO_03() throws Exception
  {
    // Request variables
    Tracabilite tracabilite = new Tracabilite();
    String idtprf_p = "idtprf_p"; //$NON-NLS-1$
    String typprf_p = "typprf_p"; //$NON-NLS-1$

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_PE_IDTPRF_TYPPRF(?,?,?,?,?,?,?) }")).andThrow(new PoolExhaustedException()); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<String, Retour> connectorResponse = _pgSpirit.getProfilElectriqueParIdentifiant(tracabilite, idtprf_p, typprf_p);

    // Asserts
    Retour retourExpected = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("GDRConnector.ERREUR_GDR_AUCUNE_SESSION")); //$NON-NLS-1$

    assertNull(connectorResponse._first);
    assertEquals(retourExpected, connectorResponse._second);
  }

  /**
   * SQL Recoverable Exception<br/>
   *
   * <b>Entrées:</b>SQL Recoverable Exception<br/>
   * <b>Attendu:</b>Retour=KO<br/>
   *
   * @throws Exception
   *           On unexpected error
   */
  @Test
  public void testGetProfilElectriqueParIdentifiant_KO_04() throws Exception
  {
    // Request variables
    Tracabilite tracabilite = new Tracabilite();
    String idtprf_p = "idtprf_p"; //$NON-NLS-1$
    String typprf_p = "typprf_p"; //$NON-NLS-1$

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_PE_IDTPRF_TYPPRF(?,?,?,?,?,?,?) }")).andThrow(new SQLRecoverableException()); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<String, Retour> connectorResponse = _pgSpirit.getProfilElectriqueParIdentifiant(tracabilite, idtprf_p, typprf_p);

    // Asserts
    Retour retourExpected = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_CONNEXION"), 4)); //$NON-NLS-1$

    assertNull(connectorResponse._first);
    assertEquals(retourExpected, connectorResponse._second);
  }

  /**
   * SQL Exception<br/>
   *
   * <b>Entrées:</b>SQL Exception<br/>
   * <b>Attendu:</b>Retour=KO<br/>
   *
   * @throws Exception
   *           On unexpected error
   */
  @Test
  public void testGetProfilElectriqueParIdentifiant_KO_05() throws Exception
  {
    // Request variables
    Tracabilite tracabilite = new Tracabilite();
    String idtprf_p = "idtprf_p"; //$NON-NLS-1$
    String typprf_p = "typprf_p"; //$NON-NLS-1$

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_PE_IDTPRF_TYPPRF(?,?,?,?,?,?,?) }")).andThrow(new SQLException()); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<String, Retour> connectorResponse = new ConnectorResponse<>(null, null);

    try
    {
      connectorResponse = _pgSpirit.getProfilElectriqueParIdentifiant(tracabilite, idtprf_p, typprf_p);

    }
    catch (Exception ex)
    {
      String errorMessage = "Technical Exception in GDRConnector during PG_SPIRIT.P_GET_PE_IDTPRF_TYPPRF call: code(0) reason(null) at GDRPGSpirit.java"; //$NON-NLS-1$
      assertTrue(ex.getMessage().contains(errorMessage));
    }
  }

  /**
   * Nominal test case<br/>
   *
   * <b>Entrées:</b>2 variables<br/>
   * <b>Attendu:</b>Retour=OK<br/>
   *
   * @throws Exception
   *           On unexpected error
   */
  @Test
  public void testGetProfilElectriqueParIdentifiant_OK() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String idtprf_p = "idtprf_p"; //$NON-NLS-1$
    String typprf_p = "typprf_p"; //$NON-NLS-1$

    // Setup mocks
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString("po_PE")).andReturn("po_PE"); //$NON-NLS-1$ //$NON-NLS-2$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_PE_IDTPRF_TYPPRF(?,?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<String, Retour> connectorResponse = _pgSpirit.getProfilElectriqueParIdentifiant(tracabilite, idtprf_p, typprf_p);

    // Asserts
    assertEquals("po_PE", connectorResponse._first); //$NON-NLS-1$

    assertEquals(StringConstants.OK, connectorResponse._second.getResultat());
    assertNull(connectorResponse._second.getCategorie());
    assertNull(connectorResponse._second.getLibelle());
    assertNull(connectorResponse._second.getDiagnostic());
  }

  /**
   * GetSimsNonPreProvisionnes KO test<br/>
   *
   * <b>Entrées:</b>No results<br/>
   * <b>Attendu:</b>Retour=KO<br/>
   *
   * @throws Exception
   *           On unexpected error
   */
  @Test
  public void testGetSimsNonPreProvisionnes_KO_01() throws Exception
  {
    // Request variables
    Tracabilite tracabilite = new Tracabilite();
    String idtCmd_p = "idtCmd_p"; //$NON-NLS-1$
    String etatMoc_p = "etatMoc_p"; //$NON-NLS-1$

    // Setup mocks
    Capture<String> piIdtCmd = Capture.newInstance();
    _callableStatement.setString(EasyMock.eq("pi_IDTCMD"), EasyMock.capture(piIdtCmd)); //$NON-NLS-1$

    Capture<String> piEtatMoc = Capture.newInstance();
    _callableStatement.setString(EasyMock.eq("pi_ETATMOC"), EasyMock.capture(piEtatMoc)); //$NON-NLS-1$

    EasyMock.expectLastCall();
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.KO); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_SIM_IDTCMD(?,?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<List<Sim>, Retour> connectorResponse = _pgSpirit.getSimsNonPreProvisionnes(tracabilite, idtCmd_p, etatMoc_p);

    // Asserts
    assertEquals(idtCmd_p, piIdtCmd.getValue());
    assertEquals(etatMoc_p, piEtatMoc.getValue());

    assertEquals(0, connectorResponse._first.size());
    assertEquals(IMegConsts.KO, connectorResponse._second.getResultat());
    assertNull(connectorResponse._second.getCategorie());
    assertNull(connectorResponse._second.getLibelle());
    assertNull(connectorResponse._second.getDiagnostic());
  }

  /**
   * SQL Timeout Exception<br/>
   *
   * <b>Entrées:</b>SQL Timeout Exception<br/>
   * <b>Attendu:</b>Retour=KO<br/>
   *
   * @throws Exception
   *           On unexpected error
   */
  @Test
  public void testGetSimsNonPreProvisionnes_KO_02() throws Exception
  {
    // Request variables
    Tracabilite tracabilite = new Tracabilite();
    String idtCmd_p = "idtCmd_p"; //$NON-NLS-1$
    String etatMoc_p = "etatMoc_p"; //$NON-NLS-1$

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_SIM_IDTCMD(?,?,?,?,?,?,?) }")).andThrow(new SQLTimeoutException()); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<List<Sim>, Retour> connectorResponse = _pgSpirit.getSimsNonPreProvisionnes(tracabilite, idtCmd_p, etatMoc_p);

    // Asserts
    Retour retourExpected = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_SUR_NON_REPONSE"), 1)); //$NON-NLS-1$

    assertNull(connectorResponse._first);
    assertEquals(retourExpected, connectorResponse._second);
  }

  /**
   * Pool Exhausted Exception<br/>
   *
   * <b>Entrées:</b>Pool Exhausted Exception<br/>
   * <b>Attendu:</b>Retour=KO<br/>
   *
   * @throws Exception
   *           On unexpected error
   */
  @Test
  public void testGetSimsNonPreProvisionnes_KO_03() throws Exception
  {
    // Request variables
    Tracabilite tracabilite = new Tracabilite();
    String idtCmd_p = "idtCmd_p"; //$NON-NLS-1$
    String etatMoc_p = "etatMoc_p"; //$NON-NLS-1$

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_SIM_IDTCMD(?,?,?,?,?,?,?) }")).andThrow(new PoolExhaustedException()); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<List<Sim>, Retour> connectorResponse = _pgSpirit.getSimsNonPreProvisionnes(tracabilite, idtCmd_p, etatMoc_p);

    // Asserts
    Retour retourExpected = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("GDRConnector.ERREUR_GDR_AUCUNE_SESSION")); //$NON-NLS-1$

    assertNull(connectorResponse._first);
    assertEquals(retourExpected, connectorResponse._second);
  }

  /**
   * SQL Recoverable Exception<br/>
   *
   * <b>Entrées:</b>SQL Recoverable Exception<br/>
   * <b>Attendu:</b>Retour=KO<br/>
   *
   * @throws Exception
   *           On unexpected error
   */
  @Test
  public void testGetSimsNonPreProvisionnes_KO_04() throws Exception
  {
    // Request variables
    Tracabilite tracabilite = new Tracabilite();
    String idtCmd_p = "idtCmd_p"; //$NON-NLS-1$
    String etatMoc_p = "etatMoc_p"; //$NON-NLS-1$

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_SIM_IDTCMD(?,?,?,?,?,?,?) }")).andThrow(new SQLRecoverableException()); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<List<Sim>, Retour> connectorResponse = _pgSpirit.getSimsNonPreProvisionnes(tracabilite, idtCmd_p, etatMoc_p);

    // Asserts
    Retour retourExpected = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_CONNEXION"), 4)); //$NON-NLS-1$

    assertNull(connectorResponse._first);
    assertEquals(retourExpected, connectorResponse._second);
  }

  /**
   * SQL Exception<br/>
   *
   * <b>Entrées:</b>SQL Exception<br/>
   * <b>Attendu:</b>Retour=KO<br/>
   *
   * @throws Exception
   *           On unexpected error
   */
  @Test
  public void testGetSimsNonPreProvisionnes_KO_05() throws Exception
  {
    // Request variables
    Tracabilite tracabilite = new Tracabilite();
    String idtCmd_p = "idtCmd_p"; //$NON-NLS-1$
    String etatMoc_p = "etatMoc_p"; //$NON-NLS-1$

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_SIM_IDTCMD(?,?,?,?,?,?,?) }")).andThrow(new SQLException()); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    try
    {
      _pgSpirit.getSimsNonPreProvisionnes(tracabilite, idtCmd_p, etatMoc_p);
    }
    catch (Exception ex)
    {
      String errorMessage = "Technical Exception in GDRConnector during PG_SPIRIT.P_GET_SIM_IDTCMD call: code(0) reason(null) at GDRPGSpirit.java"; //$NON-NLS-1$
      assertTrue(ex.getMessage().contains(errorMessage));
    }
  }

  /**
   * Nominal test case<br/>
   *
   * <b>Entrées:</b>2 variables<br/>
   * <b>Attendu:</b>Retour=OK<br/>
   *
   * @throws Exception
   *           On unexpected error
   */
  @Test
  public void testGetSimsNonPreProvisionnes_OK() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String idtCmd_p = "idtCmd_p"; //$NON-NLS-1$
    String etatMoc_p = "etatMoc_p"; //$NON-NLS-1$

    // Setup mocks
    EasyMock.expect(_resultSet.next()).andReturn(true);
    EasyMock.expect(_resultSet.getLong("IDTSIM")).andReturn(123L); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getLong("IDTHLR")).andReturn(123L); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getLong("IDTCMD")).andReturn(123L); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getString("ETASIM")).andReturn("ETASIM"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getLong("IDTACNSIM")).andReturn(123L); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getTimestamp("DATETA")).andReturn(new Timestamp(new Date().getTime())); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getString("SIM")).andReturn("SIM"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("IMS")).andReturn("IMS"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getLong("PIN")).andReturn(123L); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getLong("PIN002")).andReturn(123L); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getLong("PUK")).andReturn(123L); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getLong("PUK002")).andReturn(123L); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getString("CLEKI_")).andReturn("CLEKI_"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("CODADM")).andReturn("CODADM"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getLong("TYPSIM")).andReturn(123L); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getString("ETACOM")).andReturn("ETACOM"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("ETAPRT")).andReturn("ETAPRT"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("IDTDERMOD")).andReturn("IDTDERMOD"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("CLEOTA")).andReturn("CLEOTA"); //$NON-NLS-1$ //$NON-NLS-2$

    PowerMock.replay(_resultSet);

    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getObject("po_RESULT")).andReturn(_resultSet); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_SIM_IDTCMD(?,?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<List<Sim>, Retour> connectorResponse = _pgSpirit.getSimsNonPreProvisionnes(tracabilite, idtCmd_p, etatMoc_p);

    // Asserts
    assertEquals(1, connectorResponse._first.size());
    assertEquals(new Long(123), connectorResponse._first.get(0).getIdtsim());
    assertEquals(new Long(123), connectorResponse._first.get(0).getIdthlr());
    assertEquals(new Long(123), connectorResponse._first.get(0).getIdtcmd());
    assertEquals(null, connectorResponse._first.get(0).getEtasim());
    assertEquals(new Long(123), connectorResponse._first.get(0).getIdtacnsim());
    assertEquals("SIM", connectorResponse._first.get(0).getSim()); //$NON-NLS-1$
    assertEquals("IMS", connectorResponse._first.get(0).getIms()); //$NON-NLS-1$
    assertEquals(new Long(123), connectorResponse._first.get(0).getPin());
    assertEquals(new Long(123), connectorResponse._first.get(0).getPin002());
    assertEquals(new Long(123), connectorResponse._first.get(0).getPuk());
    assertEquals(new Long(123), connectorResponse._first.get(0).getPuk002());
    assertEquals("CLEKI_", connectorResponse._first.get(0).getCleki()); //$NON-NLS-1$
    assertEquals("CODADM", connectorResponse._first.get(0).getCodam()); //$NON-NLS-1$
    assertEquals(new Long(123), connectorResponse._first.get(0).getTypsim());
    assertEquals("ETACOM", connectorResponse._first.get(0).getEtacom()); //$NON-NLS-1$
    assertEquals("ETAPRT", connectorResponse._first.get(0).getEtaprt()); //$NON-NLS-1$
    assertEquals("IDTDERMOD", connectorResponse._first.get(0).getIdtdermod()); //$NON-NLS-1$
    assertEquals("CLEOTA", connectorResponse._first.get(0).getCleota()); //$NON-NLS-1$

    assertEquals(StringConstants.OK, connectorResponse._second.getResultat());
    assertNull(connectorResponse._second.getCategorie());
    assertNull(connectorResponse._second.getLibelle());
    assertNull(connectorResponse._second.getDiagnostic());
  }

  /**
   * GetStatistiquesEsim KO test<br/>
   *
   * <b>Entrées:</b>No results<br/>
   * <b>Attendu:</b>Retour=KO<br/>
   *
   * @throws Exception
   *           On unexpected error
   */
  @Test
  public void testGetStatistiquesEsim_KO_01() throws Exception
  {
    // Request variables
    Tracabilite tracabilite = new Tracabilite();
    String periodicite = "periodicite"; //$NON-NLS-1$

    // Setup mocks
    Capture<String> piPeriodiciteCapture = Capture.newInstance();

    _callableStatement.setString(EasyMock.eq("pi_Periodicite"), EasyMock.capture(piPeriodiciteCapture)); //$NON-NLS-1$

    EasyMock.expectLastCall();
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.KO); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_STATISTIQUESESIM(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<List<StatistiqueEsim>, Retour> connectorResponse = _pgSpirit.getStatistiquesEsim(tracabilite, periodicite);

    // Asserts
    assertEquals(periodicite, piPeriodiciteCapture.getValue());

    assertEquals(0, connectorResponse._first.size());
    assertEquals(IMegConsts.KO, connectorResponse._second.getResultat());
    assertNull(connectorResponse._second.getCategorie());
    assertNull(connectorResponse._second.getLibelle());
    assertNull(connectorResponse._second.getDiagnostic());
  }

  /**
   * SQL Timeout Exception<br/>
   *
   * <b>Entrées:</b>SQL Timeout Exception<br/>
   * <b>Attendu:</b>Retour=KO<br/>
   *
   * @throws Exception
   *           On unexpected error
   */
  @Test
  public void testGetStatistiquesEsim_KO_02() throws Exception
  {
    // Request variables
    Tracabilite tracabilite = new Tracabilite();
    String periodicite = "periodicite"; //$NON-NLS-1$

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_STATISTIQUESESIM(?,?,?,?,?,?) }")).andThrow(new SQLTimeoutException()); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<List<StatistiqueEsim>, Retour> connectorResponse = _pgSpirit.getStatistiquesEsim(tracabilite, periodicite);

    // Asserts
    Retour retourExpected = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_SUR_NON_REPONSE"), 1)); //$NON-NLS-1$

    assertNull(connectorResponse._first);
    assertEquals(retourExpected, connectorResponse._second);
  }

  /**
   * Pool Exhausted Exception<br/>
   *
   * <b>Entrées:</b>Pool Exhausted Exception<br/>
   * <b>Attendu:</b>Retour=KO<br/>
   *
   * @throws Exception
   *           On unexpected error
   */
  @Test
  public void testGetStatistiquesEsim_KO_03() throws Exception
  {
    // Request variables
    Tracabilite tracabilite = new Tracabilite();
    String periodicite = "periodicite"; //$NON-NLS-1$

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_STATISTIQUESESIM(?,?,?,?,?,?) }")).andThrow(new PoolExhaustedException()); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<List<StatistiqueEsim>, Retour> connectorResponse = _pgSpirit.getStatistiquesEsim(tracabilite, periodicite);

    // Asserts
    Retour retourExpected = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("GDRConnector.ERREUR_GDR_AUCUNE_SESSION")); //$NON-NLS-1$

    assertNull(connectorResponse._first);
    assertEquals(retourExpected, connectorResponse._second);
  }

  /**
   * SQL Recoverable Exception<br/>
   *
   * <b>Entrées:</b>SQL Recoverable Exception<br/>
   * <b>Attendu:</b>Retour=KO<br/>
   *
   * @throws Exception
   *           On unexpected error
   */
  @Test
  public void testGetStatistiquesEsim_KO_04() throws Exception
  {
    // Request variables
    Tracabilite tracabilite = new Tracabilite();
    String periodicite = "periodicite"; //$NON-NLS-1$

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_STATISTIQUESESIM(?,?,?,?,?,?) }")).andThrow(new SQLRecoverableException()); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<List<StatistiqueEsim>, Retour> connectorResponse = _pgSpirit.getStatistiquesEsim(tracabilite, periodicite);

    // Asserts
    Retour retourExpected = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_CONNEXION"), 4)); //$NON-NLS-1$

    assertNull(connectorResponse._first);
    assertEquals(retourExpected, connectorResponse._second);
  }

  /**
   * SQL Exception<br/>
   *
   * <b>Entrées:</b>SQL Exception<br/>
   * <b>Attendu:</b>Retour=KO<br/>
   *
   * @throws Exception
   *           On unexpected error
   */
  @Test
  public void testGetStatistiquesEsim_KO_05() throws Exception
  {
    // Request variables
    Tracabilite tracabilite = new Tracabilite();
    String periodicite = "periodicite"; //$NON-NLS-1$

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_STATISTIQUESESIM(?,?,?,?,?,?) }")).andThrow(new SQLException()); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    try
    {
      _pgSpirit.getStatistiquesEsim(tracabilite, periodicite);
    }
    catch (Exception ex)
    {
      String errorMessage = "Technical Exception in GDRConnector during PG_SPIRIT.P_GET_STATISTIQUESESIM call: code(0) reason(null) at GDRPGSpirit.java"; //$NON-NLS-1$
      assertTrue(ex.getMessage().contains(errorMessage));
    }
  }

  /**
   * Nominal test case<br/>
   *
   * <b>Entrées:</b>One result<br/>
   * <b>Attendu:</b>Retour=OK<br/>
   *
   * @throws Exception
   *           On unexpected error
   */
  @Test
  public void testGetStatistiquesEsim_OK_01() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String periodicite = "periodicite"; //$NON-NLS-1$

    // Setup mocks
    EasyMock.expect(_resultSet.next()).andReturn(true);
    EasyMock.expect(_resultSet.getTimestamp(DATECOMPTAGE)).andReturn(new Timestamp(new Date().getTime()));
    EasyMock.expect(_resultSet.getString(TYPECOMPTAGE)).andReturn(TYPECOMPTAGE);
    EasyMock.expect(_resultSet.getBigDecimal(GENCOD)).andReturn(new BigDecimal(123));
    EasyMock.expect(_resultSet.getLong(GENCOD)).andReturn(123L);
    EasyMock.expect(_resultSet.getString(PROFILELECTRIQUE)).andReturn("1.2"); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getString(CODEARTICLESAP)).andReturn(CODEARTICLESAP);
    EasyMock.expect(_resultSet.getString(PROFILETYPE)).andReturn(PROFILETYPE);
    EasyMock.expect(_resultSet.getString(ENCARTEUR)).andReturn(ENCARTEUR);
    EasyMock.expect(_resultSet.getInt(QUANTITE)).andReturn(0);
    EasyMock.expect(_resultSet.getString(ALERTE)).andReturn(ALERTE);

    PowerMock.replay(_resultSet);

    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getObject("po_RESULT")).andReturn(_resultSet); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_STATISTIQUESESIM(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<List<StatistiqueEsim>, Retour> connectorResponse = _pgSpirit.getStatistiquesEsim(tracabilite, periodicite);

    // Asserts
    assertEquals(1, connectorResponse._first.size());
    assertEquals(new Long(123), connectorResponse._first.get(0).getGencod());
    assertEquals(new String("1.2"), connectorResponse._first.get(0).getProfilElectrique()); //$NON-NLS-1$
    assertEquals(0, connectorResponse._first.get(0).getQuantite());
    assertEquals(ALERTE, connectorResponse._first.get(0).getAlert());
    assertEquals(StringConstants.OK, connectorResponse._second.getResultat());
    assertNull(connectorResponse._second.getCategorie());
    assertNull(connectorResponse._second.getLibelle());
    assertNull(connectorResponse._second.getDiagnostic());
  }

  /**
   * Nominal test case<br/>
   *
   * <b>Entrées:</b>Multiple results<br/>
   * <b>Attendu:</b>Retour=OK<br/>
   *
   * @throws Exception
   *           On unexpected error
   */
  @Test
  public void testGetStatistiquesEsim_OK_02() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String periodicite = "periodicite"; //$NON-NLS-1$

    // Setup mocks
    EasyMock.expect(_resultSet.next()).andReturn(true);
    EasyMock.expect(_resultSet.getTimestamp(DATECOMPTAGE)).andReturn(new Timestamp(new Date().getTime()));
    EasyMock.expect(_resultSet.getString(TYPECOMPTAGE)).andReturn(TYPECOMPTAGE);
    EasyMock.expect(_resultSet.getBigDecimal(GENCOD)).andReturn(new BigDecimal(123));
    EasyMock.expect(_resultSet.getLong(GENCOD)).andReturn(123L);
    EasyMock.expect(_resultSet.getString(PROFILELECTRIQUE)).andReturn("3.4"); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getString(CODEARTICLESAP)).andReturn(CODEARTICLESAP);
    EasyMock.expect(_resultSet.getString(PROFILETYPE)).andReturn(PROFILETYPE);
    EasyMock.expect(_resultSet.getString(ENCARTEUR)).andReturn(ENCARTEUR);
    EasyMock.expect(_resultSet.getInt(QUANTITE)).andReturn(0);
    EasyMock.expect(_resultSet.getString(ALERTE)).andReturn(ALERTE);

    EasyMock.expect(_resultSet.next()).andReturn(true);
    EasyMock.expect(_resultSet.getTimestamp(DATECOMPTAGE)).andReturn(new Timestamp(new Date().getTime()));
    EasyMock.expect(_resultSet.getString(TYPECOMPTAGE)).andReturn(TYPECOMPTAGE);
    EasyMock.expect(_resultSet.getBigDecimal(GENCOD)).andReturn(new BigDecimal(456));
    EasyMock.expect(_resultSet.getLong(GENCOD)).andReturn(123L);
    EasyMock.expect(_resultSet.getString(PROFILELECTRIQUE)).andReturn("3.4"); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getString(CODEARTICLESAP)).andReturn(CODEARTICLESAP);
    EasyMock.expect(_resultSet.getString(PROFILETYPE)).andReturn(PROFILETYPE);
    EasyMock.expect(_resultSet.getString(ENCARTEUR)).andReturn(ENCARTEUR);
    EasyMock.expect(_resultSet.getInt(QUANTITE)).andReturn(0);
    EasyMock.expect(_resultSet.getString(ALERTE)).andReturn(ALERTE);

    PowerMock.replay(_resultSet);

    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getObject("po_RESULT")).andReturn(_resultSet); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_STATISTIQUESESIM(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<List<StatistiqueEsim>, Retour> connectorResponse = _pgSpirit.getStatistiquesEsim(tracabilite, periodicite);

    // Asserts
    assertEquals(2, connectorResponse._first.size());
    assertEquals(new Long(123), connectorResponse._first.get(0).getGencod());
    assertEquals(new String("3.4"), connectorResponse._first.get(0).getProfilElectrique()); //$NON-NLS-1$
    assertEquals(0, connectorResponse._first.get(0).getQuantite());
    assertEquals(ALERTE, connectorResponse._first.get(0).getAlert());
    assertEquals(StringConstants.OK, connectorResponse._second.getResultat());
    assertNull(connectorResponse._second.getCategorie());
    assertNull(connectorResponse._second.getLibelle());
    assertNull(connectorResponse._second.getDiagnostic());
  }

  /**
   * SQL Timeout Exception for method insertErreurSmdp<br/>
   *
   * <b>Entrées:</b>SQL Timeout Exception<br/>
   * <b>Attendu:</b>Retour=KO<br/>
   *
   * @throws Exception
   *           On unexpected error
   */
  @Test
  public void testInsertErreurSmdp_KO_01() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String iccid = "iccid"; //$NON-NLS-1$
    String requestid = "requestid"; //$NON-NLS-1$
    String etaterreur = "etaterreur"; //$NON-NLS-1$
    LocalDateTime dat = LocalDateTime.of(2019, 7, 1, 20, 0, 0);
    String idtdermod = "idtdermod"; //$NON-NLS-1$
    String etatrequete = "etatrequete"; //$NON-NLS-1$
    String entiteerreur = "entiteerreur"; //$NON-NLS-1$
    String raisonerreur = "raisonerreur"; //$NON-NLS-1$
    String libelleerreur = "libelleerreur"; //$NON-NLS-1$

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_INS_ERREUR_SMDP(?,?,?,?,?,?,?,?,?,?,?,?,?) }")).andThrow(new SQLTimeoutException()); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<Nothing, Retour> connectorResponse = _pgSpirit.insertErreurSmdp(tracabilite, iccid, requestid, etaterreur, dat, idtdermod, etatrequete, entiteerreur, raisonerreur, libelleerreur);

    // Asserts
    Retour retourExpected = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_SUR_NON_REPONSE"), 1)); //$NON-NLS-1$

    assertNull(connectorResponse._first);
    assertEquals(retourExpected, connectorResponse._second);
  }

  /**
   * Pool Exhausted Exception for method insertErreurSmdp<br/>
   *
   * <b>Entrées:</b>Pool Exhausted Exception<br/>
   * <b>Attendu:</b>Retour=KO<br/>
   *
   * @throws Exception
   *           On unexpected error
   */
  @Test
  public void testInsertErreurSmdp_KO_02() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String iccid = "iccid"; //$NON-NLS-1$
    String requestid = "requestid"; //$NON-NLS-1$
    String etaterreur = "etaterreur"; //$NON-NLS-1$
    LocalDateTime dat = LocalDateTime.of(2019, 7, 1, 20, 0, 0);
    String idtdermod = "idtdermod"; //$NON-NLS-1$
    String etatrequete = "etatrequete"; //$NON-NLS-1$
    String entiteerreur = "entiteerreur"; //$NON-NLS-1$
    String raisonerreur = "raisonerreur"; //$NON-NLS-1$
    String libelleerreur = "libelleerreur"; //$NON-NLS-1$

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_INS_ERREUR_SMDP(?,?,?,?,?,?,?,?,?,?,?,?,?) }")).andThrow(new PoolExhaustedException()); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<Nothing, Retour> connectorResponse = _pgSpirit.insertErreurSmdp(tracabilite, iccid, requestid, etaterreur, dat, idtdermod, etatrequete, entiteerreur, raisonerreur, libelleerreur);

    // Asserts
    Retour retourExpected = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("GDRConnector.ERREUR_GDR_AUCUNE_SESSION")); //$NON-NLS-1$

    assertNull(connectorResponse._first);
    assertEquals(retourExpected, connectorResponse._second);
  }

  /**
   * SQL Recoverable Exception for method insertErreurSmdp<br/>
   *
   * <b>Entrées:</b>SQL Recoverable Exception<br/>
   * <b>Attendu:</b>Retour=KO<br/>
   *
   * @throws Exception
   *           On unexpected error
   */
  @Test
  public void testInsertErreurSmdp_KO_03() throws Exception
  {
    // Request variables
    Tracabilite tracabilite = new Tracabilite();
    String iccid = "iccid"; //$NON-NLS-1$
    String requestid = "requestid"; //$NON-NLS-1$
    String etaterreur = "etaterreur"; //$NON-NLS-1$
    LocalDateTime dat = LocalDateTime.of(2019, 7, 1, 20, 0, 0);
    String idtdermod = "idtdermod"; //$NON-NLS-1$
    String etatrequete = "etatrequete"; //$NON-NLS-1$
    String entiteerreur = "entiteerreur"; //$NON-NLS-1$
    String raisonerreur = "raisonerreur"; //$NON-NLS-1$
    String libelleerreur = "libelleerreur"; //$NON-NLS-1$

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_INS_ERREUR_SMDP(?,?,?,?,?,?,?,?,?,?,?,?,?) }")).andThrow(new SQLRecoverableException()); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<Nothing, Retour> connectorResponse = _pgSpirit.insertErreurSmdp(tracabilite, iccid, requestid, etaterreur, dat, idtdermod, etatrequete, entiteerreur, raisonerreur, libelleerreur);

    // Asserts
    Retour retourExpected = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_CONNEXION"), 4)); //$NON-NLS-1$

    assertNull(connectorResponse._first);
    assertEquals(retourExpected, connectorResponse._second);
  }

  /**
   * SQL Exception for method insertErreurSmdp<br/>
   *
   * <b>Entrées:</b>SQL Exception<br/>
   * <b>Attendu:</b>Retour=KO<br/>
   *
   * @throws Exception
   *           On unexpected error
   */
  @Test
  public void testInsertErreurSmdp_KO_04() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String iccid = "iccid"; //$NON-NLS-1$
    String requestid = "requestid"; //$NON-NLS-1$
    String etaterreur = "etaterreur"; //$NON-NLS-1$
    LocalDateTime dat = LocalDateTime.of(2019, 7, 1, 20, 0, 0);
    String idtdermod = "idtdermod"; //$NON-NLS-1$
    String etatrequete = "etatrequete"; //$NON-NLS-1$
    String entiteerreur = "entiteerreur"; //$NON-NLS-1$
    String raisonerreur = "raisonerreur"; //$NON-NLS-1$
    String libelleerreur = "libelleerreur"; //$NON-NLS-1$

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_INS_ERREUR_SMDP(?,?,?,?,?,?,?,?,?,?,?,?,?) }")).andThrow(new SQLException()); //$NON-NLS-1$
    PowerMock.replay(_connection);

    ConnectorResponse<Nothing, Retour> connectorResponse = new ConnectorResponse<>(null, null);
    try
    {
      connectorResponse = _pgSpirit.insertErreurSmdp(tracabilite, iccid, requestid, etaterreur, dat, idtdermod, etatrequete, entiteerreur, raisonerreur, libelleerreur);
    }
    catch (Exception ex)
    {
      assertNull(connectorResponse._second);
      String errorMessage = "Technical Exception in GDRConnector during PG_SPIRIT.P_INS_ERREUR_SMDP call: code(0) reason(null) at GDRPGSpirit.java"; //$NON-NLS-1$
      assertTrue(ex.getMessage().contains(errorMessage));
    }
  }

  /**
   * Nominal test case for method<br/>
   *
   * <b>Entrées:</b>9 variables<br/>
   * <b>Attendu:</b>Retour=OK<br/>
   *
   * @throws Exception
   *           On unexpected error
   */
  @Test
  public void testInsertErreurSmdp_OK() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String iccid = "iccid"; //$NON-NLS-1$
    String requestid = "requestid"; //$NON-NLS-1$
    String etaterreur = "etaterreur"; //$NON-NLS-1$
    LocalDateTime dat = LocalDateTime.of(2019, 7, 1, 20, 0, 0);
    String idtdermod = "idtdermod"; //$NON-NLS-1$
    String etatrequete = "etatrequete"; //$NON-NLS-1$
    String entiteerreur = "entiteerreur"; //$NON-NLS-1$
    String raisonerreur = "raisonerreur"; //$NON-NLS-1$
    String libelleerreur = "libelleerreur"; //$NON-NLS-1$

    // Setup mocks
    Capture<String> iccidCapture = Capture.newInstance();
    Capture<String> requestidCapture = Capture.newInstance();
    Capture<String> etaterreurCapture = Capture.newInstance();
    Capture<Timestamp> datCapture = Capture.newInstance();
    Capture<String> idtdermodCapture = Capture.newInstance();
    Capture<String> etatrequeteCapture = Capture.newInstance();
    Capture<String> entiteerreurCapture = Capture.newInstance();
    Capture<String> raisonerreurCapture = Capture.newInstance();
    Capture<String> libelleerreurCapture = Capture.newInstance();

    _callableStatement.setString(EasyMock.eq("pi_ICCID"), EasyMock.capture(iccidCapture)); //$NON-NLS-1$
    _callableStatement.setString(EasyMock.eq("pi_REQUESTID"), EasyMock.capture(requestidCapture)); //$NON-NLS-1$
    _callableStatement.setString(EasyMock.eq("pi_ETATERREUR"), EasyMock.capture(etaterreurCapture)); //$NON-NLS-1$
    _callableStatement.setTimestamp(EasyMock.eq("pi_DAT"), EasyMock.capture(datCapture)); //$NON-NLS-1$
    _callableStatement.setString(EasyMock.eq("pi_IDTDERMOD"), EasyMock.capture(idtdermodCapture)); //$NON-NLS-1$
    _callableStatement.setString(EasyMock.eq("pi_ETATREQUETE"), EasyMock.capture(etatrequeteCapture)); //$NON-NLS-1$
    _callableStatement.setString(EasyMock.eq("pi_ENTITEERREUR"), EasyMock.capture(entiteerreurCapture)); //$NON-NLS-1$
    _callableStatement.setString(EasyMock.eq("pi_RAISONERREUR"), EasyMock.capture(raisonerreurCapture)); //$NON-NLS-1$
    _callableStatement.setString(EasyMock.eq("pi_LIBELLEERREUR"), EasyMock.capture(libelleerreurCapture)); //$NON-NLS-1$

    EasyMock.expectLastCall();
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_INS_ERREUR_SMDP(?,?,?,?,?,?,?,?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<Nothing, Retour> connectorResponse = _pgSpirit.insertErreurSmdp(tracabilite, iccid, requestid, etaterreur, dat, idtdermod, etatrequete, entiteerreur, raisonerreur, libelleerreur);

    // Asserts
    assertEquals(RetourFactory.createOkRetour(), connectorResponse._second);
    assertEquals(iccid, iccidCapture.getValue());
    assertEquals(requestid, requestidCapture.getValue());
    assertEquals(etaterreur, etaterreurCapture.getValue());
    assertEquals(idtdermod, idtdermodCapture.getValue());
    assertEquals(etatrequete, etatrequeteCapture.getValue());
    assertEquals(entiteerreur, entiteerreurCapture.getValue());
    assertEquals(raisonerreur, raisonerreurCapture.getValue());
    assertEquals(libelleerreur, libelleerreurCapture.getValue());
    assertEquals(Timestamp.valueOf(dat), datCapture.getValue());

    assertEquals(null, connectorResponse._first);
  }

  /**
   * Test update state sim batch <BR>
   * KO with SQLTimeoutException
   * @throws Exception on error.
   */
  @Test
  public void testMettreAJourSIM_KO_01() throws Exception
  {
    // Request variables
    Tracabilite tracabilite = new Tracabilite();
    String iccid = "iccid"; //$NON-NLS-1$
    String etatSmdp = "etatSmdp"; //$NON-NLS-1$
    String statutTelechargement = "statutTelechargement"; //$NON-NLS-1$
    String objetModification = "objetModification"; //$NON-NLS-1$
    String timestamp = "timestamp"; //$NON-NLS-1$
    String eid = "eid"; //$NON-NLS-1$

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_MAJ_SIM(?,?,?,?,?,?,?,?,?,?) }")).andThrow(new SQLTimeoutException()); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<String, Retour> connectorResponse = _pgSpirit.mettreAJourSIM(tracabilite, iccid, etatSmdp, statutTelechargement, objetModification, timestamp, eid);

    // Asserts

    Retour retourExpected = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_SUR_NON_REPONSE"), 1)); //$NON-NLS-1$

    assertEquals(null, connectorResponse._first);
    assertEquals(retourExpected, connectorResponse._second);
  }

  /**
   * Test update state sim batch <BR>
   * KO with PoolExhaustedException
   * @throws Exception on error.
   */
  @Test
  public void testMettreAJourSIM_KO_02() throws Exception
  {
    // Request variables
    Tracabilite tracabilite = new Tracabilite();
    String iccid = "iccid"; //$NON-NLS-1$
    String etatSmdp = "etatSmdp"; //$NON-NLS-1$
    String statutTelechargement = "statutTelechargement"; //$NON-NLS-1$
    String objetModification = "objetModification"; //$NON-NLS-1$
    String timestamp = "timestamp"; //$NON-NLS-1$
    String eid = "eid"; //$NON-NLS-1$

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_MAJ_SIM(?,?,?,?,?,?,?,?,?,?) }")).andThrow(new PoolExhaustedException()); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<String, Retour> connectorResponse = _pgSpirit.mettreAJourSIM(tracabilite, iccid, etatSmdp, statutTelechargement, objetModification, timestamp, eid);

    // Asserts

    Retour retourExpected = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("GDRConnector.ERREUR_GDR_AUCUNE_SESSION")); //$NON-NLS-1$

    assertEquals(null, connectorResponse._first);
    assertEquals(retourExpected, connectorResponse._second);
  }

  /**
   * Test update state sim batch <BR>
   * KO with SQLRecoverableException
   * @throws Exception on error.
   */
  @Test
  public void testMettreAJourSIM_KO_03() throws Exception
  {
    // Request variables
    Tracabilite tracabilite = new Tracabilite();
    String iccid = "iccid"; //$NON-NLS-1$
    String etatSmdp = "etatSmdp"; //$NON-NLS-1$
    String statutTelechargement = "statutTelechargement"; //$NON-NLS-1$
    String objetModification = "objetModification"; //$NON-NLS-1$
    String timestamp = "timestamp"; //$NON-NLS-1$
    String eid = "eid"; //$NON-NLS-1$

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_MAJ_SIM(?,?,?,?,?,?,?,?,?,?) }")).andThrow(new SQLRecoverableException()); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<String, Retour> connectorResponse = _pgSpirit.mettreAJourSIM(tracabilite, iccid, etatSmdp, statutTelechargement, objetModification, timestamp, eid);

    // Asserts

    Retour retourExpected = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_CONNEXION"), 4)); //$NON-NLS-1$

    assertEquals(null, connectorResponse._first);
    assertEquals(retourExpected, connectorResponse._second);
  }

  /**
   * Test update state sim batch (nominal case)
   * @throws Exception on error.
   */
  @Test
  public void testMettreAJourSIM_OK() throws Exception
  {
    // Request variables
    Tracabilite tracabilite = new Tracabilite();
    String iccid = "iccid"; //$NON-NLS-1$
    String etatSmdp = "etatSmdp"; //$NON-NLS-1$
    String statutTelechargement = "statutTelechargement"; //$NON-NLS-1$
    String objetModification = "objetModification"; //$NON-NLS-1$
    String timestamp = "timestamp"; //$NON-NLS-1$
    String eid = "eid"; //$NON-NLS-1$

    // Setup mocks
    Capture<String> piIccidCapture = Capture.newInstance();
    Capture<String> piEtatSmdpCapture = Capture.newInstance();
    Capture<String> piStatutTelechargementCapture = Capture.newInstance();
    Capture<String> piObjetModificationCapture = Capture.newInstance();

    _callableStatement.setString(EasyMock.eq("pi_Iccid"), EasyMock.capture(piIccidCapture)); //$NON-NLS-1$
    _callableStatement.setString(EasyMock.eq("pi_etatSmdp"), EasyMock.capture(piEtatSmdpCapture)); //$NON-NLS-1$
    _callableStatement.setString(EasyMock.eq("pi_statutTelechargement"), EasyMock.capture(piStatutTelechargementCapture)); //$NON-NLS-1$
    _callableStatement.setString(EasyMock.eq("pi_objetModification"), EasyMock.capture(piObjetModificationCapture)); //$NON-NLS-1$

    EasyMock.expectLastCall();
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_MAJ_SIM(?,?,?,?,?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<String, Retour> connectorResponse = _pgSpirit.mettreAJourSIM(tracabilite, iccid, etatSmdp, statutTelechargement, objetModification, timestamp, eid);

    // Asserts
    assertEquals(iccid, piIccidCapture.getValue());
    assertEquals(etatSmdp, piEtatSmdpCapture.getValue());
    assertEquals(statutTelechargement, piStatutTelechargementCapture.getValue());
    assertEquals(objetModification, piObjetModificationCapture.getValue());

    assertEquals(null, connectorResponse._first);
    assertEquals(null, connectorResponse._second.getCategorie());
    assertEquals(null, connectorResponse._second.getLibelle());
    assertEquals(null, connectorResponse._second.getDiagnostic());
  }

  /**
   * Test update state sim batch <BR>
   * KO with SQLTimeoutException
   * @throws Exception on error.
   */
  @Test
  public void testMettreAJourSIMNotif_KO_01() throws Exception
  {
    // Request variables
    Tracabilite tracabilite = new Tracabilite();
    String iccid = "iccid"; //$NON-NLS-1$
    String etatSmdp = "etatSmdp"; //$NON-NLS-1$
    String identifiantAction = "identifiantAction"; //$NON-NLS-1$
    String objetModification = "objetModification"; //$NON-NLS-1$
    String datEta = "2018-10-10T15:16:17.018"; //$NON-NLS-1$
    String etatNotif = "Profil inactif ok"; //$NON-NLS-1$

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_MAJ_SIM_NOTIF(?,?,?,?,?,?,?,?,?,?)}")).andThrow(new SQLTimeoutException()); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<String, Retour> connectorResponse = _pgSpirit.mettreAJourSIMNotif(tracabilite, iccid, etatSmdp, identifiantAction, objetModification, datEta, etatNotif);

    // Asserts
    Retour retourExpected = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_SUR_NON_REPONSE"), 1)); //$NON-NLS-1$

    assertEquals(null, connectorResponse._first);
    assertEquals(retourExpected, connectorResponse._second);
  }

  /**
   * Test update state sim batch <BR>
   * KO with PoolExhaustedException
   * @throws Exception on error.
   */
  @Test
  public void testMettreAJourSIMNotif_KO_02() throws Exception
  {
    // Request variables
    Tracabilite tracabilite = new Tracabilite();
    String iccid = "iccid"; //$NON-NLS-1$
    String etatSmdp = "etatSmdp"; //$NON-NLS-1$
    String identifiantAction = "identifiantAction"; //$NON-NLS-1$
    String objetModification = "objetModification"; //$NON-NLS-1$
    String datEta = DateTimeManager.getInstance().now().toString();
    String etatNotif = "Profil inactif ok"; //$NON-NLS-1$

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_MAJ_SIM_NOTIF(?,?,?,?,?,?,?,?,?,?)}")).andThrow(new PoolExhaustedException()); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<String, Retour> connectorResponse = _pgSpirit.mettreAJourSIMNotif(tracabilite, iccid, etatSmdp, identifiantAction, objetModification, datEta, etatNotif);

    // Asserts
    Retour retourExpected = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("GDRConnector.ERREUR_GDR_AUCUNE_SESSION")); //$NON-NLS-1$

    assertEquals(null, connectorResponse._first);
    assertEquals(retourExpected, connectorResponse._second);
  }

  /**
   * Test update state sim batch <BR>
   * KO with SQLRecoverableException
   * @throws Exception on error.
   */
  @Test
  public void testMettreAJourSIMNotif_KO_03() throws Exception
  {
    // Request variables
    Tracabilite tracabilite = new Tracabilite();
    String iccid = "iccid"; //$NON-NLS-1$
    String etatSmdp = "etatSmdp"; //$NON-NLS-1$
    String identifiantAction = "identifiantAction"; //$NON-NLS-1$
    String objetModification = "objetModification"; //$NON-NLS-1$
    String datEta = DateTimeManager.getInstance().now().toString();
    String etatNotif = "Profil inactif ok"; //$NON-NLS-1$
    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_MAJ_SIM_NOTIF(?,?,?,?,?,?,?,?,?,?)}")).andThrow(new SQLRecoverableException()); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<String, Retour> connectorResponse = _pgSpirit.mettreAJourSIMNotif(tracabilite, iccid, etatSmdp, identifiantAction, objetModification, datEta, etatNotif);

    // Asserts
    Retour retourExpected = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_CONNEXION"), 4)); //$NON-NLS-1$

    assertEquals(null, connectorResponse._first);
    assertEquals(retourExpected, connectorResponse._second);
  }

  /**
   * Test update state sim batch <BR>
   * KO with SQLException
   * @throws Exception on error.
   */
  @Test
  public void testMettreAJourSIMNotif_KO_04() throws Exception
  {
    // Request variables
    Tracabilite tracabilite = new Tracabilite();
    String iccid = "iccid"; //$NON-NLS-1$
    String etatSmdp = "etatSmdp"; //$NON-NLS-1$
    String identifiantAction = "identifiantAction"; //$NON-NLS-1$
    String objetModification = "objetModification"; //$NON-NLS-1$
    String datEta = DateTimeManager.getInstance().now().toString();
    String etatNotif = "Profil inactif ok"; //$NON-NLS-1$
    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_MAJ_SIM_NOTIF(?,?,?,?,?,?,?,?,?,?)}")).andThrow(new SQLException()); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    try
    {
      _pgSpirit.mettreAJourSIMNotif(tracabilite, iccid, etatSmdp, identifiantAction, objetModification, datEta, etatNotif);
    }
    catch (Exception ex)
    {
      String errorMessage = "Technical Exception in GDRConnector during PG_SPIRIT.P_MAJ_SIM_NOTIF call: code(0) reason(null) at GDRPGSpirit.java"; //$NON-NLS-1$
      assertTrue(ex.getMessage().contains(errorMessage));
    }
  }

  /**
   * Test update state sim batch (nominal case)
   * @throws Exception on error.
   */
  @Test
  public void testMettreAJourSIMNotif_OK() throws Exception
  {
    // Request variables
    Tracabilite tracabilite = new Tracabilite();
    String iccid = "iccid"; //$NON-NLS-1$
    String etatSmdp = "etatSmdp"; //$NON-NLS-1$
    String identifiantAction = "identifiantAction"; //$NON-NLS-1$
    String objetModification = "objetModification"; //$NON-NLS-1$
    String datEta = DateTimeManager.getInstance().now().toString();
    String etatNotif = "Profil inactif ok"; //$NON-NLS-1$

    // Setup mocks
    Capture<String> piIccidCapture = Capture.newInstance();
    Capture<String> piEtatSmdpCapture = Capture.newInstance();
    Capture<String> piIdentifiantActionCapture = Capture.newInstance();
    Capture<String> piObjetModificationCapture = Capture.newInstance();
    Capture<String> piDatEtaCapture = Capture.newInstance();

    _callableStatement.setString(EasyMock.eq("pi_Iccid"), EasyMock.capture(piIccidCapture)); //$NON-NLS-1$
    _callableStatement.setString(EasyMock.eq("pi_etatSmdp"), EasyMock.capture(piEtatSmdpCapture)); //$NON-NLS-1$
    _callableStatement.setString(EasyMock.eq("pi_identifiantAction"), EasyMock.capture(piIdentifiantActionCapture)); //$NON-NLS-1$
    _callableStatement.setString(EasyMock.eq("pi_objetModification"), EasyMock.capture(piObjetModificationCapture)); //$NON-NLS-1$
    _callableStatement.setString(EasyMock.eq("pi_datEta"), EasyMock.capture(piDatEtaCapture)); //$NON-NLS-1$

    EasyMock.expectLastCall();
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_MAJ_SIM_NOTIF(?,?,?,?,?,?,?,?,?,?)}")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<String, Retour> connectorResponse = _pgSpirit.mettreAJourSIMNotif(tracabilite, iccid, etatSmdp, identifiantAction, objetModification, datEta, etatNotif);

    // Asserts
    assertEquals(iccid, piIccidCapture.getValue());
    assertEquals(etatSmdp, piEtatSmdpCapture.getValue());
    assertEquals(identifiantAction, piIdentifiantActionCapture.getValue());
    assertEquals(objetModification, piObjetModificationCapture.getValue());
    assertEquals(datEta, piDatEtaCapture.getValue());

    assertEquals(null, connectorResponse._first);
    assertEquals(null, connectorResponse._second.getCategorie());
    assertEquals(null, connectorResponse._second.getLibelle());
    assertEquals(null, connectorResponse._second.getDiagnostic());
  }

  /**
   * SQL Timeout Exception<br/>
   *
   * <b>Entrées:</b>SQL Timeout Exception<br/>
   * <b>Attendu:</b>Retour=KO<br/>
   *
   * @throws Exception
   *           On unexpected error
   */
  @Test
  public void testUpdateSimEtatMoc_KO_01() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String pe_p = "pe_p"; //$NON-NLS-1$
    String etatMoc_p = "etatMoc_p"; //$NON-NLS-1$

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_MAJ_PREPROVMOC_PE(?,?,?,?,?,?) }")).andThrow(new SQLTimeoutException()); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<Nothing, Retour> connectorResponse = _pgSpirit.updateSimEtatMoc(tracabilite, pe_p, etatMoc_p);

    // Asserts
    Retour retourExpected = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_SUR_NON_REPONSE"), 1)); //$NON-NLS-1$

    assertNull(connectorResponse._first);
    assertEquals(retourExpected, connectorResponse._second);
  }

  /**
   * Pool Exhausted Exception<br/>
   *
   * <b>Entrées:</b>Pool Exhausted Exception<br/>
   * <b>Attendu:</b>Retour=KO<br/>
   *
   * @throws Exception
   *           On unexpected error
   */
  @Test
  public void testUpdateSimEtatMoc_KO_02() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String pe_p = "pe_p"; //$NON-NLS-1$
    String etatMoc_p = "etatMoc_p"; //$NON-NLS-1$

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_MAJ_PREPROVMOC_PE(?,?,?,?,?,?) }")).andThrow(new PoolExhaustedException()); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<Nothing, Retour> connectorResponse = _pgSpirit.updateSimEtatMoc(tracabilite, pe_p, etatMoc_p);

    // Asserts
    Retour retourExpected = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("GDRConnector.ERREUR_GDR_AUCUNE_SESSION")); //$NON-NLS-1$

    assertNull(connectorResponse._first);
    assertEquals(retourExpected, connectorResponse._second);
  }

  /**
   * SQL Recoverable Exception<br/>
   *
   * <b>Entrées:</b>SQL Recoverable Exception<br/>
   * <b>Attendu:</b>Retour=KO<br/>
   *
   * @throws Exception
   *           On unexpected error
   */
  @Test
  public void testUpdateSimEtatMoc_KO_03() throws Exception
  {
    // Request variables
    Tracabilite tracabilite = new Tracabilite();
    String pe_p = "pe_p"; //$NON-NLS-1$
    String etatMoc_p = "etatMoc_p"; //$NON-NLS-1$

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_MAJ_PREPROVMOC_PE(?,?,?,?,?,?) }")).andThrow(new SQLRecoverableException()); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<Nothing, Retour> connectorResponse = _pgSpirit.updateSimEtatMoc(tracabilite, pe_p, etatMoc_p);

    // Asserts
    Retour retourExpected = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_CONNEXION"), 4)); //$NON-NLS-1$

    assertNull(connectorResponse._first);
    assertEquals(retourExpected, connectorResponse._second);
  }

  /**
   * SQL Exception<br/>
   *
   * <b>Entrées:</b>SQL Exception<br/>
   * <b>Attendu:</b>Retour=KO<br/>
   *
   * @throws Exception
   *           On unexpected error
   */
  @Test
  public void testUpdateSimEtatMoc_KO_04() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String pe_p = "pe_p"; //$NON-NLS-1$
    String etatMoc_p = "etatMoc_p"; //$NON-NLS-1$

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_MAJ_PREPROVMOC_PE(?,?,?,?,?,?) }")).andThrow(new SQLException()); //$NON-NLS-1$
    PowerMock.replay(_connection);

    ConnectorResponse<Nothing, Retour> connectorResponse = new ConnectorResponse<>(null, null);
    try
    {
      connectorResponse = _pgSpirit.updateSimEtatMoc(tracabilite, pe_p, etatMoc_p);
    }
    catch (Exception ex)
    {
      assertNull(connectorResponse._second);
      String errorMessage = "Technical Exception in GDRConnector during PG_SPIRIT.P_MAJ_PREPROVMOC_PE call: code(0) reason(null) at GDRPGSpirit.java"; //$NON-NLS-1$
      assertTrue(ex.getMessage().contains(errorMessage));
    }
  }

  /**
   * Nominal test case<br/>
   *
   * <b>Entrées:</b>2 variables<br/>
   * <b>Attendu:</b>Retour=OK<br/>
   *
   * @throws Exception
   *           On unexpected error
   */
  @Test
  public void testUpdateSimEtatMoc_OK() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String pe_p = "pe_p"; //$NON-NLS-1$
    String etatMoc_p = "etatMoc_p"; //$NON-NLS-1$

    // Setup mocks
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_MAJ_PREPROVMOC_PE(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<Nothing, Retour> connectorResponse = _pgSpirit.updateSimEtatMoc(tracabilite, pe_p, etatMoc_p);

    // Asserts
    assertEquals(RetourFactory.createOkRetour(), connectorResponse._second);
  }

  /**
   * SQL Timeout Exception<br/>
   *
   * <b>Entrées:</b>SQL Timeout Exception<br/>
   * <b>Attendu:</b>Retour=KO<br/>
   *
   * @throws Exception
   *           On unexpected error
   */
  @Test
  public void testUpdateSimEtatMocImsi_KO_01() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String imsi_p = "imsi_p"; //$NON-NLS-1$
    String etatMoc_p = "etatMoc_p"; //$NON-NLS-1$

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_MAJ_PREPROVMOC_IMSI(?,?,?,?,?,?) }")).andThrow(new SQLTimeoutException()); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<Nothing, Retour> connectorResponse = _pgSpirit.updateSimEtatMocImsi(tracabilite, imsi_p, etatMoc_p);

    // Asserts
    Retour retourExpected = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_SUR_NON_REPONSE"), 1)); //$NON-NLS-1$

    assertNull(connectorResponse._first);
    assertEquals(retourExpected, connectorResponse._second);
  }

  /**
   * Pool Exhausted Exception<br/>
   *
   * <b>Entrées:</b>Pool Exhausted Exception<br/>
   * <b>Attendu:</b>Retour=KO<br/>
   *
   * @throws Exception
   *           On unexpected error
   */
  @Test
  public void testUpdateSimEtatMocImsi_KO_02() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String imsi_p = "imsi_p"; //$NON-NLS-1$
    String etatMoc_p = "etatMoc_p"; //$NON-NLS-1$

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_MAJ_PREPROVMOC_IMSI(?,?,?,?,?,?) }")).andThrow(new PoolExhaustedException()); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<Nothing, Retour> connectorResponse = _pgSpirit.updateSimEtatMocImsi(tracabilite, imsi_p, etatMoc_p);

    // Asserts
    Retour retourExpected = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString("GDRConnector.ERREUR_GDR_AUCUNE_SESSION")); //$NON-NLS-1$

    assertNull(connectorResponse._first);
    assertEquals(retourExpected, connectorResponse._second);
  }

  /**
   * SQL Recoverable Exception<br/>
   *
   * <b>Entrées:</b>SQL Recoverable Exception<br/>
   * <b>Attendu:</b>Retour=KO<br/>
   *
   * @throws Exception
   *           On unexpected error
   */
  @Test
  public void testUpdateSimEtatMocImsi_KO_03() throws Exception
  {
    // Request variables
    Tracabilite tracabilite = new Tracabilite();
    String imsi_p = "imsi_p"; //$NON-NLS-1$
    String etatMoc_p = "etatMoc_p"; //$NON-NLS-1$

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_MAJ_PREPROVMOC_IMSI(?,?,?,?,?,?) }")).andThrow(new SQLRecoverableException()); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<Nothing, Retour> connectorResponse = _pgSpirit.updateSimEtatMocImsi(tracabilite, imsi_p, etatMoc_p);

    // Asserts
    Retour retourExpected = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString("GDRConnector.ERREUR_GDR_TIMEOUT_CONNEXION"), 4)); //$NON-NLS-1$

    assertNull(connectorResponse._first);
    assertEquals(retourExpected, connectorResponse._second);
  }

  /**
   * SQL Exception<br/>
   *
   * <b>Entrées:</b>SQL Exception<br/>
   * <b>Attendu:</b>Retour=KO<br/>
   *
   * @throws Exception
   *           On unexpected error
   */
  @Test
  public void testUpdateSimEtatMocImsi_KO_04() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String imsi_p = "imsi_p"; //$NON-NLS-1$
    String etatMoc_p = "etatMoc_p"; //$NON-NLS-1$

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_MAJ_PREPROVMOC_IMSI(?,?,?,?,?,?) }")).andThrow(new SQLException()); //$NON-NLS-1$
    PowerMock.replay(_connection);

    ConnectorResponse<Nothing, Retour> connectorResponse = new ConnectorResponse<>(null, null);
    try
    {
      connectorResponse = _pgSpirit.updateSimEtatMocImsi(tracabilite, imsi_p, etatMoc_p);
    }
    catch (Exception ex)
    {
      assertNull(connectorResponse._second);
      String errorMessage = "Technical Exception in GDRConnector during PG_SPIRIT.P_MAJ_PREPROVMOC_IMSI call: code(0) reason(null) at GDRPGSpirit.java"; //$NON-NLS-1$
      assertTrue(ex.getMessage().contains(errorMessage));
    }
  }

  /**
   * Nominal test case<br/>
   *
   * <b>Entrées:</b>2 variables<br/>
   * <b>Attendu:</b>Retour=OK<br/>
   *
   * @throws Exception
   *           On unexpected error
   */
  @Test
  public void testUpdateSimEtatMocImsi_OK() throws Exception
  {
    // Request
    Tracabilite tracabilite = new Tracabilite();
    String imsi_p = "imsi_p"; //$NON-NLS-1$
    String etatMoc_p = "etatMoc_p"; //$NON-NLS-1$

    // Setup mocks
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$
    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_MAJ_PREPROVMOC_IMSI(?,?,?,?,?,?) }")).andReturn(_callableStatement); //$NON-NLS-1$
    PowerMock.replay(_connection);

    // Call connector
    ConnectorResponse<Nothing, Retour> connectorResponse = _pgSpirit.updateSimEtatMocImsi(tracabilite, imsi_p, etatMoc_p);

    // Asserts
    assertEquals(RetourFactory.createOkRetour(), connectorResponse._second);
  }
}
