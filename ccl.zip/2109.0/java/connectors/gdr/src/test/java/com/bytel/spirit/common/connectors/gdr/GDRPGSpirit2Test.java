/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.gdr;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLRecoverableException;
import java.sql.SQLTimeoutException;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.apache.tomcat.jdbc.pool.DataSource;
import org.apache.tomcat.jdbc.pool.PoolExhaustedException;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.modules.junit4.PowerMockRunner;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.RetourFactoryForTU;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.connectors.gdr.structs.ICallbackLireSim;
import com.bytel.spirit.common.connectors.gdr.structs.Policy;
import com.bytel.spirit.common.connectors.gdr.structs.Sim;
import com.bytel.spirit.common.connectors.gdr.structs.enumeration.EtatSMDP;
import com.bytel.spirit.common.connectors.gdr.structs.enumeration.PolicyAction;
import com.bytel.spirit.common.connectors.gdr.structs.enumeration.PolicyQualification;
import com.bytel.spirit.common.connectors.gdr.utils.GDRPGSpirit;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

import oracle.jdbc.OracleTypes;

/**
 * A second class for testing the methods from GDR Connector that are from PG_SPIRIT.
 * 
 * @author $Author$
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PowerMockIgnore("javax.management.*") //$NON-NLS-1$
public class GDRPGSpirit2Test
{
  /**
   * Callback used by getEsimProfileStatus.
   */
  static class GetEsimProfileStatusCallback implements ICallbackLireSim
  {
    List<List<Sim>> _listSimList = new ArrayList<>();
    Retour _retour;

    /**
     * @param retour_p
     *          the desired retour for the callback.
     */
    public GetEsimProfileStatusCallback(Retour retour_p)
    {
      _retour = retour_p;
    }

    @Override
    public Retour consume(Tracabilite tracabilite_p, List<Sim> simList_p)
    {
      _listSimList.add(new ArrayList<>(simList_p));
      return _retour;
    }
  }

  private GDRPGSpirit _pgSpirit;

  @MockStrict
  DataSource _datasource;

  @MockStrict
  Connection _connection;

  @MockStrict
  CallableStatement _callableStatement;

  @MockStrict
  ResultSet _resultSet;

  /**
   * Run before each test.
   * 
   * @throws Exception
   *           on error.
   */
  @Before
  public void beforeEach() throws Exception
  {
    EasyMock.expect(_datasource.getConnection()).andReturn(_connection);

    _pgSpirit = new GDRPGSpirit(_datasource, 1, 4, null);
  }

  /**
   * NOK, procedure throws SQLTimeoutException.
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void test_getEsimProfileStatus_NOK_01() throws Exception
  {
    // The expected results
    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT1, "INSERTION_FAILED", "Erreur GDR : timeout sur non reponse du serveur base GDR au bout de 1 secondes"); //$NON-NLS-1$ //$NON-NLS-2$

    // Create the request
    Tracabilite tracabilite = new Tracabilite();
    String simType = "simType"; //$NON-NLS-1$
    String profileType = "profileType"; //$NON-NLS-1$

    // Prepare the mocks for the calls made by the connector
    // Prepare the prepare call
    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_ESIM_PROFIL_STATUS(?,?,?,?,?,?,?)}")).andThrow(new SQLTimeoutException()); //$NON-NLS-1$

    // Prepare the closing
    _connection.close();

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<Nothing, Retour> connectorResponse = _pgSpirit.getEsimProfileStatus(tracabilite, simType, profileType, null, 2);

    // Verify the results
    PowerMock.verifyAll();

    assertEquals(expectedRetour, connectorResponse._second);
  }

  /**
   * NOK, procedure throws PoolExhaustedException.
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void test_getEsimProfileStatus_NOK_02() throws Exception
  {
    // The expected results
    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT1, "SESSION_UNAVAILABLE", "Erreur GDR : aucune session base GDR persistante disponible"); //$NON-NLS-1$ //$NON-NLS-2$

    // Create the request
    Tracabilite tracabilite = new Tracabilite();
    String simType = "simType"; //$NON-NLS-1$
    String profileType = "profileType"; //$NON-NLS-1$

    // Prepare the mocks for the calls made by the connector
    // Prepare the prepare call
    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_ESIM_PROFIL_STATUS(?,?,?,?,?,?,?)}")).andThrow(new PoolExhaustedException()); //$NON-NLS-1$

    // Prepare the closing
    _connection.close();

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<Nothing, Retour> connectorResponse = _pgSpirit.getEsimProfileStatus(tracabilite, simType, profileType, null, 2);

    // Verify the results
    PowerMock.verifyAll();

    assertEquals(expectedRetour, connectorResponse._second);
  }

  /**
   * NOK, procedure throws SQLRecoverableException.
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void test_getEsimProfileStatus_NOK_03() throws Exception
  {
    // The expected results
    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT1, "CONNEXION_FAILED", "Erreur GDR: timeout connexion à la base GDR au bout de 4 secondes"); //$NON-NLS-1$ //$NON-NLS-2$

    // Create the request
    Tracabilite tracabilite = new Tracabilite();
    String simType = "simType"; //$NON-NLS-1$
    String profileType = "profileType"; //$NON-NLS-1$

    // Prepare the mocks for the calls made by the connector
    // Prepare the prepare call
    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_ESIM_PROFIL_STATUS(?,?,?,?,?,?,?)}")).andThrow(new SQLRecoverableException()); //$NON-NLS-1$

    // Prepare the closing
    _connection.close();

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<Nothing, Retour> connectorResponse = _pgSpirit.getEsimProfileStatus(tracabilite, simType, profileType, null, 2);

    // Verify the results
    PowerMock.verifyAll();

    assertEquals(expectedRetour, connectorResponse._second);
  }

  /**
   * NOK, procedure throws SQLException.
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void test_getEsimProfileStatus_NOK_04() throws Exception
  {
    // Create the request
    Tracabilite tracabilite = new Tracabilite();
    String simType = "simType"; //$NON-NLS-1$
    String profileType = "profileType"; //$NON-NLS-1$

    // Prepare the mocks for the calls made by the connector
    // Prepare the prepare call
    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_ESIM_PROFIL_STATUS(?,?,?,?,?,?,?)}")).andThrow(new SQLException()); //$NON-NLS-1$

    // Prepare the closing
    _connection.close();

    PowerMock.replayAll();

    // Call connector
    boolean exceptionCaught = false;

    try
    {
      _pgSpirit.getEsimProfileStatus(tracabilite, simType, profileType, null, 2);
    }
    catch (RavelException exception_p)
    {
      exceptionCaught = true;
    }

    // Verify the results
    PowerMock.verifyAll();

    assertTrue(exceptionCaught);
  }

  /**
   * NOK, procedure returns NOK.
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void test_getEsimProfileStatus_NOK_05() throws Exception
  {
    // The expected results
    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CATEGORIE, IMegConsts.DIAGNOSTIC, IMegConsts.LIBELLE);

    // Create the request
    Tracabilite tracabilite = new Tracabilite();
    String simType = "simType"; //$NON-NLS-1$
    String profileType = "profileType"; //$NON-NLS-1$

    // Prepare the mocks for the calls made by the connector
    // Prepare the prepare call
    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_ESIM_PROFIL_STATUS(?,?,?,?,?,?,?)}")).andReturn(_callableStatement); //$NON-NLS-1$

    // Prepare the parameters
    _callableStatement.setQueryTimeout(1);

    _callableStatement.setString("pi_typeSim", simType); //$NON-NLS-1$
    _callableStatement.setString("pi_profileType", profileType); //$NON-NLS-1$
    _callableStatement.registerOutParameter("po_RESULT", OracleTypes.CURSOR); //$NON-NLS-1$
    _callableStatement.registerOutParameter("Retour_Resultat", OracleTypes.NVARCHAR); //$NON-NLS-1$
    _callableStatement.registerOutParameter("Retour_Categorie", OracleTypes.NVARCHAR); //$NON-NLS-1$
    _callableStatement.registerOutParameter("Retour_Diagnostic", OracleTypes.NVARCHAR); //$NON-NLS-1$
    _callableStatement.registerOutParameter("Retour_Libelle", OracleTypes.NVARCHAR); //$NON-NLS-1$

    // Prepare the execution
    EasyMock.expect(_callableStatement.execute()).andReturn(true);

    // Prepare the response
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.NOK); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString("Retour_Categorie")).andReturn(IMegConsts.CATEGORIE); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString("Retour_Diagnostic")).andReturn(IMegConsts.DIAGNOSTIC); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString("Retour_Libelle")).andReturn(IMegConsts.LIBELLE); //$NON-NLS-1$

    // Prepare the closing
    _callableStatement.close();
    _connection.close();

    PowerMock.replayAll();

    // Call connector
    ConnectorResponse<Nothing, Retour> connectorResponse = _pgSpirit.getEsimProfileStatus(tracabilite, simType, profileType, null, 2);

    // Verify the results
    PowerMock.verifyAll();

    assertEquals(expectedRetour, connectorResponse._second);
  }

  /**
   * NOK, consume returns NOK.
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void test_getEsimProfileStatus_NOK_06() throws Exception
  {
    // The expected results
    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CATEGORIE, IMegConsts.DIAGNOSTIC, IMegConsts.LIBELLE);

    Sim sim1 = new Sim();
    sim1.setSim("iccid1"); //$NON-NLS-1$
    sim1.setTypeProfile("profile_type1"); //$NON-NLS-1$
    sim1.setEtasmdp(EtatSMDP.DOWNLOAD);
    sim1.setEtanotif("etat_notif1"); //$NON-NLS-1$
    sim1.setDateta(new Timestamp(LocalDate.of(2020, 1, 1).toEpochDay()));
    sim1.setEid("eid1"); //$NON-NLS-1$
    sim1.setPolicies(new Policy(null, PolicyAction.ENABLE, PolicyQualification.AUTO_DELETE));

    Sim sim2 = new Sim();
    sim2.setSim("iccid2"); //$NON-NLS-1$
    sim2.setTypeProfile("profile_type2"); //$NON-NLS-1$
    sim2.setEtasmdp(EtatSMDP.DELETE);
    sim2.setEtanotif("etat_notif2"); //$NON-NLS-1$
    sim2.setDateta(new Timestamp(LocalDate.of(2020, 2, 2).toEpochDay()));
    sim2.setEid("eid2"); //$NON-NLS-1$
    sim2.setPolicies(new Policy(null, PolicyAction.DELETE, PolicyQualification.NOT_ALLOWED));

    List<Sim> simList1 = new ArrayList<>();
    simList1.add(sim1);
    simList1.add(sim2);

    List<List<Sim>> expectedList = new ArrayList<>();
    expectedList.add(simList1);

    // Create the request
    Tracabilite tracabilite = new Tracabilite();
    String simType = "simType"; //$NON-NLS-1$
    String profileType = "profileType"; //$NON-NLS-1$

    // Prepare the mocks for the calls made by the connector
    // Prepare the prepare call
    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_ESIM_PROFIL_STATUS(?,?,?,?,?,?,?)}")).andReturn(_callableStatement); //$NON-NLS-1$

    // Prepare the parameters
    _callableStatement.setQueryTimeout(1);

    _callableStatement.setString("pi_typeSim", simType); //$NON-NLS-1$
    _callableStatement.setString("pi_profileType", profileType); //$NON-NLS-1$
    _callableStatement.registerOutParameter("po_RESULT", OracleTypes.CURSOR); //$NON-NLS-1$
    _callableStatement.registerOutParameter("Retour_Resultat", OracleTypes.NVARCHAR); //$NON-NLS-1$
    _callableStatement.registerOutParameter("Retour_Categorie", OracleTypes.NVARCHAR); //$NON-NLS-1$
    _callableStatement.registerOutParameter("Retour_Diagnostic", OracleTypes.NVARCHAR); //$NON-NLS-1$
    _callableStatement.registerOutParameter("Retour_Libelle", OracleTypes.NVARCHAR); //$NON-NLS-1$

    // Prepare the execution
    EasyMock.expect(_callableStatement.execute()).andReturn(true);

    // Prepare the response
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString("Retour_Categorie")).andReturn(null); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString("Retour_Diagnostic")).andReturn(null); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString("Retour_Libelle")).andReturn(null); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getObject("po_RESULT")).andReturn(_resultSet); //$NON-NLS-1$

    // Prepare for the getting of the results
    EasyMock.expect(_resultSet.next()).andReturn(true);

    EasyMock.expect(_resultSet.getString("ICCID")).andReturn("iccid1"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("PROFILE_TYPE")).andReturn("profile_type1"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("ETAT_PROFIL")).andReturn("download"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("ETAT_NOTIF")).andReturn("etat_notif1"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getTimestamp("DATETA")).andReturn(new Timestamp(LocalDate.of(2020, 1, 1).toEpochDay())); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getString("EID")).andReturn("eid1"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("POLICYETAT")).andReturn("ENABLE"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("POLICYHABILITATION")).andReturn("Auto-Delete"); //$NON-NLS-1$ //$NON-NLS-2$

    EasyMock.expect(_resultSet.next()).andReturn(true);

    EasyMock.expect(_resultSet.getString("ICCID")).andReturn("iccid2"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("PROFILE_TYPE")).andReturn("profile_type2"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("ETAT_PROFIL")).andReturn("delete"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("ETAT_NOTIF")).andReturn("etat_notif2"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getTimestamp("DATETA")).andReturn(new Timestamp(LocalDate.of(2020, 2, 2).toEpochDay())); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getString("EID")).andReturn("eid2"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("POLICYETAT")).andReturn("DELETE"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("POLICYHABILITATION")).andReturn("Not-Allowed"); //$NON-NLS-1$ //$NON-NLS-2$

    // Prepare the closing
    _callableStatement.close();
    _connection.close();

    PowerMock.replayAll();

    // Call connector
    GetEsimProfileStatusCallback callback = new GetEsimProfileStatusCallback(RetourFactoryForTU.createNOK(IMegConsts.CATEGORIE, IMegConsts.DIAGNOSTIC, IMegConsts.LIBELLE));

    ConnectorResponse<Nothing, Retour> connectorResponse = _pgSpirit.getEsimProfileStatus(tracabilite, simType, profileType, callback, 2);

    // Verify the results
    PowerMock.verifyAll();

    assertEquals(expectedRetour, connectorResponse._second);
    assertEquals(expectedList, callback._listSimList);
  }

  /**
   * NOK, last consume returns NOK.
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void test_getEsimProfileStatus_NOK_07() throws Exception
  {
    // The expected results
    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CATEGORIE, IMegConsts.DIAGNOSTIC, IMegConsts.LIBELLE);

    Sim sim1 = new Sim();
    sim1.setSim("iccid1"); //$NON-NLS-1$
    sim1.setTypeProfile("profile_type1"); //$NON-NLS-1$
    sim1.setEtasmdp(EtatSMDP.DOWNLOAD);
    sim1.setEtanotif("etat_notif1"); //$NON-NLS-1$
    sim1.setDateta(new Timestamp(LocalDate.of(2020, 1, 1).toEpochDay()));
    sim1.setEid("eid1"); //$NON-NLS-1$
    sim1.setPolicies(new Policy(null, PolicyAction.ENABLE, PolicyQualification.AUTO_DELETE));

    Sim sim2 = new Sim();
    sim2.setSim("iccid2"); //$NON-NLS-1$
    sim2.setTypeProfile("profile_type2"); //$NON-NLS-1$
    sim2.setEtasmdp(EtatSMDP.DELETE);
    sim2.setEtanotif("etat_notif2"); //$NON-NLS-1$
    sim2.setDateta(new Timestamp(LocalDate.of(2020, 2, 2).toEpochDay()));
    sim2.setEid("eid2"); //$NON-NLS-1$
    sim2.setPolicies(new Policy(null, PolicyAction.DELETE, PolicyQualification.NOT_ALLOWED));

    Sim sim3 = new Sim();
    sim3.setSim("iccid3"); //$NON-NLS-1$
    sim3.setTypeProfile("profile_type3"); //$NON-NLS-1$
    sim3.setEtasmdp(EtatSMDP.DOWNLOAD_DISABLE);
    sim3.setEtanotif("etat_notif3"); //$NON-NLS-1$
    sim3.setDateta(new Timestamp(LocalDate.of(2020, 3, 3).toEpochDay()));
    sim3.setEid("eid3"); //$NON-NLS-1$
    sim3.setPolicies(new Policy(null, PolicyAction.DISABLE, PolicyQualification.NOT_ALLOWED));

    List<Sim> simList1 = new ArrayList<>();
    simList1.add(sim1);
    simList1.add(sim2);
    simList1.add(sim3);

    List<List<Sim>> expectedList = new ArrayList<>();
    expectedList.add(simList1);

    // Create the request
    Tracabilite tracabilite = new Tracabilite();
    String simType = "simType"; //$NON-NLS-1$
    String profileType = "profileType"; //$NON-NLS-1$

    // Prepare the mocks for the calls made by the connector
    // Prepare the prepare call
    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_ESIM_PROFIL_STATUS(?,?,?,?,?,?,?)}")).andReturn(_callableStatement); //$NON-NLS-1$

    // Prepare the parameters
    _callableStatement.setQueryTimeout(1);

    _callableStatement.setString("pi_typeSim", simType); //$NON-NLS-1$
    _callableStatement.setString("pi_profileType", profileType); //$NON-NLS-1$
    _callableStatement.registerOutParameter("po_RESULT", OracleTypes.CURSOR); //$NON-NLS-1$
    _callableStatement.registerOutParameter("Retour_Resultat", OracleTypes.NVARCHAR); //$NON-NLS-1$
    _callableStatement.registerOutParameter("Retour_Categorie", OracleTypes.NVARCHAR); //$NON-NLS-1$
    _callableStatement.registerOutParameter("Retour_Diagnostic", OracleTypes.NVARCHAR); //$NON-NLS-1$
    _callableStatement.registerOutParameter("Retour_Libelle", OracleTypes.NVARCHAR); //$NON-NLS-1$

    // Prepare the execution
    EasyMock.expect(_callableStatement.execute()).andReturn(true);

    // Prepare the response
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString("Retour_Categorie")).andReturn(null); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString("Retour_Diagnostic")).andReturn(null); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString("Retour_Libelle")).andReturn(null); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getObject("po_RESULT")).andReturn(_resultSet); //$NON-NLS-1$

    // Prepare for the getting of the results
    EasyMock.expect(_resultSet.next()).andReturn(true);

    EasyMock.expect(_resultSet.getString("ICCID")).andReturn("iccid1"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("PROFILE_TYPE")).andReturn("profile_type1"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("ETAT_PROFIL")).andReturn("download"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("ETAT_NOTIF")).andReturn("etat_notif1"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getTimestamp("DATETA")).andReturn(new Timestamp(LocalDate.of(2020, 1, 1).toEpochDay())); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getString("EID")).andReturn("eid1"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("POLICYETAT")).andReturn("ENABLE"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("POLICYHABILITATION")).andReturn("Auto-Delete"); //$NON-NLS-1$ //$NON-NLS-2$

    EasyMock.expect(_resultSet.next()).andReturn(true);

    EasyMock.expect(_resultSet.getString("ICCID")).andReturn("iccid2"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("PROFILE_TYPE")).andReturn("profile_type2"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("ETAT_PROFIL")).andReturn("delete"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("ETAT_NOTIF")).andReturn("etat_notif2"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getTimestamp("DATETA")).andReturn(new Timestamp(LocalDate.of(2020, 2, 2).toEpochDay())); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getString("EID")).andReturn("eid2"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("POLICYETAT")).andReturn("DELETE"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("POLICYHABILITATION")).andReturn("Not-Allowed"); //$NON-NLS-1$ //$NON-NLS-2$

    EasyMock.expect(_resultSet.next()).andReturn(true);

    EasyMock.expect(_resultSet.getString("ICCID")).andReturn("iccid3"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("PROFILE_TYPE")).andReturn("profile_type3"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("ETAT_PROFIL")).andReturn("downloadDisable"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("ETAT_NOTIF")).andReturn("etat_notif3"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getTimestamp("DATETA")).andReturn(new Timestamp(LocalDate.of(2020, 3, 3).toEpochDay())); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getString("EID")).andReturn("eid3"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("POLICYETAT")).andReturn("DISABLE"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("POLICYHABILITATION")).andReturn("Not-Allowed"); //$NON-NLS-1$ //$NON-NLS-2$

    EasyMock.expect(_resultSet.next()).andReturn(false);

    // Prepare the closing
    _callableStatement.close();
    _connection.close();

    PowerMock.replayAll();

    // Call connector
    GetEsimProfileStatusCallback callback = new GetEsimProfileStatusCallback(RetourFactoryForTU.createNOK(IMegConsts.CATEGORIE, IMegConsts.DIAGNOSTIC, IMegConsts.LIBELLE));

    ConnectorResponse<Nothing, Retour> connectorResponse = _pgSpirit.getEsimProfileStatus(tracabilite, simType, profileType, callback, 4);

    // Verify the results
    PowerMock.verifyAll();

    assertEquals(expectedRetour, connectorResponse._second);
    assertEquals(expectedList, callback._listSimList);
  }

  /**
   * OK.
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void test_getEsimProfileStatus_OK() throws Exception
  {
    // The expected results
    Retour expectedRetour = RetourFactoryForTU.createOkRetour();

    Sim sim1 = new Sim();
    sim1.setSim("iccid1"); //$NON-NLS-1$
    sim1.setTypeProfile("profile_type1"); //$NON-NLS-1$
    sim1.setEtasmdp(EtatSMDP.DOWNLOAD);
    sim1.setEtanotif("etat_notif1"); //$NON-NLS-1$
    sim1.setDateta(new Timestamp(LocalDate.of(2020, 1, 1).toEpochDay()));
    sim1.setEid("eid1"); //$NON-NLS-1$
    sim1.setPolicies(new Policy(null, PolicyAction.ENABLE, PolicyQualification.AUTO_DELETE));

    Sim sim2 = new Sim();
    sim2.setSim("iccid2"); //$NON-NLS-1$
    sim2.setTypeProfile("profile_type2"); //$NON-NLS-1$
    sim2.setEtasmdp(EtatSMDP.DELETE);
    sim2.setEtanotif("etat_notif2"); //$NON-NLS-1$
    sim2.setDateta(new Timestamp(LocalDate.of(2020, 2, 2).toEpochDay()));
    sim2.setEid("eid2"); //$NON-NLS-1$
    sim2.setPolicies(new Policy(null, PolicyAction.DELETE, PolicyQualification.NOT_ALLOWED));

    List<Sim> simList1 = new ArrayList<>();
    simList1.add(sim1);
    simList1.add(sim2);

    Sim sim3 = new Sim();
    sim3.setSim("iccid3"); //$NON-NLS-1$
    sim3.setTypeProfile("profile_type3"); //$NON-NLS-1$
    sim3.setEtasmdp(EtatSMDP.DOWNLOAD_DISABLE);
    sim3.setEtanotif("etat_notif3"); //$NON-NLS-1$
    sim3.setDateta(new Timestamp(LocalDate.of(2020, 3, 3).toEpochDay()));
    sim3.setEid("eid3"); //$NON-NLS-1$
    sim3.setPolicies(new Policy(null, PolicyAction.DISABLE, PolicyQualification.NOT_ALLOWED));

    List<Sim> simList2 = new ArrayList<>();
    simList2.add(sim3);

    List<List<Sim>> expectedList = new ArrayList<>();
    expectedList.add(simList1);
    expectedList.add(simList2);

    // Create the request
    Tracabilite tracabilite = new Tracabilite();
    String simType = "simType"; //$NON-NLS-1$
    String profileType = "profileType"; //$NON-NLS-1$

    // Prepare the mocks for the calls made by the connector
    // Prepare the prepare call
    EasyMock.expect(_connection.prepareCall("{call PG_SPIRIT.P_GET_ESIM_PROFIL_STATUS(?,?,?,?,?,?,?)}")).andReturn(_callableStatement); //$NON-NLS-1$

    // Prepare the parameters
    _callableStatement.setQueryTimeout(1);

    _callableStatement.setString("pi_typeSim", simType); //$NON-NLS-1$
    _callableStatement.setString("pi_profileType", profileType); //$NON-NLS-1$
    _callableStatement.registerOutParameter("po_RESULT", OracleTypes.CURSOR); //$NON-NLS-1$
    _callableStatement.registerOutParameter("Retour_Resultat", OracleTypes.NVARCHAR); //$NON-NLS-1$
    _callableStatement.registerOutParameter("Retour_Categorie", OracleTypes.NVARCHAR); //$NON-NLS-1$
    _callableStatement.registerOutParameter("Retour_Diagnostic", OracleTypes.NVARCHAR); //$NON-NLS-1$
    _callableStatement.registerOutParameter("Retour_Libelle", OracleTypes.NVARCHAR); //$NON-NLS-1$

    // Prepare the execution
    EasyMock.expect(_callableStatement.execute()).andReturn(true);

    // Prepare the response
    EasyMock.expect(_callableStatement.getString("Retour_Resultat")).andReturn(StringConstants.OK); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString("Retour_Categorie")).andReturn(null); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString("Retour_Diagnostic")).andReturn(null); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString("Retour_Libelle")).andReturn(null); //$NON-NLS-1$
    EasyMock.expect(_callableStatement.getObject("po_RESULT")).andReturn(_resultSet); //$NON-NLS-1$

    // Prepare for the getting of the results
    EasyMock.expect(_resultSet.next()).andReturn(true);

    EasyMock.expect(_resultSet.getString("ICCID")).andReturn("iccid1"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("PROFILE_TYPE")).andReturn("profile_type1"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("ETAT_PROFIL")).andReturn("download"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("ETAT_NOTIF")).andReturn("etat_notif1"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getTimestamp("DATETA")).andReturn(new Timestamp(LocalDate.of(2020, 1, 1).toEpochDay())); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getString("EID")).andReturn("eid1"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("POLICYETAT")).andReturn("ENABLE"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("POLICYHABILITATION")).andReturn("Auto-Delete"); //$NON-NLS-1$ //$NON-NLS-2$

    EasyMock.expect(_resultSet.next()).andReturn(true);

    EasyMock.expect(_resultSet.getString("ICCID")).andReturn("iccid2"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("PROFILE_TYPE")).andReturn("profile_type2"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("ETAT_PROFIL")).andReturn("delete"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("ETAT_NOTIF")).andReturn("etat_notif2"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getTimestamp("DATETA")).andReturn(new Timestamp(LocalDate.of(2020, 2, 2).toEpochDay())); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getString("EID")).andReturn("eid2"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("POLICYETAT")).andReturn("DELETE"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("POLICYHABILITATION")).andReturn("Not-Allowed"); //$NON-NLS-1$ //$NON-NLS-2$

    EasyMock.expect(_resultSet.next()).andReturn(true);

    EasyMock.expect(_resultSet.getString("ICCID")).andReturn("iccid3"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("PROFILE_TYPE")).andReturn("profile_type3"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("ETAT_PROFIL")).andReturn("downloadDisable"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("ETAT_NOTIF")).andReturn("etat_notif3"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getTimestamp("DATETA")).andReturn(new Timestamp(LocalDate.of(2020, 3, 3).toEpochDay())); //$NON-NLS-1$
    EasyMock.expect(_resultSet.getString("EID")).andReturn("eid3"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("POLICYETAT")).andReturn("DISABLE"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSet.getString("POLICYHABILITATION")).andReturn("Not-Allowed"); //$NON-NLS-1$ //$NON-NLS-2$

    EasyMock.expect(_resultSet.next()).andReturn(false);

    // Prepare the closing
    _callableStatement.close();
    _connection.close();

    PowerMock.replayAll();

    // Call connector
    GetEsimProfileStatusCallback callback = new GetEsimProfileStatusCallback(RetourFactoryForTU.createOkRetour());

    ConnectorResponse<Nothing, Retour> connectorResponse = _pgSpirit.getEsimProfileStatus(tracabilite, simType, profileType, callback, 2);

    // Verify the results
    PowerMock.verifyAll();

    assertEquals(expectedRetour, connectorResponse._second);
    assertEquals(expectedList, callback._listSimList);
  }
}
