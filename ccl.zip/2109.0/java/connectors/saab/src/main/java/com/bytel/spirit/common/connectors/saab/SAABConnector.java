/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.saab;

import java.net.HttpURLConnection;

import javax.ws.rs.core.Response;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.Pair;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.services.conf.connector.generated.Connector;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.connector.RESTRequest;
import com.bytel.spirit.common.connectors.saab.structs.SAABResponse;
import com.bytel.spirit.common.shared.functional.types.json.RavelJsonTools;
import com.bytel.spirit.common.shared.misc.connectors.AbstractInternalRESTConnector;
import com.bytel.spirit.common.shared.misc.error.ReponseErreur;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.google.gson.Gson;

/**
 *
 * @author jgregori
 * @version ($Revision$ $Date$)
 */
public class SAABConnector extends AbstractInternalRESTConnector implements ISAABConnector
{

  @Override
  public String getConfigParameter(String connectorID_p, String paramName_p) throws RavelException
  {
    return null;
  }

  @Override
  public void loadConnectorConfiguration(Connector connector_p) throws RavelException
  {
    super.loadConnectorConfiguration(connector_p);
  }

  @Override
  public <T> ConnectorResponse<Retour, SAABResponse<T>> sendRequest(RESTRequest restRequest_p, Class<T> responseClass_p) throws RavelException
  {
    try
    {
      // Call STARK FrontEnd
      final Response response;
      try
      {
        response = sendRequest(restRequest_p);
      }
      catch (Exception e)
      {
        // Retour KO
        RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, (Tracabilite) restRequest_p.getTraceability(), e));
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e.getMessage()), null);
      }

      Pair<Retour, SAABResponse<T>> saabResponse = deserializeResponse(response, responseClass_p, restRequest_p);
      return new ConnectorResponse<>(saabResponse._first, saabResponse._second);
    }
    catch (Exception e)
    {
      // Retour KO
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, (Tracabilite) restRequest_p.getTraceability(), e));
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e.getMessage()), null);
    }
  }

  /**
   * Deserialize response as ReponseErreur
   *
   * @param jsonResponse
   *          String json representing ReponseErreur object
   * @param restRequest_p
   *          rest request
   * @return ReponseErreur object
   */
  private ReponseErreur deserializeAsError(String jsonResponse, RESTRequest restRequest_p)
  {
    ReponseErreur responseError;
    try
    {
      //Try to deserialize as error
      if ((restRequest_p.getSerializer() != null) && (restRequest_p.getSerializer() instanceof Gson))
      {
        Gson gsonParser = (Gson) restRequest_p.getSerializer();
        responseError = gsonParser.fromJson(jsonResponse, ReponseErreur.class);
      }
      else // moshi
      {
        responseError = RavelJsonTools.getInstance().fromJson(jsonResponse, ReponseErreur.class);
      }
    }
    catch (Exception e)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, (Tracabilite) restRequest_p.getTraceability(), e));
      responseError = null;
    }
    return responseError;
  }

  /**
   * Deserializes a Response object.
   *
   * @param response_p
   *          The response object to deserialize
   * @return SAABResponse
   * @throws RavelException
   *           In case of deserialization errors.
   */
  private <T> Pair<Retour, SAABResponse<T>> deserializeResponse(final Response response_p, final Class<T> responseClass_p, RESTRequest restRequest_p) throws RavelException
  {
    // Get the content to a JSON string
    String jsonResponse = getContent(response_p, restRequest_p.getPath(), (Tracabilite) restRequest_p.getTraceability());

    Retour retour = RetourFactory.createOkRetour();
    T responseObj = null;
    ReponseErreur responseError = null;
    //try to deserialize response as extected object
    if ((response_p.getStatus() == HttpURLConnection.HTTP_OK) || (response_p.getStatus() == HttpURLConnection.HTTP_CREATED) || (response_p.getStatus() == HttpURLConnection.HTTP_ACCEPTED))
    {
      if ((restRequest_p.getSerializer() != null) && (restRequest_p.getSerializer() instanceof Gson))
      {
        Gson gsonParser = (Gson) restRequest_p.getSerializer();
        responseObj = gsonParser.fromJson(jsonResponse, responseClass_p);
      }
      else // moshi
      {
        responseObj = RavelJsonTools.getInstance().fromJson(jsonResponse, responseClass_p);
      }
    }
    else if (response_p.getStatus() != HttpURLConnection.HTTP_NO_CONTENT)
    {
      retour = RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, "Error response code received:" + response_p.getStatus());
      responseError = deserializeAsError(jsonResponse, restRequest_p);
    }

    SAABResponse<T> saabResponse = new SAABResponse<>(response_p.getStatus());
    if (responseObj != null)
    {
      saabResponse.setResponse(responseObj);
    }
    if (responseError != null)
    {
      saabResponse.setReponseErreur(responseError);
    }
    return new Pair<Retour, SAABResponse<T>>(retour, saabResponse);
  }
}
