/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.saab.structs;

import java.io.Serializable;

import com.bytel.spirit.common.shared.misc.error.ReponseErreur;

/**
 *
 * @author jgregori
 * @version ($Revision$ $Date$)
 * @param <T>
 *          Type of the Response of STARKConnector
 */
public final class SAABResponse<T> implements Serializable
{

  /**
   * UUID
   */
  private static final long serialVersionUID = -8130910660764929690L;

  /**
   * Code HTTP in response
   */
  private int _httpStatusCode;
  /**
   * Represent the body of the response when the request is treated successfully
   */
  private T _response;

  /**
   * Represent the body of the response in case of error
   */
  private ReponseErreur _reponseErreur;

  /**
   * @param httpStatusCode_p
   *          Status code
   */
  public SAABResponse(int httpStatusCode_p)
  {
    super();
    _httpStatusCode = httpStatusCode_p;
  }

  /**
   * @return the httpStatusCode
   */
  public int getHttpStatusCode()
  {
    return _httpStatusCode;
  }

  /**
   * @return the reponseErreur
   */
  public ReponseErreur getReponseErreur()
  {
    return _reponseErreur;
  }

  /**
   * @return the response
   */
  public T getResponse()
  {
    return _response;
  }

  /**
   * @param httpStatusCode_p
   *          the httpStatusCode to set
   */
  public void setHttpStatusCode(int httpStatusCode_p)
  {
    _httpStatusCode = httpStatusCode_p;
  }

  /**
   * @param reponseErreur_p
   *          the reponseErreur to set
   */
  public void setReponseErreur(ReponseErreur reponseErreur_p)
  {
    _reponseErreur = reponseErreur_p;
  }

  /**
   * @param response_p
   *          the response to set
   */
  public void setResponse(T response_p)
  {
    _response = response_p;
  }
}
