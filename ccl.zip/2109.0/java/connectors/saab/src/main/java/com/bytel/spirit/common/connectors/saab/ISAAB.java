/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.saab;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.connector.RESTRequest;
import com.bytel.spirit.common.connectors.saab.structs.SAABResponse;

/**
 *
 * @author jgregori
 * @version ($Revision$ $Date$)
 */
public interface ISAAB
{

  /**
   * Send a request to the SAAB.
   *
   * @param restRequest_p
   *          rest request
   * @param responseClass_p
   *          response class
   *
   * @return ConnectorResponse
   * @throws RavelException
   *           Exception if thrown
   */
  public <T> ConnectorResponse<Retour, SAABResponse<T>> sendRequest(RESTRequest restRequest_p, Class<T> responseClass_p) throws RavelException;

}
