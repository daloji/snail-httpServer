/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.saab;

import com.bytel.ravel.services.connector.IConnector;

/**
 *
 * @author jgregori
 * @version ($Revision$ $Date$)
 */
public interface ISAABConnector extends ISAAB, IConnector
{

  /**
   * The id to retrieve the connector.
   */
  public String BEAN_ID = "SAABConnector"; //$NON-NLS-1$
}
