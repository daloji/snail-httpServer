/*******************************************************************************
* $Id: RSTConnectorTest.java 37797 2020-06-17 09:30:45Z jsantos $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.rst;

import java.io.ByteArrayInputStream;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.cxf.jaxrs.impl.ResponseBuilderImpl;
import org.easymock.Capture;
import org.easymock.EasyMock;
import org.easymock.EasyMockSupport;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.conf.generated.LoadBalancer;
import com.bytel.ravel.common.conf.generated.Param;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.json.IRavelJson;
import com.bytel.ravel.common.json.IRavelJsonAdapter;
import com.bytel.ravel.common.json.RavelJson.RavelJsonBuilder;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.test.JUnitTools;
import com.bytel.ravel.common.test.podam.JavaTimeManufacturer;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.utils.ACManagerUtil;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.RetourFactoryForTU;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.net.loadbalancing.ILoadBalancer;
import com.bytel.ravel.net.loadbalancing.URLBalancedElement;
import com.bytel.ravel.net.rest.RestConnectorPool;
import com.bytel.ravel.net.rest.RestInstance;
import com.bytel.ravel.services.conf.connector.generated.Connector;
import com.bytel.ravel.services.conf.connector.generated.URL;
import com.bytel.ravel.services.conf.connector.generated.URLS;
import com.bytel.ravel.services.connector.AbstractRESTConnector;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.IDonneesProvisionnees;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.TypePFS;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.mail.DonneesProvisionneesSTPfsMail;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.mail.StPfsMail;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.BasicResponse;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.ressources.RetourConverter;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.rst.ServiceTechnique;
import com.bytel.spirit.common.shared.saab.rst.StLienAllocationCommercial;
import com.bytel.spirit.common.shared.saab.rst.TypeST;
import com.bytel.spirit.common.shared.saab.rst.request.UpdateServiceTechniqueRequest;
import com.bytel.spirit.common.shared.saab.rst.request.UpdateStLienAllocationCommercialRequest;
import com.bytel.spirit.common.shared.saab.rst.request.UpdateStPfsRequest;
import com.bytel.spirit.common.shared.saab.rst.response.GetServiceTechniqueResponse;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author pcarreir
 * @version ($Revision: 37797 $ $Date: 2020-06-17 11:30:45 +0200 (mer. 17 juin 2020) $)
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({})
public class RSTConnectorTest extends EasyMockSupport
{
  /**
   * Path for PAD4000 operation
   */
  private static final String PAD4000_PATH_PARAM = "PAD4000_ServiceTechnique"; //$NON-NLS-1$

  /**
   * Path for PAD4200 operation
   */
  private static final String PAD4200_PATH_PARAM = "PAD4200_StLienAllocationCommercial"; //$NON-NLS-1$

  /**
   * Path for PAD4300 operation
   */
  private static final String PAD4300_PATH_PARAM = "PAD4300_StPfs"; //$NON-NLS-1$

  /**
   * The constant for idSt param
   */
  private static final String PARAM_ID_ST = "idSt"; //$NON-NLS-1$

  /**
   * Message error for Json parse error
   */
  private static final String JSON_ERROR_MESSAGE = Messages.getString("RSTConnector.JsonErrorMessage"); //$NON-NLS-1$

  /**
   * Message error for Json parse error
   */
  private static final String MISSING_CONFIGURATION_PARAMETER_MESSAGE = Messages.getString("RSTConnector.missing_configuration_parameter"); //$NON-NLS-1$

  /**
   * Content-Type constant
   */
  private static final String CONTENT_TYPE = "Content-Type"; //$NON-NLS-1$

  /**
   * The constant for clientOperateur param
   */
  private static final String PARAM_CLIENT_OPERATEUR = "clientOperateur"; //$NON-NLS-1$

  /**
   * The constant for noCompte param
   */
  private static final String PARAM_NO_COMPTE = "noCompte"; //$NON-NLS-1$

  /**
   * The constant for typeStNiveau1 param
   */
  private static final String PARAM_TYPE_ST_NIVEAU1 = "typeStNiveau1"; //$NON-NLS-1$

  /**
   * The constant for typeStNiveau2 param
   */
  private static final String PARAM_TYPE_ST_NIVEAU2 = "typeStNiveau2"; //$NON-NLS-1$

  /**
   * The constant for filtreStatut param
   */
  private static final String PARAM_FILTRE_STATUT = "filtreStatut"; //$NON-NLS-1$

  /**
   * The INACTIF constant
   */
  private static final String INACTIF = "INACTIF"; //$NON-NLS-1$

  /**
   * Class Initialization method
   */
  @BeforeClass
  public static void init()
  {
    ACManagerUtil.resetACManager();
    new ClassPathXmlApplicationContext("classpath:beans.xml"); //$NON-NLS-1$
  }

  /**
   * The service technique endpoint
   */
  private String _serviceTechniqueUrl = "/serviceTechnique"; //$NON-NLS-1$

  /**
   * The st lien allocation commercial endpoint
   */
  private String _stLienAllocationCommercialUrl = "/stLienAllocationCommercial"; //$NON-NLS-1$

  /**
   * The st pfs endpoint
   */
  private String _stPfsUrl = "/stPfs"; //$NON-NLS-1$

  /**
   * Connector to test
   */
  private RSTConnector _rstConnector;

  /**
   * Connector instance
   */
  private Connector _connector;

  /***
   * Mock {@link ILoadBalancer}
   */
  @MockStrict
  ILoadBalancer<URLBalancedElement> _loadBalancerMock;

  /**
   * Mock of connectors pool HTTP
   */
  @MockStrict
  Hashtable<String, RestConnectorPool> _connectorPoolMock;

  /**
   * Factory to generate beans
   */
  private PodamFactory _podam = new PodamFactoryImpl();

  /**
   * The tracabilite
   */
  Tracabilite _tracabilite;

  /**
   * Mock {@link RestConnectorPool}
   */
  @MockStrict
  RestConnectorPool _restConnectorPoolMock;

  /**
   * Mock {@link RestInstance}
   */
  @MockStrict
  RestInstance _restInstanceMock;

  /**
   * Mock {@link URLBalancedElement}
   */
  @MockStrict
  URLBalancedElement _urlBalancedElementMock;

  /**
   * Initialize before tests
   *
   * @throws Exception
   *           Thrown in case of error during switch in attributes of parent class
   */
  @Before
  public void beforeTest() throws Exception
  {
    _podam.getStrategy().setMemoization(false);
    _podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());
    JavaTimeManufacturer.registerPodamFactory(_podam);

    _connector = new Connector();
    initializeConnectorParameters(_connector);
    _connector.setURLS(generateURLS());

    _rstConnector = new RSTConnector();
    _rstConnector.loadConnectorConfiguration(_connector);
    JUnitTools.setInaccessibleFieldValue(_rstConnector, "_loadBalancer", _loadBalancerMock); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_rstConnector, "_connectorPool", _connectorPoolMock); //$NON-NLS-1$
    _tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);

    PowerMock.resetAll();
    PowerMock.mockStaticNice(RestInstance.class);
  }

  /**
   * Test method {@link RSTConnector#loadConnectorConfiguration(Connector)}
   *
   * @throws Exception
   *           Thrown in case of error
   */
  @Test
  public void test_LoadConnectorConfiguration() throws Exception
  {
    // test
    _rstConnector.loadConnectorConfiguration(_connector);

    // assertions
    Assert.assertEquals(_serviceTechniqueUrl, JUnitTools.getInaccessibleFieldValue(_rstConnector, "_serviceTechniqueUrl")); //$NON-NLS-1$
    Assert.assertEquals(_stLienAllocationCommercialUrl, JUnitTools.getInaccessibleFieldValue(_rstConnector, "_stLienAllocationCommercialUrl")); //$NON-NLS-1$
    Assert.assertEquals(_stPfsUrl, JUnitTools.getInaccessibleFieldValue(_rstConnector, "_stPfsUrl")); //$NON-NLS-1$
  }

  /**
   * Test method {@link RSTConnector#loadConnectorConfiguration(Connector)}
   *
   * @throws Exception
   *           Thrown in case of error
   */
  @Test
  public void test_LoadConnectorConfiguration_KO_03() throws Exception
  {
    try
    {
      _connector.getParam().remove(PAD4200_PATH_PARAM);
      // test
      _rstConnector.loadConnectorConfiguration(_connector);
    }
    catch (RavelException ravelException)
    {
      // assertions
      Assert.assertEquals(ravelException.getErrorCode(), ErrorCode.CNCTOR_00020);
      Assert.assertEquals(ravelException.getExceptionType(), ExceptionType.INVALID_CONFIGURATION);
      Assert.assertEquals(ravelException.getMessage(), MessageFormat.format(MISSING_CONFIGURATION_PARAMETER_MESSAGE, PAD4200_PATH_PARAM));
    }
  }

  /**
   * Test method {@link RSTConnector#loadConnectorConfiguration(Connector)}
   *
   * @throws Exception
   *           Thrown in case of error
   */
  @Test
  public void test_LoadConnectorConfiguration_KO_04() throws Exception
  {
    try
    {
      _connector.getParam().remove(PAD4300_PATH_PARAM);
      // test
      _rstConnector.loadConnectorConfiguration(_connector);
    }
    catch (RavelException ravelException)
    {
      // assertions
      Assert.assertEquals(ravelException.getErrorCode(), ErrorCode.CNCTOR_00020);
      Assert.assertEquals(ravelException.getExceptionType(), ExceptionType.INVALID_CONFIGURATION);
      Assert.assertEquals(ravelException.getMessage(), MessageFormat.format(MISSING_CONFIGURATION_PARAMETER_MESSAGE, PAD4300_PATH_PARAM));
    }
  }

  /**
   * Test method {@link RSTConnector#serviceTechniqueLireTousParPfi(Tracabilite, String, String, String, String)}<br>
   * Bad query paramaters - typeStNiveaux2 without typeStNiveaux1
   *
   * @throws Exception
   *           Thrown in case of error
   */
  @Test
  public void test_ServiceTechnique_KO_00() throws Exception
  {
    Retour retourNOK = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegConsts.DONNEE_INVALIDE, "Requete donnees invalides."); //$NON-NLS-1$
    List<ServiceTechnique> listeServiceTechnique = new ArrayList<>();
    String clientOperateur = _podam.manufacturePojo(String.class);
    String noCompte = _podam.manufacturePojo(String.class);
    String typeStNiveaux2 = "techno"; //$NON-NLS-1$
    HashMap<String, String> queryParams = new HashMap<>();

    queryParams.put(PARAM_CLIENT_OPERATEUR, clientOperateur);
    queryParams.put(PARAM_NO_COMPTE, noCompte);
    queryParams.put(PARAM_TYPE_ST_NIVEAU2, typeStNiveaux2);

    com.bytel.ravel.types.Retour retour = new com.bytel.ravel.types.Retour();
    retour.setResultat(StringConstants.NOK);
    retour.setCategorie(IMegConsts.CAT2);
    retour.setDiagnostic(IMegConsts.DONNEE_INVALIDE);
    retour.setLibelle("Requete donnees invalides."); //$NON-NLS-1$
    GetServiceTechniqueResponse getServiceTechniquesResponse = new GetServiceTechniqueResponse(retour, new ArrayList<>());
    final String partnerResponse = this.serializeWithMoshi(getServiceTechniquesResponse, GetServiceTechniqueResponse.class);

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();

    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_serviceTechniqueUrl), EasyMock.anyObject(), EasyMock.eq(queryParams))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    // test
    PowerMock.replayAll();
    _rstConnector.loadConnectorConfiguration(_connector);
    JUnitTools.setInaccessibleFieldValue(_rstConnector, "_loadBalancer", _loadBalancerMock); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_rstConnector, "_connectorPool", _connectorPoolMock); //$NON-NLS-1$
    ConnectorResponse<Retour, List<ServiceTechnique>> connectorResult = _rstConnector.serviceTechniqueLireTousParPfi(_tracabilite, clientOperateur, noCompte, null, typeStNiveaux2);
    PowerMock.verifyAll();

    Assert.assertEquals(connectorResult._first, retourNOK);
    Assert.assertEquals(connectorResult._second, listeServiceTechnique);
  }

  /**
   * Test method {@link RSTConnector#serviceTechniqueLireTousParPfi(Tracabilite, String, String, String, String)}<br>
   * SendRequest returns an empty json.
   *
   * @throws Exception
   *           Thrown in case of error
   */
  @Test
  public void test_ServiceTechnique_KO_01() throws Exception
  {
    Retour ko = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, "Impossible de recuperer la reponse"); //$NON-NLS-1$
    List<ServiceTechnique> listeServiceTechnique = null;
    String clientOperateur = _podam.manufacturePojo(String.class);
    String noCompte = _podam.manufacturePojo(String.class);
    String typeStNiveaux2 = "techno"; //$NON-NLS-1$
    HashMap<String, String> queryParams = new HashMap<>();

    queryParams.put(PARAM_CLIENT_OPERATEUR, clientOperateur);
    queryParams.put(PARAM_NO_COMPTE, noCompte);
    queryParams.put(PARAM_TYPE_ST_NIVEAU2, typeStNiveaux2);

    com.bytel.ravel.types.Retour retour = new com.bytel.ravel.types.Retour();
    retour.setResultat(StringConstants.NOK);
    retour.setCategorie(IMegConsts.CAT2);
    retour.setDiagnostic(IMegConsts.DONNEE_INVALIDE);
    retour.setLibelle("Requete donnees invalides."); //$NON-NLS-1$

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(StringConstants.EMPTY_STRING.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();

    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_serviceTechniqueUrl), EasyMock.anyObject(), EasyMock.eq(queryParams))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    // test
    PowerMock.replayAll();
    _rstConnector.loadConnectorConfiguration(_connector);
    JUnitTools.setInaccessibleFieldValue(_rstConnector, "_loadBalancer", _loadBalancerMock); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_rstConnector, "_connectorPool", _connectorPoolMock); //$NON-NLS-1$
    ConnectorResponse<Retour, List<ServiceTechnique>> connectorResult = _rstConnector.serviceTechniqueLireTousParPfi(_tracabilite, clientOperateur, noCompte, null, typeStNiveaux2);
    PowerMock.verifyAll();

    Assert.assertEquals(connectorResult._first, ko);
    Assert.assertEquals(connectorResult._second, listeServiceTechnique);
  }

  /**
   * Test method {@link RSTConnector#serviceTechniqueLireUn(Tracabilite, String)}<br>
   * Bad query paramaters - typeStNiveaux2 without typeStNiveaux1
   *
   * @throws Exception
   *           Thrown in case of error
   */
  @Test
  public void test_ServiceTechnique_KO_04() throws Exception
  {
    Retour ko = RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.DONNEE_INVALIDE, "Requete donnees invalides."); //$NON-NLS-1$
    List<ServiceTechnique> listeServiceTechnique = new ArrayList<>();
    String idSt = null;
    HashMap<String, String> queryParams = new HashMap<>();

    com.bytel.ravel.types.Retour retour = new com.bytel.ravel.types.Retour();
    retour.setResultat(StringConstants.NOK);
    retour.setCategorie(IMegConsts.CAT2);
    retour.setDiagnostic(IMegConsts.DONNEE_INVALIDE);
    retour.setLibelle("Requete donnees invalides."); //$NON-NLS-1$
    GetServiceTechniqueResponse getServiceTechniquesResponse = new GetServiceTechniqueResponse(retour, new ArrayList<>());
    final String partnerResponse = this.serializeWithMoshi(getServiceTechniquesResponse, GetServiceTechniqueResponse.class);

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();

    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_serviceTechniqueUrl), EasyMock.anyObject(), EasyMock.eq(queryParams))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    // test
    PowerMock.replayAll();
    _rstConnector.loadConnectorConfiguration(_connector);
    JUnitTools.setInaccessibleFieldValue(_rstConnector, "_loadBalancer", _loadBalancerMock); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_rstConnector, "_connectorPool", _connectorPoolMock); //$NON-NLS-1$
    ConnectorResponse<Retour, List<ServiceTechnique>> connectorResult = _rstConnector.serviceTechniqueLireUn(_tracabilite, idSt);
    PowerMock.verifyAll();

    Assert.assertEquals(connectorResult._first, ko);
    Assert.assertEquals(connectorResult._second, listeServiceTechnique);
  }

  /**
   * Test method {@link RSTConnector#serviceTechniqueLireUn(Tracabilite, String)}<br>
   * SendRequest returns an empty json.
   *
   * @throws Exception
   *           Thrown in case of error
   */
  @Test
  public void test_ServiceTechnique_KO_05() throws Exception
  {
    Retour ko = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, "Impossible de recuperer la reponse"); //$NON-NLS-1$
    List<ServiceTechnique> listeServiceTechnique = null;
    String idSt = _podam.manufacturePojo(String.class);

    HashMap<String, String> queryParams = new HashMap<>();
    queryParams.put(PARAM_ID_ST, idSt);

    com.bytel.ravel.types.Retour retour = new com.bytel.ravel.types.Retour();
    retour.setResultat(StringConstants.NOK);
    retour.setCategorie(IMegConsts.CAT2);
    retour.setDiagnostic(IMegConsts.DONNEE_INVALIDE);
    retour.setLibelle("Requete donnees invalides."); //$NON-NLS-1$

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(StringConstants.EMPTY_STRING.getBytes())).header("OOO", "OOO").header("Tracabilite", _tracabilite).build(); //$NON-NLS-1$//$NON-NLS-2$ //$NON-NLS-3$

    // test scenario
    initializeMocksForSendRequest();

    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_serviceTechniqueUrl), EasyMock.anyObject(), EasyMock.eq(queryParams))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    // test
    PowerMock.replayAll();
    _rstConnector.loadConnectorConfiguration(_connector);
    JUnitTools.setInaccessibleFieldValue(_rstConnector, "_loadBalancer", _loadBalancerMock); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_rstConnector, "_connectorPool", _connectorPoolMock); //$NON-NLS-1$
    ConnectorResponse<Retour, List<ServiceTechnique>> connectorResult = _rstConnector.serviceTechniqueLireUn(_tracabilite, idSt);
    PowerMock.verifyAll();

    Assert.assertEquals(connectorResult._first, ko);
    Assert.assertEquals(connectorResult._second, listeServiceTechnique);
  }

  /**
   * Test method {@link RSTConnector#serviceTechniqueModifierStatut(Tracabilite, UpdateServiceTechniqueRequest)}<br>
   * SendRequest returns an empty json.
   *
   * @throws Exception
   *           Thrown in case of error
   */
  @Test
  public void test_ServiceTechnique_KO_06() throws Exception
  {
    Retour ko = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, "Impossible de recuperer la reponse"); //$NON-NLS-1$
    UpdateServiceTechniqueRequest updateSt = _podam.manufacturePojo(UpdateServiceTechniqueRequest.class);

    com.bytel.ravel.types.Retour retour = new com.bytel.ravel.types.Retour();
    retour.setResultat(StringConstants.NOK);
    retour.setCategorie(IMegConsts.CAT2);
    retour.setDiagnostic(IMegConsts.DONNEE_INVALIDE);
    retour.setLibelle("Requete donnees invalides."); //$NON-NLS-1$

    String jsonString = this.serializeWithMoshi(updateSt, UpdateServiceTechniqueRequest.class);

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(StringConstants.EMPTY_STRING.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();

    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_serviceTechniqueUrl), EasyMock.anyObject(), EasyMock.eq(jsonString), EasyMock.isNull())).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    // test
    PowerMock.replayAll();
    _rstConnector.loadConnectorConfiguration(_connector);
    JUnitTools.setInaccessibleFieldValue(_rstConnector, "_loadBalancer", _loadBalancerMock); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_rstConnector, "_connectorPool", _connectorPoolMock); //$NON-NLS-1$
    ConnectorResponse<Retour, Nothing> connectorResult = _rstConnector.serviceTechniqueModifierStatut(_tracabilite, updateSt);
    PowerMock.verifyAll();

    Assert.assertEquals(ko, connectorResult._first);
  }

  /**
   * Test method {@link RSTConnector#serviceTechniqueLireTousParPfi(Tracabilite, String, String, String, String)}<br>
   *
   * @throws Exception
   *           Thrown in case of error
   */
  @Test
  public void test_ServiceTechnique_OK_00() throws Exception
  {
    Retour ok = RetourFactoryForTU.createOkRetour();
    List<ServiceTechnique> listeServiceTechnique = new ArrayList<>();
    ServiceTechnique st = _podam.manufacturePojoWithFullData(StLienAllocationCommercial.class);// new ServiceTechnique(RandomStringUtils.random(4), "LAC", "ACTIF", "BSS_ENT", RandomStringUtils.random(8));
    st.setTypeServiceTechnique(TypeST.LAC.name());
    listeServiceTechnique.add(st);
    ServiceTechnique st2 = _podam.manufacturePojoWithFullData(StPfsMail.class);// new ServiceTechnique(RandomStringUtils.random(4), "PFS", "ACTIF", "BSS_GP", RandomStringUtils.random(8));
    st2.setTypeServiceTechnique(TypeST.PFS.name());
    StPfsMail.class.cast(st2).setTypePfs(com.bytel.spirit.common.shared.functional.types.json.st.pfs.TypePFS.MAIL.name());
    listeServiceTechnique.add(st2);

    String clientOperateur = _podam.manufacturePojo(String.class);
    String noCompte = _podam.manufacturePojo(String.class);
    String typeStNiveaux1 = "typeServiceTechnique"; //$NON-NLS-1$
    String typeStNiveaux2 = "techno"; //$NON-NLS-1$

    HashMap<String, String> queryParams = new HashMap<>();
    queryParams.put(PARAM_CLIENT_OPERATEUR, clientOperateur);
    queryParams.put(PARAM_NO_COMPTE, noCompte);
    queryParams.put(PARAM_TYPE_ST_NIVEAU1, typeStNiveaux1);
    queryParams.put(PARAM_TYPE_ST_NIVEAU2, typeStNiveaux2);

    com.bytel.ravel.types.Retour retour = new com.bytel.ravel.types.Retour();
    retour.setResultat(StringConstants.OK);
    GetServiceTechniqueResponse getServiceTechniquesResponse = new GetServiceTechniqueResponse(retour, listeServiceTechnique);
    final String partnerResponse = this.serializeWithMoshi(getServiceTechniquesResponse, GetServiceTechniqueResponse.class);

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();

    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_serviceTechniqueUrl), EasyMock.anyObject(), EasyMock.eq(queryParams))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    // test
    PowerMock.replayAll();
    _rstConnector.loadConnectorConfiguration(_connector);
    JUnitTools.setInaccessibleFieldValue(_rstConnector, "_loadBalancer", _loadBalancerMock); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_rstConnector, "_connectorPool", _connectorPoolMock); //$NON-NLS-1$
    ConnectorResponse<Retour, List<ServiceTechnique>> connectorResult = _rstConnector.serviceTechniqueLireTousParPfi(_tracabilite, clientOperateur, noCompte, typeStNiveaux1, typeStNiveaux2);
    PowerMock.verifyAll();

    Assert.assertEquals(ok, connectorResult._first);
    Assert.assertEquals(listeServiceTechnique, connectorResult._second);
  }

  /**
   * Test method {@link RSTConnector#serviceTechniqueLireTousParPfi(Tracabilite, String, String, String, String)}<br>
   *
   * @throws Exception
   *           Thrown in case of error
   */
  @Test
  public void test_ServiceTechnique_OK_02() throws Exception
  {
    Retour ok = RetourFactory.createOkRetour();
    List<ServiceTechnique> listeServiceTechnique = new ArrayList<>();
    ServiceTechnique st = _podam.manufacturePojoWithFullData(StLienAllocationCommercial.class);
    st.setTypeServiceTechnique(TypeST.LAC.name());
    listeServiceTechnique.add(st);
    ServiceTechnique st2 = _podam.manufacturePojoWithFullData(StLienAllocationCommercial.class);
    st2.setTypeServiceTechnique(TypeST.LAC.name());
    listeServiceTechnique.add(st2);

    String idSt = _podam.manufacturePojo(String.class);

    HashMap<String, String> queryParams = new HashMap<>();
    queryParams.put(PARAM_ID_ST, idSt);

    com.bytel.ravel.types.Retour retour = new com.bytel.ravel.types.Retour();
    retour.setResultat(StringConstants.OK);
    GetServiceTechniqueResponse getServiceTechniquesResponse = new GetServiceTechniqueResponse(retour, listeServiceTechnique);
    final String partnerResponse = this.serializeWithMoshi(getServiceTechniquesResponse, GetServiceTechniqueResponse.class);

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();

    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_serviceTechniqueUrl), EasyMock.anyObject(), EasyMock.eq(queryParams))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    // test
    PowerMock.replayAll();
    _rstConnector.loadConnectorConfiguration(_connector);
    JUnitTools.setInaccessibleFieldValue(_rstConnector, "_loadBalancer", _loadBalancerMock); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_rstConnector, "_connectorPool", _connectorPoolMock); //$NON-NLS-1$
    ConnectorResponse<Retour, List<ServiceTechnique>> connectorResult = _rstConnector.serviceTechniqueLireUn(_tracabilite, idSt);
    PowerMock.verifyAll();

    Assert.assertEquals(connectorResult._first, ok);
    Assert.assertEquals(connectorResult._second, listeServiceTechnique);
  }

  /**
   * Test method {@link RSTConnector#serviceTechniqueLireTousParPfi(Tracabilite, String, String, String, String)}<br>
   *
   * @throws Exception
   *           Thrown in case of error
   */
  @Test
  public void test_ServiceTechnique_OK_04() throws Exception
  {
    Retour ok = RetourFactory.createOkRetour();

    UpdateServiceTechniqueRequest updateSt = _podam.manufacturePojo(UpdateServiceTechniqueRequest.class);

    String jsonString = this.serializeWithMoshi(updateSt, UpdateServiceTechniqueRequest.class);

    final Retour retour = RetourFactoryForTU.createOkRetour();
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = this.serializeWithMoshi(basicResponse, BasicResponse.class);

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();

    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_serviceTechniqueUrl), EasyMock.anyObject(), EasyMock.eq(jsonString), EasyMock.isNull())).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    // test
    PowerMock.replayAll();
    _rstConnector.loadConnectorConfiguration(_connector);
    JUnitTools.setInaccessibleFieldValue(_rstConnector, "_loadBalancer", _loadBalancerMock); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_rstConnector, "_connectorPool", _connectorPoolMock); //$NON-NLS-1$
    ConnectorResponse<Retour, Nothing> connectorResult = _rstConnector.serviceTechniqueModifierStatut(_tracabilite, updateSt);
    PowerMock.verifyAll();

    Assert.assertEquals(ok, connectorResult._first);
  }

  /**
   * Test KO for the method {@link RSTConnector#stLienAllocationCommercialCreer(Tracabilite, ServiceTechnique)}
   * httpStatus 200, with retourKO
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testStLienAllocationCommercialCreer_KO_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final ServiceTechnique serviceTechnique = _podam.manufacturePojoWithFullData(StLienAllocationCommercial.class);
    serviceTechnique.setTypeServiceTechnique(TypeST.LAC.name());
    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT1, IMegSpiritConsts.DONNEE_INDISPONIBLE, StringConstants.EMPTY_STRING, null);
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = serializeWithMoshi(basicResponse, BasicResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();

    // construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    String jsonRequest = serializeWithMoshi(serviceTechnique, ServiceTechnique.class);
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(_stLienAllocationCommercialUrl), EasyMock.capture(headersCapture), EasyMock.eq(jsonRequest), EasyMock.isNull())).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    _rstConnector.loadConnectorConfiguration(_connector);
    JUnitTools.setInaccessibleFieldValue(_rstConnector, "_loadBalancer", _loadBalancerMock); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_rstConnector, "_connectorPool", _connectorPoolMock); //$NON-NLS-1$
    final ConnectorResponse<Retour, Nothing> result = _rstConnector.stLienAllocationCommercialCreer(tracabilite, serviceTechnique);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());
    Assert.assertNotNull(headersCapture.getValue().get(CONTENT_TYPE));
    Assert.assertEquals(MediaType.APPLICATION_JSON, headersCapture.getValue().get(CONTENT_TYPE).get(0));

    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test KO for the method {@link RSTConnector#stLienAllocationCommercialCreer(Tracabilite, ServiceTechnique)}
   * httpStatus 200, jsonResponse null (throws RavelException)
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testStLienAllocationCommercialCreer_KO_002() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final ServiceTechnique serviceTechnique = _podam.manufacturePojoWithFullData(StLienAllocationCommercial.class);
    serviceTechnique.setTypeServiceTechnique(TypeST.LAC.name());
    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();

    // construct response
    final Response response = new ResponseBuilderImpl().status(200).build();

    // test scenario
    initializeMocksForSendRequest();
    String jsonRequest = serializeWithMoshi(serviceTechnique, ServiceTechnique.class);
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(_stLienAllocationCommercialUrl), EasyMock.capture(headersCapture), EasyMock.eq(jsonRequest), EasyMock.isNull())).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    ConnectorResponse<Retour, Nothing> result = null;

    PowerMock.replayAll();
    _rstConnector.loadConnectorConfiguration(_connector);
    JUnitTools.setInaccessibleFieldValue(_rstConnector, "_loadBalancer", _loadBalancerMock); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_rstConnector, "_connectorPool", _connectorPoolMock); //$NON-NLS-1$
    result = _rstConnector.stLienAllocationCommercialCreer(tracabilite, serviceTechnique);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());
    Assert.assertNotNull(headersCapture.getValue().get(CONTENT_TYPE));
    Assert.assertEquals(MediaType.APPLICATION_JSON, headersCapture.getValue().get(CONTENT_TYPE).get(0));

    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, JSON_ERROR_MESSAGE, null);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test OK for the method {@link RSTConnector#stLienAllocationCommercialCreer(Tracabilite, ServiceTechnique)} with
   * httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testStLienAllocationCommercialCreer_OK_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final ServiceTechnique serviceTechnique = _podam.manufacturePojoWithFullData(StLienAllocationCommercial.class);
    serviceTechnique.setTypeServiceTechnique(TypeST.LAC.name());
    final Retour retour = RetourFactoryForTU.createOkRetour();
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = serializeWithMoshi(basicResponse, BasicResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();

    // construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    String jsonRequest = this.serializeWithMoshi(serviceTechnique, ServiceTechnique.class);
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(_stLienAllocationCommercialUrl), EasyMock.capture(headersCapture), EasyMock.eq(jsonRequest), EasyMock.isNull())).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    _rstConnector.loadConnectorConfiguration(_connector);
    JUnitTools.setInaccessibleFieldValue(_rstConnector, "_loadBalancer", _loadBalancerMock); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_rstConnector, "_connectorPool", _connectorPoolMock); //$NON-NLS-1$
    final ConnectorResponse<Retour, Nothing> result = _rstConnector.stLienAllocationCommercialCreer(tracabilite, serviceTechnique);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());
    Assert.assertNotNull(headersCapture.getValue().get(CONTENT_TYPE));
    Assert.assertEquals(MediaType.APPLICATION_JSON, headersCapture.getValue().get(CONTENT_TYPE).get(0));

    Assert.assertEquals(retour, result._first);
  }

  /**
   * Test the method
   * {@link RSTConnector#stLienAllocationCommercialGererModifPfiAssocie(Tracabilite, UpdateStLienAllocationCommercialRequest)}
   * httpStatus 400
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testStLienAllocationCommercialGererModifPfiAssocie_KO_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    String idSt = "idSt"; //$NON-NLS-1$
    List<String> listIdSt = new ArrayList<>();
    listIdSt.add(idSt);
    UpdateStLienAllocationCommercialRequest stLienAllocationCommercialRequest = new UpdateStLienAllocationCommercialRequest("clientOperateur", "noCompteSource", "noCompteCible", listIdSt); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    Retour retour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, Response.Status.BAD_REQUEST.getReasonPhrase());
    final String partnerResponse = "{\"retour\":" + serializeWithMoshi(retour, Retour.class) + "}"; //$NON-NLS-1$//$NON-NLS-2$

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(400).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    String requestJson = this.serializeWithMoshi(stLienAllocationCommercialRequest, UpdateStLienAllocationCommercialRequest.class);
    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_stLienAllocationCommercialUrl), EasyMock.capture(headersCapture), EasyMock.eq(requestJson), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    _rstConnector.loadConnectorConfiguration(_connector);
    JUnitTools.setInaccessibleFieldValue(_rstConnector, "_loadBalancer", _loadBalancerMock); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_rstConnector, "_connectorPool", _connectorPoolMock); //$NON-NLS-1$
    final ConnectorResponse<Retour, Nothing> result = _rstConnector.stLienAllocationCommercialGererModifPfiAssocie(tracabilite, stLienAllocationCommercialRequest);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());
    Assert.assertNotNull(headersCapture.getValue().get(CONTENT_TYPE));
    Assert.assertEquals(MediaType.APPLICATION_JSON, headersCapture.getValue().get(CONTENT_TYPE).get(0));

    checkQueryParams(queryParamsCapture);

    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
  }

  /**
   * Test the method
   * {@link RSTConnector#stLienAllocationCommercialGererModifPfiAssocie(Tracabilite, UpdateStLienAllocationCommercialRequest)}
   * httpStatus 200 jsonResponse null
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testStLienAllocationCommercialGererModifPfiAssocie_KO_002() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    UpdateStLienAllocationCommercialRequest stLienAllocationCommercialRequest = new UpdateStLienAllocationCommercialRequest(null, null, null, null);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).build();

    // test scenario
    initializeMocksForSendRequest();
    String jsonRequestBody = serializeWithMoshi(stLienAllocationCommercialRequest, UpdateStLienAllocationCommercialRequest.class);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_stLienAllocationCommercialUrl), EasyMock.capture(headersCapture), EasyMock.eq(jsonRequestBody), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    ConnectorResponse<Retour, Nothing> result = null;

    PowerMock.replayAll();
    _rstConnector.loadConnectorConfiguration(_connector);
    JUnitTools.setInaccessibleFieldValue(_rstConnector, "_loadBalancer", _loadBalancerMock); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_rstConnector, "_connectorPool", _connectorPoolMock); //$NON-NLS-1$
    result = _rstConnector.stLienAllocationCommercialGererModifPfiAssocie(tracabilite, stLienAllocationCommercialRequest);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());
    Assert.assertNotNull(headersCapture.getValue().get(CONTENT_TYPE));
    Assert.assertEquals(MediaType.APPLICATION_JSON, headersCapture.getValue().get(CONTENT_TYPE).get(0));

    checkQueryParams(queryParamsCapture);

    Retour expectedRetour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, JSON_ERROR_MESSAGE);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method
   * {@link RSTConnector#stLienAllocationCommercialGererModifPfiAssocie(Tracabilite, UpdateStLienAllocationCommercialRequest)}
   * httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testStLienAllocationCommercialGererModifPfiAssocie_OK_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    String idSt = "idSt"; //$NON-NLS-1$
    List<String> listIdSt = new ArrayList<>();
    listIdSt.add(idSt);
    UpdateStLienAllocationCommercialRequest stLienAllocationCommercialRequest = new UpdateStLienAllocationCommercialRequest("clientOperateur", "noCompteSource", "noCompteCible", listIdSt); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    final Retour retour = RetourFactory.createOkRetour();
    final String partnerResponse = "{\"retour\":" + serializeWithMoshi(retour, Retour.class) + "}"; //$NON-NLS-1$//$NON-NLS-2$

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    String jsonRequestBody = this.serializeWithMoshi(stLienAllocationCommercialRequest, UpdateStLienAllocationCommercialRequest.class);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_stLienAllocationCommercialUrl), EasyMock.capture(headersCapture), EasyMock.eq(jsonRequestBody), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    _rstConnector.loadConnectorConfiguration(_connector);
    JUnitTools.setInaccessibleFieldValue(_rstConnector, "_loadBalancer", _loadBalancerMock); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_rstConnector, "_connectorPool", _connectorPoolMock); //$NON-NLS-1$
    final ConnectorResponse<Retour, Nothing> result = _rstConnector.stLienAllocationCommercialGererModifPfiAssocie(tracabilite, stLienAllocationCommercialRequest);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());
    Assert.assertNotNull(headersCapture.getValue().get(CONTENT_TYPE));
    Assert.assertEquals(MediaType.APPLICATION_JSON, headersCapture.getValue().get(CONTENT_TYPE).get(0));

    checkQueryParams(queryParamsCapture);

    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
  }

  /**
   * Test KO for the method {@link RSTConnector#stLienAllocationCommercialModifierStatutActif(Tracabilite, String)}
   *
   * Expected : Retour KO, CAT-4, DONNEE_INCONNUE, "ressourceCompteMail xxx inconnue"
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testStLienAllocationCommercialModifierStatutActif_KO_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final String idRessource = RandomStringUtils.randomAlphabetic(5);
    final String idSt = RandomStringUtils.randomAlphabetic(5);

    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "ressourceCompteMail " + idRessource + " inconnue", null); //$NON-NLS-1$ //$NON-NLS-2$
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = this.serializeWithMoshi(basicResponse, BasicResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_stLienAllocationCommercialUrl), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    _rstConnector.loadConnectorConfiguration(_connector);
    JUnitTools.setInaccessibleFieldValue(_rstConnector, "_loadBalancer", _loadBalancerMock); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_rstConnector, "_connectorPool", _connectorPoolMock); //$NON-NLS-1$
    final ConnectorResponse<Retour, Nothing> result = _rstConnector.stLienAllocationCommercialModifierStatutActif(tracabilite, idSt);

    // check header
    Assert.assertNotNull(headersCapture.getValue());
    Assert.assertNotNull(headersCapture.getValue().get(CONTENT_TYPE));
    Assert.assertEquals(MediaType.APPLICATION_JSON, headersCapture.getValue().get(CONTENT_TYPE).get(0));

    //check params sent
    checkQueryParams(queryParamsCapture, PARAM_ID_ST, idSt);

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test OK for the method {@link RSTConnector#stLienAllocationCommercialModifierStatutActif(Tracabilite, String)}
   * httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testStLienAllocationCommercialModifierStatutActif_OK_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final String idSt = RandomStringUtils.randomAlphabetic(5);

    final Retour retour = RetourFactoryForTU.createOkRetour();
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = this.serializeWithMoshi(basicResponse, BasicResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_stLienAllocationCommercialUrl), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    _rstConnector.loadConnectorConfiguration(_connector);
    JUnitTools.setInaccessibleFieldValue(_rstConnector, "_loadBalancer", _loadBalancerMock); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_rstConnector, "_connectorPool", _connectorPoolMock); //$NON-NLS-1$
    final ConnectorResponse<Retour, Nothing> result = _rstConnector.stLienAllocationCommercialModifierStatutActif(tracabilite, idSt);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());
    Assert.assertNotNull(headersCapture.getValue().get(CONTENT_TYPE));
    Assert.assertEquals(MediaType.APPLICATION_JSON, headersCapture.getValue().get(CONTENT_TYPE).get(0));

    //check params sent
    checkQueryParams(queryParamsCapture, PARAM_ID_ST, idSt);

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method {@link REXConnector#stPfsGererModifPfiAssocie(Tracabilite, UpdateStPfsRequest)} httpStatus 400
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void teststPfsCreer_OK_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final ServiceTechnique serviceTechnique = _podam.manufacturePojo(StPfsMail.class);
    serviceTechnique.setTypeServiceTechnique(TypeST.PFS.name());
    StPfsMail.class.cast(serviceTechnique).setTypePfs(TypePFS.MAIL.name());
    final Retour retour = RetourFactoryForTU.createOkRetour();
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = this.serializeWithMoshi(basicResponse, BasicResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();

    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();
    // construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(_stPfsUrl), EasyMock.capture(headersCapture), EasyMock.eq(this.serializeWithMoshi(serviceTechnique, ServiceTechnique.class)), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _rstConnector.stPfsCreer(tracabilite, serviceTechnique);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());
    Assert.assertNotNull(headersCapture.getValue().get(CONTENT_TYPE));
    Assert.assertEquals(MediaType.APPLICATION_JSON, headersCapture.getValue().get(CONTENT_TYPE).get(0));

    Assert.assertEquals(retour, result._first);

  }

  //  /**
  //   * Test the method {@link REXConnector#stPfsDslamCreer(Tracabilite, serviceTechnique)} httpStatus 200
  //   *
  //   * @throws Exception
  //   *           thrown in case of error
  //   */
  //  @Test
  //  public void teststPfsDslamCreer_OK_001() throws Exception
  //  {
  //
  //    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
  //    final ServiceTechnique serviceTechnique = _podam.manufacturePojo(ServiceTechnique.class);
  //    final Retour retour = RetourFactoryForTU.createOkRetour();
  //    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
  //    final String partnerResponse = this.serializeWithMoshi(basicResponse, BasicResponse.class);
  //
  //    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
  //
  //    // construct response
  //    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();
  //
  //    // test scenario
  //    initializeMocksForSendRequest();
  //    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(_stPfsDslamUrl), EasyMock.capture(headersCapture), EasyMock.eq(this.serializeWithMoshi(serviceTechnique, ServiceTechnique.class)), EasyMock.isNull())).andReturn(response);
  //    _restConnectorPoolMock.returnObject(_restInstanceMock);
  //
  //    PowerMock.replayAll();
  //    final ConnectorResponse<Retour, Nothing> result = _rstConnector.stPfsDslamCreer(tracabilite, serviceTechnique);
  //    PowerMock.verifyAll();
  //
  //    // check header
  //    Assert.assertNotNull(headersCapture.getValue());
  //    Assert.assertNotNull(headersCapture.getValue().get(CONTENT_TYPE));
  //    Assert.assertEquals(MediaType.APPLICATION_JSON, headersCapture.getValue().get(CONTENT_TYPE).get(0));
  //
  //    Assert.assertEquals(retour, result._first);
  //
  //  }

  //  /**
  //   * Test the method {@link REXConnector#stPfsDslamModifierStatutActif httpStatus 200
  //   *
  //   * @throws Exception
  //   *           thrown in case of error
  //   */
  //  @Test
  //  public void teststPfsDslamModifierStatutActif_OK_001() throws Exception
  //  {
  //
  //    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
  //    final String codeAccesTechnique = RandomStringUtils.randomAlphabetic(5);
  //    final String idSt = RandomStringUtils.randomAlphabetic(5);
  //    final Retour retour = RetourFactoryForTU.createOkRetour();
  //    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
  //    final String partnerResponse = this.serializeWithMoshi(basicResponse, BasicResponse.class);
  //
  //    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
  //    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();
  //    // construct response
  //    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();
  //
  //    // test scenario
  //    initializeMocksForSendRequest();
  //    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_stPfsDslamUrl), EasyMock.capture(headersCapture), EasyMock.isNull(), EasyMock.capture(queryParamsCapture))).andReturn(response); //$NON-NLS-1$
  //    _restConnectorPoolMock.returnObject(_restInstanceMock);
  //
  //    PowerMock.replayAll();
  //    final ConnectorResponse<Retour, Nothing> result = _rstConnector.stPfsDslamModifierStatutActif(tracabilite, idSt, codeAccesTechnique);
  //    PowerMock.verifyAll();
  //
  //    // check header
  //    Assert.assertNotNull(headersCapture.getValue());
  //    Assert.assertNotNull(headersCapture.getValue().get(CONTENT_TYPE));
  //    Assert.assertEquals(MediaType.APPLICATION_JSON, headersCapture.getValue().get(CONTENT_TYPE).get(0));
  //
  //    Assert.assertEquals(retour, result._first);
  //
  //  }

  /**
   * Test the method {@link REXConnector#stPfsGererModifPfiAssocie(Tracabilite, UpdateStPfsRequest)}
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void teststPfsgererModifPfiAssocie_OK_001() throws Exception
  {

    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    String idSt = "idSt"; //$NON-NLS-1$
    List<String> listIdSt = new ArrayList<>();
    listIdSt.add(idSt);
    UpdateStPfsRequest updateStpfsRequest = new UpdateStPfsRequest("clientOperateur", "noCompteSource", "noCompteCible", listIdSt); //$NON-NLS-1$ //$NON-NLS-2$//$NON-NLS-3$
    final Retour retour = RetourFactoryForTU.createOkRetour();
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = this.serializeWithMoshi(basicResponse, BasicResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();

    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();
    // construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    String jsonRequestBody = this.serializeWithMoshi(updateStpfsRequest, UpdateStPfsRequest.class);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_stPfsUrl), EasyMock.capture(headersCapture), EasyMock.eq(jsonRequestBody), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _rstConnector.stPfsGererModifPfiAssocie(tracabilite, updateStpfsRequest);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());
    Assert.assertNotNull(headersCapture.getValue().get(CONTENT_TYPE));
    Assert.assertEquals(MediaType.APPLICATION_JSON, headersCapture.getValue().get(CONTENT_TYPE).get(0));

    Assert.assertEquals(retour, result._first);

  }

  /**
   * Test the method {@link REXConnector#PfsGererModifPfiAssocie(Tracabilite, UpdateStPfsRequest)} httpStatus 400
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testStPfsGererModifPfiAssocie_OK_001() throws Exception
  {

    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    String idSt = "idSt"; //$NON-NLS-1$
    List<String> listIdSt = new ArrayList<>();
    listIdSt.add(idSt);
    UpdateStPfsRequest updateStpfsRequest = new UpdateStPfsRequest("clientOperateur", "noCompteSource", "noCompteCible", listIdSt); //$NON-NLS-1$ //$NON-NLS-2$//$NON-NLS-3$
    final Retour retour = RetourFactoryForTU.createOkRetour();
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = this.serializeWithMoshi(basicResponse, BasicResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();

    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();
    // construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_stPfsUrl), EasyMock.capture(headersCapture), EasyMock.eq(this.serializeWithMoshi(updateStpfsRequest, UpdateStPfsRequest.class)), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _rstConnector.stPfsGererModifPfiAssocie(tracabilite, updateStpfsRequest);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());
    Assert.assertNotNull(headersCapture.getValue().get(CONTENT_TYPE));
    Assert.assertEquals(MediaType.APPLICATION_JSON, headersCapture.getValue().get(CONTENT_TYPE).get(0));

    Assert.assertEquals(retour, result._first);

  }

  /**
   * Test OK for the method
   * {@link RESConnector#ressourceRaccordementModifierStatutAllocation(Tracabilite, String, String, String)} httpStatus
   * 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  //@Test
  public void teststPfsModifierStatutActif_OK_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final String idSt = RandomStringUtils.randomAlphabetic(5);
    final Retour retour = RetourFactoryForTU.createOkRetour();
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = this.serializeWithMoshi(basicResponse, BasicResponse.class);
    IDonneesProvisionnees donneesIdentification = new DonneesProvisionneesSTPfsMail("adresseMail", 0, 0, "RESTREINT"); //$NON-NLS-1$ //$NON-NLS-2$

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();

    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();
    // construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_stPfsUrl), EasyMock.capture(headersCapture), EasyMock.isNull(), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _rstConnector.stPfsModifierStatutActif(tracabilite, idSt, donneesIdentification);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());
    Assert.assertNotNull(headersCapture.getValue().get(CONTENT_TYPE));
    Assert.assertEquals(MediaType.APPLICATION_JSON, headersCapture.getValue().get(CONTENT_TYPE).get(0));

    Assert.assertEquals(retour, result._first);

  }

  /**
   * Adds one parameter to the connector conf
   *
   * @param connector_p
   *          The connector
   * @param name_p
   *          The parameter name
   * @param value_p
   *          The parameter value
   */
  private void addParameter(Connector connector_p, String name_p, String value_p)
  {
    Param param = new Param();
    param.setName(name_p);
    param.setValue(value_p);
    connector_p.getParam().add(param);
  }

  /**
   * Check the query params in rest send request method
   *
   * @param queryParams
   *          the actual query params
   * @param expected_p
   *          list of expected query params strings key1 value1 key2 value2...keyN valueN
   */
  private void checkQueryParams(Capture<Map<String, String>> queryParams, String... expected_p)
  {
    if (expected_p == null)
    {
      Assert.assertNull(queryParams.getValue());
    }
    else
    {
      Assert.assertEquals(0, expected_p.length % 2);
      for (int i = 0; i < expected_p.length; i = i + 2)
      {
        Assert.assertEquals(expected_p[i + 1], queryParams.getValue().get(expected_p[i]));
      }
    }
  }

  /**
   * Génération du LoadBalancer minimal pour passer {@link AbstractRESTConnector#loadConnectorConfiguration(Connector)}
   *
   * @return {@link LoadBalancer}
   */
  private LoadBalancer generateLoadBalancer()
  {
    final LoadBalancer loadBalancer = new LoadBalancer();
    Param timer = new Param();
    timer.setName("TIMER"); //$NON-NLS-1$
    timer.setValue("30"); //$NON-NLS-1$
    loadBalancer.getParam().add(timer);
    loadBalancer.setType("RoundRobin"); //$NON-NLS-1$
    return loadBalancer;
  }

  /**
   * Génération du URL minimal pour passer {@link AbstractRESTConnector#loadConnectorConfiguration(Connector)}
   *
   * @return {@link URL}
   */
  private URL generateURL()
  {
    final URL url = new URL();
    url.setName("urlName"); //$NON-NLS-1$
    url.setAccessPoint("http://localhost:8888"); //$NON-NLS-1$
    Param param = new Param();
    param.setName("PROXY_ENABLED"); //$NON-NLS-1$
    param.setValue(String.valueOf(false));
    url.getParam().add(param);
    param = new Param();
    param.setName("TIMEOUT"); //$NON-NLS-1$
    param.setValue("30"); //$NON-NLS-1$
    url.getParam().add(param);

    return url;
  }

  /**
   * Génération du URLS minimal pour passer {@link AbstractRESTConnector#loadConnectorConfiguration(Connector)}
   *
   * @return {@link URLS}
   */
  private URLS generateURLS()
  {
    final URLS urls = new URLS();
    urls.setLoadBalancer(generateLoadBalancer());
    urls.getURL().add(generateURL());
    return urls;
  }

  /**
   * Initializes the connector parameters
   *
   * @param connector_p
   *          the connector to initialize
   */
  private void initializeConnectorParameters(Connector connector_p)
  {
    addParameter(connector_p, PAD4000_PATH_PARAM, _serviceTechniqueUrl);
    addParameter(connector_p, PAD4200_PATH_PARAM, _stLienAllocationCommercialUrl);
    addParameter(connector_p, PAD4300_PATH_PARAM, _stPfsUrl);
  }

  /**
   * prepare mock scenario to initialize method sendRequest from AbstractRestConnector
   *
   * @throws Exception
   *           Thrown in case of error
   */
  private void initializeMocksForSendRequest() throws Exception
  {
    final String urlBalancedElementName = RandomStringUtils.randomAlphanumeric(45);
    final String urlBalancedElementDescription = RandomStringUtils.randomAlphabetic(9);

    EasyMock.expect(_loadBalancerMock.chooseBalancedElement()).andReturn(_urlBalancedElementMock);

    EasyMock.expect(_urlBalancedElementMock.getName()).andReturn(urlBalancedElementName);
    EasyMock.expect(_urlBalancedElementMock.getDescription()).andReturn(urlBalancedElementDescription);
    EasyMock.expect(_urlBalancedElementMock.getName()).andReturn(urlBalancedElementName);
    EasyMock.expect(_connectorPoolMock.get(urlBalancedElementName)).andReturn(_restConnectorPoolMock);
    EasyMock.expect(_restConnectorPoolMock.borrowObject()).andReturn(_restInstanceMock);
    _restInstanceMock.setReceiveTimeout(30);
  }

  /**
   * Serializes the object in obj parameter and returns a string representing the object as json.
   *
   * @param obj
   *          The object to eserialize
   * @param clazz
   *          The class type of the objet to serialize from
   * @return The json String
   * @throws RavelException
   *           If thrown by the Json builder
   */
  private <T> String serializeWithMoshi(T obj, Class<T> clazz) throws RavelException
  {
    IRavelJson jsonBuilder = new RavelJsonBuilder() //
        .profil("STARK")//$NON-NLS-1$
        .build();
    final IRavelJsonAdapter<T> adapter = jsonBuilder.adapter(clazz);

    return adapter.toJson(obj);

  }
}
