/*******************************************************************************
* $Id: IRST.java 14546 2018-12-12 11:55:56Z jgregori $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.rst;

import java.util.List;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.IDonneesProvisionnees;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.rst.ServiceTechnique;
import com.bytel.spirit.common.shared.saab.rst.request.UpdateServiceTechniqueRequest;
import com.bytel.spirit.common.shared.saab.rst.request.UpdateStLienAllocationCommercialRequest;
import com.bytel.spirit.common.shared.saab.rst.request.UpdateStPfsRequest;

/**
 *
 * @author pcarreir
 * @version ($Revision: 14546 $ $Date: 2018-12-12 12:55:56 +0100 (mer. 12 déc. 2018) $)
 */
public interface IRST
{
  /**
   * @param tracabilite_p
   *          Tracabilite object
   * @param clientOperateur_p
   *          Client code
   * @param noCompte_p
   *          Account number
   * @param typeStNiveaux1_p
   *          Technical system type level 1 <br>
   *          Mandatory if typeStNiveaux2_p not null or empty<br>
   *          Allowed values: <br>
   *          - typeServiceTechnique
   * @param typeStNiveaux2_p
   *          Technical system type level 2 <br>
   *          Allowed Values: <br>
   *          - techno <br>
   *          - typePfs
   * @return {@link ConnectorResponse}
   * @throws RavelException
   *           Exception thrown in case of failure
   */
  public ConnectorResponse<Retour, List<ServiceTechnique>> serviceTechniqueLireTousParPfi(Tracabilite tracabilite_p, String clientOperateur_p, String noCompte_p, String typeStNiveaux1_p, String typeStNiveaux2_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          Tracabilite object
   * @param idSt_p
   *          Code Insee
   * @return {@link ConnectorResponse}
   * @throws RavelException
   *           Exception thrown in case of failure
   */
  public ConnectorResponse<Retour, List<ServiceTechnique>> serviceTechniqueLireUn(Tracabilite tracabilite_p, String idSt_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          Tracabilite object
   * @param updateServiceTechniqueRequest_p
   *          {@link UpdateServiceTechniqueRequest}
   * @return {@link Retour}
   * @throws RavelException
   *           Exception thrown in case of failure
   */
  public ConnectorResponse<Retour, Nothing> serviceTechniqueModifierStatut(Tracabilite tracabilite_p, UpdateServiceTechniqueRequest updateServiceTechniqueRequest_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          Tracabilite object
   * @param serviceTechnique_p
   *          serviceTechnique
   * @return {@link Retour}
   * @throws RavelException
   *           Exception thrown in case of failure
   */
  public ConnectorResponse<Retour, Nothing> stLienAllocationCommercialCreer(Tracabilite tracabilite_p, ServiceTechnique serviceTechnique_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          Tracabilite object
   * @param stLienAllocationCommercialRequest_p
   *          stLienAllocationCommercialRequest
   * @return {@link Retour}
   * @throws RavelException
   *           Exception thrown in case of failure
   */
  public ConnectorResponse<Retour, Nothing> stLienAllocationCommercialGererModifPfiAssocie(Tracabilite tracabilite_p, UpdateStLienAllocationCommercialRequest stLienAllocationCommercialRequest_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          Tracabilite object
   * @param idSt_p
   *          The technical service Id
   * @return {@link Retour}
   * @throws RavelException
   *           Exception thrown in case of failure
   */
  public ConnectorResponse<Retour, Nothing> stLienAllocationCommercialModifierStatutActif(Tracabilite tracabilite_p, String idSt_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          Tracabilite object
   * @param serviceTechnique_p
   *          serviceTechnique object
   * @return {@link Retour}
   * @throws RavelException
   *           Exception thrown in case of failure
   */
  public ConnectorResponse<Retour, Nothing> stPfsCreer(Tracabilite tracabilite_p, ServiceTechnique serviceTechnique_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          Tracabilite object
   * @param updateStpfsRequest_p
   *          update St PFS
   * @return {@link Retour}
   * @throws RavelException
   *           Exception thrown in case of failure
   */
  public ConnectorResponse<Retour, Nothing> stPfsGererModifPfiAssocie(Tracabilite tracabilite_p, UpdateStPfsRequest updateStpfsRequest_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          Tracabilite object
   * @param idSt_p
   *          The technical service Id
   * @param donneesProvisionnees_p
   *          the donneesProvisionnees
   * @return {@link Retour}
   * @throws RavelException
   *           Exception thrown in case of failure
   */
  public ConnectorResponse<Retour, Nothing> stPfsModifierStatutActif(Tracabilite tracabilite_p, String idSt_p, IDonneesProvisionnees donneesProvisionnees_p) throws RavelException;

  /**
   * Method to call PAD4100_StRacco.Create. Create a new {@link ServiceTechnique} of type RACCO
   *
   * @param tracabilite_p
   *          Tracabilite object
   * @param updateStPfsRequest_p
   *          updateStPfsRequest object
   * @return {@link ConnectorResponse}
   * @throws RavelException
   *           Exception thrown in case of failure
   */
  public ConnectorResponse<Retour, Nothing> stPfsModifPfiAssocie(Tracabilite tracabilite_p, UpdateStPfsRequest updateStPfsRequest_p) throws RavelException;

}
