/*******************************************************************************
* $Id: Messages.java 5930 2018-05-04 14:22:08Z pcarreir $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.rst;

import java.util.MissingResourceException;
import java.util.ResourceBundle;

/**
 *
 * @author pcarreir
 * @version ($Revision: 5930 $ $Date: 2018-05-04 16:22:08 +0200 (ven. 04 mai 2018) $)
 */
public class Messages
{
  /**
   * The resource bundle name
   */
  private static final String BUNDLE_NAME = "com.bytel.spirit.common.connectors.rst.messages"; //$NON-NLS-1$

  /**
   * The resource bundle
   */
  private static final ResourceBundle RESOURCE_BUNDLE = ResourceBundle.getBundle(BUNDLE_NAME);

  /**
   * @param key
   *          The key to search for
   * @return {@link String}
   */
  public static String getString(String key)
  {
    try
    {
      return RESOURCE_BUNDLE.getString(key);
    }
    catch (MissingResourceException e)
    {
      return '!' + key + '!';
    }
  }

  /**
   * The constructor
   */
  private Messages()
  {
  }
}
