/*******************************************************************************
* $Id: IRSTConnector.java 5930 2018-05-04 14:22:08Z pcarreir $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.rst;

import com.bytel.ravel.services.connector.IConnector;

/**
 *
 * @author pcarreir
 * @version ($Revision: 5930 $ $Date: 2018-05-04 16:22:08 +0200 (ven. 04 mai 2018) $)
 */
public interface IRSTConnector extends IConnector, IRST
{
  /**
   * The id to retrieve the connector.
   */
  public String BEAN_ID = "RSTConnector"; //$NON-NLS-1$
}
