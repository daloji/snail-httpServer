/*******************************************************************************
* $Id: RSTProxy.java 14546 2018-12-12 11:55:56Z jgregori $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.rst;

import java.util.List;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.probes.AvgDoubleCollectorItem;
import com.bytel.ravel.common.probes.AvgFlowPerSecondCollector;
import com.bytel.ravel.common.probes.RavelProbeConfigurationManager;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.services.connector.BaseProxy;
import com.bytel.ravel.services.connector.ConnectorExecution;
import com.bytel.ravel.services.connector.ConnectorManager;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.IDonneesProvisionnees;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.rst.ServiceTechnique;
import com.bytel.spirit.common.shared.saab.rst.request.UpdateServiceTechniqueRequest;
import com.bytel.spirit.common.shared.saab.rst.request.UpdateStLienAllocationCommercialRequest;
import com.bytel.spirit.common.shared.saab.rst.request.UpdateStPfsRequest;

/**
 *
 * @author pcarreir
 * @version ($Revision: 14546 $ $Date: 2018-12-12 12:55:56 +0100 (mer. 12 déc. 2018) $)
 */
public final class RSTProxy extends BaseProxy implements IRST
{

  /**
   * Proxy instance.
   */
  private static RSTProxy _instance = new RSTProxy();

  /**
   * @return The proxy instance.
   */
  public static RSTProxy getInstance()
  {
    return RSTProxy._instance;
  }

  /**
   * For probe to count the amount of calls to the serviceTechniqueLireTousParPfi operation
   */
  AvgFlowPerSecondCollector _avg_ServiceTechniqueLireTousParPfi_call_counter;

  /**
   * For probe to count the execution call duration to the serviceTechniqueLireTousParPfi operation
   */
  AvgDoubleCollectorItem _avg_ServiceTechniqueLireTousParPfi_ExecTime;

  /**
   * For probe to count the amount of calls to the serviceTechniqueLireUn operation
   */
  AvgFlowPerSecondCollector _avg_ServiceTechniqueLireUn_call_counter;

  /**
   * For probe to count the execution call duration to the serviceTechniqueLireUn operation
   */
  AvgDoubleCollectorItem _avg_ServiceTechniqueLireUn_ExecTime;

  /**
   * For probe to count the amount of calls to the serviceTechniqueModifierStatut operation
   */
  AvgFlowPerSecondCollector _avg_ServiceTechniqueModifierStatut_call_counter;

  /**
   * For probe to count the execution call duration to the serviceTechniqueModifierStatut operation
   */
  AvgDoubleCollectorItem _avg_ServiceTechniqueModifierStatut_ExecTime;

  /**
   * For probe to count the amount of calls to the stLienAllocationCommercialCreer operation
   */
  AvgFlowPerSecondCollector _avg_StLienAllocationCommercialCreer_call_counter;

  /**
   * For probe to count the execution call duration to the stLienAllocationCommercialCreer operation
   */
  AvgDoubleCollectorItem _avg_StLienAllocationCommercialCreer_ExecTime;

  /**
   * For probe to count the amount of calls to the stLienAllocationCommercialGererModifPfiAssocie operation
   */
  AvgFlowPerSecondCollector _avg_StLienAllocationCommercialGererModifPfiAssocie_call_counter;

  /**
   * For probe to count the execution call duration to the stLienAllocationCommercialGererModifPfiAssocie operation
   */
  AvgDoubleCollectorItem _avg_StLienAllocationCommercialGererModifPfiAssocie_ExecTime;

  /**
   * For probe to count the amount of calls to the stLienAllocationCommercialModifierStatutActif operation
   */
  AvgFlowPerSecondCollector _avg_StLienAllocationCommercialModifierStatutActif_call_counter;

  /**
   * For probe to count the execution call duration to the stLienAllocationCommercialModifierStatutActif operation
   */
  AvgDoubleCollectorItem _avg_StLienAllocationCommercialModifierStatutActif_ExecTime;

  /**
   * For probe to count the amount of calls to the stPfsGererModifPfiAssocie operation
   */
  AvgFlowPerSecondCollector _avg_StPfsGererModifPfiAssocie_call_counter;

  /**
   * For probe to count the execution call duration to the stPfsGererModifPfiAssocie operation
   */
  AvgDoubleCollectorItem _avg_StPfsGererModifPfiAssocie_ExecTime;

  /**
   * For probe to count the amount of calls to the stPfsCreer operation
   */
  AvgFlowPerSecondCollector _avg_StPfsCreer_call_counter;

  /**
   * For probe to count the execution call duration to the stPfsCreer operation
   */
  AvgDoubleCollectorItem _avg_StPfsCreer_ExecTime;

  /**
   * For probe to count the amount of calls to the stPfsModifierStatutActif operation
   */
  AvgFlowPerSecondCollector _avg_StPfsModifierStatutActif_call_counter;

  /**
   * For probe to count the execution call duration to the stPfsModifierStatutActif operation
   */
  AvgDoubleCollectorItem _avg_StPfsModifierStatutActif_ExecTime;

  /**
   * For probe to count the amount of calls to the stPfsModifPfiAssocie operation
   */

  AvgFlowPerSecondCollector _avg_StPfsModifPfiAssocie_call_counter;
  /**
   * FFor probe to count the execution call duration to the stPfsModifPfiAssocie operation
   */
  AvgDoubleCollectorItem _avg_StPfsModifPfiAssocie_ExecTime;

  /**
   * The private singleton constructor
   */
  private RSTProxy()
  {
    _avg_ServiceTechniqueLireTousParPfi_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_ServiceTechniqueLireTousParPfi_call_counter", "RSTProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_ServiceTechniqueLireTousParPfi_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_ServiceTechniqueLireTousParPfi_ExecTime", "RSTProxy"); //$NON-NLS-1$//$NON-NLS-2$

    _avg_ServiceTechniqueLireUn_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_ServiceTechniqueLireUn_call_counter", "RSTProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_ServiceTechniqueLireUn_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_ServiceTechniqueLireUn_ExecTime", "RSTProxy"); //$NON-NLS-1$//$NON-NLS-2$

    _avg_ServiceTechniqueModifierStatut_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_ServiceTechniqueModifierStatut_call_counter", "RSTProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_ServiceTechniqueModifierStatut_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_ServiceTechniqueModifierStatut_ExecTime", "RSTProxy"); //$NON-NLS-1$//$NON-NLS-2$

    _avg_StLienAllocationCommercialCreer_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_StLienAllocationCommercialCreer_call_counter", "RSTProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_StLienAllocationCommercialCreer_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_StLienAllocationCommercialCreer_ExecTime", "RSTProxy"); //$NON-NLS-1$//$NON-NLS-2$

    _avg_StLienAllocationCommercialGererModifPfiAssocie_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_StLienAllocationCommercialGererModifPfiAssocie_call_counter", "RSTProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_StLienAllocationCommercialGererModifPfiAssocie_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_StLienAllocationCommercialGererModifPfiAssocie_ExecTime", "RSTProxy"); //$NON-NLS-1$//$NON-NLS-2$

    _avg_StLienAllocationCommercialModifierStatutActif_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_StLienAllocationCommercialModifierStatutActif_call_counter", "RSTProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_StLienAllocationCommercialModifierStatutActif_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_StLienAllocationCommercialModifierStatutActif_ExecTime", "RSTProxy"); //$NON-NLS-1$//$NON-NLS-2$

    _avg_StPfsGererModifPfiAssocie_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_StPfsGererModifPfiAssocie_call_counter", "RSTProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_StPfsGererModifPfiAssocie_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_StPfsGererModifPfiAssocie_ExecTime", "RSTProxy"); //$NON-NLS-1$//$NON-NLS-2$

    _avg_StPfsCreer_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_StPfsCreer_call_counter", "RSTProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_StPfsCreer_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_StPfsCreer_ExecTime", "RSTProxy"); //$NON-NLS-1$//$NON-NLS-2$

    _avg_StPfsModifierStatutActif_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_StPfsModifierStatutActif_call_counter", "RSTProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_StPfsModifierStatutActif_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_StPfsModifierStatutActif_ExecTime", "RSTProxy"); //$NON-NLS-1$//$NON-NLS-2$

    _avg_StPfsModifPfiAssocie_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_StPfsModifPfiAssocie_call_counter", "RSTProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_StPfsModifPfiAssocie_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_StPfsModifPfiAssocie_ExecTime", "RSTProxy"); //$NON-NLS-1$//$NON-NLS-2$

  }

  @Override
  public ConnectorResponse<Retour, List<ServiceTechnique>> serviceTechniqueLireTousParPfi(Tracabilite tracabilite_p, String clientOperateur_p, String noCompte_p, String typeStNiveaux1_p, String typeStNiveaux2_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, List<ServiceTechnique>>>(IRSTConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, List<ServiceTechnique>> run() throws RavelException
      {
        IRSTConnector rstConnector = null;
        try
        {
          rstConnector = (IRSTConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          // Retour NOK
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_ServiceTechniqueLireTousParPfi_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return rstConnector.serviceTechniqueLireTousParPfi(tracabilite_p, clientOperateur_p, noCompte_p, typeStNiveaux1_p, typeStNiveaux2_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_ServiceTechniqueLireTousParPfi_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, List<ServiceTechnique>> serviceTechniqueLireUn(Tracabilite tracabilite_p, String idSt_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, List<ServiceTechnique>>>(IRSTConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, List<ServiceTechnique>> run() throws RavelException
      {
        IRSTConnector rstConnector = null;
        try
        {
          rstConnector = (IRSTConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          // Retour NOK
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_ServiceTechniqueLireUn_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return rstConnector.serviceTechniqueLireUn(tracabilite_p, idSt_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_ServiceTechniqueLireUn_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> serviceTechniqueModifierStatut(Tracabilite tracabilite_p, UpdateServiceTechniqueRequest updateServiceTechniqueRequest_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IRSTConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        IRSTConnector rstConnector = null;
        try
        {
          rstConnector = (IRSTConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          // Retour NOK
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_ServiceTechniqueModifierStatut_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return rstConnector.serviceTechniqueModifierStatut(tracabilite_p, updateServiceTechniqueRequest_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_ServiceTechniqueModifierStatut_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> stLienAllocationCommercialCreer(Tracabilite tracabilite_p, ServiceTechnique serviceTechnique_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IRSTConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        IRSTConnector rstConnector = null;
        try
        {
          rstConnector = (IRSTConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          // Retour NOK
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_StLienAllocationCommercialCreer_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return rstConnector.stLienAllocationCommercialCreer(tracabilite_p, serviceTechnique_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_StLienAllocationCommercialCreer_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> stLienAllocationCommercialGererModifPfiAssocie(Tracabilite tracabilite_p, UpdateStLienAllocationCommercialRequest updateStLienAllocationCommercialRequest_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IRSTConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        IRSTConnector rstConnector = null;
        try
        {
          rstConnector = (IRSTConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          // Retour NOK
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_StLienAllocationCommercialGererModifPfiAssocie_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return rstConnector.stLienAllocationCommercialGererModifPfiAssocie(tracabilite_p, updateStLienAllocationCommercialRequest_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_StLienAllocationCommercialGererModifPfiAssocie_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> stLienAllocationCommercialModifierStatutActif(Tracabilite tracabilite_p, String idSt_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IRSTConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        IRSTConnector rstConnector = null;
        try
        {
          rstConnector = (IRSTConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          // Retour NOK
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_StLienAllocationCommercialModifierStatutActif_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return rstConnector.stLienAllocationCommercialModifierStatutActif(tracabilite_p, idSt_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_StLienAllocationCommercialModifierStatutActif_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> stPfsCreer(Tracabilite tracabilite_p, ServiceTechnique serviceTechnique_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IRSTConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        IRSTConnector rstConnector = null;
        try
        {
          rstConnector = (IRSTConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          // Retour NOK
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_StPfsCreer_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return rstConnector.stPfsCreer(tracabilite_p, serviceTechnique_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_StPfsCreer_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> stPfsGererModifPfiAssocie(Tracabilite tracabilite_p, UpdateStPfsRequest updateStpfsRequest_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IRSTConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        IRSTConnector rstConnector = null;
        try
        {
          rstConnector = (IRSTConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          // Retour NOK
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_StPfsGererModifPfiAssocie_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return rstConnector.stPfsGererModifPfiAssocie(tracabilite_p, updateStpfsRequest_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_StPfsGererModifPfiAssocie_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> stPfsModifierStatutActif(Tracabilite tracabilite_p, String idSt_p, IDonneesProvisionnees donneesProvisionnees_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IRSTConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        IRSTConnector rstConnector = null;
        try
        {
          rstConnector = (IRSTConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          // Retour NOK
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_StPfsModifierStatutActif_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return rstConnector.stPfsModifierStatutActif(tracabilite_p, idSt_p, donneesProvisionnees_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_StPfsModifierStatutActif_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> stPfsModifPfiAssocie(Tracabilite tracabilite_p, UpdateStPfsRequest updateStPfsRequest_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IRSTConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        IRSTConnector rstConnector = null;
        try
        {
          rstConnector = (IRSTConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          // Retour NOK
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_StPfsModifPfiAssocie_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return rstConnector.stPfsModifPfiAssocie(tracabilite_p, updateStPfsRequest_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_StPfsModifPfiAssocie_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }
}
