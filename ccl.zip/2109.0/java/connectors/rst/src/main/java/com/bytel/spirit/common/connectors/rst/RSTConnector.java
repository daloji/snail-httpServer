/*******************************************************************************
* $Id: RSTConnector.java 49682 2021-03-24 13:30:21Z fbarnabe $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.rst;

import java.text.MessageFormat;
import java.util.HashMap;
import java.util.List;

import javax.ws.rs.HttpMethod;
import javax.ws.rs.core.Response;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.conf.generated.Param;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.json.IRavelJson;
import com.bytel.ravel.common.json.RavelJson.RavelJsonBuilder;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.services.conf.connector.generated.Connector;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.connector.RESTRequest;
import com.bytel.ravel.services.connector.RESTRequest.RESTRequestBuilder;
import com.bytel.spirit.common.shared.functional.types.json.RavelJsonTools;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.IDonneesProvisionnees;
import com.bytel.spirit.common.shared.misc.connectors.AbstractInternalRESTConnector;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.BasicResponse;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.ressources.RetourConverter;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.rst.ServiceTechnique;
import com.bytel.spirit.common.shared.saab.rst.request.UpdateServiceTechniqueRequest;
import com.bytel.spirit.common.shared.saab.rst.request.UpdateStLienAllocationCommercialRequest;
import com.bytel.spirit.common.shared.saab.rst.request.UpdateStPfsRequest;
import com.bytel.spirit.common.shared.saab.rst.response.GetServiceTechniqueResponse;

/**
 *
 * @author pcarreir
 * @version ($Revision: 49682 $ $Date: 2021-03-24 14:30:21 +0100 (mer. 24 mars 2021) $)
 */
public class RSTConnector extends AbstractInternalRESTConnector implements IRSTConnector
{
  /**
   * The constant for clientOperateur param
   */
  private static final String PARAM_CLIENT_OPERATEUR = "clientOperateur"; //$NON-NLS-1$

  /**
   * Path for PAD4000 operation
   */
  private static final String PAD4000_PATH_PARAM = "PAD4000_ServiceTechnique"; //$NON-NLS-1$

  /**
   * Path for PAD4200 operation
   */
  private static final String PAD4200_PATH_PARAM = "PAD4200_StLienAllocationCommercial"; //$NON-NLS-1$

  /**
   * Path for PAD4300 operation
   */
  private static final String PAD4300_PATH_PARAM = "PAD4300_StPfs"; //$NON-NLS-1$

  /**
   * The constant for noCompte param
   */
  private static final String PARAM_NO_COMPTE = "noCompte"; //$NON-NLS-1$

  /**
   * The constant for typeStNiveau1 param
   */
  private static final String PARAM_TYPE_ST_NIVEAU1 = "typeStNiveau1"; //$NON-NLS-1$

  /**
   * The constant for typeStNiveau2 param
   */
  private static final String PARAM_TYPE_ST_NIVEAU2 = "typeStNiveau2"; //$NON-NLS-1$

  /**
   * The constant for idSt param
   */
  private static final String PARAM_ID_ST = "idSt"; //$NON-NLS-1$

  /**
   * Message error for Json parse error
   */
  private static final String JSON_ERROR_MESSAGE = Messages.getString("RSTConnector.JsonErrorMessage"); //$NON-NLS-1$

  /**
   * Message error for Json parse error
   */
  private static final String MISSING_CONFIGURATION_PARAMETER_MESSAGE = Messages.getString("RSTConnector.missing_configuration_parameter"); //$NON-NLS-1$

  /**
   * The constant for stPfsCreer
   */
  private static final String METHOD_NAME_ST_PFS_CREER = "stPfsCreer"; //$NON-NLS-1$

  /**
   * The constant for stPfsGererModifPfiAssocie service name
   */
  private static final String METHOD_NAME_ST_PFS_GERER_MODIFIER_PFI_ASSOCIE = "stPfsGererModifPfiAssocie"; //$NON-NLS-1$

  /**
   * The constant for stLienAllocationCommercialCreer service name
   */
  private static final String METHOD_NAME_ST_LIEN_ALLOCATION_COMMERCIAL_CREER = "stLienAllocationCommercialCreer"; //$NON-NLS-1$

  /**
   * The constant for stLienAllocationCommercialModifierStatutActif service name
   */
  private static final String METHOD_NAME_ST_LIEN_ALLOCATION_COMMERCIAL_MODIFIER_STATUT_ACTIF = "stLienAllocationCommercialModifierStatutActif"; //$NON-NLS-1$

  /**
   * The constant for stLienAllocationCommercialGererModifPfiAssocie service name
   */
  private static final String METHOD_NAME_ST_LIEN_ALLOCATION_COMMERCIAL_GERER_MODIF_PFI = "stLienAllocationCommercialGererModifPfiAssocie"; //$NON-NLS-1$

  /**
   * Constant for name of query parameter action
   */
  public static final String ACTION_QUERY_PARAM_NAME = "action"; //$NON-NLS-1$

  /**
   * Constant for action GererModifPfiAssocie
   */
  private static final String ACTION_GERER_MODIF_PFI_ASSOCIE = "GererModifPfiAssocie"; //$NON-NLS-1$

  /**
   * profil used in json serializtion
   */
  private static final String RAVEL_JSON_PROFIL = "STARK"; //$NON-NLS-1$

  /**
   * The lien allocation commercial endpoint
   */
  private String _stLienAllocationCommercialUrl;

  /**
   * The service technique pfs endpoint
   */
  private String _stPfsUrl;

  /**
   * The service technique endpoint
   */
  private String _serviceTechniqueUrl;

  /**
   * Ravel Json serializer
   */
  private IRavelJson _jsonBuilder = new RavelJsonBuilder().profil(RAVEL_JSON_PROFIL).build();

  @Override
  public String getConfigParameter(String connectorID_p, String paramName_p) throws RavelException
  {
    return null;
  }

  @Override
  public void loadConnectorConfiguration(Connector connector_p) throws RavelException
  {
    super.loadConnectorConfiguration(connector_p);

    // Get and validate specific configuration parameters
    for (Param param : connector_p.getParam())
    {
      switch (param.getName())
      {
        case PAD4000_PATH_PARAM:
          _serviceTechniqueUrl = param.getValue();
          break;
        case PAD4200_PATH_PARAM:
          _stLienAllocationCommercialUrl = param.getValue();
          break;
        case PAD4300_PATH_PARAM:
          _stPfsUrl = param.getValue();
          break;
        default:
          break;
      }
    }
  }

  @Override
  public ConnectorResponse<Retour, List<ServiceTechnique>> serviceTechniqueLireTousParPfi(Tracabilite tracabilite_p, String clientOperateur_p, String noCompte_p, String typeStNiveaux1_p, String typeStNiveaux2_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_serviceTechniqueUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MISSING_CONFIGURATION_PARAMETER_MESSAGE, PAD4000_PATH_PARAM));
      }

      List<ServiceTechnique> listeServiceTechnique = null;
      Retour retour;

      // Query parameters
      HashMap<String, String> queryParams = new HashMap<>();

      queryParams.put(PARAM_CLIENT_OPERATEUR, clientOperateur_p);
      queryParams.put(PARAM_NO_COMPTE, noCompte_p);
      if (StringTools.isNotNullOrEmpty(typeStNiveaux1_p))
      {
        queryParams.put(PARAM_TYPE_ST_NIVEAU1, typeStNiveaux1_p);
      }
      if (StringTools.isNotNullOrEmpty(typeStNiveaux2_p))
      {
        queryParams.put(PARAM_TYPE_ST_NIVEAU2, typeStNiveaux2_p);
      }
      Response response;

      try
      {
        RESTRequest request = new RESTRequestBuilder()//
            .httpMethod(HttpMethod.GET)//
            .traceability(tracabilite_p)//
            .headers(SPIRIT_STARK_REQUEST_HEADER)//
            .path(_serviceTechniqueUrl)//
            .queryParameter(queryParams)//
            .method(PAD4000_PATH_PARAM)//
            .build();

        response = sendRequest(request);
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content to a JSON string
      String jsonResponse = getContent(response, PAD4000_PATH_PARAM, tracabilite_p);

      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, JSON_ERROR_MESSAGE);
      }

      GetServiceTechniqueResponse getServiceTechniqueResponse = deserializeWithMoshi(jsonResponse, GetServiceTechniqueResponse.class);

      // Retour OK
      retour = RetourConverter.convertFromJsonRetour(getServiceTechniqueResponse.getRetour());
      listeServiceTechnique = getServiceTechniqueResponse.getListeSt();

      return new ConnectorResponse<>(retour, listeServiceTechnique);
    }
    catch (Exception ex_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, ex_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, List<ServiceTechnique>> serviceTechniqueLireUn(Tracabilite tracabilite_p, String idSt_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_serviceTechniqueUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MISSING_CONFIGURATION_PARAMETER_MESSAGE, PAD4000_PATH_PARAM));
      }

      List<ServiceTechnique> listeServiceTechnique = null;
      Retour retour;

      // Query parameters
      HashMap<String, String> queryParams = new HashMap<>();
      if (StringTools.isNotNullOrEmpty(idSt_p))
      {
        queryParams.put(PARAM_ID_ST, idSt_p);
      }

      Response response;

      try
      {
        RESTRequest request = new RESTRequestBuilder()//
            .httpMethod(HttpMethod.GET)//
            .traceability(tracabilite_p)//
            .headers(SPIRIT_STARK_REQUEST_HEADER)//
            .path(_serviceTechniqueUrl)//
            .queryParameter(queryParams)//
            .method(PAD4000_PATH_PARAM)//
            .build();

        response = sendRequest(request);
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content to a JSON string
      String jsonResponse = getContent(response, PAD4000_PATH_PARAM, tracabilite_p);

      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, JSON_ERROR_MESSAGE);
      }

      GetServiceTechniqueResponse getServiceTechniqueResponse = deserializeWithMoshi(jsonResponse, GetServiceTechniqueResponse.class);

      // Retour OK
      retour = RetourConverter.convertFromJsonRetour(getServiceTechniqueResponse.getRetour());
      listeServiceTechnique = getServiceTechniqueResponse.getListeSt();

      return new ConnectorResponse<>(retour, listeServiceTechnique);
    }
    catch (Exception ex_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, ex_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, Nothing> serviceTechniqueModifierStatut(Tracabilite tracabilite_p, UpdateServiceTechniqueRequest updateServiceTechniqueRequest_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_serviceTechniqueUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MISSING_CONFIGURATION_PARAMETER_MESSAGE, PAD4000_PATH_PARAM));
      }

      Retour retour;
      Response response;

      try
      {
        RESTRequest request = new RESTRequestBuilder()//
            .httpMethod(HttpMethod.PUT)// set method
            .traceability(tracabilite_p)// set tracabilite
            .headers(SPIRIT_STARK_REQUEST_HEADER)//set request header
            .path(_serviceTechniqueUrl)//set request url
            .method(PAD4000_PATH_PARAM)//set method name
            .request(updateServiceTechniqueRequest_p)//set body object
            .ravelJson(_jsonBuilder)//set json builder
            .build();

        response = sendRequest(request);
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content to a JSON string
      String jsonResponse = getContent(response, PAD4000_PATH_PARAM, tracabilite_p);

      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, JSON_ERROR_MESSAGE);
      }

      BasicResponse basicResponse = deserializeWithMoshi(jsonResponse, BasicResponse.class);

      // Retour OK
      retour = RetourConverter.convertFromJsonRetour(basicResponse.getRetour());

      return new ConnectorResponse<>(retour, null);
    }
    catch (Exception ex_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, ex_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, Nothing> stLienAllocationCommercialCreer(Tracabilite tracabilite_p, ServiceTechnique serviceTechnique_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_stLienAllocationCommercialUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MISSING_CONFIGURATION_PARAMETER_MESSAGE, PAD4200_PATH_PARAM));
      }

      // Call SAAB
      final Response response;
      try
      {

        RESTRequest request = new RESTRequestBuilder()//
            .httpMethod(HttpMethod.POST)// set method
            .traceability(tracabilite_p)// set tracabilite
            .headers(SPIRIT_STARK_REQUEST_HEADER)//set request header
            .path(_stLienAllocationCommercialUrl)//set request url
            .method(METHOD_NAME_ST_LIEN_ALLOCATION_COMMERCIAL_CREER)//set method name
            .request(serviceTechnique_p)//set body object
            .ravelJson(_jsonBuilder)//set json builder
            .build();

        response = sendRequest(request);
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content to a JSON string
      String jsonResponse = getContent(response, METHOD_NAME_ST_LIEN_ALLOCATION_COMMERCIAL_CREER, tracabilite_p);

      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, JSON_ERROR_MESSAGE);
      }

      BasicResponse basicResponse = deserializeWithMoshi(jsonResponse, BasicResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(basicResponse.getRetour());

      return new ConnectorResponse<>(retour, null);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }

  }

  @Override
  public ConnectorResponse<Retour, Nothing> stLienAllocationCommercialGererModifPfiAssocie(Tracabilite tracabilite_p, UpdateStLienAllocationCommercialRequest stLienAllocationCommercialRequest_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_stLienAllocationCommercialUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MISSING_CONFIGURATION_PARAMETER_MESSAGE, PAD4200_PATH_PARAM));
      }

      // Call SAAB
      final Response response;

      // Query parameters
      HashMap<String, String> queryParams = new HashMap<>();
      queryParams.put(ACTION_QUERY_PARAM_NAME, ACTION_GERER_MODIF_PFI_ASSOCIE);
      try
      {
        RESTRequest request = new RESTRequestBuilder()//
            .httpMethod(HttpMethod.PUT)// set method
            .traceability(tracabilite_p)// set tracabilite
            .headers(SPIRIT_STARK_REQUEST_HEADER)//set request header
            .path(_stLienAllocationCommercialUrl)//set request url
            .method(METHOD_NAME_ST_LIEN_ALLOCATION_COMMERCIAL_CREER)//set method name
            .queryParameter(queryParams)// set query parameters
            .request(stLienAllocationCommercialRequest_p)//set body object
            .ravelJson(_jsonBuilder)//set json builder
            .build();
        response = sendRequest(request);
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get json from response as string
      String jsonResponse = getContent(response, METHOD_NAME_ST_LIEN_ALLOCATION_COMMERCIAL_GERER_MODIF_PFI, tracabilite_p);

      // Check response
      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, JSON_ERROR_MESSAGE);
      }

      BasicResponse basicResponse = this.deserializeWithMoshi(jsonResponse, BasicResponse.class);

      // Retour OK
      return new ConnectorResponse<>(RetourConverter.convertFromJsonRetour(basicResponse.getRetour()), null);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, Nothing> stLienAllocationCommercialModifierStatutActif(Tracabilite tracabilite_p, String idSt_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_stLienAllocationCommercialUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MISSING_CONFIGURATION_PARAMETER_MESSAGE, PAD4200_PATH_PARAM));
      }

      // Query parameters
      HashMap<String, String> queryParams = new HashMap<>();
      if (StringTools.isNotNullOrEmpty(idSt_p))
      {
        queryParams.put(PARAM_ID_ST, idSt_p);
      }

      // Call SAAB
      final Response response;
      try
      {
        RESTRequest request = new RESTRequestBuilder()//
            .httpMethod(HttpMethod.PUT)// set method
            .traceability(tracabilite_p)// set tracabilite
            .headers(SPIRIT_STARK_REQUEST_HEADER)//set request header
            .path(_stLienAllocationCommercialUrl)//set request url
            .method(METHOD_NAME_ST_LIEN_ALLOCATION_COMMERCIAL_MODIFIER_STATUT_ACTIF)//set method name
            .queryParameter(queryParams)// set query parameters
            .build();
        response = sendRequest(request);
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content to a JSON string
      String jsonResponse = getContent(response, METHOD_NAME_ST_LIEN_ALLOCATION_COMMERCIAL_MODIFIER_STATUT_ACTIF, tracabilite_p);

      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, JSON_ERROR_MESSAGE);
      }

      BasicResponse basicResponse = deserializeWithMoshi(jsonResponse, BasicResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(basicResponse.getRetour());
      return new ConnectorResponse<>(retour, null);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, Nothing> stPfsCreer(Tracabilite tracabilite_p, ServiceTechnique serviceTechnique_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_stPfsUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MISSING_CONFIGURATION_PARAMETER_MESSAGE, PAD4300_PATH_PARAM));
      }

      // Call SAAB
      final Response response;
      try
      {
        RESTRequest request = new RESTRequestBuilder()//
            .httpMethod(HttpMethod.POST)// set method
            .traceability(tracabilite_p)// set tracabilite
            .headers(SPIRIT_STARK_REQUEST_HEADER)//set request header
            .path(_stPfsUrl)//set request url
            .method(METHOD_NAME_ST_PFS_CREER)//set method name
            .request(serviceTechnique_p)//set request body
            .ravelJson(_jsonBuilder)//set json builder
            .build();
        response = sendRequest(request);
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content to a JSON string
      String jsonResponse = getContent(response, METHOD_NAME_ST_PFS_CREER, tracabilite_p);

      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, JSON_ERROR_MESSAGE);
      }

      BasicResponse basicResponse = deserializeWithMoshi(jsonResponse, BasicResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(basicResponse.getRetour());
      return new ConnectorResponse<>(retour, null);

    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, Nothing> stPfsGererModifPfiAssocie(Tracabilite tracabilite_p, UpdateStPfsRequest updateStpfsRequest_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_stPfsUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MISSING_CONFIGURATION_PARAMETER_MESSAGE, PAD4300_PATH_PARAM));
      }

      // Call SAAB
      final Response response;
      // Query parameters
      HashMap<String, String> queryParams = new HashMap<>();
      queryParams.put(ACTION_QUERY_PARAM_NAME, ACTION_GERER_MODIF_PFI_ASSOCIE);
      try
      {

        RESTRequest request = new RESTRequestBuilder()//
            .httpMethod(HttpMethod.PUT)// set method
            .traceability(tracabilite_p)// set tracabilite
            .headers(SPIRIT_STARK_REQUEST_HEADER)//set request header
            .path(_stPfsUrl)//set request url
            .method(METHOD_NAME_ST_PFS_GERER_MODIFIER_PFI_ASSOCIE)//set method name
            .queryParameter(queryParams)//set query parameters
            .request(updateStpfsRequest_p)//set request body
            .ravelJson(_jsonBuilder)//set json builder
            .build();
        response = sendRequest(request);
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content to a JSON string
      String jsonResponse = getContent(response, METHOD_NAME_ST_PFS_GERER_MODIFIER_PFI_ASSOCIE, tracabilite_p);

      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, JSON_ERROR_MESSAGE);
      }

      BasicResponse basicResponse = deserializeWithMoshi(jsonResponse, BasicResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(basicResponse.getRetour());
      return new ConnectorResponse<>(retour, null);

    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, Nothing> stPfsModifierStatutActif(Tracabilite tracabilite_p, String idSt_p, IDonneesProvisionnees donneesProvisionnees_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_stPfsUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MISSING_CONFIGURATION_PARAMETER_MESSAGE, PAD4300_PATH_PARAM));
      }

      Retour retour;
      // Query parameters
      HashMap<String, String> queryParams = new HashMap<>();
      if (StringTools.isNotNullOrEmpty(idSt_p))
      {
        queryParams.put(PARAM_ID_ST, idSt_p);
      }

      Response response;

      try
      {
        RESTRequest request = new RESTRequestBuilder()//
            .httpMethod(HttpMethod.PUT)// set method
            .traceability(tracabilite_p)// set tracabilite
            .headers(SPIRIT_STARK_REQUEST_HEADER)//set request header
            .path(_stPfsUrl)//set request url
            .method(PAD4300_PATH_PARAM)//set method name
            .queryParameter(queryParams)//set query parameters
            .request(donneesProvisionnees_p)//set request body
            .ravelJson(_jsonBuilder)//set json builder
            .build();
        response = sendRequest(request);

      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content to a JSON string
      String jsonResponse = getContent(response, PAD4300_PATH_PARAM, tracabilite_p);

      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, JSON_ERROR_MESSAGE);
      }
      BasicResponse basicResponse = deserializeWithMoshi(jsonResponse, BasicResponse.class);

      // Retour OK
      retour = RetourConverter.convertFromJsonRetour(basicResponse.getRetour());

      return new ConnectorResponse<>(retour, null);
    }
    catch (Exception ex_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, ex_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, Nothing> stPfsModifPfiAssocie(Tracabilite tracabilite_p, UpdateStPfsRequest updateStPfsRequest_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_stPfsUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MISSING_CONFIGURATION_PARAMETER_MESSAGE, PAD4300_PATH_PARAM));
      }

      // Call SAAB
      final Response response;
      try
      {

        RESTRequest request = new RESTRequestBuilder()//
            .httpMethod(HttpMethod.PUT)// set method
            .traceability(tracabilite_p)// set tracabilite
            .headers(SPIRIT_STARK_REQUEST_HEADER)//set request header
            .path(_stPfsUrl)//set request url
            .method(METHOD_NAME_ST_PFS_GERER_MODIFIER_PFI_ASSOCIE)//set method name
            .request(updateStPfsRequest_p)//set request body
            .ravelJson(_jsonBuilder)//set json builder
            .build();
        response = sendRequest(request);
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content to a JSON string
      String jsonResponse = getContent(response, METHOD_NAME_ST_PFS_GERER_MODIFIER_PFI_ASSOCIE, tracabilite_p);

      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, JSON_ERROR_MESSAGE);
      }

      BasicResponse basicResponse = deserializeWithMoshi(jsonResponse, BasicResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(basicResponse.getRetour());
      return new ConnectorResponse<>(retour, null);

    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  /**
   * Deserializes the string in jsonString parameter and returns an instance of the deserialized object.
   *
   * @param jsonString_p
   *          The string to deserialize
   * @param clazz_p
   *          The class type of the objet to deserialize to
   * @return The deserialized object
   * @throws RavelException
   *           If thrown by the Json builder
   */
  private <T> T deserializeWithMoshi(String jsonString_p, Class<T> clazz_p) throws RavelException
  {
    return RavelJsonTools.getInstance().fromJson(jsonString_p, clazz_p);
  }

}
