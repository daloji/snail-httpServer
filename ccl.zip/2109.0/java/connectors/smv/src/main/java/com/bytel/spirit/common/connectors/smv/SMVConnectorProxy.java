/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.smv;

import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.probes.AvgDoubleCollectorItem;
import com.bytel.ravel.common.probes.AvgFlowPerSecondCollector;
import com.bytel.ravel.common.probes.RavelProbeConfigurationManager;
import com.bytel.ravel.services.connector.BaseProxy;
import com.bytel.ravel.services.connector.ConnectorExecution;
import com.bytel.ravel.services.connector.ConnectorManager;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.generated.ws.smv.prov.CustomerInformationType;
import com.bytel.spirit.common.generated.ws.smv.prov.CustomerOptionsType;
import com.bytel.spirit.common.generated.ws.smv.prov.GetCustomerInformation;
import com.bytel.spirit.common.generated.ws.smv.prov.GetCustomerOptions;
import com.bytel.spirit.common.generated.ws.smv.prov.ResetPinCode;
import com.bytel.spirit.common.generated.ws.smv.prov.ResetPurchaseCode;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

/**
 * @author acorreia
 * @version ($Revision$ $Date$)
 */
public class SMVConnectorProxy extends BaseProxy implements ISMV
{
  /** The instance of the SMVConnectorProxy. */
  private static final SMVConnectorProxy _instance = new SMVConnectorProxy();

  /**
   * @return the instance of SMVConnectorProxy.
   */
  public static SMVConnectorProxy getInstance()
  {
    return _instance;
  }

  /** Probe: measure the average number of getCustomerInformation requests per second. */
  AvgFlowPerSecondCollector _avg_getCustomerInformation_call_counter;

  /** Probe: measure the average execution time of getCustomerInformation requests. */
  AvgDoubleCollectorItem _avg_getCustomerInformation_exec_time;

  /** Probe: measure the average number of getCustomerOptions requests per second. */
  AvgFlowPerSecondCollector _avg_getCustomerOptions_call_counter;

  /** Probe: measure the average execution time of getCustomerOptions requests. */
  AvgDoubleCollectorItem _avg_getCustomerOptions_exec_time;

  /** Probe: measure the average number of resetCodePinParental requests per second. */
  AvgFlowPerSecondCollector _avg_resetCodePinParental_call_counter;

  /** Probe: measure the average execution time of resetCodePinParental requests. */
  AvgDoubleCollectorItem _avg_resetCodePinParental_exec_time;

  /** Probe: measure the average number of resetCodePinAchat requests per second. */
  AvgFlowPerSecondCollector _avg_resetCodePinAchat_call_counter;

  /** Probe: measure the average execution time of resetCodePinAchat requests. */
  AvgDoubleCollectorItem _avg_resetCodePinAchat_exec_time;

  /**
   * The constructor.
   */
  public SMVConnectorProxy()
  {
    _avg_getCustomerInformation_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("avg_getCustomerInformation_call_counter", "SMVConnectorProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_getCustomerInformation_exec_time = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("avg_getCustomerInformation_exec_time", "SMVConnectorProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_getCustomerOptions_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("avg_getCustomerOptions_call_counter", "SMVConnectorProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_getCustomerOptions_exec_time = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("avg_getCustomerOptions_exec_time", "SMVConnectorProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_resetCodePinParental_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("avg_resetCodePinParental_call_counter", "SMVConnectorProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_resetCodePinParental_exec_time = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("avg_resetCodePinParental_exec_time", "SMVConnectorProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_resetCodePinAchat_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("avg_resetCodePinAchat_call_counter", "SMVConnectorProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_resetCodePinAchat_exec_time = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("avg_resetCodePinAchat_exec_time", "SMVConnectorProxy"); //$NON-NLS-1$ //$NON-NLS-2$

  }

  /**
   * {@inheritDoc}
   */
  @Override
  public ConnectorResponse<CustomerInformationType, Nothing> getCustomerInformation(Tracabilite tracabilite_p, GetCustomerInformation getCustomerInformation_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<CustomerInformationType, Nothing>>(ISMVConnector.BEAN_ID_SMV_PROV)
    {
      @Override
      public ConnectorResponse<CustomerInformationType, Nothing> run() throws RavelException
      {
        ISMVConnector connector = (ISMVConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_getCustomerInformation_call_counter.measure();
        long startTime = System.currentTimeMillis();

        try
        {
          return connector.getCustomerInformation(tracabilite_p, getCustomerInformation_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_getCustomerInformation_exec_time.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public ConnectorResponse<CustomerOptionsType, Nothing> getCustomerOptions(Tracabilite tracabilite_p, GetCustomerOptions getCustomerOptions_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<CustomerOptionsType, Nothing>>(ISMVConnector.BEAN_ID_SMV_PROV)
    {
      @Override
      public ConnectorResponse<CustomerOptionsType, Nothing> run() throws RavelException
      {
        ISMVConnector connector = (ISMVConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_getCustomerOptions_call_counter.measure();
        long startTime = System.currentTimeMillis();

        try
        {
          return connector.getCustomerOptions(tracabilite_p, getCustomerOptions_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_getCustomerOptions_exec_time.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Nothing, Nothing> resetCodePinAchat(Tracabilite tracabilite_p, ResetPurchaseCode resetPurchaseCode_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Nothing, Nothing>>(ISMVConnector.BEAN_ID_SMV_PROV)
    {
      @Override
      public ConnectorResponse<Nothing, Nothing> run() throws RavelException
      {
        ISMVConnector connector = (ISMVConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_resetCodePinAchat_call_counter.measure();
        long startTime = System.currentTimeMillis();

        try
        {
          return connector.resetCodePinAchat(tracabilite_p, resetPurchaseCode_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_resetCodePinAchat_exec_time.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public ConnectorResponse<Nothing, Nothing> resetCodePinParental(Tracabilite tracabilite_p, ResetPinCode resetPinCode_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Nothing, Nothing>>(ISMVConnector.BEAN_ID_SMV_PROV)
    {
      @Override
      public ConnectorResponse<Nothing, Nothing> run() throws RavelException
      {
        ISMVConnector connector = (ISMVConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_resetCodePinParental_call_counter.measure();
        long startTime = System.currentTimeMillis();

        try
        {
          return connector.resetCodePinParental(tracabilite_p, resetPinCode_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_resetCodePinParental_exec_time.updateAvgValue(endTime - startTime);
        }
      }
    });
  }
}