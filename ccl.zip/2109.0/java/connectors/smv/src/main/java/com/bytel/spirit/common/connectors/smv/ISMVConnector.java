/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.smv;

import com.bytel.ravel.services.connector.IConnector;

/**
 * @author acorreia
 * @version ($Revision$ $Date$)
 */
public interface ISMVConnector extends IConnector, ISMV
{
  /**
   * The id used to retrieve the SMV Prov connector.
   */
  String BEAN_ID_SMV_PROV = "SMVProvConnector"; //$NON-NLS-1$
}
