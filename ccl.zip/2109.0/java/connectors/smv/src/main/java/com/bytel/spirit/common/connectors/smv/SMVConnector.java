/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.smv;

import java.text.MessageFormat;
import java.util.HashMap;
import java.util.Map;

import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.services.conf.connector.generated.Connector;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.generated.ws.smv.prov.CustomerInformationType;
import com.bytel.spirit.common.generated.ws.smv.prov.CustomerOptionsType;
import com.bytel.spirit.common.generated.ws.smv.prov.GetCustomerInformation;
import com.bytel.spirit.common.generated.ws.smv.prov.GetCustomerOptions;
import com.bytel.spirit.common.generated.ws.smv.prov.ProvPort;
import com.bytel.spirit.common.generated.ws.smv.prov.ResetPinCode;
import com.bytel.spirit.common.generated.ws.smv.prov.ResetPurchaseCode;
import com.bytel.spirit.common.shared.misc.connectors.AbstractSpiritSOAPConnector;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

/**
 * @author acorreia
 * @version ($Revision$ $Date$)
 */
public class SMVConnector extends AbstractSpiritSOAPConnector implements ISMVConnector
{

  /** Methods names. */
  private final static class MethodNames
  {
    /** Name for getCustomerInformation operation. */
    private static final String GET_CUSTOMER_INFORMATION = "getCustomerInformation"; //$NON-NLS-1$

    /** Name for getCustomerOptions operation. */
    private static final String GET_CUSTOMER_OPTIONS = "getCustomerOptions"; //$NON-NLS-1$

    /** Name for resetCodePinParental operation. */
    private static final String RESET_CODE_PIN_PARENTAL = "resetPinCode"; //$NON-NLS-1$

    /** Name for resetCodePinAchat operation. */
    private static final String RESET_CODE_PIN_ACHAT = "resetPurchaseCode"; //$NON-NLS-1$

    /** Empty private constructor. */
    private MethodNames()
    {

    }
  }

  /** The error message for TechnicalException. */
  private static final String ERROR_TECHNICAL_EXCEPTION = Messages.getString("SMVConnector.TechnicalExceptionMessage"); //$NON-NLS-1$

  @Override
  public String getConfigParameter(String arg0_p, String arg1_p)
  {
    return null;
  }

  /**
   * This method is used to obtain information from a customer.
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param getCustomerInformation_p
   *          the customer id.
   *
   * @return the customer information.
   * @throws RavelException
   *           on error.
   */
  @Override
  public ConnectorResponse<CustomerInformationType, Nothing> getCustomerInformation(Tracabilite tracabilite_p, GetCustomerInformation getCustomerInformation_p) throws RavelException
  {
    try
    {
      Object[] request = new Object[] { getCustomerInformation_p.getCustomerId() };
      // Call SOAP Service
      Map<String, String> queryParams = new HashMap<>();
      return new ConnectorResponse<>(sendRequest(tracabilite_p, MethodNames.GET_CUSTOMER_INFORMATION, null, null, null, queryParams, null, request), null);
    }
    catch (Exception e)
    {
      final String message = MessageFormat.format(ERROR_TECHNICAL_EXCEPTION, MethodNames.GET_CUSTOMER_INFORMATION, e.getMessage());
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, message));

      throw new RavelException(ExceptionType.PFS_EXCEPTION, ErrorCode.CNCTOR_00010, message, e);
    }
  }

  /**
   * This method is used to obtain options from a customer.
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param getCustomerOptions_p
   *          the customer id.
   *
   * @return the customer options.
   * @throws RavelException
   *           on error.
   */
  @Override
  public ConnectorResponse<CustomerOptionsType, Nothing> getCustomerOptions(Tracabilite tracabilite_p, GetCustomerOptions getCustomerOptions_p) throws RavelException
  {
    try
    {
      Object[] request = new Object[] { getCustomerOptions_p.getCustomerId() };
      // Call SOAP Service
      Map<String, String> queryParams = new HashMap<>();
      return new ConnectorResponse<>(sendRequest(tracabilite_p, MethodNames.GET_CUSTOMER_OPTIONS, null, null, null, queryParams, null, request), null);
    }
    catch (Exception e)
    {
      final String message = MessageFormat.format(ERROR_TECHNICAL_EXCEPTION, MethodNames.GET_CUSTOMER_OPTIONS, e.getMessage());
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, message));

      throw new RavelException(ExceptionType.PFS_EXCEPTION, ErrorCode.CNCTOR_00010, message, e);
    }
  }

  @Override
  public void loadConnectorConfiguration(Connector connector_p) throws RavelException
  {
    setServiceInterfaceClass(ProvPort.class);
    super.loadConnectorConfiguration(connector_p);
  }

  @Override
  public ConnectorResponse<Nothing, Nothing> resetCodePinAchat(Tracabilite tracabilite_p, ResetPurchaseCode resetPurchaseCode_p) throws RavelException
  {
    try
    {
      Object[] request = new Object[] { resetPurchaseCode_p };
      // Call SOAP Service
      Map<String, String> queryParams = new HashMap<>();
      return new ConnectorResponse<>(sendRequest(tracabilite_p, MethodNames.RESET_CODE_PIN_ACHAT, null, null, null, queryParams, null, request), null);
    }
    catch (Exception e)
    {
      final String message = MessageFormat.format(ERROR_TECHNICAL_EXCEPTION, MethodNames.RESET_CODE_PIN_ACHAT, e.getMessage());
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, message));

      throw new RavelException(ExceptionType.PFS_EXCEPTION, ErrorCode.CNCTOR_00010, message, e);
    }
  }

  /**
   * This method is used reset the parental code from one equipment.
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param resetPinCode_p
   *          the equipment .
   *
   * @return the customer options.
   * @throws RavelException
   *           on error.
   */
  @Override
  public ConnectorResponse<Nothing, Nothing> resetCodePinParental(Tracabilite tracabilite_p, ResetPinCode resetPinCode_p) throws RavelException
  {
    try
    {
      Object[] request = new Object[] { resetPinCode_p };
      // Call SOAP Service
      Map<String, String> queryParams = new HashMap<>();
      return new ConnectorResponse<>(sendRequest(tracabilite_p, MethodNames.RESET_CODE_PIN_PARENTAL, null, null, null, queryParams, null, request), null);
    }
    catch (Exception e)
    {
      final String message = MessageFormat.format(ERROR_TECHNICAL_EXCEPTION, MethodNames.RESET_CODE_PIN_PARENTAL, e.getMessage());
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, message));

      throw new RavelException(ExceptionType.PFS_EXCEPTION, ErrorCode.CNCTOR_00010, message, e);
    }
  }

}
