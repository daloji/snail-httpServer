/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.smv;

import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.generated.ws.smv.prov.CustomerInformationType;
import com.bytel.spirit.common.generated.ws.smv.prov.CustomerOptionsType;
import com.bytel.spirit.common.generated.ws.smv.prov.GetCustomerInformation;
import com.bytel.spirit.common.generated.ws.smv.prov.GetCustomerOptions;
import com.bytel.spirit.common.generated.ws.smv.prov.ResetPinCode;
import com.bytel.spirit.common.generated.ws.smv.prov.ResetPurchaseCode;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

/**
 * SMV Connector interface
 *
 * @author acorreia
 * @version ($Revision$ $Date$)
 */
public interface ISMV
{
  /**
   * This method is used reset the parental code from one equipment.
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param resetPinCode_p
   *          the equipment code.
   *
   * @return the customer options.
   * @throws RavelException
   *           on error.
   */
  public ConnectorResponse<Nothing, Nothing> resetCodePinParental(Tracabilite tracabilite_p, ResetPinCode resetPinCode_p) throws RavelException;

  /**
   * This method is used to obtain information from a customer.
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param getCustomerInformation_p
   *          the customer id.
   *
   * @return the customer information.
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<CustomerInformationType, Nothing> getCustomerInformation(Tracabilite tracabilite_p, GetCustomerInformation getCustomerInformation_p) throws RavelException;

  /**
   * This method is used to obtain information from a customer.
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param getCustomerOptions_p
   *          the customer id.
   *
   * @return the customer information.
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<CustomerOptionsType, Nothing> getCustomerOptions(Tracabilite tracabilite_p, GetCustomerOptions getCustomerOptions_p) throws RavelException;

  /**
   * This method is used to obtain information from a customer.
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param resetPurchaseCode_p
   *          the equipment code.
   *
   * @return the customer information.
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Nothing, Nothing> resetCodePinAchat(Tracabilite tracabilite_p, ResetPurchaseCode resetPurchaseCode_p) throws RavelException;
}
