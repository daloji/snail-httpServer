/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.smv;

import java.text.MessageFormat;
import java.util.Objects;

import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionTools;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.log.event.SystemLogEvent;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.services.connector.pools.soap.SoapInstance;

/**
 * SOAP Caller (for authentication).
 *
 * @param <P>
 *          Generated interface of the SOAP Service (by JAX-WS compatible tool).
 *
 * @author mlebihan
 * @version ($Revision$ $Date$)
 */
public class SoapCaller<P>
{
  /** Proxy Login. */
  private String _proxyLogin;

  /** Proxy Password. */
  private String _proxyPassword;

  /** Proxy Host. */
  private String _proxyHost;

  /** Proxy Port. */
  private int _proxyPort;

  /** Timeout. */
  private int _timeout;

  /** URL. */
  private String _url;

  /** SOAP Version. */
  private String _soapVersion;

  /** Name of this REST connection. */
  private String _name;

  /** Proxy class of the SOAP service : generated interface of the SOAP Service (by JAX-WS compatible tool). */
  private Class<P> _proxyClass;

  /**
   * Construct an Altitude Authentifcation Service.
   *
   * @param proxyClass_p
   *          Generated interface of the SOAP Service (by JAX-WS compatible tool).
   * @param name_p
   *          Name of that REST connection.
   * @param completeUrl_p
   *          Complete URL of the REST service.
   * @param soapVersion_p
   *          SOAP version.
   * @param timeout_p
   *          Timeout.
   * @param proxyLogin_p
   *          Proxy Login.
   * @param proxyPassword_p
   *          Proxy password.
   * @param proxyHost_p
   *          Proxy host.
   * @param proxyPort_p
   *          Proxy port.
   */
  public SoapCaller(Class<P> proxyClass_p, String name_p, String completeUrl_p, String soapVersion_p, int timeout_p, //
      String proxyLogin_p, String proxyPassword_p, String proxyHost_p, int proxyPort_p)
  {
    _proxyClass = proxyClass_p;
    _proxyLogin = proxyLogin_p;
    _proxyPassword = proxyPassword_p;
    _proxyHost = proxyHost_p;
    _proxyPort = proxyPort_p;
    _timeout = timeout_p;
    _url = completeUrl_p;
    _soapVersion = soapVersion_p;
    _name = name_p;
  }

  /**
   * Send a SOAP request and receive a generic response.
   *
   * @param responseClass_p
   *          The expected class of the returned object.
   * @param <R>
   *          The expected class of the returned object
   *
   * @param msgId_p
   *          Message id.
   * @param methodName_p
   *          SOAP method name to call.
   * @param request_p
   *          SOAP Request
   * @return response
   * @throws RavelException
   *           if an internal SOAP server error occurs.
   */
  public <R> R send(Class<R> responseClass_p, String msgId_p, String methodName_p, Object... request_p) throws RavelException
  {
    Objects.requireNonNull(methodName_p, "Cannot send a null SOAP request without method name."); //$NON-NLS-1$
    Objects.requireNonNull(request_p, "Cannot send a null SOAP request."); //$NON-NLS-1$

    SoapInstance<P> soapInstance = soapInstance();

    try
    {
      Object[] invoke = soapInstance.getClient().invoke(methodName_p, request_p);

      if ((invoke != null) && (invoke.length != 0))
      {
        Object o = invoke[0];

        if ((o != null) && (responseClass_p.isInstance(o) == false))
        {
          String format = "SOAP method {0} returned a non-null object of class {1} instead of one of {2} (or inheritable) expected."; //$NON-NLS-1$
          StringBuilder message = new StringBuilder(MessageFormat.format(format, methodName_p, o.getClass().getSimpleName(), responseClass_p.getSimpleName()));

          RavelException ex = new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, message.toString());
          RavelLogger.log(new SystemLogEvent(LogSeverity.WARNING, null, ex)); // No msgId.
          throw ex;
        }

        @SuppressWarnings("unchecked") // We just checked that.
        R response = (R) o;

        return response;
      }

      return null;
    }
    catch (Exception exception)
    {
      throw buildTechnicalException(exception, msgId_p, methodName_p);
    }
  }

  /**
   * Build a log entry and throws an {@link RavelException} for a technical problem.
   *
   * @param exception_p
   *          exception from connector Studio
   * @param msgIdIsis_p
   *          The current MsgIdISIS
   * @param method_p
   *          The method name in which the fault was raised.
   * @return The {@link RavelException} built
   */
  private RavelException buildTechnicalException(final Exception exception_p, final String msgIdIsis_p, final String method_p)
  {
    final String messageTechnicalException = "Technical Exception in SoapCaller during {0} call: code({1}) reason({2})"; // Adapted from Ravel properties file. //$NON-NLS-1$

    String message = MessageFormat.format(messageTechnicalException, method_p, StringConstants.EMPTY_STRING, exception_p.getMessage());
    // add fileName and line number of the exception
    message += ExceptionTools.getExceptionLineAndFile(exception_p);
    RavelLogger.log(new SystemLogEvent(LogSeverity.ERROR, msgIdIsis_p, message));
    RavelLogger.log(new SystemLogEvent(LogSeverity.DEBUG, msgIdIsis_p, new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, "Technical Exception", exception_p))); //$NON-NLS-1$
    return new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, message, _name, exception_p);
  }

  /**
   * Return a SOAP instance.
   *
   * @return Rest instance.
   * @throws RavelException
   *           if the SOAP instance cannot be built.
   */
  private SoapInstance<P> soapInstance() throws RavelException
  {
    SoapInstance<P> soapInstance = new SoapInstance<P>(_proxyClass, _url, _timeout, _timeout, _soapVersion, null);

    // Set the proxy parameters if the proxy host is filled.
    if (StringTools.isNotNullOrEmpty(_proxyHost))
    {
      soapInstance.setProxy(_proxyLogin, _proxyPassword, _proxyHost, _proxyPort);
    }

    if (StringTools.isNotNullOrEmpty(_proxyHost))
    {
      soapInstance.setProxy(_proxyLogin, _proxyPassword, _proxyHost, _proxyPort);
    }

    return soapInstance;
  }
}
