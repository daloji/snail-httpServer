/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.smv;

import java.text.MessageFormat;
import java.time.Instant;
import java.util.Map;

import javax.ws.rs.core.MultivaluedMap;

import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.log.event.SystemLogEvent;
import com.bytel.ravel.services.connector.IAuthentService;
import com.bytel.spirit.common.generated.ws.smv.authentication.AuthenticateUserParameter;
import com.bytel.spirit.common.generated.ws.smv.authentication.AuthenticateUserResult;
import com.bytel.spirit.common.generated.ws.smv.authentication.AuthenticationPort;

/**
 * SMV Authentification Service.
 *
 * @author mlebihan
 * @version ($Revision$ $Date$)
 */
public class SMVAuthentService implements IAuthentService
{
  /** SMV Token. */
  private AuthenticateUserResult _token;

  /** SOAP Caller. */
  private SoapCaller<AuthenticationPort> _soapCaller;

  /** SMV login. */
  private String _login;

  /** SMV password. */
  private String _password;

  /**
   * Construct an SMV Authentication Service.
   *
   * @param name_p
   *          Name of that REST connection.
   * @param completeUrl_p
   *          Complete URL of the REST service.
   * @param login_p
   *          Login.
   * @param password_p
   *          Password.
   * @param timeout_p
   *          Timeout.
   * @param proxyLogin_p
   *          Proxy Login.
   * @param proxyPassword_p
   *          Proxy password.
   * @param proxyHost_p
   *          Proxy host.
   * @param proxyPort_p
   *          Proxy port.
   */
  public SMVAuthentService(String name_p, String completeUrl_p, String login_p, String password_p, int timeout_p, //
      String proxyLogin_p, String proxyPassword_p, String proxyHost_p, int proxyPort_p)
  {
    _soapCaller = new SoapCaller<>(AuthenticationPort.class, name_p, completeUrl_p, //
        null, // No SOAP version specified. "1.2" might be set instead.
        timeout_p, //
        proxyLogin_p, proxyPassword_p, proxyHost_p, proxyPort_p);

    _login = login_p;
    _password = password_p;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void cleanInvalidToken()
  {
    _token = null;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void completeSecurityInformation(MultivaluedMap<String, String> headers_p, Map<String, String> queryParams_p) throws RavelException
  {
    String token = getAccessToken(); // Always get token before tokenType

    queryParams_p.put("SecurityToken", token); //$NON-NLS-1$
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public String getAccessToken() throws RavelException
  {
    // Check token expiration. Token carries a long integer : milliseconds, GMT, from 01.01.1970 expired since, cf. SmartvisionSPF4.18_API_EndUser_WebService_IRS
    if (_token != null)
    {
      long now = System.currentTimeMillis();

      if (now < _token.getExpirationDate())
      {
        return _token.getSecurityToken();
      }
    }
    else
    {
      String format = "There''s no access token for {0} yet. Asking for one..."; //$NON-NLS-1$
      String message = MessageFormat.format(format, getClass().getSimpleName());

      RavelLogger.log(new SystemLogEvent(LogSeverity.DEBUG, message));
    }

    // Ask for a new token.
    AuthenticateUserParameter authenficateUserRequest = new AuthenticateUserParameter();
    authenficateUserRequest.setLogin(_login);
    authenficateUserRequest.setPassword(_password);

    _token = _soapCaller.send(AuthenticateUserResult.class, "SMVAuthentication", "authenticateUser", authenficateUserRequest); //$NON-NLS-1$ //$NON-NLS-2$

    if (_token == null)
    {
      String message = "SMV partner encountered a problem during token delivery and returned no token."; //$NON-NLS-1$

      RavelException ex = new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, message);
      RavelLogger.log(new SystemLogEvent(LogSeverity.WARNING, "SMVAuthentication", ex)); //$NON-NLS-1$
      throw ex;
    }

    String format2 = "Token received for {0} : expiration date : {1}."; //$NON-NLS-1$
    String dateExpiration = Instant.ofEpochMilli(_token.getExpirationDate()).toString();
    String message2 = MessageFormat.format(format2, getClass().getSimpleName(), dateExpiration);

    RavelLogger.log(new SystemLogEvent(LogSeverity.DEBUG, message2));

    return _token.getSecurityToken();
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public String getTokenType()
  {
    return "Bearer"; //$NON-NLS-1$
  }
}
