/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.smv;

import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.Hashtable;

import javax.xml.bind.ValidationEventHandler;

import org.apache.cxf.endpoint.Client;
import org.apache.cxf.interceptor.Interceptor;
import org.easymock.EasyMock;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.bytel.ravel.common.conf.generated.LoadBalancer;
import com.bytel.ravel.common.conf.generated.Param;
import com.bytel.ravel.common.configuration.ConfigFileManager;
import com.bytel.ravel.common.encryption.PasswordDecrypter;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.test.JUnitTools;
import com.bytel.ravel.common.test.podam.JavaTimeManufacturer;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.net.loadbalancing.Element;
import com.bytel.ravel.net.loadbalancing.ILoadBalancer;
import com.bytel.ravel.net.loadbalancing.URLBalancedElement;
import com.bytel.ravel.services.conf.connector.generated.Connector;
import com.bytel.ravel.services.conf.connector.generated.URL;
import com.bytel.ravel.services.conf.connector.generated.URLS;
import com.bytel.ravel.services.connector.AbstractSOAPConnector;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.connector.pools.soap.ISoapInterceptorsFactory;
import com.bytel.ravel.services.connector.pools.soap.SoapConnectorPool;
import com.bytel.ravel.services.connector.pools.soap.SoapInstance;
import com.bytel.spirit.common.generated.ws.smv.prov.CustomerInformationType;
import com.bytel.spirit.common.generated.ws.smv.prov.CustomerOptionsType;
import com.bytel.spirit.common.generated.ws.smv.prov.GetCustomerInformation;
import com.bytel.spirit.common.generated.ws.smv.prov.GetCustomerOptions;
import com.bytel.spirit.common.generated.ws.smv.prov.ResetPinCode;
import com.bytel.spirit.common.generated.ws.smv.prov.ResetPurchaseCode;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 * Test class for SMVConnector.
 *
 * @author acorreia
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({ AbstractSOAPConnector.class, PasswordDecrypter.class })
public class SMVConnectorTest
{
  /** Configuration parameters. */
  private final static class ConfigParameters
  {
    /** The constant for the service name, given that it has multiple services. */
    private static final String CONNECTOR_SERVICE_NAME = "SMV_SERVICE_NAME"; //$NON-NLS-1$

    /** The constant for the variable login in the configuration file. */
    private static final String LOGIN = "LOGIN"; //$NON-NLS-1$

    /** The constant for the variable password in the configuration file. */
    private static final String PASSWORD = "PASSWORD"; //$NON-NLS-1$
  }

  /** Configuration parameter values. */
  private final static class ConfigParametersValues
  {
    /** Login value. */
    private static final String LOGIN = "LOGIN"; //$NON-NLS-1$

    /** Password value, crypted. */
    private static final String PASSWORD = "0hxtgyNUmrjG1Be3E9y0rA=="; //$NON-NLS-1$
  }

  /** Methods names. */
  private final static class MethodNames
  {
    /** Get Gustomer information method */
    final static String GET_CUSTOMER_INFORMATION = "getCustomerInformation"; //$NON-NLS-1$

    /** Name for getCustomerOptions operation. */
    private static final String GET_CUSTOMER_OPTIONS = "getCustomerOptions"; //$NON-NLS-1$

    /** Name for getCustomerOptions operation. */
    private static final String RESET_CODE_PIN_PARENTAL = "resetPinCode"; //$NON-NLS-1$

    /** Name for resetCodePinAchat operation. */
    private static final String RESET_CODE_PIN_ACHAT = "resetPurchaseCode"; //$NON-NLS-1$
  }

  /** Request parameters values. */
  private final static class RequestParametersValues
  {
    /** Customer id request parameter. */
    final static String CUSTOMER_ID = "CUSTOMER_ID"; //$NON-NLS-1$
  }

  /** Response values. */
  private final static class ResponseValues
  {
    /** HD Status. */
    final static boolean HD_STATUS = false;

    /** Zip code. */
    final static String ZIP_CODE = "ZIP_CODE"; //$NON-NLS-1$

    /** Localization. */
    final static String LOCALIZATION = "LOCALIZATION"; //$NON-NLS-1$
  }

  /** Error message for MissingParameter. */
  private static final String ERROR_MISSING_PARAMETER = Messages.getString("SMVConnector.MissingParameter"); //$NON-NLS-1$

  /** Error message for InvalidParameter. */
  private static final String ERROR_INVALID_PARAMETER = Messages.getString("SMVConnector.InvalidParameter"); //$NON-NLS-1$

  /**
   * Instance of {@code SMVConnector}.
   */
  private SMVConnector _connector;

  /**
   * Factory to generate beans
   */
  private PodamFactory _podam = new PodamFactoryImpl();

  /** Configuration manager. */
  ConfigFileManager _configFileManager;

  /**
   * Mock {@link ILoadBalancer}
   */
  @MockStrict
  ILoadBalancer<URLBalancedElement> _loadBalancerMock;

  /**
   * Mock {@link URLBalancedElement}
   */
  @MockStrict
  URLBalancedElement _urlBalancedElementMock;

  /**
   * Mock of connectors pool HTTP
   */
  @SuppressWarnings("rawtypes")
  @MockStrict
  Hashtable<String, SoapConnectorPool> _connectorPoolMock;

  /**
   * Mock {@link SoapConnectorPool}
   */
  @SuppressWarnings("rawtypes")
  @MockStrict
  SoapConnectorPool _soapConnectorPoolMock;

  /**
   * Mock {@link SoapInstance}
   */
  @SuppressWarnings("rawtypes")
  @MockStrict
  SoapInstance _soapInstanceMock;

  /**
   * Mock {@link Client}
   */
  @MockStrict
  Client _soapInstanceMockClient;

  /**
   * Initialize before tests
   *
   * @throws Exception
   *           Thrown in case of error during switch in attributes of parent class
   */
  @Before
  public void beforeTest() throws Exception
  {
    PowerMock.mockStaticStrict(PasswordDecrypter.class);

    _podam.getStrategy().setMemoization(true);
    _podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());
    JavaTimeManufacturer.registerPodamFactory(_podam);

    _connector = new SMVConnector();

    EasyMock.expect(PasswordDecrypter.decrypt("0hxtgyNUmrjG1Be3E9y0rA==")).andReturn("PASSWORD").anyTimes(); //$NON-NLS-1$ //$NON-NLS-2$
    PowerMock.replay(PasswordDecrypter.class);
  }

  /**
   * Case when sendRequest throws a RavelException
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public void getCustomerInformation_Exception() throws Exception
  {
    Tracabilite tracabilite_p = _podam.manufacturePojoWithFullData(Tracabilite.class);

    loadSMVConnector(ISMVConnector.BEAN_ID_SMV_PROV);

    final String urlBalancedElementName = org.apache.commons.lang3.RandomStringUtils.randomAlphanumeric(45);
    final String urlBalancedElementDescription = org.apache.commons.lang3.RandomStringUtils.randomAlphabetic(9);

    // Mock load balancer
    EasyMock.expect(_loadBalancerMock.chooseBalancedElement()).andReturn(_urlBalancedElementMock);
    EasyMock.expect(_urlBalancedElementMock.getName()).andReturn(urlBalancedElementName);
    EasyMock.expect(_urlBalancedElementMock.getDescription()).andReturn(urlBalancedElementDescription);
    EasyMock.expect(_urlBalancedElementMock.getName()).andReturn(urlBalancedElementName);
    EasyMock.expect(_connectorPoolMock.get(urlBalancedElementName)).andReturn(_soapConnectorPoolMock);
    EasyMock.expect(_soapConnectorPoolMock.borrowObject()).andReturn(_soapInstanceMock);

    EasyMock.expect(_soapInstanceMock.getClient()).andReturn(_soapInstanceMockClient);

    _soapConnectorPoolMock.returnObject(EasyMock.anyObject());
    EasyMock.expectLastCall();

    JUnitTools.setInaccessibleFieldValue(_connector, "_loadBalancer", _loadBalancerMock); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_connectorPool", _connectorPoolMock); //$NON-NLS-1$

    EasyMock.expect(_soapInstanceMockClient.getInInterceptors()).andReturn(new ArrayList<Interceptor<?>>());
    EasyMock.expect(_soapInstanceMockClient.getOutInterceptors()).andReturn(new ArrayList<Interceptor<?>>());

    EasyMock.expect(_soapInstanceMockClient.invoke(EasyMock.eq(MethodNames.GET_CUSTOMER_INFORMATION), EasyMock.eq(createGetCustomerInformation().getCustomerId()))).andThrow(new SocketTimeoutException("ERROR")); //$NON-NLS-1$

    try
    {
      PowerMock.replayAll();
      _connector.getCustomerInformation(tracabilite_p, createGetCustomerInformation());

    }
    catch (RavelException e)
    {
      PowerMock.verifyAll();

      Assert.assertEquals(ExceptionType.PFS_EXCEPTION, e.getExceptionType());
      Assert.assertEquals(ErrorCode.CNCTOR_00010, e.getErrorCode());
    }
  }

  /**
   * Cas Nominal
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public void getCustomerInformation_OK() throws Exception
  {
    Tracabilite tracabilite_p = _podam.manufacturePojoWithFullData(Tracabilite.class);
    CustomerInformationType customerInformationType = createCustomerInformationType();
    Object[] responseClient = { customerInformationType };

    loadSMVConnector(ISMVConnector.BEAN_ID_SMV_PROV);
    initializeMocksForSendRequestGetCustomerInformation();

    EasyMock.expect(_soapInstanceMockClient.invoke(EasyMock.eq(MethodNames.GET_CUSTOMER_INFORMATION), EasyMock.eq(createGetCustomerInformation().getCustomerId()))).andReturn(responseClient);
    PowerMock.replayAll();

    final ConnectorResponse<CustomerInformationType, Nothing> result = _connector.getCustomerInformation(tracabilite_p, createGetCustomerInformation());
    PowerMock.verifyAll();
    Assert.assertEquals(customerInformationType, result._first);
  }

  /**
   * Case when sendRequest throws a RavelException
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public void getCustomerOptions_Exception() throws Exception
  {
    Tracabilite tracabilite_p = _podam.manufacturePojoWithFullData(Tracabilite.class);

    loadSMVConnector(ISMVConnector.BEAN_ID_SMV_PROV);

    final String urlBalancedElementName = org.apache.commons.lang3.RandomStringUtils.randomAlphanumeric(45);
    final String urlBalancedElementDescription = org.apache.commons.lang3.RandomStringUtils.randomAlphabetic(9);

    // Mock load balancer
    EasyMock.expect(_loadBalancerMock.chooseBalancedElement()).andReturn(_urlBalancedElementMock);
    EasyMock.expect(_urlBalancedElementMock.getName()).andReturn(urlBalancedElementName);
    EasyMock.expect(_urlBalancedElementMock.getDescription()).andReturn(urlBalancedElementDescription);
    EasyMock.expect(_urlBalancedElementMock.getName()).andReturn(urlBalancedElementName);
    EasyMock.expect(_connectorPoolMock.get(urlBalancedElementName)).andReturn(_soapConnectorPoolMock);
    EasyMock.expect(_soapConnectorPoolMock.borrowObject()).andReturn(_soapInstanceMock);

    EasyMock.expect(_soapInstanceMock.getClient()).andReturn(_soapInstanceMockClient);

    _soapConnectorPoolMock.returnObject(EasyMock.anyObject());
    EasyMock.expectLastCall();

    JUnitTools.setInaccessibleFieldValue(_connector, "_loadBalancer", _loadBalancerMock); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_connectorPool", _connectorPoolMock); //$NON-NLS-1$

    EasyMock.expect(_soapInstanceMockClient.getInInterceptors()).andReturn(new ArrayList<Interceptor<?>>());
    EasyMock.expect(_soapInstanceMockClient.getOutInterceptors()).andReturn(new ArrayList<Interceptor<?>>());

    EasyMock.expect(_soapInstanceMockClient.invoke(EasyMock.eq(MethodNames.GET_CUSTOMER_OPTIONS), EasyMock.eq(createGetCustomerOptions().getCustomerId()))).andThrow(new SocketTimeoutException("ERROR")); //$NON-NLS-1$

    try
    {
      PowerMock.replayAll();
      _connector.getCustomerOptions(tracabilite_p, createGetCustomerOptions());

    }
    catch (RavelException e)
    {
      PowerMock.verifyAll();

      Assert.assertEquals(ExceptionType.PFS_EXCEPTION, e.getExceptionType());
      Assert.assertEquals(ErrorCode.CNCTOR_00010, e.getErrorCode());
    }
  }

  /**
   * Cas Nominal
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public void getCustomerOptions_OK() throws Exception
  {
    Tracabilite tracabilite_p = _podam.manufacturePojoWithFullData(Tracabilite.class);
    CustomerOptionsType customerOptionsType = createCustomerOptionsType();
    Object[] responseClient = { customerOptionsType };

    loadSMVConnector(ISMVConnector.BEAN_ID_SMV_PROV);
    initializeMocksForSendRequestGetCustomerInformation();

    EasyMock.expect(_soapInstanceMockClient.invoke(EasyMock.eq(MethodNames.GET_CUSTOMER_OPTIONS), EasyMock.eq(createGetCustomerOptions().getCustomerId()))).andReturn(responseClient);

    PowerMock.replayAll();
    final ConnectorResponse<CustomerOptionsType, Nothing> result = _connector.getCustomerOptions(tracabilite_p, createGetCustomerOptions());
    PowerMock.verifyAll();

    Assert.assertEquals(customerOptionsType, result._first);
  }

  /**
   * Test the loadConnectorConfiguration, missing SMV_SERVICE_NAME parameter.
   */
  /**
   * @Test public void loadConnectorConfiguration_Test_001() { // The expected result RavelException expectedException =
   *       new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020,
   *       MessageFormat.format(ERROR_MISSING_PARAMETER, ConfigParameters.CONNECTOR_SERVICE_NAME));
   *
   *       try { _connector.loadConnectorConfiguration(createConnectorConfig(null, false, false));
   *
   *       Assert.fail(); } catch (RavelException actualException) { assertRavelException(expectedException,
   *       actualException); } }
   */

  /**
   * Test the loadConnectorConfiguration, invalid SMV_SERVICE_NAME parameter.
   */
  /*
  @Test
  public void loadConnectorConfiguration_Test_002()
  {
    // The expected result
    RavelException expectedException = new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(ERROR_INVALID_PARAMETER, ConfigParameters.CONNECTOR_SERVICE_NAME));

    try
    {
      _connector.loadConnectorConfiguration(createConnectorConfig(StringConstants.EMPTY_VALUE, false, false));

      Assert.fail();
    }
    catch (RavelException actualException)
    {
      assertRavelException(expectedException, actualException);
    }
  }
  */

  /**
   * Case when sendRequest throws a RavelException
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public void resetCodePinAchat_Exception() throws Exception
  {
    Tracabilite tracabilite_p = _podam.manufacturePojoWithFullData(Tracabilite.class);

    loadSMVConnector(ISMVConnector.BEAN_ID_SMV_PROV);

    final String urlBalancedElementName = org.apache.commons.lang3.RandomStringUtils.randomAlphanumeric(45);
    final String urlBalancedElementDescription = org.apache.commons.lang3.RandomStringUtils.randomAlphabetic(9);

    // Mock load balancer
    EasyMock.expect(_loadBalancerMock.chooseBalancedElement()).andReturn(_urlBalancedElementMock);
    EasyMock.expect(_urlBalancedElementMock.getName()).andReturn(urlBalancedElementName);
    EasyMock.expect(_urlBalancedElementMock.getDescription()).andReturn(urlBalancedElementDescription);
    EasyMock.expect(_urlBalancedElementMock.getName()).andReturn(urlBalancedElementName);
    EasyMock.expect(_connectorPoolMock.get(urlBalancedElementName)).andReturn(_soapConnectorPoolMock);
    EasyMock.expect(_soapConnectorPoolMock.borrowObject()).andReturn(_soapInstanceMock);

    EasyMock.expect(_soapInstanceMock.getClient()).andReturn(_soapInstanceMockClient);

    _soapConnectorPoolMock.returnObject(EasyMock.anyObject());
    EasyMock.expectLastCall();

    JUnitTools.setInaccessibleFieldValue(_connector, "_loadBalancer", _loadBalancerMock); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_connectorPool", _connectorPoolMock); //$NON-NLS-1$

    EasyMock.expect(_soapInstanceMockClient.getInInterceptors()).andReturn(new ArrayList<Interceptor<?>>());
    EasyMock.expect(_soapInstanceMockClient.getOutInterceptors()).andReturn(new ArrayList<Interceptor<?>>());

    ResetPurchaseCode resetPurchaseCode = new ResetPurchaseCode();
    resetPurchaseCode.setTerminalExtId("123456789"); //$NON-NLS-1$

    EasyMock.expect(_soapInstanceMockClient.invoke(EasyMock.eq(MethodNames.RESET_CODE_PIN_ACHAT), EasyMock.eq(resetPurchaseCode))).andThrow(new SocketTimeoutException("ERROR")); //$NON-NLS-1$
    try
    {
      PowerMock.replayAll();
      _connector.resetCodePinAchat(tracabilite_p, resetPurchaseCode);
    }
    catch (RavelException e)
    {
      PowerMock.verifyAll();
      Assert.assertEquals(ExceptionType.PFS_EXCEPTION, e.getExceptionType());
      Assert.assertEquals(ErrorCode.CNCTOR_00010, e.getErrorCode());
    }
  }

  /**
   * Cas Nominal
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public void resetCodePinAchat_OK() throws Exception
  {
    Tracabilite tracabilite_p = _podam.manufacturePojoWithFullData(Tracabilite.class);

    loadSMVConnector(ISMVConnector.BEAN_ID_SMV_PROV);

    final String urlBalancedElementName = org.apache.commons.lang3.RandomStringUtils.randomAlphanumeric(45);
    final String urlBalancedElementDescription = org.apache.commons.lang3.RandomStringUtils.randomAlphabetic(9);

    // Mock load balancer
    EasyMock.expect(_loadBalancerMock.chooseBalancedElement()).andReturn(_urlBalancedElementMock);
    EasyMock.expect(_urlBalancedElementMock.getName()).andReturn(urlBalancedElementName);
    EasyMock.expect(_urlBalancedElementMock.getDescription()).andReturn(urlBalancedElementDescription);
    EasyMock.expect(_urlBalancedElementMock.getName()).andReturn(urlBalancedElementName);
    EasyMock.expect(_connectorPoolMock.get(urlBalancedElementName)).andReturn(_soapConnectorPoolMock);
    EasyMock.expect(_soapConnectorPoolMock.borrowObject()).andReturn(_soapInstanceMock);

    EasyMock.expect(_soapInstanceMock.getClient()).andReturn(_soapInstanceMockClient);

    _soapConnectorPoolMock.returnObject(EasyMock.anyObject());
    EasyMock.expectLastCall();

    JUnitTools.setInaccessibleFieldValue(_connector, "_loadBalancer", _loadBalancerMock); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_connectorPool", _connectorPoolMock); //$NON-NLS-1$

    EasyMock.expect(_soapInstanceMockClient.getInInterceptors()).andReturn(new ArrayList<Interceptor<?>>());
    EasyMock.expect(_soapInstanceMockClient.getOutInterceptors()).andReturn(new ArrayList<Interceptor<?>>());

    ResetPurchaseCode resetPurchaseCode = new ResetPurchaseCode();
    resetPurchaseCode.setTerminalExtId("123456789"); //$NON-NLS-1$

    EasyMock.expect(_soapInstanceMockClient.invoke(EasyMock.eq(MethodNames.RESET_CODE_PIN_ACHAT), EasyMock.eq(resetPurchaseCode))).andReturn(null);

    PowerMock.replayAll();
    final ConnectorResponse<Nothing, Nothing> result = _connector.resetCodePinAchat(tracabilite_p, resetPurchaseCode);
    PowerMock.verifyAll();

    Assert.assertNotNull(result);
  }

  /**
   * Case when sendRequest throws a RavelException
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public void resetCodePinParental_Exception() throws Exception
  {
    Tracabilite tracabilite_p = _podam.manufacturePojoWithFullData(Tracabilite.class);

    loadSMVConnector(ISMVConnector.BEAN_ID_SMV_PROV);

    final String urlBalancedElementName = org.apache.commons.lang3.RandomStringUtils.randomAlphanumeric(45);
    final String urlBalancedElementDescription = org.apache.commons.lang3.RandomStringUtils.randomAlphabetic(9);

    // Mock load balancer
    EasyMock.expect(_loadBalancerMock.chooseBalancedElement()).andReturn(_urlBalancedElementMock);
    EasyMock.expect(_urlBalancedElementMock.getName()).andReturn(urlBalancedElementName);
    EasyMock.expect(_urlBalancedElementMock.getDescription()).andReturn(urlBalancedElementDescription);
    EasyMock.expect(_urlBalancedElementMock.getName()).andReturn(urlBalancedElementName);
    EasyMock.expect(_connectorPoolMock.get(urlBalancedElementName)).andReturn(_soapConnectorPoolMock);
    EasyMock.expect(_soapConnectorPoolMock.borrowObject()).andReturn(_soapInstanceMock);

    EasyMock.expect(_soapInstanceMock.getClient()).andReturn(_soapInstanceMockClient);

    _soapConnectorPoolMock.returnObject(EasyMock.anyObject());
    EasyMock.expectLastCall();

    JUnitTools.setInaccessibleFieldValue(_connector, "_loadBalancer", _loadBalancerMock); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_connectorPool", _connectorPoolMock); //$NON-NLS-1$

    ResetPinCode resetPinCode = new ResetPinCode();
    resetPinCode.setTerminalExtId("123456789"); //$NON-NLS-1$

    EasyMock.expect(_soapInstanceMockClient.getInInterceptors()).andReturn(new ArrayList<Interceptor<?>>());
    EasyMock.expect(_soapInstanceMockClient.getOutInterceptors()).andReturn(new ArrayList<Interceptor<?>>());

    EasyMock.expect(_soapInstanceMockClient.invoke(EasyMock.eq(MethodNames.RESET_CODE_PIN_PARENTAL), EasyMock.eq(resetPinCode))).andThrow(new SocketTimeoutException("ERROR")); //$NON-NLS-1$
    try
    {
      PowerMock.replayAll();
      _connector.resetCodePinParental(tracabilite_p, resetPinCode);
    }
    catch (RavelException e)
    {
      PowerMock.verifyAll();

      Assert.assertEquals(ExceptionType.PFS_EXCEPTION, e.getExceptionType());
      Assert.assertEquals(ErrorCode.CNCTOR_00010, e.getErrorCode());
    }
  }

  /**
   * Cas Nominal
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public void resetCodePinParental_OK() throws Exception
  {
    Tracabilite tracabilite_p = _podam.manufacturePojoWithFullData(Tracabilite.class);

    loadSMVConnector(ISMVConnector.BEAN_ID_SMV_PROV);

    final String urlBalancedElementName = org.apache.commons.lang3.RandomStringUtils.randomAlphanumeric(45);
    final String urlBalancedElementDescription = org.apache.commons.lang3.RandomStringUtils.randomAlphabetic(9);

    // Mock load balancer
    EasyMock.expect(_loadBalancerMock.chooseBalancedElement()).andReturn(_urlBalancedElementMock);
    EasyMock.expect(_urlBalancedElementMock.getName()).andReturn(urlBalancedElementName);
    EasyMock.expect(_urlBalancedElementMock.getDescription()).andReturn(urlBalancedElementDescription);
    EasyMock.expect(_urlBalancedElementMock.getName()).andReturn(urlBalancedElementName);
    EasyMock.expect(_connectorPoolMock.get(urlBalancedElementName)).andReturn(_soapConnectorPoolMock);
    EasyMock.expect(_soapConnectorPoolMock.borrowObject()).andReturn(_soapInstanceMock);

    EasyMock.expect(_soapInstanceMock.getClient()).andReturn(_soapInstanceMockClient);

    _soapConnectorPoolMock.returnObject(EasyMock.anyObject());
    EasyMock.expectLastCall();

    JUnitTools.setInaccessibleFieldValue(_connector, "_loadBalancer", _loadBalancerMock); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_connectorPool", _connectorPoolMock); //$NON-NLS-1$

    EasyMock.expect(_soapInstanceMockClient.getInInterceptors()).andReturn(new ArrayList<Interceptor<?>>());
    EasyMock.expect(_soapInstanceMockClient.getOutInterceptors()).andReturn(new ArrayList<Interceptor<?>>());

    ResetPinCode resetPinCode = new ResetPinCode();
    resetPinCode.setTerminalExtId("123456789"); //$NON-NLS-1$

    EasyMock.expect(_soapInstanceMockClient.invoke(EasyMock.eq(MethodNames.RESET_CODE_PIN_PARENTAL), EasyMock.eq(resetPinCode))).andReturn(null);

    PowerMock.replayAll();
    final ConnectorResponse<Nothing, Nothing> result = _connector.resetCodePinParental(tracabilite_p, resetPinCode);
    PowerMock.verifyAll();

    Assert.assertNotNull(result);
  }

  /**
   * Assert that the RavelExceptions are the same.
   *
   * @param expectedException_p
   *          the expected exception.
   * @param actualException_p
   *          the actual exception.
   */
  private void assertRavelException(RavelException expectedException_p, RavelException actualException_p)
  {
    Assert.assertEquals(expectedException_p.getExceptionType(), actualException_p.getExceptionType());
    Assert.assertEquals(expectedException_p.getErrorCode(), actualException_p.getErrorCode());
    Assert.assertEquals(expectedException_p.getMessage(), actualException_p.getMessage());
  }

  /**
   * Create the connector configuration.
   *
   *
   * @param serviceName_p
   *          the name of the service.
   * @param hasLogin_p
   *          True if the login should be added to the configuration.
   * @param hasPassword_p
   *          True if the password should be added to the configuration.
   *
   * @return the created config.
   */
  private Connector createConnectorConfig(final String serviceName_p, final boolean hasLogin_p, final boolean hasPassword_p)
  {
    Connector connectorConfig = new Connector();

    // Set the service name parameter
    Param serviceName = new Param();
    serviceName.setName(ConfigParameters.CONNECTOR_SERVICE_NAME);
    serviceName.setValue(serviceName_p);

    connectorConfig.getParam().add(serviceName);

    // Set the login parameter
    if (hasLogin_p)
    {
      Param login = new Param();
      login.setName(ConfigParameters.LOGIN);
      login.setValue(ConfigParametersValues.LOGIN);

      connectorConfig.getParam().add(login);
    }

    // Set the password parameter
    if (hasPassword_p)
    {
      Param password = new Param();
      password.setName(ConfigParameters.PASSWORD);
      password.setValue(ConfigParametersValues.PASSWORD);

      connectorConfig.getParam().add(password);
    }

    return connectorConfig;
  }

  /**
   * Create a GetCustomerInformationResponse.
   *
   * @return the created object.
   */
  private CustomerInformationType createCustomerInformationType()
  {
    CustomerInformationType customerInformationType = new CustomerInformationType();
    customerInformationType.setHdStatus(ResponseValues.HD_STATUS);
    customerInformationType.setZipCode(ResponseValues.ZIP_CODE);

    return customerInformationType;
  }

  /**
   * Create a CustomerOptionsType object.
   *
   * @return the created object.
   */
  private CustomerOptionsType createCustomerOptionsType()
  {
    CustomerOptionsType customerOptionsType = new CustomerOptionsType();
    customerOptionsType.setLocalization(ResponseValues.LOCALIZATION);
    customerOptionsType.setZipCode(ResponseValues.ZIP_CODE);

    return customerOptionsType;
  }

  /**
   * Create a GetCustomerInformation.
   *
   * @return the created object.
   */
  private GetCustomerInformation createGetCustomerInformation()
  {
    GetCustomerInformation getCustomerInformation = new GetCustomerInformation();
    getCustomerInformation.setCustomerId(RequestParametersValues.CUSTOMER_ID);

    return getCustomerInformation;
  }

  /**
   * Create a GetCustomerOptions.
   *
   * @return the created object.
   */
  private GetCustomerOptions createGetCustomerOptions()
  {
    GetCustomerOptions getCustomerOptions = new GetCustomerOptions();
    getCustomerOptions.setCustomerId(RequestParametersValues.CUSTOMER_ID);

    return getCustomerOptions;
  }

  /**
   * Génération du LoadBalancer minimal pour passer {@link AbstractSOAPConnector#loadConnectorConfiguration(Connector)}
   *
   * @return {@link LoadBalancer}
   */
  private LoadBalancer generateLoadBalancer()
  {
    final LoadBalancer loadBalancer = new LoadBalancer();
    Param timer = new Param();
    timer.setName("TIMER"); //$NON-NLS-1$
    timer.setValue("30"); //$NON-NLS-1$
    loadBalancer.getParam().add(timer);
    loadBalancer.setType("RoundRobin"); //$NON-NLS-1$
    return loadBalancer;
  }

  /**
   * Génération du URL minimal pour passer {@link AbstractSOAPConnector#loadConnectorConfiguration(Connector)}
   *
   * @return {@link URL}
   */
  private URL generateURL()
  {
    final URL url = new URL();
    url.setName("urlName"); //$NON-NLS-1$
    url.setAccessPoint("http://localhost:8888"); //$NON-NLS-1$

    Param param = new Param();
    param.setName("PROXY_ENABLED"); //$NON-NLS-1$
    param.setValue(String.valueOf(false));
    url.getParam().add(param);

    param = new Param();
    param.setName("TIMEOUT"); //$NON-NLS-1$
    param.setValue("30"); //$NON-NLS-1$
    url.getParam().add(param);

    param = new Param();
    param.setName("BASIC_AUTHENT"); //$NON-NLS-1$
    param.setValue(String.valueOf(false));
    url.getParam().add(param);

    param = new Param();
    param.setName("CONNECTION_TIMEOUT"); //$NON-NLS-1$
    param.setValue("30"); //$NON-NLS-1$
    url.getParam().add(param);

    param = new Param();
    param.setName("RECEIVE_TIMEOUT"); //$NON-NLS-1$
    param.setValue("30"); //$NON-NLS-1$
    url.getParam().add(param);

    return url;
  }

  /**
   * @return URLS
   */
  private URLS generateURLS()
  {
    final URLS urls = new URLS();
    urls.setLoadBalancer(generateLoadBalancer());
    urls.getURL().add(generateURL());
    return urls;
  }

  /**
   * prepare mock scenario to initialize method sendRequest from AbstractSoapConnector
   *
   * @throws Exception
   *           Thrown in case of error
   */
  private void initializeMocksForSendRequestGetCustomerInformation() throws Exception
  {
    final String urlBalancedElementName = org.apache.commons.lang3.RandomStringUtils.randomAlphanumeric(45);
    final String urlBalancedElementDescription = org.apache.commons.lang3.RandomStringUtils.randomAlphabetic(9);

    // Mock load balancer
    EasyMock.expect(_loadBalancerMock.chooseBalancedElement()).andReturn(_urlBalancedElementMock);
    EasyMock.expect(_urlBalancedElementMock.getName()).andReturn(urlBalancedElementName);
    EasyMock.expect(_urlBalancedElementMock.getDescription()).andReturn(urlBalancedElementDescription);
    EasyMock.expect(_urlBalancedElementMock.getName()).andReturn(urlBalancedElementName);
    EasyMock.expect(_connectorPoolMock.get(urlBalancedElementName)).andReturn(_soapConnectorPoolMock);
    EasyMock.expect(_soapConnectorPoolMock.borrowObject()).andReturn(_soapInstanceMock);

    EasyMock.expect(_soapInstanceMock.getClient()).andReturn(_soapInstanceMockClient);
    EasyMock.expect(_loadBalancerMock.getPingConnectionTimeout()).andReturn(0);
    EasyMock.expect(_urlBalancedElementMock.validConnection(EasyMock.anyInt())).andReturn(Element.ElementState.OK);

    _soapConnectorPoolMock.returnObject(EasyMock.anyObject());
    EasyMock.expectLastCall();

    JUnitTools.setInaccessibleFieldValue(_connector, "_loadBalancer", _loadBalancerMock); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_connectorPool", _connectorPoolMock); //$NON-NLS-1$

    EasyMock.expect(_soapInstanceMockClient.getInInterceptors()).andReturn(new ArrayList<Interceptor<?>>());
    EasyMock.expect(_soapInstanceMockClient.getOutInterceptors()).andReturn(new ArrayList<Interceptor<?>>());
  }

  /**
   * Load SMV connector configuration.
   *
   * @param connectorName_p
   *          Configuration name.
   * @throws Exception
   *           if a problem happens.
   */
  private void loadSMVConnector(String connectorName_p) throws Exception
  {
    final Connector connector = new Connector();
    connector.setName("SmvConnector"); //$NON-NLS-1$
    Param param = new Param();
    param.setName("SMV_SERVICE_NAME"); //$NON-NLS-1$
    param.setValue(connectorName_p);
    connector.getParam().add(param);
    param = new Param();
    param.setName("LOGIN"); //$NON-NLS-1$
    param.setValue(ConfigParametersValues.LOGIN);
    connector.getParam().add(param);
    param = new Param();
    param.setName("PASSWORD"); //$NON-NLS-1$
    param.setValue(ConfigParametersValues.PASSWORD);
    connector.getParam().add(param);
    connector.setURLS(generateURLS());

    PowerMock.expectNew(SoapConnectorPool.class, EasyMock.anyObject(Class.class), EasyMock.anyString(), EasyMock.anyInt(), EasyMock.anyInt(), EasyMock.anyInt(), EasyMock.anyBoolean(), EasyMock.anyString(), EasyMock.anyString(), EasyMock.anyBoolean(), EasyMock.anyString(), EasyMock.anyString(), EasyMock.anyString(), EasyMock.anyInt(), EasyMock.anyString(), EasyMock.anyObject(ValidationEventHandler.class), EasyMock.anyObject(ISoapInterceptorsFactory.class)).andReturn(_soapConnectorPoolMock);
    PowerMock.replay(SoapConnectorPool.class);

    // test
    _connector.loadConnectorConfiguration(connector);
  }
}
