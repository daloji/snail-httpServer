/*******************************************************************************
* $Id: AideCommandeAltitudeConnectorTest.java 42744 2020-10-26 13:02:33Z jbrites $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.smv;

import java.lang.reflect.Field;

import org.easymock.EasyMock;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.bytel.spirit.common.generated.ws.smv.authentication.AuthenticateUserResult;
import com.bytel.spirit.common.generated.ws.smv.authentication.AuthenticationPort;

/**
 * Test SMV Service (Authentication part used by SMV Connector).
 *
 * @author mlebihan
 * @version ($Revision: 42744 $ $Date: 2020-10-26 14:02:33 +0100 (lun. 26 oct. 2020) $)
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({ SMVAuthentService.class, SoapCaller.class })
@PowerMockIgnore({ "com.sun.*", "org.w3c.*", "javax.xml.*" })
public class SMVServiceTest
{
  /** For send(responseClass_p, msgId_p, methodName_p, request_p) method call. */
  private static String SEND = "send"; //$NON-NLS-1$

  /** Authentification service. */
  private SMVAuthentService _authentService;

  /** Soap Caller Mock. */
  @MockStrict
  private SoapCaller<AuthenticationPort> _soapCallerMock;

  /** System time in millisecond of a date in March 2005. */
  private long MARCH_2005_SYSTEMTIME = 1110625487945L;

  /** System time in millisecond of a date in March 2040. */
  private long MARCH_2040_SYSTEMTIME = 2500624354418L;

  /** The result of a successful authentication, carrying an expired token. */
  private AuthenticateUserResult authenticatedWithExpiredToken = new AuthenticateUserResult().withExpirationDate(MARCH_2005_SYSTEMTIME).withSecurityToken("SMV-Expired-Token-12348"); //$NON-NLS-1$

  /** The result of a successful authentication, carrying an active token. */
  private AuthenticateUserResult authenticatedWithActiveToken = new AuthenticateUserResult().withExpirationDate(MARCH_2040_SYSTEMTIME).withSecurityToken("SMV-Active-Token-45722"); //$NON-NLS-1$

  /** The result of a successful authentication, carrying another active token. */
  private AuthenticateUserResult authenticatedWithActiveToken2 = new AuthenticateUserResult().withExpirationDate(MARCH_2040_SYSTEMTIME).withSecurityToken("SMV-Active-Token-45728"); //$NON-NLS-1$

  /**
   * Initialize SMVAuthentService with a global SOAP destination.
   *
   * @throws Exception
   *           if field _soapCaller cannot be set with the mock.
   */
  @SuppressWarnings("unchecked") // createNicePartialMock returns a raw type of SoapCaller.
  @Before
  public void beforeTest() throws Exception
  {
    _authentService = new SMVAuthentService("soapSMVAuthentication", "http://test.no.no//", "login", "password", 10, null, null, null, 8180); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$)

    // Create a mock that :
    // 1) Invokes SoapCaller(Class<P> proxyClass_p, String name_p, String completeUrl_p, String soapVersion_p, int timeout_p, String proxyLogin_p, String proxyPassword_p, String proxyHost_p, int proxyPort_p) constructor.
    Class<?>[] constructorTypes = { Class.class, String.class, String.class, String.class, Integer.TYPE, String.class, String.class, String.class, Integer.TYPE };
    Object[] constructorArguments = { AuthenticationPort.class, "soapSMV", "http://test.no.no//", null, 10, null, null, null, 8180 }; //$NON-NLS-1$ //$NON-NLS-2$

    // 2) Mocks only send(responseClass_p, msgId_p, methodName_p, request_p) method.
    Class<?>[] getTypes = { Class.class, String.class, String.class, Object[].class };
    _soapCallerMock = PowerMock.createNicePartialMock(SoapCaller.class, SEND, getTypes, constructorArguments, constructorTypes);

    Assert.assertNotNull("SOAPCaller Mock not initialized", _soapCallerMock); //$NON-NLS-1$

    Field authentServiceRestCallerMember = _authentService.getClass().getDeclaredField("_soapCaller"); //$NON-NLS-1$
    authentServiceRestCallerMember.setAccessible(true);
    authentServiceRestCallerMember.set(_authentService, _soapCallerMock);
  }

  /**
   * OK : Test that when after a valid token is given, a clearInvalidToken() cause it to be renewed at the next call
   * even if it is not expired.
   *
   * @throws Exception
   *           if a trouble happens.
   */
  @Test
  public void testAltitudeService_OK_ClearInvalidToken() throws Exception
  {
    // First, a not expired token will be returned by the service, and then another call to to the getAccesToken()
    // is expected return another token, because where will clear the previous token.
    authenticationResponds(authenticatedWithActiveToken);
    authenticationResponds(authenticatedWithActiveToken2);

    PowerMock.replayAll();

    Assert.assertEquals("The first token expected has not been returned.", authenticatedWithActiveToken.getSecurityToken(), _authentService.getAccessToken()); //$NON-NLS-1$
    _authentService.cleanInvalidToken();
    Assert.assertEquals("The other token expected after a call to clearInvalidToken() has not been returned.", authenticatedWithActiveToken2.getSecurityToken(), _authentService.getAccessToken()); //$NON-NLS-1$

    PowerMock.verifyAll();
  }

  /**
   * OK : Test that when the current token is still active service doesn't attempt to renew it.
   *
   * @throws Exception
   *           if a trouble happens.
   */
  @Test
  public void testAltitudeService_OK_KeepValid() throws Exception
  {
    // getAccesToken() returns a token that will be valid for a long time.
    authenticationResponds(authenticatedWithActiveToken);

    PowerMock.replayAll();

    Assert.assertEquals("The valid token expected has not been returned.", authenticatedWithActiveToken.getSecurityToken(), _authentService.getAccessToken()); //$NON-NLS-1$

    try
    {
      _authentService.getAccessToken();
    }
    catch (RuntimeException e)
    {
      // Fails if a second attempt happens because the mock doesn't expected it.
      Assert.fail("Another call to the REST service has been attempted but the first token returned was still valid."); //$NON-NLS-1$
    }

    PowerMock.verifyAll();
  }

  /**
   * OK : Test that when the token is expired it is renewed.
   *
   * @throws Exception
   *           if a trouble happens.
   */
  @Test
  public void testAltitudeService_OK_RenewToken() throws Exception
  {
    // First, a token will be returned by the service. We have put a expire timestamp in the past.
    // Another call to the getAccesToken() has to return this new token.
    authenticationResponds(authenticatedWithExpiredToken);
    authenticationResponds(authenticatedWithActiveToken);

    PowerMock.replayAll();

    Assert.assertEquals("The first token expected has not been returned.", authenticatedWithExpiredToken.getSecurityToken(), _authentService.getAccessToken()); //$NON-NLS-1$
    Assert.assertEquals("The renewed token expected has not been returned.", authenticatedWithActiveToken.getSecurityToken(), _authentService.getAccessToken()); //$NON-NLS-1$

    PowerMock.verifyAll();
  }

  /**
   * OK : Test that the wished token is returned when all is Ok.
   *
   * @throws Exception
   *           if a trouble happens.
   */
  @Test
  public void testAltitudeService_OK_SingleCall() throws Exception
  {
    authenticationResponds(authenticatedWithActiveToken);
    PowerMock.replayAll();

    Assert.assertEquals("The expected token has not been returned.", authenticatedWithActiveToken.getSecurityToken(), _authentService.getAccessToken()); //$NON-NLS-1$

    PowerMock.verifyAll();
  }

  /**
   * Prepare the send call with its response and perform the replayAll.
   *
   * @param response
   *          Response expected.
   * @throws Exception
   *           if a mock problem happens.
   */
  private void authenticationResponds(Object response) throws Exception
  {
    Object[] sendArgs = new Object[] { (Class<?>) EasyMock.anyObject(), (String) EasyMock.anyObject(), (String) EasyMock.anyObject(), (Object[]) EasyMock.anyObject() };
    PowerMock.expectPrivate(_soapCallerMock, SEND, sendArgs).andReturn(response);
  }
}
