/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.padawanFTTH.oracle;

import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.connectors.padawanFTTH.oracle.structs.ConsulterNumInterventionRaccResponse;
import com.bytel.spirit.common.connectors.padawanFTTH.oracle.structs.PadawanFTTHOracleRetour;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

/**
 * @author fbarnabe
 * @version ($Revision$ $Date$)
 */
public interface IPadawanFTTHOracle
{
  /**
   * Retourner la liste des NumIntervention et la RefPrestationPrise
   *
   * @param tracabilite_p
   *          La traçabilité
   * @param codeOI_p
   *          le oi à verifier
   * @param reference_p
   *          obligatoire si numIntervention_p = null
   * @param typeReference_p
   *          obligatoire si reference_p != null
   * @return retour du connecteur
   * @throws RavelException
   *           exception
   */
  public ConnectorResponse<PadawanFTTHOracleRetour, ConsulterNumInterventionRaccResponse> consulterNumInterventionRacc(Tracabilite tracabilite_p, String codeOI_p, String reference_p, String typeReference_p) throws RavelException;

  /**
   * Get NRM Id by OSS Id
   *
   * @param tracabilite_p
   *          La traçabilité
   * @param idOss_p
   *          id oss
   * @return retour du connecteur
   * @throws RavelException
   *           exception
   */
  public ConnectorResponse<PadawanFTTHOracleRetour, Long> getNRMidByIdOSS(Tracabilite tracabilite_p, Long idOss_p) throws RavelException;

  /**
   * Recuperer IdRaccordement by OSS Id
   *
   * @param tracabilite_p
   *          La traçabilité
   * @param idOss_p
   *          id oss
   * @return retour du connecteur
   * @throws RavelException
   *           exception
   */
  public ConnectorResponse<PadawanFTTHOracleRetour, String> recupererIdRaccoparIdOss(Tracabilite tracabilite_p, Long idOss_p) throws RavelException;

  /**
   * Vérifie l’habilitation d’un OI
   *
   * @param tracabilite_p
   *          La traçabilité
   * @param codeOI_p
   *          le oi à verifier
   * @param numIntervention_p
   *          obligatoire si reference_p = null
   * @param reference_p
   *          obligatoire si numIntervention_p = null
   * @param typeReference_p
   *          obligatoire si reference_p != null
   * @return retour du connecteur
   * @throws RavelException
   *           exception
   */
  public ConnectorResponse<PadawanFTTHOracleRetour, String> verifierHabilitationOI(Tracabilite tracabilite_p, String codeOI_p, String numIntervention_p, String reference_p, String typeReference_p) throws RavelException;
}
