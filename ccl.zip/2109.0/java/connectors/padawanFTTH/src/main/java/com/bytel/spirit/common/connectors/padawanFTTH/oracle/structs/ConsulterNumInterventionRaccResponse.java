/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.padawanFTTH.oracle.structs;

import static java.util.Objects.isNull;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author msilva
 */
public class ConsulterNumInterventionRaccResponse implements Serializable
{

  /**
   * serialVersionUID
   */
  private static final long serialVersionUID = 2906189053951785174L;

  /**
   * refPrestationPrise
   */
  private String _refPrestationPrise;

  /**
   * numsIntervention
   */
  private List<String> _numsIntervention;

  /**
   * Default constructor
   */
  public ConsulterNumInterventionRaccResponse()
  {
    super();

    // Nothing to do yet
  }

  /**
   * Recopy constructor
   *
   * @param object_p
   *          Object to recopy
   */
  public ConsulterNumInterventionRaccResponse(ConsulterNumInterventionRaccResponse object_p)
  {
    super();

    _refPrestationPrise = object_p.getRefPrestationPrise();
    _numsIntervention = object_p.getNumsIntervention();
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    ConsulterNumInterventionRaccResponse other = (ConsulterNumInterventionRaccResponse) obj;
    if (_numsIntervention == null)
    {
      if (other._numsIntervention != null)
      {
        return false;
      }
    }
    else if (!_numsIntervention.equals(other._numsIntervention))
    {
      return false;
    }
    if (_refPrestationPrise == null)
    {
      if (other._refPrestationPrise != null)
      {
        return false;
      }
    }
    else if (!_refPrestationPrise.equals(other._refPrestationPrise))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the numsIntervention
   */
  public List<String> getNumsIntervention()
  {
    return isNull(_numsIntervention) ? null : new ArrayList<>(_numsIntervention);
  }

  /**
   * @return the refPrestationPrise
   */
  public String getRefPrestationPrise()
  {
    return _refPrestationPrise;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_numsIntervention == null) ? 0 : _numsIntervention.hashCode());
    result = (prime * result) + ((_refPrestationPrise == null) ? 0 : _refPrestationPrise.hashCode());
    return result;
  }

  /**
   * @param numsIntervention_p
   *          the numsIntervention to set
   */
  public void setNumsIntervention(List<String> numsIntervention_p)
  {
    _numsIntervention = isNull(numsIntervention_p) ? null : new ArrayList<>(numsIntervention_p);
  }

  /**
   * @param refPrestationPrise_p
   *          the refPrestationPrise to set
   */
  public void setRefPrestationPrise(String refPrestationPrise_p)
  {
    _refPrestationPrise = refPrestationPrise_p;
  }

  @Override
  public String toString()
  {
    return "ConsulterNumInterventionRaccResponse [refPrestationPrise=" + _refPrestationPrise + ", numsIntervention=" + _numsIntervention + "]"; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
  }
}
