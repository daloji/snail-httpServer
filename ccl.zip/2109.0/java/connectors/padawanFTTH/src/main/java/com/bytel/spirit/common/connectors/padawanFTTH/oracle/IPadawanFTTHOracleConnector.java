/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.padawanFTTH.oracle;

import com.bytel.ravel.services.connector.IConnector;

/**
 * Interface of IPadawanFTTHConnector that defines the BEAN_ID
 *
 * @author fbarnabe
 * @version ($Revision$ $Date$)
 */
public interface IPadawanFTTHOracleConnector extends IPadawanFTTHOracle, IConnector
{
  /**
   * The id to retrieve the connector.
   */
  public String BEAN_ID = "PadawanFTTHOracleConnector"; //$NON-NLS-1$
}
