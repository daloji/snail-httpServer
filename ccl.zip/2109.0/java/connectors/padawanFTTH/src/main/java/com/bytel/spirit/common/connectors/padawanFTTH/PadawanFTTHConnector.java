/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.padawanFTTH;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.conf.generated.Param;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.services.conf.connector.generated.Connector;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.generated.ws.access.ftth.*;
import com.bytel.spirit.common.generated.ws.extern.ftth.FtthExtern;
import com.bytel.spirit.common.generated.ws.extern.ftth.GetNrmIdByIdOssResponse;
import com.bytel.spirit.common.shared.misc.connectors.AbstractSpiritSOAPConnector;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

import java.text.MessageFormat;

/**
 *
 * @author jramos
 * @version ($Revision$ $Date$)
 */
public class PadawanFTTHConnector extends AbstractSpiritSOAPConnector implements IPadawanFTTHConnector
{

  /**
   * Name for PadawanFTTH service operation
   */
  private static final String PADAWANFTTH_SERVICE_PARAM = "PADAWANFTTH_SERVICE_NAME"; //$NON-NLS-1$

  /**
   * The constant for MissingConfigurationParameter
   */
  private static final String MESSAGE_MISSING_CONFIGURATION_PARAMETER = Messages.getString("PADAWANFTTHConnector.MissingParameter"); //$NON-NLS-1$

  /**
   * The constant for InvalidonfigurationParameter
   */
  private static final String MESSAGE_INVALID_CONFIGURATION_PARAMETER = Messages.getString("PADAWANFTTHConnector.InvalidParameter"); //$NON-NLS-1$

  /**
   * The constant for TechnicalExceptionMessage
   */
  private static final String MESSAGE_TECHNICAL_EXCEPTION_MESSAGE = Messages.getString("PADAWANFTTHConnector.TechnicalExceptionMessage"); //$NON-NLS-1$

  /**
   * The URI
   */
  private static final String FTTH_ACCESS_SERVICE = "FtthAccessService"; //$NON-NLS-1$

  /**
   * The URI
   */
  private static final String FTTH_EXTERN_SERVICE = "FtthExternService"; //$NON-NLS-1$

  /**
   * The method recupererInfosAcces
   */
  private static final String METHOD_RECUPERER_INFO_ACCES = "recupererInfosAcces"; //$NON-NLS-1$

  /**
   * The method getNrmIdByIdOss
   */
  private static final String METHOD_GET_NRM_ID_BY_ID_OSS = "getNrmIdByIdOss"; //$NON-NLS-1$

  /**
   * The service name to call.
   */
  private String _ftthServiceName;

  @Override
  public String getConfigParameter(String connectorID_p, String paramName_p) throws RavelException
  {
    // TODO Auto-generated method stub
    return null;
  }

  @Override
  public void loadConnectorConfiguration(Connector connector_p) throws RavelException
  {
    // Get and validate specific configuration parameters
    for (Param param : connector_p.getParam())
    {
      switch (param.getName())
      {
        case PADAWANFTTH_SERVICE_PARAM:
          _ftthServiceName = param.getValue();
          break;
        default:
          break;
      }
    }
    if (StringTools.isNullOrEmpty(_ftthServiceName))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PADAWANFTTH_SERVICE_PARAM));
    }

    switch (_ftthServiceName)
    {
      case FTTH_ACCESS_SERVICE:
        super.setServiceInterfaceClass(FtthAccess.class);
        break;
      case FTTH_EXTERN_SERVICE:
        super.setServiceInterfaceClass(FtthExtern.class);
        break;
      default:
        throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(MESSAGE_INVALID_CONFIGURATION_PARAMETER, _ftthServiceName));
    }

    super.loadConnectorConfiguration(connector_p);
  }

  @Override
  public ConnectorResponse<RecupererInfosAccesResponse, Retour> recupererInfosAccesFTTH(Tracabilite tracabilite_p, String idServiceClient_p) throws RavelException
  {
    ConnectorResponse<RecupererInfosAccesResponse, Retour> recupererInfoRetour = null;
    try
    {
      // Build request
      RecupererInfosAccesRequestType request = new RecupererInfosAccesRequestType();
      request.setIdServiceClient(idServiceClient_p);
      RecupererInfosAccesResponse reponseinfoAcces = new RecupererInfosAccesResponse();
      // Call SOAP Service
      RecupererInfosAccesType response = sendRequest(tracabilite_p, METHOD_RECUPERER_INFO_ACCES, request);
      if ((response != null) && (response.getAccuseReception() != null))
      {
        reponseinfoAcces.setRecupererInfosAcces(response);
        if (TypeAr.OK.equals(response.getAccuseReception().getTypeAr()))
        {
          recupererInfoRetour = new ConnectorResponse<>(reponseinfoAcces, RetourFactory.createOkRetour());
        }
        else
        {
          Retour retour = RetourFactory.createNOK(IMegConsts.CAT1, response.getAccuseReception().getIdRejet(), response.getAccuseReception().getLibelleRejet());
          recupererInfoRetour = new ConnectorResponse<>(reponseinfoAcces, retour);
        }
      }
    }
    catch (Exception e)
    {
      final String message = MessageFormat.format(MESSAGE_TECHNICAL_EXCEPTION_MESSAGE, _ftthServiceName, e.getMessage());
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, message));

      throw new RavelException(ExceptionType.PFS_EXCEPTION, ErrorCode.CNCTOR_00010, message, e);
    }

    return recupererInfoRetour;
  }

  @Override
  public ConnectorResponse<GetNrmIdByIdOssResponse, Retour> getNrmIdByIdOss(Tracabilite tracabilite_p, Long idOss_p) throws RavelException
  {
    try
    {
      GetNrmIdByIdOssResponse getNrmIdByIdOss = new GetNrmIdByIdOssResponse();

      // Call SOAP Service
      Long nrmId = sendRequest(tracabilite_p, METHOD_GET_NRM_ID_BY_ID_OSS, idOss_p);

      // Build response
      getNrmIdByIdOss.setReturn(nrmId);
      return new ConnectorResponse<>(getNrmIdByIdOss, RetourFactory.createOkRetour());
    }
    catch (Exception e)
    {
      final String message = MessageFormat.format(MESSAGE_TECHNICAL_EXCEPTION_MESSAGE, _ftthServiceName, e.getMessage());
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, message));

      throw new RavelException(ExceptionType.PFS_EXCEPTION, ErrorCode.CNCTOR_00010, message, e);
    }
  }
}
