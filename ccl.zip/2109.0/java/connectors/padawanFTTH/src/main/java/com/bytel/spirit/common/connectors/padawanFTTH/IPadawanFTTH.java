/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.padawanFTTH;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.generated.ws.access.ftth.RecupererInfosAccesResponse;
import com.bytel.spirit.common.generated.ws.extern.ftth.GetNrmIdByIdOssResponse;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

/**
 *
 * @author jramos
 * @version ($Revision$ $Date$)
 */
public interface IPadawanFTTH
{

  /**
   * @param tracabilite_p
   *          traca
   * @param idServiceClient_p
   *          id
   * @return Response
   * @throws RavelException
   *           exception
   */
  ConnectorResponse<RecupererInfosAccesResponse, Retour> recupererInfosAccesFTTH(final Tracabilite tracabilite_p, final String idServiceClient_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          traca
   * @param idOss_p
   *          idOss
   * @return Response
   * @throws RavelException
   *           exception
   */
  ConnectorResponse<GetNrmIdByIdOssResponse, Retour> getNrmIdByIdOss(final Tracabilite tracabilite_p, final Long idOss_p) throws RavelException;

}
