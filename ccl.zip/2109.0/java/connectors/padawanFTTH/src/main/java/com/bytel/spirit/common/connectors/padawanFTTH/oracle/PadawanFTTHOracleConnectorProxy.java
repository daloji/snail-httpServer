/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.padawanFTTH.oracle;

import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.probes.AvgDoubleCollectorItem;
import com.bytel.ravel.common.probes.AvgFlowPerSecondCollector;
import com.bytel.ravel.common.probes.RavelProbeConfigurationManager;
import com.bytel.ravel.services.connector.BaseProxy;
import com.bytel.ravel.services.connector.ConnectorExecution;
import com.bytel.ravel.services.connector.ConnectorManager;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.connectors.padawanFTTH.oracle.structs.ConsulterNumInterventionRaccResponse;
import com.bytel.spirit.common.connectors.padawanFTTH.oracle.structs.PadawanFTTHOracleRetour;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

/**
 * @author fbarnabe
 * @version ($Revision$ $Date$)
 */
public final class PadawanFTTHOracleConnectorProxy extends BaseProxy implements IPadawanFTTHOracle
{
  /**
   * Proxy name.
   */
  private static final String PROXY_NAME = "PadawanFTTHOracleProxy"; //$NON-NLS-1$

  /**
   * Proxy instance.
   */
  private static PadawanFTTHOracleConnectorProxy _instance = new PadawanFTTHOracleConnectorProxy();

  /**
   * @return The proxy instance.
   */
  public static PadawanFTTHOracleConnectorProxy getInstance()
  {
    return _instance;
  }

  /**
   * For probe to count the amount of call to the getNrmIdByIdOss operation
   */
  AvgFlowPerSecondCollector _avg_getNrmIdByIdOss_call_counter;

  /**
   * For probe to count the execution time of call to the getNrmIdByIdOss operation
   */
  AvgDoubleCollectorItem _avg_getNrmIdByIdOss_ExecTime;

  /**
   * For probe to count the amount of call to the verifierHabilitationOI operation
   */
  AvgFlowPerSecondCollector _avg_verifierHabilitationOI_call_counter;

  /**
   * For probe to count the execution time of call to the verifierHabilitationOI operation
   */
  AvgDoubleCollectorItem _avg_verifierHabilitationOI_ExecTime;

  /**
   * For probe to count the amount of call to the consulterNumInterventionRacc operation
   */
  AvgFlowPerSecondCollector _avg_consulterNumInterventionRacc_call_counter;

  /**
   * For probe to count the execution time of call to the consulterNumInterventionRacc operation
   */
  AvgDoubleCollectorItem _avg_consulterNumInterventionRacc_ExecTime;

  /**
   * For probe to count the amount of call to the recupererIdRaccoparIdOss operation
   */
  AvgFlowPerSecondCollector _avg_recupererIdRaccoparIdOss_call_counter;

  /**
   * For probe to count the execution time of call to the recupererIdRaccoparIdOss operation
   */
  AvgDoubleCollectorItem _avg_recupererIdRaccoparIdOss_ExecTime;

  /**
   * Constructor
   */
  private PadawanFTTHOracleConnectorProxy()
  {
    _avg_getNrmIdByIdOss_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_getNrmIdByIdOss_call_counter", PROXY_NAME); //$NON-NLS-1$
    _avg_getNrmIdByIdOss_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_getNrmIdByIdOss_ExecTime", PROXY_NAME); //$NON-NLS-1$
    _avg_verifierHabilitationOI_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_verifierHabilitationOI_call_counter", PROXY_NAME); //$NON-NLS-1$
    _avg_verifierHabilitationOI_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_verifierHabilitationOI_ExecTime", PROXY_NAME); //$NON-NLS-1$
    _avg_consulterNumInterventionRacc_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_consulterNumInterventionRacc_call_counter", PROXY_NAME); //$NON-NLS-1$
    _avg_consulterNumInterventionRacc_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_consulterNumInterventionRacc_ExecTime", PROXY_NAME); //$NON-NLS-1$
    _avg_recupererIdRaccoparIdOss_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_recupererIdRaccoparIdOss_call_counter", PROXY_NAME); //$NON-NLS-1$
    _avg_recupererIdRaccoparIdOss_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_recupererIdRaccoparIdOss_ExecTime", PROXY_NAME); //$NON-NLS-1$
  }

  @Override
  public ConnectorResponse<PadawanFTTHOracleRetour, ConsulterNumInterventionRaccResponse> consulterNumInterventionRacc(Tracabilite tracabilite_p, String codeOI_p, String reference_p, String typeReference_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<PadawanFTTHOracleRetour, ConsulterNumInterventionRaccResponse>>(IPadawanFTTHOracleConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<PadawanFTTHOracleRetour, ConsulterNumInterventionRaccResponse> run() throws RavelException
      {
        IPadawanFTTHOracleConnector padawanOracleConnector = (IPadawanFTTHOracleConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_consulterNumInterventionRacc_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return padawanOracleConnector.consulterNumInterventionRacc(tracabilite_p, codeOI_p, reference_p, typeReference_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_consulterNumInterventionRacc_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<PadawanFTTHOracleRetour, Long> getNRMidByIdOSS(Tracabilite tracabilite_p, Long idOss_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<PadawanFTTHOracleRetour, Long>>(IPadawanFTTHOracleConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<PadawanFTTHOracleRetour, Long> run() throws RavelException
      {
        IPadawanFTTHOracleConnector nrmOacleConnector = (IPadawanFTTHOracleConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_getNrmIdByIdOss_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return nrmOacleConnector.getNRMidByIdOSS(tracabilite_p, idOss_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_getNrmIdByIdOss_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<PadawanFTTHOracleRetour, String> recupererIdRaccoparIdOss(Tracabilite tracabilite_p, Long idOss_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<PadawanFTTHOracleRetour, String>>(IPadawanFTTHOracleConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<PadawanFTTHOracleRetour, String> run() throws RavelException
      {
        IPadawanFTTHOracleConnector padawanOracleConnector = (IPadawanFTTHOracleConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_recupererIdRaccoparIdOss_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return padawanOracleConnector.recupererIdRaccoparIdOss(tracabilite_p, idOss_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_recupererIdRaccoparIdOss_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<PadawanFTTHOracleRetour, String> verifierHabilitationOI(Tracabilite tracabilite_p, String codeOI_p, String numIntervention_p, String reference_p, String typeReference_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<PadawanFTTHOracleRetour, String>>(IPadawanFTTHOracleConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<PadawanFTTHOracleRetour, String> run() throws RavelException
      {
        IPadawanFTTHOracleConnector padawanOracleConnector = (IPadawanFTTHOracleConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_verifierHabilitationOI_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return padawanOracleConnector.verifierHabilitationOI(tracabilite_p, codeOI_p, numIntervention_p, reference_p, typeReference_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_verifierHabilitationOI_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

}
