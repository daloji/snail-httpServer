/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.padawanFTTH.oracle;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionTools;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.services.conf.connector.generated.Connector;
import com.bytel.ravel.services.connector.AbstractDBConnector;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.connectors.padawanFTTH.Messages;
import com.bytel.spirit.common.connectors.padawanFTTH.oracle.structs.ConsulterNumInterventionRaccResponse;
import com.bytel.spirit.common.connectors.padawanFTTH.oracle.structs.PadawanFTTHOracleRetour;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

import oracle.jdbc.OracleTypes;

/**
 * @author fbarnabe
 * @version ($Revision$ $Date$)
 */
public class PadawanFTTHOracleConnector extends AbstractDBConnector implements IPadawanFTTHOracleConnector
{
  /**
   * Defines all mandatory parameters read from config file.
   *
   * @author fbarnabe
   * @version ($Revision$ $Date$)
   */
  protected enum ParameterName
  {
    /**
     * The URL parameter
     */
    DB_CONNECTIONSTRING,
    /**
     * The LOGIN parameter
     */
    DB_USERNAME,
    /**
     * The PASSWORD parameter
     */
    DB_PASSWORD,
    /**
     * The POOLSIZE parameter
     */
    POOLSIZE,
    /**
     * Connect timeout in sec
     */
    CONNECT_TIMEOUT_SEC,
    /**
     * read timeout in sec
     */
    READ_TIMEOUT_SEC,
    /**
     * query timeout in sec
     */
    QUERY_TIMEOUT_SEC
  }

  /**
   * The constant for MESSAGE_MISSING_CONFIGURATION_PARAMETER
   */
  private static final String MESSAGE_MISSING_CONFIGURATION_PARAMETER = Messages.getString("PadawanFTTHOracleConnector.MissingConfigurationParameter"); //$NON-NLS-1$

  /**
   * The constant for MESSAGE_INVALID_CONFIGURATION_PARAMETER
   */
  private static final String MESSAGE_INVALID_CONFIGURATION_PARAMETER = Messages.getString("PadawanFTTHOracleConnector.InvalidConfigurationParameter"); //$NON-NLS-1$

  /**
   * The constant for MESSAGE_TECHNICAL_EXCEPTION_MESSAGE
   */
  private static final String MESSAGE_TECHNICAL_EXCEPTION_MESSAGE = Messages.getString("PadawanFTTHOracleConnector.TechnicalExceptionMessage"); //$NON-NLS-1$

  /**
   * datasource connection properties
   */
  private final static String CONNECTION_PROPERTIES = "oracle.net.CONNECT_TIMEOUT=%d;oracle.jdbc.ReadTimeout=%d"; //$NON-NLS-1$

  /**
   * The constant for PKG_SPIRIT_MODIFIER_NUMERO_SERIE_ONT
   */
  public static final String PKG_SPIRIT_GET_NRMID_BY_OSSID = "{call PKG_SPIRIT.getNRMidByIdOSS (?,?,?,?)}"; //$NON-NLS-1$

  /**
   * The constant for PKG_SPIRIT_MODIFIER_NUMERO_SERIE_ONT
   */
  public static final String PKG_SPIRIT_RECUPERER_IDRACCO_PAR_IDOSS = "{call PKG_SPIRIT.recupererIdRaccoparIdOss (?,?,?,?)}"; //$NON-NLS-1$

  /**
   * The constant for PKG_SPIRIT_MODIFIER_NUMERO_SERIE_ONT
   */
  public static final String PKG_SPIRIT_VERIFIER_HABILITATION_OI = "{call PKG_SPIRIT.verifierHabilitationOI (?,?,?,?,?,?,?)}"; //$NON-NLS-1$

  /**
   * The constant for PKG_SPIRIT_MODIFIER_NUMERO_SERIE_ONT
   */
  public static final String PKG_SPIRIT_CONSULTER_NUM_INTERVENTION_RACC = "{call PKG_SPIRIT.consulterNumInterventionRacc (?,?,?,?,?,?,?)}"; //$NON-NLS-1$

  /**
   * Parameters read from configuration.
   */
  private Map<ParameterName, String> _parameters = new HashMap<>(0);

  /**
   * Connect timeout in seconds
   */
  private int _connectTimeoutMilliSec;

  /**
   * Read timeout in seconds
   */
  private int _readTimeoutSec;

  /**
   * Query timeout in seconds
   */
  private int _queryTimeoutSec;

  /**
   * Retourner la liste des NumIntervention et la RefPrestationPrise
   *
   * @param tracabilite_p
   *          La traçabilité
   * @param codeOI_p
   *          le oi à verifier
   * @param reference_p
   *          obligatoire si numIntervention_p = null
   * @param typeReference_p
   *          obligatoire si reference_p != null
   * @return retour du connecteur
   * @throws RavelException
   *           exception
   */
  @Override
  public ConnectorResponse<PadawanFTTHOracleRetour, ConsulterNumInterventionRaccResponse> consulterNumInterventionRacc(Tracabilite tracabilite_p, String codeOI_p, String reference_p, String typeReference_p) throws RavelException
  {
    // lock
    _dsReadLock.lock();

    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall(PKG_SPIRIT_CONSULTER_NUM_INTERVENTION_RACC))
    {
      // Set timeout
      cs.setQueryTimeout(_queryTimeoutSec);

      // Input parameters
      cs.setString(1, codeOI_p);
      cs.setString(2, reference_p);
      cs.setString(3, typeReference_p);

      // Output parameters
      cs.registerOutParameter(4, Types.VARCHAR); //refPrestationPrise
      cs.registerOutParameter(5, OracleTypes.CURSOR); //numsIntervention
      cs.registerOutParameter(6, Types.INTEGER); //codeRetour
      cs.registerOutParameter(7, Types.VARCHAR); //libelle

      // Execute the stored procedure
      cs.execute();

      // Get output parameters
      String refPrestationPrise = cs.getString(4);
      if (cs.wasNull())
      {
        refPrestationPrise = null;
      }

      Integer codeRetour = cs.getInt(6);
      if (cs.wasNull())
      {
        codeRetour = null;
      }

      String libelleErreur = cs.getString(7);

      List<String> numIntervention = null;

      ResultSet rs = (ResultSet) cs.getObject(5);

      if (rs != null)
      {
        numIntervention = new ArrayList<>();

        while (rs.next())
        {
          numIntervention.add(rs.getString(1));
        }
      }

      ConsulterNumInterventionRaccResponse response = new ConsulterNumInterventionRaccResponse();
      response.setRefPrestationPrise(refPrestationPrise);
      response.setNumsIntervention(numIntervention);

      return new ConnectorResponse<>(new PadawanFTTHOracleRetour(codeRetour, libelleErreur), response);

    }
    catch (SQLException exception)
    {
      throw buildTechnicalException(exception, tracabilite_p, "consulterNumInterventionRacc"); //$NON-NLS-1$
    }
    finally
    {
      // unlock
      _dsReadLock.unlock();
    }
  }

  /**
   * Get NRM Id by OSS Id
   *
   * @param tracabilite_p
   *          La traçabilité
   * @param idOss_p
   *          id oss
   * @return retour du connecteur
   * @throws RavelException
   *           exception
   */
  @Override
  public ConnectorResponse<PadawanFTTHOracleRetour, Long> getNRMidByIdOSS(Tracabilite tracabilite_p, Long idOss_p) throws RavelException
  {
    // lock
    _dsReadLock.lock();

    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall(PKG_SPIRIT_GET_NRMID_BY_OSSID))
    {
      // Set timeout
      cs.setQueryTimeout(_queryTimeoutSec);

      // Input parameters
      cs.setLong(1, idOss_p);

      // Output parameters
      cs.registerOutParameter(2, Types.BIGINT); //nrmId
      cs.registerOutParameter(3, Types.INTEGER); //codeRetour
      cs.registerOutParameter(4, Types.VARCHAR); //libelle

      // Execute the stored procedure
      cs.execute();

      // Get output parameters

      Long nrmId = cs.getLong(2);
      if (cs.wasNull())
      {
        nrmId = null;
      }
      Integer codeRetour = cs.getInt(3);
      if (cs.wasNull())
      {
        codeRetour = null;
      }
      String libelleErreur = cs.getString(4);

      return new ConnectorResponse<>(new PadawanFTTHOracleRetour(codeRetour, libelleErreur), nrmId);
    }
    catch (SQLException exception)
    {
      throw buildTechnicalException(exception, tracabilite_p, "getNRMidByIdOSS"); //$NON-NLS-1$
    }
    finally
    {
      // unlock
      _dsReadLock.unlock();
    }
  }

  @Override
  public void loadConnectorConfiguration(Connector connector_p) throws RavelException
  {
    // Read parameters.
    _name = connector_p.getName();
    _enabled = connector_p.isEnabled();

    // Get parameters
    connector_p.getParam().forEach(p -> _parameters.put(ParameterName.valueOf(p.getName().toUpperCase()), p.getValue()));

    // Check parameters

    // Get DB_CONNECTIONSTRING
    String connectionString = _parameters.get(ParameterName.DB_CONNECTIONSTRING);
    if (StringTools.isNullOrEmpty(connectionString))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, _name, ParameterName.DB_CONNECTIONSTRING.toString()));
    }

    // Get DB_USERNAME
    String dbUserName = _parameters.get(ParameterName.DB_USERNAME);
    if (StringTools.isNullOrEmpty(dbUserName))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, _name, ParameterName.DB_USERNAME.toString()));
    }

    // Get DB_PASSWORD
    String dbPassword = _parameters.get(ParameterName.DB_PASSWORD);
    if (StringTools.isNullOrEmpty(dbPassword))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, _name, ParameterName.DB_PASSWORD.toString()));
    }

    // Get POOLSIZE
    String poolSize = _parameters.get(ParameterName.POOLSIZE);

    // Get CONNECT_TIMEOUT_SEC
    String connectTimeoutSec = _parameters.get(ParameterName.CONNECT_TIMEOUT_SEC);
    if (StringTools.isNullOrEmpty(connectTimeoutSec))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, _name, ParameterName.CONNECT_TIMEOUT_SEC.toString()));
    }
    try
    {
      _connectTimeoutMilliSec = Integer.parseInt(connectTimeoutSec) * 1000;
    }
    catch (NumberFormatException e)
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00021, MessageFormat.format(MESSAGE_INVALID_CONFIGURATION_PARAMETER, _name, ParameterName.CONNECT_TIMEOUT_SEC.toString()));
    }

    // Get READ_TIMEOUT_SEC
    String readTimeoutSec = _parameters.get(ParameterName.READ_TIMEOUT_SEC);
    if (StringTools.isNullOrEmpty(readTimeoutSec))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, _name, ParameterName.READ_TIMEOUT_SEC.toString()));
    }
    try
    {
      _readTimeoutSec = Integer.parseInt(readTimeoutSec) * 1000;
    }
    catch (NumberFormatException e)
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00021, MessageFormat.format(MESSAGE_INVALID_CONFIGURATION_PARAMETER, _name, ParameterName.READ_TIMEOUT_SEC.toString()));
    }

    // Get QUERY_TIMEOUT_SEC
    String queryTimeoutSec = _parameters.get(ParameterName.QUERY_TIMEOUT_SEC);
    if (StringTools.isNullOrEmpty(queryTimeoutSec))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, _name, ParameterName.QUERY_TIMEOUT_SEC.toString()));
    }
    try
    {
      _queryTimeoutSec = Integer.parseInt(queryTimeoutSec) * 1000;
    }
    catch (NumberFormatException e)
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00021, MessageFormat.format(MESSAGE_INVALID_CONFIGURATION_PARAMETER, _name, ParameterName.QUERY_TIMEOUT_SEC.toString()));
    }

    // Create data source
    createDataSource(connectionString, dbUserName, dbPassword, poolSize, DatabaseType.ORACLE);
    _datasource.setConnectionProperties(String.format(CONNECTION_PROPERTIES, _connectTimeoutMilliSec, _readTimeoutSec));

  }

  @Override
  public ConnectorResponse<PadawanFTTHOracleRetour, String> recupererIdRaccoparIdOss(Tracabilite tracabilite_p, Long idOss_p) throws RavelException
  {
    // lock
    _dsReadLock.lock();

    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall(PKG_SPIRIT_RECUPERER_IDRACCO_PAR_IDOSS))
    {
      // Set timeout
      cs.setQueryTimeout(_queryTimeoutSec);

      // Input parameters
      cs.setLong(1, idOss_p);

      // Output parameters
      cs.registerOutParameter(2, Types.VARCHAR); //idRaccordement
      cs.registerOutParameter(3, Types.INTEGER); //codeRetour
      cs.registerOutParameter(4, Types.VARCHAR); //libelle

      // Execute the stored procedure
      cs.execute();

      // Get output parameters
      String idRaccordement = cs.getString(2);
      if (cs.wasNull())
      {
        idRaccordement = null;
      }

      Integer codeRetour = cs.getInt(3);
      if (cs.wasNull())
      {
        codeRetour = null;
      }

      String libelleErreur = cs.getString(4);

      return new ConnectorResponse<>(new PadawanFTTHOracleRetour(codeRetour, libelleErreur), idRaccordement);
    }
    catch (SQLException exception)
    {
      throw buildTechnicalException(exception, tracabilite_p, "recupererIdRaccoparIdOss"); //$NON-NLS-1$
    }
    finally
    {
      // unlock
      _dsReadLock.unlock();
    }
  }

  /**
   * Vérifie l’habilitation d’un OI
   *
   * @param tracabilite_p
   *          La traçabilité
   * @param codeOI_p
   *          le oi à verifier
   * @param numIntervention_p
   *          obligatoire si reference_p = null
   * @param reference_p
   *          obligatoire si numIntervention_p = null
   * @param typeReference_p
   *          obligatoire si reference_p != null
   * @return retour du connecteur
   * @throws RavelException
   *           exception
   */
  @Override
  public ConnectorResponse<PadawanFTTHOracleRetour, String> verifierHabilitationOI(Tracabilite tracabilite_p, String codeOI_p, String numIntervention_p, String reference_p, String typeReference_p) throws RavelException
  {
    // lock
    _dsReadLock.lock();

    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall(PKG_SPIRIT_VERIFIER_HABILITATION_OI))
    {
      // Set timeout
      cs.setQueryTimeout(_queryTimeoutSec);

      // Input parameters
      cs.setString(1, codeOI_p);
      cs.setString(2, numIntervention_p);
      cs.setString(3, reference_p);
      cs.setString(4, typeReference_p);

      // Output parameters
      cs.registerOutParameter(5, Types.VARCHAR); //statutHabilitation
      cs.registerOutParameter(6, Types.INTEGER); //codeRetour
      cs.registerOutParameter(7, Types.VARCHAR); //libelle

      // Execute the stored procedure
      cs.execute();

      // Get output parameters

      String statutHabilitation = cs.getString(5);
      if (cs.wasNull())
      {
        statutHabilitation = null;
      }

      Integer codeRetour = cs.getInt(6);
      if (cs.wasNull())
      {
        codeRetour = null;
      }

      String libelleErreur = cs.getString(7);

      return new ConnectorResponse<>(new PadawanFTTHOracleRetour(codeRetour, libelleErreur), statutHabilitation);
    }
    catch (SQLException exception)
    {
      throw buildTechnicalException(exception, tracabilite_p, "verifierHabilitationOI"); //$NON-NLS-1$
    }
    finally
    {
      // unlock
      _dsReadLock.unlock();
    }
  }

  /**
   * Build a log entry and throws an {@link RavelException} for a technical problem.
   *
   * @param exc_p
   *          The {@link Exception} raised
   * @param tracabilite_p
   *          The traçabilite
   * @param method_p
   *          The method name in which the fault was raised.
   * @return RavelException The technical exception.
   */
  private RavelException buildTechnicalException(Exception exc_p, Tracabilite tracabilite_p, String method_p)
  {
    String message = MessageFormat.format(MESSAGE_TECHNICAL_EXCEPTION_MESSAGE, method_p, exc_p.getClass().getSimpleName(), exc_p.getMessage());
    // add fileName and line number of the exception
    message += ExceptionTools.getExceptionLineAndFile(exc_p);
    RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, message));
    return new RavelException(ExceptionType.DATABASE_ERROR, ErrorCode.CNCTOR_00010, message, IPadawanFTTHOracleConnector.BEAN_ID, exc_p);
  }
}
