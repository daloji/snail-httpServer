/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.padawanFTTH;

import com.bytel.ravel.services.connector.IConnector;

/**
 *
 * @author jramos
 * @version ($Revision$ $Date$)
 */
public interface IPadawanFTTHConnector extends IConnector, IPadawanFTTH
{
  /**
   * The id to retrieve the connector.
   */
  public static final String BEAN_ID_PADAWANFTTH_FTTH_ACCESS = "FtthAccessPadawanFTTHConnector"; //$NON-NLS-1$

  /**
   * The id to retrieve the connector.
   */
  public static final String BEAN_ID_PADAWANFTTH_FTTH_EXTERN = "FtthExternPadawanFTTHConnector"; //$NON-NLS-1$

}
