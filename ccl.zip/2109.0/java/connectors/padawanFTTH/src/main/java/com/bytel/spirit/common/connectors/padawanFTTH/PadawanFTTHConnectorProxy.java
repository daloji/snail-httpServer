/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.padawanFTTH;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.probes.AvgDoubleCollectorItem;
import com.bytel.ravel.common.probes.AvgFlowPerSecondCollector;
import com.bytel.ravel.common.probes.RavelProbeConfigurationManager;
import com.bytel.ravel.services.connector.BaseProxy;
import com.bytel.ravel.services.connector.ConnectorExecution;
import com.bytel.ravel.services.connector.ConnectorManager;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.generated.ws.access.ftth.RecupererInfosAccesResponse;
import com.bytel.spirit.common.generated.ws.extern.ftth.GetNrmIdByIdOssResponse;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

/**
 *
 * @author jramos
 * @version ($Revision$ $Date$)
 */
public class PadawanFTTHConnectorProxy extends BaseProxy implements IPadawanFTTH
{
  /**
   * NRMInfoConnectorProxy _instance
   */
  private static final PadawanFTTHConnectorProxy _instance = new PadawanFTTHConnectorProxy();

  /**
   * @return getInstance()
   */
  public static PadawanFTTHConnectorProxy getInstance()
  {
    return _instance;
  }

  /**
   * Probe: measure the average number of recupererInfosAccesFTTH call per second.
   */
  AvgFlowPerSecondCollector _avg_ftth_recupererInfosAccesFTTH_call_counter;

  /**
   * Probe: measure the average execution time of the recupererInfosAccesFTTH operation.
   */
  AvgDoubleCollectorItem _avg_ftth_recupererInfosAccesFTTH_ExecTime;

  /**
   * Probe: measure the average number of getNrmIdByIdOss call per second.
   */
  AvgFlowPerSecondCollector _avg_ftth_getNrmIdByIdOss_call_counter;

  /**
   * Probe: measure the average execution time of the getNrmIdByIdOss operation.
   */
  AvgDoubleCollectorItem _avg_ftth_getNrmIdByIdOss_ExecTime;

  /**
   *
   */
  public PadawanFTTHConnectorProxy()
  {
    _avg_ftth_recupererInfosAccesFTTH_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_ftth_getTechnicalInfo_per_second", "FtthAccessPadawanFTTHConnector"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_ftth_recupererInfosAccesFTTH_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_ftth_getTechnicalInfo_ExecTime", "FtthAccessPadawanFTTHConnector"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_ftth_getNrmIdByIdOss_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_ftth_verifyOfferCodeAndSlotTypeCompatibility_per_second", "FtthExternPadawanFTTHConnector"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_ftth_getNrmIdByIdOss_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_ftth_verifyOfferCodeAndSlotTypeCompatibility_ExecTime", "FtthExternPadawanFTTHConnector"); //$NON-NLS-1$ //$NON-NLS-2$
  }

  @Override
  public ConnectorResponse<RecupererInfosAccesResponse, Retour> recupererInfosAccesFTTH(final Tracabilite tracabilite_p, final String idServiceClient_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<RecupererInfosAccesResponse, Retour>>(IPadawanFTTHConnector.BEAN_ID_PADAWANFTTH_FTTH_ACCESS)
    {

      @Override
      public ConnectorResponse<RecupererInfosAccesResponse, Retour> run() throws RavelException
      {
        PadawanFTTHConnector ftthConnector = (PadawanFTTHConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_ftth_recupererInfosAccesFTTH_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return ftthConnector.recupererInfosAccesFTTH(tracabilite_p, idServiceClient_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_ftth_recupererInfosAccesFTTH_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<GetNrmIdByIdOssResponse, Retour> getNrmIdByIdOss(Tracabilite tracabilite_p, Long idOss_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<GetNrmIdByIdOssResponse, Retour>>(IPadawanFTTHConnector.BEAN_ID_PADAWANFTTH_FTTH_EXTERN)
    {

      @Override
      public ConnectorResponse<GetNrmIdByIdOssResponse, Retour> run() throws RavelException
      {
        PadawanFTTHConnector ftthConnector = (PadawanFTTHConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_ftth_getNrmIdByIdOss_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return ftthConnector.getNrmIdByIdOss(tracabilite_p, idOss_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_ftth_getNrmIdByIdOss_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }
}
