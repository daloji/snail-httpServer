/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.padawanFTTH.oracle;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.concurrent.locks.Lock;

import org.apache.tomcat.jdbc.pool.DataSource;
import org.easymock.EasyMock;
import org.easymock.EasyMockSupport;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.test.JUnitTools;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.connectors.padawanFTTH.oracle.structs.ConsulterNumInterventionRaccResponse;
import com.bytel.spirit.common.connectors.padawanFTTH.oracle.structs.PadawanFTTHOracleRetour;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

import oracle.jdbc.OracleTypes;

/**
 *
 * @author msilva
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({ PadawanFTTHOracleConnector.class, Lock.class, DataSource.class, Connection.class, CallableStatement.class, ResultSet.class })
public class PadawanFTTHOracleConnectorTest extends EasyMockSupport
{

  /**
   * Tracabilite
   */
  private Tracabilite _tracabilite;

  /**
   * Connector to test
   */
  private PadawanFTTHOracleConnector _connector;

  /**
   * Mock de {@link Lock}
   */
  @MockStrict
  private Lock _dsReadLockMock;

  /**
   * Mock de {@link DataSource}
   */
  @MockStrict
  private DataSource _dataSourceMock;

  /**
   * Mock de {@link Connection}
   */
  @MockStrict
  private Connection _connectionMock;

  /**
   * Mock de {@link ResultSet}
   */
  @MockStrict
  private ResultSet _resultSetMock;

  /**
   * Mock de {@link CallableStatement}
   */
  @MockStrict
  private CallableStatement _callableStatementMock;

  /**
   * Initialize before tests
   *
   * @throws Exception
   *           Thrown in case of error during switch in attributes of parent class
   */
  @Before
  public void beforeTest() throws Exception
  {

    _connector = new PadawanFTTHOracleConnector();
    _tracabilite = new Tracabilite();

    PowerMock.resetAll();
    PowerMock.mockStaticStrict(Lock.class);
    PowerMock.mockStaticStrict(DataSource.class);
    PowerMock.mockStaticStrict(Connection.class);
    PowerMock.mockStaticStrict(CallableStatement.class);
    PowerMock.mockStaticStrict(ResultSet.class);

    JUnitTools.setInaccessibleFieldValue(_connector, "_dsReadLock", _dsReadLockMock); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_datasource", _dataSourceMock); //$NON-NLS-1$

  }

  /**
   * Nominal OK
   *
   * @throws SQLException
   *           if error
   * @throws RavelException
   *           if error
   */
  @Test
  public void PadawanFTTHOracleConnector_consulterNumInterventionRacc_001() throws SQLException, RavelException
  {
    String codeOI = "codeOI"; //$NON-NLS-1$
    String reference = "reference"; //$NON-NLS-1$
    String typeReference = "typeReference"; //$NON-NLS-1$

    _dsReadLockMock.lock();
    EasyMock.expect(_dataSourceMock.getConnection()).andReturn(_connectionMock);
    EasyMock.expect(_connectionMock.prepareCall(PadawanFTTHOracleConnector.PKG_SPIRIT_CONSULTER_NUM_INTERVENTION_RACC)).andReturn(_callableStatementMock);
    _callableStatementMock.setQueryTimeout(EasyMock.anyInt());
    _callableStatementMock.setString(1, codeOI);
    _callableStatementMock.setString(2, reference);
    _callableStatementMock.setString(3, typeReference);
    _callableStatementMock.registerOutParameter(4, Types.VARCHAR);
    _callableStatementMock.registerOutParameter(5, OracleTypes.CURSOR);
    _callableStatementMock.registerOutParameter(6, Types.INTEGER);
    _callableStatementMock.registerOutParameter(7, Types.VARCHAR);
    EasyMock.expect(_callableStatementMock.execute()).andReturn(true);
    EasyMock.expect(_callableStatementMock.getString(4)).andReturn("refPrestationPrise"); //$NON-NLS-1$
    EasyMock.expect(_callableStatementMock.wasNull()).andReturn(false);
    EasyMock.expect(_callableStatementMock.getInt(6)).andReturn(1);
    EasyMock.expect(_callableStatementMock.wasNull()).andReturn(false);
    EasyMock.expect(_callableStatementMock.getString(7)).andReturn(null);
    EasyMock.expect(_callableStatementMock.getObject(5)).andReturn(_resultSetMock);

    EasyMock.expect(_resultSetMock.next()).andReturn(true).once();
    EasyMock.expect(_resultSetMock.getString(1)).andReturn("numsIntervention1").once(); //$NON-NLS-1$
    EasyMock.expect(_resultSetMock.next()).andReturn(true).once();
    EasyMock.expect(_resultSetMock.getString(1)).andReturn("numsIntervention2").once(); //$NON-NLS-1$
    EasyMock.expect(_resultSetMock.next()).andReturn(false).once();

    _callableStatementMock.close();
    _connectionMock.close();
    _dsReadLockMock.unlock();

    PowerMock.replayAll();
    ConnectorResponse<PadawanFTTHOracleRetour, ConsulterNumInterventionRaccResponse> connectorResponse = _connector.consulterNumInterventionRacc(_tracabilite, codeOI, reference, typeReference);
    PowerMock.verifyAll();

    Assert.assertEquals(new Integer(1), connectorResponse._first.getCodeRetour());
    Assert.assertNull(connectorResponse._first.getLibelleErreur());
    Assert.assertNotNull(connectorResponse._second);
    Assert.assertEquals("refPrestationPrise", connectorResponse._second.getRefPrestationPrise()); //$NON-NLS-1$
    Assert.assertEquals(2, connectorResponse._second.getNumsIntervention().size());
    Assert.assertEquals("numsIntervention1", connectorResponse._second.getNumsIntervention().get(0)); //$NON-NLS-1$
    Assert.assertEquals("numsIntervention2", connectorResponse._second.getNumsIntervention().get(1)); //$NON-NLS-1$

  }

  /**
   * SQLException
   *
   * @throws SQLException
   *           if error
   * @throws RavelException
   *           if error
   */
  @Test
  public void PadawanFTTHOracleConnector_consulterNumInterventionRacc_002() throws SQLException, RavelException
  {
    String codeOI = "codeOI"; //$NON-NLS-1$
    String reference = "reference"; //$NON-NLS-1$
    String typeReference = "typeReference"; //$NON-NLS-1$

    SQLException exception = new SQLException("ORA-XYZ"); //$NON-NLS-1$

    _dsReadLockMock.lock();
    EasyMock.expect(_dataSourceMock.getConnection()).andReturn(_connectionMock);
    EasyMock.expect(_connectionMock.prepareCall(PadawanFTTHOracleConnector.PKG_SPIRIT_CONSULTER_NUM_INTERVENTION_RACC)).andReturn(_callableStatementMock);
    _callableStatementMock.setQueryTimeout(EasyMock.anyInt());
    _callableStatementMock.setString(1, codeOI);
    _callableStatementMock.setString(2, reference);
    _callableStatementMock.setString(3, typeReference);
    _callableStatementMock.registerOutParameter(4, Types.VARCHAR);
    _callableStatementMock.registerOutParameter(5, OracleTypes.CURSOR);
    _callableStatementMock.registerOutParameter(6, Types.INTEGER);
    _callableStatementMock.registerOutParameter(7, Types.VARCHAR);
    EasyMock.expect(_callableStatementMock.execute()).andThrow(exception);
    _dsReadLockMock.unlock();

    PowerMock.replayAll();
    try
    {
      _connector.consulterNumInterventionRacc(_tracabilite, codeOI, reference, typeReference);
      Assert.fail("Should throw exception"); //$NON-NLS-1$
    }
    catch (RavelException ex)
    {
      PowerMock.verifyAll();
      String message = "Technical Exception in PadawanFTTHOracleConnector during consulterNumInterventionRacc call: type(SQLException) reason(ORA-XYZ)"; //$NON-NLS-1$
      RavelException excpected = new RavelException(ExceptionType.DATABASE_ERROR, ErrorCode.CNCTOR_00010, message, IPadawanFTTHOracleConnector.BEAN_ID, exception);
      Assert.assertEquals(excpected, ex);
    }

  }

  /**
   * Test case recupererIdRaccoparIdOss throws exception
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public void PadawanFTTHOracleConnector_recupererIdRaccoparIdOss_001() throws Exception
  {
    long ossId = 12345;

    SQLException exception = new SQLException("ORA-XYZ"); //$NON-NLS-1$

    _dsReadLockMock.lock();
    EasyMock.expect(_dataSourceMock.getConnection()).andReturn(_connectionMock);
    EasyMock.expect(_connectionMock.prepareCall(PadawanFTTHOracleConnector.PKG_SPIRIT_RECUPERER_IDRACCO_PAR_IDOSS)).andReturn(_callableStatementMock);
    _callableStatementMock.setQueryTimeout(EasyMock.anyInt());
    _callableStatementMock.setLong(1, ossId);
    _callableStatementMock.registerOutParameter(2, Types.VARCHAR);
    _callableStatementMock.registerOutParameter(3, Types.INTEGER);
    _callableStatementMock.registerOutParameter(4, Types.VARCHAR);
    EasyMock.expect(_callableStatementMock.execute()).andThrow(exception);
    _dsReadLockMock.unlock();

    try
    {
      PowerMock.replayAll();
      _connector.recupererIdRaccoparIdOss(_tracabilite, ossId);
      Assert.fail("Should throw exception"); //$NON-NLS-1$
      PowerMock.verifyAll();
    }
    catch (RavelException ex)
    {
      String message = "Technical Exception in PadawanFTTHOracleConnector during recupererIdRaccoparIdOss call: type(SQLException) reason(ORA-XYZ)"; //$NON-NLS-1$
      RavelException excpected = new RavelException(ExceptionType.DATABASE_ERROR, ErrorCode.CNCTOR_00010, message, IPadawanFTTHOracleConnector.BEAN_ID, exception);
      Assert.assertEquals(excpected, ex);
    }

  }

  /**
   * Nominal test for recupererIdRaccoparIdOss
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public void PadawanFTTHOracleConnector_recupererIdRaccoparIdOss_002() throws Exception
  {
    long ossId = 12345;

    _dsReadLockMock.lock();
    EasyMock.expect(_dataSourceMock.getConnection()).andReturn(_connectionMock);
    EasyMock.expect(_connectionMock.prepareCall(PadawanFTTHOracleConnector.PKG_SPIRIT_RECUPERER_IDRACCO_PAR_IDOSS)).andReturn(_callableStatementMock);
    _callableStatementMock.setQueryTimeout(EasyMock.anyInt());
    _callableStatementMock.setLong(1, ossId);
    _callableStatementMock.registerOutParameter(2, Types.VARCHAR);
    _callableStatementMock.registerOutParameter(3, Types.INTEGER);
    _callableStatementMock.registerOutParameter(4, Types.VARCHAR);
    EasyMock.expect(_callableStatementMock.execute()).andReturn(true);
    EasyMock.expect(_callableStatementMock.getString(2)).andReturn("idRaccordement"); //$NON-NLS-1$
    EasyMock.expect(_callableStatementMock.wasNull()).andReturn(false);
    EasyMock.expect(_callableStatementMock.getInt(3)).andReturn(1);
    EasyMock.expect(_callableStatementMock.wasNull()).andReturn(false);
    EasyMock.expect(_callableStatementMock.getString(4)).andReturn(StringConstants.OK);
    _callableStatementMock.close();
    _connectionMock.close();
    _dsReadLockMock.unlock();

    PowerMock.replayAll();
    ConnectorResponse<PadawanFTTHOracleRetour, String> response = _connector.recupererIdRaccoparIdOss(new Tracabilite(), ossId);
    PowerMock.verifyAll();

    Assert.assertEquals(new Integer(1), response._first.getCodeRetour());
    Assert.assertEquals(StringConstants.OK, response._first.getLibelleErreur());
    Assert.assertEquals("idRaccordement", response._second); //$NON-NLS-1$
  }

  /**
   * Nominal OK
   *
   * @throws SQLException
   *           if error
   * @throws RavelException
   *           if error
   */
  @Test
  public void PadawanFTTHOracleConnector_verifierHabilitationOI_001() throws SQLException, RavelException
  {
    String codeOI = "codeOI"; //$NON-NLS-1$
    String numIntervention = "numIntervention"; //$NON-NLS-1$
    String reference = "reference"; //$NON-NLS-1$
    String typeReference = "typeReference"; //$NON-NLS-1$

    _dsReadLockMock.lock();
    EasyMock.expect(_dataSourceMock.getConnection()).andReturn(_connectionMock);
    EasyMock.expect(_connectionMock.prepareCall(PadawanFTTHOracleConnector.PKG_SPIRIT_VERIFIER_HABILITATION_OI)).andReturn(_callableStatementMock);
    _callableStatementMock.setQueryTimeout(EasyMock.anyInt());
    _callableStatementMock.setString(1, codeOI);
    _callableStatementMock.setString(2, numIntervention);
    _callableStatementMock.setString(3, reference);
    _callableStatementMock.setString(4, typeReference);
    _callableStatementMock.registerOutParameter(5, Types.VARCHAR);
    _callableStatementMock.registerOutParameter(6, Types.INTEGER);
    _callableStatementMock.registerOutParameter(7, Types.VARCHAR);
    EasyMock.expect(_callableStatementMock.execute()).andReturn(true);
    EasyMock.expect(_callableStatementMock.getString(5)).andReturn("statutHabilitation"); //$NON-NLS-1$
    EasyMock.expect(_callableStatementMock.wasNull()).andReturn(false);
    EasyMock.expect(_callableStatementMock.getInt(6)).andReturn(1);
    EasyMock.expect(_callableStatementMock.wasNull()).andReturn(false);
    EasyMock.expect(_callableStatementMock.getString(7)).andReturn(null);
    _callableStatementMock.close();
    _connectionMock.close();
    _dsReadLockMock.unlock();

    PowerMock.replayAll();
    ConnectorResponse<PadawanFTTHOracleRetour, String> connectorResponse = _connector.verifierHabilitationOI(_tracabilite, codeOI, numIntervention, reference, typeReference);
    PowerMock.verifyAll();

    Assert.assertEquals(new Integer(1), connectorResponse._first.getCodeRetour());
    Assert.assertNull(connectorResponse._first.getLibelleErreur());
    Assert.assertEquals("statutHabilitation", connectorResponse._second); //$NON-NLS-1$

  }

  /**
   * SQLException
   *
   * @throws SQLException
   *           if error
   */
  @Test
  public void PadawanFTTHOracleConnector_verifierHabilitationOI_002() throws SQLException
  {
    String codeOI = "codeOI"; //$NON-NLS-1$
    String numIntervention = "numIntervention"; //$NON-NLS-1$
    String reference = "reference"; //$NON-NLS-1$
    String typeReference = "typeReference"; //$NON-NLS-1$

    SQLException exception = new SQLException("ORA-XYZ"); //$NON-NLS-1$

    _dsReadLockMock.lock();
    EasyMock.expect(_dataSourceMock.getConnection()).andReturn(_connectionMock);
    EasyMock.expect(_connectionMock.prepareCall(PadawanFTTHOracleConnector.PKG_SPIRIT_VERIFIER_HABILITATION_OI)).andReturn(_callableStatementMock);
    _callableStatementMock.setQueryTimeout(EasyMock.anyInt());
    _callableStatementMock.setString(1, codeOI);
    _callableStatementMock.setString(2, numIntervention);
    _callableStatementMock.setString(3, reference);
    _callableStatementMock.setString(4, typeReference);
    _callableStatementMock.registerOutParameter(5, Types.VARCHAR);
    _callableStatementMock.registerOutParameter(6, Types.INTEGER);
    _callableStatementMock.registerOutParameter(7, Types.VARCHAR);
    EasyMock.expect(_callableStatementMock.execute()).andThrow(exception);
    _dsReadLockMock.unlock();

    PowerMock.replayAll();
    try
    {
      _connector.verifierHabilitationOI(_tracabilite, codeOI, numIntervention, reference, typeReference);
      Assert.fail("Should throw exception"); //$NON-NLS-1$
    }
    catch (RavelException ex)
    {
      PowerMock.verifyAll();
      String message = "Technical Exception in PadawanFTTHOracleConnector during verifierHabilitationOI call: type(SQLException) reason(ORA-XYZ)"; //$NON-NLS-1$
      RavelException excpected = new RavelException(ExceptionType.DATABASE_ERROR, ErrorCode.CNCTOR_00010, message, IPadawanFTTHOracleConnector.BEAN_ID, exception);
      Assert.assertEquals(excpected, ex);
    }

  }

}
