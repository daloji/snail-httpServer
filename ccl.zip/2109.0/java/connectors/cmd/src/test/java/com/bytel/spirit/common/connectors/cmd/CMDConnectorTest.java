/*******************************************************************************
* $Id: CMDConnectorTest.java 44035 2020-11-25 11:33:28Z jjoly $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.cmd;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.cxf.jaxrs.impl.MetadataMap;
import org.apache.cxf.jaxrs.impl.ResponseBuilderImpl;
import org.easymock.Capture;
import org.easymock.EasyMock;
import org.easymock.EasyMockSupport;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.conf.generated.LoadBalancer;
import com.bytel.ravel.common.conf.generated.Param;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.test.JUnitTools;
import com.bytel.ravel.common.test.podam.JavaTimeManufacturer;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.net.loadbalancing.ILoadBalancer;
import com.bytel.ravel.net.loadbalancing.URLBalancedElement;
import com.bytel.ravel.net.rest.RestConnectorPool;
import com.bytel.ravel.net.rest.RestInstance;
import com.bytel.ravel.services.conf.connector.generated.Connector;
import com.bytel.ravel.services.conf.connector.generated.URL;
import com.bytel.ravel.services.conf.connector.generated.URLS;
import com.bytel.ravel.services.connector.AbstractRESTConnector;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.BasicResponse;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.ressources.RetourConverter;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.cmd.Commande;
import com.bytel.spirit.common.shared.saab.cmd.CommandeComposite;
import com.bytel.spirit.common.shared.saab.cmd.Statut;
import com.bytel.spirit.common.shared.saab.cmd.request.CreateCommandeRequest;
import com.bytel.spirit.common.shared.saab.cmd.request.CreateModificationCommercialeRequest;
import com.bytel.spirit.common.shared.saab.cmd.request.CreateModificationTechniqueRequest;
import com.bytel.spirit.common.shared.saab.cmd.request.UpdateModificationCommercialeStatutRequest;
import com.bytel.spirit.common.shared.saab.cmd.request.UpdateModificationTechniqueStatutRequest;
import com.bytel.spirit.common.shared.saab.cmd.response.GetCommandeCompositeResponse;
import com.bytel.spirit.common.shared.saab.cmd.response.GetCommandeResponse;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author kbettenc
 * @version ($Revision: 44035 $ $Date: 2020-11-25 12:33:28 +0100 (mer. 25 nov. 2020) $)
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({})
public class CMDConnectorTest extends EasyMockSupport
{

  /**
   *
   */
  private static final String ACTION = "action"; //$NON-NLS-1$

  /**
   *
   */
  private static final String ID_CMD = "idCmd"; //$NON-NLS-1$

  /**
   * Path for get pad2001
   */
  private static final String commande_PARAM = "/commande/"; //$NON-NLS-1$

  /**
   * Path for get pad2002
   */
  private static final String modificationCommerciale_PARAM = "/modificationCommerciale/"; //$NON-NLS-1$

  /**
   * Path for get pad2004
   */
  private static final String modificationTechnique_PARAM = "/modificationTechnique/"; //$NON-NLS-1$

  /**
   * Path for get pad2002
   */
  private static final String commandeComposite_PARAM = "/commandeComposite/"; //$NON-NLS-1$

  /**
   * The constant for JSON_ERROR_MESSAGE
   */
  private static final String JSON_ERROR_MESSAGE = Messages.getString("CMDConnector.JsonErrorMessage"); //$NON-NLS-1$

  /**
   * NO_COMPTE
   */
  private static final String NO_COMPTE = "noCompte"; //$NON-NLS-1$

  /**
   * NATURE_COMMANDE
   */
  private static final String NATURE_COMMANDE = "natureCommande"; //$NON-NLS-1$

  /**
   * CLIENT_OPERATEUR
   */
  private static final String CLIENT_OPERATEUR = "clientOperateur"; //$NON-NLS-1$

  /**
   * ID_EXTERNE
   */
  private static final String ID_EXTERNE = "idExterne"; //$NON-NLS-1$

  /**
   * statut
   */
  private static final String STATUT = "statut"; //$NON-NLS-1$

  /**
   * type fibre param
   */
  private static final String PARAM_TYPE_FIBRE = "typeDeFiltre"; //$NON-NLS-1$

  /**
   * Code erreur
   */
  private static final String CODE_ERREUR = "codeErreur"; //$NON-NLS-1$

  /**
   * Libelle erreur
   */
  private static final String LIBELLE_ERREUR = "libelleErreur"; //$NON-NLS-1$

  /**
   * The CLE_SEQUENCEMENT string.
   */
  private static final String CLE_SEQUENCEMENT = "CLE_SEQUENCEMENT"; //$NON-NLS-1$

  /**
   * The constant for cleSequencement param
   */
  private static final String PARAM_CLE_SEQUENCEMENT = "cleSequencement"; //$NON-NLS-1$

  /**
   * The FINAL_RETOUR_RESULTAT string.
   */
  private static final String FINAL_RETOUR_RESULTAT = "FINAL_RETOUR_RESULTAT"; //$NON-NLS-1$

  /**
   * The FINAL_RETOUR_CATEGORIE string.
   */
  private static final String FINAL_RETOUR_CATEGORIE = "FINAL_RETOUR_CATEGORIE"; //$NON-NLS-1$

  /**
   * The FINAL_RETOUR_DIAGNOSTIC string.
   */
  private static final String FINAL_RETOUR_DIAGNOSTIC = "FINAL_RETOUR_DIAGNOSTIC"; //$NON-NLS-1$

  /**
   * The FINAL_RETOUR_LIBELLE string.
   */
  private static final String FINAL_RETOUR_LIBELLE = "FINAL_RETOUR_LIBELLE"; //$NON-NLS-1$

  /**
   * Connector to test
   */
  private CMDConnector _connector;

  /**
   * Factory to generate beans
   */
  private PodamFactory _podam = new PodamFactoryImpl();

  /**
   * Mock {@link ILoadBalancer}
   */
  @MockStrict
  ILoadBalancer<URLBalancedElement> _loadBalancerMock;

  /**
   * Mock {@link URLBalancedElement}
   */
  @MockStrict
  URLBalancedElement _urlBalancedElementMock;

  /**
   * Mock of connectors pool HTTP
   */
  @MockStrict
  Hashtable<String, RestConnectorPool> _connectorPoolMock;

  /**
   * Mock {@link RestConnectorPool}
   */
  @MockStrict
  RestConnectorPool _restConnectorPoolMock;

  /**
   * Mock {@link RestInstance}
   */
  @MockStrict
  RestInstance _restInstanceMock;

  /**
   * Mock InputStream
   */
  @MockStrict
  InputStream _inputStreamMock;

  /**
   * Mock {@link Response}
   */
  @MockStrict
  Response _responseMock;

  /**
   * Path for PAD2001
   */
  private String _commandeUrl;

  /**
   * Path for CommandeComposite
   */
  private String _commandeCompositeUrl;

  /**
   * Path for PAD2002
   */
  private String _modificationCommercialeUrl;

  /**
   * Path for PAD2004
   */
  private String _modificationTechniqueUrl;

  /**
   * Initialize before tests
   *
   * @throws Exception
   *           Thrown in case of error during switch in attributes of parent class
   */
  @Before
  public void beforeTest() throws Exception
  {
    _podam.getStrategy().setMemoization(false);
    _podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());
    JavaTimeManufacturer.registerPodamFactory(_podam);

    _connector = new CMDConnector();
    _commandeUrl = commande_PARAM;
    _commandeCompositeUrl = commandeComposite_PARAM;
    _modificationCommercialeUrl = modificationCommerciale_PARAM;
    _modificationTechniqueUrl = modificationTechnique_PARAM;

    JUnitTools.setInaccessibleFieldValue(_connector, "_loadBalancer", _loadBalancerMock); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_connectorPool", _connectorPoolMock); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_commandeUrl", _commandeUrl); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_commandeCompositeUrl", _commandeCompositeUrl); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_modificationCommercialeUrl", _modificationCommercialeUrl); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_modificationTechniqueUrl", _modificationTechniqueUrl); //$NON-NLS-1$

    PowerMock.resetAll();
  }

  /**
   * Test method {@link CMDConnector#loadConnectorConfiguration(Connector)}
   *
   * @throws Exception
   *           Thrown in case of error
   */
  @Test
  public void test_loadConnectorConfiguration() throws Exception
  {
    final Connector connector = new Connector();

    Param param = new Param();
    param.setName("PAD2001_Commande"); //$NON-NLS-1$
    param.setValue(_commandeUrl);
    connector.getParam().add(param);

    param = new Param();
    param.setName("PAD2002_ModificationCommerciale"); //$NON-NLS-1$
    param.setValue(_modificationCommercialeUrl);
    connector.getParam().add(param);

    param = new Param();
    param.setName("PAD2003_CommandeComposite"); //$NON-NLS-1$
    param.setValue(_commandeCompositeUrl);
    connector.getParam().add(param);

    param = new Param();
    param.setName("PAD2004_ModificationTechnique"); //$NON-NLS-1$
    param.setValue(_modificationTechniqueUrl);
    connector.getParam().add(param);

    connector.setURLS(generateURLS());

    // test
    _connector.loadConnectorConfiguration(connector);

    // assertions
    Assert.assertEquals(_commandeUrl, JUnitTools.getInaccessibleFieldValue(_connector, "_commandeUrl")); //$NON-NLS-1$
    Assert.assertEquals(_modificationCommercialeUrl, JUnitTools.getInaccessibleFieldValue(_connector, "_modificationCommercialeUrl")); //$NON-NLS-1$
    Assert.assertEquals(_commandeCompositeUrl, JUnitTools.getInaccessibleFieldValue(_connector, "_commandeCompositeUrl")); //$NON-NLS-1$
    Assert.assertEquals(_modificationTechniqueUrl, JUnitTools.getInaccessibleFieldValue(_connector, "_modificationTechniqueUrl")); //$NON-NLS-1$
  }

  /**
   * Test KO for the method
   * {@link CMDConnector#commandeCompositeGererLireTousModCommModTechParPfiFiltrerTraite(Tracabilite, String, String)}
   * Expected : Retour KO, CAT-4, DONNEE_INCONNUE, "clientOperateur xxx inconnue"
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testCommandeCompositeGererLireTousModCommParPfiFiltrerTraite_KO_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final CommandeComposite commandeComposite = _podam.manufacturePojo(CommandeComposite.class);
    List<CommandeComposite> listeCommandeComposite = Arrays.asList(commandeComposite);
    final Retour retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "clientOperateur " + commandeComposite.getCommande().getClientOperateur() + " inconnu"); //$NON-NLS-1$ //$NON-NLS-2$
    final GetCommandeCompositeResponse getCommandeResponse = new GetCommandeCompositeResponse(RetourConverter.convertToJsonRetour(retour), listeCommandeComposite); //FIXME
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(getCommandeResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_commandeCompositeUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<CommandeComposite>> result = _connector.commandeCompositeGererLireTousModCommModTechParPfiFiltrerTraite(tracabilite, commandeComposite.getCommande().getClientOperateur(), commandeComposite.getCommande().getNoCompte());
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, CLIENT_OPERATEUR, commandeComposite.getCommande().getClientOperateur());
    checkQueryParams(queryParamsCapture, NO_COMPTE, commandeComposite.getCommande().getNoCompte());
    checkQueryParams(queryParamsCapture, PARAM_TYPE_FIBRE, "TRAITE"); //$NON-NLS-1$

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertEquals(listeCommandeComposite, result._second);
  }

  /**
   * Test OK for the method
   * {@link CMDConnector#CommandeCompositeGererLireTousModCommParPfiFiltrerTraite(Tracabilite, String, String)}
   * httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testCommandeCompositeGererLireTousModCommParPfiFiltrerTraite_OK_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final CommandeComposite commandeComposite = _podam.manufacturePojo(CommandeComposite.class);
    List<CommandeComposite> listeCommandeComposite = Arrays.asList(commandeComposite);
    final Retour retour = RetourFactory.createOkRetour();
    final GetCommandeCompositeResponse getCommandeResponse = new GetCommandeCompositeResponse(RetourConverter.convertToJsonRetour(retour), listeCommandeComposite); //FIXME
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(getCommandeResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_commandeCompositeUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<CommandeComposite>> result = _connector.commandeCompositeGererLireTousModCommModTechParPfiFiltrerTraite(tracabilite, commandeComposite.getCommande().getClientOperateur(), commandeComposite.getCommande().getNoCompte());
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, CLIENT_OPERATEUR, commandeComposite.getCommande().getClientOperateur());
    checkQueryParams(queryParamsCapture, NO_COMPTE, commandeComposite.getCommande().getNoCompte());
    checkQueryParams(queryParamsCapture, PARAM_TYPE_FIBRE, "TRAITE"); //$NON-NLS-1$

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertEquals(listeCommandeComposite, result._second);
  }

  /**
   * Test KO for the method {@link CMDConnector#commandeLireTousParStatutEtPFI(Tracabilite, String, String, String)}
   * Expected : Retour KO, CAT-4, DONNEE_INCONNUE, "clientOperateur xxx inconnue"
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testCommandeCompositeLireTousParPFI_KO_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final CommandeComposite commandeComposite = _podam.manufacturePojo(CommandeComposite.class);
    List<CommandeComposite> listeCommandeComposite = Arrays.asList(commandeComposite);
    final Retour retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "clientOperateur " + commandeComposite.getCommande().getClientOperateur() + " inconnu"); //$NON-NLS-1$ //$NON-NLS-2$
    final GetCommandeCompositeResponse getCommandeResponse = new GetCommandeCompositeResponse(RetourConverter.convertToJsonRetour(retour), listeCommandeComposite); //FIXME
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(getCommandeResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_commandeCompositeUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<CommandeComposite>> result = _connector.commandeCompositeLireTousParPFI(tracabilite, commandeComposite.getCommande().getClientOperateur(), commandeComposite.getCommande().getNoCompte(), commandeComposite.getCommande().getStatut());
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, CLIENT_OPERATEUR, commandeComposite.getCommande().getClientOperateur());
    checkQueryParams(queryParamsCapture, NO_COMPTE, commandeComposite.getCommande().getNoCompte());
    checkQueryParams(queryParamsCapture, STATUT, commandeComposite.getCommande().getStatut());

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertEquals(listeCommandeComposite, result._second);
  }

  /**
   * Test OK for the method {@link CMDConnector#commandeLireTousParStatutEtPFI(Tracabilite, String, String, String)}
   * httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testCommandeCompositeLireTousParPFI_OK_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final CommandeComposite commandeComposite = _podam.manufacturePojo(CommandeComposite.class);
    List<CommandeComposite> listeCommandeComposite = Arrays.asList(commandeComposite);
    final Retour retour = RetourFactory.createOkRetour();
    final GetCommandeCompositeResponse getCommandeResponse = new GetCommandeCompositeResponse(RetourConverter.convertToJsonRetour(retour), listeCommandeComposite); //FIXME
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(getCommandeResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_commandeCompositeUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<CommandeComposite>> result = _connector.commandeCompositeLireTousParPFI(tracabilite, commandeComposite.getCommande().getClientOperateur(), commandeComposite.getCommande().getNoCompte(), commandeComposite.getCommande().getStatut());
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, CLIENT_OPERATEUR, commandeComposite.getCommande().getClientOperateur());
    checkQueryParams(queryParamsCapture, NO_COMPTE, commandeComposite.getCommande().getNoCompte());
    checkQueryParams(queryParamsCapture, STATUT, commandeComposite.getCommande().getStatut());

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertEquals(listeCommandeComposite, result._second);
  }

  /**
   * Test KO for the method {@link CMDConnector#commandeCreer(Tracabilite, CreateCommandeRequest)} httpStatus 200, with
   * retourKO
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testCommandeCreer_KO_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final CreateCommandeRequest createCommandeRequest = _podam.manufacturePojo(CreateCommandeRequest.class);
    final Retour retour = RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.DONNEE_INDISPONIBLE, StringConstants.EMPTY_STRING);
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(basicResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();

    // construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(_commandeUrl), EasyMock.capture(headersCapture), EasyMock.eq(GsonTools.getIso8601Ms().toJson(createCommandeRequest)), EasyMock.isNull())).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.commandeCreer(tracabilite, createCommandeRequest);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test KO for the method {@link CMDConnector#commandeCreer(Tracabilite, CreateCommandeRequest)} httpStatus 200,
   * jsonResponse null (throws RavelException)
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testCommandeCreer_KO_003() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final CreateCommandeRequest createCommandeRequest = _podam.manufacturePojo(CreateCommandeRequest.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();

    // construct response
    final Response response = new ResponseBuilderImpl().status(200).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(_commandeUrl), EasyMock.capture(headersCapture), EasyMock.eq(GsonTools.getIso8601Ms().toJson(createCommandeRequest)), EasyMock.isNull())).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    ConnectorResponse<Retour, Nothing> result = null;

    PowerMock.replayAll();
    result = _connector.commandeCreer(tracabilite, createCommandeRequest);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    Retour expectedRetour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, JSON_ERROR_MESSAGE);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test KO for the method {@link CMDConnector#commandeCreer(Tracabilite, CreateCommandeRequest)} httpStatus 500,
   * jsonResponse null (throws RavelException)
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testCommandeCreer_KO_004() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final CreateCommandeRequest createCommandeRequest = _podam.manufacturePojo(CreateCommandeRequest.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();

    // construct response
    final Response response = new ResponseBuilderImpl().status(500).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(_commandeUrl), EasyMock.capture(headersCapture), EasyMock.eq(GsonTools.getIso8601Ms().toJson(createCommandeRequest)), EasyMock.isNull())).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    ConnectorResponse<Retour, Nothing> result = null;

    PowerMock.replayAll();
    result = _connector.commandeCreer(tracabilite, createCommandeRequest);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    Retour expectedRetour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, JSON_ERROR_MESSAGE);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test OK for the method {@link CMDConnector#commandeCreer(Tracabilite, CreateCommandeRequest)} with httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testCommandeCreer_OK_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final CreateCommandeRequest createCommandeRequest = _podam.manufacturePojo(CreateCommandeRequest.class);
    final Retour retour = RetourFactory.createOkRetour();
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(basicResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();

    // construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(_commandeUrl), EasyMock.capture(headersCapture), EasyMock.eq(GsonTools.getIso8601Ms().toJson(createCommandeRequest)), EasyMock.isNull())).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.commandeCreer(tracabilite, createCommandeRequest);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    Assert.assertEquals(retour, result._first);
  }

  /**
   * Test KO for the method {@link CMDConnector#commandeGererFinaliserCommandesParPFI(Tracabilite, String, String)}
   * httpStatus 200
   *
   * Expected : Retour KO, CAT-4, DONNEE_INCONNUE, "noCompte xxx inconnu"
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testCommandeGererFinaliserCommandesParPFI_KO_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final Commande commande = _podam.manufacturePojoWithFullData(Commande.class);
    final Retour retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "noCompte " + commande.getNoCompte() + " inconnu"); //$NON-NLS-1$ //$NON-NLS-2$
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(basicResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_commandeUrl), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.commandeGererFinaliserCommandesParPFI(tracabilite, commande.getClientOperateur(), commande.getNoCompte());
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, CLIENT_OPERATEUR, commande.getClientOperateur());
    checkQueryParams(queryParamsCapture, NO_COMPTE, commande.getNoCompte());
    checkQueryParams(queryParamsCapture, ACTION, "GererFinaliserCommandesParPFI"); //$NON-NLS-1$

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test OK for the method {@link CMDConnector#commandeGererFinaliserCommandesParPFI(Tracabilite, String, String)}
   * httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testCommandeGererFinaliserCommandesParPFI_OK_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final Commande commande = _podam.manufacturePojoWithFullData(Commande.class);
    final Retour retour = RetourFactory.createOkRetour();
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(basicResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_commandeUrl), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.commandeGererFinaliserCommandesParPFI(tracabilite, commande.getClientOperateur(), commande.getNoCompte());
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, CLIENT_OPERATEUR, commande.getClientOperateur());
    checkQueryParams(queryParamsCapture, NO_COMPTE, commande.getNoCompte());
    checkQueryParams(queryParamsCapture, ACTION, "GererFinaliserCommandesParPFI"); //$NON-NLS-1$

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method {@link CMDConnector#commandeLirePlusVieuxParCleSequencement(Tracabilite, String)} when everything
   * is Ok.
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testCommandeLirePlusVieuxParCleSequencement_001() throws Exception
  {
    // Prepare the parameters for the get request
    MultivaluedMap<String, String> headers = createGetHeaders();

    HashMap<String, String> queryParams = new HashMap<>();
    queryParams.put(PARAM_CLE_SEQUENCEMENT, CLE_SEQUENCEMENT);

    // Prepare the response for the get request
    final Commande commande = new Commande();
    commande.setStatut(Statut.ACQUITTE.name());
    final Retour retour = RetourFactory.createRetour(FINAL_RETOUR_RESULTAT, FINAL_RETOUR_CATEGORIE, FINAL_RETOUR_DIAGNOSTIC, FINAL_RETOUR_LIBELLE);
    final GetCommandeResponse getCommandeResponse = new GetCommandeResponse(RetourConverter.convertToJsonRetour(retour), Arrays.asList(commande));
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(getCommandeResponse);
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // The get request
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.get(_commandeUrl, headers, queryParams)).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();

    // Execute the command
    final Tracabilite tracabilite = new Tracabilite();
    final String cleSequencement = CLE_SEQUENCEMENT;
    final ConnectorResponse<Retour, Commande> result = _connector.commandeLirePlusVieuxParCleSequencement(tracabilite, cleSequencement);

    PowerMock.verifyAll();

    // Verify that the response is as expected
    Retour expectedRetour = RetourFactory.createRetour(FINAL_RETOUR_RESULTAT, FINAL_RETOUR_CATEGORIE, FINAL_RETOUR_DIAGNOSTIC, FINAL_RETOUR_LIBELLE);
    Commande expectedCommande = new Commande();
    expectedCommande.setStatut(Statut.ACQUITTE.name());

    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertEquals(expectedCommande, result._second);
  }

  /**
   * Test the method {@link CMDConnector#commandeLirePlusVieuxParCleSequencement(Tracabilite, String)} when
   * cleSequencement is null.
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testCommandeLirePlusVieuxParCleSequencement_002() throws Exception
  {
    // Prepare the parameters for the get request
    MultivaluedMap<String, String> headers = createGetHeaders();

    HashMap<String, String> queryParams = new HashMap<>();

    // Prepare the response for the get request
    final Commande commande = new Commande();
    commande.setStatut(Statut.ACQUITTE.name());
    final Retour retour = RetourFactory.createRetour(FINAL_RETOUR_RESULTAT, FINAL_RETOUR_CATEGORIE, FINAL_RETOUR_DIAGNOSTIC, FINAL_RETOUR_LIBELLE);
    final GetCommandeResponse getCommandeResponse = new GetCommandeResponse(RetourConverter.convertToJsonRetour(retour), Arrays.asList(commande));
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(getCommandeResponse);
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // The get request
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.get(_commandeUrl, headers, queryParams)).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();

    // Execute the command
    final Tracabilite tracabilite = new Tracabilite();
    final ConnectorResponse<Retour, Commande> result = _connector.commandeLirePlusVieuxParCleSequencement(tracabilite, null);

    PowerMock.verifyAll();

    // Verify that the response is as expected
    Retour expectedRetour = RetourFactory.createRetour(FINAL_RETOUR_RESULTAT, FINAL_RETOUR_CATEGORIE, FINAL_RETOUR_DIAGNOSTIC, FINAL_RETOUR_LIBELLE);
    Commande expectedCommande = new Commande();
    expectedCommande.setStatut(Statut.ACQUITTE.name());

    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertEquals(expectedCommande, result._second);
  }

  /**
   * Test the method {@link CMDConnector#commandeLirePlusVieuxParCleSequencement(Tracabilite, String)} when the list of
   * Commande inside the response is null.
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testCommandeLirePlusVieuxParCleSequencement_003() throws Exception
  {
    // Prepare the parameters for the get request
    MultivaluedMap<String, String> headers = createGetHeaders();

    HashMap<String, String> queryParams = new HashMap<>();
    queryParams.put(PARAM_CLE_SEQUENCEMENT, CLE_SEQUENCEMENT);

    // Prepare the response for the get request
    final Retour retour = RetourFactory.createRetour(FINAL_RETOUR_RESULTAT, FINAL_RETOUR_CATEGORIE, FINAL_RETOUR_DIAGNOSTIC, FINAL_RETOUR_LIBELLE);
    final GetCommandeResponse getCommandeResponse = new GetCommandeResponse(RetourConverter.convertToJsonRetour(retour), null);
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(getCommandeResponse);
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // The get request
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.get(_commandeUrl, headers, queryParams)).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();

    // Execute the command
    final Tracabilite tracabilite = new Tracabilite();
    final String cleSequencement = CLE_SEQUENCEMENT;
    final ConnectorResponse<Retour, Commande> result = _connector.commandeLirePlusVieuxParCleSequencement(tracabilite, cleSequencement);

    PowerMock.verifyAll();

    // Verify that the response is as expected
    Retour expectedRetour = RetourFactory.createRetour(FINAL_RETOUR_RESULTAT, FINAL_RETOUR_CATEGORIE, FINAL_RETOUR_DIAGNOSTIC, FINAL_RETOUR_LIBELLE);
    Commande expectedCommande = null;

    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertEquals(expectedCommande, result._second);
  }

  /**
   * Test the method {@link CMDConnector#commandeLirePlusVieuxParCleSequencement(Tracabilite, String)} when the response
   * has no entity.
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testCommandeLirePlusVieuxParCleSequencement_004() throws Exception
  {
    // Prepare the parameters for the get request
    MultivaluedMap<String, String> headers = createGetHeaders();

    HashMap<String, String> queryParams = new HashMap<>();
    queryParams.put(PARAM_CLE_SEQUENCEMENT, CLE_SEQUENCEMENT);

    // Prepare the response for the get request
    final Response response = new ResponseBuilderImpl().status(200).build();

    // The get request
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.get(_commandeUrl, headers, queryParams)).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();

    // Execute the command
    final Tracabilite tracabilite = new Tracabilite();
    final String cleSequencement = CLE_SEQUENCEMENT;
    final ConnectorResponse<Retour, Commande> result = _connector.commandeLirePlusVieuxParCleSequencement(tracabilite, cleSequencement);

    PowerMock.verifyAll();

    // Verify that the response is as expected
    Retour expectedRetour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, "Impossible de recuperer la reponse"); //$NON-NLS-1$
    Commande expectedCommande = null;

    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertEquals(expectedCommande, result._second);
  }

  /**
   * Test the method {@link CMDConnector#commandeLirePlusVieuxParCleSequencement(Tracabilite, String)} when the call to
   * borrowObject throws an exception.
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testCommandeLirePlusVieuxParCleSequencement_005() throws Exception
  {
    final String urlBalancedElementName = RandomStringUtils.randomAlphanumeric(45);
    final String urlBalancedElementDescription = RandomStringUtils.randomAlphabetic(9);

    EasyMock.expect(_loadBalancerMock.chooseBalancedElement()).andReturn(_urlBalancedElementMock);
    EasyMock.expect(_urlBalancedElementMock.getName()).andReturn(urlBalancedElementName);
    EasyMock.expect(_urlBalancedElementMock.getDescription()).andReturn(urlBalancedElementDescription);
    EasyMock.expect(_urlBalancedElementMock.getName()).andReturn(urlBalancedElementName);
    EasyMock.expect(_connectorPoolMock.get(urlBalancedElementName)).andReturn(_restConnectorPoolMock);

    RavelException exception = new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, "RAVEL_EXCEPTION_MESSAGE"); //$NON-NLS-1$

    EasyMock.expect(_restConnectorPoolMock.borrowObject()).andThrow(exception);
    _restConnectorPoolMock.returnObject(null);
    _loadBalancerMock.setKOElement(_urlBalancedElementMock);
    EasyMock.expect(_urlBalancedElementMock.getName()).andReturn(null);

    PowerMock.replayAll();

    // Execute the command
    final Tracabilite tracabilite = new Tracabilite();
    final String cleSequencement = CLE_SEQUENCEMENT;
    final ConnectorResponse<Retour, Commande> result = _connector.commandeLirePlusVieuxParCleSequencement(tracabilite, cleSequencement);

    PowerMock.verifyAll();

    // Verify that the response is as expected
    Retour expectedRetour = RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, "Technical Exception in AbstractWebServiceConnector during commandeLirePlusVieuxParCleSequencement call: code() reason(RAVEL_EXCEPTION_MESSAGE) at <generated> line: -1"); //$NON-NLS-1$
    Commande expectedCommande = null;

    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertEquals(expectedCommande, result._second);
  }

  /**
   * Test the method {@link CMDConnector#commandeLirePlusVieuxParCleSequencement(Tracabilite, String)} when the
   * _commandeUrl is null.
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testCommandeLirePlusVieuxParCleSequencement_006() throws Exception
  {
    // Set the _commandeUrl parameter to null
    JUnitTools.setInaccessibleFieldValue(_connector, "_commandeUrl", null); //$NON-NLS-1$

    PowerMock.replayAll();

    final ConnectorResponse<Retour, Commande> result = _connector.commandeLirePlusVieuxParCleSequencement(null, null);

    PowerMock.verifyAll();

    Retour expectedRetour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, "The configuration parameter PAD2001_Commande is missing"); //$NON-NLS-1$
    Commande expectedCommande = null;

    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertEquals(expectedCommande, result._second);
  }

  /**
   * Test OK for the method {@link CMDConnector#commandeLireTousParStatutEtPFI(Tracabilite, String, String, String)}
   * httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testCommandeLireTousParStatutEtPFI_OK_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final Commande commande = _podam.manufacturePojo(Commande.class);
    final Retour retour = RetourFactory.createOkRetour();
    final GetCommandeResponse getCommandeResponse = new GetCommandeResponse(RetourConverter.convertToJsonRetour(retour), Arrays.asList(commande));
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(getCommandeResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_commandeUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<Commande>> result = _connector.commandeLireTousParStatutEtPFI(tracabilite, commande.getClientOperateur(), commande.getNoCompte(), commande.getStatut());
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, CLIENT_OPERATEUR, commande.getClientOperateur());
    checkQueryParams(queryParamsCapture, NO_COMPTE, commande.getNoCompte());
    checkQueryParams(queryParamsCapture, STATUT, commande.getStatut());

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertEquals(commande, result._second.get(0));
  }

  /**
   * Test the method {@link CMDConnector#commandeLireUn(Tracabilite, String)} httpStatus 200 Retour KO with idCommande
   * inconnu
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testCommandeLireUn_KO_002() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final String idCommande = RandomStringUtils.randomAlphabetic(5);
    final Retour retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "idCommande inconnu"); //$NON-NLS-1$
    final GetCommandeResponse getCommandeResponse = new GetCommandeResponse(RetourConverter.convertToJsonRetour(retour), null);
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(getCommandeResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_commandeUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Commande> result = _connector.commandeLireUn(tracabilite, idCommande);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, ID_CMD, idCommande);

    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method {@link CMDConnector#commandeLireUn(Tracabilite, String)} httpStatus 200 jsonResponse null (throws
   * RavelException)
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testCommandeLireUn_KO_003() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final String idCommande = RandomStringUtils.randomAlphabetic(5);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_commandeUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    ConnectorResponse<Retour, Commande> result = null;

    // Call connector
    PowerMock.replayAll();
    result = _connector.commandeLireUn(tracabilite, idCommande);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture);

    Retour expectedRetour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, JSON_ERROR_MESSAGE);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method {@link CMDConnector#commandeLireUn(Tracabilite, String)} httpStatus 500 jsonResponse null (throws
   * RavelException)
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testCommandeLireUn_KO_004() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final String idCommande = RandomStringUtils.randomAlphabetic(5);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(500).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_commandeUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    ConnectorResponse<Retour, Commande> result = null;

    PowerMock.replayAll();
    result = _connector.commandeLireUn(tracabilite, idCommande);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture);

    Retour expectedRetour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, JSON_ERROR_MESSAGE);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test OK for the method {@link CMDConnector#commandeLireUn(Tracabilite, String)} httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testCommandeLireUn_OK_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final Commande commande = _podam.manufacturePojo(Commande.class);
    final Retour retour = RetourFactory.createOkRetour();
    final GetCommandeResponse getCommandeResponse = new GetCommandeResponse(RetourConverter.convertToJsonRetour(retour), Arrays.asList(commande)); //FIXME
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(getCommandeResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_commandeUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Commande> result = _connector.commandeLireUn(tracabilite, commande.getIdCmd());
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, ID_CMD, commande.getIdCmd());

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertEquals(commande, result._second);
  }

  /**
   * Test the method {@link CMDConnector#commandeLireUnParIdExterneEtPFI(Tracabilite, String, String, String)}
   * httpStatus 200 Retour KO with idCommande inconnu
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testCommandeLireUnParIdExterneEtPFI_KO_002() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final String clientOperateur = RandomStringUtils.randomAlphabetic(5);
    final String noCompte = RandomStringUtils.randomAlphabetic(5);
    final String idExterne = RandomStringUtils.randomAlphabetic(5);
    final String natureCommande = RandomStringUtils.randomAlphabetic(5);
    final Retour retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "clientOperateur " + clientOperateur + " inconnu"); //$NON-NLS-1$ //$NON-NLS-2$
    final GetCommandeResponse getCommandeResponse = new GetCommandeResponse(RetourConverter.convertToJsonRetour(retour), null);
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(getCommandeResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_commandeUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Commande> result = _connector.commandelireUnParIdExterneEtNatureCommandeEtPFI(tracabilite, clientOperateur, noCompte, idExterne, natureCommande);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, CLIENT_OPERATEUR, clientOperateur);
    checkQueryParams(queryParamsCapture, NO_COMPTE, noCompte);
    checkQueryParams(queryParamsCapture, ID_EXTERNE, idExterne);

    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method {@link CMDConnector#commandeLireUn(Tracabilite, String)} httpStatus 200 jsonResponse null (throws
   * RavelException)
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testCommandeLireUnParIdExterneEtPFI_KO_003() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final String clientOperateur = RandomStringUtils.randomAlphabetic(5);
    final String noCompte = RandomStringUtils.randomAlphabetic(5);
    final String idExterne = RandomStringUtils.randomAlphabetic(5);
    final String natureCommande = RandomStringUtils.randomAlphabetic(5);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_commandeUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    ConnectorResponse<Retour, Commande> result = null;

    PowerMock.replayAll();
    result = _connector.commandelireUnParIdExterneEtNatureCommandeEtPFI(tracabilite, clientOperateur, noCompte, idExterne, natureCommande);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture);

    Retour expectedRetour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, JSON_ERROR_MESSAGE);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method {@link CMDConnector#commandeLireUn(Tracabilite, String)} httpStatus 500 jsonResponse null (throws
   * RavelException)
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testCommandeLireUnParIdExterneEtPFI_KO_004() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final String clientOperateur = RandomStringUtils.randomAlphabetic(5);
    final String noCompte = RandomStringUtils.randomAlphabetic(5);
    final String idExterne = RandomStringUtils.randomAlphabetic(5);
    final String natureCommande = RandomStringUtils.randomAlphabetic(5);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(500).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_commandeUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    ConnectorResponse<Retour, Commande> result = null;

    PowerMock.replayAll();
    result = _connector.commandelireUnParIdExterneEtNatureCommandeEtPFI(tracabilite, clientOperateur, noCompte, idExterne, natureCommande);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture);

    Retour expectedRetour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, JSON_ERROR_MESSAGE);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test OK for the method {@link CMDConnector#commandeLireUnParIdExterneEtPFI(Tracabilite, String, String, String)}
   * httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testCommandeLireUnParIdExterneEtPFI_OK_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final Commande commande = _podam.manufacturePojo(Commande.class);
    final Retour retour = RetourFactory.createOkRetour();
    final GetCommandeResponse getCommandeResponse = new GetCommandeResponse(RetourConverter.convertToJsonRetour(retour), Arrays.asList(commande)); //FIXME
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(getCommandeResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_commandeUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Commande> result = _connector.commandelireUnParIdExterneEtNatureCommandeEtPFI(tracabilite, commande.getClientOperateur(), commande.getNoCompte(), commande.getIdExterne(), commande.getNatureCommande());
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, CLIENT_OPERATEUR, commande.getClientOperateur());
    checkQueryParams(queryParamsCapture, NO_COMPTE, commande.getNoCompte());
    checkQueryParams(queryParamsCapture, ID_EXTERNE, commande.getIdExterne());
    checkQueryParams(queryParamsCapture, NATURE_COMMANDE, commande.getNatureCommande());

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertEquals(commande, result._second);
  }

  /**
   * Test KO for the method {@link CMDConnector#commandeModifierStatut(Tracabilite, String, String, String, String)}
   * httpStatus 400
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testCommandeModifierStatut_KO_002() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final String idCommande = RandomStringUtils.randomAlphabetic(5);
    final String statut = "TRAITEE"; //$NON-NLS-1$

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_commandeUrl), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    ConnectorResponse<Retour, Nothing> result = null;

    PowerMock.replayAll();
    result = _connector.commandeModifierStatut(tracabilite, idCommande, statut, null, null);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, ID_CMD, idCommande);
    checkQueryParams(queryParamsCapture, STATUT, statut);
    checkQueryParams(queryParamsCapture, CODE_ERREUR, null);
    checkQueryParams(queryParamsCapture, LIBELLE_ERREUR, null);

    Retour expectedRetour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, JSON_ERROR_MESSAGE);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test OK for the method {@link CMDConnector#commandeModifierStatut(Tracabilite, String, String, String, String)}
   * httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testCommandeModifierStatut_OK_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final String idCommande = RandomStringUtils.randomAlphabetic(5);
    final String statut = "TRAITEE"; //$NON-NLS-1$
    final Retour retour = RetourFactory.createOkRetour();
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(basicResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_commandeUrl), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.commandeModifierStatut(tracabilite, idCommande, statut, null, null);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, ID_CMD, idCommande);
    checkQueryParams(queryParamsCapture, STATUT, statut);
    checkQueryParams(queryParamsCapture, CODE_ERREUR, null);
    checkQueryParams(queryParamsCapture, LIBELLE_ERREUR, null);

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test OK for the method {@link CMDConnector#commandeModifierStatut(Tracabilite, String, String, String, String)}
   * httpStatus 500
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testCommandeModifierStatut_OK_002() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final String idCommande = RandomStringUtils.randomAlphabetic(5);
    final String statut = "TRAITEE"; //$NON-NLS-1$
    final Retour retour = RetourFactory.createOkRetour();
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(basicResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(500).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_commandeUrl), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.commandeModifierStatut(tracabilite, idCommande, statut, null, null);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, ID_CMD, idCommande);
    checkQueryParams(queryParamsCapture, STATUT, statut);
    checkQueryParams(queryParamsCapture, CODE_ERREUR, null);
    checkQueryParams(queryParamsCapture, LIBELLE_ERREUR, null);

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test OK for the method {@link CMDConnector#commandeModifierStatut(Tracabilite, String, String, String, String)}
   * httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testCommandeModifierStatut_OK_003() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final String idCommande = RandomStringUtils.randomAlphabetic(5);
    final String statut = "REJETE"; //$NON-NLS-1$
    final String codeErreur = "codeErreur"; //$NON-NLS-1$
    final String libelleErreur = "libelleErreur"; //$NON-NLS-1$
    final Retour retour = RetourFactory.createOkRetour();
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(basicResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_commandeUrl), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.commandeModifierStatut(tracabilite, idCommande, statut, codeErreur, libelleErreur);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, ID_CMD, idCommande);
    checkQueryParams(queryParamsCapture, STATUT, statut);
    checkQueryParams(queryParamsCapture, CODE_ERREUR, codeErreur);
    checkQueryParams(queryParamsCapture, LIBELLE_ERREUR, libelleErreur);

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test OK for the method {@link CMDConnector#commandeModifierStatut(Tracabilite, String, String, String, String)}
   * httpStatus 500
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testCommandeModifierStatut_OK_004() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final String idCommande = RandomStringUtils.randomAlphabetic(5);
    final String statut = "REJETE"; //$NON-NLS-1$
    final String codeErreur = "codeErreur"; //$NON-NLS-1$
    final String libelleErreur = "libelleErreur"; //$NON-NLS-1$
    final Retour retour = RetourFactory.createOkRetour();
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(basicResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(500).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_commandeUrl), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.commandeModifierStatut(tracabilite, idCommande, statut, codeErreur, libelleErreur);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, ID_CMD, idCommande);
    checkQueryParams(queryParamsCapture, STATUT, statut);
    checkQueryParams(queryParamsCapture, CODE_ERREUR, codeErreur);
    checkQueryParams(queryParamsCapture, LIBELLE_ERREUR, libelleErreur);

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test OK for the method {@link CMDConnector#commandeModifierStatut(Tracabilite, String, String, String, String)}
   * httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testCommandeModifierStatut_OK_005() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final String idCommande = RandomStringUtils.randomAlphabetic(5);
    final String statut = "TRAITE_NOK"; //$NON-NLS-1$
    final String codeErreur = "codeErreur"; //$NON-NLS-1$
    final String libelleErreur = "libelleErreur"; //$NON-NLS-1$
    final Retour retour = RetourFactory.createOkRetour();
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(basicResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_commandeUrl), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.commandeModifierStatut(tracabilite, idCommande, statut, codeErreur, libelleErreur);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, ID_CMD, idCommande);
    checkQueryParams(queryParamsCapture, STATUT, statut);
    checkQueryParams(queryParamsCapture, CODE_ERREUR, codeErreur);
    checkQueryParams(queryParamsCapture, LIBELLE_ERREUR, libelleErreur);

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test OK for the method {@link CMDConnector#commandeModifierStatut(Tracabilite, String, String, String, String)}
   * httpStatus 500
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testCommandeModifierStatut_OK_006() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final String idCommande = RandomStringUtils.randomAlphabetic(5);
    final String statut = "TRAITE_NOK"; //$NON-NLS-1$
    final String codeErreur = "codeErreur"; //$NON-NLS-1$
    final String libelleErreur = "libelleErreur"; //$NON-NLS-1$
    final Retour retour = RetourFactory.createOkRetour();
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(basicResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(500).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_commandeUrl), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.commandeModifierStatut(tracabilite, idCommande, statut, codeErreur, libelleErreur);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, ID_CMD, idCommande);
    checkQueryParams(queryParamsCapture, STATUT, statut);
    checkQueryParams(queryParamsCapture, CODE_ERREUR, codeErreur);
    checkQueryParams(queryParamsCapture, LIBELLE_ERREUR, libelleErreur);

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test KO for the method
   * {@link CMDConnector#modificationCommercialeCreerListe(Tracabilite, CreateModificationCommercialeRequest)}
   *
   * Expected : Retour KO, CAT-4, DONNEE_INVALIDE
   *
   * @throws Exception
   *           thrown in case of error
   *
   */
  @Test
  public void testModificationCommercialeCreerListe_KO_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    Retour retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INVALIDE, "input invalid : null or empty"); //$NON-NLS-1$

    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(basicResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();

    // construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    //test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(_modificationCommercialeUrl), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.isNull())).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.modificationCommercialeCreerListe(tracabilite, null);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    Assert.assertEquals(retour, result._first);
  }

  /**
   * Test OK for the method
   * {@link CMDConnector#modificationCommercialeCreerListe(Tracabilite, CreateModificationCommercialeRequest)}
   * httpStatus 500
   *
   * @throws Exception
   *           thrown in case of error
   *
   */
  @Test
  public void testModificationCommercialeCreerListe_OK_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final CreateModificationCommercialeRequest createModificationCommercialeRequest = _podam.manufacturePojo(CreateModificationCommercialeRequest.class);
    Retour retour = RetourFactory.createOkRetour();

    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(basicResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();

    // construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    //test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(_modificationCommercialeUrl), EasyMock.capture(headersCapture), EasyMock.eq(GsonTools.getIso8601Ms().toJson(createModificationCommercialeRequest)), EasyMock.isNull())).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.modificationCommercialeCreerListe(tracabilite, createModificationCommercialeRequest);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    Assert.assertEquals(retour, result._first);
  }

  /**
   * Test KO for the method {@link CMDConnector#modificationCommercialeModifierListeStatut(Tracabilite, String, String,
   * UpdateModificationTechniqueStatutRequest))}
   *
   * Expected : Retour KO, CAT-4, DONNEE_INCONNUE, "idCommande xxx inconnue"
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testModificationCommercialeModifierStatut_KO_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final String idCommande = RandomStringUtils.randomAlphabetic(5);
    final String statut = "TRAITEE"; //$NON-NLS-1$
    final Retour retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "idCommande " + idCommande + " inconnue"); //$NON-NLS-1$ //$NON-NLS-2$
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(basicResponse);
    final UpdateModificationCommercialeStatutRequest updateModificationCommercialeStatutRequest = _podam.manufacturePojoWithFullData(UpdateModificationCommercialeStatutRequest.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_modificationCommercialeUrl), EasyMock.capture(headersCapture), EasyMock.eq(GsonTools.getIso8601Ms().toJson(updateModificationCommercialeStatutRequest)), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.modificationCommercialeModifierListeStatut(tracabilite, idCommande, statut, updateModificationCommercialeStatutRequest);

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, ID_CMD, idCommande);
    checkQueryParams(queryParamsCapture, STATUT, statut);

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test OK for the method {@link CMDConnector#modificationCommercialeModifierListeStatut(Tracabilite, String, String,
   * UpdateModificationTechniqueStatutRequest))}
   *
   * Expected : Retour OK
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testModificationCommercialeModifierStatut_OK_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final String idCommande = RandomStringUtils.randomAlphabetic(5);
    final String statut = "TRAITEE"; //$NON-NLS-1$
    final Retour retour = RetourFactory.createOkRetour();
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(basicResponse);
    final UpdateModificationCommercialeStatutRequest updateModificationCommercialeStatutRequest = _podam.manufacturePojoWithFullData(UpdateModificationCommercialeStatutRequest.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_modificationCommercialeUrl), EasyMock.capture(headersCapture), EasyMock.eq(GsonTools.getIso8601Ms().toJson(updateModificationCommercialeStatutRequest)), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.modificationCommercialeModifierListeStatut(tracabilite, idCommande, statut, updateModificationCommercialeStatutRequest);

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, ID_CMD, idCommande);
    checkQueryParams(queryParamsCapture, STATUT, statut);

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test KO for the method
   * {@link CMDConnector#modificationTechniqueCreerListe(Tracabilite, CreateModificationTechniqueRequest)}
   *
   * Expected : Retour KO, CAT-4, DONNEE_INVALIDE
   *
   * @throws Exception
   *           thrown in case of error
   *
   */
  @Test
  public void testModificationTechniqueCreerListe_KO_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    Retour retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INVALIDE, "input invalid : null or empty"); //$NON-NLS-1$

    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(basicResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();

    // construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    //test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(_modificationTechniqueUrl), EasyMock.capture(headersCapture), EasyMock.isNull(), EasyMock.isNull())).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.modificationTechniqueCreerListe(tracabilite, null);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    Assert.assertEquals(retour, result._first);
  }

  /**
   * Test OK for the method
   * {@link CMDConnector#modificationTechniqueCreerListe(Tracabilite, CreateModificationTechniqueRequest)} httpStatus
   * 500
   *
   * @throws Exception
   *           thrown in case of error
   *
   */
  @Test
  public void testModificationTechniqueCreerListe_OK_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final CreateModificationTechniqueRequest createModificationTechniqueRequest = _podam.manufacturePojo(CreateModificationTechniqueRequest.class);
    Retour retour = RetourFactory.createOkRetour();

    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(basicResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();

    // construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    //test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(_modificationTechniqueUrl), EasyMock.capture(headersCapture), EasyMock.eq(GsonTools.getIso8601Ms().toJson(createModificationTechniqueRequest)), EasyMock.isNull())).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.modificationTechniqueCreerListe(tracabilite, createModificationTechniqueRequest);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    Assert.assertEquals(retour, result._first);
  }

  /**
   * Test KO for the method {@link CMDConnector#modificationTechniqueModifierListeStatut(Tracabilite, String, String,
   * UpdateModificationTechniqueStatutRequest))}
   *
   * Expected : Retour KO, CAT-4, DONNEE_INCONNUE, "idCommande xxx inconnue"
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testModificationTechniqueModifierStatut_KO_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final String idCommande = RandomStringUtils.randomAlphabetic(5);
    final String statut = "TRAITEE"; //$NON-NLS-1$
    final Retour retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "idCommande " + idCommande + " inconnue"); //$NON-NLS-1$ //$NON-NLS-2$
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(basicResponse);
    final UpdateModificationTechniqueStatutRequest updateModificationTechniqueStatutRequest = _podam.manufacturePojoWithFullData(UpdateModificationTechniqueStatutRequest.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_modificationTechniqueUrl), EasyMock.capture(headersCapture), EasyMock.eq(GsonTools.getIso8601Ms().toJson(updateModificationTechniqueStatutRequest)), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.modificationTechniqueModifierListeStatut(tracabilite, idCommande, statut, updateModificationTechniqueStatutRequest);

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, ID_CMD, idCommande);
    checkQueryParams(queryParamsCapture, STATUT, statut);

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test OK for the method {@link CMDConnector#modificationTechniqueModifierListeStatut(Tracabilite, String, String,
   * UpdateModificationTechniqueStatutRequest))}
   *
   * Expected : Retour OK
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testModificationTechniqueModifierStatut_OK_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final String idCommande = RandomStringUtils.randomAlphabetic(5);
    final String statut = "TRAITEE"; //$NON-NLS-1$
    final Retour retour = RetourFactory.createOkRetour();
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(basicResponse);
    final UpdateModificationTechniqueStatutRequest updateModificationTechniqueStatutRequest = _podam.manufacturePojoWithFullData(UpdateModificationTechniqueStatutRequest.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_modificationTechniqueUrl), EasyMock.capture(headersCapture), EasyMock.eq(GsonTools.getIso8601Ms().toJson(updateModificationTechniqueStatutRequest)), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.modificationTechniqueModifierListeStatut(tracabilite, idCommande, statut, updateModificationTechniqueStatutRequest);

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, ID_CMD, idCommande);
    checkQueryParams(queryParamsCapture, STATUT, statut);

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Check the query params in rest send request method
   *
   * @param queryParams
   *          the actual query params
   * @param expected_p
   *          list of expected query params strings key1 value1 key2 value2...keyN valueN
   */
  private void checkQueryParams(Capture<Map<String, String>> queryParams, String... expected_p)
  {
    if (expected_p == null)
    {
      Assert.assertNull(queryParams.getValue());
    }
    else
    {
      Assert.assertEquals(0, expected_p.length % 2);
      for (int i = 0; i < expected_p.length; i = i + 2)
      {
        Assert.assertEquals(expected_p[i + 1], queryParams.getValue().get(expected_p[i]));
      }
    }
  }

  /**
   * Create the headers used for get requests.
   *
   * @return the headers.
   */
  private MultivaluedMap<String, String> createGetHeaders()
  {
    MultivaluedMap<String, String> headers = new MetadataMap<>();
    headers.add("X-Oauth2-Habilit", "SPIRIT_STARK"); //$NON-NLS-1$ //$NON-NLS-2$
    //headers.add("Content-Type", "application/json");//$NON-NLS-1$ //$NON-NLS-2$
    headers.add("X-Request-Id", null);//$NON-NLS-1$
    headers.add("X-Request-Id-Spirit", null);//$NON-NLS-1$
    headers.add("X-Source", null);//$NON-NLS-1$
    headers.add("X-Process", null);//$NON-NLS-1$
    headers.add("X-Process-Id-Spirit", null);//$NON-NLS-1$

    return headers;
  }

  /**
   * Génération du LoadBalancer minimal pour passer {@link AbstractRESTConnector#loadConnectorConfiguration(Connector)}
   *
   * @return {@link LoadBalancer}
   */
  private LoadBalancer generateLoadBalancer()
  {
    final LoadBalancer loadBalancer = new LoadBalancer();
    Param timer = new Param();
    timer.setName("TIMER"); //$NON-NLS-1$
    timer.setValue("30"); //$NON-NLS-1$
    loadBalancer.getParam().add(timer);
    loadBalancer.setType("RoundRobin"); //$NON-NLS-1$
    return loadBalancer;
  }

  /**
   * Génération du URL minimal pour passer {@link AbstractRESTConnector#loadConnectorConfiguration(Connector)}
   *
   * @return {@link URL}
   */
  private URL generateURL()
  {
    final URL url = new URL();
    url.setName("urlName"); //$NON-NLS-1$
    url.setAccessPoint("http://localhost:8888"); //$NON-NLS-1$
    Param param = new Param();
    param.setName("PROXY_ENABLED"); //$NON-NLS-1$
    param.setValue(String.valueOf(false));
    url.getParam().add(param);
    param = new Param();
    param.setName("TIMEOUT"); //$NON-NLS-1$
    param.setValue("30"); //$NON-NLS-1$
    url.getParam().add(param);

    return url;
  }

  /**
   * Génération du URLS minimal pour passer {@link AbstractRESTConnector#loadConnectorConfiguration(Connector)}
   *
   * @return {@link URLS}
   */
  private URLS generateURLS()
  {
    final URLS urls = new URLS();
    urls.setLoadBalancer(generateLoadBalancer());
    urls.getURL().add(generateURL());
    return urls;
  }

  /**
   * prepare mock scenario to initialize method sendRequest from AbstractRestConnector
   *
   * @throws Exception
   *           Thrown in case of error
   */
  private void initializeMocksForSendRequest() throws Exception
  {
    final String urlBalancedElementName = RandomStringUtils.randomAlphanumeric(45);
    final String urlBalancedElementDescription = RandomStringUtils.randomAlphabetic(9);

    EasyMock.expect(_loadBalancerMock.chooseBalancedElement()).andReturn(_urlBalancedElementMock);
    EasyMock.expect(_urlBalancedElementMock.getName()).andReturn(urlBalancedElementName);
    EasyMock.expect(_urlBalancedElementMock.getDescription()).andReturn(urlBalancedElementDescription);
    EasyMock.expect(_urlBalancedElementMock.getName()).andReturn(urlBalancedElementName);
    EasyMock.expect(_connectorPoolMock.get(urlBalancedElementName)).andReturn(_restConnectorPoolMock);
    EasyMock.expect(_restConnectorPoolMock.borrowObject()).andReturn(_restInstanceMock);
    _restInstanceMock.setReceiveTimeout(0);
  }

}
