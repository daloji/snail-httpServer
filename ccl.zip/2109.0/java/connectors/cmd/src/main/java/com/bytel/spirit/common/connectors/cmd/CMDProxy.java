/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.cmd;

import java.util.List;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.probes.AvgDoubleCollectorItem;
import com.bytel.ravel.common.probes.AvgFlowPerSecondCollector;
import com.bytel.ravel.common.probes.RavelProbeConfigurationManager;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.services.connector.BaseProxy;
import com.bytel.ravel.services.connector.ConnectorExecution;
import com.bytel.ravel.services.connector.ConnectorManager;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.cmd.Commande;
import com.bytel.spirit.common.shared.saab.cmd.CommandeComposite;
import com.bytel.spirit.common.shared.saab.cmd.request.CreateCommandeRequest;
import com.bytel.spirit.common.shared.saab.cmd.request.CreateModificationCommercialeRequest;
import com.bytel.spirit.common.shared.saab.cmd.request.CreateModificationTechniqueRequest;
import com.bytel.spirit.common.shared.saab.cmd.request.UpdateModificationCommercialeStatutRequest;
import com.bytel.spirit.common.shared.saab.cmd.request.UpdateModificationTechniqueStatutRequest;

/**
 * Proxy of {@link CMDConnector}
 *
 * @author kbettenc
 * @version ($Revision$ $Date$)
 */
public final class CMDProxy extends BaseProxy implements ICMD
{
  /**
   * Proxy instance.
   */
  private static CMDProxy _instance = new CMDProxy();

  /**
   * @return The proxy instance.
   */
  public static CMDProxy getInstance()
  {
    return _instance;
  }

  /**
   * For probe to count the amount of call to the commandeCreer operation
   */
  AvgFlowPerSecondCollector _avg_commandeCreer_call_counter;

  /**
   * For probe to count the execution time of call to the commandeCreer operation
   */
  AvgDoubleCollectorItem _avg_commandeCreer_ExecTime;

  /**
   * For probe to count the amount of call to the commandeLireTousParStatutEtPFI operation
   */
  AvgFlowPerSecondCollector _avg_commandeLireTousParStatutEtPFI_call_counter;

  /**
   * For probe to count the execution time of call to the commandeLireTousParStatutEtPFI operation
   */
  AvgDoubleCollectorItem _avg_commandeLireTousParStatutEtPFI_ExecTime;

  /**
   * For probe to count the amount of call to the commandeCompositeGererLireTousModCommParPfiFiltrerTraite operation
   */
  AvgFlowPerSecondCollector _avg_commandeCompositeGererLireTousModCommParPfiFiltrerTraite_call_counter;

  /**
   * For probe to count the execution time of call to the commandeCompositeGererLireTousModCommParPfiFiltrerTraite
   * operation
   */
  AvgDoubleCollectorItem _avg_commandeCompositeGererLireTousModCommParPfiFiltrerTraite_ExecTime;

  /**
   * For probe to count the amount of call to the commandeLireUn operation
   */
  AvgFlowPerSecondCollector _avg_commandeLireUn_call_counter;

  /**
   * For probe to count the execution time of call to the commandeLireUn operation
   */
  AvgDoubleCollectorItem _avg_commandeLireUn_ExecTime;

  /**
   * For probe to count the amount of call to the commandeLireUnParIdExterneEtPFI operation
   */
  AvgFlowPerSecondCollector _avg_commandeLireUnParIdExterneEtPFI_call_counter;

  /**
   * For probe to count the execution time of call to the commandeLireUnParIdExterneEtPFI operation
   */
  AvgDoubleCollectorItem _avg_commandeLireUnParIdExterneEtPFI_ExecTime;

  /**
   * For probe to count the amount of call to the commandeModifierStatut operation
   */
  AvgFlowPerSecondCollector _avg_commandeModifierStatut_call_counter;

  /**
   * For probe to count the execution time of call to the commandeModifierStatut operation
   */
  AvgDoubleCollectorItem _avg_commandeModifierStatut_ExecTime;

  /**
   * For probe to count the amount of call to the commandeLirePlusVieuxParCleSequencement operation
   */
  AvgFlowPerSecondCollector _avg_commandeLirePlusVieuxParCleSequencement_call_counter;

  /**
   * For probe to count the execution time of call to the commandeLirePlusVieuxParCleSequencement operation
   */
  AvgDoubleCollectorItem _avg_commandeLirePlusVieuxParCleSequencement_ExecTime;

  /**
   * For probe to count the amount of call to the commandeGererFinaliserCommandesParPFI operation
   */
  AvgFlowPerSecondCollector _avg_commandeGererFinaliserCommandesParPFI_call_counter;

  /**
   * For probe to count the execution time of call to the commandeGererFinaliserCommandesParPFI operation
   */
  AvgDoubleCollectorItem _avg_commandeGererFinaliserCommandesParPFI_ExecTime;

  /**
   * For probe to count the amount of call to the commandeCompositeLireTousParPFI operation
   */
  AvgFlowPerSecondCollector _avg_commandeCompositeLireTousParPFI_call_counter;

  /**
   * For probe to count the execution time of call to the commandeCompositeLireTousParPFI operation
   */
  AvgDoubleCollectorItem _avg_commandeCompositeLireTousParPFI_ExecTime;

  /**
   * For probe to count the amount of call to the modificationCommercialeCreerListe operation
   */
  AvgFlowPerSecondCollector _avg_modificationCommercialeCreerListe_call_counter;

  /**
   * For probe to count the execution time of call to the modificationCommercialeCreerListe operation
   */
  AvgDoubleCollectorItem _avg_modificationCommercialeCreerListe_ExecTime;

  /**
   * For probe to count the amount of call to the modificationCommercialeModifierListeStatut operation
   */
  AvgFlowPerSecondCollector _avg_modificationCommercialeModifierListeStatut_call_counter;

  /**
   * For probe to count the execution time of call to the modificationCommercialeModifierListeStatut operation
   */
  AvgDoubleCollectorItem _avg_modificationCommercialeModifierListeStatut_ExecTime;

  /**
   * For probe to count the amount of call to the modificationCommercialeCreerListe operation
   */
  AvgFlowPerSecondCollector _avg_modificationTechniqueCreerListe_call_counter;

  /**
   * For probe to count the execution time of call to the modificationCommercialeCreerListe operation
   */
  AvgDoubleCollectorItem _avg_modificationTechniqueCreerListe_ExecTime;

  /**
   * For probe to count the amount of call to the modificationCommercialeModifierListeStatut operation
   */
  AvgFlowPerSecondCollector _avg_modificationTechniqueModifierListeStatut_call_counter;

  /**
   * For probe to count the execution time of call to the modificationCommercialeModifierListeStatut operation
   */
  AvgDoubleCollectorItem _avg_modificationTechniqueModifierListeStatut_ExecTime;

  /**
   * Constructor
   */
  private CMDProxy()
  {
    _avg_commandeCreer_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_commandeCreer_call_counter", "CMDProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_commandeCreer_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_commandeCreer_ExecTime", "CMDProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_commandeLireUn_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_commandeLireUn_call_counter", "CMDProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_commandeLireUn_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_commandeLireUn_ExecTime", "CMDProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_commandeLireUnParIdExterneEtPFI_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_commandeLireUnParIdExterneEtPFI_call_counter", "CMDProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_commandeLireUnParIdExterneEtPFI_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_commandeLireUnParIdExterneEtPFI_ExecTime", "CMDProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_commandeLireTousParStatutEtPFI_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_commandeLireTousParStatutEtPFI_call_counter", "CMDProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_commandeLireTousParStatutEtPFI_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_commandeLireTousParStatutEtPFI_ExecTime", "CMDProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_commandeModifierStatut_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_commandeModifierStatut_call_counter", "CMDProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_commandeModifierStatut_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_commandeModifierStatut_ExecTime", "CMDProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_commandeGererFinaliserCommandesParPFI_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_commandeGererFinaliserCommandesParPFI_call_counter", "CMDProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_commandeGererFinaliserCommandesParPFI_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_commandeGererFinaliserCommandesParPFI_ExecTime", "CMDProxy"); //$NON-NLS-1$//$NON-NLS-2$

    _avg_commandeCompositeLireTousParPFI_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_commandeCompositeLireTousParPFI_call_counter", "CMDProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_commandeCompositeLireTousParPFI_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_commandeCompositeLireTousParPFI_ExecTime", "CMDProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_commandeCompositeGererLireTousModCommParPfiFiltrerTraite_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_commandeCompositeGererLireTousModCommParPfiFiltrerTraite_call_counter", "CMDProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_commandeCompositeGererLireTousModCommParPfiFiltrerTraite_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_commandeCompositeGererLireTousModCommParPfiFiltrerTraite_ExecTime", "CMDProxy"); //$NON-NLS-1$//$NON-NLS-2$

    _avg_modificationCommercialeCreerListe_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_modificationCommercialeCreerListe_call_counter", "CMDProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_modificationCommercialeCreerListe_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_modificationCommercialeCreerListe_ExecTime", "CMDProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_modificationCommercialeModifierListeStatut_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_modificationCommercialeModifierListeStatut_call_counter", "CMDProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_modificationCommercialeModifierListeStatut_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_modificationCommercialeModifierListeStatut_ExecTime", "CMDProxy"); //$NON-NLS-1$//$NON-NLS-2$

    _avg_modificationTechniqueCreerListe_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_modificationTechniqueCreerListe_call_counter", "CMDProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_modificationTechniqueCreerListe_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_modificationTechniqueCreerListe_ExecTime", "CMDProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_modificationTechniqueModifierListeStatut_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_modificationTechniqueModifierListeStatut_call_counter", "CMDProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_modificationTechniqueModifierListeStatut_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_modificationTechniqueModifierListeStatut_ExecTime", "CMDProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_commandeLirePlusVieuxParCleSequencement_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_commandeLirePlusVieuxParCleSequencement_call_counter", "CMDProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_commandeLirePlusVieuxParCleSequencement_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_commandeLirePlusVieuxParCleSequencement_ExecTime", "CMDProxy"); //$NON-NLS-1$//$NON-NLS-2$
  }

  @Override
  public ConnectorResponse<Retour, List<CommandeComposite>> commandeCompositeGererLireTousModCommModTechParPfiFiltrerTraite(Tracabilite tracabilite_p, String clientOperateur_p, String noCompte_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, List<CommandeComposite>>>(ICMDConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, List<CommandeComposite>> run() throws RavelException
      {
        ICMDConnector icmdConnector = null;
        try
        {
          icmdConnector = (ICMDConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          // Retour NOK
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_commandeCompositeGererLireTousModCommParPfiFiltrerTraite_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return icmdConnector.commandeCompositeGererLireTousModCommModTechParPfiFiltrerTraite(tracabilite_p, clientOperateur_p, noCompte_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_commandeCompositeGererLireTousModCommParPfiFiltrerTraite_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, List<CommandeComposite>> commandeCompositeLireTousParPFI(Tracabilite tracabilite_p, String clientOperateur_p, String noCompte_p, String statut_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, List<CommandeComposite>>>(ICMDConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, List<CommandeComposite>> run() throws RavelException
      {
        ICMDConnector icmdConnector = null;
        try
        {
          icmdConnector = (ICMDConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          // Retour NOK
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_commandeCompositeLireTousParPFI_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return icmdConnector.commandeCompositeLireTousParPFI(tracabilite_p, clientOperateur_p, noCompte_p, statut_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_commandeCompositeLireTousParPFI_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> commandeCreer(Tracabilite tracabilite_p, CreateCommandeRequest commande_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(ICMDConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        ICMDConnector icmdConnector = null;
        try
        {
          icmdConnector = (ICMDConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          // Retour NOK
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_commandeCreer_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return icmdConnector.commandeCreer(tracabilite_p, commande_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_commandeCreer_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> commandeGererFinaliserCommandesParPFI(Tracabilite tracabilite_p, String clientOperateur_p, String noCompte_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(ICMDConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        ICMDConnector icmdConnector = null;
        try
        {
          icmdConnector = (ICMDConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          // Retour NOK
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_commandeGererFinaliserCommandesParPFI_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return icmdConnector.commandeGererFinaliserCommandesParPFI(tracabilite_p, clientOperateur_p, noCompte_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_commandeGererFinaliserCommandesParPFI_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Commande> commandeLirePlusVieuxParCleSequencement(Tracabilite tracabilite_p, String cleSequencement) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Commande>>(ICMDConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Commande> run() throws RavelException
      {
        ICMDConnector icmdConnector = null;
        try
        {
          icmdConnector = (ICMDConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          // Retour NOK
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_commandeLirePlusVieuxParCleSequencement_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return icmdConnector.commandeLirePlusVieuxParCleSequencement(tracabilite_p, cleSequencement);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_commandeLirePlusVieuxParCleSequencement_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, List<Commande>> commandeLireTousParStatutEtPFI(Tracabilite tracabilite_p, String clientOperateur_p, String noCompte_p, String statut_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, List<Commande>>>(ICMDConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, List<Commande>> run() throws RavelException
      {
        ICMDConnector icmdConnector = null;
        try
        {
          icmdConnector = (ICMDConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          // Retour NOK
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_commandeLireTousParStatutEtPFI_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return icmdConnector.commandeLireTousParStatutEtPFI(tracabilite_p, clientOperateur_p, noCompte_p, statut_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_commandeLireTousParStatutEtPFI_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Commande> commandeLireUn(Tracabilite tracabilite_p, String idCmd_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Commande>>(ICMDConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Commande> run() throws RavelException
      {
        ICMDConnector icmdConnector = null;
        try
        {
          icmdConnector = (ICMDConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          // Retour NOK
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_commandeLireUn_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return icmdConnector.commandeLireUn(tracabilite_p, idCmd_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_commandeLireUn_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Commande> commandelireUnParIdExterneEtNatureCommandeEtPFI(Tracabilite tracabilite_p, String clientOperateur_p, String noCompte_p, String idExterne_p, String natureCommande_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Commande>>(ICMDConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Commande> run() throws RavelException
      {
        ICMDConnector icmdConnector = null;
        try
        {
          icmdConnector = (ICMDConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          // Retour NOK
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_commandeLireUnParIdExterneEtPFI_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return icmdConnector.commandelireUnParIdExterneEtNatureCommandeEtPFI(tracabilite_p, clientOperateur_p, noCompte_p, idExterne_p, natureCommande_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_commandeLireUnParIdExterneEtPFI_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> commandeModifierStatut(Tracabilite tracabilite_p, String idCmd_p, String statut_p, String codeErreur_p, String libelleErreur_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(ICMDConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        ICMDConnector icmdConnector = null;
        try
        {
          icmdConnector = (ICMDConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          // Retour NOK
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_commandeModifierStatut_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return icmdConnector.commandeModifierStatut(tracabilite_p, idCmd_p, statut_p, codeErreur_p, libelleErreur_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_commandeModifierStatut_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> modificationCommercialeCreerListe(Tracabilite tracabilite_p, CreateModificationCommercialeRequest listeModificationCommerciale_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(ICMDConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        ICMDConnector icmdConnector = null;
        try
        {
          icmdConnector = (ICMDConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          // Retour NOK
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_modificationCommercialeCreerListe_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return icmdConnector.modificationCommercialeCreerListe(tracabilite_p, listeModificationCommerciale_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_modificationCommercialeCreerListe_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> modificationCommercialeModifierListeStatut(Tracabilite tracabilite_p, String idCmd_p, String statut_p, UpdateModificationCommercialeStatutRequest listeIdModificationCommerciale_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(ICMDConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        ICMDConnector icmdConnector = null;
        try
        {
          icmdConnector = (ICMDConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          // Retour NOK
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_modificationCommercialeModifierListeStatut_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return icmdConnector.modificationCommercialeModifierListeStatut(tracabilite_p, idCmd_p, statut_p, listeIdModificationCommerciale_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_modificationCommercialeModifierListeStatut_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> modificationTechniqueCreerListe(Tracabilite tracabilite_p, CreateModificationTechniqueRequest listeModificationTechnique_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(ICMDConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        ICMDConnector icmdConnector = null;
        try
        {
          icmdConnector = (ICMDConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          // Retour NOK
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_modificationTechniqueCreerListe_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return icmdConnector.modificationTechniqueCreerListe(tracabilite_p, listeModificationTechnique_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_modificationTechniqueCreerListe_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> modificationTechniqueModifierListeStatut(Tracabilite tracabilite_p, String idCmd_p, String statut_p, UpdateModificationTechniqueStatutRequest listeIdModificationTechnique_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(ICMDConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        ICMDConnector icmdConnector = null;
        try
        {
          icmdConnector = (ICMDConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          // Retour NOK
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_modificationTechniqueModifierListeStatut_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return icmdConnector.modificationTechniqueModifierListeStatut(tracabilite_p, idCmd_p, statut_p, listeIdModificationTechnique_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_modificationTechniqueModifierListeStatut_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }
}
