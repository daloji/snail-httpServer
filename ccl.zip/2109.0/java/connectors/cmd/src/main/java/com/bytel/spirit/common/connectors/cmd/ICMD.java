/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.cmd;

import java.util.List;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.cmd.Commande;
import com.bytel.spirit.common.shared.saab.cmd.CommandeComposite;
import com.bytel.spirit.common.shared.saab.cmd.request.CreateCommandeRequest;
import com.bytel.spirit.common.shared.saab.cmd.request.CreateModificationCommercialeRequest;
import com.bytel.spirit.common.shared.saab.cmd.request.CreateModificationTechniqueRequest;
import com.bytel.spirit.common.shared.saab.cmd.request.UpdateModificationCommercialeStatutRequest;
import com.bytel.spirit.common.shared.saab.cmd.request.UpdateModificationTechniqueStatutRequest;

/**
 * Interface of CMDConnector that defines methods to implements
 *
 * @author kbettenc
 * @version ($Revision$ $Date$)
 */
public interface ICMD
{
  /**
   * @param tracabilite_p
   *          the trace
   * @param clientOperateur_p
   *          the clientOperateur
   * @param noCompte_p
   *          the noCompte
   * @return an instance of {@link ConnectorResponse}
   * @throws RavelException
   *           on exceptions
   */
  public ConnectorResponse<Retour, List<CommandeComposite>> commandeCompositeGererLireTousModCommModTechParPfiFiltrerTraite(Tracabilite tracabilite_p, String clientOperateur_p, String noCompte_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the trace
   * @param clientOperateur_p
   *          the clientOperateur
   * @param noCompte_p
   *          the noCompte
   * @param statut_p
   *          the statut
   * @return an instance of {@link ConnectorResponse}
   * @throws RavelException
   *           on exceptions
   */
  public ConnectorResponse<Retour, List<CommandeComposite>> commandeCompositeLireTousParPFI(Tracabilite tracabilite_p, String clientOperateur_p, String noCompte_p, String statut_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          The trace
   * @param commande_p
   *          the commande
   * @return an instance of {@link ConnectorResponse}
   * @throws RavelException
   *           on exceptions
   */
  public ConnectorResponse<Retour, Nothing> commandeCreer(Tracabilite tracabilite_p, CreateCommandeRequest commande_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the trace
   * @param clientOperateur_p
   *          the clientOperateur
   * @param noCompte_p
   *          the noCompte
   * @return an instance of {@link ConnectorResponse}
   * @throws RavelException
   *           on exceptions
   */
  public ConnectorResponse<Retour, Nothing> commandeGererFinaliserCommandesParPFI(Tracabilite tracabilite_p, String clientOperateur_p, String noCompte_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          The trace
   * @param cleSequencement
   *          The cleSequencement
   * @return an instance of {@link ConnectorResponse}
   * @throws RavelException
   *           on exceptions
   */
  public ConnectorResponse<Retour, Commande> commandeLirePlusVieuxParCleSequencement(Tracabilite tracabilite_p, String cleSequencement) throws RavelException;

  /**
   * @param tracabilite_p
   *          the trace
   * @param clientOperateur_p
   *          the clientOperateur
   * @param noCompte_p
   *          the noCompte
   * @param statut_p
   *          the statut
   * @return an instance of {@link ConnectorResponse}
   * @throws RavelException
   *           on exceptions
   */
  public ConnectorResponse<Retour, List<Commande>> commandeLireTousParStatutEtPFI(Tracabilite tracabilite_p, String clientOperateur_p, String noCompte_p, String statut_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          The trace
   * @param idCmd_p
   *          The idCmd
   * @return an instance of {@link ConnectorResponse}
   * @throws RavelException
   *           on exceptions
   */
  public ConnectorResponse<Retour, Commande> commandeLireUn(Tracabilite tracabilite_p, String idCmd_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the trace
   * @param clientOperateur_p
   *          the clientOperateur
   * @param noCompte_p
   *          the noCompte
   * @param idExterne_p
   *          the idExterne
   * @param natureCommande_p
   *          nature commande
   * @return an instance of {@link ConnectorResponse}
   * @throws RavelException
   *           on exceptions
   */
  public ConnectorResponse<Retour, Commande> commandelireUnParIdExterneEtNatureCommandeEtPFI(Tracabilite tracabilite_p, String clientOperateur_p, String noCompte_p, String idExterne_p, String natureCommande_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          The trace
   * @param idCmd_p
   *          The idCmd
   * @param statut_p
   *          the statut
   * @param codeErreur_p
   *          the codeErreur
   * @param libelleErreur_p
   *          the libelleErreur
   * @return an instance of {@link ConnectorResponse}
   * @throws RavelException
   *           on exceptions
   */
  public ConnectorResponse<Retour, Nothing> commandeModifierStatut(Tracabilite tracabilite_p, String idCmd_p, String statut_p, String codeErreur_p, String libelleErreur_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          The trace
   * @param listeModificationCommerciale_p
   *          The list of modificationCommerciale object
   * @return an instance of {@link ConnectorResponse}
   * @throws RavelException
   *           on exceptions
   */
  public ConnectorResponse<Retour, Nothing> modificationCommercialeCreerListe(Tracabilite tracabilite_p, CreateModificationCommercialeRequest listeModificationCommerciale_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the trace
   * @param idCmd_p
   *          the idCmd
   * @param statut_p
   *          the statut
   * @param listeIdModificationCommerciale_p
   * @return an instance of {@link ConnectorResponse}
   * @throws RavelException
   *           on exceptions
   */
  public ConnectorResponse<Retour, Nothing> modificationCommercialeModifierListeStatut(Tracabilite tracabilite_p, String idCmd_p, String statut_p, UpdateModificationCommercialeStatutRequest listeIdModificationCommerciale_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          The trace
   * @param listeModificationTechnique_p
   *          The list of modificationTechnique object
   * @return an instance of {@link ConnectorResponse}
   * @throws RavelException
   *           on exceptions
   */
  public ConnectorResponse<Retour, Nothing> modificationTechniqueCreerListe(Tracabilite tracabilite_p, CreateModificationTechniqueRequest listeModificationTechnique_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          The trace
   * @param idCmd_p
   *          the idCmd
   * @param statut_p
   *          the statut
   * @param listeIdModificationTechnique_p
   *          The list of modificationTechnique object
   * @return an instance of {@link ConnectorResponse}
   * @throws RavelException
   *           on exceptions
   */
  public ConnectorResponse<Retour, Nothing> modificationTechniqueModifierListeStatut(Tracabilite tracabilite_p, String idCmd_p, String statut_p, UpdateModificationTechniqueStatutRequest listeIdModificationTechnique_p) throws RavelException;

}
