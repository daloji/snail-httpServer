/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.cmd;

import com.bytel.ravel.services.connector.IConnector;

/**
 * Interface of CMDConnector that defines the BEAN_ID
 *
 * @author kbettenc
 * @version ($Revision$ $Date$)
 */
public interface ICMDConnector extends ICMD, IConnector
{

  /**
   * The id to retrieve the connector.
   */
  public String BEAN_ID = "CMDConnector"; //$NON-NLS-1$

}
