/*******************************************************************************
* $Id: CMDConnector.java 1964 2017-10-19 18:51:22Z kbettenc $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.cmd;

import java.text.MessageFormat;
import java.util.HashMap;
import java.util.List;

import javax.ws.rs.HttpMethod;
import javax.ws.rs.core.Response;

import org.springframework.util.CollectionUtils;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.conf.generated.Param;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.services.conf.connector.generated.Connector;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.connector.RESTRequest.RESTRequestBuilder;
import com.bytel.spirit.common.shared.functional.types.json.RavelJsonTools;
import com.bytel.spirit.common.shared.misc.connectors.AbstractInternalRESTConnector;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.BasicResponse;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.ressources.RetourConverter;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.cmd.Commande;
import com.bytel.spirit.common.shared.saab.cmd.CommandeComposite;
import com.bytel.spirit.common.shared.saab.cmd.Statut;
import com.bytel.spirit.common.shared.saab.cmd.request.CreateCommandeRequest;
import com.bytel.spirit.common.shared.saab.cmd.request.CreateModificationCommercialeRequest;
import com.bytel.spirit.common.shared.saab.cmd.request.CreateModificationTechniqueRequest;
import com.bytel.spirit.common.shared.saab.cmd.request.UpdateModificationCommercialeStatutRequest;
import com.bytel.spirit.common.shared.saab.cmd.request.UpdateModificationTechniqueStatutRequest;
import com.bytel.spirit.common.shared.saab.cmd.response.GetCommandeCompositeResponse;
import com.bytel.spirit.common.shared.saab.cmd.response.GetCommandeResponse;

/**
 *
 * @author kbettenc
 * @version ($Revision: 1964 $ $Date: 2017-10-19 20:51:22 +0200 (jeu., 19 oct. 2017) $)
 */
public class CMDConnector extends AbstractInternalRESTConnector implements ICMDConnector
{

  /**
   * Path for PAD2001 operation
   */
  private static final String PAD2001_PATH_PARAM = "PAD2001_Commande"; //$NON-NLS-1$

  /**
   * Path for PAD2002 operation
   */
  private static final String PAD2002_PATH_PARAM = "PAD2002_ModificationCommerciale"; //$NON-NLS-1$

  /**
   * Path for PAD2003 operation
   */
  private static final String PAD2003_PATH_PARAM = "PAD2003_CommandeComposite"; //$NON-NLS-1$

  /**
   * Path for PAD2004 operation
   */
  private static final String PAD2004_PATH_PARAM = "PAD2004_ModificationTechnique"; //$NON-NLS-1$

  /**
   * Delay in months config parameter
   */
  private static final String FILTRER_MODIFICATION_IN_MONTH_PARAM = "FILTRER_MODIFICATION_IN_MONTH"; //$NON-NLS-1$

  /**
   * The constant for MESSAGE_MISSING_CONFIGURATION_PARAMETER
   */
  private static final String MESSAGE_MISSING_CONFIGURATION_PARAMETER = Messages.getString("CMDConnector.MissingConfigurationParameter"); //$NON-NLS-1$

  /**
   * The constant for MESSAGE_JSON_ERROR
   */
  private static final String MESSAGE_JSON_ERROR = Messages.getString("CMDConnector.JsonErrorMessage"); //$NON-NLS-1$

  /**
   * The constant for commandeCreer service
   */
  private static final String METHOD_NAME_COMMANDE_CREER = "commandeCreer"; //$NON-NLS-1$

  /**
   * The constant for commandeLireUn service
   */
  private static final String METHOD_NAME_COMMANDE_LIRE_UN = "commandeLireUn"; //$NON-NLS-1$

  /**
   * The constant for commandeLirePlusVieuxParCleSequencement service
   */
  private static final String METHOD_NAME_COMMANDE_LIRE_PLUS_VIEUX_PAR_CLE_SEQUENCEMENT = "commandeLirePlusVieuxParCleSequencement"; //$NON-NLS-1$

  /**
   * The constant for modificationTechniqueCreerListe service
   */
  private static final String METHOD_NAME_MODIFICATION_TECHNIQUE_CREER_LISTE = "modificationTechniqueCreerListe"; //$NON-NLS-1$

  /**
   * The constant for modificationTechniqueCreerListe service
   */
  private static final String METHOD_NAME_MODIFICATION_TECHNIQUE_MODIFIER_LISTE_STATUT = "modificationTechniqueModifierListeStatut"; //$NON-NLS-1$

  /**
   * The constant for commandeLireUnParIdExterneEtPFI service
   */
  private static final String METHOD_NAME_COMMANDE_LIRE_UN_PAR_ID_EXTERNE_ET_PFI = "commandelireUnParIdExterneEtNatureCommandeEtPFI"; //$NON-NLS-1$

  /**
   * The constant for commandeLireTousParStatutEtPFI service
   */
  private static final String METHOD_NAME_COMMANDE_LIRE_TOUS_PAR_STATUT_ET_PFI_ = "commandeLireTousParStatutEtPFI"; //$NON-NLS-1$

  /**
   * The constant for commandeModifierStatut service
   */
  private static final String METHOD_NAME_COMMANDE_MODIFIER_STATUT = "commandeModifierStatut"; //$NON-NLS-1$

  /**
   * The constant for commandeGererFinaliserCommandesParPFI service
   */
  private static final String METHOD_NAME_COMMANDE_GERER_FINALISER_COMMANDES_PAR_PFI = "commandeGererFinaliserCommandesParPFI"; //$NON-NLS-1$

  /**
   * The constant for modificationCommercialeCreerListe service
   */
  private static final String METHOD_NAME_MODIFICATION_COMMERCIALE_CREER_LISTE = "modificationCommercialeCreerListe"; //$NON-NLS-1$

  /**
   * The constant for PAD2002_ModificationCommerciale_Update service
   */
  private static final String METHOD_NAME_MODIFICATION_COMMERCIALE_MODIFIER_LISTE_STATUT = "modificationCommercialeModifierListeStatut"; //$NON-NLS-1$

  /**
   * The constant for commandeCompositeLireTousParPFI service
   */
  private static final String METHOD_NAME_COMMANDE_COMPOSITE_LIRE_TOUS_PAR_PFI = "commandeCompositeLireTousParPFI"; //$NON-NLS-1$

  /**
   * The constant for commandeCompositeGererLireTousModCommParPfiFiltrerTraite service
   */
  private static final String METHOD_NAME_COMMANDE_COMPOSITE_GERER_LIRE_TOUS_MOD_COMM_PAR_PFI_FILTRER_TRAITE = "commandeCompositeGererLireTousModCommParPfiFiltrerTraite"; //$NON-NLS-1$

  /**
   * The constant for idCmd param
   */
  private static final String PARAM_ID_CMD = "idCmd"; //$NON-NLS-1$

  /**
   * The constant for cleSequencement param
   */
  private static final String PARAM_CLE_SEQUENCEMENT = "cleSequencement"; //$NON-NLS-1$

  /**
   * The constant for statut param
   */
  private static final String PARAM_STATUT = "statut"; //$NON-NLS-1$

  /**
   * The constant for filter type param
   */
  private static final String PARAM_TYPE_FIBRE = "typeDeFiltre"; //$NON-NLS-1$

  /**
   * The constant for codeErreur param
   */
  private static final String PARAM_CODE_ERREUR = "codeErreur"; //$NON-NLS-1$

  /**
   * The constant for libelleErreur param
   */
  private static final String PARAM_LIBELLE_ERREUR = "libelleErreur"; //$NON-NLS-1$

  /**
   * The constant for noCompte param
   */
  private static final String PARAM_NO_COMPTE = "noCompte"; //$NON-NLS-1$

  /**
   * The constant for natureCommande param
   */
  private static final String PARAM_NATURE_COMMANDE = "natureCommande"; //$NON-NLS-1$

  /**
   * The constant for clientOperateur param
   */
  private static final String PARAM_CLIENT_OPERATEUR = "clientOperateur"; //$NON-NLS-1$

  /**
   * The constant for idExterne param
   */
  private static final String PARAM_ID_EXTERNE = "idExterne"; //$NON-NLS-1$

  /**
   * The constant for action param
   */
  private static final String PARAM_ACTION = "action"; //$NON-NLS-1$

  /**
   * The constant for action value
   */
  private static final String VALUE_ACTION = "GererFinaliserCommandesParPFI"; //$NON-NLS-1$

  /**
   * Delay in months config parameter
   */
  Integer _delayInMonths = 2;

  /**
   * Path for PAD2001
   */
  private String _commandeUrl;

  /**
   * Path for PAD2002
   */
  private String _modificationCommercialeUrl;

  /**
   * Path for PAD2004
   */
  private String _commandeCompositeUrl;

  /**
   * Path for PAD2003
   */
  private String _modificationTechniqueUrl;

  @Override
  public ConnectorResponse<Retour, List<CommandeComposite>> commandeCompositeGererLireTousModCommModTechParPfiFiltrerTraite(Tracabilite tracabilite_p, String clientOperateur_p, String noCompte_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_commandeCompositeUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD2003_PATH_PARAM));
      }

      // Query parameters
      HashMap<String, String> queryParams = new HashMap<>();
      if (StringTools.isNotNullOrEmpty(clientOperateur_p) && StringTools.isNotNullOrEmpty(noCompte_p))
      {
        queryParams.put(PARAM_CLIENT_OPERATEUR, clientOperateur_p);
        queryParams.put(PARAM_NO_COMPTE, noCompte_p);
        queryParams.put(PARAM_TYPE_FIBRE, "TRAITE"); //$NON-NLS-1$
      }

      // Call SAAB
      final Response response;
      try
      {
        RESTRequestBuilder restRequestBuilder = new RESTRequestBuilder();
        restRequestBuilder.httpMethod(HttpMethod.GET).traceability(tracabilite_p).method(METHOD_NAME_COMMANDE_COMPOSITE_GERER_LIRE_TOUS_MOD_COMM_PAR_PFI_FILTRER_TRAITE).headers(SPIRIT_STARK_REQUEST_HEADER).path(_commandeCompositeUrl).queryParameter(queryParams);
        response = sendRequest(restRequestBuilder.build());
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content to a JSON string
      String jsonResponse = getContent(response, METHOD_NAME_COMMANDE_COMPOSITE_GERER_LIRE_TOUS_MOD_COMM_PAR_PFI_FILTRER_TRAITE, tracabilite_p);

      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR);
      }

      GetCommandeCompositeResponse getCommandeCompositeResponse = GsonTools.getIso8601Ms().fromJson(jsonResponse, GetCommandeCompositeResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(getCommandeCompositeResponse.getRetour());
      List<CommandeComposite> listeCommandeComposite = getCommandeCompositeResponse.getListeCommandeComposite();

      return new ConnectorResponse<>(retour, listeCommandeComposite);
    }
    catch (Exception e_p)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, e_p));
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, List<CommandeComposite>> commandeCompositeLireTousParPFI(Tracabilite tracabilite_p, String clientOperateur_p, String noCompte_p, String statut_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_commandeCompositeUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD2003_PATH_PARAM));
      }

      // Query parameters
      HashMap<String, String> queryParams = new HashMap<>();
      if (StringTools.isNotNullOrEmpty(clientOperateur_p) && StringTools.isNotNullOrEmpty(noCompte_p))
      {
        queryParams.put(PARAM_CLIENT_OPERATEUR, clientOperateur_p);
        queryParams.put(PARAM_NO_COMPTE, noCompte_p);
        queryParams.put(PARAM_STATUT, statut_p); // Optional
      }

      // Call SAAB
      final Response response;
      try
      {
        RESTRequestBuilder restRequestBuilder = new RESTRequestBuilder();
        restRequestBuilder.httpMethod(HttpMethod.GET).traceability(tracabilite_p).method(METHOD_NAME_COMMANDE_COMPOSITE_LIRE_TOUS_PAR_PFI).headers(SPIRIT_STARK_REQUEST_HEADER).path(_commandeCompositeUrl).queryParameter(queryParams);
        response = sendRequest(restRequestBuilder.build());
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content to a JSON string
      String jsonResponse = getContent(response, METHOD_NAME_COMMANDE_COMPOSITE_LIRE_TOUS_PAR_PFI, tracabilite_p);

      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR);
      }

      GetCommandeCompositeResponse getCommandeCompositeResponse = GsonTools.getIso8601Ms().fromJson(jsonResponse, GetCommandeCompositeResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(getCommandeCompositeResponse.getRetour());
      List<CommandeComposite> listeCommandeComposite = getCommandeCompositeResponse.getListeCommandeComposite();

      return new ConnectorResponse<>(retour, listeCommandeComposite);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, Nothing> commandeCreer(Tracabilite tracabilite_p, CreateCommandeRequest commande_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_commandeUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD2001_PATH_PARAM));
      }

      // Call SAAB
      final Response response;
      try
      {
        RESTRequestBuilder restRequestBuilder = new RESTRequestBuilder();
        restRequestBuilder.httpMethod(HttpMethod.POST).traceability(tracabilite_p).method(METHOD_NAME_COMMANDE_CREER).headers(SPIRIT_STARK_REQUEST_HEADER).path(_commandeUrl).request(commande_p);
        response = sendRequest(restRequestBuilder.build());
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content to a JSON string
      String jsonResponse = getContent(response, METHOD_NAME_COMMANDE_CREER, tracabilite_p);

      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR);
      }

      BasicResponse basicResponse = GsonTools.getIso8601Ms().fromJson(jsonResponse, BasicResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(basicResponse.getRetour());

      return new ConnectorResponse<>(retour, null);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, Nothing> commandeGererFinaliserCommandesParPFI(Tracabilite tracabilite_p, String clientOperateur_p, String noCompte_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_commandeUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD2001_PATH_PARAM));
      }

      // Query parameters
      HashMap<String, String> queryParams = new HashMap<>();
      if (StringTools.isNotNullOrEmpty(clientOperateur_p) && StringTools.isNotNullOrEmpty(noCompte_p))
      {
        queryParams.put(PARAM_CLIENT_OPERATEUR, clientOperateur_p);
        queryParams.put(PARAM_NO_COMPTE, noCompte_p);
        queryParams.put(PARAM_ACTION, VALUE_ACTION);
      }

      // Call SAAB
      final Response response;
      try
      {
        RESTRequestBuilder restRequestBuilder = new RESTRequestBuilder();
        restRequestBuilder.httpMethod(HttpMethod.PUT).traceability(tracabilite_p).method(METHOD_NAME_COMMANDE_GERER_FINALISER_COMMANDES_PAR_PFI).headers(SPIRIT_STARK_REQUEST_HEADER).path(_commandeUrl).queryParameter(queryParams);
        response = sendRequest(restRequestBuilder.build());
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content to a JSON string
      String jsonResponse = getContent(response, METHOD_NAME_COMMANDE_GERER_FINALISER_COMMANDES_PAR_PFI, tracabilite_p);

      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR);
      }

      BasicResponse basicResponse = GsonTools.getIso8601Ms().fromJson(jsonResponse, BasicResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(basicResponse.getRetour());

      return new ConnectorResponse<>(retour, null);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, Commande> commandeLirePlusVieuxParCleSequencement(Tracabilite tracabilite_p, String cleSequencement) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_commandeUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD2001_PATH_PARAM));
      }

      // Query parameters
      HashMap<String, String> queryParams = new HashMap<>();

      if (StringTools.isNotNullOrEmpty(cleSequencement))
      {
        queryParams.put(PARAM_CLE_SEQUENCEMENT, cleSequencement);
      }

      // Call SAAB
      final Response response;
      try
      {
        RESTRequestBuilder restRequestBuilder = new RESTRequestBuilder();
        restRequestBuilder.httpMethod(HttpMethod.GET).traceability(tracabilite_p).method(METHOD_NAME_COMMANDE_LIRE_PLUS_VIEUX_PAR_CLE_SEQUENCEMENT).headers(SPIRIT_STARK_REQUEST_HEADER).path(_commandeUrl).queryParameter(queryParams);
        response = sendRequest(restRequestBuilder.build());
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content to a JSON string
      String jsonResponse = getContent(response, METHOD_NAME_COMMANDE_LIRE_PLUS_VIEUX_PAR_CLE_SEQUENCEMENT, tracabilite_p);

      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR);
      }

      GetCommandeResponse getCommandeResponse = RavelJsonTools.getInstance().fromJson(jsonResponse, GetCommandeResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(getCommandeResponse.getRetour());
      Commande commande = null;

      if (!CollectionUtils.isEmpty(getCommandeResponse.getListeCommande()))
      {
        if (getCommandeResponse.getListeCommande().get(0) != null)
        {
          String statut = getCommandeResponse.getListeCommande().get(0).getStatut();
          if (Statut.ACQUITTE.name().equals(statut))
          {
            commande = getCommandeResponse.getListeCommande().get(0);
          }
        }
      }

      return new ConnectorResponse<>(retour, commande);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, List<Commande>> commandeLireTousParStatutEtPFI(Tracabilite tracabilite_p, String clientOperateur_p, String noCompte_p, String statut_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_commandeUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD2001_PATH_PARAM));
      }

      // Query parameters
      HashMap<String, String> queryParams = new HashMap<>();
      if (StringTools.isNotNullOrEmpty(clientOperateur_p) && StringTools.isNotNullOrEmpty(noCompte_p) && StringTools.isNotNullOrEmpty(statut_p))
      {
        queryParams.put(PARAM_CLIENT_OPERATEUR, clientOperateur_p);
        queryParams.put(PARAM_NO_COMPTE, noCompte_p);
        queryParams.put(PARAM_STATUT, statut_p);
      }

      // Call SAAB
      final Response response;
      try
      {
        RESTRequestBuilder restRequestBuilder = new RESTRequestBuilder();
        restRequestBuilder.httpMethod(HttpMethod.GET).traceability(tracabilite_p).method(METHOD_NAME_COMMANDE_LIRE_TOUS_PAR_STATUT_ET_PFI_).headers(SPIRIT_STARK_REQUEST_HEADER).path(_commandeUrl).queryParameter(queryParams);
        response = sendRequest(restRequestBuilder.build());
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content to a JSON string
      String jsonResponse = getContent(response, METHOD_NAME_COMMANDE_LIRE_TOUS_PAR_STATUT_ET_PFI_, tracabilite_p);

      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR);
      }

      GetCommandeResponse getCommandeResponse = GsonTools.getIso8601Ms().fromJson(jsonResponse, GetCommandeResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(getCommandeResponse.getRetour());
      List<Commande> listeCommande = getCommandeResponse.getListeCommande();

      return new ConnectorResponse<>(retour, listeCommande);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, Commande> commandeLireUn(Tracabilite tracabilite_p, String idCmd_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_commandeUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD2001_PATH_PARAM));
      }

      // Query parameters
      HashMap<String, String> queryParams = new HashMap<>();
      if (StringTools.isNotNullOrEmpty(idCmd_p))
      {
        queryParams.put(PARAM_ID_CMD, idCmd_p);
      }

      // Call SAAB
      final Response response;
      try
      {
        RESTRequestBuilder restRequestBuilder = new RESTRequestBuilder();
        restRequestBuilder.httpMethod(HttpMethod.GET).traceability(tracabilite_p).method(METHOD_NAME_COMMANDE_LIRE_UN).headers(SPIRIT_STARK_REQUEST_HEADER).path(_commandeUrl).queryParameter(queryParams);
        response = sendRequest(restRequestBuilder.build());
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }
      // Get the content to a JSON string
      String jsonResponse = getContent(response, METHOD_NAME_COMMANDE_LIRE_UN, tracabilite_p);

      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR);
      }

      GetCommandeResponse getCommandeResponse = GsonTools.getIso8601Ms().fromJson(jsonResponse, GetCommandeResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(getCommandeResponse.getRetour());
      Commande commande = null;

      if (!CollectionUtils.isEmpty(getCommandeResponse.getListeCommande()))
      {
        commande = getCommandeResponse.getListeCommande().get(0);
      }

      return new ConnectorResponse<>(retour, commande);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, Commande> commandelireUnParIdExterneEtNatureCommandeEtPFI(Tracabilite tracabilite_p, String clientOperateur_p, String noCompte_p, String idExterne_p, String natureCommande_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_commandeUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD2001_PATH_PARAM));
      }

      // Query parameters
      HashMap<String, String> queryParams = new HashMap<>();
      if (StringTools.isNotNullOrEmpty(clientOperateur_p) && StringTools.isNotNullOrEmpty(noCompte_p) && StringTools.isNotNullOrEmpty(idExterne_p))
      {
        queryParams.put(PARAM_CLIENT_OPERATEUR, clientOperateur_p);
        queryParams.put(PARAM_NO_COMPTE, noCompte_p);
        queryParams.put(PARAM_ID_EXTERNE, idExterne_p);
        queryParams.put(PARAM_NATURE_COMMANDE, natureCommande_p);
      }

      // Call SAAB
      final Response response;
      try
      {
        RESTRequestBuilder restRequestBuilder = new RESTRequestBuilder();
        restRequestBuilder.httpMethod(HttpMethod.GET).traceability(tracabilite_p).method(METHOD_NAME_COMMANDE_LIRE_UN_PAR_ID_EXTERNE_ET_PFI).headers(SPIRIT_STARK_REQUEST_HEADER).path(_commandeUrl).queryParameter(queryParams);
        response = sendRequest(restRequestBuilder.build());
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }
      // Get the content to a JSON string
      String jsonResponse = getContent(response, METHOD_NAME_COMMANDE_LIRE_UN_PAR_ID_EXTERNE_ET_PFI, tracabilite_p);

      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR);
      }

      GetCommandeResponse getCommandeResponse = GsonTools.getIso8601Ms().fromJson(jsonResponse, GetCommandeResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(getCommandeResponse.getRetour());
      Commande commande = null;

      if (!CollectionUtils.isEmpty(getCommandeResponse.getListeCommande()))
      {
        commande = getCommandeResponse.getListeCommande().get(0);
      }

      return new ConnectorResponse<>(retour, commande);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, Nothing> commandeModifierStatut(Tracabilite tracabilite_p, String idCmd_p, String statut_p, String codeErreur_p, String libelleErreur_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_commandeUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD2001_PATH_PARAM));
      }

      // Query parameters
      HashMap<String, String> queryParams = new HashMap<>();
      if (StringTools.isNotNullOrEmpty(idCmd_p) && StringTools.isNotNullOrEmpty(statut_p))
      {
        queryParams.put(PARAM_ID_CMD, idCmd_p);
        queryParams.put(PARAM_STATUT, statut_p);

        if (Statut.REJETE.name().equals(statut_p) || Statut.TRAITE_NOK.name().equals(statut_p) || Statut.OBSOLETE.name().equals(statut_p) || Statut.ECHEC.name().equals(statut_p) || Statut.INVALIDE.name().equals(statut_p) || Statut.ECHEC_PEP.name().equals(statut_p))
        {
          queryParams.put(PARAM_CODE_ERREUR, codeErreur_p);
          queryParams.put(PARAM_LIBELLE_ERREUR, libelleErreur_p);
        }
      }

      // Call SAAB
      final Response response;
      try
      {
        RESTRequestBuilder restRequestBuilder = new RESTRequestBuilder();
        restRequestBuilder.httpMethod(HttpMethod.PUT).traceability(tracabilite_p).method(METHOD_NAME_COMMANDE_MODIFIER_STATUT).headers(SPIRIT_STARK_REQUEST_HEADER).path(_commandeUrl).queryParameter(queryParams);
        response = sendRequest(restRequestBuilder.build());
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content to a JSON string
      String jsonResponse = getContent(response, METHOD_NAME_COMMANDE_MODIFIER_STATUT, tracabilite_p);

      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR);
      }

      BasicResponse basicResponse = GsonTools.getIso8601Ms().fromJson(jsonResponse, BasicResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(basicResponse.getRetour());

      return new ConnectorResponse<>(retour, null);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public String getConfigParameter(String arg0_p, String arg1_p) throws RavelException
  {
    return null;
  }

  @Override
  public void loadConnectorConfiguration(Connector connector_p) throws RavelException
  {
    super.loadConnectorConfiguration(connector_p);

    // Get and validate specific configuration parameters
    for (Param param : connector_p.getParam())
    {
      switch (param.getName())
      {
        case PAD2001_PATH_PARAM:
          _commandeUrl = param.getValue();
          break;
        case PAD2002_PATH_PARAM:
          _modificationCommercialeUrl = param.getValue();
          break;
        case PAD2003_PATH_PARAM:
          _commandeCompositeUrl = param.getValue();
          break;
        case PAD2004_PATH_PARAM:
          _modificationTechniqueUrl = param.getValue();
          break;
        case FILTRER_MODIFICATION_IN_MONTH_PARAM:
          _delayInMonths = Integer.parseInt(param.getValue());
          break;
        default:
          break;
      }
    }
  }

  @Override
  public ConnectorResponse<Retour, Nothing> modificationCommercialeCreerListe(Tracabilite tracabilite_p, CreateModificationCommercialeRequest listeModificationCommerciale_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_modificationCommercialeUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD2002_PATH_PARAM));
      }

      // Call SAAB
      final Response response;
      try
      {
        RESTRequestBuilder restRequestBuilder = new RESTRequestBuilder();
        restRequestBuilder.httpMethod(HttpMethod.POST).traceability(tracabilite_p).method(METHOD_NAME_MODIFICATION_COMMERCIALE_CREER_LISTE).headers(SPIRIT_STARK_REQUEST_HEADER).path(_modificationCommercialeUrl).request(listeModificationCommerciale_p);
        response = sendRequest(restRequestBuilder.build());
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content to a JSON string
      String jsonResponse = getContent(response, METHOD_NAME_MODIFICATION_COMMERCIALE_CREER_LISTE, tracabilite_p);

      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR);
      }

      BasicResponse basicResponse = GsonTools.getIso8601Ms().fromJson(jsonResponse, BasicResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(basicResponse.getRetour());

      return new ConnectorResponse<>(retour, null);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, Nothing> modificationCommercialeModifierListeStatut(Tracabilite tracabilite_p, String idCmd_p, String statut_p, UpdateModificationCommercialeStatutRequest listeIdModificationCommerciale_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_modificationCommercialeUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD2002_PATH_PARAM));
      }

      // Query parameters
      HashMap<String, String> queryParams = new HashMap<>();
      if (StringTools.isNotNullOrEmpty(idCmd_p) && StringTools.isNotNullOrEmpty(statut_p))
      {
        queryParams.put(PARAM_ID_CMD, idCmd_p);
        queryParams.put(PARAM_STATUT, statut_p);
      }

      // Call SAAB
      final Response response;
      try
      {
        RESTRequestBuilder restRequestBuilder = new RESTRequestBuilder();
        restRequestBuilder.httpMethod(HttpMethod.PUT).traceability(tracabilite_p).method(METHOD_NAME_MODIFICATION_COMMERCIALE_MODIFIER_LISTE_STATUT).headers(SPIRIT_STARK_REQUEST_HEADER).path(_modificationCommercialeUrl).queryParameter(queryParams).request(listeIdModificationCommerciale_p);
        response = sendRequest(restRequestBuilder.build());
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content to a JSON string
      String jsonResponse = getContent(response, METHOD_NAME_MODIFICATION_COMMERCIALE_MODIFIER_LISTE_STATUT, tracabilite_p);

      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR);
      }

      BasicResponse basicResponse = GsonTools.getIso8601Ms().fromJson(jsonResponse, BasicResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(basicResponse.getRetour());
      return new ConnectorResponse<>(retour, null);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, Nothing> modificationTechniqueCreerListe(Tracabilite tracabilite_p, CreateModificationTechniqueRequest listeModificationTechnique_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_modificationTechniqueUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD2004_PATH_PARAM));
      }

      // Call SAAB
      final Response response;
      try
      {
        RESTRequestBuilder restRequestBuilder = new RESTRequestBuilder();
        restRequestBuilder.httpMethod(HttpMethod.POST).traceability(tracabilite_p).method(METHOD_NAME_MODIFICATION_TECHNIQUE_CREER_LISTE).headers(SPIRIT_STARK_REQUEST_HEADER).path(_modificationTechniqueUrl).request(listeModificationTechnique_p);
        response = sendRequest(restRequestBuilder.build());
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content to a JSON string
      String jsonResponse = getContent(response, METHOD_NAME_MODIFICATION_TECHNIQUE_CREER_LISTE, tracabilite_p);

      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR);
      }

      BasicResponse basicResponse = GsonTools.getIso8601Ms().fromJson(jsonResponse, BasicResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(basicResponse.getRetour());

      return new ConnectorResponse<>(retour, null);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, Nothing> modificationTechniqueModifierListeStatut(Tracabilite tracabilite_p, String idCmd_p, String statut_p, UpdateModificationTechniqueStatutRequest listeIdModificationTechnique_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_modificationTechniqueUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD2004_PATH_PARAM));
      }

      // Query parameters
      HashMap<String, String> queryParams = new HashMap<>();
      if (StringTools.isNotNullOrEmpty(idCmd_p) && StringTools.isNotNullOrEmpty(statut_p))
      {
        queryParams.put(PARAM_ID_CMD, idCmd_p);
        queryParams.put(PARAM_STATUT, statut_p);
      }

      // Call SAAB
      final Response response;
      try
      {
        RESTRequestBuilder restRequestBuilder = new RESTRequestBuilder();
        restRequestBuilder.httpMethod(HttpMethod.PUT).traceability(tracabilite_p).method(METHOD_NAME_MODIFICATION_TECHNIQUE_MODIFIER_LISTE_STATUT).headers(SPIRIT_STARK_REQUEST_HEADER).path(_modificationTechniqueUrl).queryParameter(queryParams).request(listeIdModificationTechnique_p);
        response = sendRequest(restRequestBuilder.build());
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content to a JSON string
      String jsonResponse = getContent(response, METHOD_NAME_MODIFICATION_TECHNIQUE_MODIFIER_LISTE_STATUT, tracabilite_p);

      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR);
      }

      BasicResponse basicResponse = GsonTools.getIso8601Ms().fromJson(jsonResponse, BasicResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(basicResponse.getRetour());
      return new ConnectorResponse<>(retour, null);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }
}
