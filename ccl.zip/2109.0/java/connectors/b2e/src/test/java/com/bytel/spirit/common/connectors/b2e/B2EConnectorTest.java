/*******************************************************************************
 * $Id: B2EConnectorTest.java 49485 2021-03-22 15:28:13Z ykulczak $
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.b2e;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;

import org.apache.tomcat.jdbc.pool.DataSource;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PowerMockListener;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.testlisteners.FieldDefaulter;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.modules.junit4.PowerMockRunnerDelegate;
import org.powermock.reflect.Whitebox;
import org.springframework.test.context.ContextConfiguration;

import com.bytel.ravel.common.conf.generated.Param;
import com.bytel.ravel.common.encryption.PasswordDecrypter;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.test.podam.JavaTimeManufacturer;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.test.podam.PodamBytelJUnit4ClassRunner;
import com.bytel.ravel.services.conf.connector.generated.Connector;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.connectors.b2e.structs.StEquipementLegacy;
import com.bytel.spirit.common.connectors.b2e.structs.StatutLegacy;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 * @author jpais
 * @version ($Revision: 49485 $ $Date: 2021-03-22 16:28:13 +0100 (lun. 22 mars 2021) $)
 */
@RunWith(PowerMockRunner.class)
@PowerMockListener(FieldDefaulter.class)
@PowerMockRunnerDelegate(PodamBytelJUnit4ClassRunner.class)
@ContextConfiguration("classpath:BeansConnectorsTestMocks.xml")
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*", "javax.management.*" })
@PrepareForTest({ B2EConnector.class, PasswordDecrypter.class })
public final class B2EConnectorTest
{
  /**
   * bean Factory generation
   */
  private static PodamFactory __podam;

  /**
   * The current timestamp
   */
  private static LocalDateTime __now;

  /**
   * The object {@Code Tracabilite}
   */
  private static Tracabilite __tracabilite;

  /**
   * Phone number
   */
  private static String __phoneNumber;

  /**
   * Serial number
   */
  private static String __serialNumber;

  /**
   *
   */
  private static String __status;

  /**
   *
   */
  private static String __commentaire;

  /**
   *
   */
  private static String __noCompteCourt;

  /**
   *
   */
  private static String __type;

  /**
   *
   */
  private static String __domainIms;

  /**
   *
   */
  private static String __nomFqdn;

  /**
   *
   */
  private static String __impiPortVoix1;

  /**
   *
   */
  private static String __motDePassePortVoix1;

  /**
   *
   */
  private static String __telUriPortVoix1;

  /**
   *
   */
  private static String __impiPortVoix2;

  /**
   *
   */
  private static String __motDePassePortVoix2;

  /**
   *
   */
  private static String __telUriPortVoix2;

  /**
   * Initialize before all tests
   *
   * @throws Exception
   *           Exception to be thrown in case of failure
   */
  @BeforeClass
  public static void setUpBeforeClass() throws Exception
  {
    __podam = new PodamFactoryImpl();
    __podam.getStrategy().setMemoization(false);
    __podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());
    JavaTimeManufacturer.registerPodamFactory(__podam);

    __now = LocalDateTime.of(2016, 8, 25, 12, 0, 0, 0);

    __tracabilite = __podam.manufacturePojoWithFullData(Tracabilite.class);
    __phoneNumber = __podam.manufacturePojo(String.class);
    __serialNumber = __podam.manufacturePojo(String.class);
    __status = StatutLegacy.ACTIF.name();
    __commentaire = __podam.manufacturePojo(String.class);
    __noCompteCourt = __podam.manufacturePojo(String.class);
    __type = __podam.manufacturePojo(String.class);
    __now = __podam.manufacturePojo(LocalDateTime.class);
    __now = __podam.manufacturePojo(LocalDateTime.class);
    __domainIms = __podam.manufacturePojo(String.class);
    __nomFqdn = __podam.manufacturePojo(String.class);
    __impiPortVoix1 = __podam.manufacturePojo(String.class);
    __motDePassePortVoix1 = __podam.manufacturePojo(String.class);
    __telUriPortVoix1 = __podam.manufacturePojo(String.class);
    __impiPortVoix2 = __podam.manufacturePojo(String.class);
    __motDePassePortVoix2 = __podam.manufacturePojo(String.class);
    __telUriPortVoix2 = __podam.manufacturePojo(String.class);
  }

  /**
   * Connector to test
   */
  private B2EConnector _instance;

  /**
   * Exception has been thrown
   */
  private boolean _exception;

  /**
   *
   */
  @MockStrict
  DataSource _dataSource;

  /**
   *
   */
  @MockStrict
  Connection _connection;

  /**
   *
   */
  @MockStrict
  CallableStatement _callableStatement;

  /**
   * Test lireRessourceNoTelephone KO
   *
   * @throws Exception
   *           On errors
   */
  @Test
  public void lireServiceTechniqueEquipementModemTest_KO() throws Exception
  {
    ConnectorResponse<StEquipementLegacy, Nothing> actual = null;

    try
    {
      EasyMock.expect(_dataSource.getConnection()).andReturn(_connection);
      EasyMock.expect(_connection.prepareCall(B2EConnector.PKG_SPIRIT_LIRE_SERVICE_TECHNIQUE_EQUIPEMENT)).andReturn(_callableStatement);

      _callableStatement.setQueryTimeout(1000);
      EasyMock.expectLastCall();

      // Setup statement mock
      _callableStatement.setString(EasyMock.eq(1), EasyMock.eq(__serialNumber));
      EasyMock.expectLastCall();
      _callableStatement.registerOutParameter(2, Types.VARCHAR);
      EasyMock.expectLastCall();
      _callableStatement.registerOutParameter(3, Types.VARCHAR);
      EasyMock.expectLastCall();
      _callableStatement.registerOutParameter(4, Types.TIMESTAMP);
      EasyMock.expectLastCall();
      _callableStatement.registerOutParameter(5, Types.TIMESTAMP);
      EasyMock.expectLastCall();
      _callableStatement.registerOutParameter(6, Types.VARCHAR);
      EasyMock.expectLastCall();
      _callableStatement.registerOutParameter(7, Types.VARCHAR);
      EasyMock.expectLastCall();
      _callableStatement.registerOutParameter(8, Types.VARCHAR);
      EasyMock.expectLastCall();
      _callableStatement.registerOutParameter(9, Types.VARCHAR);
      EasyMock.expectLastCall();
      _callableStatement.registerOutParameter(10, Types.VARCHAR);
      EasyMock.expectLastCall();
      _callableStatement.registerOutParameter(11, Types.VARCHAR);
      EasyMock.expectLastCall();
      _callableStatement.registerOutParameter(12, Types.VARCHAR);
      EasyMock.expectLastCall();
      _callableStatement.registerOutParameter(13, Types.VARCHAR);
      EasyMock.expectLastCall();
      _callableStatement.registerOutParameter(14, Types.VARCHAR);
      EasyMock.expectLastCall();
      _callableStatement.registerOutParameter(15, Types.VARCHAR);
      EasyMock.expectLastCall();

      EasyMock.expect(_callableStatement.execute()).andThrow(new SQLException());

      _callableStatement.close();
      EasyMock.expectLastCall();
      _connection.close();
      EasyMock.expectLastCall();

      PowerMock.replayAll();

      actual = _instance.lireServiceTechniqueEquipementModem(__tracabilite, __serialNumber);
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertTrue(_exception);

      assertNull(actual);
    }
  }

  /**
   * Nominal test lireRessourceNoTelephone OK
   *
   * @throws Exception
   *           On errors
   */
  @Test
  public void lireServiceTechniqueEquipementModemTest_OK() throws Exception
  {
    ConnectorResponse<StEquipementLegacy, Nothing> actual = null;

    try
    {
      EasyMock.expect(_dataSource.getConnection()).andReturn(_connection);
      EasyMock.expect(_connection.prepareCall(B2EConnector.PKG_SPIRIT_LIRE_SERVICE_TECHNIQUE_EQUIPEMENT)).andReturn(_callableStatement);

      _callableStatement.setQueryTimeout(1000);
      EasyMock.expectLastCall();

      // Setup statement mock
      _callableStatement.setString(EasyMock.eq(1), EasyMock.eq(__serialNumber));
      EasyMock.expectLastCall();
      _callableStatement.registerOutParameter(2, Types.VARCHAR);
      EasyMock.expectLastCall();
      _callableStatement.registerOutParameter(3, Types.VARCHAR);
      EasyMock.expectLastCall();
      _callableStatement.registerOutParameter(4, Types.TIMESTAMP);
      EasyMock.expectLastCall();
      _callableStatement.registerOutParameter(5, Types.TIMESTAMP);
      EasyMock.expectLastCall();
      _callableStatement.registerOutParameter(6, Types.VARCHAR);
      EasyMock.expectLastCall();
      _callableStatement.registerOutParameter(7, Types.VARCHAR);
      EasyMock.expectLastCall();
      _callableStatement.registerOutParameter(8, Types.VARCHAR);
      EasyMock.expectLastCall();
      _callableStatement.registerOutParameter(9, Types.VARCHAR);
      EasyMock.expectLastCall();
      _callableStatement.registerOutParameter(10, Types.VARCHAR);
      EasyMock.expectLastCall();
      _callableStatement.registerOutParameter(11, Types.VARCHAR);
      EasyMock.expectLastCall();
      _callableStatement.registerOutParameter(12, Types.VARCHAR);
      EasyMock.expectLastCall();
      _callableStatement.registerOutParameter(13, Types.VARCHAR);
      EasyMock.expectLastCall();
      _callableStatement.registerOutParameter(14, Types.VARCHAR);
      EasyMock.expectLastCall();
      _callableStatement.registerOutParameter(15, Types.VARCHAR);
      EasyMock.expectLastCall();

      EasyMock.expect(_callableStatement.execute()).andReturn(true);

      EasyMock.expect(_callableStatement.getString(2)).andReturn(__commentaire);
      EasyMock.expect(_callableStatement.getString(3)).andReturn(__status);
      EasyMock.expect(_callableStatement.getTimestamp(4)).andReturn(new Timestamp(__now.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli())).times(2);
      EasyMock.expect(_callableStatement.getTimestamp(5)).andReturn(new Timestamp(__now.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli())).times(2);
      EasyMock.expect(_callableStatement.getString(6)).andReturn(__noCompteCourt);
      EasyMock.expect(_callableStatement.getString(7)).andReturn(__domainIms);
      EasyMock.expect(_callableStatement.getString(8)).andReturn(__nomFqdn);
      EasyMock.expect(_callableStatement.getString(9)).andReturn(__impiPortVoix1);
      EasyMock.expect(_callableStatement.getString(10)).andReturn(__motDePassePortVoix1);
      EasyMock.expect(_callableStatement.getString(11)).andReturn(__telUriPortVoix1);
      EasyMock.expect(_callableStatement.getString(12)).andReturn(__impiPortVoix2);
      EasyMock.expect(_callableStatement.getString(13)).andReturn(__motDePassePortVoix2);
      EasyMock.expect(_callableStatement.getString(14)).andReturn(__telUriPortVoix2);
      EasyMock.expect(_callableStatement.getString(15)).andReturn(__type);

      _callableStatement.close();
      EasyMock.expectLastCall();
      _connection.close();
      EasyMock.expectLastCall();

      PowerMock.replayAll();

      actual = _instance.lireServiceTechniqueEquipementModem(__tracabilite, __serialNumber);
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(actual);
      assertNotNull(actual.getResult());
      assertEquals(__status, actual.getResult().getStatut());
      assertEquals(__commentaire, actual.getResult().getCommentaire());
      assertEquals(__noCompteCourt, actual.getResult().getNoCompteCourt());
      assertEquals(__type, actual.getResult().getType());
      assertEquals(__now, actual.getResult().getDateCreation());
      assertEquals(__now, actual.getResult().getDateModification());
      assertEquals(__domainIms, actual.getResult().getDomaineIms());
      assertEquals(__nomFqdn, actual.getResult().getNomFqdn());
      assertEquals(__impiPortVoix1, actual.getResult().getImpiPortVoix1());
      assertEquals(__motDePassePortVoix1, actual.getResult().getMotDePasseportVoix1());
      assertEquals(__telUriPortVoix1, actual.getResult().getTelUriPortVoix1());
      assertEquals(__impiPortVoix2, actual.getResult().getImpiPortVoix2());
      assertEquals(__motDePassePortVoix2, actual.getResult().getMotDePasseportVoix2());
      assertEquals(__telUriPortVoix2, actual.getResult().getTelUriPortVoix2());
    }
  }

  /**
   ** Test load configuration without DB_CONNECTIONSTRING.
   */
  @Test
  public void loadConnectorConfigurationTest_KO1()
  {
    final Connector connector = new Connector();
    connector.setName("B2EConnector"); //$NON-NLS-1$
    List<Param> paramList = new ArrayList<>();

    Param param = new Param();
    param.setName(B2EConnector.ParameterName.DB_CONNECTIONSTRING.name());
    param.setValue(""); //$NON-NLS-1$
    paramList.add(param);

    connector.getParam().addAll(paramList);

    try
    {
      _instance.loadConnectorConfiguration(connector);
    }
    catch (final RavelException e)
    {
      assertEquals(ExceptionType.INVALID_CONFIGURATION, e.getExceptionType());
      assertEquals(ErrorCode.CNCTOR_00020, e.getErrorCode());
      assertEquals("Connector 'B2EConnector': The DB_CONNECTIONSTRING parameter is missing.", e.getMessage()); //$NON-NLS-1$
    }
  }

  /**
   ** Test load configuration without DB_USERNAME.
   */
  @Test
  public void loadConnectorConfigurationTest_KO2()
  {
    final Connector connector = new Connector();
    connector.setName("B2EConnector"); //$NON-NLS-1$

    List<Param> paramList = new ArrayList<>();

    Param param = new Param();
    param.setName(B2EConnector.ParameterName.DB_CONNECTIONSTRING.name());
    param.setValue("connectiongString"); //$NON-NLS-1$
    paramList.add(param);

    param = new Param();
    param.setName(B2EConnector.ParameterName.DB_USERNAME.name());
    param.setValue(""); //$NON-NLS-1$
    paramList.add(param);

    connector.getParam().addAll(paramList);

    try
    {
      _instance.loadConnectorConfiguration(connector);
    }
    catch (final RavelException e)
    {
      assertEquals(ExceptionType.INVALID_CONFIGURATION, e.getExceptionType());
      assertEquals(ErrorCode.CNCTOR_00020, e.getErrorCode());
      assertEquals("Connector 'B2EConnector': The DB_USERNAME parameter is missing.", e.getMessage()); //$NON-NLS-1$
    }
  }

  /**
   ** Test load configuration without DB_PASSWORD.
   */
  @Test
  public void loadConnectorConfigurationTest_KO3()
  {
    final Connector connector = new Connector();
    connector.setName("B2EConnector"); //$NON-NLS-1$

    List<Param> paramList = new ArrayList<>();

    Param param = new Param();
    param.setName(B2EConnector.ParameterName.DB_CONNECTIONSTRING.name());
    param.setValue("connectiongString"); //$NON-NLS-1$
    paramList.add(param);

    param = new Param();
    param.setName(B2EConnector.ParameterName.DB_USERNAME.name());
    param.setValue("TEST"); //$NON-NLS-1$
    paramList.add(param);

    param = new Param();
    param.setName(B2EConnector.ParameterName.DB_PASSWORD.name());
    param.setValue(""); //$NON-NLS-1$
    paramList.add(param);

    connector.getParam().addAll(paramList);

    try
    {
      _instance.loadConnectorConfiguration(connector);
    }
    catch (final RavelException e)
    {
      assertEquals(ExceptionType.INVALID_CONFIGURATION, e.getExceptionType());
      assertEquals(ErrorCode.CNCTOR_00020, e.getErrorCode());
      assertEquals("Connector 'B2EConnector': The DB_PASSWORD parameter is missing.", e.getMessage()); //$NON-NLS-1$

    }
  }

  /**
   * Test load configuration with all parameters OK
   *
   * @throws RavelException
   *           On error
   */
  @Test
  public void loadConnectorConfigurationTest_OK() throws RavelException
  {
    final Connector connector = new Connector();
    List<Param> paramList = new ArrayList<>();

    Param param = new Param();
    param.setName(B2EConnector.ParameterName.DB_CONNECTIONSTRING.name());
    param.setValue("connectiongString"); //$NON-NLS-1$
    paramList.add(param);

    param = new Param();
    param.setName(B2EConnector.ParameterName.DB_USERNAME.name());
    param.setValue("TEST"); //$NON-NLS-1$
    paramList.add(param);

    param = new Param();
    param.setName(B2EConnector.ParameterName.DB_PASSWORD.name());
    param.setValue("EmoEOmWbGT/DKV9ZjcD/3A=="); //$NON-NLS-1$
    paramList.add(param);

    param = new Param();
    param.setName(B2EConnector.ParameterName.POOLSIZE.name());
    param.setValue(String.valueOf(20));
    paramList.add(param);

    param = new Param();
    param.setName(B2EConnector.ParameterName.CONNECT_TIMEOUT_SEC.name());
    param.setValue(String.valueOf(5));
    paramList.add(param);

    param = new Param();
    param.setName(B2EConnector.ParameterName.READ_TIMEOUT_SEC.name());
    param.setValue(String.valueOf(30));
    paramList.add(param);

    param = new Param();
    param.setName(B2EConnector.ParameterName.QUERY_TIMEOUT_SEC.name());
    param.setValue(String.valueOf(600));
    paramList.add(param);

    connector.getParam().addAll(paramList);

    _instance.loadConnectorConfiguration(connector);
  }

  /**
   * @throws Exception
   *           On errors
   */
  @Before
  public void setUp() throws Exception
  {
    _exception = false;

    PowerMock.mockStaticStrict(PasswordDecrypter.class);

    _instance = new B2EConnector();
    Whitebox.setInternalState(_instance, "_datasource", _dataSource); //$NON-NLS-1$
    Whitebox.setInternalState(_instance, "_queryTimeoutSec", 1000); //$NON-NLS-1$
  }
}
