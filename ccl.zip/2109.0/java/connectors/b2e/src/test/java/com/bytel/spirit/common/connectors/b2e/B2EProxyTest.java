/*******************************************************************************
 * $Id: B2EProxyTest.java 35860 2020-05-05 12:54:40Z jjoly $
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.b2e;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;

import java.sql.SQLException;
import java.text.MessageFormat;
import java.time.LocalDateTime;

import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PowerMockListener;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.testlisteners.FieldDefaulter;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.modules.junit4.PowerMockRunnerDelegate;
import org.powermock.reflect.Whitebox;
import org.springframework.test.context.ContextConfiguration;

import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.probes.AvgDoubleCollectorItem;
import com.bytel.ravel.common.probes.AvgFlowPerSecondCollector;
import com.bytel.ravel.common.test.podam.JavaTimeManufacturer;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.test.podam.PodamBytelJUnit4ClassRunner;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.services.connector.ConnectorManager;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.connectors.b2e.structs.StEquipementLegacy;
import com.bytel.spirit.common.connectors.b2e.structs.StatutLegacy;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author jjoly
 * @version ($Revision: 35860 $ $Date: 2020-05-05 14:54:40 +0200 (mar. 05 mai 2020) $)
 */
@RunWith(PowerMockRunner.class)
@PowerMockListener(FieldDefaulter.class)
@PowerMockRunnerDelegate(PodamBytelJUnit4ClassRunner.class)
@ContextConfiguration("classpath:BeansConnectorsTestMocks.xml")
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*", "javax.management.*" })
@PrepareForTest({ B2EProxy.class, ConnectorManager.class })
public final class B2EProxyTest
{
  /**
   * bean Factory generation
   */
  private static PodamFactory __podam;

  /**
   * The object {@Code Tracabilite}
   */
  private static Tracabilite __tracabilite;

  /**
   * Serial number
   */
  private static String __serialNumber;

  /**
   * Initialize before all tests
   *
   * @throws Exception
   *           Exception to be thrown in case of failure
   */
  @BeforeClass
  public static void setUpBeforeClass() throws Exception
  {
    __podam = new PodamFactoryImpl();
    __podam.getStrategy().setMemoization(false);
    __podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());
    JavaTimeManufacturer.registerPodamFactory(__podam);

    __tracabilite = __podam.manufacturePojoWithFullData(Tracabilite.class);
    __serialNumber = __podam.manufacturePojo(String.class);
  }

  /**
   * The mock object {@code AvgFlowPerSecondCollector}
   */
  @MockStrict
  AvgFlowPerSecondCollector _avgCallCounterMock;

  /**
   * The mock object {@code AvgDoubleCollectorItem}
   */
  @MockStrict
  AvgDoubleCollectorItem _avgExecTimeMock;

  /**
   * The mock object {@code ConnectorManager}
   */
  @MockStrict
  private ConnectorManager _connectorManagerMock;

  /**
   * The mock object {@code IB2EConnector}
   */
  @MockStrict
  private IB2EConnector _B2EConnectorMock;

  /**
   * Object {@code AbstractConnectorCallTask} to evaluate
   */
  private B2EProxy _instance;

  /**
   * Exception has been thrown
   */
  private boolean _exception;

  /**
   * Initialization of tests
   *
   * @throws Exception
   *           Exception to be thrown in case of failure
   */
  @Before
  public void setUp() throws Exception
  {
    _exception = false;
    _instance = B2EProxy.getInstance();

    PowerMock.resetAll();

    PowerMock.mockStaticStrict(LocalDateTime.class);
    PowerMock.mockStaticStrict(ConnectorManager.class);
  }

  /**
   * Test method for {@link com.bytel.spirit.common.connectors.b2e.B2EProxy#getInstance()}.
   */
  @Test
  public void testB2EProxy_000()
  {
    PowerMock.replayAll();

    Whitebox.setInternalState(_instance, "_avg_lireServiceTechniqueEquipementModem_call_counter", _avgCallCounterMock); //$NON-NLS-1$
    Whitebox.setInternalState(_instance, "_avg_lireServiceTechniqueEquipementModem_ExecTime", _avgExecTimeMock); //$NON-NLS-1$

    PowerMock.verifyAll();

    // Assertions
    assertNotNull(_instance);
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.common.connectors.b2e.B2EProxy#lireServiceTechniqueEquipementModem(java.lang.String)}
   * .<br/>
   *
   * <b>Input:</b>All input are valid but exception appear when connector is search<br/>
   * <b>Expected:</b>KO<br/>
   *
   * @throws Exception
   *           On errors
   */
  @Test
  public void testB2EProxy_001() throws Exception
  {
    final ConnectorResponse<StEquipementLegacy, Nothing> expected = new ConnectorResponse<>(new StEquipementLegacy(__serialNumber, StatutLegacy.ECHEC.name(), "Echec Consultation ST  Legacy EQUIPEMENT : Connector B2EConnector is unknown."), null); //$NON-NLS-1$
    ConnectorResponse<StEquipementLegacy, Nothing> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock);
      EasyMock.expect(_connectorManagerMock.getConnector(IB2EConnector.BEAN_ID)).andThrow(new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.MGRCTR_00002, MessageFormat.format("Connector {0} is unknown.", IB2EConnector.BEAN_ID))).once(); //$NON-NLS-1$

      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock);
      EasyMock.expect(_connectorManagerMock.getConnector(IB2EConnector.BEAN_ID)).andReturn(_B2EConnectorMock).once();
      EasyMock.expect(_B2EConnectorMock.isEnabled()).andReturn(false);

      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock);
      _connectorManagerMock.enable(IB2EConnector.BEAN_ID);
      EasyMock.expectLastCall().andVoid();

      PowerMock.replayAll();

      actual = _instance.lireServiceTechniqueEquipementModem(__tracabilite, __serialNumber);
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected.getResult(), actual.getResult());
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.common.connectors.b2e.B2EProxy#lireServiceTechniqueEquipementModem(java.lang.String)}
   * .<br/>
   *
   * <b>Input:</b>All input are valid but exception appear during SQL execution<br/>
   * <b>Expected:</b>KO<br/>
   *
   * @throws Exception
   *           On errors
   */
  @Test
  public void testB2EProxy_002() throws Exception
  {
    final ConnectorResponse<StEquipementLegacy, Nothing> expected = new ConnectorResponse<>(new StEquipementLegacy(__serialNumber, StatutLegacy.ECHEC.name(), "Echec Consultation ST  Legacy EQUIPEMENT : "), null); //$NON-NLS-1$
    ConnectorResponse<StEquipementLegacy, Nothing> actual = null;

    try
    {
      Whitebox.setInternalState(_instance, "_avg_lireServiceTechniqueEquipementModem_call_counter", _avgCallCounterMock); //$NON-NLS-1$
      Whitebox.setInternalState(_instance, "_avg_lireServiceTechniqueEquipementModem_ExecTime", _avgExecTimeMock); //$NON-NLS-1$

      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock);
      EasyMock.expect(_connectorManagerMock.getConnector(IB2EConnector.BEAN_ID)).andReturn(_B2EConnectorMock).once();

      _avgCallCounterMock.measure();
      EasyMock.expectLastCall().andVoid().once();

      EasyMock.expect(_B2EConnectorMock.lireServiceTechniqueEquipementModem(__tracabilite, __serialNumber)).andThrow(new RavelException(ExceptionType.PFS_EXCEPTION, ErrorCode.CNCTOR_00010, StringConstants.EMPTY_STRING, IB2EConnector.BEAN_ID, new SQLException(StringConstants.EMPTY_STRING)));

      _avgExecTimeMock.updateAvgValue(EasyMock.geq(0L));
      EasyMock.expectLastCall().andVoid().once();

      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock);
      EasyMock.expect(_connectorManagerMock.getConnector(IB2EConnector.BEAN_ID)).andReturn(_B2EConnectorMock).once();
      EasyMock.expect(_B2EConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      actual = _instance.lireServiceTechniqueEquipementModem(__tracabilite, __serialNumber);
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // Assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.common.connectors.b2e.B2EProxy#lireServiceTechniqueEquipementModem(java.lang.String)}
   * .<br/>
   *
   * <b>Input:</b>All input are valid<br/>
   * <b>Expected:</b>Nominal behavior<br/>
   *
   * @throws Exception
   *           On errors
   */
  @Test
  public void testB2EProxy_003() throws Exception
  {
    final StEquipementLegacy st = __podam.manufacturePojoWithFullData(StEquipementLegacy.class);
    final ConnectorResponse<StEquipementLegacy, Nothing> expected = new ConnectorResponse<>(st, null);
    ConnectorResponse<StEquipementLegacy, Nothing> actual = null;

    try
    {
      Whitebox.setInternalState(_instance, "_avg_lireServiceTechniqueEquipementModem_call_counter", _avgCallCounterMock); //$NON-NLS-1$
      Whitebox.setInternalState(_instance, "_avg_lireServiceTechniqueEquipementModem_ExecTime", _avgExecTimeMock); //$NON-NLS-1$

      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock);
      EasyMock.expect(_connectorManagerMock.getConnector(IB2EConnector.BEAN_ID)).andReturn(_B2EConnectorMock).once();

      _avgCallCounterMock.measure();
      EasyMock.expectLastCall().andVoid().once();

      EasyMock.expect(_B2EConnectorMock.lireServiceTechniqueEquipementModem(__tracabilite, __serialNumber)).andReturn(new ConnectorResponse<>(st, null));

      _avgExecTimeMock.updateAvgValue(EasyMock.geq(0L));
      EasyMock.expectLastCall().andVoid().once();

      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock);
      EasyMock.expect(_connectorManagerMock.getConnector(IB2EConnector.BEAN_ID)).andReturn(_B2EConnectorMock).once();
      EasyMock.expect(_B2EConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      actual = _instance.lireServiceTechniqueEquipementModem(__tracabilite, __serialNumber);
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // Assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }
}
