/*******************************************************************************
* $Id: StTelephonieLegacy.java 20220 2019-04-11 16:19:42Z jjoly $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.b2e.structs;

import static java.util.Objects.isNull;
import static java.util.Objects.requireNonNull;

import java.time.LocalDateTime;

/**
 *
 * @author jjoly
 * @version ($Revision: 20220 $ $Date: 2019-04-11 18:19:42 +0200 (jeu. 11 avril 2019) $)
 */
public final class StTelephonieLegacy
{
  /**
   * Check status ECHEC madndatory
   *
   * @param argument_p
   *          This argument is mandatory and Must be equals to ECHEC
   * @return The input argument
   */
  public static String requireEchec(final String argument_p)
  {
    if (isNull(argument_p))
    {
      throw new NullPointerException();
    }

    if (!StatutLegacy.ECHEC.name().equals(argument_p))
    {
      throw new IllegalArgumentException();
    }

    return argument_p;
  }

  /**
   * Check status ECHEC not allowed
   *
   * @param argument_p
   *          This argument is mandatory and Must be equals to ECHEC
   * @return The input argument
   */
  public static String requireNonEchec(final String argument_p)
  {
    if (isNull(argument_p))
    {
      throw new NullPointerException();
    }

    if (StatutLegacy.ECHEC.name().equals(argument_p))
    {
      throw new IllegalArgumentException();
    }

    return argument_p;
  }

  /**
   * Numéro de téléphone
   */
  private String _noTelephone;

  /**
   * Statut du Service Technique
   */
  private String _statut;

  /**
   * Commentaire associé au statut ECHEC
   */
  private String _commentaire;

  /**
   * Type de l'usage du service _téléphonie
   */
  private String _typeUsage;

  /**
   * Numéro de compte Pfi court
   */
  private String _noCompteCourt;

  /**
   * Identité du Compte IMS
   */
  private String _idCompteIms;

  /**
   * Identité Ims privé Fixe
   */
  private String _impiFixe;

  /**
   * Identité publique du Compte IMS de type Sip Uri
   */
  private String _sipUri;

  /**
   * Adresse IP utilisée dans le provisionning CLF
   */
  private String _adresseIpClf;

  /**
   * Mot de passe de d'authentification du compte IMS sur le cœur IMS
   */
  private String _motDePasseIms;

  /**
   * Nom de l'équipement FQDN desservant les lignes VOIX de l'abonné
   */
  private String _nomFQDN;

  /**
   * Date de création de l'objet
   */
  private LocalDateTime _dateCreation;

  /**
   * Date de dernière modification de l'objet
   */
  private LocalDateTime _dateModification;

  /**
   * Constructeur
   *
   * @param noTelephone_p
   *          Numéro de téléphone
   * @param statut_p
   *          Statut du Service Technique
   * @param commentaire_p
   *          Commentaire associé au statut ECHEC
   * @throws NullPointerException
   *           if statut_p is null
   * @throws IllegalArgumentException
   *           if statut_p is not equals to ECHEC
   */
  public StTelephonieLegacy(final String noTelephone_p, final String statut_p, final String commentaire_p)
  {
    super();

    _noTelephone = requireNonNull(noTelephone_p);
    _statut = requireEchec(statut_p);
    _commentaire = commentaire_p;
    _dateCreation = null;
    _dateModification = null;
    _typeUsage = null;
    _noCompteCourt = null;
    _idCompteIms = null;
    _impiFixe = null;
    _sipUri = null;
    _adresseIpClf = null;
    _motDePasseIms = null;
    _nomFQDN = null;
  }

  /**
   * Constructeur
   *
   * @param noTelephone_p
   *          Numéro de téléphone
   * @param statut_p
   *          Statut du Service Technique
   * @param commentaire_p
   *          Commentaire associé au statut ECHEC
   * @param dateCreation_p
   *          Date de création de l'objet
   * @param dateModification_p
   *          Date de dernière modification de l'objet
   * @param noCompteCourt_p
   *          Numéro de compte Pfi court
   * @param typeUsage_p
   *          Type de l'usage du service téléphonie
   * @param idCompteIms_p
   *          Identifiant du Compte IMS
   * @param impiFixe_p
   *          Identité Ims privé Fixe
   * @param sipUri_p
   *          Identité publique du Compte IMS de type Sip Uri.
   * @param adresseIpClf_p
   *          Adresse IP utilisée dans le provisionning CLF
   * @param motDePasseIms_p
   *          Mot de passe de d'authentification du compte IMS sur le cœur IMS
   * @param nomFQDN_p
   *          Nom de l'equiepement FQDN desservant les lignes VOIX de l'abonné
   * @throws NullPointerException
   *           if statut_p is null
   * @throws IllegalArgumentException
   *           if statut_p is equals to ECHEC
   */
  public StTelephonieLegacy(final String noTelephone_p, final String statut_p, final String commentaire_p, final LocalDateTime dateCreation_p, final LocalDateTime dateModification_p, final String noCompteCourt_p, final String typeUsage_p, final String idCompteIms_p, final String impiFixe_p, final String sipUri_p, final String adresseIpClf_p, final String motDePasseIms_p, final String nomFQDN_p)
  {
    super();

    _noTelephone = requireNonNull(noTelephone_p);
    _statut = requireNonEchec(statut_p);
    _commentaire = commentaire_p;
    _dateCreation = dateCreation_p;
    _dateModification = dateModification_p;
    _typeUsage = typeUsage_p;
    _noCompteCourt = noCompteCourt_p;
    _idCompteIms = idCompteIms_p;
    _impiFixe = impiFixe_p;
    _sipUri = sipUri_p;
    _adresseIpClf = adresseIpClf_p;
    _motDePasseIms = motDePasseIms_p;
    _nomFQDN = nomFQDN_p;
  }

  @Override
  public boolean equals(final Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    final StTelephonieLegacy other = StTelephonieLegacy.class.cast(obj);
    if (_adresseIpClf == null)
    {
      if (other._adresseIpClf != null)
      {
        return false;
      }
    }
    else if (!_adresseIpClf.equals(other._adresseIpClf))
    {
      return false;
    }
    if (_commentaire == null)
    {
      if (other._commentaire != null)
      {
        return false;
      }
    }
    else if (!_commentaire.equals(other._commentaire))
    {
      return false;
    }
    if (_dateCreation == null)
    {
      if (other._dateCreation != null)
      {
        return false;
      }
    }
    else if (!_dateCreation.equals(other._dateCreation))
    {
      return false;
    }
    if (_dateModification == null)
    {
      if (other._dateModification != null)
      {
        return false;
      }
    }
    else if (!_dateModification.equals(other._dateModification))
    {
      return false;
    }
    if (_idCompteIms == null)
    {
      if (other._idCompteIms != null)
      {
        return false;
      }
    }
    else if (!_idCompteIms.equals(other._idCompteIms))
    {
      return false;
    }
    if (_impiFixe == null)
    {
      if (other._impiFixe != null)
      {
        return false;
      }
    }
    else if (!_impiFixe.equals(other._impiFixe))
    {
      return false;
    }
    if (_motDePasseIms == null)
    {
      if (other._motDePasseIms != null)
      {
        return false;
      }
    }
    else if (!_motDePasseIms.equals(other._motDePasseIms))
    {
      return false;
    }
    if (_noCompteCourt == null)
    {
      if (other._noCompteCourt != null)
      {
        return false;
      }
    }
    else if (!_noCompteCourt.equals(other._noCompteCourt))
    {
      return false;
    }
    if (_noTelephone == null)
    {
      if (other._noTelephone != null)
      {
        return false;
      }
    }
    else if (!_noTelephone.equals(other._noTelephone))
    {
      return false;
    }
    if (_nomFQDN == null)
    {
      if (other._nomFQDN != null)
      {
        return false;
      }
    }
    else if (!_nomFQDN.equals(other._nomFQDN))
    {
      return false;
    }
    if (_sipUri == null)
    {
      if (other._sipUri != null)
      {
        return false;
      }
    }
    else if (!_sipUri.equals(other._sipUri))
    {
      return false;
    }
    if (_statut == null)
    {
      if (other._statut != null)
      {
        return false;
      }
    }
    else if (!_statut.equals(other._statut))
    {
      return false;
    }
    if (_typeUsage == null)
    {
      if (other._typeUsage != null)
      {
        return false;
      }
    }
    else if (!_typeUsage.equals(other._typeUsage))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the adresseIpClf
   */
  public final String getAdresseIpClf()
  {
    return _adresseIpClf;
  }

  /**
   * @return the commentaire
   */
  public String getCommentaire()
  {
    return _commentaire;
  }

  /**
   * @return the dateCreation
   */
  public LocalDateTime getDateCreation()
  {
    return _dateCreation;
  }

  /**
   * @return the dateModification
   */
  public LocalDateTime getDateModification()
  {
    return _dateModification;
  }

  /**
   * @return the idCompteIms
   */
  public String getIdCompteIms()
  {
    return _idCompteIms;
  }

  /**
   * @return the impiFixe
   */
  public String getImpiFixe()
  {
    return _impiFixe;
  }

  /**
   * @return the motDePasseIms
   */
  public final String getMotDePasseIms()
  {
    return _motDePasseIms;
  }

  /**
   * @return the noCompteCourt
   */
  public String getNoCompteCourt()
  {
    return _noCompteCourt;
  }

  /**
   * @return the nomFQDN
   */
  public String getNomFQDN()
  {
    return _nomFQDN;
  }

  /**
   * @return the noTelephone
   */
  public final String getNoTelephone()
  {
    return _noTelephone;
  }

  /**
   * @return the sipUri
   */
  public String getSipUri()
  {
    return _sipUri;
  }

  /**
   * @return the statut
   */
  public String getStatut()
  {
    return _statut;
  }

  /**
   * @return the typeUsage
   */
  public String getTypeUsage()
  {
    return _typeUsage;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_adresseIpClf == null) ? 0 : _adresseIpClf.hashCode());
    result = (prime * result) + ((_commentaire == null) ? 0 : _commentaire.hashCode());
    result = (prime * result) + ((_dateCreation == null) ? 0 : _dateCreation.hashCode());
    result = (prime * result) + ((_dateModification == null) ? 0 : _dateModification.hashCode());
    result = (prime * result) + ((_idCompteIms == null) ? 0 : _idCompteIms.hashCode());
    result = (prime * result) + ((_impiFixe == null) ? 0 : _impiFixe.hashCode());
    result = (prime * result) + ((_motDePasseIms == null) ? 0 : _motDePasseIms.hashCode());
    result = (prime * result) + ((_noCompteCourt == null) ? 0 : _noCompteCourt.hashCode());
    result = (prime * result) + ((_noTelephone == null) ? 0 : _noTelephone.hashCode());
    result = (prime * result) + ((_nomFQDN == null) ? 0 : _nomFQDN.hashCode());
    result = (prime * result) + ((_sipUri == null) ? 0 : _sipUri.hashCode());
    result = (prime * result) + ((_statut == null) ? 0 : _statut.hashCode());
    result = (prime * result) + ((_typeUsage == null) ? 0 : _typeUsage.hashCode());
    return result;
  }

  /**
   * @param adresseIpClf_p
   *          the adresseIpClf to set
   */
  public void setAdresseIpClf(final String adresseIpClf_p)
  {
    _adresseIpClf = adresseIpClf_p;
  }

  /**
   * @param commentaire_p
   *          the commentaire to set
   */
  public void setCommentaire(final String commentaire_p)
  {
    _commentaire = commentaire_p;
  }

  /**
   * @param dateCreation_p
   *          the dateCreation to set
   */
  public void setDateCreation(final LocalDateTime dateCreation_p)
  {
    _dateCreation = dateCreation_p;
  }

  /**
   * @param dateModification_p
   *          the dateModification to set
   */
  public void setDateModification(final LocalDateTime dateModification_p)
  {
    _dateModification = dateModification_p;
  }

  /**
   * @param idCompteIms_p
   *          the idCompteIms to set
   */
  public void setIdCompteIms(final String idCompteIms_p)
  {
    _idCompteIms = idCompteIms_p;
  }

  /**
   * @param impiFixe_p
   *          the impiFixe to set
   */
  public void setImpiFixe(final String impiFixe_p)
  {
    _impiFixe = impiFixe_p;
  }

  /**
   * @param motDePasseIms_p
   *          the motDePasseIms to set
   */
  public void setMotDePasseIms(final String motDePasseIms_p)
  {
    _motDePasseIms = motDePasseIms_p;
  }

  /**
   * @param noCompteCourt_p
   *          the noCompteCourt to set
   */
  public void setNoCompteCourt(final String noCompteCourt_p)
  {
    _noCompteCourt = noCompteCourt_p;
  }

  /**
   * @param nomFQDN_p
   *          the nomFQDN to set
   */
  public void setNomFQDN(final String nomFQDN_p)
  {
    _nomFQDN = nomFQDN_p;
  }

  /**
   * @param noTelephone_p
   *          the noTelephone to set
   */
  public void setNoTelephone(final String noTelephone_p)
  {
    _noTelephone = noTelephone_p;
  }

  /**
   * @param sipUri_p
   *          the sipUri to set
   */
  public void setSipUri(final String sipUri_p)
  {
    _sipUri = sipUri_p;
  }

  /**
   * @param statut_p
   *          the statut to set
   */
  public void setStatut(final String statut_p)
  {
    _statut = statut_p;
  }

  /**
   * @param typeUsage_p
   *          the typeUsage to set
   */
  public void setTypeUsage(final String typeUsage_p)
  {
    _typeUsage = typeUsage_p;
  }

  @Override
  public String toString()
  {
    final StringBuilder builder = new StringBuilder();
    builder.append("StTelephonieLegacy [_noTelephone="); //$NON-NLS-1$
    builder.append(_noTelephone);
    builder.append(", _statut="); //$NON-NLS-1$
    builder.append(_statut);
    builder.append(", _commentaire="); //$NON-NLS-1$
    builder.append(_commentaire);
    builder.append(", _typeUsage="); //$NON-NLS-1$
    builder.append(_typeUsage);
    builder.append(", _noCompteCourt="); //$NON-NLS-1$
    builder.append(_noCompteCourt);
    builder.append(", _idCompteIms="); //$NON-NLS-1$
    builder.append(_idCompteIms);
    builder.append(", _impiFixe="); //$NON-NLS-1$
    builder.append(_impiFixe);
    builder.append(", _sipUri="); //$NON-NLS-1$
    builder.append(_sipUri);
    builder.append(", _adresseIpClf="); //$NON-NLS-1$
    builder.append(_adresseIpClf);
    builder.append(", _motDePasseIms="); //$NON-NLS-1$
    builder.append(_motDePasseIms);
    builder.append(", _nomFQDN="); //$NON-NLS-1$
    builder.append(_nomFQDN);
    builder.append(", _dateCreation="); //$NON-NLS-1$
    builder.append(_dateCreation);
    builder.append(", _dateModification="); //$NON-NLS-1$
    builder.append(_dateModification);
    builder.append(", getAdresseIpClf()="); //$NON-NLS-1$
    builder.append(getAdresseIpClf());
    builder.append(", getCommentaire()="); //$NON-NLS-1$
    builder.append(getCommentaire());
    builder.append(", getDateCreation()="); //$NON-NLS-1$
    builder.append(getDateCreation());
    builder.append(", getDateModification()="); //$NON-NLS-1$
    builder.append(getDateModification());
    builder.append(", getIdCompteIms()="); //$NON-NLS-1$
    builder.append(getIdCompteIms());
    builder.append(", getImpiFixe()="); //$NON-NLS-1$
    builder.append(getImpiFixe());
    builder.append(", getMotDePasseIms()="); //$NON-NLS-1$
    builder.append(getMotDePasseIms());
    builder.append(", getNoCompteCourt()="); //$NON-NLS-1$
    builder.append(getNoCompteCourt());
    builder.append(", getNomFQDN()="); //$NON-NLS-1$
    builder.append(getNomFQDN());
    builder.append(", getNoTelephone()="); //$NON-NLS-1$
    builder.append(getNoTelephone());
    builder.append(", getSipUri()="); //$NON-NLS-1$
    builder.append(getSipUri());
    builder.append(", getStatut()="); //$NON-NLS-1$
    builder.append(getStatut());
    builder.append(", getTypeUsage()="); //$NON-NLS-1$
    builder.append(getTypeUsage());
    builder.append(", hashCode()="); //$NON-NLS-1$
    builder.append(hashCode());
    builder.append(", getClass()="); //$NON-NLS-1$
    builder.append(getClass());
    builder.append(", toString()="); //$NON-NLS-1$
    builder.append(super.toString());
    builder.append("]"); //$NON-NLS-1$
    return builder.toString();
  }
}
