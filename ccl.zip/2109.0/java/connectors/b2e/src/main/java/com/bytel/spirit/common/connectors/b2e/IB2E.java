/*******************************************************************************
 * $Id: IB2E.java 35860 2020-05-05 12:54:40Z jjoly $
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.b2e;

import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.connectors.b2e.structs.StEquipementLegacy;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

/**
 * @author jjoly
 * @version ($Revision: 35860 $ $Date: 2020-05-05 14:54:40 +0200 (mar. 05 mai 2020) $)
 */
public interface IB2E
{
  /**
   * Permettant de recuperer une ressource avec son numero de série sur la chaine Legacy.
   *
   * @param tracabilite_p
   *          The object {@Code Tracabilite}
   * @param numeroSerie_p
   *          The serial number
   * @return ConnectorResponse<ServiceTechniqueTelephonieLegacy, Retour>
   * @throws RavelException
   *           On error
   */
  public ConnectorResponse<StEquipementLegacy, Nothing> lireServiceTechniqueEquipementModem(final Tracabilite tracabilite_p, final String numeroSerie_p) throws RavelException;
}
