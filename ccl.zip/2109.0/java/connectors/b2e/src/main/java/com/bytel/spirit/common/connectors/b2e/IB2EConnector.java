/*******************************************************************************
 * $Id: IB2EConnector.java 19760 2019-04-04 16:07:52Z jjoly $
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.b2e;

import com.bytel.ravel.services.connector.IConnector;
import com.bytel.spirit.common.connectors.b2e.IB2E;

/**
 * Interface of IB2EConnector that defines the BEAN_ID
 *
 * @author jjoly
 * @version ($Revision: 19760 $ $Date: 2019-04-04 18:07:52 +0200 (jeu. 04 avril 2019) $)
 */
public interface IB2EConnector extends IB2E, IConnector
{
  /**
   * The id to retrieve the connector.
   */
  public String BEAN_ID = "B2EConnector"; //$NON-NLS-1$
}
