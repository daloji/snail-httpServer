/*******************************************************************************
* $Id: Messages.java 19760 2019-04-04 16:07:52Z jjoly $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.b2e;

import java.util.MissingResourceException;
import java.util.ResourceBundle;

/**
 *
 * @author jjoly
 * @version ($Revision: 19760 $ $Date: 2019-04-04 18:07:52 +0200 (jeu. 04 avril 2019) $)
 */
public final class Messages
{
  /**
   *
   */
  private static final String BUNDLE_NAME = "com.bytel.spirit.common.connectors.b2e.messages"; //$NON-NLS-1$

  /**
   *
   */
  private static final ResourceBundle RESOURCE_BUNDLE = ResourceBundle.getBundle(BUNDLE_NAME);

  /**
   * @param key
   * @return
   */
  public static String getString(final String key)
  {
    try
    {
      return RESOURCE_BUNDLE.getString(key);
    }
    catch (final MissingResourceException e)
    {
      return '!' + key + '!';
    }
  }

  /**
   * Defautl constructor
   */
  private Messages()
  {
    // Nothing to do
  }
}
