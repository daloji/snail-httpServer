/*******************************************************************************
* $Id: StEquipementLegacy.java 25287 2019-08-12 15:02:53Z fbarnabe $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.b2e.structs;

import static java.util.Objects.isNull;
import static java.util.Objects.requireNonNull;

import java.time.LocalDateTime;

/**
 *
 * @author pescudei
 * @version ($Revision: 25287 $ $Date: 2019-08-12 17:02:53 +0200 (lun. 12 août 2019) $)
 */
public final class StEquipementLegacy
{
  /**
   * Check status ECHEC madndatory
   *
   * @param argument_p
   *          This argument is mandatory and Must be equals to ECHEC
   * @return The input argument
   */
  public static String requireEchec(final String argument_p)
  {
    if (isNull(argument_p))
    {
      throw new NullPointerException();
    }

    if (!StatutLegacy.ECHEC.name().equals(argument_p))
    {
      throw new IllegalArgumentException();
    }

    return argument_p;
  }

  /**
   * Numero Serie Equipement
   */
  private String _numeroSerie;

  /**
   * Statut Provisionning
   */
  private String _statut;

  /**
   * Commentaire
   */
  private String _commentaire;

  /**
   * Numéro de compte Pfi court
   */
  private String _noCompteCourt;

  /**
   * Type
   */
  private String _type;

  /**
   * Date creation
   */
  private LocalDateTime _dateCreation;

  /**
   * Date modification
   */
  private LocalDateTime _dateModification;

  /**
   * DomainIms
   */
  private String _domaineIms;

  /**
   * nomFQDN
   */
  private String _nomFqdn;

  /**
   * ImpiPortVoix1
   */
  private String _impiPortVoix1;

  /**
   * MotDePasseportVoix1
   */
  private String _motDePasseportVoix1;

  /**
   * TelUriPortVoix1
   */
  private String _telUriPortVoix1;

  /**
   * DoaminIms
   */
  private String _impiPortVoix2;

  /**
   * MotDePasseportVoix2
   */
  private String _motDePasseportVoix2;

  /**
   * TelUriPortVoix1
   */
  private String _telUriPortVoix2;

  /**
   * Constructoeur
   *
   * @param numeroSerie_p
   *          Numéro de téléphone
   * @param statut_p
   *          Statut Provisionning
   * @param commentaire_p
   *          Commentaire associé au statut ECHEC
   * @throws NullPointerException
   *           if statut_p is null
   * @throws IllegalArgumentException
   *           if statut_p is not equals to ECHEC
   */
  public StEquipementLegacy(final String numeroSerie_p, final String statut_p, final String commentaire_p)
  {
    super();

    _numeroSerie = requireNonNull(numeroSerie_p);
    _statut = requireEchec(statut_p);
    _commentaire = commentaire_p;
    _noCompteCourt = null;
    _type = null;
    _dateCreation = null;
    _dateModification = null;
    _domaineIms = null;
    _nomFqdn = null;
    _impiPortVoix1 = null;
    _motDePasseportVoix1 = null;
    _telUriPortVoix1 = null;
    _impiPortVoix2 = null;
    _motDePasseportVoix2 = null;
    _telUriPortVoix2 = null;
  }

  /**
   * Constructoeur
   *
   * @param numeroSerie_p
   *          Numéro de téléphone
   * @param statut_p
   *          Statut Provisionning
   * @param type_p
   *          Type servie Technique Equipement
   * @param dateCreation_p
   *          Date de creation
   * @param dateModification_p
   *          Date de modification
   * @param commentaire_p
   *          Commentaire associé au statut ECHEC
   * @param noCompteCourt_p
   * @param domaineIms_p
   * @param nomFqdn_p
   * @param impiPortVoix1_p
   * @param motDePasseportVoix1_p
   * @param telUriPortVoix1_p
   * @param impiPortVoix2_p
   * @param motDePasseportVoix2_p
   * @param telUriPortVoix2_p
   * @throws NullPointerException
   *           if statut_p is null
   * @throws IllegalArgumentException
   *           if statut_p is equals to ECHEC
   */
  public StEquipementLegacy(final String numeroSerie_p, final String statut_p, final String commentaire_p, final String noCompteCourt_p, final String type_p, final LocalDateTime dateCreation_p, final LocalDateTime dateModification_p, final String domaineIms_p, final String nomFqdn_p, final String impiPortVoix1_p, final String motDePasseportVoix1_p, final String telUriPortVoix1_p, final String impiPortVoix2_p, final String motDePasseportVoix2_p, final String telUriPortVoix2_p)
  {
    super();

    _numeroSerie = requireNonNull(numeroSerie_p);
    _statut = statut_p;
    _commentaire = commentaire_p;
    _noCompteCourt = noCompteCourt_p;
    _type = type_p;
    _dateCreation = dateCreation_p;
    _dateModification = dateModification_p;
    _domaineIms = domaineIms_p;
    _nomFqdn = nomFqdn_p;
    _impiPortVoix1 = impiPortVoix1_p;
    _motDePasseportVoix1 = motDePasseportVoix1_p;
    _telUriPortVoix1 = telUriPortVoix1_p;
    _impiPortVoix2 = impiPortVoix2_p;
    _motDePasseportVoix2 = motDePasseportVoix2_p;
    _telUriPortVoix2 = telUriPortVoix2_p;
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    final StEquipementLegacy other = StEquipementLegacy.class.cast(obj);
    if (_commentaire == null)
    {
      if (other._commentaire != null)
      {
        return false;
      }
    }
    else if (!_commentaire.equals(other._commentaire))
    {
      return false;
    }
    if (_dateCreation == null)
    {
      if (other._dateCreation != null)
      {
        return false;
      }
    }
    else if (!_dateCreation.equals(other._dateCreation))
    {
      return false;
    }
    if (_dateModification == null)
    {
      if (other._dateModification != null)
      {
        return false;
      }
    }
    else if (!_dateModification.equals(other._dateModification))
    {
      return false;
    }
    if (_domaineIms == null)
    {
      if (other._domaineIms != null)
      {
        return false;
      }
    }
    else if (!_domaineIms.equals(other._domaineIms))
    {
      return false;
    }
    if (_impiPortVoix1 == null)
    {
      if (other._impiPortVoix1 != null)
      {
        return false;
      }
    }
    else if (!_impiPortVoix1.equals(other._impiPortVoix1))
    {
      return false;
    }
    if (_impiPortVoix2 == null)
    {
      if (other._impiPortVoix2 != null)
      {
        return false;
      }
    }
    else if (!_impiPortVoix2.equals(other._impiPortVoix2))
    {
      return false;
    }
    if (_motDePasseportVoix1 == null)
    {
      if (other._motDePasseportVoix1 != null)
      {
        return false;
      }
    }
    else if (!_motDePasseportVoix1.equals(other._motDePasseportVoix1))
    {
      return false;
    }
    if (_motDePasseportVoix2 == null)
    {
      if (other._motDePasseportVoix2 != null)
      {
        return false;
      }
    }
    else if (!_motDePasseportVoix2.equals(other._motDePasseportVoix2))
    {
      return false;
    }
    if (_noCompteCourt == null)
    {
      if (other._noCompteCourt != null)
      {
        return false;
      }
    }
    else if (!_noCompteCourt.equals(other._noCompteCourt))
    {
      return false;
    }
    if (_nomFqdn == null)
    {
      if (other._nomFqdn != null)
      {
        return false;
      }
    }
    else if (!_nomFqdn.equals(other._nomFqdn))
    {
      return false;
    }
    if (_numeroSerie == null)
    {
      if (other._numeroSerie != null)
      {
        return false;
      }
    }
    else if (!_numeroSerie.equals(other._numeroSerie))
    {
      return false;
    }
    if (_statut == null)
    {
      if (other._statut != null)
      {
        return false;
      }
    }
    else if (!_statut.equals(other._statut))
    {
      return false;
    }
    if (_telUriPortVoix1 == null)
    {
      if (other._telUriPortVoix1 != null)
      {
        return false;
      }
    }
    else if (!_telUriPortVoix1.equals(other._telUriPortVoix1))
    {
      return false;
    }
    if (_telUriPortVoix2 == null)
    {
      if (other._telUriPortVoix2 != null)
      {
        return false;
      }
    }
    else if (!_telUriPortVoix2.equals(other._telUriPortVoix2))
    {
      return false;
    }
    if (_type == null)
    {
      if (other._type != null)
      {
        return false;
      }
    }
    else if (!_type.equals(other._type))
    {
      return false;
    }
    return true;
  }

  /**
   * @return value of _commentaire
   */
  public final String getCommentaire()
  {
    return _commentaire;
  }

  /**
   * @return value of _dateCreation
   */
  public final LocalDateTime getDateCreation()
  {
    return _dateCreation;
  }

  /**
   * @return value of _dateModification
   */
  public final LocalDateTime getDateModification()
  {
    return _dateModification;
  }

  /**
   * @return the domaineIms
   */
  public final String getDomaineIms()
  {
    return _domaineIms;
  }

  /**
   * @return the impiPortVoix1
   */
  public final String getImpiPortVoix1()
  {
    return _impiPortVoix1;
  }

  /**
   * @return the impiPortVoix2
   */
  public final String getImpiPortVoix2()
  {
    return _impiPortVoix2;
  }

  /**
   * @return the motDePasseportVoix1
   */
  public final String getMotDePasseportVoix1()
  {
    return _motDePasseportVoix1;
  }

  /**
   * @return the motDePasseportVoix2
   */
  public final String getMotDePasseportVoix2()
  {
    return _motDePasseportVoix2;
  }

  /**
   * @return the noCompteCourt
   */
  public final String getNoCompteCourt()
  {
    return _noCompteCourt;
  }

  /**
   * @return the nomFqdn
   */
  public final String getNomFqdn()
  {
    return _nomFqdn;
  }

  /**
   * @return the numeroSerie
   */
  public final String getNumeroSerie()
  {
    return _numeroSerie;
  }

  /**
   * @return value of _statut
   */
  public final String getStatut()
  {
    return _statut;
  }

  /**
   * @return the telUriPortVoix1
   */
  public final String getTelUriPortVoix1()
  {
    return _telUriPortVoix1;
  }

  /**
   * @return the telUriPortVoix2
   */
  public final String getTelUriPortVoix2()
  {
    return _telUriPortVoix2;
  }

  /**
   * @return value of _type
   */
  public final String getType()
  {
    return _type;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_commentaire == null) ? 0 : _commentaire.hashCode());
    result = (prime * result) + ((_dateCreation == null) ? 0 : _dateCreation.hashCode());
    result = (prime * result) + ((_dateModification == null) ? 0 : _dateModification.hashCode());
    result = (prime * result) + ((_domaineIms == null) ? 0 : _domaineIms.hashCode());
    result = (prime * result) + ((_impiPortVoix1 == null) ? 0 : _impiPortVoix1.hashCode());
    result = (prime * result) + ((_impiPortVoix2 == null) ? 0 : _impiPortVoix2.hashCode());
    result = (prime * result) + ((_motDePasseportVoix1 == null) ? 0 : _motDePasseportVoix1.hashCode());
    result = (prime * result) + ((_motDePasseportVoix2 == null) ? 0 : _motDePasseportVoix2.hashCode());
    result = (prime * result) + ((_noCompteCourt == null) ? 0 : _noCompteCourt.hashCode());
    result = (prime * result) + ((_nomFqdn == null) ? 0 : _nomFqdn.hashCode());
    result = (prime * result) + ((_numeroSerie == null) ? 0 : _numeroSerie.hashCode());
    result = (prime * result) + ((_statut == null) ? 0 : _statut.hashCode());
    result = (prime * result) + ((_telUriPortVoix1 == null) ? 0 : _telUriPortVoix1.hashCode());
    result = (prime * result) + ((_telUriPortVoix2 == null) ? 0 : _telUriPortVoix2.hashCode());
    result = (prime * result) + ((_type == null) ? 0 : _type.hashCode());
    return result;
  }

  /**
   * @param commentaire_p
   *          The _commentaire to set.
   */
  public void setCommentaire(final String commentaire_p)
  {
    _commentaire = commentaire_p;
  }

  /**
   * @param dateCreation_p
   *          The _dateCreation to set.
   */
  public void setDateCreation(final LocalDateTime dateCreation_p)
  {
    _dateCreation = dateCreation_p;
  }

  /**
   * @param dateModification_p
   *          The _dateModification to set.
   */
  public void setDateModification(final LocalDateTime dateModification_p)
  {
    _dateModification = dateModification_p;
  }

  /**
   * @param domaineIms_p
   *          the domaineIms to set
   */
  public void setDomaineIms(final String domaineIms_p)
  {
    _domaineIms = domaineIms_p;
  }

  /**
   * @param impiPortVoix1_p
   *          the impiPortVoix1 to set
   */
  public void setImpiPortVoix1(final String impiPortVoix1_p)
  {
    _impiPortVoix1 = impiPortVoix1_p;
  }

  /**
   * @param impiPortVoix2_p
   *          the impiPortVoix2 to set
   */
  public void setImpiPortVoix2(final String impiPortVoix2_p)
  {
    _impiPortVoix2 = impiPortVoix2_p;
  }

  /**
   * @param motDePasseportVoix1_p
   *          the motDePasseportVoix1 to set
   */
  public void setMotDePasseportVoix1(final String motDePasseportVoix1_p)
  {
    _motDePasseportVoix1 = motDePasseportVoix1_p;
  }

  /**
   * @param motDePasseportVoix2_p
   *          the motDePasseportVoix2 to set
   */
  public void setMotDePasseportVoix2(final String motDePasseportVoix2_p)
  {
    _motDePasseportVoix2 = motDePasseportVoix2_p;
  }

  /**
   * @param noCompteCourt_p
   *          the noCompteCourt to set
   */
  public void setNoCompteCourt(final String noCompteCourt_p)
  {
    _noCompteCourt = noCompteCourt_p;
  }

  /**
   * @param nomFqdn_p
   *          the proxyIms to set
   */
  public void setNomFqdn(final String nomFqdn_p)
  {
    _nomFqdn = nomFqdn_p;
  }

  /**
   * @param numeroSerie_p
   *          the numeroSerie to set
   */
  public void setNumeroSerie(final String numeroSerie_p)
  {
    _numeroSerie = numeroSerie_p;
  }

  /**
   * @param statut_p
   *          The _statut to set.
   */
  public void setStatut(final String statut_p)
  {
    _statut = statut_p;
  }

  /**
   * @param telUriPortVoix1_p
   *          the telUriPortVoix1 to set
   */
  public void setTelUriPortVoix1(final String telUriPortVoix1_p)
  {
    _telUriPortVoix1 = telUriPortVoix1_p;
  }

  /**
   * @param telUriPortVoix2_p
   *          the telUriPortVoix2 to set
   */
  public void setTelUriPortVoix2(final String telUriPortVoix2_p)
  {
    _telUriPortVoix2 = telUriPortVoix2_p;
  }

  /**
   * @param type_p
   *          The _type to set.
   */
  public void setType(final String type_p)
  {
    _type = type_p;
  }

  @Override
  public String toString()
  {
    final StringBuilder builder = new StringBuilder();
    builder.append("StEquipementLegacy [_numeroSerie="); //$NON-NLS-1$
    builder.append(_numeroSerie);
    builder.append(", _statut="); //$NON-NLS-1$
    builder.append(_statut);
    builder.append(", _commentaire="); //$NON-NLS-1$
    builder.append(_commentaire);
    builder.append(", _noCompteCourt="); //$NON-NLS-1$
    builder.append(_noCompteCourt);
    builder.append(", _type="); //$NON-NLS-1$
    builder.append(_type);
    builder.append(", _dateCreation="); //$NON-NLS-1$
    builder.append(_dateCreation);
    builder.append(", _dateModification="); //$NON-NLS-1$
    builder.append(_dateModification);
    builder.append(", _domaineIms="); //$NON-NLS-1$
    builder.append(_domaineIms);
    builder.append(", _nomFqdn="); //$NON-NLS-1$
    builder.append(_nomFqdn);
    builder.append(", _impiPortVoix1="); //$NON-NLS-1$
    builder.append(_impiPortVoix1);
    builder.append(", _motDePasseportVoix1="); //$NON-NLS-1$
    builder.append(_motDePasseportVoix1);
    builder.append(", _telUriPortVoix1="); //$NON-NLS-1$
    builder.append(_telUriPortVoix1);
    builder.append(", _impiPortVoix2="); //$NON-NLS-1$
    builder.append(_impiPortVoix2);
    builder.append(", _motDePasseportVoix2="); //$NON-NLS-1$
    builder.append(_motDePasseportVoix2);
    builder.append(", _telUriPortVoix2="); //$NON-NLS-1$
    builder.append(_telUriPortVoix2);
    builder.append("]"); //$NON-NLS-1$
    return builder.toString();
  }

}
