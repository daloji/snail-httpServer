/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.b2e.structs;

/**
 * @author jpais
 * @version ($Revision$ $Date$)
 */
public enum StatutLegacy
{
  /**
   * Statut ACTIF
   */
  ACTIF,

  /**
   * Statu INACTIF
   */
  INACTIF,

  /**
   * Statut INDETERMINE
   */
  INDETERMINE,

  /**
   * Statut ECHEC
   */
  ECHEC;
}
