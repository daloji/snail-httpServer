/*******************************************************************************
 * $Id: B2EProxy.java 35860 2020-05-05 12:54:40Z jjoly $
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.b2e;

import java.time.Duration;
import java.time.Instant;

import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.probes.AvgDoubleCollectorItem;
import com.bytel.ravel.common.probes.AvgFlowPerSecondCollector;
import com.bytel.ravel.common.probes.RavelProbeConfigurationManager;
import com.bytel.ravel.services.connector.BaseProxy;
import com.bytel.ravel.services.connector.ConnectorExecution;
import com.bytel.ravel.services.connector.ConnectorManager;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.connectors.b2e.structs.StEquipementLegacy;
import com.bytel.spirit.common.connectors.b2e.structs.StatutLegacy;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

/**
 * @author jpais
 * @version ($Revision: 35860 $ $Date: 2020-05-05 14:54:40 +0200 (mar. 05 mai 2020) $)
 */
public final class B2EProxy extends BaseProxy implements IB2E
{
  /**
   * Proxy instance.
   */
  private static B2EProxy _instance = new B2EProxy();

  /**
   * @return The proxy instance.
   */
  public static B2EProxy getInstance()
  {
    return _instance;
  }

  /**
   * For probe to count the amount of call to the lireServiceTechniqueEquipementModem operation
   */
  AvgFlowPerSecondCollector _avg_lireServiceTechniqueEquipementModem_call_counter;

  /**
   * For probe to count the execution time of call to the lireServiceTechniqueEquipementModem operation
   */
  AvgDoubleCollectorItem _avg_lireServiceTechniqueEquipementModem_ExecTime;

  /**
   * Constructor
   */
  private B2EProxy()
  {
    _avg_lireServiceTechniqueEquipementModem_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_lireServiceTechniqueEquipementModem_call_counter", B2EProxy.class.getSimpleName()); //$NON-NLS-1$
    _avg_lireServiceTechniqueEquipementModem_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_lireServiceTechniqueEquipementModem_ExecTime", B2EProxy.class.getSimpleName()); //$NON-NLS-1$
  }

  @Override
  public ConnectorResponse<StEquipementLegacy, Nothing> lireServiceTechniqueEquipementModem(Tracabilite tracabilite_p, String numeroSerie_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<StEquipementLegacy, Nothing>>(IB2EConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<StEquipementLegacy, Nothing> run() throws RavelException
      {
        IB2EConnector connector = null;

        try
        {
          connector = IB2EConnector.class.cast(ConnectorManager.getInstance().getConnector(_connectorId));
        }
        catch (final RavelException e)
        {
          return new ConnectorResponse<>(new StEquipementLegacy(numeroSerie_p, StatutLegacy.ECHEC.name(), new StringBuilder().append("Echec Consultation ST  Legacy EQUIPEMENT : ").append(e.getMessage()).toString()), null); //$NON-NLS-1$
        }

        _avg_lireServiceTechniqueEquipementModem_call_counter.measure();

        final Instant startTime = Instant.now();

        try
        {
          return connector.lireServiceTechniqueEquipementModem(tracabilite_p, numeroSerie_p);
        }
        catch (final RavelException e)
        {
          return new ConnectorResponse<>(new StEquipementLegacy(numeroSerie_p, StatutLegacy.ECHEC.name(), new StringBuilder().append("Echec Consultation ST  Legacy EQUIPEMENT : ").append(e.getMessage()).toString()), null); //$NON-NLS-1$
        }
        finally
        {
          final Instant endTime = Instant.now();

          _avg_lireServiceTechniqueEquipementModem_ExecTime.updateAvgValue(Duration.between(startTime, endTime).toMillis());
        }
      }
    });
  }
}
