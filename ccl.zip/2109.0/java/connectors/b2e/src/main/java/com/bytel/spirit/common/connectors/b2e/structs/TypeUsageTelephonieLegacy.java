/*******************************************************************************
* $Id: TypeUsageTelephonieLegacy.java 19760 2019-04-04 16:07:52Z jjoly $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.b2e.structs;

/**
 *
 * @author jjoly
 * @version ($Revision: 19760 $ $Date: 2019-04-04 18:07:52 +0200 (jeu. 04 avril 2019) $)
 */
public enum TypeUsageTelephonieLegacy
{
  /**
   * VOIX
   */
  VOIX,

  /**
   * FAX
   */
  FAX;
}
