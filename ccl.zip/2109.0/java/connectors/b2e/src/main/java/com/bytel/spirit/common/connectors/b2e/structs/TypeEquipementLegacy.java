/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.b2e.structs;

/**
 * @author jpais
 * @version ($Revision$ $Date$)
 */
public enum TypeEquipementLegacy
{
  /**
   * Type of equipment MODEM
   */
  MODEM;
}
