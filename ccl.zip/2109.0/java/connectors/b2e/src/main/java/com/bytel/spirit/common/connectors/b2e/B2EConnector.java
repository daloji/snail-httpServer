/*******************************************************************************
 * $Id: B2EConnector.java 49485 2021-03-22 15:28:13Z ykulczak $
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.b2e;

import static org.apache.commons.lang3.StringUtils.isBlank;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.text.MessageFormat;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.utils.DateTimeTools;
import com.bytel.ravel.services.conf.connector.generated.Connector;
import com.bytel.ravel.services.connector.AbstractDBConnector;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.connectors.b2e.structs.StEquipementLegacy;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

/**
 * @author jjoly
 * @version ($Revision: 49485 $ $Date: 2021-03-22 16:28:13 +0100 (lun. 22 mars 2021) $)
 */
public final class B2EConnector extends AbstractDBConnector implements IB2EConnector
{
  /**
   * Defines all mandatory parameters read from config file.
   *
   * @author jpais
   * @version ($Revision: 49485 $ $Date: 2021-03-22 16:28:13 +0100 (lun. 22 mars 2021) $)
   */
  protected enum ParameterName
  {
    /**
     * The URL parameter
     */
    DB_CONNECTIONSTRING,

    /**
     * The LOGIN parameter
     */
    DB_USERNAME,

    /**
     * The PASSWORD parameter
     */
    DB_PASSWORD,

    /**
     * The POOLSIZE parameter
     */
    POOLSIZE,

    /**
     * Connect timeout in sec
     */
    CONNECT_TIMEOUT_SEC,

    /**
     * read timeout in sec
     */
    READ_TIMEOUT_SEC,

    /**
     * query timeout in sec
     */
    QUERY_TIMEOUT_SEC;
  }

  /**
   * The constant for MESSAGE_MISSING_CONFIGURATION_PARAMETER
   */
  private static final String MESSAGE_MISSING_CONFIGURATION_PARAMETER = Messages.getString("B2EConnector.MissingConfigurationParameter"); //$NON-NLS-1$

  /**
   * The constant for MESSAGE_INVALID_CONFIGURATION_PARAMETER
   */
  private static final String MESSAGE_INVALID_CONFIGURATION_PARAMETER = Messages.getString("B2EConnector.InvalidConfigurationParameter"); //$NON-NLS-1$

  /**
   * datasource connection properties
   */
  private static final String CONNECTION_PROPERTIES = "oracle.net.CONNECT_TIMEOUT=%d;oracle.jdbc.ReadTimeout=%d"; //$NON-NLS-1$

  /**
   * The constant for PKG_SPIRIT_LIRE_SERVICE_TECHNIQUE_EQUIPEMENT
   */
  protected static final String PKG_SPIRIT_LIRE_SERVICE_TECHNIQUE_EQUIPEMENT = "{call PKG_SPIRIT.lireStEquipementModem (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}"; //$NON-NLS-1$

  /**
   * Parameters read from configuration.
   */
  private Map<ParameterName, String> _parameters = new HashMap<>(0);

  /**
   * Connect timeout in seconds
   */
  private Integer _connectTimeoutMilliSec;

  /**
   * Read timeout in seconds
   */
  private Integer _readTimeoutMilliSec;

  /**
   * Query timeout in seconds
   */
  private Integer _queryTimeoutSec;

  @Override
  public ConnectorResponse<StEquipementLegacy, Nothing> lireServiceTechniqueEquipementModem(final Tracabilite tracabilite_p, final String numeroSerie_p) throws RavelException
  {
    // lock
    _dsReadLock.lock();

    try (Connection con = _datasource.getConnection(); //
        CallableStatement cs = con.prepareCall(PKG_SPIRIT_LIRE_SERVICE_TECHNIQUE_EQUIPEMENT))
    {
      // Set timeout
      cs.setQueryTimeout(_queryTimeoutSec);

      // Input parameters
      cs.setString(1, numeroSerie_p);

      // Output parameters
      cs.registerOutParameter(2, Types.VARCHAR);
      cs.registerOutParameter(3, Types.VARCHAR);
      cs.registerOutParameter(4, Types.TIMESTAMP);
      cs.registerOutParameter(5, Types.TIMESTAMP);
      cs.registerOutParameter(6, Types.VARCHAR);
      cs.registerOutParameter(7, Types.VARCHAR);
      cs.registerOutParameter(8, Types.VARCHAR);
      cs.registerOutParameter(9, Types.VARCHAR);
      cs.registerOutParameter(10, Types.VARCHAR);
      cs.registerOutParameter(11, Types.VARCHAR);
      cs.registerOutParameter(12, Types.VARCHAR);
      cs.registerOutParameter(13, Types.VARCHAR);
      cs.registerOutParameter(14, Types.VARCHAR);
      cs.registerOutParameter(15, Types.VARCHAR);

      // Execute the stored procedure
      cs.execute();

      // Get output parameters
      final String commentaire = cs.getString(2);
      final String status = cs.getString(3);
      final LocalDateTime dateCreation = null == cs.getTimestamp(4) ? null : DateTimeTools.ofEpochMilli(cs.getTimestamp(4).getTime());
      final LocalDateTime dateModification = null == cs.getTimestamp(5) ? null : DateTimeTools.ofEpochMilli(cs.getTimestamp(5).getTime());
      final String noCompteCourt = cs.getString(6);
      final String domainIms = cs.getString(7);
      final String nomFqdn = cs.getString(8);
      final String impiPortVoix1 = cs.getString(9);
      final String motDePassePortVoix1 = cs.getString(10);
      final String telUriPortVoix1 = cs.getString(11);
      final String impiPortVoix2 = cs.getString(12);
      final String motDePassePortVoix2 = cs.getString(13);
      final String telUriPortVoix2 = cs.getString(14);
      final String type = cs.getString(15);

      return new ConnectorResponse<>(new StEquipementLegacy(numeroSerie_p, status, commentaire, noCompteCourt, type, dateCreation, dateModification, domainIms, nomFqdn, impiPortVoix1, motDePassePortVoix1, telUriPortVoix1, impiPortVoix2, motDePassePortVoix2, telUriPortVoix2), null);
    }
    catch (final SQLException exception)
    {
      throw buildTechnicalException(exception, tracabilite_p, "lireStEquipementModem"); //$NON-NLS-1$
    }
    finally
    {
      // unlock
      _dsReadLock.unlock();
    }
  }

  @Override
  public void loadConnectorConfiguration(final Connector connector_p) throws RavelException
  {
    // Read parameters.
    _name = connector_p.getName();
    _enabled = connector_p.isEnabled();

    // Get parameters
    connector_p.getParam().forEach(p -> _parameters.put(ParameterName.valueOf(p.getName().toUpperCase()), p.getValue()));

    // Check parameters

    // Get DB_CONNECTIONSTRING
    final String connectionString = _parameters.get(ParameterName.DB_CONNECTIONSTRING);
    if (isBlank(connectionString))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, _name, ParameterName.DB_CONNECTIONSTRING.toString()));
    }

    // Get DB_USERNAME
    final String dbUserName = _parameters.get(ParameterName.DB_USERNAME);
    if (isBlank(dbUserName))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, _name, ParameterName.DB_USERNAME.toString()));
    }

    // Get DB_PASSWORD
    final String dbPassword = _parameters.get(ParameterName.DB_PASSWORD);
    if (isBlank(dbPassword))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, _name, ParameterName.DB_PASSWORD.toString()));
    }

    // Get POOLSIZE
    final String poolSize = _parameters.get(ParameterName.POOLSIZE);

    // Get CONNECT_TIMEOUT_SEC
    final String connectTimeoutSec = _parameters.get(ParameterName.CONNECT_TIMEOUT_SEC);
    if (isBlank(connectTimeoutSec))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, _name, ParameterName.CONNECT_TIMEOUT_SEC.toString()));
    }
    try
    {
      _connectTimeoutMilliSec = 1000 * Integer.parseInt(connectTimeoutSec);
    }
    catch (final NumberFormatException e)
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00021, MessageFormat.format(MESSAGE_INVALID_CONFIGURATION_PARAMETER, _name, ParameterName.CONNECT_TIMEOUT_SEC.toString()));
    }

    // Get READ_TIMEOUT_SEC
    final String readTimeoutSec = _parameters.get(ParameterName.READ_TIMEOUT_SEC);
    if (isBlank(readTimeoutSec))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, _name, ParameterName.READ_TIMEOUT_SEC.toString()));
    }
    try
    {
      _readTimeoutMilliSec = 1000 * Integer.parseInt(readTimeoutSec);
    }
    catch (final NumberFormatException e)
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00021, MessageFormat.format(MESSAGE_INVALID_CONFIGURATION_PARAMETER, _name, ParameterName.READ_TIMEOUT_SEC.toString()));
    }

    // Get QUERY_TIMEOUT_SEC
    final String queryTimeoutSec = _parameters.get(ParameterName.QUERY_TIMEOUT_SEC);
    if (isBlank(queryTimeoutSec))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, _name, ParameterName.QUERY_TIMEOUT_SEC.toString()));
    }
    try
    {
      _queryTimeoutSec = Integer.parseInt(queryTimeoutSec);
    }
    catch (final NumberFormatException e)
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00021, MessageFormat.format(MESSAGE_INVALID_CONFIGURATION_PARAMETER, _name, ParameterName.QUERY_TIMEOUT_SEC.toString()));
    }

    // Create data source
    createDataSource(connectionString, dbUserName, dbPassword, poolSize, DatabaseType.ORACLE);
    _datasource.setConnectionProperties(String.format(CONNECTION_PROPERTIES, _connectTimeoutMilliSec, _readTimeoutMilliSec));
  }

  /**
   * Build a log entry and throws an {@link RavelException} for a technical problem.
   *
   * @param exc_p
   *          The {@link Exception} raised
   * @param tracabilite_p
   *          The traçabilite
   * @param method_p
   *          The method name in which the fault was raised.
   * @return RavelException The technical exception.
   */
  private RavelException buildTechnicalException(Exception exc_p, Tracabilite tracabilite_p, String method_p)
  {
    String message = MessageFormat.format(Messages.getString("B2EConnector.TechnicalExceptionMessage"), method_p, exc_p.getClass().getSimpleName(), exc_p.getMessage()); //$NON-NLS-1$
    RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, exc_p));
    return new RavelException(ExceptionType.DATABASE_ERROR, ErrorCode.CNCTOR_00010, message, IB2EConnector.BEAN_ID, exc_p);
  }
}
