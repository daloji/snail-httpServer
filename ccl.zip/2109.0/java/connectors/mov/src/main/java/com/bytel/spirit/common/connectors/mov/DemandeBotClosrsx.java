/*******************************************************************************
* $Id: DemandeBotClosrsx.java 33005 2016-11-15 11:21:01Z lmerces $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.mov;

/**
 * Stores information retrieved from the stored procedure P_007_CONS_DEMAND_BOT_CLOSRSX
 *
 * @author fcabral
 * @version ($Revision: 33005 $ $Date: 2016-11-15 12:21:01 +0100 (mar., 15 nov. 2016) $)
 */
public class DemandeBotClosrsx
{
  /**
   * Field for Demande
   */
  private long _demande;

  /**
   * Field for IMEI
   */
  private String _imei;

  /**
   * Field for CodeDemandeur
   */
  private String _codeDemandeur;

  /**
   * Field for FlgTAC
   */
  private String _flagTac;

  /**
   * Field for CodeMotif
   */
  private String _codeMotif;

  /**
   * Field for Mouvement
   */
  private String _mouvement;

  /**
   * Field for CodeMombreExt
   */
  private String _codeMembreExt;

  /**
   * Field for DescMotif
   */
  private String _descMotif;

  /**
   * Field for CodeGie
   */
  private String _codeGie;

  /**
   * @return the codeDemandeur
   */
  public String getCodeDemandeur()
  {
    return _codeDemandeur;
  }

  /**
   * @return the codeGie
   */
  public String getCodeGie()
  {
    return _codeGie;
  }

  /**
   * @return the codeMembreExt
   */
  public String getCodeMembreExt()
  {
    return _codeMembreExt;
  }

  /**
   * @return the codeMotif
   */
  public String getCodeMotif()
  {
    return _codeMotif;
  }

  /**
   * @return the demande
   */
  public long getDemande()
  {
    return _demande;
  }

  /**
   * @return the descMotif
   */
  public String getDescMotif()
  {
    return _descMotif;
  }

  /**
   * @return the flagTac
   */
  public String getFlagTac()
  {
    return _flagTac;
  }

  /**
   * @return the imei
   */
  public String getImei()
  {
    return _imei;
  }

  /**
   * @return the mouvement
   */
  public String getMouvement()
  {
    return _mouvement;
  }

  /**
   * @param codeDemandeur_p
   *          the codeDemandeur to set
   */
  public void setCodeDemandeur(String codeDemandeur_p)
  {
    _codeDemandeur = codeDemandeur_p;
  }

  /**
   * @param codeGie_p
   *          the codeGie to set
   */
  public void setCodeGie(String codeGie_p)
  {
    _codeGie = codeGie_p;
  }

  /**
   * @param codeMembreExt_p
   *          the codeMembreExt to set
   */
  public void setCodeMembreExt(String codeMembreExt_p)
  {
    _codeMembreExt = codeMembreExt_p;
  }

  /**
   * @param codeMotif_p
   *          the codeMotif to set
   */
  public void setCodeMotif(String codeMotif_p)
  {
    _codeMotif = codeMotif_p;
  }

  /**
   * @param demande_p
   *          the demande to set
   */
  public void setDemande(long demande_p)
  {
    _demande = demande_p;
  }

  /**
   * @param descMotif_p
   *          the descMotif to set
   */
  public void setDescMotif(String descMotif_p)
  {
    _descMotif = descMotif_p;
  }

  /**
   * @param flagTac_p
   *          the flagTac to set
   */
  public void setFlagTac(String flagTac_p)
  {
    _flagTac = flagTac_p;
  }

  /**
   * @param imei_p
   *          the imei to set
   */
  public void setImei(String imei_p)
  {
    _imei = imei_p;
  }

  /**
   * @param mouvement_p
   *          the mouvement to set
   */
  public void setMouvement(String mouvement_p)
  {
    _mouvement = mouvement_p;
  }

}
