/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.mov;

/**
 *
 * @author lmerces
 * @version ($Revision$ $Date$)
 */
public enum CodeMembre
{
  /**
   * BOT
   */
  BOT,

  /**
   * FTM
   */
  FTM,

  /**
   * SFR
   */
  SFR;
}
