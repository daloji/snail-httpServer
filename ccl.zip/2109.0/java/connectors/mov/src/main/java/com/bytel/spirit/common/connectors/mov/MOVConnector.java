/*******************************************************************************
 * $Id: MOVConnector.java 33877 2017-01-25 17:27:24Z lmerces $
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.mov;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLRecoverableException;
import java.sql.SQLTimeoutException;
import java.sql.Timestamp;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.tomcat.jdbc.pool.PoolExhaustedException;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.conf.generated.Param;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionTools;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.DateTimeTools;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.services.conf.connector.generated.Connector;
import com.bytel.ravel.services.connector.AbstractDBConnector;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

import oracle.jdbc.OracleTypes;

/**
 *
 * @author $Author: lmerces $
 * @version ($Revision$ $Date: 2017-01-25 18:27:24 +0100 (mer., 25 janv. 2017) $)
 */
public class MOVConnector extends AbstractDBConnector implements IMOVConnector
{
  /**
   * Defines all mandatory parameters read from configuration file.
   *
   * @author $Author: lmerces $
   * @version ($Revision$ $Date: 2017-01-25 18:27:24 +0100 (mer., 25 janv. 2017) $)
   */
  private enum ParameterName
  {
    /**
     * The URL parameter.
     */
    DB_CONNECTIONSTRING,
    /**
     * The PASSWORD parameter.
     */
    DB_PASSWORD,
    /**
     * The LOGIN parameter.
     */
    DB_USERNAME,
    /**
     * The POOLSIZE parameter.
     */
    POOLSIZE,

    /**
     * Connect timeout in sec
     */
    CONNECT_TIMEOUT_SEC,

    /**
     * read timeout in sec
     */
    READ_TIMEOUT_SEC
  }

  /**
   *
   */
  private static final String CURSORX = "cursorx"; //$NON-NLS-1$

  /**
   *
   */
  private static final String MOV_CONNECTOR_ERREUR_MOV_TIMEOUT_SUR_NON_REPONSE = "MOVConnector.ERREUR_MOV_TIMEOUT_SUR_NON_REPONSE"; //$NON-NLS-1$

  /**
   *
   */
  private static final String MOV_CONNECTOR_ERREUR_MOV_TIMEOUT_CONNEXION = "MOVConnector.ERREUR_MOV_TIMEOUT_CONNEXION"; //$NON-NLS-1$

  /**
   *
   */
  private static final String MOV_CONNECTOR_ERREUR_GDR_AUCUNE_SESSION = "MOVConnector.ERREUR_GDR_AUCUNE_SESSION"; //$NON-NLS-1$

  /**
   *
   */
  private static final String CALL_MOV_PS = "{call %s(?,?,?,?,?,?) }"; //$NON-NLS-1$

  /**
   *
   */
  private static final String RETOUR2 = "RETOUR"; //$NON-NLS-1$

  /**
   *
   */
  private static final String MOV_CONNECTOR_ERREUR_MOV_AUCUNE_SESSION = "MOVConnector.ERREUR_MOV_AUCUNE_SESSION"; //$NON-NLS-1$

  /**
   *
   */
  private static final String LOG_ERREUR = "LOG_ERREUR"; //$NON-NLS-1$

  /**
   *
   */
  private static final String IMEI = "IMEI:"; //$NON-NLS-1$

  /**
   *
   */
  private static final String ERREUR2 = "ERREUR"; //$NON-NLS-1$

  /**
   *
   */
  private static final String DEMANDE = "Demande: "; //$NON-NLS-1$

  /**
   *
   */
  private static final String CODE_MOTIF2 = "CODE MOTIF:"; //$NON-NLS-1$

  /**
   *
   */
  private static final String CODE_MEMBRE_P = "CODE_MEMBRE_P"; //$NON-NLS-1$

  /**
   *
   */
  private static final String CODE_MEMBRE2 = "CODE MEMBRE:"; //$NON-NLS-1$

  /**
   *
   */
  private static final String STATUT = ",Statut: "; //$NON-NLS-1$

  /**
   *
   */
  private static final String RECYCLAGE = ",Recyclage: "; //$NON-NLS-1$

  /**
   *
   */
  private static final String FICHIER = ",Fichier: "; //$NON-NLS-1$

  /**
   *
   */
  private static final String DESC_ERREUR = ",DescErreur: "; //$NON-NLS-1$

  /**
   *
   */
  private static final String DATE_ETAT = ",DateEtat: "; //$NON-NLS-1$

  /**
   *
   */
  private static final String CODE_ERREUR = ",CodeErreur"; //$NON-NLS-1$

  /**
   *
   */
  private static final String CHRONO = ",Chrono: "; //$NON-NLS-1$

  /**
   *
   */
  private static final String SERVICE = " SERVICE:"; //$NON-NLS-1$

  /**
   *
   */
  private static final String ORIGINE = " ORIGINE:"; //$NON-NLS-1$

  /**
   *
   */
  private static final String MSISDN = " MSISDN:"; //$NON-NLS-1$

  /**
   *
   */
  private static final String MOUVEMENT = " MOUVEMENT:"; //$NON-NLS-1$

  /**
   *
   */
  private static final String FABRICANT = " FABRICANT:"; //$NON-NLS-1$

  /**
   *
   */
  private static final String LUHN = " LUHN:"; //$NON-NLS-1$

  /**
   *
   */
  private static final String FICHIER_SOURCE = " FICHIER SOURCE:"; //$NON-NLS-1$

  /**
   *
   */
  private static final String DESIGNATION = " DESIGNATION:"; //$NON-NLS-1$

  /**
   *
   */
  private static final String DEMANDEUR = " DEMANDEUR:"; //$NON-NLS-1$

  /**
   *
   */
  private static final String CODE_MOTIF = " CODE MOTIF:"; //$NON-NLS-1$

  /**
   *
   */
  private static final String CODE_MEMBRE = " CODE MEMBRE:"; //$NON-NLS-1$

  /**
   * Connection failed
   */
  public static final String CONNEXION_FAILED = "CONNEXION_FAILED"; //$NON-NLS-1$

  /**
   * Epic failure during insertion
   */
  public static final String INSERTION_FAILED = "INSERTION_FAILED"; //$NON-NLS-1$

  /**
   * Failure during select
   */
  public static final String SELECT_FAILED = "SELECT_FAILED"; //$NON-NLS-1$

  /**
   * Session is unavailable
   */
  public static final String SESSION_UNAVAILABLE = "SESSION_UNAVAILABLE"; //$NON-NLS-1$

  /**
   * Connect timeout in seconds
   */
  private int _connectTimeoutSec;

  /**
   * Parameters read from configuration.
   */
  private Map<ParameterName, String> _parameters = new HashMap<ParameterName, String>();

  /**
   * Read timeout in seconds
   */
  private int _readTimeoutSec;

  @Override
  public ConnectorResponse<List<Indicateur>, Retour> calculerNombreBlacklistage(Tracabilite tracabilite_p, String codeMembres_p, String dateDebut_p, String dateFin_p) throws RavelException
  {

    Connection con = null;
    CallableStatement cs = null;
    _dsReadLock.lock();
    ResultSet rs = null;
    final String methodName = "P_GET_NB_BLACKLISTAGES"; //$NON-NLS-1$
    try
    {
      con = _datasource.getConnection();
      cs = con.prepareCall("{call PG_IHM_MOV.P_GET_NB_BLACKLISTAGES(?,?,?,?,?,?,?,?) }"); //$NON-NLS-1$

      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("pi_DateDebut", dateDebut_p); //$NON-NLS-1$
      cs.setString("pi_DateFin", dateFin_p); //$NON-NLS-1$
      cs.setString("pi_CodeMembre", codeMembres_p); //$NON-NLS-1$

      cs.registerOutParameter("po_RESULT", OracleTypes.CURSOR); //$NON-NLS-1$
      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();

      List<Indicateur> listIndicateur = new ArrayList<>();
      Retour retour = getRetour(cs);

      rs = (ResultSet) cs.getObject("po_RESULT"); //$NON-NLS-1$

      if (StringConstants.OK.equals(retour.getResultat()) && (rs != null))
      {
        while (rs.next())
        {
          listIndicateur.add(new Indicateur(rs));
        }
      }
      return new ConnectorResponse<>(listIndicateur, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("dateDebut: ").append(dateDebut_p).append("dateFin: ").append(dateFin_p).append("codeMembre: ").append(codeMembres_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

      // when insert takes too long
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, MessageFormat.format(Messages.getString(MOV_CONNECTOR_ERREUR_MOV_TIMEOUT_SUR_NON_REPONSE), _readTimeoutSec));
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("dateDebut: ").append(dateDebut_p).append("dateFin: ").append(dateFin_p).append("codeMembre: ").append(codeMembres_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

      //no sessions/connections available in the connection pool
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString(MOV_CONNECTOR_ERREUR_MOV_AUCUNE_SESSION));
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("dateDebut: ").append(dateDebut_p).append("dateFin: ").append(dateFin_p).append("codeMembre: ").append(codeMembres_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

      // when not able to connect
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString(MOV_CONNECTOR_ERREUR_MOV_TIMEOUT_CONNEXION), _connectTimeoutSec));
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append("dateDebut: ").append(dateDebut_p).append("dateFin: ").append(dateFin_p).append("codeMembre: ").append(codeMembres_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    }
    finally
    {
      if (cs != null)
      {
        try
        {
          cs.close();
        }
        catch (SQLException e)
        {
          //nothing to do
        }
      }
      if (con != null)
      {
        try
        {
          con.close();
        }
        catch (SQLException e)
        {
          //nothing to do
        }
      }
      _dsReadLock.unlock();
    }
  }

  @Override
  public ConnectorResponse<List<Indicateur>, Retour> calculerNombreDeblacklistage(Tracabilite tracabilite_p, String codeMembres_p, String dateDebut_p, String dateFin_p) throws RavelException
  {
    Connection con = null;
    CallableStatement cs = null;
    _dsReadLock.lock();
    ResultSet rs = null;
    final String methodName = "P_GET_NB_BLACKLISTAGES"; //$NON-NLS-1$
    try
    {
      con = _datasource.getConnection();
      cs = con.prepareCall("{call PG_IHM_MOV.P_GET_NB_DEBLACKLISTAGES(?,?,?,?,?,?,?,?) }"); //$NON-NLS-1$

      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("pi_DateDebut", dateDebut_p); //$NON-NLS-1$
      cs.setString("pi_DateFin", dateFin_p); //$NON-NLS-1$
      cs.setString("pi_CodeMembre", codeMembres_p); //$NON-NLS-1$

      cs.registerOutParameter("po_RESULT", OracleTypes.CURSOR); //$NON-NLS-1$
      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();

      List<Indicateur> listIndicateur = new ArrayList<>();
      Retour retour = getRetour(cs);

      rs = (ResultSet) cs.getObject("po_RESULT"); //$NON-NLS-1$

      if (StringConstants.OK.equals(retour.getResultat()) && (rs != null))
      {
        while (rs.next())
        {
          listIndicateur.add(new Indicateur(rs));
        }
      }
      return new ConnectorResponse<>(listIndicateur, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("dateDebut: ").append(dateDebut_p).append("dateFin: ").append(dateFin_p).append("codeMembre: ").append(codeMembres_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

      // when insert takes too long
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, MessageFormat.format(Messages.getString(MOV_CONNECTOR_ERREUR_MOV_TIMEOUT_SUR_NON_REPONSE), _readTimeoutSec));
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("dateDebut: ").append(dateDebut_p).append("dateFin: ").append(dateFin_p).append("codeMembre: ").append(codeMembres_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

      //no sessions/connections available in the connection pool
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString(MOV_CONNECTOR_ERREUR_MOV_AUCUNE_SESSION));
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("dateDebut: ").append(dateDebut_p).append("dateFin: ").append(dateFin_p).append("codeMembre: ").append(codeMembres_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

      // when not able to connect
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString(MOV_CONNECTOR_ERREUR_MOV_TIMEOUT_CONNEXION), _connectTimeoutSec));
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append("dateDebut: ").append(dateDebut_p).append("dateFin: ").append(dateFin_p).append("codeMembre: ").append(codeMembres_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    }
    finally
    {
      if (cs != null)
      {
        try
        {
          cs.close();
        }
        catch (SQLException e)
        {
          //nothing to do
        }
      }
      if (con != null)
      {
        try
        {
          con.close();
        }
        catch (SQLException e)
        {
          //nothing to do
        }
      }
      _dsReadLock.unlock();
    }
  }

  /**
   *
   */
  @Override
  public ConnectorResponse<List<DemandeBotClosrsx>, Retour> consultDemandeBotClosrsx(Tracabilite tracabilite_p) throws RavelException
  {
    ResultSet rs = null;
    Connection con = null;
    CallableStatement cs = null;
    _dsReadLock.lock();

    final String methodName = "P_007_CONS_DEMAND_BOT_CLOSRSX"; //$NON-NLS-1$
    try
    {
      con = _datasource.getConnection();
      cs = con.prepareCall(String.format("{call %s(?,?,?,?,?) }", methodName)); //$NON-NLS-1$
      cs.setQueryTimeout(_readTimeoutSec);

      cs.registerOutParameter(CURSORX, OracleTypes.CURSOR);
      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();

      rs = (ResultSet) cs.getObject(CURSORX);

      List<DemandeBotClosrsx> listDemandes = new ArrayList<>();

      while (rs.next())
      {
        DemandeBotClosrsx demande = new DemandeBotClosrsx();
        mapValuesFromResultSet(demande, rs);
        listDemandes.add(demande);
      }

      Retour retour = getRetour(cs);

      return new ConnectorResponse<>(listDemandes, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName);

      //when select takes too long
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SELECT_FAILED, MessageFormat.format(Messages.getString(MOV_CONNECTOR_ERREUR_MOV_TIMEOUT_SUR_NON_REPONSE), _readTimeoutSec));
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName);

      //no sessions/connections available in the connection pool
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString(MOV_CONNECTOR_ERREUR_GDR_AUCUNE_SESSION));
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName);

      // when not able to connect
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString(MOV_CONNECTOR_ERREUR_MOV_TIMEOUT_CONNEXION), _connectTimeoutSec));
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName);
    }
    finally
    {
      close(rs, cs, con);
      _dsReadLock.unlock();
    }
  }

  /**
   * Appel à la procédure stockée « P_GET_INFORMATIONS »
   *
   * @param tracabilite_p
   *          Ravel Message Id
   * @param date_p
   *          date
   * @param dateDebut_p
   *          date début
   * @param dateFin_p
   *          date fin
   * @return {@link InformationsDemande}
   * @throws RavelException
   *           exception thrown
   */
  @Override
  public ConnectorResponse<List<InformationsDemande>, Retour> consulterInformationsParDate(Tracabilite tracabilite_p, String date_p, String dateDebut_p, String dateFin_p) throws RavelException
  {
    return consulterInformationsDemande(tracabilite_p, date_p, dateDebut_p, dateFin_p, null, null, null);
  }

  /**
   * Appel à la procédure stockée « P_GET_INFORMATIONS »
   *
   * @param tracabilite_p
   *          Ravel Message Id
   * @param date_p
   *          date
   * @param dateDebut_p
   *          date début
   * @param dateFin_p
   *          date fin
   * @param codeMembre_p
   *          code membre
   * @return {@link InformationsDemande}
   * @throws RavelException
   *           exception thrown
   */
  @Override
  public ConnectorResponse<List<InformationsDemande>, Retour> consulterInformationsParDateCodeMembre(Tracabilite tracabilite_p, String date_p, String dateDebut_p, String dateFin_p, String codeMembre_p) throws RavelException
  {
    return consulterInformationsDemande(tracabilite_p, date_p, dateDebut_p, dateFin_p, codeMembre_p, null, null);
  }

  /**
   * Appel à la procédure stockée « P_GET_INFORMATIONS »
   *
   * @param tracabilite_p
   *          Ravel Message Id
   * @param imei_p
   *          imei
   * @return {@link InformationsDemande}
   * @throws RavelException
   *           exception thrown
   */
  @Override
  public ConnectorResponse<List<InformationsDemande>, Retour> consulterInformationsParImei(Tracabilite tracabilite_p, String imei_p) throws RavelException
  {
    return consulterInformationsDemande(tracabilite_p, null, null, null, null, null, imei_p);
  }

  /**
   * Appel à la procédure stockée « P_GET_INFORMATIONS »
   *
   * @param tracabilite_p
   *          Ravel Message Id
   * @param imei_p
   *          imei
   * @param date_p
   *          date
   * @param dateDebut_p
   *          date début
   * @param dateFin_p
   *          date fin
   * @return {@link InformationsDemande}
   * @throws RavelException
   *           exception thrown
   */
  @Override
  public ConnectorResponse<List<InformationsDemande>, Retour> consulterInformationsParImeiDate(Tracabilite tracabilite_p, String imei_p, String date_p, String dateDebut_p, String dateFin_p) throws RavelException
  {
    return consulterInformationsDemande(tracabilite_p, date_p, dateDebut_p, dateFin_p, null, null, imei_p);
  }

  /**
   * Appel à la procédure stockée « P_GET_INFORMATIONS »
   *
   * @param tracabilite_p
   *          Ravel Message Id
   * @param msisdn_p
   *          msisdn
   * @return {@link InformationsDemande}
   * @throws RavelException
   *           exception thrown
   */
  @Override
  public ConnectorResponse<List<InformationsDemande>, Retour> consulterInformationsParMsisdn(Tracabilite tracabilite_p, String msisdn_p) throws RavelException
  {
    return consulterInformationsDemande(tracabilite_p, null, null, null, null, msisdn_p, null);
  }

  /**
   * Appel à la procédure stockée « P_GET_INFORMATIONS »
   *
   * @param tracabilite_p
   *          Ravel Message Id
   * @param msisdn_p
   *          msisdn
   * @param date_p
   *          date
   * @param dateDebut_p
   *          date début
   * @param dateFin_p
   *          date fin
   * @return {@link InformationsDemande}
   * @throws RavelException
   *           exception thrown
   */
  @Override
  public ConnectorResponse<List<InformationsDemande>, Retour> consulterInformationsParMsisdnDate(Tracabilite tracabilite_p, String msisdn_p, String date_p, String dateDebut_p, String dateFin_p) throws RavelException
  {
    return consulterInformationsDemande(tracabilite_p, date_p, dateDebut_p, dateFin_p, null, msisdn_p, null);
  }

  /**
   * Invokes the stored procedure P_002_cons_MOV_DerniereDemande
   *
   * @param tracabilite_p
   *          Ravel Message Id
   * @param imei_p
   *          IMEI to be searched
   * @return response from the stored procedure
   * @throws RavelException
   *           thrown exception
   */
  @Override
  public ConnectorResponse<Demande, Retour> consultMOVDerniereDemande(Tracabilite tracabilite_p, String imei_p) throws RavelException
  {
    Demande ret = null;
    ResultSet rs = null;
    Connection con = null;
    CallableStatement cs = null;
    _dsReadLock.lock();
    final String methodName = "P_002_cons_MOV_DerniereDemande"; //$NON-NLS-1$
    try
    {
      con = _datasource.getConnection();
      cs = con.prepareCall(String.format(CALL_MOV_PS, methodName));
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("IMEI_In", imei_p); //$NON-NLS-1$

      cs.registerOutParameter(CURSORX, OracleTypes.CURSOR);
      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();
      rs = (ResultSet) cs.getObject(CURSORX);

      if (rs.next())
      {
        ret = new Demande();
        mapValuesFromResultSet(ret, rs);
      }

      Retour retour = getRetour(cs);

      if (ret == null)
      {
        retour = RetourFactory.createKO(IMegConsts.CAT4, "DONNEE_INCONNUE", "Aucune demande n'existe pour l'IMEI demandé"); //$NON-NLS-1$ //$NON-NLS-2$
      }

      return new ConnectorResponse<>(ret, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append(IMEI).append(imei_p).toString());

      // when insert takes too long
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, MessageFormat.format(Messages.getString(MOV_CONNECTOR_ERREUR_MOV_TIMEOUT_SUR_NON_REPONSE), _readTimeoutSec));
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append(IMEI).append(imei_p).toString());

      //no sessions/connections available in the connection pool
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString(MOV_CONNECTOR_ERREUR_GDR_AUCUNE_SESSION));
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append(IMEI).append(imei_p).toString());

      // when not able to connect
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString(MOV_CONNECTOR_ERREUR_MOV_TIMEOUT_CONNEXION), _connectTimeoutSec));
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append(IMEI).append(imei_p).toString());
    }
    finally
    {
      close(rs, cs, con);
      _dsReadLock.unlock();
    }
  }

  /**
   * Invokes the stored procedure P_001_consult_MOV_ListeDemande
   *
   * @param tracabilite_p
   *          Ravel Message Id
   * @param imei_p
   *          IMEI to be searched
   * @return response from the stored procedure
   * @throws RavelException
   *           thrown exception
   */

  @Override
  public ConnectorResponse<Demande[], Retour> consultMOVListeDemande(Tracabilite tracabilite_p, String imei_p) throws RavelException
  {
    Demande[] ret = null;
    ResultSet rs = null;
    Connection con = null;
    CallableStatement cs = null;

    _dsReadLock.lock();
    final String methodName = "P_001_consult_MOV_ListeDemande"; //$NON-NLS-1$
    try
    {
      con = _datasource.getConnection();
      cs = con.prepareCall(String.format(CALL_MOV_PS, methodName));
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("IMEI_In", imei_p); //$NON-NLS-1$

      cs.registerOutParameter(CURSORX, OracleTypes.CURSOR);
      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();
      rs = (ResultSet) cs.getObject(CURSORX);

      ArrayList<Demande> listDemande = new ArrayList<>();

      while (rs.next())
      {
        Demande demande = new Demande();
        mapValuesFromResultSet(demande, rs);
        listDemande.add(demande);
      }

      Retour retour = getRetour(cs);
      ret = new Demande[listDemande.size()];
      ret = listDemande.toArray(ret);

      if (listDemande.isEmpty())
      {
        retour = RetourFactory.createKO(IMegConsts.CAT4, "DONNEE_INCONNUE", "Aucune demande n'existe pour l'IMEI demandé"); //$NON-NLS-1$//$NON-NLS-2$
      }

      return new ConnectorResponse<>(ret, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append(IMEI).append(imei_p).toString());

      // when insert takes too long
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, MessageFormat.format(Messages.getString(MOV_CONNECTOR_ERREUR_MOV_TIMEOUT_SUR_NON_REPONSE), _readTimeoutSec));
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append(IMEI).append(imei_p).toString());

      //no sessions/connections available in the connection pool
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString(MOV_CONNECTOR_ERREUR_GDR_AUCUNE_SESSION));
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append(IMEI).append(imei_p).toString());

      // when not able to connect
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString(MOV_CONNECTOR_ERREUR_MOV_TIMEOUT_CONNEXION), _connectTimeoutSec));
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append(IMEI).append(imei_p).toString());
    }
    finally
    {
      close(rs, cs, con);
      _dsReadLock.unlock();
    }
  }

  /**
   * Appel à la procédure stockée P_003_GESTION_DEMANDE_BLKDBLK
   *
   * @param tracabilite_p
   *          Ravel Message Id
   * @param demandeur_p
   *          Demandeur
   * @param imei_p
   *          IMEI
   * @param code_membre_p
   *          Code Membre
   * @param code_motif_p
   *          Code Motif
   * @param mouvement_p
   *          Mouvement
   * @param flg_luhn_p
   *          LUHN
   * @param origine_p
   *          Origine
   * @param msisdn_p
   *          MSISDN
   * @param service_p
   *          Service
   * @param fabricant_p
   *          Fabricant
   * @param designation_p
   *          Designation
   * @param fichier_source_p
   *          Fichier Source
   * @return une flag TAC
   * @throws RavelException
   *           exception
   */
  @Override
  public ConnectorResponse<Integer, Retour> insererDemandeMOV(Tracabilite tracabilite_p, String imei_p, String demandeur_p, String code_membre_p, String code_motif_p, String mouvement_p, int flg_luhn_p, String origine_p, String msisdn_p, String service_p, String fabricant_p, String designation_p, String fichier_source_p) throws RavelException
  {
    Integer flgTAC = null;

    Connection con = null;
    CallableStatement callableStatement = null;
    _dsReadLock.lock();
    final String methodName = "P_003_GESTION_DEMANDE_BLKDBLK"; //$NON-NLS-1$
    try
    {
      con = _datasource.getConnection();
      callableStatement = con.prepareCall(String.format("{call %s(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) }", methodName)); //$NON-NLS-1$
      callableStatement.setQueryTimeout(_readTimeoutSec);

      callableStatement.setString("IMEI_P", imei_p); //$NON-NLS-1$
      callableStatement.setString("DEMANDEUR_P", demandeur_p); //$NON-NLS-1$
      callableStatement.setString(CODE_MEMBRE_P, code_membre_p);
      callableStatement.setString("CODE_MOTIF_P", code_motif_p); //$NON-NLS-1$
      callableStatement.setString("MOUVEMENT_P", mouvement_p); //$NON-NLS-1$
      callableStatement.setInt("FLG_LUHN_P", flg_luhn_p); //$NON-NLS-1$
      callableStatement.setString("ORIGINE_P", origine_p); //$NON-NLS-1$
      callableStatement.setString("MSISDN_P", msisdn_p); //$NON-NLS-1$
      callableStatement.setString("SERVICE_P", service_p); //$NON-NLS-1$
      callableStatement.setString("FABRICANT_P", fabricant_p); //$NON-NLS-1$
      callableStatement.setString("DESIGNATION_P", designation_p); //$NON-NLS-1$
      callableStatement.setString("FICHIER_SOURCE_P", fichier_source_p); //$NON-NLS-1$

      callableStatement.registerOutParameter(RETOUR2, OracleTypes.NUMBER);
      callableStatement.registerOutParameter(LOG_ERREUR, OracleTypes.VARCHAR);
      callableStatement.registerOutParameter(ERREUR2, OracleTypes.VARCHAR);
      callableStatement.registerOutParameter("TAC", OracleTypes.NUMBER); //$NON-NLS-1$

      callableStatement.execute();

      String logErreur = callableStatement.getString(LOG_ERREUR);
      String erreur = callableStatement.getString(ERREUR2);

      Retour retour = RetourFactory.createOkRetour();
      flgTAC = callableStatement.getInt("TAC"); //$NON-NLS-1$

      if (callableStatement.getInt(RETOUR2) != 0)
      {
        retour.setResultat(StringConstants.KO);
        retour.setDiagnostic(erreur);
        retour.setCategorie(logErreur);
        retour.setLibelle(erreur);
      }

      return new ConnectorResponse<>(flgTAC, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append(IMEI).append(imei_p).append(DEMANDEUR).append(demandeur_p).append(CODE_MEMBRE).append(code_membre_p).append(CODE_MOTIF).append(code_motif_p).append(MOUVEMENT).append(mouvement_p).append(LUHN).append(flg_luhn_p).append(ORIGINE).append(origine_p).append(MSISDN).append(msisdn_p).append(SERVICE).append(service_p).append(FABRICANT).append(fabricant_p).append(DESIGNATION).append(designation_p).append(FICHIER_SOURCE).append(fichier_source_p).toString());

      // when insert takes too long
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, MessageFormat.format(Messages.getString(MOV_CONNECTOR_ERREUR_MOV_TIMEOUT_SUR_NON_REPONSE), _readTimeoutSec));
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append(IMEI).append(imei_p).append(DEMANDEUR).append(demandeur_p).append(CODE_MEMBRE).append(code_membre_p).append(CODE_MOTIF).append(code_motif_p).append(MOUVEMENT).append(mouvement_p).append(LUHN).append(flg_luhn_p).append(ORIGINE).append(origine_p).append(MSISDN).append(msisdn_p).append(SERVICE).append(service_p).append(FABRICANT).append(fabricant_p).append(DESIGNATION).append(designation_p).append(FICHIER_SOURCE).append(fichier_source_p).toString());

      //no sessions/connections available in the connection pool
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString(MOV_CONNECTOR_ERREUR_MOV_AUCUNE_SESSION));
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append(IMEI).append(imei_p).append(DEMANDEUR).append(demandeur_p).append(CODE_MEMBRE).append(code_membre_p).append(CODE_MOTIF).append(code_motif_p).append(MOUVEMENT).append(mouvement_p).append(LUHN).append(flg_luhn_p).append(ORIGINE).append(origine_p).append(MSISDN).append(msisdn_p).append(SERVICE).append(service_p).append(FABRICANT).append(fabricant_p).append(DESIGNATION).append(designation_p).append(FICHIER_SOURCE).append(fichier_source_p).toString());

      // when not able to connect
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString(MOV_CONNECTOR_ERREUR_MOV_TIMEOUT_CONNEXION), _connectTimeoutSec));
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append(IMEI).append(imei_p).append(DEMANDEUR).append(demandeur_p).append(CODE_MEMBRE).append(code_membre_p).append(CODE_MOTIF).append(code_motif_p).append(MOUVEMENT).append(mouvement_p).append(LUHN).append(flg_luhn_p).append(ORIGINE).append(origine_p).append(MSISDN).append(msisdn_p).append(SERVICE).append(service_p).append(FABRICANT).append(fabricant_p).append(DESIGNATION).append(designation_p).append(FICHIER_SOURCE).append(fichier_source_p).toString());
    }
    finally
    {
      if (callableStatement != null)
      {
        try
        {
          callableStatement.close();
        }
        catch (SQLException e)
        {
          //nothing to do
        }
      }
      if (con != null)
      {
        try
        {
          con.close();
        }
        catch (SQLException e)
        {
          //nothing to do
        }
      }
      _dsReadLock.unlock();
    }
  }

  /**
   * Appel à la procédure stockée P_008_INSERT_NEW_ETAT
   *
   * @param tracabilite_p
   *          Ravel MEssage Id
   * @param demande_p
   *          The Demande number
   * @param statut_p
   *          The statut
   * @param fichier_p
   *          The filename
   * @param dateEtat_p
   *          The Etat date
   * @param codeErreur_p
   *          The error code
   * @param descErreur_p
   *          The error description
   * @param chrono_p
   *          The chrono number
   * @param recyclage_p
   *          The recyclage
   * @return response from the stored procedure
   * @throws RavelException
   *           on error
   */
  @Override
  public ConnectorResponse<Boolean, Retour> insertNewEtat(Tracabilite tracabilite_p, long demande_p, String statut_p, String fichier_p, Timestamp dateEtat_p, String codeErreur_p, String descErreur_p, Long chrono_p, Long recyclage_p) throws RavelException
  {

    Connection con = null;
    CallableStatement cs = null;

    _dsReadLock.lock();
    final String methodName = "P_008_INSERT_NEW_ETAT"; //$NON-NLS-1$
    try
    {
      con = _datasource.getConnection();
      cs = con.prepareCall(String.format("{call %s(?,?,?,?,?,?,?,?,?,?,?,?) }", methodName)); //$NON-NLS-1$
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setLong("pi_demande", demande_p); //$NON-NLS-1$
      cs.setString("pi_statut", statut_p); //$NON-NLS-1$
      cs.setString("pi_fichier", fichier_p); //$NON-NLS-1$
      cs.setTimestamp("pi_date_etat", dateEtat_p); //$NON-NLS-1$
      cs.setString("pi_code_erreur", codeErreur_p); //$NON-NLS-1$
      cs.setString("pi_description_erreur", descErreur_p); //$NON-NLS-1$

      if (chrono_p != null)
      {
        cs.setLong("pi_chrono", chrono_p); //$NON-NLS-1$
      }
      else
      {
        cs.setNull("pi_chrono", OracleTypes.NUMBER); //$NON-NLS-1$
      }

      if (recyclage_p != null)
      {
        cs.setLong("pi_recyclage", recyclage_p); //$NON-NLS-1$
      }
      else
      {
        cs.setNull("pi_recyclage", OracleTypes.NUMBER); //$NON-NLS-1$
      }

      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();

      Retour retour = getRetour(cs);

      return new ConnectorResponse<>(true, retour);
    }
    catch (SQLTimeoutException e)
    {
      StringBuilder sb = new StringBuilder().append(DEMANDE).append(demande_p).append(STATUT).append(statut_p);
      sb = sb.append(FICHIER).append(fichier_p).append(DATE_ETAT).append(dateEtat_p).append(CODE_ERREUR).append(codeErreur_p);
      sb = sb.append(DESC_ERREUR).append(descErreur_p).append(CHRONO).append(chrono_p).append(RECYCLAGE).append(recyclage_p);

      buildTechnicalMessage(e, tracabilite_p, methodName, sb.toString());

      // when insert takes too long
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, MessageFormat.format(Messages.getString(MOV_CONNECTOR_ERREUR_MOV_TIMEOUT_SUR_NON_REPONSE), _readTimeoutSec));
      return new ConnectorResponse<>(false, retour);
    }
    catch (PoolExhaustedException e)
    {
      StringBuilder sb = new StringBuilder().append(DEMANDE).append(demande_p).append(STATUT).append(statut_p);
      sb = sb.append(FICHIER).append(fichier_p).append(DATE_ETAT).append(dateEtat_p).append(CODE_ERREUR).append(codeErreur_p);
      sb = sb.append(DESC_ERREUR).append(descErreur_p).append(CHRONO).append(chrono_p).append(RECYCLAGE).append(recyclage_p);

      buildTechnicalMessage(e, tracabilite_p, methodName, sb.toString());

      //no sessions/connections available in the connection pool
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString(MOV_CONNECTOR_ERREUR_GDR_AUCUNE_SESSION));
      return new ConnectorResponse<>(false, retour);
    }
    catch (SQLRecoverableException e)
    {
      StringBuilder sb = new StringBuilder().append(DEMANDE).append(demande_p).append(STATUT).append(statut_p);
      sb = sb.append(FICHIER).append(fichier_p).append(DATE_ETAT).append(dateEtat_p).append(CODE_ERREUR).append(codeErreur_p);
      sb = sb.append(DESC_ERREUR).append(descErreur_p).append(CHRONO).append(chrono_p).append(RECYCLAGE).append(recyclage_p);

      buildTechnicalMessage(e, tracabilite_p, methodName, sb.toString());

      // when not able to connect
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString(MOV_CONNECTOR_ERREUR_MOV_TIMEOUT_CONNEXION), _connectTimeoutSec));
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      StringBuilder sb = new StringBuilder().append(DEMANDE).append(demande_p).append(STATUT).append(statut_p);
      sb = sb.append(FICHIER).append(fichier_p).append(DATE_ETAT).append(dateEtat_p).append(CODE_ERREUR).append(codeErreur_p);
      sb = sb.append(DESC_ERREUR).append(descErreur_p).append(CHRONO).append(chrono_p).append(RECYCLAGE).append(recyclage_p);

      throw buildTechnicalException(e, tracabilite_p, methodName, sb.toString());
    }
    finally
    {
      if (cs != null)
      {
        try
        {
          cs.close();
        }
        catch (SQLException e)
        {
          //nothing to do
        }
      }
      if (con != null)
      {
        try
        {
          con.close();
        }
        catch (SQLException e)
        {
          //nothing to do
        }
      }
      _dsReadLock.unlock();
    }
  }

  /**
   * loadConnectorConfiguration
   */
  @Override
  public void loadConnectorConfiguration(Connector connector_p) throws RavelException
  {
    // Read parameters.
    _name = connector_p.getName();
    _enabled = connector_p.isEnabled();
    for (Param parameter : connector_p.getParam())
    {
      ParameterName parameterName = ParameterName.valueOf(parameter.getName().toUpperCase());
      if (parameterName != null)
      {
        _parameters.put(parameterName, parameter.getValue());
      }
    }

    // Check parameters
    String connectionString = _parameters.get(ParameterName.DB_CONNECTIONSTRING);
    if ((connectionString == null) || connectionString.isEmpty())
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, Messages.getString(Messages.MISSING_PARAMETER, _name, ParameterName.DB_CONNECTIONSTRING.toString()));
    }
    String dbUserName = _parameters.get(ParameterName.DB_USERNAME);
    if ((dbUserName == null) || dbUserName.isEmpty())
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, Messages.getString(Messages.MISSING_PARAMETER, _name, ParameterName.DB_USERNAME.toString()));
    }
    String dbPassword = _parameters.get(ParameterName.DB_PASSWORD);
    if ((dbPassword == null) || dbPassword.isEmpty())
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, Messages.getString(Messages.MISSING_PARAMETER, _name, ParameterName.DB_PASSWORD.toString()));
    }
    String poolSize = _parameters.get(ParameterName.POOLSIZE);

    String connectTimeoutSec = _parameters.get(ParameterName.CONNECT_TIMEOUT_SEC);
    if (StringTools.isNullOrEmpty(connectTimeoutSec))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, Messages.getString(Messages.MISSING_PARAMETER, _name, ParameterName.CONNECT_TIMEOUT_SEC.toString()));
    }
    try
    {
      _connectTimeoutSec = Integer.parseInt(connectTimeoutSec);
    }
    catch (NumberFormatException e)
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00021, Messages.getString(Messages.INVALID_PARAMETER, _name, _parameters.get(ParameterName.CONNECT_TIMEOUT_SEC)));
    }

    String readTimeoutSec = _parameters.get(ParameterName.READ_TIMEOUT_SEC);
    if (StringTools.isNullOrEmpty(readTimeoutSec))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, Messages.getString(Messages.MISSING_PARAMETER, _name, ParameterName.READ_TIMEOUT_SEC.toString()));
    }
    try
    {
      _readTimeoutSec = Integer.parseInt(readTimeoutSec);
    }
    catch (NumberFormatException e)
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00021, Messages.getString(Messages.INVALID_PARAMETER, _name, _parameters.get(ParameterName.READ_TIMEOUT_SEC)));
    }

    createDataSource(connectionString, dbUserName, dbPassword, poolSize, DatabaseType.ORACLE);

  }

  /**
   * Appel à la procédure stockée P_005_CHECK_CODE_MEMBRE
   *
   * @param tracabilite_p
   *          Ravel Message Id
   * @param code_membre_p
   *          Le code membre à vérifier
   * @return nombre d'occurrences ({@link Retour})
   * @throws RavelException
   *           exception thrown
   */
  @Override
  public ConnectorResponse<Long, Retour> verifierCodeMembre(Tracabilite tracabilite_p, String code_membre_p) throws RavelException
  {

    Connection con = null;
    CallableStatement callableStatement = null;
    _dsReadLock.lock();
    final String methodName = "P_005_CHECK_CODE_MEMBRE"; //$NON-NLS-1$
    try
    {
      con = _datasource.getConnection();
      callableStatement = con.prepareCall(String.format("{call %s(?,?) }", methodName)); //$NON-NLS-1$
      callableStatement.setQueryTimeout(_readTimeoutSec);

      callableStatement.setString(CODE_MEMBRE_P, code_membre_p);

      callableStatement.registerOutParameter(RETOUR2, OracleTypes.NUMBER);

      callableStatement.execute();

      Long nbResultats = callableStatement.getLong(RETOUR2);

      return new ConnectorResponse<>(nbResultats, RetourFactory.createOkRetour());
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append(CODE_MEMBRE2).append(code_membre_p).toString());

      // when insert takes too long
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, MessageFormat.format(Messages.getString(MOV_CONNECTOR_ERREUR_MOV_TIMEOUT_SUR_NON_REPONSE), _readTimeoutSec));
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append(CODE_MEMBRE2).append(code_membre_p).toString());

      //no sessions/connections available in the connection pool
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString(MOV_CONNECTOR_ERREUR_MOV_AUCUNE_SESSION));
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append(CODE_MEMBRE2).append(code_membre_p).toString());

      // when not able to connect
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString(MOV_CONNECTOR_ERREUR_MOV_TIMEOUT_CONNEXION), _connectTimeoutSec));
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append(CODE_MEMBRE2).append(code_membre_p).toString());
    }
    finally
    {
      if (callableStatement != null)
      {
        try
        {
          callableStatement.close();
        }
        catch (SQLException e)
        {
          //nothing to do
        }
      }
      if (con != null)
      {
        try
        {
          con.close();
        }
        catch (SQLException e)
        {
          //nothing to do
        }
      }
      _dsReadLock.unlock();
    }
  }

  /**
   * Appel à la procédure stockée P_004_CHECK_CODE_MOTIF
   *
   * @param tracabilite_p
   *          Ravel Message Id
   * @param code_motif_p
   *          Le code motif à vérifier
   * @return nombre d'occurrences ({@link Retour})
   * @throws RavelException
   *           exception thrown
   */
  @Override
  public ConnectorResponse<Long, Retour> verifierCodeMotif(Tracabilite tracabilite_p, String code_motif_p) throws RavelException
  {

    Connection con = null;
    CallableStatement callableStatement = null;
    _dsReadLock.lock();
    final String methodName = "P_004_CHECK_CODE_MOTIF"; //$NON-NLS-1$
    try
    {
      con = _datasource.getConnection();
      callableStatement = con.prepareCall(String.format("{call %s(?,?) }", methodName)); //$NON-NLS-1$
      callableStatement.setQueryTimeout(_readTimeoutSec);

      callableStatement.setString("CODE_MOTIF_P", code_motif_p); //$NON-NLS-1$

      callableStatement.registerOutParameter(RETOUR2, OracleTypes.NUMBER);

      callableStatement.execute();

      Long nbResultats = callableStatement.getLong(RETOUR2);

      return new ConnectorResponse<>(nbResultats, RetourFactory.createOkRetour());
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append(CODE_MOTIF2).append(code_motif_p).toString());

      // when insert takes too long
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, MessageFormat.format(Messages.getString(MOV_CONNECTOR_ERREUR_MOV_TIMEOUT_SUR_NON_REPONSE), _readTimeoutSec));
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append(CODE_MOTIF2).append(code_motif_p).toString());

      //no sessions/connections available in the connection pool
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString(MOV_CONNECTOR_ERREUR_MOV_AUCUNE_SESSION));
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append(CODE_MOTIF2).append(code_motif_p).toString());

      // when not able to connect
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString(MOV_CONNECTOR_ERREUR_MOV_TIMEOUT_CONNEXION), _connectTimeoutSec));
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append(CODE_MOTIF2).append(code_motif_p).toString());
    }
    finally
    {
      if (callableStatement != null)
      {
        try
        {
          callableStatement.close();
        }
        catch (SQLException e)
        {
          //nothing to do
        }
      }
      if (con != null)
      {
        try
        {
          con.close();
        }
        catch (SQLException e)
        {
          //nothing to do
        }
      }
      _dsReadLock.unlock();
    }
  }

  /**
   * Appel à la procédure stockée P_006_CHECK_DEDOUBLONNAGE
   *
   * @param tracabilite_p
   *          Ravel Message Id
   * @param imei_p
   *          L'IMEI à vérifier
   * @param mouvement_p
   *          Mouvement
   * @param code_membre_p
   *          Code membre
   * @return true or false si demande valide ({@link Retour})
   * @throws RavelException
   *           exception thrown
   */
  @Override
  public ConnectorResponse<Boolean, Retour> verifierDedoublonnage(Tracabilite tracabilite_p, String imei_p, String mouvement_p, String code_membre_p) throws RavelException
  {
    Boolean resultat = Boolean.TRUE;

    Connection con = null;
    CallableStatement callableStatement = null;
    _dsReadLock.lock();
    final String methodName = "P_006_CHECK_DEDOUBLONNAGE"; //$NON-NLS-1$
    try
    {
      con = _datasource.getConnection();
      callableStatement = con.prepareCall(String.format(CALL_MOV_PS, methodName));
      callableStatement.setQueryTimeout(_readTimeoutSec);

      callableStatement.setString("IMEI_P", imei_p); //$NON-NLS-1$
      callableStatement.setString("MOUVEMENT_P", mouvement_p); //$NON-NLS-1$
      callableStatement.setString(CODE_MEMBRE_P, code_membre_p);

      callableStatement.registerOutParameter(RETOUR2, OracleTypes.NUMBER);
      callableStatement.registerOutParameter(LOG_ERREUR, OracleTypes.VARCHAR);
      callableStatement.registerOutParameter(ERREUR2, OracleTypes.VARCHAR);

      callableStatement.execute();

      String logErreur = callableStatement.getString(LOG_ERREUR);
      String erreur = callableStatement.getString(ERREUR2);

      Retour retour = RetourFactory.createOkRetour();

      if (callableStatement.getInt(RETOUR2) != 0)
      {
        resultat = Boolean.FALSE;
        retour.setResultat(StringConstants.KO);
        retour.setDiagnostic(erreur);
        retour.setCategorie(logErreur);
        retour.setLibelle(erreur);
      }

      return new ConnectorResponse<>(resultat, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append(IMEI).append(imei_p).append(MOUVEMENT).append(mouvement_p).append(CODE_MEMBRE).append(code_membre_p).toString());

      // when insert takes too long
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, MessageFormat.format(Messages.getString(MOV_CONNECTOR_ERREUR_MOV_TIMEOUT_SUR_NON_REPONSE), _readTimeoutSec));
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append(IMEI).append(imei_p).append(MOUVEMENT).append(mouvement_p).append(CODE_MEMBRE).append(code_membre_p).toString());

      //no sessions/connections available in the connection pool
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString(MOV_CONNECTOR_ERREUR_MOV_AUCUNE_SESSION));
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append(IMEI).append(imei_p).append(MOUVEMENT).append(mouvement_p).append(CODE_MEMBRE).append(code_membre_p).toString());

      // when not able to connect
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString(MOV_CONNECTOR_ERREUR_MOV_TIMEOUT_CONNEXION), _connectTimeoutSec));
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append(IMEI).append(imei_p).append(MOUVEMENT).append(mouvement_p).append(CODE_MEMBRE).append(code_membre_p).toString());
    }
    finally
    {
      if (callableStatement != null)
      {
        try
        {
          callableStatement.close();
        }
        catch (SQLException e)
        {
          //nothing to do
        }
      }
      if (con != null)
      {
        try
        {
          con.close();
        }
        catch (SQLException e)
        {
          //nothing to do
        }
      }
      _dsReadLock.unlock();
    }
  }

  /**
   * Build a log entry and throws an {@link RavelException} for a technical problem.
   *
   * @param exc_p
   *          The {@link Exception} raised
   * @param tracabilite_p
   *          The current MsgId
   * @param spName_p
   *          The stored oricedure name in which the fault was raised
   * @return The technical exception
   */
  private RavelException buildTechnicalException(SQLException exc_p, Tracabilite tracabilite_p, String spName_p)
  {
    final String message = buildTechnicalMessage(exc_p, tracabilite_p, spName_p);

    return new RavelException(ExceptionType.PFS_EXCEPTION, ErrorCode.CNCTOR_00010, message, IMOVConnector.BEAN_ID, exc_p);
  }

  /**
   * Build a log entry and throws an {@link RavelException} for a technical problem.
   *
   * @param exc_p
   *          The {@link Exception} raised
   * @param tracabilite_p
   *          The current MsgId
   * @param spName_p
   *          The stored procedure name in which the fault was raised.
   * @param inputs_p
   *          A string representing input data of the stored procedure.
   * @return RavelException The technical exception.
   */
  private RavelException buildTechnicalException(SQLException exc_p, Tracabilite tracabilite_p, String spName_p, String inputs_p)
  {
    final String message = buildTechnicalMessage(exc_p, tracabilite_p, spName_p, inputs_p);

    return new RavelException(ExceptionType.PFS_EXCEPTION, ErrorCode.CNCTOR_00010, message, IMOVConnector.BEAN_ID, exc_p);
  }

  /**
   * Build a log entry for a technical problem.
   *
   * @param exc_p
   *          The {@link Exception} raised
   * @param tracabilite_p
   *          The current MsgId
   * @param spName_p
   *          The stored procedure name in which the fault was raised
   *
   * @return The message of the technical exception
   */
  private String buildTechnicalMessage(SQLException exc_p, Tracabilite tracabilite_p, String spName_p)
  {
    final String message = new StringBuilder().append(MessageFormat.format(Messages.getString(Messages.TECHNICAL_EXCEPTION), spName_p, exc_p.getErrorCode(), exc_p.getLocalizedMessage())).append(ExceptionTools.getExceptionLineAndFile(exc_p)).toString();

    RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, message));

    return message;

  }

  /**
   * Build a log entry for a technical problem.
   *
   * @param exc_p
   *          The {@link Exception} raised
   * @param tracabilite_p
   *          The current MsgId
   * @param spName_p
   *          The stored procedure name in which the fault was raised.
   * @param inputs_p
   *          A string representing input data of the stored procedure.
   * @return String The message of technical exception.
   */
  private String buildTechnicalMessage(SQLException exc_p, Tracabilite tracabilite_p, String spName_p, String inputs_p)
  {
    final String message = new StringBuilder().append(MessageFormat.format(Messages.getString(Messages.TECHNICAL_EXCEPTION), spName_p, exc_p.getErrorCode(), exc_p.getLocalizedMessage())).append(ExceptionTools.getExceptionLineAndFile(exc_p)) // add fileName and line number of the exception
        .toString();

    RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, message));

    return message;
  }

  /**
   * Restituer la liste de demandes
   *
   * @param tracabilite_p
   *          msg id
   * @param date_p
   *          date
   * @param dateDebut_p
   *          date début
   * @param dateFin_p
   *          date fin
   * @param codeMembre_p
   *          code membre
   * @param msisdn_p
   *          msisdn
   * @param imei_p
   *          imei
   * @return {@link InformationsDemande}
   * @throws RavelException
   *           exception thrown
   */
  private ConnectorResponse<List<InformationsDemande>, Retour> consulterInformationsDemande(Tracabilite tracabilite_p, String date_p, String dateDebut_p, String dateFin_p, String codeMembre_p, String msisdn_p, String imei_p) throws RavelException
  {
    Connection con = null;
    ResultSet rs = null;
    CallableStatement cs = null;
    final String methodName = "PG_IHM_MOV.P_GET_INFORMATIONS"; //$NON-NLS-1$
    _dsReadLock.lock();

    try
    {
      con = _datasource.getConnection();
      cs = con.prepareCall("{call PG_IHM_MOV.P_GET_INFORMATIONS(?,?,?,?,?,?,?,?,?,?,?) }"); //$NON-NLS-1$
      cs.setQueryTimeout(_readTimeoutSec);

      cs.setString("pi_DateDemande", date_p); //$NON-NLS-1$
      cs.setString("pi_DateDebut", dateDebut_p); //$NON-NLS-1$
      cs.setString("pi_DateFin", dateFin_p); //$NON-NLS-1$
      cs.setString("pi_CodeMembre", codeMembre_p); //$NON-NLS-1$
      cs.setString("pi_Imei", imei_p); //$NON-NLS-1$
      cs.setString("pi_Msisdn", msisdn_p); //$NON-NLS-1$

      cs.registerOutParameter("po_RESULT", OracleTypes.CURSOR); //$NON-NLS-1$
      cs.registerOutParameter(RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      cs.registerOutParameter(RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      cs.execute();
      List<InformationsDemande> resultat = new ArrayList<InformationsDemande>();

      Retour retour = getRetour(cs);

      rs = (ResultSet) cs.getObject("po_RESULT"); //$NON-NLS-1$

      if (StringConstants.OK.equals(retour.getResultat()) && (rs != null))
      {
        while (rs.next())
        {
          InformationsDemande informationsDemande = new InformationsDemande(rs);
          resultat.add(informationsDemande);
        }
      }

      return new ConnectorResponse<>(resultat, retour);
    }
    catch (SQLTimeoutException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("dateDebut: ").append(dateDebut_p).append("dateFin: ").append(dateFin_p).append("codeMembre: ").append(codeMembre_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

      // when insert takes too long
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, INSERTION_FAILED, MessageFormat.format(Messages.getString(MOV_CONNECTOR_ERREUR_MOV_TIMEOUT_SUR_NON_REPONSE), _readTimeoutSec));
      return new ConnectorResponse<>(null, retour);
    }
    catch (PoolExhaustedException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("dateDebut: ").append(dateDebut_p).append("dateFin: ").append(dateFin_p).append("codeMembre: ").append(codeMembre_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

      //no sessions/connections available in the connection pool
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, SESSION_UNAVAILABLE, Messages.getString(MOV_CONNECTOR_ERREUR_MOV_AUCUNE_SESSION));
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLRecoverableException e)
    {
      buildTechnicalMessage(e, tracabilite_p, methodName, new StringBuilder().append("dateDebut: ").append(dateDebut_p).append("dateFin: ").append(dateFin_p).append("codeMembre: ").append(codeMembre_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

      // when not able to connect
      Retour retour = RetourFactory.createKO(IMegConsts.CAT1, CONNEXION_FAILED, MessageFormat.format(Messages.getString(MOV_CONNECTOR_ERREUR_MOV_TIMEOUT_CONNEXION), _connectTimeoutSec));
      return new ConnectorResponse<>(null, retour);
    }
    catch (SQLException e)
    {
      throw buildTechnicalException(e, tracabilite_p, methodName, new StringBuilder().append("dateDebut: ").append(dateDebut_p).append("dateFin: ").append(dateFin_p).append("codeMembre: ").append(codeMembre_p).toString()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    }
    finally
    {
      if (cs != null)
      {
        try
        {
          cs.close();
        }
        catch (SQLException e)
        {
          //nothing to do
        }
      }
      if (con != null)
      {
        try
        {
          con.close();
        }
        catch (SQLException e)
        {
          //nothing to do
        }
      }
      _dsReadLock.unlock();
    }
  }

  /**
   * Map values from the result set to an Demande object
   *
   * @param demande_p
   *          object to be mapped
   * @param resultSet_p
   *          result set obtained from the stored procedure
   * @throws SQLException
   *           exception thrown while reading the result set
   */
  private void mapValuesFromResultSet(Demande demande_p, ResultSet resultSet_p) throws SQLException
  {
    demande_p.setDemande(resultSet_p.getLong("demande")); //$NON-NLS-1$
    demande_p.setImei(resultSet_p.getString("imei")); //$NON-NLS-1$
    demande_p.setCodeDemandeur(resultSet_p.getString("code_demandeur")); //$NON-NLS-1$
    demande_p.setCodeMembre(resultSet_p.getString("code_membre")); //$NON-NLS-1$
    demande_p.setCodeMotif(resultSet_p.getString("code_motif")); //$NON-NLS-1$
    demande_p.setMouvement(resultSet_p.getString("mouvement")); //$NON-NLS-1$
    demande_p.setFlgLuhn(resultSet_p.getString("flg_Luhn")); //$NON-NLS-1$
    demande_p.setFlgTac(resultSet_p.getString("flg_Tac")); //$NON-NLS-1$
    demande_p.setOrigine(resultSet_p.getString("origine")); //$NON-NLS-1$
    demande_p.setMsisdn(resultSet_p.getString("msisdn")); //$NON-NLS-1$
    demande_p.setService(resultSet_p.getString("service")); //$NON-NLS-1$
    demande_p.setFabricant(resultSet_p.getString("fabricant")); //$NON-NLS-1$
    demande_p.setDesignation(resultSet_p.getString("designation")); //$NON-NLS-1$
    demande_p.setDateInsertion(resultSet_p.getString("date_insertion")); //$NON-NLS-1$
    demande_p.setHeureInsertion(resultSet_p.getString("heure_insertion")); //$NON-NLS-1$
    demande_p.setInstanceImei(resultSet_p.getString("instance_imei")); //$NON-NLS-1$
    demande_p.setImeiUnique(resultSet_p.getString("imei_unique")); //$NON-NLS-1$
    demande_p.setStatut(resultSet_p.getString("statut")); //$NON-NLS-1$
    demande_p.setDescMotif(resultSet_p.getString("desc_motif")); //$NON-NLS-1$
    demande_p.setPriority(resultSet_p.getLong("priority")); //$NON-NLS-1$
    demande_p.setDateEtat(DateTimeTools.toLocalDateTime(resultSet_p.getTimestamp("date_etat"))); //$NON-NLS-1$
  }

  /**
   * Map value from the result set to an DemandeBotClosrsx
   *
   * @param demande_p
   *          object to be mapped
   * @param resultSet_p
   *          result set obtained from the stored procedure
   * @throws SQLException
   *           exception thrown while reading the result set
   */
  private void mapValuesFromResultSet(DemandeBotClosrsx demande_p, ResultSet resultSet_p) throws SQLException
  {
    demande_p.setCodeDemandeur(resultSet_p.getString("CODE_DEMANDEUR")); //$NON-NLS-1$
    demande_p.setCodeMembreExt(resultSet_p.getString("CODE_MEMBRE_EXT")); //$NON-NLS-1$
    demande_p.setCodeMotif(resultSet_p.getString("CODE_MOTIF")); //$NON-NLS-1$
    demande_p.setDemande(resultSet_p.getLong("DEMANDE")); //$NON-NLS-1$
    demande_p.setDescMotif(resultSet_p.getString("DESC_MOTIF")); //$NON-NLS-1$
    demande_p.setFlagTac(resultSet_p.getString("FLG_TAC")); //$NON-NLS-1$
    demande_p.setImei(resultSet_p.getString("IMEI")); //$NON-NLS-1$
    demande_p.setMouvement(resultSet_p.getString("MOUVEMENT")); //$NON-NLS-1$
    demande_p.setCodeGie(resultSet_p.getString("CODE_GIE")); //$NON-NLS-1$
  }
}
