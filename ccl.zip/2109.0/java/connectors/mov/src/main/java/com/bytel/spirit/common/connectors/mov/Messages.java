package com.bytel.spirit.common.connectors.mov;

import java.text.MessageFormat;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

/**
 *
 * @author $Author: voliveir $
 * @version ($Revision$ $Date: 2016-08-08 17:33:11 +0200 (lun., 08 août 2016) $)
 */
public final class Messages
{
  /**
   *
   */
  public static final String EXCEPTION = "MOV.ExceptionMessage";//$NON-NLS-1$
  /**
   * INVALID_PARAMETER
   */
  public static final String INVALID_PARAMETER = "MOVConnector.InvalidParameter";
  /**
   *
   */
  public static final String MISSING_PARAMETER = "MOV.MissingParameter";//$NON-NLS-1$
  /**
   *
   */
  public static final String TECHNICAL_EXCEPTION = "MOVConnector.TechnicalExceptionMessage";//$NON-NLS-1$
  /**
   *
   */
  private static final String BUNDLE_NAME = "com.bytel.spirit.common.connectors.mov.messages"; //$NON-NLS-1$
  /**
   *
   */
  private static final ResourceBundle RESOURCE_BUNDLE = ResourceBundle.getBundle(Messages.BUNDLE_NAME);

  /**
   * Gets the string.
   *
   * @param key_p
   *          the key
   * @return the value
   */
  public static String getString(String key_p)
  {
    try
    {
      return Messages.RESOURCE_BUNDLE.getString(key_p);
    }
    catch (MissingResourceException e)
    {
      return '!' + key_p + '!';
    }
  }

  /**
   * Returns a message formatted with the supplied pattern and arguments
   *
   * @param pattern_p
   * @param arguments_p
   * @return
   */
  public static String getString(String pattern_p, Object... arguments_p)
  {
    return MessageFormat.format(pattern_p, arguments_p);
  }

  /**
   *
   */
  private Messages()
  {
  }
}
