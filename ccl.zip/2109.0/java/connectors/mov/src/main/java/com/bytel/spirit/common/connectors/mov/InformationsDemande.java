/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.mov;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;

import com.bytel.ravel.common.utils.DateTimeTools;

/**
 *
 * @author lmerces
 * @version ($Revision$ $Date$)
 */
public class InformationsDemande
{
  /**
   * Constant with the value of the Table Column for IMEI
   */
  public static final String IMEI = "imei"; //$NON-NLS-1$

  /**
   * Constant with the value of the Table Column for ORIGINE
   */
  public static final String ORIGINE = "origine"; //$NON-NLS-1$

  /**
   * Constant with the value of the Table Column for CODE_MEMBRE
   */
  public static final String CODE_MEMBRE = "code_membre"; //$NON-NLS-1$

  /**
   * Constant with the value of the Table Column for MSISDN
   */
  public static final String MSISDN = "msisdn"; //$NON-NLS-1$

  /**
   * Constant with the value of the Table Column for SERVICE
   */
  public static final String SERVICE = "service"; //$NON-NLS-1$

  /**
   * Constant with the value of the Table Column for MOUVEMENT
   */
  public static final String MOUVEMENT = "mouvement"; //$NON-NLS-1$

  /**
   * Constant with the value of the Table Column for DATE_ETAT
   */
  public static final String DATE_ETAT = "date_etat"; //$NON-NLS-1$

  /**
   * Constant with the value of the Table Column for DERNIER_ETAT
   */
  public static final String DERNIER_ETAT = "dernier_etat"; //$NON-NLS-1$

  /**
   * Constant with the value of the Table Column for MOTIF
   */
  public static final String MOTIF = "motif"; //$NON-NLS-1$

  /**
   * Constant with the value of the Table Column for DATE_INSERTION
   */
  public static final String DATE_INSERTION = "date_insertion"; //$NON-NLS-1$

  /**
   * Constant with the value of the Table Column for HEURE_INSERTION
   */
  public static final String HEURE_INSERTION = "heure_insertion"; //$NON-NLS-1$

  /**
   * Field for imei
   */
  private String _imei;

  /**
   * Field for origine
   */
  private String _origine;

  /**
   * Field for code_membre
   */
  private String _codeMembre;

  /**
   * Field for msisdn
   */
  private String _msisdn;

  /**
   * Field for service
   */
  private String _service;

  /**
   * Field for mouvement
   */
  private String _mouvement;

  /**
   * Field for date_etat
   */
  private LocalDateTime _dateEtat;

  /**
   * Field for dernier_etat
   */
  private String _dernierEtat;

  /**
   * Field for motif
   */
  private String _motif;

  /**
   * Field for date_insertion
   */
  private String _dateInsertion;

  /**
   * Field for heure_insertion
   */
  private String _heureInsertion;

  /**
   * Constructor
   */
  public InformationsDemande()
  {
    super();
  }

  /**
   * Constructor
   *
   * @param rs_p
   *          resultSet
   * @throws SQLException
   *           exception
   */
  public InformationsDemande(ResultSet rs_p) throws SQLException
  {
    _imei = rs_p.getString(IMEI);
    _origine = rs_p.getString(ORIGINE);
    _codeMembre = rs_p.getString(CODE_MEMBRE);
    _msisdn = rs_p.getString(MSISDN);
    _service = rs_p.getString(SERVICE);
    _mouvement = rs_p.getString(MOUVEMENT);
    _dateEtat = DateTimeTools.toLocalDateTime(rs_p.getTimestamp(DATE_ETAT));
    _dernierEtat = rs_p.getString(DERNIER_ETAT);
    _motif = rs_p.getString(MOTIF);
    _dateInsertion = rs_p.getString(DATE_INSERTION);
    _heureInsertion = rs_p.getString(HEURE_INSERTION);
  }

  /**
   * Constructor
   *
   * @param imei_p
   *          imei
   * @param origine_p
   *          origine
   * @param codeMembre_p
   *          codeMembre
   * @param msisdn_p
   *          msisdn
   * @param service_p
   *          service
   * @param mouvement_p
   *          mouvement
   * @param dateEtat_p
   *          date etat
   * @param dernierEtat_p
   *          dernier etat
   * @param motif_p
   *          motif
   * @param dateInsertion_p
   *          date insertion
   * @param heureInsertion_p
   *          heure insertion
   */
  public InformationsDemande(String imei_p, String origine_p, String codeMembre_p, String msisdn_p, String service_p, String mouvement_p, LocalDateTime dateEtat_p, String dernierEtat_p, String motif_p, String dateInsertion_p, String heureInsertion_p)
  {
    super();
    _imei = imei_p;
    _origine = origine_p;
    _codeMembre = codeMembre_p;
    _msisdn = msisdn_p;
    _service = service_p;
    _mouvement = mouvement_p;
    _dateEtat = dateEtat_p;
    _dernierEtat = dernierEtat_p;
    _motif = motif_p;
    _dateInsertion = dateInsertion_p;
    _heureInsertion = heureInsertion_p;
  }

  /**
   * @return the codeMembre
   */
  public String getCodeMembre()
  {
    return _codeMembre;
  }

  /**
   * @return the dateEtat
   */
  public LocalDateTime getDateEtat()
  {
    return _dateEtat;
  }

  /**
   * @return the dateInsertion
   */
  public String getDateInsertion()
  {
    return _dateInsertion;
  }

  /**
   * @return the dernierEtat
   */
  public String getDernierEtat()
  {
    return _dernierEtat;
  }

  /**
   * @return the heureInsertion
   */
  public String getHeureInsertion()
  {
    return _heureInsertion;
  }

  /**
   * @return the imei
   */
  public String getImei()
  {
    return _imei;
  }

  /**
   * @return the motif
   */
  public String getMotif()
  {
    return _motif;
  }

  /**
   * @return the mouvement
   */
  public String getMouvement()
  {
    return _mouvement;
  }

  /**
   * @return the msisdn
   */
  public String getMsisdn()
  {
    return _msisdn;
  }

  /**
   * @return the origine
   */
  public String getOrigine()
  {
    return _origine;
  }

  /**
   * @return the service
   */
  public String getService()
  {
    return _service;
  }

  /**
   * @param codeMembre_p
   *          the codeMembre to set
   */
  public void setCodeMembre(String codeMembre_p)
  {
    _codeMembre = codeMembre_p;
  }

  /**
   * @param dateEtat_p
   *          the dateEtat to set
   */
  public void setDateEtat(LocalDateTime dateEtat_p)
  {
    _dateEtat = dateEtat_p;
  }

  /**
   * @param dateInsertion_p
   *          the dateInsertion to set
   */
  public void setDateInsertion(String dateInsertion_p)
  {
    _dateInsertion = dateInsertion_p;
  }

  /**
   * @param dernierEtat_p
   *          the dernierEtat to set
   */
  public void setDernierEtat(String dernierEtat_p)
  {
    _dernierEtat = dernierEtat_p;
  }

  /**
   * @param heureInsertion_p
   *          the heureInsertion to set
   */
  public void setHeureInsertion(String heureInsertion_p)
  {
    _heureInsertion = heureInsertion_p;
  }

  /**
   * @param imei_p
   *          the imei to set
   */
  public void setImei(String imei_p)
  {
    _imei = imei_p;
  }

  /**
   * @param motif_p
   *          the motif to set
   */
  public void setMotif(String motif_p)
  {
    _motif = motif_p;
  }

  /**
   * @param mouvement_p
   *          the mouvement to set
   */
  public void setMouvement(String mouvement_p)
  {
    _mouvement = mouvement_p;
  }

  /**
   * @param msisdn_p
   *          the msisdn to set
   */
  public void setMsisdn(String msisdn_p)
  {
    _msisdn = msisdn_p;
  }

  /**
   * @param origine_p
   *          the origine to set
   */
  public void setOrigine(String origine_p)
  {
    _origine = origine_p;
  }

  /**
   * @param service_p
   *          the service to set
   */
  public void setService(String service_p)
  {
    _service = service_p;
  }

}
