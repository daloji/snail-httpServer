/*******************************************************************************
 * $Id: Demande.java 33877 2017-01-25 17:27:24Z lmerces $
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.mov;

import java.time.LocalDateTime;

/**
 * Stores information retrieved from the stored procedures P_001_consult_MOV_ListeDemande and
 * P_002_cons_MOV_DerniereDemande
 *
 * @author $Author: vborrego $
 *
 */
public class Demande
{
  /**
   * Field for CodeDemandeur
   */
  private String _codeDemandeur;

  /**
   * Field for CodeMembre
   */
  private String _codeMembre;

  /**
   * Field for CodeMotif
   */
  private String _codeMotif;

  /**
   * Field for Date etat
   */
  private LocalDateTime _dateEtat;

  /**
   * Field for Dateinsertion
   */
  private String _dateInsertion;

  /**
   * Field for Demande
   */
  private Long _demande;

  /**
   * Field for DescMotif
   */
  private String _descMotif;

  /**
   * Field for Designation
   */
  private String _designation;

  /**
   * Field for Fabricant
   */
  private String _fabricant;

  /**
   * Field for FlgLuhn
   */
  private String _flgLuhn;

  /**
   * Field for FlgTac
   */
  private String _flgTac;

  /**
   * Field for HeureInsertion
   */
  private String _heureInsertion;

  /**
   * Field for Imei
   */
  private String _imei;

  /**
   * Field for ImeiUnique
   */
  private String _imeiUnique;

  /**
   * Field for InstanceImei
   */
  private String _instanceImei;

  /**
   * Field for mouvement
   */
  private String _mouvement;

  /**
   * Field for Msisdn
   */
  private String _msisdn;

  /**
   * Field for Origine
   */
  private String _origine;

  /**
   * Field for Priority
   */
  private Long _priority;

  /**
   * Field for Service
   */
  private String _service;

  /**
   * Field for Statut
   */
  private String _statut;

  /**
   *
   * @return value for the field CodeDemandeur
   */
  public String getCodeDemandeur()
  {
    return _codeDemandeur;
  }

  /**
   *
   * @return value for the field CodeMembre
   */
  public String getCodeMembre()
  {
    return _codeMembre;
  }

  /**
   *
   * @return value for the field CodeMotif
   */
  public String getCodeMotif()
  {
    return _codeMotif;
  }

  /**
   *
   * @return value for the field date etat
   */
  public LocalDateTime getDateEtat()
  {
    return _dateEtat;
  }

  /**
   *
   * @return value for the field DateInsertion
   */
  public String getDateInsertion()
  {
    return _dateInsertion;
  }

  /**
   *
   * @return the value for the field Demande
   */
  public Long getDemande()
  {
    return _demande;
  }

  /**
   *
   * @return value for the field DescMotif
   */
  public String getDescMotif()
  {
    return _descMotif;
  }

  /**
   *
   * @return value for the field Designation
   */
  public String getDesignation()
  {
    return _designation;
  }

  /**
   *
   * @return value for the field Fabricant
   */
  public String getFabricant()
  {
    return _fabricant;
  }

  /**
   *
   * @return value for the field FlgLuhn
   */
  public String getFlgLuhn()
  {
    return _flgLuhn;
  }

  /**
   *
   * @return value for the field FlgTac
   */
  public String getFlgTac()
  {
    return _flgTac;
  }

  /**
   *
   * @return value for the field HeureInsertion
   */
  public String getHeureInsertion()
  {
    return _heureInsertion;
  }

  /**
   *
   * @return value for the field Imei
   */
  public String getImei()
  {
    return _imei;
  }

  /**
   *
   * @return value for the field ImeiUnique
   */
  public String getImeiUnique()
  {
    return _imeiUnique;
  }

  /**
   *
   * @return value for the field InstanceImei
   */
  public String getInstanceImei()
  {
    return _instanceImei;
  }

  /**
   *
   * @return value for the field Mouvement
   */
  public String getMouvement()
  {
    return _mouvement;
  }

  /**
   *
   * @return value for the field Msisdn
   */
  public String getMsisdn()
  {
    return _msisdn;
  }

  /**
   *
   * @return value for the field Origine
   */
  public String getOrigine()
  {
    return _origine;
  }

  /**
   *
   * @return value for the field Priority
   */
  public Long getPriority()
  {
    return _priority;
  }

  /**
   *
   * @return value for the field Service
   */
  public String getService()
  {
    return _service;
  }

  /**
   *
   * @return value for the field Statut
   */
  public String getStatut()
  {
    return _statut;
  }

  /**
   *
   * @param codeDemandeur_p
   *          value for the field CodeDemandeur
   */
  public void setCodeDemandeur(String codeDemandeur_p)
  {
    this._codeDemandeur = codeDemandeur_p;
  }

  /**
   *
   * @param codeMembre_p
   *          value for the field CodeMembre
   */
  public void setCodeMembre(String codeMembre_p)
  {
    this._codeMembre = codeMembre_p;
  }

  /**
   *
   * @param codeMotif_p
   *          value for the field CodeMotif
   */
  public void setCodeMotif(String codeMotif_p)
  {
    this._codeMotif = codeMotif_p;
  }

  /**
   *
   * @param dateEtat_p
   *          value for the field date etat
   */
  public void setDateEtat(LocalDateTime dateEtat_p)
  {

    this._dateEtat = dateEtat_p;

  }

  /**
   *
   * @param dateInsertion_p
   *          value for the field DateInsertion
   */
  public void setDateInsertion(String dateInsertion_p)
  {
    this._dateInsertion = dateInsertion_p;
  }

  /**
   *
   * @param demande_p
   *          value for the field Demande
   */
  public void setDemande(Long demande_p)
  {
    this._demande = demande_p;
  }

  /**
   *
   * @param descMotif_p
   *          DescMotif
   */
  public void setDescMotif(String descMotif_p)
  {
    this._descMotif = descMotif_p;
  }

  /**
   *
   * @param designation_p
   *          value for the field Designation
   */
  public void setDesignation(String designation_p)
  {
    this._designation = designation_p;
  }

  /**
   *
   * @param fabricant_p
   *          value for the field Fabricant
   */
  public void setFabricant(String fabricant_p)
  {
    this._fabricant = fabricant_p;
  }

  /**
   *
   * @param flgLuhn_p
   *          value for the field FlgLuhn
   */
  public void setFlgLuhn(String flgLuhn_p)
  {
    this._flgLuhn = flgLuhn_p;
  }

  /**
   *
   * @param flgTac_p
   *          value for the field FlgTac
   */
  public void setFlgTac(String flgTac_p)
  {
    this._flgTac = flgTac_p;
  }

  /**
   *
   * @param heureInsertion_p
   *          value for the field HeureInsertion
   */
  public void setHeureInsertion(String heureInsertion_p)
  {
    this._heureInsertion = heureInsertion_p;
  }

  /**
   *
   * @param imei_p
   *          value for the field Imei
   */
  public void setImei(String imei_p)
  {
    this._imei = imei_p;
  }

  /**
   *
   * @param imeiUnique_p
   *          value for the field ImeiUnique
   */
  public void setImeiUnique(String imeiUnique_p)
  {
    this._imeiUnique = imeiUnique_p;
  }

  /**
   *
   * @param instanceImei_p
   *          value for the field InstanceImei
   */
  public void setInstanceImei(String instanceImei_p)
  {
    this._instanceImei = instanceImei_p;
  }

  /**
   *
   * @param mouvement_p
   *          value for the field Mouvement
   */
  public void setMouvement(String mouvement_p)
  {
    this._mouvement = mouvement_p;
  }

  /**
   *
   * @param msisdn_p
   *          value for the field Msisdn
   */
  public void setMsisdn(String msisdn_p)
  {
    this._msisdn = msisdn_p;
  }

  /**
   *
   * @param origine_p
   *          value for the field Origine
   */
  public void setOrigine(String origine_p)
  {
    this._origine = origine_p;
  }

  /**
   *
   * @param priority_p
   *          value for the field Priority
   */
  public void setPriority(Long priority_p)
  {
    this._priority = priority_p;
  }

  /**
   *
   * @param service_p
   *          value for the field Service
   */
  public void setService(String service_p)
  {
    this._service = service_p;
  }

  /**
   *
   * @param statut_p
   *          value for the field Statut
   */
  public void setStatut(String statut_p)
  {
    this._statut = statut_p;
  }
}
