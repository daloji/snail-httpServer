/*******************************************************************************
 * $Id: IMOV.java 33877 2017-01-25 17:27:24Z lmerces $
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.mov;

import java.sql.Timestamp;
import java.util.List;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

/**
 * The Interface IMOV for MOV (MObiles Voles) DB operations.
 *
 * @author $Author: lmerces $
 * @version ($Revision$ $Date: 2017-01-25 18:27:24 +0100 (mer., 25 janv. 2017) $)
 */
public interface IMOV
{
  /**
   * @param tracabilite_p
   * @param codeMembres_p
   * @param dateDebut_p
   * @param dateFin_p
   * @return
   * @throws RavelException
   */
  ConnectorResponse<List<Indicateur>, Retour> calculerNombreBlacklistage(Tracabilite tracabilite_p, String codeMembres_p, String dateDebut_p, String dateFin_p) throws RavelException;

  /**
   * @param tracabilite_p
   * @param codeMembres_p
   * @param dateDebut_p
   * @param dateFin_p
   * @return
   * @throws RavelException
   */
  ConnectorResponse<List<Indicateur>, Retour> calculerNombreDeblacklistage(Tracabilite tracabilite_p, String codeMembres_p, String dateDebut_p, String dateFin_p) throws RavelException;

  /**
   * Invocation of the stored procedure P_007_CONS_DEMAND_BOT_CLOSRSX. Search the requests of code member 'BOT' and last
   * state CLOSRSX without error (0 or -1000)
   *
   * @param tracabilite_p
   *          Tracabilite
   *
   * @return response from the stored procedure
   *
   * @throws RavelException
   *           on error
   */
  ConnectorResponse<List<DemandeBotClosrsx>, Retour> consultDemandeBotClosrsx(Tracabilite tracabilite_p) throws RavelException;

  /**
   * Appel à la procédure stockée « P_GET_INFORMATIONS »
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param date_p
   *          date
   * @param dateDebut_p
   *          date début
   * @param dateFin_p
   *          date fin
   * @return {@link InformationsDemande}
   * @throws RavelException
   *           exception thrown
   */
  ConnectorResponse<List<InformationsDemande>, Retour> consulterInformationsParDate(Tracabilite tracabilite_p, String date_p, String dateDebut_p, String dateFin_p) throws RavelException;

  /**
   * Appel à la procédure stockée « P_GET_INFORMATIONS »
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param date_p
   *          date
   * @param dateDebut_p
   *          date début
   * @param dateFin_p
   *          date fin
   * @param codeMembre_p
   *          code membre
   * @return {@link InformationsDemande}
   * @throws RavelException
   *           exception thrown
   */
  ConnectorResponse<List<InformationsDemande>, Retour> consulterInformationsParDateCodeMembre(Tracabilite tracabilite_p, String date_p, String dateDebut_p, String dateFin_p, String codeMembre_p) throws RavelException;

  /**
   * Appel à la procédure stockée « P_GET_INFORMATIONS »
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param imei_p
   *          imei
   * @return {@link InformationsDemande}
   * @throws RavelException
   *           exception thrown
   */
  ConnectorResponse<List<InformationsDemande>, Retour> consulterInformationsParImei(Tracabilite tracabilite_p, String imei_p) throws RavelException;

  /**
   * Appel à la procédure stockée « P_GET_INFORMATIONS »
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param imei_p
   *          imei
   * @param date_p
   *          date
   * @param dateDebut_p
   *          date début
   * @param dateFin_p
   *          date fin
   * @return {@link InformationsDemande}
   * @throws RavelException
   *           exception thrown
   */
  ConnectorResponse<List<InformationsDemande>, Retour> consulterInformationsParImeiDate(Tracabilite tracabilite_p, String imei_p, String date_p, String dateDebut_p, String dateFin_p) throws RavelException;

  /**
   * Appel à la procédure stockée « P_GET_INFORMATIONS »
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param msisdn_p
   *          msisdn
   * @return {@link InformationsDemande}
   * @throws RavelException
   *           exception thrown
   */
  ConnectorResponse<List<InformationsDemande>, Retour> consulterInformationsParMsisdn(Tracabilite tracabilite_p, String msisdn_p) throws RavelException;

  /**
   * Appel à la procédure stockée « P_GET_INFORMATIONS »
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param msisdn_p
   *          msisdn
   * @param date_p
   *          date
   * @param dateDebut_p
   *          date début
   * @param dateFin_p
   *          date fin
   * @return {@link InformationsDemande}
   * @throws RavelException
   *           exception thrown
   */
  ConnectorResponse<List<InformationsDemande>, Retour> consulterInformationsParMsisdnDate(Tracabilite tracabilite_p, String msisdn_p, String date_p, String dateDebut_p, String dateFin_p) throws RavelException;

  /**
   * Invocation of the stored procedure P_002_cons_MOV_DerniereDemande. Search the last update made for the supplied
   * IMEI.
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param imei_p
   *          IMEI to be used by the stored procedure
   * @return response from the stored procedure
   * @throws RavelException
   *           exception thrown
   */
  ConnectorResponse<Demande, Retour> consultMOVDerniereDemande(Tracabilite tracabilite_p, String imei_p) throws RavelException;

  /**
   * Invocation of the stored procedure P_001_consult_MOV_ListeDemande. Search the update made for the supplied IMEI.
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param imei_p
   *          IMEI to be used by the stored procedure
   * @return response from the stored procedure
   * @throws RavelException
   *           exception thrown
   */
  ConnectorResponse<Demande[], Retour> consultMOVListeDemande(Tracabilite tracabilite_p, String imei_p) throws RavelException;

  /**
   * Appel à la procédure stockée P_003_GESTION_DEMANDE_BLKDBLK
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param demandeur_p
   *          Demandeur
   * @param imei_p
   *          IMEI
   * @param code_membre_p
   *          Code Membre
   * @param code_motif_p
   *          Code Motif
   * @param mouvement_p
   *          Mouvement
   * @param flg_luhn_p
   *          LUHN
   * @param origine_p
   *          Origine
   * @param msisdn_p
   *          MSISDN
   * @param service_p
   *          Service
   * @param fabricant_p
   *          Fabricant
   * @param designation_p
   *          Designation
   * @param fichier_source_p
   *          Fichier Source
   * @return une flag TAC
   * @throws RavelException
   *           exception
   */
  ConnectorResponse<Integer, Retour> insererDemandeMOV(Tracabilite tracabilite_p, String imei_p, String demandeur_p, String code_membre_p, String code_motif_p, String mouvement_p, int flg_luhn_p, String origine_p, String msisdn_p, String service_p, String fabricant_p, String designation_p, String fichier_source_p) throws RavelException;

  /**
   * Appel à la procédure stockée P_008_INSERT_NEW_ETAT
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param demande_p
   *          The Demande number
   * @param statut_p
   *          The statut
   * @param fichier_p
   *          The filename
   * @param dateEtat_p
   *          The Etat date
   * @param codeErreur_p
   *          The error code
   * @param descErreur_p
   *          The error description
   * @param chrono_p
   *          The chrono number
   * @param recyclage_p
   *          The recyclage
   * @return response from the stored procedure
   * @throws RavelException
   *           on error
   */
  ConnectorResponse<Boolean, Retour> insertNewEtat(Tracabilite tracabilite_p, long demande_p, String statut_p, String fichier_p, Timestamp dateEtat_p, String codeErreur_p, String descErreur_p, Long chrono_p, Long recyclage_p) throws RavelException;

  /**
   * Appel à la procédure stockée P_005_CHECK_CODE_MEMBRE
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param code_membre_p
   *          Le code membre à vérifier
   * @return nombre d'occurrences ({@link Retour})
   * @throws RavelException
   *           exception thrown
   */
  ConnectorResponse<Long, Retour> verifierCodeMembre(Tracabilite tracabilite_p, String code_membre_p) throws RavelException;

  /**
   * Appel à la procédure stockée P_004_CHECK_CODE_MOTIF
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param code_motif_p
   *          Le code motif à vérifier
   * @return nombre d'occurrences ({@link Retour})
   * @throws RavelException
   *           exception thrown
   */
  ConnectorResponse<Long, Retour> verifierCodeMotif(Tracabilite tracabilite_p, String code_motif_p) throws RavelException;

  /**
   * Appel à la procédure stockée P_006_CHECK_DEDOUBLONNAGE
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param imei_p
   *          L'IMEI à vérifier
   * @param mouvement_p
   *          Mouvement
   * @param code_membre_p
   *          Code membre
   * @return true or false si demande valide ({@link Retour})
   * @throws RavelException
   *           exception thrown
   */
  ConnectorResponse<Boolean, Retour> verifierDedoublonnage(Tracabilite tracabilite_p, String imei_p, String mouvement_p, String code_membre_p) throws RavelException;
}
