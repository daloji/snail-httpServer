/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.mov;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author mcampos
 * @version ($Revision$ $Date$)
 */
public class Indicateur
{
  /**
   * Const for Nombre
   */
  private static final String NOMBRE = "NOMBRE"; //$NON-NLS-1$

  /**
   * Const for CodeMembre
   */
  private static final String CODEMEMBRE = "CODE_MEMBRE"; //$NON-NLS-1$

  /**
   * Field for CodeMembre
   */
  private String _codeMembre;

  /**
   * Field for Nombre
   */
  private Long _nombre;

  /**
   * @param nombre_p
   * @param codeMembre_p
   */
  public Indicateur(Long nombre_p, String codeMembre_p)
  {
    _nombre = nombre_p;
    _codeMembre = codeMembre_p;
  }

  /**
   * @param resultSet_p
   * @param nombre_p
   * @param codeMembre_p
   * @throws SQLException
   */
  public Indicateur(ResultSet resultSet_p) throws SQLException
  {
    _nombre = resultSet_p.getLong(NOMBRE);
    _codeMembre = resultSet_p.getString(CODEMEMBRE);
  }

  /**
   * @return the codeMembre
   */
  public String getCodeMembre()
  {
    return _codeMembre;
  }

  /**
   * @return the nombre
   */
  public Long getNombre()
  {
    return _nombre;
  }

  /**
   * @param codeMembre_p
   *          the codeMembre to set
   */
  public void setCodeMembre(String codeMembre_p)
  {
    _codeMembre = codeMembre_p;
  }

  /**
   * @param nombre_p
   *          the nombre to set
   */
  public void setNombre(Long nombre_p)
  {
    _nombre = nombre_p;
  }
}
