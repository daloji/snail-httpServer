/*******************************************************************************
 * $Id: IMOVConnector.java 28744 2015-10-13 17:42:15Z vborrego $
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.mov;

import com.bytel.ravel.services.connector.IConnector;

/**
 * Adds the Connector ID to the IMOV interface
 *
 * @author $Author: vborrego $
 * @version ($Revision$ $Date: 2015-10-13 19:42:15 +0200 (mar., 13 oct. 2015) $)
 */
public interface IMOVConnector extends IConnector, IMOV
{
  /**
   * The id to retrieve the connector.
   */
  String BEAN_ID = "MOVConnector"; //$NON-NLS-1$
}
