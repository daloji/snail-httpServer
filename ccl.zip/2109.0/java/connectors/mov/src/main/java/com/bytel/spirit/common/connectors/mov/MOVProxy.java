/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.mov;

import java.sql.Timestamp;
import java.util.List;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.probes.AvgDoubleCollectorItem;
import com.bytel.ravel.common.probes.AvgFlowPerSecondCollector;
import com.bytel.ravel.common.probes.RavelProbeConfigurationManager;
import com.bytel.ravel.services.connector.BaseDBProxy;
import com.bytel.ravel.services.connector.ConnectorExecution;
import com.bytel.ravel.services.connector.ConnectorManager;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

/**
 *
 * @author dangelis
 * @version ($Revision$ $Date$)
 */
public class MOVProxy extends BaseDBProxy implements IMOV
{
  /**
   * Proxy instance.
   */
  private static final MOVProxy INSTANCE = new MOVProxy();

  /**
   * Gets the single instance of MOVProxy.
   *
   * @return The MOV proxy instance.
   */
  public static MOVProxy getInstance()
  {
    return MOVProxy.INSTANCE;
  }

  /**
   * Probe: measure the average execution time of the psConsultMovListeDemande call per second.
   */
  protected AvgFlowPerSecondCollector _avg_psConsultMovListeDemande_call_counter;
  /**
   * Probe: measure the average execution time of the psConsultMovDerniereDemande call per second.
   */
  protected AvgFlowPerSecondCollector _avg_psConsultMovDerniereDemande_call_counter;
  /**
   * Probe: measure the average execution time of the psConsultDemandeBotClosrsx call per second.
   */
  protected AvgFlowPerSecondCollector _avg_psConsultDemandeBotClosrsx_call_counter;
  /**
   * Probe: measure the average execution time of the psInsertNewEtat call per second;
   */
  protected AvgFlowPerSecondCollector _avg_psInsertNewEtat_call_counter;

  /**
   * Probe: measure the average execution time of the psVerifierCodeMembre call per second.
   */
  protected AvgFlowPerSecondCollector _avg_psVerifierCodeMembre_call_counter;

  /**
   * Probe: measure the average execution time of the psVerifierCodeMotif call per second.
   */
  protected AvgFlowPerSecondCollector _avg_psVerifierCodeMotif_call_counter;

  /**
   * Probe: measure the average execution time of the psVerifierDedoublonnage call per second.
   */
  protected AvgFlowPerSecondCollector _avg_psVerifierDedoublonnage_call_counter;

  /**
   * Probe: measure the average execution time of the psInsererDemandeMOV call per second.
   */
  protected AvgFlowPerSecondCollector _avg_psInsererDemandeMOV_call_counter;

  /**
   * Probe: measure the average execution time of the psConsulterInformationsParDate call per second.
   */
  protected AvgFlowPerSecondCollector _avg_psConsulterInformationsParDate_call_counter;

  /**
   * Probe: measure the average execution time of the psConsulterInformationsParDate call per second.
   */
  protected AvgFlowPerSecondCollector _avg_psConsulterInformationsParDateCodeMembre_call_counter;

  /**
   * Probe: measure the average execution time of the psConsulterInformationsParImei call per second.
   */
  protected AvgFlowPerSecondCollector _avg_psConsulterInformationsParImei_call_counter;

  /**
   * Probe: measure the average execution time of the psConsulterInformationsParImeiDate call per second.
   */
  protected AvgFlowPerSecondCollector _avg_psConsulterInformationsParImeiDate_call_counter;

  /**
   * Probe: measure the average execution time of the psConsulterInformationsParMsisdn call per second.
   */
  protected AvgFlowPerSecondCollector _avg_psConsulterInformationsParMsisdn_call_counter;

  /**
   * Probe: measure the average execution time of the psConsulterInformationsParMsisdnDate call per second.
   */
  protected AvgFlowPerSecondCollector _avg_psConsulterInformationsParMsisdnDate_call_counter;

  /**
   * Probe: measure the average execution time of the psconsultMovListeDemande operation.
   */
  protected AvgDoubleCollectorItem _avg_psconsultMovListeDemande_ExecTime;
  /**
   * Probe: measure the average execution time of the psconsultMovDerniereDemande operation.
   */
  protected AvgDoubleCollectorItem _avg_psconsultMovDerniereDemande_ExecTime;
  /**
   * Probe: measure the average execution time of the psConsultDemandeBotClosrsx operation.
   */
  protected AvgDoubleCollectorItem _avg_psConsultDemandeBotClosrsx_ExecTime;
  /**
   * Probe: measure the average execution time of the psInsertNewEtat operation
   */
  protected AvgDoubleCollectorItem _avg_psInsertNewEtat_ExecTime;

  /**
   * Probe: measure the average execution time of the psVerifierCodeMembre operation.
   */
  protected AvgDoubleCollectorItem _avg_psVerifierCodeMembre_ExecTime;

  /**
   * Probe: measure the average execution time of the psVerifierCodeMotif operation.
   */
  protected AvgDoubleCollectorItem _avg_psVerifierCodeMotif_ExecTime;

  /**
   * Probe: measure the average execution time of the psVerifierDedoublonnage operation.
   */
  protected AvgDoubleCollectorItem _avg_psVerifierDedoublonnage_ExecTime;

  /**
   * Probe: measure the average execution time of the psInsererDemandeMOV operation.
   */
  protected AvgDoubleCollectorItem _avg_psInsererDemandeMOV_ExecTime;

  /**
   * Probe: measure the average execution time of the psConsulterInformationsParDate operation.
   */
  protected AvgDoubleCollectorItem _avg_psConsulterInformationsParDate_ExecTime;

  /**
   * Probe: measure the average execution time of the psConsulterInformationsParDateCodeMembre operation.
   */
  protected AvgDoubleCollectorItem _avg_psConsulterInformationsParDateCodeMembre_ExecTime;

  /**
   * Probe: measure the average execution time of the psConsulterInformationsParImei operation.
   */
  protected AvgDoubleCollectorItem _avg_psConsulterInformationsParImei_ExecTime;

  /**
   * Probe: measure the average execution time of the psConsulterInformationsParImeiDate operation.
   */
  protected AvgDoubleCollectorItem _avg_psConsulterInformationsParImeiDate_ExecTime;

  /**
   * Probe: measure the average execution time of the psConsulterInformationsParMsisdn operation.
   */
  protected AvgDoubleCollectorItem _avg_psConsulterInformationsParMsisdn_ExecTime;

  /**
   * Probe: measure the average execution time of the psConsulterInformationsParMsisdnDate operation.
   */
  protected AvgDoubleCollectorItem _avg_psConsulterInformationsParMsisdnDate_ExecTime;
  /**
   * Probe: measure the average execution time of the psCalculerNombreBlacklistage call per second.
   */
  protected AvgFlowPerSecondCollector _avg_psCalculerNombreBlacklistage_call_counter;
  /**
   * Probe: measure the average execution time of the psCalculerNombreBlacklistage operation.
   */
  protected AvgDoubleCollectorItem _avg_psCalculerNombreBlacklistage_ExecTime;
  /**
   * Probe: measure the average execution time of the psCalculerNombreDeblacklistage call per second.
   */
  protected AvgFlowPerSecondCollector _avg_psCalculerNombreDeblacklistage_call_counter;
  /**
   * Probe: measure the average execution time of the psCalculerNombreDeblacklistage operation.
   */
  protected AvgDoubleCollectorItem _avg_psCalculerNombreDeblacklistage_ExecTime;

  /**
   * Default constructor.
   */
  public MOVProxy()
  {
    // probes
    RavelProbeConfigurationManager manager = RavelProbeConfigurationManager.getInstance();
    String proxyName = MOVProxy.class.getName();
    _avg_psConsultMovDerniereDemande_call_counter = manager.createAvgFlowPerSecondCollector("Avg_psConsultMovDerniereDemande_call_per_second", proxyName); //$NON-NLS-1$
    _avg_psconsultMovDerniereDemande_ExecTime = manager.createAvgDoubleCollectorItem("Avg_psconsultMovDerniereDemande_ExecTime", proxyName); //$NON-NLS-1$

    _avg_psConsultMovListeDemande_call_counter = manager.createAvgFlowPerSecondCollector("Avg_psConsultMovListeDemande_call_per_second", proxyName); //$NON-NLS-1$
    _avg_psconsultMovListeDemande_ExecTime = manager.createAvgDoubleCollectorItem("Avg_psconsultMovListeDemande_ExecTime", proxyName); //$NON-NLS-1$

    _avg_psVerifierCodeMembre_call_counter = manager.createAvgFlowPerSecondCollector("Avg_psVerifierCodeMembre_call_per_second", proxyName); //$NON-NLS-1$
    _avg_psVerifierCodeMembre_ExecTime = manager.createAvgDoubleCollectorItem("Avg_psVerifierCodeMembre_ExecTime", proxyName); //$NON-NLS-1$

    _avg_psVerifierCodeMotif_call_counter = manager.createAvgFlowPerSecondCollector("Avg_psVerifierCodeMotif_call_per_second", proxyName); //$NON-NLS-1$
    _avg_psVerifierCodeMotif_ExecTime = manager.createAvgDoubleCollectorItem("Avg_psVerifierCodeMotif_ExecTime", proxyName); //$NON-NLS-1$

    _avg_psVerifierDedoublonnage_call_counter = manager.createAvgFlowPerSecondCollector("Avg_psVerifierDedoublonnage_call_per_second", proxyName); //$NON-NLS-1$
    _avg_psVerifierDedoublonnage_ExecTime = manager.createAvgDoubleCollectorItem("Avg_psVerifierDedoublonnage_ExecTime", proxyName); //$NON-NLS-1$

    _avg_psConsultDemandeBotClosrsx_call_counter = manager.createAvgFlowPerSecondCollector("Avg_psConsultDemandeBotClosrsx_call_per_second", proxyName); //$NON-NLS-1$
    _avg_psConsultDemandeBotClosrsx_ExecTime = manager.createAvgDoubleCollectorItem("Avg_psConsultDemandeBotClosrsx_ExecTime", proxyName); //$NON-NLS-1$

    _avg_psInsererDemandeMOV_call_counter = manager.createAvgFlowPerSecondCollector("Avg_psInsererDemandeMOV_call_per_second", proxyName); //$NON-NLS-1$
    _avg_psInsererDemandeMOV_ExecTime = manager.createAvgDoubleCollectorItem("Avg_psInsererDemandeMOV_ExecTime", proxyName); //$NON-NLS-1$

    _avg_psInsertNewEtat_call_counter = manager.createAvgFlowPerSecondCollector("Avg_psInsertNewEtat_call_per_second", proxyName); //$NON-NLS-1$
    _avg_psInsertNewEtat_ExecTime = manager.createAvgDoubleCollectorItem("Avg_psInsertNewEtat_ExecTime", proxyName); //$NON-NLS-1$

    _avg_psConsulterInformationsParDate_call_counter = manager.createAvgFlowPerSecondCollector("Avg_psConsulterInformationsParDate_call_per_second", proxyName); //$NON-NLS-1$
    _avg_psConsulterInformationsParDate_ExecTime = manager.createAvgDoubleCollectorItem("Avg_psConsulterInformationsParDate_ExecTime", proxyName); //$NON-NLS-1$
    _avg_psConsulterInformationsParDateCodeMembre_call_counter = manager.createAvgFlowPerSecondCollector("Avg_psConsulterInformationsParDateCodeMembre_call_per_second", proxyName); //$NON-NLS-1$
    _avg_psConsulterInformationsParDateCodeMembre_ExecTime = manager.createAvgDoubleCollectorItem("Avg_psConsulterInformationsParDateCodeMembre_ExecTime", proxyName); //$NON-NLS-1$
    _avg_psConsulterInformationsParImei_call_counter = manager.createAvgFlowPerSecondCollector("Avg_psConsulterInformationsParImei_call_per_second", proxyName); //$NON-NLS-1$
    _avg_psConsulterInformationsParImei_ExecTime = manager.createAvgDoubleCollectorItem("Avg_psConsulterInformationsParImei_ExecTime", proxyName); //$NON-NLS-1$
    _avg_psConsulterInformationsParImeiDate_call_counter = manager.createAvgFlowPerSecondCollector("Avg_psConsulterInformationsParImeiDate_call_per_second", proxyName); //$NON-NLS-1$
    _avg_psConsulterInformationsParImeiDate_ExecTime = manager.createAvgDoubleCollectorItem("Avg_psConsulterInformationsParImeiDate_ExecTime", proxyName); //$NON-NLS-1$
    _avg_psConsulterInformationsParMsisdn_call_counter = manager.createAvgFlowPerSecondCollector("Avg_psConsulterInformationsParMsisdn_call_per_second", proxyName); //$NON-NLS-1$
    _avg_psConsulterInformationsParMsisdn_ExecTime = manager.createAvgDoubleCollectorItem("Avg_psConsulterInformationsParMsisdn_ExecTime", proxyName); //$NON-NLS-1$
    _avg_psConsulterInformationsParMsisdnDate_call_counter = manager.createAvgFlowPerSecondCollector("Avg_psConsulterInformationsParMsisdnDate_call_per_second", proxyName); //$NON-NLS-1$
    _avg_psConsulterInformationsParMsisdnDate_ExecTime = manager.createAvgDoubleCollectorItem("Avg_psConsulterInformationsParMsisdnDate_ExecTime", proxyName); //$NON-NLS-1$

    _avg_psCalculerNombreBlacklistage_call_counter = manager.createAvgFlowPerSecondCollector("Avg_psCalculerNombreBlacklistage_call_per_second", proxyName); //$NON-NLS-1$
    _avg_psCalculerNombreBlacklistage_ExecTime = manager.createAvgDoubleCollectorItem("Avg_psCalculerNombreBlacklistage_ExecTime", proxyName); //$NON-NLS-1$
    _avg_psCalculerNombreDeblacklistage_call_counter = manager.createAvgFlowPerSecondCollector("Avg_psCalculerNombreDeblacklistage_call_per_second", proxyName); //$NON-NLS-1$
    _avg_psCalculerNombreDeblacklistage_ExecTime = manager.createAvgDoubleCollectorItem("Avg_psCalculerNombreDeblacklistage_ExecTime", proxyName); //$NON-NLS-1$

  }

  @Override
  public ConnectorResponse<List<Indicateur>, Retour> calculerNombreBlacklistage(Tracabilite tracabilite_p, String codeMembres_p, String dateDebut_p, String dateFin_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<List<Indicateur>, Retour>>(IMOVConnector.BEAN_ID)
    {
      /**
      *
      */
      @Override
      public ConnectorResponse<List<Indicateur>, Retour> run() throws RavelException
      {
        IMOVConnector movConnector = (IMOVConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        //probes
        _avg_psCalculerNombreBlacklistage_call_counter.measure();
        //probes
        long startTime = System.currentTimeMillis();
        ConnectorResponse<List<Indicateur>, Retour> response = movConnector.calculerNombreBlacklistage(tracabilite_p, codeMembres_p, dateDebut_p, dateFin_p);
        long endTime = System.currentTimeMillis();
        //probes
        _avg_psCalculerNombreBlacklistage_ExecTime.updateAvgValue(endTime - startTime);
        //probes
        return response;
      }
    });
  }

  @Override
  public ConnectorResponse<List<Indicateur>, Retour> calculerNombreDeblacklistage(Tracabilite tracabilite_p, String codeMembres_p, String dateDebut_p, String dateFin_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<List<Indicateur>, Retour>>(IMOVConnector.BEAN_ID)
    {
      /**
      *
      */
      @Override
      public ConnectorResponse<List<Indicateur>, Retour> run() throws RavelException
      {
        IMOVConnector movConnector = (IMOVConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        //probes
        _avg_psCalculerNombreDeblacklistage_call_counter.measure();
        //probes
        long startTime = System.currentTimeMillis();
        ConnectorResponse<List<Indicateur>, Retour> response = movConnector.calculerNombreDeblacklistage(tracabilite_p, codeMembres_p, dateDebut_p, dateFin_p);
        long endTime = System.currentTimeMillis();
        //probes
        _avg_psCalculerNombreDeblacklistage_ExecTime.updateAvgValue(endTime - startTime);
        //probes
        return response;
      }
    });
  }

  /**
   * Invocation of the stored procedure P_007_CONS_DEMAND_BOT_CLOSRSX. Search the requests of code member 'BOT' and last
   * state CLOSRSX without error (0 or -1000)
   *
   * @param tracabilite_p
   *          Tracabilite
   *
   * @return response from the stored procedure
   *
   * @throws RavelException
   *           on error
   */
  @Override
  public ConnectorResponse<List<DemandeBotClosrsx>, Retour> consultDemandeBotClosrsx(final Tracabilite tracabilite_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<List<DemandeBotClosrsx>, Retour>>(IMOVConnector.BEAN_ID)
    {
      /**
      *
      */
      @Override
      public ConnectorResponse<List<DemandeBotClosrsx>, Retour> run() throws RavelException
      {
        IMOVConnector movConnector = (IMOVConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        //probes
        _avg_psConsultDemandeBotClosrsx_call_counter.measure();
        //probes
        long startTime = System.currentTimeMillis();
        ConnectorResponse<List<DemandeBotClosrsx>, Retour> response = movConnector.consultDemandeBotClosrsx(tracabilite_p);
        long endTime = System.currentTimeMillis();
        //probes
        _avg_psConsultDemandeBotClosrsx_ExecTime.updateAvgValue(endTime - startTime);
        //probes
        return response;
      }
    });
  }

  /**
   * Appel à la procédure stockée « P_GET_INFORMATIONS »
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param date_p
   *          date
   * @param dateDebut_p
   *          date début
   * @param dateFin_p
   *          date fin
   * @return {@link InformationsDemande}
   * @throws RavelException
   *           exception thrown
   */
  @Override
  public ConnectorResponse<List<InformationsDemande>, Retour> consulterInformationsParDate(final Tracabilite tracabilite_p, final String date_p, final String dateDebut_p, final String dateFin_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<List<InformationsDemande>, Retour>>(IMOVConnector.BEAN_ID)
    {
      /**
      *
      */
      @Override
      public ConnectorResponse<List<InformationsDemande>, Retour> run() throws RavelException
      {
        IMOVConnector movConnector = (IMOVConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        //probes
        _avg_psConsulterInformationsParDate_call_counter.measure();
        //probes
        long startTime = System.currentTimeMillis();
        ConnectorResponse<List<InformationsDemande>, Retour> response = movConnector.consulterInformationsParDate(tracabilite_p, date_p, dateDebut_p, dateFin_p);
        long endTime = System.currentTimeMillis();
        //probes
        _avg_psConsulterInformationsParDate_ExecTime.updateAvgValue(endTime - startTime);
        //probes
        return response;
      }
    });
  }

  /**
   * Appel à la procédure stockée « P_GET_INFORMATIONS »
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param date_p
   *          date
   * @param dateDebut_p
   *          date début
   * @param dateFin_p
   *          date fin
   * @param codeMembre_p
   *          code membre
   * @return {@link InformationsDemande}
   * @throws RavelException
   *           exception thrown
   */
  @Override
  public ConnectorResponse<List<InformationsDemande>, Retour> consulterInformationsParDateCodeMembre(final Tracabilite tracabilite_p, final String date_p, final String dateDebut_p, final String dateFin_p, final String codeMembre_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<List<InformationsDemande>, Retour>>(IMOVConnector.BEAN_ID)
    {
      /**
      *
      */
      @Override
      public ConnectorResponse<List<InformationsDemande>, Retour> run() throws RavelException
      {
        IMOVConnector movConnector = (IMOVConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        //probes
        _avg_psConsulterInformationsParDateCodeMembre_call_counter.measure();
        //probes
        long startTime = System.currentTimeMillis();
        ConnectorResponse<List<InformationsDemande>, Retour> response = movConnector.consulterInformationsParDateCodeMembre(tracabilite_p, date_p, dateDebut_p, dateFin_p, codeMembre_p);
        long endTime = System.currentTimeMillis();
        //probes
        _avg_psConsulterInformationsParDateCodeMembre_ExecTime.updateAvgValue(endTime - startTime);
        //probes
        return response;
      }
    });
  }

  /**
   * Appel à la procédure stockée « P_GET_INFORMATIONS »
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param imei_p
   *          imei
   * @return {@link InformationsDemande}
   * @throws RavelException
   *           exception thrown
   */
  @Override
  public ConnectorResponse<List<InformationsDemande>, Retour> consulterInformationsParImei(final Tracabilite tracabilite_p, final String imei_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<List<InformationsDemande>, Retour>>(IMOVConnector.BEAN_ID)
    {
      /**
      *
      */
      @Override
      public ConnectorResponse<List<InformationsDemande>, Retour> run() throws RavelException
      {
        IMOVConnector movConnector = (IMOVConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        //probes
        _avg_psConsulterInformationsParImei_call_counter.measure();
        //probes
        long startTime = System.currentTimeMillis();
        ConnectorResponse<List<InformationsDemande>, Retour> response = movConnector.consulterInformationsParImei(tracabilite_p, imei_p);
        long endTime = System.currentTimeMillis();
        //probes
        _avg_psConsulterInformationsParImei_ExecTime.updateAvgValue(endTime - startTime);
        //probes
        return response;
      }
    });
  }

  /**
   * Appel à la procédure stockée « P_GET_INFORMATIONS »
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param imei_p
   *          imei
   * @param date_p
   *          date
   * @param dateDebut_p
   *          date début
   * @param dateFin_p
   *          date fin
   * @return {@link InformationsDemande}
   * @throws RavelException
   *           exception thrown
   */
  @Override
  public ConnectorResponse<List<InformationsDemande>, Retour> consulterInformationsParImeiDate(final Tracabilite tracabilite_p, final String imei_p, final String date_p, final String dateDebut_p, final String dateFin_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<List<InformationsDemande>, Retour>>(IMOVConnector.BEAN_ID)
    {
      /**
      *
      */
      @Override
      public ConnectorResponse<List<InformationsDemande>, Retour> run() throws RavelException
      {
        IMOVConnector movConnector = (IMOVConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        //probes
        _avg_psConsulterInformationsParImei_call_counter.measure();
        //probes
        long startTime = System.currentTimeMillis();
        ConnectorResponse<List<InformationsDemande>, Retour> response = movConnector.consulterInformationsParImeiDate(tracabilite_p, imei_p, date_p, dateDebut_p, dateFin_p);
        long endTime = System.currentTimeMillis();
        //probes
        _avg_psConsulterInformationsParImei_ExecTime.updateAvgValue(endTime - startTime);
        //probes
        return response;
      }
    });
  }

  /**
   * Appel à la procédure stockée « P_GET_INFORMATIONS »
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param msisdn_p
   *          msisdn
   * @return {@link InformationsDemande}
   * @throws RavelException
   *           exception thrown
   */
  @Override
  public ConnectorResponse<List<InformationsDemande>, Retour> consulterInformationsParMsisdn(final Tracabilite tracabilite_p, final String msisdn_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<List<InformationsDemande>, Retour>>(IMOVConnector.BEAN_ID)
    {
      /**
      *
      */
      @Override
      public ConnectorResponse<List<InformationsDemande>, Retour> run() throws RavelException
      {
        IMOVConnector movConnector = (IMOVConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        //probes
        _avg_psConsulterInformationsParImei_call_counter.measure();
        //probes
        long startTime = System.currentTimeMillis();
        ConnectorResponse<List<InformationsDemande>, Retour> response = movConnector.consulterInformationsParMsisdn(tracabilite_p, msisdn_p);
        long endTime = System.currentTimeMillis();
        //probes
        _avg_psConsulterInformationsParImei_ExecTime.updateAvgValue(endTime - startTime);
        //probes
        return response;
      }
    });
  }

  /**
   * Appel à la procédure stockée « P_GET_INFORMATIONS »
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param msisdn_p
   *          msisdn
   * @param date_p
   *          date
   * @param dateDebut_p
   *          date début
   * @param dateFin_p
   *          date fin
   * @return {@link InformationsDemande}
   * @throws RavelException
   *           exception thrown
   */
  @Override
  public ConnectorResponse<List<InformationsDemande>, Retour> consulterInformationsParMsisdnDate(final Tracabilite tracabilite_p, final String msisdn_p, final String date_p, final String dateDebut_p, final String dateFin_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<List<InformationsDemande>, Retour>>(IMOVConnector.BEAN_ID)
    {
      /**
      *
      */
      @Override
      public ConnectorResponse<List<InformationsDemande>, Retour> run() throws RavelException
      {
        IMOVConnector movConnector = (IMOVConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        //probes
        _avg_psConsulterInformationsParImei_call_counter.measure();
        //probes
        long startTime = System.currentTimeMillis();
        ConnectorResponse<List<InformationsDemande>, Retour> response = movConnector.consulterInformationsParMsisdnDate(tracabilite_p, msisdn_p, date_p, dateDebut_p, dateFin_p);
        long endTime = System.currentTimeMillis();
        //probes
        _avg_psConsulterInformationsParImei_ExecTime.updateAvgValue(endTime - startTime);
        //probes
        return response;
      }
    });
  }

  /**
   * Wrapper to call method consultMOVDerniereDemande
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param imei_p
   *          Imei to be searched
   * @return Response from the wrapped method
   * @throws RavelException
   *           exception to be thrown
   */
  @Override
  public ConnectorResponse<Demande, Retour> consultMOVDerniereDemande(final Tracabilite tracabilite_p, final String imei_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Demande, Retour>>(IMOVConnector.BEAN_ID)
    {
      /**
      *
      */
      @Override
      public ConnectorResponse<Demande, Retour> run() throws RavelException
      {
        IMOVConnector movConnector = (IMOVConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        // probes
        _avg_psConsultMovDerniereDemande_call_counter.measure();
        // probes
        long startTime = System.currentTimeMillis();
        ConnectorResponse<Demande, Retour> response = movConnector.consultMOVDerniereDemande(tracabilite_p, imei_p);
        Long endTime = System.currentTimeMillis();
        // probes
        _avg_psconsultMovDerniereDemande_ExecTime.updateAvgValue(endTime - startTime);
        // probes
        return response;
      }
    });
  }

  /**
   * Wrapper to call method consultMOVListeDemande
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param imei_p
   *          Imei to be searched
   * @return Response from the wrapped method
   * @throws RavelException
   *           exception to be thrown
   */

  @Override
  public ConnectorResponse<Demande[], Retour> consultMOVListeDemande(final Tracabilite tracabilite_p, final String imei_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Demande[], Retour>>(IMOVConnector.BEAN_ID)
    {
      /**
      *
      */
      @Override
      public ConnectorResponse<Demande[], Retour> run() throws RavelException
      {
        IMOVConnector movConnector = (IMOVConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        // probes
        _avg_psConsultMovListeDemande_call_counter.measure();
        // probes
        long startTime = System.currentTimeMillis();
        ConnectorResponse<Demande[], Retour> response = movConnector.consultMOVListeDemande(tracabilite_p, imei_p);
        Long endTime = System.currentTimeMillis();
        // probes
        _avg_psconsultMovListeDemande_ExecTime.updateAvgValue(endTime - startTime);
        // probes
        return response;
      }
    });
  }

  /**
   * Appel à la procédure stockée P_003_GESTION_DEMANDE_BLKDBLK
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param demandeur_p
   *          Demandeur
   * @param imei_p
   *          IMEI
   * @param code_membre_p
   *          Code Membre
   * @param code_motif_p
   *          Code Motif
   * @param mouvement_p
   *          Mouvement
   * @param flg_luhn_p
   *          LUHN
   * @param origine_p
   *          Origine
   * @param msisdn_p
   *          MSISDN
   * @param service_p
   *          Service
   * @param fabricant_p
   *          Fabricant
   * @param designation_p
   *          Designation
   * @param fichier_source_p
   *          Fichier Source
   * @return une flag TAC
   * @throws RavelException
   *           exception
   */
  @Override
  public ConnectorResponse<Integer, Retour> insererDemandeMOV(final Tracabilite tracabilite_p, final String imei_p, final String demandeur_p, final String code_membre_p, final String code_motif_p, final String mouvement_p, final int flg_luhn_p, final String origine_p, final String msisdn_p, final String service_p, final String fabricant_p, final String designation_p, final String fichier_source_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Integer, Retour>>(IMOVConnector.BEAN_ID)
    {
      /**
      *
      */
      @Override
      public ConnectorResponse<Integer, Retour> run() throws RavelException
      {
        IMOVConnector movConnector = (IMOVConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        // probes
        _avg_psInsererDemandeMOV_call_counter.measure();
        // probes
        long startTime = System.currentTimeMillis();
        ConnectorResponse<Integer, Retour> response = movConnector.insererDemandeMOV(tracabilite_p, imei_p, demandeur_p, code_membre_p, code_motif_p, mouvement_p, flg_luhn_p, origine_p, msisdn_p, service_p, fabricant_p, designation_p, fichier_source_p);
        Long endTime = System.currentTimeMillis();
        // probes
        _avg_psInsererDemandeMOV_ExecTime.updateAvgValue(endTime - startTime);
        // probes
        return response;
      }
    });
  }

  /**
   * Appel à la procédure stockée P_008_INSERT_NEW_ETAT
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param demande_p
   *          The Demande number
   * @param statut_p
   *          The statut
   * @param fichier_p
   *          The filename
   * @param dateEtat_p
   *          The Etat date
   * @param codeErreur_p
   *          The error code
   * @param descErreur_p
   *          The error description
   * @param chrono_p
   *          The chrono number
   * @param recyclage_p
   *          The recyclage
   * @return response from the stored procedure
   * @throws RavelException
   *           on error
   */
  @Override
  public ConnectorResponse<Boolean, Retour> insertNewEtat(final Tracabilite tracabilite_p, final long demande_p, final String statut_p, final String fichier_p, final Timestamp dateEtat_p, final String codeErreur_p, final String descErreur_p, final Long chrono_p, final Long recyclage_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Boolean, Retour>>(IMOVConnector.BEAN_ID)
    {
      /**
      *
      */
      @Override
      public ConnectorResponse<Boolean, Retour> run() throws RavelException
      {
        IMOVConnector movConnector = (IMOVConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        // probes
        _avg_psInsertNewEtat_call_counter.measure();
        // probes
        long startTime = System.currentTimeMillis();
        ConnectorResponse<Boolean, Retour> response = movConnector.insertNewEtat(tracabilite_p, demande_p, statut_p, fichier_p, dateEtat_p, codeErreur_p, descErreur_p, chrono_p, recyclage_p);
        Long endTime = System.currentTimeMillis();
        // probes
        _avg_psInsertNewEtat_ExecTime.updateAvgValue(endTime - startTime);
        // probes

        return response;
      }
    });
  }

  /**
   * Appel à la procédure stockée P_005_CHECK_CODE_MEMBRE
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param code_membre_p
   *          Le code membre à vérifier
   * @return nombre d'occurrences ({@link Retour})
   * @throws RavelException
   *           exception thrown
   */
  @Override
  public ConnectorResponse<Long, Retour> verifierCodeMembre(final Tracabilite tracabilite_p, final String code_membre_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Long, Retour>>(IMOVConnector.BEAN_ID)
    {
      /**
      *
      */
      @Override
      public ConnectorResponse<Long, Retour> run() throws RavelException
      {
        IMOVConnector movConnector = (IMOVConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        // probes
        _avg_psVerifierCodeMembre_call_counter.measure();
        // probes
        long startTime = System.currentTimeMillis();
        ConnectorResponse<Long, Retour> response = movConnector.verifierCodeMembre(tracabilite_p, code_membre_p);
        Long endTime = System.currentTimeMillis();
        // probes
        _avg_psVerifierCodeMembre_ExecTime.updateAvgValue(endTime - startTime);
        // probes
        return response;
      }
    });
  }

  /**
   * Appel à la procédure stockée P_004_CHECK_CODE_MOTIF
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param code_motif_p
   *          Le code motif à vérifier
   * @return nombre d'occurrences ({@link Retour})
   * @throws RavelException
   *           exception thrown
   */
  @Override
  public ConnectorResponse<Long, Retour> verifierCodeMotif(final Tracabilite tracabilite_p, final String code_motif_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Long, Retour>>(IMOVConnector.BEAN_ID)
    {
      /**
      *
      */
      @Override
      public ConnectorResponse<Long, Retour> run() throws RavelException
      {
        IMOVConnector movConnector = (IMOVConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        // probes
        _avg_psVerifierCodeMotif_call_counter.measure();
        // probes
        long startTime = System.currentTimeMillis();
        ConnectorResponse<Long, Retour> response = movConnector.verifierCodeMotif(tracabilite_p, code_motif_p);
        Long endTime = System.currentTimeMillis();
        // probes
        _avg_psVerifierCodeMotif_ExecTime.updateAvgValue(endTime - startTime);
        // probes
        return response;
      }
    });
  }

  /**
   * Appel à la procédure stockée P_006_CHECK_DEDOUBLONNAGE
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param imei_p
   *          L'IMEI à vérifier
   * @param mouvement_p
   *          Mouvement
   * @param code_membre_p
   *          Code membre
   * @return true or false si demande valide ({@link Retour})
   * @throws RavelException
   *           exception thrown
   */
  @Override
  public ConnectorResponse<Boolean, Retour> verifierDedoublonnage(final Tracabilite tracabilite_p, final String imei_p, final String mouvement_p, final String code_membre_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Boolean, Retour>>(IMOVConnector.BEAN_ID)
    {
      /**
      *
      */
      @Override
      public ConnectorResponse<Boolean, Retour> run() throws RavelException
      {
        IMOVConnector movConnector = (IMOVConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        // probes
        _avg_psVerifierDedoublonnage_call_counter.measure();
        // probes
        long startTime = System.currentTimeMillis();
        ConnectorResponse<Boolean, Retour> response = movConnector.verifierDedoublonnage(tracabilite_p, imei_p, mouvement_p, code_membre_p);
        Long endTime = System.currentTimeMillis();
        // probes
        _avg_psVerifierDedoublonnage_ExecTime.updateAvgValue(endTime - startTime);
        // probes
        return response;
      }
    });
  }
}
