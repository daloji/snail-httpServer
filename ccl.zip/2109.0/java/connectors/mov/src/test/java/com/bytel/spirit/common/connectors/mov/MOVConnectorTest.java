/*******************************************************************************
 * $Id: MOVConnectorTest.java 33877 2017-01-25 17:27:24Z lmerces $
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.mov;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.List;
import java.util.concurrent.locks.Lock;

import org.apache.tomcat.jdbc.pool.DataSource;
import org.easymock.EasyMock;
import org.easymock.EasyMockSupport;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockNice;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.modules.junit4.PowerMockRunner;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.test.JUnitTools;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.services.connector.AbstractDBConnector;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

import oracle.jdbc.OracleTypes;

/**
 *
 * @author $Author: lmerces $
 * @version ($Revision$ $Date: 2017-01-25 18:27:24 +0100 (mer., 25 janv. 2017) $)
 */
@RunWith(PowerMockRunner.class)
//Dans cette classe nous mockons les appels statiques vers les méthodes de log

public class MOVConnectorTest extends EasyMockSupport
{

  /**
   *
   */
  private MOVConnector _connector;

  /**
   * Mock de {@link Lock}
   */
  @MockStrict
  Lock _dsReadLockMock;

  /**
   * Mock de {@link DataSource}
   */
  @MockStrict
  DataSource _dataSourceMock;

  /**
   *
   * Mock de {@link Connection}
   */
  @MockStrict
  Connection _connectionMock;

  /**
   * Mock de {@link ResultSet}
   */
  @MockNice
  ResultSet _resultSet;

  /**
   * Mock de {@link CallableStatement}
   */
  @MockStrict
  CallableStatement _callableStatementMock;

  /**
   * Mock de {@link ResultSet}
   */
  @MockStrict
  ResultSet _resultSetMock;

  /**
   * Test to get the list of requests of codeMembre 'BOT' and last status 'CLOSRSX'
   *
   * @throws Exception
   *           Exception
   */

  @Before
  public void beforeTest() throws Exception
  {
    _connector = new MOVConnector();
    // on réinitialise tous les mocks pour qu'il n'y ait pas d'interférrence entre les différents tests
    PowerMock.resetAll();
    // on indique que la classe de log sera mocké de façon statique dans le test à venir

    JUnitTools.setInaccessibleFieldValue(_connector, "_dsReadLock", _dsReadLockMock); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_datasource", _dataSourceMock); //$NON-NLS-1$
  }

  /**
   * Calculer Nombre Total Blacklistage
   *
   * @throws SQLException
   *           SQLException
   */
  @Test
  public void testCalculerNombreBlacklistageKO() throws SQLException
  {
    _dsReadLockMock.lock();
    EasyMock.expect(_dataSourceMock.getConnection()).andReturn(_connectionMock);
    EasyMock.expect(_connectionMock.prepareCall("{call PG_IHM_MOV.P_GET_NB_BLACKLISTAGES(?,?,?,?,?,?,?,?) }")).andReturn(_callableStatementMock); //$NON-NLS-1$

    try
    {

      Tracabilite tracabilite = new Tracabilite("idBytel", "idcorrelation", "ihm", "processus", "idprocessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$

      String dateDebut = "22062016"; //$NON-NLS-1$
      String dateFin = "22062016"; //$NON-NLS-1$
      String codeMembres = "BOT,FTM,SFR,FREE"; //$NON-NLS-1$
      Long result = 326L;

      EasyMock.expect(_resultSet.next()).andReturn(true);

      EasyMock.expect(_resultSet.getLong("NOMBRE")).andReturn(result); //$NON-NLS-1$
      EasyMock.expect(_resultSet.getString("CODE_MEMBRE")).andReturn("BOT"); //$NON-NLS-1$ //$NON-NLS-2$

      PowerMock.replay(_resultSet);

      _callableStatementMock.setQueryTimeout(0);
      _callableStatementMock.setString("pi_DateDebut", dateDebut); //$NON-NLS-1$
      _callableStatementMock.setString("pi_DateFin", dateFin); //$NON-NLS-1$
      _callableStatementMock.setString("pi_CodeMembre", codeMembres); //$NON-NLS-1$

      _callableStatementMock.registerOutParameter("po_RESULT", OracleTypes.CURSOR); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter(AbstractDBConnector.RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      _callableStatementMock.registerOutParameter(AbstractDBConnector.RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      _callableStatementMock.registerOutParameter(AbstractDBConnector.RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      _callableStatementMock.registerOutParameter(AbstractDBConnector.RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      EasyMock.expect(_callableStatementMock.execute()).andReturn(true);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_RESULTAT)).andReturn(StringConstants.KO);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_CATEGORIE)).andReturn(null);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_DIAGNOSTIC)).andReturn(null);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_LIBELLE)).andReturn(null);
      EasyMock.expect(_callableStatementMock.getObject("po_RESULT")).andReturn(_resultSet); //$NON-NLS-1$
      _resultSetMock.close();
      _callableStatementMock.close();
      _connectionMock.close();
      // Déverouillage du Lock
      _dsReadLockMock.unlock();

      PowerMock.replayAll();
      ConnectorResponse<List<Indicateur>, Retour> connectorResponse = _connector.calculerNombreBlacklistage(tracabilite, codeMembres, dateDebut, dateFin);

      assertEquals(StringConstants.KO, connectorResponse._second.getResultat());
      assertNull(connectorResponse._second.getCategorie());
      assertNull(connectorResponse._second.getLibelle());
      assertNull(connectorResponse._second.getDiagnostic());

    }
    catch (RavelException exception)
    {
      exception.printStackTrace();
    }
  }

  /**
   * Calculer Nombre Total Blacklistage
   *
   * @throws SQLException
   *           SQLException
   */
  @Test
  public void testCalculerNombreBlacklistageOK() throws SQLException
  {
    _dsReadLockMock.lock();
    EasyMock.expect(_dataSourceMock.getConnection()).andReturn(_connectionMock);
    EasyMock.expect(_connectionMock.prepareCall("{call PG_IHM_MOV.P_GET_NB_BLACKLISTAGES(?,?,?,?,?,?,?,?) }")).andReturn(_callableStatementMock); //$NON-NLS-1$

    try
    {

      Tracabilite tracabilite = new Tracabilite("idBytel", "idcorrelation", "ihm", "processus", "idprocessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$

      String dateDebut = "22062016"; //$NON-NLS-1$
      String dateFin = "22062016"; //$NON-NLS-1$
      String codeMembres = "BOT,FTM,SFR,FREE"; //$NON-NLS-1$
      Long result = 326L;

      EasyMock.expect(_resultSet.next()).andReturn(true);

      EasyMock.expect(_resultSet.getLong("NOMBRE")).andReturn(result); //$NON-NLS-1$
      EasyMock.expect(_resultSet.getString("CODE_MEMBRE")).andReturn("BOT"); //$NON-NLS-1$ //$NON-NLS-2$

      PowerMock.replay(_resultSet);

      _callableStatementMock.setQueryTimeout(0);
      _callableStatementMock.setString("pi_DateDebut", dateDebut); //$NON-NLS-1$
      _callableStatementMock.setString("pi_DateFin", dateFin); //$NON-NLS-1$
      _callableStatementMock.setString("pi_CodeMembre", codeMembres); //$NON-NLS-1$

      _callableStatementMock.registerOutParameter("po_RESULT", OracleTypes.CURSOR); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter(AbstractDBConnector.RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      _callableStatementMock.registerOutParameter(AbstractDBConnector.RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      _callableStatementMock.registerOutParameter(AbstractDBConnector.RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      _callableStatementMock.registerOutParameter(AbstractDBConnector.RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      EasyMock.expect(_callableStatementMock.execute()).andReturn(true);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_RESULTAT)).andReturn(StringConstants.OK);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_CATEGORIE)).andReturn(null);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_DIAGNOSTIC)).andReturn(null);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_LIBELLE)).andReturn(null);
      EasyMock.expect(_callableStatementMock.getObject("po_RESULT")).andReturn(_resultSet); //$NON-NLS-1$
      _resultSetMock.close();
      _callableStatementMock.close();
      _connectionMock.close();
      // Déverouillage du Lock
      _dsReadLockMock.unlock();

      PowerMock.replayAll();
      ConnectorResponse<List<Indicateur>, Retour> connectorResponse = _connector.calculerNombreBlacklistage(tracabilite, codeMembres, dateDebut, dateFin);

      assertEquals(StringConstants.OK, connectorResponse._second.getResultat());
      assertNull(connectorResponse._second.getCategorie());
      assertNull(connectorResponse._second.getLibelle());
      assertNull(connectorResponse._second.getDiagnostic());

      assertNotNull(connectorResponse._first);
      assertEquals(result, connectorResponse._first.get(0).getNombre());
    }
    catch (RavelException exception)
    {
      exception.printStackTrace();
    }
  }

  /**
   * Calculer Nombre Total Deblacklistage
   *
   * @throws SQLException
   *           SQLException
   */
  @Test
  public void testCalculerNombreDeblacklistageKO() throws SQLException
  {
    _dsReadLockMock.lock();
    EasyMock.expect(_dataSourceMock.getConnection()).andReturn(_connectionMock);
    EasyMock.expect(_connectionMock.prepareCall("{call PG_IHM_MOV.P_GET_NB_DEBLACKLISTAGES(?,?,?,?,?,?,?,?) }")).andReturn(_callableStatementMock); //$NON-NLS-1$

    try
    {

      Tracabilite tracabilite = new Tracabilite("idBytel", "idcorrelation", "ihm", "processus", "idprocessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$

      String dateDebut = "22062016"; //$NON-NLS-1$
      String dateFin = "22062016"; //$NON-NLS-1$
      String codeMembres = "BOT,FTM,SFR,FREE"; //$NON-NLS-1$
      Long result = 326L;

      EasyMock.expect(_resultSet.next()).andReturn(true);

      EasyMock.expect(_resultSet.getLong("NOMBRE")).andReturn(result); //$NON-NLS-1$
      EasyMock.expect(_resultSet.getString("CODE_MEMBRE")).andReturn("BOT"); //$NON-NLS-1$ //$NON-NLS-2$

      PowerMock.replay(_resultSet);

      _callableStatementMock.setQueryTimeout(0);
      _callableStatementMock.setString("pi_DateDebut", dateDebut); //$NON-NLS-1$
      _callableStatementMock.setString("pi_DateFin", dateFin); //$NON-NLS-1$
      _callableStatementMock.setString("pi_CodeMembre", codeMembres); //$NON-NLS-1$

      _callableStatementMock.registerOutParameter("po_RESULT", OracleTypes.CURSOR); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter(AbstractDBConnector.RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      _callableStatementMock.registerOutParameter(AbstractDBConnector.RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      _callableStatementMock.registerOutParameter(AbstractDBConnector.RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      _callableStatementMock.registerOutParameter(AbstractDBConnector.RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      EasyMock.expect(_callableStatementMock.execute()).andReturn(true);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_RESULTAT)).andReturn(StringConstants.KO);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_CATEGORIE)).andReturn(null);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_DIAGNOSTIC)).andReturn(null);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_LIBELLE)).andReturn(null);
      EasyMock.expect(_callableStatementMock.getObject("po_RESULT")).andReturn(_resultSet); //$NON-NLS-1$
      _resultSetMock.close();
      _callableStatementMock.close();
      _connectionMock.close();
      // Déverouillage du Lock
      _dsReadLockMock.unlock();

      PowerMock.replayAll();
      ConnectorResponse<List<Indicateur>, Retour> connectorResponse = _connector.calculerNombreDeblacklistage(tracabilite, codeMembres, dateDebut, dateFin);

      assertEquals(StringConstants.KO, connectorResponse._second.getResultat());
      assertNull(connectorResponse._second.getCategorie());
      assertNull(connectorResponse._second.getLibelle());
      assertNull(connectorResponse._second.getDiagnostic());
    }
    catch (RavelException exception)
    {
      exception.printStackTrace();
    }
  }

  /**
   * Calculer Nombre Total Deblacklistage
   *
   * @throws SQLException
   *           SQLException
   */
  @Test
  public void testCalculerNombreDeblacklistageOK() throws SQLException
  {
    _dsReadLockMock.lock();
    EasyMock.expect(_dataSourceMock.getConnection()).andReturn(_connectionMock);
    EasyMock.expect(_connectionMock.prepareCall("{call PG_IHM_MOV.P_GET_NB_DEBLACKLISTAGES(?,?,?,?,?,?,?,?) }")).andReturn(_callableStatementMock); //$NON-NLS-1$

    try
    {

      Tracabilite tracabilite = new Tracabilite("idBytel", "idcorrelation", "ihm", "processus", "idprocessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$

      String dateDebut = "22062016"; //$NON-NLS-1$
      String dateFin = "22062016"; //$NON-NLS-1$
      String codeMembres = "BOT,FTM,SFR,FREE"; //$NON-NLS-1$
      Long result = 326L;

      EasyMock.expect(_resultSet.next()).andReturn(true);

      EasyMock.expect(_resultSet.getLong("NOMBRE")).andReturn(result); //$NON-NLS-1$
      EasyMock.expect(_resultSet.getString("CODE_MEMBRE")).andReturn("BOT"); //$NON-NLS-1$ //$NON-NLS-2$

      PowerMock.replay(_resultSet);

      _callableStatementMock.setQueryTimeout(0);
      _callableStatementMock.setString("pi_DateDebut", dateDebut); //$NON-NLS-1$
      _callableStatementMock.setString("pi_DateFin", dateFin); //$NON-NLS-1$
      _callableStatementMock.setString("pi_CodeMembre", codeMembres); //$NON-NLS-1$

      _callableStatementMock.registerOutParameter("po_RESULT", OracleTypes.CURSOR); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter(AbstractDBConnector.RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      _callableStatementMock.registerOutParameter(AbstractDBConnector.RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      _callableStatementMock.registerOutParameter(AbstractDBConnector.RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      _callableStatementMock.registerOutParameter(AbstractDBConnector.RETOUR_LIBELLE, OracleTypes.NVARCHAR);

      EasyMock.expect(_callableStatementMock.execute()).andReturn(true);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_RESULTAT)).andReturn(StringConstants.OK);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_CATEGORIE)).andReturn(null);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_DIAGNOSTIC)).andReturn(null);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_LIBELLE)).andReturn(null);
      EasyMock.expect(_callableStatementMock.getObject("po_RESULT")).andReturn(_resultSet); //$NON-NLS-1$
      _resultSetMock.close();
      _callableStatementMock.close();
      _connectionMock.close();
      // Déverouillage du Lock
      _dsReadLockMock.unlock();

      PowerMock.replayAll();
      ConnectorResponse<List<Indicateur>, Retour> connectorResponse = _connector.calculerNombreDeblacklistage(tracabilite, codeMembres, dateDebut, dateFin);

      assertEquals(StringConstants.OK, connectorResponse._second.getResultat());
      assertNull(connectorResponse._second.getCategorie());
      assertNull(connectorResponse._second.getLibelle());
      assertNull(connectorResponse._second.getDiagnostic());

      assertNotNull(connectorResponse._first);
      assertEquals(result, connectorResponse._first.get(0).getNombre());
    }
    catch (RavelException exception)
    {
      exception.printStackTrace();
    }
  }

  /**
   * @throws RavelException
   *           RavelException
   * @throws SQLException
   *           SQLException
   */
  @Test
  public void testConsultDemandeBotClosrsx() throws RavelException, SQLException
  {

    Tracabilite tracabilite = new Tracabilite("idBytel", "idcorrelation", "ihm", "processus", "idprocessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
    _dsReadLockMock.lock();
    EasyMock.expect(_dataSourceMock.getConnection()).andReturn(_connectionMock);
    EasyMock.expect(_connectionMock.prepareCall("{call P_007_CONS_DEMAND_BOT_CLOSRSX(?,?,?,?,?) }")).andReturn(_callableStatementMock); //$NON-NLS-1$
    _callableStatementMock.setQueryTimeout(0);

    _callableStatementMock.registerOutParameter("cursorx", OracleTypes.CURSOR); //$NON-NLS-1$
    _callableStatementMock.registerOutParameter("Retour_Resultat", OracleTypes.NVARCHAR); //$NON-NLS-1$
    _callableStatementMock.registerOutParameter("Retour_Categorie", OracleTypes.NVARCHAR); //$NON-NLS-1$
    _callableStatementMock.registerOutParameter("Retour_Diagnostic", OracleTypes.NVARCHAR); //$NON-NLS-1$
    _callableStatementMock.registerOutParameter("Retour_Libelle", OracleTypes.NVARCHAR); //$NON-NLS-1$
    EasyMock.expect(_callableStatementMock.execute()).andReturn(true);
    EasyMock.expect(_callableStatementMock.getObject("cursorx")).andReturn(_resultSetMock); //$NON-NLS-1$
    EasyMock.expect(_resultSetMock.next()).andReturn(true);

    EasyMock.expect(_resultSetMock.getString("CODE_DEMANDEUR")).andReturn("BOT"); //$NON-NLS-1$//$NON-NLS-2$
    EasyMock.expect(_resultSetMock.getString("CODE_MEMBRE_EXT")).andReturn("208/PLMN/002000"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSetMock.getString("CODE_MOTIF")).andReturn("IV"); //$NON-NLS-1$//$NON-NLS-2$
    EasyMock.expect(_resultSetMock.getLong("DEMANDE")).andReturn(3000001L); //$NON-NLS-1$
    EasyMock.expect(_resultSetMock.getString("DESC_MOTIF")).andReturn("Volé"); //$NON-NLS-1$//$NON-NLS-2$
    EasyMock.expect(_resultSetMock.getString("FLG_TAC")).andReturn("0"); //$NON-NLS-1$//$NON-NLS-2$
    EasyMock.expect(_resultSetMock.getString("IMEI")).andReturn("350000000000001"); //$NON-NLS-1$//$NON-NLS-2$
    EasyMock.expect(_resultSetMock.getString("MOUVEMENT")).andReturn("I"); //$NON-NLS-1$//$NON-NLS-2$
    EasyMock.expect(_resultSetMock.getString("CODE_GIE")).andReturn("codeDemandeur"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_resultSetMock.next()).andReturn(false);
    EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_RESULTAT)).andReturn(StringConstants.OK);
    EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_CATEGORIE)).andReturn(null);
    EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_DIAGNOSTIC)).andReturn(null);
    EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_LIBELLE)).andReturn(null);
    _resultSetMock.close();
    _callableStatementMock.close();
    _connectionMock.close();
    // Déverouillage du Lock
    _dsReadLockMock.unlock();

    PowerMock.replayAll();
    ConnectorResponse<List<DemandeBotClosrsx>, Retour> connectorResponse = _connector.consultDemandeBotClosrsx(tracabilite);

    List<DemandeBotClosrsx> listDemandes = connectorResponse._first;

    Assert.assertNotNull(listDemandes);
    Assert.assertFalse(listDemandes.isEmpty());
    assertEquals(1, listDemandes.size());

    DemandeBotClosrsx demande = findDemandeBotClosrsxByDemande(listDemandes, 3000001);

    Assert.assertNotNull(demande);

    assertEquals(3000001, demande.getDemande());
    assertEquals("350000000000001", demande.getImei()); //$NON-NLS-1$
    assertEquals("BOT", demande.getCodeDemandeur()); //$NON-NLS-1$
    assertEquals("0", demande.getFlagTac()); //$NON-NLS-1$
    assertEquals("IV", demande.getCodeMotif()); //$NON-NLS-1$
    assertEquals("I", demande.getMouvement()); //$NON-NLS-1$
    assertEquals("208/PLMN/002000", demande.getCodeMembreExt()); //$NON-NLS-1$
    assertEquals("Volé", demande.getDescMotif()); //$NON-NLS-1$

  }

  /**
   * Consulter informations par date
   *
   * @throws SQLException
   *           SQLException
   */
  @Test
  public void testConsulterInformationsParDate() throws SQLException
  {
    _dsReadLockMock.lock();
    EasyMock.expect(_dataSourceMock.getConnection()).andReturn(_connectionMock);
    EasyMock.expect(_connectionMock.prepareCall("{call PG_IHM_MOV.P_GET_INFORMATIONS(?,?,?,?,?,?,?,?,?,?,?) }")).andReturn(_callableStatementMock); //$NON-NLS-1$

    try
    {

      Tracabilite tracabilite = new Tracabilite("idBytel", "idcorrelation", "ihm", "processus", "idprocessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$

      String dateDemande = "22062016"; //$NON-NLS-1$
      String dateDebut = "22062016"; //$NON-NLS-1$
      String dateFin = "22062016"; //$NON-NLS-1$

      _callableStatementMock.setQueryTimeout(0);
      _callableStatementMock.setString("pi_DateDemande", dateDemande); //$NON-NLS-1$
      _callableStatementMock.setString("pi_DateDebut", dateDebut); //$NON-NLS-1$
      _callableStatementMock.setString("pi_DateFin", dateFin); //$NON-NLS-1$
      _callableStatementMock.setString("pi_CodeMembre", null); //$NON-NLS-1$
      _callableStatementMock.setString("pi_Imei", null); //$NON-NLS-1$
      _callableStatementMock.setString("pi_Msisdn", null); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("po_RESULT", OracleTypes.CURSOR); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter(AbstractDBConnector.RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      _callableStatementMock.registerOutParameter(AbstractDBConnector.RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      _callableStatementMock.registerOutParameter(AbstractDBConnector.RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      _callableStatementMock.registerOutParameter(AbstractDBConnector.RETOUR_LIBELLE, OracleTypes.NVARCHAR);
      EasyMock.expect(_callableStatementMock.execute()).andReturn(true);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_RESULTAT)).andReturn(StringConstants.OK);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_CATEGORIE)).andReturn(null);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_DIAGNOSTIC)).andReturn(null);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_LIBELLE)).andReturn(null);
      EasyMock.expect(_callableStatementMock.getObject("po_RESULT")).andReturn(_resultSetMock); //$NON-NLS-1$
      EasyMock.expect(_resultSetMock.next()).andReturn(true);
      EasyMock.expect(_resultSetMock.getString("imei")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("origine")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("code_membre")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("msisdn")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("service")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("mouvement")).andReturn("350000000000001");//$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getTimestamp("date_etat")).andReturn(Timestamp.valueOf("2017-02-06 14:16:39.78")); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("dernier_etat")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("motif")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("date_insertion")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("heure_insertion")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.next()).andReturn(false);

      _resultSetMock.close();
      _callableStatementMock.close();
      _connectionMock.close();
      // Déverouillage du Lock
      _dsReadLockMock.unlock();

      PowerMock.replayAll();
      ConnectorResponse<List<InformationsDemande>, Retour> connectorResponse = _connector.consulterInformationsParDate(tracabilite, dateDemande, dateDebut, dateFin);

      assertEquals(StringConstants.OK, connectorResponse._second.getResultat());
      assertNull(connectorResponse._second.getCategorie());
      assertNull(connectorResponse._second.getLibelle());
      assertNull(connectorResponse._second.getDiagnostic());

      assertNotNull(connectorResponse._first);
      assertTrue(!connectorResponse._first.isEmpty());
    }
    catch (RavelException exception)
    {
      exception.printStackTrace();
    }
  }

  /**
   * Consulter informations par date et code membre
   *
   * @throws SQLException
   *           SQLException
   */
  @Test
  public void testConsulterInformationsParDateCodeMembre() throws SQLException
  {
    _dsReadLockMock.lock();
    EasyMock.expect(_dataSourceMock.getConnection()).andReturn(_connectionMock);
    EasyMock.expect(_connectionMock.prepareCall("{call PG_IHM_MOV.P_GET_INFORMATIONS(?,?,?,?,?,?,?,?,?,?,?) }")).andReturn(_callableStatementMock); //$NON-NLS-1$

    try
    {

      Tracabilite tracabilite = new Tracabilite("idBytel", "idcorrelation", "ihm", "processus", "idprocessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$

      String dateDemande = "22062016"; //$NON-NLS-1$
      String dateDebut = null;
      String dateFin = null;

      _callableStatementMock.setQueryTimeout(0);
      _callableStatementMock.setString("pi_DateDemande", dateDemande); //$NON-NLS-1$
      _callableStatementMock.setString("pi_DateDebut", dateDebut); //$NON-NLS-1$
      _callableStatementMock.setString("pi_DateFin", dateFin); //$NON-NLS-1$
      _callableStatementMock.setString("pi_CodeMembre", CodeMembre.BOT.name()); //$NON-NLS-1$
      _callableStatementMock.setString("pi_Imei", null); //$NON-NLS-1$
      _callableStatementMock.setString("pi_Msisdn", null); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("po_RESULT", OracleTypes.CURSOR); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter(AbstractDBConnector.RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      _callableStatementMock.registerOutParameter(AbstractDBConnector.RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      _callableStatementMock.registerOutParameter(AbstractDBConnector.RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      _callableStatementMock.registerOutParameter(AbstractDBConnector.RETOUR_LIBELLE, OracleTypes.NVARCHAR);
      EasyMock.expect(_callableStatementMock.execute()).andReturn(true);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_RESULTAT)).andReturn(StringConstants.OK);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_CATEGORIE)).andReturn(null);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_DIAGNOSTIC)).andReturn(null);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_LIBELLE)).andReturn(null);
      EasyMock.expect(_callableStatementMock.getObject("po_RESULT")).andReturn(_resultSetMock); //$NON-NLS-1$
      EasyMock.expect(_resultSetMock.next()).andReturn(true);
      EasyMock.expect(_resultSetMock.getString("imei")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("origine")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("code_membre")).andReturn(CodeMembre.BOT.name()); //$NON-NLS-1$
      EasyMock.expect(_resultSetMock.getString("msisdn")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("service")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("mouvement")).andReturn("350000000000001");//$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getTimestamp("date_etat")).andReturn(Timestamp.valueOf("2017-02-06 14:16:39.78")); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("dernier_etat")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("motif")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("date_insertion")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("heure_insertion")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.next()).andReturn(false);

      _resultSetMock.close();
      _callableStatementMock.close();
      _connectionMock.close();
      // Déverouillage du Lock
      _dsReadLockMock.unlock();

      PowerMock.replayAll();
      ConnectorResponse<List<InformationsDemande>, Retour> connectorResponse = _connector.consulterInformationsParDateCodeMembre(tracabilite, dateDemande, dateDebut, dateFin, CodeMembre.BOT.name());

      assertEquals(StringConstants.OK, connectorResponse._second.getResultat());
      assertNull(connectorResponse._second.getCategorie());
      assertNull(connectorResponse._second.getLibelle());
      assertNull(connectorResponse._second.getDiagnostic());

      assertNotNull(connectorResponse._first);
      assertTrue(!connectorResponse._first.isEmpty());
    }
    catch (RavelException exception)
    {
      exception.printStackTrace();
    }
  }

  /**
   * Consulter informations par imei
   *
   * @throws SQLException
   *           SQLException
   */
  @Test
  public void testConsulterInformationsParImei() throws SQLException
  {
    _dsReadLockMock.lock();
    EasyMock.expect(_dataSourceMock.getConnection()).andReturn(_connectionMock);
    EasyMock.expect(_connectionMock.prepareCall("{call PG_IHM_MOV.P_GET_INFORMATIONS(?,?,?,?,?,?,?,?,?,?,?) }")).andReturn(_callableStatementMock); //$NON-NLS-1$

    try
    {

      Tracabilite tracabilite = new Tracabilite("idBytel", "idcorrelation", "ihm", "processus", "idprocessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
      String imei = "350000000000001"; //$NON-NLS-1$

      _callableStatementMock.setQueryTimeout(0);
      _callableStatementMock.setString("pi_DateDemande", null); //$NON-NLS-1$
      _callableStatementMock.setString("pi_DateDebut", null); //$NON-NLS-1$
      _callableStatementMock.setString("pi_DateFin", null); //$NON-NLS-1$
      _callableStatementMock.setString("pi_CodeMembre", null); //$NON-NLS-1$
      _callableStatementMock.setString("pi_Imei", imei); //$NON-NLS-1$
      _callableStatementMock.setString("pi_Msisdn", null); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("po_RESULT", OracleTypes.CURSOR); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter(AbstractDBConnector.RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      _callableStatementMock.registerOutParameter(AbstractDBConnector.RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      _callableStatementMock.registerOutParameter(AbstractDBConnector.RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      _callableStatementMock.registerOutParameter(AbstractDBConnector.RETOUR_LIBELLE, OracleTypes.NVARCHAR);
      EasyMock.expect(_callableStatementMock.execute()).andReturn(true);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_RESULTAT)).andReturn(StringConstants.OK);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_CATEGORIE)).andReturn(null);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_DIAGNOSTIC)).andReturn(null);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_LIBELLE)).andReturn(null);
      EasyMock.expect(_callableStatementMock.getObject("po_RESULT")).andReturn(_resultSetMock); //$NON-NLS-1$
      EasyMock.expect(_resultSetMock.next()).andReturn(true);
      EasyMock.expect(_resultSetMock.getString("imei")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("origine")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("code_membre")).andReturn(CodeMembre.BOT.name()); //$NON-NLS-1$
      EasyMock.expect(_resultSetMock.getString("msisdn")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("service")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("mouvement")).andReturn("350000000000001");//$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getTimestamp("date_etat")).andReturn(Timestamp.valueOf("2017-02-06 14:16:39.78")); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("dernier_etat")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("motif")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("date_insertion")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("heure_insertion")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.next()).andReturn(false);

      _resultSetMock.close();
      _callableStatementMock.close();
      _connectionMock.close();
      // Déverouillage du Lock
      _dsReadLockMock.unlock();

      PowerMock.replayAll();
      ConnectorResponse<List<InformationsDemande>, Retour> connectorResponse = _connector.consulterInformationsParImei(tracabilite, imei);

      assertEquals(StringConstants.OK, connectorResponse._second.getResultat());
      assertNull(connectorResponse._second.getCategorie());
      assertNull(connectorResponse._second.getLibelle());
      assertNull(connectorResponse._second.getDiagnostic());

      assertNotNull(connectorResponse._first);
      assertTrue(!connectorResponse._first.isEmpty());
    }
    catch (RavelException exception)
    {
      exception.printStackTrace();
    }
  }

  /**
   * Consulter informations par imei et date
   *
   * @throws SQLException
   *           SQLException
   */
  @Test
  public void testConsulterInformationsParImeiDate() throws SQLException
  {
    _dsReadLockMock.lock();
    EasyMock.expect(_dataSourceMock.getConnection()).andReturn(_connectionMock);
    EasyMock.expect(_connectionMock.prepareCall("{call PG_IHM_MOV.P_GET_INFORMATIONS(?,?,?,?,?,?,?,?,?,?,?) }")).andReturn(_callableStatementMock); //$NON-NLS-1$

    try
    {

      Tracabilite tracabilite = new Tracabilite("idBytel", "idcorrelation", "ihm", "processus", "idprocessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
      String imei = "350000000000001"; //$NON-NLS-1$
      String dateDemande = "22062016"; //$NON-NLS-1$
      String dateDebut = null;
      String dateFin = null;

      _callableStatementMock.setQueryTimeout(0);
      _callableStatementMock.setString("pi_DateDemande", dateDemande); //$NON-NLS-1$
      _callableStatementMock.setString("pi_DateDebut", dateDebut); //$NON-NLS-1$
      _callableStatementMock.setString("pi_DateFin", dateFin); //$NON-NLS-1$
      _callableStatementMock.setString("pi_CodeMembre", null); //$NON-NLS-1$
      _callableStatementMock.setString("pi_Imei", imei); //$NON-NLS-1$
      _callableStatementMock.setString("pi_Msisdn", null); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("po_RESULT", OracleTypes.CURSOR); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter(AbstractDBConnector.RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      _callableStatementMock.registerOutParameter(AbstractDBConnector.RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      _callableStatementMock.registerOutParameter(AbstractDBConnector.RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      _callableStatementMock.registerOutParameter(AbstractDBConnector.RETOUR_LIBELLE, OracleTypes.NVARCHAR);
      EasyMock.expect(_callableStatementMock.execute()).andReturn(true);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_RESULTAT)).andReturn(StringConstants.OK);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_CATEGORIE)).andReturn(null);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_DIAGNOSTIC)).andReturn(null);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_LIBELLE)).andReturn(null);
      EasyMock.expect(_callableStatementMock.getObject("po_RESULT")).andReturn(_resultSetMock); //$NON-NLS-1$
      EasyMock.expect(_resultSetMock.next()).andReturn(true);
      EasyMock.expect(_resultSetMock.getString("imei")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("origine")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("code_membre")).andReturn(CodeMembre.BOT.name()); //$NON-NLS-1$
      EasyMock.expect(_resultSetMock.getString("msisdn")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("service")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("mouvement")).andReturn("350000000000001");//$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getTimestamp("date_etat")).andReturn(Timestamp.valueOf("2017-02-06 14:16:39.78")); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("dernier_etat")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("motif")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("date_insertion")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("heure_insertion")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.next()).andReturn(false);

      _resultSetMock.close();
      _callableStatementMock.close();
      _connectionMock.close();
      // Déverouillage du Lock
      _dsReadLockMock.unlock();

      PowerMock.replayAll();
      ConnectorResponse<List<InformationsDemande>, Retour> connectorResponse = _connector.consulterInformationsParImeiDate(tracabilite, imei, dateDemande, dateDebut, dateFin);

      assertEquals(StringConstants.OK, connectorResponse._second.getResultat());
      assertNull(connectorResponse._second.getCategorie());
      assertNull(connectorResponse._second.getLibelle());
      assertNull(connectorResponse._second.getDiagnostic());

      assertNotNull(connectorResponse._first);
      assertTrue(!connectorResponse._first.isEmpty());
    }
    catch (RavelException exception)
    {
      exception.printStackTrace();
    }
  }

  /**
   * Consulter informations par msisdn
   *
   * @throws SQLException
   *           SQLException
   */
  @Test
  public void testConsulterInformationsParMsisdn() throws SQLException
  {
    _dsReadLockMock.lock();
    EasyMock.expect(_dataSourceMock.getConnection()).andReturn(_connectionMock);
    EasyMock.expect(_connectionMock.prepareCall("{call PG_IHM_MOV.P_GET_INFORMATIONS(?,?,?,?,?,?,?,?,?,?,?) }")).andReturn(_callableStatementMock); //$NON-NLS-1$

    try
    {

      Tracabilite tracabilite = new Tracabilite("idBytel", "idcorrelation", "ihm", "processus", "idprocessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
      String msisdn = "350000000000001"; //$NON-NLS-1$

      _callableStatementMock.setQueryTimeout(0);
      _callableStatementMock.setString("pi_DateDemande", null); //$NON-NLS-1$
      _callableStatementMock.setString("pi_DateDebut", null); //$NON-NLS-1$
      _callableStatementMock.setString("pi_DateFin", null); //$NON-NLS-1$
      _callableStatementMock.setString("pi_CodeMembre", null); //$NON-NLS-1$
      _callableStatementMock.setString("pi_Imei", null); //$NON-NLS-1$
      _callableStatementMock.setString("pi_Msisdn", msisdn); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("po_RESULT", OracleTypes.CURSOR); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter(AbstractDBConnector.RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      _callableStatementMock.registerOutParameter(AbstractDBConnector.RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      _callableStatementMock.registerOutParameter(AbstractDBConnector.RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      _callableStatementMock.registerOutParameter(AbstractDBConnector.RETOUR_LIBELLE, OracleTypes.NVARCHAR);
      EasyMock.expect(_callableStatementMock.execute()).andReturn(true);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_RESULTAT)).andReturn(StringConstants.OK);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_CATEGORIE)).andReturn(null);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_DIAGNOSTIC)).andReturn(null);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_LIBELLE)).andReturn(null);
      EasyMock.expect(_callableStatementMock.getObject("po_RESULT")).andReturn(_resultSetMock); //$NON-NLS-1$
      EasyMock.expect(_resultSetMock.next()).andReturn(true);
      EasyMock.expect(_resultSetMock.getString("imei")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("origine")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("code_membre")).andReturn(CodeMembre.BOT.name()); //$NON-NLS-1$
      EasyMock.expect(_resultSetMock.getString("msisdn")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("service")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("mouvement")).andReturn("350000000000001");//$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getTimestamp("date_etat")).andReturn(Timestamp.valueOf("2017-02-06 14:16:39.78")); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("dernier_etat")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("motif")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("date_insertion")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("heure_insertion")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.next()).andReturn(false);

      _resultSetMock.close();
      _callableStatementMock.close();
      _connectionMock.close();
      // Déverouillage du Lock
      _dsReadLockMock.unlock();

      PowerMock.replayAll();
      ConnectorResponse<List<InformationsDemande>, Retour> connectorResponse = _connector.consulterInformationsParMsisdn(tracabilite, msisdn);

      assertEquals(StringConstants.OK, connectorResponse._second.getResultat());
      assertNull(connectorResponse._second.getCategorie());
      assertNull(connectorResponse._second.getLibelle());
      assertNull(connectorResponse._second.getDiagnostic());

      assertNotNull(connectorResponse._first);
      assertTrue(!connectorResponse._first.isEmpty());
    }
    catch (RavelException exception)
    {
      exception.printStackTrace();
    }
  }

  /**
   * Consulter informations par msisdn et date
   *
   * @throws SQLException
   *           SQLException
   */
  @Test
  public void testConsulterInformationsParMsisdnDate() throws SQLException
  {
    _dsReadLockMock.lock();
    EasyMock.expect(_dataSourceMock.getConnection()).andReturn(_connectionMock);
    EasyMock.expect(_connectionMock.prepareCall("{call PG_IHM_MOV.P_GET_INFORMATIONS(?,?,?,?,?,?,?,?,?,?,?) }")).andReturn(_callableStatementMock); //$NON-NLS-1$

    try
    {

      Tracabilite tracabilite = new Tracabilite("idBytel", "idcorrelation", "ihm", "processus", "idprocessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
      String msisdn = "350000000000001"; //$NON-NLS-1$
      String dateDemande = "22062016"; //$NON-NLS-1$
      String dateDebut = null;
      String dateFin = null;

      _callableStatementMock.setQueryTimeout(0);
      _callableStatementMock.setString("pi_DateDemande", dateDemande); //$NON-NLS-1$
      _callableStatementMock.setString("pi_DateDebut", null); //$NON-NLS-1$
      _callableStatementMock.setString("pi_DateFin", null); //$NON-NLS-1$
      _callableStatementMock.setString("pi_CodeMembre", null); //$NON-NLS-1$
      _callableStatementMock.setString("pi_Imei", null); //$NON-NLS-1$
      _callableStatementMock.setString("pi_Msisdn", msisdn); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("po_RESULT", OracleTypes.CURSOR); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter(AbstractDBConnector.RETOUR_RESULTAT, OracleTypes.NVARCHAR);
      _callableStatementMock.registerOutParameter(AbstractDBConnector.RETOUR_CATEGORIE, OracleTypes.NVARCHAR);
      _callableStatementMock.registerOutParameter(AbstractDBConnector.RETOUR_DIAGNOSTIC, OracleTypes.NVARCHAR);
      _callableStatementMock.registerOutParameter(AbstractDBConnector.RETOUR_LIBELLE, OracleTypes.NVARCHAR);
      EasyMock.expect(_callableStatementMock.execute()).andReturn(true);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_RESULTAT)).andReturn(StringConstants.OK);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_CATEGORIE)).andReturn(null);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_DIAGNOSTIC)).andReturn(null);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_LIBELLE)).andReturn(null);
      EasyMock.expect(_callableStatementMock.getObject("po_RESULT")).andReturn(_resultSetMock); //$NON-NLS-1$
      EasyMock.expect(_resultSetMock.next()).andReturn(true);
      EasyMock.expect(_resultSetMock.getString("imei")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("origine")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("code_membre")).andReturn(CodeMembre.BOT.name()); //$NON-NLS-1$
      EasyMock.expect(_resultSetMock.getString("msisdn")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("service")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("mouvement")).andReturn("350000000000001");//$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getTimestamp("date_etat")).andReturn(Timestamp.valueOf("2017-02-06 14:16:39.78")); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("dernier_etat")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("motif")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("date_insertion")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("heure_insertion")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.next()).andReturn(false);

      _resultSetMock.close();
      _callableStatementMock.close();
      _connectionMock.close();
      // Déverouillage du Lock
      _dsReadLockMock.unlock();

      PowerMock.replayAll();
      ConnectorResponse<List<InformationsDemande>, Retour> connectorResponse = _connector.consulterInformationsParMsisdnDate(tracabilite, msisdn, dateDemande, dateDebut, dateFin);

      assertEquals(StringConstants.OK, connectorResponse._second.getResultat());
      assertNull(connectorResponse._second.getCategorie());
      assertNull(connectorResponse._second.getLibelle());
      assertNull(connectorResponse._second.getDiagnostic());

      assertNotNull(connectorResponse._first);
      assertTrue(!connectorResponse._first.isEmpty());
    }
    catch (RavelException exception)
    {
      exception.printStackTrace();
    }
  }

  /**
   * Test to search for the last update for an existing IMEI
   *
   * @throws SQLException
   *           SQLException
   */
  @Test
  public void testConsultMOVDerniereDemande() throws SQLException
  {
    _dsReadLockMock.lock();
    EasyMock.expect(_dataSourceMock.getConnection()).andReturn(_connectionMock);
    EasyMock.expect(_connectionMock.prepareCall("{call P_002_cons_MOV_DerniereDemande(?,?,?,?,?,?) }")).andReturn(_callableStatementMock); //$NON-NLS-1$

    try
    {

      Tracabilite tracabilite = new Tracabilite("idBytel", "idcorrelation", "ihm", "processus", "idprocessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
      String imei = "350000000000001";//$NON-NLS-1$
      _callableStatementMock.setQueryTimeout(0);
      _callableStatementMock.setString("IMEI_In", imei); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("cursorx", OracleTypes.CURSOR); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("Retour_Resultat", OracleTypes.NVARCHAR); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("Retour_Categorie", OracleTypes.NVARCHAR); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("Retour_Diagnostic", OracleTypes.NVARCHAR); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("Retour_Libelle", OracleTypes.NVARCHAR); //$NON-NLS-1$
      EasyMock.expect(_callableStatementMock.execute()).andReturn(true);
      EasyMock.expect(_callableStatementMock.getObject("cursorx")).andReturn(_resultSetMock); //$NON-NLS-1$
      EasyMock.expect(_resultSetMock.next()).andReturn(true);
      EasyMock.expect(_resultSetMock.getLong("demande")).andReturn(1L); //$NON-NLS-1$
      EasyMock.expect(_resultSetMock.getString("imei")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("code_demandeur")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("code_membre")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("code_motif")).andReturn("IV"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("mouvement")).andReturn("350000000000001");//$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("flg_Luhn")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("flg_Tac")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("origine")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("msisdn")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("service")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("fabricant")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("designation")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("date_insertion")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("heure_insertion")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("instance_imei")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("imei_unique")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("statut")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("desc_motif")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getLong("priority")).andReturn(1L); //$NON-NLS-1$
      EasyMock.expect(_resultSetMock.getTimestamp("date_etat")).andReturn(Timestamp.valueOf("2017-02-06 14:16:39.78")); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_RESULTAT)).andReturn(StringConstants.OK);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_CATEGORIE)).andReturn(null);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_DIAGNOSTIC)).andReturn(null);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_LIBELLE)).andReturn(null);
      _resultSetMock.close();
      _callableStatementMock.close();
      _connectionMock.close();
      // Déverouillage du Lock
      _dsReadLockMock.unlock();

      PowerMock.replayAll();
      ConnectorResponse<Demande, Retour> connectorResponse = _connector.consultMOVDerniereDemande(tracabilite, imei);

      assertEquals(StringConstants.OK, connectorResponse._second.getResultat());
      assertEquals(null, connectorResponse._second.getCategorie());
      assertEquals(null, connectorResponse._second.getLibelle());
      assertEquals(null, connectorResponse._second.getDiagnostic());

      assertEquals(connectorResponse._first != null, true);
      assertEquals("350000000000001", connectorResponse._first.getImei()); //$NON-NLS-1$
      assertEquals("IV", connectorResponse._first.getCodeMotif()); //$NON-NLS-1$

    }
    catch (RavelException exception)
    {
      exception.printStackTrace();
    }

  }

  /**
   * Test to search for the last update for a non existing IMEI
   *
   * @throws SQLException
   *           SQLException
   */
  @Test
  public void testConsultMOVDerniereDemandeNonExistingIMEI() throws SQLException
  {
    _dsReadLockMock.lock();
    EasyMock.expect(_dataSourceMock.getConnection()).andReturn(_connectionMock);
    EasyMock.expect(_connectionMock.prepareCall("{call P_002_cons_MOV_DerniereDemande(?,?,?,?,?,?) }")).andReturn(_callableStatementMock); //$NON-NLS-1$

    try
    {

      Tracabilite tracabilite = new Tracabilite("idBytel", "idcorrelation", "ihm", "processus", "idprocessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
      String nonExistingImei = "990000000000001";//$NON-NLS-1$
      _callableStatementMock.setQueryTimeout(0);
      _callableStatementMock.setString("IMEI_In", nonExistingImei); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("cursorx", OracleTypes.CURSOR); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("Retour_Resultat", OracleTypes.NVARCHAR); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("Retour_Categorie", OracleTypes.NVARCHAR); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("Retour_Diagnostic", OracleTypes.NVARCHAR); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("Retour_Libelle", OracleTypes.NVARCHAR); //$NON-NLS-1$
      EasyMock.expect(_callableStatementMock.execute()).andReturn(true);
      EasyMock.expect(_callableStatementMock.getObject("cursorx")).andReturn(_resultSetMock); //$NON-NLS-1$
      EasyMock.expect(_resultSetMock.next()).andReturn(false);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_RESULTAT)).andReturn(StringConstants.KO);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_CATEGORIE)).andReturn(IMegConsts.CAT4);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_DIAGNOSTIC)).andReturn(""); //$NON-NLS-1$
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_LIBELLE)).andReturn(""); //$NON-NLS-1$
      _resultSetMock.close();
      _callableStatementMock.close();
      _connectionMock.close();
      // Déverouillage du Lock
      _dsReadLockMock.unlock();
      PowerMock.replayAll();
      ConnectorResponse<Demande, Retour> connectorResponse = _connector.consultMOVDerniereDemande(tracabilite, nonExistingImei);

      assertEquals(StringConstants.KO, connectorResponse._second.getResultat());
      assertEquals(IMegConsts.CAT4, connectorResponse._second.getCategorie());
      assertEquals("DONNEE_INCONNUE", connectorResponse._second.getDiagnostic());//$NON-NLS-1$

      assertEquals(true, connectorResponse._first == null);
    }
    catch (RavelException exception)
    {
      exception.printStackTrace();
    }

  }

  /**
   * Test to search for the updates for an existing IMEI Verifies the returned order based on statut and priority fields
   *
   * @throws SQLException
   *           SQLException
   */
  @Test
  public void testConsultMOVListeDemande() throws SQLException
  {
    _dsReadLockMock.lock();
    EasyMock.expect(_dataSourceMock.getConnection()).andReturn(_connectionMock);
    EasyMock.expect(_connectionMock.prepareCall("{call P_001_consult_MOV_ListeDemande(?,?,?,?,?,?) }")).andReturn(_callableStatementMock); //$NON-NLS-1$
    try
    {

      Tracabilite tracabilite = new Tracabilite("idBytel", "idcorrelation", "ihm", "processus", "idprocessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
      String imei = "350000000000001";//$NON-NLS-1$
      _callableStatementMock.setQueryTimeout(0);
      _callableStatementMock.setString("IMEI_In", imei); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("cursorx", OracleTypes.CURSOR); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("Retour_Resultat", OracleTypes.NVARCHAR); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("Retour_Categorie", OracleTypes.NVARCHAR); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("Retour_Diagnostic", OracleTypes.NVARCHAR); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("Retour_Libelle", OracleTypes.NVARCHAR); //$NON-NLS-1$
      EasyMock.expect(_callableStatementMock.execute()).andReturn(true);
      EasyMock.expect(_callableStatementMock.getObject("cursorx")).andReturn(_resultSetMock); //$NON-NLS-1$
      EasyMock.expect(_resultSetMock.next()).andReturn(true);
      EasyMock.expect(_resultSetMock.getLong("demande")).andReturn(1L); //$NON-NLS-1$
      EasyMock.expect(_resultSetMock.getString("imei")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("code_demandeur")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("code_membre")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("code_motif")).andReturn("IV"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("mouvement")).andReturn("350000000000001");//$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("flg_Luhn")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("flg_Tac")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("origine")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("msisdn")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("service")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("fabricant")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("designation")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("date_insertion")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("heure_insertion")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("instance_imei")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("imei_unique")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("statut")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getString("desc_motif")).andReturn("350000000000001"); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.getLong("priority")).andReturn(1L); //$NON-NLS-1$
      EasyMock.expect(_resultSetMock.getTimestamp("date_etat")).andReturn(Timestamp.valueOf("2017-02-06 14:16:39.78")); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_resultSetMock.next()).andReturn(false);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_RESULTAT)).andReturn(StringConstants.OK);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_CATEGORIE)).andReturn(null);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_DIAGNOSTIC)).andReturn(null);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_LIBELLE)).andReturn(null);
      _resultSetMock.close();
      _callableStatementMock.close();
      _connectionMock.close();
      // Déverouillage du Lock
      _dsReadLockMock.unlock();

      PowerMock.replayAll();
      ConnectorResponse<Demande[], Retour> connectorResponse = _connector.consultMOVListeDemande(tracabilite, imei);

      assertEquals(StringConstants.OK, connectorResponse._second.getResultat());
      assertEquals(null, connectorResponse._second.getCategorie());
      assertEquals(null, connectorResponse._second.getLibelle());
      assertEquals(null, connectorResponse._second.getDiagnostic());

      assertEquals(connectorResponse._first.length > 0, true);
      assertEquals("350000000000001", connectorResponse._first[0].getImei()); //$NON-NLS-1$
      assertEquals("IV", connectorResponse._first[0].getCodeMotif()); //$NON-NLS-1$
      assertEquals(new Long(1), connectorResponse._first[0].getPriority());

    }
    catch (RavelException exception)
    {
      exception.printStackTrace();
    }
  }

  /**
   * Test to search for the updates for a non existing IMEI
   *
   * @throws SQLException
   *           SQLException
   */
  @Test
  public void testConsultMOVListeDemandeNonExistingIMEI() throws SQLException
  {
    _dsReadLockMock.lock();
    EasyMock.expect(_dataSourceMock.getConnection()).andReturn(_connectionMock);
    EasyMock.expect(_connectionMock.prepareCall("{call P_001_consult_MOV_ListeDemande(?,?,?,?,?,?) }")).andReturn(_callableStatementMock); //$NON-NLS-1$

    try
    {
      Tracabilite tracabilite = new Tracabilite("idBytel", "idcorrelation", "ihm", "processus", "idprocessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
      String nonExistingImei = "990000000000001";//$NON-NLS-1$
      _callableStatementMock.setQueryTimeout(0);
      _callableStatementMock.setString("IMEI_In", nonExistingImei); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("cursorx", OracleTypes.CURSOR); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("Retour_Resultat", OracleTypes.NVARCHAR); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("Retour_Categorie", OracleTypes.NVARCHAR); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("Retour_Diagnostic", OracleTypes.NVARCHAR); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("Retour_Libelle", OracleTypes.NVARCHAR); //$NON-NLS-1$
      EasyMock.expect(_callableStatementMock.execute()).andReturn(true);
      EasyMock.expect(_callableStatementMock.getObject("cursorx")).andReturn(_resultSetMock); //$NON-NLS-1$
      EasyMock.expect(_resultSetMock.next()).andReturn(false);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_RESULTAT)).andReturn(StringConstants.OK);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_CATEGORIE)).andReturn(null);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_DIAGNOSTIC)).andReturn(null);
      EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_LIBELLE)).andReturn(null);
      _resultSetMock.close();
      _callableStatementMock.close();
      _connectionMock.close();
      // Déverouillage du Lock
      _dsReadLockMock.unlock();

      PowerMock.replayAll();
      ConnectorResponse<Demande[], Retour> connectorResponse = _connector.consultMOVListeDemande(tracabilite, nonExistingImei);

      assertEquals(StringConstants.KO, connectorResponse._second.getResultat());
      assertEquals(IMegConsts.CAT4, connectorResponse._second.getCategorie());
      assertEquals("DONNEE_INCONNUE", connectorResponse._second.getDiagnostic());//$NON-NLS-1$

      assertEquals(true, connectorResponse._first != null);
      assertEquals(true, connectorResponse._first.length == 0);

    }
    catch (RavelException exception)
    {
      exception.printStackTrace();
    }

  }

  /**
   * Insère une demande en base
   *
   * @throws RavelException
   *           exception
   * @throws SQLException
   *           SQLException
   */
  @Test
  public void testInsererDemandeMOV_TAC_0() throws RavelException, SQLException
  {
    Tracabilite tracabilite = new Tracabilite("idBytel", "idcorrelation", "ihm", "processus", "idprocessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$

    _dsReadLockMock.lock();
    EasyMock.expect(_dataSourceMock.getConnection()).andReturn(_connectionMock);
    EasyMock.expect(_connectionMock.prepareCall("{call P_003_GESTION_DEMANDE_BLKDBLK(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) }")).andReturn(_callableStatementMock); //$NON-NLS-1$
    _callableStatementMock.setQueryTimeout(0);
    Integer flgTAC = 0;
    _callableStatementMock.setString("IMEI_P", "271992600011795"); //$NON-NLS-1$ //$NON-NLS-2$
    _callableStatementMock.setString("DEMANDEUR_P", "BOT"); //$NON-NLS-1$ //$NON-NLS-2$
    _callableStatementMock.setString("CODE_MEMBRE_P", "BOT"); //$NON-NLS-1$ //$NON-NLS-2$
    _callableStatementMock.setString("CODE_MOTIF_P", "II"); //$NON-NLS-1$ //$NON-NLS-2$
    _callableStatementMock.setString("MOUVEMENT_P", "I"); //$NON-NLS-1$ //$NON-NLS-2$
    _callableStatementMock.setInt("FLG_LUHN_P", 1); //$NON-NLS-1$
    _callableStatementMock.setString("ORIGINE_P", null); //$NON-NLS-1$
    _callableStatementMock.setString("MSISDN_P", null); //$NON-NLS-1$
    _callableStatementMock.setString("SERVICE_P", null); //$NON-NLS-1$
    _callableStatementMock.setString("FABRICANT_P", null); //$NON-NLS-1$
    _callableStatementMock.setString("DESIGNATION_P", null); //$NON-NLS-1$
    _callableStatementMock.setString("FICHIER_SOURCE_P", null); //$NON-NLS-1$

    _callableStatementMock.registerOutParameter("RETOUR", OracleTypes.NUMBER); //$NON-NLS-1$
    _callableStatementMock.registerOutParameter("LOG_ERREUR", OracleTypes.VARCHAR); //$NON-NLS-1$
    _callableStatementMock.registerOutParameter("ERREUR", OracleTypes.VARCHAR); //$NON-NLS-1$
    _callableStatementMock.registerOutParameter("TAC", OracleTypes.NUMBER); //$NON-NLS-1$
    EasyMock.expect(_callableStatementMock.execute()).andReturn(true);
    EasyMock.expect(_callableStatementMock.getString("LOG_ERREUR")).andReturn(""); //$NON-NLS-1$//$NON-NLS-2$
    EasyMock.expect(_callableStatementMock.getString("ERREUR")).andReturn(""); //$NON-NLS-1$//$NON-NLS-2$
    EasyMock.expect(_callableStatementMock.getInt("TAC")).andReturn(0); //$NON-NLS-1$
    EasyMock.expect(_callableStatementMock.getInt("RETOUR")).andReturn(0); //$NON-NLS-1$
    _resultSetMock.close();
    _callableStatementMock.close();
    _connectionMock.close();
    // Déverouillage du Lock
    _dsReadLockMock.unlock();

    PowerMock.replayAll();
    ConnectorResponse<Integer, Retour> connectorResponse = _connector.insererDemandeMOV(tracabilite, "271992600011795", "BOT", "BOT", "II", "I", 1, null, null, null, null, null, null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$

    assertNotNull(connectorResponse._first);
    assertEquals(flgTAC, connectorResponse._first);
    assertEquals(StringConstants.OK, connectorResponse._second.getResultat());
    assertNull(connectorResponse._second.getLibelle());
    assertNull(connectorResponse._second.getDiagnostic());
  }

  /**
   * Insère une demande en base
   *
   * @throws RavelException
   *           exception
   * @throws SQLException
   *           SQLException
   */
  @Test
  public void testInsererDemandeMOV_TAC_1() throws RavelException, SQLException
  {
    Tracabilite tracabilite = new Tracabilite("idBytel", "idcorrelation", "ihm", "processus", "idprocessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$

    _dsReadLockMock.lock();
    EasyMock.expect(_dataSourceMock.getConnection()).andReturn(_connectionMock);
    EasyMock.expect(_connectionMock.prepareCall("{call P_003_GESTION_DEMANDE_BLKDBLK(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) }")).andReturn(_callableStatementMock); //$NON-NLS-1$
    _callableStatementMock.setQueryTimeout(0);

    _callableStatementMock.setString("IMEI_P", "350623890011795"); //$NON-NLS-1$ //$NON-NLS-2$
    _callableStatementMock.setString("DEMANDEUR_P", "BOT"); //$NON-NLS-1$ //$NON-NLS-2$
    _callableStatementMock.setString("CODE_MEMBRE_P", "BOT"); //$NON-NLS-1$//$NON-NLS-2$
    _callableStatementMock.setString("CODE_MOTIF_P", "II"); //$NON-NLS-1$//$NON-NLS-2$
    _callableStatementMock.setString("MOUVEMENT_P", "I"); //$NON-NLS-1$//$NON-NLS-2$
    _callableStatementMock.setInt("FLG_LUHN_P", 1); //$NON-NLS-1$
    _callableStatementMock.setString("ORIGINE_P", null); //$NON-NLS-1$
    _callableStatementMock.setString("MSISDN_P", null); //$NON-NLS-1$
    _callableStatementMock.setString("SERVICE_P", null); //$NON-NLS-1$
    _callableStatementMock.setString("FABRICANT_P", null); //$NON-NLS-1$
    _callableStatementMock.setString("DESIGNATION_P", null); //$NON-NLS-1$
    _callableStatementMock.setString("FICHIER_SOURCE_P", null); //$NON-NLS-1$

    _callableStatementMock.registerOutParameter("RETOUR", OracleTypes.NUMBER); //$NON-NLS-1$
    _callableStatementMock.registerOutParameter("LOG_ERREUR", OracleTypes.VARCHAR); //$NON-NLS-1$
    _callableStatementMock.registerOutParameter("ERREUR", OracleTypes.VARCHAR); //$NON-NLS-1$
    _callableStatementMock.registerOutParameter("TAC", OracleTypes.NUMBER); //$NON-NLS-1$
    EasyMock.expect(_callableStatementMock.execute()).andReturn(true);
    EasyMock.expect(_callableStatementMock.getString("LOG_ERREUR")).andReturn(""); //$NON-NLS-1$//$NON-NLS-2$
    EasyMock.expect(_callableStatementMock.getString("ERREUR")).andReturn(""); //$NON-NLS-1$//$NON-NLS-2$
    EasyMock.expect(_callableStatementMock.getInt("TAC")).andReturn(1); //$NON-NLS-1$
    EasyMock.expect(_callableStatementMock.getInt("RETOUR")).andReturn(0); //$NON-NLS-1$
    _resultSetMock.close();
    _callableStatementMock.close();
    _connectionMock.close();
    // Déverouillage du Lock
    _dsReadLockMock.unlock();

    PowerMock.replayAll();

    Integer flgTAC = 1;

    ConnectorResponse<Integer, Retour> connectorResponse = _connector.insererDemandeMOV(tracabilite, "350623890011795", "BOT", "BOT", "II", "I", 1, null, null, null, null, null, null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$

    assertNotNull(connectorResponse._first);
    assertEquals(flgTAC, connectorResponse._first);
    assertEquals(StringConstants.OK, connectorResponse._second.getResultat());
    assertNull(connectorResponse._second.getLibelle());
    assertNull(connectorResponse._second.getDiagnostic());
  }

  /**
   * Test insert of Etat
   *
   * @throws RavelException
   *           on error
   * @throws SQLException
   *           SQLException
   */
  @Test
  public void testInsertNewEtat() throws RavelException, SQLException
  {
    Tracabilite tracabilite = new Tracabilite("idBytel", "idcorrelation", "ihm", "processus", "idprocessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$

    _dsReadLockMock.lock();
    EasyMock.expect(_dataSourceMock.getConnection()).andReturn(_connectionMock);
    EasyMock.expect(_connectionMock.prepareCall("{call P_008_INSERT_NEW_ETAT(?,?,?,?,?,?,?,?,?,?,?,?) }")).andReturn(_callableStatementMock); //$NON-NLS-1$
    _callableStatementMock.setQueryTimeout(0);

    long demande = 3000002;
    long chrono = 90000;
    Timestamp dateEtat = new Timestamp(System.currentTimeMillis());
    String codeErreur = null;
    String descErreur = null;
    String fichier = "FR90000.UDP"; //$NON-NLS-1$
    long recyclage = 0;
    String statut = "ENVGIE"; //$NON-NLS-1$

    _callableStatementMock.setLong("pi_demande", demande); //$NON-NLS-1$
    _callableStatementMock.setString("pi_statut", statut); //$NON-NLS-1$
    _callableStatementMock.setString("pi_fichier", fichier); //$NON-NLS-1$
    _callableStatementMock.setTimestamp("pi_date_etat", dateEtat); //$NON-NLS-1$
    _callableStatementMock.setString("pi_code_erreur", codeErreur); //$NON-NLS-1$
    _callableStatementMock.setString("pi_description_erreur", descErreur); //$NON-NLS-1$
    _callableStatementMock.setLong("pi_chrono", chrono); //$NON-NLS-1$
    _callableStatementMock.setLong("pi_recyclage", recyclage); //$NON-NLS-1$

    _callableStatementMock.registerOutParameter("Retour_Resultat", OracleTypes.NVARCHAR); //$NON-NLS-1$
    _callableStatementMock.registerOutParameter("Retour_Categorie", OracleTypes.NVARCHAR); //$NON-NLS-1$
    _callableStatementMock.registerOutParameter("Retour_Diagnostic", OracleTypes.NVARCHAR); //$NON-NLS-1$
    _callableStatementMock.registerOutParameter("Retour_Libelle", OracleTypes.NVARCHAR); //$NON-NLS-1$
    EasyMock.expect(_callableStatementMock.execute()).andReturn(true);
    EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_RESULTAT)).andReturn(StringConstants.OK);
    EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_CATEGORIE)).andReturn(null);
    EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_DIAGNOSTIC)).andReturn(null);
    EasyMock.expect(_callableStatementMock.getString(AbstractDBConnector.RETOUR_LIBELLE)).andReturn(null);
    _resultSetMock.close();
    _callableStatementMock.close();
    _connectionMock.close();
    // Déverouillage du Lock
    _dsReadLockMock.unlock();

    PowerMock.replayAll();
    ConnectorResponse<Boolean, Retour> connectorResponse = _connector.insertNewEtat(tracabilite, demande, statut, fichier, dateEtat, codeErreur, descErreur, chrono, recyclage);

    Assert.assertTrue(connectorResponse._first);

    assertEquals(connectorResponse._second.getResultat(), "OK"); //$NON-NLS-1$
  }

  /**
   * Vérifie l'existence du code membre
   *
   * @throws RavelException
   *           exception
   * @throws SQLException
   *           SQLException
   */
  @Test
  public void testVerifierCodeMembre() throws RavelException, SQLException
  {

    Tracabilite tracabilite = new Tracabilite("idBytel", "idcorrelation", "ihm", "processus", "idprocessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
    String codeMembre = "BOT";//$NON-NLS-1$
    Long result = 1L;
    _dsReadLockMock.lock();
    EasyMock.expect(_dataSourceMock.getConnection()).andReturn(_connectionMock);
    EasyMock.expect(_connectionMock.prepareCall("{call P_005_CHECK_CODE_MEMBRE(?,?) }")).andReturn(_callableStatementMock); //$NON-NLS-1$

    _callableStatementMock.setQueryTimeout(0);

    _callableStatementMock.setString("CODE_MEMBRE_P", codeMembre); //$NON-NLS-1$

    _callableStatementMock.registerOutParameter("RETOUR", OracleTypes.NUMBER); //$NON-NLS-1$

    EasyMock.expect(_callableStatementMock.execute()).andReturn(true);

    EasyMock.expect(_callableStatementMock.getLong("RETOUR")).andReturn(1L); //$NON-NLS-1$
    _resultSetMock.close();
    _callableStatementMock.close();
    _connectionMock.close();
    // Déverouillage du Lock
    _dsReadLockMock.unlock();

    PowerMock.replayAll();
    ConnectorResponse<Long, Retour> connectorResponse = _connector.verifierCodeMembre(tracabilite, codeMembre);

    assertEquals(StringConstants.OK, connectorResponse._second.getResultat());
    assertEquals(null, connectorResponse._second.getCategorie());
    assertEquals(null, connectorResponse._second.getLibelle());
    assertEquals(null, connectorResponse._second.getDiagnostic());

    assertNotNull(connectorResponse._first);
    assertEquals(result, connectorResponse._first);
  }

  /**
   * Vérifie l'existence du code motif
   *
   * @throws RavelException
   *           exception
   * @throws SQLException
   *           SQLException
   */
  @Test
  public void testVerifierCodeMotif() throws RavelException, SQLException
  {
    _dsReadLockMock.lock();
    EasyMock.expect(_dataSourceMock.getConnection()).andReturn(_connectionMock);
    EasyMock.expect(_connectionMock.prepareCall("{call P_004_CHECK_CODE_MOTIF(?,?) }")).andReturn(_callableStatementMock); //$NON-NLS-1$

    Tracabilite tracabilite = new Tracabilite("idBytel", "idcorrelation", "ihm", "processus", "idprocessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
    String codeMotif = "II";//$NON-NLS-1$
    Long result = 1L;
    _callableStatementMock.setQueryTimeout(0);

    _callableStatementMock.setString("CODE_MOTIF_P", codeMotif); //$NON-NLS-1$

    _callableStatementMock.registerOutParameter("RETOUR", OracleTypes.NUMBER); //$NON-NLS-1$

    EasyMock.expect(_callableStatementMock.execute()).andReturn(true);

    EasyMock.expect(_callableStatementMock.getLong("RETOUR")).andReturn(1L); //$NON-NLS-1$
    _resultSetMock.close();
    _callableStatementMock.close();
    _connectionMock.close();
    // Déverouillage du Lock
    _dsReadLockMock.unlock();

    PowerMock.replayAll();
    ConnectorResponse<Long, Retour> connectorResponse = _connector.verifierCodeMotif(tracabilite, codeMotif);

    assertEquals(StringConstants.OK, connectorResponse._second.getResultat());
    assertEquals(null, connectorResponse._second.getCategorie());
    assertEquals(null, connectorResponse._second.getLibelle());
    assertEquals(null, connectorResponse._second.getDiagnostic());

    assertNotNull(connectorResponse._first);
    assertEquals(result, connectorResponse._first);
  }

  /**
   * Vérifie l'existence d'un doublon par rapport aux demandes encours en base
   *
   * @throws SQLException
   *           SQLException
   */
  @Test
  public void testVerifierDedoublonnage_KO() throws SQLException
  {

    try
    {

      Tracabilite tracabilite = new Tracabilite("idBytel", "idcorrelation", "ihm", "processus", "idprocessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
      String imei = "350105800305511"; //$NON-NLS-1$
      String codeMembre = "BOT"; //$NON-NLS-1$
      String mouvement = "I";//$NON-NLS-1$
      _dsReadLockMock.lock();
      EasyMock.expect(_dataSourceMock.getConnection()).andReturn(_connectionMock);
      EasyMock.expect(_connectionMock.prepareCall("{call P_006_CHECK_DEDOUBLONNAGE(?,?,?,?,?,?) }")).andReturn(_callableStatementMock); //$NON-NLS-1$
      _callableStatementMock.setQueryTimeout(0);

      _callableStatementMock.setString("IMEI_P", imei); //$NON-NLS-1$
      _callableStatementMock.setString("MOUVEMENT_P", mouvement); //$NON-NLS-1$
      _callableStatementMock.setString("CODE_MEMBRE_P", codeMembre); //$NON-NLS-1$

      _callableStatementMock.registerOutParameter("RETOUR", OracleTypes.NUMBER); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("LOG_ERREUR", OracleTypes.VARCHAR); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("ERREUR", OracleTypes.VARCHAR); //$NON-NLS-1$
      EasyMock.expect(_callableStatementMock.execute()).andReturn(true);
      EasyMock.expect(_callableStatementMock.getString("LOG_ERREUR")).andReturn("MOV-002360"); //$NON-NLS-1$//$NON-NLS-2$
      EasyMock.expect(_callableStatementMock.getString("ERREUR")).andReturn("IMEI est déjà blacklisté (I)"); //$NON-NLS-1$//$NON-NLS-2$
      EasyMock.expect(_callableStatementMock.getInt("RETOUR")).andReturn(1); //$NON-NLS-1$
      _callableStatementMock.close();
      _connectionMock.close();
      // Déverouillage du Lock
      _dsReadLockMock.unlock();

      PowerMock.replayAll();
      ConnectorResponse<Boolean, Retour> connectorResponse = _connector.verifierDedoublonnage(tracabilite, imei, mouvement, codeMembre);

      assertNotNull(connectorResponse._first);
      assertEquals(Boolean.FALSE, connectorResponse._first);
      assertEquals(StringConstants.KO, connectorResponse._second.getResultat());
      assertEquals("IMEI est déjà blacklisté (I)", connectorResponse._second.getLibelle()); //$NON-NLS-1$
      assertEquals("MOV-002360", connectorResponse._second.getCategorie()); //$NON-NLS-1$
    }
    catch (RavelException exception)
    {
      exception.printStackTrace();
    }
  }

  /**
   * Vérifie l'existence d'un doublon par rapport aux demandes encours en base
   *
   * @throws SQLException
   *           SQLException
   */
  @Test
  public void testVerifierDedoublonnage_OK() throws SQLException
  {

    try
    {

      Tracabilite tracabilite = new Tracabilite("idBytel", "idcorrelation", "ihm", "processus", "idprocessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
      String imei = "351872026465440"; //$NON-NLS-1$
      String codeMembre = "BOT"; //$NON-NLS-1$
      String mouvement = "I";//$NON-NLS-1$
      _dsReadLockMock.lock();
      EasyMock.expect(_dataSourceMock.getConnection()).andReturn(_connectionMock);
      EasyMock.expect(_connectionMock.prepareCall("{call P_006_CHECK_DEDOUBLONNAGE(?,?,?,?,?,?) }")).andReturn(_callableStatementMock); //$NON-NLS-1$
      _callableStatementMock.setQueryTimeout(0);

      _callableStatementMock.setString("IMEI_P", imei); //$NON-NLS-1$
      _callableStatementMock.setString("MOUVEMENT_P", mouvement); //$NON-NLS-1$
      _callableStatementMock.setString("CODE_MEMBRE_P", codeMembre); //$NON-NLS-1$

      _callableStatementMock.registerOutParameter("RETOUR", OracleTypes.NUMBER); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("LOG_ERREUR", OracleTypes.VARCHAR); //$NON-NLS-1$
      _callableStatementMock.registerOutParameter("ERREUR", OracleTypes.VARCHAR); //$NON-NLS-1$
      EasyMock.expect(_callableStatementMock.execute()).andReturn(true);
      EasyMock.expect(_callableStatementMock.getString("LOG_ERREUR")).andReturn(""); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_callableStatementMock.getString("ERREUR")).andReturn(""); //$NON-NLS-1$//$NON-NLS-2$
      EasyMock.expect(_callableStatementMock.getInt("RETOUR")).andReturn(0); //$NON-NLS-1$
      _callableStatementMock.close();
      _connectionMock.close();
      // Déverouillage du Lock
      _dsReadLockMock.unlock();

      PowerMock.replayAll();
      ConnectorResponse<Boolean, Retour> connectorResponse = _connector.verifierDedoublonnage(tracabilite, imei, mouvement, codeMembre);

      assertNotNull(connectorResponse._first);
      assertEquals(Boolean.TRUE, connectorResponse._first);
      assertEquals(StringConstants.OK, connectorResponse._second.getResultat());
      assertNull(connectorResponse._second.getLibelle());
      assertNull(connectorResponse._second.getDiagnostic());

    }
    catch (RavelException exception)
    {
      exception.printStackTrace();
    }
  }

  /**
   * Vérifie l'existence d'un doublon par rapport aux demandes encours en base
   *
   * @throws RavelException
   *           exception
   * @throws SQLException
   *           SQLException
   */
  @Test
  public void testVerifierDedoublonnage_Rejet() throws RavelException, SQLException
  {

    Tracabilite tracabilite = new Tracabilite("idBytel", "idcorrelation", "ihm", "processus", "idprocessus", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$

    String imei = "350000000000000"; //$NON-NLS-1$
    String codeMembre = "BOT"; //$NON-NLS-1$
    String mouvement = "I";//$NON-NLS-1$
    _dsReadLockMock.lock();
    EasyMock.expect(_dataSourceMock.getConnection()).andReturn(_connectionMock);
    EasyMock.expect(_connectionMock.prepareCall("{call P_006_CHECK_DEDOUBLONNAGE(?,?,?,?,?,?) }")).andReturn(_callableStatementMock); //$NON-NLS-1$
    _callableStatementMock.setQueryTimeout(0);

    _callableStatementMock.setString("IMEI_P", imei); //$NON-NLS-1$
    _callableStatementMock.setString("MOUVEMENT_P", mouvement); //$NON-NLS-1$
    _callableStatementMock.setString("CODE_MEMBRE_P", codeMembre); //$NON-NLS-1$

    _callableStatementMock.registerOutParameter("RETOUR", OracleTypes.NUMBER); //$NON-NLS-1$
    _callableStatementMock.registerOutParameter("LOG_ERREUR", OracleTypes.VARCHAR); //$NON-NLS-1$
    _callableStatementMock.registerOutParameter("ERREUR", OracleTypes.VARCHAR); //$NON-NLS-1$
    EasyMock.expect(_callableStatementMock.execute()).andReturn(true);
    EasyMock.expect(_callableStatementMock.getString("LOG_ERREUR")).andReturn("MOV-002360"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_callableStatementMock.getString("ERREUR")).andReturn("Rejet des demandes sur des IMEI en cours de traitement dans MOV"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_callableStatementMock.getInt("RETOUR")).andReturn(1); //$NON-NLS-1$
    _callableStatementMock.close();
    _connectionMock.close();
    // Déverouillage du Lock
    _dsReadLockMock.unlock();

    PowerMock.replayAll();
    ConnectorResponse<Boolean, Retour> connectorResponse = _connector.verifierDedoublonnage(tracabilite, imei, mouvement, codeMembre);

    assertNotNull(connectorResponse._first);
    assertEquals(Boolean.FALSE, connectorResponse._first);
    assertEquals(StringConstants.KO, connectorResponse._second.getResultat());
    assertEquals("Rejet des demandes sur des IMEI en cours de traitement dans MOV", connectorResponse._second.getLibelle()); //$NON-NLS-1$
    assertEquals("MOV-002360", connectorResponse._second.getCategorie()); //$NON-NLS-1$

  }

  /**
   * Auxiliary function to find a DemandeBotClosrsx on list by the demande
   *
   * @param list
   *          the list
   * @param demande
   *          the demande to find
   *
   * @return the DemandeBorClosrsx if found else null
   */
  private DemandeBotClosrsx findDemandeBotClosrsxByDemande(List<DemandeBotClosrsx> list, long demande)
  {
    if ((list == null) || list.isEmpty())
    {
      return null;
    }

    for (DemandeBotClosrsx demandeBotClosrsx : list)
    {
      if (demandeBotClosrsx.getDemande() == demande)
      {
        return demandeBotClosrsx;
      }
    }

    return null;
  }
}
