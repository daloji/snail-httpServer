/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.idgenerator;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.probes.AvgDoubleCollectorItem;
import com.bytel.ravel.common.probes.AvgFlowPerSecondCollector;
import com.bytel.ravel.common.probes.RavelProbeConfigurationManager;
import com.bytel.ravel.services.connector.BaseProxy;
import com.bytel.ravel.services.connector.ConnectorExecution;
import com.bytel.ravel.services.connector.ConnectorManager;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

/**
 *
 * @author rrosa
 * @version ($Revision$ $Date$)
 */
public final class IDGeneratorProxy extends BaseProxy implements IIDGenerator
{
  /**
   * Proxy instance.
   */
  private static IDGeneratorProxy _instance = new IDGeneratorProxy();

  /**
   * @return The proxy instance.
   */
  public static IDGeneratorProxy getInstance()
  {
    return _instance;
  }

  /**
   * For probe to count the amount of call to the obtenirIdentifiantUnique operation
   */
  AvgFlowPerSecondCollector _avg_obtenirIdentifiantUnique_call_counter;

  /**
   * For probe to count the execution time of call to the obtenirIdentifiantUnique operation
   */
  AvgDoubleCollectorItem _avg_obtenirIdentifiantUnique_ExecTime;

  /**
   * Constructor
   */
  private IDGeneratorProxy()
  {
    _avg_obtenirIdentifiantUnique_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_obtenirIdentifiantUnique_call_counter", "IDGeneratorProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_obtenirIdentifiantUnique_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_obtenirIdentifiantUnique_ExecTime", "IDGeneratorProxy"); //$NON-NLS-1$//$NON-NLS-2$
  }

  @Override
  public ConnectorResponse<Retour, String> obtenirIdentifiantUnique(Tracabilite tracabilite_p, String type_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, String>>(IIDGeneratorConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, String> run() throws RavelException
      {
        IIDGeneratorConnector idgeneratorConnector = (IIDGeneratorConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_obtenirIdentifiantUnique_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return idgeneratorConnector.obtenirIdentifiantUnique(tracabilite_p, type_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_obtenirIdentifiantUnique_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

}
