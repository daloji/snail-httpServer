/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.idgenerator;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

/**
 *
 * @author rrosa
 * @version ($Revision$ $Date$)
 */
public interface IIDGenerator
{
  /**
   * Method obtenirIdentifiantUnique.
   *
   * @param tracabilite_p
   *          The Tracabilite
   * @param type_p
   *          The type
   * @return The retour
   * @throws RavelException
   *           Thrown if any errors occurred
   */
  public ConnectorResponse<Retour, String> obtenirIdentifiantUnique(Tracabilite tracabilite_p, String type_p) throws RavelException;
}
