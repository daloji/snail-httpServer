/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.idgenerator;

import java.text.MessageFormat;
import java.util.HashMap;

import javax.ws.rs.HttpMethod;
import javax.ws.rs.core.Response;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.conf.generated.Param;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.services.conf.connector.generated.Connector;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.connector.RESTRequest.RESTRequestBuilder;
import com.bytel.spirit.common.shared.misc.connectors.AbstractInternalRESTConnector;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.RetourConverter;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.uniqueid.response.ObtenirIdentifiantUniqueResponse;

/**
 *
 * @author rrosa
 * @version ($Revision$ $Date$)
 */
public class IDGeneratorConnector extends AbstractInternalRESTConnector implements IIDGeneratorConnector
{
  /**
   * Path for PAD0001 operation
   */
  private static final String PAD0001_PATH_PARAM = "PAD0001_ObtenirIdentifiantUnique"; //$NON-NLS-1$

  /**
   * The constant for MissingConfigurationParameter
   */
  private static final String MESSAGE_MISSING_CONFIGURATION_PARAMETER = Messages.getString("IDGeneratorConnector.MissingConfigurationParameter"); //$NON-NLS-1$

  /**
   * The constant for JsonErrorMessage
   */
  private static final String MESSAGE_JSON_ERROR_MESSAGE = Messages.getString("IDGeneratorConnector.JsonErrorMessage"); //$NON-NLS-1$

  /**
   * The constant for obtenirIdentifiantUnique service
   */
  private static final String METHOD_NAME_OBTENIR_IDENTIFIANT_UNIQUE = "obtenirIdentifiantUnique"; //$NON-NLS-1$

  /**
   * The constant for typeId param
   */
  private static final String PARAM_TYPE_ID = "typeId"; //$NON-NLS-1$

  /**
   * Path for PAD0001
   */
  private String _identifiantUniqueUrl;

  @Override
  public String getConfigParameter(String connectorID_p, String paramName_p) throws RavelException
  {
    return null;
  }

  @Override
  public void loadConnectorConfiguration(Connector connector_p) throws RavelException
  {
    super.loadConnectorConfiguration(connector_p);

    // Get and validate specific configuration parameters
    for (Param param : connector_p.getParam())
    {
      switch (param.getName())
      {
        case PAD0001_PATH_PARAM:
          _identifiantUniqueUrl = param.getValue();
          break;
        default:
          break;
      }
    }

    if (StringTools.isNullOrEmpty(_identifiantUniqueUrl))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD0001_PATH_PARAM));
    }
  }

  @Override
  public ConnectorResponse<Retour, String> obtenirIdentifiantUnique(Tracabilite tracabilite_p, String type_p) throws RavelException
  {
    try
    {
      // Build query parameters
      HashMap<String, String> queryParams = new HashMap<>();

      if (StringTools.isNotNullOrEmpty(type_p))
      {
        queryParams.put(PARAM_TYPE_ID, type_p);
      }

      // Call SAAB
      final Response response;
      try
      {
        RESTRequestBuilder restRequestBuilder = new RESTRequestBuilder();
        restRequestBuilder.httpMethod(HttpMethod.GET).traceability(tracabilite_p).method(METHOD_NAME_OBTENIR_IDENTIFIANT_UNIQUE).headers(SPIRIT_STARK_REQUEST_HEADER).path(_identifiantUniqueUrl).queryParameter(queryParams);
        response = sendRequest(restRequestBuilder.build());
      }
      catch (Exception e)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e.getMessage()), null);
      }

      // Get the content to a JSON string
      String jsonResponse = getContent(response, METHOD_NAME_OBTENIR_IDENTIFIANT_UNIQUE, tracabilite_p);

      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }

      ObtenirIdentifiantUniqueResponse obtenirIdentifiantUniqueResponse = GsonTools.getIso8601Ms().fromJson(jsonResponse, ObtenirIdentifiantUniqueResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(obtenirIdentifiantUniqueResponse.getRetour());
      String uniqueIdValue = obtenirIdentifiantUniqueResponse.getUniqueIdValue();

      return new ConnectorResponse<>(retour, uniqueIdValue);
    }
    catch (Exception e)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e.getMessage()), null);

    }
  }
}
