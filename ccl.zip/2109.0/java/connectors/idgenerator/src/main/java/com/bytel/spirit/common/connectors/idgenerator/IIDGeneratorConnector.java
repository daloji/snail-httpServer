/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.idgenerator;

import com.bytel.ravel.services.connector.IConnector;

/**
 *
 * @author rrosa
 * @version ($Revision$ $Date$)
 */
public interface IIDGeneratorConnector extends IIDGenerator, IConnector
{

  /**
   * The id to retrieve the connector.
   */
  public String BEAN_ID = "IDGeneratorConnector"; //$NON-NLS-1$
}
