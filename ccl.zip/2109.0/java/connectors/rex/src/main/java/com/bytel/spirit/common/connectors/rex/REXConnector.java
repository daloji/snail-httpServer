/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.rex;

import java.net.URLEncoder;
import java.text.MessageFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.ws.rs.HttpMethod;
import javax.ws.rs.core.Response;

import org.apache.cxf.common.util.CollectionUtils;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.conf.generated.Param;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.json.IRavelJson;
import com.bytel.ravel.common.json.RavelJson;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.services.conf.connector.generated.Connector;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.connector.RESTRequest;
import com.bytel.ravel.services.connector.RESTRequest.RESTRequestBuilder;
import com.bytel.spirit.common.connectors.rex.services.ConfigurationPfsCompositeService;
import com.bytel.spirit.common.shared.functional.types.json.RavelJsonTools;
import com.bytel.spirit.common.shared.functional.types.json.notification.AbstractNotificationReseau;
import com.bytel.spirit.common.shared.misc.connectors.AbstractInternalRESTConnector;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.BasicResponse;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.ressources.RetourConverter;
import com.bytel.spirit.common.shared.misc.ressources.SpiritConstants;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.rex.AssociationPfiReconcialitionCommerciale;
import com.bytel.spirit.common.shared.saab.rex.BlocageEquipement;
import com.bytel.spirit.common.shared.saab.rex.ClientImpacte;
import com.bytel.spirit.common.shared.saab.rex.ComparaisonCommerciale;
import com.bytel.spirit.common.shared.saab.rex.ConfigurationPfs;
import com.bytel.spirit.common.shared.saab.rex.ConfigurationPfsComposite;
import com.bytel.spirit.common.shared.saab.rex.DecisionExploitation;
import com.bytel.spirit.common.shared.saab.rex.ErreurSpirit;
import com.bytel.spirit.common.shared.saab.rex.HistorisationEligibilite;
import com.bytel.spirit.common.shared.saab.rex.LigneDeTestEligDSL;
import com.bytel.spirit.common.shared.saab.rex.OperationVieReseau;
import com.bytel.spirit.common.shared.saab.rex.ReconciliationCommerciale;
import com.bytel.spirit.common.shared.saab.rex.RequeteExploitation;
import com.bytel.spirit.common.shared.saab.rex.TemplateRequeteExploitation;
import com.bytel.spirit.common.shared.saab.rex.TraitementDeMasse;
import com.bytel.spirit.common.shared.saab.rex.TypeConfiguration;
import com.bytel.spirit.common.shared.saab.rex.request.CreateComparaisonCommercialeCompositeRequest;
import com.bytel.spirit.common.shared.saab.rex.request.CreateErreurSpiritRequest;
import com.bytel.spirit.common.shared.saab.rex.request.CreateOrUpdateReconciliationCommercialeRequest;
import com.bytel.spirit.common.shared.saab.rex.request.ListeCleRechercheBlocageEquipementRequest;
import com.bytel.spirit.common.shared.saab.rex.request.ListeCleRechercheNotificationReseauRequest;
import com.bytel.spirit.common.shared.saab.rex.request.ListeCleRechercheOperationVieReseauRequest;
import com.bytel.spirit.common.shared.saab.rex.request.ManageReconciliationCommercialeEnMasseRequest;
import com.bytel.spirit.common.shared.saab.rex.request.OperationVieReseauModifierListeClientImpacteRequest;
import com.bytel.spirit.common.shared.saab.rex.request.OperationVieReseauModifierStatutRequest;
import com.bytel.spirit.common.shared.saab.rex.request.ReconciliationCommercialeEnMasseAjouterRequest;
import com.bytel.spirit.common.shared.saab.rex.request.UpdateBlocageEquipementRequest;
import com.bytel.spirit.common.shared.saab.rex.request.UpdateErreurSpiritRequest;
import com.bytel.spirit.common.shared.saab.rex.request.UpdateNotificationReseauStatutRequest;
import com.bytel.spirit.common.shared.saab.rex.response.GetComparaisonCommercialeCompositeResponse;
import com.bytel.spirit.common.shared.saab.rex.response.GetErreurSpiritResponse;
import com.bytel.spirit.common.shared.saab.rex.response.GetNotificationReseauResponseSpirit;
import com.bytel.spirit.common.shared.saab.rex.response.GetReconciliationCommercialeResponse;
import com.bytel.spirit.common.shared.saab.rex.response.GetTraitementDeMasseResponse;
import com.bytel.spirit.common.shared.saab.rex.response.GetLigneDeTestEligDSLResponse;
import com.bytel.spirit.common.shared.saab.rex.response.ListeBlocageEquipementResponse;
import com.bytel.spirit.common.shared.saab.rex.response.ListeDecisionExploitationResponse;
import com.bytel.spirit.common.shared.saab.rex.response.ListeOperationVieReseauResponse;
import com.bytel.spirit.common.shared.saab.rex.response.ListeRequeteExploitationResponse;
import com.bytel.spirit.common.shared.saab.rex.response.ListeTemplateRequeteExploitationResponse;
import com.bytel.spirit.common.shared.saab.rex.response.PutReconciliationCommercialeResponse;

/**
 *
 * @author kbettenc
 * @version ($Revision$ $Date$)
 */
public class REXConnector extends AbstractInternalRESTConnector implements IREXConnector
{
  /**
   * Path for PAD6001 operation
   */
  private static final String PAD6001_PATH_PARAM = "PAD6001_ComparaisonCommercialeComposite"; //$NON-NLS-1$

  /**
   * Path for PAD6002 operation
   */
  private static final String PAD6002_PATH_PARAM = "PAD6002_ReconciliationCommerciale"; //$NON-NLS-1$

  /**
   * Path for PAD6003 operation
   */
  private static final String PAD6003_PATH_PARAM = "PAD6003_ErreurSpirit"; //$NON-NLS-1$

  /**
   * Path for PAD6004 operation
   */
  private static final String PAD6004_PATH_PARAM = "PAD6004_TraitementDeMasse"; //$NON-NLS-1$

  /**
   * Path for PAD6005 operation
   */
  private static final String PAD6005_PATH_PARAM = "PAD6005_ReconciliationCommercialeEnMasse"; //$NON-NLS-1$

  /**
   * Path for PAD6006 operation : ConfigurationPfsComposite
   */
  public static final String PAD6006_PATH_PARAM = "PAD6006_ConfigurationPfsComposite"; //$NON-NLS-1$

  /**
   * Path for PAD6005 operation
   */
  private static final String PAD6007_PATH_PARAM = "PAD6007_ConfigurationProsper"; //$NON-NLS-1$

  /**
   * Path for PAD6008 operation
   */
  private static final String PAD6008_PATH_PARAM = "PAD6008_NotificationReseau"; //$NON-NLS-1$

  /**
   * Path for PAD6009_PATH_PARAM operation
   */
  private static final String PAD6009_PATH_PARAM = "PAD6009_CleRechercheNotificationReseau"; //$NON-NLS-1$

  /**
   * Path for PAD6010_PATH_PARAM operation : HistorisationEligibilite
   */
  private static final String PAD6010_PATH_PARAM = "PAD6010_HistorisationEligibilite"; //$NON-NLS-1$

  /**
   * Path for PAD6011_PATH_PARAM operation : OperationVieReseau
   */
  private static final String PAD6011_PATH_PARAM = "PAD6011_OperationVieReseau"; //$NON-NLS-1$

  /**
   * Path for PAD6012_PATH_PARAM operation : CleRechercheOperationVieReseau
   */
  private static final String PAD6012_PATH_PARAM = "PAD6012_CleRechercheOperationVieReseau"; //$NON-NLS-1$

  /***
   * Path for PAD6013_PATH_PARAM operation : BlocageEquipement
   */
  private static final String PAD6013_PATH_PARAM = "PAD6013_BlocageEquipement";//$NON-NLS-1$

  /**
   * Path for PAD6014_PATH_PARAM operation : CleRechercheBlocageEquipement
   */
  private static final String PAD6014_PATH_PARAM = "PAD6014_CleRechercheBlocageEquipement"; //$NON-NLS-1$

  /**
   * Path for PAD6015_PATH_PARAM operation : LigneDeTestEligDSL
   */
  private static final String PAD6015_PATH_PARAM = "PAD6015_LigneDeTestEligDSL"; //$NON-NLS-1$

  /**
   * The constant for MissingConfigurationParameter
   */
  public static final String MESSAGE_MISSING_CONFIGURATION_PARAMETER = Messages.getString("REXConnector.MissingConfigurationParameter"); //$NON-NLS-1$

  /**
   * The constant for JsonErrorMessage
   */
  private static final String MESSAGE_JSON_ERROR_MESSAGE = Messages.getString("REXConnector.JsonErrorMessage"); //$NON-NLS-1$

  /**
   * The constant for comparaisonCommercialeCompositeCreer service
   */
  private static final String METHOD_NAME_COMPARAISON_COMMERCIALE_COMPOSITE_CREER = "comparaisonCommercialeCompositeCreer"; //$NON-NLS-1$

  /**
   * The constant for erreurSpiritCreer service
   */
  private static final String METHOD_NAME_ERREUR_SPIRIT_CREER = "erreurSpiritCreer"; //$NON-NLS-1$

  /**
   * The constant for comparaisonCommercialeCompositeLireTousParIdCmd service
   */
  private static final String METHOD_NAME_COMPARAISON_COMMERCIALE_COMPOSITE_LIRE_DERNIER_PAR_ID_CMD = "comparaisonCommercialeCompositeLireTousParIdCmd"; //$NON-NLS-1$

  /**
   * The constant for reconciliationCommercialeCreer service
   */
  private static final String METHOD_NAME_RECONCILIATION_COMMERCIALE_CREER = "reconciliationCommercialeCreer"; //$NON-NLS-1$

  /**
   * The constant for reconciliationCommercialeAjouter service
   */
  private static final String METHOD_NAME_RECONCILIATION_COMMERCIALE_AJOUTER = "reconciliationCommercialeAjouter"; //$NON-NLS-1$

  /**
   * The constant for reconciliationCommercialeLireTousParClientOperateurNoCompte service
   */
  private static final String METHOD_NAME_RECONCILIATION_COMMERCIALE_LIRE_TOUS_PAR_CLIENT_OPERATEUR_NO_COMPTE = "reconciliationCommercialeLireTousParClientOperateurNoCompte"; //$NON-NLS-1$

  /**
   * The constant for reconciliationCommercialeEnMasseLireTous service
   */
  private static final String METHOD_NAME_RECONCILIATION_COMMERCIALE_EN_MASSE_LIRE_TOUS = "reconciliationCommercialeEnMasseLireTous"; //$NON-NLS-1$

  /**
   * The constant for erreurSpiritLireTousParStatutPeriod service
   */
  private static final String METHOD_NAME_ERREUR_SPIRIT_LIRE_TOUS_PAR_STATUT_PERIOD = "erreurSpiritLireTousParStatutPeriod"; //$NON-NLS-1$

  /**
   * The constant for erreurSpiritLireUn service
   */
  private static final String METHOD_NAME_ERREUR_SPIRIT_LIRE_UN = "erreurSpiritLireUn"; //$NON-NLS-1$

  /**
   * The constant for erreurSpiritLireTousSurPeriod service
   */
  private static final String METHOD_NAME_ERREUR_SPIRIT_LIRE_TOUS_SUR_PERIOD = "erreurSpiritLireTousSurPeriod"; //$NON-NLS-1$

  /**
   * The constant for erreurSpiritModifierStatut service
   */
  private static final String METHOD_NAME_ERREUR_SPIRIT_MODIFIER_STATUT = "erreurSpiritModifierStatut"; //$NON-NLS-1$

  /**
   * The constant for reconciliationCommercialeLireTousParIdReconciliation service
   */
  private static final String METHOD_NAME_RECONCILIATION_COMMERCIALE_LIRE_TOUS_PAR_ID_RECONCILIATION = "reconciliationCommercialeLireTousParIdReconciliation"; //$NON-NLS-1$

  /**
   * The constant for reconciliationCommercialeModifier service
   */
  private static final String METHOD_NAME_RECONCILIATION_COMMERCIALE_MODIFIER = "reconciliationCommercialeModifier"; //$NON-NLS-1$

  /**
   * The constant for reconciliationCommercialeEnMasseAcquitterUn service
   */
  private static final String METHOD_NAME_RECONCILIATION_COMMERCIALE_EN_MASSE_ACQUITTER_UN = "reconciliationCommercialeEnMasseAcquitterUn"; //$NON-NLS-1$

  /**
   * The constant for traitementDeMasseLireTous service
   */
  private static final String METHOD_NAME_TRAITEMENT_MASSE_LIRE_TOUS = "traitementDeMasseLireTous"; //$NON-NLS-1$

  /**
   * The constant for traitementDeMasseLireUn service
   */
  private static final String METHOD_NAME_TRAITEMENT_MASSE_LIRE_UN = "traitementDeMasseLireUn"; //$NON-NLS-1$

  /**
   * The constant for traitementDeMasseModifierStatutEnCours service
   */
  private static final String METHOD_NAME_TRAITEMENT_MASSE_MODIFIER_STATUT_EN_COURS = "traitementDeMasseModifierStatutEnCours"; //$NON-NLS-1$

  /**
   * The constant for traitementDeMasseCreer service
   */
  private static final String METHOD_NAME_TRAITEMENT_MASSE_CREER = "traitementDeMasseCreer"; //$NON-NLS-1$

  /**
   * The constant for historisationEligibiliteCreer service
   */
  private static final String METHOD_NAME_HISTORISATION_ELIGIBILITE_CREER = "historisationEligibiliteCreer"; //$NON-NLS-1$

  /**
   * The constant for requeteExploitationLireUn service
   */
  private static final String METHODE_NAME_REQUETE_EXPLOITATION_LIRE_UN = "requeteExploitationLireUn";//$NON-NLS-1$

  /**
   * The constant for templateRequeteExploitationLireUn service
   */
  private static final String METHODE_NAME_TEMPLATE_REQUETE_EXPLOITATION_LIRE_UN = "templateRequeteExploitationLireUn";//$NON-NLS-1$

  /**
   * The constant for decisionExploitationLireUn service
   */
  private static final String METHODE_NAME_DECISION_EXPLOITATION_LIRE_UN = "decisionExploitationLireUn";//$NON-NLS-1$

  /**
   * The constant for notificationReseauCreer service
   */
  private static final String METHOD_NAME_NOTIFICATION_RESEAU_CREER = "notificationReseauCreer"; //$NON-NLS-1$

  /**
   * The constant for notificationReseaLireUn service
   */
  private static final String METHOD_NAME_NOTIFICATION_RESEAU_LIRE_UN = "notificationReseauLireUn"; //$NON-NLS-1$

  /**
   * The constant for notificationReseauModifierStatut service
   */
  private static final String METHOD_NAME_NOTIFICATION_RESEAU_MODIFIER_STATUT = "notificationReseauModifierStatut"; //$NON-NLS-1$

  /**
   * The constant for cleRechercheNotificationReseau service
   */
  private static final String METHOD_NAME_CLE_RECHERCHE_NOTIFICATION_RESEAU = "cleRechercheNotificationReseau"; //$NON-NLS-1$
  /**
   * The constant for cleRechercheBlocageEquipementCreerListe service
   */
  private static final String METHOD_NAME_CLE_RECHERCHE_BLOCAGE_EQUIPEMENT_CREER_LISTE = "cleRechercheBlocageEquipementCreerListe"; //$NON-NLS-1$

  /**
   * The constant for operationVieReseauCreer service
   */
  private static final String METHOD_NAME_OPERATION_VIE_RESEAU_CREER = "operationVieReseauCreer"; //$NON-NLS-1$

  /**
   * The constant for operationVieReseauLireUn service
   */
  private static final String METHOD_NAME_OPERATION_VIE_RESEAU_LIRE_UN = "operationVieReseauLireUn"; //$NON-NLS-1$

  /**
   * The constant for operationVieReseauCompositeLireTousParCleRecherche service
   */
  private static final String METHOD_NAME_OPERATION_VIE_RESEAU_LIRE_TOUS_PAR_CLE_RECHERCHE = "operationVieReseauCompositeLireTousParCleRecherche"; //$NON-NLS-1$

  /**
   * The constant for operationVieReseauModifierStatut service
   */
  private static final String METHOD_NAME_OPERATION_VIE_RESEAU_MODIFIER_STATUT = "operationVieReseauModifierStatut"; //$NON-NLS-1$
  /**
   * The constant for operationVieReseauModifierListeClientImpacte service
   */
  private static final String METHOD_NAME_OPERATION_VIE_RESEAU_MODIFIER_LISTE_CLIENT_IMPACTE = "operationVieReseauModifierListeClientImpacte"; //$NON-NLS-1$

  /**
   * The constant for cleRechercheOperationVieReseau service
   */
  private static final String METHOD_NAME_CLE_RECHERCHE_OPERATION_VIE_RESEAU_CREER_LISTE = "cleRechercheOperationVieReseauCreerListe"; //$NON-NLS-1$

  /**
   * The constant for blocageEquipementCreer service
   */
  private static final String METHOD_NAME_BLOCAGE_EQUIPEMENT_CREER = "blocageEquipementCreer";//$NON-NLS-1$

  /**
   * The constant for blocageEquipementLireUn service
   */
  private static final String METHOD_NAME_BLOCAGE_EQUIPEMENT_LIRE_UN = "blocageEquipementLireUn"; //$NON-NLS-1$

  /**
   * The constant for blocageEquipementSupprimer service
   */
  private static final String METHOD_NAME_BLOCAGE_EQUIPEMENT_SUPPRIMER = "blocageEquipementSupprimer"; //$NON-NLS-1$
  /**
   * The constant for blocageEquipementModifier service
   */
  private static final String METHOD_NAME_BLOCAGE_EQUIPEMENT_MODIFIER = "blocageEquipementModifier"; //$NON-NLS-1$

  /**
   * The constant for ligneDeTestEligDslLireUn service
   */
  private static final String METHOD_NAME_LIGNE_DE_TEST_ELIG_DSL_LIRE_UN = "ligneDeTestEligDslLireUn"; //$NON-NLS-1$

  /**
   * The constant for ligneDeTestEligDslLireTous service
   */
  private static final String METHOD_NAME_LIGNE_DE_TEST_ELIG_DSL_LIRE_TOUS = "ligneDeTestEligDslLireTous"; //$NON-NLS-1$

  /**
   * The constant for ligneDeTestEligDslCreer service
   */
  private static final String METHOD_NAME_LIGNE_DE_TEST_ELIG_DSL_CREER = "ligneDeTestEligDslCreer"; //$NON-NLS-1$

  /**
   * The constant for ligneDeTestEligDslModifier service
   */
  private static final String METHOD_NAME_LIGNE_DE_TEST_ELIG_DSL_MODIFIER = "ligneDeTestEligDslModifier"; //$NON-NLS-1$

  /**
   * The constant for ligneDeTestEligDslSupprimer service
   */
  private static final String METHOD_NAME_LIGNE_DE_TEST_ELIG_DSL_SUPPRIMER = "ligneDeTestEligDslSupprimer"; //$NON-NLS-1$

  /**
   * The constant for idCmd param
   */
  private static final String PARAM_ID_CMD = "idCmd"; //$NON-NLS-1$

  /**
   * The constant for idReconciliation param
   */
  private static final String PARAM_ID_RECONCILIATION = "idReconciliation"; //$NON-NLS-1$

  /**
   * The constant for clientOperateur param
   */
  private static final String PARAM_CLIENT_OPERATEUR = "clientOperateur"; //$NON-NLS-1$

  /**
   * The constant for statut param
   */
  private static final String PARAM_STATUT = "statut"; //$NON-NLS-1$

  /**
   * The constant for idErreurSpirit param
   */
  private static final String PARAM_ID_ERREUR_SPIRIT = "idErreurSpirit"; //$NON-NLS-1$

  /**
   * The constant for dateDeb param
   */
  private static final String PARAM_DATE_DEB = "dateDeb"; //$NON-NLS-1$

  /**
   * The constant for dateFin param
   */
  private static final String PARAM_DATE_FIN = "dateFin"; //$NON-NLS-1$

  /**
   * The constant for noCompte param
   */
  private static final String PARAM_NO_COMPTE = "noCompte"; //$NON-NLS-1$

  /**
   * The constant for action param
   */
  private static final String PARAM_ACTION = "action"; //$NON-NLS-1$

  /**
   * The constant for idTraitementDeMasse param
   */
  private static final String PARAM_ID_TRAITEMENT_DE_MASSE = "idTraitementDeMasse"; //$NON-NLS-1$

  /**
   * The constant for nbTraitementsARealiser param
   */
  private static final String PARAM_NB_TRAITEMENTS_A_REALISER = "nbTraitementsARealiser"; //$NON-NLS-1$

  /**
   * The constant for idNotificationReseau param
   */
  private static final String PARAM_ID_NOTIFICATION_RESEAU = "idNotificationReseau"; //$NON-NLS-1$

  /**
   * The constant for AcquitterUn param
   */
  private static final String ACTION_ACQUITTER_UN = "AcquitterUn"; //$NON-NLS-1$

  /**
   * The constant for Ajouter param
   */
  private static final String ACTION_AJOUTER = "Ajouter"; //$NON-NLS-1$

  /**
   * The constant for type configuration param
   */
  private static final String TYPE_CONFIGURATION = "type_configuration"; //$NON-NLS-1$
  /**
   * The constant for nom param
   */
  private static final String NOM = "nom"; //$NON-NLS-1$

  /**
   * The constant form idOperationVieReseau
   */
  private static final String PARAM_ID_OPERATION_VIE_RESEAU = "idOperationVieReseau";//$NON-NLS-1$

  /**
   * The constant form typeOperationVieReseau
   */
  private static final String PARAM_TYPE_OPERATION_VIE_RESEAU = "typeOperationVieReseau";//$NON-NLS-1$

  /**
   * The constant form typeCle
   */
  private static final String PARAM_TYPE_CLE = "typeCle";//$NON-NLS-1$

  /**
   * The constant form valeurCle
   */
  private static final String PARAM_VALEUR_CLE = "valeurCle";//$NON-NLS-1$

  /**
   * The constant form idBlocageEquipement
   */
  private static final String PARAM_ID_BLOCAGE_EQUIPEMENT = "idBlocageEquipement";//$NON-NLS-1$

  /**
   * The constant form nd
   */
  private static final String PARAM_NUMERO_DE_DESIGNATION = "nd"; //$NON-NLS-1$

  /**
   * Path for PAD6001
   */
  private String _comparaisonCommercialeCompositeUrl;

  /**
   * Path for PAD6002
   */
  private String _reconciliationCommercialeUrl;

  /**
   * Path for PAD6003
   */
  private String _erreurSpiritUrl;

  /**
   * Path for PAD6004
   */
  private String _traitementDeMasseUrl;

  /**
   * Path for PAD6005
   */
  private String _reconciliationCommercialeEnMasseUrl;

  /**
   * Path for PAD6006 : Configuration PFS Composite
   */
  private String _configurationPfsCompositeUrl;

  /**
   * Path for PAD6007
   */
  private String _configurationProsperUrl;

  /**
   * Path for PAD6008
   */
  private String _notificationReseauUrl;

  /**
   * Path for PAD6010
   */
  private String _historisationEligibiliteUrl;

  /**
   * Ravel Json serializer
   */
  private IRavelJson _jsonBuilder = new RavelJson.RavelJsonBuilder().profil(SpiritConstants.JSON_PROFILE_STARK).build();

  /**
   * Path fot PAD6009
   */
  private String _cleRechercheNotificationReseauUrl;

  /**
   * Path fot PAD6010
   */
  private String _operationVieReseauUrl;
  /**
   * Path fot PAD6012
   */
  private String _cleRechercheOperationVieReseauUrl;

  /**
   * Path fot PAD6013
   */
  private String _blocageEquipementUrl;

  /**
   * Path fot PAD6014
   */
  private String _cleRechercheBlocageEquipementUrl;

  /**
   * Path for PAD6015
   */
  private String _ligneDeTestEligDSLUrl;

  /** ConfigurationPfsComposite service {@link ConfigurationPfsCompositeService} */
  private ConfigurationPfsCompositeService _configurationPfsCompositeService;

  @Override
  public ConnectorResponse<Retour, Nothing> blocageEquipementCreer(Tracabilite tracabilite_p, BlocageEquipement blocageEquipement_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_blocageEquipementUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD6013_PATH_PARAM));
      }
      // Call SAAB
      final Response response;
      try
      {
        RESTRequestBuilder restRequestBuilder = new RESTRequestBuilder();
        restRequestBuilder.httpMethod(HttpMethod.POST)//
            .serializer(_jsonBuilder)//
            .traceability(tracabilite_p)//
            .method(METHOD_NAME_BLOCAGE_EQUIPEMENT_CREER)//
            .headers(SPIRIT_STARK_REQUEST_HEADER)//
            .path(_blocageEquipementUrl)//
            .request(blocageEquipement_p);
        response = sendRequest(restRequestBuilder.build());
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get json from response as string
      String jsonResponse = getContent(response, METHOD_NAME_BLOCAGE_EQUIPEMENT_CREER, tracabilite_p);

      // Check response
      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }

      BasicResponse basicResponse = RavelJsonTools.getInstance().fromJson(jsonResponse, BasicResponse.class);
      // Retour OK
      return new ConnectorResponse<>(RetourConverter.convertFromJsonRetour(basicResponse.getRetour()), null);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, BlocageEquipement> blocageEquipementLireUn(Tracabilite tracabilite_p, String idBlocageEquipement_p) throws RavelException
  {

    try
    {
      if (StringTools.isNullOrEmpty(_blocageEquipementUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD6013_PATH_PARAM));
      }

      // Build query parameters
      HashMap<String, String> queryParams = new HashMap<>();

      if (StringTools.isNotNullOrEmpty(idBlocageEquipement_p))
      {
        queryParams.put(PARAM_ID_BLOCAGE_EQUIPEMENT, idBlocageEquipement_p);
      }
      // Call SAAB
      final Response response;
      try
      {
        RESTRequest restRequest = new RESTRequestBuilder()//
            .httpMethod(HttpMethod.GET)//
            .traceability(tracabilite_p)//
            .method(METHOD_NAME_BLOCAGE_EQUIPEMENT_LIRE_UN)//
            .headers(SPIRIT_STARK_REQUEST_HEADER)//
            .path(_blocageEquipementUrl)//
            .queryParameter(queryParams)//
            .build();
        response = sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get json from response as string
      String jsonResponse = getContent(response, METHOD_NAME_BLOCAGE_EQUIPEMENT_LIRE_UN, tracabilite_p);

      // Check response
      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }

      ListeBlocageEquipementResponse listeBlocageEquipementResponse = RavelJsonTools.getInstance().fromJson(jsonResponse, ListeBlocageEquipementResponse.class, SpiritConstants.JSON_PROFILE_STARK);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(listeBlocageEquipementResponse.getRetour());
      BlocageEquipement blocageEquipement = null;

      if (!CollectionUtils.isEmpty(listeBlocageEquipementResponse.getBlocageEquipementList()))
      {
        blocageEquipement = listeBlocageEquipementResponse.getBlocageEquipementList().get(0);
      }

      return new ConnectorResponse<>(retour, blocageEquipement);

    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, Nothing> blocageEquipementModifier(Tracabilite tracabilite_p, UpdateBlocageEquipementRequest updateBlocageEquipementRequest_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_blocageEquipementUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD6013_PATH_PARAM));
      }
      // Call SAAB
      final Response response;
      try
      {
        RESTRequestBuilder restRequestBuilder = new RESTRequestBuilder();
        restRequestBuilder.httpMethod(HttpMethod.PUT)//
            .serializer(_jsonBuilder)//
            .traceability(tracabilite_p)//
            .method(METHOD_NAME_BLOCAGE_EQUIPEMENT_MODIFIER)//
            .headers(SPIRIT_STARK_REQUEST_HEADER)//
            .path(_blocageEquipementUrl)//
            .request(updateBlocageEquipementRequest_p);
        response = sendRequest(restRequestBuilder.build());
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get json from response as string
      String jsonResponse = getContent(response, METHOD_NAME_BLOCAGE_EQUIPEMENT_MODIFIER, tracabilite_p);

      // Check response
      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }

      BasicResponse basicResponse = RavelJsonTools.getInstance().fromJson(jsonResponse, BasicResponse.class);
      // Retour OK
      return new ConnectorResponse<>(RetourConverter.convertFromJsonRetour(basicResponse.getRetour()), null);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, Nothing> blocageEquipementSupprimer(Tracabilite tracabilite_p, String idBlocageEquipement_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_blocageEquipementUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD6013_PATH_PARAM));
      }

      // Build query parameters
      HashMap<String, String> queryParams = new HashMap<>();

      if (StringTools.isNotNullOrEmpty(idBlocageEquipement_p))
      {
        queryParams.put(PARAM_ID_BLOCAGE_EQUIPEMENT, idBlocageEquipement_p);
      }
      // Call SAAB
      final Response response;
      try
      {
        RESTRequest restRequest = new RESTRequestBuilder()//
            .httpMethod(HttpMethod.DELETE)//
            .traceability(tracabilite_p)//
            .method(METHOD_NAME_BLOCAGE_EQUIPEMENT_SUPPRIMER)//
            .headers(SPIRIT_STARK_REQUEST_HEADER)//
            .path(_blocageEquipementUrl)//
            .queryParameter(queryParams)//
            .build();
        response = sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get json from response as string
      String jsonResponse = getContent(response, METHOD_NAME_BLOCAGE_EQUIPEMENT_SUPPRIMER, tracabilite_p);

      // Check response
      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }

      BasicResponse basicResponse = RavelJsonTools.getInstance().fromJson(jsonResponse, BasicResponse.class);
      // Retour OK
      return new ConnectorResponse<>(RetourConverter.convertFromJsonRetour(basicResponse.getRetour()), null);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, Nothing> cleRechercheBlocageEquipementCreerListe(Tracabilite tracabilite_p, ListeCleRechercheBlocageEquipementRequest listeCleRechercheBlocageEquipementRequest_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_cleRechercheBlocageEquipementUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD6014_PATH_PARAM));
      }

      // Call SAAB
      final Response response;
      try
      {
        RESTRequest restRequest = new RESTRequestBuilder()//
            .serializer(_jsonBuilder)//
            .httpMethod(HttpMethod.POST)//
            .traceability(tracabilite_p)//
            .method(METHOD_NAME_CLE_RECHERCHE_BLOCAGE_EQUIPEMENT_CREER_LISTE)//
            .headers(SPIRIT_STARK_REQUEST_HEADER)//
            .path(_cleRechercheBlocageEquipementUrl)//
            .queryParameter(null)//
            .request(listeCleRechercheBlocageEquipementRequest_p)//
            .build();
        response = sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get json from response as string
      String jsonResponse = getContent(response, METHOD_NAME_CLE_RECHERCHE_BLOCAGE_EQUIPEMENT_CREER_LISTE, tracabilite_p);

      // Check response
      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }

      BasicResponse basicResponse = RavelJsonTools.getInstance().fromJson(jsonResponse, BasicResponse.class);
      // Retour OK
      return new ConnectorResponse<>(RetourConverter.convertFromJsonRetour(basicResponse.getRetour()), null);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, Nothing> cleRechercheNotificationReseau(Tracabilite tracabilite_p, ListeCleRechercheNotificationReseauRequest listeCleRechercheNotificationReseauRequest_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_cleRechercheNotificationReseauUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD6009_PATH_PARAM));
      }

      // Call SAAB
      final Response response;
      try
      {
        RESTRequest restRequest = new RESTRequestBuilder()//
            .serializer(_jsonBuilder)//
            .httpMethod(HttpMethod.POST)//
            .traceability(tracabilite_p)//
            .method(METHOD_NAME_CLE_RECHERCHE_NOTIFICATION_RESEAU)//
            .headers(SPIRIT_STARK_REQUEST_HEADER)//
            .path(_cleRechercheNotificationReseauUrl)//
            .queryParameter(null)//
            .request(listeCleRechercheNotificationReseauRequest_p)//
            .build();
        response = sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get json from response as string
      String jsonResponse = getContent(response, METHOD_NAME_CLE_RECHERCHE_NOTIFICATION_RESEAU, tracabilite_p);

      // Check response
      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }

      BasicResponse basicResponse = RavelJsonTools.getInstance().fromJson(jsonResponse, BasicResponse.class);
      // Retour OK
      return new ConnectorResponse<>(RetourConverter.convertFromJsonRetour(basicResponse.getRetour()), null);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, Nothing> cleRechercheOperationVieReseauCreerListe(Tracabilite tracabilite_p, ListeCleRechercheOperationVieReseauRequest listeCleRechercheOperationVieReseauRequest_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_cleRechercheOperationVieReseauUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD6012_PATH_PARAM));
      }

      // Call SAAB
      final Response response;
      try
      {
        RESTRequest restRequest = new RESTRequestBuilder()//
            .serializer(_jsonBuilder)//
            .httpMethod(HttpMethod.POST)//
            .traceability(tracabilite_p)//
            .method(METHOD_NAME_CLE_RECHERCHE_OPERATION_VIE_RESEAU_CREER_LISTE)//
            .headers(SPIRIT_STARK_REQUEST_HEADER)//
            .path(_cleRechercheOperationVieReseauUrl)//
            .queryParameter(null)//
            .request(listeCleRechercheOperationVieReseauRequest_p)//
            .build();
        response = sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get json from response as string
      String jsonResponse = getContent(response, METHOD_NAME_CLE_RECHERCHE_OPERATION_VIE_RESEAU_CREER_LISTE, tracabilite_p);

      // Check response
      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }

      BasicResponse basicResponse = RavelJsonTools.getInstance().fromJson(jsonResponse, BasicResponse.class);
      // Retour OK
      return new ConnectorResponse<>(RetourConverter.convertFromJsonRetour(basicResponse.getRetour()), null);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, Nothing> comparaisonCommercialeCompositeCreer(Tracabilite tracabilite_p, CreateComparaisonCommercialeCompositeRequest comparaisonCommerciale_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_comparaisonCommercialeCompositeUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD6001_PATH_PARAM));
      }

      // Call SAAB
      final Response response;
      try
      {
        RESTRequestBuilder restRequestBuilder = new RESTRequestBuilder();
        restRequestBuilder.httpMethod(HttpMethod.POST).traceability(tracabilite_p).method(METHOD_NAME_COMPARAISON_COMMERCIALE_COMPOSITE_CREER).headers(SPIRIT_STARK_REQUEST_HEADER).path(_comparaisonCommercialeCompositeUrl).request(comparaisonCommerciale_p);
        response = sendRequest(restRequestBuilder.build());
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content to a JSON string
      String jsonResponse = getContent(response, METHOD_NAME_COMPARAISON_COMMERCIALE_COMPOSITE_CREER, tracabilite_p);

      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }

      BasicResponse basicResponse = GsonTools.getIso8601Ms().fromJson(jsonResponse, BasicResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(basicResponse.getRetour());

      return new ConnectorResponse<>(retour, null);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, List<ComparaisonCommerciale>> comparaisonCommercialeCompositeLireTousParIdCmd(Tracabilite tracabilite_p, String idCmd_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_comparaisonCommercialeCompositeUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD6001_PATH_PARAM));
      }

      // Build query parameters
      HashMap<String, String> queryParams = new HashMap<>();
      try
      {
        if (StringTools.isNotNullOrEmpty(idCmd_p))
        {
          queryParams.put(PARAM_ID_CMD, URLEncoder.encode(idCmd_p, "UTF-8")); //$NON-NLS-1$
        }
      }
      catch (Exception ex)
      {
        throw new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.KO_00000, "URLEncodingException for id " + idCmd_p); //$NON-NLS-1$
      }

      // Call SAAB
      final Response response;
      try
      {
        RESTRequestBuilder restRequestBuilder = new RESTRequestBuilder();
        restRequestBuilder.httpMethod(HttpMethod.GET).traceability(tracabilite_p).method(METHOD_NAME_COMPARAISON_COMMERCIALE_COMPOSITE_LIRE_DERNIER_PAR_ID_CMD).headers(SPIRIT_STARK_REQUEST_HEADER).path(_comparaisonCommercialeCompositeUrl).queryParameter(queryParams);
        response = sendRequest(restRequestBuilder.build());
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content to a JSON string
      String jsonResponse = getContent(response, METHOD_NAME_COMPARAISON_COMMERCIALE_COMPOSITE_LIRE_DERNIER_PAR_ID_CMD, tracabilite_p);

      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }

      GetComparaisonCommercialeCompositeResponse getComparaisonCommercialeCompositeResponse = GsonTools.getIso8601Ms().fromJson(jsonResponse, GetComparaisonCommercialeCompositeResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(getComparaisonCommercialeCompositeResponse.getRetour());
      List<ComparaisonCommerciale> listeComparaisonCommercialeComposite = getComparaisonCommercialeCompositeResponse.getListComparaisonCommercialeComposite();

      return new ConnectorResponse<>(retour, listeComparaisonCommercialeComposite);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, Nothing> configurationPfsCompositeGererEcrireConfigurationPfs(Tracabilite tracabilite_p, String xOauth2Login_p, ConfigurationPfs configurationPfs_p) throws RavelException
  {
    return _configurationPfsCompositeService.configurationPfsCompositeGererEcrireConfigurationPfs(tracabilite_p, _configurationPfsCompositeUrl, xOauth2Login_p, configurationPfs_p);
  }

  @Override
  public ConnectorResponse<Retour, Nothing> configurationPfsCompositeGererEcrirePfs(Tracabilite tracabilite_p, String xOauth2Login_p, ConfigurationPfsComposite configurationPfsComposite_p) throws RavelException
  {
    return _configurationPfsCompositeService.configurationPfsCompositeGererEcrirePfs(tracabilite_p, _configurationPfsCompositeUrl, xOauth2Login_p, configurationPfsComposite_p);
  }

  @Override
  public ConnectorResponse<Retour, Nothing> configurationPfsCompositeGererSuppressionConfigurationPfs(Tracabilite tracabilite_p, String xOauth2Login_p, ConfigurationPfs configurationPfs_p) throws RavelException
  {
    return _configurationPfsCompositeService.configurationPfsCompositeGererSuppressionConfigurationPfs(tracabilite_p, _configurationPfsCompositeUrl, xOauth2Login_p, configurationPfs_p);
  }

  @Override
  public ConnectorResponse<Retour, Nothing> configurationPfsCompositeGererSuppressionPfs(Tracabilite tracabilite_p, String xOauth2Login_p, ConfigurationPfsComposite configurationPfsComposite_p) throws RavelException
  {
    return _configurationPfsCompositeService.configurationPfsCompositeGererSuppressionPfs(tracabilite_p, _configurationPfsCompositeUrl, xOauth2Login_p, configurationPfsComposite_p);
  }

  @Override
  public ConnectorResponse<Retour, List<ConfigurationPfsComposite>> configurationPfsCompositeLireTous(Tracabilite tracabilite_p) throws RavelException
  {
    return _configurationPfsCompositeService.configurationPfsCompositeLireTous(tracabilite_p, _configurationPfsCompositeUrl);
  }

  @Override
  public ConnectorResponse<Retour, DecisionExploitation> decisionExploitationLireUn(Tracabilite tracabilite_p, String nom_p)
  {
    ConnectorResponse<Retour, ListeDecisionExploitationResponse> response = configurationProsper(tracabilite_p, TypeConfiguration.DecisionExploitation, nom_p, ListeDecisionExploitationResponse.class, METHODE_NAME_DECISION_EXPLOITATION_LIRE_UN);
    if (RetourFactory.isRetourOK(response._first))
    {
      return new ConnectorResponse<>(RetourFactory.createOkRetour(), response._second.getListeDecisionExploitation().get(0));
    }
    else
    {
      return new ConnectorResponse<>(response._first, null);
    }
  }

  @Override
  public ConnectorResponse<Retour, Nothing> erreurSpiritCreer(Tracabilite tracabilite_p, CreateErreurSpiritRequest erreurSpirit_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_erreurSpiritUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD6003_PATH_PARAM));
      }

      // Call SAAB
      final Response response;
      try
      {
        RESTRequestBuilder restRequestBuilder = new RESTRequestBuilder();
        restRequestBuilder.httpMethod(HttpMethod.POST).traceability(tracabilite_p).method(METHOD_NAME_ERREUR_SPIRIT_CREER).headers(SPIRIT_STARK_REQUEST_HEADER).path(_erreurSpiritUrl).request(erreurSpirit_p);
        response = sendRequest(restRequestBuilder.build());
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content to a JSON string
      String jsonResponse = getContent(response, METHOD_NAME_ERREUR_SPIRIT_CREER, tracabilite_p);

      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }

      BasicResponse basicResponse = GsonTools.getIso8601Ms().fromJson(jsonResponse, BasicResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(basicResponse.getRetour());

      return new ConnectorResponse<>(retour, null);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, List<ErreurSpirit>> erreurSpiritLireTousParStatutPeriod(Tracabilite tracabilite_p, String statut_p, String dateDeb_p, String dateFin_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_erreurSpiritUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD6003_PATH_PARAM));
      }

      // Build query parameters
      HashMap<String, String> queryParams = new HashMap<>();

      if (StringTools.isNotNullOrEmpty(statut_p) && StringTools.isNotNullOrEmpty(dateDeb_p) && StringTools.isNotNullOrEmpty(dateFin_p))
      {
        queryParams.put(PARAM_STATUT, statut_p);
        queryParams.put(PARAM_DATE_DEB, dateDeb_p);
        queryParams.put(PARAM_DATE_FIN, dateFin_p);
      }

      // Call SAAB
      final Response response;
      try
      {
        RESTRequestBuilder restRequestBuilder = new RESTRequestBuilder();
        restRequestBuilder.httpMethod(HttpMethod.GET).traceability(tracabilite_p).method(METHOD_NAME_ERREUR_SPIRIT_LIRE_TOUS_PAR_STATUT_PERIOD).headers(SPIRIT_STARK_REQUEST_HEADER).path(_erreurSpiritUrl).queryParameter(queryParams);
        response = sendRequest(restRequestBuilder.build());
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content to a JSON string
      String jsonResponse = getContent(response, METHOD_NAME_ERREUR_SPIRIT_LIRE_TOUS_PAR_STATUT_PERIOD, tracabilite_p);

      // Verify response
      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }

      GetErreurSpiritResponse getErreurSpiritResponse = GsonTools.getIso8601Ms().fromJson(jsonResponse, GetErreurSpiritResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(getErreurSpiritResponse.getRetour());
      List<ErreurSpirit> erreurSpiritList = getErreurSpiritResponse.getListeErreurSpirit();

      return new ConnectorResponse<>(retour, erreurSpiritList);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, List<ErreurSpirit>> erreurSpiritLireTousSurPeriod(Tracabilite tracabilite_p, String dateDeb_p, String dateFin_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_erreurSpiritUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD6003_PATH_PARAM));
      }

      // Build query parameters
      HashMap<String, String> queryParams = new HashMap<>();

      if (StringTools.isNotNullOrEmpty(dateDeb_p) && StringTools.isNotNullOrEmpty(dateFin_p))
      {
        queryParams.put(PARAM_DATE_DEB, dateDeb_p);
        queryParams.put(PARAM_DATE_FIN, dateFin_p);
      }

      // Call SAAB
      final Response response;
      try
      {
        RESTRequestBuilder restRequestBuilder = new RESTRequestBuilder();
        restRequestBuilder.httpMethod(HttpMethod.GET).traceability(tracabilite_p).method(METHOD_NAME_ERREUR_SPIRIT_LIRE_TOUS_SUR_PERIOD).headers(SPIRIT_STARK_REQUEST_HEADER).path(_erreurSpiritUrl).queryParameter(queryParams);
        response = sendRequest(restRequestBuilder.build());
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content to a JSON string
      String jsonResponse = getContent(response, METHOD_NAME_ERREUR_SPIRIT_LIRE_TOUS_SUR_PERIOD, tracabilite_p);

      // Verify response
      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }

      GetErreurSpiritResponse getErreurSpiritResponse = GsonTools.getIso8601Ms().fromJson(jsonResponse, GetErreurSpiritResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(getErreurSpiritResponse.getRetour());
      List<ErreurSpirit> erreurSpiritList = getErreurSpiritResponse.getListeErreurSpirit();

      return new ConnectorResponse<>(retour, erreurSpiritList);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, List<ErreurSpirit>> erreurSpiritLireUn(Tracabilite tracabilite_p, String idErreurSpirit_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_erreurSpiritUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD6003_PATH_PARAM));
      }

      // Build query parameters
      HashMap<String, String> queryParams = new HashMap<>();

      if (StringTools.isNotNullOrEmpty(idErreurSpirit_p))
      {
        queryParams.put(PARAM_ID_ERREUR_SPIRIT, idErreurSpirit_p);
      }

      // Call SAAB
      final Response response;
      try
      {
        RESTRequestBuilder restRequestBuilder = new RESTRequestBuilder();
        restRequestBuilder.httpMethod(HttpMethod.GET).traceability(tracabilite_p).method(METHOD_NAME_ERREUR_SPIRIT_LIRE_UN).headers(SPIRIT_STARK_REQUEST_HEADER).path(_erreurSpiritUrl).queryParameter(queryParams);
        response = sendRequest(restRequestBuilder.build());
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content to a JSON string
      String jsonResponse = getContent(response, METHOD_NAME_ERREUR_SPIRIT_LIRE_UN, tracabilite_p);

      // Verify response
      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }

      GetErreurSpiritResponse getErreurSpiritResponse = GsonTools.getIso8601Ms().fromJson(jsonResponse, GetErreurSpiritResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(getErreurSpiritResponse.getRetour());
      List<ErreurSpirit> erreurSpiritList = getErreurSpiritResponse.getListeErreurSpirit();

      return new ConnectorResponse<>(retour, erreurSpiritList);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, Nothing> erreurSpiritModifierStatut(Tracabilite tracabilite_p, UpdateErreurSpiritRequest updateErreurSpirit_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_erreurSpiritUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD6003_PATH_PARAM));
      }

      // Call SAAB
      final Response response;
      try
      {
        RESTRequestBuilder restRequestBuilder = new RESTRequestBuilder();
        restRequestBuilder.httpMethod(HttpMethod.PUT).traceability(tracabilite_p).method(METHOD_NAME_ERREUR_SPIRIT_MODIFIER_STATUT).headers(SPIRIT_STARK_REQUEST_HEADER).path(_erreurSpiritUrl).request(updateErreurSpirit_p);
        response = sendRequest(restRequestBuilder.build());
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get json from response as string
      String jsonResponse = getContent(response, METHOD_NAME_ERREUR_SPIRIT_MODIFIER_STATUT, tracabilite_p);

      // Check response
      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }

      BasicResponse basicResponse = GsonTools.getIso8601Ms().fromJson(jsonResponse, BasicResponse.class);

      // Retour OK
      return new ConnectorResponse<>(RetourConverter.convertFromJsonRetour(basicResponse.getRetour()), null);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public String getConfigParameter(String arg0_p, String arg1_p) throws RavelException
  {
    return null;
  }

  /**
   * Generic method to get the response objet from the REST response
   */
  public <T> T getContentFromResponse(Tracabilite tracabilite_p, Response response_p, String callerMethod_p, Class<T> clazz_p) throws RavelException
  {
    // Get the content to a JSON string
    String jsonResponse = super.getContent(response_p, callerMethod_p, tracabilite_p);

    if (StringTools.isNullOrEmpty(jsonResponse))
    {
      throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
    }

    return RavelJsonTools.getInstance().fromJson(jsonResponse, clazz_p);
  }

  @Override
  public ConnectorResponse<Retour, Nothing> historisationEligibiliteCreer(Tracabilite tracabilite_p, HistorisationEligibilite historisationEligibilite_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_historisationEligibiliteUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD6010_PATH_PARAM));
      }

      // Call SAAB
      final Response response;
      try
      {
        RESTRequest restRequest = new RESTRequestBuilder().serializer(_jsonBuilder) //
            .httpMethod(HttpMethod.POST) //
            .traceability(tracabilite_p) //
            .method(METHOD_NAME_HISTORISATION_ELIGIBILITE_CREER) //
            .headers(SPIRIT_STARK_REQUEST_HEADER) //
            .path(_historisationEligibiliteUrl) //
            .queryParameter(null) //
            .request(historisationEligibilite_p) //
            .build();

        response = sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get json from response as string
      String jsonResponse = getContent(response, METHOD_NAME_HISTORISATION_ELIGIBILITE_CREER, tracabilite_p);

      // Check response
      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }

      BasicResponse basicResponse = RavelJsonTools.getInstance().fromJson(jsonResponse, BasicResponse.class);

      // Retour OK
      return new ConnectorResponse<>(RetourConverter.convertFromJsonRetour(basicResponse.getRetour()), null);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public void loadConnectorConfiguration(Connector connector_p) throws RavelException
  {
    super.loadConnectorConfiguration(connector_p);

    // Get and validate specific configuration parameters
    for (Param param : connector_p.getParam())
    {
      switch (param.getName())
      {
        case PAD6001_PATH_PARAM:
          _comparaisonCommercialeCompositeUrl = param.getValue();
          break;
        case PAD6002_PATH_PARAM:
          _reconciliationCommercialeUrl = param.getValue();
          break;
        case PAD6003_PATH_PARAM:
          _erreurSpiritUrl = param.getValue();
          break;
        case PAD6004_PATH_PARAM:
          _traitementDeMasseUrl = param.getValue();
          break;
        case PAD6005_PATH_PARAM:
          _reconciliationCommercialeEnMasseUrl = param.getValue();
          break;
        case PAD6006_PATH_PARAM:
          _configurationPfsCompositeUrl = param.getValue();
          break;
        case PAD6007_PATH_PARAM:
          _configurationProsperUrl = param.getValue();
          break;
        case PAD6008_PATH_PARAM:
          _notificationReseauUrl = param.getValue();
          break;
        case PAD6009_PATH_PARAM:
          _cleRechercheNotificationReseauUrl = param.getValue();
          break;
        case PAD6010_PATH_PARAM:
          _historisationEligibiliteUrl = param.getValue();
          break;
        case PAD6011_PATH_PARAM:
          _operationVieReseauUrl = param.getValue();
          break;
        case PAD6012_PATH_PARAM:
          _cleRechercheOperationVieReseauUrl = param.getValue();
          break;
        case PAD6013_PATH_PARAM:
          _blocageEquipementUrl = param.getValue();
          break;
        case PAD6014_PATH_PARAM:
          _cleRechercheBlocageEquipementUrl = param.getValue();
          break;
        case PAD6015_PATH_PARAM:
          _ligneDeTestEligDSLUrl = param.getValue();
          break;
        default:
          break;
      }
    }

    // Load Services
    _configurationPfsCompositeService = new ConfigurationPfsCompositeService(this);
  }

  @Override
  public ConnectorResponse<Retour, Nothing> notificationReseauCreer(Tracabilite tracabilite_p, AbstractNotificationReseau notificationReseau_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_notificationReseauUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD6008_PATH_PARAM));
      }

      // Call SAAB
      final Response response;
      try
      {
        RESTRequest restRequest = new RESTRequestBuilder()//
            .serializer(_jsonBuilder)//
            .httpMethod(HttpMethod.POST)//
            .traceability(tracabilite_p)//
            .method(METHOD_NAME_NOTIFICATION_RESEAU_CREER)//
            .headers(SPIRIT_STARK_REQUEST_HEADER)//
            .path(_notificationReseauUrl)//
            .queryParameter(null)//
            .request(notificationReseau_p)//
            .build();
        response = sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get json from response as string
      String jsonResponse = getContent(response, METHOD_NAME_NOTIFICATION_RESEAU_CREER, tracabilite_p);

      // Check response
      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }

      BasicResponse basicResponse = RavelJsonTools.getInstance().fromJson(jsonResponse, BasicResponse.class);

      // Retour OK
      return new ConnectorResponse<>(RetourConverter.convertFromJsonRetour(basicResponse.getRetour()), null);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, AbstractNotificationReseau> notificationReseauLireUn(Tracabilite tracabilite_p, String idNotificationReseau_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_notificationReseauUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD6008_PATH_PARAM));
      }

      // Build query parameters
      HashMap<String, String> queryParams = new HashMap<>();

      if (StringTools.isNotNullOrEmpty(idNotificationReseau_p))
      {
        queryParams.put(PARAM_ID_NOTIFICATION_RESEAU, idNotificationReseau_p);
      }

      // Call GET
      final Response response;
      try
      {
        RESTRequest restRequest = new RESTRequestBuilder()//
            .httpMethod(HttpMethod.GET)//
            .traceability(tracabilite_p)//
            .method(METHOD_NAME_NOTIFICATION_RESEAU_LIRE_UN)//
            .headers(SPIRIT_STARK_REQUEST_HEADER)//
            .path(_notificationReseauUrl)//
            .queryParameter(queryParams)//
            .build();
        response = sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content to a JSON string
      String jsonResponse = getContent(response, METHOD_NAME_NOTIFICATION_RESEAU_LIRE_UN, tracabilite_p);

      // Verify response
      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }

      GetNotificationReseauResponseSpirit getNotificationReseauResponse = RavelJsonTools.getInstance().fromJson(jsonResponse, GetNotificationReseauResponseSpirit.class, SpiritConstants.JSON_PROFILE_STARK);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(getNotificationReseauResponse.getRetour());
      AbstractNotificationReseau notificationReseau = null;

      if (!CollectionUtils.isEmpty(getNotificationReseauResponse.getListeNotificationReseau()))
      {
        notificationReseau = getNotificationReseauResponse.getListeNotificationReseau().get(0);
      }

      return new ConnectorResponse<>(retour, notificationReseau);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, Nothing> notificationReseauModifierStatut(Tracabilite tracabilite_p, UpdateNotificationReseauStatutRequest updateNotificationReseauStatutRequest_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_notificationReseauUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD6008_PATH_PARAM));
      }

      // Call PUT
      final Response response;
      try
      {
        RESTRequest restRequest = new RESTRequestBuilder()//
            .serializer(_jsonBuilder)//
            .httpMethod(HttpMethod.PUT)//
            .traceability(tracabilite_p)//
            .method(METHOD_NAME_NOTIFICATION_RESEAU_MODIFIER_STATUT)//
            .headers(SPIRIT_STARK_REQUEST_HEADER)//
            .path(_notificationReseauUrl)//
            .request(updateNotificationReseauStatutRequest_p)//
            .build();
        response = sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get json from response as string
      String jsonResponse = getContent(response, METHOD_NAME_NOTIFICATION_RESEAU_MODIFIER_STATUT, tracabilite_p);

      // Check response
      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }

      BasicResponse basicResponse = RavelJsonTools.getInstance().fromJson(jsonResponse, BasicResponse.class);

      // Retour OK
      return new ConnectorResponse<>(RetourConverter.convertFromJsonRetour(basicResponse.getRetour()), null);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, List<OperationVieReseau>> operationVieReseauCompositeLireTousParCleRecherche(Tracabilite tracabilite_p, String typeOperationVieReseau_p, String typeCle_p, String valeurCle_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_operationVieReseauUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD6011_PATH_PARAM));
      }
      // Build query parameters
      HashMap<String, String> queryParams = new HashMap<>();

      if (StringTools.isNotNullOrEmpty(typeOperationVieReseau_p) && StringTools.isNotNullOrEmpty(typeCle_p) && StringTools.isNotNullOrEmpty(valeurCle_p))
      {
        queryParams.put(PARAM_TYPE_OPERATION_VIE_RESEAU, typeOperationVieReseau_p);
        queryParams.put(PARAM_TYPE_CLE, typeCle_p);
        queryParams.put(PARAM_VALEUR_CLE, valeurCle_p);
      }
      // Call SAAB
      final Response response;
      try
      {
        RESTRequest restRequest = new RESTRequestBuilder()//
            .httpMethod(HttpMethod.GET)//
            .traceability(tracabilite_p)//
            .method(METHOD_NAME_OPERATION_VIE_RESEAU_LIRE_TOUS_PAR_CLE_RECHERCHE)//
            .headers(SPIRIT_STARK_REQUEST_HEADER)//
            .path(_operationVieReseauUrl)//
            .queryParameter(queryParams)//
            .build();
        response = sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get json from response as string
      String jsonResponse = getContent(response, METHOD_NAME_OPERATION_VIE_RESEAU_LIRE_TOUS_PAR_CLE_RECHERCHE, tracabilite_p);

      // Check response
      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }

      ListeOperationVieReseauResponse listeOperationVieReseauResponse = RavelJsonTools.getInstance().fromJson(jsonResponse, ListeOperationVieReseauResponse.class, SpiritConstants.JSON_PROFILE_STARK);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(listeOperationVieReseauResponse.getRetour());

      return new ConnectorResponse<>(retour, listeOperationVieReseauResponse.getOperationVieReseauList());

    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, Nothing> operationVieReseauCreer(Tracabilite tracabilite_p, OperationVieReseau operationVieReseau_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_operationVieReseauUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD6011_PATH_PARAM));
      }

      // Call SAAB
      final Response response;
      try
      {
        RESTRequestBuilder restRequestBuilder = new RESTRequestBuilder();
        restRequestBuilder.httpMethod(HttpMethod.POST)//
            .serializer(_jsonBuilder)//
            .traceability(tracabilite_p)//
            .method(METHOD_NAME_OPERATION_VIE_RESEAU_CREER)//
            .headers(SPIRIT_STARK_REQUEST_HEADER)//
            .path(_operationVieReseauUrl)//
            .request(operationVieReseau_p);
        response = sendRequest(restRequestBuilder.build());
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get json from response as string
      String jsonResponse = getContent(response, METHOD_NAME_OPERATION_VIE_RESEAU_CREER, tracabilite_p);

      // Check response
      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }

      BasicResponse basicResponse = RavelJsonTools.getInstance().fromJson(jsonResponse, BasicResponse.class);
      // Retour OK
      return new ConnectorResponse<>(RetourConverter.convertFromJsonRetour(basicResponse.getRetour()), null);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, OperationVieReseau> operationVieReseauLireUn(Tracabilite tracabilite_p, String idOperationVieReseau_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_operationVieReseauUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD6011_PATH_PARAM));
      }

      // Build query parameters
      HashMap<String, String> queryParams = new HashMap<>();

      if (StringTools.isNotNullOrEmpty(idOperationVieReseau_p))
      {
        queryParams.put(PARAM_ID_OPERATION_VIE_RESEAU, idOperationVieReseau_p);
      }
      // Call SAAB
      final Response response;
      try
      {
        RESTRequest restRequest = new RESTRequestBuilder()//
            .httpMethod(HttpMethod.GET)//
            .traceability(tracabilite_p)//
            .method(METHOD_NAME_OPERATION_VIE_RESEAU_LIRE_UN)//
            .headers(SPIRIT_STARK_REQUEST_HEADER)//
            .path(_operationVieReseauUrl)//
            .queryParameter(queryParams)//
            .build();
        response = sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get json from response as string
      String jsonResponse = getContent(response, METHOD_NAME_OPERATION_VIE_RESEAU_LIRE_UN, tracabilite_p);

      // Check response
      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }

      ListeOperationVieReseauResponse listeOperationVieReseauResponse = RavelJsonTools.getInstance().fromJson(jsonResponse, ListeOperationVieReseauResponse.class, SpiritConstants.JSON_PROFILE_STARK);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(listeOperationVieReseauResponse.getRetour());
      OperationVieReseau operationVieReseau = null;

      if (!CollectionUtils.isEmpty(listeOperationVieReseauResponse.getOperationVieReseauList()))
      {
        operationVieReseau = listeOperationVieReseauResponse.getOperationVieReseauList().get(0);
      }

      return new ConnectorResponse<>(retour, operationVieReseau);

    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, Nothing> operationVieReseauModifierListeClientImpacte(Tracabilite tracabilite_p, String idOperationVieReseau_p, Set<ClientImpacte> clientImpactes_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_operationVieReseauUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD6011_PATH_PARAM));
      }
      OperationVieReseauModifierListeClientImpacteRequest operationVieReseauModifierListeClientImpacteRequest = new OperationVieReseauModifierListeClientImpacteRequest();
      operationVieReseauModifierListeClientImpacteRequest.setIdOperationVieReseau(idOperationVieReseau_p);
      operationVieReseauModifierListeClientImpacteRequest.setClientImpactes(clientImpactes_p);
      // Call SAAB
      final Response response;
      try
      {
        RESTRequest restRequest = new RESTRequestBuilder()//
            .httpMethod(HttpMethod.PUT)//
            .traceability(tracabilite_p)//
            .method(METHOD_NAME_OPERATION_VIE_RESEAU_MODIFIER_LISTE_CLIENT_IMPACTE)//
            .headers(SPIRIT_STARK_REQUEST_HEADER)//
            .path(_operationVieReseauUrl)//
            .request(operationVieReseauModifierListeClientImpacteRequest)//
            .serializer(_jsonBuilder)//
            .build();
        response = sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get json from response as string
      String jsonResponse = getContent(response, METHOD_NAME_OPERATION_VIE_RESEAU_MODIFIER_LISTE_CLIENT_IMPACTE, tracabilite_p);

      // Check response
      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }

      BasicResponse basicResponse = RavelJsonTools.getInstance().fromJson(jsonResponse, BasicResponse.class);

      // Retour OK
      return new ConnectorResponse<>(RetourConverter.convertFromJsonRetour(basicResponse.getRetour()), null);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, Nothing> operationVieReseauModifierStatut(Tracabilite tracabilite_p, String idOperationVieReseau_p, String statut_p, String codeErreur_p, String libelleErreur_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_operationVieReseauUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD6011_PATH_PARAM));
      }
      OperationVieReseauModifierStatutRequest operationVieReseauModifierStatutRequest = new OperationVieReseauModifierStatutRequest();
      operationVieReseauModifierStatutRequest.setIdOperationVieReseau(idOperationVieReseau_p);
      operationVieReseauModifierStatutRequest.setStatut(statut_p);
      operationVieReseauModifierStatutRequest.setCodeErreur(codeErreur_p);
      operationVieReseauModifierStatutRequest.setLibelleErreur(libelleErreur_p);
      // Call SAAB
      final Response response;
      try
      {
        RESTRequest restRequest = new RESTRequestBuilder()//
            .httpMethod(HttpMethod.PUT)//
            .traceability(tracabilite_p)//
            .method(METHOD_NAME_OPERATION_VIE_RESEAU_MODIFIER_STATUT)//
            .headers(SPIRIT_STARK_REQUEST_HEADER)//
            .path(_operationVieReseauUrl)//
            .serializer(_jsonBuilder)//
            .request(operationVieReseauModifierStatutRequest)//
            .serializer(_jsonBuilder)//
            .build();
        response = sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get json from response as string
      String jsonResponse = getContent(response, METHOD_NAME_OPERATION_VIE_RESEAU_MODIFIER_STATUT, tracabilite_p);

      // Check response
      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }

      BasicResponse basicResponse = RavelJsonTools.getInstance().fromJson(jsonResponse, BasicResponse.class);

      // Retour OK
      return new ConnectorResponse<>(RetourConverter.convertFromJsonRetour(basicResponse.getRetour()), null);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, Nothing> reconciliationCommercialeCreer(Tracabilite tracabilite_p, CreateOrUpdateReconciliationCommercialeRequest reconciliationCommerciale_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_reconciliationCommercialeUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD6002_PATH_PARAM));
      }

      // Call SAAB
      final Response response;
      try
      {
        RESTRequestBuilder restRequestBuilder = new RESTRequestBuilder();
        restRequestBuilder.httpMethod(HttpMethod.POST).traceability(tracabilite_p).method(METHOD_NAME_RECONCILIATION_COMMERCIALE_CREER).headers(SPIRIT_STARK_REQUEST_HEADER).path(_reconciliationCommercialeUrl).request(reconciliationCommerciale_p);
        response = sendRequest(restRequestBuilder.build());
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get json from response as string
      String jsonResponse = getContent(response, METHOD_NAME_RECONCILIATION_COMMERCIALE_CREER, tracabilite_p);

      // Check response
      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }

      BasicResponse basicResponse = GsonTools.getIso8601Ms().fromJson(jsonResponse, BasicResponse.class);

      // Retour OK
      return new ConnectorResponse<>(RetourConverter.convertFromJsonRetour(basicResponse.getRetour()), null);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, Nothing> reconciliationCommercialeEnMasseAcquitterUn(Tracabilite tracabilite_p, ManageReconciliationCommercialeEnMasseRequest manageReconciliationCommercialeEnMasseRequest_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_reconciliationCommercialeEnMasseUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD6005_PATH_PARAM));
      }

      // Build query parameters
      HashMap<String, String> queryParams = new HashMap<>();
      queryParams.put(PARAM_ACTION, ACTION_ACQUITTER_UN);

      // Call SAAB
      final Response response;
      try
      {
        RESTRequestBuilder restRequestBuilder = new RESTRequestBuilder();
        restRequestBuilder.httpMethod(HttpMethod.PUT).traceability(tracabilite_p).method(METHOD_NAME_RECONCILIATION_COMMERCIALE_EN_MASSE_ACQUITTER_UN).headers(SPIRIT_STARK_REQUEST_HEADER).path(_reconciliationCommercialeEnMasseUrl).queryParameter(queryParams).request(manageReconciliationCommercialeEnMasseRequest_p);
        response = sendRequest(restRequestBuilder.build());
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get json from response as string
      String jsonResponse = getContent(response, METHOD_NAME_RECONCILIATION_COMMERCIALE_EN_MASSE_ACQUITTER_UN, tracabilite_p);

      // Check response
      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }

      BasicResponse basicResponse = GsonTools.getIso8601Ms().fromJson(jsonResponse, BasicResponse.class);

      // Retour OK
      return new ConnectorResponse<>(RetourConverter.convertFromJsonRetour(basicResponse.getRetour()), null);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, List<AssociationPfiReconcialitionCommerciale>> reconciliationCommercialeEnMasseAjouter(Tracabilite tracabilite_p, String idTraitementDeMasse_p, List<String> listeNoCompte_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_reconciliationCommercialeEnMasseUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD6005_PATH_PARAM));
      }

      // Build query parameters
      HashMap<String, String> queryParams = new HashMap<>();
      queryParams.put(PARAM_ACTION, ACTION_AJOUTER);

      ReconciliationCommercialeEnMasseAjouterRequest request = new ReconciliationCommercialeEnMasseAjouterRequest();
      request.setListeNoCompte(listeNoCompte_p);
      request.setIdTraitementDeMasse(idTraitementDeMasse_p);

      // Call SAAB
      final Response response;
      try
      {
        RESTRequestBuilder restRequestBuilder = new RESTRequestBuilder();
        restRequestBuilder.httpMethod(HttpMethod.PUT).traceability(tracabilite_p).method(METHOD_NAME_RECONCILIATION_COMMERCIALE_AJOUTER).headers(SPIRIT_STARK_REQUEST_HEADER).path(_reconciliationCommercialeEnMasseUrl).queryParameter(queryParams).request(request);
        response = sendRequest(restRequestBuilder.build());
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get json from response as string
      String jsonResponse = getContent(response, METHOD_NAME_RECONCILIATION_COMMERCIALE_AJOUTER, tracabilite_p);

      // Check response
      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }

      PutReconciliationCommercialeResponse putReconciliationCommercialeResponse = GsonTools.getIso8601Ms().fromJson(jsonResponse, PutReconciliationCommercialeResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(putReconciliationCommercialeResponse.getRetour());
      List<AssociationPfiReconcialitionCommerciale> listAssociationPfiReconcialitionCommerciales = putReconciliationCommercialeResponse.getListeNoCompteIdReconciliationCommerciale();

      return new ConnectorResponse<>(retour, listAssociationPfiReconcialitionCommerciales);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, List<ReconciliationCommerciale>> reconciliationCommercialeEnMasseLireTous(Tracabilite tracabilite_p, String idTraitementMasse_p, String statut_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_reconciliationCommercialeEnMasseUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD6005_PATH_PARAM));
      }

      // Build query parameters
      HashMap<String, String> queryParams = new HashMap<>();

      if (StringTools.isNotNullOrEmpty(idTraitementMasse_p))
      {
        queryParams.put(PARAM_ID_TRAITEMENT_DE_MASSE, idTraitementMasse_p);
      }
      if (StringTools.isNotNullOrEmpty(statut_p))
      {
        queryParams.put(PARAM_STATUT, statut_p);
      }

      // Call SAAB
      final Response response;
      try
      {
        RESTRequestBuilder restRequestBuilder = new RESTRequestBuilder();
        restRequestBuilder.httpMethod(HttpMethod.GET).traceability(tracabilite_p).method(METHOD_NAME_RECONCILIATION_COMMERCIALE_EN_MASSE_LIRE_TOUS).headers(SPIRIT_STARK_REQUEST_HEADER).path(_reconciliationCommercialeEnMasseUrl).queryParameter(queryParams);
        response = sendRequest(restRequestBuilder.build());
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content to a JSON string
      String jsonResponse = getContent(response, METHOD_NAME_RECONCILIATION_COMMERCIALE_EN_MASSE_LIRE_TOUS, tracabilite_p);

      // Verify response
      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }

      GetReconciliationCommercialeResponse getReconciliationCommercialeResponse = GsonTools.getIso8601Ms().fromJson(jsonResponse, GetReconciliationCommercialeResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(getReconciliationCommercialeResponse.getRetour());
      List<ReconciliationCommerciale> reconciliationCommercialeList = getReconciliationCommercialeResponse.getListeReconciliationCommerciale();

      return new ConnectorResponse<>(retour, reconciliationCommercialeList);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, List<ReconciliationCommerciale>> reconciliationCommercialeLireTousParClientOperateurNoCompte(Tracabilite tracabilite_p, String clientOperateur_p, String noCompte_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_reconciliationCommercialeUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD6002_PATH_PARAM));
      }

      // Build query parameters
      HashMap<String, String> queryParams = new HashMap<>();

      if (StringTools.isNotNullOrEmpty(clientOperateur_p) && StringTools.isNotNullOrEmpty(noCompte_p))
      {
        queryParams.put(PARAM_CLIENT_OPERATEUR, clientOperateur_p);
        queryParams.put(PARAM_NO_COMPTE, noCompte_p);
      }

      // Call SAAB
      final Response response;
      try
      {
        RESTRequestBuilder restRequestBuilder = new RESTRequestBuilder();
        restRequestBuilder.httpMethod(HttpMethod.GET).traceability(tracabilite_p).method(METHOD_NAME_RECONCILIATION_COMMERCIALE_LIRE_TOUS_PAR_CLIENT_OPERATEUR_NO_COMPTE).headers(SPIRIT_STARK_REQUEST_HEADER).path(_reconciliationCommercialeUrl).queryParameter(queryParams);
        response = sendRequest(restRequestBuilder.build());
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content to a JSON string
      String jsonResponse = getContent(response, METHOD_NAME_RECONCILIATION_COMMERCIALE_LIRE_TOUS_PAR_CLIENT_OPERATEUR_NO_COMPTE, tracabilite_p);

      // Verify response
      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }

      GetReconciliationCommercialeResponse getReconciliationCommercialeResponse = GsonTools.getIso8601Ms().fromJson(jsonResponse, GetReconciliationCommercialeResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(getReconciliationCommercialeResponse.getRetour());
      List<ReconciliationCommerciale> reconciliationCommercialeList = getReconciliationCommercialeResponse.getListeReconciliationCommerciale();

      return new ConnectorResponse<>(retour, reconciliationCommercialeList);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, List<ReconciliationCommerciale>> reconciliationCommercialeLireTousParIdReconciliation(Tracabilite tracabilite_p, String idReconciliation_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_reconciliationCommercialeUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD6002_PATH_PARAM));
      }

      // Build query parameters
      HashMap<String, String> queryParams = new HashMap<>();

      if (StringTools.isNotNullOrEmpty(idReconciliation_p))
      {
        queryParams.put(PARAM_ID_RECONCILIATION, idReconciliation_p);
      }

      // Call GET
      final Response response;
      try
      {
        RESTRequestBuilder restRequestBuilder = new RESTRequestBuilder();
        restRequestBuilder.httpMethod(HttpMethod.GET).traceability(tracabilite_p).method(METHOD_NAME_RECONCILIATION_COMMERCIALE_LIRE_TOUS_PAR_ID_RECONCILIATION).headers(SPIRIT_STARK_REQUEST_HEADER).path(_reconciliationCommercialeUrl).queryParameter(queryParams);
        response = sendRequest(restRequestBuilder.build());
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content to a JSON string
      String jsonResponse = getContent(response, METHOD_NAME_RECONCILIATION_COMMERCIALE_LIRE_TOUS_PAR_ID_RECONCILIATION, tracabilite_p);

      // Verify response
      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }

      GetReconciliationCommercialeResponse getReconciliationCommercialeResponse = GsonTools.getIso8601Ms().fromJson(jsonResponse, GetReconciliationCommercialeResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(getReconciliationCommercialeResponse.getRetour());
      List<ReconciliationCommerciale> reconciliationCommercialeList = getReconciliationCommercialeResponse.getListeReconciliationCommerciale();

      return new ConnectorResponse<>(retour, reconciliationCommercialeList);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, Nothing> reconciliationCommercialeModifier(Tracabilite tracabilite_p, CreateOrUpdateReconciliationCommercialeRequest reconciliationCommerciale_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_reconciliationCommercialeUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD6002_PATH_PARAM));
      }

      // Call SAAB
      final Response response;
      try
      {
        RESTRequestBuilder restRequestBuilder = new RESTRequestBuilder();
        restRequestBuilder.httpMethod(HttpMethod.PUT).traceability(tracabilite_p).method(METHOD_NAME_RECONCILIATION_COMMERCIALE_MODIFIER).headers(SPIRIT_STARK_REQUEST_HEADER).path(_reconciliationCommercialeUrl).queryParameter(null).request(reconciliationCommerciale_p);
        response = sendRequest(restRequestBuilder.build());
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get json from response as string
      String jsonResponse = getContent(response, METHOD_NAME_RECONCILIATION_COMMERCIALE_MODIFIER, tracabilite_p);

      // Check response
      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }

      BasicResponse basicResponse = GsonTools.getIso8601Ms().fromJson(jsonResponse, BasicResponse.class);

      // Retour OK
      return new ConnectorResponse<>(RetourConverter.convertFromJsonRetour(basicResponse.getRetour()), null);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, RequeteExploitation> requeteExploitationLireUn(Tracabilite tracabilite_p, String nom_p)
  {
    ConnectorResponse<Retour, ListeRequeteExploitationResponse> response = configurationProsper(tracabilite_p, TypeConfiguration.RequeteExploitation, nom_p, ListeRequeteExploitationResponse.class, METHODE_NAME_REQUETE_EXPLOITATION_LIRE_UN);
    if (RetourFactory.isRetourOK(response._first))
    {
      return new ConnectorResponse<>(RetourFactory.createOkRetour(), response._second.getListeRequeteExploitation().get(0));
    }
    else
    {
      return new ConnectorResponse<>(response._first, null);
    }
  }

  @Override
  public ConnectorResponse<Retour, TemplateRequeteExploitation> templateRequeteExploitationLireUn(Tracabilite tracabilite_p, String nom_p)
  {
    ConnectorResponse<Retour, ListeTemplateRequeteExploitationResponse> response = configurationProsper(tracabilite_p, TypeConfiguration.TemplateRequeteExploitation, nom_p, ListeTemplateRequeteExploitationResponse.class, METHODE_NAME_TEMPLATE_REQUETE_EXPLOITATION_LIRE_UN);
    if (RetourFactory.isRetourOK(response._first))
    {
      return new ConnectorResponse<>(RetourFactory.createOkRetour(), response._second.getListeTemplateRequeteExploitation().get(0));
    }
    else
    {
      return new ConnectorResponse<>(response._first, null);
    }
  }

  @Override
  public ConnectorResponse<Retour, Nothing> traitementDeMasseCreer(Tracabilite tracabilite_p, TraitementDeMasse traitementDeMasse_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_traitementDeMasseUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD6004_PATH_PARAM));
      }

      // Call SAAB
      final Response response;
      try
      {
        RESTRequestBuilder restRequestBuilder = new RESTRequestBuilder();
        restRequestBuilder.httpMethod(HttpMethod.POST).traceability(tracabilite_p).method(METHOD_NAME_TRAITEMENT_MASSE_CREER).headers(SPIRIT_STARK_REQUEST_HEADER).path(_traitementDeMasseUrl).queryParameter(null).request(traitementDeMasse_p);
        response = sendRequest(restRequestBuilder.build());
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get json from response as string
      String jsonResponse = getContent(response, METHOD_NAME_TRAITEMENT_MASSE_CREER, tracabilite_p);

      // Check response
      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }

      BasicResponse basicResponse = GsonTools.getIso8601Ms().fromJson(jsonResponse, BasicResponse.class);

      // Retour OK
      return new ConnectorResponse<>(RetourConverter.convertFromJsonRetour(basicResponse.getRetour()), null);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, List<TraitementDeMasse>> traitementDeMasseLireTous(Tracabilite tracabilite_p, String statut_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_traitementDeMasseUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD6004_PATH_PARAM));
      }

      // Build query parameters
      HashMap<String, String> queryParams = new HashMap<>();

      if (StringTools.isNotNullOrEmpty(statut_p))
      {
        queryParams.put(PARAM_STATUT, statut_p);
      }

      // Call GET
      final Response response;
      try
      {
        RESTRequestBuilder restRequestBuilder = new RESTRequestBuilder();
        restRequestBuilder.httpMethod(HttpMethod.GET).traceability(tracabilite_p).method(METHOD_NAME_TRAITEMENT_MASSE_LIRE_TOUS).headers(SPIRIT_STARK_REQUEST_HEADER).path(_traitementDeMasseUrl).queryParameter(queryParams);
        response = sendRequest(restRequestBuilder.build());
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content to a JSON string
      String jsonResponse = getContent(response, METHOD_NAME_TRAITEMENT_MASSE_LIRE_TOUS, tracabilite_p);

      // Verify response
      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }

      GetTraitementDeMasseResponse getTraitementDeMasseResponse = GsonTools.getIso8601Ms().fromJson(jsonResponse, GetTraitementDeMasseResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(getTraitementDeMasseResponse.getRetour());
      List<TraitementDeMasse> listTraitementDeMasse = getTraitementDeMasseResponse.getListeTraitementDeMasse();
      return new ConnectorResponse<>(retour, listTraitementDeMasse);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, TraitementDeMasse> traitementDeMasseLireUn(Tracabilite tracabilite_p, String idTraitementDeMasse_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_traitementDeMasseUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD6004_PATH_PARAM));
      }

      // Build query parameters
      HashMap<String, String> queryParams = new HashMap<>();

      if (StringTools.isNotNullOrEmpty(idTraitementDeMasse_p))
      {
        queryParams.put(PARAM_ID_TRAITEMENT_DE_MASSE, idTraitementDeMasse_p);
      }

      // Call GET
      final Response response;
      try
      {
        RESTRequestBuilder restRequestBuilder = new RESTRequestBuilder();
        restRequestBuilder.httpMethod(HttpMethod.GET).traceability(tracabilite_p).method(METHOD_NAME_TRAITEMENT_MASSE_LIRE_UN).headers(SPIRIT_STARK_REQUEST_HEADER).path(_traitementDeMasseUrl).queryParameter(queryParams);
        response = sendRequest(restRequestBuilder.build());
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content to a JSON string
      String jsonResponse = getContent(response, METHOD_NAME_TRAITEMENT_MASSE_LIRE_UN, tracabilite_p);

      // Verify response
      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }

      GetTraitementDeMasseResponse getTraitementDeMasseResponse = GsonTools.getIso8601Ms().fromJson(jsonResponse, GetTraitementDeMasseResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(getTraitementDeMasseResponse.getRetour());
      TraitementDeMasse traitementDeMasse = null;
      if ((getTraitementDeMasseResponse.getListeTraitementDeMasse() != null) && !getTraitementDeMasseResponse.getListeTraitementDeMasse().isEmpty())
      {
        traitementDeMasse = getTraitementDeMasseResponse.getListeTraitementDeMasse().get(0);
      }

      return new ConnectorResponse<>(retour, traitementDeMasse);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, Nothing> traitementDeMasseModifierStatutEnCours(Tracabilite tracabilite_p, String idTraitementDeMasse_p, Integer nbTraitementsARealiser_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_traitementDeMasseUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD6004_PATH_PARAM));
      }

      // Build query parameters
      HashMap<String, String> queryParams = new HashMap<>();

      if ((StringTools.isNotNullOrEmpty(idTraitementDeMasse_p)) && (nbTraitementsARealiser_p != null))
      {
        queryParams.put(PARAM_ID_TRAITEMENT_DE_MASSE, idTraitementDeMasse_p);
        queryParams.put(PARAM_NB_TRAITEMENTS_A_REALISER, nbTraitementsARealiser_p.toString());
      }

      // Call PUT
      final Response response;
      try
      {
        RESTRequestBuilder restRequestBuilder = new RESTRequestBuilder();
        restRequestBuilder.httpMethod(HttpMethod.PUT).traceability(tracabilite_p).method(METHOD_NAME_TRAITEMENT_MASSE_MODIFIER_STATUT_EN_COURS).headers(SPIRIT_STARK_REQUEST_HEADER).path(_traitementDeMasseUrl).queryParameter(queryParams);
        response = sendRequest(restRequestBuilder.build());
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get json from response as string
      String jsonResponse = getContent(response, METHOD_NAME_TRAITEMENT_MASSE_MODIFIER_STATUT_EN_COURS, tracabilite_p);

      // Check response
      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }

      BasicResponse basicResponse = GsonTools.getIso8601Ms().fromJson(jsonResponse, BasicResponse.class);

      // Retour OK
      return new ConnectorResponse<>(RetourConverter.convertFromJsonRetour(basicResponse.getRetour()), null);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, LigneDeTestEligDSL> ligneDeTestEligDSLLireUn(Tracabilite tracabilite_p, String numeroDeDesignation_p)
  {
    try
    {
      if (StringTools.isNullOrEmpty(_ligneDeTestEligDSLUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD6015_PATH_PARAM));
      }

      Map<String, String> queryParams = new HashMap<>();
      if (StringTools.isNotNullOrEmpty(numeroDeDesignation_p))
      {
        queryParams.put(PARAM_NUMERO_DE_DESIGNATION, numeroDeDesignation_p);
      }

      Response response;
      try
      {
        RESTRequest request = new RESTRequestBuilder() //
            .httpMethod(HttpMethod.GET) //
            .traceability(tracabilite_p) //
            .headers(SPIRIT_STARK_REQUEST_HEADER) //
            .method(METHOD_NAME_LIGNE_DE_TEST_ELIG_DSL_LIRE_UN) //
            .path(_ligneDeTestEligDSLUrl) //
            .queryParameter(queryParams) //
            .build();
        response = sendRequest(request);
      }
      catch (Exception exception)
      {
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, exception.getMessage()), null);
      }
      String jsonResponse = getContent(response, METHOD_NAME_LIGNE_DE_TEST_ELIG_DSL_LIRE_UN, tracabilite_p);
      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }

      GetLigneDeTestEligDSLResponse getLigneDeTestEligDSLResponse = RavelJsonTools.getInstance().fromJson(jsonResponse, GetLigneDeTestEligDSLResponse.class, SpiritConstants.JSON_PROFILE_STARK);
      LigneDeTestEligDSL ligneDeTestEligDSL = null;
      Retour retour = RetourConverter.convertFromJsonRetour(getLigneDeTestEligDSLResponse.getRetour());
      if (!CollectionUtils.isEmpty(getLigneDeTestEligDSLResponse.getLignesDeTestEligDsl()))
      {
        ligneDeTestEligDSL = getLigneDeTestEligDSLResponse.getLignesDeTestEligDsl().get(0);
      }
      return new ConnectorResponse<>(retour, ligneDeTestEligDSL);
    }
    catch (RavelException e_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, List<LigneDeTestEligDSL>> ligneDeTestEligDSLLireTous(Tracabilite tracabilite_p)
  {
    try
    {
      if (StringTools.isNullOrEmpty(_ligneDeTestEligDSLUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD6015_PATH_PARAM));
      }

      Response response;
      try
      {
        RESTRequest request = new RESTRequestBuilder() //
            .httpMethod(HttpMethod.GET) //
            .traceability(tracabilite_p) //
            .headers(SPIRIT_STARK_REQUEST_HEADER) //
            .method(METHOD_NAME_LIGNE_DE_TEST_ELIG_DSL_LIRE_TOUS) //
            .path(_ligneDeTestEligDSLUrl) //
            .build();
        response = sendRequest(request);
      }
      catch (Exception exception)
      {
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, exception.getMessage()), null);
      }
      String jsonResponse = getContent(response, METHOD_NAME_LIGNE_DE_TEST_ELIG_DSL_LIRE_TOUS, tracabilite_p);
      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }

      GetLigneDeTestEligDSLResponse getLigneDeTestEligDSLResponse = RavelJsonTools.getInstance().fromJson(jsonResponse, GetLigneDeTestEligDSLResponse.class, SpiritConstants.JSON_PROFILE_STARK);
      List<LigneDeTestEligDSL> lignesDeTestEligDSL = null;
      Retour retour = RetourConverter.convertFromJsonRetour(getLigneDeTestEligDSLResponse.getRetour());
      if (!CollectionUtils.isEmpty(getLigneDeTestEligDSLResponse.getLignesDeTestEligDsl()))
      {
        lignesDeTestEligDSL = getLigneDeTestEligDSLResponse.getLignesDeTestEligDsl();
      }
      return new ConnectorResponse<>(retour, lignesDeTestEligDSL);
    }
    catch (Exception e_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, Nothing> ligneDeTestEligDSLCreer(Tracabilite tracabilite_p, LigneDeTestEligDSL ligneDeTestEligDSL_p)
  {
    try
    {
      if (StringTools.isNullOrEmpty(_ligneDeTestEligDSLUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD6015_PATH_PARAM));
      }

      Response response;
      try
      {
        RESTRequest request = new RESTRequestBuilder() //
            .httpMethod(HttpMethod.POST) //
            .serializer(_jsonBuilder) //
            .traceability(tracabilite_p) //
            .headers(SPIRIT_STARK_REQUEST_HEADER) //
            .method(METHOD_NAME_LIGNE_DE_TEST_ELIG_DSL_CREER) //
            .path(_ligneDeTestEligDSLUrl) //
            .request(ligneDeTestEligDSL_p) //
            .build();
        response = sendRequest(request);
      }
      catch (Exception exception)
      {
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, exception.getMessage()), null);
      }
      String jsonResponse = getContent(response, METHOD_NAME_LIGNE_DE_TEST_ELIG_DSL_CREER, tracabilite_p);
      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }

      BasicResponse basicResponse = RavelJsonTools.getInstance().fromJson(jsonResponse, BasicResponse.class);
      return new ConnectorResponse<>(RetourConverter.convertFromJsonRetour(basicResponse.getRetour()), null);
    }
    catch (Exception e_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, Nothing> ligneDeTestEligDSLModifier(Tracabilite tracabilite_p, LigneDeTestEligDSL ligneDeTestEligDSL_p)
  {
    try
    {
      if (StringTools.isNullOrEmpty(_ligneDeTestEligDSLUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD6015_PATH_PARAM));
      }

      Response response;
      try
      {
        RESTRequest request = new RESTRequestBuilder() //
            .httpMethod(HttpMethod.PUT) //
            .serializer(_jsonBuilder) //
            .traceability(tracabilite_p) //
            .headers(SPIRIT_STARK_REQUEST_HEADER) //
            .method(METHOD_NAME_LIGNE_DE_TEST_ELIG_DSL_MODIFIER) //
            .path(_ligneDeTestEligDSLUrl) //
            .request(ligneDeTestEligDSL_p) //
            .build();
        response = sendRequest(request);
      }
      catch (Exception exception)
      {
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, exception.getMessage()), null);
      }
      String jsonResponse = getContent(response, METHOD_NAME_LIGNE_DE_TEST_ELIG_DSL_MODIFIER, tracabilite_p);
      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }

      BasicResponse basicResponse = RavelJsonTools.getInstance().fromJson(jsonResponse, BasicResponse.class);
      return new ConnectorResponse<>(RetourConverter.convertFromJsonRetour(basicResponse.getRetour()), null);
    }
    catch (Exception e_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, Nothing> ligneDeTestEligDSLSupprimer(Tracabilite tracabilite_p, String numeroDeDesignation_p)
  {
    try
    {
      if (StringTools.isNullOrEmpty(_ligneDeTestEligDSLUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD6015_PATH_PARAM));
      }

      Map<String, String> queryParams = new HashMap<>();
      if (StringTools.isNotNullOrEmpty(numeroDeDesignation_p))
      {
        queryParams.put(PARAM_NUMERO_DE_DESIGNATION, numeroDeDesignation_p);
      }

      Response response;
      try
      {
        RESTRequest request = new RESTRequestBuilder() //
            .httpMethod(HttpMethod.DELETE) //
            .traceability(tracabilite_p) //
            .headers(SPIRIT_STARK_REQUEST_HEADER) //
            .method(METHOD_NAME_LIGNE_DE_TEST_ELIG_DSL_SUPPRIMER)
            .path(_ligneDeTestEligDSLUrl) //
            .queryParameter(queryParams) //
            .build();
        response = sendRequest(request);
      }
      catch (Exception exception)
      {
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, exception.getMessage()), null);
      }
      String jsonResponse = getContent(response, METHOD_NAME_LIGNE_DE_TEST_ELIG_DSL_SUPPRIMER, tracabilite_p);
      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }

      BasicResponse basicResponse = RavelJsonTools.getInstance().fromJson(jsonResponse, BasicResponse.class);
      return new ConnectorResponse<>(RetourConverter.convertFromJsonRetour(basicResponse.getRetour()), null);
    }
    catch (Exception e_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  /**
   * GET configurer prosper
   *
   * @param tracabilite_p
   *          tracabilite
   * @param typeConfiguration_p
   *          typeConfiguration
   * @param nom_p
   *          nom
   * @param klass_p
   *          class to serialize
   * @param methodName_p
   *          methode name
   * @param <T>
   *          class type to deserialize
   * @return connector response
   */
  private <T> ConnectorResponse<Retour, T> configurationProsper(Tracabilite tracabilite_p, TypeConfiguration typeConfiguration_p, String nom_p, Class<T> klass_p, String methodName_p)
  {
    try
    {
      if (StringTools.isNullOrEmpty(_configurationProsperUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD6007_PATH_PARAM));
      }

      // Build query parameters
      HashMap<String, String> queryParams = new HashMap<>();

      queryParams.put(TYPE_CONFIGURATION, typeConfiguration_p.name());
      if (StringTools.isNotNullOrEmpty(nom_p))
      {
        queryParams.put(NOM, nom_p);
      }

      // Call GET
      final Response response;
      try
      {
        RESTRequestBuilder restRequestBuilder = new RESTRequestBuilder();
        restRequestBuilder.httpMethod(HttpMethod.GET).traceability(tracabilite_p).method(methodName_p).headers(SPIRIT_STARK_REQUEST_HEADER).path(_configurationProsperUrl).queryParameter(queryParams);
        response = sendRequest(restRequestBuilder.build());
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get json from response as string
      String jsonResponse = getContent(response, methodName_p, tracabilite_p);

      // Check response
      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }

      T resp = RavelJsonTools.getInstance().fromJson(jsonResponse, klass_p);

      // Retour OK
      return new ConnectorResponse<>(RetourConverter.convertFromJsonRetour(((BasicResponse) resp).getRetour()), resp);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

}
