/*******************************************************************************
* $Id: ConfigurationPfsCompositeProxy.java 43187 2020-11-03 11:47:03Z jpais $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.rex.services;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.probes.AvgDoubleCollectorItem;
import com.bytel.ravel.common.probes.AvgFlowPerSecondCollector;
import com.bytel.ravel.common.probes.RavelProbeConfigurationManager;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.services.connector.ConnectorManager;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.connectors.rex.IREXConnector;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.rex.ConfigurationPfs;
import com.bytel.spirit.common.shared.saab.rex.ConfigurationPfsComposite;

import java.util.List;

/**
 *
 * @author jiantila
 * @version ($Revision: 43187 $ $Date: 2020-11-03 12:47:03 +0100 (mar. 03 nov. 2020) $)
 */
public class ConfigurationPfsCompositeProxy
{
  /** Connector Id */
  private String _connectorId;

  /** For probe to count the amount of call to the configurationPfsCompositeLireTous operation */
  AvgFlowPerSecondCollector _avg_configurationPfsCompositeLireTous_call_counter;
  /** For probe to count the execution time of call to the configurationPfsCompositeLireTous operation */
  AvgDoubleCollectorItem _avg_configurationPfsCompositeLireTous_ExecTime;

  /** For probe to count the amount of call to the configurationPfsCompositeGererEcrireConfigurationPfs operation */
  AvgFlowPerSecondCollector _avg_configurationPfsCompositeGererEcrireConfigurationPfs_call_counter;
  /** For probe to count the execution time of call to the configurationPfsCompositeGererEcrireConfigurationPfs operation */
  AvgDoubleCollectorItem _avg_configurationPfsCompositeGererEcrireConfigurationPfs_ExecTime;

  /** For probe to count the amount of call to the configurationPfsCompositeGererEcrirePfs operation */
  AvgFlowPerSecondCollector _avg_configurationPfsCompositeGererEcrirePfs_call_counter;
  /** For probe to count the execution time of call to the configurationPfsCompositeGererEcrirePfs operation */
  AvgDoubleCollectorItem _avg_configurationPfsCompositeGererEcrirePfs_ExecTime;

  /** For probe to count the amount of call to the configurationPfsCompositeGererSuppressionConfigurationPfs operation */
  AvgFlowPerSecondCollector _avg_configurationPfsCompositeGererSuppressionConfigurationPfs_call_counter;
  /** For probe to count the execution time of call to the configurationPfsCompositeGererSuppressionConfigurationPfs operation */
  AvgDoubleCollectorItem _avg_configurationPfsCompositeGererSuppressionConfigurationPfs_ExecTime;

  /** For probe to count the amount of call to the configurationPfsCompositeGererSuppressionPfs operation */
  AvgFlowPerSecondCollector _avg_configurationPfsCompositeGererSuppressionPfs_call_counter;
  /** For probe to count the execution time of call to the configurationPfsCompositeGererSuppressionPfs operation */
  AvgDoubleCollectorItem _avg_configurationPfsCompositeGererSuppressionPfs_ExecTime;

  /**
   *
   * @param connectorId_p
   */
  public ConfigurationPfsCompositeProxy(String connectorId_p)
  {
    _connectorId = connectorId_p;

    _avg_configurationPfsCompositeLireTous_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_configurationPfsCompositeLireTous_call_counter", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_configurationPfsCompositeLireTous_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_configurationPfsCompositeLireTous_ExecTime", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$

    _avg_configurationPfsCompositeGererEcrireConfigurationPfs_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_configurationPfsCompositeGererEcrireConfigurationPfs_call_counter", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_configurationPfsCompositeGererEcrireConfigurationPfs_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_configurationPfsCompositeGererEcrireConfigurationPfs_ExecTime", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$

    _avg_configurationPfsCompositeGererEcrirePfs_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_configurationPfsCompositeGererEcrirePfs_call_counter", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_configurationPfsCompositeGererEcrirePfs_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_configurationPfsCompositeGererEcrirePfs_ExecTime", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$

    _avg_configurationPfsCompositeGererSuppressionConfigurationPfs_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_configurationPfsCompositeGererSuppressionConfigurationPfs_call_counter", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_configurationPfsCompositeGererSuppressionConfigurationPfs_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_configurationPfsCompositeGererSuppressionConfigurationPfs_ExecTime", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$

    _avg_configurationPfsCompositeGererSuppressionPfs_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_configurationPfsCompositeGererSuppressionPfs_call_counter", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_configurationPfsCompositeGererSuppressionPfs_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_configurationPfsCompositeGererSuppressionPfs_ExecTime", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
  }

  /**
   *
   * @param tracabilite_p
   * @param xOauth2Login_p
   * @param configurationPfs_p
   * @return
   * @throws RavelException
   */
  public ConnectorResponse<Retour, Nothing> configurationPfsCompositeGererEcrireConfigurationPfs(Tracabilite tracabilite_p, String xOauth2Login_p, ConfigurationPfs configurationPfs_p) throws RavelException
  {
    IREXConnector rexConnector = null;
    try
    {
      rexConnector = (IREXConnector) ConnectorManager.getInstance().getConnector(_connectorId);
    }
    catch (Exception e_p)
    {
      // Retour NOK
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
    }
    _avg_configurationPfsCompositeGererEcrireConfigurationPfs_call_counter.measure();
    long startTime = System.currentTimeMillis();
    try
    {
      return rexConnector.configurationPfsCompositeGererEcrireConfigurationPfs(tracabilite_p, xOauth2Login_p, configurationPfs_p);
    }
    finally
    {
      long endTime = System.currentTimeMillis();
      _avg_configurationPfsCompositeGererEcrireConfigurationPfs_ExecTime.updateAvgValue(endTime - startTime);
    }
  }

  /**
   *
   * @param tracabilite_p
   * @param xOauth2Login_p
   * @param configurationPfsComposite_p
   * @return
   * @throws RavelException
   */
  public ConnectorResponse<Retour, Nothing> configurationPfsCompositeGererEcrirePfs(Tracabilite tracabilite_p, String xOauth2Login_p, ConfigurationPfsComposite configurationPfsComposite_p) throws RavelException
  {
    IREXConnector rexConnector = null;
    try
    {
      rexConnector = (IREXConnector) ConnectorManager.getInstance().getConnector(_connectorId);
    }
    catch (Exception e_p)
    {
      // Retour NOK
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
    }
    _avg_configurationPfsCompositeGererEcrirePfs_call_counter.measure();
    long startTime = System.currentTimeMillis();
    try
    {
      return rexConnector.configurationPfsCompositeGererEcrirePfs(tracabilite_p, xOauth2Login_p, configurationPfsComposite_p);
    }
    finally
    {
      long endTime = System.currentTimeMillis();
      _avg_configurationPfsCompositeGererEcrirePfs_ExecTime.updateAvgValue(endTime - startTime);
    }
  }

  /**
   *
   * @param tracabilite_p
   * @param xOauth2Login_p
   * @param configurationPfs_p
   * @return
   * @throws RavelException
   */
  public ConnectorResponse<Retour, Nothing> configurationPfsCompositeGererSuppressionConfigurationPfs(Tracabilite tracabilite_p, String xOauth2Login_p, ConfigurationPfs configurationPfs_p) throws RavelException
  {
    IREXConnector rexConnector = null;
    try
    {
      rexConnector = (IREXConnector) ConnectorManager.getInstance().getConnector(_connectorId);
    }
    catch (Exception e_p)
    {
      // Retour NOK
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
    }
    _avg_configurationPfsCompositeGererSuppressionConfigurationPfs_call_counter.measure();
    long startTime = System.currentTimeMillis();
    try
    {
      return rexConnector.configurationPfsCompositeGererSuppressionConfigurationPfs(tracabilite_p, xOauth2Login_p, configurationPfs_p);
    }
    finally
    {
      long endTime = System.currentTimeMillis();
      _avg_configurationPfsCompositeGererSuppressionConfigurationPfs_ExecTime.updateAvgValue(endTime - startTime);
    }
  }

  /**
   *
   * @param tracabilite_p
   * @param xOauth2Login_p
   * @param configurationPfsComposite_p
   * @return
   * @throws RavelException
   */
  public ConnectorResponse<Retour, Nothing> configurationPfsCompositeGererSuppressionPfs(Tracabilite tracabilite_p, String xOauth2Login_p, ConfigurationPfsComposite configurationPfsComposite_p) throws RavelException
  {
    IREXConnector rexConnector = null;
    try
    {
      rexConnector = (IREXConnector) ConnectorManager.getInstance().getConnector(_connectorId);
    }
    catch (Exception e_p)
    {
      // Retour NOK
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
    }
    _avg_configurationPfsCompositeGererSuppressionPfs_call_counter.measure();
    long startTime = System.currentTimeMillis();
    try
    {
      return rexConnector.configurationPfsCompositeGererSuppressionPfs(tracabilite_p, xOauth2Login_p, configurationPfsComposite_p);
    }
    finally
    {
      long endTime = System.currentTimeMillis();
      _avg_configurationPfsCompositeGererSuppressionPfs_ExecTime.updateAvgValue(endTime - startTime);
    }
  }

  /**
   *
   * @param tracabilite_p
   * @return
   * @throws RavelException
   */
  public ConnectorResponse<Retour, List<ConfigurationPfsComposite>> configurationPfsCompositeLireTous(Tracabilite tracabilite_p) throws RavelException
  {
    IREXConnector rexConnector = null;
    try
    {
      rexConnector = (IREXConnector) ConnectorManager.getInstance().getConnector(_connectorId);
    }
    catch (Exception e_p)
    {
      // Retour NOK
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
    }
    _avg_configurationPfsCompositeLireTous_call_counter.measure();
    long startTime = System.currentTimeMillis();
    try
    {
      return rexConnector.configurationPfsCompositeLireTous(tracabilite_p);
    }
    finally
    {
      long endTime = System.currentTimeMillis();
      _avg_configurationPfsCompositeLireTous_ExecTime.updateAvgValue(endTime - startTime);
    }
  }

}
