/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.rex;

import java.util.List;
import java.util.Set;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.shared.functional.types.json.notification.AbstractNotificationReseau;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.rex.AssociationPfiReconcialitionCommerciale;
import com.bytel.spirit.common.shared.saab.rex.BlocageEquipement;
import com.bytel.spirit.common.shared.saab.rex.ClientImpacte;
import com.bytel.spirit.common.shared.saab.rex.ComparaisonCommerciale;
import com.bytel.spirit.common.shared.saab.rex.ConfigurationPfs;
import com.bytel.spirit.common.shared.saab.rex.ConfigurationPfsComposite;
import com.bytel.spirit.common.shared.saab.rex.DecisionExploitation;
import com.bytel.spirit.common.shared.saab.rex.ErreurSpirit;
import com.bytel.spirit.common.shared.saab.rex.HistorisationEligibilite;
import com.bytel.spirit.common.shared.saab.rex.LigneDeTestEligDSL;
import com.bytel.spirit.common.shared.saab.rex.OperationVieReseau;
import com.bytel.spirit.common.shared.saab.rex.ReconciliationCommerciale;
import com.bytel.spirit.common.shared.saab.rex.RequeteExploitation;
import com.bytel.spirit.common.shared.saab.rex.TemplateRequeteExploitation;
import com.bytel.spirit.common.shared.saab.rex.TraitementDeMasse;
import com.bytel.spirit.common.shared.saab.rex.request.CreateComparaisonCommercialeCompositeRequest;
import com.bytel.spirit.common.shared.saab.rex.request.CreateErreurSpiritRequest;
import com.bytel.spirit.common.shared.saab.rex.request.CreateOrUpdateReconciliationCommercialeRequest;
import com.bytel.spirit.common.shared.saab.rex.request.ListeCleRechercheBlocageEquipementRequest;
import com.bytel.spirit.common.shared.saab.rex.request.ListeCleRechercheNotificationReseauRequest;
import com.bytel.spirit.common.shared.saab.rex.request.ListeCleRechercheOperationVieReseauRequest;
import com.bytel.spirit.common.shared.saab.rex.request.ManageReconciliationCommercialeEnMasseRequest;
import com.bytel.spirit.common.shared.saab.rex.request.UpdateBlocageEquipementRequest;
import com.bytel.spirit.common.shared.saab.rex.request.UpdateErreurSpiritRequest;
import com.bytel.spirit.common.shared.saab.rex.request.UpdateNotificationReseauStatutRequest;

/**
 * Interface of CMDConnector that defines methods to implements
 *
 * @author kbettenc
 * @version ($Revision$ $Date$)
 */
public interface IREX
{

  /**
   * Creer Blocage Equipement
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param blocageEquipement_p
   *          {@link BlocageEquipement}
   * @return {@link Retour}
   * @throws RavelException
   */
  public ConnectorResponse<Retour, Nothing> blocageEquipementCreer(Tracabilite tracabilite_p, BlocageEquipement blocageEquipement_p) throws RavelException;

  /**
   * Lire Un Blocage Equipement
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param idBlocageEquipement_p
   *          idBlocageEquipement_p
   * @return {@link Retour}
   * @throws RavelException
   */
  public ConnectorResponse<Retour, BlocageEquipement> blocageEquipementLireUn(Tracabilite tracabilite_p, String idBlocageEquipement_p) throws RavelException;

  /**
   * Modifier Blocage Equipement
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param updateBlocageEquipementRequest_p
   *          {@link UpdateBlocageEquipementRequest}
   * @return {@link Retour}
   * @throws RavelException
   */
  public ConnectorResponse<Retour, Nothing> blocageEquipementModifier(Tracabilite tracabilite_p, UpdateBlocageEquipementRequest updateBlocageEquipementRequest_p) throws RavelException;

  /**
   * Supprimer Blocage Equipement
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param idBlocageEquipement_p
   *          idBlocageEquipement_p
   * @return {@link Retour}
   * @throws RavelException
   */
  public ConnectorResponse<Retour, Nothing> blocageEquipementSupprimer(Tracabilite tracabilite_p, String idBlocageEquipement_p) throws RavelException;

  /**
   * Creer CleRecherche BlocageEquipement
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param listeCleRechercheBlocageEquipementRequest_p
   *          objet à creer
   * @return {@link Retour}
   * @throws RavelException
   */
  public ConnectorResponse<Retour, Nothing> cleRechercheBlocageEquipementCreerListe(Tracabilite tracabilite_p, ListeCleRechercheBlocageEquipementRequest listeCleRechercheBlocageEquipementRequest_p) throws RavelException;

  /**
   * Cle Recherche NotificationReseau
   *
   * @param tracabilite_p
   * @param listeCleRechercheNotificationReseauRequest_p
   * @return
   * @throws RavelException
   */
  public ConnectorResponse<Retour, Nothing> cleRechercheNotificationReseau(Tracabilite tracabilite_p, ListeCleRechercheNotificationReseauRequest listeCleRechercheNotificationReseauRequest_p) throws RavelException;

  /**
   * Creer CleRecherche Operation Vie Reseau
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param listeCleRechercheOperationVieReseauRequest_p
   *          objet à creer
   * @return {@link Retour}
   * @throws RavelException
   *           exception
   */
  public ConnectorResponse<Retour, Nothing> cleRechercheOperationVieReseauCreerListe(Tracabilite tracabilite_p, ListeCleRechercheOperationVieReseauRequest listeCleRechercheOperationVieReseauRequest_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite
   * @param comparaisonCommerciale_p
   *          the comparaison commerciale
   * @return
   * @throws RavelException
   */
  public ConnectorResponse<Retour, Nothing> comparaisonCommercialeCompositeCreer(Tracabilite tracabilite_p, CreateComparaisonCommercialeCompositeRequest comparaisonCommerciale_p) throws RavelException;

  /**
   * @param tracabilite_p
   * @param idCmd_p
   * @return
   * @throws RavelException
   */
  public ConnectorResponse<Retour, List<ComparaisonCommerciale>> comparaisonCommercialeCompositeLireTousParIdCmd(Tracabilite tracabilite_p, String idCmd_p) throws RavelException;

  /**
   * Gerer Ecrire ConfigurationPfs
   *
   * @param tracabilite_p
   * @param xOauth2Login_p
   * @param configurationPfs_p
   * @return
   * @throws RavelException
   */
  public ConnectorResponse<Retour, Nothing> configurationPfsCompositeGererEcrireConfigurationPfs(Tracabilite tracabilite_p, String xOauth2Login_p, ConfigurationPfs configurationPfs_p) throws RavelException;

  /**
   * Gerer Ecrire PFS
   *
   * @param tracabilite_p
   *          tracability.
   * @param xOauth2Login_p
   * @param configurationPfsComposite_p
   *          Request containing the {@link ConfigurationPfs} to persist.
   * @return Connector with only a Retour in it.
   * @throws RavelException
   *           if SAAB call fails.
   */
  public ConnectorResponse<Retour, Nothing> configurationPfsCompositeGererEcrirePfs(Tracabilite tracabilite_p, String xOauth2Login_p, ConfigurationPfsComposite configurationPfsComposite_p) throws RavelException;

  /**
   * Gerer Suppression ConfigurationPfs
   *
   * @param tracabilite_p
   *          tracability.
   * @param xOauth2Login_p
   * @param configurationPfs_p
   *          Request containing the {@link ConfigurationPfs} to persist.
   * @return Connector with only a Retour in it.
   * @throws RavelException
   *           if SAAB call fails.
   */
  public ConnectorResponse<Retour, Nothing> configurationPfsCompositeGererSuppressionConfigurationPfs(Tracabilite tracabilite_p, String xOauth2Login_p, ConfigurationPfs configurationPfs_p) throws RavelException;

  /**
   * Gerer Suppresion ConfigurationPfs
   *
   * @param tracabilite_p
   * @param xOauth2Login_p
   * @param configurationPfsComposite_p
   * @return
   * @throws RavelException
   */
  public ConnectorResponse<Retour, Nothing> configurationPfsCompositeGererSuppressionPfs(Tracabilite tracabilite_p, String xOauth2Login_p, ConfigurationPfsComposite configurationPfsComposite_p) throws RavelException;

  /**
   * Read all Configuration PFS Composite (configurationPfsCompositeLireTous verb).
   *
   * @param tracabilite_p
   *          tracability.
   * @return List of {@link ConfigurationPfsComposite}.
   * @throws RavelException
   *           if the SAAB call fails.
   */
  public ConnectorResponse<Retour, List<ConfigurationPfsComposite>> configurationPfsCompositeLireTous(Tracabilite tracabilite_p) throws RavelException;

  /**
   * Get configuration decision explotation lire un
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param nomDecisionExploitation_p
   *          nomDecisionExploitation
   * @return {@link Retour}
   */
  ConnectorResponse<Retour, DecisionExploitation> decisionExploitationLireUn(Tracabilite tracabilite_p, String nomDecisionExploitation_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite
   * @param erreurSpirit_p
   *          the erreur spirit
   * @return
   * @throws RavelException
   */
  public ConnectorResponse<Retour, Nothing> erreurSpiritCreer(Tracabilite tracabilite_p, CreateErreurSpiritRequest erreurSpirit_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite
   * @param statut_p
   *          the status
   * @param dateDeb_p
   *          start date
   * @param dateFin_p
   *          end date
   *
   * @return
   * @throws RavelException
   */
  public ConnectorResponse<Retour, List<ErreurSpirit>> erreurSpiritLireTousParStatutPeriod(Tracabilite tracabilite_p, String statut_p, String dateDeb_p, String dateFin_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite
   * @param dateDeb_p
   *          start date
   * @param dateFin_p
   *          end date
   *
   * @return
   * @throws RavelException
   */
  public ConnectorResponse<Retour, List<ErreurSpirit>> erreurSpiritLireTousSurPeriod(Tracabilite tracabilite_p, String dateDeb_p, String dateFin_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite
   * @param idErreurSpirit_p
   *          Id of the erreur spirit
   * @return
   * @throws RavelException
   */

  public ConnectorResponse<Retour, List<ErreurSpirit>> erreurSpiritLireUn(Tracabilite tracabilite_p, String idErreurSpirit_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite
   * @param erreurSpirit_p
   *          the erreur spirit
   * @return
   * @throws RavelException
   */
  public ConnectorResponse<Retour, Nothing> erreurSpiritModifierStatut(Tracabilite tracabilite_p, UpdateErreurSpiritRequest erreurSpirit_p) throws RavelException;

  /**
   * Create historisation eligibilite
   *
   * @param tracabilite_p
   * @param historisationEligibilite_p
   * @return
   * @throws RavelException
   */
  public ConnectorResponse<Retour, Nothing> historisationEligibiliteCreer(Tracabilite tracabilite_p, HistorisationEligibilite historisationEligibilite_p) throws RavelException;

  /**
   * Creer notification reseau
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param notificationReseau_p
   *          objet à creer
   * @return {@link Retour}
   * @throws RavelException
   *           exception
   */
  public ConnectorResponse<Retour, Nothing> notificationReseauCreer(Tracabilite tracabilite_p, AbstractNotificationReseau notificationReseau_p) throws RavelException;

  /**
   * Lire notification reseau
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param idNotificationReseau_p
   *          id notification reseau
   * @return {@link Retour}
   * @throws RavelException
   *           exception
   */
  public ConnectorResponse<Retour, AbstractNotificationReseau> notificationReseauLireUn(Tracabilite tracabilite_p, String idNotificationReseau_p) throws RavelException;

  /**
   * Modifier notification reseau
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @return {@link Retour}
   * @throws RavelException
   *           exception
   */
  public ConnectorResponse<Retour, Nothing> notificationReseauModifierStatut(Tracabilite tracabilite_p, UpdateNotificationReseauStatutRequest updateNotificationReseauStatutRequest_p) throws RavelException;

  /**
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param typeOperationVieReseau_p
   *          Type notification Réseau
   * @param typeCle_p
   *          Le type de la clé composée
   * @param valeurCle_p
   *          La valeur d’une clé
   * @return {@link Retour} {@link Retour}
   * @throws RavelException
   *           exception
   */
  public ConnectorResponse<Retour, List<OperationVieReseau>> operationVieReseauCompositeLireTousParCleRecherche(Tracabilite tracabilite_p, String typeOperationVieReseau_p, String typeCle_p, String valeurCle_p) throws RavelException;

  /**
   * Creer Operation Vie Reseau
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param operationVieReseau_p
   *          objet à creer
   * @return {@link Retour}
   * @throws RavelException
   *           exception
   */
  public ConnectorResponse<Retour, Nothing> operationVieReseauCreer(Tracabilite tracabilite_p, OperationVieReseau operationVieReseau_p) throws RavelException;

  /**
   * Lire Un Operation Vie Reseau
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param idOperationVieReseau_p
   *          objet à creer
   * @return {@link Retour}
   * @throws RavelException
   *           exception
   */
  public ConnectorResponse<Retour, OperationVieReseau> operationVieReseauLireUn(Tracabilite tracabilite_p, String idOperationVieReseau_p) throws RavelException;

  /**
   * Modifier Liste Client Impacte Operation Vie Reseau
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param idOperationVieReseau_p
   *          Identifiant de l’opération vie réseau
   * @param clientImpactes_p
   *          La liste des identifiants des Clients impactés par l’opération vie réseau.
   * @return
   * @throws RavelException
   */
  public ConnectorResponse<Retour, Nothing> operationVieReseauModifierListeClientImpacte(Tracabilite tracabilite_p, String idOperationVieReseau_p, Set<ClientImpacte> clientImpactes_p) throws RavelException;

  /**
   * Modifier Statut Operation Vie Reseau
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param idOperationVieReseau_p
   *          Identifiant de l’opération vie réseau
   * @param statut_p
   *          Statut de l’opération vie réseau
   * @param codeErreur_p
   *          Code d’erreur associé en cas de rejet ou de traitement NOK
   * @param libelleErreur_p
   *          Libellé d’erreur associé en cas de rejet ou de traitement NOK Format : sans emploi des codes délimiteurs
   *          («;», CR/LF, EOF)
   * @return
   * @return {@link Retour}
   * @throws RavelException
   *           exception
   */
  public ConnectorResponse<Retour, Nothing> operationVieReseauModifierStatut(Tracabilite tracabilite_p, String idOperationVieReseau_p, String statut_p, String codeErreur_p, String libelleErreur_p) throws RavelException;

  /**
   * Create Reconciliation Comerciale
   *
   * @param tracabilite_p
   *          The tracabilite.
   * @param reconciliationCommerciale_p
   *          The reconciliation comertiale.
   * @return
   * @throws RavelException
   */
  public ConnectorResponse<Retour, Nothing> reconciliationCommercialeCreer(Tracabilite tracabilite_p, CreateOrUpdateReconciliationCommercialeRequest reconciliationCommerciale_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param manageReconciliationCommercialeEnMasseRequest_p
   *          {@link ManageReconciliationCommercialeEnMasseRequest}
   * @return {@link Retour}
   * @throws RavelException
   *           exception
   */
  public ConnectorResponse<Retour, Nothing> reconciliationCommercialeEnMasseAcquitterUn(Tracabilite tracabilite_p, ManageReconciliationCommercialeEnMasseRequest manageReconciliationCommercialeEnMasseRequest_p) throws RavelException;

  /**
   * Update Reconciliation Comerciale
   *
   * @param tracabilite_p
   *          The tracabilite.
   * @param idTraitementDeMasse_p
   *          The traitement de masse Id
   * @param listeNoCompte_p
   *          The account numbers list
   * @return ConnectorResponse<Retour, List<AssociationPfiReconcialitionCommerciale>>
   * @throws RavelException
   *           Thrown in case of failure
   */
  public ConnectorResponse<Retour, List<AssociationPfiReconcialitionCommerciale>> reconciliationCommercialeEnMasseAjouter(Tracabilite tracabilite_p, String idTraitementDeMasse_p, List<String> listeNoCompte_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param idTraitementMasse_p
   *          id traitement masse
   * @param statut_p
   *          statut
   * @return {@link Retour}
   * @throws RavelException
   *           exception
   */
  public ConnectorResponse<Retour, List<ReconciliationCommerciale>> reconciliationCommercialeEnMasseLireTous(Tracabilite tracabilite_p, String idTraitementMasse_p, String statut_p) throws RavelException;

  /**
   * @param tracabilite_p
   * @param clientOperateur_p
   * @param noCompte_p
   * @return
   * @throws RavelException
   */
  public ConnectorResponse<Retour, List<ReconciliationCommerciale>> reconciliationCommercialeLireTousParClientOperateurNoCompte(Tracabilite tracabilite_p, String clientOperateur_p, String noCompte_p) throws RavelException;

  /**
   * @param tracabilite_p
   * @param idReconciliation_p
   * @return
   * @throws RavelException
   */
  public ConnectorResponse<Retour, List<ReconciliationCommerciale>> reconciliationCommercialeLireTousParIdReconciliation(Tracabilite tracabilite_p, String idReconciliation_p) throws RavelException;

  /**
   * Update Reconciliation Comerciale
   *
   * @param tracabilite_p
   *          The tracabilite.
   * @param reconciliationCommerciale_p
   *          The reconciliation comertiale.
   * @return ConnectorResponse<Retour, Nothing>
   * @throws RavelException
   *           Thrown in case of failure
   */
  public ConnectorResponse<Retour, Nothing> reconciliationCommercialeModifier(Tracabilite tracabilite_p, CreateOrUpdateReconciliationCommercialeRequest reconciliationCommerciale_p) throws RavelException;

  /**
   * Get configuration template requete exploitation
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param nomRequete_p
   *          nomDecisionExploitation
   * @return {@link Retour}
   */
  ConnectorResponse<Retour, RequeteExploitation> requeteExploitationLireUn(Tracabilite tracabilite_p, String nomRequete_p) throws RavelException;

  /**
   * Get configuration requete exploitation lire un
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param nomTemplateRequeteExploitation_p
   *          nomDecisionExploitation
   * @return {@link Retour}
   */
  ConnectorResponse<Retour, TemplateRequeteExploitation> templateRequeteExploitationLireUn(Tracabilite tracabilite_p, String nomTemplateRequeteExploitation_p) throws RavelException;

  /**
   * Get traitement de masse by id
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param traitementDeMasse_p
   *          traitement
   * @return {@link Retour}
   * @throws RavelException
   *           exception
   */
  public ConnectorResponse<Retour, Nothing> traitementDeMasseCreer(Tracabilite tracabilite_p, TraitementDeMasse traitementDeMasse_p) throws RavelException;

  /**
   * Get traitements de masse
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param statut_p
   *          statut
   * @return {@link Retour}
   * @throws RavelException
   *           exception
   */
  public ConnectorResponse<Retour, List<TraitementDeMasse>> traitementDeMasseLireTous(Tracabilite tracabilite_p, String statut_p) throws RavelException;

  /**
   * Get traitement de masse by id
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param idTraitementDeMasse_p
   *          id traitement
   * @return {@link Retour}
   * @throws RavelException
   *           exception
   */
  public ConnectorResponse<Retour, TraitementDeMasse> traitementDeMasseLireUn(Tracabilite tracabilite_p, String idTraitementDeMasse_p) throws RavelException;

  /**
   * Get traitement de masse by id
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param idTraitementDeMasse_p
   *          id traitement
   * @param nbTraitementsARealiser_p
   *          Nombre de traitements
   * @return {@link Retour}
   * @throws RavelException
   *           exception
   */
  public ConnectorResponse<Retour, Nothing> traitementDeMasseModifierStatutEnCours(Tracabilite tracabilite_p, String idTraitementDeMasse_p, Integer nbTraitementsARealiser_p) throws RavelException;

  /**
   * Get LigneDeTest by nd
   *
   * @param tracabilite_p
   *           {@link Tracabilite}
   * @param numeroDeDesignation_p
   *           Numero de Désignation (nd)
   * @return {@link Retour}
   * @throws RavelException
   *            exception
   */
  public ConnectorResponse<Retour, LigneDeTestEligDSL> ligneDeTestEligDSLLireUn(Tracabilite tracabilite_p, String numeroDeDesignation_p) throws RavelException;

  /**
   * Get all LigneDeTest
   *
   * @param tracabilite_p
   *           {@link Tracabilite}
   * @return {@link Retour}
   * @throws RavelException
   *            exception
   */
  public ConnectorResponse<Retour, List<LigneDeTestEligDSL>> ligneDeTestEligDSLLireTous(Tracabilite tracabilite_p) throws RavelException;

  /**
   * Creates LigneDeTest
   *
   * @param tracabilite_p
   *           {@link Tracabilite}
   * @param ligneDeTestEligDSL_p
   *           LigneDeTest
   * @return {@link Retour}
   * @throws RavelException
   *            exception
   */
  public ConnectorResponse<Retour, Nothing> ligneDeTestEligDSLCreer(Tracabilite tracabilite_p, LigneDeTestEligDSL ligneDeTestEligDSL_p) throws RavelException;

  /**
   * Update LigneDeTest
   *
   * @param tracabilite_p
   *           {@link Tracabilite}
   * @param ligneDeTestEligDSL_p
   *            LigneDeTest
   * @return {@link Retour}
   * @throws RavelException
   *            exception
   */
  public ConnectorResponse<Retour, Nothing> ligneDeTestEligDSLModifier(Tracabilite tracabilite_p, LigneDeTestEligDSL ligneDeTestEligDSL_p) throws RavelException;

  /**
   * Delete LigneDeTest by nd
   *
   * @param tracabilite_p
   *           {@link Tracabilite}
   * @param numeroDeDesignation_p
   *            Numero de Désignation (nd)
   * @return {@link Retour}
   * @throws RavelException
   *            exception
   */
  public ConnectorResponse<Retour, Nothing> ligneDeTestEligDSLSupprimer(Tracabilite tracabilite_p, String numeroDeDesignation_p) throws RavelException;
}
