/*******************************************************************************
* $Id: ConfigurationPfsCompositeService.java 49682 2021-03-24 13:30:21Z fbarnabe $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.rex.services;

import static com.bytel.spirit.common.connectors.rex.REXConnector.MESSAGE_MISSING_CONFIGURATION_PARAMETER;

import java.text.MessageFormat;
import java.util.HashMap;
import java.util.List;

import javax.ws.rs.HttpMethod;
import javax.ws.rs.core.Response;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.json.IRavelJson;
import com.bytel.ravel.common.json.RavelJson;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.connector.RESTRequest;
import com.bytel.ravel.services.connector.RESTRequest.RESTRequestBuilder;
import com.bytel.spirit.common.connectors.rex.IREXConnector;
import com.bytel.spirit.common.connectors.rex.REXConnector;
import com.bytel.spirit.common.shared.misc.connectors.AbstractInternalRESTConnector;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.BasicResponse;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.ressources.RetourConverter;
import com.bytel.spirit.common.shared.misc.ressources.SpiritConstants;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.rex.ConfigurationPfs;
import com.bytel.spirit.common.shared.saab.rex.ConfigurationPfsComposite;
import com.bytel.spirit.common.shared.saab.rex.response.GetConfigurationPfsCompositeResponse;

/**
 *
 * @author jpais
 * @version ($Revision: 49682 $ $Date: 2021-03-24 14:30:21 +0100 (mer. 24 mars 2021) $)
 */
public class ConfigurationPfsCompositeService
{
  private interface IAction
  {
    String GERER_ECRIRE_CONFIGURATION_PFS = "GererEcrireConfigurationPfs"; //$NON-NLS-1$
    String GERER_ECRIRE_PFS = "GererEcrirePfs"; //$NON-NLS-1$
    String GERER_SUPPRESSION_CONFIGURATION_PFS = "GererSuppressionConfigurationPfs"; //$NON-NLS-1$
    String GERER_SUPPRESSION_PFS = "GererSuppressionPfs"; //$NON-NLS-1$
  }

  private interface IMethodName
  {
    String CONFIGURATION_PFS_COMPOSITE_LIRE_TOUS = "configurationPfsCompositeLireTous"; //$NON-NLS-1$
    String CONFIGURATION_PFS_COMPOSITE_GERER_ECRIRE_CONFIGURATION_PFS = "configurationPfsCompositeGererEcrireConfigurationPfs"; //$NON-NLS-1$
    String CONFIGURATION_PFS_COMPOSITE_GERER_ECRIRE_PFS = "configurationPfsCompositeGererEcrirePfs"; //$NON-NLS-1$
    String CONFIGURATION_PFS_COMPOSITE_GERER_SUPPRESSION_CONFIGURATION_PFS = "configurationPfsCompositeGererSuppressionConfigurationPfs"; //$NON-NLS-1$
    String CONFIGURATION_PFS_COMPOSITE_GERER_SUPPRESSION_PFS = "configurationPfsCompositeGererSuppressionPfs"; //$NON-NLS-1$
  }

  /** REXConnector instance */
  private final REXConnector _rexInstance;

  /** Json Builder instance */
  private final IRavelJson _jsonBuilder;

  /**
   * @param rexInstance_p
   *          {@link REXConnector}
   */
  public ConfigurationPfsCompositeService(REXConnector rexInstance_p)
  {
    _rexInstance = rexInstance_p;
    _jsonBuilder = new RavelJson.RavelJsonBuilder().profil(SpiritConstants.JSON_PROFILE_STARK).build();
  }

  /**
   * GererEcrireConfigurationPfs
   *
   * @param tracabilite_p
   * @param configurationPfsCompositeUrl_p
   * @param xOauth2Login_p
   * @param configurationPfs_p
   * @return
   */
  public ConnectorResponse<Retour, Nothing> configurationPfsCompositeGererEcrireConfigurationPfs(Tracabilite tracabilite_p, String configurationPfsCompositeUrl_p, String xOauth2Login_p, ConfigurationPfs configurationPfs_p)
  {
    try
    {
      if (StringTools.isNullOrEmpty(configurationPfsCompositeUrl_p))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, REXConnector.PAD6006_PATH_PARAM));
      }

      // Call SAAB
      final Response response;
      HashMap<String, String> queryParams = new HashMap<>();
      queryParams.put(IREXConnector.PARAM_ACTION, IAction.GERER_ECRIRE_CONFIGURATION_PFS);

      // Add header
      AbstractInternalRESTConnector.getSpiritStarkRequestHeader().putSingle(IHttpHeadersConsts.X_OAUTH2_LOGIN, xOauth2Login_p);

      try
      {
        RESTRequest restRequest = new RESTRequestBuilder() //
            .httpMethod(HttpMethod.PUT) //
            .traceability(tracabilite_p) //
            .method(IMethodName.CONFIGURATION_PFS_COMPOSITE_GERER_ECRIRE_CONFIGURATION_PFS) //
            .headers(AbstractInternalRESTConnector.getSpiritStarkRequestHeader()) //
            .path(configurationPfsCompositeUrl_p) //
            .queryParameter(queryParams) //
            .request(new ConfigurationPfsComposite(configurationPfs_p)) //
            .serializer(_jsonBuilder) //
            .build();
        response = _rexInstance.sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get response
      BasicResponse basicResponse = _rexInstance.getContentFromResponse(tracabilite_p, response, IMethodName.CONFIGURATION_PFS_COMPOSITE_GERER_ECRIRE_CONFIGURATION_PFS, BasicResponse.class);

      // Retour OK
      return new ConnectorResponse<>(RetourConverter.convertFromJsonRetour(basicResponse.getRetour()), null);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  /**
   * GererEcrirePfs
   *
   * @param tracabilite_p
   * @param configurationPfsCompositeUrl_p
   * @param xOauth2Login_p
   * @param configurationPfsComposite_p
   * @return
   */
  public ConnectorResponse<Retour, Nothing> configurationPfsCompositeGererEcrirePfs(Tracabilite tracabilite_p, String configurationPfsCompositeUrl_p, String xOauth2Login_p, ConfigurationPfsComposite configurationPfsComposite_p)
  {
    try
    {
      if (StringTools.isNullOrEmpty(configurationPfsCompositeUrl_p))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, REXConnector.PAD6006_PATH_PARAM));
      }

      // Call SAAB
      final Response response;
      HashMap<String, String> queryParams = new HashMap<>();
      queryParams.put(IREXConnector.PARAM_ACTION, IAction.GERER_ECRIRE_PFS);

      // Add header
      AbstractInternalRESTConnector.getSpiritStarkRequestHeader().putSingle(IHttpHeadersConsts.X_OAUTH2_LOGIN, xOauth2Login_p);

      try
      {
        RESTRequest restRequest = new RESTRequestBuilder() //
            .httpMethod(HttpMethod.PUT) //
            .traceability(tracabilite_p) //
            .method(IMethodName.CONFIGURATION_PFS_COMPOSITE_GERER_ECRIRE_PFS) //
            .headers(AbstractInternalRESTConnector.getSpiritStarkRequestHeader()) //
            .path(configurationPfsCompositeUrl_p) //
            .queryParameter(queryParams) //
            .request(configurationPfsComposite_p) //
            .serializer(_jsonBuilder) //
            .build();
        response = _rexInstance.sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get response
      BasicResponse basicResponse = _rexInstance.getContentFromResponse(tracabilite_p, response, IMethodName.CONFIGURATION_PFS_COMPOSITE_GERER_ECRIRE_PFS, BasicResponse.class);

      // Retour OK
      return new ConnectorResponse<>(RetourConverter.convertFromJsonRetour(basicResponse.getRetour()), null);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  /**
   * GererSuppressionConfigurationPfs
   *
   * @param tracabilite_p
   * @param configurationPfsCompositeUrl_p
   * @param xOauth2Login_p
   * @param configurationPfs_p
   * @return
   */
  public ConnectorResponse<Retour, Nothing> configurationPfsCompositeGererSuppressionConfigurationPfs(Tracabilite tracabilite_p, String configurationPfsCompositeUrl_p, String xOauth2Login_p, ConfigurationPfs configurationPfs_p)
  {
    try
    {
      if (StringTools.isNullOrEmpty(configurationPfsCompositeUrl_p))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, REXConnector.PAD6006_PATH_PARAM));
      }

      // Call SAAB
      final Response response;
      HashMap<String, String> queryParams = new HashMap<>();
      queryParams.put(IREXConnector.PARAM_ACTION, IAction.GERER_SUPPRESSION_CONFIGURATION_PFS);

      // Add header
      AbstractInternalRESTConnector.getSpiritStarkRequestHeader().putSingle(IHttpHeadersConsts.X_OAUTH2_LOGIN, xOauth2Login_p);

      try
      {
        RESTRequest restRequest = new RESTRequestBuilder() //
            .httpMethod(HttpMethod.PUT) //
            .traceability(tracabilite_p) //
            .method(IMethodName.CONFIGURATION_PFS_COMPOSITE_GERER_SUPPRESSION_CONFIGURATION_PFS) //
            .headers(AbstractInternalRESTConnector.getSpiritStarkRequestHeader()) //
            .path(configurationPfsCompositeUrl_p) //
            .queryParameter(queryParams) //
            .request(new ConfigurationPfsComposite(configurationPfs_p)) //
            .serializer(_jsonBuilder) //
            .build();
        response = _rexInstance.sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get response
      BasicResponse basicResponse = _rexInstance.getContentFromResponse(tracabilite_p, response, IMethodName.CONFIGURATION_PFS_COMPOSITE_GERER_SUPPRESSION_CONFIGURATION_PFS, BasicResponse.class);

      // Retour OK
      return new ConnectorResponse<>(RetourConverter.convertFromJsonRetour(basicResponse.getRetour()), null);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  /**
   * GererSuppresionConfigurationPfs
   *
   * @param tracabilite_p
   * @param configurationPfsCompositeUrl_p
   * @param xOauth2Login_p
   * @param configurationPfsComposite_p
   * @return
   */
  public ConnectorResponse<Retour, Nothing> configurationPfsCompositeGererSuppressionPfs(Tracabilite tracabilite_p, String configurationPfsCompositeUrl_p, String xOauth2Login_p, ConfigurationPfsComposite configurationPfsComposite_p)
  {
    try
    {
      if (StringTools.isNullOrEmpty(configurationPfsCompositeUrl_p))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, REXConnector.PAD6006_PATH_PARAM));
      }

      // Call SAAB
      final Response response;
      HashMap<String, String> queryParams = new HashMap<>();
      queryParams.put(IREXConnector.PARAM_ACTION, IAction.GERER_SUPPRESSION_PFS);

      // Add header
      AbstractInternalRESTConnector.getSpiritStarkRequestHeader().putSingle(IHttpHeadersConsts.X_OAUTH2_LOGIN, xOauth2Login_p);

      try
      {
        RESTRequest restRequest = new RESTRequestBuilder() //
            .httpMethod(HttpMethod.PUT) //
            .traceability(tracabilite_p) //
            .method(IMethodName.CONFIGURATION_PFS_COMPOSITE_GERER_SUPPRESSION_PFS) //
            .headers(AbstractInternalRESTConnector.getSpiritStarkRequestHeader()) //
            .path(configurationPfsCompositeUrl_p) //
            .queryParameter(queryParams) //
            .request(configurationPfsComposite_p) //
            .serializer(_jsonBuilder) //
            .build();
        response = _rexInstance.sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get response
      BasicResponse basicResponse = _rexInstance.getContentFromResponse(tracabilite_p, response, IMethodName.CONFIGURATION_PFS_COMPOSITE_GERER_SUPPRESSION_PFS, BasicResponse.class);

      // Retour OK
      return new ConnectorResponse<>(RetourConverter.convertFromJsonRetour(basicResponse.getRetour()), null);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  /**
   * ConfigurationPfsComposite LireTous
   *
   * @param tracabilite_p
   * @param configurationPfsCompositeUrl_p
   * @return
   */
  public ConnectorResponse<Retour, List<ConfigurationPfsComposite>> configurationPfsCompositeLireTous(Tracabilite tracabilite_p, String configurationPfsCompositeUrl_p)
  {
    try
    {
      if (StringTools.isNullOrEmpty(configurationPfsCompositeUrl_p))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, REXConnector.PAD6006_PATH_PARAM));
      }

      // Build query parameters
      HashMap<String, String> queryParams = new HashMap<>();

      // Call SAAB
      final Response response;
      try
      {
        RESTRequest restRequest = new RESTRequestBuilder()//
            .httpMethod(HttpMethod.GET)//
            .traceability(tracabilite_p)//
            .method(IMethodName.CONFIGURATION_PFS_COMPOSITE_LIRE_TOUS)//
            .headers(AbstractInternalRESTConnector.getSpiritStarkRequestHeader())//
            .path(configurationPfsCompositeUrl_p)//
            .queryParameter(queryParams)//
            .build();
        response = _rexInstance.sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content to a JSON string
      GetConfigurationPfsCompositeResponse configurationPfsCompositeResponse = _rexInstance.getContentFromResponse(tracabilite_p, response, IMethodName.CONFIGURATION_PFS_COMPOSITE_LIRE_TOUS, GetConfigurationPfsCompositeResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(configurationPfsCompositeResponse.getRetour());
      List<ConfigurationPfsComposite> listeConfigurations = configurationPfsCompositeResponse.getListeConfigurationPfsComposite();

      return new ConnectorResponse<>(retour, listeConfigurations);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }
}
