/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.rex;

import com.bytel.ravel.services.connector.IConnector;

/**
 * Interface of IREXConnector that defines the BEAN_ID
 *
 * @author kbettenc
 * @version ($Revision$ $Date$)
 */
public interface IREXConnector extends IREX, IConnector
{
  /**
   * The id to retrieve the connector.
   */
  String BEAN_ID = "REXConnector"; //$NON-NLS-1$

  String PARAM_ACTION = "action"; //$NON-NLS-1$

}
