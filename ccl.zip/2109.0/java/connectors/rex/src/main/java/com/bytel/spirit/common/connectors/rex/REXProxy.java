/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.rex;

import java.util.List;
import java.util.Set;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.probes.AvgDoubleCollectorItem;
import com.bytel.ravel.common.probes.AvgFlowPerSecondCollector;
import com.bytel.ravel.common.probes.RavelProbeConfigurationManager;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.services.connector.BaseProxy;
import com.bytel.ravel.services.connector.ConnectorExecution;
import com.bytel.ravel.services.connector.ConnectorManager;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.connectors.rex.services.ConfigurationPfsCompositeProxy;
import com.bytel.spirit.common.shared.functional.types.json.notification.AbstractNotificationReseau;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.rex.AssociationPfiReconcialitionCommerciale;
import com.bytel.spirit.common.shared.saab.rex.BlocageEquipement;
import com.bytel.spirit.common.shared.saab.rex.ClientImpacte;
import com.bytel.spirit.common.shared.saab.rex.ComparaisonCommerciale;
import com.bytel.spirit.common.shared.saab.rex.ConfigurationPfs;
import com.bytel.spirit.common.shared.saab.rex.ConfigurationPfsComposite;
import com.bytel.spirit.common.shared.saab.rex.DecisionExploitation;
import com.bytel.spirit.common.shared.saab.rex.ErreurSpirit;
import com.bytel.spirit.common.shared.saab.rex.HistorisationEligibilite;
import com.bytel.spirit.common.shared.saab.rex.LigneDeTestEligDSL;
import com.bytel.spirit.common.shared.saab.rex.OperationVieReseau;
import com.bytel.spirit.common.shared.saab.rex.ReconciliationCommerciale;
import com.bytel.spirit.common.shared.saab.rex.RequeteExploitation;
import com.bytel.spirit.common.shared.saab.rex.TemplateRequeteExploitation;
import com.bytel.spirit.common.shared.saab.rex.TraitementDeMasse;
import com.bytel.spirit.common.shared.saab.rex.request.CreateComparaisonCommercialeCompositeRequest;
import com.bytel.spirit.common.shared.saab.rex.request.CreateErreurSpiritRequest;
import com.bytel.spirit.common.shared.saab.rex.request.CreateOrUpdateReconciliationCommercialeRequest;
import com.bytel.spirit.common.shared.saab.rex.request.ListeCleRechercheBlocageEquipementRequest;
import com.bytel.spirit.common.shared.saab.rex.request.ListeCleRechercheNotificationReseauRequest;
import com.bytel.spirit.common.shared.saab.rex.request.ListeCleRechercheOperationVieReseauRequest;
import com.bytel.spirit.common.shared.saab.rex.request.ManageReconciliationCommercialeEnMasseRequest;
import com.bytel.spirit.common.shared.saab.rex.request.UpdateBlocageEquipementRequest;
import com.bytel.spirit.common.shared.saab.rex.request.UpdateErreurSpiritRequest;
import com.bytel.spirit.common.shared.saab.rex.request.UpdateNotificationReseauStatutRequest;

/**
 * Proxy of {@link REXConnector}
 *
 * @author kbettenc
 * @version ($Revision$ $Date$)
 */
public final class REXProxy extends BaseProxy implements IREX
{
  /**
   * Proxy instance.
   */
  private static REXProxy _instance = new REXProxy();

  /**
   * @return The proxy instance.
   */
  public static REXProxy getInstance()
  {
    return _instance;
  }

  /**
   * For probe to count the amount of call to the decisionExploitationLireUn operation
   */
  AvgFlowPerSecondCollector _avg_decisionExploitationLireUn_call_counter;

  /**
   * For probe to count the execution time of call to the decisionExploitationLireUn operation
   */
  AvgDoubleCollectorItem _avg_decisionExploitationLireUn_ExecTime;

  /**
   * For probe to count the amount of call to the requeteExploitationLireUn operation
   */
  AvgFlowPerSecondCollector _avg_requeteExploitationLireUn_call_counter;

  /**
   * For probe to count the execution time of call to the requeteExploitationLireUn operation
   */
  AvgDoubleCollectorItem _avg_requeteExploitationLireUn_ExecTime;

  /**
   * For probe to count the amount of call to the emplateRequeteExploitationLireUn operation
   */
  AvgFlowPerSecondCollector _avg_templateRequeteExploitationLireUn_call_counter;

  /**
   * For probe to count the execution time of call to the emplateRequeteExploitationLireUn operation
   */
  AvgDoubleCollectorItem _avg_templateRequeteExploitationLireUn_ExecTime;

  /**
   * For probe to count the amount of call to the comparaisonCommercialeCompositeCreer operation
   */
  AvgFlowPerSecondCollector _avg_comparaisonCommercialeCompositeCreer_call_counter;

  /**
   * For probe to count the execution time of call to the comparaisonCommercialeCompositeCreer operation
   */
  AvgDoubleCollectorItem _avg_comparaisonCommercialeCompositeCreer_ExecTime;

  /**
   * For probe to count the amount of call to the erreurSpiritCreer operation
   */
  AvgFlowPerSecondCollector _avg_erreurSpiritCreer_call_counter;

  /**
   * For probe to count the execution time of call to the erreurSpiritCreer operation
   */
  AvgDoubleCollectorItem _avg_erreurSpiritCreer_ExecTime;

  /**
   * For probe to count the amount of call to the erreurSpiritModifierStatut operation
   */
  AvgFlowPerSecondCollector _avg_erreurSpiritModifierStatut_call_counter;

  /**
   * For probe to count the execution time of call to the erreurSpiritModifierStatut operation
   */
  AvgDoubleCollectorItem _avg_erreurSpiritModifierStatut_ExecTime;

  /**
   * For probe to count the amount of call to the erreurSpiritLireUn operation
   */
  AvgFlowPerSecondCollector _avg_erreurSpiritLireUn_call_counter;

  /**
   * For probe to count the execution time of call to the erreurSpiritLireUn operation
   */
  AvgDoubleCollectorItem _avg_erreurSpiritLireUn_ExecTime;

  /**
   * For probe to count the amount of call to the erreurSpiritLireTousSurPeriod operation
   */
  AvgFlowPerSecondCollector _avg_erreurSpiritLireTousSurPeriod_call_counter;

  /**
   * For probe to count the execution time of call to the erreurSpiritLireTousSurPeriod operation
   */
  AvgDoubleCollectorItem _avg_erreurSpiritLireTousSurPeriod_ExecTime;

  /**
   * For probe to count the amount of call to the erreurSpiritLireTousParStatutPeriod operation
   */
  AvgFlowPerSecondCollector _avg_erreurSpiritLireTousParStatutPeriod_call_counter;

  /**
   * For probe to count the execution time of call to the erreurSpiritLireTousParStatutPeriod operation
   */
  AvgDoubleCollectorItem _avg_erreurSpiritLireTousParStatutPeriod_ExecTime;

  /**
   * For probe to count the amount of call to the comparaisonCommercialeCompositeLireTousParIdCmd operation
   */
  AvgFlowPerSecondCollector _avg_comparaisonCommercialeCompositeLireTousParIdCmd_call_counter;

  /**
   * For probe to count the execution time of call to the pad6001ComparaisonCommercialeCreate operation
   */
  AvgDoubleCollectorItem _avg_comparaisonCommercialeCompositeLireTousParIdCmd_ExecTime;

  /**
   * For probe to count the amount of call to the reconciliationCommercialeCreer operation
   */
  AvgFlowPerSecondCollector _avg_reconciliationCommercialeAjouter_call_counter;

  /**
   * For probe to count the execution time of call to the reconciliationCommercialeCreer operation
   */
  AvgDoubleCollectorItem _avg_reconciliationCommercialeAjouter_ExecTime;

  /**
   * For probe to count the amount of call to the reconciliationCommercialeCreer operation
   */
  AvgFlowPerSecondCollector _avg_reconciliationCommercialeCreer_call_counter;

  /**
   * For probe to count the execution time of call to the reconciliationCommercialeCreer operation
   */
  AvgDoubleCollectorItem _avg_reconciliationCommercialeCreer_ExecTime;

  /**
   * For probe to count the amount of call to the reconciliationCommercialeLireTousParIdReconciliation operation
   */
  AvgFlowPerSecondCollector _avg_reconciliationCommercialeLireTousParIdReconciliation_call_counter;

  /**
   * For probe to count the execution time of call to the reconciliationCommercialeLireTousParIdReconciliation operation
   */
  AvgDoubleCollectorItem _avg_reconciliationCommercialeLireTousParIdReconciliation_ExecTime;

  /**
   * For probe to count the amount of call to the reconciliationCommercialeLireTousParClientOperateurNoCompte operation
   */
  AvgFlowPerSecondCollector _avg_reconciliationCommercialeLireTousParClientOperateurNoCompte_call_counter;

  /**
   * For probe to count the execution time of call to the reconciliationCommercialeLireTousParClientOperateurNoCompte
   * operation
   */
  AvgDoubleCollectorItem _avg_reconciliationCommercialeLireTousParClientOperateurNoCompte_ExecTime;

  /**
   * For probe to count the amount of call to the reconciliationCommercialeModifier operation
   */
  AvgFlowPerSecondCollector _avg_reconciliationCommercialeModifier_call_counter;

  /**
   * For probe to count the execution time of call to the reconciliationCommercialeModifier operation
   */
  AvgDoubleCollectorItem _avg_reconciliationCommercialeModifier_ExecTime;

  /**
   * For probe to count the amount of call to the reconciliationCommercialeEnMasseAcquitterUn operation
   */
  AvgFlowPerSecondCollector _avg_reconciliationCommercialeEnMasseAcquitterUn_call_counter;

  /**
   * For probe to count the execution time of call to the reconciliationCommercialeEnMasseAcquitterUn operation
   */
  AvgDoubleCollectorItem _avg_reconciliationCommercialeEnMasseAcquitterUn_ExecTime;

  /**
   * For probe to count the amount of call to the reconciliationCommercialeEnMasseLireTous operation
   */
  AvgFlowPerSecondCollector _avg_reconciliationCommercialeEnMasseLireTous_call_counter;

  /**
   * For probe to count the execution time of call to the reconciliationCommercialeEnMasseLireTous operation
   */
  AvgDoubleCollectorItem _avg_reconciliationCommercialeEnMasseLireTous_ExecTime;

  /**
   * For probe to count the amount of call to the traitementDeMasseLireTous operation
   */
  AvgFlowPerSecondCollector _avg_traitementDeMasseLireTous_call_counter;

  /**
   * For probe to count the execution time of call to the traitementDeMasseLireTous operation
   */
  AvgDoubleCollectorItem _avg_traitementDeMasseLireTous_ExecTime;

  /**
   * For probe to count the amount of call to the traitementDeMasseLireUn operation
   */
  AvgFlowPerSecondCollector _avg_traitementDeMasseLireUn_call_counter;

  /**
   * For probe to count the execution time of call to the traitementDeMasseLireUn operation
   */
  AvgDoubleCollectorItem _avg_traitementDeMasseLireUn_ExecTime;

  /**
   * For probe to count the amount of call to the traitementDeMasseLireUn operation
   */
  AvgFlowPerSecondCollector _avg_traitementDeMasseCreer_call_counter;

  /**
   * For probe to count the execution time of call to the traitementDeMasseLireUn operation
   */
  AvgDoubleCollectorItem _avg_traitementDeMasseCreer_ExecTime;

  /**
   * For probe to count the amount of call to the traitementDeMasseLireUn operation
   */
  AvgFlowPerSecondCollector _avg_traitementDeMasseModifierStatutEnCours_call_counter;

  /**
   * For probe to count the execution time of call to the traitementDeMasseLireUn operation
   */
  AvgDoubleCollectorItem _avg_traitementDeMasseModifierStatutEnCours_ExecTime;

  /**
   * For probe to count the amount of call to the notificationReseauCreer operation
   */
  AvgFlowPerSecondCollector _avg_notificationReseauCreer_call_counter;

  /**
   * For probe to count the execution time of call to the notificationReseauCreer operation
   */
  AvgDoubleCollectorItem _avg_notificationReseauCreer_ExecTime;

  /**
   * For probe to count the amount of call to the notificationReseauLireUn operation
   */
  AvgFlowPerSecondCollector _avg_notificationReseauLireUn_call_counter;

  /**
   * For probe to count the execution time of call to the notificationReseauLireUn operation
   */
  AvgDoubleCollectorItem _avg_notificationReseauLireUn_ExecTime;

  /**
   * For probe to count the amount of call to the notificationReseauModifierStatut operation
   */
  AvgFlowPerSecondCollector _avg_notificationReseauModifierStatut_call_counter;

  /**
   * For probe to count the execution time of call to the notificationReseauModifierStatut operation
   */
  AvgDoubleCollectorItem _avg_notificationReseauModifierStatut_ExecTime;

  /**
   * For probe to count the amount of call to the cleRechercheNotificationReseau operation
   */
  AvgFlowPerSecondCollector _avg_cleRechercheNotificationReseau_call_counter;

  /**
   * For probe to count the execution time of call to the cleRechercheNotificationReseau operation
   */
  AvgDoubleCollectorItem _avg_cleRechercheNotificationReseau_ExecTime;

  /**
   * For probe to count the amount of call to the cleRechercheBlocageEquipementCreerListe operation
   */
  AvgFlowPerSecondCollector _avg_cleRechercheBlocageEquipementCreerListe_call_counter;

  /**
   * For probe to count the execution time of call to the cleRechercheBlocageEquipementCreerListe operation
   */
  AvgDoubleCollectorItem _avg_cleRechercheBlocageEquipementCreerListe_ExecTime;

  /**
   * For probe to count the amount of call to the historisationEligibiliteCreer operation
   */
  AvgFlowPerSecondCollector _avg_historisationEligibiliteCreer_call_counter;

  /**
   * For probe to count the execution time of call to the historisationEligibiliteCreer operation
   */
  AvgDoubleCollectorItem _avg_historisationEligibiliteCreer_ExecTime;

  /**
   * For probe to count the amount of call to the cleRechercheOperationVieReseauCreerListe operation
   */
  AvgFlowPerSecondCollector _avg_cleRechercheOperationVieReseauCreerListe_call_counter;

  /**
   * For probe to count the execution time of call to the cleRechercheOperationVieReseauCreerListe operation
   */
  AvgDoubleCollectorItem _avg_cleRechercheOperationVieReseauCreerListe_ExecTime;

  /**
   * For probe to count the amount of call to the operationVieReseauCreer operation
   */
  AvgFlowPerSecondCollector _avg_operationVieReseauCreer_call_counter;

  /**
   * For probe to count the execution time of call to the operationVieReseauCreer operation
   */
  AvgDoubleCollectorItem _avg_operationVieReseauCreer_ExecTime;
  /**
   * For probe to count the amount of call to the blocageEquipementCreer operation
   */
  AvgFlowPerSecondCollector _avg_blocageEquipementCreer_call_counter;

  /**
   * For probe to count the execution time of call to the blocageEquipementCreer operation
   */
  AvgDoubleCollectorItem _avg_blocageEquipementCreer_ExecTime;

  /**
   * For probe to count the amount of call to the operationVieReseauLireUn operation
   */
  AvgFlowPerSecondCollector _avg_operationVieReseauLireUn_call_counter;

  /**
   * For probe to count the execution time of call to the operationVieReseauLireUn operation
   */
  AvgDoubleCollectorItem _avg_operationVieReseauLireUn_ExecTime;

  /**
   * For probe to count the amount of call to the operationVieReseauModifierStatut operation
   */
  AvgFlowPerSecondCollector _avg_operationVieReseauModifierStatut_call_counter;

  /**
   * For probe to count the execution time of call to the operationVieReseauModifierStatut operation
   */
  AvgDoubleCollectorItem _avg_operationVieReseauModifierStatut_ExecTime;

  /**
   * For probe to count the amount of call to the operationVieReseauModifierListeClientImpacte operation
   */
  AvgFlowPerSecondCollector _avg_operationVieReseauModifierListeClientImpacte_call_counter;

  /**
   * For probe to count the execution time of call to the operationVieReseauModifierListeClientImpacte operation
   */
  AvgDoubleCollectorItem _avg_operationVieReseauModifierListeClientImpacte_ExecTime;

  /**
   * For probe to count the amount of call to the operationVieReseauCompositeLireTousParCleRecherche operation
   */
  AvgFlowPerSecondCollector _avg_operationVieReseauCompositeLireTousParCleRecherche_call_counter;

  /**
   * For probe to count the execution time of call to the operationVieReseauCompositeLireTousParCleRecherche operation
   */
  AvgDoubleCollectorItem _avg_operationVieReseauCompositeLireTousParCleRecherche_ExecTime;

  /**
   * For probe to count the amount of call to the blocageEquipementLireUn operation
   */
  AvgFlowPerSecondCollector _avg_blocageEquipementLireUn_call_counter;

  /**
   * For probe to count the execution time of call to the blocageEquipementLireUn operation
   */
  AvgDoubleCollectorItem _avg_blocageEquipementLireUn_ExecTime;

  /**
   * For probe to count the amount of call to the blocageEquipementSupprimer operation
   */
  AvgFlowPerSecondCollector _avg_blocageEquipementSupprimer_call_counter;

  /**
   * For probe to count the execution time of call to the blocageEquipementSupprimer operation
   */
  AvgDoubleCollectorItem _avg_blocageEquipementSupprimer_ExecTime;
  /**
   * For probe to count the amount of call to the blocageEquipementModifier operation
   */
  AvgFlowPerSecondCollector _avg_blocageEquipementModifier_call_counter;

  /**
   * For probe to count the execution time of call to the blocageEquipementModifier operation
   */
  AvgDoubleCollectorItem _avg_blocageEquipementModifier_ExecTime;

  /** ConfigurationPfsCompositeService Proxy (create this service to avoid sonar 3000 line error for REXProxy) */
  ConfigurationPfsCompositeProxy _configurationPfsCompositeProxy;

  /**
   * For probe to count the amount of calls to the ligneDeTestEligDSLLireUn operation
   */
  AvgFlowPerSecondCollector _avg_ligneDeTestEligDSLLireUn_call_counter;

  /**
   * For probe to count the execution time of call to the ligneDeTestEligDSLLireUn operation
   */
  AvgDoubleCollectorItem _avg_ligneDeTestEligDSLLireUn_ExecTime;

  /**
   * For probe to count the amount of calls to the ligneDeTestEligDSLLireTous operation
   */
  AvgFlowPerSecondCollector _avg_ligneDeTestEligDSLLireTous_call_counter;

  /**
   * For probe to count the execution time of call to the ligneDeTestEligDSLLireTous operation
   */
  AvgDoubleCollectorItem _avg_ligneDeTestEligDSLLireTous_ExecTime;

  /**
   * For probe to count the amount of calls to the ligneDeTestEligDSLCreer operation
   */
  AvgFlowPerSecondCollector _avg_ligneDeTestEligDSLCreer_call_counter;

  /**
   * For probe to count the execution time of call to the ligneDeTestEligDSLCreer operation
   */
  AvgDoubleCollectorItem _avg_ligneDeTestEligDSLCreer_ExecTime;

  /**
   * For probe to count the amount of calls to the ligneDeTestEligDSLModifier operation
   */
  AvgFlowPerSecondCollector _avg_ligneDeTestEligDSLModifier_call_counter;

  /**
   * For probe to count the execution time of call to the ligneDeTestEligDSLModifier operation
   */
  AvgDoubleCollectorItem _avg_ligneDeTestEligDSLModifier_ExecTime;

  /**
   * For probe to count the amount of calls to the ligneDeTestEligDSLSupprimer operation
   */
  AvgFlowPerSecondCollector _avg_ligneDeTestEligDSLSupprimer_call_counter;

  /**
   * For probe to count the execution time of call to the ligneDeTestEligDSLSupprimer operation
   */
  AvgDoubleCollectorItem _avg_ligneDeTestEligDSLSupprimer_ExecTime;

  /**
   * Constructor
   */
  private REXProxy()
  {
    _avg_comparaisonCommercialeCompositeCreer_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_comparaisonCommercialeCompositeCreer_call_counter", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_comparaisonCommercialeCompositeCreer_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_comparaisonCommercialeCompositeCreer_ExecTime", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_comparaisonCommercialeCompositeLireTousParIdCmd_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_comparaisonCommercialeCompositeLireTousParIdCmd_call_counter", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_comparaisonCommercialeCompositeLireTousParIdCmd_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_comparaisonCommercialeCompositeLireTousParIdCmd_ExecTime", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$

    _avg_reconciliationCommercialeAjouter_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_reconciliationCommercialeAjouter_call_counter", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_reconciliationCommercialeAjouter_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_reconciliationCommercialeAjouter_ExecTime", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_reconciliationCommercialeCreer_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_reconciliationCommercialeCreer_call_counter", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_reconciliationCommercialeCreer_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_reconciliationCommercialeCreer_ExecTime", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_reconciliationCommercialeLireTousParIdReconciliation_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_reconciliationCommercialeLireTousParIdReconciliation_call_counter", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_reconciliationCommercialeLireTousParIdReconciliation_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_reconciliationCommercialeLireTousParIdReconciliation_ExecTime", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_reconciliationCommercialeLireTousParClientOperateurNoCompte_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_reconciliationCommercialeLireTousParClientOperateurNoCompte_call_counter", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_reconciliationCommercialeLireTousParClientOperateurNoCompte_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_reconciliationCommercialeLireTousParClientOperateurNoCompte_ExecTime", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_reconciliationCommercialeModifier_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_reconciliationCommercialeModifier_call_counter", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_reconciliationCommercialeModifier_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_reconciliationCommercialeModifier_ExecTime", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$

    _avg_erreurSpiritCreer_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_erreurSpiritCreer_call_counter", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_erreurSpiritCreer_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_erreurSpiritCreer_ExecTime", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_erreurSpiritModifierStatut_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_erreurSpiritModifierStatut_call_counter", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_erreurSpiritModifierStatut_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_erreurSpiritModifierStatut_ExecTime", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_erreurSpiritLireUn_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_erreurSpiritLireUn_call_counter", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_erreurSpiritLireUn_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_erreurSpiritLireUn_ExecTime", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_erreurSpiritLireTousParStatutPeriod_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_erreurSpiritLireTousParStatutPeriod_call_counter", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_erreurSpiritLireTousParStatutPeriod_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_erreurSpiritLireTousParStatutPeriod_ExecTime", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_erreurSpiritLireTousSurPeriod_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_erreurSpiritLireTousSurPeriod_call_counter", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_erreurSpiritLireTousSurPeriod_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_erreurSpiritLireTousSurPeriod_ExecTime", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$

    _avg_reconciliationCommercialeEnMasseAcquitterUn_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_reconciliationCommercialeEnMasseAcquitterUn_call_counter", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_reconciliationCommercialeEnMasseAcquitterUn_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_reconciliationCommercialeEnMasseAcquitterUn_ExecTime", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_reconciliationCommercialeEnMasseLireTous_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_reconciliationCommercialeEnMasseLireTous_call_counter", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_reconciliationCommercialeEnMasseLireTous_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_reconciliationCommercialeEnMasseLireTous_ExecTime", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$

    _avg_traitementDeMasseLireTous_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_traitementDeMasseLireTous_call_counter", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_traitementDeMasseLireTous_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_traitementDeMasseLireTous_ExecTime", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_traitementDeMasseLireUn_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_traitementDeMasseLireUn_call_counter", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_traitementDeMasseLireUn_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_traitementDeMasseLireUn_ExecTime", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_traitementDeMasseCreer_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_traitementDeMasseCreer_call_counter", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_traitementDeMasseCreer_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_traitementDeMasseCreer_ExecTime", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_traitementDeMasseModifierStatutEnCours_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_traitementDeMasseModifierStatutEnCours_call_counter", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_traitementDeMasseModifierStatutEnCours_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_traitementDeMasseModifierStatutEnCours_ExecTime", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$

    _avg_requeteExploitationLireUn_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_requeteExploitationLireUn_call_counter", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_requeteExploitationLireUn_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_requeteExploitationLireUn_ExecTime", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_decisionExploitationLireUn_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_decisionExploitationLireUn_call_counter", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_decisionExploitationLireUn_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_decisionExploitationLireUn_ExecTime", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_templateRequeteExploitationLireUn_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_templateRequeteExploitationLireUn_call_counter", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_templateRequeteExploitationLireUn_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_templateRequeteExploitationLireUn_ExecTime", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$

    _avg_notificationReseauCreer_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_notificationReseauCreer_call_counter", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_notificationReseauCreer_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_notificationReseauCreer_ExecTime", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_notificationReseauLireUn_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_notificationReseauLireUn_call_counter", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_notificationReseauLireUn_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_notificationReseauLireUn_ExecTime", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_notificationReseauModifierStatut_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_notificationReseauModifierStatut_call_counter", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_notificationReseauModifierStatut_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_notificationReseauModifierStatut_ExecTime", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_cleRechercheNotificationReseau_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_cleRechercheNotificationReseau_call_counter", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_cleRechercheNotificationReseau_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_cleRechercheNotificationReseau_ExecTime", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$

    _avg_historisationEligibiliteCreer_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_historisationEligibiliteCreer_call_counter", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_historisationEligibiliteCreer_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_historisationEligibiliteCreer_ExecTime", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$

    _avg_cleRechercheOperationVieReseauCreerListe_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_cleRechercheOperationVieReseauCreerListe_call_counter", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_cleRechercheOperationVieReseauCreerListe_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_cleRechercheOperationVieReseauCreerListe_ExecTime", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$

    _avg_operationVieReseauCreer_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_operationVieReseauCreer_call_counter", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_operationVieReseauCreer_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_operationVieReseauCreer_ExecTime", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$

    _avg_operationVieReseauLireUn_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_operationVieReseauLireUn_call_counter", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_operationVieReseauLireUn_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_operationVieReseauLireUn_ExecTime", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_operationVieReseauCompositeLireTousParCleRecherche_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_operationVieReseauCompositeLireTousParCleRecherche_call_counter", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_operationVieReseauCompositeLireTousParCleRecherche_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_operationVieReseauCompositeLireTousParCleRecherche_ExecTime", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_cleRechercheBlocageEquipementCreerListe_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_cleRechercheBlocageEquipementCreerListe_call_counter", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_cleRechercheBlocageEquipementCreerListe_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_cleRechercheBlocageEquipementCreerListe_ExecTime", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_blocageEquipementLireUn_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_blocageEquipementLireUn_call_counter", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_blocageEquipementLireUn_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_blocageEquipementLireUn_ExecTime", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_blocageEquipementCreer_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_blocageEquipementCreer_call_counter", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_blocageEquipementCreer_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_blocageEquipementCreer_ExecTime", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_blocageEquipementSupprimer_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_blocageEquipementSupprimer_call_counter", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_blocageEquipementSupprimer_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_blocageEquipementSupprimer_ExecTime", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_blocageEquipementModifier_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_blocageEquipementModifier_call_counter", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_blocageEquipementModifier_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_blocageEquipementModifier_ExecTime", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_operationVieReseauModifierStatut_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_operationVieReseauModifierStatut_call_counter", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_operationVieReseauModifierStatut_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_operationVieReseauModifierStatut_ExecTime", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_operationVieReseauModifierListeClientImpacte_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_operationVieReseauModifierListeClientImpacte_call_counter", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_operationVieReseauModifierListeClientImpacte_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_operationVieReseauModifierListeClientImpacte_ExecTime", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$

    _avg_ligneDeTestEligDSLLireUn_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_ligneDeTestEligDSLLireUn_call_counter", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_ligneDeTestEligDSLLireUn_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_ligneDeTestEligDSLLireUn_ExecTime", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_ligneDeTestEligDSLLireTous_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_ligneDeTestEligDSLLireTous_call_counter", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_ligneDeTestEligDSLLireTous_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_ligneDeTestEligDSLLireTous_ExecTime", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_ligneDeTestEligDSLCreer_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_ligneDeTestEligDSLCreer_call_counter", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_ligneDeTestEligDSLCreer_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_ligneDeTestEligDSLCreer_ExecTime", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_ligneDeTestEligDSLModifier_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_ligneDeTestEligDSLModifier_call_counter", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_ligneDeTestEligDSLModifier_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_ligneDeTestEligDSLModifier_ExecTime", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_ligneDeTestEligDSLSupprimer_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_ligneDeTestEligDSLSupprimer_call_counter", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_ligneDeTestEligDSLSupprimer_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_ligneDeTestEligDSLSupprimer_ExecTime", "REXProxy"); //$NON-NLS-1$//$NON-NLS-2$

    // Load proxy services
    _configurationPfsCompositeProxy = new ConfigurationPfsCompositeProxy(IREXConnector.BEAN_ID);
  }

  @Override
  public ConnectorResponse<Retour, Nothing> blocageEquipementCreer(Tracabilite tracabilite_p, BlocageEquipement blocageEquipement_p) throws RavelException
  {

    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IREXConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        IREXConnector irexConnector = null;
        try
        {
          irexConnector = (IREXConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          // Retour NOK
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_blocageEquipementCreer_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return irexConnector.blocageEquipementCreer(tracabilite_p, blocageEquipement_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_blocageEquipementCreer_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, BlocageEquipement> blocageEquipementLireUn(Tracabilite tracabilite_p, String idBlocageEquipement_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, BlocageEquipement>>(IREXConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, BlocageEquipement> run() throws RavelException
      {
        IREXConnector irexConnector = null;
        try
        {
          irexConnector = (IREXConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          // Retour NOK
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_blocageEquipementLireUn_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return irexConnector.blocageEquipementLireUn(tracabilite_p, idBlocageEquipement_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_blocageEquipementLireUn_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> blocageEquipementModifier(Tracabilite tracabilite_p, UpdateBlocageEquipementRequest updateBlocageEquipementRequest_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IREXConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        IREXConnector irexConnector = null;
        try
        {
          irexConnector = (IREXConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          // Retour NOK
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_blocageEquipementModifier_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return irexConnector.blocageEquipementModifier(tracabilite_p, updateBlocageEquipementRequest_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_blocageEquipementModifier_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> blocageEquipementSupprimer(Tracabilite tracabilite_p, String idBlocageEquipement_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IREXConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        IREXConnector irexConnector = null;
        try
        {
          irexConnector = (IREXConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          // Retour NOK
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_blocageEquipementSupprimer_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return irexConnector.blocageEquipementSupprimer(tracabilite_p, idBlocageEquipement_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_blocageEquipementSupprimer_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> cleRechercheBlocageEquipementCreerListe(Tracabilite tracabilite_p, ListeCleRechercheBlocageEquipementRequest listeCleRechercheBlocageEquipementRequest_p) throws RavelException
  {

    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IREXConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        IREXConnector irexConnector = null;
        try
        {
          irexConnector = (IREXConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          // Retour NOK
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_cleRechercheBlocageEquipementCreerListe_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return irexConnector.cleRechercheBlocageEquipementCreerListe(tracabilite_p, listeCleRechercheBlocageEquipementRequest_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_cleRechercheBlocageEquipementCreerListe_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> cleRechercheNotificationReseau(Tracabilite tracabilite_p, ListeCleRechercheNotificationReseauRequest listeCleRechercheNotificationReseauRequest_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IREXConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        IREXConnector irexConnector = null;
        try
        {
          irexConnector = (IREXConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          // Retour NOK
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_cleRechercheNotificationReseau_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return irexConnector.cleRechercheNotificationReseau(tracabilite_p, listeCleRechercheNotificationReseauRequest_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_cleRechercheNotificationReseau_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> cleRechercheOperationVieReseauCreerListe(Tracabilite tracabilite_p, ListeCleRechercheOperationVieReseauRequest listeCleRechercheOperationVieReseauRequest_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IREXConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        IREXConnector irexConnector = null;
        try
        {
          irexConnector = (IREXConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          // Retour NOK
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_cleRechercheOperationVieReseauCreerListe_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return irexConnector.cleRechercheOperationVieReseauCreerListe(tracabilite_p, listeCleRechercheOperationVieReseauRequest_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_cleRechercheOperationVieReseauCreerListe_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> comparaisonCommercialeCompositeCreer(Tracabilite tracabilite_p, CreateComparaisonCommercialeCompositeRequest comparaisonCommerciale_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IREXConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        IREXConnector irexConnector = null;
        try
        {
          irexConnector = (IREXConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          // Retour NOK
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_comparaisonCommercialeCompositeCreer_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return irexConnector.comparaisonCommercialeCompositeCreer(tracabilite_p, comparaisonCommerciale_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_comparaisonCommercialeCompositeCreer_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, List<ComparaisonCommerciale>> comparaisonCommercialeCompositeLireTousParIdCmd(Tracabilite tracabilite_p, String idCmd_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, List<ComparaisonCommerciale>>>(IREXConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, List<ComparaisonCommerciale>> run() throws RavelException
      {
        IREXConnector irexConnector = null;
        try
        {
          irexConnector = (IREXConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          // Retour NOK
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_comparaisonCommercialeCompositeLireTousParIdCmd_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return irexConnector.comparaisonCommercialeCompositeLireTousParIdCmd(tracabilite_p, idCmd_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_comparaisonCommercialeCompositeLireTousParIdCmd_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> configurationPfsCompositeGererEcrireConfigurationPfs(Tracabilite tracabilite_p, String xOauth2Login_p, ConfigurationPfs configurationPfs_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IREXConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        return _configurationPfsCompositeProxy.configurationPfsCompositeGererEcrireConfigurationPfs(tracabilite_p, xOauth2Login_p, configurationPfs_p);
      }
    });
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public ConnectorResponse<Retour, Nothing> configurationPfsCompositeGererEcrirePfs(Tracabilite tracabilite_p, String xOauth2Login_p, ConfigurationPfsComposite configurationPfsComposite_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IREXConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        return _configurationPfsCompositeProxy.configurationPfsCompositeGererEcrirePfs(tracabilite_p, xOauth2Login_p, configurationPfsComposite_p);
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> configurationPfsCompositeGererSuppressionConfigurationPfs(Tracabilite tracabilite_p, String xOauth2Login_p, ConfigurationPfs configurationPfs_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IREXConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        return _configurationPfsCompositeProxy.configurationPfsCompositeGererSuppressionConfigurationPfs(tracabilite_p, xOauth2Login_p, configurationPfs_p);
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> configurationPfsCompositeGererSuppressionPfs(Tracabilite tracabilite_p, String xOauth2Login_p, ConfigurationPfsComposite configurationPfsComposite_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IREXConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        return _configurationPfsCompositeProxy.configurationPfsCompositeGererSuppressionPfs(tracabilite_p, xOauth2Login_p, configurationPfsComposite_p);
      }
    });
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public ConnectorResponse<Retour, List<ConfigurationPfsComposite>> configurationPfsCompositeLireTous(Tracabilite tracabilite_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, List<ConfigurationPfsComposite>>>(IREXConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, List<ConfigurationPfsComposite>> run() throws RavelException
      {
        return _configurationPfsCompositeProxy.configurationPfsCompositeLireTous(tracabilite_p);
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, DecisionExploitation> decisionExploitationLireUn(Tracabilite tracabilite_p, String nom_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, DecisionExploitation>>(IREXConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, DecisionExploitation> run() throws RavelException
      {
        IREXConnector irexConnector = null;
        try
        {
          irexConnector = (IREXConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          // Retour NOK
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_decisionExploitationLireUn_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return irexConnector.decisionExploitationLireUn(tracabilite_p, nom_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_decisionExploitationLireUn_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> erreurSpiritCreer(Tracabilite tracabilite_p, CreateErreurSpiritRequest erreurSpirit_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IREXConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        IREXConnector irexConnector = null;
        try
        {
          irexConnector = (IREXConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          // Retour NOK
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_erreurSpiritCreer_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return irexConnector.erreurSpiritCreer(tracabilite_p, erreurSpirit_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_erreurSpiritCreer_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, List<ErreurSpirit>> erreurSpiritLireTousParStatutPeriod(Tracabilite tracabilite_p, String statut_p, String dateDeb_p, String dateFin_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, List<ErreurSpirit>>>(IREXConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, List<ErreurSpirit>> run() throws RavelException
      {
        IREXConnector irexConnector = null;
        try
        {
          irexConnector = (IREXConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          // Retour NOK
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_erreurSpiritLireTousParStatutPeriod_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return irexConnector.erreurSpiritLireTousParStatutPeriod(tracabilite_p, statut_p, dateDeb_p, dateFin_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_erreurSpiritLireTousParStatutPeriod_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, List<ErreurSpirit>> erreurSpiritLireTousSurPeriod(Tracabilite tracabilite_p, String dateDeb_p, String dateFin_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, List<ErreurSpirit>>>(IREXConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, List<ErreurSpirit>> run() throws RavelException
      {
        IREXConnector irexConnector = null;
        try
        {
          irexConnector = (IREXConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          // Retour NOK
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_erreurSpiritLireTousSurPeriod_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return irexConnector.erreurSpiritLireTousSurPeriod(tracabilite_p, dateDeb_p, dateFin_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_erreurSpiritLireTousSurPeriod_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, List<ErreurSpirit>> erreurSpiritLireUn(Tracabilite tracabilite_p, String idErreurSpirit_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, List<ErreurSpirit>>>(IREXConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, List<ErreurSpirit>> run() throws RavelException
      {
        IREXConnector irexConnector = null;
        try
        {
          irexConnector = (IREXConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          // Retour NOK
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_erreurSpiritLireUn_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return irexConnector.erreurSpiritLireUn(tracabilite_p, idErreurSpirit_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_erreurSpiritLireUn_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> erreurSpiritModifierStatut(Tracabilite tracabilite_p, UpdateErreurSpiritRequest updateErreurSpirit_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IREXConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        IREXConnector irexConnector = null;
        try
        {
          irexConnector = (IREXConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          // Retour NOK
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_erreurSpiritModifierStatut_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return irexConnector.erreurSpiritModifierStatut(tracabilite_p, updateErreurSpirit_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_erreurSpiritModifierStatut_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> historisationEligibiliteCreer(Tracabilite tracabilite_p, HistorisationEligibilite historisationEligibilite_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IREXConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        IREXConnector irexConnector = null;
        try
        {
          irexConnector = (IREXConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          // Retour NOK
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_historisationEligibiliteCreer_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return irexConnector.historisationEligibiliteCreer(tracabilite_p, historisationEligibilite_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_historisationEligibiliteCreer_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> notificationReseauCreer(Tracabilite tracabilite_p, AbstractNotificationReseau notificationReseau_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IREXConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        IREXConnector irexConnector = null;
        try
        {
          irexConnector = (IREXConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          // Retour NOK
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_notificationReseauCreer_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return irexConnector.notificationReseauCreer(tracabilite_p, notificationReseau_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_notificationReseauCreer_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, AbstractNotificationReseau> notificationReseauLireUn(Tracabilite tracabilite_p, String idNotificationReseau_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, AbstractNotificationReseau>>(IREXConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, AbstractNotificationReseau> run() throws RavelException
      {
        IREXConnector irexConnector = null;
        try
        {
          irexConnector = (IREXConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          // Retour NOK
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_notificationReseauLireUn_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return irexConnector.notificationReseauLireUn(tracabilite_p, idNotificationReseau_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_notificationReseauLireUn_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> notificationReseauModifierStatut(Tracabilite tracabilite_p, UpdateNotificationReseauStatutRequest updateNotificationReseauStatutRequest_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IREXConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        IREXConnector irexConnector = null;
        try
        {
          irexConnector = (IREXConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          // Retour NOK
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_notificationReseauModifierStatut_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return irexConnector.notificationReseauModifierStatut(tracabilite_p, updateNotificationReseauStatutRequest_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_notificationReseauModifierStatut_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, List<OperationVieReseau>> operationVieReseauCompositeLireTousParCleRecherche(Tracabilite tracabilite_p, String typeOperationVieReseau_p, String typeCle_p, String valeurCle_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, List<OperationVieReseau>>>(IREXConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, List<OperationVieReseau>> run() throws RavelException
      {
        IREXConnector irexConnector = null;
        try
        {
          irexConnector = (IREXConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          // Retour NOK
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_operationVieReseauCompositeLireTousParCleRecherche_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return irexConnector.operationVieReseauCompositeLireTousParCleRecherche(tracabilite_p, typeOperationVieReseau_p, typeCle_p, valeurCle_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_operationVieReseauCompositeLireTousParCleRecherche_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> operationVieReseauCreer(Tracabilite tracabilite_p, OperationVieReseau operationVieReseau_p) throws RavelException
  {

    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IREXConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        IREXConnector irexConnector = null;
        try
        {
          irexConnector = (IREXConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          // Retour NOK
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_operationVieReseauCreer_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return irexConnector.operationVieReseauCreer(tracabilite_p, operationVieReseau_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_operationVieReseauCreer_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, OperationVieReseau> operationVieReseauLireUn(Tracabilite tracabilite_p, String idOperationVieReseau_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, OperationVieReseau>>(IREXConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, OperationVieReseau> run() throws RavelException
      {
        IREXConnector irexConnector = null;
        try
        {
          irexConnector = (IREXConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          // Retour NOK
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_operationVieReseauLireUn_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return irexConnector.operationVieReseauLireUn(tracabilite_p, idOperationVieReseau_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_operationVieReseauLireUn_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> operationVieReseauModifierListeClientImpacte(Tracabilite tracabilite_p, String idOperationVieReseau_p, Set<ClientImpacte> clientImpactes_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IREXConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        IREXConnector irexConnector = null;
        try
        {
          irexConnector = (IREXConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          // Retour NOK
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_operationVieReseauModifierListeClientImpacte_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return irexConnector.operationVieReseauModifierListeClientImpacte(tracabilite_p, idOperationVieReseau_p, clientImpactes_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_operationVieReseauModifierListeClientImpacte_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> operationVieReseauModifierStatut(Tracabilite tracabilite_p, String idOperationVieReseau_p, String statut_p, String codeErreur_p, String libelleErreur_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IREXConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        IREXConnector irexConnector = null;
        try
        {
          irexConnector = (IREXConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          // Retour NOK
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_operationVieReseauModifierStatut_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return irexConnector.operationVieReseauModifierStatut(tracabilite_p, idOperationVieReseau_p, statut_p, codeErreur_p, libelleErreur_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_operationVieReseauModifierStatut_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> reconciliationCommercialeCreer(Tracabilite tracabilite_p, CreateOrUpdateReconciliationCommercialeRequest reconciliationCommerciale_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IREXConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        IREXConnector irexConnector = null;
        try
        {
          irexConnector = (IREXConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          // Retour NOK
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_reconciliationCommercialeCreer_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return irexConnector.reconciliationCommercialeCreer(tracabilite_p, reconciliationCommerciale_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_reconciliationCommercialeCreer_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> reconciliationCommercialeEnMasseAcquitterUn(Tracabilite tracabilite_p, ManageReconciliationCommercialeEnMasseRequest manageReconciliationCommercialeEnMasseRequest_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IREXConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        IREXConnector irexConnector = null;
        try
        {
          irexConnector = (IREXConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          // Retour NOK
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_reconciliationCommercialeEnMasseAcquitterUn_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return irexConnector.reconciliationCommercialeEnMasseAcquitterUn(tracabilite_p, manageReconciliationCommercialeEnMasseRequest_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_reconciliationCommercialeEnMasseAcquitterUn_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, List<AssociationPfiReconcialitionCommerciale>> reconciliationCommercialeEnMasseAjouter(Tracabilite tracabilite_p, String idTraitementDeMasse_p, List<String> listeNoCompte_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, List<AssociationPfiReconcialitionCommerciale>>>(IREXConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, List<AssociationPfiReconcialitionCommerciale>> run() throws RavelException
      {
        IREXConnector irexConnector = null;
        try
        {
          irexConnector = (IREXConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          // Retour NOK
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_reconciliationCommercialeAjouter_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return irexConnector.reconciliationCommercialeEnMasseAjouter(tracabilite_p, idTraitementDeMasse_p, listeNoCompte_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_reconciliationCommercialeAjouter_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, List<ReconciliationCommerciale>> reconciliationCommercialeEnMasseLireTous(Tracabilite tracabilite_p, String idTraitementMasse_p, String statut_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, List<ReconciliationCommerciale>>>(IREXConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, List<ReconciliationCommerciale>> run() throws RavelException
      {
        IREXConnector irexConnector = null;
        try
        {
          irexConnector = (IREXConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          // Retour NOK
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_reconciliationCommercialeEnMasseLireTous_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return irexConnector.reconciliationCommercialeEnMasseLireTous(tracabilite_p, idTraitementMasse_p, statut_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_reconciliationCommercialeEnMasseLireTous_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, List<ReconciliationCommerciale>> reconciliationCommercialeLireTousParClientOperateurNoCompte(Tracabilite tracabilite_p, String clientOperateur_p, String noCompte_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, List<ReconciliationCommerciale>>>(IREXConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, List<ReconciliationCommerciale>> run() throws RavelException
      {
        IREXConnector irexConnector = null;
        try
        {
          irexConnector = (IREXConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          // Retour NOK
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_reconciliationCommercialeLireTousParClientOperateurNoCompte_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return irexConnector.reconciliationCommercialeLireTousParClientOperateurNoCompte(tracabilite_p, clientOperateur_p, noCompte_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_reconciliationCommercialeLireTousParClientOperateurNoCompte_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, List<ReconciliationCommerciale>> reconciliationCommercialeLireTousParIdReconciliation(Tracabilite tracabilite_p, String idReconciliation_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, List<ReconciliationCommerciale>>>(IREXConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, List<ReconciliationCommerciale>> run() throws RavelException
      {
        IREXConnector irexConnector = null;
        try
        {
          irexConnector = (IREXConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          // Retour NOK
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_reconciliationCommercialeLireTousParIdReconciliation_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return irexConnector.reconciliationCommercialeLireTousParIdReconciliation(tracabilite_p, idReconciliation_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_reconciliationCommercialeLireTousParIdReconciliation_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> reconciliationCommercialeModifier(Tracabilite tracabilite_p, CreateOrUpdateReconciliationCommercialeRequest reconciliationCommerciale_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IREXConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        IREXConnector irexConnector = null;
        try
        {
          irexConnector = (IREXConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          // Retour NOK
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_reconciliationCommercialeModifier_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return irexConnector.reconciliationCommercialeModifier(tracabilite_p, reconciliationCommerciale_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_reconciliationCommercialeModifier_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, RequeteExploitation> requeteExploitationLireUn(Tracabilite tracabilite_p, String nom_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, RequeteExploitation>>(IREXConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, RequeteExploitation> run() throws RavelException
      {
        IREXConnector irexConnector = null;
        try
        {
          irexConnector = (IREXConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          // Retour NOK
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_requeteExploitationLireUn_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return irexConnector.requeteExploitationLireUn(tracabilite_p, nom_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_requeteExploitationLireUn_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, TemplateRequeteExploitation> templateRequeteExploitationLireUn(Tracabilite tracabilite_p, String nom_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, TemplateRequeteExploitation>>(IREXConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, TemplateRequeteExploitation> run() throws RavelException
      {
        IREXConnector irexConnector = null;
        try
        {
          irexConnector = (IREXConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          // Retour NOK
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_templateRequeteExploitationLireUn_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return irexConnector.templateRequeteExploitationLireUn(tracabilite_p, nom_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_templateRequeteExploitationLireUn_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> traitementDeMasseCreer(Tracabilite tracabilite_p, TraitementDeMasse traitementDeMasse_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IREXConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        IREXConnector irexConnector = null;
        try
        {
          irexConnector = (IREXConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          // Retour NOK
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_traitementDeMasseCreer_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return irexConnector.traitementDeMasseCreer(tracabilite_p, traitementDeMasse_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_traitementDeMasseCreer_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, List<TraitementDeMasse>> traitementDeMasseLireTous(Tracabilite tracabilite_p, String statut_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, List<TraitementDeMasse>>>(IREXConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, List<TraitementDeMasse>> run() throws RavelException
      {
        IREXConnector irexConnector = null;
        try
        {
          irexConnector = (IREXConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          // Retour NOK
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_traitementDeMasseLireTous_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return irexConnector.traitementDeMasseLireTous(tracabilite_p, statut_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_traitementDeMasseLireTous_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, TraitementDeMasse> traitementDeMasseLireUn(Tracabilite tracabilite_p, String idTraitementDeMasse_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, TraitementDeMasse>>(IREXConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, TraitementDeMasse> run() throws RavelException
      {
        IREXConnector irexConnector = null;
        try
        {
          irexConnector = (IREXConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          // Retour NOK
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_traitementDeMasseLireUn_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return irexConnector.traitementDeMasseLireUn(tracabilite_p, idTraitementDeMasse_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_traitementDeMasseLireUn_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> traitementDeMasseModifierStatutEnCours(Tracabilite tracabilite_p, String idTraitementDeMasse_p, Integer nbTraitementsARealiser_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IREXConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        IREXConnector irexConnector = null;
        try
        {
          irexConnector = (IREXConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          // Retour NOK
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_traitementDeMasseModifierStatutEnCours_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return irexConnector.traitementDeMasseModifierStatutEnCours(tracabilite_p, idTraitementDeMasse_p, nbTraitementsARealiser_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_traitementDeMasseModifierStatutEnCours_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, LigneDeTestEligDSL> ligneDeTestEligDSLLireUn(Tracabilite tracabilite_p, String numeroDeDesignation_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, LigneDeTestEligDSL>>(IREXConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, LigneDeTestEligDSL> run() throws RavelException
      {
        IREXConnector irexConnector;
        try
        {
          irexConnector = (IREXConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception exception)
        {
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, exception.getMessage()), null);
        }
        _avg_ligneDeTestEligDSLLireUn_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return irexConnector.ligneDeTestEligDSLLireUn(tracabilite_p, numeroDeDesignation_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_ligneDeTestEligDSLLireUn_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, List<LigneDeTestEligDSL>> ligneDeTestEligDSLLireTous(Tracabilite tracabilite_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, List<LigneDeTestEligDSL>>>(IREXConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, List<LigneDeTestEligDSL>> run() throws RavelException
      {
        IREXConnector irexConnector;
        try
        {
          irexConnector = (IREXConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception exception)
        {
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, exception.getMessage()), null);
        }
        _avg_ligneDeTestEligDSLLireTous_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return irexConnector.ligneDeTestEligDSLLireTous(tracabilite_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_ligneDeTestEligDSLLireTous_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> ligneDeTestEligDSLCreer(Tracabilite tracabilite_p, LigneDeTestEligDSL ligneDeTestEligDSL_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IREXConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        IREXConnector irexConnector;
        try
        {
          irexConnector = (IREXConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception exception)
        {
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, exception.getMessage()), null);
        }
        _avg_ligneDeTestEligDSLCreer_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return irexConnector.ligneDeTestEligDSLCreer(tracabilite_p, ligneDeTestEligDSL_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_ligneDeTestEligDSLCreer_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> ligneDeTestEligDSLModifier(Tracabilite tracabilite_p, LigneDeTestEligDSL ligneDeTestEligDSL_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IREXConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        IREXConnector irexConnector;
        try
        {
          irexConnector = (IREXConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception exception)
        {
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, exception.getMessage()), null);
        }
        _avg_ligneDeTestEligDSLModifier_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return irexConnector.ligneDeTestEligDSLModifier(tracabilite_p, ligneDeTestEligDSL_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_ligneDeTestEligDSLModifier_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> ligneDeTestEligDSLSupprimer(Tracabilite tracabilite_p, String numeroDeDesignation_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IREXConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        IREXConnector irexConnector;
        try
        {
          irexConnector = (IREXConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception exception)
        {
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, exception.getMessage()), null);
        }
        _avg_ligneDeTestEligDSLSupprimer_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return irexConnector.ligneDeTestEligDSLSupprimer(tracabilite_p, numeroDeDesignation_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_ligneDeTestEligDSLSupprimer_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }
}