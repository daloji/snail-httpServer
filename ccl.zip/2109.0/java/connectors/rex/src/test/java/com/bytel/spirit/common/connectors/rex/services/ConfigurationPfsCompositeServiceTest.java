/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.rex.services;

import java.io.ByteArrayInputStream;
import java.util.Collections;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.cxf.jaxrs.impl.ResponseBuilderImpl;
import org.easymock.Capture;
import org.easymock.EasyMock;
import org.easymock.EasyMockSupport;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.modules.junit4.PowerMockRunner;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.conf.generated.Param;
import com.bytel.ravel.common.test.JUnitTools;
import com.bytel.ravel.common.test.podam.JavaTimeManufacturer;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.net.loadbalancing.ILoadBalancer;
import com.bytel.ravel.net.loadbalancing.URLBalancedElement;
import com.bytel.ravel.net.rest.RestConnectorPool;
import com.bytel.ravel.net.rest.RestInstance;
import com.bytel.ravel.services.conf.connector.generated.Connector;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.connectors.rex.IREX;
import com.bytel.spirit.common.connectors.rex.IREXConnector;
import com.bytel.spirit.common.connectors.rex.REXConnector;
import com.bytel.spirit.common.connectors.rex.REXConnectorTest;
import com.bytel.spirit.common.shared.functional.types.json.RavelJsonTools;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.ressources.BasicResponse;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.ressources.RetourConverter;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.rex.ConfigurationPfs;
import com.bytel.spirit.common.shared.saab.rex.ConfigurationPfsComposite;
import com.bytel.spirit.common.shared.saab.rex.response.GetConfigurationPfsCompositeResponse;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 * @author jpais
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
public class ConfigurationPfsCompositeServiceTest extends EasyMockSupport
{
  /** Param name for PAD6006 */
  private static final String PAD6006_PATH_PARAM = "/configurationPfsComposite"; //$NON-NLS-1$

  /** Path for PAD6006 */
  private String _configurationPfsCompositeUrl;

  /** Factory to generate beans */
  private PodamFactory _podam = new PodamFactoryImpl();

  /** Connector to test */
  private REXConnector _connector;

  /** The traçability */
  private Tracabilite _tracabilite;

  /** Mock {@link ILoadBalancer} */
  @MockStrict
  ILoadBalancer<URLBalancedElement> _loadBalancerMock;

  /** Mock {@link URLBalancedElement} */
  @MockStrict
  URLBalancedElement _urlBalancedElementMock;

  /**
   * Mock of connectors pool HTTP
   */
  @MockStrict
  Hashtable<String, RestConnectorPool> _connectorPoolMock;

  /**
   * Mock {@link RestConnectorPool}
   */
  @MockStrict
  RestConnectorPool _restConnectorPoolMock;

  /**
   * Mock {@link RestInstance}
   */
  @MockStrict
  RestInstance _restInstanceMock;

  /**
   * Initialize before tests
   *
   * @throws Exception
   *           Thrown in case of error during switch in attributes of parent class
   */
  @Before
  public void beforeTest() throws Exception
  {
    _podam.getStrategy().setMemoization(false);
    _podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());
    JavaTimeManufacturer.registerPodamFactory(_podam);

    _connector = new REXConnector();

    _configurationPfsCompositeUrl = PAD6006_PATH_PARAM;
    _tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);

    JUnitTools.setInaccessibleFieldValue(_connector, "_loadBalancer", _loadBalancerMock); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_connectorPool", _connectorPoolMock); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_configurationPfsCompositeUrl", _configurationPfsCompositeUrl); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_configurationPfsCompositeService", new ConfigurationPfsCompositeService(_connector)); //$NON-NLS-1$

    PowerMock.resetAll();
  }

  /**
   * Test the method
   * {@link IREX#configurationPfsCompositeGererEcrireConfigurationPfs(Tracabilite, String, ConfigurationPfs)} httpStatus
   * 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void configurationPfsCompositeGererEcrireConfigurationPfsTest_OK_001() throws Exception
  {
    // Expected response
    Retour retour = RetourFactory.createOkRetour();
    String partnerResponse = RavelJsonTools.getInstance().toJson(new BasicResponse(RetourConverter.convertToJsonRetour(retour)), BasicResponse.class);
    Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // Init mocks
    initializeMocksForSendRequest();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();
    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();

    ConfigurationPfs configurationPfs = _podam.manufacturePojo(ConfigurationPfs.class);

    String expectedJSON = RavelJsonTools.getInstance().toJson(new ConfigurationPfsComposite(configurationPfs), ConfigurationPfsComposite.class);

    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_configurationPfsCompositeUrl), EasyMock.capture(headersCapture), EasyMock.eq(expectedJSON), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();

    // Request
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    String xOauth2Login = "TEST";

    // Call method
    ConnectorResponse<Retour, Nothing> result = _connector.configurationPfsCompositeGererEcrireConfigurationPfs(tracabilite, xOauth2Login, configurationPfs);

    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());
    Assert.assertNotNull(headersCapture.getValue().get(IHttpHeadersConsts.X_OAUTH2_LOGIN));
    Assert.assertEquals(xOauth2Login, headersCapture.getValue().get(IHttpHeadersConsts.X_OAUTH2_LOGIN).get(0));

    checkQueryParams(queryParamsCapture, IREXConnector.PARAM_ACTION, "GererEcrireConfigurationPfs");

    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);

  }

  /**
   * Test the method
   * {@link IREX#configurationPfsCompositeGererEcrirePfs(Tracabilite, String, ConfigurationPfsComposite)} httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void configurationPfsCompositeGererEcrirePfsTest_OK_001() throws Exception
  {
    // Expected response
    Retour retour = RetourFactory.createOkRetour();
    String partnerResponse = RavelJsonTools.getInstance().toJson(new BasicResponse(RetourConverter.convertToJsonRetour(retour)), BasicResponse.class);
    Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // Init mocks
    initializeMocksForSendRequest();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();
    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();

    ConfigurationPfsComposite configurationPfsComposite = _podam.manufacturePojo(ConfigurationPfsComposite.class);

    String expectedJSON = RavelJsonTools.getInstance().toJson(configurationPfsComposite, ConfigurationPfsComposite.class);

    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_configurationPfsCompositeUrl), EasyMock.capture(headersCapture), EasyMock.eq(expectedJSON), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();

    // Request
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    String xOauth2Login = "TEST";

    // Call method
    ConnectorResponse<Retour, Nothing> result = _connector.configurationPfsCompositeGererEcrirePfs(tracabilite, xOauth2Login, configurationPfsComposite);

    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());
    Assert.assertNotNull(headersCapture.getValue().get(IHttpHeadersConsts.X_OAUTH2_LOGIN));
    Assert.assertEquals(xOauth2Login, headersCapture.getValue().get(IHttpHeadersConsts.X_OAUTH2_LOGIN).get(0));

    checkQueryParams(queryParamsCapture, IREXConnector.PARAM_ACTION, "GererEcrirePfs");

    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);

  }

  /**
   * Test the method
   * {@link IREX#configurationPfsCompositeGererSuppressionConfigurationPfs(Tracabilite, String, ConfigurationPfs)}
   * httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void configurationPfsCompositeGererSuppressionConfigurationPfsTest_OK_001() throws Exception
  {
    // Expected response
    Retour retour = RetourFactory.createOkRetour();
    String partnerResponse = RavelJsonTools.getInstance().toJson(new BasicResponse(RetourConverter.convertToJsonRetour(retour)), BasicResponse.class);
    Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // Init mocks
    initializeMocksForSendRequest();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();
    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();

    ConfigurationPfs configurationPfs = _podam.manufacturePojo(ConfigurationPfs.class);

    String expectedJSON = RavelJsonTools.getInstance().toJson(new ConfigurationPfsComposite(configurationPfs), ConfigurationPfsComposite.class);

    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_configurationPfsCompositeUrl), EasyMock.capture(headersCapture), EasyMock.eq(expectedJSON), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();

    // Request
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    String xOauth2Login = "TEST";

    // Call method
    ConnectorResponse<Retour, Nothing> result = _connector.configurationPfsCompositeGererSuppressionConfigurationPfs(tracabilite, xOauth2Login, configurationPfs);

    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());
    Assert.assertNotNull(headersCapture.getValue().get(IHttpHeadersConsts.X_OAUTH2_LOGIN));
    Assert.assertEquals(xOauth2Login, headersCapture.getValue().get(IHttpHeadersConsts.X_OAUTH2_LOGIN).get(0));

    checkQueryParams(queryParamsCapture, IREXConnector.PARAM_ACTION, "GererSuppressionConfigurationPfs");

    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
  }

  /**
   * Test the method
   * {@link IREX#configurationPfsCompositeGererSuppressionPfs(Tracabilite, String, ConfigurationPfsComposite)}
   * httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void configurationPfsCompositeGererSuppressionPfsTest_OK_001() throws Exception
  {
    // Expected response
    Retour retour = RetourFactory.createOkRetour();
    String partnerResponse = RavelJsonTools.getInstance().toJson(new BasicResponse(RetourConverter.convertToJsonRetour(retour)), BasicResponse.class);
    Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // Init mocks
    initializeMocksForSendRequest();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();
    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();

    ConfigurationPfsComposite configurationPfsComposite = _podam.manufacturePojo(ConfigurationPfsComposite.class);

    String expectedJSON = RavelJsonTools.getInstance().toJson(configurationPfsComposite, ConfigurationPfsComposite.class);

    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_configurationPfsCompositeUrl), EasyMock.capture(headersCapture), EasyMock.eq(expectedJSON), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();

    // Request
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    String xOauth2Login = "TEST";

    // Call method
    ConnectorResponse<Retour, Nothing> result = _connector.configurationPfsCompositeGererSuppressionPfs(tracabilite, xOauth2Login, configurationPfsComposite);

    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());
    Assert.assertNotNull(headersCapture.getValue().get(IHttpHeadersConsts.X_OAUTH2_LOGIN));
    Assert.assertEquals(xOauth2Login, headersCapture.getValue().get(IHttpHeadersConsts.X_OAUTH2_LOGIN).get(0));

    checkQueryParams(queryParamsCapture, IREXConnector.PARAM_ACTION, "GererSuppressionPfs");

    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);

  }

  /**
   * Test the method {@link REXConnector#configurationPfsCompositeLireTous(Tracabilite)} httpStatus 200 idCmd inconnu
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void configurationPfsCompositeLireTousTest_OK_001() throws Exception
  {
    // Expected response
    Retour retour = RetourFactory.createOkRetour();
    ConfigurationPfsComposite configurationPfsComposite = _podam.manufacturePojo(ConfigurationPfsComposite.class);

    String partnerResponse = RavelJsonTools.getInstance().toJson(new GetConfigurationPfsCompositeResponse(RetourConverter.convertToJsonRetour(retour), Collections.singletonList(configurationPfsComposite)), GetConfigurationPfsCompositeResponse.class);
    Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // Init mocks
    initializeMocksForSendRequest();

    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();
    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();

    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_configurationPfsCompositeUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();

    // Request
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);

    // Call method
    ConnectorResponse<Retour, List<ConfigurationPfsComposite>> result = _connector.configurationPfsCompositeLireTous(tracabilite);
    PowerMock.verifyAll();

    // Assertions
    Assert.assertNotNull(headersCapture.getValue());

    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
    Assert.assertNotNull(result._second);
    Assert.assertEquals(configurationPfsComposite, result._second.get(0));
  }

  /**
   * @throws Exception
   *           Exception
   */
  @Test
  public void loadConnectorConfigurationTest() throws Exception
  {
    final Connector connector = new Connector();

    Param param = new Param();
    param.setName("PAD6006_PATH_PARAM"); //$NON-NLS-1$
    param.setValue(_configurationPfsCompositeUrl);
    connector.getParam().add(param);

    connector.setURLS(REXConnectorTest.generateURLS());

    // test
    _connector.loadConnectorConfiguration(connector);

    // assertions
    Assert.assertEquals(_configurationPfsCompositeUrl, JUnitTools.getInaccessibleFieldValue(_connector, "_configurationPfsCompositeUrl")); //$NON-NLS-1$
    Assert.assertNotNull(JUnitTools.getInaccessibleFieldValue(_connector, "_configurationPfsCompositeService")); //$NON-NLS-1$
  }

  /**
   * Check the query params in rest send request method
   *
   * @param queryParams
   *          the actual query params
   * @param expected_p
   *          list of expected query params strings key1 value1 key2 value2...keyN valueN
   */
  private void checkQueryParams(Capture<Map<String, String>> queryParams, String... expected_p)
  {
    if (expected_p == null)
    {
      Assert.assertNull(queryParams.getValue());
    }
    else
    {
      Assert.assertEquals(0, expected_p.length % 2);
      for (int i = 0; i < expected_p.length; i = i + 2)
      {
        Assert.assertEquals(expected_p[i + 1], queryParams.getValue().get(expected_p[i]));
      }
    }
  }

  /**
   * prepare mock scenario to initialize method sendRequest from AbstractRestConnector
   *
   * @throws Exception
   *           Thrown in case of error
   */
  private void initializeMocksForSendRequest() throws Exception
  {
    final String urlBalancedElementName = RandomStringUtils.randomAlphanumeric(45);
    final String urlBalancedElementDescription = RandomStringUtils.randomAlphabetic(9);

    EasyMock.expect(_loadBalancerMock.chooseBalancedElement()).andReturn(_urlBalancedElementMock);
    EasyMock.expect(_urlBalancedElementMock.getName()).andReturn(urlBalancedElementName);
    EasyMock.expect(_urlBalancedElementMock.getDescription()).andReturn(urlBalancedElementDescription);
    EasyMock.expect(_urlBalancedElementMock.getName()).andReturn(urlBalancedElementName);
    EasyMock.expect(_connectorPoolMock.get(urlBalancedElementName)).andReturn(_restConnectorPoolMock);
    EasyMock.expect(_restConnectorPoolMock.borrowObject()).andReturn(_restInstanceMock);

    _restInstanceMock.setReceiveTimeout(0);
  }
}
