/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.rex;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.conf.generated.LoadBalancer;
import com.bytel.ravel.common.conf.generated.Param;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.test.JUnitTools;
import com.bytel.ravel.common.test.podam.JavaTimeManufacturer;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.RetourFactoryForTU;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.net.loadbalancing.ILoadBalancer;
import com.bytel.ravel.net.loadbalancing.URLBalancedElement;
import com.bytel.ravel.net.rest.RestConnectorPool;
import com.bytel.ravel.net.rest.RestInstance;
import com.bytel.ravel.services.conf.connector.generated.Connector;
import com.bytel.ravel.services.conf.connector.generated.URL;
import com.bytel.ravel.services.conf.connector.generated.URLS;
import com.bytel.ravel.services.connector.AbstractRESTConnector;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.shared.functional.types.json.RavelJsonTools;
import com.bytel.spirit.common.shared.functional.types.json.notification.AbstractNotificationReseau;
import com.bytel.spirit.common.shared.functional.types.json.notification.NotificationReseauONTInconnuJSON;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.BasicResponse;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.ressources.RetourConverter;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.StatutBlockage;
import com.bytel.spirit.common.shared.saab.rex.AssociationPfiReconcialitionCommerciale;
import com.bytel.spirit.common.shared.saab.rex.BlocageEquipement;
import com.bytel.spirit.common.shared.saab.rex.ComparaisonCommerciale;
import com.bytel.spirit.common.shared.saab.rex.DecisionExploitation;
import com.bytel.spirit.common.shared.saab.rex.Equipement;
import com.bytel.spirit.common.shared.saab.rex.ErreurSpirit;
import com.bytel.spirit.common.shared.saab.rex.HistorisationEligibilite;
import com.bytel.spirit.common.shared.saab.rex.LigneDeTestEligDSL;
import com.bytel.spirit.common.shared.saab.rex.NotificationReseau;
import com.bytel.spirit.common.shared.saab.rex.NotificationReseauOntInconnu;
import com.bytel.spirit.common.shared.saab.rex.NotificationReseauStatut;
import com.bytel.spirit.common.shared.saab.rex.NotificationReseauType;
import com.bytel.spirit.common.shared.saab.rex.OperationVieReseau;
import com.bytel.spirit.common.shared.saab.rex.ReconciliationCommerciale;
import com.bytel.spirit.common.shared.saab.rex.RequeteExploitation;
import com.bytel.spirit.common.shared.saab.rex.TemplateRequeteExploitation;
import com.bytel.spirit.common.shared.saab.rex.TraitementDeMasse;
import com.bytel.spirit.common.shared.saab.rex.request.CreateComparaisonCommercialeCompositeRequest;
import com.bytel.spirit.common.shared.saab.rex.request.CreateErreurSpiritRequest;
import com.bytel.spirit.common.shared.saab.rex.request.CreateOrUpdateReconciliationCommercialeRequest;
import com.bytel.spirit.common.shared.saab.rex.request.ListeCleRechercheBlocageEquipementRequest;
import com.bytel.spirit.common.shared.saab.rex.request.ListeCleRechercheNotificationReseauRequest;
import com.bytel.spirit.common.shared.saab.rex.request.ListeCleRechercheOperationVieReseauRequest;
import com.bytel.spirit.common.shared.saab.rex.request.ManageReconciliationCommercialeEnMasseRequest;
import com.bytel.spirit.common.shared.saab.rex.request.OperationVieReseauModifierListeClientImpacteRequest;
import com.bytel.spirit.common.shared.saab.rex.request.OperationVieReseauModifierStatutRequest;
import com.bytel.spirit.common.shared.saab.rex.request.ReconciliationCommercialeEnMasseAjouterRequest;
import com.bytel.spirit.common.shared.saab.rex.request.UpdateBlocageEquipementRequest;
import com.bytel.spirit.common.shared.saab.rex.request.UpdateErreurSpiritRequest;
import com.bytel.spirit.common.shared.saab.rex.request.UpdateNotificationReseauStatutRequest;
import com.bytel.spirit.common.shared.saab.rex.response.GetNotificationReseauResponse;
import com.bytel.spirit.common.shared.saab.rex.response.ListeBlocageEquipementResponse;
import com.bytel.spirit.common.shared.saab.rex.response.ListeOperationVieReseauResponse;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.cxf.jaxrs.impl.ResponseBuilderImpl;
import org.easymock.Capture;
import org.easymock.EasyMock;
import org.easymock.EasyMockSupport;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import java.io.ByteArrayInputStream;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Supplier;

import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author kbettenc
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({})
public class REXConnectorTest extends EasyMockSupport
{
  /**
   * ID_CMD
   */
  private static final String ID_CMD = "idCmd"; //$NON-NLS-1$

  /**
   * ID_RECONCILIATION
   */
  private static final String ID_RECONCILIATION = "idReconciliation"; //$NON-NLS-1$

  /**
   * STATUT
   */
  private static final String STATUT = "statut"; //$NON-NLS-1$

  /**
   * DATE_DEB
   */
  private static final String DATE_DEB = "dateDeb"; //$NON-NLS-1$

  /**
   * DATE_FIN
   */
  private static final String DATE_FIN = "dateFin"; //$NON-NLS-1$

  /**
   * ID_ERREUR_SPIRIT
   */
  private static final String ID_ERREUR_SPIRIT = "idErreurSpirit"; //$NON-NLS-1$

  /**
   * CLIENT_OPERATEUR
   */
  private static final String CLIENT_OPERATEUR = "clientOperateur"; //$NON-NLS-1$

  /**
   * NO_COMPTE
   */
  private static final String NO_COMPTE = "noCompte"; //$NON-NLS-1$
  /**
   * NOM
   */
  private static final String NOM = "nom"; //$NON-NLS-1$

  /**
   * ID_HISTORISATION_ELIGIBILITE
   */
  private static final String ID_HISTORISATION_ELIGIBILITE = "idHistorisationEligibilite"; //$NON-NLS-1$

  /**
   * ID_BLOCAGE_EQUIPEMENT
   */
  private static final String ID_BLOCAGE_EQUIPEMENT = "idBlocageEquipement"; //$NON-NLS-1$
  /**
   * ID_OPERATION_VIE_RESEAU
   */
  private static final String ID_OPERATION_VIE_RESEAU = "idOperationVieReseau"; //$NON-NLS-1$

  /**
   * ID_TRAITEMENT_DE_MASSE
   */
  private static final String ID_TRAITEMENT_DE_MASSE = "idTraitementDeMasse"; //$NON-NLS-1$

  /**
   * TYPE_TRAITEMENT_DE_MASSE
   */
  private static final String TYPE_TRAITEMENT_DE_MASSE = "typeTraitementDeMasse"; //$NON-NLS-1$

  /**
   * Path for get pad6001
   */
  private static final String PAD6001_PATH_PARAM = "/comparaisonCommerciale/"; //$NON-NLS-1$

  /**
   * Path for get pad6002
   */
  private static final String PAD6002_PATH_PARAM = "/reconciliationCommerciale/"; //$NON-NLS-1$

  /**
   * Path for get pad6003
   */
  private static final String PAD6003_PATH_PARAM = "/erreurSpirit/"; //$NON-NLS-1$

  /**
   * Path for get pad6004
   */
  private static final String PAD6004_PATH_PARAM = "/traitementDeMasse/"; //$NON-NLS-1$

  /**
   * Path for get pad6005
   */
  private static final String PAD6005_PATH_PARAM = "/reconciliationCommercialeEnMasse/"; //$NON-NLS-1$

  /**
   * Path for get pad6007
   */
  private static final String PAD6007_PATH_PARAM = "/configurationProsper/"; //$NON-NLS-1$

  /**
   * Path for get pad6008
   */
  private static final String PAD6008_PATH_PARAM = "/notificationReseau/"; //$NON-NLS-1$

  /**
   * Path for get pad6009
   */
  private static final String PAD6009_PATH_PARAM = "/cleRechercheNotificationReseau/"; //$NON-NLS-1$

  /**
   * Path for get pad6010
   */
  private static final String PAD6010_PATH_PARAM = "/historisationEligibilite/"; //$NON-NLS-1$

  /**
   * Path for get pad6011
   */
  private static final String PAD6011_PATH_PARAM = "/operationVieReseau/"; //$NON-NLS-1$

  /**
   * Path for get pad6012
   */
  private static final String PAD6012_PATH_PARAM = "/cleRechercheOperationVieReseau/"; //$NON-NLS-1$
  /**
   * Path for get pad6013
   */
  private static final String PAD6013_PATH_PARAM = "/blocageEquipement/"; //$NON-NLS-1$

  /**
   * Path for post PAD6014
   */
  private static final String PAD6014_PATH_PARAM = "/cleRechercheBlocageEquipement/"; //$NON-NLS-1$

  private static final String PAD6015_PATH_PARAM = "/ligneDeTestEligDSL/"; //$NON-NLS-1$

  /**
   * The constant for JSON_ERROR_MESSAGE
   */
  private static final String JSON_ERROR_MESSAGE = Messages.getString("REXConnector.JsonErrorMessage"); //$NON-NLS-1$

  /**
   * The constant for nbTraitementsARealiser param
   */
  private static final String PARAM_NB_TRAITEMENTS_A_REALISER = "nbTraitementsARealiser"; //$NON-NLS-1$
  /**
   * The constant for idNotificationReseau param
   */
  private static final String PARAM_ID_NOTIFICATION_RESEAU = "idNotificationReseau"; //$NON-NLS-1$

  /**
   * The constant for Ajouter param
   */
  private static final String ACTION_AJOUTER = "Ajouter"; //$NON-NLS-1$

  /**
   * The constant for action param
   */
  private static final String PARAM_ACTION = "action"; //$NON-NLS-1$

  final static String TYPE_OPERATION_VIE_RESEAU = "typeOperationVieReseau";

  final static String TYPE_CLE = "typeCle";

  final static String VALEUR_CLE = "valeurCle";

  /**
   * @return URLS
   */
  public static URLS generateURLS()
  {
    final URLS urls = new URLS();
    urls.setLoadBalancer(generateLoadBalancer());
    urls.getURL().add(generateURL());
    return urls;
  }

  /**
   * Génération du LoadBalancer minimal pour passer {@link AbstractRESTConnector#loadConnectorConfiguration(Connector)}
   *
   * @return {@link LoadBalancer}
   */
  private static LoadBalancer generateLoadBalancer()
  {
    final LoadBalancer loadBalancer = new LoadBalancer();
    Param timer = new Param();
    timer.setName("TIMER"); //$NON-NLS-1$
    timer.setValue("30"); //$NON-NLS-1$
    loadBalancer.getParam().add(timer);
    loadBalancer.setType("RoundRobin"); //$NON-NLS-1$
    return loadBalancer;
  }

  /**
   * Génération du URL minimal pour passer {@link AbstractRESTConnector#loadConnectorConfiguration(Connector)}
   *
   * @return {@link URL}
   */
  private static URL generateURL()
  {
    final URL url = new URL();
    url.setName("urlName"); //$NON-NLS-1$
    url.setAccessPoint("http://localhost:8888"); //$NON-NLS-1$
    Param param = new Param();
    param.setName("PROXY_ENABLED"); //$NON-NLS-1$
    param.setValue(String.valueOf(false));
    url.getParam().add(param);
    param = new Param();
    param.setName("TIMEOUT"); //$NON-NLS-1$
    param.setValue("30"); //$NON-NLS-1$
    url.getParam().add(param);

    return url;
  }

  /**
   * Path for PAD6012
   */
  private String _cleRechercheOperationVieReseauUrl;

  /**
   * Path for PAD6013
   */
  private String _blocageEquipementUrl;

  /**
   * Connector to test
   */
  private REXConnector _connector;

  /**
   * Factory to generate beans
   */
  private PodamFactory _podam = new PodamFactoryImpl();

  /**
   * Path for PAD6001
   */
  private String _comparaisonCommercialeCompositeUrl;

  /**
   * Path for PAD6002
   */
  private String _reconciliationCommercialeUrl;

  /**
   * Path for PAD6003
   */
  private String _erreurSpiritUrl;

  /**
   * Path for PAD6004
   */
  private String _traitementDeMasseUrl;

  /**
   * Path for PAD6007
   */
  private String _configurationProsperUrl;

  /**
   * Path for PAD6005
   */
  private String _reconciliationCommercialeEnMasseUrl;

  /** Path for PAD6006. */
  private String _configurationPfsCompositeUrl;

  /**
   * Path for PAD6008
   */
  private String _notificationReseauUrl;

  /**
   * Path for PAD6014
   */
  private String _cleRechercheBlocageEquipementUrl;

  /**
   * Path for PAD6009
   */
  private String _cleRechercheNotificationReseauUrl;

  /**
   * Path for PAD6011
   */
  private String _operationVieReseauUrl;

  /**
   * Path for PAD6010
   */
  private String _historisationEligibiliteUrl;

  /**
   * Path for PAD6015
   */
  private String _ligneDeTestEligDSLUrl;

  /**
   * Mock {@link ILoadBalancer}
   */
  @MockStrict
  ILoadBalancer<URLBalancedElement> _loadBalancerMock;

  /**
   * Mock {@link URLBalancedElement}
   */
  @MockStrict
  URLBalancedElement _urlBalancedElementMock;

  /**
   * Mock of connectors pool HTTP
   */
  @MockStrict
  Hashtable<String, RestConnectorPool> _connectorPoolMock;

  /**
   * Mock {@link RestConnectorPool}
   */
  @MockStrict
  RestConnectorPool _restConnectorPoolMock;

  /**
   * Mock {@link RestInstance}
   */
  @MockStrict
  RestInstance _restInstanceMock;

  /**
   * Initialize before tests
   *
   * @throws Exception
   *           Thrown in case of error during switch in attributes of parent class
   */
  @Before
  public void beforeTest() throws Exception
  {
    _podam.getStrategy().setMemoization(false);
    _podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());
    JavaTimeManufacturer.registerPodamFactory(_podam);

    _connector = new REXConnector();
    _comparaisonCommercialeCompositeUrl = PAD6001_PATH_PARAM;
    _reconciliationCommercialeUrl = PAD6002_PATH_PARAM;
    _erreurSpiritUrl = PAD6003_PATH_PARAM;
    _traitementDeMasseUrl = PAD6004_PATH_PARAM;
    _reconciliationCommercialeEnMasseUrl = PAD6005_PATH_PARAM;
    _configurationProsperUrl = PAD6007_PATH_PARAM;
    _notificationReseauUrl = PAD6008_PATH_PARAM;
    _cleRechercheNotificationReseauUrl = PAD6009_PATH_PARAM;
    _historisationEligibiliteUrl = PAD6010_PATH_PARAM;
    _operationVieReseauUrl = PAD6011_PATH_PARAM;
    _cleRechercheOperationVieReseauUrl = PAD6012_PATH_PARAM;
    _blocageEquipementUrl = PAD6013_PATH_PARAM;
    _cleRechercheBlocageEquipementUrl = PAD6014_PATH_PARAM;
    _ligneDeTestEligDSLUrl = PAD6015_PATH_PARAM;

    JUnitTools.setInaccessibleFieldValue(_connector, "_loadBalancer", _loadBalancerMock); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_connectorPool", _connectorPoolMock); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_comparaisonCommercialeCompositeUrl", _comparaisonCommercialeCompositeUrl); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_reconciliationCommercialeUrl", _reconciliationCommercialeUrl); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_erreurSpiritUrl", _erreurSpiritUrl); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_traitementDeMasseUrl", _traitementDeMasseUrl); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_reconciliationCommercialeEnMasseUrl", _reconciliationCommercialeEnMasseUrl); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_configurationProsperUrl", _configurationProsperUrl); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_notificationReseauUrl", _notificationReseauUrl); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_cleRechercheNotificationReseauUrl", _cleRechercheNotificationReseauUrl); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_historisationEligibiliteUrl", _historisationEligibiliteUrl); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_operationVieReseauUrl", _operationVieReseauUrl); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_cleRechercheBlocageEquipementUrl", _cleRechercheBlocageEquipementUrl); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_blocageEquipementUrl", _blocageEquipementUrl); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_cleRechercheBlocageEquipementUrl", _cleRechercheBlocageEquipementUrl); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_cleRechercheOperationVieReseauUrl", _cleRechercheOperationVieReseauUrl); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_ligneDeTestEligDSLUrl", _ligneDeTestEligDSLUrl); //$NON-NLS-1$

    PowerMock.resetAll();
  }

  /**
   * @throws Exception
   *           Exception
   */
  @Test
  public void test_loadConnectorConfiguration() throws Exception
  {
    JUnitTools.setInaccessibleFieldValue(_connector, "_loadBalancer", null); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_connectorPool", null); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_comparaisonCommercialeCompositeUrl", null); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_reconciliationCommercialeUrl", null); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_erreurSpiritUrl", null); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_traitementDeMasseUrl", null); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_reconciliationCommercialeEnMasseUrl", null); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_configurationProsperUrl", null); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_notificationReseauUrl", null); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_cleRechercheNotificationReseauUrl", null); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_configurationPfsCompositeUrl", null); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_operationVieReseauUrl", null); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_cleRechercheBlocageEquipementUrl", null); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_blocageEquipementUrl", null); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_cleRechercheBlocageEquipementUrl", null); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_cleRechercheOperationVieReseauUrl", null); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_ligneDeTestEligDSLUrl", null); //$NON-NLS-1$

    final Connector connector = new Connector();

    Param param = new Param();
    param.setName("PAD6001_ComparaisonCommercialeComposite"); //$NON-NLS-1$
    param.setValue(_comparaisonCommercialeCompositeUrl);
    connector.getParam().add(param);

    param = new Param();
    param.setName("PAD6002_ReconciliationCommerciale"); //$NON-NLS-1$
    param.setValue(_reconciliationCommercialeUrl);
    connector.getParam().add(param);

    param = new Param();
    param.setName("PAD6003_ErreurSpirit"); //$NON-NLS-1$
    param.setValue(_erreurSpiritUrl);
    connector.getParam().add(param);

    param = new Param();
    param.setName("PAD6004_TraitementDeMasse"); //$NON-NLS-1$
    param.setValue(_traitementDeMasseUrl);
    connector.getParam().add(param);

    param = new Param();
    param.setName("PAD6005_ReconciliationCommercialeEnMasse"); //$NON-NLS-1$
    param.setValue(_reconciliationCommercialeEnMasseUrl);
    connector.getParam().add(param);

    param = new Param();
    param.setName("PAD6006_ConfigurationPfsComposite"); //$NON-NLS-1$
    param.setValue(_configurationPfsCompositeUrl);
    connector.getParam().add(param);

    param = new Param();
    param.setName("PAD6008_NotificationReseau"); //$NON-NLS-1$
    param.setValue(_notificationReseauUrl);
    connector.getParam().add(param);

    param = new Param();
    param.setName("PAD6009_CleRechercheNotificationReseau"); //$NON-NLS-1$
    param.setValue(_cleRechercheNotificationReseauUrl);
    connector.getParam().add(param);

    param = new Param();
    param.setName("PAD6010_HistorisationEligibilite"); //$NON-NLS-1$
    param.setValue(_historisationEligibiliteUrl);
    connector.getParam().add(param);

    param = new Param();
    param.setName("PAD6011_OperationVieReseau"); //$NON-NLS-1$
    param.setValue(_operationVieReseauUrl);
    connector.getParam().add(param);

    param = new Param();
    param.setName("PAD6012_CleRechercheOperationVieReseau"); //$NON-NLS-1$
    param.setValue(_cleRechercheOperationVieReseauUrl);
    connector.getParam().add(param);

    param = new Param();
    param.setName("PAD6013_BlocageEquipement"); //$NON-NLS-1$
    param.setValue(_blocageEquipementUrl);
    connector.getParam().add(param);

    param = new Param();
    param.setName("PAD6014_CleRechercheBlocageEquipement"); //$NON-NLS-1$
    param.setValue(_cleRechercheBlocageEquipementUrl);
    connector.getParam().add(param);

    param = new Param();
    param.setName("PAD6015_LigneDeTestEligDSL"); //$NON-NLS-1$
    param.setValue(_ligneDeTestEligDSLUrl);
    connector.getParam().add(param);

    connector.setURLS(generateURLS());

    // test
    _connector.loadConnectorConfiguration(connector);

    // assertions
    Assert.assertEquals(_comparaisonCommercialeCompositeUrl, JUnitTools.getInaccessibleFieldValue(_connector, "_comparaisonCommercialeCompositeUrl")); //$NON-NLS-1$
    Assert.assertEquals(_reconciliationCommercialeUrl, JUnitTools.getInaccessibleFieldValue(_connector, "_reconciliationCommercialeUrl")); //$NON-NLS-1$
    Assert.assertEquals(_erreurSpiritUrl, JUnitTools.getInaccessibleFieldValue(_connector, "_erreurSpiritUrl")); //$NON-NLS-1$
    Assert.assertEquals(_traitementDeMasseUrl, JUnitTools.getInaccessibleFieldValue(_connector, "_traitementDeMasseUrl")); //$NON-NLS-1$
    Assert.assertEquals(_reconciliationCommercialeEnMasseUrl, JUnitTools.getInaccessibleFieldValue(_connector, "_reconciliationCommercialeEnMasseUrl")); //$NON-NLS-1$
    Assert.assertEquals(_notificationReseauUrl, JUnitTools.getInaccessibleFieldValue(_connector, "_notificationReseauUrl")); //$NON-NLS-1$
    Assert.assertEquals(_cleRechercheNotificationReseauUrl, JUnitTools.getInaccessibleFieldValue(_connector, "_cleRechercheNotificationReseauUrl")); //$NON-NLS-1$
    Assert.assertEquals(_configurationPfsCompositeUrl, JUnitTools.getInaccessibleFieldValue(_connector, "_configurationPfsCompositeUrl")); //$NON-NLS-1$
    Assert.assertEquals(_ligneDeTestEligDSLUrl, JUnitTools.getInaccessibleFieldValue(_connector, "_ligneDeTestEligDSLUrl")); //$NON-NLS-1$
  }

  /**
   * Test the method {@link REXConnector#blocageEquipementCreer} httpStatus 400
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testBlocageEquipementCreer_KO_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);

    Retour retour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, Response.Status.BAD_REQUEST.getReasonPhrase());
    BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = RavelJsonTools.getInstance().toJson(basicResponse, BasicResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(400).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(_blocageEquipementUrl), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.blocageEquipementCreer(tracabilite, null);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture);

    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
  }

  /**
   * Test the method {@link REXConnector#blocageEquipementCreer} httpStatus 200 jsonResponse null
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testBlocageEquipementCreer_KO_002() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock
        .expect(_restInstanceMock.post(EasyMock.eq(_blocageEquipementUrl), //
            EasyMock.capture(headersCapture), //
            EasyMock.eq(null), //
            EasyMock.capture(queryParamsCapture)))//
        .andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    ConnectorResponse<Retour, Nothing> result = _connector.blocageEquipementCreer(tracabilite, null);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture);

    Retour expectedRetour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, JSON_ERROR_MESSAGE);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method {@link REXConnector#blocageEquipementCreer} httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testBlocageEquipementCreer_OK_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final BlocageEquipement blocageEquipement = _podam.manufacturePojoWithFullData(BlocageEquipement.class);

    Retour retour = RetourFactory.createOkRetour();
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = RavelJsonTools.getInstance().toJson(basicResponse, BasicResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock
        .expect(_restInstanceMock.post(EasyMock.eq(_blocageEquipementUrl), //
            EasyMock.capture(headersCapture), //
            EasyMock.eq(RavelJsonTools.getInstance().toJson(blocageEquipement, BlocageEquipement.class)), //
            EasyMock.capture(queryParamsCapture)))//
        .andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.blocageEquipementCreer(tracabilite, blocageEquipement);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());
    checkQueryParams(queryParamsCapture);

    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
  }

  /**
   * Test the method {@link REXConnector#blocageEquipementLireUn} httpStatus 400
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testBlocageEquipementLireUn_KO_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);

    Retour retour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, Response.Status.BAD_REQUEST.getReasonPhrase());
    BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = RavelJsonTools.getInstance().toJson(basicResponse, BasicResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(400).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_blocageEquipementUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, BlocageEquipement> result = _connector.blocageEquipementLireUn(tracabilite, null);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture);

    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);

  }

  /**
   * Test the method {@link REXConnector#blocageEquipementLireUn} httpStatus 200 jsonResponse null
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testBlocageEquipementLireUn_KO_002() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock
        .expect(_restInstanceMock.get(EasyMock.eq(_blocageEquipementUrl), //
            EasyMock.capture(headersCapture), //
            EasyMock.capture(queryParamsCapture)))//
        .andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    ConnectorResponse<Retour, BlocageEquipement> result = _connector.blocageEquipementLireUn(tracabilite, null);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture);

    Retour expectedRetour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, JSON_ERROR_MESSAGE);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method {@link REXConnector#blocageEquipementLireUn} httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testBlocageEquipementLireUn_OK_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);

    String idBlocageEqpt = _podam.manufacturePojoWithFullData(String.class);

    Retour retour = RetourFactory.createOkRetour();
    ListeBlocageEquipementResponse listBlocageEquipementResp = new ListeBlocageEquipementResponse(RetourConverter.convertToJsonRetour(retour));
    List<BlocageEquipement> listBlocageEquipement = new ArrayList<>();
    Set<Equipement> listEquipements = new HashSet<>();
    Set<Equipement> olt = _podam.manufacturePojo(HashSet.class, Equipement.class);
    olt.forEach(o -> o.setType("OLT"));
    Set<Equipement> pm = _podam.manufacturePojo(HashSet.class, Equipement.class);
    pm.forEach(p -> p.setType("PM"));
    listEquipements.addAll(olt);
    listEquipements.addAll(pm);
    BlocageEquipement blocage = new BlocageEquipement(idBlocageEqpt, StatutBlockage.ACTIF.name(), _podam.manufacturePojo(HashSet.class, String.class), //
        listEquipements);

    listBlocageEquipement.add(blocage);
    listBlocageEquipementResp.setBlocageEquipementList(listBlocageEquipement);

    final String partnerResponse = RavelJsonTools.getInstance().toJson(listBlocageEquipementResp, ListeBlocageEquipementResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_blocageEquipementUrl), //
        EasyMock.capture(headersCapture), //
        EasyMock.capture(queryParamsCapture)))//
        .andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, BlocageEquipement> result = _connector.blocageEquipementLireUn(tracabilite, idBlocageEqpt);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());
    checkQueryParams(queryParamsCapture, ID_BLOCAGE_EQUIPEMENT, idBlocageEqpt);
    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
    Assert.assertEquals(listBlocageEquipementResp.getBlocageEquipementList().get(0), result._second);

  }

  /**
   * Test the method {@link REXConnector#blocageEquipementModifier} httpStatus 400
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testBlocageEquipementModifier_KO_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);

    Retour retour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, Response.Status.BAD_REQUEST.getReasonPhrase());
    BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = RavelJsonTools.getInstance().toJson(basicResponse, BasicResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(400).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_blocageEquipementUrl), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.blocageEquipementModifier(tracabilite, null);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture);

    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
  }

  /**
   * Test the method {@link REXConnector#blocageEquipementModifier} httpStatus 200 jsonResponse null
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testBlocageEquipementModifier_KO_002() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock
        .expect(_restInstanceMock.put(EasyMock.eq(_blocageEquipementUrl), //
            EasyMock.capture(headersCapture), //
            EasyMock.eq(null), //
            EasyMock.capture(queryParamsCapture)))//
        .andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    ConnectorResponse<Retour, Nothing> result = _connector.blocageEquipementModifier(tracabilite, null);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture);

    Retour expectedRetour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, JSON_ERROR_MESSAGE);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method {@link REXConnector#blocageEquipementModifier} httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testBlocageEquipementModifier_OK_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);

    UpdateBlocageEquipementRequest blocageEquipementReq = _podam.manufacturePojoWithFullData(UpdateBlocageEquipementRequest.class);

    Retour retour = RetourFactory.createOkRetour();
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = RavelJsonTools.getInstance().toJson(basicResponse, BasicResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock
        .expect(_restInstanceMock.put(EasyMock.eq(_blocageEquipementUrl), //
            EasyMock.capture(headersCapture), //
            EasyMock.eq(RavelJsonTools.getInstance().toJson(blocageEquipementReq, UpdateBlocageEquipementRequest.class)), //
            EasyMock.capture(queryParamsCapture)))//
        .andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.blocageEquipementModifier(tracabilite, blocageEquipementReq);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());
    checkQueryParams(queryParamsCapture);

    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
  }

  /**
   * Test the method {@link REXConnector#blocageEquipementSupprimer(Tracabilite, String)} httpStatus 400
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testBlocageEquipementSupprimer_KO_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);

    Retour retour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, Response.Status.BAD_REQUEST.getReasonPhrase());
    BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = RavelJsonTools.getInstance().toJson(basicResponse, BasicResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(400).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.delete(EasyMock.eq(_blocageEquipementUrl), //
        EasyMock.capture(headersCapture), //
        EasyMock.eq(null), //
        EasyMock.capture(queryParamsCapture)))//
        .andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.blocageEquipementSupprimer(tracabilite, null);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture);

    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);

  }

  /**
   * Test the method {@link REXConnector#blocageEquipementSupprimer} httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testBlocageEquipementSupprimer_OK_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);

    Retour retour = RetourFactory.createOkRetour();
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = RavelJsonTools.getInstance().toJson(basicResponse, BasicResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    String idBlocageEqpt = "1234";

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.delete(EasyMock.eq(_blocageEquipementUrl), //
        EasyMock.capture(headersCapture), //
        EasyMock.eq(null), //
        EasyMock.capture(queryParamsCapture)))//
        .andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.blocageEquipementSupprimer(tracabilite, idBlocageEqpt);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());
    checkQueryParams(queryParamsCapture, ID_BLOCAGE_EQUIPEMENT, idBlocageEqpt);

    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
  }

  /**
   * Test the method {@link REXConnector#cleRechercheBlocageEquipementCreerListe} httpStatus 400
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testCleRechercheBlocageEquipementCreerListe_KO_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);

    ListeCleRechercheBlocageEquipementRequest listeCleRecherche = new ListeCleRechercheBlocageEquipementRequest(null);

    Retour retour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, Response.Status.BAD_REQUEST.getReasonPhrase());
    BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = RavelJsonTools.getInstance().toJson(basicResponse, BasicResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(400).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(_cleRechercheBlocageEquipementUrl), EasyMock.capture(headersCapture), EasyMock.eq(RavelJsonTools.getInstance().toJson(listeCleRecherche, ListeCleRechercheBlocageEquipementRequest.class)), EasyMock.capture(queryParamsCapture)))//
        .andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.cleRechercheBlocageEquipementCreerListe(tracabilite, listeCleRecherche);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture);

    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
  }

  /**
   * Test the method {@link REXConnector#cleRechercheBlocageEquipementCreerListe} httpStatus 200 jsonResponse null
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testCleRechercheBlocageEquipementCreerListe_KO_002() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    ListeCleRechercheBlocageEquipementRequest listeCleRechercheReq = new ListeCleRechercheBlocageEquipementRequest(null);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock
        .expect(_restInstanceMock.post(EasyMock.eq(_cleRechercheBlocageEquipementUrl), //
            EasyMock.capture(headersCapture), //
            EasyMock.eq(RavelJsonTools.getInstance().toJson(listeCleRechercheReq, ListeCleRechercheBlocageEquipementRequest.class)), //
            EasyMock.capture(queryParamsCapture)))//
        .andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    ConnectorResponse<Retour, Nothing> result = null;

    PowerMock.replayAll();
    result = _connector.cleRechercheBlocageEquipementCreerListe(tracabilite, listeCleRechercheReq);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture);

    Retour expectedRetour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, JSON_ERROR_MESSAGE);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method {@link REXConnector#cleRechercheBlocageEquipementCreerListe} httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testCleRechercheBlocageEquipementCreerListe_OK_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final ListeCleRechercheBlocageEquipementRequest listeCleRechercheBlocageEquipementRequest = _podam.manufacturePojoWithFullData(ListeCleRechercheBlocageEquipementRequest.class);
    final Retour retour = RetourFactory.createOkRetour();
    final String partnerResponse = "{\"retour\":" + RavelJsonTools.getInstance().toJson(retour, Retour.class) + "}"; //$NON-NLS-1$//$NON-NLS-2$

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock
        .expect(_restInstanceMock.post(EasyMock.eq(_cleRechercheBlocageEquipementUrl), //
            EasyMock.capture(headersCapture), //
            EasyMock.eq(RavelJsonTools.getInstance().toJson(listeCleRechercheBlocageEquipementRequest, ListeCleRechercheBlocageEquipementRequest.class)), //
            EasyMock.capture(queryParamsCapture)))//
        .andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.cleRechercheBlocageEquipementCreerListe(tracabilite, listeCleRechercheBlocageEquipementRequest);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
  }

  /**
   * Test the method {@link REXConnector#cleRechercheNotificationReseau}httpStatus 400**
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testCleRechercheNotificationReseau_KO_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);

    Retour retour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, Response.Status.BAD_REQUEST.getReasonPhrase());
    BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = RavelJsonTools.getInstance().toJson(basicResponse, BasicResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(400).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(_cleRechercheNotificationReseauUrl), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.cleRechercheNotificationReseau(tracabilite, null);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture);

    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
  }

  /**
   * Test the method {@link REXConnector#cleRechercheNotificationReseau} httpStatus 200 jsonResponse null
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testCleRechercheNotificationReseau_KO_002() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock
        .expect(_restInstanceMock.post(EasyMock.eq(_cleRechercheNotificationReseauUrl), //
            EasyMock.capture(headersCapture), //
            EasyMock.eq(null), //
            EasyMock.capture(queryParamsCapture)))//
        .andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    ConnectorResponse<Retour, Nothing> result = _connector.cleRechercheNotificationReseau(tracabilite, null);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture);

    Retour expectedRetour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, JSON_ERROR_MESSAGE);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method
   * {@link REXConnector#cleRechercheNotificationReseau(Tracabilite, ListeCleRechercheNotificationReseauRequest)}
   * httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testCleRechercheNotificationReseau_OK_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final ListeCleRechercheNotificationReseauRequest listeCleRechercheNotificationReseauRequest = _podam.manufacturePojoWithFullData(ListeCleRechercheNotificationReseauRequest.class);
    final Retour retour = RetourFactory.createOkRetour();
    final String partnerResponse = "{\"retour\":" + RavelJsonTools.getInstance().toJson(retour, Retour.class) + "}"; //$NON-NLS-1$//$NON-NLS-2$

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(_cleRechercheNotificationReseauUrl), EasyMock.capture(headersCapture), EasyMock.eq(RavelJsonTools.getInstance().toJson(listeCleRechercheNotificationReseauRequest, ListeCleRechercheNotificationReseauRequest.class)), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.cleRechercheNotificationReseau(tracabilite, listeCleRechercheNotificationReseauRequest);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
  }

  /**
   * Test the method {@link REXConnector#cleRechercheOperationVieReseauCreerListe} httpStatus 400
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testCleRechercheOperationVieReseauCreerListe_KO_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);

    Retour retour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, Response.Status.BAD_REQUEST.getReasonPhrase());
    BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = RavelJsonTools.getInstance().toJson(basicResponse, BasicResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(400).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(_cleRechercheOperationVieReseauUrl), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.cleRechercheOperationVieReseauCreerListe(tracabilite, null);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture);

    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
  }

  /**
   * Test the method {@link REXConnector#cleRechercheOperationVieReseauCreerListe} httpStatus 200 jsonResponse null
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testCleRechercheOperationVieReseauCreerListe_KO_002() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock
        .expect(_restInstanceMock.post(EasyMock.eq(_cleRechercheOperationVieReseauUrl), //
            EasyMock.capture(headersCapture), //
            EasyMock.eq(null), //
            EasyMock.capture(queryParamsCapture)))//
        .andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    ConnectorResponse<Retour, Nothing> result = _connector.cleRechercheOperationVieReseauCreerListe(tracabilite, null);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture);

    Retour expectedRetour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, JSON_ERROR_MESSAGE);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method {@link REXConnector#cleRechercheOperationVieReseauCreerListe} httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testCleRechercheOperationVieReseauCreerListe_OK_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final ListeCleRechercheOperationVieReseauRequest listeCleRecherche = _podam.manufacturePojoWithFullData(ListeCleRechercheOperationVieReseauRequest.class);

    Retour retour = RetourFactory.createOkRetour();
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = RavelJsonTools.getInstance().toJson(basicResponse, BasicResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock
        .expect(_restInstanceMock.post(EasyMock.eq(_cleRechercheOperationVieReseauUrl), //
            EasyMock.capture(headersCapture), //
            EasyMock.eq(RavelJsonTools.getInstance().toJson(listeCleRecherche, ListeCleRechercheOperationVieReseauRequest.class)), //
            EasyMock.capture(queryParamsCapture)))//
        .andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.cleRechercheOperationVieReseauCreerListe(tracabilite, listeCleRecherche);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());
    checkQueryParams(queryParamsCapture);

    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
  }

  /**
   * Test the method
   * {@link REXConnector#comparaisonCommercialeCompositeCreer(Tracabilite, CreateComparaisonCommercialeCompositeRequest)}
   * httpStatus 400
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testComparaisonCommercialeCompositeCreer_KO_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final ComparaisonCommerciale comparaisonCommerciale = _podam.manufacturePojo(ComparaisonCommerciale.class);
    CreateComparaisonCommercialeCompositeRequest comparaisonCommercialeRequest = new CreateComparaisonCommercialeCompositeRequest(comparaisonCommerciale);
    Retour retour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, Response.Status.BAD_REQUEST.getReasonPhrase());
    final String partnerResponse = "{\"retour\":" + GsonTools.getIso8601Ms().toJson(retour) + "}"; //$NON-NLS-1$//$NON-NLS-2$

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(400).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(_comparaisonCommercialeCompositeUrl), EasyMock.capture(headersCapture), EasyMock.eq(GsonTools.getIso8601Ms().toJson(comparaisonCommercialeRequest)), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.comparaisonCommercialeCompositeCreer(tracabilite, comparaisonCommercialeRequest);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture);

    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
  }

  /**
   * Test the method
   * {@link REXConnector#comparaisonCommercialeCompositeCreer(Tracabilite, CreateComparaisonCommercialeCompositeRequest)}
   * httpStatus 200 jsonResponse null
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testComparaisonCommercialeCompositeCreer_KO_002() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    CreateComparaisonCommercialeCompositeRequest comparaisonCommercialeRequest = new CreateComparaisonCommercialeCompositeRequest(new ComparaisonCommerciale(null, null));

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(_comparaisonCommercialeCompositeUrl), EasyMock.capture(headersCapture), EasyMock.eq(GsonTools.getIso8601Ms().toJson(comparaisonCommercialeRequest)), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    ConnectorResponse<Retour, Nothing> result = null;

    PowerMock.replayAll();
    result = _connector.comparaisonCommercialeCompositeCreer(tracabilite, comparaisonCommercialeRequest);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture);

    Retour expectedRetour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, JSON_ERROR_MESSAGE);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method
   * {@link REXConnector#comparaisonCommercialeCompositeCreer(Tracabilite, CreateComparaisonCommercialeCompositeRequest)}
   * httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testComparaisonCommercialeCompositeCreer_OK_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final ComparaisonCommerciale comparaisonCommerciale = _podam.manufacturePojo(ComparaisonCommerciale.class);
    CreateComparaisonCommercialeCompositeRequest comparaisonCommercialeRequest = new CreateComparaisonCommercialeCompositeRequest(comparaisonCommerciale);
    final Retour retour = RetourFactory.createOkRetour();
    final String partnerResponse = "{\"retour\":" + GsonTools.getIso8601Ms().toJson(retour) + "}"; //$NON-NLS-1$//$NON-NLS-2$

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(_comparaisonCommercialeCompositeUrl), EasyMock.capture(headersCapture), EasyMock.eq(GsonTools.getIso8601Ms().toJson(comparaisonCommercialeRequest)), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.comparaisonCommercialeCompositeCreer(tracabilite, comparaisonCommercialeRequest);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture);

    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
  }

  /**
   * Test the method {@link REXConnector#comparaisonCommercialeCompositeLireTousParIdCmd(Tracabilite, String)}
   * httpStatus 200 idCmd inconnu
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testComparaisonCommercialeCompositeLireDernierParIdCmd_KO_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final ComparaisonCommerciale comparaisonCommerciale = _podam.manufacturePojo(ComparaisonCommerciale.class);
    final Retour retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "idCmd " + comparaisonCommerciale.getIdCmd() + " inconnu"); //$NON-NLS-1$ //$NON-NLS-2$
    final String partnerResponse = "{\"retour\":" + GsonTools.getIso8601Ms().toJson(retour) + "}"; //$NON-NLS-1$//$NON-NLS-2$

    // construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_comparaisonCommercialeCompositeUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<ComparaisonCommerciale>> result = _connector.comparaisonCommercialeCompositeLireTousParIdCmd(tracabilite, comparaisonCommerciale.getIdCmd());
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, ID_CMD, comparaisonCommerciale.getIdCmd());

    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
    Assert.assertEquals(0, result._second.size());
  }

  /**
   * Test the method {@link REXConnector#comparaisonCommercialeCompositeLireTousParIdCmd(Tracabilite, String)}
   * httpStatus 400
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testComparaisonCommercialeCompositeLireDernierParIdCmd_KO_002() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final Retour retour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, JSON_ERROR_MESSAGE);

    // construct response
    final Response response = new ResponseBuilderImpl().status(500).build();

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_comparaisonCommercialeCompositeUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);
    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<ComparaisonCommerciale>> result = _connector.comparaisonCommercialeCompositeLireTousParIdCmd(tracabilite, StringConstants.EMPTY_STRING);
    PowerMock.verifyAll();

    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method {@link REXConnector#comparaisonCommercialeCompositeLireTousParIdCmd(Tracabilite, String)}
   * httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testComparaisonCommercialeCompositeLireDernierParIdCmd_OK_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final ComparaisonCommerciale comparaisonCommerciale = _podam.manufacturePojo(ComparaisonCommerciale.class);
    final Retour retour = RetourFactory.createOkRetour();
    final String partnerResponse = "{\"retour\":" + GsonTools.getIso8601Ms().toJson(retour) + "," + "\"listeComparaisonCommercialeComposite\":[" + GsonTools.getIso8601Ms().toJson(comparaisonCommerciale) + "]}"; //$NON-NLS-1$//$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_comparaisonCommercialeCompositeUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<ComparaisonCommerciale>> result = _connector.comparaisonCommercialeCompositeLireTousParIdCmd(tracabilite, comparaisonCommerciale.getIdCmd());
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, ID_CMD, comparaisonCommerciale.getIdCmd());

    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
    Assert.assertEquals(1, result._second.size());
    Assert.assertEquals(comparaisonCommerciale, result._second.get(0));
  }

  /**
   * Test the method {@link REXConnector#decisionExploitationLireUn(Tracabilite, String)} httpStatus 200 donnes inconue
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testDecisionExploitationLireUn_KO_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final DecisionExploitation element = _podam.manufacturePojo(DecisionExploitation.class);
    final Retour retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "");
    final String expectedResponse = "{\"retour\":" + RavelJsonTools.getInstance().toJson(retour, Retour.class) + "}"; //$NON-NLS-1$//$NON-NLS-2$

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(expectedResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_configurationProsperUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    String nom = element.getNom();
    final ConnectorResponse<Retour, DecisionExploitation> result = _connector.decisionExploitationLireUn(tracabilite, nom);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, NOM, nom);
    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method {@link REXConnector#decisionExploitationLireUn(Tracabilite, String)} httpStatus 200 donnes inconue
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testDecisionExploitationLireUn_KO_002() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final DecisionExploitation element = _podam.manufacturePojo(DecisionExploitation.class);
    element.setNom(null);
    final Retour retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.DONNEE_INVALIDE, "");
    final String expectedResponse = "{\"retour\":" + RavelJsonTools.getInstance().toJson(retour, Retour.class) + "}"; //$NON-NLS-1$//$NON-NLS-2$

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(expectedResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_configurationProsperUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    String nom = element.getNom();
    final ConnectorResponse<Retour, DecisionExploitation> result = _connector.decisionExploitationLireUn(tracabilite, nom);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, NOM, nom);
    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method {@link REXConnector#decisionExploitationLireUn(Tracabilite, String)} httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testDecisionExploitationLireUn_OK_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final DecisionExploitation element = _podam.manufacturePojo(DecisionExploitation.class);

    final Retour retour = RetourFactory.createOkRetour();
    final String expectedResponse = "{\"retour\":" + RavelJsonTools.getInstance().toJson(retour, Retour.class) + "," + "\"" + "listeDecisionExploitation" + "\":[" + RavelJsonTools.getInstance().toJson(element, DecisionExploitation.class) + "]}"; //$NON-NLS-1$//$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(expectedResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_configurationProsperUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    String nom = element.getNom();
    final ConnectorResponse<Retour, DecisionExploitation> result = _connector.decisionExploitationLireUn(tracabilite, nom);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, NOM, nom);
    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
    Assert.assertNotNull(result._second);
    Assert.assertEquals(element, result._second);
  }

  /**
   * Test the method {@link REXConnector#cleRechercheBlocageEquipementCreerListe} httpStatus 200 statut inconnu
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testErreurSpiritCleRechercheBlocageEquipementCreerListe_KO_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);

    // construct response
    final Retour retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "statut " + "xxx" + " inconnu"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = RavelJsonTools.getInstance().toJson(basicResponse, BasicResponse.class);
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(_cleRechercheBlocageEquipementUrl), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.cleRechercheBlocageEquipementCreerListe(tracabilite, null);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method {@link REXConnector#erreurSpiritCreer(Tracabilite, CreateErreurSpiritRequest)} httpStatus 400
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testErreurSpiritCreer_KO_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final ErreurSpirit erreurSpirit = _podam.manufacturePojo(ErreurSpirit.class);
    CreateErreurSpiritRequest createErreurSpiritRequest = new CreateErreurSpiritRequest(erreurSpirit);
    Retour retour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, Response.Status.BAD_REQUEST.getReasonPhrase());
    final String partnerResponse = "{\"retour\":" + GsonTools.getIso8601Ms().toJson(retour) + "}"; //$NON-NLS-1$//$NON-NLS-2$

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(400).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(_erreurSpiritUrl), EasyMock.capture(headersCapture), EasyMock.eq(GsonTools.getIso8601Ms().toJson(createErreurSpiritRequest)), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.erreurSpiritCreer(tracabilite, createErreurSpiritRequest);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture);

    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
  }

  /**
   * Test the method {@link REXConnector#erreurSpiritCreer(Tracabilite, CreateErreurSpiritRequest)} httpStatus 200
   * jsonResponse null
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testErreurSpiritCreer_KO_002() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    CreateErreurSpiritRequest createErreurSpiritRequest = new CreateErreurSpiritRequest(null);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(_erreurSpiritUrl), EasyMock.capture(headersCapture), EasyMock.eq(GsonTools.getIso8601Ms().toJson(createErreurSpiritRequest)), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    ConnectorResponse<Retour, Nothing> result = null;

    PowerMock.replayAll();
    result = _connector.erreurSpiritCreer(tracabilite, createErreurSpiritRequest);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture);

    Retour expectedRetour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, JSON_ERROR_MESSAGE);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method {@link REXConnector#erreurSpiritCreer(Tracabilite, CreateErreurSpiritRequest)} httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testErreurSpiritCreer_OK_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final ErreurSpirit erreurSpirit = _podam.manufacturePojo(ErreurSpirit.class);
    CreateErreurSpiritRequest createErreurSpiritRequest = new CreateErreurSpiritRequest(erreurSpirit);
    final Retour retour = RetourFactory.createOkRetour();
    final String partnerResponse = "{\"retour\":" + GsonTools.getIso8601Ms().toJson(retour) + "}"; //$NON-NLS-1$//$NON-NLS-2$

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(_erreurSpiritUrl), EasyMock.capture(headersCapture), EasyMock.eq(GsonTools.getIso8601Ms().toJson(createErreurSpiritRequest)), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.erreurSpiritCreer(tracabilite, createErreurSpiritRequest);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture);

    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
  }

  /**
   * Test the method {@link REXConnector#erreurSpiritLireTousParStatutPeriod(Tracabilite, String, String, String)}
   * httpStatus 200 statut inconnu
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testErreurSpiritLireTousParStatutPeriod_KO_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final Retour retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "statut " + "xxx" + " inconnu"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    final String partnerResponse = "{\"retour\":" + GsonTools.getIso8601Ms().toJson(retour) + "}"; //$NON-NLS-1$//$NON-NLS-2$

    // construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_erreurSpiritUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<ErreurSpirit>> result = _connector.erreurSpiritLireTousParStatutPeriod(tracabilite, "xxx", "dateDeb", "dateFin"); //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, STATUT, "xxx"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, DATE_DEB, "dateDeb"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, DATE_FIN, "dateFin"); //$NON-NLS-1$

    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
    Assert.assertEquals(Collections.emptyList(), result._second);
  }

  /**
   * Test the method {@link REXConnector#erreurSpiritLireTousParStatutPeriod(Tracabilite, String, String, String)}
   * httpStatus 200 json null
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testErreurSpiritLireTousParStatutPeriod_KO_002() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);

    // construct response
    final Response response = new ResponseBuilderImpl().status(200).build();

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_erreurSpiritUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    ConnectorResponse<Retour, List<ErreurSpirit>> result = null;
    PowerMock.replayAll();
    result = _connector.erreurSpiritLireTousParStatutPeriod(tracabilite, "statut", "dateDeb", "dateFin"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, STATUT, "statut"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, DATE_DEB, "dateDeb"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, DATE_FIN, "dateFin"); //$NON-NLS-1$

    Retour expectedRetour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, JSON_ERROR_MESSAGE);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method {@link REXConnector#erreurSpiritLireTousParStatutPeriod(Tracabilite, String, String, String)}
   * httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testErreurSpiritLireTousParStatutPeriod_OK_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final ErreurSpirit erreurSpirit = _podam.manufacturePojo(ErreurSpirit.class);
    final Retour retour = RetourFactory.createOkRetour();
    final String partnerResponse = "{\"retour\":" + GsonTools.getIso8601Ms().toJson(retour) + "," + "\"listeErreurSpirit\":[" + GsonTools.getIso8601Ms().toJson(erreurSpirit) + "]}"; //$NON-NLS-1$//$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_erreurSpiritUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    ConnectorResponse<Retour, List<ErreurSpirit>> result = null;
    PowerMock.replayAll();
    result = _connector.erreurSpiritLireTousParStatutPeriod(tracabilite, "statut", "dateDeb", "dateFin"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, STATUT, "statut"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, DATE_DEB, "dateDeb"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, DATE_FIN, "dateFin"); //$NON-NLS-1$
    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
    Assert.assertNotNull(result._second);
    Assert.assertEquals(erreurSpirit, result._second.get(0));
  }

  /**
   * Test the method {@link REXConnector#erreurSpiritLireTousSurPeriod(Tracabilite, String, String)} httpStatus 200
   * statut inconnu
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testErreurSpiritLireTousSurPeriod_KO_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final Retour retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "dateDeb " + "xxx" + " inconnu"); //$NON-NLS-1$ //$NON-NLS-2$
    final String partnerResponse = "{\"retour\":" + GsonTools.getIso8601Ms().toJson(retour) + "}"; //$NON-NLS-1$//$NON-NLS-2$

    // construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_erreurSpiritUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<ErreurSpirit>> result = _connector.erreurSpiritLireTousSurPeriod(tracabilite, "xxx", "dateFin"); //$NON-NLS-1$ //$NON-NLS-2$
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, DATE_DEB, "xxx"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, DATE_FIN, "dateFin"); //$NON-NLS-1$

    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
    Assert.assertEquals(Collections.emptyList(), result._second);
  }

  /**
   * Test the method {@link REXConnector#erreurSpiritLireTousSurPeriod(Tracabilite, String, String)} httpStatus 200 json
   * null
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testErreurSpiritLireTousSurPeriod_KO_002() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);

    // construct response
    final Response response = new ResponseBuilderImpl().status(200).build();

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_erreurSpiritUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    ConnectorResponse<Retour, List<ErreurSpirit>> result = null;
    PowerMock.replayAll();
    result = _connector.erreurSpiritLireTousSurPeriod(tracabilite, "dateDeb", "dateFin"); //$NON-NLS-1$ //$NON-NLS-2$
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, DATE_DEB, "dateDeb"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, DATE_FIN, "dateFin"); //$NON-NLS-1$

    Retour expectedRetour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, JSON_ERROR_MESSAGE);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method {@link REXConnector#erreurSpiritLireTousSurPeriod(Tracabilite, String, String)} httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testErreurSpiritLireTousSurPeriod_OK_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final ErreurSpirit erreurSpirit = _podam.manufacturePojo(ErreurSpirit.class);
    final Retour retour = RetourFactory.createOkRetour();
    final String partnerResponse = "{\"retour\":" + GsonTools.getIso8601Ms().toJson(retour) + "," + "\"listeErreurSpirit\":[" + GsonTools.getIso8601Ms().toJson(erreurSpirit) + "]}"; //$NON-NLS-1$//$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_erreurSpiritUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    ConnectorResponse<Retour, List<ErreurSpirit>> result = null;
    PowerMock.replayAll();
    result = _connector.erreurSpiritLireTousSurPeriod(tracabilite, "dateDeb", "dateFin"); //$NON-NLS-1$ //$NON-NLS-2$
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, DATE_DEB, "dateDeb"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, DATE_FIN, "dateFin"); //$NON-NLS-1$
    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
    Assert.assertNotNull(result._second);
    Assert.assertEquals(erreurSpirit, result._second.get(0));
  }

  /**
   * Test the method {@link REXConnector#erreurSpiritLireUn(Tracabilite, String)} httpStatus 200 statut inconnu
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testErreurSpiritLireUn_KO_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final Retour retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "idErreurSpirit " + "xxx" + " inconnu"); //$NON-NLS-1$ //$NON-NLS-2$
    final String partnerResponse = "{\"retour\":" + GsonTools.getIso8601Ms().toJson(retour) + "}"; //$NON-NLS-1$//$NON-NLS-2$

    // construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_erreurSpiritUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<ErreurSpirit>> result = _connector.erreurSpiritLireUn(tracabilite, "xxx"); //$NON-NLS-1$
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, ID_ERREUR_SPIRIT, "xxx"); //$NON-NLS-1$

    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
    Assert.assertEquals(Collections.emptyList(), result._second);
  }

  /**
   * Test the method {@link REXConnector#erreurSpiritLireUn(Tracabilite, String)} httpStatus 200 json null
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testErreurSpiritLireUn_KO_002() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);

    // construct response
    final Response response = new ResponseBuilderImpl().status(200).build();

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_erreurSpiritUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    ConnectorResponse<Retour, List<ErreurSpirit>> result = null;
    PowerMock.replayAll();
    result = _connector.erreurSpiritLireUn(tracabilite, "idErreurSpirit"); //$NON-NLS-1$
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, ID_ERREUR_SPIRIT, "idErreurSpirit"); //$NON-NLS-1$

    Retour expectedRetour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, JSON_ERROR_MESSAGE);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method {@link REXConnector#erreurSpiritLireUn(Tracabilite, String)} httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testErreurSpiritLireUn_OK_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final ErreurSpirit erreurSpirit = _podam.manufacturePojo(ErreurSpirit.class);
    final Retour retour = RetourFactory.createOkRetour();
    final String partnerResponse = "{\"retour\":" + GsonTools.getIso8601Ms().toJson(retour) + "," + "\"listeErreurSpirit\":[" + GsonTools.getIso8601Ms().toJson(erreurSpirit) + "]}"; //$NON-NLS-1$//$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_erreurSpiritUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    ConnectorResponse<Retour, List<ErreurSpirit>> result = null;
    PowerMock.replayAll();
    result = _connector.erreurSpiritLireUn(tracabilite, "idErreurSpirit"); //$NON-NLS-1$
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, ID_ERREUR_SPIRIT, "idErreurSpirit"); //$NON-NLS-1$
    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
    Assert.assertNotNull(result._second);
    Assert.assertEquals(erreurSpirit, result._second.get(0));
  }

  /**
   * Test the method {@link REXConnector#erreurSpiritModifierStatut(Tracabilite, UpdateErreurSpiritRequest)} httpStatus
   * 400
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testErreurSpiritModifierStatut_KO_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    UpdateErreurSpiritRequest updateErreurSpiritRequest = new UpdateErreurSpiritRequest("xxx", "xxx"); //$NON-NLS-1$ //$NON-NLS-2$
    Retour retour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, Response.Status.BAD_REQUEST.getReasonPhrase());
    final String partnerResponse = "{\"retour\":" + GsonTools.getIso8601Ms().toJson(retour) + "}"; //$NON-NLS-1$//$NON-NLS-2$

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(400).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_erreurSpiritUrl), EasyMock.capture(headersCapture), EasyMock.eq(GsonTools.getIso8601Ms().toJson(updateErreurSpiritRequest)), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.erreurSpiritModifierStatut(tracabilite, updateErreurSpiritRequest);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture);

    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
  }

  /**
   * Test the method {@link REXConnector#erreurSpiritModifierStatut(Tracabilite, UpdateErreurSpiritRequest)} httpStatus
   * 200 jsonResponse null
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testErreurSpiritModifierStatut_KO_002() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    UpdateErreurSpiritRequest updateErreurSpiritRequest = new UpdateErreurSpiritRequest(null, null);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_erreurSpiritUrl), EasyMock.capture(headersCapture), EasyMock.eq(GsonTools.getIso8601Ms().toJson(updateErreurSpiritRequest)), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    ConnectorResponse<Retour, Nothing> result = null;

    PowerMock.replayAll();
    result = _connector.erreurSpiritModifierStatut(tracabilite, updateErreurSpiritRequest);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture);

    Retour expectedRetour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, JSON_ERROR_MESSAGE);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method {@link REXConnector#erreurSpiritModifierStatut(Tracabilite, UpdateErreurSpiritRequest)} httpStatus
   * 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testErreurSpiritModifierStatut_OK_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    UpdateErreurSpiritRequest updateErreurSpiritRequest = new UpdateErreurSpiritRequest("idErreurSpirit", "statut"); //$NON-NLS-1$ //$NON-NLS-2$
    final Retour retour = RetourFactory.createOkRetour();
    final String partnerResponse = "{\"retour\":" + GsonTools.getIso8601Ms().toJson(retour) + "}"; //$NON-NLS-1$//$NON-NLS-2$

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_erreurSpiritUrl), EasyMock.capture(headersCapture), EasyMock.eq(GsonTools.getIso8601Ms().toJson(updateErreurSpiritRequest)), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.erreurSpiritModifierStatut(tracabilite, updateErreurSpiritRequest);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture);

    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
  }

  /**
   * Test the method {@link REXConnector#historisationEligibiliteCreer(Tracabilite, HistorisationEligibilite)}
   * httpStatus 200 idReconciliation inconnu
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testHistorisationEligibiliteCreer_KO_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);

    HistorisationEligibilite historisationEligibilite = new HistorisationEligibilite(ID_HISTORISATION_ELIGIBILITE, "nomProcessus_p", LocalDateTime.now().minusMinutes(2), LocalDateTime.now().minusMinutes(1), "demandeEligibilite_p", "reponseEligibilite_p");

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(_historisationEligibiliteUrl), EasyMock.capture(headersCapture), EasyMock.eq(RavelJsonTools.getInstance().toJson(historisationEligibilite, HistorisationEligibilite.class)), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    ConnectorResponse<Retour, Nothing> result = null;

    PowerMock.replayAll();
    result = _connector.historisationEligibiliteCreer(tracabilite, historisationEligibilite);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture);

    Retour expectedRetour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, JSON_ERROR_MESSAGE);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method {@link REXConnector#historisationEligibiliteCreer(Tracabilite, HistorisationEligibilite)}
   * httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testHistorisationEligibiliteCreer_OK_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    HistorisationEligibilite historisationEligibilite = new HistorisationEligibilite(ID_HISTORISATION_ELIGIBILITE, "nomProcessus_p", LocalDateTime.now().minusMinutes(2), LocalDateTime.now().minusMinutes(1), "demandeEligibilite_p", "reponseEligibilite_p");
    final Retour retour = RetourFactory.createOkRetour();
    final String partnerResponse = "{\"retour\":" + RavelJsonTools.getInstance().toJson(retour, Retour.class) + "}"; //$NON-NLS-1$//$NON-NLS-2$

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(_historisationEligibiliteUrl), EasyMock.capture(headersCapture), EasyMock.eq(RavelJsonTools.getInstance().toJson(historisationEligibilite, HistorisationEligibilite.class)), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.historisationEligibiliteCreer(tracabilite, historisationEligibilite);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
  }

  /**
   * Test the method {@link REXConnector#notificationReseauCreer(Tracabilite, AbstractNotificationReseau)} httpStatus
   * 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testNotificationReseauCreer_OK_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final AbstractNotificationReseau notificationReseau = _podam.manufacturePojoWithFullData(NotificationReseauONTInconnuJSON.class);
    final Retour retour = RetourFactory.createOkRetour();
    final String partnerResponse = "{\"retour\":" + RavelJsonTools.getInstance().toJson(retour, Retour.class) + "}"; //$NON-NLS-1$//$NON-NLS-2$

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(_notificationReseauUrl), EasyMock.capture(headersCapture), EasyMock.eq(RavelJsonTools.getInstance().toJson(notificationReseau, NotificationReseauONTInconnuJSON.class)), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.notificationReseauCreer(tracabilite, notificationReseau);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
  }

  /**
   * Test the method {@link REXConnector#notificationReseauLireUn(Tracabilite, String)} httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testNotificationReseauLireUn_OK_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final NotificationReseau notificationReseau = _podam.manufacturePojoWithFullData(NotificationReseauOntInconnu.class);
    notificationReseau.setTypeNotificationReseau(NotificationReseauType.ONT_INCONNU.name());
    final Retour retour = RetourFactory.createOkRetour();
    final GetNotificationReseauResponse getNotificationReseauResponse = new GetNotificationReseauResponse(RetourConverter.convertToJsonRetour(retour), Arrays.asList(notificationReseau));
    final String partnerResponse = RavelJsonTools.getInstance().toJson(getNotificationReseauResponse, GetNotificationReseauResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_notificationReseauUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, AbstractNotificationReseau> result = _connector.notificationReseauLireUn(tracabilite, notificationReseau.getIdNotificationReseau());
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, PARAM_ID_NOTIFICATION_RESEAU, notificationReseau.getIdNotificationReseau());
    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
    Assert.assertNotNull(result._second);
    Assert.assertEquals(notificationReseau.getIdNotificationReseau(), result._second.getIdNotificationReseau());
  }

  /**
   * Test the method
   * {@link REXConnector#notificationReseauModifierStatut(Tracabilite, UpdateNotificationReseauStatutRequest)}
   * httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testNotificationReseauModifierStatut_OK_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final Retour retour = RetourFactory.createOkRetour();
    final String partnerResponse = "{\"retour\":" + RavelJsonTools.getInstance().toJson(retour, Retour.class) + "}"; //$NON-NLS-1$//$NON-NLS-2$

    UpdateNotificationReseauStatutRequest request = new UpdateNotificationReseauStatutRequest(RandomStringUtils.randomAlphanumeric(10), NotificationReseauStatut.TRAITE_OK.name());

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<UpdateNotificationReseauStatutRequest> queryRequestCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_notificationReseauUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryRequestCapture), EasyMock.eq(null))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    ConnectorResponse<Retour, Nothing> result = null;

    PowerMock.replayAll();
    result = _connector.notificationReseauModifierStatut(tracabilite, request);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    Assert.assertEquals(RavelJsonTools.getInstance().toJson(request, UpdateNotificationReseauStatutRequest.class), queryRequestCapture.getValue());

    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
  }

  /**
   * Test the method {@link REXConnector#operationVieReseauCompositeLireTousParCleRecherche} httpStatus 400
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testOperationVieReseauCompositeLireTousParCleRecherche_KO_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);

    Retour retour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, Response.Status.BAD_REQUEST.getReasonPhrase());
    BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = RavelJsonTools.getInstance().toJson(basicResponse, BasicResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(400).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_operationVieReseauUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<OperationVieReseau>> result = _connector.operationVieReseauCompositeLireTousParCleRecherche(tracabilite, null, null, null);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture);

    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
    Assert.assertEquals(new ArrayList<OperationVieReseau>(), result._second);

  }

  /**
   * Test the method {@link REXConnector#operationVieReseauCompositeLireTousParCleRecherche} httpStatus 200 jsonResponse
   * null
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testOperationVieReseauCompositeLireTousParCleRecherche_KO_002() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock
        .expect(_restInstanceMock.get(EasyMock.eq(_operationVieReseauUrl), //
            EasyMock.capture(headersCapture), //
            EasyMock.capture(queryParamsCapture)))//
        .andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    ConnectorResponse<Retour, List<OperationVieReseau>> result = _connector.operationVieReseauCompositeLireTousParCleRecherche(tracabilite, null, null, null);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture);

    Retour expectedRetour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, JSON_ERROR_MESSAGE);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method {@link REXConnector#operationVieReseauCompositeLireTousParCleRecherche} httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testOperationVieReseauCompositeLireTousParCleRecherche_OK_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);

    String typeOperationVieReseau = _podam.manufacturePojoWithFullData(String.class);
    String typeCle = _podam.manufacturePojoWithFullData(String.class);
    String valeurCle = _podam.manufacturePojoWithFullData(String.class);

    Retour retour = RetourFactory.createOkRetour();
    ListeOperationVieReseauResponse listeOperationVieReseau = new ListeOperationVieReseauResponse(RetourConverter.convertToJsonRetour(retour));
    List<OperationVieReseau> listOpVieReseau = new ArrayList<>();
    listOpVieReseau.add(_podam.manufacturePojo(OperationVieReseau.class));
    listeOperationVieReseau.setOperationVieReseauList(listOpVieReseau);

    final String partnerResponse = RavelJsonTools.getInstance().toJson(listeOperationVieReseau, ListeOperationVieReseauResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock
        .expect(_restInstanceMock.get(EasyMock.eq(_operationVieReseauUrl), //
            EasyMock.capture(headersCapture), //
            EasyMock.capture(queryParamsCapture)))//
        .andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<OperationVieReseau>> result = _connector.operationVieReseauCompositeLireTousParCleRecherche(tracabilite, //
        typeOperationVieReseau, //
        typeCle, //
        valeurCle);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());
    checkQueryParams(queryParamsCapture, TYPE_OPERATION_VIE_RESEAU, typeOperationVieReseau, //
        TYPE_CLE, typeCle, //
        VALEUR_CLE, valeurCle);
    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
    Assert.assertEquals(listeOperationVieReseau.getOperationVieReseauList(), result._second);

  }

  /**
   * Test the method {@link REXConnector#operationVieReseauCreer} httpStatus 400
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testOperationVieReseauCreer_KO_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);

    Retour retour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, Response.Status.BAD_REQUEST.getReasonPhrase());
    BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = RavelJsonTools.getInstance().toJson(basicResponse, BasicResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(400).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(_operationVieReseauUrl), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.operationVieReseauCreer(tracabilite, null);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture);

    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
  }

  /**
   * Test the method {@link REXConnector#operationVieReseauCreer} httpStatus 200 jsonResponse null
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testOperationVieReseauCreer_KO_002() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock
        .expect(_restInstanceMock.post(EasyMock.eq(_operationVieReseauUrl), //
            EasyMock.capture(headersCapture), //
            EasyMock.eq(null), //
            EasyMock.capture(queryParamsCapture)))//
        .andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    ConnectorResponse<Retour, Nothing> result = _connector.operationVieReseauCreer(tracabilite, null);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture);

    Retour expectedRetour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, JSON_ERROR_MESSAGE);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method {@link REXConnector#operationVieReseauCreer} httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testOperationVieReseauCreer_OK_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final OperationVieReseau opVieReseau = _podam.manufacturePojoWithFullData(OperationVieReseau.class);

    Retour retour = RetourFactory.createOkRetour();
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = RavelJsonTools.getInstance().toJson(basicResponse, BasicResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock
        .expect(_restInstanceMock.post(EasyMock.eq(_operationVieReseauUrl), //
            EasyMock.capture(headersCapture), //
            EasyMock.eq(RavelJsonTools.getInstance().toJson(opVieReseau, OperationVieReseau.class)), //
            EasyMock.capture(queryParamsCapture)))//
        .andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.operationVieReseauCreer(tracabilite, opVieReseau);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());
    checkQueryParams(queryParamsCapture);

    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
  }

  /**
   * Test the method {@link REXConnector#operationVieReseauLireUn} httpStatus 400
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testOperationVieReseauLireUn_KO_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);

    Retour retour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, Response.Status.BAD_REQUEST.getReasonPhrase());
    BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = RavelJsonTools.getInstance().toJson(basicResponse, BasicResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(400).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_operationVieReseauUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, OperationVieReseau> result = _connector.operationVieReseauLireUn(tracabilite, null);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture);

    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);

  }

  /**
   * Test the method {@link REXConnector#operationVieReseauLireUn} httpStatus 200 jsonResponse null
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testOperationVieReseauLireUn_KO_002() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock
        .expect(_restInstanceMock.get(EasyMock.eq(_operationVieReseauUrl), //
            EasyMock.capture(headersCapture), //
            EasyMock.capture(queryParamsCapture)))//
        .andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    ConnectorResponse<Retour, OperationVieReseau> result = _connector.operationVieReseauLireUn(tracabilite, null);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture);

    Retour expectedRetour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, JSON_ERROR_MESSAGE);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method {@link REXConnector#operationVieReseauLireUn} httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testOperationVieReseauLireUn_OK_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);

    String idOperationVieReseau = _podam.manufacturePojoWithFullData(String.class);

    Retour retour = RetourFactory.createOkRetour();
    ListeOperationVieReseauResponse listeOperationVieReseau = _podam.manufacturePojo(ListeOperationVieReseauResponse.class);
    JUnitTools.setInaccessibleFieldValue(listeOperationVieReseau, "_retour", RetourConverter.convertToJsonRetour(retour)); //$NON-NLS-1$

    final String partnerResponse = RavelJsonTools.getInstance().toJson(listeOperationVieReseau, ListeOperationVieReseauResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock
        .expect(_restInstanceMock.get(EasyMock.eq(_operationVieReseauUrl), //
            EasyMock.capture(headersCapture), //
            EasyMock.capture(queryParamsCapture)))//
        .andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, OperationVieReseau> result = _connector.operationVieReseauLireUn(tracabilite, idOperationVieReseau);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());
    checkQueryParams(queryParamsCapture, ID_OPERATION_VIE_RESEAU, idOperationVieReseau);
    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
    Assert.assertEquals(listeOperationVieReseau.getOperationVieReseauList().get(0), result._second);

  }

  /**
   * Test the method {@link REXConnector#operationVieReseauModifierStatut} httpStatus 400
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testOperationVieReseauModifierStatut_KO_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);

    Retour retour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, Response.Status.BAD_REQUEST.getReasonPhrase());
    BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = RavelJsonTools.getInstance().toJson(basicResponse, BasicResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(400).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_operationVieReseauUrl), //
        EasyMock.capture(headersCapture), //
        EasyMock.eq(RavelJsonTools.getInstance().toJson(new OperationVieReseauModifierStatutRequest(), OperationVieReseauModifierStatutRequest.class)), //
        EasyMock.capture(queryParamsCapture))//
    ).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.operationVieReseauModifierStatut(tracabilite, null, null, null, null);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture);

    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
  }

  /**
   * Test the method {@link REXConnector#operationVieReseauModifierStatut} httpStatus 200 jsonResponse null
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testOperationVieReseauModifierStatut_KO_002() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock
        .expect(_restInstanceMock.put(EasyMock.eq(_operationVieReseauUrl), //
            EasyMock.capture(headersCapture), //
            EasyMock.eq(RavelJsonTools.getInstance().toJson(new OperationVieReseauModifierStatutRequest(), OperationVieReseauModifierStatutRequest.class)), //
            EasyMock.capture(queryParamsCapture)))//
        .andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    ConnectorResponse<Retour, Nothing> result = _connector.operationVieReseauModifierStatut(tracabilite, null, null, null, null);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture);

    Retour expectedRetour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, JSON_ERROR_MESSAGE);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method {@link REXConnector#operationVieReseauModifierStatut} httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testOperationVieReseauModifierStatut_OK_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);

    OperationVieReseauModifierStatutRequest updateRequest = _podam.manufacturePojoWithFullData(OperationVieReseauModifierStatutRequest.class);

    Retour retour = RetourFactory.createOkRetour();
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = RavelJsonTools.getInstance().toJson(basicResponse, BasicResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock
        .expect(_restInstanceMock.put(EasyMock.eq(_operationVieReseauUrl), //
            EasyMock.capture(headersCapture), //
            EasyMock.eq(RavelJsonTools.getInstance().toJson(updateRequest, OperationVieReseauModifierStatutRequest.class)), //
            EasyMock.capture(queryParamsCapture)))//
        .andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.operationVieReseauModifierStatut(tracabilite, //
        updateRequest.getIdOperationVieReseau(), //
        updateRequest.getStatut(), //
        updateRequest.getCodeErreur(), //
        updateRequest.getLibelleErreur());
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());
    checkQueryParams(queryParamsCapture);

    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
  }


  /**
   * Test the method {@link REXConnector#operationVieReseauModifierListeClientImpacte} httpStatus 400
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testOperationVieReseauModifierListeClientImpacte_KO_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);

    Retour retour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, Response.Status.BAD_REQUEST.getReasonPhrase());
    BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = RavelJsonTools.getInstance().toJson(basicResponse, BasicResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(400).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    OperationVieReseauModifierListeClientImpacteRequest request = new OperationVieReseauModifierListeClientImpacteRequest();
    request.setClientImpactes(null);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_operationVieReseauUrl), //
        EasyMock.capture(headersCapture), //
        EasyMock.eq(RavelJsonTools.getInstance().toJson(request, OperationVieReseauModifierListeClientImpacteRequest.class)), //
        EasyMock.capture(queryParamsCapture))//
    ).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.operationVieReseauModifierListeClientImpacte(tracabilite, null, new HashSet<>());
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture);

    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
  }

  /**
   * Test the method {@link REXConnector#operationVieReseauModifierListeClientImpacte} httpStatus 200 jsonResponse null
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testOperationVieReseauModifierListeClientImpacte_KO_002() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).build();

    // test scenario
    initializeMocksForSendRequest();
    OperationVieReseauModifierListeClientImpacteRequest request = new OperationVieReseauModifierListeClientImpacteRequest();
    request.setClientImpactes(null);
    EasyMock
        .expect(_restInstanceMock.put(EasyMock.eq(_operationVieReseauUrl), //
            EasyMock.capture(headersCapture), //
            EasyMock.eq(RavelJsonTools.getInstance().toJson(request, OperationVieReseauModifierListeClientImpacteRequest.class)), //
            EasyMock.capture(queryParamsCapture)))//
        .andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    ConnectorResponse<Retour, Nothing> result = _connector.operationVieReseauModifierListeClientImpacte(tracabilite, null, null);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture);

    Retour expectedRetour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, JSON_ERROR_MESSAGE);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method {@link REXConnector#operationVieReseauModifierListeClientImpacte} httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testOperationVieReseauModifierListeClientImpacte_OK_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);

    OperationVieReseauModifierListeClientImpacteRequest updateRequest = _podam.manufacturePojoWithFullData(OperationVieReseauModifierListeClientImpacteRequest.class);

    Retour retour = RetourFactory.createOkRetour();
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = RavelJsonTools.getInstance().toJson(basicResponse, BasicResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock
        .expect(_restInstanceMock.put(EasyMock.eq(_operationVieReseauUrl), //
            EasyMock.capture(headersCapture), //
            EasyMock.eq(RavelJsonTools.getInstance().toJson(updateRequest, OperationVieReseauModifierListeClientImpacteRequest.class)), //
            EasyMock.capture(queryParamsCapture)))//
        .andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.operationVieReseauModifierListeClientImpacte(tracabilite, //
        updateRequest.getIdOperationVieReseau(), //
        updateRequest.getClientImpactes());
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());
    checkQueryParams(queryParamsCapture);

    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
  }

  /**
   * Test the method {@link REXConnector#reconciliationCommercialeEnMasseAjouter(Tracabilite, String, List)} httpStatus
   * 400
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testReconciliationCommercialeAjouter_KO_001() throws Exception
  {
    String idTraitementDeMasse = ID_TRAITEMENT_DE_MASSE;
    List<String> listeNoCompte = new ArrayList<>();
    listeNoCompte.add(RandomStringUtils.randomAlphanumeric(10));
    listeNoCompte.add(RandomStringUtils.randomAlphanumeric(10));

    ReconciliationCommercialeEnMasseAjouterRequest request = new ReconciliationCommercialeEnMasseAjouterRequest();
    request.setListeNoCompte(listeNoCompte);
    request.setIdTraitementDeMasse(idTraitementDeMasse);

    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    Retour retour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, null);
    final String partnerResponse = "{\"retour\":" + GsonTools.getIso8601Ms().toJson(retour) + "}"; //$NON-NLS-1$//$NON-NLS-2$

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(400).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_reconciliationCommercialeEnMasseUrl), EasyMock.capture(headersCapture), EasyMock.eq(GsonTools.getIso8601Ms().toJson(request)), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<AssociationPfiReconcialitionCommerciale>> result = _connector.reconciliationCommercialeEnMasseAjouter(tracabilite, idTraitementDeMasse, listeNoCompte);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture);

    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
  }

  /**
   * Test the method {@link REXConnector#reconciliationCommercialeEnMasseAjouter(Tracabilite, String, List)} httpStatus
   * 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testReconciliationCommercialeAjouter_OK_001() throws Exception
  {
    String idTraitementDeMasse = ID_TRAITEMENT_DE_MASSE;
    List<String> listeNoCompte = new ArrayList<>();
    listeNoCompte.add(RandomStringUtils.randomAlphanumeric(10));
    listeNoCompte.add(RandomStringUtils.randomAlphanumeric(10));

    ReconciliationCommercialeEnMasseAjouterRequest request = new ReconciliationCommercialeEnMasseAjouterRequest();
    request.setListeNoCompte(listeNoCompte);
    request.setIdTraitementDeMasse(idTraitementDeMasse);

    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);

    final Retour retour = RetourFactory.createOkRetour();
    final AssociationPfiReconcialitionCommerciale associationPfiReconcialitionCommerciale = _podam.manufacturePojo(AssociationPfiReconcialitionCommerciale.class);

    final String partnerResponse = "{\"retour\":" + GsonTools.getIso8601Ms().toJson(retour) + "," + "\"listeNoCompteReconciliationCommerciale\":[" + GsonTools.getIso8601Ms().toJson(associationPfiReconcialitionCommerciale) + "]}"; //$NON-NLS-1$//$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_reconciliationCommercialeEnMasseUrl), EasyMock.capture(headersCapture), EasyMock.eq(GsonTools.getIso8601Ms().toJson(request)), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<AssociationPfiReconcialitionCommerciale>> result = _connector.reconciliationCommercialeEnMasseAjouter(tracabilite, idTraitementDeMasse, listeNoCompte);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture);

    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, PARAM_ACTION, ACTION_AJOUTER);
    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
    Assert.assertNotNull(result._second);
    Assert.assertEquals(associationPfiReconcialitionCommerciale, result._second.get(0));
  }

  /**
   * Test the method
   * {@link REXConnector#reconciliationCommercialeCreer(Tracabilite, CreateOrUpdateReconciliationCommercialeRequest)}
   * httpStatus 400
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testReconciliationCommercialeCreer_KO_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final ReconciliationCommerciale reconciliationCommerciale = _podam.manufacturePojo(ReconciliationCommerciale.class);
    CreateOrUpdateReconciliationCommercialeRequest reconciliationCommercialeRequest = new CreateOrUpdateReconciliationCommercialeRequest(reconciliationCommerciale);
    Retour retour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, Response.Status.BAD_REQUEST.getReasonPhrase());
    final String partnerResponse = "{\"retour\":" + GsonTools.getIso8601Ms().toJson(retour) + "}"; //$NON-NLS-1$//$NON-NLS-2$

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(400).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(_reconciliationCommercialeUrl), EasyMock.capture(headersCapture), EasyMock.eq(GsonTools.getIso8601Ms().toJson(reconciliationCommercialeRequest)), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.reconciliationCommercialeCreer(tracabilite, reconciliationCommercialeRequest);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture);

    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
  }

  /**
   * Test the method
   * {@link REXConnector#reconciliationCommercialeCreer(Tracabilite, CreateOrUpdateReconciliationCommercialeRequest)}
   * httpStatus 200 jsonResponse null
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testReconciliationCommercialeCreer_KO_002() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    CreateOrUpdateReconciliationCommercialeRequest reconciliationCommercialeRequest = new CreateOrUpdateReconciliationCommercialeRequest(null);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(_reconciliationCommercialeUrl), EasyMock.capture(headersCapture), EasyMock.eq(GsonTools.getIso8601Ms().toJson(reconciliationCommercialeRequest)), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    ConnectorResponse<Retour, Nothing> result = null;

    PowerMock.replayAll();
    result = _connector.reconciliationCommercialeCreer(tracabilite, reconciliationCommercialeRequest);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture);

    Retour expectedRetour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, JSON_ERROR_MESSAGE);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method
   * {@link REXConnector#reconciliationCommercialeCreer(Tracabilite, CreateOrUpdateReconciliationCommercialeRequest)}
   * httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testReconciliationCommercialeCreer_OK_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final ReconciliationCommerciale reconciliationCommerciale = _podam.manufacturePojo(ReconciliationCommerciale.class);
    CreateOrUpdateReconciliationCommercialeRequest reconciliationCommercialeRequest = new CreateOrUpdateReconciliationCommercialeRequest(reconciliationCommerciale);
    final Retour retour = RetourFactory.createOkRetour();
    final String partnerResponse = "{\"retour\":" + GsonTools.getIso8601Ms().toJson(retour) + "}"; //$NON-NLS-1$//$NON-NLS-2$

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(_reconciliationCommercialeUrl), EasyMock.capture(headersCapture), EasyMock.eq(GsonTools.getIso8601Ms().toJson(reconciliationCommercialeRequest)), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.reconciliationCommercialeCreer(tracabilite, reconciliationCommercialeRequest);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture);

    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
  }

  /**
   * Test the method
   * {@link REXConnector#reconciliationCommercialeCreer(Tracabilite, CreateOrUpdateReconciliationCommercialeRequest)}
   * httpStatus 500
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testReconciliationCommercialeCreer_OK_002() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final ReconciliationCommerciale reconciliationCommerciale = _podam.manufacturePojo(ReconciliationCommerciale.class);
    CreateOrUpdateReconciliationCommercialeRequest reconciliationCommercialeRequest = new CreateOrUpdateReconciliationCommercialeRequest(reconciliationCommerciale);
    final Retour retour = RetourFactory.createOkRetour();
    final String partnerResponse = "{\"retour\":" + GsonTools.getIso8601Ms().toJson(retour) + "}"; //$NON-NLS-1$//$NON-NLS-2$

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(500).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(_reconciliationCommercialeUrl), EasyMock.capture(headersCapture), EasyMock.eq(GsonTools.getIso8601Ms().toJson(reconciliationCommercialeRequest)), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.reconciliationCommercialeCreer(tracabilite, reconciliationCommercialeRequest);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture);

    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
  }

  /**
   * Test the method
   * {@link REXConnector#reconciliationCommercialeEnMasseAcquitterUn(Tracabilite, ManageReconciliationCommercialeEnMasseRequest)}
   * httpStatus 400
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testReconciliationCommercialeEnMasseAcquitterUn_KO_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final ReconciliationCommerciale reconciliationCommerciale = _podam.manufacturePojo(ReconciliationCommerciale.class);
    ManageReconciliationCommercialeEnMasseRequest manageReconciliationCommercialeEnMasseRequest = new ManageReconciliationCommercialeEnMasseRequest(reconciliationCommerciale.getIdTraitementMasse(), reconciliationCommerciale);
    Retour retour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, Response.Status.BAD_REQUEST.getReasonPhrase());
    final String partnerResponse = "{\"retour\":" + GsonTools.getIso8601Ms().toJson(retour) + "}"; //$NON-NLS-1$//$NON-NLS-2$

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(400).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_reconciliationCommercialeEnMasseUrl), EasyMock.capture(headersCapture), EasyMock.eq(GsonTools.getIso8601Ms().toJson(manageReconciliationCommercialeEnMasseRequest)), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.reconciliationCommercialeEnMasseAcquitterUn(tracabilite, manageReconciliationCommercialeEnMasseRequest);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture);

    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
  }

  /**
   * Test the method
   * {@link REXConnector#reconciliationCommercialeEnMasseAcquitterUn(Tracabilite, ManageReconciliationCommercialeEnMasseRequest)}
   * httpStatus 200 jsonResponse null
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testReconciliationCommercialeEnMasseAcquitterUn_KO_002() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final ReconciliationCommerciale reconciliationCommerciale = null;
    ManageReconciliationCommercialeEnMasseRequest manageReconciliationCommercialeEnMasseRequest = new ManageReconciliationCommercialeEnMasseRequest(null, reconciliationCommerciale);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_reconciliationCommercialeEnMasseUrl), EasyMock.capture(headersCapture), EasyMock.eq(GsonTools.getIso8601Ms().toJson(manageReconciliationCommercialeEnMasseRequest)), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    ConnectorResponse<Retour, Nothing> result = null;

    PowerMock.replayAll();
    result = _connector.reconciliationCommercialeEnMasseAcquitterUn(tracabilite, manageReconciliationCommercialeEnMasseRequest);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture);

    Retour expectedRetour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, JSON_ERROR_MESSAGE);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method
   * {@link REXConnector#reconciliationCommercialeEnMasseAcquitterUn(Tracabilite, ManageReconciliationCommercialeEnMasseRequest)}
   * httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testReconciliationCommercialeEnMasseAcquitterUn_OK_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final ReconciliationCommerciale reconciliationCommerciale = _podam.manufacturePojo(ReconciliationCommerciale.class);
    ManageReconciliationCommercialeEnMasseRequest manageReconciliationCommercialeEnMasseRequest = new ManageReconciliationCommercialeEnMasseRequest(reconciliationCommerciale.getIdTraitementMasse(), reconciliationCommerciale);

    final Retour retour = RetourFactory.createOkRetour();
    final String partnerResponse = "{\"retour\":" + GsonTools.getIso8601Ms().toJson(retour) + "}"; //$NON-NLS-1$//$NON-NLS-2$

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_reconciliationCommercialeEnMasseUrl), EasyMock.capture(headersCapture), EasyMock.eq(GsonTools.getIso8601Ms().toJson(manageReconciliationCommercialeEnMasseRequest)), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.reconciliationCommercialeEnMasseAcquitterUn(tracabilite, manageReconciliationCommercialeEnMasseRequest);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture);

    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
  }

  /**
   * Test the method {@link REXConnector#reconciliationCommercialeEnMasseLireTous(Tracabilite, String, String)}
   * httpStatus 400
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testReconciliationCommercialeEnMasseLireTous_KO_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    ReconciliationCommerciale reconciliationCommerciale = _podam.manufacturePojoWithFullData(ReconciliationCommerciale.class);
    final Retour retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "idTraitementMasse " + reconciliationCommerciale.getIdTraitementMasse() + " inconnu"); //$NON-NLS-1$ //$NON-NLS-2$
    final String partnerResponse = "{\"retour\":" + GsonTools.getIso8601Ms().toJson(retour) + "}"; //$NON-NLS-1$//$NON-NLS-2$

    // construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_reconciliationCommercialeEnMasseUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<ReconciliationCommerciale>> result = _connector.reconciliationCommercialeEnMasseLireTous(tracabilite, reconciliationCommerciale.getIdTraitementMasse(), null);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, ID_TRAITEMENT_DE_MASSE, reconciliationCommerciale.getIdTraitementMasse());

    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
    Assert.assertEquals(Collections.emptyList(), result._second);
  }

  /**
   * Test the method {@link REXConnector#reconciliationCommercialeEnMasseLireTous(Tracabilite, String, String)}
   * httpStatus 200 jsonResponse null
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testReconciliationCommercialeEnMasseLireTous_KO_002() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    ReconciliationCommerciale reconciliationCommerciale = _podam.manufacturePojoWithFullData(ReconciliationCommerciale.class);

    // construct response
    final Response response = new ResponseBuilderImpl().status(200).build();

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_reconciliationCommercialeEnMasseUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    ConnectorResponse<Retour, List<ReconciliationCommerciale>> result = null;
    PowerMock.replayAll();
    result = _connector.reconciliationCommercialeEnMasseLireTous(tracabilite, reconciliationCommerciale.getIdTraitementMasse(), "EN_COURS"); //$NON-NLS-1$
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, ID_TRAITEMENT_DE_MASSE, reconciliationCommerciale.getIdTraitementMasse());
    checkQueryParams(queryParamsCapture, STATUT, "EN_COURS"); //$NON-NLS-1$

    Retour expectedRetour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, JSON_ERROR_MESSAGE);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method {@link REXConnector#reconciliationCommercialeEnMasseLireTous(Tracabilite, String, String)}
   * httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testReconciliationCommercialeEnMasseLireTous_OK_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final ReconciliationCommerciale reconciliationCommerciale = _podam.manufacturePojo(ReconciliationCommerciale.class);
    final Retour retour = RetourFactory.createOkRetour();
    final String partnerResponse = "{\"retour\":" + GsonTools.getIso8601Ms().toJson(retour) + "," + "\"listeReconciliationCommerciale\":[" + GsonTools.getIso8601Ms().toJson(reconciliationCommerciale) + "]}"; //$NON-NLS-1$//$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_reconciliationCommercialeEnMasseUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<ReconciliationCommerciale>> result = _connector.reconciliationCommercialeEnMasseLireTous(tracabilite, reconciliationCommerciale.getIdTraitementMasse(), "EN_COURS"); //$NON-NLS-1$
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, ID_TRAITEMENT_DE_MASSE, reconciliationCommerciale.getIdTraitementMasse());
    checkQueryParams(queryParamsCapture, STATUT, "EN_COURS"); //$NON-NLS-1$
    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
    Assert.assertNotNull(result._second);
    Assert.assertEquals(reconciliationCommerciale, result._second.get(0));
  }

  /**
   * Test the method
   * {@link REXConnector#reconciliationCommercialeLireTousParClientOperateurNoCompte(Tracabilite, String, String)}
   * httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testReconciliationCommercialeLireTousParClientOperateurNoCompte_KO_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final ReconciliationCommerciale reconciliationCommerciale = _podam.manufacturePojo(ReconciliationCommerciale.class);
    final Retour retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "noCompte " + reconciliationCommerciale.getNoCompte() + " inconnu"); //$NON-NLS-1$ //$NON-NLS-2$
    final String partnerResponse = "{\"retour\":" + GsonTools.getIso8601Ms().toJson(retour) + "," + "\"listeReconciliationCommerciale\":[" + GsonTools.getIso8601Ms().toJson(reconciliationCommerciale) + "]}"; //$NON-NLS-1$//$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_reconciliationCommercialeUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<ReconciliationCommerciale>> result = _connector.reconciliationCommercialeLireTousParClientOperateurNoCompte(tracabilite, reconciliationCommerciale.getClientOperateur(), reconciliationCommerciale.getNoCompte());
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, CLIENT_OPERATEUR, reconciliationCommerciale.getClientOperateur());
    checkQueryParams(queryParamsCapture, NO_COMPTE, reconciliationCommerciale.getNoCompte());
    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
  }

  /**
   * Test the method
   * {@link REXConnector#reconciliationCommercialeLireTousParClientOperateurNoCompte(Tracabilite, String, String)}<BR>
   * Input : clientOperateur and noCompte null <BR>
   * Expected : Retour KO, CAT-4, DONNEE_INVALIDE, "input invalid"
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testReconciliationCommercialeLireTousParClientOperateurNoCompte_KO_002() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final Retour retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INVALIDE, "input invalid"); //$NON-NLS-1$
    final String partnerResponse = "{\"retour\":" + GsonTools.getIso8601Ms().toJson(retour) + "}"; //$NON-NLS-1$//$NON-NLS-2$

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_reconciliationCommercialeUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();

    final ConnectorResponse<Retour, List<ReconciliationCommerciale>> result = _connector.reconciliationCommercialeLireTousParClientOperateurNoCompte(tracabilite, null, null);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, CLIENT_OPERATEUR, null);
    checkQueryParams(queryParamsCapture, NO_COMPTE, null);
    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
  }

  /**
   * Test the method
   * {@link REXConnector#reconciliationCommercialeLireTousParClientOperateurNoCompte(Tracabilite, String, String)}<BR>
   * Input : clientOperateur null <BR>
   * Expected : Retour KO, CAT-4, DONNEE_INVALIDE, "input invalid"
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testReconciliationCommercialeLireTousParClientOperateurNoCompte_KO_003() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    String noCompte = RandomStringUtils.random(5);
    final Retour retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INVALIDE, "input invalid"); //$NON-NLS-1$
    final String partnerResponse = "{\"retour\":" + GsonTools.getIso8601Ms().toJson(retour) + "}"; //$NON-NLS-1$//$NON-NLS-2$

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_reconciliationCommercialeUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();

    final ConnectorResponse<Retour, List<ReconciliationCommerciale>> result = _connector.reconciliationCommercialeLireTousParClientOperateurNoCompte(tracabilite, null, noCompte);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, CLIENT_OPERATEUR, null);
    checkQueryParams(queryParamsCapture, NO_COMPTE, null);
    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
  }

  /**
   * Test the method
   * {@link REXConnector#reconciliationCommercialeLireTousParClientOperateurNoCompte(Tracabilite, String, String)}<BR>
   * Input : noCompte null <BR>
   * Expected : Retour KO, CAT-4, DONNEE_INVALIDE, "input invalid"
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testReconciliationCommercialeLireTousParClientOperateurNoCompte_KO_004() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    String clientOperateur = RandomStringUtils.random(5);
    final Retour retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INVALIDE, "input invalid"); //$NON-NLS-1$
    final String partnerResponse = "{\"retour\":" + GsonTools.getIso8601Ms().toJson(retour) + "}"; //$NON-NLS-1$//$NON-NLS-2$

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_reconciliationCommercialeUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();

    final ConnectorResponse<Retour, List<ReconciliationCommerciale>> result = _connector.reconciliationCommercialeLireTousParClientOperateurNoCompte(tracabilite, clientOperateur, null);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, CLIENT_OPERATEUR, null);
    checkQueryParams(queryParamsCapture, NO_COMPTE, null);
    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
  }

  /**
   * Test the method
   * {@link REXConnector#reconciliationCommercialeLireTousParClientOperateurNoCompte(Tracabilite, String, String)}
   * httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testReconciliationCommercialeLireTousParClientOperateurNoCompte_OK_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final ReconciliationCommerciale reconciliationCommerciale = _podam.manufacturePojo(ReconciliationCommerciale.class);
    final Retour retour = RetourFactory.createOkRetour();
    final String partnerResponse = "{\"retour\":" + GsonTools.getIso8601Ms().toJson(retour) + "," + "\"listeReconciliationCommerciale\":[" + GsonTools.getIso8601Ms().toJson(reconciliationCommerciale) + "]}"; //$NON-NLS-1$//$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_reconciliationCommercialeUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<ReconciliationCommerciale>> result = _connector.reconciliationCommercialeLireTousParClientOperateurNoCompte(tracabilite, reconciliationCommerciale.getClientOperateur(), reconciliationCommerciale.getNoCompte());
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, CLIENT_OPERATEUR, reconciliationCommerciale.getClientOperateur());
    checkQueryParams(queryParamsCapture, NO_COMPTE, reconciliationCommerciale.getNoCompte());
    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
    Assert.assertNotNull(result._second);
    Assert.assertEquals(reconciliationCommerciale, result._second.get(0));
  }

  /**
   * Test the method {@link REXConnector#reconciliationCommercialeLireTousParIdReconciliation(Tracabilite, String)}
   * httpStatus 200 idReconciliation inconnu
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testReconciliationCommercialeLireTousParIdReconciliation_KO_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    ReconciliationCommerciale reconciliationCommerciale = _podam.manufacturePojoWithFullData(ReconciliationCommerciale.class);
    final Retour retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "idReconciliation " + reconciliationCommerciale.getIdReconciliation() + " inconnu"); //$NON-NLS-1$ //$NON-NLS-2$
    final String partnerResponse = "{\"retour\":" + GsonTools.getIso8601Ms().toJson(retour) + "}"; //$NON-NLS-1$//$NON-NLS-2$

    // construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_reconciliationCommercialeUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<ReconciliationCommerciale>> result = _connector.reconciliationCommercialeLireTousParIdReconciliation(tracabilite, reconciliationCommerciale.getIdReconciliation());
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, ID_RECONCILIATION, reconciliationCommerciale.getIdReconciliation());

    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
    Assert.assertEquals(Collections.emptyList(), result._second);
  }

  /**
   * Test the method {@link REXConnector#reconciliationCommercialeLireTousParIdReconciliation(Tracabilite, String)}
   * httpStatus 200 json null
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testReconciliationCommercialeLireTousParIdReconciliation_KO_002() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    ReconciliationCommerciale reconciliationCommerciale = _podam.manufacturePojoWithFullData(ReconciliationCommerciale.class);

    // construct response
    final Response response = new ResponseBuilderImpl().status(200).build();

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_reconciliationCommercialeUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    ConnectorResponse<Retour, List<ReconciliationCommerciale>> result = null;
    PowerMock.replayAll();
    result = _connector.reconciliationCommercialeLireTousParIdReconciliation(tracabilite, reconciliationCommerciale.getIdReconciliation());
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, ID_RECONCILIATION, reconciliationCommerciale.getIdReconciliation());

    Retour expectedRetour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, JSON_ERROR_MESSAGE);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method {@link REXConnector#reconciliationCommercialeLireTousParIdReconciliation(Tracabilite, String)}
   * httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testReconciliationCommercialeLireTousParIdReconciliation_OK_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final ReconciliationCommerciale reconciliationCommerciale = _podam.manufacturePojo(ReconciliationCommerciale.class);
    final Retour retour = RetourFactory.createOkRetour();
    final String partnerResponse = "{\"retour\":" + GsonTools.getIso8601Ms().toJson(retour) + "," + "\"listeReconciliationCommerciale\":[" + GsonTools.getIso8601Ms().toJson(reconciliationCommerciale) + "]}"; //$NON-NLS-1$//$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_reconciliationCommercialeUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<ReconciliationCommerciale>> result = _connector.reconciliationCommercialeLireTousParIdReconciliation(tracabilite, reconciliationCommerciale.getIdReconciliation());
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, ID_RECONCILIATION, reconciliationCommerciale.getIdReconciliation());
    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
    Assert.assertNotNull(result._second);
    Assert.assertEquals(reconciliationCommerciale, result._second.get(0));
  }

  /**
   * Test the method
   * {@link REXConnector#reconciliationCommercialeModifier(Tracabilite, CreateOrUpdateReconciliationCommercialeRequest)}
   * httpStatus 400
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testReconciliationCommercialeModifier_KO_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final ReconciliationCommerciale reconciliationCommerciale = _podam.manufacturePojo(ReconciliationCommerciale.class);
    CreateOrUpdateReconciliationCommercialeRequest reconciliationCommercialeRequest = new CreateOrUpdateReconciliationCommercialeRequest(reconciliationCommerciale);
    Retour retour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, Response.Status.BAD_REQUEST.getReasonPhrase());
    final String partnerResponse = "{\"retour\":" + GsonTools.getIso8601Ms().toJson(retour) + "}"; //$NON-NLS-1$//$NON-NLS-2$

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(400).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_reconciliationCommercialeUrl), EasyMock.capture(headersCapture), EasyMock.eq(GsonTools.getIso8601Ms().toJson(reconciliationCommercialeRequest)), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.reconciliationCommercialeModifier(tracabilite, reconciliationCommercialeRequest);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture);

    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
  }

  /**
   * Test the method
   * {@link REXConnector#reconciliationCommercialeModifier(Tracabilite, CreateOrUpdateReconciliationCommercialeRequest)}
   * httpStatus 200 jsonResponse null
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testReconciliationCommercialeModifier_KO_002() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    CreateOrUpdateReconciliationCommercialeRequest reconciliationCommercialeRequest = new CreateOrUpdateReconciliationCommercialeRequest(null);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_reconciliationCommercialeUrl), EasyMock.capture(headersCapture), EasyMock.eq(GsonTools.getIso8601Ms().toJson(reconciliationCommercialeRequest)), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    ConnectorResponse<Retour, Nothing> result = null;

    PowerMock.replayAll();
    result = _connector.reconciliationCommercialeModifier(tracabilite, reconciliationCommercialeRequest);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture);

    Retour expectedRetour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, JSON_ERROR_MESSAGE);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method
   * {@link REXConnector#reconciliationCommercialeModifier(Tracabilite, CreateOrUpdateReconciliationCommercialeRequest)}
   * httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testReconciliationCommercialeModifier_OK_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final ReconciliationCommerciale reconciliationCommerciale = _podam.manufacturePojo(ReconciliationCommerciale.class);
    CreateOrUpdateReconciliationCommercialeRequest reconciliationCommercialeRequest = new CreateOrUpdateReconciliationCommercialeRequest(reconciliationCommerciale);
    final Retour retour = RetourFactory.createOkRetour();
    final String partnerResponse = "{\"retour\":" + GsonTools.getIso8601Ms().toJson(retour) + "}"; //$NON-NLS-1$//$NON-NLS-2$

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_reconciliationCommercialeUrl), EasyMock.capture(headersCapture), EasyMock.eq(GsonTools.getIso8601Ms().toJson(reconciliationCommercialeRequest)), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.reconciliationCommercialeModifier(tracabilite, reconciliationCommercialeRequest);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture);

    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
  }

  /**
   * Test the method {@link REXConnector#requeteExploitationLireUn(Tracabilite, String)} httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testRequeteExploitationLireUn_KO_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final RequeteExploitation element = _podam.manufacturePojo(RequeteExploitation.class);
    final Retour retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "");
    final String expectedResponse = "{\"retour\":" + RavelJsonTools.getInstance().toJson(retour, Retour.class) + "}"; //$NON-NLS-1$//$NON-NLS-2$

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(expectedResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_configurationProsperUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    String nom = element.getNom();
    final ConnectorResponse<Retour, RequeteExploitation> result = _connector.requeteExploitationLireUn(tracabilite, nom);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, NOM, nom);
    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);

  }

  /**
   * Test the method {@link REXConnector#requeteExploitationLireUn(Tracabilite, String)} httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testRequeteExploitationLireUn_KO_002() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final RequeteExploitation element = _podam.manufacturePojo(RequeteExploitation.class);
    element.setNom(null);
    final Retour retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.DONNEE_INVALIDE, "");
    final String expectedResponse = "{\"retour\":" + RavelJsonTools.getInstance().toJson(retour, Retour.class) + "}"; //$NON-NLS-1$//$NON-NLS-2$

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(expectedResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_configurationProsperUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    String nom = element.getNom();
    final ConnectorResponse<Retour, RequeteExploitation> result = _connector.requeteExploitationLireUn(tracabilite, nom);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, NOM, nom);
    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method {@link REXConnector#requeteExploitationLireUn(Tracabilite, String)} httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testRequeteExploitationLireUn_OK_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final RequeteExploitation element = _podam.manufacturePojo(RequeteExploitation.class);

    final Retour retour = RetourFactory.createOkRetour();
    final String expectedResponse = "{\"retour\":" + RavelJsonTools.getInstance().toJson(retour, Retour.class) + "," + "\"" + "listeRequeteExploitation" + "\":[" + RavelJsonTools.getInstance().toJson(element, RequeteExploitation.class) + "]}"; //$NON-NLS-1$//$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(expectedResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_configurationProsperUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    String nom = element.getNom();
    final ConnectorResponse<Retour, RequeteExploitation> result = _connector.requeteExploitationLireUn(tracabilite, nom);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, NOM, nom);
    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
    Assert.assertNotNull(result._second);
    Assert.assertEquals(element, result._second);
  }

  /**
   * Test the method {@link REXConnector#templateRequeteExploitationLireUn(Tracabilite, String)} httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testTemplateRequeteExploitationLireUn_KO_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final TemplateRequeteExploitation element = _podam.manufacturePojo(TemplateRequeteExploitation.class);
    final Retour retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "");
    final String expectedResponse = "{\"retour\":" + RavelJsonTools.getInstance().toJson(retour, Retour.class) + "}"; //$NON-NLS-2$

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(expectedResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_configurationProsperUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    String nom = element.getNom();
    final ConnectorResponse<Retour, TemplateRequeteExploitation> result = _connector.templateRequeteExploitationLireUn(tracabilite, nom);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, NOM, nom);
    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method {@link REXConnector#templateRequeteExploitationLireUn(Tracabilite, String)} httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testTemplateRequeteExploitationLireUn_KO_002() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final TemplateRequeteExploitation element = _podam.manufacturePojo(TemplateRequeteExploitation.class);
    element.setNom(null);
    final Retour retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.DONNEE_INVALIDE, "");
    final String expectedResponse = "{\"retour\":" + RavelJsonTools.getInstance().toJson(retour, Retour.class) + "}"; //$NON-NLS-1$//$NON-NLS-2$

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(expectedResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_configurationProsperUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    String nom = element.getNom();
    final ConnectorResponse<Retour, TemplateRequeteExploitation> result = _connector.templateRequeteExploitationLireUn(tracabilite, nom);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, NOM, nom);
    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method {@link REXConnector#templateRequeteExploitationLireUn(Tracabilite, String)} httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testTemplateRequeteExploitationLireUn_OK_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final TemplateRequeteExploitation element = _podam.manufacturePojo(TemplateRequeteExploitation.class);

    final Retour retour = RetourFactory.createOkRetour();
    final String expectedResponse = "{\"retour\":" + RavelJsonTools.getInstance().toJson(retour, Retour.class) + "," + "\"" + "listeTemplateRequeteExploitation" + "\":[" + RavelJsonTools.getInstance().toJson(element, TemplateRequeteExploitation.class) + "]}"; //$NON-NLS-1$//$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(expectedResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_configurationProsperUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    String nom = element.getNom();
    final ConnectorResponse<Retour, TemplateRequeteExploitation> result = _connector.templateRequeteExploitationLireUn(tracabilite, nom);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, NOM, nom);
    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
    Assert.assertNotNull(result._second);
    Assert.assertEquals(element, result._second);

  }

  /**
   * Test the method {@link REXConnector#traitementDeMasseCreer(Tracabilite, TraitementDeMasse)} httpStatus 200
   * idReconciliation inconnu
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testTraitementDeMasseCreer_KO_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);

    TraitementDeMasse traitementDeMasse = new TraitementDeMasse(ID_TRAITEMENT_DE_MASSE, CLIENT_OPERATEUR, TYPE_TRAITEMENT_DE_MASSE, STATUT);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(_traitementDeMasseUrl), EasyMock.capture(headersCapture), EasyMock.eq(GsonTools.getIso8601Ms().toJson(traitementDeMasse)), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    ConnectorResponse<Retour, Nothing> result = null;

    PowerMock.replayAll();
    result = _connector.traitementDeMasseCreer(tracabilite, traitementDeMasse);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture);

    Retour expectedRetour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, JSON_ERROR_MESSAGE);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method {@link REXConnector#traitementDeMasseCreer(Tracabilite, TraitementDeMasse)} httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testTraitementDeMasseCreer_OK_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final TraitementDeMasse traitementDeMasse = _podam.manufacturePojoWithFullData(TraitementDeMasse.class);
    final Retour retour = RetourFactory.createOkRetour();
    final String partnerResponse = "{\"retour\":" + GsonTools.getIso8601Ms().toJson(retour) + "}"; //$NON-NLS-1$//$NON-NLS-2$

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(_traitementDeMasseUrl), EasyMock.capture(headersCapture), EasyMock.eq(GsonTools.getIso8601Ms().toJson(traitementDeMasse)), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.traitementDeMasseCreer(tracabilite, traitementDeMasse);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
  }

  /**
   * Test the method {@link REXConnector#traitementDeMasseLireTous(Tracabilite, String)} httpStatus 200 idReconciliation
   * inconnu
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testTraitementDeMasseLireTous_KO_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final Retour retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "Aucun traitementDeMasse trouvé"); //$NON-NLS-1$
    final String partnerResponse = "{\"retour\":" + GsonTools.getIso8601Ms().toJson(retour) + "}"; //$NON-NLS-1$//$NON-NLS-2$

    // construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_traitementDeMasseUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<TraitementDeMasse>> result = _connector.traitementDeMasseLireTous(tracabilite, "EN_COURS"); //$NON-NLS-1$
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, STATUT, "EN_COURS"); //$NON-NLS-1$

    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
    Assert.assertEquals(Collections.emptyList(), result._second);
  }

  /**
   * Test the method {@link REXConnector#traitementDeMasseLireTous(Tracabilite, String)} httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testTraitementDeMasseLireTous_OK_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final TraitementDeMasse traitementDeMasse = _podam.manufacturePojoWithFullData(TraitementDeMasse.class);
    final Retour retour = RetourFactory.createOkRetour();
    //    final String partnerResponse = "{\"retour\":" + GsonTools.getIso8601Ms().toJson(retour) + "," + "\"listeTraitementDeMasse\":[{\"traitementDeMasse\":" + GsonTools.getIso8601Ms().toJson(traitementDeMasse) + "}], \"nbTraitementDeMasse\":1}"; //$NON-NLS-1$//$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    final String partnerResponse = "{\"retour\":" + GsonTools.getIso8601Ms().toJson(retour) + "," + "\"listeTraitementDeMasse\":[" + GsonTools.getIso8601Ms().toJson(traitementDeMasse) + "], \"nbTraitementDeMasse\":1}"; //$NON-NLS-1$//$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_traitementDeMasseUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<TraitementDeMasse>> result = _connector.traitementDeMasseLireTous(tracabilite, null);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, STATUT, null);
    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
    Assert.assertNotNull(result._second);
    Assert.assertNotEquals(Collections.emptyList(), result._second);
    Assert.assertEquals(1, result._second.size());
    Assert.assertEquals(traitementDeMasse.getIdTraitementDeMasse(), result._second.get(0).getIdTraitementDeMasse());
  }

  /**
   * Test the method {@link REXConnector#traitementDeMasseLireUn(Tracabilite, String)} httpStatus 200 idReconciliation
   * inconnu
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testTraitementDeMasseLireUn_KO_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final Retour retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "Aucun traitementDeMasse trouvé"); //$NON-NLS-1$
    final String partnerResponse = "{\"retour\":" + GsonTools.getIso8601Ms().toJson(retour) + "}"; //$NON-NLS-1$//$NON-NLS-2$

    // construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_traitementDeMasseUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, TraitementDeMasse> result = _connector.traitementDeMasseLireUn(tracabilite, "xxx"); //$NON-NLS-1$
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, ID_TRAITEMENT_DE_MASSE, "xxx"); //$NON-NLS-1$

    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method {@link REXConnector#traitementDeMasseLireUn(Tracabilite, String)} httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testTraitementDeMasseLireUn_OK_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final TraitementDeMasse traitementDeMasse = _podam.manufacturePojoWithFullData(TraitementDeMasse.class);
    final Retour retour = RetourFactory.createOkRetour();
    final String partnerResponse = "{\"retour\":" + GsonTools.getIso8601Ms().toJson(retour) + "," + "\"listeTraitementDeMasse\":[" + GsonTools.getIso8601Ms().toJson(traitementDeMasse) + "]}"; //$NON-NLS-1$//$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_traitementDeMasseUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, TraitementDeMasse> result = _connector.traitementDeMasseLireUn(tracabilite, traitementDeMasse.getIdTraitementDeMasse());
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, STATUT, null);
    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
    Assert.assertNotNull(result._second);
    Assert.assertEquals(traitementDeMasse.getIdTraitementDeMasse(), result._second.getIdTraitementDeMasse());
  }

  /**
   * Test the method {@link REXConnector#traitementDeMasseModifierStatutEnCours(Tracabilite, String, Integer)}
   * httpStatus 200 jsonResponse null
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testTraitementDeMasseModifierStatutEnCours_KO_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    Integer nbTraitements = new Integer(1);
    String idTraitement = RandomStringUtils.randomAlphanumeric(10);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_traitementDeMasseUrl), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    ConnectorResponse<Retour, Nothing> result = null;

    PowerMock.replayAll();
    result = _connector.traitementDeMasseModifierStatutEnCours(tracabilite, idTraitement, nbTraitements);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, ID_TRAITEMENT_DE_MASSE, idTraitement);
    checkQueryParams(queryParamsCapture, PARAM_NB_TRAITEMENTS_A_REALISER, nbTraitements.toString());

    Retour expectedRetour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, JSON_ERROR_MESSAGE);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method {@link REXConnector#traitementDeMasseModifierStatutEnCours(Tracabilite, String, Integer)}
   * httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testTraitementDeMasseModifierStatutEnCours_OK_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final Retour retour = RetourFactory.createOkRetour();
    final String partnerResponse = "{\"retour\":" + GsonTools.getIso8601Ms().toJson(retour) + "}"; //$NON-NLS-1$//$NON-NLS-2$
    Integer nbTraitements = new Integer(1);
    String idTraitement = RandomStringUtils.randomAlphanumeric(10);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_traitementDeMasseUrl), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    ConnectorResponse<Retour, Nothing> result = null;

    PowerMock.replayAll();
    result = _connector.traitementDeMasseModifierStatutEnCours(tracabilite, idTraitement, nbTraitements);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture);

    Assert.assertNotNull(result);
    Assert.assertNotNull(result._first);
    Assert.assertEquals(retour, result._first);
  }

  /**
   * Test the method {@link REXConnector#ligneDeTestEligDSLLireUn(Tracabilite, String)}
   * httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testLigneDeTestEligDSLLireUn_OK_001() throws Exception
  {
    initializeMocksForSendRequest();
    LigneDeTestEligDSL ligneDeTestExpected = createLigneDeTest();
    String jsonRetour = "\"retour\":" + RavelJsonTools.getInstance().toJson(RetourFactoryForTU.createOkRetour(), Retour.class);
    String jsonLignesDeTest = "\"listeLigneDeTestEligDSL\":[" + RavelJsonTools.getInstance().toJson(ligneDeTestExpected, LigneDeTestEligDSL.class) + "]";
    String jsonResponse = "{" + jsonRetour + "," + jsonLignesDeTest + "}";
    Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(jsonResponse.getBytes())).build();
    Capture<Map<String, String>> queryParams = Capture.newInstance();
    Capture<MultivaluedMap<String, String>> headers = Capture.newInstance();
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_ligneDeTestEligDSLUrl), EasyMock.capture(headers), EasyMock.capture(queryParams))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    PowerMock.replayAll();
    ConnectorResponse<Retour, LigneDeTestEligDSL> result = _connector.ligneDeTestEligDSLLireUn(tracabilite, "0123456789");
    PowerMock.verifyAll();
    Assert.assertTrue(RetourFactoryForTU.isRetourOK(result._first));
    LigneDeTestEligDSL ligneDeTestEligDSL = result._second;
    Assert.assertNotNull(ligneDeTestEligDSL);
    Assert.assertEquals(ligneDeTestExpected, ligneDeTestEligDSL);
    Assert.assertNotNull(headers.getValue());
    checkQueryParams(queryParams);
  }

  /**
   * Test the method {@link REXConnector#ligneDeTestEligDSLLireUn(Tracabilite, String)} when url is null
   *
   * @throws RavelException
   *           thrown in case of error
   */
  @Test
  public void testLigneDeTestEligDSLLireUn_KO_001() throws RavelException
  {
    Supplier<ConnectorResponse<Retour, ?>> supplier = () -> _connector.ligneDeTestEligDSLLireUn(null, "0123456789");
    testWhenUrlIsNull("PAD6015_LigneDeTestEligDSL", supplier);
  }

  /**
   * Test the method {@link REXConnector#ligneDeTestEligDSLLireUn(Tracabilite, String)} when REST request contains null fields
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testLigneDeTestEligDSLLireUn_KO_002() throws Exception
  {
    ConnectorResponse<Retour, LigneDeTestEligDSL> result = _connector.ligneDeTestEligDSLLireUn(null, "0123456789");
    Assert.assertTrue(RetourFactoryForTU.isRetourKO(result._first));
    Assert.assertEquals(IMegSpiritConsts.CAT2, result._first.getCategorie());
    Assert.assertEquals(IMegSpiritConsts.SERVICE_TIERS_INDISPONIBLE, result._first.getDiagnostic());
    Assert.assertEquals("No trace id for Rest Request", result._first.getLibelle());
    Assert.assertNull(result._second);
  }

  /**
   * Test the method {@link REXConnector#ligneDeTestEligDSLLireUn(Tracabilite, String)} when exception is thrown
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testLigneDeTestEligDSLLireUn_KO_003() throws Exception
  {
    EasyMock.expect(_loadBalancerMock.chooseBalancedElement()).andReturn(null);
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    PowerMock.replayAll();
    ConnectorResponse<Retour, LigneDeTestEligDSL> result = _connector.ligneDeTestEligDSLLireUn(tracabilite, "0123456789");
    PowerMock.verifyAll();
    Assert.assertTrue(RetourFactoryForTU.isRetourKO(result._first));
    Assert.assertEquals(IMegSpiritConsts.CAT2, result._first.getCategorie());
    Assert.assertEquals(IMegSpiritConsts.SERVICE_TIERS_INDISPONIBLE, result._first.getDiagnostic());
    Assert.assertEquals("Technical Exception in AbstractWebServiceConnector during ligneDeTestEligDslLireUn call: code() reason(Load balancer of the AbstractInternalRESTConnector : All http url failed, no more url available.) at AbstractSpiritRESTConnector.java line: 227", result._first.getLibelle());
    Assert.assertNull(result._second);
  }

  /**
   * Test the method {@link REXConnector#ligneDeTestEligDSLLireUn(Tracabilite, String)} when Json response is empty
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testLigneDeTestEligDSLLireUn_KO_004() throws Exception
  {
    initializeMocksForSendRequest();
    Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream("".getBytes())).build();
    Capture<MultivaluedMap<String, String>> headers = Capture.newInstance();
    Capture<Map<String, String>> queryParams = Capture.newInstance();
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_ligneDeTestEligDSLUrl), EasyMock.capture(headers), EasyMock.capture(queryParams))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    PowerMock.replayAll();
    ConnectorResponse<Retour, LigneDeTestEligDSL> result = _connector.ligneDeTestEligDSLLireUn(tracabilite, "0123456789");
    PowerMock.verifyAll();
    Assert.assertTrue(RetourFactoryForTU.isRetourKO(result._first));
    Assert.assertEquals(IMegSpiritConsts.CAT10, result._first.getCategorie());
    Assert.assertEquals(IMegSpiritConsts.TRAITEMENT_ARRETE, result._first.getDiagnostic());
    Assert.assertEquals("Impossible de recuperer la reponse", result._first.getLibelle());
    Assert.assertNull(result._second);
    checkQueryParams(queryParams);
    Assert.assertNotNull(headers.getValue());
  }

  /**
   * Test the method {@link REXConnector#ligneDeTestEligDSLLireUn(Tracabilite, String)} when liste of LigneDeTest is empty
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testLigneDeTestEligDSLLireUn_KO_005() throws Exception
  {
    initializeMocksForSendRequest();
    String jsonRetour = "\"retour\":" + RavelJsonTools.getInstance().toJson(RetourFactoryForTU.createOkRetour(), Retour.class);
    String jsonLignesDeTest = "\"listeLigneDeTestEligDSL\":[]";
    String jsonResponse = "{" + jsonRetour + "," + jsonLignesDeTest + "}";
    Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(jsonResponse.getBytes())).build();
    Capture<MultivaluedMap<String, String>> headers = Capture.newInstance();
    Capture<Map<String, String>> queryParams = Capture.newInstance();
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_ligneDeTestEligDSLUrl), EasyMock.capture(headers), EasyMock.capture(queryParams))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    PowerMock.replayAll();
    ConnectorResponse<Retour, LigneDeTestEligDSL> result = _connector.ligneDeTestEligDSLLireUn(tracabilite, "0123456789");
    PowerMock.verifyAll();
    LigneDeTestEligDSL ligneDeTestEligDSL = result._second;
    Assert.assertNull(ligneDeTestEligDSL);
    Assert.assertNotNull(headers.getValue());
    checkQueryParams(queryParams);
  }

  /**
   * Test the method {@link REXConnector#ligneDeTestEligDSLLireTous(Tracabilite)}
   * httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testLigneDeTestEligDSLLireTous_OK_001() throws Exception
  {
    initializeMocksForSendRequest();
    LigneDeTestEligDSL ligneDeTestExpected = new LigneDeTestEligDSL("0123456789", 4.0f, 678, "59480 QUE", LocalDateTime.now());
    LigneDeTestEligDSL ligneDeTestExpected2 = new LigneDeTestEligDSL("0123456789", 0.4f, 867, "59123 BRA", LocalDateTime.now());
    String jsonRetour = "\"retour\":" + RavelJsonTools.getInstance().toJson(RetourFactoryForTU.createOkRetour(), Retour.class);
    String jsonLigneDeTest1 = RavelJsonTools.getInstance().toJson(ligneDeTestExpected, LigneDeTestEligDSL.class);
    String jsonLigneDeTest2 = RavelJsonTools.getInstance().toJson(ligneDeTestExpected2, LigneDeTestEligDSL.class);
    String jsonLignesDeTest = "\"listeLigneDeTestEligDSL\":[" + jsonLigneDeTest1 + "," + jsonLigneDeTest2 + "]";
    String jsonResponse = "{" + jsonRetour + "," + jsonLignesDeTest + "}";
    Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(jsonResponse.getBytes())).build();
    Capture<MultivaluedMap<String, String>> headers = Capture.newInstance();
    Capture<Map<String, String>> queryParams = Capture.newInstance();
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_ligneDeTestEligDSLUrl), EasyMock.capture(headers), EasyMock.capture(queryParams))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    PowerMock.replayAll();
    ConnectorResponse<Retour, List<LigneDeTestEligDSL>> result = _connector.ligneDeTestEligDSLLireTous(tracabilite);
    PowerMock.verifyAll();
    Assert.assertTrue(RetourFactoryForTU.isRetourOK(result._first));
    List<LigneDeTestEligDSL> lignesDeTestEligDSL = result._second;
    Assert.assertNotNull(lignesDeTestEligDSL);
    Assert.assertFalse(lignesDeTestEligDSL.isEmpty());
    Assert.assertTrue(lignesDeTestEligDSL.contains(ligneDeTestExpected));
    Assert.assertTrue(lignesDeTestEligDSL.contains(ligneDeTestExpected2));
    Assert.assertNotNull(headers.getValue());
    checkQueryParams(queryParams);
  }

  /**
   * Test the method {@link REXConnector#ligneDeTestEligDSLLireTous(Tracabilite)}
   * when url is null
   *
   * @throws RavelException
   *           thrown in case of error
   */
  @Test
  public void testLigneDeTestEligDSLLireTous_KO_001() throws RavelException
  {
    Supplier<ConnectorResponse<Retour, ?>> supplier = () -> _connector.ligneDeTestEligDSLLireTous(null);
    testWhenUrlIsNull("PAD6015_LigneDeTestEligDSL", supplier);
  }

  /**
   * Test the method {@link REXConnector#ligneDeTestEligDSLLireTous(Tracabilite)}
   * when REST request contains null fields
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testLigneDeTestEligDSLLireTous_KO_002() throws Exception
  {
    ConnectorResponse<Retour, List<LigneDeTestEligDSL>> result = _connector.ligneDeTestEligDSLLireTous(null);
    Assert.assertTrue(RetourFactoryForTU.isRetourKO(result._first));
    Assert.assertEquals(IMegSpiritConsts.CAT2, result._first.getCategorie());
    Assert.assertEquals(IMegSpiritConsts.SERVICE_TIERS_INDISPONIBLE, result._first.getDiagnostic());
    Assert.assertEquals("No trace id for Rest Request", result._first.getLibelle());
    Assert.assertNull(result._second);
  }

  /**
   * Test the method {@link REXConnector#ligneDeTestEligDSLLireTous(Tracabilite)}
   * when exception is thrown
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testLigneDeTestEligDSLLireTous_KO_003() throws Exception
  {
    EasyMock.expect(_loadBalancerMock.chooseBalancedElement()).andReturn(null);
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    PowerMock.replayAll();
    ConnectorResponse<Retour, List<LigneDeTestEligDSL>> result = _connector.ligneDeTestEligDSLLireTous(tracabilite);
    PowerMock.verifyAll();
    Assert.assertTrue(RetourFactoryForTU.isRetourKO(result._first));
    Assert.assertEquals(IMegSpiritConsts.CAT2, result._first.getCategorie());
    Assert.assertEquals(IMegSpiritConsts.SERVICE_TIERS_INDISPONIBLE, result._first.getDiagnostic());
    Assert.assertEquals("Technical Exception in AbstractWebServiceConnector during ligneDeTestEligDslLireTous call: code() reason(Load balancer of the AbstractInternalRESTConnector : All http url failed, no more url available.) at AbstractSpiritRESTConnector.java line: 227", result._first.getLibelle());
    Assert.assertNull(result._second);
  }

  /**
   * Test the method {@link REXConnector#ligneDeTestEligDSLLireTous(Tracabilite)}
   * when json response is empty
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testLigneDeTestEligDSLLireTous_KO_004() throws Exception
  {
    initializeMocksForSendRequest();
    Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream("".getBytes())).build();
    Capture<MultivaluedMap<String, String>> headers = Capture.newInstance();
    Capture<Map<String, String>> queryParams = Capture.newInstance();
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_ligneDeTestEligDSLUrl), EasyMock.capture(headers), EasyMock.capture(queryParams))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    PowerMock.replayAll();
    ConnectorResponse<Retour, List<LigneDeTestEligDSL>> result = _connector.ligneDeTestEligDSLLireTous(tracabilite);
    PowerMock.verifyAll();
    Assert.assertTrue(RetourFactoryForTU.isRetourKO(result._first));
    Assert.assertEquals(IMegSpiritConsts.CAT10, result._first.getCategorie());
    Assert.assertEquals(IMegSpiritConsts.TRAITEMENT_ARRETE, result._first.getDiagnostic());
    Assert.assertEquals("Impossible de recuperer la reponse", result._first.getLibelle());
    Assert.assertNull(result._second);
    Assert.assertNotNull(headers.getValue());
    checkQueryParams(queryParams);
  }

  /**
   * Test the method {@link REXConnector#ligneDeTestEligDSLLireTous(Tracabilite)}
   * when list of LigneDeTest is empty
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testLigneDeTestEligDSLLireTous_KO_005() throws Exception
  {
    initializeMocksForSendRequest();
    String jsonRetour = "\"retour\":" + RavelJsonTools.getInstance().toJson(RetourFactoryForTU.createOkRetour(), Retour.class);
    String jsonLignesDeTest = "\"listeLigneDeTestEligDSL\":[]";
    String jsonResponse = "{" + jsonRetour + "," + jsonLignesDeTest + "}";
    Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(jsonResponse.getBytes())).build();
    Capture<MultivaluedMap<String, String>> headers = Capture.newInstance();
    Capture<Map<String, String>> queryParams = Capture.newInstance();
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_ligneDeTestEligDSLUrl), EasyMock.capture(headers), EasyMock.capture(queryParams))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    PowerMock.replayAll();
    ConnectorResponse<Retour, List<LigneDeTestEligDSL>> result = _connector.ligneDeTestEligDSLLireTous(tracabilite);
    PowerMock.verifyAll();
    List<LigneDeTestEligDSL> ligneDeTestEligDSL = result._second;
    Assert.assertNull(ligneDeTestEligDSL);
    Assert.assertNotNull(headers.getValue());
    checkQueryParams(queryParams);
  }

  /**
   * Test the method {@link REXConnector#ligneDeTestEligDSLCreer(Tracabilite, LigneDeTestEligDSL)}
   * httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testLigneDeTestEligDSLCreer_OK_001() throws Exception
  {
    initializeMocksForSendRequest();
    LigneDeTestEligDSL ligneDeTestExpected = new LigneDeTestEligDSL("0123456789", 4.0f, 678, "59480 QUE", LocalDateTime.now());
    BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(RetourFactoryForTU.createOkRetour()));
    String jsonResponse = RavelJsonTools.getInstance().toJson(basicResponse, BasicResponse.class);
    String ligneDeTestJson = RavelJsonTools.getInstance().toJson(ligneDeTestExpected, LigneDeTestEligDSL.class);
    Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(jsonResponse.getBytes())).build();
    Capture<MultivaluedMap<String, String>> headers = Capture.newInstance();
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(_ligneDeTestEligDSLUrl), EasyMock.capture(headers), EasyMock.eq(ligneDeTestJson), EasyMock.eq(null))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    PowerMock.replayAll();
    ConnectorResponse<Retour, Nothing> result = _connector.ligneDeTestEligDSLCreer(tracabilite, ligneDeTestExpected);
    PowerMock.verifyAll();
    Assert.assertTrue(RetourFactoryForTU.isRetourOK(result._first));
    Nothing lignesDeTestEligDSL = result._second;
    Assert.assertNull(lignesDeTestEligDSL);
    Assert.assertNotNull(headers.getValue());
  }

  /**
   * Test the method {@link REXConnector#ligneDeTestEligDSLCreer(Tracabilite, LigneDeTestEligDSL)}
   * when url is null
   *
   * @throws RavelException
   *           thrown in case of error
   */
  @Test
  public void testLigneDeTestEligDSLCreer_KO_001() throws RavelException
  {
    Supplier<ConnectorResponse<Retour, ?>> supplier = () -> _connector.ligneDeTestEligDSLCreer(null, createLigneDeTest());
    testWhenUrlIsNull("PAD6015_LigneDeTestEligDSL", supplier);
  }

  /**
   * Test the method {@link REXConnector#ligneDeTestEligDSLCreer(Tracabilite, LigneDeTestEligDSL)}
   * when REST request contains null fields
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testLigneDeTestEligDSLCreer_KO_002() throws Exception
  {
    ConnectorResponse<Retour, Nothing> result = _connector.ligneDeTestEligDSLCreer(null, createLigneDeTest());
    Assert.assertTrue(RetourFactoryForTU.isRetourKO(result._first));
    Assert.assertEquals(IMegSpiritConsts.CAT2, result._first.getCategorie());
    Assert.assertEquals(IMegSpiritConsts.SERVICE_TIERS_INDISPONIBLE, result._first.getDiagnostic());
    Assert.assertEquals("No trace id for Rest Request", result._first.getLibelle());
    Assert.assertNull(result._second);
  }

  /**
   * Test the method {@link REXConnector#ligneDeTestEligDSLCreer(Tracabilite, LigneDeTestEligDSL)}
   * when exception is thrown
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testLigneDeTestEligDSLCreer_KO_003() throws Exception
  {
    EasyMock.expect(_loadBalancerMock.chooseBalancedElement()).andReturn(null);
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    PowerMock.replayAll();
    ConnectorResponse<Retour, Nothing> result = _connector.ligneDeTestEligDSLCreer(tracabilite, createLigneDeTest());
    PowerMock.verifyAll();
    Assert.assertTrue(RetourFactoryForTU.isRetourKO(result._first));
    Assert.assertEquals(IMegSpiritConsts.CAT2, result._first.getCategorie());
    Assert.assertEquals(IMegSpiritConsts.SERVICE_TIERS_INDISPONIBLE, result._first.getDiagnostic());
    Assert.assertEquals("Technical Exception in AbstractWebServiceConnector during ligneDeTestEligDslCreer call: code() reason(Load balancer of the AbstractInternalRESTConnector : All http url failed, no more url available.) at AbstractSpiritRESTConnector.java line: 227", result._first.getLibelle());
    Assert.assertNull(result._second);
  }

  /**
   * Test the method {@link REXConnector#ligneDeTestEligDSLCreer(Tracabilite, LigneDeTestEligDSL)}
   * when json response is empty
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testLigneDeTestEligDSLCreer_KO_004() throws Exception
  {
    initializeMocksForSendRequest();
    Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream("".getBytes())).build();
    LigneDeTestEligDSL ligneDeTestExpected = new LigneDeTestEligDSL("0123456789", 4.0f, 678, "59480 QUE", LocalDateTime.now());
    String ligneDeTestJson = RavelJsonTools.getInstance().toJson(ligneDeTestExpected, LigneDeTestEligDSL.class);
    Capture<MultivaluedMap<String, String>> headers = Capture.newInstance();
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(_ligneDeTestEligDSLUrl), EasyMock.capture(headers), EasyMock.eq(ligneDeTestJson), EasyMock.eq(null))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    PowerMock.replayAll();
    ConnectorResponse<Retour, Nothing> result = _connector.ligneDeTestEligDSLCreer(tracabilite, ligneDeTestExpected);
    PowerMock.verifyAll();
    Assert.assertTrue(RetourFactoryForTU.isRetourKO(result._first));
    Assert.assertEquals(IMegSpiritConsts.CAT10, result._first.getCategorie());
    Assert.assertEquals(IMegSpiritConsts.TRAITEMENT_ARRETE, result._first.getDiagnostic());
    Assert.assertEquals("Impossible de recuperer la reponse", result._first.getLibelle());
    Assert.assertNull(result._second);
    Assert.assertNotNull(headers.getValue());
  }

  /**
   * Test the method {@link REXConnector#ligneDeTestEligDSLModifier(Tracabilite, LigneDeTestEligDSL)}
   * httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testLigneDeTestEligDSLModifier_OK_001() throws Exception
  {
    initializeMocksForSendRequest();
    String numeroDeDesignation = "0123456789";
    LigneDeTestEligDSL ligneDeTestExpected = createLigneDeTest();
    BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(RetourFactoryForTU.createOkRetour()));
    String jsonResponse = RavelJsonTools.getInstance().toJson(basicResponse, BasicResponse.class);
    String ligneDeTestJson = RavelJsonTools.getInstance().toJson(ligneDeTestExpected, LigneDeTestEligDSL.class);
    Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(jsonResponse.getBytes())).build();
    Capture<MultivaluedMap<String, String>> headers = Capture.newInstance();
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_ligneDeTestEligDSLUrl), EasyMock.capture(headers), EasyMock.eq(ligneDeTestJson), EasyMock.eq(null))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    PowerMock.replayAll();
    ConnectorResponse<Retour, Nothing> result = _connector.ligneDeTestEligDSLModifier(tracabilite, ligneDeTestExpected);
    PowerMock.verifyAll();
    Assert.assertTrue(RetourFactoryForTU.isRetourOK(result._first));
    Nothing lignesDeTestEligDSL = result._second;
    Assert.assertNull(lignesDeTestEligDSL);
    Assert.assertNotNull(headers.getValue());
  }

  /**
   * Test the method {@link REXConnector#ligneDeTestEligDSLModifier(Tracabilite, LigneDeTestEligDSL)}
   * when url is Null
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testLigneDeTestEligDSLModifier_KO_001() throws RavelException
  {
    Supplier<ConnectorResponse<Retour, ?>> supplier = () -> _connector.ligneDeTestEligDSLModifier(null, createLigneDeTest());
    testWhenUrlIsNull("PAD6015_LigneDeTestEligDSL", supplier);
  }

  /**
   * Test the method {@link REXConnector#ligneDeTestEligDSLModifier(Tracabilite, LigneDeTestEligDSL)}
   * when REST request contains null fields
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testLigneDeTestEligDSLModifier_KO_002() throws Exception
  {
    ConnectorResponse<Retour, Nothing> result = _connector.ligneDeTestEligDSLModifier(null, createLigneDeTest());
    Assert.assertTrue(RetourFactoryForTU.isRetourKO(result._first));
    Assert.assertEquals(IMegSpiritConsts.CAT2, result._first.getCategorie());
    Assert.assertEquals(IMegSpiritConsts.SERVICE_TIERS_INDISPONIBLE, result._first.getDiagnostic());
    Assert.assertEquals("No trace id for Rest Request", result._first.getLibelle());
    Assert.assertNull(result._second);
  }

  /**
   * Test the method {@link REXConnector#ligneDeTestEligDSLModifier(Tracabilite, LigneDeTestEligDSL)}
   * when exception is thrown
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testLigneDeTestEligDSLModifier_KO_003() throws Exception
  {
    EasyMock.expect(_loadBalancerMock.chooseBalancedElement()).andReturn(null);
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    PowerMock.replayAll();
    ConnectorResponse<Retour, Nothing> result = _connector.ligneDeTestEligDSLModifier(tracabilite, createLigneDeTest());
    PowerMock.verifyAll();
    Assert.assertTrue(RetourFactoryForTU.isRetourKO(result._first));
    Assert.assertEquals(IMegSpiritConsts.CAT2, result._first.getCategorie());
    Assert.assertEquals(IMegSpiritConsts.SERVICE_TIERS_INDISPONIBLE, result._first.getDiagnostic());
    Assert.assertEquals("Technical Exception in AbstractWebServiceConnector during ligneDeTestEligDslModifier call: code() reason(Load balancer of the AbstractInternalRESTConnector : All http url failed, no more url available.) at AbstractSpiritRESTConnector.java line: 227", result._first.getLibelle());
    Assert.assertNull(result._second);
  }

  /**
   * Test the method {@link REXConnector#ligneDeTestEligDSLModifier(Tracabilite, LigneDeTestEligDSL)}
   * when json response is empty
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testLigneDeTestEligDSLModifier_KO_004() throws Exception
  {
    initializeMocksForSendRequest();
    LigneDeTestEligDSL ligneDeTestExpected = createLigneDeTest();
    String ligneDeTestJson = RavelJsonTools.getInstance().toJson(ligneDeTestExpected, LigneDeTestEligDSL.class);
    Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream("".getBytes())).build();
    Capture<MultivaluedMap<String, String>> headers = Capture.newInstance();
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_ligneDeTestEligDSLUrl), EasyMock.capture(headers), EasyMock.eq(ligneDeTestJson), EasyMock.eq(null))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    PowerMock.replayAll();
    ConnectorResponse<Retour, Nothing> result = _connector.ligneDeTestEligDSLModifier(tracabilite, ligneDeTestExpected);
    PowerMock.verifyAll();
    Assert.assertTrue(RetourFactoryForTU.isRetourKO(result._first));
    Assert.assertEquals(IMegSpiritConsts.CAT10, result._first.getCategorie());
    Assert.assertEquals(IMegSpiritConsts.TRAITEMENT_ARRETE, result._first.getDiagnostic());
    Assert.assertEquals("Impossible de recuperer la reponse", result._first.getLibelle());
    Assert.assertNull(result._second);
    Assert.assertNotNull(headers.getValue());
  }

  /**
   * Test the method {@link REXConnector#ligneDeTestEligDSLSupprimer(Tracabilite, String)}
   * httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testLigneDeTestEligDSLSupprimer_OK_001() throws Exception
  {
    initializeMocksForSendRequest();
    BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(RetourFactoryForTU.createOkRetour()));
    String jsonResponse = RavelJsonTools.getInstance().toJson(basicResponse, BasicResponse.class);
    Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(jsonResponse.getBytes())).build();
    Capture<MultivaluedMap<String, String>> headers = Capture.newInstance();
    EasyMock.expect(_restInstanceMock.delete(EasyMock.eq(_ligneDeTestEligDSLUrl), EasyMock.capture(headers), EasyMock.eq(null), EasyMock.capture(Capture.newInstance()))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    PowerMock.replayAll();
    ConnectorResponse<Retour, Nothing> result = _connector.ligneDeTestEligDSLSupprimer(tracabilite, "0123456789");
    PowerMock.verifyAll();
    Assert.assertTrue(RetourFactoryForTU.isRetourOK(result._first));
    Nothing lignesDeTestEligDSL = result._second;
    Assert.assertNull(lignesDeTestEligDSL);
    Assert.assertNotNull(headers.getValue());
  }

  /**
   * Test the method {@link REXConnector#ligneDeTestEligDSLSupprimer(Tracabilite, String)}
   * when url is null
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testLigneDeTestEligDSLSupprimer_KO_001() throws RavelException
  {
    Supplier<ConnectorResponse<Retour, ?>> supplier = () -> _connector.ligneDeTestEligDSLSupprimer(null, "0123456789");
    testWhenUrlIsNull("PAD6015_LigneDeTestEligDSL", supplier);
  }

  /**
   * Test the method {@link REXConnector#ligneDeTestEligDSLSupprimer(Tracabilite, String)}
   * when REST request contains null fields
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testLigneDeTestEligDSLSupprimer_KO_002() throws Exception
  {
    ConnectorResponse<Retour, Nothing> result = _connector.ligneDeTestEligDSLSupprimer(null, "0123456789");
    Assert.assertTrue(RetourFactoryForTU.isRetourKO(result._first));
    Assert.assertEquals(IMegSpiritConsts.CAT2, result._first.getCategorie());
    Assert.assertEquals(IMegSpiritConsts.SERVICE_TIERS_INDISPONIBLE, result._first.getDiagnostic());
    Assert.assertEquals("No trace id for Rest Request", result._first.getLibelle());
    Assert.assertNull(result._second);
  }

  /**
   * Test the method {@link REXConnector#ligneDeTestEligDSLSupprimer(Tracabilite, String)}
   * when exception is thrown
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testLigneDeTestEligDSLSupprimer_KO_003() throws Exception
  {
    EasyMock.expect(_loadBalancerMock.chooseBalancedElement()).andReturn(null);
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    PowerMock.replayAll();
    ConnectorResponse<Retour, Nothing> result = _connector.ligneDeTestEligDSLSupprimer(tracabilite, "0123456789");
    PowerMock.verifyAll();
    Assert.assertTrue(RetourFactoryForTU.isRetourKO(result._first));
    Assert.assertEquals(IMegSpiritConsts.CAT2, result._first.getCategorie());
    Assert.assertEquals(IMegSpiritConsts.SERVICE_TIERS_INDISPONIBLE, result._first.getDiagnostic());
    Assert.assertEquals("Technical Exception in AbstractWebServiceConnector during ligneDeTestEligDslSupprimer call: code() reason(Load balancer of the AbstractInternalRESTConnector : All http url failed, no more url available.) at AbstractSpiritRESTConnector.java line: 227", result._first.getLibelle());
    Assert.assertNull(result._second);
  }

  /**
   * Test the method {@link REXConnector#ligneDeTestEligDSLSupprimer(Tracabilite, String)}
   * when json response is empty
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testLigneDeTestEligDSLSupprimer_KO_004() throws Exception
  {
    initializeMocksForSendRequest();
    Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream("".getBytes())).build();
    Capture<MultivaluedMap<String, String>> headers = Capture.newInstance();
    EasyMock.expect(_restInstanceMock.delete(EasyMock.eq(_ligneDeTestEligDSLUrl), EasyMock.capture(headers), EasyMock.eq(null), EasyMock.capture(Capture.newInstance()))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    PowerMock.replayAll();
    ConnectorResponse<Retour, Nothing> result = _connector.ligneDeTestEligDSLSupprimer(tracabilite, "0123456789");
    PowerMock.verifyAll();
    Assert.assertTrue(RetourFactoryForTU.isRetourKO(result._first));
    Assert.assertEquals(IMegSpiritConsts.CAT10, result._first.getCategorie());
    Assert.assertEquals(IMegSpiritConsts.TRAITEMENT_ARRETE, result._first.getDiagnostic());
    Assert.assertEquals("Impossible de recuperer la reponse", result._first.getLibelle());
    Assert.assertNull(result._second);
    Assert.assertNotNull(headers.getValue());
  }

  /**
   *
   * @param parameterName
   *          parameterName
   * @param supplier
   *          supplier
   * @throws RavelException
   *          in case of error
   */
  private void testWhenUrlIsNull(String parameterName, Supplier<ConnectorResponse<Retour, ?>> supplier) throws RavelException
  {
    Connector connector = new Connector();
    Param param = new Param();
    param.setName(parameterName); //$NON-NLS-1$
    param.setValue(null);
    connector.getParam().add(param);
    connector.setURLS(generateURLS());
    _connector.loadConnectorConfiguration(connector);
    ConnectorResponse<Retour, ?> connectorResponse = supplier.get();
    Retour retour = connectorResponse.getResult();
    Assert.assertTrue(RetourFactoryForTU.isRetourKO(retour));
    Assert.assertEquals(IMegConsts.CAT10, retour.getCategorie());
    Assert.assertEquals(IMegSpiritConsts.TRAITEMENT_ARRETE, retour.getDiagnostic());
    Assert.assertEquals("The configuration parameter " + parameterName + " is missing", retour.getLibelle());
    Assert.assertNull(connectorResponse._second);
  }

  /**
   * Creates a LigneDeTest
   * @return LigneDeTestEligDSL
   */
  private LigneDeTestEligDSL createLigneDeTest() {
    return new LigneDeTestEligDSL("0123456789", 4.0f, 678, "59480 QUE", LocalDateTime.now());
  }

  /**
   * Check the query params in rest send request method
   *
   * @param queryParams
   *          the actual query params
   * @param expected_p
   *          list of expected query params strings key1 value1 key2 value2...keyN valueN
   */
  private void checkQueryParams(Capture<Map<String, String>> queryParams, String... expected_p)
  {
    if (expected_p == null)
    {
      Assert.assertNull(queryParams.getValue());
    }
    else
    {
      Assert.assertEquals(0, expected_p.length % 2);
      for (int i = 0; i < expected_p.length; i = i + 2)
      {
        Assert.assertEquals(expected_p[i + 1], queryParams.getValue().get(expected_p[i]));
      }
    }
  }

  /**
   * prepare mock scenario to initialize method sendRequest from AbstractRestConnector
   *
   * @throws Exception
   *           Thrown in case of error
   */
  private void initializeMocksForSendRequest() throws Exception
  {
    final String urlBalancedElementName = RandomStringUtils.randomAlphanumeric(45);
    final String urlBalancedElementDescription = RandomStringUtils.randomAlphabetic(9);

    EasyMock.expect(_loadBalancerMock.chooseBalancedElement()).andReturn(_urlBalancedElementMock);
    EasyMock.expect(_urlBalancedElementMock.getName()).andReturn(urlBalancedElementName);
    EasyMock.expect(_urlBalancedElementMock.getDescription()).andReturn(urlBalancedElementDescription);
    EasyMock.expect(_urlBalancedElementMock.getName()).andReturn(urlBalancedElementName);
    EasyMock.expect(_connectorPoolMock.get(urlBalancedElementName)).andReturn(_restConnectorPoolMock);
    EasyMock.expect(_restConnectorPoolMock.borrowObject()).andReturn(_restInstanceMock);
    _restInstanceMock.setReceiveTimeout(0);
  }
}
