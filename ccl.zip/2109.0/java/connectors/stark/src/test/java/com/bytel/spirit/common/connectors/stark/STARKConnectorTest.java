/*******************************************************************************
* $Id: STARKConnectorTest.java 33294 2020-03-16 14:06:00Z fbarnabe $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.stark;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Hashtable;
import java.util.List;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedHashMap;
import javax.ws.rs.core.Response;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.cxf.jaxrs.impl.ResponseBuilderImpl;
import org.easymock.EasyMock;
import org.easymock.EasyMockSupport;
import org.fusesource.hawtbuf.ByteArrayInputStream;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.conf.generated.LoadBalancer;
import com.bytel.ravel.common.conf.generated.Param;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.test.JUnitTools;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.utils.ACManagerUtil;
import com.bytel.ravel.common.utils.RetourFactoryForTU;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.net.loadbalancing.ILoadBalancer;
import com.bytel.ravel.net.loadbalancing.URLBalancedElement;
import com.bytel.ravel.net.rest.RestConnectorPool;
import com.bytel.ravel.net.rest.RestInstance;
import com.bytel.ravel.services.conf.connector.generated.Connector;
import com.bytel.ravel.services.conf.connector.generated.URL;
import com.bytel.ravel.services.conf.connector.generated.URLS;
import com.bytel.ravel.services.connector.AbstractRESTConnector;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.connectors.stark.structs.STARKRequestTestStruct;
import com.bytel.spirit.common.connectors.stark.structs.STARKResponse;
import com.bytel.spirit.common.connectors.stark.structs.STARKReturnTestStruct;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author pcarreir
 * @version ($Revision: 33294 $ $Date: 2020-03-16 15:06:00 +0100 (lun. 16 mars 2020) $)
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({ RestConnectorPool.class, ILoadBalancer.class, URLBalancedElement.class, RestInstance.class })
public class STARKConnectorTest extends EasyMockSupport
{

  /**
   * URI param
   */
  private static final String PARAM_URI = "URI"; //$NON-NLS-1$

  /**
   * The URI value
   */
  private final static String URI_VALUE = "http://server.com/path/to/service"; //$NON-NLS-1$

  /**
   * The constant for JsonErrorMessage
   */
  private static final String MESSAGE_JSON_ERROR_MESSAGE = Messages.getString("STARKConnector.JsonErrorMessage"); //$NON-NLS-1$

  /**
   * Class Initialization method
   */
  @BeforeClass
  public static void init()
  {
    ACManagerUtil.resetACManager();
    //    new ClassPathXmlApplicationContext("classpath:beans.xml"); //$NON-NLS-1$
  }

  /**
   * The constant for the « SPIRIT_STARK » in the request header
   */
  private MultivaluedHashMap<String, String> _headers;

  /**
   * Factory to generate beans
   */
  private PodamFactory _podam = new PodamFactoryImpl();

  /**
   * The instance to be tested
   */
  private STARKConnector _instance;

  /**
   * The Tracability
   */
  private Tracabilite _tracabilite;

  /**
   * Mock of connectors pool HTTP
   */
  @MockStrict
  Hashtable<String, RestConnectorPool> _connectorPoolMock;

  /**
   * Mock {@link RestConnectorPool}
   */
  @MockStrict
  RestConnectorPool _restConnectorPoolMock;

  /**
   * Mock {@link ILoadBalancer}
   */
  @MockStrict
  ILoadBalancer<URLBalancedElement> _loadBalancerMock;

  /**
   * Mock {@link URLBalancedElement}
   */
  @MockStrict
  URLBalancedElement _urlBalancedElementMock;

  /**
   * Mock {@link RestInstance}
   */
  @MockStrict
  RestInstance _restInstanceMock;

  /**
   * The URI
   */
  String _uri = URI_VALUE;

  /**
   * The url balanced name
   */
  private String _urlBalancedElementName = RandomStringUtils.randomAlphanumeric(45);

  /**
   * Initialize before tests
   *
   * @throws Exception
   *           Thrown in case of error during switch in attributes of parent class
   */
  @Before
  public void beforeTest() throws Exception
  {
    _podam.getStrategy().setMemoization(false);
    _podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());

    _instance = new STARKConnector();
    _tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);

    _headers = new MultivaluedHashMap<>();
    _headers.add(IHttpHeadersConsts.X_OAUTH2_HABILIT, IHttpHeadersConsts.SPIRIT_STARK_ROLE);
    _headers.put(IHttpHeadersConsts.CONTENT_TYPE, new ArrayList<>(Arrays.asList(MediaType.APPLICATION_JSON)));
    _headers.put(IHttpHeadersConsts.X_REQUEST_ID, new ArrayList<>(Arrays.asList(_tracabilite.getIdCorrelationByTel())));
    _headers.put(IHttpHeadersConsts.X_REQUEST_ID_SPIRIT, new ArrayList<>(Arrays.asList(_tracabilite.getIdCorrelationSpirit())));
    _headers.put(IHttpHeadersConsts.X_SOURCE, new ArrayList<>(Arrays.asList(_tracabilite.getNomSysteme())));
    _headers.put(IHttpHeadersConsts.X_PROCESS, new ArrayList<>(Arrays.asList(_tracabilite.getNomProcessus())));
    _headers.put(IHttpHeadersConsts.X_PROCESS_ID_SPIRIT, new ArrayList<>(Arrays.asList(_tracabilite.getIdProcessusSpirit())));
    _tracabilite.getRefFonc().forEach((key, value) -> _headers.put(IHttpHeadersConsts.X_TRACE.concat(key), new ArrayList<>(Arrays.asList(value))));

    //    _connector = new Connector();
    //    initializeConnectorParameters(_connector);
    //    _connector.setURLS(generateURLS());

    //    _rstConnector = new RSTConnector();
    //    _rstConnector.loadConnectorConfiguration(_connector);
    //    JUnitTools.setInaccessibleFieldValue(_rstConnector, "_loadBalancer", _loadBalancerMock); //$NON-NLS-1$
    //    JUnitTools.setInaccessibleFieldValue(_rstConnector, "_connectorPool", _connectorPoolMock); //$NON-NLS-1$
    //    _tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);

    PowerMock.resetAll();
    PowerMock.mockStaticNice(RestConnectorPool.class);
    PowerMock.mockStaticNice(ILoadBalancer.class);
    PowerMock.mockStaticNice(URLBalancedElement.class);
    PowerMock.mockStaticNice(RestInstance.class);

    PowerMock.resetAll();
  }

  /**
   * There is an exception when calling the send Method
   *
   * Expected: ConnectorResponse<Retour, STARKReturnTestStruct> - Retor NOK, IMegConsts.CAT2,
   * IMegConsts.SERVICE_TIERS_INDISPONIBLE
   *
   * Test method
   * {@link STARKConnector#sendDeleteRequest(Tracabilite, Class, java.io.Serializable, javax.ws.rs.core.MultivaluedMap, java.util.Map)}
   *
   * @throws Exception
   *           Thrown in case of error
   */
  @Test
  public void starkConnectorTest_SendDeleteRequest_KO_000() throws Exception
  {
    Connector connector = initializeConnectorParameters();
    NullPointerException exception = new NullPointerException("Exception message."); //$NON-NLS-1$

    Retour expected = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, exception.getMessage());

    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.delete(URI_VALUE, _headers, null, null)).andThrow(exception);
    _loadBalancerMock.setKOElement(_urlBalancedElementMock);
    EasyMock.expectLastCall();
    EasyMock.expect(_urlBalancedElementMock.getName()).andReturn(_urlBalancedElementName);
    _restConnectorPoolMock.returnObject(_restInstanceMock);
    EasyMock.expectLastCall();
    PowerMock.replayAll();

    // test
    _instance.loadConnectorConfiguration(connector);

    JUnitTools.setInaccessibleFieldValue(_instance, "_loadBalancer", _loadBalancerMock); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_instance, "_connectorPool", _connectorPoolMock); //$NON-NLS-1$

    ConnectorResponse<Retour, STARKResponse<STARKReturnTestStruct>> result = _instance.sendDeleteRequest(_tracabilite, _uri, STARKReturnTestStruct.class, null, GsonTools.getIso8601Ms(), _headers, null);

    PowerMock.verifyAll();
    // assertions
    Assert.assertEquals(expected.getResultat(), result._first.getResultat());
    Assert.assertEquals(expected.getCategorie(), result._first.getCategorie());
    Assert.assertEquals(expected.getDiagnostic(), result._first.getDiagnostic());
    Assert.assertEquals(expected.getActivite(), result._first.getActivite());
    Assert.assertEquals(null, result._second);
  }

  /**
   * Nominal test case
   *
   * Expected: ConnectorResponse<Retour, STARKReturnTestStruct> - Retor OK
   *
   * Test method
   * {@link STARKConnector#sendDeleteRequest(Tracabilite, Class, java.io.Serializable, javax.ws.rs.core.MultivaluedMap, java.util.Map)}
   *
   * @throws Exception
   *           Thrown in case of error
   */
  @Test
  public void starkConnectorTest_SendDeleteRequest_OK_000() throws Exception
  {
    Connector connector = initializeConnectorParameters();
    STARKResponse<STARKReturnTestStruct> expected = new STARKResponse<STARKReturnTestStruct>(200, _headers);
    STARKReturnTestStruct starkResponse = new STARKReturnTestStruct();
    starkResponse.setIntField(100);
    starkResponse.setStringField(StringConstants.ID_CLIENT);
    List<String> listString = new ArrayList<>();
    listString.add(StringConstants.CONTINUE_PROCESS);
    listString.add(StringConstants.HTTP_METHOD);
    listString.add(StringConstants.NUMTELFIXE);
    starkResponse.setListField(listString);
    expected.setResponse(starkResponse);

    String partnerResponse = GsonTools.getIso8601Ms().toJson(starkResponse);
    Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.delete(URI_VALUE, _headers, null, null)).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);
    EasyMock.expectLastCall();
    PowerMock.replayAll();

    // test
    _instance.loadConnectorConfiguration(connector);

    JUnitTools.setInaccessibleFieldValue(_instance, "_loadBalancer", _loadBalancerMock); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_instance, "_connectorPool", _connectorPoolMock); //$NON-NLS-1$

    ConnectorResponse<Retour, STARKResponse<STARKReturnTestStruct>> result = _instance.sendDeleteRequest(_tracabilite, _uri, STARKReturnTestStruct.class, null, GsonTools.getIso8601Ms(), _headers, null);

    PowerMock.verifyAll();
    // assertions
    Assert.assertEquals(RetourFactoryForTU.createOkRetour(), result._first);
    Assert.assertEquals(expected.getHttpStatusCode(), result._second.getHttpStatusCode());
    Assert.assertEquals(expected.getResponse(), result._second.getResponse());
  }

  /**
   * The jsonResponse is null or empty
   *
   * Expected: ConnectorResponse<Retour, STARKReturnTestStruct> - Retor OK
   *
   *
   * Test method
   * {@link STARKConnector#sendDeleteRequest(Tracabilite, Class, java.io.Serializable, javax.ws.rs.core.MultivaluedMap, java.util.Map)}
   *
   * @throws Exception
   *           Thrown in case of error
   */
  @Test
  public void starkConnectorTest_SendDeleteRequest_OK_001() throws Exception
  {
    Connector connector = initializeConnectorParameters();

    Response response = new ResponseBuilderImpl().status(200).entity(null).build();

    Retour expected = RetourFactoryForTU.createOkRetour();
    STARKResponse<STARKReturnTestStruct> expectedResponse = new STARKResponse<>(200, _headers);

    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.delete(URI_VALUE, _headers, null, null)).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);
    EasyMock.expectLastCall();
    PowerMock.replayAll();
    // test
    _instance.loadConnectorConfiguration(connector);

    JUnitTools.setInaccessibleFieldValue(_instance, "_loadBalancer", _loadBalancerMock); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_instance, "_connectorPool", _connectorPoolMock); //$NON-NLS-1$

    ConnectorResponse<Retour, STARKResponse<STARKReturnTestStruct>> result = _instance.sendDeleteRequest(_tracabilite, _uri, STARKReturnTestStruct.class, null, GsonTools.getIso8601Ms(), _headers, null);

    PowerMock.verifyAll();
    // assertions
    Assert.assertEquals(expected, result._first);
    Assert.assertEquals(expectedResponse.getResponse(), result._second.getResponse());
    Assert.assertEquals(expectedResponse.getReponseErreur(), result._second.getReponseErreur());
    Assert.assertEquals(expectedResponse.getHttpStatusCode(), result._second.getHttpStatusCode());
  }

  /**
   * There is an exception when calling the send Method
   *
   * Expected: ConnectorResponse<Retour, STARKReturnTestStruct> - Retor NOK, IMegConsts.CAT2,
   * IMegConsts.SERVICE_TIERS_INDISPONIBLE
   *
   * Test method
   * {@link STARKConnector#sendGetRequest(Tracabilite, Class, java.io.Serializable, javax.ws.rs.core.MultivaluedMap, java.util.Map)}
   *
   * @throws Exception
   *           Thrown in case of error
   */
  @Test
  public void starkConnectorTest_SendGetRequest_KO_000() throws Exception
  {
    Connector connector = initializeConnectorParameters();
    NullPointerException exception = new NullPointerException("Exception message."); //$NON-NLS-1$

    Retour expected = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, exception.getMessage());

    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.get(URI_VALUE, _headers, null)).andThrow(exception);
    _loadBalancerMock.setKOElement(_urlBalancedElementMock);
    EasyMock.expectLastCall();
    EasyMock.expect(_urlBalancedElementMock.getName()).andReturn(_urlBalancedElementName);
    _restConnectorPoolMock.returnObject(_restInstanceMock);
    EasyMock.expectLastCall();
    PowerMock.replayAll();

    // test
    _instance.loadConnectorConfiguration(connector);

    JUnitTools.setInaccessibleFieldValue(_instance, "_loadBalancer", _loadBalancerMock); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_instance, "_connectorPool", _connectorPoolMock); //$NON-NLS-1$

    ConnectorResponse<Retour, STARKResponse<STARKReturnTestStruct>> result = _instance.sendGetRequest(_tracabilite, _uri, STARKReturnTestStruct.class, null, GsonTools.getIso8601Ms(), _headers, null);

    PowerMock.verifyAll();
    // assertions
    Assert.assertEquals(expected.getResultat(), result._first.getResultat());
    Assert.assertEquals(expected.getCategorie(), result._first.getCategorie());
    Assert.assertEquals(expected.getDiagnostic(), result._first.getDiagnostic());
    Assert.assertEquals(expected.getActivite(), result._first.getActivite());
    Assert.assertEquals(null, result._second);
  }

  /**
   * Nominal test case
   *
   * Expected: ConnectorResponse<Retour, STARKReturnTestStruct> - Retor OK
   *
   * Test method
   * {@link STARKConnector#sendGetRequest(Tracabilite, Class, java.io.Serializable, javax.ws.rs.core.MultivaluedMap, java.util.Map)}
   *
   * @throws Exception
   *           Thrown in case of error
   */
  @Test
  public void starkConnectorTest_SendGetRequest_OK_000() throws Exception
  {
    Connector connector = initializeConnectorParameters();
    STARKResponse<STARKReturnTestStruct> expected = new STARKResponse<STARKReturnTestStruct>(200, _headers);
    STARKReturnTestStruct starkResponse = new STARKReturnTestStruct();
    starkResponse.setIntField(100);
    starkResponse.setStringField(StringConstants.ID_CLIENT);
    List<String> listString = new ArrayList<>();
    listString.add(StringConstants.CONTINUE_PROCESS);
    listString.add(StringConstants.HTTP_METHOD);
    listString.add(StringConstants.NUMTELFIXE);
    starkResponse.setListField(listString);
    expected.setResponse(starkResponse);

    String partnerResponse = GsonTools.getIso8601Ms().toJson(starkResponse);
    Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.get(URI_VALUE, _headers, null)).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);
    EasyMock.expectLastCall();
    PowerMock.replayAll();

    // test
    _instance.loadConnectorConfiguration(connector);

    JUnitTools.setInaccessibleFieldValue(_instance, "_loadBalancer", _loadBalancerMock); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_instance, "_connectorPool", _connectorPoolMock); //$NON-NLS-1$

    ConnectorResponse<Retour, STARKResponse<STARKReturnTestStruct>> result = _instance.sendGetRequest(_tracabilite, _uri, STARKReturnTestStruct.class, null, GsonTools.getIso8601Ms(), _headers, null);

    PowerMock.verifyAll();
    // assertions
    Assert.assertEquals(RetourFactoryForTU.createOkRetour(), result._first);
    Assert.assertEquals(expected.getHttpStatusCode(), result._second.getHttpStatusCode());
    Assert.assertEquals(expected.getResponse(), result._second.getResponse());
  }

  /**
   * The jsonResponse is null or empty
   *
   * Expected: ConnectorResponse<Retour, STARKReturnTestStruct> - Retor OK IMegConsts.TRAITEMENT_ARRETE
   *
   * Test method
   * {@link STARKConnector#sendGetRequest(Tracabilite, Class, java.io.Serializable, javax.ws.rs.core.MultivaluedMap, java.util.Map)}
   *
   * @throws Exception
   *           Thrown in case of error
   */
  @Test
  public void starkConnectorTest_SendGetRequest_OK_001() throws Exception
  {
    Connector connector = initializeConnectorParameters();

    Response response = new ResponseBuilderImpl().status(200).entity(null).build();

    Retour expected = RetourFactoryForTU.createOkRetour();
    STARKResponse<STARKReturnTestStruct> expectedResponse = new STARKResponse<>(200, _headers);

    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.get(URI_VALUE, _headers, null)).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);
    EasyMock.expectLastCall();
    PowerMock.replayAll();

    // test
    _instance.loadConnectorConfiguration(connector);

    JUnitTools.setInaccessibleFieldValue(_instance, "_loadBalancer", _loadBalancerMock); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_instance, "_connectorPool", _connectorPoolMock); //$NON-NLS-1$

    ConnectorResponse<Retour, STARKResponse<STARKReturnTestStruct>> result = _instance.sendGetRequest(_tracabilite, _uri, STARKReturnTestStruct.class, null, GsonTools.getIso8601Ms(), _headers, null);

    PowerMock.verifyAll();
    // assertions
    Assert.assertEquals(expected, result._first);
    Assert.assertEquals(expectedResponse.getResponse(), result._second.getResponse());
    Assert.assertEquals(expectedResponse.getReponseErreur(), result._second.getReponseErreur());
    Assert.assertEquals(expectedResponse.getHttpStatusCode(), result._second.getHttpStatusCode());
  }

  /**
   * There is an exception when calling the send Method
   *
   * Expected: ConnectorResponse<Retour, STARKReturnTestStruct> - Retor NOK, IMegConsts.CAT2,
   * IMegConsts.SERVICE_TIERS_INDISPONIBLE
   *
   * Test method
   * {@link STARKConnector#sendPostRequest(Tracabilite, Class, java.io.Serializable, javax.ws.rs.core.MultivaluedMap, java.util.Map)}
   *
   * @throws Exception
   *           Thrown in case of error
   */
  @Test
  public void starkConnectorTest_SendPostRequest_KO_000() throws Exception
  {
    STARKRequestTestStruct request = new STARKRequestTestStruct();
    Connector connector = initializeConnectorParameters();
    NullPointerException exception = new NullPointerException("Exception message."); //$NON-NLS-1$

    String jsonRequest = GsonTools.getIso8601Ms().toJson(request);

    Retour expected = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, exception.getMessage());

    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.post(URI_VALUE, _headers, jsonRequest, null)).andThrow(exception);
    _loadBalancerMock.setKOElement(_urlBalancedElementMock);
    EasyMock.expectLastCall();
    EasyMock.expect(_urlBalancedElementMock.getName()).andReturn(_urlBalancedElementName);
    _restConnectorPoolMock.returnObject(_restInstanceMock);
    EasyMock.expectLastCall();
    PowerMock.replayAll();

    // test
    _instance.loadConnectorConfiguration(connector);

    JUnitTools.setInaccessibleFieldValue(_instance, "_loadBalancer", _loadBalancerMock); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_instance, "_connectorPool", _connectorPoolMock); //$NON-NLS-1$

    ConnectorResponse<Retour, STARKResponse<STARKReturnTestStruct>> result = _instance.sendPostRequest(_tracabilite, _uri, STARKReturnTestStruct.class, request, GsonTools.getIso8601Ms(), _headers, null);

    PowerMock.verifyAll();
    // assertions
    Assert.assertEquals(expected.getResultat(), result._first.getResultat());
    Assert.assertEquals(expected.getCategorie(), result._first.getCategorie());
    Assert.assertEquals(expected.getDiagnostic(), result._first.getDiagnostic());
    Assert.assertEquals(expected.getActivite(), result._first.getActivite());
    Assert.assertEquals(null, result._second);
  }

  /**
   * Nominal test case
   *
   * Expected: ConnectorResponse<Retour, STARKReturnTestStruct> - Retor OK
   *
   * Test method
   * {@link STARKConnector#sendPostRequest(Tracabilite, Class, java.io.Serializable, javax.ws.rs.core.MultivaluedMap, java.util.Map)}
   *
   * @throws Exception
   *           Thrown in case of error
   */
  @Test
  public void starkConnectorTest_SendPostRequest_OK_000() throws Exception
  {
    STARKRequestTestStruct request = new STARKRequestTestStruct();
    request.setIntField(50);
    Connector connector = initializeConnectorParameters();
    STARKResponse<STARKReturnTestStruct> expected = new STARKResponse<STARKReturnTestStruct>(200, _headers);
    STARKReturnTestStruct starkResponse = new STARKReturnTestStruct();
    starkResponse.setIntField(100);
    starkResponse.setStringField(StringConstants.ID_CLIENT);
    List<String> listString = new ArrayList<>();
    listString.add(StringConstants.CONTINUE_PROCESS);
    listString.add(StringConstants.HTTP_METHOD);
    listString.add(StringConstants.NUMTELFIXE);
    starkResponse.setListField(listString);
    expected.setResponse(starkResponse);

    String jsonRequest = GsonTools.getIso8601Ms().toJson(request);

    String partnerResponse = GsonTools.getIso8601Ms().toJson(starkResponse);
    Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.post(URI_VALUE, _headers, jsonRequest, null)).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);
    EasyMock.expectLastCall();
    PowerMock.replayAll();

    // test
    _instance.loadConnectorConfiguration(connector);

    JUnitTools.setInaccessibleFieldValue(_instance, "_loadBalancer", _loadBalancerMock); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_instance, "_connectorPool", _connectorPoolMock); //$NON-NLS-1$

    ConnectorResponse<Retour, STARKResponse<STARKReturnTestStruct>> result = _instance.sendPostRequest(_tracabilite, _uri, STARKReturnTestStruct.class, request, GsonTools.getIso8601Ms(), _headers, null);

    PowerMock.verifyAll();
    // assertions
    Assert.assertEquals(RetourFactoryForTU.createOkRetour(), result._first);
    Assert.assertEquals(expected.getHttpStatusCode(), result._second.getHttpStatusCode());
    Assert.assertEquals(expected.getResponse(), result._second.getResponse());
  }

  /**
   * The jsonResponse is null or empty
   *
   * Expected: ConnectorResponse<Retour, STARKReturnTestStruct> - Retor OK
   *
   * Test method
   * {@link STARKConnector#sendPostRequest(Tracabilite, Class, java.io.Serializable, javax.ws.rs.core.MultivaluedMap, java.util.Map)}
   *
   * @throws Exception
   *           Thrown in case of error
   */
  @Test
  public void starkConnectorTest_SendPostRequest_OK_001() throws Exception
  {
    STARKRequestTestStruct request = new STARKRequestTestStruct();
    Connector connector = initializeConnectorParameters();

    String jsonRequest = GsonTools.getIso8601Ms().toJson(request);

    Response response = new ResponseBuilderImpl().status(200).entity(null).build();

    Retour expected = RetourFactoryForTU.createOkRetour();
    STARKResponse<STARKReturnTestStruct> expectedResponse = new STARKResponse<>(200, _headers);
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.post(URI_VALUE, _headers, jsonRequest, null)).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);
    EasyMock.expectLastCall();
    PowerMock.replayAll();

    // test
    _instance.loadConnectorConfiguration(connector);

    JUnitTools.setInaccessibleFieldValue(_instance, "_loadBalancer", _loadBalancerMock); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_instance, "_connectorPool", _connectorPoolMock); //$NON-NLS-1$

    ConnectorResponse<Retour, STARKResponse<STARKReturnTestStruct>> result = _instance.sendPostRequest(_tracabilite, _uri, STARKReturnTestStruct.class, request, GsonTools.getIso8601Ms(), _headers, null);

    PowerMock.verifyAll();
    // assertions
    Assert.assertEquals(expected, result._first);
    Assert.assertEquals(expectedResponse.getResponse(), result._second.getResponse());
    Assert.assertEquals(expectedResponse.getReponseErreur(), result._second.getReponseErreur());
    Assert.assertEquals(expectedResponse.getHttpStatusCode(), result._second.getHttpStatusCode());
  }

  /**
   * There is an exception when calling the send Method
   *
   * Expected: ConnectorResponse<Retour, STARKReturnTestStruct> - Retor NOK, IMegConsts.CAT2,
   * IMegConsts.SERVICE_TIERS_INDISPONIBLE
   *
   * Test method
   * {@link STARKConnector#sendPutRequest(Tracabilite, Class, java.io.Serializable, javax.ws.rs.core.MultivaluedMap, java.util.Map)}
   *
   * @throws Exception
   *           Thrown in case of error
   */
  @Test
  public void starkConnectorTest_SendPutRequest_KO_000() throws Exception
  {
    STARKRequestTestStruct request = new STARKRequestTestStruct();
    Connector connector = initializeConnectorParameters();
    NullPointerException exception = new NullPointerException("Exception message."); //$NON-NLS-1$

    String jsonRequest = GsonTools.getIso8601Ms().toJson(request);

    Retour expected = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, exception.getMessage());

    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.put(URI_VALUE, _headers, jsonRequest, null)).andThrow(exception);
    _loadBalancerMock.setKOElement(_urlBalancedElementMock);
    EasyMock.expectLastCall();
    EasyMock.expect(_urlBalancedElementMock.getName()).andReturn(_urlBalancedElementName);
    _restConnectorPoolMock.returnObject(_restInstanceMock);
    EasyMock.expectLastCall();
    PowerMock.replayAll();

    // test
    _instance.loadConnectorConfiguration(connector);

    JUnitTools.setInaccessibleFieldValue(_instance, "_loadBalancer", _loadBalancerMock); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_instance, "_connectorPool", _connectorPoolMock); //$NON-NLS-1$

    ConnectorResponse<Retour, STARKResponse<STARKReturnTestStruct>> result = _instance.sendPutRequest(_tracabilite, _uri, STARKReturnTestStruct.class, request, GsonTools.getIso8601Ms(), _headers, null);

    PowerMock.verifyAll();
    // assertions
    Assert.assertEquals(expected.getResultat(), result._first.getResultat());
    Assert.assertEquals(expected.getCategorie(), result._first.getCategorie());
    Assert.assertEquals(expected.getDiagnostic(), result._first.getDiagnostic());
    Assert.assertEquals(expected.getActivite(), result._first.getActivite());
    Assert.assertEquals(null, result._second);
  }

  /**
   * Nominal test case
   *
   * Expected: ConnectorResponse<Retour, STARKReturnTestStruct> - Retor OK
   *
   * Test method
   * {@link STARKConnector#sendPutRequest(Tracabilite, Class, java.io.Serializable, javax.ws.rs.core.MultivaluedMap, java.util.Map)}
   *
   * @throws Exception
   *           Thrown in case of error
   */
  @Test
  public void starkConnectorTest_SendPutRequest_OK_000() throws Exception
  {
    STARKRequestTestStruct request = new STARKRequestTestStruct();
    request.setIntField(50);
    Connector connector = initializeConnectorParameters();
    STARKResponse<STARKReturnTestStruct> expected = new STARKResponse<STARKReturnTestStruct>(200, _headers);
    STARKReturnTestStruct starkResponse = new STARKReturnTestStruct();
    starkResponse.setIntField(100);
    starkResponse.setStringField(StringConstants.ID_CLIENT);
    List<String> listString = new ArrayList<>();
    listString.add(StringConstants.CONTINUE_PROCESS);
    listString.add(StringConstants.HTTP_METHOD);
    listString.add(StringConstants.NUMTELFIXE);
    starkResponse.setListField(listString);
    expected.setResponse(starkResponse);

    String jsonRequest = GsonTools.getIso8601Ms().toJson(request);

    String partnerResponse = GsonTools.getIso8601Ms().toJson(starkResponse);
    Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.put(URI_VALUE, _headers, jsonRequest, null)).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);
    EasyMock.expectLastCall();
    PowerMock.replayAll();

    // test
    _instance.loadConnectorConfiguration(connector);

    JUnitTools.setInaccessibleFieldValue(_instance, "_loadBalancer", _loadBalancerMock); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_instance, "_connectorPool", _connectorPoolMock); //$NON-NLS-1$

    ConnectorResponse<Retour, STARKResponse<STARKReturnTestStruct>> result = _instance.sendPutRequest(_tracabilite, _uri, STARKReturnTestStruct.class, request, GsonTools.getIso8601Ms(), _headers, null);

    PowerMock.verifyAll();
    // assertions
    Assert.assertEquals(RetourFactoryForTU.createOkRetour(), result._first);
    Assert.assertEquals(expected.getHttpStatusCode(), result._second.getHttpStatusCode());
    Assert.assertEquals(expected.getResponse(), result._second.getResponse());
  }

  /**
   * The jsonResponse is null or empty
   *
   * Expected: ConnectorResponse<Retour, STARKReturnTestStruct> - Retor OK
   *
   * Test method
   * {@link STARKConnector#sendGetRequest(Tracabilite, Class, java.io.Serializable, javax.ws.rs.core.MultivaluedMap, java.util.Map)}
   *
   * @throws Exception
   *           Thrown in case of error
   */
  @Test
  public void starkConnectorTest_SendPutRequest_OK_001() throws Exception
  {
    STARKRequestTestStruct request = new STARKRequestTestStruct();
    Connector connector = initializeConnectorParameters();

    String jsonRequest = GsonTools.getIso8601Ms().toJson(request);

    Response response = new ResponseBuilderImpl().status(200).entity(null).build();

    Retour expected = RetourFactoryForTU.createOkRetour();
    STARKResponse<STARKReturnTestStruct> expectedResponse = new STARKResponse<>(200, _headers);
    initializeMocksForSendRequest();
    EasyMock.expect(_restInstanceMock.put(URI_VALUE, _headers, jsonRequest, null)).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);
    EasyMock.expectLastCall();
    PowerMock.replayAll();

    // test
    _instance.loadConnectorConfiguration(connector);

    JUnitTools.setInaccessibleFieldValue(_instance, "_loadBalancer", _loadBalancerMock); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_instance, "_connectorPool", _connectorPoolMock); //$NON-NLS-1$

    ConnectorResponse<Retour, STARKResponse<STARKReturnTestStruct>> result = _instance.sendPutRequest(_tracabilite, _uri, STARKReturnTestStruct.class, request, GsonTools.getIso8601Ms(), _headers, null);

    PowerMock.verifyAll();
    // assertions
    Assert.assertEquals(expected, result._first);
    Assert.assertEquals(expectedResponse.getResponse(), result._second.getResponse());
    Assert.assertEquals(expectedResponse.getReponseErreur(), result._second.getReponseErreur());
    Assert.assertEquals(expectedResponse.getHttpStatusCode(), result._second.getHttpStatusCode());
  }

  /**
   * Adds one parameter to the connector conf
   *
   * @param connector_p
   *          The connector
   * @param name_p
   *          The parameter name
   * @param value_p
   *          The parameter value
   */
  private void addParameter(Connector connector_p, String name_p, String value_p)
  {
    Param param = new Param();
    param.setName(name_p);
    param.setValue(value_p);
    connector_p.getParam().add(param);
  }

  /**
   * Génération du LoadBalancer minimal pour passer {@link AbstractRESTConnector#loadConnectorConfiguration(Connector)}
   *
   * @return {@link LoadBalancer}
   */
  private LoadBalancer generateLoadBalancer()
  {
    final LoadBalancer loadBalancer = new LoadBalancer();
    Param timer = new Param();
    timer.setName("TIMER"); //$NON-NLS-1$
    timer.setValue("30"); //$NON-NLS-1$
    loadBalancer.getParam().add(timer);
    loadBalancer.setType("RoundRobin"); //$NON-NLS-1$
    return loadBalancer;
  }

  /**
   * Génération du URL minimal pour passer {@link AbstractRESTConnector#loadConnectorConfiguration(Connector)}
   *
   * @return {@link URL}
   */
  private URL generateURL()
  {
    final URL url = new URL();
    url.setName("urlName"); //$NON-NLS-1$
    url.setAccessPoint("http://localhost:8888"); //$NON-NLS-1$
    Param param = new Param();
    param.setName("PROXY_ENABLED"); //$NON-NLS-1$
    param.setValue(String.valueOf(false));
    url.getParam().add(param);
    param = new Param();
    param.setName("TIMEOUT"); //$NON-NLS-1$
    param.setValue("30"); //$NON-NLS-1$
    url.getParam().add(param);

    return url;
  }

  /**
   * Génération du URLS minimal pour passer {@link AbstractRESTConnector#loadConnectorConfiguration(Connector)}
   *
   * @return {@link URLS}
   */
  private URLS generateURLS()
  {
    final URLS urls = new URLS();
    urls.setLoadBalancer(generateLoadBalancer());
    urls.getURL().add(generateURL());
    return urls;
  }

  /**
   * Initializes the connector parameters
   *
   * @return {@link Connector}
   */
  private Connector initializeConnectorParameters()
  {
    Connector connector = new Connector();

    connector.setName(ISTARKConnector.BEAN_ID);
    connector.setClazz("com.bytel.spirit.common.connectors.stark.STARKConnector"); //$NON-NLS-1$
    connector.setType("client"); //$NON-NLS-1$
    connector.setEnabled(true);

    connector.setURLS(generateURLS());

    addParameter(connector, PARAM_URI, URI_VALUE);

    return connector;
  }

  /**
   * prepare mock scenario to initialize method sendRequest from AbstractRestConnector
   *
   * @throws Exception
   *           Thrown in case of error
   */
  private void initializeMocksForSendRequest() throws Exception
  {
    final String urlBalancedElementDescription = RandomStringUtils.randomAlphabetic(9);

    EasyMock.expect(_loadBalancerMock.chooseBalancedElement()).andReturn(_urlBalancedElementMock);
    EasyMock.expect(_urlBalancedElementMock.getName()).andReturn(_urlBalancedElementName);
    EasyMock.expect(_urlBalancedElementMock.getDescription()).andReturn(urlBalancedElementDescription);
    EasyMock.expect(_urlBalancedElementMock.getName()).andReturn(_urlBalancedElementName);
    EasyMock.expect(_connectorPoolMock.get(_urlBalancedElementName)).andReturn(_restConnectorPoolMock);
    EasyMock.expect(_restConnectorPoolMock.borrowObject()).andReturn(_restInstanceMock);
    _restInstanceMock.setReceiveTimeout(30);
  }
}
