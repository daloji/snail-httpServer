/*******************************************************************************
* $Id: STARKRequestTestStruct.java 9771 2018-09-03 10:31:04Z pcarreir $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.stark.structs;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author pcarreir
 * @version ($Revision: 9771 $ $Date: 2018-09-03 12:31:04 +0200 (lun. 03 sept. 2018) $)
 */
public class STARKRequestTestStruct implements Serializable
{

  /**
   * The serial version UID
   */
  private static final long serialVersionUID = -834661045819092715L;

  /**
   * Test purposes only
   */
  private List<String> _listField;

  /**
   * Test purposes only
   */
  private int _intField;

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    STARKRequestTestStruct other = (STARKRequestTestStruct) obj;
    if (_intField != other._intField)
    {
      return false;
    }
    if (_listField == null)
    {
      if (other._listField != null)
      {
        return false;
      }
    }
    else if (!_listField.equals(other._listField))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the intField
   */
  public int getIntField()
  {
    return _intField;
  }

  /**
   * @return the listField
   */
  public List<String> getListField()
  {
    return new ArrayList<>(_listField);
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + _intField;
    result = (prime * result) + ((_listField == null) ? 0 : _listField.hashCode());
    return result;
  }

  /**
   * @param intField_p
   *          the intField to set
   */
  public void setIntField(int intField_p)
  {
    _intField = intField_p;
  }

  /**
   * @param listField_p
   *          the listField to set
   */
  public void setListField(List<String> listField_p)
  {
    _listField = new ArrayList<>(listField_p);
  }

  @Override
  public String toString()
  {
    return "STARKReturnStructTest [_listField=" + _listField + ", _intField=" + _intField + "]"; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
  }

}
