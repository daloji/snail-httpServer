/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.stark;

import java.io.Serializable;
import java.util.Map;

import javax.ws.rs.core.MultivaluedMap;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.connector.RESTRequest;
import com.bytel.spirit.common.connectors.stark.structs.STARKResponse;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.google.gson.Gson;

/**
 *
 * @author jgregori
 * @version ($Revision$ $Date$)
 */
public interface ISTARK
{

  /**
   * Send a DELETE request to the STARK system.
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param uri_p
   *          The uri of the REST service
   * @param responseClass_p
   *          Class of the response
   * @param request_p
   *          Request
   * @param gsonParser_p
   *          Gson parser
   * @param headers_p
   *          Map of Headers
   * @param queryParams_p
   *          Map of query parameters
   * @return ConnectorResponse
   * @throws RavelException
   *           Exception if thrown
   */
  @Deprecated
  public <T> ConnectorResponse<Retour, STARKResponse<T>> sendDeleteRequest(Tracabilite tracabilite_p, String uri_p, Class<T> responseClass_p, Serializable request_p, Gson gsonParser_p, MultivaluedMap<String, String> headers_p, Map<String, String> queryParams_p) throws RavelException;

  /**
   * Send a GET request to the STARK system.
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param uri_p
   *          The uri of the REST service
   * @param responseClass_p
   *          Class of the response
   * @param request_p
   *          Request
   * @param gsonParser_p
   *          Gson parser
   * @param headers_p
   *          Map of Headers
   * @param queryParams_p
   *          Map of query parameters
   * @return ConnectorResponse
   * @throws RavelException
   *           Exception if thrown
   */
  @Deprecated
  public <T> ConnectorResponse<Retour, STARKResponse<T>> sendGetRequest(Tracabilite tracabilite_p, String uri_p, Class<T> responseClass_p, Serializable request_p, Gson gsonParser_p, MultivaluedMap<String, String> headers_p, Map<String, String> queryParams_p) throws RavelException;

  /**
   * Send a POST request to the STARK system.
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param uri_p
   *          The uri of the REST service
   * @param responseClass_p
   *          Class of the response
   * @param request_p
   *          Request
   * @param gsonParser_p
   *          TODO
   * @param headers_p
   *          Map of Headers
   * @param queryParams_p
   *          Map of query parameters
   * @return ConnectorResponse
   * @throws RavelException
   *           Exception if thrown
   */
  @Deprecated
  public <T> ConnectorResponse<Retour, STARKResponse<T>> sendPostRequest(Tracabilite tracabilite_p, String uri_p, Class<T> responseClass_p, Serializable request_p, Gson gsonParser_p, MultivaluedMap<String, String> headers_p, Map<String, String> queryParams_p) throws RavelException;

  /**
   * Send a PUT request to the STARK system.
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param uri_p
   *          The uri of the REST service
   * @param responseClass_p
   *          Class of the response
   * @param request_p
   *          Request
   * @param gsonParser_p
   *          TODO
   * @param queryParams_p
   *          Map of query parameters
   * @param headers_pDELETE
   *          Map of Headers
   * @return ConnectorResponse
   * @throws RavelException
   *           Exception if thrown
   */
  @Deprecated
  public <T> ConnectorResponse<Retour, STARKResponse<T>> sendPutRequest(Tracabilite tracabilite_p, String uri_p, Class<T> responseClass_p, Serializable request_p, Gson gsonParser_p, MultivaluedMap<String, String> headers_p, Map<String, String> queryParams_p) throws RavelException;

  /**
   * Send a request to the STARK system.
   * 
   * @param restRequest_p
   *          rest request
   * @param responseClass_p
   *          response class
   *
   * @return ConnectorResponse
   * @throws RavelException
   *           Exception if thrown
   */
  public <T> ConnectorResponse<Retour, STARKResponse<T>> sendRequest(RESTRequest restRequest_p, Class<T> responseClass_p) throws RavelException;

}
