/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.stark;

import java.io.Serializable;
import java.util.Map;

import javax.ws.rs.core.MultivaluedMap;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.probes.AvgDoubleCollectorItem;
import com.bytel.ravel.common.probes.AvgFlowPerSecondCollector;
import com.bytel.ravel.common.probes.RavelProbeConfigurationManager;
import com.bytel.ravel.services.connector.BaseProxy;
import com.bytel.ravel.services.connector.ConnectorExecution;
import com.bytel.ravel.services.connector.ConnectorManager;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.connector.RESTRequest;
import com.bytel.spirit.common.connectors.stark.structs.STARKResponse;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.google.gson.Gson;

/**
 *
 * @author jgregori
 * @version ($Revision$ $Date$)
 */
public final class STARKProxy extends BaseProxy implements ISTARK
{
  /**
   * Proxy instance.
   */
  private static STARKProxy _instance = new STARKProxy();

  /**
   * @return The proxy instance.
   */
  public static STARKProxy getInstance()
  {
    return _instance;
  }

  /**
   * For probe to count the amount of call to the sendDeleteRequest operation
   */
  AvgFlowPerSecondCollector _avg_sendDeleteRequest_call_counter;
  /**
   * For probe to count the execution time of call to the sendDeleteRequest operation
   */
  AvgDoubleCollectorItem _avg_sendDeleteRequest_ExecTime;
  /**
   * For probe to count the amount of call to the sendGetRequest operation
   */
  AvgFlowPerSecondCollector _avg_sendGetRequest_call_counter;
  /**
   * For probe to count the execution time of call to the sendGetRequest operation
   */
  AvgDoubleCollectorItem _avg_sendGetRequest_ExecTime;
  /**
   * For probe to count the amount of call to the sendPostRequest operation
   */
  AvgFlowPerSecondCollector _avg_sendPostRequest_call_counter;
  /**
   * For probe to count the execution time of call to the sendPostRequest operation
   */
  AvgDoubleCollectorItem _avg_sendPostRequest_ExecTime;
  /**
   * For probe to count the amount of call to the sendPutRequest operation
   */
  AvgFlowPerSecondCollector _avg_sendPutRequest_call_counter;
  /**
   * For probe to count the execution time of call to the sendPutRequest operation
   */
  AvgDoubleCollectorItem _avg_sendPutRequest_ExecTime;

  /**
   * For probe to count the amount of call to the sendRequest operation
   */
  AvgFlowPerSecondCollector _avg_sendRequest_call_counter;
  /**
   * For probe to count the execution time of call to the sendRequest operation
   */
  AvgDoubleCollectorItem _avg_sendRequest_ExecTime;

  /**
   * private Constructor
   */
  private STARKProxy()
  {
    _avg_sendDeleteRequest_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_sendDeleteRequest_call_counter", "STARKProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_sendDeleteRequest_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_sendDeleteRequest_ExecTime", "STARKProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_sendGetRequest_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_sendGetRequest_call_counter", "STARKProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_sendGetRequest_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_sendGetRequest_ExecTime", "STARKProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_sendPostRequest_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_sendPostRequest_call_counter", "STARKProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_sendPostRequest_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_sendPostRequest_ExecTime", "STARKProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_sendPutRequest_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_sendPutRequest_call_counter", "STARKProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_sendPutRequest_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_sendPutRequest_ExecTime", "STARKProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_sendRequest_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_sendRequest_call_counter", "STARKProxy"); //$NON-NLS-1$//$NON-NLS-2$
    _avg_sendRequest_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_sendRequest_ExecTime", "STARKProxy"); //$NON-NLS-1$//$NON-NLS-2$

  }

  @Override
  public <T> ConnectorResponse<Retour, STARKResponse<T>> sendDeleteRequest(Tracabilite tracabilite_p, String uri_p, Class<T> responseClass_p, Serializable request_p, Gson gsonParser_p, MultivaluedMap<String, String> headers_p, Map<String, String> queryParams_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, STARKResponse<T>>>(ISTARKConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, STARKResponse<T>> run() throws RavelException
      {
        ISTARKConnector starkConnector = (ISTARKConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_sendDeleteRequest_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return starkConnector.sendDeleteRequest(tracabilite_p, uri_p, responseClass_p, request_p, gsonParser_p, headers_p, queryParams_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_sendDeleteRequest_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public <T> ConnectorResponse<Retour, STARKResponse<T>> sendGetRequest(Tracabilite tracabilite_p, String uri_p, Class<T> responseClass_p, Serializable request_p, Gson gsonParser_p, MultivaluedMap<String, String> headers_p, Map<String, String> queryParams_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, STARKResponse<T>>>(ISTARKConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, STARKResponse<T>> run() throws RavelException
      {
        ISTARKConnector starkConnector = (ISTARKConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_sendGetRequest_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return starkConnector.sendGetRequest(tracabilite_p, uri_p, responseClass_p, request_p, gsonParser_p, headers_p, queryParams_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_sendGetRequest_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public <T> ConnectorResponse<Retour, STARKResponse<T>> sendPostRequest(Tracabilite tracabilite_p, String uri_p, Class<T> responseClass_p, Serializable request_p, Gson gsonParser_p, MultivaluedMap<String, String> headers_p, Map<String, String> queryParams_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, STARKResponse<T>>>(ISTARKConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, STARKResponse<T>> run() throws RavelException
      {
        ISTARKConnector starkConnector = (ISTARKConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_sendPostRequest_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return starkConnector.sendPostRequest(tracabilite_p, uri_p, responseClass_p, request_p, gsonParser_p, headers_p, queryParams_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_sendPostRequest_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public <T> ConnectorResponse<Retour, STARKResponse<T>> sendPutRequest(Tracabilite tracabilite_p, String uri_p, Class<T> responseClass_p, Serializable request_p, Gson gsonParser_p, MultivaluedMap<String, String> headers_p, Map<String, String> queryParams_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, STARKResponse<T>>>(ISTARKConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, STARKResponse<T>> run() throws RavelException
      {
        ISTARKConnector starkConnector = (ISTARKConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_sendPutRequest_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return starkConnector.sendPutRequest(tracabilite_p, uri_p, responseClass_p, request_p, gsonParser_p, headers_p, queryParams_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_sendPutRequest_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public <T> ConnectorResponse<Retour, STARKResponse<T>> sendRequest(RESTRequest restRequest_p, Class<T> responseClass_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, STARKResponse<T>>>(ISTARKConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, STARKResponse<T>> run() throws RavelException
      {
        ISTARKConnector starkConnector = (ISTARKConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_sendRequest_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return starkConnector.sendRequest(restRequest_p, responseClass_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_sendRequest_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

}
