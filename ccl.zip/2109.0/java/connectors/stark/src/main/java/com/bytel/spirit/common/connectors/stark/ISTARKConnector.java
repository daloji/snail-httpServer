/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.stark;

import com.bytel.ravel.services.connector.IConnector;

/**
 *
 * @author jgregori
 * @version ($Revision$ $Date$)
 */
public interface ISTARKConnector extends ISTARK, IConnector
{

  /**
   * The id to retrieve the connector.
   */
  public String BEAN_ID = "STARKConnector"; //$NON-NLS-1$
}
