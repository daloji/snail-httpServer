package com.bytel.spirit.common.connectors.acs.nbi1;

/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/

import java.util.ArrayList;
import java.util.Hashtable;

import javax.xml.bind.ValidationEventHandler;

import org.apache.cxf.endpoint.Client;
import org.apache.cxf.interceptor.Interceptor;
import org.easymock.EasyMock;
import org.easymock.EasyMockSupport;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.bytel.ravel.common.conf.generated.LoadBalancer;
import com.bytel.ravel.common.conf.generated.Param;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.test.JUnitTools;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.net.loadbalancing.Element;
import com.bytel.ravel.net.loadbalancing.ILoadBalancer;
import com.bytel.ravel.net.loadbalancing.URLBalancedElement;
import com.bytel.ravel.services.conf.connector.generated.Connector;
import com.bytel.ravel.services.conf.connector.generated.URL;
import com.bytel.ravel.services.conf.connector.generated.URLS;
import com.bytel.ravel.services.connector.AbstractSOAPConnector;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.connector.pools.soap.ISoapInterceptorsFactory;
import com.bytel.ravel.services.connector.pools.soap.SoapConnectorPool;
import com.bytel.ravel.services.connector.pools.soap.SoapInstance;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.netopia.nbbs.webservice.ArrayOfNamedValue;
import com.netopia.nbbs.webservice.ArrayOfServiceInfoStruct;
import com.netopia.nbbs.webservice.ArrayOfXsdString;
import com.netopia.nbbs.webservice.CpeIdentifier;
import com.netopia.nbbs.webservice.CpeProperties;
import com.netopia.nbbs.webservice.EventSink;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author csilva
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({ AbstractSOAPConnector.class })
public class AcsNbi1ConnectorTest extends EasyMockSupport
{
  /** */
  private static final String SERIAL_NUMBER = "serialNumber"; //$NON-NLS-1$

  /** */
  private static final String USER_ID = "userId"; //$NON-NLS-1$

  /**
   * Connector to test
   */
  private AcsNbi1Connector _connector;

  /**
   * Factory to generate beans
   */
  private PodamFactory _podam = new PodamFactoryImpl();

  /**
   * Mock {@link ILoadBalancer}
   */
  @MockStrict
  ILoadBalancer<URLBalancedElement> _loadBalancerMock;

  /**
   * Mock {@link URLBalancedElement}
   */
  @MockStrict
  URLBalancedElement _urlBalancedElementMock;

  /**
   * Mock of connectors pool HTTP
   */
  @MockStrict
  Hashtable<String, SoapConnectorPool> _connectorPoolMock;

  /**
   * Mock {@link SoapConnectorPool}
   */
  @MockStrict
  SoapConnectorPool _soapConnectorPoolMock;

  /**
   * Mock {@link SoapInstance}
   */
  @MockStrict
  SoapInstance _soapInstanceMock;

  /**
   * Mock {@link Client}
   */
  @MockStrict
  Client _soapInstanceMockClient;

  /**
   *
   * @throws Exception
   *           exception
   */
  @Test
  public void AcsNbi1ConnectorTest_addService_001() throws Exception
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    CpeIdentifier cpeIdentifier = new CpeIdentifier();
    ArrayOfNamedValue arrayOfNamedValue = new ArrayOfNamedValue();
    EventSink eventSink = new EventSink();
    Object[] responseClient = { null };

    AcsNbi1ConnectorTest_prepare();
    cpeIdentifier.setSerialNumber(SERIAL_NUMBER);

    EasyMock.expect(_soapInstanceMockClient.invoke(EasyMock.eq("AddService"), EasyMock.eq(cpeIdentifier), EasyMock.eq(arrayOfNamedValue), EasyMock.eq(eventSink))) //
        .andReturn(responseClient);

    PowerMock.replayAll();
    final ConnectorResponse<Nothing, Nothing> response = _connector.addService(tracabilite, cpeIdentifier, arrayOfNamedValue, eventSink);
    PowerMock.verifyAll();

    Assert.assertNotNull(response);
  }

  /**
   *
   * @throws Exception
   *           exception
   */
  @Test
  public void AcsNbi1ConnectorTest_createCpe_001() throws Exception
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    CpeProperties cpeProperties = new CpeProperties();
    EventSink eventSink = new EventSink();
    Object[] responseClient = { null };

    AcsNbi1ConnectorTest_prepare();
    cpeProperties.setCpeName("CreateCPE");
    cpeProperties.setSerialNumber(SERIAL_NUMBER);
    cpeProperties.setUserId(USER_ID);

    EasyMock.expect(_soapInstanceMockClient.invoke(EasyMock.eq("CreateCPE"), EasyMock.eq(cpeProperties), EasyMock.eq(eventSink))).andReturn(responseClient);

    PowerMock.replayAll();
    final ConnectorResponse<Nothing, Nothing> response = _connector.createCpe(tracabilite, cpeProperties, eventSink);
    PowerMock.verifyAll();

    Assert.assertNotNull(response);
  }

  /**
   *
   * @throws Exception
   *           exception
   */
  @Test
  public void AcsNbi1ConnectorTest_deleteCpe_001() throws Exception
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    CpeIdentifier cpeIdentifier = _podam.manufacturePojoWithFullData(CpeIdentifier.class);
    Object[] responseClient = { null };

    AcsNbi1ConnectorTest_prepare();
    EasyMock.expect(_soapInstanceMockClient.invoke(EasyMock.eq("DeleteCPE"), EasyMock.eq(cpeIdentifier))).andReturn(responseClient);
    PowerMock.replayAll();

    final ConnectorResponse<Nothing, Nothing> response = _connector.deleteCpe(tracabilite, cpeIdentifier);
    PowerMock.verifyAll();

    Assert.assertNotNull(response);
  }

  /**
   * Nominal case ListService
   *
   * @throws Exception
   */
  @Test
  public void AcsNbi1ConnectorTest_ListService_0K_001() throws Exception
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    ArrayOfServiceInfoStruct arrayService = _podam.manufacturePojoWithFullData(ArrayOfServiceInfoStruct.class);
    CpeIdentifier cpidentifier = _podam.manufacturePojoWithFullData(CpeIdentifier.class);
    ArrayOfXsdString arrayofString = _podam.manufacturePojoWithFullData(ArrayOfXsdString.class);
    Object[] responseClient = { arrayService };
    String detailService = "detailService"; //$NON-NLS-1$
    initializeMocksForSendRequest();
    EasyMock.expect(_loadBalancerMock.getPingConnectionTimeout()).andReturn(0);
    EasyMock.expect(_urlBalancedElementMock.validConnection(EasyMock.anyInt())).andReturn(Element.ElementState.OK);

    EasyMock.expect(_soapInstanceMockClient.invoke(EasyMock.eq("ListService"), EasyMock.eq(cpidentifier), EasyMock.eq(arrayofString), EasyMock.eq(detailService))).andReturn(responseClient); //$NON-NLS-1$

    PowerMock.replayAll();
    final ConnectorResponse<ArrayOfServiceInfoStruct, Nothing> response = _connector.getListService(tracabilite, cpidentifier, arrayofString, detailService);

    PowerMock.verifyAll();

    Assert.assertNotNull(response);
    Assert.assertNotNull(response._first);
    Assert.assertEquals(response._first, arrayService);

  }

  /**
   * throw exception when invoking WS
   *
   * @throws Exception
   */
  @Test
  public void AcsNbi1ConnectorTest_ListService_KO_001() throws Exception
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    ArrayOfServiceInfoStruct arrayService = _podam.manufacturePojoWithFullData(ArrayOfServiceInfoStruct.class);
    CpeIdentifier cpidentifier = _podam.manufacturePojoWithFullData(CpeIdentifier.class);
    ArrayOfXsdString arrayofString = _podam.manufacturePojoWithFullData(ArrayOfXsdString.class);
    Object[] responseClient = { arrayService };
    String detailService = "detailService"; //$NON-NLS-1$
    initializeMocksForSendRequest();
    EasyMock.expect(_loadBalancerMock.getPingConnectionTimeout()).andReturn(0);
    EasyMock.expect(_urlBalancedElementMock.validConnection(EasyMock.anyInt())).andReturn(Element.ElementState.OK);

    EasyMock.expect(_soapInstanceMockClient.invoke(EasyMock.eq("ListService"), EasyMock.eq(cpidentifier), EasyMock.eq(arrayofString), EasyMock.eq(detailService))).andThrow(new Exception()); //$NON-NLS-1$

    try
    {
      PowerMock.replayAll();
      final ConnectorResponse<ArrayOfServiceInfoStruct, Nothing> response = _connector.getListService(tracabilite, cpidentifier, arrayofString, detailService);

      PowerMock.verifyAll();
    }
    catch (RavelException exception)
    {
      Assert.assertTrue(exception instanceof RavelException);
    }

  }

  /**
   *
   * @throws Exception
   *           exception
   */
  @Test
  public void AcsNbi1ConnectorTest_modifyService_001() throws Exception
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    CpeIdentifier cpeIdentifier = _podam.manufacturePojoWithFullData(CpeIdentifier.class);
    ArrayOfNamedValue arrayOfNamedValue = new ArrayOfNamedValue();
    Object[] responseClient = { null };

    AcsNbi1ConnectorTest_prepare();
    EasyMock.expect(_soapInstanceMockClient.invoke(EasyMock.eq("ModifyService"), EasyMock.eq(cpeIdentifier), EasyMock.eq(arrayOfNamedValue))) //
        .andReturn(responseClient);
    PowerMock.replayAll();

    final ConnectorResponse<Nothing, Nothing> response = _connector.modifyService(tracabilite, cpeIdentifier, arrayOfNamedValue);
    PowerMock.verifyAll();

    Assert.assertNotNull(response);
  }

  /**
   * Nominal case ListService
   *
   * @throws Exception
   */
  @Test
  public void AcsNbi1ConnectorTest_reboot_0K_001() throws Exception
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    CpeIdentifier cpidentifier = _podam.manufacturePojoWithFullData(CpeIdentifier.class);
    Object[] responseClient = { null };
    initializeMocksForSendRequest();
    EasyMock.expect(_loadBalancerMock.getPingConnectionTimeout()).andReturn(0);
    EasyMock.expect(_urlBalancedElementMock.validConnection(EasyMock.anyInt())).andReturn(Element.ElementState.OK);

    EasyMock.expect(_soapInstanceMockClient.invoke(EasyMock.eq("Reboot"), EasyMock.eq(cpidentifier))).andReturn(responseClient); //$NON-NLS-1$

    PowerMock.replayAll();
    final ConnectorResponse<Nothing, Nothing> response = _connector.reboot(tracabilite, cpidentifier);

    PowerMock.verifyAll();

    Assert.assertNotNull(response);

  }

  /**
   *
   * @throws Exception
   *           exception
   */
  @Test
  public void AcsNbi1ConnectorTest_removeService_001() throws Exception
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    CpeIdentifier cpeIdentifier = _podam.manufacturePojoWithFullData(CpeIdentifier.class);
    ArrayOfNamedValue arrayOfNamedValue = new ArrayOfNamedValue();
    Object[] responseClient = { null };

    AcsNbi1ConnectorTest_prepare();
    EasyMock.expect(_soapInstanceMockClient.invoke(EasyMock.eq("RemoveService"), EasyMock.eq(cpeIdentifier), EasyMock.eq(arrayOfNamedValue))) //
        .andReturn(responseClient);
    PowerMock.replayAll();

    final ConnectorResponse<Nothing, Nothing> response = _connector.removeService(tracabilite, cpeIdentifier, arrayOfNamedValue);
    PowerMock.verifyAll();

    Assert.assertNotNull(response);
  }

  /**
   *
   * @throws Exception
   *           exception
   */
  @Test
  public void AcsNbi1ConnectorTest_syncService_001() throws Exception
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    CpeIdentifier cpeIdentifier = _podam.manufacturePojoWithFullData(CpeIdentifier.class);
    Object[] responseClient = { null };

    AcsNbi1ConnectorTest_prepare();
    EasyMock.expect(_soapInstanceMockClient.invoke(EasyMock.eq("SyncService"), EasyMock.eq(cpeIdentifier))).andReturn(responseClient);
    PowerMock.replayAll();

    final ConnectorResponse<Nothing, Nothing> response = _connector.syncService(tracabilite, cpeIdentifier);
    PowerMock.verifyAll();

    Assert.assertNotNull(response);
  }

  /**
   * Initialize before tests
   *
   * @throws Exception
   *           Thrown in case of error during switch in attributes of parent class
   */
  @Before
  public void beforeTest() throws Exception
  {
    _podam.getStrategy().setMemoization(true);
    _podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());

    _connector = new AcsNbi1Connector();
  }

  /**
   *
   * @throws Exception
   *           exception
   */
  private void AcsNbi1ConnectorTest_prepare() throws Exception
  {
    loadAcsServicesServiceConnector("NBBSNorthboundAPI_01"); //$NON-NLS-1$
    initializeMocksForSendRequest();
    EasyMock.expect(_loadBalancerMock.getPingConnectionTimeout()).andReturn(0);
    EasyMock.expect(_urlBalancedElementMock.validConnection(EasyMock.anyInt())).andReturn(Element.ElementState.OK);
  }

  /**
   * Génération du LoadBalancer minimal pour passer {@link AbstractSOAPConnector#loadConnectorConfiguration(Connector)}
   *
   * @return {@link LoadBalancer}
   */
  private LoadBalancer generateLoadBalancer()
  {
    final LoadBalancer loadBalancer = new LoadBalancer();
    Param timer = new Param();
    timer.setName("TIMER"); //$NON-NLS-1$
    timer.setValue("30"); //$NON-NLS-1$
    loadBalancer.getParam().add(timer);
    loadBalancer.setType("RoundRobin"); //$NON-NLS-1$
    return loadBalancer;
  }

  /**
   * Génération du URL minimal pour passer {@link AbstractSOAPConnector#loadConnectorConfiguration(Connector)}
   *
   * @return {@link URL}
   */
  private URL generateURL()
  {
    final URL url = new URL();
    url.setName("urlName"); //$NON-NLS-1$
    url.setAccessPoint("http://localhost:8888"); //$NON-NLS-1$

    Param param = new Param();
    param.setName("PROXY_ENABLED"); //$NON-NLS-1$
    param.setValue(String.valueOf(false));
    url.getParam().add(param);

    param = new Param();
    param.setName("TIMEOUT"); //$NON-NLS-1$
    param.setValue("30"); //$NON-NLS-1$
    url.getParam().add(param);

    param = new Param();
    param.setName("BASIC_AUTHENT"); //$NON-NLS-1$
    param.setValue(String.valueOf(false));
    url.getParam().add(param);

    param = new Param();
    param.setName("CONNECTION_TIMEOUT"); //$NON-NLS-1$
    param.setValue("30"); //$NON-NLS-1$
    url.getParam().add(param);

    param = new Param();
    param.setName("RECEIVE_TIMEOUT"); //$NON-NLS-1$
    param.setValue("30"); //$NON-NLS-1$
    url.getParam().add(param);

    return url;
  }

  /**
   * @return URLS
   */
  private URLS generateURLS()
  {
    final URLS urls = new URLS();
    urls.setLoadBalancer(generateLoadBalancer());
    urls.getURL().add(generateURL());
    return urls;
  }

  /**
   * prepare mock scenario to initialize method sendRequest from AbstractSoapConnector
   *
   * @throws Exception
   *           Thrown in case of error
   */
  private void initializeMocksForSendRequest() throws Exception
  {
    final String urlBalancedElementName = org.apache.commons.lang3.RandomStringUtils.randomAlphanumeric(45);
    final String urlBalancedElementDescription = org.apache.commons.lang3.RandomStringUtils.randomAlphabetic(9);

    // Mock load balancer
    EasyMock.expect(_loadBalancerMock.chooseBalancedElement()).andReturn(_urlBalancedElementMock);
    EasyMock.expect(_urlBalancedElementMock.getName()).andReturn(urlBalancedElementName);
    EasyMock.expect(_urlBalancedElementMock.getDescription()).andReturn(urlBalancedElementDescription);
    EasyMock.expect(_urlBalancedElementMock.getName()).andReturn(urlBalancedElementName);
    EasyMock.expect(_connectorPoolMock.get(urlBalancedElementName)).andReturn(_soapConnectorPoolMock);
    EasyMock.expect(_soapConnectorPoolMock.borrowObject()).andReturn(_soapInstanceMock);
    EasyMock.expect(_soapInstanceMock.getClient()).andReturn(_soapInstanceMockClient);
    _soapConnectorPoolMock.returnObject(EasyMock.anyObject());
    EasyMock.expectLastCall();

    JUnitTools.setInaccessibleFieldValue(_connector, "_loadBalancer", _loadBalancerMock); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_connectorPool", _connectorPoolMock); //$NON-NLS-1$

    EasyMock.expect(_soapInstanceMockClient.getInInterceptors()).andReturn(new ArrayList<Interceptor<?>>());
    EasyMock.expect(_soapInstanceMockClient.getOutInterceptors()).andReturn(new ArrayList<Interceptor<?>>());
  }

  /**
   *
   * @param acsServicesServiceName
   * @throws Exception
   */
  private void loadAcsServicesServiceConnector(String acsServicesServiceName) throws Exception
  {
    final Connector connector = new Connector();
    connector.setName("AcsServicesConnector"); //$NON-NLS-1$
    Param param = new Param();
    param.setName("ACS_NBI_1_SERVICE_NAME"); //$NON-NLS-1$
    param.setValue(acsServicesServiceName);
    connector.getParam().add(param);
    connector.setURLS(generateURLS());

    PowerMock.expectNew(SoapConnectorPool.class, EasyMock.anyObject(Class.class), EasyMock.anyString(), EasyMock.anyInt(), EasyMock.anyInt(), EasyMock.anyInt(), EasyMock.anyBoolean(), EasyMock.anyString(), EasyMock.anyString(), EasyMock.anyBoolean(), EasyMock.anyString(), EasyMock.anyString(), EasyMock.anyString(), EasyMock.anyInt(), EasyMock.anyString(), EasyMock.anyObject(ValidationEventHandler.class), EasyMock.anyObject(ISoapInterceptorsFactory.class)).andReturn(_soapConnectorPoolMock);
    PowerMock.replay(SoapConnectorPool.class);

    // test
    _connector.loadConnectorConfiguration(connector);
  }
}
