package com.bytel.spirit.common.connectors.acs.nbi2;

import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.netopia.nbbs.Device;

import java.util.List;

/**
 *
 * @author csilva
 * @version ($Revision$ $Date$)
 */
public interface IAcsNbi2
{
  /**
   * Signature of the method getSubscriberDevices
   */
  public ConnectorResponse<List<Device>, Nothing> getSubscriberDevices(final Tracabilite tracabilite_p, String subscriberId_p) throws RavelException;
}
