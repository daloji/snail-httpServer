package com.bytel.spirit.common.connectors.acs.nbi1;

import com.bytel.ravel.services.connector.IConnector;

/**
 *
 * @author csilva
 * @version ($Revision$ $Date$)
 */
public interface IAcsNbi1Connector extends IConnector, IAcsNbi1
{

  /**
   * The id to retrieve the connector.
   */
  public static final String BEAN_ID_ACS_NBI_1 = "AcsNbi1Connector"; //$NON-NLS-1$

}
