package com.bytel.spirit.common.connectors.acs.nbi1;

import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.netopia.nbbs.webservice.ArrayOfNamedValue;
import com.netopia.nbbs.webservice.ArrayOfServiceInfoStruct;
import com.netopia.nbbs.webservice.ArrayOfXsdString;
import com.netopia.nbbs.webservice.CpeIdentifier;
import com.netopia.nbbs.webservice.CpeProperties;
import com.netopia.nbbs.webservice.EventSink;

/**
 *
 * @author csilva
 * @version ($Revision$ $Date$)
 */
public interface IAcsNbi1
{
  /**
   * Requête AddService
   *
   * @param tracabilite_p
   *          Traçabilité
   * @param cpeIdentifier_p
   * @param arrayOfNamedValue_p
   * @param eventSink_p
   * @return
   */
  public ConnectorResponse<Nothing, Nothing> addService(final Tracabilite tracabilite_p, CpeIdentifier cpeIdentifier_p, ArrayOfNamedValue arrayOfNamedValue_p, EventSink eventSink_p) throws RavelException;

  /**
   * Requête CreateCPE
   *
   * @param tracabilite_p
   *          Traçabilité
   * @param cpeProperties_p
   * @param eventSink_p
   * @return
   */
  public ConnectorResponse<Nothing, Nothing> createCpe(final Tracabilite tracabilite_p, CpeProperties cpeProperties_p, EventSink eventSink_p) throws RavelException;

  /**
   * Requête DeleteCPE
   *
   * @param tracabilite_p
   *          Traçabilité
   * @param cpeIdentifier_p
   * @return
   */
  public ConnectorResponse<Nothing, Nothing> deleteCpe(final Tracabilite tracabilite_p, CpeIdentifier cpeIdentifier_p) throws RavelException;

  /**
   * Signature of the method getListService
   */
  public ConnectorResponse<ArrayOfServiceInfoStruct, Nothing> getListService(final Tracabilite tracabilite_p, CpeIdentifier cpeIdentifier_p, ArrayOfXsdString serviceIds, String detailLevel) throws RavelException;

  /**
   * Requête ModifyService
   *
   * @param tracabilite_p
   *          Traçabilité
   * @param cpeIdentifier_p
   * @param arrayOfNamedValue_p
   * @return
   */
  public ConnectorResponse<Nothing, Nothing> modifyService(final Tracabilite tracabilite_p, CpeIdentifier cpeIdentifier_p, ArrayOfNamedValue arrayOfNamedValue_p) throws RavelException;

  /**
   * Signature of the method reboot
   */
  public ConnectorResponse<Nothing, Nothing> reboot(final Tracabilite tracabilite_p, CpeIdentifier cpeIdentifier_p) throws RavelException;

  /**
   * Requête RemoveService
   *
   * @param tracabilite_p
   *          Traçabilité
   * @param cpeIdentifier_p
   * @param arrayOfNamedValue_p
   * @return
   */
  public ConnectorResponse<Nothing, Nothing> removeService(final Tracabilite tracabilite_p, CpeIdentifier cpeIdentifier_p, ArrayOfNamedValue arrayOfNamedValue_p) throws RavelException;

  /**
   * Requête SyncService
   *
   * @param tracabilite_p
   * @param cpeIdentifier_p
   * @return
   * @throws RavelException
   */
  public ConnectorResponse<Nothing, Nothing> syncService(final Tracabilite tracabilite_p, CpeIdentifier cpeIdentifier_p) throws RavelException;

}
