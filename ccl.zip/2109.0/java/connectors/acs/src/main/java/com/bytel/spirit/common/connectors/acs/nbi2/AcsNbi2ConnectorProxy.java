package com.bytel.spirit.common.connectors.acs.nbi2;

import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.probes.AvgDoubleCollectorItem;
import com.bytel.ravel.common.probes.AvgFlowPerSecondCollector;
import com.bytel.ravel.common.probes.RavelProbeConfigurationManager;
import com.bytel.ravel.services.connector.BaseProxy;
import com.bytel.ravel.services.connector.ConnectorExecution;
import com.bytel.ravel.services.connector.ConnectorManager;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.netopia.nbbs.Device;

import java.util.List;

/**
 *
 * @author csilva
 * @version ($Revision$ $Date$)
 */
public class AcsNbi2ConnectorProxy extends BaseProxy implements IAcsNbi2
{

  /**
   * AcsNbi2ConnectorProxy instance
   */
  private static final AcsNbi2ConnectorProxy _instance = new AcsNbi2ConnectorProxy();

  /**
   * Probe: measure the average number of getSubscriberDevices call per second.
   */
  AvgFlowPerSecondCollector _avg_getSubscriberDevices_call_counter;

  /**
   * Probe: measure the average execution time of the getSubscriberDevices operation.
   */
  AvgDoubleCollectorItem _avg_getSubscriberDevices_ExecTime;

  /**
   * 
   */
  public AcsNbi2ConnectorProxy()
  {
    _avg_getSubscriberDevices_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_getSubscriberDevices_per_second", "AcsNbi2ConnectorProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_getSubscriberDevices_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_getSubscriberDevices_ExecTime", "AcsNbi2ConnectorProxy"); //$NON-NLS-1$ //$NON-NLS-2$
  }

  /**
   * Get the proxy instance
   */
  public static AcsNbi2ConnectorProxy getInstance()
  {
    return _instance;
  }

  /**
   * Request to getSubscriberDevices
   */
  @Override
  public ConnectorResponse<List<Device>, Nothing> getSubscriberDevices(Tracabilite tracabilite_p, String subscriberId_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<List<Device>, Nothing>>(IAcsNbi2Connector.BEAN_ID_ACS_NBI_2)
    {

      @Override
      public ConnectorResponse<List<Device>, Nothing> run() throws RavelException
      {
        IAcsNbi2Connector acsConnector = (IAcsNbi2Connector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_getSubscriberDevices_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return acsConnector.getSubscriberDevices(tracabilite_p, subscriberId_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_getSubscriberDevices_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }
}
