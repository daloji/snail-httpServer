package com.bytel.spirit.common.connectors.acs.nbi1;

import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.probes.AvgDoubleCollectorItem;
import com.bytel.ravel.common.probes.AvgFlowPerSecondCollector;
import com.bytel.ravel.common.probes.RavelProbeConfigurationManager;
import com.bytel.ravel.services.connector.BaseProxy;
import com.bytel.ravel.services.connector.ConnectorExecution;
import com.bytel.ravel.services.connector.ConnectorManager;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.netopia.nbbs.webservice.ArrayOfNamedValue;
import com.netopia.nbbs.webservice.ArrayOfServiceInfoStruct;
import com.netopia.nbbs.webservice.ArrayOfXsdString;
import com.netopia.nbbs.webservice.CpeIdentifier;
import com.netopia.nbbs.webservice.CpeProperties;
import com.netopia.nbbs.webservice.EventSink;

/**
 *
 * @author csilva
 * @version ($Revision$ $Date$)
 */
public class AcsNbi1ConnectorProxy extends BaseProxy implements IAcsNbi1
{

  /**
   * AcsNbi1ConnectorProxy instance
   */
  private static final AcsNbi1ConnectorProxy _instance = new AcsNbi1ConnectorProxy();

  /**
   * Get the proxy instance
   */
  public static AcsNbi1ConnectorProxy getInstance()
  {
    return _instance;
  }

  /**
   * Probe: measure the average number of getListService call per second.
   */
  AvgFlowPerSecondCollector _avg_getListService_call_counter;

  /**
   * Probe: measure the average execution time of the getListService operation.
   */
  AvgDoubleCollectorItem _avg_getListService_ExecTime;

  /**
   * Probe: measure the average number of reboot call per second.
   */
  AvgFlowPerSecondCollector _avg_reboot_call_counter;

  /**
   * Probe: measure the average execution time of the reboot operation.
   */
  AvgDoubleCollectorItem _avg_reboot_ExecTime;

  /**
   *
   */
  public AcsNbi1ConnectorProxy()
  {
    _avg_getListService_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_getListService_per_second", "AcsNbi1ConnectorProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_getListService_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_getListService_ExecTime", "AcsNbi1ConnectorProxy"); //$NON-NLS-1$ //$NON-NLS-2$

    _avg_reboot_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_reboot_per_second", "AcsNbi1ConnectorProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_reboot_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_reboot_ExecTime", "AcsNbi1ConnectorProxy"); //$NON-NLS-1$ //$NON-NLS-2$
  }

  @Override
  public ConnectorResponse<Nothing, Nothing> addService(Tracabilite tracabilite_p, CpeIdentifier cpeIdentifier_p, ArrayOfNamedValue arrayOfNamedValue_p, EventSink eventSink_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Nothing, Nothing>>(IAcsNbi1Connector.BEAN_ID_ACS_NBI_1)
    {
      @Override
      public ConnectorResponse<Nothing, Nothing> run() throws RavelException
      {
        IAcsNbi1Connector acsConnector = (IAcsNbi1Connector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_reboot_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return acsConnector.addService(tracabilite_p, cpeIdentifier_p, arrayOfNamedValue_p, eventSink_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_reboot_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Nothing, Nothing> createCpe(Tracabilite tracabilite_p, CpeProperties cpeProperties_p, EventSink eventSink_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Nothing, Nothing>>(IAcsNbi1Connector.BEAN_ID_ACS_NBI_1)
    {
      @Override
      public ConnectorResponse<Nothing, Nothing> run() throws RavelException
      {
        IAcsNbi1Connector acsConnector = (IAcsNbi1Connector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_reboot_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return acsConnector.createCpe(tracabilite_p, cpeProperties_p, eventSink_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_reboot_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Nothing, Nothing> deleteCpe(Tracabilite tracabilite_p, CpeIdentifier cpeIdentifier_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Nothing, Nothing>>(IAcsNbi1Connector.BEAN_ID_ACS_NBI_1)
    {
      @Override
      public ConnectorResponse<Nothing, Nothing> run() throws RavelException
      {
        IAcsNbi1Connector acsConnector = (IAcsNbi1Connector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_reboot_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return acsConnector.deleteCpe(tracabilite_p, cpeIdentifier_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_reboot_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<ArrayOfServiceInfoStruct, Nothing> getListService(Tracabilite tracabilite_p, CpeIdentifier cpeIdentifier_p, ArrayOfXsdString serviceIds, String detailLevel) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<ArrayOfServiceInfoStruct, Nothing>>(IAcsNbi1Connector.BEAN_ID_ACS_NBI_1)
    {

      @Override
      public ConnectorResponse<ArrayOfServiceInfoStruct, Nothing> run() throws RavelException
      {
        IAcsNbi1Connector acsConnector = (IAcsNbi1Connector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_getListService_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return acsConnector.getListService(tracabilite_p, cpeIdentifier_p, serviceIds, detailLevel);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_getListService_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Nothing, Nothing> modifyService(Tracabilite tracabilite_p, CpeIdentifier cpeIdentifier_p, ArrayOfNamedValue arrayOfNamedValue_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Nothing, Nothing>>(IAcsNbi1Connector.BEAN_ID_ACS_NBI_1)
    {
      @Override
      public ConnectorResponse<Nothing, Nothing> run() throws RavelException
      {
        IAcsNbi1Connector acsConnector = (IAcsNbi1Connector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_reboot_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return acsConnector.modifyService(tracabilite_p, cpeIdentifier_p, arrayOfNamedValue_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_reboot_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Nothing, Nothing> reboot(Tracabilite tracabilite_p, CpeIdentifier cpeIdentifier_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Nothing, Nothing>>(IAcsNbi1Connector.BEAN_ID_ACS_NBI_1)
    {

      @Override
      public ConnectorResponse<Nothing, Nothing> run() throws RavelException
      {
        IAcsNbi1Connector acsConnector = (IAcsNbi1Connector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_reboot_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return acsConnector.reboot(tracabilite_p, cpeIdentifier_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_reboot_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Nothing, Nothing> removeService(Tracabilite tracabilite_p, CpeIdentifier cpeIdentifier_p, ArrayOfNamedValue arrayOfNamedValue_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Nothing, Nothing>>(IAcsNbi1Connector.BEAN_ID_ACS_NBI_1)
    {
      @Override
      public ConnectorResponse<Nothing, Nothing> run() throws RavelException
      {
        IAcsNbi1Connector acsConnector = (IAcsNbi1Connector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_reboot_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return acsConnector.removeService(tracabilite_p, cpeIdentifier_p, arrayOfNamedValue_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_reboot_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Nothing, Nothing> syncService(Tracabilite tracabilite_p, CpeIdentifier cpeIdentifier_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Nothing, Nothing>>(IAcsNbi1Connector.BEAN_ID_ACS_NBI_1)
    {
      @Override
      public ConnectorResponse<Nothing, Nothing> run() throws RavelException
      {
        IAcsNbi1Connector acsConnector = (IAcsNbi1Connector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_reboot_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return acsConnector.syncService(tracabilite_p, cpeIdentifier_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_reboot_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

}
