package com.bytel.spirit.common.connectors.acs.nbi2;

import com.bytel.ravel.services.connector.IConnector;

/**
 *
 * @author csilva
 * @version ($Revision$ $Date$)
 */
public interface IAcsNbi2Connector extends IConnector, IAcsNbi2
{

  /**
   * The id to retrieve the connector.
   */
  public static final String BEAN_ID_ACS_NBI_2 = "AcsNbi2Connector"; //$NON-NLS-1$

}
