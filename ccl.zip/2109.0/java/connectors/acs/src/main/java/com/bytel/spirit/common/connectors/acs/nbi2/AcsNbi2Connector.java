package com.bytel.spirit.common.connectors.acs.nbi2;

import com.bytel.ravel.common.conf.generated.Param;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.services.conf.connector.generated.Connector;
import com.bytel.spirit.common.shared.misc.connectors.AbstractSpiritSOAPConnector;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.netopia.nbbs.Device;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.netopia.nbbs.NbiService;
import com.netopia.nbbs.webservice.NBBSNorthboundAPI01;

import java.text.MessageFormat;
import java.util.List;

/**
 *
 * @author csilva
 * @version ($Revision$ $Date$)
 */
public class AcsNbi2Connector extends AbstractSpiritSOAPConnector implements IAcsNbi2Connector
{

  /**
   * Method to call
   */
  private static final String GET_SUBSCRIBER_DEVICES = "getSubscriberDevices";

  /**
   * Name for Acs service operation
   */
  private static final String ACS_NBI_2_SERVICE_NAME = "ACS_NBI_2_SERVICE_NAME"; //$NON-NLS-1$


  /**
   * The TechnicalException Message
   */
  private static final String TECHNICAL_EXCEPTION_MESSAGE = Messages.getString("AcsNbi2Connector.TechnicalExceptionMessage");

  /**
   * The constant for MissingConfigurationParameter
   */
  private static final String MESSAGE_MISSING_CONFIGURATION_PARAMETER = Messages.getString("AcsNbi2Connector.MissingParameter"); //$NON-NLS-1$

  /**
   * The constant for InvalidonfigurationParameter
   */
  private static final String MESSAGE_INVALID_CONFIGURATION_PARAMETER = Messages.getString("AcsNbi2Connector.InvalidParameter"); //$NON-NLS-1$

  /**
   * The URI
   */
  private static final String ACS_NBI_2_ACCESS_SERVICE = "NbiService"; //$NON-NLS-1$

  /**
   * The service name to call.
   */
  private String _serviceName;

  @Override
  public void loadConnectorConfiguration(Connector connector_p) throws RavelException
  {
    // Get and validate specific configuration parameters
    for (Param param : connector_p.getParam())
    {
      switch (param.getName())
      {
        case ACS_NBI_2_SERVICE_NAME:
          _serviceName = param.getValue();
          break;
        default:
          break;
      }
    }
    if (StringTools.isNullOrEmpty(_serviceName))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, ACS_NBI_2_SERVICE_NAME));
    }

    switch (_serviceName)
    {
      case ACS_NBI_2_ACCESS_SERVICE:
        super.setServiceInterfaceClass(NbiService.class);
        break;
      default:
        throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(MESSAGE_INVALID_CONFIGURATION_PARAMETER, _serviceName));
    }

    super.loadConnectorConfiguration(connector_p);
  }

  @Override
  public ConnectorResponse<List<Device>, Nothing> getSubscriberDevices(Tracabilite tracabilite_p, String subscriberId_p) throws RavelException
  {
    try
    {
      // Call SOAP Service
      List<Device> response = sendRequest(tracabilite_p, GET_SUBSCRIBER_DEVICES, subscriberId_p);
      return new ConnectorResponse<>(response, null);
    }
    catch (Exception e)
    {
      final String message = MessageFormat.format(TECHNICAL_EXCEPTION_MESSAGE, GET_SUBSCRIBER_DEVICES, e.getMessage());
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, message));

      throw new RavelException(ExceptionType.PFS_EXCEPTION, ErrorCode.CNCTOR_00010, message, e);
    }
  }

  @Override
  public String getConfigParameter(String connectorID_p, String paramName_p) throws RavelException
  {
    return null;
  }

}
