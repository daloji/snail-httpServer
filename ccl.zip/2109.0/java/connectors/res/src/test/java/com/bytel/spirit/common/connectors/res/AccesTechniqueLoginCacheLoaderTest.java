/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.res;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.easymock.EasyMock;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.util.CollectionUtils;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.cache.BasicCache;
import com.bytel.ravel.common.cache.ICacheLoader;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.services.connector.ConnectorManager;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.IActivityCaller;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.AccesTechnique;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 * @author jpais
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({ RESConnector.class, ConnectorManager.class })
public class AccesTechniqueLoginCacheLoaderTest
{
  /**
   * Bean generation factory
   */
  private final PodamFactory _podam = new PodamFactoryImpl();

  private String _login;

  /**
   * {@link IActivityCaller} mock
   */
  IActivityCaller _activityCallerMock;

  /**
   * {@link RESConnector} mock
   */
  @MockStrict
  RESConnector _resConnector;

  /**
   * {@link ConnectorManager} mock
   */
  @MockStrict
  ConnectorManager _connectorManager;

  /**
   * Tests if a list of AccesTechnique is well written in the cache
   *
   * <b>Inputs:</b>Valid inputs (a list containing one AccesTechnique)<br/>
   * <b>Expected:</b><br/>
   *
   * @throws RavelException
   *           Thrown in case of error
   */
  @Test
  public void AccesTechniqueLoginCacheLoader_LoadCacheKO_001() throws RavelException
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);

    EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManager);
    EasyMock.expect(_connectorManager.getConnector(IRESConnector.BEAN_ID)).andReturn(_resConnector);

    RavelException ravelExceptionExpected = new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.KO_00000, StringConstants.EMPTY_STRING);
    EasyMock.expect(_resConnector.loadAccesTechniqueLireTous(tracabilite)).andThrow(ravelExceptionExpected);

    // On enregistre le scénario des appels avant de lancer l'activité
    PowerMock.replayAll();
    // test de l'activité
    ICacheLoader cacheLoader = new AccesTechniqueLoginCacheLoader(tracabilite, Duration.ZERO, _login);

    @SuppressWarnings("unchecked")
    BasicCache<List<AccesTechnique>> cache = (BasicCache<List<AccesTechnique>>) cacheLoader.initializeCache();

    cacheLoader.loadCache(cache);

    // On demande à PowerMock de vérifier la stack d'appel en fonction du scénario
    PowerMock.verifyAll();
  }

  /**
   * Tests if a list of AccesTechnique is well written in the cache
   *
   * <b>Inputs:</b>Valid inputs (a list containing one accesTechnique)<br/>
   * <b>Expected:</b><br/>
   *
   * @throws RavelException
   *           Thrown in case of error
   */
  @Test
  public void AccesTechniqueLoginCacheLoader_LoadCacheOK_001() throws RavelException
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);

    _login = _podam.manufacturePojo(String.class);

    Set<String> listeLoginAutorise1 = new HashSet<>();
    listeLoginAutorise1.add(_login);
    listeLoginAutorise1.add(_podam.manufacturePojo(String.class));

    Set<String> listeLoginAutorise2 = new HashSet<>();
    listeLoginAutorise2.add(_podam.manufacturePojo(String.class));
    listeLoginAutorise2.add(_podam.manufacturePojo(String.class));
    listeLoginAutorise2.add(_podam.manufacturePojo(String.class));
    listeLoginAutorise2.add(_podam.manufacturePojo(String.class));
    listeLoginAutorise2.add(_podam.manufacturePojo(String.class));

    Set<String> listeLoginAutorise3 = new HashSet<>();
    listeLoginAutorise3.add(_login);
    listeLoginAutorise3.add(_podam.manufacturePojo(String.class));
    listeLoginAutorise3.add(_podam.manufacturePojo(String.class));

    List<AccesTechnique> listeAccesTechniqueExpected = new ArrayList<>();
    listeAccesTechniqueExpected.add(_podam.manufacturePojo(AccesTechnique.class));
    listeAccesTechniqueExpected.add(_podam.manufacturePojo(AccesTechnique.class));

    AccesTechnique accesTechnique = _podam.manufacturePojo(AccesTechnique.class);
    accesTechnique.setListeLoginAutorise(listeLoginAutorise1);
    listeAccesTechniqueExpected.add(accesTechnique);

    AccesTechnique accesTechnique2 = _podam.manufacturePojo(AccesTechnique.class);
    accesTechnique2.setListeLoginAutorise(listeLoginAutorise2);
    listeAccesTechniqueExpected.add(accesTechnique2);

    AccesTechnique accesTechnique3 = _podam.manufacturePojo(AccesTechnique.class);
    accesTechnique3.setListeLoginAutorise(listeLoginAutorise3);
    listeAccesTechniqueExpected.add(accesTechnique3);

    Retour expectedRetour = RetourFactory.createOkRetour();
    ConnectorResponse<Retour, List<AccesTechnique>> expectedResponse = new ConnectorResponse<>(expectedRetour, listeAccesTechniqueExpected);

    EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManager);
    EasyMock.expect(_connectorManager.getConnector(IRESConnector.BEAN_ID)).andReturn(_resConnector);
    EasyMock.expect(_resConnector.loadAccesTechniqueLireTous(tracabilite)).andReturn(expectedResponse);

    // On enregistre le scénario des appels avant de lancer l'activité
    PowerMock.replayAll();
    // test de l'activité
    ICacheLoader cacheLoader = new AccesTechniqueLoginCacheLoader(tracabilite, Duration.ZERO, _login);

    @SuppressWarnings("unchecked")
    BasicCache<List<AccesTechnique>> cache = (BasicCache<List<AccesTechnique>>) cacheLoader.initializeCache();

    cacheLoader.loadCache(cache);

    // On demande à PowerMock de vérifier la stack d'appel en fonction du scénario
    PowerMock.verifyAll();

    // Assertions
    Assert.assertNotNull(cache);
    Assert.assertEquals("acces_technique" + "_" + _login, cacheLoader.getCacheId()); //$NON-NLS-1$ //$NON-NLS-2$

    listeAccesTechniqueExpected = listeAccesTechniqueExpected.stream().filter(accesTechnique_p -> !CollectionUtils.isEmpty(accesTechnique_p.getListeLoginAutorise()) && accesTechnique_p.getListeLoginAutorise().contains(_login)).collect(Collectors.toList());

    Assert.assertEquals(listeAccesTechniqueExpected, cache.read(_login));
  }

  /**
   * Tests if the cache is valid when it is empty
   *
   * <b>Inputs:</b>A cache with an empty list of accesTechnique<br/>
   * <b>Expected:</b>Method validateCache returns false<br/>
   *
   * @throws RavelException
   *           Thrown in case of error
   */
  @Test
  public void AccesTechniqueLoginCacheLoader_ValidateCacheFalse_001() throws RavelException
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    List<AccesTechnique> listeAccesTechniqueExpected = new ArrayList<>();

    Retour expectedRetour = RetourFactory.createOkRetour();
    ConnectorResponse<Retour, List<AccesTechnique>> expectedResponse = new ConnectorResponse<>(expectedRetour, listeAccesTechniqueExpected);

    EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManager);
    EasyMock.expect(_connectorManager.getConnector(IRESConnector.BEAN_ID)).andReturn(_resConnector);
    EasyMock.expect(_resConnector.loadAccesTechniqueLireTous(tracabilite)).andReturn(expectedResponse);

    // On enregistre le scénario des appels avant de lancer l'activité
    PowerMock.replayAll();
    // test de l'activité
    ICacheLoader cacheLoader = new AccesTechniqueLoginCacheLoader(tracabilite, Duration.ZERO, _login);

    @SuppressWarnings("unchecked")
    BasicCache<List<AccesTechnique>> cache = (BasicCache<List<AccesTechnique>>) cacheLoader.initializeCache();

    cacheLoader.loadCache(cache);

    // On demande à PowerMock de vérifier la stack d'appel en fonction du scénario
    PowerMock.verifyAll();

    Assert.assertFalse(cacheLoader.validateCache(cache));
  }

  /**
   * Tests if the cache is valid when null
   *
   * <b>Inputs:</b>A cache with no list of accesTechnique<br/>
   * <b>Expected:</b>Method validateCache returns false<br/>
   *
   * @throws RavelException
   *           Thrown in case of error
   */
  @Test
  public void AccesTechniqueLoginCacheLoader_ValidateCacheFalse_002() throws RavelException
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);

    Retour expectedRetour = RetourFactory.createOkRetour();
    ConnectorResponse<Retour, List<AccesTechnique>> expectedResponse = new ConnectorResponse<>(expectedRetour, null);

    EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManager);
    EasyMock.expect(_connectorManager.getConnector(IRESConnector.BEAN_ID)).andReturn(_resConnector);
    EasyMock.expect(_resConnector.loadAccesTechniqueLireTous(tracabilite)).andReturn(expectedResponse);

    // On enregistre le scénario des appels avant de lancer l'activité
    PowerMock.replayAll();
    // test de l'activité
    ICacheLoader cacheLoader = new AccesTechniqueLoginCacheLoader(tracabilite, Duration.ZERO, _login);

    @SuppressWarnings("unchecked")
    BasicCache<List<AccesTechnique>> cache = (BasicCache<List<AccesTechnique>>) cacheLoader.initializeCache();

    cacheLoader.loadCache(cache);

    // On demande à PowerMock de vérifier la stack d'appel en fonction du scénario
    PowerMock.verifyAll();

    Assert.assertFalse(cacheLoader.validateCache(cache));
  }

  /**
   * Tests if the cache is valid when the duration of cache is not expired
   *
   * <b>Inputs:</b>A cache with 10 min of validity<br/>
   * <b>Expected:</b>Method validateCache returns true<br/>
   *
   * @throws RavelException
   *           Thrown in case of error
   */
  @Test
  public void AccesTechniqueLoginCacheLoader_ValidateCacheTrue_001() throws RavelException
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);

    _login = _podam.manufacturePojo(String.class);

    Set<String> listeLoginAutorise1 = new HashSet<>();
    listeLoginAutorise1.add(_login);
    listeLoginAutorise1.add(_podam.manufacturePojo(String.class));

    Set<String> listeLoginAutorise2 = new HashSet<>();
    listeLoginAutorise2.add(_podam.manufacturePojo(String.class));
    listeLoginAutorise2.add(_podam.manufacturePojo(String.class));
    listeLoginAutorise2.add(_podam.manufacturePojo(String.class));
    listeLoginAutorise2.add(_podam.manufacturePojo(String.class));
    listeLoginAutorise2.add(_podam.manufacturePojo(String.class));

    Set<String> listeLoginAutorise3 = new HashSet<>();
    listeLoginAutorise3.add(_login);
    listeLoginAutorise3.add(_podam.manufacturePojo(String.class));
    listeLoginAutorise3.add(_podam.manufacturePojo(String.class));

    List<AccesTechnique> listeAccesTechniqueExpected = new ArrayList<>();
    listeAccesTechniqueExpected.add(_podam.manufacturePojo(AccesTechnique.class));
    listeAccesTechniqueExpected.add(_podam.manufacturePojo(AccesTechnique.class));

    AccesTechnique accesTechnique = _podam.manufacturePojo(AccesTechnique.class);
    accesTechnique.setListeLoginAutorise(listeLoginAutorise1);
    listeAccesTechniqueExpected.add(accesTechnique);

    AccesTechnique accesTechnique2 = _podam.manufacturePojo(AccesTechnique.class);
    accesTechnique2.setListeLoginAutorise(listeLoginAutorise2);
    listeAccesTechniqueExpected.add(accesTechnique2);

    AccesTechnique accesTechnique3 = _podam.manufacturePojo(AccesTechnique.class);
    accesTechnique3.setListeLoginAutorise(listeLoginAutorise3);
    listeAccesTechniqueExpected.add(accesTechnique3);

    Retour expectedRetour = RetourFactory.createOkRetour();
    ConnectorResponse<Retour, List<AccesTechnique>> expectedResponse = new ConnectorResponse<>(expectedRetour, listeAccesTechniqueExpected);

    EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManager);
    EasyMock.expect(_connectorManager.getConnector(IRESConnector.BEAN_ID)).andReturn(_resConnector);
    EasyMock.expect(_resConnector.loadAccesTechniqueLireTous(tracabilite)).andReturn(expectedResponse);

    // On enregistre le scénario des appels avant de lancer l'activité
    PowerMock.replayAll();
    // test de l'activité
    ICacheLoader cacheLoader = new AccesTechniqueLoginCacheLoader(tracabilite, Duration.parse("PT10M"), _login); //$NON-NLS-1$

    @SuppressWarnings("unchecked")
    BasicCache<List<AccesTechnique>> cache = (BasicCache<List<AccesTechnique>>) cacheLoader.initializeCache();

    cacheLoader.loadCache(cache);

    // On demande à PowerMock de vérifier la stack d'appel en fonction du scénario
    PowerMock.verifyAll();

    Assert.assertTrue(cacheLoader.validateCache(cache));
  }

  /**
   * Tests if the cache is valid when the duration of cache is not expired
   *
   * <b>Inputs:</b>A cache with 10 min of validity<br/>
   * <b>Expected:</b>Method validateCache returns true<br/>
   *
   * @throws RavelException
   *           Thrown in case of error
   */
  @Test
  public void AccesTechniqueLoginCacheLoader_ValidateCacheTrue_002() throws RavelException
  {
    _login = _podam.manufacturePojo(String.class);

    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    List<AccesTechnique> listeAccesTechniqueExpected = Collections.singletonList(_podam.manufacturePojo(AccesTechnique.class));

    Retour expectedRetour = RetourFactory.createOkRetour();
    ConnectorResponse<Retour, List<AccesTechnique>> expectedResponse = new ConnectorResponse<>(expectedRetour, listeAccesTechniqueExpected);

    EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManager);
    EasyMock.expect(_connectorManager.getConnector(IRESConnector.BEAN_ID)).andReturn(_resConnector);
    EasyMock.expect(_resConnector.loadAccesTechniqueLireTous(tracabilite)).andReturn(expectedResponse);

    // On enregistre le scénario des appels avant de lancer l'activité
    PowerMock.replayAll();
    // test de l'activité
    ICacheLoader cacheLoader = new AccesTechniqueLoginCacheLoader(tracabilite, Duration.ZERO, _login);

    @SuppressWarnings("unchecked")
    BasicCache<List<AccesTechnique>> cache = (BasicCache<List<AccesTechnique>>) cacheLoader.initializeCache();

    cacheLoader.loadCache(cache);

    // On demande à PowerMock de vérifier la stack d'appel en fonction du scénario
    PowerMock.verifyAll();

    Assert.assertFalse(cacheLoader.validateCache(cache));
  }

  /**
   * Test initialization
   */
  @Before
  public void beforeTest()
  {
    // désactivation du cache podam
    _podam.getStrategy().setMemoization(false);

    PowerMock.resetAll();
    PowerMock.mockStaticStrict(RESConnector.class);
    PowerMock.mockStaticStrict(ConnectorManager.class);
  }
}
