/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.res.services;

import java.io.ByteArrayInputStream;
import java.time.LocalDateTime;
import java.util.Hashtable;
import java.util.Map;

import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.cxf.jaxrs.impl.ResponseBuilderImpl;
import org.easymock.Capture;
import org.easymock.EasyMock;
import org.easymock.EasyMockSupport;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.modules.junit4.PowerMockRunner;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.datetime.DateTimeManager;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.json.format.impl.IsoShortOffsetDateTimeWithMillis;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.test.JUnitTools;
import com.bytel.ravel.common.test.podam.JavaTimeManufacturer;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.utils.RetourFactoryForTU;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.net.loadbalancing.ILoadBalancer;
import com.bytel.ravel.net.loadbalancing.URLBalancedElement;
import com.bytel.ravel.net.rest.RestConnectorPool;
import com.bytel.ravel.net.rest.RestInstance;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.connectors.res.RESConnector;
import com.bytel.spirit.common.shared.functional.types.json.RavelJsonTools;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.BasicResponse;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.ressources.RetourConverter;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.Ressource;
import com.bytel.spirit.common.shared.saab.res.RessourceRaccordement;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author icarrao
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
public class RessourceRaccordementServiceTest extends EasyMockSupport
{

  /**
  *
  */
  private static final String PARAM_ID_RESSOURCE = "idRessource"; //$NON-NLS-1$

  /**
  *
  */
  private static final String DATE_DERNIERE_DECLARATION_ONT_INSTALLE = "dateDerniereDeclarationOntInstalle"; //$NON-NLS-1$

  /**
  *
  */
  private static final String NO_SERIE_ONT_INSTALLE = "noSerieOntInstalle"; //$NON-NLS-1$

  /**
  *
  */
  private static final String TYPE_TECHNOLOGIE_PON = "typeTechnologiePon"; //$NON-NLS-1$

  /**
  *
  */
  private static final String PARAM_ID_ST = "idSt"; //$NON-NLS-1$

  /**
   *
   */
  private static final String PARAM_STATUT = "statut"; //$NON-NLS-1$

  /**
   * Check the query params in rest send request method
   *
   * @param queryParams
   *          the actual query params
   * @param expected_p
   *          list of expected query params strings key1 value1 key2 value2...keyN valueN
   */
  public static void checkQueryParams(Capture<Map<String, String>> queryParams, String... expected_p)
  {
    if (expected_p == null)
    {
      Assert.assertNull(queryParams.getValue());
    }
    else
    {
      Assert.assertEquals(0, expected_p.length % 2);
      for (int i = 0; i < expected_p.length; i = i + 2)
      {
        Assert.assertEquals(expected_p[i + 1], queryParams.getValue().get(expected_p[i]));
      }
    }
  }

  /**
   * Factory to generate beans
   */
  private final PodamFactory _podam = new PodamFactoryImpl();

  /**
   * Mock {@link RestConnectorPool}
   */
  @MockStrict
  RestConnectorPool _restConnectorPoolMock;

  /**
   * Mock {@link RestInstance}
   */
  @MockStrict
  RestInstance _restInstanceMock;

  private Tracabilite _tracabilite;

  /**
   * Connector to test
   */
  private RESConnector _connector;

  /**
   * Mock {@link ILoadBalancer}
   */
  @MockStrict
  ILoadBalancer<URLBalancedElement> _loadBalancerMock;

  /**
   * Mock {@link URLBalancedElement}
   */
  @MockStrict
  URLBalancedElement _urlBalancedElementMock;

  /**
   * Mock of connectors pool HTTP
   */
  @MockStrict
  Hashtable<String, RestConnectorPool> _connectorPoolMock;

  /**
   * Initialize before tests
   *
   * @throws Exception
   *           Thrown in case of error during switch in attributes of parent class
   */
  @Before
  public void beforeTest() throws Exception
  {
    _podam.getStrategy().setMemoization(false);
    _podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());
    JavaTimeManufacturer.registerPodamFactory(_podam);

    _connector = new RESConnector();

    _tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    JUnitTools.setInaccessibleFieldValue(_connector, "_loadBalancer", _loadBalancerMock); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_connectorPool", _connectorPoolMock); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_ressourceRaccordementUrl", "/ressourcePortPm/"); //$NON-NLS-1$ //$NON-NLS-2$
    JUnitTools.setInaccessibleFieldValue(_connector, "_ressourceRaccordementService", new RessourceRaccordementService(_connector)); //$NON-NLS-1$
  }

  /**
   * Test KO for the method {@link RESConnector#ressourceRaccordementCreer(Tracabilite, Ressource)} httpStatus 200, with
   * retourKO
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testRessourceRaccordementCreer_KO_001() throws Exception
  {

    final RessourceRaccordement ressourceRaccordement = _podam.manufacturePojo(RessourceRaccordement.class);
    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT1, IMegSpiritConsts.DONNEE_INDISPONIBLE, StringConstants.EMPTY_STRING, null);
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(basicResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();

    // construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq("/ressourcePortPm/"), EasyMock.capture(headersCapture), EasyMock.eq(RavelJsonTools.getInstance().toJson(ressourceRaccordement, RessourceRaccordement.class)), EasyMock.isNull())).andReturn(response); //$NON-NLS-1$
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.ressourceRaccordementCreer(_tracabilite, ressourceRaccordement);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test KO for the method {@link RESConnector#ressourceRaccordementCreer(Tracabilite, Ressource)} httpStatus 200,
   * jsonResponse null (throws RavelException)
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testRessourceRaccordementCreer_KO_002() throws Exception
  {

    final RessourceRaccordement ressourceRaccordement = _podam.manufacturePojo(RessourceRaccordement.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();

    // construct response
    final Response response = new ResponseBuilderImpl().status(200).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq("/ressourcePortPm/"), EasyMock.capture(headersCapture), EasyMock.eq(RavelJsonTools.getInstance().toJson(ressourceRaccordement, RessourceRaccordement.class)), EasyMock.isNull())).andReturn(response); //$NON-NLS-1$
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    ConnectorResponse<Retour, Nothing> result = null;

    PowerMock.replayAll();
    result = _connector.ressourceRaccordementCreer(_tracabilite, ressourceRaccordement);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, "Impossible de récupérer la réponse", null); //$NON-NLS-1$
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test KO for the method {@link RESConnector#ressourceRaccordementCreer(Tracabilite, Ressource)} httpStatus 500,
   * jsonResponse null (throws RavelException)
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testRessourceRaccordementCreer_KO_003() throws Exception
  {

    final RessourceRaccordement ressourceRaccordement = _podam.manufacturePojo(RessourceRaccordement.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();

    // construct response
    final Response response = new ResponseBuilderImpl().status(500).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq("/ressourcePortPm/"), EasyMock.capture(headersCapture), EasyMock.eq(RavelJsonTools.getInstance().toJson(ressourceRaccordement, RessourceRaccordement.class)), EasyMock.isNull())).andReturn(response); //$NON-NLS-1$
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    ConnectorResponse<Retour, Nothing> result = null;

    PowerMock.replayAll();
    result = _connector.ressourceRaccordementCreer(_tracabilite, ressourceRaccordement);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, "Impossible de récupérer la réponse", null); //$NON-NLS-1$
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test KO for the method
   * {@link RESConnector#ressourceRaccordementModifierCodeAccesTechnique(Tracabilite, String, String)}
   *
   * Expected : Retour KO, CAT-4, DONNEE_INCONNUE, "ressourceCompteMail xxx inconnue"
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testRessourceRaccordementModifierCodeAccesTechnique_KO_001() throws Exception
  {
    final String idRessource = RandomStringUtils.randomAlphabetic(5);
    final String codeAccesTechnique = "codeAccesTechnique"; //$NON-NLS-1$

    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "ressourceRaccordement " + idRessource + " inconnue", null); //$NON-NLS-1$ //$NON-NLS-2$
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = RavelJsonTools.getInstance().toJson(basicResponse, BasicResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq("/ressourcePortPm/"), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response); //$NON-NLS-1$
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.ressourceRaccordementModifierCodeAccesTechnique(_tracabilite, idRessource, codeAccesTechnique);

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, PARAM_ID_RESSOURCE, idRessource);

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test OK for the method
   * {@link RESConnector#ressourceRaccordementModifierCodeAccesTechnique(Tracabilite, String, String)} httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testRessourceRaccordementModifierCodeAccesTechnique_OK_001() throws Exception
  {
    final String idRessource = RandomStringUtils.randomAlphabetic(5);
    final String codeAccesTechnique = "codeAccesTechnique"; //$NON-NLS-1$

    final Retour retour = RetourFactoryForTU.createOkRetour();
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = RavelJsonTools.getInstance().toJson(basicResponse, BasicResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq("/ressourcePortPm/"), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response); //$NON-NLS-1$
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.ressourceRaccordementModifierCodeAccesTechnique(_tracabilite, idRessource, codeAccesTechnique);

    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, PARAM_ID_RESSOURCE, idRessource);

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test KO for the method
   * {@link RESConnector#RessourceRaccordementModifierOntInstalle(Tracabilite, String, Date, String, String)}
   *
   * Expected : Retour KO, CAT-4, DONNEE_INCONNUE, "ressourceCompteMail xxx inconnue"
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testRessourceRaccordementModifierOntInstalle_KO_001() throws Exception
  {
    LocalDateTime date = DateTimeManager.getInstance().now();

    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "ressourceRaccordement " + "idRessource" + " inconnue", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = RavelJsonTools.getInstance().toJson(basicResponse, BasicResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq("/ressourcePortPm/"), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response); //$NON-NLS-1$
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.ressourceRaccordementModifierOntInstalle(_tracabilite, "idRessource", date, "PON", "5576"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, PARAM_ID_RESSOURCE, "idRessource"); //$NON-NLS-1$
    IsoShortOffsetDateTimeWithMillis isoShortOffsetDateTimeWithMillis = new IsoShortOffsetDateTimeWithMillis();
    checkQueryParams(queryParamsCapture, DATE_DERNIERE_DECLARATION_ONT_INSTALLE, isoShortOffsetDateTimeWithMillis.format(date));
    checkQueryParams(queryParamsCapture, NO_SERIE_ONT_INSTALLE, "5576"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, TYPE_TECHNOLOGIE_PON, "PON"); //$NON-NLS-1$

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test OK for the method
   * {@link RESConnector#ressourceRaccordementModifierOntInstalle(Tracabilite, String, Date, String, String)} httpStatus
   * 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testRessourceRaccordementModifierOntInstalle_OK_001() throws Exception
  {

    LocalDateTime date = DateTimeManager.getInstance().now();

    final Retour retour = RetourFactoryForTU.createOkRetour();
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(basicResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq("/ressourcePortPm/"), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response); //$NON-NLS-1$
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.ressourceRaccordementModifierOntInstalle(_tracabilite, "idRessource", date, "PON", "5576"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, PARAM_ID_RESSOURCE, "idRessource"); //$NON-NLS-1$
    IsoShortOffsetDateTimeWithMillis isoShortOffsetDateTimeWithMillis = new IsoShortOffsetDateTimeWithMillis();
    checkQueryParams(queryParamsCapture, DATE_DERNIERE_DECLARATION_ONT_INSTALLE, isoShortOffsetDateTimeWithMillis.format(date));
    checkQueryParams(queryParamsCapture, NO_SERIE_ONT_INSTALLE, "5576"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, TYPE_TECHNOLOGIE_PON, "PON"); //$NON-NLS-1$

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test KO for the method
   * {@link RESConnector#ressourceRaccordementModifierStatutAllocation(Tracabilite, String, String, String)}
   *
   * Expected : Retour KO, CAT-4, DONNEE_INCONNUE, "ressourceCompteMail xxx inconnue"
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testRessourceRaccordementModifierStatutAllocation_KO_001() throws Exception
  {

    final String idRessource = RandomStringUtils.randomAlphabetic(5);
    final String idSt = RandomStringUtils.randomAlphabetic(5);
    final String statut = "TRAITEE"; //$NON-NLS-1$

    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "ressourceCompteMail " + idRessource + " inconnue", null); //$NON-NLS-1$ //$NON-NLS-2$
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(basicResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq("/ressourcePortPm/"), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response); //$NON-NLS-1$
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.ressourceRaccordementModifierStatutAllocation(_tracabilite, idRessource, idSt, statut);

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, PARAM_ID_RESSOURCE, idRessource);
    checkQueryParams(queryParamsCapture, PARAM_ID_ST, idSt);
    checkQueryParams(queryParamsCapture, PARAM_STATUT, statut);

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test OK for the method
   * {@link RESConnector#ressourceRaccordementModifierStatutAllocation(Tracabilite, String, String, String)} httpStatus
   * 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testRessourceRaccordementModifierStatutAllocation_OK_001() throws Exception
  {

    final String idRessource = RandomStringUtils.randomAlphabetic(5);
    final String idSt = RandomStringUtils.randomAlphabetic(5);
    final String statut = "TRAITEE"; //$NON-NLS-1$

    final Retour retour = RetourFactoryForTU.createOkRetour();
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(basicResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq("/ressourcePortPm/"), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response); //$NON-NLS-1$
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.ressourceRaccordementModifierStatutAllocation(_tracabilite, idRessource, idSt, statut);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, PARAM_ID_RESSOURCE, idRessource);
    checkQueryParams(queryParamsCapture, PARAM_ID_ST, idSt);
    checkQueryParams(queryParamsCapture, PARAM_STATUT, statut);

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * prepare mock scenario to initialize method sendRequest from AbstractRestConnector
   *
   * @throws Exception
   *           Thrown in case of error
   */
  private void initializeMocksForSendRequest() throws Exception
  {
    final String urlBalancedElementName = RandomStringUtils.randomAlphanumeric(45);
    final String urlBalancedElementDescription = RandomStringUtils.randomAlphabetic(9);

    EasyMock.expect(_loadBalancerMock.chooseBalancedElement()).andReturn(_urlBalancedElementMock);
    EasyMock.expect(_urlBalancedElementMock.getName()).andReturn(urlBalancedElementName);
    EasyMock.expect(_urlBalancedElementMock.getDescription()).andReturn(urlBalancedElementDescription);
    EasyMock.expect(_urlBalancedElementMock.getName()).andReturn(urlBalancedElementName);
    EasyMock.expect(_connectorPoolMock.get(urlBalancedElementName)).andReturn(_restConnectorPoolMock);
    EasyMock.expect(_restConnectorPoolMock.borrowObject()).andReturn(_restInstanceMock);
  }

}
