/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.res;

import java.io.ByteArrayInputStream;
import java.util.Collections;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

import javax.ws.rs.core.MultivaluedHashMap;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;

import org.apache.cxf.jaxrs.impl.ResponseBuilderImpl;
import org.easymock.Capture;
import org.easymock.EasyMock;
import org.easymock.EasyMockSupport;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.modules.junit4.PowerMockRunner;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.conf.generated.Param;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.test.JUnitTools;
import com.bytel.ravel.common.utils.RetourFactoryForTU;
import com.bytel.ravel.net.rest.RestConnectorPool;
import com.bytel.ravel.net.rest.RestInstance;
import com.bytel.ravel.services.conf.connector.generated.Connector;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.shared.functional.types.json.RavelJsonTools;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.BasicResponse;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.ressources.RetourConverter;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.PoolIP;
import com.bytel.spirit.common.shared.saab.res.request.ManagePoolIPRequest;

/**
 * @author acorreia
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
public class PoolIpServiceTest extends EasyMockSupport
{
  private static final String _poolIpUrl = "/poolIp"; //$NON-NLS-1$

  private RESConnector _resConnector;
  private Tracabilite _tracabilite;

  private Capture<MultivaluedMap<String, String>> _headersCapture;
  private Capture<Map<String, String>> _queryParamsCapture;

  @MockStrict
  private Hashtable<String, RestConnectorPool> _connectorPoolMock;

  @MockStrict
  private RestInstance _restInstanceMock;

  @MockStrict
  private RestConnectorPool _restConnectorPoolMock;

  /**
   * Run after each test.
   */
  @After
  public void afterTest()
  {
    // Check that there are no unverified captures
    Assert.assertFalse("Unverified headers.", _headersCapture.hasCaptured()); //$NON-NLS-1$
    Assert.assertFalse("Unverified query parameters.", _queryParamsCapture.hasCaptured()); //$NON-NLS-1$
  }

  /**
   * Run before each test.
   */
  @Before
  public void beforeTest()
  {
    PowerMock.resetAll();

    _resConnector = new RESConnector();
    _tracabilite = new Tracabilite();

    _headersCapture = Capture.newInstance();
    _queryParamsCapture = Capture.newInstance();
  }

  /**
   * NOK, missing url in configuration.
   *
   * @throws RavelException
   *           on error while loading configuration.
   */
  @Test
  public void poolIpGererImport_test_NOK_01() throws RavelException
  {
    // Expected result
    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, "The configuration parameter POOL_IP_PATH is missing"); //$NON-NLS-1$

    // Prepare and call the method in the connector
    prepareServiceConfiguration(true);

    ConnectorResponse<Retour, Nothing> poolIpResponse = _resConnector.poolIpGererImport(_tracabilite, null);

    // Verify the result
    verifyRetour(expectedRetour, poolIpResponse._first, true);
  }

  /**
   * NOK, sendRequest throws exception.
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void poolIpGererImport_test_NOK_02() throws Exception
  {
    // Expected result
    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, IMegConsts.LIBELLE);

    // Prepare and call the method in the connector
    prepareServiceConfiguration(false);

    final PoolIP poolIP = new PoolIP("nomPoolIP", "typePoolIP", "masqueSousReseau", 5, "passerelle", "statutTechnique", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$

    JUnitTools.setInaccessibleFieldValue(_resConnector, "_connectorPool", _connectorPoolMock); //$NON-NLS-1$

    EasyMock.expect(_connectorPoolMock.get("urlName")).andReturn(_restConnectorPoolMock); //$NON-NLS-1$
    EasyMock.expect(_restConnectorPoolMock.borrowObject()).andThrow(new RavelException(ExceptionType.CONNECTOR_CHECKING_ERROR, ErrorCode.AGRTOR_00001, IMegConsts.LIBELLE));
    _restConnectorPoolMock.returnObject(null);

    PowerMock.replayAll();

    ConnectorResponse<Retour, Nothing> poolIpResponse = _resConnector.poolIpGererImport(_tracabilite, poolIP);

    PowerMock.verifyAll();

    // Verify the result
    verifyRetour(expectedRetour, poolIpResponse._first, false);
  }

  /**
   * NOK, getContentFromResponse throws exception.
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void poolIpGererImport_test_NOK_03() throws Exception
  {
    // Expected result
    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, null);

    Map<String, String> expectedQueryParams = new HashMap<>();
    expectedQueryParams.put("action", "GererImport"); //$NON-NLS-1$ //$NON-NLS-2$

    // Prepare and call the method in the connector
    prepareServiceConfiguration(false);

    final PoolIP poolIP = new PoolIP("nomPoolIP", "typePoolIP", "masqueSousReseau", 5, "passerelle", "statutTechnique", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$

    prepareSendRequest(30);

    ManagePoolIPRequest managePoolIPRequest = new ManagePoolIPRequest(poolIP);
    String poolIpJson = RavelJsonTools.getInstance().toJson(managePoolIPRequest, ManagePoolIPRequest.class);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_poolIpUrl), EasyMock.capture(_headersCapture), EasyMock.eq(poolIpJson), EasyMock.capture(_queryParamsCapture))).andReturn(null);

    PowerMock.replayAll();

    ConnectorResponse<Retour, Nothing> poolIpResponse = _resConnector.poolIpGererImport(_tracabilite, poolIP);

    PowerMock.verifyAll();

    // Verify the result
    verifyRetour(expectedRetour, poolIpResponse._first, true);

    Assert.assertEquals(getMapDefaultHeaders(), _headersCapture.getValue());
    _headersCapture.reset();

    Assert.assertEquals(expectedQueryParams, _queryParamsCapture.getValue());
    _queryParamsCapture.reset();
  }

  /**
   * OK.
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void poolIpGererImport_test_OK() throws Exception
  {
    // Expected result
    Retour expectedRetour = RetourFactoryForTU.createRetour(IMegConsts.RESULTAT, IMegConsts.CATEGORIE, IMegConsts.DIAGNOSTIC, IMegConsts.LIBELLE, null);

    Map<String, String> expectedQueryParams = new HashMap<>();
    expectedQueryParams.put("action", "GererImport"); //$NON-NLS-1$ //$NON-NLS-2$

    // Prepare and call the method in the connector
    prepareServiceConfiguration(false);

    final PoolIP poolIP = new PoolIP("nomPoolIP", "typePoolIP", "masqueSousReseau", 5, "passerelle", "statutTechnique", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$

    Retour importRetour = RetourFactoryForTU.createRetour(IMegConsts.RESULTAT, IMegConsts.CATEGORIE, IMegConsts.DIAGNOSTIC, IMegConsts.LIBELLE, null);
    preparePoolIpGererImport(poolIP, importRetour);

    PowerMock.replayAll();

    ConnectorResponse<Retour, Nothing> poolIpResponse = _resConnector.poolIpGererImport(_tracabilite, poolIP);

    PowerMock.verifyAll();

    // Verify the result
    verifyRetour(expectedRetour, poolIpResponse._first, true);

    Assert.assertEquals(getMapDefaultHeaders(), _headersCapture.getValue());
    _headersCapture.reset();

    Assert.assertEquals(expectedQueryParams, _queryParamsCapture.getValue());
    _queryParamsCapture.reset();
  }

  /**
   * Get a map with the default headers.
   *
   * @return the map.
   */
  private MultivaluedMap<String, String> getMapDefaultHeaders()
  {
    MultivaluedMap<String, String> headers = new MultivaluedHashMap<>();
    headers.put(IHttpHeadersConsts.X_REQUEST_ID, Collections.singletonList(null));
    headers.put(IHttpHeadersConsts.X_SOURCE, Collections.singletonList(null));
    headers.add(IHttpHeadersConsts.X_OAUTH2_HABILIT, "SPIRIT_STARK"); //$NON-NLS-1$
    headers.put(IHttpHeadersConsts.X_PROCESS, Collections.singletonList(null));
    headers.put(IHttpHeadersConsts.X_REQUEST_ID_SPIRIT, Collections.singletonList(null));
    headers.put(IHttpHeadersConsts.X_PROCESS_ID_SPIRIT, Collections.singletonList(null));
    headers.add(IHttpHeadersConsts.CONTENT_TYPE, "application/json"); //$NON-NLS-1$

    return headers;
  }

  /**
   * Prepare for the call made by poolIpGererImport.
   *
   * @param poolIP_p
   *          the object being sent.
   * @param retour_p
   *          the retour from the poolIpGererImport.
   * @throws Exception
   *           on error.
   */
  private void preparePoolIpGererImport(PoolIP poolIP_p, Retour retour_p) throws Exception
  {
    prepareSendRequest(30);
    ManagePoolIPRequest managePoolIPRequest = new ManagePoolIPRequest(poolIP_p);

    String poolIpJson = RavelJsonTools.getInstance().toJson(managePoolIPRequest, ManagePoolIPRequest.class);
    String basicResponse = RavelJsonTools.getInstance().toJson(new BasicResponse(RetourConverter.convertToJsonRetour(retour_p)), BasicResponse.class);
    Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(basicResponse.getBytes())).build();

    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_poolIpUrl), EasyMock.capture(_headersCapture), EasyMock.eq(poolIpJson), EasyMock.capture(_queryParamsCapture))).andReturn(response);
  }

  /**
   * Prepare mock scenario to initialize method sendRequest from AbstractSpiritRESTConnector.
   *
   * @param timeout_p
   *          the timeout.
   * @throws Exception
   *           on error.
   */
  private void prepareSendRequest(int timeout_p) throws Exception
  {
    JUnitTools.setInaccessibleFieldValue(_resConnector, "_connectorPool", _connectorPoolMock); //$NON-NLS-1$

    EasyMock.expect(_connectorPoolMock.get("urlName")).andReturn(_restConnectorPoolMock); //$NON-NLS-1$
    EasyMock.expect(_restConnectorPoolMock.borrowObject()).andReturn(_restInstanceMock);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    _restInstanceMock.setReceiveTimeout(timeout_p);
  }

  /**
   * Set all values necessary by the service in order to execute, avoiding the call to loadConnectorConfiguration, and
   * thus the need for a configuration file.
   *
   * @param removeUrl_p
   *          True if the url should be missing from the configuration.
   * @throws RavelException
   *           on error loading the configuration.
   */
  private void prepareServiceConfiguration(boolean removeUrl_p) throws RavelException
  {
    // Set the configuration
    final Connector connector = new Connector();

    // Necessary for any request
    Param param = new Param();
    param.setName("AccesTechniqueCacheDuration"); //$NON-NLS-1$
    param.setValue("PT10M"); //$NON-NLS-1$
    connector.getParam().add(param);

    param = new Param();
    param.setName("AbaqueDSLCacheDuration"); //$NON-NLS-1$
    param.setValue("PT10M"); //$NON-NLS-1$
    connector.getParam().add(param);

    // The configuration specific to this service
    if (!removeUrl_p)
    {
      param = new Param();
      param.setName("POOL_IP_PATH"); //$NON-NLS-1$
      param.setValue(_poolIpUrl);
      connector.getParam().add(param);
    }

    connector.setURLS(RESConnectorTest.generateURLS());

    // Call the loadConnectorConfiguration
    _resConnector.loadConnectorConfiguration(connector);
  }

  /**
   * Verify that the retour is as expected.
   *
   * @param expectedRetour_p
   *          the expected retour.
   * @param actualRetour_p
   *          the actual retour.
   * @param exactLibelle_p
   *          whether to check if the libelle is an exact match or if it is enough for it to check that it is a part of
   *          it.
   */
  private void verifyRetour(Retour expectedRetour_p, Retour actualRetour_p, boolean exactLibelle_p)
  {
    Assert.assertEquals(expectedRetour_p.getResultat(), actualRetour_p.getResultat());
    Assert.assertEquals(expectedRetour_p.getCategorie(), actualRetour_p.getCategorie());
    Assert.assertEquals(expectedRetour_p.getDiagnostic(), actualRetour_p.getDiagnostic());

    if (exactLibelle_p)
    {
      Assert.assertEquals(expectedRetour_p.getLibelle(), actualRetour_p.getLibelle());
    }
    else
    {
      Assert.assertTrue(actualRetour_p.getLibelle().contains(expectedRetour_p.getLibelle()));
    }
  }
}
