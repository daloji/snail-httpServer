/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.res.services;

import java.io.ByteArrayInputStream;
import java.time.Duration;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Map;
import java.util.Set;

import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.cxf.jaxrs.impl.ResponseBuilderImpl;
import org.easymock.Capture;
import org.easymock.EasyMock;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.modules.junit4.PowerMockRunner;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.conf.generated.Param;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.test.JUnitTools;
import com.bytel.ravel.common.test.podam.JavaTimeManufacturer;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.RetourFactoryForTU;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.net.loadbalancing.ILoadBalancer;
import com.bytel.ravel.net.loadbalancing.URLBalancedElement;
import com.bytel.ravel.net.rest.RestConnectorPool;
import com.bytel.ravel.net.rest.RestInstance;
import com.bytel.ravel.services.conf.connector.generated.Connector;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.connectors.res.IRES;
import com.bytel.spirit.common.connectors.res.IRESConnector;
import com.bytel.spirit.common.connectors.res.RESConnector;
import com.bytel.spirit.common.connectors.res.RESConnectorTest;
import com.bytel.spirit.common.shared.functional.types.json.RavelJsonTools;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.ressources.BasicResponse;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.ressources.RetourConverter;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.CompteRenduSuppression;
import com.bytel.spirit.common.shared.saab.res.PMComposite;
import com.bytel.spirit.common.shared.saab.res.request.ManagePmCompositeRequest;
import com.bytel.spirit.common.shared.saab.res.response.ListeCRSupressionResponse;
import com.bytel.spirit.common.shared.types.json.response.PMConsultResponse;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 * @author root
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
public class PmCompositeServiceTest
{
  /** Param name for PAD3200 */
  private static final String PAD3205_PATH_PARAM = "/pmComposite/"; //$NON-NLS-1$

  /**
   * Action
   */
  private static final String PARAM_ACTION = "action"; //$NON-NLS-1$

  private static final String REFERENCE_PM_BYTEL = "referencePmBytel"; //$NON-NLS-1$

  private static final String REFERENCE_PM_BOITIER = "referenceBoitierPm"; //$NON-NLS-1$

  private static final String REFERENCE_PM_OI = "referencePmOi"; //$NON-NLS-1$

  public static final String POSTITION_PORT_PM = "positionPortPM"; //$NON-NLS-1$

  public static final String NOM_PANNEAU = "nomPanneau"; //$NON-NLS-1$

  /**
   * The action
   */
  final static String ACTION_MODIFIER_SURCHARGE_DATE_DEBUT_QUARANTAINE_PM = "ModifierSurChargeDateDebutQuarantainePM"; //$NON-NLS-1$

  /** Factory to generate beans */
  private final PodamFactory _podam = new PodamFactoryImpl();

  /** Path for PAD3205 */
  private String _pmCompositeUrl;

  /** Connector to test */
  private RESConnector _connector;

  /** The traçability */
  private Tracabilite _tracabilite;

  /** Mock {@link ILoadBalancer} */
  @MockStrict
  ILoadBalancer<URLBalancedElement> _loadBalancerMock;

  /** Mock {@link URLBalancedElement} */
  @MockStrict
  URLBalancedElement _urlBalancedElementMock;

  /**
   * Mock of connectors pool HTTP
   */
  @MockStrict
  Hashtable<String, RestConnectorPool> _connectorPoolMock;

  /**
   * Mock {@link RestConnectorPool}
   */
  @MockStrict
  RestConnectorPool _restConnectorPoolMock;

  /**
   * Mock {@link RestInstance}
   */
  @MockStrict
  RestInstance _restInstanceMock;

  /**
   * Initialize before tests
   *
   * @throws Exception
   *           on error. during switch in attributes of parent class
   */
  @Before
  public void beforeTest() throws Exception
  {
    _podam.getStrategy().setMemoization(false);
    _podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());
    JavaTimeManufacturer.registerPodamFactory(_podam);

    _connector = new RESConnector();

    _pmCompositeUrl = PAD3205_PATH_PARAM;
    _tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);

    JUnitTools.setInaccessibleFieldValue(_connector, "_loadBalancer", _loadBalancerMock); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_connectorPool", _connectorPoolMock); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_pmCompositeUrl", _pmCompositeUrl); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_pmCompositeService", new PmCompositeService(_connector)); //$NON-NLS-1$

    PowerMock.resetAll();
  }

  /**
   * Test Exception for the method {@link RESConnector#pmCompositeGererImport}.
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void gererImport_Exception() throws Exception
  {
    Retour expectedRetour = RetourFactoryForTU.createNOK("CAT-10", "TRAITEMENT_ARRETE", "Impossible de récupérer la réponse"); // $NON-NLS-1$ // $NON-NLS-2$ // $NON-NLS-3$

    PMComposite pmComposite = _podam.manufacturePojoWithFullData(PMComposite.class);
    ManagePmCompositeRequest request = new ManagePmCompositeRequest(pmComposite);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    // Prepare the mocks for the calls made by the connector's method
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(StringConstants.EMPTY_STRING.getBytes())).build();

    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_pmCompositeUrl), EasyMock.capture(headersCapture), EasyMock.eq(RavelJsonTools.getInstance().toJson(request, ManagePmCompositeRequest.class)), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    // Call the method
    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.pmCompositeGererImport(_tracabilite, pmComposite);
    PowerMock.verifyAll();

    // Verify the result
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test NOK for the method {@link RESConnector#pmCompositeGererImport}.
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void gererImport_NOK_001() throws Exception
  {
    Retour expectedRetour = RetourFactoryForTU.createNOK("CAT-4", "DONNEE_INVALIDE", "libelle"); // $NON-NLS-1$ // $NON-NLS-2$ // $NON-NLS-3$

    PMComposite update = _podam.manufacturePojoWithFullData(PMComposite.class);
    ManagePmCompositeRequest request = new ManagePmCompositeRequest(update);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    // Prepare the mocks for the calls made by the connector's method
    String retour = "{\"retour\":{\"resultat\":\"NOK\",\"categorie\":\"CAT-4\",\"diagnostic\":\"DONNEE_INVALIDE\",\"libelle\":\"libelle\"}}"; //$NON-NLS-1$
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(retour.getBytes())).build();

    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_pmCompositeUrl), EasyMock.capture(headersCapture), EasyMock.eq(RavelJsonTools.getInstance().toJson(request, ManagePmCompositeRequest.class)), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    // Call the method
    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.pmCompositeGererImport(_tracabilite, update);
    PowerMock.verifyAll();

    // Check the results
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test OK for the method {@link RESConnector#pmCompositeGererImport}.
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void gererImport_OK_001() throws Exception
  {
    PMComposite update = _podam.manufacturePojoWithFullData(PMComposite.class);
    ManagePmCompositeRequest request = new ManagePmCompositeRequest(update);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    // Prepare the mocks for the calls made by the connector's method
    String json = RavelJsonTools.getInstance().toJson(request, ManagePmCompositeRequest.class);
    String result = "{\"retour\":{\"resultat\":\"OK\"}}"; //$NON-NLS-1$
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(result.getBytes())).build();

    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_pmCompositeUrl), EasyMock.capture(headersCapture), EasyMock.eq(json), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    // Call the method
    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> resultResponse = _connector.pmCompositeGererImport(_tracabilite, update);
    PowerMock.verifyAll();

    // Check headers sent
    Assert.assertNotNull(headersCapture.getValue());

    // Check params sent
    checkQueryParams(queryParamsCapture, PARAM_ACTION, "GererImport"); // $NON-NLS-1$

    // Check the results
    Assert.assertNotNull(resultResponse);
    Assert.assertNotNull(resultResponse._first);
    Assert.assertEquals(RetourFactoryForTU.createOkRetour(), resultResponse._first);
    Assert.assertNull(resultResponse._second);
  }

  /**
   * Test Exception for the method {@link RESConnector#pmCompositeGererSuppressionPMNonReference}.
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void gererSuppressionPMNonReference_Exception() throws Exception
  {
    Retour expectedRetour = RetourFactoryForTU.createNOK("CAT-10", "TRAITEMENT_ARRETE", "Impossible de récupérer la réponse"); // $NON-NLS-1$ // $NON-NLS-2$ // $NON-NLS-3$

    Set<String> listNomPM = new HashSet<>();
    ManagePmCompositeRequest request = new ManagePmCompositeRequest(listNomPM);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream("".getBytes())).build(); //$NON-NLS-1$

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_pmCompositeUrl), EasyMock.capture(headersCapture), EasyMock.eq(RavelJsonTools.getInstance().toJson(request, ManagePmCompositeRequest.class)), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    // Call the method
    PowerMock.replayAll();
    final ConnectorResponse<Retour, Set<CompteRenduSuppression>> result = _connector.pmCompositeGererSuppressionPMNonReference(_tracabilite, listNomPM);
    PowerMock.verifyAll();

    // Verify the result
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test NOK for the method pmCompositegererSuppressionPMNonReference.
   * {@link RESConnector#pmCompositeGererSuppressionPMNonReference(Tracabilite, Set)} httpStatus 404
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void gererSuppressionPMNonReference_NOK_001() throws Exception
  {
    Set<String> listNomPM = new HashSet<>();
    ManagePmCompositeRequest request = new ManagePmCompositeRequest(listNomPM);

    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, ""); //$NON-NLS-1$
    ListeCRSupressionResponse pmCompositeResponse = new ListeCRSupressionResponse(RetourConverter.convertToJsonRetour(retour));

    final String partnerResponse = RavelJsonTools.getInstance().toJson(pmCompositeResponse, ListeCRSupressionResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();
    String referencePmOi = "referencePmOi"; //$NON-NLS-1$
    //construct response
    final Response response = new ResponseBuilderImpl().status(404).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(PAD3205_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.eq(RavelJsonTools.getInstance().toJson(request, ManagePmCompositeRequest.class)), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PmCompositeService pmComposite = new PmCompositeService(_connector);
    JUnitTools.setInaccessibleFieldValue(_connector, "_pmCompositeService", pmComposite); //$NON-NLS-1$
    PowerMock.replayAll();
    final ConnectorResponse<Retour, Set<CompteRenduSuppression>> result = _connector.pmCompositeGererSuppressionPMNonReference(_tracabilite, listNomPM);
    PowerMock.verifyAll();

    // Check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_ACTION, IRESConnector.ACTION_GERER_SUPPRESSION_PM_NON_REFERENCE);

    // Check results
    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test OK for the method pmCompositegererSuppressionPMNonReference.
   * {@link RESConnector#pmCompositeGererSuppressionPMNonReference(Tracabilite, Set)} httpStatus 200
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void gererSuppressionPMNonReference_OK_001() throws Exception
  {
    Set<String> listNomPM = new HashSet<>();
    ManagePmCompositeRequest request = new ManagePmCompositeRequest(listNomPM);

    final Retour retour = RetourFactoryForTU.createOkRetour();
    PMConsultResponse pmCompositeResponse = new PMConsultResponse(RetourConverter.convertToJsonRetour(retour));

    final String partnerResponse = RavelJsonTools.getInstance().toJson(pmCompositeResponse, PMConsultResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(PAD3205_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.eq(RavelJsonTools.getInstance().toJson(request, ManagePmCompositeRequest.class)), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PmCompositeService pmComposite = new PmCompositeService(_connector);
    JUnitTools.setInaccessibleFieldValue(_connector, "_pmCompositeService", pmComposite); //$NON-NLS-1$
    PowerMock.replayAll();
    final ConnectorResponse<Retour, Set<CompteRenduSuppression>> result = _connector.pmCompositeGererSuppressionPMNonReference(_tracabilite, null);
    PowerMock.verifyAll();

    // Check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_ACTION, IRESConnector.ACTION_GERER_SUPPRESSION_PM_NON_REFERENCE);

    // Check results
    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test Exception for the method {@link RESConnector#pmCompositeLireSurchargeBoitierPM} OK.
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void lireSurchargeBoitierPM_Exception() throws Exception
  {
    Retour expectedRetour = RetourFactoryForTU.createNOK("CAT-10", "TRAITEMENT_ARRETE", "Impossible de récupérer la réponse"); // $NON-NLS-1$ // $NON-NLS-2$ // $NON-NLS-3$

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream("".getBytes())).build(); //$NON-NLS-1$

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(PAD3205_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    // Call the method
    PowerMock.replayAll();
    final ConnectorResponse<Retour, PMConsultResponse> result = _connector.pmCompositeLireSurchargeBoitierPM(_tracabilite, "referencePmBytel", "referenceBoitierPm", "nomPanneau", "1"); //$NON-NLS-1$ //$NON-NLS-2$ // $NON-NLS-3$
    PowerMock.verifyAll();

    // Verify the result
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test NOK for the {@link RESConnector#pmCompositeLireSurchargeBoitierPM} httpStatus 404
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void lireSurchargeBoitierPM_NOK_001() throws Exception
  {
    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, ""); //$NON-NLS-1$
    PMConsultResponse pmCompositeResponse = new PMConsultResponse(RetourConverter.convertToJsonRetour(retour));

    final String partnerResponse = RavelJsonTools.getInstance().toJson(pmCompositeResponse, PMConsultResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(404).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(PAD3205_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PmCompositeService pmComposite = new PmCompositeService(_connector);
    JUnitTools.setInaccessibleFieldValue(_connector, "_pmCompositeService", pmComposite); //$NON-NLS-1$
    PowerMock.replayAll();
    final ConnectorResponse<Retour, PMConsultResponse> result = _connector.pmCompositeLireSurchargeBoitierPM(_tracabilite, "referencePmBytel", "referenceBoitierPm", "nomPanneau", "1");
    PowerMock.verifyAll();

    // Check header
    Assert.assertNotNull(headersCapture.getValue());

    // Check params sent
    checkQueryParams(queryParamsCapture, PARAM_ACTION, "LireSurchargeBoitierPM"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, REFERENCE_PM_BYTEL, "referencePmBytel"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, REFERENCE_PM_BOITIER, "referenceBoitierPm"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, NOM_PANNEAU, "nomPanneau"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, POSTITION_PORT_PM, "1");

    // Check results
    Assert.assertEquals(retour, result._first);
    Assert.assertNotNull(result._second);
  }

  /**
   * Test OK for the method pad3205LireSurcharge.
   * {@link IRES#pmCompositeLireSurchargeBoitierPM(Tracabilite, String, String, String, String)} httpStatus 200
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void lireSurchargeBoitierPM_OK_001() throws Exception
  {
    final Retour retour = RetourFactoryForTU.createOkRetour();
    PMConsultResponse pmCompositeResponse = new PMConsultResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = RavelJsonTools.getInstance().toJson(pmCompositeResponse, PMConsultResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();
    String referencePmBytel = "referencePmBytel"; //$NON-NLS-1$
    String referenceBoitierPm = "referenceBoitierPm"; //$NON-NLS-1$
    String nomPanneau = "nomPanneau"; //$NON-NLS-1$
    String positionPortPM = "positionPortPM"; //$NON-NLS-1$

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(PAD3205_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PmCompositeService pmComposite = new PmCompositeService(_connector);
    JUnitTools.setInaccessibleFieldValue(_connector, "_pmCompositeService", pmComposite); //$NON-NLS-1$
    PowerMock.replayAll();
    final ConnectorResponse<Retour, PMConsultResponse> result = _connector.pmCompositeLireSurchargeBoitierPM(_tracabilite, referencePmBytel, referenceBoitierPm, nomPanneau, positionPortPM);
    PowerMock.verifyAll();

    // Check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_ACTION, "LireSurchargeBoitierPM"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, IRESConnector.REFERENCE_PM_BYTEL, referencePmBytel);
    checkQueryParams(queryParamsCapture, IRESConnector.REFERENCE_BOITIER_PM, referenceBoitierPm);
    checkQueryParams(queryParamsCapture, IRESConnector.NOM_PANNEAU, nomPanneau);
    checkQueryParams(queryParamsCapture, IRESConnector.POSITION_PORT_PM, positionPortPM);

    // Check results
    Assert.assertEquals(retour, result._first);
    Assert.assertNotNull(result._second);
  }

  /**
   * Test Exception for the method {@link RESConnector#pmCompositeLireSurchargePM} OK.
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void lireSurchargePM_Exception() throws Exception
  {
    Retour expectedRetour = RetourFactoryForTU.createNOK("CAT-10", "TRAITEMENT_ARRETE", "Impossible de récupérer la réponse"); // $NON-NLS-1$ // $NON-NLS-2$ // $NON-NLS-3$

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream("".getBytes())).build(); //$NON-NLS-1$

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(PAD3205_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    // Call the method
    PowerMock.replayAll();
    final ConnectorResponse<Retour, PMConsultResponse> result = _connector.pmCompositeLireSurchargePM(_tracabilite, "referencePmBytel", "referenceBoitierPm", "nomPanneau", "1"); //$NON-NLS-1$ //$NON-NLS-2$ // $NON-NLS-3$
    PowerMock.verifyAll();

    // Verify the result
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test NOK for the {@link RESConnector#pmCompositeLireSurchargePM} httpStatus 404
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void lireSurchargePM_NOK_001() throws Exception
  {
    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, ""); //$NON-NLS-1$
    PMConsultResponse pmCompositeResponse = new PMConsultResponse(RetourConverter.convertToJsonRetour(retour));

    final String partnerResponse = RavelJsonTools.getInstance().toJson(pmCompositeResponse, PMConsultResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(404).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(PAD3205_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PmCompositeService pmComposite = new PmCompositeService(_connector);
    JUnitTools.setInaccessibleFieldValue(_connector, "_pmCompositeService", pmComposite); //$NON-NLS-1$
    PowerMock.replayAll();
    final ConnectorResponse<Retour, PMConsultResponse> result = _connector.pmCompositeLireSurchargePM(_tracabilite, "referencePmBytel", "referenceBoitierPm", "nomPanneau", "1");
    PowerMock.verifyAll();

    // Check results
    Assert.assertEquals(retour, result._first);
    Assert.assertNotNull(result._second);
  }

  /**
   * Test OK for the method {@link IRES#pmCompositeLireSurchargeBoitierPM}.
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void lireSurchargePM_OK_001() throws Exception
  {
    final Retour retour = RetourFactoryForTU.createOkRetour();
    PMConsultResponse pmCompositeResponse = new PMConsultResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = RavelJsonTools.getInstance().toJson(pmCompositeResponse, PMConsultResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();
    String referencePmBytel = "referencePmBytel"; //$NON-NLS-1$
    String referenceBoitierPm = "referenceBoitierPm"; //$NON-NLS-1$
    String nomPanneau = "nomPanneau"; //$NON-NLS-1$
    String positionPortPM = "positionPortPM"; //$NON-NLS-1$

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(PAD3205_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PmCompositeService pmComposite = new PmCompositeService(_connector);
    JUnitTools.setInaccessibleFieldValue(_connector, "_pmCompositeService", pmComposite); //$NON-NLS-1$
    PowerMock.replayAll();
    final ConnectorResponse<Retour, PMConsultResponse> result = _connector.pmCompositeLireSurchargePM(_tracabilite, referencePmBytel, referenceBoitierPm, nomPanneau, positionPortPM);
    PowerMock.verifyAll();

    // Check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_ACTION, "LireSurchargePM"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, IRESConnector.REFERENCE_PM_BYTEL, referencePmBytel);
    checkQueryParams(queryParamsCapture, IRESConnector.REFERENCE_BOITIER_PM, referenceBoitierPm);
    checkQueryParams(queryParamsCapture, IRESConnector.NOM_PANNEAU, nomPanneau);
    checkQueryParams(queryParamsCapture, IRESConnector.POSITION_PORT_PM, positionPortPM);

    // Check results
    Assert.assertEquals(retour, result._first);
    Assert.assertNotNull(result._second);
  }

  /**
   * Test Exception for the method {@link RESConnector#pmCompositeLireSurchargePortPM} OK.
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void lireSurchargePortPM_Exception() throws Exception
  {
    Retour expectedRetour = RetourFactoryForTU.createNOK("CAT-10", "TRAITEMENT_ARRETE", "Impossible de récupérer la réponse"); // $NON-NLS-1$ // $NON-NLS-2$ // $NON-NLS-3$

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream("".getBytes())).build(); //$NON-NLS-1$

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(PAD3205_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    // Call the method
    PowerMock.replayAll();
    final ConnectorResponse<Retour, PMConsultResponse> result = _connector.pmCompositeLireSurchargePortPM(_tracabilite, "referencePmBytel", "referenceBoitierPm", "nomPanneau", "1"); //$NON-NLS-1$ //$NON-NLS-2$ // $NON-NLS-3$
    PowerMock.verifyAll();

    // Verify the result
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test NOK for the {@link RESConnector#pmCompositeLireSurchargePortPM} httpStatus 404
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void lireSurchargePortPM_NOK_001() throws Exception
  {
    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, ""); //$NON-NLS-1$
    PMConsultResponse pmCompositeResponse = new PMConsultResponse(RetourConverter.convertToJsonRetour(retour));

    final String partnerResponse = RavelJsonTools.getInstance().toJson(pmCompositeResponse, PMConsultResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(404).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(PAD3205_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PmCompositeService pmComposite = new PmCompositeService(_connector);
    JUnitTools.setInaccessibleFieldValue(_connector, "_pmCompositeService", pmComposite); //$NON-NLS-1$
    PowerMock.replayAll();
    final ConnectorResponse<Retour, PMConsultResponse> result = _connector.pmCompositeLireSurchargePortPM(_tracabilite, "referencePmBytel", "referenceBoitierPm", "nomPanneau", "1");
    PowerMock.verifyAll();

    // Check results
    Assert.assertEquals(retour, result._first);
    Assert.assertNotNull(result._second);
  }

  /**
   * Test OK for the method {@link IRES#pmCompositeLireSurchargeBoitierPM}.
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void lireSurchargePortPM_OK_001() throws Exception
  {
    final Retour retour = RetourFactoryForTU.createOkRetour();
    PMConsultResponse pmCompositeResponse = new PMConsultResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = RavelJsonTools.getInstance().toJson(pmCompositeResponse, PMConsultResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();
    String referencePmBytel = "referencePmBytel"; //$NON-NLS-1$
    String referenceBoitierPm = "referenceBoitierPm"; //$NON-NLS-1$
    String nomPanneau = "nomPanneau"; //$NON-NLS-1$
    String positionPortPM = "positionPortPM"; //$NON-NLS-1$

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(PAD3205_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PmCompositeService pmComposite = new PmCompositeService(_connector);
    JUnitTools.setInaccessibleFieldValue(_connector, "_pmCompositeService", pmComposite); //$NON-NLS-1$
    PowerMock.replayAll();
    final ConnectorResponse<Retour, PMConsultResponse> result = _connector.pmCompositeLireSurchargePortPM(_tracabilite, referencePmBytel, referenceBoitierPm, nomPanneau, positionPortPM);
    PowerMock.verifyAll();

    // Check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_ACTION, "LireSurchargePortPM"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, IRESConnector.REFERENCE_PM_BYTEL, referencePmBytel);
    checkQueryParams(queryParamsCapture, IRESConnector.REFERENCE_BOITIER_PM, referenceBoitierPm);
    checkQueryParams(queryParamsCapture, IRESConnector.NOM_PANNEAU, nomPanneau);
    checkQueryParams(queryParamsCapture, IRESConnector.POSITION_PORT_PM, positionPortPM);

    // Check results
    Assert.assertEquals(retour, result._first);
    Assert.assertNotNull(result._second);
  }

  /**
   * Test Exception for the method {@link RESConnector#pmCompositeLireUnParReferencePmBytel} OK.
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void lireUnParReferencePmBytel_Exception() throws Exception
  {
    Retour expectedRetour = RetourFactoryForTU.createNOK("CAT-10", "TRAITEMENT_ARRETE", "Impossible de récupérer la réponse"); // $NON-NLS-1$ // $NON-NLS-2$ // $NON-NLS-3$

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream("".getBytes())).build(); //$NON-NLS-1$

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(PAD3205_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    // Call the method
    PowerMock.replayAll();
    final ConnectorResponse<Retour, PMComposite> result = _connector.pmCompositeLireUnParReferencePmBytel(_tracabilite, "referencePmBytel"); //$NON-NLS-1$
    PowerMock.verifyAll();

    // Verify the result
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test NOK for the method pmCompositeLireUnParReferencePmBytel.
   * {@link RESConnector#pmCompositeLireUnParReferencePmBytel(Tracabilite, String)} httpStatus 404
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void lireUnParReferencePmBytel_NOK_001() throws Exception
  {
    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, ""); //$NON-NLS-1$
    PMConsultResponse pmCompositeResponse = new PMConsultResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = RavelJsonTools.getInstance().toJson(pmCompositeResponse, PMConsultResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();
    String referencePMBytel = "referencePMBytel"; //$NON-NLS-1$
    //construct response
    final Response response = new ResponseBuilderImpl().status(404).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(PAD3205_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PmCompositeService pmComposite = new PmCompositeService(_connector);
    JUnitTools.setInaccessibleFieldValue(_connector, "_pmCompositeService", pmComposite); //$NON-NLS-1$
    PowerMock.replayAll();
    final ConnectorResponse<Retour, PMComposite> result = _connector.pmCompositeLireUnParReferencePmBytel(_tracabilite, referencePMBytel);
    PowerMock.verifyAll();

    // Check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, REFERENCE_PM_BYTEL, referencePMBytel);

    // Check results
    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test OK for the method pmCompositeLireUnParReferencePmBytel.
   * {@link RESConnector#pmCompositeLireUnParReferencePmBytel(Tracabilite, String)} httpStatus 200
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void lireUnParReferencePmBytel_OK_001() throws Exception
  {
    Retour retourOK = RetourFactoryForTU.createOkRetour();
    PMConsultResponse pmCompositeResponse = new PMConsultResponse(RetourConverter.convertToJsonRetour(retourOK));
    pmCompositeResponse.setPmComposite(_podam.manufacturePojoWithFullData(PMComposite.class));
    final String partnerResponse = RavelJsonTools.getInstance().toJson(pmCompositeResponse, PMConsultResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();
    String referencePMBytel = "referencePMBytel";
    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(PAD3205_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PmCompositeService pmComposite = new PmCompositeService(_connector);
    JUnitTools.setInaccessibleFieldValue(_connector, "_pmCompositeService", pmComposite); //$NON-NLS-1$
    PowerMock.replayAll();
    final ConnectorResponse<Retour, PMComposite> result = _connector.pmCompositeLireUnParReferencePmBytel(_tracabilite, referencePMBytel);
    PowerMock.verifyAll();

    // Check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, REFERENCE_PM_BYTEL, referencePMBytel);

    // Check results
    Assert.assertEquals(retourOK, result._first);
    Assert.assertNotNull(result._second);
  }

  /**
   * Test Exception for the method {@link RESConnector#pmCompositeLireUnParReferencePmOi} OK.
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void lireUnParReferencePmOi_Exception() throws Exception
  {
    Retour expectedRetour = RetourFactoryForTU.createNOK("CAT-10", "TRAITEMENT_ARRETE", "Impossible de récupérer la réponse"); // $NON-NLS-1$ // $NON-NLS-2$ // $NON-NLS-3$

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream("".getBytes())).build(); //$NON-NLS-1$

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(PAD3205_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    // Call the method
    PowerMock.replayAll();
    final ConnectorResponse<Retour, PMComposite> result = _connector.pmCompositeLireUnParReferencePmOi(_tracabilite, "referencePmOi"); //$NON-NLS-1$
    PowerMock.verifyAll();

    // Verify the result
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test NOK for the method pmCompositeLireUnParReferencePmOi.
   * {@link RESConnector#pmCompositeLireUnParReferencePmOi(Tracabilite, String)} httpStatus 404
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void lireUnParReferencePmOi_NOK_001() throws Exception
  {

    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, ""); //$NON-NLS-1$
    PMConsultResponse pmCompositeResponse = new PMConsultResponse(RetourConverter.convertToJsonRetour(retour));

    final String partnerResponse = RavelJsonTools.getInstance().toJson(pmCompositeResponse, PMConsultResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();
    String referencePmOi = "referencePmOi"; //$NON-NLS-1$
    //construct response
    final Response response = new ResponseBuilderImpl().status(404).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(PAD3205_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PmCompositeService pmComposite = new PmCompositeService(_connector);
    JUnitTools.setInaccessibleFieldValue(_connector, "_pmCompositeService", pmComposite); //$NON-NLS-1$
    PowerMock.replayAll();
    final ConnectorResponse<Retour, PMComposite> result = _connector.pmCompositeLireUnParReferencePmOi(_tracabilite, referencePmOi);
    PowerMock.verifyAll();

    // Check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, REFERENCE_PM_OI, referencePmOi);

    // Check results
    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test OK for the method pmCompositeLireUnParReferencePmOi.
   * {@link RESConnector#pmCompositeLireUnParReferencePmOi(Tracabilite, String)} httpStatus 200
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void lireUnParReferencePmOi_OK_001() throws Exception
  {
    final Retour retour = RetourFactoryForTU.createOkRetour();
    PMConsultResponse pmCompositeResponse = new PMConsultResponse(RetourConverter.convertToJsonRetour(retour));

    final String partnerResponse = RavelJsonTools.getInstance().toJson(pmCompositeResponse, PMConsultResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();
    String referencePmOi = "ReferencePmOi";
    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(PAD3205_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PmCompositeService pmComposite = new PmCompositeService(_connector);
    JUnitTools.setInaccessibleFieldValue(_connector, "_pmCompositeService", pmComposite); //$NON-NLS-1$
    PowerMock.replayAll();
    final ConnectorResponse<Retour, PMComposite> result = _connector.pmCompositeLireUnParReferencePmOi(_tracabilite, referencePmOi);
    PowerMock.verifyAll();

    // Check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, REFERENCE_PM_OI, referencePmOi);

    // Check results
    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * @throws Exception
   *           Exception
   */
  @Test
  public void loadConnectorConfigurationTest() throws Exception
  {
    final Connector connector = new Connector();

    Param param = new Param();
    param.setName("PAD3205_PATH_PARAM"); //$NON-NLS-1$
    param.setValue(_pmCompositeUrl);
    connector.getParam().add(param);

    param = new Param();
    param.setName("AccesTechniqueCacheDuration"); //$NON-NLS-1$
    param.setValue("PT10M"); //$NON-NLS-1$
    connector.getParam().add(param);

    param = new Param();
    param.setName("AbaqueDSLCacheDuration"); //$NON-NLS-1$
    param.setValue("PT10M"); //$NON-NLS-1$
    connector.getParam().add(param);

    connector.setURLS(RESConnectorTest.generateURLS());

    // test
    _connector.loadConnectorConfiguration(connector);

    // assertions
    Assert.assertEquals(_pmCompositeUrl, JUnitTools.getInaccessibleFieldValue(_connector, "_pmCompositeUrl")); //$NON-NLS-1$
    Assert.assertNotNull(JUnitTools.getInaccessibleFieldValue(_connector, "_pmCompositeService")); //$NON-NLS-1$
    Assert.assertEquals(Duration.parse("PT10M"), JUnitTools.getInaccessibleFieldValue(_connector, "_accesTechniqueCacheDuration")); //$NON-NLS-1$
    Assert.assertEquals(Duration.parse("PT10M"), JUnitTools.getInaccessibleFieldValue(_connector, "_abaqueDslCacheDuration")); //$NON-NLS-1$
  }

  /**
   * Test NOK for the {@link RESConnector#pmCompositeModifierSurchargeDateDebutQuarantainePM}.
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void modifierSurchargeDateDebutQuarantainePM_NOK_001() throws Exception
  {
    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, _podam.manufacturePojoWithFullData(String.class));
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(expectedRetour));

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(RavelJsonTools.getInstance().toJson(basicResponse, BasicResponse.class).getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(PAD3205_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.isNull(), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PmCompositeService pmComposite = new PmCompositeService(_connector);
    JUnitTools.setInaccessibleFieldValue(_connector, "_pmCompositeService", pmComposite); //$NON-NLS-1$

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.pmCompositeModifierSurchargeDateDebutQuarantainePM(_tracabilite, null);
    PowerMock.verifyAll();

    // Check results
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test OK for the method {@link RESConnector#pmCompositeModifierSurchargeDateDebutQuarantainePM}.
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void modifierSurchargeDateDebutQuarantainePM_OK_001() throws Exception
  {
    final Retour expectedRetour = RetourFactoryForTU.createOkRetour();
    final String referencePmBytel = _podam.manufacturePojoWithFullData(String.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(RetourFactory.createOkRetour()));
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(RavelJsonTools.getInstance().toJson(basicResponse, BasicResponse.class).getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(PAD3205_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.isNull(), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PmCompositeService pmComposite = new PmCompositeService(_connector);
    JUnitTools.setInaccessibleFieldValue(_connector, "_pmCompositeService", pmComposite); //$NON-NLS-1$

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> resultResponse = _connector.pmCompositeModifierSurchargeDateDebutQuarantainePM(_tracabilite, referencePmBytel);
    PowerMock.verifyAll();

    // Check header
    checkHeaders(_tracabilite, headersCapture);

    // Check params sent
    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_ACTION, ACTION_MODIFIER_SURCHARGE_DATE_DEBUT_QUARANTAINE_PM);
    checkQueryParams(queryParamsCapture, IRESConnector.REFERENCE_PM_BYTEL, referencePmBytel);

    // Check results
    Assert.assertEquals(expectedRetour, resultResponse._first);
    Assert.assertNull(resultResponse._second);
  }

  /**
   * Test Exception for the method {@link RESConnector#pmCompositeModifierSurchargeExploitationPortPM} OK.
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void modifierSurchargeExploitationPortPM_Exception() throws Exception
  {
    Retour expectedRetour = RetourFactoryForTU.createNOK("CAT-10", "TRAITEMENT_ARRETE", "Impossible de récupérer la réponse"); // $NON-NLS-1$ // $NON-NLS-2$ // $NON-NLS-3$

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream("".getBytes())).build(); //$NON-NLS-1$

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(PAD3205_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.isNull(), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    // Call the method
    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.pmCompositeModifierSurchargeExploitationPortPM(_tracabilite, "referencePmBytel", "referenceBoitierPm", "nomPanneau", "positionPortPM", "statutExploitation", "commentaireExploitation"); //$NON-NLS-1$ //$NON-NLS-2$ // $NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ // $NON-NLS-6$
    PowerMock.verifyAll();

    // Verify the result
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test NOK for the {@link RESConnector#pmCompositeModifierSurchargeExploitationPortPM} httpStatus 404
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void modifierSurchargeExploitationPortPM_NOK_001() throws Exception
  {
    Retour expectedRetour = RetourFactoryForTU.createNOK("CAT-4", "DONNEE_INVALIDE", "libelle"); // $NON-NLS-1$ // $NON-NLS-2$ // $NON-NLS-3$

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    String retour = "{\"retour\":{\"resultat\":\"NOK\",\"categorie\":\"CAT-4\",\"diagnostic\":\"DONNEE_INVALIDE\",\"libelle\":\"libelle\"}}"; //$NON-NLS-1$
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(retour.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(PAD3205_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.isNull(), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PmCompositeService pmComposite = new PmCompositeService(_connector);
    JUnitTools.setInaccessibleFieldValue(_connector, "_pmCompositeService", pmComposite); //$NON-NLS-1$

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.pmCompositeModifierSurchargeExploitationPortPM(_tracabilite, "referencePmBytel", "referenceBoitierPm", "nomPanneau", "positionPortPM", "statutExploitation", "commentaireExploitation"); //$NON-NLS-1$ //$NON-NLS-2$ // $NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ // $NON-NLS-6$
    PowerMock.verifyAll();

    // Check results
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test OK for the method {@link IRES#pmCompositeModifierSurchargeExploitationPortPM}.
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void modifierSurchargeExploitationPortPM_OK_001() throws Exception
  {
    final Retour expectedRetour = RetourFactoryForTU.createOkRetour();

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    String result = "{\"retour\":{\"resultat\":\"OK\"}}"; //$NON-NLS-1$
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(result.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(PAD3205_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.isNull(), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PmCompositeService pmComposite = new PmCompositeService(_connector);
    JUnitTools.setInaccessibleFieldValue(_connector, "_pmCompositeService", pmComposite); //$NON-NLS-1$

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> resultResponse = _connector.pmCompositeModifierSurchargeExploitationPortPM(_tracabilite, "referencePmBytel", "referenceBoitierPm", "nomPanneau", "positionPortPM", "statutExploitation", "commentaireExploitation"); //$NON-NLS-1$ //$NON-NLS-2$ // $NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ // $NON-NLS-6$
    PowerMock.verifyAll();

    // Check header
    checkHeaders(_tracabilite, headersCapture);

    // Check params sent
    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_ACTION, "ModifierSurChargeExploitationPortPM"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, IRESConnector.REFERENCE_PM_BYTEL, "referencePmBytel"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, IRESConnector.REFERENCE_BOITIER_PM, "referenceBoitierPm"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, IRESConnector.NOM_PANNEAU, "nomPanneau"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, IRESConnector.POSITION_PORT_PM, "positionPortPM"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, IRESConnector.STATUT_EXPLOITATION, "statutExploitation"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, IRESConnector.COMMENTAIRE_EXPLOITATION, "commentaireExploitation"); //$NON-NLS-1$

    // Check results
    Assert.assertEquals(expectedRetour, resultResponse._first);
    Assert.assertNull(resultResponse._second);
  }

  /**
   * Test Exception for the method {@link RESConnector#pmCompositeModifierSurchargePriseClientBoitierPM} OK.
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void modifierSurchargePriseClientBoitierPM_Exception() throws Exception
  {
    Retour expectedRetour = RetourFactoryForTU.createNOK("CAT-10", "TRAITEMENT_ARRETE", "Impossible de récupérer la réponse"); // $NON-NLS-1$ // $NON-NLS-2$ // $NON-NLS-3$

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream("".getBytes())).build(); //$NON-NLS-1$

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(PAD3205_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.isNull(), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    // Call the method
    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.pmCompositeModifierSurchargePriseClientBoitierPM(_tracabilite, "referencePmBytel", "referenceBoitierPm", "statutBlocage", "commentaireBlocage"); //$NON-NLS-1$ //$NON-NLS-2$ // $NON-NLS-3$
    PowerMock.verifyAll();

    // Verify the result
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test NOK for the {@link RESConnector#pmCompositeModifierSurchargePriseClientBoitierPM} httpStatus 404
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void modifierSurchargePriseClientBoitierPM_NOK_001() throws Exception
  {
    Retour expectedRetour = RetourFactoryForTU.createNOK("CAT-4", "DONNEE_INVALIDE", "libelle"); // $NON-NLS-1$ // $NON-NLS-2$ // $NON-NLS-3$

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    String retour = "{\"retour\":{\"resultat\":\"NOK\",\"categorie\":\"CAT-4\",\"diagnostic\":\"DONNEE_INVALIDE\",\"libelle\":\"libelle\"}}"; //$NON-NLS-1$
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(retour.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(PAD3205_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.isNull(), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PmCompositeService pmComposite = new PmCompositeService(_connector);
    JUnitTools.setInaccessibleFieldValue(_connector, "_pmCompositeService", pmComposite); //$NON-NLS-1$

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.pmCompositeModifierSurchargePriseClientBoitierPM(_tracabilite, "referencePmBytel", "referenceBoitierPm", "statutBlocage", "commentaireBlocage"); //$NON-NLS-1$ //$NON-NLS-2$ // $NON-NLS-3$
    PowerMock.verifyAll();

    // Check results
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test OK for the method {@link IRES#pmCompositeModifierSurchargePriseClientBoitierPM}.
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void modifierSurchargePriseClientBoitierPM_OK_001() throws Exception
  {
    final Retour expectedRetour = RetourFactoryForTU.createOkRetour();

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();
    String referencePmBytel = "referencePmBytel"; //$NON-NLS-1$
    String referenceBoitierPm = "referenceBoitierPm"; //$NON-NLS-1$
    String statutBlocage = "statutBlocage"; //$NON-NLS-1$
    String commentaireBlocage = "commentaireBlocage"; //$NON-NLS-1$

    //construct response
    String result = "{\"retour\":{\"resultat\":\"OK\"}}"; //$NON-NLS-1$
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(result.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(PAD3205_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.isNull(), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PmCompositeService pmComposite = new PmCompositeService(_connector);
    JUnitTools.setInaccessibleFieldValue(_connector, "_pmCompositeService", pmComposite); //$NON-NLS-1$

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> resultResponse = _connector.pmCompositeModifierSurchargePriseClientBoitierPM(_tracabilite, "referencePmBytel", "referenceBoitierPm", "statutBlocage", "commentaireBlocage"); //$NON-NLS-1$ //$NON-NLS-2$ // $NON-NLS-3$
    PowerMock.verifyAll();

    // Check header
    checkHeaders(_tracabilite, headersCapture);

    // Check params sent
    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_ACTION, "ModifierSurChargePriseClientBoitierPM"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, IRESConnector.REFERENCE_PM_BYTEL, referencePmBytel);
    checkQueryParams(queryParamsCapture, IRESConnector.REFERENCE_BOITIER_PM, referenceBoitierPm);
    checkQueryParams(queryParamsCapture, IRESConnector.STATUT_BLOCAGE, statutBlocage);
    checkQueryParams(queryParamsCapture, IRESConnector.COMMENTAIRE_BLOCAGE, commentaireBlocage);

    // Check results
    Assert.assertEquals(expectedRetour, resultResponse._first);
    Assert.assertNull(resultResponse._second);
  }

  /**
   * Test Exception for the method {@link RESConnector#pmCompositeModifierSurchargePriseClientPM} OK.
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void modifierSurchargePriseClientPM_Exception() throws Exception
  {
    Retour expectedRetour = RetourFactoryForTU.createNOK("CAT-10", "TRAITEMENT_ARRETE", "Impossible de récupérer la réponse"); // $NON-NLS-1$ // $NON-NLS-2$ // $NON-NLS-3$

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream("".getBytes())).build(); //$NON-NLS-1$

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(PAD3205_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.isNull(), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    // Call the method
    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.pmCompositeModifierSurchargePriseClientPM(_tracabilite, "referencePmBytel", "statutBlocage", "commentaireBlocage"); //$NON-NLS-1$ //$NON-NLS-2$ // $NON-NLS-3$
    PowerMock.verifyAll();

    // Verify the result
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test NOK for the {@link RESConnector#pmCompositeModifierSurchargePriseClientPM} httpStatus 404
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void modifierSurchargePriseClientPM_NOK_001() throws Exception
  {
    Retour expectedRetour = RetourFactoryForTU.createNOK("CAT-4", "DONNEE_INVALIDE", "libelle"); // $NON-NLS-1$ // $NON-NLS-2$ // $NON-NLS-3$

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    String retour = "{\"retour\":{\"resultat\":\"NOK\",\"categorie\":\"CAT-4\",\"diagnostic\":\"DONNEE_INVALIDE\",\"libelle\":\"libelle\"}}"; //$NON-NLS-1$
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(retour.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(PAD3205_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.isNull(), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PmCompositeService pmComposite = new PmCompositeService(_connector);
    JUnitTools.setInaccessibleFieldValue(_connector, "_pmCompositeService", pmComposite); //$NON-NLS-1$

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.pmCompositeModifierSurchargePriseClientPM(_tracabilite, "referencePmBytel", "statutBlocage", "commentaireBlocage"); //$NON-NLS-1$ //$NON-NLS-2$ // $NON-NLS-3$
    PowerMock.verifyAll();

    // Check results
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test OK for the method {@link IRES#pmCompositeModifierSurchargePriseClientPM}.
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void modifierSurchargePriseClientPM_OK_001() throws Exception
  {
    final Retour expectedRetour = RetourFactoryForTU.createOkRetour();

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    String result = "{\"retour\":{\"resultat\":\"OK\"}}"; //$NON-NLS-1$
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(result.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(PAD3205_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.isNull(), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PmCompositeService pmComposite = new PmCompositeService(_connector);
    JUnitTools.setInaccessibleFieldValue(_connector, "_pmCompositeService", pmComposite); //$NON-NLS-1$

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> resultResponse = _connector.pmCompositeModifierSurchargePriseClientPM(_tracabilite, "referencePmBytel", "statutBlocage", "commentaireBlocage"); //$NON-NLS-1$ //$NON-NLS-2$ // $NON-NLS-3$
    PowerMock.verifyAll();

    // Check header
    checkHeaders(_tracabilite, headersCapture);

    // Check params sent
    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_ACTION, "ModifierSurChargePriseClientPM"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, IRESConnector.REFERENCE_PM_BYTEL, "referencePmBytel"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, IRESConnector.STATUT_BLOCAGE, "statutBlocage"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, IRESConnector.COMMENTAIRE_BLOCAGE, "commentaireBlocage"); //$NON-NLS-1$

    // Check results
    Assert.assertEquals(expectedRetour, resultResponse._first);
    Assert.assertNull(resultResponse._second);
  }

  /**
   * Test Exception for the method {@link RESConnector#pmCompositeModifierSurchargePriseClientPortPM} OK.
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void modifierSurchargePriseClientPortPM_Exception() throws Exception
  {
    Retour expectedRetour = RetourFactoryForTU.createNOK("CAT-10", "TRAITEMENT_ARRETE", "Impossible de récupérer la réponse"); // $NON-NLS-1$ // $NON-NLS-2$ // $NON-NLS-3$

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream("".getBytes())).build(); //$NON-NLS-1$

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(PAD3205_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.isNull(), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    // Call the method
    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.pmCompositeModifierSurchargePriseClientPortPM(_tracabilite, "referencePmBytel", "referenceBoitierPm", "nomPanneau", "positionPortPM", "statutBlocage", "commentaireBlocage"); //$NON-NLS-1$ //$NON-NLS-2$ // $NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ // $NON-NLS-6$
    PowerMock.verifyAll();

    // Verify the result
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test NOK for the {@link RESConnector#pmCompositeModifierSurchargePriseClientPortPM}.
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void modifierSurchargePriseClientPortPM_NOK_001() throws Exception
  {
    Retour expectedRetour = RetourFactoryForTU.createNOK("CAT-4", "DONNEE_INVALIDE", "libelle"); // $NON-NLS-1$ // $NON-NLS-2$ // $NON-NLS-3$

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    String retour = "{\"retour\":{\"resultat\":\"NOK\",\"categorie\":\"CAT-4\",\"diagnostic\":\"DONNEE_INVALIDE\",\"libelle\":\"libelle\"}}"; //$NON-NLS-1$
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(retour.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(PAD3205_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.isNull(), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PmCompositeService pmComposite = new PmCompositeService(_connector);
    JUnitTools.setInaccessibleFieldValue(_connector, "_pmCompositeService", pmComposite); //$NON-NLS-1$

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.pmCompositeModifierSurchargePriseClientPortPM(_tracabilite, "referencePmBytel", "referenceBoitierPm", "nomPanneau", "positionPortPM", "statutBlocage", "commentaireBlocage"); //$NON-NLS-1$ //$NON-NLS-2$ // $NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ // $NON-NLS-6$
    PowerMock.verifyAll();

    // Check results
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test OK for the method {@link IRES#pmCompositeModifierSurchargePriseClientPortPM}.
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void modifierSurchargePriseClientPortPM_OK_001() throws Exception
  {
    final Retour expectedRetour = RetourFactoryForTU.createOkRetour();

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    String result = "{\"retour\":{\"resultat\":\"OK\"}}"; //$NON-NLS-1$
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(result.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(PAD3205_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.isNull(), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PmCompositeService pmComposite = new PmCompositeService(_connector);
    JUnitTools.setInaccessibleFieldValue(_connector, "_pmCompositeService", pmComposite); //$NON-NLS-1$

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> resultResponse = _connector.pmCompositeModifierSurchargePriseClientPortPM(_tracabilite, "referencePmBytel", "referenceBoitierPm", "nomPanneau", "positionPortPM", "statutBlocage", "commentaireBlocage"); //$NON-NLS-1$ //$NON-NLS-2$ // $NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ // $NON-NLS-6$
    PowerMock.verifyAll();

    // Check header
    checkHeaders(_tracabilite, headersCapture);

    // Check params sent
    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_ACTION, "ModifierSurChargePriseClientPortPM"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, IRESConnector.REFERENCE_PM_BYTEL, "referencePmBytel"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, IRESConnector.REFERENCE_BOITIER_PM, "referenceBoitierPm"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, IRESConnector.NOM_PANNEAU, "nomPanneau"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, IRESConnector.POSITION_PORT_PM, "positionPortPM"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, IRESConnector.STATUT_BLOCAGE, "statutBlocage"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, IRESConnector.COMMENTAIRE_BLOCAGE, "commentaireBlocage"); //$NON-NLS-1$

    // Check results
    Assert.assertEquals(expectedRetour, resultResponse._first);
    Assert.assertNull(resultResponse._second);
  }

  /**
   * Check that all the necessary headers were captured.
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param headersCapture_p
   *          the {@link Capture} of the headers.
   */
  private void checkHeaders(Tracabilite tracabilite_p, Capture<MultivaluedMap<String, String>> headersCapture_p)
  {
    Assert.assertNotNull(headersCapture_p.getValue());
    Assert.assertNotNull(headersCapture_p.getValue().get(IHttpHeadersConsts.X_REQUEST_ID));
    Assert.assertEquals(tracabilite_p.getIdCorrelationByTel(), headersCapture_p.getValue().get(IHttpHeadersConsts.X_REQUEST_ID).get(0));
    Assert.assertNotNull(headersCapture_p.getValue().get(IHttpHeadersConsts.X_REQUEST_ID_SPIRIT));
    Assert.assertEquals(tracabilite_p.getIdCorrelationSpirit(), headersCapture_p.getValue().get(IHttpHeadersConsts.X_REQUEST_ID_SPIRIT).get(0));
    Assert.assertNotNull(headersCapture_p.getValue().get(IHttpHeadersConsts.X_SOURCE));
    Assert.assertEquals(tracabilite_p.getNomSysteme(), headersCapture_p.getValue().get(IHttpHeadersConsts.X_SOURCE).get(0));
    Assert.assertNotNull(headersCapture_p.getValue().get(IHttpHeadersConsts.X_PROCESS));
    Assert.assertEquals(tracabilite_p.getNomProcessus(), headersCapture_p.getValue().get(IHttpHeadersConsts.X_PROCESS).get(0));
    Assert.assertNotNull(headersCapture_p.getValue().get(IHttpHeadersConsts.X_PROCESS_ID_SPIRIT));
    Assert.assertEquals(tracabilite_p.getIdProcessusSpirit(), headersCapture_p.getValue().get(IHttpHeadersConsts.X_PROCESS_ID_SPIRIT).get(0));

    tracabilite_p.getRefFonc().forEach((key, value) -> Assert.assertEquals(value, headersCapture_p.getValue().get(IHttpHeadersConsts.X_TRACE.concat(key)).get(0)));
  }

  /**
   * Check the query params in rest send request method
   *
   * @param queryParams
   *          the actual query params
   * @param expected_p
   *          list of expected query params strings key1 value1 key2 value2...keyN valueN
   */
  private void checkQueryParams(Capture<Map<String, String>> queryParams, String... expected_p)
  {
    if (expected_p == null)
    {
      Assert.assertNull(queryParams.getValue());
    }
    else
    {
      Assert.assertEquals(0, expected_p.length % 2);
      for (int i = 0; i < expected_p.length; i = i + 2)
      {
        Assert.assertEquals(expected_p[i + 1], queryParams.getValue().get(expected_p[i]));
      }
    }
  }

  /**
   * prepare mock scenario to initialize method sendRequest from AbstractRestConnector
   *
   * @throws Exception
   *           on error.
   */
  private void initializeMocksForSendRequest() throws Exception
  {
    final String urlBalancedElementName = RandomStringUtils.randomAlphanumeric(45);
    final String urlBalancedElementDescription = RandomStringUtils.randomAlphabetic(9);

    EasyMock.expect(_loadBalancerMock.chooseBalancedElement()).andReturn(_urlBalancedElementMock);
    EasyMock.expect(_urlBalancedElementMock.getName()).andReturn(urlBalancedElementName);
    EasyMock.expect(_urlBalancedElementMock.getDescription()).andReturn(urlBalancedElementDescription);
    EasyMock.expect(_urlBalancedElementMock.getName()).andReturn(urlBalancedElementName);
    EasyMock.expect(_connectorPoolMock.get(urlBalancedElementName)).andReturn(_restConnectorPoolMock);
    EasyMock.expect(_restConnectorPoolMock.borrowObject()).andReturn(_restInstanceMock);
  }
}
