/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.res;

import org.easymock.EasyMock;
import org.easymock.EasyMockSupport;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockNice;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.utils.DateTimeTools;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.IActivityCaller;
import com.bytel.spirit.common.connectors.res.activities.RES2105_RechercherIntegrationGroupeFichiers;
import com.bytel.spirit.common.connectors.res.activities.RES2105_RechercherIntegrationGroupeFichiers.RES2105_RechercherIntegrationGroupeFichiersBuilder;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.IntegrationGroupeFichiers;
import com.bytel.spirit.common.shared.saab.res.response.IntegrationGroupeFichierResponse;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author dangelis
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({ RESProxy.class })
public class RES2105_RechercherIntegrationGroupeFichiers_Test extends EasyMockSupport
{
  /**
   *
   */
  private RES2105_RechercherIntegrationGroupeFichiers _activite;

  /**
   * Factory de génération des beans
   */
  private PodamFactory _podam = new PodamFactoryImpl();

  /**
   * Mock de {@link RESProxy}
   */
  @MockStrict
  RESProxy _resProxy;

  /**
   * Mock de {@link IActivityCaller}
   */
  @MockNice
  IActivityCaller _activityCallerMock;

  /**
   *
   */
  @Before
  public void beforeTest()
  {

    // désactivation du cache podam
    _podam.getStrategy().setMemoization(false);

    // on réinitialise tous les mocks afin de ne pas avoir d'interférence entre les tests
    PowerMock.resetAll();

    // On initialise toutes les classes à mocker comportant un appel à un eméthode statique
    // Dans notre cas on mock statiquemement toutes les classes des activités et des proxys appelés (pour les createContexte et le getInstance)
    PowerMock.mockStaticStrict(RES2105_RechercherIntegrationGroupeFichiers.class);
    PowerMock.mockStaticStrict(RESProxy.class);
  }

  /**
   * Incorrect builder
   */
  @Test
  public void test001()
  {
    _activite = new RES2105_RechercherIntegrationGroupeFichiersBuilder().build();
    Assert.assertEquals(StringConstants.NOK, _activite.getRetour().getResultat());
    Assert.assertEquals("CAT-3", _activite.getRetour().getCategorie()); //$NON-NLS-1$
    Assert.assertEquals("Parametre d'entree de l'activite non renseignee", _activite.getRetour().getLibelle()); //$NON-NLS-1$

  }

  /**
   * Incorrect builder
   */
  @Test
  public void test002()
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    _activite = new RES2105_RechercherIntegrationGroupeFichiersBuilder().tracabilite(tracabilite).build();
    Assert.assertEquals(StringConstants.NOK, _activite.getRetour().getResultat());
    Assert.assertEquals("CAT-3", _activite.getRetour().getCategorie()); //$NON-NLS-1$
    Assert.assertEquals("Parametre d'entree de l'activite non renseignee", _activite.getRetour().getLibelle()); //$NON-NLS-1$

  }

  /**
   * Incorrect builder
   */
  @Test
  public void test003()
  {
    _activite = new RES2105_RechercherIntegrationGroupeFichiersBuilder().nomGroupFichiers("Test").build(); //$NON-NLS-1$
    Assert.assertEquals(StringConstants.NOK, _activite.getRetour().getResultat());
    Assert.assertEquals("CAT-3", _activite.getRetour().getCategorie()); //$NON-NLS-1$
    Assert.assertEquals("Parametre d'entree de l'activite non renseignee", _activite.getRetour().getLibelle()); //$NON-NLS-1$

  }

  /**
   * Nominal OK
   *
   * @throws RavelException
   *           RavelException
   */
  @Test
  public void test004() throws RavelException
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    String json = "{\n\t\"retour\": {\n\t\t\"resultat\": \"OK\"\n\t},\n\t\"integrationGroupeFichier\": { \t\n\t\t\"nomGroupeFichier\": \"ELIG PREV\",\n\t\t\"dateIntegration\": \"2017-09-15T12:25:33\",\n\t\t\"cheminRepertoireArchive\": \"F:\\\\Backups\\\\MesFichiers\\\\Archives\",\n\t\t\"listeFichierIntegre\": [\n\t\t\t{\t\"idFichier\": \"COMMUNES\",\n\t\t\t\t\"date\": \"2017-09-14T12:25:33\",\n\t\t\t\t\"index\": 12,\n\t\t\t\t\"nbLigne\": 37256,\n\t\t\t\t\"nbLigneOK\": 37205\n\t\t\t},\n\t\t\t{\t\"idFichier\": \"COMMUNES_NOMS_ALT\",\n\t\t\t\t\"date\": \"2017-09-14T12:25:33\",\n\t\t\t\t\"index\": 12,\n\t\t\t\t\"nbLigne\": 18692,\n\t\t\t\t\"nbLigneOK\": 18692\n\t\t\t},\n\t\t\t{\t\"idFichier\": \"PREV_FTTH\",\n\t\t\t\t\"date\": \"2017-09-14T12:25:33\",\n\t\t\t\t\"index\": 12,\n\t\t\t\t\"nbLigne\": 12892,\n\t\t\t\t\"nbLigneOK\": 12892\n\t\t\t},\n\t\t\t{\t\"idFichier\": \"PREV_CROZON\",\n\t\t\t\t\"date\": \"2017-09-14T12:25:33\",\n\t\t\t\t\"index\": 12,\n\t\t\t\t\"nbLigne\": 25120,\n\t\t\t\t\"nbLigneOK\": 24358\n\t\t\t}\n\t\t]\n\t}\n}\n\n"; //$NON-NLS-1$
    IntegrationGroupeFichierResponse integrationReponse = GsonTools.getInstance(DateTimeTools.DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss).fromJson(json, IntegrationGroupeFichierResponse.class);
    Retour expectedRetour = RetourFactory.createOkRetour();
    ConnectorResponse<Retour, IntegrationGroupeFichierResponse> expectedResponse = new ConnectorResponse<Retour, IntegrationGroupeFichierResponse>(expectedRetour, integrationReponse);
    _activite = new RES2105_RechercherIntegrationGroupeFichiersBuilder().tracabilite(tracabilite).nomGroupFichiers("Test").build(); //$NON-NLS-1$
    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxy);
    EasyMock.expect(_resProxy.pad3003IntegrationGroupeFichierRead(tracabilite, "Test")).andReturn(expectedResponse); //$NON-NLS-1$
    PowerMock.replayAll();
    IntegrationGroupeFichiers result = _activite.execute(_activityCallerMock);
    PowerMock.verifyAll();
    Assert.assertEquals(expectedRetour, _activite.getRetour());
    Assert.assertEquals(result.getNomGroupeFichiers(), integrationReponse.getIntegration().getNomGroupeFichiers());
  }

  /**
   * @throws RavelException
   *           RavelException
   */
  @Test
  public void test005() throws RavelException
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    Retour expectedRetour = RetourFactory.createNOK("CAT-4", "DONNEE_INCONNUE", "Nom de groupe de fichiers ELIG PREV inconnu"); //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$
    ConnectorResponse<Retour, IntegrationGroupeFichierResponse> expectedResponse = new ConnectorResponse<Retour, IntegrationGroupeFichierResponse>(expectedRetour, null);
    _activite = new RES2105_RechercherIntegrationGroupeFichiersBuilder().tracabilite(tracabilite).nomGroupFichiers("ELIG PREV").build(); //$NON-NLS-1$
    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxy);
    EasyMock.expect(_resProxy.pad3003IntegrationGroupeFichierRead(tracabilite, "ELIG PREV")).andReturn(expectedResponse); //$NON-NLS-1$
    PowerMock.replayAll();
    IntegrationGroupeFichiers result = _activite.execute(_activityCallerMock);
    PowerMock.verifyAll();
    Assert.assertEquals(expectedRetour, _activite.getRetour());
    Assert.assertNull(result);
  }

}
