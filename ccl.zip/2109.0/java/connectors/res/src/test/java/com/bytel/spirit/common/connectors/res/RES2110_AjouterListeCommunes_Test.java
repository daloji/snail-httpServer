/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.res;

import java.util.ArrayList;

import org.easymock.EasyMock;
import org.easymock.EasyMockSupport;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockNice;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.utils.DateTimeTools;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.IActivityCaller;
import com.bytel.spirit.common.connectors.res.activities.RES2110_AjouterListeCommunes;
import com.bytel.spirit.common.connectors.res.activities.RES2110_AjouterListeCommunes.RES2110_AjouterListeCommunesBuilder;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.Commune;
import com.bytel.spirit.common.shared.saab.res.request.ListeCommuneRequest;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author dangelis
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({ RESProxy.class })
public class RES2110_AjouterListeCommunes_Test extends EasyMockSupport
{
  /**
   * activité testée
   */
  private RES2110_AjouterListeCommunes _activite;

  /**
   * Factory de génération des beans
   */
  private PodamFactory _podam = new PodamFactoryImpl();

  /**
   * Mock de {@link RESProxy}
   */
  @MockStrict
  RESProxy _resProxy;

  /**
   * Mock de {@link IActivityCaller}
   */
  @MockNice
  IActivityCaller _activityCallerMock;

  /**
   * Initialisation des tests
   */
  @Before
  public void beforeTest()
  {

    // désactivation du cache podam
    _podam.getStrategy().setMemoization(false);

    // on réinitialise tous les mocks afin de ne pas avoir d'interférence entre les tests
    PowerMock.resetAll();

    // On initialise toutes les classes à mocker comportant un appel à un eméthode statique
    // Dans notre cas on mock statiquemement toutes les classes des activités et des proxys appelés (pour les createContexte et le getInstance)
    PowerMock.mockStaticStrict(RES2110_AjouterListeCommunes.class);
    PowerMock.mockStaticStrict(RESProxy.class);
  }

  /**
   * builder incorrect
   *
   * @throws RavelException
   *           RavelException
   */
  @Test
  public void test001() throws RavelException
  {

    _activite = new RES2110_AjouterListeCommunesBuilder().build();
    Assert.assertEquals(StringConstants.NOK, _activite.getRetour().getResultat());
    Assert.assertEquals("CAT-3", _activite.getRetour().getCategorie()); //$NON-NLS-1$
    Assert.assertEquals("Parametre d'entree de l'activite non renseignee", _activite.getRetour().getLibelle()); //$NON-NLS-1$
  }

  /**
   * builder incorrect
   *
   * @throws RavelException
   *           RavelException
   */
  @Test
  public void test002() throws RavelException
  {
    _activite = new RES2110_AjouterListeCommunesBuilder().listeCommunes(new ArrayList<Commune>()).build();

    Assert.assertEquals(StringConstants.NOK, _activite.getRetour().getResultat());
    Assert.assertEquals("CAT-3", _activite.getRetour().getCategorie()); //$NON-NLS-1$
    Assert.assertEquals("Parametre d'entree de l'activite non renseignee", _activite.getRetour().getLibelle()); //$NON-NLS-1$
  }

  /**
   *
   * Nominal
   *
   * @throws RavelException
   *           RavelException
   */
  @Test
  public void test003() throws RavelException
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    Retour expectedRetour = RetourFactory.createOkRetour();
    ConnectorResponse<Retour, Boolean> expectedResponse = new ConnectorResponse<Retour, Boolean>(expectedRetour, true);
    String jsonList = "{\r\n\t  \"listeCommune\": [\r\n\t\t{ \t\"codeInsee\": \"10899\",\r\n\t\t\t\"nomCommune\": \"MaCommune1\",\r\n\t\t\t\"ancienCodeInsee\": \"10888\",\r\n\t\t\t\"listeCodePostal\": [\r\n\t\t\t\t\"59188\",\r\n\t\t\t\t\"59189\"\r\n\t\t\t],\r\n\t\t\t\"listeNomAlternatif\": [\r\n\t\t\t\t{\"provenance\": \"SNA\", \"nomCommune\": \"MaCom1\"},\r\n\t{\"provenance\": \"42R4\", \"nomCommune\": \"UneCommune\"}\r\n\t\t\t]\r\n\t\t},\r\n\t\t{ \t\"codeInsee\": \"10905\",\r\n\t\t\t\"nomCommune\": \"MaCommune2\",\r\n\t\t\t\"ancienCodeInsee\": \"10904\",\r\n\t\t\t\"listeCodePostal\": [\r\n\t\t\t\t\"62458\"\r\n\t\t\t]\r\n\t\t}\r\n\t  ]\r\n}\r\n"; //$NON-NLS-1$
    ListeCommuneRequest listRequest = GsonTools.getInstance(DateTimeTools.DateTimeFormatPattern.yyyy_dash_MM_dash_dd).fromJson(jsonList, ListeCommuneRequest.class);
    _activite = new RES2110_AjouterListeCommunesBuilder().tracabilite(tracabilite).listeCommunes(listRequest.getListeCommune()).build();
    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxy);
    EasyMock.expect(_resProxy.pad3001CommuneCreate(EasyMock.isA(Tracabilite.class), EasyMock.isA(ListeCommuneRequest.class))).andReturn(expectedResponse);
    PowerMock.replayAll();
    Retour reponse = _activite.execute(_activityCallerMock);
    PowerMock.verifyAll();
    Assert.assertEquals(expectedResponse._first, reponse);
  }

}
