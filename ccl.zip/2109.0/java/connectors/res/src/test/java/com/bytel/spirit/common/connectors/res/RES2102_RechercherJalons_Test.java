/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.res;

import java.util.List;

import org.easymock.EasyMock;
import org.easymock.EasyMockSupport;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockNice;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.DateTimeTools;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.IActivityCaller;
import com.bytel.spirit.common.connectors.res.activities.RES2102_RechercherJalons;
import com.bytel.spirit.common.connectors.res.activities.RES2102_RechercherJalons.RES2102_RechercherJalonsBuilder;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.Jalon;
import com.bytel.spirit.common.shared.saab.res.response.ListePrevisionResponse;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author dangelis
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({ RESProxy.class })
public class RES2102_RechercherJalons_Test extends EasyMockSupport
{
  /**
   * activité testée
   */
  private RES2102_RechercherJalons _activite;

  /**
   * Factory de génération des beans
   */
  private PodamFactory _podam = new PodamFactoryImpl();

  /**
   * Mock de {@link RESProxy}
   */
  @MockStrict
  RESProxy _resProxy;

  /**
   * Mock de {@link IActivityCaller}
   */
  @MockNice
  IActivityCaller _activityCallerMock;

  /**
   *
   */
  @Before
  public void beforeTest()
  {

    // désactivation du cache podam
    _podam.getStrategy().setMemoization(false);

    // on réinitialise tous les mocks afin de ne pas avoir d'interférence entre les tests
    PowerMock.resetAll();

    // On initialise toutes les classes à mocker comportant un appel à un eméthode statique
    // Dans notre cas on mock statiquemement toutes les classes des activités et des proxys appelés (pour les createContexte et le getInstance)
    PowerMock.mockStaticStrict(RES2102_RechercherJalons.class);
    PowerMock.mockStaticStrict(RESProxy.class);
  }

  /**
   * Nominal
   *
   * @throws RavelException
   *           RavelException
   */
  @Test
  public void test_004() throws RavelException
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    Retour expectedRetour = RetourFactory.createOkRetour();
    String jsonList = "{      \"retour\": {\n            \"resultat\": \"OK\"\n      },\n\n\"listePrevisionProgramme\": [\n\t\t{ \t\"codeInsee\": \"10899\",\n\t\t\t\"nomProgramme\": \"FTTH\",\n\t\t\t\"listeJalon\": [\n\t\t\t\t{\"nomJalon\":\"FTTH_DANS_LA_VILLE\", \"dateJalon\":\"2017-09-15\"}\n\t\t\t]\n\t\t},\n\t\t{ \t\"codeInsee\": \"10899\",\n\t\t\t\"nomProgramme\": \"CROZON\",\n\t\t\t\"listeJalon\": [\n\t\t\t\t{\t\"nomJalon\": \"SWAP\", \n\t\t\t\t\t\"dateJalon\": \"2017-09-15\"\n},\n\t\t\t\t{\t\"nomJalon\": \"SWAP_GABARISE\",\n\t\t\t\t\t\"dateJalon\": \"2017-09-16\"\n\t\t\t\t},\n\t\t\t\t{\t\"nomJalon\": \"BF1\",\n\t\t\t\t\t\"dateJalon\": \"2017-09-17\"\n\t\t\t\t},\n\t\t\t\t{\t\"nomJalon\": \"BF2\",\n\t\t\t\t\t\"dateJalon\": \"2017-09-18\"\n\t\t\t\t}\n\t\t\t]\n\t\t}\n\t]\n}\n"; //$NON-NLS-1$
    ListePrevisionResponse listReponse = GsonTools.getInstance(DateTimeTools.DateTimeFormatPattern.yyyy_dash_MM_dash_dd).fromJson(jsonList, ListePrevisionResponse.class);
    ConnectorResponse<Retour, ListePrevisionResponse> expectedResponse = new ConnectorResponse<Retour, ListePrevisionResponse>(expectedRetour, listReponse);
    _activite = new RES2102_RechercherJalonsBuilder().tracabilite(tracabilite).codeInsee("12345").nomProgramme("TRUC").build(); //$NON-NLS-1$//$NON-NLS-2$
    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxy);
    EasyMock.expect(_resProxy.pad3002PrevisionProgRead(tracabilite, "TRUC", "12345")).andReturn(expectedResponse); //$NON-NLS-1$//$NON-NLS-2$
    PowerMock.replayAll();
    List<Jalon> response = _activite.execute(_activityCallerMock);
    PowerMock.verifyAll();
    Assert.assertEquals(expectedResponse._first, _activite.getRetour());
    Assert.assertNotNull(response);
    Assert.assertEquals(response.size(), 5);
    Assert.assertEquals(response.get(0).getNomJalon(), "FTTH_DANS_LA_VILLE"); //$NON-NLS-1$
    Assert.assertEquals(response.get(0).getDateJalon().toString(), "2017-09-15T00:00"); //$NON-NLS-1$
    Assert.assertEquals(response.get(1).getNomJalon(), "SWAP"); //$NON-NLS-1$
    Assert.assertEquals(response.get(1).getDateJalon().toString(), "2017-09-15T00:00"); //$NON-NLS-1$
    Assert.assertEquals(response.get(2).getNomJalon(), "SWAP_GABARISE"); //$NON-NLS-1$
    Assert.assertEquals(response.get(2).getDateJalon().toString(), "2017-09-16T00:00"); //$NON-NLS-1$
    Assert.assertEquals(response.get(3).getNomJalon(), "BF1"); //$NON-NLS-1$
    Assert.assertEquals(response.get(3).getDateJalon().toString(), "2017-09-17T00:00"); //$NON-NLS-1$
    Assert.assertEquals(response.get(4).getNomJalon(), "BF2"); //$NON-NLS-1$
    Assert.assertEquals(response.get(4).getDateJalon().toString(), "2017-09-18T00:00"); //$NON-NLS-1$
  }

  /**
   * Code insee invalide
   *
   * @throws RavelException
   *           RavelException
   *
   */
  @Test
  public void test_005() throws RavelException
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    Retour expectedRetour = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ENTREE_INCORRECTE, "Code insee 123456 invalide"); //$NON-NLS-1$
    ConnectorResponse<Retour, Boolean> expectedResponse = new ConnectorResponse<Retour, Boolean>(expectedRetour, true);
    _activite = new RES2102_RechercherJalonsBuilder().tracabilite(tracabilite).codeInsee("123456").nomProgramme("CROZON").build(); //$NON-NLS-1$//$NON-NLS-2$
    List<Jalon> response = _activite.execute(_activityCallerMock);
    Assert.assertEquals(expectedResponse._first, _activite.getRetour());
    Assert.assertNull(response);

  }

  /**
   * Retour request avec codeInsee invalide
   *
   * @throws RavelException
   *           RavelException
   */
  @Test
  public void test_006() throws RavelException
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    Retour expectedRetour = RetourFactory.createNOK("CAT-4", "DONNEE_INVALIDE", "Code insee 10 invalide"); //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$
    ConnectorResponse<Retour, ListePrevisionResponse> expectedResponse = new ConnectorResponse<Retour, ListePrevisionResponse>(expectedRetour, null);
    _activite = new RES2102_RechercherJalonsBuilder().tracabilite(tracabilite).codeInsee("12345").nomProgramme("FTTH").build(); //$NON-NLS-1$//$NON-NLS-2$
    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxy);
    EasyMock.expect(_resProxy.pad3002PrevisionProgRead(tracabilite, "FTTH", "12345")).andReturn(expectedResponse); //$NON-NLS-1$ //$NON-NLS-2$
    PowerMock.replayAll();
    List<Jalon> response = _activite.execute(_activityCallerMock);
    PowerMock.verifyAll();
    Assert.assertEquals(expectedResponse._first, _activite.getRetour());
    Assert.assertEquals(response.size(), 0);
  }

  /**
   * Retour OK quand la retour du connecteur revient KO CAT-4 DONNEE_INCONNUE
   *
   * @throws RavelException
   *           RavelException
   */
  @Test
  public void test_007() throws RavelException
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    Retour expectedRetour = RetourFactory.createNOK("CAT-4", "DONNEE_INCONNUE", "Donnee inconnue"); //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$
    Retour expectedRetourOk = RetourFactory.createOkRetour();
    ConnectorResponse<Retour, ListePrevisionResponse> expectedResponse = new ConnectorResponse<Retour, ListePrevisionResponse>(expectedRetour, null);
    _activite = new RES2102_RechercherJalonsBuilder().tracabilite(tracabilite).codeInsee("12345").nomProgramme("FTTH").build(); //$NON-NLS-1$//$NON-NLS-2$
    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxy);
    EasyMock.expect(_resProxy.pad3002PrevisionProgRead(tracabilite, "FTTH", "12345")).andReturn(expectedResponse); //$NON-NLS-1$ //$NON-NLS-2$
    PowerMock.replayAll();
    List<Jalon> response = _activite.execute(_activityCallerMock);
    PowerMock.verifyAll();
    Assert.assertEquals(expectedRetourOk, _activite.getRetour());
    Assert.assertEquals(response.size(), 0);
  }

  /**
   * builder incorrect
   *
   * @throws RavelException
   *           RavelException
   */
  @Test
  public void test001() throws RavelException
  {

    _activite = new RES2102_RechercherJalonsBuilder().build();
    Assert.assertEquals(StringConstants.NOK, _activite.getRetour().getResultat());
    Assert.assertEquals("CAT-3", _activite.getRetour().getCategorie()); //$NON-NLS-1$
    Assert.assertEquals("Parametre d'entree de l'activite non renseignee", _activite.getRetour().getLibelle()); //$NON-NLS-1$
  }
}
