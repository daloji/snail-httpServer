/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.res.services;

import java.io.ByteArrayInputStream;
import java.time.Duration;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.cxf.jaxrs.impl.ResponseBuilderImpl;
import org.easymock.Capture;
import org.easymock.EasyMock;
import org.easymock.EasyMockSupport;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.modules.junit4.PowerMockRunner;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.conf.generated.Param;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.test.JUnitTools;
import com.bytel.ravel.common.test.podam.JavaTimeManufacturer;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.utils.RetourFactoryForTU;
import com.bytel.ravel.net.loadbalancing.ILoadBalancer;
import com.bytel.ravel.net.loadbalancing.URLBalancedElement;
import com.bytel.ravel.net.rest.RestConnectorPool;
import com.bytel.ravel.net.rest.RestInstance;
import com.bytel.ravel.services.conf.connector.generated.Connector;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.connectors.res.IRESConnector;
import com.bytel.spirit.common.connectors.res.RESConnector;
import com.bytel.spirit.common.connectors.res.RESConnectorTest;
import com.bytel.spirit.common.shared.functional.types.json.RavelJsonTools;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.ressources.BasicResponse;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.ressources.RetourConverter;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.CompteRenduSuppression;
import com.bytel.spirit.common.shared.saab.res.ListeTechnologieAutorisee;
import com.bytel.spirit.common.shared.saab.res.OltComposite;
import com.bytel.spirit.common.shared.saab.res.SurchargeCarte;
import com.bytel.spirit.common.shared.saab.res.SurchargeOLT;
import com.bytel.spirit.common.shared.saab.res.SurchargeOntId;
import com.bytel.spirit.common.shared.saab.res.SurchargePortPON;
import com.bytel.spirit.common.shared.saab.res.request.ManageOltCompositeRequest;
import com.bytel.spirit.common.shared.saab.res.response.GetOltCompositeResponse;
import com.bytel.spirit.common.shared.saab.res.response.GetSurchargeResponse;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 * @author jpais
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
public class OltCompositeServiceTest extends EasyMockSupport
{
  /** Param name for PAD3200 */
  private static final String PAD3200_PATH_PARAM = "/oltComposite/"; //$NON-NLS-1$

  /** Path for PAD3200 */
  private String _oltCompositeUrl;

  /** Factory to generate beans */
  private PodamFactory _podam = new PodamFactoryImpl();

  /** Connector to test */
  private RESConnector _connector;

  /** The traçability */
  private Tracabilite _tracabilite;

  /** Mock {@link ILoadBalancer} */
  @MockStrict
  ILoadBalancer<URLBalancedElement> _loadBalancerMock;

  /** Mock {@link URLBalancedElement} */
  @MockStrict
  URLBalancedElement _urlBalancedElementMock;

  /**
   * Mock of connectors pool HTTP
   */
  @MockStrict
  Hashtable<String, RestConnectorPool> _connectorPoolMock;

  /**
   * Mock {@link RestConnectorPool}
   */
  @MockStrict
  RestConnectorPool _restConnectorPoolMock;

  /**
   * Mock {@link RestInstance}
   */
  @MockStrict
  RestInstance _restInstanceMock;

  /**
   * Initialize before tests
   *
   * @throws Exception
   *           Thrown in case of error during switch in attributes of parent class
   */
  @Before
  public void beforeTest() throws Exception
  {
    _podam.getStrategy().setMemoization(false);
    _podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());
    JavaTimeManufacturer.registerPodamFactory(_podam);

    _connector = new RESConnector();

    _oltCompositeUrl = PAD3200_PATH_PARAM;
    _tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);

    JUnitTools.setInaccessibleFieldValue(_connector, "_loadBalancer", _loadBalancerMock); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_connectorPool", _connectorPoolMock); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_oltCompositeUrl", _oltCompositeUrl); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_oltCompositeService", new OltCompositeService(_connector)); //$NON-NLS-1$

    PowerMock.resetAll();
  }

  /**
   * @throws Exception
   *           Exception
   */
  @Test
  public void loadConnectorConfigurationTest() throws Exception
  {
    final Connector connector = new Connector();

    Param param = new Param();
    param.setName("PAD3200_PATH_PARAM"); //$NON-NLS-1$
    param.setValue(_oltCompositeUrl);
    connector.getParam().add(param);

    param = new Param();
    param.setName("AccesTechniqueCacheDuration"); //$NON-NLS-1$
    param.setValue("PT10M"); //$NON-NLS-1$
    connector.getParam().add(param);

    param = new Param();
    param.setName("AbaqueDSLCacheDuration"); //$NON-NLS-1$
    param.setValue("PT10M"); //$NON-NLS-1$
    connector.getParam().add(param);

    connector.setURLS(RESConnectorTest.generateURLS());

    // test
    _connector.loadConnectorConfiguration(connector);

    // assertions
    Assert.assertEquals(_oltCompositeUrl, JUnitTools.getInaccessibleFieldValue(_connector, "_oltCompositeUrl")); //$NON-NLS-1$
    Assert.assertNotNull(JUnitTools.getInaccessibleFieldValue(_connector, "_oltCompositeService")); //$NON-NLS-1$
    Assert.assertEquals(Duration.parse("PT10M"), JUnitTools.getInaccessibleFieldValue(_connector, "_accesTechniqueCacheDuration")); //$NON-NLS-1$ //$NON-NLS-2$
    Assert.assertEquals(Duration.parse("PT10M"), JUnitTools.getInaccessibleFieldValue(_connector, "_abaqueDslCacheDuration")); //$NON-NLS-1$ //$NON-NLS-2$

  }

  /**
   * Test KO for the method oltCompositeLireSurchage.
   *
   * {@link RESConnector#oltCompositeLireSurchage(Tracabilite, String, String, String, String, String)}
   *
   * expect resultat:NOK categorie:CAT-4 diagnostic:DONNEE_INVALIDE
   *
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public void oltCompositeLireSurchage_KO_001() throws Exception
  {
    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, ""); //$NON-NLS-1$
    final GetSurchargeResponse getOltCompositeResponse = new GetSurchargeResponse(RetourConverter.convertToJsonRetour(retour));

    final String partnerResponse = RavelJsonTools.getInstance().toJson(getOltCompositeResponse, GetSurchargeResponse.class);

    final Response response = new ResponseBuilderImpl().status(404).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    // test scenario
    OltCompositeService oltComposite = new OltCompositeService(_connector);
    JUnitTools.setInaccessibleFieldValue(_connector, "_oltCompositeService", oltComposite); //$NON-NLS-1$
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(PAD3200_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);

    _restConnectorPoolMock.returnObject(_restInstanceMock);
    PowerMock.replayAll();
    final ConnectorResponse<Retour, GetSurchargeResponse> resultResponse = _connector.oltCompositeLireSurchage(_tracabilite, null, null, null, null, null);
    PowerMock.verifyAll();
    checkHeader(_tracabilite, headersCapture);
    Retour retourExpect = RetourFactoryForTU.createNOK("CAT-4", "DONNEE_INCONNUE", ""); //$NON-NLS-1$ //$NON-NLS-2$//$NON-NLS-3$
    Assert.assertNotNull(resultResponse);
    Assert.assertNotNull(resultResponse._first);
    Assert.assertEquals(retourExpect, resultResponse._first);
    Assert.assertNotNull(resultResponse._second);

  }

  /**
   * Test OK for the method oltCompositeLireSurchage.
   *
   * {@link RESConnector#oltCompositeLireSurchage(Tracabilite, String, String, String, String, String)}
   *
   * expect resultat: OK Reponse of List<Olt>
   *
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public void oltCompositeLireSurchage_OK_001() throws Exception
  {

    Retour retour = RetourFactoryForTU.createOkRetour();
    String nomOlt = "nomOLT"; //$NON-NLS-1$
    String action = "action"; //$NON-NLS-1$
    String positionCarte = "positionCarte"; //$NON-NLS-1$
    String positionPortPon = "positionPortPon"; //$NON-NLS-1$
    String positionOntId = "positionOntId"; //$NON-NLS-1$
    // Retour OK

    GetSurchargeResponse getoltSurchage = new GetSurchargeResponse(RetourConverter.convertToJsonRetour(retour));
    getoltSurchage.setSurchargeCarte(_podam.manufacturePojoWithFullData(SurchargeCarte.class));
    getoltSurchage.setSurchargeOLT(_podam.manufacturePojoWithFullData(SurchargeOLT.class));
    getoltSurchage.setSurchargeOntId(_podam.manufacturePojoWithFullData(SurchargeOntId.class));
    getoltSurchage.setSurchargePortPon(_podam.manufacturePojoWithFullData(SurchargePortPON.class));

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    final String oltListResponse = RavelJsonTools.getInstance().toJson(getoltSurchage, GetSurchargeResponse.class);
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(oltListResponse.getBytes())).build();

    OltCompositeService oltComposite = new OltCompositeService(_connector);
    JUnitTools.setInaccessibleFieldValue(_connector, "_oltCompositeService", oltComposite); //$NON-NLS-1$
    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(PAD3200_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);

    _restConnectorPoolMock.returnObject(_restInstanceMock);
    PowerMock.replayAll();
    final ConnectorResponse<Retour, GetSurchargeResponse> resultResponse = _connector.oltCompositeLireSurchage(_tracabilite, nomOlt, action, positionCarte, positionPortPon, positionOntId);
    PowerMock.verifyAll();
    checkHeader(_tracabilite, headersCapture);
    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_ACTION, action);
    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_NOM_OLT, nomOlt);
    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_POSITION_CARTE, positionCarte);
    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_POSITION_PORT_PON, positionPortPon);
    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_POSITION_ONT_ID, positionOntId);

    Assert.assertNotNull(resultResponse);
    Assert.assertNotNull(resultResponse._first);
    Assert.assertEquals(RetourFactoryForTU.createOkRetour(), resultResponse._first);
    Assert.assertNotNull(resultResponse._second);

  }

  /**
   * Test Exception for the method oltCompositeLireUn.
   *
   * {@link RESConnector#oltCompositeLireUn(Tracabilite, String)}
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public void oltCompositeLireUn_Exception() throws Exception
  {

    final OltComposite oltcomposite = new OltComposite("nomOLT", "nomNR", "constructeur", "modele", "statutTechnique"); //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
    oltcomposite.setIp("ip"); //$NON-NLS-1$

    final Retour retour = RetourFactoryForTU.createOkRetour();
    final GetOltCompositeResponse getOltCompositeResponse = new GetOltCompositeResponse(RetourConverter.convertToJsonRetour(retour), oltcomposite);

    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream("".getBytes())).build(); //$NON-NLS-1$

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    // test scenario
    OltCompositeService oltComposite = new OltCompositeService(_connector);
    JUnitTools.setInaccessibleFieldValue(_connector, "_oltCompositeService", oltComposite); //$NON-NLS-1$
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(PAD3200_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);

    _restConnectorPoolMock.returnObject(_restInstanceMock);
    PowerMock.replayAll();
    try
    {
      _connector.oltCompositeLireUn(_tracabilite, "nomOlt_p"); //$NON-NLS-1$
    }
    catch (RavelException e)
    {
      Assert.assertEquals(ExceptionType.UNEXPECTED, e.getExceptionType());
      Assert.assertEquals(ErrorCode.CNCTOR_00010, e.getErrorCode());
      Assert.assertEquals("Impossible de récupérer la réponse", e.getMessage()); //$NON-NLS-1$
    }

  }

  /**
   * Test KO for the method oltCompositeLireUn.
   *
   * {@link RESConnector#oltCompositeLireUn(Tracabilite, String)}
   *
   * expect resultat:NOK categorie:CAT-4 diagnostic:DONNEE_INVALIDE
   *
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public void oltCompositeLireUn_KO_001() throws Exception
  {

    final OltComposite oltcomposite = null;

    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, ""); //$NON-NLS-1$
    final GetOltCompositeResponse getOltCompositeResponse = new GetOltCompositeResponse(RetourConverter.convertToJsonRetour(retour), oltcomposite);

    final String partnerResponse = RavelJsonTools.getInstance().toJson(getOltCompositeResponse, GetOltCompositeResponse.class);

    final Response response = new ResponseBuilderImpl().status(404).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    // test scenario
    OltCompositeService oltComposite = new OltCompositeService(_connector);
    JUnitTools.setInaccessibleFieldValue(_connector, "_oltCompositeService", oltComposite); //$NON-NLS-1$
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(PAD3200_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);

    _restConnectorPoolMock.returnObject(_restInstanceMock);
    PowerMock.replayAll();
    final ConnectorResponse<Retour, OltComposite> resultResponse = _connector.oltCompositeLireUn(_tracabilite, "nomOlt_p"); //$NON-NLS-1$
    PowerMock.verifyAll();
    checkHeader(_tracabilite, headersCapture);
    Retour retourExpect = RetourFactoryForTU.createNOK("CAT-4", "DONNEE_INCONNUE", ""); //$NON-NLS-1$ //$NON-NLS-2$//$NON-NLS-3$
    Assert.assertNotNull(resultResponse);
    Assert.assertNotNull(resultResponse._first);
    Assert.assertEquals(retourExpect, resultResponse._first);
    Assert.assertNull(resultResponse._second);

  }

  /**
   * Test OK for the method oltCompositeLireUn.
   *
   * {@link RESConnector#oltCompositeLireUn(Tracabilite, String)}
   *
   * expect resultat:OK Reponse not null
   *
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public void oltCompositeLireUn_OK_001() throws Exception
  {

    final Retour retour = RetourFactoryForTU.createOkRetour();
    final GetOltCompositeResponse getOltCompositeResponse = new GetOltCompositeResponse(RetourConverter.convertToJsonRetour(retour));
    getOltCompositeResponse.setOltComposite(_podam.manufacturePojoWithFullData(OltComposite.class));
    final String partnerResponse = RavelJsonTools.getInstance().toJson(getOltCompositeResponse, GetOltCompositeResponse.class);

    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    // test scenario
    OltCompositeService oltComposite = new OltCompositeService(_connector);
    JUnitTools.setInaccessibleFieldValue(_connector, "_oltCompositeService", oltComposite); //$NON-NLS-1$
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(PAD3200_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);

    _restConnectorPoolMock.returnObject(_restInstanceMock);
    PowerMock.replayAll();
    final ConnectorResponse<Retour, OltComposite> resultResponse = _connector.oltCompositeLireUn(_tracabilite, "nomOlt_p"); //$NON-NLS-1$
    PowerMock.verifyAll();
    checkHeader(_tracabilite, headersCapture);
    //check params sent
    checkQueryParams(queryParamsCapture, "nomOLT", "nomOlt_p"); //$NON-NLS-1$ //$NON-NLS-2$
    Assert.assertNotNull(resultResponse);
    Assert.assertNotNull(resultResponse._first);
    Assert.assertEquals(RetourFactoryForTU.createOkRetour(), resultResponse._first);
    Assert.assertNotNull(resultResponse._second);

  }

  /**
   * Test KO for the method oltCompositemodifierSurchargeDateDebutQuarantaineOLT.
   *
   * {@link RESConnector#oltCompositemodifierSurchargeDateDebutQuarantaineOLT(Tracabilite, ListeTechnologieAutorisee, String)}
   *
   * expect resultat:NOK categorie:CAT-4 diagnostic:DONNEE_INVALIDE
   *
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public void oltModifierSurchargeDateDebutQuarantaineOLT_KO_001() throws Exception
  {
    final Retour retourKO = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, ""); //$NON-NLS-1$
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retourKO));
    final String partnerResponse = RavelJsonTools.getInstance().toJson(basicResponse, BasicResponse.class);
    final Response response = new ResponseBuilderImpl().status(404).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    // test scenario
    OltCompositeService oltComposite = new OltCompositeService(_connector);
    JUnitTools.setInaccessibleFieldValue(_connector, "_oltCompositeService", oltComposite); //$NON-NLS-1$
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(PAD3200_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response);

    _restConnectorPoolMock.returnObject(_restInstanceMock);
    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> resultResponse = _connector.oltCompositemodifierSurchargeDateDebutQuarantaineOLT(_tracabilite, null, "yrd"); //$NON-NLS-1$
    PowerMock.verifyAll();

    checkHeader(_tracabilite, headersCapture);
    Assert.assertNotNull(resultResponse);
    Assert.assertNotNull(resultResponse._first);
    Assert.assertEquals(retourKO, resultResponse._first);
    Assert.assertNull(resultResponse._second);

  }

  /**
   * Test OK for the method oltCompositemodifierSurchargeDateDebutQuarantaineOLT.
   *
   * {@link RESConnector#oltCompositemodifierSurchargeDateDebutQuarantaineOLT(Tracabilite, ListeTechnologieAutorisee, String)}
   *
   * expect resultat:OK Reponse not null
   *
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public void oltModifierSurchargeDateDebutQuarantaineOLT_OK_001() throws Exception
  {

    final Retour retour = RetourFactoryForTU.createOkRetour();
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = RavelJsonTools.getInstance().toJson(basicResponse, BasicResponse.class);

    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    // test scenario
    OltCompositeService oltComposite = new OltCompositeService(_connector);
    JUnitTools.setInaccessibleFieldValue(_connector, "_oltCompositeService", oltComposite); //$NON-NLS-1$
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(PAD3200_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.isNull(), EasyMock.capture(queryParamsCapture))).andReturn(response);

    _restConnectorPoolMock.returnObject(_restInstanceMock);
    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> resultResponse = _connector.oltCompositemodifierSurchargeDateDebutQuarantaineOLT(_tracabilite, null, "nomOlt_p"); //$NON-NLS-1$
    PowerMock.verifyAll();
    checkHeader(_tracabilite, headersCapture);
    //check params sent
    checkQueryParams(queryParamsCapture, //
        "nomOLT", "nomOlt_p", // //$NON-NLS-1$ //$NON-NLS-2$
        IRESConnector.PARAM_ACTION, OltCompositeService.IAction.MODIFIER_SURCHARGE_DATE_DEBUT_QUARANTAINE_OLT);

    Assert.assertNotNull(resultResponse);
    Assert.assertNotNull(resultResponse._first);
    Assert.assertEquals(retour, resultResponse._first);
    Assert.assertNull(resultResponse._second);
  }

  /**
   * Test the method
   * {@link RESConnector#oltCompositeModifierSurchargeDebitGarantiPortPon(Tracabilite, String, String, String, String)}
   * httpStatus 404 Retour KO
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void oltModifierSurchargeDebitGarantiPortPon_KO_001() throws Exception
  {

    final Retour retourKO = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "erreur"); //$NON-NLS-1$
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retourKO));
    final String partnerResponse = RavelJsonTools.getInstance().toJson(basicResponse, BasicResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();
    //construct response
    final Response response = new ResponseBuilderImpl().status(404).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();
    String nomOlt = "nomOlt"; //$NON-NLS-1$
    String positionCarte = "positionCarte"; //$NON-NLS-1$
    String positionPortPon = "positionPortPon"; //$NON-NLS-1$
    String debitGarantieCapaciteAllouee = "debitGarantieCapaciteAllouee"; //$NON-NLS-1$
    // test scenario
    OltCompositeService oltService = new OltCompositeService(_connector);
    JUnitTools.setInaccessibleFieldValue(_connector, "_oltCompositeService", oltService); //$NON-NLS-1$
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_oltCompositeUrl), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.oltCompositeModifierSurchargeDebitGarantiPortPon(_tracabilite, nomOlt, positionCarte, positionPortPon, debitGarantieCapaciteAllouee);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_ACTION, OltCompositeService.IAction.MODIFIER_SURCHARGE_DEBIT_GARANTI_PORT_PON);
    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_NOM_OLT, "nomOlt"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_POSITION_CARTE, "positionCarte"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_POSITION_PORT_PON, "positionPortPon"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_DEBIT_GARANTI_ALLOUE, "debitGarantieCapaciteAllouee"); //$NON-NLS-1$

    Assert.assertEquals(retourKO, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method
   * {@link RESConnector#oltCompositeModifierSurchargeDebitGarantiPortPon(Tracabilite, String, String, String, String)}
   * httpStatus Retour OK
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void oltModifierSurchargeDebitGarantiPortPon_OK_001() throws Exception
  {

    final Retour retourOK = RetourFactoryForTU.createOkRetour();
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retourOK));
    final String partnerResponse = RavelJsonTools.getInstance().toJson(basicResponse, BasicResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(404).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();
    String nomOlt = "nomOlt"; //$NON-NLS-1$
    String positionCarte = "positionCarte"; //$NON-NLS-1$
    String positionPortPon = "positionPortPon"; //$NON-NLS-1$
    String debitGarantieCapaciteAllouee = "debitGarantieCapaciteAllouee"; //$NON-NLS-1$
    // test scenario
    OltCompositeService oltService = new OltCompositeService(_connector);
    JUnitTools.setInaccessibleFieldValue(_connector, "_oltCompositeService", oltService); //$NON-NLS-1$
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_oltCompositeUrl), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.oltCompositeModifierSurchargeDebitGarantiPortPon(_tracabilite, nomOlt, positionCarte, positionPortPon, debitGarantieCapaciteAllouee);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_ACTION, OltCompositeService.IAction.MODIFIER_SURCHARGE_DEBIT_GARANTI_PORT_PON);
    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_NOM_OLT, "nomOlt"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_POSITION_CARTE, "positionCarte"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_POSITION_PORT_PON, "positionPortPon"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_DEBIT_GARANTI_ALLOUE, "debitGarantieCapaciteAllouee"); //$NON-NLS-1$

    Assert.assertEquals(retourOK, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method
   * {@link RESConnector#oltCompositeModifierSurchargeExploitationOntId(Tracabilite, String, String, String, String, String, String)}
   * httpStatus Retour OK
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test

  public void oltModifierSurchargeExploitationOntId_KO() throws Exception
  {

    final Retour retourKO = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "erreur"); //$NON-NLS-1$
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retourKO));
    final String partnerResponse = RavelJsonTools.getInstance().toJson(basicResponse, BasicResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();
    //construct response
    final Response response = new ResponseBuilderImpl().status(404).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();
    String nomOlt = "nomOlt"; //$NON-NLS-1$
    String positionCarte = "positionCarte"; //$NON-NLS-1$
    String positionPortPon = "positionPortPon"; //$NON-NLS-1$
    String positionOntId = "positionOntId"; //$NON-NLS-1$
    String statutExploitation = "statutExploitation"; //$NON-NLS-1$
    String commentaireExploitation = "commentaireExploitation"; //$NON-NLS-1$
    // test scenario
    OltCompositeService oltService = new OltCompositeService(_connector);
    JUnitTools.setInaccessibleFieldValue(_connector, "_oltCompositeService", oltService); //$NON-NLS-1$
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_oltCompositeUrl), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.oltCompositeModifierSurchargeExploitationOntId(_tracabilite, nomOlt, positionCarte, positionPortPon, positionOntId, statutExploitation, commentaireExploitation);

    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_ACTION, OltCompositeService.IAction.MODIFIER_SURCHARGE_EXPLOITATION_ONT_ID);
    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_NOM_OLT, "nomOlt"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_POSITION_CARTE, "positionCarte"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_POSITION_PORT_PON, "positionPortPon"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_POSITION_ONT_ID, "positionOntId"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, IRESConnector.STATUT_EXPLOITATION, "statutExploitation"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, IRESConnector.COMMENTAIRE_EXPLOITATION, "commentaireExploitation"); //$NON-NLS-1$

    Assert.assertEquals(retourKO, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method
   * {@link RESConnector#oltCompositeModifierSurchargeExploitationOntId(Tracabilite, String, String, String, String, String, String)}
   * httpStatus Retour OK
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test

  public void oltModifierSurchargeExploitationOntId_OK_001() throws Exception
  {

    final Retour retourOK = RetourFactoryForTU.createOkRetour();
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retourOK));
    final String partnerResponse = RavelJsonTools.getInstance().toJson(basicResponse, BasicResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();
    //construct response
    final Response response = new ResponseBuilderImpl().status(202).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();
    String nomOlt = "nomOlt"; //$NON-NLS-1$
    String positionCarte = "positionCarte"; //$NON-NLS-1$
    String positionPortPon = "positionPortPon"; //$NON-NLS-1$
    String positionOntId = "positionOntId"; //$NON-NLS-1$
    String statutExploitation = "statutExploitation"; //$NON-NLS-1$
    String commentaireExploitation = "commentaireExploitation"; //$NON-NLS-1$
    // test scenario
    OltCompositeService oltService = new OltCompositeService(_connector);
    JUnitTools.setInaccessibleFieldValue(_connector, "_oltCompositeService", oltService); //$NON-NLS-1$
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_oltCompositeUrl), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.oltCompositeModifierSurchargeExploitationOntId(_tracabilite, nomOlt, positionCarte, positionPortPon, positionOntId, statutExploitation, commentaireExploitation);

    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_ACTION, OltCompositeService.IAction.MODIFIER_SURCHARGE_EXPLOITATION_ONT_ID);
    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_NOM_OLT, "nomOlt"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_POSITION_CARTE, "positionCarte"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_POSITION_PORT_PON, "positionPortPon"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_POSITION_ONT_ID, "positionOntId"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, IRESConnector.STATUT_EXPLOITATION, "statutExploitation"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, IRESConnector.COMMENTAIRE_EXPLOITATION, "commentaireExploitation"); //$NON-NLS-1$

    Assert.assertEquals(retourOK, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method
   * {@link RESConnector#oltCompositeModifierSurchargePriseClientCarte(Tracabilite, String, String, String, String)}
   * httpStatus Retour OK
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void oltModifierSurchargePriseClientCarte_KO() throws Exception
  {

    final Retour retourKO = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "erreur"); //$NON-NLS-1$
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retourKO));
    final String partnerResponse = RavelJsonTools.getInstance().toJson(basicResponse, BasicResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(404).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();
    String nomOlt = "nomOlt"; //$NON-NLS-1$
    String positionCarte = "positionCarte"; //$NON-NLS-1$
    String statutBlocage = "statutBlocage"; //$NON-NLS-1$
    String commentaireBlocage = "commentaireBlocage"; //$NON-NLS-1$
    // test scenario
    OltCompositeService oltService = new OltCompositeService(_connector);
    JUnitTools.setInaccessibleFieldValue(_connector, "_oltCompositeService", oltService); //$NON-NLS-1$
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_oltCompositeUrl), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.oltCompositeModifierSurchargePriseClientCarte(_tracabilite, nomOlt, positionCarte, statutBlocage, commentaireBlocage);

    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_ACTION, OltCompositeService.IAction.MODIFIER_SURCHARGE_OLT_PRISE_CLIENT_CARTE);
    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_NOM_OLT, "nomOlt"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_POSITION_CARTE, "positionCarte"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, IRESConnector.STATUT_BLOCAGE, "statutBlocage"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, IRESConnector.COMMENTAIRE_BLOCAGE, "commentaireBlocage"); //$NON-NLS-1$

    Assert.assertEquals(retourKO, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method
   * {@link RESConnector#oltCompositeModifierSurchargePriseClientCarte(Tracabilite, String, String, String, String)}
   * httpStatus Retour OK
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void oltModifierSurchargePriseClientCarte_OK() throws Exception
  {

    final Retour retourOK = RetourFactoryForTU.createOkRetour();
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retourOK));
    final String partnerResponse = RavelJsonTools.getInstance().toJson(basicResponse, BasicResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(404).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();
    String nomOlt = "nomOlt"; //$NON-NLS-1$
    String positionCarte = "positionCarte"; //$NON-NLS-1$
    String statutBlocage = "statutBlocage"; //$NON-NLS-1$
    String commentaireBlocage = "commentaireBlocage"; //$NON-NLS-1$
    // test scenario
    OltCompositeService oltService = new OltCompositeService(_connector);
    JUnitTools.setInaccessibleFieldValue(_connector, "_oltCompositeService", oltService); //$NON-NLS-1$
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_oltCompositeUrl), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.oltCompositeModifierSurchargePriseClientCarte(_tracabilite, nomOlt, positionCarte, statutBlocage, commentaireBlocage);

    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_ACTION, OltCompositeService.IAction.MODIFIER_SURCHARGE_OLT_PRISE_CLIENT_CARTE);
    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_NOM_OLT, "nomOlt"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_POSITION_CARTE, "positionCarte"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, IRESConnector.STATUT_BLOCAGE, "statutBlocage"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, IRESConnector.COMMENTAIRE_BLOCAGE, "commentaireBlocage"); //$NON-NLS-1$

    Assert.assertEquals(retourOK, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method
   * {@link RESConnector#oltCompositeModifierSurchargePriseClientOLT(Tracabilite, String, String, String)} httpStatus
   * Retour OK
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void oltModifierSurchargePriseClientOLT_KO() throws Exception
  {

    final Retour retourKO = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "erreur"); //$NON-NLS-1$
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retourKO));
    final String partnerResponse = RavelJsonTools.getInstance().toJson(basicResponse, BasicResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(202).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();
    String nomOlt = "nomOlt"; //$NON-NLS-1$
    String statutBlocage = "statutBlocage"; //$NON-NLS-1$
    String commentaireBlocage = "commentaireBlocage"; //$NON-NLS-1$
    // test scenario
    OltCompositeService oltService = new OltCompositeService(_connector);
    JUnitTools.setInaccessibleFieldValue(_connector, "_oltCompositeService", oltService); //$NON-NLS-1$
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_oltCompositeUrl), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.oltCompositeModifierSurchargePriseClientOLT(_tracabilite, nomOlt, statutBlocage, commentaireBlocage);

    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_ACTION, OltCompositeService.IAction.MODIFIER_SURCHARGE_PRISE_CLIENT_OLT);
    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_NOM_OLT, "nomOlt"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, IRESConnector.STATUT_BLOCAGE, "statutBlocage"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, IRESConnector.COMMENTAIRE_BLOCAGE, "commentaireBlocage"); //$NON-NLS-1$

    Assert.assertEquals(retourKO, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method
   * {@link RESConnector#oltCompositeModifierSurchargePriseClientOLT(Tracabilite, String, String, String)} httpStatus
   * Retour OK
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test

  public void oltModifierSurchargePriseClientOLT_OK() throws Exception
  {

    final Retour retourOK = RetourFactoryForTU.createOkRetour();
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retourOK));
    final String partnerResponse = RavelJsonTools.getInstance().toJson(basicResponse, BasicResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();
    //construct response
    final Response response = new ResponseBuilderImpl().status(202).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();
    String nomOlt = "nomOlt"; //$NON-NLS-1$
    String statutBlocage = "statutBlocage"; //$NON-NLS-1$
    String commentaireBlocage = "commentaireBlocage"; //$NON-NLS-1$
    // test scenario
    OltCompositeService oltService = new OltCompositeService(_connector);
    JUnitTools.setInaccessibleFieldValue(_connector, "_oltCompositeService", oltService); //$NON-NLS-1$
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_oltCompositeUrl), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.oltCompositeModifierSurchargePriseClientOLT(_tracabilite, nomOlt, statutBlocage, commentaireBlocage);

    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_ACTION, OltCompositeService.IAction.MODIFIER_SURCHARGE_PRISE_CLIENT_OLT);
    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_NOM_OLT, "nomOlt"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, IRESConnector.STATUT_BLOCAGE, "statutBlocage"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, IRESConnector.COMMENTAIRE_BLOCAGE, "commentaireBlocage"); //$NON-NLS-1$

    Assert.assertEquals(retourOK, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method
   * {@link RESConnector#oltCompositeModifierSurchargePriseClientOntId(Tracabilite, String, String, String, String, String, String)}
   * httpStatus 404 Retour KO
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void oltModifierSurchargePriseClientOntId_KO_001() throws Exception
  {

    final Retour retourKO = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "erreur"); //$NON-NLS-1$
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retourKO));
    final String partnerResponse = RavelJsonTools.getInstance().toJson(basicResponse, BasicResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(404).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();
    String nomOlt = "nomOlt"; //$NON-NLS-1$
    String positionCarte = "positionCarte"; //$NON-NLS-1$
    String positionPortPon = "positionPortPon"; //$NON-NLS-1$
    String positionOntId = "positionOntId"; //$NON-NLS-1$
    String statutBlocage = "statutBlocage"; //$NON-NLS-1$
    String commentaireBlocage = "commentaireBlocage"; //$NON-NLS-1$
    // test scenario
    OltCompositeService oltService = new OltCompositeService(_connector);
    JUnitTools.setInaccessibleFieldValue(_connector, "_oltCompositeService", oltService); //$NON-NLS-1$
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_oltCompositeUrl), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.oltCompositeModifierSurchargePriseClientOntId(_tracabilite, nomOlt, positionCarte, positionPortPon, positionOntId, statutBlocage, commentaireBlocage);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_ACTION, OltCompositeService.IAction.MODIFIER_SURCHAGE_PRISE_CLIENT_ONT_ID);
    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_NOM_OLT, "nomOlt"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_POSITION_CARTE, "positionCarte"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_POSITION_PORT_PON, "positionPortPon"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_POSITION_ONT_ID, "positionOntId"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, IRESConnector.STATUT_BLOCAGE, "statutBlocage"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, IRESConnector.COMMENTAIRE_BLOCAGE, "commentaireBlocage"); //$NON-NLS-1$

    Assert.assertEquals(retourKO, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method
   * {@link RESConnector#oltCompositeModifierSurchargePriseClientOntId(Tracabilite, String, String, String, String, String, String)}
   * httpStatus Retour OK
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void oltModifierSurchargePriseClientOntId_OK_001() throws Exception
  {

    final Retour retourOK = RetourFactoryForTU.createOkRetour();
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retourOK));
    final String partnerResponse = RavelJsonTools.getInstance().toJson(basicResponse, BasicResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();
    String nomOlt = "nomOlt"; //$NON-NLS-1$
    String positionCarte = "positionCarte"; //$NON-NLS-1$
    String positionPortPon = "positionPortPon"; //$NON-NLS-1$
    String statutBlocage = "statutBlocage"; //$NON-NLS-1$
    String positionOntId = "positionOntId"; //$NON-NLS-1$
    String commentaireBlocage = "commentaireBlocage"; //$NON-NLS-1$

    // test scenario
    OltCompositeService oltService = new OltCompositeService(_connector);
    JUnitTools.setInaccessibleFieldValue(_connector, "_oltCompositeService", oltService); //$NON-NLS-1$
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_oltCompositeUrl), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.oltCompositeModifierSurchargePriseClientOntId(_tracabilite, nomOlt, positionCarte, positionPortPon, positionOntId, statutBlocage, commentaireBlocage);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_ACTION, OltCompositeService.IAction.MODIFIER_SURCHAGE_PRISE_CLIENT_ONT_ID);
    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_NOM_OLT, "nomOlt"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_POSITION_CARTE, "positionCarte"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_POSITION_PORT_PON, "positionPortPon"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_POSITION_ONT_ID, "positionOntId"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, IRESConnector.STATUT_BLOCAGE, "statutBlocage"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, IRESConnector.COMMENTAIRE_BLOCAGE, "commentaireBlocage"); //$NON-NLS-1$

    Assert.assertEquals(retourOK, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method
   * {@link RESConnector#oltCompositeModifierSurchargePriseClientPortPon(Tracabilite, String, String, String, String, String)}
   * httpStatus 404 Retour KO
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void oltModifierSurchargePriseClientPortPon_KO_001() throws Exception
  {

    final Retour retourKO = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "erreur"); //$NON-NLS-1$
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retourKO));
    final String partnerResponse = RavelJsonTools.getInstance().toJson(basicResponse, BasicResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(404).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();
    String nomOlt = "nomOlt"; //$NON-NLS-1$
    String positionCarte = "positionCarte"; //$NON-NLS-1$
    String positionPortPon = "positionPortPon"; //$NON-NLS-1$
    String statutBlocage = "statutBlocage"; //$NON-NLS-1$
    String commentaireBlocage = "commentaireBlocage"; //$NON-NLS-1$

    // test scenario
    OltCompositeService oltService = new OltCompositeService(_connector);
    JUnitTools.setInaccessibleFieldValue(_connector, "_oltCompositeService", oltService); //$NON-NLS-1$
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_oltCompositeUrl), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.oltCompositeModifierSurchargePriseClientPortPon(_tracabilite, nomOlt, positionCarte, positionPortPon, statutBlocage, commentaireBlocage);

    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_ACTION, OltCompositeService.IAction.MODIFIER_SURCHARGE_PRISE_CLIENT_PORT_PON);
    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_NOM_OLT, "nomOlt"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_POSITION_CARTE, "positionCarte"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_POSITION_PORT_PON, "positionPortPon"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, IRESConnector.STATUT_BLOCAGE, "statutBlocage"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, IRESConnector.COMMENTAIRE_BLOCAGE, "commentaireBlocage"); //$NON-NLS-1$

    Assert.assertEquals(retourKO, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method
   * {@link RESConnector#oltCompositeModifierSurchargePriseClientPortPon(Tracabilite, String, String, String, String, String)}
   * httpStatus 404 Retour KO
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void oltModifierSurchargePriseClientPortPon_OK() throws Exception
  {

    final Retour retourOK = RetourFactoryForTU.createOkRetour();
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retourOK));
    final String partnerResponse = RavelJsonTools.getInstance().toJson(basicResponse, BasicResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(404).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();
    String nomOlt = "nomOlt"; //$NON-NLS-1$
    String positionCarte = "positionCarte"; //$NON-NLS-1$
    String positionPortPon = "positionPortPon"; //$NON-NLS-1$
    String statutBlocage = "statutBlocage"; //$NON-NLS-1$
    String commentaireBlocage = "commentaireBlocage"; //$NON-NLS-1$
    // test scenario
    OltCompositeService oltService = new OltCompositeService(_connector);
    JUnitTools.setInaccessibleFieldValue(_connector, "_oltCompositeService", oltService); //$NON-NLS-1$
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_oltCompositeUrl), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.oltCompositeModifierSurchargePriseClientPortPon(_tracabilite, nomOlt, positionCarte, positionPortPon, statutBlocage, commentaireBlocage);

    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_ACTION, OltCompositeService.IAction.MODIFIER_SURCHARGE_PRISE_CLIENT_PORT_PON);
    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_NOM_OLT, "nomOlt"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_POSITION_CARTE, "positionCarte"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_POSITION_PORT_PON, "positionPortPon"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, IRESConnector.STATUT_BLOCAGE, "statutBlocage"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, IRESConnector.COMMENTAIRE_BLOCAGE, "commentaireBlocage"); //$NON-NLS-1$

    Assert.assertEquals(retourOK, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method
   * {@link RESConnector#oltCompositeModifierSurchargeTechnoAutoriseePortPon(Tracabilite, ListeTechnologieAutorisee, String, String, String)}
   * httpStatus 404 Retour KO
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void oltModifierSurchargeTechnoAutoriseePortPon_KO_001() throws Exception
  {

    final Retour retourKO = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "erreur"); //$NON-NLS-1$
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retourKO));
    final String partnerResponse = RavelJsonTools.getInstance().toJson(basicResponse, BasicResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(404).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();
    String nomOlt = "nomOlt"; //$NON-NLS-1$
    String positionCarte = "positionCarte"; //$NON-NLS-1$
    String positionPortPon = "positionPortPon"; //$NON-NLS-1$
    // test scenario
    OltCompositeService oltService = new OltCompositeService(_connector);
    JUnitTools.setInaccessibleFieldValue(_connector, "_oltCompositeService", oltService); //$NON-NLS-1$
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_oltCompositeUrl), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.oltCompositeModifierSurchargeTechnoAutoriseePortPon(_tracabilite, null, nomOlt, positionCarte, positionPortPon);

    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_ACTION, OltCompositeService.IAction.MODIFIER_SURCHARGE_TECHNO_AUTORISEEPORT_PON);
    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_NOM_OLT, "nomOlt"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_POSITION_CARTE, "positionCarte"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_POSITION_PORT_PON, "positionPortPon"); //$NON-NLS-1$

    Assert.assertEquals(retourKO, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method
   * {@link RESConnector#oltCompositeModifierSurchargeTechnoAutoriseePortPon(Tracabilite, ListeTechnologieAutorisee, String, String, String)}
   * httpStatus 404 Retour KO
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void oltModifierSurchargeTechnoAutoriseePortPon_OK() throws Exception
  {

    final Retour retourOK = RetourFactoryForTU.createOkRetour();
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retourOK));
    final String partnerResponse = RavelJsonTools.getInstance().toJson(basicResponse, BasicResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();
    List<String> listAutorise = new ArrayList<>();
    listAutorise.add("value1"); //$NON-NLS-1$
    listAutorise.add("value2"); //$NON-NLS-1$

    ListeTechnologieAutorisee listTechno = new ListeTechnologieAutorisee();
    listTechno.setListTechnologieAutorisee(listAutorise);
    String request = RavelJsonTools.getInstance().toJson(listTechno, ListeTechnologieAutorisee.class);
    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();
    String nomOlt = "nomOlt"; //$NON-NLS-1$
    String positionCarte = "positionCarte"; //$NON-NLS-1$
    String positionPortPon = "positionPortPon"; //$NON-NLS-1$
    // test scenario
    OltCompositeService oltService = new OltCompositeService(_connector);
    JUnitTools.setInaccessibleFieldValue(_connector, "_oltCompositeService", oltService); //$NON-NLS-1$
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_oltCompositeUrl), EasyMock.capture(headersCapture), EasyMock.eq(request), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.oltCompositeModifierSurchargeTechnoAutoriseePortPon(_tracabilite, listTechno, nomOlt, positionCarte, positionPortPon);

    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_ACTION, OltCompositeService.IAction.MODIFIER_SURCHARGE_TECHNO_AUTORISEEPORT_PON);
    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_NOM_OLT, "nomOlt"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_POSITION_CARTE, "positionCarte"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_POSITION_PORT_PON, "positionPortPon"); //$NON-NLS-1$

    Assert.assertEquals(retourOK, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method
   * {@link RESConnector#oltCompositeModifierSurchargeVersionOLT(Tracabilite, ListeTechnologieAutorisee, String, String)}
   * httpStatus 404 Retour KO
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void oltModifierSurchargeVersionOLT_KO_001() throws Exception
  {

    final Retour retourKO = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "erreur"); //$NON-NLS-1$
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retourKO));
    final String partnerResponse = RavelJsonTools.getInstance().toJson(basicResponse, BasicResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(404).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();
    String nomOlt = "nomOlt"; //$NON-NLS-1$
    String versionInterfaceEchange = "versionInterfaceEchange"; //$NON-NLS-1$
    // test scenario
    OltCompositeService oltService = new OltCompositeService(_connector);
    JUnitTools.setInaccessibleFieldValue(_connector, "_oltCompositeService", oltService); //$NON-NLS-1$
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_oltCompositeUrl), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.oltCompositeModifierSurchargeVersionOLT(_tracabilite, null, nomOlt, versionInterfaceEchange);

    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_ACTION, OltCompositeService.IAction.MODIFIER_SURCHARGE_VERSION_OLT);
    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_NOM_OLT, "nomOlt"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_VERSION_INTERFACE_ECHANGE, "versionInterfaceEchange"); //$NON-NLS-1$

    Assert.assertEquals(retourKO, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method
   * {@link RESConnector#oltCompositeModifierSurchargeVersionOLT(Tracabilite, ListeTechnologieAutorisee, String, String)}
   * httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void oltModifierSurchargeVersionOLT_OK() throws Exception
  {

    final Retour retourOK = RetourFactoryForTU.createOkRetour();
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retourOK));
    final String partnerResponse = RavelJsonTools.getInstance().toJson(basicResponse, BasicResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();
    List<String> listAutorise = new ArrayList<>();
    listAutorise.add("value1"); //$NON-NLS-1$
    listAutorise.add("value2"); //$NON-NLS-1$

    ListeTechnologieAutorisee listTechno = new ListeTechnologieAutorisee();
    listTechno.setListTechnologieAutorisee(listAutorise);
    String request = RavelJsonTools.getInstance().toJson(listTechno, ListeTechnologieAutorisee.class);
    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();
    String nomOlt = "nomOlt"; //$NON-NLS-1$
    String versionInterfaceEchange = "versionInterfaceEchange"; //$NON-NLS-1$
    // test scenario
    OltCompositeService oltService = new OltCompositeService(_connector);
    JUnitTools.setInaccessibleFieldValue(_connector, "_oltCompositeService", oltService); //$NON-NLS-1$
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_oltCompositeUrl), EasyMock.capture(headersCapture), EasyMock.eq(request), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.oltCompositeModifierSurchargeVersionOLT(_tracabilite, listTechno, nomOlt, versionInterfaceEchange);

    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_ACTION, OltCompositeService.IAction.MODIFIER_SURCHARGE_VERSION_OLT);
    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_NOM_OLT, "nomOlt"); //$NON-NLS-1$
    checkQueryParams(queryParamsCapture, IRESConnector.PARAM_VERSION_INTERFACE_ECHANGE, "versionInterfaceEchange"); //$NON-NLS-1$

    Assert.assertEquals(retourOK, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Error From PAD3200
   *
   * expect resultat:NOK categorie:CAT-4 diagnostic:DONNEE_INVALIDE,libelle:invalid value fro attribute
   * carteP2P.modele:CarteAPuce //$NON-NLS-1$
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public void testOltComposite_KO_001() throws Exception
  {

    final OltComposite oltcomposite = new OltComposite("nomOLT", "nomNR", "constructeur", "modele", "statutTechnique"); //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
    oltcomposite.setIp("ip"); //$NON-NLS-1$
    String result = "{\"retour\":{\"resultat\":\"NOK\",\"categorie\":\"CAT-4\",\"diagnostic\":\"DONNEE_INVALIDE\",\"libelle\":\"invalid value fro attribute carteP2P.modele:CarteAPuce\"}}"; //$NON-NLS-1$
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(result.getBytes())).build();
    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    // test scenario
    OltCompositeService oltComposite = new OltCompositeService(_connector);
    JUnitTools.setInaccessibleFieldValue(_connector, "_oltCompositeService", oltComposite); //$NON-NLS-1$
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_oltCompositeUrl), EasyMock.capture(headersCapture), EasyMock.anyObject(), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);
    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> resultResponse = _connector.oltCompositeGererImport(_tracabilite, oltcomposite);
    PowerMock.verifyAll();
    checkHeader(_tracabilite, headersCapture);
    checkQueryParams(queryParamsCapture, "action", "GererImport"); //$NON-NLS-1$ //$NON-NLS-2$
    Retour retourExpect = RetourFactoryForTU.createNOK("CAT-4", "DONNEE_INVALIDE", "invalid value fro attribute carteP2P.modele:CarteAPuce"); //$NON-NLS-1$ //$NON-NLS-2$//$NON-NLS-3$
    Assert.assertNotNull(resultResponse);
    Assert.assertNotNull(resultResponse._first);
    Assert.assertEquals(retourExpect, resultResponse._first);
    Assert.assertNull(resultResponse._second);

  }

  /**
   * Retour OK From PAD3200
   *
   * expect resultat:OK //$NON-NLS-1$
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public void testOltComposite_OK_001() throws Exception
  {
    final OltComposite oltcomposite = new OltComposite("nomOLT", "nomNR", "constructeur", "modele", "statutTechnique"); //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
    oltcomposite.setIp("ip"); //$NON-NLS-1$
    String result = "{\"retour\":{\"resultat\":\"OK\"}}"; //$NON-NLS-1$
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(result.getBytes())).build();
    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    // test scenario
    OltCompositeService oltComposite = new OltCompositeService(_connector);
    JUnitTools.setInaccessibleFieldValue(_connector, "_oltCompositeService", oltComposite); //$NON-NLS-1$
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_oltCompositeUrl), EasyMock.capture(headersCapture), EasyMock.anyObject(), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);
    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> resultResponse = _connector.oltCompositeGererImport(_tracabilite, oltcomposite);
    //pad3001CommuneReadAncienCodeInsee(_tracabilite, "123"); //$NON-NLS-1$
    PowerMock.verifyAll();
    checkHeader(_tracabilite, headersCapture);
    checkQueryParams(queryParamsCapture, "action", "GererImport"); //$NON-NLS-1$ //$NON-NLS-2$
    Assert.assertNotNull(resultResponse);
    Assert.assertNotNull(resultResponse._first);
    Assert.assertEquals(RetourFactoryForTU.createOkRetour(), resultResponse._first);
    Assert.assertNull(resultResponse._second);
  }

  /**
   * Error From PAD3200
   *
   * expect resultat:NOK categorie:CAT-4 diagnostic:DONNEE_INVALIDE,libelle:invalid value fro attribute
   * carteP2P.modele:CarteAPuce //$NON-NLS-1$
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public void testoltCompositeGererSuppressionOltNonReference_KO_001() throws Exception
  {
    Set<String> listeNomOLT = new HashSet<>();

    ManageOltCompositeRequest oltreq = new ManageOltCompositeRequest(listeNomOLT);
    String json = RavelJsonTools.getInstance().toJson(oltreq, ManageOltCompositeRequest.class);
    String result = "{\"retour\":{\"resultat\":\"NOK\",\"categorie\":\"CAT-4\",\"diagnostic\":\"DONNEE_INVALIDE\",\"libelle\":\"invalid value fro attribute carteP2P.modele:CarteAPuce\"}}"; //$NON-NLS-1$
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(result.getBytes())).build();
    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    // test scenario
    OltCompositeService oltComposite = new OltCompositeService(_connector);
    JUnitTools.setInaccessibleFieldValue(_connector, "_oltCompositeService", oltComposite); //$NON-NLS-1$
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_oltCompositeUrl), EasyMock.capture(headersCapture), EasyMock.eq(json), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);
    PowerMock.replayAll();
    final ConnectorResponse<Retour, Set<CompteRenduSuppression>> resultResponse = _connector.oltCompositeGererSuppressionOltNonReference(_tracabilite, listeNomOLT);
    PowerMock.verifyAll();
    checkHeader(_tracabilite, headersCapture);
    checkQueryParams(queryParamsCapture, "action", "GererSuppressionOltNonReference"); //$NON-NLS-1$ //$NON-NLS-2$
    Retour retourExpect = RetourFactoryForTU.createNOK("CAT-4", "DONNEE_INVALIDE", "invalid value fro attribute carteP2P.modele:CarteAPuce"); //$NON-NLS-1$ //$NON-NLS-2$//$NON-NLS-3$
    Assert.assertNotNull(resultResponse);
    Assert.assertNotNull(resultResponse._first);
    Assert.assertEquals(retourExpect, resultResponse._first);
    Assert.assertNull(resultResponse._second);

  }

  /**
   * Retour OK From PAD3200
   *
   * expect resultat:OK //$NON-NLS-1$
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public void testoltCompositeGererSuppressionOltNonReference_OK_001() throws Exception
  {
    Set<String> listeNomOLT = new HashSet<>();

    ManageOltCompositeRequest oltreq = new ManageOltCompositeRequest(listeNomOLT);
    String json = RavelJsonTools.getInstance().toJson(oltreq, ManageOltCompositeRequest.class);
    String result = "{\"retour\":{\"resultat\":\"OK\"}}"; //$NON-NLS-1$
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(result.getBytes())).build();
    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    // test scenario
    OltCompositeService oltComposite = new OltCompositeService(_connector);
    JUnitTools.setInaccessibleFieldValue(_connector, "_oltCompositeService", oltComposite); //$NON-NLS-1$
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_oltCompositeUrl), EasyMock.capture(headersCapture), EasyMock.eq(json), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);
    PowerMock.replayAll();
    final ConnectorResponse<Retour, Set<CompteRenduSuppression>> resultResponse = _connector.oltCompositeGererSuppressionOltNonReference(_tracabilite, listeNomOLT);
    //pad3001CommuneReadAncienCodeInsee(_tracabilite, "123"); //$NON-NLS-1$
    PowerMock.verifyAll();
    checkHeader(_tracabilite, headersCapture);
    checkQueryParams(queryParamsCapture, "action", "GererSuppressionOltNonReference"); //$NON-NLS-1$ //$NON-NLS-2$
    Assert.assertNotNull(resultResponse);
    Assert.assertNotNull(resultResponse._first);
    Assert.assertEquals(RetourFactoryForTU.createOkRetour(), resultResponse._first);
    Assert.assertNull(resultResponse._second);

  }

  /**
   * @param tracabilite_p
   *          _tracabilite
   * @param headersCapture_p
   *          headersCapture
   */
  private void checkHeader(Tracabilite tracabilite_p, Capture<MultivaluedMap<String, String>> headersCapture_p)
  {
    Assert.assertNotNull(headersCapture_p.getValue());
    Assert.assertNotNull(headersCapture_p.getValue().get(IHttpHeadersConsts.X_REQUEST_ID));
    Assert.assertEquals(tracabilite_p.getIdCorrelationByTel(), headersCapture_p.getValue().get(IHttpHeadersConsts.X_REQUEST_ID).get(0));
    Assert.assertNotNull(headersCapture_p.getValue().get(IHttpHeadersConsts.X_REQUEST_ID_SPIRIT));
    Assert.assertEquals(tracabilite_p.getIdCorrelationSpirit(), headersCapture_p.getValue().get(IHttpHeadersConsts.X_REQUEST_ID_SPIRIT).get(0));
    Assert.assertNotNull(headersCapture_p.getValue().get(IHttpHeadersConsts.X_SOURCE));
    Assert.assertEquals(tracabilite_p.getNomSysteme(), headersCapture_p.getValue().get(IHttpHeadersConsts.X_SOURCE).get(0));
    Assert.assertNotNull(headersCapture_p.getValue().get(IHttpHeadersConsts.X_PROCESS));
    Assert.assertEquals(tracabilite_p.getNomProcessus(), headersCapture_p.getValue().get(IHttpHeadersConsts.X_PROCESS).get(0));
    Assert.assertNotNull(headersCapture_p.getValue().get(IHttpHeadersConsts.X_PROCESS_ID_SPIRIT));
    Assert.assertEquals(tracabilite_p.getIdProcessusSpirit(), headersCapture_p.getValue().get(IHttpHeadersConsts.X_PROCESS_ID_SPIRIT).get(0));

    tracabilite_p.getRefFonc().forEach((key, value) -> Assert.assertEquals(value, headersCapture_p.getValue().get(IHttpHeadersConsts.X_TRACE.concat(key)).get(0)));
  }

  /**
   * Check the query params in rest send request method
   *
   * @param queryParams
   *          the actual query params
   * @param expected_p
   *          list of expected query params strings key1 value1 key2 value2...keyN valueN
   */
  private void checkQueryParams(Capture<Map<String, String>> queryParams, String... expected_p)
  {
    if (expected_p == null)
    {
      Assert.assertNull(queryParams.getValue());
    }
    else
    {
      Assert.assertEquals(0, expected_p.length % 2);
      for (int i = 0; i < expected_p.length; i = i + 2)
      {
        Assert.assertEquals(expected_p[i + 1], queryParams.getValue().get(expected_p[i]));
      }
    }
  }

  /**
   * prepare mock scenario to initialize method sendRequest from AbstractRestConnector
   *
   * @throws Exception
   *           Thrown in case of error
   */
  private void initializeMocksForSendRequest() throws Exception
  {
    final String urlBalancedElementName = RandomStringUtils.randomAlphanumeric(45);
    final String urlBalancedElementDescription = RandomStringUtils.randomAlphabetic(9);

    EasyMock.expect(_loadBalancerMock.chooseBalancedElement()).andReturn(_urlBalancedElementMock);
    EasyMock.expect(_urlBalancedElementMock.getName()).andReturn(urlBalancedElementName);
    EasyMock.expect(_urlBalancedElementMock.getDescription()).andReturn(urlBalancedElementDescription);
    EasyMock.expect(_urlBalancedElementMock.getName()).andReturn(urlBalancedElementName);
    EasyMock.expect(_connectorPoolMock.get(urlBalancedElementName)).andReturn(_restConnectorPoolMock);
    EasyMock.expect(_restConnectorPoolMock.borrowObject()).andReturn(_restInstanceMock);
  }
}
