/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.res;

import java.io.ByteArrayInputStream;
import java.text.MessageFormat;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Map;
import java.util.Set;

import javax.ws.rs.core.MultivaluedHashMap;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;

import org.apache.cxf.jaxrs.impl.ResponseBuilderImpl;
import org.easymock.EasyMock;
import org.easymock.EasyMockSupport;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.conf.generated.Param;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.test.JUnitTools;
import com.bytel.ravel.common.utils.RetourFactoryForTU;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.net.rest.RestConnectorPool;
import com.bytel.ravel.net.rest.RestInstance;
import com.bytel.ravel.services.conf.connector.generated.Connector;
import com.bytel.ravel.services.connector.ConnectorManager;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.shared.functional.types.json.RavelJsonTools;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.BasicResponse;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.ressources.RetourConverter;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.CompteRenduSuppression;
import com.bytel.spirit.common.shared.saab.res.PorteDeCollecte;
import com.bytel.spirit.common.shared.saab.res.request.ManagePorteCollecteRequest;
import com.bytel.spirit.common.shared.saab.res.response.GetPorteDeCollecteResponse;
import com.bytel.spirit.common.shared.saab.res.response.ListeCRSupressionResponse;

/**
 * @author acorreia
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({ RESProxy.class, ConnectorManager.class })
public class PorteDeCollecteServiceTest extends EasyMockSupport
{
  private static final String _url = "/porteDeCollecte"; //$NON-NLS-1$

  private RESConnector _resConnector;
  private Tracabilite _tracabilite;

  @MockStrict
  private ConnectorManager _connectorManagerMock;

  @MockStrict
  private Hashtable<String, RestConnectorPool> _connectorPoolMock;

  @MockStrict
  private RestInstance _restInstanceMock;

  @MockStrict
  private RestConnectorPool _restConnectorPoolMock;

  /**
   * Run before each test.
   * 
   * @throws RavelException
   *           on error.
   */
  @Before
  public void beforeTest() throws RavelException
  {
    PowerMock.resetAll();

    _resConnector = new RESConnector();
    _tracabilite = new Tracabilite();

    PowerMock.mockStaticStrict(ConnectorManager.class);
  }

  /**
   * NOK, proxy throws exception when trying to obtain the connector.
   *
   * @throws RavelException
   *           on error.
   */
  @Test
  public void porteDeCollecteGererImport_test_NOK_01() throws RavelException
  {
    // Expected result
    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegSpiritConsts.SERVICE_TIERS_INDISPONIBLE, ""); //$NON-NLS-1$

    // Prepare the mocks and configuration
    prepareProxy(false);

    PowerMock.replayAll();

    // Call the connector
    ConnectorResponse<Retour, Nothing> porteDeCollecteResponse = RESProxy.getInstance().porteDeCollecteGererImport(_tracabilite, null);

    // Verify the result
    PowerMock.verifyAll();

    verifyRetour(expectedRetour, porteDeCollecteResponse._first, false);
    Assert.assertNull(porteDeCollecteResponse._second);
  }

  /**
   * NOK, missing url in configuration.
   *
   * @throws RavelException
   *           on error.
   */
  @Test
  public void porteDeCollecteGererImport_test_NOK_02() throws RavelException
  {
    // Expected result
    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, "The configuration parameter PORTE_DE_COLLECTE_PATH is missing"); //$NON-NLS-1$

    // Prepare the mocks and configuration
    prepareProxy(true);

    prepareServiceConfiguration(true);

    PowerMock.replayAll();

    // Call the connector
    ConnectorResponse<Retour, Nothing> porteDeCollecteResponse = RESProxy.getInstance().porteDeCollecteGererImport(_tracabilite, null);

    // Verify the result
    PowerMock.verifyAll();

    verifyRetour(expectedRetour, porteDeCollecteResponse._first, true);
    Assert.assertNull(porteDeCollecteResponse._second);
  }

  /**
   * NOK, sendRequest throws exception.
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void porteDeCollecteGererImport_test_NOK_03() throws Exception
  {
    // Expected result
    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, IMegConsts.LIBELLE);

    // Prepare the mocks and configuration
    prepareProxy(true);

    prepareServiceConfiguration(false);

    final PorteDeCollecte porteDeCollecte = new PorteDeCollecte("idNomCollecte"); //$NON-NLS-1$

    JUnitTools.setInaccessibleFieldValue(_resConnector, "_connectorPool", _connectorPoolMock); //$NON-NLS-1$

    EasyMock.expect(_connectorPoolMock.get("urlName")).andReturn(_restConnectorPoolMock); //$NON-NLS-1$
    EasyMock.expect(_restConnectorPoolMock.borrowObject()).andThrow(new RavelException(ExceptionType.CONNECTOR_CHECKING_ERROR, ErrorCode.AGRTOR_00001, IMegConsts.LIBELLE));
    _restConnectorPoolMock.returnObject(null);

    PowerMock.replayAll();

    // Call the connector
    ConnectorResponse<Retour, Nothing> porteDeCollecteResponse = RESProxy.getInstance().porteDeCollecteGererImport(_tracabilite, porteDeCollecte);

    // Verify the result
    PowerMock.verifyAll();

    verifyRetour(expectedRetour, porteDeCollecteResponse._first, false);
    Assert.assertNull(porteDeCollecteResponse._second);
  }

  /**
   * NOK, getContentFromResponse throws exception.
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void porteDeCollecteGererImport_test_NOK_04() throws Exception
  {
    // Expected result
    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, null);

    Map<String, String> expectedQueryParams = new HashMap<>();
    expectedQueryParams.put("action", "GererImport"); //$NON-NLS-1$ //$NON-NLS-2$

    // Prepare the mocks and configuration
    prepareProxy(true);

    prepareServiceConfiguration(false);

    final PorteDeCollecte porteDeCollecte = new PorteDeCollecte("idNomCollecte"); //$NON-NLS-1$

    prepareSendRequest(30);

    ManagePorteCollecteRequest managePorteCollecteRequest = new ManagePorteCollecteRequest(porteDeCollecte);
    String json = RavelJsonTools.getInstance().toJson(managePorteCollecteRequest, ManagePorteCollecteRequest.class);
    EasyMock.expect(_restInstanceMock.put(_url, getMapDefaultHeaders(false), json, expectedQueryParams)).andReturn(null);

    PowerMock.replayAll();

    // Call the connector
    ConnectorResponse<Retour, Nothing> porteDeCollecteResponse = RESProxy.getInstance().porteDeCollecteGererImport(_tracabilite, porteDeCollecte);

    // Verify the result
    PowerMock.verifyAll();

    verifyRetour(expectedRetour, porteDeCollecteResponse._first, true);
    Assert.assertNull(porteDeCollecteResponse._second);
  }

  /**
   * OK.
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void porteDeCollecteGererImport_test_OK() throws Exception
  {
    // Expected result
    Retour expectedRetour = RetourFactoryForTU.createRetour(IMegConsts.RESULTAT, IMegConsts.CATEGORIE, IMegConsts.DIAGNOSTIC, IMegConsts.LIBELLE, null);

    Map<String, String> expectedQueryParams = new HashMap<>();
    expectedQueryParams.put("action", "GererImport"); //$NON-NLS-1$ //$NON-NLS-2$

    // Prepare the mocks and configuration
    prepareProxy(true);

    prepareServiceConfiguration(false);

    final PorteDeCollecte porteDeCollecte = new PorteDeCollecte("idNomCollecte"); //$NON-NLS-1$

    Retour importRetour = RetourFactoryForTU.createRetour(IMegConsts.RESULTAT, IMegConsts.CATEGORIE, IMegConsts.DIAGNOSTIC, IMegConsts.LIBELLE, null);
    preparePorteDeCollecteGererImport(expectedQueryParams, porteDeCollecte, importRetour);

    PowerMock.replayAll();

    // Call the connector
    ConnectorResponse<Retour, Nothing> porteDeCollecteResponse = RESProxy.getInstance().porteDeCollecteGererImport(_tracabilite, porteDeCollecte);

    // Verify the result
    PowerMock.verifyAll();

    verifyRetour(expectedRetour, porteDeCollecteResponse._first, true);
    Assert.assertNull(porteDeCollecteResponse._second);
  }

  /**
   * NOK, proxy throws exception when trying to obtain the connector.
   *
   * @throws RavelException
   *           on error.
   */
  @Test
  public void porteDeCollecteGererSuppressionPorteDeCollecteNonReference_test_NOK_01() throws RavelException
  {
    // Expected result
    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegSpiritConsts.SERVICE_TIERS_INDISPONIBLE, ""); //$NON-NLS-1$

    // Prepare the mocks and configuration
    prepareProxy(false);

    PowerMock.replayAll();

    // Call the connector
    ConnectorResponse<Retour, Set<CompteRenduSuppression>> porteDeCollecteResponse = RESProxy.getInstance().porteDeCollecteGererSuppressionPorteDeCollecteNonReference(_tracabilite, null);

    // Verify the result
    PowerMock.verifyAll();

    verifyRetour(expectedRetour, porteDeCollecteResponse._first, false);
    Assert.assertNull(porteDeCollecteResponse._second);
  }

  /**
   * NOK, missing url in configuration.
   *
   * @throws RavelException
   *           on error.
   */
  @Test
  public void porteDeCollecteGererSuppressionPorteDeCollecteNonReference_test_NOK_02() throws RavelException
  {
    // Expected result
    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, "The configuration parameter PORTE_DE_COLLECTE_PATH is missing"); //$NON-NLS-1$

    // Prepare the mocks and configuration
    prepareProxy(true);

    prepareServiceConfiguration(true);

    PowerMock.replayAll();

    // Call the connector
    ConnectorResponse<Retour, Set<CompteRenduSuppression>> porteDeCollecteResponse = RESProxy.getInstance().porteDeCollecteGererSuppressionPorteDeCollecteNonReference(_tracabilite, null);

    // Verify the result
    PowerMock.verifyAll();

    verifyRetour(expectedRetour, porteDeCollecteResponse._first, true);
    Assert.assertNull(porteDeCollecteResponse._second);
  }

  /**
   * NOK, sendRequest throws exception.
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void porteDeCollecteGererSuppressionPorteDeCollecteNonReference_test_NOK_03() throws Exception
  {
    // Expected result
    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, IMegConsts.LIBELLE);

    // Prepare the mocks and configuration
    prepareProxy(true);

    prepareServiceConfiguration(false);

    final Set<String> listeIdNomCollecte = new HashSet<>();
    listeIdNomCollecte.add("MaCollecte1"); //$NON-NLS-1$
    listeIdNomCollecte.add("MaCollecte2"); //$NON-NLS-1$

    JUnitTools.setInaccessibleFieldValue(_resConnector, "_connectorPool", _connectorPoolMock); //$NON-NLS-1$

    EasyMock.expect(_connectorPoolMock.get("urlName")).andReturn(_restConnectorPoolMock); //$NON-NLS-1$
    EasyMock.expect(_restConnectorPoolMock.borrowObject()).andThrow(new RavelException(ExceptionType.CONNECTOR_CHECKING_ERROR, ErrorCode.AGRTOR_00001, IMegConsts.LIBELLE));
    _restConnectorPoolMock.returnObject(null);

    PowerMock.replayAll();

    // Call the connector
    ConnectorResponse<Retour, Set<CompteRenduSuppression>> porteDeCollecteResponse = RESProxy.getInstance().porteDeCollecteGererSuppressionPorteDeCollecteNonReference(_tracabilite, listeIdNomCollecte);

    // Verify the result
    PowerMock.verifyAll();

    verifyRetour(expectedRetour, porteDeCollecteResponse._first, false);
    Assert.assertNull(porteDeCollecteResponse._second);
  }

  /**
   * NOK, getContentFromResponse throws exception.
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void porteDeCollecteGererSuppressionPorteDeCollecteNonReference_test_NOK_04() throws Exception
  {
    // Expected result
    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, null);

    Map<String, String> expectedQueryParams = new HashMap<>();
    expectedQueryParams.put("action", "GererSuppressionPorteDeCollecteNonReference"); //$NON-NLS-1$ //$NON-NLS-2$

    // Prepare the mocks and configuration
    prepareProxy(true);

    prepareServiceConfiguration(false);

    final Set<String> listeIdNomCollecte = new HashSet<>();
    listeIdNomCollecte.add("MaCollecte1"); //$NON-NLS-1$
    listeIdNomCollecte.add("MaCollecte2"); //$NON-NLS-1$

    prepareSendRequest(30);

    ManagePorteCollecteRequest managePorteCollecteRequest = new ManagePorteCollecteRequest(listeIdNomCollecte);
    String json = RavelJsonTools.getInstance().toJson(managePorteCollecteRequest, ManagePorteCollecteRequest.class);
    EasyMock.expect(_restInstanceMock.put(_url, getMapDefaultHeaders(false), json, expectedQueryParams)).andReturn(null);

    PowerMock.replayAll();

    // Call the connector
    ConnectorResponse<Retour, Set<CompteRenduSuppression>> porteDeCollecteResponse = RESProxy.getInstance().porteDeCollecteGererSuppressionPorteDeCollecteNonReference(_tracabilite, listeIdNomCollecte);

    // Verify the result
    PowerMock.verifyAll();

    verifyRetour(expectedRetour, porteDeCollecteResponse._first, true);
    Assert.assertNull(porteDeCollecteResponse._second);
  }

  /**
   * OK.
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void porteDeCollecteGererSuppressionPorteDeCollecteNonReference_test_OK() throws Exception
  {
    // Expected result
    Retour expectedRetour = RetourFactoryForTU.createRetour(IMegConsts.RESULTAT, IMegConsts.CATEGORIE, IMegConsts.DIAGNOSTIC, IMegConsts.LIBELLE, null);

    final Set<CompteRenduSuppression> expectedCompteRenduSuppressionSet = new HashSet<>();
    expectedCompteRenduSuppressionSet.add(new CompteRenduSuppression("MaCollecte3", StringConstants.OK)); //$NON-NLS-1$
    expectedCompteRenduSuppressionSet.add(new CompteRenduSuppression("MaCollecte4", StringConstants.OK)); //$NON-NLS-1$

    Map<String, String> expectedQueryParams = new HashMap<>();
    expectedQueryParams.put("action", "GererSuppressionPorteDeCollecteNonReference"); //$NON-NLS-1$ //$NON-NLS-2$

    // Prepare the mocks and configuration
    prepareProxy(true);

    prepareServiceConfiguration(false);

    final Set<String> listeIdNomCollecte = new HashSet<>();
    listeIdNomCollecte.add("MaCollecte1"); //$NON-NLS-1$
    listeIdNomCollecte.add("MaCollecte2"); //$NON-NLS-1$

    final Set<CompteRenduSuppression> compteRenduSuppressionSet = new HashSet<>();
    compteRenduSuppressionSet.add(new CompteRenduSuppression("MaCollecte3", StringConstants.OK)); //$NON-NLS-1$
    compteRenduSuppressionSet.add(new CompteRenduSuppression("MaCollecte4", StringConstants.OK)); //$NON-NLS-1$

    Retour importRetour = RetourFactoryForTU.createRetour(IMegConsts.RESULTAT, IMegConsts.CATEGORIE, IMegConsts.DIAGNOSTIC, IMegConsts.LIBELLE, null);
    preparePorteDeCollecteGererSuppressionPorteDeCollecteNonReference(expectedQueryParams, listeIdNomCollecte, compteRenduSuppressionSet, importRetour);

    PowerMock.replayAll();

    // Call the connector
    ConnectorResponse<Retour, Set<CompteRenduSuppression>> porteDeCollecteResponse = RESProxy.getInstance().porteDeCollecteGererSuppressionPorteDeCollecteNonReference(_tracabilite, listeIdNomCollecte);

    // Verify the result
    PowerMock.verifyAll();

    verifyRetour(expectedRetour, porteDeCollecteResponse._first, true);
    Assert.assertEquals(expectedCompteRenduSuppressionSet, porteDeCollecteResponse._second);
  }

  /**
   * NOK, proxy throws exception when trying to obtain the connector.
   *
   * @throws RavelException
   *           on error.
   */
  @Test
  public void porteDeCollecteLireUn_test_NOK_01() throws RavelException
  {
    // Expected result
    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegSpiritConsts.SERVICE_TIERS_INDISPONIBLE, ""); //$NON-NLS-1$

    // Prepare the mocks and configuration
    prepareProxy(false);

    // Call the connector
    PowerMock.replayAll();

    ConnectorResponse<Retour, PorteDeCollecte> porteDeCollecteResponse = RESProxy.getInstance().porteDeCollecteLireUn(_tracabilite, null);

    PowerMock.verifyAll();

    // Verify the result

    verifyRetour(expectedRetour, porteDeCollecteResponse._first, false);
    Assert.assertNull(porteDeCollecteResponse._second);
  }

  /**
   * NOK, missing url in configuration.
   *
   * @throws RavelException
   *           on error.
   */
  @Test
  public void porteDeCollecteLireUn_test_NOK_02() throws RavelException
  {
    // Expected result
    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, "The configuration parameter PORTE_DE_COLLECTE_PATH is missing"); //$NON-NLS-1$

    // Prepare the mocks and configuration
    prepareProxy(true);

    prepareServiceConfiguration(true);

    // Call the connector
    PowerMock.replayAll();

    ConnectorResponse<Retour, PorteDeCollecte> porteDeCollecteResponse = RESProxy.getInstance().porteDeCollecteLireUn(_tracabilite, null);

    // Verify the result
    PowerMock.verifyAll();

    verifyRetour(expectedRetour, porteDeCollecteResponse._first, true);
    Assert.assertNull(porteDeCollecteResponse._second);
  }

  /**
   * NOK, sendRequest throws exception.
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void porteDeCollecteLireUn_test_NOK_03() throws Exception
  {
    // Expected result
    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, IMegConsts.LIBELLE);

    // Prepare the mocks and configuration
    prepareProxy(true);

    prepareServiceConfiguration(false);

    final String idNomCollecte = "idNomCollecte"; //$NON-NLS-1$

    JUnitTools.setInaccessibleFieldValue(_resConnector, "_connectorPool", _connectorPoolMock); //$NON-NLS-1$

    EasyMock.expect(_connectorPoolMock.get("urlName")).andReturn(_restConnectorPoolMock); //$NON-NLS-1$
    EasyMock.expect(_restConnectorPoolMock.borrowObject()).andThrow(new RavelException(ExceptionType.CONNECTOR_CHECKING_ERROR, ErrorCode.AGRTOR_00001, IMegConsts.LIBELLE));
    _restConnectorPoolMock.returnObject(null);

    PowerMock.replayAll();

    // Call the connector
    ConnectorResponse<Retour, PorteDeCollecte> porteDeCollecteResponse = RESProxy.getInstance().porteDeCollecteLireUn(_tracabilite, idNomCollecte);

    // Verify the result
    PowerMock.verifyAll();

    verifyRetour(expectedRetour, porteDeCollecteResponse._first, false);
    Assert.assertNull(porteDeCollecteResponse._second);
  }

  /**
   * NOK, getContentFromResponse throws exception.
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void porteDeCollecteLireUn_test_NOK_04() throws Exception
  {
    // Expected result
    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, null);

    Map<String, String> expectedQueryParams = new HashMap<>();
    expectedQueryParams.put("idNomCollecte", "MaCollecte1"); //$NON-NLS-1$ //$NON-NLS-2$

    // Prepare the mocks and configuration
    prepareProxy(true);

    prepareServiceConfiguration(false);

    final String idNomCollecte = "MaCollecte1"; //$NON-NLS-1$

    prepareSendRequest(30);

    EasyMock.expect(_restInstanceMock.get(_url, getMapDefaultHeaders(true), expectedQueryParams)).andReturn(null);

    PowerMock.replayAll();

    // Call the connector
    ConnectorResponse<Retour, PorteDeCollecte> porteDeCollecteResponse = RESProxy.getInstance().porteDeCollecteLireUn(_tracabilite, idNomCollecte);

    // Verify the result
    PowerMock.verifyAll();

    verifyRetour(expectedRetour, porteDeCollecteResponse._first, true);
    Assert.assertNull(porteDeCollecteResponse._second);
  }

  /**
   * OK.
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void porteDeCollecteLireUn_test_OK() throws Exception
  {
    // Expected result
    Retour expectedRetour = RetourFactoryForTU.createRetour(IMegConsts.RESULTAT, IMegConsts.CATEGORIE, IMegConsts.DIAGNOSTIC, IMegConsts.LIBELLE, null);

    final PorteDeCollecte expectedPorteDeCollecte = new PorteDeCollecte("MaCollecte1"); //$NON-NLS-1$

    Map<String, String> expectedQueryParams = new HashMap<>();
    expectedQueryParams.put("idNomCollecte", "MaCollecte1"); //$NON-NLS-1$ //$NON-NLS-2$

    // Prepare the mocks and configuration
    prepareProxy(true);

    prepareServiceConfiguration(false);

    final String idNomCollecte = "MaCollecte1"; //$NON-NLS-1$

    final PorteDeCollecte porteDeCollecte = new PorteDeCollecte("MaCollecte1"); //$NON-NLS-1$
    Retour importRetour = RetourFactoryForTU.createRetour(IMegConsts.RESULTAT, IMegConsts.CATEGORIE, IMegConsts.DIAGNOSTIC, IMegConsts.LIBELLE, null);
    preparePorteDeCollecteLireUn(expectedQueryParams, porteDeCollecte, importRetour);

    PowerMock.replayAll();

    // Call the connector
    ConnectorResponse<Retour, PorteDeCollecte> porteDeCollecteResponse = RESProxy.getInstance().porteDeCollecteLireUn(_tracabilite, idNomCollecte);

    // Verify the result
    PowerMock.verifyAll();

    verifyRetour(expectedRetour, porteDeCollecteResponse._first, true);
    Assert.assertEquals(expectedPorteDeCollecte, porteDeCollecteResponse._second);
  }

  /**
   * Get a map with the default headers.
   *
   * @param isGet_p
   *          True if the method is GET.
   * @return the map.
   */
  private MultivaluedMap<String, String> getMapDefaultHeaders(boolean isGet_p)
  {
    MultivaluedMap<String, String> headers = new MultivaluedHashMap<>();
    headers.put(IHttpHeadersConsts.X_REQUEST_ID, Collections.singletonList(null));
    headers.put(IHttpHeadersConsts.X_SOURCE, Collections.singletonList(null));
    headers.add(IHttpHeadersConsts.X_OAUTH2_HABILIT, "SPIRIT_STARK"); //$NON-NLS-1$
    headers.put(IHttpHeadersConsts.X_PROCESS, Collections.singletonList(null));
    headers.put(IHttpHeadersConsts.X_REQUEST_ID_SPIRIT, Collections.singletonList(null));
    headers.put(IHttpHeadersConsts.X_PROCESS_ID_SPIRIT, Collections.singletonList(null));

    if (!isGet_p)
    {
      headers.add(IHttpHeadersConsts.CONTENT_TYPE, "application/json"); //$NON-NLS-1$
    }

    return headers;
  }

  /**
   * Prepare for the call made by porteDeCollecteGererImport.
   *
   * @param expectedQueryParams_p
   *          the expected query parameters.
   * @param porteDeCollecte_p
   *          the object being sent.
   * @param retour_p
   *          the desired retour.
   * @throws Exception
   *           on error.
   */
  private void preparePorteDeCollecteGererImport(Map<String, String> expectedQueryParams_p, PorteDeCollecte porteDeCollecte_p, Retour retour_p) throws Exception
  {
    prepareSendRequest(30);
    ManagePorteCollecteRequest managePorteCollecteRequest = new ManagePorteCollecteRequest(porteDeCollecte_p);

    String json = RavelJsonTools.getInstance().toJson(managePorteCollecteRequest, ManagePorteCollecteRequest.class);
    String responseBody = RavelJsonTools.getInstance().toJson(new BasicResponse(RetourConverter.convertToJsonRetour(retour_p)), BasicResponse.class);
    Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(responseBody.getBytes())).build();

    EasyMock.expect(_restInstanceMock.put(_url, getMapDefaultHeaders(false), json, expectedQueryParams_p)).andReturn(response);
  }

  /**
   * Prepare for the call made by porteDeCollecteGererSuppressionPorteDeCollecteNonReference.
   *
   * @param expectedQueryParams_p
   *          the expected query parameters.
   * @param listeIdNomeCollecte_p
   *          the object being sent.
   * @param compteRenduSuppressionSet_p
   *          the object being received.
   * @param retour_p
   *          the desired retour.
   * @throws Exception
   *           on error.
   */
  private void preparePorteDeCollecteGererSuppressionPorteDeCollecteNonReference(Map<String, String> expectedQueryParams_p, Set<String> listeIdNomeCollecte_p, Set<CompteRenduSuppression> compteRenduSuppressionSet_p, Retour retour_p) throws Exception
  {
    prepareSendRequest(30);
    ManagePorteCollecteRequest managePorteCollecteRequest = new ManagePorteCollecteRequest(listeIdNomeCollecte_p);

    String json = RavelJsonTools.getInstance().toJson(managePorteCollecteRequest, ManagePorteCollecteRequest.class);
    String responseBody = RavelJsonTools.getInstance().toJson(new ListeCRSupressionResponse(RetourConverter.convertToJsonRetour(retour_p), compteRenduSuppressionSet_p), ListeCRSupressionResponse.class);
    Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(responseBody.getBytes())).build();

    EasyMock.expect(_restInstanceMock.put(_url, getMapDefaultHeaders(false), json, expectedQueryParams_p)).andReturn(response);
  }

  /**
   * Prepare for the call made by porteDeCollecteLireUn.
   *
   * @param expectedQueryParams_p
   *          the expected query parameters.
   * @param porteDeCollecte_p
   *          the object being received.
   * @param retour_p
   *          the desired retour.
   * @throws Exception
   *           on error.
   */
  private void preparePorteDeCollecteLireUn(Map<String, String> expectedQueryParams_p, PorteDeCollecte porteDeCollecte_p, Retour retour_p) throws Exception
  {
    prepareSendRequest(30);
    GetPorteDeCollecteResponse managePorteCollecteRequest = new GetPorteDeCollecteResponse(RetourConverter.convertToJsonRetour(retour_p), porteDeCollecte_p);

    String responseBody = RavelJsonTools.getInstance().toJson(managePorteCollecteRequest, GetPorteDeCollecteResponse.class);
    Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(responseBody.getBytes())).build();

    EasyMock.expect(_restInstanceMock.get(_url, getMapDefaultHeaders(true), expectedQueryParams_p)).andReturn(response);
  }

  /**
   * Prepare the proxy mock for the calls.
   * 
   * @param success_p
   *          True if we want the proxy to be correctly configured.
   * @throws RavelException
   *           on error.
   */
  private void prepareProxy(boolean success_p) throws RavelException
  {
    EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).anyTimes();

    if (success_p)
    {
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_resConnector).anyTimes();
    }
    else
    {
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andThrow(new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.MGRCTR_00002, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID))); //$NON-NLS-1$
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_resConnector);
    }

    _connectorManagerMock.enable(IRESConnector.BEAN_ID);
  }

  /**
   * Prepare mock scenario to initialize method sendRequest from AbstractSpiritRESTConnector.
   *
   * @param timeout_p
   *          the timeout.
   * @throws Exception
   *           on error.
   */
  private void prepareSendRequest(int timeout_p) throws Exception
  {
    JUnitTools.setInaccessibleFieldValue(_resConnector, "_connectorPool", _connectorPoolMock); //$NON-NLS-1$

    EasyMock.expect(_connectorPoolMock.get("urlName")).andReturn(_restConnectorPoolMock); //$NON-NLS-1$
    EasyMock.expect(_restConnectorPoolMock.borrowObject()).andReturn(_restInstanceMock);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    _restInstanceMock.setReceiveTimeout(timeout_p);
  }

  /**
   * Set all values necessary by the service in order to execute, avoiding the call to loadConnectorConfiguration, and
   * thus the need for a configuration file.
   *
   * @param removeUrl_p
   *          True if the url should be missing from the configuration.
   * @throws RavelException
   *           on error loading the configuration.
   */
  private void prepareServiceConfiguration(boolean removeUrl_p) throws RavelException
  {
    // Set the configuration
    final Connector connector = new Connector();

    // Necessary for any request
    Param param = new Param();
    param.setName("AccesTechniqueCacheDuration"); //$NON-NLS-1$
    param.setValue("PT10M"); //$NON-NLS-1$
    connector.getParam().add(param);

    param = new Param();
    param.setName("AbaqueDSLCacheDuration"); //$NON-NLS-1$
    param.setValue("PT10M"); //$NON-NLS-1$
    connector.getParam().add(param);

    // The configuration specific to this service
    if (!removeUrl_p)
    {
      param = new Param();
      param.setName("POOL_IP_PATH"); //$NON-NLS-1$
      param.setValue(_url);
      connector.getParam().add(param);

      param = new Param();
      param.setName("PORTE_DE_COLLECTE_PATH"); //$NON-NLS-1$
      param.setValue(_url);
      connector.getParam().add(param);
    }

    connector.setURLS(RESConnectorTest.generateURLS());

    // Call the loadConnectorConfiguration
    _resConnector.loadConnectorConfiguration(connector);
  }

  /**
   * Verify that the retour is as expected.
   *
   * @param expectedRetour_p
   *          the expected retour.
   * @param actualRetour_p
   *          the actual retour.
   * @param exactLibelle_p
   *          whether to check if the libelle is an exact match or if it is enough for it to check that it is a part of
   *          it.
   */
  private void verifyRetour(Retour expectedRetour_p, Retour actualRetour_p, boolean exactLibelle_p)
  {
    Assert.assertEquals(expectedRetour_p.getResultat(), actualRetour_p.getResultat());
    Assert.assertEquals(expectedRetour_p.getCategorie(), actualRetour_p.getCategorie());
    Assert.assertEquals(expectedRetour_p.getDiagnostic(), actualRetour_p.getDiagnostic());

    if (exactLibelle_p)
    {
      Assert.assertEquals(expectedRetour_p.getLibelle(), actualRetour_p.getLibelle());
    }
    else
    {
      Assert.assertTrue(actualRetour_p.getLibelle().contains(expectedRetour_p.getLibelle()));
    }
  }
}
