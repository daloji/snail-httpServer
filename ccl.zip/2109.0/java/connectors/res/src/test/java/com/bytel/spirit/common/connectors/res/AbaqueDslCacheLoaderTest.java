/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.res;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.easymock.EasyMock;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.cache.BasicCache;
import com.bytel.ravel.common.cache.ICacheLoader;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.services.connector.ConnectorManager;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.IActivityCaller;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.AbaqueDSL;
import com.bytel.spirit.common.shared.saab.res.LigneMarche;
import com.bytel.spirit.common.shared.saab.res.NormeTechno;
import com.bytel.spirit.common.shared.saab.res.ReseauCollecte;
import com.bytel.spirit.common.shared.saab.res.SensFlux;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 * @author jpais
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({ RESConnector.class, ConnectorManager.class })
public class AbaqueDslCacheLoaderTest
{
  /**
   * Bean generation factory
   */
  private PodamFactory _podam = new PodamFactoryImpl();

  /**
   * {@link IActivityCaller} mock
   */
  IActivityCaller _activityCallerMock;

  /**
   * {@link RESConnector} mock
   */
  @MockStrict
  RESConnector _resConnector;

  /**
   * {@link ConnectorManager} mock
   */
  @MockStrict
  ConnectorManager _connectorManager;

  /**
   * Tests if a list of AbaqueDSL is well written in the cache
   *
   * <b>Inputs:</b>Valid inputs (a list containing one AbaqueDSL)<br/>
   * <b>Expected:</b><br/>
   *
   * @throws RavelException
   *           Thrown in case of error
   */
  @Test
  public void abaqueDslCacheLoader_LoadCacheKO_001() throws RavelException
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);

    EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManager);
    EasyMock.expect(_connectorManager.getConnector(IRESConnector.BEAN_ID)).andReturn(_resConnector);

    RavelException ravelExceptionExpected = new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.KO_00000, StringConstants.EMPTY_STRING);
    EasyMock.expect(_resConnector.loadAbaqueDslLireTous(tracabilite)).andThrow(ravelExceptionExpected);

    // On enregistre le scénario des appels avant de lancer l'activité
    PowerMock.replayAll();
    // test de l'activité
    ICacheLoader cacheLoader = new AbaqueDSLCacheLoader(tracabilite, Duration.ZERO);

    @SuppressWarnings("unchecked")
    BasicCache<AbaqueDSL> cache = (BasicCache<AbaqueDSL>) cacheLoader.initializeCache();

    cacheLoader.loadCache(cache);

    // On demande à PowerMock de vérifier la stack d'appel en fonction du scénario
    PowerMock.verifyAll();
  }

  /**
   * Tests if a list of AbaqueDSL is well written in the cache
   *
   * <b>Inputs:</b>Valid inputs (a list containing one abaqueDsl)<br/>
   * <b>Expected:</b><br/>
   *
   * @throws RavelException
   *           Thrown in case of error
   */
  @Test
  public void abaqueDslCacheLoader_LoadCacheOK_001() throws RavelException
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    List<AbaqueDSL> listeAbaqueDslExpected = new ArrayList<>();
    AbaqueDSL abaqueDSL = new AbaqueDSL(ReseauCollecte.BYTEL.name(), LigneMarche.GP.name(), NormeTechno.ADSL.name(), SensFlux.UP.name(), 1.0F, 1);
    listeAbaqueDslExpected.add(abaqueDSL);
    AbaqueDSL abaqueDSL2 = new AbaqueDSL(ReseauCollecte.BYTEL.name(), LigneMarche.GP.name(), NormeTechno.ADSL.name(), SensFlux.DOWN.name(), 1.0F, 1);
    listeAbaqueDslExpected.add(abaqueDSL2);
    AbaqueDSL abaqueDSL21 = new AbaqueDSL(ReseauCollecte.BYTEL.name(), LigneMarche.GP.name(), NormeTechno.ADSL.name(), SensFlux.DOWN.name(), 1.2F, 2);
    listeAbaqueDslExpected.add(abaqueDSL21);
    AbaqueDSL abaqueDSL3 = new AbaqueDSL(ReseauCollecte.BYTEL.name(), LigneMarche.ENT.name(), NormeTechno.ADSL.name(), SensFlux.DOWN.name(), 1.3F, 3);
    listeAbaqueDslExpected.add(abaqueDSL3);

    Retour expectedRetour = RetourFactory.createOkRetour();
    ConnectorResponse<Retour, List<AbaqueDSL>> expectedResponse = new ConnectorResponse<>(expectedRetour, listeAbaqueDslExpected);

    EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManager);
    EasyMock.expect(_connectorManager.getConnector(IRESConnector.BEAN_ID)).andReturn(_resConnector);
    EasyMock.expect(_resConnector.loadAbaqueDslLireTous(tracabilite)).andReturn(expectedResponse);

    // On enregistre le scénario des appels avant de lancer l'activité
    PowerMock.replayAll();
    // test de l'activité
    ICacheLoader cacheLoader = new AbaqueDSLCacheLoader(tracabilite, Duration.ZERO);

    @SuppressWarnings("unchecked")
    BasicCache<List<AbaqueDSL>> cache = (BasicCache<List<AbaqueDSL>>) cacheLoader.initializeCache();

    cacheLoader.loadCache(cache);

    // On demande à PowerMock de vérifier la stack d'appel en fonction du scénario
    PowerMock.verifyAll();

    // Assertions
    Assert.assertNotNull(cache);
    Assert.assertEquals("abaque_dsl", cacheLoader.getCacheId()); //$NON-NLS-1$
    Assert.assertEquals(abaqueDSL, cache.read(abaqueDSL.getKey()).get(0));
    Assert.assertEquals(abaqueDSL2, cache.read(abaqueDSL2.getKey()).get(0));
    Assert.assertEquals(abaqueDSL21, cache.read(abaqueDSL21.getKey()).get(1));
    Assert.assertEquals(abaqueDSL3, cache.read(abaqueDSL3.getKey()).get(0));
  }

  /**
   * Tests if the cache is valid when it is empty
   *
   * <b>Inputs:</b>A cache with an empty list of abaqueDsl<br/>
   * <b>Expected:</b>Method validateCache returns false<br/>
   *
   * @throws RavelException
   *           Thrown in case of error
   */
  @Test
  public void abaqueDslCacheLoader_ValidateCacheFalse_001() throws RavelException
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    List<AbaqueDSL> listeAbaqueDslExpected = new ArrayList<>();

    Retour expectedRetour = RetourFactory.createOkRetour();
    ConnectorResponse<Retour, List<AbaqueDSL>> expectedResponse = new ConnectorResponse<>(expectedRetour, listeAbaqueDslExpected);

    EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManager);
    EasyMock.expect(_connectorManager.getConnector(IRESConnector.BEAN_ID)).andReturn(_resConnector);
    EasyMock.expect(_resConnector.loadAbaqueDslLireTous(tracabilite)).andReturn(expectedResponse);

    // On enregistre le scénario des appels avant de lancer l'activité
    PowerMock.replayAll();
    // test de l'activité
    ICacheLoader cacheLoader = new AbaqueDSLCacheLoader(tracabilite, Duration.ZERO);

    @SuppressWarnings("unchecked")
    BasicCache<AbaqueDSL> cache = (BasicCache<AbaqueDSL>) cacheLoader.initializeCache();

    cacheLoader.loadCache(cache);

    // On demande à PowerMock de vérifier la stack d'appel en fonction du scénario
    PowerMock.verifyAll();

    Assert.assertFalse(cacheLoader.validateCache(cache));
  }

  /**
   * Tests if the cache is valid when null
   *
   * <b>Inputs:</b>A cache with no list of abaqueDsl<br/>
   * <b>Expected:</b>Method validateCache returns false<br/>
   *
   * @throws RavelException
   *           Thrown in case of error
   */
  @Test
  public void abaqueDslCacheLoader_ValidateCacheFalse_002() throws RavelException
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);

    Retour expectedRetour = RetourFactory.createOkRetour();
    ConnectorResponse<Retour, List<AbaqueDSL>> expectedResponse = new ConnectorResponse<>(expectedRetour, null);

    EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManager);
    EasyMock.expect(_connectorManager.getConnector(IRESConnector.BEAN_ID)).andReturn(_resConnector);
    EasyMock.expect(_resConnector.loadAbaqueDslLireTous(tracabilite)).andReturn(expectedResponse);

    // On enregistre le scénario des appels avant de lancer l'activité
    PowerMock.replayAll();
    // test de l'activité
    ICacheLoader cacheLoader = new AbaqueDSLCacheLoader(tracabilite, Duration.ZERO);

    @SuppressWarnings("unchecked")
    BasicCache<AbaqueDSL> cache = (BasicCache<AbaqueDSL>) cacheLoader.initializeCache();

    cacheLoader.loadCache(cache);

    // On demande à PowerMock de vérifier la stack d'appel en fonction du scénario
    PowerMock.verifyAll();

    Assert.assertFalse(cacheLoader.validateCache(cache));
  }

  /**
   * Tests if the cache is valid when the duration of cache is not expired
   *
   * <b>Inputs:</b>A cache with 10 min of validity<br/>
   * <b>Expected:</b>Method validateCache returns true<br/>
   *
   * @throws RavelException
   *           Thrown in case of error
   */
  @Test
  public void abaqueDslCacheLoader_ValidateCacheTrue_001() throws RavelException
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    List<AbaqueDSL> listeAbaqueDslExpected = Arrays.asList(_podam.manufacturePojo(AbaqueDSL.class));

    Retour expectedRetour = RetourFactory.createOkRetour();
    ConnectorResponse<Retour, List<AbaqueDSL>> expectedResponse = new ConnectorResponse<>(expectedRetour, listeAbaqueDslExpected);

    EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManager);
    EasyMock.expect(_connectorManager.getConnector(IRESConnector.BEAN_ID)).andReturn(_resConnector);
    EasyMock.expect(_resConnector.loadAbaqueDslLireTous(tracabilite)).andReturn(expectedResponse);

    // On enregistre le scénario des appels avant de lancer l'activité
    PowerMock.replayAll();
    // test de l'activité
    ICacheLoader cacheLoader = new AbaqueDSLCacheLoader(tracabilite, Duration.parse("PT10M")); //$NON-NLS-1$

    @SuppressWarnings("unchecked")
    BasicCache<AbaqueDSL> cache = (BasicCache<AbaqueDSL>) cacheLoader.initializeCache();

    cacheLoader.loadCache(cache);

    // On demande à PowerMock de vérifier la stack d'appel en fonction du scénario
    PowerMock.verifyAll();

    Assert.assertTrue(cacheLoader.validateCache(cache));
  }

  /**
   * Tests if the cache is valid when the duration of cache is not expired
   *
   * <b>Inputs:</b>A cache with 10 min of validity<br/>
   * <b>Expected:</b>Method validateCache returns true<br/>
   *
   * @throws RavelException
   *           Thrown in case of error
   */
  @Test
  public void abaqueDslCacheLoader_ValidateCacheTrue_002() throws RavelException
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    List<AbaqueDSL> listeAbaqueDslExpected = Arrays.asList(_podam.manufacturePojo(AbaqueDSL.class));

    Retour expectedRetour = RetourFactory.createOkRetour();
    ConnectorResponse<Retour, List<AbaqueDSL>> expectedResponse = new ConnectorResponse<>(expectedRetour, listeAbaqueDslExpected);

    EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManager);
    EasyMock.expect(_connectorManager.getConnector(IRESConnector.BEAN_ID)).andReturn(_resConnector);
    EasyMock.expect(_resConnector.loadAbaqueDslLireTous(tracabilite)).andReturn(expectedResponse);

    // On enregistre le scénario des appels avant de lancer l'activité
    PowerMock.replayAll();
    // test de l'activité
    ICacheLoader cacheLoader = new AbaqueDSLCacheLoader(tracabilite, Duration.ZERO);

    @SuppressWarnings("unchecked")
    BasicCache<AbaqueDSL> cache = (BasicCache<AbaqueDSL>) cacheLoader.initializeCache();

    cacheLoader.loadCache(cache);

    // On demande à PowerMock de vérifier la stack d'appel en fonction du scénario
    PowerMock.verifyAll();

    Assert.assertFalse(cacheLoader.validateCache(cache));
  }

  /**
   * Test initialization
   */
  @Before
  public void beforeTest()
  {
    // désactivation du cache podam
    _podam.getStrategy().setMemoization(false);

    PowerMock.resetAll();
    PowerMock.mockStaticStrict(RESConnector.class);
    PowerMock.mockStaticStrict(ConnectorManager.class);
  }
}
