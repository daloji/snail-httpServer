/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.res;

import java.util.List;

import org.easymock.EasyMock;
import org.easymock.EasyMockSupport;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockNice;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.IActivityCaller;
import com.bytel.spirit.common.connectors.res.activities.RES2103_RechercherCodeInseeAssocies;
import com.bytel.spirit.common.connectors.res.activities.RES2103_RechercherCodeInseeAssocies.RES2103_RechercherCodeInseeAssociesBuilder;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.response.ListeCommuneResponse;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author dangelis
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({ RESProxy.class })
public class RES2103_RechercherCodeInseeAssocies_Test extends EasyMockSupport
{
  /**
   *
   */
  private RES2103_RechercherCodeInseeAssocies _activite;
  /**
   * Factory de génération des beans
   */
  private PodamFactory _podam = new PodamFactoryImpl();

  /**
   * Mock de {@link RESProxy}
   */
  @MockStrict
  RESProxy _resProxy;

  /**
   * Mock de {@link IActivityCaller}
   */
  @MockNice
  IActivityCaller _activityCallerMock;

  /**
   *
   */
  @Before
  public void beforeTest()
  {

    // désactivation du cache podam
    _podam.getStrategy().setMemoization(false);

    // on réinitialise tous les mocks afin de ne pas avoir d'interférence entre les tests
    PowerMock.resetAll();

    // On initialise toutes les classes à mocker comportant un appel à un eméthode statique
    // Dans notre cas on mock statiquemement toutes les classes des activités et des proxys appelés (pour les createContexte et le getInstance)
    PowerMock.mockStaticStrict(RES2103_RechercherCodeInseeAssocies.class);
    PowerMock.mockStaticStrict(RESProxy.class);
  }

  /**
   * builder incorrect
   *
   * @throws RavelException
   *           RavelException
   */
  @Test
  public void test001() throws RavelException
  {

    _activite = new RES2103_RechercherCodeInseeAssociesBuilder().build();
    Assert.assertEquals(StringConstants.NOK, _activite.getRetour().getResultat());
    Assert.assertEquals("CAT-3", _activite.getRetour().getCategorie()); //$NON-NLS-1$
    Assert.assertEquals("Parametre d'entree de l'activite non renseignee", _activite.getRetour().getLibelle()); //$NON-NLS-1$
  }

  /**
   * Nominal ancien codeInsee
   *
   * @throws RavelException
   *           RavelException
   */
  @Test
  public void test002() throws RavelException
  {
    String codeInsee_p = "12344"; //$NON-NLS-1$
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    Retour expectedRetour = RetourFactory.createOkRetour();
    String json = "\n{\n\t\"retour\": {\n\t\t\"resultat\": \"OK\"\n\t},\n\t\"listeCommune\": [\n\t\t{ \t\"codeInsee\": \"10899\",\n\t\t\t\"nomCommune\": \"MaCommune1\",\n\t\t\t\"ancienCodeInsee\": \"10888\",\n\t\t\t\"listeCodePostal\": [\n\t\t\t\t\"59188\",\n\t\t\t\t\"59189\"\n\t\t\t],\n\t\t\t\"listeNomAlternatif\": [\n\t\t\t\t{\"provenance\": \"SNA\", \"nomCommune\": \"MaCom1\"},\n\t\t\t\t{\"provenance\": \"42R4\", \"nomCommune\": \"UneCommune\"}\n\t\t\t]\n\t\t},\n\t\t{ \t\"codeInsee\": \"10899\",\n\t\t\t\"nomCommune\": \"MaCommune2\",\n\t\t\t\"ancienCodeInsee\": \"10888\",\n\t\t\t\"listeCodePostal\": [\n\t\t\t\t\"59187\"\n\t\t\t]\n\t\t}\n\t]\n}\n\n"; //$NON-NLS-1$
    ListeCommuneResponse listeCommune = GsonTools.getInstance().fromJson(json, ListeCommuneResponse.class);
    ConnectorResponse<Retour, ListeCommuneResponse> expectedResponse = new ConnectorResponse<Retour, ListeCommuneResponse>(expectedRetour, listeCommune);
    _activite = new RES2103_RechercherCodeInseeAssociesBuilder().tracabilite(tracabilite).codeInsee(codeInsee_p).build();
    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxy);
    EasyMock.expect(_resProxy.pad3001CommuneReadAncienCodeInsee(tracabilite, codeInsee_p)).andReturn(expectedResponse);
    PowerMock.replayAll();
    List<String> result = _activite.execute(_activityCallerMock);
    PowerMock.verifyAll();
    Assert.assertEquals(expectedRetour, _activite.getRetour());
    Assert.assertEquals(expectedResponse._second.getListeCommune().get(0).getAncienCodeInsee(), result.get(0));
  }

  /**
   * Code insee invalide
   *
   * @throws RavelException
   *           RavelException
   */
  @Test
  public void test003() throws RavelException
  {
    String codeInsee_p = "123445"; //$NON-NLS-1$
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    Retour expectedRetour = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ENTREE_INCORRECTE, "Code insee 123445 invalide"); //$NON-NLS-1$
    _activite = new RES2103_RechercherCodeInseeAssociesBuilder().tracabilite(tracabilite).codeInsee(codeInsee_p).build();
    List<String> result = _activite.execute(_activityCallerMock);
    Assert.assertEquals(expectedRetour, _activite.getRetour());
    Assert.assertEquals(result.size(), 0);
  }

  /**
   * Nominal ancien code insee avec anciencodeInsee vide pour unne commune
   *
   * @throws RavelException
   *           RavelException
   */
  @Test
  public void test004() throws RavelException
  {
    String codeInsee_p = "12344"; //$NON-NLS-1$
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    Retour expectedRetour = RetourFactory.createOkRetour();
    String json = "\n{\n\t\"retour\": {\n\t\t\"resultat\": \"OK\"\n\t},\n\t\"listeCommune\": [\n\t\t{ \t\"codeInsee\": \"10899\",\n\t\t\t\"nomCommune\": \"MaCommune1\",\n\t\t\t\"ancienCodeInsee\": \"\",\n\t\t\t\"listeCodePostal\": [\n\t\t\t\t\"59188\",\n\t\t\t\t\"59189\"\n\t\t\t],\n\t\t\t\"listeNomAlternatif\": [\n\t\t\t\t{\"provenance\": \"SNA\", \"nomCommune\": \"MaCom1\"},\n\t\t\t\t{\"provenance\": \"42R4\", \"nomCommune\": \"UneCommune\"}\n\t\t\t]\n\t\t},\n\t\t{ \t\"codeInsee\": \"10899\",\n\t\t\t\"nomCommune\": \"MaCommune2\",\n\t\t\t\"ancienCodeInsee\": \"10888\",\n\t\t\t\"listeCodePostal\": [\n\t\t\t\t\"59187\"\n\t\t\t]\n\t\t}\n\t]\n}\n\n"; //$NON-NLS-1$
    ListeCommuneResponse listeCommune = GsonTools.getInstance().fromJson(json, ListeCommuneResponse.class);
    ConnectorResponse<Retour, ListeCommuneResponse> expectedResponse = new ConnectorResponse<Retour, ListeCommuneResponse>(expectedRetour, listeCommune);
    _activite = new RES2103_RechercherCodeInseeAssociesBuilder().tracabilite(tracabilite).codeInsee(codeInsee_p).build();
    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxy);
    EasyMock.expect(_resProxy.pad3001CommuneReadAncienCodeInsee(tracabilite, codeInsee_p)).andReturn(expectedResponse);
    PowerMock.replayAll();
    List<String> result = _activite.execute(_activityCallerMock);
    PowerMock.verifyAll();
    Assert.assertEquals(expectedRetour, _activite.getRetour());
    Assert.assertEquals(expectedResponse._second.getListeCommune().get(1).getAncienCodeInsee(), result.get(0));
  }

  /**
   * Nominal avec ancien code insee et code insee
   *
   * @throws RavelException
   *           RavelException
   */
  @Test
  public void test005() throws RavelException
  {
    String codeInsee_p = "12344"; //$NON-NLS-1$
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    Retour expectedRetour = RetourFactory.createOkRetour();
    Retour expectedRetour1 = RetourFactory.createNOK("CAT-4", "CODE_INSEE_INCONNU", "Code insee 10899 inconnu"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    String json = "\n{\n\t\"retour\": {\n\t\t\"resultat\": \"OK\"\n\t},\n\t\"listeCommune\": [\n\t\t{ \t\"codeInsee\": \"10899\",\n\t\t\t\"nomCommune\": \"MaCommune1\",\n\t\t\t\"ancienCodeInsee\": \"\",\n\t\t\t\"listeCodePostal\": [\n\t\t\t\t\"59188\",\n\t\t\t\t\"59189\"\n\t\t\t],\n\t\t\t\"listeNomAlternatif\": [\n\t\t\t\t{\"provenance\": \"SNA\", \"nomCommune\": \"MaCom1\"},\n\t\t\t\t{\"provenance\": \"42R4\", \"nomCommune\": \"UneCommune\"}\n\t\t\t]\n\t\t},\n\t\t{ \t\"codeInsee\": \"10899\",\n\t\t\t\"nomCommune\": \"MaCommune2\",\n\t\t\t\"ancienCodeInsee\": \"10888\",\n\t\t\t\"listeCodePostal\": [\n\t\t\t\t\"59187\"\n\t\t\t]\n\t\t}\n\t]\n}\n\n"; //$NON-NLS-1$
    ListeCommuneResponse listeCommune = GsonTools.getInstance().fromJson(json, ListeCommuneResponse.class);
    ConnectorResponse<Retour, ListeCommuneResponse> expectedResponse = new ConnectorResponse<Retour, ListeCommuneResponse>(expectedRetour1, null);
    ConnectorResponse<Retour, ListeCommuneResponse> expectedResponse1 = new ConnectorResponse<Retour, ListeCommuneResponse>(expectedRetour, listeCommune);
    _activite = new RES2103_RechercherCodeInseeAssociesBuilder().tracabilite(tracabilite).codeInsee(codeInsee_p).build();
    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxy);
    EasyMock.expect(_resProxy.pad3001CommuneReadAncienCodeInsee(tracabilite, codeInsee_p)).andReturn(expectedResponse);
    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxy);
    EasyMock.expect(_resProxy.pad3001CommuneReadCodeInsee(tracabilite, codeInsee_p)).andReturn(expectedResponse1);
    PowerMock.replayAll();
    List<String> result = _activite.execute(_activityCallerMock);
    PowerMock.verifyAll();
    Assert.assertEquals(expectedRetour, _activite.getRetour());
    Assert.assertEquals(expectedResponse1._second.getListeCommune().get(1).getAncienCodeInsee(), result.get(0));
  }

  /**
   * Erreur avec ancien code insee et codeinsee
   *
   * @throws RavelException
   *           RavelException
   */
  @Test
  public void test006() throws RavelException
  {
    String codeInsee_p = "12344"; //$NON-NLS-1$
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    Retour expectedRetour = RetourFactory.createNOK("CAT-4", "CODE_INSEE_INCONNU", "Code insee 12344 inconnu"); //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$
    ConnectorResponse<Retour, ListeCommuneResponse> expectedResponse = new ConnectorResponse<Retour, ListeCommuneResponse>(expectedRetour, null);
    ConnectorResponse<Retour, ListeCommuneResponse> expectedResponse1 = new ConnectorResponse<Retour, ListeCommuneResponse>(expectedRetour, null);
    _activite = new RES2103_RechercherCodeInseeAssociesBuilder().tracabilite(tracabilite).codeInsee(codeInsee_p).build();
    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxy);
    EasyMock.expect(_resProxy.pad3001CommuneReadAncienCodeInsee(tracabilite, codeInsee_p)).andReturn(expectedResponse);
    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxy);
    EasyMock.expect(_resProxy.pad3001CommuneReadCodeInsee(tracabilite, codeInsee_p)).andReturn(expectedResponse1);
    PowerMock.replayAll();
    _activite.execute(_activityCallerMock);
    PowerMock.verifyAll();
    Assert.assertEquals(expectedRetour, _activite.getRetour());

  }

}
