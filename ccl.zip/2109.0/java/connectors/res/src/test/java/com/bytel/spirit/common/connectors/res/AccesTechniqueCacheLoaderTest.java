/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.res;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.easymock.EasyMock;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.cache.BasicCache;
import com.bytel.ravel.common.cache.ICacheLoader;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.services.connector.ConnectorManager;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.IActivityCaller;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.AccesTechnique;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 * @author jpais
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({ RESConnector.class, ConnectorManager.class })
public class AccesTechniqueCacheLoaderTest
{
  /**
   * Bean generation factory
   */
  private PodamFactory _podam = new PodamFactoryImpl();

  /**
   * {@link IActivityCaller} mock
   */
  IActivityCaller _activityCallerMock;

  /**
   * {@link RESConnector} mock
   */
  @MockStrict
  RESConnector _resConnector;

  /**
   * {@link ConnectorManager} mock
   */
  @MockStrict
  ConnectorManager _connectorManager;

  /**
   * Tests if a list of AccesTechnique is well written in the cache
   *
   * <b>Inputs:</b>Valid inputs (a list containing one AccesTechnique)<br/>
   * <b>Expected:</b><br/>
   *
   * @throws RavelException
   *           Thrown in case of error
   */
  @Test
  public void accesTechniqueCacheLoader_LoadCacheKO_001() throws RavelException
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);

    EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManager);
    EasyMock.expect(_connectorManager.getConnector(IRESConnector.BEAN_ID)).andReturn(_resConnector);

    RavelException ravelExceptionExpected = new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.KO_00000, StringConstants.EMPTY_STRING);
    EasyMock.expect(_resConnector.loadAccesTechniqueLireTous(tracabilite)).andThrow(ravelExceptionExpected);

    // On enregistre le scénario des appels avant de lancer l'activité
    PowerMock.replayAll();
    // test de l'activité
    ICacheLoader cacheLoader = new AccesTechniqueCacheLoader(tracabilite, Duration.ZERO);

    @SuppressWarnings("unchecked")
    BasicCache<AccesTechnique> cache = (BasicCache<AccesTechnique>) cacheLoader.initializeCache();

    cacheLoader.loadCache(cache);

    // On demande à PowerMock de vérifier la stack d'appel en fonction du scénario
    PowerMock.verifyAll();
  }

  /**
   * Tests if a list of AccesTechnique is well written in the cache
   *
   * <b>Inputs:</b>Valid inputs (a list containing one accesTechnique)<br/>
   * <b>Expected:</b><br/>
   *
   * @throws RavelException
   *           Thrown in case of error
   */
  @Test
  public void accesTechniqueCacheLoader_LoadCacheOK_001() throws RavelException
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    List<AccesTechnique> listeAccesTechniqueExpected = new ArrayList<>();
    listeAccesTechniqueExpected.add(_podam.manufacturePojo(AccesTechnique.class));
    listeAccesTechniqueExpected.add(_podam.manufacturePojo(AccesTechnique.class));
    listeAccesTechniqueExpected.add(_podam.manufacturePojo(AccesTechnique.class));
    listeAccesTechniqueExpected.add(_podam.manufacturePojo(AccesTechnique.class));
    listeAccesTechniqueExpected.add(_podam.manufacturePojo(AccesTechnique.class));

    Retour expectedRetour = RetourFactory.createOkRetour();
    ConnectorResponse<Retour, List<AccesTechnique>> expectedResponse = new ConnectorResponse<>(expectedRetour, listeAccesTechniqueExpected);

    EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManager);
    EasyMock.expect(_connectorManager.getConnector(IRESConnector.BEAN_ID)).andReturn(_resConnector);
    EasyMock.expect(_resConnector.loadAccesTechniqueLireTous(tracabilite)).andReturn(expectedResponse);

    // On enregistre le scénario des appels avant de lancer l'activité
    PowerMock.replayAll();
    // test de l'activité
    ICacheLoader cacheLoader = new AccesTechniqueCacheLoader(tracabilite, Duration.ZERO);

    @SuppressWarnings("unchecked")
    BasicCache<AccesTechnique> cache = (BasicCache<AccesTechnique>) cacheLoader.initializeCache();

    cacheLoader.loadCache(cache);

    // On demande à PowerMock de vérifier la stack d'appel en fonction du scénario
    PowerMock.verifyAll();

    // Assertions
    Assert.assertNotNull(cache);
    Assert.assertEquals("acces_technique", cacheLoader.getCacheId()); //$NON-NLS-1$
    listeAccesTechniqueExpected.forEach(accesTechnique -> Assert.assertEquals(accesTechnique, cache.read(accesTechnique.getCodeAccesTechnique())));
  }

  /**
   * Tests if the cache is valid when it is empty
   *
   * <b>Inputs:</b>A cache with an empty list of accesTechnique<br/>
   * <b>Expected:</b>Method validateCache returns false<br/>
   *
   * @throws RavelException
   *           Thrown in case of error
   */
  @Test
  public void accesTechniqueCacheLoader_ValidateCacheFalse_001() throws RavelException
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    List<AccesTechnique> listeAccesTechniqueExpected = new ArrayList<>();

    Retour expectedRetour = RetourFactory.createOkRetour();
    ConnectorResponse<Retour, List<AccesTechnique>> expectedResponse = new ConnectorResponse<>(expectedRetour, listeAccesTechniqueExpected);

    EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManager);
    EasyMock.expect(_connectorManager.getConnector(IRESConnector.BEAN_ID)).andReturn(_resConnector);
    EasyMock.expect(_resConnector.loadAccesTechniqueLireTous(tracabilite)).andReturn(expectedResponse);

    // On enregistre le scénario des appels avant de lancer l'activité
    PowerMock.replayAll();
    // test de l'activité
    ICacheLoader cacheLoader = new AccesTechniqueCacheLoader(tracabilite, Duration.ZERO);

    @SuppressWarnings("unchecked")
    BasicCache<AccesTechnique> cache = (BasicCache<AccesTechnique>) cacheLoader.initializeCache();

    cacheLoader.loadCache(cache);

    // On demande à PowerMock de vérifier la stack d'appel en fonction du scénario
    PowerMock.verifyAll();

    Assert.assertFalse(cacheLoader.validateCache(cache));
  }

  /**
   * Tests if the cache is valid when null
   *
   * <b>Inputs:</b>A cache with no list of accesTechnique<br/>
   * <b>Expected:</b>Method validateCache returns false<br/>
   *
   * @throws RavelException
   *           Thrown in case of error
   */
  @Test
  public void accesTechniqueCacheLoader_ValidateCacheFalse_002() throws RavelException
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);

    Retour expectedRetour = RetourFactory.createOkRetour();
    ConnectorResponse<Retour, List<AccesTechnique>> expectedResponse = new ConnectorResponse<>(expectedRetour, null);

    EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManager);
    EasyMock.expect(_connectorManager.getConnector(IRESConnector.BEAN_ID)).andReturn(_resConnector);
    EasyMock.expect(_resConnector.loadAccesTechniqueLireTous(tracabilite)).andReturn(expectedResponse);

    // On enregistre le scénario des appels avant de lancer l'activité
    PowerMock.replayAll();
    // test de l'activité
    ICacheLoader cacheLoader = new AccesTechniqueCacheLoader(tracabilite, Duration.ZERO);

    @SuppressWarnings("unchecked")
    BasicCache<AccesTechnique> cache = (BasicCache<AccesTechnique>) cacheLoader.initializeCache();

    cacheLoader.loadCache(cache);

    // On demande à PowerMock de vérifier la stack d'appel en fonction du scénario
    PowerMock.verifyAll();

    Assert.assertFalse(cacheLoader.validateCache(cache));
  }

  /**
   * Tests if the cache is valid when the duration of cache is not expired
   *
   * <b>Inputs:</b>A cache with 10 min of validity<br/>
   * <b>Expected:</b>Method validateCache returns true<br/>
   *
   * @throws RavelException
   *           Thrown in case of error
   */
  @Test
  public void accesTechniqueCacheLoader_ValidateCacheTrue_001() throws RavelException
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    List<AccesTechnique> listeAccesTechniqueExpected = Arrays.asList(_podam.manufacturePojo(AccesTechnique.class));

    Retour expectedRetour = RetourFactory.createOkRetour();
    ConnectorResponse<Retour, List<AccesTechnique>> expectedResponse = new ConnectorResponse<>(expectedRetour, listeAccesTechniqueExpected);

    EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManager);
    EasyMock.expect(_connectorManager.getConnector(IRESConnector.BEAN_ID)).andReturn(_resConnector);
    EasyMock.expect(_resConnector.loadAccesTechniqueLireTous(tracabilite)).andReturn(expectedResponse);

    // On enregistre le scénario des appels avant de lancer l'activité
    PowerMock.replayAll();
    // test de l'activité
    ICacheLoader cacheLoader = new AccesTechniqueCacheLoader(tracabilite, Duration.parse("PT10M")); //$NON-NLS-1$

    @SuppressWarnings("unchecked")
    BasicCache<AccesTechnique> cache = (BasicCache<AccesTechnique>) cacheLoader.initializeCache();

    cacheLoader.loadCache(cache);

    // On demande à PowerMock de vérifier la stack d'appel en fonction du scénario
    PowerMock.verifyAll();

    Assert.assertTrue(cacheLoader.validateCache(cache));
  }

  /**
   * Tests if the cache is valid when the duration of cache is not expired
   *
   * <b>Inputs:</b>A cache with 10 min of validity<br/>
   * <b>Expected:</b>Method validateCache returns true<br/>
   *
   * @throws RavelException
   *           Thrown in case of error
   */
  @Test
  public void accesTechniqueCacheLoader_ValidateCacheTrue_002() throws RavelException
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    List<AccesTechnique> listeAccesTechniqueExpected = Arrays.asList(_podam.manufacturePojo(AccesTechnique.class));

    Retour expectedRetour = RetourFactory.createOkRetour();
    ConnectorResponse<Retour, List<AccesTechnique>> expectedResponse = new ConnectorResponse<>(expectedRetour, listeAccesTechniqueExpected);

    EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManager);
    EasyMock.expect(_connectorManager.getConnector(IRESConnector.BEAN_ID)).andReturn(_resConnector);
    EasyMock.expect(_resConnector.loadAccesTechniqueLireTous(tracabilite)).andReturn(expectedResponse);

    // On enregistre le scénario des appels avant de lancer l'activité
    PowerMock.replayAll();
    // test de l'activité
    ICacheLoader cacheLoader = new AccesTechniqueCacheLoader(tracabilite, Duration.ZERO);

    @SuppressWarnings("unchecked")
    BasicCache<AccesTechnique> cache = (BasicCache<AccesTechnique>) cacheLoader.initializeCache();

    cacheLoader.loadCache(cache);

    // On demande à PowerMock de vérifier la stack d'appel en fonction du scénario
    PowerMock.verifyAll();

    Assert.assertFalse(cacheLoader.validateCache(cache));
  }

  /**
   * Test initialization
   */
  @Before
  public void beforeTest()
  {
    // désactivation du cache podam
    _podam.getStrategy().setMemoization(false);

    PowerMock.resetAll();
    PowerMock.mockStaticStrict(RESConnector.class);
    PowerMock.mockStaticStrict(ConnectorManager.class);
  }
}
