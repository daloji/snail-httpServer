/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.res;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;

import java.text.MessageFormat;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.bytel.spirit.common.shared.saab.res.Couverture5GENT;
import com.bytel.spirit.common.shared.saab.res.TypeCouverture5G;
import org.easymock.EasyMock;
import org.easymock.EasyMockSupport;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockListener;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.testlisteners.FieldDefaulter;
import org.powermock.modules.junit4.PowerMockRunner;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.probes.AvgDoubleCollectorItem;
import com.bytel.ravel.common.probes.AvgFlowPerSecondCollector;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.RetourFactoryForTU;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.services.connector.ConnectorManager;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.ressources.RetourConverter;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.CompteRenduSuppression;
import com.bytel.spirit.common.shared.saab.res.Couverture5G;
import com.bytel.spirit.common.shared.saab.res.EntonnoirCommune;
import com.bytel.spirit.common.shared.saab.res.EntonnoirNumero;
import com.bytel.spirit.common.shared.saab.res.EntonnoirVoie;
import com.bytel.spirit.common.shared.saab.res.OltComposite;
import com.bytel.spirit.common.shared.saab.res.PMComposite;
import com.bytel.spirit.common.shared.saab.res.PointAncrageIPCollecte;
import com.bytel.spirit.common.shared.saab.res.Ressource;
import com.bytel.spirit.common.shared.saab.res.RessourceAggrege;
import com.bytel.spirit.common.shared.saab.res.request.ManageNoeudRaccordementRequest;
import com.bytel.spirit.common.shared.saab.res.response.GetSurchargeResponse;
import com.bytel.spirit.common.shared.types.json.response.PMConsultResponse;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 * @author jramos
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PowerMockListener(FieldDefaulter.class)
@PrepareForTest({ RESProxy.class, ConnectorManager.class })
public class RESProxyTest extends EasyMockSupport
{
  /**
   * Factory to generate beans
   */
  private static PodamFactory __podam;

  /**
   * Initialize before all tests
   *
   * @throws Exception
   *           Exception to be thrown in case of failure
   */
  @SuppressWarnings("unchecked")
  @BeforeClass
  public static void setUpBeforeClass() throws Exception
  {
    __podam = new PodamFactoryImpl();
    __podam.getStrategy().setMemoization(false);
    __podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());
  }

  /**
   * The mock object {@code ConnectorManager}
   */
  @MockStrict
  private ConnectorManager _connectorManagerMock;

  /**
   * The mock object {@code IUsageDataConnector}
   */
  @MockStrict
  private IRESConnector _iresConnectorMock;

  /**
   * Object {@code AbstractConnectorCallTask} to evaluate
   */
  private RESProxy _instance;

  /**
   * Exception has been thrown
   */
  private boolean _exception;

  private Tracabilite _tracabilite;

  /**
   * The mock object {@code AvgFlowPerSecondCollector}
   */
  @MockStrict
  AvgFlowPerSecondCollector _avgCallCounterMock;

  /**
   * The mock object {@code AvgDoubleCollectorItem}
   */
  @MockStrict
  AvgDoubleCollectorItem _avgExecTimeMock;

  /**
   * Test the method {@link RESProxy#entonnoirCommuneLireTousParCodeInsee} Exception.
   *
   * @IN - Parameter codeInsee.
   * @OUT - Retour NOK CAT2 , List EntonnoirCommune null
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public final void entonnoirCommuneLireTousParCodeInsee_Exception() throws Exception
  {

    final ConnectorResponse<Retour, List<EntonnoirCommune>> expected = new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID)), null); //$NON-NLS-1$
    ConnectorResponse<Retour, List<EntonnoirCommune>> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andThrow(new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.MGRCTR_00002, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID))).once(); //$NON-NLS-1$

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();
      actual = _instance.entonnoirCommuneLireTousParCodeInsee(_tracabilite, "12345");//$NON-NLS-1$
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#entonnoirCommuneLireTousParCodeInsee} OK.
   *
   * @IN - Parameter codeInsee.
   * @OUT - Retour OK , List EntonnoirCommune with 1 element.
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public final void entonnoirCommuneLireTousParCodeInsee_OK() throws Exception
  {

    EntonnoirCommune entonnoirCommune = new EntonnoirCommune("codePostal_123", "12345", "libelle_123", true, false, "departement_123"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$

    final ConnectorResponse<Retour, List<EntonnoirCommune>> expected = new ConnectorResponse<>(RetourFactory.createOkRetour(), Collections.singletonList(entonnoirCommune));
    ConnectorResponse<Retour, List<EntonnoirCommune>> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();

      EasyMock.expect(_iresConnectorMock.entonnoirCommuneLireTousParCodeInsee(_tracabilite, "12345")).andReturn(expected);//$NON-NLS-1$

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();

      actual = _instance.entonnoirCommuneLireTousParCodeInsee(_tracabilite, "12345");//$NON-NLS-1$
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#entonnoirCommuneLireTousParCodePostal} Exception.
   *
   * @IN - Parameter codePostal.
   * @OUT - Retour NOK CAT2 , List EntonnoirCommune null
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public final void entonnoirCommuneLireTousParCodePostal_Exception() throws Exception
  {

    final ConnectorResponse<Retour, List<EntonnoirCommune>> expected = new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID)), null); //$NON-NLS-1$
    ConnectorResponse<Retour, List<EntonnoirCommune>> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andThrow(new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.MGRCTR_00002, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID))).once(); //$NON-NLS-1$

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();
      actual = _instance.entonnoirCommuneLireTousParCodePostal(_tracabilite, "12345");//$NON-NLS-1$
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#entonnoirCommuneLireTousParCodeInsee} OK.
   *
   * @IN - Parameter codePostal.
   * @OUT - Retour OK , List EntonnoirCommune with 1 element.
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public final void entonnoirCommuneLireTousParCodePostal_OK() throws Exception
  {

    EntonnoirCommune entonnoirCommune = new EntonnoirCommune("12345", "codeInsee_123", "libelle_123", true, false, "departement_123"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$

    final ConnectorResponse<Retour, List<EntonnoirCommune>> expected = new ConnectorResponse<>(RetourFactory.createOkRetour(), Collections.singletonList(entonnoirCommune));
    ConnectorResponse<Retour, List<EntonnoirCommune>> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();

      EasyMock.expect(_iresConnectorMock.entonnoirCommuneLireTousParCodePostal(_tracabilite, "12345")).andReturn(expected);//$NON-NLS-1$

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();

      actual = _instance.entonnoirCommuneLireTousParCodePostal(_tracabilite, "12345");//$NON-NLS-1$
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#entonnoirCommuneLireTousParDepartement} Exception.
   *
   * @IN - Parameter departement.
   * @OUT - Retour NOK CAT2 , List EntonnoirCommune null
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public final void entonnoirCommuneLireTousParDepartement_Exception() throws Exception
  {

    final ConnectorResponse<Retour, List<EntonnoirCommune>> expected = new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID)), null); //$NON-NLS-1$
    ConnectorResponse<Retour, List<EntonnoirCommune>> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andThrow(new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.MGRCTR_00002, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID))).once(); //$NON-NLS-1$

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();
      actual = _instance.entonnoirCommuneLireTousParDepartement(_tracabilite, "12345");//$NON-NLS-1$
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#entonnoirCommuneLireTousParDepartement} OK.
   *
   * @IN - Parameter departement.
   * @OUT - Retour OK , List EntonnoirCommune with 1 element.
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public final void entonnoirCommuneLireTousParDepartement_OK() throws Exception
  {

    EntonnoirCommune entonnoirCommune = new EntonnoirCommune("codePostal_123", "codeInsee_123", "libelle_123", true, false, "12345"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$

    final ConnectorResponse<Retour, List<EntonnoirCommune>> expected = new ConnectorResponse<>(RetourFactory.createOkRetour(), Collections.singletonList(entonnoirCommune));
    ConnectorResponse<Retour, List<EntonnoirCommune>> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();

      EasyMock.expect(_iresConnectorMock.entonnoirCommuneLireTousParDepartement(_tracabilite, "12345")).andReturn(expected);//$NON-NLS-1$

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();

      actual = _instance.entonnoirCommuneLireTousParDepartement(_tracabilite, "12345");//$NON-NLS-1$
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#entonnoirNumeroLireTousParCodeInseeCodeRivoli} Exception.
   *
   * @IN - Parameter codeInsee, codeRivoli.
   * @OUT - Retour NOK CAT2 , List EntonnoirNumero null
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public final void entonnoirNumeroLireTousParCodeInseeCodeRivoli_Exception() throws Exception
  {

    final ConnectorResponse<Retour, List<EntonnoirNumero>> expected = new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID)), null); //$NON-NLS-1$
    ConnectorResponse<Retour, List<EntonnoirNumero>> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andThrow(new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.MGRCTR_00002, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID))).once(); //$NON-NLS-1$

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();
      actual = _instance.entonnoirNumeroLireTousParCodeInseeCodeRivoli(_tracabilite, "12345", "54321");//$NON-NLS-1$
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#entonnoirNumeroLireTousParCodeInseeCodeRivoli} OK.
   *
   * @IN - Parameter codeInsee, codeRivoli.
   * @OUT - Retour OK , List EntonnoirNumero with 1 element.
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public final void entonnoirNumeroLireTousParCodeInseeCodeRivoli_OK() throws Exception
  {

    EntonnoirNumero entonnoirNumero = new EntonnoirNumero("12345", "similiHexacle0_123", 123, "hexacleInterne_123", "idAdresseBytel_123"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$

    final ConnectorResponse<Retour, List<EntonnoirNumero>> expected = new ConnectorResponse<>(RetourFactory.createOkRetour(), Collections.singletonList(entonnoirNumero));
    ConnectorResponse<Retour, List<EntonnoirNumero>> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();

      EasyMock.expect(_iresConnectorMock.entonnoirNumeroLireTousParCodeInseeCodeRivoli(_tracabilite, "12345", "54321")).andReturn(expected);//$NON-NLS-1$

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();

      actual = _instance.entonnoirNumeroLireTousParCodeInseeCodeRivoli(_tracabilite, "12345", "54321");//$NON-NLS-1$
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#entonnoirNumeroLireTousParCodeInseeSimiliHexacle0} Exception.
   *
   * @IN - Parameter codeInsee, similiHexacle0.
   * @OUT - Retour NOK CAT2 , List EntonnoirNumero null
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public final void entonnoirNumeroLireTousParCodeInseeSimiliHexacle0_Exception() throws Exception
  {

    final ConnectorResponse<Retour, List<EntonnoirNumero>> expected = new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID)), null); //$NON-NLS-1$
    ConnectorResponse<Retour, List<EntonnoirNumero>> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andThrow(new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.MGRCTR_00002, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID))).once(); //$NON-NLS-1$

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();
      actual = _instance.entonnoirNumeroLireTousParCodeInseeSimiliHexacle0(_tracabilite, "12345", "54321");//$NON-NLS-1$
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#entonnoirNumeroLireTousParCodeInseeSimiliHexacle0} OK.
   *
   * @IN - Parameter codeInsee, similiHexacle0.
   * @OUT - Retour OK , List EntonnoirNumero with 1 element.
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public final void entonnoirNumeroLireTousParCodeInseeSimiliHexacle0_OK() throws Exception
  {

    EntonnoirNumero entonnoirNumero = new EntonnoirNumero("12345", "54321", 123, "hexacleInterne_123", "idAdresseBytel_123"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$

    final ConnectorResponse<Retour, List<EntonnoirNumero>> expected = new ConnectorResponse<>(RetourFactory.createOkRetour(), Collections.singletonList(entonnoirNumero));
    ConnectorResponse<Retour, List<EntonnoirNumero>> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();

      EasyMock.expect(_iresConnectorMock.entonnoirNumeroLireTousParCodeInseeSimiliHexacle0(_tracabilite, "12345", "54321")).andReturn(expected);//$NON-NLS-1$

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();

      actual = _instance.entonnoirNumeroLireTousParCodeInseeSimiliHexacle0(_tracabilite, "12345", "54321");//$NON-NLS-1$
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#entonnoirVoieLireTousParCodeInsee} Exception.
   *
   * @IN - Parameter codeInsee.
   * @OUT - Retour NOK CAT2 , List EntonnoirVoie null
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public final void entonnoirVoieLireTousParCodeInsee_Exception() throws Exception
  {

    final ConnectorResponse<Retour, List<EntonnoirVoie>> expected = new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID)), null); //$NON-NLS-1$
    ConnectorResponse<Retour, List<EntonnoirVoie>> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andThrow(new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.MGRCTR_00002, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID))).once(); //$NON-NLS-1$

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();
      actual = _instance.entonnoirVoieLireTousParCodeInsee(_tracabilite, "12345");//$NON-NLS-1$
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#entonnoirVoieLireTousParCodeInsee} OK.
   *
   * @IN - Parameter codeInsee.
   * @OUT - Retour OK , List EntonnoirVoie with 1 element.
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public final void entonnoirVoieLireTousParCodeInsee_OK() throws Exception
  {

    EntonnoirVoie entonnoirVoie = new EntonnoirVoie("codeInsee_123", "similiHexacle0_123", "libelleNormalise_123", true); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    final ConnectorResponse<Retour, List<EntonnoirVoie>> expected = new ConnectorResponse<>(RetourFactory.createOkRetour(), Collections.singletonList(entonnoirVoie));
    ConnectorResponse<Retour, List<EntonnoirVoie>> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();

      EasyMock.expect(_iresConnectorMock.entonnoirVoieLireTousParCodeInsee(_tracabilite, "12345")).andReturn(expected);//$NON-NLS-1$

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();

      actual = _instance.entonnoirVoieLireTousParCodeInsee(_tracabilite, "12345");//$NON-NLS-1$
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#entonnoirVoieLireUnParCodeInseeCodeRivoli} Exception.
   *
   * @IN - Parameter codeInsee, codeRivoli.
   * @OUT - Retour NOK CAT2 , List EntonnoirVoie null
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public final void entonnoirVoieLireUnParCodeInseeCodeRivoli_Exception() throws Exception
  {

    final ConnectorResponse<Retour, List<EntonnoirVoie>> expected = new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID)), null); //$NON-NLS-1$
    ConnectorResponse<Retour, List<EntonnoirVoie>> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andThrow(new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.MGRCTR_00002, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID))).once(); //$NON-NLS-1$

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();
      actual = _instance.entonnoirVoieLireUnParCodeInseeCodeRivoli(_tracabilite, "12345", "54321");//$NON-NLS-1$
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#entonnoirVoieLireUnParCodeInseeCodeRivoli} OK.
   *
   * @IN - Parameter codeInsee, codeRivoli.
   * @OUT - Retour OK , List EntonnoirVoie with 1 element.
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public final void entonnoirVoieLireUnParCodeInseeCodeRivoli_OK() throws Exception
  {

    EntonnoirVoie entonnoirVoie = new EntonnoirVoie("12345", "similiHexacle0_123", "libelleNormalise_123", true); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    final ConnectorResponse<Retour, List<EntonnoirVoie>> expected = new ConnectorResponse<>(RetourFactory.createOkRetour(), Collections.singletonList(entonnoirVoie));
    ConnectorResponse<Retour, List<EntonnoirVoie>> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();

      EasyMock.expect(_iresConnectorMock.entonnoirVoieLireUnParCodeInseeCodeRivoli(_tracabilite, "12345", "54321")).andReturn(expected);//$NON-NLS-1$

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();

      actual = _instance.entonnoirVoieLireUnParCodeInseeCodeRivoli(_tracabilite, "12345", "54321");//$NON-NLS-1$
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#entonnoirVoieLireUnParCodeInseeSimiliHexacle0} Exception.
   *
   * @IN - Parameter codeInsee, similiHexacle0.
   * @OUT - Retour NOK CAT2 , List EntonnoirVoie null
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public final void entonnoirVoieLireUnParCodeInseeSimiliHexacle0_Exception() throws Exception
  {

    final ConnectorResponse<Retour, List<EntonnoirVoie>> expected = new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID)), null); //$NON-NLS-1$
    ConnectorResponse<Retour, List<EntonnoirVoie>> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andThrow(new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.MGRCTR_00002, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID))).once(); //$NON-NLS-1$

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();
      actual = _instance.entonnoirVoieLireUnParCodeInseeSimiliHexacle0(_tracabilite, "12345", "54321");//$NON-NLS-1$
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#entonnoirVoieLireTousParCodeInsee} OK.
   *
   * @IN - Parameter codeInsee, similiHexacle.
   * @OUT - Retour OK , List EntonnoirVoie with 1 element.
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public final void entonnoirVoieLireUnParCodeInseeSimiliHexacle0_OK() throws Exception
  {

    EntonnoirVoie entonnoirVoie = new EntonnoirVoie("12345", "54321", "libelleNormalise_123", true); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    final ConnectorResponse<Retour, List<EntonnoirVoie>> expected = new ConnectorResponse<>(RetourFactory.createOkRetour(), Collections.singletonList(entonnoirVoie));
    ConnectorResponse<Retour, List<EntonnoirVoie>> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();

      EasyMock.expect(_iresConnectorMock.entonnoirVoieLireUnParCodeInseeSimiliHexacle0(_tracabilite, "12345", "54321")).andReturn(expected);//$NON-NLS-1$

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();

      actual = _instance.entonnoirVoieLireUnParCodeInseeSimiliHexacle0(_tracabilite, "12345", "54321");//$NON-NLS-1$
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#oltCompositeGererSuppressionOltNonReference} Exception.
   *
   * @OUT - Retour NOK CAT2
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public final void oltCompositeGererSuppressionOltNonReference_Exception() throws Exception
  {

    final ConnectorResponse<Retour, Set<CompteRenduSuppression>> expected = new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID)), null); //$NON-NLS-1$
    ConnectorResponse<Retour, Set<CompteRenduSuppression>> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andThrow(new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.MGRCTR_00002, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID))).once(); //$NON-NLS-1$

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();
      actual = _instance.oltCompositeGererSuppressionOltNonReference(_tracabilite, null);
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * * Test the method {@link RESProxy#couverture5gLireUn} Exception.
   *
   * @IN - Parameter idAdresseBytel.
   * @OUT - Retour NOK CAT2 , Couverture5G = null
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public final void pad3015Couverture5GRead_Exception() throws Exception
  {

    final ConnectorResponse<Retour, Couverture5G> expected = new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID)), null); //$NON-NLS-1$
    ConnectorResponse<Retour, Couverture5G> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andThrow(new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.MGRCTR_00002, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID))).once(); //$NON-NLS-1$

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();
      actual = _instance.couverture5gLireUn(_tracabilite, "12345", TypeCouverture5G.ENT); //$NON-NLS-1$
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#couverture5gLireUn} OK.
   *
   * @IN - Parameter idAdresseBytel.
   * @OUT -Retour OK, Couverture5G
   *
   * @throws Exception
   *           thrown in case of error
   */

  @Test
  public final void pad3015Couverture5GRead_OK() throws Exception
  {

    final ConnectorResponse<Retour, Couverture5G> expected = new ConnectorResponse<>(RetourFactory.createOkRetour(), new Couverture5GENT("12345")); //$NON-NLS-1$
    ConnectorResponse<Retour, Couverture5G> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();

      EasyMock.expect(_iresConnectorMock.couverture5gLireUn(_tracabilite, "12345", TypeCouverture5G.ENT)).andReturn(expected); //$NON-NLS-1$

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();

      actual = _instance.couverture5gLireUn(_tracabilite, "12345", TypeCouverture5G.ENT); //$NON-NLS-1$
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#ressourceLireTousParIdRessourceLie} OK.
   *
   * @IN - Parameter ID_RESSOURCELIE.
   * @OUT - Retour NOK CAT2 , List Ressources null
   *
   * @throws Exception
   *           thrown in case of error
   */

  @Test
  public final void pad3100RessourceLireTousParIdRessourceLie_OK() throws Exception
  {

    final ConnectorResponse<Retour, List<Ressource>> expected = new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID)), null); //$NON-NLS-1$
    ConnectorResponse<Retour, List<Ressource>> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();

      EasyMock.expect(_iresConnectorMock.ressourceLireTousParIdRessourceLie(_tracabilite, "idRessourceLie", "typeRessource")).andReturn(expected);

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();

      actual = _instance.ressourceLireTousParIdRessourceLie(_tracabilite, "idRessourceLie", "typeRessource");
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#ressourceLireTousParIdRessourceLie} Exception.
   *
   * @IN - Parameter ID_RESSOURCELIE.
   * @OUT - Retour NOK CAT2 , List Ressources null
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public final void pad3100RessourcemodifierIdRessourceLie() throws Exception
  {

    final ConnectorResponse<Retour, List<Ressource>> expected = new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID)), null); //$NON-NLS-1$
    ConnectorResponse<Retour, Nothing> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andThrow(new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.MGRCTR_00002, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID))).once(); //$NON-NLS-1$

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();
      actual = _instance.ressourceModifierIdRessourceLie(_tracabilite, "typeRessource", "idRessourc", "idRessourceLi", "idRessourceLieCible"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * @throws Exception
   */
  @Test
  public final void pad3100RessourcemodifierIdRessourceLie_Exception() throws Exception
  {

    final ConnectorResponse<Retour, List<Ressource>> expected = new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID)), null); //$NON-NLS-1$
    ConnectorResponse<Retour, List<Ressource>> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andThrow(new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.MGRCTR_00002, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID))).once(); //$NON-NLS-1$

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();
      actual = _instance.ressourceLireTousParIdRessourceLie(_tracabilite, "idRessourceLie", "typeRessource");
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#pad3101RessourceAggregeP2PLireUn} Exception.
   *
   * @IN - Parameter TYPERESSOURCEAGGREGE, ID_RESSOURCE.
   * @OUT - Retour NOK CAT2 , null
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public final void pad3101RessourceAggregeP2PLireUn_Exception() throws Exception
  {

    final ConnectorResponse<Retour, RessourceAggrege> expected = new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID)), null); //$NON-NLS-1$
    ConnectorResponse<Retour, RessourceAggrege> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andThrow(new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.MGRCTR_00002, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID))).once(); //$NON-NLS-1$

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();
      actual = _instance.pad3101RessourceAggregeP2PLireUn(_tracabilite, "typeRessourceAggrege", "idRessource"); //$NON-NLS-1$//$NON-NLS-2$
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#ressourceLireTousParIdRessourceLie} OK.
   *
   * @IN - Parameter ID_RESSOURCELIE.
   * @OUT - Retour NOK CAT2 , List Ressources null
   *
   * @throws Exception
   *           thrown in case of error
   */

  @Test
  public final void pad3101RessourceLireTousParIdRessourceLie_OK() throws Exception
  {

    final ConnectorResponse<Retour, RessourceAggrege> expected = new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID)), null); //$NON-NLS-1$
    ConnectorResponse<Retour, RessourceAggrege> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();

      EasyMock.expect(_iresConnectorMock.pad3101RessourceAggregeP2PLireUn(_tracabilite, "typeRessourceAggrege", "idRessource")).andReturn(expected);

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();

      actual = _instance.pad3101RessourceAggregeP2PLireUn(_tracabilite, "typeRessourceAggrege", "idRessource"); //$NON-NLS-1$//$NON-NLS-2$
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#pad3200OltCompositeGererSuppressionOltNonReference} OK.
   *
   *
   * @throws Exception
   *           thrown in case of error
   */

  @Test
  public final void pad3200OltCompositeGererSuppressionOltNonReference_OK() throws Exception
  {
    Set<CompteRenduSuppression> hashSet = new HashSet<CompteRenduSuppression>();
    CompteRenduSuppression compteRendu = new CompteRenduSuppression("referenceObjet", "resultat"); //$NON-NLS-1$//$NON-NLS-2$
    hashSet.add(compteRendu);
    final ConnectorResponse<Retour, Set<CompteRenduSuppression>> expected = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), hashSet);
    ConnectorResponse<Retour, Set<CompteRenduSuppression>> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();

      EasyMock.expect(_iresConnectorMock.oltCompositeGererSuppressionOltNonReference(_tracabilite, null)).andReturn(expected);

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();

      actual = _instance.oltCompositeGererSuppressionOltNonReference(_tracabilite, null);

    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#oltCompositeLireSurchage} Exception.
   *
   * @IN - Parameter NoeudRaccordementRequest.
   * @OUT - Retour NOK CAT2
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public final void pad3200OltCompositeLireSurchage_Exception() throws Exception
  {

    final ConnectorResponse<Retour, GetSurchargeResponse> expected = new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID)), null); //$NON-NLS-1$
    ConnectorResponse<Retour, GetSurchargeResponse> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andThrow(new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.MGRCTR_00002, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID))).once(); //$NON-NLS-1$

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();
      actual = _instance.oltCompositeLireSurchage(_tracabilite, "action", "positionCarte", "positionCarte", "positionPortPon", "positionOntId"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#oltCompositeLireSurchage} OK.
   *
   *
   *
   * @throws Exception
   *           thrown in case of error
   */

  @Test
  public final void pad3200OltCompositeLireSurchage_OK() throws Exception
  {
    GetSurchargeResponse getoltSurcharge = new GetSurchargeResponse(RetourConverter.convertToJsonRetour(RetourFactoryForTU.createOkRetour()));
    final ConnectorResponse<Retour, GetSurchargeResponse> expected = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), getoltSurcharge);
    ConnectorResponse<Retour, GetSurchargeResponse> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();

      EasyMock.expect(_iresConnectorMock.oltCompositeLireSurchage(_tracabilite, "action", "positionCarte", "positionCarte", "positionPortPon", "positionOntId")).andReturn(expected); //$NON-NLS-1$

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();

      actual = _instance.oltCompositeLireSurchage(_tracabilite, "action", "positionCarte", "positionCarte", "positionPortPon", "positionOntId");

    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#pad3200OltCompositeLireUn} Exception.
   *
   * @IN - Parameter ID_RESSOURCELIE.
   * @OUT - Retour NOK CAT2 , List Ressources null
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public final void pad3200OltCompositeLireUn_Exception() throws Exception
  {

    final ConnectorResponse<Retour, OltComposite> expected = new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID)), null); //$NON-NLS-1$
    ConnectorResponse<Retour, OltComposite> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andThrow(new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.MGRCTR_00002, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID))).once(); //$NON-NLS-1$

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();
      actual = _instance.oltCompositeLireUn(_tracabilite, "nomOlt");
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#pad3200OltCompositeLireUn} OK.
   *
   * @IN - Parameter ID_RESSOURCELIE.
   * @OUT - Retour NOK CAT2 , List Ressources null
   *
   * @throws Exception
   *           thrown in case of error
   */

  @Test
  public final void pad3200OltCompositeLireUn_OK() throws Exception
  {

    final ConnectorResponse<Retour, OltComposite> expected = new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID)), null); //$NON-NLS-1$
    ConnectorResponse<Retour, OltComposite> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();

      EasyMock.expect(_iresConnectorMock.oltCompositeLireUn(_tracabilite, "nomOlt")).andReturn(expected); //$NON-NLS-1$

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();

      actual = _instance.oltCompositeLireUn(_tracabilite, "nomOlt"); //$NON-NLS-1$
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#oltCompositemodifierSurchargeDateDebutQuarantaineOLT} Exception.
   *
   * @IN - Parameter NoeudRaccordementRequest.
   * @OUT - Retour NOK CAT2
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public final void pad3200OltModifierSurchargeDateDebutQuarantaineOLT_Exception() throws Exception
  {

    final ConnectorResponse<Retour, Nothing> expected = new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID)), null); //$NON-NLS-1$
    ConnectorResponse<Retour, Nothing> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andThrow(new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.MGRCTR_00002, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID))).once(); //$NON-NLS-1$

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();
      actual = _instance.oltCompositemodifierSurchargeDateDebutQuarantaineOLT(_tracabilite, null, null);
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#oltCompositemodifierSurchargeDateDebutQuarantaineOLT} OK.
   *
   * @IN - Parameter ID_RESSOURCELIE.
   * @OUT - Retour NOK CAT2 , List Ressources null
   *
   * @throws Exception
   *           thrown in case of error
   */

  @Test
  public final void pad3200OltModifierSurchargeDateDebutQuarantaineOLT_OK() throws Exception
  {
    Retour retour = RetourFactoryForTU.createOkRetour();
    final ConnectorResponse<Retour, Nothing> expected = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), null);
    ConnectorResponse<Retour, Nothing> actual = null;
    String nomOlt = "nomOlt"; //$NON-NLS-1$

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();

      EasyMock.expect(_iresConnectorMock.oltCompositemodifierSurchargeDateDebutQuarantaineOLT(_tracabilite, null, nomOlt)).andReturn(expected);

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();

      actual = _instance.oltCompositemodifierSurchargeDateDebutQuarantaineOLT(_tracabilite, null, nomOlt);

    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#oltCompositeModifierSurchargeDebitGarantiPortPon} Exception.
   *
   * @IN - Parameter NoeudRaccordementRequest.
   * @OUT - Retour NOK CAT2
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public final void pad3200OltModifierSurchargeDebitGarantiPortPon_Exception() throws Exception
  {

    final ConnectorResponse<Retour, Nothing> expected = new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID)), null); //$NON-NLS-1$
    ConnectorResponse<Retour, Nothing> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andThrow(new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.MGRCTR_00002, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID))).once(); //$NON-NLS-1$

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();
      actual = _instance.oltCompositeModifierSurchargeDebitGarantiPortPon(_tracabilite, null, null, null, null);
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#pad3200OltUpdateSurchargeDebitGarantiPortPon} OK.
   *
   * @IN - Parameter ID_RESSOURCELIE.
   * @OUT - Retour NOK CAT2 , List Ressources null
   *
   * @throws Exception
   *           thrown in case of error
   */

  @Test
  public final void pad3200OltModifierSurchargeDebitGarantiPortPon_OK() throws Exception
  {
    Retour retour = RetourFactoryForTU.createOkRetour();
    final ConnectorResponse<Retour, Nothing> expected = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), null);
    ConnectorResponse<Retour, Nothing> actual = null;
    String action = "action"; //$NON-NLS-1$
    String nomOlt = "nomOlt"; //$NON-NLS-1$
    String positionCarte = "positionCarte"; //$NON-NLS-1$
    String positionPortPon = "positionPortPon"; //$NON-NLS-1$
    String debitGarantieCapaciteAllouee = "debitGarantieCapaciteAllouee"; //$NON-NLS-1$
    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();

      EasyMock.expect(_iresConnectorMock.oltCompositeModifierSurchargeDebitGarantiPortPon(_tracabilite, nomOlt, positionCarte, positionPortPon, debitGarantieCapaciteAllouee)).andReturn(expected);

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();

      actual = _instance.oltCompositeModifierSurchargeDebitGarantiPortPon(_tracabilite, nomOlt, positionCarte, positionPortPon, debitGarantieCapaciteAllouee);

    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#oltCompositeModifierSurchargeExploitationOntId} Exception.
   *
   * @OUT - Retour NOK CAT2
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public final void pad3200OltModifierSurchargeExploitationOntId_Exception() throws Exception
  {

    final ConnectorResponse<Retour, Nothing> expected = new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID)), null); //$NON-NLS-1$
    ConnectorResponse<Retour, Nothing> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andThrow(new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.MGRCTR_00002, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID))).once(); //$NON-NLS-1$

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();
      actual = _instance.oltCompositeModifierSurchargeExploitationOntId(_tracabilite, null, null, null, null, null, null);
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#oltCompositeModifierSurchargeExploitationOntId} OK.
   *
   *
   * @throws Exception
   *           thrown in case of error
   */

  @Test
  public final void pad3200OltModifierSurchargeExploitationOntId_OK() throws Exception
  {
    final ConnectorResponse<Retour, Nothing> expected = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), null);
    ConnectorResponse<Retour, Nothing> actual = null;
    String action = "action"; //$NON-NLS-1$
    String nomOlt = "nomOlt"; //$NON-NLS-1$
    String positionCarte = "positionCarte"; //$NON-NLS-1$
    String positionPortPon = "positionPortPon"; //$NON-NLS-1$
    String positionOntId = "positionOntId"; //$NON-NLS-1$
    String statutExploitation = "statutExploitation"; //$NON-NLS-1$
    String commentaireExploitation = "commentaireExploitation"; //$NON-NLS-1$
    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();

      EasyMock.expect(_iresConnectorMock.oltCompositeModifierSurchargeExploitationOntId(_tracabilite, nomOlt, positionCarte, positionPortPon, positionOntId, statutExploitation, commentaireExploitation)).andReturn(expected);

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();

      actual = _instance.oltCompositeModifierSurchargeExploitationOntId(_tracabilite, nomOlt, positionCarte, positionPortPon, positionOntId, statutExploitation, commentaireExploitation);

    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#oltCompositeModifierSurchargePriseClientCarte} Exception.
   *
   * @OUT - Retour NOK CAT2
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public final void pad3200OltModifierSurchargePriseClientCarte_Exception() throws Exception
  {

    final ConnectorResponse<Retour, Nothing> expected = new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID)), null); //$NON-NLS-1$
    ConnectorResponse<Retour, Nothing> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andThrow(new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.MGRCTR_00002, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID))).once(); //$NON-NLS-1$

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();
      actual = _instance.oltCompositeModifierSurchargePriseClientCarte(_tracabilite, null, null, null, null);
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#oltCompositeModifierSurchargePriseClientOntId} Exception.
   *
   * @OUT - Retour NOK CAT2
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public final void pad3200OltModifierSurchargePriseClientOntId_Exception() throws Exception
  {

    final ConnectorResponse<Retour, Nothing> expected = new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID)), null); //$NON-NLS-1$
    ConnectorResponse<Retour, Nothing> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andThrow(new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.MGRCTR_00002, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID))).once(); //$NON-NLS-1$

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();
      actual = _instance.oltCompositeModifierSurchargePriseClientOntId(_tracabilite, null, null, null, null, null, null);
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#oltCompositeModifierSurchargePriseClientOntId} OK.
   *
   *
   * @throws Exception
   *           thrown in case of error
   */

  @Test
  public final void pad3200OltModifierSurchargePriseClientOntId_OK() throws Exception
  {
    final ConnectorResponse<Retour, Nothing> expected = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), null);
    ConnectorResponse<Retour, Nothing> actual = null;
    String nomOlt = "nomOlt"; //$NON-NLS-1$
    String positionCarte = "positionCarte"; //$NON-NLS-1$
    String positionPortPon = "positionPortPon"; //$NON-NLS-1$
    String positionOntId = "positionOntId"; //$NON-NLS-1$
    String statutBlocage = "statutBlocage"; //$NON-NLS-1$
    String commentaireBlocage = "commentaireBlocage"; //$NON-NLS-1$

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();

      EasyMock.expect(_iresConnectorMock.oltCompositeModifierSurchargePriseClientOntId(_tracabilite, nomOlt, positionCarte, positionPortPon, positionOntId, statutBlocage, commentaireBlocage)).andReturn(expected);

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();

      actual = _instance.oltCompositeModifierSurchargePriseClientOntId(_tracabilite, nomOlt, positionCarte, positionPortPon, positionOntId, statutBlocage, commentaireBlocage);

    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#oltCompositeModifierSurchargePriseClientPortPon} Exception.
   *
   * @OUT - Retour NOK CAT2
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public final void pad3200OltModifierSurchargePriseClientPortPon_Exception() throws Exception
  {

    final ConnectorResponse<Retour, Nothing> expected = new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID)), null); //$NON-NLS-1$
    ConnectorResponse<Retour, Nothing> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andThrow(new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.MGRCTR_00002, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID))).once(); //$NON-NLS-1$

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();
      actual = _instance.oltCompositeModifierSurchargePriseClientPortPon(_tracabilite, null, null, null, null, null);
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#pad3200OltUpdateSurchargePriseClientPortPon} OK.
   *
   *
   * @throws Exception
   *           thrown in case of error
   */

  @Test
  public final void pad3200OltModifierSurchargePriseClientPortPon_OK() throws Exception
  {
    final ConnectorResponse<Retour, Nothing> expected = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), null);
    ConnectorResponse<Retour, Nothing> actual = null;
    String action = "action"; //$NON-NLS-1$
    String nomOlt = "nomOlt"; //$NON-NLS-1$
    String positionCarte = "positionCarte"; //$NON-NLS-1$
    String positionPortPon = "positionPortPon"; //$NON-NLS-1$
    String positionOntId = "positionOntId"; //$NON-NLS-1$
    String statutBlocage = "statutBlocage"; //$NON-NLS-1$
    String commentaireBlocage = "commentaireBlocage"; //$NON-NLS-1$

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();

      EasyMock.expect(_iresConnectorMock.oltCompositeModifierSurchargePriseClientPortPon(_tracabilite, nomOlt, positionCarte, positionPortPon, statutBlocage, commentaireBlocage)).andReturn(expected);

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();

      actual = _instance.oltCompositeModifierSurchargePriseClientPortPon(_tracabilite, nomOlt, positionCarte, positionPortPon, statutBlocage, commentaireBlocage);

    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#oltCompositeModifierSurchargeTechnoAutoriseePortPon} Exception.
   *
   * @OUT - Retour NOK CAT2
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public final void pad3200OltModifierSurchargeTechnoAutoriseePortPon_Exception() throws Exception
  {

    final ConnectorResponse<Retour, Nothing> expected = new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID)), null); //$NON-NLS-1$
    ConnectorResponse<Retour, Nothing> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andThrow(new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.MGRCTR_00002, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID))).once(); //$NON-NLS-1$

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();
      actual = _instance.oltCompositeModifierSurchargeTechnoAutoriseePortPon(_tracabilite, null, null, null, null);
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#oltCompositeModifierSurchargeTechnoAutoriseePortPon} OK.
   *
   *
   * @throws Exception
   *           thrown in case of error
   */

  @Test
  public final void pad3200OltModifierSurchargeTechnoAutoriseePortPon_OK() throws Exception
  {
    final ConnectorResponse<Retour, Nothing> expected = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), null);
    ConnectorResponse<Retour, Nothing> actual = null;
    String nomOlt = "nomOlt"; //$NON-NLS-1$
    String positionCarte = "positionCarte"; //$NON-NLS-1$
    String positionPortPon = "positionPortPon"; //$NON-NLS-1$

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();

      EasyMock.expect(_iresConnectorMock.oltCompositeModifierSurchargeTechnoAutoriseePortPon(_tracabilite, null, nomOlt, positionCarte, positionPortPon)).andReturn(expected);

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();

      actual = _instance.oltCompositeModifierSurchargeTechnoAutoriseePortPon(_tracabilite, null, nomOlt, positionCarte, positionPortPon);

    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#oltCompositeModifierSurchargeVersionOLT} Exception.
   *
   * @OUT - Retour NOK CAT2
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public final void pad3200OltModifierSurchargeVersionOLT_Exception() throws Exception
  {

    final ConnectorResponse<Retour, Nothing> expected = new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID)), null); //$NON-NLS-1$
    ConnectorResponse<Retour, Nothing> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andThrow(new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.MGRCTR_00002, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID))).once(); //$NON-NLS-1$

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();
      actual = _instance.oltCompositeModifierSurchargeVersionOLT(_tracabilite, null, null, null);
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#oltCompositeModifierSurchargeVersionOLT} OK.
   *
   *
   * @throws Exception
   *           thrown in case of error
   */

  @Test
  public final void pad3200OltModifierSurchargeVersionOLT_OK() throws Exception
  {
    final ConnectorResponse<Retour, Nothing> expected = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), null);
    ConnectorResponse<Retour, Nothing> actual = null;
    String nomOlt = "nomOlt"; //$NON-NLS-1$
    String versionInterfaceEchange = "versionInterfaceEchange"; //$NON-NLS-1$

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();

      EasyMock.expect(_iresConnectorMock.oltCompositeModifierSurchargeVersionOLT(_tracabilite, null, nomOlt, versionInterfaceEchange)).andReturn(expected);

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();

      actual = _instance.oltCompositeModifierSurchargeVersionOLT(_tracabilite, null, nomOlt, versionInterfaceEchange);

    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#pad3200OltMoifierSurchargePriseClientCarte} OK.
   *
   *
   * @throws Exception
   *           thrown in case of error
   */

  @Test
  public final void pad3200OltMoifierSurchargePriseClientCarte_OK() throws Exception
  {
    final ConnectorResponse<Retour, Nothing> expected = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), null);
    ConnectorResponse<Retour, Nothing> actual = null;
    String nomOlt = "nomOlt"; //$NON-NLS-1$
    String positionCarte = "positionCarte"; //$NON-NLS-1$
    String statutBlocage = "statutBlocage"; //$NON-NLS-1$
    String commentaireBlocage = "commentaireBlocage"; //$NON-NLS-1$
    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();

      EasyMock.expect(_iresConnectorMock.oltCompositeModifierSurchargePriseClientCarte(_tracabilite, nomOlt, positionCarte, statutBlocage, commentaireBlocage)).andReturn(expected);

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();

      actual = _instance.oltCompositeModifierSurchargePriseClientCarte(_tracabilite, nomOlt, positionCarte, statutBlocage, commentaireBlocage);

    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#pad3204CreerNoeudRaccordementGererImport} Exception.
   *
   * @IN - Parameter NoeudRaccordementRequest.
   * @OUT - Retour NOK CAT2
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public final void pad3204CreerNoeudRaccordementGererImport_Exception() throws Exception
  {

    final ManageNoeudRaccordementRequest noeudRaccordement = __podam.manufacturePojoWithFullData(ManageNoeudRaccordementRequest.class);

    final ConnectorResponse<Retour, Nothing> expected = new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID)), null); //$NON-NLS-1$
    ConnectorResponse<Retour, Nothing> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andThrow(new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.MGRCTR_00002, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID))).once(); //$NON-NLS-1$

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();
      actual = _instance.noeudRaccordementGererImport(_tracabilite, noeudRaccordement);
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#pad3204CreerNoeudRaccordementGererImport} OK.
   *
   *
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public final void pad3204CreerNoeudRaccordementGererImport_OK() throws Exception
  {

    final ManageNoeudRaccordementRequest noeudRaccordement = __podam.manufacturePojoWithFullData(ManageNoeudRaccordementRequest.class);

    final ConnectorResponse<Retour, Nothing> expected = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), null);
    ConnectorResponse<Retour, Nothing> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();

      EasyMock.expect(_iresConnectorMock.noeudRaccordementGererImport(_tracabilite, noeudRaccordement)).andReturn(expected);

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();

      actual = _instance.noeudRaccordementGererImport(_tracabilite, noeudRaccordement);
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#pmCompositeGererImport} Exception.
   */
  @Test
  public final void pmCompositeGererImport_Exception()
  {
    final ConnectorResponse<Retour, Nothing> expected = new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID)), null); //$NON-NLS-1$
    ConnectorResponse<Retour, Nothing> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andThrow(new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.MGRCTR_00002, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID))).once(); //$NON-NLS-1$

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();
      actual = _instance.pmCompositeGererImport(_tracabilite, null);
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);
      assertNotNull(_instance);

      // Assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#pmCompositeGererImport} OK.
   */
  @Test
  public final void pmCompositeGererImport_OK()
  {
    PMComposite update = __podam.manufacturePojoWithFullData(PMComposite.class);
    final ConnectorResponse<Retour, Nothing> expected = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), null);
    ConnectorResponse<Retour, Nothing> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();

      EasyMock.expect(_iresConnectorMock.pmCompositeGererImport(_tracabilite, update, null)).andReturn(expected);

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();

      actual = _instance.pmCompositeGererImport(_tracabilite, update);
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);
      assertNotNull(_instance);

      // Assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#pmCompositeGererSuppressionPMNonReference} Exception.
   */
  @Test
  public final void pmCompositeGererSuppressionPMNonReference_Exception()
  {
    final ConnectorResponse<Retour, Set<CompteRenduSuppression>> expected = new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID)), null); //$NON-NLS-1$
    ConnectorResponse<Retour, Set<CompteRenduSuppression>> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andThrow(new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.MGRCTR_00002, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID))).once(); //$NON-NLS-1$

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();
      actual = _instance.pmCompositeGererSuppressionPMNonReference(_tracabilite, null);
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#pmCompositeGererSuppressionPMNonReference} OK.
   */
  @Test
  public final void pmCompositeGererSuppressionPMNonReference_OK()
  {
    Set<String> update = new HashSet<>();
    final ConnectorResponse<Retour, Set<CompteRenduSuppression>> expected = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), null);
    ConnectorResponse<Retour, Set<CompteRenduSuppression>> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();

      EasyMock.expect(_iresConnectorMock.pmCompositeGererSuppressionPMNonReference(_tracabilite, update)).andReturn(expected);

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();

      actual = _instance.pmCompositeGererSuppressionPMNonReference(_tracabilite, update);
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#pmCompositeLireSurchargeBoitierPM} Exception.
   */
  @Test
  public final void pmCompositeLireSurchargeBoitierPM_Exception()
  {
    String referencePmBytel = "referencePmBytel"; //$NON-NLS-1$
    String referenceBoitierPm = "referenceBoitierPm"; //$NON-NLS-1$
    String nomPanneau = "nomPanneau"; //$NON-NLS-1$
    String positionPortPM = "1";

    final ConnectorResponse<Retour, PMConsultResponse> expected = new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID)), null); //$NON-NLS-1$
    ConnectorResponse<Retour, PMConsultResponse> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andThrow(new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.MGRCTR_00002, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID))).once(); //$NON-NLS-1$

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();
      actual = _instance.pmCompositeLireSurchargeBoitierPM(_tracabilite, referencePmBytel, referenceBoitierPm, nomPanneau, positionPortPM);
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#pmCompositeLireSurchargeBoitierPM} OK.
   */
  @Test
  public final void pmCompositeLireSurchargeBoitierPM_OK()
  {
    final PMConsultResponse pmResponse = __podam.manufacturePojoWithFullData(PMConsultResponse.class);
    String referencePmBytel = "referencePmBytel"; //$NON-NLS-1$
    String referenceBoitierPm = "referenceBoitierPm"; //$NON-NLS-1$
    String nomPanneau = "nomPanneau"; //$NON-NLS-1$
    String positionPortPM = "1";
    final ConnectorResponse<Retour, PMConsultResponse> expected = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), pmResponse);
    ConnectorResponse<Retour, PMConsultResponse> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();

      EasyMock.expect(_iresConnectorMock.pmCompositeLireSurchargeBoitierPM(_tracabilite, referencePmBytel, referenceBoitierPm, nomPanneau, positionPortPM)).andReturn(expected);

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();

      actual = _instance.pmCompositeLireSurchargeBoitierPM(_tracabilite, referencePmBytel, referenceBoitierPm, nomPanneau, positionPortPM);

    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#pmCompositeLireSurchargePM} Exception.
   */
  @Test
  public final void pmCompositeLireSurchargePM_Exception()
  {
    String referencePmBytel = "referencePmBytel"; //$NON-NLS-1$
    String referenceBoitierPm = "referenceBoitierPm"; //$NON-NLS-1$
    String nomPanneau = "nomPanneau"; //$NON-NLS-1$
    String positionPortPM = "1";

    final ConnectorResponse<Retour, PMConsultResponse> expected = new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID)), null); //$NON-NLS-1$
    ConnectorResponse<Retour, PMConsultResponse> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andThrow(new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.MGRCTR_00002, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID))).once(); //$NON-NLS-1$

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();
      actual = _instance.pmCompositeLireSurchargePM(_tracabilite, referencePmBytel, referenceBoitierPm, nomPanneau, positionPortPM);
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#pmCompositeLireSurchargePM} OK.
   */
  @Test
  public final void pmCompositeLireSurchargePM_OK()
  {
    final PMConsultResponse pmResponse = __podam.manufacturePojoWithFullData(PMConsultResponse.class);
    String referencePmBytel = "referencePmBytel"; //$NON-NLS-1$
    String referenceBoitierPm = "referenceBoitierPm"; //$NON-NLS-1$
    String nomPanneau = "nomPanneau"; //$NON-NLS-1$
    String positionPortPM = "1";
    final ConnectorResponse<Retour, PMConsultResponse> expected = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), pmResponse);
    ConnectorResponse<Retour, PMConsultResponse> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();

      EasyMock.expect(_iresConnectorMock.pmCompositeLireSurchargePM(_tracabilite, referencePmBytel, referenceBoitierPm, nomPanneau, positionPortPM)).andReturn(expected);

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();

      actual = _instance.pmCompositeLireSurchargePM(_tracabilite, referencePmBytel, referenceBoitierPm, nomPanneau, positionPortPM);

    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#pmCompositeLireSurchargePortPM} Exception.
   */
  @Test
  public final void pmCompositeLireSurchargePortPM_Exception()
  {
    String referencePmBytel = "referencePmBytel"; //$NON-NLS-1$
    String referenceBoitierPm = "referenceBoitierPm"; //$NON-NLS-1$
    String nomPanneau = "nomPanneau"; //$NON-NLS-1$
    String positionPortPM = "1";

    final ConnectorResponse<Retour, PMConsultResponse> expected = new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID)), null); //$NON-NLS-1$
    ConnectorResponse<Retour, PMConsultResponse> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andThrow(new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.MGRCTR_00002, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID))).once(); //$NON-NLS-1$

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();
      actual = _instance.pmCompositeLireSurchargePortPM(_tracabilite, referencePmBytel, referenceBoitierPm, nomPanneau, positionPortPM);
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#pmCompositeLireSurchargePortPM} OK.
   */
  @Test
  public final void pmCompositeLireSurchargePortPM_OK()
  {
    final PMConsultResponse pmResponse = __podam.manufacturePojoWithFullData(PMConsultResponse.class);
    String referencePmBytel = "referencePmBytel"; //$NON-NLS-1$
    String referenceBoitierPm = "referenceBoitierPm"; //$NON-NLS-1$
    String nomPanneau = "nomPanneau"; //$NON-NLS-1$
    String positionPortPM = "1";
    final ConnectorResponse<Retour, PMConsultResponse> expected = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), pmResponse);
    ConnectorResponse<Retour, PMConsultResponse> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();

      EasyMock.expect(_iresConnectorMock.pmCompositeLireSurchargePortPM(_tracabilite, referencePmBytel, referenceBoitierPm, nomPanneau, positionPortPM)).andReturn(expected);

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();

      actual = _instance.pmCompositeLireSurchargePortPM(_tracabilite, referencePmBytel, referenceBoitierPm, nomPanneau, positionPortPM);

    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#pmCompositeLireUnParReferencePmBytel} Exception.
   */
  @Test
  public final void pmCompositeLireUnParReferencePmBytel_Exception()
  {
    final ConnectorResponse<Retour, PMComposite> expected = new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID)), null); //$NON-NLS-1$
    ConnectorResponse<Retour, PMComposite> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andThrow(new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.MGRCTR_00002, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID))).once(); //$NON-NLS-1$

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();
      actual = _instance.pmCompositeLireUnParReferencePmBytel(_tracabilite, null);
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#pmCompositeLireUnParReferencePmBytel} OK.
   */
  @Test
  public final void pmCompositeLireUnParReferencePmBytel_OK()
  {
    final PMComposite pmResponse = __podam.manufacturePojoWithFullData(PMComposite.class);

    final ConnectorResponse<Retour, PMComposite> expected = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), pmResponse);
    ConnectorResponse<Retour, PMComposite> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();

      EasyMock.expect(_iresConnectorMock.pmCompositeLireUnParReferencePmBytel(_tracabilite, "referencePmBytel")).andReturn(expected); //$NON-NLS-1$

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();

      actual = _instance.pmCompositeLireUnParReferencePmBytel(_tracabilite, "referencePmBytel"); //$NON-NLS-1$
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#pmCompositeLireUnParReferencePmOi} Exception.
   */
  @Test
  public final void pmCompositeLireUnParReferencePmOi_Exception()
  {
    final ConnectorResponse<Retour, PMComposite> expected = new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID)), null); //$NON-NLS-1$
    ConnectorResponse<Retour, PMComposite> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andThrow(new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.MGRCTR_00002, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID))).once(); //$NON-NLS-1$

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();
      actual = _instance.pmCompositeLireUnParReferencePmOi(_tracabilite, null);
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#pmCompositeLireUnParReferencePmOi} OK.
   */
  @Test
  public final void pmCompositeLireUnParReferencePmOi_OK()
  {
    final PMComposite pmResponse = __podam.manufacturePojoWithFullData(PMComposite.class);

    final ConnectorResponse<Retour, PMComposite> expected = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), pmResponse);
    ConnectorResponse<Retour, PMComposite> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();

      EasyMock.expect(_iresConnectorMock.pmCompositeLireUnParReferencePmOi(_tracabilite, null)).andReturn(expected);

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();

      actual = _instance.pmCompositeLireUnParReferencePmOi(_tracabilite, null);
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#pmCompositeModifierSurchargeDateDebutQuarantainePM} Exception.
   */
  @Test
  public final void pmCompositeModifierSurchargeDateDebutQuarantainePM_Exception()
  {
    final ConnectorResponse<Retour, Nothing> expected = new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID)), null); //$NON-NLS-1$
    ConnectorResponse<Retour, Nothing> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andThrow(new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.MGRCTR_00002, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID))).once(); //$NON-NLS-1$

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();
      actual = _instance.pmCompositeModifierSurchargeDateDebutQuarantainePM(_tracabilite, null);
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#pmCompositeModifierSurchargeDateDebutQuarantainePM} OK.
   */
  @Test
  public final void pmCompositeModifierSurchargeDateDebutQuarantainePM_OK()
  {
    String referencePmBytel = "referencePmBytel"; //$NON-NLS-1$

    final ConnectorResponse<Retour, Nothing> expected = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), null);
    ConnectorResponse<Retour, Nothing> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();

      EasyMock.expect(_iresConnectorMock.pmCompositeModifierSurchargeDateDebutQuarantainePM(_tracabilite, referencePmBytel)).andReturn(expected);

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();

      actual = _instance.pmCompositeModifierSurchargeDateDebutQuarantainePM(_tracabilite, referencePmBytel);
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#pmCompositeModifierSurchargeExploitationPortPM} Exception.
   */
  @Test
  public final void pmCompositeModifierSurchargeExploitationPortPM_Exception()
  {
    final ConnectorResponse<Retour, Nothing> expected = new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID)), null); //$NON-NLS-1$
    ConnectorResponse<Retour, Nothing> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andThrow(new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.MGRCTR_00002, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID))).once(); //$NON-NLS-1$

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();
      actual = _instance.pmCompositeModifierSurchargeExploitationPortPM(_tracabilite, null, null, null, null, null, null);
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#pmCompositeModifierSurchargeExploitationPortPM} OK.
   */
  @Test
  public final void pmCompositeModifierSurchargeExploitationPortPM_OK()
  {
    String referencePmBytel = "referencePmBytel"; //$NON-NLS-1$
    String referenceBoitierPm = "referenceBoitierPm"; //$NON-NLS-1$
    String nomPanneau = "nomPanneau"; //$NON-NLS-1$
    String positionPortPM = "positionPortPM"; //$NON-NLS-1$
    String statutExploitation = "statutExploitation"; //$NON-NLS-1$
    String commentaireExploitation = "commentaireExploitation"; //$NON-NLS-1$
    final ConnectorResponse<Retour, Nothing> expected = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), null);
    ConnectorResponse<Retour, Nothing> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();

      EasyMock.expect(_iresConnectorMock.pmCompositeModifierSurchargeExploitationPortPM(_tracabilite, referencePmBytel, referenceBoitierPm, nomPanneau, positionPortPM, statutExploitation, commentaireExploitation)).andReturn(expected);

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();

      actual = _instance.pmCompositeModifierSurchargeExploitationPortPM(_tracabilite, referencePmBytel, referenceBoitierPm, nomPanneau, positionPortPM, statutExploitation, commentaireExploitation);
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#pmCompositeModifierSurchargePriseClientBoitierPM} Exception.
   */
  @Test
  public final void pmCompositeModifierSurchargePriseClientBoitierPM_Exception()
  {
    final ConnectorResponse<Retour, Nothing> expected = new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID)), null); //$NON-NLS-1$
    ConnectorResponse<Retour, Nothing> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andThrow(new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.MGRCTR_00002, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID))).once(); //$NON-NLS-1$

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();
      actual = _instance.pmCompositeModifierSurchargePriseClientBoitierPM(_tracabilite, null, null, null, null);
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#pmCompositeModifierSurchargePriseClientBoitierPM} OK.
   */
  @Test
  public final void pmCompositeModifierSurchargePriseClientBoitierPM_OK()
  {
    String referencePmBytel = "referencePmBytel"; //$NON-NLS-1$
    String referenceBoitierPm = "referenceBoitierPm"; //$NON-NLS-1$
    String statutBlocage = "statutBlocage"; //$NON-NLS-1$
    String commentaireBlocage = "commentaireBlocage"; //$NON-NLS-1$
    final ConnectorResponse<Retour, Nothing> expected = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), null);
    ConnectorResponse<Retour, Nothing> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();

      EasyMock.expect(_iresConnectorMock.pmCompositeModifierSurchargePriseClientBoitierPM(_tracabilite, referencePmBytel, referenceBoitierPm, statutBlocage, commentaireBlocage)).andReturn(expected);

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();

      actual = _instance.pmCompositeModifierSurchargePriseClientBoitierPM(_tracabilite, referencePmBytel, referenceBoitierPm, statutBlocage, commentaireBlocage);
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#pmCompositeModifierSurchargePriseClientPM} Exception.
   */
  @Test
  public final void pmCompositeModifierSurchargePriseClientPM_Exception()
  {
    final ConnectorResponse<Retour, Nothing> expected = new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID)), null); //$NON-NLS-1$
    ConnectorResponse<Retour, Nothing> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andThrow(new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.MGRCTR_00002, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID))).once(); //$NON-NLS-1$

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();
      actual = _instance.pmCompositeModifierSurchargePriseClientPM(_tracabilite, null, null, null);
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#pmCompositeModifierSurchargePriseClientPM} OK.
   */
  @Test
  public final void pmCompositeModifierSurchargePriseClientPM_OK()
  {
    String referencePmBytel = "referencePmBytel"; //$NON-NLS-1$
    String statutBlocage = "statutBlocage"; //$NON-NLS-1$
    String commentaireBlocage = "commentaireBlocage"; //$NON-NLS-1$
    final ConnectorResponse<Retour, Nothing> expected = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), null);
    ConnectorResponse<Retour, Nothing> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();

      EasyMock.expect(_iresConnectorMock.pmCompositeModifierSurchargePriseClientPM(_tracabilite, referencePmBytel, statutBlocage, commentaireBlocage)).andReturn(expected);

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();

      actual = _instance.pmCompositeModifierSurchargePriseClientPM(_tracabilite, referencePmBytel, statutBlocage, commentaireBlocage);
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#pmCompositeModifierSurchargePriseClientPortPM} Exception.
   */
  @Test
  public final void pmCompositeModifierSurchargePriseClientPortPM_Exception()
  {
    final ConnectorResponse<Retour, Nothing> expected = new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID)), null); //$NON-NLS-1$
    ConnectorResponse<Retour, Nothing> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andThrow(new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.MGRCTR_00002, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID))).once(); //$NON-NLS-1$

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();
      actual = _instance.pmCompositeModifierSurchargePriseClientPortPM(_tracabilite, null, null, null, null, null, null);
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#pmCompositeModifierSurchargePriseClientPortPM} OK.
   */
  @Test
  public final void pmCompositeModifierSurchargePriseClientPortPM_OK()
  {
    String referencePmBytel = "referencePmBytel"; //$NON-NLS-1$
    String referenceBoitierPM = "referenceBoitierPM"; //$NON-NLS-1$
    String nomPanneauPM = "nomPanneauPM"; //$NON-NLS-1$
    String positionPortPM = "positionPortPM"; //$NON-NLS-1$
    String statutBlocage = "statutBlocage"; //$NON-NLS-1$
    String commentaireBlocage = "commentaireBlocage"; //$NON-NLS-1$
    final ConnectorResponse<Retour, Nothing> expected = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), null);
    ConnectorResponse<Retour, Nothing> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();

      EasyMock.expect(_iresConnectorMock.pmCompositeModifierSurchargePriseClientPortPM(_tracabilite, referencePmBytel, referenceBoitierPM, nomPanneauPM, positionPortPM, statutBlocage, commentaireBlocage)).andReturn(expected);

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();

      actual = _instance.pmCompositeModifierSurchargePriseClientPortPM(_tracabilite, referencePmBytel, referenceBoitierPM, nomPanneauPM, positionPortPM, statutBlocage, commentaireBlocage);
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#pointAncrageIpGererImport} OK.
   *
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public final void pointAncrageIpGererImport_OK() throws Exception
  {
    final String action = "GererImport"; //$NON-NLS-1$
    PointAncrageIPCollecte pointAncrageIP = new PointAncrageIPCollecte("nomPointAncrageIP", "typePointAncrageIP");

    final ConnectorResponse<Retour, Nothing> expected = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), null);
    ConnectorResponse<Retour, Nothing> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();

      EasyMock.expect(_iresConnectorMock.pointAncrageIpGererImport(_tracabilite, pointAncrageIP)).andReturn(expected);

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();

      actual = _instance.pointAncrageIpGererImport(_tracabilite, pointAncrageIP);

    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#pointAncrageIpGererSuppressionPointAncrageIPNonReference} OK.
   *
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public final void pointAncrageIpGererSuppressionPointAncrageIPNonReference_OK() throws Exception
  {
    final String action = "GererSuppressionPointAncrageIPNonReference"; //$NON-NLS-1$
    Set<String> listeNomPointAncrageIP = new HashSet<>();
    String typePointAncrageIP = StringConstants.EMPTY_STRING;
    Set<CompteRenduSuppression> hashSet = new HashSet<CompteRenduSuppression>();
    CompteRenduSuppression compteRendu = new CompteRenduSuppression("referenceObjet", "resultat"); //$NON-NLS-1$//$NON-NLS-2$
    hashSet.add(compteRendu);
    final ConnectorResponse<Retour, Set<CompteRenduSuppression>> expected = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), hashSet);
    ConnectorResponse<Retour, Set<CompteRenduSuppression>> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();

      EasyMock.expect(_iresConnectorMock.pointAncrageIpGererSuppressionPointAncrageIPNonReference(_tracabilite, listeNomPointAncrageIP, typePointAncrageIP)).andReturn(expected);

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();

      actual = _instance.pointAncrageIpGererSuppressionPointAncrageIPNonReference(_tracabilite, listeNomPointAncrageIP, typePointAncrageIP);

    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#ressourcePortP2PGererAllocation} Exception.
   *
   * @IN - Parameter nomNR.
   * @OUT - Retour NOK CAT2 , compteurPortP2PLibre null
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public final void ressourcePortP2PcompterPortLibre_Exception()
  {
    final ConnectorResponse<Retour, Integer> expected = new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID)), null); //$NON-NLS-1$
    ConnectorResponse<Retour, Integer> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andThrow(new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.MGRCTR_00002, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID))).once(); //$NON-NLS-1$

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();
      actual = _instance.ressourcePortP2PcompterPortLibreP2P(_tracabilite, "NoeudR1");//$NON-NLS-1$
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#ressourcePortP2PcompterPortLibre} OK.
   *
   * @IN - Parameter ID_RESSOURCELIE.
   * @OUT - Retour OK , compteurPortP2PLibre 2
   *
   * @throws Exception
   *           thrown in case of error
   */

  @Test
  public final void ressourcePortP2PcompterPortLibre_OK() throws Exception
  {

    final ConnectorResponse<Retour, Integer> expected = new ConnectorResponse<>(RetourFactory.createOkRetour(), 2);
    ConnectorResponse<Retour, Integer> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();

      EasyMock.expect(_iresConnectorMock.ressourcePortP2PcompterPortLibreP2P(_tracabilite, "NoeudR1")).andReturn(expected);//$NON-NLS-1$

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();

      actual = _instance.ressourcePortP2PcompterPortLibreP2P(_tracabilite, "NoeudR1");//$NON-NLS-1$
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#ressourcePortP2PGererAllocation} Exception.
   *
   * @IN - Parameter ID_RESSOURCELIE.
   * @OUT - Retour NOK CAT2 , List Ressources null
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public final void ressourcePortP2PGererAllocation_Exception() throws Exception
  {

    final ConnectorResponse<Retour, Nothing> expected = new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID)), null); //$NON-NLS-1$
    ConnectorResponse<Retour, Nothing> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andThrow(new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.MGRCTR_00002, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID))).once(); //$NON-NLS-1$

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();
      actual = _instance.ressourcePortP2PGererAllocation(_tracabilite, "nomNR", "distance", "idRessourceRaccordment", "action"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#ressourcePortP2PGererAllocation} OK.
   *
   * @IN - Parameter ID_RESSOURCELIE.
   * @OUT - Retour NOK CAT2 , List Ressources null
   *
   * @throws Exception
   *           thrown in case of error
   */

  @Test
  public final void ressourcePortP2PGererAllocation_OK() throws Exception
  {

    final ConnectorResponse<Retour, Nothing> expected = new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID)), null); //$NON-NLS-1$
    ConnectorResponse<Retour, Nothing> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();

      EasyMock.expect(_iresConnectorMock.ressourcePortP2PGererAllocation(_tracabilite, "nomNR", "distance", "idRessourceRaccordment", "action")).andReturn(expected); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();

      actual = _instance.ressourcePortP2PGererAllocation(_tracabilite, "nomNR", "distance", "idRessourceRaccordment", "action"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#ressourcePortP2PModifierStatutAllocation} Exception.
   *
   * @IN - Parameter ID_RESSOURCELIE.
   * @OUT - Retour NOK CAT2 , List Ressources null
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public final void ressourcePortP2PModifierStatutAllocation_Exception() throws Exception
  {

    final ConnectorResponse<Retour, Nothing> expected = new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID)), null); //$NON-NLS-1$
    ConnectorResponse<Retour, Nothing> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andThrow(new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.MGRCTR_00002, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID))).once(); //$NON-NLS-1$

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();
      actual = _instance.ressourcePortP2PModifierStatutAllocation(_tracabilite, "idRessource_p", "idLienAllocation", "statut"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Test the method {@link RESProxy#ressourcePortP2PModifierStatutAllocation} OK.
   *
   * @IN - Parameter ID_RESSOURCELIE.
   * @OUT - Retour NOK CAT2 , List Ressources null
   *
   * @throws Exception
   *           thrown in case of error
   */

  @Test
  public final void ressourcePortP2PModifierStatutAllocation_OK() throws Exception
  {
    final ConnectorResponse<Retour, Nothing> expected = new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, MessageFormat.format(Messages.getString("ConnectorManager.UnknownConnector"), IRESConnector.BEAN_ID)), null); //$NON-NLS-1$
    ConnectorResponse<Retour, Nothing> actual = null;

    try
    {
      EasyMock.expect(ConnectorManager.getInstance()).andReturn(_connectorManagerMock).times(2);
      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();

      EasyMock.expect(_iresConnectorMock.ressourcePortP2PModifierStatutAllocation(_tracabilite, "idRessource_p", "idLienAllocation", "statut")).andReturn(expected); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

      EasyMock.expect(_connectorManagerMock.getConnector(IRESConnector.BEAN_ID)).andReturn(_iresConnectorMock).once();
      EasyMock.expect(_iresConnectorMock.isEnabled()).andReturn(true);

      PowerMock.replayAll();

      _instance = RESProxy.getInstance();

      actual = _instance.ressourcePortP2PModifierStatutAllocation(_tracabilite, "idRessource_p", "idLienAllocation", "statut"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    }
    catch (final RavelException exception)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verifyAll();

      assertFalse(_exception);

      assertNotNull(_instance);

      // assertions
      assertNotNull(actual);
      assertEquals(expected._first, actual._first);
      assertEquals(expected._second, actual._second);
    }
  }

  /**
   * Initialization of tests
   *
   * @throws Exception
   *           Exception to be thrown in case of failure
   */
  @Before
  public void setUp() throws Exception
  {
    _tracabilite = __podam.manufacturePojoWithFullData(Tracabilite.class);

    _exception = false;

    PowerMock.resetAll();

    PowerMock.mockStaticStrict(ConnectorManager.class);
  }
}
