/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.res.services;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.time.Duration;
import java.util.Hashtable;
import java.util.Map;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.cxf.jaxrs.impl.ResponseBuilderImpl;
import org.easymock.Capture;
import org.easymock.EasyMock;
import org.easymock.EasyMockSupport;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.modules.junit4.PowerMockRunner;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.conf.generated.LoadBalancer;
import com.bytel.ravel.common.conf.generated.Param;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.test.JUnitTools;
import com.bytel.ravel.common.test.podam.JavaTimeManufacturer;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.utils.RetourFactoryForTU;
import com.bytel.ravel.net.loadbalancing.ILoadBalancer;
import com.bytel.ravel.net.loadbalancing.URLBalancedElement;
import com.bytel.ravel.net.rest.RestConnectorPool;
import com.bytel.ravel.net.rest.RestInstance;
import com.bytel.ravel.services.conf.connector.generated.Connector;
import com.bytel.ravel.services.conf.connector.generated.URL;
import com.bytel.ravel.services.conf.connector.generated.URLS;
import com.bytel.ravel.services.connector.AbstractRESTConnector;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.connectors.res.Messages;
import com.bytel.spirit.common.connectors.res.RESConnector;
import com.bytel.spirit.common.shared.functional.types.json.RavelJsonTools;
import com.bytel.spirit.common.shared.misc.ressources.BasicResponse;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.ressources.RetourConverter;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.response.GetRessourcePortP2PResponse;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 * @author ppinto
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
public class RessourcePortP2PServiceTest extends EasyMockSupport
{
  /**
   * Param name for PAD3124
   */
  private static final String PAD3124_PATH_PARAM = "/ressourcePortP2P/"; //$NON-NLS-1$

  /**
   * Action
   */
  private static final String PARAM_ACTION = "action"; //$NON-NLS-1$

  /**
   * nomNR
   */
  private static final String PARAM_NOMNR = "nomNR"; //$NON-NLS-1$

  /**
   * Distance
   */
  private static final String PARAM_DISTANCE = "distance"; //$NON-NLS-1$

  /**
   *
   */
  private static final String PARAM_ID_RESSOURCE = "idRessource"; //$NON-NLS-1$

  /**
   *
   */
  private static final String PARAM_ID_RESSOURCELIE = "idRessourceLie"; //$NON-NLS-1$

  /**
   *
   */
  private static final String PARAM_STATUT = "statut"; //$NON-NLS-1$

  /**
   * Impossible de récupérer la réponse constant
   */
  public static final String JSON_ERROR_MESSAGE = Messages.getString("RESConnector.JsonErrorMessage"); //$NON-NLS-1$

  /**
   * Param name for CREATE_LONG_TIMEOUT
   */
  private static final String CREATE_LONG_TIMEOUT_PARAM = "36000000"; //$NON-NLS-1$

  /**
   * Check the query params in rest send request method
   *
   * @param queryParams
   *          the actual query params
   * @param expected_p
   *          list of expected query params strings key1 value1 key2 value2...keyN valueN
   */
  public static void checkQueryParams(Capture<Map<String, String>> queryParams, String... expected_p)
  {
    if (expected_p == null)
    {
      Assert.assertNull(queryParams.getValue());
    }
    else
    {
      Assert.assertEquals(0, expected_p.length % 2);
      for (int i = 0; i < expected_p.length; i = i + 2)
      {
        Assert.assertEquals(expected_p[i + 1], queryParams.getValue().get(expected_p[i]));
      }
    }
  }

  /**
   * Génération du LoadBalancer minimal pour passer {@link AbstractRESTConnector#loadConnectorConfiguration(Connector)}
   *
   * @return {@link LoadBalancer}
   */
  public static LoadBalancer generateLoadBalancer()
  {
    final LoadBalancer loadBalancer = new LoadBalancer();
    Param timer = new Param();
    timer.setName("TIMER"); //$NON-NLS-1$
    timer.setValue("30"); //$NON-NLS-1$
    loadBalancer.getParam().add(timer);
    loadBalancer.setType("RoundRobin"); //$NON-NLS-1$
    return loadBalancer;
  }

  /**
   * Génération du URL minimal pour passer {@link AbstractRESTConnector#loadConnectorConfiguration(Connector)}
   *
   * @return {@link URL}
   */
  public static URL generateURL()
  {
    final URL url = new URL();
    url.setName("urlName"); //$NON-NLS-1$
    url.setAccessPoint("http://localhost:8888"); //$NON-NLS-1$
    Param param = new Param();
    param.setName("PROXY_ENABLED"); //$NON-NLS-1$
    param.setValue(String.valueOf(false));
    url.getParam().add(param);
    param = new Param();
    param.setName("TIMEOUT"); //$NON-NLS-1$
    param.setValue("30"); //$NON-NLS-1$
    url.getParam().add(param);

    return url;
  }

  /**
   * @return URLS
   */
  public static URLS generateURLS()
  {
    final URLS urls = new URLS();
    urls.setLoadBalancer(generateLoadBalancer());
    urls.getURL().add(generateURL());
    return urls;
  }

  /**
   * Factory to generate beans
   */
  private final PodamFactory _podam = new PodamFactoryImpl();

  /**
   * Connector to test
   */
  private RESConnector _connector;

  /**
   * Path for PAD3124
   */
  private String _ressourcePortP2PUrl;

  /**
   * Timeout value
   */
  private Integer _createLongTimeout;

  private Tracabilite _tracabilite;

  /**
   * Mock {@link ILoadBalancer}
   */
  @MockStrict
  ILoadBalancer<URLBalancedElement> _loadBalancerMock;

  /**
   * Mock {@link URLBalancedElement}
   */
  @MockStrict
  URLBalancedElement _urlBalancedElementMock;

  /**
   * Mock of connectors pool HTTP
   */
  @MockStrict
  Hashtable<String, RestConnectorPool> _connectorPoolMock;

  /**
   * Mock {@link RestConnectorPool}
   */
  @MockStrict
  RestConnectorPool _restConnectorPoolMock;

  /**
   * Mock {@link RestInstance}
   */
  @MockStrict
  RestInstance _restInstanceMock;

  /**
   * Initialize before tests
   *
   * @throws Exception
   *           Thrown in case of error during switch in attributes of parent class
   */
  @Before
  public void beforeTest() throws Exception
  {
    _podam.getStrategy().setMemoization(false);
    _podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());
    JavaTimeManufacturer.registerPodamFactory(_podam);

    _connector = new RESConnector();

    _ressourcePortP2PUrl = PAD3124_PATH_PARAM;
    _createLongTimeout = Integer.parseInt(CREATE_LONG_TIMEOUT_PARAM);

    JUnitTools.setInaccessibleFieldValue(_connector, "_loadBalancer", _loadBalancerMock); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_connectorPool", _connectorPoolMock); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_createLongTimeout", 5); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_ressourcePortP2PUrl", _ressourcePortP2PUrl); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_ressourceService", new RessourceService(_connector)); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_ressourceRaccordementService", new RessourceRaccordementService(_connector)); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_ressourcePortPmService", new RessourcePortPmService(_connector)); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_ressourcePortP2PService", new RessourcePortP2PService(_connector)); //$NON-NLS-1$
    PowerMock.resetAll();
    _tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
  }

  /**
   * Test Exception for the method ressourcePortP2PGererAllocation.
   * {@link RESConnector#ressourcePortP2PGererAllocation(Tracabilite, String, String, String, String)} httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void ressourcePortP2PGererAllocation_Exception() throws Exception
  {

    final String nomNR = RandomStringUtils.randomAlphabetic(5);
    final String distance = RandomStringUtils.randomAlphabetic(5);
    final String idRessourceRaccordment = RandomStringUtils.randomAlphabetic(5);
    final String action = "GererAllocation"; //$NON-NLS-1$

    final Retour retour = RetourFactoryForTU.createOkRetour();
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream("".getBytes())).build(); //$NON-NLS-1$

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_ressourcePortP2PUrl), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();

    try
    {
      _connector.ressourcePortP2PGererAllocation(_tracabilite, nomNR, distance, idRessourceRaccordment, action);
    }
    catch (RavelException e)
    {
      Assert.assertEquals(ExceptionType.UNEXPECTED, e.getExceptionType());
      Assert.assertEquals(ErrorCode.CNCTOR_00010, e.getErrorCode());
      Assert.assertEquals("Impossible de récupérer la réponse", e.getMessage()); //$NON-NLS-1$
    }
  }

  /**
   * Test KO for the method ressourcePortP2PGererAllocation.
   * {@link RESConnector#ressourcePortP2PGererAllocation(Tracabilite, String, String, String,String)}
   *
   * Expected : Retour KO, CAT-4, DONNEE_INCONNUE,
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void ressourcePortP2PGererAllocation_KO_001() throws Exception
  {

    final String nomNR = RandomStringUtils.randomAlphabetic(5);
    final String distance = RandomStringUtils.randomAlphabetic(5);
    final String idRessourceLie = RandomStringUtils.randomAlphabetic(5);
    final String action = "GererAllocation"; //$NON-NLS-1$

    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "ressourceCompteMail " + idRessourceLie + " inconnue", null); //$NON-NLS-1$ //$NON-NLS-2$
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = RavelJsonTools.getInstance().toJson(basicResponse, BasicResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(404).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_ressourcePortP2PUrl), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.ressourcePortP2PGererAllocation(_tracabilite, nomNR, distance, idRessourceLie, action);

    // check header
    Assert.assertNotNull(headersCapture.getValue());


    //check params sent
    checkQueryParams(queryParamsCapture, PARAM_NOMNR, nomNR);
    checkQueryParams(queryParamsCapture, PARAM_DISTANCE, distance);
    checkQueryParams(queryParamsCapture, PARAM_ID_RESSOURCELIE, idRessourceLie);
    checkQueryParams(queryParamsCapture, PARAM_ACTION, action);

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test OK for the method ressourcePortP2PGererAllocation.
   * {@link RESConnector#ressourcePortP2PGererAllocation(Tracabilite, String, String, String,String)} httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void ressourcePortP2PGererAllocation_OK_001() throws Exception
  {

    final String nomNR = RandomStringUtils.randomAlphabetic(5);
    final String distance = RandomStringUtils.randomAlphabetic(5);
    final String idRessourceLie = RandomStringUtils.randomAlphabetic(5);
    final String action = "GererAllocation"; //$NON-NLS-1$

    final Retour retour = RetourFactoryForTU.createOkRetour();
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(basicResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_ressourcePortP2PUrl), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.ressourcePortP2PGererAllocation(_tracabilite, nomNR, distance, idRessourceLie, action);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());


    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test Exception for the method ressourcePortP2PGererAllocation
   * {@link RESConnector#ressourcePortP2PModifierStatutAllocation(Tracabilite, String, String, String)}
   *
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void ressourcePortP2PModifierStatutAllocation_Exception() throws Exception
  {

    final String idRessource = RandomStringUtils.randomAlphabetic(5);
    final String idLienAllocation = RandomStringUtils.randomAlphabetic(5);
    final String statut = "LIBRE"; //$NON-NLS-1$

    final Retour retour = RetourFactoryForTU.createOkRetour();
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream("".getBytes())).build(); //$NON-NLS-1$

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_ressourcePortP2PUrl), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();

    try
    {
      _connector.ressourcePortP2PModifierStatutAllocation(_tracabilite, idRessource, idLienAllocation, statut);
    }
    catch (RavelException e)
    {
      Assert.assertEquals(ExceptionType.UNEXPECTED, e.getExceptionType());
      Assert.assertEquals(ErrorCode.CNCTOR_00010, e.getErrorCode());
      Assert.assertEquals("Impossible de récupérer la réponse", e.getMessage()); //$NON-NLS-1$

    }
  }

  /**
   * Test KO for the method pad3124RessourcePortP2PGererAllocation.
   * {@link RESConnector#ressourcePortP2PModifierStatutAllocation(Tracabilite, String, String, String)}
   *
   * Expected : Retour KO, CAT-4, DONNEE_INCONNUE,
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void ressourcePortP2PModifierStatutAllocation_KO_001() throws Exception
  {

    final String idRessource = RandomStringUtils.randomAlphabetic(5);
    final String idRessourceLie = RandomStringUtils.randomAlphabetic(5);
    final String statut = "LIBRE"; //$NON-NLS-1$

    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "", null); //$NON-NLS-1$
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(basicResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(404).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_ressourcePortP2PUrl), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.ressourcePortP2PModifierStatutAllocation(_tracabilite, idRessource, idRessourceLie, statut);

    // check header
    Assert.assertNotNull(headersCapture.getValue());


    //check params sent
    checkQueryParams(queryParamsCapture, PARAM_ID_RESSOURCE, idRessource);
    checkQueryParams(queryParamsCapture, PARAM_ID_RESSOURCELIE, idRessourceLie);
    checkQueryParams(queryParamsCapture, PARAM_STATUT, statut);

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test OK for the method pad3124RessourcePortP2PGererAllocation.
   * {@link RESConnector#ressourcePortP2PModifierStatutAllocation(Tracabilite, String, String, String)} httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void ressourcePortP2PModifierStatutAllocation_OK_001() throws Exception
  {

    final String idRessource = RandomStringUtils.randomAlphabetic(5);
    final String idRessourceLie = RandomStringUtils.randomAlphabetic(5);
    final String statut = "LIBRE"; //$NON-NLS-1$

    final Retour retour = RetourFactoryForTU.createOkRetour();
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(basicResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_ressourcePortP2PUrl), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.ressourcePortP2PModifierStatutAllocation(_tracabilite, idRessource, idRessourceLie, statut);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());


    //check params sent
    checkQueryParams(queryParamsCapture, PARAM_ID_RESSOURCE, idRessource);
    checkQueryParams(queryParamsCapture, PARAM_ID_RESSOURCELIE, idRessourceLie);
    checkQueryParams(queryParamsCapture, PARAM_STATUT, statut);

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test Exception for the method ressourcePortP2PcompterPortLibre
   * {@link RESConnector#ressourcePortP2PcompterPortLibreP2P(Tracabilite, String)}
   *
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void ressourcePortP2PcompterPortLibre_Exception() throws Exception
  {

    final String nomNR = "NoeudR1";//$NON-NLS-1$

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream("".getBytes())).build(); //$NON-NLS-1$

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(PAD3124_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);

    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();

    try
    {
      _connector.ressourcePortP2PcompterPortLibreP2P(_tracabilite, nomNR);
    }
    catch (RavelException e)
    {
      Assert.assertEquals(ExceptionType.UNEXPECTED, e.getExceptionType());
      Assert.assertEquals(ErrorCode.CNCTOR_00010, e.getErrorCode());
      Assert.assertEquals("Impossible de récupérer la réponse", e.getMessage()); //$NON-NLS-1$

    }
  }

  /**
   * Test KO for the method ressourcePortP2PcompterPortLibre.
   * {@link RESConnector#ressourcePortP2PcompterPortLibreP2P(Tracabilite, String)}
   *
   * Expected : Retour KO, CAT-4, DONNEE_INCONNUE, compteurPortP2PLibre null
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void ressourcePortP2PcompterPortLibre_KO_001() throws Exception
  {
    final String nomNR = "NoeudR1";//$NON-NLS-1$

    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "", null); //$NON-NLS-1$
    final GetRessourcePortP2PResponse getRessourcePortP2PResponse = new GetRessourcePortP2PResponse(RetourConverter.convertToJsonRetour(retour), null);
    final String partnerResponse = RavelJsonTools.getInstance().toJson(getRessourcePortP2PResponse, GetRessourcePortP2PResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(404).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(PAD3124_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Integer> result = _connector.ressourcePortP2PcompterPortLibreP2P(_tracabilite, nomNR);

    // check header
    Assert.assertNotNull(headersCapture.getValue());


    //check params sent
    checkQueryParams(queryParamsCapture, PARAM_NOMNR, nomNR);

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test OK for the method ressourcePortP2PcompterPortLibre.
   * {@link RESConnector#ressourcePortP2PcompterPortLibreP2P(Tracabilite, String)} httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void ressourcePortP2PcompterPortLibre_OK_001() throws Exception
  {

    final String nomNR = "NoeudR1";//$NON-NLS-1$

    final Retour retour = RetourFactoryForTU.createOkRetour();
    final GetRessourcePortP2PResponse Response = new GetRessourcePortP2PResponse(RetourConverter.convertToJsonRetour(retour), 2);
    final String partnerResponse = RavelJsonTools.getInstance().toJson(Response, GetRessourcePortP2PResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(PAD3124_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Integer> result = _connector.ressourcePortP2PcompterPortLibreP2P(_tracabilite, nomNR);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());


    //check params sent
    checkQueryParams(queryParamsCapture, PARAM_NOMNR, nomNR);

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertNotNull(result._second);
  }

  /**
   * prepare mock scenario to initialize method sendRequest from AbstractRestConnector
   *
   * @throws Exception
   *           Thrown in case of error
   */
  private void initializeMocksForSendRequest() throws Exception
  {
    final String urlBalancedElementName = RandomStringUtils.randomAlphanumeric(45);
    final String urlBalancedElementDescription = RandomStringUtils.randomAlphabetic(9);

    EasyMock.expect(_loadBalancerMock.chooseBalancedElement()).andReturn(_urlBalancedElementMock);
    EasyMock.expect(_urlBalancedElementMock.getName()).andReturn(urlBalancedElementName);
    EasyMock.expect(_urlBalancedElementMock.getDescription()).andReturn(urlBalancedElementDescription);
    EasyMock.expect(_urlBalancedElementMock.getName()).andReturn(urlBalancedElementName);
    EasyMock.expect(_connectorPoolMock.get(urlBalancedElementName)).andReturn(_restConnectorPoolMock);
    EasyMock.expect(_restConnectorPoolMock.borrowObject()).andReturn(_restInstanceMock);
  }
}
