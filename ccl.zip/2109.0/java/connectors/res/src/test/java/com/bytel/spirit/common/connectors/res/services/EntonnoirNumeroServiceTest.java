/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.res.services;

import java.io.ByteArrayInputStream;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.cxf.jaxrs.impl.ResponseBuilderImpl;
import org.easymock.Capture;
import org.easymock.EasyMock;
import org.easymock.EasyMockSupport;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.modules.junit4.PowerMockRunner;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.conf.generated.Param;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.test.JUnitTools;
import com.bytel.ravel.common.test.podam.JavaTimeManufacturer;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.utils.RetourFactoryForTU;
import com.bytel.ravel.net.loadbalancing.ILoadBalancer;
import com.bytel.ravel.net.loadbalancing.URLBalancedElement;
import com.bytel.ravel.net.rest.RestConnectorPool;
import com.bytel.ravel.net.rest.RestInstance;
import com.bytel.ravel.services.conf.connector.generated.Connector;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.connectors.res.RESConnector;
import com.bytel.spirit.common.connectors.res.RESConnectorTest;
import com.bytel.spirit.common.shared.functional.types.json.RavelJsonTools;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.RetourConverter;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.EntonnoirNumero;
import com.bytel.spirit.common.shared.saab.res.response.GetListeEntonnoirNumeroResponse;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 * @author rafcosta
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
public class EntonnoirNumeroServiceTest extends EasyMockSupport
{

  /** Param name for PAD3023 */
  private static final String PAD3023_PATH_PARAM = "/entonnoirNumero"; //$NON-NLS-1$

  /** Code INSEE */
  private static final String PARAM_CODE_INSEE = "codeInsee"; //$NON-NLS-1$
  /** Code rivoli */
  private static final String PARAM_RIVOLI = "codeRivoli"; //$NON-NLS-1$
  /** SimiliHexacle0 */
  private static final String PARAM_SIMILI_HEXACLE_0 = "similiHexacle0"; //$NON-NLS-1$

  /** Path for PAD3023 */
  private String _entonnoirNumeroUrl;

  /**
   * Factory to generate beans
   */
  private PodamFactory _podam = new PodamFactoryImpl();

  /**
   * Connector to test
   */
  private RESConnector _connector;

  /**
   * Mock {@link ILoadBalancer}
   */
  @MockStrict
  ILoadBalancer<URLBalancedElement> _loadBalancerMock;

  /**
   * Mock {@link URLBalancedElement}
   */
  @MockStrict
  URLBalancedElement _urlBalancedElementMock;

  /**
   * Mock of connectors pool HTTP
   */
  @MockStrict
  Hashtable<String, RestConnectorPool> _connectorPoolMock;

  /**
   * Mock {@link RestConnectorPool}
   */
  @MockStrict
  RestConnectorPool _restConnectorPoolMock;

  /**
   * Mock {@link RestInstance}
   */
  @MockStrict
  RestInstance _restInstanceMock;

  /**
   * Initialize before tests
   *
   * @throws Exception
   *           Thrown in case of error during switch in attributes of parent class
   */
  @Before
  public void beforeTest() throws Exception
  {
    _podam.getStrategy().setMemoization(false);
    _podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());
    JavaTimeManufacturer.registerPodamFactory(_podam);

    _connector = new RESConnector();

    _entonnoirNumeroUrl = PAD3023_PATH_PARAM;

    JUnitTools.setInaccessibleFieldValue(_connector, "_loadBalancer", _loadBalancerMock); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_connectorPool", _connectorPoolMock); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_entonnoirNumeroUrl", _entonnoirNumeroUrl); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_entonnoirNumeroService", new EntonnoirNumeroService(_connector)); //$NON-NLS-1$

    PowerMock.resetAll();
  }

  /**
   * Test the method {@link RESConnector#entonnoirNumeroLireTousParCodeInseeCodeRivoli} httpStatus 200 Retour KO with
   * List<EntonnoirNumero> null
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void entonnoirNumeroLireTousParCodeInseeCodeRivoli_KO_001() throws Exception
  {
    // Call parameters
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final String codeInsee = RandomStringUtils.randomAlphabetic(5);
    final String codeRivoli = RandomStringUtils.randomAlphabetic(5);

    // Response values
    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "CodeInsee " + codeInsee + " / CodeRivoli " + codeRivoli + " inconnu", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NOM-NLS-3$
    final GetListeEntonnoirNumeroResponse getListeEntonnoirNumeroResponse = new GetListeEntonnoirNumeroResponse(RetourConverter.convertToJsonRetour(retour), null);
    final String partnerResponse = RavelJsonTools.getInstance().toJson(getListeEntonnoirNumeroResponse, GetListeEntonnoirNumeroResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_entonnoirNumeroUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<EntonnoirNumero>> result = _connector.entonnoirNumeroLireTousParCodeInseeCodeRivoli(tracabilite, codeInsee, codeRivoli);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    RESConnectorTest.checkQueryParams(queryParamsCapture, PARAM_CODE_INSEE, codeInsee, PARAM_RIVOLI, codeRivoli);

    Assert.assertEquals(retour, result._first);
    Assert.assertEquals(new ArrayList<>(), result._second);
  }

  /**
   * Test the method {@link RESConnector#entonnoirNumeroLireTousParCodeInseeCodeRivoli} httpStatus 200 jsonResponse null
   * (throws RavelException)
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void entonnoirNumeroLireTousParCodeInseeCodeRivoli_KO_002() throws Exception
  {
    // Call parameters
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final String codeInsee = RandomStringUtils.randomAlphabetic(5);
    final String codeRivoli = RandomStringUtils.randomAlphabetic(5);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_entonnoirNumeroUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    // Call connector
    PowerMock.replayAll();
    ConnectorResponse<Retour, List<EntonnoirNumero>> result = _connector.entonnoirNumeroLireTousParCodeInseeCodeRivoli(tracabilite, codeInsee, codeRivoli);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    RESConnectorTest.checkQueryParams(queryParamsCapture, PARAM_CODE_INSEE, codeInsee, PARAM_RIVOLI, codeRivoli);

    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, RESConnectorTest.JSON_ERROR_MESSAGE, null);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test OK for the method {@link RESConnector#entonnoirNumeroLireTousParCodeInseeCodeRivoli} httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void entonnoirNumeroLireTousParCodeInseeCodeRivoli_OK_001() throws Exception
  {
    // Call parameters
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final String codeInsee = RandomStringUtils.randomAlphabetic(5);
    final String codeRivoli = RandomStringUtils.randomAlphabetic(5);

    // Response values
    EntonnoirNumero entonnoirNumero = _podam.manufacturePojoWithFullData(EntonnoirNumero.class);
    List<EntonnoirNumero> entonnoirNumeroList = Collections.singletonList(entonnoirNumero);
    final Retour retour = RetourFactoryForTU.createOkRetour();
    final GetListeEntonnoirNumeroResponse getListeEntonnoirNumeroResponse = new GetListeEntonnoirNumeroResponse(RetourConverter.convertToJsonRetour(retour), entonnoirNumeroList);
    final String partnerResponse = RavelJsonTools.getInstance().toJson(getListeEntonnoirNumeroResponse, GetListeEntonnoirNumeroResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_entonnoirNumeroUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<EntonnoirNumero>> result = _connector.entonnoirNumeroLireTousParCodeInseeCodeRivoli(tracabilite, codeInsee, codeRivoli);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    RESConnectorTest.checkQueryParams(queryParamsCapture, PARAM_CODE_INSEE, codeInsee, PARAM_RIVOLI, codeRivoli);

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertEquals(entonnoirNumeroList, result._second);
  }

  /**
   * Test the method {@link RESConnector#entonnoirNumeroLireTousParCodeInseeSimiliHexacle0} httpStatus 200 Retour KO
   * with List<EntonnoirNumero> null
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void entonnoirNumeroLireTousParCodeInseeSimiliHexacle0_KO_001() throws Exception
  {
    // Call parameters
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final String codeInsee = RandomStringUtils.randomAlphabetic(5);
    final String similiHexacle0 = RandomStringUtils.randomAlphabetic(5);

    // Response values
    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "CodeInsee " + codeInsee + " / SimiliHexacle0 " + similiHexacle0 + " inconnu", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NOM-NLS-3$
    final GetListeEntonnoirNumeroResponse getListeEntonnoirNumeroResponse = new GetListeEntonnoirNumeroResponse(RetourConverter.convertToJsonRetour(retour), null);
    final String partnerResponse = RavelJsonTools.getInstance().toJson(getListeEntonnoirNumeroResponse, GetListeEntonnoirNumeroResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_entonnoirNumeroUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<EntonnoirNumero>> result = _connector.entonnoirNumeroLireTousParCodeInseeSimiliHexacle0(tracabilite, codeInsee, similiHexacle0);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    RESConnectorTest.checkQueryParams(queryParamsCapture, PARAM_CODE_INSEE, codeInsee, PARAM_SIMILI_HEXACLE_0, similiHexacle0);

    Assert.assertEquals(retour, result._first);
    Assert.assertEquals(new ArrayList<>(), result._second);
  }

  /**
   * Test the method {@link RESConnector#entonnoirNumeroLireTousParCodeInseeSimiliHexacle0} httpStatus 200 jsonResponse
   * null (throws RavelException)
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void entonnoirNumeroLireTousParCodeInseeSimiliHexacle0_KO_002() throws Exception
  {
    // Call parameters
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final String codeInsee = RandomStringUtils.randomAlphabetic(5);
    final String similiHexacle0 = RandomStringUtils.randomAlphabetic(5);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_entonnoirNumeroUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    // Call connector
    PowerMock.replayAll();
    ConnectorResponse<Retour, List<EntonnoirNumero>> result = _connector.entonnoirNumeroLireTousParCodeInseeSimiliHexacle0(tracabilite, codeInsee, similiHexacle0);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    RESConnectorTest.checkQueryParams(queryParamsCapture, PARAM_CODE_INSEE, codeInsee, PARAM_SIMILI_HEXACLE_0, similiHexacle0);

    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, RESConnectorTest.JSON_ERROR_MESSAGE, null);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test OK for the method {@link RESConnector#entonnoirNumeroLireTousParCodeInseeSimiliHexacle0} httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void entonnoirNumeroLireTousParCodeInseeSimiliHexacle0_OK_001() throws Exception
  {
    // Call parameters
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final String codeInsee = RandomStringUtils.randomAlphabetic(5);
    final String similiHexacle0 = RandomStringUtils.randomAlphabetic(5);

    // Response values
    EntonnoirNumero entonnoirNumero = _podam.manufacturePojoWithFullData(EntonnoirNumero.class);
    List<EntonnoirNumero> entonnoirNumeroList = Collections.singletonList(entonnoirNumero);
    final Retour retour = RetourFactoryForTU.createOkRetour();
    final GetListeEntonnoirNumeroResponse getListeEntonnoirNumeroResponse = new GetListeEntonnoirNumeroResponse(RetourConverter.convertToJsonRetour(retour), entonnoirNumeroList);
    final String partnerResponse = RavelJsonTools.getInstance().toJson(getListeEntonnoirNumeroResponse, GetListeEntonnoirNumeroResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_entonnoirNumeroUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<EntonnoirNumero>> result = _connector.entonnoirNumeroLireTousParCodeInseeSimiliHexacle0(tracabilite, codeInsee, similiHexacle0);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    RESConnectorTest.checkQueryParams(queryParamsCapture, PARAM_CODE_INSEE, codeInsee, PARAM_SIMILI_HEXACLE_0, similiHexacle0);

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertEquals(entonnoirNumeroList, result._second);
  }

  /**
   * @throws Exception
   *           Exception
   */
  @Test
  public void test_loadConnectorConfiguration() throws Exception
  {
    final Connector connector = new Connector();

    Param param = new Param();
    param.setName("PAD3023_PATH_PARAM"); //$NON-NLS-1$
    param.setValue(_entonnoirNumeroUrl);
    connector.getParam().add(param);

    param = new Param();
    param.setName("AccesTechniqueCacheDuration"); //$NON-NLS-1$
    param.setValue("PT10M"); //$NON-NLS-1$
    connector.getParam().add(param);

    param = new Param();
    param.setName("AbaqueDSLCacheDuration"); //$NON-NLS-1$
    param.setValue("PT10M"); //$NON-NLS-1$
    connector.getParam().add(param);

    connector.setURLS(RESConnectorTest.generateURLS());

    // test
    _connector.loadConnectorConfiguration(connector);

    // assertions
    Assert.assertEquals(_entonnoirNumeroUrl, JUnitTools.getInaccessibleFieldValue(_connector, "_entonnoirNumeroUrl")); //$NON-NLS-1$
    Assert.assertNotNull(JUnitTools.getInaccessibleFieldValue(_connector, "_entonnoirNumeroService")); //$NON-NLS-1$
    Assert.assertEquals(Duration.parse("PT10M"), JUnitTools.getInaccessibleFieldValue(_connector, "_accesTechniqueCacheDuration")); //$NON-NLS-1$ //$NON-NLS-2$
    Assert.assertEquals(Duration.parse("PT10M"), JUnitTools.getInaccessibleFieldValue(_connector, "_abaqueDslCacheDuration")); //$NON-NLS-1$ //$NON-NLS-2$
  }

  /**
   * prepare mock scenario to initialize method sendRequest from AbstractRestConnector
   *
   * @throws Exception
   *           Thrown in case of error
   */
  private void initializeMocksForSendRequest() throws Exception
  {
    final String urlBalancedElementName = RandomStringUtils.randomAlphanumeric(45);
    final String urlBalancedElementDescription = RandomStringUtils.randomAlphabetic(9);

    EasyMock.expect(_loadBalancerMock.chooseBalancedElement()).andReturn(_urlBalancedElementMock);
    EasyMock.expect(_urlBalancedElementMock.getName()).andReturn(urlBalancedElementName);
    EasyMock.expect(_urlBalancedElementMock.getDescription()).andReturn(urlBalancedElementDescription);
    EasyMock.expect(_urlBalancedElementMock.getName()).andReturn(urlBalancedElementName);
    EasyMock.expect(_connectorPoolMock.get(urlBalancedElementName)).andReturn(_restConnectorPoolMock);
    EasyMock.expect(_restConnectorPoolMock.borrowObject()).andReturn(_restInstanceMock);
  }
}
