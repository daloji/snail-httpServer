/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.res.services;

import java.io.ByteArrayInputStream;
import java.text.MessageFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.cxf.jaxrs.impl.ResponseBuilderImpl;
import org.easymock.Capture;
import org.easymock.EasyMock;
import org.easymock.EasyMockSupport;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.modules.junit4.PowerMockRunner;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.conf.generated.Param;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.test.JUnitTools;
import com.bytel.ravel.common.test.podam.JavaTimeManufacturer;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.utils.RetourFactoryForTU;
import com.bytel.ravel.net.loadbalancing.ILoadBalancer;
import com.bytel.ravel.net.loadbalancing.URLBalancedElement;
import com.bytel.ravel.net.rest.RestConnectorPool;
import com.bytel.ravel.net.rest.RestInstance;
import com.bytel.ravel.services.conf.connector.generated.Connector;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.connectors.res.Messages;
import com.bytel.spirit.common.connectors.res.RESConnector;
import com.bytel.spirit.common.connectors.res.RESConnectorTest;
import com.bytel.spirit.common.shared.functional.types.json.RavelJsonTools;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.RetourConverter;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.DispoRessourceDSLAxione;
import com.bytel.spirit.common.shared.saab.res.DispoRessourceDSLBouygues;
import com.bytel.spirit.common.shared.saab.res.DispoRessourceDSLOrange;
import com.bytel.spirit.common.shared.saab.res.DispoRessourceDSLSFR;
import com.bytel.spirit.common.shared.saab.res.response.GetDispoRessourceDSLAxioneResponse;
import com.bytel.spirit.common.shared.saab.res.response.GetDispoRessourceDSLBouyguesResponse;
import com.bytel.spirit.common.shared.saab.res.response.GetDispoRessourceDSLOrangeResponse;
import com.bytel.spirit.common.shared.saab.res.response.GetDispoRessourceDSLSFRResponse;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 * @author rafcosta
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
public class DispoRessourceDSLServiceTest extends EasyMockSupport
{
  /** Param name for PAD3017 */
  private static final String PAD3017_PATH_PARAM = "/dispoRessourceDSLOrange/"; //$NON-NLS-1$
  /** Param name for PAD3018 */
  private static final String PAD3018_PATH_PARAM = "/dispoRessourceDSLBouygues/"; //$NON-NLS-1$
  /** Param name for PAD3019 */
  private static final String PAD3019_PATH_PARAM = "/dispoRessourceDSLAxione/"; //$NON-NLS-1$
  /** Param name for PAD3020 */
  private static final String PAD3020_PATH_PARAM = "/dispoRessourceDSLSFR/"; //$NON-NLS-1$

  /** Parameter nomURAOrange */
  private static final String PARAM_NOM_URA_ORANGE = "nomURAOrange"; //$NON-NLS-1$
  /** Parameter nbPaire */
  private static final String PARAM_NB_PAIRE = "nbPaire"; //$NON-NLS-1$
  /** Parameter techno */
  private static final String PARAM_TECHNO = "techno"; //$NON-NLS-1$

  /** Path for PAD3017 */
  private String _dispoRessourceDslOrangeUrl;
  /** Path for PAD3018 */
  private String _dispoRessourceDslBouyguesUrl;
  /** Path for PAD3019 */
  private String _dispoRessourceDslAxioneUrl;
  /** Path for PAD3020 */
  private String _dispoRessourceDslSFRUrl;

  /**
   * Factory to generate beans
   */
  private PodamFactory _podam = new PodamFactoryImpl();

  /**
   * Connector to test
   */
  private RESConnector _connector;

  /**
   * Mock {@link ILoadBalancer}
   */
  @MockStrict
  ILoadBalancer<URLBalancedElement> _loadBalancerMock;

  /**
   * Mock {@link URLBalancedElement}
   */
  @MockStrict
  URLBalancedElement _urlBalancedElementMock;

  /**
   * Mock of connectors pool HTTP
   */
  @MockStrict
  Hashtable<String, RestConnectorPool> _connectorPoolMock;

  /**
   * Mock {@link RestConnectorPool}
   */
  @MockStrict
  RestConnectorPool _restConnectorPoolMock;

  /**
   * Mock {@link RestInstance}
   */
  @MockStrict
  RestInstance _restInstanceMock;

  /**
   * Initialize before tests
   *
   * @throws Exception
   *           Thrown in case of error during switch in attributes of parent class
   */
  @Before
  public void beforeTest() throws Exception
  {
    _podam.getStrategy().setMemoization(false);
    _podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());
    JavaTimeManufacturer.registerPodamFactory(_podam);

    _connector = new RESConnector();

    _dispoRessourceDslOrangeUrl = PAD3017_PATH_PARAM;
    _dispoRessourceDslBouyguesUrl = PAD3018_PATH_PARAM;
    _dispoRessourceDslAxioneUrl = PAD3019_PATH_PARAM;
    _dispoRessourceDslSFRUrl = PAD3020_PATH_PARAM;

    JUnitTools.setInaccessibleFieldValue(_connector, "_loadBalancer", _loadBalancerMock); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_connectorPool", _connectorPoolMock); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_dispoRessourceDSLService", new DispoRessourceDSLService(_connector)); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_dispoRessourceDslOrangeUrl", _dispoRessourceDslOrangeUrl); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_dispoRessourceDslBouyguesUrl", _dispoRessourceDslBouyguesUrl); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_dispoRessourceDslAxioneUrl", _dispoRessourceDslAxioneUrl); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_dispoRessourceDslSFRUrl", _dispoRessourceDslSFRUrl); //$NON-NLS-1$

    PowerMock.resetAll();
  }

  /**
   * Test the method {@link RESConnector#dispoRessourceDslAxioneLire(Tracabilite, String, String, String, String)}
   * httpStatus 200 Retour KO with "lecture indisponible"
   *
   * Expected : Retour KO, CAT-1, LECTURE_INDISPONIBLE, "Unexpected error in res database connector: Test Error"
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void dispoRessourceDslAxioneLire_Test_KO_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final String nomUraOrange = RandomStringUtils.randomAlphanumeric(10);
    final String techno = RandomStringUtils.randomAlphanumeric(5);
    final String nbPaire = RandomStringUtils.randomAlphanumeric(1);
    final String typeKP = RandomStringUtils.randomAlphanumeric(5);
    final String message = MessageFormat.format(Messages.getString("res.unexpectedError"), "Test Error"); //$NON-NLS-1$ //$NON-NLS-2$
    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT1, IMegSpiritConsts.LECTURE_INDISPONIBLE, message, null);
    final GetDispoRessourceDSLAxioneResponse getDispoRessourceDSLAxioneResponse = new GetDispoRessourceDSLAxioneResponse(RetourConverter.convertToJsonRetour(retour), null);
    final String partnerResponse = RavelJsonTools.getInstance().toJson(getDispoRessourceDSLAxioneResponse, GetDispoRessourceDSLAxioneResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_dispoRessourceDslAxioneUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<DispoRessourceDSLAxione>> result = _connector.dispoRessourceDslAxioneLire(tracabilite, nomUraOrange, techno, nbPaire, typeKP);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    RESConnectorTest.checkQueryParams(queryParamsCapture, PARAM_NOM_URA_ORANGE, nomUraOrange);
    RESConnectorTest.checkQueryParams(queryParamsCapture, PARAM_TECHNO, techno);
    RESConnectorTest.checkQueryParams(queryParamsCapture, PARAM_NB_PAIRE, nbPaire);
    RESConnectorTest.checkQueryParams(queryParamsCapture, PARAM_NOM_URA_ORANGE, nomUraOrange);

    Assert.assertEquals(retour, result._first);
    Assert.assertEquals(new ArrayList<>(), result._second);
  }

  /**
   * Test the method {@link RESConnector#dispoRessourceDslAxioneLire(Tracabilite, String, String, String, String)}
   * httpStatus 200 jsonResponse null (throws RavelException)
   *
   * Expected : null JsonResponse - Retour KO, CAT-10, TRAITEMENT_ARRETE, "Impossible de récupérer la réponse"
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void dispoRessourceDslAxioneLire_Test_KO_002() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final String nomUraOrange = RandomStringUtils.randomAlphanumeric(10);
    final String techno = RandomStringUtils.randomAlphanumeric(5);
    final String nbPaire = RandomStringUtils.randomAlphanumeric(1);
    final String typeKP = RandomStringUtils.randomAlphanumeric(5);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_dispoRessourceDslAxioneUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    // Call connector
    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<DispoRessourceDSLAxione>> result = _connector.dispoRessourceDslAxioneLire(tracabilite, nomUraOrange, techno, nbPaire, typeKP);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    RESConnectorTest.checkQueryParams(queryParamsCapture, PARAM_NOM_URA_ORANGE, nomUraOrange);
    RESConnectorTest.checkQueryParams(queryParamsCapture, PARAM_TECHNO, techno);
    RESConnectorTest.checkQueryParams(queryParamsCapture, PARAM_NB_PAIRE, nbPaire);
    RESConnectorTest.checkQueryParams(queryParamsCapture, PARAM_NOM_URA_ORANGE, nomUraOrange);

    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, RESConnectorTest.JSON_ERROR_MESSAGE, null);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test OK for the method
   * {@link RESConnector#dispoRessourceDslAxioneLire(Tracabilite, String, String, String, String)} httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void dispoRessourceDslAxioneLire_Test_OK_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final String nomUraOrange = RandomStringUtils.randomAlphanumeric(10);
    final String techno = RandomStringUtils.randomAlphanumeric(5);
    final String nbPaire = RandomStringUtils.randomAlphanumeric(1);
    final String typeKP = RandomStringUtils.randomAlphanumeric(5);

    final DispoRessourceDSLAxione dispoRessourceDSLAxione = _podam.manufacturePojoWithFullData(DispoRessourceDSLAxione.class);
    final List<DispoRessourceDSLAxione> listDispoRessourceDSLAxione = new ArrayList<>();
    listDispoRessourceDSLAxione.add(dispoRessourceDSLAxione);
    final Retour retour = RetourFactoryForTU.createOkRetour();
    final GetDispoRessourceDSLAxioneResponse getDispoRessourceDSLAxioneResponse = new GetDispoRessourceDSLAxioneResponse(RetourConverter.convertToJsonRetour(retour), listDispoRessourceDSLAxione);

    final String partnerResponse = RavelJsonTools.getInstance().toJson(getDispoRessourceDSLAxioneResponse, GetDispoRessourceDSLAxioneResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_dispoRessourceDslAxioneUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<DispoRessourceDSLAxione>> result = _connector.dispoRessourceDslAxioneLire(tracabilite, nomUraOrange, techno, nbPaire, typeKP);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    RESConnectorTest.checkQueryParams(queryParamsCapture, PARAM_NOM_URA_ORANGE, nomUraOrange);
    RESConnectorTest.checkQueryParams(queryParamsCapture, PARAM_TECHNO, techno);
    RESConnectorTest.checkQueryParams(queryParamsCapture, PARAM_NB_PAIRE, nbPaire);
    RESConnectorTest.checkQueryParams(queryParamsCapture, PARAM_NOM_URA_ORANGE, nomUraOrange);

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertEquals(listDispoRessourceDSLAxione, result._second);
  }

  /**
   * Test the method {@link RESConnector#dispoRessourceDslAxioneLireParNomUra(Tracabilite, String)} httpStatus 200
   * Retour KO with "lecture indisponible"
   *
   * Expected : Retour KO, CAT-1, LECTURE_INDISPONIBLE, "Unexpected error in res database connector: Test Error"
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void dispoRessourceDslAxioneLireParNomUra_Test_KO_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final String nomUraOrange = RandomStringUtils.randomAlphanumeric(10);
    final String message = MessageFormat.format(Messages.getString("res.unexpectedError"), "Test Error"); //$NON-NLS-1$ //$NON-NLS-2$
    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT1, IMegSpiritConsts.LECTURE_INDISPONIBLE, message, null);
    final GetDispoRessourceDSLAxioneResponse getDispoRessourceDSLAxioneResponse = new GetDispoRessourceDSLAxioneResponse(RetourConverter.convertToJsonRetour(retour), null);
    final String partnerResponse = RavelJsonTools.getInstance().toJson(getDispoRessourceDSLAxioneResponse, GetDispoRessourceDSLAxioneResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_dispoRessourceDslAxioneUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<DispoRessourceDSLAxione>> result = _connector.dispoRessourceDslAxioneLireParNomUra(tracabilite, nomUraOrange);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    RESConnectorTest.checkQueryParams(queryParamsCapture, PARAM_NOM_URA_ORANGE, nomUraOrange);

    Assert.assertEquals(retour, result._first);
    Assert.assertEquals(new ArrayList<>(), result._second);
  }

  /**
   * Test the method {@link RESConnector#dispoRessourceDslAxioneLireParNomUra(Tracabilite, String)} httpStatus 200
   * jsonResponse null (throws RavelException)
   *
   * Expected : null JsonResponse - Retour KO, CAT-10, TRAITEMENT_ARRETE, "Impossible de récupérer la réponse"
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void dispoRessourceDslAxioneLireParNomUra_Test_KO_002() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final String nomUraOrange = RandomStringUtils.randomAlphanumeric(10);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_dispoRessourceDslAxioneUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    // Call connector
    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<DispoRessourceDSLAxione>> result = _connector.dispoRessourceDslAxioneLireParNomUra(tracabilite, nomUraOrange);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    RESConnectorTest.checkQueryParams(queryParamsCapture, PARAM_NOM_URA_ORANGE, nomUraOrange);

    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, RESConnectorTest.JSON_ERROR_MESSAGE, null);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test OK for the method {@link RESConnector#dispoRessourceDslAxioneLireParNomUra(Tracabilite, String)} httpStatus
   * 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void dispoRessourceDslAxioneLireParNomUra_Test_OK_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final String nomUraOrange = RandomStringUtils.randomAlphanumeric(10);
    final DispoRessourceDSLAxione dispoRessourceDSLAxione = _podam.manufacturePojoWithFullData(DispoRessourceDSLAxione.class);
    final List<DispoRessourceDSLAxione> listDispoRessourceDSLAxione = new ArrayList<>();
    listDispoRessourceDSLAxione.add(dispoRessourceDSLAxione);
    final Retour retour = RetourFactoryForTU.createOkRetour();
    final GetDispoRessourceDSLAxioneResponse getDispoRessourceDSLAxioneResponse = new GetDispoRessourceDSLAxioneResponse(RetourConverter.convertToJsonRetour(retour), listDispoRessourceDSLAxione);

    final String partnerResponse = RavelJsonTools.getInstance().toJson(getDispoRessourceDSLAxioneResponse, GetDispoRessourceDSLAxioneResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_dispoRessourceDslAxioneUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<DispoRessourceDSLAxione>> result = _connector.dispoRessourceDslAxioneLireParNomUra(tracabilite, nomUraOrange);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    RESConnectorTest.checkQueryParams(queryParamsCapture, PARAM_NOM_URA_ORANGE, nomUraOrange);

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertEquals(listDispoRessourceDSLAxione, result._second);
  }

  /**
   * Test the method {@link RESConnector#dispoRessourceDslBouyguesLire(Tracabilite, String, String, String, String)}
   * httpStatus 200 Retour KO with "lecture indisponible"
   *
   * Expected : Retour KO, CAT-1, LECTURE_INDISPONIBLE, "Unexpected error in res database connector: Test Error"
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void dispoRessourceDslBouyguesLire_Test_KO_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final String nomUraOrange = RandomStringUtils.randomAlphanumeric(10);
    final String techno = RandomStringUtils.randomAlphanumeric(5);
    final String nbPaire = RandomStringUtils.randomAlphanumeric(1);
    final String typeKP = RandomStringUtils.randomAlphanumeric(5);
    final String message = MessageFormat.format(Messages.getString("res.unexpectedError"), "Test Error"); //$NON-NLS-1$ //$NON-NLS-2$
    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT1, IMegSpiritConsts.LECTURE_INDISPONIBLE, message, null);
    final GetDispoRessourceDSLBouyguesResponse getDispoRessourceDSLBouyguesResponse = new GetDispoRessourceDSLBouyguesResponse(RetourConverter.convertToJsonRetour(retour), null);
    final String partnerResponse = RavelJsonTools.getInstance().toJson(getDispoRessourceDSLBouyguesResponse, GetDispoRessourceDSLBouyguesResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_dispoRessourceDslBouyguesUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<DispoRessourceDSLBouygues>> result = _connector.dispoRessourceDslBouyguesLire(tracabilite, nomUraOrange, techno, nbPaire, typeKP);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    RESConnectorTest.checkQueryParams(queryParamsCapture, PARAM_NOM_URA_ORANGE, nomUraOrange);
    RESConnectorTest.checkQueryParams(queryParamsCapture, PARAM_TECHNO, techno);
    RESConnectorTest.checkQueryParams(queryParamsCapture, PARAM_NB_PAIRE, nbPaire);
    RESConnectorTest.checkQueryParams(queryParamsCapture, PARAM_NOM_URA_ORANGE, nomUraOrange);

    Assert.assertEquals(retour, result._first);
    Assert.assertEquals(new ArrayList<>(), result._second);
  }

  /**
   * Test the method {@link RESConnector#dispoRessourceDslBouyguesLire(Tracabilite, String, String, String, String)}
   * httpStatus 200 jsonResponse null (throws RavelException)
   *
   * Expected : null JsonResponse - Retour KO, CAT-10, TRAITEMENT_ARRETE, "Impossible de récupérer la réponse"
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void dispoRessourceDslBouyguesLire_Test_KO_002() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final String nomUraOrange = RandomStringUtils.randomAlphanumeric(10);
    final String techno = RandomStringUtils.randomAlphanumeric(5);
    final String nbPaire = RandomStringUtils.randomAlphanumeric(1);
    final String typeKP = RandomStringUtils.randomAlphanumeric(5);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_dispoRessourceDslBouyguesUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    // Call connector
    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<DispoRessourceDSLBouygues>> result = _connector.dispoRessourceDslBouyguesLire(tracabilite, nomUraOrange, techno, nbPaire, typeKP);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    RESConnectorTest.checkQueryParams(queryParamsCapture, PARAM_NOM_URA_ORANGE, nomUraOrange);
    RESConnectorTest.checkQueryParams(queryParamsCapture, PARAM_TECHNO, techno);
    RESConnectorTest.checkQueryParams(queryParamsCapture, PARAM_NB_PAIRE, nbPaire);
    RESConnectorTest.checkQueryParams(queryParamsCapture, PARAM_NOM_URA_ORANGE, nomUraOrange);

    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, RESConnectorTest.JSON_ERROR_MESSAGE, null);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test OK for the method
   * {@link RESConnector#dispoRessourceDslBouyguesLire(Tracabilite, String, String, String, String)} httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void dispoRessourceDslBouyguesLire_Test_OK_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final String nomUraOrange = RandomStringUtils.randomAlphanumeric(10);
    final String techno = RandomStringUtils.randomAlphanumeric(5);
    final String nbPaire = RandomStringUtils.randomAlphanumeric(1);
    final String typeKP = RandomStringUtils.randomAlphanumeric(5);

    final DispoRessourceDSLBouygues dispoRessourceDSLBouygues = _podam.manufacturePojoWithFullData(DispoRessourceDSLBouygues.class);
    final List<DispoRessourceDSLBouygues> listDispoRessourceDSLBouygues = new ArrayList<>();
    listDispoRessourceDSLBouygues.add(dispoRessourceDSLBouygues);
    final Retour retour = RetourFactoryForTU.createOkRetour();
    final GetDispoRessourceDSLBouyguesResponse getDispoRessourceDSLBouyguesResponse = new GetDispoRessourceDSLBouyguesResponse(RetourConverter.convertToJsonRetour(retour), listDispoRessourceDSLBouygues);

    final String partnerResponse = RavelJsonTools.getInstance().toJson(getDispoRessourceDSLBouyguesResponse, GetDispoRessourceDSLBouyguesResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_dispoRessourceDslBouyguesUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<DispoRessourceDSLBouygues>> result = _connector.dispoRessourceDslBouyguesLire(tracabilite, nomUraOrange, techno, nbPaire, typeKP);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    RESConnectorTest.checkQueryParams(queryParamsCapture, PARAM_NOM_URA_ORANGE, nomUraOrange);
    RESConnectorTest.checkQueryParams(queryParamsCapture, PARAM_TECHNO, techno);
    RESConnectorTest.checkQueryParams(queryParamsCapture, PARAM_NB_PAIRE, nbPaire);
    RESConnectorTest.checkQueryParams(queryParamsCapture, PARAM_NOM_URA_ORANGE, nomUraOrange);

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertEquals(listDispoRessourceDSLBouygues, result._second);
  }

  /**
   * Test the method {@link RESConnector#dispoRessourceDslBouyguesLireParNomUra(Tracabilite, String)} httpStatus 200
   * Retour KO with "lecture indisponible"
   *
   * Expected : Retour KO, CAT-1, LECTURE_INDISPONIBLE, "Unexpected error in res database connector: Test Error"
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void dispoRessourceDslBouyguesLireParNomUra_Test_KO_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final String nomUraOrange = RandomStringUtils.randomAlphanumeric(10);
    final String message = MessageFormat.format(Messages.getString("res.unexpectedError"), "Test Error"); //$NON-NLS-1$ //$NON-NLS-2$
    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT1, IMegSpiritConsts.LECTURE_INDISPONIBLE, message, null);
    final GetDispoRessourceDSLBouyguesResponse getDispoRessourceDSLBouyguesResponse = new GetDispoRessourceDSLBouyguesResponse(RetourConverter.convertToJsonRetour(retour), null);
    final String partnerResponse = RavelJsonTools.getInstance().toJson(getDispoRessourceDSLBouyguesResponse, GetDispoRessourceDSLBouyguesResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_dispoRessourceDslBouyguesUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<DispoRessourceDSLBouygues>> result = _connector.dispoRessourceDslBouyguesLireParNomUra(tracabilite, nomUraOrange);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    RESConnectorTest.checkQueryParams(queryParamsCapture, PARAM_NOM_URA_ORANGE, nomUraOrange);

    Assert.assertEquals(retour, result._first);
    Assert.assertEquals(new ArrayList<>(), result._second);
  }

  /**
   * Test the method {@link RESConnector#dispoRessourceDslBouyguesLireParNomUra(Tracabilite, String)} httpStatus 200
   * jsonResponse null (throws RavelException)
   *
   * Expected : null JsonResponse - Retour KO, CAT-10, TRAITEMENT_ARRETE, "Impossible de récupérer la réponse"
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void dispoRessourceDslBouyguesLireParNomUra_Test_KO_002() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final String nomUraOrange = RandomStringUtils.randomAlphanumeric(10);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_dispoRessourceDslBouyguesUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    // Call connector
    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<DispoRessourceDSLBouygues>> result = _connector.dispoRessourceDslBouyguesLireParNomUra(tracabilite, nomUraOrange);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    RESConnectorTest.checkQueryParams(queryParamsCapture, PARAM_NOM_URA_ORANGE, nomUraOrange);

    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, RESConnectorTest.JSON_ERROR_MESSAGE, null);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test OK for the method {@link RESConnector#dispoRessourceDslBouyguesLireParNomUra(Tracabilite, String)} httpStatus
   * 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void dispoRessourceDslBouyguesLireParNomUra_Test_OK_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final String nomUraOrange = RandomStringUtils.randomAlphanumeric(10);
    final DispoRessourceDSLBouygues dispoRessourceDSLBouygues = _podam.manufacturePojoWithFullData(DispoRessourceDSLBouygues.class);
    final List<DispoRessourceDSLBouygues> listDispoRessourceDSLBouygues = new ArrayList<>();
    listDispoRessourceDSLBouygues.add(dispoRessourceDSLBouygues);
    final Retour retour = RetourFactoryForTU.createOkRetour();
    final GetDispoRessourceDSLBouyguesResponse getDispoRessourceDSLBouyguesResponse = new GetDispoRessourceDSLBouyguesResponse(RetourConverter.convertToJsonRetour(retour), listDispoRessourceDSLBouygues);

    final String partnerResponse = RavelJsonTools.getInstance().toJson(getDispoRessourceDSLBouyguesResponse, GetDispoRessourceDSLBouyguesResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_dispoRessourceDslBouyguesUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<DispoRessourceDSLBouygues>> result = _connector.dispoRessourceDslBouyguesLireParNomUra(tracabilite, nomUraOrange);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    RESConnectorTest.checkQueryParams(queryParamsCapture, PARAM_NOM_URA_ORANGE, nomUraOrange);

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertEquals(listDispoRessourceDSLBouygues, result._second);
  }

  /**
   * Test the method {@link RESConnector#dispoRessourceDslOrangeLire(Tracabilite, String, String, String, String)}
   * httpStatus 200 Retour KO with "lecture indisponible"
   *
   * Expected : Retour KO, CAT-1, LECTURE_INDISPONIBLE, "Unexpected error in res database connector: Test Error"
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void dispoRessourceDslOrangeLire_Test_KO_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final String nomUraOrange = RandomStringUtils.randomAlphanumeric(10);
    final String techno = RandomStringUtils.randomAlphanumeric(5);
    final String nbPaire = RandomStringUtils.randomAlphanumeric(1);
    final String typeKP = RandomStringUtils.randomAlphanumeric(5);
    final String message = MessageFormat.format(Messages.getString("res.unexpectedError"), "Test Error"); //$NON-NLS-1$ //$NON-NLS-2$
    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT1, IMegSpiritConsts.LECTURE_INDISPONIBLE, message, null);
    final GetDispoRessourceDSLOrangeResponse getDispoRessourceDSLOrangeResponse = new GetDispoRessourceDSLOrangeResponse(RetourConverter.convertToJsonRetour(retour), null);
    final String partnerResponse = RavelJsonTools.getInstance().toJson(getDispoRessourceDSLOrangeResponse, GetDispoRessourceDSLOrangeResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_dispoRessourceDslOrangeUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<DispoRessourceDSLOrange>> result = _connector.dispoRessourceDslOrangeLire(tracabilite, nomUraOrange, techno, nbPaire, typeKP);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    RESConnectorTest.checkQueryParams(queryParamsCapture, PARAM_NOM_URA_ORANGE, nomUraOrange);
    RESConnectorTest.checkQueryParams(queryParamsCapture, PARAM_TECHNO, techno);
    RESConnectorTest.checkQueryParams(queryParamsCapture, PARAM_NB_PAIRE, nbPaire);
    RESConnectorTest.checkQueryParams(queryParamsCapture, PARAM_NOM_URA_ORANGE, nomUraOrange);

    Assert.assertEquals(retour, result._first);
    Assert.assertEquals(new ArrayList<>(), result._second);
  }

  /**
   * Test the method {@link RESConnector#dispoRessourceDslOrangeLire(Tracabilite, String, String, String, String)}
   * httpStatus 200 jsonResponse null (throws RavelException)
   *
   * Expected : null JsonResponse - Retour KO, CAT-10, TRAITEMENT_ARRETE, "Impossible de récupérer la réponse"
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void dispoRessourceDslOrangeLire_Test_KO_002() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final String nomUraOrange = RandomStringUtils.randomAlphanumeric(10);
    final String techno = RandomStringUtils.randomAlphanumeric(5);
    final String nbPaire = RandomStringUtils.randomAlphanumeric(1);
    final String typeKP = RandomStringUtils.randomAlphanumeric(5);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_dispoRessourceDslOrangeUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    // Call connector
    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<DispoRessourceDSLOrange>> result = _connector.dispoRessourceDslOrangeLire(tracabilite, nomUraOrange, techno, nbPaire, typeKP);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    RESConnectorTest.checkQueryParams(queryParamsCapture, PARAM_NOM_URA_ORANGE, nomUraOrange);
    RESConnectorTest.checkQueryParams(queryParamsCapture, PARAM_TECHNO, techno);
    RESConnectorTest.checkQueryParams(queryParamsCapture, PARAM_NB_PAIRE, nbPaire);
    RESConnectorTest.checkQueryParams(queryParamsCapture, PARAM_NOM_URA_ORANGE, nomUraOrange);

    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, RESConnectorTest.JSON_ERROR_MESSAGE, null);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test OK for the method
   * {@link RESConnector#dispoRessourceDslOrangeLire(Tracabilite, String, String, String, String)} httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void dispoRessourceDslOrangeLire_Test_OK_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final String nomUraOrange = RandomStringUtils.randomAlphanumeric(10);
    final String techno = RandomStringUtils.randomAlphanumeric(5);
    final String nbPaire = RandomStringUtils.randomAlphanumeric(1);
    final String typeKP = RandomStringUtils.randomAlphanumeric(5);

    final DispoRessourceDSLOrange dispoRessourceDSLOrange = _podam.manufacturePojoWithFullData(DispoRessourceDSLOrange.class);
    final List<DispoRessourceDSLOrange> listDispoRessourceDSLOrange = new ArrayList<>();
    listDispoRessourceDSLOrange.add(dispoRessourceDSLOrange);
    final Retour retour = RetourFactoryForTU.createOkRetour();
    final GetDispoRessourceDSLOrangeResponse getDispoRessourceDSLOrangeResponse = new GetDispoRessourceDSLOrangeResponse(RetourConverter.convertToJsonRetour(retour), listDispoRessourceDSLOrange);

    final String partnerResponse = RavelJsonTools.getInstance().toJson(getDispoRessourceDSLOrangeResponse, GetDispoRessourceDSLOrangeResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_dispoRessourceDslOrangeUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<DispoRessourceDSLOrange>> result = _connector.dispoRessourceDslOrangeLire(tracabilite, nomUraOrange, techno, nbPaire, typeKP);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    RESConnectorTest.checkQueryParams(queryParamsCapture, PARAM_NOM_URA_ORANGE, nomUraOrange);
    RESConnectorTest.checkQueryParams(queryParamsCapture, PARAM_TECHNO, techno);
    RESConnectorTest.checkQueryParams(queryParamsCapture, PARAM_NB_PAIRE, nbPaire);
    RESConnectorTest.checkQueryParams(queryParamsCapture, PARAM_NOM_URA_ORANGE, nomUraOrange);

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertEquals(listDispoRessourceDSLOrange, result._second);
  }

  /**
   * Test the method {@link RESConnector#dispoRessourceDslOrangeLireParNomUra(Tracabilite, String)} httpStatus 200
   * Retour KO with "lecture indisponible"
   *
   * Expected : Retour KO, CAT-1, LECTURE_INDISPONIBLE, "Unexpected error in res database connector: Test Error"
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void dispoRessourceDslOrangeLireParNomUra_Test_KO_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final String nomUraOrange = RandomStringUtils.randomAlphanumeric(10);
    final String message = MessageFormat.format(Messages.getString("res.unexpectedError"), "Test Error"); //$NON-NLS-1$ //$NON-NLS-2$
    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT1, IMegSpiritConsts.LECTURE_INDISPONIBLE, message, null);
    final GetDispoRessourceDSLOrangeResponse getDispoRessourceDSLOrangeResponse = new GetDispoRessourceDSLOrangeResponse(RetourConverter.convertToJsonRetour(retour), null);
    final String partnerResponse = RavelJsonTools.getInstance().toJson(getDispoRessourceDSLOrangeResponse, GetDispoRessourceDSLOrangeResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_dispoRessourceDslOrangeUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<DispoRessourceDSLOrange>> result = _connector.dispoRessourceDslOrangeLireParNomUra(tracabilite, nomUraOrange);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    RESConnectorTest.checkQueryParams(queryParamsCapture, PARAM_NOM_URA_ORANGE, nomUraOrange);

    Assert.assertEquals(retour, result._first);
    Assert.assertEquals(new ArrayList<>(), result._second);
  }

  /**
   * Test the method {@link RESConnector#dispoRessourceDslOrangeLireParNomUra(Tracabilite, String)} httpStatus 200
   * jsonResponse null (throws RavelException)
   *
   * Expected : null JsonResponse - Retour KO, CAT-10, TRAITEMENT_ARRETE, "Impossible de récupérer la réponse"
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void dispoRessourceDslOrangeLireParNomUra_Test_KO_002() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final String nomUraOrange = RandomStringUtils.randomAlphanumeric(10);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_dispoRessourceDslOrangeUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    // Call connector
    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<DispoRessourceDSLOrange>> result = _connector.dispoRessourceDslOrangeLireParNomUra(tracabilite, nomUraOrange);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    RESConnectorTest.checkQueryParams(queryParamsCapture, PARAM_NOM_URA_ORANGE, nomUraOrange);

    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, RESConnectorTest.JSON_ERROR_MESSAGE, null);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test OK for the method {@link RESConnector#dispoRessourceDslOrangeLireParNomUra(Tracabilite, String)} httpStatus
   * 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void dispoRessourceDslOrangeLireParNomUra_Test_OK_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final String nomUraOrange = RandomStringUtils.randomAlphanumeric(10);
    final DispoRessourceDSLOrange dispoRessourceDSLOrange = _podam.manufacturePojoWithFullData(DispoRessourceDSLOrange.class);
    final List<DispoRessourceDSLOrange> listDispoRessourceDSLOrange = new ArrayList<>();
    listDispoRessourceDSLOrange.add(dispoRessourceDSLOrange);
    final Retour retour = RetourFactoryForTU.createOkRetour();
    final GetDispoRessourceDSLOrangeResponse getDispoRessourceDSLOrangeResponse = new GetDispoRessourceDSLOrangeResponse(RetourConverter.convertToJsonRetour(retour), listDispoRessourceDSLOrange);

    final String partnerResponse = RavelJsonTools.getInstance().toJson(getDispoRessourceDSLOrangeResponse, GetDispoRessourceDSLOrangeResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_dispoRessourceDslOrangeUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<DispoRessourceDSLOrange>> result = _connector.dispoRessourceDslOrangeLireParNomUra(tracabilite, nomUraOrange);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    RESConnectorTest.checkQueryParams(queryParamsCapture, PARAM_NOM_URA_ORANGE, nomUraOrange);

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertEquals(listDispoRessourceDSLOrange, result._second);
  }

  /**
   * Test the method {@link RESConnector#dispoRessourceDslSFRLire(Tracabilite, String, String, String, String)}
   * httpStatus 200 Retour KO with "lecture indisponible"
   *
   * Expected : Retour KO, CAT-1, LECTURE_INDISPONIBLE, "Unexpected error in res database connector: Test Error"
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void dispoRessourceDslSFRLire_Test_KO_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final String nomUraOrange = RandomStringUtils.randomAlphanumeric(10);
    final String techno = RandomStringUtils.randomAlphanumeric(5);
    final String nbPaire = RandomStringUtils.randomAlphanumeric(1);
    final String typeKP = RandomStringUtils.randomAlphanumeric(5);
    final String message = MessageFormat.format(Messages.getString("res.unexpectedError"), "Test Error"); //$NON-NLS-1$ //$NON-NLS-2$
    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT1, IMegSpiritConsts.LECTURE_INDISPONIBLE, message, null);
    final GetDispoRessourceDSLSFRResponse getDispoRessourceDSLSFRResponse = new GetDispoRessourceDSLSFRResponse(RetourConverter.convertToJsonRetour(retour), null);
    final String partnerResponse = RavelJsonTools.getInstance().toJson(getDispoRessourceDSLSFRResponse, GetDispoRessourceDSLSFRResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_dispoRessourceDslSFRUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<DispoRessourceDSLSFR>> result = _connector.dispoRessourceDslSFRLire(tracabilite, nomUraOrange, techno, nbPaire, typeKP);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    RESConnectorTest.checkQueryParams(queryParamsCapture, PARAM_NOM_URA_ORANGE, nomUraOrange);
    RESConnectorTest.checkQueryParams(queryParamsCapture, PARAM_TECHNO, techno);
    RESConnectorTest.checkQueryParams(queryParamsCapture, PARAM_NB_PAIRE, nbPaire);
    RESConnectorTest.checkQueryParams(queryParamsCapture, PARAM_NOM_URA_ORANGE, nomUraOrange);

    Assert.assertEquals(retour, result._first);
    Assert.assertEquals(new ArrayList<>(), result._second);
  }

  /**
   * Test the method {@link RESConnector#dispoRessourceDslSFRLire(Tracabilite, String, String, String, String)}
   * httpStatus 200 jsonResponse null (throws RavelException)
   *
   * Expected : null JsonResponse - Retour KO, CAT-10, TRAITEMENT_ARRETE, "Impossible de récupérer la réponse"
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void dispoRessourceDslSFRLire_Test_KO_002() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final String nomUraOrange = RandomStringUtils.randomAlphanumeric(10);
    final String techno = RandomStringUtils.randomAlphanumeric(5);
    final String nbPaire = RandomStringUtils.randomAlphanumeric(1);
    final String typeKP = RandomStringUtils.randomAlphanumeric(5);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_dispoRessourceDslSFRUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    // Call connector
    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<DispoRessourceDSLSFR>> result = _connector.dispoRessourceDslSFRLire(tracabilite, nomUraOrange, techno, nbPaire, typeKP);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    RESConnectorTest.checkQueryParams(queryParamsCapture, PARAM_NOM_URA_ORANGE, nomUraOrange);
    RESConnectorTest.checkQueryParams(queryParamsCapture, PARAM_TECHNO, techno);
    RESConnectorTest.checkQueryParams(queryParamsCapture, PARAM_NB_PAIRE, nbPaire);
    RESConnectorTest.checkQueryParams(queryParamsCapture, PARAM_NOM_URA_ORANGE, nomUraOrange);

    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, RESConnectorTest.JSON_ERROR_MESSAGE, null);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test OK for the method {@link RESConnector#dispoRessourceDslSFRLire(Tracabilite, String, String, String, String)}
   * httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void dispoRessourceDslSFRLire_Test_OK_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final String nomUraOrange = RandomStringUtils.randomAlphanumeric(10);
    final String techno = RandomStringUtils.randomAlphanumeric(5);
    final String nbPaire = RandomStringUtils.randomAlphanumeric(1);
    final String typeKP = RandomStringUtils.randomAlphanumeric(5);

    final DispoRessourceDSLSFR dispoRessourceDSLSFR = _podam.manufacturePojoWithFullData(DispoRessourceDSLSFR.class);
    final List<DispoRessourceDSLSFR> listDispoRessourceDSLSFR = new ArrayList<>();
    listDispoRessourceDSLSFR.add(dispoRessourceDSLSFR);
    final Retour retour = RetourFactoryForTU.createOkRetour();
    final GetDispoRessourceDSLSFRResponse getDispoRessourceDSLSFRResponse = new GetDispoRessourceDSLSFRResponse(RetourConverter.convertToJsonRetour(retour), listDispoRessourceDSLSFR);

    final String partnerResponse = RavelJsonTools.getInstance().toJson(getDispoRessourceDSLSFRResponse, GetDispoRessourceDSLSFRResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_dispoRessourceDslSFRUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<DispoRessourceDSLSFR>> result = _connector.dispoRessourceDslSFRLire(tracabilite, nomUraOrange, techno, nbPaire, typeKP);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    RESConnectorTest.checkQueryParams(queryParamsCapture, PARAM_NOM_URA_ORANGE, nomUraOrange);
    RESConnectorTest.checkQueryParams(queryParamsCapture, PARAM_TECHNO, techno);
    RESConnectorTest.checkQueryParams(queryParamsCapture, PARAM_NB_PAIRE, nbPaire);
    RESConnectorTest.checkQueryParams(queryParamsCapture, PARAM_NOM_URA_ORANGE, nomUraOrange);

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertEquals(listDispoRessourceDSLSFR, result._second);
  }

  /**
   * Test the method {@link RESConnector#dispoRessourceDslSFRLireParNomUra(Tracabilite, String)} httpStatus 200 Retour
   * KO with "lecture indisponible"
   *
   * Expected : Retour KO, CAT-1, LECTURE_INDISPONIBLE, "Unexpected error in res database connector: Test Error"
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void dispoRessourceDslSFRLireParNomUra_Test_KO_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final String nomUraOrange = RandomStringUtils.randomAlphanumeric(10);
    final String message = MessageFormat.format(Messages.getString("res.unexpectedError"), "Test Error"); //$NON-NLS-1$ //$NON-NLS-2$
    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT1, IMegSpiritConsts.LECTURE_INDISPONIBLE, message, null);
    final GetDispoRessourceDSLSFRResponse getDispoRessourceDSLSFRResponse = new GetDispoRessourceDSLSFRResponse(RetourConverter.convertToJsonRetour(retour), null);
    final String partnerResponse = RavelJsonTools.getInstance().toJson(getDispoRessourceDSLSFRResponse, GetDispoRessourceDSLSFRResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_dispoRessourceDslSFRUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<DispoRessourceDSLSFR>> result = _connector.dispoRessourceDslSFRLireParNomUra(tracabilite, nomUraOrange);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    RESConnectorTest.checkQueryParams(queryParamsCapture, PARAM_NOM_URA_ORANGE, nomUraOrange);

    Assert.assertEquals(retour, result._first);
    Assert.assertEquals(new ArrayList<>(), result._second);
  }

  /**
   * Test the method {@link RESConnector#dispoRessourceDslSFRLireParNomUra(Tracabilite, String)} httpStatus 200
   * jsonResponse null (throws RavelException)
   *
   * Expected : null JsonResponse - Retour KO, CAT-10, TRAITEMENT_ARRETE, "Impossible de récupérer la réponse"
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void dispoRessourceDslSFRLireParNomUra_Test_KO_002() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final String nomUraOrange = RandomStringUtils.randomAlphanumeric(10);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_dispoRessourceDslSFRUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    // Call connector
    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<DispoRessourceDSLSFR>> result = _connector.dispoRessourceDslSFRLireParNomUra(tracabilite, nomUraOrange);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    RESConnectorTest.checkQueryParams(queryParamsCapture, PARAM_NOM_URA_ORANGE, nomUraOrange);

    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, RESConnectorTest.JSON_ERROR_MESSAGE, null);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test OK for the method {@link RESConnector#dispoRessourceDslSFRLireParNomUra(Tracabilite, String)} httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void dispoRessourceDslSFRLireParNomUra_Test_OK_001() throws Exception
  {
    final Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    final String nomUraOrange = RandomStringUtils.randomAlphanumeric(10);
    final DispoRessourceDSLSFR dispoRessourceDSLSFR = _podam.manufacturePojoWithFullData(DispoRessourceDSLSFR.class);
    final List<DispoRessourceDSLSFR> listDispoRessourceDSLSFR = new ArrayList<>();
    listDispoRessourceDSLSFR.add(dispoRessourceDSLSFR);
    final Retour retour = RetourFactoryForTU.createOkRetour();
    final GetDispoRessourceDSLSFRResponse getDispoRessourceDSLSFRResponse = new GetDispoRessourceDSLSFRResponse(RetourConverter.convertToJsonRetour(retour), listDispoRessourceDSLSFR);

    final String partnerResponse = RavelJsonTools.getInstance().toJson(getDispoRessourceDSLSFRResponse, GetDispoRessourceDSLSFRResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_dispoRessourceDslSFRUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<DispoRessourceDSLSFR>> result = _connector.dispoRessourceDslSFRLireParNomUra(tracabilite, nomUraOrange);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    RESConnectorTest.checkQueryParams(queryParamsCapture, PARAM_NOM_URA_ORANGE, nomUraOrange);

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertEquals(listDispoRessourceDSLSFR, result._second);
  }

  /**
   * @throws Exception
   *           Exception
   */
  @Test
  public void test_loadConnectorConfiguration() throws Exception
  {
    final Connector connector = new Connector();

    Param param = new Param();
    param.setName("PAD3017_PATH_PARAM"); //$NON-NLS-1$
    param.setValue(_dispoRessourceDslOrangeUrl);
    connector.getParam().add(param);

    param = new Param();
    param.setName("PAD3018_PATH_PARAM"); //$NON-NLS-1$
    param.setValue(_dispoRessourceDslBouyguesUrl);
    connector.getParam().add(param);

    param = new Param();
    param.setName("PAD3019_PATH_PARAM"); //$NON-NLS-1$
    param.setValue(_dispoRessourceDslAxioneUrl);
    connector.getParam().add(param);

    param = new Param();
    param.setName("PAD3020_PATH_PARAM"); //$NON-NLS-1$
    param.setValue(_dispoRessourceDslSFRUrl);
    connector.getParam().add(param);

    param = new Param();
    param.setName("AccesTechniqueCacheDuration"); //$NON-NLS-1$
    param.setValue("PT10M"); //$NON-NLS-1$
    connector.getParam().add(param);

    param = new Param();
    param.setName("AbaqueDSLCacheDuration"); //$NON-NLS-1$
    param.setValue("PT10M"); //$NON-NLS-1$
    connector.getParam().add(param);

    connector.setURLS(RESConnectorTest.generateURLS());

    // test
    _connector.loadConnectorConfiguration(connector);

    // assertions
    Assert.assertEquals(_dispoRessourceDslOrangeUrl, JUnitTools.getInaccessibleFieldValue(_connector, "_dispoRessourceDslOrangeUrl")); //$NON-NLS-1$
    Assert.assertEquals(_dispoRessourceDslBouyguesUrl, JUnitTools.getInaccessibleFieldValue(_connector, "_dispoRessourceDslBouyguesUrl")); //$NON-NLS-1$
    Assert.assertEquals(_dispoRessourceDslAxioneUrl, JUnitTools.getInaccessibleFieldValue(_connector, "_dispoRessourceDslAxioneUrl")); //$NON-NLS-1$
    Assert.assertEquals(_dispoRessourceDslSFRUrl, JUnitTools.getInaccessibleFieldValue(_connector, "_dispoRessourceDslSFRUrl")); //$NON-NLS-1$
    Assert.assertNotNull(JUnitTools.getInaccessibleFieldValue(_connector, "_dispoRessourceDSLService")); //$NON-NLS-1$
    Assert.assertEquals(Duration.parse("PT10M"), JUnitTools.getInaccessibleFieldValue(_connector, "_accesTechniqueCacheDuration")); //$NON-NLS-1$
    Assert.assertEquals(Duration.parse("PT10M"), JUnitTools.getInaccessibleFieldValue(_connector, "_abaqueDslCacheDuration")); //$NON-NLS-1$
  }

  /**
   * prepare mock scenario to initialize method sendRequest from AbstractRestConnector
   *
   * @throws Exception
   *           Thrown in case of error
   */
  private void initializeMocksForSendRequest() throws Exception
  {
    final String urlBalancedElementName = RandomStringUtils.randomAlphanumeric(45);
    final String urlBalancedElementDescription = RandomStringUtils.randomAlphabetic(9);

    EasyMock.expect(_loadBalancerMock.chooseBalancedElement()).andReturn(_urlBalancedElementMock);
    EasyMock.expect(_urlBalancedElementMock.getName()).andReturn(urlBalancedElementName);
    EasyMock.expect(_urlBalancedElementMock.getDescription()).andReturn(urlBalancedElementDescription);
    EasyMock.expect(_urlBalancedElementMock.getName()).andReturn(urlBalancedElementName);
    EasyMock.expect(_connectorPoolMock.get(urlBalancedElementName)).andReturn(_restConnectorPoolMock);
    EasyMock.expect(_restConnectorPoolMock.borrowObject()).andReturn(_restInstanceMock);
  }
}
