/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.res;

import org.easymock.EasyMock;
import org.easymock.EasyMockSupport;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockNice;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.IActivityCaller;
import com.bytel.spirit.common.connectors.res.activities.RES2106_EffacerReferentielSecondaire;
import com.bytel.spirit.common.connectors.res.activities.RES2106_EffacerReferentielSecondaire.RES2106_EffacerReferentielSecondaireBuilder;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author dangelis
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({ RESProxy.class })
public class RES2106_EffacerReferentielSecondaire_Test extends EasyMockSupport
{
  /**
   *
   */
  private RES2106_EffacerReferentielSecondaire _activite;
  /**
   * Factory de génération des beans
   */
  private PodamFactory _podam = new PodamFactoryImpl();

  /**
   * Mock de {@link RESProxy}
   */
  @MockStrict
  RESProxy _resProxy;

  /**
   * Mock de {@link IActivityCaller}
   */
  @MockNice
  IActivityCaller _activityCallerMock;

  /**
   *
   */
  @Before
  public void beforeTest()
  {

    // désactivation du cache podam
    _podam.getStrategy().setMemoization(false);

    // on réinitialise tous les mocks afin de ne pas avoir d'interférence entre les tests
    PowerMock.resetAll();

    // On initialise toutes les classes à mocker comportant un appel à un eméthode statique
    // Dans notre cas on mock statiquemement toutes les classes des activités et des proxys appelés (pour les createContexte et le getInstance)
    PowerMock.mockStaticStrict(RES2106_EffacerReferentielSecondaire.class);
    PowerMock.mockStaticStrict(RESProxy.class);
  }

  /**
   * Incorrect builder
   */
  @Test
  public void test001()
  {
    _activite = new RES2106_EffacerReferentielSecondaireBuilder().build();
    Assert.assertEquals(StringConstants.NOK, _activite.getRetour().getResultat());
    Assert.assertEquals("CAT-3", _activite.getRetour().getCategorie()); //$NON-NLS-1$
    Assert.assertEquals("Parametre d'entree de l'activite non renseignee", _activite.getRetour().getLibelle()); //$NON-NLS-1$
  }

  /**
   * Incorrect builder
   */
  @Test
  public void test002()
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    _activite = new RES2106_EffacerReferentielSecondaireBuilder().tracabilite(tracabilite).build();
    Assert.assertEquals(StringConstants.NOK, _activite.getRetour().getResultat());
    Assert.assertEquals("CAT-3", _activite.getRetour().getCategorie()); //$NON-NLS-1$
    Assert.assertEquals("Parametre d'entree de l'activite non renseignee", _activite.getRetour().getLibelle()); //$NON-NLS-1$
  }

  /**
   * Incorrect builder
   */
  @Test
  public void test003()
  {
    _activite = new RES2106_EffacerReferentielSecondaireBuilder().nomGroupFichiers("Test").build(); //$NON-NLS-1$
    Assert.assertEquals(StringConstants.NOK, _activite.getRetour().getResultat());
    Assert.assertEquals("CAT-3", _activite.getRetour().getCategorie()); //$NON-NLS-1$
    Assert.assertEquals("Parametre d'entree de l'activite non renseignee", _activite.getRetour().getLibelle()); //$NON-NLS-1$

  }

  /**
   * Request KO
   *
   * @throws RavelException
   *           RavelException
   */
  @Test
  public void test004() throws RavelException
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    Retour expectedRetour = RetourFactory.createNOK("CAT-4", "DONNEE_INCONNUE", "Nom de groupe de fichiers ELIG PREV inconnu"); //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$
    ConnectorResponse<Retour, Boolean> expectedResponse = new ConnectorResponse<Retour, Boolean>(expectedRetour, false);
    _activite = new RES2106_EffacerReferentielSecondaireBuilder().tracabilite(tracabilite).nomGroupFichiers("ELIG PREV").build(); //$NON-NLS-1$
    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxy);
    EasyMock.expect(_resProxy.pad3003IntegrationGroupeFichierDelete(tracabilite, "ELIG PREV", "EFFACER_REFERENTIEL_SECONDAIRE")).andReturn(expectedResponse); //$NON-NLS-1$ //$NON-NLS-2$
    PowerMock.replayAll();
    Retour result = _activite.execute(_activityCallerMock);
    PowerMock.verifyAll();
    Assert.assertEquals(expectedRetour, _activite.getRetour());
    Assert.assertEquals(expectedRetour, result);

  }

  /**
   * NommGroupFichierIncorrect
   *
   * @throws RavelException
   *           RavelException
   */
  @Test
  public void test005() throws RavelException
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    Retour expectedRetour = RetourFactory.createNOK("CAT-3", "ENTREE_INCORRECTE", "ELIG PREVe"); //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$
    _activite = new RES2106_EffacerReferentielSecondaireBuilder().tracabilite(tracabilite).nomGroupFichiers("ELIG PREVe").build(); //$NON-NLS-1$
    Retour result = _activite.execute(_activityCallerMock);

    Assert.assertEquals(expectedRetour, _activite.getRetour());
    Assert.assertEquals(expectedRetour, result);

  }
}
