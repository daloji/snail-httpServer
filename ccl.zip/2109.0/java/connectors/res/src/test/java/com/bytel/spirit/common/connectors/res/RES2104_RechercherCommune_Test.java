/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.res;

import org.easymock.EasyMock;
import org.easymock.EasyMockSupport;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockNice;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.IActivityCaller;
import com.bytel.spirit.common.connectors.res.activities.RES2104_RechercherCommune;
import com.bytel.spirit.common.connectors.res.activities.RES2104_RechercherCommune.RES2104_RechercherCommuneBuilder;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.Commune;
import com.bytel.spirit.common.shared.saab.res.response.ListeCommuneResponse;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author dangelis
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({ RESProxy.class })
public class RES2104_RechercherCommune_Test extends EasyMockSupport
{
  /**
   * activité testée
   */
  private RES2104_RechercherCommune _activite;

  /**
   * Factory de génération des beans
   */
  private PodamFactory _podam = new PodamFactoryImpl();

  /**
   * Mock de {@link RESProxy}
   */
  @MockStrict
  RESProxy _resProxy;

  /**
   * Mock de {@link IActivityCaller}
   */
  @MockNice
  IActivityCaller _activityCallerMock;

  /**
   *
   */
  @Before
  public void beforeTest()
  {

    // désactivation du cache podam
    _podam.getStrategy().setMemoization(false);

    // on réinitialise tous les mocks afin de ne pas avoir d'interférence entre les tests
    PowerMock.resetAll();

    // On initialise toutes les classes à mocker comportant un appel à un eméthode statique
    // Dans notre cas on mock statiquemement toutes les classes des activités et des proxys appelés (pour les createContexte et le getInstance)
    PowerMock.mockStaticStrict(RES2104_RechercherCommune.class);
    PowerMock.mockStaticStrict(RESProxy.class);
  }

  /**
   * builder incorrect
   *
   * @throws RavelException
   *           RavelException
   */
  @Test
  public void test001() throws RavelException
  {

    _activite = new RES2104_RechercherCommuneBuilder().build();
    Assert.assertEquals(StringConstants.NOK, _activite.getRetour().getResultat());
    Assert.assertEquals("CAT-3", _activite.getRetour().getCategorie()); //$NON-NLS-1$
    Assert.assertEquals("Parametre d'entree de l'activite non renseignee", _activite.getRetour().getLibelle()); //$NON-NLS-1$
  }

  /**
   * builder incorrect
   *
   * @throws RavelException
   *           RavelException
   */
  @Test
  public void test002() throws RavelException
  {

    _activite = new RES2104_RechercherCommuneBuilder().codePostal("51100").build(); //$NON-NLS-1$
    Assert.assertEquals(StringConstants.NOK, _activite.getRetour().getResultat());
    Assert.assertEquals("CAT-3", _activite.getRetour().getCategorie()); //$NON-NLS-1$
    Assert.assertEquals("Parametre d'entree de l'activite non renseignee", _activite.getRetour().getLibelle()); //$NON-NLS-1$
  }

  /**
   * builder incorrect
   *
   * @throws RavelException
   *           RavelException
   */
  @Test
  public void test003() throws RavelException
  {

    _activite = new RES2104_RechercherCommuneBuilder().codePostal("51100").nomCommune("Reims").build(); //$NON-NLS-1$ //$NON-NLS-2$
    Assert.assertEquals(StringConstants.NOK, _activite.getRetour().getResultat());
    Assert.assertEquals("CAT-3", _activite.getRetour().getCategorie()); //$NON-NLS-1$
    Assert.assertEquals("Parametre d'entree de l'activite non renseignee", _activite.getRetour().getLibelle()); //$NON-NLS-1$
  }

  /**
   * builder incorrect
   *
   * @throws RavelException
   *           RavelException
   */
  @Test
  public void test004() throws RavelException
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    _activite = new RES2104_RechercherCommuneBuilder().tracabilite(tracabilite).nomCommune("Reims").build(); //$NON-NLS-1$
    Assert.assertEquals(StringConstants.NOK, _activite.getRetour().getResultat());
    Assert.assertEquals("CAT-3", _activite.getRetour().getCategorie()); //$NON-NLS-1$
    Assert.assertEquals("Parametre d'entree de l'activite non renseignee", _activite.getRetour().getLibelle()); //$NON-NLS-1$
  }

  /**
   * builder incorrect
   *
   * @throws RavelException
   *           RavelException
   */
  @Test
  public void test005() throws RavelException
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    _activite = new RES2104_RechercherCommuneBuilder().tracabilite(tracabilite).build();
    Assert.assertEquals(StringConstants.NOK, _activite.getRetour().getResultat());
    Assert.assertEquals("CAT-3", _activite.getRetour().getCategorie()); //$NON-NLS-1$
    Assert.assertEquals("Parametre d'entree de l'activite non renseignee", _activite.getRetour().getLibelle()); //$NON-NLS-1$
  }

  /**
   * OK
   *
   * @throws RavelException
   *           RavelException
   */
  @Test
  public void test006() throws RavelException
  {
    String json = "{\r\n\t\"retour\": {\r\n\t\t\"resultat\": \"OK\"\r\n\t},\r\n\t\"listeCommune\": [\r\n\t\t{ \t\"codeInsee\": \"10899\",\r\n\t\t\t\"nomCommune\": \"MaCommune1\",\r\n\t\t\t\"ancienCodeInsee\": \"10888\",\r\n\t\t\t\"listeCodePostal\": [\r\n\t\t\t\t\"59188\",\r\n\t\t\t\t\"59189\"\r\n\t\t\t],\r\n\t\t\t\"listeNomAlternatif\": [\r\n\t\t\t\t{\"provenance\": \"SNA\", \"nomCommune\": \"MaCom1\"},\r\n\t\t\t\t{\"provenance\": \"42R4\", \"nomCommune\": \"UneCommune\"}\r\n\t\t\t]\r\n\t\t},\r\n\t\t{ \t\"codeInsee\": \"10899\",\r\n\t\t\t\"nomCommune\": \"MaCommune2\",\r\n\t\t\t\"ancienCodeInsee\": \"10888\",\r\n\t\t\t\"listeCodePostal\": [\r\n\t\t\t\t\"59187\"\r\n\t\t\t]\r\n\t\t}\r\n\t]\r\n}\r\n"; //$NON-NLS-1$
    ListeCommuneResponse listeCommune = GsonTools.getInstance().fromJson(json, ListeCommuneResponse.class);
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    Retour expectedRetour = RetourFactory.createOkRetour();
    ConnectorResponse<Retour, ListeCommuneResponse> expectedResponse = new ConnectorResponse<Retour, ListeCommuneResponse>(expectedRetour, listeCommune);
    _activite = new RES2104_RechercherCommuneBuilder().tracabilite(tracabilite).codePostal("59188").nomCommune("MaCommune1").build(); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxy);
    EasyMock.expect(_resProxy.pad3001CommuneReadCodePostal(tracabilite, "59188")).andReturn(expectedResponse); //$NON-NLS-1$
    PowerMock.replayAll();
    Commune result = _activite.execute(_activityCallerMock);

    Assert.assertEquals(expectedRetour, _activite.getRetour());
    Assert.assertEquals("MaCommune1", result.getNomCommune()); //$NON-NLS-1$

  }

  /**
   * KO Commune Inconnu
   *
   * @throws RavelException
   *           RavelException
   */
  @Test
  public void test007() throws RavelException
  {
    String json = "{\r\n\t\"retour\": {\r\n\t\t\"resultat\": \"OK\"\r\n\t},\r\n\t\"listeCommune\": [\r\n\t\t{ \t\"codeInsee\": \"10899\",\r\n\t\t\t\"nomCommune\": \"MaCommune1\",\r\n\t\t\t\"ancienCodeInsee\": \"10888\",\r\n\t\t\t\"listeCodePostal\": [\r\n\t\t\t\t\"59188\",\r\n\t\t\t\t\"59189\"\r\n\t\t\t],\r\n\t\t\t\"listeNomAlternatif\": [\r\n\t\t\t\t{\"provenance\": \"SNA\", \"nomCommune\": \"MaCom1\"},\r\n\t\t\t\t{\"provenance\": \"42R4\", \"nomCommune\": \"UneCommune\"}\r\n\t\t\t]\r\n\t\t},\r\n\t\t{ \t\"codeInsee\": \"10899\",\r\n\t\t\t\"nomCommune\": \"MaCommune2\",\r\n\t\t\t\"ancienCodeInsee\": \"10888\",\r\n\t\t\t\"listeCodePostal\": [\r\n\t\t\t\t\"59187\"\r\n\t\t\t]\r\n\t\t}\r\n\t]\r\n}\r\n"; //$NON-NLS-1$
    ListeCommuneResponse listeCommune = GsonTools.getInstance().fromJson(json, ListeCommuneResponse.class);
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    Retour expectedRetourRequest = RetourFactory.createOkRetour();
    Retour expectedRetour = RetourFactory.createNOK("CAT-4", "NOM_COMMUNE_INCONNU", "Nom de commune MaCommune3 inconnu pour ce code postal"); //$NON-NLS-1$//$NON-NLS-2$ //$NON-NLS-3$
    ConnectorResponse<Retour, ListeCommuneResponse> expectedResponse = new ConnectorResponse<Retour, ListeCommuneResponse>(expectedRetourRequest, listeCommune);
    _activite = new RES2104_RechercherCommuneBuilder().tracabilite(tracabilite).codePostal("59188").nomCommune("MaCommune3").build(); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxy);
    EasyMock.expect(_resProxy.pad3001CommuneReadCodePostal(tracabilite, "59188")).andReturn(expectedResponse); //$NON-NLS-1$
    PowerMock.replayAll();
    Commune result = _activite.execute(_activityCallerMock);

    Assert.assertEquals(expectedRetour, _activite.getRetour());
    Assert.assertNull(result);

  }

  /**
   * Nominal nom alternatifs
   *
   * @throws RavelException
   *           RavelException
   */
  @Test
  public void test008() throws RavelException
  {
    String json = "{\r\n\t\"retour\": {\r\n\t\t\"resultat\": \"OK\"\r\n\t},\r\n\t\"listeCommune\": [\r\n\t\t{ \t\"codeInsee\": \"10899\",\r\n\t\t\t\"nomCommune\": \"MaCommune1\",\r\n\t\t\t\"ancienCodeInsee\": \"10888\",\r\n\t\t\t\"listeCodePostal\": [\r\n\t\t\t\t\"59188\",\r\n\t\t\t\t\"59189\"\r\n\t\t\t],\r\n\t\t\t\"listeNomAlternatif\": [\r\n\t\t\t\t{\"provenance\": \"SNA\", \"nomCommune\": \"MaCommune3\"},\r\n\t\t\t\t{\"provenance\": \"42R4\", \"nomCommune\": \"UneCommune\"}\r\n\t\t\t]\r\n\t\t},\r\n\t\t{ \t\"codeInsee\": \"10899\",\r\n\t\t\t\"nomCommune\": \"MaCommune2\",\r\n\t\t\t\"ancienCodeInsee\": \"10888\",\r\n\t\t\t\"listeCodePostal\": [\r\n\t\t\t\t\"59187\"\r\n\t\t\t]\r\n\t\t}\r\n\t]\r\n}\r\n"; //$NON-NLS-1$
    ListeCommuneResponse listeCommune = GsonTools.getInstance().fromJson(json, ListeCommuneResponse.class);
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    Retour expectedRetourRequest = RetourFactory.createOkRetour();
    Retour expectedRetour = RetourFactory.createOkRetour();
    ConnectorResponse<Retour, ListeCommuneResponse> expectedResponse = new ConnectorResponse<Retour, ListeCommuneResponse>(expectedRetourRequest, listeCommune);
    _activite = new RES2104_RechercherCommuneBuilder().tracabilite(tracabilite).codePostal("59188").nomCommune("MaCommune3").build(); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxy);
    EasyMock.expect(_resProxy.pad3001CommuneReadCodePostal(tracabilite, "59188")).andReturn(expectedResponse); //$NON-NLS-1$
    PowerMock.replayAll();
    Commune result = _activite.execute(_activityCallerMock);

    Assert.assertEquals(expectedRetour, _activite.getRetour());
    Assert.assertEquals("MaCommune1", result.getNomCommune()); //$NON-NLS-1$

  }

  /**
   * KO code insee inconnu
   *
   * @throws RavelException
   *           RavelException
   *
   */
  @Test
  public void test009() throws RavelException
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    Retour expectedRetourRequest = RetourFactory.createNOK("CAT-4", "CODE_INSEE_INCONNU", "59188"); //$NON-NLS-1$//$NON-NLS-2$ //$NON-NLS-3$
    Retour expectedRetour = RetourFactory.createNOK("CAT-4", "CODE_POSTAL_INCONNU", "Code postal 59188 inconnu"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    ConnectorResponse<Retour, ListeCommuneResponse> expectedResponse = new ConnectorResponse<Retour, ListeCommuneResponse>(expectedRetourRequest, null);
    _activite = new RES2104_RechercherCommuneBuilder().tracabilite(tracabilite).codePostal("59188").nomCommune("MaCommune3").build(); //$NON-NLS-1$//$NON-NLS-2$
    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxy);
    EasyMock.expect(_resProxy.pad3001CommuneReadCodePostal(tracabilite, "59188")).andReturn(expectedResponse); //$NON-NLS-1$
    PowerMock.replayAll();
    Commune result = _activite.execute(_activityCallerMock);

    Assert.assertEquals(expectedRetour.getResultat(), _activite.getRetour().getResultat());
    Assert.assertEquals(expectedRetour.getDiagnostic(), _activite.getRetour().getDiagnostic());
    Assert.assertNull(result);

  }

  /**
   * Retour 1 seul commune
   *
   * @throws RavelException
   *           RavelException
   */
  @Test
  public void test010() throws RavelException
  {
    String json = "{\r\n\t\"retour\": {\r\n\t\t\"resultat\": \"OK\"\r\n\t},\r\n\t\"listeCommune\": [\r\n\t\t{ \t\"codeInsee\": \"10899\",\r\n\t\t\t\"nomCommune\": \"MaCommune1\",\r\n\t\t\t\"ancienCodeInsee\": \"10888\",\r\n\t\t\t\"listeCodePostal\": [\r\n\t\t\t\t\"59188\",\r\n\t\t\t\t\"59189\"\r\n\t\t\t],\r\n\t\t\t\"listeNomAlternatif\": [\r\n\t\t\t\t{\"provenance\": \"SNA\", \"nomCommune\": \"MaCommune3\"},\r\n\t\t\t\t{\"provenance\": \"42R4\", \"nomCommune\": \"UneCommune\"}\r\n\t\t\t]\r\n\t\t}]\r\n}\r\n"; //$NON-NLS-1$
    ListeCommuneResponse listeCommune = GsonTools.getInstance().fromJson(json, ListeCommuneResponse.class);
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    Retour expectedRetourRequest = RetourFactory.createOkRetour();
    Retour expectedRetour = RetourFactory.createOkRetour();
    ConnectorResponse<Retour, ListeCommuneResponse> expectedResponse = new ConnectorResponse<Retour, ListeCommuneResponse>(expectedRetourRequest, listeCommune);
    _activite = new RES2104_RechercherCommuneBuilder().tracabilite(tracabilite).codePostal("59188").nomCommune("MaCommune3").build(); //$NON-NLS-1$//$NON-NLS-2$
    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxy);
    EasyMock.expect(_resProxy.pad3001CommuneReadCodePostal(tracabilite, "59188")).andReturn(expectedResponse); //$NON-NLS-1$
    PowerMock.replayAll();
    Commune result = _activite.execute(_activityCallerMock);

    Assert.assertEquals(expectedRetour, _activite.getRetour());
    Assert.assertEquals("MaCommune1", result.getNomCommune()); //$NON-NLS-1$

  }

  /**
   * code postal incorrect
   *
   * @throws RavelException
   *           RavelException
   *
   */
  @Test
  public void test011() throws RavelException
  {

    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    Retour expectedRetour = RetourFactory.createNOK("CAT-3", "ENTREE_INCORRECTE", "Code postal 591889 invalide"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    _activite = new RES2104_RechercherCommuneBuilder().tracabilite(tracabilite).codePostal("591889").nomCommune("MaCommune3").build(); //$NON-NLS-1$//$NON-NLS-2$

    _activite.execute(_activityCallerMock);

    Assert.assertEquals(expectedRetour.getResultat(), _activite.getRetour().getResultat());
    Assert.assertEquals(expectedRetour.getDiagnostic(), _activite.getRetour().getDiagnostic());
    Assert.assertEquals(expectedRetour.getCategorie(), _activite.getRetour().getCategorie());

  }

}
