/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.res;

import java.util.List;

import org.easymock.EasyMock;
import org.easymock.EasyMockSupport;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockNice;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.IActivityCaller;
import com.bytel.spirit.common.connectors.res.activities.RES2101_RechercherCommunesParInsee;
import com.bytel.spirit.common.connectors.res.activities.RES2101_RechercherCommunesParInsee.RES2101_RechercherCommunesParInseeBuilder;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.Commune;
import com.bytel.spirit.common.shared.saab.res.response.ListeCommuneResponse;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author dangelis
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({ RESProxy.class })
public class RES2101_RechercherCommunesParInsee_Test extends EasyMockSupport
{
  /**
   * activité testée
   */
  private RES2101_RechercherCommunesParInsee _activite;

  /**
   * Factory de génération des beans
   */
  private PodamFactory _podam = new PodamFactoryImpl();

  /**
   * Mock de {@link RESProxy}
   */
  @MockStrict
  RESProxy _resProxy;

  /**
   * Mock de {@link IActivityCaller}
   */
  @MockNice
  IActivityCaller _activityCallerMock;

  /**
   *
   */
  @Before
  public void beforeTest()
  {

    // désactivation du cache podam
    _podam.getStrategy().setMemoization(false);

    // on réinitialise tous les mocks afin de ne pas avoir d'interférence entre les tests
    PowerMock.resetAll();

    // On initialise toutes les classes à mocker comportant un appel à un eméthode statique
    // Dans notre cas on mock statiquemement toutes les classes des activités et des proxys appelés (pour les createContexte et le getInstance)
    PowerMock.mockStaticStrict(RES2101_RechercherCommunesParInsee.class);
    PowerMock.mockStaticStrict(RESProxy.class);
  }

  /**
   * Nominal PRECEDENT
   *
   * @throws RavelException
   *           RavelException
   */
  @Test
  public void test001() throws RavelException
  {
    String codeInsee_p = "12344"; //$NON-NLS-1$
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    Retour expectedRetour = RetourFactory.createOkRetour();
    ListeCommuneResponse listeCommune = _podam.manufacturePojoWithFullData(ListeCommuneResponse.class);
    ConnectorResponse<Retour, ListeCommuneResponse> expectedResponse = new ConnectorResponse<Retour, ListeCommuneResponse>(expectedRetour, listeCommune);
    _activite = new RES2101_RechercherCommunesParInseeBuilder().tracabilite(tracabilite).codeInsee(codeInsee_p).typeCodeInsee("PRECEDENT").build(); //$NON-NLS-1$
    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxy);
    EasyMock.expect(_resProxy.pad3001CommuneReadAncienCodeInsee(tracabilite, codeInsee_p)).andReturn(expectedResponse);
    PowerMock.replayAll();
    List<Commune> result = _activite.execute(_activityCallerMock);
    PowerMock.verifyAll();
    Assert.assertEquals(expectedRetour, _activite.getRetour());
    Assert.assertEquals(listeCommune.getListeCommune(), result);
  }

  /**
   * Nominal Courant
   *
   * @throws RavelException
   *           RavelException
   */
  @Test
  public void test002() throws RavelException
  {
    String codeInsee_p = "12344"; //$NON-NLS-1$
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    Retour expectedRetour = RetourFactory.createOkRetour();
    ListeCommuneResponse listeCommune = _podam.manufacturePojoWithFullData(ListeCommuneResponse.class);
    ConnectorResponse<Retour, ListeCommuneResponse> expectedResponse = new ConnectorResponse<Retour, ListeCommuneResponse>(expectedRetour, listeCommune);
    _activite = new RES2101_RechercherCommunesParInseeBuilder().tracabilite(tracabilite).codeInsee(codeInsee_p).typeCodeInsee("COURANT").build(); //$NON-NLS-1$
    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxy);
    EasyMock.expect(_resProxy.pad3001CommuneReadCodeInsee(tracabilite, codeInsee_p)).andReturn(expectedResponse);
    PowerMock.replayAll();
    List<Commune> result = _activite.execute(_activityCallerMock);
    PowerMock.verifyAll();
    Assert.assertEquals(expectedRetour, _activite.getRetour());
    Assert.assertEquals(listeCommune.getListeCommune(), result);
  }

  /**
   * Nominal typeCodeInsee inconnu
   *
   * @throws RavelException
   *           RavelException
   */
  @Test
  public void test003() throws RavelException
  {
    String codeInsee_p = "12344"; //$NON-NLS-1$
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    Retour expectedRetour = RetourFactory.createNOK("CAT-3", "ENTREE_INCORRECTE", "Type de code insee COURANTee inconnu"); //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$
    _activite = new RES2101_RechercherCommunesParInseeBuilder().tracabilite(tracabilite).codeInsee(codeInsee_p).typeCodeInsee("COURANTee").build(); //$NON-NLS-1$

    List<Commune> result = _activite.execute(_activityCallerMock);
    Assert.assertEquals(expectedRetour, _activite.getRetour());
    Assert.assertNull(result);
  }

  /**
   * code_insee inconnu COURANT
   *
   * @throws RavelException
   *           RavelException
   */
  @Test
  public void test004() throws RavelException
  {
    String codeInsee_p = "12344"; //$NON-NLS-1$
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    Retour expectedRetour = RetourFactory.createNOK("CAT-4", "CODE_INSEE_INCONNU", "Code insee 12344 inconnu"); //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$
    ConnectorResponse<Retour, ListeCommuneResponse> expectedResponse = new ConnectorResponse<Retour, ListeCommuneResponse>(expectedRetour, null);
    _activite = new RES2101_RechercherCommunesParInseeBuilder().tracabilite(tracabilite).codeInsee(codeInsee_p).typeCodeInsee("COURANT").build(); //$NON-NLS-1$
    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxy);
    EasyMock.expect(_resProxy.pad3001CommuneReadCodeInsee(tracabilite, codeInsee_p)).andReturn(expectedResponse);
    PowerMock.replayAll();

    List<Commune> result = _activite.execute(_activityCallerMock);
    PowerMock.verifyAll();
    Assert.assertEquals(expectedRetour, _activite.getRetour());
    Assert.assertNull(result);
  }

  /**
   * code_insee inconnu PRECEDENT
   *
   * @throws RavelException
   *           RavelException
   */
  @Test
  public void test005() throws RavelException
  {
    String codeInsee_p = "12344"; //$NON-NLS-1$
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    Retour expectedRetour = RetourFactory.createNOK("CAT-4", "CODE_INSEE_INCONNU", "Code insee 12344 inconnu"); //$NON-NLS-1$//$NON-NLS-2$ //$NON-NLS-3$
    ConnectorResponse<Retour, ListeCommuneResponse> expectedResponse = new ConnectorResponse<Retour, ListeCommuneResponse>(expectedRetour, null);
    _activite = new RES2101_RechercherCommunesParInseeBuilder().tracabilite(tracabilite).codeInsee(codeInsee_p).typeCodeInsee("PRECEDENT").build(); //$NON-NLS-1$
    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxy);
    EasyMock.expect(_resProxy.pad3001CommuneReadAncienCodeInsee(tracabilite, codeInsee_p)).andReturn(expectedResponse);
    PowerMock.replayAll();

    List<Commune> result = _activite.execute(_activityCallerMock);
    PowerMock.verifyAll();
    Assert.assertEquals(expectedRetour, _activite.getRetour());
    Assert.assertNull(result);
  }

  /**
   * builder incorrect
   *
   * @throws RavelException
   *           RavelException
   */
  @Test
  public void test006() throws RavelException
  {

    _activite = new RES2101_RechercherCommunesParInseeBuilder().build();
    Assert.assertEquals(StringConstants.NOK, _activite.getRetour().getResultat());
    Assert.assertEquals("CAT-3", _activite.getRetour().getCategorie()); //$NON-NLS-1$
    Assert.assertEquals("Parametre d'entree de l'activite non renseignee", _activite.getRetour().getLibelle()); //$NON-NLS-1$
  }
}
