/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.res;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.text.MessageFormat;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.Month;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.cxf.jaxrs.impl.ResponseBuilderImpl;
import org.easymock.Capture;
import org.easymock.EasyMock;
import org.easymock.EasyMockSupport;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.modules.junit4.PowerMockRunner;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.conf.generated.LoadBalancer;
import com.bytel.ravel.common.conf.generated.Param;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.json.IRavelJson;
import com.bytel.ravel.common.json.IRavelJsonAdapter;
import com.bytel.ravel.common.json.RavelJson.RavelJsonBuilder;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.test.JUnitTools;
import com.bytel.ravel.common.test.podam.JavaTimeManufacturer;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.RetourFactoryForTU;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.net.loadbalancing.ILoadBalancer;
import com.bytel.ravel.net.loadbalancing.URLBalancedElement;
import com.bytel.ravel.net.rest.RestConnectorPool;
import com.bytel.ravel.net.rest.RestInstance;
import com.bytel.ravel.services.conf.connector.generated.Connector;
import com.bytel.ravel.services.conf.connector.generated.URL;
import com.bytel.ravel.services.conf.connector.generated.URLS;
import com.bytel.ravel.services.connector.AbstractRESTConnector;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.connectors.res.services.NoeudRaccordementService;
import com.bytel.spirit.common.connectors.res.services.RessourcePortPmService;
import com.bytel.spirit.common.connectors.res.services.RessourceRaccordementService;
import com.bytel.spirit.common.connectors.res.services.RessourceService;
import com.bytel.spirit.common.connectors.res.services.TopologieArcturusService;
import com.bytel.spirit.common.shared.functional.types.json.RavelJsonTools;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.BasicResponse;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.ressources.RetourConverter;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.AccesTechnique;
import com.bytel.spirit.common.shared.saab.res.CacheElig;
import com.bytel.spirit.common.shared.saab.res.CompteRenduSuppression;
import com.bytel.spirit.common.shared.saab.res.CoupleImbOi;
import com.bytel.spirit.common.shared.saab.res.CouvertureCuivre;
import com.bytel.spirit.common.shared.saab.res.CouvertureFtto;
import com.bytel.spirit.common.shared.saab.res.CouvertureTokyo;
import com.bytel.spirit.common.shared.saab.res.DispoNroFtteOrg;
import com.bytel.spirit.common.shared.saab.res.FichierOrigine;
import com.bytel.spirit.common.shared.saab.res.FichierReferentielComposite;
import com.bytel.spirit.common.shared.saab.res.Fqdn;
import com.bytel.spirit.common.shared.saab.res.Olt;
import com.bytel.spirit.common.shared.saab.res.Ressource;
import com.bytel.spirit.common.shared.saab.res.RessourceAdresseIpClf;
import com.bytel.spirit.common.shared.saab.res.RessourceAggrege;
import com.bytel.spirit.common.shared.saab.res.RessourceAggregeP2P;
import com.bytel.spirit.common.shared.saab.res.RessourceCompteIms;
import com.bytel.spirit.common.shared.saab.res.RessourceCompteMail;
import com.bytel.spirit.common.shared.saab.res.RessourceImpiFixe;
import com.bytel.spirit.common.shared.saab.res.RessourceMotDePasseIms;
import com.bytel.spirit.common.shared.saab.res.RessourcePortPM;
import com.bytel.spirit.common.shared.saab.res.RessourceRaccordementComposite;
import com.bytel.spirit.common.shared.saab.res.RessourceRaccordementP2P;
import com.bytel.spirit.common.shared.saab.res.SVImmeubleFtth;
import com.bytel.spirit.common.shared.saab.res.StructureVerticaleFtthComposite;
import com.bytel.spirit.common.shared.saab.res.TopologieArcturus;
import com.bytel.spirit.common.shared.saab.res.request.IntegrationGroupeFichierRequest;
import com.bytel.spirit.common.shared.saab.res.request.ListeCacheEligRequest;
import com.bytel.spirit.common.shared.saab.res.request.ListeCommuneRequest;
import com.bytel.spirit.common.shared.saab.res.request.ListeCoupleImbOiRequest;
import com.bytel.spirit.common.shared.saab.res.request.ListeNomOLTRequest;
import com.bytel.spirit.common.shared.saab.res.request.ListePrevisionRequest;
import com.bytel.spirit.common.shared.saab.res.request.ManageNoeudRaccordementRequest;
import com.bytel.spirit.common.shared.saab.res.response.CreateCacheEligResponse;
import com.bytel.spirit.common.shared.saab.res.response.GetAccesTechniqueResponse;
import com.bytel.spirit.common.shared.saab.res.response.GetCacheEligResponse;
import com.bytel.spirit.common.shared.saab.res.response.GetCouvertureCuivreResponse;
import com.bytel.spirit.common.shared.saab.res.response.GetCouvertureFtthResponse;
import com.bytel.spirit.common.shared.saab.res.response.GetCouvertureFttoResponse;
import com.bytel.spirit.common.shared.saab.res.response.GetCouvertureTokyoResponse;
import com.bytel.spirit.common.shared.saab.res.response.GetDispoNroFtteOrgResponse;
import com.bytel.spirit.common.shared.saab.res.response.GetFichierReferentielCompositeResponse;
import com.bytel.spirit.common.shared.saab.res.response.GetListeFqdnResponse;
import com.bytel.spirit.common.shared.saab.res.response.GetListeOltResponse;
import com.bytel.spirit.common.shared.saab.res.response.GetRessourceAggrege;
import com.bytel.spirit.common.shared.saab.res.response.GetRessourceRaccordementCompositeResponse;
import com.bytel.spirit.common.shared.saab.res.response.GetRessourceRaccordementResponse;
import com.bytel.spirit.common.shared.saab.res.response.GetRessourceResponse;
import com.bytel.spirit.common.shared.saab.res.response.GetStructureVerticaleFtthCompositeResponse;
import com.bytel.spirit.common.shared.saab.res.response.GetTopologieArcturusResponse;
import com.bytel.spirit.common.shared.saab.res.response.IntegrationGroupeFichierResponse;
import com.bytel.spirit.common.shared.saab.res.response.ListeCommuneResponse;
import com.bytel.spirit.common.shared.saab.res.response.ListePrevisionResponse;
import com.bytel.spirit.common.shared.saab.res.response.NoeudRaccordementResponse;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author dangelis
 * @version ($Revision$ $Date$)
 */

@RunWith(PowerMockRunner.class)
public class RESConnectorTest extends EasyMockSupport
{
  /**
   * Param name for PAD3001
   */
  private static final String PAD3001_PATH_PARAM = "/commune/"; //$NON-NLS-1$

  /**
   * Param name for PAD3002
   */
  private static final String PAD3002_PATH_PARAM = "/previsionProgramme/"; //$NON-NLS-1$

  /**
   * Param name for PAD3003
   */
  private static final String PAD3003_PATH_PARAM = "/integrationGroupFichier/"; //$NON-NLS-1$

  /**
   * Param name for PAD3004
   */
  private static final String PAD3004_PATH_PARAM = "/accesTechnique/"; //$NON-NLS-1$

  /**
   * Param name for PAD3005
   */
  private static final String PAD3005_PATH_PARAM = "/gestionReferentiel/"; //$NON-NLS-1$

  /**
   * Param name for PAD3006
   */
  private static final String PAD3006_PATH_PARAM = "/fichierReferentielComposite/"; //$NON-NLS-1$

  /**
   * Param name for PAD3007
   */
  private static final String PAD3007_PATH_PARAM = "/couvertureCuivre/"; //$NON-NLS-1$

  /**
   * Param name for PAD3008
   */
  private static final String PAD3008_PATH_PARAM = "/couvertureFtto/"; //$NON-NLS-1$

  /**
   * Param name for PAD3009
   */
  private static final String PAD3009_PATH_PARAM = "/couvertureTokyo/"; //$NON-NLS-1$

  /**
   * Param name for PAD3010
   */
  private static final String PAD3013_PATH_PARAM = "/topologieArcturus/"; //$NON-NLS-1$

  /**
   * Param name for PAD3011
   */
  private static final String PAD3011_PATH_PARAM = "/ressourceFtth/"; //$NON-NLS-1$

  /**
   * Param name for PAD3012
   */
  private static final String PAD3012_PATH_PARAM = "/structureVerticaleFtthComposite/"; //$NON-NLS-1$

  /**
   * Param name for PAD3012 Recherche
   */
  private static final String PAD3012_RECHERCHE_PATH_PARAM = "/structureVerticaleFtthComposite/recherche"; //$NON-NLS-1$

  /**
   * Param name for PAD3202
   */
  private static final String PAD3202_PATH_PARAM = "/fqdn/"; //$NON-NLS-1$

  /**
   * Param name for PAD3100
   */
  private static final String PAD3100_PATH_PARAM = "/ressource/"; //$NON-NLS-1$

  /**
   * Param name for PAD3101
   */
  private static final String PAD3101_PATH_PARAM = "/ressourceReseauComposite/"; //$NON-NLS-1$

  /**
   * Param name for PAD3110
   */
  private static final String PAD3110_PATH_PARAM = "/ressourcePortPm/"; //$NON-NLS-1$

  /**
   * Param name for PAD3127
   */
  private static final String PAD3127_PATH_PARAM = "/ressourceRaccordement/"; //$NON-NLS-1$

  /**
   * Param name for PAD3111
   */
  private static final String PAD3111_PATH_PARAM = "/ressourceRaccordementComposite/"; //$NON-NLS-1$

  /**
   * Param name for PAD3111 (manage)
   */
  private static final String PAD3111_MANAGE_PATH_PARAM = "/manageRessourceRaccordementComposite/"; //$NON-NLS-1$

  /**
   * Param name for PAD3200
   */
  private static final String PAD3203_PATH_PARAM = "/olt/"; //$NON-NLS-1$

  /**
   * Param name for PAD3123
   */
  private static final String PAD_RAIC_PATH_PARAM = "/ressourceAdresseIpClf/"; //$NON-NLS-1$
  /**
   * Param name for PAD3122
   */
  private static final String PAD_RIF_PATH_PARAM = "/ressourceImpiFixe/"; //$NON-NLS-1$
  /**
   * Param name for PAD3121
   */
  private static final String PAD_RCI_PATH_PARAM = "/ressourceCompteIms/"; //$NON-NLS-1$
  /**
   * Param name for PAD3125
   */
  private static final String PAD_RM2PI_PATH_PARAM = "/ressourceMotDePasseIms/"; //$NON-NLS-1$
  /**
   * Param name for PAD3126
   */
  private static final String PAD_ROI_PATH_PARAM = "/ressourceOntId/"; //$NON-NLS-1$

  /**
   * Param name for PAD3120
   */
  private static final String PAD3120_PATH_PARAM = "/ressourceCompteMail/"; //$NON-NLS-1$

  /**
   * Param name for PAD3124
   */
  private static final String PAD3124_PATH_PARAM = "/ressourcePortP2P/"; //$NON-NLS-1$

  /**
   *
   */
  private static final String PAD3204_PATH_PARAM = "/noeudRaccordement"; //$NON-NLS-1$

  /**
   *
   */
  private static final String PAD3205_PATH_PARAM = "/pmComposite"; //$NON-NLS-1$

  /**
   * Param name for PAD3300
   */
  private static final String PAD3300_PATH_PARAM = "/cacheElig/"; //$NON-NLS-1$

  /**
   * Param name for PAD3014
   */
  private static final String PAD3014_PATH_PARAM = "/dispoNroFtteOrg/"; //$NON-NLS-1$

  /**
   * Param name for CREATE_LONG_TIMEOUT
   */
  private static final String CREATE_LONG_TIMEOUT_PARAM = "36000000"; //$NON-NLS-1$

  /**
   * Action
   */
  private static final String PARAM_ACTION = "action"; //$NON-NLS-1$

  /**
   * nomNR
   */
  private static final String PARAM_NOMNR = "nomNR"; //$NON-NLS-1$

  /**
   * Distance
   */
  private static final String PARAM_DISTANCE = "distance"; //$NON-NLS-1$

  /**
   * Code INSEE
   */
  private static final String PARAM_CODE_INSEE = "codeInsee"; //$NON-NLS-1$

  /**
   * idAdresseBytel
   */
  private static final String PARAM_ID_ADRESSE_BYTEL = "idAdresseBytel"; //$NON-NLS-1$

  /**
   *
   */
  private static final String PARAM_ID_RESSOURCE = "idRessource"; //$NON-NLS-1$

  /**
   *
   */
  private static final String PARAM_ID_RESSOURCELIE = "idRessourceLie"; //$NON-NLS-1$

  /**
   *
   */
  private static final String PARAM_ID_RR_CIBLE = "idRRCible"; //$NON-NLS-1$

  /**
   *
   */
  private static final String PARAM_ID_SOURCE = "idSource"; //$NON-NLS-1$

  /**
   *
   */
  private static final String PARAM_ID_ST = "idSt"; //$NON-NLS-1$

  /**
  *
  */
  private static final String DATE_DERNIERE_DECLARATION_ONT_INSTALLE = "dateDerniereDeclarationOntInstalle"; //$NON-NLS-1$

  /**
  *
  */
  private static final String NO_SERIE_ONT_INSTALLE = " noSerieOntInstalle"; //$NON-NLS-1$

  /**
  *
  */
  private static final String TYPE_TECHNOLOGIE_PON = "typeTechnologiePon"; //$NON-NLS-1$

  /**
   * numeroComplement
   */
  private static final String PARAM_NUMERO_COMPLEMENT = "numeroComplement"; //$NON-NLS-1$

  /**
   * rivoli
   */
  private static final String PARAM_RIVOLI = "codeRivoli"; //$NON-NLS-1$

  /**
   *
   */
  private static final String PARAM_STATUT = "statut"; //$NON-NLS-1$

  /**
   *
   */
  private static final String PARAM_TYPE_RESSOURCE = "typeRessource"; //$NON-NLS-1$

  /**
   * typeReferentiel
   */
  private static final String PARAM_TYPE_REFERENTIEL = "typeReferentiel"; //$NON-NLS-1$

  /**
   * PARAM_TYPE_RESSOURCE_AGGREGE
   */
  private static final String PARAM_TYPE_RESSOURCE_AGGREGE = "typeRessourceAggrege"; //$NON-NLS-1$

  /**
   * nomFqdn
   */
  private static final String PARAM_NOM_FQDN = "nomFQDN"; //$NON-NLS-1$

  /**
   * Nombre de session
   */
  private static final String PARAM_NOMBRE_SESSION = "nombreSession"; //$NON-NLS-1$

  /**
   * Opération
   */
  private static final String PARAM_OPERATION = "operation"; //$NON-NLS-1$

  /**
   * idNomCollecte
   */
  private static final String PARAM_ID_NOM_COLLECTE = "idNomCollecte"; //$NON-NLS-1$
  /**
   * IdEqptAcces
   */
  private static final String PARAM_ID_EQPT_ACCES = "idEqptAcces"; //$NON-NLS-1$

  /**
   * Impossible de récupérer la réponse constant
   */
  public static final String JSON_ERROR_MESSAGE = Messages.getString("RESConnector.JsonErrorMessage"); //$NON-NLS-1$

  /**
   * Action
   */
  private static final String ACTION = "action"; //$NON-NLS-1$

  /**
   * Check the query params in rest send request method
   *
   * @param queryParams
   *          the actual query params
   * @param expected_p
   *          list of expected query params strings key1 value1 key2 value2...keyN valueN
   */
  public static void checkQueryParams(Capture<Map<String, String>> queryParams, String... expected_p)
  {
    if (expected_p == null)
    {
      Assert.assertNull(queryParams.getValue());
    }
    else
    {
      Assert.assertEquals(0, expected_p.length % 2);
      for (int i = 0; i < expected_p.length; i = i + 2)
      {
        Assert.assertEquals(expected_p[i + 1], queryParams.getValue().get(expected_p[i]));
      }
    }
  }

  /**
   * Génération du LoadBalancer minimal pour passer {@link AbstractRESTConnector#loadConnectorConfiguration(Connector)}
   *
   * @return {@link LoadBalancer}
   */
  public static LoadBalancer generateLoadBalancer()
  {
    final LoadBalancer loadBalancer = new LoadBalancer();
    Param timer = new Param();
    timer.setName("TIMER"); //$NON-NLS-1$
    timer.setValue("30"); //$NON-NLS-1$
    loadBalancer.getParam().add(timer);
    loadBalancer.setType("RoundRobin"); //$NON-NLS-1$
    return loadBalancer;
  }

  /**
   * Génération du URL minimal pour passer {@link AbstractRESTConnector#loadConnectorConfiguration(Connector)}
   *
   * @return {@link URL}
   */
  public static URL generateURL()
  {
    final URL url = new URL();
    url.setName("urlName"); //$NON-NLS-1$
    url.setAccessPoint("http://localhost:8888"); //$NON-NLS-1$
    Param param = new Param();
    param.setName("PROXY_ENABLED"); //$NON-NLS-1$
    param.setValue(String.valueOf(false));
    url.getParam().add(param);
    param = new Param();
    param.setName("TIMEOUT"); //$NON-NLS-1$
    param.setValue("30"); //$NON-NLS-1$
    url.getParam().add(param);

    return url;
  }

  /**
   * @return URLS
   */
  public static URLS generateURLS()
  {
    final URLS urls = new URLS();
    urls.setLoadBalancer(generateLoadBalancer());
    urls.getURL().add(generateURL());
    return urls;
  }

  /**
   * Connector to test
   */
  private RESConnector _connector;

  /**
   * Factory to generate beans
   */
  private PodamFactory _podam = new PodamFactoryImpl();

  /**
   * Path for PAD3001
   */
  private String _communeUrl;

  /**
   * Path for PAD3002
   */
  private String _previsionProgUrl;

  /**
   * Path for PAD3003
   */
  private String _integrationGroupFileUrl;

  /**
   * Path for PAD3004
   */
  private String _accesTechniqueUrl;

  /**
   * Path for PAD3005 GestionReferentiel
   */
  private String _gestionReferentielUrl;

  /**
   * Path for PAD3006 fichierReferentielComposite
   */
  private String _fichierReferentielCompositeUrl;

  /**
   * Path for PAD3204 noeudRaccordement
   */
  private String _noeudRaccordementUrl;

  /**
   * Path for PAD3205 pmCompositeUrl
   */
  private String _pmCompositeUrl;

  /**
   * Path for PAD3007 couvertureCuivre
   */
  private String _couvertureCuivreUrl;

  /**
   * Path for PAD3008 couvertureFtto
   */
  private String _couvertureFttoUrl;

  /**
   * Path for PAD3009 couvertureTokyo
   */
  private String _couvertureTokyoUrl;

  /**
   * Path for PAD3013 topologieArcturus
   */
  private String _topologieArcturus;

  /**
   * Path for PAD3011 ressourceFtth
   */
  private String _ressourceFtthUrl;

  /**
   * Path for PAD3012 structureVerticaleFtthComposite
   */
  private String _structureVerticaleFtthCompositeUrl;

  /**
   * Path for PAD3012 structureVerticaleFtthCompositeRecherche
   */
  private String _structureVerticaleFtthCompositeRechercheUrl;

  /**
   * Path for PAD3100
   */
  private String _ressourceUrl;

  /**
   * Path for PAD3101
   */
  private String _ressourceReseauCompositeUrl;

  /**
   * Path for PAD3110
   */
  private String _ressourceRaccordementUrl;

  /**
   * Path for PAD3127
   */
  private String _ressourcePortPmUrl;

  /**
   * Path for PAD3111
   */
  private String _ressourceRaccordementCompositeUrl;

  /**
   * Path for PAD3111 manage
   */
  private String _manageRessourceRaccordementCompositeUrl;

  /** Path for PAD???? */
  private String _ressourceAdresseIpClfUrl;

  /** Path for PAD???? */
  private String _allocationSessionFqdnUrl;

  /** Path for PAD???? */
  private String _ressourceImpiFixeUrl;

  /** Path for PAD???? */
  private String _ressourceCompteImsUrl;

  /**
   * Path for PAD3120
   */
  private String _ressourceCompteMailUrl;

  /** Path for PAD???? */
  private String _ressourceMotDePasseImsUrl;

  /** Path for PAD???? */
  private String _ressourceOntIdUrl;

  /**
   * Path for PAD3124
   */
  private String _ressourcePortP2PUrl;

  /** Path for PAD3300 */
  private String _cacheEligUrl;

  /** Path for PAD3014 */
  private String _dispoNroFtteOrgUrl;

  /**
   * Path for PAD3202 fqdn
   */
  private String _fqdnUrl;

  /**
   * Path for PAD3203 fqdn
   */
  private String _oltUrl;

  /**
   * Timeout value
   */
  private Integer _createLongTimeout;

  /**
   * cache duration
   */
  private Duration _accesTechniqueCacheDuration;

  /** cache duration */
  private Duration _abaqueDslCacheDuration;

  private Tracabilite _tracabilite;

  /**
   * Mock {@link ILoadBalancer}
   */
  @MockStrict
  ILoadBalancer<URLBalancedElement> _loadBalancerMock;

  /**
   * Mock {@link URLBalancedElement}
   */
  @MockStrict
  URLBalancedElement _urlBalancedElementMock;

  /**
   * Mock of connectors pool HTTP
   */
  @MockStrict
  Hashtable<String, RestConnectorPool> _connectorPoolMock;

  /**
   * Mock {@link RestConnectorPool}
   */
  @MockStrict
  RestConnectorPool _restConnectorPoolMock;

  /**
   * Mock {@link RestInstance}
   */
  @MockStrict
  RestInstance _restInstanceMock;

  /**
   * Mock InputStream
   */
  @MockStrict
  InputStream _inputStreamMock;

  /**
   * Mock {@link Response}
   */
  @MockStrict
  Response _responseMock;

  /**
   * Test the method {@link RESConnector#accesTechniqueLireTous(Tracabilite)} httpStatus 200 Retour KO with "lecture
   * indisponible"
   *
   * Expected : Retour KO, CAT-1, LECTURE_INDISPONIBLE, "Unexpected error in res database connector: Test Error"
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void accesTechniqueLireTous_Test_KO_001() throws Exception
  {
    final String message = MessageFormat.format(Messages.getString("res.unexpectedError"), "Test Error"); //$NON-NLS-1$ //$NON-NLS-2$
    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT1, IMegSpiritConsts.LECTURE_INDISPONIBLE, message, null);
    final GetAccesTechniqueResponse getAccesTechniqueResponse = new GetAccesTechniqueResponse(RetourConverter.convertToJsonRetour(retour), null);
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(getAccesTechniqueResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_accesTechniqueUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<AccesTechnique>> result = _connector.loadAccesTechniqueLireTous(_tracabilite);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    Assert.assertEquals(retour, result._first);
    Assert.assertEquals(new ArrayList<>(), result._second);
  }

  /**
   * Test the method {@link RESConnector#accesTechniqueLireTous(Tracabilite)} httpStatus 200 jsonResponse null (throws
   * RavelException)
   *
   * Expected : null JsonResponse - Retour KO, CAT-10, TRAITEMENT_ARRETE, "Impossible de récupérer la réponse"
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void accesTechniqueLireTous_Test_KO_002() throws Exception
  {

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_accesTechniqueUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    // Call connector
    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<AccesTechnique>> result = _connector.loadAccesTechniqueLireTous(_tracabilite);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, JSON_ERROR_MESSAGE, null);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test OK for the method {@link RESConnector#accesTechniqueLireTous(Tracabilite)} httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void accesTechniqueLireTous_Test_OK_001() throws Exception
  {

    final AccesTechnique accesTechnique = _podam.manufacturePojoWithFullData(AccesTechnique.class);
    LocalDateTime creation = LocalDateTime.of(2018, Month.AUGUST, 15, 14, 30, 00, 123000000);
    LocalDateTime modification = LocalDateTime.of(2018, Month.AUGUST, 21, 15, 45, 30, 125000000);
    accesTechnique.setDateCreation(creation);
    accesTechnique.setDateModification(modification);
    final List<AccesTechnique> listAccesTechnique = new ArrayList<>();
    listAccesTechnique.add(accesTechnique);
    final Retour retour = RetourFactoryForTU.createOkRetour();
    final GetAccesTechniqueResponse getAccesTechniqueResponse = new GetAccesTechniqueResponse(RetourConverter.convertToJsonRetour(retour), listAccesTechnique);

    final String partnerResponse = GsonTools.getIso8601Ms().toJson(getAccesTechniqueResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_accesTechniqueUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<AccesTechnique>> result = _connector.loadAccesTechniqueLireTous(_tracabilite);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertEquals(listAccesTechnique, result._second);
  }

  /**
   * Initialize before tests
   *
   * @throws Exception
   *           Thrown in case of error during switch in attributes of parent class
   */
  @Before
  public void beforeTest() throws Exception
  {
    _podam.getStrategy().setMemoization(false);
    _podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());
    JavaTimeManufacturer.registerPodamFactory(_podam);

    _connector = new RESConnector();

    _communeUrl = PAD3001_PATH_PARAM;
    _previsionProgUrl = PAD3002_PATH_PARAM;
    _integrationGroupFileUrl = PAD3003_PATH_PARAM;
    _accesTechniqueUrl = PAD3004_PATH_PARAM;
    _ressourceUrl = PAD3100_PATH_PARAM;
    _gestionReferentielUrl = PAD3005_PATH_PARAM;
    _fichierReferentielCompositeUrl = PAD3006_PATH_PARAM;
    _couvertureCuivreUrl = PAD3007_PATH_PARAM;
    _couvertureFttoUrl = PAD3008_PATH_PARAM;
    _couvertureTokyoUrl = PAD3009_PATH_PARAM;
    _topologieArcturus = PAD3013_PATH_PARAM;
    _ressourceRaccordementUrl = PAD3110_PATH_PARAM;
    _ressourcePortPmUrl = PAD3127_PATH_PARAM;
    _ressourceRaccordementCompositeUrl = PAD3111_PATH_PARAM;
    _ressourceAdresseIpClfUrl = PAD_RAIC_PATH_PARAM;
    _ressourceCompteImsUrl = PAD_RCI_PATH_PARAM;
    _ressourceCompteMailUrl = PAD3120_PATH_PARAM;
    _ressourceImpiFixeUrl = PAD_RIF_PATH_PARAM;
    _ressourceMotDePasseImsUrl = PAD_RM2PI_PATH_PARAM;
    _ressourceOntIdUrl = PAD_ROI_PATH_PARAM;
    _manageRessourceRaccordementCompositeUrl = PAD3111_MANAGE_PATH_PARAM;
    _ressourcePortP2PUrl = PAD3124_PATH_PARAM;
    _ressourceReseauCompositeUrl = PAD3101_PATH_PARAM;
    _createLongTimeout = Integer.parseInt(CREATE_LONG_TIMEOUT_PARAM);
    _fqdnUrl = PAD3202_PATH_PARAM;
    _oltUrl = PAD3203_PATH_PARAM;
    _ressourceFtthUrl = PAD3011_PATH_PARAM;
    _structureVerticaleFtthCompositeUrl = PAD3012_PATH_PARAM;
    _structureVerticaleFtthCompositeRechercheUrl = PAD3012_RECHERCHE_PATH_PARAM;
    _cacheEligUrl = PAD3300_PATH_PARAM;
    _dispoNroFtteOrgUrl = PAD3014_PATH_PARAM;
    _noeudRaccordementUrl = PAD3204_PATH_PARAM;
    _pmCompositeUrl = PAD3205_PATH_PARAM;
    _accesTechniqueCacheDuration = Duration.parse("PT10M"); //$NON-NLS-1$
    _abaqueDslCacheDuration = Duration.parse("PT10M"); //$NON-NLS-1$

    JUnitTools.setInaccessibleFieldValue(_connector, "_loadBalancer", _loadBalancerMock); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_connectorPool", _connectorPoolMock); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_createLongTimeout", 5); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_communeUrl", _communeUrl); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_previsionProgUrl", _previsionProgUrl); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_integrationGroupFileUrl", _integrationGroupFileUrl); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_accesTechniqueUrl", _accesTechniqueUrl); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_gestionReferentielUrl", _gestionReferentielUrl); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_ressourceUrl", _ressourceUrl); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_fichierReferentielCompositeUrl", _fichierReferentielCompositeUrl); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_couvertureCuivreUrl", _couvertureCuivreUrl); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_couvertureFttoUrl", _couvertureFttoUrl); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_couvertureTokyoUrl", _couvertureTokyoUrl); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_ressourceRaccordementUrl", _ressourceRaccordementUrl); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_ressourceRaccordementCompositeUrl", _ressourceRaccordementCompositeUrl); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_manageRessourceRaccordementCompositeUrl", _manageRessourceRaccordementCompositeUrl); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_ressourceAdresseIpClfUrl", _ressourceAdresseIpClfUrl); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_ressourceImpiFixeUrl", _ressourceImpiFixeUrl); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_ressourceCompteImsUrl", _ressourceCompteImsUrl); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_ressourceCompteMailUrl", _ressourceCompteMailUrl); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_ressourceMotDePasseImsUrl", _ressourceMotDePasseImsUrl); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_ressourceOntIdUrl", _ressourceOntIdUrl); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_ressourcePortP2PUrl", _ressourcePortP2PUrl); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_ressourceReseauCompositeUrl", _ressourceReseauCompositeUrl); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_createLongTimeout", _createLongTimeout); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_fqdnUrl", _fqdnUrl); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_oltTousFiltreUrl", _oltUrl); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_topologieArcturusUrl", _topologieArcturus); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_ressourceFtthUrl", _ressourceFtthUrl); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_structureVerticaleFtthCompositeUrl", _structureVerticaleFtthCompositeUrl); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_structureVerticaleFtthCompositeRechercheUrl", _structureVerticaleFtthCompositeRechercheUrl); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_cacheEligUrl", _cacheEligUrl); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_dispoNroFtteOrgUrl", _dispoNroFtteOrgUrl); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_nouedRacordementUrl", _noeudRaccordementUrl); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_pmCompositeUrl", _pmCompositeUrl); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_ressourceService", new RessourceService(_connector)); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_ressourceRaccordementService", new RessourceRaccordementService(_connector)); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_ressourcePortPmService", new RessourcePortPmService(_connector)); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_connector, "_topologieArcturusService", new TopologieArcturusService(_connector)); //$NON-NLS-1$

    PowerMock.resetAll();
    _tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);

  }

  /**
   * Test NOK for the method {@link RESConnector#cacheEligCreerListe(Tracabilite, ListeCacheEligRequest)} with null
   * JsonResponse - Retour KO, CAT-10, TRAITEMENT_ARRETE
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void cacheEligCreerListe_Test_NOK_001() throws Exception
  {

    final CacheElig cacheElig = _podam.manufacturePojo(CacheElig.class);
    ListeCacheEligRequest listeCacheEligRequest = new ListeCacheEligRequest(Arrays.asList(cacheElig));
    final Retour retour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, StringConstants.EMPTY_STRING);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();

    // construct response
    final Response response = null;

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(_cacheEligUrl), EasyMock.capture(headersCapture), EasyMock.anyObject(), EasyMock.isNull())).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Integer> result = _connector.cacheEligCreerListe(_tracabilite, listeCacheEligRequest);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    Assert.assertEquals(retour.getDiagnostic(), result._first.getDiagnostic());
    Assert.assertEquals(retour.getCategorie(), result._first.getCategorie());

    Assert.assertNull(result._second);

  }

  /**
   * Test Exception for the method {@link RESConnector#cacheEligCreerListe(Tracabilite, ListeCacheEligRequest)}
   *
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void cacheEligCreerListe_Test_NOK_002_Exception() throws Exception
  {

    final CacheElig cacheElig = _podam.manufacturePojo(CacheElig.class);
    ListeCacheEligRequest listeCacheEligRequest = new ListeCacheEligRequest(Arrays.asList(cacheElig));

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();

    // construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream("".getBytes())).build(); //$NON-NLS-1$

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(_cacheEligUrl), EasyMock.capture(headersCapture), EasyMock.anyObject(), EasyMock.isNull())).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    try
    {
      _connector.cacheEligCreerListe(_tracabilite, listeCacheEligRequest);
    }
    catch (RavelException e)
    {
      Assert.assertEquals(ExceptionType.UNEXPECTED, e.getExceptionType());
      Assert.assertEquals(ErrorCode.CNCTOR_00010, e.getErrorCode());
      Assert.assertEquals("Impossible de récupérer la réponse", e.getMessage()); //$NON-NLS-1$
    }

  }

  /**
   * Test OK for the method {@link RESConnector#cacheEligCreerListe(Tracabilite, ListeCacheEligRequest)} with httpStatus
   * 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void cacheEligCreerListe_Test_OK_001() throws Exception
  {

    final CacheElig cacheElig = _podam.manufacturePojo(CacheElig.class);
    ListeCacheEligRequest listeCacheEligRequest = new ListeCacheEligRequest(Arrays.asList(cacheElig));
    final Retour retour = RetourFactoryForTU.createOkRetour();
    final CreateCacheEligResponse Response = new CreateCacheEligResponse(RetourConverter.convertToJsonRetour(retour), 0);
    final String partnerResponse = RavelJsonTools.getInstance().toJson(Response, CreateCacheEligResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();

    // construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(_cacheEligUrl), EasyMock.capture(headersCapture), EasyMock.anyObject(), EasyMock.isNull())).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Integer> result = _connector.cacheEligCreerListe(_tracabilite, listeCacheEligRequest);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    Assert.assertEquals(retour, result._first);
    Assert.assertEquals((Integer) 0, result._second);
  }

  /**
   * Test NOK for the method {@link RESConnector#cacheEligLire(Tracabilite, String, String, String, String)} with null
   * JsonResponse - Retour KO, CAT-10, TRAITEMENT_ARRETE
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void cacheEligLire_Test_NOK_001() throws Exception
  {
    final String idCleCompose = RandomStringUtils.random(5);
    final String typeCle = RandomStringUtils.random(5);
    final String techno = RandomStringUtils.random(5);
    final String operateur = RandomStringUtils.random(5);

    final Retour retour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, StringConstants.EMPTY_STRING);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    // construct response
    final Response response = null;

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(PAD3300_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, CacheElig> result = _connector.cacheEligLire(_tracabilite, idCleCompose, typeCle, techno, operateur);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    Assert.assertEquals(retour.getDiagnostic(), result._first.getDiagnostic());
    Assert.assertEquals(retour.getCategorie(), result._first.getCategorie());

    Assert.assertNull(result._second);
  }

  /**
   * Test Exception for the method {@link RESConnector#cacheEligLire(Tracabilite, String, String, String, String)}
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void cacheEligLire_Test_NOK_002_Exception() throws Exception
  {
    final String idCleCompose = RandomStringUtils.random(5);
    final String typeCle = RandomStringUtils.random(5);
    final String techno = RandomStringUtils.random(5);
    final String operateur = RandomStringUtils.random(5);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    // construct response
    final Response response = null;

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(PAD3300_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    try
    {
      _connector.cacheEligLire(_tracabilite, idCleCompose, typeCle, techno, operateur);
    }
    catch (RavelException e)
    {
      Assert.assertEquals(ExceptionType.UNEXPECTED, e.getExceptionType());
      Assert.assertEquals(ErrorCode.CNCTOR_00010, e.getErrorCode());
      Assert.assertEquals("Impossible de récupérer la réponse", e.getMessage()); //$NON-NLS-1$
    }
  }

  /**
   * Test OK for the method {@link RESConnector#cacheEligLire(Tracabilite, String, String, String, String)} with
   * httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void cacheEligLire_Test_OK_001() throws Exception
  {
    final String idCleCompose = RandomStringUtils.random(5);
    final String typeCle = RandomStringUtils.random(5);
    final String techno = RandomStringUtils.random(5);
    final String operateur = RandomStringUtils.random(5);

    final CacheElig cacheElig = _podam.manufacturePojo(CacheElig.class);
    final Retour retour = RetourFactoryForTU.createOkRetour();
    final GetCacheEligResponse Response = new GetCacheEligResponse(RetourConverter.convertToJsonRetour(retour), cacheElig);
    final String partnerResponse = RavelJsonTools.getInstance().toJson(Response, GetCacheEligResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    // construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(PAD3300_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, CacheElig> result = _connector.cacheEligLire(_tracabilite, idCleCompose, typeCle, techno, operateur);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    Assert.assertEquals(retour, result._first);
    Assert.assertNotNull(result._second);
  }

  /**
   * Test the method {@link RESConnector#couvertureCuivreLireTousParIdAdresseBytel(Tracabilite, String)} httpStatus 200
   * Retour KO with "lecture indisponible"
   *
   * Expected : Retour KO, CAT-1, LECTURE_INDISPONIBLE, "Unexpected error in res database connector: Test Error"
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void couvertureCuivreLireTousParIdAdresseBytel_Test_KO_001() throws Exception
  {

    final String idAdresseBytel = RandomStringUtils.randomAlphanumeric(13);
    final String message = MessageFormat.format(Messages.getString("res.unexpectedError"), "Test Error"); //$NON-NLS-1$ //$NON-NLS-2$
    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT1, IMegSpiritConsts.LECTURE_INDISPONIBLE, message, null);
    final GetCouvertureCuivreResponse getCouvertureCuivreResponse = new GetCouvertureCuivreResponse(RetourConverter.convertToJsonRetour(retour), null);
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(getCouvertureCuivreResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_couvertureCuivreUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<CouvertureCuivre>> result = _connector.couvertureCuivreLireTousParIdAdresseBytel(_tracabilite, idAdresseBytel);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, PARAM_ID_ADRESSE_BYTEL, idAdresseBytel);

    Assert.assertEquals(retour, result._first);
    Assert.assertEquals(new ArrayList<>(), result._second);
  }

  /**
   * Test the method {@link RESConnector#couvertureCuivreLireTousParIdAdresseBytel(Tracabilite, String)} httpStatus 200
   * jsonResponse null (throws RavelException)
   *
   * Expected : null JsonResponse - Retour KO, CAT-10, TRAITEMENT_ARRETE, "Impossible de récupérer la réponse"
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void couvertureCuivreLireTousParIdAdresseBytel_Test_KO_002() throws Exception
  {

    final String idAdresseBytel = RandomStringUtils.randomAlphanumeric(13);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_couvertureCuivreUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    // Call connector
    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<CouvertureCuivre>> result = _connector.couvertureCuivreLireTousParIdAdresseBytel(_tracabilite, idAdresseBytel);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, PARAM_ID_ADRESSE_BYTEL, idAdresseBytel);

    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, JSON_ERROR_MESSAGE, null);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test OK for the method {@link RESConnector#couvertureCuivreLireTousParIdAdresseBytel(Tracabilite, String)}
   * httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void couvertureCuivreLireTousParIdAdresseBytel_Test_OK_001() throws Exception
  {

    final String idAdresseBytel = RandomStringUtils.randomAlphanumeric(13);
    final CouvertureCuivre couvertureCuivre = _podam.manufacturePojoWithFullData(CouvertureCuivre.class);
    final List<CouvertureCuivre> listCouvertureCuivre = new ArrayList<>();
    listCouvertureCuivre.add(couvertureCuivre);
    final Retour retour = RetourFactoryForTU.createOkRetour();
    final GetCouvertureCuivreResponse getCouvertureCuivreResponse = new GetCouvertureCuivreResponse(RetourConverter.convertToJsonRetour(retour), listCouvertureCuivre);

    final String partnerResponse = GsonTools.getIso8601Ms().toJson(getCouvertureCuivreResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_couvertureCuivreUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<CouvertureCuivre>> result = _connector.couvertureCuivreLireTousParIdAdresseBytel(_tracabilite, idAdresseBytel);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, PARAM_ID_ADRESSE_BYTEL, idAdresseBytel);

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertEquals(listCouvertureCuivre, result._second);
  }

  /**
   * Test the method {@link RESConnector#couvertureCuivreLireUnParRivoli(Tracabilite, String, String, String)}
   * httpStatus 200 Retour KO with "lecture indisponible"
   *
   * Expected : Retour KO, CAT-1, LECTURE_INDISPONIBLE, "Unexpected error in res database connector: Test Error"
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void couvertureCuivreLireUnParRivoli_Test_KO_001() throws Exception
  {

    final String codeInsee = RandomStringUtils.randomAlphanumeric(5);
    final String rivoli = RandomStringUtils.randomAlphanumeric(5);
    final String numeroComplement = RandomStringUtils.randomAlphanumeric(5);
    final String message = MessageFormat.format(Messages.getString("res.unexpectedError"), "Test Error"); //$NON-NLS-1$ //$NON-NLS-2$
    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT1, IMegSpiritConsts.LECTURE_INDISPONIBLE, message, null);
    final GetCouvertureCuivreResponse getCouvertureCuivreResponse = new GetCouvertureCuivreResponse(RetourConverter.convertToJsonRetour(retour), null);
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(getCouvertureCuivreResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_couvertureCuivreUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<CouvertureCuivre>> result = _connector.couvertureCuivreLireUnParRivoli(_tracabilite, codeInsee, rivoli, numeroComplement);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, PARAM_CODE_INSEE, codeInsee);
    checkQueryParams(queryParamsCapture, PARAM_RIVOLI, rivoli);
    checkQueryParams(queryParamsCapture, PARAM_NUMERO_COMPLEMENT, numeroComplement);

    Assert.assertEquals(retour, result._first);
    Assert.assertEquals(new ArrayList<>(), result._second);
  }

  /**
   * Test the method {@link RESConnector#couvertureCuivreLireUnParRivoli(Tracabilite, String, String, String)}
   * httpStatus 200 jsonResponse null (throws RavelException)
   *
   * Expected : null JsonResponse - Retour KO, CAT-10, TRAITEMENT_ARRETE, "Impossible de récupérer la réponse"
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void couvertureCuivreLireUnParRivoli_Test_KO_002() throws Exception
  {

    final String codeInsee = RandomStringUtils.randomAlphanumeric(5);
    final String rivoli = RandomStringUtils.randomAlphanumeric(5);
    final String numeroComplement = RandomStringUtils.randomAlphanumeric(5);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_couvertureCuivreUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    // Call connector
    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<CouvertureCuivre>> result = _connector.couvertureCuivreLireUnParRivoli(_tracabilite, codeInsee, rivoli, numeroComplement);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, PARAM_CODE_INSEE, codeInsee);
    checkQueryParams(queryParamsCapture, PARAM_RIVOLI, rivoli);
    checkQueryParams(queryParamsCapture, PARAM_NUMERO_COMPLEMENT, numeroComplement);

    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, JSON_ERROR_MESSAGE, null);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test OK for the method {@link RESConnector#couvertureCuivreLireUnParRivoli(Tracabilite, String, String, String)}
   * httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void couvertureCuivreLireUnParRivoli_Test_OK_001() throws Exception
  {

    final String codeInsee = RandomStringUtils.randomAlphanumeric(5);
    final String rivoli = RandomStringUtils.randomAlphanumeric(5);
    final String numeroComplement = RandomStringUtils.randomAlphanumeric(5);

    final CouvertureCuivre couvertureCuivre = _podam.manufacturePojoWithFullData(CouvertureCuivre.class);
    final List<CouvertureCuivre> listCouvertureCuivre = new ArrayList<>();
    listCouvertureCuivre.add(couvertureCuivre);
    final Retour retour = RetourFactoryForTU.createOkRetour();
    final GetCouvertureCuivreResponse getCouvertureCuivreResponse = new GetCouvertureCuivreResponse(RetourConverter.convertToJsonRetour(retour), listCouvertureCuivre);

    final String partnerResponse = GsonTools.getIso8601Ms().toJson(getCouvertureCuivreResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_couvertureCuivreUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<CouvertureCuivre>> result = _connector.couvertureCuivreLireUnParRivoli(_tracabilite, codeInsee, rivoli, numeroComplement);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, PARAM_CODE_INSEE, codeInsee);
    checkQueryParams(queryParamsCapture, PARAM_RIVOLI, rivoli);
    checkQueryParams(queryParamsCapture, PARAM_NUMERO_COMPLEMENT, numeroComplement);

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertEquals(listCouvertureCuivre, result._second);
  }

  /**
   * Test the method {@link RESConnector#couvertureFttoLireUn(Tracabilite, String)} httpStatus 200 Retour KO with
   * "lecture indisponible"
   *
   * Expected : Retour KO, CAT-1, LECTURE_INDISPONIBLE, "Unexpected error in res database connector: Test Error"
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void couvertureFttoLireUn_Test_KO_001() throws Exception
  {

    final String idAdresseBytel = RandomStringUtils.randomAlphanumeric(13);
    final String message = MessageFormat.format(Messages.getString("res.unexpectedError"), "Test Error"); //$NON-NLS-1$ //$NON-NLS-2$
    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT1, IMegSpiritConsts.LECTURE_INDISPONIBLE, message, null);
    final GetCouvertureFttoResponse getCouvertureFttoResponse = new GetCouvertureFttoResponse(RetourConverter.convertToJsonRetour(retour), null);
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(getCouvertureFttoResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_couvertureFttoUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, CouvertureFtto> result = _connector.couvertureFttoLireUn(_tracabilite, idAdresseBytel);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, PARAM_ID_ADRESSE_BYTEL, idAdresseBytel);

    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method {@link RESConnector#couvertureFttoLireUn(Tracabilite, String)} httpStatus 200 jsonResponse null
   * (throws RavelException)
   *
   * Expected : null JsonResponse - Retour KO, CAT-10, TRAITEMENT_ARRETE, "Impossible de récupérer la réponse"
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void couvertureFttoLireUn_Test_KO_002() throws Exception
  {

    final String idAdresseBytel = RandomStringUtils.randomAlphanumeric(13);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_couvertureFttoUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    // Call connector
    PowerMock.replayAll();
    final ConnectorResponse<Retour, CouvertureFtto> result = _connector.couvertureFttoLireUn(_tracabilite, idAdresseBytel);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, PARAM_ID_ADRESSE_BYTEL, idAdresseBytel);

    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, JSON_ERROR_MESSAGE, null);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test OK for the method {@link RESConnector#couvertureFttoLireUn(Tracabilite, String)} httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void couvertureFttoLireUn_Test_OK_001() throws Exception
  {

    final String idAdresseBytel = RandomStringUtils.randomAlphanumeric(13);

    final CouvertureFtto couvertureFtto = _podam.manufacturePojoWithFullData(CouvertureFtto.class);
    final Retour retour = RetourFactoryForTU.createOkRetour();
    final GetCouvertureFttoResponse getCouvertureFttoResponse = new GetCouvertureFttoResponse(RetourConverter.convertToJsonRetour(retour), couvertureFtto);

    final String partnerResponse = GsonTools.getIso8601Ms().toJson(getCouvertureFttoResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_couvertureFttoUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, CouvertureFtto> result = _connector.couvertureFttoLireUn(_tracabilite, idAdresseBytel);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, PARAM_ID_ADRESSE_BYTEL, idAdresseBytel);

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertEquals(couvertureFtto, result._second);
  }

  /**
   * Test the method {@link RESConnector#couvertureTokyoLireUn(Tracabilite, String)} httpStatus 200 Retour KO with
   * "lecture indisponible"
   *
   * Expected : Retour KO, CAT-1, LECTURE_INDISPONIBLE, "Unexpected error in res database connector: Test Error"
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void couvertureTokyoLireUn_Test_KO_001() throws Exception
  {

    final String idAdresseBytel = RandomStringUtils.randomAlphanumeric(13);
    final String message = MessageFormat.format(Messages.getString("res.unexpectedError"), "Test Error"); //$NON-NLS-1$ //$NON-NLS-2$
    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT1, IMegSpiritConsts.LECTURE_INDISPONIBLE, message, null);
    final GetCouvertureTokyoResponse getCouvertureTokyoResponse = new GetCouvertureTokyoResponse(RetourConverter.convertToJsonRetour(retour), null);
    final String partnerResponse = this.serializeWithMoshi(getCouvertureTokyoResponse, GetCouvertureTokyoResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_couvertureTokyoUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, CouvertureTokyo> result = _connector.couvertureTokyoLireUn(_tracabilite, idAdresseBytel);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, PARAM_ID_ADRESSE_BYTEL, idAdresseBytel);

    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method {@link RESConnector#couvertureTokyoLireUn(Tracabilite, String)} httpStatus 200 jsonResponse null
   * (throws RavelException)
   *
   * Expected : null JsonResponse - Retour KO, CAT-10, TRAITEMENT_ARRETE, "Impossible de récupérer la réponse"
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void couvertureTokyoLireUn_Test_KO_002() throws Exception
  {

    final String idAdresseBytel = RandomStringUtils.randomAlphanumeric(13);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_couvertureTokyoUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    // Call connector
    PowerMock.replayAll();
    final ConnectorResponse<Retour, CouvertureTokyo> result = _connector.couvertureTokyoLireUn(_tracabilite, idAdresseBytel);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, PARAM_ID_ADRESSE_BYTEL, idAdresseBytel);

    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, JSON_ERROR_MESSAGE, null);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test OK for the method {@link RESConnector#couvertureTokyoLireUn(Tracabilite, String)} httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void couvertureTokyoLireUn_Test_OK_001() throws Exception
  {

    final String idAdresseBytel = RandomStringUtils.randomAlphanumeric(13);

    final CouvertureTokyo couvertureTokyo = _podam.manufacturePojoWithFullData(CouvertureTokyo.class);
    final Retour retour = RetourFactoryForTU.createOkRetour();
    final GetCouvertureTokyoResponse getCouvertureTokyoResponse = new GetCouvertureTokyoResponse(RetourConverter.convertToJsonRetour(retour), couvertureTokyo);

    final String partnerResponse = this.serializeWithMoshi(getCouvertureTokyoResponse, GetCouvertureTokyoResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_couvertureTokyoUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, CouvertureTokyo> result = _connector.couvertureTokyoLireUn(_tracabilite, idAdresseBytel);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, PARAM_ID_ADRESSE_BYTEL, idAdresseBytel);

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertEquals(couvertureTokyo, result._second);
  }

  /**
   * Test NOK for the method {@link RESConnector#dispoNroFtteOrgLire(Tracabilite, String)} with null JsonResponse -
   * Retour KO, CAT-10, TRAITEMENT_ARRETE
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void dispoNroFtteOrgLire_Test_NOK_001() throws Exception
  {
    final String nro = RandomStringUtils.random(5);

    final Retour retour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, StringConstants.EMPTY_STRING);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    // construct response
    final Response response = null;

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(PAD3014_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, DispoNroFtteOrg> result = _connector.dispoNroFtteOrgLire(_tracabilite, nro);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    Assert.assertEquals(retour.getDiagnostic(), result._first.getDiagnostic());
    Assert.assertEquals(retour.getCategorie(), result._first.getCategorie());

    Assert.assertNull(result._second);
  }

  /**
   * Test Exception NOK for the method {@link RESConnector#dispoNroFtteOrgLire(Tracabilite, String)}
   *
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void dispoNroFtteOrgLire_Test_NOK_002_Exception() throws Exception
  {
    final String nro = RandomStringUtils.random(5);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    // construct response
    final Response response = null;

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(PAD3014_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    try
    {
      _connector.dispoNroFtteOrgLire(_tracabilite, nro);
    }
    catch (RavelException e)
    {
      Assert.assertEquals(ExceptionType.UNEXPECTED, e.getExceptionType());
      Assert.assertEquals(ErrorCode.CNCTOR_00010, e.getErrorCode());
      Assert.assertEquals("Impossible de récupérer la réponse", e.getMessage()); //$NON-NLS-1$
    }
  }

  /**
   * Test OK for the method {@link RESConnector#dispoNroFtteOrgLire(Tracabilite, String)} with httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void dispoNroFtteOrgLire_Test_OK_001() throws Exception
  {
    final String nro = RandomStringUtils.random(5);

    final DispoNroFtteOrg dispoNroFtteOrg = _podam.manufacturePojo(DispoNroFtteOrg.class);
    final Retour retour = RetourFactoryForTU.createOkRetour();
    final GetDispoNroFtteOrgResponse Response = new GetDispoNroFtteOrgResponse(RetourConverter.convertToJsonRetour(retour), dispoNroFtteOrg);
    final String partnerResponse = RavelJsonTools.getInstance().toJson(Response, GetDispoNroFtteOrgResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    // construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(PAD3014_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, DispoNroFtteOrg> result = _connector.dispoNroFtteOrgLire(_tracabilite, nro);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    Assert.assertEquals(retour, result._first);
    Assert.assertNotNull(result._second);
  }

  /**
   * Test KO for the method
   * {@link RESConnector#fichierReferentielCompositeGererEchecIntegration(Tracabilite, String, FichierOrigine)}
   *
   * Expected : Retour KO, CAT-1, LECTURE_INDISPONIBLE, "Unexpected error in res database connector: Test Error"
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void fichierReferentielCompositeGererEchecIntegration_KO_001() throws Exception
  {

    final FichierOrigine fichierOrigine = _podam.manufacturePojoWithFullData(FichierOrigine.class);
    final String typeReferentiel = "COUV_CUIVRE"; //$NON-NLS-1$

    final String message = MessageFormat.format(Messages.getString("res.unexpectedError"), "Test Error"); //$NON-NLS-1$ //$NON-NLS-2$
    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT1, IMegSpiritConsts.LECTURE_INDISPONIBLE, message, null);
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(basicResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_fichierReferentielCompositeUrl), EasyMock.capture(headersCapture), EasyMock.eq(GsonTools.getIso8601Ms().toJson(fichierOrigine)), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.fichierReferentielCompositeGererEchecIntegration(_tracabilite, typeReferentiel, fichierOrigine);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, PARAM_TYPE_REFERENTIEL, typeReferentiel);
    checkQueryParams(queryParamsCapture, PARAM_ACTION, "GererEchecIntegration"); //$NON-NLS-1$

    //check result
    Assert.assertEquals(retour, result._first);
  }

  /**
   * Test KO for the method
   * {@link RESConnector#fichierReferentielCompositeGererEchecIntegration(Tracabilite, String, FichierOrigine)}
   *
   *
   * Expected : null JsonResponse - Retour KO, CAT-10, TRAITEMENT_ARRETE, "Impossible de récupérer la réponse"
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void fichierReferentielCompositeGererEchecIntegration_KO_002() throws Exception
  {

    final FichierOrigine fichierOrigine = _podam.manufacturePojoWithFullData(FichierOrigine.class);
    final String typeReferentiel = "COUV_CUIVRE"; //$NON-NLS-1$

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_fichierReferentielCompositeUrl), EasyMock.capture(headersCapture), EasyMock.eq(GsonTools.getIso8601Ms().toJson(fichierOrigine)), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.fichierReferentielCompositeGererEchecIntegration(_tracabilite, typeReferentiel, fichierOrigine);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, PARAM_TYPE_REFERENTIEL, typeReferentiel);
    checkQueryParams(queryParamsCapture, PARAM_ACTION, "GererEchecIntegration"); //$NON-NLS-1$

    //check result
    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, JSON_ERROR_MESSAGE, null);
    Assert.assertEquals(retour, result._first);
  }

  /**
   * Test OK for the method
   * {@link RESConnector#fichierReferentielCompositeGererEchecIntegration(Tracabilite, String, FichierOrigine)}
   *
   * Expected : Retour OK
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void fichierReferentielCompositeGererEchecIntegration_OK_001() throws Exception
  {

    final FichierOrigine fichierOrigine = _podam.manufacturePojoWithFullData(FichierOrigine.class);
    final String typeReferentiel = "COUV_CUIVRE"; //$NON-NLS-1$

    final Retour retour = RetourFactoryForTU.createOkRetour();
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(basicResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_fichierReferentielCompositeUrl), EasyMock.capture(headersCapture), EasyMock.eq(GsonTools.getIso8601Ms().toJson(fichierOrigine)), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.fichierReferentielCompositeGererEchecIntegration(_tracabilite, typeReferentiel, fichierOrigine);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, PARAM_TYPE_REFERENTIEL, typeReferentiel);
    checkQueryParams(queryParamsCapture, PARAM_ACTION, "GererEchecIntegration"); //$NON-NLS-1$

    //check result
    Assert.assertEquals(retour, result._first);
  }

  /**
   * Test the method {@link RESConnector#fichierReferentielCompositeLireTous(Tracabilite, String)} httpStatus 200 Retour
   * KO with "lecture indisponible"
   *
   * Expected : Retour KO, CAT-1, LECTURE_INDISPONIBLE, "Unexpected error in res database connector: Test Error"
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void fichierReferentielCompositeLireTous_Test_KO_001() throws Exception
  {

    final String typeReferentiel = "COUV_CUIVRE"; //$NON-NLS-1$
    final String message = MessageFormat.format(Messages.getString("res.unexpectedError"), "Test Error"); //$NON-NLS-1$ //$NON-NLS-2$
    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT1, IMegSpiritConsts.LECTURE_INDISPONIBLE, message, null);
    final GetFichierReferentielCompositeResponse getFichierReferentielCompositeResponse = new GetFichierReferentielCompositeResponse(RetourConverter.convertToJsonRetour(retour), null);
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(getFichierReferentielCompositeResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_fichierReferentielCompositeUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<FichierReferentielComposite>> result = _connector.fichierReferentielCompositeLireTous(_tracabilite, typeReferentiel);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, PARAM_TYPE_REFERENTIEL, typeReferentiel);

    Assert.assertEquals(retour, result._first);
    Assert.assertEquals(new ArrayList<>(), result._second);
  }

  /**
   * Test the method {@link RESConnector#fichierReferentielCompositeLireTous(Tracabilite, String)} httpStatus 200 Retour
   * KO
   *
   * Expected : null JsonResponse - Retour KO, CAT-10, TRAITEMENT_ARRETE, "Impossible de récupérer la réponse"
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void fichierReferentielCompositeLireTous_Test_KO_002() throws Exception
  {

    final String typeReferentiel = "COUV_CUIVRE"; //$NON-NLS-1$

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_fichierReferentielCompositeUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<FichierReferentielComposite>> result = _connector.fichierReferentielCompositeLireTous(_tracabilite, typeReferentiel);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, PARAM_TYPE_REFERENTIEL, typeReferentiel);

    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, JSON_ERROR_MESSAGE, null);
    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method {@link RESConnector#fichierReferentielCompositeLireTous(Tracabilite, String)}
   *
   * Expected : Retour OK
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void fichierReferentielCompositeLireTous_Test_OK_001() throws Exception
  {
    final String typeReferentiel = "COUV_CUIVRE"; //$NON-NLS-1$

    final FichierReferentielComposite fichierReferentielComposite = _podam.manufacturePojoWithFullData(FichierReferentielComposite.class);
    LocalDateTime creation = LocalDateTime.of(2018, Month.AUGUST, 15, 14, 30, 00, 123000000);
    LocalDateTime modification = LocalDateTime.of(2018, Month.AUGUST, 21, 15, 45, 30, 125000000);
    final FichierOrigine fichierOrigine = new FichierOrigine("nomFichier", "CSV", 2, creation, "indexFichier", "idRef", typeReferentiel); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$

    final List<FichierOrigine> listFichierOrigine = new ArrayList<>();
    final List<FichierReferentielComposite> listFichierReferentielComposite = new ArrayList<>();

    fichierOrigine.setDateCreation(creation);
    fichierOrigine.setDateModification(modification);
    listFichierOrigine.add(fichierOrigine);
    fichierReferentielComposite.getGestionReferentiel().setDateCreation(creation);
    fichierReferentielComposite.getGestionReferentiel().setDateModification(modification);
    fichierReferentielComposite.setListeNomFichierOrigine(listFichierOrigine);

    listFichierReferentielComposite.add(fichierReferentielComposite);

    final Retour retour = RetourFactoryForTU.createOkRetour();
    final GetFichierReferentielCompositeResponse getFichierReferentielCompositeResponse = new GetFichierReferentielCompositeResponse(RetourConverter.convertToJsonRetour(retour), listFichierReferentielComposite);
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(getFichierReferentielCompositeResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_fichierReferentielCompositeUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<FichierReferentielComposite>> result = _connector.fichierReferentielCompositeLireTous(_tracabilite, typeReferentiel);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, PARAM_TYPE_REFERENTIEL, typeReferentiel);

    Assert.assertEquals(retour, result._first);
    Assert.assertEquals(listFichierReferentielComposite, result._second);
  }

  /**
   * Test KO for the method
   * {@link RESConnector#ressourceCompteMailModifierStatutAllocation(Tracabilite, String, String, String)}
   *
   * Expected : Retour KO, CAT-4, DONNEE_INCONNUE, "ressourceCompteMail xxx inconnue"
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void fqdnGererAllocationSession_KO_001() throws Exception
  {

    final String nomFqdn = RandomStringUtils.randomAlphabetic(5);
    final String operation = "ALLOUER"; //$NON-NLS-1$
    final int nombreSession = 2;

    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "ressourceCompteMail " + nomFqdn + " inconnue", null); //$NON-NLS-1$ //$NON-NLS-2$
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(basicResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_fqdnUrl), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.fqdnGererAllocationSession(_tracabilite, nomFqdn, operation, nombreSession);

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, PARAM_NOM_FQDN, nomFqdn);
    checkQueryParams(queryParamsCapture, PARAM_OPERATION, operation);
    checkQueryParams(queryParamsCapture, PARAM_NOMBRE_SESSION, Integer.valueOf(nombreSession).toString());

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test OK for the method
   * {@link RESConnector#ressourceRaccordementModifierStatutAllocation(Tracabilite, String, String, String)} httpStatus
   * 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void fqdnGererAllocationSession_OK_001() throws Exception
  {

    final String nomFqdn = RandomStringUtils.randomAlphabetic(5);
    final String operation = "LIBERER"; //$NON-NLS-1$
    final int nombreSession = 2;

    final Retour retour = RetourFactoryForTU.createOkRetour();
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(basicResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_fqdnUrl), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.fqdnGererAllocationSession(_tracabilite, nomFqdn, operation, nombreSession);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, PARAM_NOM_FQDN, nomFqdn);
    checkQueryParams(queryParamsCapture, PARAM_OPERATION, operation);
    checkQueryParams(queryParamsCapture, PARAM_NOMBRE_SESSION, Integer.valueOf(nombreSession).toString());

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method {@link RESConnector#fqdnLireUn(Tracabilite, String)} httpStatus 200 Retour KO with "lecture
   * indisponible"
   *
   * Expected : Retour KO, CAT-1, LECTURE_INDISPONIBLE, "Unexpected error in res database connector: Test Error"
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void fqdnLireUn_Test_KO_001() throws Exception
  {

    final String nomFQDN = RandomStringUtils.randomAlphanumeric(13);
    final String message = MessageFormat.format(Messages.getString("res.unexpectedError"), "Test Error"); //$NON-NLS-1$ //$NON-NLS-2$

    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT1, IMegSpiritConsts.LECTURE_INDISPONIBLE, message, null);
    final GetListeFqdnResponse getFqdnResponse = new GetListeFqdnResponse(RetourConverter.convertToJsonRetour(retour), null);
    final String partnerResponse = this.serializeWithMoshi(getFqdnResponse, GetListeFqdnResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_fqdnUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Fqdn> result = _connector.fqdnLireUn(_tracabilite, nomFQDN);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, PARAM_NOM_FQDN, nomFQDN);

    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method {@link RESConnector#fqdnLireUn(Tracabilite, String)} httpStatus 200 jsonResponse null (throws
   * RavelException)
   *
   * Expected : null JsonResponse - Retour KO, CAT-10, TRAITEMENT_ARRETE, "Impossible de récupérer la réponse"
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void fqdnLireUn_Test_KO_002() throws Exception
  {

    final String nomFQDN = RandomStringUtils.randomAlphanumeric(13);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_fqdnUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    // Call connector
    PowerMock.replayAll();
    final ConnectorResponse<Retour, Fqdn> result = _connector.fqdnLireUn(_tracabilite, nomFQDN);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, PARAM_NOM_FQDN, nomFQDN);

    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, JSON_ERROR_MESSAGE, null);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method {@link RESConnector#fqdnLireUnParTauxOccupation(Tracabilite)} httpStatus 200 Retour KO with
   * "lecture indisponible"
   *
   * Expected : Retour KO, CAT-1, LECTURE_INDISPONIBLE, "Unexpected error in res database connector: Test Error"
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void fqdnLireUnParTauxOccupation_Test_KO_001() throws Exception
  {
    final String message = MessageFormat.format(Messages.getString("res.unexpectedError"), "Test Error"); //$NON-NLS-1$ //$NON-NLS-2$

    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT1, IMegSpiritConsts.LECTURE_INDISPONIBLE, message, null);
    final GetListeFqdnResponse getFqdnResponse = new GetListeFqdnResponse(RetourConverter.convertToJsonRetour(retour), null);
    final String partnerResponse = this.serializeWithMoshi(getFqdnResponse, GetListeFqdnResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_fqdnUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Fqdn> result = _connector.fqdnLireUnParTauxOccupation(_tracabilite);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method {@link RESConnector#fqdnLireUnParTauxOccupation(Tracabilite)} httpStatus 200 jsonResponse null
   * (throws RavelException)
   *
   * Expected : null JsonResponse - Retour KO, CAT-10, TRAITEMENT_ARRETE, "Impossible de récupérer la réponse"
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void fqdnLireUnParTauxOccupation_Test_KO_002() throws Exception
  {
    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_fqdnUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    // Call connector
    PowerMock.replayAll();
    final ConnectorResponse<Retour, Fqdn> result = _connector.fqdnLireUnParTauxOccupation(_tracabilite);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, JSON_ERROR_MESSAGE, null);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test OK for the method {@link RESConnector#fqdnLireUnParTauxOccupation(Tracabilite)} httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void fqdnLireUnParTauxOccupation_Test_OK_001() throws Exception
  {
    final Fqdn fqdn = _podam.manufacturePojoWithFullData(Fqdn.class);
    final Retour retour = RetourFactoryForTU.createOkRetour();
    final GetListeFqdnResponse getFqdnResponse = new GetListeFqdnResponse(RetourConverter.convertToJsonRetour(retour), Collections.singletonList(fqdn));

    final String partnerResponse = this.serializeWithMoshi(getFqdnResponse, GetListeFqdnResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_fqdnUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Fqdn> result = _connector.fqdnLireUnParTauxOccupation(_tracabilite);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertEquals(fqdn, result._second);
  }

  /**
   * Test OK for the method {@link RESConnector#fqdnLireUn(Tracabilite, String)} httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void fqdnLireUnTest_OK_001() throws Exception
  {

    final String nomFQDN = RandomStringUtils.randomAlphanumeric(13);

    final Fqdn fqdn = _podam.manufacturePojoWithFullData(Fqdn.class);
    final Retour retour = RetourFactoryForTU.createOkRetour();
    final GetListeFqdnResponse getFqdnResponse = new GetListeFqdnResponse(RetourConverter.convertToJsonRetour(retour), Collections.singletonList(fqdn));

    final String partnerResponse = this.serializeWithMoshi(getFqdnResponse, GetListeFqdnResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_fqdnUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Fqdn> result = _connector.fqdnLireUn(_tracabilite, nomFQDN);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, PARAM_NOM_FQDN, nomFQDN);

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertEquals(fqdn, result._second);
  }

  /**
   * Test KO for the method {@link RESConnector#gestionReferentielGererBascule(Tracabilite, String)}
   *
   * Expected : Retour KO, CAT-1, LECTURE_INDISPONIBLE, "Unexpected error in res database connector: Test Error"
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void gestionReferentielGererBascule_Test_KO_001() throws Exception
  {

    final String typeReferentiel = "COUV_CUIVRE"; //$NON-NLS-1$

    final String message = MessageFormat.format(Messages.getString("res.unexpectedError"), "Test Error"); //$NON-NLS-1$ //$NON-NLS-2$
    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT1, IMegSpiritConsts.LECTURE_INDISPONIBLE, message, null);
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(basicResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_gestionReferentielUrl), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.gestionReferentielGererBascule(_tracabilite, typeReferentiel);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, PARAM_TYPE_REFERENTIEL, typeReferentiel);
    checkQueryParams(queryParamsCapture, PARAM_ACTION, "GererBascule"); //$NON-NLS-1$

    //check result
    Assert.assertEquals(retour, result._first);
  }

  /**
   * Test KO for the method {@link RESConnector#gestionReferentielGererBascule(Tracabilite, String)}
   *
   * Expected : null JsonResponse - Retour KO, CAT-10, TRAITEMENT_ARRETE, "Impossible de récupérer la réponse"
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void gestionReferentielGererBascule_Test_KO_002() throws Exception
  {

    final String typeReferentiel = "COUV_CUIVRE"; //$NON-NLS-1$

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_gestionReferentielUrl), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.gestionReferentielGererBascule(_tracabilite, typeReferentiel);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, PARAM_TYPE_REFERENTIEL, typeReferentiel);
    checkQueryParams(queryParamsCapture, PARAM_ACTION, "GererBascule"); //$NON-NLS-1$

    //check result
    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, JSON_ERROR_MESSAGE, null);
    Assert.assertEquals(retour, result._first);
  }

  /**
   * Test OK for the method {@link RESConnector#gestionReferentielGererBascule(Tracabilite, String)}
   *
   * Expected : Retour OK
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void gestionReferentielGererBascule_Test_OK_001() throws Exception
  {

    final String typeReferentiel = "COUV_CUIVRE"; //$NON-NLS-1$

    final Retour retour = RetourFactoryForTU.createOkRetour();
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(basicResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_gestionReferentielUrl), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.gestionReferentielGererBascule(_tracabilite, typeReferentiel);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, PARAM_TYPE_REFERENTIEL, typeReferentiel);
    checkQueryParams(queryParamsCapture, PARAM_ACTION, "GererBascule"); //$NON-NLS-1$

    //check result
    Assert.assertEquals(retour, result._first);
  }

  /**
   * Test KO for the method {@link RESConnector#gestionReferentielGererRestaurationBackup(Tracabilite, String)}
   *
   * Expected : Retour KO, CAT-1, LECTURE_INDISPONIBLE, "Unexpected error in res database connector: Test Error"
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void gestionReferentielGererRestaurationBackup_Test_KO_001() throws Exception
  {

    final String typeReferentiel = "COUV_CUIVRE"; //$NON-NLS-1$

    final String message = MessageFormat.format(Messages.getString("res.unexpectedError"), "Test Error"); //$NON-NLS-1$ //$NON-NLS-2$
    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT1, IMegSpiritConsts.LECTURE_INDISPONIBLE, message, null);
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(basicResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_gestionReferentielUrl), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.gestionReferentielGererRestaurationBackup(_tracabilite, typeReferentiel);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, PARAM_TYPE_REFERENTIEL, typeReferentiel);
    checkQueryParams(queryParamsCapture, PARAM_ACTION, "GererRestaurationBackup"); //$NON-NLS-1$

    //check result
    Assert.assertEquals(retour, result._first);
  }

  /**
   * Test KO for the method {@link RESConnector#gestionReferentielGererRestaurationBackup(Tracabilite, String)}
   *
   * Expected : null JsonResponse - Retour KO, CAT-10, TRAITEMENT_ARRETE, "Impossible de récupérer la réponse"
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void gestionReferentielGererRestaurationBackup_Test_KO_002() throws Exception
  {

    final String typeReferentiel = "COUV_CUIVRE"; //$NON-NLS-1$

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_gestionReferentielUrl), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);
    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.gestionReferentielGererRestaurationBackup(_tracabilite, typeReferentiel);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, PARAM_TYPE_REFERENTIEL, typeReferentiel);
    checkQueryParams(queryParamsCapture, PARAM_ACTION, "GererRestaurationBackup"); //$NON-NLS-1$

    //check result
    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, JSON_ERROR_MESSAGE, null);
    Assert.assertEquals(retour, result._first);
  }

  /**
   * Test OK for the method {@link RESConnector#gestionReferentielGererRestaurationBackup(Tracabilite, String)}
   *
   * Expected : Retour OK
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void gestionReferentielGererRestaurationBackup_Test_OK_001() throws Exception
  {

    final String typeReferentiel = "COUV_CUIVRE"; //$NON-NLS-1$

    final Retour retour = RetourFactoryForTU.createOkRetour();
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(basicResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_gestionReferentielUrl), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.gestionReferentielGererRestaurationBackup(_tracabilite, typeReferentiel);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, PARAM_TYPE_REFERENTIEL, typeReferentiel);
    checkQueryParams(queryParamsCapture, PARAM_ACTION, "GererRestaurationBackup"); //$NON-NLS-1$

    //check result
    Assert.assertEquals(retour, result._first);
  }

  /**
   * Test the method {@link RESConnector#ressourceLireTousParIdRessourceLie} httpStatus 200.
   *
   * @IN - Parameter ID_RESSOURCELIE.
   * @OUT - Retour NOK CAT4 , List Ressources Empty
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void pad3100RessourceLireTousParIdRessourceLie_KO_001() throws Exception
  {

    final String idRessourceLie = RandomStringUtils.randomAlphabetic(5);
    final String typeRessource = RandomStringUtils.randomAlphabetic(10);

    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "idRessource " + idRessourceLie + " inconnu", null); //$NON-NLS-1$ //$NON-NLS-2$
    List<Ressource> listRessource = new ArrayList<>();
    final GetRessourceResponse getListRessourceResponse = new GetRessourceResponse(RetourConverter.convertToJsonRetour(retour), listRessource);
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(getListRessourceResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario

    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_ressourceUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<Ressource>> result = _connector.ressourceLireTousParIdRessourceLie(_tracabilite, idRessourceLie, typeRessource);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, PARAM_ID_RESSOURCELIE, idRessourceLie);

    Assert.assertEquals(retour, result._first);
    Assert.assertEquals(0, result._second.size());
  }

  /**
   * Test the method {@link RESConnector#ressourceLireTousParIdRessourceLie(Tracabilite, String, String)} httpStatus
   * 404.
   *
   * @IN - Parameter ID_RESSOURCELIE.
   * @OUT - Retour NOK CAT4 , response null
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void pad3100RessourceLireTousParIdRessourceLie_KO_002() throws Exception
  {

    final String idRessourceLie = RandomStringUtils.randomAlphabetic(5);
    final String typeRessource = RandomStringUtils.randomAlphabetic(10);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(404).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_ressourceUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    // ConnectorResponse<Retour, List<Ressource>> result = null;

    // Call connector
    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<Ressource>> result = _connector.ressourceLireTousParIdRessourceLie(_tracabilite, idRessourceLie, typeRessource);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, PARAM_ID_RESSOURCELIE, idRessourceLie);

    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, JSON_ERROR_MESSAGE, null);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test OK for the method {@link RESConnector#ressourceLireUn(Tracabilite, String, String)} httpStatus 200
   *
   * @IN - Parameter ID_RESSOURCELIE.
   * @OUT - Retour OK , List Ressources size 1
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void pad3100RessourceLireTousParIdRessourceLie_OK_001() throws Exception
  {

    final String idRessourceLie = RandomStringUtils.randomAlphanumeric(5);
    final String typeRessource = RandomStringUtils.randomAlphanumeric(10);

    final Ressource ressource = _podam.manufacturePojo(Ressource.class);

    final List<Ressource> listressources = new ArrayList<>();
    listressources.add(ressource);

    final Retour retour = RetourFactoryForTU.createOkRetour();
    final GetRessourceResponse getListRessourceResponse = new GetRessourceResponse(RetourConverter.convertToJsonRetour(retour), listressources);
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(getListRessourceResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_ressourceUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<Ressource>> result = _connector.ressourceLireTousParIdRessourceLie(_tracabilite, idRessourceLie, typeRessource);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, PARAM_ID_RESSOURCELIE, idRessourceLie);

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertEquals(listressources.size(), result._second.size());
    Assert.assertEquals(listressources, result._second);

  }

  @Test
  public void pad3100RessourcemodifierIdRessourceLie_OK() throws Exception
  {

    final String idRessourceLie = RandomStringUtils.randomAlphanumeric(5);
    final String typeRessource = RandomStringUtils.randomAlphanumeric(10);

    final Ressource ressource = _podam.manufacturePojo(Ressource.class);

    final List<Ressource> listressources = new ArrayList<>();
    listressources.add(ressource);

    final Retour retour = RetourFactoryForTU.createOkRetour();
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String retourjson = GsonTools.getIso8601Ms().toJson(basicResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(retourjson.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_ressourceUrl), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();

    final ConnectorResponse<Retour, Nothing> result = _connector.ressourceModifierIdRessourceLie(_tracabilite, "typeRessource", "idRessource", "idRessourceLie", "idRessourceLieCible"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, "idRessourceLie", "idRessourceLie"); //$NON-NLS-1$ //$NON-NLS-2$
    checkQueryParams(queryParamsCapture, "idRessourceLieCible", "idRessourceLieCible"); //$NON-NLS-1$//$NON-NLS-2$
    checkQueryParams(queryParamsCapture, "typeRessource", "typeRessource"); //$NON-NLS-1$ //$NON-NLS-2$
    checkQueryParams(queryParamsCapture, "idRessource", "idRessource"); //$NON-NLS-1$//$NON-NLS-2$

    //check result
    Assert.assertEquals(retour, result._first);

  }

  /**
   * Test the method {@link RESConnector#pad3101RessourceAggregeP2PLireUn(Tracabilite, String, String)} httpStatus 404.
   *
   * @IN - Parameter ID_RESSOURCE. Parameter TYPE_RESSOURCE_AGGREGE.
   * @OUT - Retour NOK CAT4 , response null
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void pad3101RessourceAggregeP2PLireUn_KO_001() throws Exception
  {

    final String idRessource = RandomStringUtils.randomAlphabetic(5);
    final String typeRessourceAggrege = RandomStringUtils.randomAlphabetic(5);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(404).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_ressourceReseauCompositeUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    // Call connector
    PowerMock.replayAll();
    final ConnectorResponse<Retour, RessourceAggrege> result = _connector.pad3101RessourceAggregeP2PLireUn(_tracabilite, typeRessourceAggrege, idRessource);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, PARAM_TYPE_RESSOURCE_AGGREGE, typeRessourceAggrege);
    checkQueryParams(queryParamsCapture, PARAM_ID_RESSOURCE, idRessource);

    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, JSON_ERROR_MESSAGE, null);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test OK for the method {@link RESConnector#pad3101RessourceAggregeP2PLireUn(Tracabilite, String, String)}
   * httpStatus 200
   *
   * @IN - Parameter TYPERESSOURCEAGGREGE, ID_RESSOURCE.
   * @OUT - Retour OK , RESSOURCEAGGREGE,
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void pad3101RessourceAggregeP2PLireUn_OK_001() throws Exception
  {

    final String idRessource = RandomStringUtils.randomAlphabetic(5);
    final String typeRessourceAggrege = RandomStringUtils.randomAlphabetic(5);

    RessourceAggregeP2P ressourceAggregeP2P = new RessourceAggregeP2P("nomOlt", 1, 2, 3); //$NON-NLS-1$
    ressourceAggregeP2P.setPositionRelativePortP2P(0);

    final Retour retour = RetourFactoryForTU.createOkRetour();
    final GetRessourceAggrege getRessourceAggregeP2P = new GetRessourceAggrege(RetourConverter.convertToJsonRetour(retour), ressourceAggregeP2P);
    final String partnerResponse = this.serializeWithMoshi(getRessourceAggregeP2P, GetRessourceAggrege.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_ressourceReseauCompositeUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, RessourceAggrege> result = _connector.pad3101RessourceAggregeP2PLireUn(_tracabilite, typeRessourceAggrege, idRessource);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, PARAM_TYPE_RESSOURCE_AGGREGE, typeRessourceAggrege);
    checkQueryParams(queryParamsCapture, PARAM_ID_RESSOURCE, idRessource);

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertEquals(ressourceAggregeP2P, result._second);

  }

  /**
   * Test OK for the method pad3203OltLireTousFiltreNomOlt.
   *
   * {@link RESConnector#pad3203OltLireTousFiltreNomOlt(Tracabilite, ListeNomOLTRequest)}
   *
   * expect resultat:OK Reponse of List<Olt>
   *
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public void pad3203OltLireTousFiltreNomOlt_OK_001() throws Exception
  {

    List<String> list = new ArrayList<>();
    list.add("nomOlt1"); //$NON-NLS-1$
    list.add("nomOlt2"); //$NON-NLS-1$
    list.add("nomOlt3"); //$NON-NLS-1$
    ListeNomOLTRequest listoltRequest = new ListeNomOLTRequest(list);
    Set<String> nomProviderEdge = new HashSet<>();
    Olt olt = new Olt("nomOLT", "nomNR", "constructeur", "modele", "ip", "versionInterfaceEchange", "statutTechnique", nomProviderEdge); //$NON-NLS-1$//$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$
    List<Olt> listolt = new ArrayList<>();
    listolt.add(olt);
    olt = new Olt("nomOLT1", "nomNR1", "constructeur1", "modele1", "ip1", "versionInterfaceEchange1", "statutTechnique1", nomProviderEdge); //$NON-NLS-1$//$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$
    listolt.add(olt);
    Retour retour = RetourFactoryForTU.createOkRetour();
    // Retour OK

    GetListeOltResponse getlistOltResponse = new GetListeOltResponse(RetourConverter.convertToJsonRetour(retour), listolt);
    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    final String oltListResponse = RavelJsonTools.getInstance().toJson(getlistOltResponse, GetListeOltResponse.class);
    String oltList = RavelJsonTools.getInstance().toJson(listoltRequest, ListeNomOLTRequest.class);
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(oltListResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(PAD3203_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.anyObject(), EasyMock.capture(queryParamsCapture))).andReturn(response);

    _restConnectorPoolMock.returnObject(_restInstanceMock);
    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<Olt>> resultResponse = _connector.pad3203OltLireTousFiltreNomOlt(_tracabilite, listoltRequest);
    PowerMock.verifyAll();
    checkHeader(_tracabilite, headersCapture);
    Assert.assertNotNull(resultResponse);
    Assert.assertNotNull(resultResponse._first);
    Assert.assertEquals(RetourFactoryForTU.createOkRetour(), resultResponse._first);
    Assert.assertNotNull(resultResponse._second);

  }

  /**
   * Test KO for the method noeudRaccordementGererImport.
   * {@link RESConnector#noeudRaccordementGererImport(Tracabilite, ManageNoeudRaccordementRequest)} httpStatus 404
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void pad3204CreerNoeudRaccordementGererImport_KO_001() throws Exception
  {

    final ManageNoeudRaccordementRequest noeudRequest = _podam.manufacturePojoWithFullData(ManageNoeudRaccordementRequest.class);
    final Retour retourKO = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "erreur"); //$NON-NLS-1$
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retourKO));
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(basicResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(404).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_noeudRaccordementUrl), EasyMock.capture(headersCapture), EasyMock.eq(RavelJsonTools.getInstance().toJson(noeudRequest, ManageNoeudRaccordementRequest.class)), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    NoeudRaccordementService nouedService = new NoeudRaccordementService(_connector);
    JUnitTools.setInaccessibleFieldValue(_connector, "_noeudRaccordementService", nouedService); //$NON-NLS-1$
    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.noeudRaccordementGererImport(_tracabilite, noeudRequest);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, PARAM_ACTION, "GererImport"); //$NON-NLS-1$

    //check result
    Assert.assertEquals(retourKO, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test OK for the method noeudRaccordementGererImport.
   * {@link RESConnector#noeudRaccordementGererImport(Tracabilite, ManageNoeudRaccordementRequest)} httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void pad3204CreerNoeudRaccordementGererImport_OK_001() throws Exception
  {

    final ManageNoeudRaccordementRequest noeudRequest = _podam.manufacturePojoWithFullData(ManageNoeudRaccordementRequest.class);
    final Retour retourOK = RetourFactoryForTU.createOkRetour();
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retourOK));
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(basicResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_noeudRaccordementUrl), EasyMock.capture(headersCapture), EasyMock.eq(RavelJsonTools.getInstance().toJson(noeudRequest, ManageNoeudRaccordementRequest.class)), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    NoeudRaccordementService nouedService = new NoeudRaccordementService(_connector);
    JUnitTools.setInaccessibleFieldValue(_connector, "_noeudRaccordementService", nouedService); //$NON-NLS-1$
    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.noeudRaccordementGererImport(_tracabilite, noeudRequest);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, PARAM_ACTION, "GererImport"); //$NON-NLS-1$

    //check result
    Assert.assertEquals(retourOK, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test KO for the method noeudRaccordementGererSuppressionNrNonReference.
   * {@link RESConnector#noeudRaccordementGererSuppressionNrNonReference(Tracabilite, Set)} (Tracabilite,
   * ManageNoeudRaccordementRequest)} httpStatus 404
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void pad3204CreerNoeudRaccordementGererSuppression_KO_001() throws Exception
  {
    final ManageNoeudRaccordementRequest noeudRequest = new ManageNoeudRaccordementRequest(Collections.singleton("id1")); //$NON-NLS-1$
    final Retour retourKO = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "erreur"); //$NON-NLS-1$
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retourKO));
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(basicResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(404).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_noeudRaccordementUrl), EasyMock.capture(headersCapture), EasyMock.eq(RavelJsonTools.getInstance().toJson(noeudRequest, ManageNoeudRaccordementRequest.class)), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    NoeudRaccordementService nouedService = new NoeudRaccordementService(_connector);
    JUnitTools.setInaccessibleFieldValue(_connector, "_noeudRaccordementService", nouedService); //$NON-NLS-1$
    PowerMock.replayAll();
    final ConnectorResponse<Retour, Set<CompteRenduSuppression>> result = _connector.noeudRaccordementGererSuppressionNrNonReference(_tracabilite, Collections.singleton("id1")); //$NON-NLS-1$
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, PARAM_ACTION, "GererSuppressionNrNonReference"); //$NON-NLS-1$

    //check result
    Assert.assertEquals(retourKO, result._first);
  }

  /**
   * Test OK for the method noeudRaccordementGererSuppressionNrNonReference.
   * {@link RESConnector#noeudRaccordementGererSuppressionNrNonReference(Tracabilite, Set)} (Tracabilite,
   * ManageNoeudRaccordementRequest)} httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void pad3204CreerNoeudRaccordementGererSuppression_OK_001() throws Exception
  {
    final ManageNoeudRaccordementRequest noeudRequest = new ManageNoeudRaccordementRequest(Collections.singleton("id1")); //$NON-NLS-1$
    final Retour retourOK = RetourFactoryForTU.createOkRetour();
    Set<CompteRenduSuppression> lisCompteRendu = new HashSet<CompteRenduSuppression>();
    CompteRenduSuppression compteRendu = new CompteRenduSuppression("NR3", "OK"); //$NON-NLS-1$//$NON-NLS-2$
    lisCompteRendu.add(compteRendu);
    compteRendu = new CompteRenduSuppression("NR8", "OK"); //$NON-NLS-1$//$NON-NLS-2$
    lisCompteRendu.add(compteRendu);
    NoeudRaccordementResponse listResponse = new NoeudRaccordementResponse(RetourConverter.convertToJsonRetour(retourOK), lisCompteRendu);
    final String partnerResponse = RavelJsonTools.getInstance().toJson(listResponse, NoeudRaccordementResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_noeudRaccordementUrl), EasyMock.capture(headersCapture), EasyMock.eq(RavelJsonTools.getInstance().toJson(noeudRequest, ManageNoeudRaccordementRequest.class)), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    NoeudRaccordementService nouedService = new NoeudRaccordementService(_connector);
    JUnitTools.setInaccessibleFieldValue(_connector, "_noeudRaccordementService", nouedService); //$NON-NLS-1$
    PowerMock.replayAll();
    final ConnectorResponse<Retour, Set<CompteRenduSuppression>> result = _connector.noeudRaccordementGererSuppressionNrNonReference(_tracabilite, Collections.singleton("id1")); //$NON-NLS-1$
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, PARAM_ACTION, "GererSuppressionNrNonReference"); //$NON-NLS-1$

    //check result
    Assert.assertEquals(retourOK, result._first);
    Assert.assertEquals(result._second.size(), 2);
  }

  /**
   * Test KO for the method
   * {@link RESConnector#structureVerticaleFtthCompositeCreer(Tracabilite, StructureVerticaleFtthComposite)} httpStatus
   * 200, with retourKO
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void structureVerticaleFtthCompositeCreer_Test_KO_001() throws Exception
  {
    final StructureVerticaleFtthComposite structureVerticale = _podam.manufacturePojo(StructureVerticaleFtthComposite.class);
    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT1, IMegSpiritConsts.DONNEE_INDISPONIBLE, StringConstants.EMPTY_STRING, null);
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = RavelJsonTools.getInstance().toJson(basicResponse, BasicResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();

    // construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(_structureVerticaleFtthCompositeUrl), EasyMock.capture(headersCapture), EasyMock.eq(RavelJsonTools.getInstance().toJson(structureVerticale, StructureVerticaleFtthComposite.class)), EasyMock.isNull())).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.structureVerticaleFtthCompositeCreer(_tracabilite, structureVerticale);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test KO for the method
   * {@link RESConnector#structureVerticaleFtthCompositeCreer(Tracabilite, StructureVerticaleFtthComposite)} httpStatus
   * 200, jsonResponse null (throws RavelException)
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void structureVerticaleFtthCompositeCreer_Test_KO_002() throws Exception
  {

    final StructureVerticaleFtthComposite structureVerticale = _podam.manufacturePojo(StructureVerticaleFtthComposite.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();

    // construct response
    final Response response = new ResponseBuilderImpl().status(200).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(_structureVerticaleFtthCompositeUrl), EasyMock.capture(headersCapture), EasyMock.eq(RavelJsonTools.getInstance().toJson(structureVerticale, StructureVerticaleFtthComposite.class)), EasyMock.isNull())).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    ConnectorResponse<Retour, Nothing> result = null;

    PowerMock.replayAll();
    result = _connector.structureVerticaleFtthCompositeCreer(_tracabilite, structureVerticale);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, JSON_ERROR_MESSAGE, null);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test KO for the method
   * {@link RESConnector#structureVerticaleFtthCompositeCreer(Tracabilite, StructureVerticaleFtthComposite)} httpStatus
   * 500, jsonResponse null (throws RavelException)
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void structureVerticaleFtthCompositeCreer_Test_KO_003() throws Exception
  {

    final StructureVerticaleFtthComposite structureVerticale = _podam.manufacturePojo(StructureVerticaleFtthComposite.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();

    // construct response
    final Response response = new ResponseBuilderImpl().status(500).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(_structureVerticaleFtthCompositeUrl), EasyMock.capture(headersCapture), EasyMock.eq(RavelJsonTools.getInstance().toJson(structureVerticale, StructureVerticaleFtthComposite.class)), EasyMock.isNull())).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    ConnectorResponse<Retour, Nothing> result = null;

    PowerMock.replayAll();
    result = _connector.structureVerticaleFtthCompositeCreer(_tracabilite, structureVerticale);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, JSON_ERROR_MESSAGE, null);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test OK for the method
   * {@link RESConnector#structureVerticaleFtthCompositeCreer(Tracabilite, StructureVerticaleFtthComposite)} with
   * httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void structureVerticaleFtthCompositeCreer_Test_OK_001() throws Exception
  {

    final StructureVerticaleFtthComposite structureVerticale = _podam.manufacturePojo(StructureVerticaleFtthComposite.class);
    final Retour retour = RetourFactoryForTU.createOkRetour();
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = RavelJsonTools.getInstance().toJson(basicResponse, BasicResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();

    // construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(_structureVerticaleFtthCompositeUrl), EasyMock.capture(headersCapture), EasyMock.eq(RavelJsonTools.getInstance().toJson(structureVerticale, StructureVerticaleFtthComposite.class)), EasyMock.isNull())).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.structureVerticaleFtthCompositeCreer(_tracabilite, structureVerticale);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    Assert.assertEquals(retour, result._first);
  }

  /**
   * Test the method
   * {@link RESConnector#structureVerticaleFtthCompositeLireTousParListeOIIMB(Tracabilite, ListeCoupleImbOiRequest)}
   * httpStatus 200 Retour KO with "lecture indisponible"
   *
   * Expected : Retour KO, CAT-1, LECTURE_INDISPONIBLE, "Unexpected error in res database connector: Test Error"
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void structureVerticaleFtthCompositeLireTousParListeOIIMB_Test_KO_001() throws Exception
  {

    List<CoupleImbOi> coupleImbOiList = new ArrayList<>();
    coupleImbOiList.add(new CoupleImbOi(RandomStringUtils.randomAlphanumeric(10), RandomStringUtils.randomAlphanumeric(10)));
    ListeCoupleImbOiRequest listeCoupleImbOiRequest = new ListeCoupleImbOiRequest(coupleImbOiList);

    final String message = MessageFormat.format(Messages.getString("res.unexpectedError"), "Test Error"); //$NON-NLS-1$ //$NON-NLS-2$
    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT1, IMegSpiritConsts.LECTURE_INDISPONIBLE, message, null);
    final GetCouvertureFtthResponse getCouvertureFtthResponse = new GetCouvertureFtthResponse(RetourConverter.convertToJsonRetour(retour), null);
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(getCouvertureFtthResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(PAD3012_RECHERCHE_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.anyObject(), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, StructureVerticaleFtthComposite> result = _connector.structureVerticaleFtthCompositeLireTousParListeOIIMB(_tracabilite, listeCoupleImbOiRequest);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method
   * {@link RESConnector#structureVerticaleFtthCompositeLireTousParListeOIIMB(Tracabilite, ListeCoupleImbOiRequest)}
   * httpStatus 200 jsonResponse null (throws RavelException)
   *
   * Expected : null JsonResponse - Retour KO, CAT-10, TRAITEMENT_ARRETE, "Impossible de récupérer la réponse"
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void structureVerticaleFtthCompositeLireTousParListeOIIMB_Test_KO_002() throws Exception
  {

    List<CoupleImbOi> coupleImbOiList = new ArrayList<>();
    coupleImbOiList.add(new CoupleImbOi(RandomStringUtils.randomAlphanumeric(10), RandomStringUtils.randomAlphanumeric(10)));
    ListeCoupleImbOiRequest listeCoupleImbOiRequest = new ListeCoupleImbOiRequest(coupleImbOiList);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(PAD3012_RECHERCHE_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.anyObject(), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    // Call connector
    PowerMock.replayAll();
    final ConnectorResponse<Retour, StructureVerticaleFtthComposite> result = _connector.structureVerticaleFtthCompositeLireTousParListeOIIMB(_tracabilite, listeCoupleImbOiRequest);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, JSON_ERROR_MESSAGE, null);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test OK for the method
   * {@link RESConnector#structureVerticaleFtthCompositeLireTousParListeOIIMB(Tracabilite, ListeCoupleImbOiRequest)}
   * httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void structureVerticaleFtthCompositeLireTousParListeOIIMB_Test_OK_001() throws Exception
  {

    List<CoupleImbOi> coupleImbOiList = new ArrayList<>();
    coupleImbOiList.add(new CoupleImbOi(RandomStringUtils.randomAlphanumeric(10), RandomStringUtils.randomAlphanumeric(10)));
    ListeCoupleImbOiRequest listeCoupleImbOiRequest = new ListeCoupleImbOiRequest(coupleImbOiList);

    SVImmeubleFtth svImmeuble = new SVImmeubleFtth("imb", "oi", null, null); //$NON-NLS-1$ //$NON-NLS-2$
    List<SVImmeubleFtth> listeSvImmeubleFtth = new ArrayList<>();
    listeSvImmeubleFtth.add(svImmeuble);
    StructureVerticaleFtthComposite structureVerticale = new StructureVerticaleFtthComposite(listeSvImmeubleFtth);

    final Retour retour = RetourFactoryForTU.createOkRetour();
    final GetStructureVerticaleFtthCompositeResponse getStructureVerticaleFtthCompositeResponse = new GetStructureVerticaleFtthCompositeResponse(RetourConverter.convertToJsonRetour(retour), structureVerticale);

    final String partnerResponse = RavelJsonTools.getInstance().toJson(getStructureVerticaleFtthCompositeResponse, GetStructureVerticaleFtthCompositeResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(PAD3012_RECHERCHE_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.anyObject(), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, StructureVerticaleFtthComposite> result = _connector.structureVerticaleFtthCompositeLireTousParListeOIIMB(_tracabilite, listeCoupleImbOiRequest);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertEquals(structureVerticale, result._second);
  }

  /**
   * @throws Exception
   *           Exception
   */
  @Test
  public void test_loadConnectorConfiguration() throws Exception
  {
    final Connector connector = new Connector();

    Param param = new Param();
    param.setName("COMMUNE_PATH"); //$NON-NLS-1$
    param.setValue(_communeUrl);
    connector.getParam().add(param);

    param = new Param();
    param.setName("PREVISION_PROG_PATH"); //$NON-NLS-1$
    param.setValue(_previsionProgUrl);
    connector.getParam().add(param);
    connector.setURLS(generateURLS());

    param = new Param();
    param.setName("INTEGRATION_GROUPE_FICHIER_PATH"); //$NON-NLS-1$
    param.setValue(_integrationGroupFileUrl);
    connector.getParam().add(param);
    connector.setURLS(generateURLS());

    param = new Param();
    param.setName("RESSOURCE_PATH"); //$NON-NLS-1$
    param.setValue(_ressourceUrl);
    connector.getParam().add(param);
    connector.setURLS(generateURLS());

    param = new Param();
    param.setName("RESSOURCE_RACCORDEMENT_PATH"); //$NON-NLS-1$
    param.setValue(_ressourceRaccordementUrl);
    connector.getParam().add(param);
    connector.setURLS(generateURLS());

    param = new Param();
    param.setName("RESSOURCE_RACCORDEMENT_COMPOSITE_PATH"); //$NON-NLS-1$
    param.setValue(_ressourceRaccordementCompositeUrl);
    connector.getParam().add(param);
    connector.setURLS(generateURLS());

    param = new Param();
    param.setName("RESSOURCE_ADRESSE_IP_CLF_PATH"); //$NON-NLS-1$
    param.setValue(_ressourceAdresseIpClfUrl);
    connector.getParam().add(param);
    connector.setURLS(generateURLS());

    param = new Param();
    param.setName("ALLOCATION_SESSION_FQDN_PATH"); //$NON-NLS-1$
    param.setValue(_allocationSessionFqdnUrl);
    connector.getParam().add(param);
    connector.setURLS(generateURLS());

    param = new Param();
    param.setName("RESSOURCE_IMPI_FIXE_PATH"); //$NON-NLS-1$
    param.setValue(_ressourceImpiFixeUrl);
    connector.getParam().add(param);
    connector.setURLS(generateURLS());

    param = new Param();
    param.setName("RESSOURCE_COMPTE_IMS_PATH"); //$NON-NLS-1$
    param.setValue(_ressourceCompteImsUrl);
    connector.getParam().add(param);
    connector.setURLS(generateURLS());

    param = new Param();
    param.setName("RESSOURCE_MOTDEPASSE_IMS_PATH"); //$NON-NLS-1$
    param.setValue(_ressourceMotDePasseImsUrl);
    connector.getParam().add(param);
    connector.setURLS(generateURLS());

    param = new Param();
    param.setName("RESSOURCE_COMPTE_MAIL_PATH"); //$NON-NLS-1$
    param.setValue(_ressourceCompteMailUrl);
    connector.getParam().add(param);
    connector.setURLS(generateURLS());

    param = new Param();
    param.setName("ACCES_TECHNIQUE_PATH"); //$NON-NLS-1$
    param.setValue(_accesTechniqueUrl);
    connector.getParam().add(param);

    param = new Param();
    param.setName("GESTION_REFERENTIEL_PATH"); //$NON-NLS-1$
    param.setValue(_gestionReferentielUrl);
    connector.getParam().add(param);

    param = new Param();
    param.setName("FICHIER_REFERENTIEL_COMPOSITE_PATH"); //$NON-NLS-1$
    param.setValue(_fichierReferentielCompositeUrl);
    connector.getParam().add(param);

    param = new Param();
    param.setName("COUVERTURE_CUIVRE_PATH"); //$NON-NLS-1$
    param.setValue(_couvertureCuivreUrl);
    connector.getParam().add(param);

    param = new Param();
    param.setName("COUVERTURE_FTTO_PATH"); //$NON-NLS-1$
    param.setValue(_couvertureFttoUrl);
    connector.getParam().add(param);

    param = new Param();
    param.setName("COUVERTURE_TOKYO_PATH"); //$NON-NLS-1$
    param.setValue(_couvertureTokyoUrl);
    connector.getParam().add(param);

    param = new Param();
    param.setName("CREATE_LONG_createLongTimeout"); //$NON-NLS-1$
    param.setValue(_createLongTimeout.toString());
    connector.getParam().add(param);

    param = new Param();
    param.setName("RESSOURCE_PORT_P2P_PATH"); //$NON-NLS-1$
    param.setValue(_ressourcePortP2PUrl);
    connector.getParam().add(param);

    param = new Param();
    param.setName("FQDN_PATH"); //$NON-NLS-1$
    param.setValue(_fqdnUrl);
    connector.getParam().add(param);

    param = new Param();
    param.setName("PAD3012_PATH_PARAM"); //$NON-NLS-1$
    param.setValue(_structureVerticaleFtthCompositeUrl);
    connector.getParam().add(param);

    param = new Param();
    param.setName("PAD3012_RECHERCHE_PATH_PARAM"); //$NON-NLS-1$
    param.setValue(_structureVerticaleFtthCompositeRechercheUrl);
    connector.getParam().add(param);

    param = new Param();
    param.setName("AccesTechniqueCacheDuration"); //$NON-NLS-1$
    param.setValue("PT10M"); //$NON-NLS-1$
    connector.getParam().add(param);

    param = new Param();
    param.setName("AbaqueDSLCacheDuration"); //$NON-NLS-1$
    param.setValue("PT10M"); //$NON-NLS-1$
    connector.getParam().add(param);

    connector.setURLS(generateURLS());

    // test
    _connector.loadConnectorConfiguration(connector);

    // assertions
    Assert.assertEquals(_communeUrl, JUnitTools.getInaccessibleFieldValue(_connector, "_communeUrl")); //$NON-NLS-1$
    Assert.assertEquals(_previsionProgUrl, JUnitTools.getInaccessibleFieldValue(_connector, "_previsionProgUrl")); //$NON-NLS-1$
    Assert.assertEquals(_integrationGroupFileUrl, JUnitTools.getInaccessibleFieldValue(_connector, "_integrationGroupFileUrl")); //$NON-NLS-1$
    Assert.assertEquals(_createLongTimeout, JUnitTools.getInaccessibleFieldValue(_connector, "_createLongTimeout")); //$NON-NLS-1$
    Assert.assertEquals(_accesTechniqueUrl, JUnitTools.getInaccessibleFieldValue(_connector, "_accesTechniqueUrl")); //$NON-NLS-1$
    Assert.assertEquals(_couvertureCuivreUrl, JUnitTools.getInaccessibleFieldValue(_connector, "_couvertureCuivreUrl")); //$NON-NLS-1$
    Assert.assertEquals(_couvertureFttoUrl, JUnitTools.getInaccessibleFieldValue(_connector, "_couvertureFttoUrl")); //$NON-NLS-1$
    Assert.assertEquals(_couvertureTokyoUrl, JUnitTools.getInaccessibleFieldValue(_connector, "_couvertureTokyoUrl")); //$NON-NLS-1$
    Assert.assertEquals(_fichierReferentielCompositeUrl, JUnitTools.getInaccessibleFieldValue(_connector, "_fichierReferentielCompositeUrl")); //$NON-NLS-1$
    Assert.assertEquals(_gestionReferentielUrl, JUnitTools.getInaccessibleFieldValue(_connector, "_gestionReferentielUrl")); //$NON-NLS-1$
    Assert.assertEquals(_ressourcePortP2PUrl, JUnitTools.getInaccessibleFieldValue(_connector, "_ressourcePortP2PUrl")); //$NON-NLS-1$
    Assert.assertEquals(_fqdnUrl, JUnitTools.getInaccessibleFieldValue(_connector, "_fqdnUrl")); //$NON-NLS-1$
    Assert.assertEquals(_structureVerticaleFtthCompositeUrl, JUnitTools.getInaccessibleFieldValue(_connector, "_structureVerticaleFtthCompositeUrl")); //$NON-NLS-1$
    Assert.assertEquals(_structureVerticaleFtthCompositeRechercheUrl, JUnitTools.getInaccessibleFieldValue(_connector, "_structureVerticaleFtthCompositeRechercheUrl")); //$NON-NLS-1$
    Assert.assertEquals(_accesTechniqueCacheDuration, JUnitTools.getInaccessibleFieldValue(_connector, "_accesTechniqueCacheDuration")); //$NON-NLS-1$
    Assert.assertEquals(_abaqueDslCacheDuration, JUnitTools.getInaccessibleFieldValue(_connector, "_abaqueDslCacheDuration")); //$NON-NLS-1$
  }

  /**
   * Nominal IntrgrationFichier create
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public void testFichierCreate001() throws Exception
  {

    String json = "{\r\n\t\"integrationGroupeFichier\": {\r\n\t\t\"nomGroupeFichier\": \"ELIG PREV\",\r\n\t\t\"dateIntegration\": \"2017-09-15T12:25:33.000+0200\",\r\n\t\t\"cheminRepertoireArchive\": \"F:\\\\Backups\\\\MesFichiers\\\\Archives\",\r\n\t\t\"listeFichierIntegre\": [\r\n\t\t\t{\t\"idFichier\": \"COMMUNES\",\r\n\t\t\t\t\"date\": \"2017-09-15T12:25:33.000+0200\",\r\n\t\t\t\t\"index\": 12,\r\n\t\t\t\t\"nbLigne\": 37256,\r\n\t\t\t\t\"nbLigneOK\": 37205\r\n},\r\n\t\t\t{\t\"idFichier\": \"COMMUNES_NOMS_ALT\",\r\n\t\t\t\t\"date\": \"2017-09-15T12:25:33.000+0200\",\r\n\t\t\t\t\"index\": 12,\r\n\t\t\t\t\"nbLigne\": 18692,\r\n\t\t\t\t\"nbLigneOK\": 18692\r\n\t\t\t},\r\n\t\t\t{\t\"idFichier\": \"PREV_FTTH\",\r\n\t\t\t\t\"date\": \"2017-09-15T12:25:33.000+0200\",\r\n\t\t\t\t\"index\": 12,\r\n\t\t\t\t\"nbLigne\": 12892,\r\n\t\t\t\t\"nbLigneOK\": 12892\r\n\t\t\t},\r\n\t\t\t{\t\"idFichier\": \"PREV_CROZON\",\r\n\t\t\t\t\"date\": \"2017-09-15T12:25:33.000+0200\",\r\n\t\t\t\t\"index\": 12,\r\n\t\t\t\t\"nbLigne\": 25120,\r\n\t\t\t\t\"nbLigneOK\": 24358\r\n\t\t\t},\r\n\t\t]\r\n\t}\r\n}\r\n"; //$NON-NLS-1$
    String result = "{\r\n\t\"retour\": {\r\n\t\t\"resultat\": \"OK\"\r\n\t}\r\n}\r\n"; //$NON-NLS-1$
    IntegrationGroupeFichierRequest request = GsonTools.getIso8601Ms().fromJson(json, IntegrationGroupeFichierRequest.class);
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(result.getBytes())).build();
    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    // test scenario
    String jsonRequestString = GsonTools.getIso8601Ms().toJson(request);
    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);

    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(PAD3003_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.eq(jsonRequestString), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);
    PowerMock.replayAll();
    final ConnectorResponse<Retour, Boolean> resultResponse = _connector.pad3003IntegrationGroupeFichierCreate(_tracabilite, request);
    PowerMock.verifyAll();
    checkHeader(_tracabilite, headersCapture);
    checkQueryParams(queryParamsCapture, (String[]) null);

    Assert.assertNull(queryParamsCapture.getValue());
    Assert.assertNotNull(resultResponse);
    Assert.assertNotNull(resultResponse._first);
    Assert.assertEquals(RetourFactoryForTU.createOkRetour(), resultResponse._first);

  }

  /**
   * Retour KO request
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public void testFichierCreate002() throws Exception
  {

    String json = "{\r\n\t\"integrationGroupeFichier\": {\r\n\t\t\"nomGroupeFichier\": \"ELIG PREV\",\r\n\t\t\"dateIntegration\": \"2017-09-15T12:25:33.000+0200\",\r\n\t\t\"cheminRepertoireArchive\": \"F:\\\\Backups\\\\MesFichiers\\\\Archives\",\r\n\t\t\"listeFichierIntegre\": [\r\n\t\t\t{\t\"idFichier\": \"COMMUNES\",\r\n\t\t\t\t\"date\": \"2017-09-15T12:25:33.000+0200\",\r\n\t\t\t\t\"index\": 12,\r\n\t\t\t\t\"nbLigne\": 37256,\r\n\t\t\t\t\"nbLigneOK\": 37205\r\n},\r\n\t\t\t{\t\"idFichier\": \"COMMUNES_NOMS_ALT\",\r\n\t\t\t\t\"date\": \"2017-09-15T12:25:33.000+0200\",\r\n\t\t\t\t\"index\": 12,\r\n\t\t\t\t\"nbLigne\": 18692,\r\n\t\t\t\t\"nbLigneOK\": 18692\r\n\t\t\t},\r\n\t\t\t{\t\"idFichier\": \"PREV_FTTH\",\r\n\t\t\t\t\"date\": \"2017-09-15T12:25:33.000+0200\",\r\n\t\t\t\t\"index\": 12,\r\n\t\t\t\t\"nbLigne\": 12892,\r\n\t\t\t\t\"nbLigneOK\": 12892\r\n\t\t\t},\r\n\t\t\t{\t\"idFichier\": \"PREV_CROZON\",\r\n\t\t\t\t\"date\": \"2017-09-15T12:25:33.000+0200\",\r\n\t\t\t\t\"index\": 12,\r\n\t\t\t\t\"nbLigne\": 25120,\r\n\t\t\t\t\"nbLigneOK\": 24358\r\n\t\t\t},\r\n\t\t]\r\n\t}\r\n}\r\n"; //$NON-NLS-1$
    String result = "{\r\n\t\"retour\": {\r\n\t\t\"resultat\": \"NOK\",\r\n\t\t\"categorie\": \"CAT-4\",\r\n\t\t\"diagnostic\": \"DONNEE_INVALIDE\",\r\n\t\t\"libelle\": \"Nom du groupe de fichiers ELIGXYZ invalide\"\r\n\t}\r\n}\r\n"; //$NON-NLS-1$
    IntegrationGroupeFichierRequest request = GsonTools.getIso8601Ms().fromJson(json, IntegrationGroupeFichierRequest.class);
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(result.getBytes())).build();
    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    // test scenario
    String jsonRequestString = GsonTools.getIso8601Ms().toJson(request);
    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);

    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(PAD3003_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.eq(jsonRequestString), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);
    PowerMock.replayAll();
    final ConnectorResponse<Retour, Boolean> resultResponse = _connector.pad3003IntegrationGroupeFichierCreate(_tracabilite, request);
    PowerMock.verifyAll();

    checkHeader(_tracabilite, headersCapture);
    checkQueryParams(queryParamsCapture, (String[]) null);

    Assert.assertNotNull(resultResponse);
    Assert.assertNotNull(resultResponse._first);
    Assert.assertEquals("NOK", resultResponse._first.getResultat()); //$NON-NLS-1$
    Assert.assertEquals("CAT-4", resultResponse._first.getCategorie()); //$NON-NLS-1$
    Assert.assertEquals("DONNEE_INVALIDE", resultResponse._first.getDiagnostic()); //$NON-NLS-1$
    Assert.assertEquals("Nom du groupe de fichiers ELIGXYZ invalide", resultResponse._first.getLibelle()); //$NON-NLS-1$
    Assert.assertEquals(false, resultResponse._second);

  }

  /**
   * @throws Exception
   *           Exception
   */
  @Test
  public void testFichierCreate003() throws Exception
  {

    String json = "{\r\n\t\"integrationGroupeFichier\": {\r\n\t\t\"nomGroupeFichier\": \"ELIG PREV\",\r\n\t\t\"dateIntegration\": \"2017-09-15T12:25:33.000+0200\",\r\n\t\t\"cheminRepertoireArchive\": \"F:\\\\Backups\\\\MesFichiers\\\\Archives\",\r\n\t\t\"listeFichierIntegre\": [\r\n\t\t\t{\t\"idFichier\": \"COMMUNES\",\r\n\t\t\t\t\"date\": \"2017-09-15T12:25:33.000+0200\",\r\n\t\t\t\t\"index\": 12,\r\n\t\t\t\t\"nbLigne\": 37256,\r\n\t\t\t\t\"nbLigneOK\": 37205\r\n},\r\n\t\t\t{\t\"idFichier\": \"COMMUNES_NOMS_ALT\",\r\n\t\t\t\t\"date\": \"2017-09-15T12:25:33.000+0200\",\r\n\t\t\t\t\"index\": 12,\r\n\t\t\t\t\"nbLigne\": 18692,\r\n\t\t\t\t\"nbLigneOK\": 18692\r\n\t\t\t},\r\n\t\t\t{\t\"idFichier\": \"PREV_FTTH\",\r\n\t\t\t\t\"date\": \"2017-09-15T12:25:33.000+0200\",\r\n\t\t\t\t\"index\": 12,\r\n\t\t\t\t\"nbLigne\": 12892,\r\n\t\t\t\t\"nbLigneOK\": 12892\r\n\t\t\t},\r\n\t\t\t{\t\"idFichier\": \"PREV_CROZON\",\r\n\t\t\t\t\"date\": \"2017-09-15T12:25:33.000+0200\",\r\n\t\t\t\t\"index\": 12,\r\n\t\t\t\t\"nbLigne\": 25120,\r\n\t\t\t\t\"nbLigneOK\": 24358\r\n\t\t\t},\r\n\t\t]\r\n\t}\r\n}\r\n"; //$NON-NLS-1$
    IntegrationGroupeFichierRequest request = GsonTools.getIso8601Ms().fromJson(json, IntegrationGroupeFichierRequest.class);
    String jsonRequestString = GsonTools.getIso8601Ms().toJson(request);
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream("".getBytes())).build(); //$NON-NLS-1$
    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);

    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(PAD3003_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.eq(jsonRequestString), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);
    PowerMock.replayAll();
    try
    {
      _connector.pad3003IntegrationGroupeFichierCreate(_tracabilite, request);
    }
    catch (RavelException e)
    {
      Assert.assertEquals(ExceptionType.UNEXPECTED, e.getExceptionType());
      Assert.assertEquals(ErrorCode.CNCTOR_00010, e.getErrorCode());
      Assert.assertEquals("Impossible de récupérer la réponse", e.getMessage()); //$NON-NLS-1$
    }
  }

  /**
   * Nominal IntrgrationFichier delete
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public void testFichierDelete001() throws Exception
  {

    String result = "{\r\n\t\"retour\": {\r\n\t\t\"resultat\": \"OK\"\r\n\t}\r\n}\r\n"; //$NON-NLS-1$
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(result.getBytes())).build();
    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();
    Capture<String> bodyCapture = Capture.newInstance();

    // test scenario

    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);

    EasyMock.expect(_restInstanceMock.delete(EasyMock.eq(PAD3003_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.capture(bodyCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);
    PowerMock.replayAll();
    final ConnectorResponse<Retour, Boolean> resultResponse = _connector.pad3003IntegrationGroupeFichierDelete(_tracabilite, "ELIG%20PREV", "EFFACER_REFERENTIEL_SECONDAIRE"); //$NON-NLS-1$ //$NON-NLS-2$
    PowerMock.verifyAll();
    checkHeader(_tracabilite, headersCapture);
    checkQueryParams(queryParamsCapture, "nomGroupeFichier", "ELIG%20PREV", "action", "EFFACER_REFERENTIEL_SECONDAIRE"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$

    Assert.assertNotNull(queryParamsCapture.getValue());
    Assert.assertEquals("ELIG%20PREV", queryParamsCapture.getValue().get("nomGroupeFichier")); //$NON-NLS-1$//$NON-NLS-2$
    Assert.assertNotNull(resultResponse);
    Assert.assertNotNull(resultResponse._first);
    Assert.assertEquals(RetourFactoryForTU.createOkRetour(), resultResponse._first);

  }

  /**
   * Retour KO request
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public void testFichierDelete002() throws Exception
  {

    String result = "{\r\n\t\"retour\": {\r\n\t\t\"resultat\": \"NOK\",\r\n\t\t\"categorie\": \"CAT-4\",\r\n\t\t\"diagnostic\": \"DONNEE_INVALIDE\",\r\n\t\t\"libelle\": \"Nom du groupe de fichiers ELIGXYZ invalide\"\r\n\t}\r\n}\r\n"; //$NON-NLS-1$
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(result.getBytes())).build();
    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();
    Capture<String> bodyCapture = Capture.newInstance();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);

    EasyMock.expect(_restInstanceMock.delete(EasyMock.eq(PAD3003_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.capture(bodyCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);
    PowerMock.replayAll();
    final ConnectorResponse<Retour, Boolean> resultResponse = _connector.pad3003IntegrationGroupeFichierDelete(_tracabilite, "ELIG%20PREV", "EFFACER_REFERENTIEL_SECONDAIRE"); //$NON-NLS-1$ //$NON-NLS-2$
    PowerMock.verifyAll();

    checkHeader(_tracabilite, headersCapture);
    checkQueryParams(queryParamsCapture, "nomGroupeFichier", "ELIG%20PREV", "action", "EFFACER_REFERENTIEL_SECONDAIRE"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$

    Assert.assertNotNull(resultResponse);
    Assert.assertNotNull(resultResponse._first);
    Assert.assertEquals("NOK", resultResponse._first.getResultat()); //$NON-NLS-1$
    Assert.assertEquals("CAT-4", resultResponse._first.getCategorie()); //$NON-NLS-1$
    Assert.assertEquals("DONNEE_INVALIDE", resultResponse._first.getDiagnostic()); //$NON-NLS-1$
    Assert.assertEquals("Nom du groupe de fichiers ELIGXYZ invalide", resultResponse._first.getLibelle()); //$NON-NLS-1$
    Assert.assertEquals(false, resultResponse._second);

  }

  /**
   * @throws Exception
   *           Exception
   */
  @Test
  public void testFichierDelete003() throws Exception
  {

    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream("".getBytes())).build(); //$NON-NLS-1$
    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();
    Capture<String> bodyCapture = Capture.newInstance();

    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);

    EasyMock.expect(_restInstanceMock.delete(EasyMock.eq(PAD3003_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.capture(bodyCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);
    PowerMock.replayAll();
    try
    {
      _connector.pad3003IntegrationGroupeFichierDelete(_tracabilite, "ELIG%20PREV", "EFFACER_REFERENTIEL_SECONDAIRE"); //$NON-NLS-1$//$NON-NLS-2$
    }
    catch (RavelException e)
    {
      checkQueryParams(queryParamsCapture, "nomGroupeFichier", "ELIG%20PREV", "action", "EFFACER_REFERENTIEL_SECONDAIRE"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$

      Assert.assertEquals(ExceptionType.UNEXPECTED, e.getExceptionType());
      Assert.assertEquals(ErrorCode.CNCTOR_00010, e.getErrorCode());
      Assert.assertEquals("Impossible de récupérer la réponse", e.getMessage()); //$NON-NLS-1$
    }
  }

  /**
   * Nominal
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public void testFichierRead001() throws Exception
  {

    String result = "{\r\n\t\"retour\": {\r\n\t\t\"resultat\": \"OK\"\r\n\t},\r\n\t\"integrationGroupeFichier\": { \t\r\n\t\t\"nomGroupeFichier\": \"ELIG PREV\",\r\n\t\t\"dateIntegration\": \"2017-09-15T12:25:33.000+0200\",\r\n\t\t\"cheminRepertoireArchive\": \"F:\\\\Backups\\\\MesFichiers\\\\Archives\",\r\n\t\t\"listeFichierIntegre\": [\r\n\t\t\t{\t\"idFichier\": \"COMMUNES\",\r\n\t\t\t\t\"date\": \"2017-09-15T12:25:33.000+0200\",\r\n\t\t\t\t\"index\": 12,\r\n\t\t\t\t\"nbLigne\": 37256,\r\n\t\t\t\t\"nbLigneOK\": 37205\r\n\t\t\t},\r\n\t\t\t{\t\"idFichier\": \"COMMUNES_NOMS_ALT\",\r\n\t\t\t\t\"date\": \"2017-09-15T12:25:33.000+0200\",\r\n\t\t\t\t\"index\": 12,\r\n\t\t\t\t\"nbLigne\": 18692,\r\n\t\t\t\t\"nbLigneOK\": 18692\r\n},\r\n\t\t\t{\t\"idFichier\": \"PREV_FTTH\",\r\n\t\t\t\t\"date\": \"2017-09-15T12:25:33.000+0200\",\r\n\t\t\t\t\"index\": 12,\r\n\t\t\t\t\"nbLigne\": 12892,\r\n\t\t\t\t\"nbLigneOK\": 12892\r\n\t\t\t},\r\n\t\t\t{\t\"idFichier\": \"PREV_CROZON\",\r\n\t\t\t\t\"date\": \"2017-09-15T12:25:33.000+0200\",\r\n\t\t\t\t\"index\": 12,\r\n\t\t\t\t\"nbLigne\": 25120,\r\n\t\t\t\t\"nbLigneOK\": 24358\r\n\t\t\t},\r\n\t\t]\r\n\t}\r\n}\r\n"; //$NON-NLS-1$
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(result.getBytes())).build();
    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);

    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(PAD3003_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);
    PowerMock.replayAll();
    final ConnectorResponse<Retour, IntegrationGroupeFichierResponse> resultResponse = _connector.pad3003IntegrationGroupeFichierRead(_tracabilite, "ELIG%20PREV"); //$NON-NLS-1$
    PowerMock.verifyAll();
    checkHeader(_tracabilite, headersCapture);
    checkQueryParams(queryParamsCapture, "nomGroupeFichier", "ELIG%20PREV"); //$NON-NLS-1$ //$NON-NLS-2$
    Assert.assertNotNull(resultResponse);
    Assert.assertNotNull(resultResponse._first);
    Assert.assertEquals(RetourFactoryForTU.createOkRetour(), resultResponse._first);
    Assert.assertNotNull(resultResponse._second);
    Assert.assertNotNull(resultResponse._second.getIntegration());
    Assert.assertNotNull(resultResponse._second.getIntegration().getListeFichiers());
    Assert.assertNotNull(resultResponse._second.getIntegration().getNomGroupeFichiers());

  }

  /**
   * Retour request KO
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public void testFichierRead002() throws Exception
  {

    String result = "{\r\n\t\"retour\": {\r\n\t\t\"resultat\": \"NOK\",\r\n\t\t\"categorie\": \"CAT-4\",\r\n\t\t\"diagnostic\": \"DONNEE_INCONNUE\",\r\n\t\t\"libelle\": \"Nom de groupe de fichiers ELIG PREV inconnu\"\r\n\t}}\r\n"; //$NON-NLS-1$
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(result.getBytes())).build();
    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);

    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(PAD3003_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);
    PowerMock.replayAll();
    final ConnectorResponse<Retour, IntegrationGroupeFichierResponse> resultResponse = _connector.pad3003IntegrationGroupeFichierRead(_tracabilite, "ELIG%20PREV"); //$NON-NLS-1$
    PowerMock.verifyAll();
    checkHeader(_tracabilite, headersCapture);
    checkQueryParams(queryParamsCapture, "nomGroupeFichier", "ELIG%20PREV"); //$NON-NLS-1$ //$NON-NLS-2$

    Assert.assertNotNull(resultResponse);
    Assert.assertNotNull(resultResponse._first);
    Assert.assertEquals("NOK", resultResponse._first.getResultat()); //$NON-NLS-1$
    Assert.assertEquals("CAT-4", resultResponse._first.getCategorie()); //$NON-NLS-1$
    Assert.assertEquals("DONNEE_INCONNUE", resultResponse._first.getDiagnostic()); //$NON-NLS-1$
    Assert.assertEquals("Nom de groupe de fichiers ELIG PREV inconnu", resultResponse._first.getLibelle()); //$NON-NLS-1$
    Assert.assertNull(resultResponse._second);

  }

  /**
   * Exception KO
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public void testFichierRead003() throws Exception
  {

    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream("".getBytes())).build(); //$NON-NLS-1$
    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);

    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(PAD3003_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);
    PowerMock.replayAll();
    try
    {
      _connector.pad3003IntegrationGroupeFichierRead(_tracabilite, "ELIG%20PREV"); //$NON-NLS-1$
    }
    catch (RavelException e)
    {
      checkQueryParams(queryParamsCapture, "nomGroupeFichier", "ELIG%20PREV"); //$NON-NLS-1$ //$NON-NLS-2$

      Assert.assertEquals(ExceptionType.UNEXPECTED, e.getExceptionType());
      Assert.assertEquals(ErrorCode.CNCTOR_00010, e.getErrorCode());
      Assert.assertEquals("Impossible de récupérer la réponse", e.getMessage()); //$NON-NLS-1$
    }

  }

  /**
   * Nominal
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public void testFichierUpdate001() throws Exception
  {

    String result = "{\r\n\t\"retour\": {\r\n\t\t\"resultat\": \"OK\"\r\n\t}\r\n}\r\n"; //$NON-NLS-1$
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(result.getBytes())).build();
    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);

    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(PAD3003_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);
    PowerMock.replayAll();
    final ConnectorResponse<Retour, Boolean> resultResponse = _connector.pad3003IntegrationGroupeFichierUpdate(_tracabilite, "ELIG PREV", "BASCULE_REFERENTIEL"); //$NON-NLS-1$ //$NON-NLS-2$
    PowerMock.verifyAll();
    checkHeader(_tracabilite, headersCapture);
    checkQueryParams(queryParamsCapture, "nomGroupeFichier", "ELIG PREV", "action", "BASCULE_REFERENTIEL"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    Assert.assertNotNull(resultResponse);
    Assert.assertNotNull(resultResponse._first);
    Assert.assertEquals(RetourFactoryForTU.createOkRetour(), resultResponse._first);
    Assert.assertNotNull(resultResponse._second);

  }

  /**
   * Retour request KO
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public void testFichierUpdate002() throws Exception
  {

    String result = "{\r\n\t\"retour\": {\r\n\t\t\"resultat\": \"NOK\",\r\n\t\t\"categorie\": \"CAT-4\",\r\n\t\t\"diagnostic\": \"DONNEE_INVALIDE\",\r\n\t\t\"libelle\": \"Action STOP invalide\"\r\n\t}\r\n}\r\n"; //$NON-NLS-1$
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(result.getBytes())).build();
    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);

    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(PAD3003_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);
    PowerMock.replayAll();
    final ConnectorResponse<Retour, Boolean> resultResponse = _connector.pad3003IntegrationGroupeFichierUpdate(_tracabilite, "ELIG%20PREV", "BASCULE_REFERENTIEL"); //$NON-NLS-1$//$NON-NLS-2$
    PowerMock.verifyAll();
    checkHeader(_tracabilite, headersCapture);
    checkQueryParams(queryParamsCapture, "nomGroupeFichier", "ELIG%20PREV", "action", "BASCULE_REFERENTIEL"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$

    Assert.assertNotNull(resultResponse);
    Assert.assertNotNull(resultResponse._first);
    Assert.assertEquals("NOK", resultResponse._first.getResultat()); //$NON-NLS-1$
    Assert.assertEquals("CAT-4", resultResponse._first.getCategorie()); //$NON-NLS-1$
    Assert.assertEquals("DONNEE_INVALIDE", resultResponse._first.getDiagnostic()); //$NON-NLS-1$
    Assert.assertEquals("Action STOP invalide", resultResponse._first.getLibelle()); //$NON-NLS-1$
    Assert.assertEquals(false, resultResponse._second);

  }

  /**
   * Exception KO
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public void testFichierUpdate003() throws Exception
  {

    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream("".getBytes())).build(); //$NON-NLS-1$
    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);

    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(PAD3003_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);
    PowerMock.replayAll();
    try
    {
      _connector.pad3003IntegrationGroupeFichierUpdate(_tracabilite, "ELIG%20PREV", "BASCULE_REFERENTIEL"); //$NON-NLS-1$//$NON-NLS-2$
    }
    catch (RavelException e)
    {
      checkQueryParams(queryParamsCapture, "nomGroupeFichier", "ELIG%20PREV", "action", "BASCULE_REFERENTIEL"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$

      Assert.assertEquals(ExceptionType.UNEXPECTED, e.getExceptionType());
      Assert.assertEquals(ErrorCode.CNCTOR_00010, e.getErrorCode());
      Assert.assertEquals("Impossible de récupérer la réponse", e.getMessage()); //$NON-NLS-1$
    }

  }

  /**
   * Nominal
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public void testPad3001_001_ancienCodeInsee() throws Exception
  {

    String result = "{\n\t\"retour\": {\n\t\t\"resultat\": \"OK\"\n\t},\n\t\"listeCommune\": [\n\t\t{ \t\"codeInsee\": \"10899\",\n\t\t\t\"nomCommune\": \"MaCommune1\",\n\t\t\t\"ancienCodeInsee\": \"10888\",\n\t\t\t\"listeCodePostal\": [\n\t\t\t\t\"59188\",\n\t\t\t\t\"59189\"\n\t\t\t],\n\t\t\t\"listeNomAlternatif\": [\n\t\t\t\t{\"provenance\": \"SNA\", \"nomCommune\": \"MaCom1\"},\n\t\t\t\t{\"provenance\": \"42R4\", \"nomCommune\": \"UneCommune\"}\n\t\t\t]\n\t\t},\n\t\t{ \t\"codeInsee\": \"10899\",\n\t\t\t\"nomCommune\": \"MaCommune2\",\n\t\t\t\"ancienCodeInsee\": \"10888\",\n\t\t\t\"listeCodePostal\": [\n\"59187\"\n\t\t\t]\n\t\t}\n\t]\n}\n"; //$NON-NLS-1$
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(result.getBytes())).build();
    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);

    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(PAD3001_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);
    PowerMock.replayAll();
    final ConnectorResponse<Retour, ListeCommuneResponse> resultResponse = _connector.pad3001CommuneReadAncienCodeInsee(_tracabilite, "123"); //$NON-NLS-1$
    PowerMock.verifyAll();
    checkHeader(_tracabilite, headersCapture);
    checkQueryParams(queryParamsCapture, "ancienCodeInsee", "123"); //$NON-NLS-1$ //$NON-NLS-2$
    Assert.assertNotNull(resultResponse);
    Assert.assertNotNull(resultResponse._first);
    Assert.assertEquals(RetourFactoryForTU.createOkRetour(), resultResponse._first);
    Assert.assertNotNull(resultResponse._second);
    Assert.assertNotNull(resultResponse._second.getListeCommune());
    Assert.assertNotNull(resultResponse._second.getListeCommune().get(0).getCodePostaux());
    Assert.assertNotNull(resultResponse._second.getListeCommune().get(0).getNomsAlternatifs());
    Assert.assertNotNull(resultResponse._second.getListeCommune().get(1).getCodePostaux());
    Assert.assertNotNull(resultResponse._second.getListeCommune().get(1).getNomsAlternatifs());

  }

  /**
   * @throws Exception
   *           Exception
   */
  @Test
  public void testPad3001_001_codePostal() throws Exception
  {

    String result = "{\n\t\"retour\": {\n\t\t\"resultat\": \"OK\"\n\t},\n\t\"listeCommune\": [\n\t\t{ \t\"codeInsee\": \"10899\",\n\t\t\t\"nomCommune\": \"MaCommune1\",\n\t\t\t\"ancienCodeInsee\": \"10888\",\n\t\t\t\"listeCodePostal\": [\n\t\t\t\t\"59188\",\n\t\t\t\t\"59189\"\n\t\t\t],\n\t\t\t\"listeNomAlternatif\": [\n\t\t\t\t{\"provenance\": \"SNA\", \"nomCommune\": \"MaCom1\"},\n\t\t\t\t{\"provenance\": \"42R4\", \"nomCommune\": \"UneCommune\"}\n\t\t\t]\n\t\t},\n\t\t{ \t\"codeInsee\": \"10899\",\n\t\t\t\"nomCommune\": \"MaCommune2\",\n\t\t\t\"ancienCodeInsee\": \"10888\",\n\t\t\t\"listeCodePostal\": [\n\"59187\"\n\t\t\t]\n\t\t}\n\t]\n}\n"; //$NON-NLS-1$
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(result.getBytes())).build();
    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);

    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(PAD3001_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);
    PowerMock.replayAll();
    final ConnectorResponse<Retour, ListeCommuneResponse> resultResponse = _connector.pad3001CommuneReadCodePostal(_tracabilite, "123"); //$NON-NLS-1$
    PowerMock.verifyAll();
    checkHeader(_tracabilite, headersCapture);
    checkQueryParams(queryParamsCapture, "codePostal", "123"); //$NON-NLS-1$ //$NON-NLS-2$
    Assert.assertNotNull(resultResponse);
    Assert.assertNotNull(resultResponse._first);
    Assert.assertEquals(RetourFactoryForTU.createOkRetour(), resultResponse._first);
    Assert.assertNotNull(resultResponse._second);

  }

  /**
   * @throws Exception
   *           Exception
   */
  @Test
  public void testPad3001_001_create() throws Exception
  {

    String listCommuneJson = "{\n\t  \"listeCommune\": [\n\t\t{ \t\"codeInsee\": \"10899\",\n\t\t\t\"nomCommune\": \"MaCommune1\",\n\t\t\t\"ancienCodeInsee\": \"10888\",\n\t\t\t\"listeCodePostal\": [\n\t\t\t\t\"59188\",\n\t\t\t\t\"59189\"\n\t\t\t],\n\t\t\t\"listeNomAlternatif\": [\n\t\t\t\t{\"provenance\": \"SNA\", \"nomCommune\": \"MaCom1\"},\n\t\t\t\t{\"provenance\": \"42R4\", \"nomCommune\": \"UneCommune\"}\n\t\t\t]\n\t\t},\n\t\t{ \t\"codeInsee\": \"10905\",\n\t\t\t\"nomCommune\": \"MaCommune2\",\n\t\t\t\"ancienCodeInsee\": \"10904\",\n\t\t\t\"listeCodePostal\": [\n\t\t\t\t\"62458\"\n\t\t\t]\n\t\t}\n\t  ]\n}\n"; //$NON-NLS-1$
    String result = "{\n      \"retour\": {\n            \"resultat\": \"OK\"\n      }\n}\n\n"; //$NON-NLS-1$
    ListeCommuneRequest listCommune = GsonTools.getIso8601Ms().fromJson(listCommuneJson, ListeCommuneRequest.class);
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(result.getBytes())).build();
    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    String jsonRequestString = GsonTools.getIso8601Ms().toJson(listCommune);
    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(_createLongTimeout);

    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(PAD3001_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.eq(jsonRequestString), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);
    PowerMock.replayAll();
    final ConnectorResponse<Retour, Boolean> resultResponse = _connector.pad3001CommuneCreate(_tracabilite, listCommune);
    PowerMock.verifyAll();
    checkHeader(_tracabilite, headersCapture);

    Assert.assertNotNull(resultResponse);
    Assert.assertNotNull(resultResponse._first);
    Assert.assertEquals(RetourFactoryForTU.createOkRetour(), resultResponse._first);

  }

  /**
   * @throws Exception
   *           Exception
   */
  @Test
  public void testPad3001_001_Insee() throws Exception
  {

    String result = "{\n\t\"retour\": {\n\t\t\"resultat\": \"OK\"\n\t},\n\t\"listeCommune\": [\n\t\t{ \t\"codeInsee\": \"10899\",\n\t\t\t\"nomCommune\": \"MaCommune1\",\n\t\t\t\"ancienCodeInsee\": \"10888\",\n\t\t\t\"listeCodePostal\": [\n\t\t\t\t\"59188\",\n\t\t\t\t\"59189\"\n\t\t\t],\n\t\t\t\"listeNomAlternatif\": [\n\t\t\t\t{\"provenance\": \"SNA\", \"nomCommune\": \"MaCom1\"},\n\t\t\t\t{\"provenance\": \"42R4\", \"nomCommune\": \"UneCommune\"}\n\t\t\t]\n\t\t},\n\t\t{ \t\"codeInsee\": \"10899\",\n\t\t\t\"nomCommune\": \"MaCommune2\",\n\t\t\t\"ancienCodeInsee\": \"10888\",\n\t\t\t\"listeCodePostal\": [\n\"59187\"\n\t\t\t]\n\t\t}\n\t]\n}\n"; //$NON-NLS-1$
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(result.getBytes())).build();
    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);

    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(PAD3001_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);
    PowerMock.replayAll();
    final ConnectorResponse<Retour, ListeCommuneResponse> resultResponse = _connector.pad3001CommuneReadCodeInsee(_tracabilite, "123"); //$NON-NLS-1$
    PowerMock.verifyAll();
    checkHeader(_tracabilite, headersCapture);
    checkQueryParams(queryParamsCapture, "codeInsee", "123"); //$NON-NLS-1$ //$NON-NLS-2$

    Assert.assertNotNull(resultResponse);
    Assert.assertNotNull(resultResponse._first);
    Assert.assertEquals(RetourFactoryForTU.createOkRetour(), resultResponse._first);
    Assert.assertNotNull(resultResponse._second);
  }

  /**
   * @throws Exception
   *           Exception
   */
  @Test
  public void testPad3001_002_anciencodeInsee() throws Exception
  {

    String result = "{\n      \"retour\": {\n            \"resultat\": \"NOK\",\n            \"categorie\": \"CAT-4\",\n            \"diagnostic\": \"CODE_INSEE_INCONNU\",\n            \"libelle\": \"Code insee 10899 inconnu\"\n      }\n}\n"; //$NON-NLS-1$
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(result.getBytes())).build();
    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);

    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(PAD3001_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);
    PowerMock.replayAll();
    final ConnectorResponse<Retour, ListeCommuneResponse> resultResponse = _connector.pad3001CommuneReadAncienCodeInsee(_tracabilite, "123"); //$NON-NLS-1$
    PowerMock.verifyAll();
    checkHeader(_tracabilite, headersCapture);
    checkQueryParams(queryParamsCapture, "ancienCodeInsee", "123"); //$NON-NLS-1$ //$NON-NLS-2$

    Assert.assertNotNull(resultResponse);
    Assert.assertNotNull(resultResponse._first);
    Assert.assertEquals("NOK", resultResponse._first.getResultat()); //$NON-NLS-1$
    Assert.assertEquals("CAT-4", resultResponse._first.getCategorie()); //$NON-NLS-1$
    Assert.assertEquals("CODE_INSEE_INCONNU", resultResponse._first.getDiagnostic()); //$NON-NLS-1$
    Assert.assertEquals("Code insee 10899 inconnu", resultResponse._first.getLibelle()); //$NON-NLS-1$
    Assert.assertNull(resultResponse._second);

  }

  /**
   * @throws Exception
   *           Exception
   */
  @Test
  public void testPad3001_002_codePostal() throws Exception
  {

    String result = "{\n      \"retour\": {\n            \"resultat\": \"NOK\",\n            \"categorie\": \"CAT-4\",\n            \"diagnostic\": \"CODE_INSEE_INCONNU\",\n            \"libelle\": \"Code insee 10899 inconnu\"\n      }\n}\n"; //$NON-NLS-1$
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(result.getBytes())).build();
    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);

    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(PAD3001_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);
    PowerMock.replayAll();
    final ConnectorResponse<Retour, ListeCommuneResponse> resultResponse = _connector.pad3001CommuneReadCodePostal(_tracabilite, "123"); //$NON-NLS-1$
    PowerMock.verifyAll();
    checkHeader(_tracabilite, headersCapture);
    checkQueryParams(queryParamsCapture, "codePostal", "123"); //$NON-NLS-1$ //$NON-NLS-2$

    Assert.assertNotNull(resultResponse);
    Assert.assertNotNull(resultResponse._first);
    Assert.assertEquals("NOK", resultResponse._first.getResultat()); //$NON-NLS-1$
    Assert.assertEquals("CAT-4", resultResponse._first.getCategorie()); //$NON-NLS-1$
    Assert.assertEquals("CODE_INSEE_INCONNU", resultResponse._first.getDiagnostic()); //$NON-NLS-1$
    Assert.assertEquals("Code insee 10899 inconnu", resultResponse._first.getLibelle()); //$NON-NLS-1$
    Assert.assertNull(resultResponse._second);

  }

  /**
   * @throws Exception
   *           Exception
   */
  @Test
  public void testPad3001_002_create() throws Exception
  {

    String listCommuneJson = "{\n\t  \"listeCommune\": [\n\t\t{ \t\"codeInsee\": \"10899\",\n\t\t\t\"nomCommune\": \"MaCommune1\",\n\t\t\t\"ancienCodeInsee\": \"10888\",\n\t\t\t\"listeCodePostal\": [\n\t\t\t\t\"59188\",\n\t\t\t\t\"59189\"\n\t\t\t],\n\t\t\t\"listeNomAlternatif\": [\n\t\t\t\t{\"provenance\": \"SNA\", \"nomCommune\": \"MaCom1\"},\n\t\t\t\t{\"provenance\": \"42R4\", \"nomCommune\": \"UneCommune\"}\n\t\t\t]\n\t\t},\n\t\t{ \t\"codeInsee\": \"10905\",\n\t\t\t\"nomCommune\": \"MaCommune2\",\n\t\t\t\"ancienCodeInsee\": \"10904\",\n\t\t\t\"listeCodePostal\": [\n\t\t\t\t\"62458\"\n\t\t\t]\n\t\t}\n\t  ]\n}\n"; //$NON-NLS-1$
    String result = "{\n      \"retour\": {\n            \"resultat\": \"NOK\",\n            \"categorie\": \"CAT-4\",\n            \"diagnostic\": \"DONNEE_INVALIDE\",\n            \"libelle\": \"Code insee 10 invalide\"\n      }\n}\n"; //$NON-NLS-1$
    ListeCommuneRequest listCommune = GsonTools.getIso8601Ms().fromJson(listCommuneJson, ListeCommuneRequest.class);
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(result.getBytes())).build();
    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    String jsonRequestString = GsonTools.getIso8601Ms().toJson(listCommune);
    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(_createLongTimeout);

    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(PAD3001_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.eq(jsonRequestString), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);
    PowerMock.replayAll();
    final ConnectorResponse<Retour, Boolean> resultResponse = _connector.pad3001CommuneCreate(_tracabilite, listCommune);
    PowerMock.verifyAll();
    checkHeader(_tracabilite, headersCapture);

    Assert.assertNotNull(resultResponse);
    Assert.assertNotNull(resultResponse._first);
    Assert.assertEquals("NOK", resultResponse._first.getResultat()); //$NON-NLS-1$
    Assert.assertEquals("CAT-4", resultResponse._first.getCategorie()); //$NON-NLS-1$
    Assert.assertEquals("DONNEE_INVALIDE", resultResponse._first.getDiagnostic()); //$NON-NLS-1$
    Assert.assertEquals("Code insee 10 invalide", resultResponse._first.getLibelle()); //$NON-NLS-1$

  }

  /**
   * @throws Exception
   *           Exception
   */
  @Test
  public void testPad3001_002_Insee() throws Exception
  {

    String result = "{\n      \"retour\": {\n            \"resultat\": \"NOK\",\n            \"categorie\": \"CAT-4\",\n            \"diagnostic\": \"CODE_INSEE_INCONNU\",\n            \"libelle\": \"Code insee 10899 inconnu\"\n      }\n}\n"; //$NON-NLS-1$
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(result.getBytes())).build();
    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);

    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(PAD3001_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);
    PowerMock.replayAll();
    final ConnectorResponse<Retour, ListeCommuneResponse> resultResponse = _connector.pad3001CommuneReadCodeInsee(_tracabilite, "123"); //$NON-NLS-1$
    PowerMock.verifyAll();
    checkHeader(_tracabilite, headersCapture);
    checkQueryParams(queryParamsCapture, "codeInsee", "123"); //$NON-NLS-1$ //$NON-NLS-2$

    Assert.assertNotNull(resultResponse);
    Assert.assertNotNull(resultResponse._first);
    Assert.assertEquals("NOK", resultResponse._first.getResultat()); //$NON-NLS-1$
    Assert.assertEquals("CAT-4", resultResponse._first.getCategorie()); //$NON-NLS-1$
    Assert.assertEquals("CODE_INSEE_INCONNU", resultResponse._first.getDiagnostic()); //$NON-NLS-1$
    Assert.assertEquals("Code insee 10899 inconnu", resultResponse._first.getLibelle()); //$NON-NLS-1$
    Assert.assertNull(resultResponse._second);

  }

  /**
   * @throws Exception
   *           Exception
   */
  @Test
  public void testPad3001_003_ancienCodeInsee() throws Exception
  {

    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream("".getBytes())).build(); //$NON-NLS-1$
    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);

    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(PAD3001_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);
    PowerMock.replayAll();
    try
    {
      _connector.pad3001CommuneReadAncienCodeInsee(_tracabilite, "123"); //$NON-NLS-1$
    }
    catch (RavelException e)
    {
      checkQueryParams(queryParamsCapture, "ancienCodeInsee", "123"); //$NON-NLS-1$ //$NON-NLS-2$

      Assert.assertEquals(ExceptionType.UNEXPECTED, e.getExceptionType());
      Assert.assertEquals(ErrorCode.CNCTOR_00010, e.getErrorCode());
      Assert.assertEquals("Impossible de récupérer la réponse", e.getMessage()); //$NON-NLS-1$
    }
  }

  /**
   * @throws Exception
   *           Exception
   */
  @Test
  public void testPad3001_003_codePostal() throws Exception
  {

    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream("".getBytes())).build(); //$NON-NLS-1$
    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);

    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(PAD3001_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);
    PowerMock.replayAll();
    try
    {
      _connector.pad3001CommuneReadCodePostal(_tracabilite, "123"); //$NON-NLS-1$
    }
    catch (RavelException e)
    {
      checkQueryParams(queryParamsCapture, "codePostal", "123"); //$NON-NLS-1$ //$NON-NLS-2$

      Assert.assertEquals(ExceptionType.UNEXPECTED, e.getExceptionType());
      Assert.assertEquals(ErrorCode.CNCTOR_00010, e.getErrorCode());
      Assert.assertEquals("Impossible de récupérer la réponse", e.getMessage()); //$NON-NLS-1$
    }

  }

  /**
   * @throws Exception
   *           Exception
   */
  @Test
  public void testPad3001_003_create() throws Exception
  {

    String listCommuneJson = "{\n\t  \"listeCommune\": [\n\t\t{ \t\"codeInsee\": \"10899\",\n\t\t\t\"nomCommune\": \"MaCommune1\",\n\t\t\t\"ancienCodeInsee\": \"10888\",\n\t\t\t\"listeCodePostal\": [\n\t\t\t\t\"59188\",\n\t\t\t\t\"59189\"\n\t\t\t],\n\t\t\t\"listeNomAlternatif\": [\n\t\t\t\t{\"provenance\": \"SNA\", \"nomCommune\": \"MaCom1\"},\n\t\t\t\t{\"provenance\": \"42R4\", \"nomCommune\": \"UneCommune\"}\n\t\t\t]\n\t\t},\n\t\t{ \t\"codeInsee\": \"10905\",\n\t\t\t\"nomCommune\": \"MaCommune2\",\n\t\t\t\"ancienCodeInsee\": \"10904\",\n\t\t\t\"listeCodePostal\": [\n\t\t\t\t\"62458\"\n\t\t\t]\n\t\t}\n\t  ]\n}\n"; //$NON-NLS-1$
    ListeCommuneRequest listCommune = GsonTools.getIso8601Ms().fromJson(listCommuneJson, ListeCommuneRequest.class);
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream("".getBytes())).build(); //$NON-NLS-1$
    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    String jsonRequestString = GsonTools.getIso8601Ms().toJson(listCommune);
    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(_createLongTimeout);

    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(PAD3001_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.eq(jsonRequestString), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);
    PowerMock.replayAll();
    try
    {
      _connector.pad3001CommuneCreate(_tracabilite, listCommune);
    }
    catch (RavelException e)
    {
      checkQueryParams(queryParamsCapture, (String[]) null);

      Assert.assertEquals(ExceptionType.UNEXPECTED, e.getExceptionType());
      Assert.assertEquals(ErrorCode.CNCTOR_00010, e.getErrorCode());
      Assert.assertEquals("Impossible de récupérer la réponse", e.getMessage()); //$NON-NLS-1$
    }
  }

  /**
   * @throws Exception
   *           Exception
   */
  @Test
  public void testPad3001_003_Insee() throws Exception
  {

    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream("".getBytes())).build(); //$NON-NLS-1$
    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);

    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(PAD3001_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);
    PowerMock.replayAll();
    try
    {
      _connector.pad3001CommuneReadCodeInsee(_tracabilite, "123"); //$NON-NLS-1$
    }
    catch (RavelException e)
    {
      checkQueryParams(queryParamsCapture, "codeInsee", "123"); //$NON-NLS-1$ //$NON-NLS-2$

      Assert.assertEquals(ExceptionType.UNEXPECTED, e.getExceptionType());
      Assert.assertEquals(ErrorCode.CNCTOR_00010, e.getErrorCode());
      Assert.assertEquals("Impossible de récupérer la réponse", e.getMessage()); //$NON-NLS-1$
    }

  }

  /**
   * @throws Exception
   *           Exception
   */
  @Test
  public void testPrevProgCreate001() throws Exception
  {
    String json = "{\r\n\t\"listePrevisionProgramme\": [\r\n\t\t{ \t\"codeInsee\": \"10899\",\r\n\t\t\t\"nomProgramme\": \"FTTH\",\r\n\t\t\t\"listeJalon\": [\r\n\t\t\t\t{\"FTTH_DANS_LA_VILLE\": \"2017-09-15T00:00:00.000+0200\"}\r\n\t\t\t]\r\n\t\t},\r\n\t\t{ \t\"codeInsee\": \"10899\",\r\n\t\t\t\"nomProgramme\": \"CROZON\",\r\n\t\t\t\"listeJalon\": [\r\n\t\t\t\t{\t\"nomJalon\": \"SWAP\", \r\n\t\t\t\t\t\"dateJalon\": \"2017-09-15T00:00:00.000+0200\"\r\n\t\t\t\t},\r\n\t\t\t\t{\t\"nomJalon\": \"SWAP_GABARISE\",\r\n\t\t\t\t\t\"dateJalon\": \"2017-09-16T00:00:00.000+0200\"\r\n\t\t\t\t},\r\n\t\t\t\t{\t\"nomJalon\": \"BF1\",\r\n\t\t\t\t\t\"dateJalon\": \"2017-09-17T00:00:00.000+0200\"\r\n\t\t\t\t},\r\n\t\t\t\t{\t\"nomJalon\": \"BF2\",\r\n\t\t\t\t\t\"dateJalon\": \"2017-09-18T00:00:00.000+0200\"\r\n\t\t\t\t}\r\n\t\t\t]\r\n\t\t}\r\n\t]\r\n}\r\n"; //$NON-NLS-1$

    String result = "{\n      \"retour\": {\n            \"resultat\": \"OK\"\n      }\n}\n\n"; //$NON-NLS-1$
    ListePrevisionRequest listCommune = GsonTools.getIso8601Ms().fromJson(json, ListePrevisionRequest.class);
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(result.getBytes())).build();
    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    String jsonRequestString = GsonTools.getIso8601Ms().toJson(listCommune);
    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(_createLongTimeout);

    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(PAD3002_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.eq(jsonRequestString), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);
    PowerMock.replayAll();
    final ConnectorResponse<Retour, Boolean> resultResponse = _connector.pad3002PrevisionProgCreate(_tracabilite, listCommune);
    PowerMock.verifyAll();
    checkHeader(_tracabilite, headersCapture);
    checkQueryParams(queryParamsCapture, (String[]) null);

    Assert.assertNotNull(resultResponse);
    Assert.assertNotNull(resultResponse._first);
    Assert.assertEquals(RetourFactoryForTU.createOkRetour(), resultResponse._first);

  }

  /**
   * @throws Exception
   *           Exception
   */
  @Test
  public void testPrevProgCreate002() throws Exception
  {
    String json = "{\r\n\t\"listePrevisionProgramme\": [\r\n\t\t{ \t\"codeInsee\": \"10899\",\r\n\t\t\t\"nomProgramme\": \"FTTH\",\r\n\t\t\t\"listeJalon\": [\r\n\t\t\t\t{\"FTTH_DANS_LA_VILLE\": \"2017-09-15T00:00:00.000+0200\"}\r\n\t\t\t]\r\n\t\t},\r\n\t\t{ \t\"codeInsee\": \"10899\",\r\n\t\t\t\"nomProgramme\": \"CROZON\",\r\n\t\t\t\"listeJalon\": [\r\n\t\t\t\t{\t\"nomJalon\": \"SWAP\", \r\n\t\t\t\t\t\"dateJalon\": \"2017-09-15T00:00:00.000+0200\"\r\n\t\t\t\t},\r\n\t\t\t\t{\t\"nomJalon\": \"SWAP_GABARISE\",\r\n\t\t\t\t\t\"dateJalon\": \"2017-09-16T00:00:00.000+0200\"\r\n\t\t\t\t},\r\n\t\t\t\t{\t\"nomJalon\": \"BF1\",\r\n\t\t\t\t\t\"dateJalon\": \"2017-09-17T00:00:00.000+0200\"\r\n\t\t\t\t},\r\n\t\t\t\t{\t\"nomJalon\": \"BF2\",\r\n\t\t\t\t\t\"dateJalon\": \"2017-09-18T00:00:00.000+0200\"\r\n\t\t\t\t}\r\n\t\t\t]\r\n\t\t}\r\n\t]\r\n}\r\n"; //$NON-NLS-1$

    String result = "{\n      \"retour\": {\n            \"resultat\": \"NOK\",\n            \"categorie\": \"CAT-4\",\n            \"diagnostic\": \"DONNEE_INVALIDE\",\n            \"libelle\": \"Code insee 10 invalide\"\n      }\n}\n"; //$NON-NLS-1$
    ListePrevisionRequest listCommune = GsonTools.getIso8601Ms().fromJson(json, ListePrevisionRequest.class);
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(result.getBytes())).build();
    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    String jsonRequestString = GsonTools.getIso8601Ms().toJson(listCommune);
    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(_createLongTimeout);

    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(PAD3002_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.eq(jsonRequestString), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);
    PowerMock.replayAll();
    final ConnectorResponse<Retour, Boolean> resultResponse = _connector.pad3002PrevisionProgCreate(_tracabilite, listCommune);
    PowerMock.verifyAll();
    checkHeader(_tracabilite, headersCapture);
    checkQueryParams(queryParamsCapture, (String[]) null);

    Assert.assertNotNull(resultResponse);
    Assert.assertNotNull(resultResponse._first);
    Assert.assertEquals("NOK", resultResponse._first.getResultat()); //$NON-NLS-1$
    Assert.assertEquals("CAT-4", resultResponse._first.getCategorie()); //$NON-NLS-1$
    Assert.assertEquals("DONNEE_INVALIDE", resultResponse._first.getDiagnostic()); //$NON-NLS-1$
    Assert.assertEquals("Code insee 10 invalide", resultResponse._first.getLibelle()); //$NON-NLS-1$

  }

  /**
   * @throws Exception
   *           Exception
   */
  @Test
  public void testPrevProgCreate003() throws Exception
  {

    String json = "{\r\n\t\"listePrevisionProgramme\": [\r\n\t\t{ \t\"codeInsee\": \"10899\",\r\n\t\t\t\"nomProgramme\": \"FTTH\",\r\n\t\t\t\"listeJalon\": [\r\n\t\t\t\t{\"FTTH_DANS_LA_VILLE\": \"2017-09-15T00:00:00.000+0200\"}\r\n\t\t\t]\r\n\t\t},\r\n\t\t{ \t\"codeInsee\": \"10899\",\r\n\t\t\t\"nomProgramme\": \"CROZON\",\r\n\t\t\t\"listeJalon\": [\r\n\t\t\t\t{\t\"nomJalon\": \"SWAP\", \r\n\t\t\t\t\t\"dateJalon\": \"2017-09-15T00:00:00.000+0200\"\r\n\t\t\t\t},\r\n\t\t\t\t{\t\"nomJalon\": \"SWAP_GABARISE\",\r\n\t\t\t\t\t\"dateJalon\": \"2017-09-16T00:00:00.000+0200\"\r\n\t\t\t\t},\r\n\t\t\t\t{\t\"nomJalon\": \"BF1\",\r\n\t\t\t\t\t\"dateJalon\": \"2017-09-17T00:00:00.000+0200\"\r\n\t\t\t\t},\r\n\t\t\t\t{\t\"nomJalon\": \"BF2\",\r\n\t\t\t\t\t\"dateJalon\": \"2017-09-18T00:00:00.000+0200\"\r\n\t\t\t\t}\r\n\t\t\t]\r\n\t\t}\r\n\t]\r\n}\r\n"; //$NON-NLS-1$
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream("".getBytes())).build(); //$NON-NLS-1$
    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    ListePrevisionRequest listCommune = GsonTools.getIso8601Ms().fromJson(json, ListePrevisionRequest.class);
    String jsonRequestString = GsonTools.getIso8601Ms().toJson(listCommune);
    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(_createLongTimeout);
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(PAD3002_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.eq(jsonRequestString), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);
    PowerMock.replayAll();
    try
    {
      _connector.pad3002PrevisionProgCreate(_tracabilite, listCommune);
    }
    catch (RavelException e)
    {
      checkQueryParams(queryParamsCapture, (String[]) null);

      Assert.assertEquals(ExceptionType.UNEXPECTED, e.getExceptionType());
      Assert.assertEquals(ErrorCode.CNCTOR_00010, e.getErrorCode());
      Assert.assertEquals("Impossible de récupérer la réponse", e.getMessage()); //$NON-NLS-1$
    }
  }

  /**
   * @throws Exception
   *           Exception
   */
  @Test
  public void testPrevProgRead001() throws Exception
  {

    String result = "{\r\n\t\"retour\": {\r\n\t\t\"resultat\": \"OK\"\r\n\t},\r\n\"previsionProgramme\": { \t\r\n\t\t\"codeInsee\": \"10899\",\r\n\t\t\"nomProgramme\": \"CROZON\",\r\n\t\t\"listeJalon\": [\r\n\t\t\t{\t\"nomJalon\": \"SWAP\", \r\n\t\t\t\t\"dateJalon\": \"2017-09-15T00:00:00.000+0200\"\r\n\t\t\t},\r\n\t\t\t{\t\"nomJalon\": \"SWAP_GABARISE\",\r\n\t\t\t\t\"dateJalon\": \"2017-09-16T00:00:00.000+0200\"\r\n\t\t\t},\r\n\t\t\t{\t\"nomJalon\": \"BF1\",\r\n\t\t\t\t\"dateJalon\": \"2017-09-17T00:00:00.000+0200\"\r\n\t\t\t},\r\n\t\t\t{\t\"nomJalon\": \"BF2\",\r\n\t\t\t\t\"dateJalon\": \"2017-09-18T00:00:00.000+0200\"\r\n\t\t\t}\r\n\t\t]\r\n\t}\r\n\r\n}\r\n"; //$NON-NLS-1$
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(result.getBytes())).build();
    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);

    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(PAD3002_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);
    PowerMock.replayAll();
    final ConnectorResponse<Retour, ListePrevisionResponse> resultResponse = _connector.pad3002PrevisionProgRead(_tracabilite, "CROZON", "10899"); //$NON-NLS-1$ //$NON-NLS-2$
    PowerMock.verifyAll();
    checkHeader(_tracabilite, headersCapture);
    checkQueryParams(queryParamsCapture, "nomProgramme", "CROZON", "codeInsee", "10899"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$

    Assert.assertNotNull(resultResponse);
    Assert.assertNotNull(resultResponse._first);
    Assert.assertEquals(RetourFactoryForTU.createOkRetour(), resultResponse._first);
    Assert.assertNotNull(resultResponse._second);

  }

  /**
   * @throws Exception
   *           Exception
   */
  @Test
  public void testPrevProgRead002() throws Exception
  {

    String result = "{\n      \"retour\": {\n            \"resultat\": \"NOK\",\n            \"categorie\": \"CAT-4\",\n            \"diagnostic\": \"DONNEE_INVALIDE\",\n            \"libelle\": \"Code insee 10 invalide\"\n      }\n}\n"; //$NON-NLS-1$
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(result.getBytes())).build();
    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(PAD3002_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);
    PowerMock.replayAll();
    final ConnectorResponse<Retour, ListePrevisionResponse> resultResponse = _connector.pad3002PrevisionProgRead(_tracabilite, "CROZON", "10899"); //$NON-NLS-1$ //$NON-NLS-2$
    PowerMock.verifyAll();
    checkHeader(_tracabilite, headersCapture);
    checkQueryParams(queryParamsCapture, "nomProgramme", "CROZON", "codeInsee", "10899"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$

    Assert.assertNotNull(resultResponse);
    Assert.assertNotNull(resultResponse._first);
    Assert.assertEquals("NOK", resultResponse._first.getResultat()); //$NON-NLS-1$
    Assert.assertEquals("CAT-4", resultResponse._first.getCategorie()); //$NON-NLS-1$
    Assert.assertEquals("DONNEE_INVALIDE", resultResponse._first.getDiagnostic()); //$NON-NLS-1$
    Assert.assertEquals("Code insee 10 invalide", resultResponse._first.getLibelle()); //$NON-NLS-1$

  }

  /**
   * @throws Exception
   *           Exception
   */
  @Test
  public void testPrevProgRead003() throws Exception
  {

    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream("".getBytes())).build(); //$NON-NLS-1$
    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(PAD3002_PATH_PARAM), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);
    PowerMock.replayAll();
    try
    {
      _connector.pad3002PrevisionProgRead(_tracabilite, "CROZON", "10899"); //$NON-NLS-1$ //$NON-NLS-2$
    }
    catch (RavelException e)
    {
      checkQueryParams(queryParamsCapture, "nomProgramme", "CROZON", "codeInsee", "10899"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$

      Assert.assertEquals(ExceptionType.UNEXPECTED, e.getExceptionType());
      Assert.assertEquals(ErrorCode.CNCTOR_00010, e.getErrorCode());
      Assert.assertEquals("Impossible de récupérer la réponse", e.getMessage()); //$NON-NLS-1$
    }
  }

  /**
   * Test KO for the method {@link RESConnector#ressourceCompteImsCreer(Tracabilite, Ressource)} httpStatus 200, with
   * retourKO
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testRessourceAdresseIpClfCreer_KO_001() throws Exception
  {

    final RessourceAdresseIpClf ressourceAdresseIpClf = _podam.manufacturePojo(RessourceAdresseIpClf.class);
    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT1, IMegSpiritConsts.DONNEE_INDISPONIBLE, StringConstants.EMPTY_STRING, null);
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(basicResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();

    // construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(_ressourceAdresseIpClfUrl), EasyMock.capture(headersCapture), EasyMock.eq(RavelJsonTools.getInstance().toJson(ressourceAdresseIpClf, RessourceAdresseIpClf.class)), EasyMock.isNull())).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.ressourceAdresseIpClfCreer(_tracabilite, ressourceAdresseIpClf);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test KO for the method {@link RESConnector#ressourceAdresseIpClfCreer(Tracabilite, Ressource)} httpStatus 200,
   * jsonResponse null (throws RavelException)
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testRessourceAdresseIpClfCreer_KO_002() throws Exception
  {

    final RessourceAdresseIpClf ressourceAdresseIpClf = _podam.manufacturePojo(RessourceAdresseIpClf.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();

    // construct response
    final Response response = new ResponseBuilderImpl().status(200).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(_ressourceAdresseIpClfUrl), EasyMock.capture(headersCapture), EasyMock.eq(RavelJsonTools.getInstance().toJson(ressourceAdresseIpClf, RessourceAdresseIpClf.class)), EasyMock.isNull())).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    ConnectorResponse<Retour, Nothing> result = null;

    PowerMock.replayAll();
    result = _connector.ressourceAdresseIpClfCreer(_tracabilite, ressourceAdresseIpClf);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, JSON_ERROR_MESSAGE, null);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test KO for the method {@link RESConnector#ressourceAdresseIpClfCreer(Tracabilite, Ressource)} httpStatus 500,
   * jsonResponse null (throws RavelException)
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testRessourceAdresseIpClfCreer_KO_003() throws Exception
  {

    final RessourceAdresseIpClf ressourceAdresseIpClf = _podam.manufacturePojo(RessourceAdresseIpClf.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();

    // construct response
    final Response response = new ResponseBuilderImpl().status(500).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(_ressourceAdresseIpClfUrl), EasyMock.capture(headersCapture), EasyMock.eq(RavelJsonTools.getInstance().toJson(ressourceAdresseIpClf, RessourceAdresseIpClf.class)), EasyMock.isNull())).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    ConnectorResponse<Retour, Nothing> result = null;

    PowerMock.replayAll();
    result = _connector.ressourceAdresseIpClfCreer(_tracabilite, ressourceAdresseIpClf);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, JSON_ERROR_MESSAGE, null);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test OK for the method {@link RESConnector#ressourceAdresseIpClfCreer(Tracabilite, Ressource)} with httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testRessourceAdresseIpClfCreer_OK_001() throws Exception
  {

    final RessourceAdresseIpClf ressourceAdresseIpClf = _podam.manufacturePojo(RessourceAdresseIpClf.class);
    final Retour retour = RetourFactoryForTU.createOkRetour();
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(basicResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();

    // construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(_ressourceAdresseIpClfUrl), EasyMock.capture(headersCapture), EasyMock.eq(RavelJsonTools.getInstance().toJson(ressourceAdresseIpClf, RessourceAdresseIpClf.class)), EasyMock.isNull())).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.ressourceAdresseIpClfCreer(_tracabilite, ressourceAdresseIpClf);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    Assert.assertEquals(retour, result._first);
  }

  /**
   * Test KO for the method
   * {@link RESConnector#ressourceAdresseIpClfModifierStatutAllocation(Tracabilite, String, String, String)}
   *
   * Expected : Retour KO, CAT-4, DONNEE_INCONNUE, "ressourceCompteMail xxx inconnue"
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testRessourceAdresseIpClfModifierStatutAllocation_KO_001() throws Exception
  {

    final String idRessource = RandomStringUtils.randomAlphabetic(5);
    final String idSt = RandomStringUtils.randomAlphabetic(5);
    final String statut = "TRAITEE"; //$NON-NLS-1$

    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "ressourceCompteMail " + idRessource + " inconnue", null); //$NON-NLS-1$ //$NON-NLS-2$
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(basicResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_ressourceAdresseIpClfUrl), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.ressourceAdresseIpClfModifierStatutAllocation(_tracabilite, idRessource, idSt, statut);

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, PARAM_ID_RESSOURCE, idRessource);
    checkQueryParams(queryParamsCapture, PARAM_ID_ST, idSt);
    checkQueryParams(queryParamsCapture, PARAM_STATUT, statut);

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test OK for the method
   * {@link RESConnector#ressourceAdresseIpClfModifierStatutAllocation(Tracabilite, String, String, String)} httpStatus
   * 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testRessourceAdresseIpClfModifierStatutAllocation_OK_001() throws Exception
  {

    final String idRessource = RandomStringUtils.randomAlphabetic(5);
    final String idSt = RandomStringUtils.randomAlphabetic(5);
    final String statut = "TRAITEE"; //$NON-NLS-1$

    final Retour retour = RetourFactoryForTU.createOkRetour();
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(basicResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_ressourceAdresseIpClfUrl), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.ressourceAdresseIpClfModifierStatutAllocation(_tracabilite, idRessource, idSt, statut);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, PARAM_ID_RESSOURCE, idRessource);
    checkQueryParams(queryParamsCapture, PARAM_ID_ST, idSt);
    checkQueryParams(queryParamsCapture, PARAM_STATUT, statut);

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test KO for the method {@link RESConnector#ressourceCompteImsCreer(Tracabilite, Ressource)} httpStatus 200, with
   * retourKO
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testRessourceCompteImsCreer_KO_001() throws Exception
  {

    final RessourceCompteIms ressourceCompteIms = _podam.manufacturePojo(RessourceCompteIms.class);
    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT1, IMegSpiritConsts.DONNEE_INDISPONIBLE, StringConstants.EMPTY_STRING, null);
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(basicResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();

    // construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(_ressourceCompteImsUrl), EasyMock.capture(headersCapture), EasyMock.eq(RavelJsonTools.getInstance().toJson(ressourceCompteIms, RessourceCompteIms.class)), EasyMock.isNull())).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.ressourceCompteImsCreer(_tracabilite, ressourceCompteIms);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test KO for the method {@link RESConnector#ressourceCompteImsCreer(Tracabilite, Ressource)} httpStatus 200,
   * jsonResponse null (throws RavelException)
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testRessourceCompteImsCreer_KO_002() throws Exception
  {

    final RessourceCompteIms ressourceCompteIms = _podam.manufacturePojo(RessourceCompteIms.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();

    // construct response
    final Response response = new ResponseBuilderImpl().status(200).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(_ressourceCompteImsUrl), EasyMock.capture(headersCapture), EasyMock.eq(RavelJsonTools.getInstance().toJson(ressourceCompteIms, RessourceCompteIms.class)), EasyMock.isNull())).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    ConnectorResponse<Retour, Nothing> result = null;

    PowerMock.replayAll();
    result = _connector.ressourceCompteImsCreer(_tracabilite, ressourceCompteIms);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, JSON_ERROR_MESSAGE, null);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test KO for the method {@link RESConnector#ressourceCompteImsCreer(Tracabilite, Ressource)} httpStatus 500,
   * jsonResponse null (throws RavelException)
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testRessourceCompteImsCreer_KO_003() throws Exception
  {

    final RessourceCompteIms ressourceCompteIms = _podam.manufacturePojo(RessourceCompteIms.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();

    // construct response
    final Response response = new ResponseBuilderImpl().status(500).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(_ressourceCompteImsUrl), EasyMock.capture(headersCapture), EasyMock.eq(RavelJsonTools.getInstance().toJson(ressourceCompteIms, RessourceCompteIms.class)), EasyMock.isNull())).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    ConnectorResponse<Retour, Nothing> result = null;

    PowerMock.replayAll();
    result = _connector.ressourceCompteImsCreer(_tracabilite, ressourceCompteIms);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, JSON_ERROR_MESSAGE, null);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test OK for the method {@link RESConnector#ressourceCompteImsCreer(Tracabilite, Ressource)} with httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testRessourceCompteImsCreer_OK_001() throws Exception
  {

    final RessourceCompteIms ressourceCompteIms = _podam.manufacturePojo(RessourceCompteIms.class);
    final Retour retour = RetourFactoryForTU.createOkRetour();
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(basicResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();

    // construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(_ressourceCompteImsUrl), EasyMock.capture(headersCapture), EasyMock.eq(RavelJsonTools.getInstance().toJson(ressourceCompteIms, RessourceCompteIms.class)), EasyMock.isNull())).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.ressourceCompteImsCreer(_tracabilite, ressourceCompteIms);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    Assert.assertEquals(retour, result._first);
  }

  /**
   * Test KO for the method
   * {@link RESConnector#ressourceCompteImsModifierStatutAllocation(Tracabilite, String, String, String)}
   *
   * Expected : Retour KO, CAT-4, DONNEE_INCONNUE, "ressourceCompteMail xxx inconnue"
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testRessourceCompteImsModifierStatutAllocation_KO_001() throws Exception
  {

    final String idRessource = RandomStringUtils.randomAlphabetic(5);
    final String idSt = RandomStringUtils.randomAlphabetic(5);
    final String statut = "TRAITEE"; //$NON-NLS-1$

    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "ressourceCompteMail " + idRessource + " inconnue", null); //$NON-NLS-1$ //$NON-NLS-2$
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(basicResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_ressourceCompteImsUrl), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.ressourceCompteImsModifierStatutAllocation(_tracabilite, idRessource, idSt, statut);

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, PARAM_ID_RESSOURCE, idRessource);
    checkQueryParams(queryParamsCapture, PARAM_ID_ST, idSt);
    checkQueryParams(queryParamsCapture, PARAM_STATUT, statut);

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test OK for the method
   * {@link RESConnector#ressourceCompteImsModifierStatutAllocation(Tracabilite, String, String, String)} httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testRessourceCompteImsModifierStatutAllocation_OK_001() throws Exception
  {

    final String idRessource = RandomStringUtils.randomAlphabetic(5);
    final String idSt = RandomStringUtils.randomAlphabetic(5);
    final String statut = "TRAITEE"; //$NON-NLS-1$

    final Retour retour = RetourFactoryForTU.createOkRetour();
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(basicResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_ressourceCompteImsUrl), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.ressourceCompteImsModifierStatutAllocation(_tracabilite, idRessource, idSt, statut);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, PARAM_ID_RESSOURCE, idRessource);
    checkQueryParams(queryParamsCapture, PARAM_ID_ST, idSt);
    checkQueryParams(queryParamsCapture, PARAM_STATUT, statut);

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test KO for the method {@link RESConnector#ressourceCompteMailCreer(Tracabilite, Ressource)} httpStatus 200, with
   * retourKO
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testRessourceCompteMailCreer_KO_001() throws Exception
  {

    final RessourceCompteMail ressourceCompteMail = _podam.manufacturePojo(RessourceCompteMail.class);
    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT1, IMegSpiritConsts.DONNEE_INDISPONIBLE, StringConstants.EMPTY_STRING, null);
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(basicResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();

    // construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(_ressourceCompteMailUrl), EasyMock.capture(headersCapture), EasyMock.eq(RavelJsonTools.getInstance().toJson(ressourceCompteMail, RessourceCompteMail.class)), EasyMock.isNull())).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.ressourceCompteMailCreer(_tracabilite, ressourceCompteMail);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test KO for the method {@link RESConnector#ressourceCompteMailCreer(Tracabilite, Ressource)} httpStatus 200,
   * jsonResponse null (throws RavelException)
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testRessourceCompteMailCreer_KO_002() throws Exception
  {

    final RessourceCompteMail ressourceCompteMail = _podam.manufacturePojo(RessourceCompteMail.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();

    // construct response
    final Response response = new ResponseBuilderImpl().status(200).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(_ressourceCompteMailUrl), EasyMock.capture(headersCapture), EasyMock.eq(RavelJsonTools.getInstance().toJson(ressourceCompteMail, RessourceCompteMail.class)), EasyMock.isNull())).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    ConnectorResponse<Retour, Nothing> result = null;

    PowerMock.replayAll();
    result = _connector.ressourceCompteMailCreer(_tracabilite, ressourceCompteMail);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, JSON_ERROR_MESSAGE, null);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test KO for the method {@link RESConnector#ressourceCompteMailCreer(Tracabilite, Ressource)} httpStatus 500,
   * jsonResponse null (throws RavelException)
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testRessourceCompteMailCreer_KO_003() throws Exception
  {

    final RessourceCompteMail ressourceCompteMail = _podam.manufacturePojo(RessourceCompteMail.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();

    // construct response
    final Response response = new ResponseBuilderImpl().status(500).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(_ressourceCompteMailUrl), EasyMock.capture(headersCapture), EasyMock.eq(RavelJsonTools.getInstance().toJson(ressourceCompteMail, RessourceCompteMail.class)), EasyMock.isNull())).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    ConnectorResponse<Retour, Nothing> result = null;

    PowerMock.replayAll();
    result = _connector.ressourceCompteMailCreer(_tracabilite, ressourceCompteMail);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, JSON_ERROR_MESSAGE, null);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test OK for the method {@link RESConnector#ressourceCompteMailCreer(Tracabilite, Ressource)} with httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testRessourceCompteMailCreer_OK_001() throws Exception
  {

    final RessourceCompteMail ressourceCompteMail = _podam.manufacturePojo(RessourceCompteMail.class);
    final Retour retour = RetourFactoryForTU.createOkRetour();
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(basicResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();

    // construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(_ressourceCompteMailUrl), EasyMock.capture(headersCapture), EasyMock.eq(RavelJsonTools.getInstance().toJson(ressourceCompteMail, RessourceCompteMail.class)), EasyMock.isNull())).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.ressourceCompteMailCreer(_tracabilite, ressourceCompteMail);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    Assert.assertEquals(retour, result._first);
  }

  /**
   * Test KO for the method
   * {@link RESConnector#ressourceCompteMailModifierStatutAllocation(Tracabilite, String, String, String)}
   *
   * Expected : Retour KO, CAT-4, DONNEE_INCONNUE, "ressourceCompteMail xxx inconnue"
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testRessourceCompteMailModifierStatutAllocation_KO_001() throws Exception
  {

    final String idRessource = RandomStringUtils.randomAlphabetic(5);
    final String idSt = RandomStringUtils.randomAlphabetic(5);
    final String statut = "TRAITEE"; //$NON-NLS-1$

    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "ressourceCompteMail " + idRessource + " inconnue", null); //$NON-NLS-1$ //$NON-NLS-2$
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(basicResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_ressourceCompteMailUrl), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.ressourceCompteMailModifierStatutAllocation(_tracabilite, idRessource, idSt, statut);

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, PARAM_ID_RESSOURCE, idRessource);
    checkQueryParams(queryParamsCapture, PARAM_ID_ST, idSt);
    checkQueryParams(queryParamsCapture, PARAM_STATUT, statut);

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test OK for the method
   * {@link RESConnector#ressourceRaccordementModifierStatutAllocation(Tracabilite, String, String, String)} httpStatus
   * 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testRessourceCompteMailModifierStatutAllocation_OK_001() throws Exception
  {

    final String idRessource = RandomStringUtils.randomAlphabetic(5);
    final String idSt = RandomStringUtils.randomAlphabetic(5);
    final String statut = "TRAITEE"; //$NON-NLS-1$

    final Retour retour = RetourFactoryForTU.createOkRetour();
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(basicResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_ressourceCompteMailUrl), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.ressourceCompteMailModifierStatutAllocation(_tracabilite, idRessource, idSt, statut);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, PARAM_ID_RESSOURCE, idRessource);
    checkQueryParams(queryParamsCapture, PARAM_ID_ST, idSt);
    checkQueryParams(queryParamsCapture, PARAM_STATUT, statut);

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test KO for the method {@link RESConnector#ressourceImpiFixeCreer(Tracabilite, Ressource)} httpStatus 200, with
   * retourKO
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testRessourceImpiFixeCreer_KO_001() throws Exception
  {

    final RessourceImpiFixe ressourceImpiFixe = _podam.manufacturePojo(RessourceImpiFixe.class);
    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT1, IMegSpiritConsts.DONNEE_INDISPONIBLE, StringConstants.EMPTY_STRING, null);
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(basicResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();

    // construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(_ressourceImpiFixeUrl), EasyMock.capture(headersCapture), EasyMock.eq(RavelJsonTools.getInstance().toJson(ressourceImpiFixe, RessourceImpiFixe.class)), EasyMock.isNull())).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.ressourceImpiFixeCreer(_tracabilite, ressourceImpiFixe);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test KO for the method {@link RESConnector#ressourceImpiFixeCreer(Tracabilite, Ressource)} httpStatus 200,
   * jsonResponse null (throws RavelException)
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testRessourceImpiFixeCreer_KO_002() throws Exception
  {

    final RessourceImpiFixe ressourceImpiFixe = _podam.manufacturePojo(RessourceImpiFixe.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();

    // construct response
    final Response response = new ResponseBuilderImpl().status(200).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(_ressourceImpiFixeUrl), EasyMock.capture(headersCapture), EasyMock.eq(RavelJsonTools.getInstance().toJson(ressourceImpiFixe, RessourceImpiFixe.class)), EasyMock.isNull())).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    ConnectorResponse<Retour, Nothing> result = null;

    PowerMock.replayAll();
    result = _connector.ressourceImpiFixeCreer(_tracabilite, ressourceImpiFixe);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, JSON_ERROR_MESSAGE, null);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test KO for the method {@link RESConnector#ressourceImpiFixeCreer(Tracabilite, Ressource)} httpStatus 500,
   * jsonResponse null (throws RavelException)
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testRessourceImpiFixeCreer_KO_003() throws Exception
  {

    final RessourceImpiFixe ressourceImpiFixe = _podam.manufacturePojo(RessourceImpiFixe.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();

    // construct response
    final Response response = new ResponseBuilderImpl().status(500).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(_ressourceImpiFixeUrl), EasyMock.capture(headersCapture), EasyMock.eq(RavelJsonTools.getInstance().toJson(ressourceImpiFixe, RessourceImpiFixe.class)), EasyMock.isNull())).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    ConnectorResponse<Retour, Nothing> result = null;

    PowerMock.replayAll();
    result = _connector.ressourceImpiFixeCreer(_tracabilite, ressourceImpiFixe);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, JSON_ERROR_MESSAGE, null);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test OK for the method {@link RESConnector#ressourceImpiFixeCreer(Tracabilite, Ressource)} with httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testRessourceImpiFixeCreer_OK_001() throws Exception
  {

    final RessourceImpiFixe ressourceImpiFixe = _podam.manufacturePojo(RessourceImpiFixe.class);
    final Retour retour = RetourFactoryForTU.createOkRetour();
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(basicResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();

    // construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(_ressourceImpiFixeUrl), EasyMock.capture(headersCapture), EasyMock.eq(RavelJsonTools.getInstance().toJson(ressourceImpiFixe, RessourceImpiFixe.class)), EasyMock.isNull())).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.ressourceImpiFixeCreer(_tracabilite, ressourceImpiFixe);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    Assert.assertEquals(retour, result._first);
  }

  /**
   * Test KO for the method
   * {@link RESConnector#ressourceImpiFixeModifierStatutAllocation(Tracabilite, String, String, String)}
   *
   * Expected : Retour KO, CAT-4, DONNEE_INCONNUE, "ressourceCompteMail xxx inconnue"
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testRessourceImpiFixeModifierStatutAllocation_KO_001() throws Exception
  {

    final String idRessource = RandomStringUtils.randomAlphabetic(5);
    final String idSt = RandomStringUtils.randomAlphabetic(5);
    final String statut = "TRAITEE"; //$NON-NLS-1$

    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "ressourceCompteMail " + idRessource + " inconnue", null); //$NON-NLS-1$ //$NON-NLS-2$
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(basicResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_ressourceImpiFixeUrl), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.ressourceImpiFixeModifierStatutAllocation(_tracabilite, idRessource, idSt, statut);

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, PARAM_ID_RESSOURCE, idRessource);
    checkQueryParams(queryParamsCapture, PARAM_ID_ST, idSt);
    checkQueryParams(queryParamsCapture, PARAM_STATUT, statut);

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test OK for the method
   * {@link RESConnector#ressourceImpiFixeModifierStatutAllocation(Tracabilite, String, String, String)} httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testRessourceImpiFixeModifierStatutAllocation_OK_001() throws Exception
  {

    final String idRessource = RandomStringUtils.randomAlphabetic(5);
    final String idSt = RandomStringUtils.randomAlphabetic(5);
    final String statut = "TRAITEE"; //$NON-NLS-1$

    final Retour retour = RetourFactoryForTU.createOkRetour();
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(basicResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_ressourceImpiFixeUrl), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.ressourceImpiFixeModifierStatutAllocation(_tracabilite, idRessource, idSt, statut);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, PARAM_ID_RESSOURCE, idRessource);
    checkQueryParams(queryParamsCapture, PARAM_ID_ST, idSt);
    checkQueryParams(queryParamsCapture, PARAM_STATUT, statut);

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method {@link RESConnector#ressourceLireUn(Tracabilite, String, String)} httpStatus 200 Retour KO with
   * idRessource inconnu
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testRessourceLireUn_KO_001() throws Exception
  {

    final String idRessource = RandomStringUtils.randomAlphabetic(5);
    final String typeRessource = "RACCO"; //$NON-NLS-1$
    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "idRessource " + idRessource + " inconnu", null); //$NON-NLS-1$ //$NON-NLS-2$
    List<Ressource> listRessource = new ArrayList<>();

    final GetRessourceResponse getCommandeResponse = new GetRessourceResponse(RetourConverter.convertToJsonRetour(retour), listRessource);
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(getCommandeResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_ressourceUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Ressource> result = _connector.ressourceLireUn(_tracabilite, idRessource, typeRessource);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, PARAM_ID_RESSOURCE, idRessource);
    checkQueryParams(queryParamsCapture, PARAM_TYPE_RESSOURCE, typeRessource);

    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method {@link RESConnector#ressourceLireUn(Tracabilite, String, String)} httpStatus 200 jsonResponse null
   * (throws RavelException)
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testRessourceLireUn_KO_002() throws Exception
  {

    final String idRessource = RandomStringUtils.randomAlphabetic(5);
    final String typeRessource = "RACCO"; //$NON-NLS-1$

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).build();

    // test scenario
    RessourceService ressourceService = new RessourceService(_connector);
    JUnitTools.setInaccessibleFieldValue(_connector, "_ressourceService", ressourceService); //$NON-NLS-1$

    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_ressourceUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    ConnectorResponse<Retour, Ressource> result = null;

    // Call connector
    PowerMock.replayAll();
    result = _connector.ressourceLireUn(_tracabilite, idRessource, typeRessource);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, PARAM_ID_RESSOURCE, idRessource);
    checkQueryParams(queryParamsCapture, PARAM_TYPE_RESSOURCE, typeRessource);

    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, JSON_ERROR_MESSAGE, null);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test OK for the method {@link RESConnector#ressourceLireUn(Tracabilite, String, String)} httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testRessourceLireUn_OK_001() throws Exception
  {

    final RessourceCompteMail ressource = _podam.manufacturePojo(RessourceCompteMail.class);
    final Retour retour = RetourFactoryForTU.createOkRetour();
    final GetRessourceResponse getCommandeResponse = new GetRessourceResponse(RetourConverter.convertToJsonRetour(retour), ressource); //FIXME
    final String partnerResponse = this.serializeWithMoshi(getCommandeResponse, GetRessourceResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_ressourceUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Ressource> result = _connector.ressourceLireUn(_tracabilite, ressource.getIdRessource(), ressource.getTypeRessource());
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, PARAM_ID_RESSOURCE, ressource.getIdRessource());
    checkQueryParams(queryParamsCapture, PARAM_TYPE_RESSOURCE, ressource.getTypeRessource());

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertEquals(ressource, result._second);
  }

  /**
   * Test KO for the method {@link RESConnector#ressourceCompteImsCreer(Tracabilite, Ressource)} httpStatus 200, with
   * retourKO
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testRessourceMotDePasseImsCreer_KO_001() throws Exception
  {

    final RessourceMotDePasseIms ressourceMotDePasseIms = _podam.manufacturePojo(RessourceMotDePasseIms.class);
    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT1, IMegSpiritConsts.DONNEE_INDISPONIBLE, StringConstants.EMPTY_STRING, null);
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(basicResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();

    // construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(_ressourceMotDePasseImsUrl), EasyMock.capture(headersCapture), EasyMock.eq(RavelJsonTools.getInstance().toJson(ressourceMotDePasseIms, RessourceMotDePasseIms.class)), EasyMock.isNull())).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.ressourceMotDePasseImsCreer(_tracabilite, ressourceMotDePasseIms);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test KO for the method {@link RESConnector#ressourceMotDePasseImsCreer(Tracabilite, Ressource)} httpStatus 200,
   * jsonResponse null (throws RavelException)
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testRessourceMotDePasseImsCreer_KO_002() throws Exception
  {

    final RessourceMotDePasseIms ressourceMotDePasseIms = _podam.manufacturePojo(RessourceMotDePasseIms.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();

    // construct response
    final Response response = new ResponseBuilderImpl().status(200).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(_ressourceMotDePasseImsUrl), EasyMock.capture(headersCapture), EasyMock.eq(RavelJsonTools.getInstance().toJson(ressourceMotDePasseIms, RessourceMotDePasseIms.class)), EasyMock.isNull())).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    ConnectorResponse<Retour, Nothing> result = null;

    PowerMock.replayAll();
    result = _connector.ressourceMotDePasseImsCreer(_tracabilite, ressourceMotDePasseIms);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, JSON_ERROR_MESSAGE, null);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test KO for the method {@link RESConnector#ressourceMotDePasseImsCreer(Tracabilite, Ressource)} httpStatus 500,
   * jsonResponse null (throws RavelException)
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testRessourceMotDePasseImsCreer_KO_003() throws Exception
  {

    final RessourceMotDePasseIms ressourceMotDePasseIms = _podam.manufacturePojo(RessourceMotDePasseIms.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();

    // construct response
    final Response response = new ResponseBuilderImpl().status(500).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(_ressourceMotDePasseImsUrl), EasyMock.capture(headersCapture), EasyMock.eq(RavelJsonTools.getInstance().toJson(ressourceMotDePasseIms, RessourceMotDePasseIms.class)), EasyMock.isNull())).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    ConnectorResponse<Retour, Nothing> result = null;

    PowerMock.replayAll();
    result = _connector.ressourceMotDePasseImsCreer(_tracabilite, ressourceMotDePasseIms);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, JSON_ERROR_MESSAGE, null);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test OK for the method {@link RESConnector#ressourceMotDePasseImsCreer(Tracabilite, Ressource)} with httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testRessourceMotDePasseImsCreer_OK_001() throws Exception
  {

    final RessourceMotDePasseIms ressourceMotDePasseIms = _podam.manufacturePojo(RessourceMotDePasseIms.class);
    final Retour retour = RetourFactoryForTU.createOkRetour();
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(basicResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();

    // construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.post(EasyMock.eq(_ressourceMotDePasseImsUrl), EasyMock.capture(headersCapture), EasyMock.eq(RavelJsonTools.getInstance().toJson(ressourceMotDePasseIms, RessourceMotDePasseIms.class)), EasyMock.isNull())).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.ressourceMotDePasseImsCreer(_tracabilite, ressourceMotDePasseIms);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    Assert.assertEquals(retour, result._first);
  }

  /**
   * Test KO for the method
   * {@link RESConnector#ressourceMotDePasseImsModifierStatutAllocation(Tracabilite, String, String, String)}
   *
   * Expected : Retour KO, CAT-4, DONNEE_INCONNUE, "ressourceCompteMail xxx inconnue"
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testRessourceMotDePasseImsModifierStatutAllocation_KO_001() throws Exception
  {

    final String idRessource = RandomStringUtils.randomAlphabetic(5);
    final String idSt = RandomStringUtils.randomAlphabetic(5);
    final String statut = "TRAITEE"; //$NON-NLS-1$

    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "ressourceCompteMail " + idRessource + " inconnue", null); //$NON-NLS-1$ //$NON-NLS-2$
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(basicResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_ressourceMotDePasseImsUrl), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.ressourceMotDePasseImsModifierStatutAllocation(_tracabilite, idRessource, idSt, statut);

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, PARAM_ID_RESSOURCE, idRessource);
    checkQueryParams(queryParamsCapture, PARAM_ID_ST, idSt);
    checkQueryParams(queryParamsCapture, PARAM_STATUT, statut);

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test OK for the method
   * {@link RESConnector#ressourceMotDePasseImsModifierStatutAllocation(Tracabilite, String, String, String)} httpStatus
   * 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testRessourceMotDePasseImsModifierStatutAllocation_OK_001() throws Exception
  {

    final String idRessource = RandomStringUtils.randomAlphabetic(5);
    final String idSt = RandomStringUtils.randomAlphabetic(5);
    final String statut = "TRAITEE"; //$NON-NLS-1$

    final Retour retour = RetourFactoryForTU.createOkRetour();
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(basicResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_ressourceMotDePasseImsUrl), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.ressourceMotDePasseImsModifierStatutAllocation(_tracabilite, idRessource, idSt, statut);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, PARAM_ID_RESSOURCE, idRessource);
    checkQueryParams(queryParamsCapture, PARAM_ID_ST, idSt);
    checkQueryParams(queryParamsCapture, PARAM_STATUT, statut);

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test KO for the method
   * {@link RESConnector#ressourceAdresseIpClfModifierStatutAllocation(Tracabilite, String, String, String)}
   *
   * Expected : Retour KO, CAT-4, DONNEE_INCONNUE, "ressourceCompteMail xxx inconnue"
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testRessourceOntIdGererLiberaion_KO_001() throws Exception
  {

    final String idRessource = RandomStringUtils.randomAlphabetic(5);
    final String idRessourceLie = RandomStringUtils.randomAlphabetic(5);

    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "ressourceCompteMail " + idRessource + " inconnue", null); //$NON-NLS-1$ //$NON-NLS-2$
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(basicResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_ressourceOntIdUrl), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.ressourceOntIdGererLiberation(_tracabilite, idRessource, idRessourceLie);

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, PARAM_ID_RESSOURCE, idRessource);
    checkQueryParams(queryParamsCapture, PARAM_ID_RESSOURCELIE, idRessourceLie);

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test OK for the method
   * {@link RESConnector#ressourceAdresseIpClfModifierStatutAllocation(Tracabilite, String, String, String)} httpStatus
   * 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testRessourceOntIdGererLiberaion_OK_001() throws Exception
  {

    final String idRessource = RandomStringUtils.randomAlphabetic(5);
    final String idRessourceLie = RandomStringUtils.randomAlphabetic(5);

    final Retour retour = RetourFactoryForTU.createOkRetour();
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(basicResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(_ressourceOntIdUrl), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, Nothing> result = _connector.ressourceOntIdGererLiberation(_tracabilite, idRessource, idRessourceLie);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, PARAM_ID_RESSOURCE, idRessource);
    checkQueryParams(queryParamsCapture, PARAM_ID_RESSOURCELIE, idRessourceLie);

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test KO for the method {@link IRES#ressourcePortPmGererAllocation}
   *
   * Expected : Retour KO, CAT-4, DONNEE_INCONNUE, "ressourceCompteMail xxx inconnue"
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testRessourcePortPmGererAllocation_KO_001() throws Exception
  {
    // Request parameters
    final String referencePmBytel = RandomStringUtils.randomAlphabetic(5);
    final String referencePmOi = RandomStringUtils.randomAlphabetic(5);
    final String referenceBoitierPm = RandomStringUtils.randomAlphabetic(5);
    final String nomPmTechnique = RandomStringUtils.randomAlphabetic(5);
    final String nomPanneauPm = RandomStringUtils.randomAlphabetic(5);
    final int positionPortPm = 0;
    final String technologiePON = RandomStringUtils.randomAlphabetic(5);
    final String idRessourceLie = RandomStringUtils.randomAlphabetic(5);

    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "ressourceCompteMail " + idRessourceLie + " inconnue", null); //$NON-NLS-1$ //$NON-NLS-2$
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = RavelJsonTools.getInstance().toJson(basicResponse, BasicResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(null), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();

    final ConnectorResponse<Retour, RessourcePortPM> result = _connector.ressourcePortPmGererAllocation(_tracabilite, referencePmBytel, referencePmOi, referenceBoitierPm, nomPmTechnique, nomPanneauPm, positionPortPm, technologiePON, idRessourceLie);
    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test OK for the method {@link IRES#ressourcePortPmGererAllocation} httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testRessourcePortPmGererAllocation_OK_001() throws Exception
  {
    final String referencePmBytel = RandomStringUtils.randomAlphabetic(5);
    final String referencePmOi = RandomStringUtils.randomAlphabetic(5);
    final String referenceBoitierPm = RandomStringUtils.randomAlphabetic(5);
    final String nomPmTechnique = RandomStringUtils.randomAlphabetic(5);
    final String nomPanneauPm = RandomStringUtils.randomAlphabetic(5);
    final int positionPortPm = 0;
    final String technologiePON = RandomStringUtils.randomAlphabetic(5);
    final String idRessourceLie = RandomStringUtils.randomAlphabetic(5);

    final Retour retour = RetourFactoryForTU.createOkRetour();
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = RavelJsonTools.getInstance().toJson(basicResponse, BasicResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(null), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, RessourcePortPM> result = _connector.ressourcePortPmGererAllocation(_tracabilite, referencePmBytel, referencePmOi, referenceBoitierPm, nomPmTechnique, nomPanneauPm, positionPortPm, technologiePON, idRessourceLie);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test KO for the method {@link RESConnector#ressourcePortPmGererMigrationPortPm}
   *
   * Expected : Retour KO, CAT-4, DONNEE_INCONNUE, "ressourceCompteMail xxx inconnue"
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testRessourcePortPmGererMigrationPortPm_KO_001() throws Exception
  {
    final String idRessource = RandomStringUtils.randomAlphabetic(5);
    final String referencePmBytel = RandomStringUtils.randomAlphabetic(5);
    final String referencePmOi = RandomStringUtils.randomAlphabetic(5);
    final String referenceBoitierPm = RandomStringUtils.randomAlphabetic(5);
    final String nomPmTechnique = RandomStringUtils.randomAlphabetic(5);
    final String nomPanneauPm = RandomStringUtils.randomAlphabetic(5);
    final int positionPortPm = 0;
    final String technologiePON = RandomStringUtils.randomAlphabetic(5);
    final String idRessourceLie = RandomStringUtils.randomAlphabetic(5);
    final String motifMigration = RandomStringUtils.randomAlphabetic(5);

    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "ressourceCompteMail " + idRessource + " inconnue", null); //$NON-NLS-1$ //$NON-NLS-2$
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = RavelJsonTools.getInstance().toJson(basicResponse, BasicResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(null), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, RessourcePortPM> result = _connector.ressourcePortPmGererMigrationPortPm(_tracabilite, idRessource, motifMigration, referencePmBytel, referencePmOi, referenceBoitierPm, nomPmTechnique, nomPanneauPm, positionPortPm, technologiePON, idRessourceLie);
    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test OK for the method {@link RESConnector#ressourcePortPmGererMigrationPortPm}. httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testRessourcePortPmGererMigrationPortPm_OK_001() throws Exception
  {

    final String idRessource = RandomStringUtils.randomAlphabetic(5);
    final String referencePmBytel = RandomStringUtils.randomAlphabetic(5);
    final String referencePmOi = RandomStringUtils.randomAlphabetic(5);
    final String referenceBoitierPm = RandomStringUtils.randomAlphabetic(5);
    final String nomPmTechnique = RandomStringUtils.randomAlphabetic(5);
    final String nomPanneauPm = RandomStringUtils.randomAlphabetic(5);
    final int positionPortPm = 0;
    final String technologiePON = RandomStringUtils.randomAlphabetic(5);
    final String idRessourceLie = RandomStringUtils.randomAlphabetic(5);
    final String motifMigration = RandomStringUtils.randomAlphabetic(5);

    final Retour retour = RetourFactoryForTU.createOkRetour();
    final BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour));
    final String partnerResponse = RavelJsonTools.getInstance().toJson(basicResponse, BasicResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.put(EasyMock.eq(null), EasyMock.capture(headersCapture), EasyMock.eq(null), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, RessourcePortPM> result = _connector.ressourcePortPmGererMigrationPortPm(_tracabilite, idRessource, motifMigration, referencePmBytel, referencePmOi, referenceBoitierPm, nomPmTechnique, nomPanneauPm, positionPortPm, technologiePON, idRessourceLie);

    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method {@link RESConnector#ressourceLireUn(Tracabilite, String, String)} httpStatus 200 Retour KO with
   * idRessource inconnu
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testRessourceRaccordementCompositeGererAnalyseModif_RR_KO_001() throws Exception
  {

    final String idRRSource = RandomStringUtils.randomAlphabetic(5);
    final String idRRCible = RandomStringUtils.randomAlphabetic(5);
    final String action = RandomStringUtils.randomAlphabetic(5);

    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "RessourceRaccordementComposite  " + idRRSource + " inconnu", null); //$NON-NLS-1$ //$NON-NLS-2$
    final GetRessourceRaccordementResponse getRessourceRaccordementResponse = new GetRessourceRaccordementResponse(RetourConverter.convertToJsonRetour(retour), null);
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(getRessourceRaccordementResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_manageRessourceRaccordementCompositeUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, String> result = _connector.ressourceRaccordementCompositeGererAnalyserModifRR(_tracabilite, idRRSource, idRRCible, action);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, PARAM_ID_SOURCE, idRRSource);
    checkQueryParams(queryParamsCapture, PARAM_ID_RR_CIBLE, idRRCible);
    checkQueryParams(queryParamsCapture, ACTION, action);

    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method {@link RESConnector#ressourceLireUn(Tracabilite, String, String)} httpStatus 200 jsonResponse null
   * (throws RavelException)
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testRessourceRaccordementCompositeGererAnalyseModif_RR_KO_002() throws Exception
  {

    final String idRRSource = RandomStringUtils.randomAlphabetic(5);
    final String idRRCible = RandomStringUtils.randomAlphabetic(5);
    final String action = RandomStringUtils.randomAlphabetic(5);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_manageRessourceRaccordementCompositeUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    ConnectorResponse<Retour, String> result = null;

    // Call connector
    PowerMock.replayAll();
    result = _connector.ressourceRaccordementCompositeGererAnalyserModifRR(_tracabilite, idRRSource, idRRCible, action);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, PARAM_ID_SOURCE, idRRSource);
    checkQueryParams(queryParamsCapture, PARAM_ID_RR_CIBLE, idRRCible);
    checkQueryParams(queryParamsCapture, ACTION, action);

    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, JSON_ERROR_MESSAGE, null);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test OK for the method
   * {@link RESConnector#ressourceRaccordementCompositeGererAnalyserModifRR(Tracabilite, String, String, String)} with
   * httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testRessourceRaccordementCompositeGererAnalyseModif_RR_OK_001() throws Exception
  {

    final String idRRSource = RandomStringUtils.randomAlphabetic(5);
    final String idRRCible = RandomStringUtils.randomAlphabetic(5);
    final String action = RandomStringUtils.randomAlphabetic(5);

    final String typeModif = "PROFIL"; //$NON-NLS-1$
    final Retour retour = RetourFactoryForTU.createOkRetour();
    final GetRessourceRaccordementResponse getRessourceRaccordementResponse = new GetRessourceRaccordementResponse(RetourConverter.convertToJsonRetour(retour), typeModif); //FIXME
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(getRessourceRaccordementResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_manageRessourceRaccordementCompositeUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, String> result = _connector.ressourceRaccordementCompositeGererAnalyserModifRR(_tracabilite, idRRSource, idRRCible, action);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, PARAM_ID_SOURCE, idRRSource);
    checkQueryParams(queryParamsCapture, PARAM_ID_RR_CIBLE, idRRCible);
    checkQueryParams(queryParamsCapture, ACTION, action);

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertEquals(typeModif, result._second);
  }

  /**
   * Test the method {@link RESConnector#ressourceRaccordementCompositeLireUn(Tracabilite, String)} httpStatus 200
   * Retour KO with idRessourceRaccordementComposite inconnu
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testRessourceRaccordementCompositeLireUn_KO_001() throws Exception
  {

    final String idRessourceRaccordementComposite = RandomStringUtils.randomAlphabetic(5);
    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "idRessourceRaccordementComposite " + idRessourceRaccordementComposite + " inconnu", null); //$NON-NLS-1$ //$NON-NLS-2$
    final GetRessourceRaccordementCompositeResponse getCommandeResponse = new GetRessourceRaccordementCompositeResponse(RetourConverter.convertToJsonRetour(retour), null);
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(getCommandeResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_ressourceRaccordementCompositeUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, RessourceRaccordementComposite> result = _connector.ressourceRaccordementCompositeLireUn(_tracabilite, idRessourceRaccordementComposite);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, PARAM_ID_RESSOURCE, idRessourceRaccordementComposite);

    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method {@link RESConnector#ressourceRaccordementCompositeLireUn(Tracabilite, String)} httpStatus 200
   * jsonResponse null (throws RavelException)
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testRessourceRaccordementCompositeLireUn_KO_002() throws Exception
  {

    final String idRessourceRaccordementComposite = RandomStringUtils.randomAlphabetic(5);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_ressourceRaccordementCompositeUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    ConnectorResponse<Retour, RessourceRaccordementComposite> result = null;

    // Call connector
    PowerMock.replayAll();
    result = _connector.ressourceRaccordementCompositeLireUn(_tracabilite, idRessourceRaccordementComposite);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    checkQueryParams(queryParamsCapture, PARAM_ID_RESSOURCE, idRessourceRaccordementComposite);

    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, JSON_ERROR_MESSAGE, null);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test OK for the method {@link RESConnector#ressourceRaccordementCompositeLireUn(Tracabilite, String)} httpStatus
   * 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void testRessourceRaccordementCompositeLireUn_OK_001() throws Exception
  {

    final RessourceRaccordementComposite ressource = new RessourceRaccordementComposite(new RessourceRaccordementP2P(RandomStringUtils.randomAlphabetic(10), RandomStringUtils.randomAlphabetic(10), RandomStringUtils.randomAlphabetic(10)), _podam.manufacturePojo(AccesTechnique.class));
    final Retour retour = RetourFactoryForTU.createOkRetour();
    final GetRessourceRaccordementCompositeResponse getCommandeResponse = new GetRessourceRaccordementCompositeResponse(RetourConverter.convertToJsonRetour(retour), ressource); //FIXME
    final String partnerResponse = GsonTools.getIso8601Ms().toJson(getCommandeResponse);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_ressourceRaccordementCompositeUrl), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, RessourceRaccordementComposite> result = _connector.ressourceRaccordementCompositeLireUn(_tracabilite, ressource.getRessource().getIdRessource());
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, PARAM_ID_RESSOURCE, ressource.getRessource().getIdRessource());

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertEquals(ressource, result._second);
  }

  /**
   * Test OK for the method {@link RESConnector#topologieArcturusLireUn(Tracabilite, String)} httpStatus 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void topologieArcturusLire_Test_OK_001() throws Exception
  {

    final String valeurIdentifiant = RandomStringUtils.randomAlphanumeric(13);
    final TopologieArcturus topologieArcturus = _podam.manufacturePojoWithFullData(TopologieArcturus.class);
    final List<TopologieArcturus> topologieArcturusList = new ArrayList<>();
    topologieArcturusList.add(topologieArcturus);
    final Retour retour = RetourFactoryForTU.createOkRetour();
    final GetTopologieArcturusResponse getTopologieArcturusResponse = new GetTopologieArcturusResponse(RetourConverter.convertToJsonRetour(retour), topologieArcturusList);

    final String partnerResponse = RavelJsonTools.getInstance().toJson(getTopologieArcturusResponse, GetTopologieArcturusResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_topologieArcturus), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, TopologieArcturus> result = _connector.topologieArcturusLireUn(_tracabilite, valeurIdentifiant);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, PARAM_ID_NOM_COLLECTE, valeurIdentifiant);

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertEquals(topologieArcturus, result._second);
  }

  /**
   * Test the method {@link RESConnector#topologieArcturusLireTousParIdEqptAcces(Tracabilite, String)} httpStatus 200
   * Retour KO with "lecture indisponible"
   *
   * Expected : Retour KO, CAT-1, LECTURE_INDISPONIBLE, "Unexpected error in res database connector: Test Error"
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void topologieArcturusLireTousParIdEqptAcces_Test_KO_001() throws Exception
  {

    final String idEqptAcces = RandomStringUtils.randomAlphanumeric(13);
    final String message = MessageFormat.format(Messages.getString("res.unexpectedError"), "Test Error"); //$NON-NLS-1$ //$NON-NLS-2$
    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT1, IMegSpiritConsts.LECTURE_INDISPONIBLE, message, null);
    final GetTopologieArcturusResponse getTopologieArcturusResponse = new GetTopologieArcturusResponse(RetourConverter.convertToJsonRetour(retour), null);
    final String partnerResponse = RavelJsonTools.getInstance().toJson(getTopologieArcturusResponse, GetTopologieArcturusResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_topologieArcturus), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<TopologieArcturus>> result = _connector.topologieArcturusLireTousParIdEqptAcces(_tracabilite, idEqptAcces);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, PARAM_ID_EQPT_ACCES, idEqptAcces);

    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method {@link RESConnector#topologieArcturusLireTousParIdEqptAcces(Tracabilite, String)} httpStatus 200
   * jsonResponse null (throws RavelException)
   *
   * Expected : null JsonResponse - Retour KO, CAT-10, TRAITEMENT_ARRETE, "Impossible de récupérer la réponse"
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void topologieArcturusLireTousParIdEqptAcces_Test_KO_002() throws Exception
  {

    final String valeurIdentifiant = RandomStringUtils.randomAlphanumeric(13);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_topologieArcturus), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    // Call connector
    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<TopologieArcturus>> result = _connector.topologieArcturusLireTousParIdEqptAcces(_tracabilite, valeurIdentifiant);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, PARAM_ID_EQPT_ACCES, valeurIdentifiant);

    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, JSON_ERROR_MESSAGE, null);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test OK for the method {@link RESConnector#topologieArcturusLireTousParIdEqptAcces(Tracabilite, String)} httpStatus
   * 200
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void topologieArcturusLireTousParIdEqptAcces_Test_OK_001() throws Exception
  {

    final String valeurIdentifiant = RandomStringUtils.randomAlphanumeric(13);
    final TopologieArcturus topologieArcturus = _podam.manufacturePojoWithFullData(TopologieArcturus.class);
    final List<TopologieArcturus> topologieArcturusList = new ArrayList<>();
    topologieArcturusList.add(topologieArcturus);
    final Retour retour = RetourFactoryForTU.createOkRetour();
    final GetTopologieArcturusResponse getTopologieArcturusResponse = new GetTopologieArcturusResponse(RetourConverter.convertToJsonRetour(retour), topologieArcturusList);

    final String partnerResponse = RavelJsonTools.getInstance().toJson(getTopologieArcturusResponse, GetTopologieArcturusResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_topologieArcturus), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, List<TopologieArcturus>> result = _connector.topologieArcturusLireTousParIdEqptAcces(_tracabilite, valeurIdentifiant);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, PARAM_ID_EQPT_ACCES, valeurIdentifiant);

    //check result
    Assert.assertEquals(retour, result._first);
    Assert.assertEquals(topologieArcturusList, result._second);
  }

  /**
   * Test the method {@link RESConnector#topologieArcturusLireUn(Tracabilite, String)} httpStatus 200 Retour KO with
   * "lecture indisponible"
   *
   * Expected : Retour KO, CAT-1, LECTURE_INDISPONIBLE, "Unexpected error in res database connector: Test Error"
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void topologieArcturusLireUn_Test_KO_001() throws Exception
  {

    final String nomCollecte = RandomStringUtils.randomAlphanumeric(13);
    final String message = MessageFormat.format(Messages.getString("res.unexpectedError"), "Test Error"); //$NON-NLS-1$ //$NON-NLS-2$
    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT1, IMegSpiritConsts.LECTURE_INDISPONIBLE, message, null);
    final GetTopologieArcturusResponse getTopologieArcturusResponse = new GetTopologieArcturusResponse(RetourConverter.convertToJsonRetour(retour), null);
    final String partnerResponse = RavelJsonTools.getInstance().toJson(getTopologieArcturusResponse, GetTopologieArcturusResponse.class);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_topologieArcturus), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    PowerMock.replayAll();
    final ConnectorResponse<Retour, TopologieArcturus> result = _connector.topologieArcturusLireUn(_tracabilite, nomCollecte);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, PARAM_ID_NOM_COLLECTE, nomCollecte);

    Assert.assertEquals(retour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * Test the method {@link RESConnector#topologieArcturusLireUn(Tracabilite, String)} httpStatus 200 jsonResponse null
   * (throws RavelException)
   *
   * Expected : null JsonResponse - Retour KO, CAT-10, TRAITEMENT_ARRETE, "Impossible de récupérer la réponse"
   *
   * @throws Exception
   *           thrown in case of error
   */
  @Test
  public void topologieArcturusLireUn_Test_KO_002() throws Exception
  {

    final String valeurIdentifiant = RandomStringUtils.randomAlphanumeric(13);

    Capture<MultivaluedMap<String, String>> headersCapture = Capture.newInstance();
    Capture<Map<String, String>> queryParamsCapture = Capture.newInstance();

    //construct response
    final Response response = new ResponseBuilderImpl().status(200).build();

    // test scenario
    initializeMocksForSendRequest();
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(EasyMock.eq(_topologieArcturus), EasyMock.capture(headersCapture), EasyMock.capture(queryParamsCapture))).andReturn(response);
    _restConnectorPoolMock.returnObject(_restInstanceMock);

    // Call connector
    PowerMock.replayAll();
    final ConnectorResponse<Retour, TopologieArcturus> result = _connector.topologieArcturusLireUn(_tracabilite, valeurIdentifiant);
    PowerMock.verifyAll();

    // check header
    Assert.assertNotNull(headersCapture.getValue());

    //check params sent
    checkQueryParams(queryParamsCapture, PARAM_ID_NOM_COLLECTE, valeurIdentifiant);

    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, JSON_ERROR_MESSAGE, null);
    Assert.assertEquals(expectedRetour, result._first);
    Assert.assertNull(result._second);
  }

  /**
   * @param tracabilite_p
   *          _tracabilite
   * @param headersCapture_p
   *          headersCapture
   * @throws Exception
   *           Exception
   */
  private void checkHeader(Tracabilite tracabilite_p, Capture<MultivaluedMap<String, String>> headersCapture_p) throws Exception
  {
    Assert.assertNotNull(headersCapture_p.getValue());
    Assert.assertNotNull(headersCapture_p.getValue().get(IHttpHeadersConsts.X_REQUEST_ID));
    Assert.assertEquals(tracabilite_p.getIdCorrelationByTel(), headersCapture_p.getValue().get(IHttpHeadersConsts.X_REQUEST_ID).get(0));
    Assert.assertNotNull(headersCapture_p.getValue().get(IHttpHeadersConsts.X_REQUEST_ID_SPIRIT));
    Assert.assertEquals(tracabilite_p.getIdCorrelationSpirit(), headersCapture_p.getValue().get(IHttpHeadersConsts.X_REQUEST_ID_SPIRIT).get(0));
    Assert.assertNotNull(headersCapture_p.getValue().get(IHttpHeadersConsts.X_SOURCE));
    Assert.assertEquals(tracabilite_p.getNomSysteme(), headersCapture_p.getValue().get(IHttpHeadersConsts.X_SOURCE).get(0));
    Assert.assertNotNull(headersCapture_p.getValue().get(IHttpHeadersConsts.X_PROCESS));
    Assert.assertEquals(tracabilite_p.getNomProcessus(), headersCapture_p.getValue().get(IHttpHeadersConsts.X_PROCESS).get(0));
    Assert.assertNotNull(headersCapture_p.getValue().get(IHttpHeadersConsts.X_PROCESS_ID_SPIRIT));
    Assert.assertEquals(tracabilite_p.getIdProcessusSpirit(), headersCapture_p.getValue().get(IHttpHeadersConsts.X_PROCESS_ID_SPIRIT).get(0));

    tracabilite_p.getRefFonc().forEach((key, value) -> Assert.assertEquals(value, headersCapture_p.getValue().get(IHttpHeadersConsts.X_TRACE.concat(key)).get(0)));
  }

  /**
   * prepare mock scenario to initialize method sendRequest from AbstractRestConnector
   *
   * @throws Exception
   *           Thrown in case of error
   */
  private void initializeMocksForSendRequest() throws Exception
  {
    final String urlBalancedElementName = RandomStringUtils.randomAlphanumeric(45);
    final String urlBalancedElementDescription = RandomStringUtils.randomAlphabetic(9);

    EasyMock.expect(_loadBalancerMock.chooseBalancedElement()).andReturn(_urlBalancedElementMock);
    EasyMock.expect(_urlBalancedElementMock.getName()).andReturn(urlBalancedElementName);
    EasyMock.expect(_urlBalancedElementMock.getDescription()).andReturn(urlBalancedElementDescription);
    EasyMock.expect(_urlBalancedElementMock.getName()).andReturn(urlBalancedElementName);
    EasyMock.expect(_connectorPoolMock.get(urlBalancedElementName)).andReturn(_restConnectorPoolMock);
    EasyMock.expect(_restConnectorPoolMock.borrowObject()).andReturn(_restInstanceMock);
  }

  /**
   * Serializes the object in obj parameter and returns a string representing the object as json.
   *
   * @param obj
   *          The object to eserialize
   * @param clazz
   *          The class type of the objet to serialize from
   * @return The json String
   * @throws RavelException
   *           If thrown by the Json builder
   */
  private <T> String serializeWithMoshi(T obj, Class<T> clazz) throws RavelException
  {
    IRavelJson jsonBuilder = new RavelJsonBuilder() //
        .profil("STARK")//$NON-NLS-1$
        .build();
    final IRavelJsonAdapter<T> adapter = jsonBuilder.adapter(clazz);

    return adapter.toJson(obj);
  }
}
