/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.res.services;

import java.text.MessageFormat;
import java.util.HashMap;
import java.util.List;

import javax.ws.rs.HttpMethod;
import javax.ws.rs.core.Response;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.connector.RESTRequest;
import com.bytel.spirit.common.connectors.res.IRESConnector;
import com.bytel.spirit.common.connectors.res.RESConnector;
import com.bytel.spirit.common.shared.misc.connectors.AbstractInternalRESTConnector;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.RetourConverter;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.DispoRessourceDSLAxione;
import com.bytel.spirit.common.shared.saab.res.DispoRessourceDSLBouygues;
import com.bytel.spirit.common.shared.saab.res.DispoRessourceDSLOrange;
import com.bytel.spirit.common.shared.saab.res.DispoRessourceDSLSFR;
import com.bytel.spirit.common.shared.saab.res.response.GetDispoRessourceDSLAxioneResponse;
import com.bytel.spirit.common.shared.saab.res.response.GetDispoRessourceDSLBouyguesResponse;
import com.bytel.spirit.common.shared.saab.res.response.GetDispoRessourceDSLOrangeResponse;
import com.bytel.spirit.common.shared.saab.res.response.GetDispoRessourceDSLSFRResponse;

/**
 * @author jbrites
 * @version ($Revision$ $Date$)
 */
public class DispoRessourceDSLService
{
  /** The constant for pad3017_DispoRessourceDSLOrange_Lire service name */
  public static final String METHOD_NAME_PAD3017_DISPO_RESSOURCE_DSL_ORANGE_LIRE = "dispoRessourceDslOrangeLire"; //$NON-NLS-1$
  /** The constant for pad3017_DispoRessourceDSLOrange_LireParNomUra service name */
  public static final String METHOD_NAME_PAD3017_DISPO_RESSOURCE_DSL_ORANGE_LIRE_PAR_NOM_URA = "dispoRessourceDslOrangeLireParNomUra"; //$NON-NLS-1$
  /** The constant for pad3018_DispoRessourceDSLBouygues_Lire service name */
  public static final String METHOD_NAME_PAD3018_DISPO_RESSOURCE_DSL_BOUYGUES_LIRE = "dispoRessourceDslBouyguesLire"; //$NON-NLS-1$
  /** The constant for pad3018_DispoRessourceDSLBouygues_LireParNomUra service name */
  public static final String METHOD_NAME_PAD3018_DISPO_RESSOURCE_DSL_BOUYGUES_LIRE_PAR_NOM_URA = "dispoRessourceDslBouyguesLireParNomUra"; //$NON-NLS-1$
  /** The constant for pad3019_DispoRessourceDSLAxione_Lire service name */
  public static final String METHOD_NAME_PAD3019_DISPO_RESSOURCE_DSL_AXIONE_LIRE = "dispoRessourceDslAxioneLire"; //$NON-NLS-1$
  /** The constant for pad3019_DispoRessourceDSLAxione_LireParNomUra service name */
  public static final String METHOD_NAME_PAD3019_DISPO_RESSOURCE_DSL_AXIONE_LIRE_PAR_NOM_URA = "dispoRessourceDslAxioneLireParNomUra"; //$NON-NLS-1$
  /** The constant for pad3020_DispoRessourceDSLSFR_Lire service name */
  public static final String METHOD_NAME_PAD3020_DISPO_RESSOURCE_DSL_SFR_LIRE = "dispoRessourceDslSFRLire"; //$NON-NLS-1$
  /** The constant for pad3020_DispoRessourceDSLSFR_LireParNomUra service name */
  public static final String METHOD_NAME_PAD3020_DISPO_RESSOURCE_DSL_SFR_LIRE_PAR_NOM_URA = "dispoRessourceDslSFRLireParNomUra"; //$NON-NLS-1$

  private final RESConnector _resInstance;

  /**
   * Default constructor
   *
   * @param resInstance_p
   *          Current RESConnector instance
   */
  public DispoRessourceDSLService(RESConnector resInstance_p)
  {
    _resInstance = resInstance_p;
  }

  /**
   * dispoRessourceDslAxioneLire
   */
  public ConnectorResponse<Retour, List<DispoRessourceDSLAxione>> dispoRessourceDslAxioneLire(Tracabilite tracabilite_p, String dispoRessourceDslBouyguesUrl_p, String nomUraOrange_p, String techno_p, String nbPaire_p, String typeKp_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(dispoRessourceDslBouyguesUrl_p))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(IRESConnector.MESSAGE_MISSING_CONFIGURATION_PARAMETER, IRESConnector.PAD3018_PATH_PARAM));
      }

      // Call SAAB
      final Response response;
      HashMap<String, String> queryParams = new HashMap<>();
      queryParams.put(IRESConnector.PARAM_NOM_URA_ORANGE, nomUraOrange_p);
      queryParams.put(IRESConnector.PARAM_TECHNO, techno_p);
      queryParams.put(IRESConnector.PARAM_NB_PAIRE, nbPaire_p);
      queryParams.put(IRESConnector.PARAM_TYPE_KP, typeKp_p);

      try
      {
        RESTRequest restRequest = new RESTRequest.RESTRequestBuilder()//
            .httpMethod(HttpMethod.GET)//
            .traceability(tracabilite_p)//
            .method(METHOD_NAME_PAD3019_DISPO_RESSOURCE_DSL_AXIONE_LIRE)//
            .headers(AbstractInternalRESTConnector.getSpiritStarkRequestHeader())//
            .path(dispoRessourceDslBouyguesUrl_p)//
            .queryParameter(queryParams)//
            .build();
        response = _resInstance.sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content
      GetDispoRessourceDSLAxioneResponse getDispoRessourceDSLAxioneResponse = _resInstance.getContentFromResponse(tracabilite_p, response, METHOD_NAME_PAD3019_DISPO_RESSOURCE_DSL_AXIONE_LIRE, GetDispoRessourceDSLAxioneResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(getDispoRessourceDSLAxioneResponse.getRetour());
      List<DispoRessourceDSLAxione> listeDispoRessourceDSLAxione = getDispoRessourceDSLAxioneResponse.getListeDispoRessourceDSLAxione();

      return new ConnectorResponse<>(retour, listeDispoRessourceDSLAxione);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  /**
   * dispoRessourceDslAxioneLireParNomUra
   */
  public ConnectorResponse<Retour, List<DispoRessourceDSLAxione>> dispoRessourceDslAxioneLireParNomUra(Tracabilite tracabilite_p, String dispoRessourceDslBouyguesUrl_p, String nomUraOrange_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(dispoRessourceDslBouyguesUrl_p))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(IRESConnector.MESSAGE_MISSING_CONFIGURATION_PARAMETER, IRESConnector.PAD3018_PATH_PARAM));
      }

      // Call SAAB
      final Response response;
      HashMap<String, String> queryParams = new HashMap<>();
      queryParams.put(IRESConnector.PARAM_NOM_URA_ORANGE, nomUraOrange_p);

      try
      {
        RESTRequest restRequest = new RESTRequest.RESTRequestBuilder()//
            .httpMethod(HttpMethod.GET)//
            .traceability(tracabilite_p)//
            .method(METHOD_NAME_PAD3019_DISPO_RESSOURCE_DSL_AXIONE_LIRE_PAR_NOM_URA)//
            .headers(AbstractInternalRESTConnector.getSpiritStarkRequestHeader())//
            .path(dispoRessourceDslBouyguesUrl_p)//
            .queryParameter(queryParams)//
            .build();
        response = _resInstance.sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content
      GetDispoRessourceDSLAxioneResponse getDispoRessourceDSLAxioneResponse = _resInstance.getContentFromResponse(tracabilite_p, response, METHOD_NAME_PAD3019_DISPO_RESSOURCE_DSL_AXIONE_LIRE_PAR_NOM_URA, GetDispoRessourceDSLAxioneResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(getDispoRessourceDSLAxioneResponse.getRetour());
      List<DispoRessourceDSLAxione> listeDispoRessourceDSLAxione = getDispoRessourceDSLAxioneResponse.getListeDispoRessourceDSLAxione();

      return new ConnectorResponse<>(retour, listeDispoRessourceDSLAxione);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  /**
   * dispoRessourceDslBouyguesLire
   */
  public ConnectorResponse<Retour, List<DispoRessourceDSLBouygues>> dispoRessourceDslBouyguesLire(Tracabilite tracabilite_p, String dispoRessourceDslBouyguesUrl_p, String nomUraOrange_p, String techno_p, String nbPaire_p, String typeKp_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(dispoRessourceDslBouyguesUrl_p))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(IRESConnector.MESSAGE_MISSING_CONFIGURATION_PARAMETER, IRESConnector.PAD3018_PATH_PARAM));
      }

      // Call SAAB
      final Response response;
      HashMap<String, String> queryParams = new HashMap<>();
      queryParams.put(IRESConnector.PARAM_NOM_URA_ORANGE, nomUraOrange_p);
      queryParams.put(IRESConnector.PARAM_TECHNO, techno_p);
      queryParams.put(IRESConnector.PARAM_NB_PAIRE, nbPaire_p);
      queryParams.put(IRESConnector.PARAM_TYPE_KP, typeKp_p);

      try
      {
        RESTRequest restRequest = new RESTRequest.RESTRequestBuilder()//
            .httpMethod(HttpMethod.GET)//
            .traceability(tracabilite_p)//
            .method(METHOD_NAME_PAD3018_DISPO_RESSOURCE_DSL_BOUYGUES_LIRE)//
            .headers(AbstractInternalRESTConnector.getSpiritStarkRequestHeader())//
            .path(dispoRessourceDslBouyguesUrl_p)//
            .queryParameter(queryParams)//
            .build();
        response = _resInstance.sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content
      GetDispoRessourceDSLBouyguesResponse getDispoRessourceDSLBouyguesResponse = _resInstance.getContentFromResponse(tracabilite_p, response, METHOD_NAME_PAD3018_DISPO_RESSOURCE_DSL_BOUYGUES_LIRE, GetDispoRessourceDSLBouyguesResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(getDispoRessourceDSLBouyguesResponse.getRetour());
      List<DispoRessourceDSLBouygues> listeDispoRessourceDSLBouygues = getDispoRessourceDSLBouyguesResponse.getListeDispoRessourceDSLBouygues();

      return new ConnectorResponse<>(retour, listeDispoRessourceDSLBouygues);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  /**
   * dispoRessourceDslBouyguesLireParNomUra
   */
  public ConnectorResponse<Retour, List<DispoRessourceDSLBouygues>> dispoRessourceDslBouyguesLireParNomUra(Tracabilite tracabilite_p, String dispoRessourceDslBouyguesUrl_p, String nomUraOrange_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(dispoRessourceDslBouyguesUrl_p))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(IRESConnector.MESSAGE_MISSING_CONFIGURATION_PARAMETER, IRESConnector.PAD3018_PATH_PARAM));
      }

      // Call SAAB
      final Response response;
      HashMap<String, String> queryParams = new HashMap<>();
      queryParams.put(IRESConnector.PARAM_NOM_URA_ORANGE, nomUraOrange_p);

      try
      {
        RESTRequest restRequest = new RESTRequest.RESTRequestBuilder()//
            .httpMethod(HttpMethod.GET)//
            .traceability(tracabilite_p)//
            .method(METHOD_NAME_PAD3018_DISPO_RESSOURCE_DSL_BOUYGUES_LIRE_PAR_NOM_URA)//
            .headers(AbstractInternalRESTConnector.getSpiritStarkRequestHeader())//
            .path(dispoRessourceDslBouyguesUrl_p)//
            .queryParameter(queryParams)//
            .build();
        response = _resInstance.sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content
      GetDispoRessourceDSLBouyguesResponse getDispoRessourceDSLBouyguesResponse = _resInstance.getContentFromResponse(tracabilite_p, response, METHOD_NAME_PAD3018_DISPO_RESSOURCE_DSL_BOUYGUES_LIRE_PAR_NOM_URA, GetDispoRessourceDSLBouyguesResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(getDispoRessourceDSLBouyguesResponse.getRetour());
      List<DispoRessourceDSLBouygues> listeDispoRessourceDSLBouygues = getDispoRessourceDSLBouyguesResponse.getListeDispoRessourceDSLBouygues();

      return new ConnectorResponse<>(retour, listeDispoRessourceDSLBouygues);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  /**
   * dispoRessourceDslOrangeLire
   */
  public ConnectorResponse<Retour, List<DispoRessourceDSLOrange>> dispoRessourceDslOrangeLire(Tracabilite tracabilite_p, String dispoRessourceDslOrangeUrl_p, String nomUraOrange_p, String techno_p, String nbPaire_p, String typeKp_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(dispoRessourceDslOrangeUrl_p))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(IRESConnector.MESSAGE_MISSING_CONFIGURATION_PARAMETER, IRESConnector.PAD3017_PATH_PARAM));
      }

      // Call SAAB
      final Response response;
      HashMap<String, String> queryParams = new HashMap<>();
      queryParams.put(IRESConnector.PARAM_NOM_URA_ORANGE, nomUraOrange_p);
      queryParams.put(IRESConnector.PARAM_TECHNO, techno_p);
      queryParams.put(IRESConnector.PARAM_NB_PAIRE, nbPaire_p);
      queryParams.put(IRESConnector.PARAM_TYPE_KP, typeKp_p);

      try
      {
        RESTRequest restRequest = new RESTRequest.RESTRequestBuilder()//
            .httpMethod(HttpMethod.GET)//
            .traceability(tracabilite_p)//
            .method(METHOD_NAME_PAD3017_DISPO_RESSOURCE_DSL_ORANGE_LIRE)//
            .headers(AbstractInternalRESTConnector.getSpiritStarkRequestHeader())//
            .path(dispoRessourceDslOrangeUrl_p)//
            .queryParameter(queryParams)//
            .build();
        response = _resInstance.sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content
      GetDispoRessourceDSLOrangeResponse getDispoRessourceDSLOrangeResponse = _resInstance.getContentFromResponse(tracabilite_p, response, METHOD_NAME_PAD3017_DISPO_RESSOURCE_DSL_ORANGE_LIRE, GetDispoRessourceDSLOrangeResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(getDispoRessourceDSLOrangeResponse.getRetour());
      List<DispoRessourceDSLOrange> listeDispoRessourceDSLOrange = getDispoRessourceDSLOrangeResponse.getListeDispoRessourceDSLOrange();

      return new ConnectorResponse<>(retour, listeDispoRessourceDSLOrange);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  /**
   * dispoRessourceDslOrangeLireParNomUra
   */
  public ConnectorResponse<Retour, List<DispoRessourceDSLOrange>> dispoRessourceDslOrangeLireParNomUra(Tracabilite tracabilite_p, String dispoRessourceDslOrangeUrl_p, String nomUraOrange_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(dispoRessourceDslOrangeUrl_p))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(IRESConnector.MESSAGE_MISSING_CONFIGURATION_PARAMETER, IRESConnector.PAD3017_PATH_PARAM));
      }

      // Call SAAB
      final Response response;
      HashMap<String, String> queryParams = new HashMap<>();
      queryParams.put(IRESConnector.PARAM_NOM_URA_ORANGE, nomUraOrange_p);

      try
      {
        RESTRequest restRequest = new RESTRequest.RESTRequestBuilder()//
            .httpMethod(HttpMethod.GET)//
            .traceability(tracabilite_p)//
            .method(METHOD_NAME_PAD3017_DISPO_RESSOURCE_DSL_ORANGE_LIRE_PAR_NOM_URA)//
            .headers(AbstractInternalRESTConnector.getSpiritStarkRequestHeader())//
            .path(dispoRessourceDslOrangeUrl_p)//
            .queryParameter(queryParams)//
            .build();
        response = _resInstance.sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content
      GetDispoRessourceDSLOrangeResponse getDispoRessourceDSLOrangeResponse = _resInstance.getContentFromResponse(tracabilite_p, response, METHOD_NAME_PAD3017_DISPO_RESSOURCE_DSL_ORANGE_LIRE_PAR_NOM_URA, GetDispoRessourceDSLOrangeResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(getDispoRessourceDSLOrangeResponse.getRetour());
      List<DispoRessourceDSLOrange> listeDispoRessourceDSLOrange = getDispoRessourceDSLOrangeResponse.getListeDispoRessourceDSLOrange();

      return new ConnectorResponse<>(retour, listeDispoRessourceDSLOrange);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  /**
   * dispoRessourceDslSFRLire
   */
  public ConnectorResponse<Retour, List<DispoRessourceDSLSFR>> dispoRessourceDslSFRLire(Tracabilite tracabilite_p, String dispoRessourceDslBouyguesUrl_p, String nomUraOrange_p, String techno_p, String nbPaire_p, String typeKp_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(dispoRessourceDslBouyguesUrl_p))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(IRESConnector.MESSAGE_MISSING_CONFIGURATION_PARAMETER, IRESConnector.PAD3018_PATH_PARAM));
      }

      // Call SAAB
      final Response response;
      HashMap<String, String> queryParams = new HashMap<>();
      queryParams.put(IRESConnector.PARAM_NOM_URA_ORANGE, nomUraOrange_p);
      queryParams.put(IRESConnector.PARAM_TECHNO, techno_p);
      queryParams.put(IRESConnector.PARAM_NB_PAIRE, nbPaire_p);
      queryParams.put(IRESConnector.PARAM_TYPE_KP, typeKp_p);

      try
      {
        RESTRequest restRequest = new RESTRequest.RESTRequestBuilder()//
            .httpMethod(HttpMethod.GET)//
            .traceability(tracabilite_p)//
            .method(METHOD_NAME_PAD3020_DISPO_RESSOURCE_DSL_SFR_LIRE)//
            .headers(AbstractInternalRESTConnector.getSpiritStarkRequestHeader())//
            .path(dispoRessourceDslBouyguesUrl_p)//
            .queryParameter(queryParams)//
            .build();
        response = _resInstance.sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content
      GetDispoRessourceDSLSFRResponse getDispoRessourceDSLSFRResponse = _resInstance.getContentFromResponse(tracabilite_p, response, METHOD_NAME_PAD3020_DISPO_RESSOURCE_DSL_SFR_LIRE, GetDispoRessourceDSLSFRResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(getDispoRessourceDSLSFRResponse.getRetour());
      List<DispoRessourceDSLSFR> listeDispoRessourceDSLSFR = getDispoRessourceDSLSFRResponse.getListeDispoRessourceDSLSFR();

      return new ConnectorResponse<>(retour, listeDispoRessourceDSLSFR);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  /**
   * dispoRessourceDslSFRLireParNomUra
   */
  public ConnectorResponse<Retour, List<DispoRessourceDSLSFR>> dispoRessourceDslSFRLireParNomUra(Tracabilite tracabilite_p, String dispoRessourceDslBouyguesUrl_p, String nomUraOrange_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(dispoRessourceDslBouyguesUrl_p))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(IRESConnector.MESSAGE_MISSING_CONFIGURATION_PARAMETER, IRESConnector.PAD3018_PATH_PARAM));
      }

      // Call SAAB
      final Response response;
      HashMap<String, String> queryParams = new HashMap<>();
      queryParams.put(IRESConnector.PARAM_NOM_URA_ORANGE, nomUraOrange_p);

      try
      {
        RESTRequest restRequest = new RESTRequest.RESTRequestBuilder()//
            .httpMethod(HttpMethod.GET)//
            .traceability(tracabilite_p)//
            .method(METHOD_NAME_PAD3020_DISPO_RESSOURCE_DSL_SFR_LIRE_PAR_NOM_URA)//
            .headers(AbstractInternalRESTConnector.getSpiritStarkRequestHeader())//
            .path(dispoRessourceDslBouyguesUrl_p)//
            .queryParameter(queryParams)//
            .build();
        response = _resInstance.sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content
      GetDispoRessourceDSLSFRResponse getDispoRessourceDSLSFRResponse = _resInstance.getContentFromResponse(tracabilite_p, response, METHOD_NAME_PAD3020_DISPO_RESSOURCE_DSL_SFR_LIRE_PAR_NOM_URA, GetDispoRessourceDSLSFRResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(getDispoRessourceDSLSFRResponse.getRetour());
      List<DispoRessourceDSLSFR> listeDispoRessourceDSLSFR = getDispoRessourceDSLSFRResponse.getListeDispoRessourceDSLSFR();

      return new ConnectorResponse<>(retour, listeDispoRessourceDSLSFR);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }
}
