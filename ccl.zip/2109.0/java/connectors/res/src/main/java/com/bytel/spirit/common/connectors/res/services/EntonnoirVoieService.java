/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.res.services;

import java.text.MessageFormat;
import java.util.HashMap;
import java.util.List;

import javax.ws.rs.HttpMethod;
import javax.ws.rs.core.Response;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.connector.RESTRequest;
import com.bytel.spirit.common.connectors.res.IRESConnector;
import com.bytel.spirit.common.connectors.res.RESConnector;
import com.bytel.spirit.common.shared.misc.connectors.AbstractInternalRESTConnector;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.RetourConverter;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.EntonnoirVoie;
import com.bytel.spirit.common.shared.saab.res.response.GetListeEntonnoirVoieResponse;

/**
 * @author rafcosta
 * @version ($Revision$ $Date$)
 */
public class EntonnoirVoieService
{
  /** The constant for entonnoirVoieLireTousParCodeInsee service name */
  public static final String METHOD_NAME_ENTONNOIR_VOIE_LIRE_TOUS_PAR_CODE_INSEE = "entonnoirVoieLireTousParCodeInsee"; //$NON-NLS-1$
  /** The constant for entonnoirVoieLireUnParCodeInseeSimiliHexacle0 service name */
  public static final String METHOD_NAME_ENTONNOIR_VOIE_LIRE_TOUS_PAR_CODE_INSEE_SIMILI_HEXACLE_0 = "entonnoirVoieLireUnParCodeInseeSimiliHexacle0"; //$NON-NLS-1$
  /** The constant for entonnoirVoieLireUnParCodeInseeCodeRivoli service name */
  public static final String METHOD_NAME_ENTONNOIR_VOIE_LIRE_TOUS_PAR_CODE_INSEE_CODE_RIVOLI = "entonnoirVoieLireUnParCodeInseeCodeRivoli"; //$NON-NLS-1$

  private final RESConnector _resInstance;

  /**
   * @param resInstance_p
   *          {@link RESConnector}
   */
  public EntonnoirVoieService(RESConnector resInstance_p)
  {
    _resInstance = resInstance_p;
  }

  /**
   * entonnoirVoieLireTousParCodeInsee
   *
   * @param tracabilite_p
   *          tracabilite
   * @param entonnoirVoieUrl_p
   *          entonnoirVoieUrl
   * @param codeInsee_p
   *          codeInsee
   * @return ConnectorResponse<Retour, List<EntonnoirVoie>>
   */
  public ConnectorResponse<Retour, List<EntonnoirVoie>> entonnoirVoieLireTousParCodeInsee(Tracabilite tracabilite_p, String entonnoirVoieUrl_p, String codeInsee_p)
  {
    try
    {
      if (StringTools.isNullOrEmpty(entonnoirVoieUrl_p))
      {
        throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(IRESConnector.MESSAGE_MISSING_CONFIGURATION_PARAMETER, IRESConnector.PAD3022_PATH_PARAM));
      }

      // Query parameters
      HashMap<String, String> queryParams = new HashMap<>();
      if (StringTools.isNotNullOrEmpty(codeInsee_p))
      {
        queryParams.put(IRESConnector.PARAM_CODE_INSEE, codeInsee_p);
      }

      // Call SAAB
      final Response response;
      try
      {
        RESTRequest restRequest = new RESTRequest.RESTRequestBuilder()//
            .httpMethod(HttpMethod.GET)//
            .traceability(tracabilite_p)//
            .method(METHOD_NAME_ENTONNOIR_VOIE_LIRE_TOUS_PAR_CODE_INSEE)//
            .headers(AbstractInternalRESTConnector.getSpiritStarkRequestHeader())//
            .path(entonnoirVoieUrl_p)//
            .queryParameter(queryParams)//
            .build();
        response = _resInstance.sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content
      GetListeEntonnoirVoieResponse getListeEntonnoirVoieResponse = _resInstance.getContentFromResponse(tracabilite_p, response, METHOD_NAME_ENTONNOIR_VOIE_LIRE_TOUS_PAR_CODE_INSEE, GetListeEntonnoirVoieResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(getListeEntonnoirVoieResponse.getRetour());
      List<EntonnoirVoie> entonnoirCommuneList = getListeEntonnoirVoieResponse.getListeEntonnoirVoie();

      return new ConnectorResponse<>(retour, entonnoirCommuneList);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  /**
   * entonnoirVoieLireUnParCodeInseeCodeRivoli
   *
   * @param tracabilite_p
   *          tracabilite
   * @param entonnoirVoieUrl_p
   *          entonnoirVoieUrl
   * @param codeInsee_p
   *          codeInsee
   * @param codeRivoli_p
   *          codeRivoli
   * @return ConnectorResponse<Retour, List<EntonnoirVoie>>
   */
  public ConnectorResponse<Retour, List<EntonnoirVoie>> entonnoirVoieLireUnParCodeInseeCodeRivoli(Tracabilite tracabilite_p, String entonnoirVoieUrl_p, String codeInsee_p, String codeRivoli_p)
  {
    try
    {
      if (StringTools.isNullOrEmpty(entonnoirVoieUrl_p))
      {
        throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(IRESConnector.MESSAGE_MISSING_CONFIGURATION_PARAMETER, IRESConnector.PAD3022_PATH_PARAM));
      }

      // Query parameters
      HashMap<String, String> queryParams = new HashMap<>();
      if (StringTools.isNotNullOrEmpty(codeInsee_p))
      {
        queryParams.put(IRESConnector.PARAM_CODE_INSEE, codeInsee_p);
      }
      if (StringTools.isNotNullOrEmpty(codeRivoli_p))
      {
        queryParams.put(IRESConnector.PARAM_RIVOLI, codeRivoli_p);
      }

      // Call SAAB
      final Response response;
      try
      {
        RESTRequest restRequest = new RESTRequest.RESTRequestBuilder()//
            .httpMethod(HttpMethod.GET)//
            .traceability(tracabilite_p)//
            .method(METHOD_NAME_ENTONNOIR_VOIE_LIRE_TOUS_PAR_CODE_INSEE_CODE_RIVOLI)//
            .headers(AbstractInternalRESTConnector.getSpiritStarkRequestHeader())//
            .path(entonnoirVoieUrl_p)//
            .queryParameter(queryParams)//
            .build();
        response = _resInstance.sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content
      GetListeEntonnoirVoieResponse getListeEntonnoirVoieResponse = _resInstance.getContentFromResponse(tracabilite_p, response, METHOD_NAME_ENTONNOIR_VOIE_LIRE_TOUS_PAR_CODE_INSEE_CODE_RIVOLI, GetListeEntonnoirVoieResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(getListeEntonnoirVoieResponse.getRetour());
      List<EntonnoirVoie> entonnoirCommuneList = getListeEntonnoirVoieResponse.getListeEntonnoirVoie();

      return new ConnectorResponse<>(retour, entonnoirCommuneList);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  /**
   * entonnoirVoieLireUnParCodeInseeSimiliHexacle0
   *
   * @param tracabilite_p
   *          tracabilite
   * @param entonnoirVoieUrl_p
   *          entonnoirVoieUrl
   * @param codeInsee_p
   *          codeInsee
   * @param similiHexacle0_p
   *          similiHexacle0
   * @return ConnectorResponse<Retour, List<EntonnoirVoie>>
   */
  public ConnectorResponse<Retour, List<EntonnoirVoie>> entonnoirVoieLireUnParCodeInseeSimiliHexacle0(Tracabilite tracabilite_p, String entonnoirVoieUrl_p, String codeInsee_p, String similiHexacle0_p)
  {
    try
    {
      if (StringTools.isNullOrEmpty(entonnoirVoieUrl_p))
      {
        throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(IRESConnector.MESSAGE_MISSING_CONFIGURATION_PARAMETER, IRESConnector.PAD3022_PATH_PARAM));
      }

      // Query parameters
      HashMap<String, String> queryParams = new HashMap<>();
      if (StringTools.isNotNullOrEmpty(codeInsee_p))
      {
        queryParams.put(IRESConnector.PARAM_CODE_INSEE, codeInsee_p);
      }
      if (StringTools.isNotNullOrEmpty(similiHexacle0_p))
      {
        queryParams.put(IRESConnector.PARAM_SIMILI_HEXACLE_0, similiHexacle0_p);
      }

      // Call SAAB
      final Response response;
      try
      {
        RESTRequest restRequest = new RESTRequest.RESTRequestBuilder()//
            .httpMethod(HttpMethod.GET)//
            .traceability(tracabilite_p)//
            .method(METHOD_NAME_ENTONNOIR_VOIE_LIRE_TOUS_PAR_CODE_INSEE_SIMILI_HEXACLE_0)//
            .headers(AbstractInternalRESTConnector.getSpiritStarkRequestHeader())//
            .path(entonnoirVoieUrl_p)//
            .queryParameter(queryParams)//
            .build();
        response = _resInstance.sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content
      GetListeEntonnoirVoieResponse getListeEntonnoirVoieResponse = _resInstance.getContentFromResponse(tracabilite_p, response, METHOD_NAME_ENTONNOIR_VOIE_LIRE_TOUS_PAR_CODE_INSEE_SIMILI_HEXACLE_0, GetListeEntonnoirVoieResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(getListeEntonnoirVoieResponse.getRetour());
      List<EntonnoirVoie> entonnoirCommuneList = getListeEntonnoirVoieResponse.getListeEntonnoirVoie();

      return new ConnectorResponse<>(retour, entonnoirCommuneList);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }
}
