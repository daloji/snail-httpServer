/*******************************************************************************
* $Id: NoeudRaccordementProxy.java 47793 2021-02-18 14:31:20Z lchanyip $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.res.services;

import java.util.Set;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.probes.AvgDoubleCollectorItem;
import com.bytel.ravel.common.probes.AvgFlowPerSecondCollector;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.services.connector.ConnectorManager;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.connectors.res.IRESConnector;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.CompteRenduSuppression;
import com.bytel.spirit.common.shared.saab.res.request.ManageNoeudRaccordementRequest;

/**
 *
 * @author jiantila
 * @version ($Revision: 47793 $ $Date: 2021-02-18 15:31:20 +0100 (jeu. 18 févr. 2021) $)
 */
public class NoeudRaccordementProxy
{

  /**
   * connector Id
   */
  private String _connectorId;

  /**
   * AVG call counter
   */
  private AvgFlowPerSecondCollector _avgCallCounter;

  /**
   * AVG time execution
   */
  private AvgDoubleCollectorItem _avgExecTime;

  /**
   *
   * @param connectorId_p
   * @param avgCallCounter_p
   * @param avgExecTime_p
   */
  public NoeudRaccordementProxy(String connectorId_p, AvgFlowPerSecondCollector avgCallCounter_p, AvgDoubleCollectorItem avgExecTime_p)
  {
    _avgCallCounter = avgCallCounter_p;
    _avgExecTime = avgExecTime_p;
    _connectorId = connectorId_p;
  }

  /**
   * pad3204CreerNoeudRaccordementGererImport cas 1 GererImport
   *
   * @param tracabilite_p
   *          tracabilite
   * @param manageNoeudRaccordementRequest_p
   *          noeudRaccordement
   * @return
   * @throws RavelException
   */
  public ConnectorResponse<Retour, Nothing> gererImport(Tracabilite tracabilite_p, ManageNoeudRaccordementRequest manageNoeudRaccordementRequest_p) throws RavelException
  {
    IRESConnector resConnector = null;
    try
    {
      resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
    }
    catch (Exception e_p)
    {
      // Retour NOK
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
    }
    _avgCallCounter.measure();
    long startTime = System.currentTimeMillis();
    try
    {
      return resConnector.noeudRaccordementGererImport(tracabilite_p, manageNoeudRaccordementRequest_p);
    }
    finally
    {
      long endTime = System.currentTimeMillis();
      _avgExecTime.updateAvgValue(endTime - startTime);
    }
  }

  /**
   * pad3204CreerNoeudRaccordementGererSuppression cas 2 - GererSuppressionNrNonReference
   *
   * @param tracabilite_p
   *          tracabilite
   * @param listeNomNoedRaco_p
   *          the list with the names of the NoedRaccordement that have been imported.
   * @return a pair with the retour and a set of {@link CompteRenduSuppression}.
   * @throws RavelException
   *           on erro.
   */
  public ConnectorResponse<Retour, Set<CompteRenduSuppression>> gererSuppressionNrNonReference(Tracabilite tracabilite_p, Set<String> listeNomNoedRaco_p) throws RavelException
  {
    IRESConnector resConnector;

    try
    {
      resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
    }
    catch (Exception e_p)
    {
      // Retour NOK
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
    }

    _avgCallCounter.measure();
    long startTime = System.currentTimeMillis();

    try
    {
      return resConnector.noeudRaccordementGererSuppressionNrNonReference(tracabilite_p, listeNomNoedRaco_p);
    }
    finally
    {
      long endTime = System.currentTimeMillis();
      _avgExecTime.updateAvgValue(endTime - startTime);
    }
  }
}
