/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.res.services;

import static com.bytel.spirit.common.connectors.res.IRESConnector.MESSAGE_MISSING_CONFIGURATION_PARAMETER;

import java.text.MessageFormat;
import java.util.HashMap;
import java.util.Set;

import javax.ws.rs.HttpMethod;
import javax.ws.rs.core.Response;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.json.IRavelJson;
import com.bytel.ravel.common.json.RavelJson;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.connector.RESTRequest;
import com.bytel.spirit.common.connectors.res.Messages;
import com.bytel.spirit.common.connectors.res.RESConnector;
import com.bytel.spirit.common.shared.misc.connectors.AbstractInternalRESTConnector;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.BasicResponse;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.ressources.RetourConverter;
import com.bytel.spirit.common.shared.misc.ressources.SpiritConstants;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.CompteRenduSuppression;
import com.bytel.spirit.common.shared.saab.res.PointAncrageIP;
import com.bytel.spirit.common.shared.saab.res.request.ManagePointAncrageIPRequest;
import com.bytel.spirit.common.shared.saab.res.response.ManagePointAncrageIPResponse;

/**
 * @author ppinto
 * @version ($Revision$ $Date$)
 */
public class PointAncrageIpService
{
  public interface IMethodName
  {
    /** The constant for pad3124RessourcePortP2PGererAllocation service name */
    String METHOD_NAME_POINT_ANCRAGE_IP_GERER_IMPORT = "pointAncrageIpGererImport"; //$NON-NLS-1$
    String METHOD_NAME_POINT_ANCRAGE_IP_GERER_SUPPRESSION_POINT_ANCRAGE_IP_NON_REFERENCE = "pointAncrageIpGererSuppressionPointAncrageIPNonReference"; //$NON-NLS-1$
    /** The constant for ressourcePortP2PModifierStatutAllocation service name */
    String METHOD_NAME_RESSOURCE_PORTP2P_MODIFIER_STATUT_ALLOCATION = "ressourcePortP2PModifierStatutAllocation"; //$NON-NLS-1$
    /** The constant for ressourcePortP2PCompterPortLibre service name */
    String METHOD_NAME_RESSOURCE_PORTP2P_COMPTER_PORT_LIBRE = "ressourcePortP2PCompterPortLibre"; //$NON-NLS-1$
  }

  public interface IParameter
  {
    /** Parameter idRessource */
    String PARAM_ID_RESSOURCE = "idRessource"; //$NON-NLS-1$
    /** Parameter nomNR */
    String PARAM_NOMNR = "nomNR"; //$NON-NLS-1$
    /** Parameter distance */
    String PARAM_DISTANCE = "distance"; //$NON-NLS-1$
    /** Parameter Action */
    String PARAM_ACTION = "action"; //$NON-NLS-1$
    /** Parameter GererImport */
    String PARAM_GERER_IMPORT = "GererImport"; //$NON-NLS-1$
    /** Parameter GererSuppressionPointAncrageIPNonReference */
    String PARAM_GERER_SUPRESSION_POINT_ANCRAGE_IP_NON_REFERENCE = "GererSuppressionPointAncrageIPNonReference"; //$NON-NLS-1$
    /** Parameter RESSOURCE_PORT_P2P_PATH */
    String RESSOURCE_PORT_P2P_PATH = "RESSOURCE_PORT_P2P_PATH"; //$NON-NLS-1$
    /** The constant for message Impossible de récupérer la réponse constant */
    String MESSAGE_JSON_ERROR_MESSAGE = Messages.getString("RESConnector.JsonErrorMessage"); //$NON-NLS-1$
    /** Parameter statut */
    String PARAM_STATUT = "statut"; //$NON-NLS-1$
  }

  /** The connector instance */
  private final RESConnector _resInstance;

  /** The json builder */
  private final IRavelJson _jsonBuilder;

  /**
   * Default constructor
   *
   * @param resInstance_p
   *          Current RESConnector instance
   */
  public PointAncrageIpService(RESConnector resInstance_p)
  {
    _resInstance = resInstance_p;
    _jsonBuilder = new RavelJson.RavelJsonBuilder().profil(SpiritConstants.JSON_PROFILE_STARK).build();
  }

  public ConnectorResponse<Retour, Nothing> pointAncrageIpGererImport(Tracabilite tracabilite_p, PointAncrageIP pointAncrageIP_p, String pointAncrageIpUrl_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(pointAncrageIpUrl_p))
      {
        throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, RessourcePortP2PService.IParameter.RESSOURCE_PORT_P2P_PATH));
      }
      // Query parameters
      HashMap<String, String> queryParams = new HashMap<>();
      queryParams.put(IParameter.PARAM_ACTION, IParameter.PARAM_GERER_IMPORT);

      ManagePointAncrageIPRequest request = new ManagePointAncrageIPRequest(pointAncrageIP_p);

      // Call SAAB
      final Response response;
      try
      {
        RESTRequest restRequest = new RESTRequest.RESTRequestBuilder()//
            .httpMethod(HttpMethod.PUT)//
            .traceability(tracabilite_p)//
            .serializer(_jsonBuilder)//
            .method(IMethodName.METHOD_NAME_POINT_ANCRAGE_IP_GERER_IMPORT)//
            .headers(AbstractInternalRESTConnector.getSpiritStarkRequestHeader())//
            .path(pointAncrageIpUrl_p)//
            .queryParameter(queryParams)//
            .request(request)//
            .build();
        response = _resInstance.sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content to a JSON string
      BasicResponse basicResponse = _resInstance.getContentFromResponse(tracabilite_p, response, IMethodName.METHOD_NAME_POINT_ANCRAGE_IP_GERER_IMPORT, BasicResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(basicResponse.getRetour());
      return new ConnectorResponse<>(retour, null);
    }
    catch (Exception e_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  public ConnectorResponse<Retour, Set<CompteRenduSuppression>> pointAncrageIpGererSuppressionPointAncrageIPNonReference(Tracabilite tracabilite_p, Set<String> listeNomPointAncrageIP_p, String typePointAncrageIP_p, String pointAncrageIpUrl_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(pointAncrageIpUrl_p))
      {
        throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, RessourcePortP2PService.IParameter.RESSOURCE_PORT_P2P_PATH));
      }
      // Query parameters
      HashMap<String, String> queryParams = new HashMap<>();
      queryParams.put(IParameter.PARAM_ACTION, IParameter.PARAM_GERER_SUPRESSION_POINT_ANCRAGE_IP_NON_REFERENCE);

      ManagePointAncrageIPRequest request = new ManagePointAncrageIPRequest(listeNomPointAncrageIP_p, typePointAncrageIP_p);

      // Call SAAB
      final Response response;
      try
      {
        RESTRequest restRequest = new RESTRequest.RESTRequestBuilder()//
            .httpMethod(HttpMethod.PUT)//
            .traceability(tracabilite_p)//
            .serializer(_jsonBuilder)//
            .method(IMethodName.METHOD_NAME_POINT_ANCRAGE_IP_GERER_SUPPRESSION_POINT_ANCRAGE_IP_NON_REFERENCE)//
            .headers(AbstractInternalRESTConnector.getSpiritStarkRequestHeader())//
            .path(pointAncrageIpUrl_p)//
            .queryParameter(queryParams)//
            .request(request)//
            .build();
        response = _resInstance.sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content to a JSON string
      ManagePointAncrageIPResponse managePointAncrageIpResponse = _resInstance.getContentFromResponse(tracabilite_p, response, IMethodName.METHOD_NAME_POINT_ANCRAGE_IP_GERER_SUPPRESSION_POINT_ANCRAGE_IP_NON_REFERENCE, ManagePointAncrageIPResponse.class);
      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(managePointAncrageIpResponse.getRetour());
      Set<CompteRenduSuppression> compteRendu = managePointAncrageIpResponse.getListeCompteRenduSupression();

      return new ConnectorResponse<>(retour, compteRendu);
    }
    catch (Exception e_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }
}
