/*******************************************************************************
* $Id: RES2103_RechercherCodeInseeAssocies.java 247 2017-07-18 13:57:48Z pcarreir $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.res.activities;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.log.event.SystemLogEvent;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.IActivityCaller;
import com.bytel.ravel.services.process.activity.BuiltActivityContext;
import com.bytel.spirit.common.connectors.res.Messages;
import com.bytel.spirit.common.connectors.res.RESProxy;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.Commune;
import com.bytel.spirit.common.shared.saab.res.response.ListeCommuneResponse;

/**
 *
 * @author pcarreir
 * @version ($Revision: 247 $ $Date: 2017-07-18 15:57:48 +0200 (mar., 18 juil. 2017) $)
 */
public class RES2103_RechercherCodeInseeAssocies extends BuiltActivityContext<List<String>>
{
  /**
   *
   * @author pcarreir
   * @version ($Revision: 247 $ $Date: 2017-07-18 15:57:48 +0200 (mar., 18 juil. 2017) $)
   */
  public static class RES2103_RechercherCodeInseeAssociesBuilder
  {
    /**
     * Object to build
     */
    RES2103_RechercherCodeInseeAssocies _toBuild;

    /**
     * Constructor
     */
    public RES2103_RechercherCodeInseeAssociesBuilder()
    {
      _toBuild = new RES2103_RechercherCodeInseeAssocies();
    }

    /**
     * @return RR0020_BL003_RechercherCodeInseeAssocies
     */
    public RES2103_RechercherCodeInseeAssocies build()
    {
      if ((_toBuild.getTracabilite() == null) || (_toBuild.getCodeInsee() == null))
      {
        // PARAMETRE INVALIDE
        Retour retour = new Retour();
        retour.setResultat(StringConstants.NOK);
        retour.setCategorie(IMegConsts.CAT3);
        retour.setDiagnostic(IMegSpiritConsts.DONNEE_INVALIDE);
        retour.setLibelle("Parametre d'entree de l'activite non renseignee"); //$NON-NLS-1$
        _toBuild.setRetour(retour);
      }
      return _toBuild;
    }

    /**
     * @param codeInsee_p
     *          The code insee
     * @return RR0020_BL003_RechercherCodeInseeAssociesBuilder
     */
    public RES2103_RechercherCodeInseeAssociesBuilder codeInsee(String codeInsee_p)
    {
      _toBuild.setCodeInsee(codeInsee_p);
      return this;
    }

    /**
     * @param tracabilite_p
     *          The tracability
     * @return RR0020_BL003_RechercherCodeInseeAssociesBuilder
     */
    public RES2103_RechercherCodeInseeAssociesBuilder tracabilite(Tracabilite tracabilite_p)
    {
      _toBuild.setTracabilite(tracabilite_p);
      return this;
    }
  }

  /**
   *
   * @author pcarreir
   * @version ($Revision: 247 $ $Date: 2017-07-18 15:57:48 +0200 (mar., 18 juil. 2017) $)
   */
  private enum Step
  {
    /**
     * First step to execute
     */
    First,

    /**
     * If all steps have been executed
     */
    End
  }

  /**
   *
   */
  private static final String CODE_INSEE = "CodeInsee"; //$NON-NLS-1$

  /**
   *
   */
  private static final String RETOUR = "Retour"; //$NON-NLS-1$

  /**
   * The serial version UID
   */
  private static final long serialVersionUID = -3040940022058709909L;

  /**
   * the code insee
   */
  private String _codeInsee;

  /**
   * The current execution step
   */
  private Step _currentStep = Step.First;

  /**
   * The tracability
   */
  private Tracabilite _tracabilite = null;

  @Override
  public List<String> executeNextStep(IActivityCaller arg0_p) throws RavelException
  {
    List<String> result = null;
    switch (_currentStep)
    {
      case First:
        result = rechercherCodeInseeAssocies();

        _currentStep = Step.End;
        break;
      default:
        break;
    }
    return result;
  }

  @Override
  public boolean isEndStep()
  {
    return Step.End.equals(_currentStep);
  }

  /**
   * @return String
   */
  protected String getCodeInsee()
  {
    return _codeInsee;
  }

  /**
   * @return Tracabilite
   */
  protected Tracabilite getTracabilite()
  {
    return _tracabilite;
  }

  /**
   * @param codeInsee_p
   *          The code insee
   */
  protected void setCodeInsee(String codeInsee_p)
  {
    _codeInsee = codeInsee_p;
  }

  /**
   * @param tracabilite_p
   *          The tracability
   */
  protected void setTracabilite(Tracabilite tracabilite_p)
  {
    _tracabilite = tracabilite_p;
  }

  /**
   * @return List<String>
   * @throws RavelException
   *           List<String>
   */
  private List<String> rechercherCodeInseeAssocies() throws RavelException
  {
    List<String> result;
    Retour retour;
    result = new ArrayList<String>();
    SystemLogEvent system = new SystemLogEvent(LogSeverity.DEBUG, _tracabilite.getIdCorrelationSpirit(), Messages.getString("res.RES2103_RechercherCodeInseeAssocies")); //$NON-NLS-1$
    system.addField(CODE_INSEE, _codeInsee, false);
    RavelLogger.log(system);
    if (_codeInsee.length() != 5)
    {
      retour = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ENTREE_INCORRECTE, MessageFormat.format(Messages.getString("res.codeInseeInvalide"), _codeInsee)); //$NON-NLS-1$
    }
    else
    {

      ConnectorResponse<Retour, ListeCommuneResponse> communeRes = RESProxy.getInstance().pad3001CommuneReadAncienCodeInsee(_tracabilite, _codeInsee); //Communes.LireTous(_codeInsee); //ancient code insee
      retour = communeRes._first;
      if (!RetourFactory.isRetourOK(communeRes._first))
      {
        if (IMegConsts.CAT4.equals(communeRes._first.getCategorie()) && (IMegConsts.DONNEE_INCONNUE.equals(communeRes._first.getDiagnostic()) || IMegSpiritConsts.CODE_INSEE_INCONNU.equals(communeRes._first.getDiagnostic())))
        {
          communeRes = RESProxy.getInstance().pad3001CommuneReadCodeInsee(_tracabilite, _codeInsee);//Communes.LireTous(_codeInsee);
          if (RetourFactory.isRetourOK(communeRes._first))
          {
            retour = communeRes._first;
            for (Commune commune : communeRes._second.getListeCommune())
            {
              if (!StringTools.isNullOrEmpty(commune.getAncienCodeInsee()))
              {
                result.add(commune.getAncienCodeInsee());
              }
            }
          }
          else
          {
            if (IMegConsts.DONNEE_INCONNUE.equals(communeRes._first.getDiagnostic()) || IMegSpiritConsts.CODE_INSEE_INCONNU.equals(communeRes._first.getDiagnostic()))
            {
              retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.CODE_INSEE_INCONNU, MessageFormat.format(Messages.getString("res.codeInseeInconnu"), _codeInsee)); //$NON-NLS-1$
            }
          }
        }
      }
      else
      {
        for (Commune commune : communeRes._second.getListeCommune())
        {
          if (!StringTools.isNullOrEmpty(commune.getAncienCodeInsee()))
          {
            result.add(commune.getAncienCodeInsee());
          }
        }
      }
    }
    system = new SystemLogEvent(LogSeverity.DEBUG, _tracabilite.getIdCorrelationSpirit(), Messages.getString("res.RES2103_RechercherCodeInseeAssocies")); //$NON-NLS-1$
    system.addField(RETOUR, retour, false);
    RavelLogger.log(system);
    this.setRetour(retour);
    return result;
  }

}
