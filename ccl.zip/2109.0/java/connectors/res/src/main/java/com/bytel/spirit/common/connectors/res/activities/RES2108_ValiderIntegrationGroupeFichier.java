/*******************************************************************************
* $Id: RES2108_ValiderIntegrationGroupeFichier.java 255 2017-07-18 16:27:19Z pcarreir $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.res.activities;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.log.event.SystemLogEvent;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.IActivityCaller;
import com.bytel.ravel.services.process.activity.BuiltActivityContext;
import com.bytel.spirit.common.connectors.res.Messages;
import com.bytel.spirit.common.connectors.res.RESProxy;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.IntegrationGroupeFichiers;
import com.bytel.spirit.common.shared.saab.res.request.IntegrationGroupeFichierRequest;

/**
 *
 * @author pcarreir
 * @version ($Revision: 255 $ $Date: 2017-07-18 18:27:19 +0200 (mar., 18 juil. 2017) $)
 */
public class RES2108_ValiderIntegrationGroupeFichier extends BuiltActivityContext<Retour>
{
  /**
   *
   * @author pcarreir
   * @version ($Revision: 255 $ $Date: 2017-07-18 18:27:19 +0200 (mar., 18 juil. 2017) $)
   */
  public static class RES2108_ValiderIntegrationGroupeFichierBuilder
  {
    /**
     * Object to build
     */
    RES2108_ValiderIntegrationGroupeFichier _toBuild;

    /**
     * The constructor
     */
    public RES2108_ValiderIntegrationGroupeFichierBuilder()
    {
      _toBuild = new RES2108_ValiderIntegrationGroupeFichier();
    }

    /**
     * @return RR0020_BL008_ValiderIntegrationGroupeFichier
     */
    public RES2108_ValiderIntegrationGroupeFichier build()
    {
      if ((_toBuild.getTracabilite() == null) || (_toBuild.getIntegrationGroupeFichier() == null))
      {
        // PARAMETRE INVALIDE
        Retour retour = new Retour();
        retour.setResultat(StringConstants.NOK);
        retour.setCategorie(IMegConsts.CAT3);
        retour.setDiagnostic(IMegSpiritConsts.DONNEE_INVALIDE);
        retour.setLibelle("Parametre d'entree de l'activite non renseignee"); //$NON-NLS-1$
        _toBuild.setRetour(retour);
      }
      return _toBuild;
    }

    /**
     * @param integrationGroupeFichier_p
     *          integrationGroupeFichier
     *
     *
     * @return RR0020_BL008_ValiderIntegrationGroupeFichierBuilder
     */

    public RES2108_ValiderIntegrationGroupeFichierBuilder integrationGroupeFichiers(IntegrationGroupeFichiers integrationGroupeFichier_p)
    {
      _toBuild.setIntegrationGroupeFichier(integrationGroupeFichier_p);
      return this;
    }

    /**
     * @param tracabilite_p
     *          The tracabilite
     * @return RR0020_BL008_ValiderIntegrationGroupeFichierBuilder
     */
    public RES2108_ValiderIntegrationGroupeFichierBuilder tracabilite(Tracabilite tracabilite_p)
    {
      _toBuild.setTracabilite(tracabilite_p);
      return this;
    }
  }

  /**
   *
   * @author pcarreir
   * @version ($Revision: 255 $ $Date: 2017-07-18 18:27:19 +0200 (mar., 18 juil. 2017) $)
   */
  private enum Step
  {
    /**
     * First step to execute
     */
    First,

    /**
     * If all steps have been executed
     */
    End
  }

  /**
   *
   */
  private static final String RETOUR = "Retour"; //$NON-NLS-1$

  /**
   * The serial version UID
   */
  private static final long serialVersionUID = 1315190666522503394L;

  /**
   * The ELIG PREV constant
   */
  private final static String ELIG_PREV = "ELIG PREV"; //$NON-NLS-1$

  /**
  *
  */
  private static final String NOM_GROUPE_FICHIER = "NomGroupeFichier"; //$NON-NLS-1$

  /**
   * The tracability
   */
  private Tracabilite _tracabilite = null;
  /**
   * The current execution step
   */
  private Step _currentStep = Step.First;
  /**
   * The file group config
   */
  private IntegrationGroupeFichiers _integrationGroupeFichier;

  @Override
  public Retour executeNextStep(IActivityCaller arg0_p) throws RavelException
  {
    SystemLogEvent system = new SystemLogEvent(LogSeverity.DEBUG, _tracabilite.getIdCorrelationSpirit(), Messages.getString("res.RES2108_ValiderIntegrationGroupeFichier")); //$NON-NLS-1$
    system.addField(NOM_GROUPE_FICHIER, _integrationGroupeFichier.getNomGroupeFichiers(), false);
    RavelLogger.log(system);
    Retour result = null;
    switch (_currentStep)
    {
      case First:
        if (ELIG_PREV.equals(_integrationGroupeFichier.getNomGroupeFichiers()))
        {

          IntegrationGroupeFichierRequest integrationRequest = new IntegrationGroupeFichierRequest(_integrationGroupeFichier);
          ConnectorResponse<Retour, Boolean> retour = RESProxy.getInstance().pad3003IntegrationGroupeFichierCreate(_tracabilite, integrationRequest);
          result = retour._first;
        }
        else
        {
          result = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ENTREE_INCORRECTE, _integrationGroupeFichier.getNomGroupeFichiers());
        }

        this.setRetour(result);
        system = new SystemLogEvent(LogSeverity.DEBUG, _tracabilite.getIdCorrelationSpirit(), Messages.getString("res.RES2108_ValiderIntegrationGroupeFichier")); //$NON-NLS-1$
        system.addField(RETOUR, result, false);
        RavelLogger.log(system);
        _currentStep = Step.End;
        break;
      default:
        break;
    }
    return result;
  }

  /**
   * @return String
   */
  public IntegrationGroupeFichiers getIntegrationGroupeFichier()
  {
    return _integrationGroupeFichier;
  }

  /**
   * @return Tracabilite
   */
  public Tracabilite getTracabilite()
  {
    return _tracabilite;
  }

  @Override
  public boolean isEndStep()
  {
    return Step.End.equals(_currentStep);
  }

  /**
   * @param integrationGroupeFichier_p
   *          the integrationGroupeFichier to set
   */
  public void setIntegrationGroupeFichier(IntegrationGroupeFichiers integrationGroupeFichier_p)
  {
    _integrationGroupeFichier = integrationGroupeFichier_p;
  }

  /**
   * @param tracabilite_p
   *          The tracability
   */
  public void setTracabilite(Tracabilite tracabilite_p)
  {
    _tracabilite = tracabilite_p;
  }
}
