/*******************************************************************************
* $Id: OltCompositeService.java 49682 2021-03-24 13:30:21Z fbarnabe $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.res.services;

import java.text.MessageFormat;
import java.util.HashMap;
import java.util.Set;

import javax.ws.rs.HttpMethod;
import javax.ws.rs.core.Response;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.json.IRavelJson;
import com.bytel.ravel.common.json.RavelJson;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.connector.RESTRequest;
import com.bytel.ravel.services.connector.RESTRequest.RESTRequestBuilder;
import com.bytel.spirit.common.connectors.res.IRESConnector;
import com.bytel.spirit.common.connectors.res.RESConnector;
import com.bytel.spirit.common.shared.misc.connectors.AbstractInternalRESTConnector;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.BasicResponse;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.ressources.RetourConverter;
import com.bytel.spirit.common.shared.misc.ressources.SpiritConstants;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.CompteRenduSuppression;
import com.bytel.spirit.common.shared.saab.res.ListeTechnologieAutorisee;
import com.bytel.spirit.common.shared.saab.res.OltComposite;
import com.bytel.spirit.common.shared.saab.res.request.ManageOltCompositeRequest;
import com.bytel.spirit.common.shared.saab.res.response.GetOltCompositeResponse;
import com.bytel.spirit.common.shared.saab.res.response.GetSurchargeResponse;
import com.bytel.spirit.common.shared.saab.res.response.ManageOltCompositeResponse;
import com.bytel.spirit.common.shared.saab.res.response.NoeudRaccordementResponse;

/**
 *
 * @author jiantila
 * @version ($Revision: 49682 $ $Date: 2021-03-24 14:30:21 +0100 (mer. 24 mars 2021) $)
 */
public class OltCompositeService
{
  public interface IAction
  {
    String GERER_IMPORT = "GererImport"; //$NON-NLS-1$
    String MODIFIER_SURCHAGE_PRISE_CLIENT_ONT_ID = "ModifierSurchargePriseClientOntId"; //$NON-NLS-1$
    String MODIFIER_SURCHARGE_PRISE_CLIENT_PORT_PON = "ModifierSurchargePriseClientPortPon"; //$NON-NLS-1$
    String MODIFIER_SURCHARGE_DEBIT_GARANTI_PORT_PON = "ModifierSurchargeDebitGarantiPortPon"; //$NON-NLS-1$
    String MODIFIER_SURCHARGE_TECHNO_AUTORISEEPORT_PON = "ModifierSurchargeTechnoAutoriseePortPon"; //$NON-NLS-1$
    String MODIFIER_SURCHARGE_VERSION_OLT = "ModifierSurchargeVersionOLT"; //$NON-NLS-1$
    String MODIFIER_SURCHARGE_EXPLOITATION_ONT_ID = "ModifierSurchargeExploitationOntId"; //$NON-NLS-1$
    String MODIFIER_SURCHARGE_OLT_NON_REFERENCE = "GererSuppressionOltNonReference"; //$NON-NLS-1$
    String MODIFIER_SURCHARGE_OLT_PRISE_CLIENT_CARTE = "ModifierSurchargePriseClientCarte"; //$NON-NLS-1$
    String MODIFIER_SURCHARGE_PRISE_CLIENT_OLT = "ModifierSurchargePriseClientOLT"; //$NON-NLS-1$
    String MODIFIER_SURCHARGE_DATE_DEBUT_QUARANTAINE_OLT = "ModifierSurchargeDateDebutQuarantaineOLT";//$NON-NLS-1$
  }

  public interface IMethodName
  {
    String OLT_COMPOSITE_GERER_IMPORT = "oltCompositeGererImport"; //$NON-NLS-1$
    String OLT_COMPOSITE_GERER_SUPPRESSION_OLT_NON_REF = "oltCompositeGererSuppressionOltNonReference"; //$NON-NLS-1$
    String OLT_COMPOSITE_LIRE_SURCHAGE = "oltCompositeLireSurchage"; //$NON-NLS-1$
    String OLT_COMPOSITE_LIRE_UN = "oltCompositeLireUn"; //$NON-NLS-1$
    String OLT_COMPOSITE_MODIFIER_SURCHARGE_DEBIT_GARANTI_PORT_PON = "oltCompositeModifierSurchargeDebitGarantiPortPon"; //$NON-NLS-1$
    String OLT_COMPOSITE_MODIFIER_SURCHARGE_EXPLOITATION_ONT_ID = "oltCompositeModifierSurchargeExploitationOntId"; //$NON-NLS-1$
    String OLT_COMPOSITE_MODIFIER_SURCHARGE_PRISE_CLIENT_CARTE = "oltCompositeModifierSurchargePriseClientCarte"; //$NON-NLS-1$
    String OLT_COMPOSITE_MODIFIER_SURCHARGE_PRISE_CLIENT_OLT = "oltCompositeModifierSurchargePriseClientOLT"; //$NON-NLS-1$
    String OLT_COMPOSITE_MODIFIER_SURCHARGE_PRISE_CLIENT_ONT_ID = "oltCompositeModifierSurchargePriseClientOntId"; //$NON-NLS-1$
    String OLT_COMPOSITE_MODIFIER_SURCHARGE_PRISE_CLIENT_PORT_PON = "oltCompositeModifierSurchargePriseClientPortPon"; //$NON-NLS-1$
    String OLT_COMPOSITE_MODIFIER_SURCHARGE_TECHNO_AUTORISEE_PORT_PON = "oltCompositeModifierSurchargeTechnoAutoriseePortPon"; //$NON-NLS-1$
    String OLT_COMPOSITE_MODIFIER_SURCHARGE_VERSION_OLT = "oltCompositeModifierSurchargeVersionOLT"; //$NON-NLS-1$
    String OLT_COMPOSITE_MODIFIER_SURCHARGE_DATE_DEBUT_QUARANTAINE_OLT = "oltCompositemodifierSurchargeDateDebutQuarantaineOLT";//$NON-NLS-1$
  }

  /** The connector instance */
  private final RESConnector _resInstance;

  /** The json builder */
  private final IRavelJson _jsonBuilder;

  /**
   * @param resInstance_p
   *          {@link RESConnector}
   */
  public OltCompositeService(RESConnector resInstance_p)
  {
    _resInstance = resInstance_p;
    _jsonBuilder = new RavelJson.RavelJsonBuilder().profil(SpiritConstants.JSON_PROFILE_STARK).build();
  }

  /**
   * @param tracabilite_p
   * @param oltCompositeUrl_p
   * @param oltComposite_p
   * @return
   * @throws RavelException
   */
  public ConnectorResponse<Retour, Nothing> oltCompositeGererImport(Tracabilite tracabilite_p, String oltCompositeUrl_p, OltComposite oltComposite_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(oltCompositeUrl_p))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(IRESConnector.MESSAGE_MISSING_CONFIGURATION_PARAMETER, IRESConnector.PAD3200_PATH_PARAM));
      }

      Retour retour;
      Response response;
      HashMap<String, String> queryParams = new HashMap<>();
      queryParams.put(IRESConnector.PARAM_ACTION, IAction.GERER_IMPORT);

      ManageOltCompositeRequest request = new ManageOltCompositeRequest(oltComposite_p);

      try
      {
        RESTRequest restRequest = new RESTRequestBuilder()//
            .httpMethod(HttpMethod.PUT)//
            .traceability(tracabilite_p)//
            .serializer(_jsonBuilder)//
            .method(IMethodName.OLT_COMPOSITE_GERER_IMPORT)//
            .headers(AbstractInternalRESTConnector.getSpiritStarkRequestHeader())//
            .path(oltCompositeUrl_p)//
            .queryParameter(queryParams)//
            .request(request)//
            .build();
        response = _resInstance.sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content to a JSON string
      NoeudRaccordementResponse basicResponse = _resInstance.getContentFromResponse(tracabilite_p, response, IMethodName.OLT_COMPOSITE_GERER_IMPORT, NoeudRaccordementResponse.class);
      // Retour OK
      retour = RetourConverter.convertFromJsonRetour(basicResponse.getRetour());
      return new ConnectorResponse<>(retour, null);
    }
    catch (Exception ex_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, ex_p.getMessage()), null);
    }

  }

  /**
   * OltComposite oltCompositeGererSuppressionOltNonReference verb (PAD3200)
   *
   * @param tracabilite_p
   *          tracabilite
   * @param oltCompositeUrl_p
   *          SAAB Path.
   * @param listeNomOLT_p
   *          request
   * @return ConnectorResponse with a set of CompteRenduSuppression.
   * @throws RavelException
   *           if the SAAB call fails.
   */
  public ConnectorResponse<Retour, Set<CompteRenduSuppression>> oltCompositeGererSuppressionOltNonReference(Tracabilite tracabilite_p, String oltCompositeUrl_p, Set<String> listeNomOLT_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(oltCompositeUrl_p))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(IRESConnector.MESSAGE_MISSING_CONFIGURATION_PARAMETER, IRESConnector.PAD3200_PATH_PARAM));
      }

      Response response;
      HashMap<String, String> queryParams = new HashMap<>();
      queryParams.put(IRESConnector.PARAM_ACTION, IAction.MODIFIER_SURCHARGE_OLT_NON_REFERENCE);

      ManageOltCompositeRequest request = new ManageOltCompositeRequest(listeNomOLT_p);

      try
      {
        RESTRequest restRequest = new RESTRequestBuilder()//
            .httpMethod(HttpMethod.PUT)//
            .traceability(tracabilite_p)//
            .serializer(_jsonBuilder)//
            .method(IMethodName.OLT_COMPOSITE_GERER_SUPPRESSION_OLT_NON_REF)//
            .headers(AbstractInternalRESTConnector.getSpiritStarkRequestHeader())//
            .path(oltCompositeUrl_p)//
            .queryParameter(queryParams)//
            .request(request)//
            .build();
        response = _resInstance.sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content to a JSON string
      ManageOltCompositeResponse manageOltResponse = _resInstance.getContentFromResponse(tracabilite_p, response, IMethodName.OLT_COMPOSITE_GERER_SUPPRESSION_OLT_NON_REF, ManageOltCompositeResponse.class);
      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(manageOltResponse.getRetour());
      Set<CompteRenduSuppression> compteRendu = manageOltResponse.getListeCompteRenduSupression();

      return new ConnectorResponse<>(retour, compteRendu);
    }
    catch (Exception ex_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, ex_p.getMessage()), null);
    }

  }

  /**
   * Ce service permet de consulter un « OltComposite » à partir du nom de l’OLT un de ses sous-objets "surcharge".
   *
   * @param tracabilite_p
   *          tracabilite
   * @param oltCompositeUrl_p
   *          olt Composite
   * @param nomOLT_p
   *          nom olT
   * @param action_p
   *          action
   * @param positionCarte_p
   *          position carte
   * @param positionPortPon_p
   *          position port pon
   * @param positionOntId_p
   *          position ont id
   * @return ConnectorResponse<Retour, GetOltSurchargeResponse>
   * @throws RavelException
   *           exception
   */
  public ConnectorResponse<Retour, GetSurchargeResponse> oltCompositeLireSurchage(Tracabilite tracabilite_p, String oltCompositeUrl_p, String nomOLT_p, String action_p, String positionCarte_p, String positionPortPon_p, String positionOntId_p) throws RavelException
  {
    if (StringTools.isNullOrEmpty(oltCompositeUrl_p))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(IRESConnector.MESSAGE_MISSING_CONFIGURATION_PARAMETER, IRESConnector.PAD3200_PATH_PARAM));
    }

    HashMap<String, String> queryParams = new HashMap<>();

    queryParams.put(IRESConnector.PARAM_ACTION, action_p);
    queryParams.put(IRESConnector.PARAM_NOM_OLT, nomOLT_p);

    if (!StringTools.isNullOrEmpty(positionCarte_p))
    {
      queryParams.put(IRESConnector.PARAM_POSITION_CARTE, positionCarte_p);
    }
    if (!StringTools.isNullOrEmpty(positionPortPon_p))
    {
      queryParams.put(IRESConnector.PARAM_POSITION_PORT_PON, positionPortPon_p);
    }
    if (!StringTools.isNullOrEmpty(positionOntId_p))
    {
      queryParams.put(IRESConnector.PARAM_POSITION_ONT_ID, positionOntId_p);
    }

    // Call SAAB
    final Response response;
    try
    {
      RESTRequest restRequest = new RESTRequestBuilder()//
          .httpMethod(HttpMethod.GET).traceability(tracabilite_p)//
          .method(IMethodName.OLT_COMPOSITE_LIRE_SURCHAGE)//
          .headers(AbstractInternalRESTConnector.getSpiritStarkRequestHeader())//
          .path(oltCompositeUrl_p)//
          .queryParameter(queryParams).build();
      response = _resInstance.sendRequest(restRequest);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
    }

    GetSurchargeResponse getOltSurchageResponse = _resInstance.getContentFromResponse(tracabilite_p, response, IMethodName.OLT_COMPOSITE_LIRE_SURCHAGE, GetSurchargeResponse.class);

    // Retour OK
    Retour retour = RetourConverter.convertFromJsonRetour(getOltSurchageResponse.getRetour());

    return new ConnectorResponse<>(retour, getOltSurchageResponse);
  }

  /**
   * OLTComposite.LireUn verb.
   *
   * @param tracabilite_p
   *          Tracability.
   * @param oltCompositeUrl_p
   *          OLT URL for SAAB.
   * @param nomOLT_p
   *          Name of the OLT.
   * @return Olt Composite?
   * @throws RavelException
   *           if a trouble happens during SAAB invocation.
   */
  public ConnectorResponse<Retour, OltComposite> oltCompositeLireUn(Tracabilite tracabilite_p, String oltCompositeUrl_p, String nomOLT_p) throws RavelException
  {
    if (StringTools.isNullOrEmpty(oltCompositeUrl_p))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(IRESConnector.MESSAGE_MISSING_CONFIGURATION_PARAMETER, IRESConnector.PAD3200_PATH_PARAM));
    }

    HashMap<String, String> queryParams = new HashMap<>();
    if (!StringTools.isNullOrEmpty(nomOLT_p))
    {
      queryParams.put(IRESConnector.PARAM_NOM_OLT, nomOLT_p);
    }
    // Call SAAB
    final Response response;
    try
    {
      RESTRequest restRequest = new RESTRequestBuilder()//
          .httpMethod(HttpMethod.GET).traceability(tracabilite_p)//
          .method(IMethodName.OLT_COMPOSITE_LIRE_UN)//
          .headers(AbstractInternalRESTConnector.getSpiritStarkRequestHeader())//
          .path(oltCompositeUrl_p)//
          .queryParameter(queryParams).build();
      response = _resInstance.sendRequest(restRequest);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
    }

    GetOltCompositeResponse getOltCompositeResponse = _resInstance.getContentFromResponse(tracabilite_p, response, IMethodName.OLT_COMPOSITE_LIRE_UN, GetOltCompositeResponse.class);

    // Retour OK
    Retour retour = RetourConverter.convertFromJsonRetour(getOltCompositeResponse.getRetour());
    OltComposite oltComposite = getOltCompositeResponse.getOltComposite();

    return new ConnectorResponse<>(retour, oltComposite);
  }

  public ConnectorResponse<Retour, Nothing> oltCompositemodifierSurchargeDateDebutQuarantaineOLT(Tracabilite tracabilite_p, String oltCompositeUrl_p, ListeTechnologieAutorisee listTechnoAutorisee_p, String nomOlt_p) throws RavelException
  {

    if (StringTools.isNullOrEmpty(oltCompositeUrl_p))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(IRESConnector.MESSAGE_MISSING_CONFIGURATION_PARAMETER, IRESConnector.PAD3200_PATH_PARAM));
    }

    HashMap<String, String> queryParams = new HashMap<>();
    queryParams.put(IRESConnector.PARAM_ACTION, IAction.MODIFIER_SURCHARGE_DATE_DEBUT_QUARANTAINE_OLT);
    queryParams.put(IRESConnector.PARAM_NOM_OLT, nomOlt_p);

    // Call SAAB
    final Response response;
    try
    {
      RESTRequest restRequest = new RESTRequestBuilder()//
          .httpMethod(HttpMethod.PUT)//
          .traceability(tracabilite_p)//
          .serializer(_jsonBuilder)//
          .request(listTechnoAutorisee_p)//
          .method(IMethodName.OLT_COMPOSITE_MODIFIER_SURCHARGE_DATE_DEBUT_QUARANTAINE_OLT)//
          .headers(AbstractInternalRESTConnector.getSpiritStarkRequestHeader())//
          .path(oltCompositeUrl_p)//
          .queryParameter(queryParams).build();
      response = _resInstance.sendRequest(restRequest);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
    }

    BasicResponse retourResponse = _resInstance.getContentFromResponse(tracabilite_p, response, IMethodName.OLT_COMPOSITE_MODIFIER_SURCHARGE_DATE_DEBUT_QUARANTAINE_OLT, BasicResponse.class);

    // Retour OK
    Retour retour = RetourConverter.convertFromJsonRetour(retourResponse.getRetour());

    return new ConnectorResponse<>(retour, null);
  }

  /**
   * Ce service permet de modifier un sous-objet "surcharge" spécifique de l'objet "OltComposite".
   *
   * @param tracabilite_p
   *          tracabilite
   * @param oltCompositeUrl_p
   *          olt url
   * @param nomOlt_p
   *          nom OLT
   * @param positionCarte_p
   *          position Carte
   * @param positionPortPon_p
   *          position PortPon
   * @param debitGarantieCapaciteAllouee_p
   *          debitGarantieCapaciteAllouee
   * @return ConnectorResponse<Retour, Nothing>
   * @throws RavelException
   *           exception
   */
  public ConnectorResponse<Retour, Nothing> oltCompositeModifierSurchargeDebitGarantiPortPon(Tracabilite tracabilite_p, String oltCompositeUrl_p, String nomOlt_p, String positionCarte_p, String positionPortPon_p, String debitGarantieCapaciteAllouee_p) throws RavelException
  {
    if (StringTools.isNullOrEmpty(oltCompositeUrl_p))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(IRESConnector.MESSAGE_MISSING_CONFIGURATION_PARAMETER, IRESConnector.PAD3200_PATH_PARAM));
    }

    HashMap<String, String> queryParams = new HashMap<>();
    queryParams.put(IRESConnector.PARAM_ACTION, IAction.MODIFIER_SURCHARGE_DEBIT_GARANTI_PORT_PON);
    queryParams.put(IRESConnector.PARAM_NOM_OLT, nomOlt_p);
    queryParams.put(IRESConnector.PARAM_POSITION_CARTE, positionCarte_p);
    queryParams.put(IRESConnector.PARAM_POSITION_PORT_PON, positionPortPon_p);
    queryParams.put(IRESConnector.PARAM_DEBIT_GARANTI_ALLOUE, debitGarantieCapaciteAllouee_p);

    // Call SAAB
    final Response response;
    try
    {
      RESTRequest restRequest = new RESTRequestBuilder()//
          .httpMethod(HttpMethod.PUT)//
          .traceability(tracabilite_p)//
          .method(IMethodName.OLT_COMPOSITE_MODIFIER_SURCHARGE_DEBIT_GARANTI_PORT_PON)//
          .headers(AbstractInternalRESTConnector.getSpiritStarkRequestHeader())//
          .path(oltCompositeUrl_p)//
          .queryParameter(queryParams).build();
      response = _resInstance.sendRequest(restRequest);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
    }

    BasicResponse retourResponse = _resInstance.getContentFromResponse(tracabilite_p, response, IMethodName.OLT_COMPOSITE_MODIFIER_SURCHARGE_DEBIT_GARANTI_PORT_PON, BasicResponse.class);

    // Retour OK
    Retour retour = RetourConverter.convertFromJsonRetour(retourResponse.getRetour());

    return new ConnectorResponse<>(retour, null);
  }

  /**
   * Ce service permet de modifier un sous-objet "surcharge" spécifique de l'objet "OltComposite".
   * SurchargeExploitationOntId
   *
   * @param tracabilite_p
   *          tracabilite
   * @param oltCompositeUrl_p
   *          oltComposite url
   * @param nomOlt_p
   *          nom OLT
   * @param positionCarte_p
   *          position Carte
   * @param positionPortPon_p
   *          position PortPon
   * @param positionOntId_p
   *          positionOntId
   * @param statutExploitation_p
   *          statutExploitation
   * @param commentaireExploitation_p
   *          commentaireExploitation
   * @return ConnectorResponse<Retour, Nothing>
   * @throws RavelException
   *           exception
   */
  public ConnectorResponse<Retour, Nothing> oltCompositeModifierSurchargeExploitationOntId(Tracabilite tracabilite_p, String oltCompositeUrl_p, String nomOlt_p, String positionCarte_p, String positionPortPon_p, String positionOntId_p, String statutExploitation_p, String commentaireExploitation_p) throws RavelException
  {
    if (StringTools.isNullOrEmpty(oltCompositeUrl_p))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(IRESConnector.MESSAGE_MISSING_CONFIGURATION_PARAMETER, IRESConnector.PAD3200_PATH_PARAM));
    }

    HashMap<String, String> queryParams = new HashMap<>();
    queryParams.put(IRESConnector.PARAM_ACTION, IAction.MODIFIER_SURCHARGE_EXPLOITATION_ONT_ID);
    queryParams.put(IRESConnector.PARAM_NOM_OLT, nomOlt_p);
    queryParams.put(IRESConnector.PARAM_POSITION_CARTE, positionCarte_p);
    queryParams.put(IRESConnector.PARAM_POSITION_PORT_PON, positionPortPon_p);
    queryParams.put(IRESConnector.PARAM_POSITION_ONT_ID, positionOntId_p);
    queryParams.put(IRESConnector.STATUT_EXPLOITATION, statutExploitation_p);
    if (!StringTools.isNullOrEmpty(commentaireExploitation_p))
    {
      queryParams.put(IRESConnector.COMMENTAIRE_EXPLOITATION, commentaireExploitation_p);

    }
    // Call SAAB
    final Response response;
    try
    {
      RESTRequest restRequest = new RESTRequestBuilder()//
          .httpMethod(HttpMethod.PUT)//
          .traceability(tracabilite_p)//
          .method(IMethodName.OLT_COMPOSITE_MODIFIER_SURCHARGE_EXPLOITATION_ONT_ID)//
          .headers(AbstractInternalRESTConnector.getSpiritStarkRequestHeader())//
          .path(oltCompositeUrl_p)//
          .queryParameter(queryParams).build();
      response = _resInstance.sendRequest(restRequest);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
    }

    BasicResponse retourResponse = _resInstance.getContentFromResponse(tracabilite_p, response, IMethodName.OLT_COMPOSITE_MODIFIER_SURCHARGE_EXPLOITATION_ONT_ID, BasicResponse.class);

    // Retour OK
    Retour retour = RetourConverter.convertFromJsonRetour(retourResponse.getRetour());

    return new ConnectorResponse<>(retour, null);
  }

  /**
   * Ce service permet de modifier un sous-objet "surcharge" spécifique de l'objet "OltComposite".
   * SurchargePriseClientCarte
   *
   * @param tracabilite_p
   *          tracabilite
   * @param oltCompositeUrl_p
   *          olt composite url
   * @param nomOlt_p
   *          nom olt
   * @param positionCarte_p
   *          positionCarte
   * @param statutBlocage_p
   *          statutBlocage
   * @param commentaireBlocage_p
   *          commentaireBlocage
   * @return ConnectorResponse<Retour, Nothing>
   * @throws RavelException
   *           exception
   */
  public ConnectorResponse<Retour, Nothing> oltCompositeModifierSurchargePriseClientCarte(Tracabilite tracabilite_p, String oltCompositeUrl_p, String nomOlt_p, String positionCarte_p, String statutBlocage_p, String commentaireBlocage_p) throws RavelException
  {
    if (StringTools.isNullOrEmpty(oltCompositeUrl_p))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(IRESConnector.MESSAGE_MISSING_CONFIGURATION_PARAMETER, IRESConnector.PAD3200_PATH_PARAM));
    }

    HashMap<String, String> queryParams = new HashMap<>();
    queryParams.put(IRESConnector.PARAM_ACTION, IAction.MODIFIER_SURCHARGE_OLT_PRISE_CLIENT_CARTE);
    queryParams.put(IRESConnector.PARAM_NOM_OLT, nomOlt_p);
    queryParams.put(IRESConnector.PARAM_POSITION_CARTE, positionCarte_p);
    queryParams.put(IRESConnector.STATUT_BLOCAGE, statutBlocage_p);
    if (!StringTools.isNullOrEmpty(commentaireBlocage_p))
    {
      queryParams.put(IRESConnector.COMMENTAIRE_BLOCAGE, commentaireBlocage_p);
    }
    // Call SAAB
    final Response response;
    try
    {
      RESTRequest restRequest = new RESTRequestBuilder()//
          .httpMethod(HttpMethod.PUT)//
          .traceability(tracabilite_p)//
          .method(IMethodName.OLT_COMPOSITE_MODIFIER_SURCHARGE_PRISE_CLIENT_CARTE)//
          .headers(AbstractInternalRESTConnector.getSpiritStarkRequestHeader())//
          .path(oltCompositeUrl_p)//
          .queryParameter(queryParams).build();
      response = _resInstance.sendRequest(restRequest);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
    }

    BasicResponse retourResponse = _resInstance.getContentFromResponse(tracabilite_p, response, IMethodName.OLT_COMPOSITE_MODIFIER_SURCHARGE_PRISE_CLIENT_CARTE, BasicResponse.class);

    // Retour OK
    Retour retour = RetourConverter.convertFromJsonRetour(retourResponse.getRetour());

    return new ConnectorResponse<>(retour, null);
  }

  /**
   * @param tracabilite_p
   * @param oltCompositeUrl_p
   * @param nomOlt_p
   * @param statutBlocage_p
   * @param commentaireBlocage_p
   * @return
   * @throws RavelException
   */
  public ConnectorResponse<Retour, Nothing> oltCompositeModifierSurchargePriseClientOLT(Tracabilite tracabilite_p, String oltCompositeUrl_p, String nomOlt_p, String statutBlocage_p, String commentaireBlocage_p) throws RavelException
  {
    if (StringTools.isNullOrEmpty(oltCompositeUrl_p))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(IRESConnector.MESSAGE_MISSING_CONFIGURATION_PARAMETER, IRESConnector.PAD3200_PATH_PARAM));
    }

    HashMap<String, String> queryParams = new HashMap<>();
    queryParams.put(IRESConnector.PARAM_ACTION, IAction.MODIFIER_SURCHARGE_PRISE_CLIENT_OLT);
    queryParams.put(IRESConnector.PARAM_NOM_OLT, nomOlt_p);
    queryParams.put(IRESConnector.STATUT_BLOCAGE, statutBlocage_p);
    if (!StringTools.isNullOrEmpty(commentaireBlocage_p))
    {
      queryParams.put(IRESConnector.COMMENTAIRE_BLOCAGE, commentaireBlocage_p);
    }
    // Call SAAB
    final Response response;
    try
    {
      RESTRequest restRequest = new RESTRequestBuilder()//
          .httpMethod(HttpMethod.PUT)//
          .traceability(tracabilite_p)//
          .method(IMethodName.OLT_COMPOSITE_MODIFIER_SURCHARGE_PRISE_CLIENT_OLT)//
          .headers(AbstractInternalRESTConnector.getSpiritStarkRequestHeader())//
          .path(oltCompositeUrl_p)//
          .queryParameter(queryParams).build();
      response = _resInstance.sendRequest(restRequest);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
    }

    BasicResponse retourResponse = _resInstance.getContentFromResponse(tracabilite_p, response, IMethodName.OLT_COMPOSITE_MODIFIER_SURCHARGE_PRISE_CLIENT_OLT, BasicResponse.class);

    // Retour OK
    Retour retour = RetourConverter.convertFromJsonRetour(retourResponse.getRetour());

    return new ConnectorResponse<>(retour, null);
  }

  /**
   * @param tracabilite_p
   * @param oltCompositeUrl_p
   * @param nomOlt_p
   * @param positionCarte_p
   * @param positionPortPon_p
   * @param positionOntId_p
   * @param statutBlocage_p
   * @param commentaireBlocage_p
   * @return
   * @throws RavelException
   */
  public ConnectorResponse<Retour, Nothing> oltCompositeModifierSurchargePriseClientOntId(Tracabilite tracabilite_p, String oltCompositeUrl_p, String nomOlt_p, String positionCarte_p, String positionPortPon_p, String positionOntId_p, String statutBlocage_p, String commentaireBlocage_p) throws RavelException
  {
    if (StringTools.isNullOrEmpty(oltCompositeUrl_p))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(IRESConnector.MESSAGE_MISSING_CONFIGURATION_PARAMETER, IRESConnector.PAD3200_PATH_PARAM));
    }

    HashMap<String, String> queryParams = new HashMap<>();
    queryParams.put(IRESConnector.PARAM_ACTION, IAction.MODIFIER_SURCHAGE_PRISE_CLIENT_ONT_ID);
    queryParams.put(IRESConnector.PARAM_NOM_OLT, nomOlt_p);
    queryParams.put(IRESConnector.PARAM_POSITION_CARTE, positionCarte_p);
    queryParams.put(IRESConnector.PARAM_POSITION_ONT_ID, positionOntId_p);
    queryParams.put(IRESConnector.PARAM_POSITION_PORT_PON, positionPortPon_p);
    queryParams.put(IRESConnector.STATUT_BLOCAGE, statutBlocage_p);
    if (!StringTools.isNullOrEmpty(commentaireBlocage_p))
    {
      queryParams.put(IRESConnector.COMMENTAIRE_BLOCAGE, commentaireBlocage_p);
    }
    // Call SAAB
    final Response response;
    try
    {
      RESTRequest restRequest = new RESTRequestBuilder()//
          .httpMethod(HttpMethod.PUT)//
          .traceability(tracabilite_p)//
          .method(IMethodName.OLT_COMPOSITE_MODIFIER_SURCHARGE_PRISE_CLIENT_ONT_ID)//
          .headers(AbstractInternalRESTConnector.getSpiritStarkRequestHeader())//
          .path(oltCompositeUrl_p)//
          .queryParameter(queryParams).build();
      response = _resInstance.sendRequest(restRequest);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
    }

    BasicResponse retourResponse = _resInstance.getContentFromResponse(tracabilite_p, response, IMethodName.OLT_COMPOSITE_MODIFIER_SURCHARGE_PRISE_CLIENT_ONT_ID, BasicResponse.class);

    // Retour OK
    Retour retour = RetourConverter.convertFromJsonRetour(retourResponse.getRetour());

    return new ConnectorResponse<>(retour, null);
  }

  /**
   * @param tracabilite_p
   * @param oltCompositeUrl_p
   * @param nomOlt_p
   * @param positionCarte_p
   * @param positionPortPon_p
   * @param statutBlocage_p
   * @param commentaireBlocage_p
   * @return
   * @throws RavelException
   */
  public ConnectorResponse<Retour, Nothing> oltCompositeModifierSurchargePriseClientPortPon(Tracabilite tracabilite_p, String oltCompositeUrl_p, String nomOlt_p, String positionCarte_p, String positionPortPon_p, String statutBlocage_p, String commentaireBlocage_p) throws RavelException
  {
    if (StringTools.isNullOrEmpty(oltCompositeUrl_p))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(IRESConnector.MESSAGE_MISSING_CONFIGURATION_PARAMETER, IRESConnector.PAD3200_PATH_PARAM));
    }

    HashMap<String, String> queryParams = new HashMap<>();
    queryParams.put(IRESConnector.PARAM_ACTION, IAction.MODIFIER_SURCHARGE_PRISE_CLIENT_PORT_PON);
    queryParams.put(IRESConnector.PARAM_NOM_OLT, nomOlt_p);
    queryParams.put(IRESConnector.PARAM_POSITION_CARTE, positionCarte_p);
    queryParams.put(IRESConnector.PARAM_POSITION_PORT_PON, positionPortPon_p);
    queryParams.put(IRESConnector.STATUT_BLOCAGE, statutBlocage_p);
    if (!StringTools.isNullOrEmpty(commentaireBlocage_p))
    {
      queryParams.put(IRESConnector.COMMENTAIRE_BLOCAGE, commentaireBlocage_p);
    }
    // Call SAAB
    final Response response;
    try
    {
      RESTRequest restRequest = new RESTRequestBuilder()//
          .httpMethod(HttpMethod.PUT)//
          .traceability(tracabilite_p)//
          .method(IMethodName.OLT_COMPOSITE_MODIFIER_SURCHARGE_PRISE_CLIENT_PORT_PON)//
          .headers(AbstractInternalRESTConnector.getSpiritStarkRequestHeader())//
          .path(oltCompositeUrl_p)//
          .queryParameter(queryParams).build();
      response = _resInstance.sendRequest(restRequest);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
    }

    BasicResponse retourResponse = _resInstance.getContentFromResponse(tracabilite_p, response, IMethodName.OLT_COMPOSITE_MODIFIER_SURCHARGE_PRISE_CLIENT_PORT_PON, BasicResponse.class);

    // Retour OK
    Retour retour = RetourConverter.convertFromJsonRetour(retourResponse.getRetour());

    return new ConnectorResponse<>(retour, null);
  }

  /**
   * @param tracabilite_p
   * @param oltCompositeUrl_p
   * @param listTechnoAutorisee_p
   * @param nomOlt_p
   * @param positionCarte_p
   * @param positionPortPon_p
   * @return
   * @throws RavelException
   */
  public ConnectorResponse<Retour, Nothing> oltCompositeModifierSurchargeTechnoAutoriseePortPon(Tracabilite tracabilite_p, String oltCompositeUrl_p, ListeTechnologieAutorisee listTechnoAutorisee_p, String nomOlt_p, String positionCarte_p, String positionPortPon_p) throws RavelException
  {
    if (StringTools.isNullOrEmpty(oltCompositeUrl_p))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(IRESConnector.MESSAGE_MISSING_CONFIGURATION_PARAMETER, IRESConnector.PAD3200_PATH_PARAM));
    }

    HashMap<String, String> queryParams = new HashMap<>();
    queryParams.put(IRESConnector.PARAM_ACTION, IAction.MODIFIER_SURCHARGE_TECHNO_AUTORISEEPORT_PON);
    queryParams.put(IRESConnector.PARAM_NOM_OLT, nomOlt_p);
    queryParams.put(IRESConnector.PARAM_POSITION_CARTE, positionCarte_p);
    queryParams.put(IRESConnector.PARAM_POSITION_PORT_PON, positionPortPon_p);

    // Call SAAB
    final Response response;
    try
    {
      RESTRequest restRequest = new RESTRequestBuilder()//
          .httpMethod(HttpMethod.PUT)//
          .traceability(tracabilite_p)//
          .serializer(_jsonBuilder)//
          .request(listTechnoAutorisee_p)//
          .method(IMethodName.OLT_COMPOSITE_MODIFIER_SURCHARGE_TECHNO_AUTORISEE_PORT_PON)//
          .headers(AbstractInternalRESTConnector.getSpiritStarkRequestHeader())//
          .path(oltCompositeUrl_p)//
          .queryParameter(queryParams).build();
      response = _resInstance.sendRequest(restRequest);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
    }

    BasicResponse retourResponse = _resInstance.getContentFromResponse(tracabilite_p, response, IMethodName.OLT_COMPOSITE_MODIFIER_SURCHARGE_TECHNO_AUTORISEE_PORT_PON, BasicResponse.class);

    // Retour OK
    Retour retour = RetourConverter.convertFromJsonRetour(retourResponse.getRetour());

    return new ConnectorResponse<>(retour, null);
  }

  /**
   * @param tracabilite_p
   *          tracabilite
   * @param oltCompositeUrl_p
   *          oltComposite Url
   * @param listTechnoAutorisee_p
   *          list TechnoAutorisee
   * @param nomOlt_p
   *          nom olt
   * @param versionInterfaceEchange_p
   *          version InterfaceEchange
   * @return ConnectorResponse<Retour, Nothing>
   * @throws RavelException
   *           exception
   */
  public ConnectorResponse<Retour, Nothing> oltCompositeModifierSurchargeVersionOLT(Tracabilite tracabilite_p, String oltCompositeUrl_p, ListeTechnologieAutorisee listTechnoAutorisee_p, String nomOlt_p, String versionInterfaceEchange_p) throws RavelException
  {
    if (StringTools.isNullOrEmpty(oltCompositeUrl_p))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(IRESConnector.MESSAGE_MISSING_CONFIGURATION_PARAMETER, IRESConnector.PAD3200_PATH_PARAM));
    }

    HashMap<String, String> queryParams = new HashMap<>();
    queryParams.put(IRESConnector.PARAM_ACTION, IAction.MODIFIER_SURCHARGE_VERSION_OLT);
    queryParams.put(IRESConnector.PARAM_NOM_OLT, nomOlt_p);
    queryParams.put(IRESConnector.PARAM_VERSION_INTERFACE_ECHANGE, versionInterfaceEchange_p);

    // Call SAAB
    final Response response;
    try
    {
      RESTRequest restRequest = new RESTRequestBuilder()//
          .httpMethod(HttpMethod.PUT)//
          .traceability(tracabilite_p)//
          .serializer(_jsonBuilder)//
          .request(listTechnoAutorisee_p)//
          .method(IMethodName.OLT_COMPOSITE_MODIFIER_SURCHARGE_VERSION_OLT)//
          .headers(AbstractInternalRESTConnector.getSpiritStarkRequestHeader())//
          .path(oltCompositeUrl_p)//
          .queryParameter(queryParams).build();
      response = _resInstance.sendRequest(restRequest);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
    }

    BasicResponse retourResponse = _resInstance.getContentFromResponse(tracabilite_p, response, IMethodName.OLT_COMPOSITE_MODIFIER_SURCHARGE_VERSION_OLT, BasicResponse.class);

    // Retour OK
    Retour retour = RetourConverter.convertFromJsonRetour(retourResponse.getRetour());

    return new ConnectorResponse<>(retour, null);
  }
}
