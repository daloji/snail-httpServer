/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.res.services;

import java.util.List;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.probes.AvgDoubleCollectorItem;
import com.bytel.ravel.common.probes.AvgFlowPerSecondCollector;
import com.bytel.ravel.common.probes.RavelProbeConfigurationManager;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.services.connector.ConnectorManager;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.connectors.res.IRESConnector;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.Ressource;

/**
 * @author jpais
 * @version ($Revision$ $Date$)
 */
public class RessourceProxy
{
  /** connector Id */
  private String _connectorId;

  /** For probe to count the execution time of call to the ressourceModifierRessouceLie operation */
  AvgDoubleCollectorItem _avg_ressourceModifierRessouceLie_ExecTime;
  /** For probe to count the amount of call to the ressourceModifierRessouceLie operation */
  AvgFlowPerSecondCollector _avg_ressourceModifierRessouceLie_call_counter;

  /** For probe to count the amount of call to the pad3100RessourceLireTousParIdRessourceLie operation */
  AvgFlowPerSecondCollector _avg_ressourceLireTousParIdRessourceLie_call_counter;
  /** For probe to count the execution time of call to the pad3100RessourceLireTousParIdRessourceLie operation */
  AvgDoubleCollectorItem _avg_ressourceLireTousParIdRessourceLie_ExecTime;

  /** For probe to count the amount of call to the ressourceLireUn operation */
  AvgFlowPerSecondCollector _avg_ressourceLireUn_call_counter;
  /** For probe to count the execution time of call to the ressourceLireUn operation */
  AvgDoubleCollectorItem _avg_ressourceLireUn_ExecTime;

  /**
   *
   * @param connectorId_p
   */
  public RessourceProxy(String connectorId_p)
  {
    _connectorId = connectorId_p;

    _avg_ressourceLireTousParIdRessourceLie_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_ressourceLireTousParIdRessourceLie_call_counter", "RESProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_ressourceLireTousParIdRessourceLie_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_ressourceLireTousParIdRessourceLie_ExecTime", "RESProxy"); //$NON-NLS-1$ //$NON-NLS-2$

    _avg_ressourceModifierRessouceLie_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_ressourceModifierRessouceLie_call_counter", "RESProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_ressourceModifierRessouceLie_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_ressourceModifierRessouceLie_Read_ExecTime", "RESProxy"); //$NON-NLS-1$ //$NON-NLS-2$

    _avg_ressourceLireUn_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_ressourceLireUn_call_counter", "RESProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_ressourceLireUn_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_ressourceLireUn_ExecTime", "RESProxy"); //$NON-NLS-1$ //$NON-NLS-2$
  }

  /**
   * ressourceLireTousParIdRessourceLie
   *
   * @param tracabilite_p
   *          tracabilite
   * @param idRessourceLie_p
   *          idRessourceLie
   * @param typeRessource_p
   *          typeRessource
   * @return
   * @throws RavelException
   */
  public ConnectorResponse<Retour, List<Ressource>> ressourceLireTousParIdRessourceLie(Tracabilite tracabilite_p, String idRessourceLie_p, String typeRessource_p) throws RavelException
  {
    IRESConnector resConnector = null;
    try
    {
      resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
    }
    catch (Exception e_p)
    {
      // Retour NOK
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
    }
    _avg_ressourceLireTousParIdRessourceLie_call_counter.measure();
    long startTime = System.currentTimeMillis();
    try
    {
      return resConnector.ressourceLireTousParIdRessourceLie(tracabilite_p, idRessourceLie_p, typeRessource_p);
    }
    finally
    {
      long endTime = System.currentTimeMillis();
      _avg_ressourceLireTousParIdRessourceLie_ExecTime.updateAvgValue(endTime - startTime);
    }
  }

  /**
   * ressourceLireUn
   *
   * @param tracabilite_p
   * @param idRessource_p
   * @param typeRessource_p
   * @return
   * @throws RavelException
   */
  public ConnectorResponse<Retour, Ressource> ressourceLireUn(Tracabilite tracabilite_p, String idRessource_p, String typeRessource_p) throws RavelException
  {

    IRESConnector resConnector = null;
    try
    {
      resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
    }
    catch (Exception e_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
    }
    _avg_ressourceLireUn_call_counter.measure();
    long startTime = System.currentTimeMillis();
    try
    {
      return resConnector.ressourceLireUn(tracabilite_p, idRessource_p, typeRessource_p);
    }
    finally
    {
      long endTime = System.currentTimeMillis();
      _avg_ressourceLireUn_ExecTime.updateAvgValue(endTime - startTime);
    }
  }

  /**
   * ressourceModifierIdRessourceLie
   *
   * @param tracabilite_p
   * @param typeRessource_p
   * @param idRessource_p
   * @param idRessourceLie_p
   * @param idRessourceLieCible_p
   * @return
   * @throws RavelException
   */
  public ConnectorResponse<Retour, Nothing> ressourceModifierIdRessourceLie(Tracabilite tracabilite_p, String typeRessource_p, String idRessource_p, String idRessourceLie_p, String idRessourceLieCible_p) throws RavelException
  {
    IRESConnector resConnector = null;
    try
    {
      resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
    }
    catch (Exception e_p)
    {
      // Retour NOK
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
    }
    _avg_ressourceModifierRessouceLie_call_counter.measure();
    long startTime = System.currentTimeMillis();
    try
    {
      return resConnector.ressourceModifierIdRessourceLie(tracabilite_p, typeRessource_p, idRessource_p, idRessourceLie_p, idRessourceLieCible_p);
    }
    finally
    {
      long endTime = System.currentTimeMillis();
      _avg_ressourceModifierRessouceLie_ExecTime.updateAvgValue(endTime - startTime);
    }
  }

}
