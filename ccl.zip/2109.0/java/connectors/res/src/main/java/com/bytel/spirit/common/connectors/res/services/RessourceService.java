/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.res.services;

import java.util.HashMap;
import java.util.List;

import javax.ws.rs.HttpMethod;
import javax.ws.rs.core.Response;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.connector.RESTRequest;
import com.bytel.ravel.services.connector.RESTRequest.RESTRequestBuilder;
import com.bytel.spirit.common.connectors.res.RESConnector;
import com.bytel.spirit.common.shared.misc.connectors.AbstractInternalRESTConnector;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.BasicResponse;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.ressources.RetourConverter;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.Ressource;
import com.bytel.spirit.common.shared.saab.res.response.GetRessourceResponse;

/**
 * Service class implementation for PAD3100
 *
 * @author jpais
 * @version ($Revision$ $Date$)
 */
public class RessourceService
{
  public interface IMethodName
  {
    String RESSOURCE_MODIFIER_RESSOURCE_LIE = "ressourceModifierIdRessourceLie"; //$NON-NLS-1$
    String RESSOURCE_LIRE_TOUS_PAR_ID_RESSOURCE_LIE = "ressourceLireTousParIdRessourceLie"; //$NON-NLS-1$
    String RESSOURCE_LIRE_UN = "ressourceLireUn"; //$NON-NLS-1$
  }

  public interface IParameter
  {
    String ID_RESSOURCE_LIE = "idRessourceLie"; //$NON-NLS-1$
    String TYPE_RESSOURCE = "typeRessource"; //$NON-NLS-1$
    String ID_RESSOURCE = "idRessource"; //$NON-NLS-1$
    String ID_RESSOURCELIE_CIBLE = "idRessourceLieCible"; //$NON-NLS-1$
  }

  /** The connector instance */
  private final RESConnector _resInstance;

  /**
   * Default constructor
   *
   * @param resInstance_p
   *          Current RESConnector instance
   */
  public RessourceService(RESConnector resInstance_p)
  {
    _resInstance = resInstance_p;
  }

  public ConnectorResponse<Retour, List<Ressource>> ressourceLireTousParIdRessourceLie(Tracabilite tracabilite_p, String ressourceUrl_p, String idRessourceLie_p, String typeRessource_p)
  {
    try
    {
      // Query parameters
      HashMap<String, String> queryParams = new HashMap<>();
      if (StringTools.isNotNullOrEmpty(idRessourceLie_p))
      {
        queryParams.put(IParameter.ID_RESSOURCE_LIE, idRessourceLie_p);
        queryParams.put(IParameter.TYPE_RESSOURCE, typeRessource_p);
      }
      // Call SAAB
      final Response response;
      try
      {
        RESTRequest restRequest = new RESTRequestBuilder()//
            .httpMethod(HttpMethod.GET)//
            .traceability(tracabilite_p)//
            .method(IMethodName.RESSOURCE_LIRE_TOUS_PAR_ID_RESSOURCE_LIE)//
            .headers(AbstractInternalRESTConnector.getSpiritStarkRequestHeader())//
            .path(ressourceUrl_p)//
            .queryParameter(queryParams)//
            .build();
        response = _resInstance.sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content to a JSON string
      GetRessourceResponse getListRessourceResponse = _resInstance.getContentFromResponse(tracabilite_p, response, IMethodName.RESSOURCE_LIRE_TOUS_PAR_ID_RESSOURCE_LIE, GetRessourceResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(getListRessourceResponse.getRetour());
      List<Ressource> listressources = getListRessourceResponse.getListRessource();

      return new ConnectorResponse<>(retour, listressources);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  public ConnectorResponse<Retour, Ressource> ressourceLireUn(Tracabilite tracabilite_p, String ressourceUrl_p, String idRessource_p, String typeRessource_p)
  {
    Ressource ressource = null;
    Retour retour = RetourFactory.createOkRetour();

    try
    {
      // Query parameters
      HashMap<String, String> queryParams = new HashMap<>();
      if (StringTools.isNotNullOrEmpty(idRessource_p) && StringTools.isNotNullOrEmpty(typeRessource_p))
      {
        queryParams.put(IParameter.ID_RESSOURCE, idRessource_p);
        queryParams.put(IParameter.TYPE_RESSOURCE, typeRessource_p);
      }

      // Call SAAB
      final Response response;

      try
      {
        RESTRequest restRequest = new RESTRequestBuilder()//
            .httpMethod(HttpMethod.GET)//
            .traceability(tracabilite_p)//
            .method(IMethodName.RESSOURCE_LIRE_UN)//
            .headers(AbstractInternalRESTConnector.getSpiritStarkRequestHeader())//
            .path(ressourceUrl_p)//
            .queryParameter(queryParams)//
            .build();
        response = _resInstance.sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }
      // Get the content to a JSON string
      GetRessourceResponse getRessourceResponse = _resInstance.getContentFromResponse(tracabilite_p, response, IMethodName.RESSOURCE_LIRE_UN, GetRessourceResponse.class);

      if (getRessourceResponse != null)
      {
        retour = RetourConverter.convertFromJsonRetour(getRessourceResponse.getRetour());

        if ((getRessourceResponse.getListRessource() != null) && !getRessourceResponse.getListRessource().isEmpty())
        {
          ressource = getRessourceResponse.getListRessource().get(0);
        }
      }
      return new ConnectorResponse<>(retour, ressource);
    }
    catch (Exception e_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  public ConnectorResponse<Retour, Nothing> ressourceModifierIdRessourceLie(Tracabilite tracabilite_p, String ressourceUrl_p, String typeRessource_p, String idRessource_p, String idRessourceLie_p, String idRessourceLieCible_p)
  {
    try
    {
      // Query parameters
      HashMap<String, String> queryParams = new HashMap<>();
      if (StringTools.isNotNullOrEmpty(idRessourceLie_p))
      {
        queryParams.put(IParameter.ID_RESSOURCE_LIE, idRessourceLie_p);
        queryParams.put(IParameter.TYPE_RESSOURCE, typeRessource_p);
        queryParams.put(IParameter.ID_RESSOURCE, idRessource_p);
        queryParams.put(IParameter.ID_RESSOURCELIE_CIBLE, idRessourceLieCible_p);
      }

      // Call SAAB
      final Response response;
      try
      {
        RESTRequest restRequest = new RESTRequestBuilder()//
            .httpMethod(HttpMethod.PUT)//
            .traceability(tracabilite_p)//
            .method(IMethodName.RESSOURCE_MODIFIER_RESSOURCE_LIE)//
            .headers(AbstractInternalRESTConnector.getSpiritStarkRequestHeader())//
            .path(ressourceUrl_p)//
            .queryParameter(queryParams)//
            .build();
        response = _resInstance.sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }
      // Get the content to a JSON string
      BasicResponse basicResponse = _resInstance.getContentFromResponse(tracabilite_p, response, IMethodName.RESSOURCE_MODIFIER_RESSOURCE_LIE, BasicResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(basicResponse.getRetour());

      return new ConnectorResponse<>(retour, null);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

}
