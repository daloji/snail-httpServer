/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.res.services;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.probes.AvgDoubleCollectorItem;
import com.bytel.ravel.common.probes.AvgFlowPerSecondCollector;
import com.bytel.ravel.common.probes.RavelProbeConfigurationManager;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.services.connector.ConnectorManager;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.connectors.res.IRESConnector;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

/**
 *
 * @author jrolao
 * @version ($Revision$ $Date$)
 */
public class RessourcePortP2PProxy
{

  /** connector Id */
  private final String _connectorId;

  /** For probe to count the amount of call to the ressourcePortP2PGererAllocation operation */
  AvgFlowPerSecondCollector _avg_ressourcePortP2PGererAllocation_call_counter;
  /** For probe to count the execution time of call to the ressourcePortP2PGererAllocation operation */
  AvgDoubleCollectorItem _avg_ressourcePortP2PGererAllocation_ExecTime;

  /** For probe to count the amount of call to the ressourcePortP2PModifierStatutAllocation operation */
  AvgFlowPerSecondCollector _avg_ressourcePortP2PModifierStatutAllocation_call_counter;
  /** For probe to count the execution time of call to the ressourcePortP2PModifierStatutAllocation operation */
  AvgDoubleCollectorItem _avg_ressourcePortP2PModifierStatutAllocation_ExecTime;

  /** For probe to count the amount of call to the _avg_ressourcePortP2PcompterPortLibre operation */
  AvgFlowPerSecondCollector _avg_ressourcePortP2PcompterPortLibreP2P_call_counter;
  /** For probe to count the execution time of call to the _avg_ressourcePortP2PcompterPortLibre_ExecTime operation */
  AvgDoubleCollectorItem _avg_ressourcePortP2PcompterPortLibreP2P_ExecTime;

  /**
   *
   * @param connectorId_p
   */
  public RessourcePortP2PProxy(String connectorId_p)
  {
    _connectorId = connectorId_p;

    _avg_ressourcePortP2PGererAllocation_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_ressourcePortP2PGererAllocation_call_counter", "RESProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_ressourcePortP2PGererAllocation_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_ressourcePortP2PGererAllocation_ExecTime", "RESProxy"); //$NON-NLS-1$ //$NON-NLS-2$

    _avg_ressourcePortP2PModifierStatutAllocation_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_ressourcePortP2PModifierStatutAllocation_call_counter", "RESProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_ressourcePortP2PModifierStatutAllocation_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_ressourcePortP2PModifierStatutAllocation_ExecTime", "RESProxy"); //$NON-NLS-1$ //$NON-NLS-2$

    _avg_ressourcePortP2PcompterPortLibreP2P_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_ressourcePortP2PcompterPortLibreP2P_call_counter", "RESProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_ressourcePortP2PcompterPortLibreP2P_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_ressourcePortP2PcompterPortLibreP2P_ExecTime", "RESProxy"); //$NON-NLS-1$ //$NON-NLS-2$
  }

  public ConnectorResponse<Retour, Nothing> ressourcePortP2PGererAllocation(Tracabilite tracabilite_p, String nomNR_p, String distance_p, String idRessourceLie_p, String action_p) throws RavelException
  {
    IRESConnector resConnector = null;
    try
    {
      resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
    }
    catch (Exception e_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
    }
    _avg_ressourcePortP2PGererAllocation_call_counter.measure();
    long startTime = System.currentTimeMillis();
    try
    {
      return resConnector.ressourcePortP2PGererAllocation(tracabilite_p, nomNR_p, distance_p, idRessourceLie_p, action_p);
    }
    finally
    {
      long endTime = System.currentTimeMillis();
      _avg_ressourcePortP2PGererAllocation_ExecTime.updateAvgValue(endTime - startTime);
    }
  }

  public ConnectorResponse<Retour, Nothing> ressourcePortP2PModifierStatutAllocation(Tracabilite tracabilite_p, String idRessource_p, String idRessourceLie_p, String statut_p) throws RavelException
  {
    IRESConnector resConnector = null;
    try
    {
      resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
    }
    catch (Exception e_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
    }
    _avg_ressourcePortP2PModifierStatutAllocation_call_counter.measure();
    long startTime = System.currentTimeMillis();
    try
    {
      return resConnector.ressourcePortP2PModifierStatutAllocation(tracabilite_p, idRessource_p, idRessourceLie_p, statut_p);
    }
    finally
    {
      long endTime = System.currentTimeMillis();
      _avg_ressourcePortP2PModifierStatutAllocation_ExecTime.updateAvgValue(endTime - startTime);
    }
  }

  public ConnectorResponse<Retour, Integer> ressourcePortP2PcompterPortLibreP2P(Tracabilite tracabilite_p, String nomNR_p) throws RavelException
  {
    IRESConnector resConnector = null;
    try
    {
      resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
    }
    catch (Exception e_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
    }
    _avg_ressourcePortP2PcompterPortLibreP2P_call_counter.measure();
    long startTime = System.currentTimeMillis();
    try
    {
      return resConnector.ressourcePortP2PcompterPortLibreP2P(tracabilite_p, nomNR_p);
    }
    finally
    {
      long endTime = System.currentTimeMillis();
      _avg_ressourcePortP2PcompterPortLibreP2P_ExecTime.updateAvgValue(endTime - startTime);
    }
  }
}
