/*******************************************************************************
* $Id: RES2101_RechercherCommunesParInsee.java 247 2017-07-18 13:57:48Z pcarreir $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.res.activities;

import java.text.MessageFormat;
import java.util.List;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.log.event.SystemLogEvent;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.IActivityCaller;
import com.bytel.ravel.services.process.activity.BuiltActivityContext;
import com.bytel.spirit.common.connectors.res.Messages;
import com.bytel.spirit.common.connectors.res.RESProxy;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.Commune;
import com.bytel.spirit.common.shared.saab.res.response.ListeCommuneResponse;

/**
 *
 * @author pcarreir
 * @version ($Revision: 247 $ $Date: 2017-07-18 15:57:48 +0200 (mar., 18 juil. 2017) $)
 */
public class RES2101_RechercherCommunesParInsee extends BuiltActivityContext<List<Commune>>
{

  /**
   *
   * @author pcarreir
   * @version ($Revision: 247 $ $Date: 2017-07-18 15:57:48 +0200 (mar., 18 juil. 2017) $)
   */
  public final static class RES2101_RechercherCommunesParInseeBuilder
  {
    /**
     * object to build
     */
    RES2101_RechercherCommunesParInsee _toBuild;

    /**
     * The constructor
     */
    public RES2101_RechercherCommunesParInseeBuilder()
    {
      _toBuild = new RES2101_RechercherCommunesParInsee();
    }

    /**
     * @return RR0020_BL001_RechercherCommunesParInsee
     */
    public RES2101_RechercherCommunesParInsee build()
    {
      if ((_toBuild.getTypeCodeInsee() == null) || (_toBuild.getTracabilite() == null) || (_toBuild.getCodeInsee() == null))
      {
        // PARAMETRE INVALIDE
        Retour retour = new Retour();
        retour.setResultat(StringConstants.NOK);
        retour.setCategorie(IMegConsts.CAT3);
        retour.setDiagnostic(IMegSpiritConsts.DONNEE_INVALIDE);
        retour.setLibelle("Parametre d'entree de l'activite non renseignee"); //$NON-NLS-1$
        _toBuild.setRetour(retour);
      }
      return _toBuild;
    }

    /**
     * @param codeInsee_p
     *          The code insee
     * @return RR0020_BL001_RechercherCommunesParInseeBuilder
     */
    public RES2101_RechercherCommunesParInseeBuilder codeInsee(String codeInsee_p)
    {
      _toBuild.setCodeInsee(codeInsee_p);
      return this;
    }

    /**
     * @param tracabilite_p
     *          The tracability
     * @return RR0020_BL001_RechercherCommunesParInseeBuilder
     */
    public RES2101_RechercherCommunesParInseeBuilder tracabilite(Tracabilite tracabilite_p)
    {
      _toBuild.setTracabilite(tracabilite_p);
      return this;
    }

    /**
     * @param typeCodeInsee_p
     *          The code insee type
     * @return RR0020_BL001_RechercherCommunesParInseeBuilder
     */
    public RES2101_RechercherCommunesParInseeBuilder typeCodeInsee(String typeCodeInsee_p)
    {
      _toBuild.setTypeCodeInsee(typeCodeInsee_p);
      return this;
    }
  }

  /**
   *
   * @author pcarreir
   * @version ($Revision: 247 $ $Date: 2017-07-18 15:57:48 +0200 (mar., 18 juil. 2017) $)
   */
  private enum Step
  {
    /**
     * First step to execute
     */
    First,

    /**
     * If all steps have been executed
     */
    End
  }

  /**
   *
   */
  private static final String CODE_INSEE = "CodeInsee"; //$NON-NLS-1$

  /**
   *
   */
  private static final String TYPE_CODE_INSEE = "TypeCodeInsee"; //$NON-NLS-1$

  /**
   *
   */
  private static final String RETOUR2 = "Retour"; //$NON-NLS-1$

  /**
   * The serial version UID
   */
  private static final long serialVersionUID = -7110358168081928179L;

  /**
   * The PRECEDENT insee type constant
   */
  private final static String PRECEDENT = "PRECEDENT"; //$NON-NLS-1$

  /**
   * The COURANT insee type constant
   */
  private final static String COURANT = "COURANT"; //$NON-NLS-1$

  /**
   * the code insee
   */
  private String _codeInsee;

  /**
   * the code type
   */
  private String _typeCodeInsee;

  /**
   * The current execution step
   */
  private Step _currentStep = Step.First;

  /**
   * The tracability
   */
  private Tracabilite _tracabilite = null;

  @Override
  public List<Commune> executeNextStep(IActivityCaller arg0) throws RavelException
  {
    List<Commune> result = null;
    // Always use a switch/case to define and to chain all steps to execute!
    // Chaining two steps is done by updating the _nextStep variable.
    switch (_currentStep)
    {
      case First:

        result = rechercherCommunesParInsee();

        _currentStep = Step.End;
        break;
      default:
        break;
    }
    return result;
  }

  @Override
  public boolean isEndStep()
  {
    return Step.End.equals(_currentStep);
  }

  /**
   * @return String
   */
  protected String getCodeInsee()
  {
    return _codeInsee;
  }

  /**
   * @return Tracability
   */
  protected Tracabilite getTracabilite()
  {
    return _tracabilite;
  }

  /**
   * @return String
   */
  protected String getTypeCodeInsee()
  {
    return _typeCodeInsee;
  }

  /**
   * @param codeInsee_p
   *          The code insee
   */
  protected void setCodeInsee(String codeInsee_p)
  {
    _codeInsee = codeInsee_p;
  }

  /**
   * @param tracabilite_p
   *          The tracability
   */
  protected void setTracabilite(Tracabilite tracabilite_p)
  {
    _tracabilite = tracabilite_p;
  }

  /**
   * @param typeCodeInsee_p
   *          The code insee type
   */
  protected void setTypeCodeInsee(String typeCodeInsee_p)
  {
    _typeCodeInsee = typeCodeInsee_p;
  }

  /**
   *
   * @return List<Commune>
   * @throws RavelException
   *           RavelException
   */
  private List<Commune> rechercherCommunesParInsee() throws RavelException
  {
    List<Commune> result = null;
    Retour retour;
    SystemLogEvent system = new SystemLogEvent(LogSeverity.DEBUG, _tracabilite.getIdCorrelationSpirit(), Messages.getString("res.RES2101_RechercherCommunesParInsee")); //$NON-NLS-1$
    system.addField(TYPE_CODE_INSEE, _typeCodeInsee, false);
    system.addField(CODE_INSEE, _codeInsee, false);
    RavelLogger.log(system);
    if (PRECEDENT.equals(_typeCodeInsee))
    {

      ConnectorResponse<Retour, ListeCommuneResponse> response = RESProxy.getInstance().pad3001CommuneReadAncienCodeInsee(_tracabilite, _codeInsee);
      retour = response._first;
      if (RetourFactory.isRetourOK(retour))
      {
        result = response._second.getListeCommune();
      }
    }
    else if (COURANT.equals(_typeCodeInsee))
    {

      ConnectorResponse<Retour, ListeCommuneResponse> response = RESProxy.getInstance().pad3001CommuneReadCodeInsee(_tracabilite, _codeInsee);
      retour = response._first;
      if (RetourFactory.isRetourOK(retour))
      {
        result = response._second.getListeCommune();
      }
    }
    else
    {
      retour = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ENTREE_INCORRECTE, MessageFormat.format(Messages.getString("res.typeCodeInseeInconnu"), _typeCodeInsee)); //$NON-NLS-1$
    }

    if (!RetourFactory.isRetourOK(retour) && IMegConsts.CAT4.equals(retour.getCategorie()) && IMegSpiritConsts.CODE_INSEE_INCONNU.equals(retour.getDiagnostic()))
    {
      retour.setDiagnostic(IMegSpiritConsts.CODE_INSEE_INCONNU);
      retour.setLibelle(MessageFormat.format(Messages.getString("res.codeInseeInconnu"), _codeInsee)); //$NON-NLS-1$
    }
    system = new SystemLogEvent(LogSeverity.DEBUG, _tracabilite.getIdCorrelationSpirit(), Messages.getString("res.RES2101_RechercherCommunesParInsee")); //$NON-NLS-1$
    system.addField(RETOUR2, retour, false);
    RavelLogger.log(system);
    this.setRetour(retour);
    return result;
  }

}
