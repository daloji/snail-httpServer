/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.res.services;

import java.util.HashMap;

import javax.ws.rs.HttpMethod;
import javax.ws.rs.core.Response;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.connector.RESTRequest;
import com.bytel.ravel.services.connector.RESTRequest.RESTRequestBuilder;
import com.bytel.spirit.common.connectors.res.IRESConnector;
import com.bytel.spirit.common.connectors.res.RESConnector;
import com.bytel.spirit.common.shared.misc.connectors.AbstractInternalRESTConnector;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.RetourConverter;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.RessourcePortPM;
import com.bytel.spirit.common.shared.saab.res.response.ManageRessourcePortPM;

/**
 *
 * @author jrolao
 * @version ($Revision$ $Date$)
 */
public class RessourcePortPmService
{
  public interface IAction
  {
    String GERER_ALLOCATION = "GererAllocation"; //$NON-NLS-1$
    String GERER_MIGRATION_PORT_PM = "GererMigrationPortPM"; //$NON-NLS-1$
  }

  public interface IMethodName
  {
    String RESSOURCE_PORT_PM_GERER_ALLOCATION = "ressourcePortPmGererAllocation"; //$NON-NLS-1$
    String RESSOURCE_PORT_PM_GERER_MIGRATION_PORT_PM = "ressourcePortPmGererMigrationPortPm"; //$NON-NLS-1$
  }

  public interface IParameter
  {
    String REFERENCE_PM_BYTEL = "referencePmBytel"; //$NON-NLS-1$
    String REFERENCE_PM_OI = "referencePmOi"; //$NON-NLS-1$
    String REFERENCE_BOITIER_PM = "referenceBoitierPm"; //$NON-NLS-1$
    String NOM_PM_TECHNIQUE = "nomPmTechnique"; //$NON-NLS-1$
    String NOM_PANNEAU_PM = "nomPanneauPm"; //$NON-NLS-1$
    String POSITION_PORT_PM = "positionPortPm"; //$NON-NLS-1$
    String ID_RESSOURCE_LIE = "idRessourceLie"; //$NON-NLS-1$
    String TECHNOLOGIE_PON = "technologiePON"; //$NON-NLS-1$
    String MOTIF_MIGRATION = "motifMigration"; //$NON-NLS-1$
    String ID_RESSOURCE = "idRessource"; //$NON-NLS-1$
  }

  /** The connector instance */
  private final RESConnector _resInstance;

  /**
   * Default constructor
   *
   * @param resInstance_p
   *          Current RESConnector instance
   */
  public RessourcePortPmService(RESConnector resInstance_p)
  {
    _resInstance = resInstance_p;
  }

  public ConnectorResponse<Retour, RessourcePortPM> ressourcePortPmGererAllocation(Tracabilite tracabilite_p, String ressourcePortPmURL_p, String referencePmBytel_p, String referencePmOi_p, String referenceBoitierPm_p, String nomPmTechnique_p, String nomPanneauPm_p, Integer positionPortPm_p, String technologiePON_p, String idRessourceLie_p)
  {
    try
    {
      // Query parameters
      HashMap<String, String> queryParams = new HashMap<>();
      queryParams.put(IRESConnector.PARAM_ACTION, IAction.GERER_ALLOCATION);

      if (StringTools.isNotNullOrEmpty(idRessourceLie_p) && StringTools.isNotNullOrEmpty(technologiePON_p))
      {
        queryParams.put(IParameter.REFERENCE_PM_BYTEL, referencePmBytel_p);
        queryParams.put(IParameter.REFERENCE_PM_OI, referencePmOi_p);
        queryParams.put(IParameter.REFERENCE_BOITIER_PM, referenceBoitierPm_p);
        queryParams.put(IParameter.NOM_PM_TECHNIQUE, nomPmTechnique_p);
        queryParams.put(IParameter.NOM_PANNEAU_PM, nomPanneauPm_p);
        if (positionPortPm_p != null)
        {
          queryParams.put(IParameter.POSITION_PORT_PM, String.valueOf(positionPortPm_p));
        }
        queryParams.put(IParameter.TECHNOLOGIE_PON, technologiePON_p);
        queryParams.put(IParameter.ID_RESSOURCE_LIE, idRessourceLie_p);
      }

      // Call SAAB
      final Response response;
      try
      {
        RESTRequest restRequest = new RESTRequestBuilder()//
            .httpMethod(HttpMethod.PUT)//
            .traceability(tracabilite_p)//
            .method(IMethodName.RESSOURCE_PORT_PM_GERER_ALLOCATION)//
            .headers(AbstractInternalRESTConnector.getSpiritStarkRequestHeader())//
            .path(ressourcePortPmURL_p)//
            .queryParameter(queryParams)//
            .build();
        response = _resInstance.sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }
      // Get the content to a JSON string
      ManageRessourcePortPM responseFromConector = _resInstance.getContentFromResponse(tracabilite_p, response, IMethodName.RESSOURCE_PORT_PM_GERER_ALLOCATION, ManageRessourcePortPM.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(responseFromConector.getRetour());
      return new ConnectorResponse<>(retour, responseFromConector.getRessourcePortPM());
    }
    catch (Exception e_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  public ConnectorResponse<Retour, RessourcePortPM> ressourcePortPmGererMigrationPortPm(Tracabilite tracabilite_p, String ressourcePortPmURL_p, String idRessource_p, String motifMigration_p, String referencePmBytel_p, String referencePmOi_p, String referenceBoitierPm_p, String nomPmTechnique_p, String nomPanneauPm_p, Integer positionPortPm_p, String technologiePON_p, String idRessourceLie_p)
  {
    try
    {
      // Query parameters
      HashMap<String, String> queryParams = new HashMap<>();
      queryParams.put(IRESConnector.PARAM_ACTION, IAction.GERER_MIGRATION_PORT_PM);

      if (StringTools.isNotNullOrEmpty(idRessource_p) && StringTools.isNotNullOrEmpty(idRessourceLie_p))
      {
        queryParams.put(IParameter.ID_RESSOURCE, idRessource_p);
        queryParams.put(IParameter.MOTIF_MIGRATION, motifMigration_p);
        queryParams.put(IParameter.REFERENCE_PM_BYTEL, referencePmBytel_p);
        queryParams.put(IParameter.REFERENCE_PM_OI, referencePmOi_p);
        queryParams.put(IParameter.REFERENCE_BOITIER_PM, referenceBoitierPm_p);
        queryParams.put(IParameter.NOM_PM_TECHNIQUE, nomPmTechnique_p);
        queryParams.put(IParameter.NOM_PANNEAU_PM, nomPanneauPm_p);
        if (positionPortPm_p != null)
        {
          queryParams.put(IParameter.POSITION_PORT_PM, String.valueOf(positionPortPm_p));
        }
        if (StringTools.isNotNullOrEmpty(technologiePON_p))
        {
          queryParams.put(IParameter.TECHNOLOGIE_PON, technologiePON_p);
        }
        queryParams.put(IParameter.ID_RESSOURCE_LIE, idRessourceLie_p);
      }

      // Call SAAB
      final Response response;
      try
      {
        RESTRequest restRequest = new RESTRequestBuilder()//
            .httpMethod(HttpMethod.PUT)//
            .traceability(tracabilite_p)//
            .method(IMethodName.RESSOURCE_PORT_PM_GERER_MIGRATION_PORT_PM)//
            .headers(AbstractInternalRESTConnector.getSpiritStarkRequestHeader())//
            .path(ressourcePortPmURL_p)//
            .queryParameter(queryParams)//
            .build();
        response = _resInstance.sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content to a JSON string
      ManageRessourcePortPM responseFromConector = _resInstance.getContentFromResponse(tracabilite_p, response, IMethodName.RESSOURCE_PORT_PM_GERER_MIGRATION_PORT_PM, ManageRessourcePortPM.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(responseFromConector.getRetour());
      return new ConnectorResponse<>(retour, responseFromConector.getRessourcePortPM());
    }
    catch (Exception e_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }

  }

}
