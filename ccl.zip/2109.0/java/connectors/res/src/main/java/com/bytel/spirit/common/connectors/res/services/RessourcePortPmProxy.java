/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.res.services;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.probes.AvgDoubleCollectorItem;
import com.bytel.ravel.common.probes.AvgFlowPerSecondCollector;
import com.bytel.ravel.common.probes.RavelProbeConfigurationManager;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.services.connector.ConnectorManager;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.connectors.res.IRESConnector;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.RessourcePortPM;

/**
 *
 * @author jrolao
 * @version ($Revision$ $Date$)
 */
public class RessourcePortPmProxy
{

  /** connector Id */
  private String _connectorId;

  /** For probe to count the amount of call to the ressourcePortPmGererAllocation operation */
  AvgFlowPerSecondCollector _avg_ressourcePortPmGererAllocation_call_counter;
  /** For probe to count the execution time of call to the ressourcePortPmGererAllocation operation */
  AvgDoubleCollectorItem _avg_ressourcePortPmGererAllocation_ExecTime;

  /** For probe to count the amount of call to the ressourcePortPmGererMigrationPortPm operation */
  AvgFlowPerSecondCollector _avg_ressourcePortPmGererMigrationPortPm_call_counter;
  /** For probe to count the execution time of call to the ressourcePortPmGererMigrationPortPm operation */
  AvgDoubleCollectorItem _avg_ressourcePortPmGererMigrationPortPm_ExecTime;

  /**
   *
   * @param connectorId_p
   */
  public RessourcePortPmProxy(String connectorId_p)
  {
    _connectorId = connectorId_p;

    _avg_ressourcePortPmGererAllocation_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_ressourcePortPmGererAllocation_call_counter", "RESProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_ressourcePortPmGererAllocation_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_ressourcePortPmGererAllocation_ExecTime", "RESProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_ressourcePortPmGererMigrationPortPm_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_ressourcePortPmGererMigrationPortPm_call_counter", "RESProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_ressourcePortPmGererMigrationPortPm_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_ressourcePortPmGererMigrationPortPm_ExecTime", "RESProxy"); //$NON-NLS-1$ //$NON-NLS-2$
  }

  public ConnectorResponse<Retour, RessourcePortPM> ressourcePortPmGererAllocation(Tracabilite tracabilite_p, String referencePmBytel_p, String referencePmOi_p, String referenceBoitierPm_p, String nomPmTechnique_p, String nomPanneauPm_p, Integer positionPortPm_p, String technologiePON_p, String idRessourceLie_p) throws RavelException
  {
    IRESConnector resConnector = null;
    try
    {
      resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
    }
    catch (Exception e_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
    }
    _avg_ressourcePortPmGererAllocation_call_counter.measure();
    long startTime = System.currentTimeMillis();
    try
    {
      return resConnector.ressourcePortPmGererAllocation(tracabilite_p, referencePmBytel_p, referencePmOi_p, referenceBoitierPm_p, nomPmTechnique_p, nomPanneauPm_p, positionPortPm_p, technologiePON_p, idRessourceLie_p);
    }
    finally
    {
      long endTime = System.currentTimeMillis();
      _avg_ressourcePortPmGererAllocation_ExecTime.updateAvgValue(endTime - startTime);
    }
  }

  public ConnectorResponse<Retour, RessourcePortPM> ressourcePortPmGererMigrationPortPm(Tracabilite tracabilite_p, String idRessource_p, String motifMigration_p, String referencePmBytel_p, String referencePmOi_p, String referenceBoitierPm_p, String nomPmTechnique_p, String nomPanneauPm_p, Integer positionPortPm_p, String technologiePON_p, String idRessourceLie_p) throws RavelException
  {
    IRESConnector resConnector = null;
    try
    {
      resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
    }
    catch (Exception e_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
    }
    _avg_ressourcePortPmGererMigrationPortPm_call_counter.measure();
    long startTime = System.currentTimeMillis();
    try
    {
      return resConnector.ressourcePortPmGererMigrationPortPm(tracabilite_p, idRessource_p, motifMigration_p, referencePmBytel_p, referencePmOi_p, referenceBoitierPm_p, nomPmTechnique_p, nomPanneauPm_p, positionPortPm_p, technologiePON_p, idRessourceLie_p);
    }
    finally
    {
      long endTime = System.currentTimeMillis();
      _avg_ressourcePortPmGererMigrationPortPm_ExecTime.updateAvgValue(endTime - startTime);
    }
  }
}
