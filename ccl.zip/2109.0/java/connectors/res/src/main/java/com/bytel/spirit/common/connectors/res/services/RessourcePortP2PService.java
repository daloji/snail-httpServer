/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.res.services;

import static com.bytel.spirit.common.connectors.res.IRESConnector.MESSAGE_MISSING_CONFIGURATION_PARAMETER;

import java.text.MessageFormat;
import java.util.HashMap;

import javax.ws.rs.HttpMethod;
import javax.ws.rs.core.Response;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.connector.RESTRequest;
import com.bytel.spirit.common.connectors.res.Messages;
import com.bytel.spirit.common.connectors.res.RESConnector;
import com.bytel.spirit.common.shared.misc.connectors.AbstractInternalRESTConnector;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.BasicResponse;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.ressources.RetourConverter;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.response.GetRessourcePortP2PResponse;

/**
 * @author ppinto
 * @version ($Revision$ $Date$)
 */
public class RessourcePortP2PService
{
  public interface IMethodName
  {
    /** The constant for pad3124RessourcePortP2PGererAllocation service name */
    String METHOD_NAME_RESSOURCE_PORTP2P_GERER_ALLOCATION = "ressourcePortP2PGererAllocation"; //$NON-NLS-1$
    /** The constant for ressourcePortP2PModifierStatutAllocation service name */
    String METHOD_NAME_RESSOURCE_PORTP2P_MODIFIER_STATUT_ALLOCATION = "ressourcePortP2PModifierStatutAllocation"; //$NON-NLS-1$
    /** The constant for ressourcePortP2PCompterPortLibre service name */
    String METHOD_NAME_RESSOURCE_PORTP2P_COMPTER_PORT_LIBRE = "ressourcePortP2PCompterPortLibre"; //$NON-NLS-1$
  }

  public interface IParameter
  {
    /** Parameter idRessource */
    String PARAM_ID_RESSOURCE = "idRessource"; //$NON-NLS-1$
    /** Parameter nomNR */
    String PARAM_NOMNR = "nomNR"; //$NON-NLS-1$
    /** Parameter distance */
    String PARAM_DISTANCE = "distance"; //$NON-NLS-1$
    /** Parameter Action */
    String PARAM_ACTION = "action"; //$NON-NLS-1$
    /** Parameter idRessourceLie */
    String PARAM_ID_RESSOURCE_LIE = "idRessourceLie"; //$NON-NLS-1$
    /** Parameter RESSOURCE_PORT_P2P_PATH */
    String RESSOURCE_PORT_P2P_PATH = "RESSOURCE_PORT_P2P_PATH"; //$NON-NLS-1$
    /** The constant for message Impossible de récupérer la réponse constant */
    String MESSAGE_JSON_ERROR_MESSAGE = Messages.getString("RESConnector.JsonErrorMessage"); //$NON-NLS-1$
    /** Parameter statut */
    String PARAM_STATUT = "statut"; //$NON-NLS-1$
  }

  /** The connector instance */
  private final RESConnector _resInstance;

  /**
   * Default constructor
   *
   * @param resInstance_p
   *          Current RESConnector instance
   */
  public RessourcePortP2PService(RESConnector resInstance_p)
  {
    _resInstance = resInstance_p;
  }

  public ConnectorResponse<Retour, Integer> ressourcePortP2PcompterPortLibreP2P(Tracabilite tracabilite_p, String nomNR_p, String ressourcePortP2PUrl_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(ressourcePortP2PUrl_p))
      {
        throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, IParameter.RESSOURCE_PORT_P2P_PATH));
      }

      // Query parameters
      HashMap<String, String> queryParams = new HashMap<>();
      queryParams.put(IParameter.PARAM_ACTION, "CompterPortLibreP2P"); //$NON-NLS-1$

      if (StringTools.isNotNullOrEmpty(nomNR_p))
      {
        queryParams.put(IParameter.PARAM_NOMNR, nomNR_p);
      }

      // Call SAAB
      final Response response;
      try
      {
        RESTRequest restRequest = new RESTRequest.RESTRequestBuilder()//
            .httpMethod(HttpMethod.GET)//
            .traceability(tracabilite_p)//
            .method(IMethodName.METHOD_NAME_RESSOURCE_PORTP2P_COMPTER_PORT_LIBRE)//
            .headers(AbstractInternalRESTConnector.getSpiritStarkRequestHeader())//
            .path(ressourcePortP2PUrl_p)//
            .queryParameter(queryParams)//
            .build();
        response = _resInstance.sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content to a JSON string
      GetRessourcePortP2PResponse responseFromConector = _resInstance.getContentFromResponse(tracabilite_p, response, IMethodName.METHOD_NAME_RESSOURCE_PORTP2P_COMPTER_PORT_LIBRE, GetRessourcePortP2PResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(responseFromConector.getRetour());
      return new ConnectorResponse<>(retour, responseFromConector.getCompteurPortP2PLibre());
    }
    catch (Exception e_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  public ConnectorResponse<Retour, Nothing> ressourcePortP2PGererAllocation(Tracabilite tracabilite_p, String nomNR_p, String distance_p, String idRessourceLie_p, String action_p, String ressourcePortP2PUrl_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(ressourcePortP2PUrl_p))
      {
        throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, IParameter.RESSOURCE_PORT_P2P_PATH));
      }

      // Query parameters
      HashMap<String, String> queryParams = new HashMap<>();
      if (StringTools.isNotNullOrEmpty(nomNR_p) && StringTools.isNotNullOrEmpty(distance_p) && StringTools.isNotNullOrEmpty(idRessourceLie_p) && StringTools.isNotNullOrEmpty(action_p))
      {
        queryParams.put(IParameter.PARAM_NOMNR, nomNR_p);
        queryParams.put(IParameter.PARAM_DISTANCE, distance_p);
        queryParams.put(IParameter.PARAM_ID_RESSOURCE_LIE, idRessourceLie_p);
        queryParams.put(IParameter.PARAM_ACTION, action_p);
      }

      // Call SAAB
      final Response response;
      try
      {
        RESTRequest restRequest = new RESTRequest.RESTRequestBuilder()//
            .httpMethod(HttpMethod.PUT)//
            .traceability(tracabilite_p)//
            .method(IMethodName.METHOD_NAME_RESSOURCE_PORTP2P_GERER_ALLOCATION)//
            .headers(AbstractInternalRESTConnector.getSpiritStarkRequestHeader())//
            .path(ressourcePortP2PUrl_p)//
            .queryParameter(queryParams)//
            .build();
        response = _resInstance.sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }
      // Get the content to a JSON string
      BasicResponse basicResponse = _resInstance.getContentFromResponse(tracabilite_p, response, IMethodName.METHOD_NAME_RESSOURCE_PORTP2P_GERER_ALLOCATION, BasicResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(basicResponse.getRetour());
      return new ConnectorResponse<>(retour, null);
    }
    catch (Exception e_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  public ConnectorResponse<Retour, Nothing> ressourcePortP2PModifierStatutAllocation(Tracabilite tracabilite_p, String idRessource_p, String idRessourceLie_p, String statut_p, String ressourcePortP2PUrl_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(ressourcePortP2PUrl_p))
      {
        throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, IParameter.RESSOURCE_PORT_P2P_PATH));
      }
      // Query parameters
      HashMap<String, String> queryParams = new HashMap<>();
      if (StringTools.isNotNullOrEmpty(idRessource_p) && StringTools.isNotNullOrEmpty(idRessourceLie_p) && StringTools.isNotNullOrEmpty(statut_p))
      {
        queryParams.put(IParameter.PARAM_ID_RESSOURCE, idRessource_p);
        queryParams.put(IParameter.PARAM_ID_RESSOURCE_LIE, idRessourceLie_p);
        queryParams.put(IParameter.PARAM_STATUT, statut_p);
      }

      // Call SAAB
      final Response response;
      try
      {
        RESTRequest restRequest = new RESTRequest.RESTRequestBuilder()//
            .httpMethod(HttpMethod.PUT)//
            .traceability(tracabilite_p)//
            .method(IMethodName.METHOD_NAME_RESSOURCE_PORTP2P_MODIFIER_STATUT_ALLOCATION)//
            .headers(AbstractInternalRESTConnector.getSpiritStarkRequestHeader())//
            .path(ressourcePortP2PUrl_p)//
            .queryParameter(queryParams)//
            .build();
        response = _resInstance.sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content to a JSON string
      BasicResponse basicResponse = _resInstance.getContentFromResponse(tracabilite_p, response, IMethodName.METHOD_NAME_RESSOURCE_PORTP2P_MODIFIER_STATUT_ALLOCATION, BasicResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(basicResponse.getRetour());
      return new ConnectorResponse<>(retour, null);
    }
    catch (Exception e_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }
}
