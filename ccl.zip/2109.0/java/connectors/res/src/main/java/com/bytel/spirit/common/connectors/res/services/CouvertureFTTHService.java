/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.res.services;

import java.text.MessageFormat;
import java.util.HashMap;
import java.util.List;

import javax.ws.rs.HttpMethod;
import javax.ws.rs.core.Response;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.connector.RESTRequest;
import com.bytel.spirit.common.connectors.res.IRESConnector;
import com.bytel.spirit.common.connectors.res.RESConnector;
import com.bytel.spirit.common.shared.misc.connectors.AbstractInternalRESTConnector;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.RetourConverter;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.CouvertureFtth;
import com.bytel.spirit.common.shared.saab.res.response.GetCouvertureFtthResponse;

/**
 * @author jpais
 * @version ($Revision$ $Date$)
 */
public class CouvertureFTTHService
{
  /** The constant for couvertureFtthLireTousParHexacleInterne service name */
  public static final String METHOD_NAME_COUVERTURE_FTTH_LIRE_TOUS_HEXACLE_INTERNE = "couvertureFtthLireTousParHexacleInterne"; //$NON-NLS-1$
  /** The constant for couvertureFtthLireTousParIdAdresseBytel service name */
  public static final String METHOD_NAME_COUVERTURE_FTTH_LIRE_TOUS_ID_ADRESSE_BYTEL = "couvertureFtthLireTousParIdAdresseBytel"; //$NON-NLS-1$
  /** The constant for couvertureFtthLireTousParIMB service name */
  public static final String METHOD_NAME_COUVERTURE_FTTH_LIRE_TOUS_IMB = "couvertureFtthLireTousParIMB"; //$NON-NLS-1$

  private final RESConnector _resInstance;

  /**
   * Default constructor
   *
   * @param resInstance_p
   *          Current RESConnector instance
   */
  public CouvertureFTTHService(RESConnector resInstance_p)
  {
    _resInstance = resInstance_p;
  }

  public ConnectorResponse<Retour, List<CouvertureFtth>> couvertureFtthLireTousParHexacleInterne(Tracabilite tracabilite_p, String couvertureFtthUr_p, String hexacleInterne_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(couvertureFtthUr_p))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(IRESConnector.MESSAGE_MISSING_CONFIGURATION_PARAMETER, IRESConnector.PAD3010_PATH_PARAM));
      }

      // Call SAAB
      final Response response;
      HashMap<String, String> queryParams = new HashMap<>();
      queryParams.put(IRESConnector.PARAM_HEXACLE_INTERNE, hexacleInterne_p);

      try
      {
        RESTRequest restRequest = new RESTRequest.RESTRequestBuilder()//
            .httpMethod(HttpMethod.GET)//
            .traceability(tracabilite_p)//
            .method(METHOD_NAME_COUVERTURE_FTTH_LIRE_TOUS_HEXACLE_INTERNE)//
            .headers(AbstractInternalRESTConnector.getSpiritStarkRequestHeader())//
            .path(couvertureFtthUr_p)//
            .queryParameter(queryParams)//
            .build();
        response = _resInstance.sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content
      GetCouvertureFtthResponse getCouvertureFtthResponse = _resInstance.getContentFromResponse(tracabilite_p, response, METHOD_NAME_COUVERTURE_FTTH_LIRE_TOUS_HEXACLE_INTERNE, GetCouvertureFtthResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(getCouvertureFtthResponse.getRetour());
      List<CouvertureFtth> listeCouvertureFtth = getCouvertureFtthResponse.getListeCouvertureFtth();

      return new ConnectorResponse<>(retour, listeCouvertureFtth);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  public ConnectorResponse<Retour, List<CouvertureFtth>> couvertureFtthLireTousParIdAdresseBytel(Tracabilite tracabilite_p, String couvertureFtthUr_p, String idAdresseBytel_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(couvertureFtthUr_p))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(IRESConnector.MESSAGE_MISSING_CONFIGURATION_PARAMETER, IRESConnector.PAD3010_PATH_PARAM));
      }

      // Call SAAB
      final Response response;
      HashMap<String, String> queryParams = new HashMap<>();
      queryParams.put(IRESConnector.PARAM_ID_ADRESSE_BYTEL, idAdresseBytel_p);

      try
      {
        RESTRequest restRequest = new RESTRequest.RESTRequestBuilder()//
            .httpMethod(HttpMethod.GET)//
            .traceability(tracabilite_p)//
            .method(METHOD_NAME_COUVERTURE_FTTH_LIRE_TOUS_ID_ADRESSE_BYTEL)//
            .headers(AbstractInternalRESTConnector.getSpiritStarkRequestHeader())//
            .path(couvertureFtthUr_p)//
            .queryParameter(queryParams)//
            .build();
        response = _resInstance.sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content
      GetCouvertureFtthResponse getCouvertureFtthResponse = _resInstance.getContentFromResponse(tracabilite_p, response, METHOD_NAME_COUVERTURE_FTTH_LIRE_TOUS_ID_ADRESSE_BYTEL, GetCouvertureFtthResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(getCouvertureFtthResponse.getRetour());
      List<CouvertureFtth> listeCouvertureFtth = getCouvertureFtthResponse.getListeCouvertureFtth();

      return new ConnectorResponse<>(retour, listeCouvertureFtth);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  public ConnectorResponse<Retour, List<CouvertureFtth>> couvertureFtthLireTousParIMB(Tracabilite tracabilite_p, String couvertureFtthUr_p, String imb_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(couvertureFtthUr_p))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(IRESConnector.MESSAGE_MISSING_CONFIGURATION_PARAMETER, IRESConnector.PAD3010_PATH_PARAM));
      }

      // Call SAAB
      final Response response;
      HashMap<String, String> queryParams = new HashMap<>();
      queryParams.put(IRESConnector.PARAM_IMB, imb_p);

      try
      {
        RESTRequest restRequest = new RESTRequest.RESTRequestBuilder()//
            .httpMethod(HttpMethod.GET)//
            .traceability(tracabilite_p)//
            .method(METHOD_NAME_COUVERTURE_FTTH_LIRE_TOUS_IMB)//
            .headers(AbstractInternalRESTConnector.getSpiritStarkRequestHeader())//
            .path(couvertureFtthUr_p)//
            .queryParameter(queryParams)//
            .build();
        response = _resInstance.sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content
      GetCouvertureFtthResponse getCouvertureFtthResponse = _resInstance.getContentFromResponse(tracabilite_p, response, METHOD_NAME_COUVERTURE_FTTH_LIRE_TOUS_IMB, GetCouvertureFtthResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(getCouvertureFtthResponse.getRetour());
      List<CouvertureFtth> listeCouvertureFtth = getCouvertureFtthResponse.getListeCouvertureFtth();

      return new ConnectorResponse<>(retour, listeCouvertureFtth);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }
}
