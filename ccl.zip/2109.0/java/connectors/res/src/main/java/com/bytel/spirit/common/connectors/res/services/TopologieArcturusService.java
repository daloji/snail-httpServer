/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.res.services;

import java.text.MessageFormat;
import java.util.HashMap;
import java.util.List;

import javax.ws.rs.HttpMethod;
import javax.ws.rs.core.Response;

import org.springframework.util.CollectionUtils;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.connector.RESTRequest;
import com.bytel.spirit.common.connectors.res.IRESConnector;
import com.bytel.spirit.common.connectors.res.RESConnector;
import com.bytel.spirit.common.shared.misc.connectors.AbstractInternalRESTConnector;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.RetourConverter;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.TopologieArcturus;
import com.bytel.spirit.common.shared.saab.res.response.GetTopologieArcturusResponse;

/**
 * @author pramos
 * @version ($Revision$ $Date$)
 */
public class TopologieArcturusService
{

  private final RESConnector _resInstance;

  public TopologieArcturusService(RESConnector resInstance_p)
  {
    _resInstance = resInstance_p;
  }

  /**
   *
   * @param tracabilite_p
   * @param topologieArcturusUrl_p
   * @param idEqptAcces_p
   * @return
   * @throws RavelException
   */
  public ConnectorResponse<Retour, List<TopologieArcturus>> topologieArcturusLireTousParIdEqptAcces(Tracabilite tracabilite_p, String topologieArcturusUrl_p, String idEqptAcces_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(topologieArcturusUrl_p))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(IRESConnector.MESSAGE_MISSING_CONFIGURATION_PARAMETER, IRESConnector.PAD3013_PATH_PARAM));
      }
      // Call SAAB
      final Response response;
      HashMap<String, String> queryParams = new HashMap<>();
      queryParams.put(IRESConnector.PARAM_ID_EQPT_ACCES, idEqptAcces_p);
      try
      {
        RESTRequest restRequest = new RESTRequest.RESTRequestBuilder()//
            .httpMethod(HttpMethod.GET)//
            .traceability(tracabilite_p)//
            .method(IRESConnector.METHOD_NAME_TOPOLOGIE_ARCTURUS_LIRE_TOUS_PAR_IDEQPTACCES)//
            .headers(AbstractInternalRESTConnector.getSpiritStarkRequestHeader())//
            .path(topologieArcturusUrl_p)//
            .queryParameter(queryParams)//
            .build();
        response = _resInstance.sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }
      // Get the content to a JSON string
      GetTopologieArcturusResponse basicResponse = _resInstance.getContentFromResponse(tracabilite_p, response, IRESConnector.METHOD_NAME_TOPOLOGIE_ARCTURUS_LIRE_TOUS_PAR_IDEQPTACCES, GetTopologieArcturusResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(basicResponse.getRetour());
      List<TopologieArcturus> listeTopologieArcturus = basicResponse.getListeTopologieArcturus();
      return new ConnectorResponse<>(retour, listeTopologieArcturus);
    }
    catch (Exception e_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  /**
   *
   * @param tracabilite_p
   * @param topologieArcturusUrl_p
   * @param idNomCollecte_p
   * @return
   * @throws RavelException
   */
  public ConnectorResponse<Retour, TopologieArcturus> topologieArcturusLireUn(Tracabilite tracabilite_p, String topologieArcturusUrl_p, String idNomCollecte_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(topologieArcturusUrl_p))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(IRESConnector.MESSAGE_MISSING_CONFIGURATION_PARAMETER, IRESConnector.PAD3013_PATH_PARAM));
      }
      // Call SAAB
      final Response response;
      HashMap<String, String> queryParams = new HashMap<>();
      queryParams.put(IRESConnector.PARAM_ID_NOM_COLLECTE, idNomCollecte_p);
      try
      {
        RESTRequest restRequest = new RESTRequest.RESTRequestBuilder()//
            .httpMethod(HttpMethod.GET)//
            .traceability(tracabilite_p)//
            .method(IRESConnector.METHOD_NAME_TOPOLOGIE_ARCTURUS_LIRE_UN)//
            .headers(AbstractInternalRESTConnector.getSpiritStarkRequestHeader())//
            .path(topologieArcturusUrl_p)//
            .queryParameter(queryParams)//
            .build();
        response = _resInstance.sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      GetTopologieArcturusResponse basicResponse = _resInstance.getContentFromResponse(tracabilite_p, response, IRESConnector.METHOD_NAME_TOPOLOGIE_ARCTURUS_LIRE_UN, GetTopologieArcturusResponse.class);
      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(basicResponse.getRetour());
      List<TopologieArcturus> listeTopologieArcturus = basicResponse.getListeTopologieArcturus();
      return new ConnectorResponse<>(retour, CollectionUtils.isEmpty(listeTopologieArcturus) ? null : listeTopologieArcturus.get(0));
    }
    catch (Exception e_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }
}
