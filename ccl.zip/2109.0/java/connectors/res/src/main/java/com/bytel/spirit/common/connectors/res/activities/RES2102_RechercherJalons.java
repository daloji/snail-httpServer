/*******************************************************************************
* $Id: RES2102_RechercherJalons.java 249 2017-07-18 14:23:39Z pcarreir $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.res.activities;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.log.event.SystemLogEvent;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.IActivityCaller;
import com.bytel.ravel.services.process.activity.BuiltActivityContext;
import com.bytel.spirit.common.connectors.res.Messages;
import com.bytel.spirit.common.connectors.res.RESProxy;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.Jalon;
import com.bytel.spirit.common.shared.saab.res.Prevision;
import com.bytel.spirit.common.shared.saab.res.response.ListePrevisionResponse;

/**
 *
 * @author pcarreir
 * @version ($Revision: 249 $ $Date: 2017-07-18 16:23:39 +0200 (mar., 18 juil. 2017) $)
 */
public class RES2102_RechercherJalons extends BuiltActivityContext<List<Jalon>>
{

  /**
   *
   * @author pcarreir
   * @version ($Revision: 249 $ $Date: 2017-07-18 16:23:39 +0200 (mar., 18 juil. 2017) $)
   */
  public static class RES2102_RechercherJalonsBuilder
  {
    /**
     * Object to build
     */
    RES2102_RechercherJalons _toBuild = new RES2102_RechercherJalons();

    /**
     * Constructor
     */
    public RES2102_RechercherJalonsBuilder()
    {
      _toBuild = new RES2102_RechercherJalons();
    }

    /**
     * @return RR0020_BL002_RechercherJalons
     */
    public RES2102_RechercherJalons build()
    {
      if ((_toBuild.getNomProgramme() == null) || (_toBuild.getTracabilite() == null) || (_toBuild.getCodeInsee() == null))
      {
        // PARAMETRE INVALIDE
        Retour retour = new Retour();
        retour.setResultat(StringConstants.NOK);
        retour.setCategorie(IMegConsts.CAT3);
        retour.setDiagnostic(IMegSpiritConsts.DONNEE_INVALIDE);
        retour.setLibelle("Parametre d'entree de l'activite non renseignee"); //$NON-NLS-1$
        _toBuild.setRetour(retour);
      }
      return _toBuild;
    }

    /**
     * @param codeInsee_p
     *          The code insee
     * @return RR0020_BL002_RechercherJalonsBuilder
     */
    public RES2102_RechercherJalonsBuilder codeInsee(String codeInsee_p)
    {
      _toBuild.setCodeInsee(codeInsee_p);
      return this;
    }

    /**
     * @param nomProgramme_p
     *          The program name
     * @return RR0020_BL002_RechercherJalonsBuilder
     */
    public RES2102_RechercherJalonsBuilder nomProgramme(String nomProgramme_p)
    {
      _toBuild.setNomProgramme(nomProgramme_p);
      return this;
    }

    /**
     * @param tracabilite_p
     *          The tracability
     * @return RR0020_BL002_RechercherJalonsBuilder
     */
    public RES2102_RechercherJalonsBuilder tracabilite(Tracabilite tracabilite_p)
    {
      _toBuild.setTracabilite(tracabilite_p);
      return this;
    }
  }

  /**
   *
   * @author pcarreir
   * @version ($Revision: 249 $ $Date: 2017-07-18 16:23:39 +0200 (mar., 18 juil. 2017) $)
   */
  private enum Step
  {
    /**
     * First step to execute
     */
    First,

    /**
     * If all steps have been executed
     */
    End
  }

  /**
   *
   */
  private static final String CODE_INSEE = "CodeInsee"; //$NON-NLS-1$

  /**
   *
   */
  private static final String NOM_PROGRAMME = "NomProgramme"; //$NON-NLS-1$

  /**
   *
   */
  private static final String RETOUR = "Retour"; //$NON-NLS-1$

  /**
   * The serial version UID
   */
  private static final long serialVersionUID = 7318577917001181874L;

  /**
   * The program name
   */
  private String _nomProgramme;

  /**
   * The code insee
   */
  private String _codeInsee;

  /**
   * The current execution step
   */
  private Step _currentStep = Step.First;

  /**
   * The tracability
   */
  private Tracabilite _tracabilite = null;

  @Override
  public List<Jalon> executeNextStep(IActivityCaller arg0_p) throws RavelException
  {
    List<Jalon> response = null;
    Retour retour = RetourFactory.createOkRetour();
    SystemLogEvent system = new SystemLogEvent(LogSeverity.DEBUG, _tracabilite.getIdCorrelationSpirit(), Messages.getString("res.RES2102_RechercherJalons")); //$NON-NLS-1$
    system.addField(NOM_PROGRAMME, _nomProgramme, false);
    system.addField(CODE_INSEE, _codeInsee, false);
    RavelLogger.log(system);
    switch (_currentStep)
    {
      case First:

        if (_codeInsee.length() != 5)
        {
          retour = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ENTREE_INCORRECTE, MessageFormat.format(Messages.getString("res.codeInseeInvalide"), _codeInsee)); //$NON-NLS-1$
        }
        else
        {
          response = new ArrayList<Jalon>();
          // TODO add real connector call
          ConnectorResponse<Retour, ListePrevisionResponse> previsionsRes = RESProxy.getInstance().pad3002PrevisionProgRead(_tracabilite, _nomProgramme, _codeInsee);
          if (RetourFactory.isRetourOK(previsionsRes._first))
          {

            for (Prevision prevision : previsionsRes._second.getListePrevision())
            {
              for (Jalon jalon : prevision.getListeJalons())
              {
                response.add(jalon);
              }
            }
          }
          else if (IMegConsts.CAT4.equals(previsionsRes._first.getCategorie()) && (IMegConsts.DONNEE_INCONNUE.equals(previsionsRes._first.getDiagnostic())))
          {
            retour = RetourFactory.createOkRetour();
          }
          else
          {
            retour = previsionsRes._first;
          }
        }

        this.setRetour(retour);
        system = new SystemLogEvent(LogSeverity.DEBUG, _tracabilite.getIdCorrelationSpirit(), Messages.getString("res.RES2102_RechercherJalons")); //$NON-NLS-1$
        system.addField(RETOUR, retour, false);
        RavelLogger.log(system);
        _currentStep = Step.End;
        break;
      default:
        break;
    }
    return response;
  }

  @Override
  public boolean isEndStep()
  {
    return Step.End.equals(_currentStep);
  }

  /**
   * @return String
   */
  protected String getCodeInsee()
  {
    return _codeInsee;
  }

  /**
   * @return String
   */
  protected String getNomProgramme()
  {
    return _nomProgramme;
  }

  /**
   * @return Tracabilite
   */
  protected Tracabilite getTracabilite()
  {
    return _tracabilite;
  }

  /**
   * @param codeInsee_p
   *          The code insee
   */
  protected void setCodeInsee(String codeInsee_p)
  {
    _codeInsee = codeInsee_p;
  }

  /**
   * @param nomProgramme_p
   *          The program name
   */
  protected void setNomProgramme(String nomProgramme_p)
  {
    _nomProgramme = nomProgramme_p;
  }

  /**
   * @param tracabilite_p
   *          The tracability
   */
  protected void setTracabilite(Tracabilite tracabilite_p)
  {
    _tracabilite = tracabilite_p;
  }

}
