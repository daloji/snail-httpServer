/*******************************************************************************
²* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.res;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.services.connector.ConnectorExecution;
import com.bytel.ravel.services.connector.ConnectorManager;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.connectors.res.services.PmCompositeProxy;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.AbaqueDSL;
import com.bytel.spirit.common.shared.saab.res.AccesTechnique;
import com.bytel.spirit.common.shared.saab.res.CacheElig;
import com.bytel.spirit.common.shared.saab.res.CompteRenduSuppression;
import com.bytel.spirit.common.shared.saab.res.Couverture5G;
import com.bytel.spirit.common.shared.saab.res.CouvertureCuivre;
import com.bytel.spirit.common.shared.saab.res.CouvertureFtth;
import com.bytel.spirit.common.shared.saab.res.CouvertureFtto;
import com.bytel.spirit.common.shared.saab.res.CouvertureGeoCodage;
import com.bytel.spirit.common.shared.saab.res.CouvertureTokyo;
import com.bytel.spirit.common.shared.saab.res.DispoNroFtteOrg;
import com.bytel.spirit.common.shared.saab.res.DispoRessourceDSLAxione;
import com.bytel.spirit.common.shared.saab.res.DispoRessourceDSLBouygues;
import com.bytel.spirit.common.shared.saab.res.DispoRessourceDSLOrange;
import com.bytel.spirit.common.shared.saab.res.DispoRessourceDSLSFR;
import com.bytel.spirit.common.shared.saab.res.EntonnoirCommune;
import com.bytel.spirit.common.shared.saab.res.EntonnoirNumero;
import com.bytel.spirit.common.shared.saab.res.EntonnoirVoie;
import com.bytel.spirit.common.shared.saab.res.FichierOrigine;
import com.bytel.spirit.common.shared.saab.res.FichierReferentielComposite;
import com.bytel.spirit.common.shared.saab.res.Fqdn;
import com.bytel.spirit.common.shared.saab.res.ListeTechnologieAutorisee;
import com.bytel.spirit.common.shared.saab.res.Olt;
import com.bytel.spirit.common.shared.saab.res.OltComposite;
import com.bytel.spirit.common.shared.saab.res.PMComposite;
import com.bytel.spirit.common.shared.saab.res.PointAncrageIP;
import com.bytel.spirit.common.shared.saab.res.PoolIP;
import com.bytel.spirit.common.shared.saab.res.PorteDeCollecte;
import com.bytel.spirit.common.shared.saab.res.Ressource;
import com.bytel.spirit.common.shared.saab.res.RessourceAggrege;
import com.bytel.spirit.common.shared.saab.res.RessourceFtth;
import com.bytel.spirit.common.shared.saab.res.RessourcePortPM;
import com.bytel.spirit.common.shared.saab.res.RessourceRaccordementComposite;
import com.bytel.spirit.common.shared.saab.res.StructureVerticaleFtthComposite;
import com.bytel.spirit.common.shared.saab.res.TopologieArcturus;
import com.bytel.spirit.common.shared.saab.res.TypeCouverture5G;
import com.bytel.spirit.common.shared.saab.res.request.IntegrationGroupeFichierRequest;
import com.bytel.spirit.common.shared.saab.res.request.ListeCacheEligRequest;
import com.bytel.spirit.common.shared.saab.res.request.ListeCommuneRequest;
import com.bytel.spirit.common.shared.saab.res.request.ListeCoupleImbOiRequest;
import com.bytel.spirit.common.shared.saab.res.request.ListeNomOLTRequest;
import com.bytel.spirit.common.shared.saab.res.request.ListePrevisionRequest;
import com.bytel.spirit.common.shared.saab.res.request.ManageNoeudRaccordementRequest;
import com.bytel.spirit.common.shared.saab.res.response.GetSurchargeResponse;
import com.bytel.spirit.common.shared.saab.res.response.IntegrationGroupeFichierResponse;
import com.bytel.spirit.common.shared.saab.res.response.ListeCommuneResponse;
import com.bytel.spirit.common.shared.saab.res.response.ListePrevisionResponse;
import com.bytel.spirit.common.shared.types.json.response.PMConsultResponse;

/**
 * @author dangelis
 * @version ($Revision$ $Date$)
 */
public final class RESProxy extends RESProbeProxy implements IRES
{
  /** Proxy instance. */
  private static final RESProxy _instance = new RESProxy(RESProxy.class.getSimpleName());

  /**
   * @return The proxy instance.
   */
  public static RESProxy getInstance()
  {
    return RESProxy._instance;
  }

  /**
   *
   * @param name_p
   */
  private RESProxy(String name_p)
  {
    super(name_p);
  }

  @Override
  public ConnectorResponse<Retour, Map<String, List<AbaqueDSL>>> abaqueDslLireTous(Tracabilite tracabilite_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Map<String, List<AbaqueDSL>>>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Map<String, List<AbaqueDSL>>> run() throws RavelException
      {
        IRESConnector resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_abaqueDslLireTous_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return resConnector.abaqueDslLireTous(tracabilite_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_abaqueDslLireTous_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Map<String, AccesTechnique>> accesTechniqueLireTous(Tracabilite tracabilite_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Map<String, AccesTechnique>>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Map<String, AccesTechnique>> run() throws RavelException
      {
        IRESConnector resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_accesTechniqueLireTous_Read_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return resConnector.accesTechniqueLireTous(tracabilite_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_accesTechniqueLireTous_Read_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, List<AccesTechnique>> accesTechniqueLireTousParLogin(Tracabilite tracabilite_p, String login_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, List<AccesTechnique>>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, List<AccesTechnique>> run() throws RavelException
      {
        IRESConnector resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_accesTechniqueLireTous_Read_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return resConnector.accesTechniqueLireTousParLogin(tracabilite_p, login_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_accesTechniqueLireTous_Read_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Integer> cacheEligCreerListe(Tracabilite tracabilite_p, ListeCacheEligRequest listeCacheEligRequest_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Integer>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Integer> run() throws RavelException
      {
        IRESConnector resConnector;
        try
        {
          resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_cacheEligCreerListe_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return resConnector.cacheEligCreerListe(tracabilite_p, listeCacheEligRequest_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_cacheEligCreerListe_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, CacheElig> cacheEligLire(Tracabilite tracabilite_p, String idCleCompose_p, String typeCle_p, String techno_p, String operateur_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, CacheElig>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, CacheElig> run() throws RavelException
      {
        IRESConnector resConnector;
        try
        {
          resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_cacheEligLire_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return resConnector.cacheEligLire(tracabilite_p, idCleCompose_p, typeCle_p, techno_p, operateur_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_cacheEligLire_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Couverture5G> couverture5gLireUn(Tracabilite tracabilite_p, String idAdresseBytel_p, TypeCouverture5G typeCouverture5G_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Couverture5G>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Couverture5G> run() throws RavelException
      {
        IRESConnector resConnector;
        try
        {
          resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_pad3015Couverture5GRead_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return resConnector.couverture5gLireUn(tracabilite_p, idAdresseBytel_p, typeCouverture5G_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_pad3015Couverture5GRead_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, List<CouvertureCuivre>> couvertureCuivreLireTousParIdAdresseBytel(Tracabilite tracabilite_p, String idAdresseBytel_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, List<CouvertureCuivre>>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, List<CouvertureCuivre>> run() throws RavelException
      {
        IRESConnector resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_couvertureCuivreLireTousParIdAdresseBytel_Read_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return resConnector.couvertureCuivreLireTousParIdAdresseBytel(tracabilite_p, idAdresseBytel_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_couvertureCuivreLireTousParIdAdresseBytel_Read_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, List<CouvertureCuivre>> couvertureCuivreLireUnParRivoli(Tracabilite tracabilite_p, String codeInsee_p, String rivoli_p, String numeroComplement_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, List<CouvertureCuivre>>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, List<CouvertureCuivre>> run() throws RavelException
      {
        IRESConnector resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_couvertureCuivreLireUnParRivoli_Read_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return resConnector.couvertureCuivreLireUnParRivoli(tracabilite_p, codeInsee_p, rivoli_p, numeroComplement_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_couvertureCuivreLireUnParRivoli_Read_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, List<CouvertureFtth>> couvertureFtthLireTousParHexacleInterne(Tracabilite tracabilite_p, String hexacleInterne_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, List<CouvertureFtth>>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, List<CouvertureFtth>> run() throws RavelException
      {
        IRESConnector resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_couvertureFtthLireTousParHexacleInterne_Read_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return resConnector.couvertureFtthLireTousParHexacleInterne(tracabilite_p, hexacleInterne_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_couvertureFtthLireTousParHexacleInterne_Read_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, List<CouvertureFtth>> couvertureFtthLireTousParIdAdresseBytel(Tracabilite tracabilite_p, String idAdresseBytel_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, List<CouvertureFtth>>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, List<CouvertureFtth>> run() throws RavelException
      {
        IRESConnector resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_couvertureFtthLireTousParIdAdresseBytel_Read_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return resConnector.couvertureFtthLireTousParIdAdresseBytel(tracabilite_p, idAdresseBytel_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_couvertureFtthLireTousParIdAdresseBytel_Read_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, List<CouvertureFtth>> couvertureFtthLireTousParIMB(Tracabilite tracabilite_p, String imb_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, List<CouvertureFtth>>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, List<CouvertureFtth>> run() throws RavelException
      {
        IRESConnector resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_couvertureFtthLireTousParIMB_Read_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return resConnector.couvertureFtthLireTousParIMB(tracabilite_p, imb_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_couvertureFtthLireTousParIMB_Read_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, CouvertureFtto> couvertureFttoLireUn(Tracabilite tracabilite_p, String idAdresseBytel_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, CouvertureFtto>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, CouvertureFtto> run() throws RavelException
      {
        IRESConnector resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_couvertureFttoLireUn_Read_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return resConnector.couvertureFttoLireUn(tracabilite_p, idAdresseBytel_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_couvertureFttoLireUn_Read_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, CouvertureGeoCodage> couvertureGeocodageLireUn(Tracabilite tracabilite_p, String idAdresseBytel_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, CouvertureGeoCodage>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, CouvertureGeoCodage> run() throws RavelException
      {
        IRESConnector resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_couvertureGeoCodage_Read_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return resConnector.couvertureGeocodageLireUn(tracabilite_p, idAdresseBytel_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_couvertureGeoCodage_Read_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, CouvertureTokyo> couvertureTokyoLireUn(Tracabilite tracabilite_p, String idAdresseBytel_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, CouvertureTokyo>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, CouvertureTokyo> run() throws RavelException
      {
        IRESConnector resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_couvertureTokyoLireUn_Read_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return resConnector.couvertureTokyoLireUn(tracabilite_p, idAdresseBytel_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_couvertureTokyoLireUn_Read_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, DispoNroFtteOrg> dispoNroFtteOrgLire(Tracabilite tracabilite_p, String nro_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, DispoNroFtteOrg>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, DispoNroFtteOrg> run() throws RavelException
      {
        IRESConnector resConnector;
        try
        {
          resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_dispoNroFtteOrgLire_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return resConnector.dispoNroFtteOrgLire(tracabilite_p, nro_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_dispoNroFtteOrgLire_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, List<DispoRessourceDSLAxione>> dispoRessourceDslAxioneLire(Tracabilite tracabilite_p, String nomUraOrange_p, String techno_p, String nbPaire_p, String typeKp_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, List<DispoRessourceDSLAxione>>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, List<DispoRessourceDSLAxione>> run() throws RavelException
      {
        IRESConnector resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_dispoRessourceDslAxioneLire_Read_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return resConnector.dispoRessourceDslAxioneLire(tracabilite_p, nomUraOrange_p, techno_p, nbPaire_p, typeKp_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_dispoRessourceDslAxioneLire_Read_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, List<DispoRessourceDSLAxione>> dispoRessourceDslAxioneLireParNomUra(Tracabilite tracabilite_p, String nomUraOrange_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, List<DispoRessourceDSLAxione>>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, List<DispoRessourceDSLAxione>> run() throws RavelException
      {
        IRESConnector resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_dispoRessourceDslAxioneLireParNomUra_Read_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return resConnector.dispoRessourceDslAxioneLireParNomUra(tracabilite_p, nomUraOrange_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_dispoRessourceDslAxioneLireParNomUra_Read_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, List<DispoRessourceDSLBouygues>> dispoRessourceDslBouyguesLire(Tracabilite tracabilite_p, String nomUraOrange_p, String techno_p, String nbPaire_p, String typeKp_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, List<DispoRessourceDSLBouygues>>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, List<DispoRessourceDSLBouygues>> run() throws RavelException
      {
        IRESConnector resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_dispoRessourceDslBouyguesLire_Read_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return resConnector.dispoRessourceDslBouyguesLire(tracabilite_p, nomUraOrange_p, techno_p, nbPaire_p, typeKp_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_dispoRessourceDslBouyguesLire_Read_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, List<DispoRessourceDSLBouygues>> dispoRessourceDslBouyguesLireParNomUra(Tracabilite tracabilite_p, String nomUraOrange_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, List<DispoRessourceDSLBouygues>>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, List<DispoRessourceDSLBouygues>> run() throws RavelException
      {
        IRESConnector resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_dispoRessourceDslBouyguesLireParNomUra_Read_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return resConnector.dispoRessourceDslBouyguesLireParNomUra(tracabilite_p, nomUraOrange_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_dispoRessourceDslBouyguesLireParNomUra_Read_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, List<DispoRessourceDSLOrange>> dispoRessourceDslOrangeLire(Tracabilite tracabilite_p, String nomUraOrange_p, String techno_p, String nbPaire_p, String typeKp_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, List<DispoRessourceDSLOrange>>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, List<DispoRessourceDSLOrange>> run() throws RavelException
      {
        IRESConnector resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_dispoRessourceDslOrangeLire_Read_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return resConnector.dispoRessourceDslOrangeLire(tracabilite_p, nomUraOrange_p, techno_p, nbPaire_p, typeKp_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_dispoRessourceDslOrangeLire_Read_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, List<DispoRessourceDSLOrange>> dispoRessourceDslOrangeLireParNomUra(Tracabilite tracabilite_p, String nomUraOrange_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, List<DispoRessourceDSLOrange>>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, List<DispoRessourceDSLOrange>> run() throws RavelException
      {
        IRESConnector resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_dispoRessourceDslOrangeLireParNomUra_Read_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return resConnector.dispoRessourceDslOrangeLireParNomUra(tracabilite_p, nomUraOrange_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_dispoRessourceDslOrangeLireParNomUra_Read_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, List<DispoRessourceDSLSFR>> dispoRessourceDslSFRLire(Tracabilite tracabilite_p, String nomUraOrange_p, String techno_p, String nbPaire_p, String typeKp_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, List<DispoRessourceDSLSFR>>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, List<DispoRessourceDSLSFR>> run() throws RavelException
      {
        IRESConnector resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_dispoRessourceDslSFRLire_Read_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return resConnector.dispoRessourceDslSFRLire(tracabilite_p, nomUraOrange_p, techno_p, nbPaire_p, typeKp_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_dispoRessourceDslSFRLire_Read_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, List<DispoRessourceDSLSFR>> dispoRessourceDslSFRLireParNomUra(Tracabilite tracabilite_p, String nomUraOrange_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, List<DispoRessourceDSLSFR>>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, List<DispoRessourceDSLSFR>> run() throws RavelException
      {
        IRESConnector resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_dispoRessourceDslSFRLireParNomUra_Read_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return resConnector.dispoRessourceDslSFRLireParNomUra(tracabilite_p, nomUraOrange_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_dispoRessourceDslSFRLireParNomUra_Read_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, List<EntonnoirCommune>> entonnoirCommuneLireTousParCodeInsee(Tracabilite tracabilite_p, String codeInsee_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, List<EntonnoirCommune>>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, List<EntonnoirCommune>> run() throws RavelException
      {
        IRESConnector resConnector;
        try
        {
          resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_entonnoirCommuneLireTousParCodeInsee_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return resConnector.entonnoirCommuneLireTousParCodeInsee(tracabilite_p, codeInsee_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_entonnoirCommuneLireTousParCodeInsee_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, List<EntonnoirCommune>> entonnoirCommuneLireTousParCodePostal(Tracabilite tracabilite_p, String codePostal_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, List<EntonnoirCommune>>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, List<EntonnoirCommune>> run() throws RavelException
      {
        IRESConnector resConnector;
        try
        {
          resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_entonnoirCommuneLireTousParCodePostal_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return resConnector.entonnoirCommuneLireTousParCodePostal(tracabilite_p, codePostal_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_entonnoirCommuneLireTousParCodePostal_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, List<EntonnoirCommune>> entonnoirCommuneLireTousParDepartement(Tracabilite tracabilite_p, String departement_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, List<EntonnoirCommune>>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, List<EntonnoirCommune>> run() throws RavelException
      {
        IRESConnector resConnector;
        try
        {
          resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_entonnoirCommuneLireTousParDepartement_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return resConnector.entonnoirCommuneLireTousParDepartement(tracabilite_p, departement_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_entonnoirCommuneLireTousParDepartement_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, List<EntonnoirNumero>> entonnoirNumeroLireTousParCodeInseeCodeRivoli(Tracabilite tracabilite_p, String codeInsee_p, String codeRivoli_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, List<EntonnoirNumero>>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, List<EntonnoirNumero>> run() throws RavelException
      {
        IRESConnector resConnector;
        try
        {
          resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_entonnoirNumeroLireTousParCodeInseeCodeRivoli_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return resConnector.entonnoirNumeroLireTousParCodeInseeCodeRivoli(tracabilite_p, codeInsee_p, codeRivoli_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_entonnoirNumeroLireTousParCodeInseeCodeRivoli_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, List<EntonnoirNumero>> entonnoirNumeroLireTousParCodeInseeSimiliHexacle0(Tracabilite tracabilite_p, String codeInsee_p, String similiHexacle0_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, List<EntonnoirNumero>>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, List<EntonnoirNumero>> run() throws RavelException
      {
        IRESConnector resConnector;
        try
        {
          resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_entonnoirNumeroLireTousParCodeInseeSimiliHexacle0_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return resConnector.entonnoirNumeroLireTousParCodeInseeSimiliHexacle0(tracabilite_p, codeInsee_p, similiHexacle0_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_entonnoirNumeroLireTousParCodeInseeSimiliHexacle0_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, List<EntonnoirVoie>> entonnoirVoieLireTousParCodeInsee(Tracabilite tracabilite_p, String codeInsee_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, List<EntonnoirVoie>>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, List<EntonnoirVoie>> run() throws RavelException
      {
        IRESConnector resConnector;
        try
        {
          resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_entonnoirVoieLireTousParCodeInsee_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return resConnector.entonnoirVoieLireTousParCodeInsee(tracabilite_p, codeInsee_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_entonnoirVoieLireTousParCodeInsee_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, List<EntonnoirVoie>> entonnoirVoieLireUnParCodeInseeCodeRivoli(Tracabilite tracabilite_p, String codeInsee_p, String codeRivoli_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, List<EntonnoirVoie>>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, List<EntonnoirVoie>> run() throws RavelException
      {
        IRESConnector resConnector;
        try
        {
          resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_entonnoirVoieLireUnParCodeInseeCodeRivoli_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return resConnector.entonnoirVoieLireUnParCodeInseeCodeRivoli(tracabilite_p, codeInsee_p, codeRivoli_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_entonnoirVoieLireUnParCodeInseeCodeRivoli_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, List<EntonnoirVoie>> entonnoirVoieLireUnParCodeInseeSimiliHexacle0(Tracabilite tracabilite_p, String codeInsee_p, String similiHexacle0_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, List<EntonnoirVoie>>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, List<EntonnoirVoie>> run() throws RavelException
      {
        IRESConnector resConnector;
        try
        {
          resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_entonnoirVoieLireUnParCodeInseeSimiliHexacle0_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return resConnector.entonnoirVoieLireUnParCodeInseeSimiliHexacle0(tracabilite_p, codeInsee_p, similiHexacle0_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_entonnoirVoieLireUnParCodeInseeSimiliHexacle0_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> fichierReferentielCompositeGererEchecIntegration(Tracabilite tracabilite_p, String typeReferentiel_p, FichierOrigine fichierOrigine_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        IRESConnector resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_fichierReferentielCompositeGererEchecIntegration_Manage_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return resConnector.fichierReferentielCompositeGererEchecIntegration(tracabilite_p, typeReferentiel_p, fichierOrigine_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_fichierReferentielCompositeGererEchecIntegration_Manage_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, List<FichierReferentielComposite>> fichierReferentielCompositeLireTous(Tracabilite tracabilite_p, String typeReferentiel_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, List<FichierReferentielComposite>>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, List<FichierReferentielComposite>> run() throws RavelException
      {
        IRESConnector resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_fichierReferentielCompositeLireTous_Read_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return resConnector.fichierReferentielCompositeLireTous(tracabilite_p, typeReferentiel_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_fichierReferentielCompositeLireTous_Read_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> fqdnGererAllocationSession(Tracabilite tracabilite_p, String nomfqdn_p, String operation_p, int nombreSession_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        IRESConnector resConnector;
        try
        {
          resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_ressourceCompteMailModifierStatutAllocation_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return resConnector.fqdnGererAllocationSession(tracabilite_p, nomfqdn_p, operation_p, nombreSession_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_ressourceCompteMailModifierStatutAllocation_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Fqdn> fqdnLireUn(Tracabilite tracabilite_p, String nomFQDN_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Fqdn>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Fqdn> run() throws RavelException
      {
        IRESConnector resConnector;
        try
        {
          resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_fqdnLireUn_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return resConnector.fqdnLireUn(tracabilite_p, nomFQDN_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_fqdnLireUn_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Fqdn> fqdnLireUnParTauxOccupation(Tracabilite tracabilite_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Fqdn>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Fqdn> run() throws RavelException
      {
        IRESConnector resConnector;
        try
        {
          resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_fqdnLireUn_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return resConnector.fqdnLireUnParTauxOccupation(tracabilite_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_fqdnLireUn_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> gestionReferentielGererBascule(Tracabilite tracabilite_p, String typeReferentiel_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        IRESConnector resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_gestionReferentielGererBascule_Manage_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return resConnector.gestionReferentielGererBascule(tracabilite_p, typeReferentiel_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_gestionReferentielGererBascule_Manage_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> gestionReferentielGererRestaurationBackup(Tracabilite tracabilite_p, String typeReferentiel_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        IRESConnector resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_gestionReferentielGererRestaurationBackup_Manage_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return resConnector.gestionReferentielGererRestaurationBackup(tracabilite_p, typeReferentiel_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_gestionReferentielGererRestaurationBackup_Manage_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> noeudRaccordementGererImport(Tracabilite tracabilite_p, ManageNoeudRaccordementRequest manageNoeudRaccordementRequest_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        return _noeudRaccordementProxy.gererImport(tracabilite_p, manageNoeudRaccordementRequest_p);
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Set<CompteRenduSuppression>> noeudRaccordementGererSuppressionNrNonReference(Tracabilite tracabilite_p, Set<String> listeNomNoedRaco_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Set<CompteRenduSuppression>>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Set<CompteRenduSuppression>> run() throws RavelException
      {
        return _noeudRaccordementProxy.gererSuppressionNrNonReference(tracabilite_p, listeNomNoedRaco_p);
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> oltCompositeGererImport(Tracabilite tracabilite_p, OltComposite oltComposite_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        return _oltCompositeProxy.oltCompositeGererImport(tracabilite_p, oltComposite_p);
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Set<CompteRenduSuppression>> oltCompositeGererSuppressionOltNonReference(Tracabilite tracabilite_p, Set<String> listeNomOLT_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Set<CompteRenduSuppression>>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Set<CompteRenduSuppression>> run() throws RavelException
      {
        return _oltCompositeProxy.oltCompositeGererSuppressionOltNonReference(tracabilite_p, listeNomOLT_p);
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, GetSurchargeResponse> oltCompositeLireSurchage(Tracabilite tracabilite_p, String nomOLT_p, String action_p, String positionCarte_p, String positionPortPon_p, String positionOntId_p) throws RavelException
  {

    return execute(new ConnectorExecution<ConnectorResponse<Retour, GetSurchargeResponse>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, GetSurchargeResponse> run() throws RavelException
      {
        return _oltCompositeProxy.oltCompositeLireSurchage(tracabilite_p, nomOLT_p, action_p, positionCarte_p, positionPortPon_p, positionOntId_p);

      }

    });
  }

  @Override
  public ConnectorResponse<Retour, OltComposite> oltCompositeLireUn(Tracabilite tracabilite_p, String nomOLT_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, OltComposite>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, OltComposite> run() throws RavelException
      {
        return _oltCompositeProxy.oltCompositeLireUn(tracabilite_p, nomOLT_p);
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> oltCompositemodifierSurchargeDateDebutQuarantaineOLT(Tracabilite tracabilite_p, ListeTechnologieAutorisee listTechnoAutorisee_p, String nomOlt_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        return _oltCompositeProxy.oltCompositemodifierSurchargeDateDebutQuarantaineOLT(tracabilite_p, listTechnoAutorisee_p, nomOlt_p);
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> oltCompositeModifierSurchargeDebitGarantiPortPon(Tracabilite tracabilite_p, String nomOlt_p, String positionCarte_p, String positionPortPon_p, String debitGarantieCapaciteAllouee_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        return _oltCompositeProxy.oltCompositeModifierSurchargeDebitGarantiPortPon(tracabilite_p, nomOlt_p, positionCarte_p, positionPortPon_p, debitGarantieCapaciteAllouee_p);
      }
    });

  }

  @Override
  public ConnectorResponse<Retour, Nothing> oltCompositeModifierSurchargeExploitationOntId(Tracabilite tracabilite_p, String nomOlt_p, String positionCarte_p, String positionPortPon_p, String positionOntId_p, String statutExploitation_p, String commentaireExploitation_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        return _oltCompositeProxy.oltCompositeModifierSurchargeExploitationOntId(tracabilite_p, nomOlt_p, positionCarte_p, positionPortPon_p, positionOntId_p, statutExploitation_p, commentaireExploitation_p);
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> oltCompositeModifierSurchargePriseClientCarte(Tracabilite tracabilite_p, String nomOlt_p, String positionCarte_p, String statutBlocage_p, String commentaireBlocage_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        return _oltCompositeProxy.oltCompositeModifierSurchargePriseClientCarte(tracabilite_p, nomOlt_p, positionCarte_p, statutBlocage_p, commentaireBlocage_p);
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> oltCompositeModifierSurchargePriseClientOLT(Tracabilite tracabilite_p, String nomOlt_p, String statutBlocage_p, String commentaireBlocage_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        return _oltCompositeProxy.oltCompositeModifierSurchargePriseClientOLT(tracabilite_p, nomOlt_p, statutBlocage_p, commentaireBlocage_p);
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> oltCompositeModifierSurchargePriseClientOntId(Tracabilite tracabilite_p, String nomOlt_p, String positionCarte_p, String positionPortPon_p, String positionOntId_p, String statutBlocage_p, String commentaireBlocage_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        return _oltCompositeProxy.oltCompositeModifierSurchargePriseClientOntId(tracabilite_p, nomOlt_p, positionCarte_p, positionPortPon_p, positionOntId_p, statutBlocage_p, commentaireBlocage_p);
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> oltCompositeModifierSurchargePriseClientPortPon(Tracabilite tracabilite_p, String nomOlt_p, String positionCarte_p, String positionPortPon_p, String statutBlocage_p, String commentaireBlocage_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        return _oltCompositeProxy.oltCompositeModifierSurchargePriseClientPortPon(tracabilite_p, nomOlt_p, positionCarte_p, positionPortPon_p, statutBlocage_p, commentaireBlocage_p);
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> oltCompositeModifierSurchargeTechnoAutoriseePortPon(Tracabilite tracabilite_p, ListeTechnologieAutorisee listTechnoAutorisee_p, String nomOlt_p, String positionCarte_p, String positionPortPon_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        return _oltCompositeProxy.oltCompositeModifierSurchargeTechnoAutoriseePortPon(tracabilite_p, listTechnoAutorisee_p, nomOlt_p, positionCarte_p, positionPortPon_p);
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> oltCompositeModifierSurchargeVersionOLT(Tracabilite tracabilite_p, ListeTechnologieAutorisee listTechnoAutorisee_p, String nomOlt_p, String versionInterfaceEchange_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        return _oltCompositeProxy.oltCompositeModifierSurchargeVersionOLT(tracabilite_p, listTechnoAutorisee_p, nomOlt_p, versionInterfaceEchange_p);
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Boolean> pad3001CommuneCreate(Tracabilite tracabilite_p, ListeCommuneRequest listeCommune_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Boolean>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Boolean> run() throws RavelException
      {
        IRESConnector resConnector;
        try
        {
          resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_PAD3001_Commune_Create_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return resConnector.pad3001CommuneCreate(tracabilite_p, listeCommune_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_PAD3001_Commune_Create_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, ListeCommuneResponse> pad3001CommuneReadAncienCodeInsee(Tracabilite tracabilite_p, String codeInsee_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, ListeCommuneResponse>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, ListeCommuneResponse> run() throws RavelException
      {
        IRESConnector resConnector;
        try
        {
          resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_PAD3001_Commune_ancienCodeInsee_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return resConnector.pad3001CommuneReadAncienCodeInsee(tracabilite_p, codeInsee_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_PAD3001_Commune_ancienCodeInsee_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, ListeCommuneResponse> pad3001CommuneReadCodeInsee(Tracabilite tracabilite_p, String codeInsee_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, ListeCommuneResponse>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, ListeCommuneResponse> run() throws RavelException
      {
        IRESConnector resConnector;
        try
        {
          resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_PAD3001_Commune_codeinsee_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return resConnector.pad3001CommuneReadCodeInsee(tracabilite_p, codeInsee_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_PAD3001_Commune_codeinsee_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, ListeCommuneResponse> pad3001CommuneReadCodePostal(Tracabilite tracabilite_p, String codePostal_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, ListeCommuneResponse>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, ListeCommuneResponse> run() throws RavelException
      {
        IRESConnector resConnector;
        try
        {
          resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_PAD3001_Commune_codePostal_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return resConnector.pad3001CommuneReadCodePostal(tracabilite_p, codePostal_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_PAD3001_Commune_codePostal_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Boolean> pad3002PrevisionProgCreate(Tracabilite tracabilite_p, ListePrevisionRequest listePrevision_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Boolean>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Boolean> run() throws RavelException
      {
        IRESConnector resConnector;
        try
        {
          resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_PAD3002_PrevisionProg_Create_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return resConnector.pad3002PrevisionProgCreate(tracabilite_p, listePrevision_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_PAD3002_PrevisionProg_Create_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, ListePrevisionResponse> pad3002PrevisionProgRead(Tracabilite tracabilite_p, String nomProgramme_p, String codeInsee_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, ListePrevisionResponse>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, ListePrevisionResponse> run() throws RavelException
      {
        IRESConnector resConnector;
        try
        {
          resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_PAD3002_PrevisionProg_Read_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return resConnector.pad3002PrevisionProgRead(tracabilite_p, nomProgramme_p, codeInsee_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_PAD3002_PrevisionProg_Read_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Boolean> pad3003IntegrationGroupeFichierCreate(Tracabilite tracabilite_p, IntegrationGroupeFichierRequest integration_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Boolean>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Boolean> run() throws RavelException
      {
        IRESConnector resConnector;
        try
        {
          resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_PAD3003_IntegrationGroupeFichier_Create_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return resConnector.pad3003IntegrationGroupeFichierCreate(tracabilite_p, integration_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_PAD3003_IntegrationGroupeFichier_Create_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Boolean> pad3003IntegrationGroupeFichierDelete(Tracabilite tracabilite_p, String nomGroupeFichier_p, String action_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Boolean>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Boolean> run() throws RavelException
      {
        IRESConnector resConnector;
        try
        {
          resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_PAD3003_IntegrationGroupeFichier_Delete_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return resConnector.pad3003IntegrationGroupeFichierDelete(tracabilite_p, nomGroupeFichier_p, action_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_PAD3003_IntegrationGroupeFichier_Delete_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, IntegrationGroupeFichierResponse> pad3003IntegrationGroupeFichierRead(Tracabilite tracabilite_p, String nomGrooupeFichier_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, IntegrationGroupeFichierResponse>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, IntegrationGroupeFichierResponse> run() throws RavelException
      {
        IRESConnector resConnector;
        try
        {
          resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_PAD3003_IntegrationGroupeFichier_Read_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return resConnector.pad3003IntegrationGroupeFichierRead(tracabilite_p, nomGrooupeFichier_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_PAD3003_IntegrationGroupeFichier_Read_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Boolean> pad3003IntegrationGroupeFichierUpdate(Tracabilite tracabilite_p, String nomGroupeFichier_p, String action_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Boolean>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Boolean> run() throws RavelException
      {
        IRESConnector resConnector;
        try
        {
          resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_PAD3003_IntegrationGroupeFichier_Update_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return resConnector.pad3003IntegrationGroupeFichierUpdate(tracabilite_p, nomGroupeFichier_p, action_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_PAD3003_IntegrationGroupeFichier_Update_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, RessourceAggrege> pad3101RessourceAggregeP2PLireUn(Tracabilite tracabilite_p, String typeRessourceAggrege_p, String idRessource_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, RessourceAggrege>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, RessourceAggrege> run() throws RavelException
      {
        IRESConnector resConnector;
        try
        {
          resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_pad3101RessourceAggregeP2PLireUn_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return resConnector.pad3101RessourceAggregeP2PLireUn(tracabilite_p, typeRessourceAggrege_p, idRessource_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_pad3101RessourceAggregeP2PLireUn_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, List<Olt>> pad3203OltLireTousFiltreNomOlt(Tracabilite tracabilite_p, ListeNomOLTRequest listNomOlt_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, List<Olt>>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, List<Olt>> run() throws RavelException
      {
        IRESConnector resConnector;
        try
        {
          resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_pad3203OltLireTousFiltreNomOlt_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return resConnector.pad3203OltLireTousFiltreNomOlt(tracabilite_p, listNomOlt_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_pad3203OltLireTousFiltreNomOlt_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Deprecated
  @Override
  public ConnectorResponse<Retour, Nothing> pmCompositeGererImport(Tracabilite tracabilite_p, PMComposite pmComposite_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        PmCompositeProxy pmCompositeProxy = new PmCompositeProxy(IRESConnector.BEAN_ID, _pmCompositeGererImport_avgCallCounterSecond, _pmCompositeGererImport_avgExecTime);
        return pmCompositeProxy.gererImport(tracabilite_p, pmComposite_p, null);
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> pmCompositeGererImport(Tracabilite tracabilite_p, PMComposite pmComposite_p, String typeFluxImport_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        PmCompositeProxy pmCompositeProxy = new PmCompositeProxy(IRESConnector.BEAN_ID, _pmCompositeGererImportWithTypeFluxImport_avgCallCounterSecond, _pmCompositeGererImportWithTypeFluxImport_avgExecTime);
        return pmCompositeProxy.gererImport(tracabilite_p, pmComposite_p, typeFluxImport_p);
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Set<CompteRenduSuppression>> pmCompositeGererSuppressionPMNonReference(Tracabilite tracabilite_p, Set<String> listNomPM_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Set<CompteRenduSuppression>>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Set<CompteRenduSuppression>> run() throws RavelException
      {
        PmCompositeProxy pmCompositeProxy = new PmCompositeProxy(IRESConnector.BEAN_ID, _pmCompositeGererSuppressionPmNonReference_avgCallCounterSecond, _pmCompositeGererSuppressionPmNonReference_avgExecTime);
        return pmCompositeProxy.gererSuppressionPMNonReference(tracabilite_p, listNomPM_p);
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, PMConsultResponse> pmCompositeLireSurchargeBoitierPM(Tracabilite tracabilite_p, String referencePmBytel_p, String referenceBoitierPm_p, String nomPanneau_p, String positionPortPM_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, PMConsultResponse>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, PMConsultResponse> run() throws RavelException
      {
        PmCompositeProxy pmCompositeProxy = new PmCompositeProxy(IRESConnector.BEAN_ID, _pmCompositeLireSurchargeBoitierPM_avgCallCounterSecond, _pmCompositeLireSurchargeBoitierPM_avgExecTime);
        return pmCompositeProxy.lireSurchargeBoitierPM(tracabilite_p, referencePmBytel_p, referenceBoitierPm_p, nomPanneau_p, positionPortPM_p);
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, PMConsultResponse> pmCompositeLireSurchargePM(Tracabilite tracabilite_p, String referencePmBytel_p, String referenceBoitierPm_p, String nomPanneau_p, String positionPortPM_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, PMConsultResponse>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, PMConsultResponse> run() throws RavelException
      {
        PmCompositeProxy pmCompositeProxy = new PmCompositeProxy(IRESConnector.BEAN_ID, _pmCompositeLireSurchargePM_avgCallCounterSecond, _pmCompositeLireSurchargePM_avgExecTime);
        return pmCompositeProxy.lireSurchargePM(tracabilite_p, referencePmBytel_p, referenceBoitierPm_p, nomPanneau_p, positionPortPM_p);
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, PMConsultResponse> pmCompositeLireSurchargePortPM(Tracabilite tracabilite_p, String referencePmBytel_p, String referenceBoitierPm_p, String nomPanneau_p, String positionPortPM_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, PMConsultResponse>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, PMConsultResponse> run() throws RavelException
      {
        PmCompositeProxy pmCompositeProxy = new PmCompositeProxy(IRESConnector.BEAN_ID, _pmCompositeLireSurchargePortPM_avgCallCounterSecond, _pmCompositeLireSurchargePortPM_avgExecTime);
        return pmCompositeProxy.lireSurchargePortPM(tracabilite_p, referencePmBytel_p, referenceBoitierPm_p, nomPanneau_p, positionPortPM_p);
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, PMComposite> pmCompositeLireUnParReferencePmBytel(Tracabilite tracabilite_p, String referencePmBytel_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, PMComposite>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, PMComposite> run() throws RavelException
      {
        PmCompositeProxy pmCompositeProxy = new PmCompositeProxy(IRESConnector.BEAN_ID, _pmCompositeLireUnParReferencePmBytel_avgCallCounterSecond, _pmCompositeLireUnParReferencePmBytel_avgExecTime);
        return pmCompositeProxy.lireUnParReferencePmBytel(tracabilite_p, referencePmBytel_p);
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, PMComposite> pmCompositeLireUnParReferencePmOi(Tracabilite tracabilite_p, String referencePmOi_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, PMComposite>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, PMComposite> run() throws RavelException
      {
        PmCompositeProxy pmCompositeProxy = new PmCompositeProxy(IRESConnector.BEAN_ID, _pmCompositeLireUnParReferencePmOi_avgCallCounterSecond, _pmCompositeLireUnParReferencePmOi_avgExecTime);
        return pmCompositeProxy.lireUnParReferencePmOi(tracabilite_p, referencePmOi_p);
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> pmCompositeModifierSurchargeDateDebutQuarantainePM(Tracabilite tracabilite_p, String referencePmBytel_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        PmCompositeProxy pmCompositeProxy = new PmCompositeProxy(_connectorId, _pmCompositeModifierSurchargeDateDebutQuarantainePM_avgCallCounterSecond, _pmCompositeModifierSurchargeDateDebutQuarantainePM_avgExecTime);
        return pmCompositeProxy.modifierSurchargeDateDebutQuarantainePM(tracabilite_p, referencePmBytel_p);
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> pmCompositeModifierSurchargeExploitationPortPM(Tracabilite tracabilite_p, String referencePmBytel_p, String referenceBoitierPm_p, String nomPanneau_p, String positionPortPM_p, String statutExploitation_p, String commentaireExploitation_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        PmCompositeProxy pmCompositeProxy = new PmCompositeProxy(_connectorId, _pmCompositeModifierSurchargeExploitationPortPM_avgCallCounterSecond, _pmCompositeModifierSurchargeExploitationPortPM_avgExecTime);
        return pmCompositeProxy.modifierSurchargeExploitationPortPM(tracabilite_p, referencePmBytel_p, referenceBoitierPm_p, nomPanneau_p, positionPortPM_p, statutExploitation_p, commentaireExploitation_p);
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> pmCompositeModifierSurchargePriseClientBoitierPM(Tracabilite tracabilite_p, String referencePmBytel_p, String referenceBoitierPm_p, String statutBlocage_p, String commentaireBlocage_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        PmCompositeProxy pmCompositeProxy = new PmCompositeProxy(_connectorId, _pmCompositeModifierSurchargePriseClientBoitierPM_avgCallCounterSecond, _pmCompositeModifierSurchargePriseClientBoitierPM_avgExecTime);
        return pmCompositeProxy.modifierSurchargePriseClientBoitierPM(tracabilite_p, referencePmBytel_p, referenceBoitierPm_p, statutBlocage_p, commentaireBlocage_p);
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> pmCompositeModifierSurchargePriseClientPM(Tracabilite tracabilite_p, String referencePmBytel_p, String statutBlocage_p, String commentaireBlocage_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        PmCompositeProxy pmCompositeProxy = new PmCompositeProxy(_connectorId, _pmCompositeModifierSurchargePriseClientPM_avgCallCounterSecond, _pmCompositeModifierSurchargePriseClientPM_avgExecTime);
        return pmCompositeProxy.modifierSurchargePriseClientPM(tracabilite_p, referencePmBytel_p, statutBlocage_p, commentaireBlocage_p);
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> pmCompositeModifierSurchargePriseClientPortPM(Tracabilite tracabilite_p, String referencePmBytel_p, String referenceBoitierPm_p, String nomPanneau_p, String positionPortPM_p, String statutBlocage_p, String commentaireBlocage_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        PmCompositeProxy pmCompositeProxy = new PmCompositeProxy(_connectorId, _pmCompositeModifierSurchargePriseClientPortPM_avgCallCounterSecond, _pmCompositeModifierSurchargePriseClientPortPM_avgExecTime);
        return pmCompositeProxy.modifierSurchargePriseClientPortPM(tracabilite_p, referencePmBytel_p, referenceBoitierPm_p, nomPanneau_p, positionPortPM_p, statutBlocage_p, commentaireBlocage_p);
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> pointAncrageIpGererImport(Tracabilite tracabilite_p, PointAncrageIP pointAncrageIP_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        return _pointAncrageIpProxy.pointAncrageIpGererImport(tracabilite_p, pointAncrageIP_p);
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Set<CompteRenduSuppression>> pointAncrageIpGererSuppressionPointAncrageIPNonReference(Tracabilite tracabilite_p, Set<String> listeNomPointAncrageIP_p, String typePointAncrageIP_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Set<CompteRenduSuppression>>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Set<CompteRenduSuppression>> run() throws RavelException
      {
        return _pointAncrageIpProxy.pointAncrageIpGererSuppressionPointAncrageIPNonReference(tracabilite_p, listeNomPointAncrageIP_p, typePointAncrageIP_p);
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> poolIpGererImport(Tracabilite tracabilite_p, PoolIP poolIP_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        return _poolIpProxy.gererImport(tracabilite_p, poolIP_p);
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> porteDeCollecteGererImport(Tracabilite tracabilite_p, PorteDeCollecte porteDeCollecte_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        return _porteDeCollecteProxy.gererImport(tracabilite_p, porteDeCollecte_p);
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Set<CompteRenduSuppression>> porteDeCollecteGererSuppressionPorteDeCollecteNonReference(Tracabilite tracabilite_p, Set<String> setIdNomCollecte_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Set<CompteRenduSuppression>>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Set<CompteRenduSuppression>> run() throws RavelException
      {
        return _porteDeCollecteProxy.gererSuppressionPorteDeCollecteNonReference(tracabilite_p, setIdNomCollecte_p);
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, PorteDeCollecte> porteDeCollecteLireUn(Tracabilite tracabilite_p, String idNomCollecte_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, PorteDeCollecte>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, PorteDeCollecte> run() throws RavelException
      {
        return _porteDeCollecteProxy.porteDeCollecteLireUn(tracabilite_p, idNomCollecte_p);
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> ressourceAdresseIpClfCreer(Tracabilite tracabilite_p, Ressource ressource_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        IRESConnector resConnector;
        try
        {
          resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_ressourceCompteMailCreer_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return resConnector.ressourceAdresseIpClfCreer(tracabilite_p, ressource_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_ressourceCompteMailCreer_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> ressourceAdresseIpClfModifierStatutAllocation(Tracabilite tracabilite_p, String idRessource_p, String idSt_p, String statut_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        IRESConnector resConnector;
        try
        {
          resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_ressourceCompteMailModifierStatutAllocation_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return resConnector.ressourceAdresseIpClfModifierStatutAllocation(tracabilite_p, idRessource_p, idSt_p, statut_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_ressourceCompteMailModifierStatutAllocation_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> ressourceCompteImsCreer(Tracabilite tracabilite_p, Ressource ressource_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        IRESConnector resConnector;
        try
        {
          resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_ressourceCompteMailCreer_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return resConnector.ressourceCompteImsCreer(tracabilite_p, ressource_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_ressourceCompteMailCreer_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> ressourceCompteImsModifierStatutAllocation(Tracabilite tracabilite_p, String idRessource_p, String idSt_p, String statut_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        IRESConnector resConnector;
        try
        {
          resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_ressourceCompteMailModifierStatutAllocation_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return resConnector.ressourceCompteImsModifierStatutAllocation(tracabilite_p, idRessource_p, idSt_p, statut_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_ressourceCompteMailModifierStatutAllocation_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> ressourceCompteMailCreer(Tracabilite tracabilite_p, Ressource ressource_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        IRESConnector resConnector;
        try
        {
          resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_ressourceCompteMailCreer_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return resConnector.ressourceCompteMailCreer(tracabilite_p, ressource_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_ressourceCompteMailCreer_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> ressourceCompteMailModifierStatutAllocation(Tracabilite tracabilite_p, String idRessource_p, String idSt_p, String statut_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        IRESConnector resConnector;
        try
        {
          resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_ressourceCompteMailModifierStatutAllocation_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return resConnector.ressourceCompteMailModifierStatutAllocation(tracabilite_p, idRessource_p, idSt_p, statut_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_ressourceCompteMailModifierStatutAllocation_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, List<RessourceFtth>> ressourceFtthLireTousParReferencePM(Tracabilite tracabilite_p, String referencePm_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, List<RessourceFtth>>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, List<RessourceFtth>> run() throws RavelException
      {
        IRESConnector resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_ressourceFtthLireTousParReferencePM_Read_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return resConnector.ressourceFtthLireTousParReferencePM(tracabilite_p, referencePm_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_ressourceFtthLireTousParReferencePM_Read_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> ressourceImpiFixeCreer(Tracabilite tracabilite_p, Ressource ressource_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        IRESConnector resConnector;
        try
        {
          resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_ressourceCompteMailCreer_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return resConnector.ressourceImpiFixeCreer(tracabilite_p, ressource_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_ressourceCompteMailCreer_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> ressourceImpiFixeModifierStatutAllocation(Tracabilite tracabilite_p, String idRessource_p, String idSt_p, String statut_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        IRESConnector resConnector;
        try
        {
          resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_ressourceCompteMailModifierStatutAllocation_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return resConnector.ressourceImpiFixeModifierStatutAllocation(tracabilite_p, idRessource_p, idSt_p, statut_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_ressourceCompteMailModifierStatutAllocation_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, List<Ressource>> ressourceLireTousParIdRessourceLie(Tracabilite tracabilite_p, String idRessourceLie_p, String typeRessource_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, List<Ressource>>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, List<Ressource>> run() throws RavelException
      {
        return _ressourceProxy.ressourceLireTousParIdRessourceLie(tracabilite_p, idRessourceLie_p, typeRessource_p);
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Ressource> ressourceLireUn(Tracabilite tracabilite_p, String idRessource_p, String typeRessource_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Ressource>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Ressource> run() throws RavelException
      {
        return _ressourceProxy.ressourceLireUn(tracabilite_p, idRessource_p, typeRessource_p);
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> ressourceModifierIdRessourceLie(Tracabilite tracabilite_p, String typeRessource_p, String idRessource_p, String idRessourceLie_p, String idRessourceLieCible_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        return _ressourceProxy.ressourceModifierIdRessourceLie(tracabilite_p, typeRessource_p, idRessource_p, idRessourceLie_p, idRessourceLieCible_p);
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> ressourceMotDePasseImsCreer(Tracabilite tracabilite_p, Ressource ressource_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        IRESConnector resConnector;
        try
        {
          resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_ressourceCompteMailCreer_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return resConnector.ressourceMotDePasseImsCreer(tracabilite_p, ressource_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_ressourceCompteMailCreer_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> ressourceMotDePasseImsModifierStatutAllocation(Tracabilite tracabilite_p, String idRessource_p, String idSt_p, String statut_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        IRESConnector resConnector;
        try
        {
          resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_ressourceCompteMailModifierStatutAllocation_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return resConnector.ressourceMotDePasseImsModifierStatutAllocation(tracabilite_p, idRessource_p, idSt_p, statut_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_ressourceCompteMailModifierStatutAllocation_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> ressourceOntIdGererLiberation(Tracabilite tracabilite_p, String idRessource_p, String idRessourceLie_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        IRESConnector resConnector;
        try
        {
          resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_ressourceCompteMailModifierStatutAllocation_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return resConnector.ressourceOntIdGererLiberation(tracabilite_p, idRessource_p, idRessourceLie_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_ressourceCompteMailModifierStatutAllocation_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Integer> ressourcePortP2PcompterPortLibreP2P(Tracabilite tracabilite_p, String nomNR_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Integer>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Integer> run() throws RavelException
      {
        return _ressourcePortP2PProxy.ressourcePortP2PcompterPortLibreP2P(tracabilite_p, nomNR_p);
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> ressourcePortP2PGererAllocation(Tracabilite tracabilite_p, String nomNR_p, String distance_p, String idRessourceLie_p, String action_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        return _ressourcePortP2PProxy.ressourcePortP2PGererAllocation(tracabilite_p, nomNR_p, distance_p, idRessourceLie_p, action_p);
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> ressourcePortP2PModifierStatutAllocation(Tracabilite tracabilite_p, String idRessource_p, String idRessourceLie_p, String statut_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        return _ressourcePortP2PProxy.ressourcePortP2PModifierStatutAllocation(tracabilite_p, idRessource_p, idRessourceLie_p, statut_p);
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, RessourcePortPM> ressourcePortPmGererAllocation(Tracabilite tracabilite_p, String referencePmBytel_p, String referencePmOi_p, String referenceBoitierPm_p, String nomPmTechnique_p, String nomPanneauPm_p, Integer positionPortPm_p, String technologiePON_p, String idRessourceLie_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, RessourcePortPM>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, RessourcePortPM> run() throws RavelException
      {
        return _ressourcePortPmProxy.ressourcePortPmGererAllocation(tracabilite_p, referencePmBytel_p, referencePmOi_p, referenceBoitierPm_p, nomPmTechnique_p, nomPanneauPm_p, positionPortPm_p, technologiePON_p, idRessourceLie_p);
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, RessourcePortPM> ressourcePortPmGererMigrationPortPm(Tracabilite tracabilite_p, String idRessource_p, String motifMigration_p, String referencePmBytel_p, String referencePmOi_p, String referenceBoitierPm_p, String nomPmTechnique_p, String nomPanneauPm_p, Integer positionPortPm_p, String technologiePON_p, String idRessourceLie_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, RessourcePortPM>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, RessourcePortPM> run() throws RavelException
      {
        return _ressourcePortPmProxy.ressourcePortPmGererMigrationPortPm(tracabilite_p, idRessource_p, motifMigration_p, referencePmBytel_p, referencePmOi_p, referenceBoitierPm_p, nomPmTechnique_p, nomPanneauPm_p, positionPortPm_p, technologiePON_p, idRessourceLie_p);
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, String> ressourceRaccordementCompositeGererAnalyserModifRR(Tracabilite tracabilite_p, String idRRSource_p, String idRRCible_p, String action_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, String>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, String> run() throws RavelException
      {
        IRESConnector resConnector;
        try
        {
          resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_ressourceRaccordementCompositeGererAnalyserModif_RR_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return resConnector.ressourceRaccordementCompositeGererAnalyserModifRR(tracabilite_p, idRRSource_p, idRRCible_p, action_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_ressourceRaccordementCompositeGererAnalyserModif_RR_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, RessourceRaccordementComposite> ressourceRaccordementCompositeLireUn(Tracabilite tracabilite_p, String idRessource_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, RessourceRaccordementComposite>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, RessourceRaccordementComposite> run() throws RavelException
      {
        IRESConnector resConnector;
        try
        {
          resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_ressourceRaccordementCompositeLireUn_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return resConnector.ressourceRaccordementCompositeLireUn(tracabilite_p, idRessource_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_ressourceRaccordementCompositeLireUn_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> ressourceRaccordementCreer(Tracabilite tracabilite_p, Ressource ressource_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        return _ressourceRaccordementProxy.ressourceRaccordementCreer(tracabilite_p, ressource_p);
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> ressourceRaccordementModifierCodeAccesTechnique(Tracabilite tracabilite_p, String idRessource_p, String codeAccesTechnique_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        return _ressourceRaccordementProxy.ressourceRaccordementModifierCodeAccesTechnique(tracabilite_p, idRessource_p, codeAccesTechnique_p);
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> ressourceRaccordementModifierOntInstalle(Tracabilite tracabilite_p, String idRessource_p, LocalDateTime dateDerniereDeclarationOntInstalle_p, String typeTechnologiePon_p, String noSerieOntInstalle_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        return _ressourceRaccordementProxy.ressourceRaccordementModifierOntInstalle(tracabilite_p, idRessource_p, dateDerniereDeclarationOntInstalle_p, typeTechnologiePon_p, noSerieOntInstalle_p);
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> ressourceRaccordementModifierStatutAllocation(Tracabilite tracabilite_p, String idRessource_p, String idSt_p, String statut_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        return _ressourceRaccordementProxy.ressourceRaccordementModifierStatutAllocation(tracabilite_p, idRessource_p, idSt_p, statut_p);
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, Nothing> structureVerticaleFtthCompositeCreer(Tracabilite tracabilite_p, StructureVerticaleFtthComposite structureVerticaleFtthComposite_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, Nothing>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, Nothing> run() throws RavelException
      {
        IRESConnector resConnector;
        try
        {
          resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_structureVerticaleFtthComposite_Creer_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return resConnector.structureVerticaleFtthCompositeCreer(tracabilite_p, structureVerticaleFtthComposite_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_structureVerticaleFtthComposite_Creer_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, StructureVerticaleFtthComposite> structureVerticaleFtthCompositeLireTousParListeOIIMB(Tracabilite tracabilite_p, ListeCoupleImbOiRequest listeCoupleImbOi_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, StructureVerticaleFtthComposite>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, StructureVerticaleFtthComposite> run() throws RavelException
      {
        IRESConnector resConnector;
        try
        {
          resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        }
        catch (Exception e_p)
        {
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
        }
        _avg_structureVerticaleFtthCompositeLireTousParListeOIIMB_Read_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return resConnector.structureVerticaleFtthCompositeLireTousParListeOIIMB(tracabilite_p, listeCoupleImbOi_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_structureVerticaleFtthCompositeLireTousParListeOIIMB_Read_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, List<TopologieArcturus>> topologieArcturusLireTousParIdEqptAcces(Tracabilite tracabilite_p, String idEqptAcces_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, List<TopologieArcturus>>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, List<TopologieArcturus>> run() throws RavelException
      {
        return _topologieArcturusProxy.topologieArcturusLireTousParIdEqptAcces(tracabilite_p, idEqptAcces_p);
      }
    });
  }

  @Override
  public ConnectorResponse<Retour, TopologieArcturus> topologieArcturusLireUn(Tracabilite tracabilite_p, String idNomCollecte_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Retour, TopologieArcturus>>(IRESConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Retour, TopologieArcturus> run() throws RavelException
      {
        return _topologieArcturusProxy.topologieArcturusLireUn(tracabilite_p, idNomCollecte_p);
      }
    });
  }
}
