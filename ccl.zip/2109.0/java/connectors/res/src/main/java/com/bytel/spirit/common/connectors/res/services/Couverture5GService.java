/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.res.services;

import java.text.MessageFormat;
import java.util.HashMap;

import javax.ws.rs.HttpMethod;
import javax.ws.rs.core.Response;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.connector.RESTRequest;
import com.bytel.spirit.common.connectors.res.IRESConnector;
import com.bytel.spirit.common.connectors.res.RESConnector;
import com.bytel.spirit.common.shared.misc.connectors.AbstractInternalRESTConnector;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.RetourConverter;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.Couverture5G;
import com.bytel.spirit.common.shared.saab.res.TypeCouverture5G;
import com.bytel.spirit.common.shared.saab.res.response.GetCouverture5G;

/**
 * @author jpais
 * @version ($Revision$ $Date$)
 */
public class Couverture5GService
{
  /** The constant for couverture5GlireUn service name */
  public static final String METHOD_NAME_COUVERTURE_5G_LIRE_UN = "couverture5GlireUn"; //$NON-NLS-1$

  private final RESConnector _resInstance;

  /**
   * Default constructor
   *
   * @param resInstance_p
   *          Current RESConnector instance
   */
  public Couverture5GService(RESConnector resInstance_p)
  {
    _resInstance = resInstance_p;
  }

  public ConnectorResponse<Retour, Couverture5G> couverture5gLireUn(Tracabilite tracabilite_p, String couverture5GUrl_p, String idAdresseBytel_p, TypeCouverture5G typeCouverture5G_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(couverture5GUrl_p))
      {
        throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(IRESConnector.MESSAGE_MISSING_CONFIGURATION_PARAMETER, IRESConnector.PAD3015_PATH_PARAM));
      }

      // Query parameters
      HashMap<String, String> queryParams = new HashMap<>();
      if (StringTools.isNotNullOrEmpty(idAdresseBytel_p))
      {
        queryParams.put(IRESConnector.PARAM_ID_ADRESSE_BYTEL, idAdresseBytel_p);
        queryParams.put(IRESConnector.PARAM_TYPE_COUVERTURE_5G, typeCouverture5G_p.name());
      }

      // Call SAAB
      final Response response;
      try
      {
        RESTRequest restRequest = new RESTRequest.RESTRequestBuilder()//
            .httpMethod(HttpMethod.GET)//
            .traceability(tracabilite_p)//
            .method(METHOD_NAME_COUVERTURE_5G_LIRE_UN)//
            .headers(AbstractInternalRESTConnector.getSpiritStarkRequestHeader())//
            .path(couverture5GUrl_p)//
            .queryParameter(queryParams)//
            .build();
        response = _resInstance.sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content
      GetCouverture5G couverture5GResponse = _resInstance.getContentFromResponse(tracabilite_p, response, METHOD_NAME_COUVERTURE_5G_LIRE_UN, GetCouverture5G.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(couverture5GResponse.getRetour());
      Couverture5G couverture5g = couverture5GResponse.getCouverture5G();
      return new ConnectorResponse<>(retour, couverture5g);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

}
