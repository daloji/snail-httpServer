/*******************************************************************************
* $Id: NoeudRaccordementService.java 49682 2021-03-24 13:30:21Z fbarnabe $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.res.services;

import java.text.MessageFormat;
import java.util.HashMap;
import java.util.Set;

import javax.ws.rs.HttpMethod;
import javax.ws.rs.core.Response;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.json.IRavelJson;
import com.bytel.ravel.common.json.RavelJson;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.connector.RESTRequest;
import com.bytel.ravel.services.connector.RESTRequest.RESTRequestBuilder;
import com.bytel.spirit.common.connectors.res.IRESConnector;
import com.bytel.spirit.common.connectors.res.RESConnector;
import com.bytel.spirit.common.shared.misc.connectors.AbstractInternalRESTConnector;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.ressources.RetourConverter;
import com.bytel.spirit.common.shared.misc.ressources.SpiritConstants;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.CompteRenduSuppression;
import com.bytel.spirit.common.shared.saab.res.request.ManageNoeudRaccordementRequest;
import com.bytel.spirit.common.shared.saab.res.response.NoeudRaccordementResponse;

/**
 *
 * @author jiantila
 * @version ($Revision: 49682 $ $Date: 2021-03-24 14:30:21 +0100 (mer. 24 mars 2021) $)
 */
public class NoeudRaccordementService
{

  /**
   *
   */
  private final RESConnector _resInstance;
  
  public interface IMethodName
  {
    String NOEUD_RACCORDEMENT_GERER_IMPORT = "noeudRaccordementGererImport"; //$NON-NLS-1$
    String NOEUD_RACCORDEMENT_GERER_SUPPRESSION_NR_NON_REFERENCE = "noeudRaccordementGererSuppressionNrNonReference"; //$NON-NLS-1$
  }

  /**
   *
   */
  private IRavelJson _jsonBuilder;

  /**
   * @param resInstance_p
   *          {@link RESConnector}
   */
  public NoeudRaccordementService(RESConnector resInstance_p)
  {
    _resInstance = resInstance_p;
    _jsonBuilder = new RavelJson.RavelJsonBuilder().profil(SpiritConstants.JSON_PROFILE_STARK).build();
  }

  /**
   * Ce service permet de créer ou de modifier une ressource « NoeudRaccordement ». QueryParam - Cas n°1 GererImport
   *
   * @param tracabilite_p
   *          tracabilite
   * @param noeudRaccordementUrl_p
   *          noeud Raccordement url
   * @param manageNoeudRaccordementRequest_p
   *          noued Raccordement request
   * @return Nothing (in a connector response).
   */
  public ConnectorResponse<Retour, Nothing> noeudRaccordementGererImport(Tracabilite tracabilite_p, String noeudRaccordementUrl_p, ManageNoeudRaccordementRequest manageNoeudRaccordementRequest_p)
  {
    try
    {
      if (StringTools.isNullOrEmpty(noeudRaccordementUrl_p))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(IRESConnector.MESSAGE_MISSING_CONFIGURATION_PARAMETER, IRESConnector.PAD3204_PATH_PARAM));
      }

      // Query parameters
      HashMap<String, String> queryParams = new HashMap<>();
      queryParams.put(IRESConnector.PARAM_ACTION, IRESConnector.ACTION_GERER_IMPORT);
      // Call SAAB
      final Response response;
      try
      {
        RESTRequest restRequest = new RESTRequestBuilder()//
            .httpMethod(HttpMethod.PUT)//
            .serializer(_jsonBuilder)//
            .traceability(tracabilite_p)//
            .method(IMethodName.NOEUD_RACCORDEMENT_GERER_IMPORT)//
            .headers(AbstractInternalRESTConnector.getSpiritStarkRequestHeader())//
            .path(noeudRaccordementUrl_p)//
            .queryParameter(queryParams)//
            .request(manageNoeudRaccordementRequest_p)//
            .build();
        response = _resInstance.sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content to a JSON string
      // Get the content
      NoeudRaccordementResponse noeudResponse = _resInstance.getContentFromResponse(tracabilite_p, response, IMethodName.NOEUD_RACCORDEMENT_GERER_IMPORT, NoeudRaccordementResponse.class);
      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(noeudResponse.getRetour());
      return new ConnectorResponse<>(retour, null);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }

  }

  /**
   * NoeudRaccordement creerNoeudRaccordementGererSuppression verb.
   *
   * @param tracabilite_p
   *          tracabilite
   * @param noeudRaccordementUrl_p
   *          SAAB path to use.
   * @param listeNomNoedRaco_p
   *          the list with the names of the NoedRaccordement that have been imported.
   * @return ConnectorResponse<Retour, List<CompteRenduSuppression>>
   * @throws RavelException
   *           if the SAAB call fails.
   */
  public ConnectorResponse<Retour, Set<CompteRenduSuppression>> noeudRaccordementGererSuppressionNrNonReference(Tracabilite tracabilite_p, String noeudRaccordementUrl_p, Set<String> listeNomNoedRaco_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(noeudRaccordementUrl_p))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(IRESConnector.MESSAGE_MISSING_CONFIGURATION_PARAMETER, IRESConnector.PAD3204_PATH_PARAM));
      }

      // Query parameters
      HashMap<String, String> queryParams = new HashMap<>();
      queryParams.put(IRESConnector.PARAM_ACTION, IRESConnector.GERER_SUPPRESSION);

      // Call SAAB
      final Response response;

      try
      {
        RESTRequest restRequest = new RESTRequestBuilder() //
            .httpMethod(HttpMethod.PUT) //
            .traceability(tracabilite_p) //
            .serializer(_jsonBuilder) //
            .method(IMethodName.NOEUD_RACCORDEMENT_GERER_SUPPRESSION_NR_NON_REFERENCE) //
            .headers(AbstractInternalRESTConnector.getSpiritStarkRequestHeader()) //
            .path(noeudRaccordementUrl_p) //
            .queryParameter(queryParams) //
            .request(new ManageNoeudRaccordementRequest(listeNomNoedRaco_p)) //
            .build();

        response = _resInstance.sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content to a JSON string
      // Get the content
      NoeudRaccordementResponse noeudRaccordementResponse = _resInstance.getContentFromResponse(tracabilite_p, response, IMethodName.NOEUD_RACCORDEMENT_GERER_SUPPRESSION_NR_NON_REFERENCE, NoeudRaccordementResponse.class);
      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(noeudRaccordementResponse.getRetour());

      Set<CompteRenduSuppression> listCompteSuppr = noeudRaccordementResponse.getListeCompteRenduSupression();

      return new ConnectorResponse<>(retour, listCompteSuppr);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }
}
