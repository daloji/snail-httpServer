
/*******************************************************************************
* $Id: Messages.java 199 2017-07-13 10:20:21Z pcarreir $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.res;

import java.util.MissingResourceException;
import java.util.ResourceBundle;

/**
 *
 * @author pcarreir
 * @version ($Revision: 199 $ $Date: 2017-07-13 12:20:21 +0200 (jeu., 13 juil. 2017) $)
 */
public final class Messages
{
  /**
   * The bundle name
   */
  private static final String BUNDLE_NAME = "com.bytel.spirit.common.connectors.res.messages"; //$NON-NLS-1$

  /**
   * Creating resource bundle
   */
  private static final ResourceBundle RESOURCE_BUNDLE = ResourceBundle.getBundle(BUNDLE_NAME);

  /**
   * @param key
   *          The key of the object to find
   * @return String
   */
  public static String getString(String key)
  {
    try
    {
      return Messages.RESOURCE_BUNDLE.getString(key);
    }
    catch (MissingResourceException e)
    {
      return '!' + key + '!';
    }
  }

  /**
   * The constructor
   */
  private Messages()
  {
  }
}
