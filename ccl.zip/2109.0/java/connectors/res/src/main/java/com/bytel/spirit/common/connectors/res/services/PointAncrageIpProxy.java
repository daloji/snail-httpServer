/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.res.services;

import java.util.Set;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.probes.AvgDoubleCollectorItem;
import com.bytel.ravel.common.probes.AvgFlowPerSecondCollector;
import com.bytel.ravel.common.probes.RavelProbeConfigurationManager;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.services.connector.ConnectorManager;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.connectors.res.IRESConnector;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.CompteRenduSuppression;
import com.bytel.spirit.common.shared.saab.res.PointAncrageIP;

/**
 *
 * @author jrolao
 * @version ($Revision$ $Date$)
 */
public class PointAncrageIpProxy
{

  /** connector Id */
  private final String _connectorId;

  /** For probe to count the amount of call to the pointAncrageIpGererImport operation */
  AvgFlowPerSecondCollector _avg_pointAncrageIpGererImport_call_counter;
  /** For probe to count the execution time of call to the pointAncrageIpGererImport operation */
  AvgDoubleCollectorItem _avg_pointAncrageIpGererImport_ExecTime;

  /** For probe to count the amount of call to the pointAncrageIpGererSuppressionPointAncrageIPNonReference operation */
  AvgFlowPerSecondCollector _avg_pointAncrageIpGererSuppressionPointAncrageIPNonReference_call_counter;
  /**
   * For probe to count the execution time of call to the pointAncrageIpGererSuppressionPointAncrageIPNonReference
   * operation
   */
  AvgDoubleCollectorItem _avg_pointAncrageIpGererSuppressionPointAncrageIPNonReference_ExecTime;

  /**
   *
   * @param connectorId_p
   */
  public PointAncrageIpProxy(String connectorId_p)
  {
    _connectorId = connectorId_p;

    _avg_pointAncrageIpGererImport_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_pointAncrageIpGererImport_call_counter", "RESProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_pointAncrageIpGererImport_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_pointAncrageIpGererImport_ExecTime", "RESProxy"); //$NON-NLS-1$ //$NON-NLS-2$

    _avg_pointAncrageIpGererSuppressionPointAncrageIPNonReference_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_pointAncrageIpGererSuppressionPointAncrageIPNonReference_call_counter", "RESProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_pointAncrageIpGererSuppressionPointAncrageIPNonReference_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_pointAncrageIpGererSuppressionPointAncrageIPNonReference_ExecTime", "RESProxy"); //$NON-NLS-1$ //$NON-NLS-2$
  }

  public ConnectorResponse<Retour, Nothing> pointAncrageIpGererImport(Tracabilite tracabilite_p, PointAncrageIP pointAncrageIP_p) throws RavelException
  {
    IRESConnector resConnector = null;
    try
    {
      resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
    }
    catch (Exception e_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
    }
    _avg_pointAncrageIpGererImport_call_counter.measure();
    long startTime = System.currentTimeMillis();
    try
    {
      return resConnector.pointAncrageIpGererImport(tracabilite_p, pointAncrageIP_p);
    }
    finally
    {
      long endTime = System.currentTimeMillis();
      _avg_pointAncrageIpGererImport_ExecTime.updateAvgValue(endTime - startTime);
    }
  }

  public ConnectorResponse<Retour, Set<CompteRenduSuppression>> pointAncrageIpGererSuppressionPointAncrageIPNonReference(Tracabilite tracabilite_p, Set<String> listeNomPointAncrageIP_p, String typePointAncrageIP_p) throws RavelException
  {
    IRESConnector resConnector = null;
    try
    {
      resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
    }
    catch (Exception e_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
    }
    _avg_pointAncrageIpGererSuppressionPointAncrageIPNonReference_call_counter.measure();
    long startTime = System.currentTimeMillis();
    try
    {
      return resConnector.pointAncrageIpGererSuppressionPointAncrageIPNonReference(tracabilite_p, listeNomPointAncrageIP_p, typePointAncrageIP_p);
    }
    finally
    {
      long endTime = System.currentTimeMillis();
      _avg_pointAncrageIpGererSuppressionPointAncrageIPNonReference_ExecTime.updateAvgValue(endTime - startTime);
    }
  }
}
