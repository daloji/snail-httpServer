/*******************************************************************************
* $Id: RES2111_AjouterListePrevisions.java 249 2017-07-18 14:23:39Z pcarreir $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.res.activities;

import java.util.ArrayList;
import java.util.List;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.log.event.SystemLogEvent;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.IActivityCaller;
import com.bytel.ravel.services.process.activity.BuiltActivityContext;
import com.bytel.spirit.common.connectors.res.Messages;
import com.bytel.spirit.common.connectors.res.RESProxy;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.Prevision;
import com.bytel.spirit.common.shared.saab.res.request.ListePrevisionRequest;

/**
 *
 * @author pcarreir
 * @version ($Revision: 249 $ $Date: 2017-07-18 16:23:39 +0200 (mar., 18 juil. 2017) $)
 */
public class RES2111_AjouterListePrevisions extends BuiltActivityContext<Retour>
{
  /**
   *
   * @author pcarreir
   * @version ($Revision: 249 $ $Date: 2017-07-18 16:23:39 +0200 (mar., 18 juil. 2017) $)
   */
  public static class RES2111_AjouterListePrevisionsBuilder
  {
    /**
     * Object to build
     */
    RES2111_AjouterListePrevisions _toBuild = new RES2111_AjouterListePrevisions();

    /**
     * Constructor
     */
    public RES2111_AjouterListePrevisionsBuilder()
    {
      _toBuild = new RES2111_AjouterListePrevisions();
    }

    /**
     * @return RR020_BL011_AjouterListePrevisions
     */
    public RES2111_AjouterListePrevisions build()
    {
      if ((_toBuild.getTracabilite() == null) || (_toBuild.getListePrevisions() == null))
      {
        // PARAMETRE INVALIDE
        Retour retour = new Retour();
        retour.setResultat(StringConstants.NOK);
        retour.setCategorie(IMegConsts.CAT3);
        retour.setDiagnostic(IMegSpiritConsts.DONNEE_INVALIDE);
        retour.setLibelle("Parametre d'entree de l'activite non renseignee"); //$NON-NLS-1$
        _toBuild.setRetour(retour);
      }
      return _toBuild;
    }

    /**
     * @param listePrevisions_p
     *          The previsions list
     * @return RR020_BL011_AjouterListePrevisionsBuilder
     */
    public RES2111_AjouterListePrevisionsBuilder listePrevisions(List<Prevision> listePrevisions_p)
    {
      _toBuild.setListePrevisions(listePrevisions_p);
      return this;
    }

    /**
     * @param tracabilite_p
     *          The tracability
     * @return RR020_BL011_AjouterListePrevisionsBuilder
     */
    public RES2111_AjouterListePrevisionsBuilder tracabilite(Tracabilite tracabilite_p)
    {
      _toBuild.setTracabilite(tracabilite_p);
      return this;
    }
  }

  /**
   *
   * @author pcarreir
   * @version ($Revision: 249 $ $Date: 2017-07-18 16:23:39 +0200 (mar., 18 juil. 2017) $)
   */
  private enum Step
  {
    /**
     * First step to execute
     */
    First,

    /**
     * If all steps have been executed
     */
    End
  }

  /**
   *
   */
  private static final String RETOUR = "Retour"; //$NON-NLS-1$
  /**
   *
   */
  private static final String LISTE_PREVISIONS = "listePrevisions"; //$NON-NLS-1$

  /**
   * The serial version UID
   */
  private static final long serialVersionUID = 5486320480133447874L;

  /**
   * The tracability
   */
  private Tracabilite _tracabilite = null;

  /**
   * The previsions list
   */
  private List<Prevision> _listePrevisions = null;

  /**
   * The current execution step
   */
  private Step _currentStep = Step.First;

  @Override
  public Retour executeNextStep(IActivityCaller arg0_p) throws RavelException
  {
    Retour result = null;
    switch (_currentStep)
    {
      case First:
        result = ajouterListePrevisions();

        _currentStep = Step.End;
        break;
      default:
        break;
    }
    return result;
  }

  /**
   * @return List<Previsions>
   */
  public List<Prevision> getListePrevisions()
  {
    return _listePrevisions == null ? new ArrayList<>() : new ArrayList<>(_listePrevisions);
  }

  /**
   * @return Tracability
   */
  public Tracabilite getTracabilite()
  {
    return _tracabilite;
  }

  @Override
  public boolean isEndStep()
  {
    return Step.End.equals(_currentStep);
  }

  /**
   * @param listePrevisions_p
   *          The previsions list
   */
  public void setListePrevisions(List<Prevision> listePrevisions_p)
  {
    _listePrevisions = new ArrayList<>(listePrevisions_p);
  }

  /**
   * @param tracabilite_p
   *          The tracability
   */
  public void setTracabilite(Tracabilite tracabilite_p)
  {
    _tracabilite = tracabilite_p;
  }

  /**
   * @return Retour
   * @throws RavelException
   *           RavelException
   */
  private Retour ajouterListePrevisions() throws RavelException
  {
    SystemLogEvent system = new SystemLogEvent(LogSeverity.DEBUG, _tracabilite.getIdCorrelationSpirit(), Messages.getString("res.RES2111_AjouterListePrevisions")); //$NON-NLS-1$
    Retour result;
    ListePrevisionRequest listePrevision = new ListePrevisionRequest(_listePrevisions);
    system.addField(LISTE_PREVISIONS, GsonTools.getIso8601Ms().toJson(listePrevision), false);
    RavelLogger.log(system);
    ConnectorResponse<Retour, Boolean> response = RESProxy.getInstance().pad3002PrevisionProgCreate(_tracabilite, listePrevision);
    result = response._first;
    this.setRetour(result);
    system = new SystemLogEvent(LogSeverity.DEBUG, _tracabilite.getIdCorrelationSpirit(), Messages.getString("res.RES2111_AjouterListePrevisions")); //$NON-NLS-1$
    system.addField(RETOUR, result, false);
    RavelLogger.log(system);
    return result;
  }

}
