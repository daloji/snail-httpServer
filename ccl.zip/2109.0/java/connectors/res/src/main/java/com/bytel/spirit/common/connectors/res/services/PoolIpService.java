/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.res.services;

import java.text.MessageFormat;
import java.util.HashMap;

import javax.ws.rs.HttpMethod;
import javax.ws.rs.core.Response;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.json.IRavelJson;
import com.bytel.ravel.common.json.RavelJson;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.connector.RESTRequest;
import com.bytel.spirit.common.connectors.res.IRESConnector;
import com.bytel.spirit.common.connectors.res.RESConnector;
import com.bytel.spirit.common.shared.misc.connectors.AbstractInternalRESTConnector;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.BasicResponse;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.ressources.RetourConverter;
import com.bytel.spirit.common.shared.misc.ressources.SpiritConstants;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.PoolIP;
import com.bytel.spirit.common.shared.saab.res.request.ManagePoolIPRequest;

/**
 * @author acorreia
 * @version ($Revision$ $Date$)
 */
public class PoolIpService
{
  interface IMethodNames
  {
    String GERER_IMPORT = "poolIpGererImport"; //$NON-NLS-1$
  }

  private final IRavelJson _jsonBuilder;

  private final RESConnector _resInstance;

  /**
   * @param resInstance_p
   *          {@link RESConnector}
   */
  public PoolIpService(RESConnector resInstance_p)
  {
    _resInstance = resInstance_p;
    _jsonBuilder = new RavelJson.RavelJsonBuilder().profil(SpiritConstants.JSON_PROFILE_STARK).build();
  }

  /**
   * The method used to import a {@link PoolIP} into the DB.
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param poolIpUrl_p
   *          the url to the corresponding endpoint in SAAB.
   * @param poolIP_p
   *          the object being written.
   * @return a {@link ConnectorResponse} with the {@link Retour}.
   */
  public ConnectorResponse<Retour, Nothing> poolIpGererImport(Tracabilite tracabilite_p, String poolIpUrl_p, PoolIP poolIP_p)
  {
    try
    {
      if (StringTools.isNullOrEmpty(poolIpUrl_p))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(IRESConnector.MESSAGE_MISSING_CONFIGURATION_PARAMETER, IRESConnector.PAD3207_POOL_IP_PATH_PARAM));
      }

      // Query parameters
      HashMap<String, String> queryParams = new HashMap<>();
      queryParams.put(IRESConnector.PARAM_ACTION, IRESConnector.ACTION_GERER_IMPORT);

      // Call SAAB
      final Response response;
      ManagePoolIPRequest managePoolIPRequest = new ManagePoolIPRequest(poolIP_p);

      try
      {
        RESTRequest restRequest = new RESTRequest.RESTRequestBuilder() //
            .httpMethod(HttpMethod.PUT) //
            .traceability(tracabilite_p) //
            .method(IMethodNames.GERER_IMPORT) //
            .headers(AbstractInternalRESTConnector.getSpiritStarkRequestHeader()) //
            .path(poolIpUrl_p) //
            .queryParameter(queryParams) //
            .request(managePoolIPRequest) //
            .serializer(_jsonBuilder) //
            .build();

        response = _resInstance.sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        // Retour NOK
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the object in the response
      BasicResponse responseObject = _resInstance.getContentFromResponse(tracabilite_p, response, IMethodNames.GERER_IMPORT, BasicResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(responseObject.getRetour());
      return new ConnectorResponse<>(retour, null);
    }
    catch (Exception e_p)
    {
      // Retour NOK
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }
}
