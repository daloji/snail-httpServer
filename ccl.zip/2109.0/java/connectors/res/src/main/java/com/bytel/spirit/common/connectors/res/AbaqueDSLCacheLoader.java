/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.res;

import java.text.MessageFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections4.CollectionUtils;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.cache.BasicCache;
import com.bytel.ravel.common.cache.ICache;
import com.bytel.ravel.common.cache.ICacheLoader;
import com.bytel.ravel.common.datetime.DateTimeManager;
import com.bytel.ravel.common.exception.ExceptionTools;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.services.connector.ConnectorManager;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.AbaqueDSL;

/**
 * @author jpais
 * @version ($Revision$ $Date$)
 */
public class AbaqueDSLCacheLoader implements ICacheLoader
{
  /**
   * CacheId to store in and retrieve from cache manager
   */
  private static final String _cacheId = "abaque_dsl"; //$NON-NLS-1$

  /**
   * Tracabilite to call the RES connector
   */
  private Tracabilite _tracabilite;

  /**
   * Duration Of Cache In Hours.
   */
  private Duration _durationOfCache;

  /**
   * retour
   */
  private Retour _retour;

  /**
   * @param tracabilite_p
   *          the tracabilite
   * @param durationOfCache_p
   *          duration of cache in hours
   */
  public AbaqueDSLCacheLoader(Tracabilite tracabilite_p, Duration durationOfCache_p)
  {
    super();
    _tracabilite = tracabilite_p;
    _durationOfCache = durationOfCache_p;
  }

  @Override
  public String getCacheId()
  {
    return _cacheId;
  }

  /**
   * @return the retour
   */
  public Retour getRetour()
  {
    return _retour;
  }

  @Override
  public ICache<?> initializeCache()
  {
    return new BasicCache<>();
  }

  @Override
  public void loadCache(ICache<?> cache_p)
  {
    @SuppressWarnings("unchecked")
    BasicCache<List<AbaqueDSL>> cache = (BasicCache<List<AbaqueDSL>>) cache_p;

    try
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.INFO, _tracabilite, "AbaqueDSLCacheLoader - Load Cache Start")); //$NON-NLS-1$

      RESConnector resConnector = (RESConnector) ConnectorManager.getInstance().getConnector(IRESConnector.BEAN_ID);

      // Call RES.loadAbaqueDslLireTous
      ConnectorResponse<Retour, List<AbaqueDSL>> loadAbaqueDslLireTousResponse = resConnector.loadAbaqueDslLireTous(_tracabilite);
      List<AbaqueDSL> abaqueDslList = loadAbaqueDslLireTousResponse._second;

      //Write the list of AccesTechnique in the cache
      //(key = {AbaqueDSL key} , value = List<AbaqueDSL>)
      if (CollectionUtils.isNotEmpty(abaqueDslList))
      {
        List<AbaqueDSL> abaqueDslListToWrite = null;
        String lastKey = null;
        String currentKey = null;

        for (AbaqueDSL abaqueDSL : abaqueDslList)
        {
          // Get current Abaque Key
          currentKey = abaqueDSL.getKey();

          if (!currentKey.equals(lastKey))
          {
            // Write to cache
            if (abaqueDslListToWrite != null)
            {
              cache.write(lastKey, abaqueDslListToWrite);
            }

            // Clear write list
            abaqueDslListToWrite = new ArrayList<>();

            // Update key
            lastKey = currentKey;
          }

          // Add current Abaque to the write list
          abaqueDslListToWrite.add(abaqueDSL);
        }

        // Write to cache
        if (abaqueDslListToWrite != null)
        {
          cache.write(currentKey, abaqueDslListToWrite);
        }
      }
      else
      {
        Retour retour = loadAbaqueDslLireTousResponse._first;

        String message = MessageFormat.format(Messages.getString("AbaqueDSLCacheLoader.ListeAbaqueslNull"), retour.getResultat(), retour.getCategorie(), retour.getDiagnostic(), retour.getLibelle()); //$NON-NLS-1$
        RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, _tracabilite, message));
      }

      this.setRetour(loadAbaqueDslLireTousResponse._first);
      RavelLogger.log(new SpiritLogEvent(LogSeverity.INFO, _tracabilite, "AbaqueDSLCacheLoader - Load Cache End")); //$NON-NLS-1$
    }
    catch (RavelException exception)
    {
      String message = MessageFormat.format(Messages.getString("AbaqueDSLCacheLoader.TechnicalExceptionMessage"), "loadCache", exception.getErrorCode(), exception.getMessage()); //$NON-NLS-1$ //$NON-NLS-2$
      // add fileName and line number of the exception
      message += ExceptionTools.getExceptionLineAndFile(exception);
      this.setRetour(RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.LECTURE_INDISPONIBLE, message));
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, _tracabilite, message));
    }
  }

  /**
   * @param retour_p
   *          the retour to set
   */
  public void setRetour(Retour retour_p)
  {
    _retour = retour_p;
  }

  @Override
  public boolean validateCache(ICache<?> cache_p)
  {
    if (!cache_p.isEmpty() && (cache_p.getDateOfCache() != null))
    {
      Duration durationSinceDateOfCache = Duration.between(cache_p.getDateOfCache(), DateTimeManager.getInstance().now());

      return (durationSinceDateOfCache.compareTo(_durationOfCache) < 0);
    }
    return false;
  }
}
