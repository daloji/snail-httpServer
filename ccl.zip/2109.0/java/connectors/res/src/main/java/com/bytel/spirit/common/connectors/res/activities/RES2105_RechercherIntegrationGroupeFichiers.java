/*******************************************************************************
* $Id: RES2105_RechercherIntegrationGroupeFichiers.java 255 2017-07-18 16:27:19Z pcarreir $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.res.activities;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.log.event.SystemLogEvent;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.IActivityCaller;
import com.bytel.ravel.services.process.activity.BuiltActivityContext;
import com.bytel.spirit.common.connectors.res.Messages;
import com.bytel.spirit.common.connectors.res.RESProxy;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.IntegrationGroupeFichiers;
import com.bytel.spirit.common.shared.saab.res.response.IntegrationGroupeFichierResponse;

/**
 *
 * @author pcarreir
 * @version ($Revision: 255 $ $Date: 2017-07-18 18:27:19 +0200 (mar., 18 juil. 2017) $)
 */
public class RES2105_RechercherIntegrationGroupeFichiers extends BuiltActivityContext<IntegrationGroupeFichiers>
{
  /**
   *
   * @author pcarreir
   * @version ($Revision: 255 $ $Date: 2017-07-18 18:27:19 +0200 (mar., 18 juil. 2017) $)
   */
  public static class RES2105_RechercherIntegrationGroupeFichiersBuilder
  {
    /**
     * Object to build
     */
    RES2105_RechercherIntegrationGroupeFichiers _toBuild;

    /**
     * Constructor
     */
    public RES2105_RechercherIntegrationGroupeFichiersBuilder()
    {
      _toBuild = new RES2105_RechercherIntegrationGroupeFichiers();
    }

    /**
     * @return RR0020_BL005_RechercherIntegrationGroupeFichiers
     */
    public RES2105_RechercherIntegrationGroupeFichiers build()
    {
      if ((_toBuild.getTracabilite() == null) || (_toBuild.getNomGroupFichiers() == null))
      {
        // PARAMETRE INVALIDE
        Retour retour = new Retour();
        retour.setResultat(StringConstants.NOK);
        retour.setCategorie(IMegConsts.CAT3);
        retour.setDiagnostic(IMegSpiritConsts.DONNEE_INVALIDE);
        retour.setLibelle("Parametre d'entree de l'activite non renseignee"); //$NON-NLS-1$
        _toBuild.setRetour(retour);
      }
      return _toBuild;
    }

    /**
     * @param nomGroupFichiers_p
     *          The file group name
     * @return RR0020_BL005_RechercherIntegrationGroupeFichiersBuilder
     */
    public RES2105_RechercherIntegrationGroupeFichiersBuilder nomGroupFichiers(String nomGroupFichiers_p)
    {
      _toBuild.setNomGroupFichiers(nomGroupFichiers_p);
      return this;
    }

    /**
     * @param tracabilite_p
     *          The tracability
     * @return RR0020_BL005_RechercherIntegrationGroupeFichiersBuilder
     */
    public RES2105_RechercherIntegrationGroupeFichiersBuilder tracabilite(Tracabilite tracabilite_p)
    {
      _toBuild.setTracabilite(tracabilite_p);
      return this;
    }
  }

  /**
   *
   * @author pcarreir
   * @version ($Revision: 255 $ $Date: 2017-07-18 18:27:19 +0200 (mar., 18 juil. 2017) $)
   */
  private enum Step
  {
    /**
     * First step to execute
     */
    First,

    /**
     * If all steps have been executed
     */
    End
  }

  /**
   *
   */
  private static final String NOM_GROUPE_FICHIER = "NomGroupeFichier"; //$NON-NLS-1$

  /**
   *
   */
  private static final String RETOUR = "Retour"; //$NON-NLS-1$

  /**
   * The serial version UID
   */
  private static final long serialVersionUID = -3875402514497302606L;

  /**
   * The tracability
   */
  private Tracabilite _tracabilite = null;

  /**
   * The current execution step
   */
  private Step _currentStep = Step.First;

  /**
   * The file group name
   */
  private String _nomGroupFichiers;

  @Override
  public IntegrationGroupeFichiers executeNextStep(IActivityCaller arg0_p) throws RavelException
  {
    IntegrationGroupeFichiers result = null;
    Retour retour = RetourFactory.createOkRetour();
    SystemLogEvent system = new SystemLogEvent(LogSeverity.DEBUG, _tracabilite.getIdCorrelationSpirit(), Messages.getString("res.RES2105_RechercherIntegrationGroupeFichiers")); //$NON-NLS-1$
    system.addField(NOM_GROUPE_FICHIER, _nomGroupFichiers, false);
    RavelLogger.log(system);
    switch (_currentStep)
    {
      case First:
        ConnectorResponse<Retour, IntegrationGroupeFichierResponse> fichierRes = RESProxy.getInstance().pad3003IntegrationGroupeFichierRead(_tracabilite, _nomGroupFichiers);
        if (RetourFactory.isRetourOK(fichierRes._first))
        {
          result = fichierRes._second.getIntegration();
        }
        retour = fichierRes._first;

        this.setRetour(retour);

        _currentStep = Step.End;
        break;
      default:
        break;
    }
    system = new SystemLogEvent(LogSeverity.DEBUG, _tracabilite.getIdCorrelationSpirit(), Messages.getString("res.RES2105_RechercherIntegrationGroupeFichiers")); //$NON-NLS-1$
    system.addField(RETOUR, retour, false);
    RavelLogger.log(system);
    return result;
  }

  @Override
  public boolean isEndStep()
  {
    return Step.End.equals(_currentStep);
  }

  /**
   * @return String
   */
  protected String getNomGroupFichiers()
  {
    return _nomGroupFichiers;
  }

  /**
   * @return Tracability
   */
  protected Tracabilite getTracabilite()
  {
    return _tracabilite;
  }

  /**
   * @param nomGroupFichiers_p
   *          The file group name
   */
  protected void setNomGroupFichiers(String nomGroupFichiers_p)
  {
    _nomGroupFichiers = nomGroupFichiers_p;
  }

  /**
   * @param tracabilite_p
   *          The tracability
   */
  protected void setTracabilite(Tracabilite tracabilite_p)
  {
    _tracabilite = tracabilite_p;
  }

}
