/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.res.services;

import java.util.Set;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.probes.AvgDoubleCollectorItem;
import com.bytel.ravel.common.probes.AvgFlowPerSecondCollector;
import com.bytel.ravel.common.probes.RavelProbeConfigurationManager;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.services.connector.ConnectorManager;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.connectors.res.IRESConnector;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.CompteRenduSuppression;
import com.bytel.spirit.common.shared.saab.res.PorteDeCollecte;

/**
 * @author rafcosta
 * @version ($Revision$ $Date$)
 */
public class PorteDeCollecteProxy
{
  /** The connector instance */
  private final String _connectorId;

  /** For probe to count the amount of call to the porteDeCollecteLireUn operation */
  AvgFlowPerSecondCollector _porteDeCollecteLireUn_avgCallCounterSecond;

  /** For probe to count the execution time of call to the porteDeCollecteLireUn operation */
  AvgDoubleCollectorItem _porteDeCollecteLireUn_avgExecTime;

  /** For the probe to count the average amount of calls made to the gererImport operation. */
  AvgFlowPerSecondCollector _porteDeCollecteGererImport_avgCallCounterSecond;

  /** For the probe to count the average amount of calls made to the gererImport operation. */
  AvgDoubleCollectorItem _porteDeCollecteGererImport_avgExecTime;

  /**
   * For the probe to count the average amount of calls made to the gererSuppressionPorteDeCollecteNonReference operation.
   */
  AvgFlowPerSecondCollector _porteDeCollecteGererSuppresion_avgCallCounterSecond;

  /**
   * For the probe to count the average amount of calls made to the gererSuppressionPorteDeCollecteNonReference operation.
   */
  AvgDoubleCollectorItem _porteDeCollecteGererSuppresion_avgExecTime;

  /**
   * @param connectorId_p
   *          connectorId
   */
  public PorteDeCollecteProxy(String connectorId_p)
  {
    _connectorId = connectorId_p;

    _porteDeCollecteLireUn_avgCallCounterSecond = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_porteDeCollecteLireUn_Read_call_counter", "RESProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _porteDeCollecteLireUn_avgExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_porteDeCollecteLireUn_Read_ExecTime", "RESProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _porteDeCollecteGererImport_avgCallCounterSecond = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("porteDeCollecteGererImport_avgCallCounterSecond", "RESProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _porteDeCollecteGererImport_avgExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("porteDeCollecteGererImport_avgExecTime", "RESProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _porteDeCollecteGererSuppresion_avgCallCounterSecond = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("porteDeCollecteGererSuppresion_avgCallCounterSecond", "RESProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _porteDeCollecteGererSuppresion_avgExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("porteDeCollecteGererSuppresion_avgExecTime", "RESProxy"); //$NON-NLS-1$ //$NON-NLS-2$
  }

  /**
   * Import a {@link PorteDeCollecte}.
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param porteDeCollecte_p
   *          the {@link PorteDeCollecte} being imported.
   * @return a pair with the retour and a Nothing (because it needs to be a pair).
   * @throws RavelException
   *           on error.
   */
  public ConnectorResponse<Retour, Nothing> gererImport(Tracabilite tracabilite_p, PorteDeCollecte porteDeCollecte_p) throws RavelException
  {
    IRESConnector resConnector;

    try
    {
      resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
    }
    catch (Exception e_p)
    {
      // Retour NOK
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
    }

    _porteDeCollecteGererImport_avgCallCounterSecond.measure();
    long startTime = System.currentTimeMillis();

    try
    {
      return resConnector.porteDeCollecteGererImport(tracabilite_p, porteDeCollecte_p);
    }
    finally
    {
      long endTime = System.currentTimeMillis();
      _porteDeCollecteGererImport_avgExecTime.updateAvgValue(endTime - startTime);
    }
  }

  /**
   * Delete all {@link PorteDeCollecte} whose id is not in the list.
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param setIdNomCollecte_p
   *          the set with the ids being used.
   * @return a pair with the retour and a set with the results of the deletion, for each {@link PorteDeCollecte}.
   * @throws RavelException
   *           on error.
   */
  public ConnectorResponse<Retour, Set<CompteRenduSuppression>> gererSuppressionPorteDeCollecteNonReference(Tracabilite tracabilite_p, Set<String> setIdNomCollecte_p) throws RavelException
  {
    IRESConnector resConnector;

    try
    {
      resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
    }
    catch (Exception e_p)
    {
      // Retour NOK
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
    }

    _porteDeCollecteGererSuppresion_avgCallCounterSecond.measure();
    long startTime = System.currentTimeMillis();

    try
    {
      return resConnector.porteDeCollecteGererSuppressionPorteDeCollecteNonReference(tracabilite_p, setIdNomCollecte_p);
    }
    finally
    {
      long endTime = System.currentTimeMillis();
      _porteDeCollecteGererImport_avgExecTime.updateAvgValue(endTime - startTime);
    }
  }

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param idNomCollecte_p
   *          idNomCollecte
   * @return ConnectorResponse<Retour, PorteDeCollecte>
   * @throws RavelException
   *           ravelException
   */
  public ConnectorResponse<Retour, PorteDeCollecte> porteDeCollecteLireUn(Tracabilite tracabilite_p, String idNomCollecte_p) throws RavelException
  {
    IRESConnector resConnector;

    try
    {
      resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
    }
    catch (Exception e_p)
    {
      // Retour NOK
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
    }

    _porteDeCollecteLireUn_avgCallCounterSecond.measure();
    long startTime = System.currentTimeMillis();

    try
    {
      return resConnector.porteDeCollecteLireUn(tracabilite_p, idNomCollecte_p);
    }
    finally
    {
      long endTime = System.currentTimeMillis();
      _porteDeCollecteLireUn_avgExecTime.updateAvgValue(endTime - startTime);
    }
  }
}
