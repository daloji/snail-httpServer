/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.res;

import com.bytel.ravel.services.connector.IConnector;

/**
 * @author dangelis
 * @version ($Revision$ $Date$)
 */
public interface IRESConnector extends IConnector, IRES
{
  /** The id to retrieve the connector. */
  String BEAN_ID = "RESConnector"; //$NON-NLS-1$

  /** Parameter Action */
  String PARAM_ACTION = "action"; //$NON-NLS-1$

  /** Parameter typeFluxImport */
  String PARAM_TYPE_FLUX_IMPORT = "typeFluxImport"; //$NON-NLS-1$

  String ACTION_GERER_IMPORT = "GererImport"; //$NON-NLS-1$

  String ACTION_GERER_SUPPRESSION_PM_NON_REFERENCE = "GererSuppressionPmNonReference"; //$NON-NLS-1$

  /** */
  String ACTION_GERER_ALLOCATION_SESSION_FQDN = "GererAllocationSessionFqdn"; //$NON-NLS-1$
  /** */
  String PAR_TAUX_OCCUPATION = "ParTauxOccupation"; //$NON-NLS-1$

  /** Parameter Action referencePmBytel */
  String REFERENCE_PM_BYTEL = "referencePmBytel"; //$NON-NLS-1$

  /** Parameter Action referencePmOi */
  String REFERENCE_PM_OI = "referencePmOi"; //$NON-NLS-1$

  /** Parameter Action statutBlocage */
  String STATUT_BLOCAGE = "statutBlocage"; //$NON-NLS-1$

  /** Parameter Action referenceBoitierPm */
  String REFERENCE_BOITIER_PM = "referenceBoitierPm"; //$NON-NLS-1$

  /** Parameter Action commentaireBlocage */
  String COMMENTAIRE_BLOCAGE = "commentaireBlocage"; //$NON-NLS-1$

  /** Parameter Action nomPanneau */
  String NOM_PANNEAU = "nomPanneau"; //$NON-NLS-1$

  /** Parameter Action positionPortPM */
  String POSITION_PORT_PM = "positionPortPM"; //$NON-NLS-1$

  /** Parameter Action statutExploitation */
  String STATUT_EXPLOITATION = "statutExploitation"; //$NON-NLS-1$

  /** Parameter Action commentaireExploitation */
  String COMMENTAIRE_EXPLOITATION = "commentaireExploitation"; //$NON-NLS-1$

  /** Parameter GererSuppressionNrNonReference */
  String GERER_SUPPRESSION = "GererSuppressionNrNonReference"; //$NON-NLS-1$

  /** Parameter codeInsee */
  String PARAM_CODE_INSEE = "codeInsee"; //$NON-NLS-1$
  /** Parameter idAdresseBytel */
  String PARAM_ID_ADRESSE_BYTEL = "idAdresseBytel"; //$NON-NLS-1$
  /** Parameter idAdresseBytel */
  String PARAM_TYPE_COUVERTURE_5G = "typeCouverture5G"; //$NON-NLS-1$
  /** Parameter idNomCollecte */
  String PARAM_ID_NOM_COLLECTE = "idNomCollecte"; //$NON-NLS-1$
  /** Parameter idEqptAcces */
  String PARAM_ID_EQPT_ACCES = "idEqptAcces";//$NON-NLS-1$
  /** Parameter idRessource */
  String PARAM_ID_RESSOURCE = "idRessource"; //$NON-NLS-1$
  /** Parameter idRessource */
  String PARAM_ID_RESSOURCE_LIE = "idRessourceLie"; //$NON-NLS-1$
  /** Parameter idRRCible */
  String PARAM_ID_RR_CIBLE = "idRRCible"; //$NON-NLS-1$
  /** Parameter idSource */
  String PARAM_ID_SOURCE = "idSource"; //$NON-NLS-1$
  /** Parameter idSt */
  String PARAM_ID_ST = "idSt"; //$NON-NLS-1$
  /** Parameter numeroComplement */
  String PARAM_NUMERO_COMPLEMENT = "numeroComplement"; //$NON-NLS-1$
  /** Parameter codeRivoli */
  String PARAM_RIVOLI = "codeRivoli"; //$NON-NLS-1$
  /** Parameter statut */
  String PARAM_STATUT = "statut"; //$NON-NLS-1$
  /** Parameter filtre */
  String PARAM_FILTRE = "filtre"; //$NON-NLS-1$

  /** Parameter typeReferentiel */
  String PARAM_TYPE_REFERENTIEL = "typeReferentiel"; //$NON-NLS-1$
  /** Parameter nomFQDN */
  String PARAM_NOM_FQDN = "nomFQDN"; //$NON-NLS-1$
  /** Parameter nombreSession */
  String PARAM_NOMBRE_SESSION = "nombreSession"; //$NON-NLS-1$
  /** Parameter imb */
  String PARAM_IMB = "imb"; //$NON-NLS-1$
  /** Parameter hexacleInterne */
  String PARAM_HEXACLE_INTERNE = "hexacleInterne"; //$NON-NLS-1$
  /** Parameter referencePM */
  String PARAM_REFERENCE_PM = "referencePM"; //$NON-NLS-1$
  /** Parameter codePostal */
  String PARAM_CODE_POSTAL = "codePostal"; //$NON-NLS-1$
  /** Parameter ancienCodeInsee */
  String PARAM_ANCIEN_CODE_INSEE = "ancienCodeInsee"; //$NON-NLS-1$
  /** Parameter nomProgramme */
  String PARAM_NOM_PROGRAMME = "nomProgramme"; //$NON-NLS-1$
  /** Parameter nomGroupeFichier */
  String PARAM_NOM_GROUPE_FICHIER = "nomGroupeFichier"; //$NON-NLS-1$
  /** Parameter nomOLT */
  String PARAM_NOM_OLT = "nomOLT"; //$NON-NLS-1$
  /** Parameter positionCarte */
  String PARAM_POSITION_CARTE = "positionCarte"; //$NON-NLS-1$
  /** Parameter versionInterfaceEchange */
  String PARAM_VERSION_INTERFACE_ECHANGE = "versionInterfaceEchange"; //$NON-NLS-1$
  /** Parameter debitGarantieCapaciteAllouee */
  String PARAM_DEBIT_GARANTI_ALLOUE = "debitGarantieCapaciteAllouee"; //$NON-NLS-1$
  /** Parameter positionCarte */
  String PARAM_POSITION_PORT_PON = "positionPortPon"; //$NON-NLS-1$
  /** Parameter positionCarte */
  String PARAM_POSITION_ONT_ID = "positionOntId"; //$NON-NLS-1$
  /** Parameter typeRessourceAggrege */
  String PARAM_TYPE_RESSOURCE_AGGREGE = "typeRessourceAggrege"; //$NON-NLS-1$
  /** Parameter idCleCompose */
  String PARAM_ID_CLE_COMPOSE = "idCleCompose"; //$NON-NLS-1$
  /** Parameter typeCle */
  String PARAM_TYPE_CLE = "typeCle"; //$NON-NLS-1$
  /** Parameter techno */
  String PARAM_TECHNO = "techno"; //$NON-NLS-1$
  /** Parameter operateur */
  String PARAM_OPERATEUR = "operateur"; //$NON-NLS-1$
  /** Parameter operation */
  String PARAM_OPERATION = "operation"; //$NON-NLS-1$
  /** Parameter nro */
  String PARAM_NRO = "nro"; //$NON-NLS-1$
  /** Parameter nomURAOrange */
  String PARAM_NOM_URA_ORANGE = "nomURAOrange"; //$NON-NLS-1$
  /** Parameter nbPaire */
  String PARAM_NB_PAIRE = "nbPaire"; //$NON-NLS-1$
  /** Parameter typeKP */
  String PARAM_TYPE_KP = "typeKP"; //$NON-NLS-1$
  /** Parameter departement */
  String PARAM_DEPARTEMENT = "departement"; //$NON-NLS-1$
  /** Parameter similiHexacle0 */
  String PARAM_SIMILI_HEXACLE_0 = "similiHexacle0"; //$NON-NLS-1$

  /** The constant for message WrongConfigurationParameter */
  String MESSAGE_WRONG_CONFIGURATION_PARAMETER = Messages.getString("RESConnector.WrongConfigurationParameter"); //$NON-NLS-1$
  /** The constant for message MissingConfigurationParameter */
  String MESSAGE_MISSING_CONFIGURATION_PARAMETER = Messages.getString("RESConnector.MissingConfigurationParameter"); //$NON-NLS-1$
  /** The constant for message Impossible de récupérer la réponse constant */
  String MESSAGE_JSON_ERROR_MESSAGE = Messages.getString("RESConnector.JsonErrorMessage"); //$NON-NLS-1$
  /** The constant for message ServicesComCache constant */
  String MESSAGE_SERVICES_COM_CACHE = Messages.getString("ServicesComCacheLoader.ServicesComCache"); //$NON-NLS-1$

  /** Param name for PAD3127 */
  String PAD3127_PATH_PARAM = "RESSOURCE_PORT_PM_PATH"; //$NON-NLS-1$
  /** Param name for PAD3001 */
  String PAD3001_PATH_PARAM = "COMMUNE_PATH"; //$NON-NLS-1$
  /** Param name for PAD3002 */
  String PAD3002_PATH_PARAM = "PREVISION_PROG_PATH"; //$NON-NLS-1$
  /** Param name for PAD3003 */
  String PAD3003_PATH_PARAM = "INTEGRATION_GROUPE_FICHIER_PATH"; //$NON-NLS-1$
  /** Param name for PAD3013 */
  String PAD3013_PATH_PARAM = "TOPOLOGIE_ARCTURUS_PATH"; //$NON-NLS-1$
  /** Param name for PAD3100 */
  String PAD3100_PATH_PARAM = "RESSOURCE_PATH"; //$NON-NLS-1$
  /** Param name for PAD3101 */
  String PAD3101_PATH_PARAM = "RESSOURCE_RESEAU_COMPOSITE_PATH"; //$NON-NLS-1$
  /** Param name for PAD3110 */
  String PAD3110_PATH_PARAM = "RESSOURCE_RACCORDEMENT_PATH"; //$NON-NLS-1$
  /** Param name for PAD3111 */
  String PAD3111_PATH_PARAM = "RESSOURCE_RACCORDEMENT_COMPOSITE_PATH"; //$NON-NLS-1$
  /** aram name for PAD3111 (manage) */
  String PAD3111_MANAGE_PATH_PARAM = "MANAGE_RESSOURCE_RACCORDEMENT_COMPOSITE_PATH"; //$NON-NLS-1$
  /** Param name for PAD3200 */
  String PAD3200_PATH_PARAM = "OLT_COMPOSITE_PATH"; //$NON-NLS-1$

  // TODO: PAD???? Quel numéro ?
  /** */
  String PAD_RAIC_PATH_PARAM = "RESSOURCE_ADRESSE_IP_CLF_PATH"; //$NON-NLS-1$
  /** */
  String PAD_RIF_PATH_PARAM = "RESSOURCE_IMPI_FIXE_PATH"; //$NON-NLS-1$
  /** */
  String PAD_RCI_PATH_PARAM = "RESSOURCE_COMPTE_IMS_PATH"; //$NON-NLS-1$
  /** */
  String PAD_RM2PI_PATH_PARAM = "RESSOURCE_MOTDEPASSE_IMS_PATH"; //$NON-NLS-1$
  /** */
  String PAD_ROI_PATH_PARAM = "RESSOURCE_ONT_ID_PATH"; //$NON-NLS-1$

  /** Param name for PAD3120 */
  String PAD3120_PATH_PARAM = "RESSOURCE_COMPTE_MAIL_PATH"; //$NON-NLS-1$
  /** Param name for PAD3004 */
  String PAD3004_PATH_PARAM = "ACCES_TECHNIQUE_PATH"; //$NON-NLS-1$
  /** Param name for PAD3005 */
  String PAD3005_PATH_PARAM = "GESTION_REFERENTIEL_PATH"; //$NON-NLS-1$
  /** Param name for PAD3006 */
  String PAD3006_PATH_PARAM = "FICHIER_REFERENTIEL_COMPOSITE_PATH"; //$NON-NLS-1$
  /** Param name for PAD3007 */
  String PAD3007_PATH_PARAM = "COUVERTURE_CUIVRE_PATH"; //$NON-NLS-1$
  /** Param name for PAD3008 */
  String PAD3008_PATH_PARAM = "COUVERTURE_FTTO_PATH"; //$NON-NLS-1$
  /** Param name for PAD3009 */
  String PAD3009_PATH_PARAM = "COUVERTURE_TOKYO_PATH"; //$NON-NLS-1$
  /** Param name for PAD3010 */
  String PAD3010_PATH_PARAM = "COUVERTURE_FTTH_PATH"; //$NON-NLS-1$
  /** Param name for PAD3011 */
  String PAD3011_PATH_PARAM = "RESSOURCE_FTTH_PATH"; //$NON-NLS-1$
  /** Param name for PAD3012 */
  String PAD3012_PATH_PARAM = "STRUCTURE_VERTICALE_FTTH_COMPOSITE_PATH"; //$NON-NLS-1$
  /** Param name for PAD3012 recherche */
  String PAD3012_RECHERCHE_PATH_PARAM = "STRUCTURE_VERTICALE_FTTH_COMPOSITE_RECHERCHE_PATH"; //$NON-NLS-1$

  /** Param name for PAD3124 */
  String PAD3124_PATH_PARAM = "RESSOURCE_PORT_P2P_PATH"; //$NON-NLS-1$
  /** Param name for PAD3202 */
  String PAD3202_PATH_PARAM = "FQDN_PATH"; //$NON-NLS-1$
  /** Param name for PAD3203 */
  String PAD3203_PATH_PARAM = "OLT_FILTRE_PATH"; //$NON-NLS-1$
  /** Param name for PAD3300 */
  String PAD3300_PATH_PARAM = "CACHE_ELIG_PATH"; //$NON-NLS-1$
  /** Param name for PAD3014 */
  String PAD3014_PATH_PARAM = "DISPO_NRO_FTTE_ORG_PATH"; //$NON-NLS-1$
  /** Param name for PAD3015 */
  String PAD3015_PATH_PARAM = "COUVERTURE_5G_PATH"; //$NON-NLS-1$
  /** Param name for PAD30146 */
  String PAD3016_PATH_PARAM = "ABAQUE_DSL_PATH"; //$NON-NLS-1$
  /** Param name for PAD3017 */
  String PAD3017_PATH_PARAM = "DISPO_RESSOURCE_DSL_ORANGE_PATH"; //$NON-NLS-1$
  /** Param name for PAD3018 */
  String PAD3018_PATH_PARAM = "DISPO_RESSOURCE_DSL_BOUYGUES_PATH"; //$NON-NLS-1$
  /** Param name for PAD3019 */
  String PAD3019_PATH_PARAM = "DISPO_RESSOURCE_DSL_AXIONE_PATH"; //$NON-NLS-1$
  /** Param name for PAD3020 */
  String PAD3020_PATH_PARAM = "DISPO_RESSOURCE_DSL_SFR_PATH"; //$NON-NLS-1$
  /** Param name for PAD3021 */
  String PAD3021_PATH_PARAM = "ENTONNOIR_COMMUNE_PATH"; //$NON-NLS-1$
  /** Param name for PAD3022 */
  String PAD3022_PATH_PARAM = "ENTONNOIR_VOIE_PATH"; //$NON-NLS-1$
  /** Param name for PAD3023 */
  String PAD3023_PATH_PARAM = "ENTONNOIR_NUMERO_PATH"; //$NON-NLS-1$
  /** Param name for PAD3024 */
  String PAD3024_PATH_PARAM = "COUV_GEO_CODAGE_PATH"; //$NON-NLS-1$
  /** Param name for PAD3204 */
  String PAD3204_PATH_PARAM = "NOEUD_RACCORDEMENT_PATH"; //$NON-NLS-1$
  /** Param name for PAD3205 */
  String PAD3205_PATH_PARAM = "PM_COMPOSITE_PATH"; //$NON-NLS-1$
  String PAD3207_POOL_IP_PATH_PARAM = "POOL_IP_PATH"; //$NON-NLS-1$
  /** Param name for PAD3206 */
  String PAD3206_POINT_ANCRAGE_IP_PATH_PARAM = "POINT_ANCRAGE_IP_PATH"; //$NON-NLS-1$
  String PORTE_DE_COLLECTE_PATH_PARAM = "PORTE_DE_COLLECTE_PATH"; //$NON-NLS-1$
  /** Param name for CREATE_LONG_TIMEOUT */
  String CREATE_LONG_TIMEOUT_PARAM = "CREATE_LONG_TIMEOUT"; //$NON-NLS-1$
  /** Param name for fichierReferentielLireTous */
  String ACCES_TECHNIQUE_CACHE_DURATION = "AccesTechniqueCacheDuration"; //$NON-NLS-1$
  /** Param name for abaqueDslLireTous */
  String ABAQUE_DSL_CACHE_DURATION = "AbaqueDSLCacheDuration"; //$NON-NLS-1$

  /** The constant for pad3001_Commune_Create service name */
  String METHOD_NAME_PAD3001_CREATE = "pad3001_Commune_Create"; //$NON-NLS-1$
  /** The constant for pad3001_Commune_codeinsee service name */
  String METHOD_NAME_PAD3001_INSEE = "pad3001_Commune_codeinsee"; //$NON-NLS-1$
  /** The constant for pad3001_Commune_AncienCodeInsee service name */
  String METHOD_NAME_PAD3001_ANCIEN_INSEE = "pad3001_Commune_AncienCodeInsee"; //$NON-NLS-1$
  /** The constant for pad3001_Commune_codePostal service name */
  String METHOD_NAME_PAD3001_CODE_POSTAL = "pad3001_Commune_codePostal"; //$NON-NLS-1$

  /** The constant for pad3002_PrevisionProg_Create service name */
  String METHOD_NAME_PAD3002_PREVISION_PROG = "pad3002_PrevisionProg_Create"; //$NON-NLS-1$
  /** The constant for pad3002_PrevisionProg_Read service name */
  String METHOD_NAME_PAD3002_READ = "pad3002_PrevisionProg_Read"; //$NON-NLS-1$

  /** The constant for pad3003_IntegrationGroupeFichier service name */
  String METHOD_NAME_PAD3003_CREATE = "pad3003_IntegrationGroupeFichier"; //$NON-NLS-1$
  /** The constant for pad3003_IntegrationGroupeFichier_Read service name */
  String METHOD_NAME_PAD3003_READ = "pad3003_IntegrationGroupeFichier_Read"; //$NON-NLS-1$
  /** The constant for pad3003_IntegrationGroupeFichier_Update service name */
  String METHOD_NAME_PAD3003_UPDATE = "pad3003_IntegrationGroupeFichier_Update"; //$NON-NLS-1$
  /** The constant for pad3003_IntegrationGroupeFichier_Delete service name */
  String METHOD_NAME_PAD3003_DELETE = "pad3003_IntegrationGroupeFichier_Delete"; //$NON-NLS-1$
  /** The constant for pad3203_Olt_Create service name */
  String METHOD_NAME_PAD3203_CREATE = "pad3203_Olt_Create"; //$NON-NLS-1$

  /** The constant for gestionReferentielGererRestaurationBackup service name */
  String METHOD_NAME_GESTION_REFERENTIEL_GERER_RESTAURATION_BACKUP = "gestionReferentielGererRestaurationBackup"; //$NON-NLS-1$
  /** The constant for gestionReferentielGererBascule service name */
  String METHOD_NAME_GESTION_REFERENTIEL_GERER_BASCULE = "gestionReferentielGererBascule"; //$NON-NLS-1$

  /** The constant for couvertureCuivreLireTousParIdBytel service name */
  String METHOD_NAME_COUVERTURE_CUIVRE_LIRE_TOUS_ID_BYTEL = "couvertureCuivreLireTousParIdBytel"; //$NON-NLS-1$
  /** The constant for couvertureCuivreLireUnParRivoli service name */
  String METHOD_NAME_COUVERTURE_CUIVRE_LIRE_UN_PAR_RIVOLI = "couvertureCuivreLireUnParRivoli"; //$NON-NLS-1$
  /** The constant for couvertureFttoLireUn service name */
  String METHOD_NAME_COUVERTURE_FTTO_LIRE_UN = "couvertureFttoLireUn"; //$NON-NLS-1$
  /** The constant for couvertureTokyoLireUn service name */
  String METHOD_NAME_COUVERTURE_TOKYO_LIRE_UN = "couvertureTokyoLireUn"; //$NON-NLS-1$
  /** The constant for topologieArcturusLire service name */
  String METHOD_NAME_TOPOLOGIE_ARCTURUS_LIRE_UN = "topologieArcturusLireUn"; //$NON-NLS-1$
  /** The constant for topologieArcturusLireTousParIdEqptAcces service name */
  String METHOD_NAME_TOPOLOGIE_ARCTURUS_LIRE_TOUS_PAR_IDEQPTACCES = "topologieArcturusLireTousParIdEqptAcces"; //$NON-NLS-1$

  /** The constant for fichierReferentielLireTous service name */
  String METHOD_NAME_FICHIER_REFERENTIEL_LIRE_TOUS = "fichierReferentielLireTous"; //$NON-NLS-1$
  /** The constant for fichierReferentielGererEchecIntegration service name */
  String METHOD_NAME_FICHIER_REFERENTIEL_GERER_ECHEC_INTEGRATION = "fichierReferentielGererEchecIntegration"; //$NON-NLS-1$

  /** The constant for ressourceLireUn service name */
  String METHOD_NAME_RESSOURCE_LIRE_UN = "ressourceLireUn"; //$NON-NLS-1$
  /** The constant for ressourceRaccordementCompositeLireUn service name */
  String METHOD_NAME_RESSOURCE_RACCORDEMENT_COMPOSITE_LIRE_UN = "ressourceRaccordementCompositeLireUn"; //$NON-NLS-1$
  /** The constant for ressourceCompteImsCreer service name */
  String METHOD_NAME_RESSOURCE_ADRESSE_IP_CLF_CREER = "ressourceAdresseIpClfCreer"; //$NON-NLS-1$
  /** The constant for ressourceCompteImsModifierStatutAllocation service name */
  String METHOD_NAME_RESSOURCE_ADRESSE_IP_CLF_MODIFIER_STATUT = "ressourceAdresseIpClfModifierStatutAllocation"; //$NON-NLS-1$
  /** The constant for ressourceCompteImsCreer service name */
  String METHOD_NAME_RESSOURCE_COMPTE_IMPI_FIXE_CREER = "ressourceCompteImpiFixeCreer"; //$NON-NLS-1$
  /** The constant for ressourceCompteImsModifierStatutAllocation service name */
  String METHOD_NAME_RESSOURCE_COMPTE_IMPI_FIXE_MODIFIER_STATUT = "ressourceCompteImpiFixeModifierStatutAllocation"; //$NON-NLS-1$
  /** The constant for ressourceCompteImsCreer service name */
  String METHOD_NAME_RESSOURCE_COMPTE_IMS_CREER = "ressourceCompteImsCreer"; //$NON-NLS-1$
  /** The constant for ressourceCompteImsModifierStatutAllocation service name */
  String METHOD_NAME_RESSOURCE_COMPTE_IMS_MODIFIER_STATUT = "ressourceCompteImsModifierStatutAllocation"; //$NON-NLS-1$
  /** The constant for ressourceCompteMailCreer service name */
  String METHOD_NAME_RESSOURCE_COMPTE_MAIL_CREER = "ressourceCompteMailCreer"; //$NON-NLS-1$
  /** The constant for ressourceCompteMailModifierStatutAllocation service name */
  String METHOD_NAME_RESSOURCE_COMPTE_MAIL_MODIFIER_STATUT = "ressourceCompteMailModifierStatutAllocation"; //$NON-NLS-1$
  /** The constant for ressourceCompteMailCreer service name */
  String METHOD_NAME_RESSOURCE_MOTDEPASSE_IMS_CREER = "ressourceMotDePasseImsCreer"; //$NON-NLS-1$
  /** The constant for ressourceCompteMailModifierStatutAllocation service name */
  String METHOD_NAME_RESSOURCE_MOTDEPASSE_IMS_MODIFIER_STATUT = "ressourceMotDePasseImsModifierStatutAllocation"; //$NON-NLS-1$
  /** The constant for ressourceOntIdGererLiberation service name */
  String METHOD_NAME_RESSOURCE_ONT_ID_GERER_LIBERATION = "ressourceOntIdGererLiberation"; //$NON-NLS-1$
  /** The constant for ressourceFtthLireTousParReferencePM service name */
  String METHOD_NAME_RESSOURCE_FTTH_LIRE_TOUS_REFERENCE_PM = "ressourceFtthLireTousParReferencePM"; //$NON-NLS-1$

  /** The constant for accesTechniqueLireTous service name */
  String METHOD_NAME_ACCES_TECHNIQUE_LIRE_TOUS = "accesTechniqueLireTous"; //$NON-NLS-1$

  /** The constant for pad3101RessourceAggregeP2PLireUn service name */
  String METHOD_NAME_PAD3101_RESSOURCE_AGGREGE_LIRE_UN = "pad3101RessourceAggregeP2PLireUn"; //$NON-NLS-1$

  /** The constant for fqdnLireUn service name */
  String METHOD_NAME_FQDN_LIRE_UN = "fqdnLireUn"; //$NON-NLS-1$
  /** The constant for fqdnLireUn service name */
  String METHOD_NAME_FQDN_LIRE_UN_PAR_TAUX_OCCUPATION = "FqdnLireUnParTauxOccupation"; //$NON-NLS-1$
  /** The constant for gererAllocationSessionFqdn service name */
  String METHOD_NAME_ALLOCATION_SESSION_FQDN = "gererAllocationSessionFqdn"; //$NON-NLS-1$

  /** The constant for structureVerticaleFtthCompositeCreer service name */
  String METHOD_NAME_STRUCTURE_VERTICALE_FTTH_COMPOSITE_CREER = "structureVerticaleFtthCompositeCreer"; //$NON-NLS-1$
  /** The constant for structureVerticaleFtthCompositeLireTousParListeOIIMB service name */
  String METHOD_NAME_STRUCTURE_VERTICALE_FTTH_COMPOSITE_LIRE_TOUS_LISTE_OI_IMB = "structureVerticaleFtthCompositeLireTousParListeOIIMB"; //$NON-NLS-1$
  /** The constant for pad3300_CacheElig_CreerListe service name */
  String METHOD_NAME_PAD3300_CACHE_ELIG_CREER_LISTE = "cacheEligCreerListe"; //$NON-NLS-1$
  /** The constant for pad3300_CacheElig_Lire service name */
  String METHOD_NAME_PAD3300_CACHE_ELIG_LIRE = "cacheEligLire"; //$NON-NLS-1$

  /** The constant for pad3014_DispoNroFtteOrg service name */
  String METHOD_NAME_PAD3014_DISPO_NRO_FTTE_ORG_LIRE = "dispoNroFtteOrgLire"; //$NON-NLS-1$
}
