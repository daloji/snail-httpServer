/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.res.services;

import java.time.LocalDateTime;
import java.util.HashMap;

import javax.ws.rs.HttpMethod;
import javax.ws.rs.core.Response;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.json.IRavelJson;
import com.bytel.ravel.common.json.RavelJson;
import com.bytel.ravel.common.json.format.impl.IsoShortOffsetDateTimeWithMillis;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.connector.RESTRequest;
import com.bytel.ravel.services.connector.RESTRequest.RESTRequestBuilder;
import com.bytel.spirit.common.connectors.res.RESConnector;
import com.bytel.spirit.common.shared.misc.connectors.AbstractInternalRESTConnector;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.BasicResponse;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.ressources.RetourConverter;
import com.bytel.spirit.common.shared.misc.ressources.SpiritConstants;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.Ressource;

/**
 * Service class implementation for PAD3110
 *
 * @author jpais
 * @version ($Revision$ $Date$)
 */
public class RessourceRaccordementService
{
  public interface IMethodName
  {
    String RESSOURCE_RACCORDEMENT_CREER = "ressourceRaccordementCreer"; //$NON-NLS-1$
    String RESSOURCE_RACCORDEMENT_MODIFIER_STATUT_ALLOCATION = "ressourceRaccordementModifierStatutAllocation"; //$NON-NLS-1$
    String RESSOURCE_RACCORDEMENT_MODIFIER_CODE_ACCES_TECHNIQUE = "ressourceRaccordementModifierCodeAccesTechnique"; //$NON-NLS-1$
    String RESSOURCE_RACCORDEMENT_MODIFIER_ONT_INSTALLE = "ressourceRaccordementModifierOntInstalle"; //$NON-NLS-1$

  }

  public interface IParameter
  {
    String ID_RESSOURCE = "idRessource"; //$NON-NLS-1$
    String ID_ST = "idSt"; //$NON-NLS-1$
    String STATUT = "statut"; //$NON-NLS-1$
    String CODE_ACCES_TECHNIQUE = "codeAccesTechnique"; //$NON-NLS-1$
    String DATE_DERNIERE_DECLARATION_ONT_INSTALLE = "dateDerniereDeclarationOntInstalle"; //$NON-NLS-1$
    String TYPE_TECHNOLOGIE_PON = "typeTechnologiePon"; //$NON-NLS-1$
    String NO_SERIE_ONT_INSTALLE = "noSerieOntInstalle"; //$NON-NLS-1$
  }

  /** The connector instance */
  private final RESConnector _resInstance;
  /** The json builder */
  private IRavelJson _jsonBuilder;

  /**
   * Default constructor
   *
   * @param resInstance_p
   *          Current RESConnector instance
   */
  public RessourceRaccordementService(RESConnector resInstance_p)
  {
    _resInstance = resInstance_p;
    _jsonBuilder = new RavelJson.RavelJsonBuilder().profil(SpiritConstants.JSON_PROFILE_STARK).build();
  }

  public ConnectorResponse<Retour, Nothing> ressourceRaccordementCreer(Tracabilite tracabilite_p, String ressourceRaccordementUrl_p, Ressource ressource_p) throws RavelException
  {
    try
    {
      // Call SAAB
      final Response response;
      try
      {
        RESTRequest restRequest = new RESTRequestBuilder()//
            .httpMethod(HttpMethod.POST)//
            .traceability(tracabilite_p)//
            .serializer(_jsonBuilder)//
            .method(IMethodName.RESSOURCE_RACCORDEMENT_CREER)//
            .headers(AbstractInternalRESTConnector.getSpiritStarkRequestHeader())//
            .path(ressourceRaccordementUrl_p)//
            .request(ressource_p)//
            .build();
        response = _resInstance.sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }
      // Get the content to a JSON string
      BasicResponse basicResponse = _resInstance.getContentFromResponse(tracabilite_p, response, IMethodName.RESSOURCE_RACCORDEMENT_CREER, BasicResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(basicResponse.getRetour());
      return new ConnectorResponse<>(retour, null);
    }
    catch (Exception e_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  public ConnectorResponse<Retour, Nothing> ressourceRaccordementModifierCodeAccesTechnique(Tracabilite tracabilite_p, String ressourceRaccordementUrl_p, String idRessource_p, String codeAccesTechnique_p) throws RavelException
  {
    try
    {
      // Query parameters
      HashMap<String, String> queryParams = new HashMap<>();
      if (StringTools.isNotNullOrEmpty(idRessource_p) && StringTools.isNotNullOrEmpty(codeAccesTechnique_p))
      {
        queryParams.put(IParameter.ID_RESSOURCE, idRessource_p);
        queryParams.put(IParameter.CODE_ACCES_TECHNIQUE, codeAccesTechnique_p);
      }
      // Call SAAB
      final Response response;
      try
      {
        RESTRequest restRequest = new RESTRequestBuilder()//
            .httpMethod(HttpMethod.PUT)//
            .traceability(tracabilite_p)//
            .method(IMethodName.RESSOURCE_RACCORDEMENT_MODIFIER_CODE_ACCES_TECHNIQUE)//
            .headers(AbstractInternalRESTConnector.getSpiritStarkRequestHeader())//
            .path(ressourceRaccordementUrl_p)//
            .queryParameter(queryParams)//
            .build();
        response = _resInstance.sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }
      // Get the content to a JSON string
      BasicResponse basicResponse = _resInstance.getContentFromResponse(tracabilite_p, response, IMethodName.RESSOURCE_RACCORDEMENT_MODIFIER_CODE_ACCES_TECHNIQUE, BasicResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(basicResponse.getRetour());
      return new ConnectorResponse<>(retour, null);
    }
    catch (Exception e_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  /**
   * @param tracabilite_p
   *          tracabilite
   * @param ressourceRaccordementUrl_p
   *          ressourceRaccordementUrl_p
   * @param idRessource_p
   *          idRessource
   * @param dateDerniereDeclarationOntInstalle_p
   *          dateDerniereDeclarationOntInstalle
   * @param typeTechnologiePon_p
   *          typeTechnologiePon
   * @param noSerieOntInstalle_p
   *          noSerieOntInstalle
   * @return ConnectorResponse<Retour, Nothing>
   * @throws RavelException
   *           In case of Exception
   */
  public ConnectorResponse<Retour, Nothing> ressourceRaccordementModifierOntInstalle(Tracabilite tracabilite_p, String ressourceRaccordementUrl_p, String idRessource_p, LocalDateTime dateDerniereDeclarationOntInstalle_p, String typeTechnologiePon_p, String noSerieOntInstalle_p) throws RavelException
  {
    try
    {
      // Query parameters
      HashMap<String, String> queryParams = new HashMap<>();
      if (StringTools.isNotNullOrEmpty(idRessource_p) && StringTools.isNotNullOrEmpty(dateDerniereDeclarationOntInstalle_p.toString()))
      {
        queryParams.put(IParameter.ID_RESSOURCE, idRessource_p);
        IsoShortOffsetDateTimeWithMillis isoShortOffsetDateTimeWithMillis = new IsoShortOffsetDateTimeWithMillis();
        queryParams.put(IParameter.DATE_DERNIERE_DECLARATION_ONT_INSTALLE, isoShortOffsetDateTimeWithMillis.format(dateDerniereDeclarationOntInstalle_p));

        if (StringTools.isNotNullOrEmpty(typeTechnologiePon_p))
        {
          queryParams.put(IParameter.TYPE_TECHNOLOGIE_PON, typeTechnologiePon_p);
        }
        if (StringTools.isNotNullOrEmpty(noSerieOntInstalle_p))
        {
          queryParams.put(IParameter.NO_SERIE_ONT_INSTALLE, noSerieOntInstalle_p);
        }
      }
      // Call SAAB
      final Response response;
      try
      {
        RESTRequest restRequest = new RESTRequestBuilder()//
            .httpMethod(HttpMethod.PUT)//
            .traceability(tracabilite_p)//
            .method(IMethodName.RESSOURCE_RACCORDEMENT_MODIFIER_ONT_INSTALLE)//
            .headers(AbstractInternalRESTConnector.getSpiritStarkRequestHeader())//
            .path(ressourceRaccordementUrl_p)//
            .queryParameter(queryParams)//
            .build();
        response = _resInstance.sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }
      // Get the content to a JSON string
      BasicResponse basicResponse = _resInstance.getContentFromResponse(tracabilite_p, response, IMethodName.RESSOURCE_RACCORDEMENT_MODIFIER_ONT_INSTALLE, BasicResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(basicResponse.getRetour());
      return new ConnectorResponse<>(retour, null);
    }
    catch (Exception e_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  public ConnectorResponse<Retour, Nothing> ressourceRaccordementModifierStatutAllocation(Tracabilite tracabilite_p, String ressourceRaccordementUrl_p, String idRessource_p, String idSt_p, String statut_p) throws RavelException
  {
    try
    {
      // Query parameters
      HashMap<String, String> queryParams = new HashMap<>();
      if (StringTools.isNotNullOrEmpty(idRessource_p) && StringTools.isNotNullOrEmpty(idSt_p) && StringTools.isNotNullOrEmpty(statut_p))
      {
        queryParams.put(IParameter.ID_RESSOURCE, idRessource_p);
        queryParams.put(IParameter.ID_ST, idSt_p);
        queryParams.put(IParameter.STATUT, statut_p);
      }
      // Call SAAB
      final Response response;
      try
      {
        RESTRequest restRequest = new RESTRequestBuilder()//
            .httpMethod(HttpMethod.PUT)//
            .traceability(tracabilite_p)//
            .method(IMethodName.RESSOURCE_RACCORDEMENT_MODIFIER_STATUT_ALLOCATION)//
            .headers(AbstractInternalRESTConnector.getSpiritStarkRequestHeader())//
            .path(ressourceRaccordementUrl_p)//
            .queryParameter(queryParams)//
            .build();
        response = _resInstance.sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }
      // Get the content to a JSON string
      BasicResponse basicResponse = _resInstance.getContentFromResponse(tracabilite_p, response, IMethodName.RESSOURCE_RACCORDEMENT_MODIFIER_STATUT_ALLOCATION, BasicResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(basicResponse.getRetour());
      return new ConnectorResponse<>(retour, null);
    }
    catch (Exception e_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }
}
