/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.res;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.AbaqueDSL;
import com.bytel.spirit.common.shared.saab.res.AccesTechnique;
import com.bytel.spirit.common.shared.saab.res.CacheElig;
import com.bytel.spirit.common.shared.saab.res.CompteRenduSuppression;
import com.bytel.spirit.common.shared.saab.res.Couverture5G;
import com.bytel.spirit.common.shared.saab.res.CouvertureCuivre;
import com.bytel.spirit.common.shared.saab.res.CouvertureFtth;
import com.bytel.spirit.common.shared.saab.res.CouvertureFtto;
import com.bytel.spirit.common.shared.saab.res.CouvertureGeoCodage;
import com.bytel.spirit.common.shared.saab.res.CouvertureTokyo;
import com.bytel.spirit.common.shared.saab.res.DispoNroFtteOrg;
import com.bytel.spirit.common.shared.saab.res.DispoRessourceDSLAxione;
import com.bytel.spirit.common.shared.saab.res.DispoRessourceDSLBouygues;
import com.bytel.spirit.common.shared.saab.res.DispoRessourceDSLOrange;
import com.bytel.spirit.common.shared.saab.res.DispoRessourceDSLSFR;
import com.bytel.spirit.common.shared.saab.res.EntonnoirCommune;
import com.bytel.spirit.common.shared.saab.res.EntonnoirNumero;
import com.bytel.spirit.common.shared.saab.res.EntonnoirVoie;
import com.bytel.spirit.common.shared.saab.res.FichierOrigine;
import com.bytel.spirit.common.shared.saab.res.FichierReferentielComposite;
import com.bytel.spirit.common.shared.saab.res.Fqdn;
import com.bytel.spirit.common.shared.saab.res.ListeTechnologieAutorisee;
import com.bytel.spirit.common.shared.saab.res.Olt;
import com.bytel.spirit.common.shared.saab.res.OltComposite;
import com.bytel.spirit.common.shared.saab.res.PMComposite;
import com.bytel.spirit.common.shared.saab.res.PointAncrageIP;
import com.bytel.spirit.common.shared.saab.res.PoolIP;
import com.bytel.spirit.common.shared.saab.res.PorteDeCollecte;
import com.bytel.spirit.common.shared.saab.res.Ressource;
import com.bytel.spirit.common.shared.saab.res.RessourceAggrege;
import com.bytel.spirit.common.shared.saab.res.RessourceFtth;
import com.bytel.spirit.common.shared.saab.res.RessourcePortPM;
import com.bytel.spirit.common.shared.saab.res.RessourceRaccordementComposite;
import com.bytel.spirit.common.shared.saab.res.StructureVerticaleFtthComposite;
import com.bytel.spirit.common.shared.saab.res.SurchargeBoitierPM;
import com.bytel.spirit.common.shared.saab.res.SurchargePM;
import com.bytel.spirit.common.shared.saab.res.SurchargePortPM;
import com.bytel.spirit.common.shared.saab.res.TopologieArcturus;
import com.bytel.spirit.common.shared.saab.res.TypeCouverture5G;
import com.bytel.spirit.common.shared.saab.res.request.IntegrationGroupeFichierRequest;
import com.bytel.spirit.common.shared.saab.res.request.ListeCacheEligRequest;
import com.bytel.spirit.common.shared.saab.res.request.ListeCoupleImbOiRequest;
import com.bytel.spirit.common.shared.saab.res.request.ListeNomOLTRequest;
import com.bytel.spirit.common.shared.saab.res.request.ListePrevisionRequest;
import com.bytel.spirit.common.shared.saab.res.request.ManageNoeudRaccordementRequest;
import com.bytel.spirit.common.shared.saab.res.response.GetSurchargeResponse;
import com.bytel.spirit.common.shared.saab.res.response.IntegrationGroupeFichierResponse;
import com.bytel.spirit.common.shared.saab.res.response.ListeCommuneResponse;
import com.bytel.spirit.common.shared.saab.res.response.ListePrevisionResponse;
import com.bytel.spirit.common.shared.types.json.response.PMConsultResponse;

/**
 *
 * @author dangelis
 * @version ($Revision$ $Date$)
 */
public interface IRES
{
  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param referencePmBytel_p
   * @param referencePmOi_p
   * @param referenceBoitierPm_p
   * @param nomPmTechnique_p
   * @param nomPanneauPm_p
   * @param positionPortPm_p
   * @param technologiePON_p
   * @param idRessourceLie_p
   * @return
   * @throws RavelException
   */
  public ConnectorResponse<Retour, RessourcePortPM> ressourcePortPmGererAllocation(Tracabilite tracabilite_p, String referencePmBytel_p, String referencePmOi_p, String referenceBoitierPm_p, String nomPmTechnique_p, String nomPanneauPm_p, Integer positionPortPm_p, String technologiePON_p, String idRessourceLie_p) throws RavelException;

  /**
   * Get all abaques.
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @return Map<Key, List<AbaqueDSL>>, Key=reseauCollecte, ligneMarche, normeTechno, sensFlux
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, Map<String, List<AbaqueDSL>>> abaqueDslLireTous(Tracabilite tracabilite_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @return ConnectorResponse<Retour, AccesTechnique[]>
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, Map<String, AccesTechnique>> accesTechniqueLireTous(Tracabilite tracabilite_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param login
   * @return ConnectorResponse<Retour, AccesTechnique[]>
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, List<AccesTechnique>> accesTechniqueLireTousParLogin(Tracabilite tracabilite_p, String login) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param listeCacheEligRequest_p
   * @return
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, Integer> cacheEligCreerListe(Tracabilite tracabilite_p, ListeCacheEligRequest listeCacheEligRequest_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param idCleCompose_p
   * @param typeCle_p
   * @param techno_p
   * @param operateur_p
   * @return
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, CacheElig> cacheEligLire(Tracabilite tracabilite_p, String idCleCompose_p, String typeCle_p, String techno_p, String operateur_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param idAdresseBytel_p
   *          idAdresseBytel_p
   * @param typeCouverture5G_p
   *          typeCouverture5G
   * @return ConnectorResponse<Retour, Couverture5G>
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, Couverture5G> couverture5gLireUn(Tracabilite tracabilite_p, String idAdresseBytel_p, TypeCouverture5G typeCouverture5G_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param idAdresseBytel_p
   *          identifiant Bytel
   * @return ConnectorResponse<Retour, List<CouvertureCuivre>>
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, List<CouvertureCuivre>> couvertureCuivreLireTousParIdAdresseBytel(Tracabilite tracabilite_p, String idAdresseBytel_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param codeInsee_p
   *          Code Insee
   * @param rivoli_p
   *          Code Rivoli
   * @param numeroComplement_p
   *          Numero Complement
   * @return ConnectorResponse<Retour, List<CouvertureCuivre>>
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, List<CouvertureCuivre>> couvertureCuivreLireUnParRivoli(Tracabilite tracabilite_p, String codeInsee_p, String rivoli_p, String numeroComplement_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param hexacleInterne_p
   *          hexacleInterne
   * @return ConnectorResponse<Retour, List<CouvertureFtth>>
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, List<CouvertureFtth>> couvertureFtthLireTousParHexacleInterne(Tracabilite tracabilite_p, String hexacleInterne_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param idAdresseBytel_p
   *          identifiant Bytel
   * @return ConnectorResponse<Retour, List<CouvertureFtth>>
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, List<CouvertureFtth>> couvertureFtthLireTousParIdAdresseBytel(Tracabilite tracabilite_p, String idAdresseBytel_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param imb_p
   *          imb
   * @return ConnectorResponse<Retour, List<CouvertureFtth>>
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, List<CouvertureFtth>> couvertureFtthLireTousParIMB(Tracabilite tracabilite_p, String imb_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param idAdresseBytel_p
   *          indentifiant Bytel
   * @return ConnectorResponse<Retour, List<CouvertureFtto>>
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, CouvertureFtto> couvertureFttoLireUn(Tracabilite tracabilite_p, String idAdresseBytel_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param idAdresseBytel_p
   *          idAdresseBytel_p
   * @return ConnectorResponse<Retour, CouvertureGeoCodage>
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, CouvertureGeoCodage> couvertureGeocodageLireUn(Tracabilite tracabilite_p, String idAdresseBytel_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param idAdresseBytel_p
   *          idAdresseBytel
   * @return ConnectorResponse<Retour, CouvertureTokyo>
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, CouvertureTokyo> couvertureTokyoLireUn(Tracabilite tracabilite_p, String idAdresseBytel_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param nro_p
   * @return
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, DispoNroFtteOrg> dispoNroFtteOrgLire(Tracabilite tracabilite_p, String nro_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param nomUraOrange_p
   *          Référence Orange de l'URA
   * @param techno_p
   *          Technologie
   * @param nbPaire_p
   *          Nombre de paires
   * @param typeKp_p
   *          Identifiant du type KP
   * @return ConnectorResponse<Retour, List<DispoRessourceDSLAxione>>
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, List<DispoRessourceDSLAxione>> dispoRessourceDslAxioneLire(Tracabilite tracabilite_p, String nomUraOrange_p, String techno_p, String nbPaire_p, String typeKp_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param nomUraOrange_p
   *          Référence Orange de l'URA
   * @return ConnectorResponse<Retour, List<DispoRessourceDSLAxione>>
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, List<DispoRessourceDSLAxione>> dispoRessourceDslAxioneLireParNomUra(Tracabilite tracabilite_p, String nomUraOrange_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param nomUraOrange_p
   *          Référence Orange de l'URA
   * @param techno_p
   *          Technologie
   * @param nbPaire_p
   *          Nombre de paires
   * @param typeKp_p
   *          Identifiant du type KP
   * @return ConnectorResponse<Retour, List<DispoRessourceDSLBouygues>>
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, List<DispoRessourceDSLBouygues>> dispoRessourceDslBouyguesLire(Tracabilite tracabilite_p, String nomUraOrange_p, String techno_p, String nbPaire_p, String typeKp_p) throws RavelException;

  /**
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param nomUraOrange_p
   *          Référence Orange de l'URA
   * @return ConnectorResponse<Retour, List<DispoRessourceDSLBouygues>>
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, List<DispoRessourceDSLBouygues>> dispoRessourceDslBouyguesLireParNomUra(Tracabilite tracabilite_p, String nomUraOrange_p) throws RavelException;

  /**
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param nomUraOrange_p
   *          Référence Orange de l'URA
   * @param techno_p
   *          Technologie
   * @param nbPaire_p
   *          Nombre de paires
   * @param typeKp_p
   *          Identifiant du type KP
   * @return ConnectorResponse<Retour, List<DispoRessourceDSLOrange>>
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, List<DispoRessourceDSLOrange>> dispoRessourceDslOrangeLire(Tracabilite tracabilite_p, String nomUraOrange_p, String techno_p, String nbPaire_p, String typeKp_p) throws RavelException;

  /**
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param nomUraOrange_p
   *          Référence Orange de l'URA
   * @return ConnectorResponse<Retour, List<DispoRessourceDSLOrange>>
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, List<DispoRessourceDSLOrange>> dispoRessourceDslOrangeLireParNomUra(Tracabilite tracabilite_p, String nomUraOrange_p) throws RavelException;

  /**
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param nomUraOrange_p
   *          Référence Orange de l'URA
   * @param techno_p
   *          Technologie
   * @param nbPaire_p
   *          Nombre de paires
   * @param typeKp_p
   *          Identifiant du type KP
   * @return ConnectorResponse<Retour, List<DispoRessourceDSLSFR>>
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, List<DispoRessourceDSLSFR>> dispoRessourceDslSFRLire(Tracabilite tracabilite_p, String nomUraOrange_p, String techno_p, String nbPaire_p, String typeKp_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param nomUraOrange_p
   *          Référence Orange de l'URA
   * @return ConnectorResponse<Retour, List<DispoRessourceDSLSFR>>
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, List<DispoRessourceDSLSFR>> dispoRessourceDslSFRLireParNomUra(Tracabilite tracabilite_p, String nomUraOrange_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param codeInsee_p
   *          codeInsee
   * @return ConnectorResponse<Retour, List<EntonnoirCommune>>
   * @throws RavelException
   *           on error. on error.
   */
  ConnectorResponse<Retour, List<EntonnoirCommune>> entonnoirCommuneLireTousParCodeInsee(Tracabilite tracabilite_p, String codeInsee_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param codePostal_p
   *          codePostal
   * @return ConnectorResponse<Retour, List<EntonnoirCommune>>
   * @throws RavelException
   *           on error. on error.
   */
  ConnectorResponse<Retour, List<EntonnoirCommune>> entonnoirCommuneLireTousParCodePostal(Tracabilite tracabilite_p, String codePostal_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param departement_p
   *          departement
   * @return ConnectorResponse<Retour, List<EntonnoirCommune>>
   * @throws RavelException
   *           on error. on error.
   */
  ConnectorResponse<Retour, List<EntonnoirCommune>> entonnoirCommuneLireTousParDepartement(Tracabilite tracabilite_p, String departement_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param codeInsee_p
   *          codeInsee
   * @param codeRivoli_p
   *          codeRivoli
   * @return ConnectorResponse<Retour, List<EntonnoirNumero>>
   * @throws RavelException
   *           on error. on error.
   */
  ConnectorResponse<Retour, List<EntonnoirNumero>> entonnoirNumeroLireTousParCodeInseeCodeRivoli(Tracabilite tracabilite_p, String codeInsee_p, String codeRivoli_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param codeInsee_p
   *          codeInsee
   * @param similiHexacle0_p
   *          similiHexacle0
   * @return ConnectorResponse<Retour, List<EntonnoirNumero>>
   * @throws RavelException
   *           on error. on error.
   */
  ConnectorResponse<Retour, List<EntonnoirNumero>> entonnoirNumeroLireTousParCodeInseeSimiliHexacle0(Tracabilite tracabilite_p, String codeInsee_p, String similiHexacle0_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param codeInsee_p
   *          codeInsee
   * @return ConnectorResponse<Retour, List<EntonnoirVoie>>
   * @throws RavelException
   *           on error. on error.
   */
  ConnectorResponse<Retour, List<EntonnoirVoie>> entonnoirVoieLireTousParCodeInsee(Tracabilite tracabilite_p, String codeInsee_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param codeInsee_p
   *          codeInsee
   * @param codeRivoli_p
   *          codeRivoli
   * @return ConnectorResponse<Retour, List<EntonnoirVoie>>
   * @throws RavelException
   *           on error. on error.
   */
  ConnectorResponse<Retour, List<EntonnoirVoie>> entonnoirVoieLireUnParCodeInseeCodeRivoli(Tracabilite tracabilite_p, String codeInsee_p, String codeRivoli_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param codeInsee_p
   *          codeInsee
   * @param similiHexacle0_p
   *          similiHexacle0
   * @return ConnectorResponse<Retour, List<EntonnoirVoie>>
   * @throws RavelException
   *           on error. on error.
   */
  ConnectorResponse<Retour, List<EntonnoirVoie>> entonnoirVoieLireUnParCodeInseeSimiliHexacle0(Tracabilite tracabilite_p, String codeInsee_p, String similiHexacle0_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param typeReferentiel_p
   *          type de Referentiel
   * @param fichierOrigine_p
   *          fichierOrigine
   * @return ConnectorResponse<Retour, Nothing>
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, Nothing> fichierReferentielCompositeGererEchecIntegration(Tracabilite tracabilite_p, String typeReferentiel_p, FichierOrigine fichierOrigine_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param typeReferentiel_p
   *          type de Referentiel
   * @return ConnectorResponse<Retour, List<FichierReferentielComposite>>
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, List<FichierReferentielComposite>> fichierReferentielCompositeLireTous(Tracabilite tracabilite_p, String typeReferentiel_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param nomfqdn_p
   * @param operation_p
   * @param nombreSession_p
   * @return
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, Nothing> fqdnGererAllocationSession(Tracabilite tracabilite_p, String nomfqdn_p, String operation_p, int nombreSession_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param nomFQDN_p
   * @return
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, Fqdn> fqdnLireUn(Tracabilite tracabilite_p, String nomFQDN_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @return
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, Fqdn> fqdnLireUnParTauxOccupation(Tracabilite tracabilite_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param typeReferentiel_p
   *          type de référence
   * @return ConnectorResponse<Retour, Nothing>
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, Nothing> gestionReferentielGererBascule(Tracabilite tracabilite_p, String typeReferentiel_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param typeReferentiel_p
   *          type de référence
   * @return ConnectorResponse<Retour, Nothing>
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, Nothing> gestionReferentielGererRestaurationBackup(Tracabilite tracabilite_p, String typeReferentiel_p) throws RavelException;

  /**
   * Ce service permet de créer ou de modifier une ressource « NoeudRaccordement ». QueryParam - Cas n°1 GererImport
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param manageNoeudRaccordementRequest_p
   *          noued Raccordement
   * @return Nothing (in a connector response).
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, Nothing> noeudRaccordementGererImport(Tracabilite tracabilite_p, ManageNoeudRaccordementRequest manageNoeudRaccordementRequest_p) throws RavelException;

  /**
   * NoeudRaccordement nrGererSuppressionNonReference verb.
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param listeNomNoedRaco_p
   *          the list with the names of the NoedRaccordement that have been imported.
   * @return ConnectorResponse<Retour, List<CompteRenduSuppression>>
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, Set<CompteRenduSuppression>> noeudRaccordementGererSuppressionNrNonReference(Tracabilite tracabilite_p, Set<String> listeNomNoedRaco_p) throws RavelException;

  /**
   * PAD3200 OltComposite Manage oltcompositeGererImport
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param oltComposite_p
   *          the {@link OltComposite}.
   * @return ConnectorResponse<Retour, Nothing>
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, Nothing> oltCompositeGererImport(Tracabilite tracabilite_p, OltComposite oltComposite_p) throws RavelException;

  /**
   * OltComposite oltCompositeGererSuppressionOltNonReference verb (PAD3200)
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param listeNomOLT_p
   *          the list of names of the OLT.
   * @return ConnectorResponse with a set of CompteRenduSuppression.
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, Set<CompteRenduSuppression>> oltCompositeGererSuppressionOltNonReference(Tracabilite tracabilite_p, Set<String> listeNomOLT_p) throws RavelException;

  /**
   * Ce service permet de consulter un « OltComposite » à partir du nom de l’OLT un de ses sous-objets "surcharge".
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param nomOLT_p
   *          nom olt
   * @param action_p
   *          action
   * @param positionCarte_p
   *          posititon Carte
   * @param positionPortPon_p
   *          position port Pon
   * @param positionOntId_p
   *          position ont ID
   * @return
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, GetSurchargeResponse> oltCompositeLireSurchage(Tracabilite tracabilite_p, String nomOLT_p, String action_p, String positionCarte_p, String positionPortPon_p, String positionOntId_p) throws RavelException;

  /**
   * OLTComposite.LireUn verb.
   *
   * @param tracabilite_p
   *          Tracability.
   * @param nomOLT_p
   *          Name of the OLT.
   * @return Olt Composite?
   * @throws RavelException
   *           on error. if a trouble happens during SAAB invocation.
   */
  ConnectorResponse<Retour, OltComposite> oltCompositeLireUn(Tracabilite tracabilite_p, String nomOLT_p) throws RavelException;

  /**
   * service permet de modifier un sous-objet "surcharge" spécifique de l'objet "OltComposite".
   * SurchargeDateDebutQuarantaineOLT
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param listTechnoAutorisee_p
   *          {@link ListeTechnologieAutorisee}
   * @param nomOlt_p
   *          Nom de l'OLT
   * @return ConnectorResponse<Retour, Nothing>
   * @throws RavelException
   */
  ConnectorResponse<Retour, Nothing> oltCompositemodifierSurchargeDateDebutQuarantaineOLT(Tracabilite tracabilite_p, ListeTechnologieAutorisee listTechnoAutorisee_p, String nomOlt_p) throws RavelException;

  /**
   * Ce service permet de modifier un sous-objet "surcharge" spécifique de l'objet "OltComposite".
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param nomOlt_p
   *          nom OLT
   * @param positionCarte_p
   *          positionCarte
   * @param positionPortPon_p
   *          positionPortPon
   * @param debitGarantieCapaciteAllouee_p
   *          debitGarantieCapaciteAllouee
   * @return ConnectorResponse<Retour, Nothing>
   * @throws RavelException
   *           on error. exception
   */
  ConnectorResponse<Retour, Nothing> oltCompositeModifierSurchargeDebitGarantiPortPon(Tracabilite tracabilite_p, String nomOlt_p, String positionCarte_p, String positionPortPon_p, String debitGarantieCapaciteAllouee_p) throws RavelException;

  /**
   * Ce service permet de modifier un sous-objet "surcharge" spécifique de l'objet "OltComposite".
   * SurchargeExploitationOntId
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param nomOlt_p
   *          nom olt
   * @param positionCarte_p
   *          positionCarte
   * @param positionPortPon_p
   *          positionPortPon
   * @param positionOntId_p
   *          positionOntId
   * @param statutExploitation_p
   *          statutExploitation
   * @param commentaireExploitation_p
   *          commentaireExploitation
   * @return ConnectorResponse<Retour, Nothing>
   * @throws RavelException
   *           on error. exception
   */
  ConnectorResponse<Retour, Nothing> oltCompositeModifierSurchargeExploitationOntId(Tracabilite tracabilite_p, String nomOlt_p, String positionCarte_p, String positionPortPon_p, String positionOntId_p, String statutExploitation_p, String commentaireExploitation_p) throws RavelException;

  /**
   * Ce service permet de modifier un sous-objet "surcharge" spécifique de l'objet "OltComposite".
   * SurchargePriseClientCarte
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param nomOlt_p
   *          nom OLT
   * @param positionCarte_p
   *          position carte
   * @param statutBlocage_p
   *          statut blocage
   * @param commentaireBlocage_p
   *          commentaire blocage
   * @return ConnectorResponse<Retour, Nothing>
   * @throws RavelException
   *           on error. exception
   */
  ConnectorResponse<Retour, Nothing> oltCompositeModifierSurchargePriseClientCarte(Tracabilite tracabilite_p, String nomOlt_p, String positionCarte_p, String statutBlocage_p, String commentaireBlocage_p) throws RavelException;

  /**
   * Ce service permet de modifier un sous-objet "surcharge" spécifique de l'objet "OltComposite".
   * SurchargePriseClientOLT
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param nomOlt_p
   *          nom olt
   * @param statutBlocage_p
   *          statut blocage
   * @param commentaireBlocage_p
   *          commentaire blocage
   * @return ConnectorResponse<Retour, Nothing>
   * @throws RavelException
   *           on error. exception
   */
  ConnectorResponse<Retour, Nothing> oltCompositeModifierSurchargePriseClientOLT(Tracabilite tracabilite_p, String nomOlt_p, String statutBlocage_p, String commentaireBlocage_p) throws RavelException;

  /**
   * service permet de modifier un sous-objet "surcharge" spécifique de l'objet "OltComposite".
   * SurchargePriseClientOntId
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param nomOlt_p
   *          nom Olt
   * @param positionCarte_p
   *          positionCarte
   * @param positionPortPon_p
   *          positionPortPon
   * @param positionOntId_p
   *          positionOntId
   * @param statutBlocage_p
   *          statut blocage
   * @param commentaireBlocage_p
   *          commentaire blocage
   * @return ConnectorResponse<Retour, Nothing>
   * @throws RavelException
   *           on error. exception
   */
  ConnectorResponse<Retour, Nothing> oltCompositeModifierSurchargePriseClientOntId(Tracabilite tracabilite_p, String nomOlt_p, String positionCarte_p, String positionPortPon_p, String positionOntId_p, String statutBlocage_p, String commentaireBlocage_p) throws RavelException;

  /**
   * service permet de modifier un sous-objet "surcharge" spécifique de l'objet "OltComposite".
   * SurchargePriseClientPortPon
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param nomOlt_p
   *          nom olt
   * @param positionCarte_p
   *          position carte
   * @param positionPortPon_p
   *          position port pon
   * @param statutBlocage_p
   *          statut blocage
   * @param commentaireBlocage_p
   *          commentaire blocage
   * @return ConnectorResponse<Retour, Nothing>
   * @throws RavelException
   *           on error. exception
   */
  ConnectorResponse<Retour, Nothing> oltCompositeModifierSurchargePriseClientPortPon(Tracabilite tracabilite_p, String nomOlt_p, String positionCarte_p, String positionPortPon_p, String statutBlocage_p, String commentaireBlocage_p) throws RavelException;

  /**
   * service permet de modifier un sous-objet "surcharge" spécifique de l'objet "OltComposite".
   * SurchargeTechnoAutoriseePortPon
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param listTechnoAutorisee_p
   *          list Techno autorisée
   * @param nomOlt_p
   *          nom olt
   * @param positionCarte_p
   *          position carte
   * @param positionPortPon_p
   *          position port pon
   *
   * @return ConnectorResponse<Retour, Nothing>
   * @throws RavelException
   *           on error. exception
   */
  ConnectorResponse<Retour, Nothing> oltCompositeModifierSurchargeTechnoAutoriseePortPon(Tracabilite tracabilite_p, ListeTechnologieAutorisee listTechnoAutorisee_p, String nomOlt_p, String positionCarte_p, String positionPortPon_p) throws RavelException;

  /**
   * service permet de modifier un sous-objet "surcharge" spécifique de l'objet "OltComposite". SurchargeVersionOLT(
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param listTechnoAutorisee_p
   *          liste techno
   * @param nomOlt_p
   *          nom Olt
   * @param versionInterfaceEchange_p
   *          version interface
   * @return ConnectorResponse<Retour, Nothing>
   * @throws RavelException
   *           on error. exception
   */
  ConnectorResponse<Retour, Nothing> oltCompositeModifierSurchargeVersionOLT(Tracabilite tracabilite_p, ListeTechnologieAutorisee listTechnoAutorisee_p, String nomOlt_p, String versionInterfaceEchange_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          tracabilite
   * @param listeCommune
   *          listeCommune
   * @return ConnectorResponse<Retour, Boolean>
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, Boolean> pad3001CommuneCreate(Tracabilite tracabilite_p, com.bytel.spirit.common.shared.saab.res.request.ListeCommuneRequest listeCommune) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param codeInsee_p
   *          codeInsee_p
   * @return ConnectorResponse<Retour, ListeCommune>
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, ListeCommuneResponse> pad3001CommuneReadAncienCodeInsee(Tracabilite tracabilite_p, String codeInsee_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param codeInsee
   *          codeInsee
   * @return ConnectorResponse<Retour, ListeCommune>
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, ListeCommuneResponse> pad3001CommuneReadCodeInsee(Tracabilite tracabilite_p, String codeInsee) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite._p
   * @param codePostal_p
   *          codePostal_p
   * @return ConnectorResponse<Retour, ListeCommune>
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, ListeCommuneResponse> pad3001CommuneReadCodePostal(Tracabilite tracabilite_p, String codePostal_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite._p
   * @param listePrevision_p
   *          listePrevision_p
   * @return ConnectorResponse<Retour, Boolean>
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, Boolean> pad3002PrevisionProgCreate(Tracabilite tracabilite_p, ListePrevisionRequest listePrevision_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param nomProgramme
   *          nomProgramme
   * @param codeInsee
   *          codeInsee
   * @return ConnectorResponse<Retour, ListePrevisionReponse>
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, ListePrevisionResponse> pad3002PrevisionProgRead(Tracabilite tracabilite_p, String nomProgramme, String codeInsee) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param integration
   *          integration
   * @return ConnectorResponse<Retour, Boolean>
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, Boolean> pad3003IntegrationGroupeFichierCreate(Tracabilite tracabilite_p, IntegrationGroupeFichierRequest integration) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param nomGroupeFichier_p
   *          nomGroupeFichier
   * @param action_p
   *          action
   * @return ConnectorResponse<Retour, Boolean>
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, Boolean> pad3003IntegrationGroupeFichierDelete(Tracabilite tracabilite_p, String nomGroupeFichier_p, String action_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param nomGroupeFichier
   *          nomGroupeFichier
   * @return ConnectorResponse<Retour, IntegrationGroupeFichierReponse>
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, IntegrationGroupeFichierResponse> pad3003IntegrationGroupeFichierRead(Tracabilite tracabilite_p, String nomGroupeFichier) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param nomGroupeFichier_p
   *          nomGroupeFichier
   * @param action_p
   *          action
   * @return ConnectorResponse<Retour, Boolean>
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, Boolean> pad3003IntegrationGroupeFichierUpdate(Tracabilite tracabilite_p, String nomGroupeFichier_p, String action_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param typeRessourceAggrege_p
   * @param idRessource_p
   * @return
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, RessourceAggrege> pad3101RessourceAggregeP2PLireUn(Tracabilite tracabilite_p, String typeRessourceAggrege_p, String idRessource_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param listNomOlt_p
   * @return
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, List<Olt>> pad3203OltLireTousFiltreNomOlt(Tracabilite tracabilite_p, ListeNomOLTRequest listNomOlt_p) throws RavelException;

  /**
   * Import a {@link PMComposite} to the DB.
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param pmComposite_p
   *          the {@link PMComposite} to be imported.
   * @return a {@link ConnectorResponse} with the {@link Retour} and {@link Nothing} (just because it needs to be a
   *         ConnectorResponse).
   * @throws RavelException
   *           on error. if the SAAB call fails.
   */
  @Deprecated
  ConnectorResponse<Retour, Nothing> pmCompositeGererImport(Tracabilite tracabilite_p, PMComposite pmComposite_p) throws RavelException;

  /**
   * Import a {@link PMComposite} to the DB.
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param pmComposite_p
   *          the {@link PMComposite} to be imported.
   * @param typeFluxImport_p
   *          Champ technique permettant de déterminer le type du flux d’import. Valeurs connues : - IMPORT_NOMINAL -
   *          VIE_DE_RESEAU
   * @return a {@link ConnectorResponse} with the {@link Retour} and {@link Nothing} (just because it needs to be a
   *         ConnectorResponse).
   * @throws RavelException
   *           if the SAAB call fails.
   */
  ConnectorResponse<Retour, Nothing> pmCompositeGererImport(Tracabilite tracabilite_p, PMComposite pmComposite_p, String typeFluxImport_p) throws RavelException;

  /**
   * Remove all PMs from the DB whose name is not on the list.
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param listNomPM_p
   *          the list of names of PMs to keep.
   * @return a {@link ConnectorResponse} with the {@link Retour} and a set of {@link CompteRenduSuppression} for results
   *         of the suppression.
   * @throws RavelException
   *           on error. if the SAAB call fails.
   */
  ConnectorResponse<Retour, Set<CompteRenduSuppression>> pmCompositeGererSuppressionPMNonReference(Tracabilite tracabilite_p, Set<String> listNomPM_p) throws RavelException;

  /**
   * Get a {@link SurchargeBoitierPM} (inside a {@link PMConsultResponse}) from the reference to the PM, the reference
   * to the "boitier" and the name of the "panneau".
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param referencePmBytel_p
   *          the Bytel reference to a PM.
   * @param referenceBoitierPm_p
   *          the reference to the "boitier" in the PM.
   * @param nomPanneau_p
   *          the name of the "panneau" in the boitier.
   * @param positionPortPM_p
   *          the position of the port in the "panneau".
   * @return a {@link ConnectorResponse} with the {@link Retour} and the {@link PMConsultResponse} obtained from the DB.
   * @throws RavelException
   *           on error. if the SAAB call fails.
   */
  ConnectorResponse<Retour, PMConsultResponse> pmCompositeLireSurchargeBoitierPM(Tracabilite tracabilite_p, String referencePmBytel_p, String referenceBoitierPm_p, String nomPanneau_p, String positionPortPM_p) throws RavelException;

  /**
   * Get a {@link SurchargePM} (inside a {@link PMConsultResponse}) from the reference to the PM and the reference to
   * the "boitier".
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param referencePmBytel_p
   *          the Bytel reference to a PM.
   * @param referenceBoitierPm_p
   *          the reference to the "boitier" in the PM.
   * @param nomPanneau_p
   *          the name of the "panneau" in the boitier.
   * @param positionPortPM_p
   *          the position of the port in the "panneau".
   * @return a {@link ConnectorResponse} with the {@link Retour} and the {@link PMConsultResponse} obtained from the DB.
   * @throws RavelException
   *           on error. if the SAAB call fails.
   */
  ConnectorResponse<Retour, PMConsultResponse> pmCompositeLireSurchargePM(Tracabilite tracabilite_p, String referencePmBytel_p, String referenceBoitierPm_p, String nomPanneau_p, String positionPortPM_p) throws RavelException;

  /**
   * Get a {@link SurchargePortPM} (inside a {@link PMConsultResponse}) from the reference to the PM, the reference to
   * the "boitier", the name of the "panneau" and the position of the port.
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param referencePmBytel_p
   *          the Bytel reference to a PM.
   * @param referenceBoitierPm_p
   *          the reference to the "boitier" in the PM.
   * @param nomPanneau_p
   *          the name of the "panneau" in the boitier.
   * @param positionPortPM_p
   *          the position of the port in the "panneau".
   * @return a {@link ConnectorResponse} with the {@link Retour} and the {@link PMConsultResponse} obtained from the DB.
   * @throws RavelException
   *           on error. if the SAAB call fails.
   */
  ConnectorResponse<Retour, PMConsultResponse> pmCompositeLireSurchargePortPM(Tracabilite tracabilite_p, String referencePmBytel_p, String referenceBoitierPm_p, String nomPanneau_p, String positionPortPM_p) throws RavelException;

  /**
   * Get a {@link PMComposite} given its Bytel reference.
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param referencePmBytel_p
   *          the Bytel reference to a PM.
   * @return a {@link ConnectorResponse} with the {@link Retour} and the {@link PMComposite}.
   * @throws RavelException
   *           on error. if the SAAB call fails.
   */
  ConnectorResponse<Retour, PMComposite> pmCompositeLireUnParReferencePmBytel(Tracabilite tracabilite_p, String referencePmBytel_p) throws RavelException;

  /**
   * Get a {@link PMComposite} given the reference to the OI of the PM.
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param referencePmOi_p
   *          the reference to the OI of the PM.
   * @return a {@link ConnectorResponse} with the {@link Retour} and the {@link PMComposite}.
   * @throws RavelException
   *           on error. if the SAAB call fails.
   */
  ConnectorResponse<Retour, PMComposite> pmCompositeLireUnParReferencePmOi(Tracabilite tracabilite_p, String referencePmOi_p) throws RavelException;

  /**
   * Update an object "surcharge" of a given PM.
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param referencePmBytel_p
   *          the Bytel reference to a PM.
   * @return a {@link ConnectorResponse} with the {@link Retour} and {@link Nothing} (just because it needs to be a
   *         ConnectorResponse).
   * @throws RavelException
   *           if the SAAB call fails.
   */
  ConnectorResponse<Retour, Nothing> pmCompositeModifierSurchargeDateDebutQuarantainePM(Tracabilite tracabilite_p, String referencePmBytel_p) throws RavelException;

  /**
   * Update an object "surcharge" of a given PM.
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param referencePmBytel_p
   *          the Bytel reference to a PM.
   * @param referenceBoitierPm_p
   *          the reference to the "boitier" in the PM.
   * @param nomPanneau_p
   *          the name of the "panneau" in the boitier.
   * @param positionPortPM_p
   *          the position of the port in the "panneau".
   * @param statutExploitation_p
   *          the status of "exploitation".
   * @param commentaireExploitation_p
   *          the comment of "exploitation".
   * @return a {@link ConnectorResponse} with the {@link Retour} and {@link Nothing} (just because it needs to be a
   *         ConnectorResponse).
   * @throws RavelException
   *           on error. if the SAAB call fails.
   */
  ConnectorResponse<Retour, Nothing> pmCompositeModifierSurchargeExploitationPortPM(Tracabilite tracabilite_p, String referencePmBytel_p, String referenceBoitierPm_p, String nomPanneau_p, String positionPortPM_p, String statutExploitation_p, String commentaireExploitation_p) throws RavelException;

  /**
   * Update an object "surcharge" of a given PM.
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param referencePmBytel_p
   *          the Bytel reference to a PM.
   * @param referenceBoitierPm_p
   *          the reference to the "boitier" in the PM.
   * @param statutBlocage_p
   *          the status of "blocage".
   * @param commentaireBlocage_p
   *          the comment of "blocage".
   * @return a {@link ConnectorResponse} with the {@link Retour} and {@link Nothing} (just because it needs to be a
   *         ConnectorResponse).
   * @throws RavelException
   *           on error. if the SAAB call fails.
   */
  ConnectorResponse<Retour, Nothing> pmCompositeModifierSurchargePriseClientBoitierPM(Tracabilite tracabilite_p, String referencePmBytel_p, String referenceBoitierPm_p, String statutBlocage_p, String commentaireBlocage_p) throws RavelException;

  /**
   * Update an object "surcharge" of a given PM.
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param referencePmBytel_p
   *          the Bytel reference to a PM.
   * @param statutBlocage_p
   *          the status of "blocage".
   * @param commentaireBlocage_p
   *          the comment of "blocage".
   * @return a {@link ConnectorResponse} with the {@link Retour} and {@link Nothing} (just because it needs to be a
   *         ConnectorResponse).
   * @throws RavelException
   *           on error. if the SAAB call fails.
   */
  ConnectorResponse<Retour, Nothing> pmCompositeModifierSurchargePriseClientPM(Tracabilite tracabilite_p, String referencePmBytel_p, String statutBlocage_p, String commentaireBlocage_p) throws RavelException;

  /**
   * Update an object "surcharge" of a given PM.
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param referencePmBytel_p
   *          the Bytel reference to a PM.
   * @param referenceBoitierPm_p
   *          the reference to the "boitier" in the PM.
   * @param nomPanneau_p
   *          the name of the "panneau" in the boitier.
   * @param positionPortPM_p
   *          the position of the port in the "panneau".
   * @param statutBlocage_p
   *          the status of "blocage".
   * @param commentaireBlocage_p
   *          the comment of "blocage".
   * @return a {@link ConnectorResponse} with the {@link Retour} and {@link Nothing} (just because it needs to be a
   *         ConnectorResponse).
   * @throws RavelException
   *           on error. if the SAAB call fails.
   */
  ConnectorResponse<Retour, Nothing> pmCompositeModifierSurchargePriseClientPortPM(Tracabilite tracabilite_p, String referencePmBytel_p, String referenceBoitierPm_p, String nomPanneau_p, String positionPortPM_p, String statutBlocage_p, String commentaireBlocage_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param pointAncrageIP_p
   *          pointAncrageIP
   * @return ConnectorResponse<Retour, PointAncrageIP>
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, Nothing> pointAncrageIpGererImport(Tracabilite tracabilite_p, PointAncrageIP pointAncrageIP_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param listeNomPointAncrageIP_p
   *          listeNomPointAncrageIP
   * @param typePointAncrageIP_p
   *          typePointAncrageIP
   * @return ConnectorResponse<Retour, PointAncrageIP>
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, Set<CompteRenduSuppression>> pointAncrageIpGererSuppressionPointAncrageIPNonReference(Tracabilite tracabilite_p, Set<String> listeNomPointAncrageIP_p, String typePointAncrageIP_p) throws RavelException;

  /**
   * The method used to import a {@link PoolIP} into the DB.
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param poolIP_p
   *          the object being written.
   * @return a {@link ConnectorResponse} with the {@link Retour}.
   * @throws RavelException
   *           on error. on error.
   */
  ConnectorResponse<Retour, Nothing> poolIpGererImport(Tracabilite tracabilite_p, PoolIP poolIP_p) throws RavelException;

  /**
   * Import a {@link PorteDeCollecte}.
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param porteDeCollecte_p
   *          the {@link PorteDeCollecte} being imported.
   * @return a pair with the retour and a Nothing (because it needs to be a pair).
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, Nothing> porteDeCollecteGererImport(Tracabilite tracabilite_p, PorteDeCollecte porteDeCollecte_p) throws RavelException;

  /**
   * Delete all {@link PorteDeCollecte} whose id is not in the list.
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param setIdNomCollecte_p
   *          the set with the ids being used.
   * @return a pair with the retour and a set with the results of the deletion, for each {@link PorteDeCollecte}.
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, Set<CompteRenduSuppression>> porteDeCollecteGererSuppressionPorteDeCollecteNonReference(Tracabilite tracabilite_p, Set<String> setIdNomCollecte_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param idNomCollecte_p
   *          identifiant de nom de collecte
   * @return ConnectorResponse<Retour, PorteDeCollecte>
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, PorteDeCollecte> porteDeCollecteLireUn(Tracabilite tracabilite_p, String idNomCollecte_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param ressource_p
   * @return
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, Nothing> ressourceAdresseIpClfCreer(Tracabilite tracabilite_p, Ressource ressource_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param idRessource_p
   * @param idSt_p
   * @param statut_p
   * @return
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, Nothing> ressourceAdresseIpClfModifierStatutAllocation(Tracabilite tracabilite_p, String idRessource_p, String idSt_p, String statut_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param ressource_p
   * @return
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, Nothing> ressourceCompteImsCreer(Tracabilite tracabilite_p, Ressource ressource_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param idRessource_p
   * @param idSt_p
   * @param statut_p
   * @return
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, Nothing> ressourceCompteImsModifierStatutAllocation(Tracabilite tracabilite_p, String idRessource_p, String idSt_p, String statut_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param ressource_p
   * @return
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, Nothing> ressourceCompteMailCreer(Tracabilite tracabilite_p, Ressource ressource_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param idRessource_p
   * @param idSt_p
   * @param statut_p
   * @return
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, Nothing> ressourceCompteMailModifierStatutAllocation(Tracabilite tracabilite_p, String idRessource_p, String idSt_p, String statut_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param referencePm_p
   *          referencePm
   * @return ConnectorResponse<Retour, List<RessourceFtth>>
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, List<RessourceFtth>> ressourceFtthLireTousParReferencePM(Tracabilite tracabilite_p, String referencePm_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param ressource_p
   * @return
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, Nothing> ressourceImpiFixeCreer(Tracabilite tracabilite_p, Ressource ressource_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param idRessource_p
   * @param idSt_p
   * @param statut_p
   * @return
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, Nothing> ressourceImpiFixeModifierStatutAllocation(Tracabilite tracabilite_p, String idRessource_p, String idSt_p, String statut_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param idRessourceLie_p
   * @param typeRessource_p
   * @return
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, List<Ressource>> ressourceLireTousParIdRessourceLie(Tracabilite tracabilite_p, String idRessourceLie_p, String typeRessource_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param idRessource_p
   * @param typeRessource_p
   * @return
   * @throws RavelException
   */
  ConnectorResponse<Retour, Ressource> ressourceLireUn(Tracabilite tracabilite_p, String idRessource_p, String typeRessource_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param typeRessource_p
   *          typeRessource
   * @param idRessource_p
   *          idRessource
   * @param idRessourceLie_p
   *          idRessourceLie
   * @param idRessourceLieCible_p
   *          idRessourceLieCible
   * @return ConnectorResponse<Retour, Nothing>
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, Nothing> ressourceModifierIdRessourceLie(Tracabilite tracabilite_p, String typeRessource_p, String idRessource_p, String idRessourceLie_p, String idRessourceLieCible_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param ressource_p
   * @return
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, Nothing> ressourceMotDePasseImsCreer(Tracabilite tracabilite_p, Ressource ressource_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param idRessource_p
   * @param idSt_p
   * @param statut_p
   * @return
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, Nothing> ressourceMotDePasseImsModifierStatutAllocation(Tracabilite tracabilite_p, String idRessource_p, String idSt_p, String statut_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param idRessource_p
   * @param idRessourceLie_p
   * @return
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, Nothing> ressourceOntIdGererLiberation(Tracabilite tracabilite_p, String idRessource_p, String idRessourceLie_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param nomNR_p
   * @return ConnectorResponse<Retour, Integer>
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, Integer> ressourcePortP2PcompterPortLibreP2P(Tracabilite tracabilite_p, String nomNR_p) throws RavelException;

  /**
   * @param tracabilite_p
   * @param nomNR_p
   * @param distance_p
   * @param idRessourceRaccordment_p
   * @param action_p
   * @return
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, Nothing> ressourcePortP2PGererAllocation(Tracabilite tracabilite_p, String nomNR_p, String distance_p, String idRessourceRaccordment_p, String action_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param idRessource_p
   * @param idLienAllocation_p
   * @param statut_p
   * @return
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, Nothing> ressourcePortP2PModifierStatutAllocation(Tracabilite tracabilite_p, String idRessource_p, String idLienAllocation_p, String statut_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param idRessource_p
   * @param motifMigration_p
   * @param referencePmBytel_p
   * @param referencePmOi_p
   * @param referenceBoitierPm_p
   * @param nomPmTechnique_p
   * @param nomPanneauPm_p
   * @param positionPortPm_p
   * @param technologiePON_p
   * @param idRessourceLie_p
   * @return
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, RessourcePortPM> ressourcePortPmGererMigrationPortPm(Tracabilite tracabilite_p, String idRessource_p, String motifMigration_p, String referencePmBytel_p, String referencePmOi_p, String referenceBoitierPm_p, String nomPmTechnique_p, String nomPanneauPm_p, Integer positionPortPm_p, String technologiePON_p, String idRessourceLie_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param idRRSource_p
   * @param idRRCible_p
   * @param action_p
   * @return
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, String> ressourceRaccordementCompositeGererAnalyserModifRR(Tracabilite tracabilite_p, String idRRSource_p, String idRRCible_p, String action_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param idRessource_p
   * @return
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, RessourceRaccordementComposite> ressourceRaccordementCompositeLireUn(Tracabilite tracabilite_p, String idRessource_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param ressource_p
   * @return
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, Nothing> ressourceRaccordementCreer(Tracabilite tracabilite_p, Ressource ressource_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param idRessource_p
   * @param codeAccesTechnique_p
   * @return
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, Nothing> ressourceRaccordementModifierCodeAccesTechnique(Tracabilite tracabilite_p, String idRessource_p, String codeAccesTechnique_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          tracabilite
   * @param idRessource_p
   *          idRessource
   * @param dateDerniereDeclarationOntInstalle_p
   *          dateDerniereDeclarationOntInstalle
   * @param typeTechnologiePon_p
   *          typeTechnologiePon
   * @param noSerieOntInstalle_p
   *          noSerieOntInstalle
   * @return ConnectorResponse<Retour, Nothing>
   * @throws RavelException
   *           In case of exception
   */
  ConnectorResponse<Retour, Nothing> ressourceRaccordementModifierOntInstalle(Tracabilite tracabilite_p, String idRessource_p, LocalDateTime dateDerniereDeclarationOntInstalle_p, String typeTechnologiePon_p, String noSerieOntInstalle_p) throws RavelException;

  /**
   * @param tracabilite_p
   * @param idRessource_p
   * @param idSt_p
   * @param statut_p
   * @return
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, Nothing> ressourceRaccordementModifierStatutAllocation(Tracabilite tracabilite_p, String idRessource_p, String idSt_p, String statut_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param structureVerticaleFtthComposite_p
   *          structureVerticaleFtthComposite
   * @return ConnectorResponse<Retour, Nothing>
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, Nothing> structureVerticaleFtthCompositeCreer(Tracabilite tracabilite_p, StructureVerticaleFtthComposite structureVerticaleFtthComposite_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param listeCoupleImbOi_p
   *          listeCoupleImbOi
   * @return ConnectorResponse<Retour, Nothing>
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, StructureVerticaleFtthComposite> structureVerticaleFtthCompositeLireTousParListeOIIMB(Tracabilite tracabilite_p, ListeCoupleImbOiRequest listeCoupleImbOi_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param idEqptAcces_p
   * @return
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, List<TopologieArcturus>> topologieArcturusLireTousParIdEqptAcces(Tracabilite tracabilite_p, String idEqptAcces_p) throws RavelException;

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param idNomCollecte_p
   *          valeurIdentifiant_p
   * @return ConnectorResponse<Retour, List<TopologieArcturus>>
   * @throws RavelException
   *           on error.
   */
  ConnectorResponse<Retour, TopologieArcturus> topologieArcturusLireUn(Tracabilite tracabilite_p, String idNomCollecte_p) throws RavelException;

}
