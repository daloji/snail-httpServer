/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.res.services;

import java.text.MessageFormat;
import java.time.Duration;
import java.util.List;
import java.util.Map;

import javax.ws.rs.HttpMethod;
import javax.ws.rs.core.Response;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.cache.CacheManager;
import com.bytel.ravel.common.cache.ICache;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.connector.RESTRequest;
import com.bytel.spirit.common.connectors.res.AbaqueDSLCacheLoader;
import com.bytel.spirit.common.connectors.res.IRESConnector;
import com.bytel.spirit.common.connectors.res.RESConnector;
import com.bytel.spirit.common.shared.misc.connectors.AbstractInternalRESTConnector;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.RetourConverter;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.AbaqueDSL;
import com.bytel.spirit.common.shared.saab.res.response.GetAbaqueDSLResponse;

/**
 * @author jpais
 * @version ($Revision$ $Date$)
 */
public class AbaqueDSLService
{
  /** The constant for PAD3016_AbaqueDSL.Read service name */
  public static final String METHOD_NAME_ABAQUE_DSL_LIRE_TOUS = "abaqueDslLireTous"; //$NON-NLS-1$

  /** Current RESConnector instance */
  private final RESConnector _resInstance;

  /**
   * Default constructor
   *
   * @param resInstance_p
   *          Current RESConnector instance
   */
  public AbaqueDSLService(RESConnector resInstance_p)
  {
    _resInstance = resInstance_p;
  }

  public ConnectorResponse<Retour, Map<String, List<AbaqueDSL>>> abaqueDslLireTous(Tracabilite tracabilite_p, Duration abaqueDslCacheDuration_p) throws RavelException
  {
    try
    {
      AbaqueDSLCacheLoader cacheLoader = new AbaqueDSLCacheLoader(tracabilite_p, abaqueDslCacheDuration_p);
      ICache<List<AbaqueDSL>> cache = (ICache<List<AbaqueDSL>>) CacheManager.getInstance().getCache(cacheLoader);

      if ((cache != null) && !cache.isEmpty())
      {
        return new ConnectorResponse<>(RetourFactory.createOkRetour(), cache.getFirstCache());
      }
      else
      {
        if (cacheLoader.getRetour() != null)
        {
          return new ConnectorResponse<>(cacheLoader.getRetour(), null);
        }
        else
        {
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.LECTURE_INDISPONIBLE, IRESConnector.MESSAGE_SERVICES_COM_CACHE), null);
        }
      }
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  public ConnectorResponse<Retour, List<AbaqueDSL>> loadAbaqueDslLireTous(Tracabilite tracabilite_p, String abaqueDslUrl_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(abaqueDslUrl_p))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(IRESConnector.MESSAGE_MISSING_CONFIGURATION_PARAMETER, IRESConnector.PAD3016_PATH_PARAM));
      }

      // Call SAAB
      final Response response;
      try
      {
        RESTRequest restRequest = new RESTRequest.RESTRequestBuilder()//
            .httpMethod(HttpMethod.GET)//
            .traceability(tracabilite_p)//
            .method(METHOD_NAME_ABAQUE_DSL_LIRE_TOUS)//
            .headers(AbstractInternalRESTConnector.getSpiritStarkRequestHeader())//
            .path(abaqueDslUrl_p)//
            .build();
        response = _resInstance.sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content
      GetAbaqueDSLResponse getAbaqueDSLResponse = _resInstance.getContentFromResponse(tracabilite_p, response, METHOD_NAME_ABAQUE_DSL_LIRE_TOUS, GetAbaqueDSLResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(getAbaqueDSLResponse.getRetour());
      List<AbaqueDSL> abaqueDslList = getAbaqueDSLResponse.getListeAbaqueDSL();

      return new ConnectorResponse<>(retour, abaqueDslList);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

}
