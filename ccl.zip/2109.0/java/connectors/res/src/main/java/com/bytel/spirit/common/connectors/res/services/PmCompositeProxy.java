/*******************************************************************************
* $Id: PmCompositeProxy.java 47970 2021-02-22 16:10:46Z pramos $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.res.services;

import java.util.Set;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.probes.AvgDoubleCollectorItem;
import com.bytel.ravel.common.probes.AvgFlowPerSecondCollector;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.services.connector.ConnectorManager;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.connectors.res.IRESConnector;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.CompteRenduSuppression;
import com.bytel.spirit.common.shared.saab.res.PMComposite;
import com.bytel.spirit.common.shared.saab.res.SurchargeBoitierPM;
import com.bytel.spirit.common.shared.saab.res.SurchargePM;
import com.bytel.spirit.common.shared.saab.res.SurchargePortPM;
import com.bytel.spirit.common.shared.types.json.response.PMConsultResponse;

/**
 * @author jiantila
 * @version ($Revision: 47970 $ $Date: 2021-02-22 17:10:46 +0100 (lun. 22 févr. 2021) $)
 */
public class PmCompositeProxy
{
  private final String _connectorId;

  private final AvgFlowPerSecondCollector _avgCallCounter;

  private final AvgDoubleCollectorItem _avgExecTime;

  /**
   * The constructor.
   *
   * @param connectorId_p
   *          the bean id of the connector.
   * @param avgCallCounter_p
   *          the object used to calculate the average number of calls of a method, per second.
   * @param avgExecTime_p
   *          the object used to calculate the average execution time of a method.
   */
  public PmCompositeProxy(String connectorId_p, AvgFlowPerSecondCollector avgCallCounter_p, AvgDoubleCollectorItem avgExecTime_p)
  {
    _avgCallCounter = avgCallCounter_p;
    _avgExecTime = avgExecTime_p;
    _connectorId = connectorId_p;
  }

  /**
   * Import a {@link PMComposite} to the DB.
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param pmComposite_p
   *          the {@link PMComposite} to be imported.
   * @param typeFluxImport_p
   *          Champ technique permettant de déterminer le type du flux d’import. Valeurs connues : - IMPORT_NOMINAL -
   *          VIE_DE_RESEAU
   * @return a {@link ConnectorResponse} with the {@link Retour} and {@link Nothing} (just because it needs to be a
   *         ConnectorResponse).
   * @throws RavelException
   *           if the SAAB call fails.
   */
  public ConnectorResponse<Retour, Nothing> gererImport(Tracabilite tracabilite_p, PMComposite pmComposite_p, String typeFluxImport_p) throws RavelException
  {
    IRESConnector resConnector;

    try
    {
      resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
    }
    catch (Exception e_p)
    {
      // Retour NOK
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
    }

    _avgCallCounter.measure();
    long startTime = System.currentTimeMillis();

    try
    {
      return resConnector.pmCompositeGererImport(tracabilite_p, pmComposite_p, typeFluxImport_p);
    }
    finally
    {
      long endTime = System.currentTimeMillis();
      _avgExecTime.updateAvgValue(endTime - startTime);
    }
  }

  /**
   * Remove all PMs from the DB whose name is not on the list.
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param listNomPM_p
   *          the list of names of PMs to keep.
   * @return a {@link ConnectorResponse} with the {@link Retour} and a set of {@link CompteRenduSuppression} for results
   *         of the suppression.
   * @throws RavelException
   *           if the SAAB call fails.
   */
  public ConnectorResponse<Retour, Set<CompteRenduSuppression>> gererSuppressionPMNonReference(Tracabilite tracabilite_p, Set<String> listNomPM_p) throws RavelException
  {
    IRESConnector resConnector;

    try
    {
      resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
    }
    catch (Exception e_p)
    {
      // Retour NOK
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
    }

    _avgCallCounter.measure();
    long startTime = System.currentTimeMillis();

    try
    {
      return resConnector.pmCompositeGererSuppressionPMNonReference(tracabilite_p, listNomPM_p);
    }
    finally
    {
      long endTime = System.currentTimeMillis();
      _avgExecTime.updateAvgValue(endTime - startTime);
    }
  }

  /**
   * Get a {@link SurchargeBoitierPM} (inside a {@link PMConsultResponse}) from the reference to the PM, the reference to
   * the "boitier" and the name of the "panneau".
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param referencePmBytel_p
   *          the Bytel reference to a PM.
   * @param referenceBoitierPm_p
   *          the reference to the "boitier" in the PM.
   * @param nomPanneau_p
   *          the name of the "panneau" in the boitier.
   * @param positionPortPM_p
   *          the position of the port in the "panneau".
   * @return a {@link ConnectorResponse} with the {@link Retour} and the {@link PMConsultResponse} obtained from the DB.
   * @throws RavelException
   *           if the SAAB call fails.
   */
  public ConnectorResponse<Retour, PMConsultResponse> lireSurchargeBoitierPM(Tracabilite tracabilite_p, String referencePmBytel_p, String referenceBoitierPm_p, String nomPanneau_p, String positionPortPM_p) throws RavelException
  {
    IRESConnector resConnector;

    try
    {
      resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
    }
    catch (Exception e_p)
    {
      // Retour NOK
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
    }

    _avgCallCounter.measure();
    long startTime = System.currentTimeMillis();

    try
    {
      return resConnector.pmCompositeLireSurchargeBoitierPM(tracabilite_p, referencePmBytel_p, referenceBoitierPm_p, nomPanneau_p, positionPortPM_p);
    }
    finally
    {
      long endTime = System.currentTimeMillis();
      _avgExecTime.updateAvgValue(endTime - startTime);
    }
  }

  /**
   * Get a {@link SurchargePM} (inside a {@link PMConsultResponse}) from the reference to the PM and the reference to the
   * "boitier".
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param referencePmBytel_p
   *          the Bytel reference to a PM.
   * @param referenceBoitierPm_p
   *          the reference to the "boitier" in the PM.
   * @param nomPanneau_p
   *          the name of the "panneau" in the boitier.
   * @param positionPortPM_p
   *          the position of the port in the "panneau".
   * @return a {@link ConnectorResponse} with the {@link Retour} and the {@link PMConsultResponse} obtained from the DB.
   * @throws RavelException
   *           if the SAAB call fails.
   */
  public ConnectorResponse<Retour, PMConsultResponse> lireSurchargePM(Tracabilite tracabilite_p, String referencePmBytel_p, String referenceBoitierPm_p, String nomPanneau_p, String positionPortPM_p) throws RavelException
  {
    IRESConnector resConnector;

    try
    {
      resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
    }
    catch (Exception e_p)
    {
      // Retour NOK
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
    }

    _avgCallCounter.measure();
    long startTime = System.currentTimeMillis();

    try
    {
      return resConnector.pmCompositeLireSurchargePM(tracabilite_p, referencePmBytel_p, referenceBoitierPm_p, nomPanneau_p, positionPortPM_p);
    }
    finally
    {
      long endTime = System.currentTimeMillis();
      _avgExecTime.updateAvgValue(endTime - startTime);
    }
  }

  /**
   * Get a {@link SurchargePortPM} (inside a {@link PMConsultResponse}) from the reference to the PM, the reference to the
   * "boitier", the name of the "panneau" and the position of the port.
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param referencePmBytel_p
   *          the Bytel reference to a PM.
   * @param referenceBoitierPm_p
   *          the reference to the "boitier" in the PM.
   * @param nomPanneau_p
   *          the name of the "panneau" in the boitier.
   * @param positionPortPM_p
   *          the position of the port in the "panneau".
   * @return a {@link ConnectorResponse} with the {@link Retour} and the {@link PMConsultResponse} obtained from the DB.
   * @throws RavelException
   *           if the SAAB call fails.
   */
  public ConnectorResponse<Retour, PMConsultResponse> lireSurchargePortPM(Tracabilite tracabilite_p, String referencePmBytel_p, String referenceBoitierPm_p, String nomPanneau_p, String positionPortPM_p) throws RavelException
  {
    IRESConnector resConnector;

    try
    {
      resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
    }
    catch (Exception e_p)
    {
      // Retour NOK
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
    }

    _avgCallCounter.measure();
    long startTime = System.currentTimeMillis();

    try
    {
      return resConnector.pmCompositeLireSurchargePortPM(tracabilite_p, referencePmBytel_p, referenceBoitierPm_p, nomPanneau_p, positionPortPM_p);
    }
    finally
    {
      long endTime = System.currentTimeMillis();
      _avgExecTime.updateAvgValue(endTime - startTime);
    }
  }

  /**
   * Get a {@link PMComposite} given its Bytel reference.
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param referencePmBytel_p
   *          the Bytel reference to a PM.
   * @return a {@link ConnectorResponse} with the {@link Retour} and the {@link PMComposite}.
   * @throws RavelException
   *           if the SAAB call fails.
   */
  public ConnectorResponse<Retour, PMComposite> lireUnParReferencePmBytel(Tracabilite tracabilite_p, String referencePmBytel_p) throws RavelException
  {
    IRESConnector resConnector;

    try
    {
      resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
    }
    catch (Exception e_p)
    {
      // Retour NOK
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
    }

    _avgCallCounter.measure();
    long startTime = System.currentTimeMillis();

    try
    {
      return resConnector.pmCompositeLireUnParReferencePmBytel(tracabilite_p, referencePmBytel_p);
    }
    finally
    {
      long endTime = System.currentTimeMillis();
      _avgExecTime.updateAvgValue(endTime - startTime);
    }
  }

  /**
   * Get a {@link PMComposite} given the reference to the OI of the PM.
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param referencePmOi_p
   *          the reference to the OI of the PM.
   * @return a {@link ConnectorResponse} with the {@link Retour} and the {@link PMComposite}.
   * @throws RavelException
   *           if the SAAB call fails.
   */
  public ConnectorResponse<Retour, PMComposite> lireUnParReferencePmOi(Tracabilite tracabilite_p, String referencePmOi_p) throws RavelException
  {
    IRESConnector resConnector;

    try
    {
      resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
    }
    catch (Exception e_p)
    {
      // Retour NOK
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
    }

    _avgCallCounter.measure();
    long startTime = System.currentTimeMillis();

    try
    {
      return resConnector.pmCompositeLireUnParReferencePmOi(tracabilite_p, referencePmOi_p);
    }
    finally
    {
      long endTime = System.currentTimeMillis();
      _avgExecTime.updateAvgValue(endTime - startTime);
    }
  }

  /**
   * Update an object "surcharge" of a given PM.
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param referencePmBytel_p
   *          the Bytel reference to a PM.
   * @return a {@link ConnectorResponse} with the {@link Retour} and {@link Nothing} (just because it needs to be a
   *         ConnectorResponse).
   * @throws RavelException
   *           if the SAAB call fails.
   */
  public ConnectorResponse<Retour, Nothing> modifierSurchargeDateDebutQuarantainePM(Tracabilite tracabilite_p, String referencePmBytel_p) throws RavelException
  {
    IRESConnector resConnector;

    try
    {
      resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
    }
    catch (Exception e_p)
    {
      // Retour NOK
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
    }

    _avgCallCounter.measure();
    long startTime = System.currentTimeMillis();

    try
    {
      return resConnector.pmCompositeModifierSurchargeDateDebutQuarantainePM(tracabilite_p, referencePmBytel_p);
    }
    finally
    {
      long endTime = System.currentTimeMillis();
      _avgExecTime.updateAvgValue(endTime - startTime);
    }
  }

  /**
   * Update an object "surcharge" of a given PM.
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param referencePmBytel_p
   *          the Bytel reference to a PM.
   * @param referenceBoitierPm_p
   *          the reference to the "boitier" in the PM.
   * @param nomPanneau_p
   *          the name of the "panneau" in the boitier.
   * @param positionPortPM_p
   *          the position of the port in the "panneau".
   * @param statutExploitation_p
   *          the status of "exploitation".
   * @param commentaireExploitation_p
   *          the comment of "exploitation".
   * @return a {@link ConnectorResponse} with the {@link Retour} and {@link Nothing} (just because it needs to be a
   *         ConnectorResponse).
   * @throws RavelException
   *           if the SAAB call fails.
   */
  public ConnectorResponse<Retour, Nothing> modifierSurchargeExploitationPortPM(Tracabilite tracabilite_p, String referencePmBytel_p, String referenceBoitierPm_p, String nomPanneau_p, String positionPortPM_p, String statutExploitation_p, String commentaireExploitation_p) throws RavelException
  {
    IRESConnector resConnector;

    try
    {
      resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
    }
    catch (Exception e_p)
    {
      // Retour NOK
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
    }

    _avgCallCounter.measure();
    long startTime = System.currentTimeMillis();

    try
    {
      return resConnector.pmCompositeModifierSurchargeExploitationPortPM(tracabilite_p, referencePmBytel_p, referenceBoitierPm_p, nomPanneau_p, positionPortPM_p, statutExploitation_p, commentaireExploitation_p);
    }
    finally
    {
      long endTime = System.currentTimeMillis();
      _avgExecTime.updateAvgValue(endTime - startTime);
    }
  }

  /**
   * Update an object "surcharge" of a given PM.
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param referencePmBytel_p
   *          the Bytel reference to a PM.
   * @param referenceBoitierPm_p
   *          the reference to the "boitier" in the PM.
   * @param statutBlocage_p
   *          the status of "blocage".
   * @param commentaireBlocage_p
   *          the comment of "blocage".
   * @return a {@link ConnectorResponse} with the {@link Retour} and {@link Nothing} (just because it needs to be a
   *         ConnectorResponse).
   * @throws RavelException
   *           if the SAAB call fails.
   */
  public ConnectorResponse<Retour, Nothing> modifierSurchargePriseClientBoitierPM(Tracabilite tracabilite_p, String referencePmBytel_p, String referenceBoitierPm_p, String statutBlocage_p, String commentaireBlocage_p) throws RavelException
  {
    IRESConnector resConnector;

    try
    {
      resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
    }
    catch (Exception e_p)
    {
      // Retour NOK
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
    }

    _avgCallCounter.measure();
    long startTime = System.currentTimeMillis();

    try
    {
      return resConnector.pmCompositeModifierSurchargePriseClientBoitierPM(tracabilite_p, referencePmBytel_p, referenceBoitierPm_p, statutBlocage_p, commentaireBlocage_p);
    }
    finally
    {
      long endTime = System.currentTimeMillis();
      _avgExecTime.updateAvgValue(endTime - startTime);
    }
  }

  /**
   * Update an object "surcharge" of a given PM.
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param referencePmBytel_p
   *          the Bytel reference to a PM.
   * @param statutBlocage_p
   *          the status of "blocage".
   * @param commentaireBlocage_p
   *          the comment of "blocage".
   * @return a {@link ConnectorResponse} with the {@link Retour} and {@link Nothing} (just because it needs to be a
   *         ConnectorResponse).
   * @throws RavelException
   *           if the SAAB call fails.
   */
  public ConnectorResponse<Retour, Nothing> modifierSurchargePriseClientPM(Tracabilite tracabilite_p, String referencePmBytel_p, String statutBlocage_p, String commentaireBlocage_p) throws RavelException
  {
    IRESConnector resConnector;

    try
    {
      resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
    }
    catch (Exception e_p)
    {
      // Retour NOK
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
    }

    _avgCallCounter.measure();
    long startTime = System.currentTimeMillis();

    try
    {
      return resConnector.pmCompositeModifierSurchargePriseClientPM(tracabilite_p, referencePmBytel_p, statutBlocage_p, commentaireBlocage_p);
    }
    finally
    {
      long endTime = System.currentTimeMillis();
      _avgExecTime.updateAvgValue(endTime - startTime);
    }
  }

  /**
   * Update an object "surcharge" of a given PM.
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param referencePmBytel_p
   *          the Bytel reference to a PM.
   * @param referenceBoitierPm_p
   *          the reference to the "boitier" in the PM.
   * @param nomPanneau_p
   *          the name of the "panneau" in the boitier.
   * @param positionPortPM_p
   *          the position of the port in the "panneau".
   * @param statutBlocage_p
   *          the status of "blocage".
   * @param commentaireBlocage_p
   *          the comment of "blocage".
   * @return a {@link ConnectorResponse} with the {@link Retour} and {@link Nothing} (just because it needs to be a
   *         ConnectorResponse).
   * @throws RavelException
   *           if the SAAB call fails.
   */
  public ConnectorResponse<Retour, Nothing> modifierSurchargePriseClientPortPM(Tracabilite tracabilite_p, String referencePmBytel_p, String referenceBoitierPm_p, String nomPanneau_p, String positionPortPM_p, String statutBlocage_p, String commentaireBlocage_p) throws RavelException
  {
    IRESConnector resConnector;

    try
    {
      resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
    }
    catch (Exception e_p)
    {
      // Retour NOK
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
    }

    _avgCallCounter.measure();
    long startTime = System.currentTimeMillis();

    try
    {
      return resConnector.pmCompositeModifierSurchargePriseClientPortPM(tracabilite_p, referencePmBytel_p, referenceBoitierPm_p, nomPanneau_p, positionPortPM_p, statutBlocage_p, commentaireBlocage_p);
    }
    finally
    {
      long endTime = System.currentTimeMillis();
      _avgExecTime.updateAvgValue(endTime - startTime);
    }
  }
}
