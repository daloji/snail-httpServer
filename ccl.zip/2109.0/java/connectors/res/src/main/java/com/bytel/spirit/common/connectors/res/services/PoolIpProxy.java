/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.res.services;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.probes.AvgDoubleCollectorItem;
import com.bytel.ravel.common.probes.AvgFlowPerSecondCollector;
import com.bytel.ravel.common.probes.RavelProbeConfigurationManager;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.services.connector.ConnectorManager;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.connectors.res.IRESConnector;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.PoolIP;

/**
 * @author acorreia
 * @version ($Revision$ $Date$)
 */
public class PoolIpProxy
{
  /** The connector instance */
  private final String _connectorId;

  /** For the probe to count the average execution time of a call to the poolIpGererImport operation. */
  AvgDoubleCollectorItem _poolIpGererImport_avgExecTime;

  /** For the probe to count the average amount of calls made to the poolIpGererImport operation, per second. */
  AvgFlowPerSecondCollector _poolIpGererImport_avgCallCounterSecond;

  /**
   * @param connectorId_p
   *          connectorId
   */
  public PoolIpProxy(String connectorId_p)
  {
    _connectorId = connectorId_p;

    _poolIpGererImport_avgExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("poolIpGererImport_avgExecTime", "RESProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _poolIpGererImport_avgCallCounterSecond = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("poolIpGererImport_callCounter", "RESProxy"); //$NON-NLS-1$ //$NON-NLS-2$
  }

  /**
   * Import a {@link PoolIP}.
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param poolIP_p
   *          the {@link PoolIP} being imported.
   * @return a pair with the retour and a Nothing (because it needs to be a pair).
   * @throws RavelException
   *           on error.
   */
  public ConnectorResponse<Retour, Nothing> gererImport(Tracabilite tracabilite_p, PoolIP poolIP_p) throws RavelException
  {
    IRESConnector resConnector;

    try
    {
      resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
    }
    catch (Exception e_p)
    {
      // Retour NOK
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
    }

    _poolIpGererImport_avgCallCounterSecond.measure();
    long startTime = System.currentTimeMillis();

    try
    {
      return resConnector.poolIpGererImport(tracabilite_p, poolIP_p);
    }
    finally
    {
      long endTime = System.currentTimeMillis();
      _poolIpGererImport_avgExecTime.updateAvgValue(endTime - startTime);
    }
  }
}
