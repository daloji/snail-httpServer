/*******************************************************************************
* $Id: OltCompositeProxy.java 47592 2021-02-15 11:14:10Z shwang $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.res.services;

import java.util.Set;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.probes.AvgDoubleCollectorItem;
import com.bytel.ravel.common.probes.AvgFlowPerSecondCollector;
import com.bytel.ravel.common.probes.RavelProbeConfigurationManager;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.services.connector.ConnectorManager;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.connectors.res.IRESConnector;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.CompteRenduSuppression;
import com.bytel.spirit.common.shared.saab.res.ListeTechnologieAutorisee;
import com.bytel.spirit.common.shared.saab.res.OltComposite;
import com.bytel.spirit.common.shared.saab.res.response.GetSurchargeResponse;

/**
 *
 * @author jiantila
 * @version ($Revision: 47592 $ $Date: 2021-02-15 12:14:10 +0100 (lun. 15 févr. 2021) $)
 */
public class OltCompositeProxy
{
  /** The connector instance */
  private String _connectorId;

  /** For probe to count the amount of call to the oltCompositeGererImport operation */
  AvgFlowPerSecondCollector _avg_oltCompositeGererImport_call_counter;
  /** For probe to count the execution time of call to the oltCompositeGererImport operation */
  AvgDoubleCollectorItem _avg_oltCompositeGererImport_ExecTime;

  /** For probe to count the amount of call to the oltCompositeGererSuppressionOltNonReference operation */
  AvgFlowPerSecondCollector _avg_oltCompositeGererSuppressionOltNonReference_call_counter;
  /** For probe to count the execution time of call to the oltCompositeGererSuppressionOltNonReference operation */
  AvgDoubleCollectorItem _avg_oltCompositeGererSuppressionOltNonReference_ExecTime;

  /** For probe to count the amount of call to the oltCompositeLireSurchage operation */
  AvgFlowPerSecondCollector _avg_oltCompositeLireSurchage_call_counter;
  /** For probe to count the execution time of call to the oltCompositeLireSurchage operation */
  AvgDoubleCollectorItem _avg_oltCompositeLireSurchage_ExecTime;

  /** For probe to count the amount of call to the oltCompositeLireUn operation */
  AvgFlowPerSecondCollector _avg_oltCompositeLireUn_call_counter;
  /** For probe to count the execution time of call to the oltCompositeLireUn operation */
  AvgDoubleCollectorItem _avg_oltCompositeLireUn_ExecTime;

  /** For probe to count the amount of call to the oltCompositeModifierSurchargeDebitGarantiPortPon operation */
  AvgFlowPerSecondCollector _avg_oltCompositeModifierSurchargeDebitGarantiPortPon_call_counter;
  /** For probe to count the execution time of call to the oltCompositeModifierSurchargeDebitGarantiPortPon operation */
  AvgDoubleCollectorItem _avg_oltCompositeModifierSurchargeDebitGarantiPortPon_ExecTime;

  /** For probe to count the amount of call to the oltCompositeModifierSurchargeExploitationOntId operation */
  AvgFlowPerSecondCollector _avg_oltCompositeModifierSurchargeExploitationOntId_call_counter;
  /** For probe to count the execution time of call to the oltCompositeModifierSurchargeExploitationOntId operation */
  AvgDoubleCollectorItem _avg_oltCompositeModifierSurchargeExploitationOntId_ExecTime;

  /** For probe to count the amount of call to the oltCompositeModifierSurchargePriseClientCarte operation */
  AvgFlowPerSecondCollector _avg_oltCompositeModifierSurchargePriseClientCarte_call_counter;
  /** For probe to count the execution time of call to the oltCompositeModifierSurchargePriseClientCarte operation */
  AvgDoubleCollectorItem _avg_oltCompositeModifierSurchargePriseClientCarte_ExecTime;

  /** For probe to count the amount of call to the oltCompositeModifierSurchargePriseClientOLT operation */
  AvgFlowPerSecondCollector _avg_oltCompositeModifierSurchargePriseClientOLT_call_counter;
  /** For probe to count the execution time of call to the oltCompositeModifierSurchargePriseClientOLT operation */
  AvgDoubleCollectorItem _avg_oltCompositeModifierSurchargePriseClientOLT_ExecTime;

  /** For probe to count the amount of call to the oltCompositeModifierSurchargePriseClientOntId operation */
  AvgFlowPerSecondCollector _avg_oltCompositeModifierSurchargePriseClientOntId_call_counter;
  /** For probe to count the execution time of call to the oltCompositeModifierSurchargePriseClientOntId operation */
  AvgDoubleCollectorItem _avg_oltCompositeModifierSurchargePriseClientOntId_ExecTime;

  /** For probe to count the amount of call to the oltCompositeModifierSurchargePriseClientPortPon operation */
  AvgFlowPerSecondCollector _avg_oltCompositeModifierSurchargePriseClientPortPon_call_counter;
  /** For probe to count the execution time of call to the oltCompositeModifierSurchargePriseClientPortPon operation */
  AvgDoubleCollectorItem _avg_oltCompositeModifierSurchargePriseClientPortPon_ExecTime;

  /** For probe to count the amount of call to the oltCompositeModifierSurchargeTechnoAutoriseePortPon operation */
  AvgFlowPerSecondCollector _avg_oltCompositeModifierSurchargeTechnoAutoriseePortPon_call_counter;
  /**
   * For probe to count the execution time of call to the oltCompositeModifierSurchargeTechnoAutoriseePortPon operation
   */
  AvgDoubleCollectorItem _avg_oltCompositeModifierSurchargeTechnoAutoriseePortPon_ExecTime;

  /** For probe to count the amount of call to the oltCompositeModifierSurchargeVersionOLT operation */
  AvgFlowPerSecondCollector _avg_oltCompositeModifierSurchargeVersionOLT_call_counter;
  /** For probe to count the execution time of call to the oltCompositeModifierSurchargeVersionOLT operation */
  AvgDoubleCollectorItem _avg_oltCompositeModifierSurchargeVersionOLT_ExecTime;

  /** For probe to count the amount of call to the oltCompositemodifierSurchargeDateDebutQuarantaineOLT operation */
  AvgFlowPerSecondCollector _avg_oltCompositemodifierSurchargeDateDebutQuarantaineOLT_call_counter;
  /**
   * For probe to count the execution time of call to the oltCompositemodifierSurchargeDateDebutQuarantaineOLT operation
   */
  AvgDoubleCollectorItem _avg_oltCompositemodifierSurchargeDateDebutQuarantaineOLT_ExecTime;

  /**
   * @param connectorId_p
   */
  public OltCompositeProxy(String connectorId_p)
  {
    _connectorId = connectorId_p;

    _avg_oltCompositeGererImport_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_oltCompositeGererImport_call_counter", "RESProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_oltCompositeGererImport_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_oltCompositeGererImport_ExecTime", "RESProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_oltCompositeGererSuppressionOltNonReference_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_oltCompositeGererSuppressionOltNonReference_call_counter", "RESProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_oltCompositeGererSuppressionOltNonReference_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_oltCompositeGererSuppressionOltNonReference_ExecTime", "RESProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_oltCompositeLireSurchage_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_oltCompositeLireSurchage_call_counter", "RESProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_oltCompositeLireSurchage_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_oltCompositeLireSurchage_ExecTime", "RESProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_oltCompositeLireUn_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_oltCompositeLireUn_call_counter", "RESProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_oltCompositeLireUn_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_oltCompositeLireUn_ExecTime", "RESProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_oltCompositeModifierSurchargeDebitGarantiPortPon_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_oltCompositeModifierSurchargeDebitGarantiPortPon_call_counter", "RESProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_oltCompositeModifierSurchargeDebitGarantiPortPon_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_oltCompositeModifierSurchargeDebitGarantiPortPon_ExecTime", "RESProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_oltCompositeModifierSurchargeExploitationOntId_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_oltCompositeModifierSurchargeExploitationOntId_call_counter", "RESProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_oltCompositeModifierSurchargeExploitationOntId_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_oltCompositeModifierSurchargeExploitationOntId_ExecTime", "RESProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_oltCompositeModifierSurchargePriseClientCarte_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_oltCompositeModifierSurchargePriseClientCarte_call_counter", "RESProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_oltCompositeModifierSurchargePriseClientCarte_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_oltCompositeModifierSurchargePriseClientCarte_ExecTime", "RESProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_oltCompositeModifierSurchargePriseClientOLT_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_oltCompositeModifierSurchargePriseClientOLT_call_counter", "RESProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_oltCompositeModifierSurchargePriseClientOLT_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_oltCompositeModifierSurchargePriseClientOLT_ExecTime", "RESProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_oltCompositeModifierSurchargePriseClientOntId_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_oltCompositeModifierSurchargePriseClientOntId_call_counter", "RESProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_oltCompositeModifierSurchargePriseClientOntId_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_oltCompositeModifierSurchargePriseClientOntId_ExecTime", "RESProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_oltCompositeModifierSurchargePriseClientPortPon_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_oltCompositeModifierSurchargePriseClientPortPon_call_counter", "RESProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_oltCompositeModifierSurchargePriseClientPortPon_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_oltCompositeModifierSurchargePriseClientPortPon_ExecTime", "RESProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_oltCompositeModifierSurchargeTechnoAutoriseePortPon_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_oltCompositeModifierSurchargeTechnoAutoriseePortPon_call_counter", "RESProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_oltCompositeModifierSurchargeTechnoAutoriseePortPon_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_oltCompositeModifierSurchargeTechnoAutoriseePortPon_ExecTime", "RESProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_oltCompositeModifierSurchargeVersionOLT_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_oltCompositeModifierSurchargeVersionOLT_call_counter", "RESProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_oltCompositeModifierSurchargeVersionOLT_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_oltCompositeModifierSurchargeVersionOLT_ExecTime", "RESProxy"); //$NON-NLS-1$ //$NON-NLS-2$
   _avg_oltCompositemodifierSurchargeDateDebutQuarantaineOLT_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_oltCompositemodifierSurchargeDateDebutQuarantaineOLT_call_counter", "RESProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_oltCompositemodifierSurchargeDateDebutQuarantaineOLT_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_oltCompositemodifierSurchargeDateDebutQuarantaineOLT_ExecTime", "RESProxy"); //$NON-NLS-1$ //$NON-NLS-2$

  }

  /**
   * @param tracabilite_p
   * @param oltComposite_p
   * @return
   * @throws RavelException
   */
  public ConnectorResponse<Retour, Nothing> oltCompositeGererImport(Tracabilite tracabilite_p, OltComposite oltComposite_p) throws RavelException
  {
    IRESConnector resConnector = null;
    try
    {
      resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
    }
    catch (Exception e_p)
    {
      // Retour NOK
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
    }
    _avg_oltCompositeGererImport_call_counter.measure();
    long startTime = System.currentTimeMillis();
    try
    {
      return resConnector.oltCompositeGererImport(tracabilite_p, oltComposite_p);
    }
    finally
    {
      long endTime = System.currentTimeMillis();
      _avg_oltCompositeGererImport_ExecTime.updateAvgValue(endTime - startTime);
    }
  }

  public ConnectorResponse<Retour, Set<CompteRenduSuppression>> oltCompositeGererSuppressionOltNonReference(Tracabilite tracabilite_p, Set<String> listeNomOLT_p) throws RavelException
  {
    IRESConnector resConnector = null;
    try
    {
      resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
    }
    catch (Exception e_p)
    {
      // Retour NOK
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
    }
    _avg_oltCompositeGererSuppressionOltNonReference_call_counter.measure();
    long startTime = System.currentTimeMillis();
    try
    {
      return resConnector.oltCompositeGererSuppressionOltNonReference(tracabilite_p, listeNomOLT_p);
    }
    finally
    {
      long endTime = System.currentTimeMillis();
      _avg_oltCompositeGererSuppressionOltNonReference_ExecTime.updateAvgValue(endTime - startTime);
    }
  }

  /**
   * Ce service permet de consulter un « OltComposite » à partir du nom de l’OLT. ou spécifiquement l'un de ses
   * sous-objets "surcharge".
   *
   * @param tracabilite_p
   *          tracabilite
   * @param nomOLT_p
   *          nom olt
   * @param action_p
   *          action
   * @param positionCarte_p
   *          position carte
   * @param positionPortPon_p
   *          position port pon
   * @param positionOntId_p
   *          position ont id
   * @return ConnectorResponse<Retour, GetOltSurchargeResponse>
   * @throws RavelException
   *           exception
   */
  public ConnectorResponse<Retour, GetSurchargeResponse> oltCompositeLireSurchage(Tracabilite tracabilite_p, String nomOLT_p, String action_p, String positionCarte_p, String positionPortPon_p, String positionOntId_p) throws RavelException
  {
    IRESConnector resConnector = null;
    try
    {
      resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
    }
    catch (Exception e_p)
    {
      // Retour NOK
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
    }
    _avg_oltCompositeLireSurchage_call_counter.measure();
    long startTime = System.currentTimeMillis();
    try
    {
      return resConnector.oltCompositeLireSurchage(tracabilite_p, nomOLT_p, action_p, positionCarte_p, positionPortPon_p, positionOntId_p);
    }
    finally
    {
      long endTime = System.currentTimeMillis();
      _avg_oltCompositeLireSurchage_ExecTime.updateAvgValue(endTime - startTime);
    }
  }

  public ConnectorResponse<Retour, OltComposite> oltCompositeLireUn(Tracabilite tracabilite_p, String nomOLT_p) throws RavelException
  {
    IRESConnector resConnector = null;
    try
    {
      resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
    }
    catch (Exception e_p)
    {
      // Retour NOK
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
    }
    _avg_oltCompositeLireUn_call_counter.measure();
    long startTime = System.currentTimeMillis();
    try
    {
      return resConnector.oltCompositeLireUn(tracabilite_p, nomOLT_p);
    }
    finally
    {
      long endTime = System.currentTimeMillis();
      _avg_oltCompositeLireUn_ExecTime.updateAvgValue(endTime - startTime);
    }
  }

  /**
   * @param tracabilite_p
   * @param nomOlt_p
   * @param positionCarte_p
   * @param positionPortPon_p
   * @param debitGarantieCapaciteAllouee_p
   * @return
   * @throws RavelException
   */
  public ConnectorResponse<Retour, Nothing> oltCompositeModifierSurchargeDebitGarantiPortPon(Tracabilite tracabilite_p, String nomOlt_p, String positionCarte_p, String positionPortPon_p, String debitGarantieCapaciteAllouee_p) throws RavelException
  {
    IRESConnector resConnector = null;
    try
    {
      resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
    }
    catch (Exception e_p)
    {
      // Retour NOK
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
    }
    _avg_oltCompositeModifierSurchargeDebitGarantiPortPon_call_counter.measure();
    long startTime = System.currentTimeMillis();
    try
    {
      return resConnector.oltCompositeModifierSurchargeDebitGarantiPortPon(tracabilite_p, nomOlt_p, positionCarte_p, positionPortPon_p, debitGarantieCapaciteAllouee_p);
    }
    finally
    {
      long endTime = System.currentTimeMillis();
      _avg_oltCompositeModifierSurchargeDebitGarantiPortPon_ExecTime.updateAvgValue(endTime - startTime);
    }
  }

  /**
   * @param tracabilite_p
   * @param nomOlt_p
   * @param positionCarte_p
   * @param positionPortPon_p
   * @param positionOntId_p
   * @param statutExploitation_p
   * @param commentaireExploitation_p
   * @return
   * @throws RavelException
   */
  public ConnectorResponse<Retour, Nothing> oltCompositeModifierSurchargeExploitationOntId(Tracabilite tracabilite_p, String nomOlt_p, String positionCarte_p, String positionPortPon_p, String positionOntId_p, String statutExploitation_p, String commentaireExploitation_p) throws RavelException
  {
    IRESConnector resConnector = null;
    try
    {
      resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
    }
    catch (Exception e_p)
    {
      // Retour NOK
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
    }
    _avg_oltCompositeModifierSurchargeExploitationOntId_call_counter.measure();
    long startTime = System.currentTimeMillis();
    try
    {
      return resConnector.oltCompositeModifierSurchargeExploitationOntId(tracabilite_p, nomOlt_p, positionCarte_p, positionPortPon_p, positionOntId_p, statutExploitation_p, commentaireExploitation_p);
    }
    finally
    {
      long endTime = System.currentTimeMillis();
      _avg_oltCompositeModifierSurchargeExploitationOntId_ExecTime.updateAvgValue(endTime - startTime);
    }
  }

  /**
   * @param tracabilite_p
   * @param nomOlt_p
   * @param positionCarte_p
   * @param statutBlocage_p
   * @param commentaireBlocage_p
   * @return
   * @throws RavelException
   */
  public ConnectorResponse<Retour, Nothing> oltCompositeModifierSurchargePriseClientCarte(Tracabilite tracabilite_p, String nomOlt_p, String positionCarte_p, String statutBlocage_p, String commentaireBlocage_p) throws RavelException
  {
    IRESConnector resConnector = null;
    try
    {
      resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
    }
    catch (Exception e_p)
    {
      // Retour NOK
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
    }
    _avg_oltCompositeModifierSurchargePriseClientCarte_call_counter.measure();
    long startTime = System.currentTimeMillis();
    try
    {
      return resConnector.oltCompositeModifierSurchargePriseClientCarte(tracabilite_p, nomOlt_p, positionCarte_p, statutBlocage_p, commentaireBlocage_p);
    }
    finally
    {
      long endTime = System.currentTimeMillis();
      _avg_oltCompositeModifierSurchargePriseClientCarte_ExecTime.updateAvgValue(endTime - startTime);
    }
  }

  /**
   * @param tracabilite_p
   * @param nomOlt_p
   * @param statutBlocage_p
   * @param commentaireBlocage_p
   * @return
   * @throws RavelException
   */
  public ConnectorResponse<Retour, Nothing> oltCompositeModifierSurchargePriseClientOLT(Tracabilite tracabilite_p, String nomOlt_p, String statutBlocage_p, String commentaireBlocage_p) throws RavelException
  {
    IRESConnector resConnector = null;
    try
    {
      resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
    }
    catch (Exception e_p)
    {
      // Retour NOK
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
    }
    _avg_oltCompositeModifierSurchargePriseClientOLT_call_counter.measure();
    long startTime = System.currentTimeMillis();
    try
    {
      return resConnector.oltCompositeModifierSurchargePriseClientOLT(tracabilite_p, nomOlt_p, statutBlocage_p, commentaireBlocage_p);
    }
    finally
    {
      long endTime = System.currentTimeMillis();
      _avg_oltCompositeModifierSurchargePriseClientOLT_ExecTime.updateAvgValue(endTime - startTime);
    }
  }

  /**
   * @param tracabilite_p
   * @param nomOlt_p
   * @param positionCarte_p
   * @param positionPortPon_p
   * @param positionOntId_p
   * @param statutBlocage_p
   * @param commentaireBlocage_p
   * @return
   * @throws RavelException
   */
  public ConnectorResponse<Retour, Nothing> oltCompositeModifierSurchargePriseClientOntId(Tracabilite tracabilite_p, String nomOlt_p, String positionCarte_p, String positionPortPon_p, String positionOntId_p, String statutBlocage_p, String commentaireBlocage_p) throws RavelException
  {
    IRESConnector resConnector = null;
    try
    {
      resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
    }
    catch (Exception e_p)
    {
      // Retour NOK
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
    }
    _avg_oltCompositeModifierSurchargePriseClientOntId_call_counter.measure();
    long startTime = System.currentTimeMillis();
    try
    {
      return resConnector.oltCompositeModifierSurchargePriseClientOntId(tracabilite_p, nomOlt_p, positionCarte_p, positionPortPon_p, positionOntId_p, statutBlocage_p, commentaireBlocage_p);
    }
    finally
    {
      long endTime = System.currentTimeMillis();
      _avg_oltCompositeModifierSurchargePriseClientOntId_ExecTime.updateAvgValue(endTime - startTime);
    }
  }

  /**
   * @param tracabilite_p
   * @param nomOlt_p
   * @param positionCarte_p
   * @param positionPortPon_p
   * @param statutBlocage_p
   * @param commentaireBlocage_p
   * @return
   * @throws RavelException
   */
  public ConnectorResponse<Retour, Nothing> oltCompositeModifierSurchargePriseClientPortPon(Tracabilite tracabilite_p, String nomOlt_p, String positionCarte_p, String positionPortPon_p, String statutBlocage_p, String commentaireBlocage_p) throws RavelException
  {
    IRESConnector resConnector = null;
    try
    {
      resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
    }
    catch (Exception e_p)
    {
      // Retour NOK
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
    }
    _avg_oltCompositeModifierSurchargePriseClientPortPon_call_counter.measure();
    long startTime = System.currentTimeMillis();
    try
    {
      return resConnector.oltCompositeModifierSurchargePriseClientPortPon(tracabilite_p, nomOlt_p, positionCarte_p, positionPortPon_p, statutBlocage_p, commentaireBlocage_p);
    }
    finally
    {
      long endTime = System.currentTimeMillis();
      _avg_oltCompositeModifierSurchargePriseClientPortPon_ExecTime.updateAvgValue(endTime - startTime);
    }
  }

  /**
   * @param tracabilite_p
   * @param listTechnoAutorisee_p
   * @param nomOlt_p
   * @param positionCarte_p
   * @param positionPortPon_p
   * @return
   * @throws RavelException
   */
  public ConnectorResponse<Retour, Nothing> oltCompositeModifierSurchargeTechnoAutoriseePortPon(Tracabilite tracabilite_p, ListeTechnologieAutorisee listTechnoAutorisee_p, String nomOlt_p, String positionCarte_p, String positionPortPon_p) throws RavelException
  {
    IRESConnector resConnector = null;
    try
    {
      resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
    }
    catch (Exception e_p)
    {
      // Retour NOK
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
    }
    _avg_oltCompositeModifierSurchargeTechnoAutoriseePortPon_call_counter.measure();
    long startTime = System.currentTimeMillis();
    try
    {
      return resConnector.oltCompositeModifierSurchargeTechnoAutoriseePortPon(tracabilite_p, listTechnoAutorisee_p, nomOlt_p, positionCarte_p, positionPortPon_p);
    }
    finally
    {
      long endTime = System.currentTimeMillis();
      _avg_oltCompositeModifierSurchargeTechnoAutoriseePortPon_ExecTime.updateAvgValue(endTime - startTime);
    }
  }

  /**
   * @param tracabilite_p
   * @param listTechnoAutorisee_p
   * @param nomOlt_p
   * @param versionInterfaceEchange_p
   * @return
   * @throws RavelException
   */
  public ConnectorResponse<Retour, Nothing> oltCompositeModifierSurchargeVersionOLT(Tracabilite tracabilite_p, ListeTechnologieAutorisee listTechnoAutorisee_p, String nomOlt_p, String versionInterfaceEchange_p) throws RavelException
  {
    IRESConnector resConnector = null;
    try
    {
      resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
    }
    catch (Exception e_p)
    {
      // Retour NOK
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
    }
    _avg_oltCompositeModifierSurchargeVersionOLT_call_counter.measure();
    long startTime = System.currentTimeMillis();
    try
    {
      return resConnector.oltCompositeModifierSurchargeVersionOLT(tracabilite_p, listTechnoAutorisee_p, nomOlt_p, versionInterfaceEchange_p);
    }
    finally
    {
      long endTime = System.currentTimeMillis();
      _avg_oltCompositeModifierSurchargeVersionOLT_ExecTime.updateAvgValue(endTime - startTime);
    }
  }

  public ConnectorResponse<Retour, Nothing> oltCompositemodifierSurchargeDateDebutQuarantaineOLT(Tracabilite tracabilite_p, ListeTechnologieAutorisee listTechnoAutorisee_p, String nomOlt_p) throws RavelException
  {
    IRESConnector resConnector = null;
    try
    {
      resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
    }
    catch (Exception e_p)
    {
      // Retour NOK
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
    }
    _avg_oltCompositemodifierSurchargeDateDebutQuarantaineOLT_call_counter.measure();
    long startTime = System.currentTimeMillis();
    try
    {
      return resConnector.oltCompositemodifierSurchargeDateDebutQuarantaineOLT(tracabilite_p, listTechnoAutorisee_p, nomOlt_p);
    }
    finally
    {
      long endTime = System.currentTimeMillis();
      _avg_oltCompositemodifierSurchargeDateDebutQuarantaineOLT_ExecTime.updateAvgValue(endTime - startTime);
    }
  }
}
