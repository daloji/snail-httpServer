/*******************************************************************************
 * $Id: PmCompositeService.java 49682 2021-03-24 13:30:21Z fbarnabe $
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.res.services;

import java.text.MessageFormat;
import java.util.HashMap;
import java.util.Set;

import javax.ws.rs.HttpMethod;
import javax.ws.rs.core.Response;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.json.IRavelJson;
import com.bytel.ravel.common.json.RavelJson;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.connector.RESTRequest;
import com.bytel.ravel.services.connector.RESTRequest.RESTRequestBuilder;
import com.bytel.spirit.common.connectors.res.IRESConnector;
import com.bytel.spirit.common.connectors.res.RESConnector;
import com.bytel.spirit.common.shared.misc.connectors.AbstractInternalRESTConnector;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.BasicResponse;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.ressources.RetourConverter;
import com.bytel.spirit.common.shared.misc.ressources.SpiritConstants;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.CompteRenduSuppression;
import com.bytel.spirit.common.shared.saab.res.PMComposite;
import com.bytel.spirit.common.shared.saab.res.SurchargeBoitierPM;
import com.bytel.spirit.common.shared.saab.res.SurchargePM;
import com.bytel.spirit.common.shared.saab.res.SurchargePortPM;
import com.bytel.spirit.common.shared.saab.res.request.ManagePmCompositeRequest;
import com.bytel.spirit.common.shared.saab.res.response.ListeCRSupressionResponse;
import com.bytel.spirit.common.shared.types.json.response.PMConsultResponse;

/**
 * The service that contains all connector methods related to the PMComposite.
 *
 * @author jiantila
 * @version ($Revision: 49682 $ $Date: 2021-03-24 14:30:21 +0100 (mer. 24 mars 2021) $)
 */
public class PmCompositeService
{
  public interface IMethodName
  {
    String PM_COMPOSITE_GERER_IMPORT = "pmCompositeGererImport"; //$NON-NLS-1$
    String PM_COMPOSITE_GERER_SUPPRESSION_PM_NON_REF = "pmCompositeGererSuppressionPMNonReference"; //$NON-NLS-1$
    String PM_COMPOSITE_LIRE_SURCHAGE_BOITIER_PM = "pmCompositeLireSurchargeBoitierPM"; //$NON-NLS-1$
    String PM_COMPOSITE_LIRE_SURCHAGE_PM = "pmCompositeLireSurchargePM"; //$NON-NLS-1$
    String PM_COMPOSITE_LIRE_SURCHAGE_PORT_PM = "pmCompositeLireSurchargePortPM"; //$NON-NLS-1$
    String PM_COMPOSITE_LIRE_UN_PAR_REF_PM_BYTEL = "pmCompositeLireUnParReferencePmBytel"; //$NON-NLS-1$
    String PM_COMPOSITE_LIRE_UN_PAR_REF_PM_OI = "pmCompositeLireUnParReferencePmOi"; //$NON-NLS-1$
    String PM_COMPOSITE_MODIFIER_SURCHARGE_DATE_DEBUT_QUARANTAINE_PM = "pmcompositeModifierSurchargeDateDebutQuarantainePM"; //$NON-NLS-1$
    String PM_COMPOSITE_MODIFIER_SURCHARGE_EXPLOITATION_PORT_PM = "pmCompositeModifierSurchargeExploitationPortPM"; //$NON-NLS-1$
    String PM_COMPOSITE_MODIFIER_SURCHARGE_PRISE_CLIENT_BOITIER_PM = "pmCompositeModifierSurchargePriseClientBoitierPM"; //$NON-NLS-1$
    String PM_COMPOSITE_MODIFIER_SURCHARGE_PRISE_CLIENT_PM = "pmCompositeModifierSurchargePriseClientPM"; //$NON-NLS-1$
    String PM_COMPOSITE_MODIFIER_SURCHARGE_PRISE_CLIENT_PORT_PM = "pmCompositeModifierSurchargePriseClientPortPM"; //$NON-NLS-1$
  }

  interface IAction
  {
    String LIRE_SURCHARGE_PM = "LireSurchargePM"; //$NON-NLS-1$
    String LIRE_SURCHARGE_PORT_PM = "LireSurchargePortPM"; //$NON-NLS-1$
    String LIRE_SURCHARGE_BOITIER_PM = "LireSurchargeBoitierPM"; //$NON-NLS-1$

    String MODIFIER_SURCHARGE_EXPLOITATION_PORT_PM = "ModifierSurChargeExploitationPortPM"; //$NON-NLS-1$
    String MODIFIER_SURCHARGE_PRISE_CLIENT_BOITIER_PM = "ModifierSurChargePriseClientBoitierPM"; //$NON-NLS-1$
    String MODIFIER_SURCHARGE_PRISE_CLIENT_PM = "ModifierSurChargePriseClientPM"; //$NON-NLS-1$
    String MODIFIER_SURCHARGE_PRISE_CLIENT_PORT_PM = "ModifierSurChargePriseClientPortPM"; //$NON-NLS-1$
    String MODIFIER_SURCHARGE_DATE_DEBUT_QUARANTAINE_PM = "ModifierSurChargeDateDebutQuarantainePM";
  }

  /**
   * Used for the serialization of the objects.
   */
  private final IRavelJson _jsonBuilder;

  private final RESConnector _resInstance;

  /**
   * @param resInstance_p
   *          {@link RESConnector}
   */
  public PmCompositeService(RESConnector resInstance_p)
  {
    _resInstance = resInstance_p;
    _jsonBuilder = new RavelJson.RavelJsonBuilder().profil(SpiritConstants.JSON_PROFILE_STARK).build();
  }

  /**
   * Import a {@link PMComposite} to the DB.
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param pmCompositeUrl_p
   *          the url to the corresponding endpoint in SAAB.
   * @param pmComposite_p
   *          the {@link PMComposite} to be imported.
   * @return a {@link ConnectorResponse} with the {@link Retour} and {@link Nothing} (just because it needs to be a
   *         ConnectorResponse).
   */
  public ConnectorResponse<Retour, Nothing> gererImport(Tracabilite tracabilite_p, String pmCompositeUrl_p, PMComposite pmComposite_p, String typeFluxImport_p)
  {
    try
    {
      if (StringTools.isNullOrEmpty(pmCompositeUrl_p))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(IRESConnector.MESSAGE_MISSING_CONFIGURATION_PARAMETER, IRESConnector.PAD3205_PATH_PARAM));
      }

      // Query parameters
      HashMap<String, String> queryParams = new HashMap<>();
      queryParams.put(IRESConnector.PARAM_ACTION, IRESConnector.ACTION_GERER_IMPORT);
      if (StringTools.isNotNullOrEmpty(typeFluxImport_p))
      {
        queryParams.put(IRESConnector.PARAM_TYPE_FLUX_IMPORT, typeFluxImport_p);
      }
      // Call SAAB
      final Response response;
      try
      {
        ManagePmCompositeRequest request = new ManagePmCompositeRequest(pmComposite_p);

        RESTRequest restRequest = new RESTRequestBuilder() //
            .httpMethod(HttpMethod.PUT) //
            .request(request) //
            .serializer(_jsonBuilder) //
            .traceability(tracabilite_p) //
            .method(IMethodName.PM_COMPOSITE_GERER_IMPORT) //
            .headers(AbstractInternalRESTConnector.getSpiritStarkRequestHeader()) //
            .path(pmCompositeUrl_p) //
            .queryParameter(queryParams) //
            .build();

        response = _resInstance.sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the response object
      ListeCRSupressionResponse manageResponse = _resInstance.getContentFromResponse(tracabilite_p, response, IMethodName.PM_COMPOSITE_GERER_IMPORT, ListeCRSupressionResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(manageResponse.getRetour());
      return new ConnectorResponse<>(retour, null);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  /**
   * Remove all PMs from the DB whose name is not on the list.
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param pmCompositeUrl_p
   *          the url to the corresponding endpoint in SAAB.
   * @param listNomPM_p
   *          the list of names of PMs to keep.
   * @return a {@link ConnectorResponse} with the {@link Retour} and a set of {@link CompteRenduSuppression} for results
   *         of the suppression.
   */
  public ConnectorResponse<Retour, Set<CompteRenduSuppression>> gererSuppressionPMNonReference(Tracabilite tracabilite_p, String pmCompositeUrl_p, Set<String> listNomPM_p)
  {
    try
    {
      if (StringTools.isNullOrEmpty(pmCompositeUrl_p))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(IRESConnector.MESSAGE_MISSING_CONFIGURATION_PARAMETER, IRESConnector.PAD3205_PATH_PARAM));
      }

      // Query parameters
      HashMap<String, String> queryParams = new HashMap<>();
      queryParams.put(IRESConnector.PARAM_ACTION, IRESConnector.ACTION_GERER_SUPPRESSION_PM_NON_REFERENCE);

      // Call SAAB
      final Response response;
      try
      {
        ManagePmCompositeRequest request = new ManagePmCompositeRequest(listNomPM_p);

        RESTRequest restRequest = new RESTRequestBuilder() //
            .httpMethod(HttpMethod.PUT) //
            .request(request) //
            .serializer(_jsonBuilder) //
            .traceability(tracabilite_p) //
            .method(IMethodName.PM_COMPOSITE_GERER_SUPPRESSION_PM_NON_REF) //
            .headers(AbstractInternalRESTConnector.getSpiritStarkRequestHeader()) //
            .path(pmCompositeUrl_p) //
            .queryParameter(queryParams) //
            .build();

        response = _resInstance.sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the response object
      ListeCRSupressionResponse repCompteRenduSuppression = _resInstance.getContentFromResponse(tracabilite_p, response, IMethodName.PM_COMPOSITE_GERER_SUPPRESSION_PM_NON_REF, ListeCRSupressionResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(repCompteRenduSuppression.getRetour());
      Set<CompteRenduSuppression> listcompteRendu = repCompteRenduSuppression.getListeCompteRenduSupression();
      return new ConnectorResponse<>(retour, listcompteRendu);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  /**
   * Get a {@link SurchargeBoitierPM} (inside a {@link PMConsultResponse}) from the reference to the PM, the reference
   * to the "boitier" and the name of the "panneau".
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param pmCompositeUrl_p
   *          the url to the corresponding endpoint in SAAB.
   * @param referencePmBytel_p
   *          the Bytel reference to a PM.
   * @param referenceBoitierPm_p
   *          the reference to the "boitier" in the PM.
   * @param nomPanneau_p
   *          the name of the "panneau" in the boitier.
   * @param positionPortPM_p
   *          the position of the port in the "panneau".
   * @return a {@link ConnectorResponse} with the {@link Retour} and the {@link PMConsultResponse} obtained from the DB.
   */
  public ConnectorResponse<Retour, PMConsultResponse> lireSurchargeBoitierPM(Tracabilite tracabilite_p, String pmCompositeUrl_p, String referencePmBytel_p, String referenceBoitierPm_p, String nomPanneau_p, String positionPortPM_p)
  {
    return lireSurcharge(tracabilite_p, pmCompositeUrl_p, IAction.LIRE_SURCHARGE_BOITIER_PM, referencePmBytel_p, referenceBoitierPm_p, nomPanneau_p, positionPortPM_p, IMethodName.PM_COMPOSITE_LIRE_SURCHAGE_BOITIER_PM);
  }

  /**
   * Get a {@link SurchargePM} (inside a {@link PMConsultResponse}) from the reference to the PM and the reference to
   * the "boitier".
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param pmCompositeUrl_p
   *          the url to the corresponding endpoint in SAAB.
   * @param referencePmBytel_p
   *          the Bytel reference to a PM.
   * @param referenceBoitierPm_p
   *          the reference to the "boitier" in the PM.
   * @param nomPanneau_p
   *          the name of the "panneau" in the boitier.
   * @param positionPortPM_p
   *          the position of the port in the "panneau".
   * @return a {@link ConnectorResponse} with the {@link Retour} and the {@link PMConsultResponse} obtained from the DB.
   */
  public ConnectorResponse<Retour, PMConsultResponse> lireSurchargePM(Tracabilite tracabilite_p, String pmCompositeUrl_p, String referencePmBytel_p, String referenceBoitierPm_p, String nomPanneau_p, String positionPortPM_p)
  {
    return lireSurcharge(tracabilite_p, pmCompositeUrl_p, IAction.LIRE_SURCHARGE_PM, referencePmBytel_p, referenceBoitierPm_p, nomPanneau_p, positionPortPM_p, IMethodName.PM_COMPOSITE_LIRE_SURCHAGE_PM);
  }

  /**
   * Get a {@link SurchargePortPM} (inside a {@link PMConsultResponse}) from the reference to the PM, the reference to
   * the "boitier", the name of the "panneau" and the position of the port.
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param pmCompositeUrl_p
   *          the url to the corresponding endpoint in SAAB.
   * @param referencePmBytel_p
   *          the Bytel reference to a PM.
   * @param referenceBoitierPm_p
   *          the reference to the "boitier" in the PM.
   * @param nomPanneau_p
   *          the name of the "panneau" in the boitier.
   * @param positionPortPM_p
   *          the position of the port in the "panneau".
   * @return a {@link ConnectorResponse} with the {@link Retour} and the {@link PMConsultResponse} obtained from the DB.
   */
  public ConnectorResponse<Retour, PMConsultResponse> lireSurchargePortPM(Tracabilite tracabilite_p, String pmCompositeUrl_p, String referencePmBytel_p, String referenceBoitierPm_p, String nomPanneau_p, String positionPortPM_p)
  {
    return lireSurcharge(tracabilite_p, pmCompositeUrl_p, IAction.LIRE_SURCHARGE_PORT_PM, referencePmBytel_p, referenceBoitierPm_p, nomPanneau_p, positionPortPM_p, IMethodName.PM_COMPOSITE_LIRE_SURCHAGE_PORT_PM);
  }

  /**
   * Get a {@link PMComposite} given its Bytel reference.
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param pmCompositeUrl_p
   *          the url to the corresponding endpoint in SAAB.
   * @param referencePmBytel_p
   *          the Bytel reference to a PM.
   * @return a {@link ConnectorResponse} with the {@link Retour} and the {@link PMComposite}.
   */
  public ConnectorResponse<Retour, PMComposite> lireUnParReferencePmBytel(Tracabilite tracabilite_p, String pmCompositeUrl_p, String referencePmBytel_p)
  {
    try
    {
      if (StringTools.isNullOrEmpty(pmCompositeUrl_p))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(IRESConnector.MESSAGE_MISSING_CONFIGURATION_PARAMETER, IRESConnector.PAD3205_PATH_PARAM));
      }

      // Query parameters
      HashMap<String, String> queryParams = new HashMap<>();
      queryParams.put(IRESConnector.REFERENCE_PM_BYTEL, referencePmBytel_p);

      // Call SAAB
      final Response response;
      try
      {
        RESTRequest restRequest = new RESTRequestBuilder() //
            .httpMethod(HttpMethod.GET) //
            .traceability(tracabilite_p) //
            .method(IMethodName.PM_COMPOSITE_LIRE_UN_PAR_REF_PM_BYTEL) //
            .headers(AbstractInternalRESTConnector.getSpiritStarkRequestHeader()) //
            .path(pmCompositeUrl_p) //
            .queryParameter(queryParams) //
            .build();

        response = _resInstance.sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the response object
      PMConsultResponse pmCompositeRep = _resInstance.getContentFromResponse(tracabilite_p, response, IMethodName.PM_COMPOSITE_LIRE_UN_PAR_REF_PM_BYTEL, PMConsultResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(pmCompositeRep.getRetour());
      PMComposite pmcomposite = pmCompositeRep.getPmComposite();
      return new ConnectorResponse<>(retour, pmcomposite);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  /**
   * Get a {@link PMComposite} given the reference to the OI of the PM.
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param pmCompositeUrl_p
   *          the url to the corresponding endpoint in SAAB.
   * @param referencePmOi_p
   *          the reference to the OI of the PM.
   * @return a {@link ConnectorResponse} with the {@link Retour} and the {@link PMComposite}.
   */
  public ConnectorResponse<Retour, PMComposite> lireUnParReferencePmOi(Tracabilite tracabilite_p, String pmCompositeUrl_p, String referencePmOi_p)
  {
    try
    {
      if (StringTools.isNullOrEmpty(pmCompositeUrl_p))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(IRESConnector.MESSAGE_MISSING_CONFIGURATION_PARAMETER, IRESConnector.PAD3205_PATH_PARAM));
      }

      // Query parameters
      HashMap<String, String> queryParams = new HashMap<>();
      queryParams.put(IRESConnector.REFERENCE_PM_OI, referencePmOi_p);

      // Call SAAB
      final Response response;
      try
      {
        RESTRequest restRequest = new RESTRequestBuilder() //
            .httpMethod(HttpMethod.GET) //
            .traceability(tracabilite_p) //
            .method(IMethodName.PM_COMPOSITE_LIRE_UN_PAR_REF_PM_OI) //
            .headers(AbstractInternalRESTConnector.getSpiritStarkRequestHeader()) //
            .path(pmCompositeUrl_p) //
            .queryParameter(queryParams) //
            .build();

        response = _resInstance.sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the response object
      PMConsultResponse pmCompositeRep = _resInstance.getContentFromResponse(tracabilite_p, response, IMethodName.PM_COMPOSITE_LIRE_UN_PAR_REF_PM_OI, PMConsultResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(pmCompositeRep.getRetour());
      PMComposite pmComposite = pmCompositeRep.getPmComposite();
      return new ConnectorResponse<>(retour, pmComposite);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  /**
   * Update an object "surcharge" of a given PM.
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param pmCompositeUrl_p
   *          the url to the corresponding endpoint in SAAB.
   * @param referencePmBytel_p
   *          the Bytel reference to a PM.
   * @return a {@link ConnectorResponse} with the {@link Retour} and {@link Nothing} (just because it needs to be a
   *         ConnectorResponse).
   */
  public ConnectorResponse<Retour, Nothing> modifierSurchargeDateDebutQuarantainePM(Tracabilite tracabilite_p, String pmCompositeUrl_p, String referencePmBytel_p)
  {
    return modifierSurcharge(tracabilite_p, pmCompositeUrl_p, IAction.MODIFIER_SURCHARGE_DATE_DEBUT_QUARANTAINE_PM, referencePmBytel_p, null, null, null, null, null, null, null, IMethodName.PM_COMPOSITE_MODIFIER_SURCHARGE_DATE_DEBUT_QUARANTAINE_PM);
  }

  /**
   * Update an object "surcharge" of a given PM.
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param pmCompositeUrl_p
   *          the url to the corresponding endpoint in SAAB.
   * @param referencePmBytel_p
   *          the Bytel reference to a PM.
   * @param referenceBoitierPm_p
   *          the reference to the "boitier" in the PM.
   * @param nomPanneau_p
   *          the name of the "panneau" in the boitier.
   * @param positionPortPM_p
   *          the position of the port in the "panneau".
   * @param statutExploitation_p
   *          the status of "exploitation".
   * @param commentaireExploitation_p
   *          the comment of "exploitation".
   * @return a {@link ConnectorResponse} with the {@link Retour} and {@link Nothing} (just because it needs to be a
   *         ConnectorResponse).
   */
  public ConnectorResponse<Retour, Nothing> modifierSurchargeExploitationPortPM(Tracabilite tracabilite_p, String pmCompositeUrl_p, String referencePmBytel_p, String referenceBoitierPm_p, String nomPanneau_p, String positionPortPM_p, String statutExploitation_p, String commentaireExploitation_p)
  {
    return modifierSurcharge(tracabilite_p, pmCompositeUrl_p, IAction.MODIFIER_SURCHARGE_EXPLOITATION_PORT_PM, referencePmBytel_p, referenceBoitierPm_p, nomPanneau_p, positionPortPM_p, null, statutExploitation_p, null, commentaireExploitation_p, IMethodName.PM_COMPOSITE_MODIFIER_SURCHARGE_EXPLOITATION_PORT_PM);
  }

  /**
   * Update an object "surcharge" of a given PM.
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param pmCompositeUrl_p
   *          the url to the corresponding endpoint in SAAB.
   * @param referencePmBytel_p
   *          the Bytel reference to a PM.
   * @param referenceBoitierPm_p
   *          the reference to the "boitier" in the PM.
   * @param statutBlocage_p
   *          the status of "blocage".
   * @param commentaireBlocage_p
   *          the comment of "blocage".
   * @return a {@link ConnectorResponse} with the {@link Retour} and {@link Nothing} (just because it needs to be a
   *         ConnectorResponse).
   */
  public ConnectorResponse<Retour, Nothing> modifierSurchargePriseClientBoitierPM(Tracabilite tracabilite_p, String pmCompositeUrl_p, String referencePmBytel_p, String referenceBoitierPm_p, String statutBlocage_p, String commentaireBlocage_p)
  {
    return modifierSurcharge(tracabilite_p, pmCompositeUrl_p, IAction.MODIFIER_SURCHARGE_PRISE_CLIENT_BOITIER_PM, referencePmBytel_p, referenceBoitierPm_p, null, null, statutBlocage_p, null, commentaireBlocage_p, null, IMethodName.PM_COMPOSITE_MODIFIER_SURCHARGE_PRISE_CLIENT_BOITIER_PM);
  }

  /**
   * Update an object "surcharge" of a given PM.
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param pmCompositeUrl_p
   *          the url to the corresponding endpoint in SAAB.
   * @param referencePmBytel_p
   *          the Bytel reference to a PM.
   * @param statutBlocage_p
   *          the status of "blocage".
   * @param commentaireBlocage_p
   *          the comment of "blocage".
   * @return a {@link ConnectorResponse} with the {@link Retour} and {@link Nothing} (just because it needs to be a
   *         ConnectorResponse).
   */
  public ConnectorResponse<Retour, Nothing> modifierSurchargePriseClientPM(Tracabilite tracabilite_p, String pmCompositeUrl_p, String referencePmBytel_p, String statutBlocage_p, String commentaireBlocage_p)
  {
    return modifierSurcharge(tracabilite_p, pmCompositeUrl_p, IAction.MODIFIER_SURCHARGE_PRISE_CLIENT_PM, referencePmBytel_p, null, null, null, statutBlocage_p, null, commentaireBlocage_p, null, IMethodName.PM_COMPOSITE_MODIFIER_SURCHARGE_PRISE_CLIENT_PM);
  }

  /**
   * Update an object "surcharge" of a given PM.
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param pmCompositeUrl_p
   *          the url to the corresponding endpoint in SAAB.
   * @param referencePmBytel_p
   *          the Bytel reference to a PM.
   * @param referenceBoitierPm_p
   *          the reference to the "boitier" in the PM.
   * @param nomPanneau_p
   *          the name of the "panneau" in the boitier.
   * @param positionPortPM_p
   *          the position of the port in the "panneau".
   * @param statutBlocage_p
   *          the status of "blocage".
   * @param commentaireBlocage_p
   *          the comment of "blocage".
   * @return a {@link ConnectorResponse} with the {@link Retour} and {@link Nothing} (just because it needs to be a
   *         ConnectorResponse).
   */
  public ConnectorResponse<Retour, Nothing> modifierSurchargePriseClientPortPM(Tracabilite tracabilite_p, String pmCompositeUrl_p, String referencePmBytel_p, String referenceBoitierPm_p, String nomPanneau_p, String positionPortPM_p, String statutBlocage_p, String commentaireBlocage_p)
  {
    return modifierSurcharge(tracabilite_p, pmCompositeUrl_p, IAction.MODIFIER_SURCHARGE_PRISE_CLIENT_PORT_PM, referencePmBytel_p, referenceBoitierPm_p, nomPanneau_p, positionPortPM_p, statutBlocage_p, null, commentaireBlocage_p, null, IMethodName.PM_COMPOSITE_MODIFIER_SURCHARGE_PRISE_CLIENT_PORT_PM);
  }

  /**
   * Generic method for all of the lireSurcharge methods.
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param pmCompositeUrl_p
   *          the url to the corresponding endpoint in SAAB.
   * @param action_p
   *          the action.
   * @param referencePmBytel_p
   *          the Bytel reference to a PM.
   * @param referenceBoitierPm_p
   *          the reference to the "boitier" in the PM.
   * @param nomPanneau_p
   *          the name of the "panneau" in the boitier.
   * @param positionPortPM_p
   *          the position of the port in the "panneau".
   * @param methodName_p
   *          the name of the method.
   * @return a {@link ConnectorResponse} with the {@link Retour} and the {@link PMConsultResponse} obtained from the DB.
   */
  private ConnectorResponse<Retour, PMConsultResponse> lireSurcharge(Tracabilite tracabilite_p, String pmCompositeUrl_p, String action_p, String referencePmBytel_p, String referenceBoitierPm_p, String nomPanneau_p, String positionPortPM_p, String methodName_p)
  {
    try
    {
      if (StringTools.isNullOrEmpty(pmCompositeUrl_p))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(IRESConnector.MESSAGE_MISSING_CONFIGURATION_PARAMETER, IRESConnector.PAD3205_PATH_PARAM));
      }

      // Query parameters
      HashMap<String, String> queryParams = new HashMap<>();
      queryParams.put(IRESConnector.PARAM_ACTION, action_p);
      queryParams.put(IRESConnector.REFERENCE_PM_BYTEL, referencePmBytel_p);
      queryParams.put(IRESConnector.REFERENCE_BOITIER_PM, referenceBoitierPm_p);

      if (!StringTools.isNullOrEmpty(nomPanneau_p))
      {
        queryParams.put(IRESConnector.NOM_PANNEAU, nomPanneau_p);
      }

      if (!StringTools.isNullOrEmpty(positionPortPM_p))
      {
        queryParams.put(IRESConnector.POSITION_PORT_PM, positionPortPM_p);
      }

      // Call SAAB
      final Response response;
      try
      {
        RESTRequest restRequest = new RESTRequestBuilder() //
            .httpMethod(HttpMethod.GET) //
            .traceability(tracabilite_p) //
            .method(methodName_p) //
            .headers(AbstractInternalRESTConnector.getSpiritStarkRequestHeader()) //
            .path(pmCompositeUrl_p) //
            .queryParameter(queryParams) //
            .build();

        response = _resInstance.sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the response object
      PMConsultResponse pmConsultResponse = _resInstance.getContentFromResponse(tracabilite_p, response, methodName_p, PMConsultResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(pmConsultResponse.getRetour());
      return new ConnectorResponse<>(retour, pmConsultResponse);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  /**
   * Generic method for all of the modifierSurcharge methods.
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param pmCompositeUrl_p
   *          the url to the corresponding endpoint in SAAB.
   * @param action_p
   *          the action.
   * @param referencePmBytel_p
   *          the Bytel reference to a PM.
   * @param referenceBoitierPm_p
   *          the reference to the "boitier" in the PM.
   * @param nomPanneau_p
   *          the name of the "panneau" in the boitier.
   * @param positionPortPM_p
   *          the position of the port in the "panneau".
   * @param statutBlocage_p
   *          the status of "blocage".
   * @param statutExploitation_p
   *          the status of "exploitation".
   * @param commentaireBlocage_p
   *          the comment of "blocage".
   * @param commentaireExploitation_p
   *          the comment of "exploitation".
   * @param methodName_p
   *          the name of the method.
   * @return a {@link ConnectorResponse} with the {@link Retour} and {@link Nothing} (just because it needs to be a
   *         ConnectorResponse).
   */
  private ConnectorResponse<Retour, Nothing> modifierSurcharge(Tracabilite tracabilite_p, String pmCompositeUrl_p, String action_p, String referencePmBytel_p, String referenceBoitierPm_p, String nomPanneau_p, String positionPortPM_p, String statutBlocage_p, String statutExploitation_p, String commentaireBlocage_p, String commentaireExploitation_p, String methodName_p)
  {
    try
    {
      if (StringTools.isNullOrEmpty(pmCompositeUrl_p))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(IRESConnector.MESSAGE_MISSING_CONFIGURATION_PARAMETER, IRESConnector.PAD3205_PATH_PARAM));
      }

      // Query parameters
      HashMap<String, String> queryParams = new HashMap<>();
      queryParams.put(IRESConnector.PARAM_ACTION, action_p);
      queryParams.put(IRESConnector.REFERENCE_PM_BYTEL, referencePmBytel_p);

      if (!StringTools.isNullOrEmpty(referenceBoitierPm_p))
      {
        queryParams.put(IRESConnector.REFERENCE_BOITIER_PM, referenceBoitierPm_p);
      }

      if (!StringTools.isNullOrEmpty(nomPanneau_p))
      {
        queryParams.put(IRESConnector.NOM_PANNEAU, nomPanneau_p);
      }

      if (!StringTools.isNullOrEmpty(positionPortPM_p))
      {
        queryParams.put(IRESConnector.POSITION_PORT_PM, positionPortPM_p);
      }

      if (!StringTools.isNullOrEmpty(statutBlocage_p))
      {
        queryParams.put(IRESConnector.STATUT_BLOCAGE, statutBlocage_p);
      }

      if (!StringTools.isNullOrEmpty(statutExploitation_p))
      {
        queryParams.put(IRESConnector.STATUT_EXPLOITATION, statutExploitation_p);
      }

      if (!StringTools.isNullOrEmpty(commentaireBlocage_p))
      {
        queryParams.put(IRESConnector.COMMENTAIRE_BLOCAGE, commentaireBlocage_p);
      }

      if (!StringTools.isNullOrEmpty(commentaireExploitation_p))
      {
        queryParams.put(IRESConnector.COMMENTAIRE_EXPLOITATION, commentaireExploitation_p);
      }

      // Call SAAB
      final Response response;
      try
      {
        RESTRequest restRequest = new RESTRequestBuilder() //
            .httpMethod(HttpMethod.PUT) //
            .traceability(tracabilite_p) //
            .method(methodName_p) //
            .headers(AbstractInternalRESTConnector.getSpiritStarkRequestHeader()) //
            .path(pmCompositeUrl_p) //
            .queryParameter(queryParams) //
            .build();

        response = _resInstance.sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the response object
      BasicResponse basicResponse = _resInstance.getContentFromResponse(tracabilite_p, response, methodName_p, BasicResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(basicResponse.getRetour());
      return new ConnectorResponse<>(retour, null);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

}
