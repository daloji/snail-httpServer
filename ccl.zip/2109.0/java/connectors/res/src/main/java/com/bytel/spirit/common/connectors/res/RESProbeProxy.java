/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.res;

import com.bytel.ravel.common.probes.AvgDoubleCollectorItem;
import com.bytel.ravel.common.probes.AvgFlowPerSecondCollector;
import com.bytel.ravel.common.probes.RavelProbeConfigurationManager;
import com.bytel.ravel.services.connector.BaseProxy;
import com.bytel.spirit.common.connectors.res.services.NoeudRaccordementProxy;
import com.bytel.spirit.common.connectors.res.services.OltCompositeProxy;
import com.bytel.spirit.common.connectors.res.services.PointAncrageIpProxy;
import com.bytel.spirit.common.connectors.res.services.PoolIpProxy;
import com.bytel.spirit.common.connectors.res.services.PorteDeCollecteProxy;
import com.bytel.spirit.common.connectors.res.services.RessourcePortP2PProxy;
import com.bytel.spirit.common.connectors.res.services.RessourcePortPmProxy;
import com.bytel.spirit.common.connectors.res.services.RessourceProxy;
import com.bytel.spirit.common.connectors.res.services.RessourceRaccordementProxy;
import com.bytel.spirit.common.connectors.res.services.TopologieArcturusProxy;

/**
 * @author pramos
 * @version ($Revision$ $Date$)
 *
 *          Workaround for 3000 lines limit Sonar rule in the {@link RESProxy}
 */
public class RESProbeProxy extends BaseProxy
{

  /** For probe to count the amount of call to the couvertureCuivreLireUnParRivoli_Read operation */
  AvgFlowPerSecondCollector _avg_couvertureCuivreLireUnParRivoli_Read_call_counter;

  /** For probe to count the execution time of call to the couvertureCuivreLireUnParRivoli_Read operation */
  AvgDoubleCollectorItem _avg_couvertureCuivreLireUnParRivoli_Read_ExecTime;

  /** For probe to count the amount of call to the couvertureCuivreLireTousParIdAdresseBytel_Read operation */
  AvgFlowPerSecondCollector _avg_couvertureCuivreLireTousParIdAdresseBytel_Read_call_counter;

  /** For probe to count the execution time of call to the couvertureCuivreLireTousParIdAdresseBytel_Read operation */
  AvgDoubleCollectorItem _avg_couvertureCuivreLireTousParIdAdresseBytel_Read_ExecTime;

  /** For probe to count the amount of call to the couvertureCuivreCreerListe_Create operation */
  AvgFlowPerSecondCollector _avg_couvertureCuivreCreerListe_Create_call_counter;

  /** For probe to count the execution time of call to the couvertureCuivreCreerListe_Create operation */
  AvgDoubleCollectorItem _avg_couvertureCuivreCreerListe_Create_ExecTime;

  /** For probe to count the amount of call to the couvertureFttoCreerListe_Create operation */
  AvgFlowPerSecondCollector _avg_couvertureFttoCreerListe_Create_call_counter;

  /** For probe to count the execution time of call to the couvertureFttoCreerListe_Create operation */
  AvgDoubleCollectorItem _avg_couvertureFttoCreerListe_Create_ExecTime;

  /** For probe to count the amount of call to the couvertureFttoLireUn_Read operation */
  AvgFlowPerSecondCollector _avg_couvertureFttoLireUn_Read_call_counter;

  /** For probe to count the amount of call to the couvertureTokyoLireUn_Read operation */
  AvgFlowPerSecondCollector _avg_couvertureTokyoLireUn_Read_call_counter;

  /** For probe to count the execution time of call to the couvertureFttoLireUn_Read operation */
  AvgDoubleCollectorItem _avg_couvertureFttoLireUn_Read_ExecTime;

  /** For probe to count the execution time of call to the couvertureTokyoLireUn_Read operation */
  AvgDoubleCollectorItem _avg_couvertureTokyoLireUn_Read_ExecTime;

  /** For probe to count the amount of call to the fichierReferentielCompositeGererAjo operation */
  AvgFlowPerSecondCollector _avg_fichierReferentielCompositeGererAjoutFichierOrigine_Manage_call_counter;

  /** For probe to count the execution time of call to the fichierReferentielCompositeGererAjou operation */
  AvgDoubleCollectorItem _avg_fichierReferentielCompositeGererAjoutFichierOrigine_Manage_ExecTime;

  /** For probe to count the amount of call to the fichierReferentielCompositeGerer_Manage operation */
  AvgFlowPerSecondCollector _avg_fichierReferentielCompositeGererEchecIntegration_Manage_call_counter;

  /** For probe to count the execution time of call to the fichierReferentielComposite_Manage operation */
  AvgDoubleCollectorItem _avg_fichierReferentielCompositeGererEchecIntegration_Manage_ExecTime;

  /** For probe to count the amount of call to the fichierReferentielCompositeLireTous_Read operation */
  AvgFlowPerSecondCollector _avg_fichierReferentielCompositeLireTous_Read_call_counter;

  /** For probe to count the execution time of call to the fichierReferentielCompositeLireTous_Read operation */
  AvgDoubleCollectorItem _avg_fichierReferentielCompositeLireTous_Read_ExecTime;

  /** For probe to count the amount of call to the gestionReferentielGererBascule_Manage operation */
  AvgFlowPerSecondCollector _avg_gestionReferentielGererBascule_Manage_call_counter;

  /** For probe to count the execution time of call to the gestionReferentielGererBascule_Manage operatio */
  AvgDoubleCollectorItem _avg_gestionReferentielGererBascule_Manage_ExecTime;

  /** For probe to count the amount of call to the gestionReferentielGererRestaurationBackup_Manage operation */
  AvgFlowPerSecondCollector _avg_gestionReferentielGererRestaurationBackup_Manage_call_counter;

  /** For probe to count the execution time of call to the gestionReferentielGererRestaurationBackup_Manage operation */
  AvgDoubleCollectorItem _avg_gestionReferentielGererRestaurationBackup_Manage_ExecTime;

  /** For probe to count the amount of call to the gestionReferentielCreer_Create operation */
  AvgFlowPerSecondCollector _avg_gestionReferentielCreer_Create_call_counter;

  /** For probe to count the execution time of call to the gestionReferentielCreer_Create operation */
  AvgDoubleCollectorItem _avg_gestionReferentielCreer_Create_ExecTime;

  /** For probe to count the amount of call to the accesTechniqueLireTous_Read operation */
  AvgFlowPerSecondCollector _avg_accesTechniqueLireTous_Read_call_counter;

  /** For probe to count the execution time of call to the accesTechniqueLireTous_Read operation */
  AvgDoubleCollectorItem _avg_accesTechniqueLireTous_Read_ExecTime;

  /** For probe to count the amount of call to the pad3003_IntegrationGroupeFichier_Delete operation */
  AvgFlowPerSecondCollector _avg_PAD3003_IntegrationGroupeFichier_Delete_call_counter;

  /** For probe to count the execution time of call to the pad3003_IntegrationGroupeFichier_Delete operation */
  AvgDoubleCollectorItem _avg_PAD3003_IntegrationGroupeFichier_Delete_ExecTime;

  /** For probe to count the amount of call to the pad3003_IntegrationGroupeFichier_Update operation */
  AvgFlowPerSecondCollector _avg_PAD3003_IntegrationGroupeFichier_Update_call_counter;

  /** For probe to count the execution time of call to the pad3003_IntegrationGroupeFichier_Update operation */
  AvgDoubleCollectorItem _avg_PAD3003_IntegrationGroupeFichier_Update_ExecTime;

  /** For probe to count the amount of call to the pad3003_IntegrationGroupeFichier_Read operation */
  AvgFlowPerSecondCollector _avg_PAD3003_IntegrationGroupeFichier_Read_call_counter;

  /** For probe to count the execution time of call to the pad3003_IntegrationGroupeFichier_Read operation */
  AvgDoubleCollectorItem _avg_PAD3003_IntegrationGroupeFichier_Read_ExecTime;

  /** For probe to count the amount of call to the pad3003_IntegrationGroupeFichier_Create operation */
  AvgFlowPerSecondCollector _avg_PAD3003_IntegrationGroupeFichier_Create_call_counter;

  /** For probe to count the execution time of call to the pad3003_IntegrationGroupeFichier_Create operation */
  AvgDoubleCollectorItem _avg_PAD3003_IntegrationGroupeFichier_Create_ExecTime;
  /** For probe to count the amount of call to the pad3002_PrevisionProg_Create operation */
  AvgFlowPerSecondCollector _avg_PAD3002_PrevisionProg_Create_call_counter;

  /** For probe to count the execution time of call to the pad3002_PrevisionProg_Create operation */
  AvgDoubleCollectorItem _avg_PAD3002_PrevisionProg_Create_ExecTime;

  /** For probe to count the amount of call to the pad3002_PrevisionProg_Read operation */
  AvgFlowPerSecondCollector _avg_PAD3002_PrevisionProg_Read_call_counter;

  /** For probe to count the execution time of call to the pad3002_PrevisionProg_Read operation */
  AvgDoubleCollectorItem _avg_PAD3002_PrevisionProg_Read_ExecTime;

  /** For probe to count the amount of call to the pad3001_Commune_Create operation */
  AvgFlowPerSecondCollector _avg_PAD3001_Commune_Create_call_counter;

  /** For probe to count the execution time of call to the pad3001_Commune_Create operation */
  AvgDoubleCollectorItem _avg_PAD3001_Commune_Create_ExecTime;
  /*** For probe to count the amount of call to the pad3001_Commune_codeAncienCodeInsee operation */
  AvgFlowPerSecondCollector _avg_PAD3001_Commune_ancienCodeInsee_call_counter;

  /** For probe to count the execution time of call to the pad3001_Commune_codeAncienCodeInsee operation */
  AvgDoubleCollectorItem _avg_PAD3001_Commune_ancienCodeInsee_ExecTime;

  /** For probe to count the amount of call to the pad3001_Commune_codeinsee operation */
  AvgFlowPerSecondCollector _avg_PAD3001_Commune_codeinsee_call_counter;

  /** For probe to count the execution time of call to the pad3001_Commune_codeinsee operation */
  AvgDoubleCollectorItem _avg_PAD3001_Commune_codeinsee_ExecTime;

  /** For probe to count the amount of call to the pad3001_Commune_codePostal operation */
  AvgFlowPerSecondCollector _avg_PAD3001_Commune_codePostal_call_counter;

  /** For probe to count the execution time of call to the pad3001_Commune_codePostal operation */
  AvgDoubleCollectorItem _avg_PAD3001_Commune_codePostal_ExecTime;

  /** For probe to count the amount of call to the PAD3204CreerNoeudRaccordementGererImport operation */
  AvgFlowPerSecondCollector _avg_PAD3204CreerNoeudRaccordementGererImport_call_counter;

  /** For probe to count the execution time of call to the PAD3204CreerNoeudRaccordementGererImport operation */
  AvgDoubleCollectorItem _avg_PAD3204CreerNoeudRaccordementGererImport_ExecTime;

  /** For probe to count the amount of call to the ressourceRaccordementCompositeGererAnalyserModif_RR operation */
  AvgFlowPerSecondCollector _avg_ressourceRaccordementCompositeGererAnalyserModif_RR_call_counter;

  /** For probe to count the execution time of call to the ressourceRaccordementCompositeGererAnalyser peration */
  AvgDoubleCollectorItem _avg_ressourceRaccordementCompositeGererAnalyserModif_RR_ExecTime;

  /** For probe to count the amount of call to the ressourceRaccordementCompositeLireUn operation */
  AvgFlowPerSecondCollector _avg_ressourceRaccordementCompositeLireUn_call_counter;

  /** For probe to count the execution time of call to the ressourceRaccordementCompositeLireUn operation */
  AvgDoubleCollectorItem _avg_ressourceRaccordementCompositeLireUn_ExecTime;

  /** For probe to count the amount of call to the ressourceCompteMailCreer operation */
  AvgFlowPerSecondCollector _avg_ressourceCompteMailCreer_call_counter;

  /** For probe to count the execution time of call to the ressourceCompteMailCreer operation */
  AvgDoubleCollectorItem _avg_ressourceCompteMailCreer_ExecTime;

  /** For probe to count the amount of call to the ressourceCompteMailModifierStatutAllocation operation */
  AvgFlowPerSecondCollector _avg_ressourceCompteMailModifierStatutAllocation_call_counter;

  /** For probe to count the execution time of call to the ressourceCompteMailModifierStatutAllocation operation */
  AvgDoubleCollectorItem _avg_ressourceCompteMailModifierStatutAllocation_ExecTime;

  /** For probe to count the amount of call to the _avg_oltComposite_gererImport operation */
  AvgFlowPerSecondCollector _avg_oltComposite_gererImport_call_counter;

  /** For probe to count the execution time of call to the _avg_oltComposite_gererImport_ExecTime operation */
  AvgDoubleCollectorItem _avg_oltComposite_gererImport_ExecTime;

  /** For probe to count the amount of call to the _avg_pad3203OltLireTousFiltreNomOlt operation */
  AvgFlowPerSecondCollector _avg_pad3203OltLireTousFiltreNomOlt_call_counter;

  /** For probe to count the execution time of call to the _avg_pad3203OltLireTousFiltreNomOlt_ExecTime operation */
  AvgDoubleCollectorItem _avg_pad3203OltLireTousFiltreNomOlt_ExecTime;

  /** For probe to count the amount of call to the _avg_pad3124RessourcePortP2PModifierStatutAllocation operation */
  AvgFlowPerSecondCollector _avg_pad3124RessourcePortP2PModifierStatutAllocation_call_counter;

  /** For probe to count the execution time of call to the _avg_pad3124RessourcePortP2PModifierStatuT */
  AvgDoubleCollectorItem _avg_pad3124RessourcePortP2PModifierStatutAllocation_ExecTime;

  /** For probe to count the amount of call to the _avg_ressourcePortP2PcompterPortLibre operation */
  AvgFlowPerSecondCollector _avg_ressourcePortP2PcompterPortLibre_call_counter;

  /** For probe to count the execution time of call to the _avg_ressourcePortP2PcompterPortLibre_ExecTime operation */
  AvgDoubleCollectorItem _avg_ressourcePortP2PcompterPortLibre_ExecTime;

  /** For probe to count the amount of call to the _avg_pad3124RessourcePortP2PGererAllocation operation */
  AvgFlowPerSecondCollector _avg_pad3124RessourcePortP2PGererAllocation_call_counter;

  /** For probe to count the execution time of call to the _avg_pad3124RessourcePortP2P_ExecTime operation */
  AvgDoubleCollectorItem _avg_pad3124RessourcePortP2PGererAllocation_ExecTime;

  /** For probe to count the amount of call to the pad3101RessourceAggregeP2PLireUn operation */
  AvgFlowPerSecondCollector _avg_pad3101RessourceAggregeP2PLireUn_call_counter;

  /** For probe to count the execution time of call to the pad3101RessourceAggregeP2PLireUn operation */
  AvgDoubleCollectorItem _avg_pad3101RessourceAggregeP2PLireUn_ExecTime;

  /** For probe to count the amount of call to the fqdnLireUn operation */
  AvgFlowPerSecondCollector _avg_fqdnLireUn_call_counter;

  /** For probe to count the execution time of call to the fqdnLireUn operation */
  AvgDoubleCollectorItem _avg_fqdnLireUn_ExecTime;

  /** For probe to count the amount of call to the couvertureFtthLireTousParIdAdresseBytel_Read operation */
  AvgFlowPerSecondCollector _avg_couvertureFtthLireTousParIdAdresseBytel_Read_call_counter;

  /** For probe to count the execution time of call to the couvertureFtthLireTousParIdAdresseBytel_Read operation */
  AvgDoubleCollectorItem _avg_couvertureFtthLireTousParIdAdresseBytel_Read_ExecTime;

  /** For probe to count the amount of call to the couvertureFtthLireTousParHexacleInterne_Read operation */
  AvgFlowPerSecondCollector _avg_couvertureFtthLireTousParHexacleInterne_Read_call_counter;

  /** For probe to count the execution time of call to the couvertureFtthLireTousParHexacleInterne_Read operation */
  AvgDoubleCollectorItem _avg_couvertureFtthLireTousParHexacleInterne_Read_ExecTime;

  /** For probe to count the amount of call to the couvertureFtthLireTousParIMB_Read operation */
  AvgFlowPerSecondCollector _avg_couvertureFtthLireTousParIMB_Read_call_counter;

  /** For probe to count the execution time of call to the couvertureFtthLireTousParIMB_Read operation */
  AvgDoubleCollectorItem _avg_couvertureFtthLireTousParIMB_Read_ExecTime;

  /** For probe to count the amount of call to the ressourceFtthLireTousParReferencePM_Read operation */
  AvgFlowPerSecondCollector _avg_ressourceFtthLireTousParReferencePM_Read_call_counter;

  /** For probe to count the execution time of call to the ressourceFtthLireTousParReferencePM_Read operation */
  AvgDoubleCollectorItem _avg_ressourceFtthLireTousParReferencePM_Read_ExecTime;

  /** For probe to count the amount of call to the structureVerticaleFtthCompositeCreer_Read operation */
  AvgFlowPerSecondCollector _avg_structureVerticaleFtthComposite_Creer_call_counter;

  /** For probe to count the execution time of call to the structureVerticaleFtthCompositeCreer_Read operation */
  AvgDoubleCollectorItem _avg_structureVerticaleFtthComposite_Creer_ExecTime;

  /** For probe to count the amount of call to the structureVerticaleFtthCompositeLireTousParListeOI operation */
  AvgFlowPerSecondCollector _avg_structureVerticaleFtthCompositeLireTousParListeOIIMB_Read_call_counter;

  /** For probe to count the execution time of call to the structureVerticaleFtthCompositeLireTousParListeOII */
  AvgDoubleCollectorItem _avg_structureVerticaleFtthCompositeLireTousParListeOIIMB_Read_ExecTime;

  /** For probe to count the amount of call to the topologieArcturusLire operation */
  AvgFlowPerSecondCollector _avg_topologieArcturusLire_Read_call_counter;

  /** For probe to count the execution time of call to the topologieArcturusLire operation */
  AvgDoubleCollectorItem _avg_topologieArcturusLire_Read_ExecTime;

  /** For probe to count the amount of call to the cacheEligCreerListe operation */
  AvgFlowPerSecondCollector _avg_cacheEligCreerListe_call_counter;

  /** For probe to count the execution time of call to the cacheEligCreerListe operation */
  AvgDoubleCollectorItem _avg_cacheEligCreerListe_ExecTime;

  /** For probe to count the execution time of call to the pad3300CacheEligRead operation */
  AvgDoubleCollectorItem _avg_cacheEligLire_ExecTime;

  /** For probe to count the amount of call to the pad3300CacheEligRead operation */
  AvgFlowPerSecondCollector _avg_cacheEligLire_call_counter;

  /** For probe to count the execution time of call to the dispoNroFtteOrgLire operation */
  AvgDoubleCollectorItem _avg_dispoNroFtteOrgLire_ExecTime;

  /** For probe to count the amount of call to the dispoNroFtteOrgLire operation */
  AvgFlowPerSecondCollector _avg_dispoNroFtteOrgLire_call_counter;

  /** For probe to count the amount of call to the dispoRessourceDslOrangeLire_Read operation */
  AvgFlowPerSecondCollector _avg_dispoRessourceDslOrangeLire_Read_call_counter;

  /** For probe to count the execution time of call to the dispoRessourceDslOrangeLire_Read operation */
  AvgDoubleCollectorItem _avg_dispoRessourceDslOrangeLire_Read_ExecTime;

  /** For probe to count the amount of call to the dispoRessourceDslOrangeLireParNomUra_Read operation */
  AvgFlowPerSecondCollector _avg_dispoRessourceDslOrangeLireParNomUra_Read_call_counter;

  /** For probe to count the execution time of call to the dispoRessourceDslOrangeLireParNomUra_Read operation */
  AvgDoubleCollectorItem _avg_dispoRessourceDslOrangeLireParNomUra_Read_ExecTime;

  /** For probe to count the execution time of call to the pad3015Couverture5GRead operation */
  AvgDoubleCollectorItem _avg_pad3015Couverture5GRead_ExecTime;

  /** For probe to count the amount of call to the pad3015Couverture5GRead operation */
  AvgFlowPerSecondCollector _avg_pad3015Couverture5GRead_call_counter;

  /** For probe to count the execution time of call to the abaqueDslLireTous operation */
  AvgDoubleCollectorItem _avg_abaqueDslLireTous_ExecTime;

  /** For probe to count the amount of call to the abaqueDslLireTous operation */
  AvgFlowPerSecondCollector _avg_abaqueDslLireTous_call_counter;

  /** For probe to count the amount of call to the dispoRessourceDslBouyguesLire_Read operation */
  AvgFlowPerSecondCollector _avg_dispoRessourceDslBouyguesLire_Read_call_counter;

  /** For probe to count the execution time of call to the dispoRessourceDslBouyguesLire_Read operation */
  AvgDoubleCollectorItem _avg_dispoRessourceDslBouyguesLire_Read_ExecTime;

  /** For probe to count the amount of call to the dispoRessourceDslBouyguesLireParNomUra_Read operation */
  AvgFlowPerSecondCollector _avg_dispoRessourceDslBouyguesLireParNomUra_Read_call_counter;

  /** For probe to count the execution time of call to the dispoRessourceDslBouyguesLireParNomUra_Read operation */
  AvgDoubleCollectorItem _avg_dispoRessourceDslBouyguesLireParNomUra_Read_ExecTime;
  /** For probe to count the amount of call to the dispoRessourceDslAxioneLire_Read operation */
  AvgFlowPerSecondCollector _avg_dispoRessourceDslAxioneLire_Read_call_counter;

  /** For probe to count the execution time of call to the dispoRessourceDslAxioneLire_Read operation */
  AvgDoubleCollectorItem _avg_dispoRessourceDslAxioneLire_Read_ExecTime;

  /** For probe to count the amount of call to the dispoRessourceDslAxioneLireParNomUra_Read operation */
  AvgFlowPerSecondCollector _avg_dispoRessourceDslAxioneLireParNomUra_Read_call_counter;

  /** For probe to count the execution time of call to the dispoRessourceDslAxioneLireParNomUra_Read operation */
  AvgDoubleCollectorItem _avg_dispoRessourceDslAxioneLireParNomUra_Read_ExecTime;
  /** For probe to count the amount of call to the dispoRessourceDslSFRLire_Read operation */
  AvgFlowPerSecondCollector _avg_dispoRessourceDslSFRLire_Read_call_counter;

  /** For probe to count the execution time of call to the dispoRessourceDslSFRLire_Read operation */
  AvgDoubleCollectorItem _avg_dispoRessourceDslSFRLire_Read_ExecTime;

  /** For probe to count the amount of call to the dispoRessourceDslSFRLireParNomUra_Read operation */
  AvgFlowPerSecondCollector _avg_dispoRessourceDslSFRLireParNomUra_Read_call_counter;

  /** For probe to count the execution time of call to the dispoRessourceDslSFRLireParNo operation */
  AvgDoubleCollectorItem _avg_dispoRessourceDslSFRLireParNomUra_Read_ExecTime;
  /** For probe to count the execution time of call to the entonnoirCommuneLireTousParCodeInsee operation */
  AvgDoubleCollectorItem _avg_entonnoirCommuneLireTousParCodeInsee_ExecTime;

  /** For probe to count the amount of call to the entonnoirCommuneLireTousParCodeInsee operation */
  AvgFlowPerSecondCollector _avg_entonnoirCommuneLireTousParCodeInsee_call_counter;

  /** For probe to count the execution time of call to the entonnoirCommuneLireTousParCodePostal operation */
  AvgDoubleCollectorItem _avg_entonnoirCommuneLireTousParCodePostal_ExecTime;

  /** For probe to count the amount of call to the entonnoirCommuneLireTousParCodePostal operation */
  AvgFlowPerSecondCollector _avg_entonnoirCommuneLireTousParCodePostal_call_counter;

  /** For probe to count the execution time of call to the entonnoirCommuneLireTousParDepartement operation */
  AvgDoubleCollectorItem _avg_entonnoirCommuneLireTousParDepartement_ExecTime;

  /** For probe to count the amount of call to the entonnoirCommuneLireTousParDepartement operation */
  AvgFlowPerSecondCollector _avg_entonnoirCommuneLireTousParDepartement_call_counter;

  /** For probe to count the execution time of call to the entonnoirVoieLireTousParCodeInsee operation */
  AvgDoubleCollectorItem _avg_entonnoirVoieLireTousParCodeInsee_ExecTime;

  /** For probe to count the amount of call to the entonnoirVoieLireTousParCodeInsee operation */
  AvgFlowPerSecondCollector _avg_entonnoirVoieLireTousParCodeInsee_call_counter;

  /** For probe to count the execution time of call to the entonnoirVoieLireUnParCodeInseeSimiliHexacle0 operation */
  AvgDoubleCollectorItem _avg_entonnoirVoieLireUnParCodeInseeSimiliHexacle0_ExecTime;

  /** For probe to count the amount of call to the entonnoirVoieLireUnParCodeInseeSimiliHexacle0 operation */
  AvgFlowPerSecondCollector _avg_entonnoirVoieLireUnParCodeInseeSimiliHexacle0_call_counter;

  /**
   * For the probe to count the average execution time of a call to the entonnoirVoieLireUnParCodeInseeCodeRivoli
   * operation.
   */
  AvgDoubleCollectorItem _avg_entonnoirVoieLireUnParCodeInseeCodeRivoli_ExecTime;

  /** For the probe to count the amount of calls made to the entonnoirVoieLireUnParCodeInseeCodeRivoli operation. */
  AvgFlowPerSecondCollector _avg_entonnoirVoieLireUnParCodeInseeCodeRivoli_call_counter;

  /**
   * For probe to count the execution time of call to the entonnoirNumeroLireTousParCodeInseeSimiliHexacle0 operation.
   */
  AvgDoubleCollectorItem _avg_entonnoirNumeroLireTousParCodeInseeSimiliHexacle0_ExecTime;

  /** For probe to count the amount of call to the entonnoirNumeroLireTousParCodeInseeSimiliHexacle0 operation. */
  AvgFlowPerSecondCollector _avg_entonnoirNumeroLireTousParCodeInseeSimiliHexacle0_call_counter;

  /** For probe to count the execution time of call to the entonnoirNumeroLireTousParCodeInseeCodeRivoli operation. */
  AvgDoubleCollectorItem _avg_entonnoirNumeroLireTousParCodeInseeCodeRivoli_ExecTime;

  /** For probe to count the amount of call to the ressourcePortPmGererAllocation operation. */
  AvgFlowPerSecondCollector _avg_ressourcePortPmGererAllocation_call_counter;

  /** For probe to count the execution time of call to the ressourcePortPmGererAllocation operation. */
  AvgDoubleCollectorItem _avg_ressourcePortPmGererAllocation_ExecTime;

  /**
   * For probe to count the amount of call to the ressourcePortPmGererMigrationPortPm operation .
   */
  AvgFlowPerSecondCollector _avg_ressourcePortPmGererMigrationPortPm_call_counter;

  /** For probe to count the execution time of call to the ressourcePortPmGererMigrationPortPm operation. */
  AvgDoubleCollectorItem _avg_ressourcePortPmGererMigrationPortPm_ExecTime;

  /** For probe to count the amount of call to the entonnoirNumeroLireTousParCodeInseeCodeRivoli operation. */
  AvgFlowPerSecondCollector _avg_entonnoirNumeroLireTousParCodeInseeCodeRivoli_call_counter;

  /** For probe to count the amount of call to the couvertureGeoCodage operation. */
  AvgFlowPerSecondCollector _avg_couvertureGeoCodage_Read_call_counter;

  /** For probe to count the execution time of call to the couvertureGeoCodage operation. */
  AvgDoubleCollectorItem _avg_couvertureGeoCodage_Read_ExecTime;

  /** For the probe to count the average execution time of a call to the poolIpGererImport operation. */
  AvgDoubleCollectorItem _poolIpGererImport_avgExecTime;

  /** For the probe to count the average amount of calls made to the poolIpGererImport operation, per second. */
  AvgFlowPerSecondCollector _poolIpGererImport_avgCallCounterSecond;

  /** For the probe to count the average execution time of a call to the GererImport operation. */
  AvgDoubleCollectorItem _pmCompositeGererImport_avgExecTime;

  /** For the probe to count the average execution time of a call to the GererImport operation. */
  AvgDoubleCollectorItem _pmCompositeGererImportWithTypeFluxImport_avgExecTime;

  /** For the probe to count the average amount of calls made to the GererImport operation, per second. */
  AvgFlowPerSecondCollector _pmCompositeGererImport_avgCallCounterSecond;

  /** For the probe to count the average amount of calls made to the GererImport operation, per second. */
  AvgFlowPerSecondCollector _pmCompositeGererImportWithTypeFluxImport_avgCallCounterSecond;

  /** For the probe to count the average execution time of a call to the GererSuppressionPmNonReference operation. */
  AvgDoubleCollectorItem _pmCompositeGererSuppressionPmNonReference_avgExecTime;

  /** For the probe to count the average amount of calls made to the GererSuppressionPmNonReference operation. */
  AvgFlowPerSecondCollector _pmCompositeGererSuppressionPmNonReference_avgCallCounterSecond;

  /** For the probe to count the average amount of calls made to the LireSurchargeBoitierPM operation. */
  AvgFlowPerSecondCollector _pmCompositeLireSurchargeBoitierPM_avgCallCounterSecond;

  /** For the probe to count the average amount of calls made to the LireSurchargeBoitierPM operation. */
  AvgDoubleCollectorItem _pmCompositeLireSurchargeBoitierPM_avgExecTime;

  /** For the probe to count the average amount of calls made to the LireSurchargePM operation. */
  AvgFlowPerSecondCollector _pmCompositeLireSurchargePM_avgCallCounterSecond;

  /** For the probe to count the average amount of calls made to the LireSurchargePM operation. */
  AvgDoubleCollectorItem _pmCompositeLireSurchargePM_avgExecTime;

  /** For the probe to count the average amount of calls made to the LireSurchargePortPM operation. */
  AvgFlowPerSecondCollector _pmCompositeLireSurchargePortPM_avgCallCounterSecond;

  /** For the probe to count the average amount of calls made to the LireSurchargePortPM operation. */
  AvgDoubleCollectorItem _pmCompositeLireSurchargePortPM_avgExecTime;

  /** For the probe to count the average amount of calls made to the LireUnParReferencePmBytel operation. */
  AvgFlowPerSecondCollector _pmCompositeLireUnParReferencePmBytel_avgCallCounterSecond;

  /** For the probe to count the average amount of calls made to the LireUnParReferencePmBytel operation. */
  AvgDoubleCollectorItem _pmCompositeLireUnParReferencePmBytel_avgExecTime;

  /** For the probe to count the average amount of calls made to the LireUnParReferencePmOi operation. */
  AvgFlowPerSecondCollector _pmCompositeLireUnParReferencePmOi_avgCallCounterSecond;

  /** For the probe to count the average amount of calls made to the LireUnParReferencePmOi operation. */
  AvgDoubleCollectorItem _pmCompositeLireUnParReferencePmOi_avgExecTime;

  /** For probe to count the amount of call to the ModifierSurchargeExploitationPortPM operation */
  AvgFlowPerSecondCollector _pmCompositeModifierSurchargeExploitationPortPM_avgCallCounterSecond;

  /** For probe to count the execution time of call to the ModifierSurchargeExploitationPortPM operation */
  AvgDoubleCollectorItem _pmCompositeModifierSurchargeExploitationPortPM_avgExecTime;

  /** For probe to count the amount of call to the ModifierSurchargePriseClientBoitierPM operation */
  AvgFlowPerSecondCollector _pmCompositeModifierSurchargePriseClientBoitierPM_avgCallCounterSecond;

  /** For probe to count the execution time of call to the ModifierSurchargePriseClientBoitierPM operation */
  AvgDoubleCollectorItem _pmCompositeModifierSurchargePriseClientBoitierPM_avgExecTime;

  /** For probe to count the amount of call to the ModifierSurchargePriseClientPM operation */
  AvgFlowPerSecondCollector _pmCompositeModifierSurchargePriseClientPM_avgCallCounterSecond;

  /** For probe to count the execution time of call to the ModifierSurchargePriseClientPM operation */
  AvgDoubleCollectorItem _pmCompositeModifierSurchargePriseClientPM_avgExecTime;

  /** For probe to count the amount of call to the ModifierSurchargePriseClientPortPM operation */
  AvgFlowPerSecondCollector _pmCompositeModifierSurchargePriseClientPortPM_avgCallCounterSecond;

  /** For probe to count the execution time of call to the ModifierSurchargePriseClientPortPM operation */
  AvgDoubleCollectorItem _pmCompositeModifierSurchargePriseClientPortPM_avgExecTime;

  /** For probe to count the amount of call to the pmCompositeModifierSurchargeDateDebutQuarantainePM operation */
  AvgFlowPerSecondCollector _pmCompositeModifierSurchargeDateDebutQuarantainePM_avgCallCounterSecond;

  /**
   * For probe to count the execution time of call to the pmCompositeModifierSurchargeDateDebutQuarantainePM operation.
   */
  AvgDoubleCollectorItem _pmCompositeModifierSurchargeDateDebutQuarantainePM_avgExecTime;

  /**
   * NoeudRaccordement Proxy (create this service to avoid sonar 3000 line error for RESProxy)
   */
  NoeudRaccordementProxy _noeudRaccordementProxy;

  /** OltCompositeProxyService Proxy (create this service to avoid sonar 3000 line error for RESProxy) */
  OltCompositeProxy _oltCompositeProxy;
  /** RessourceService Proxy (create this service to avoid sonar 3000 line error for RESProxy) */
  RessourceProxy _ressourceProxy;
  /** RessourceRaccordementService Proxy (create this service to avoid sonar 3000 line error for RESProxy) */
  RessourceRaccordementProxy _ressourceRaccordementProxy;
  /** RessourceRaccordementService Proxy (create this service to avoid sonar 3000 line error for RESProxy) */
  RessourcePortPmProxy _ressourcePortPmProxy;
  /** RessourceRaccordementService Proxy (create this service to avoid sonar 3000 line error for RESProxy) */
  RessourcePortP2PProxy _ressourcePortP2PProxy;
  /** RessourceRaccordementService Proxy (create this service to avoid sonar 3000 line error for RESProxy) */
  PointAncrageIpProxy _pointAncrageIpProxy;
  /** TopologieArcturusService Proxy (create this service to avoid sonar 3000 line error for RESProxy) */
  TopologieArcturusProxy _topologieArcturusProxy;
  PorteDeCollecteProxy _porteDeCollecteProxy;
  PoolIpProxy _poolIpProxy;

  protected RESProbeProxy(String simpleName_p)
  {

    _avg_PAD3001_Commune_Create_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_PAD3001_Commune_codeInseeCreate_call_counter", simpleName_p); //$NON-NLS-1$
    _avg_PAD3001_Commune_Create_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_PAD3001_Commune_codeInseeCreate_ExecTime", simpleName_p); //$NON-NLS-1$

    _avg_PAD3001_Commune_ancienCodeInsee_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_PAD3001_Commune_ancienCodeInsee_call_counter", simpleName_p); //$NON-NLS-1$
    _avg_PAD3001_Commune_ancienCodeInsee_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_PAD3001_Commune_ancienCodeInsee_ExecTime", simpleName_p); //$NON-NLS-1$

    _avg_PAD3001_Commune_codeinsee_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_PAD3001_Commune_codeinsee_call_counter", simpleName_p); //$NON-NLS-1$
    _avg_PAD3001_Commune_codeinsee_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_PAD3001_Commune_codeinsee_ExecTime", simpleName_p); //$NON-NLS-1$

    _avg_PAD3001_Commune_codePostal_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_PAD3001_Commune_codePostal_call_counter", simpleName_p); //$NON-NLS-1$
    _avg_PAD3001_Commune_codePostal_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_PAD3001_Commune_codePostal_ExecTime", simpleName_p); //$NON-NLS-1$

    _avg_PAD3002_PrevisionProg_Create_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_PAD3002_PrevisionProg_Create_call_counter", simpleName_p); //$NON-NLS-1$
    _avg_PAD3002_PrevisionProg_Create_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_PAD3002_PrevisionProg_Create_ExecTime", simpleName_p); //$NON-NLS-1$

    _avg_PAD3002_PrevisionProg_Read_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_PAD3002_PrevisionProg_Read_call_counter", simpleName_p); //$NON-NLS-1$
    _avg_PAD3002_PrevisionProg_Read_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_PAD3002_PrevisionProg_Read_ExecTime", simpleName_p); //$NON-NLS-1$

    _avg_PAD3003_IntegrationGroupeFichier_Create_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_PAD3003_IntegrationGroupeFichier_Create_call_counter", simpleName_p); //$NON-NLS-1$
    _avg_PAD3003_IntegrationGroupeFichier_Create_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_PAD3003_IntegrationGroupeFichier_Create_ExecTime", simpleName_p); //$NON-NLS-1$

    _avg_PAD3003_IntegrationGroupeFichier_Read_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_PAD3003_IntegrationGroupeFichier_Read_call_counter", simpleName_p); //$NON-NLS-1$
    _avg_PAD3003_IntegrationGroupeFichier_Read_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_PAD3003_IntegrationGroupeFichier_Read_ExecTime", simpleName_p); //$NON-NLS-1$

    _avg_PAD3003_IntegrationGroupeFichier_Update_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_PAD3003_IntegrationGroupeFichier_Update_call_counter", simpleName_p); //$NON-NLS-1$
    _avg_PAD3003_IntegrationGroupeFichier_Update_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_PAD3003_IntegrationGroupeFichier_Update_ExecTime", simpleName_p); //$NON-NLS-1$

    _avg_PAD3003_IntegrationGroupeFichier_Delete_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_PAD3003_IntegrationGroupeFichier_Delete_call_counter", simpleName_p); //$NON-NLS-1$
    _avg_PAD3003_IntegrationGroupeFichier_Delete_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_PAD3003_IntegrationGroupeFichier_Delete_ExecTime", simpleName_p); //$NON-NLS-1$

    _avg_ressourceRaccordementCompositeLireUn_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_ressourceRaccordementCompositeLireUn_call_counter", simpleName_p); //$NON-NLS-1$
    _avg_ressourceRaccordementCompositeLireUn_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_ressourceRaccordementCompositeLireUn_ExecTime", simpleName_p); //$NON-NLS-1$

    _avg_ressourceRaccordementCompositeGererAnalyserModif_RR_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_ressourceRaccordementCompositeGererAnalyserModif_RR_call_counter", simpleName_p); //$NON-NLS-1$
    _avg_ressourceRaccordementCompositeGererAnalyserModif_RR_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_ressourceRaccordementCompositeGererAnalyserModif_RR_ExecTime", simpleName_p); //$NON-NLS-1$

    _avg_ressourceCompteMailCreer_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_ressourceCompteMailCreer_call_counter", simpleName_p); //$NON-NLS-1$
    _avg_ressourceCompteMailCreer_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_ressourceCompteMailCreer_ExecTime", simpleName_p); //$NON-NLS-1$

    _avg_ressourceCompteMailModifierStatutAllocation_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_ressourceCompteMailModifierStatutAllocation_call_counter", simpleName_p); //$NON-NLS-1$
    _avg_ressourceCompteMailModifierStatutAllocation_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_ressourceCompteMailModifierStatutAllocation_ExecTime", simpleName_p); //$NON-NLS-1$

    _avg_fichierReferentielCompositeLireTous_Read_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_fichierReferentielCompositeLireTous_Read_call_counter", simpleName_p); //$NON-NLS-1$
    _avg_fichierReferentielCompositeLireTous_Read_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_fichierReferentielCompositeLireTous_Read_ExecTime", simpleName_p); //$NON-NLS-1$

    _avg_gestionReferentielCreer_Create_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_gestionReferentielCreer_Create_call_counter", simpleName_p); //$NON-NLS-1$
    _avg_gestionReferentielCreer_Create_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_gestionReferentielCreer_Create_ExecTime", simpleName_p); //$NON-NLS-1$

    _avg_couvertureCuivreCreerListe_Create_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_couvertureCuivreCreerListe_Create_call_counter", simpleName_p); //$NON-NLS-1$
    _avg_couvertureCuivreCreerListe_Create_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_couvertureCuivreCreerListe_Create_ExecTime", simpleName_p); //$NON-NLS-1$

    _avg_couvertureFttoCreerListe_Create_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_couvertureFttoCreerListe_Create_call_counter", simpleName_p); //$NON-NLS-1$
    _avg_couvertureFttoCreerListe_Create_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_couvertureFttoCreerListe_Create_ExecTime", simpleName_p); //$NON-NLS-1$

    _avg_fichierReferentielCompositeGererAjoutFichierOrigine_Manage_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_fichierReferentielCompositeGererAjoutFichierOrigine_Manage_call_counter", simpleName_p); //$NON-NLS-1$
    _avg_fichierReferentielCompositeGererAjoutFichierOrigine_Manage_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_fichierReferentielCompositeGererAjoutFichierOrigine_Manage_ExecTime", simpleName_p); //$NON-NLS-1$

    _avg_gestionReferentielGererBascule_Manage_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_gestionReferentielGererBascule_Manage_call_counter", simpleName_p); //$NON-NLS-1$
    _avg_gestionReferentielGererBascule_Manage_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_gestionReferentielGererBascule_Manage_ExecTime", simpleName_p); //$NON-NLS-1$

    _avg_accesTechniqueLireTous_Read_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_accesTechniqueLireTous_Read_call_counter", simpleName_p); //$NON-NLS-1$
    _avg_accesTechniqueLireTous_Read_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_accesTechniqueLireTous_Read_ExecTime", simpleName_p); //$NON-NLS-1$

    _avg_couvertureCuivreLireTousParIdAdresseBytel_Read_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_couvertureCuivreLireTousParIdAdresseBytel_Read_call_counter", simpleName_p); //$NON-NLS-1$
    _avg_couvertureCuivreLireTousParIdAdresseBytel_Read_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_couvertureCuivreLireTousParIdAdresseBytel_Read_ExecTime", simpleName_p); //$NON-NLS-1$

    _avg_gestionReferentielGererRestaurationBackup_Manage_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_gestionReferentielGererRestaurationBackup_Manage_call_counter", simpleName_p); //$NON-NLS-1$
    _avg_gestionReferentielGererRestaurationBackup_Manage_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_gestionReferentielGererRestaurationBackup_Manage_ExecTime", simpleName_p); //$NON-NLS-1$

    _avg_couvertureCuivreLireUnParRivoli_Read_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_couvertureCuivreLireUnParRivoli_Read_call_counter", simpleName_p); //$NON-NLS-1$
    _avg_couvertureCuivreLireUnParRivoli_Read_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_couvertureCuivreLireUnParRivoli_Read_ExecTime", simpleName_p); //$NON-NLS-1$

    _avg_couvertureFttoLireUn_Read_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_couvertureFttoLireUn_Read_call_counter", simpleName_p); //$NON-NLS-1$
    _avg_couvertureFttoLireUn_Read_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_couvertureFttoLireUn_Read_ExecTime", simpleName_p); //$NON-NLS-1$

    _avg_couvertureTokyoLireUn_Read_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_couvertureTokyoLireUn_Read_call_counter", simpleName_p); //$NON-NLS-1$
    _avg_couvertureTokyoLireUn_Read_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_couvertureTokyoLireUn_Read_ExecTime", simpleName_p); //$NON-NLS-1$

    _avg_fichierReferentielCompositeGererEchecIntegration_Manage_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_fichierReferentielCompositeGererEchecIntegration_Manage_call_counter", simpleName_p); //$NON-NLS-1$
    _avg_fichierReferentielCompositeGererEchecIntegration_Manage_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_fichierReferentielCompositeGererEchecIntegration_Manage_ExecTime", simpleName_p); //$NON-NLS-1$

    _avg_oltComposite_gererImport_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_oltComposite_gererImport_call_counter", simpleName_p); //$NON-NLS-1$
    _avg_oltComposite_gererImport_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_oltComposite_gererImport_ExecTime", simpleName_p); //$NON-NLS-1$

    _avg_pad3124RessourcePortP2PModifierStatutAllocation_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_pad3124RessourcePortP2PModifierStatutAllocation_call_counter", simpleName_p); //$NON-NLS-1$
    _avg_pad3124RessourcePortP2PModifierStatutAllocation_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_pad3124RessourcePortP2PModifierStatutAllocation_ExecTime", simpleName_p); //$NON-NLS-1$

    _avg_ressourcePortP2PcompterPortLibre_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_ressourcePortP2PcompterPortLibre_call_counter", simpleName_p); //$NON-NLS-1$
    _avg_ressourcePortP2PcompterPortLibre_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_ressourcePortP2PcompterPortLibre_ExecTime", simpleName_p); //$NON-NLS-1$

    _avg_pad3124RessourcePortP2PGererAllocation_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_pad3124RessourcePortP2PGererAllocation_call_counter", simpleName_p); //$NON-NLS-1$
    _avg_pad3124RessourcePortP2PGererAllocation_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_pad3124RessourcePortP2PGererAllocation_ExecTime", simpleName_p); //$NON-NLS-1$

    _avg_pad3101RessourceAggregeP2PLireUn_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_pad3101RessourceAggregeP2PLireUn_call_counter", simpleName_p); //$NON-NLS-1$
    _avg_pad3101RessourceAggregeP2PLireUn_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_pad3101RessourceAggregeP2PLireUn_ExecTime", simpleName_p); //$NON-NLS-1$

    _avg_fqdnLireUn_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_fqdnLireUn_call_counter", simpleName_p); //$NON-NLS-1$
    _avg_fqdnLireUn_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_fqdnLireUn_ExecTime", simpleName_p); //$NON-NLS-1$

    _avg_pad3203OltLireTousFiltreNomOlt_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_pad3203OltLireTousFiltreNomOlt", simpleName_p); //$NON-NLS-1$
    _avg_pad3203OltLireTousFiltreNomOlt_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_pad3200OltCompositeLireUn_ExecTime", simpleName_p); //$NON-NLS-1$

    _avg_PAD3204CreerNoeudRaccordementGererImport_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_PAD3204CreerNoeudRaccordementGererImport_call_counter", simpleName_p); //$NON-NLS-1$
    _avg_PAD3204CreerNoeudRaccordementGererImport_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_PAD3204CreerNoeudRaccordementGererImport_ExecTime", simpleName_p); //$NON-NLS-1$

    _avg_couvertureFtthLireTousParIdAdresseBytel_Read_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_couvertureFtthLireTousParIdAdresseBytel_Read_call_counter", simpleName_p); //$NON-NLS-1$
    _avg_couvertureFtthLireTousParIdAdresseBytel_Read_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_couvertureFtthLireTousParIdAdresseBytel_Read_ExecTime", simpleName_p); //$NON-NLS-1$

    _avg_couvertureFtthLireTousParHexacleInterne_Read_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_couvertureFtthLireTousParHexacleInterne_Read_call_counter", simpleName_p); //$NON-NLS-1$
    _avg_couvertureFtthLireTousParHexacleInterne_Read_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_couvertureFtthLireTousParHexacleInterne_Read_ExecTime", simpleName_p); //$NON-NLS-1$

    _avg_couvertureFtthLireTousParIMB_Read_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_couvertureFtthLireTousParIMB_Read_call_counter", simpleName_p); //$NON-NLS-1$
    _avg_couvertureFtthLireTousParIMB_Read_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_couvertureFtthLireTousParIMB_Read_ExecTime", simpleName_p); //$NON-NLS-1$

    _avg_ressourceFtthLireTousParReferencePM_Read_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_ressourceFtthLireTousParReferencePM_Read_call_counter", simpleName_p); //$NON-NLS-1$
    _avg_ressourceFtthLireTousParReferencePM_Read_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_ressourceFtthLireTousParReferencePM_Read_ExecTime", simpleName_p); //$NON-NLS-1$

    _avg_structureVerticaleFtthComposite_Creer_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_structureVerticaleFtthComposite_Creer_call_counter", simpleName_p); //$NON-NLS-1$
    _avg_structureVerticaleFtthComposite_Creer_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_structureVerticaleFtthComposite_Creer_ExecTime", simpleName_p); //$NON-NLS-1$

    _avg_structureVerticaleFtthCompositeLireTousParListeOIIMB_Read_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_structureVerticaleFtthCompositeLireTousParListeOIIMB_Read_call_counter", simpleName_p); //$NON-NLS-1$
    _avg_structureVerticaleFtthCompositeLireTousParListeOIIMB_Read_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_structureVerticaleFtthCompositeLireTousParListeOIIMB_Read_ExecTime", simpleName_p); //$NON-NLS-1$

    _avg_topologieArcturusLire_Read_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_topologieArcturusLire_Read_call_counter", simpleName_p); //$NON-NLS-1$
    _avg_topologieArcturusLire_Read_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_topologieArcturusLire_Read_ExecTime", simpleName_p); //$NON-NLS-1$

    _avg_cacheEligCreerListe_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_cacheEligCreerListe_Read_call_counter", simpleName_p); //$NON-NLS-1$
    _avg_cacheEligCreerListe_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_cacheEligCreerListe_ExecTime", simpleName_p); //$NON-NLS-1$

    _avg_cacheEligLire_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_cacheEligLire_call_counter", simpleName_p); //$NON-NLS-1$
    _avg_cacheEligLire_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_cacheEligLire_ExecTime", simpleName_p); //$NON-NLS-1$

    _avg_dispoNroFtteOrgLire_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_dispoNroFtteOrgLire_call_counter", simpleName_p); //$NON-NLS-1$
    _avg_dispoNroFtteOrgLire_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_dispoNroFtteOrgLire_ExecTime", simpleName_p); //$NON-NLS-1$

    _avg_dispoRessourceDslOrangeLire_Read_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_dispoRessourceDslOrangeLire_call_counter", simpleName_p); //$NON-NLS-1$
    _avg_dispoRessourceDslOrangeLire_Read_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_dispoRessourceDslOrangeLire_Read_ExecTime", simpleName_p); //$NON-NLS-1$

    _avg_dispoRessourceDslOrangeLireParNomUra_Read_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_dispoRessourceDslOrangeLireParNomUra_call_counter", simpleName_p); //$NON-NLS-1$
    _avg_dispoRessourceDslOrangeLireParNomUra_Read_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_dispoRessourceDslOrangeLireParNomUra_Read_ExecTime", simpleName_p); //$NON-NLS-1$

    _avg_pad3015Couverture5GRead_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_avg_pad3015Couverture5GRead_call_counter", simpleName_p); //$NON-NLS-1$
    _avg_pad3015Couverture5GRead_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_pad3015Couverture5GRead_ExecTime", simpleName_p); //$NON-NLS-1$

    _avg_abaqueDslLireTous_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_abaqueDslLireTous_call_counter", simpleName_p); //$NON-NLS-1$
    _avg_abaqueDslLireTous_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_abaqueDslLireTous_ExecTime", simpleName_p); //$NON-NLS-1$

    _avg_dispoRessourceDslBouyguesLire_Read_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_dispoRessourceDslBouyguesLire_call_counter", simpleName_p); //$NON-NLS-1$
    _avg_dispoRessourceDslBouyguesLire_Read_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_dispoRessourceDslBouyguesLire_Read_ExecTime", simpleName_p); //$NON-NLS-1$

    _avg_dispoRessourceDslBouyguesLireParNomUra_Read_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_dispoRessourceDslBouyguesLireParNomUra_call_counter", simpleName_p); //$NON-NLS-1$
    _avg_dispoRessourceDslBouyguesLireParNomUra_Read_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_dispoRessourceDslBouyguesLireParNomUra_Read_ExecTime", simpleName_p); //$NON-NLS-1$

    _avg_dispoRessourceDslAxioneLire_Read_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_dispoRessourceDslAxioneLire_call_counter", simpleName_p); //$NON-NLS-1$
    _avg_dispoRessourceDslAxioneLire_Read_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_dispoRessourceDslAxioneLire_Read_ExecTime", simpleName_p); //$NON-NLS-1$

    _avg_dispoRessourceDslAxioneLireParNomUra_Read_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_dispoRessourceDslAxioneLireParNomUra_call_counter", simpleName_p); //$NON-NLS-1$
    _avg_dispoRessourceDslAxioneLireParNomUra_Read_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_dispoRessourceDslAxioneLireParNomUra_Read_ExecTime", simpleName_p); //$NON-NLS-1$

    _avg_dispoRessourceDslSFRLire_Read_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_dispoRessourceDslSFRLire_call_counter", simpleName_p); //$NON-NLS-1$
    _avg_dispoRessourceDslSFRLire_Read_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_dispoRessourceDslSFRLire_Read_ExecTime", simpleName_p); //$NON-NLS-1$

    _avg_dispoRessourceDslSFRLireParNomUra_Read_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_dispoRessourceDslSFRLireParNomUra_call_counter", simpleName_p); //$NON-NLS-1$
    _avg_dispoRessourceDslSFRLireParNomUra_Read_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_dispoRessourceDslSFRLireParNomUra_Read_ExecTime", simpleName_p); //$NON-NLS-1$

    _avg_entonnoirCommuneLireTousParCodeInsee_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_entonnoirCommuneLireTousParCodeInsee_call_counter", simpleName_p); //$NON-NLS-1$
    _avg_entonnoirCommuneLireTousParCodeInsee_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_entonnoirCommuneLireTousParCodeInsee_ExecTime", simpleName_p); //$NON-NLS-1$

    _avg_entonnoirCommuneLireTousParCodePostal_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_entonnoirCommuneLireTousParCodePostal_call_counter", simpleName_p); //$NON-NLS-1$
    _avg_entonnoirCommuneLireTousParCodePostal_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_entonnoirCommuneLireTousParCodePostal_ExecTime", simpleName_p); //$NON-NLS-1$

    _avg_entonnoirCommuneLireTousParDepartement_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_entonnoirCommuneLireTousParDepartement_call_counter", simpleName_p); //$NON-NLS-1$
    _avg_entonnoirCommuneLireTousParDepartement_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_entonnoirCommuneLireTousParDepartement_ExecTime", simpleName_p); //$NON-NLS-1$

    _avg_entonnoirVoieLireTousParCodeInsee_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_entonnoirVoieLireTousParCodeInsee_call_counter", simpleName_p); //$NON-NLS-1$
    _avg_entonnoirVoieLireTousParCodeInsee_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_entonnoirVoieLireTousParCodeInsee_ExecTime", simpleName_p); //$NON-NLS-1$

    _avg_entonnoirVoieLireUnParCodeInseeSimiliHexacle0_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_entonnoirVoieLireUnParCodeInseeSimiliHexacle0_call_counter", simpleName_p); //$NON-NLS-1$
    _avg_entonnoirVoieLireUnParCodeInseeSimiliHexacle0_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_entonnoirVoieLireUnParCodeInseeSimiliHexacle0_ExecTime", simpleName_p); //$NON-NLS-1$

    _avg_entonnoirVoieLireUnParCodeInseeCodeRivoli_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_entonnoirVoieLireUnParCodeInseeCodeRivoli_call_counter", simpleName_p); //$NON-NLS-1$
    _avg_entonnoirVoieLireUnParCodeInseeCodeRivoli_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_entonnoirVoieLireUnParCodeInseeCodeRivoli_ExecTime", simpleName_p); //$NON-NLS-1$

    _avg_entonnoirNumeroLireTousParCodeInseeSimiliHexacle0_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_entonnoirNumeroLireTousParCodeInseeSimiliHexacle0_call_counter", simpleName_p); //$NON-NLS-1$
    _avg_entonnoirNumeroLireTousParCodeInseeSimiliHexacle0_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_entonnoirNumeroLireTousParCodeInseeSimiliHexacle0_ExecTime", simpleName_p); //$NON-NLS-1$

    _avg_entonnoirNumeroLireTousParCodeInseeCodeRivoli_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_entonnoirNumeroLireTousParCodeInseeCodeRivoli_call_counter", simpleName_p); //$NON-NLS-1$
    _avg_entonnoirNumeroLireTousParCodeInseeCodeRivoli_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_entonnoirNumeroLireTousParCodeInseeCodeRivoli_ExecTime", simpleName_p); //$NON-NLS-1$

    _avg_couvertureGeoCodage_Read_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_couvertureGeoCodage_Read_call_counter", simpleName_p); //$NON-NLS-1$
    _avg_couvertureGeoCodage_Read_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_couvertureGeoCodage_Read_ExecTime", simpleName_p); //$NON-NLS-1$

    _avg_ressourcePortPmGererAllocation_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_ressourcePortPmGererAllocation_call_counter", simpleName_p); //$NON-NLS-1$
    _avg_ressourcePortPmGererAllocation_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_ressourcePortPmGererAllocation_ExecTime", simpleName_p); //$NON-NLS-1$

    _avg_ressourcePortPmGererMigrationPortPm_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_ressourcePortPmGererMigrationPortPm_call_counter", simpleName_p); //$NON-NLS-1$
    _avg_ressourcePortPmGererMigrationPortPm_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_ressourcePortPmGererMigrationPortPm_ExecTime", simpleName_p); //$NON-NLS-1$

    _poolIpGererImport_avgExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("poolIpGererImport_avgExecTime", simpleName_p); //$NON-NLS-1$
    _poolIpGererImport_avgCallCounterSecond = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("poolIpGererImport_callCounter", simpleName_p); //$NON-NLS-1$

    _pmCompositeGererImport_avgExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("pmCompositeGererImport_avgExecTime", simpleName_p); //$NON-NLS-1$
    _pmCompositeGererImport_avgCallCounterSecond = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("pmCompositeGererImport_avgCallCounterSecond", simpleName_p); //$NON-NLS-1$

    _pmCompositeGererImportWithTypeFluxImport_avgExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("pmCompositeGererImportWithTypeFluxImport_avgExecTime", simpleName_p); //$NON-NLS-1$
    _pmCompositeGererImportWithTypeFluxImport_avgCallCounterSecond = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("pmCompositeGererImportWithTypeFluxImport_avgCallCounterSecond", simpleName_p); //$NON-NLS-1$

    _pmCompositeGererSuppressionPmNonReference_avgExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("pmCompositeGererSuppressionPmNonReference_avgExecTime", simpleName_p); //$NON-NLS-1$
    _pmCompositeGererSuppressionPmNonReference_avgCallCounterSecond = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("pmCompositeGererSuppressionPmNonReference_avgCallCounterSecond", simpleName_p); //$NON-NLS-1$

    _pmCompositeLireSurchargeBoitierPM_avgCallCounterSecond = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("pmCompositeLireSurchargeBoitierPM_avgCallCounterSecond", simpleName_p); //$NON-NLS-1$
    _pmCompositeLireSurchargeBoitierPM_avgExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("pmCompositeLireSurchargeBoitierPM_avgExecTime", simpleName_p); //$NON-NLS-1$

    _pmCompositeLireSurchargePM_avgExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("pmCompositeLireSurchargePM_avgExecTime", simpleName_p); //$NON-NLS-1$
    _pmCompositeLireSurchargePM_avgCallCounterSecond = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("pmCompositeLireSurchargePM_avgCallCounterSecond", simpleName_p); //$NON-NLS-1$

    _pmCompositeLireSurchargePortPM_avgExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("pmCompositeLireSurchargePortPM_avgExecTime", simpleName_p); //$NON-NLS-1$
    _pmCompositeLireSurchargePortPM_avgCallCounterSecond = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("pmCompositeLireSurchargePortPM_avgCallCounterSecond", simpleName_p); //$NON-NLS-1$

    _pmCompositeLireUnParReferencePmBytel_avgExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("pmCompositeLireUnParReferencePmBytel_avgExecTime", simpleName_p); //$NON-NLS-1$
    _pmCompositeLireUnParReferencePmBytel_avgCallCounterSecond = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("pmCompositeLireUnParReferencePmBytel_avgCallCounterSecond", simpleName_p); //$NON-NLS-1$

    _pmCompositeLireUnParReferencePmOi_avgExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("pmCompositeLireUnParReferencePmOi_avgExecTime", simpleName_p); //$NON-NLS-1$
    _pmCompositeLireUnParReferencePmOi_avgCallCounterSecond = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("pmCompositeLireUnParReferencePmOi_avgCallCounterSecond", simpleName_p); //$NON-NLS-1$

    _pmCompositeModifierSurchargeExploitationPortPM_avgCallCounterSecond = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("pmCompositeModifierSurchargeExploitationPortPM_avgCallCounterSecond", simpleName_p); //$NON-NLS-1$
    _pmCompositeModifierSurchargeExploitationPortPM_avgExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("pmCompositeModifierSurchargeExploitationPortPM_avgExecTime", simpleName_p); //$NON-NLS-1$

    _pmCompositeModifierSurchargePriseClientBoitierPM_avgCallCounterSecond = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("pmCompositeModifierSurchargePriseClientBoitierPM_avgCallCounterSecond", simpleName_p); //$NON-NLS-1$
    _pmCompositeModifierSurchargePriseClientBoitierPM_avgExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("pmCompositeModifierSurchargePriseClientBoitierPM_avgExecTime", simpleName_p); //$NON-NLS-1$

    _pmCompositeModifierSurchargePriseClientPM_avgCallCounterSecond = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("pmCompositeModifierSurchargePriseClientPM_avgCallCounterSecond", simpleName_p); //$NON-NLS-1$
    _pmCompositeModifierSurchargePriseClientPM_avgExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("pmCompositeModifierSurchargePriseClientPM_avgExecTime", simpleName_p); //$NON-NLS-1$
    _pmCompositeModifierSurchargePriseClientPortPM_avgCallCounterSecond = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("pmCompositeModifierSurchargePriseClientPortPM_avgCallCounterSecond", simpleName_p); //$NON-NLS-1$
    _pmCompositeModifierSurchargePriseClientPortPM_avgExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("pmCompositeModifierSurchargePriseClientPortPM_avgExecTime", simpleName_p); //$NON-NLS-1$
    _pmCompositeModifierSurchargeDateDebutQuarantainePM_avgCallCounterSecond = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("pmCompositeModifierSurchargeDateDebutQuarantainePM_avgCallCounterSecond", simpleName_p); //$NON-NLS-1$
    _pmCompositeModifierSurchargeDateDebutQuarantainePM_avgExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("pmCompositeModifierSurchargeDateDebutQuarantainePM_avgExecTime", simpleName_p); //$NON-NLS-1$

    _noeudRaccordementProxy = new NoeudRaccordementProxy(IRESConnector.BEAN_ID, _avg_PAD3204CreerNoeudRaccordementGererImport_call_counter, _avg_PAD3204CreerNoeudRaccordementGererImport_ExecTime);
    _oltCompositeProxy = new OltCompositeProxy(IRESConnector.BEAN_ID);
    _ressourceProxy = new RessourceProxy(IRESConnector.BEAN_ID);
    _ressourceRaccordementProxy = new RessourceRaccordementProxy(IRESConnector.BEAN_ID);
    _ressourcePortPmProxy = new RessourcePortPmProxy(IRESConnector.BEAN_ID);
    _ressourcePortP2PProxy = new RessourcePortP2PProxy(IRESConnector.BEAN_ID);
    _pointAncrageIpProxy = new PointAncrageIpProxy(IRESConnector.BEAN_ID);
    _topologieArcturusProxy = new TopologieArcturusProxy(IRESConnector.BEAN_ID);
    _porteDeCollecteProxy = new PorteDeCollecteProxy(IRESConnector.BEAN_ID);
    _poolIpProxy = new PoolIpProxy(IRESConnector.BEAN_ID);
  }

}
