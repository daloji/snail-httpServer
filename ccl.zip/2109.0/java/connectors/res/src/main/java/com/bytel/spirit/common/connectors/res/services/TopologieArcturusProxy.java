/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.res.services;

import java.util.List;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.probes.AvgDoubleCollectorItem;
import com.bytel.ravel.common.probes.AvgFlowPerSecondCollector;
import com.bytel.ravel.common.probes.RavelProbeConfigurationManager;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.services.connector.ConnectorManager;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.connectors.res.IRESConnector;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.TopologieArcturus;

/**
 * @author pramos
 * @version ($Revision$ $Date$)
 */
public class TopologieArcturusProxy
{
  /** The connector instance */
  private String _connectorId;

  /** For probe to count the amount of call to the topologieArcturusLireUn operation */
  AvgFlowPerSecondCollector _avg_topologieArcturusLireUn_Read_call_counter;

  /** For probe to count the execution time of call to the topologieArcturusLireUn operation */
  AvgDoubleCollectorItem _avg_topologieArcturusLireUn_Read_ExecTime;

  /** For probe to count the amount of call to the topologieArcturusLireTousParIdEqptAcces operation */
  AvgFlowPerSecondCollector _avg_topologieArcturusLireTousParIdEqptAcces_Read_call_counter;

  /** For probe to count the execution time of call to the topologieArcturusLireTousParIdEqptAcces operation */
  AvgDoubleCollectorItem _avg_topologieArcturusLireTousParIdEqptAcces_Read_ExecTime;

  public TopologieArcturusProxy(String connectorId_p)
  {
    _connectorId = connectorId_p;

    _avg_topologieArcturusLireUn_Read_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_topologieArcturusLireUn_Read_call_counter", "RESProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_topologieArcturusLireUn_Read_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_topologieArcturusLireUn_Read_ExecTime", "RESProxy"); //$NON-NLS-1$ //$NON-NLS-2$

    _avg_topologieArcturusLireTousParIdEqptAcces_Read_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_topologieArcturusLireTousParIdEqptAcces_Read_call_counter", "RESProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_topologieArcturusLireTousParIdEqptAcces_Read_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_topologieArcturusLireTousParIdEqptAcces_Read_ExecTime", "RESProxy"); //$NON-NLS-1$ //$NON-NLS-2$
  }

  /**
   * 
   * @param tracabilite_p
   * @param idEqptAcces_p
   * @return
   * @throws RavelException
   */
  public ConnectorResponse<Retour, List<TopologieArcturus>> topologieArcturusLireTousParIdEqptAcces(Tracabilite tracabilite_p, String idEqptAcces_p) throws RavelException
  {

    IRESConnector resConnector = null;
    try
    {
      resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
    }
    catch (Exception e_p)
    {
      // Retour NOK
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
    }
    _avg_topologieArcturusLireTousParIdEqptAcces_Read_call_counter.measure();
    long startTime = System.currentTimeMillis();
    try
    {
      return resConnector.topologieArcturusLireTousParIdEqptAcces(tracabilite_p, idEqptAcces_p);
    }
    finally
    {
      long endTime = System.currentTimeMillis();
      _avg_topologieArcturusLireTousParIdEqptAcces_Read_ExecTime.updateAvgValue(endTime - startTime);
    }

  }

  /**
   * 
   * @param tracabilite_p
   * @param idNomCollecte_p
   * @return
   * @throws RavelException
   */
  public ConnectorResponse<Retour, TopologieArcturus> topologieArcturusLireUn(Tracabilite tracabilite_p, String idNomCollecte_p) throws RavelException
  {

    IRESConnector resConnector = null;
    try
    {
      resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
    }
    catch (Exception e_p)
    {
      // Retour NOK
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
    }
    _avg_topologieArcturusLireUn_Read_call_counter.measure();
    long startTime = System.currentTimeMillis();
    try
    {
      return resConnector.topologieArcturusLireUn(tracabilite_p, idNomCollecte_p);
    }
    finally
    {
      long endTime = System.currentTimeMillis();
      _avg_topologieArcturusLireUn_Read_ExecTime.updateAvgValue(endTime - startTime);
    }

  }
}
