/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.res;

import java.text.MessageFormat;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.ws.rs.HttpMethod;
import javax.ws.rs.core.Response;

import org.springframework.util.CollectionUtils;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.cache.CacheManager;
import com.bytel.ravel.common.cache.ICache;
import com.bytel.ravel.common.conf.generated.Param;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.json.IRavelJson;
import com.bytel.ravel.common.json.RavelJson;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.services.conf.connector.generated.Connector;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.connector.RESTRequest;
import com.bytel.ravel.services.connector.RESTRequest.RESTRequestBuilder;
import com.bytel.spirit.common.connectors.res.services.AbaqueDSLService;
import com.bytel.spirit.common.connectors.res.services.Couverture5GService;
import com.bytel.spirit.common.connectors.res.services.CouvertureFTTHService;
import com.bytel.spirit.common.connectors.res.services.CouvertureGeoCodageService;
import com.bytel.spirit.common.connectors.res.services.DispoRessourceDSLService;
import com.bytel.spirit.common.connectors.res.services.EntonnoirCommuneService;
import com.bytel.spirit.common.connectors.res.services.EntonnoirNumeroService;
import com.bytel.spirit.common.connectors.res.services.EntonnoirVoieService;
import com.bytel.spirit.common.connectors.res.services.NoeudRaccordementService;
import com.bytel.spirit.common.connectors.res.services.OltCompositeService;
import com.bytel.spirit.common.connectors.res.services.PmCompositeService;
import com.bytel.spirit.common.connectors.res.services.PointAncrageIpService;
import com.bytel.spirit.common.connectors.res.services.PoolIpService;
import com.bytel.spirit.common.connectors.res.services.PorteDeCollecteService;
import com.bytel.spirit.common.connectors.res.services.RessourcePortP2PService;
import com.bytel.spirit.common.connectors.res.services.RessourcePortPmService;
import com.bytel.spirit.common.connectors.res.services.RessourceRaccordementService;
import com.bytel.spirit.common.connectors.res.services.RessourceService;
import com.bytel.spirit.common.connectors.res.services.TopologieArcturusService;
import com.bytel.spirit.common.shared.functional.types.json.RavelJsonTools;
import com.bytel.spirit.common.shared.misc.connectors.AbstractInternalRESTConnector;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.BasicResponse;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.ressources.RetourConverter;
import com.bytel.spirit.common.shared.misc.ressources.SpiritConstants;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.AbaqueDSL;
import com.bytel.spirit.common.shared.saab.res.AccesTechnique;
import com.bytel.spirit.common.shared.saab.res.CacheElig;
import com.bytel.spirit.common.shared.saab.res.CompteRenduSuppression;
import com.bytel.spirit.common.shared.saab.res.Couverture5G;
import com.bytel.spirit.common.shared.saab.res.CouvertureCuivre;
import com.bytel.spirit.common.shared.saab.res.CouvertureFtth;
import com.bytel.spirit.common.shared.saab.res.CouvertureFtto;
import com.bytel.spirit.common.shared.saab.res.CouvertureGeoCodage;
import com.bytel.spirit.common.shared.saab.res.CouvertureTokyo;
import com.bytel.spirit.common.shared.saab.res.DispoNroFtteOrg;
import com.bytel.spirit.common.shared.saab.res.DispoRessourceDSLAxione;
import com.bytel.spirit.common.shared.saab.res.DispoRessourceDSLBouygues;
import com.bytel.spirit.common.shared.saab.res.DispoRessourceDSLOrange;
import com.bytel.spirit.common.shared.saab.res.DispoRessourceDSLSFR;
import com.bytel.spirit.common.shared.saab.res.EntonnoirCommune;
import com.bytel.spirit.common.shared.saab.res.EntonnoirNumero;
import com.bytel.spirit.common.shared.saab.res.EntonnoirVoie;
import com.bytel.spirit.common.shared.saab.res.FichierOrigine;
import com.bytel.spirit.common.shared.saab.res.FichierReferentielComposite;
import com.bytel.spirit.common.shared.saab.res.Fqdn;
import com.bytel.spirit.common.shared.saab.res.ListeTechnologieAutorisee;
import com.bytel.spirit.common.shared.saab.res.Olt;
import com.bytel.spirit.common.shared.saab.res.OltComposite;
import com.bytel.spirit.common.shared.saab.res.PMComposite;
import com.bytel.spirit.common.shared.saab.res.PointAncrageIP;
import com.bytel.spirit.common.shared.saab.res.PoolIP;
import com.bytel.spirit.common.shared.saab.res.PorteDeCollecte;
import com.bytel.spirit.common.shared.saab.res.Ressource;
import com.bytel.spirit.common.shared.saab.res.RessourceAggrege;
import com.bytel.spirit.common.shared.saab.res.RessourceFtth;
import com.bytel.spirit.common.shared.saab.res.RessourcePortPM;
import com.bytel.spirit.common.shared.saab.res.RessourceRaccordementComposite;
import com.bytel.spirit.common.shared.saab.res.StructureVerticaleFtthComposite;
import com.bytel.spirit.common.shared.saab.res.TopologieArcturus;
import com.bytel.spirit.common.shared.saab.res.TypeCouverture5G;
import com.bytel.spirit.common.shared.saab.res.request.IntegrationGroupeFichierRequest;
import com.bytel.spirit.common.shared.saab.res.request.ListeCacheEligRequest;
import com.bytel.spirit.common.shared.saab.res.request.ListeCommuneRequest;
import com.bytel.spirit.common.shared.saab.res.request.ListeCoupleImbOiRequest;
import com.bytel.spirit.common.shared.saab.res.request.ListeNomOLTRequest;
import com.bytel.spirit.common.shared.saab.res.request.ListePrevisionRequest;
import com.bytel.spirit.common.shared.saab.res.request.ManageNoeudRaccordementRequest;
import com.bytel.spirit.common.shared.saab.res.response.CreateCacheEligResponse;
import com.bytel.spirit.common.shared.saab.res.response.GetAccesTechniqueResponse;
import com.bytel.spirit.common.shared.saab.res.response.GetCacheEligResponse;
import com.bytel.spirit.common.shared.saab.res.response.GetCouvertureCuivreResponse;
import com.bytel.spirit.common.shared.saab.res.response.GetCouvertureFttoResponse;
import com.bytel.spirit.common.shared.saab.res.response.GetCouvertureTokyoResponse;
import com.bytel.spirit.common.shared.saab.res.response.GetDispoNroFtteOrgResponse;
import com.bytel.spirit.common.shared.saab.res.response.GetFichierReferentielCompositeResponse;
import com.bytel.spirit.common.shared.saab.res.response.GetListeFqdnResponse;
import com.bytel.spirit.common.shared.saab.res.response.GetListeOltResponse;
import com.bytel.spirit.common.shared.saab.res.response.GetRessourceAggrege;
import com.bytel.spirit.common.shared.saab.res.response.GetRessourceFtthResponse;
import com.bytel.spirit.common.shared.saab.res.response.GetRessourceRaccordementCompositeResponse;
import com.bytel.spirit.common.shared.saab.res.response.GetRessourceRaccordementResponse;
import com.bytel.spirit.common.shared.saab.res.response.GetStructureVerticaleFtthCompositeResponse;
import com.bytel.spirit.common.shared.saab.res.response.GetSurchargeResponse;
import com.bytel.spirit.common.shared.saab.res.response.IntegrationGroupeFichierResponse;
import com.bytel.spirit.common.shared.saab.res.response.ListeCommuneResponse;
import com.bytel.spirit.common.shared.saab.res.response.ListePrevisionResponse;
import com.bytel.spirit.common.shared.types.json.response.PMConsultResponse;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

/**
 * @author dangelis
 * @version ($Revision$ $Date$)
 */
public class RESConnector extends AbstractInternalRESTConnector implements IRESConnector
{
  /** Ravel Json serializer */
  private final IRavelJson _jsonBuilder = new RavelJson.RavelJsonBuilder().profil(SpiritConstants.JSON_PROFILE_STARK).build();
  /** Path for PAD3001 */
  private String _communeUrl;
  /** Path for PAD3002 */
  private String _previsionProgUrl;
  /** Path for PAD3003 */
  private String _integrationGroupFileUrl;
  /** Path for PAD3004 accessTechnique */
  private String _accesTechniqueUrl;
  /** Path for PAD3005 gestionReferentiel */
  private String _gestionReferentielUrl;
  /** Path for PAD3006 fichierReferentielComposite */
  private String _fichierReferentielCompositeUrl;
  /** Path for PAD3007 couvertureCuivre */
  private String _couvertureCuivreUrl;
  /** Path for PAD3010 couvertureFtth */
  private String _couvertureFtthUrl;
  /** Path for PAD3011 ressourceFtth */
  private String _ressourceFtthUrl;
  /** Path for PAD3127 ressourcePorm */
  private String _ressourcePortPmUrl;
  /** Path for PAD3008 couvertureFtto */
  private String _couvertureFttoUrl;
  /** Path for PAD3009 couvertureTokyo */
  private String _couvertureTokyoUrl;
  /** Path for PAD3013 couvertureTokyo */
  private String _topologieArcturusUrl;
  /** Path for PAD3012 structureVerticaleFtthComposite */
  private String _structureVerticaleFtthCompositeUrl;
  /** Path for PAD3012 structureVerticaleFtthCompositeRecherche */
  private String _structureVerticaleFtthCompositeRechercheUrl;
  /** Path for PAD3100 */
  private String _ressourceUrl;
  /** Path for PAD3110 */
  private String _ressourceRaccordementUrl;
  /** Path for PAD3111 */
  private String _ressourceRaccordementCompositeUrl;
  /** Path for PAD3111 manage */
  private String _manageRessourceRaccordementCompositeUrl;
  /** Path for PAD???? */
  private String _ressourceAdresseIpClfUrl;
  /** Path for PAD???? */
  private String _ressourceImpiFixeUrl;
  /** Path for PAD???? */
  private String _ressourceCompteImsUrl;
  /** Path for PAD3120 */
  private String _ressourceCompteMailUrl;
  /** Path for PAD???? */
  private String _ressourceMotDePasseImsUrl;
  /** Path for PAD???? */
  private String _ressourceOntIdUrl;
  /** Path for PAD3200 */
  private String _oltCompositeUrl;
  /** Path for PAD3124 */
  private String _ressourcePortP2PUrl;
  /** Path for PAD3101 */
  private String _ressourceReseauCompositeUrl;
  /** Path for PAD3202 */
  private String _fqdnUrl;
  /** Path for PAD3203 */
  private String _oltTousFiltreUrl;
  /** Path for PAD3300 */
  private String _cacheEligUrl;
  /** Path for PAD3014 */
  private String _dispoNroFtteOrgUrl;
  /** Path for PAD3015 */
  private String _couverture5GUrl;
  /** Path for PAD3016 */
  private String _abaqueDslUrl;
  /** Path for PAD3024 */
  private String _couvertureGeocodageUrl;
  /** Path for PAD3017 */
  private String _dispoRessourceDslOrangeUrl;
  /** Path for PAD3018 */
  private String _dispoRessourceDslBouyguesUrl;
  /** Path for PAD3019 */
  private String _dispoRessourceDslAxioneUrl;
  /** Path for PAD3020 */
  private String _dispoRessourceDslSFRUrl;
  /** Path for PAD3021 */
  private String _entonnoirCommuneUrl;
  /** Path for PAD3022 */
  private String _entonnoirVoieUrl;
  /** Path for PAD3023 */
  private String _entonnoirNumeroUrl;
  /** Path for PAD3204 */
  private String _nouedRacordementUrl;
  /** Path for PAD3205 */
  private String _pmCompositeUrl;
  private String _poolIpUrl;
  /** Path for PAD3206 */
  private String _pointAncrageIpUrl;
  /** Path for PAD3208 */
  private String _porteDeCollecteUrl;
  /** Timeout value */
  private Integer _createLongTimeout;
  /** cache duration */
  private Duration _accesTechniqueCacheDuration;
  /** cache duration */
  private Duration _abaqueDslCacheDuration;

  // Services
  private AbaqueDSLService _abaqueDSLService;
  private Couverture5GService _couverture5GService;
  private DispoRessourceDSLService _dispoRessourceDSLService;
  private CouvertureFTTHService _couvertureFTTHService;
  private EntonnoirCommuneService _entonnoirCommuneService;
  private EntonnoirVoieService _entonnoirVoieService;
  private EntonnoirNumeroService _entonnoirNumeroService;
  private CouvertureGeoCodageService _couvertureGeoCodageService;
  private NoeudRaccordementService _noeudRaccordementService;
  private PmCompositeService _pmCompositeService;
  private OltCompositeService _oltCompositeService;
  private RessourceService _ressourceService;
  private RessourceRaccordementService _ressourceRaccordementService;
  private RessourcePortPmService _ressourcePortPmService;
  private RessourcePortP2PService _ressourcePortP2PService;
  private PoolIpService _poolIpService;
  private PointAncrageIpService _pointAncrageIpService;
  private TopologieArcturusService _topologieArcturusService;
  private PorteDeCollecteService _porteDeCollecteService;

  @Override
  public ConnectorResponse<Retour, Map<String, List<AbaqueDSL>>> abaqueDslLireTous(Tracabilite tracabilite_p) throws RavelException
  {
    return _abaqueDSLService.abaqueDslLireTous(tracabilite_p, _abaqueDslCacheDuration);
  }

  @Override
  public ConnectorResponse<Retour, Map<String, AccesTechnique>> accesTechniqueLireTous(Tracabilite tracabilite_p) throws RavelException
  {
    try
    {
      AccesTechniqueCacheLoader cacheLoader = new AccesTechniqueCacheLoader(tracabilite_p, _accesTechniqueCacheDuration);
      ICache<AccesTechnique> cache = (ICache<AccesTechnique>) CacheManager.getInstance().getCache(cacheLoader);
      if ((cache != null) && !cache.isEmpty())
      {
        Map<String, AccesTechnique> map = cache.getFirstCache();
        return new ConnectorResponse<>(RetourFactory.createOkRetour(), map);
      }
      if (cacheLoader.getRetour() != null)
      {
        return new ConnectorResponse<>(cacheLoader.getRetour(), null);
      }
      else
      {
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.LECTURE_INDISPONIBLE, MESSAGE_SERVICES_COM_CACHE), null);
      }
    }
    catch (Exception e_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, List<AccesTechnique>> accesTechniqueLireTousParLogin(Tracabilite tracabilite_p, String login_p) throws RavelException
  {
    try
    {
      AccesTechniqueLoginCacheLoader cacheLoader = new AccesTechniqueLoginCacheLoader(tracabilite_p, _accesTechniqueCacheDuration, login_p);
      ICache<List<AccesTechnique>> cache = (ICache<List<AccesTechnique>>) CacheManager.getInstance().getCache(cacheLoader);

      if ((cache != null) && !cache.isEmpty())
      {
        return new ConnectorResponse<>(RetourFactory.createOkRetour(), cache.getFirstCache().get(login_p));
      }
      else
      {
        if (cacheLoader.getRetour() != null)
        {
          return new ConnectorResponse<>(cacheLoader.getRetour(), null);
        }
        else
        {
          return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.LECTURE_INDISPONIBLE, MESSAGE_SERVICES_COM_CACHE), null);
        }
      }
    }
    catch (Exception e_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, Integer> cacheEligCreerListe(Tracabilite tracabilite_p, ListeCacheEligRequest listeCacheEligRequest_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_cacheEligUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD3300_PATH_PARAM));
      }
      final Response response;
      try
      {
        RESTRequest restRequest = new RESTRequestBuilder().httpMethod(HttpMethod.POST).request(listeCacheEligRequest_p).serializer(_jsonBuilder).traceability(tracabilite_p).method(METHOD_NAME_PAD3300_CACHE_ELIG_CREER_LISTE).headers(SPIRIT_STARK_REQUEST_HEADER).path(_cacheEligUrl).build();
        response = sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }
      // Get the content to a JSON string
      String jsonResponse = getContent(response, METHOD_NAME_PAD3300_CACHE_ELIG_CREER_LISTE, tracabilite_p);

      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }
      CreateCacheEligResponse cacheEligResponse = RavelJsonTools.getInstance().fromJson(jsonResponse, CreateCacheEligResponse.class);
      Retour retour = RetourConverter.convertFromJsonRetour(cacheEligResponse.getRetour());
      return new ConnectorResponse<>(retour, cacheEligResponse.getNombreLigneKO());
    }
    catch (Exception e_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, CacheElig> cacheEligLire(Tracabilite tracabilite_p, String idCleCompose_p, String typeCle_p, String techno_p, String operateur_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_cacheEligUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD3300_PATH_PARAM));
      }
      // Query parameters
      HashMap<String, String> queryParams = new HashMap<>();
      queryParams.put(PARAM_ID_CLE_COMPOSE, idCleCompose_p);
      queryParams.put(PARAM_TYPE_CLE, typeCle_p);
      queryParams.put(PARAM_TECHNO, techno_p);
      queryParams.put(PARAM_OPERATEUR, operateur_p);

      // Call SAAB
      final Response response;
      try
      {
        RESTRequest restRequest = new RESTRequestBuilder()//
            .httpMethod(HttpMethod.GET)//
            .traceability(tracabilite_p)//
            .method(METHOD_NAME_PAD3300_CACHE_ELIG_LIRE)//
            .headers(SPIRIT_STARK_REQUEST_HEADER)//
            .path(_cacheEligUrl)//
            .queryParameter(queryParams)//
            .build();
        response = sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content to a JSON string
      String jsonResponse = getContent(response, METHOD_NAME_PAD3300_CACHE_ELIG_LIRE, tracabilite_p);

      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }
      GetCacheEligResponse cacheEligResponse = RavelJsonTools.getInstance().fromJson(jsonResponse, GetCacheEligResponse.class);
      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(cacheEligResponse.getRetour());
      return new ConnectorResponse<>(retour, cacheEligResponse.getCacheElig());
    }
    catch (Exception e_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, Couverture5G> couverture5gLireUn(Tracabilite tracabilite_p, String idAdresseBytel_p, TypeCouverture5G typeCouverture5G_p) throws RavelException
  {
    return _couverture5GService.couverture5gLireUn(tracabilite_p, _couverture5GUrl, idAdresseBytel_p, typeCouverture5G_p);
  }

  @Override
  public ConnectorResponse<Retour, List<CouvertureCuivre>> couvertureCuivreLireTousParIdAdresseBytel(Tracabilite tracabilite_p, String idAdresseBytel_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_couvertureCuivreUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD3007_PATH_PARAM));
      }
      // Call SAAB
      final Response response;
      HashMap<String, String> queryParams = new HashMap<>();
      queryParams.put(PARAM_ID_ADRESSE_BYTEL, idAdresseBytel_p);

      try
      {
        RESTRequest restRequest = new RESTRequestBuilder()//
            .httpMethod(HttpMethod.GET)//
            .traceability(tracabilite_p)//
            .method(METHOD_NAME_COUVERTURE_CUIVRE_LIRE_TOUS_ID_BYTEL)//
            .headers(SPIRIT_STARK_REQUEST_HEADER)//
            .path(_couvertureCuivreUrl)//
            .queryParameter(queryParams)//
            .build();
        response = sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }
      // Get the content to a JSON string
      String jsonResponse = getContent(response, METHOD_NAME_COUVERTURE_CUIVRE_LIRE_TOUS_ID_BYTEL, tracabilite_p);

      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }
      GetCouvertureCuivreResponse getCouvertureCuivreResponse = GsonTools.getIso8601Ms().fromJson(jsonResponse, GetCouvertureCuivreResponse.class);
      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(getCouvertureCuivreResponse.getRetour());
      List<CouvertureCuivre> listeCouvertureCuivre = getCouvertureCuivreResponse.getListeCouvertureCuivre();

      return new ConnectorResponse<>(retour, listeCouvertureCuivre);
    }
    catch (Exception e_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, List<CouvertureCuivre>> couvertureCuivreLireUnParRivoli(Tracabilite tracabilite_p, String codeInsee_p, String rivoli_p, String numeroComplement_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_couvertureCuivreUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD3007_PATH_PARAM));
      }
      // Call SAAB
      final Response response;
      HashMap<String, String> queryParams = new HashMap<>();
      queryParams.put(PARAM_CODE_INSEE, codeInsee_p);
      queryParams.put(PARAM_RIVOLI, rivoli_p);
      queryParams.put(PARAM_NUMERO_COMPLEMENT, numeroComplement_p);

      try
      {
        RESTRequest restRequest = new RESTRequestBuilder()//
            .httpMethod(HttpMethod.GET)//
            .traceability(tracabilite_p)//
            .method(METHOD_NAME_COUVERTURE_CUIVRE_LIRE_UN_PAR_RIVOLI)//
            .headers(SPIRIT_STARK_REQUEST_HEADER)//
            .path(_couvertureCuivreUrl)//
            .queryParameter(queryParams)//
            .build();
        response = sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }
      // Get the content to a JSON string
      String jsonResponse = getContent(response, METHOD_NAME_COUVERTURE_CUIVRE_LIRE_UN_PAR_RIVOLI, tracabilite_p);

      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }
      GetCouvertureCuivreResponse getCouvertureCuivreResponse = GsonTools.getIso8601Ms().fromJson(jsonResponse, GetCouvertureCuivreResponse.class);
      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(getCouvertureCuivreResponse.getRetour());
      List<CouvertureCuivre> listeCouvertureCuivre = getCouvertureCuivreResponse.getListeCouvertureCuivre();
      return new ConnectorResponse<>(retour, listeCouvertureCuivre);
    }
    catch (Exception e_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, List<CouvertureFtth>> couvertureFtthLireTousParHexacleInterne(Tracabilite tracabilite_p, String hexacleInterne_p) throws RavelException
  {
    return _couvertureFTTHService.couvertureFtthLireTousParHexacleInterne(tracabilite_p, _couvertureFtthUrl, hexacleInterne_p);
  }

  @Override
  public ConnectorResponse<Retour, List<CouvertureFtth>> couvertureFtthLireTousParIdAdresseBytel(Tracabilite tracabilite_p, String idAdresseBytel_p) throws RavelException
  {
    return _couvertureFTTHService.couvertureFtthLireTousParIdAdresseBytel(tracabilite_p, _couvertureFtthUrl, idAdresseBytel_p);
  }

  @Override
  public ConnectorResponse<Retour, List<CouvertureFtth>> couvertureFtthLireTousParIMB(Tracabilite tracabilite_p, String imb_p) throws RavelException
  {
    return _couvertureFTTHService.couvertureFtthLireTousParIMB(tracabilite_p, _couvertureFtthUrl, imb_p);
  }

  @Override
  public ConnectorResponse<Retour, CouvertureFtto> couvertureFttoLireUn(Tracabilite tracabilite_p, String idAdresseBytel_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_couvertureFttoUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD3008_PATH_PARAM));
      }
      // Call SAAB
      final Response response;
      HashMap<String, String> queryParams = new HashMap<>();
      queryParams.put(PARAM_ID_ADRESSE_BYTEL, idAdresseBytel_p);

      try
      {
        RESTRequest restRequest = new RESTRequestBuilder()//
            .httpMethod(HttpMethod.GET)//
            .traceability(tracabilite_p)//
            .method(METHOD_NAME_COUVERTURE_FTTO_LIRE_UN)//
            .headers(SPIRIT_STARK_REQUEST_HEADER)//
            .path(_couvertureFttoUrl)//
            .queryParameter(queryParams)//
            .build();
        response = sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }
      // Get the content to a JSON string
      String jsonResponse = getContent(response, METHOD_NAME_COUVERTURE_FTTO_LIRE_UN, tracabilite_p);
      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }
      GetCouvertureFttoResponse getCouvertureFttoResponse = GsonTools.getIso8601Ms().fromJson(jsonResponse, GetCouvertureFttoResponse.class);
      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(getCouvertureFttoResponse.getRetour());
      CouvertureFtto couvertureFtto = getCouvertureFttoResponse.getCouvertureFtto();
      return new ConnectorResponse<>(retour, couvertureFtto);
    }
    catch (Exception e_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, CouvertureGeoCodage> couvertureGeocodageLireUn(Tracabilite tracabilite_p, String idAdresseBytel_p) throws RavelException
  {
    return _couvertureGeoCodageService.couvertureGeocodageLireUn(tracabilite_p, idAdresseBytel_p, _couvertureGeocodageUrl);
  }

  @Override
  public ConnectorResponse<Retour, CouvertureTokyo> couvertureTokyoLireUn(Tracabilite tracabilite_p, String idAdresseBytel_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_couvertureTokyoUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD3009_PATH_PARAM));
      }

      // Call SAAB
      final Response response;
      HashMap<String, String> queryParams = new HashMap<>();
      queryParams.put(PARAM_ID_ADRESSE_BYTEL, idAdresseBytel_p);

      try
      {
        RESTRequest restRequest = new RESTRequestBuilder()//
            .httpMethod(HttpMethod.GET)//
            .traceability(tracabilite_p)//
            .method(METHOD_NAME_COUVERTURE_TOKYO_LIRE_UN)//
            .headers(SPIRIT_STARK_REQUEST_HEADER)//
            .path(_couvertureTokyoUrl)//
            .queryParameter(queryParams)//
            .build();
        response = sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content to a JSON string
      String jsonResponse = getContent(response, METHOD_NAME_COUVERTURE_TOKYO_LIRE_UN, tracabilite_p);

      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }

      // Deserialize response
      GetCouvertureTokyoResponse getCouvertureTokyoResponse = RavelJsonTools.getInstance().fromJson(jsonResponse, GetCouvertureTokyoResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(getCouvertureTokyoResponse.getRetour());
      CouvertureTokyo couvertureTokyo = getCouvertureTokyoResponse.getCouvertureTokyo();

      return new ConnectorResponse<>(retour, couvertureTokyo);
    }
    catch (Exception e_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, DispoNroFtteOrg> dispoNroFtteOrgLire(Tracabilite tracabilite_p, String nro_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_dispoNroFtteOrgUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD3300_PATH_PARAM));
      }

      // Query parameters
      HashMap<String, String> queryParams = new HashMap<>();
      queryParams.put(PARAM_NRO, nro_p);

      // Call SAAB
      final Response response;
      try
      {
        RESTRequest restRequest = new RESTRequestBuilder()//
            .httpMethod(HttpMethod.GET)//
            .traceability(tracabilite_p)//
            .method(METHOD_NAME_PAD3014_DISPO_NRO_FTTE_ORG_LIRE)//
            .headers(SPIRIT_STARK_REQUEST_HEADER)//
            .path(_dispoNroFtteOrgUrl)//
            .queryParameter(queryParams)//
            .build();
        response = sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content to a JSON string
      String jsonResponse = getContent(response, METHOD_NAME_PAD3014_DISPO_NRO_FTTE_ORG_LIRE, tracabilite_p);

      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }

      GetDispoNroFtteOrgResponse dispoNroFtteOrgResponse = RavelJsonTools.getInstance().fromJson(jsonResponse, GetDispoNroFtteOrgResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(dispoNroFtteOrgResponse.getRetour());
      return new ConnectorResponse<>(retour, dispoNroFtteOrgResponse.getDispoNroFtteOrg());
    }
    catch (Exception e_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, List<DispoRessourceDSLAxione>> dispoRessourceDslAxioneLire(Tracabilite tracabilite_p, String nomUraOrange_p, String techno_p, String nbPaire_p, String typeKp_p) throws RavelException
  {
    return _dispoRessourceDSLService.dispoRessourceDslAxioneLire(tracabilite_p, _dispoRessourceDslAxioneUrl, nomUraOrange_p, techno_p, nbPaire_p, typeKp_p);
  }

  @Override
  public ConnectorResponse<Retour, List<DispoRessourceDSLAxione>> dispoRessourceDslAxioneLireParNomUra(Tracabilite tracabilite_p, String nomUraOrange_p) throws RavelException
  {
    return _dispoRessourceDSLService.dispoRessourceDslAxioneLireParNomUra(tracabilite_p, _dispoRessourceDslAxioneUrl, nomUraOrange_p);
  }

  @Override
  public ConnectorResponse<Retour, List<DispoRessourceDSLBouygues>> dispoRessourceDslBouyguesLire(Tracabilite tracabilite_p, String nomUraOrange_p, String techno_p, String nbPaire_p, String typeKp_p) throws RavelException
  {
    return _dispoRessourceDSLService.dispoRessourceDslBouyguesLire(tracabilite_p, _dispoRessourceDslBouyguesUrl, nomUraOrange_p, techno_p, nbPaire_p, typeKp_p);
  }

  @Override
  public ConnectorResponse<Retour, List<DispoRessourceDSLBouygues>> dispoRessourceDslBouyguesLireParNomUra(Tracabilite tracabilite_p, String nomUraOrange_p) throws RavelException
  {
    return _dispoRessourceDSLService.dispoRessourceDslBouyguesLireParNomUra(tracabilite_p, _dispoRessourceDslBouyguesUrl, nomUraOrange_p);
  }

  @Override
  public ConnectorResponse<Retour, List<DispoRessourceDSLOrange>> dispoRessourceDslOrangeLire(Tracabilite tracabilite_p, String nomUraOrange_p, String techno_p, String nbPaire_p, String typeKp_p) throws RavelException
  {
    return _dispoRessourceDSLService.dispoRessourceDslOrangeLire(tracabilite_p, _dispoRessourceDslOrangeUrl, nomUraOrange_p, techno_p, nbPaire_p, typeKp_p);
  }

  @Override
  public ConnectorResponse<Retour, List<DispoRessourceDSLOrange>> dispoRessourceDslOrangeLireParNomUra(Tracabilite tracabilite_p, String nomUraOrange_p) throws RavelException
  {
    return _dispoRessourceDSLService.dispoRessourceDslOrangeLireParNomUra(tracabilite_p, _dispoRessourceDslOrangeUrl, nomUraOrange_p);
  }

  @Override
  public ConnectorResponse<Retour, List<DispoRessourceDSLSFR>> dispoRessourceDslSFRLire(Tracabilite tracabilite_p, String nomUraOrange_p, String techno_p, String nbPaire_p, String typeKp_p) throws RavelException
  {
    return _dispoRessourceDSLService.dispoRessourceDslSFRLire(tracabilite_p, _dispoRessourceDslSFRUrl, nomUraOrange_p, techno_p, nbPaire_p, typeKp_p);
  }

  @Override
  public ConnectorResponse<Retour, List<DispoRessourceDSLSFR>> dispoRessourceDslSFRLireParNomUra(Tracabilite tracabilite_p, String nomUraOrange_p) throws RavelException
  {
    return _dispoRessourceDSLService.dispoRessourceDslSFRLireParNomUra(tracabilite_p, _dispoRessourceDslSFRUrl, nomUraOrange_p);
  }

  @Override
  public ConnectorResponse<Retour, List<EntonnoirCommune>> entonnoirCommuneLireTousParCodeInsee(Tracabilite tracabilite_p, String codeInsee_p) throws RavelException
  {
    return _entonnoirCommuneService.entonnoirCommuneLireTousParCodeInsee(tracabilite_p, _entonnoirCommuneUrl, codeInsee_p);
  }

  @Override
  public ConnectorResponse<Retour, List<EntonnoirCommune>> entonnoirCommuneLireTousParCodePostal(Tracabilite tracabilite_p, String codePostal_p) throws RavelException
  {
    return _entonnoirCommuneService.entonnoirCommuneLireTousParCodePostal(tracabilite_p, _entonnoirCommuneUrl, codePostal_p);
  }

  @Override
  public ConnectorResponse<Retour, List<EntonnoirCommune>> entonnoirCommuneLireTousParDepartement(Tracabilite tracabilite_p, String departement_p) throws RavelException
  {
    return _entonnoirCommuneService.entonnoirCommuneLireTousParDepartement(tracabilite_p, _entonnoirCommuneUrl, departement_p);
  }

  @Override
  public ConnectorResponse<Retour, List<EntonnoirNumero>> entonnoirNumeroLireTousParCodeInseeCodeRivoli(Tracabilite tracabilite_p, String codeInsee_p, String codeRivoli_p) throws RavelException
  {
    return _entonnoirNumeroService.entonnoirNumeroLireTousParCodeInseeCodeRivoli(tracabilite_p, _entonnoirNumeroUrl, codeInsee_p, codeRivoli_p);
  }

  @Override
  public ConnectorResponse<Retour, List<EntonnoirNumero>> entonnoirNumeroLireTousParCodeInseeSimiliHexacle0(Tracabilite tracabilite_p, String codeInsee_p, String similiHexacle0_p) throws RavelException
  {
    return _entonnoirNumeroService.entonnoirNumeroLireTousParCodeInseeSimiliHexacle0(tracabilite_p, _entonnoirNumeroUrl, codeInsee_p, similiHexacle0_p);
  }

  @Override
  public ConnectorResponse<Retour, List<EntonnoirVoie>> entonnoirVoieLireTousParCodeInsee(Tracabilite tracabilite_p, String codeInsee_p) throws RavelException
  {
    return _entonnoirVoieService.entonnoirVoieLireTousParCodeInsee(tracabilite_p, _entonnoirVoieUrl, codeInsee_p);
  }

  @Override
  public ConnectorResponse<Retour, List<EntonnoirVoie>> entonnoirVoieLireUnParCodeInseeCodeRivoli(Tracabilite tracabilite_p, String codeInsee_p, String codeRivoli_p) throws RavelException
  {
    return _entonnoirVoieService.entonnoirVoieLireUnParCodeInseeCodeRivoli(tracabilite_p, _entonnoirVoieUrl, codeInsee_p, codeRivoli_p);
  }

  @Override
  public ConnectorResponse<Retour, List<EntonnoirVoie>> entonnoirVoieLireUnParCodeInseeSimiliHexacle0(Tracabilite tracabilite_p, String codeInsee_p, String similiHexacle0_p) throws RavelException
  {
    return _entonnoirVoieService.entonnoirVoieLireUnParCodeInseeSimiliHexacle0(tracabilite_p, _entonnoirVoieUrl, codeInsee_p, similiHexacle0_p);
  }

  @Override
  public ConnectorResponse<Retour, Nothing> fichierReferentielCompositeGererEchecIntegration(Tracabilite tracabilite_p, String typeReferentiel_p, FichierOrigine fichierOrigine_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_fichierReferentielCompositeUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD3006_PATH_PARAM));
      }

      Retour retour;
      Response response;

      HashMap<String, String> queryParams = new HashMap<>();
      queryParams.put(PARAM_TYPE_REFERENTIEL, typeReferentiel_p);
      queryParams.put(PARAM_ACTION, "GererEchecIntegration"); //$NON-NLS-1$

      try
      {
        RESTRequest restRequest = new RESTRequestBuilder()//
            .httpMethod(HttpMethod.PUT)//
            .traceability(tracabilite_p)//
            .method(METHOD_NAME_FICHIER_REFERENTIEL_GERER_ECHEC_INTEGRATION)//
            .headers(SPIRIT_STARK_REQUEST_HEADER)//
            .path(_fichierReferentielCompositeUrl)//
            .queryParameter(queryParams)//
            .request(fichierOrigine_p)//
            .build();
        response = sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content to a JSON string
      String jsonResponse = getContent(response, METHOD_NAME_FICHIER_REFERENTIEL_GERER_ECHEC_INTEGRATION, tracabilite_p);

      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }

      BasicResponse basicResponse = GsonTools.getIso8601Ms().fromJson(jsonResponse, BasicResponse.class);

      // Retour OK
      retour = RetourConverter.convertFromJsonRetour(basicResponse.getRetour());

      return new ConnectorResponse<>(retour, null);
    }
    catch (Exception ex_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, ex_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, List<FichierReferentielComposite>> fichierReferentielCompositeLireTous(Tracabilite tracabilite_p, String typeReferentiel_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_fichierReferentielCompositeUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD3006_PATH_PARAM));
      }

      // Call SAAB
      final Response response;
      HashMap<String, String> queryParams = new HashMap<>();
      queryParams.put(PARAM_TYPE_REFERENTIEL, typeReferentiel_p);

      try
      {
        RESTRequest restRequest = new RESTRequestBuilder()//
            .httpMethod(HttpMethod.GET)//
            .traceability(tracabilite_p)//
            .method(METHOD_NAME_FICHIER_REFERENTIEL_LIRE_TOUS)//
            .headers(SPIRIT_STARK_REQUEST_HEADER)//
            .path(_fichierReferentielCompositeUrl)//
            .queryParameter(queryParams)//
            .build();
        response = sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content to a JSON string
      String jsonResponse = getContent(response, METHOD_NAME_FICHIER_REFERENTIEL_LIRE_TOUS, tracabilite_p);

      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }

      GetFichierReferentielCompositeResponse getFichierReferentielCompositeResponse = GsonTools.getIso8601Ms().fromJson(jsonResponse, GetFichierReferentielCompositeResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(getFichierReferentielCompositeResponse.getRetour());
      List<FichierReferentielComposite> listeFichierReferentielComposite = getFichierReferentielCompositeResponse.getListeFichierReferentielComposite();

      return new ConnectorResponse<>(retour, listeFichierReferentielComposite);
    }
    catch (Exception e_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, Nothing> fqdnGererAllocationSession(Tracabilite tracabilite_p, String nomfqdn_p, String operation_p, int nombreSession_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_fqdnUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD3003_PATH_PARAM));
      }
      // Query parameters
      HashMap<String, String> queryParams = new HashMap<>();
      if (StringTools.isNotNullOrEmpty(nomfqdn_p) && StringTools.isNotNullOrEmpty(operation_p))
      {
        queryParams.put(PARAM_NOM_FQDN, nomfqdn_p);
        queryParams.put(PARAM_OPERATION, operation_p);
        queryParams.put(PARAM_NOMBRE_SESSION, Integer.toString(nombreSession_p));
        queryParams.put(PARAM_ACTION, ACTION_GERER_ALLOCATION_SESSION_FQDN);
      }
      // Call SAAB
      final Response response;
      try
      {
        RESTRequest restRequest = new RESTRequestBuilder()//
            .httpMethod(HttpMethod.PUT)//
            .traceability(tracabilite_p)//
            .method(METHOD_NAME_ALLOCATION_SESSION_FQDN)//
            .headers(SPIRIT_STARK_REQUEST_HEADER)//
            .path(_fqdnUrl)//
            .queryParameter(queryParams)//
            .build();
        response = sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }
      // Get the content to a JSON string
      String jsonResponse = getContent(response, METHOD_NAME_ALLOCATION_SESSION_FQDN, tracabilite_p);

      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }
      BasicResponse basicResponse = GsonTools.getIso8601Ms().fromJson(jsonResponse, BasicResponse.class);
      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(basicResponse.getRetour());
      return new ConnectorResponse<>(retour, null);
    }
    catch (Exception e_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, Fqdn> fqdnLireUn(Tracabilite tracabilite_p, String nomFQDN_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_fqdnUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD3202_PATH_PARAM));
      }

      // Call SAAB
      final Response response;
      HashMap<String, String> queryParams = new HashMap<>();
      queryParams.put(PARAM_NOM_FQDN, nomFQDN_p);

      try
      {
        RESTRequest restRequest = new RESTRequestBuilder()//
            .httpMethod(HttpMethod.GET)//
            .traceability(tracabilite_p)//
            .method(METHOD_NAME_FQDN_LIRE_UN)//
            .headers(SPIRIT_STARK_REQUEST_HEADER)//
            .path(_fqdnUrl)//
            .queryParameter(queryParams)//
            .build();
        response = sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content to a JSON string
      String jsonResponse = getContent(response, METHOD_NAME_FQDN_LIRE_UN, tracabilite_p);

      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }

      // Deserialize response
      GetListeFqdnResponse getFqdnResponse = RavelJsonTools.getInstance().fromJson(jsonResponse, GetListeFqdnResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(getFqdnResponse.getRetour());
      Fqdn fqdn = null;

      if (!CollectionUtils.isEmpty(getFqdnResponse.getListeFqdn()))
      {
        fqdn = getFqdnResponse.getListeFqdn().get(0);
      }

      return new ConnectorResponse<>(retour, fqdn);
    }
    catch (Exception e_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, Fqdn> fqdnLireUnParTauxOccupation(Tracabilite tracabilite_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_fqdnUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD3202_PATH_PARAM));
      }

      // Call SAAB
      final Response response;
      HashMap<String, String> queryParams = new HashMap<>();
      queryParams.put(PARAM_FILTRE, PAR_TAUX_OCCUPATION);

      try
      {
        RESTRequest restRequest = new RESTRequestBuilder()//
            .httpMethod(HttpMethod.GET)//
            .traceability(tracabilite_p)//
            .method(METHOD_NAME_FQDN_LIRE_UN_PAR_TAUX_OCCUPATION)//
            .headers(SPIRIT_STARK_REQUEST_HEADER)//
            .path(_fqdnUrl)//
            .queryParameter(queryParams)//
            .build();
        response = sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content to a JSON string
      String jsonResponse = getContent(response, METHOD_NAME_FQDN_LIRE_UN_PAR_TAUX_OCCUPATION, tracabilite_p);

      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }

      // Deserialize response
      GetListeFqdnResponse getFqdnResponse = RavelJsonTools.getInstance().fromJson(jsonResponse, GetListeFqdnResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(getFqdnResponse.getRetour());
      Fqdn fqdn = null;

      if (!CollectionUtils.isEmpty(getFqdnResponse.getListeFqdn()))
      {
        fqdn = getFqdnResponse.getListeFqdn().get(0);
      }

      return new ConnectorResponse<>(retour, fqdn);
    }
    catch (Exception e_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, Nothing> gestionReferentielGererBascule(Tracabilite tracabilite_p, String typeReferentiel_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_gestionReferentielUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD3005_PATH_PARAM));
      }

      Retour retour;
      Response response;
      HashMap<String, String> queryParams = new HashMap<>();

      queryParams.put(PARAM_TYPE_REFERENTIEL, typeReferentiel_p);
      queryParams.put(PARAM_ACTION, "GererBascule"); //$NON-NLS-1$

      try
      {
        RESTRequest restRequest = new RESTRequestBuilder()//
            .httpMethod(HttpMethod.PUT)//
            .traceability(tracabilite_p)//
            .method(METHOD_NAME_GESTION_REFERENTIEL_GERER_BASCULE)//
            .headers(SPIRIT_STARK_REQUEST_HEADER)//
            .path(_gestionReferentielUrl)//
            .queryParameter(queryParams)//
            .build();
        response = sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content to a JSON string
      String jsonResponse = getContent(response, METHOD_NAME_GESTION_REFERENTIEL_GERER_BASCULE, tracabilite_p);

      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }

      BasicResponse basicResponse = GsonTools.getIso8601Ms().fromJson(jsonResponse, BasicResponse.class);

      // Retour OK
      retour = RetourConverter.convertFromJsonRetour(basicResponse.getRetour());

      return new ConnectorResponse<>(retour, null);
    }
    catch (Exception ex_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, ex_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, Nothing> gestionReferentielGererRestaurationBackup(Tracabilite tracabilite_p, String typeReferentiel_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_gestionReferentielUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD3005_PATH_PARAM));
      }

      Retour retour;
      Response response;
      HashMap<String, String> queryParams = new HashMap<>();
      queryParams.put(PARAM_TYPE_REFERENTIEL, typeReferentiel_p);
      queryParams.put(PARAM_ACTION, "GererRestaurationBackup"); //$NON-NLS-1$

      try
      {
        RESTRequest restRequest = new RESTRequestBuilder()//
            .httpMethod(HttpMethod.PUT)//
            .traceability(tracabilite_p)//
            .method(METHOD_NAME_GESTION_REFERENTIEL_GERER_RESTAURATION_BACKUP)//
            .headers(SPIRIT_STARK_REQUEST_HEADER)//
            .path(_gestionReferentielUrl)//
            .queryParameter(queryParams)//
            .build();
        response = sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content to a JSON string
      String jsonResponse = getContent(response, METHOD_NAME_GESTION_REFERENTIEL_GERER_RESTAURATION_BACKUP, tracabilite_p);

      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }

      BasicResponse basicResponse = GsonTools.getIso8601Ms().fromJson(jsonResponse, BasicResponse.class);

      // Retour OK
      retour = RetourConverter.convertFromJsonRetour(basicResponse.getRetour());

      return new ConnectorResponse<>(retour, null);
    }
    catch (Exception ex_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, ex_p.getMessage()), null);
    }
  }

  @Override
  public String getConfigParameter(String arg0_p, String arg1_p) throws RavelException
  {
    return null;
  }

  /**
   * Generic method to get the response objet from the REST response.
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param response_p
   *          the response.
   * @param callerMethod_p
   *          the method of interest.
   * @param clazz_p
   *          the class of the response.
   * @param <T>
   *          the type of the response.
   * @return the response object.
   * @throws RavelException
   *           on error.
   */
  public <T> T getContentFromResponse(Tracabilite tracabilite_p, Response response_p, String callerMethod_p, Class<T> clazz_p) throws RavelException
  {
    // Get the content to a JSON string
    String jsonResponse = super.getContent(response_p, callerMethod_p, tracabilite_p);

    if (StringTools.isNullOrEmpty(jsonResponse))
    {
      throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
    }

    return RavelJsonTools.getInstance().fromJson(jsonResponse, clazz_p);
  }

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @return a pair with the retour and the list of {@link AbaqueDSL}.
   * @throws RavelException
   *           on error.
   */
  public ConnectorResponse<Retour, List<AbaqueDSL>> loadAbaqueDslLireTous(Tracabilite tracabilite_p) throws RavelException
  {
    return _abaqueDSLService.loadAbaqueDslLireTous(tracabilite_p, _abaqueDslUrl);
  }

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @return a pair with the retour and the list of {@link AccesTechnique}.
   * @throws RavelException
   *           on error.
   */
  public ConnectorResponse<Retour, List<AccesTechnique>> loadAccesTechniqueLireTous(Tracabilite tracabilite_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_accesTechniqueUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD3004_PATH_PARAM));
      }

      // Call SAAB
      final Response response;
      try
      {
        RESTRequest restRequest = new RESTRequestBuilder()//
            .httpMethod(HttpMethod.GET)//
            .traceability(tracabilite_p)//
            .method(METHOD_NAME_ACCES_TECHNIQUE_LIRE_TOUS)//
            .headers(SPIRIT_STARK_REQUEST_HEADER)//
            .path(_accesTechniqueUrl)//
            .build();
        response = sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content to a JSON string
      String jsonResponse = getContent(response, METHOD_NAME_ACCES_TECHNIQUE_LIRE_TOUS, tracabilite_p);

      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }

      GetAccesTechniqueResponse getAccesTechniqueResponse = GsonTools.getIso8601Ms().fromJson(jsonResponse, GetAccesTechniqueResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(getAccesTechniqueResponse.getRetour());
      List<AccesTechnique> listAccesTechnique = getAccesTechniqueResponse.getListAccesTechnique();

      return new ConnectorResponse<>(retour, listAccesTechnique);
    }
    catch (Exception e_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public void loadConnectorConfiguration(Connector connector_p) throws RavelException
  {
    super.loadConnectorConfiguration(connector_p);

    // Get and validate specific configuration parameters
    for (Param param : connector_p.getParam())
    {
      switch (param.getName())
      {
        case PAD3127_PATH_PARAM:
          _ressourcePortPmUrl = param.getValue();
          break;
        case PAD3001_PATH_PARAM:
          _communeUrl = param.getValue();
          break;
        case PAD3002_PATH_PARAM:
          _previsionProgUrl = param.getValue();
          break;
        case PAD3003_PATH_PARAM:
          _integrationGroupFileUrl = param.getValue();
          break;
        case PAD3004_PATH_PARAM:
          _accesTechniqueUrl = param.getValue();
          break;
        case PAD3005_PATH_PARAM:
          _gestionReferentielUrl = param.getValue();
          break;
        case PAD3006_PATH_PARAM:
          _fichierReferentielCompositeUrl = param.getValue();
          break;
        case PAD3007_PATH_PARAM:
          _couvertureCuivreUrl = param.getValue();
          break;
        case PAD3008_PATH_PARAM:
          _couvertureFttoUrl = param.getValue();
          break;
        case PAD3009_PATH_PARAM:
          _couvertureTokyoUrl = param.getValue();
          break;
        case PAD3013_PATH_PARAM:
          _topologieArcturusUrl = param.getValue();
          break;
        case PAD3010_PATH_PARAM:
          _couvertureFtthUrl = param.getValue();
          break;
        case PAD3011_PATH_PARAM:
          _ressourceFtthUrl = param.getValue();
          break;
        case PAD3012_PATH_PARAM:
          _structureVerticaleFtthCompositeUrl = param.getValue();
          break;
        case PAD3012_RECHERCHE_PATH_PARAM:
          _structureVerticaleFtthCompositeRechercheUrl = param.getValue();
          break;
        case PAD3100_PATH_PARAM:
          _ressourceUrl = param.getValue();
          break;
        case PAD3110_PATH_PARAM:
          _ressourceRaccordementUrl = param.getValue();
          break;
        case PAD3111_PATH_PARAM:
          _ressourceRaccordementCompositeUrl = param.getValue();
          break;
        case PAD3111_MANAGE_PATH_PARAM:
          _manageRessourceRaccordementCompositeUrl = param.getValue();
          break;
        case PAD_RIF_PATH_PARAM:
          _ressourceAdresseIpClfUrl = param.getValue();
          break;
        case PAD_RCI_PATH_PARAM:
          _ressourceImpiFixeUrl = param.getValue();
          break;
        case PAD_RM2PI_PATH_PARAM:
          _ressourceCompteImsUrl = param.getValue();
          break;
        case PAD_RAIC_PATH_PARAM:
          _ressourceMotDePasseImsUrl = param.getValue();
          break;
        case PAD_ROI_PATH_PARAM:
          _ressourceOntIdUrl = param.getValue();
          break;
        case PAD3120_PATH_PARAM:
          _ressourceCompteMailUrl = param.getValue();
          break;
        case PAD3200_PATH_PARAM:
          _oltCompositeUrl = param.getValue();
          break;
        case PAD3124_PATH_PARAM:
          _ressourcePortP2PUrl = param.getValue();
          break;
        case PAD3101_PATH_PARAM:
          _ressourceReseauCompositeUrl = param.getValue();
          break;
        case PAD3202_PATH_PARAM:
          _fqdnUrl = param.getValue();
          break;
        case PAD3203_PATH_PARAM:
          _oltTousFiltreUrl = param.getValue();
          break;
        case PAD3300_PATH_PARAM:
          _cacheEligUrl = param.getValue();
          break;
        case PAD3014_PATH_PARAM:
          _dispoNroFtteOrgUrl = param.getValue();
          break;
        case PAD3015_PATH_PARAM:
          _couverture5GUrl = param.getValue();
          break;
        case PAD3016_PATH_PARAM:
          _abaqueDslUrl = param.getValue();
          break;
        case PAD3017_PATH_PARAM:
          _dispoRessourceDslOrangeUrl = param.getValue();
          break;
        case PAD3018_PATH_PARAM:
          _dispoRessourceDslBouyguesUrl = param.getValue();
          break;
        case PAD3019_PATH_PARAM:
          _dispoRessourceDslAxioneUrl = param.getValue();
          break;
        case PAD3020_PATH_PARAM:
          _dispoRessourceDslSFRUrl = param.getValue();
          break;
        case PAD3021_PATH_PARAM:
          _entonnoirCommuneUrl = param.getValue();
          break;
        case PAD3022_PATH_PARAM:
          _entonnoirVoieUrl = param.getValue();
          break;
        case PAD3023_PATH_PARAM:
          _entonnoirNumeroUrl = param.getValue();
          break;
        case PAD3024_PATH_PARAM:
          _couvertureGeocodageUrl = param.getValue();
          break;
        case PAD3204_PATH_PARAM:
          _nouedRacordementUrl = param.getValue();
          break;
        case PAD3205_PATH_PARAM:
          _pmCompositeUrl = param.getValue();
          break;
        case PAD3207_POOL_IP_PATH_PARAM:
          _poolIpUrl = param.getValue();
          break;
        case PAD3206_POINT_ANCRAGE_IP_PATH_PARAM:
          _pointAncrageIpUrl = param.getValue();
          break;
        case PORTE_DE_COLLECTE_PATH_PARAM:
          _porteDeCollecteUrl = param.getValue();
          break;
        case ACCES_TECHNIQUE_CACHE_DURATION:
          _accesTechniqueCacheDuration = Duration.parse(param.getValue());
          break;
        case ABAQUE_DSL_CACHE_DURATION:
          _abaqueDslCacheDuration = Duration.parse(param.getValue());
          break;
        case CREATE_LONG_TIMEOUT_PARAM:
          try
          {
            _createLongTimeout = Integer.parseInt(param.getValue());
          }
          catch (final NumberFormatException e)
          {
            RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, MessageFormat.format(MESSAGE_WRONG_CONFIGURATION_PARAMETER, CREATE_LONG_TIMEOUT_PARAM)));
            _createLongTimeout = 30000;
          }
          break;
        default:
          break;
      }
    }

    if (_accesTechniqueCacheDuration == null)
    {
      throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_WRONG_CONFIGURATION_PARAMETER, ACCES_TECHNIQUE_CACHE_DURATION));
    }
    if (_abaqueDslCacheDuration == null)
    {
      throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_WRONG_CONFIGURATION_PARAMETER, ABAQUE_DSL_CACHE_DURATION));
    }

    // Load Services
    _abaqueDSLService = new AbaqueDSLService(this);
    _couverture5GService = new Couverture5GService(this);
    _dispoRessourceDSLService = new DispoRessourceDSLService(this);
    _couvertureFTTHService = new CouvertureFTTHService(this);
    _entonnoirCommuneService = new EntonnoirCommuneService(this);
    _entonnoirVoieService = new EntonnoirVoieService(this);
    _entonnoirNumeroService = new EntonnoirNumeroService(this);
    _couvertureGeoCodageService = new CouvertureGeoCodageService(this);
    _noeudRaccordementService = new NoeudRaccordementService(this);
    _pmCompositeService = new PmCompositeService(this);
    _oltCompositeService = new OltCompositeService(this);
    _ressourceService = new RessourceService(this);
    _ressourceRaccordementService = new RessourceRaccordementService(this);
    _ressourcePortPmService = new RessourcePortPmService(this);
    _poolIpService = new PoolIpService(this);
    _ressourcePortP2PService = new RessourcePortP2PService(this);
    _pointAncrageIpService = new PointAncrageIpService(this);
    _topologieArcturusService = new TopologieArcturusService(this);
    _porteDeCollecteService = new PorteDeCollecteService(this);
  }

  @Override
  public ConnectorResponse<Retour, Nothing> noeudRaccordementGererImport(Tracabilite tracabilite_p, ManageNoeudRaccordementRequest manageNoeudRaccordementRequest_) throws RavelException
  {
    return _noeudRaccordementService.noeudRaccordementGererImport(tracabilite_p, _nouedRacordementUrl, manageNoeudRaccordementRequest_);
  }

  @Override
  public ConnectorResponse<Retour, Set<CompteRenduSuppression>> noeudRaccordementGererSuppressionNrNonReference(Tracabilite tracabilite_p, Set<String> listeNomNoedRaco_p) throws RavelException
  {
    return _noeudRaccordementService.noeudRaccordementGererSuppressionNrNonReference(tracabilite_p, _nouedRacordementUrl, listeNomNoedRaco_p);
  }

  @Override
  public ConnectorResponse<Retour, Nothing> oltCompositeGererImport(Tracabilite tracabilite_p, OltComposite oltComposite_p) throws RavelException
  {
    return _oltCompositeService.oltCompositeGererImport(tracabilite_p, _oltCompositeUrl, oltComposite_p);
  }

  @Override
  public ConnectorResponse<Retour, Set<CompteRenduSuppression>> oltCompositeGererSuppressionOltNonReference(Tracabilite tracabilite_p, Set<String> listeNomOLT_p) throws RavelException
  {
    return _oltCompositeService.oltCompositeGererSuppressionOltNonReference(tracabilite_p, _oltCompositeUrl, listeNomOLT_p);
  }

  @Override
  public ConnectorResponse<Retour, GetSurchargeResponse> oltCompositeLireSurchage(Tracabilite tracabilite_p, String nomOLT_p, String action_p, String positionCarte_p, String positionPortPon_p, String positionOntId_p) throws RavelException
  {
    return _oltCompositeService.oltCompositeLireSurchage(tracabilite_p, _oltCompositeUrl, nomOLT_p, action_p, positionCarte_p, positionPortPon_p, positionOntId_p);
  }

  @Override
  public ConnectorResponse<Retour, OltComposite> oltCompositeLireUn(Tracabilite tracabilite_p, String nomOLT_p) throws RavelException
  {
    return _oltCompositeService.oltCompositeLireUn(tracabilite_p, _oltCompositeUrl, nomOLT_p);
  }

  @Override
  public ConnectorResponse<Retour, Nothing> oltCompositemodifierSurchargeDateDebutQuarantaineOLT(Tracabilite tracabilite_p, ListeTechnologieAutorisee listTechnoAutorisee_p, String nomOlt_p) throws RavelException
  {
    return _oltCompositeService.oltCompositemodifierSurchargeDateDebutQuarantaineOLT(tracabilite_p, _oltCompositeUrl, listTechnoAutorisee_p, nomOlt_p);
  }

  @Override
  public ConnectorResponse<Retour, Nothing> oltCompositeModifierSurchargeDebitGarantiPortPon(Tracabilite tracabilite_p, String nomOlt_p, String positionCarte_p, String positionPortPon_p, String debitGarantieCapaciteAllouee_p) throws RavelException
  {
    return _oltCompositeService.oltCompositeModifierSurchargeDebitGarantiPortPon(tracabilite_p, _oltCompositeUrl, nomOlt_p, positionCarte_p, positionPortPon_p, debitGarantieCapaciteAllouee_p);
  }

  @Override
  public ConnectorResponse<Retour, Nothing> oltCompositeModifierSurchargeExploitationOntId(Tracabilite tracabilite_p, String nomOlt_p, String positionCarte_p, String positionPortPon_p, String positionOntId_p, String statutExploitation_p, String commentaireExploitation_p) throws RavelException
  {
    return _oltCompositeService.oltCompositeModifierSurchargeExploitationOntId(tracabilite_p, _oltCompositeUrl, nomOlt_p, positionCarte_p, positionPortPon_p, positionOntId_p, statutExploitation_p, commentaireExploitation_p);
  }

  @Override
  public ConnectorResponse<Retour, Nothing> oltCompositeModifierSurchargePriseClientCarte(Tracabilite tracabilite_p, String nomOlt_p, String positionCarte_p, String statutBlocage_p, String commentaireBlocage_p) throws RavelException
  {
    return _oltCompositeService.oltCompositeModifierSurchargePriseClientCarte(tracabilite_p, _oltCompositeUrl, nomOlt_p, positionCarte_p, statutBlocage_p, commentaireBlocage_p);
  }

  @Override
  public ConnectorResponse<Retour, Nothing> oltCompositeModifierSurchargePriseClientOLT(Tracabilite tracabilite_p, String nomOlt_p, String statutBlocage_p, String commentaireBlocage_p) throws RavelException
  {
    return _oltCompositeService.oltCompositeModifierSurchargePriseClientOLT(tracabilite_p, _oltCompositeUrl, nomOlt_p, statutBlocage_p, commentaireBlocage_p);
  }

  @Override
  public ConnectorResponse<Retour, Nothing> oltCompositeModifierSurchargePriseClientOntId(Tracabilite tracabilite_p, String nomOlt_p, String positionCarte_p, String positionPortPon_p, String positionOntId_p, String statutBlocage_p, String commentaireBlocage_p) throws RavelException
  {
    return _oltCompositeService.oltCompositeModifierSurchargePriseClientOntId(tracabilite_p, _oltCompositeUrl, nomOlt_p, positionCarte_p, positionPortPon_p, positionOntId_p, statutBlocage_p, commentaireBlocage_p);
  }

  @Override
  public ConnectorResponse<Retour, Nothing> oltCompositeModifierSurchargePriseClientPortPon(Tracabilite tracabilite_p, String nomOlt_p, String positionCarte_p, String positionPortPon_p, String statutBlocage_p, String commentaireBlocage_p) throws RavelException
  {
    return _oltCompositeService.oltCompositeModifierSurchargePriseClientPortPon(tracabilite_p, _oltCompositeUrl, nomOlt_p, positionCarte_p, positionPortPon_p, statutBlocage_p, commentaireBlocage_p);
  }

  @Override
  public ConnectorResponse<Retour, Nothing> oltCompositeModifierSurchargeTechnoAutoriseePortPon(Tracabilite tracabilite_p, ListeTechnologieAutorisee listTechnoAutorisee_p, String nomOlt_p, String positionCarte_p, String positionPortPon_p) throws RavelException
  {
    return _oltCompositeService.oltCompositeModifierSurchargeTechnoAutoriseePortPon(tracabilite_p, _oltCompositeUrl, listTechnoAutorisee_p, nomOlt_p, positionCarte_p, positionPortPon_p);
  }

  @Override
  public ConnectorResponse<Retour, Nothing> oltCompositeModifierSurchargeVersionOLT(Tracabilite tracabilite_p, ListeTechnologieAutorisee listTechnoAutorisee_p, String nomOlt_p, String versionInterfaceEchange_p) throws RavelException
  {
    return _oltCompositeService.oltCompositeModifierSurchargeVersionOLT(tracabilite_p, _oltCompositeUrl, listTechnoAutorisee_p, nomOlt_p, versionInterfaceEchange_p);
  }

  /**
   * pad3001CommuneCreate
   */
  @Override
  public ConnectorResponse<Retour, Boolean> pad3001CommuneCreate(Tracabilite tracabilite_p, ListeCommuneRequest listeCommune_p) throws RavelException
  {
    if (StringTools.isNullOrEmpty(_communeUrl))
    {
      throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD3001_PATH_PARAM));
    }

    RESTRequest restRequest = new RESTRequestBuilder()//
        .httpMethod(HttpMethod.POST)//
        .request(listeCommune_p)//
        .traceability(tracabilite_p)//
        .method(METHOD_NAME_PAD3001_CREATE)//
        .headers(SPIRIT_STARK_REQUEST_HEADER)//
        .path(_communeUrl)//
        .timeout(_createLongTimeout)//
        .build();
    Response response = sendRequest(restRequest);

    // Get the content to a JSON string
    String jsonResponse = getContent(response, METHOD_NAME_PAD3001_CREATE, tracabilite_p);

    if (StringTools.isNullOrEmpty(jsonResponse))
    {
      throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
    }

    JsonParser jsonParser = new JsonParser();
    JsonObject json = jsonParser.parse(jsonResponse).getAsJsonObject();
    Retour retour = GsonTools.getIso8601Ms().fromJson(json.get(IMegSpiritConsts.RETOUR), Retour.class);

    if (RetourFactory.isRetourOK(retour))
    {
      return new ConnectorResponse<>(retour, true);
    }
    else
    {
      return new ConnectorResponse<>(retour, false);
    }

  }

  @Override
  public ConnectorResponse<Retour, ListeCommuneResponse> pad3001CommuneReadAncienCodeInsee(Tracabilite tracabilite_p, String codeInsee_p) throws RavelException
  {
    if (StringTools.isNullOrEmpty(_communeUrl))
    {
      throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD3001_PATH_PARAM));
    }

    ListeCommuneResponse listeCommune = null;
    Retour retour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, StringConstants.EMPTY_STRING);

    HashMap<String, String> queryParams = new HashMap<>();
    if (!StringTools.isNullOrEmpty(codeInsee_p))
    {
      queryParams.put(PARAM_ANCIEN_CODE_INSEE, codeInsee_p);
    }

    RESTRequest restRequest = new RESTRequestBuilder()//
        .httpMethod(HttpMethod.GET)//
        .traceability(tracabilite_p)//
        .method(METHOD_NAME_PAD3001_ANCIEN_INSEE)//
        .headers(SPIRIT_STARK_REQUEST_HEADER)//
        .path(_communeUrl)//
        .queryParameter(queryParams)//
        .build();
    Response response = sendRequest(restRequest);
    // Get the content to a JSON string
    String jsonResponse = getContent(response, METHOD_NAME_PAD3001_ANCIEN_INSEE, tracabilite_p);

    if (StringTools.isNullOrEmpty(jsonResponse))
    {
      throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
    }
    JsonParser jsonParser = new JsonParser();
    JsonObject json = jsonParser.parse(jsonResponse).getAsJsonObject();
    retour = GsonTools.getIso8601Ms().fromJson(json.get(IMegSpiritConsts.RETOUR), Retour.class);
    if (RetourFactory.isRetourOK(retour))
    {
      listeCommune = GsonTools.getIso8601Ms().fromJson(jsonResponse, ListeCommuneResponse.class);
    }
    return new ConnectorResponse<>(retour, listeCommune);
  }

  @Override
  public ConnectorResponse<Retour, ListeCommuneResponse> pad3001CommuneReadCodeInsee(Tracabilite tracabilite_p, String codeInsee_p) throws RavelException
  {
    if (StringTools.isNullOrEmpty(_communeUrl))
    {
      throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD3001_PATH_PARAM));
    }

    ListeCommuneResponse listeCommune = null;
    Retour retour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, StringConstants.EMPTY_STRING);

    HashMap<String, String> queryParams = new HashMap<>();
    if (!StringTools.isNullOrEmpty(codeInsee_p))
    {
      queryParams.put(PARAM_CODE_INSEE, codeInsee_p);
    }

    RESTRequest restRequest = new RESTRequestBuilder()//
        .httpMethod(HttpMethod.GET)//
        .traceability(tracabilite_p)//
        .method(METHOD_NAME_PAD3001_INSEE)//
        .headers(SPIRIT_STARK_REQUEST_HEADER)//
        .path(_communeUrl)//
        .queryParameter(queryParams)//
        .build();
    Response response = sendRequest(restRequest);
    // Get the content to a JSON string
    String jsonResponse = getContent(response, METHOD_NAME_PAD3001_INSEE, tracabilite_p);

    if (StringTools.isNullOrEmpty(jsonResponse))
    {
      throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
    }
    JsonParser jsonParser = new JsonParser();
    JsonObject json = jsonParser.parse(jsonResponse).getAsJsonObject();
    retour = GsonTools.getIso8601Ms().fromJson(json.get(IMegSpiritConsts.RETOUR), Retour.class);
    if (RetourFactory.isRetourOK(retour))
    {

      listeCommune = GsonTools.getIso8601Ms().fromJson(jsonResponse, ListeCommuneResponse.class);
    }
    return new ConnectorResponse<>(retour, listeCommune);
  }

  @Override
  public ConnectorResponse<Retour, ListeCommuneResponse> pad3001CommuneReadCodePostal(Tracabilite tracabilite_p, String codePostal_p) throws RavelException
  {
    if (StringTools.isNullOrEmpty(_communeUrl))
    {
      throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD3001_PATH_PARAM));
    }

    ListeCommuneResponse listeCommune = null;
    Retour retour;

    HashMap<String, String> queryParams = new HashMap<>();
    if (!StringTools.isNullOrEmpty(codePostal_p))
    {
      queryParams.put(PARAM_CODE_POSTAL, codePostal_p);
    }

    RESTRequest restRequest = new RESTRequestBuilder()//
        .httpMethod(HttpMethod.GET)//
        .traceability(tracabilite_p)//
        .method(METHOD_NAME_PAD3001_CODE_POSTAL)//
        .headers(SPIRIT_STARK_REQUEST_HEADER)//
        .path(_communeUrl)//
        .queryParameter(queryParams)//
        .build();
    Response response = sendRequest(restRequest);
    // Get the content to a JSON string
    String jsonResponse = getContent(response, METHOD_NAME_PAD3001_CODE_POSTAL, tracabilite_p);

    if (StringTools.isNullOrEmpty(jsonResponse))
    {
      throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
    }
    JsonParser jsonParser = new JsonParser();
    JsonObject json = jsonParser.parse(jsonResponse).getAsJsonObject();
    retour = GsonTools.getIso8601Ms().fromJson(json.get(IMegSpiritConsts.RETOUR), Retour.class);
    if (RetourFactory.isRetourOK(retour))
    {
      listeCommune = GsonTools.getIso8601Ms().fromJson(jsonResponse, ListeCommuneResponse.class);
    }
    return new ConnectorResponse<>(retour, listeCommune);
  }

  @Override
  public ConnectorResponse<Retour, Boolean> pad3002PrevisionProgCreate(Tracabilite tracabilite_p, ListePrevisionRequest listePrevision_p) throws RavelException
  {
    if (StringTools.isNullOrEmpty(_previsionProgUrl))
    {
      throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD3002_PATH_PARAM));
    }

    Retour retour;
    boolean result;

    RESTRequest restRequest = new RESTRequestBuilder()//
        .httpMethod(HttpMethod.POST)//
        .request(listePrevision_p)//
        .traceability(tracabilite_p)//
        .method(METHOD_NAME_PAD3002_PREVISION_PROG)//
        .headers(SPIRIT_STARK_REQUEST_HEADER)//
        .path(_previsionProgUrl)//
        .timeout(_createLongTimeout)//
        .build();
    Response response = sendRequest(restRequest);
    // Get the content to a JSON string
    String jsonResponse = getContent(response, METHOD_NAME_PAD3002_PREVISION_PROG, tracabilite_p);

    if (StringTools.isNullOrEmpty(jsonResponse))
    {
      throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
    }

    JsonParser jsonParser = new JsonParser();
    JsonObject json = jsonParser.parse(jsonResponse).getAsJsonObject();
    retour = GsonTools.getIso8601Ms().fromJson(json.get(IMegSpiritConsts.RETOUR), Retour.class);
    result = RetourFactory.isRetourOK(retour);
    return new ConnectorResponse<>(retour, result);
  }

  @Override
  public ConnectorResponse<Retour, ListePrevisionResponse> pad3002PrevisionProgRead(Tracabilite tracabilite_p, String nomProgramme_p, String codeInsee_p) throws RavelException
  {
    if (StringTools.isNullOrEmpty(_previsionProgUrl))
    {
      throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD3002_PATH_PARAM));
    }

    ListePrevisionResponse listePrevision = null;
    Retour retour;

    HashMap<String, String> queryParams = new HashMap<>();
    if (!StringTools.isNullOrEmpty(nomProgramme_p) && !StringTools.isNullOrEmpty(codeInsee_p))
    {
      queryParams.put(PARAM_NOM_PROGRAMME, nomProgramme_p);
      queryParams.put(PARAM_CODE_INSEE, codeInsee_p);
    }

    RESTRequest restRequest = new RESTRequestBuilder()//
        .httpMethod(HttpMethod.GET)//
        .traceability(tracabilite_p)//
        .method(METHOD_NAME_PAD3002_READ)//
        .headers(SPIRIT_STARK_REQUEST_HEADER)//
        .path(_previsionProgUrl)//
        .queryParameter(queryParams)//
        .build();
    Response response = sendRequest(restRequest);
    // Get the content to a JSON string
    String jsonResponse = getContent(response, METHOD_NAME_PAD3002_READ, tracabilite_p);

    if (StringTools.isNullOrEmpty(jsonResponse))
    {
      throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
    }
    JsonParser jsonParser = new JsonParser();
    JsonObject json = jsonParser.parse(jsonResponse).getAsJsonObject();
    retour = GsonTools.getIso8601Ms().fromJson(json.get(IMegSpiritConsts.RETOUR), Retour.class);
    if (RetourFactory.isRetourOK(retour))
    {
      listePrevision = GsonTools.getIso8601Ms().fromJson(jsonResponse, ListePrevisionResponse.class);
    }
    return new ConnectorResponse<>(retour, listePrevision);
  }

  /**
   * pad3003IntegrationGroupeFichierCreate
   */
  @Override
  public ConnectorResponse<Retour, Boolean> pad3003IntegrationGroupeFichierCreate(Tracabilite tracabilite_p, IntegrationGroupeFichierRequest integration_p) throws RavelException
  {
    if (StringTools.isNullOrEmpty(_integrationGroupFileUrl))
    {
      throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD3003_PATH_PARAM));
    }

    Retour retour;
    boolean result;

    RESTRequest restRequest = new RESTRequestBuilder()//
        .httpMethod(HttpMethod.POST)//
        .traceability(tracabilite_p)//
        .method(METHOD_NAME_PAD3003_CREATE)//
        .headers(SPIRIT_STARK_REQUEST_HEADER)//
        .path(_integrationGroupFileUrl)//
        .request(integration_p)//
        .build();
    Response response = sendRequest(restRequest);
    // Get the content to a JSON string
    String jsonResponse = getContent(response, METHOD_NAME_PAD3003_CREATE, tracabilite_p);

    if (StringTools.isNullOrEmpty(jsonResponse))
    {
      throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
    }

    JsonParser jsonParser = new JsonParser();
    JsonObject json = jsonParser.parse(jsonResponse).getAsJsonObject();
    retour = GsonTools.getIso8601Ms().fromJson(json.get(IMegSpiritConsts.RETOUR), Retour.class);
    result = RetourFactory.isRetourOK(retour);
    return new ConnectorResponse<>(retour, result);
  }

  @Override
  public ConnectorResponse<Retour, Boolean> pad3003IntegrationGroupeFichierDelete(Tracabilite tracabilite_p, String nomGroupeFichier_p, String action_p) throws RavelException
  {
    if (StringTools.isNullOrEmpty(_integrationGroupFileUrl))
    {
      throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD3003_PATH_PARAM));
    }

    Retour retour;
    boolean result;

    HashMap<String, String> queryParams = new HashMap<>();
    if (!StringTools.isNullOrEmpty(nomGroupeFichier_p) && !StringTools.isNullOrEmpty(action_p))
    {
      queryParams.put(PARAM_NOM_GROUPE_FICHIER, nomGroupeFichier_p);
      queryParams.put(PARAM_ACTION, action_p);
    }

    RESTRequest restRequest = new RESTRequestBuilder()//
        .httpMethod(HttpMethod.DELETE)//
        .traceability(tracabilite_p)//
        .method(METHOD_NAME_PAD3003_DELETE)//
        .headers(SPIRIT_STARK_REQUEST_HEADER)//
        .path(_integrationGroupFileUrl)//
        .queryParameter(queryParams)//
        .build();
    Response response = sendRequest(restRequest);
    // Get the content to a JSON string
    String jsonResponse = getContent(response, METHOD_NAME_PAD3003_DELETE, tracabilite_p);

    if (StringTools.isNullOrEmpty(jsonResponse))
    {
      throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
    }

    JsonParser jsonParser = new JsonParser();
    JsonObject json = jsonParser.parse(jsonResponse).getAsJsonObject();
    retour = GsonTools.getIso8601Ms().fromJson(json.get(IMegSpiritConsts.RETOUR), Retour.class);
    result = RetourFactory.isRetourOK(retour);
    return new ConnectorResponse<>(retour, result);
  }

  @Override
  public ConnectorResponse<Retour, IntegrationGroupeFichierResponse> pad3003IntegrationGroupeFichierRead(Tracabilite tracabilite_p, String nomGroupeFichier_p) throws RavelException
  {
    if (StringTools.isNullOrEmpty(_integrationGroupFileUrl))
    {
      throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD3003_PATH_PARAM));
    }

    IntegrationGroupeFichierResponse integrationFichier = null;
    Retour retour;

    HashMap<String, String> queryParams = new HashMap<>();
    if (!StringTools.isNullOrEmpty(nomGroupeFichier_p))
    {
      queryParams.put(PARAM_NOM_GROUPE_FICHIER, nomGroupeFichier_p);
    }

    RESTRequest restRequest = new RESTRequestBuilder()//
        .httpMethod(HttpMethod.GET)//
        .traceability(tracabilite_p)//
        .method(METHOD_NAME_PAD3003_READ)//
        .headers(SPIRIT_STARK_REQUEST_HEADER)//
        .path(_integrationGroupFileUrl)//
        .queryParameter(queryParams)//
        .build();
    Response response = sendRequest(restRequest);
    // Get the content to a JSON string
    String jsonResponse = getContent(response, METHOD_NAME_PAD3003_READ, tracabilite_p);

    if (StringTools.isNullOrEmpty(jsonResponse))
    {
      throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
    }
    JsonParser jsonParser = new JsonParser();
    JsonObject json = jsonParser.parse(jsonResponse).getAsJsonObject();
    retour = GsonTools.getIso8601Ms().fromJson(json.get(IMegSpiritConsts.RETOUR), Retour.class);
    if (RetourFactory.isRetourOK(retour))
    {
      integrationFichier = GsonTools.getIso8601Ms().fromJson(jsonResponse, IntegrationGroupeFichierResponse.class);
    }
    return new ConnectorResponse<>(retour, integrationFichier);
  }

  @Override
  public ConnectorResponse<Retour, Boolean> pad3003IntegrationGroupeFichierUpdate(Tracabilite tracabilite_p, String nomGroupeFichier_p, String action_p) throws RavelException
  {
    if (StringTools.isNullOrEmpty(_integrationGroupFileUrl))
    {
      throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD3003_PATH_PARAM));
    }

    Retour retour;
    boolean result;

    HashMap<String, String> queryParams = new HashMap<>();
    if (!StringTools.isNullOrEmpty(nomGroupeFichier_p) && !StringTools.isNullOrEmpty(action_p))
    {
      queryParams.put(PARAM_NOM_GROUPE_FICHIER, nomGroupeFichier_p);
      queryParams.put(PARAM_ACTION, action_p);
    }

    RESTRequest restRequest = new RESTRequestBuilder()//
        .httpMethod(HttpMethod.PUT)//
        .traceability(tracabilite_p)//
        .method(METHOD_NAME_PAD3003_UPDATE)//
        .headers(SPIRIT_STARK_REQUEST_HEADER)//
        .path(_integrationGroupFileUrl)//
        .queryParameter(queryParams)//
        .build();
    Response response = sendRequest(restRequest);
    // Get the content to a JSON string
    String jsonResponse = getContent(response, METHOD_NAME_PAD3003_UPDATE, tracabilite_p);

    if (StringTools.isNullOrEmpty(jsonResponse))
    {
      throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
    }

    JsonParser jsonParser = new JsonParser();
    JsonObject json = jsonParser.parse(jsonResponse).getAsJsonObject();
    retour = GsonTools.getIso8601Ms().fromJson(json.get(IMegSpiritConsts.RETOUR), Retour.class);
    result = RetourFactory.isRetourOK(retour);
    return new ConnectorResponse<>(retour, result);
  }

  @Override
  public ConnectorResponse<Retour, RessourceAggrege> pad3101RessourceAggregeP2PLireUn(Tracabilite tracabilite_p, String typeRessourceAggrege_p, String idRessource_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_ressourceReseauCompositeUrl))
      {
        throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD3101_PATH_PARAM));
      }
      // Query parameters
      HashMap<String, String> queryParams = new HashMap<>();
      if (StringTools.isNotNullOrEmpty(idRessource_p) && StringTools.isNotNullOrEmpty(typeRessourceAggrege_p))
      {
        queryParams.put(PARAM_TYPE_RESSOURCE_AGGREGE, typeRessourceAggrege_p);
        queryParams.put(PARAM_ID_RESSOURCE, idRessource_p);
      }
      // Call SAAB
      final Response response;
      try
      {
        RESTRequest request = new RESTRequestBuilder()//
            .httpMethod(HttpMethod.GET)//
            .traceability(tracabilite_p)//
            .headers(SPIRIT_STARK_REQUEST_HEADER)//
            .path(_ressourceReseauCompositeUrl)//
            .queryParameter(queryParams)//
            .method(METHOD_NAME_PAD3101_RESSOURCE_AGGREGE_LIRE_UN)//
            .build();
        response = sendRequest(request);
      }
      catch (Exception e_p)
      {
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }
      // Get the content to a JSON string
      String jsonResponse = getContent(response, METHOD_NAME_PAD3101_RESSOURCE_AGGREGE_LIRE_UN, tracabilite_p);
      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }
      GetRessourceAggrege getRessourceAggregeP2P = RavelJsonTools.getInstance().fromJson(jsonResponse, GetRessourceAggrege.class);
      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(getRessourceAggregeP2P.getRetour());
      return new ConnectorResponse<>(retour, getRessourceAggregeP2P.getRessourceAggrege());
    }
    catch (Exception e_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, List<Olt>> pad3203OltLireTousFiltreNomOlt(Tracabilite tracabilite_p, ListeNomOLTRequest listNomOlt_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_oltTousFiltreUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD3203_PATH_PARAM));
      }
      // Call SAAB
      final Response response;
      try
      {
        RESTRequest restRequest = new RESTRequestBuilder()//
            .httpMethod(HttpMethod.POST)//
            .request(listNomOlt_p)//
            .serializer(_jsonBuilder)//
            .traceability(tracabilite_p)//
            .method(METHOD_NAME_PAD3203_CREATE)//
            .headers(SPIRIT_STARK_REQUEST_HEADER)//
            .path(_oltTousFiltreUrl)//
            .build();
        response = sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }
      // Get the content to a JSON string
      String jsonResponse = getContent(response, METHOD_NAME_PAD3203_CREATE, tracabilite_p);
      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }
      GetListeOltResponse getListOltResponse = RavelJsonTools.getInstance().fromJson(jsonResponse, GetListeOltResponse.class);
      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(getListOltResponse.getRetour());
      List<Olt> listOlt = getListOltResponse.getListeOlt();
      return new ConnectorResponse<>(retour, listOlt);
    }
    catch (Exception e_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Deprecated
  @Override
  public ConnectorResponse<Retour, Nothing> pmCompositeGererImport(Tracabilite tracabilite_p, PMComposite pmComposite_p) throws RavelException
  {
    return _pmCompositeService.gererImport(tracabilite_p, _pmCompositeUrl, pmComposite_p, null);
  }

  @Override
  public ConnectorResponse<Retour, Nothing> pmCompositeGererImport(Tracabilite tracabilite_p, PMComposite pmComposite_p, String typeFluxImport_p) throws RavelException
  {
    return _pmCompositeService.gererImport(tracabilite_p, _pmCompositeUrl, pmComposite_p, typeFluxImport_p);
  }

  @Override
  public ConnectorResponse<Retour, Set<CompteRenduSuppression>> pmCompositeGererSuppressionPMNonReference(Tracabilite tracabilite_p, Set<String> listNomPM_p) throws RavelException
  {
    return _pmCompositeService.gererSuppressionPMNonReference(tracabilite_p, _pmCompositeUrl, listNomPM_p);
  }

  @Override
  public ConnectorResponse<Retour, PMConsultResponse> pmCompositeLireSurchargeBoitierPM(Tracabilite tracabilite_p, String referencePmBytel_p, String referenceBoitierPm_p, String nomPanneau_p, String positionPortPM_p) throws RavelException
  {
    return _pmCompositeService.lireSurchargeBoitierPM(tracabilite_p, _pmCompositeUrl, referencePmBytel_p, referenceBoitierPm_p, nomPanneau_p, positionPortPM_p);
  }

  @Override
  public ConnectorResponse<Retour, PMConsultResponse> pmCompositeLireSurchargePM(Tracabilite tracabilite_p, String referencePmBytel_p, String referenceBoitierPm_p, String nomPanneau_p, String positionPortPM_p) throws RavelException
  {
    return _pmCompositeService.lireSurchargePM(tracabilite_p, _pmCompositeUrl, referencePmBytel_p, referenceBoitierPm_p, nomPanneau_p, positionPortPM_p);
  }

  @Override
  public ConnectorResponse<Retour, PMConsultResponse> pmCompositeLireSurchargePortPM(Tracabilite tracabilite_p, String referencePmBytel_p, String referenceBoitierPm_p, String nomPanneau_p, String positionPortPM_p) throws RavelException
  {
    return _pmCompositeService.lireSurchargePortPM(tracabilite_p, _pmCompositeUrl, referencePmBytel_p, referenceBoitierPm_p, nomPanneau_p, positionPortPM_p);
  }

  @Override
  public ConnectorResponse<Retour, PMComposite> pmCompositeLireUnParReferencePmBytel(Tracabilite tracabilite_p, String referencePmBytel_p) throws RavelException
  {
    return _pmCompositeService.lireUnParReferencePmBytel(tracabilite_p, _pmCompositeUrl, referencePmBytel_p);
  }

  @Override
  public ConnectorResponse<Retour, PMComposite> pmCompositeLireUnParReferencePmOi(Tracabilite tracabilite_p, String referencePmOi_p)
  {
    return _pmCompositeService.lireUnParReferencePmOi(tracabilite_p, _pmCompositeUrl, referencePmOi_p);
  }

  @Override
  public ConnectorResponse<Retour, Nothing> pmCompositeModifierSurchargeDateDebutQuarantainePM(Tracabilite tracabilite_p, String referencePmBytel_p) throws RavelException
  {
    return _pmCompositeService.modifierSurchargeDateDebutQuarantainePM(tracabilite_p, _pmCompositeUrl, referencePmBytel_p);
  }

  @Override
  public ConnectorResponse<Retour, Nothing> pmCompositeModifierSurchargeExploitationPortPM(Tracabilite tracabilite_p, String referencePmBytel_p, String referenceBoitierPm_p, String nomPanneau_p, String positionPortPM_p, String statutExploitation_p, String commentaireExploitation_p) throws RavelException
  {
    return _pmCompositeService.modifierSurchargeExploitationPortPM(tracabilite_p, _pmCompositeUrl, referencePmBytel_p, referenceBoitierPm_p, nomPanneau_p, positionPortPM_p, statutExploitation_p, commentaireExploitation_p);
  }

  @Override
  public ConnectorResponse<Retour, Nothing> pmCompositeModifierSurchargePriseClientBoitierPM(Tracabilite tracabilite_p, String referencePmBytel_p, String referenceBoitierPm_p, String statutBlocage_p, String commentaireBlocage_p) throws RavelException
  {
    return _pmCompositeService.modifierSurchargePriseClientBoitierPM(tracabilite_p, _pmCompositeUrl, referencePmBytel_p, referenceBoitierPm_p, statutBlocage_p, commentaireBlocage_p);
  }

  @Override
  public ConnectorResponse<Retour, Nothing> pmCompositeModifierSurchargePriseClientPM(Tracabilite tracabilite_p, String referencePmBytel_p, String statutBlocage_p, String commentaireBlocage_p) throws RavelException
  {
    return _pmCompositeService.modifierSurchargePriseClientPM(tracabilite_p, _pmCompositeUrl, referencePmBytel_p, statutBlocage_p, commentaireBlocage_p);
  }

  @Override
  public ConnectorResponse<Retour, Nothing> pmCompositeModifierSurchargePriseClientPortPM(Tracabilite tracabilite_p, String referencePmBytel_p, String referenceBoitierPm_p, String nomPanneau_p, String positionPortPM_p, String statutBlocage_p, String commentaireBlocage_p) throws RavelException
  {
    return _pmCompositeService.modifierSurchargePriseClientPortPM(tracabilite_p, _pmCompositeUrl, referencePmBytel_p, referenceBoitierPm_p, nomPanneau_p, positionPortPM_p, statutBlocage_p, commentaireBlocage_p);
  }

  @Override
  public ConnectorResponse<Retour, Nothing> pointAncrageIpGererImport(Tracabilite tracabilite_p, PointAncrageIP pointAncrageIP_p) throws RavelException
  {
    return _pointAncrageIpService.pointAncrageIpGererImport(tracabilite_p, pointAncrageIP_p, _pointAncrageIpUrl);
  }

  @Override
  public ConnectorResponse<Retour, Set<CompteRenduSuppression>> pointAncrageIpGererSuppressionPointAncrageIPNonReference(Tracabilite tracabilite_p, Set<String> listeNomPointAncrageIP_p, String typePointAncrageIP_p) throws RavelException
  {
    return _pointAncrageIpService.pointAncrageIpGererSuppressionPointAncrageIPNonReference(tracabilite_p, listeNomPointAncrageIP_p, typePointAncrageIP_p, _pointAncrageIpUrl);
  }

  @Override
  public ConnectorResponse<Retour, Nothing> poolIpGererImport(Tracabilite tracabilite_p, PoolIP poolIP_p)
  {
    return _poolIpService.poolIpGererImport(tracabilite_p, _poolIpUrl, poolIP_p);
  }

  @Override
  public ConnectorResponse<Retour, Nothing> porteDeCollecteGererImport(Tracabilite tracabilite_p, PorteDeCollecte porteDeCollecte_p)
  {
    return _porteDeCollecteService.gererImport(tracabilite_p, _porteDeCollecteUrl, porteDeCollecte_p);
  }

  @Override
  public ConnectorResponse<Retour, Set<CompteRenduSuppression>> porteDeCollecteGererSuppressionPorteDeCollecteNonReference(Tracabilite tracabilite_p, Set<String> setIdNomCollecte_p)
  {
    return _porteDeCollecteService.gererSuppressionPorteDeCollecteNonReference(tracabilite_p, _porteDeCollecteUrl, setIdNomCollecte_p);
  }

  @Override
  public ConnectorResponse<Retour, PorteDeCollecte> porteDeCollecteLireUn(Tracabilite tracabilite_p, String idNomCollecte_p) throws RavelException
  {
    return _porteDeCollecteService.lireUn(tracabilite_p, _porteDeCollecteUrl, idNomCollecte_p);
  }

  @Override
  public ConnectorResponse<Retour, Nothing> ressourceAdresseIpClfCreer(Tracabilite tracabilite_p, Ressource ressource_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_ressourceAdresseIpClfUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD3003_PATH_PARAM));
      }

      // Call SAAB
      final Response response;
      try
      {
        RESTRequest restRequest = new RESTRequestBuilder()//
            .httpMethod(HttpMethod.POST)//
            .traceability(tracabilite_p)//
            .serializer(_jsonBuilder)//
            .method(METHOD_NAME_RESSOURCE_ADRESSE_IP_CLF_CREER)//
            .headers(SPIRIT_STARK_REQUEST_HEADER)//
            .path(_ressourceAdresseIpClfUrl)//
            .request(ressource_p)//
            .build();
        response = sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content to a JSON string
      String jsonResponse = getContent(response, METHOD_NAME_RESSOURCE_ADRESSE_IP_CLF_CREER, tracabilite_p);

      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }

      BasicResponse basicResponse = GsonTools.getIso8601Ms().fromJson(jsonResponse, BasicResponse.class);
      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(basicResponse.getRetour());
      return new ConnectorResponse<>(retour, null);
    }
    catch (Exception e_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, Nothing> ressourceAdresseIpClfModifierStatutAllocation(Tracabilite tracabilite_p, String idRessource_p, String idSt_p, String statut_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_ressourceAdresseIpClfUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD3003_PATH_PARAM));
      }
      // Query parameters
      HashMap<String, String> queryParams = new HashMap<>();
      if (StringTools.isNotNullOrEmpty(idRessource_p) && StringTools.isNotNullOrEmpty(idSt_p) && StringTools.isNotNullOrEmpty(statut_p))
      {
        queryParams.put(PARAM_ID_RESSOURCE, idRessource_p);
        queryParams.put(PARAM_ID_ST, idSt_p);
        queryParams.put(PARAM_STATUT, statut_p);
      }
      // Call SAAB
      final Response response;
      try
      {
        RESTRequest restRequest = new RESTRequestBuilder()//
            .httpMethod(HttpMethod.PUT)//
            .traceability(tracabilite_p)//
            .method(METHOD_NAME_RESSOURCE_ADRESSE_IP_CLF_MODIFIER_STATUT)//
            .headers(SPIRIT_STARK_REQUEST_HEADER)//
            .path(_ressourceAdresseIpClfUrl)//
            .queryParameter(queryParams)//
            .build();
        response = sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }
      // Get the content to a JSON string
      String jsonResponse = getContent(response, METHOD_NAME_RESSOURCE_ADRESSE_IP_CLF_MODIFIER_STATUT, tracabilite_p);

      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }
      BasicResponse basicResponse = GsonTools.getIso8601Ms().fromJson(jsonResponse, BasicResponse.class);
      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(basicResponse.getRetour());
      return new ConnectorResponse<>(retour, null);
    }
    catch (Exception e_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, Nothing> ressourceCompteImsCreer(Tracabilite tracabilite_p, Ressource ressource_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_ressourceCompteImsUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD3003_PATH_PARAM));
      }

      // Call SAAB
      final Response response;
      try
      {
        RESTRequest restRequest = new RESTRequestBuilder()//
            .httpMethod(HttpMethod.POST)//
            .traceability(tracabilite_p)//
            .serializer(_jsonBuilder)//
            .method(METHOD_NAME_RESSOURCE_COMPTE_IMS_CREER)//
            .headers(SPIRIT_STARK_REQUEST_HEADER)//
            .path(_ressourceCompteImsUrl)//
            .request(ressource_p)//
            .build();
        response = sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content to a JSON string
      String jsonResponse = getContent(response, METHOD_NAME_RESSOURCE_COMPTE_IMS_CREER, tracabilite_p);

      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }

      BasicResponse basicResponse = GsonTools.getIso8601Ms().fromJson(jsonResponse, BasicResponse.class);
      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(basicResponse.getRetour());
      return new ConnectorResponse<>(retour, null);
    }
    catch (Exception e_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, Nothing> ressourceCompteImsModifierStatutAllocation(Tracabilite tracabilite_p, String idRessource_p, String idSt_p, String statut_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_ressourceCompteImsUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD3003_PATH_PARAM));
      }
      // Query parameters
      HashMap<String, String> queryParams = new HashMap<>();
      if (StringTools.isNotNullOrEmpty(idRessource_p) && StringTools.isNotNullOrEmpty(idSt_p) && StringTools.isNotNullOrEmpty(statut_p))
      {
        queryParams.put(PARAM_ID_RESSOURCE, idRessource_p);
        queryParams.put(PARAM_ID_ST, idSt_p);
        queryParams.put(PARAM_STATUT, statut_p);
      }
      // Call SAAB
      final Response response;
      try
      {
        RESTRequest restRequest = new RESTRequestBuilder()//
            .httpMethod(HttpMethod.PUT)//
            .traceability(tracabilite_p)//
            .method(METHOD_NAME_RESSOURCE_COMPTE_IMS_MODIFIER_STATUT)//
            .headers(SPIRIT_STARK_REQUEST_HEADER)//
            .path(_ressourceCompteImsUrl)//
            .queryParameter(queryParams)//
            .build();
        response = sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }
      // Get the content to a JSON string
      String jsonResponse = getContent(response, METHOD_NAME_RESSOURCE_COMPTE_IMS_MODIFIER_STATUT, tracabilite_p);

      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }
      BasicResponse basicResponse = GsonTools.getIso8601Ms().fromJson(jsonResponse, BasicResponse.class);
      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(basicResponse.getRetour());
      return new ConnectorResponse<>(retour, null);
    }
    catch (Exception e_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, Nothing> ressourceCompteMailCreer(Tracabilite tracabilite_p, Ressource ressource_p)
  {
    try
    {
      if (StringTools.isNullOrEmpty(_ressourceCompteMailUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD3003_PATH_PARAM));
      }

      // Call SAAB
      final Response response;
      try
      {
        RESTRequest restRequest = new RESTRequestBuilder()//
            .httpMethod(HttpMethod.POST)//
            .traceability(tracabilite_p)//
            .serializer(_jsonBuilder)//
            .method(METHOD_NAME_RESSOURCE_COMPTE_MAIL_CREER)//
            .headers(SPIRIT_STARK_REQUEST_HEADER)//
            .path(_ressourceCompteMailUrl)//
            .request(ressource_p)//
            .build();
        response = sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content to a JSON string
      String jsonResponse = getContent(response, METHOD_NAME_RESSOURCE_COMPTE_MAIL_CREER, tracabilite_p);

      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }

      BasicResponse basicResponse = GsonTools.getIso8601Ms().fromJson(jsonResponse, BasicResponse.class);
      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(basicResponse.getRetour());
      return new ConnectorResponse<>(retour, null);
    }
    catch (Exception e_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }

  }

  @Override
  public ConnectorResponse<Retour, Nothing> ressourceCompteMailModifierStatutAllocation(Tracabilite tracabilite_p, String idRessource_p, String idSt_p, String statut_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_ressourceCompteMailUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD3003_PATH_PARAM));
      }
      // Query parameters
      HashMap<String, String> queryParams = new HashMap<>();
      if (StringTools.isNotNullOrEmpty(idRessource_p) && StringTools.isNotNullOrEmpty(idSt_p) && StringTools.isNotNullOrEmpty(statut_p))
      {
        queryParams.put(PARAM_ID_RESSOURCE, idRessource_p);
        queryParams.put(PARAM_ID_ST, idSt_p);
        queryParams.put(PARAM_STATUT, statut_p);
      }
      // Call SAAB
      final Response response;
      try
      {
        RESTRequest restRequest = new RESTRequestBuilder()//
            .httpMethod(HttpMethod.PUT)//
            .traceability(tracabilite_p)//
            .method(METHOD_NAME_RESSOURCE_COMPTE_MAIL_MODIFIER_STATUT)//
            .headers(SPIRIT_STARK_REQUEST_HEADER)//
            .path(_ressourceCompteMailUrl)//
            .queryParameter(queryParams)//
            .build();
        response = sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }
      // Get the content to a JSON string
      String jsonResponse = getContent(response, METHOD_NAME_RESSOURCE_COMPTE_MAIL_MODIFIER_STATUT, tracabilite_p);

      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }
      BasicResponse basicResponse = GsonTools.getIso8601Ms().fromJson(jsonResponse, BasicResponse.class);
      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(basicResponse.getRetour());
      return new ConnectorResponse<>(retour, null);
    }
    catch (Exception e_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, List<RessourceFtth>> ressourceFtthLireTousParReferencePM(Tracabilite tracabilite_p, String referencePm_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_ressourceFtthUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD3011_PATH_PARAM));
      }

      // Call SAAB
      final Response response;
      HashMap<String, String> queryParams = new HashMap<>();
      queryParams.put(PARAM_REFERENCE_PM, referencePm_p);

      try
      {
        RESTRequest restRequest = new RESTRequestBuilder()//
            .httpMethod(HttpMethod.GET)//
            .traceability(tracabilite_p)//
            .method(METHOD_NAME_RESSOURCE_FTTH_LIRE_TOUS_REFERENCE_PM)//
            .headers(SPIRIT_STARK_REQUEST_HEADER)//
            .path(_ressourceFtthUrl)//
            .queryParameter(queryParams)//
            .build();
        response = sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content to a JSON string
      String jsonResponse = getContent(response, METHOD_NAME_RESSOURCE_FTTH_LIRE_TOUS_REFERENCE_PM, tracabilite_p);

      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }

      GetRessourceFtthResponse getRessourceFtthResponse = RavelJsonTools.getInstance().fromJson(jsonResponse, GetRessourceFtthResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(getRessourceFtthResponse.getRetour());
      List<RessourceFtth> listeRessourceFtth = getRessourceFtthResponse.getListeRessourceFtth();

      return new ConnectorResponse<>(retour, listeRessourceFtth);
    }
    catch (Exception e_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, Nothing> ressourceImpiFixeCreer(Tracabilite tracabilite_p, Ressource ressource_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_ressourceImpiFixeUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD3003_PATH_PARAM));
      }

      // Call SAAB
      final Response response;
      try
      {
        RESTRequest restRequest = new RESTRequestBuilder()//
            .httpMethod(HttpMethod.POST)//
            .traceability(tracabilite_p)//
            .serializer(_jsonBuilder)//
            .method(METHOD_NAME_RESSOURCE_COMPTE_IMPI_FIXE_CREER)//
            .headers(SPIRIT_STARK_REQUEST_HEADER)//
            .path(_ressourceImpiFixeUrl)//
            .request(ressource_p)//
            .build();
        response = sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content to a JSON string
      String jsonResponse = getContent(response, METHOD_NAME_RESSOURCE_COMPTE_IMPI_FIXE_CREER, tracabilite_p);

      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }

      BasicResponse basicResponse = GsonTools.getIso8601Ms().fromJson(jsonResponse, BasicResponse.class);
      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(basicResponse.getRetour());
      return new ConnectorResponse<>(retour, null);
    }
    catch (Exception e_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, Nothing> ressourceImpiFixeModifierStatutAllocation(Tracabilite tracabilite_p, String idRessource_p, String idSt_p, String statut_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_ressourceImpiFixeUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD3003_PATH_PARAM));
      }
      // Query parameters
      HashMap<String, String> queryParams = new HashMap<>();
      if (StringTools.isNotNullOrEmpty(idRessource_p) && StringTools.isNotNullOrEmpty(idSt_p) && StringTools.isNotNullOrEmpty(statut_p))
      {
        queryParams.put(PARAM_ID_RESSOURCE, idRessource_p);
        queryParams.put(PARAM_ID_ST, idSt_p);
        queryParams.put(PARAM_STATUT, statut_p);
      }
      // Call SAAB
      final Response response;
      try
      {
        RESTRequest restRequest = new RESTRequestBuilder()//
            .httpMethod(HttpMethod.PUT)//
            .traceability(tracabilite_p)//
            .method(METHOD_NAME_RESSOURCE_COMPTE_IMPI_FIXE_MODIFIER_STATUT)//
            .headers(SPIRIT_STARK_REQUEST_HEADER)//
            .path(_ressourceImpiFixeUrl)//
            .queryParameter(queryParams)//
            .build();
        response = sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }
      // Get the content to a JSON string
      String jsonResponse = getContent(response, METHOD_NAME_RESSOURCE_COMPTE_IMPI_FIXE_MODIFIER_STATUT, tracabilite_p);

      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }
      BasicResponse basicResponse = GsonTools.getIso8601Ms().fromJson(jsonResponse, BasicResponse.class);
      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(basicResponse.getRetour());
      return new ConnectorResponse<>(retour, null);
    }
    catch (Exception e_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, List<Ressource>> ressourceLireTousParIdRessourceLie(Tracabilite tracabilite_p, String idRessourceLie_p, String typeRessource_p) throws RavelException
  {
    return _ressourceService.ressourceLireTousParIdRessourceLie(tracabilite_p, _ressourceUrl, idRessourceLie_p, typeRessource_p);
  }

  @Override
  public ConnectorResponse<Retour, Ressource> ressourceLireUn(Tracabilite tracabilite_p, String idRessource_p, String typeRessource_p) throws RavelException
  {
    return _ressourceService.ressourceLireUn(tracabilite_p, _ressourceUrl, idRessource_p, typeRessource_p);
  }

  @Override
  public ConnectorResponse<Retour, Nothing> ressourceModifierIdRessourceLie(Tracabilite tracabilite_p, String typeRessource_p, String idRessource_p, String idRessourceLie_p, String idRessourceLieCible_p) throws RavelException
  {
    return _ressourceService.ressourceModifierIdRessourceLie(tracabilite_p, _ressourceUrl, typeRessource_p, idRessource_p, idRessourceLie_p, idRessourceLieCible_p);
  }

  @Override
  public ConnectorResponse<Retour, Nothing> ressourceMotDePasseImsCreer(Tracabilite tracabilite_p, Ressource ressource_p)
  {
    try
    {
      if (StringTools.isNullOrEmpty(_ressourceMotDePasseImsUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD3003_PATH_PARAM));
      }

      // Call SAAB
      final Response response;
      try
      {
        RESTRequest restRequest = new RESTRequestBuilder()//
            .httpMethod(HttpMethod.POST)//
            .traceability(tracabilite_p)//
            .serializer(_jsonBuilder)//
            .method(METHOD_NAME_RESSOURCE_MOTDEPASSE_IMS_CREER)//
            .headers(SPIRIT_STARK_REQUEST_HEADER)//
            .path(_ressourceMotDePasseImsUrl)//
            .request(ressource_p)//
            .build();
        response = sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content to a JSON string
      String jsonResponse = getContent(response, METHOD_NAME_RESSOURCE_MOTDEPASSE_IMS_CREER, tracabilite_p);

      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }

      BasicResponse basicResponse = GsonTools.getIso8601Ms().fromJson(jsonResponse, BasicResponse.class);
      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(basicResponse.getRetour());
      return new ConnectorResponse<>(retour, null);
    }
    catch (Exception e_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }

  }

  @Override
  public ConnectorResponse<Retour, Nothing> ressourceMotDePasseImsModifierStatutAllocation(Tracabilite tracabilite_p, String idRessource_p, String idSt_p, String statut_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_ressourceMotDePasseImsUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD3003_PATH_PARAM));
      }
      // Query parameters
      HashMap<String, String> queryParams = new HashMap<>();
      if (StringTools.isNotNullOrEmpty(idRessource_p) && StringTools.isNotNullOrEmpty(idSt_p) && StringTools.isNotNullOrEmpty(statut_p))
      {
        queryParams.put(PARAM_ID_RESSOURCE, idRessource_p);
        queryParams.put(PARAM_ID_ST, idSt_p);
        queryParams.put(PARAM_STATUT, statut_p);
      }
      // Call SAAB
      final Response response;
      try
      {
        RESTRequest restRequest = new RESTRequestBuilder()//
            .httpMethod(HttpMethod.PUT)//
            .traceability(tracabilite_p)//
            .method(METHOD_NAME_RESSOURCE_MOTDEPASSE_IMS_MODIFIER_STATUT)//
            .headers(SPIRIT_STARK_REQUEST_HEADER)//
            .path(_ressourceMotDePasseImsUrl)//
            .queryParameter(queryParams)//
            .build();
        response = sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }
      // Get the content to a JSON string
      String jsonResponse = getContent(response, METHOD_NAME_RESSOURCE_MOTDEPASSE_IMS_MODIFIER_STATUT, tracabilite_p);

      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }
      BasicResponse basicResponse = GsonTools.getIso8601Ms().fromJson(jsonResponse, BasicResponse.class);
      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(basicResponse.getRetour());
      return new ConnectorResponse<>(retour, null);
    }
    catch (Exception e_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, Nothing> ressourceOntIdGererLiberation(Tracabilite tracabilite_p, String idRessource_p, String idRessourceLie_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_ressourceOntIdUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD3003_PATH_PARAM));
      }
      // Query parameters
      HashMap<String, String> queryParams = new HashMap<>();
      if (StringTools.isNotNullOrEmpty(idRessource_p) && StringTools.isNotNullOrEmpty(idRessourceLie_p))
      {
        queryParams.put(PARAM_ID_RESSOURCE, idRessource_p);
        queryParams.put(PARAM_ID_RESSOURCE_LIE, idRessourceLie_p);
      }
      // Call SAAB
      final Response response;
      try
      {
        RESTRequest restRequest = new RESTRequestBuilder()//
            .httpMethod(HttpMethod.PUT)//
            .traceability(tracabilite_p)//
            .method(METHOD_NAME_RESSOURCE_ONT_ID_GERER_LIBERATION)//
            .headers(SPIRIT_STARK_REQUEST_HEADER)//
            .path(_ressourceOntIdUrl)//
            .queryParameter(queryParams)//
            .build();
        response = sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }
      // Get the content to a JSON string
      String jsonResponse = getContent(response, METHOD_NAME_RESSOURCE_ONT_ID_GERER_LIBERATION, tracabilite_p);

      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }
      BasicResponse basicResponse = GsonTools.getIso8601Ms().fromJson(jsonResponse, BasicResponse.class);
      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(basicResponse.getRetour());
      return new ConnectorResponse<>(retour, null);
    }
    catch (Exception e_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  /**
   * pad3124RessourcePortP2PCompterPortLibre.
   */
  @Override
  public ConnectorResponse<Retour, Integer> ressourcePortP2PcompterPortLibreP2P(Tracabilite tracabilite_p, String nomNR_p) throws RavelException
  {
    return _ressourcePortP2PService.ressourcePortP2PcompterPortLibreP2P(tracabilite_p, nomNR_p, _ressourcePortP2PUrl);
  }

  @Override
  public ConnectorResponse<Retour, Nothing> ressourcePortP2PGererAllocation(Tracabilite tracabilite_p, String nomNR_p, String distance_p, String idRessourceLie_p, String action_p) throws RavelException
  {
    return _ressourcePortP2PService.ressourcePortP2PGererAllocation(tracabilite_p, nomNR_p, distance_p, idRessourceLie_p, action_p, _ressourcePortP2PUrl);
  }

  @Override
  public ConnectorResponse<Retour, Nothing> ressourcePortP2PModifierStatutAllocation(Tracabilite tracabilite_p, String idRessource_p, String idRessourceLie_p, String statut_p) throws RavelException
  {
    return _ressourcePortP2PService.ressourcePortP2PModifierStatutAllocation(tracabilite_p, idRessource_p, idRessourceLie_p, statut_p, _ressourcePortP2PUrl);
  }

  @Override
  public ConnectorResponse<Retour, RessourcePortPM> ressourcePortPmGererAllocation(Tracabilite tracabilite_p, String referencePmBytel_p, String referencePmOi_p, String referenceBoitierPm_p, String nomPmTechnique_p, String nomPanneauPm_p, Integer positionPortPm_p, String technologiePON_p, String idRessourceLie_p)
  {
    return _ressourcePortPmService.ressourcePortPmGererAllocation(tracabilite_p, _ressourcePortPmUrl, referencePmBytel_p, referencePmOi_p, referenceBoitierPm_p, nomPmTechnique_p, nomPanneauPm_p, positionPortPm_p, technologiePON_p, idRessourceLie_p);
  }

  @Override
  public ConnectorResponse<Retour, RessourcePortPM> ressourcePortPmGererMigrationPortPm(Tracabilite tracabilite_p, String idRessource_p, String motifMigration_p, String referencePmBytel_p, String referencePmOi_p, String referenceBoitierPm_p, String nomPmTechnique_p, String nomPanneauPm_p, Integer positionPortPm_p, String technologiePON_p, String idRessourceLie_p)
  {
    return _ressourcePortPmService.ressourcePortPmGererMigrationPortPm(tracabilite_p, _ressourcePortPmUrl, idRessource_p, motifMigration_p, referencePmBytel_p, referencePmOi_p, referenceBoitierPm_p, nomPmTechnique_p, nomPanneauPm_p, positionPortPm_p, technologiePON_p, idRessourceLie_p);
  }

  @Override
  public ConnectorResponse<Retour, String> ressourceRaccordementCompositeGererAnalyserModifRR(Tracabilite tracabilite_p, String idRRSource_p, String idRRCible_p, String action_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_manageRessourceRaccordementCompositeUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD3111_MANAGE_PATH_PARAM));
      }

      // Query parameters
      HashMap<String, String> queryParams = new HashMap<>();
      if (StringTools.isNotNullOrEmpty(idRRSource_p) && StringTools.isNotNullOrEmpty(idRRCible_p) && StringTools.isNotNullOrEmpty(action_p))
      {
        queryParams.put(PARAM_ID_SOURCE, idRRSource_p);
        queryParams.put(PARAM_ID_RR_CIBLE, idRRCible_p);
        queryParams.put(PARAM_ACTION, action_p);
      }

      // Call SAAB
      final Response response;
      try
      {
        RESTRequest restRequest = new RESTRequestBuilder()//
            .httpMethod(HttpMethod.GET)//
            .traceability(tracabilite_p)//
            .method(METHOD_NAME_RESSOURCE_LIRE_UN)//
            .headers(SPIRIT_STARK_REQUEST_HEADER)//
            .path(_manageRessourceRaccordementCompositeUrl)//
            .queryParameter(queryParams)//
            .build();
        response = sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }
      // Get the content to a JSON string
      String jsonResponse = getContent(response, METHOD_NAME_RESSOURCE_LIRE_UN, tracabilite_p);

      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }
      GetRessourceRaccordementResponse getRessourceRaccordementResponse = GsonTools.getIso8601Ms().fromJson(jsonResponse, GetRessourceRaccordementResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(getRessourceRaccordementResponse.getRetour());
      String ressource = getRessourceRaccordementResponse.getTypeModif();

      return new ConnectorResponse<>(retour, ressource);
    }
    catch (Exception e_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, RessourceRaccordementComposite> ressourceRaccordementCompositeLireUn(Tracabilite tracabilite_p, String idRessource_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_ressourceRaccordementCompositeUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD3003_PATH_PARAM));
      }

      // Query parameters
      HashMap<String, String> queryParams = new HashMap<>();
      if (StringTools.isNotNullOrEmpty(idRessource_p))
      {
        queryParams.put(PARAM_ID_RESSOURCE, idRessource_p);
      }
      // Call SAAB
      final Response response;
      try
      {
        RESTRequest restRequest = new RESTRequestBuilder()//
            .httpMethod(HttpMethod.GET)//
            .traceability(tracabilite_p)//
            .method(METHOD_NAME_RESSOURCE_RACCORDEMENT_COMPOSITE_LIRE_UN)//
            .headers(SPIRIT_STARK_REQUEST_HEADER)//
            .path(_ressourceRaccordementCompositeUrl)//
            .queryParameter(queryParams)//
            .build();
        response = sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }
      // Get the content to a JSON string
      String jsonResponse = getContent(response, METHOD_NAME_RESSOURCE_RACCORDEMENT_COMPOSITE_LIRE_UN, tracabilite_p);

      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }

      GetRessourceRaccordementCompositeResponse getRessourceRaccordementCompositeResponse = RavelJsonTools.getInstance().fromJson(jsonResponse, GetRessourceRaccordementCompositeResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(getRessourceRaccordementCompositeResponse.getRetour());
      RessourceRaccordementComposite ressourceRaccordementComposite = getRessourceRaccordementCompositeResponse.getRessourceRaccordementComposite();

      return new ConnectorResponse<>(retour, ressourceRaccordementComposite);
    }
    catch (Exception e_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, Nothing> ressourceRaccordementCreer(Tracabilite tracabilite_p, Ressource ressource_p) throws RavelException
  {
    return _ressourceRaccordementService.ressourceRaccordementCreer(tracabilite_p, _ressourceRaccordementUrl, ressource_p);
  }

  @Override
  public ConnectorResponse<Retour, Nothing> ressourceRaccordementModifierCodeAccesTechnique(Tracabilite tracabilite_p, String idRessource_p, String codeAccesTechnique_p) throws RavelException
  {
    return _ressourceRaccordementService.ressourceRaccordementModifierCodeAccesTechnique(tracabilite_p, _ressourceRaccordementUrl, idRessource_p, codeAccesTechnique_p);
  }

  @Override
  public ConnectorResponse<Retour, Nothing> ressourceRaccordementModifierOntInstalle(Tracabilite tracabilite_p, String idRessource_p, LocalDateTime dateDerniereDeclarationOntInstalle_p, String typeTechnologiePon_p, String noSerieOntInstalle_p) throws RavelException
  {
    return _ressourceRaccordementService.ressourceRaccordementModifierOntInstalle(tracabilite_p, _ressourceRaccordementUrl, idRessource_p, dateDerniereDeclarationOntInstalle_p, typeTechnologiePon_p, noSerieOntInstalle_p);

  }

  @Override
  public ConnectorResponse<Retour, Nothing> ressourceRaccordementModifierStatutAllocation(Tracabilite tracabilite_p, String idRessource_p, String idSt_p, String statut_p) throws RavelException
  {
    return _ressourceRaccordementService.ressourceRaccordementModifierStatutAllocation(tracabilite_p, _ressourceRaccordementUrl, idRessource_p, idSt_p, statut_p);
  }

  @Override
  public ConnectorResponse<Retour, Nothing> structureVerticaleFtthCompositeCreer(Tracabilite tracabilite_p, StructureVerticaleFtthComposite structureVerticaleFtthComposite_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_structureVerticaleFtthCompositeUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD3012_PATH_PARAM));
      }
      // Call SAAB
      final Response response;
      try
      {
        RESTRequest restRequest = new RESTRequestBuilder()//
            .httpMethod(HttpMethod.POST)//
            .traceability(tracabilite_p)//
            .serializer(_jsonBuilder)//
            .method(METHOD_NAME_STRUCTURE_VERTICALE_FTTH_COMPOSITE_CREER)//
            .headers(SPIRIT_STARK_REQUEST_HEADER)//
            .path(_structureVerticaleFtthCompositeUrl)//
            .request(structureVerticaleFtthComposite_p)//
            .build();
        response = sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }
      // Get the content to a JSON string
      String jsonResponse = getContent(response, METHOD_NAME_STRUCTURE_VERTICALE_FTTH_COMPOSITE_CREER, tracabilite_p);
      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }
      BasicResponse basicResponse = GsonTools.getIso8601Ms().fromJson(jsonResponse, BasicResponse.class);
      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(basicResponse.getRetour());
      return new ConnectorResponse<>(retour, null);
    }
    catch (Exception e_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, StructureVerticaleFtthComposite> structureVerticaleFtthCompositeLireTousParListeOIIMB(Tracabilite tracabilite_p, ListeCoupleImbOiRequest listeCoupleImbOi_p) throws RavelException
  {
    try
    {
      if (StringTools.isNullOrEmpty(_structureVerticaleFtthCompositeUrl))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, PAD3012_PATH_PARAM));
      }
      // Call SAAB
      final Response response;
      try
      {
        RESTRequest restRequest = new RESTRequestBuilder()//
            .httpMethod(HttpMethod.POST)//
            .traceability(tracabilite_p)//
            .serializer(_jsonBuilder)//
            .method(METHOD_NAME_STRUCTURE_VERTICALE_FTTH_COMPOSITE_LIRE_TOUS_LISTE_OI_IMB)//
            .headers(SPIRIT_STARK_REQUEST_HEADER)//
            .path(_structureVerticaleFtthCompositeRechercheUrl)//
            .request(listeCoupleImbOi_p).build();
        response = sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }
      // Get the content to a JSON string
      String jsonResponse = getContent(response, METHOD_NAME_STRUCTURE_VERTICALE_FTTH_COMPOSITE_LIRE_TOUS_LISTE_OI_IMB, tracabilite_p);
      if (StringTools.isNullOrEmpty(jsonResponse))
      {
        throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.CNCTOR_00010, MESSAGE_JSON_ERROR_MESSAGE);
      }
      GetStructureVerticaleFtthCompositeResponse getStructureVerticaleFtthCompositeResponse = RavelJsonTools.getInstance().fromJson(jsonResponse, GetStructureVerticaleFtthCompositeResponse.class);
      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(getStructureVerticaleFtthCompositeResponse.getRetour());
      StructureVerticaleFtthComposite structureVerticaleFtthComposite = getStructureVerticaleFtthCompositeResponse.getStructureVerticaleFtthComposite();
      return new ConnectorResponse<>(retour, structureVerticaleFtthComposite);
    }
    catch (Exception e_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  @Override
  public ConnectorResponse<Retour, List<TopologieArcturus>> topologieArcturusLireTousParIdEqptAcces(Tracabilite tracabilite_p, String idEqptAcces_p) throws RavelException
  {
    return _topologieArcturusService.topologieArcturusLireTousParIdEqptAcces(tracabilite_p, _topologieArcturusUrl, idEqptAcces_p);
  }

  @Override
  public ConnectorResponse<Retour, TopologieArcturus> topologieArcturusLireUn(Tracabilite tracabilite_p, String idNomCollecte_p) throws RavelException
  {
    return _topologieArcturusService.topologieArcturusLireUn(tracabilite_p, _topologieArcturusUrl, idNomCollecte_p);
  }
}
