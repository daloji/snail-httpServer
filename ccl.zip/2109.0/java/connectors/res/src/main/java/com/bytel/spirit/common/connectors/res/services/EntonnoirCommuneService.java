/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.res.services;

import java.text.MessageFormat;
import java.util.HashMap;
import java.util.List;

import javax.ws.rs.HttpMethod;
import javax.ws.rs.core.Response;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.connector.RESTRequest;
import com.bytel.spirit.common.connectors.res.IRESConnector;
import com.bytel.spirit.common.connectors.res.RESConnector;
import com.bytel.spirit.common.shared.misc.connectors.AbstractInternalRESTConnector;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.RetourConverter;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.EntonnoirCommune;
import com.bytel.spirit.common.shared.saab.res.response.GetListeEntonnoirCommuneResponse;

/**
 * @author rafcosta
 * @version ($Revision$ $Date$)
 */
public class EntonnoirCommuneService
{

  /** The constant for entonnoirCommuneLireTousParCodeInsee service name */
  public static final String METHOD_NAME_ENTONNOIR_COMMUNE_LIRE_TOUS_PAR_CODE_INSEE = "entonnoirCommuneLireTousParCodeInsee"; //$NON-NLS-1$
  /** The constant for entonnoirCommuneLireTousParCodePostal service name */
  public static final String METHOD_NAME_ENTONNOIR_COMMUNE_LIRE_TOUS_PAR_CODE_POSTAL = "entonnoirCommuneLireTousParCodePostal"; //$NON-NLS-1$
  /** The constant for entonnoirCommuneLireTousParDepartement service name */
  public static final String METHOD_NAME_ENTONNOIR_COMMUNE_LIRE_TOUS_PAR_DEPARTEMENT = "entonnoirCommuneLireTousParDepartement"; //$NON-NLS-1$

  private final RESConnector _resInstance;

  /**
   * @param resInstance_p
   *          {@link RESConnector}
   */
  public EntonnoirCommuneService(RESConnector resInstance_p)
  {
    _resInstance = resInstance_p;
  }

  /**
   * entonnoirCommuneLireTousParCodeInsee
   *
   * @param tracabilite_p
   *          tracabilite
   * @param entonnoirCommuneUrl_p
   *          entonnoirCommuneURL
   * @param codeInsee_p
   *          codeInsee
   * @return ConnectorResponse<Retour, List<EntonnoirCommune>>
   */
  public ConnectorResponse<Retour, List<EntonnoirCommune>> entonnoirCommuneLireTousParCodeInsee(Tracabilite tracabilite_p, String entonnoirCommuneUrl_p, String codeInsee_p)
  {
    try
    {
      if (StringTools.isNullOrEmpty(entonnoirCommuneUrl_p))
      {
        throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(IRESConnector.MESSAGE_MISSING_CONFIGURATION_PARAMETER, IRESConnector.PAD3021_PATH_PARAM));
      }

      // Query parameters
      HashMap<String, String> queryParams = new HashMap<>();
      if (StringTools.isNotNullOrEmpty(codeInsee_p))
      {
        queryParams.put(IRESConnector.PARAM_CODE_INSEE, codeInsee_p);
      }

      // Call SAAB
      final Response response;
      try
      {
        RESTRequest restRequest = new RESTRequest.RESTRequestBuilder()//
            .httpMethod(HttpMethod.GET)//
            .traceability(tracabilite_p)//
            .method(METHOD_NAME_ENTONNOIR_COMMUNE_LIRE_TOUS_PAR_CODE_INSEE)//
            .headers(AbstractInternalRESTConnector.getSpiritStarkRequestHeader())//
            .path(entonnoirCommuneUrl_p)//
            .queryParameter(queryParams)//
            .build();
        response = _resInstance.sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content
      GetListeEntonnoirCommuneResponse getListeEntonnoirCommuneResponse = _resInstance.getContentFromResponse(tracabilite_p, response, METHOD_NAME_ENTONNOIR_COMMUNE_LIRE_TOUS_PAR_CODE_INSEE, GetListeEntonnoirCommuneResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(getListeEntonnoirCommuneResponse.getRetour());
      List<EntonnoirCommune> entonnoirCommuneList = getListeEntonnoirCommuneResponse.getListeEntonnoirCommune();

      return new ConnectorResponse<>(retour, entonnoirCommuneList);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  /**
   * entonnoirCommuneLireTousParCodePostal
   *
   * @param tracabilite_p
   *          tracabilite
   * @param entonnoirCommuneUrl_p
   *          entonnoirCommuneUrl
   * @param codePostal_p
   *          codePostal
   * @return ConnectorResponse<Retour, List<EntonnoirCommune>>
   */
  public ConnectorResponse<Retour, List<EntonnoirCommune>> entonnoirCommuneLireTousParCodePostal(Tracabilite tracabilite_p, String entonnoirCommuneUrl_p, String codePostal_p)
  {
    try
    {
      if (StringTools.isNullOrEmpty(entonnoirCommuneUrl_p))
      {
        throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(IRESConnector.MESSAGE_MISSING_CONFIGURATION_PARAMETER, IRESConnector.PAD3021_PATH_PARAM));
      }

      // Query parameters
      HashMap<String, String> queryParams = new HashMap<>();
      if (StringTools.isNotNullOrEmpty(codePostal_p))
      {
        queryParams.put(IRESConnector.PARAM_CODE_POSTAL, codePostal_p);
      }

      // Call SAAB
      final Response response;
      try
      {
        RESTRequest restRequest = new RESTRequest.RESTRequestBuilder()//
            .httpMethod(HttpMethod.GET)//
            .traceability(tracabilite_p)//
            .method(METHOD_NAME_ENTONNOIR_COMMUNE_LIRE_TOUS_PAR_CODE_POSTAL)//
            .headers(AbstractInternalRESTConnector.getSpiritStarkRequestHeader())//
            .path(entonnoirCommuneUrl_p)//
            .queryParameter(queryParams)//
            .build();
        response = _resInstance.sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content
      GetListeEntonnoirCommuneResponse getListeEntonnoirCommuneResponse = _resInstance.getContentFromResponse(tracabilite_p, response, METHOD_NAME_ENTONNOIR_COMMUNE_LIRE_TOUS_PAR_CODE_POSTAL, GetListeEntonnoirCommuneResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(getListeEntonnoirCommuneResponse.getRetour());
      List<EntonnoirCommune> entonnoirCommuneList = getListeEntonnoirCommuneResponse.getListeEntonnoirCommune();

      return new ConnectorResponse<>(retour, entonnoirCommuneList);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  /**
   * entonnoirCommuneLireTousParDepartement
   *
   * @param tracabilite_p
   *          tracabilite
   * @param entonnoirCommuneUrl_p
   *          entonnoirCommuneUrl
   * @param departement_p
   *          departement
   * @return ConnectorResponse<Retour, List<EntonnoirCommune>>
   */
  public ConnectorResponse<Retour, List<EntonnoirCommune>> entonnoirCommuneLireTousParDepartement(Tracabilite tracabilite_p, String entonnoirCommuneUrl_p, String departement_p)
  {
    try
    {
      if (StringTools.isNullOrEmpty(entonnoirCommuneUrl_p))
      {
        throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(IRESConnector.MESSAGE_MISSING_CONFIGURATION_PARAMETER, IRESConnector.PAD3021_PATH_PARAM));
      }

      // Query parameters
      HashMap<String, String> queryParams = new HashMap<>();
      if (StringTools.isNotNullOrEmpty(departement_p))
      {
        queryParams.put(IRESConnector.PARAM_DEPARTEMENT, departement_p);
      }

      // Call SAAB
      final Response response;
      try
      {
        RESTRequest restRequest = new RESTRequest.RESTRequestBuilder()//
            .httpMethod(HttpMethod.GET)//
            .traceability(tracabilite_p)//
            .method(METHOD_NAME_ENTONNOIR_COMMUNE_LIRE_TOUS_PAR_DEPARTEMENT)//
            .headers(AbstractInternalRESTConnector.getSpiritStarkRequestHeader())//
            .path(entonnoirCommuneUrl_p)//
            .queryParameter(queryParams)//
            .build();
        response = _resInstance.sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content
      GetListeEntonnoirCommuneResponse getListeEntonnoirCommuneResponse = _resInstance.getContentFromResponse(tracabilite_p, response, METHOD_NAME_ENTONNOIR_COMMUNE_LIRE_TOUS_PAR_DEPARTEMENT, GetListeEntonnoirCommuneResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(getListeEntonnoirCommuneResponse.getRetour());
      List<EntonnoirCommune> entonnoirCommuneList = getListeEntonnoirCommuneResponse.getListeEntonnoirCommune();

      return new ConnectorResponse<>(retour, entonnoirCommuneList);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }
}
