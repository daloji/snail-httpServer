/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.res.services;

import java.time.LocalDateTime;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.probes.AvgDoubleCollectorItem;
import com.bytel.ravel.common.probes.AvgFlowPerSecondCollector;
import com.bytel.ravel.common.probes.RavelProbeConfigurationManager;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.services.connector.ConnectorManager;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.connectors.res.IRESConnector;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.Ressource;

/**
 * @author jpais
 * @version ($Revision$ $Date$)
 */
public class RessourceRaccordementProxy
{
  /** connector Id */
  private String _connectorId;

  /** For probe to count the amount of call to the ressourceRaccordementCreer operation */
  AvgFlowPerSecondCollector _avg_ressourceRaccordementCreer_call_counter;
  /** For probe to count the execution time of call to the ressourceRaccordementCreer operation */
  AvgDoubleCollectorItem _avg_ressourceRaccordementCreer_ExecTime;

  /** For probe to count the amount of call to the ressourceRaccordementModifierStatutAllocation operation */
  AvgFlowPerSecondCollector _avg_ressourceRaccordementModifierStatutAllocation_call_counter;
  /** For probe to count the execution time of call to the ressourceRaccordementModifierStatutAllocation operation */
  AvgDoubleCollectorItem _avg_ressourceRaccordementModifierStatutAllocation_ExecTime;

  /** For probe to count the amount of call to the ressourceRaccordementModifierCodeAccesTechnique operation */
  AvgFlowPerSecondCollector _avg_ressourceRaccordementModifierCodeAccesTechnique_call_counter;
  /** For probe to count the execution time of call to the ressourceRaccordementModifierCodeAccesTechnique operation */
  AvgDoubleCollectorItem _avg_ressourceRaccordementModifierCodeAccesTechnique_ExecTime;

  /** For probe to count the amount of call to the ressourceModifierOntInstalle operation */
  AvgFlowPerSecondCollector _avg_ressourceModifierOntInstalle_call_counter;
  /** For probe to count the execution time of call to the ressourceModifierOntInstalle operation */
  AvgDoubleCollectorItem _avg_ressourceModifierOntInstalle_ExecTime;

  /**
   *
   * @param connectorId_p
   */
  public RessourceRaccordementProxy(String connectorId_p)
  {
    _connectorId = connectorId_p;

    _avg_ressourceRaccordementCreer_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_ressourceRaccordementCreer_call_counter", "RESProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_ressourceRaccordementCreer_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_ressourceRaccordementCreer_ExecTime", "RESProxy"); //$NON-NLS-1$ //$NON-NLS-2$

    _avg_ressourceRaccordementModifierStatutAllocation_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_ressourceRaccordementModifierStatutAllocation_call_counter", "RESProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_ressourceRaccordementModifierStatutAllocation_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_ressourceRaccordementModifierStatutAllocation_ExecTime", "RESProxy"); //$NON-NLS-1$ //$NON-NLS-2$

    _avg_ressourceRaccordementModifierCodeAccesTechnique_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_ressourceRaccordementModifierCodeAccesTechnique_call_counter", "RESProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_ressourceRaccordementModifierCodeAccesTechnique_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_ressourceRaccordementModifierCodeAccesTechnique_ExecTime", "RESProxy"); //$NON-NLS-1$ //$NON-NLS-2$

    _avg_ressourceModifierOntInstalle_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_ressourceModifierOntInstalle_call_counter", "RESProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_ressourceModifierOntInstalle_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_ressourceModifierOntInstalle_ExecTime", "RESProxy"); //$NON-NLS-1$ //$NON-NLS-2$

  }

  public ConnectorResponse<Retour, Nothing> ressourceRaccordementCreer(Tracabilite tracabilite_p, Ressource ressource_p) throws RavelException
  {
    IRESConnector resConnector = null;
    try
    {
      resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
    }
    catch (Exception e_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
    }
    _avg_ressourceRaccordementCreer_call_counter.measure();
    long startTime = System.currentTimeMillis();
    try
    {
      return resConnector.ressourceRaccordementCreer(tracabilite_p, ressource_p);
    }
    finally
    {
      long endTime = System.currentTimeMillis();
      _avg_ressourceRaccordementCreer_ExecTime.updateAvgValue(endTime - startTime);
    }
  }

  public ConnectorResponse<Retour, Nothing> ressourceRaccordementModifierCodeAccesTechnique(Tracabilite tracabilite_p, String idRessource_p, String codeAccesTechnique_p) throws RavelException
  {
    IRESConnector resConnector = null;
    try
    {
      resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
    }
    catch (Exception e_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
    }
    _avg_ressourceRaccordementModifierCodeAccesTechnique_call_counter.measure();
    long startTime = System.currentTimeMillis();
    try
    {
      return resConnector.ressourceRaccordementModifierCodeAccesTechnique(tracabilite_p, idRessource_p, codeAccesTechnique_p);
    }
    finally
    {
      long endTime = System.currentTimeMillis();
      _avg_ressourceRaccordementModifierCodeAccesTechnique_ExecTime.updateAvgValue(endTime - startTime);
    }
  }

  public ConnectorResponse<Retour, Nothing> ressourceRaccordementModifierOntInstalle(Tracabilite tracabilite_p, String idRessource_p, LocalDateTime dateDerniereDeclarationOntInstalle_p, String typeTechnologiePon_p, String noSerieOntInstalle_p) throws RavelException
  {
    IRESConnector resConnector = null;
    try
    {
      resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
    }
    catch (Exception e_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
    }
    _avg_ressourceModifierOntInstalle_call_counter.measure();
    long startTime = System.currentTimeMillis();
    try
    {
      return resConnector.ressourceRaccordementModifierOntInstalle(tracabilite_p, idRessource_p, dateDerniereDeclarationOntInstalle_p, typeTechnologiePon_p, noSerieOntInstalle_p);
    }
    finally
    {
      long endTime = System.currentTimeMillis();
      _avg_ressourceModifierOntInstalle_ExecTime.updateAvgValue(endTime - startTime);
    }
  }

  public ConnectorResponse<Retour, Nothing> ressourceRaccordementModifierStatutAllocation(Tracabilite tracabilite_p, String idRessource_p, String idSt_p, String statut_p) throws RavelException
  {
    IRESConnector resConnector = null;
    try
    {
      resConnector = (IRESConnector) ConnectorManager.getInstance().getConnector(_connectorId);
    }
    catch (Exception e_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
    }
    _avg_ressourceRaccordementModifierStatutAllocation_call_counter.measure();
    long startTime = System.currentTimeMillis();
    try
    {
      return resConnector.ressourceRaccordementModifierStatutAllocation(tracabilite_p, idRessource_p, idSt_p, statut_p);
    }
    finally
    {
      long endTime = System.currentTimeMillis();
      _avg_ressourceRaccordementModifierStatutAllocation_ExecTime.updateAvgValue(endTime - startTime);
    }
  }
}
