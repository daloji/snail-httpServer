/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.res.services;

import java.text.MessageFormat;
import java.util.HashMap;
import java.util.Set;

import javax.ws.rs.HttpMethod;
import javax.ws.rs.core.Response;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.json.IRavelJson;
import com.bytel.ravel.common.json.RavelJson;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.connector.RESTRequest;
import com.bytel.spirit.common.connectors.res.IRESConnector;
import com.bytel.spirit.common.connectors.res.RESConnector;
import com.bytel.spirit.common.shared.misc.connectors.AbstractInternalRESTConnector;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.BasicResponse;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.ressources.RetourConverter;
import com.bytel.spirit.common.shared.misc.ressources.SpiritConstants;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.CompteRenduSuppression;
import com.bytel.spirit.common.shared.saab.res.PorteDeCollecte;
import com.bytel.spirit.common.shared.saab.res.request.ManagePorteCollecteRequest;
import com.bytel.spirit.common.shared.saab.res.request.PorteDeCollecteGererSupressionRequest;
import com.bytel.spirit.common.shared.saab.res.response.GetPorteDeCollecteResponse;
import com.bytel.spirit.common.shared.saab.res.response.ListeCRSupressionResponse;

/**
 * @author rafcosta
 * @version ($Revision$ $Date$)
 */
public class PorteDeCollecteService
{
  interface IMethodNames
  {
    String GERER_IMPORT = "porteDeCollecteGererImport"; //$NON-NLS-1$
    String GERER_SUPPRESSION = "porteDeCollecteGererSuppressionPorteDeCollecteNonReference"; //$NON-NLS-1$
    String LIRE_UN = "porteDeCollecteLireUn"; //$NON-NLS-1$
  }

  /** Ravel Json serializer. */
  private final IRavelJson _jsonBuilder = new RavelJson.RavelJsonBuilder().profil(SpiritConstants.JSON_PROFILE_STARK).build();

  /** {@link RESConnector} */
  private final RESConnector _resInstance;

  /**
   * @param resInstance_p
   *          {@link RESConnector}
   */
  public PorteDeCollecteService(RESConnector resInstance_p)
  {
    _resInstance = resInstance_p;
  }

  /**
   * Import a {@link PorteDeCollecte}.
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param url_p
   *          the url.
   * @param porteDeCollecte_p
   *          the {@link PorteDeCollecte} being imported.
   * @return a pair with the retour and a Nothing (because it needs to be a pair).
   */
  public ConnectorResponse<Retour, Nothing> gererImport(Tracabilite tracabilite_p, String url_p, PorteDeCollecte porteDeCollecte_p)
  {
    try
    {
      if (StringTools.isNullOrEmpty(url_p))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(IRESConnector.MESSAGE_MISSING_CONFIGURATION_PARAMETER, IRESConnector.PORTE_DE_COLLECTE_PATH_PARAM));
      }

      // Call SAAB
      final Response response;
      HashMap<String, String> queryParams = new HashMap<>();
      queryParams.put(IRESConnector.PARAM_ACTION, IRESConnector.ACTION_GERER_IMPORT);

      try
      {
        RESTRequest restRequest = new RESTRequest.RESTRequestBuilder() //
            .httpMethod(HttpMethod.PUT) //
            .traceability(tracabilite_p) //
            .method(IMethodNames.GERER_IMPORT) //
            .headers(AbstractInternalRESTConnector.getSpiritStarkRequestHeader()) //
            .path(url_p) //
            .queryParameter(queryParams) //
            .request(new ManagePorteCollecteRequest(porteDeCollecte_p)) //
            .serializer(_jsonBuilder) //
            .build();

        response = _resInstance.sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      BasicResponse basicResponse = _resInstance.getContentFromResponse(tracabilite_p, response, IMethodNames.GERER_IMPORT, BasicResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(basicResponse.getRetour());
      return new ConnectorResponse<>(retour, null);
    }
    catch (Exception e_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  /**
   * Delete all {@link PorteDeCollecte} whose id is not in the list.
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param url_p
   *          the url.
   * @param setIdNomCollecte_p
   *          the set with the ids being used.
   * @return a pair with the retour and a set with the results of the deletion, for each {@link PorteDeCollecte}.
   */
  public ConnectorResponse<Retour, Set<CompteRenduSuppression>> gererSuppressionPorteDeCollecteNonReference(Tracabilite tracabilite_p, String url_p, Set<String> setIdNomCollecte_p)
  {
    try
    {
      if (StringTools.isNullOrEmpty(url_p))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(IRESConnector.MESSAGE_MISSING_CONFIGURATION_PARAMETER, IRESConnector.PORTE_DE_COLLECTE_PATH_PARAM));
      }

      // Call SAAB
      final Response response;
      HashMap<String, String> queryParams = new HashMap<>();
      queryParams.put(IRESConnector.PARAM_ACTION, "GererSuppressionPorteDeCollecteNonReference"); //$NON-NLS-1$

      try
      {
        RESTRequest restRequest = new RESTRequest.RESTRequestBuilder() //
            .httpMethod(HttpMethod.PUT) //
            .traceability(tracabilite_p) //
            .method(IMethodNames.GERER_SUPPRESSION) //
            .headers(AbstractInternalRESTConnector.getSpiritStarkRequestHeader()) //
            .path(url_p) //
            .queryParameter(queryParams) //
            .request(new PorteDeCollecteGererSupressionRequest(setIdNomCollecte_p)) //
            .serializer(_jsonBuilder) //
            .build();

        response = _resInstance.sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      ListeCRSupressionResponse responseBody = _resInstance.getContentFromResponse(tracabilite_p, response, IMethodNames.GERER_SUPPRESSION, ListeCRSupressionResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(responseBody.getRetour());
      return new ConnectorResponse<>(retour, responseBody.getListeCompteRenduSupression());
    }
    catch (Exception e_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  /**
   * @param tracabilite_p
   *          the tracabilite.
   * @param porteDeCollecteUrl_p
   *          porteDeCollecteUrl
   * @param idNomCollecte_p
   *          idNomCollecte
   * @return ConnectorResponse<Retour, PorteDeCollecte>
   */
  public ConnectorResponse<Retour, PorteDeCollecte> lireUn(Tracabilite tracabilite_p, String porteDeCollecteUrl_p, String idNomCollecte_p)
  {
    try
    {
      if (StringTools.isNullOrEmpty(porteDeCollecteUrl_p))
      {
        throw new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(IRESConnector.MESSAGE_MISSING_CONFIGURATION_PARAMETER, IRESConnector.PORTE_DE_COLLECTE_PATH_PARAM));
      }

      // Call SAAB
      final Response response;
      HashMap<String, String> queryParams = new HashMap<>();
      queryParams.put(IRESConnector.PARAM_ID_NOM_COLLECTE, idNomCollecte_p);

      try
      {
        RESTRequest restRequest = new RESTRequest.RESTRequestBuilder() //
            .httpMethod(HttpMethod.GET) //
            .traceability(tracabilite_p) //
            .method(IMethodNames.LIRE_UN) //
            .headers(AbstractInternalRESTConnector.getSpiritStarkRequestHeader()) //
            .path(porteDeCollecteUrl_p) //
            .queryParameter(queryParams) //
            .build();

        response = _resInstance.sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      GetPorteDeCollecteResponse basicResponse = _resInstance.getContentFromResponse(tracabilite_p, response, IMethodNames.LIRE_UN, GetPorteDeCollecteResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(basicResponse.getRetour());
      PorteDeCollecte porteDeCollecte = basicResponse.getPorteDeCollecte();
      return new ConnectorResponse<>(retour, porteDeCollecte);
    }
    catch (Exception e_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }
}
