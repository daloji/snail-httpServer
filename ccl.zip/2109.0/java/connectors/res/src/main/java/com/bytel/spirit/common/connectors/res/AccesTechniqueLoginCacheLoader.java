/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.res;

import java.text.MessageFormat;
import java.time.Duration;
import java.util.List;
import java.util.stream.Collectors;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.cache.BasicCache;
import com.bytel.ravel.common.cache.ICache;
import com.bytel.ravel.common.cache.ICacheLoader;
import com.bytel.ravel.common.datetime.DateTimeManager;
import com.bytel.ravel.common.exception.ExceptionTools;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.services.connector.ConnectorManager;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.AccesTechnique;

/**
 *
 * @author ppinto
 * @version ($Revision$ $Date$)
 */
public class AccesTechniqueLoginCacheLoader implements ICacheLoader
{
  /**
   * CacheId to store in and retrieve from cache manager
   */
  private static final String _cacheId = "acces_technique"; //$NON-NLS-1$

  /**
   * Tracabilite to call the RPG connector
   */
  private final Tracabilite _tracabilite;

  /**
   * Duration Of Cache In Hours.
   */
  private final Duration _durationOfCache;

  /**
   * login
   */
  private final String _login;

  /**
   * retour
   */
  private Retour _retour;

  /**
   * @param tracabilite_p
   *          the tracabilite
   * @param durationOfCache_p
   *          duration of cache in hours
   */
  public AccesTechniqueLoginCacheLoader(Tracabilite tracabilite_p, Duration durationOfCache_p, String login_p)
  {
    super();
    _tracabilite = tracabilite_p;
    _durationOfCache = durationOfCache_p;
    _login = login_p;
  }

  @Override
  public String getCacheId()
  {
    return _cacheId + "_" + _login;
  }

  /**
   * @return the retour
   */
  public Retour getRetour()
  {
    return _retour;
  }

  @Override
  public ICache<?> initializeCache()
  {
    return new BasicCache<>();
  }

  @Override
  public void loadCache(ICache<?> cache_p)
  {
    @SuppressWarnings("unchecked")
    BasicCache<List<AccesTechnique>> cache = (BasicCache<List<AccesTechnique>>) cache_p;
    RESConnector resConnector = null;
    Retour retour = null;

    try
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.INFO, _tracabilite, "AccesTechniqueLoginCacheLoader - Load Cache Start")); //$NON-NLS-1$

      resConnector = (RESConnector) ConnectorManager.getInstance().getConnector(IRESConnector.BEAN_ID);

      // Call RES.loadAccesTechniqueLireTous
      ConnectorResponse<Retour, List<AccesTechnique>> resAccesTechniqueResponse = resConnector.loadAccesTechniqueLireTous(_tracabilite);
      List<AccesTechnique> accesTechniqueList = resAccesTechniqueResponse._second;

      //Write the login with the corresponding list of AccesTechnique in the cache
      //(key = {cacheId + login} , value = List<AccesTechnique>)
      if ((accesTechniqueList != null) && !accesTechniqueList.isEmpty())
      {
        List<AccesTechnique> accesTechniquesAutorisesList = accesTechniqueList.parallelStream() //
            .filter(accesTechnique_p -> accesTechnique_p.getListeLoginAutorise().stream().anyMatch(_login::equals)) //
            .collect(Collectors.toList());

        if (!accesTechniquesAutorisesList.isEmpty())
        {
          cache.write(_login, accesTechniquesAutorisesList);
        }

      }
      else
      {
        retour = resAccesTechniqueResponse._first;

        String message = MessageFormat.format(Messages.getString("AccesTechniqueCacheLoader.ListeAccesTechniqueNull"), retour.getResultat(), retour.getCategorie(), retour.getDiagnostic(), retour.getLibelle()); //$NON-NLS-1$
        RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, _tracabilite, message));
      }

      RavelLogger.log(new SpiritLogEvent(LogSeverity.INFO, _tracabilite, "AccesTechniqueLoginCacheLoader - Load Cache End")); //$NON-NLS-1$
    }
    catch (RavelException exception)
    {
      String message = MessageFormat.format(Messages.getString("AccesTechniqueCacheLoader.TechnicalExceptionMessage"), "loadCache", exception.getErrorCode(), exception.getMessage()); //$NON-NLS-1$ //$NON-NLS-2$
      // add fileName and line number of the exception
      message += ExceptionTools.getExceptionLineAndFile(exception);
      retour = RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.LECTURE_INDISPONIBLE, message);
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, _tracabilite, message));
    }
    setRetour(retour);
  }

  /**
   * @param retour_p
   *          the retour to set
   */
  public void setRetour(Retour retour_p)
  {
    _retour = retour_p;
  }

  @Override
  public boolean validateCache(ICache<?> cache_p)
  {
    if (!cache_p.isEmpty() && (cache_p.getDateOfCache() != null))
    {
      Duration durationSinceDateOfCache = Duration.between(cache_p.getDateOfCache(), DateTimeManager.getInstance().now());

      return (durationSinceDateOfCache.compareTo(_durationOfCache) < 0);
    }
    return false;
  }
}
