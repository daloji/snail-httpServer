/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.res.services;

import java.text.MessageFormat;
import java.util.HashMap;
import java.util.List;

import javax.ws.rs.HttpMethod;
import javax.ws.rs.core.Response;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.connector.RESTRequest;
import com.bytel.spirit.common.connectors.res.IRESConnector;
import com.bytel.spirit.common.connectors.res.RESConnector;
import com.bytel.spirit.common.shared.misc.connectors.AbstractInternalRESTConnector;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.RetourConverter;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.EntonnoirNumero;
import com.bytel.spirit.common.shared.saab.res.response.GetListeEntonnoirNumeroResponse;

/**
 * @author rafcosta
 * @version ($Revision$ $Date$)
 */
public class EntonnoirNumeroService
{

  /** The constant for entonnoirNumeroLireTousParCodeInseeCodeRivoli service name */
  public static final String METHOD_NAME_ENTONNOIR_NUMERO_LIRE_TOUS_PAR_CODE_INSEE_CODE_RIVOLI = "entonnoirNumeroLireTousParCodeInseeCodeRivoli"; //$NON-NLS-1$
  /** The constant for entonnoirNumeroLireTousParCodeInseeSimiliHexacle0 service name */
  public static final String METHOD_NAME_ENTONNOIR_NUMERO_LIRE_TOUS_PAR_CODE_INSEE_SIMILI_HEXACLE_0 = "entonnoirNumeroLireTousParCodeInseeSimiliHexacle0"; //$NON-NLS-1$

  private final RESConnector _resInstance;

  /**
   * @param resInstance_p
   *          {@link RESConnector}
   */
  public EntonnoirNumeroService(RESConnector resInstance_p)
  {
    _resInstance = resInstance_p;
  }

  /**
   * entonnoirNumeroLireTousParCodeInseeCodeRivoli
   *
   * @param tracabilite_p
   *          tracabilite
   * @param entonnoirNumeroUrl_p
   *          entonnoirNumeroUrl
   * @param codeInsee_p
   *          codeInsee
   * @param codeRivoli_p
   *          codeRivoli
   * @return ConnectorResponse<Retour, List<EntonnoirNumero>>
   */
  public ConnectorResponse<Retour, List<EntonnoirNumero>> entonnoirNumeroLireTousParCodeInseeCodeRivoli(Tracabilite tracabilite_p, String entonnoirNumeroUrl_p, String codeInsee_p, String codeRivoli_p)
  {
    try
    {
      if (StringTools.isNullOrEmpty(entonnoirNumeroUrl_p))
      {
        throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(IRESConnector.MESSAGE_MISSING_CONFIGURATION_PARAMETER, IRESConnector.PAD3023_PATH_PARAM));
      }

      // Query parameters
      HashMap<String, String> queryParams = new HashMap<>();
      if (StringTools.isNotNullOrEmpty(codeInsee_p))
      {
        queryParams.put(IRESConnector.PARAM_CODE_INSEE, codeInsee_p);
      }
      if (StringTools.isNotNullOrEmpty(codeRivoli_p))
      {
        queryParams.put(IRESConnector.PARAM_RIVOLI, codeRivoli_p);
      }

      // Call SAAB
      final Response response;
      try
      {
        RESTRequest restRequest = new RESTRequest.RESTRequestBuilder()//
            .httpMethod(HttpMethod.GET)//
            .traceability(tracabilite_p)//
            .method(METHOD_NAME_ENTONNOIR_NUMERO_LIRE_TOUS_PAR_CODE_INSEE_CODE_RIVOLI)//
            .headers(AbstractInternalRESTConnector.getSpiritStarkRequestHeader())//
            .path(entonnoirNumeroUrl_p)//
            .queryParameter(queryParams)//
            .build();
        response = _resInstance.sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content
      GetListeEntonnoirNumeroResponse getListeEntonnoirNumeroResponse = _resInstance.getContentFromResponse(tracabilite_p, response, METHOD_NAME_ENTONNOIR_NUMERO_LIRE_TOUS_PAR_CODE_INSEE_CODE_RIVOLI, GetListeEntonnoirNumeroResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(getListeEntonnoirNumeroResponse.getRetour());
      List<EntonnoirNumero> entonnoirCommuneList = getListeEntonnoirNumeroResponse.getListeEntonnoirNumero();

      return new ConnectorResponse<>(retour, entonnoirCommuneList);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }

  /**
   * entonnoirNumeroLireTousParCodeInseeSimiliHexacle0
   *
   * @param tracabilite_p
   *          tracabilite
   * @param entonnoirNumeroUrl_p
   *          entonnoirNumeroUrl
   * @param codeInsee_p
   *          codeInsee
   * @param similiHexacle0_p
   *          similiHexacle0
   * @return ConnectorResponse<Retour, List<EntonnoirNumero>>
   */
  public ConnectorResponse<Retour, List<EntonnoirNumero>> entonnoirNumeroLireTousParCodeInseeSimiliHexacle0(Tracabilite tracabilite_p, String entonnoirNumeroUrl_p, String codeInsee_p, String similiHexacle0_p)
  {
    try
    {
      if (StringTools.isNullOrEmpty(entonnoirNumeroUrl_p))
      {
        throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(IRESConnector.MESSAGE_MISSING_CONFIGURATION_PARAMETER, IRESConnector.PAD3023_PATH_PARAM));
      }

      // Query parameters
      HashMap<String, String> queryParams = new HashMap<>();
      if (StringTools.isNotNullOrEmpty(codeInsee_p))
      {
        queryParams.put(IRESConnector.PARAM_CODE_INSEE, codeInsee_p);
      }
      if (StringTools.isNotNullOrEmpty(similiHexacle0_p))
      {
        queryParams.put(IRESConnector.PARAM_SIMILI_HEXACLE_0, similiHexacle0_p);
      }

      // Call SAAB
      final Response response;
      try
      {
        RESTRequest restRequest = new RESTRequest.RESTRequestBuilder()//
            .httpMethod(HttpMethod.GET)//
            .traceability(tracabilite_p)//
            .method(METHOD_NAME_ENTONNOIR_NUMERO_LIRE_TOUS_PAR_CODE_INSEE_SIMILI_HEXACLE_0)//
            .headers(AbstractInternalRESTConnector.getSpiritStarkRequestHeader())//
            .path(entonnoirNumeroUrl_p)//
            .queryParameter(queryParams)//
            .build();
        response = _resInstance.sendRequest(restRequest);
      }
      catch (Exception e_p)
      {
        // Retour KO
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
      }

      // Get the content
      GetListeEntonnoirNumeroResponse getListeEntonnoirNumeroResponse = _resInstance.getContentFromResponse(tracabilite_p, response, METHOD_NAME_ENTONNOIR_NUMERO_LIRE_TOUS_PAR_CODE_INSEE_SIMILI_HEXACLE_0, GetListeEntonnoirNumeroResponse.class);

      // Retour OK
      Retour retour = RetourConverter.convertFromJsonRetour(getListeEntonnoirNumeroResponse.getRetour());
      List<EntonnoirNumero> entonnoirCommuneList = getListeEntonnoirNumeroResponse.getListeEntonnoirNumero();

      return new ConnectorResponse<>(retour, entonnoirCommuneList);
    }
    catch (Exception e_p)
    {
      // Retour KO
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e_p.getMessage()), null);
    }
  }
}
