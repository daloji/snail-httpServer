/*******************************************************************************
* $Id: RES2104_RechercherCommune.java 247 2017-07-18 13:57:48Z pcarreir $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.res.activities;

import java.text.MessageFormat;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.log.event.SystemLogEvent;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.IActivityCaller;
import com.bytel.ravel.services.process.activity.BuiltActivityContext;
import com.bytel.spirit.common.connectors.res.Messages;
import com.bytel.spirit.common.connectors.res.RESProxy;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.Commune;
import com.bytel.spirit.common.shared.saab.res.NomCommuneAlt;
import com.bytel.spirit.common.shared.saab.res.response.ListeCommuneResponse;

/**
 *
 * @author pcarreir
 * @version ($Revision: 247 $ $Date: 2017-07-18 15:57:48 +0200 (mar., 18 juil. 2017) $)
 */
public class RES2104_RechercherCommune extends BuiltActivityContext<Commune>
{

  /**
   *
   * @author pcarreir
   * @version ($Revision: 247 $ $Date: 2017-07-18 15:57:48 +0200 (mar., 18 juil. 2017) $)
   */
  public static class RES2104_RechercherCommuneBuilder
  {
    /**
     * Object to build
     */
    RES2104_RechercherCommune _toBuild;

    /**
     * Constructor
     */
    public RES2104_RechercherCommuneBuilder()
    {
      _toBuild = new RES2104_RechercherCommune();
    }

    /**
     * @return RR0020_BL004_RechercherCommune
     */
    public RES2104_RechercherCommune build()
    {
      if ((_toBuild.getTracabilite() == null) || (_toBuild.getCodePostal() == null) || (_toBuild.getNomCommune() == null))
      {
        // PARAMETRE INVALIDE
        Retour retour = new Retour();
        retour.setResultat(StringConstants.NOK);
        retour.setCategorie(IMegConsts.CAT3);
        retour.setDiagnostic(IMegSpiritConsts.DONNEE_INVALIDE);
        retour.setLibelle("Parametre d'entree de l'activite non renseignee"); //$NON-NLS-1$
        _toBuild.setRetour(retour);
      }
      return _toBuild;
    }

    /**
     * @param codePostal_p
     *          The postal code
     * @return RR0020_BL004_RechercherCommuneBuilder
     */
    public RES2104_RechercherCommuneBuilder codePostal(String codePostal_p)
    {
      _toBuild.setCodePostal(codePostal_p);
      return this;
    }

    /**
     * @param nomCommune_p
     *          The commune name
     * @return RR0020_BL004_RechercherCommuneBuilder
     */
    public RES2104_RechercherCommuneBuilder nomCommune(String nomCommune_p)
    {
      _toBuild.setNomCommune(nomCommune_p);
      return this;
    }

    /**
     * @param tracabilite_p
     *          The tracability
     * @return RR0020_BL004_RechercherCommuneBuilder
     */
    public RES2104_RechercherCommuneBuilder tracabilite(Tracabilite tracabilite_p)
    {
      _toBuild.setTracabilite(tracabilite_p);
      return this;
    }
  }

  /**
   *
   * @author pcarreir
   * @version ($Revision: 247 $ $Date: 2017-07-18 15:57:48 +0200 (mar., 18 juil. 2017) $)
   */
  private enum Step
  {
    /**
     * First step to execute
     */
    First,

    /**
     * If all steps have been executed
     */
    End
  }

  /**
   *
   */
  private static final String CODE_POSTAL = "codePostal"; //$NON-NLS-1$

  /**
   *
   */
  private static final String RETOUR = "Retour"; //$NON-NLS-1$

  /**
   * The serial version UID
   */
  private static final long serialVersionUID = 6560046410318725076L;

  /**
   * The tracability
   */
  private Tracabilite _tracabilite = null;

  /**
   * The current execution step
   */
  private Step _currentStep = Step.First;

  /**
   * The commune name
   */
  private String _nomCommune;

  /**
   * The postal code
   */
  private String _codePostal;

  @Override
  public Commune executeNextStep(IActivityCaller arg0_p) throws RavelException
  {
    Commune result = null;
    switch (_currentStep)
    {
      case First:
        result = rechercherCommune();

        _currentStep = Step.End;
        break;
      default:
        break;
    }
    return result;
  }

  @Override
  public boolean isEndStep()
  {
    return Step.End.equals(_currentStep);
  }

  /**
   * @return String
   */
  protected String getCodePostal()
  {
    return _codePostal;
  }

  /**
   * @return String
   */
  protected String getNomCommune()
  {
    return _nomCommune;
  }

  /**
   * @return Tracabilite
   */
  protected Tracabilite getTracabilite()
  {
    return _tracabilite;
  }

  /**
   * @param codePostal_p
   *          The postal code
   */
  protected void setCodePostal(String codePostal_p)
  {
    _codePostal = codePostal_p;
  }

  /**
   * @param nomCommune_p
   *          The commune name
   */
  protected void setNomCommune(String nomCommune_p)
  {
    _nomCommune = nomCommune_p;
  }

  /**
   * @param tracabilite_p
   *          The tracability
   */
  protected void setTracabilite(Tracabilite tracabilite_p)
  {
    _tracabilite = tracabilite_p;
  }

  /**
   *
   * @return Commune
   * @throws RavelException
   *           RavelException
   */
  private Commune rechercherCommune() throws RavelException
  {
    SystemLogEvent system = new SystemLogEvent(LogSeverity.DEBUG, _tracabilite.getIdCorrelationSpirit(), Messages.getString("res.RES2104_RechercherCommune")); //$NON-NLS-1$
    system.addField(CODE_POSTAL, _codePostal, false);
    RavelLogger.log(system);
    Commune result = null;
    Retour retour;
    if (_codePostal.length() != 5)
    {
      retour = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ENTREE_INCORRECTE, MessageFormat.format(Messages.getString("res.codePostalInvalide"), _codePostal)); //$NON-NLS-1$
    }
    else
    {
      ConnectorResponse<Retour, ListeCommuneResponse> communeRes = RESProxy.getInstance().pad3001CommuneReadCodePostal(_tracabilite, _codePostal);//Communes.LireTous(_codePostal);
      retour = communeRes._first;
      if (!RetourFactory.isRetourOK(communeRes._first))
      {
        if (IMegConsts.DONNEE_INCONNUE.equals(communeRes._first.getDiagnostic()) || IMegSpiritConsts.CODE_INSEE_INCONNU.equals(communeRes._first.getDiagnostic()))
        {
          retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.CODE_POSTAL_INCONNU, MessageFormat.format(Messages.getString("res.codePostalInconnu"), _codePostal)); //$NON-NLS-1$
        }
      }
      else
      {
        if (communeRes._second.getListeCommune().size() == 1)
        {
          result = communeRes._second.getListeCommune().get(0);
        }
        else if (communeRes._second.getListeCommune().size() > 1)
        {
          for (Commune commune : communeRes._second.getListeCommune())
          {
            if ((commune.getNomCommune().equals(_nomCommune)))
            {
              result = commune;
              break;
            }
            for (NomCommuneAlt communeAlt : commune.getNomsAlternatifs())
            {
              if ((communeAlt.getNomCommune().equals(_nomCommune)))
              {
                result = commune;
                break;
              }
            }
          }
          if (result == null)
          {
            retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.NOM_COMMUNE_INCONNU, MessageFormat.format(Messages.getString("res.nomCommuneInconnu"), _nomCommune)); //$NON-NLS-1$
          }
        }
      }
    }
    system = new SystemLogEvent(LogSeverity.DEBUG, _tracabilite.getIdCorrelationSpirit(), Messages.getString("res.RES2104_RechercherCommune")); //$NON-NLS-1$
    system.addField(RETOUR, retour, false);
    RavelLogger.log(system);
    this.setRetour(retour);
    return result;
  }

}
