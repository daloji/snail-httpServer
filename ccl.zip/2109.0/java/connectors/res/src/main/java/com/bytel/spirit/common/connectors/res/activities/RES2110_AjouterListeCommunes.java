/*******************************************************************************
* $Id: RES2110_AjouterListeCommunes.java 247 2017-07-18 13:57:48Z pcarreir $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.res.activities;

import java.util.ArrayList;
import java.util.List;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.log.event.SystemLogEvent;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.IActivityCaller;
import com.bytel.ravel.services.process.activity.BuiltActivityContext;
import com.bytel.spirit.common.connectors.res.Messages;
import com.bytel.spirit.common.connectors.res.RESProxy;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.Commune;
import com.bytel.spirit.common.shared.saab.res.request.ListeCommuneRequest;

/**
 *
 * @author pcarreir
 * @version ($Revision: 247 $ $Date: 2017-07-18 15:57:48 +0200 (mar., 18 juil. 2017) $)
 */
public class RES2110_AjouterListeCommunes extends BuiltActivityContext<Retour>
{
  /**
   *
   * @author pcarreir
   * @version ($Revision: 247 $ $Date: 2017-07-18 15:57:48 +0200 (mar., 18 juil. 2017) $)
   */
  public static class RES2110_AjouterListeCommunesBuilder
  {
    /**
     * Object to build
     */
    RES2110_AjouterListeCommunes _toBuild;

    /**
     * Constructor
     */
    public RES2110_AjouterListeCommunesBuilder()
    {
      _toBuild = new RES2110_AjouterListeCommunes();
    }

    /**
     * @return RR0020_BL010_AjouterListeCommunes
     */
    public RES2110_AjouterListeCommunes build()
    {
      if ((_toBuild.getTracabilite() == null) || (_toBuild.getListeCommunes() == null))
      {
        // PARAMETRE INVALIDE
        Retour retour = new Retour();
        retour.setResultat(StringConstants.NOK);
        retour.setCategorie(IMegConsts.CAT3);
        retour.setDiagnostic(IMegSpiritConsts.DONNEE_INVALIDE);
        retour.setLibelle("Parametre d'entree de l'activite non renseignee"); //$NON-NLS-1$
        _toBuild.setRetour(retour);
      }
      return _toBuild;
    }

    /**
     * @param listeCommunes_p
     *          The commune list
     * @return RR0020_BL010_AjouterListeCommunesBuilder
     */
    public RES2110_AjouterListeCommunesBuilder listeCommunes(List<Commune> listeCommunes_p)
    {
      _toBuild.setListeCommunes(listeCommunes_p);
      return this;
    }

    /**
     * @param tracabilite_p
     *          The tracability
     * @return RR0020_BL010_AjouterListeCommunesBuilder
     */
    public RES2110_AjouterListeCommunesBuilder tracabilite(Tracabilite tracabilite_p)
    {
      _toBuild.setTracabilite(tracabilite_p);
      return this;
    }
  }

  /**
   *
   * @author pcarreir
   * @version ($Revision: 247 $ $Date: 2017-07-18 15:57:48 +0200 (mar., 18 juil. 2017) $)
   */
  private enum Step
  {
    /**
     * First step to execute
     */
    First,

    /**
     * If all steps have been executed
     */
    End
  }

  /**
   *
   */
  private static final String LISTE_COMMUNES = "listeCommunes"; //$NON-NLS-1$

  /**
   *
   */
  private static final String RETOUR = "Retour"; //$NON-NLS-1$

  /**
   * The serial version UID
   */
  private static final long serialVersionUID = 1624483678111094200L;

  /**
   * The tracability
   */
  private Tracabilite _tracabilite = null;

  /**
   * The current execution step
   */
  private Step _currentStep = Step.First;

  /**
   * The commune list
   */
  private List<Commune> _listeCommunes;

  @Override
  public Retour executeNextStep(IActivityCaller arg0_p) throws RavelException
  {
    SystemLogEvent system = new SystemLogEvent(LogSeverity.DEBUG, _tracabilite.getIdCorrelationSpirit(), Messages.getString("res.RES2110_AjouterListeCommunes")); //$NON-NLS-1$

    Retour result = null;
    switch (_currentStep)
    {
      case First:
        ListeCommuneRequest listRequest = new ListeCommuneRequest(_listeCommunes);
        system.addField(LISTE_COMMUNES, GsonTools.getIso8601Ms().toJson(listRequest), false);
        RavelLogger.log(system);
        ConnectorResponse<Retour, Boolean> retour = RESProxy.getInstance().pad3001CommuneCreate(_tracabilite, listRequest);
        result = retour._first;

        this.setRetour(result);

        _currentStep = Step.End;
        break;
      default:
        break;
    }
    system = new SystemLogEvent(LogSeverity.DEBUG, _tracabilite.getIdCorrelationSpirit(), Messages.getString("res.RES2110_AjouterListeCommunes")); //$NON-NLS-1$
    system.addField(RETOUR, result, false);
    RavelLogger.log(system);
    return result;
  }

  /**
   * @return List<Commune>
   */
  public List<Commune> getListeCommunes()
  {
    return _listeCommunes == null ? new ArrayList<>() : new ArrayList<>(_listeCommunes);
  }

  /**
   * @return Tracability
   */
  public Tracabilite getTracabilite()
  {
    return _tracabilite;
  }

  @Override
  public boolean isEndStep()
  {
    return Step.End.equals(_currentStep);
  }

  /**
   * @param listeCommunes_p
   *          The commune list
   */
  public void setListeCommunes(List<Commune> listeCommunes_p)
  {
    _listeCommunes = new ArrayList<>(listeCommunes_p);
  }

  /**
   * @param tracabilite_p
   *          The tracability
   */
  public void setTracabilite(Tracabilite tracabilite_p)
  {
    _tracabilite = tracabilite_p;
  }

}
