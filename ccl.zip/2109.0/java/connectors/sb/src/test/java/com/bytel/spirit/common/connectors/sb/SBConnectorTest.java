/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.sb;

import java.io.ByteArrayInputStream;
import java.util.Hashtable;

import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.cxf.jaxrs.impl.MetadataMap;
import org.apache.cxf.jaxrs.impl.ResponseBuilderImpl;
import org.easymock.EasyMock;
import org.easymock.EasyMockSupport;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockNice;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.modules.junit4.PowerMockRunner;

import com.bytel.ravel.common.conf.generated.LoadBalancer;
import com.bytel.ravel.common.conf.generated.Param;
import com.bytel.ravel.common.encryption.DESKeyManager;
import com.bytel.ravel.common.test.JUnitTools;
import com.bytel.ravel.common.utils.MarshallTools;
import com.bytel.ravel.net.loadbalancing.ILoadBalancer;
import com.bytel.ravel.net.loadbalancing.URLBalancedElement;
import com.bytel.ravel.net.rest.RestConnectorPool;
import com.bytel.ravel.net.rest.RestInstance;
import com.bytel.ravel.services.conf.connector.generated.Connector;
import com.bytel.ravel.services.conf.connector.generated.URL;
import com.bytel.ravel.services.conf.connector.generated.URLS;
import com.bytel.ravel.services.connector.AbstractRESTConnector;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.connector.sbconnector.Account;
import com.bytel.spirit.common.connector.sbconnector.Parameter;
import com.bytel.spirit.common.connector.sbconnector.Reason;
import com.bytel.spirit.common.connector.sbconnector.Service;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author mbaptist
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
public class SBConnectorTest extends EasyMockSupport
{
  /**
   * The TRUE string constant.
   */
  public final static String DEFAULT_MSGID = "4C25AE9D-CA17-4831-9243-30DC02C78079"; //$NON-NLS-1$

  /**
   * Manages the DES encryption keys and features
   */
  @SuppressWarnings("unused")
  private static DESKeyManager _desKeyManager;

  /**
   * Connector instance
   */
  private SBConnector _sbConnector;

  /**
   * Factory to generate beans
   */
  private PodamFactory _podam = new PodamFactoryImpl();

  @MockStrict
  ILoadBalancer<URLBalancedElement> _loadBalancerMock;

  /**
   * Mock of connectors pool HTTP
   */
  @MockStrict
  Hashtable<String, RestConnectorPool> _connectorPoolMock;

  /**
   * Mock {@link URLBalancedElement}
   */
  @MockStrict
  URLBalancedElement _urlBalancedElementMock;

  /**
  *
  */
  @MockStrict
  private RestInstance _restInstanceMock;

  /**
   *
   */
  @MockNice
  RestConnectorPool _restConnectorPoolMock;

  /**
   * @throws Exception
   */
  @Test
  public void consultSB_Test_KO_1() throws Exception
  {

    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    MultivaluedMap<String, String> httpHeader = new MetadataMap<String, String>();
    httpHeader.add("ReqId", tracabilite.getIdCorrelationSpirit()); //$NON-NLS-1$
    Reason reason = new Reason();
    reason.setCode(500);
    reason.setValue("value"); //$NON-NLS-1$
    String path = "http://localhost:8089/SB/prov/reqId_p"; //$NON-NLS-1$
    Parameter parameter = new Parameter();
    parameter.setName("name"); //$NON-NLS-1$
    parameter.setValue("value"); //$NON-NLS-1$
    Service service = new Service();
    service.setName("name"); //$NON-NLS-1$
    service.getParameters().add(parameter);

    final String urlBalancedElementName = RandomStringUtils.randomAlphanumeric(45);
    final String urlBalancedElementDescription = RandomStringUtils.randomAlphabetic(9);

    final String partnerResponse = MarshallTools.marshall(reason);
    final Response expectedResponse = new ResponseBuilderImpl().status(500).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();
    _sbConnector = new SBConnector();

    PowerMock.resetAll();
    //    JUnitTools.setInaccessibleFieldValue(_sbConnector, "_restConnectorPool", _restConnectorPoolMock); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_sbConnector, "_connectorPool", _connectorPoolMock); //$NON-NLS-1$
    //    JUnitTools.setInaccessibleFieldValue(_sbConnector, "_proxyEnabled", false); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_sbConnector, "_pathname", "http://localhost:8089/SB/prov/"); //$NON-NLS-1$ //$NON-NLS-2$
    JUnitTools.setInaccessibleFieldValue(_sbConnector, "_loadBalancer", _loadBalancerMock); //$NON-NLS-1$

    EasyMock.expect(_loadBalancerMock.chooseBalancedElement()).andReturn(_urlBalancedElementMock);
    EasyMock.expect(_urlBalancedElementMock.getName()).andReturn(urlBalancedElementName);
    EasyMock.expect(_urlBalancedElementMock.getDescription()).andReturn(urlBalancedElementDescription);
    EasyMock.expect(_urlBalancedElementMock.getName()).andReturn(urlBalancedElementName);
    EasyMock.expect(_connectorPoolMock.get(urlBalancedElementName)).andReturn(_restConnectorPoolMock);
    EasyMock.expect(_restConnectorPoolMock.borrowObject()).andReturn(_restInstanceMock);
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(path, httpHeader, null)).andReturn(expectedResponse);
    PowerMock.replayAll();
    ConnectorResponse<Integer, ResponseConnector> response = _sbConnector.consultSB(tracabilite, "reqId_p"); //$NON-NLS-1$

    Assert.assertEquals(new Integer(500), response._first);
    Assert.assertEquals("value", response._second.getReason().getValue()); //$NON-NLS-1$

  }

  /**
   * @throws Exception
   */
  @Test
  public void consultSB_Test_KO_2() throws Exception
  {

    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    MultivaluedMap<String, String> httpHeader = new MetadataMap<String, String>();
    httpHeader.add("ReqId", tracabilite.getIdCorrelationSpirit()); //$NON-NLS-1$
    String path = "http://localhost:8089/SB/prov/reqId_p"; //$NON-NLS-1$
    Parameter parameter = new Parameter();
    parameter.setName("name"); //$NON-NLS-1$
    parameter.setValue("value"); //$NON-NLS-1$
    Service service = new Service();
    service.setName("name"); //$NON-NLS-1$
    service.getParameters().add(parameter);

    final String urlBalancedElementName = RandomStringUtils.randomAlphanumeric(45);
    final String urlBalancedElementDescription = RandomStringUtils.randomAlphabetic(9);

    final String partnerResponse = "<html><head><title>404 Not Found</title></head><body bgcolor=\"white\"><center><h1>404 Not Found</h1></center><hr><center>nginx</center></body></html>"; //$NON-NLS-1$
    final Response expectedResponse = new ResponseBuilderImpl().status(404).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();
    _sbConnector = new SBConnector();

    PowerMock.resetAll();
    //    JUnitTools.setInaccessibleFieldValue(_sbConnector, "_restConnectorPool", _restConnectorPoolMock); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_sbConnector, "_connectorPool", _connectorPoolMock); //$NON-NLS-1$
    //    JUnitTools.setInaccessibleFieldValue(_sbConnector, "_proxyEnabled", false); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_sbConnector, "_pathname", "http://localhost:8089/SB/prov/"); //$NON-NLS-1$ //$NON-NLS-2$
    JUnitTools.setInaccessibleFieldValue(_sbConnector, "_loadBalancer", _loadBalancerMock); //$NON-NLS-1$

    EasyMock.expect(_loadBalancerMock.chooseBalancedElement()).andReturn(_urlBalancedElementMock);
    EasyMock.expect(_urlBalancedElementMock.getName()).andReturn(urlBalancedElementName);
    EasyMock.expect(_urlBalancedElementMock.getDescription()).andReturn(urlBalancedElementDescription);
    EasyMock.expect(_urlBalancedElementMock.getName()).andReturn(urlBalancedElementName);
    EasyMock.expect(_connectorPoolMock.get(urlBalancedElementName)).andReturn(_restConnectorPoolMock);
    EasyMock.expect(_restConnectorPoolMock.borrowObject()).andReturn(_restInstanceMock);
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(path, httpHeader, null)).andReturn(expectedResponse);
    PowerMock.replayAll();
    ConnectorResponse<Integer, ResponseConnector> response = _sbConnector.consultSB(tracabilite, "reqId_p"); //$NON-NLS-1$

    Assert.assertEquals(new Integer(500), response._first);
    Assert.assertEquals(null, response._second);

  }

  /**
   * @throws Exception
   */
  @Test
  public void consultSB_Test_OK() throws Exception
  {

    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    MultivaluedMap<String, String> httpHeader = new MetadataMap<String, String>();
    httpHeader.add("ReqId", tracabilite.getIdCorrelationSpirit()); //$NON-NLS-1$
    String path = "http://localhost:8089/SB/prov/reqId_p"; //$NON-NLS-1$
    Parameter parameter = new Parameter();
    parameter.setName("name"); //$NON-NLS-1$
    parameter.setValue("value"); //$NON-NLS-1$
    Service service = new Service();
    service.setName("name"); //$NON-NLS-1$
    service.getParameters().add(parameter);
    Account account = new Account();
    account.getParameters().add(parameter);
    account.getServices().add(service);
    account.setNumtel("33612345678"); //$NON-NLS-1$

    final String urlBalancedElementName = RandomStringUtils.randomAlphanumeric(45);
    final String urlBalancedElementDescription = RandomStringUtils.randomAlphabetic(9);

    final String partnerResponse = MarshallTools.marshall(account);
    final Response expectedResponse = new ResponseBuilderImpl().status(200).entity(new ByteArrayInputStream(partnerResponse.getBytes())).build();
    _sbConnector = new SBConnector();

    PowerMock.resetAll();
    //    JUnitTools.setInaccessibleFieldValue(_sbConnector, "_restConnectorPool", _restConnectorPoolMock); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_sbConnector, "_connectorPool", _connectorPoolMock); //$NON-NLS-1$
    //    JUnitTools.setInaccessibleFieldValue(_sbConnector, "_proxyEnabled", false); //$NON-NLS-1$
    JUnitTools.setInaccessibleFieldValue(_sbConnector, "_pathname", "http://localhost:8089/SB/prov/"); //$NON-NLS-1$ //$NON-NLS-2$
    JUnitTools.setInaccessibleFieldValue(_sbConnector, "_loadBalancer", _loadBalancerMock); //$NON-NLS-1$

    EasyMock.expect(_loadBalancerMock.chooseBalancedElement()).andReturn(_urlBalancedElementMock);
    EasyMock.expect(_urlBalancedElementMock.getName()).andReturn(urlBalancedElementName);
    EasyMock.expect(_urlBalancedElementMock.getDescription()).andReturn(urlBalancedElementDescription);
    EasyMock.expect(_urlBalancedElementMock.getName()).andReturn(urlBalancedElementName);
    EasyMock.expect(_connectorPoolMock.get(urlBalancedElementName)).andReturn(_restConnectorPoolMock);
    EasyMock.expect(_restConnectorPoolMock.borrowObject()).andReturn(_restInstanceMock);
    _restInstanceMock.setReceiveTimeout(0);
    EasyMock.expect(_restInstanceMock.get(path, httpHeader, null)).andReturn(expectedResponse);
    PowerMock.replayAll();
    ConnectorResponse<Integer, ResponseConnector> response = _sbConnector.consultSB(tracabilite, "reqId_p"); //$NON-NLS-1$

    Assert.assertEquals(new Integer(200), response._first);
    Assert.assertEquals("33612345678", response._second.getAccount().getNumtel()); //$NON-NLS-1$

  }

  /**
   * Init the test
   *
   * @throws Exception
   */
  @Before
  public void init() throws Exception
  {

    // test encryption key ...
    //_desKeyManager = new DESKeyManager("com.bytel.ressources.services.connector.oam.TestKey"); //$NON-NLS-1$

    PowerMock.resetAll();

    _sbConnector = new SBConnector();

    Connector connectorCfg = new Connector();

    connectorCfg.setName("SBConnector"); //$NON-NLS-1$
    connectorCfg.setClazz("package com.bytel.spirit.common.connectors.sb.SBConnector"); //$NON-NLS-1$
    connectorCfg.setType("client"); //$NON-NLS-1$
    connectorCfg.setEnabled(true);

    addParam(connectorCfg, "URL", "http://localhost:8089"); //$NON-NLS-1$//$NON-NLS-2$
    addParam(connectorCfg, "PATHNAME", "/SB/prov/"); //$NON-NLS-1$ //$NON-NLS-2$
    //    addParam(connectorCfg, "LOGIN_USERID", "npbtb4"); //$NON-NLS-1$//$NON-NLS-2$
    //    addParam(connectorCfg, "LOGIN_PASSWORD", "password"); //$NON-NLS-1$//$NON-NLS-2$
    addParam(connectorCfg, "BASIC_AUTHENT", "false"); //$NON-NLS-1$//$NON-NLS-2$
    addParam(connectorCfg, "LOGIN_AUTHENT", "teste"); //$NON-NLS-1$//$NON-NLS-2$
    addParam(connectorCfg, "PASSWORD_AUTHENT", "H+ayqi0gQ+J2LQCq59s8Xg=="); //$NON-NLS-1$//$NON-NLS-2$
    addParam(connectorCfg, "PROXY_ENABLED", "false"); //$NON-NLS-1$ //$NON-NLS-2$
    addParam(connectorCfg, "PROXY_HOST", "xxx.xxx.xxx.xxx"); //$NON-NLS-1$ //$NON-NLS-2$
    addParam(connectorCfg, "PROXY_PORT", "xxxx"); //$NON-NLS-1$ //$NON-NLS-2$
    addParam(connectorCfg, "PROXY_LOGIN", "[LOGIN]"); //$NON-NLS-1$ //$NON-NLS-2$
    addParam(connectorCfg, "PROXY_PASSWORD", "[ENCRYPTED_PASSWORD]"); //$NON-NLS-1$ //$NON-NLS-2$
    addParam(connectorCfg, "POOLSIZE", "15"); //$NON-NLS-1$ //$NON-NLS-2$
    addParam(connectorCfg, "RECEIVE_TIMEOUT", "30000"); //$NON-NLS-1$ //$NON-NLS-2$

    connectorCfg.setURLS(generateURLS());

    _sbConnector.loadConnectorConfiguration(connectorCfg);

  }

  /**
   * @param connectorCfg
   *          the connector to fill
   * @param name
   *          the parameter name
   * @param value
   *          the parameter value
   */
  private void addParam(Connector connectorCfg, String name, String value)
  {
    Param p = new Param();
    p.setName(name);
    p.setValue(value);
    connectorCfg.getParam().add(p);
  }

  /**
   * Génération du LoadBalancer minimal pour passer {@link AbstractRESTConnector#loadConnectorConfiguration(Connector)}
   *
   * @return {@link LoadBalancer}
   */
  private LoadBalancer generateLoadBalancer()
  {
    final LoadBalancer loadBalancer = new LoadBalancer();
    Param timer = new Param();
    timer.setName("TIMER"); //$NON-NLS-1$
    timer.setValue("30"); //$NON-NLS-1$
    loadBalancer.getParam().add(timer);
    loadBalancer.setType("RoundRobin"); //$NON-NLS-1$
    return loadBalancer;
  }

  /**
   * Génération du URL minimal pour passer {@link AbstractRESTConnector#loadConnectorConfiguration(Connector)}
   *
   * @return {@link URL}
   */
  private URL generateURL()
  {
    final URL url = new URL();
    url.setName("urlName"); //$NON-NLS-1$
    url.setAccessPoint("http://localhost:8089/SB/prov/"); //$NON-NLS-1$
    Param param = new Param();
    param.setName("PROXY_ENABLED"); //$NON-NLS-1$
    param.setValue(String.valueOf(false));
    url.getParam().add(param);
    param = new Param();
    param.setName("TIMEOUT"); //$NON-NLS-1$
    param.setValue("30"); //$NON-NLS-1$
    url.getParam().add(param);

    return url;
  }

  /**
   * Génération du URLS minimal pour passer {@link AbstractRESTConnector#loadConnectorConfiguration(Connector)}
   *
   * @return {@link URLS}
   */
  private URLS generateURLS()
  {
    final URLS urls = new URLS();
    urls.setLoadBalancer(generateLoadBalancer());
    urls.getURL().add(generateURL());
    return urls;
  }

}