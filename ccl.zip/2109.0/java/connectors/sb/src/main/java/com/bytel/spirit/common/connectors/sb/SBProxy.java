/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.sb;

import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.probes.AvgDoubleCollectorItem;
import com.bytel.ravel.common.probes.AvgFlowPerSecondCollector;
import com.bytel.ravel.common.probes.RavelProbeConfigurationManager;
import com.bytel.ravel.services.connector.BaseProxy;
import com.bytel.ravel.services.connector.ConnectorExecution;
import com.bytel.ravel.services.connector.ConnectorManager;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

/**
 * ServiceBroker connector proxy
 *
 * @author mbaptist
 * @version ($Revision$ $Date$)
 */
public final class SBProxy extends BaseProxy implements ISB
{

  /**
   * Proxy instance
   */
  private static final SBProxy _instance = new SBProxy();

  /**
   * Gets the single instance of SBProxy.
   *
   * @return The proxy instance.
   */
  public static SBProxy getInstance()
  {
    return SBProxy._instance;
  }

  /**
   * Probe: measure the average number of consultSB requests per second.
   */
  AvgFlowPerSecondCollector _avg_consultSB_call_counter;

  /**
   * Probe: measure the average execution time of consultSB requests.
   */
  AvgDoubleCollectorItem _avg_consultSB_ExecTime;

  /**
   * Default constructor.
   */
  private SBProxy()
  {
    _avg_consultSB_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_consultSB_call_counter", "SBProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_consultSB_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_consultSB_ExecTime", "SBProxy"); //$NON-NLS-1$ //$NON-NLS-2$

  }

  @Override
  public ConnectorResponse<Integer, ResponseConnector> consultSB(final Tracabilite tracabilite_p, final String numtel_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<Integer, ResponseConnector>>(ISBConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<Integer, ResponseConnector> run() throws RavelException
      {
        ISBConnector connector = (ISBConnector) ConnectorManager.getInstance().getConnector(_connectorId);

        _avg_consultSB_call_counter.measure();

        long startTime = System.currentTimeMillis();
        ConnectorResponse<Integer, ResponseConnector> response = connector.consultSB(tracabilite_p, numtel_p);
        long endTime = System.currentTimeMillis();

        _avg_consultSB_ExecTime.updateAvgValue(endTime - startTime);

        return response;
      }
    });
  }

}