/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.sb;

import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

/**
 *
 * @author mbaptist
 * @version ($Revision$ $Date$)
 */
public interface ISB
{
  /**
   * Consult Service Broker with numtel parameter.
   *
   * @param tracabilite_p
   *          the tracabilite
   * @param numtel_p
   *          The numtel parameter
   * @return {@link ResponseConnector}
   * @throws RavelException
   *           On unexpected error (technical exception for instance).
   */
  public ConnectorResponse<Integer, ResponseConnector> consultSB(Tracabilite tracabilite_p, String numtel_p) throws RavelException;
}
