/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.sb;

import com.bytel.ravel.services.connector.IConnector;

/**
 *
 * @author mbaptist
 * @version ($Revision$ $Date$)
 */
public interface ISBConnector extends IConnector, ISB
{
  /**
   * The id to retrieve the connector.
   */
  public String BEAN_ID = "SBConnector"; //$NON-NLS-1$
}
