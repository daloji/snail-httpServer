/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.sb;

import java.util.MissingResourceException;
import java.util.ResourceBundle;

/**
 *
 * @author mbaptist
 * @version ($Revision$ $Date$)
 */
public final class Messages
{

  /**
   *
   */
  private static final String BUNDLE_NAME = "com.bytel.spirit.common.connectors.sb.messages"; //$NON-NLS-1$

  /**
   *
   */
  private static final ResourceBundle RESOURCE_BUNDLE = ResourceBundle.getBundle(Messages.BUNDLE_NAME);

  /**
   * Gets the string.
   *
   * @param key_p
   *          the key
   * @return the value
   */
  public static String getString(String key_p)
  {
    try
    {
      return Messages.RESOURCE_BUNDLE.getString(key_p);
    }
    catch (MissingResourceException e)
    {
      return '!' + key_p + '!';
    }
  }

  /**
   *
   */
  private Messages()
  {
  }
}