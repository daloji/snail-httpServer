/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.sb;

import com.bytel.spirit.common.connector.sbconnector.Account;
import com.bytel.spirit.common.connector.sbconnector.Reason;

/**
 *
 * @author mbaptist
 * @version ($Revision$ $Date$)
 */
public class ResponseConnector
{

  /**
   * {@link Account}
   */
  private Account _account;

  /**
   * {@link Reason}
   */
  private Reason _reason;

  /**
   *
   * Constructor with parameters.
   *
   * @param account_p
   *          {@link Account}
   * @param reason_p
   *          {@link Reason}
   */
  public ResponseConnector(Account account_p, Reason reason_p)
  {
    super();
    _account = account_p;
    _reason = reason_p;
  }

  /**
   * @return the account
   */
  public Account getAccount()
  {
    return _account;
  }

  /**
   * @return the reason
   */
  public Reason getReason()
  {
    return _reason;
  }

  /**
   * @param account_p
   *          the account to set
   */
  public void setAccount(Account account_p)
  {
    _account = account_p;
  }

  /**
   * @param reason_p
   *          the reason to set
   */
  public void setReason(Reason reason_p)
  {
    _reason = reason_p;
  }

}