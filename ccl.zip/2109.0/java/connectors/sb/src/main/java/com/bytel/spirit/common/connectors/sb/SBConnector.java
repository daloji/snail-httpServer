/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.sb;

import java.text.MessageFormat;

import javax.ws.rs.HttpMethod;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.apache.cxf.jaxrs.impl.MetadataMap;

import com.bytel.ravel.common.conf.generated.Param;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.utils.MarshallTools;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.services.conf.connector.generated.Connector;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.connector.RESTRequest.RESTRequestBuilder;
import com.bytel.ravel.services.connector.tools.MSISDNTools;
import com.bytel.ravel.services.connector.tools.MSISDNTools.MsisdnFormat;
import com.bytel.spirit.common.connector.sbconnector.Account;
import com.bytel.spirit.common.connector.sbconnector.Reason;
import com.bytel.spirit.common.shared.misc.connectors.AbstractExternalRESTConnector;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

/**
 * ServiceBroker connector
 *
 * @author mbaptist
 * @version ($Revision$ $Date$)
 */
public class SBConnector extends AbstractExternalRESTConnector implements ISBConnector
{

  /**
   * The REQ_ID string constant.
   */
  private static final String REQ_ID = "ReqId"; //$NON-NLS-1$

  /**
   * The constant for commandeLireUn service
   */
  private static final String METHOD_NAME_CONSULT_SB = "consultSB"; //$NON-NLS-1$

  /**
   * The constant for parameter PATHNAME
   */
  private static final String PATHNAME = "PATHNAME"; //$NON-NLS-1$

  /**
   * Stores the SB pathname
   */
  private String _pathname;

  @Override
  public ConnectorResponse<Integer, ResponseConnector> consultSB(Tracabilite tracabilite_p, String numtel_p) throws RavelException
  {
    try
    {
      MultivaluedMap<String, String> httpHeader = new MetadataMap<String, String>();
      httpHeader.add(REQ_ID, tracabilite_p.getIdCorrelationSpirit());

      String url;
      String msisdn = MSISDNTools.convert(MsisdnFormat.INTERNATIONAL, numtel_p);
      if (_pathname.endsWith("/")) //$NON-NLS-1$
      {
        url = _pathname + msisdn;
      }
      else
      {
        url = _pathname + "/" + msisdn; //$NON-NLS-1$
      }

      RESTRequestBuilder restRequestBuilder = new RESTRequestBuilder();
      restRequestBuilder.httpMethod(HttpMethod.GET).traceability(tracabilite_p).method(METHOD_NAME_CONSULT_SB).headers(httpHeader).path(url);
      Response response = sendRequest(restRequestBuilder.build());

      String tmp = getContent(response, METHOD_NAME_CONSULT_SB, tracabilite_p);

      if (response.getStatus() == Status.OK.getStatusCode())
      {
        Account account = MarshallTools.unmarshall(Account.class, tmp);

        return new ConnectorResponse<Integer, ResponseConnector>(response.getStatus(), new ResponseConnector(account, null));
      }

      Reason reason = MarshallTools.unmarshall(Reason.class, tmp);

      return new ConnectorResponse<Integer, ResponseConnector>(response.getStatus(), new ResponseConnector(null, reason));

    }
    catch (Exception e)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, e));
      return new ConnectorResponse<Integer, ResponseConnector>(500, null);
    }
  }

  @Override
  public String getConfigParameter(String arg0_p, String arg1_p) throws RavelException
  {
    return null;
  }

  @Override
  public void loadConnectorConfiguration(Connector connector_p) throws RavelException
  {
    super.loadConnectorConfiguration(connector_p);

    // Get and validate specific configuration parameters
    for (Param param : connector_p.getParam())
    {
      if (PATHNAME.equals(param.getName()))
      {
        _pathname = param.getValue();
        break;
      }
    }

    if (StringTools.isNullOrEmpty(_pathname))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(Messages.getString("SBConnector.MissingParameter"), PATHNAME)); //$NON-NLS-1$
    }
  }
}