/*******************************************************************************
* $Id: StTasClip.java 9142 2018-08-16 15:00:16Z jalmeida $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.tas.structs;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 *
 * @author lchanyip
 * @version ($Revision: 9142 $ $Date: 2018-08-16 17:00:16 +0200 (jeu. 16 août 2018) $)
 */
public class StTasClip
{
  /**
   * Etat du service : ACTIF, INACTIF ou vide
   */
  @SerializedName("etat")
  @Expose
  private String _etat;

  /**
   * restriction-override
   */
  @SerializedName("restriction-override")
  @Expose
  private String _restrictionOverride;

  /**
   */
  public StTasClip()
  {
    this("");
  }

  /**
   * @param etat_p
   */
  public StTasClip(String etat_p)
  {
    _etat = etat_p;
    _restrictionOverride = ""; //$NON-NLS-1$
  }

  /**
   * @return the etat
   */
  public String getEtat()
  {
    return _etat;
  }

  /**
   * @return the restrictionOverride
   */
  public String getRestrictionOverride()
  {
    return _restrictionOverride;
  }

  /**
   * @param etat_p
   *          the etat to set
   */
  public void setEtat(String etat_p)
  {
    _etat = etat_p;
  }

  /**
   * @param restrictionOverride_p
   *          the restrictionOverride to set
   */
  public void setRestrictionOverride(String restrictionOverride_p)
  {
    _restrictionOverride = restrictionOverride_p;
  }
}
