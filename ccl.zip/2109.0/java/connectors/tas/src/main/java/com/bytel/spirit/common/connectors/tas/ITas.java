/*******************************************************************************
 * $Id: ITas.java 9350 2018-08-22 08:56:15Z jalmeida $
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.tas;

import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.connector.GenericError;
import com.bytel.spirit.common.connectors.tas.structs.JsonGetResponse;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

/**
 * Services to implement.
 *
 * @author lchanyip
 * @version ($Revision: 9350 $ $Date: 2018-08-22 10:56:15 +0200 (mer. 22 août 2018) $)
 */
public interface ITas
{
  /**
   * get user's data operation.
   *
   * @param tracabilite_p
   *          message identifier
   *
   * @param sessionId_p
   *          sessionId identifies the session opened with the LOGIN request
   * @param msisdn_p
   *          msisdn to search
   * @return a GetResponse object
   * @throws RavelException
   *           if unexpected error occurs.
   */
  public ConnectorResponse<JsonGetResponse, GenericError<Integer>> get(Tracabilite tracabilite_p, String sessionId_p, String msisdn_p) throws RavelException;

  /**
   * Login operation.
   *
   * @param tracabilite_p
   *          message identifier
   * @return a session id (String)
   *
   * @throws RavelException
   *           if unexpected error occurs.
   */
  public ConnectorResponse<String, GenericError<Integer>> login(Tracabilite tracabilite_p) throws RavelException;

  /**
   * Logout operation.
   *
   * @param tracabilite_p
   *          message identifier
   * @param sessionId_p
   *          sessionId to logout
   * @return the sessionId
   *
   * @throws RavelException
   *           if unexpected error occurs.
   */
  public ConnectorResponse<String, GenericError<Integer>> logout(Tracabilite tracabilite_p, String sessionId_p) throws RavelException;

}
