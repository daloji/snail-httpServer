/*******************************************************************************
 * $Id: TasProxy.java 9350 2018-08-22 08:56:15Z jalmeida $
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.tas;

import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.probes.AvgDoubleCollectorItem;
import com.bytel.ravel.common.probes.AvgFlowPerSecondCollector;
import com.bytel.ravel.common.probes.RavelProbeConfigurationManager;
import com.bytel.ravel.services.connector.BaseProxy;
import com.bytel.ravel.services.connector.ConnectorExecution;
import com.bytel.ravel.services.connector.ConnectorManager;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.connector.GenericError;
import com.bytel.spirit.common.connectors.tas.structs.JsonGetResponse;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

/**
 * Proxy class.
 *
 * @author lchanyip
 * @version ($Revision: 9350 $ $Date: 2018-08-22 10:56:15 +0200 (mer. 22 août 2018) $)
 */
public final class TasProxy extends BaseProxy implements ITas
{

  /**
   * Proxy instance.
   */
  private static final TasProxy _instance = new TasProxy();

  /**
   * Gets the single instance of MMSCProxy.
   *
   * @return The proxy instance.
   */
  public static TasProxy getInstance()
  {
    return TasProxy._instance;
  }

  /**
   * Probe: measure the average number of login requests per second.
   */
  AvgFlowPerSecondCollector _avg_login_call_counter;

  /**
   * Probe: measure the average execution time of login requests.
   */
  AvgDoubleCollectorItem _avg_login_ExecTime;

  /**
   * Probe: measure the average number of logout requests per second.
   */
  AvgFlowPerSecondCollector _avg_logout_call_counter;

  /**
   * Probe: measure the average execution time of logout requests.
   */
  AvgDoubleCollectorItem _avg_logout_ExecTime;

  /**
   * Probe: measure the average number of GET requests per second.
   */
  AvgFlowPerSecondCollector _avg_get_call_counter;

  /**
   * Probe: measure the average execution time of GET requests.
   */
  AvgDoubleCollectorItem _avg_get_ExecTime;

  /**
   * Default constructor.
   */
  private TasProxy()
  {
    _avg_login_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_TasLogin_call_per_second", "TasProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_login_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_TasLogin_ExecTime", "TasProxy"); //$NON-NLS-1$ //$NON-NLS-2$

    _avg_logout_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_TasLogout_call_per_second", "TasProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_logout_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_TasLogout_ExecTime", "TasProxy"); //$NON-NLS-1$ //$NON-NLS-2$

    _avg_get_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_TasGet_call_per_second", "TasProxy"); //$NON-NLS-1$ //$NON-NLS-2$
    _avg_get_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_TasGet_ExecTime", "TasProxy"); //$NON-NLS-1$ //$NON-NLS-2$
  }

  @Override
  public ConnectorResponse<JsonGetResponse, GenericError<Integer>> get(Tracabilite tracabilite_p, String sessionId_p, String msisdn_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<JsonGetResponse, GenericError<Integer>>>(ITasConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<JsonGetResponse, GenericError<Integer>> run() throws RavelException
      {
        ITasConnector connector = (ITasConnector) ConnectorManager.getInstance().getConnector(_connectorId);

        _avg_get_call_counter.measure();

        long startTime = System.currentTimeMillis();
        try
        {
          ConnectorResponse<JsonGetResponse, GenericError<Integer>> response = connector.get(tracabilite_p, sessionId_p, msisdn_p);
          return response;
        }
        finally
        {
          long endTime = System.currentTimeMillis();

          _avg_get_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<String, GenericError<Integer>> login(Tracabilite tracabilite_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<String, GenericError<Integer>>>(ITasConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<String, GenericError<Integer>> run() throws RavelException
      {
        ITasConnector connector = (ITasConnector) ConnectorManager.getInstance().getConnector(_connectorId);

        _avg_login_call_counter.measure();

        long startTime = System.currentTimeMillis();
        try
        {
          ConnectorResponse<String, GenericError<Integer>> response = connector.login(tracabilite_p);
          return response;
        }
        finally
        {
          long endTime = System.currentTimeMillis();

          _avg_login_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }

  @Override
  public ConnectorResponse<String, GenericError<Integer>> logout(Tracabilite tracabilite_p, String sessionId_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<String, GenericError<Integer>>>(ITasConnector.BEAN_ID)
    {
      @Override
      public ConnectorResponse<String, GenericError<Integer>> run() throws RavelException
      {
        ITasConnector connector = (ITasConnector) ConnectorManager.getInstance().getConnector(_connectorId);

        _avg_logout_call_counter.measure();

        long startTime = System.currentTimeMillis();
        try
        {
          ConnectorResponse<String, GenericError<Integer>> response = connector.logout(tracabilite_p, sessionId_p);
          return response;
        }
        finally
        {
          long endTime = System.currentTimeMillis();

          _avg_logout_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }
}
