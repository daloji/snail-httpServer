package com.bytel.spirit.common.connectors.tas;

import java.util.MissingResourceException;
import java.util.ResourceBundle;

/**
 * @author lchanyip
 * @version ($Revision: 9350 $ $Date: 2018-08-22 10:56:15 +0200 (mer. 22 août 2018) $)
 */
public final class Messages
{

  /**
   *
   */
  private static final String BUNDLE_NAME = "com.bytel.spirit.common.connectors.tas.messages"; //$NON-NLS-1$

  /**
   *
   */
  private static final ResourceBundle RESOURCE_BUNDLE = ResourceBundle.getBundle(Messages.BUNDLE_NAME);

  /**
   * Gets the string.
   *
   * @param key_p
   *          the key
   * @return the value
   */
  public static String getString(String key_p)
  {
    try
    {
      return Messages.RESOURCE_BUNDLE.getString(key_p);
    }
    catch (MissingResourceException e)
    {
      return '!' + key_p + '!';
    }
  }

  /**
   *
   */
  private Messages()
  {
  }
}
