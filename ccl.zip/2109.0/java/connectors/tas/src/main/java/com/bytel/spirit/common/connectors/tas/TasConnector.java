/*******************************************************************************
 * $Id: TasConnector.java 26355 2019-09-11 14:43:52Z fbarnabe $
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.tas;

import java.net.MalformedURLException;
import java.net.URL;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.namespace.QName;
import javax.xml.transform.dom.DOMResult;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.Holder;

import org.apache.cxf.headers.Header;
import org.apache.cxf.jaxb.JAXBDataBinding;

import com.bytel.ravel.common.conf.generated.Param;
import com.bytel.ravel.common.encryption.PasswordDecrypter;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.utils.MarshallTools;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.services.conf.connector.generated.Connector;
import com.bytel.ravel.services.connector.AbstractConnector;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.connector.GenericError;
import com.bytel.ravel.services.connector.tools.MSISDNTools;
import com.bytel.ravel.services.connector.tools.MSISDNTools.MsisdnFormat;
import com.bytel.ravel.services.connector.tools.ServiceBuilder;
import com.bytel.spirit.common.connectors.tas.structs.JsonGetResponse;
import com.bytel.spirit.common.connectors.tas.structs.Services;
import com.bytel.spirit.common.shared.misc.log.LogEventName;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.ressources.Consts;
import com.bytel.spirit.common.shared.misc.ressources.RetourTechnique;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.connector.tas.AbstractGetAttributeType;
import com.bytel.spirit.connector.tas.ActivatedEnumType;
import com.bytel.spirit.connector.tas.AnyMOIdType;
import com.bytel.spirit.connector.tas.AnySequenceType;
import com.bytel.spirit.connector.tas.Cai3GFault_Exception;
import com.bytel.spirit.connector.tas.CdivActionsType;
import com.bytel.spirit.connector.tas.CdivActionsType.CdivActionOptions;
import com.bytel.spirit.connector.tas.CdivConditionsType;
import com.bytel.spirit.connector.tas.CdivRuleType;
import com.bytel.spirit.connector.tas.CdivRulesetType;
import com.bytel.spirit.connector.tas.CdivUserConfigurationType;
import com.bytel.spirit.connector.tas.CommunicationWaiting.CwOperatorConfiguration;
import com.bytel.spirit.connector.tas.CommunicationWaiting.CwUserConfiguration;
import com.bytel.spirit.connector.tas.Get.MOAttributes;
import com.bytel.spirit.connector.tas.GetResponseMMTel;
import com.bytel.spirit.connector.tas.GetResponseMOAttributesType;
import com.bytel.spirit.connector.tas.IcbConditionsType;
import com.bytel.spirit.connector.tas.IcbOperatorConfigurationType;
import com.bytel.spirit.connector.tas.IcbRuleType;
import com.bytel.spirit.connector.tas.IcbRulesetType;
import com.bytel.spirit.connector.tas.ObjectFactory;
import com.bytel.spirit.connector.tas.OipOperatorConfigurationType;
import com.bytel.spirit.connector.tas.OipUserConfigurationType;
import com.bytel.spirit.connector.tas.OirOperatorConfigurationType;
import com.bytel.spirit.connector.tas.OirUserConfigurationType;
import com.bytel.spirit.connector.tas.OperatorBarringProgramType;
import com.bytel.spirit.connector.tas.OperatorControlledOutgoingBarringPrograms.OcobpOperatorConfiguration;
import com.bytel.spirit.connector.tas.OperatorDiversionBarringProgramType;
import com.bytel.spirit.connector.tas.Provisioning;
import com.bytel.spirit.connector.tas.PublicId1;
import com.bytel.spirit.connector.tas.SessionControl;

/**
 * Implementation of the TAS connector.
 *
 * @author lchanyip
 * @version ($Revision: 26355 $ $Date: 2019-09-11 16:43:52 +0200 (mer. 11 sept. 2019) $)
 */
public class TasConnector extends AbstractConnector implements ITasConnector
{
  /**
   * Defines all parameters from config file.
   *
   * @author lchanyip
   * @version ($Revision: 26355 $ $Date: 2019-09-11 16:43:52 +0200 (mer. 11 sept. 2019) $)
   */
  enum ParameterName
  {
    /**
     * The URL parameter.
     */
    URL,

    /**
     * Session control service url
     */
    SESSION_SERVICE,

    /**
     * Provisioning service url
     */
    PROV_SERVICE,

    /**
     * User used for the login operation.
     */
    LOGIN_USER,

    /**
     * Password used for the login operation.
     */
    LOGIN_PWD,

    /**
     * GET MOTYPE
     */
    GET_MOTYPE,

    /**
     *
     */
    GET_MOID_SIPDOMAIN
  }

  /**
   *
   */
  private static final String AUDIO_MEDIA = "audio"; //$NON-NLS-1$

  /**
   *
   */
  private static final String SEQUENCEID = "SEQUENCEID"; //$NON-NLS-1$

  /**
   *
   */
  private static final String SESSIONID = "SESSIONID"; //$NON-NLS-1$

  /**
   *
   */
  private static final String DEFAULT_SEPARATOR = ":"; //$NON-NLS-1$

  /**
   *
   */
  private static final String OBOPRE_PREFIX = "OBOPRE"; //$NON-NLS-1$

  /**
   *
   */
  private static final String OBOPRI_PREFIX = "OBOPRI"; //$NON-NLS-1$

  /**
   *
   */
  private static final String OBSSM_PREFIX = "OBSSM"; //$NON-NLS-1$

  /**
   *
   */
  private static final String OSB3_PREFIX = "OSB3"; //$NON-NLS-1$

  /**
   *
   */
  private static final String OBO2_PREFIX = "OBO2"; //$NON-NLS-1$

  /**
   *
   */
  private static final String OBO1_PREFIX = "OBO1"; //$NON-NLS-1$

  /**
  *
  */
  private static final String OBI1_PREFIX = "OBI1"; //$NON-NLS-1$

  /**
   *
   */
  private static final String OBI2_PREFIX = "OBI2"; //$NON-NLS-1$

  /**
   *
   */
  private static final String CAI3G_NS_PREFIX = "cai3g"; //$NON-NLS-1$

  /**
   *
   */
  private static final String CAI3G_NS = "http://schemas.ericsson.com/cai3g1.2/"; //$NON-NLS-1$

  /**
   *
   */
  private static final String DEFAULT_TRANSACTIONID_VALUE = "1"; //$NON-NLS-1$

  /**
   * Parameters read from configuration.
   */
  private final Map<ParameterName, String> _parameters = new HashMap<ParameterName, String>(0);

  /**
   * Sessions control's interface
   */
  private SessionControl _sessionControl;
  /**
   * Provisioning interface
   */
  private Provisioning _provisioning;

  /**
   * User used for the login operation.
   */
  private String _userLogin;
  /**
   * Password used for the login operation.
   */
  private String _userPwd;

  /**
   * The sequenceId must be based on the baseSequenceId and incremented for each request in the session. In the first
   * request after login, the sequenceId must be greater than the baseSequenceId received from the node.
   */
  private ThreadLocal<Integer> _sequenceId = new ThreadLocal<Integer>();

  @Override
  public void clean() throws RavelException
  {
    //nothing to do
  }

  @Override
  public ConnectorResponse<JsonGetResponse, GenericError<Integer>> get(Tracabilite tracabilite_p, String sessionId_p, String msisdn_p) throws RavelException
  {
    String methodName = "get"; //$NON-NLS-1$

    try
    {
      PublicId1 publicId = new PublicId1("sip:" + MSISDNTools.convert(MsisdnFormat.INTERNATIONAL_PLUS_PREFIXED, msisdn_p) + _parameters.get(ParameterName.GET_MOID_SIPDOMAIN)); //$NON-NLS-1$
      DOMResult res = MarshallTools.marshall(ObjectFactory.class, publicId);
      org.w3c.dom.Element elt = ((org.w3c.dom.Document) res.getNode()).getDocumentElement();
      AnyMOIdType moId = new AnyMOIdType();
      moId.getAnies().add(elt);

      MOAttributes moAttributes = null;
      javax.xml.ws.Holder<AnySequenceType> extension = new Holder<>();

      javax.xml.ws.Holder<java.util.List<AnyMOIdType>> moIdOut = new Holder<>();
      javax.xml.ws.Holder<GetResponseMOAttributesType> moAttributesOut = new Holder<>();

      //increment the seq id
      _sequenceId.set(_sequenceId.get() + 1);

      addSoapHeadersToProvisioning(_sequenceId.get(), sessionId_p);

      SpiritLogEvent spiritLogEvent = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, MessageFormat.format(Messages.getString("TasConnector.callingservice"), methodName)); //$NON-NLS-1$
      spiritLogEvent.addField(SESSIONID, sessionId_p, false);
      spiritLogEvent.addField(SEQUENCEID, String.valueOf(_sequenceId.get().intValue()), false);
      spiritLogEvent.addField("MSISDN", msisdn_p, false); //$NON-NLS-1$
      RavelLogger.log(spiritLogEvent);

      _provisioning.get(_parameters.get(ParameterName.GET_MOTYPE), moId, moAttributes, extension, moIdOut, moAttributesOut);

      //here, call succeeded !

      GetResponseMOAttributesType getResponseMOAttributesType = moAttributesOut.value;
      if (getResponseMOAttributesType != null)
      {
        // log response
        try
        {
          RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, "get", "Response", GsonTools.getIso8601Ms().toJson(getResponseMOAttributesType), LogEventName.REPONSE_RECUE)); //$NON-NLS-1$
        }
        catch (Exception exception)
        {
          RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, "get", "Response", "(Response convertion to Json failed)", LogEventName.REPONSE_RECUE)); //$NON-NLS-1$ //$NON-NLS-2$
        }
        Services services = readResponseMOAttributes(getResponseMOAttributesType);

        JsonGetResponse jsonGetResponse = new JsonGetResponse();
        jsonGetResponse.setRetourTechnique(getRetourTechniqueOK());
        jsonGetResponse.setServices(services);

        return new ConnectorResponse<JsonGetResponse, GenericError<Integer>>(jsonGetResponse, null);
      }

      return new ConnectorResponse<JsonGetResponse, GenericError<Integer>>(null, new GenericError<Integer>(500, Messages.getString("TasConnector.GetResponseMOAttributesExpected"))); //$NON-NLS-1$
    }
    catch (JAXBException exception)
    {
      throwTechnicalException(exception, tracabilite_p, methodName);
    }
    catch (Cai3GFault_Exception exception)
    {
      if ((exception.getFaultInfo().getFaultcode().intValue() == 3002) || (exception.getFaultInfo().getFaultcode().intValue() == 4006))
      {
        //<faultcode>=3002 (abonné inexistant sur HSS donc a foriori sur TAS)
        //<faultcode>= 4006 (abonné existant sur HSS mais données TAS absentes)
        JsonGetResponse jsonGetResponse = new JsonGetResponse();
        jsonGetResponse.setRetourTechnique(getRetourTechniqueOK());
        jsonGetResponse.setServices(new Services(StringConstants.EMPTY_STRING));
        return new ConnectorResponse<JsonGetResponse, GenericError<Integer>>(jsonGetResponse, null);
      }

      throwTechnicalException(exception, tracabilite_p, methodName);
    }

    return null;
  }

  @Override
  public String getConfigParameter(String arg0_p, String arg1_p)
  {
    // TODO Auto-generated method stub
    return null;
  }

  @Override
  public void loadConnectorConfiguration(Connector connector_p) throws RavelException
  {
    // Read parameters.
    _name = connector_p.getName();
    _enabled = connector_p.isEnabled();
    for (Param parameter : connector_p.getParam())
    {
      ParameterName parameterName = ParameterName.valueOf(parameter.getName().toUpperCase());
      if (parameterName != null)
      {
        _parameters.put(parameterName, parameter.getValue());
      }
    }

    // Check parameters
    Set<ParameterName> parametersKeys = _parameters.keySet();

    if (!parametersKeys.contains(ParameterName.URL))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(Messages.getString("TasConnector.MissingParameter"), _name, ParameterName.URL.toString())); //$NON-NLS-1$
    }
    if (!parametersKeys.contains(ParameterName.SESSION_SERVICE))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(Messages.getString("TasConnector.MissingParameter"), _name, ParameterName.SESSION_SERVICE.toString())); //$NON-NLS-1$
    }
    if (!parametersKeys.contains(ParameterName.PROV_SERVICE))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(Messages.getString("TasConnector.MissingParameter"), _name, ParameterName.PROV_SERVICE.toString())); //$NON-NLS-1$
    }
    if (!parametersKeys.contains(ParameterName.LOGIN_USER))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(Messages.getString("TasConnector.MissingParameter"), _name, ParameterName.LOGIN_USER.toString())); //$NON-NLS-1$
    }
    if (!parametersKeys.contains(ParameterName.LOGIN_PWD))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(Messages.getString("TasConnector.MissingParameter"), _name, ParameterName.LOGIN_PWD.toString())); //$NON-NLS-1$
    }
    if (!parametersKeys.contains(ParameterName.GET_MOTYPE))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(Messages.getString("TasConnector.MissingParameter"), _name, ParameterName.GET_MOTYPE.toString())); //$NON-NLS-1$
    }

    if (!parametersKeys.contains(ParameterName.GET_MOID_SIPDOMAIN))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(Messages.getString("TasConnector.MissingParameter"), _name, ParameterName.GET_MOID_SIPDOMAIN.toString())); //$NON-NLS-1$
    }

    _userLogin = _parameters.get(ParameterName.LOGIN_USER);
    try
    {
      _userPwd = PasswordDecrypter.decrypt(_parameters.get(ParameterName.LOGIN_PWD));
    }
    catch (Exception ex)
    {
      throw new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.CNCTOR_00010, MessageFormat.format(Messages.getString("TasConnector.INITIALIZE_ERROR"), ex.getMessage())); //$NON-NLS-1$
    }

    String url_param = _parameters.get(ParameterName.URL);
    try
    {
      new URL(url_param);
    }
    catch (MalformedURLException exception)
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00021, MessageFormat.format(Messages.getString("TasConnector.InvalidURL"), url_param, _name)); //$NON-NLS-1$
    }

    _sessionControl = ServiceBuilder.buildService(SessionControl.class, url_param, _parameters.get(ParameterName.SESSION_SERVICE));
    _provisioning = ServiceBuilder.buildService(Provisioning.class, url_param, _parameters.get(ParameterName.PROV_SERVICE));

    //Use of ((BindingProvider)proxy).getRequestContext() - per JAX-WS spec, the request context is PER INSTANCE.
    //Thus, anything set there will affect requests on other threads.
    //Set the "thread.local.request.context" so that future calls to getRequestContext() will use a thread local request context.
    //That allows the request context to be threadsafe.
    ((BindingProvider) _sessionControl).getRequestContext().put("thread.local.request.context", "true"); //$NON-NLS-1$ //$NON-NLS-2$
    ((BindingProvider) _provisioning).getRequestContext().put("thread.local.request.context", "true"); //$NON-NLS-1$ //$NON-NLS-2$
  }

  @Override
  public ConnectorResponse<String, GenericError<Integer>> login(Tracabilite tracabilite_p) throws RavelException
  {
    String methodName = "login"; //$NON-NLS-1$
    ConnectorResponse<String, GenericError<Integer>> result = null;

    javax.xml.ws.Holder<java.lang.String> sessionId = new Holder<>();
    javax.xml.ws.Holder<java.math.BigInteger> baseSequenceId = new Holder<>();

    try
    {
      SpiritLogEvent spiritLogEvent = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, MessageFormat.format(Messages.getString("TasConnector.callingservice"), methodName)); //$NON-NLS-1$
      RavelLogger.log(spiritLogEvent);

      _sessionControl.login(_userLogin, _userPwd, sessionId, baseSequenceId);

      int baseSeqId = baseSequenceId.value.intValue();

      /*The sequenceId must be based on the baseSequenceId and incremented for each request in
       * the session. In the first request after login, the sequenceId must be greater than the
       * baseSequenceId received from the node.*/
      _sequenceId.set(baseSeqId);

      SpiritLogEvent sysLogEvent = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, MessageFormat.format(Messages.getString("TasConnector.PFSResponseReceived"), methodName)); //$NON-NLS-1$
      sysLogEvent.addField(SESSIONID, sessionId.value, false);
      sysLogEvent.addField(SEQUENCEID, String.valueOf(baseSeqId), false);
      RavelLogger.log(sysLogEvent);

      result = new ConnectorResponse<String, GenericError<Integer>>(sessionId.value, null);
    }
    catch (Cai3GFault_Exception exception)
    {
      throwTechnicalException(exception, tracabilite_p, methodName);
    }
    return result;
  }

  @Override
  public ConnectorResponse<String, GenericError<Integer>> logout(Tracabilite tracabilite_p, String sessionId_p) throws RavelException
  {
    String methodName = "logout"; //$NON-NLS-1$

    try
    {
      addSoapHeadersToSessionControl(sessionId_p);

      SpiritLogEvent sysLogEvent = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, MessageFormat.format(Messages.getString("TasConnector.callingservice"), methodName)); //$NON-NLS-1$
      sysLogEvent.addField(SESSIONID, sessionId_p, false);
      RavelLogger.log(sysLogEvent);

      _sessionControl.logout(sessionId_p);

      return new ConnectorResponse<String, GenericError<Integer>>(sessionId_p, null);
    }
    catch (Cai3GFault_Exception exception)
    {
      throwTechnicalException(exception, tracabilite_p, methodName);
    }
    catch (JAXBException exception)
    {
      throwTechnicalException(exception, tracabilite_p, methodName);
    }
    return null;
  }

  @Override
  public void onConnectorsLoaded() throws RavelException
  {
    // TODO Auto-generated method stub

  }

  @Override
  public void setEnabled(boolean arg0_p)
  {
    // TODO Auto-generated method stub

  }

  /**
   * @param sequenceId_p
   *          the sequenceId to set
   */
  public void setSequenceId(int sequenceId_p)
  {
    _sequenceId.set(Integer.valueOf(sequenceId_p));
  }

  /**
   * Add soap headers to the provisioning interface.
   *
   * @param sequenceId_p
   *          sequence ID value for the SequenceId header
   * @param sessionId_p
   *          session ID value for the SessionId header
   * @throws JAXBException
   *           if unexpected error
   */
  private void addSoapHeadersToProvisioning(int sequenceId_p, String sessionId_p) throws JAXBException
  {
    List<Header> headers = new ArrayList<Header>();

    Header sequenceIdHeader = new Header(new QName(CAI3G_NS, "SequenceId", CAI3G_NS_PREFIX), Integer.toString(sequenceId_p), new JAXBDataBinding(String.class)); //$NON-NLS-1$
    headers.add(sequenceIdHeader);

    Header transactionIdHeader = new Header(new QName(CAI3G_NS, "TransactionId", CAI3G_NS_PREFIX), DEFAULT_TRANSACTIONID_VALUE, new JAXBDataBinding(String.class)); //$NON-NLS-1$
    headers.add(transactionIdHeader);

    Header sessionIdHeader = new Header(new QName(CAI3G_NS, "SessionId", CAI3G_NS_PREFIX), sessionId_p, new JAXBDataBinding(String.class)); //$NON-NLS-1$
    headers.add(sessionIdHeader);

    ((BindingProvider) _provisioning).getRequestContext().put(Header.HEADER_LIST, headers);
  }

  /**
   * Add soap headers to the SessionControl interface.
   *
   * @param sessionId_p
   *          session ID value for the SessionId header
   * @throws JAXBException
   *           if unexpected error
   */
  private void addSoapHeadersToSessionControl(String sessionId_p) throws JAXBException
  {
    List<Header> headers = new ArrayList<Header>();

    Header sessionIdHeader = new Header(new QName(CAI3G_NS, "SessionId", CAI3G_NS_PREFIX), sessionId_p, new JAXBDataBinding(String.class)); //$NON-NLS-1$
    headers.add(sessionIdHeader);

    ((BindingProvider) _sessionControl).getRequestContext().put(Header.HEADER_LIST, headers);
  }

  /**
   * Concatenate a list of media into a string.
   *
   * @param medias_p
   *          list to concatenate
   * @return result string
   */
  private String concatListOfMedia(List<String> medias_p)
  {
    StringBuilder liste = new StringBuilder();
    if (medias_p != null)
    {
      for (String media : medias_p)
      {
        if (liste.length() == 0)
        {
          liste.append(media);
        }
        else
        {
          liste.append(DEFAULT_SEPARATOR);
          liste.append(media);
        }
      }
    }
    return liste.toString();
  }

  /**
   * Gets the NoReplyTimer property.
   *
   * @param cdivActionsType_p
   *          object to read
   *
   * @return an integer or null if the property does not exist.
   */
  private Integer getNoReplyTimer(CdivActionsType cdivActionsType_p)
  {
    if ((cdivActionsType_p != null) && (cdivActionsType_p.getCdivActionOptions() != null))
    {
      CdivActionOptions cdivActionOptions = cdivActionsType_p.getCdivActionOptions().getValue();
      return cdivActionOptions.getNoReplyTimer();
    }
    return null;
  }

  /**
   * Gets the ForwardTo property.
   *
   * @param cdivActionsType_p
   *          a CdivActionsType object
   *
   * @return a msisdn or empty string if the property does not exist.
   */
  private String getNumRenvoi(CdivActionsType cdivActionsType_p)
  {
    if ((cdivActionsType_p != null) && (cdivActionsType_p.getForwardTo() != null))
    {
      String target = cdivActionsType_p.getForwardTo().getTarget();
      if (target.startsWith("tel:")) //$NON-NLS-1$
      {
        return target.substring(4);
      }
      return target;
    }

    return StringConstants.EMPTY_STRING;
  }

  /**
   * Instantiate a RetourTechnique(OK) object.
   *
   * @return a RetourTechnique object
   */
  private RetourTechnique getRetourTechniqueOK()
  {
    RetourTechnique retour = new RetourTechnique();
    retour.setCodeRetour(StringConstants.OK);

    return retour;
  }

  /**
   * Parse ICB types
   *
   * @param icbOperatorConfigurationType_p
   *          object to parse
   * @return a string containing a list of ICB types (for ex. "OBO1:OBO2:OBOPRE:OBSSM:OBOPRI:OSB3") or empty string if
   *         no ICB type found.
   */
  private String getTypesICB(IcbOperatorConfigurationType icbOperatorConfigurationType_p)
  {
    StringBuilder listeTYPES_ICB = new StringBuilder();

    if (icbOperatorConfigurationType_p.getIcbRuleset() != null)
    {
      IcbRulesetType icbRulesetType = icbOperatorConfigurationType_p.getIcbRuleset().getValue();
      for (IcbRuleType icbRuleType : icbRulesetType.getIcbRules())
      {
        String categorie = mapICBCategory(icbRuleType);
        if ((categorie != null) && !listeTYPES_ICB.toString().contains(categorie))
        {
          if (listeTYPES_ICB.length() == 0)
          {
            listeTYPES_ICB.append(categorie);
          }
          else
          {
            listeTYPES_ICB.append(DEFAULT_SEPARATOR);
            listeTYPES_ICB.append(categorie);
          }
        }
      }
    }

    return listeTYPES_ICB.toString();
  }

  /**
   * Parse OperatorBarringProgramType
   *
   * @param operatorBarringProgramType_p
   *          object to parse
   * @return a string containing a list of OCOBP types (for ex. "OBO1:OBO2:OBOPRE:OBSSM:OBOPRI:OSB3") or empty string if
   *         no OCOBP types found.
   */
  private String getTypesOCOBP(OperatorBarringProgramType operatorBarringProgramType_p)
  {
    StringBuilder listeTYPES_OCOBP = new StringBuilder();
    if (operatorBarringProgramType_p.getCategoryNames() != null)
    {
      for (String op : operatorBarringProgramType_p.getCategoryNames())
      {
        String categorie = mapOCOBPCategory(op);
        if ((categorie != null) && !listeTYPES_OCOBP.toString().contains(categorie))
        {
          if (listeTYPES_OCOBP.length() == 0)
          {
            listeTYPES_OCOBP.append(categorie);
          }
          else
          {
            listeTYPES_OCOBP.append(DEFAULT_SEPARATOR);
            listeTYPES_OCOBP.append(categorie);
          }
        }
      }
    }

    return listeTYPES_OCOBP.toString();
  }

  /**
   * Parse OperatorDiversionBarringProgramType
   *
   * @param operatorDiversionBarringProgramType_p
   *          object to parse
   * @return a string containing a list of OCOBP types (for ex. "OBO1:OBO2:OBOPRE:OBSSM:OBOPRI:OSB3") or empty string if
   *         no OCOBP types found.
   */
  private String getTypesOCOBP2(OperatorDiversionBarringProgramType operatorDiversionBarringProgramType_p)
  {
    StringBuilder listeTYPES_OCOBP = new StringBuilder();
    if (operatorDiversionBarringProgramType_p.getCategoryNames() != null)
    {
      for (String op : operatorDiversionBarringProgramType_p.getCategoryNames())
      {
        String categorie = mapOCOBPCategory(op);
        if ((categorie != null) && !listeTYPES_OCOBP.toString().contains(categorie))
        {
          if (listeTYPES_OCOBP.length() == 0)
          {
            listeTYPES_OCOBP.append(categorie);
          }
          else
          {
            listeTYPES_OCOBP.append(DEFAULT_SEPARATOR);
            listeTYPES_OCOBP.append(categorie);
          }
        }
      }
    }

    return listeTYPES_OCOBP.toString();
  }

  /**
   * ICB category mapping function
   *
   * @param icbRuleType_p
   *          category rule received from the tas
   * @return the targeted ICB
   */
  private String mapICBCategory(IcbRuleType icbRuleType_p)
  {
    if ((icbRuleType_p.getCbActions() != null) && (icbRuleType_p.getCbActions().isAllow() == false))
    {
      if (icbRuleType_p.getIcbConditions() == null)
      {
        return OBI1_PREFIX;
      }

      IcbConditionsType icbConditionsType = icbRuleType_p.getIcbConditions().getValue();
      if ((icbConditionsType.isRoaming() != null))
      {
        if (icbConditionsType.isRoaming().booleanValue())
        {
          return OBI2_PREFIX;
        }

        //OBI1 si <mc:roaming>false</mc:roaming>
        return OBI1_PREFIX;
      }

      //OBI1 si pas de <mc:roaming> du tout
      return OBI1_PREFIX;
    }

    return null;
  }

  /**
   * OCOBP category mapping function
   *
   * @param categoryName_p
   *          category name received from the tas
   * @return the targeted category
   */
  private String mapOCOBPCategory(String categoryName_p)
  {
    /*<mc:category-name>Kiosque</mc:category-name>
    <mc:category-name>GP1</mc:category-name>
    <mc:category-name>GP2</mc:category-name>
    <mc:category-name>OBO1 GP</mc:category-name>
    <mc:category-name>OBOPRI1 GP</mc:category-name>
    <mc:category-name>OBOPRI2 GP</mc:category-name>
    <mc:category-name>OBOPRI3 GP</mc:category-name>
    <mc:category-name>OBOPRI4 GP</mc:category-name>
    <mc:category-name>OBOPRE GP</mc:category-name>
    <mc:category-name>OBO2 GP</mc:category-name>*/

    if (categoryName_p.startsWith(OBO1_PREFIX))
    {
      return OBO1_PREFIX;
    }

    if (categoryName_p.startsWith(OBO2_PREFIX))
    {
      return OBO2_PREFIX;
    }

    if (categoryName_p.startsWith(OSB3_PREFIX))
    {
      return OSB3_PREFIX;
    }

    if (categoryName_p.startsWith(OBSSM_PREFIX))
    {
      return OBSSM_PREFIX;
    }

    if (categoryName_p.startsWith(OBOPRI_PREFIX))
    {
      return OBOPRI_PREFIX;
    }

    if (categoryName_p.startsWith(OBOPRE_PREFIX))
    {
      return OBOPRE_PREFIX;
    }

    return null;
  }

  /**
   * Parse response's MO Attributes
   *
   * @param getResponseMOAttributesType_p
   *          object to parse
   * @return a Services object
   */
  private Services readResponseMOAttributes(GetResponseMOAttributesType getResponseMOAttributesType_p)
  {
    Services services = new Services(Consts.INACTIF.toString());

    JAXBElement<? extends AbstractGetAttributeType> getMODefinition = getResponseMOAttributesType_p.getGetMODefinition();
    if (getMODefinition != null)
    {
      GetResponseMMTel getResponseMMTel = (GetResponseMMTel) getMODefinition.getValue();
      if (getResponseMMTel != null)
      {
        //ST_TAS_CAW
        if (getResponseMMTel.getCommunicationWaiting() != null)
        {
          /*<mc:communication-waiting>
            <mc:cw-operator-configuration>
              <mc:activated>true</mc:activated>
            </mc:cw-operator-configuration>
            <mc:cw-user-configuration>
              <mc:active>true</mc:active>
            </mc:cw-user-configuration>
          </mc:communication-waiting>*/
          if ((getResponseMMTel.getCommunicationWaiting().getCwOperatorConfiguration() != null) && (getResponseMMTel.getCommunicationWaiting().getCwUserConfiguration() != null))
          {
            CwOperatorConfiguration cwOperatorConfiguration = getResponseMMTel.getCommunicationWaiting().getCwOperatorConfiguration().getValue();
            CwUserConfiguration cwUserConfiguration = getResponseMMTel.getCommunicationWaiting().getCwUserConfiguration().getValue();
            if ((cwOperatorConfiguration.getActivated() != null) && (cwOperatorConfiguration.getActivated() == ActivatedEnumType.TRUE) && (cwUserConfiguration.isActive() != null) && (cwUserConfiguration.isActive().booleanValue() == true))
            {
              services.getStTasCaw().setEtat(Consts.ACTIF.toString());
            }
          }
        }

        //ST_TAS_CLIR
        if (getResponseMMTel.getOriginatingIdentityPresentationRestriction() != null)
        {
          /*<mc:originating-identity-presentation-restriction>
          <mc:oir-operator-configuration>
            <mc:activated>true</mc:activated>
            <mc:mode>temporary</mc:mode>
            <mc:restriction>all-private-information</mc:restriction>
          </mc:oir-operator-configuration>*/
          if (getResponseMMTel.getOriginatingIdentityPresentationRestriction().getOirOperatorConfiguration() != null)
          {
            OirOperatorConfigurationType oirOperatorConfigurationType = getResponseMMTel.getOriginatingIdentityPresentationRestriction().getOirOperatorConfiguration().getValue();
            if ((oirOperatorConfigurationType.getActivated() != null) && (oirOperatorConfigurationType.getActivated() == ActivatedEnumType.TRUE))
            {
              services.getStTasClir().setEtat(Consts.ACTIF.toString());
            }
          }

          if (getResponseMMTel.getOriginatingIdentityPresentationRestriction().getOirUserConfiguration() != null)
          {
            OirUserConfigurationType oirUserConfigurationType = getResponseMMTel.getOriginatingIdentityPresentationRestriction().getOirUserConfiguration().getValue();
            if (oirUserConfigurationType.getDefaultBehaviour() != null)
            {
              services.getStTasClir().setDefaultBehaviour(oirUserConfigurationType.getDefaultBehaviour().value());
            }
          }
        }

        //ST_TAS_CLIP
        if (getResponseMMTel.getOriginatingIdentityPresentation() != null)
        {
          /*<mc:originating-identity-presentation>
          <mc:oip-operator-configuration>
            <mc:activated>true</mc:activated>
            <mc:restriction-override>override-not-active</mc:restriction-override>
          </mc:oip-operator-configuration>
          <mc:oip-user-configuration>
            <mc:active>true</mc:active>
          </mc:oip-user-configuration>
          </mc:originating-identity-presentation>*/
          if ((getResponseMMTel.getOriginatingIdentityPresentation().getOipOperatorConfiguration() != null) && (getResponseMMTel.getOriginatingIdentityPresentation().getOipUserConfiguration() != null))
          {
            OipOperatorConfigurationType oipOperatorConfigurationType = getResponseMMTel.getOriginatingIdentityPresentation().getOipOperatorConfiguration().getValue();
            OipUserConfigurationType oipUserConfigurationType = getResponseMMTel.getOriginatingIdentityPresentation().getOipUserConfiguration().getValue();
            if ((oipOperatorConfigurationType.getActivated() != null) && (oipOperatorConfigurationType.getActivated() == ActivatedEnumType.TRUE) && (oipUserConfigurationType.isActive() != null) && (oipUserConfigurationType.isActive().booleanValue() == true))
            {
              services.getStTasClip().setEtat(Consts.ACTIF.toString());
            }

            if (oipOperatorConfigurationType.getRestrictionOverride() != null)
            {
              services.getStTasClip().setRestrictionOverride(oipOperatorConfigurationType.getRestrictionOverride().value());
            }
          }
        }

        if ((getResponseMMTel.getCommunicationDiversion() != null) && (getResponseMMTel.getCommunicationDiversion().getCdivUserConfiguration() != null))
        {
          CdivUserConfigurationType cdivUserConfigurationType = getResponseMMTel.getCommunicationDiversion().getCdivUserConfiguration().getValue();
          if (cdivUserConfigurationType.getCdivRuleset() != null)
          {
            CdivRulesetType cdivRulesetType = cdivUserConfigurationType.getCdivRuleset().getValue();
            if (cdivRulesetType.getCdivRules() != null)
            {
              for (CdivRuleType cdivRuleType : cdivRulesetType.getCdivRules())
              {
                if (cdivRuleType.getCdivConditions() != null)
                {
                  CdivConditionsType cdivConditionsType = cdivRuleType.getCdivConditions().getValue();
                  if (cdivConditionsType.getCdivCallState() != null)
                  {
                    switch (cdivConditionsType.getCdivCallState())
                    {
                      case BUSY:
                        //ST_TAS_CFB
                        services.getStTasCfb().setMedia(concatListOfMedia(cdivConditionsType.getMedias()));
                        if (services.getStTasCfb().getMedia().contains(AUDIO_MEDIA))
                        {
                          services.getStTasCfb().setEtat(Consts.ACTIF.toString());
                        }
                        services.getStTasCfb().setNumRenvoi(getNumRenvoi(cdivRuleType.getCdivActions()));
                        break;

                      case NO_ANSWER:
                        //ST_TAS_CFNRY
                        services.getStTasCfnry().setMedia(concatListOfMedia(cdivConditionsType.getMedias()));
                        if (services.getStTasCfnry().getMedia().contains(AUDIO_MEDIA))
                        {
                          services.getStTasCfnry().setEtat(Consts.ACTIF.toString());
                        }
                        services.getStTasCfnry().setNumRenvoi(getNumRenvoi(cdivRuleType.getCdivActions()));

                        Integer noReplyTimer = getNoReplyTimer(cdivRuleType.getCdivActions());
                        if (noReplyTimer != null)
                        {
                          services.getStTasCfnry().setNoReplyTimer(String.valueOf(noReplyTimer));
                        }
                        break;

                      case NOT_REACHABLE:
                        //ST_TAS_CFNRC
                        services.getStTasCfnrc().setMedia(concatListOfMedia(cdivConditionsType.getMedias()));
                        if (services.getStTasCfnrc().getMedia().contains(AUDIO_MEDIA))
                        {
                          services.getStTasCfnrc().setEtat(Consts.ACTIF.toString());
                        }
                        services.getStTasCfnrc().setNumRenvoi(getNumRenvoi(cdivRuleType.getCdivActions()));
                        break;

                      default:
                        break;
                    }
                  }

                  if ((cdivConditionsType.isRuleDeactivated() != null) && (cdivConditionsType.isRuleDeactivated().booleanValue() == false))
                  {
                    //ST_TAS_CFU
                    services.getStTasCfu().setMedia(concatListOfMedia(cdivConditionsType.getMedias()));
                    if (services.getStTasCfu().getMedia().contains(AUDIO_MEDIA))
                    {
                      services.getStTasCfu().setEtat(Consts.ACTIF.toString());
                    }
                    services.getStTasCfu().setNumRenvoi(getNumRenvoi(cdivRuleType.getCdivActions()));
                  }
                }
              }
            }
          }
        }

        //ST_TAS_OCOBP
        if ((getResponseMMTel.getOperatorControlledOutgoingBarringPrograms() != null) && (getResponseMMTel.getOperatorControlledOutgoingBarringPrograms().getOcobpOperatorConfiguration() != null))
        {
          OcobpOperatorConfiguration ocobpOperatorConfiguration = getResponseMMTel.getOperatorControlledOutgoingBarringPrograms().getOcobpOperatorConfiguration();
          if (ocobpOperatorConfiguration.getActivated() == ActivatedEnumType.TRUE)
          {
            String listeTypesOCOBP = null;
            if (ocobpOperatorConfiguration.getOperatorBarringProgram() != null)
            {
              listeTypesOCOBP = getTypesOCOBP(ocobpOperatorConfiguration.getOperatorBarringProgram().getValue());
            }

            String listeTypesOCOBP2 = null;
            if (ocobpOperatorConfiguration.getOperatorDiversionBarringProgram() != null)
            {
              listeTypesOCOBP2 = getTypesOCOBP2(ocobpOperatorConfiguration.getOperatorDiversionBarringProgram().getValue());
            }

            String finalList = listeTypesOCOBP;
            if (StringTools.isNullOrEmpty(finalList))
            {
              finalList = listeTypesOCOBP2;
            }
            else
            {
              //finalList contient déjà quelque chose
              if (!StringTools.isNullOrEmpty(listeTypesOCOBP2))
              {
                finalList = finalList + DEFAULT_SEPARATOR + listeTypesOCOBP2;
              }
            }

            if (!StringTools.isNullOrEmpty(finalList))
            {
              services.getStTasOcobp().setEtat(Consts.ACTIF.toString());
              services.getStTasOcobp().setTypesOcobp(finalList);
            }
          }
        }

        //ST_TAS_ICB
        if ((getResponseMMTel.getIncomingCommunicationBarring() != null) && (getResponseMMTel.getIncomingCommunicationBarring().getIcbOperatorConfiguration() != null))
        {
          String listeTypesICB = getTypesICB(getResponseMMTel.getIncomingCommunicationBarring().getIcbOperatorConfiguration().getValue());
          if (!StringTools.isNullOrEmpty(listeTypesICB))
          {
            services.getStTasIcb().setEtat(Consts.ACTIF.toString());
            services.getStTasIcb().setTypesIcb(listeTypesICB);
          }
        }
      }
    }

    return services;
  }

  /**
   * Build a log entry and throws an {@link RavelException} for a technical problem.
   *
   * @param fault_p
   *          The {@link Cai3GFault_Exception} raised
   * @param tracabilite_p
   *          The current MsgIdISIS
   * @param method_p
   *          The method name in which the fault was raised.
   * @throws RavelException
   *           The technical exception.
   */
  private void throwTechnicalException(Cai3GFault_Exception fault_p, Tracabilite tracabilite_p, String method_p) throws RavelException
  {
    String message = MessageFormat.format(Messages.getString("TasConnector.TechnicalExceptionMessage"), method_p, fault_p.getFaultInfo().getFaultcode(), fault_p.getFaultInfo().getFaultreason().getReasonTexts().get(0)); //$NON-NLS-1$
    RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, message));
    RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, Messages.getString("TasConnector.ExceptionType") + fault_p.getClass().toString())); //$NON-NLS-1$
    throw new RavelException(ExceptionType.PFS_EXCEPTION, ErrorCode.CNCTOR_00010, message, ITasConnector.BEAN_ID, fault_p);
  }

  /**
   * Build a log entry and throws an {@link RavelException} for a technical problem.
   *
   * @param exception_p
   *          The {@link JAXBException} raised
   * @param tracabilite_p
   *          The current MsgIdISIS
   * @param method_p
   *          The method name in which the fault was raised.
   * @throws RavelException
   *           The technical exception.
   */
  private void throwTechnicalException(JAXBException exception_p, Tracabilite tracabilite_p, String method_p) throws RavelException
  {
    String message = MessageFormat.format(Messages.getString("TasConnector.TechnicalExceptionMessage"), method_p, exception_p.getErrorCode(), exception_p.getMessage()); //$NON-NLS-1$
    RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, message));
    RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, Messages.getString("TasConnector.ExceptionType") + exception_p.getClass().toString())); //$NON-NLS-1$
    throw new RavelException(ExceptionType.PFS_EXCEPTION, ErrorCode.CNCTOR_00010, message, ITasConnector.BEAN_ID, exception_p);
  }

}
