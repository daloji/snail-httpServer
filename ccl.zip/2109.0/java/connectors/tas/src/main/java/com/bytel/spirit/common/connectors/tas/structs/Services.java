/*******************************************************************************
 * $Id: Services.java 9142 2018-08-16 15:00:16Z jalmeida $
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.tas.structs;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 *
 * @author lchanyip
 * @version ($Revision: 9142 $ $Date: 2018-08-16 17:00:16 +0200 (jeu. 16 août 2018) $)
 */
public class Services implements Serializable
{
  /**
   * Generated UID
   */
  private static final long serialVersionUID = -2939362618491704222L;

  /**
   * ST_TAS_CLIR
   */
  @SerializedName("ST_TAS_CLIR")
  @Expose
  private StTasClir _stTasClir;

  /**
   * ST_TAS_CLIP
   */
  @SerializedName("ST_TAS_CLIP")
  @Expose
  private StTasClip _stTasClip;

  /**
   * ST_TAS_CAW
   */
  @SerializedName("ST_TAS_CAW")
  @Expose
  private StTasCaw _stTasCaw;

  /**
   * ST_TAS_CFB
   */
  @SerializedName("ST_TAS_CFB")
  @Expose
  private StTasCfb _stTasCfb;

  /**
   * ST_TAS_CFNRY
   */
  @SerializedName("ST_TAS_CFNRY")
  @Expose
  private StTasCfnry _stTasCfnry;

  /**
   * ST_TAS_CFNRC
   */
  @SerializedName("ST_TAS_CFNRC")
  @Expose
  private StTasCfnrc _stTasCfnrc;

  /**
   * ST_TAS_CFU
   */
  @SerializedName("ST_TAS_CFU")
  @Expose
  private StTasCfu _stTasCfu;

  /**
   * ST_TAS_OCOBP
   */
  @SerializedName("ST_TAS_OCOBP")
  @Expose
  private StTasOcobp _stTasOcobp;

  /**
   *
   */
  @SerializedName("ST_TAS_ICB")
  @Expose
  private StTasIcb _stTasIcb;

  /**
   * @param etat_p
   *
   */
  public Services(String etat_p)
  {
    _stTasClir = new StTasClir(etat_p);
    _stTasClip = new StTasClip(etat_p);
    _stTasCaw = new StTasCaw(etat_p);
    _stTasCfb = new StTasCfb(etat_p);
    _stTasCfnry = new StTasCfnry(etat_p);
    _stTasCfnrc = new StTasCfnrc(etat_p);
    _stTasCfu = new StTasCfu(etat_p);
    _stTasOcobp = new StTasOcobp(etat_p);
    _stTasIcb = new StTasIcb(etat_p);
  }

  /**
   * @return the stTasCaw
   */
  public StTasCaw getStTasCaw()
  {
    return _stTasCaw;
  }

  /**
   * @return the stTasCfb
   */
  public StTasCfb getStTasCfb()
  {
    return _stTasCfb;
  }

  /**
   * @return the stTasCfnrc
   */
  public StTasCfnrc getStTasCfnrc()
  {
    return _stTasCfnrc;
  }

  /**
   * @return the stTasCfnry
   */
  public StTasCfnry getStTasCfnry()
  {
    return _stTasCfnry;
  }

  /**
   * @return the stTasCfu
   */
  public StTasCfu getStTasCfu()
  {
    return _stTasCfu;
  }

  /**
   * @return the stTasClip
   */
  public StTasClip getStTasClip()
  {
    return _stTasClip;
  }

  /**
   * @return the stTasClir
   */
  public StTasClir getStTasClir()
  {
    return _stTasClir;
  }

  /**
   * @return the stTasIcb
   */
  public StTasIcb getStTasIcb()
  {
    return _stTasIcb;
  }

  /**
   * @return the stTasOcobp
   */
  public StTasOcobp getStTasOcobp()
  {
    return _stTasOcobp;
  }

  /**
   * @param stTasCaw_p
   *          the stTasCaw to set
   */
  public void setStTasCaw(StTasCaw stTasCaw_p)
  {
    _stTasCaw = stTasCaw_p;
  }

  /**
   * @param stTasCfb_p
   *          the stTasCfb to set
   */
  public void setStTasCfb(StTasCfb stTasCfb_p)
  {
    _stTasCfb = stTasCfb_p;
  }

  /**
   * @param stTasCfnrc_p
   *          the stTasCfnrc to set
   */
  public void setStTasCfnrc(StTasCfnrc stTasCfnrc_p)
  {
    _stTasCfnrc = stTasCfnrc_p;
  }

  /**
   * @param stTasCfnry_p
   *          the stTasCfnry to set
   */
  public void setStTasCfnry(StTasCfnry stTasCfnry_p)
  {
    _stTasCfnry = stTasCfnry_p;
  }

  /**
   * @param stTasCfu_p
   *          the stTasCfu to set
   */
  public void setStTasCfu(StTasCfu stTasCfu_p)
  {
    _stTasCfu = stTasCfu_p;
  }

  /**
   * @param stTasClip_p
   *          the stTasClip to set
   */
  public void setStTasClip(StTasClip stTasClip_p)
  {
    _stTasClip = stTasClip_p;
  }

  /**
   * @param stTasClir_p
   *          the stTasClir to set
   */
  public void setStTasClir(StTasClir stTasClir_p)
  {
    _stTasClir = stTasClir_p;
  }

  /**
   * @param stTasIcb_p
   *          the stTasIcb to set
   */
  public void setStTasIcb(StTasIcb stTasIcb_p)
  {
    _stTasIcb = stTasIcb_p;
  }

  /**
   * @param stTasOcobp_p
   *          the stTasOcobp to set
   */
  public void setStTasOcobp(StTasOcobp stTasOcobp_p)
  {
    _stTasOcobp = stTasOcobp_p;
  }
}
