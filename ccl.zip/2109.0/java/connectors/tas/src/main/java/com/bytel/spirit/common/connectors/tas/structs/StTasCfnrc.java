/*******************************************************************************
* $Id: StTasCfnrc.java 9142 2018-08-16 15:00:16Z jalmeida $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.tas.structs;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 *
 * @author lchanyip
 * @version ($Revision: 9142 $ $Date: 2018-08-16 17:00:16 +0200 (jeu. 16 août 2018) $)
 */
public class StTasCfnrc
{
  /**
   * Etat du service : ACTIF, INACTIF ou vide
   */
  @SerializedName("etat")
  @Expose
  private String _etat;

  /**
   *
   */
  @SerializedName("media")
  @Expose
  private String _media;

  /**
   *
   */
  @SerializedName("num_renvoi")
  @Expose
  private String _numRenvoi;

  /**
   *
   */
  public StTasCfnrc()
  {
    this(""); //$NON-NLS-1$
  }

  /**
   *
   * @param etat_p
   */
  public StTasCfnrc(String etat_p)
  {
    _etat = etat_p;
    _media = ""; //$NON-NLS-1$
    _numRenvoi = ""; //$NON-NLS-1$
  }

  /**
   * @return the etat
   */
  public String getEtat()
  {
    return _etat;
  }

  /**
   * @return the media
   */
  public String getMedia()
  {
    return _media;
  }

  /**
   * @return the numRenvoi
   */
  public String getNumRenvoi()
  {
    return _numRenvoi;
  }

  /**
   * @param etat_p
   *          the etat to set
   */
  public void setEtat(String etat_p)
  {
    _etat = etat_p;
  }

  /**
   * @param media_p
   *          the media to set
   */
  public void setMedia(String media_p)
  {
    _media = media_p;
  }

  /**
   * @param numRenvoi_p
   *          the numRenvoi to set
   */
  public void setNumRenvoi(String numRenvoi_p)
  {
    _numRenvoi = numRenvoi_p;
  }
}
