/*******************************************************************************
 * $Id: ITasConnector.java 9142 2018-08-16 15:00:16Z jalmeida $
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.tas;

import com.bytel.ravel.services.connector.IConnector;

/**
 * Interface for the TAS Connector.
 *
 * @author lchanyip
 * @version ($Revision: 9142 $ $Date: 2018-08-16 17:00:16 +0200 (jeu. 16 août 2018) $)
 */
public interface ITasConnector extends IConnector, ITas
{
  /**
   * The id to retrieve the connector.
   */
  public String BEAN_ID = "TasConnector"; //$NON-NLS-1$

}
