/*******************************************************************************
* $Id: TasConnectorTest.java 18001 2019-03-05 10:56:27Z kbettenc $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.connectors.tas;

import java.math.BigInteger;
import java.text.MessageFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.ws.Binding;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.EndpointReference;
import javax.xml.ws.Holder;

import org.easymock.EasyMock;
import org.easymock.EasyMockSupport;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.bytel.ravel.common.conf.generated.Param;
import com.bytel.ravel.common.encryption.DESKeyManager;
import com.bytel.ravel.common.encryption.PasswordDecrypter;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.services.conf.connector.generated.Connector;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.connector.GenericError;
import com.bytel.ravel.services.connector.tools.ServiceBuilder;
import com.bytel.spirit.common.connectors.tas.TasConnector.ParameterName;
import com.bytel.spirit.common.connectors.tas.structs.JsonGetResponse;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.connector.tas.AnyMOIdType;
import com.bytel.spirit.connector.tas.AnySequenceType;
import com.bytel.spirit.connector.tas.Cai3GFault_Exception;
import com.bytel.spirit.connector.tas.Get.MOAttributes;
import com.bytel.spirit.connector.tas.GetResponseMOAttributesType;
import com.bytel.spirit.connector.tas.Provisioning;
import com.bytel.spirit.connector.tas.SearchFiltersType;
import com.bytel.spirit.connector.tas.SessionControl;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author jalmeida
 * @version ($Revision: 18001 $ $Date: 2019-03-05 11:56:27 +0100 (mar. 05 mars 2019) $)
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({ TasConnector.class, TasConnectorTest.SessionControlMock.class, TasConnectorTest.ProvisioningMock.class, PasswordDecrypter.class, DESKeyManager.class, ServiceBuilder.class, Holder.class })
public class TasConnectorTest extends EasyMockSupport
{

  public class ProvisioningMock implements Provisioning, BindingProvider
  {

    @Override
    public void create(String moType_p, Holder<AnyMOIdType> moId_p, com.bytel.spirit.connector.tas.Create.MOAttributes moAttributes_p, Holder<AnySequenceType> extension_p, Holder<GetResponseMOAttributesType> moAttributes1_p) throws Cai3GFault_Exception
    {
      // TODO Auto-generated method stub

    }

    @Override
    public void delete(String moType_p, Holder<AnyMOIdType> moId_p, com.bytel.spirit.connector.tas.Delete.MOAttributes moAttributes_p, Holder<AnySequenceType> extension_p, Holder<GetResponseMOAttributesType> moAttributes1_p) throws Cai3GFault_Exception
    {
      // TODO Auto-generated method stub

    }

    @Override
    public void get(String moType_p, AnyMOIdType moId_p, MOAttributes moAttributes_p, Holder<AnySequenceType> extension_p, Holder<List<AnyMOIdType>> moId1_p, Holder<GetResponseMOAttributesType> moAttributes1_p) throws Cai3GFault_Exception
    {
      // TODO Auto-generated method stub

    }

    @Override
    public Binding getBinding()
    {
      // TODO Auto-generated method stub
      return null;
    }

    @Override
    public EndpointReference getEndpointReference()
    {
      // TODO Auto-generated method stub
      return null;
    }

    @Override
    public <T extends EndpointReference> T getEndpointReference(Class<T> clazz_p)
    {
      // TODO Auto-generated method stub
      return null;
    }

    @Override
    public Map<String, Object> getRequestContext()
    {
      // TODO Auto-generated method stub
      return null;
    }

    @Override
    public Map<String, Object> getResponseContext()
    {
      // TODO Auto-generated method stub
      return null;
    }

    @Override
    public void search(String moType_p, SearchFiltersType filters_p, Holder<AnySequenceType> extension_p, Holder<List<AnyMOIdType>> moId_p) throws Cai3GFault_Exception
    {
      // TODO Auto-generated method stub

    }

    @Override
    public void set(String moType_p, AnyMOIdType moId_p, com.bytel.spirit.connector.tas.Set.MOAttributes moAttributes_p, Holder<AnySequenceType> extension_p, Holder<GetResponseMOAttributesType> moAttributes1_p) throws Cai3GFault_Exception
    {
      // TODO Auto-generated method stub

    }

  }

  /**
   *
   * @author jalmeida
   * @version ($Revision: 18001 $ $Date: 2019-03-05 11:56:27 +0100 (mar. 05 mars 2019) $)
   */
  public class SessionControlMock implements SessionControl, BindingProvider
  {

    @Override
    public Binding getBinding()
    {
      // TODO Auto-generated method stub
      return null;
    }

    @Override
    public EndpointReference getEndpointReference()
    {
      // TODO Auto-generated method stub
      return null;
    }

    @Override
    public <T extends EndpointReference> T getEndpointReference(Class<T> clazz_p)
    {
      // TODO Auto-generated method stub
      return null;
    }

    @Override
    public Map<String, Object> getRequestContext()
    {
      // TODO Auto-generated method stub
      return null;
    }

    @Override
    public Map<String, Object> getResponseContext()
    {
      // TODO Auto-generated method stub
      return null;
    }

    @Override
    public void login(String userId_p, String pwd_p, Holder<String> sessionId_p, Holder<BigInteger> baseSequenceId_p) throws Cai3GFault_Exception
    {
      // TODO Auto-generated method stub

    }

    @Override
    public void logout(String sessionId_p) throws Cai3GFault_Exception
    {
      // TODO Auto-generated method stub

    }

  }

  /**
   * Connector to test
   */
  private TasConnector _connector;

  /**
   * Factory to generate beans
   */
  private PodamFactory _podam = new PodamFactoryImpl();

  /**
   *
   */
  @MockStrict
  SessionControlMock _sessionControlMock;

  /**
   *
   */
  @MockStrict
  ProvisioningMock _provisioningMock;

  /**
   *
   */
  @MockStrict
  ServiceBuilder _serviceBuilderMock;

  /**
   *
   */
  Holder<BigInteger> _holderMockBI;

  /**
   *
   */
  Holder<String> _holderMockS;

  /**
   *
   */
  Holder<AnySequenceType> _holderMockAst;

  /**
   *
   */
  Holder<List<AnyMOIdType>> _holderMockMoi;

  /**
   *
   */
  Holder<GetResponseMOAttributesType> _holderMockMoa;

  /**
   * Initialize before tests
   *
   * @throws Exception
   *           Thrown in case of error during switch in attributes of parent class
   */
  @Before
  public void beforeTest() throws Exception
  {

    PowerMock.resetAll();
    PowerMock.mockStaticNice(PasswordDecrypter.class);
    PowerMock.mockStaticNice(DESKeyManager.class);
    PowerMock.mockStaticStrict(SessionControlMock.class);
    PowerMock.mockStaticStrict(ProvisioningMock.class);
    PowerMock.mockStaticStrict(ServiceBuilder.class);
    PowerMock.mockStaticStrict(Holder.class);

    _podam.getStrategy().setMemoization(true);
    _connector = new TasConnector();

  }

  /**
   * Test method {@link NafConnector#loadConnectorConfiguration(Connector)} Expected : KO because of
   * MalformedURLException
   *
   * @throws Exception
   *           Thrown in case of error
   */
  @Test
  public void test_loadConnectorConfiguration_KO_001() throws Exception
  {
    final Connector connector = new Connector();
    addParam(connector, ParameterName.URL.name(), "url");
    addParam(connector, ParameterName.SESSION_SERVICE.name(), "SESSION_SERVICE");
    addParam(connector, ParameterName.PROV_SERVICE.name(), "PROV_SERVICE");
    addParam(connector, ParameterName.LOGIN_USER.name(), "LOGIN_USER");
    addParam(connector, ParameterName.LOGIN_PWD.name(), "LOGIN_PWD");
    addParam(connector, ParameterName.GET_MOTYPE.name(), "GET_MOTYPE");
    addParam(connector, ParameterName.GET_MOID_SIPDOMAIN.name(), "GET_MOID_SIPDOMAIN");
    // test
    try
    {
      _connector.loadConnectorConfiguration(connector);
    }
    catch (RavelException e)
    {
      Assert.assertEquals(ExceptionType.INVALID_CONFIGURATION, e.getExceptionType());
      Assert.assertEquals(ErrorCode.CNCTOR_00021, e.getErrorCode());
      Assert.assertEquals(MessageFormat.format(Messages.getString("TasConnector.InvalidURL"), "url", _connector.getName()), e.getMessage());
    }
  }

  /**
   * Test of get method with egneric error 500
   *
   * @throws RavelException
   * @throws Cai3GFault_Exception
   *
   */
  @Test
  public void testTas001() throws RavelException, Cai3GFault_Exception
  {
    Connector connectorCfg = new Connector();

    connectorCfg.setName("TasConnector"); //$NON-NLS-1$
    connectorCfg.setClazz("com.bytel.spirit.common.connectors.tas.TasConnector"); //$NON-NLS-1$
    connectorCfg.setType("client"); //$NON-NLS-1$
    connectorCfg.setEnabled(true);

    addParam(connectorCfg, "URL", "http://172.22.84.18:9999"); //$NON-NLS-1$//$NON-NLS-2$
    addParam(connectorCfg, "SESSION_SERVICE", "/axis2/services/CAI3G"); //$NON-NLS-1$//$NON-NLS-2$
    addParam(connectorCfg, "PROV_SERVICE", "/axis2/services/CAI3G"); //$NON-NLS-1$//$NON-NLS-2$
    addParam(connectorCfg, "LOGIN_USER", "user"); //$NON-NLS-1$//$NON-NLS-2$
    addParam(connectorCfg, "LOGIN_PWD", "pwd"); //$NON-NLS-1$//$NON-NLS-2$
    addParam(connectorCfg, "GET_MOTYPE", "MMTel@http://schemas.ericsson.com/mtas/mmtel/cai3g"); //$NON-NLS-1$ //$NON-NLS-2$
    addParam(connectorCfg, "GET_MOID_SIPDOMAIN", "@ims.mnc020.mcc208.3gppnetwork.org"); //$NON-NLS-1$ //$NON-NLS-2$

    ConnectorResponse<JsonGetResponse, GenericError<Integer>> result = new ConnectorResponse<JsonGetResponse, GenericError<Integer>>(null, new GenericError<Integer>(500, "TasConnector: invalid response, GetResponseMOAttributes expected not received.")); //$NON-NLS-1$

    EasyMock.expect(ServiceBuilder.buildService(SessionControl.class, "http://172.22.84.18:9999", "/axis2/services/CAI3G")).andReturn(_sessionControlMock); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(ServiceBuilder.buildService(Provisioning.class, "http://172.22.84.18:9999", "/axis2/services/CAI3G")).andReturn(_provisioningMock); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_sessionControlMock.getRequestContext()).andReturn(new HashMap<String, Object>());
    EasyMock.expect(_provisioningMock.getRequestContext()).andReturn(new HashMap<String, Object>()).times(2);

    _provisioningMock.get(EasyMock.eq("MMTel@http://schemas.ericsson.com/mtas/mmtel/cai3g"), EasyMock.anyObject(), EasyMock.isNull(), EasyMock.anyObject(), EasyMock.anyObject(), EasyMock.anyObject()); //$NON-NLS-1$

    _connector.setSequenceId(0);

    PowerMock.replayAll();
    _connector.loadConnectorConfiguration(connectorCfg);
    ConnectorResponse<JsonGetResponse, GenericError<Integer>> finalResult = _connector.get(new Tracabilite(), "", ""); //$NON-NLS-1$//$NON-NLS-2$
    PowerMock.verifyAll();

    Assert.assertEquals(result, finalResult);
  }

  /**
   * Test of get method with egneric error 500
   *
   * @throws Exception
   *
   */
  @Test
  public void testTas002() throws Exception
  {
    Connector connectorCfg = new Connector();

    connectorCfg.setName("TasConnector"); //$NON-NLS-1$
    connectorCfg.setClazz("com.bytel.spirit.common.connectors.tas.TasConnector"); //$NON-NLS-1$
    connectorCfg.setType("client"); //$NON-NLS-1$
    connectorCfg.setEnabled(true);

    addParam(connectorCfg, "URL", "http://172.22.84.18:9999"); //$NON-NLS-1$//$NON-NLS-2$
    addParam(connectorCfg, "SESSION_SERVICE", "/axis2/services/CAI3G"); //$NON-NLS-1$//$NON-NLS-2$
    addParam(connectorCfg, "PROV_SERVICE", "/axis2/services/CAI3G"); //$NON-NLS-1$//$NON-NLS-2$
    addParam(connectorCfg, "LOGIN_USER", "user"); //$NON-NLS-1$//$NON-NLS-2$
    addParam(connectorCfg, "LOGIN_PWD", "pwd"); //$NON-NLS-1$//$NON-NLS-2$
    addParam(connectorCfg, "GET_MOTYPE", "MMTel@http://schemas.ericsson.com/mtas/mmtel/cai3g"); //$NON-NLS-1$ //$NON-NLS-2$
    addParam(connectorCfg, "GET_MOID_SIPDOMAIN", "@ims.mnc020.mcc208.3gppnetwork.org"); //$NON-NLS-1$ //$NON-NLS-2$

    ConnectorResponse<JsonGetResponse, GenericError<Integer>> result = new ConnectorResponse<JsonGetResponse, GenericError<Integer>>(new JsonGetResponse(), null);

    EasyMock.expect(ServiceBuilder.buildService(SessionControl.class, "http://172.22.84.18:9999", "/axis2/services/CAI3G")).andReturn(_sessionControlMock); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(ServiceBuilder.buildService(Provisioning.class, "http://172.22.84.18:9999", "/axis2/services/CAI3G")).andReturn(_provisioningMock); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_sessionControlMock.getRequestContext()).andReturn(new HashMap<String, Object>());
    EasyMock.expect(_provisioningMock.getRequestContext()).andReturn(new HashMap<String, Object>()).times(2);

    _holderMockAst = PowerMock.createMock(Holder.class);
    _holderMockMoi = PowerMock.createMock(Holder.class);
    _holderMockMoa = PowerMock.createMock(Holder.class);

    _holderMockMoa.value = new GetResponseMOAttributesType();
    PowerMock.expectNew(Holder.class).andReturn(_holderMockAst);
    PowerMock.expectNew(Holder.class).andReturn(_holderMockMoi);
    PowerMock.expectNew(Holder.class).andReturn(_holderMockMoa);

    _provisioningMock.get(EasyMock.eq("MMTel@http://schemas.ericsson.com/mtas/mmtel/cai3g"), EasyMock.anyObject(), EasyMock.isNull(), EasyMock.anyObject(), EasyMock.anyObject(), EasyMock.anyObject()); //$NON-NLS-1$

    _connector.setSequenceId(0);

    PowerMock.replayAll();
    _connector.loadConnectorConfiguration(connectorCfg);
    ConnectorResponse<JsonGetResponse, GenericError<Integer>> finalResult = _connector.get(new Tracabilite(), "", ""); //$NON-NLS-1$//$NON-NLS-2$
    PowerMock.verifyAll();

    Assert.assertNotNull(finalResult._first);
    Assert.assertNull(finalResult._second);
  }

  /**
   * @throws Exception
   */
  @Test
  public void testTas003() throws Exception
  {
    Connector connectorCfg = new Connector();

    connectorCfg.setName("TasConnector"); //$NON-NLS-1$
    connectorCfg.setClazz("com.bytel.spirit.common.connectors.tas.TasConnector"); //$NON-NLS-1$
    connectorCfg.setType("client"); //$NON-NLS-1$
    connectorCfg.setEnabled(true);

    addParam(connectorCfg, "URL", "http://172.22.84.18:9999"); //$NON-NLS-1$//$NON-NLS-2$
    addParam(connectorCfg, "SESSION_SERVICE", "/axis2/services/CAI3G"); //$NON-NLS-1$//$NON-NLS-2$
    addParam(connectorCfg, "PROV_SERVICE", "/axis2/services/CAI3G"); //$NON-NLS-1$//$NON-NLS-2$
    addParam(connectorCfg, "LOGIN_USER", "user"); //$NON-NLS-1$//$NON-NLS-2$
    addParam(connectorCfg, "LOGIN_PWD", "pwd"); //$NON-NLS-1$//$NON-NLS-2$
    addParam(connectorCfg, "GET_MOTYPE", "MMTel@http://schemas.ericsson.com/mtas/mmtel/cai3g"); //$NON-NLS-1$ //$NON-NLS-2$
    addParam(connectorCfg, "GET_MOID_SIPDOMAIN", "@ims.mnc020.mcc208.3gppnetwork.org"); //$NON-NLS-1$ //$NON-NLS-2$

    ConnectorResponse<String, GenericError<Integer>> result = new ConnectorResponse<String, GenericError<Integer>>("", new GenericError<Integer>(1, "")); //$NON-NLS-1$//$NON-NLS-2$

    EasyMock.expect(ServiceBuilder.buildService(SessionControl.class, "http://172.22.84.18:9999", "/axis2/services/CAI3G")).andReturn(_sessionControlMock); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(ServiceBuilder.buildService(Provisioning.class, "http://172.22.84.18:9999", "/axis2/services/CAI3G")).andReturn(_provisioningMock); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_sessionControlMock.getRequestContext()).andReturn(new HashMap<String, Object>());
    EasyMock.expect(_provisioningMock.getRequestContext()).andReturn(new HashMap<String, Object>());

    _holderMockS = PowerMock.createMock(Holder.class);
    _holderMockBI = PowerMock.createMock(Holder.class);

    _holderMockBI.value = new BigInteger("0");
    PowerMock.expectNew(Holder.class).andReturn(_holderMockS);
    PowerMock.expectNew(Holder.class).andReturn(_holderMockBI);

    _sessionControlMock.login(EasyMock.eq("user"), EasyMock.isNull(), EasyMock.anyObject(), EasyMock.anyObject()); //$NON-NLS-1$

    PowerMock.replayAll();
    _connector.loadConnectorConfiguration(connectorCfg);
    ConnectorResponse<String, GenericError<Integer>> finalResult = _connector.login(new Tracabilite());
    PowerMock.verifyAll();

    Assert.assertTrue(true);
  }

  /**
   * @throws RavelException
   * @throws Cai3GFault_Exception
   */
  @Test
  public void testTas004() throws RavelException, Cai3GFault_Exception
  {
    Connector connectorCfg = new Connector();

    connectorCfg.setName("TasConnector"); //$NON-NLS-1$
    connectorCfg.setClazz("com.bytel.spirit.common.connectors.tas.TasConnector"); //$NON-NLS-1$
    connectorCfg.setType("client"); //$NON-NLS-1$
    connectorCfg.setEnabled(true);

    addParam(connectorCfg, "URL", "http://172.22.84.18:9999"); //$NON-NLS-1$//$NON-NLS-2$
    addParam(connectorCfg, "SESSION_SERVICE", "/axis2/services/CAI3G"); //$NON-NLS-1$//$NON-NLS-2$
    addParam(connectorCfg, "PROV_SERVICE", "/axis2/services/CAI3G"); //$NON-NLS-1$//$NON-NLS-2$
    addParam(connectorCfg, "LOGIN_USER", "user"); //$NON-NLS-1$//$NON-NLS-2$
    addParam(connectorCfg, "LOGIN_PWD", "pwd"); //$NON-NLS-1$//$NON-NLS-2$
    addParam(connectorCfg, "GET_MOTYPE", "MMTel@http://schemas.ericsson.com/mtas/mmtel/cai3g"); //$NON-NLS-1$ //$NON-NLS-2$
    addParam(connectorCfg, "GET_MOID_SIPDOMAIN", "@ims.mnc020.mcc208.3gppnetwork.org"); //$NON-NLS-1$ //$NON-NLS-2$

    ConnectorResponse<String, GenericError<Integer>> result = new ConnectorResponse<String, GenericError<Integer>>("sessionId", null);

    EasyMock.expect(ServiceBuilder.buildService(SessionControl.class, "http://172.22.84.18:9999", "/axis2/services/CAI3G")).andReturn(_sessionControlMock); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(ServiceBuilder.buildService(Provisioning.class, "http://172.22.84.18:9999", "/axis2/services/CAI3G")).andReturn(_provisioningMock); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(_sessionControlMock.getRequestContext()).andReturn(new HashMap<String, Object>()).times(2);
    EasyMock.expect(_provisioningMock.getRequestContext()).andReturn(new HashMap<String, Object>());

    _sessionControlMock.logout("sessionId"); //$NON-NLS-1$

    PowerMock.replayAll();
    _connector.loadConnectorConfiguration(connectorCfg);
    ConnectorResponse<String, GenericError<Integer>> finalResult = _connector.logout(new Tracabilite(), "sessionId");
    PowerMock.verifyAll();

    Assert.assertEquals(result, finalResult);
  }

  /**
   * @param connectorCfg
   *          the connector to fill
   * @param name
   *          the parameter name
   * @param value
   *          the parameter value
   */
  private void addParam(Connector connectorCfg, String name, String value)
  {
    Param p = new Param();
    p.setName(name);
    p.setValue(value);
    connectorCfg.getParam().add(p);
  }

}
