/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.odyl.oracle;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.tomcat.jdbc.pool.DataSource;
import org.easymock.EasyMock;
import org.easymock.EasyMockSupport;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockNice;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.bytel.ravel.common.conf.generated.Param;
import com.bytel.ravel.common.encryption.PasswordDecrypter;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.test.JUnitTools;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.services.conf.connector.generated.Connector;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.connectors.odyl.oracle.structs.OdylOracleRetour;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 * @author jpais
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({ PasswordDecrypter.class })
@PowerMockIgnore("javax.management.*")
public class OdylOracleConnectorTest extends EasyMockSupport
{
  /**
   * Connector to test
   */
  private OdylOracleConnector _connector = new OdylOracleConnector();

  /**
   * Factory to generate beans
   */
  private PodamFactory _podam = new PodamFactoryImpl();

  @MockNice
  DataSource _dataSource;

  @MockNice
  Connection _connection;

  @MockNice
  CallableStatement _callableStatement;

  /**
   * Code retour 1000
   *
   * @throws Exception
   */
  @Test
  public void consulterProfilTVTest_NOK_001() throws Exception
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    Integer srvId = 336582346;
    Integer nrmId = 582346424;

    // Setup statement mock
    _callableStatement.setInt(1, srvId);
    _callableStatement.setInt(2, nrmId);

    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.getInt(3)).andReturn(1000);

    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall(OdylOracleConnector.BDD_ODYL_PKG_SPIRIT_CONSULTER_PROFILETV)).andReturn(_callableStatement);
    PowerMock.replay(_connection);

    ConnectorResponse<OdylOracleRetour, Nothing> response = _connector.consulterProfilTV(tracabilite, srvId, nrmId);

    Assert.assertEquals(new OdylOracleRetour(1000, null, null), response._first);
    Assert.assertNull(response._second);
  }

  /**
   * Code retour 1001
   *
   * @throws Exception
   */
  @Test
  public void consulterProfilTVTest_NOK_002() throws Exception
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    Integer srvId = 336582346;
    Integer nrmId = 582346424;

    // Setup statement mock
    _callableStatement.setInt(1, srvId);
    _callableStatement.setInt(2, nrmId);

    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.getInt(3)).andReturn(1001);

    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall(OdylOracleConnector.BDD_ODYL_PKG_SPIRIT_CONSULTER_PROFILETV)).andReturn(_callableStatement);
    PowerMock.replay(_connection);

    ConnectorResponse<OdylOracleRetour, Nothing> response = _connector.consulterProfilTV(tracabilite, srvId, nrmId);

    Assert.assertEquals(new OdylOracleRetour(1001, null, null), response._first);

    Assert.assertNull(response._second);
  }

  /**
   * Code retour 1002
   *
   * @throws Exception
   */
  @Test
  public void consulterProfilTVTest_NOK_003() throws Exception
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    Integer srvId = 336582346;
    Integer nrmId = 582346424;

    // Setup statement mock
    _callableStatement.setInt(1, srvId);
    _callableStatement.setInt(2, nrmId);

    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.getInt(3)).andReturn(1002);

    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall(OdylOracleConnector.BDD_ODYL_PKG_SPIRIT_CONSULTER_PROFILETV)).andReturn(_callableStatement);
    PowerMock.replay(_connection);

    ConnectorResponse<OdylOracleRetour, Nothing> response = _connector.consulterProfilTV(tracabilite, srvId, nrmId);

    Assert.assertEquals(new OdylOracleRetour(1002, null, null), response._first);

    Assert.assertEquals(null, response._second);
  }

  /**
   * Code retour 5
   *
   * @throws Exception
   */
  @Test
  public void consulterProfilTVTest_NOK_004() throws Exception
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    Integer srvId = 336582346;
    Integer nrmId = 582346424;

    // Setup statement mock
    _callableStatement.setInt(1, srvId);
    _callableStatement.setInt(2, nrmId);

    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.getInt(3)).andReturn(5);

    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall(OdylOracleConnector.BDD_ODYL_PKG_SPIRIT_CONSULTER_PROFILETV)).andReturn(_callableStatement);
    PowerMock.replay(_connection);

    ConnectorResponse<OdylOracleRetour, Nothing> response = _connector.consulterProfilTV(tracabilite, srvId, nrmId);

    Assert.assertEquals(new OdylOracleRetour(5, null, null), response._first);

    Assert.assertEquals(null, response._second);
  }

  /**
   *
   *
   * @throws Exception
   */
  @Test
  public void consulterProfilTVTest_NOK_005() throws Exception
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    Integer srvId = 336582346;
    Integer nrmId = 582346424;

    // Exception
    SQLException sqlException = new SQLException();

    // Setup statement mock
    _callableStatement.setInt(1, srvId);
    _callableStatement.setInt(2, nrmId);

    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.getInt(3)).andReturn(1000);

    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall(OdylOracleConnector.BDD_ODYL_PKG_SPIRIT_CONSULTER_PROFILETV)).andThrow(sqlException);
    PowerMock.replay(_connection);
    try
    {
      ConnectorResponse<OdylOracleRetour, Nothing> response = _connector.consulterProfilTV(tracabilite, srvId, nrmId);
    }
    catch (RavelException ex)
    {
      Assert.assertNotNull(ex);
      Assert.assertEquals(ex, new RavelException(ExceptionType.DATABASE_ERROR, ErrorCode.CNCTOR_00010, "Technical Exception in OdylOracleConnector during consulterProfilTV call: type(SQLException) reason(null)", OdylOracleConnector.BEAN_ID, sqlException));
    }
  }

  /**
   * Nominal Test
   *
   * @throws Exception
   */
  @Test
  public void consulterProfilTVTest_OK() throws Exception
  {
    Tracabilite tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);
    Integer srvId = 336582346;
    Integer nrmId = 582346424;

    // Setup statement mock
    _callableStatement.setInt(1, srvId);
    _callableStatement.setInt(2, nrmId);

    EasyMock.expectLastCall();

    EasyMock.expect(_callableStatement.getInt(3)).andReturn(0);
    EasyMock.expect(_callableStatement.getString(4)).andReturn("success");//$NON-NLS-1$
    EasyMock.expect(_callableStatement.getString(5)).andReturn("profilTV1");//$NON-NLS-1$

    PowerMock.replay(_callableStatement);

    EasyMock.expect(_connection.prepareCall(OdylOracleConnector.BDD_ODYL_PKG_SPIRIT_CONSULTER_PROFILETV)).andReturn(_callableStatement);
    PowerMock.replay(_connection);

    ConnectorResponse<OdylOracleRetour, Nothing> response = _connector.consulterProfilTV(tracabilite, srvId, nrmId);

    Assert.assertEquals(new OdylOracleRetour(0, "success","profilTV1"), response._first);//$NON-NLS-1$

    Assert.assertNull(response._second);
  }

  /**
   ** Test load configuration without DB_CONNECTIONSTRING.
   */
  @Test
  public void loadConnectorConfigurationTest_KO1()
  {
    final Connector connector = new Connector();
    connector.setName("OdylOracleConnector"); //$NON-NLS-1$
    List<Param> paramList = new ArrayList<>();

    Param param = new Param();
    param.setName(OdylOracleConnector.ParameterName.DB_CONNECTIONSTRING.name());
    param.setValue(""); //$NON-NLS-1$
    paramList.add(param);

    connector.getParam().addAll(paramList);

    try
    {
      _connector.loadConnectorConfiguration(connector);
    }
    catch (RavelException e_p)
    {
      Assert.assertEquals(ExceptionType.INVALID_CONFIGURATION, e_p.getExceptionType());
      Assert.assertEquals(ErrorCode.CNCTOR_00020, e_p.getErrorCode());
      Assert.assertEquals("Connector 'OdylOracleConnector': The DB_CONNECTIONSTRING parameter is missing.", e_p.getMessage()); //$NON-NLS-1$
    }
  }

  /**
   ** Test load configuration without DB_USERNAME.
   */
  @Test
  public void loadConnectorConfigurationTest_KO2()
  {
    final Connector connector = new Connector();
    connector.setName("OdylOracleConnector"); //$NON-NLS-1$

    List<Param> paramList = new ArrayList<>();

    Param param = new Param();
    param.setName(OdylOracleConnector.ParameterName.DB_CONNECTIONSTRING.name());
    param.setValue("connectiongString"); //$NON-NLS-1$
    paramList.add(param);

    param = new Param();
    param.setName(OdylOracleConnector.ParameterName.DB_USERNAME.name());
    param.setValue(""); //$NON-NLS-1$
    paramList.add(param);

    connector.getParam().addAll(paramList);

    try
    {
      _connector.loadConnectorConfiguration(connector);
    }
    catch (RavelException e_p)
    {
      Assert.assertEquals(ExceptionType.INVALID_CONFIGURATION, e_p.getExceptionType());
      Assert.assertEquals(ErrorCode.CNCTOR_00020, e_p.getErrorCode());
      Assert.assertEquals("Connector 'OdylOracleConnector': The DB_USERNAME parameter is missing.", e_p.getMessage()); //$NON-NLS-1$
    }
  }

  /**
   ** Test load configuration without DB_PASSWORD.
   */
  @Test
  public void loadConnectorConfigurationTest_KO3()
  {
    final Connector connector = new Connector();
    connector.setName("OdylOracleConnector"); //$NON-NLS-1$

    List<Param> paramList = new ArrayList<>();

    Param param = new Param();
    param.setName(OdylOracleConnector.ParameterName.DB_CONNECTIONSTRING.name());
    param.setValue("connectiongString"); //$NON-NLS-1$
    paramList.add(param);

    param = new Param();
    param.setName(OdylOracleConnector.ParameterName.DB_USERNAME.name());
    param.setValue("TEST"); //$NON-NLS-1$
    paramList.add(param);

    param = new Param();
    param.setName(OdylOracleConnector.ParameterName.DB_PASSWORD.name());
    param.setValue(""); //$NON-NLS-1$
    paramList.add(param);

    connector.getParam().addAll(paramList);

    try
    {
      _connector.loadConnectorConfiguration(connector);
    }
    catch (RavelException e_p)
    {
      Assert.assertEquals(ExceptionType.INVALID_CONFIGURATION, e_p.getExceptionType());
      Assert.assertEquals(ErrorCode.CNCTOR_00020, e_p.getErrorCode());
      Assert.assertEquals("Connector 'OdylOracleConnector': The DB_PASSWORD parameter is missing.", e_p.getMessage()); //$NON-NLS-1$

    }
  }

  /**
   * Test load configuration with all parameters OK
   *
   * @throws RavelException
   */
  @Test
  public void loadConnectorConfigurationTest_OK() throws RavelException
  {
    final Connector connector = new Connector();
    List<Param> paramList = new ArrayList<>();

    Param param = new Param();
    param.setName(OdylOracleConnector.ParameterName.DB_CONNECTIONSTRING.name());
    param.setValue("OdylOracleConnector"); //$NON-NLS-1$
    paramList.add(param);

    param = new Param();
    param.setName(OdylOracleConnector.ParameterName.DB_USERNAME.name());
    param.setValue("TEST"); //$NON-NLS-1$
    paramList.add(param);

    param = new Param();
    param.setName(OdylOracleConnector.ParameterName.DB_PASSWORD.name());
    param.setValue("EmoEOmWbGT/DKV9ZjcD/3A=="); //$NON-NLS-1$
    paramList.add(param);

    param = new Param();
    param.setName(OdylOracleConnector.ParameterName.POOLSIZE.name());
    param.setValue(String.valueOf(20));
    paramList.add(param);

    param = new Param();
    param.setName(OdylOracleConnector.ParameterName.CONNECT_TIMEOUT_SEC.name());
    param.setValue(String.valueOf(5));
    paramList.add(param);

    param = new Param();
    param.setName(OdylOracleConnector.ParameterName.READ_TIMEOUT_SEC.name());
    param.setValue(String.valueOf(30));
    paramList.add(param);

    param = new Param();
    param.setName(OdylOracleConnector.ParameterName.QUERY_TIMEOUT_SEC.name());
    param.setValue(String.valueOf(600));
    paramList.add(param);

    connector.getParam().addAll(paramList);

    _connector.loadConnectorConfiguration(connector);
  }

  @Before
  public void setUp() throws Exception
  {
    _podam.getStrategy().setMemoization(false);
    _podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());

    PowerMock.mockStatic(PasswordDecrypter.class);
    EasyMock.expect(_dataSource.getConnection()).andReturn(_connection).anyTimes();
    PowerMock.replay(_dataSource);

    JUnitTools.setInaccessibleFieldValue(_connector, "_datasource", _dataSource); //$NON-NLS-1$

  }
}
