/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.odyl.oracle;

import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.probes.AvgDoubleCollectorItem;
import com.bytel.ravel.common.probes.AvgFlowPerSecondCollector;
import com.bytel.ravel.common.probes.RavelProbeConfigurationManager;
import com.bytel.ravel.services.connector.BaseProxy;
import com.bytel.ravel.services.connector.ConnectorExecution;
import com.bytel.ravel.services.connector.ConnectorManager;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.connectors.odyl.oracle.structs.OdylOracleRetour;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

/**
 * @author hgoncavl
 * @version ($Revision$ $Date$)
 */
public final class OdylOracleProxy extends BaseProxy implements IOdylOracle
{

  /**
   * Proxy name.
   */
  private static final String PROXY_NAME = "OdylOracleProxy"; //$NON-NLS-1$
  /**
   * OdylOracleProxy _instance
   */
  private static final OdylOracleProxy _instance = new OdylOracleProxy();

  /**
   * @return getInstance()
   */
  public static OdylOracleProxy getInstance()
  {
    return _instance;
  }

  /**
   * Probe: measure the average number of consulterProfilTV call per second.
   */
  AvgFlowPerSecondCollector _avg_consulterProfilTV_call_counter;

  /**
   * Probe: measure the average execution time of the consulterProfilTV operation.
   */
  AvgDoubleCollectorItem _avg_consulterProfilTV_ExecTime;

  /**
   *
   */
  public OdylOracleProxy()
  {
    _avg_consulterProfilTV_call_counter = RavelProbeConfigurationManager.getInstance().createAvgFlowPerSecondCollector("Avg_consulterProfilTV_call_counter", PROXY_NAME); //$NON-NLS-1$
    _avg_consulterProfilTV_ExecTime = RavelProbeConfigurationManager.getInstance().createAvgDoubleCollectorItem("Avg_consulterProfilTV_ExecTime", PROXY_NAME); //$NON-NLS-1$
  }

  @Override
  public ConnectorResponse<OdylOracleRetour, Nothing> consulterProfilTV(Tracabilite tracabilite_p, Integer srvId_p, Integer nrmId_p) throws RavelException
  {
    return execute(new ConnectorExecution<ConnectorResponse<OdylOracleRetour, Nothing>>(IOdylOracleConnector.BEAN_ID)
    {

      @Override
      public ConnectorResponse<OdylOracleRetour, Nothing> run() throws RavelException
      {
        IOdylOracleConnector odylOracleConnector = (IOdylOracleConnector) ConnectorManager.getInstance().getConnector(_connectorId);
        _avg_consulterProfilTV_call_counter.measure();
        long startTime = System.currentTimeMillis();
        try
        {
          return odylOracleConnector.consulterProfilTV(tracabilite_p, srvId_p, nrmId_p);
        }
        finally
        {
          long endTime = System.currentTimeMillis();
          _avg_consulterProfilTV_ExecTime.updateAvgValue(endTime - startTime);
        }
      }
    });
  }
}