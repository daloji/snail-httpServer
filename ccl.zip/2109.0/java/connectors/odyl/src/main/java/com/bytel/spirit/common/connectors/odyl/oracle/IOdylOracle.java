/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.odyl.oracle;

import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.connectors.odyl.oracle.structs.OdylOracleRetour;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

/**
 * @author hgoncalv
 * @version ($Revision$ $Date$)
 */
public interface IOdylOracle
{
  /**
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param srvId_p
   *          srvId_p
   * @param nrmId_p
   *          nrmId_p
   * @return Résultat de l’activité et Profil TV applicable
   * @throws RavelException
   *           In case of error
   */
  public ConnectorResponse<OdylOracleRetour, Nothing> consulterProfilTV(Tracabilite tracabilite_p, Integer srvId_p, Integer nrmId_p) throws RavelException;
}
