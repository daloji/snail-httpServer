/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.odyl.oracle.structs;

import java.io.Serializable;
import java.util.Objects;

/**
 * @author hgoncalv
 * @version ($Revision$ $Date$)
 */
public class OdylOracleRetour implements Serializable
{

  private static final long serialVersionUID = -803365160654958586L;

  /**
   * codeRetour attribute
   */
  private Integer _codeRetour;

  /**
   * libelleErreur attribute
   */
  private String _libelleErreur;

  /**
   * profilTV attribute
   */
  private String _profilTV;

  public OdylOracleRetour(Integer codeRetour_p, String libelleErreur_p, String profilTV_p)
  {
    _codeRetour = codeRetour_p;
    _libelleErreur = libelleErreur_p;
    _profilTV = profilTV_p;
  }

  @Override
  public boolean equals(Object o_p)
  {
    if (this == o_p)
    {
      return true;
    }
    if (o_p == null || getClass() != o_p.getClass())
    {
      return false;
    }
    OdylOracleRetour that = (OdylOracleRetour) o_p;
    return Objects.equals(_codeRetour, that._codeRetour) && Objects.equals(_libelleErreur, that._libelleErreur) && Objects.equals(_profilTV, that._profilTV);
  }

  /**
   * @return value of _codeRetour
   */
  public Integer getCodeRetour()
  {
    return _codeRetour;
  }

  /**
   * @return value of _libelleErreur
   */
  public String getLibelleErreur()
  {
    return _libelleErreur;
  }

  /**
   * @return value of _profilTV
   */
  public String getProfilTV()
  {
    return _profilTV;
  }

  @Override
  public int hashCode()
  {
    return Objects.hash(_codeRetour, _libelleErreur, _profilTV);
  }

  /**
   * @param codeRetour_p
   *          The _codeRetour to set.
   */
  public void setCodeRetour(Integer codeRetour_p)
  {
    _codeRetour = codeRetour_p;
  }

  /**
   * @param libelleErreur_p
   *          The _libelleErreur to set.
   */
  public void setLibelleErreur(String libelleErreur_p)
  {
    _libelleErreur = libelleErreur_p;
  }

  /**
   * @param profilTV_p
   *          The _profilTV to set.
   */
  public void setProfilTV(String profilTV_p)
  {
    _profilTV = profilTV_p;
  }

  @Override
  public String toString()
  {
    return "OdylOracleRetour [" + "codeRetour=" + _codeRetour + ", libelleErreur=" + _libelleErreur + ", profilTV=" + _profilTV + "]";
  }
}
