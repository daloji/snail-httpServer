/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.odyl.oracle;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.text.MessageFormat;
import java.util.HashMap;
import java.util.Map;

import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionTools;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.services.conf.connector.generated.Connector;
import com.bytel.ravel.services.connector.AbstractDBConnector;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.connectors.odyl.Messages;
import com.bytel.spirit.common.connectors.odyl.oracle.structs.OdylOracleRetour;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

/**
 * @author hgoncalv
 * @version ($Revision$ $Date$)
 */
public class OdylOracleConnector extends AbstractDBConnector implements IOdylOracleConnector
{

  /**
   *
   * @author pramos
   * @version ($Revision$ $Date$)
   */
  protected enum ParameterName
  {
    /**
     * The URL parameter
     */
    DB_CONNECTIONSTRING,
    /**
     * The LOGIN parameter
     */
    DB_USERNAME,
    /**
     * The PASSWORD parameter
     */
    DB_PASSWORD,
    /**
     * The POOLSIZE parameter
     */
    POOLSIZE,
    /**
     * Connect timeout in sec
     */
    CONNECT_TIMEOUT_SEC,
    /**
     * read timeout in sec
     */
    READ_TIMEOUT_SEC,
    /**
     * query timeout in sec
     */
    QUERY_TIMEOUT_SEC
  }

  /**
   * The constant for BDD_ODYL.PKG_SPIRIT.consulterProfileTV
   */
  protected static final String BDD_ODYL_PKG_SPIRIT_CONSULTER_PROFILETV = "{call PKG_SPIRIT.consulterProfilTV (?, ?, ?, ?, ?)}"; //$NON-NLS-1$

  /**
   * The constant for MESSAGE_MISSING_CONFIGURATION_PARAMETER
   */
  private static final String MESSAGE_MISSING_CONFIGURATION_PARAMETER = Messages.getString("OdylOracleConnector.MissingConfigurationParameter"); //$NON-NLS-1$

  /**
   * The constant for MESSAGE_INVALID_CONFIGURATION_PARAMETER
   */
  private static final String MESSAGE_INVALID_CONFIGURATION_PARAMETER = Messages.getString("OdylOracleConnector.InvalidConfigurationParameter"); //$NON-NLS-1$

  /**
   * datasource connection properties
   */
  private final static String CONNECTION_PROPERTIES = "oracle.net.CONNECT_TIMEOUT=%d;oracle.jdbc.ReadTimeout=%d"; //$NON-NLS-1$

  /**
   * Parameters read from configuration.
   */
  private Map<OdylOracleConnector.ParameterName, String> _parameters = new HashMap<>(0);

  /**
   * Connect timeout in seconds
   */
  private int _connectTimeoutMilliSec;

  /**
   * Read timeout in seconds
   */
  private int _readTimeoutSec;

  /**
   * Query timeout in seconds
   */
  private int _queryTimeoutSec;

  @Override
  public ConnectorResponse<OdylOracleRetour, Nothing> consulterProfilTV(Tracabilite tracabilite_p, Integer srvId_p, Integer nrmId_p) throws RavelException
  {
    // lock
    _dsReadLock.lock();

    try (Connection con = _datasource.getConnection(); CallableStatement cs = con.prepareCall(BDD_ODYL_PKG_SPIRIT_CONSULTER_PROFILETV))
    {

      // Set timeout
      cs.setQueryTimeout(_queryTimeoutSec);

      // Input parameters
      cs.setInt(1, srvId_p);
      cs.setInt(2, nrmId_p);

      // Output parameters
      cs.registerOutParameter(3, Types.INTEGER);
      cs.registerOutParameter(4, Types.VARCHAR);
      cs.registerOutParameter(5, Types.VARCHAR);

      // Execute the stored procedure
      cs.execute();

      // Get output parameters
      Integer codeRetour = cs.getInt(3);
      String libelleErreur = cs.getString(4);
      String profilTV = cs.getString(5);

      return new ConnectorResponse<>(new OdylOracleRetour(codeRetour, libelleErreur, profilTV), null);
    }
    catch (SQLException exception)
    {
      throw buildTechnicalException(exception, tracabilite_p, "consulterProfilTV"); //$NON-NLS-1$
    }
    finally
    {
      // unlock
      _dsReadLock.unlock();
    }
  }

  @Override
  public void loadConnectorConfiguration(Connector connector_p) throws RavelException
  {
    // Read parameters.
    _name = connector_p.getName();
    _enabled = connector_p.isEnabled();

    // Get parameters
    connector_p.getParam().forEach(p -> _parameters.put(ParameterName.valueOf(p.getName().toUpperCase()), p.getValue()));

    // Check parameters

    // Get DB_CONNECTIONSTRING
    String connectionString = _parameters.get(ParameterName.DB_CONNECTIONSTRING);
    if (StringTools.isNullOrEmpty(connectionString))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, _name, ParameterName.DB_CONNECTIONSTRING.toString()));
    }

    // Get DB_USERNAME
    String dbUserName = _parameters.get(ParameterName.DB_USERNAME);
    if (StringTools.isNullOrEmpty(dbUserName))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, _name, ParameterName.DB_USERNAME.toString()));
    }

    // Get DB_PASSWORD
    String dbPassword = _parameters.get(ParameterName.DB_PASSWORD);
    if (StringTools.isNullOrEmpty(dbPassword))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, _name, ParameterName.DB_PASSWORD.toString()));
    }

    // Get POOLSIZE
    String poolSize = _parameters.get(ParameterName.POOLSIZE);

    // Get CONNECT_TIMEOUT_SEC
    String connectTimeoutSec = _parameters.get(ParameterName.CONNECT_TIMEOUT_SEC);
    if (StringTools.isNullOrEmpty(connectTimeoutSec))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, _name, ParameterName.CONNECT_TIMEOUT_SEC.toString()));
    }
    try
    {
      _connectTimeoutMilliSec = Integer.parseInt(connectTimeoutSec) * 1000;
    }
    catch (NumberFormatException e)
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00021, MessageFormat.format(MESSAGE_INVALID_CONFIGURATION_PARAMETER, _name, ParameterName.CONNECT_TIMEOUT_SEC.toString()));
    }

    // Get READ_TIMEOUT_SEC
    String readTimeoutSec = _parameters.get(ParameterName.READ_TIMEOUT_SEC);
    if (StringTools.isNullOrEmpty(readTimeoutSec))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, _name, ParameterName.READ_TIMEOUT_SEC.toString()));
    }
    try
    {
      _readTimeoutSec = Integer.parseInt(readTimeoutSec) * 1000;
    }
    catch (NumberFormatException e)
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00021, MessageFormat.format(MESSAGE_INVALID_CONFIGURATION_PARAMETER, _name, ParameterName.READ_TIMEOUT_SEC.toString()));
    }

    // Get QUERY_TIMEOUT_SEC
    String queryTimeoutSec = _parameters.get(ParameterName.QUERY_TIMEOUT_SEC);
    if (StringTools.isNullOrEmpty(queryTimeoutSec))
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, _name, ParameterName.QUERY_TIMEOUT_SEC.toString()));
    }
    try
    {
      _queryTimeoutSec = Integer.parseInt(queryTimeoutSec) * 1000;
    }
    catch (NumberFormatException e)
    {
      throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00021, MessageFormat.format(MESSAGE_INVALID_CONFIGURATION_PARAMETER, _name, ParameterName.QUERY_TIMEOUT_SEC.toString()));
    }

    // Create data source
    createDataSource(connectionString, dbUserName, dbPassword, poolSize, DatabaseType.ORACLE);
    _datasource.setConnectionProperties(String.format(CONNECTION_PROPERTIES, _connectTimeoutMilliSec, _readTimeoutSec));

  }

  /**
   * Build a log entry and throws an {@link RavelException} for a technical problem.
   *
   * @param exc_p
   *          The {@link Exception} raised
   * @param tracabilite_p
   *          The traçabilite
   * @param method_p
   *          The method name in which the fault was raised.
   * @return RavelException The technical exception.
   */
  private RavelException buildTechnicalException(Exception exc_p, Tracabilite tracabilite_p, String method_p)
  {
    String message = MessageFormat.format(Messages.getString("OdylOracleConnector.TechnicalExceptionMessage"), method_p, exc_p.getClass().getSimpleName(), exc_p.getMessage()); //$NON-NLS-1$

    // Add fileName and line number of the exception
    message += ExceptionTools.getExceptionLineAndFile(exc_p);

    RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, message));
    return new RavelException(ExceptionType.DATABASE_ERROR, ErrorCode.CNCTOR_00010, message, IOdylOracleConnector.BEAN_ID, exc_p);
  }
}