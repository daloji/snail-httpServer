/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.connectors.odyl.oracle;

import com.bytel.ravel.services.connector.IConnector;

/**
 * @author hgoncalv
 * @version ($Revision$ $Date$)
 */
public interface IOdylOracleConnector extends IConnector, IOdylOracle
{

  /**
   * The id to retrieve the connector.
   */
  public String BEAN_ID = "OdylOracleConnector"; //$NON-NLS-1$
}
