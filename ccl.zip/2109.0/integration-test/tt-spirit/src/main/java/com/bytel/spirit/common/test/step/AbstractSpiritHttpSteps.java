/*******************************************************************************
* $Id: AbstractSpiritHttpSteps.java 18755 2019-03-19 15:19:59Z dangelis $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.test.step;

import com.bytel.ravel.step.helper.AbstractHttpSteps;
import com.consol.citrus.dsl.builder.HttpServerRequestActionBuilder;

/**
 *
 * @author jstrub
 * @version ($Revision: 18755 $ $Date: 2019-03-19 16:19:59 +0100 (mar. 19 mars 2019) $)
 */
public abstract class AbstractSpiritHttpSteps extends AbstractHttpSteps
{

  /**
   * Constructor
   *
   * @param baseDir_p
   *          the template base directory for this steps
   */
  public AbstractSpiritHttpSteps(String baseDir_p)
  {
    super(baseDir_p);
  }

  /**
   * Control Spirit specific headers ; extract generated identifiers with given flag (should be used on first call).
   *
   * @param serverAction_p
   *          the server request action builder
   * @param extractGenerated_p
   *          the flag to trigger generated identifier extraction instead of control
   */
  @SuppressWarnings("nls")
  public void controlReceivedHeaders(HttpServerRequestActionBuilder serverAction_p, boolean extractGenerated_p)
  {
    serverAction_p.header("X-Process", "${process}");
    serverAction_p.header("X-Request-Id", "${request.id}");
    serverAction_p.header("X-Source", "${request.source}");
    serverAction_p.header("X-Trace-cliOpe", "${request.client-operateur}");
    serverAction_p.header("X-Trace-noCpt", "${request.compte}");

    // Extract or control generated identifiers
    if (extractGenerated_p)
    {
      serverAction_p.header("X-Request-Id-Spirit", "@variable('spirit.requestId')@");
      serverAction_p.header("X-Process-Id-Spirit", "@variable('spirit.processId')@");
    }
    else
    {
      serverAction_p.header("X-Request-Id-Spirit", "${spirit.requestId}");
      serverAction_p.header("X-Process-Id-Spirit", "${spirit.processId}");
    }
  }

}
