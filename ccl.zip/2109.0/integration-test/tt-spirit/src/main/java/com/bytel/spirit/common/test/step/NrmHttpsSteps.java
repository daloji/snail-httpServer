package com.bytel.spirit.common.test.step;

import com.bytel.spirit.common.test.config.BouchonHttpConfig;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

/**
 *
 * @author jiantila
 * @version ($Revision: 43581 $ $Date: 2020-11-12 16:56:47 +0100 (jeu. 12 nov. 2020) $)
 */
public class NrmHttpsSteps extends AbstractSpiritHttpSteps
{

  /** NrmConnector base path. */
  private static final String BASE_PATH = "NRM"; //$NON-NLS-1$

  /**
   * Url reception notification
   */
  @Deprecated
  private static final String URL_RECEPTION_NOTIFICATION = "/nrm/NetworkEventsService"; //$NON-NLS-1$

  /**
   * Url spirit notification
   */
  private static final String URL_SPIRIT = "/nrm/SpiritService"; //$NON-NLS-1$

  /**
   * Url spirit notification
   */
  private static final String URL_SPIRIT_ALLOCATION = "/nrm/AllocationService"; //$NON-NLS-1$

  /**
   * Url spirit ModificationService
   */
  private static final String URL_MODIFICATION_SERVICE = "/nrm/ModificationService"; //$NON-NLS-1$

  /**
   * Url spirit notification
   */
  private static final String URL_SPIRIT_DELETION = "/nrm/DeletionService"; //$NON-NLS-1$
  /**
   * Url GetTechnicalCodeInfo
   */
  private static final String URL_GET_TECHNICAL_CODE_INFO = "/nrm/NRMInfoService"; //$NON-NLS-1$

  /** Constant for method reconciliationCommercialeEnMasseLireTous */
  private static final String METHOD_RECEPTION_NOTIFICATION = "receptionNotificationOmsFtth"; //$NON-NLS-1$

  /** Constant for method spiritNetDeviceInfo */
  private static final String METHOD_SPIRIT_NET_DEVICE_INFO = "spiritNetDeviceInfo"; //$NON-NLS-1$

  /** Constant for method spiritPortAllocate */
  private static final String METHOD_SPIRIT_PORT_ALLOCATE = "spiritPortAllocate"; //$NON-NLS-1$

  /** Constant for method technicalCodeModify */
  private static final String METHOD_TECHNICAL_CODE_MODIFY = "technicalCodeModify"; //$NON-NLS-1$

  /** Constant for method modifyPlotPmOc */
  private static final String METHOD_MODIFY_PLOT_PM_OC = "modifyPlotPmOc"; //$NON-NLS-1$

  /** Constant for method gpPonResourceDelete */
  private static final String METHOD_GP_PON_RESOURCE_DELETE = "gpPonResourceDelete"; //$NON-NLS-1$

  /** Constant for method gpPonResourceAllocate */
  private static final String METHOD_GP_PON_RESOURCE_ALLOCATE = "gpPonResourceAllocate"; //$NON-NLS-1$

  /** Constant for method portAllocate */
  private static final String METHOD_PORT_ALLOCATE = "portAllocate"; //$NON-NLS-1$
  /** Constant for method getTechnicalCodeInfo */
  private static final String METHOD_GET_TECHNICAL_CODE_INFO = "getTechnicalCodeInfo";

  /** Transient service. */
  private String _service;

  /**
   * Constructor
   */
  public NrmHttpsSteps()
  {
    super(BASE_PATH);
  }

  /**
   * @param baseDir_p
   */
  public NrmHttpsSteps(String baseDir_p)
  {
    super(baseDir_p); // TODO Auto-generated constructor stub
  }

  /**
   * NRM responds with template
   *
   * @param template_p
   *          template
   */
  @Then("NRM responds with ([^\"]*)$")
  public void nrmResponse(String template_p)
  {
    sendResponse(template_p);
  }

  /**
   * NRM receives gpPonResourceDelete request.
   *
   * @param template_p
   *          template
   */
  @When("NRM receives a gpPonResourceAllocate request with ([^\"]*)$")
  public void receiveGpPonResourceAllocateRequest(String template_p)
  {
    receiveRequest(METHOD_GP_PON_RESOURCE_ALLOCATE, template_p);
  }

  @When("NRM receives a gpPonResourceDelete request with ([^\"]*)$")
  public void receiveGpPonResourceDeleteRequest(String template_p)
  {
    receiveRequest(METHOD_GP_PON_RESOURCE_DELETE, template_p);
  }

  /**
   * NRM receives receptionNotificationOmsFtth request.
   *
   * @param template_p
   *          the template to control from
   */
  @When("NRM receives a receptionNotificationOmsFtth request with ([^\"]*)$")
  public void receiveImportMessageRequest(String template_p)
  {
    receiveRequest(METHOD_RECEPTION_NOTIFICATION, template_p);
  }

  /**
   * NRM receives modifyPlotPmOc request.
   *
   * @param template_p
   *          the template to control from
   */
  @When("NRM receives a modifyPlotPmOc request with ([^\"]*)$")
  public void receiveModifyPlotPmOcRequest(String template_p)
  {
    receiveRequest(METHOD_MODIFY_PLOT_PM_OC, template_p);
  }

  /**
   * NRM receives spiritNetDeviceInfo request.
   *
   * @param template_p
   *          the template to control from
   */
  @When("NRM receives a spiritNetDeviceInfo request with ([^\"]*)$")
  public void receiveSpiritNetDeviceInfoRequest(String template_p)
  {
    receiveRequest(METHOD_SPIRIT_NET_DEVICE_INFO, template_p);
  }

  /**
   * NRM receives spiritPortAllocate request.
   *
   * @param template_p
   *          the template to control from
   */
  @When("NRM receives a spiritPortAllocate request with ([^\"]*)$")
  public void receiveSpiritPortAllocateRequest(String template_p)
  {
    receiveRequest(METHOD_SPIRIT_PORT_ALLOCATE, template_p);
  }

  /**
   * NRM receives technicalCodeModify request.
   *
   * @param template_p
   *          the template to control from
   */
  @When("NRM receives a technicalCodeModify request with ([^\"]*)$")
  public void receiveTechnicalCodeModifyRequest(String template_p)
  {
    receiveRequest(METHOD_TECHNICAL_CODE_MODIFY, template_p);
  }

  /**
   * NRM receives portAllocate request.
   *
   * @param template_p
   *          the template to control from
   */
  @When("NRM receives a portAllocate request with ([^\"]*)$")
  public void receivePortAllocateRequest(String template_p)
  {
    receiveRequest(METHOD_PORT_ALLOCATE, template_p);
  }

  /**
   * NRM receives getTechnicalCodeInfo request.
   *
   * @param template_p
   *          the template to control from
   */
  @When("NRM receives a getTechnicalCodeInfo request with ([^\"]*)$")
  public void receiveGetTechnicalCodeInfoRequest(String template_p)
  {
    receiveRequest(METHOD_GET_TECHNICAL_CODE_INFO, template_p);
  }

  /**
   * Generic method to receive the request
   *
   * @param method_p
   *          method name to call
   * @param template_p
   *          template file name
   */
  private void receiveRequest(String method_p, String template_p)
  {
    _service = method_p;

    switch (_service)
    {
      // URL_FTTH_EXTERN
      case METHOD_RECEPTION_NOTIFICATION:
        this.getDesigner()//
            .http() //
            .server(BouchonHttpConfig.NRM_SERVER) //
            .receive() //
            .post(URL_RECEPTION_NOTIFICATION) //
            .payload(templateResource(method_p, REQUEST_DIR, template_p));
        break;
      // URL_FTTH_EXTERN
      case METHOD_SPIRIT_NET_DEVICE_INFO:
        this.getDesigner()//
            .http() //
            .server(BouchonHttpConfig.NRM_SERVER) //
            .receive() //
            .post(URL_SPIRIT) //
            .payload(templateResource(method_p, REQUEST_DIR, template_p));
        break;
      case METHOD_SPIRIT_PORT_ALLOCATE:
      case METHOD_GP_PON_RESOURCE_ALLOCATE:
      case METHOD_PORT_ALLOCATE :
        this.getDesigner()//
            .http() //
            .server(BouchonHttpConfig.NRM_SERVER) //
            .receive() //
            .post(URL_SPIRIT_ALLOCATION) //
            .payload(templateResource(method_p, REQUEST_DIR, template_p));
        break;
      case METHOD_GET_TECHNICAL_CODE_INFO :
        this.getDesigner()//
            .http() //
            .server(BouchonHttpConfig.NRM_SERVER) //
            .receive() //
            .post(URL_GET_TECHNICAL_CODE_INFO) //
            .payload(templateResource(method_p, REQUEST_DIR, template_p));
        break;
      case METHOD_TECHNICAL_CODE_MODIFY:
      case METHOD_MODIFY_PLOT_PM_OC:
        this.getDesigner()//
            .http() //
            .server(BouchonHttpConfig.NRM_SERVER) //
            .receive() //
            .post(URL_MODIFICATION_SERVICE) //
            .payload(templateResource(method_p, REQUEST_DIR, template_p));
        break;
      case METHOD_GP_PON_RESOURCE_DELETE:
        this.getDesigner()//
            .http() //
            .server(BouchonHttpConfig.NRM_SERVER) //
            .receive() //
            .post(URL_SPIRIT_DELETION) //
            .payload(templateResource(method_p, REQUEST_DIR, template_p));
        break;
      default :
        break;
    }
  }

  /**
   * Generic method to receive the request
   *
   * @param template_p
   *          template file name
   */
  private void sendResponse(String template_p)
  {
    switch (_service)
    {
      case METHOD_RECEPTION_NOTIFICATION:
      case METHOD_SPIRIT_NET_DEVICE_INFO:
      case METHOD_SPIRIT_PORT_ALLOCATE:
      case METHOD_TECHNICAL_CODE_MODIFY:
      case METHOD_MODIFY_PLOT_PM_OC:
      case METHOD_GP_PON_RESOURCE_ALLOCATE:
      case METHOD_GP_PON_RESOURCE_DELETE:
      case METHOD_PORT_ALLOCATE :
      case METHOD_GET_TECHNICAL_CODE_INFO :
        serverResponseActionOK(BouchonHttpConfig.NRM_SERVER, templateResource(_service, RESPONSE_DIR, template_p));
        break;

      default:
        break;
    }
  }

}
