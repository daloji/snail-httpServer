/*******************************************************************************
* $Id: StarkHttpSteps.java 48111 2021-02-24 17:00:02Z pramos $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.test.step;

import com.bytel.spirit.common.test.config.BouchonHttpConfig;
import com.consol.citrus.dsl.builder.HttpServerRequestActionBuilder;
import com.consol.citrus.dsl.builder.HttpServerResponseActionBuilder;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

/**
 *
 * @author kbettenc
 * @version ($Revision: 48111 $ $Date: 2021-02-24 18:00:02 +0100 (mer. 24 févr. 2021) $)
 */
public class StarkHttpSteps extends AbstractSpiritHttpSteps
{
  /** STARK base path. */
  private static final String STARK_BASE_PATH = "STARK"; //$NON-NLS-1$

  /** Transient expected REX server request. */
  private HttpServerRequestActionBuilder _serverRequest;

  /** Transient client response builder. */
  private HttpServerResponseActionBuilder _serverResponse;

  /** Transient service. */
  private String _service;

  /** */
  public StarkHttpSteps()
  {
    super(STARK_BASE_PATH);
  }

  /**
   * STARK receives header headerName=headerValue.
   *
   * @param headerName_p
   *          the name of the expected header.
   * @param headerValue_p
   *          the value of the expected header.
   */
  @And("^STARK receives header ([^=]+)=\"([^\"]+)\"$")
  public void expectHeader(String headerName_p, String headerValue_p)
  {
    _serverRequest.header(headerName_p, headerValue_p);
  }

  /**
   * Expect request has given query param
   *
   * @param name_p
   *          query param name
   * @param value_p
   *          query param value
   */
  @And("STARK query param {any}={string}")
  public void expectQueryParam(String name_p, String value_p)
  {
    _serverRequest.queryParam(name_p, value_p);
  }

  /**
   * STARK responds an error
   *
   * @param template_p
   *          relative template path
   */
  @When("STARK responds with {template}")
  public void okResponseAction(String template_p)
  {
    serverResponseActionOK(BouchonHttpConfig.STARK_SERVER, templateResource(_service, RESPONSE_DIR, template_p));
  }

  /**
   * Expect that STARK receives a GET request.
   *
   * @param uri_p
   *          uri
   */
  @When("^STARK receives a GET request on ([^\"]+)$")
  public void receiveGetRequest(String uri_p)
  {
    _service = "stark"; //$NON-NLS-1$
    _serverRequest = this.getDesigner().http().server(BouchonHttpConfig.STARK_SERVER).receive().get(uri_p);
  }

  /**
   * Expect that STARK receives a POST request.
   *
   * @param uri_p
   *          uri
   * @param template_p
   *          relative template path
   */
  @When("STARK receives a POST request on ([^\"]*) with ([^\"]*)$")
  public void receivePostRequest(String uri_p, String template_p)
  {
    _service = "stark"; //$NON-NLS-1$
    _serverRequest = this.getDesigner()//
        .http()//
        .server(BouchonHttpConfig.STARK_SERVER).receive()//
        .post(uri_p) //
        .payload(templateResource(_service, REQUEST_DIR, template_p));
  }

  /**
   * Expect that STARK receives a reconciliationCommercialeModifier request.
   *
   * @param uri_p
   *          uri
   */
  @When("^STARK receives a PUT request on ([^\"]+)$")
  public void receivePutRequest(String uri_p)
  {
    _service = "stark"; //$NON-NLS-1$
    _serverRequest = this.getDesigner()//
        .http()//
        .server(BouchonHttpConfig.STARK_SERVER).receive()//
        .put(uri_p);
  }

  /**
   * STARK responds with status and template
   *
   * @param statusCode_p
   *          http status code
   * @param template_p
   *          relative template path
   */
  @Then("STARK responds status (\\d+) with ([^\"]*)$")
  public void responseAction(Integer statusCode_p, String template_p)
  {
    _serverResponse = serverResponseAction(BouchonHttpConfig.STARK_SERVER, statusCode_p, templateResource(_service, RESPONSE_DIR, template_p));
  }

  /**
   * STARK responds with status and template
   *
   * @param statusCode_p
   *          http status code
   */
  @Then("STARK responds status (\\d+)$")
  public void responseActionOk(Integer statusCode_p)
  {
    _serverResponse = serverResponseAction(BouchonHttpConfig.STARK_SERVER, statusCode_p, null);
  }

  /**
   * Configure response with a given header
   *
   * @param name_p
   *          header name
   * @param value_p
   *          header value
   */
  @And("STARK response has header {any}={string}")
  public void sendHeaders(String name_p, String value_p)
  {
    _serverResponse.header(name_p, value_p);

  }

}
