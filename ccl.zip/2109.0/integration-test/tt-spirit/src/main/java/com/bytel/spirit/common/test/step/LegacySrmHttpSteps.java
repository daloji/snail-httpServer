/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.test.step;

import org.springframework.core.io.ClassPathResource;

import com.bytel.ravel.RavelTestException;
import com.bytel.spirit.common.test.config.BouchonHttpConfig;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

/**
 *
 * @author pramos
 * @version ($Revision$ $Date$)
 */
public class LegacySrmHttpSteps extends AbstractSpiritHttpSteps
{
  /** SRM base path. */
  private static final String BASE_PATH = "LEGACY_SRM"; //$NON-NLS-1$
  /** Transient service. */
  private String _service;

  /**
   * Constructor
   */
  public LegacySrmHttpSteps()
  {
    super(BASE_PATH);
  }

  /**
   * Expect that SRM receives a export request for the service.
   *
   * @param service_p
   *          The service
   *
   * @param path_p
   *          Post path
   *
   * @param template_p
   *          the template to control
   * @throws RavelTestException
   *           on test setup error
   */
  @When("SRM receives a ([^\"]*) request on ([^\"]*) with ([^\"]*)$")
  public void receiveImportMessageRequest(String service_p, String path_p, String template_p)
  {
    _service = service_p;

    this.getDesigner()//
        .http()//
        .server(BouchonHttpConfig.LEGACY_SRM_SERVER)//
        .receive()//
        .post(path_p)//
        .payload(templateResource(_service, REQUEST_DIR, template_p));

  }

  /**
   * SRM responds
   *
   * @param statusCode_p
   *          http status code
   * @param template_p
   *          relative template path
   */
  @Then("SRM responds status (\\d+) with ([^\"]*)$")
  public void receiveResponseWithCodeAndTemplate(Integer statusCode_p, String template_p)
  {
    ClassPathResource template = null;
    if (template_p != null)
    {
      template = templateResource(_service, RESPONSE_DIR, template_p);
    }
    serverResponseAction(BouchonHttpConfig.LEGACY_SRM_SERVER, statusCode_p, template);
  }
}
