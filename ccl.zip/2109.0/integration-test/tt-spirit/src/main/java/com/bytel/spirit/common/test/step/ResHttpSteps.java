/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.test.step;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.bytel.spirit.common.test.config.BouchonHttpConfig;
import com.consol.citrus.dsl.builder.HttpServerRequestActionBuilder;
import com.consol.citrus.endpoint.adapter.StaticResponseEndpointAdapter;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

/**
 * @author dangelis
 * @version ($Revision$ $Date$)
 */
public class ResHttpSteps extends AbstractSpiritHttpSteps
{
  private interface IMethod
  {
    String RESSOURCE_LIRE_UN = "ressourceLireUn"; //$NON-NLS-1$
    String RESSOURCE_RACCORDEMENT_COMPOSITE_LIRE_UN = "ressourceRaccordementCompositeLireUn"; //$NON-NLS-1$
    String RESSOURCE_RACCORDEMENT_MODIFIER_STATUT_ALLOCATION = "ressourceRaccordementModifierStatutAllocation"; //$NON-NLS-1$
    String PAD3101_RESSOURCE_AGGREGE_P2P_LIRE_UN = "pad3101RessourceAggregeP2PLireUn"; //$NON-NLS-1$
    String RESSOURCE_LIRE_TOUS_PAR_ID_RESSOURCE_LIE = "ressourceLireTousParIdRessourceLie"; //$NON-NLS-1$
    String FQDN_LIRE_UN = "fqdnLireUn"; //$NON-NLS-1$
    String PAD3203_OLT_CREATE = "pad3203OltCreate"; //$NON-NLS-1$
    String PAD3003_READ = "pad3003_IntegrationGroupeFichier_Read"; //$NON-NLS-1$
    String PAD3003_DELETE = "pad3003_IntegrationGroupeFichier_Delete"; //$NON-NLS-1$
    String PAD3003_UPDATE = "pad3003_IntegrationGroupeFichier_Update"; //$NON-NLS-1$
    String PAD3003_CREATE = "pad3003_IntegrationGroupeFichier"; //$NON-NLS-1$
    String PAD3001_CREATE = "pad3001_Commune_Create"; //$NON-NLS-1$
    String PORTE_DE_COLLECTE_GERER_IMPORT = "porteDeCollecteGererImport"; //$NON-NLS-1$
    String PORTE_DE_COLLECTE_GERER_SUPPRESSION = "porteDeCollecteGererSuppressionPorteDeCollecteNonReference"; //$NON-NLS-1$
    String RESSOURCE_PORTP2P_GERER_ALLOCATION = "ressourcePortP2PGererAllocation"; //$NON-NLS-1$
    String RESSOURCE_PORTP2P_MODIFIER_STATUT_ALLOCATION = "ressourcePortP2PModifierStatutAllocation"; //$NON-NLS-1$
    String RESSOURCES_MODIFIER_RESSOURCELIE = "ressourceModifierIdRessourceLie"; //$NON-NLS-1$
    String COUVERTURE_CUIVRE_LIRE_TOUS_PAR_ID_ADRESSE_BYTEL = "couvertureCuivreLireTousParIdAdresseBytel"; //$NON-NLS-1$
    String STRUCTURE_VERTICALE_FTTH_COMPOSITE_LIRE_TOUS_PAR_LISTE_OI_IMB = "structureVerticaleFtthCompositeLireTousParListeOIIMB"; //$NON-NLS-1$
    String STRUCTURE_VERTICALE_FTTH_COMPOSITE_CREER = "structureVerticaleFtthCompositeCreer"; //$NON-NLS-1$
    String COUVERTURE_CUIVRE_LIRE_UN_PAR_RIVOLI = "couvertureCuivreLireUnParRivoli"; //$NON-NLS-1$
    String COUVERTURE_FTTO_LIRE_UN = "couvertureFttoLireUn"; //$NON-NLS-1$
    String COUVERTURE_TOKYO_LIRE_UN = "couvertureTokyoLireUn"; //$NON-NLS-1$
    String COUVERTURE_FTTH_LIRE_TOUS_PAR_HEXACLE_INTERNE = "couvertureFtthLireTousParHexacleInterne"; //$NON-NLS-1$
    String COUVERTURE_FTTH_LIRE_TOUS_PAR_IMB = "couvertureFtthLireTousParIMB"; //$NON-NLS-1$
    String COUVERTURE_FTTH_LIRE_TOUS_PAR_ID_ADRESSE_BYTEL = "couvertureFtthLireTousParIdAdresseBytel"; //$NON-NLS-1$
    String COUVERTURE_5G_LIRE_UN = "couverture5gLireUn"; //$NON-NLS-1$
    String RESSOURCE_FTTH_LIRE_TOUS_PAR_REFERENCE_PM = "ressourceFtthLireTousParReferencePM"; //$NON-NLS-1$
    String RESSOURCE_PORT_P2P_COMPTER_PORT_LIBRE_P2P = "ressourcePortP2PcompterPortLibreP2P"; //$NON-NLS-1$
    String ACCES_TECHNIQUE_LIRE_TOUS = "accesTechniqueLireTous"; //$NON-NLS-1$
    String PAD3002_PREVISION_PROG_READ = "pad3002PrevisionProgRead"; //$NON-NLS-1$
    String PAD3002_PREVISION_PROG_CREATE = "pad3002PrevisionProgCreate"; //$NON-NLS-1$
    String PAD3001_COMMUNE_READ_ANCIEN_CODE_INSEE = "pad3001CommuneReadAncienCodeInsee"; //$NON-NLS-1$
    String PAD3001_COMMUNE_READ_CODE_INSEE = "pad3001CommuneReadCodeInsee"; //$NON-NLS-1$
    String PAD3001_COMMUNE_READ_CODE_POSTAL = "pad3001CommuneReadCodePostal"; //$NON-NLS-1$
    String TOPOLOGIE_ARCTURUS_LIRE_UN = "topologieArcturusLireUn"; //$NON-NLS-1$
    String TOPOLOGIE_ARCTURUS_LIRE_TOUS_PAR_IDEQPTACCES = "topologieArcturusLireTousParIdEqptAcces"; //$NON-NLS-1$
    String CACHE_ELIG_LIRE = "cacheEligLire"; //$NON-NLS-1$
    String CACHE_ELIG_CREER_LISTE = "cacheEligCreerListe"; //$NON-NLS-1$
    String DISPO_NRO_FTTE_ORG_LIRE = "dispoNroFtteOrgLire"; //$NON-NLS-1$
    String RESSOURCE_RACCORDEMENT_CREER = "ressourceRaccordementCreer"; //$NON-NLS-1$
    String DISPO_RESSOURCE_DSL_ORANGE_LIRE = "dispoRessourceDSLOrangeLire"; //$NON-NLS-1$
    String DISPO_RESSOURCE_DSL_ORANGE_LIRE_PAR_NOM_URA = "dispoRessourceDSLOrangeLireParNomUra"; //$NON-NLS-1$
    String DISPO_RESSOURCE_DSL_BOUYGUES_LIRE = "dispoRessourceDSLBouyguesLire"; //$NON-NLS-1$
    String DISPO_RESSOURCE_DSL_BOUYGUES_LIRE_PAR_NOM_URA = "dispoRessourceDSLBouyguesLireParNomUra"; //$NON-NLS-1$
    String DISPO_RESSOURCE_DSL_SFR_LIRE = "dispoRessourceDSLSFRLire"; //$NON-NLS-1$
    String DISPO_RESSOURCE_DSL_SFR_LIRE_PAR_NOM_URA = "dispoRessourceDSLSFRLireParNomUra"; //$NON-NLS-1$
    String DISPO_RESSOURCE_DSL_AXIONE_LIRE = "dispoRessourceDSLAxioneLire"; //$NON-NLS-1$
    String DISPO_RESSOURCE_DSL_AXIONE_LIRE_PAR_NOM_URA = "dispoRessourceDSLAxioneLireParNomUra"; //$NON-NLS-1$
    String ABAQUE_DSL_LIRE_TOUS = "abaqueDslLireTous"; //$NON-NLS-1$
    String ENTONNOIR_COMMUNE_LIRE_TOUS_PAR_CODE_POSTAL = "entonnoirCommuneLireTousParCodePostal"; //$NON-NLS-1$
    String ENTONNOIR_COMMUNE_LIRE_TOUS_PAR_DEPARTEMENT = "entonnoirCommuneLireTousParDepartement"; //$NON-NLS-1$
    String ENTONNOIR_COMMUNE_LIRE_TOUS_PAR_CODE_INSEE = "entonnoirCommuneLireTousParCodeInsee"; //$NON-NLS-1$
    String ENTONNOIR_VOIE_LIRE_TOUS_PAR_CODE_INSEE = "entonnoirVoieLireTousParCodeInsee"; //$NON-NLS-1$
    String ENTONNOIR_VOIE_LIRE_UN_PAR_CODE_INSEE_CODE_RIVOLI = "entonnoirVoieLireUnParCodeInseeCodeRivoli"; //$NON-NLS-1$
    String ENTONNOIR_VOIE_LIRE_UN_PAR_CODE_INSEE_SIMILI_HEXACLE_0 = "entonnoirVoieLireUnParCodeInseeSimiliHexacle0"; //$NON-NLS-1$
    String ENTONNOIR_NUMERO_LIRE_TOUS_PAR_CODE_INSEE_CODE_RIVOLI = "entonnoirNumeroLireTousParCodeInseeCodeRivoli"; //$NON-NLS-1$
    String ENTONNOIR_NUMERO_LIRE_TOUS_PAR_CODE_INSEE_SIMILI_HEXACLE_0 = "entonnoirNumeroLireTousParCodeInseeSimiliHexacle0"; //$NON-NLS-1$
    String COUVERTURE_GEO_CODAGE = "couvertureGeoCodage"; //$NON-NLS-1$
    String NOEUD_RACCORDEMENT_GERER_IMPORT = "noeudRaccordementGererImport"; //$NON-NLS-1$
    String NOEUD_RACCORDEMENT_GERER_SUPPRESSION_NR_NON_REFERENCE = "noeudRaccordementGererSuppressionNrNonReference"; //$NON-NLS-1$
    String PM_COMPOSITE_GERER_IMPORT = "pmCompositeGererImport"; //$NON-NLS-1$
    String PM_COMPOSITE_GERER_SUPPRESSION_OLT_NON_REFERENCE = "pmCompositeGererSuppressionOltNonReference"; //$NON-NLS-1$
    String PM_COMPOSITE_LIRE_UN_PAR_REFERENCE_PM_BYTEL = "pmCompositeLireUnParReferencePmBytel"; //$NON-NLS-1$
    String PM_COMPOSITE_MODIFIER_SURCHARGE_DATE_DEBUT_QUARANTAINE_PM = "pmCompositeModifierSurchargeDateDebutQuarantainePM"; //$NON-NLS-1$
    String PM_COMPOSITE_MODIFIER_SURCHARGE_EXPLOITATION_PORT_PM = "pmCompositeModifierSurchargeExploitationPortPM"; //$NON-NLS-1$
    String PM_COMPOSITE_MODIFIER_SURCHARGE_PRISE_CLIENT_BOITIER_PM = "pmCompositeModifierSurchargePriseClientBoitierPM"; //$NON-NLS-1$
    String PM_COMPOSITE_MODIFIER_SURCHARGE_PRISE_CLIENT_PM = "pmCompositeModifierSurchargePriseClientPM"; //$NON-NLS-1$
    String PM_COMPOSITE_MODIFIER_SURCHARGE_PRISE_CLIENT_PORT_PM = "pmCompositeModifierSurchargePriseClientPortPM"; //$NON-NLS-1$

    String OLT_COMPOSITE_GERER_IMPORT = "oltCompositeGererImport"; //$NON-NLS-1$
    String OLT_COMPOSITE_LIRE_UN = "oltCompositeLireUn"; //$NON-NLS-1$
    String OLT_COMPOSITE_GERER_SUPPRESSION_OLT_NON_REF = "oltCompositeGererSuppressionOltNonReference"; //$NON-NLS-1$
    String OLT_COMPOSITE_MODIFIER_SURCHARGE_DEBIT_GARANTI_PORT_PON = "oltCompositeModifierSurchargeDebitGarantiPortPon"; //$NON-NLS-1$
    String OLT_COMPOSITE_MODIFIER_SURCHARGE_EXPLOITATION_ONT_ID = "oltCompositeModifierSurchargeExploitationOntId"; //$NON-NLS-1$
    String OLT_COMPOSITE_MODIFIER_SURCHARGE_PRISE_CLIENT_CARTE = "oltCompositeModifierSurchargePriseClientCarte"; //$NON-NLS-1$
    String OLT_COMPOSITE_MODIFIER_SURCHARGE_PRISE_CLIENT_OLT = "oltCompositeModifierSurchargePriseClientOLT"; //$NON-NLS-1$
    String OLT_COMPOSITE_MODIFIER_SURCHARGE_PRISE_CLIENT_ONT_ID = "oltCompositeModifierSurchargePriseClientOntId"; //$NON-NLS-1$
    String OLT_COMPOSITE_MODIFIER_SURCHARGE_PRISE_CLIENT_PORT_PON = "oltCompositeModifierSurchargePriseClientPortPon"; //$NON-NLS-1$
    String OLT_COMPOSITE_MODIFIER_SURCHARGE_VERSION_OLT = "oltCompositeModifierSurchargeVersionOLT"; //$NON-NLS-1$
    String OLT_COMPOSITE_MODIFIER_SURCHARGE_DATE_DEBUT_QUARANTAINE_OLT = "oltCompositeModifierSurchargeDateDebutQuarantaineOLT"; //$NON-NLS-1$
    String OLT_COMPOSITE_MODIFIER_SURCHARGE_TECHNO_AUTORISEE_PORT_PON = "oltCompositeModifierSurchargeTechnoAutoriseePortPon"; //$NON-NLS-1$

    String RESSOURCE_PORT_PM_GERER_ALLOCATION = "ressourcePortPmGererAllocation"; //$NON-NLS-1$
    String RESSOURCE_RACCORDEMENT_MODIFIER_CODE_ACCESTECHNIQUE = "ressourceRaccordementModifierCodeAccesTechnique"; //$NON-NLS-1$
    String RESSOURCE_PORT_PM_GERER_MIGRATION = "ressourcePortPmGererMigrationPortPm"; //$NON-NLS-1$
    String POOL_IP_GERER_IMPORT = "poolIpGererImport"; //$NON-NLS-1$
    String POINT_ANCRAGE_IP_GERER_IMPORT = "pointAncrageIpGererImport"; //$NON-NLS-1$
    String POINT_ANCRAGE_IP_GERER_SUPPRESION_POINT_ANCRAGE_IP_NON_REFERENCE = "pointAncrageIpGererSuppressionPointAncrageIPNonReference"; //$NON-NLS-1$
    String RESSOURCE_RACCORDEMENT_MODIFIER_ONT_INSTALLE = "ressourceRaccordementModifierOntInstalle"; //$NON-NLS-1$
	String PAD3205_READ_ONE = "PAD3205_PmComposite.Read";
    String PORTE_DE_COLLECTE_LIRE_UN = "porteDeCollecteLireUn"; //$NON-NLS-1$
  }

  private interface IURL
  {
    /** Url for PAD3001 */
    String COMMUNE = "/ExecuteGenericRequestV2/commune"; //$NON-NLS-1$
    /** Url for PAD3002 */
    String PREVISION_PROGRAMME = "/ExecuteGenericRequestV2/previsionProgramme"; //$NON-NLS-1$
    /** Url for PAD3003 */
    String INTEGRATION_GROUPE_FICHIER = "/ExecuteGenericRequestV2/integrationGroupeFichier"; //$NON-NLS-1$
    /** Url for PAD3007 */
    String COUVERTURE_CUIVRE = "/ExecuteGenericRequestV2/couvertureCuivre"; //$NON-NLS-1$
    /** Url for PAD3008 */
    String COUVERTURE_FTTO = "/ExecuteGenericRequestV2/couvertureFtto"; //$NON-NLS-1$
    /** Url for PAD3009 */
    String COUVERTURE_TOKYO = "/ExecuteGenericRequestV2/couvertureTokyo"; //$NON-NLS-1$
    /** Url for PAD3010 */
    String COUVERTURE_FTTH = "/ExecuteGenericRequestV2/couvertureFtth"; //$NON-NLS-1$
    /** Url for PAD3011 */
    String RESSOURCE_FTTH = "/ExecuteGenericRequestV2/ressourceFtth"; //$NON-NLS-1$
    /** Url for PAD3015 */
    String COUVERTURE_5G = "/ExecuteGenericRequestV2/couverture5G"; //$NON-NLS-1$
    /** Url for PAD3012 */
    String STRUCTURE_VERTICALE_FTTH_COMPOSITE = "/ExecuteGenericRequestV2/structureVerticaleFtthComposite"; //$NON-NLS-1$
    /** Url for PAD3012 */
    String STRUCTURE_VERTICALE_FTTH_COMPOSITE_RECHERCHE = "/ExecuteGenericRequestV2/structureVerticaleFtthComposite/recherche"; //$NON-NLS-1$
    /** Url for PAD3013 */
    String TOPOLOGIE_ARCTURUS = "/ExecuteGenericRequestV2/topologieArcturus"; //$NON-NLS-1$
    /** Url for PAD3100 */
    String RESSOURCE = "/ExecuteGenericRequestV2/ressource"; //$NON-NLS-1$
    /** Url for PAD3110 */
    String RESSOURCE_RACCORDEMENT = "/ExecuteGenericRequestV2/ressourceRaccordement"; //$NON-NLS-1$
    /** Url for PAD3111 */
    String RESSOURCE_RACCORDEMENT_COMPOSITE = "/ExecuteGenericRequestV2/ressourceRaccordementComposite"; //$NON-NLS-1$
    /** Url for PAD3101 */
    String RESSOURCE_AGGREGE = "/ExecuteGenericRequestV2/ressourceAggrege"; //$NON-NLS-1$
    /** Url for PAD3200 */
    String OLT_COMPOSITE = "/ExecuteGenericRequestV2/oltComposite"; //$NON-NLS-1$
    /** Url for PAD3202 */
    String FQDN = "/ExecuteGenericRequestV2/fqdn"; //$NON-NLS-1$
    /** Url for PAD3203 */
    String OLT = "/ExecuteGenericRequestV2/olt"; //$NON-NLS-1$
    /** Url for PAD3014 */
    String DISPO_NRO_FTTE_ORG = "/ExecuteGenericRequestV2/dispoNroFtteOrg"; //$NON-NLS-1$
    /** Url for PAD3017 */
    String DISPO_RESSOURCE_DSL_ORANGE = "/ExecuteGenericRequestV2/dispoRessourceDSLOrange"; //$NON-NLS-1$
    /** Url for PAD3018 */
    String DISPO_RESSOURCE_DSL_BOUYGUES = "/ExecuteGenericRequestV2/dispoRessourceDSLBouygues"; //$NON-NLS-1$
    /** Url for PAD3019 */
    String DISPO_RESSOURCE_DSL_AXIONE = "/ExecuteGenericRequestV2/dispoRessourceDSLAxione"; //$NON-NLS-1$
    /** Url for PAD3020 */
    String DISPO_RESSOURCE_DSL_SFR = "/ExecuteGenericRequestV2/dispoRessourceDSLSFR"; //$NON-NLS-1$
    /** Url for PAD3021 */
    String ENTONNOIR_COMMUNE = "/ExecuteGenericRequestV2/entonnoirCommune"; //$NON-NLS-1$
    /** Url for PAD3022 */
    String ENTONNOIR_VOIE = "/ExecuteGenericRequestV2/entonnoirVoie"; //$NON-NLS-1$
    /** Url for PAD3023 */
    String ENTONNOIR_NUMERO = "/ExecuteGenericRequestV2/entonnoirNumero"; //$NON-NLS-1$
    /** Url for PAD3024 */
    String COUVERTURE_GEO_CODAGE = "/ExecuteGenericRequestV2/couvertureGeoCodage"; //$NON-NLS-1$
    /** Url for PAD3204 */
    String NOEUD_RACCORDEMENT = "/ExecuteGenericRequestV2/noeudRaccordement"; //$NON-NLS-1$
    /** Url for PAD3205 */
    String PM_COMPOSITE = "/ExecuteGenericRequestV2/pmComposite"; //$NON-NLS-1$
    /** Url for PAD3124 */
    String RESSOURCE_PORT_P2P = "/ExecuteGenericRequestV2/ressourcePortP2P"; //$NON-NLS-1$
    /** Url for PAD3127 */
    String RESSOURCE_PORT_PM = "/ExecuteGenericRequestV2/ressourcePortPM"; //$NON-NLS-1$
    /** Url for PAD3300 */
    String CACHE_ELIG = "/ExecuteGenericRequestV2/cacheElig"; //$NON-NLS-1$
    /** Url for PAD3207 */
    String POOL_IP = "/ExecuteGenericRequestV2/poolIP"; //$NON-NLS-1$
    /** Url for PAD3206 */
    String POINT_ANCRAGE_IP = "/ExecuteGenericRequestV2/pointAncrageIP"; //$NON-NLS-1$
    /** Url for PAD3208 */
    String PORTE_DE_COLLECTE = "/ExecuteGenericRequestV2/porteDeCollecte"; //$NON-NLS-1$
  }

  /** RES base path. */
  private static final String RES_BASE_PATH = "RES"; //$NON-NLS-1$

  /** */
  @Autowired
  @Qualifier(BouchonHttpConfig.RES_ENDPOINT_ADAPTER)
  private StaticResponseEndpointAdapter _resStaticEndpoint;

  @Autowired
  @Qualifier(BouchonHttpConfig.RES_ABAQUES_ENDPOINT_ADAPTER)
  private StaticResponseEndpointAdapter _resAbaquesStaticEndpoint;

  /** Transient expected RES server request. */
  private HttpServerRequestActionBuilder _serverRequest;

  /** Transient service. */
  private String _service;

  /**
   * Constructor
   */
  public ResHttpSteps()
  {
    super(RES_BASE_PATH);
  }

  /**
   * Expect request has given query param
   *
   * @param name_p
   *          query param name
   * @param value_p
   *          query param value
   */
  @And("RES query param ([^\"]*)=([^\"]*)$")
  public void expectQueryParam(String name_p, String value_p)
  {
    _serverRequest.queryParam(name_p, value_p);
  }

  /**
   * RES responds an error
   *
   * @param template_p
   *          relative template path
   */
  @Then("RES responds with ([^\"]*)$")
  public void okResponseAction(String template_p)
  {
    serverResponseActionOK(BouchonHttpConfig.RES_SERVER, templateResource(_service, RESPONSE_DIR, template_p));
  }

  @Given("RES abaqueDslLireTous will respond ([^\"]*)$")
  public void receiveAbaqueDslResponse(String template_p)
  {
    _service = IMethod.ABAQUE_DSL_LIRE_TOUS;
    _resAbaquesStaticEndpoint.setMessagePayloadResource(templateResource(_service, RESPONSE_DIR, template_p).getPath());
  }

  /**
   * Expect that RES receives an cacheEligCreerListe request.
   */
  @When("RES receives a cacheEligCreerListe request with ([^\"]*)$")
  public void receiveCacheEligCreerListeRequest(String template_p)
  {
    receiveRequest(IMethod.CACHE_ELIG_CREER_LISTE, template_p, false);
  }

  /**
   * Expect that RES receives an cacheEligLire request.
   */
  @When("RES receives a cacheEligLire request")
  public void receiveCacheEligLireRequest()
  {
    receiveRequest(IMethod.CACHE_ELIG_LIRE, null, false);
  }

  /**
   * Expect that RES receives a couverture5gLireUn request.
   */
  @When("RES receives a couverture5gLireUn request")
  public void receiveCouverture5gLireUn()
  {
    receiveRequest(IMethod.COUVERTURE_5G_LIRE_UN, null, false);
  }

  /** Expect that RES receives a couvertureCuivreLireUnParRivoli request. */
  @When("RES receives a couvertureCuivreLireTousParIdAdresseBytel request")
  public void receiveCouvertureCuivreLireTousParIdAdresseBytelRequest()
  {
    receiveRequest(IMethod.COUVERTURE_CUIVRE_LIRE_TOUS_PAR_ID_ADRESSE_BYTEL, null, false);
  }

  /** Expect that RES receives a couvertureCuivreLireUnParRivoli request. */
  @When("RES receives a couvertureCuivreLireUnParRivoli request")
  public void receiveCouvertureCuivreLireUnParRivoliRequest()
  {
    receiveRequest(IMethod.COUVERTURE_CUIVRE_LIRE_UN_PAR_RIVOLI, null, false);
  }

  /** Expect that RES receives a couvertureFtthLireTousParHexacleInterne request. */
  @When("RES receives a couvertureFtthLireTousParHexacleInterne request")
  public void receiveCouvertureFtthLireTousParHexacleInterneRequest()
  {
    receiveRequest(IMethod.COUVERTURE_FTTH_LIRE_TOUS_PAR_HEXACLE_INTERNE, null, false);
  }

  /** Expect that RES receives a couvertureFtthLireTousParIdAdresseBytel request. */
  @When("RES receives a couvertureFtthLireTousParIdAdresseBytel request")
  public void receiveCouvertureFtthLireTousParIdAdresseBytelRequest()
  {
    receiveRequest(IMethod.COUVERTURE_FTTH_LIRE_TOUS_PAR_ID_ADRESSE_BYTEL, null, false);
  }

  /** Expect that RES receives a couvertureFtthLireTousParIMB request. */
  @When("RES receives a couvertureFtthLireTousParIMB request")
  public void receivecouvertureFtthLireTousParIMBRequest()
  {
    receiveRequest(IMethod.COUVERTURE_FTTH_LIRE_TOUS_PAR_IMB, null, false);
  }

  /** Expect that RES receives a couvertureFttoLireUn request. */
  @When("RES receives a couvertureFttoLireUn request")
  public void receiveCouvertureFttoLireUnRequest()
  {
    receiveRequest(IMethod.COUVERTURE_FTTO_LIRE_UN, null, false);
  }

  /**
   * Expect that RES receives a couvertureGeoCodage request.
   */
  @When("RES receives a couvertureGeoCodage request")
  public void receiveCouvertureGeoCodageRequest()
  {
    receiveRequest(IMethod.COUVERTURE_GEO_CODAGE, null, false);
  }

  /** Expect that RES receives a couvertureTokyoLireUn request. */
  @When("RES receives a couvertureTokyoLireUn request")
  public void receiveCouvertureTokyoLireUnRequest()
  {
    receiveRequest(IMethod.COUVERTURE_TOKYO_LIRE_UN, null, false);
  }

  /**
   * Expect that RES receives an dispoNroFtteOrgLire request.
   */
  @When("RES receives a dispoNroFtteOrgLire request")
  public void receiveDispoNroFtteOrgLireRequest()
  {
    receiveRequest(IMethod.DISPO_NRO_FTTE_ORG_LIRE, null, false);
  }

  /**
   * Expect that RES receives an dispoRessourceDSLAxioneLireParNomUra request.
   */
  @When("RES receives a dispoRessourceDSLAxioneLireParNomUra request")
  public void receiveDispoRessourceDSLAxioneLireParNomUraRequest()
  {
    receiveRequest(IMethod.DISPO_RESSOURCE_DSL_AXIONE_LIRE_PAR_NOM_URA, null, false);
  }

  /**
   * Expect that RES receives an dispoRessourceDSLAxioneLire request.
   */
  @When("RES receives a dispoRessourceDSLAxioneLire request")
  public void receiveDispoRessourceDSLAxioneLireRequest()
  {
    receiveRequest(IMethod.DISPO_RESSOURCE_DSL_AXIONE_LIRE, null, false);
  }

  /**
   * Expect that RES receives an dispoRessourceDSLBouyguesLireParNomUra request.
   */
  @When("RES receives a dispoRessourceDSLBouyguesLireParNomUra request")
  public void receiveDispoRessourceDSLBouyguesLireParNomUraRequest()
  {
    receiveRequest(IMethod.DISPO_RESSOURCE_DSL_BOUYGUES_LIRE_PAR_NOM_URA, null, false);
  }

  /**
   * Expect that RES receives an dispoRessourceDSLBouyguesLire request.
   */
  @When("RES receives a dispoRessourceDSLBouyguesLire request")
  public void receiveDispoRessourceDSLBouyguesLireRequest()
  {
    receiveRequest(IMethod.DISPO_RESSOURCE_DSL_BOUYGUES_LIRE, null, false);
  }

  /**
   * Expect that RES receives an dispoRessourceDSLOrangeLireParNomUra request.
   */
  @When("RES receives a dispoRessourceDSLOrangeLireParNomUra request")
  public void receiveDispoRessourceDslOrangeLireParNomUraRequest()
  {
    receiveRequest(IMethod.DISPO_RESSOURCE_DSL_ORANGE_LIRE_PAR_NOM_URA, null, false);
  }

  /**
   * Expect that RES receives an dispoRessourceDSLOrangeLire request.
   */
  @When("RES receives a dispoRessourceDSLOrangeLire request")
  public void receiveDispoRessourceDslOrangeLireRequest()
  {
    receiveRequest(IMethod.DISPO_RESSOURCE_DSL_ORANGE_LIRE, null, false);
  }

  /**
   * Expect that RES receives an dispoRessourceDSLSFRLireParNomUra request.
   */
  @When("RES receives a dispoRessourceDSLSFRLireParNomUra request")
  public void receiveDispoRessourceDSLSFRLireParNomUraRequest()
  {
    receiveRequest(IMethod.DISPO_RESSOURCE_DSL_SFR_LIRE_PAR_NOM_URA, null, false);
  }

  /**
   * Expect that RES receives an dispoRessourceDSLSFRLire request.
   */
  @When("RES receives a dispoRessourceDSLSFRLire request")
  public void receiveDispoRessourceDSLSFRLireRequest()
  {
    receiveRequest(IMethod.DISPO_RESSOURCE_DSL_SFR_LIRE, null, false);
  }

  /**
   * Expect that RES receives an entonnoirCommuneLireTousParCodeInsee request.
   */
  @When("RES receives a entonnoirCommuneLireTousParCodeInsee request")
  public void receiveEntonnoirCommuneLireTousParCodeInseeRequest()
  {
    receiveRequest(IMethod.ENTONNOIR_COMMUNE_LIRE_TOUS_PAR_CODE_INSEE, null, false);
  }

  /**
   * Expect that RES receives an dispoRessourceDslOrangeLireParNomUra request.
   */
  @When("RES receives a entonnoirCommuneLireTousParCodePostal request")
  public void receiveEntonnoirCommuneLireTousParCodePostalRequest()
  {
    receiveRequest(IMethod.ENTONNOIR_COMMUNE_LIRE_TOUS_PAR_CODE_POSTAL, null, false);
  }

  /**
   * Expect that RES receives an entonnoirCommuneLireTousParDepartement request.
   */
  @When("RES receives a entonnoirCommuneLireTousParDepartement request")
  public void receiveEntonnoirCommuneLireTousParDepartementRequest()
  {
    receiveRequest(IMethod.ENTONNOIR_COMMUNE_LIRE_TOUS_PAR_DEPARTEMENT, null, false);
  }

  /**
   * Expect that RES receives an entonnoirNumeroLireTousParCodeInseeCodeRivoli request.
   */
  @When("RES receives a entonnoirNumeroLireTousParCodeInseeCodeRivoli request")
  public void receiveEntonnoirNumeroLireTousParCodeInseeCodeRivoliRequest()
  {
    receiveRequest(IMethod.ENTONNOIR_NUMERO_LIRE_TOUS_PAR_CODE_INSEE_CODE_RIVOLI, null, false);
  }

  /**
   * Expect that RES receives an entonnoirNumeroLireTousParCodeInseeSimiliHexacle0 request.
   */
  @When("RES receives a entonnoirNumeroLireTousParCodeInseeSimiliHexacle0 request")
  public void receiveEntonnoirNumeroLireTousParCodeInseeSimiliHexacle0Request()
  {
    receiveRequest(IMethod.ENTONNOIR_NUMERO_LIRE_TOUS_PAR_CODE_INSEE_SIMILI_HEXACLE_0, null, false);
  }

  /**
   * Expect that RES receives an entonnoirVoieLireTousParCodeInsee request.
   */
  @When("RES receives a entonnoirVoieLireTousParCodeInsee request")
  public void receiveEntonnoirVoieLireTousParCodeInseeRequest()
  {
    receiveRequest(IMethod.ENTONNOIR_VOIE_LIRE_TOUS_PAR_CODE_INSEE, null, false);
  }

  /**
   * Expect that RES receives an entonnoirVoieLireUnParCodeInseeCodeRivoli request.
   */
  @When("RES receives a entonnoirVoieLireUnParCodeInseeCodeRivoli request")
  public void receiveEntonnoirVoieLireUnParCodeInseeCodeRivoliRequest()
  {
    receiveRequest(IMethod.ENTONNOIR_VOIE_LIRE_UN_PAR_CODE_INSEE_CODE_RIVOLI, null, false);
  }

  /**
   * Expect that RES receives an entonnoirVoieLireUnParCodeInseeSimiliHexacle0 request.
   */
  @When("RES receives a entonnoirVoieLireUnParCodeInseeSimiliHexacle0 request")
  public void receiveEntonnoirVoieLireUnParCodeInseeSimiliHexacle0Request()
  {
    receiveRequest(IMethod.ENTONNOIR_VOIE_LIRE_UN_PAR_CODE_INSEE_SIMILI_HEXACLE_0, null, false);
  }

  /**
   * Expect that RES receives an fqdnLireUn request.
   */
  @When("RES receives a fqdnLireUn request")
  public void receiveFqdnLireUnRequest()
  {
    receiveRequest(IMethod.FQDN_LIRE_UN, null, false);
  }

  /** Expect that RES receives a integrationGroupeFichier request. */
  @When("RES receives a integrationGroupeFichier request")
  public void receiveintegrationGroupeFichier()
  {
    receiveRequest(IMethod.PAD3003_READ, null, false);
  }

  /** Expect that RES receives a noeudRaccordementGererImport request. */
  @When("RES receives a noeudRaccordementGererImport request with ([^\"]*)$")
  public void receiveNoeudRaccordementGererImportRequest(String template_p)
  {
    receiveRequest(IMethod.NOEUD_RACCORDEMENT_GERER_IMPORT, template_p, false);
  }

  /** Expect that RES receives a noeudRaccordementGererSuppressionNrNonReference request. */
  @When("RES receives a noeudRaccordementGererSuppressionNrNonReference request with ([^\"]*)$")
  public void receiveNoeudRaccordementGererSuppressionNrNonReferenceRequest(String template_p)
  {
    receiveRequest(IMethod.NOEUD_RACCORDEMENT_GERER_SUPPRESSION_NR_NON_REFERENCE, template_p, false);
  }

  /**
   * Expect that RES receives an oltCompositeLireUn request.
   */
  @When("^RES receives a oltCompositeLireUn request with ([^\"]*)$")
  public void receiveOltCompositeGererImport(String template_p)
  {
    receiveRequest(IMethod.OLT_COMPOSITE_LIRE_UN, template_p, false);
  }

  /**
   * Expect that RES receives an oltCompositeGererImport request.
   */
  @When("RES receives an oltCompositeGererImport request with ([^\"]*)$")
  public void receiveOltCompositeGererImportRequest(String template_p)
  {
    receiveRequest(IMethod.OLT_COMPOSITE_GERER_IMPORT, template_p, false);
  }

  /**
   * Expect that RES receives a porteDeCollecteGererImport request.
   */
  @When("RES receives a porteDeCollecteGererImport request with ([^\"]*)$")
  public void receivePorteDeCollecteGererImport(String template_p)
  {
    receiveRequest(IMethod.PORTE_DE_COLLECTE_GERER_IMPORT, template_p, false);
  }

  /**
   * Expect that RES receives a porteDeCollecteGererSuppressionPorteDeCollecteNonReference request.
   */
  @When("RES receives a porteDeCollecteGererSuppressionPorteDeCollecteNonReference request with ([^\"]*)$")
  public void receivePorteDeCollecteGererSuppressionPorteDeCollecteNonReference(String template_p)
  {
    receiveRequest(IMethod.PORTE_DE_COLLECTE_GERER_SUPPRESSION, template_p, false);
  }

  /**
   * Expect that RES receives an oltCompositeGererSuppressionOltNonReference request.
   */
  @When("RES receives an oltCompositeGererSuppressionOltNonReference request with ([^\"]*)$")
  public void receiveOltCompositeGererSuppressionOltNonReference(String template_p)
  {
    receiveRequest(IMethod.OLT_COMPOSITE_GERER_SUPPRESSION_OLT_NON_REF, template_p, false);
  }

  /**
   * Expect that RES receives an oltCompositeLireUn request.
   */
  @When("RES receives a oltCompositeLireUn request$")
  public void receiveOltCompositeLireUnRequest()
  {
    receiveRequest(IMethod.OLT_COMPOSITE_LIRE_UN, null, false);
  }

  /**
   * Expect that RES receives an oltCompositeModifierSurchargeDateDebutQuarantaineOLT request.
   */
  @When("RES receives a oltCompositeModifierSurchargeDateDebutQuarantaineOLT request$")
  public void receiveOltCompositeModifierSurchargeDateDebutQuarantaineOLT()
  {
    receiveRequest(IMethod.OLT_COMPOSITE_MODIFIER_SURCHARGE_DATE_DEBUT_QUARANTAINE_OLT, null, false);
  }

  /**
   * Expect that RES receives an oltCompositeModifierSurchargeDebitGarantiPortPon request.
   */
  @When("RES receives a oltCompositeModifierSurchargeDebitGarantiPortPon request$")
  public void receiveOltCompositeModifierSurchargeDebitGarantiPortPon()
  {
    receiveRequest(IMethod.OLT_COMPOSITE_MODIFIER_SURCHARGE_DEBIT_GARANTI_PORT_PON, null, false);
  }

  /**
   * Expect that RES receives an oltCompositeModifierSurchargeExploitationOntId request.
   */
  @When("RES receives a oltCompositeModifierSurchargeExploitationOntId request$")
  public void receiveOltCompositeModifierSurchargeExploitationOntId()
  {
    receiveRequest(IMethod.OLT_COMPOSITE_MODIFIER_SURCHARGE_EXPLOITATION_ONT_ID, null, false);
  }

  /**
   * Expect that RES receives an oltCompositeModifierSurchargePriseClientCarte request.
   */
  @When("RES receives a oltCompositeModifierSurchargePriseClientCarte request$")
  public void receiveOltCompositeModifierSurchargePriseClientCarte()
  {
    receiveRequest(IMethod.OLT_COMPOSITE_MODIFIER_SURCHARGE_PRISE_CLIENT_CARTE, null, false);
  }

  /**
   * Expect that RES receives an oltCompositeModifierSurchargePriseClientOLT request.
   */
  @When("RES receives a oltCompositeModifierSurchargePriseClientOLT request$")
  public void receiveOltCompositeModifierSurchargePriseClientOLT()
  {
    receiveRequest(IMethod.OLT_COMPOSITE_MODIFIER_SURCHARGE_PRISE_CLIENT_OLT, null, false);
  }

  /**
   * Expect that RES receives an oltCompositeModifierSurchargePriseClientOntId request.
   */
  @When("RES receives a oltCompositeModifierSurchargePriseClientOntId request$")
  public void receiveOltCompositeModifierSurchargePriseClientOntId()
  {
    receiveRequest(IMethod.OLT_COMPOSITE_MODIFIER_SURCHARGE_PRISE_CLIENT_ONT_ID, null, false);
  }

  /**
   * Expect that RES receives an oltCompositeModifierSurchargePriseClientPortPon request.
   */
  @When("RES receives a oltCompositeModifierSurchargePriseClientPortPon request$")
  public void receiveOltCompositeModifierSurchargePriseClientPortPon()
  {
    receiveRequest(IMethod.OLT_COMPOSITE_MODIFIER_SURCHARGE_PRISE_CLIENT_PORT_PON, null, false);
  }

  /**
   * Expect that RES receives an oltCompositeModifierSurchargeTechnoAutoriseePortPon request.
   */
  @When("RES receives an oltCompositeModifierSurchargeTechnoAutoriseePortPon request with ([^\"]*)$")
  public void receiveOltCompositeModifierSurchargeTechnoAutoriseePortPon(String template_p)
  {
    receiveRequest(IMethod.OLT_COMPOSITE_MODIFIER_SURCHARGE_TECHNO_AUTORISEE_PORT_PON, template_p, false);
  }

  /**
   * Expect that RES receives an oltCompositeModifierSurchargeVersionOLT request.
   */
  @When("RES receives a oltCompositeModifierSurchargeVersionOLT request$")
  public void receiveOltCompositeModifierSurchargeVersionOLT()
  {
    receiveRequest(IMethod.OLT_COMPOSITE_MODIFIER_SURCHARGE_VERSION_OLT, null, false);
  }

  /**
   * Expect that RES receives a pad3001CommuneCreate request.
   */
  @When("RES receives an pad3001CommuneCreate request with ([^\"]*)$")
  public void receivePad3001CommuneCreate(String template_p)
  {
    receiveRequest(IMethod.PAD3001_CREATE, template_p, false);
  }

  /**
   * Expect that RES receives a pad3001CommuneReadAncienCodeInsee request.
   */
  @When("RES receives a pad3001CommuneReadAncienCodeInsee request")
  public void receivePad3001CommuneReadAncienCodeInsee()
  {
    receiveRequest(IMethod.PAD3001_COMMUNE_READ_ANCIEN_CODE_INSEE, null, false);
  }

  /**
   * Expect that RES receives a pad3001CommuneReadCodeInsee request.
   */
  @When("RES receives a pad3001CommuneReadCodeInsee request")
  public void receivePad3001CommuneReadCodeInsee()
  {
    receiveRequest(IMethod.PAD3001_COMMUNE_READ_CODE_INSEE, null, false);
  }

  /**
   * Expect that RES receives a pad3001CommuneReadCodePostal request.
   */
  @When("RES receives a pad3001CommuneReadCodePostal request")
  public void receivePad3001CommuneReadCodePostal()
  {
    receiveRequest(IMethod.PAD3001_COMMUNE_READ_CODE_POSTAL, null, false);
  }

  /**
   * Expect that RES receives a pad3002PrevisionProgCreate request.
   */
  @When("RES receives a pad3002PrevisionProgCreate request")
  public void receivePad3002PrevisionProgCreate()
  {
    receiveRequest(IMethod.PAD3002_PREVISION_PROG_CREATE, null, false);
  }

  /**
   * Expect that RES receives a pad3002PrevisionProgRead request.
   */
  @When("RES receives a pad3002PrevisionProgRead request")
  public void receivePad3002PrevisionProgRead()
  {
    receiveRequest(IMethod.PAD3002_PREVISION_PROG_READ, null, false);
  }

  /** Expect that RES receives a pad3003_IntegrationGroupeFichier request. */
  @When("RES receives a pad3003_IntegrationGroupeFichierCreate request with ([^\"]*)$")
  public void receivepad3003IntegrationGroupeFichier(String template_p)
  {
    receiveRequest(IMethod.PAD3003_CREATE, template_p, false);
  }

  /** Expect that RES receives a integrationGroupeFichier request. */
  @When("RES receives a pad3003_IntegrationGroupeFichier_Delete request")
  public void receivepad3003IntegrationGroupeFichierDelete()
  {
    receiveRequest(IMethod.PAD3003_DELETE, null, false);
  }

  /** Expect that RES receives a pad3003IntegrationGroupeFichierUpdate request. */
  @When("RES receives a pad3003IntegrationGroupeFichierUpdate request")
  public void receivePad3003IntegrationGroupeFichierUpdate()
  {
    receiveRequest(IMethod.PAD3003_UPDATE, null, false);
  }

  /**
   * Expect that RES receives an pad3101RessourceAggregeP2PLireUn request.
   */
  @When("RES receives a pad3101RessourceAggregeP2PLireUn request")
  public void receivePad3101RessourceAggregeP2PLireUnRequest()
  {
    receiveRequest(IMethod.PAD3101_RESSOURCE_AGGREGE_P2P_LIRE_UN, null, false);
  }

  /**
   * Expect that RES receives an pad3203OltLireTousFiltreNomOlt request.
   */
  @When("^RES receives a pad3203OltLireTousFiltreNomOlt request with ([^\"]*)$")
  @Deprecated
  public void receivePad3203OltLireTousFiltreNomOltRequest(String template_p)
  {
    receiveRequest(IMethod.PAD3203_OLT_CREATE, template_p, false);
  }

  @When("RES receives a pad3205PmCompositeLireUn request")
  public void receivePad3205PMCompositePLireUnRequest()
  {
    this.receiveRequest(IMethod.PAD3205_READ_ONE, (String) null, false);
  }

  /**
   * Expect that RES receives a pmCompositeGererImport request.
   *
   * @param template_p
   *          the path to the template.
   */
  @When("RES receives a pmCompositeGererImport request with ([^\"]*)$")
  public void receivePmCompositeGererImportRequest(String template_p)
  {
    receiveRequest(IMethod.PM_COMPOSITE_GERER_IMPORT, template_p, false);
  }

  /**
   * Expect that RES receives a pmCompositeGererSuppressionOltNonReference request.
   *
   * @param template_p
   *          the path to the template.
   */
  @When("RES receives a pmCompositeGererSuppressionOltNonReference request with ([^\"]*)$")
  public void receivePmCompositeGererSuppressionOltNonReferenceRequest(String template_p)
  {
    receiveRequest(IMethod.PM_COMPOSITE_GERER_SUPPRESSION_OLT_NON_REFERENCE, template_p, false);
  }

  /**
   * Expect that RES receives an pmCompositeLireUnParReferencePmBytel request.
   */
  @When("RES receives a pmCompositeLireUnParReferencePmBytel request$")
  public void receivePmCompositeLireUnParReferencePmBytelRequest()
  {
    receiveRequest(IMethod.PM_COMPOSITE_LIRE_UN_PAR_REFERENCE_PM_BYTEL, null, false);
  }

  /** Expect that RES receives a pointAncrageIpGererImport request. */
  @When("RES receives a pointAncrageIpGererImport request with ([^\"]*)$")
  public void receivepointAncrageIpGererImportRequest(String template_p)
  {
    receiveRequest(IMethod.POINT_ANCRAGE_IP_GERER_IMPORT, template_p, false);
  }

  /** Expect that RES receives a pointAncrageIpGererSuppressionPointAncrageIPNonReference request. */
  @When("RES receives a pointAncrageIpGererSuppressionPointAncrageIPNonReference request with ([^\"]*)$")
  public void receivepointAncrageIpGererSuppressionPointAncrageIPNonReferenceRequest(String template_p)
  {
    receiveRequest(IMethod.POINT_ANCRAGE_IP_GERER_SUPPRESION_POINT_ANCRAGE_IP_NON_REFERENCE, template_p, false);
  }

  /** Expect that RES receives a poolIpGererImport request. */
  @When("RES receives a poolIpGererImport request with ([^\"]*)$")
  public void receivepoolIpGererImportRequest(String template_p)
  {
    receiveRequest(IMethod.POOL_IP_GERER_IMPORT, template_p, false);
  }

  /**
   * Expect that RES receives an pmCompositeModifierSurchargeDateDebutQuarantainePM request.
   */
  @When("RES receives a pmCompositeModifierSurchargeDateDebutQuarantainePM request$")
  public void receivePmCompositeModifierSurchargeDateDebutQuarantainePM()
  {
    receiveRequest(IMethod.PM_COMPOSITE_MODIFIER_SURCHARGE_DATE_DEBUT_QUARANTAINE_PM, null, false);
  }

  /**
   * Expect that RES receives an pmCompositeModifierSurchargeExploitationPortPM request.
   */
  @When("RES receives a pmCompositeModifierSurchargeExploitationPortPM request$")
  public void receivePmCompositeModifierSurchargeExploitationPortPM()
  {
    receiveRequest(IMethod.PM_COMPOSITE_MODIFIER_SURCHARGE_EXPLOITATION_PORT_PM, null, false);
  }

  /**
   * Expect that RES receives an pmCompositeModifierSurchargePriseClientBoitierPM request.
   */
  @When("RES receives a pmCompositeModifierSurchargePriseClientBoitierPM request$")
  public void receivePmCompositeModifierSurchargePriseClientBoitierPM()
  {
    receiveRequest(IMethod.PM_COMPOSITE_MODIFIER_SURCHARGE_PRISE_CLIENT_BOITIER_PM, null, false);
  }

  /**
   * Expect that RES receives an pmCompositeModifierSurchargePriseClientPM request.
   */
  @When("RES receives a pmCompositeModifierSurchargePriseClientPM request$")
  public void receivePmCompositeModifierSurchargePriseClientPM()
  {
    receiveRequest(IMethod.PM_COMPOSITE_MODIFIER_SURCHARGE_PRISE_CLIENT_PM, null, false);
  }

  /**
   * Expect that RES receives an pmCompositeModifierSurchargePriseClientPortPM request.
   */
  @When("RES receives a pmCompositeModifierSurchargePriseClientPortPM request$")
  public void receivePmCompositeModifierSurchargePriseClientPortPM()
  {
    receiveRequest(IMethod.PM_COMPOSITE_MODIFIER_SURCHARGE_PRISE_CLIENT_PORT_PM, null, false);
  }

  /**
   * RES response for accesTechniqueLireTous.
   *
   * @param template_p
   *          static response
   */
  @Given("RES accesTechniqueLireTous will respond ([^\"]*)$")
  public void receiveResponse(String template_p)
  {
    _service = IMethod.ACCES_TECHNIQUE_LIRE_TOUS;
    _resStaticEndpoint.setMessagePayloadResource(templateResource(_service, RESPONSE_DIR, template_p).getPath());
  }

  /** Expect that RES receives a ressourceFtthLireTousParReferencePM request. */
  @When("RES receives a ressourceFtthLireTousParReferencePM request")
  public void receiveRessourceFtthLireTousParReferencePM()
  {
    receiveRequest(IMethod.RESSOURCE_FTTH_LIRE_TOUS_PAR_REFERENCE_PM, null, false);
  }

  /**
   * Expect that RES receives an ressourceLireTousParIdRessourceLie request.
   */
  @When("RES receives a ressourceLireTousParIdRessourceLie request")
  public void receiveRessourceLireTousParIdRessourceLieRequest()
  {
    receiveRequest(IMethod.RESSOURCE_LIRE_TOUS_PAR_ID_RESSOURCE_LIE, null, false);
  }

  /**
   * Expect that RES receives an ressourceLireUn request.
   */
  @When("RES receives a ressourceLireUn request")
  public void receiveRessourceLireUnRequest()
  {
    receiveRequest(IMethod.RESSOURCE_LIRE_UN, null, false);
  }

  /**
   * Expect that RES receives an ressourcemodifierIdRessourceLie request.
   */
  @When("RES receives a ressourceModifierIdRessourceLie request$")
  public void receiveRessourceModifierIdRessourceLieRequest()
  {
    receiveRequest(IMethod.RESSOURCES_MODIFIER_RESSOURCELIE, null, false);
  }

  /**
   * Expect that RES receives a RessourcePortP2PModifierStatutAllocation request.
   */
  @When("^RES receives a ressourcePortP2PcompterPortLibreP2P request$")
  public void receiveRessourcePortP2PcompterPortLibreP2PRequest()
  {
    receiveRequest(IMethod.RESSOURCE_PORT_P2P_COMPTER_PORT_LIBRE_P2P, null, false);
  }

  /**
   * Expect that RES receives a RessourcePortP2PGererAllocation request.
   */
  @When("RES receives a ressourcePortP2PGererAllocation request$")
  public void receiveRessourcePortP2PGererAllocationRequest()
  {
    receiveRequest(IMethod.RESSOURCE_PORTP2P_GERER_ALLOCATION, null, false);
  }

  /**
   * Expect that RES receives a RessourcePortP2PModifierStatutAllocation request.
   */
  @When("RES receives a ressourcePortP2PModifierStatutAllocation request$")
  public void receiveRessourcePortP2PModifierStatutAllocationRequest()
  {
    receiveRequest(IMethod.RESSOURCE_PORTP2P_MODIFIER_STATUT_ALLOCATION, null, false);
  }

  /**
   * Expect that RES receives a ressourceRaccordementModifierStatutAllocation request.
   */
  @When("RES receives a ressourcePortPmGererAllocation request")
  public void receiveRessourcePortPmGererAllocationRequest()
  {
    receiveRequest(IMethod.RESSOURCE_PORT_PM_GERER_ALLOCATION, null, false);
  }

  /**
   * Expect that RES receives a ressourceRaccordementModifierStatutAllocation request.
   */
  @When("RES receives a ressourcePortPmGererMigrationPortPm request")
  public void receiveRessourcePortPmGererMigrationPortPmRequest()
  {
    receiveRequest(IMethod.RESSOURCE_PORT_PM_GERER_MIGRATION, null, false);
  }

  /**
   * Expect that RES receives an ressourceRaccordementCompositeLireUn request.
   */
  @When("RES receives a ressourceRaccordementCompositeLireUn request")
  public void receiveRessourceRaccordementCompositeLireUnRequest()
  {
    receiveRequest(IMethod.RESSOURCE_RACCORDEMENT_COMPOSITE_LIRE_UN, null, false);
  }

  /** Expect that RES receives an ressourceRaccordementCreer request. */
  @When("RES receives a ressourceRaccordementCreer request with ([^\"]*)$")
  public void receiveRessourceRaccordementCreerRequest(String template_p)
  {
    receiveRequest(IMethod.RESSOURCE_RACCORDEMENT_CREER, template_p, false);
  }

  /**
   * Expect that RES receives a ressourceRaccordementModifierCodeAccesTechnique request.
   */
  @When("RES receives a ressourceRaccordementModifierCodeAccesTechnique request")
  public void receiveRessourceRaccordementModifierCodeAccesTechniqueRequest()
  {
    receiveRequest(IMethod.RESSOURCE_RACCORDEMENT_MODIFIER_CODE_ACCESTECHNIQUE, null, false);
  }

  /**
   * Expect that RES receives a ressourceRaccordementModifierOntInstalle request.
   */
  @When("RES receives a ressourceRaccordementModifierOntInstalle request")
  public void receiveRessourceRaccordementModifierOntInstalleRequest()
  {
    receiveRequest(IMethod.RESSOURCE_RACCORDEMENT_MODIFIER_ONT_INSTALLE, null, false);
  }

  /**
   * Expect that RES receives a ressourceRaccordementModifierStatutAllocation request.
   */
  @When("RES receives a ressourceRaccordementModifierStatutAllocation request")
  public void receiveRessourceRaccordementModifierStatutAllocationRequest()
  {
    receiveRequest(IMethod.RESSOURCE_RACCORDEMENT_MODIFIER_STATUT_ALLOCATION, null, false);
  }

  /** Expect that RES receives a structureVerticaleFtthCompositeCreer request. */
  @When("RES receives a structureVerticaleFtthCompositeCreer request with ([^\"]*)$")
  public void receiveStructureVerticaleFtthCompositeCreerRequest(String template_p)
  {
    receiveRequest(IMethod.STRUCTURE_VERTICALE_FTTH_COMPOSITE_CREER, template_p, false);
  }

  /** Expect that RES receives a structureVerticaleFtthCompositeLireTousParListeOIIMB request. */
  @When("RES receives a structureVerticaleFtthCompositeLireTousParListeOIIMB request with ([^\"]*)$")
  public void receiveStructureVerticaleFtthCompositeLireTousParListeOIIMBRequest(String template_p)
  {
    receiveRequest(IMethod.STRUCTURE_VERTICALE_FTTH_COMPOSITE_LIRE_TOUS_PAR_LISTE_OI_IMB, template_p, false);
  }

  /**
   * Expect that RES receives an topologieArcturusLireTousParIdEqptAcces request.
   */
  @When("RES receives a topologieArcturusLireTousParIdEqptAcces request")
  public void receiveTopologieArcturusLireTousParIdEqptAcces()
  {
    receiveRequest(IMethod.TOPOLOGIE_ARCTURUS_LIRE_TOUS_PAR_IDEQPTACCES, null, false);
  }

  /**
   * Expect that RES receives an topologieArcturusLireUn request.
   */
  @When("RES receives a topologieArcturusLireUn request")
  public void receiveTopologieArcturusLireUnRequest()
  {
    receiveRequest(IMethod.TOPOLOGIE_ARCTURUS_LIRE_UN, null, false);
  }

  /**
   * Expect that RES receives an porteDeCollecteLireUn request.
   */
  @When("RES receives a porteDeCollecteLireUn request")
  public void receivePorteDeCollecteLireUnRequest()
  {
    receiveRequest(IMethod.PORTE_DE_COLLECTE_LIRE_UN, null, false);
  }

  /**
   * RES responds a status
   *
   * @param template_p
   *          relative template path
   */
  @Then("RES responds status (\\d+) with ([^\"]*)$")
  public void responseAction(Integer codeHttp_p, String template_p)
  {
    serverResponseAction(BouchonHttpConfig.RES_SERVER, codeHttp_p, templateResource(_service, RESPONSE_DIR, template_p));
  }

  /**
   * Generic method to receive the request
   *
   * @param method_p
   *          method name to call
   * @param template_p
   *          template file name
   */
  private void receiveRequest(String method_p, String template_p, boolean isControlHeaders_p)
  {
    _service = method_p;

    switch (_service)
    {
      // URL STRUCTURE_VERTICALE_FTTH_COMPOSITE_RECHERCHE PAD3012
      case IMethod.STRUCTURE_VERTICALE_FTTH_COMPOSITE_LIRE_TOUS_PAR_LISTE_OI_IMB:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.RES_SERVER).receive()//
            .post(IURL.STRUCTURE_VERTICALE_FTTH_COMPOSITE_RECHERCHE) //
            .payload(templateResource(_service, REQUEST_DIR, template_p));
        break;

      // URL STRUCTURE_VERTICALE_FTTH_COMPOSITE PAD3012
      case IMethod.STRUCTURE_VERTICALE_FTTH_COMPOSITE_CREER:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.RES_SERVER).receive()//
            .post(IURL.STRUCTURE_VERTICALE_FTTH_COMPOSITE) //
            .payload(templateResource(_service, REQUEST_DIR, template_p));
        break;

      // URL_OLT PAD3203
      case IMethod.PAD3203_OLT_CREATE:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.RES_SERVER).receive()//
            .post(IURL.OLT) //
            .payload(templateResource(_service, REQUEST_DIR, template_p));
        break;

      // URL_RESSOURCE PAD3100
      case IMethod.RESSOURCES_MODIFIER_RESSOURCELIE:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.RES_SERVER)//
            .receive()//
            .put(IURL.RESSOURCE);
        break;
      case IMethod.RESSOURCE_LIRE_UN:
      case IMethod.RESSOURCE_LIRE_TOUS_PAR_ID_RESSOURCE_LIE:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.RES_SERVER)//
            .receive()//
            .get(IURL.RESSOURCE);
        break;

      // URL_RESSOURCE_RACCORDEMENT_COMPOSITE PAD3111
      case IMethod.RESSOURCE_RACCORDEMENT_COMPOSITE_LIRE_UN:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.RES_SERVER)//
            .receive()//
            .get(IURL.RESSOURCE_RACCORDEMENT_COMPOSITE);
        break;

      // URL_RESSOURCE_RACCORDEMENT PAD3110
      case IMethod.RESSOURCE_RACCORDEMENT_CREER:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.RES_SERVER)//
            .receive()//
            .post(IURL.RESSOURCE_RACCORDEMENT) //
            .payload(templateResource(_service, REQUEST_DIR, template_p));
        break;
      case IMethod.RESSOURCE_RACCORDEMENT_MODIFIER_STATUT_ALLOCATION:
      case IMethod.RESSOURCE_RACCORDEMENT_MODIFIER_CODE_ACCESTECHNIQUE:
      case IMethod.RESSOURCE_RACCORDEMENT_MODIFIER_ONT_INSTALLE:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.RES_SERVER)//
            .receive()//
            .put(IURL.RESSOURCE_RACCORDEMENT);
        break;

      // URL_PREVISION_PROGRAMME PAD3002
      case IMethod.PAD3002_PREVISION_PROG_READ:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.RES_SERVER)//
            .receive()//
            .get(IURL.PREVISION_PROGRAMME);
        break;
      case IMethod.PAD3002_PREVISION_PROG_CREATE:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.RES_SERVER)//
            .receive()//
            .post(IURL.PREVISION_PROGRAMME);
        break;

      // URL_COMMUNE PAD3001
      case IMethod.PAD3001_CREATE:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.RES_SERVER)//
            .receive()//
            .post(IURL.COMMUNE) //
            .payload(templateResource(_service, REQUEST_DIR, template_p));
        break;
      case IMethod.PAD3001_COMMUNE_READ_ANCIEN_CODE_INSEE:
      case IMethod.PAD3001_COMMUNE_READ_CODE_INSEE:
      case IMethod.PAD3001_COMMUNE_READ_CODE_POSTAL:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.RES_SERVER)//
            .receive()//
            .get(IURL.COMMUNE);
        break;

      // URL_RESSOURCE_AGGREGE PAD3124
      case IMethod.PAD3101_RESSOURCE_AGGREGE_P2P_LIRE_UN:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.RES_SERVER)//
            .receive()//
            .get(IURL.RESSOURCE_AGGREGE);
        break;

      // URL_FQDN PAD3202
      case IMethod.FQDN_LIRE_UN:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.RES_SERVER)//
            .receive()//
            .get(IURL.FQDN);
        break;

      // URL_OLT_COMPOSITE PAD3200
      case IMethod.OLT_COMPOSITE_GERER_IMPORT:
      case IMethod.OLT_COMPOSITE_GERER_SUPPRESSION_OLT_NON_REF:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.RES_SERVER)//
            .receive()//
            .put(IURL.OLT_COMPOSITE)//
            .payload(templateResource(_service, REQUEST_DIR, template_p));
        break;
      case IMethod.OLT_COMPOSITE_LIRE_UN:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.RES_SERVER)//
            .receive()//
            .get(IURL.OLT_COMPOSITE);
        break;
      case IMethod.OLT_COMPOSITE_MODIFIER_SURCHARGE_DATE_DEBUT_QUARANTAINE_OLT:
      case IMethod.OLT_COMPOSITE_MODIFIER_SURCHARGE_DEBIT_GARANTI_PORT_PON:
      case IMethod.OLT_COMPOSITE_MODIFIER_SURCHARGE_EXPLOITATION_ONT_ID:
      case IMethod.OLT_COMPOSITE_MODIFIER_SURCHARGE_PRISE_CLIENT_CARTE:
      case IMethod.OLT_COMPOSITE_MODIFIER_SURCHARGE_PRISE_CLIENT_OLT:
      case IMethod.OLT_COMPOSITE_MODIFIER_SURCHARGE_PRISE_CLIENT_ONT_ID:
      case IMethod.OLT_COMPOSITE_MODIFIER_SURCHARGE_PRISE_CLIENT_PORT_PON:
      case IMethod.OLT_COMPOSITE_MODIFIER_SURCHARGE_VERSION_OLT:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.RES_SERVER)//
            .receive()//
            .put(IURL.OLT_COMPOSITE);
        break;
      case IMethod.OLT_COMPOSITE_MODIFIER_SURCHARGE_TECHNO_AUTORISEE_PORT_PON:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.RES_SERVER)//
            .receive()//
            .put(IURL.OLT_COMPOSITE) //
            .payload(templateResource(_service, REQUEST_DIR, template_p));
        break;

      case IMethod.PORTE_DE_COLLECTE_GERER_IMPORT:
      case IMethod.PORTE_DE_COLLECTE_GERER_SUPPRESSION:
        _serverRequest = this.getDesigner()//
                             .http()//
                             .server(BouchonHttpConfig.RES_SERVER)//
                             .receive()//
                             .put(IURL.PORTE_DE_COLLECTE)//
                             .payload(templateResource(_service, REQUEST_DIR, template_p));
        break;

      // URL_RESSOURCE_PORT_P2P PAD3124
      case IMethod.RESSOURCE_PORTP2P_GERER_ALLOCATION:
      case IMethod.RESSOURCE_PORTP2P_MODIFIER_STATUT_ALLOCATION:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.RES_SERVER)//
            .receive()//
            .put(IURL.RESSOURCE_PORT_P2P);
        break;
      case IMethod.RESSOURCE_PORT_P2P_COMPTER_PORT_LIBRE_P2P:
        _serverRequest = this.getDesigner() //
            .http() //
            .server(BouchonHttpConfig.RES_SERVER) //
            .receive() //
            .get(IURL.RESSOURCE_PORT_P2P);
        break;

      // URL_COUVERTURE_CUIVRE PAD3007
      case IMethod.COUVERTURE_CUIVRE_LIRE_TOUS_PAR_ID_ADRESSE_BYTEL:
      case IMethod.COUVERTURE_CUIVRE_LIRE_UN_PAR_RIVOLI:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.RES_SERVER)//
            .receive()//
            .get(IURL.COUVERTURE_CUIVRE);
        break;

      // URL_COUVERTURE_FTTO PAD3008
      case IMethod.COUVERTURE_FTTO_LIRE_UN:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.RES_SERVER)//
            .receive()//
            .get(IURL.COUVERTURE_FTTO);
        break;

      // URL_COUVERTURE_TOKYO PAD3009
      case IMethod.COUVERTURE_TOKYO_LIRE_UN:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.RES_SERVER)//
            .receive()//
            .get(IURL.COUVERTURE_TOKYO);
        break;

      // URL_COUVERTURE_FTTH PAD3010
      case IMethod.COUVERTURE_FTTH_LIRE_TOUS_PAR_HEXACLE_INTERNE:
      case IMethod.COUVERTURE_FTTH_LIRE_TOUS_PAR_ID_ADRESSE_BYTEL:
      case IMethod.COUVERTURE_FTTH_LIRE_TOUS_PAR_IMB:
        _serverRequest = this.getDesigner() //
            .http() //
            .server(BouchonHttpConfig.RES_SERVER) //
            .receive() //
            .get(IURL.COUVERTURE_FTTH);
        break;

      // URL_COUVERTURE_5G PAD3015
      case IMethod.COUVERTURE_5G_LIRE_UN:
        _serverRequest = this.getDesigner() //
            .http() //
            .server(BouchonHttpConfig.RES_SERVER) //
            .receive() //
            .get(IURL.COUVERTURE_5G);
        break;

      // URL_RESSOURCE_FTTH PAD3011
      case IMethod.RESSOURCE_FTTH_LIRE_TOUS_PAR_REFERENCE_PM:
        _serverRequest = this.getDesigner() //
            .http() //
            .server(BouchonHttpConfig.RES_SERVER) //
            .receive() //
            .get(IURL.RESSOURCE_FTTH);
        break;

      // URL_TOPOLOGIE_ARCTURUS PAD3013
      case IMethod.TOPOLOGIE_ARCTURUS_LIRE_UN:
      case IMethod.TOPOLOGIE_ARCTURUS_LIRE_TOUS_PAR_IDEQPTACCES:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.RES_SERVER)//
            .receive()//
            .get(IURL.TOPOLOGIE_ARCTURUS);
        break;

      // URL_CACHE_ELIG PAD3300
      case IMethod.CACHE_ELIG_LIRE:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.RES_SERVER)//
            .receive()//
            .get(IURL.CACHE_ELIG);
        break;
      case IMethod.CACHE_ELIG_CREER_LISTE:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.RES_SERVER)//
            .receive()//
            .post(IURL.CACHE_ELIG) //
            .payload(templateResource(_service, REQUEST_DIR, template_p));
        break;

      // URL_DISPO_NRO_FTTE_ORG PAD3014
      case IMethod.DISPO_NRO_FTTE_ORG_LIRE:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.RES_SERVER)//
            .receive()//
            .get(IURL.DISPO_NRO_FTTE_ORG);
        break;

      // URL_DISPO_RESSOURCE_DSL_ORANGE PAD3018
      case IMethod.DISPO_RESSOURCE_DSL_BOUYGUES_LIRE:
      case IMethod.DISPO_RESSOURCE_DSL_BOUYGUES_LIRE_PAR_NOM_URA:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.RES_SERVER)//
            .receive()//
            .get(IURL.DISPO_RESSOURCE_DSL_BOUYGUES);
        break;

      // URL_DISPO_RESSOURCE_DSL_AXIONE PAD3019
      case IMethod.DISPO_RESSOURCE_DSL_AXIONE_LIRE:
      case IMethod.DISPO_RESSOURCE_DSL_AXIONE_LIRE_PAR_NOM_URA:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.RES_SERVER)//
            .receive()//
            .get(IURL.DISPO_RESSOURCE_DSL_AXIONE);
        break;

      // URL_DISPO_RESSOURCE_DSL_SFR PAD3020
      case IMethod.DISPO_RESSOURCE_DSL_SFR_LIRE:
      case IMethod.DISPO_RESSOURCE_DSL_SFR_LIRE_PAR_NOM_URA:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.RES_SERVER)//
            .receive()//
            .get(IURL.DISPO_RESSOURCE_DSL_SFR);
        break;

      // URL_DISPO_RESSOURCE_DSL_ORANGE PAD3017
      case IMethod.DISPO_RESSOURCE_DSL_ORANGE_LIRE:
      case IMethod.DISPO_RESSOURCE_DSL_ORANGE_LIRE_PAR_NOM_URA:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.RES_SERVER)//
            .receive()//
            .get(IURL.DISPO_RESSOURCE_DSL_ORANGE);
        break;

      // URL_ENTONNOIR_COMMUNE PAD3021
      case IMethod.ENTONNOIR_COMMUNE_LIRE_TOUS_PAR_CODE_POSTAL:
      case IMethod.ENTONNOIR_COMMUNE_LIRE_TOUS_PAR_DEPARTEMENT:
      case IMethod.ENTONNOIR_COMMUNE_LIRE_TOUS_PAR_CODE_INSEE:
        _serverRequest = this.getDesigner() //
            .http()//
            .server(BouchonHttpConfig.RES_SERVER)//
            .receive()//
            .get(IURL.ENTONNOIR_COMMUNE);
        break;

      // URL_ENTONNOIR_VOIE PAD3022
      case IMethod.ENTONNOIR_VOIE_LIRE_TOUS_PAR_CODE_INSEE:
      case IMethod.ENTONNOIR_VOIE_LIRE_UN_PAR_CODE_INSEE_CODE_RIVOLI:
      case IMethod.ENTONNOIR_VOIE_LIRE_UN_PAR_CODE_INSEE_SIMILI_HEXACLE_0:
        _serverRequest = this.getDesigner() //
            .http()//
            .server(BouchonHttpConfig.RES_SERVER)//
            .receive()//
            .get(IURL.ENTONNOIR_VOIE);
        break;

      // URL_ENTONNOIR_NUMERO PAD3023
      case IMethod.ENTONNOIR_NUMERO_LIRE_TOUS_PAR_CODE_INSEE_CODE_RIVOLI:
      case IMethod.ENTONNOIR_NUMERO_LIRE_TOUS_PAR_CODE_INSEE_SIMILI_HEXACLE_0:
        _serverRequest = this.getDesigner() //
            .http()//
            .server(BouchonHttpConfig.RES_SERVER)//
            .receive()//
            .get(IURL.ENTONNOIR_NUMERO);
        break;

      // URL INTEGRATION_GROUPE_FICHIER PAD3003
      case IMethod.PAD3003_READ:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.RES_SERVER)//
            .receive()//
            .get(IURL.INTEGRATION_GROUPE_FICHIER);
        break;
      case IMethod.PAD3003_DELETE:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.RES_SERVER)//
            .receive()//
            .delete(IURL.INTEGRATION_GROUPE_FICHIER);
        break;
      case IMethod.PAD3003_CREATE:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.RES_SERVER)//
            .receive()//
            .post(IURL.INTEGRATION_GROUPE_FICHIER)//
            .payload(templateResource(_service, REQUEST_DIR, template_p));//
        break;
      case IMethod.PAD3003_UPDATE:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.RES_SERVER)//
            .receive()//
            .put(IURL.INTEGRATION_GROUPE_FICHIER);
        break;

      // URL_NOEUD_RACCORDEMENT PAD3024
      case IMethod.COUVERTURE_GEO_CODAGE:
        _serverRequest = this.getDesigner() //
            .http() //
            .server(BouchonHttpConfig.RES_SERVER) //
            .receive() //
            .get(IURL.COUVERTURE_GEO_CODAGE);
        break;

      // URL_NOEUD_RACCORDEMENT PAD3204
      case IMethod.NOEUD_RACCORDEMENT_GERER_IMPORT:
      case IMethod.NOEUD_RACCORDEMENT_GERER_SUPPRESSION_NR_NON_REFERENCE:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.RES_SERVER)//
            .receive()//
            .put(IURL.NOEUD_RACCORDEMENT)//
            .payload(templateResource(_service, REQUEST_DIR, template_p));
        break;

      // URL_PM_COMPOSITE PAD3205
      case IMethod.PM_COMPOSITE_GERER_IMPORT:
      case IMethod.PM_COMPOSITE_GERER_SUPPRESSION_OLT_NON_REFERENCE:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.RES_SERVER)//
            .receive()//
            .put(IURL.PM_COMPOSITE)//
            .payload(templateResource(_service, REQUEST_DIR, template_p));
        break;

      case IMethod.PM_COMPOSITE_LIRE_UN_PAR_REFERENCE_PM_BYTEL:
      case IMethod.PAD3205_READ_ONE:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.RES_SERVER)//
            .receive()//
            .get(IURL.PM_COMPOSITE);
        break;

      case IMethod.PM_COMPOSITE_MODIFIER_SURCHARGE_DATE_DEBUT_QUARANTAINE_PM:
      case IMethod.PM_COMPOSITE_MODIFIER_SURCHARGE_EXPLOITATION_PORT_PM:
      case IMethod.PM_COMPOSITE_MODIFIER_SURCHARGE_PRISE_CLIENT_BOITIER_PM:
      case IMethod.PM_COMPOSITE_MODIFIER_SURCHARGE_PRISE_CLIENT_PM:
      case IMethod.PM_COMPOSITE_MODIFIER_SURCHARGE_PRISE_CLIENT_PORT_PM:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.RES_SERVER)//
            .receive()//
            .put(IURL.PM_COMPOSITE);
        break;

      // URL_RESSOURCE_PORT_PM PAD3127
      case IMethod.RESSOURCE_PORT_PM_GERER_ALLOCATION:
      case IMethod.RESSOURCE_PORT_PM_GERER_MIGRATION:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.RES_SERVER)//
            .receive()//
            .put(IURL.RESSOURCE_PORT_PM);
        break;

      //PAD3207
      case IMethod.POOL_IP_GERER_IMPORT:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.RES_SERVER)//
            .receive()//
            .put(IURL.POOL_IP)//
            .payload(templateResource(_service, REQUEST_DIR, template_p));
        break;

      //PAD3206
      case IMethod.POINT_ANCRAGE_IP_GERER_IMPORT:
      case IMethod.POINT_ANCRAGE_IP_GERER_SUPPRESION_POINT_ANCRAGE_IP_NON_REFERENCE:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.RES_SERVER)//
            .receive()//
            .put(IURL.POINT_ANCRAGE_IP)//
            .payload(templateResource(_service, REQUEST_DIR, template_p));
        break;

      // PAD3208 PORTE_DE_COLLECTE
      case IMethod.PORTE_DE_COLLECTE_LIRE_UN:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.RES_SERVER)//
            .receive()//
            .get(IURL.PORTE_DE_COLLECTE);
        break;

      default:
        break;
    }

    if (isControlHeaders_p)
    {
      controlReceivedHeaders(_serverRequest, false);
    }
  }
}
