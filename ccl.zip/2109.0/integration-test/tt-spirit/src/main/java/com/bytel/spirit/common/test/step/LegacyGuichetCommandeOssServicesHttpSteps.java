/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.test.step;

import com.bytel.spirit.common.test.config.BouchonHttpConfig;
import com.consol.citrus.dsl.builder.HttpServerRequestActionBuilder;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

/**
 *
 * @author jjoly
 * @version ($Revision$ $Date$)
 */
public final class LegacyGuichetCommandeOssServicesHttpSteps extends AbstractSpiritHttpSteps
{
  /** OssServices base path. */
  private static final String BASE_PATH = "LEGACY_GUICHET_COMMANDE_OSS_SERVICES"; //$NON-NLS-1$

  /** Url for GuichetCommandeOssService */
  private static final String URL_GUICHET_COMMANDE = "/oss_services_guichet/GuichetCommandeOssService"; //$NON-NLS-1$

  /** Constant for method declarerEquipement */
  private static final String METHOD_DECLARER_EQUIPEMENT = "declarerEquipement"; //$NON-NLS-1$
  /** Constant for method libererEquipement */
  private static final String METHOD_LIBERER_EQUIPEMENT = "libererEquipement"; //$NON-NLS-1$

  /** Transient expected OssServices server request. */
  private HttpServerRequestActionBuilder _serverRequest;

  /** Transient service. */
  private String _service;

  /**
   * Constructor
   */
  public LegacyGuichetCommandeOssServicesHttpSteps()
  {
    super(BASE_PATH);
  }

  /**
   * OssServices receives declarerEquipement request.
   *
   * @param template_p
   *          the template to control from
   */
  @When("^GuichetCommandeOss receives a declarerEquipement request with ([^\"]*)$")
  public void declarerEquipementRequest(final String template_p)
  {
    receiveRequest(METHOD_DECLARER_EQUIPEMENT, template_p, false);
  }

  /**
   * OssServices receives libererEquipement request.
   *
   * @param template_p
   *          the template to control from
   */
  @When("^GuichetCommandeOss receives a libererEquipement request with ([^\"]*)$")
  public void libererEquipementRequest(final String template_p)
  {
    receiveRequest(METHOD_LIBERER_EQUIPEMENT, template_p, false);
  }

  /**
   * Generic method to response
   *
   * @param template_p
   *          template file name
   */
  @Then("^GuichetCommandeOss responds with ([^\"]*)$")
  public void sendResponse(final String template_p)
  {
    switch (_service)
    {
      // URL_GUICHET_COMMANDE
      case METHOD_DECLARER_EQUIPEMENT:
      case METHOD_LIBERER_EQUIPEMENT:
        serverResponseActionOK(BouchonHttpConfig.LEGACY_GUICHET_COMMANDE_OSS_SERVICES_SERVER, templateResource(_service, RESPONSE_DIR, template_p));
        break;

      default:
        break;
    }
  }

  /**
   * Generic method to receive the request
   *
   * @param method_p
   *          method name to call
   * @param template_p
   *          template file name
   * @param isControlHeaders_p
   *          true if force header control, false elsewhere
   */
  private void receiveRequest(final String method_p, final String template_p, final boolean isControlHeaders_p)
  {
    _service = method_p;
    switch (_service)
    {
      case METHOD_DECLARER_EQUIPEMENT:
      case METHOD_LIBERER_EQUIPEMENT:
        _serverRequest = getDesigner()//
            .http() //
            .server(BouchonHttpConfig.LEGACY_GUICHET_COMMANDE_OSS_SERVICES_SERVER) //
            .receive() //
            .post(URL_GUICHET_COMMANDE) //
            .payload(templateResource(_service, REQUEST_DIR, template_p));
        break;

      default:
        break;
    }

    if (isControlHeaders_p)
    {
      controlReceivedHeaders(_serverRequest, false);
    }
  }
}
