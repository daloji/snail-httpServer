/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.test.step;

import java.util.HashMap;
import java.util.Map;

import com.bytel.ravel.RavelTestException;
import com.bytel.ravel.step.helper.AbstractHttpSteps;
import com.bytel.spirit.common.test.config.BouchonHttpConfig;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

/**
 * @author rafcosta
 * @version ($Revision$ $Date$)
 */
public class VmsVSTwRpcHttpSteps extends AbstractHttpSteps
{
  /** VmsVSTwRpc 0 base path. */
  private static final String BASE_PATH = "VmsVSTwRpc"; //$NON-NLS-1$

  /** Url for call */
  private static final String URL = "/${resourceId.url}/rpc/server.php"; //$NON-NLS-1$
  /** Url for call */
  private static final String URL_VLS = "/${vslUserMsisdn.url}/swvsl_rpc_integration/server.php"; //$NON-NLS-1$

  /** Header values for RelocateMediaBox.CreateMediaBox */
  private static final String HEADER_VMS_ID = "X-VMS-ID"; //$NON-NLS-1$
  private static final String HEADER_VMS_ID_VALUES = "${headerValue.vmsId}"; //$NON-NLS-1$

  private static final String RELOCATE_MEDIABOX_CREATE_MEDIABOX = "RelocateMediaBox.CreateMediaBox"; //$NON-NLS-1$
  private static final String METHOD_INTEGRATION_SERVICE_ADD_NEW_SUBSCRIBER = "IntegrationService.addNewSubscriber"; //$NON-NLS-1$
  private static final String METHOD_RELOCATE_MEDIA_BOX_IMPORT_MESSAGES = "RelocateMediaBox.ImportMessages"; //$NON-NLS-1$
  public static final String METHOD_RELOCATE_MEDIA_BOX_IMPORT_GREETINGS = "RelocateMediaBox.ImportGreetings"; //$NON-NLS-1$
  public static final String METHOD_MEDIABOX_UPDATE_BY_MEDIA_BOX_NUM = "MediaBox.UpdateByMediaBoxNum"; //$NON-NLS-1$
  private static final String METHOD_RELOCATE_MEDIA_BOX_DELETE = "MediaBox.Delete"; //$NON-NLS-1$

  /** Transient service. */
  private String _service;

  /**
   * Constructor
   */
  public VmsVSTwRpcHttpSteps()
  {
    super(BASE_PATH);
  }

  /**
   * Expect that PFS_RPC_SERVER receives a request.
   *
   * @param service_p
   *          the service
   *
   * @param template_p
   *          the template to control
   */
  @When("^VmsVSTwRpc receives request in ([^\"]*) with template ([^\"]*)$")
  public void receive(String service_p, String template_p)
  {
    _service = service_p;
    this.getDesigner()//
        .http()//
        .server(BouchonHttpConfig.VMS_VSTW_RPC)//
        .receive()//
        .post(URL)//
        .payload(templateResource(_service, REQUEST_DIR, template_p));
  }

  /**
   * Expect that PFS_RPC_SERVER receives a request.
   *
   *
   * @param template_p
   *          the template to control
   */
  @When("^VmsVSTwRpc receives request RelocateMediaBox.CreateMediaBox with template ([^\"]*)$")
  public void receiveRelocateMediaBoxCreateMediaBox(String template_p)
  {
    _service = RELOCATE_MEDIABOX_CREATE_MEDIABOX;
    this.getDesigner()//
        .http()//
        .server(BouchonHttpConfig.VMS_VSTW_RPC)//
        .receive()//
        .post(URL)//
        .payload(templateResource(_service, REQUEST_DIR, template_p));
  }

  /**
   * Expect that PFS_RPC_SERVER receives a request.
   *
   *
   * @param template_p
   *          the template to control
   */
  @When("^VmsVSTwRpc receives request IntegrationService.addNewSubscriber with template ([^\"]*)$")
  public void receiveIntegrationServiceaddNewSubscriber(String template_p)
  {
    _service = METHOD_INTEGRATION_SERVICE_ADD_NEW_SUBSCRIBER;
    this.getDesigner()//
        .http()//
        .server(BouchonHttpConfig.VMS_VSTW_RPC)//
        .receive()//
        .post(URL_VLS)//
        .payload(templateResource(_service, REQUEST_DIR, template_p));
  }

  /**
   * Expect that PFS_RPC_SERVER receives a request.
   *
   *
   * @param template_p
   *          the template to control
   */
  @When("^VmsVSTwRpc receives request RelocateMediaBox.ImportMessages with template ([^\"]*)$")
  public void receiveRelocateMediaBoxImportMessages(String template_p)
  {
    _service = METHOD_RELOCATE_MEDIA_BOX_IMPORT_MESSAGES;
    this.getDesigner()//
        .http()//
        .server(BouchonHttpConfig.VMS_VSTW_RPC)//
        .receive()//
        .post(URL)//
        .payload(templateResource(_service, REQUEST_DIR, template_p));
  }

  /**
   * Expect that PFS_RPC_SERVER receives a request.
   *
   *
   * @param template_p
   *          the template to control
   */
  @When("^VmsVSTwRpc receives request RelocateMediaBox.ImportGreetings with template ([^\"]*)$")
  public void receiveRelocateMediaBoxImportGreetings(String template_p)
  {
    _service = METHOD_RELOCATE_MEDIA_BOX_IMPORT_GREETINGS;
    this.getDesigner()//
        .http()//
        .server(BouchonHttpConfig.VMS_VSTW_RPC)//
        .receive()//
        .post(URL)//
        .payload(templateResource(_service, REQUEST_DIR, template_p));
  }

  /**
   * Expect that PFS_RPC_SERVER receives a request.
   *
   *
   * @param template_p
   *          the template to control
   */
  @When("^VmsVSTwRpc receives request MediaBox.UpdateByMediaBoxNum with template ([^\"]*)$")
  public void receiveMediaBoxUpdateByMediaBoxNum(String template_p)
  {
    _service = METHOD_MEDIABOX_UPDATE_BY_MEDIA_BOX_NUM;
    this.getDesigner()//
        .http()//
        .server(BouchonHttpConfig.VMS_VSTW_RPC)//
        .receive()//
        .post(URL)//
        .payload(templateResource(_service, REQUEST_DIR, template_p));
  }

  /**
   * Expect that PFS_RPC_SERVER receives a request.
   *
   *
   * @param template_p
   *          the template to control
   */
  @When("^VmsVSTwRpc receives request MediaBox.Delete with template ([^\"]*)$")
  public void receiveMediaBoxDelete(String template_p)
  {
    _service = METHOD_RELOCATE_MEDIA_BOX_DELETE;
    this.getDesigner()//
        .http()//
        .server(BouchonHttpConfig.VMS_VSTW_RPC)//
        .receive()//
        .post(URL)//
        .payload(templateResource(_service, REQUEST_DIR, template_p));
  }
  /**
   * Expect that PFS_RPC_SERVER receives a request.
   *
   * @param code_p
   *          the code
   *
   * @param template_p
   *          the template to control
   */
  @Then("^VmsVSTwRpc responds with code (\\d+) and template ([^\"]*)$")
  public void responseAction(Integer code_p, String template_p)
  {
    serverResponseAction(BouchonHttpConfig.VMS_VSTW_RPC, code_p, templateResource(_service, RESPONSE_DIR, template_p));
  }

  /**
   * Expect that PFS_RPC_SERVER responds
   *
   * @param template_p
   *          the template to control
   */
  @Then("VmsVSTwRpc responds with ([^\"]*)$")
  public void responseAction(final String template_p)
  {
    serverResponseAction(BouchonHttpConfig.VMS_VSTW_RPC, 200, templateResource(_service, RESPONSE_DIR, template_p));
  }

  /**
   * Expect that PFS_RPC_SERVER responds
   *
   * @param template_p
   *          the template to control
   */
  @Then("VmsVSTwRpc RelocateMediaBox.CreateMediaBox responds with ([^\"]*)$")
  public void responseActionRelocateMediaBoxCreateMediaBox(final String template_p) throws RavelTestException
  {
    Map<String, Object> headers = new HashMap<>();
    headers.put(HEADER_VMS_ID, HEADER_VMS_ID_VALUES);
    serverResponseAction(BouchonHttpConfig.VMS_VSTW_RPC, 200, templateResource(_service, RESPONSE_DIR, template_p)).headers(headers);
  }

}
