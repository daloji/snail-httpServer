/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.test.step;

import org.springframework.core.io.ClassPathResource;

import com.bytel.ravel.RavelTestException;
import com.bytel.ravel.step.helper.AbstractHttpSteps;
import com.bytel.spirit.common.test.config.BouchonHttpConfig;
import com.consol.citrus.dsl.builder.HttpServerActionBuilder.HttpServerReceiveActionBuilder;
import com.consol.citrus.dsl.builder.HttpServerRequestActionBuilder;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

/**
 *
 * @author jgregori
 * @version ($Revision$ $Date$)
 */
public class Stw1HttpSteps extends AbstractHttpSteps
{
  /** STW 1 base path. */
  private static final String BASE_PATH = "STW1"; //$NON-NLS-1$

  /** Transient expected STW 1 server request. */
  private HttpServerRequestActionBuilder _serverRequest;

  /** Transient service. */
  private String _service;

  /**
   * Constructor
   */
  public Stw1HttpSteps()
  {
    super(BASE_PATH);
  }

  @Then("STW1 responds with {string}")
  public void okResponseAction(String template_p)
  {
    ClassPathResource template = templateResource(_service, RESPONSE_DIR, template_p);
    serverResponseActionOK(BouchonHttpConfig.STW1_SERVER, template);
  }

  /**
   * Expect that STW receives a exportGeetings request.
   *
   * @param template_p
   *          the template to control
   * @throws RavelTestException
   *           on test setup error
   */
  @When("STW1 receives a exportGreetings request with {string}")
  public void receiveExportGreetingsRequest(String template_p) throws RavelTestException
  {
    _service = "RelocateMediaBox.ExportGreetings"; //$NON-NLS-1$
    HttpServerReceiveActionBuilder receiveActionBuilder = getDesigner().http().server(BouchonHttpConfig.STW1_SERVER).receive();
    _serverRequest = receiveActionBuilder.post("/vmsxml/xmlmediabox.php"); //$NON-NLS-1$
    _serverRequest.payload(templateResource(_service, REQUEST_DIR, template_p));
  }

  /**
   * Expect that STW receives a export request.
   *
   * @param template_p
   *          the template to control
   * @throws RavelTestException
   *           on test setup error
   */
  @When("STW1 receives a exportMessages request with {string}")
  public void receiveExportMessagesRequest(String template_p) throws RavelTestException
  {
    _service = "RelocateMediaBox.ExportMessages"; //$NON-NLS-1$
    HttpServerReceiveActionBuilder receiveActionBuilder = getDesigner().http().server(BouchonHttpConfig.STW1_SERVER).receive();
    _serverRequest = receiveActionBuilder.post("/vmsxml/xmlmediabox.php"); //$NON-NLS-1$
    _serverRequest.payload(templateResource(_service, REQUEST_DIR, template_p));
  }
}
