/*******************************************************************************
 * $Id: InkHttpSteps.java 25669 2019-08-21 14:57:15Z pramos $
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.test.step;

import org.springframework.http.HttpStatus;

import com.bytel.ravel.step.helper.AbstractHttpSteps;
import com.bytel.spirit.common.test.config.BouchonHttpConfig;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

/**
 *
 * @author FMONTEIR
 * @version ($Revision: 25669 $ $Date: 2019-08-21 16:57:15 +0200 (Wed, 21 Aug 2019) $)
 */
public class SegaHttpSteps extends AbstractHttpSteps
{
  /** SEGA base path. */
  private static final String SEGA_BASE_PATH = "SEGA"; //$NON-NLS-1$

  /** Url path */
  private static final String URL_PATH = "/SEGA"; //$NON-NLS-1$

  //notifierStatutProvAccesReseau
  /** Constant for method altitude */
  private static final String METHOD_NOTIFIER_STATUT_PROV_ACCES_RESEAU = "notifierStatutProvAccesReseau"; //$NON-NLS-1$

  /** Transient service. */
  private String _service;

  /**
   * Constructor
   */
  public SegaHttpSteps()
  {
    super(SEGA_BASE_PATH);
  }

  /**
   * SEGA receives any envoyerDemandeInk request.
   *
   * @param template_p
   *          the template to control from
   */
  @When("SEGA receives an notifierStatutProvAccesReseau request with ([^\"]*)$")
  public void receiveResponse(String template_p)
  {
    _service = METHOD_NOTIFIER_STATUT_PROV_ACCES_RESEAU;

    this.getDesigner().http()//
        .server(BouchonHttpConfig.SEGA_SERVER)//
        .receive()//
        .post(URL_PATH)//
        .payload(templateResource(_service, REQUEST_DIR, template_p));
  }

  /**
   * SEGA responds
   *
   * @param template_p
   *          relative template path
   */
  @Then("SEGA responds with ([^\"]*)$")
  public void send(String template_p)
  {
    _service = METHOD_NOTIFIER_STATUT_PROV_ACCES_RESEAU;

    this.getDesigner().http()//
        .server(BouchonHttpConfig.SEGA_SERVER)//
        .respond()//
        .status(HttpStatus.OK)//
        .payload(templateResource(_service, RESPONSE_DIR, template_p));
  }

}
