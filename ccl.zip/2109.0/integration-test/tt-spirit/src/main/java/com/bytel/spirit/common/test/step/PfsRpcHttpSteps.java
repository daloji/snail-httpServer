/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.test.step;

import com.bytel.ravel.step.helper.AbstractHttpSteps;
import com.bytel.spirit.common.test.config.BouchonHttpConfig;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

/**
 *
 * @author jgregori
 * @version ($Revision$ $Date$)
 */

public class PfsRpcHttpSteps extends AbstractHttpSteps
{
  /** PfsRpc 0 base path. */
  private static final String BASE_PATH = "PfsRpc"; //$NON-NLS-1$

  /** Url for call */
  private static final String URL = "/${resourceId.url}/vmsxml/xmlmediabox.php"; //$NON-NLS-1$

  /** Transient service. */
  private String _service;

  /**
   * Constructor
   */
  public PfsRpcHttpSteps()
  {
    super(BASE_PATH);
  }

  /**
   * Expect that PFS_RPC_SERVER receives a request.
   *
   * @param template_p
   *          the template to control
   */
  @When("^PfsRpc receives request in Message.GetMessageFileByFormat with template ([^\"]*)$")
  public void receiveMessageGetMessageFileByFormat(String template_p)
  {
    _service = "Message.GetMessageFileByFormat"; //$NON-NLS-1$
    this.getDesigner()//
        .http()//
        .server(BouchonHttpConfig.PFS_RPC_SERVER)//
        .receive()//
        .post(URL) //
        .payload(templateResource(_service, REQUEST_DIR, template_p));
  }

  /**
   * Expect that PFS_RPC_SERVER receives a request.
   *
   * @param template_p
   *          the template to control
   */
  @When("PfsRpc receives request in GetMessageFileByFormat with template ([^\"]*)$")
  public void receiveMessageGetMessageFileByFormat2(String template_p)
  {
    _service = "GetMessageFileByFormat"; //$NON-NLS-1$
    this.getDesigner()//
        .http()//
        .server(BouchonHttpConfig.PFS_RPC_SERVER)//
        .receive()//
        .post(URL) //
        .payload(templateResource(_service, REQUEST_DIR, template_p));
  }

  /**
   * Expect that PFS_RPC_SERVER receives a request.
   *
   * @param template_p
   *          the template to control
   */
  @When("^PfsRpc receives request in MediaBox.SetInviteMsgByMboxIdAndFormat with template ([^\"]*)$")
  public void receiveMediaBoxSetInviteMsgByMboxIdAndFormat(String template_p)
  {
    _service = "MediaBox.SetInviteMsgByMboxIdAndFormat"; //$NON-NLS-1$
    this.getDesigner()//
        .http()//
        .server(BouchonHttpConfig.PFS_RPC_SERVER)//
        .receive()//
        .post(URL) //
        .payload(templateResource(_service, REQUEST_DIR, template_p));
  }

  /**
   * Expect that PFS_RPC_SERVER receives a request.
   *
   * @param template_p
   *          the template to control
   */
  @When("^PfsRpc receives request in MediaBox.GetInviteMsgByMboxIdAndFormat with template ([^\"]*)$")
  public void receive(String template_p)
  {
    _service = "MediaBox.GetInviteMsgByMboxIdAndFormat"; //$NON-NLS-1$
    this.getDesigner()//
        .http()//
        .server(BouchonHttpConfig.PFS_RPC_SERVER)//
        .receive()//
        .post(URL) //
        .payload(templateResource(_service, REQUEST_DIR, template_p));
  }

  /**
   * Expect that PFS_RPC_SERVER receives a request.
   *
   * @param template_p
   *          the template to control
   */
  @When("^PfsRpc receives request in MediaBox.isMediaBoxBlockedByNum with template ([^\"]*)$")
  public void receiveMediaBoxIsMediaBoxBlockedByNum(String template_p)
  {
    _service = "MediaBox.isMediaBoxBlockedByNum"; //$NON-NLS-1$
    this.getDesigner()//
        .http()//
        .server(BouchonHttpConfig.PFS_RPC_SERVER)//
        .receive()//
        .post(URL) //
        .payload(templateResource(_service, REQUEST_DIR, template_p));
  }

  /**
   * Expect that PFS_RPC_SERVER receives a request.
   *
   * @param template_p
   *          the template to control
   */
  @When("^PfsRpc receives request in MediaBox.UpdateByMediaBoxNum with template ([^\"]*)$")
  public void receiveMediaBoxUpdateByMediaBoxNum(String template_p)
  {
    _service = "MediaBox.UpdateByMediaBoxNum"; //$NON-NLS-1$
    this.getDesigner()//
        .http()//
        .server(BouchonHttpConfig.PFS_RPC_SERVER)//
        .receive()//
        .post(URL) //
        .payload(templateResource(_service, REQUEST_DIR, template_p));
  }

  /**
   * Expect that PFS_RPC_SERVER receives a request.
   *
   * @param template_p
   *          the template to control
   */
  @When("^PfsRpc receives request in RelocateMediaBox.ExportMediaBoxSettings with template ([^\"]*)$")
  public void receiveRelocateMediaBoxExportMediaBoxSettings(String template_p)
  {
    _service = "RelocateMediaBox.ExportMediaBoxSettings"; //$NON-NLS-1$
    this.getDesigner()//
        .http()//
        .server(BouchonHttpConfig.PFS_RPC_SERVER)//
        .receive()//
        .post(URL) //
        .payload(templateResource(_service, REQUEST_DIR, template_p));
  }

  /**
   * Expect that PFS_RPC_SERVER receives a request.
   *
   * @param template_p
   *          the template to control
   */
  @When("^PfsRpc receives request in SwVvmg.GetVvmPassword with template ([^\"]*)$")
  public void receiveSwVvmgGetVvmPassword(String template_p)
  {
    _service = "SwVvmg.GetVvmPassword"; //$NON-NLS-1$
    this.getDesigner()//
        .http()//
        .server(BouchonHttpConfig.PFS_RPC_SERVER)//
        .receive()//
        .post(URL) //
        .payload(templateResource(_service, REQUEST_DIR, template_p));
  }

  /**
   * Expect that PFS_RPC_SERVER receives a request.
   *
   * @param template_p
   *          the template to control
   */
  @When("^PfsRpc receives request in RelocateMediaBox.ExportMessages with template ([^\"]*)$")
  public void receiveRelocateMediaBoxExportMessages(String template_p)
  {
    _service = "RelocateMediaBox.ExportMessages"; //$NON-NLS-1$
    this.getDesigner()//
        .http()//
        .server(BouchonHttpConfig.PFS_RPC_SERVER)//
        .receive()//
        .post(URL) //
        .payload(templateResource(_service, REQUEST_DIR, template_p));
  }

  /**
   * Expect that PFS_RPC_SERVER receives a request.
   *
   * @param template_p
   *          the template to control
   */
  @When("^PfsRpc receives request in RelocateMediaBox.ExportGreetings with template ([^\"]*)$")
  public void receiveRelocateMediaBoxExportGreetings(String template_p)
  {
    _service = "RelocateMediaBox.ExportGreetings"; //$NON-NLS-1$
    this.getDesigner()//
        .http()//
        .server(BouchonHttpConfig.PFS_RPC_SERVER)//
        .receive()//
        .post(URL) //
        .payload(templateResource(_service, REQUEST_DIR, template_p));
  }

  @Then("^PfsRpc responds with code (\\d+) and template ([^\"]*)$")
  public void responseAction(Integer code_p, String template_p)
  {
    serverResponseAction(BouchonHttpConfig.PFS_RPC_SERVER, code_p, templateResource(_service, RESPONSE_DIR, template_p));
  }

  @Then("PfsRpc responds with ([^\"]*)$")
  public void responseAction(String template_p)
  {
    serverResponseAction(BouchonHttpConfig.PFS_RPC_SERVER, 200, templateResource(_service, RESPONSE_DIR, template_p));
  }

}
