/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.test.step;

import com.bytel.spirit.common.test.config.BouchonHttpConfig;
import com.consol.citrus.dsl.builder.HttpServerRequestActionBuilder;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

/**
 * @author jsantos
 * @version ($Revision$ $Date$)
 */
public class PfsDARESHttpSteps extends AbstractSpiritHttpSteps
{

  /** SMV base path. */
  private static final String BASE_PATH = "DARES"; //$NON-NLS-1$

  /** Url for SMV LireServiceTTV */
  private static final String URL_LIRE_SERVICE_TV = "/v1/profile/srv_id/@${request.id_compte_tv}/offer"; //$NON-NLS-1$

  /** Url for SMV LireTokenTV */
  private static final String URL_LIRE_TOKEN_TV = "/oauth/tokens"; //$NON-NLS-1$

  /** Constant for method lireServiceTV */
  private static final String METHOD_LIRE_SERVICE_TV = "lireServiceTV"; //$NON-NLS-1$
  /** Constant for method lireTokenTV */
  private static final String METHOD_LIRE_TOKEN_TV = "lireTokenTV"; //$NON-NLS-1$
  /** Constant for method lireTokenTV */
  private static final String METHOD_SUPPRESSION_TOKEN_TV = "suppressionTokenTV"; //$NON-NLS-1$

  /** Transient expected OssServices server request. */
  private HttpServerRequestActionBuilder _serverRequest;

  /** Transient service. */
  private String _service;

  /**
   * Constructor
   */
  public PfsDARESHttpSteps()
  {
    super(BASE_PATH);
  }

  /**
   * Expect request has given query param
   *
   * @param name_p
   *          query param name
   * @param value_p
   *          query param value
   */
  @And("DARESTokenTV query param ([^\"]*)=([^\"]*)$")
  public void expectQueryParam(String name_p, String value_p)
  {
    _serverRequest.queryParam(name_p, value_p);
  }

  /**
   * DARESServiceTV receives lireServiceTV request.
   *
   */
  @When("^DARESServiceTV receives a lireServiceTV request")
  public void lireServiceTVRequest()
  {
    receiveRequest(METHOD_LIRE_SERVICE_TV, null, false);
  }

  /**
   * DARESTokenTV receives lireTokenTV request.
   *
   */
  @When("^DARESTokenTV receives a lireTokenTV request")
  public void lireTokenTVRequest()
  {
    receiveRequest(METHOD_LIRE_TOKEN_TV, null, false);
  }

  /**
   * DARESServiceTV responds a status
   *
   * @param template_p
   *          relative template path
   */
  @Then("DARESServiceTV responds status (\\d+) with ([^\"]*)$")
  public void responseActionServiceTv(Integer codeHttp_p, String template_p)
  {
    serverResponseAction(BouchonHttpConfig.DARES_SERVICE_TV_SERVER, codeHttp_p, templateResource(_service, RESPONSE_DIR, template_p));
  }

  /**
   * DARESTokenTV responds a status
   *
   * @param template_p
   *          relative template path
   */
  @Then("DARESTokenTV responds status (\\d+) with ([^\"]*)$")
  public void responseActionTokenTv(Integer codeHttp_p, String template_p)
  {
    serverResponseAction(BouchonHttpConfig.DARES_TOKEN_TV_SERVER, codeHttp_p, templateResource(_service, RESPONSE_DIR, template_p));
  }

  /**
   * DARESServiceTV receives lireServiceTV request.
   *
   */
  @When("^DARESTokenTV receives a suppressionTokenTV request")
  public void suppressionTokenTVRequest()
  {
    receiveRequest(METHOD_SUPPRESSION_TOKEN_TV, null, false);
  }

  /**
   * Generic method to receive the request
   *
   * @param method_p
   *          method name to call
   * @param template_p
   *          template file name
   * @param isControlHeaders_p
   *          true if force header control, false elsewhere
   */
  private void receiveRequest(final String method_p, final String template_p, final boolean isControlHeaders_p)
  {
    _service = method_p;
    switch (_service)
    {
      // URL_LIRE_SERVICE_TV
      case METHOD_LIRE_SERVICE_TV:
        _serverRequest = getDesigner()//
            .http() //
            .server(BouchonHttpConfig.DARES_SERVICE_TV_SERVER) //
            .receive() //
            .get(URL_LIRE_SERVICE_TV);
        break;

      // URL_LIRE_TOKEN_TV
      case METHOD_LIRE_TOKEN_TV:
        _serverRequest = getDesigner()//
            .http() //
            .server(BouchonHttpConfig.DARES_TOKEN_TV_SERVER) //
            .receive() //
            .get(URL_LIRE_TOKEN_TV);
        break;

      // URL_LIRE_TOKEN_TV
      case METHOD_SUPPRESSION_TOKEN_TV:
        _serverRequest = getDesigner()//
            .http() //
            .server(BouchonHttpConfig.DARES_TOKEN_TV_SERVER) //
            .receive() //
            .delete(URL_LIRE_TOKEN_TV);
        break;

      default:
        break;
    }

    if (isControlHeaders_p)
    {
      controlReceivedHeaders(_serverRequest, false);
    }
  }
}
