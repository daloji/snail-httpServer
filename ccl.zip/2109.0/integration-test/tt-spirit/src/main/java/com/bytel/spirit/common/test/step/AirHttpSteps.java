/*******************************************************************************
 * $Id: AirHttpSteps.java 23515 2019-07-03 11:30:51Z jjoly $
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.test.step;

import com.bytel.spirit.common.test.config.BouchonHttpConfig;
import com.consol.citrus.dsl.builder.HttpServerRequestActionBuilder;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

/**
 *
 * @author JSTRUB
 * @version ($Revision: 23515 $ $Date: 2019-07-03 13:30:51 +0200 (mer. 03 juil. 2019) $)
 */
public class AirHttpSteps extends AbstractSpiritHttpSteps
{
  /** AIR base path. */
  private static final String AIR_BASE_PATH = "AIR"; //$NON-NLS-1$

  /** Url for PAD7001 */
  private static final String URL_INDEX_RECHERCHE_PFI = "/ExecuteGenericRequestV2/indexRecherchePfi"; //$NON-NLS-1$

  /** Constant for method indexRechercherPfiEcrire */
  private static final String METHOD_INDEX_RECHERCHER_PFI_ECRIRE = "indexRechercherPfiEcrire"; //$NON-NLS-1$
  /** Constant for method indexRechercherPfiLireTousParCleRecherche */
  private static final String METHOD_INDEX_RECHERCHER_PFI_LIRE_TOUS_PAR_CLE_RECHERCHE = "indexRechercherPfiLireTousParCleRecherche"; //$NON-NLS-1$
  /** Constant for method indexRechercherPfiLireUn */
  private static final String METHOD_INDEX_RECHERCHER_PFI_LIRE_UN = "indexRechercherPfiLireUn"; //$NON-NLS-1$
  /** Constant for method indexRechercherPfiSupprimer */
  private static final String METHOD_INDEX_RECHERCHER_PFI_SUPPRIMER = "indexRechercherPfiSupprimer"; //$NON-NLS-1$

  /** Transient expected AIR server request. */
  private HttpServerRequestActionBuilder _serverRequest;

  /** Transient service. */
  private String _service;

  /** Constructor */
  public AirHttpSteps()
  {
    super(AIR_BASE_PATH);
  }

  /**
   * Expect request has given query param
   *
   * @param name_p
   *          query param name
   * @param value_p
   *          query param value
   */
  @And("AIR query param ([^\"]*)=([^\"]*)$")
  public void expectQueryParam(String name_p, String value_p)
  {
    _serverRequest.queryParam(name_p, value_p);
  }

  /**
   * AIR responds an error
   *
   * @param template_p
   *          relative template path
   */
  @Then("AIR responds with ([^\"]*)$")
  public void okResponseAction(String template_p)
  {
    serverResponseActionOK(BouchonHttpConfig.AIR_SERVER, templateResource(_service, RESPONSE_DIR, template_p));
  }

  /**
   * Expect that AIR receives an indexRechercherPfiLireUn request.
   */
  @When("^AIR receives an indexRechercherPfiLireUn request$")
  public void receiveIndexRechecherPfiLireUnRequest()
  {
    receiveRequest(METHOD_INDEX_RECHERCHER_PFI_LIRE_UN, null, false);
  }

  /**
   * Expect that AIR receives an indexRechercherPfiEcrire request.
   *
   * @param template_p
   *          relative template path
   */
  @When("AIR receives an indexRechercherPfiEcrire request with ([^\"]*)$")
  public void receiveIndexRechercherPfiEcrireRequest(String template_p)
  {
    receiveRequest(METHOD_INDEX_RECHERCHER_PFI_ECRIRE, template_p, false);
  }

  /**
   * Expect that AIR receives an indexRechercherPfi request.
   */
  @When("AIR receives an indexRechercherPfiLireTousParCleRecherche request")
  public void receiveindexRechercherPfiLireTousParCleRechercheRequest()
  {
    receiveRequest(METHOD_INDEX_RECHERCHER_PFI_LIRE_TOUS_PAR_CLE_RECHERCHE, null, false);
  }

  /**
   * Expect that AIR receives an indexRechercherPfi request.
   */
  @When("^AIR receives an indexRechercherPfiLireTousParCleRecherche request with header control$")
  public void receiveindexRechercherPfiLireTousParCleRechercheRequest2()
  {
    receiveRequest(METHOD_INDEX_RECHERCHER_PFI_LIRE_TOUS_PAR_CLE_RECHERCHE, null, true);
  }

  /**
   * Expect that AIR receives an indexRechercherPfiSupprimer request.
   */
  @When("^AIR receives an indexRechercherPfiSupprimer request$")
  public void receiveIndexRechercherPfiSupprimerRequest()
  {
    receiveRequest(METHOD_INDEX_RECHERCHER_PFI_SUPPRIMER, null, false);
  }

  /**
   * AIR responds an error
   *
   * @param template_p
   *          relative template path
   */
  @Then("AIR responds status (\\d+) with ([^\"]*)$")
  public void responseAction(Integer codeHttp_p, String template_p)
  {
    serverResponseAction(BouchonHttpConfig.AIR_SERVER, codeHttp_p, templateResource(_service, RESPONSE_DIR, template_p));
  }

  /**
   * Generic method to receive the request
   *
   * @param method_p
   *          method name to call
   * @param template_p
   *          template file name
   */
  private void receiveRequest(String method_p, String template_p, boolean isControlHeaders_p)
  {
    _service = method_p;

    switch (_service)
    {
      case METHOD_INDEX_RECHERCHER_PFI_ECRIRE:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.AIR_SERVER)//
            .receive()//
            .post(URL_INDEX_RECHERCHE_PFI)//
            .payload(templateResource(_service, REQUEST_DIR, template_p));

        break;
      case METHOD_INDEX_RECHERCHER_PFI_LIRE_UN:
      case METHOD_INDEX_RECHERCHER_PFI_LIRE_TOUS_PAR_CLE_RECHERCHE:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.AIR_SERVER)//
            .receive()//
            .get(URL_INDEX_RECHERCHE_PFI);
        break;
      case METHOD_INDEX_RECHERCHER_PFI_SUPPRIMER:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.AIR_SERVER)//
            .receive()//
            .delete(URL_INDEX_RECHERCHE_PFI);
        break;
      default:
        break;
    }

    if (isControlHeaders_p)
    {
      controlReceivedHeaders(_serverRequest, false);
    }
  }
}
