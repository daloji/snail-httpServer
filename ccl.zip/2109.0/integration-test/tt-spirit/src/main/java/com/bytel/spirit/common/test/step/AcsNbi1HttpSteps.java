/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.test.step;

import com.bytel.spirit.common.test.config.BouchonHttpConfig;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

/**
 *
 * @author pramos
 * @version ($Revision$ $Date$)
 */
public class AcsNbi1HttpSteps extends AbstractSpiritHttpSteps
{
  /** AcsNbi1 base path. */
  private static final String BASE_PATH = "ACS_NBI_1"; //$NON-NLS-1$

  /** Url for ACS_SERVICE_URL */
  private static final String ACS_SERVICE_URL = "/nbbs/webservice/NBBSNorthboundAPI_01"; //$NON-NLS-1$

  /** Constant for method reboot */
  private static final String METHOD_REBOOT = "reboot"; //$NON-NLS-1$

  /** Constant for method ListService */
  private static final String METHOD_LIST_SERVICE = "ListService";//$NON-NLS-1$

  /** Transient service. */
  private String _service;

  /**
   * Constructor
   */
  public AcsNbi1HttpSteps()
  {
    super(BASE_PATH);
  }

  /**
   * AcsNbi1 receives ListServices request.
   *
   * @param template_p
   *          the template to control from
   */
  @When("^AcsNbi1 receives a ListServices request with ([^\"]*)$")
  public void listServicesRequest(final String template_p)
  {
    receiveRequest(METHOD_LIST_SERVICE, template_p);
  }

  /**
   * AcsNbi1 receives reboot request.
   *
   * @param template_p
   *          the template to control from
   */
  @When("^AcsNbi1 receives a reboot request with ([^\"]*)$")
  public void reboot(final String template_p)
  {
    receiveRequest(METHOD_REBOOT, template_p);
  }

  /**
   * Generic method to receive the request
   *
   * @param method_p
   *          method name to call
   * @param template_p
   *          template file name
   */
  private void receiveRequest(String method_p, String template_p)
  {
    _service = method_p;

    switch (_service)
    {
      // ACS_SERVICE_URL
      case METHOD_REBOOT:
      case METHOD_LIST_SERVICE:
        this.getDesigner()//
            .http() //
            .server(BouchonHttpConfig.ACS_NBI_1_SERVER) //
            .receive() //
            .post(ACS_SERVICE_URL) //
            .payload(templateResource(method_p, REQUEST_DIR, template_p));
        break;
      default:
        break;
    }
  }

  /**
   * Generic method to receive the request
   *
   * @param template_p
   *          template file name
   */
  @Then("AcsNbi1 responds with ([^\"]*)$")
  public void sendResponse(String template_p)
  {
    switch (_service)
    {
      // URL_ACS_NBI_1_SERVER
      case METHOD_REBOOT:
      case METHOD_LIST_SERVICE:
        serverResponseActionOK(BouchonHttpConfig.ACS_NBI_1_SERVER, templateResource(_service, RESPONSE_DIR, template_p));
        break;

      default:
        break;
    }
  }
}
