/*******************************************************************************
 * $Id: RpgHttpSteps.java 53715 2021-06-22 16:41:03Z pramos $
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.test.step;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.bytel.spirit.common.test.config.BouchonHttpConfig;
import com.consol.citrus.dsl.builder.HttpServerRequestActionBuilder;
import com.consol.citrus.endpoint.adapter.StaticResponseEndpointAdapter;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

/**
 * RPG is simulated with static response as it is cached by Prof, so service call can't be predicted.
 *
 * @author JSTRUB
 * @version ($Revision: 53715 $ $Date: 2021-06-22 18:41:03 +0200 (mar. 22 juin 2021) $)
 */
public class RpgHttpSteps extends AbstractSpiritHttpSteps
{
  /** RPG base path. */
  private static final String RPG_BASE_PATH = "RPG"; //$NON-NLS-1$

  /** Url for PAD1002 */
  private static final String URL_PFI = "/ExecuteGenericRequestV2/pfi"; //$NON-NLS-1$

  /** Url for PAD1003 */
  private static final String URL_GENCODE_AUTO_APP = "/ExecuteGenericRequestV2/gencodeAutoAppairable"; //$NON-NLS-1$

  /** Constant for method serviceCommercialLireTous */
  private static final String METHOD_NAME_SERVICECOMMERCIAL_LIRE_TOUS = "serviceCommercialLireTous"; //$NON-NLS-1$
  /** Constant for method pfiLireUn */
  private static final String METHOD_NAME_PFI_LIREUN = "pfiLireUn"; //$NON-NLS-1$
  /** Constant for method pfiLireUnFiltrerOCResilie */
  private static final String METHOD_NAME_PFI_LIREUN_FILTRER_OCRESILIE = "pfiLireUnFiltrerOCResilie"; //$NON-NLS-1$
  /** Constant for method pfiEcrire */
  private static final String METHOD_NAME_PFI_ECRIRE = "pfiEcrire"; //$NON-NLS-1$
  /** Constant for method gencodeAutoAppairableLireUn */
  private static final String METHOD_NAME_GENCODE_AUTO_APPAIRABLE_LIRE_UN = "gencodeAutoAppairableLireUn"; //$NON-NLS-1$

  /** */
  @Autowired
  @Qualifier(BouchonHttpConfig.RPG_ENDPOINT_ADAPTER)
  private StaticResponseEndpointAdapter _rpgStaticEndpoint;

  /** Transient expected RPG server request. */
  private HttpServerRequestActionBuilder _serverRequest;

  /** Transient service. */
  private String _service;

  /**
   * Constructor
   */
  public RpgHttpSteps()
  {
    super(RPG_BASE_PATH);
  }

  /**
   * Expect request has given query param
   *
   * @param name_p
   *          query param name
   * @param value_p
   *          query param value
   */
  @And("^RPG query param ([^\"]*)=([^\"]*)$")
  public void expectQueryParam(String name_p, String value_p)
  {
    _serverRequest.queryParam(name_p, value_p);
  }

  /**
   * Expect that RPG receives a pfiEcrire request.
   *
   * @param template_p
   *          relative template path
   */
  @When("^RPG receives a pfiEcrire request with ([^\"]*)$")
  public void receivePfiEcrireRequest(String template_p)
  {
    receiveRequest(METHOD_NAME_PFI_ECRIRE, template_p, false);
  }

  /**
   * Expect RPG receives a pfiLireUnFiltrerOCResilie request.
   */
  @When("RPG receives a pfiLireUnFiltrerOCResilie request")
  public void receivePfiLireUnFiltrerOCResilieRequest()
  {
    receiveRequest(METHOD_NAME_PFI_LIREUN_FILTRER_OCRESILIE, null, false);
  }

  /**
   * Expect RPG receives a pfiLireUn request.
   */
  @When("RPG receives a pfiLireUn request")
  public void receivePfiLireUnRequest()
  {
    receiveRequest(METHOD_NAME_PFI_LIREUN, null, false);
  }

  /**
   * Expect RPG receives a gencodeAutoAppairableLireUn request.
   */
  @When("RPG receives a gencodeAutoAppairableLireUn request")
  public void receiveGencodeAutoAppairableLireUnRequest()
  {
    receiveRequest(METHOD_NAME_GENCODE_AUTO_APPAIRABLE_LIRE_UN, null, false);
  }

  /**
   * RPG response for serviceCommercialLireTous.
   *
   * @param template_p
   *          static response
   */
  @Given("RPG serviceCommercialLireTous will respond ([^\"]*)$")
  public void receiveResponse(String template_p)
  {
    _service = METHOD_NAME_SERVICECOMMERCIAL_LIRE_TOUS;
    _rpgStaticEndpoint.setMessagePayloadResource(templateResource(_service, RESPONSE_DIR, template_p).getPath());
  }

  /**
   * RPG responds a status
   *
   * @param codeHttp_p
   *          HTTP error
   * @param template_p
   *          relative template path
   */
  @Then("^RPG responds status (\\d+) with ([^\"]*)$")
  public void responseAction(Integer codeHttp_p, String template_p)
  {
    serverResponseAction(BouchonHttpConfig.RPG_SERVER, codeHttp_p, templateResource(_service, RESPONSE_DIR, template_p));
  }

  /**
   * RPG responds an error
   *
   * @param template_p
   *          response
   */
  @Then("^RPG responds with ([^\"]*)$")
  public void sendAction(String template_p)
  {
    serverResponseActionOK(BouchonHttpConfig.RPG_SERVER, templateResource(_service, RESPONSE_DIR, template_p));
  }

  /**
   * Generic method to receive the request
   *
   * @param method_p
   *          method name to call
   * @param template_p
   *          template file name
   * @param isControlHeaders_p
   *          true to control headers
   */
  private void receiveRequest(String method_p, String template_p, boolean isControlHeaders_p)
  {
    _service = method_p;

    switch (_service)
    {
      // URL_PFI
      case METHOD_NAME_PFI_LIREUN:
      case METHOD_NAME_PFI_LIREUN_FILTRER_OCRESILIE:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.RPG_SERVER)//
            .receive()//
            .get(URL_PFI);
        break;

      case METHOD_NAME_PFI_ECRIRE:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.RPG_SERVER).receive()//
            .post(URL_PFI) //
            .payload(templateResource(_service, REQUEST_DIR, template_p));
        break;

      case METHOD_NAME_GENCODE_AUTO_APPAIRABLE_LIRE_UN:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.RPG_SERVER).receive()//
            .get(URL_GENCODE_AUTO_APP);
        break;

      default:
        break;
    }

    if (isControlHeaders_p)
    {
      controlReceivedHeaders(_serverRequest, false);
    }
  }
}
