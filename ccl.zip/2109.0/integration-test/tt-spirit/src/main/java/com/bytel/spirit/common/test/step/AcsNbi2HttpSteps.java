/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.test.step;

import com.bytel.spirit.common.test.config.BouchonHttpConfig;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

/**
 *
 * @author pramos
 * @version ($Revision$ $Date$)
 */
public class AcsNbi2HttpSteps extends AbstractSpiritHttpSteps
{
  /** AcsNbi1 base path. */
  private static final String BASE_PATH = "ACS_NBI_2"; //$NON-NLS-1$

  /** Url for ACS_SERVICE_URL */
  private static final String ACS_SERVICE_URL = "/nbbs/services/nbi_v2_0_http"; //$NON-NLS-1$


  /** Constant for method getSubscriberDevices */
  private static final String METHOD_GETSUBSCRIBERDEVICES = "getSubscriberDevices";//$NON-NLS-1$

  /** Transient service. */
  private String _service;

  /**
   * Constructor
   */
  public AcsNbi2HttpSteps()
  {
    super(BASE_PATH);
  }

  /**
   * AcsNbi2 receives getSubscriberDevices request.
   *
   * @param template_p
   *          the template to control from
   */
  @When("^AcsNbi2 receives a getSubscriberDevices request with ([^\"]*)$")
  public void getSubscriberDevicesRequest(final String template_p)
  {
    receiveRequest(METHOD_GETSUBSCRIBERDEVICES, template_p);
  }


  /**
   * Generic method to receive the request
   *
   * @param method_p
   *          method name to call
   * @param template_p
   *          template file name
   */
  private void receiveRequest(String method_p, String template_p)
  {
    _service = method_p;

    switch (_service)
    {
      // ACS_SERVICE_URL
      case METHOD_GETSUBSCRIBERDEVICES:
        this.getDesigner()//
            .http() //
            .server(BouchonHttpConfig.ACS_NBI_2_SERVER) //
            .receive() //
            .post(ACS_SERVICE_URL) //
            .payload(templateResource(method_p, REQUEST_DIR, template_p));
        break;
      default:
        break;
    }
  }

  /**
   * Generic method to receive the request
   *
   * @param template_p
   *          template file name
   */
  @Then("AcsNbi2 responds with ([^\"]*)$")
  public void sendResponse(String template_p)
  {
    switch (_service)
    {
      // URL_ACS_NBI_1_SERVER
      case METHOD_GETSUBSCRIBERDEVICES:
        serverResponseActionOK(BouchonHttpConfig.ACS_NBI_2_SERVER, templateResource(_service, RESPONSE_DIR, template_p));
        break;

      default:
        break;
    }
  }
}
