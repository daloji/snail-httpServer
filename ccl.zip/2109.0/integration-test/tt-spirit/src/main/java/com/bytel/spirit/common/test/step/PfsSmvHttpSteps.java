/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.test.step;

import com.bytel.spirit.common.test.config.BouchonHttpConfig;
import com.consol.citrus.dsl.builder.HttpServerRequestActionBuilder;
import cucumber.api.java.en.When;

/**
 * @author jsantos
 * @version ($Revision$ $Date$)
 */
public class PfsSmvHttpSteps extends AbstractSpiritHttpSteps
{

  /** SMV base path. */
  private static final String BASE_PATH = "SMV"; //$NON-NLS-1$

  /** Url for SMV Authenticate */
  private static final String URL_SMV_AUTHENTICATION = "/smartvision_tv/services/AuthenticationService_1"; //$NON-NLS-1$

  /** Url for SMV Prov */
  private static final String URL_SMV_PROV = "/smartvision_tv/services/AdmProvisioningService_1"; //$NON-NLS-1$

  /** Constant for method authenticateUser */
  private static final String METHOD_AUTHENTICATE_USER = "authenticateUser"; //$NON-NLS-1$

  /** Constant for method getCustomerInformation */
  private static final String METHOD_GET_CUSTOMER_INFORMATION = "getCustomerInformation"; //$NON-NLS-1$

  /** Constant for method getCustomerOptions */
  private static final String METHOD_GET_CUSTOMER_OPTIONS = "getCustomerOptions"; //$NON-NLS-1$

  private static final String METHOD_RESET_CODE_PIN_PARENTAL = "resetPinCode";

  public static final String METHOD_RESET_CODE_PIN_ACHAT = "resetPurchaseCode";

  /** Transient expected OssServices server request. */
  private HttpServerRequestActionBuilder _serverRequest;

  /** Transient service. */
  private String _service;

  /**
   * Constructor
   */
  public PfsSmvHttpSteps()
  {
    super(BASE_PATH);
  }

  /**
   * SMV receives authenticateUser request.
   *
   * @param template_p
   *          the template to control from
   */
  @When("^Authentication receives a authenticateUser request with ([^\"]*)$")
  public void authenticateUserRequest(final String template_p)
  {
    receiveRequest(METHOD_AUTHENTICATE_USER, template_p, false);
  }

  /**
   * SMV send authenticateUser response
   *
   * @param template_p
   *          template file name
   */
  @When("^Authentication responds with ([^\"]*)$")
  public void authenticateUserResponse(final String template_p)
  {
    sendResponse(_service, template_p);
  }

  /**
   * SMV receives getCustomerInformation request.
   *
   * @param template_p
   *          the template to control from
   */
  @When("^Prov receives a getCustomerInformation request with ([^\"]*)$")
  public void getCustomerInformationRequest(final String template_p)
  {
    receiveRequest(METHOD_GET_CUSTOMER_INFORMATION, template_p, false);
  }

  /**
   * SMV receives getCustomerInformation request.
   *
   * @param template_p
   *          the template to control from
   */
  @When("^Prov receives a getCustomerOptions request with ([^\"]*)$")
  public void getCustomerOptionsRequest(final String template_p)
  {
    receiveRequest(METHOD_GET_CUSTOMER_OPTIONS, template_p, false);
  }

  /**
   * SMV send getCustomerInformation response
   *
   * @param template_p
   *          template file name
   */
  @When("^Prov responds with ([^\"]*)$")
  public void getCustomerInformationResponse(final String template_p)
  {
    sendResponse(_service, template_p);
  }

  @When("^Prov receives a resetCodePinParental request with ([^\"]*)$")
  public void resetCodePinParentalRequest(final String template_p)
  {
    receiveRequest(METHOD_RESET_CODE_PIN_PARENTAL, template_p, false);
  }

  @When("^Prov receives a resetCodePinAchat request with ([^\"]*$)")
  public void resetCodePinAchatRequest(final String template_p)
  {
    receiveRequest(METHOD_RESET_CODE_PIN_ACHAT, template_p, false);
  }

  /**
   * Generic method to receive the request
   *
   * @param method_p
   *          method name to call
   * @param template_p
   *          template file name
   * @param isControlHeaders_p
   *          true if force header control, false elsewhere
   */
  private void receiveRequest(final String method_p, final String template_p, final boolean isControlHeaders_p)
  {
    _service = method_p;
    switch (_service)
    {
      // URL_SMV_AUTHENTICATION
      case METHOD_AUTHENTICATE_USER:
        _serverRequest = getDesigner()//
                                      .http() //
                                      .server(BouchonHttpConfig.SMV_AUTHENTICATION_SERVER) //
                                      .receive() //
                                      .post(URL_SMV_AUTHENTICATION) //
                                      .payload(templateResource(_service, REQUEST_DIR, template_p));
        break;

      // URL_SMV_PROV SI069
      case METHOD_GET_CUSTOMER_INFORMATION:
        // URL_SMV_PROV SI125
      case METHOD_GET_CUSTOMER_OPTIONS:
        // URL_SMV_PROV SI112
      case METHOD_RESET_CODE_PIN_PARENTAL:
        // URL_SMV_PROV SI113
      case METHOD_RESET_CODE_PIN_ACHAT:
        _serverRequest = getDesigner()//
                                      .http() //
                                      .server(BouchonHttpConfig.SMV_PROV_SERVER) //
                                      .receive() //
                                      .post(URL_SMV_PROV) //
                                      .payload(templateResource(_service, REQUEST_DIR, template_p));
        break;

      default:
        break;
    }

    if (isControlHeaders_p)
    {
      controlReceivedHeaders(_serverRequest, false);
    }
  }

  /**
   * Generic method to response
   *
   * @param method_p
   *          method name to call
   * @param template_p
   *          template file name
   */
  private void sendResponse(final String method_p, final String template_p)
  {
    switch (method_p)
    {
      // URL_SMV_AUTHENTICATION
      case METHOD_AUTHENTICATE_USER:
        serverResponseActionOK(BouchonHttpConfig.SMV_AUTHENTICATION_SERVER, templateResource(method_p, RESPONSE_DIR, template_p));
        break;

      // URL_SMV_PROV
      case METHOD_GET_CUSTOMER_INFORMATION:
      case METHOD_GET_CUSTOMER_OPTIONS:
      case METHOD_RESET_CODE_PIN_PARENTAL:
      case METHOD_RESET_CODE_PIN_ACHAT:
        serverResponseActionOK(BouchonHttpConfig.SMV_PROV_SERVER, templateResource(method_p, RESPONSE_DIR, template_p));
        break;

      default:
        break;
    }
  }
}
