/*******************************************************************************
 * $Id: RexHttpSteps.java 50968 2021-04-22 11:01:39Z jbrites $
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.test.step;

import com.bytel.spirit.common.test.config.BouchonHttpConfig;
import com.consol.citrus.dsl.builder.HttpServerRequestActionBuilder;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

/**
 * @author JSTRUB
 * @version ($Revision : 47337 $ $Date : 2021 - 02 - 10 14 : 47 : 24 + 0100 ( Wed, 10 Feb 2021) $)
 */
public class RexHttpSteps extends AbstractSpiritHttpSteps
{
  private interface IMethod
  {
    String RECONCILIATION_COMMERCIALE_CREER = "reconciliationCommercialeCreer"; //$NON-NLS-1$
    String RECONCILIATION_COMMERCIALE_LIRE_TOUS_PAR_CLIENT_OPERATEUR_NO_COMPTE = "reconciliationCommercialeLireTousParClientOperateurNoCompte"; //$NON-NLS-1$
    String RECONCILIATION_COMMERCIALE_LIRE_TOUS_PAR_ID_RECONCILIATION = "reconciliationCommercialeLireTousParIdReconciliation"; //$NON-NLS-1$
    String RECONCILIATION_COMMERCIALE_MODIFIER = "reconciliationCommercialeModifier"; //$NON-NLS-1$
    String RECONCILIATION_COMMERCIALE_EN_MASSE_ACQUITTER_UN = "reconciliationCommercialeEnMasseAcquitterUn"; //$NON-NLS-1$
    String RECONCILIATION_COMMERCIALE_EN_MASSE_AJOUTER = "reconciliationCommercialeEnMasseAjouter"; //$NON-NLS-1$
    String RECONCILIATION_COMMERCIALE_EN_MASSE_LIRE_TOUS = "reconciliationCommercialeEnMasseLireTous"; //$NON-NLS-1$

    String ERREUR_SPIRIT_LIRE_TOUS_PAR_STATUT_PERIOD = "erreurSpiritLireTousParStatutPeriod"; //$NON-NLS-1$
    String ERREUR_SPIRIT_CREER = "erreurSpiritCreer"; //$NON-NLS-1$
    String ERREUR_SPIRIT_MODIFIER_STATUT = "erreurSpiritModifierStatut"; //$NON-NLS-1$

    String TEMPLATE_REQUETE_EXPLOITATION_LIRE_UN = "templateRequeteExploitationLireUn"; //$NON-NLS-1$
    String REQUETE_EXPLOITATION_LIRE_UN = "requeteExploitationLireUn"; //$NON-NLS-1$
    String DECISION_EXPLOITATION_LIRE_UN = "decisionExploitationLireUn"; //$NON-NLS-1$

    String NOTIFICATION_RESEAU_LIRE_UN = "notificationReseauLireUn"; //$NON-NLS-1$
    String NOTIFICATION_RESEAU_CREER = "notificationReseauCreer"; //$NON-NLS-1$
    String NOTIFICATION_RESEAU_MODIFIER_STATUT = "notificationReseauModifierStatut"; //$NON-NLS-1$

    String COMPARAISON_COMMERCIALE_COMPOSITE = "comparaisonCommercialeComposite"; //$NON-NLS-1$

    String CONFIGURATION_PFS_COMPOSITE_GERER_ECRIRE_CONFIGURATION_PFS = "configurationPfsCompositeGererEcrireConfigurationPfs"; //$NON-NLS-1$
    String CONFIGURATION_PFS_COMPOSITE_GERER_ECRIRE_PFS = "configurationPfsCompositeGererEcrirePfs"; //$NON-NLS-1$
    String CONFIGURATION_PFS_COMPOSITE_GERER_SUPPRESSION_CONFIGURATION_PFS = "configurationPfsCompositeGererSuppressionConfigurationPfs"; //$NON-NLS-1$
    String CONFIGURATION_PFS_COMPOSITE_GERER_SUPPRESSION_PFS = "configurationPfsCompositeGererSuppressionPfs"; //$NON-NLS-1$
    String CONFIGURATION_PFS_COMPOSITE_LIRE_TOUS = "configurationPfsCompositeLireTous"; //$NON-NLS-1$

    String CLE_RECHERCHE_NOTIFICATION_RESEAU = "cleRechercheNotificationReseau"; //$NON-NLS-1$

    String HISTORISATION_ELIGIBILITE_CREER = "historisationEligibiliteCreer"; //$NON-NLS-1$

    String OPERATION_VIE_RESEAU_CREER = "operationVieReseauCreer"; //$NON-NLS-1$
    String OPERATION_VIE_RESEAU_LIRE_UN = "operationVieReseauLireUn"; //$NON-NLS-1$
    String OPERATION_VIE_RESEAU_LIRE_TOUS_PAR_DATE = "operationVieReseauLireTousParDate"; //$NON-NLS-1$
    String OPERATION_VIE_RESEAU_LIRE_TOUS_PAR_CLE_RECHERCHE = "operationVieReseauLireTousParCleRecherche"; //$NON-NLS-1$
    String OPERATION_VIE_RESEAU_MODIFIER_STATUT = "operationVieReseauModifierStatut"; //$NON-NLS-1$
    String OPERATION_VIE_RESEAU_MODIFIER_LISTE_CLIENT_IMPACTE = "operationVieReseauModifierListeClientImpacte"; //$NON-NLS-1$

    String CLE_RECHERCHE_OPERATION_VIE_RESEAU_CREER_LISTE = "cleRechercheOperationVieReseauCreerListe"; //$NON-NLS-1$

    String BLOCAGE_EQUIPEMENT_CREER = "blocageEquipementCreer";//$NON-NLS-1$
    String BLOCAGE_EQUIPEMENT_LIRE_UN = "blocageEquipementLireUn"; //$NON-NLS-1$
    String BLOCAGE_EQUIPEMENT_MODIFIER = "blocageEquipementModifier"; //$NON-NLS-1$
    String BLOCAGE_EQUIPEMENT_SUPPRIMER = "blocageEquipementSupprimer"; //$NON-NLS-1$

    String CLE_RECHERCHE_BLOCAGE_EQUIPEMENT_CREER_LISTE = "cleRechercheBlocageEquipementCreerListe"; //$NON-NLS-1$

    String LIGNE_DE_TEST_ELIG_DSL_LIRE_UN = "ligneDeTestEligDSLLireUn"; //$NON-NLS-1$
    String LIGNE_DE_TEST_ELIG_DSL_LIRE_TOUS = "ligneDeTestEligDSLLireTous"; //$NON-NLS-1$
    String LIGNE_DE_TEST_ELIG_DSL_CREER = "ligneDeTestEligDSLCreer"; //$NON-NLS-1$
    String LIGNE_DE_TEST_ELIG_DSL_MODIFIER = "ligneDeTestEligDSLModifier"; //$NON-NLS-1$
    String LIGNE_DE_TEST_ELIG_DSL_SUPPRIMER = "ligneDeTestEligDSLSupprimer"; //$NON-NLS-1$
  }

  private interface IUrl
  {
    /** Url for PAD6001 */
    String COMPARAISON_COMMERCIALE_COMPOSITE = "/ExecuteGenericRequestV2/comparaisonCommercialeComposite"; //$NON-NLS-1$
    /** Url for PAD6002 */
    String RECONCILIATION_COMMERCIALE = "/ExecuteGenericRequestV2/reconciliationCommerciale"; //$NON-NLS-1$
    /** Url for PAD6003 */
    String ERREUR_SPIRIT = "/ExecuteGenericRequestV2/erreurSpirit"; //$NON-NLS-1$
    /** Url for PAD6005 */
    String RECONCILIATION_COMMERCIALE_EN_MASSE = "/ExecuteGenericRequestV2/reconciliationCommercialeEnMasse"; //$NON-NLS-1$
    /** Url for PAD6006 */
    String CONFIGURATION_PFS_COMPOSITE = "/ExecuteGenericRequestV2/configurationPfsComposite"; //$NON-NLS-1$
    /** Url for PAD6007 */
    String CONFIGURATION_PROSPER = "/ExecuteGenericRequestV2/configurationProsper"; //$NON-NLS-1$
    /** Url for PAD6008 */
    String NOTIFICATION_RESEAU = "/ExecuteGenericRequestV2/notificationReseau"; //$NON-NLS-1$
    /** Url for PAD6009 */
    String CLE_RECHERCHE_NOTIFICATION_RESEAU = "/ExecuteGenericRequestV2/cleRechercheNotificationReseau"; //$NON-NLS-1$
    /** Url for PAD6010 */
    String HISTORISATION_ELIGIBILITE = "/ExecuteGenericRequestV2/historisationEligibilite"; //$NON-NLS-1$
    /** Url for PAD6011 */
    String OPERATION_VIE_RESEAU = "/ExecuteGenericRequestV2/operationVieReseau"; //$NON-NLS-1$
    /** Url for PAD6012 */
    String CLE_RECHERCHE_OPERATION_VIE_RESEAU = "/ExecuteGenericRequestV2/cleRechercheOperationVieReseau"; //$NON-NLS-1$
    /** Url for PAD6013 */
    String BLOCAGE_EQUIPEMENT = "/ExecuteGenericRequestV2/blocageEquipement"; //$NON-NLS-1$
    /** Url for PAD6014 */
    String CLE_RECHERCHE_BLOCAGE_EQUIPEMENT = "/ExecuteGenericRequestV2/cleRechercheBlocageEquipement"; //$NON-NLS-1$
    /** Url for PAD6015 */
    String LIGNE_DE_TEST_ELIG_DSL = "/ExecuteGenericRequestV2/ligneDeTestEligDSL"; //$NON-NLS-1$
  }

  /** REX base path. */
  private static final String REX_BASE_PATH = "REX"; //$NON-NLS-1$

  /** Transient expected REX server request. */
  private HttpServerRequestActionBuilder _serverRequest;

  /** Transient service. */
  private String _service;

  /** Default Constructor */
  public RexHttpSteps()
  {
    super(REX_BASE_PATH);
  }

  /**
   * Expect request has given query param
   *
   * @param name_p
   *          query param name
   * @param value_p
   *          query param value
   */
  @And("REX query param ([^\"]*)=([^\"]*)$")
  public void expectQueryParam(String name_p, String value_p)
  {
    _serverRequest.queryParam(name_p, value_p);
  }

  /**
   * Expect that REX receives a blocageEquipementCreer request.
   *
   * @param template_p
   *          relative template path
   */
  @When("^REX receives a blocageEquipementCreer request with ([^\"]*)$")
  public void receiveBlocageEquipementCreer(String template_p)
  {
    receiveRequest(IMethod.BLOCAGE_EQUIPEMENT_CREER, template_p, false, false);
  }

  /**
   * Expect that REX receives a blocageEquipementLireUn request.
   */
  @When("^REX receives a blocageEquipementLireUn request$")
  public void receiveBlocageEquipementLireUn()
  {
    receiveRequest(IMethod.BLOCAGE_EQUIPEMENT_LIRE_UN, null, false, false);
  }

  /**
   * Expect that REX receives a blocageEquipementModifier request.
   *
   * @param template_p
   *          relative template path
   */
  @When("^REX receives a blocageEquipementModifier request with ([^\"]*)$")
  public void receiveBlocageEquipementModifier(String template_p)
  {
    receiveRequest(IMethod.BLOCAGE_EQUIPEMENT_MODIFIER, template_p, false, false);
  }

  /**
   * Expect that REX receives a blocageEquipementSupprimer request.
   */
  @When("^REX receives a blocageEquipementSupprimer request$")
  public void receiveBlocageEquipementSupprimer()
  {
    receiveRequest(IMethod.BLOCAGE_EQUIPEMENT_SUPPRIMER, null, false, false);
  }

  /**
   * Expect that REX receives a cleRechercheBlocageEquipementCreerListe request.
   *
   * @param template_p
   *          relative template path
   */
  @When("^REX receives a cleRechercheBlocageEquipementCreerListe request with ([^\"]*)$")
  public void receiveCleRechercheBlocageEquipementCreerListe(String template_p)
  {
    receiveRequest(IMethod.CLE_RECHERCHE_BLOCAGE_EQUIPEMENT_CREER_LISTE, template_p, false, false);
  }

  /**
   * Expect that REX receives a cleRechercheNotificationReseau request.
   *
   * @param template_p
   *          relative template path
   */
  @When("^REX receives a cleRechercheNotificationReseau request with ([^\"]+)$")
  public void receiveCleRechercheNotificationReseau(String template_p)
  {
    receiveRequest(IMethod.CLE_RECHERCHE_NOTIFICATION_RESEAU, template_p, false, false);
  }

  /**
   * Expect that REX receives a cleRechercheOperationVieReseauCreerListe request.
   *
   * @param template_p
   *          relative template path
   */
  @When("^REX receives a cleRechercheOperationVieReseauCreerListe request with ([^\"]*)$")
  public void receiveCleRechercheOperationVieReseauCreerListe(String template_p)
  {
    receiveRequest(IMethod.CLE_RECHERCHE_OPERATION_VIE_RESEAU_CREER_LISTE, template_p, false, false);
  }

  /**
   * Expect that REX receives a comparaisonCommercialeComposite request.
   *
   * @param template_p
   *          relative template path
   */
  @When("^REX receives a comparaisonCommercialeComposite request with ([^\\\"]*)$")
  public void receiveComparaisonCommercialeComposite(String template_p)
  {
    receiveRequest(IMethod.COMPARAISON_COMMERCIALE_COMPOSITE, template_p, false, false);
  }

  /**
   * Expect that REX receives a configurationPfsCompositeGererEcrireConfigurationPfs request.
   *
   * @param template_p
   *          relative template path
   */
  @When("^REX receives a configurationPfsCompositeGererEcrireConfigurationPfs request with ([^\"]*)$")
  public void receiveConfigurationPfsCompositeGererEcrireConfigurationPfs(String template_p)
  {
    receiveRequest(IMethod.CONFIGURATION_PFS_COMPOSITE_GERER_ECRIRE_CONFIGURATION_PFS, template_p, false, true);
  }

  /**
   * Expect that REX receives a configurationPfsCompositeGererEcrirePfs request.
   *
   * @param template_p
   *          relative template path
   */
  @When("^REX receives a configurationPfsCompositeGererEcrirePfs request with ([^\"]*)$")
  public void receiveConfigurationPfsCompositeGererEcrirePfs(String template_p)
  {
    receiveRequest(IMethod.CONFIGURATION_PFS_COMPOSITE_GERER_ECRIRE_PFS, template_p, false, true);
  }

  /**
   * Expect that REX receives a configurationPfsCompositeGererSuppressionConfigurationPfs request.
   *
   * @param template_p
   *          relative template path
   */
  @When("^REX receives a configurationPfsCompositeGererSuppressionConfigurationPfs request with ([^\"]*)$")
  public void receiveConfigurationPfsCompositeGererSuppressionConfigurationPfs(String template_p)
  {
    receiveRequest(IMethod.CONFIGURATION_PFS_COMPOSITE_GERER_SUPPRESSION_CONFIGURATION_PFS, template_p, false, true);
  }

  /**
   * Expect that REX receives a configurationPfsCompositeGererSuppressionConfigurationPfs request.
   *
   * @param template_p
   *          relative template path
   */
  @When("^REX receives a configurationPfsCompositeGererSuppressionPfs request with ([^\"]*)$")
  public void receiveConfigurationPfsCompositeGererSuppressionPfs(String template_p)
  {
    receiveRequest(IMethod.CONFIGURATION_PFS_COMPOSITE_GERER_SUPPRESSION_PFS, template_p, false, true);
  }

  /**
   * Expect that REX receives a requeteExploitationLireUn request.
   */
  @When("^REX receives a configurationPfsCompositeLireTous request$")
  public void receiveConfigurationPfsCompositeLireTous()
  {
    receiveRequest(IMethod.CONFIGURATION_PFS_COMPOSITE_LIRE_TOUS, null, false, false);
  }

  /**
   * Expect that REX receives a decisionExploitationLireUn request.
   */
  @When("^REX receives a decisionExploitationLireUn request$")
  public void receiveDecisionExploitationLireUn()
  {
    receiveRequest(IMethod.DECISION_EXPLOITATION_LIRE_UN, null, false, false);
  }

  /**
   * Expect that REX receives a erreurSpiritCreer request.
   *
   * @param template_p
   *          relative template path
   */
  @When("^REX receives a erreurSpiritCreer request with ([^\"]+)$")
  public void receiveErreurSpiritCreer(String template_p)
  {
    receiveRequest(IMethod.ERREUR_SPIRIT_CREER, template_p, false, false);
  }

  /**
   * Expect that REX receives a erreurSpiritLireTousParStatutPeriod request.
   */
  @When("^REX receives a erreurSpiritLireTousParStatutPeriod request$")
  public void receiveErreurSpiritLireTousParStatutPeriod()
  {
    receiveRequest(IMethod.ERREUR_SPIRIT_LIRE_TOUS_PAR_STATUT_PERIOD, null, false, false);
  }

  /**
   * Expect that REX receives a erreurSpiritModifierStatut request.
   *
   * @param template_p
   *          relative template path
   */
  @When("^REX receives an erreurSpiritModifierStatut request with ([^\"]*)$")
  public void receiveErreurSpiritModifierStatut(String template_p)
  {
    receiveRequest(IMethod.ERREUR_SPIRIT_MODIFIER_STATUT, template_p, false, false);
  }

  /**
   * Expect that REX receives a historisationEligibiliteCreer request.
   *
   * @param template_p
   *          relative template path
   */
  @Given("REX receives a historisationEligibiliteCreer request with ([^\"]*)$")
  public void receiveHistorisationEligibiliteCreer(String template_p)
  {
    receiveRequest(IMethod.HISTORISATION_ELIGIBILITE_CREER, template_p, false, false);
  }

  /**
   * Expect that REX receives a reconciliationCommercialeCreer request.
   *
   * @param template_p
   *          relative template path
   */
  @When("^REX receives a notificationReseauCreer request with ([^\"]*)$")
  public void receiveNotificationReseauCreer(String template_p)
  {
    receiveRequest(IMethod.NOTIFICATION_RESEAU_CREER, template_p, false, false);
  }

  /**
   * Expect that REX receives a notificationReseauLireUn request.
   */
  @When("^REX receives a notificationReseauLireUn request$")
  public void receiveNotificationReseauLireUn()
  {
    receiveRequest(IMethod.NOTIFICATION_RESEAU_LIRE_UN, null, false, false);
  }

  /**
   * Expect that REX receives a notificationReseauModifierStatut request.
   *
   * @param template_p
   *          relative template path
   */
  @When("^REX receives a notificationReseauModifierStatut request with ([^\"]*)$")
  public void receivenotificationReseauModifierStatut(String template_p)
  {
    receiveRequest(IMethod.NOTIFICATION_RESEAU_MODIFIER_STATUT, template_p, false, false);
  }

  /**
   * Expect that REX receives a operationVieReseauCreer request.
   *
   * @param template_p
   *          relative template path
   */
  @When("^REX receives a operationVieReseauCreer request with ([^\"]*)$")
  public void receiveOperationVieReseauCreer(String template_p)
  {
    receiveRequest(IMethod.OPERATION_VIE_RESEAU_CREER, template_p, false, false);
  }

  /**
   * Expect that REX receives a operationVieReseauLireTousParCleRecherche request.
   */
  @When("^REX receives a operationVieReseauLireTousParCleRecherche request$")
  public void receiveOperationVieReseauLireTousParCleRecherche()
  {
    receiveRequest(IMethod.OPERATION_VIE_RESEAU_LIRE_TOUS_PAR_CLE_RECHERCHE, null, false, false);
  }

  /**
   * Expect that REX receives a operationVieReseauLireTousParDate request.
   */
  @When("^REX receives a operationVieReseauLireTousParDate request$")
  public void receiveOperationVieReseauLireTousParDate()
  {
    receiveRequest(IMethod.OPERATION_VIE_RESEAU_LIRE_TOUS_PAR_DATE, null, false, false);
  }

  /**
   * Expect that REX receives a operationVieReseauLireUn request.
   */
  @When("^REX receives a operationVieReseauLireUn request$")
  public void receiveOperationVieReseauLireUn()
  {
    receiveRequest(IMethod.OPERATION_VIE_RESEAU_LIRE_UN, null, false, false);
  }

  /**
   * Expect that REX receives a operationVieReseauModifierListeClientImpacte request.
   *
   * @param template_p
   *          relative template path
   */
  @When("^REX receives a operationVieReseauModifierListeClientImpacte request with ([^\"]*)$")
  public void receiveOperationVieReseauModifierListeClientImpacte(String template_p)
  {
    receiveRequest(IMethod.OPERATION_VIE_RESEAU_MODIFIER_LISTE_CLIENT_IMPACTE, template_p, false, false);
  }

  /**
   * Expect that REX receives a operationVieReseauModifierStatut request.
   *
   * @param template_p
   *          relative template path
   */
  @When("^REX receives a operationVieReseauModifierStatut request with ([^\"]*)$")
  public void receiveOperationVieReseauModifierStatut(String template_p)
  {
    receiveRequest(IMethod.OPERATION_VIE_RESEAU_MODIFIER_STATUT, template_p, false, false);
  }

  /**
   * Expect that REX receives a reconciliationCommercialeCreer request.
   *
   * @param template_p
   *          relative template path
   */
  @When("^REX receives a reconciliationCommercialeCreer request with ([^\"]*)$")
  public void receiveReconciliationCommercialeCreer(String template_p)
  {
    receiveRequest(IMethod.RECONCILIATION_COMMERCIALE_CREER, template_p, true, false);
  }

  /**
   * Expect that REX receives a reconciliationCommercialeEnMasseAcquitterUn request.
   *
   * @param template_p
   *          relative template path
   */
  @When("^REX receives a reconciliationCommercialeEnMasseAcquitterUn request with ([^\"]*)$")
  public void receiveReconciliationCommercialeEnMasseAcquitterUn(String template_p)
  {
    receiveRequest(IMethod.RECONCILIATION_COMMERCIALE_EN_MASSE_ACQUITTER_UN, template_p, false, false);
  }

  /**
   * Expect that REX receives a reconciliationCommercialeEnMasseAjouter request.
   *
   * @param template_p
   *          relative template path
   */
  @When("^REX receives a reconciliationCommercialeEnMasseAjouter request with ([^\"]*)$")
  public void receiveReconciliationCommercialeEnMasseAjouter(String template_p)
  {
    receiveRequest(IMethod.RECONCILIATION_COMMERCIALE_EN_MASSE_AJOUTER, template_p, true, false);
  }

  /**
   * Expect that REX receives a reconciliationCommercialeEnMasseLireTous request.
   */
  @When("^REX receives a reconciliationCommercialeEnMasseLireTous request$")
  public void receiveReconciliationCommercialeEnMasseLireTous()
  {
    receiveRequest(IMethod.RECONCILIATION_COMMERCIALE_EN_MASSE_LIRE_TOUS, null, true, false);
  }

  /**
   * Expect that REX receives a reconciliationCommercialeLireTousParClientOperateurNoCompte request.
   */
  @When("^REX receives a reconciliationCommercialeLireTousParClientOperateurNoCompte request$")
  public void receiveReconciliationCommercialeLireTousParClientOperateurNoCompte()
  {
    receiveRequest(IMethod.RECONCILIATION_COMMERCIALE_LIRE_TOUS_PAR_CLIENT_OPERATEUR_NO_COMPTE, null, false, false);
  }

  /**
   * Expect that REX receives a reconciliationCommercialeLireTousParIdReconciliation request.
   */
  @When("^REX receives a reconciliationCommercialeLireTousParIdReconciliation request$")
  public void receiveReconciliationCommercialeLireTousParIdReconciliation()
  {
    receiveRequest(IMethod.RECONCILIATION_COMMERCIALE_LIRE_TOUS_PAR_ID_RECONCILIATION, null, false, false);
  }

  /**
   * Expect that REX receives a reconciliationCommercialeModifier request.
   *
   * @param template_p
   *          relative template path
   */
  @When("^REX receives a reconciliationCommercialeModifier request with ([^\"]*)$")
  public void receiveReconciliationCommercialeModifier(String template_p)
  {
    receiveRequest(IMethod.RECONCILIATION_COMMERCIALE_MODIFIER, template_p, false, false);
  }

  /**
   * Expect that REX receives a requeteExploitationLireUn request.
   */
  @When("^REX receives a requeteExploitationLireUn request$")
  public void receiveRequeteExploitationLireUn()
  {
    receiveRequest(IMethod.REQUETE_EXPLOITATION_LIRE_UN, null, false, false);
  }

  /**
   * Expect that REX receives a templateRequeteExploitationLireUn request.
   */
  @When("^REX receives a templateRequeteExploitationLireUn request$")
  public void receiveTemplateRequeteExploitationLireUn()
  {
    receiveRequest(IMethod.TEMPLATE_REQUETE_EXPLOITATION_LIRE_UN, null, false, false);
  }

  /**
   * Expect that REX receives a ligneDeTestEligDSLLireUn request.
   */
  @When("^REX receives a ligneDeTestEligDSLLireUn request$")
  public void receiveLigneDeTestEligDSLLireUn()
  {
    receiveRequest(IMethod.LIGNE_DE_TEST_ELIG_DSL_LIRE_UN, null, false, false);
  }

  /**
   * Expect that REX receives a ligneDeTestEligDSLLireTous request.
   */
  @When("^REX receives a ligneDeTestEligDSLLireTous request$")
  public void receiveLigneDeTestEligDSLLireTous()
  {
    receiveRequest(IMethod.LIGNE_DE_TEST_ELIG_DSL_LIRE_TOUS, null, false, false);
  }

  /**
   * Expect that REX receives a ligneDeTestEligDSLCreer request.
   * @param template_p
   *           relative template path
   */
  @When("^REX receives a ligneDeTestEligDSLCreer request with ([^\"]*)$")
  public void receiveLigneDeTestEligDSLCreer(String template_p)
  {
    receiveRequest(IMethod.LIGNE_DE_TEST_ELIG_DSL_CREER, template_p, false, false);
  }

  /**
   * Expect that REX receives a ligneDeTestEligDSLModifier request.
   * @param template_p
   *           relative template path
   */
  @When("^REX receives a ligneDeTestEligDSLModifier request with ([^\"]*)$")
  public void receiveLigneDeTestEligDSLModifier(String template_p)
  {
    receiveRequest(IMethod.LIGNE_DE_TEST_ELIG_DSL_MODIFIER, template_p, false, false);
  }

  /**
   * Expect that REX receives a ligneDeTestEligDSLSupprimer request.
   */
  @When("^REX receives a ligneDeTestEligDSLSupprimer request$")
  public void receiveLigneDeTestEligDSLSupprimer()
  {
    receiveRequest(IMethod.LIGNE_DE_TEST_ELIG_DSL_SUPPRIMER, null, false, false);
  }

  /**
   * Expect that REX receives a reconciliationCommercialeModifier request.
   *
   * @param statusCode_p
   *          http status code
   * @param template_p
   *          relative template path
   */
  @Then("REX responds status (\\d+) with ([^\"]*)$")
  public void responseAction(Integer statusCode_p, String template_p)
  {
    serverResponseAction(BouchonHttpConfig.REX_SERVER, statusCode_p, templateResource(_service, RESPONSE_DIR, template_p));
  }

  /**
   * REX responds with template
   *
   * @param template_p
   *          relative template path
   */
  @Then("REX responds with ([^\"]*)$")
  public void responseAction(String template_p)
  {
    serverResponseActionOK(BouchonHttpConfig.REX_SERVER, templateResource(_service, RESPONSE_DIR, template_p));
  }

  /**
   * Generic method to receive the request
   *
   * @param method_p
   *          method name to call
   * @param template_p
   *          template file name
   * @param isControlHeaders_p
   * @param isControlXoauth2Login_p
   */
  private void receiveRequest(String method_p, String template_p, boolean isControlHeaders_p, boolean isControlXoauth2Login_p)
  {
    _service = method_p;

    switch (_service)
    {
      // URL_RECONCILIATION_COMMERCIALE
      case IMethod.RECONCILIATION_COMMERCIALE_CREER:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.REX_SERVER).receive()//
            .post(IUrl.RECONCILIATION_COMMERCIALE) //
            .payload(templateResource(_service, REQUEST_DIR, template_p));
        break;
      // URL_HISTORISATION_ELIGIBILITE
      case IMethod.HISTORISATION_ELIGIBILITE_CREER:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.REX_SERVER).receive()//
            .post(IUrl.HISTORISATION_ELIGIBILITE) //
            .payload(templateResource(_service, REQUEST_DIR, template_p));
        break;
      case IMethod.RECONCILIATION_COMMERCIALE_MODIFIER:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.REX_SERVER)//
            .receive()//
            .put(IUrl.RECONCILIATION_COMMERCIALE) //
            .payload(templateResource(_service, REQUEST_DIR, template_p));
        break;
      case IMethod.RECONCILIATION_COMMERCIALE_LIRE_TOUS_PAR_CLIENT_OPERATEUR_NO_COMPTE:
      case IMethod.RECONCILIATION_COMMERCIALE_LIRE_TOUS_PAR_ID_RECONCILIATION:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.REX_SERVER)//
            .receive()//
            .get(IUrl.RECONCILIATION_COMMERCIALE);
        break;
      case IMethod.RECONCILIATION_COMMERCIALE_EN_MASSE_ACQUITTER_UN:
      case IMethod.RECONCILIATION_COMMERCIALE_EN_MASSE_AJOUTER:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.REX_SERVER)//
            .receive()//
            .put(IUrl.RECONCILIATION_COMMERCIALE_EN_MASSE) //
            .payload(templateResource(_service, REQUEST_DIR, template_p));
        break;

      case IMethod.CONFIGURATION_PFS_COMPOSITE_GERER_ECRIRE_CONFIGURATION_PFS:
      case IMethod.CONFIGURATION_PFS_COMPOSITE_GERER_ECRIRE_PFS:
      case IMethod.CONFIGURATION_PFS_COMPOSITE_GERER_SUPPRESSION_CONFIGURATION_PFS:
      case IMethod.CONFIGURATION_PFS_COMPOSITE_GERER_SUPPRESSION_PFS:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.REX_SERVER)//
            .receive()//
            .put(IUrl.CONFIGURATION_PFS_COMPOSITE) //
            .payload(templateResource(_service, REQUEST_DIR, template_p));
        break;
      case IMethod.RECONCILIATION_COMMERCIALE_EN_MASSE_LIRE_TOUS:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.REX_SERVER)//
            .receive()//
            .get(IUrl.RECONCILIATION_COMMERCIALE_EN_MASSE);
        break;

      // URL_ERREUR_SPIRIT
      case IMethod.ERREUR_SPIRIT_LIRE_TOUS_PAR_STATUT_PERIOD:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.REX_SERVER)//
            .receive()//
            .get(IUrl.ERREUR_SPIRIT);
        break;
      case IMethod.ERREUR_SPIRIT_CREER:
        _serverRequest = this.getDesigner() //
            .http() //
            .server(BouchonHttpConfig.REX_SERVER) //
            .receive() //
            .post(IUrl.ERREUR_SPIRIT) //
            .payload(templateResource(_service, REQUEST_DIR, template_p));
        break;
      case IMethod.ERREUR_SPIRIT_MODIFIER_STATUT:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.REX_SERVER)//
            .receive()//
            .put(IUrl.ERREUR_SPIRIT)//
            .payload(templateResource(_service, REQUEST_DIR, template_p));
        break;

      // URL_CONFIGURATION_PROSPER
      case IMethod.TEMPLATE_REQUETE_EXPLOITATION_LIRE_UN:
      case IMethod.REQUETE_EXPLOITATION_LIRE_UN:
      case IMethod.DECISION_EXPLOITATION_LIRE_UN:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.REX_SERVER)//
            .receive()//
            .get(IUrl.CONFIGURATION_PROSPER);
        break;
      default:
        break;

      // URL_NOTIFICATION_RESEAU
      case IMethod.NOTIFICATION_RESEAU_CREER:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.REX_SERVER).receive()//
            .post(IUrl.NOTIFICATION_RESEAU) //
            .payload(templateResource(_service, REQUEST_DIR, template_p));
        break;
      case IMethod.NOTIFICATION_RESEAU_LIRE_UN:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.REX_SERVER).receive()//
            .get(IUrl.NOTIFICATION_RESEAU); //
        break;
      case IMethod.NOTIFICATION_RESEAU_MODIFIER_STATUT:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.REX_SERVER)//
            .receive()//
            .put(IUrl.NOTIFICATION_RESEAU) //
            .payload(templateResource(_service, REQUEST_DIR, template_p));
        break;
      case IMethod.COMPARAISON_COMMERCIALE_COMPOSITE:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.REX_SERVER)//
            .receive()//
            .post(IUrl.COMPARAISON_COMMERCIALE_COMPOSITE) //
            .payload(templateResource(_service, REQUEST_DIR, template_p));
        break;
      case IMethod.CLE_RECHERCHE_NOTIFICATION_RESEAU:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.REX_SERVER)//
            .receive()//
            .post(IUrl.CLE_RECHERCHE_NOTIFICATION_RESEAU) //
            .payload(templateResource(_service, REQUEST_DIR, template_p));
        break;
      case IMethod.CONFIGURATION_PFS_COMPOSITE_LIRE_TOUS:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.REX_SERVER)//
            .receive()//
            .get(IUrl.CONFIGURATION_PFS_COMPOSITE); //
        break;
      // URL OPERATION_VIE_RESEAU
      case IMethod.OPERATION_VIE_RESEAU_CREER:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.REX_SERVER)//
            .receive()//
            .post(IUrl.OPERATION_VIE_RESEAU) //
            .payload(templateResource(_service, REQUEST_DIR, template_p));
        break;
      case IMethod.OPERATION_VIE_RESEAU_LIRE_UN:
      case IMethod.OPERATION_VIE_RESEAU_LIRE_TOUS_PAR_DATE:
      case IMethod.OPERATION_VIE_RESEAU_LIRE_TOUS_PAR_CLE_RECHERCHE:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.REX_SERVER)//
            .receive()//
            .get(IUrl.OPERATION_VIE_RESEAU);
        break;
      case IMethod.OPERATION_VIE_RESEAU_MODIFIER_STATUT:
      case IMethod.OPERATION_VIE_RESEAU_MODIFIER_LISTE_CLIENT_IMPACTE:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.REX_SERVER)//
            .receive()//
            .put(IUrl.OPERATION_VIE_RESEAU) //
            .payload(templateResource(_service, REQUEST_DIR, template_p));
        break;
      // URL CLE_RECHERCHE_OPERATION_VIE_RESEAU
      case IMethod.CLE_RECHERCHE_OPERATION_VIE_RESEAU_CREER_LISTE:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.REX_SERVER)//
            .receive()//
            .post(IUrl.CLE_RECHERCHE_OPERATION_VIE_RESEAU) //
            .payload(templateResource(_service, REQUEST_DIR, template_p));
        break;
      // URL BLOCAGE_EQUIPEMENT
      case IMethod.BLOCAGE_EQUIPEMENT_CREER:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.REX_SERVER)//
            .receive()//
            .post(IUrl.BLOCAGE_EQUIPEMENT) //
            .payload(templateResource(_service, REQUEST_DIR, template_p));
        break;
      case IMethod.BLOCAGE_EQUIPEMENT_LIRE_UN:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.REX_SERVER)//
            .receive()//
            .get(IUrl.BLOCAGE_EQUIPEMENT);
        break;
      case IMethod.BLOCAGE_EQUIPEMENT_MODIFIER:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.REX_SERVER)//
            .receive()//
            .put(IUrl.BLOCAGE_EQUIPEMENT) //
            .payload(templateResource(_service, REQUEST_DIR, template_p));
        break;
      case IMethod.BLOCAGE_EQUIPEMENT_SUPPRIMER:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.REX_SERVER)//
            .receive()//
            .delete(IUrl.BLOCAGE_EQUIPEMENT);
        break;
      // URL CLE_RECHERCHE_BLOCAGE_EQUIPEMENT
      case IMethod.CLE_RECHERCHE_BLOCAGE_EQUIPEMENT_CREER_LISTE:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.REX_SERVER)//
            .receive()//
            .post(IUrl.CLE_RECHERCHE_BLOCAGE_EQUIPEMENT) //
            .payload(templateResource(_service, REQUEST_DIR, template_p));
        break;
      case IMethod.LIGNE_DE_TEST_ELIG_DSL_LIRE_UN:
      case IMethod.LIGNE_DE_TEST_ELIG_DSL_LIRE_TOUS:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.REX_SERVER)//
            .receive()//
            .get(IUrl.LIGNE_DE_TEST_ELIG_DSL);
        break;
      case IMethod.LIGNE_DE_TEST_ELIG_DSL_CREER:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.REX_SERVER)//
            .receive()//
            .post(IUrl.LIGNE_DE_TEST_ELIG_DSL) //
            .payload(templateResource(_service, REQUEST_DIR, template_p));
        break;
      case IMethod.LIGNE_DE_TEST_ELIG_DSL_MODIFIER:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.REX_SERVER)//
            .receive()//
            .put(IUrl.LIGNE_DE_TEST_ELIG_DSL)//
            .payload(templateResource(_service, REQUEST_DIR, template_p));
        break;
      case IMethod.LIGNE_DE_TEST_ELIG_DSL_SUPPRIMER:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.REX_SERVER)//
            .receive()//
            .delete(IUrl.LIGNE_DE_TEST_ELIG_DSL);
        break;
    }

    if (isControlHeaders_p)
    {
      controlReceivedHeaders(_serverRequest, false);
      _serverRequest.header("X-Trace-idCmd", "${custom.idCmd}"); //$NON-NLS-1$//$NON-NLS-2$
    }

    if (isControlXoauth2Login_p)
    {
      _serverRequest.header("X-Oauth2-Login", "@variable('spirit.xOauth2Login')@"); //$NON-NLS-1$//$NON-NLS-2$
    }
  }

}
