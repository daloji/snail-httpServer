/*******************************************************************************
 * $Id: InkHttpSteps.java 25669 2019-08-21 14:57:15Z pramos $
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.test.step;

import com.consol.citrus.dsl.builder.HttpServerRequestActionBuilder;
import cucumber.api.java.en.And;
import org.springframework.http.HttpStatus;

import com.bytel.ravel.step.helper.AbstractHttpSteps;
import com.bytel.spirit.common.test.config.BouchonHttpConfig;

import cucumber.api.java.en.But;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

/**
 *
 * @author JSTRUB
 * @version ($Revision: 25669 $ $Date: 2019-08-21 16:57:15 +0200 (mer. 21 août 2019) $)
 */
public class InkHttpSteps extends AbstractHttpSteps
{
  /** INK base path. */
  private static final String INK_BASE_PATH = "INK"; //$NON-NLS-1$

  /** Url for SpiritAsynchroInk */
  private static final String URL_SPIRIT_ASYNCHRO_INK = "/SpiritAsynchroInk";

  /** Url for SpiritAsynchroInk */
  private static final String URL_SPIRIT_ASYNCHRO_INKV3 = "/SpiritAsynchroInkV3";

  /** Constant for method envoyerDemandeInk */
  private static final String METHOD_ENVOYER_DEMANDE_INK = "envoyerDemandeInk";

  /** Transient service. */
  private String _service;

  /** Transient expected INK server request. */
  private HttpServerRequestActionBuilder _serverRequest;

  /** INK Custom timeout. */
  private Long _inkTimeout = 0L;

  /**
   * Constructor
   */
  public InkHttpSteps()
  {
    super(INK_BASE_PATH);
  }

  /**
   * Check nothing is received by INK.
   */
  @But("^INK receives nothing$")
  public void noReceive()
  {
    serverNoReceive(this.getDesigner(), BouchonHttpConfig.INK_SERVER, _inkTimeout);
    // Reset timeout
    _inkTimeout = 0L;
  }

  /**
   * INK receives any envoyerDemandeInk request.
   *
   * @param template_p
   *          the template to control from
   */
  @When("INK receives an envoyerDemandeInk request with ([^\"]*)$")
  public void receiveResponse(String template_p)
  {
    _service = METHOD_ENVOYER_DEMANDE_INK;

    _serverRequest = this.getDesigner().http()//
        .server(BouchonHttpConfig.INK_SERVER)//
        .receive()//
        .post(URL_SPIRIT_ASYNCHRO_INK)//
        .timeout(_inkTimeout)//
        .payload(templateResource(_service, REQUEST_DIR, template_p));
    // Reset timeout
    _inkTimeout = 0L;
  }

  /**
   * Expect request has given query param
   *
   * @param name_p
   *          query param name
   * @param value_p
   *          query param value
   */
  @And("INK query param ([^\"]*)=\"([^\"]*)\"$")
  public void expectQueryParam(String name_p, String value_p)
  {
    _serverRequest.queryParam(name_p, value_p);
  }

  /**
   * INK receives any envoyerDemandeInk request.
   *
   * @param template_p
   *          the template to control from
   */
  @When("INKV3 receives an envoyerDemandeInk request with ([^\"]*)$")
  public void receiveV3Response(String template_p)
  {
    _service = METHOD_ENVOYER_DEMANDE_INK;

    _serverRequest = this.getDesigner().http()//
        .server(BouchonHttpConfig.INK_V3_SERVER)//
        .receive()//
        .post(URL_SPIRIT_ASYNCHRO_INKV3)//
        .timeout(_inkTimeout)//
        .payload(templateResource(_service, REQUEST_DIR, template_p));
    // Reset timeout
    _inkTimeout = 0L;
  }

  /**
   * INK responds
   *
   * @param template_p
   *          relative template path
   */
  @Then("INK responds with ([^\"]*)$")
  public void sendAction(String template_p)
  {
    _service = METHOD_ENVOYER_DEMANDE_INK;

    this.getDesigner().http()//
        .server(BouchonHttpConfig.INK_SERVER)//
        .respond()//
        .status(HttpStatus.OK)//
        .payload(templateResource(_service, RESPONSE_DIR, template_p));
  }

  /**
   * INKV3 responds
   *
   * @param template_p
   *          relative template path
   */
  @Then("INKV3 responds with ([^\"]*)$")
  public void sendV3Action(String template_p)
  {
    _service = METHOD_ENVOYER_DEMANDE_INK;

    this.getDesigner().http()//
        .server(BouchonHttpConfig.INK_V3_SERVER)//
        .respond()//
        .status(HttpStatus.OK)//
        .payload(templateResource(_service, RESPONSE_DIR, template_p));
  }

  /**
   * Configure INK temporisation on next receive.
   *
   * @param tempo_p
   *          the temporisation in seconds
   */
  @Given("INK will be called with a (\\d+) second temporisation")
  public void tempo(Integer tempo_p)
  {
    _inkTimeout = tempo_p * 1000L;
  }
}
