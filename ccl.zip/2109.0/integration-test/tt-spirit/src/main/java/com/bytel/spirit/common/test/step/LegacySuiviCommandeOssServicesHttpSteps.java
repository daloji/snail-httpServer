/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.test.step;

import com.bytel.spirit.common.test.config.BouchonHttpConfig;
import com.consol.citrus.dsl.builder.HttpServerRequestActionBuilder;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

/**
 *
 * @author jjoly
 * @version ($Revision$ $Date$)
 */
public final class LegacySuiviCommandeOssServicesHttpSteps extends AbstractSpiritHttpSteps
{
  /** OssServices base path. */
  private static final String BASE_PATH = "LEGACY_SUIVI_COMMANDE_OSS_SERVICES"; //$NON-NLS-1$

  /** Url for SuiviCommandeOssService */
  private static final String URL_SUIVI_COMMANDE = "/oss_services_suivi/SuiviCommandeOssService"; //$NON-NLS-1$

  /** Constant for method getContextePourCommande */
  private static final String METHOD_GET_CONTEXTE_POUR_COMMANDE = "getContextePourCommande"; //$NON-NLS-1$

  /** Transient expected OssServices server request. */
  private HttpServerRequestActionBuilder _serverRequest;

  /** Transient service. */
  private String _service;

  /**
   * Constructor
   */
  public LegacySuiviCommandeOssServicesHttpSteps()
  {
    super(BASE_PATH);
  }

  /**
   * OssServices receives getContextePourCommande request.
   *
   * @param template_p
   *          the template to control from
   */
  @When("^SuiviCommandeOss receives a getContextePourCommande request with ([^\"]*)$")
  public void getContextePourCommandeRequest(final String template_p)
  {
    receiveRequest(METHOD_GET_CONTEXTE_POUR_COMMANDE, template_p, false);
  }

  /**
   * OssServices send getContextePourCommande response
   *
   * @param template_p
   *          template file name
   */
  @Then("^SuiviCommandeOss responds with ([^\"]*)$")
  public void getContextePourCommandeResponse(final String template_p)
  {
    sendResponse(template_p);
  }

  /**
   * Generic method to receive the request
   *
   * @param method_p
   *          method name to call
   * @param template_p
   *          template file name
   * @param isControlHeaders_p
   *          true if force header control, false elsewhere
   */
  private void receiveRequest(final String method_p, final String template_p, final boolean isControlHeaders_p)
  {
    _service = method_p;
    switch (_service)
    {
      case METHOD_GET_CONTEXTE_POUR_COMMANDE:
        _serverRequest = getDesigner()//
            .http() //
            .server(BouchonHttpConfig.LEGACY_SUIVI_COMMANDE_OSS_SERVICES_SERVER) //
            .receive() //
            .post(URL_SUIVI_COMMANDE) //
            .payload(templateResource(_service, REQUEST_DIR, template_p));
        break;

      default:
        break;
    }

    if (isControlHeaders_p)
    {
      controlReceivedHeaders(_serverRequest, false);
    }
  }

  /**
   * Generic method to response
   *
   * @param template_p
   *          template file name
   */
  private void sendResponse(final String template_p)
  {
    switch (_service)
    {
      case METHOD_GET_CONTEXTE_POUR_COMMANDE:
        serverResponseActionOK(BouchonHttpConfig.LEGACY_SUIVI_COMMANDE_OSS_SERVICES_SERVER, templateResource(_service, RESPONSE_DIR, template_p));
        break;

      default:
        break;
    }
  }
}
