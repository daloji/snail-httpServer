/*******************************************************************************
 * $Id: BouchonHttpConfig.java 54497 2021-07-16 13:22:17Z jsantos $
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.test.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import com.bytel.ravel.config.RavelHttpConfig;
import com.bytel.ravel.http.StaticResponseInterceptor;
import com.consol.citrus.endpoint.adapter.StaticResponseEndpointAdapter;
import com.consol.citrus.http.message.HttpMessageConverter;
import com.consol.citrus.http.message.HttpMessageHeaders;
import com.consol.citrus.http.server.HttpServer;

/**
 *
 * @author jstrub
 * @version ($Revision: 54497 $ $Date: 2021-07-16 15:22:17 +0200 (ven. 16 juil. 2021) $)
 */
@Configuration
@PropertySource("classpath:spirit-http.properties")
public class BouchonHttpConfig
{
  /**  */
  public static final String RPG_ENDPOINT_ADAPTER = "rpgEndpointAdapter"; //$NON-NLS-1$
  /**  */
  public static final String RES_ENDPOINT_ADAPTER = "resEndpointAdapter"; //$NON-NLS-1$
  /**  */
  public static final String RES_ABAQUES_ENDPOINT_ADAPTER = "resAbaquesEndpointAdapter"; //$NON-NLS-1$
  /**  */
  public static final String AIR_SERVER = "AIR_SERVER"; //$NON-NLS-1$
  /**  */
  public static final String RST_SERVER = "RST_SERVER"; //$NON-NLS-1$
  /**  */
  public static final String CMD_SERVER = "CMD_SERVER"; //$NON-NLS-1$
  /**  */
  public static final String INK_SERVER = "INK_SERVER"; //$NON-NLS-1$

  /**  */
  public static final String SEGA_SERVER = "SEGA_SERVER"; //$NON-NLS-1$

  /**  */
  public static final String INK_V3_SERVER = "INK_V3_SERVER"; //$NON-NLS-1$

  /**  */
  public static final String REX_SERVER = "REX_SERVER"; //$NON-NLS-1$

  /**  */
  public static final String STARK_SERVER = "STARK_SERVER"; //$NON-NLS-1$

  /** */
  public static final String OI_SERVER = "OI_SERVER"; //$NON-NLS-1$

  /** */
  public static final String AUTHENTIFICATION_SERVICE_SERVER = "AUTHENT_SERVER"; //$NON-NLS-1$

  /**  */
  public static final String RPG_SERVER = "RPG_SERVER"; //$NON-NLS-1$
  /**  */
  public static final String RES_SERVER = "RES_SERVER"; //$NON-NLS-1$
  /**  */
  public static final String STW0_SERVER = "STW0_SERVER"; //$NON-NLS-1$
  /**  */
  public static final String STW1_SERVER = "STW1_SERVER"; //$NON-NLS-1$
  /**  */
  public static final String STW2_SERVER = "STW2_SERVER"; //$NON-NLS-1$
  /**  */
  public static final String CONVERGYS_SERVER = "CONVERGYS_SERVER"; //$NON-NLS-1$
  /**  */
  public static final String PFS_RPC_SERVER = "PFS_RPC_SERVER"; //$NON-NLS-1$
  /**  */
  public static final String VMS_VSTW_RPC = "VMS_VSTW_RPC"; //$NON-NLS-1$
  /**  */
  public static final String VMS_VSTW_RPC_V2 = "VMS_VSTW_RPC_V2"; //$NON-NLS-1$
  /**  */
  public static final String LEGACY_SRM_SERVER = "LEGACY_SRM_SERVER"; //$NON-NLS-1$
  /**  */
  public static final String LEGACY_VOIP_SERVER = "LEGACY_VOIP_SERVER"; //$NON-NLS-1$
  /**  */
  public static final String LEGACY_EQUIPEMENT_SERVER = "LEGACY_EQUIPEMENT_SERVER"; //$NON-NLS-1$
  /** */
  public static final String LEGACY_DIAG_ORDER_MANAGEMENT_SERVER = "LEGACY_DIAG_ORDER_MANAGEMENT_SERVER"; //$NON-NLS-1$
  /** */
  public static final String LEGACY_GUICHET_COMMANDE_OSS_SERVICES_SERVER = "LEGACY_GUICHET_COMMANDE_OSS_SERVICES_SERVER"; //$NON-NLS-1$
  /** */
  public static final String LEGACY_GUICHET_USAGE_OSS_SERVICES_SERVER = "LEGACY_GUICHET_USAGE_OSS_SERVICES_SERVER"; //$NON-NLS-1$
  /** */
  public static final String LEGACY_SUIVI_COMMANDE_OSS_SERVICES_SERVER = "LEGACY_SUIVI_COMMANDE_OSS_SERVICES_SERVER"; //$NON-NLS-1$
  /** */
  public static final String LEGACY_PADAWAN_FTTH_SERVER = "LEGACY_PADAWAN_FTTH_SERVER"; //$NON-NLS-1$
  /** */
  public static final String LEGACY_ELIGTECH_SERVER = "LEGACY_ELIGTECH_SERVER"; //$NON-NLS-1$

  /** */
  public static final String BSS_GP_SERVER = "BSSGP_SERVER"; //$NON-NLS-1$

  /** */
  public static final String BSS_GP_SUBOX_SERVER = "BSSGPSUBOX_SERVER"; //$NON-NLS-1$

  /** */
  public static final String BSS_GP_ELIG_EQUIPEMENT_SERVER = "BSS_GP_ELIG_EQUIPEMENT_SERVER"; //$NON-NLS-1$
  /**  */
  public static final String MMSC_SERVER = "MMSC_SERVER"; //$NON-NLS-1$
  /**  */
  public static final String SB_SERVER = "SB_SERVER"; //$NON-NLS-1$

  /**  */
  public static final String XV_SERVER = "XV_SERVER"; //$NON-NLS-1$

  /**
   *
   */
  public static final String NRM_SERVER = "NRM_SERVER"; //$NON-NLS-1$

  /** */
  public static final String SMV_AUTHENTICATION_SERVER = "SMV_AUTHENTICATION_SERVER"; //$NON-NLS-1$

  /** */
  public static final String SMV_PROV_SERVER = "SMV_PROV_SERVER"; //$NON-NLS-1$

  /** */
  public static final String DARES_SERVICE_TV_SERVER = "DARES_SERVICE_TV_SERVER"; //$NON-NLS-1$

  /** */
  public static final String DARES_TOKEN_TV_SERVER = "DARES_TOKEN_TV_SERVER"; //$NON-NLS-1$

  /** */
  public static final String ACS_NBI_1_SERVER = "ACS_NBI_1_SERVER"; //$NON-NLS-1$

  /** */
  public static final String ACS_NBI_2_SERVER = "ACS_NBI_2_SERVER"; //$NON-NLS-1$

  /** Ravel's HTTP Config. */
  @Autowired
  private RavelHttpConfig _ravelConfig;

  /** */
  @Value("${air.host}")
  private String _airHost;
  /** */
  @Value("${air.port}")
  private Integer _airPort;

  /** */
  @Value("${rst.host}")
  private String _rstHost;
  /** */
  @Value("${rst.port}")
  private Integer _rstPort;

  /** */
  @Value("${cmd.host}")
  private String _cmdHost;
  /** */
  @Value("${cmd.port}")
  private Integer _cmdPort;

  /** */
  @Value("${ink.host}")
  private String _inkHost;
  /** */
  @Value("${ink.port}")
  private Integer _inkPort;

  /** */
  @Value("${inkV3.host}")
  private String _inkV3Host;
  /** */
  @Value("${inkV3.port}")
  private Integer _inkV3Port;

  /** */
  @Value("${rex.host}")
  private String _rexHost;
  /** */
  @Value("${rex.port}")
  private Integer _rexPort;

  /** */
  @Value("${res.host}")
  private String _resHost;
  /** */
  @Value("${res.port}")
  private Integer _resPort;

  /** */
  @Value("${rpg.host}")
  private String _rpgHost;

  /** */
  @Value("${rpg.port}")
  private Integer _rpgPort;

  /**  */
  @Value("${stw0.host}")
  private String _stwHost0;

  /**  */
  @Value("${stw0.port}")
  private Integer _stwPort0;

  /**  */
  @Value("${stw1.host}")
  private String _stwHost1;

  /**  */
  @Value("${stw1.port}")
  private Integer _stwPort1;

  /**  */
  @Value("${stw2.host}")
  private String _stwHost2;

  /**  */
  @Value("${stw2.port}")
  private Integer _stwPort2;

  /**  */
  @Value("${convergys.host}")
  private String _convergysHost;

  /**  */
  @Value("${convergys.port}")
  private Integer _convergysPort;

  /**  */
  @Value("${pfsRpc.host}")
  private String _pfsRpcHost;

  /**  */
  @Value("${pfsRpc.port}")
  private Integer _pfsRpcPort;

  /**  */
  @Value("${vmsVSTwRpc.host}")
  private String _vmsVSTwRpcHost;

  /**  */
  @Value("${vmsVSTwRpc.port}")
  private Integer _vmsVSTwRpcPort;

  /**  */
  @Value("${vmsVSTwRpcV2.host}")
  private String _vmsVSTwRpcV2Host;

  /**  */
  @Value("${vmsVSTwRpcV2.port}")
  private Integer _vmsVSTwRpcV2Port;

  /**  */
  @Value("${legacyVoip.host}")
  private String _legacyVoipHost;

  /**  */
  @Value("${legacyVoip.port}")
  private Integer _legacyVoipPort;

  /**  */
  @Value("${legacyEquipement.host}")
  private String _legacyEquipementHost;

  /**  */
  @Value("${legacyEquipement.port}")
  private Integer _legacyEquipementPort;

  /**  */
  @Value("${legacySrm.host}")
  private String _legacySrmHost;

  /**  */
  @Value("${legacySrm.port}")
  private Integer _legacySrmPort;

  /**  */
  @Value("${stark.host}")
  private String _starkHost;

  /**  */
  @Value("${stark.port}")
  private Integer _starkPort;

  /** */
  @Value("${oi.host}")
  private String _oiHost;

  /** */
  @Value("${oi.port}")
  private Integer _oiPort;

  /** */
  @Value("${authentService.host}")
  private String _authentServiceHost;

  /** */
  @Value("${authentService.port}")
  private Integer _authentServicePort;

  /** */
  @Value("${legacyDiagOrderManagement.host}")
  private String _legacyDiagOrderManagementHost;

  /** */
  @Value("${legacyDiagOrderManagement.port}")
  private Integer _legacyDiagOrderManagementPort;

  /** */
  @Value("${legacyOssServicesGuichetUsage.host}")
  private String _legacyOssServicesGuichetUsageHost;

  /** */
  @Value("${legacyOssServicesGuichetUsage.port}")
  private Integer _legacyOssServicesGuichetUsagePort;

  /** */
  @Value("${legacyOssServicesGuichetCommande.host}")
  private String _legacyOssServicesGuichetCommandeHost;

  /** */
  @Value("${legacyOssServicesGuichetCommande.port}")
  private Integer _legacyOssServicesGuichetCommandePort;

  /** */
  @Value("${legacyOssServicesSuiviCommande.host}")
  private String _legacyOssServicesSuiviCommandeHost;

  /** */
  @Value("${legacyOssServicesSuiviCommande.port}")
  private Integer _legacyOssServicesSuiviCommandePort;

  /** */
  @Value("${legacyPadawanFtth.host}")
  private String _legacyPadawanFtthHost;
  /** */
  @Value("${legacyPadawanFtth.port}")
  private Integer _legacyPadawanFtthPort;

  /** */
  @Value("${legacyEligTech.host}")
  private String _legacyEligTechHost;
  /** */
  @Value("${legacyEligTech.port}")
  private Integer _legacyEligTechPort;

  /** */
  @Value("${bssGp.host}")
  private String _bssGpHost;

  /** */
  @Value("${bssGp.port}")
  private Integer _bssGpPort;

  /** */
  @Value("${bssGpSubox.host}")
  private String _bssGpSuboxHost;

  /** */
  @Value("${bssGpSubox.port}")
  private Integer _bssGpSuboxPort;

  /** */
  @Value("${bssGpEligEquipement.host}")
  private String _bssGpEligEquipementHost;

  /** */
  @Value("${bssGpEligEquipement.port}")
  private Integer _bssGpEligEquipementPort;

  /** */
  @Value("${mmsc.host}")
  private String _mmscHost;
  /** */
  @Value("${mmsc.port}")
  private Integer _mmscPort;

  /** */
  @Value("${sb.host}")
  private String _sbHost;
  /** */
  @Value("${sb.port}")
  private Integer _sbPort;

  /**  */
  @Value("${xv.host}")
  private String _xvHost;

  /**  */
  @Value("${xv.port}")
  private Integer _xvPort;

  /**  */
  @Value("${nrm.host}")
  private String _nrmHost;

  /**  */
  @Value("${nrm.port}")
  private Integer _nrmPort;

  /** */
  @Value("${smvAuthentication.host}")
  private String _smvAuthenticationHost;

  /**  */
  @Value("${smvAuthentication.port}")
  private Integer _smvAuthenticationPort;

  /** */
  @Value("${smvProv.host}")
  private String _smvProvHost;

  /**  */
  @Value("${smvProv.port}")
  private Integer _smvProvPort;

  /** */
  @Value("${daresServiceTv.host}")
  private String _daresServiceTvHost;

  /**  */
  @Value("${daresServiceTv.port}")
  private Integer _daresServiceTvPort;

  /** */
  @Value("${daresTokenTv.host}")
  private String _daresTokenTvHost;

  /**  */
  @Value("${daresTokenTv.port}")
  private Integer _daresTokenTvPort;

  /** */
  @Value("${acsNbi1.host}")
  private String _acsNbi1Host;

  /**  */
  @Value("${acsNbi1.port}")
  private Integer _acsNbi1Port;

  /** */
  @Value("${acsNbi2.host}")
  private String _acsNbi2Host;

  /**  */
  @Value("${acsNbi2.port}")
  private Integer _acsNbi2Port;

  /** */
  @Value("${sega.host}")
  private String _segaHost;

  /**  */
  @Value("${sega.port}")
  private Integer _segaPort;

  /**
   * Configure the acsNbi1 server
   *
   * @return the acsNbi1 server
   */
  @Bean(name = ACS_NBI_1_SERVER)
  public HttpServer acsNbi1Server()
  {
    return _ravelConfig.initHttpServerBuilder(ACS_NBI_1_SERVER, _acsNbi1Host, _acsNbi1Port).build();
  }

  /**
   * Configure the acsNbi2 server
   *
   * @return the acsNbi2 server
   */
  @Bean(name = ACS_NBI_2_SERVER)
  public HttpServer acsNbi2Server()
  {
    return _ravelConfig.initHttpServerBuilder(ACS_NBI_2_SERVER, _acsNbi2Host, _acsNbi2Port).build();
  }

  /**
   * Configure the AIR server
   *
   * @return the AIR server
   */
  @Bean(name = AIR_SERVER)
  public HttpServer airServer()
  {
    return _ravelConfig.initHttpServerBuilder(AIR_SERVER, _airHost, _airPort).build();
  }

  /**
   * Configure the Authentification service server
   *
   * @return the Authentification service server
   */
  @Bean(name = AUTHENTIFICATION_SERVICE_SERVER)
  public HttpServer authentServiceServer()
  {
    return _ravelConfig.initHttpServerBuilder(AUTHENTIFICATION_SERVICE_SERVER, _authentServiceHost, _authentServicePort).build();
  }

  /**
   * Configure the bssGpEligEquipemen server
   *
   * @return the bssGpEligEquipemen server
   */
  @Bean(name = BSS_GP_ELIG_EQUIPEMENT_SERVER)
  public HttpServer bssGpEligEquipementServer()
  {
    return _ravelConfig.initHttpServerBuilder(BSS_GP_ELIG_EQUIPEMENT_SERVER, _bssGpEligEquipementHost, _bssGpEligEquipementPort).build();
  }

  /**
   * Configure the BSSGP server
   *
   * @return the BSSGP server
   */
  @Bean(name = BSS_GP_SERVER)
  public HttpServer bssGpServer()
  {
    return _ravelConfig.initHttpServerBuilder(BSS_GP_SERVER, _bssGpHost, _bssGpPort).build();
  }

  /**
   * Configure the BSS_GP_SUBOX_SERVER server
   *
   * @return the BSS_GP_SUBOX_SERVER server
   */
  @Bean(name = BSS_GP_SUBOX_SERVER)
  public HttpServer bssGpSuboxServer()
  {
    return _ravelConfig.initHttpServerBuilder(BSS_GP_SUBOX_SERVER, _bssGpSuboxHost, _bssGpSuboxPort).build();
  }

  /**
   * Configure the CMD server
   *
   * @return the CMD server
   */
  @Bean(name = CMD_SERVER)
  public HttpServer cmdServer()
  {
    return _ravelConfig.initHttpServerBuilder(CMD_SERVER, _cmdHost, _cmdPort).build();
  }

  /**
   * Configure the CONVERGYS_SERVER
   *
   * @return STW0_SERVER
   */
  @Bean(name = CONVERGYS_SERVER)
  public HttpServer convergysServer()
  {
    return _ravelConfig.initHttpServerBuilder(CONVERGYS_SERVER, _convergysHost, _convergysPort).build();
  }

  /**
   * Configure the DARES_SERVICE_TV_SERVER
   *
   * @return DARES_SERVICE_TV_SERVER
   */
  @Bean(name = DARES_SERVICE_TV_SERVER)
  public HttpServer daresServiceTvServer()
  {
    return _ravelConfig.initHttpServerBuilder(DARES_SERVICE_TV_SERVER, _daresServiceTvHost, _daresServiceTvPort).build();
  }

  /**
   * Configure the DARES_TOKEN_TV_SERVER
   *
   * @return DARES_TOKEN_TV_SERVER
   */
  @Bean(name = DARES_TOKEN_TV_SERVER)
  public HttpServer daresTokenTvServer()
  {
    return _ravelConfig.initHttpServerBuilder(DARES_TOKEN_TV_SERVER, _daresTokenTvHost, _daresTokenTvPort).build();
  }

  /**
   * Configure the DIAG_SERVER
   *
   * @return DIAG_SERVER
   */
  @Bean(name = LEGACY_DIAG_ORDER_MANAGEMENT_SERVER)
  public HttpServer diagOrderManagementServer()
  {
    return _ravelConfig.initHttpServerBuilder(LEGACY_DIAG_ORDER_MANAGEMENT_SERVER, _legacyDiagOrderManagementHost, _legacyDiagOrderManagementPort).build();
  }

  /**
   * Configure LEGACY_ELIGTECH_SERVER
   *
   * @return LEGACY_ELIGTECH_SERVER
   */
  @Bean(name = LEGACY_ELIGTECH_SERVER)
  public HttpServer eligTechServer()
  {
    return _ravelConfig.initHttpServerBuilder(LEGACY_ELIGTECH_SERVER, _legacyEligTechHost, _legacyEligTechPort).build();
  }

  /**
   * Configure the LEGACY_GUICHET_COMMANDE_OSS_SERVICES_SERVER
   *
   * @return LEGACY_GUICHET_COMMANDE_OSS_SERVICES_SERVER
   */
  @Bean(name = LEGACY_GUICHET_COMMANDE_OSS_SERVICES_SERVER)
  public HttpServer guichetCommandeOssServicesServer()
  {
    return _ravelConfig.initHttpServerBuilder(LEGACY_GUICHET_COMMANDE_OSS_SERVICES_SERVER, _legacyOssServicesGuichetCommandeHost, _legacyOssServicesGuichetCommandePort).build();
  }

  /**
   * Configure the LEGACY_GUICHET_USAGE_OSS_SERVICES_SERVER
   *
   * @return LEGACY_GUICHET_USAGE_OSS_SERVICES_SERVER
   */
  @Bean(name = LEGACY_GUICHET_USAGE_OSS_SERVICES_SERVER)
  public HttpServer guichetUsageOssServicesServer()
  {
    return _ravelConfig.initHttpServerBuilder(LEGACY_GUICHET_USAGE_OSS_SERVICES_SERVER, _legacyOssServicesGuichetUsageHost, _legacyOssServicesGuichetUsagePort).build();
  }

  /**
   * Configure the INK server
   *
   * @return the INK server
   */
  @Bean(name = INK_SERVER)
  public HttpServer inkServer()
  {
    return _ravelConfig.initHttpServerBuilder(INK_SERVER, _inkHost, _inkPort).build();
  }

  /**
   * Configure the INK V3 server
   *
   * @return the INK V3 server
   */
  @Bean(name = INK_V3_SERVER)
  public HttpServer inkV3Server()
  {
    return _ravelConfig.initHttpServerBuilder(INK_V3_SERVER, _inkV3Host, _inkV3Port).build();
  }

  /**
   * Configure the LEGACY_EQUIPEMENT_SERVER
   *
   * @return LEGACY_EQUIPEMENT_SERVER
   */
  @Bean(name = LEGACY_EQUIPEMENT_SERVER)
  public HttpServer legacyEquipementServer()
  {
    return _ravelConfig.initHttpServerBuilder(LEGACY_EQUIPEMENT_SERVER, _legacyEquipementHost, _legacyEquipementPort).build();
  }

  /**
   * Configure the LEGACY_SRM_SERVER
   *
   * @return LEGACY_SRM_SERVER
   */
  @Bean(name = LEGACY_SRM_SERVER)
  public HttpServer legacySrmServer()
  {
    return _ravelConfig.initHttpServerBuilder(LEGACY_SRM_SERVER, _legacySrmHost, _legacySrmPort).build();
  }

  /**
   * Configure the LEGACY_VOIP_SERVER
   *
   * @return LEGACY_VOIP_SERVER
   */
  @Bean(name = LEGACY_VOIP_SERVER)
  public HttpServer legacyVoipServer()
  {
    return _ravelConfig.initHttpServerBuilder(LEGACY_VOIP_SERVER, _legacyVoipHost, _legacyVoipPort).build();
  }

  /**
   * Configure the MMSC_SERVER
   *
   * @return MMSC_SERVER
   */
  @Bean(name = MMSC_SERVER)
  public HttpServer mmscServer()
  {
    return _ravelConfig.initHttpServerBuilder(MMSC_SERVER, _mmscHost, _mmscPort).build();
  }

  /**
   * Configure the NRM_SERVER
   *
   * @return NRM_SERVER
   */
  @Bean(name = NRM_SERVER)
  public HttpServer nrmServer()
  {
    return _ravelConfig.initHttpServerBuilder(NRM_SERVER, _nrmHost, _nrmPort).build();
  }

  /**
   * Configure the OI server
   *
   * @return the OI server
   */
  @Bean(name = OI_SERVER)
  public HttpServer oiServer()
  {
    return _ravelConfig.initHttpServerBuilder(OI_SERVER, _oiHost, _oiPort).build();
  }

  /**
   * Configure LEGACY_PADAWAN_FTTH_SERVER
   *
   * @return LEGACY_PADAWAN_FTTH_SERVER
   */
  @Bean(name = LEGACY_PADAWAN_FTTH_SERVER)
  public HttpServer padawanFTTHServer()
  {
    return _ravelConfig.initHttpServerBuilder(LEGACY_PADAWAN_FTTH_SERVER, _legacyPadawanFtthHost, _legacyPadawanFtthPort).build();
  }

  /**
   * Configure the PFS_RPC_SERVER
   *
   * @return PFS_RPC_SERVER
   */
  @Bean(name = PFS_RPC_SERVER)
  public HttpServer pfsRpcServer()
  {
    return _ravelConfig.initHttpServerBuilder(PFS_RPC_SERVER, _pfsRpcHost, _pfsRpcPort).build();
  }

  /**
   * Configure the VMS_VSTW_RPC_V2
   *
   * @return VMS_VSTW_RPC_V2
   */
  @Bean(name = VMS_VSTW_RPC_V2)
  public HttpServer vmsVSTwRpcV2Server()
  {
    return _ravelConfig.initHttpServerBuilder(VMS_VSTW_RPC_V2, _vmsVSTwRpcV2Host, _vmsVSTwRpcV2Port).build();
  }

  /**
   * RES is mock with a configurable static response : it's not part of the scenario.
   *
   * @return the RES endpoint adapter
   */
  @Bean(name = RES_ABAQUES_ENDPOINT_ADAPTER)
  public StaticResponseEndpointAdapter resAbaquesStaticEndpointAdapter()
  {
    StaticResponseEndpointAdapter resStaticEndpoint = new StaticResponseEndpointAdapter();
    resStaticEndpoint.getMessageHeader().put(HttpMessageHeaders.HTTP_STATUS_CODE, 200);
    return resStaticEndpoint;
  }

  /**
   * Configure the RES server
   *
   * @return the RES server
   */
  @Bean(name = RES_SERVER)
  public HttpServer resServer(@Autowired HttpMessageConverter converter_p)
  {
    HttpServer server = _ravelConfig.initHttpServerBuilder(RES_SERVER, _resHost, _resPort).build();
    // Réponse statique pour les appels à accesTechnique
    server.getInterceptors().add(new StaticResponseInterceptor(converter_p, resStaticEndpointAdapter(), r -> r.getRequestURI().contains("accesTechnique"))); //$NON-NLS-1$
    server.getInterceptors().add(new StaticResponseInterceptor(converter_p, resAbaquesStaticEndpointAdapter(), r -> r.getRequestURI().contains("abaqueDSL"))); //$NON-NLS-1$
    return server;
  }

  /**
   * RES is mock with a configurable static response : it's not part of the scenario.
   *
   * @return the RES endpoint adapter
   */
  @Bean(name = RES_ENDPOINT_ADAPTER)
  public StaticResponseEndpointAdapter resStaticEndpointAdapter()
  {
    StaticResponseEndpointAdapter resStaticEndpoint = new StaticResponseEndpointAdapter();
    resStaticEndpoint.getMessageHeader().put(HttpMessageHeaders.HTTP_STATUS_CODE, 200);
    return resStaticEndpoint;
  }

  /**
   * Configure the REX server
   *
   * @return the REX server
   */
  @Bean(name = REX_SERVER)
  public HttpServer rexServer()
  {
    return _ravelConfig.initHttpServerBuilder(REX_SERVER, _rexHost, _rexPort).build();
  }

  /**
   * Configure the RPG server
   *
   * @param converter_p
   *          the converter
   * @return the RPG server
   */
  @Bean(name = RPG_SERVER)
  public HttpServer rpgServer(@Autowired HttpMessageConverter converter_p)
  {
    HttpServer server = _ravelConfig.initHttpServerBuilder(RPG_SERVER, _rpgHost, _rpgPort).build();
    // Réponse statique pour les appels à catalogueServiceCommercial
    server.getInterceptors().add(new StaticResponseInterceptor(converter_p, rpgStaticEndpointAdapter(), r -> r.getRequestURI().contains("catalogueServiceCommercial"))); //$NON-NLS-1$
    return server;
  }

  /**
   * RPG is mock with a configurable static response : it's not part of the scenario.
   *
   * @return the RPG endpoint adapter
   */
  @Bean(name = RPG_ENDPOINT_ADAPTER)
  public StaticResponseEndpointAdapter rpgStaticEndpointAdapter()
  {
    StaticResponseEndpointAdapter rpgStaticEndpoint = new StaticResponseEndpointAdapter();
    rpgStaticEndpoint.getMessageHeader().put(HttpMessageHeaders.HTTP_STATUS_CODE, 200);
    return rpgStaticEndpoint;
  }

  /**
   * Configure the RST server
   *
   * @return the RST server
   */
  @Bean(name = RST_SERVER)
  public HttpServer rstServer()
  {
    return _ravelConfig.initHttpServerBuilder(RST_SERVER, _rstHost, _rstPort).build();
  }

  /**
   * Configure the SB server
   *
   * @return the SB server
   */
  @Bean(name = SB_SERVER)
  public HttpServer sbServer()
  {
    return _ravelConfig.initHttpServerBuilder(SB_SERVER, _sbHost, _sbPort).build();
  }

  /**
   * Configure the sega server
   *
   * @return the sega server
   */
  @Bean(name = SEGA_SERVER)
  public HttpServer segaServer()
  {
    return _ravelConfig.initHttpServerBuilder(SEGA_SERVER, _segaHost, _segaPort).build();
  }

  /**
   * Configure the SMV_AUTHENTICATION_SERVER
   *
   * @return SMV_AUTHENTICATION_SERVER
   */
  @Bean(name = SMV_AUTHENTICATION_SERVER)
  public HttpServer smvAuthenticationServer()
  {
    return _ravelConfig.initHttpServerBuilder(SMV_AUTHENTICATION_SERVER, _smvAuthenticationHost, _smvAuthenticationPort).build();
  }

  /**
   * Configure the SMV_PROV_SERVER
   *
   * @return SMV_PROV_SERVER
   */
  @Bean(name = SMV_PROV_SERVER)
  public HttpServer smvProvServer()
  {
    return _ravelConfig.initHttpServerBuilder(SMV_PROV_SERVER, _smvProvHost, _smvProvPort).build();
  }

  /**
   * Configure the STARK_SERVER
   *
   * @return STARK_SERVER
   */
  @Bean(name = STARK_SERVER)
  public HttpServer starkServer()
  {
    return _ravelConfig.initHttpServerBuilder(STARK_SERVER, _starkHost, _starkPort).build();
  }

  /**
   * Configure the STW0_SERVER
   *
   * @return STW0_SERVER
   */
  @Bean(name = STW0_SERVER)
  public HttpServer stw0Server()
  {
    return _ravelConfig.initHttpServerBuilder(STW0_SERVER, _stwHost0, _stwPort0).build();
  }

  /**
   * Configure the STW0_SERVER
   *
   * @return STW0_SERVER
   */
  @Bean(name = STW1_SERVER)
  public HttpServer stw1Server()
  {
    return _ravelConfig.initHttpServerBuilder(STW1_SERVER, _stwHost1, _stwPort1).build();
  }

  /**
   * Configure the STW0_SERVER
   *
   * @return STW0_SERVER
   */
  @Bean(name = STW2_SERVER)
  public HttpServer stw2Server()
  {
    return _ravelConfig.initHttpServerBuilder(STW2_SERVER, _stwHost2, _stwPort2).build();
  }

  /**
   * Configure the LEGACY_SUIVI_COMMANDE_OSS_SERVICES_SERVER
   *
   * @return LEGACY_SUIVI_COMMANDE_OSS_SERVICES_SERVER
   */
  @Bean(name = LEGACY_SUIVI_COMMANDE_OSS_SERVICES_SERVER)
  public HttpServer suiviCommandeOssServicesServer()
  {
    return _ravelConfig.initHttpServerBuilder(LEGACY_SUIVI_COMMANDE_OSS_SERVICES_SERVER, _legacyOssServicesSuiviCommandeHost, _legacyOssServicesSuiviCommandePort).build();
  }

  /**
   * Configure the VMS_VSTW_RPC
   *
   * @return VMS_VSTW_RPC
   */
  @Bean(name = VMS_VSTW_RPC)
  public HttpServer vmsVSTwRpcServer()
  {
    return _ravelConfig.initHttpServerBuilder(VMS_VSTW_RPC, _vmsVSTwRpcHost, _vmsVSTwRpcPort).build();
  }

  /**
   * Configure the XV_SERVER
   *
   * @return XV_SERVER
   */
  @Bean(name = XV_SERVER)
  public HttpServer xvServer()
  {
    return _ravelConfig.initHttpServerBuilder(XV_SERVER, _xvHost, _xvPort).build();
  }

}
