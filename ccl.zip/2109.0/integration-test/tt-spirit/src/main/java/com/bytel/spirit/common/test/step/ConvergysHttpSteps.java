/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.test.step;

import org.apache.commons.lang3.RandomUtils;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.util.MimeTypeUtils;

import com.bytel.ravel.RavelTestException;
import com.bytel.ravel.http.MultipartMessageConverter;
import com.bytel.ravel.http.MultipartMessageValidator;
import com.bytel.spirit.common.test.config.BouchonHttpConfig;
import com.consol.citrus.dsl.builder.HttpServerResponseActionBuilder;
import com.consol.citrus.http.message.HttpMessage;
import com.consol.citrus.message.MessageType;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

/**
 *
 * @author jgregori
 * @version ($Revision$ $Date$)
 */
public class ConvergysHttpSteps extends AbstractSpiritHttpSteps
{
  /** CONVERGYS base path. */
  private static final String BASE_PATH = "CONVERGYS"; //$NON-NLS-1$
  /** Transient service. */
  private String _service;

  /**
   * Constructor
   */
  public ConvergysHttpSteps()
  {
    super(BASE_PATH);
  }

  /**
   * Expect that CVG receives a get request for the service.
   *
   * @param service_p
   *          The service
   * @param path_p
   *          Post path
   */
  @When("^CONVERGYS receives a GET ([^\\s]+) on ([^\\s]+)$")
  public void receiveGetMessageRequest(String service_p, String path_p)
  {
    _service = service_p;
    this.getDesigner().http().server(BouchonHttpConfig.CONVERGYS_SERVER).receive().get(path_p);
  }

  /**
   * Expect that STW receives a export request for the service.
   *
   * @param service_p
   *          The service
   *
   * @param path_p
   *          Post path
   *
   * @param template_p
   *          the template to control
   * @throws RavelTestException
   *           on test setup error
   */
  @When("CONVERGYS receives a POST ([^\\s]+) on ([^\\s]+) with ([^\\s]+)$")
  public void receiveImportMessageRequest(String service_p, String path_p, String template_p)
  {
    _service = service_p;
    this.getDesigner()//
        .http() //
        .server(BouchonHttpConfig.CONVERGYS_SERVER) //
        .receive()//
        .post(path_p)//
        .messageType(MultipartMessageValidator.MESSAGE_TYPE)//
        .header(MultipartMessageConverter.headerKey("data", HttpHeaders.CONTENT_TYPE), MimeTypeUtils.APPLICATION_JSON_VALUE)//$NON-NLS-1$
        .header(MultipartMessageConverter.headerKey("data", MultipartMessageConverter.BODY), templateString(_service, REQUEST_DIR, template_p))//$NON-NLS-1$
        .header(MultipartMessageConverter.headerKey("audio", HttpHeaders.CONTENT_TYPE), "audio/wav");//$NON-NLS-1$//$NON-NLS-2$
  }

  /**
   * Expect that STW receives a export request for the service.
   *
   * @param service_p
   *          The service
   *
   * @param path_p
   *          Post path
   *
   * @param template_p
   *          the template to control
   * @throws RavelTestException
   *           on test setup error
   */
  @When("^CONVERGYS receives a POST ([^\\s]+) on ([^\\s]+) with json ([^\\s]+) and audio ([^\\s]+)$")
  public void receiveImportMessageRequest(String service_p, String path_p, String template_p, String audioTemplate_p)
  {
    _service = service_p;
    this.getDesigner()//
        .http()//
        .server(BouchonHttpConfig.CONVERGYS_SERVER)//
        .receive()//
        .post(path_p)//
        .messageType(MultipartMessageValidator.MESSAGE_TYPE)//
        .header(MultipartMessageConverter.headerKey("data", HttpHeaders.CONTENT_TYPE), MimeTypeUtils.APPLICATION_JSON_VALUE)//$NON-NLS-1$
        .header(MultipartMessageConverter.headerKey("data", MultipartMessageConverter.BODY), templateString(_service, REQUEST_DIR, template_p))//$NON-NLS-1$
        .header(MultipartMessageConverter.headerKey("audio", HttpHeaders.CONTENT_TYPE), "audio/wav") //$NON-NLS-1$//$NON-NLS-2$
        .header(MultipartMessageConverter.headerKey("audio", MultipartMessageConverter.BINARY_BODY), templateHexString(_service, REQUEST_DIR, audioTemplate_p))//$NON-NLS-1$
        .header(MultipartMessageConverter.headerKey("audio", MultipartMessageConverter.PART_TYPE), MessageType.BINARY.toString());//$NON-NLS-1$
  }

  /**
   * Expect that STW receives a export request for the service.
   *
   * @param service_p
   *          The service
   * @param path_p
   *          Post path
   * @param template_p
   *          the template to control
   * @throws RavelTestException
   *           on test setup error
   */
  @When("^CONVERGYS receives a POST ([^\\s]+) on ([^\\s]+) with json ([^\\s]+)$")
  public void receiveImportMessageRequestOnlyJson(String service_p, String path_p, String template_p) throws RavelTestException
  {
    _service = service_p;
    this.getDesigner()//
        .http() //
        .server(BouchonHttpConfig.CONVERGYS_SERVER) //
        .receive()//
        .post(path_p)//
        .messageType(MultipartMessageValidator.MESSAGE_TYPE)//
        .header(MultipartMessageConverter.headerKey("data", HttpHeaders.CONTENT_TYPE), MimeTypeUtils.APPLICATION_JSON_VALUE)//$NON-NLS-1$
        .header(MultipartMessageConverter.headerKey("data", MultipartMessageConverter.BODY), templateString(_service, REQUEST_DIR, template_p));//$NON-NLS-1$
  }

  /**
   * Expect receives a call in connector with fax.
   *
   * @param service_p
   *          The service
   *
   * @param path_p
   *          Post path
   *
   * @param template_p
   *          the template to control
   * @throws RavelTestException
   *           on test setup error
   */
  @When("^CONVERGYS receives a POST ([^\\s]+) on ([^\\s]+) with json ([^\\s]+) and a pdf file$")
  public void receivePostMessageRequest(String service_p, String path_p, String template_p) throws RavelTestException
  {
    _service = service_p;
    this.getDesigner()//
        .http() //
        .server(BouchonHttpConfig.CONVERGYS_SERVER) //
        .receive()//
        .post(path_p)//
        .messageType(MultipartMessageValidator.MESSAGE_TYPE)//
        .header(MultipartMessageConverter.headerKey("data", HttpHeaders.CONTENT_TYPE), MimeTypeUtils.APPLICATION_JSON_VALUE)//$NON-NLS-1$
        .header(MultipartMessageConverter.headerKey("data", MultipartMessageConverter.BODY), templateString(_service, REQUEST_DIR, template_p))//$NON-NLS-1$
        .header(MultipartMessageConverter.headerKey("fax", HttpHeaders.CONTENT_TYPE), "application/pdf");//$NON-NLS-1$//$NON-NLS-2$
  }

  /**
   * ORC responds an error
   *
   * @param statusCode_p
   *          http status code
   */
  @Then("CONVERGYS responds status (\\d+) with audio file ([^\\s]+)$")
  public void audioResponseAction(Integer statusCode_p, String template_p)
  {
    HttpServerResponseActionBuilder serverResponse = this.getDesigner().http().server(BouchonHttpConfig.CONVERGYS_SERVER).respond(HttpStatus.valueOf(statusCode_p));
    serverResponse.contentType("audio/wav");
    serverResponse.messageType(MessageType.BINARY);
    serverResponse.payload(templateResource(_service, RESPONSE_DIR, template_p));
  }

  /**
   * ORC responds an error
   *
   * @param statusCode_p
   *          http status code
   * @param template_p
   *          relative template path
   */
  @Then("^CONVERGYS responds status (\\d+) with ([^\\s]+)$")
  public void errorResponseAction(Integer statusCode_p, String template_p)
  {
    serverResponseAction(BouchonHttpConfig.CONVERGYS_SERVER, statusCode_p, templateResource(_service, RESPONSE_DIR, template_p));
  }

  /**
   * ORC responds an error
   *
   * @param statusCode_p
   *          http status code
   */
  @Then("CONVERGYS responds status (\\d+) with random audio of size (\\d+)$")
  public void randomAudioResponseAction(Integer statusCode_p, Integer size_p)
  {
    HttpServerResponseActionBuilder serverResponse = this.getDesigner().http().server(BouchonHttpConfig.CONVERGYS_SERVER).respond(HttpStatus.valueOf(statusCode_p));
    serverResponse.contentType("audio/wav");
    serverResponse.messageType(MessageType.BINARY);
    serverResponse.message(new HttpMessage(RandomUtils.nextBytes(size_p)));
  }

  @Then("^CONVERGYS responds with status (\\d+)$")
  public void responseActionOK(Integer status_p)
  {
    this.getDesigner().http().server(BouchonHttpConfig.CONVERGYS_SERVER).respond(HttpStatus.valueOf(status_p));
  }
}
