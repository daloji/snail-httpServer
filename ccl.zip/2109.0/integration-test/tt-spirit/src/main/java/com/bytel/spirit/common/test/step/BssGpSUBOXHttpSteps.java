/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.test.step;

import com.bytel.spirit.common.test.config.BouchonHttpConfig;
import com.consol.citrus.dsl.builder.HttpServerRequestActionBuilder;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

/**
 *
 * @author hduarte
 * @version ($Revision$ $Date$)
 */
public class BssGpSUBOXHttpSteps extends AbstractSpiritHttpSteps
{
  /** BSSGP base path. */
  private static final String BASE_PATH = "BSSGPSUBBOX"; //$NON-NLS-1$

  /** Url for OrderManagementDiagService */
  private static final String URL_FIND_EQUIPMENT = "/findEquipment/"; //$NON-NLS-1$

  /** Constant for method findEquipment */
  private static final String METHOD_FIND_EQUIPMENT = "findEquipment"; //$NON-NLS-1$

  /** Transient expected AIR server request. */
  private HttpServerRequestActionBuilder _serverRequest;

  /** Transient service. */
  private String _service;

  /**
   * Constructor
   */
  public BssGpSUBOXHttpSteps()
  {
    super(BASE_PATH);
  }

  /**
   * Expect request has given query param
   *
   * @param name_p
   *          query param name
   * @param value_p
   *          query param value
   */
  @And("BSSGPSUBBOX query param ([^\"]*)=([^\"]*)$")
  public void expectQueryParam(String name_p, String value_p)
  {
    _serverRequest.queryParam(name_p, value_p);
  }

  /**
   * BSSGPSUBBOX receives findEquipment request.
   */
  @When("^BSSGPSUBBOX receives a findEquipment request with ([^\"]*)$")
  public void findEquipment(final String imei_p)
  {
    receiveRequest(METHOD_FIND_EQUIPMENT, imei_p, false);
  }

  /**
   * BSSGPSUBBOX responds
   *
   * @param template_p
   *          relative template path
   */
  @Then("^BSSGPSUBBOX responds with ([^\"]*)$")
  public void sendAction(final String template_p)
  {
    serverResponseActionOK(BouchonHttpConfig.BSS_GP_SUBOX_SERVER, templateResource(_service, RESPONSE_DIR, template_p));
  }

  /**
   * Generic method to receive the request
   *
   * @param method_p
   *          method name to call
   * @param imei_p
   *          the imei for the url
   */
  private void receiveRequest(String method_p, String imei_p, boolean isControlHeaders_p)
  {
    _service = method_p;

    switch (_service)
    {
      // URL_ORDER_MANAGEMENT_DIAG
      case METHOD_FIND_EQUIPMENT:
        _serverRequest = this.getDesigner()//
            .http() //
            .server(BouchonHttpConfig.BSS_GP_SUBOX_SERVER) //
            .receive() //
            .post(URL_FIND_EQUIPMENT + imei_p);
        break;
      default:
        break;
    }

    if (isControlHeaders_p)
    {
      controlReceivedHeaders(_serverRequest, false);
    }
  }

}
