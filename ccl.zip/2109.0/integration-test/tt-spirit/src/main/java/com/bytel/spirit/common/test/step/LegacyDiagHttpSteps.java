/*******************************************************************************
* $Id: LegacyDiagHttpSteps.java 23500 2019-07-03 08:51:31Z jjoly $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.test.step;

import static com.bytel.spirit.common.test.config.BouchonHttpConfig.LEGACY_DIAG_ORDER_MANAGEMENT_SERVER;

import com.consol.citrus.dsl.builder.HttpServerRequestActionBuilder;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

/**
 *
 * @author jjoly
 * @version ($Revision: 23500 $ $Date: 2019-07-03 10:51:31 +0200 (mer. 03 juil. 2019) $)
 */
public final class LegacyDiagHttpSteps extends AbstractSpiritHttpSteps
{
  /** Diag base path. */
  private static final String BASE_PATH = "LEGACY_DIAG"; //$NON-NLS-1$

  /** Url for OrderManagementDiagService */
  private static final String URL_ORDER_MANAGEMENT_DIAG = "/diag_odad/OrderManagementDiagService"; //$NON-NLS-1$

  /** Constant for method getOrdersInfoByPortfolio */
  private static final String METHOD_GET_ORDERS_INFO_BY_PORTFOLIO = "getOrdersInfoByPortfolio"; //$NON-NLS-1$

  /** Transient expected OssServices server request. */
  private HttpServerRequestActionBuilder _serverRequest;

  /** Transient service. */
  private String _service;

  /**
   * Constructor
   */
  public LegacyDiagHttpSteps()
  {
    super(BASE_PATH);
  }

  /**
   * Diag receives getOrdersInfoByPortfolio request.
   *
   * @param template_p
   *          the template to control from
   */
  @When("^DiagOrderManagement receives a getOrdersInfoByPortfolio request with ([^\"]*)$")
  public void getOrdersInfoByPortfolioRequest(final String template_p)
  {
    receiveRequest(METHOD_GET_ORDERS_INFO_BY_PORTFOLIO, template_p, false);
  }

  /**
   * Diag send getOrdersInfoByPortfolio response
   *
   * @param template_p
   *          template file name
   */
  @Then("^DiagOrderManagement responds with ([^\"]*)$")
  public void getOrdersInfoByPortfolioResponse(final String template_p)
  {
    sendResponse(_service, template_p);
  }

  /**
   * Generic method to receive the request
   *
   * @param method_p
   *          method name to call
   * @param template_p
   *          template file name
   * @param isControlHeaders_p
   *          true if force header control, false elsewhere
   */
  private void receiveRequest(final String method_p, final String template_p, final boolean isControlHeaders_p)
  {
    _service = method_p;
    switch (_service)
    {
      // URL_ORDER_MANAGEMENT_DIAG
      case METHOD_GET_ORDERS_INFO_BY_PORTFOLIO:
        _serverRequest = getDesigner()//
            .http() //
            .server(LEGACY_DIAG_ORDER_MANAGEMENT_SERVER) //
            .receive() //
            .post(URL_ORDER_MANAGEMENT_DIAG) //
            .payload(templateResource(_service, REQUEST_DIR, template_p));
        break;

      default:
        break;
    }

    if (isControlHeaders_p)
    {
      controlReceivedHeaders(_serverRequest, false);
    }
  }

  /**
   * Generic method to respond
   *
   * @param method_p
   *          method name to call
   * @param template_p
   *          template file name
   */
  private void sendResponse(final String method_p, final String template_p)
  {
    switch (method_p)
    {
      case METHOD_GET_ORDERS_INFO_BY_PORTFOLIO:
        serverResponseActionOK(LEGACY_DIAG_ORDER_MANAGEMENT_SERVER, templateResource(method_p, RESPONSE_DIR, template_p));
        break;

      default:
        break;
    }
  }
}
