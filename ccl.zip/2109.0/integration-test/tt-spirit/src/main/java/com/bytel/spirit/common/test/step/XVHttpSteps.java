/*******************************************************************************
 * $Id: XVHttpSteps.java 25669 2019-08-21 14:57:15Z rrosa $
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.test.step;

import com.bytel.spirit.common.test.config.BouchonHttpConfig;

import com.consol.citrus.dsl.builder.HttpServerRequestActionBuilder;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

/**
 *
 * @author rrosa
 * @version ($Revision: 25669 $ $Date: 2019-08-21 16:57:15 +0200 (mer. 21 août 2019) $)
 */
public class XVHttpSteps extends AbstractSpiritHttpSteps
{
  /** XV base path. */
  private static final String XV_BASE_PATH = "XV"; //$NON-NLS-1$

  /** Constant for method notifierModificationProfilEsim */
  private static final String METHOD_NOTIFIER_MODIFICATION_PROFIL_ESIM = "notifierModificationProfilEsim"; //$NON-NLS-1$

  /** Transient service. */
  private String _service;

  /** XV Custom timeout. */
  private Long _xvTimeout = 0L;

  /** Transient expected xv server request. */
  private HttpServerRequestActionBuilder _serverRequest;

  /**
   * Constructor
   */
  public XVHttpSteps()
  {
    super(XV_BASE_PATH);
  }

  /**
   * Expect that XV receives an notifierModificationProfilEsim request.
   *
   * @param template_p
   *          relative template path
   */
  @When("XV receives a POST request on ([^\"]*) with ([^\"]*)$")
  public void receiveNotifierModificationProfilEsim(String uri_p, String template_p)
  {
    receiveRequest(METHOD_NOTIFIER_MODIFICATION_PROFIL_ESIM, uri_p, template_p);
  }

  /**
   * xv receives header headerName=headerValue.
   *
   * @param headerName_p
   *          the name of the expected header.
   * @param headerValue_p
   *          the value of the expected header.
   */
  @And("^XV receives header ([^=]+)=\"([^\"]+)\"$")
  public void expectHeader(String headerName_p, String headerValue_p)
  {
    _serverRequest.header(headerName_p, headerValue_p);
  }

  /**
   * XV responds with a code and template
   *
   * @param codeHttp_p
   *          codeHttp
   * @param template_p
   *          relative template path
   */
  @Then("XV responds status (\\d+) with ([^\"]*)$")
  public void responseAction(Integer codeHttp_p, String template_p)
  {
    serverResponseAction(BouchonHttpConfig.XV_SERVER, codeHttp_p, templateResource(_service, RESPONSE_DIR, template_p));
  }

  /**
   * Generic method to receive the request
   *
   * @param method_p
   *          method name to call
   * @param template_p
   *          template file name
   */
  private void receiveRequest(String method_p, String uri_p, String template_p)
  {
    _service = method_p;
    switch (_service)
    {
      case METHOD_NOTIFIER_MODIFICATION_PROFIL_ESIM:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.XV_SERVER)//
            .receive()//
            .post(uri_p)//
            .timeout(_xvTimeout)//
            .payload(templateResource(_service, REQUEST_DIR, template_p));
        break;
      default:
        break;
    }
    // Reset timeout
    _xvTimeout = 0L;
  }
}
