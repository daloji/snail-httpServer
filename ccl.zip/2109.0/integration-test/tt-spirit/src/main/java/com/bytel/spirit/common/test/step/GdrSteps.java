package com.bytel.spirit.common.test.step;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Lazy;

import com.bytel.ravel.config.RavelOracleConfig;
import com.bytel.ravel.step.helper.AbstractSteps;

import cucumber.api.java.en.Then;

/**
 * GDR database steps.
 *
 * @author jstrub
 */
public class GdrSteps extends AbstractSteps
{

  /** Search MSISDN's ETAMSI & IDTDERMOD where DATETAT modified less than 2 minutes ago. */
  private static final String CHECK_LIBERATED_MSISDN_ENTRY = "select ETAMSI, IDTDERMOD from PROGDR.MSISDN where NUMTEL = '%s' and DATETA > (sysdate - interval '2' minute)"; //$NON-NLS-1$
  /** List MSISDN's history, sort ascending according to DAT. */
  private static final String CHECK_LIBERATED_MSISDN_HIST = "select ETAMSI, IDTIST from PROGDR.HISETAMSI where NUMTEL = '%s' order by DAT asc"; //$NON-NLS-1$
  /** Search SIM by SIM. */
  private static final String CHECK_SIM_BY_SIM = "select ETASMDP,ETANOTIF, IDTDERMOD from PROGDR.SIM where SIM = '%s'"; //$NON-NLS-1$
  /** Search HISETASIM by IDTSIM. */
  private static final String CHECK_HISETASIM_BY_IDTSIM = "select ETASMDP,ETANOTIF from PROGDR.HISETASIM where IDTSIM = '%s'"; //$NON-NLS-1$
  /** Search MSISDN's ETAMSI & IDTDERMOD where DATETAT modified less than 2 minutes ago. */
  private static final String CHECK_MSISDN_EXISTENCE_ENTRY = "select ETAMSI, IDTACNMSI, IDTDERMOD from PROGDR.MSISDN where NUMTEL = '%s' and DATETA > (sysdate - interval '2' minute)"; //$NON-NLS-1$
  /** List MSISDN's history, sort ascending according to DAT. */
  private static final String CHECK_HISETAMSI_EXISTENCE_ENTRY = "select IDTACNMSI, ETAMSI, IDTIST from PROGDR.HISETAMSI where NUMTEL = '%s' and ETAMSI = '%s' order by DAT asc"; //$NON-NLS-1$
  /** Search HISETASIM's , sort ascending according to DAT. */
  private static final String CHECK_HISETASIM_EXISTENCE_ENTRY = "select IDTSIM, ETASIM, ETASMDP from PROGDR.HISETASIM where IDTSIM = '%s' and ETASIM = '%s' order by DAT asc"; //$NON-NLS-1$
  /** Search SIM's , sort ascending according to DAT. */
  private static final String CHECK_SIM_EXISTENCE_UPDATE = "select IDTSIM, ETASMDP from PROGDR.SIM where IDTSIM = '%s'"; //$NON-NLS-1$
  /** Search SIM's. */
  private static final String CHECK_DISTRIBUTABLE_SIM = "select ETASIM, NOTIF_APPRO, TYPSIM, IDTACNSIM from PROGDR.SIM where ETASIM = '%s' and NOTIF_APPRO = '%s' and TYPSIM = '%s' and IDTACNSIM = '%s' "; //$NON-NLS-1$
  /** Search SIM's with updated NOTIF_APPRO. */
  private static final String CHECK_NOTIF_APPRO_SIM = "select SIM, NOTIF_APPRO from PROGDR.SIM where SIM = '%s' and NOTIF_APPRO = '%s' "; //$NON-NLS-1$


  /** Oracle datasource : lazily loaded. */
  @Lazy
  @Autowired
  @Qualifier(RavelOracleConfig.RAVEL_ORACLE_DB)
  private DataSource _oracleDatasource;

  /** */
  public GdrSteps()
  {
    super("GDR"); //$NON-NLS-1$
  }

  /**
   * Check a MSISDN liberation by BL400_LibererMsisdn
   *
   * @param msisdn_p
   *          the msisdn
   * @param etat_p
   *          the expected etat
   * @param instance_p
   *          the expected instance
   */
  @SuppressWarnings("nls")
  @Then("GDR check MSISDN {string} after liberation with state {string} for instance {string}")
  public void checkLiberatedMsisdn(String msisdn_p, String etat_p, String instance_p)
  {
    getDesigner().query(_oracleDatasource).statement(String.format(CHECK_LIBERATED_MSISDN_ENTRY, msisdn_p))
        // Check state from step
        .validate("ETAMSI", etat_p)
        // Check modification by BL400
        .validate("IDTDERMOD", "BL400_LibererMsisdn");

    getDesigner().query(_oracleDatasource).statement(String.format(CHECK_LIBERATED_MSISDN_HIST, msisdn_p))
        // Check state from step
        .validateScript("assert rows.size == 2;"
            // First row etat
            + "assert rows[0].ETAMSI == 'r';"
            // Second row etat (from step)
            + "assert rows[1].ETAMSI == '" + etat_p + "';"
            // First row IDTIST (from step)
            + "assert rows[1].IDTIST == '" + instance_p + "';",
            // Script with groovy
            "groovy");
  }

  /**
   * Check an updated SIM.
   *
   * @param etatSmdp_p
   *          the etatSmdp
   * @param statutTelechargement_p
   *          the statutTelechargement_p
   * @param objetModification_p
   *          the objetModification
   * @param iccid_p
   *          the iccid
   * @param idtSim_p
   *          the idtSim
   */
  @SuppressWarnings("nls")
  @Then("GDR check SIM with values etaSmdp {string}, statutTelechargement {string}, objetModification {string}, iccid {string}, idtSim {string}")
  public void checkUpdatedSIM(String etatSmdp_p, String statutTelechargement_p, String objetModification_p, String iccid_p, String idtSim_p)
  {
    getDesigner().query(_oracleDatasource).statement(String.format(CHECK_SIM_BY_SIM, iccid_p)).validate("ETASMDP", etatSmdp_p).validate("ETANOTIF", statutTelechargement_p).validate("IDTDERMOD", objetModification_p);

    getDesigner().query(_oracleDatasource).statement(String.format(CHECK_HISETASIM_BY_IDTSIM, idtSim_p)).validate("ETASMDP", etatSmdp_p).validate("ETANOTIF", statutTelechargement_p);
  }

  /**
   * Check an updated SIM.
   *
   * @param numtel_p
   *          the numtel
   * @param etatFinal_p
   *          the etatFinal
   * @param idtacnmsi_p
   *          the idtacnmsi
   * @param idtdermod_p
   *          the idtdermod
   */
  @SuppressWarnings("nls")
  @Then("GDR check MSISDN with values numtel {string}, etatFinal {string}, IDTACNMSI {string}, IDTDERMOD_DEFAULT {string}")
  public void checkUpdateEtatMsisdn(String numtel_p, String etatFinal_p, String idtacnmsi_p, String idtdermod_p)
  {
    getDesigner().query(_oracleDatasource).statement(String.format(CHECK_MSISDN_EXISTENCE_ENTRY, numtel_p)).validate("ETAMSI", etatFinal_p).validate("IDTACNMSI", idtacnmsi_p).validate("IDTDERMOD", idtdermod_p);

    getDesigner().query(_oracleDatasource).statement(String.format(CHECK_HISETAMSI_EXISTENCE_ENTRY, numtel_p, etatFinal_p)).validate("ETAMSI", etatFinal_p);

  }

  /**
   * Check an updated SIM.
   *
   * @param idtsim_p
   *          the idtsim
   * @param etatFinal_p
   *          the etatFinal
   * @param etaSmdp_p
   *          the etaSmdp
   */
  @SuppressWarnings("nls")
  @Then("GDR check SIM with values idtsim {string}, etatFinal {string}, ETASMDP {string}")
  public void checkUpdateEtatSIM(String idtsim_p, String etatFinal_p, String etaSmdp_p)
  {

    getDesigner().query(_oracleDatasource).statement(String.format(CHECK_SIM_EXISTENCE_UPDATE, idtsim_p, etatFinal_p, etaSmdp_p)).validate("ETASMDP", etaSmdp_p);

    getDesigner().query(_oracleDatasource).statement(String.format(CHECK_HISETASIM_EXISTENCE_ENTRY, idtsim_p, etatFinal_p, etaSmdp_p)).validate("ETASIM", etatFinal_p).validate("ETASMDP", etaSmdp_p);

  }

  /**
   * Check the distributable SIM.
   *
   * @param etasim_p
   *          the etasim
   * @param notifAppro_p
   *          the notifAppro
   * @param typsim_p
   *          the typsim
   * @param idtacnsim_p
   *          the idtacnsim
   */
  @SuppressWarnings("nls")
  @Then("GDR check SIM with values etasim {string}, notifAppro {string}, typsim {string}, idtacnsim {string}")
  public void checkDistributableSIM(String etasim_p, String notifAppro_p, String typsim_p, String idtacnsim_p)
  {

    getDesigner().query(_oracleDatasource).statement(String.format(CHECK_DISTRIBUTABLE_SIM, etasim_p, notifAppro_p, typsim_p, idtacnsim_p)).validate("ETASIM", etasim_p).validate("NOTIF_APPRO", notifAppro_p).validate("TYPSIM", typsim_p).validate("IDTACNSIM", idtacnsim_p);

  }

  /**
   * Check an updated notif appro in mentioned SIM.
   *
   * @param sim_p
   *          the sim(iccid)
   * @param notifAppro_p
   *          the notifAppro
   */
  @SuppressWarnings("nls")
  @Then("GDR check SIM with values sim {string}, notifAppro {string}")
  public void checkUpdatedNotiApproSIM(String sim_p, String notifAppro_p)
  {

    getDesigner().query(_oracleDatasource).statement(String.format(CHECK_NOTIF_APPRO_SIM, sim_p, notifAppro_p)).validate("SIM", sim_p).validate("NOTIF_APPRO", notifAppro_p);

  }

}
