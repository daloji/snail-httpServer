/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.test.step;

import com.bytel.spirit.common.test.config.BouchonHttpConfig;
import com.consol.citrus.dsl.builder.HttpServerRequestActionBuilder;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

/**
 *
 * @author bferreir
 * @version ($Revision$ $Date$)
 */
public class OiHttpSteps extends AbstractSpiritHttpSteps
{
  /** OI base path. */
  private static final String OI_BASE_PATH = "OI"; //$NON-NLS-1$

  /** Url for OI */
  private static final String URL_OBTENIR_STRUCTURE_VERTICALE = "/aide-commande"; //$NON-NLS-1$

  /** Constant for method obtenirStructureVerticale */
  private static final String METHOD_OBTENIR_STRUCTURE_VERTICALE = "obtenirStructureVerticale"; //$NON-NLS-1$

  /** Url for RecherchePBO. */
  private static final String URL_RECHERCHER_PBO = "/"; //$NON-NLS-1$

  /** Url for listageFibres. */
  private static final String URL_LISTAGE_FIBRES = "/"; //$NON-NLS-1$

  /** Constant for method rechercherPBO */
  private static final String METHOD_RECHERCHER_PBO = "pbo"; //$NON-NLS-1$

  /** Constant for method listageFibres */
  private static final String METHOD_LISTAGE_FIBRES = "fibres"; //$NON-NLS-1$

  /** Transient expected OI server request. */
  private HttpServerRequestActionBuilder _serverRequest;

  /** Transient service. */
  private String _service;

  /** Constructor */
  public OiHttpSteps()
  {
    super(OI_BASE_PATH);
  }

  /**
   * Comment.
   *
   * @param comment
   *          Comment to log.
   */
  @Then("OI comment \"([^\"]*)\"")
  public void comment(String comment)
  {
    this.getDesigner().echo("OI : " + comment); //$NON-NLS-1$
  }

  /**
   * Expect request has given query param
   *
   * @param name_p
   *          query param name
   * @param value_p
   *          query param value
   */
  @And("OI query param ([^\"]*)=([^\"]*)$")
  public void expectQueryParam(String name_p, String value_p)
  {
    _serverRequest.queryParam(name_p, value_p);
  }

  /**
   * Expect that OI receives an ListageFibres request.
   */
  @When("^OI receives an ListageFibres request$")
  public void receiveListageFibresRequest()
  {
    receiveRequest(METHOD_LISTAGE_FIBRES, false);
  }

  /**
   * Expect that OI receives an obtenirStructureVerticale request.
   */
  @When("^OI receives an obtenirStructureVerticale request$")
  public void receiveObtenirStructureVerticaleRequest()
  {
    receiveRequest(METHOD_OBTENIR_STRUCTURE_VERTICALE, false);
  }

  /**
   * Expect that OI receives an rechercherPBO request.
   */
  @When("^OI receives an RecherchePBO request$")
  public void receiveRechercherPBORequest()
  {
    receiveRequest(METHOD_RECHERCHER_PBO, false);
  }

  /**
   * OI responds an error
   *
   * @param codeHttp_p
   *          Http Code
   * @param template_p
   *          relative template path
   */
  @Then("OI responds status (\\d+) with ([^\"]*)$")
  public void responseAction(Integer codeHttp_p, String template_p)
  {
    serverResponseAction(BouchonHttpConfig.OI_SERVER, codeHttp_p, templateResource(_service, RESPONSE_DIR, template_p));
  }

  /**
   * Generic method to receive the request
   *
   * @param method_p
   *          method name to call
   * @param isControlHeaders_p
   *          isControlHeaders
   */
  private void receiveRequest(String method_p, boolean isControlHeaders_p)
  {
    _service = method_p;

    switch (_service)
    {
      case METHOD_OBTENIR_STRUCTURE_VERTICALE:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.OI_SERVER)//
            .receive()//
            .post(URL_OBTENIR_STRUCTURE_VERTICALE);

        break;

      case METHOD_RECHERCHER_PBO:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.OI_SERVER)//
            .receive()//
            .post(URL_RECHERCHER_PBO);
        break;

      case METHOD_LISTAGE_FIBRES:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.OI_SERVER)//
            .receive()//
            .post(URL_LISTAGE_FIBRES);
        break;

      default:
        break;
    }

    if (isControlHeaders_p)
    {
      controlReceivedHeaders(_serverRequest, false);
    }
  }
}
