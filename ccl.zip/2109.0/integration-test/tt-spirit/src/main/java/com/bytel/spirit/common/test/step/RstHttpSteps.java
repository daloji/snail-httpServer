/*******************************************************************************
 * $Id: RstHttpSteps.java 18580 2019-03-14 10:51:07Z jpais $
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.test.step;

import com.bytel.spirit.common.test.config.BouchonHttpConfig;
import com.consol.citrus.dsl.builder.HttpServerRequestActionBuilder;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

/**
 *
 * @author pescudei
 * @version ($Revision: 18580 $ $Date: 2019-03-14 11:51:07 +0100 (jeu. 14 mars 2019) $)
 */
public class RstHttpSteps extends AbstractSpiritHttpSteps
{
  /** RST base path. */
  private static final String RST_BASE_PATH = "RST"; //$NON-NLS-1$

  /** Url for PAD4000 */
  private static final String URL_SERVICE_TECHNIQUE = "/ExecuteGenericRequestV2/serviceTechnique"; //$NON-NLS-1$

  /** Url for PAD4200 */
  private static final String URL_ST_LIEN_ALLOCATION_COMMERCIAL = "/ExecuteGenericRequestV2/stLienAllocationCommercial"; //$NON-NLS-1$

  /** Url for PAD4300 */
  private static final String URL_ST_PFS = "/ExecuteGenericRequestV2/stPfs"; //$NON-NLS-1$

  /** Constant for method serviceTechniqueLireTousParPfi */
  private static final String METHOD_SERVICE_TECHNIQUE_LIRE_TOUS_PAR_PFI = "serviceTechniqueLireTousParPfi"; //$NON-NLS-1$

  /** Constant for method serviceTechniqueLireUn */
  private static final String METHOD_SERVICE_TECHNIQUE_LIRE_UN = "serviceTechniqueLireUn"; //$NON-NLS-1$

  /** Constant for method stLienAllocationCommercialGererModifPfiAssocie */
  private static final String METHOD_ST_LIEN_ALLOCATION_COMMERCIAL_GERER_MODIF_PFI_ASSOCIE = "stLienAllocationCommercialGererModifPfiAssocie"; //$NON-NLS-1$

  /** Constant for method stPfsModifierStatutActif */
  private static final String METHOD_ST_PFS_MODIFIER_STATUT_ACTIF = "stPfsModifierStatutActif"; //$NON-NLS-1$

  /** Constant for method stPfsModifierStatutActif */
  private static final String METHOD_SERVICE_TECHNIQUE_MODIFIER_STATUT = "serviceTechniqueModifierStatut"; //$NON-NLS-1$

  /** Constant for method stPfsGererModifPfiAssocie */
  private static final String METHOD_ST_PFS_GERER_MODIF_PFI_ASSOCIE = "stPfsGererModifPfiAssocie"; //$NON-NLS-1$

  /** Constant for method stPfsCreer */
  private static final String METHOD_ST_PFS_CREER = "stPfsCreer"; //$NON-NLS-1$

  /** Transient expected RST server request. */
  private HttpServerRequestActionBuilder _serverRequest;

  /** Transient service. */
  private String _service;

  /**
   * Constructor
   */
  public RstHttpSteps()
  {
    super(RST_BASE_PATH);
  }

  /**
   * Expect request has given query param
   *
   * @param name_p
   *          query param name
   * @param value_p
   *          query param value
   */
  @And("RST query param ([^\"]*)=([^\"]*)$")
  public void expectQueryParam(String name_p, String value_p)
  {
    _serverRequest.queryParam(name_p, value_p);
  }

  /**
   * RST responds an error
   *
   * @param template_p
   *          relative template path
   */
  @Then("RST responds with ([^\"]*)$")
  public void okResponseAction(String template_p)
  {
    serverResponseActionOK(BouchonHttpConfig.RST_SERVER, templateResource(_service, RESPONSE_DIR, template_p));
  }

  /**
   * Expect that RST receives an serviceTechniqueLireTousParPfi request.
   */
  @When("RST receives a serviceTechniqueLireTousParPfi request")
  public void receiveRequest()
  {
    receiveRequest(METHOD_SERVICE_TECHNIQUE_LIRE_TOUS_PAR_PFI, null, false);
  }

  /**
   * Expect that RST receives an serviceTechniqueLireUn request.
   */
  @When("RST receives a serviceTechniqueLireUn request")
  public void receiveServiceTechniqueLireUnRequest()
  {
    receiveRequest(METHOD_SERVICE_TECHNIQUE_LIRE_UN, null, false);
  }

  /**
   * Expect RST receives a commandeModifierStatut request.
   */
  @When("RST receives a serviceTechniqueModifierStatut request with ([^\"]*)$")
  public void receiveServiceTechniqueModifierStatutRequest(String template_p)
  {
    receiveRequest(METHOD_SERVICE_TECHNIQUE_MODIFIER_STATUT, template_p, false);
  }

  /**
   * Expect RST receives a stLienAllocationCommercialGererModifPfiAssocie request.
   */
  @When("RST receives a stLienAllocationCommercialGererModifPfiAssocie request with ([^\"]*)$")
  public void receiveStLienAllocationCommercialGererModifPfiAssocieRequest(String template_p)
  {
    receiveRequest(METHOD_ST_LIEN_ALLOCATION_COMMERCIAL_GERER_MODIF_PFI_ASSOCIE, template_p, false);
  }

  /**
   * Expect that RST receives an stPfsGererModifPfiAssocie request.
   */
  @When("RST receives a stPfsGererModifPfiAssocie request with ([^\"]*)")
  public void receiveStPfsGererModifPfiAssocieRequest(String template_p)
  {
    receiveRequest(METHOD_ST_PFS_GERER_MODIF_PFI_ASSOCIE, template_p, false);
  }

  /**
   * Expect RST receives a commandeModifierStatut request.
   */
  @When("RST receives a stPfsModifierStatutActif request with ([^\"]*)$")
  public void receiveStPfsModifierStatutActifRequest(String template_p)
  {
    receiveRequest(METHOD_ST_PFS_MODIFIER_STATUT_ACTIF, template_p, false);
  }

  /**
   * Expect RST receives a commandeModifierStatut request.
   */
  @When("RST receives a stPfsCreer request with ([^\"]*)$")
  public void receiveStPfsCreerRequest(String template_p)
  {
    receiveRequest(METHOD_ST_PFS_CREER, template_p, false);
  }

  /**
   * RST responds a status
   *
   * @param statusCode_p
   *          http status code
   * @param template_p
   *          relative template path
   */
  @Then("RST responds status (\\d+) with ([^\"]*)$")
  public void responseAction(Integer statusCode_p, String template_p)
  {
    serverResponseAction(BouchonHttpConfig.RST_SERVER, statusCode_p, templateResource(_service, RESPONSE_DIR, template_p));
  }

  /**
   * Generic method to receive the request
   *
   * @param method_p
   *          method name to call
   * @param template_p
   *          template file name
   */
  private void receiveRequest(String method_p, String template_p, boolean isControlHeaders_p)
  {
    _service = method_p;

    switch (_service)
    {
      case METHOD_SERVICE_TECHNIQUE_LIRE_TOUS_PAR_PFI:
      case METHOD_SERVICE_TECHNIQUE_LIRE_UN:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.RST_SERVER)//
            .receive()//
            .get(URL_SERVICE_TECHNIQUE);
        break;
      case METHOD_ST_PFS_MODIFIER_STATUT_ACTIF:
      case METHOD_ST_PFS_GERER_MODIF_PFI_ASSOCIE:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.RST_SERVER)//
            .receive()//
            .put(URL_ST_PFS)//
            .payload(templateResource(_service, REQUEST_DIR, template_p));
        break;
      case METHOD_SERVICE_TECHNIQUE_MODIFIER_STATUT:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.RST_SERVER)//
            .receive()//
            .put(URL_SERVICE_TECHNIQUE)//
            .payload(templateResource(_service, REQUEST_DIR, template_p));
        break;
      case METHOD_ST_LIEN_ALLOCATION_COMMERCIAL_GERER_MODIF_PFI_ASSOCIE:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.RST_SERVER)//
            .receive()//
            .put(URL_ST_LIEN_ALLOCATION_COMMERCIAL)//
            .payload(templateResource(_service, REQUEST_DIR, template_p));
        break;
      case METHOD_ST_PFS_CREER:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.RST_SERVER)//
            .receive()//
            .post(URL_ST_PFS)//
            .payload(templateResource(_service, REQUEST_DIR, template_p));
        break;
      default:
        break;
    }

    if (isControlHeaders_p)
    {
      controlReceivedHeaders(_serverRequest, false);
    }
  }

}
