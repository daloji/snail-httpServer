/*******************************************************************************
 * $Id: CmdHttpSteps.java 25669 2019-08-21 14:57:15Z pramos $
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.test.step;

import com.bytel.spirit.common.test.config.BouchonHttpConfig;
import com.consol.citrus.dsl.builder.HttpServerRequestActionBuilder;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

/**
 *
 * @author JSTRUB
 * @version ($Revision: 25669 $ $Date: 2019-08-21 16:57:15 +0200 (mer. 21 août 2019) $)
 */
public class CmdHttpSteps extends AbstractSpiritHttpSteps
{
  /** CMD base path. */
  private static final String CMD_BASE_PATH = "CMD"; //$NON-NLS-1$

  /** Url for PAD2001 */
  private static final String URL_COMMANDE = "/ExecuteGenericRequestV2/commande"; //$NON-NLS-1$
  /** Url for PAD2002 */
  private static final String URL_MODIFICATION_COMMERCIALE = "/ExecuteGenericRequestV2/modificationCommerciale"; //$NON-NLS-1$
  /** Url for PAD2003 */
  private static final String URL_COMMANDE_COMPOSITE = "/ExecuteGenericRequestV2/commandeComposite"; //$NON-NLS-1$
  /** Url for PAD2004 */
  private static final String URL_MODIFICATION_TECHNIQUE = "/ExecuteGenericRequestV2/modificationTechnique"; //$NON-NLS-1$

  /** Constant for method commandeCompositeGererLireTousModCommModTechParPfiFiltrerTraite */
  private static final String METHOD_COMMANDE_COMPOSITE_GERER_LIRE_TOUS = "commandeCompositeGererLireTousModCommModTechParPfiFiltrerTraite"; //$NON-NLS-1$
  /** Constant for method commandeCompositeLireTousParPFI */
  private static final String METHOD_COMMANDE_COMPOSITE_LIRE_TOUS_PAR_PFI = "commandeCompositeLireTousParPFI"; //$NON-NLS-1$
  /** Constant for method commandeCreer */
  private static final String METHOD_COMMANDE_CREER = "commandeCreer"; //$NON-NLS-1$
  /** Constant for method commandeGererFinaliserCommandesParPFI */
  private static final String METHOD_COMMANDE_GERER_FINALISER_COMMANDES_PAR_PFI = "commandeGererFinaliserCommandesParPFI"; //$NON-NLS-1$
  /** Constant for method commandeLireTousParStatutEtPFI */
  private static final String METHOD_COMMANDE_LIRE_TOUS_PAR_STATUT_ET_PFI = "commandeLireTousParStatutEtPFI"; //$NON-NLS-1$
  /** Constant for method commandeLireUn */
  private static final String METHOD_COMMANDE_LIRE_UN = "commandeLireUn"; //$NON-NLS-1$
  /** Constant for method commandeLirePlusVieuxParCleSequencement */
  private static final String METHOD_COMMANDE_PLUS_VIEUX_PAR_CLE_SEQUENCEMENT = "commandeLirePlusVieuxParCleSequencement"; //$NON-NLS-1$
  /** Constant for method commandelireUnParIdExterneEtNatureCommandeEtPFI */
  private static final String METHOD_COMMANDE_LIRE_UN_PAR_ID_EXTERNE_ET_NATURE_COMMANDE_ET_PFI = "commandelireUnParIdExterneEtNatureCommandeEtPFI"; //$NON-NLS-1$
  /** Constant for method commandeModifierStatut */
  private static final String METHOD_COMMANDE_MODIFIER_STATUT = "commandeModifierStatut"; //$NON-NLS-1$
  /** Constant for method modificationCommercialeCreerListe */
  private static final String METHOD_MODIFICATION_COMMERCIALE_CREER_LISTE = "modificationCommercialeCreerListe"; //$NON-NLS-1$
  /** Constant for method modificationCommercialeModifierListeStatut */
  private static final String METHOD_MODIFICATION_COMMERCIALE_MODIFIER_LISTE_STATUT = "modificationCommercialeModifierListeStatut"; //$NON-NLS-1$
  /** Constant for method modificationTechniqueCreerListe */
  private static final String METHOD_MODIFICATION_TECHNIQUE_CREER_LISTE = "modificationTechniqueCreerListe"; //$NON-NLS-1$
  /** Constant for method modificationTechniqueModifierListeStatut */
  private static final String METHOD_MODIFICATION_TECHNIQUE_MODIFIER_LISTE_STATUT = "modificationTechniqueModifierListeStatut"; //$NON-NLS-1$

  /** Transient expected AIR server request. */
  private HttpServerRequestActionBuilder _serverRequest;

  /** Transient service. */
  private String _service;

  /** Constructor */
  public CmdHttpSteps()
  {
    super(CMD_BASE_PATH);
  }

  /**
   * Expect request has given query param
   *
   * @param name_p
   *          query param name
   * @param value_p
   *          query param value
   */
  @And("^CMD query param ([^\"]*)=([^\"]*)$")
  public void expectQueryParam(String name_p, String value_p)
  {
    _serverRequest.queryParam(name_p, value_p);
  }

  /**
   * Expect CMD receives a commandeCompositeGererLireTousModCommModTechParPfiFiltrerTraite request.
   */
  @When("^CMD receives a commandeCompositeGererLireTousModCommModTechParPfiFiltrerTraite request$")
  public void receiveCommandeCompositeGererLireTousModCommModTechParPfiFiltrerTraiteRequest()
  {
    receiveRequest(METHOD_COMMANDE_COMPOSITE_GERER_LIRE_TOUS, null, false);
  }

  /**
   * Expect CMD receives a commandeCompositeLireTousParPFI request.
   */
  @When("^CMD receives a commandeCompositeLireTousParPFI request$")
  public void receivecommandeCompositeLireTousParPFIRequest()
  {
    receiveRequest(METHOD_COMMANDE_COMPOSITE_LIRE_TOUS_PAR_PFI, null, false);
  }

  /**
   * Expect CMD receives a commandeCreer request.
   *
   * @param template_p
   *          template
   */
  @When("^CMD receives a commandeCreer request with ([^\"]*)$")
  public void receiveCommandeCreerRequest(String template_p)
  {
    receiveRequest(METHOD_COMMANDE_CREER, template_p, false);
  }

  /**
   * Expect CMD receives a commandeLireTousParStatutEtPFI request.
   */
  @When("^CMD receives a commandeLireTousParStatutEtPFI request$")
  public void receiveCommandeGererFinaliserCommandesParPFIRequest()
  {
    receiveRequest(METHOD_COMMANDE_LIRE_TOUS_PAR_STATUT_ET_PFI, null, false);
  }

  /**
   * Expect CMD receives a commandeGererFinaliserCommandesParPFI request.
   */
  @When("CMD receives a commandeGererFinaliserCommandesParPFI request with ([^\"]*)$")
  public void receiveCommandeGererFinaliserCommandesParPFIRequest(String template_p)
  {
    receiveRequest(METHOD_COMMANDE_GERER_FINALISER_COMMANDES_PAR_PFI, template_p, false);
  }

  /**
   * Expect CMD receives a commandeLirePlusVieuxParCleSequencement request.
   */
  @When("^CMD receives a commandeLirePlusVieuxParCleSequencement request$")
  public void receiveCommandeLirePlusVieuxParCleSequencement()
  {
    receiveRequest(METHOD_COMMANDE_PLUS_VIEUX_PAR_CLE_SEQUENCEMENT, null, false);
  }

  /**
   * Expect CMD receives a commandelireUnParIdExterneEtNatureCommandeEtPFI request.
   */
  @When("^CMD receives a commandelireUnParIdExterneEtNatureCommandeEtPFI request$")
  public void receiveCommandelireUnParIdExterneEtNatureCommandeEtPFIRequest()
  {
    receiveRequest(METHOD_COMMANDE_LIRE_UN_PAR_ID_EXTERNE_ET_NATURE_COMMANDE_ET_PFI, null, false);
  }

  /**
   * Expect CMD receives a commandeLireUn request.
   */
  @When("^CMD receives a commandeLireUn request$")
  public void receiveCommandeLireUnRequest()
  {
    receiveRequest(METHOD_COMMANDE_LIRE_UN, null, false);
  }

  /**
   * Expect CMD receives a commandeModifierStatut request.
   */
  @When("CMD receives a commandeModifierStatut request")
  public void receiveCommandeModifierStatutRequest()
  {
    receiveRequest(METHOD_COMMANDE_MODIFIER_STATUT, null, false);
  }

  /**
   * Expect CMD receives a modificationCommercialeCreerListe request.
   *
   * @param template_p
   *          The ressource
   */
  @When("^CMD receives a modificationCommercialeCreerListe request with ([^\"]*)$")
  public void receiveModificationCommercialeCreerListeRequest(String template_p)
  {
    receiveRequest(METHOD_MODIFICATION_COMMERCIALE_CREER_LISTE, template_p, false);
  }

  /**
   * Expect CMD receives a modificationCommercialeModifierListeStatut request.
   *
   * @param template_p
   *          The ressource
   */
  @When("^CMD receives a modificationCommercialeModifierListeStatut request with ([^\"]*)$")
  public void receiveModificationCommercialeModifierListeStatutRequest(String template_p)
  {
    receiveRequest(METHOD_MODIFICATION_COMMERCIALE_MODIFIER_LISTE_STATUT, template_p, false);
  }

  /**
   * Expect CMD receives a modificationTechniqueCreerListe request.
   *
   * @param template_p
   *          The ressource
   */
  @When("^CMD receives a modificationTechniqueCreerListe request with ([^\"]*)$")
  public void receiveModificationTechniqueCreerListeRequest(String template_p)
  {
    _service = METHOD_MODIFICATION_TECHNIQUE_CREER_LISTE;
    _serverRequest = this.getDesigner().http().server(BouchonHttpConfig.CMD_SERVER).receive().post(URL_MODIFICATION_TECHNIQUE).payload(templateResource(_service, REQUEST_DIR, template_p));
  }

  /**
   * Expect CMD receives a modificationTechniqueModifierListeStatut request.
   */
  @When("^CMD receives a modificationTechniqueModifierListeStatut request with ([^\"]*)$")
  public void receiveModificationTechniqueModifierListeStatutRequest(String template_p)
  {
    _service = METHOD_MODIFICATION_TECHNIQUE_MODIFIER_LISTE_STATUT;
    _serverRequest = this.getDesigner().http().server(BouchonHttpConfig.CMD_SERVER).receive().put(URL_MODIFICATION_TECHNIQUE).payload(templateResource(_service, REQUEST_DIR, template_p));
  }

  /**
   * CMD responds with status and template
   *
   * @param statusCode_p
   *          http status code
   * @param template_p
   *          relative template path
   */
  @Then("^CMD responds status (\\d+) with ([^\"]*)$")
  public void responseAction(Integer statusCode_p, String template_p)
  {
    serverResponseAction(BouchonHttpConfig.CMD_SERVER, statusCode_p, templateResource(_service, RESPONSE_DIR, template_p));
  }

  /**
   * CMD responds with template
   *
   * @param template_p
   *          template
   */
  @Then("^CMD responds with ([^\"]*)$")
  public void sendCommandeCreerAction(String template_p)
  {
    serverResponseActionOK(BouchonHttpConfig.CMD_SERVER, templateResource(_service, RESPONSE_DIR, template_p));
  }

  /**
   * Generic method to receive the request
   *
   * @param method_p
   *          method name to call
   * @param template_p
   *          template file name
   */
  private void receiveRequest(String method_p, String template_p, boolean isControlHeaders_p)
  {
    _service = method_p;

    switch (_service)
    {
      // URL_COMMANDE
      case METHOD_COMMANDE_CREER:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.CMD_SERVER)//
            .receive()//
            .post(URL_COMMANDE)//
            .payload(templateResource(_service, REQUEST_DIR, template_p));
        break;

      case METHOD_COMMANDE_LIRE_UN:
      case METHOD_COMMANDE_PLUS_VIEUX_PAR_CLE_SEQUENCEMENT:
      case METHOD_COMMANDE_LIRE_UN_PAR_ID_EXTERNE_ET_NATURE_COMMANDE_ET_PFI:
      case METHOD_COMMANDE_LIRE_TOUS_PAR_STATUT_ET_PFI:
      case METHOD_COMMANDE_GERER_FINALISER_COMMANDES_PAR_PFI:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.CMD_SERVER)//
            .receive()//
            .get(URL_COMMANDE);
        break;

      case METHOD_COMMANDE_MODIFIER_STATUT:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.CMD_SERVER)//
            .receive()//
            .put(URL_COMMANDE);
        break;

      // URL_COMMANDE_COMPOSITE
      case METHOD_COMMANDE_COMPOSITE_LIRE_TOUS_PAR_PFI:
      case METHOD_COMMANDE_COMPOSITE_GERER_LIRE_TOUS:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.CMD_SERVER)//
            .receive()//
            .get(URL_COMMANDE_COMPOSITE);
        break;

      // URL_MODIFICATION_COMMERCIALE
      case METHOD_MODIFICATION_COMMERCIALE_CREER_LISTE:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.CMD_SERVER)//
            .receive()//
            .post(URL_MODIFICATION_COMMERCIALE)//
            .payload(templateResource(_service, REQUEST_DIR, template_p));
        break;

      case METHOD_MODIFICATION_COMMERCIALE_MODIFIER_LISTE_STATUT:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.CMD_SERVER)//
            .receive()//
            .put(URL_MODIFICATION_COMMERCIALE)//
            .payload(templateResource(_service, REQUEST_DIR, template_p));
        break;

      // URL_MODIFICATION_TECHNIQUE
      case METHOD_MODIFICATION_TECHNIQUE_CREER_LISTE:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.CMD_SERVER)//
            .receive()//
            .post(URL_MODIFICATION_TECHNIQUE)//
            .payload(templateResource(_service, REQUEST_DIR, template_p));
        break;
      case METHOD_MODIFICATION_TECHNIQUE_MODIFIER_LISTE_STATUT:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.CMD_SERVER)//
            .receive()//
            .put(URL_MODIFICATION_TECHNIQUE)//
            .payload(templateResource(_service, REQUEST_DIR, template_p));
        break;

      default:
        break;
    }

    if (isControlHeaders_p)
    {
      controlReceivedHeaders(_serverRequest, false);
    }
  }
}
