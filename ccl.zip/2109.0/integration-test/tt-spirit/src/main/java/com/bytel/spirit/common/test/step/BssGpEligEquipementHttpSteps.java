/*******************************************************************************
* $Id: BssGpEligEquipementHttpSteps.java 34091 2020-04-02 16:50:34Z jjoly $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.test.step;

import com.bytel.spirit.common.test.config.BouchonHttpConfig;
import com.consol.citrus.dsl.builder.HttpServerRequestActionBuilder;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

/**
 *
 * @author jjoly
 * @version ($Revision: 34091 $ $Date: 2020-04-02 18:50:34 +0200 (jeu. 02 avril 2020) $)
 */
public final class BssGpEligEquipementHttpSteps extends AbstractSpiritHttpSteps
{
  /** BSSGP base path. */
  private static final String BASE_PATH = "BSSGPEligEquipement"; //$NON-NLS-1$

  /** Url for integrerCRSwapEquipement */
  private static final String URL_BSSGPELIGEQUIPEMENT_MANAGEMENT = "/"; //$NON-NLS-1$

  /** Constant for method integrerCRSwapEquipement */
  private static final String METHOD_INTEGRER_CR_SWAP_EQUIPEMENT = "integrerCRSwapEquipement"; //$NON-NLS-1$

  /** Transient expected BssGpEligEquipement server request. */
  private HttpServerRequestActionBuilder _serverRequest;

  /** Transient service. */
  private String _service;

  /**
   * Constructor
   */
  public BssGpEligEquipementHttpSteps()
  {
    super(BASE_PATH);
  }

  /**
   * BSSGPEligEquipement receives integrerCRSwapEquipement request.
   *
   * @param template_p
   *          the template to control from
   */
  @When("^BSSGPEligEquipement receives a integrerCRSwapEquipement request with ([^\"]*)$")
  public void getOrdersInfoByPortfolio(final String template_p)
  {
    receiveRequest(METHOD_INTEGRER_CR_SWAP_EQUIPEMENT, template_p, false);
  }

  /**
   * BSSGPEligEquipement responds
   *
   * @param template_p
   *          relative template path
   */
  @Then("^BSSGPEligEquipement responds with ([^\"]*)$")
  public void sendAction(final String template_p)
  {
    switch (_service)
    {
      case METHOD_INTEGRER_CR_SWAP_EQUIPEMENT:
        serverResponseActionOK(BouchonHttpConfig.BSS_GP_ELIG_EQUIPEMENT_SERVER, templateResource(_service, RESPONSE_DIR, template_p));
        break;

      default:
        break;
    }
  }

  /**
   * Generic method to receive the request
   *
   * @param method_p
   *          method name to call
   * @param template_p
   *          template file name
   * @param isControlHeaders_p
   *          true if force header control, false elsewhere
   */
  private void receiveRequest(String method_p, String template_p, boolean isControlHeaders_p)
  {
    _service = method_p;
    switch (_service)
    {
      // URL_ORDER_MANAGEMENT_DIAG
      case METHOD_INTEGRER_CR_SWAP_EQUIPEMENT:
        _serverRequest = getDesigner()//
            .http() //
            .server(BouchonHttpConfig.BSS_GP_ELIG_EQUIPEMENT_SERVER) //
            .receive() //
            .post(URL_BSSGPELIGEQUIPEMENT_MANAGEMENT) //
            .payload(templateResource(_service, REQUEST_DIR, template_p));

        break;
      default:
        break;
    }

    if (isControlHeaders_p)
    {
      controlReceivedHeaders(_serverRequest, false);
    }
  }
}
