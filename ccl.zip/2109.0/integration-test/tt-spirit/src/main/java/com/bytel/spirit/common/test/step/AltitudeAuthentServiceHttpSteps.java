/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.test.step;

import com.bytel.spirit.common.test.config.BouchonHttpConfig;
import com.consol.citrus.dsl.builder.HttpServerRequestActionBuilder;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

/**
 *
 * @author mlebihan
 * @version ($Revision$ $Date$)
 */
public class AltitudeAuthentServiceHttpSteps extends AbstractSpiritHttpSteps
{
  /** Altitude authent service base path. */
  private static final String AUTHENT_SERVICE_BASE_PATH = "AuthentService"; //$NON-NLS-1$

  /** Url for Altitude authent service. */
  private static final String URL_ALTITUDE = "/Authentication"; //$NON-NLS-1$

  /** Constant for method altitude */
  private static final String METHOD_ALTITUDE = "altitude"; //$NON-NLS-1$

  /** Transient expected OI server request. */
  private HttpServerRequestActionBuilder _serverRequest;

  /** Transient service. */
  private String _service;

  /** Constructor */
  public AltitudeAuthentServiceHttpSteps()
  {
    super(AUTHENT_SERVICE_BASE_PATH);
  }

  /**
   * Comment.
   *
   * @param comment
   *          Comment to log.
   */
  @Then("AltitudeService comment \"([^\"]*)\"")
  public void comment(String comment)
  {
    this.getDesigner().echo("Altitude service : " + comment); //$NON-NLS-1$
  }

  /**
   * Expect request has given query param
   *
   * @param name_p
   *          query param name
   * @param value_p
   *          query param value
   */
  @And("AltitudeService query param ([^\"]*)=([^\"]*)$")
  public void expectQueryParam(String name_p, String value_p)
  {
    _serverRequest.queryParam(name_p, value_p);
  }

  /**
   * Expect that Authent service receives an authent service request.
   */
  @When("^AltitudeService receives a service request$")
  public void receiveAltitudeAuthentServiceRequest()
  {
    receiveRequest(METHOD_ALTITUDE, false);
  }

  /**
   * Altitude service responds an error
   *
   * @param codeHttp_p
   *          Http Code
   * @param template_p
   *          relative template path
   */
  @Then("AltitudeService responds status (\\d+) with ([^\"]*)$")
  public void responseAction(Integer codeHttp_p, String template_p)
  {
    serverResponseAction(BouchonHttpConfig.AUTHENTIFICATION_SERVICE_SERVER, codeHttp_p, templateResource(_service, RESPONSE_DIR, template_p));
  }

  /**
   * Generic method to receive the request
   *
   * @param method_p
   *          method name to call
   * @param isControlHeaders_p
   *          isControlHeaders
   */
  private void receiveRequest(String method_p, boolean isControlHeaders_p)
  {
    _service = method_p;

    switch (_service)
    {
      case METHOD_ALTITUDE:
        _serverRequest = this.getDesigner()//
            .http()//
            .server(BouchonHttpConfig.AUTHENTIFICATION_SERVICE_SERVER)//
            .receive()//
            .get(URL_ALTITUDE);

        break;
      default:
        break;
    }

    if (isControlHeaders_p)
    {
      controlReceivedHeaders(_serverRequest, false);
    }
  }
}
