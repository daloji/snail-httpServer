/*******************************************************************************
 * $Id: CmdHttpSteps.java 18580 2019-03-14 10:51:07Z jpais $
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.common.test.step;

import com.bytel.ravel.step.helper.AbstractHttpSteps;
import com.bytel.spirit.common.test.config.BouchonHttpConfig;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

/**
 *
 * @author JPAIS
 * @version ($Revision: 18580 $ $Date: 2019-03-14 11:51:07 +0100 (Thu, 14 Mar 2019) $)
 */
public class LegacyVoipHttpSteps extends AbstractHttpSteps
{

  /** AIR base path. */
  private static final String BASE_PATH = "LEGACY_VOIP"; //$NON-NLS-1$

  /** Url for VoipInformationService */
  private static final String URL_VOIP_INFORMATION = "/voip_usage/VoipInformationService";

  /** Constant for method getServicesByNumTel */
  private static final String METHOD_GET_SERVICES_BY_NUM_TEL = "getServicesByNumTel";

  /** Transient service. */
  private String _service;

  /**
   * Constructor
   */
  public LegacyVoipHttpSteps()
  {
    super(BASE_PATH);
  }

  @Given("Voip request will contain ([^\"]*)=([^\"]*)$")
  public void expectRequestContains(String name_p, String value_p)
  {
    this.getDesigner().createVariable(name_p, value_p);
  }

  /**
   * Diag receives getOrdersInfoByPortfolio request.
   *
   * @param template_p
   *          the template to control from
   */
  @When("^Voip receives a getServicesByNumTel request with ([^\"]*)$")
  public void getOrdersInfoByPortfolio(final String template_p)
  {
    receiveRequest(METHOD_GET_SERVICES_BY_NUM_TEL, template_p, false);
  }

  /**
   * Diag responds
   *
   * @param template_p
   *          relative template path
   */
  @Then("^Voip responds with ([^\"]*)$")
  public void sendAction(final String template_p)
  {
    switch (_service)
    {
      case METHOD_GET_SERVICES_BY_NUM_TEL:
        serverResponseActionOK(BouchonHttpConfig.LEGACY_VOIP_SERVER, templateResource(_service, RESPONSE_DIR, template_p));
        break;
      default:
        break;
    }
  }

  /**
   * Generic method to receive the request
   *
   * @param method_p
   *          method name to call
   * @param template_p
   *          template file name
   */
  private void receiveRequest(String method_p, String template_p, boolean isControlHeaders_p)
  {
    _service = method_p;

    switch (_service)
    {
      // URL_ORDER_MANAGEMENT_DIAG
      case METHOD_GET_SERVICES_BY_NUM_TEL:
        this.getDesigner()//
            .http() //
            .server(BouchonHttpConfig.LEGACY_VOIP_SERVER) //
            .receive() //
            .post(URL_VOIP_INFORMATION) //
            .payload(templateResource(_service, REQUEST_DIR, template_p));

        break;
      default:
        break;
    }
  }

}
