/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.common.test.step;

import com.bytel.spirit.common.test.config.BouchonHttpConfig;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

/**
 *
 * @author icarrao
 * @version ($Revision$ $Date$)
 */
public class LegacyPadawanFtthHttpSteps extends AbstractSpiritHttpSteps
{
  /** PadawanFTTH base path. */
  private static final String BASE_PATH = "LEGACY_PADAWAN_FTTH"; //$NON-NLS-1$

  /** Url for LegacyPadawanFTTH */
  private static final String URL_FTTH_ACCESS= "/padawan-ftth/FtthAccessService"; //$NON-NLS-1$

  /** Url for LegacyPadawanFTTH */
  private static final String URL_FTTH_EXTERN= "/padawan-ftth/FtthExternService"; //$NON-NLS-1$

  /** Constant for method recupererInfosAccesFTTH */
  private static final String METHOD_RECUPERER_INFOS_ACCES_FTTH = "recupererInfosAccesFTTH"; //$NON-NLS-1$

  /** Constant for method getNrmIdByIdOss */
  private static final String METHOD_GET_NRM_ID_BY_ID_OSS = "getNrmIdByIdOss"; //$NON-NLS-1$

  /** Transient service. */
  private String _service;

  /**
   * Constructor
   */
  public LegacyPadawanFtthHttpSteps()
  {
    super(BASE_PATH);
  }

  /**
   * PadawanFTTH receives recupererInfosAccesFTTH request.
   *
   * @param template_p
   *          the template to control from
   */
  @When("^PadawanFTTH receives a recupererInfosAccesFTTH request with ([^\"]*)$")
  public void recupererInfosAccesFTTHRequest(final String template_p)
  {
    receiveRequest(METHOD_RECUPERER_INFOS_ACCES_FTTH, template_p);
  }

  /**
   * PadawanFTTH responds with template
   *
   * @param template_p
   *          template
   */
  @Then("PadawanFTTH responds with ([^\"]*)$")
  public void padawanFTTHResponse(String template_p)
  {
    sendResponse(template_p);
  }

  /**
   * PadawanFTTH receives getNrmIdByIdOss request.
   *
   * @param template_p
   *          the template to control from
   */
  @When("^PadawanFTTH receives a getNrmIdByIdOss request with ([^\"]*)$")
  public void getNrmIdByIdOssRequest(final String template_p)
  {
    receiveRequest(METHOD_GET_NRM_ID_BY_ID_OSS, template_p);
  }

  /**
   * Generic method to receive the request
   *
   * @param method_p
   *          method name to call
   * @param template_p
   *          template file name
   */
  private void receiveRequest(String method_p, String template_p)
  {
    _service = method_p;

    switch (_service)
    {
      // URL_FTTH_ACCESS
      case METHOD_RECUPERER_INFOS_ACCES_FTTH:
        this.getDesigner()//
            .http() //
            .server(BouchonHttpConfig.LEGACY_PADAWAN_FTTH_SERVER) //
            .receive() //
            .post(URL_FTTH_ACCESS) //
            .payload(templateResource(method_p, REQUEST_DIR, template_p));
        break;
      // URL_FTTH_EXTERN
      case METHOD_GET_NRM_ID_BY_ID_OSS:
        this.getDesigner()//
            .http() //
            .server(BouchonHttpConfig.LEGACY_PADAWAN_FTTH_SERVER) //
            .receive() //
            .post(URL_FTTH_EXTERN) //
            .payload(templateResource(method_p, REQUEST_DIR, template_p));
        break;
      default:
        break;
    }
  }

  /**
   * Generic method to receive the request
   *
   * @param template_p
   *          template file name
   */
  private void sendResponse(String template_p)
  {
    switch (_service)
    {
      // URL_FTTH_ACCESS
      case METHOD_RECUPERER_INFOS_ACCES_FTTH:
      case METHOD_GET_NRM_ID_BY_ID_OSS:
        serverResponseActionOK(BouchonHttpConfig.LEGACY_PADAWAN_FTTH_SERVER, templateResource(_service, RESPONSE_DIR, template_p));
        break;

      default:
        break;
    }
  }
}
