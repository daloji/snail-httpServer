package com.bytel.spirit.common.test.step;

import com.bytel.spirit.common.test.config.BouchonHttpConfig;
import com.consol.citrus.dsl.builder.HttpServerRequestActionBuilder;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

/**
 *
 * @author vloureir
 * @version ($Revision$ $Date$)
 */
public final class BssGpHttpSteps extends AbstractSpiritHttpSteps
{
  /** BSSGP base path. */
  private static final String BASE_PATH = "BSSGP"; //$NON-NLS-1$

  /** Url for OrderManagementDiagService */
  private static final String URL_RESYNCHRO_NFS = "/resynchroNSF/"; //$NON-NLS-1$

  /** Constant for method demandeBSSGP */
  private static final String METHOD_DEMANDE_BSSGP = "demandeBSSGP"; //$NON-NLS-1$

  /** Transient expected AIR server request. */
  private HttpServerRequestActionBuilder _serverRequest;

  /** Transient service. */
  private String _service;

  /**
   * Constructor
   */
  public BssGpHttpSteps()
  {
    super(BASE_PATH);
  }

  /**
   * Expect request has given query param
   *
   * @param name_p
   *          query param name
   * @param value_p
   *          query param value
   */
  @And("BSSGP query param ([^\"]*)=([^\"]*)$")
  public void expectQueryParam(String name_p, String value_p)
  {
    _serverRequest.queryParam(name_p, value_p);
  }

  /**
   * BSSGP receives demandeBSSGP request.
   */
  @When("^BSSGP receives a demandeBSSGP request with ([^\"]*)$")
  public void getDemandeBSSGP(final String template_p)
  {
    receiveRequest(METHOD_DEMANDE_BSSGP, template_p, false);
  }

  /**
   * BSSGP responds
   *
   * @param template_p
   *          relative template path
   */
  @Then("^BSSGP responds with ([^\"]*)$")
  public void sendAction(final String template_p)
  {
    serverResponseActionOK(BouchonHttpConfig.BSS_GP_SERVER, templateResource(_service, RESPONSE_DIR, template_p));
  }

  /**
   * Generic method to receive the request
   *
   * @param method_p
   *          method name to call
   * @param template_p
   *          template file name
   */
  private void receiveRequest(String method_p, String template_p, boolean isControlHeaders_p)
  {
    _service = method_p;

    switch (_service)
    {
      // URL_ORDER_MANAGEMENT_DIAG
      case METHOD_DEMANDE_BSSGP:
        _serverRequest = this.getDesigner()//
            .http() //
            .server(BouchonHttpConfig.BSS_GP_SERVER) //
            .receive() //
            .post(URL_RESYNCHRO_NFS) //
            .payload(templateResource(_service, REQUEST_DIR, template_p));
        break;
      default:
        break;
    }

    if (isControlHeaders_p)
    {
      controlReceivedHeaders(_serverRequest, false);
    }
  }
}
