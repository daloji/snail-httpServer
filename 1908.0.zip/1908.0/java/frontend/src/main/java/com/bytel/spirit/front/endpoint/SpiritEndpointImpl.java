/*******************************************************************************
 * $Id: EndpointImpl.java 26713 2014-10-17 00:46:32Z BTTD2025\rgoncalv $
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.front.endpoint;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

import org.apache.cxf.common.util.StringUtils;

import com.bytel.ravel.common.data.exchange.generated.RavelResponse;
import com.bytel.ravel.frontend.EndpointImpl;
import com.bytel.ravel.net.http.HttpResponse;

/**
 * Main endpoint serving both JAX-RS and JAX-WS services.
 *
 * @author fbarnabe
 * @version ($Revision: 26713 $ $Date: 2014-10-17 02:46:32 +0200 (ven., 17 oct. 2014) $)
 */

public class SpiritEndpointImpl extends EndpointImpl
{

  @Override
  protected Response transformeResponse(HttpResponse httpResponse_p)
  {

    ResponseBuilder responseBuilder = Response.status(httpResponse_p.getHttpStatusCode());
    if (httpResponse_p.getGenericResponse() != null)
    {
      String response = httpResponse_p.getGenericResponse().getResult();
      String dataType = httpResponse_p.getGenericResponse().getDataType();

      if (StringUtils.isEmpty(dataType))
      {
        responseBuilder = responseBuilder.type(MediaType.TEXT_XML);
      }
      else
      {
        responseBuilder = responseBuilder.type(dataType);
      }

      for (RavelResponse.ResponseHeader header : httpResponse_p.getGenericResponse().getResponseHeader())
      {
        responseBuilder.header(header.getName(), header.getValue());
      }

      responseBuilder = responseBuilder.entity(response);
    }
    Response response = responseBuilder.build();

    return response;
  }

}
