/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.front.proxy;

import java.io.InputStream;
import java.util.List;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.request.IRavelRequest;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.frontend.proxy.HttpProxyV2;
import com.bytel.ravel.frontend.proxy.generated.Proxy;
import com.bytel.ravel.frontend.proxy.generated.URI;

/**
 *
 * @author jgregori
 * @version ($Revision$ $Date$)
 */
public class SpiritHttpProxyV2 extends HttpProxyV2
{

  /**
   * @param proxy_p
   */
  public SpiritHttpProxyV2(Proxy proxy_p)
  {
    super(proxy_p);
  }

  @Override
  protected void sendHttpRequest(URI uri_p, IRavelRequest request_p) throws RavelException
  {
    String msgId = SpiritProxyUtils.getMsgIdFromHeader(request_p.getRequestHeader());//Get msgId from Header if present, null otherwise
    if (StringTools.isNotNullOrEmpty(msgId))
    {
      request_p.setMsgId(msgId);
    }
    super.sendHttpRequest(uri_p, request_p);

    // add RequestId-spirit in the response headers
    if (request_p.getRawResponse() != null)
    {
      InputStream input = (InputStream) request_p.getRawResponse().getEntity();
      ResponseBuilder responseBuilder = Response.status(request_p.getRawResponse().getStatus()).type(request_p.getRawResponse().getMediaType()).entity(input);

      if (request_p.getRawResponse().getHeaders() != null)
      {
        for (String headerName : request_p.getRawResponse().getHeaders().keySet())
        {
          List<Object> headerValues = request_p.getRawResponse().getHeaders().get(headerName);
          for (Object headerValue : headerValues)
          {
            responseBuilder.header(headerName, headerValue);
          }
        }
      }
      responseBuilder.header(SpiritProxyUtils.X_REQUEST_ID_SPIRIT, request_p.getMsgId());
      request_p.setRawResponse(responseBuilder.build());
    }
  }
}
