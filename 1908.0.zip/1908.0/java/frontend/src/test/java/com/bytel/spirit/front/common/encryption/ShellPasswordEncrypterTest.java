/*******************************************************************************
* $Id: ShellPasswordEncrypterTest.java 1646 2017-10-05 12:50:04Z vthibaul $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.front.common.encryption;

import javax.crypto.SecretKey;

import org.junit.Assert;
import org.junit.Test;

import com.bytel.ravel.common.encryption.DESEncrypter;
import com.bytel.ravel.common.encryption.DESKeyManager;

/**
 * ShellPasswordEncrypter test class
 *
 * @author lchanyip
 * @version ($Revision: 1646 $ $Date: 2017-10-05 14:50:04 +0200 (jeu., 05 oct. 2017) $)
 */
public class ShellPasswordEncrypterTest
{

  /**
   * Encyption test OK
   *
   * @throws Exception
   *
   */
  @Test
  public void testEncrypt() throws Exception
  {
    SecretKey key = new DESKeyManager("com.bytel.spirit.front.common.encryption.DESKey").getSecretKey(); //$NON-NLS-1$
    Assert.assertEquals("MHndnhfjTSOsxxKKnPjCVA==", new DESEncrypter(key).encrypt("azertyqsdf"));
  }
}
