package com.bytel.ravel.training.struct.commandePFI;

import java.time.LocalDateTime;

/**
 *
 * @author jstrub
 * @version ($Revision: 6719 $ $Date: 2019-02-11 12:03:32 +0100 (lun., 11 févr. 2019) $)
 */
public class CommandePFI
{

  /** */
  private String type;
  /** */
  private LocalDateTime timestamp;
  /** */
  private PortefeuilleServices portefeuilleServices;

  /**
   * @return the portefeuilleServices
   */
  public PortefeuilleServices getPortefeuilleServices()
  {
    return portefeuilleServices;
  }

  /**
   * @return the timestamp
   */
  public LocalDateTime getTimestamp()
  {
    return timestamp;
  }

  /**
   * @return the type
   */
  public String getType()
  {
    return type;
  }

  /**
   * @param portefeuilleServices_p
   *          the portefeuilleServices to set
   */
  public void setPortefeuilleServices(PortefeuilleServices portefeuilleServices_p)
  {
    portefeuilleServices = portefeuilleServices_p;
  }

  /**
   * @param timestamp_p
   *          the timestamp to set
   */
  public void setTimestamp(LocalDateTime timestamp_p)
  {
    timestamp = timestamp_p;
  }

  /**
   * @param type_p
   *          the type to set
   */
  public void setType(String type_p)
  {
    type = type_p;
  }

}
