package com.bytel.ravel.training.processus;

import java.time.Duration;
import java.util.Optional;

import javax.ws.rs.core.MultivaluedHashMap;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.request.IRavelRequest;
import com.bytel.ravel.common.factory.request.Parameter;
import com.bytel.ravel.common.factory.response.IRavelResponse;
import com.bytel.ravel.common.factory.response.RavelResponseFactory;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.log.event.SystemLogEvent;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.connector.ConnectorManager;
import com.bytel.ravel.services.process.MandatoryProcessState;
import com.bytel.ravel.services.process.ProcessSkeleton;
import com.bytel.ravel.services.process.activity.Context;
import com.bytel.ravel.training.TestUtils;
import com.bytel.ravel.training.connector.COMConnector;
import com.bytel.ravel.training.struct.cmd.Commande;
import com.google.gson.Gson;

/**
 * @author jstrub
 * @version ($Revision: 6719 $ $Date: 2019-02-11 12:03:32 +0100 (lun., 11 févr. 2019) $)
 */
public class P01_EtatCommande extends ProcessSkeleton
{

  /**
   *
   * @author jstrub
   * @version ($Revision: 6719 $ $Date: 2019-02-11 12:03:32 +0100 (lun., 11 févr. 2019) $)
   */
  public static final class P01_EtatCommandeContext extends Context
  {

    /** Generated versionUID. */
    private static final long serialVersionUID = -92023979893273779L;

    /** Contains the next step to execute. Initialized with the first step to execute. */
    private P01_EtatCommandeState _state = P01_EtatCommandeState.START;

    /**
     * @return the state
     */
    public P01_EtatCommandeState getState()
    {
      return _state;
    }

    /**
     * @param state_p
     *          the state to set
     */
    public void setState(P01_EtatCommandeState state_p)
    {
      _state = state_p;
    }
  }

  /**
   * The Enum containing all process states
   *
   * @author jstrub
   * @version ($Revision: 6719 $ $Date: 2019-02-11 12:03:32 +0100 (lun., 11 févr. 2019) $)
   */
  public enum P01_EtatCommandeState
  {
    /** START */
    START(MandatoryProcessState.PRC_START, false, false),
    /** Terminal state. */
    ENDED(MandatoryProcessState.PRC_STOP, false, false);

    /** Technical state associated. */
    protected MandatoryProcessState _technicalState = MandatoryProcessState.PRC_START;
    /** The asynchronous state. */
    protected Boolean _asynchronousState = false;
    /** Replayable state. */
    protected Boolean _replayableState = false;

    /**
     * Constructor.
     *
     * @param technicalState_p
     *          The {@link MandatoryProcessState} associated
     * @param replayable_p
     *          is replayable state
     * @param asynchronous_p
     *          is asynchronous state
     */
    private P01_EtatCommandeState(final MandatoryProcessState technicalState_p, final Boolean replayable_p, final Boolean asynchronous_p)
    {
      _technicalState = technicalState_p;
      _replayableState = replayable_p;
      _asynchronousState = asynchronous_p;
    }

    /**
     * @return the asynchronousState
     */
    public Boolean getAsynchronousState()
    {
      return _asynchronousState;
    }

    /**
     * @return the replayableState
     */
    public final Boolean getReplayableState()
    {
      return _replayableState;
    }

    /**
     * @return the technicalState
     */
    public final MandatoryProcessState getTechnicalState()
    {
      return _technicalState;
    }
  }

  /** Generated versionUID. */
  private static final long serialVersionUID = 3043806096860837742L;
  /** Process context instance. */
  private P01_EtatCommandeContext _processContext;

  @Override
  protected void continueProcess(IRavelRequest arg0_p) throws RavelException
  {
    // Auto-generated method stub
  }

  @Override
  public String createDefaultFunctionalResponse(Retour retour_p) throws RavelException
  {
    return ""; //$NON-NLS-1$
  }

  @Override
  protected void exitKOMetroLog(String s_p)
  {
    // Auto-generated method stub
  }

  @Override
  public String getInternalState()
  {
    return _processContext.getState().toString();
  }

  @Override
  public Duration getSleepTime()
  {
    return Duration.ofMinutes(0);
  }

  @Override
  public MandatoryProcessState getTechnicalState()
  {
    return _processContext.getState()._technicalState;
  }

  @Override
  public void initializeContext()
  {
    _processContext = new P01_EtatCommandeContext();
  }

  @Override
  public boolean isAsynchronous()
  {
    return _processContext.getState()._asynchronousState;
  }

  @Override
  public boolean isReplayable()
  {
    return _processContext.getState()._replayableState;
  }

  @Override
  protected void startMetroLog()
  {
    // Auto-generated method stub
  }

  @Override
  protected void startProcess(IRavelRequest request) throws RavelException
  {
    // Default error retour
    setRetour(RetourFactory.createKO(IMegConsts.CAT10, IMegConsts.TRAITEMENT_ARRETE, IMegConsts.PROBLEME_INCONNU));
    // Default result
    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setResult("{}"); //$NON-NLS-1$

    // Read request
    RavelLogger.log(new SystemLogEvent(LogSeverity.DEBUG, request.getMsgId(), "Reading parameter")); //$NON-NLS-1$
    Optional<Parameter> idCommande = request.getUrlParameters().getUrlParameters().stream().filter(p -> "idCommande".equals(p.getName())).findFirst(); //$NON-NLS-1$
    if (!idCommande.isPresent())
    {
      RavelLogger.log(new SystemLogEvent(LogSeverity.ERROR, request.getMsgId(), "Error 400 : missing idCommande parameter")); //$NON-NLS-1$
      request.setResponse(new Response(ErrorCode.KO_00400, response));
      return;
    }
    if (idCommande.get().getValue().length() < 36)
    {
      RavelLogger.log(new SystemLogEvent(LogSeverity.ERROR, request.getMsgId(), "Error 400 : idCommande is not an UUID")); //$NON-NLS-1$
      request.setResponse(new Response(ErrorCode.KO_00400, response));
      return;
    }

    try
    {
      // Call COM connector
      RavelLogger.log(new SystemLogEvent(LogSeverity.DEBUG, request.getMsgId(), "Calling COM on recherche service")); //$NON-NLS-1$
      Commande commande = ((COMConnector) ConnectorManager.getInstance().getConnector("COMConnector")).recherche(idCommande.get().getValue(), request.getMsgId(), new MultivaluedHashMap<String, String>()); //$NON-NLS-1$

      // Prepare response
      RavelLogger.log(new SystemLogEvent(LogSeverity.DEBUG, request.getMsgId(), "Preparing response")); //$NON-NLS-1$
      Gson gson = TestUtils.getDefaultGson();
      response.setResult(gson.toJson(commande));
      request.setResponse(new Response(ErrorCode.OK_00000, response));
      setRetour(RetourFactory.createOkRetour());
    }
    catch (RavelException e)
    {
      RavelLogger.log(new SystemLogEvent(LogSeverity.ERROR, request.getMsgId(), e));
      Response errorResponse = new Response(ErrorCode.KO_00503, response);
      if (ErrorCode.KO_00404.equals(e.getErrorCode()))
      {
        RavelLogger.log(new SystemLogEvent(LogSeverity.ERROR, request.getMsgId(), "Detected a 404 error : propagating it.")); //$NON-NLS-1$
        errorResponse = new Response(ErrorCode.KO_00404, response);
      }

      request.setResponse(errorResponse);
    }

    _processContext.setState(P01_EtatCommandeState.ENDED);
  }

}
