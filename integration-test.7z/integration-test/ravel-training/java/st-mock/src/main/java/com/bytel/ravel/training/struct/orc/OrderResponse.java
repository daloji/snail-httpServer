package com.bytel.ravel.training.struct.orc;

import java.io.Serializable;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

/**
 *
 * @author jstrub
 * @version ($Revision: 6719 $ $Date: 2019-02-11 12:03:32 +0100 (lun., 11 févr. 2019) $)
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = { "orderId", "params" })
@XmlRootElement(name = "response")
public class OrderResponse implements Serializable
{

  /** */
  private final static long serialVersionUID = 100L;
  /** */
  @XmlElement(required = true)
  protected String orderId;
  /** */
  @XmlElement(name = "param")
  protected List<DatasetParam> params;

  /**
   * @return the orderId
   */
  public String getOrderId()
  {
    return orderId;
  }

  /**
   * @return the params
   */
  public List<DatasetParam> getParams()
  {
    return params;
  }

  /**
   * @param orderId_p
   *          the orderId to set
   */
  public void setOrderId(String orderId_p)
  {
    orderId = orderId_p;
  }

  /**
   * @param params_p
   *          the params to set
   */
  public void setParams(List<DatasetParam> params_p)
  {
    params = params_p;
  }
}
