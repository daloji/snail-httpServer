/*******************************************************************************
 * $Id: CLIConnector.java 6719 2019-02-11 11:03:32Z jstrub $
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.ravel.training.connector;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;

import org.apache.commons.io.IOUtils;

import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.services.connector.AbstractRESTConnector;
import com.bytel.ravel.services.connector.RESTRequest.RESTRequestBuilder;
import com.bytel.ravel.training.TestUtils;
import com.bytel.ravel.training.struct.cli.EtatCompte;
import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;

/**
 *
 * @author jstrub
 * @version ($Revision: 6719 $ $Date: 2019-02-11 12:03:32 +0100 (lun., 11 févr. 2019) $)
 */
public class CLIConnector extends AbstractRESTConnector
{

  /** HTTP request PATH */
  private static final String CHECK_PATH = "/compte/check"; //$NON-NLS-1$

  /**
   * @param noCompte_p
   *          noCompte
   * @param msgId_p
   *          msgId
   * @param headers_p
   *          headers
   * @return call result
   * @throws RavelException
   *           on error
   */
  public EtatCompte check(Long noCompte_p, String msgId_p, MultivaluedMap<String, String> headers_p) throws RavelException
  {
    Gson gson = TestUtils.getDefaultGson();

    Map<String, String> queryParams = new HashMap<>();
    queryParams.put("noCompte", noCompte_p.toString()); //$NON-NLS-1$

    RESTRequestBuilder req = new RESTRequestBuilder().httpMethod("GET").msgId(msgId_p).path(CHECK_PATH).queryParameter(queryParams); //$NON-NLS-1$
    req.headers(headers_p);
    Response httpResponse = super.send(req.build());
    EtatCompte reponse = null;
    try
    {
      reponse = gson.fromJson(IOUtils.toString((InputStream) httpResponse.getEntity()), EtatCompte.class);
    }
    catch (JsonSyntaxException | IOException e)
    {
      throw new RavelException(ExceptionType.CONNECTOR_DATA_VALIDATION_ERROR, ErrorCode.CNCTOR_00010, "", e); //$NON-NLS-1$
    }

    return reponse;
  }

  @Override
  public String getConfigParameter(String connectorID_p, String paramName_p) throws RavelException
  {
    return null;
  }

}
