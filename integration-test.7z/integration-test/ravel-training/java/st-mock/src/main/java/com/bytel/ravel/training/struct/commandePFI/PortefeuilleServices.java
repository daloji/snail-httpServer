package com.bytel.ravel.training.struct.commandePFI;

import java.util.List;

/**
 *
 * @author jstrub
 * @version ($Revision: 6719 $ $Date: 2019-02-11 12:03:32 +0100 (lun., 11 févr. 2019) $)
 */
public class PortefeuilleServices
{
  /** */
  private Long noCompte;
  /** */
  private Statut statut;
  /** */
  private List<String> services;

  /**
   * @return the noCompte
   */
  public Long getNoCompte()
  {
    return noCompte;
  }

  /**
   * @return the services
   */
  public List<String> getServices()
  {
    return services;
  }

  /**
   * @return the statut
   */
  public Statut getStatut()
  {
    return statut;
  }

  /**
   * @param noCompte_p
   *          the noCompte to set
   */
  public void setNoCompte(Long noCompte_p)
  {
    noCompte = noCompte_p;
  }

  /**
   * @param services_p
   *          the services to set
   */
  public void setServices(List<String> services_p)
  {
    services = services_p;
  }

  /**
   * @param statut_p
   *          the statut to set
   */
  public void setStatut(Statut statut_p)
  {
    statut = statut_p;
  }
}
