package com.bytel.ravel.training.processus;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

import javax.ws.rs.core.MultivaluedHashMap;
import javax.ws.rs.core.MultivaluedMap;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.data.exchange.generated.RavelRequest.RequestHeader;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.request.IRavelRequest;
import com.bytel.ravel.common.factory.response.IRavelResponse;
import com.bytel.ravel.common.factory.response.RavelResponseFactory;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.log.event.SystemLogEvent;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.connector.ConnectorManager;
import com.bytel.ravel.services.process.MandatoryProcessState;
import com.bytel.ravel.services.process.ProcessSkeleton;
import com.bytel.ravel.services.process.activity.Context;
import com.bytel.ravel.training.TestUtils;
import com.bytel.ravel.training.connector.CLIConnector;
import com.bytel.ravel.training.connector.COMConnector;
import com.bytel.ravel.training.connector.ORCConnector;
import com.bytel.ravel.training.connector.SVCConnector;
import com.bytel.ravel.training.struct.Reponse;
import com.bytel.ravel.training.struct.cli.EtatCompte;
import com.bytel.ravel.training.struct.cmd.Commande;
import com.bytel.ravel.training.struct.cmd.Statut;
import com.bytel.ravel.training.struct.commandePFI.CommandePFI;
import com.bytel.ravel.training.struct.orc.DatasetParam;
import com.bytel.ravel.training.struct.orc.OrderRequest;
import com.bytel.ravel.training.struct.orc.OrderResponse;
import com.google.gson.Gson;

/**
 * @author jstrub
 * @version ($Revision: 6719 $ $Date: 2019-02-11 12:03:32 +0100 (lun., 11 févr. 2019) $)
 */
public class P02_CommandePFI extends ProcessSkeleton
{

  /**
   *
   * @author jstrub
   * @version ($Revision: 6719 $ $Date: 2019-02-11 12:03:32 +0100 (lun., 11 févr. 2019) $)
   */
  public static final class P02_CommandePFIContext extends Context
  {

    /** Generated versionUID. */
    private static final long serialVersionUID = -92023979893273779L;

    /** Contains the next step to execute. Initialized with the first step to execute. */
    private P02_CommandePFIState _state = P02_CommandePFIState.START;

    /** */
    private CommandePFI commandePFI;
    /** */
    private Commande commande;
    /** */
    private String msgId;

    /**
     * @return the commande
     */
    public Commande getCommande()
    {
      return commande;
    }

    /**
     * @return the commandePFI
     */
    public CommandePFI getCommandePFI()
    {
      return commandePFI;
    }

    /**
     * @return the msgId
     */
    public String getMsgId()
    {
      return msgId;
    }

    /**
     * @return the state
     */
    public P02_CommandePFIState getState()
    {
      return _state;
    }

    /**
     * @param commande_p
     *          the commande to set
     */
    public void setCommande(Commande commande_p)
    {
      commande = commande_p;
    }

    /**
     * @param commandePFI_p
     *          the commandePFI to set
     */
    public void setCommandePFI(CommandePFI commandePFI_p)
    {
      commandePFI = commandePFI_p;
    }

    /**
     * @param msgId_p
     *          the msgId to set
     */
    public void setMsgId(String msgId_p)
    {
      msgId = msgId_p;
    }

    /**
     * @param state_p
     *          the state to set
     */
    public void setState(P02_CommandePFIState state_p)
    {
      _state = state_p;
    }
  }

  /**
   * The Enum containing all process states
   *
   * @author jstrub
   * @version ($Revision: 6719 $ $Date: 2019-02-11 12:03:32 +0100 (lun., 11 févr. 2019) $)
   */
  public enum P02_CommandePFIState
  {
    /** START */
    START(MandatoryProcessState.PRC_START, false, false),
    /** Asynchronous state. */
    LANCER_ORCHESTRATEUR(MandatoryProcessState.PRC_RUNNING, false, true),
    /** Terminal state. */
    ENDED(MandatoryProcessState.PRC_STOP, false, false);

    /** Technical state associated. */
    protected MandatoryProcessState _technicalState = MandatoryProcessState.PRC_START;
    /** The asynchronous state. */
    protected Boolean _asynchronousState = false;
    /** Replayable state. */
    protected Boolean _replayableState = false;

    /**
     * Constructor.
     *
     * @param technicalState_p
     *          The {@link MandatoryProcessState} associated
     * @param replayable_p
     *          is replayable state
     * @param asynchronous_p
     *          is asynchronous state
     */
    private P02_CommandePFIState(final MandatoryProcessState technicalState_p, final Boolean replayable_p, final Boolean asynchronous_p)
    {
      _technicalState = technicalState_p;
      _replayableState = replayable_p;
      _asynchronousState = asynchronous_p;
    }

    /**
     * @return the asynchronousState
     */
    public Boolean getAsynchronousState()
    {
      return _asynchronousState;
    }

    /**
     * @return the replayableState
     */
    public final Boolean getReplayableState()
    {
      return _replayableState;
    }

    /**
     * @return the technicalState
     */
    public final MandatoryProcessState getTechnicalState()
    {
      return _technicalState;
    }
  }

  /** Special header that trigger the service check call. */
  private static final String X_SOURCE = "X-SOURCE"; //$NON-NLS-1$

  /** Generated versionUID. */
  private static final long serialVersionUID = 3043806096860837742L;

  /** Manual static cache. */
  private static final ConcurrentHashMap<String, List<String>> _cacheService = new ConcurrentHashMap<>();

  /**
   * Helper to create an orchestrator Param element.
   *
   * @param index
   *          index
   * @param name
   *          name
   * @param value
   *          value
   * @return the param
   */
  private static DatasetParam orcParam(long index, String name, String value)
  {
    DatasetParam param = new DatasetParam();
    param.setIndex(index);
    param.setName(name);
    param.setValue(value);
    return param;
  }

  /** Process context instance. */
  private P02_CommandePFIContext _processContext;

  @Override
  public String createDefaultFunctionalResponse(Retour retour_p) throws RavelException
  {
    return ""; //$NON-NLS-1$
  }

  @Override
  public String getInternalState()
  {
    return _processContext.getState().toString();
  }

  @Override
  public Duration getSleepTime()
  {
    return Duration.ofMinutes(0);
  }

  @Override
  public MandatoryProcessState getTechnicalState()
  {
    return _processContext.getState()._technicalState;
  }

  @Override
  public void initializeContext()
  {
    _processContext = new P02_CommandePFIContext();
  }

  @Override
  public boolean isAsynchronous()
  {
    return _processContext.getState()._asynchronousState;
  }

  @Override
  public boolean isReplayable()
  {
    return _processContext.getState()._replayableState;
  }

  @SuppressWarnings("nls")
  @Override
  protected void continueProcess(IRavelRequest requestAsync) throws RavelException
  {
    RavelLogger.log(new SystemLogEvent(LogSeverity.DEBUG, _processContext.getMsgId(), "About to call ORC on envoyerDemande service")); //$NON-NLS-1$
    CommandePFI commandePFI = _processContext.getCommandePFI();
    Commande commande = _processContext.getCommande();

    OrderRequest orcRequest = new OrderRequest();
    orcRequest.setOrderId(UUID.randomUUID().toString());
    orcRequest.setDomain("PROV");
    orcRequest.setVerb("TRAITER");
    orcRequest.setCustomerId(commandePFI.getPortefeuilleServices().getNoCompte().toString());
    orcRequest.setOriginator(commande.getClientOperateur());
    int i = 0;
    for (String service : commandePFI.getPortefeuilleServices().getServices())
    {
      orcRequest.getParams().add(orcParam(i++, "Services", service));
    }
    orcRequest.getParams().add(orcParam(0, "processus", this.getClass().getSimpleName()));
    orcRequest.getParams().add(orcParam(0, "priorite", "10"));
    orcRequest.getParams().add(orcParam(0, "idCommande", commande.getIdCommande()));

    OrderResponse orcEnvoyerReponse = ((ORCConnector) ConnectorManager.getInstance().getConnector("ORCConnector")).envoyerDemande(orcRequest, _processContext.getMsgId(), new MultivaluedHashMap<String, String>()); //$NON-NLS-1$
    if ((orcEnvoyerReponse != null) && (orcEnvoyerReponse.getOrderId() != null))
    {
      RavelLogger.log(new SystemLogEvent(LogSeverity.DEBUG, _processContext.getMsgId(), "ORC response is OK")); //$NON-NLS-1$
    }
    else
    {
      RavelLogger.log(new SystemLogEvent(LogSeverity.DEBUG, _processContext.getMsgId(), "ORC response is KO")); //$NON-NLS-1$
    }

    _processContext.setState(P02_CommandePFIState.ENDED);
  }

  @Override
  protected void exitKOMetroLog(String s_p)
  {
    // Auto-generated method stub
  }

  @Override
  protected void startMetroLog()
  {
    // Auto-generated method stub
  }

  @Override
  protected void startProcess(IRavelRequest request) throws RavelException
  {
    setRetour(RetourFactory.createKO(IMegConsts.CAT10, IMegConsts.TRAITEMENT_ARRETE, IMegConsts.PROBLEME_INCONNU));
    _processContext.setMsgId(request.getMsgId());
    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();

    RavelLogger.log(new SystemLogEvent(LogSeverity.DEBUG, request.getMsgId(), "Parsing request")); //$NON-NLS-1$
    Gson gson = TestUtils.getDefaultGson();
    // Read request
    CommandePFI commandePFI = gson.fromJson(request.getPayload(), CommandePFI.class);
    _processContext.setCommandePFI(commandePFI);
    String cliOpe = null;
    String source = null;
    for (RequestHeader header : request.getRequestHeader())
    {
      switch (header.getName())
      {
        case "X-CLIENT-OPERATEUR": //$NON-NLS-1$
          cliOpe = header.getValue();
          break;
        case X_SOURCE:
          source = header.getValue();
          break;
        default:
          break;
      }
    }

    if ((source != null) && !_cacheService.containsKey(source))
    {
      RavelLogger.log(new SystemLogEvent(LogSeverity.DEBUG, request.getMsgId(), "Found source header ; about to check services with SVC or local cache")); //$NON-NLS-1$

      // Call SVC to check services coherence with source
      MultivaluedMap<String, String> headers = new MultivaluedHashMap<>();
      headers.add(X_SOURCE, source);
      Reponse svcCheckResponse = ((SVCConnector) ConnectorManager.getInstance().getConnector("SVCConnector")).checkServices(commandePFI.getPortefeuilleServices().getServices(), request.getMsgId(), headers); //$NON-NLS-1$
      if ((svcCheckResponse.getErreur() != null) && !svcCheckResponse.getErreur().isEmpty())
      {
        RavelLogger.log(new SystemLogEvent(LogSeverity.ERROR, request.getMsgId(), "An error occured while calling SVC : process will return an error")); //$NON-NLS-1$
        response.setResult(gson.toJson(svcCheckResponse));
        request.setResponse(new Response(ErrorCode.KO_00409, response));
        setRetour(RetourFactory.createOkRetour());
        return;
      }

      // Add services for source in cache
      _cacheService.put(source, commandePFI.getPortefeuilleServices().getServices());
    }

    // Call CLI
    RavelLogger.log(new SystemLogEvent(LogSeverity.DEBUG, request.getMsgId(), "About to call CLI on check service")); //$NON-NLS-1$
    EtatCompte cliCheckRetour = ((CLIConnector) ConnectorManager.getInstance().getConnector("CLIConnector")).check(commandePFI.getPortefeuilleServices().getNoCompte(), request.getMsgId(), new MultivaluedHashMap<>()); //$NON-NLS-1$
    if (!"OK".equals(cliCheckRetour.getRetour().getResultat())) //$NON-NLS-1$
    {
      RavelLogger.log(new SystemLogEvent(LogSeverity.ERROR, request.getMsgId(), "An error occured while calling CLI : process will return an error")); //$NON-NLS-1$
      setRetour(RetourFactory.createKO(IMegConsts.CAT1, IMegConsts.TRAITEMENT_ARRETE, IMegConsts.REQUEST_ERROR));
      Reponse erreurCLI = new Reponse();
      erreurCLI.setErreur(cliCheckRetour.getRetour().getResultat());
      response.setResult(gson.toJson(erreurCLI));
      request.setResponse(new Response(ErrorCode.KO_00400, response));
      return;
    }

    // Call COM
    RavelLogger.log(new SystemLogEvent(LogSeverity.DEBUG, request.getMsgId(), "About to call COM on creer service")); //$NON-NLS-1$
    Commande creerCommande = new Commande();
    creerCommande.setIdCommande(UUID.randomUUID().toString());
    creerCommande.setDateCommande(commandePFI.getTimestamp());
    creerCommande.setClientOperateur(cliOpe);
    creerCommande.setNoCompte(commandePFI.getPortefeuilleServices().getNoCompte());
    creerCommande.setDateCreation(LocalDateTime.now());
    creerCommande.setStatut(Statut.ACQUITTE);
    _processContext.setCommande(creerCommande);
    Reponse comCreerReponse = ((COMConnector) ConnectorManager.getInstance().getConnector("COMConnector")).creer(creerCommande, request.getMsgId(), new MultivaluedHashMap<String, String>()); //$NON-NLS-1$

    // Return Async
    RavelLogger.log(new SystemLogEvent(LogSeverity.DEBUG, request.getMsgId(), "Preparing response and trigger async process handling")); //$NON-NLS-1$
    response.setResult(gson.toJson(comCreerReponse));
    if ((comCreerReponse.getErreur() != null) && !comCreerReponse.getErreur().isEmpty())
    {
      setRetour(RetourFactory.createKO(IMegConsts.CAT10, IMegConsts.TRAITEMENT_ARRETE, IMegConsts.ERREUR_TECHNIQUE));
      request.setResponse(new Response(ErrorCode.KO_00503, response));
    }
    else
    {
      setRetour(RetourFactory.createOkRetour());
      _processContext.setState(P02_CommandePFIState.LANCER_ORCHESTRATEUR);
      request.setResponse(new Response(ErrorCode.OK_00202, response));
    }
  }

}
