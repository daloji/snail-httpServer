/*******************************************************************************
 * $Id: ORCConnector.java 6719 2019-02-11 11:03:32Z jstrub $
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.ravel.training.connector;

import java.io.InputStream;

import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;

import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.utils.MarshallTools;
import com.bytel.ravel.services.connector.AbstractRESTConnector;
import com.bytel.ravel.services.connector.RESTRequest.RESTRequestBuilder;
import com.bytel.ravel.training.struct.orc.OrderRequest;
import com.bytel.ravel.training.struct.orc.OrderResponse;

/**
 *
 * @author jstrub
 * @version ($Revision: 6719 $ $Date: 2019-02-11 12:03:32 +0100 (lun., 11 févr. 2019) $)
 */
public class ORCConnector extends AbstractRESTConnector
{

  /** HTTP request PATH */
  private static final String ENVOYER_DEMANDE_PATH = "/orchestrator/order/start"; //$NON-NLS-1$

  /**
   * @param demande_p
   *          demande
   * @param msgId_p
   *          msgId
   * @param headers_p
   *          headers
   * @return call result
   * @throws RavelException
   *           on error
   */
  public OrderResponse envoyerDemande(OrderRequest demande_p, String msgId_p, MultivaluedMap<String, String> headers_p) throws RavelException
  {
    RESTRequestBuilder req = new RESTRequestBuilder().httpMethod("PUT").msgId(msgId_p).path(ENVOYER_DEMANDE_PATH); //$NON-NLS-1$
    req.headers(headers_p);
    req.request(MarshallTools.marshall(demande_p));

    Response httpResponse = super.send(req.build());
    return MarshallTools.unmarshall(OrderResponse.class, (InputStream) httpResponse.getEntity());
  }

  @Override
  public String getConfigParameter(String connectorID_p, String paramName_p) throws RavelException
  {
    return null;
  }

}
