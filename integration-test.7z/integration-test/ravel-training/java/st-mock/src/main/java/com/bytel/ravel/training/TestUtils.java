package com.bytel.ravel.training;

import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.utils.DateTimeTools.DateTimeFormatPattern;
import com.google.gson.Gson;

/**
 *
 * @author jstrub
 * @version ($Revision: 6719 $ $Date: 2019-02-11 12:03:32 +0100 (lun., 11 févr. 2019) $)
 */
public class TestUtils
{

  /**
   * @return Gson instance
   */
  public static Gson getDefaultGson()
  {
    return GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ, DateTimeFormatPattern.yyyy_dash_MM_dash_dd);
  }

  /**
   * Private constructor
   */
  private TestUtils()
  {
    // Nothing to do
  }
}
