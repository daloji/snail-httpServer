package com.bytel.ravel.training.connector;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;

import org.apache.commons.io.IOUtils;

import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.services.connector.AbstractRESTConnector;
import com.bytel.ravel.services.connector.RESTRequest.RESTRequestBuilder;
import com.bytel.ravel.training.TestUtils;
import com.bytel.ravel.training.struct.Reponse;
import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;

/**
 *
 * @author jstrub
 * @version ($Revision: 6719 $ $Date: 2019-02-11 12:03:32 +0100 (lun., 11 févr. 2019) $)
 */
public class SVCConnector extends AbstractRESTConnector
{

  /** HTTP request PATH */
  private static final String SERVICES_CHECK_PATH = "/services/check"; //$NON-NLS-1$

  /**
   * @param services_p
   *          services
   * @param msgId_p
   *          msgId
   * @param headers_p
   *          headers
   * @return call result
   * @throws RavelException
   *           on error
   */
  public Reponse checkServices(List<String> services_p, String msgId_p, MultivaluedMap<String, String> headers_p) throws RavelException
  {
    Gson gson = TestUtils.getDefaultGson();
    RESTRequestBuilder req = new RESTRequestBuilder().httpMethod("POST").msgId(msgId_p).path(SERVICES_CHECK_PATH); //$NON-NLS-1$
    req.headers(headers_p);
    req.request(gson.toJson(services_p));

    Response httpResponse = super.send(req.build());

    Reponse reponse;
    try
    {
      reponse = gson.fromJson(IOUtils.toString((InputStream) httpResponse.getEntity()), Reponse.class);
    }
    catch (JsonSyntaxException | IOException e)
    {
      throw new RavelException(ExceptionType.CONNECTOR_DATA_VALIDATION_ERROR, ErrorCode.CNCTOR_00010, "", e); //$NON-NLS-1$
    }

    return reponse;
  }

  @Override
  public String getConfigParameter(String connectorID_p, String paramName_p) throws RavelException
  {
    return null;
  }
}
