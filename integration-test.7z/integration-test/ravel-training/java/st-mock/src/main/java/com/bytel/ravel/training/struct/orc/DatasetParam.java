package com.bytel.ravel.training.struct.orc;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;

/**
 *
 * @author jstrub
 * @version ($Revision: 6719 $ $Date: 2019-02-11 12:03:32 +0100 (lun., 11 févr. 2019) $)
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DatasetParam", propOrder = { "name", "index", "value" })
public class DatasetParam implements Serializable
{

  /** */
  private final static long serialVersionUID = 100L;

  /** */
  @XmlElement(required = true)
  protected String name;
  /** */
  @XmlSchemaType(name = "unsignedInt")
  protected long index;
  /** */
  @XmlElement(required = true)
  protected String value;

  /**
   * Gets the value of the index property.
   *
   * @return the index
   */
  public long getIndex()
  {
    return index;
  }

  /**
   * Gets the value of the name property.
   *
   * @return possible object is {@link String }
   *
   */
  public String getName()
  {
    return name;
  }

  /**
   * Gets the value of the value property.
   *
   * @return possible object is {@link String }
   *
   */
  public String getValue()
  {
    return value;
  }

  /**
   * Sets the value of the index property.
   *
   * @param value
   *          the value
   */
  public void setIndex(long value)
  {
    index = value;
  }

  /**
   * Sets the value of the name property.
   *
   * @param value
   *          allowed object is {@link String }
   *
   */
  public void setName(String value)
  {
    name = value;
  }

  /**
   * Sets the value of the value property.
   *
   * @param value
   *          allowed object is {@link String }
   *
   */
  public void setValue(String value)
  {
    this.value = value;
  }

}
