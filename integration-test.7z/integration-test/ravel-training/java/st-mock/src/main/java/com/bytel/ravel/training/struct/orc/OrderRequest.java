package com.bytel.ravel.training.struct.orc;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

/**
 *
 * @author jstrub
 * @version ($Revision: 6719 $ $Date: 2019-02-11 12:03:32 +0100 (lun., 11 févr. 2019) $)
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = { "orderId", "domain", "verb", "customerId", "originator", "params" })
@XmlRootElement(name = "request")
public class OrderRequest implements Serializable
{

  /** */
  private final static long serialVersionUID = 100L;

  /** */
  @XmlElement(required = true)
  protected String orderId;
  /** */
  @XmlElement(required = true)
  protected String domain;
  /** */
  @XmlElement(required = true)
  protected String verb;
  /** */
  @XmlElement(required = true)
  protected String customerId;
  /** */
  @XmlElement(required = true)
  protected String originator;
  /** */
  @XmlElement(name = "param")
  protected List<DatasetParam> params;

  /**
   * @return the customerId
   */
  public String getCustomerId()
  {
    return customerId;
  }

  /**
   * @return the domain
   */
  public String getDomain()
  {
    return domain;
  }

  /**
   * @return the orderId
   */
  public String getOrderId()
  {
    return orderId;
  }

  /**
   * @return the originator
   */
  public String getOriginator()
  {
    return originator;
  }

  /**
   * @return the params
   */
  public List<DatasetParam> getParams()
  {
    if (params == null)
    {
      params = new ArrayList<>();
    }
    return params;
  }

  /**
   * @return the verb
   */
  public String getVerb()
  {
    return verb;
  }

  /**
   * @param customerId_p
   *          the customerId to set
   */
  public void setCustomerId(String customerId_p)
  {
    customerId = customerId_p;
  }

  /**
   * @param domain_p
   *          the domain to set
   */
  public void setDomain(String domain_p)
  {
    domain = domain_p;
  }

  /**
   * @param orderId_p
   *          the orderId to set
   */
  public void setOrderId(String orderId_p)
  {
    orderId = orderId_p;
  }

  /**
   * @param originator_p
   *          the originator to set
   */
  public void setOriginator(String originator_p)
  {
    originator = originator_p;
  }

  /**
   * @param params_p
   *          the params to set
   */
  public void setParams(List<DatasetParam> params_p)
  {
    params = params_p;
  }

  /**
   * @param verb_p
   *          the verb to set
   */
  public void setVerb(String verb_p)
  {
    verb = verb_p;
  }

}
