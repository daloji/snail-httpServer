package com.bytel.ravel.training.struct.cli;

import com.bytel.ravel.types.Retour;

/**
 *
 * @author jstrub
 * @version ($Revision: 6719 $ $Date: 2019-02-11 12:03:32 +0100 (lun., 11 févr. 2019) $)
 */
public class EtatCompte
{
  /** */
  private Retour retour;

  /**
   * @return the retour
   */
  public Retour getRetour()
  {
    return retour;
  }

  /**
   * @param retour_p
   *          the retour to set
   */
  public void setRetour(Retour retour_p)
  {
    retour = retour_p;
  }
}
