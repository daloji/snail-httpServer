package com.bytel.ravel.training.struct.cmd;

import java.time.LocalDateTime;

/**
 *
 * @author jstrub
 * @version ($Revision: 6719 $ $Date: 2019-02-11 12:03:32 +0100 (lun., 11 févr. 2019) $)
 */
public class Commande
{

  /** */
  private String idCommande;
  /** */
  private LocalDateTime dateCommande;
  /** */
  private String clientOperateur;
  /** */
  private Long noCompte;
  /** */
  private LocalDateTime dateCreation;
  /** */
  private Statut statut;

  /**
   * @return the clientOperateur
   */
  public String getClientOperateur()
  {
    return clientOperateur;
  }

  /**
   * @return the dateCommande
   */
  public LocalDateTime getDateCommande()
  {
    return dateCommande;
  }

  /**
   * @return the dateCreation
   */
  public LocalDateTime getDateCreation()
  {
    return dateCreation;
  }

  /**
   * @return the idCommande
   */
  public String getIdCommande()
  {
    return idCommande;
  }

  /**
   * @return the noCompte
   */
  public Long getNoCompte()
  {
    return noCompte;
  }

  /**
   * @return the statut
   */
  public Statut getStatut()
  {
    return statut;
  }

  /**
   * @param clientOperateur_p
   *          the clientOperateur to set
   */
  public void setClientOperateur(String clientOperateur_p)
  {
    clientOperateur = clientOperateur_p;
  }

  /**
   * @param dateCommande_p
   *          the dateCommande to set
   */
  public void setDateCommande(LocalDateTime dateCommande_p)
  {
    dateCommande = dateCommande_p;
  }

  /**
   * @param dateCreation_p
   *          the dateCreation to set
   */
  public void setDateCreation(LocalDateTime dateCreation_p)
  {
    dateCreation = dateCreation_p;
  }

  /**
   * @param idCommande_p
   *          the idCommande to set
   */
  public void setIdCommande(String idCommande_p)
  {
    idCommande = idCommande_p;
  }

  /**
   * @param noCompte_p
   *          the noCompte to set
   */
  public void setNoCompte(Long noCompte_p)
  {
    noCompte = noCompte_p;
  }

  /**
   * @param statut_p
   *          the statut to set
   */
  public void setStatut(Statut statut_p)
  {
    statut = statut_p;
  }

}
