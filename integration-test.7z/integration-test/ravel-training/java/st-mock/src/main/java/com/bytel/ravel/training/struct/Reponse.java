package com.bytel.ravel.training.struct;

/**
 * @author jstrub
 *
 */
public class Reponse
{

  /** Erreur */
  private String erreur;
  /** Id Commande */
  private String idCommande;

  /**
   * @return the erreur
   */
  public String getErreur()
  {
    return erreur;
  }

  /**
   * @return the idCommande
   */
  public String getIdCommande()
  {
    return idCommande;
  }

  /**
   * @param erreur_p
   *          the erreur to set
   */
  public void setErreur(String erreur_p)
  {
    erreur = erreur_p;
  }

  /**
   * @param idCommande_p
   *          the idCommande to set
   */
  public void setIdCommande(String idCommande_p)
  {
    idCommande = idCommande_p;
  }

}
