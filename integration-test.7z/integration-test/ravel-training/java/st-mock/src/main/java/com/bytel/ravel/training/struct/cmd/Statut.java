package com.bytel.ravel.training.struct.cmd;

/**
 *
 * @author jstrub
 * @version ($Revision: 6719 $ $Date: 2019-02-11 12:03:32 +0100 (lun., 11 févr. 2019) $)
 */
public enum Statut
{
  /** */
  ACQUITTE,
  /** */
  EN_COURS,
  /** */
  REALISEE;
}
