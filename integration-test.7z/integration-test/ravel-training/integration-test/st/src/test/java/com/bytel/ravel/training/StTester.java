package com.bytel.ravel.training;

import com.bytel.ravel.embedded.jetty.JettyServer;

/**
 * Class with a main method to launch a local ST.
 *
 * @author jstrub
 */
public final class StTester
{
  /**
   * Main method.
   *
   * @param args
   *          main args
   * @throws Exception
   *           on error
   */
  @SuppressWarnings("nls")
  public static void main(String[] args) throws Exception
  {
    // Start the backend !
    JettyServer.main(new String[] { "./conf/stJetty.xml", "start" });
  }

  /** Private constructor. */
  private StTester()
  {
    // Nothing to do
  }
}
