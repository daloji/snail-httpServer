/*******************************************************************************
* $Id: FrontendTester.java 6719 2019-02-11 11:03:32Z jstrub $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.ravel.frontend;

import com.bytel.ravel.embedded.jetty.JettyServer;

/**
 *
 * @author jstrub
 * @version ($Revision: 6719 $ $Date: 2019-02-11 12:03:32 +0100 (lun., 11 févr. 2019) $)
 */
public class FrontendTester
{
  public static void main(String[] args) throws Exception
  {
    // Add this hosts to /etc/hosts
    // 127.0.0.1 host.docker.internal
    // 127.0.0.1 backend-tester
    // 127.0.0.1 frontend-tester
    JettyServer.main(new String[] { "./conf/frontJetty.xml", "start" });
  }
}
