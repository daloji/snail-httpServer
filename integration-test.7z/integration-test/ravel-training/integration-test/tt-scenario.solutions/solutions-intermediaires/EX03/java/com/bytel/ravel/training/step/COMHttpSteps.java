package com.bytel.ravel.training.step;

import com.bytel.ravel.RavelTestException;
import com.bytel.ravel.step.AbstractRavelHttpSteps;
import com.bytel.ravel.training.config.BouchonHttpConfig;
import com.consol.citrus.dsl.builder.HttpServerRequestActionBuilder;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

/**
 *
 * @author JSTRUB
 * @version ($Revision: 6719 $ $Date: 2019-02-11 12:03:32 +0100 (lun., 11 févr. 2019) $)
 */
public class COMHttpSteps extends AbstractRavelHttpSteps
{

  /** COM base path. */
  private static final String BASE_PATH = "COM"; //$NON-NLS-1$

  /** Transient expected COM server request. */
  private HttpServerRequestActionBuilder _serverRequest;
  /** Transient service. */
  private String _service;

  /**
   * Constructor
   */
  public COMHttpSteps()
  {
    super(BASE_PATH);
  }

  /**
   * COM responds an error
   *
   * @param statusCode_p
   *          the HTTP status code to respond
   */
  @Then("^COM responds an error ([0-9]+)$")
  public void errorResponseAction(Integer statusCode_p)
  {
    serverResponseAction(BouchonHttpConfig.COM_SERVER, statusCode_p, null);
  }

  /**
   * Expect COM request has given query param
   *
   * @param name_p
   *          the query param name
   * @param value_p
   *          the query param value
   */
  @And("^COM query param ([^=]+)=\"([^\"]+)\"$")
  public void expectQueryParam(String name_p, String value_p)
  {
    _serverRequest.queryParam(name_p, value_p);
  }

  /**
   * COM responds
   * 
   * @param template_p
   *          the template to respond with
   *
   */
  public void okResponseAction(String template_p)
  {

  }

  /**
   * Expect that COM receives a creer request.
   *
   * @param template_p
   *          the template to control
   * @throws RavelTestException
   *           on test setup error
   */
  public void receiveCreerRequest(String template_p) throws RavelTestException
  {

  }

  /**
   * Expect that COM receives a recherche request.
   *
   * @throws RavelTestException
   *           on test setup error
   */
  @When("^COM receives a recherche request$")
  public void receiveRechercheRequest() throws RavelTestException
  {
    _service = "recherche"; //$NON-NLS-1$
    _serverRequest = getDesigner().http().server(BouchonHttpConfig.COM_SERVER).receive().get("/order/find"); //$NON-NLS-1$
  }
}
