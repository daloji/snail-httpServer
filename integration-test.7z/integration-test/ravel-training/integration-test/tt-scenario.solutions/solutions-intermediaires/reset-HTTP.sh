#!/bin/bash

function showHelp(){
  echo "$0: -h (help) -r (reset exercice and stop) -l nn  (reset exercice to given level)"
  exit 0
}

# Parse arguments
reset=0
while getopts "h?rl:" o; do
  case "$o" in
  h)
    showHelp
    ;;
  r)
    reset=1
    ;;
  l)
    level=$OPTARG
     ;;
  esac
done

if [[ ! "$level" =~ ^[0-9]{1,2}$ ]] && [[ $reset == 0 ]]; then
  echo $level
  echo $reset
  showHelp
fi

# Look for directories
baseDir=$(dirname "$0")
exerciceDir=$(readlink -f "$baseDir/../../tt-scenario.exercices/src/test")

# Reset with svn the exercices folder 
echo "Reseting $exerciceDir"
rm -Rf "$exerciceDir"
svn update -q "$exerciceDir"
[ $reset -eq 1 ] && exit 0

# Copy solutions until desired level is reached
for e in $(seq -f "EX%02g" 1 $level); do
  if [ ! -d $e ]; then
    echo "The level $e doesn't exist !"
    exit 1
  fi

  echo "Copying solution for level HTTP.$e"
  rsync -r "$e/" "$exerciceDir/"
done

