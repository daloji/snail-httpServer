package com.bytel.ravel.training.step;

import org.springframework.core.io.ClassPathResource;

import com.bytel.ravel.step.AbstractRavelHttpSteps;
import com.bytel.ravel.training.config.BouchonHttpConfig;
import com.consol.citrus.dsl.builder.HttpServerRequestActionBuilder;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

/**
 *
 * @author JSTRUB
 * @version ($Revision: 6719 $ $Date: 2019-02-11 12:03:32 +0100 (lun., 11 févr. 2019) $)
 */
public class CLIHttpSteps extends AbstractRavelHttpSteps
{

  /** */
  private static final String CHECK_SERVICE = "check"; //$NON-NLS-1$
  /** CLI base path. */
  private static final String BASE_PATH = "CLI"; //$NON-NLS-1$

  /** Transient expected CLI server request. */
  private HttpServerRequestActionBuilder _serverRequest;

  /**
   * Constructor
   */
  public CLIHttpSteps()
  {
    super(BASE_PATH);
  }

  /**
   * CLI responds an error
   *
   * @param statusCode_p
   *          http status code
   * @param template_p
   *          relative template path
   */
  @When("^CLI responds an error ([0-9]+) with ([^\\s]+)$")
  public void errorResponseAction(Integer statusCode_p, String template_p)
  {
    ClassPathResource template = templateResource(CHECK_SERVICE, RESPONSE_DIR, template_p);
    serverResponseAction(BouchonHttpConfig.CLI_SERVER, statusCode_p, template);
  }

  /**
   * Expect request has given query param
   *
   * @param name_p
   *          query param name
   * @param value_p
   *          query param value
   */
  @And("^CLI query param ([^=]+)=\"([^\"]+)\"")
  public void expectQueryParam(String name_p, String value_p)
  {
    _serverRequest.queryParam(name_p, value_p);
  }

  /**
   * CLI responds an error
   *
   * @param template_p
   *          relative template path
   */
  @When("^CLI responds with ([^\\s]+)$")
  public void okResponseAction(String template_p)
  {
    ClassPathResource template = templateResource(CHECK_SERVICE, RESPONSE_DIR, template_p);
    serverResponseActionOK(BouchonHttpConfig.CLI_SERVER, template);
  }

  /**
   * Expect that CLI receives a check request.
   */
  @Then("^CLI receives a check request$")
  public void receiveCheckRequest()
  {
    _serverRequest = getDesigner().http().server(BouchonHttpConfig.CLI_SERVER).receive().get("/compte/check"); //$NON-NLS-1$
  }

}
