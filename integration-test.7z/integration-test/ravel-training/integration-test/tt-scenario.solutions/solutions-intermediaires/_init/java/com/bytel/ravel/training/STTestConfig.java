package com.bytel.ravel.training;

import org.junit.runner.RunWith;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

/**
 *
 * @author jstrub
 * @version ($Revision: 6719 $ $Date: 2019-02-11 12:03:32 +0100 (lun., 11 févr. 2019) $)
 */
@RunWith(Cucumber.class)
@CucumberOptions(
    // Strict
    strict = false,
    // Steps
    glue = { "com.consol.citrus.cucumber.step.designer.core", "com.bytel.ravel.step", "com.bytel.ravel.training.step" },
    // Plugins
    plugin = { "com.consol.citrus.cucumber.CitrusReporter" },
    // Features
    features = { "src/test/resources/features/" })
@Configuration
@ComponentScan({ "com.bytel.ravel", "com.bytel.ravel.training" })
public class STTestConfig
{
  // Nothing to implement here
}
