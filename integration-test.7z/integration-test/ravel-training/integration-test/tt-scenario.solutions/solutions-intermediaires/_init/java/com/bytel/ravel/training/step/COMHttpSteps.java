package com.bytel.ravel.training.step;

import com.bytel.ravel.RavelTestException;
import com.bytel.ravel.step.AbstractRavelHttpSteps;
import com.consol.citrus.dsl.builder.HttpServerRequestActionBuilder;

/**
 *
 * @author JSTRUB
 * @version ($Revision: 6719 $ $Date: 2019-02-11 12:03:32 +0100 (lun., 11 févr. 2019) $)
 */
public class COMHttpSteps extends AbstractRavelHttpSteps
{

  /** COM base path. */
  private static final String BASE_PATH = "COM"; //$NON-NLS-1$

  /** Transient expected COM server request. */
  private HttpServerRequestActionBuilder _serverRequest;
  /** Transient service. */
  private String _service;

  /**
   * Constructor
   */
  public COMHttpSteps()
  {
    super(BASE_PATH);
  }

  /**
   * COM responds an error
   *
   * @param statusCode_p
   *          the HTTP status code to respond
   */
  public void errorResponseAction(Integer statusCode_p)
  {

  }

  /**
   * Expect COM request has given query param
   *
   * @param name_p
   *          the query param name
   * @param value_p
   *          the query param value
   */
  public void expectQueryParam(String name_p, String value_p)
  {

  }

  /**
   * COM responds
   * 
   * @param template_p
   *          the template to respond with
   *
   */
  public void okResponseAction(String template_p)
  {

  }

  /**
   * Expect that COM receives a creer request.
   *
   * @param template_p
   *          the template to control
   * @throws RavelTestException
   *           on test setup error
   */
  public void receiveCreerRequest(String template_p) throws RavelTestException
  {

  }

  /**
   * Expect that COM receives a recherche request.
   *
   * @throws RavelTestException
   *           on test setup error
   */
  public void receiveRechercheRequest() throws RavelTestException
  {

  }
}
