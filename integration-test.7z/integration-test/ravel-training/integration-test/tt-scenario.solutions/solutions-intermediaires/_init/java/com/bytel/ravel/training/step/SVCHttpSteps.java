/*******************************************************************************
 * $Id: SVCHttpSteps.java 6719 2019-02-11 11:03:32Z jstrub $
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.ravel.training.step;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.bytel.ravel.step.AbstractRavelHttpSteps;
import com.bytel.ravel.training.config.BouchonHttpConfig;
import com.consol.citrus.endpoint.adapter.StaticResponseEndpointAdapter;

import cucumber.api.java.en.Given;

/**
 * SVC is simulated with static response as it is cached by Prof, so service call can't be predicted.
 *
 * @author JSTRUB
 * @version ($Revision: 6719 $ $Date: 2019-02-11 12:03:32 +0100 (lun., 11 févr. 2019) $)
 */
public class SVCHttpSteps extends AbstractRavelHttpSteps
{

  /** SVC base path. */
  private static final String SVC_BASE_PATH = "SVC"; //$NON-NLS-1$

  /** */
  @Autowired
  @Qualifier(BouchonHttpConfig.SVC_ENDPOINT_ADAPTER)
  private StaticResponseEndpointAdapter _svcStaticEndpoint;

  /**
   * Constructor
   */
  public SVCHttpSteps()
  {
    super(SVC_BASE_PATH);
  }

  /**
   * SVC static response for serviceCheck.
   *
   * @param template_p
   *          static response
   */
  @Given("^SVC will respond ([^\\s]+)$")
  public void simpleStaticResponse(String template_p)
  {
    _svcStaticEndpoint.setMessagePayloadResource(templateResource("serviceCheck", RESPONSE_DIR, template_p).getPath()); //$NON-NLS-1$
  }

}
