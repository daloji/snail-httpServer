package com.bytel.ravel.training.step;

import org.springframework.core.io.ClassPathResource;

import com.bytel.ravel.step.AbstractRavelHttpSteps;
import com.bytel.ravel.training.config.BouchonHttpConfig;
import com.consol.citrus.dsl.builder.HttpServerRequestActionBuilder;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

/**
 *
 * @author JSTRUB
 * @version ($Revision: 6719 $ $Date: 2019-02-11 12:03:32 +0100 (lun., 11 févr. 2019) $)
 */
public class ORCHttpSteps extends AbstractRavelHttpSteps
{

  /** */
  private static final String ENVOYER_DEMANDE_SERVICE = "envoyerDemande"; //$NON-NLS-1$
  /** ORC base path. */
  private static final String BASE_PATH = "ORC"; //$NON-NLS-1$

  /**
   * Constructor
   */
  public ORCHttpSteps()
  {
    super(BASE_PATH);
  }

  /**
   * ORC responds an error
   *
   * @param statusCode_p
   *          http status code
   * @param template_p
   *          relative template path
   */
  @When("^ORC responds an error ([0-9]+) with ([^\\s]+)$")
  public void errorResponseAction(Integer statusCode_p, String template_p)
  {
    ClassPathResource template = templateResource(ENVOYER_DEMANDE_SERVICE, RESPONSE_DIR, template_p);
    serverResponseAction(BouchonHttpConfig.ORC_SERVER, statusCode_p, template);
  }

  /**
   * ORC responds an error
   *
   * @param template_p
   *          relative template path
   */
  @When("^ORC responds with ([^\\s]+)$")
  public void okResponseAction(String template_p)
  {
    ClassPathResource template = templateResource(ENVOYER_DEMANDE_SERVICE, RESPONSE_DIR, template_p);
    serverResponseActionOK(BouchonHttpConfig.ORC_SERVER, template);
  }

  /**
   * Expect that ORC receives a envoyerDemande request.
   *
   * @param template
   *          the template
   */
  @Then("^ORC receives an envoyerDemande request with ([^\\s]+)$")
  public void receiveRequest(String template)
  {
    HttpServerRequestActionBuilder requestBuilder = getDesigner().http().server(BouchonHttpConfig.ORC_SERVER).receive().put("/orchestrator/order/start"); //$NON-NLS-1$
    requestBuilder.payload(templateResource(ENVOYER_DEMANDE_SERVICE, REQUEST_DIR, template));
  }

}
