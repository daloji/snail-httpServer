/*******************************************************************************
 * $Id: BouchonHttpConfig.java 6719 2019-02-11 11:03:32Z jstrub $
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.ravel.training.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;

import com.bytel.ravel.config.RavelHttpConfigUtil;
import com.consol.citrus.endpoint.adapter.StaticResponseEndpointAdapter;
import com.consol.citrus.http.server.HttpServer;
import com.consol.citrus.http.server.HttpServerBuilder;

/**
 *
 * @author jstrub
 * @version ($Revision: 6719 $ $Date: 2019-02-11 12:03:32 +0100 (lun., 11 févr. 2019) $)
 */
@Configuration
public class BouchonHttpConfig
{
  /**  */
  public static final String SVC_ENDPOINT_ADAPTER = "svcEndpointAdapter"; //$NON-NLS-1$
  /**  */
  public static final String CLI_SERVER = "CLI_SERVER"; //$NON-NLS-1$
  /**  */
  public static final String COM_SERVER = "COM_SERVER"; //$NON-NLS-1$
  /**  */
  public static final String ORC_SERVER = "ORC_SERVER"; //$NON-NLS-1$
  /** */
  public static final String SVC_SERVER = "SVC_SERVER"; //$NON-NLS-1$

  /** */
  @Value("${cli.host}")
  private String _cliHost;
  /** */
  @Value("${cli.port}")
  private Integer _cliPort;

  /** */
  @Value("${com.host}")
  private String _comHost;
  /** */
  @Value("${com.port}")
  private Integer _comPort;

  /** */
  @Value("${orc.host}")
  private String _orcHost;
  /** */
  @Value("${orc.port}")
  private Integer _orcPort;

  /** */
  @Value("${svc.host}")
  private String _svcHost;
  /** */
  @Value("${svc.port}")
  private Integer _svcPort;

  /**
   * Configure the CLI server
   *
   * @return the CLI server
   */
  @Bean(name = CLI_SERVER)
  public HttpServer cliServer()
  {
    return RavelHttpConfigUtil.initHttpServerBuilder(CLI_SERVER, _cliHost, _cliPort).build();
  }

  /**
   * Configure the COM server
   *
   * @return the COM server
   */
  @Bean(name = COM_SERVER)
  public HttpServer comServer()
  {
    return RavelHttpConfigUtil.initHttpServerBuilder(COM_SERVER, _comHost, _comPort).build();
  }

  /**
   * Configure the ORC server
   *
   * @return the ORC server
   */
  @Bean(name = ORC_SERVER)
  public HttpServer orcServer()
  {
    return ((HttpServerBuilder) RavelHttpConfigUtil.initHttpServerBuilder(ORC_SERVER, _orcHost, _orcPort)).timeout(10000).build();
  }

  /**
   * SVC is mock with a configurable static response : it's not part of the scenario.
   *
   * @return the SVC endpoint adapter
   */
  @Bean(name = SVC_ENDPOINT_ADAPTER)
  public StaticResponseEndpointAdapter svcEndpointAdapter()
  {
    return new StaticResponseEndpointAdapter();
  }

  /**
   * Configure the SVC server
   *
   * @return the SVC server
   */
  @Bean(name = SVC_SERVER)
  public HttpServer svcServer()
  {
    HttpServerBuilder serverBuilder = (HttpServerBuilder) RavelHttpConfigUtil.initHttpServerBuilder(SVC_SERVER, _svcHost, _svcPort);
    serverBuilder.defaultStatus(HttpStatus.OK);
    serverBuilder.endpointAdapter(svcEndpointAdapter());
    return serverBuilder.name(SVC_SERVER).build();
  }

}
