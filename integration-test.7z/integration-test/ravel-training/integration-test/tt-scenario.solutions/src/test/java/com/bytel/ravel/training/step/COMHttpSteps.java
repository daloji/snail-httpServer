package com.bytel.ravel.training.step;

import org.springframework.core.io.ClassPathResource;

import com.bytel.ravel.RavelTestException;
import com.bytel.ravel.step.AbstractRavelHttpSteps;
import com.bytel.ravel.training.config.BouchonHttpConfig;
import com.consol.citrus.dsl.builder.HttpServerActionBuilder.HttpServerReceiveActionBuilder;
import com.consol.citrus.dsl.builder.HttpServerRequestActionBuilder;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

/**
 *
 * @author JSTRUB
 * @version ($Revision: 6719 $ $Date: 2019-02-11 12:03:32 +0100 (lun., 11 févr. 2019) $)
 */
public class COMHttpSteps extends AbstractRavelHttpSteps
{

  /**
   * Private enum of COM services
   */
  @SuppressWarnings("nls")
  private enum Services
  {
    /** */
    CREER("creer", "/order/create"),
    /** */
    RECHERCHE("recherche", "/order/find");

    /**
     * Find a COM service by some key
     *
     * @param key
     *          the key
     * @return Service entry or null
     */
    public static Services fromKey(String key) {
      for (Services s : Services.values()) {
        if (s.key.equals(key))
        {
          return s;
        }
      }

      return null;
    }

    /** Key used in tests objects. */
    private final String key;
    /** HTTP Path. */
    private final String httpPath;

    /**
     * Private constructor
     *
     * @param key_p
     *          the key
     * @param httpPath_p
     *          the path
     */
    private Services(String key_p, String httpPath_p)
    {
      key = key_p;
      httpPath = httpPath_p;
    }

  }

  /** COM base path. */
  private static final String BASE_PATH = "COM"; //$NON-NLS-1$

  /** Transient expected COM server request. */
  private HttpServerRequestActionBuilder _serverRequest;
  /** Transient expected service. */
  private Services currentService;

  /**
   * Constructor
   */
  public COMHttpSteps()
  {
    super(BASE_PATH);
  }

  /**
   * COM responds an error
   *
   * @param statusCode_p
   *          http status code
   */
  @When("^COM responds an error ([0-9]+)$")
  public void errorResponseAction(Integer statusCode_p)
  {
    serverResponseAction(BouchonHttpConfig.COM_SERVER, statusCode_p, null);
  }

  /**
   * Expect request has given query param
   *
   * @param name_p
   *          query param name
   * @param value_p
   *          query param value
   */
  @And("^COM query param ([^=]+)=\"([^\"]+)\"")
  public void expectQueryParam(String name_p, String value_p)
  {
    _serverRequest.queryParam(name_p, value_p);
  }

  /**
   * COM responds an error
   *
   * @param template_p
   *          relative template path
   */
  @When("^COM responds with ([^\\s]+)$")
  public void okResponseAction(String template_p)
  {
    ClassPathResource template = templateResource(currentService.key, RESPONSE_DIR, template_p);
    serverResponseActionOK(BouchonHttpConfig.COM_SERVER, template);
  }

  /**
   * Expect that COM receives a request.
   *
   * @param serviceKey
   *          the key of the expected service call
   * @param unused
   *          unused param
   * @param template
   *          the expected template
   * @throws RavelTestException
   *           on test setup error
   */
  @Then("^COM receives a ([^\\s]+) request( with ([^\\s]+))?$")
  public void receiveRequest(String serviceKey, String unused, String template) throws RavelTestException
  {
    currentService = Services.fromKey(serviceKey);
    if (currentService == null)
    {
      throw new RavelTestException("Unknown COM service key"); //$NON-NLS-1$
    }
    HttpServerReceiveActionBuilder receiveActionBuilder = getDesigner().http().server(BouchonHttpConfig.COM_SERVER).receive();
    switch (currentService)
    {
      case RECHERCHE:
        _serverRequest = receiveActionBuilder.get(currentService.httpPath);
        break;
      case CREER:
        _serverRequest = receiveActionBuilder.post(currentService.httpPath);
        _serverRequest.payload(templateResource(currentService.key, REQUEST_DIR, template));
        break;

      default:
        break;
    }
  }

}
