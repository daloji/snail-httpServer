#!/bin/bash

dir=$(readlink -f $(dirname "$0"))
cd "$dir/../citrus-training/tools/target"
java -classpath citrus-training.tools-0.0.1-SNAPSHOT.jar:dependency/* com.bytel.citrustraining.tools.common.CitrusRunner
