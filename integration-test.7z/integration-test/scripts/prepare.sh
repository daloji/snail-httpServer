#!/bin/bash

dir=$(readlink -f $(dirname "$0"))
chmod +x $dir/*.sh

echo "working dir: $dir"
echo "log dir: $dir/logs"

if [ ! -d "$dir/logs" ]; then
	mkdir "$dir/logs"
fi

###################################
# Prepare tools
###################################
cd ../citrus-training/tools

echo "Compiling tools..."
mvn clean install > "$dir/logs/tools.compile" 2>&1

if [ "$?" != "0" ]; then
	echo "Erreur lors de la compilation des tools ! See $dir/logs/tools.compile"
	exit 1
else
	echo "done."
fi

echo "Getting tools dependencies..."
mvn dependency:copy-dependencies >> "$dir/logs/tools.compile" 2>&1

if [ "$?" != "0" ]; then
	echo "Erreur lors de la récupération des dépendances des tools ! See $dir/logs/tools.compile"
	exit 1
else
	echo "done."
fi
