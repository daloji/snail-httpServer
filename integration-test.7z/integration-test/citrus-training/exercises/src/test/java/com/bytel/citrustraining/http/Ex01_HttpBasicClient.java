/*******************************************************************************
* $Id: Ex01_HttpBasicClient.java 5381 2018-08-08 15:57:08Z vthibaul $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.citrustraining.http;

import org.junit.Test;

import com.consol.citrus.annotations.CitrusTest;
import com.consol.citrus.dsl.junit.JUnit4CitrusTestDesigner;

/**
 *
 * @author vithibau
 * @version ($Revision: 5381 $ $Date: 2018-08-08 17:57:08 +0200 (mer., 08 août 2018) $)
 */
public class Ex01_HttpBasicClient extends JUnit4CitrusTestDesigner
{
  @Test
  @CitrusTest
  public void BasicClient()
  {
  }
}
