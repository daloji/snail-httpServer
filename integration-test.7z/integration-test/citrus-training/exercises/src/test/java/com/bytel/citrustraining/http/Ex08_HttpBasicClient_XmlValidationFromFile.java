/*******************************************************************************
* $Id: Ex08_HttpBasicClient_XmlValidationFromFile.java 5387 2018-08-09 14:42:21Z vthibaul $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.citrustraining.http;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.consol.citrus.annotations.CitrusTest;
import com.consol.citrus.dsl.junit.JUnit4CitrusTestDesigner;
import com.consol.citrus.http.client.HttpClient;

/**
 *
 * @author vithibau
 * @version ($Revision: 5387 $ $Date: 2018-08-09 16:42:21 +0200 (jeu., 09 août 2018) $)
 */
public class Ex08_HttpBasicClient_XmlValidationFromFile extends JUnit4CitrusTestDesigner
{
  @Autowired
  HttpClient client;

  @SuppressWarnings("nls")
  @Test
  @CitrusTest
  public void BasicClient_XmlValidationFromFile()
  {
  }
}
