/*******************************************************************************
* $Id: BasicKnowledge.java 5381 2018-08-08 15:57:08Z vthibaul $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.citrustraining.common;

/**
 *
 * @author vithibau
 * @version ($Revision: 5381 $ $Date: 2018-08-08 17:57:08 +0200 (mer., 08 août 2018) $)
 */
public class BasicKnowledge
{
  public void MyFirstCitrusTest()
  {
    description("Un test doit TOUJOURS avoir une description en une phrase qui indique le but du test");
  }
}
