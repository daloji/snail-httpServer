/*******************************************************************************
* $Id: Ex05_HttpBasicClient_QueryParamsAndHeaders_EnvSetup.java 5400 2018-08-10 15:29:44Z vthibaul $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.citrustraining.tools.envsetups.http;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import com.bytel.citrustraining.tools.common.QueryParamExtractor;
import com.consol.citrus.annotations.CitrusResource;
import com.consol.citrus.annotations.CitrusTest;
import com.consol.citrus.dsl.junit.JUnit4CitrusTestDesigner;
import com.consol.citrus.dsl.runner.TestRunner;
import com.consol.citrus.http.server.HttpServer;

/**
 *
 * @author vithibau
 * @version ($Revision: 5400 $ $Date: 2018-08-10 17:29:44 +0200 (ven., 10 août 2018) $)
 */
public class Ex05_HttpBasicClient_QueryParamsAndHeaders_EnvSetup extends JUnit4CitrusTestDesigner
{
  @Autowired
  HttpServer server;

  @SuppressWarnings("nls")
  @Test
  @CitrusTest
  public void BasicClient_QueryParamsAndHeaders(@CitrusResource TestRunner runner)
  {
    http().server(server).receive().get() // Get server
        .queryParam("id", "01234") // Check id query param
        .validationCallback(new QueryParamExtractor("action", "actionParam")) // Store queryParam 'action' value in variable 'actionParam'
        .header("X-CallerId", "Spirit"); // Check caller id header

    echo("actionParam=${actionParam}"); // Echo query param 'action' value

    http().server(server).respond().status(HttpStatus.OK) // OK
        .header("X-ActionDone", "${actionParam}"); // Set header with retrieved query param value
  }
}
