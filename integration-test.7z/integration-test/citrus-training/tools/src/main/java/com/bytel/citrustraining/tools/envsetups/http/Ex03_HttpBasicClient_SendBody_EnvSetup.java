/*******************************************************************************
* $Id: Ex03_HttpBasicClient_SendBody_EnvSetup.java 5375 2018-08-08 13:03:56Z vthibaul $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.citrustraining.tools.envsetups.http;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import com.consol.citrus.annotations.CitrusTest;
import com.consol.citrus.dsl.junit.JUnit4CitrusTestDesigner;
import com.consol.citrus.http.server.HttpServer;

/**
 *
 * @author vithibau
 * @version ($Revision: 5375 $ $Date: 2018-08-08 15:03:56 +0200 (mer., 08 août 2018) $)
 */
public class Ex03_HttpBasicClient_SendBody_EnvSetup extends JUnit4CitrusTestDesigner
{
  @Autowired
  HttpServer server;

  @Test
  @CitrusTest
  public void BasicClient_Body()
  {
    http().server(server).receive().post();
    http().server(server).respond().status(HttpStatus.OK);
  }
}
