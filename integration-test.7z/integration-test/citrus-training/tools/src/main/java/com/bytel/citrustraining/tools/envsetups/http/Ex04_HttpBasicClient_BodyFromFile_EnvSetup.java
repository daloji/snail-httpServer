/*******************************************************************************
* $Id: Ex04_HttpBasicClient_BodyFromFile_EnvSetup.java 5375 2018-08-08 13:03:56Z vthibaul $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.citrustraining.tools.envsetups.http;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpStatus;

import com.consol.citrus.annotations.CitrusTest;
import com.consol.citrus.dsl.junit.JUnit4CitrusTestDesigner;
import com.consol.citrus.http.server.HttpServer;

/**
 *
 * @author vithibau
 * @version ($Revision: 5375 $ $Date: 2018-08-08 15:03:56 +0200 (mer., 08 août 2018) $)
 */
public class Ex04_HttpBasicClient_BodyFromFile_EnvSetup extends JUnit4CitrusTestDesigner
{
  @Autowired
  HttpServer server;

  @SuppressWarnings("nls")
  @Test
  @CitrusTest
  public void BasicClient_Body()
  {
    http().server(server).receive().post().payload(new ClassPathResource("http/Ex04_server_request.json"));
    http().server(server).respond().status(HttpStatus.OK).payload(new ClassPathResource("http/Ex04_server_response.json"));
  }
}
