/*******************************************************************************
* $Id: Ex07_HttpBasicClient_JsonValidationFromCode_EnvSetup.java 5400 2018-08-10 15:29:44Z vthibaul $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.citrustraining.tools.envsetups.http;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpStatus;

import com.consol.citrus.annotations.CitrusTest;
import com.consol.citrus.dsl.junit.JUnit4CitrusTestDesigner;
import com.consol.citrus.http.server.HttpServer;

/**
 *
 * @author vithibau
 * @version ($Revision: 5400 $ $Date: 2018-08-10 17:29:44 +0200 (ven., 10 août 2018) $)
 */
public class Ex07_HttpBasicClient_JsonValidationFromCode_EnvSetup extends JUnit4CitrusTestDesigner
{
  @Autowired
  HttpServer server;

  @SuppressWarnings("nls")
  @Test
  @CitrusTest
  public void BasicClient_JsonValidationFromFile()
  {
    http().server(server).receive().get();
    http().server(server).respond().status(HttpStatus.OK).payload(new ClassPathResource("http/Ex07_server_response.json"));
  }
}
