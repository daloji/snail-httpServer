/*******************************************************************************
* $Id: QueryParamExtractor.java 5401 2018-08-10 15:40:02Z vthibaul $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.citrustraining.tools.common;

import org.junit.Assert;

import com.consol.citrus.context.TestContext;
import com.consol.citrus.message.Message;
import com.consol.citrus.validation.callback.ValidationCallback;

/**
 *
 * @author vithibau
 * @version ($Revision: 5401 $ $Date: 2018-08-10 17:40:02 +0200 (ven., 10 août 2018) $)
 */
public class QueryParamExtractor implements ValidationCallback
{
  /**
   * The source query param name.
   */
  private String _paramName;
  /**
   * The destination citrus variable name.
   */
  private String _variableName;

  /**
   * Default constructor.
   *
   * @param paramName_p
   *          The source query param name
   * @param variableName_p
   *          The destination citrus variable name
   */
  public QueryParamExtractor(String paramName_p, String variableName_p)
  {
    _paramName = paramName_p;
    _variableName = variableName_p;
  }

  @Override
  public void validate(Message message_p, TestContext context_p)
  {
    String queryParams = message_p.getHeader("citrus_http_query_params").toString(); //$NON-NLS-1$
    String[] params = queryParams.split(","); //$NON-NLS-1$
    for (String param : params)
    {
      String[] split = param.split("=", 2); //$NON-NLS-1$
      if (_paramName.equals(split[0]))
      {
        context_p.setVariable(_variableName, split[1]);
        return;
      }
    }

    Assert.fail("Query parameter '" + _paramName + "' not found in: " + queryParams); //$NON-NLS-1$ //$NON-NLS-2$
  }
}
