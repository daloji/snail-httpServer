/*******************************************************************************
* $Id: CitrusRunner.java 5375 2018-08-08 13:03:56Z vthibaul $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.citrustraining.tools.common;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.TreeMap;

import org.junit.runner.JUnitCore;
import org.junit.runner.Request;
import org.junit.runner.Result;

import com.google.common.collect.ImmutableSet;
import com.google.common.reflect.ClassPath;
import com.google.common.reflect.ClassPath.ClassInfo;

/**
 * Class used to set up an environment for each exercise. Args are : 1. full name of citrus test class 2. citrus test
 * method
 *
 * @author vithibau
 * @version ($Revision: 5375 $ $Date: 2018-08-08 15:03:56 +0200 (mer., 08 août 2018) $)
 */
public class CitrusRunner
{
  private static final String ENV_SETUPS_PACKAGE = "com.bytel.citrustraining.tools.envsetups"; //$NON-NLS-1$

  private static String MENU_SEPARATOR = "==================================================="; //$NON-NLS-1$

  private static Scanner input = new Scanner(System.in);

  /**
   * Main function to set up an environment for each exercise.
   *
   * @param args
   *          program args.
   * @throws IOException
   */
  public static void main(String[] args) throws IOException
  {
    String className = null;
    if (args.length == 0)
    {
      // Research mode
      ClassInfo selectedClass = menu();
      if (selectedClass == null)
      {
        System.exit(0);
      }
      className = selectedClass.getName();
    }
    else if (args.length == 1)
    {
      className = args[0];
    }
    else
    {
      System.out.println("Usage: " + CitrusRunner.class.getCanonicalName() + " <citrus test class>"); //$NON-NLS-1$ //$NON-NLS-2$
      System.exit(1);
    }

    Request request;
    try
    {
      request = Request.aClass(Class.forName(className));
      Result result = new JUnitCore().run(request);
      System.out.println("Test successful: " + result.wasSuccessful()); //$NON-NLS-1$
      System.exit(0);
    }
    catch (Exception exception)
    {
      System.out.println("Error while running class=" + className + exception.getMessage()); //$NON-NLS-1$
      exception.printStackTrace();
      System.exit(2);
    }
  }

  /**
   * Show a list of exercices for a category.
   *
   * @param exercices
   * @return
   */
  private static Entry<String, TreeMap<String, ClassInfo>> categoryMenu(String title, TreeMap<String, TreeMap<String, ClassInfo>> envSetups)
  {
    ArrayList<Entry<String, TreeMap<String, ClassInfo>>> categories = new ArrayList<>();

    System.out.println(MENU_SEPARATOR);
    System.out.println(title);
    System.out.println(MENU_SEPARATOR);

    // Print menu
    int i = 1;
    for (Entry<String, TreeMap<String, ClassInfo>> category : envSetups.entrySet())
    {
      System.out.println(i++ + ". " + category.getKey()); //$NON-NLS-1$
      categories.add(category);
    }
    System.out.println(""); //$NON-NLS-1$
    System.out.println(i + ". exit"); //$NON-NLS-1$

    int selection = input.nextInt() - 1;
    if ((selection >= 0) && (selection < categories.size()))
    {
      return categories.get(selection);
    }
    return null;
  }

  /**
   * Show a list of exercices for a category.
   *
   * @param exercises
   * @return
   */
  private static ClassInfo exerciseMenu(String category, TreeMap<String, ClassInfo> exercises)
  {
    ArrayList<ClassInfo> classes = new ArrayList<>();

    System.out.println(MENU_SEPARATOR);
    System.out.println(category);
    System.out.println(MENU_SEPARATOR);

    // Print menu
    int i = 1;
    for (String clazz : exercises.keySet())
    {
      System.out.println(i++ + ". " + clazz.replace("_", " ").replace("EnvSetup", "")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
      classes.add(exercises.get(clazz));
    }
    System.out.println(""); //$NON-NLS-1$
    System.out.println(i + ". exit"); //$NON-NLS-1$

    int selection = input.nextInt() - 1;
    if ((selection >= 0) && (selection < classes.size()))
    {
      return classes.get(selection);
    }
    return null;
  }

  /**
   * @return
   * @throws IOException
   */
  private static ClassInfo menu() throws IOException
  {
    ClassLoader classloader = Thread.currentThread().getContextClassLoader();
    ClassPath classpath = ClassPath.from(classloader);
    ImmutableSet<ClassInfo> classesInPackage = classpath.getTopLevelClassesRecursive(ENV_SETUPS_PACKAGE);

    TreeMap<String, TreeMap<String, ClassInfo>> envSetups = new TreeMap<>();

    String currentCategory = ""; //$NON-NLS-1$
    for (ClassInfo classInfo : classesInPackage)
    {
      String shortName = classInfo.getName().replace(ENV_SETUPS_PACKAGE + ".", ""); //$NON-NLS-1$ //$NON-NLS-2$
      String[] split = shortName.split("\\."); //$NON-NLS-1$

      if (!envSetups.containsKey(split[0]))
      {
        currentCategory = split[0];
        TreeMap<String, ClassInfo> exercices = new TreeMap<>();
        envSetups.put(currentCategory, exercices);
      }
      envSetups.get(currentCategory).put(split[1], classInfo);
    }

    Entry<String, TreeMap<String, ClassInfo>> exercises = categoryMenu("Catégorie d'exercice", envSetups); //$NON-NLS-1$
    if (exercises == null)
    {
      return null;
    }
    else
    {
      return exerciseMenu(exercises.getKey(), exercises.getValue());
    }
  }
}
