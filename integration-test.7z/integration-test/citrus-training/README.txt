This project is incomplete on purpose.
It will not compile properly because it takes place in a training program during which the student fix the errors.
See project "solutions" to have the working equivalent module.