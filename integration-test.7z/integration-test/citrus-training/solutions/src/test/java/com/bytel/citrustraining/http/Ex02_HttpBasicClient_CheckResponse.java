/*******************************************************************************
* $Id: Ex02_HttpBasicClient_CheckResponse.java 5375 2018-08-08 13:03:56Z vthibaul $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.citrustraining.http;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import com.consol.citrus.annotations.CitrusTest;
import com.consol.citrus.dsl.junit.JUnit4CitrusTestDesigner;
import com.consol.citrus.http.client.HttpClient;

/**
 *
 * @author vithibau
 * @version ($Revision: 5375 $ $Date: 2018-08-08 15:03:56 +0200 (mer., 08 août 2018) $)
 */
public class Ex02_HttpBasicClient_CheckResponse extends JUnit4CitrusTestDesigner
{
  /**
   * Generic front client.
   */
  @Autowired
  HttpClient client;

  @SuppressWarnings("nls")
  @Test
  @CitrusTest
  public void BasicClient_SendBody()
  {
    description("Basic http client: simple GET and check response");

    http() // With http protocol
        .client(client) // use preconfigured client
        .send() //prepare for send request
        .get(); //send a get request

    http() // With http protocol
        .client(client) // use preconfigured client
        .receive() //prepare for a response request
        .response(HttpStatus.OK) // Check if response status is OK
        .payload("{\"response\":\"expected!\"}");// Check response with static string payload
  }
}
