/*******************************************************************************
* $Id: Ex01_HttpBasicClient.java 5400 2018-08-10 15:29:44Z vthibaul $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.citrustraining.http;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.consol.citrus.annotations.CitrusTest;
import com.consol.citrus.dsl.junit.JUnit4CitrusTestDesigner;
import com.consol.citrus.http.client.HttpClient;

/**
 *
 * @author vithibau
 * @version ($Revision: 5400 $ $Date: 2018-08-10 17:29:44 +0200 (ven., 10 août 2018) $)
 */
public class Ex01_HttpBasicClient extends JUnit4CitrusTestDesigner
{
  /**
   * Generic front client.
   */
  @Autowired
  HttpClient client;

  @Test
  @CitrusTest
  public void BasicClient()
  {
    description("Basic http client: simple GET");

    // To create client locally
    // HttpClient client = CitrusEndpoints.http().client().requestUrl("http://localhost:38123").build();

    http() // With http protocol
        .client(client)// use preconfigured client
        .send()//prepare for send request
        .get();//send a get request
  }
}
