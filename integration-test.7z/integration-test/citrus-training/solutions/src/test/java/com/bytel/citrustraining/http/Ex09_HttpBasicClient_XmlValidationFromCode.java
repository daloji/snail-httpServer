/*******************************************************************************
* $Id: Ex09_HttpBasicClient_XmlValidationFromCode.java 5400 2018-08-10 15:29:44Z vthibaul $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.citrustraining.http;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import com.consol.citrus.annotations.CitrusTest;
import com.consol.citrus.dsl.junit.JUnit4CitrusTestDesigner;
import com.consol.citrus.http.client.HttpClient;

/**
 *
 * @author vithibau
 * @version ($Revision: 5400 $ $Date: 2018-08-10 17:29:44 +0200 (ven., 10 août 2018) $)
 */
public class Ex09_HttpBasicClient_XmlValidationFromCode extends JUnit4CitrusTestDesigner
{
  /**
   * Generic front client.
   */
  @Autowired
  HttpClient client;

  @SuppressWarnings("nls")
  @Test
  @CitrusTest
  public void BasicClient_XmlValidationFromFile()
  {
    description("Basic http client and xml hanlding: use advanced xml validation from file");

    http() // With http protocol
        .client(client) // use preconfigured client
        .send() //prepare for send request
        .post(); //send a get request

    http() // With http protocol
        .client(client) // use preconfigured client
        .receive() //prepare for a response request
        .response(HttpStatus.OK) // Check if response status is OK
        // Validate Xml
        .validate("/root/id", "Ex09_response") // id
        .validate("/root/id/@comment", "With XPath validation, nodes order doesn't matter") // comment
        .validate("//mustExistButValueIgnored", "@ignore@") // mustExistButValueIgnored
        .validate("//greaterThan10", "@greaterThan(10)@") // greaterThan10
        .validate("/root/subObject1/onlyFormatCheck", "@matches('[0-9:\\. \\-]+')@") // subObject1.onlyFormatCheck
        .validate("//ignoreValueCase", "@equalsIgnoreCase('some chars are uppercase, but assert is case insensitive!')@"); // subObject1.ignoreValueCase
  }
}
