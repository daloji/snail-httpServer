/*******************************************************************************
* $Id: Ex03_HttpBasicClient_SendBody.java 5375 2018-08-08 13:03:56Z vthibaul $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.citrustraining.http;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.consol.citrus.annotations.CitrusTest;
import com.consol.citrus.dsl.junit.JUnit4CitrusTestDesigner;
import com.consol.citrus.http.client.HttpClient;

/**
 *
 * @author vithibau
 * @version ($Revision: 5375 $ $Date: 2018-08-08 15:03:56 +0200 (mer., 08 août 2018) $)
 */
public class Ex03_HttpBasicClient_SendBody extends JUnit4CitrusTestDesigner
{
  /**
   * Generic front client.
   */
  @Autowired
  HttpClient client;

  @Test
  @CitrusTest
  public void BasicClient_SendBody()
  {
    description("Basic http client with body: POST with json body");

    http() // With http protocol
        .client(client)// use preconfigured client
        .send()//prepare for send request
        .post()//send a post request
        .contentType("application/json")// define a custom content type for body
        .payload("{\"attributeName\":\"attributeValue\"}"); // set the custom body from static string
  }
}
