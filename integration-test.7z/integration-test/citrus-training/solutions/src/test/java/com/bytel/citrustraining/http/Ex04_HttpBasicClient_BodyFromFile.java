/*******************************************************************************
* $Id: Ex04_HttpBasicClient_BodyFromFile.java 5375 2018-08-08 13:03:56Z vthibaul $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.citrustraining.http;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpStatus;

import com.consol.citrus.annotations.CitrusTest;
import com.consol.citrus.dsl.junit.JUnit4CitrusTestDesigner;
import com.consol.citrus.http.client.HttpClient;

/**
 *
 * @author vithibau
 * @version ($Revision: 5375 $ $Date: 2018-08-08 15:03:56 +0200 (mer., 08 août 2018) $)
 */
public class Ex04_HttpBasicClient_BodyFromFile extends JUnit4CitrusTestDesigner
{
  /**
   * Generic front client.
   */
  @Autowired
  HttpClient client;

  @SuppressWarnings("nls")
  @Test
  @CitrusTest
  public void BasicClient_BodyFromFile()
  {
    description("Basic http client with body: POST with json body from file");

    http() // With http protocol
        .client(client) // use preconfigured client
        .send() // prepare for send request
        .post() // send a post request
        .contentType("application/json") // define a custom content type for body
        .payload(new ClassPathResource("http/Ex04_client_request.json")); // set the custom body from static string

    http() // With http protocol
        .client(client) // use preconfigured client
        .receive() //prepare for a response request
        .response(HttpStatus.OK) // Check if response status is OK
        .payload(new ClassPathResource("http/Ex04_client_response.json"));// Check response with static string payload
  }
}
