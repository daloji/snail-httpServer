/*******************************************************************************
* $Id: EndpointConfig.java 5217 2018-07-19 16:19:16Z vthibaul $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.citrustraining.http;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.consol.citrus.dsl.endpoint.CitrusEndpoints;
import com.consol.citrus.http.client.HttpClient;

/**
 *
 * @author vithibau
 * @version ($Revision: 5217 $ $Date: 2018-07-19 18:19:16 +0200 (jeu., 19 juil. 2018) $)
 */
@Configuration
public class EndpointConfig
{
  /**
   * Generic client
   *
   * @return the http client
   */
  @Bean
  public HttpClient client()
  {
    return CitrusEndpoints.http().client().requestUrl("http://localhost:38123").contentType("application/xml").defaultAcceptHeader(false).build(); //$NON-NLS-1$ //$NON-NLS-2$
  }
}
