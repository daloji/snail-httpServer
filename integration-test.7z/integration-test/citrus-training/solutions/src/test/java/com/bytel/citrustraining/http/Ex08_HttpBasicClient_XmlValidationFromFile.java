/*******************************************************************************
* $Id: Ex08_HttpBasicClient_XmlValidationFromFile.java 5375 2018-08-08 13:03:56Z vthibaul $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.citrustraining.http;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpStatus;

import com.consol.citrus.annotations.CitrusTest;
import com.consol.citrus.dsl.junit.JUnit4CitrusTestDesigner;
import com.consol.citrus.http.client.HttpClient;

/**
 *
 * @author vithibau
 * @version ($Revision: 5375 $ $Date: 2018-08-08 15:03:56 +0200 (mer., 08 août 2018) $)
 */
public class Ex08_HttpBasicClient_XmlValidationFromFile extends JUnit4CitrusTestDesigner
{
  /**
   * Generic front client.
   */
  @Autowired
  HttpClient client;

  @SuppressWarnings("nls")
  @Test
  @CitrusTest
  public void BasicClient_XmlValidationFromFile()
  {
    description("Basic http client and xml hanlding: use advanced xml validation from file");

    http() // With http protocol
        .client(client) // use preconfigured client
        .send() //prepare for send request
        .post(); //send a get request

    http() // With http protocol
        .client(client) // use preconfigured client
        .receive() //prepare for a response request
        .response(HttpStatus.OK) // Check if response status is OK
        .payload(new ClassPathResource("http/Ex08_client_response.xml")); // Check payload
  }
}
