/*******************************************************************************
* $Id: Ex05_HttpBasicClient_QueryParamsAndHeaders.java 5400 2018-08-10 15:29:44Z vthibaul $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.citrustraining.http;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import com.consol.citrus.annotations.CitrusTest;
import com.consol.citrus.dsl.junit.JUnit4CitrusTestDesigner;
import com.consol.citrus.http.client.HttpClient;

/**
 *
 * @author vithibau
 * @version ($Revision: 5400 $ $Date: 2018-08-10 17:29:44 +0200 (ven., 10 août 2018) $)
 */
public class Ex05_HttpBasicClient_QueryParamsAndHeaders extends JUnit4CitrusTestDesigner
{
  /**
   * Generic front client.
   */
  @Autowired
  HttpClient client;

  @SuppressWarnings("nls")
  @Test
  @CitrusTest
  public void BasicClient_QueryParamsAndHeaders()
  {
    description("Basic http client with query params and headers: simple GET with query params and check headers");

    http() // With http protocol
        .client(client) // use preconfigured client
        .send() //prepare for send request
        .get() //send a get request
        .queryParam("id", "01234") // Set a query param
        .queryParam("action", "Activate") // Set a second query param
        .header("X-CallerId", "Spirit"); // Set a header

    http() // With http protocol
        .client(client) // use preconfigured client
        .receive() //prepare for a response request
        .response(HttpStatus.OK) // Check if response status is OK
        .header("X-ActionDone", "Activate"); // Check a header. The value must be the same as query param2 of request
  }
}
