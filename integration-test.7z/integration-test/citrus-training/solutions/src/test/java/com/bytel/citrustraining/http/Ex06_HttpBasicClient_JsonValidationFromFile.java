/*******************************************************************************
* $Id: Ex06_HttpBasicClient_JsonValidationFromFile.java 5400 2018-08-10 15:29:44Z vthibaul $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.citrustraining.http;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpStatus;

import com.consol.citrus.annotations.CitrusTest;
import com.consol.citrus.dsl.junit.JUnit4CitrusTestDesigner;
import com.consol.citrus.http.client.HttpClient;

/**
 *
 * @author vithibau
 * @version ($Revision: 5400 $ $Date: 2018-08-10 17:29:44 +0200 (ven., 10 août 2018) $)
 */
public class Ex06_HttpBasicClient_JsonValidationFromFile extends JUnit4CitrusTestDesigner
{
  /**
   * Generic front client.
   */
  @Autowired
  HttpClient client;

  @SuppressWarnings("nls")
  @Test
  @CitrusTest
  public void BasicClient_JsonValidationFromFile()
  {
    description("Basic http client and json hanlding: use advanced json validation from file");

    http() // With http protocol
        .client(client) // use preconfigured client
        .send() //prepare for send request
        .get(); //send a get request

    http() // With http protocol
        .client(client) // use preconfigured client
        .receive() //prepare for a response request
        .response(HttpStatus.OK) // Check if response status is OK
        .payload(new ClassPathResource("http/Ex06_client_response.json")); // Check payload
  }
}
