/*******************************************************************************
* $Id: BasicKnowledge.java 5217 2018-07-19 16:19:16Z vthibaul $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.citrustraining.common;

import org.junit.Test;

import com.consol.citrus.annotations.CitrusTest;
import com.consol.citrus.dsl.junit.JUnit4CitrusTestDesigner;

/**
 *
 * @author vithibau
 * @version ($Revision: 5217 $ $Date: 2018-07-19 18:19:16 +0200 (jeu., 19 juil. 2018) $)
 */
public class BasicKnowledge extends JUnit4CitrusTestDesigner
{
  @Test
  @CitrusTest
  public void MyFirstCitrusTest()
  {
    description("Un test doit TOUJOURS avoir une description en une phrase qui indique le but du test");
  }
}
