package com.bytel.spirit.tesla.test;

import com.bytel.ravel.embedded.jetty.JettyServer;

/**
 * Class with a main method to launch a local tesla.
 *
 * @author jstrub
 */
public final class TeslaTester
{
  /**
   * Main method.
   *
   * @param args
   *          main args
   * @throws Exception
   *           on error
   */
  @SuppressWarnings("nls")
  public static void main(String[] args) throws Exception
  {
    // Resources directory
    String confDir = "conf/";

    // System properties used by Spirit
    System.setProperty("configSpiritBackendDir", confDir);
    System.setProperty("supervisionSpiritBackendDir", "logs/");

    // Start the backend !
    JettyServer.main(new String[] { confDir + "teslaJetty.xml", "start" });
  }

  /** Private constructor. */
  private TeslaTester()
  {
    // Nothing to do
  }
}
