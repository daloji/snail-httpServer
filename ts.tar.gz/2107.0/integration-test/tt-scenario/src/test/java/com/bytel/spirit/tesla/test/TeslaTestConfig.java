package com.bytel.spirit.tesla.test;

import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.dsl.IntegrationFlow;

import com.bytel.ravel.config.RavelAMQPConfig;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

/**
 *
 * @author jstrub
 * @version ($Revision: 52358 $ $Date: 2021-05-21 11:29:05 +0200 (ven. 21 mai 2021) $)
 */
@RunWith(Cucumber.class)
@CucumberOptions(
    // Strict
    strict = true,
    // Steps
    glue = { "com.consol.citrus.cucumber.step.designer.core", "com.bytel.ravel.step", "com.bytel.spirit.common.test.step" },
    // Plugins
    plugin = { "com.consol.citrus.cucumber.CitrusReporter" },
    // Features
    features = { "src/test/resources/features/" })
@Configuration
@ComponentScan({ "com.bytel.ravel", "com.bytel.spirit.common.test" })
public class TeslaTestConfig
{
  /** Ravel's HTTP Config. */
  @Autowired
  private RavelAMQPConfig _ravelAMQPConfig;

  /**
   * AMQP Queue1
   */
  @Value("${tesla.amqp.queue1}")
  private String _queue1;

  /**
   * Configure AMQP QUEUE 1
   */
  @Bean(name = "AMQP_PublierEvenementFinProv")
  public IntegrationFlow initAMQPQueue1()
  {
    return _ravelAMQPConfig.initAMQPInboundFlow(_queue1);
  }
}
