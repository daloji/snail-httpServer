SPECIALIST="tesla"

## Information message
echo "About to start Docker images for local debug session of TT"
echo "Please ensure that this script targets the Docker images that the $SPECIALIST specialist is expecting (from docker-compose-local.yml) :"
cat ./tt-scenario/src/main/resources/docker-compose-local.yml | grep "image:"

ORACLE_IMAGE=bt1svm33:5065/npbt/oracle-test:NPBTBASESCDN_74.1
RING_IMAGE=bt1svm33:5015/ring-test:2009.0.0-SNAPSHOT

echo ""
echo "Those we are now starting from this script : "
echo $ORACLE_IMAGE
echo $RING_IMAGE

# Start local docker images 
docker run --shm-size=1g --name=oracle -p1521:1521 -d $ORACLE_IMAGE
docker run -d -p9042:9042 --name=ring $RING_IMAGE 
