# Cahier de Tests: PE0529_OperationVieReseau
## Nominal OK - POST

### Request:

```
POST http://10.136.132.71:8001/operations-vies-reseaux HTTP/1.1
Accept-Encoding: gzip,deflate
Content-Type: application/json;charset=UTF-8
X-Action-Id: X-Action-Id
X-Source: X-Source
X-Request-Id: X-Request-Id
X-Message-Id: X-Message-Id
X-Process: X-Process
Content-Length: 2590
Host: 10.136.132.71:8001
Connection: Keep-Alive
User-Agent: Apache-HttpClient/4.1.1 (java 1.5)

{
  "ajoutsPortsPm": [
    {
      "boitierPm": {
        "nomPmTechnique": "ABCD123",
        "referenceBoitierPm": "BOITIER_D"
      },
      "liensPortPon": [
        {
          "nomOLT": "777nomOlt",
          "positionCartePon": 2,
          "positionPortPon": 1
        }
      ],
      "panneauPm": {
        "nomPanneau": "PANNEAU_D"
      },
      "positionPortsPm": {
        "nomPanneau": "PANNEAU_B",
        "positionPort": 1,
        "referenceBoitierPm": "BOITIER_B",
        "referencePmBytel": "SI758074"
      }
    }
  ],
  "listeTypeEquipementImpacte": [
    "PM",
    "OLT"
  ],
  "migrationsPortsPm": [
    {
      "positionPortPmCible": {
        "nomPanneau": "B1-M1-MODULE-HZTL-BOUY",
        "positionPort": 1,
        "referenceBoitierPm": "BPI000010",
        "referencePmBytel": "SI758071"
      },
      "positionPortPmSource": {
        "nomPanneau": "B1-M1-MODULE-HZTL-BOUY",
        "positionPort": 1,
        "referenceBoitierPm": "BPI000010",
        "referencePmBytel": "SI758074"
      }
    }
  ],
  "modificationsPortsPm": [
    {
      "liensPortPonCible": [
        {
          "nomOLT": "777nomOlt",
          "positionCartePon": 2,
          "positionPortPon": 2
        }
      ],
      "liensPortPonSource": [
        {
          "nomOLT": "777nomOlt",
          "positionCartePon": 2,
          "positionPortPon": 1
        }
      ],
      "positionPortPm": {
        "nomPanneau": "B1-M1-MODULE-HZTL-BOUY",
        "positionPort": 1,
        "referenceBoitierPm": "BPI000010",
        "referencePmBytel": "SI758074"
      }
    }
  ],
  "modificationsPortsPon": [
    {
      "positionPortPon": {
        "nomOLT": "777nomOlt",
        "position": 2,
        "positionCarte": 2
      },
      "sfpListeTechnologieCompatible": [
        "XGPON"
      ]
    }
  ],
  "numeroGCR": "GCR-12345678",
  "suppressionsPortsPm": [
    {
      "positionPortsPm": [
        {
          "nomPanneau": "PANNEAU_E",
          "positionPort": 1,
          "referenceBoitierPm": "BOITIER_E",
          "referencePmBytel": "SI758074"
        }
      ]
    }
  ],
  "ajoutsPortsPon": [
    {
      "positionPortPon": {
        "position": "1",
        "positionCarte": "2",
        "nomOLT": "777nomOlt"
      },
      "sfpListeTechnologieCompatible": [
        "GPON",
        "XGPON"
      ],
      "maxOntId": "128",
      "referenceCableRenvoiNro": "R/DEG01",
      "codificationVolume": "EDANN2",
      "positionFoNro": "1/07/11/09",
      "cartePon": {
        "position": "3",
        "modeleCarte": "m2"
      }
    }
  ],
  "typeVieReseau": "PON128"
}
```

### Response:

```
HTTP/1.1 201 Created
Date: Wed, 17 Mar 2021 17:07:34 GMT
Content-Type: application/json
Server: Jetty(9.3.10.v20160621)
X-Request-Id-Spirit: 89e2dccd-d0f9-4041-9a00-8aa1ed3db651
Content-Length: 63

{"idOperationVieReseau":"8b75de58-4b5b-44d1-9df2-0a1c527714da"}
```

### Logs:

18:07:33.936|DEBUG|[qtp726950788-13] - MSG='Request ExecuteGenericRequest received from 10.42.99.135' MSGID='89e2dccd-d0f9-4041-9a00-8aa1ed3db651'
18:07:33.936|DEBUG|[qtp726950788-13] - MSG='LaunchProcess received.' MsgId='89e2dccd-d0f9-4041-9a00-8aa1ed3db651'
18:07:33.936|DEBUG|[qtp726950788-13] - MSG='Getting the process type for operation 'PE0529_OperationVieReseau'. '
18:07:33.936|DEBUG|[qtp726950788-13] - MSG='Getting a new process for operation 'PE0529_OperationVieReseau'.'
18:07:33.936|DEBUG|[qtp726950788-13] - MSG='Getting the process type for operation 'PE0529_OperationVieReseau'. '
18:07:33.936|DEBUG|[qtp726950788-13] - IdClient='null' IdProcess='9ae475ae98dc4865824b2ea6c7f2f4b6' MSG='START' MSGID='89e2dccd-d0f9-4041-9a00-8aa1ed3db651' ProcessName='PE0529_OperationVieReseau' Request='ObQ1oGI3f4Wmddh2uqth9RX7/8T18mnLaoWbCAxwGM9SXlbTAj8807gU6b/OEQ6TGlkKjghbzrhZLrV7a1U/Xj1V+S834cqOzkLkmN3dLELr+skWyBn8t+rdeSl0jbxBHFuQyGgE/BARNV2JMuVkIMPb2LNyAhJaatlboxhlvSe26a4WJc8QlbmAncWcBkQhnPXPGt9if9QyOduVH0BlEoEZKdCwJnMM5XJLMIIbDWywzMsJOA4XCPZxd1iXhHo7BsXVH/s0u16YrY9WbEbkuerdeSl0jbxBagFHTRwqn8KWAWuOGgg9ez+MDxVrltdw6H6nbKpk0OyL7RcdK3wT+5a15EApKIe7G7IeJcDcJq6dH5jlpT0svWUbG91P5b513qspimIo69S29ZqCDrCNXlM26xnb1d1N2qEqIzauFOZkiImYIYmjn6IKo2XDC89y/HXoXgjGlNNjah73vIqyHd6rKYpiKOvUI+ZUaxn779N4q2drjyMR5gAhG6PUTco/r1l/rG1qHMRFtpva63YNoAl0HciQqw3T+B512UtxwT7eqymKYijr1CPmVGsZ++/TlamQ15hRMSAbcantMrj2h4fIlNC0807+2a8EMRl5tydaETm4BemmN+lOUzhXvGpMiONeBW6rmVU7bSpFGVY2QYOT2ZnwOtldl/ezTy/ZzW8iFCcDEGrjovFhMlkotZlo2Rw0JX106ddD2VpvREShzFQI37gAncJV4ua2TolAq5UidwYygoG3Wr+Fh7pu0UKZtQ12J84h28z9yQ0VsCiSpXNAGDE7SmZDjtc/2O/GKpSzLaac/puOSFtneVTv0Ijf1HaVOUvWU5/eqymKYijr1CPmVGsZ++/Tqe5Y1Uixos+TXgutrWse2OrdeSl0jbxBuPA7pSeHcFkr3LzHtxuetgTUWj8/PNgHIgKrvR9mb4tIZgrNYdM1zOrdeSl0jbxBagFHTRwqn8JYg5zuJiYyv7mAncWcBkQheb94SuiLD5ET5VLLu4Ug2bgU6b/OEQ6TK88rO7Km0JMpso99kfREKhjPmRisqwXu3wR/DUQro+wvZL81s1m+1w9drsJsFQouPIs/TqQSiLMIsNqOIX+trLBGD67by8OqHSRdpFD+9tWn2KB8M5vLuVM26xnb1d1N2qEqIzauFOZkiImYIYmjn0L35CuesOz2gOJM1NL7Iye4k8m2TU6Yk2x3gYhLew9l1nTwOKw55x8FApMIH5YFte6HAPMxnrtt6H6nbKpk0Ox00I3X88QJJDBmNl0vdrMDRb11Sd2AbLEhQbp/c/dhf9W6kvVVExQ5OhmQp4qzfvLn3iQGBHIwF8UpExNqN1qg81UqG6IYMLBErjh8L6vO+kj24S6tPlTl3rF7j80AaIeZMU9sYjnUkpCRYYfbS+8K3vD/4khTWkqTEbPssbRQ/OEvCKNx8GCiamvwh7l8Sm81hY9gDAecDLbkX6D1EyE33e4P04AIF+TofqdsqmTQ7BhGi2cC9JkgZoPJ6pr35FilsLuc2DVfDeh+p2yqZNDsO6tPjY3SIBxt7NUbx757r4I7cyDUCtFh6H6nbKpk0OzCMcP/ymPYO7/2T8ApMNvrZqfI2M3HSkB4iin5pfdAp2et1LifmSgHuYCdxZwGRCGc9c8a32J/1H45JDIZsFZK0DyWioP+WO/ofqdsqmTQ7BpZCo4IW864ss/oAA1fdFnH803VnO6D8zC5O2KkcYcs1bqS9VUTFDnWdPA4rDnnHx6E8iq4AKJfmXqh1Omd4Xrt8V7t7WwZyN6rKYpiKOvUI+ZUaxn779OKNrLCuUL7XwD/HpEBP7mrCxC4t+j+NXoqfs+qETG4DaBG/iKTOykfqCAq+J71kLaM+HjMPEo/O+h+p2yqZNDspwfMvvXWp8DEDYa3PBcZOTlJI2A+a6yyTyxWKSkUM0Ti13r+D80DM+h+p2yqZNDsi+0XHSt8E/vAx5c7d4ejtSuCfFkSkxTXOhmQp4qzfvI8RbJGLkcci0YeJSboGdngUJx2kDI4ayltM0iUUyJ0s9OCtD4SQVJ6DjhpjEkqKyYphTSQbBUJL/cU1/tnmyCMhar/BwHBRg4LELi36P41essf0kMO1xRn+O0RAPK4zOIcCF0Lfmple6izpDodgJz0VPc0MTgtJ1oAIRuj1E3KPzurT42N0iAc0aG9uYHS6RPOlEWVf4bOuLDMywk4DhcI9nF3WJeEejsGxdUf+zS7Xpitj1ZsRuS51nTwOKw55x/M7lDAdWmX1e3xXu3tbBnIoEb+IpM7KR+6xKMXQDrqlqIvPNTc3u4UY2oe97yKsh0U8gRJ3Eqix/9STS15eU6s/gpN+/eji8NsDvLP+d2Mbt2KVV4jUZx2G3Gp7TK49odH5pCOdvA6l2et1LifmSgHuMXCCLhNClNyMPmdKAw3IgFsAgTkGSbXyIh1byQPSd3MWk522kBpMxY/Vw4gpUNGLt5R6fCugPgySlNhf9abGtd4B7qhCpDW5XJLMIIbDWzCMcP/ymPYO1kzWGk/n1+4Ffv/xPXyactiL8Cok4DasBtxqe0yuPaHr1l/rG1qHMRFtpva63YNoAl0HciQqw3TZnjrpSKWP/TofqdsqmTQ7IvtFx0rfBP7wMeXO3eHo7UrgnxZEpMU1xjPmRisqwXui2mrJ3ilJLoVwyRS9B00Zch0zqJ6b3NSoLcvM5DrD8rofqdsqmTQ7Hm/eEroiw+Rg2KayZZibkFraRUhdAgRrXGKFGfaAuXoG3Gp7TK49oda88tgowN2lexr4jALCZzxQ9lab0REocyfw6LeLB3W4/+klYV+C+pztuRfoPUTITcaWQqOCFvOuIvtFx0rfBP7lrXkQCkoh7tTNusZ29XdTdZ08DisOecfzO5QwHVpl9VnuHa88629LN6rKYpiKOvU60sLPdWAFnvfyLCPzOLQjqPFMoU+xuJLss/oAA1fdFnH803VnO6D8zC5O2KkcYcsRK44fC+rzvqXbqAePfLc+0rypm+gaz9yHJz5PgkARe5P76arAmSHyyDmevR/k9iKtuRfoPUTITck3Qf39Ina255YLESY+A/GSvWnMIlcCB3zqE5dKYmkj0TmzfLaxZwS4ZhgCHAHJJACWkWui121ZRVlBPLWrZo5O20qRRlWNkGUxS8aOfvm2+l0sT5zzrOWp/fMazryYrdRHC0ybkP7abmAncWcBkQhxfteAA5+rPj+uAiwnaG+t1qG3TADI7IJMUreU+nu0/DeqymKYijr1BBSs9kiVpJw4xxeQ1Ii+FoCRHW5RXGwaGbKK2z5Ns/HMZVACAu0t/2Fb67tieJyiBtxqe0yuPaHO6tPjY3SIBxajVUKyr6zQLmAncWcBkQhnaWTASJ7HvqXQriV5L8KfzeKja+lkga2CXBHiOl7//iWTuttsyaJYMmj1GZE4pVu8HxK0r70XIVBZuu7WppEf8hhOD8/s0Iz'
18:07:33.937|DEBUG|[qtp726950788-13] - HTTP METHOD='POST' MSG='REST START PROCESS' MSGID='89e2dccd-d0f9-4041-9a00-8aa1ed3db651'
18:07:33.937|DEBUG|[qtp726950788-13] - MSG='RestApiProcessSkeleton : USER ROLES (  ) gotten from the request headers.' MSGID='89e2dccd-d0f9-4041-9a00-8aa1ed3db651'
18:07:33.937|DEBUG|[qtp726950788-13] - MSG='RestApiProcessSkeleton : USER SCOPES (  ) gotten from the request headers.' MSGID='89e2dccd-d0f9-4041-9a00-8aa1ed3db651'
18:07:33.937|INFO |qtp726950788-13|89e2dccd-d0f9-4041-9a00-8aa1ed3db651|PE0529_OperationVieReseau|9ae475ae98dc4865824b2ea6c7f2f4b6|PE0529_OperationVieReseau.startPostProcess|DEBUT_PROCESSUS|[X-Source=X-Source],[X-Request-Id=X-Request-Id],[X-Entry-URI=/operations-vies-reseaux],[X-Action-Id=X-Action-Id],[X-Message-Id=X-Message-Id],[X-Process=X-Process]
18:07:33.937|INFO |qtp726950788-13|89e2dccd-d0f9-4041-9a00-8aa1ed3db651|PE0529_OperationVieReseau|9ae475ae98dc4865824b2ea6c7f2f4b6|PE0529_OperationVieReseau.startPostProcess|REQUETE_RECUE Body='{
"ajoutsPortsPm": [
{
"boitierPm": {
"nomPmTechnique": "ABCD123",
"referenceBoitierPm": "BOITIER_D"
},
"liensPortPon": [
{
"nomOLT": "777nomOlt",
"positionCartePon": 2,
"positionPortPon": 1
}
],
"panneauPm": {
"nomPanneau": "PANNEAU_D"
},
"positionPortsPm": {
"nomPanneau": "PANNEAU_B",
"positionPort": 1,
"referenceBoitierPm": "BOITIER_B",
"referencePmBytel": "SI758074"
}
}
],
"listeTypeEquipementImpacte": [
"PM",
"OLT"
],
"migrationsPortsPm": [
{
"positionPortPmCible": {
"nomPanneau": "B1-M1-MODULE-HZTL-BOUY",
"positionPort": 1,
"referenceBoitierPm": "BPI000010",
"referencePmBytel": "SI758071"
},
"positionPortPmSource": {
"nomPanneau": "B1-M1-MODULE-HZTL-BOUY",
"positionPort": 1,
"referenceBoitierPm": "BPI000010",
"referencePmBytel": "SI758074"
}
}
],
"modificationsPortsPm": [
{
"liensPortPonCible": [
{
"nomOLT": "777nomOlt",
"positionCartePon": 2,
"positionPortPon": 2
}
],
"liensPortPonSource": [
{
"nomOLT": "777nomOlt",
"positionCartePon": 2,
"positionPortPon": 1
}
],
"positionPortPm": {
"nomPanneau": "B1-M1-MODULE-HZTL-BOUY",
"positionPort": 1,
"referenceBoitierPm": "BPI000010",
"referencePmBytel": "SI758074"
}
}
],
"modificationsPortsPon": [
{
"positionPortPon": {
"nomOLT": "777nomOlt",
"position": 2,
"positionCarte": 2
},
"sfpListeTechnologieCompatible": [
"XGPON"
]
}
],
"numeroGCR": "GCR-12345678",
"suppressionsPortsPm": [
{
"positionPortsPm": [
{
"nomPanneau": "PANNEAU_E",
"positionPort": 1,
"referenceBoitierPm": "BOITIER_E",
"referencePmBytel": "SI758074"
}
]
}
],
"ajoutsPortsPon": [
{
"positionPortPon": {
"position": "1",
"positionCarte": "2",
"nomOLT": "777nomOlt"
},
"sfpListeTechnologieCompatible": [
"GPON",
"XGPON"
],
"maxOntId": "128",
"referenceCableRenvoiNro": "R/DEG01",
"codificationVolume": "EDANN2",
"positionFoNro": "1/07/11/09",
"cartePon": {
"position": "3",
"modeleCarte": "m2"
}
}
],
"typeVieReseau": "PON128"
}' Headers='Accept: text/xml,X-Source: X-Source,X-Request-Id: X-Request-Id,User-Agent: Apache-HttpClient/4.1.1 (java 1.5),Connection: keep-alive,Host: SPIRIT-tesla-PRA-1:8080,Accept-Encoding: gzip,deflate,Pragma: no-cache,X-Entry-URI: /operations-vies-reseaux,X-Action-Id: X-Action-Id,Cache-Control: no-cache,X-Message-Id: X-Message-Id,X-Process: X-Process,Content-Length: 2590,Content-Type: application/json;charset=UTF-8'
18:07:33.937|DEBUG|qtp726950788-13|89e2dccd-d0f9-4041-9a00-8aa1ed3db651|PE0529_OperationVieReseau|9ae475ae98dc4865824b2ea6c7f2f4b6|PE0529_BL001_VerifierDonneesCreation|DEBUT_ACTIVITE|PE0529_BL001_VerifierDonneesCreation
18:07:34.014|DEBUG|qtp726950788-13|89e2dccd-d0f9-4041-9a00-8aa1ed3db651|PE0529_OperationVieReseau|9ae475ae98dc4865824b2ea6c7f2f4b6|PE0529_BL001_VerifierDonneesCreation|FIN_ACTIVITE|Retour[resultat=OK, categorie=<null>(default), diagnostic=<null>(default), libelle=<null>(default), activite=<null>(default)]
18:07:34.014|DEBUG|qtp726950788-13|89e2dccd-d0f9-4041-9a00-8aa1ed3db651|PE0529_OperationVieReseau|9ae475ae98dc4865824b2ea6c7f2f4b6|PE0529_BL100_CreerOperationVDR|DEBUT_ACTIVITE|PE0529_BL100_CreerOperationVDR
18:07:34.014|INFO |qtp726950788-13|89e2dccd-d0f9-4041-9a00-8aa1ed3db651|PE0529_OperationVieReseau|9ae475ae98dc4865824b2ea6c7f2f4b6|PE0529_BL100_CreerOperationVDR|REQUETE_EMISE|ressourceLireUn Headers='X-Oauth2-Habilit: SPIRIT_STARK,X-Request-Id: X-Request-Id,X-Request-Id-Spirit: 89e2dccd-d0f9-4041-9a00-8aa1ed3db651,X-Source: tesla,X-Process: PE0529_OperationVieReseau,X-Process-Id-Spirit: 9ae475ae98dc4865824b2ea6c7f2f4b6' Parameters='idRessource = SI758074||BOITIER_E||PANNEAU_E||1,typeRessource = PORT_PM'
18:07:34.014|DEBUG|qtp726950788-13|89e2dccd-d0f9-4041-9a00-8aa1ed3db651|PE0529_OperationVieReseau|9ae475ae98dc4865824b2ea6c7f2f4b6|PE0529_BL100_CreerOperationVDR|TECHNIQUE|AbstractInternalRESTConnector : URL (Name=RESConnectorURL0 AccesPoint=http://SPIRIT-saab-JPA-1:8080/ExecuteGenericRequestV2) gotten from the load balancer.
18:07:34.031|INFO |qtp726950788-13|89e2dccd-d0f9-4041-9a00-8aa1ed3db651|PE0529_OperationVieReseau|9ae475ae98dc4865824b2ea6c7f2f4b6|PE0529_BL100_CreerOperationVDR|REPONSE_RECUE|ressourceLireUn Body='{"retour":{"activite":"PAD3100_Ressource.startGetProcess","categorie":"CAT-4","diagnostic":"DONNEE_INCONNUE","libelle":"Ressource PORT_PM (idRessource=SI758074||BOITIER_E||PANNEAU_E||1) inconnu","resultat":"NOK"}}' HTTPCode='404' Headers='connection: close,content-type: application/json,Date: Wed, 17 Mar 2021 17:07:34 GMT,Server: Jetty(9.3.10.v20160621),Content-Type: application/json'
18:07:34.032|INFO |qtp726950788-13|89e2dccd-d0f9-4041-9a00-8aa1ed3db651|PE0529_OperationVieReseau|9ae475ae98dc4865824b2ea6c7f2f4b6|PE0529_BL100_CreerOperationVDR|REQUETE_EMISE|pmCompositeLireUnParReferencePmBytel Headers='X-Oauth2-Habilit: SPIRIT_STARK,X-Request-Id: X-Request-Id,X-Request-Id-Spirit: 89e2dccd-d0f9-4041-9a00-8aa1ed3db651,X-Source: tesla,X-Process: PE0529_OperationVieReseau,X-Process-Id-Spirit: 9ae475ae98dc4865824b2ea6c7f2f4b6' Parameters='referencePmBytel = SI758074'
18:07:34.032|DEBUG|qtp726950788-13|89e2dccd-d0f9-4041-9a00-8aa1ed3db651|PE0529_OperationVieReseau|9ae475ae98dc4865824b2ea6c7f2f4b6|PE0529_BL100_CreerOperationVDR|TECHNIQUE|AbstractInternalRESTConnector : URL (Name=RESConnectorURL0 AccesPoint=http://SPIRIT-saab-JPA-1:8080/ExecuteGenericRequestV2) gotten from the load balancer.
18:07:34.048|INFO |qtp726950788-13|89e2dccd-d0f9-4041-9a00-8aa1ed3db651|PE0529_OperationVieReseau|9ae475ae98dc4865824b2ea6c7f2f4b6|PE0529_BL100_CreerOperationVDR|REPONSE_RECUE|pmCompositeLireUnParReferencePmBytel Body='{"pmComposite":{"adressePM":{"accessible":"BAT-1 / ESC-1 / ETAGE-SOUS-SOL-01","autresInformations":"CLIENT","batiment":"A","codeAccesImmeuble":"Digicode + Clef facteur","codeAccesSousSol":"Clefs à lagence","codeImmeuble":"pas de digicode, pas de gardien.","codeInsee":"30042","codeLocal":"SOUS SOL","codePostal":"30140","commentairePm":"AdresseTemporaire","complement":"A","contactsImmeuble":"M Toto Titi 0101010101","contactsSyndic":"AGENCE DE LA HALLE AGENCE DE LA HALLE 01 01 01 01 01  ","coordonneePmx":"637443.56","coordonneePmy":"6885895.5","hexacle":"AD95566ZAB","infoObtentionCle":"M. TOTO 0101010101","localisation":"SRO-BPI-978742","nomVoie":"DANDUZE","numeroVoie":"1579","referenceConsultationNative":"YVFI_LOTZAPM_78160_20171110-YVFI01-Lot02","rivoli":"048A","typeProjectionGeographique":"RGF93","typeVoie":"ROUTE","typeZone":"ZMD","ville":"BOISSET-ET-GAUJAC"},"codeOperateurImmeuble":"SFRA","dateCreation":"2020-12-07T12:19:15.184+0100","dateDernierImport":"2021-02-23T10:28:19.168+0100","dateModification":"2021-02-23T10:28:19.168+0100","dateOuvertureCommerciale":"2020-12-12T00:00:00.000+0100","etatDeploiement":"OUVERT_COMMERCIALEMENT","listeBoitierPM":{"BPI000010":{"dateCreation":"2020-12-07T12:19:15.184+0100","dateModification":"2020-12-07T12:19:15.184+0100","listePanneauPM":{"B1-M1-MODULE-HZTL-BOUY":{"baie":"A_1","dateCreation":"2020-12-07T12:19:15.184+0100","dateModification":"2020-12-07T12:19:15.184+0100","face":1,"listePortPM":{"1":{"dateCreation":"2020-12-07T12:19:15.184+0100","dateModification":"2020-12-07T12:19:15.184+0100","listeLienPortPMPon":{"OLT0018_1_1":{"portPon":{"nomOLT":"OLT0018","positionCartePON":1,"positionPortPON":1},"statutDeploiement":"OPERATIONNEL"}},"nomCoupleur":"SPL-1*8-01-BOU","position":1,"statutTechnique":"OPERATIONNEL","surchargePortPM":{"statutBlocage":"INACTIF","statutExploitation":"OPERATIONNEL"}}},"nomPanneau":"B1-M1-MODULE-HZTL-BOUY","positionAlpha":"K","statutTechnique":"OPERATIONNEL","tiroir":"01"}},"nomPmTechnique":"PT 1505","referenceBoitierPm":"BPI000010","statutTechnique":"OPERATIONNEL","surchargeBoitierPM":{"commentaireBlocage":"blocage prise clients suite a operation vie reseau le 14:23:05.517Z","dateActivation":"2021-02-23T15:23:05.567+0100","statutBlocage":"ACTIF"}}},"modeFinancementPM":"COFI","operateurAdduction":"ZTD SFR","referencePmBytel":"SI758074","referencePmOi":"ABC-BPI-1234","referencePrestationPM":"VOFI-BOIL02","statutTechnique":"OPERATIONNEL","surchargePM":{"statutBlocage":"INACTIF"},"typeEmplacementPM":"PMI","typeIngenierie":"MonofibreZMD"},"retour":{"resultat":"OK"}}' HTTPCode='200' Headers='connection:close,content-type: application/json,Date: Wed, 17 Mar 2021 17:07:34 GMT,Server: Jetty(9.3.10.v20160621),Content-Type: application/json'
18:07:34.073|INFO |qtp726950788-13|89e2dccd-d0f9-4041-9a00-8aa1ed3db651|PE0529_OperationVieReseau|9ae475ae98dc4865824b2ea6c7f2f4b6|PE0529_BL100_CreerOperationVDR|REQUETE_EMISE|pmCompositeLireUnParReferencePmBytel Headers='X-Oauth2-Habilit: SPIRIT_STARK,X-Request-Id: X-Request-Id,X-Request-Id-Spirit: 89e2dccd-d0f9-4041-9a00-8aa1ed3db651,X-Source: tesla,X-Process: PE0529_OperationVieReseau,X-Process-Id-Spirit: 9ae475ae98dc4865824b2ea6c7f2f4b6' Parameters='referencePmBytel = SI758071'
18:07:34.074|DEBUG|qtp726950788-13|89e2dccd-d0f9-4041-9a00-8aa1ed3db651|PE0529_OperationVieReseau|9ae475ae98dc4865824b2ea6c7f2f4b6|PE0529_BL100_CreerOperationVDR|TECHNIQUE|AbstractInternalRESTConnector : URL (Name=RESConnectorURL0 AccesPoint=http://SPIRIT-saab-JPA-1:8080/ExecuteGenericRequestV2) gotten from the load balancer.
18:07:34.105|INFO |qtp726950788-13|89e2dccd-d0f9-4041-9a00-8aa1ed3db651|PE0529_OperationVieReseau|9ae475ae98dc4865824b2ea6c7f2f4b6|PE0529_BL100_CreerOperationVDR|REPONSE_RECUE|pmCompositeLireUnParReferencePmBytel Body='{"pmComposite":{"adressePM":{"accessible":"BAT-1 / ESC-1 / ETAGE-SOUS-SOL-01","autresInformations":"CLIENT","batiment":"A","codeAccesImmeuble":"Digicode + Clef facteur","codeAccesSousSol":"Clefs à lagence","codeImmeuble":"pas de digicode, pas de gardien.","codeInsee":"30042","codeLocal":"SOUS SOL","codePostal":"30140","commentairePm":"AdresseTemporaire","complement":"A","contactsImmeuble":"M Toto Titi 0101010101","contactsSyndic":"AGENCE DE LA HALLE AGENCE DE LA HALLE 01 01 01 01 01  ","coordonneePmx":"637443.56","coordonneePmy":"6885895.5","hexacle":"AD95566ZAB","infoObtentionCle":"M. TOTO 0101010101","localisation":"SRO-BPI-978742","nomVoie":"DANDUZE","numeroVoie":"1579","referenceConsultationNative":"YVFI_LOTZAPM_78160_20171110-YVFI01-Lot02","rivoli":"048A","typeProjectionGeographique":"RGF93","typeVoie":"ROUTE","typeZone":"ZMD","ville":"BOISSET-ET-GAUJAC"},"codeOperateurImmeuble":"SFRA","dateCreation":"2021-02-08T13:29:37.784+0100","dateDernierImport":"2021-02-08T13:29:37.784+0100","dateModification":"2021-02-08T13:29:37.784+0100","dateOuvertureCommerciale":"2020-12-12T00:00:00.000+0100","etatDeploiement":"OUVERT_COMMERCIALEMENT","listeBoitierPM":{"BPI000010":{"dateCreation":"2021-02-08T13:29:37.784+0100","dateModification":"2021-02-08T13:29:37.784+0100","listePanneauPM":{"B1-M1-MODULE-HZTL-BOUY":{"baie":"A_1","dateCreation":"2021-02-08T13:29:37.784+0100","dateModification":"2021-02-08T13:29:37.784+0100","face":1,"listePortPM":{"1":{"dateCreation":"2021-02-08T13:29:37.784+0100","dateModification":"2021-02-08T13:29:37.784+0100","listeLienPortPMPon":{"OLT0018_1_1":{"portPon":{"nomOLT":"OLT0018","positionCartePON":1,"positionPortPON":1},"statutDeploiement":"OPERATIONNEL"}},"nomCoupleur":"SPL-1*8-01-BOU","position":1,"statutTechnique":"OPERATIONNEL","surchargePortPM":{"statutBlocage":"INACTIF","statutExploitation":"OPERATIONNEL"}}},"nomPanneau":"B1-M1-MODULE-HZTL-BOUY","positionAlpha":"K","statutTechnique":"OPERATIONNEL","tiroir":"01"}},"nomPmTechnique":"PT 1505","referenceBoitierPm":"BPI000010","statutTechnique":"OPERATIONNEL","surchargeBoitierPM":{"statutBlocage":"INACTIF"}}},"modeFinancementPM":"COFI","operateurAdduction":"ZTD SFR","referencePmBytel":"SI758071","referencePmOi":"SRO-BPI-1523556","referencePrestationPM":"VOFI-BOIL02","statutTechnique":"OPERATIONNEL","surchargePM":{"statutBlocage":"INACTIF"},"typeEmplacementPM":"PME","typeIngenierie":"MonofibreZMD"},"retour":{"resultat":"OK"}}' HTTPCode='200' Headers='connection: close,content-type: application/json,Date: Wed, 17 Mar 2021 17:07:34 GMT,Server: Jetty(9.3.10.v20160621),Content-Type: application/json'
18:07:34.107|INFO |qtp726950788-13|89e2dccd-d0f9-4041-9a00-8aa1ed3db651|PE0529_OperationVieReseau|9ae475ae98dc4865824b2ea6c7f2f4b6|PE0529_BL100_CreerOperationVDR|REQUETE_EMISE|oltCompositeLireUn Headers='X-Oauth2-Habilit: SPIRIT_STARK,X-Request-Id: X-Request-Id,X-Request-Id-Spirit: 89e2dccd-d0f9-4041-9a00-8aa1ed3db651,X-Source: tesla,X-Process: PE0529_OperationVieReseau,X-Process-Id-Spirit: 9ae475ae98dc4865824b2ea6c7f2f4b6' Parameters='nomOLT = OLT0018'
18:07:34.107|DEBUG|qtp726950788-13|89e2dccd-d0f9-4041-9a00-8aa1ed3db651|PE0529_OperationVieReseau|9ae475ae98dc4865824b2ea6c7f2f4b6|PE0529_BL100_CreerOperationVDR|TECHNIQUE|AbstractInternalRESTConnector : URL (Name=RESConnectorURL0 AccesPoint=http://SPIRIT-saab-JPA-1:8080/ExecuteGenericRequestV2) gotten from the load balancer.
18:07:34.146|INFO |qtp726950788-13|89e2dccd-d0f9-4041-9a00-8aa1ed3db651|PE0529_OperationVieReseau|9ae475ae98dc4865824b2ea6c7f2f4b6|PE0529_BL100_CreerOperationVDR|REPONSE_RECUE|oltCompositeLireUn Body='{"oltComposite":{"constructeur":"NOKIA","dateCreation":"2018-12-28T17:03:23.422+0100","dateDernierImport":"2021-03-05T15:58:27.908+0100","dateModification":"2021-03-05T15:58:27.908+0100","ip":"10.10.10.10","listeCarteP2P":{"1":{"dateCreation":"2021-03-05T15:58:27.908+0100","dateModification":"2021-03-05T15:58:27.908+0100","listeCageP2P":{"1":{"listePortP2P":{"1":{"dateCreation":"2020-08-25T17:48:35.342+0200","dateModification":"2020-08-25T17:48:35.342+0200","position":1,"positionRelativeCarte":1,"statutTechnique":"OPERATIONNEL"},"2":{"dateCreation":"2020-08-25T17:48:35.342+0200","dateModification":"2020-08-25T17:48:35.342+0200","position":2,"positionRelativeCarte":2,"statutTechnique":"OPERATIONNEL"}},"position":1,"surchargeCageP2P":{"distanceMax":10,"statutBlocage":"INACTIF"}},"2":{"listePortP2P":{"3":{"dateCreation":"2020-08-25T17:48:35.342+0200","dateModification":"2020-08-25T17:48:35.342+0200","position":3,"positionRelativeCarte":3,"statutTechnique":"OPERATIONNEL"}},"position":2,"surchargeCageP2P":{"distanceMax":10,"statutBlocage":"INACTIF"}}},"modele":"NELT-B","position":1,"statutTechnique":"OPERATIONNEL","surchargeCarte":{"statutBlocage":"INACTIF"},"typeCarte":"CarteP2P"},"2":{"dateCreation":"2021-03-05T15:58:27.908+0100","dateModification":"2021-03-05T15:58:27.908+0100","listeCageP2P":{"1":{"listePortP2P":{"1":{"dateCreation":"2020-08-25T17:48:35.342+0200","dateModification":"2020-08-25T17:48:35.342+0200","position":1,"positionRelativeCarte":2,"statutTechnique":"OPERATIONNEL"},"2":{"dateCreation":"2020-08-25T17:48:35.342+0200","dateModification":"2020-08-25T17:48:35.342+0200","position":2,"positionRelativeCarte":3,"statutTechnique":"OPERATIONNEL"}},"position":1,"surchargeCageP2P":{"distanceMax":10,"statutBlocage":"INACTIF"}}},"modele":"OGHK","position":2,"statutTechnique":"OPERATIONNEL","surchargeCarte":{"statutBlocage":"INACTIF"},"typeCarte":"CarteP2P"}},"listeCartePON":{},"modele":"MA5800T","nomNR":"SI758078","nomOLT":"OLT0018","nomPointAncrageIP":"BOUCLE_COLLECTE_118","statutTechnique":"OPERATIONNEL","surchargeOLT":{"nomOmc":"OMC_APC","statutBlocage":"INACTIF","versionInterfaceEchange":"qos_convergee"}},"retour":{"resultat":"OK"}}' HTTPCode='200' Headers='connection: close,content-type: application/json,Date: Wed, 17 Mar 2021 17:07:34 GMT,Server: Jetty(9.3.10.v20160621),Content-Type: application/json'
18:07:34.153|INFO |qtp726950788-13|89e2dccd-d0f9-4041-9a00-8aa1ed3db651|PE0529_OperationVieReseau|9ae475ae98dc4865824b2ea6c7f2f4b6|PE0529_BL100_CreerOperationVDR|REQUETE_EMISE|oltCompositeLireUn Headers='X-Oauth2-Habilit: SPIRIT_STARK,X-Request-Id: X-Request-Id,X-Request-Id-Spirit: 89e2dccd-d0f9-4041-9a00-8aa1ed3db651,X-Source: tesla,X-Process: PE0529_OperationVieReseau,X-Process-Id-Spirit: 9ae475ae98dc4865824b2ea6c7f2f4b6' Parameters='nomOLT = 777nomOlt'
18:07:34.153|DEBUG|qtp726950788-13|89e2dccd-d0f9-4041-9a00-8aa1ed3db651|PE0529_OperationVieReseau|9ae475ae98dc4865824b2ea6c7f2f4b6|PE0529_BL100_CreerOperationVDR|TECHNIQUE|AbstractInternalRESTConnector : URL (Name=RESConnectorURL0 AccesPoint=http://SPIRIT-saab-JPA-1:8080/ExecuteGenericRequestV2) gotten from the load balancer.
18:07:34.169|INFO |qtp726950788-13|89e2dccd-d0f9-4041-9a00-8aa1ed3db651|PE0529_OperationVieReseau|9ae475ae98dc4865824b2ea6c7f2f4b6|PE0529_BL100_CreerOperationVDR|REPONSE_RECUE|oltCompositeLireUn Body='{"oltComposite":{"constructeur":"huawei","dateCreation":"2018-12-28T17:03:23.422+0100","dateDernierImport":"2018-12-31T10:57:23.279+0100","dateModification":"2018-12-28T17:05:00.099+0100","ip":"192.168.0.44","listeCarteP2P":{"1":{"listeCageP2P":{"16":{"dateCreation":"2019-12-17T11:44:27.240+0100","dateModification":"2019-12-17T11:44:27.241+0100","listePortP2P":{"1":{"dateCreation":"2020-08-25T17:48:35.342+0200","dateModification":"2020-08-25T17:48:35.342+0200","position":1,"positionRelativeCarte":1,"statutTechnique":"OPERATIONNEL"},"2":{"dateCreation":"2020-08-25T17:48:35.342+0200","dateModification":"2020-08-25T17:48:35.342+0200","position":2,"positionRelativeCarte":2,"statutTechnique":"OPERATIONNEL"}},"position":16,"statutTechnique":"OPERATIONNEL","surchargeCageP2P":{"commentaireBlocage":"commentaire","dateActivation":"2020-08-25T17:48:35.342+0200","distanceMax":100,"statutBlocage":"ACTIF"}},"1":{"listePortP2P":{},"position":1,"statutTechnique":"OPERATIONNEL","surchargeCageP2P":{"distanceMax":10,"statutBlocage":"INACTIF"}}},"modele":"m2","position":1,"statutTechnique":"OPERATIONNEL","surchargeCarte":{"commentaireBlocage":"blocage prise clients suite a operation vie reseau le 14:23:05.517Z","dateActivation":"2021-02-23T15:23:05.527+0100","statutBlocage":"ACTIF"},"typeCarte":"CarteP2P"}},"listeCartePON":{"2":{"dateCreation":"2020-12-03T10:50:30.659+0100","dateModification":"2020-12-03T10:50:30.659+0100","listePortPON":{"2":{"codificationVolume":"test","dateCreation":"2020-12-03T10:50:30.659+0100","dateModification":"2020-12-03T10:50:30.659+0100","listeOntId":{},"maxOntId":10,"position":2,"positionFoNro":"test","referenceCableRenvoi":"test","sfpListeTechnologieCompatible":[],"statutTechnique":"OPERATIONNEL","surchargePortPON":{"debitGarantieCapaciteAllouee":10,"listeTechnologieAutorisee":["GPON","XPON"],"statutBlocage":"INACTIF"}}},"modele":"m2","position":2,"statutTechnique":"OPERATIONNEL","surchargeCarte":{"commentaireBlocage":"blocage prise clients suite a operation vie reseau le 14:23:05.517Z","dateActivation":"2021-02-23T15:23:05.554+0100","statutBlocage":"ACTIF"},"typeCarte":"CartePON"}},"modele":"m1","nomNR":"nomNR","nomOLT":"777nomOlt","statutTechnique":"OPERATIONNEL","surchargeOLT":{"nomOmc":"OMC_NCE","statutBlocage":"INACTIF","versionInterfaceEchange":"qos_convergee"}},"retour":{"resultat":"OK"}}' HTTPCode='200' Headers='connection: close,content-type: application/json,Date: Wed, 17 Mar 2021 17:07:34 GMT,Server: Jetty(9.3.10.v20160621),Content-Type: application/json'
18:07:34.174|DEBUG|qtp726950788-13|89e2dccd-d0f9-4041-9a00-8aa1ed3db651|PE0529_OperationVieReseau|9ae475ae98dc4865824b2ea6c7f2f4b6|BL800_ObtenirSequence|DEBUT_ACTIVITE|BL800_ObtenirSequence
18:07:34.174|DEBUG|qtp726950788-13|89e2dccd-d0f9-4041-9a00-8aa1ed3db651|PE0529_OperationVieReseau|9ae475ae98dc4865824b2ea6c7f2f4b6|BL800_ObtenirSequence|TECHNIQUE|BL800_ObtenirSequence ObtenirSequence='ID_OPERATION_VIE_RESEAU'
18:07:34.174|DEBUG|qtp726950788-13|89e2dccd-d0f9-4041-9a00-8aa1ed3db651|PE0529_OperationVieReseau|9ae475ae98dc4865824b2ea6c7f2f4b6|BL800_ObtenirSequence|TECHNIQUE|BL800_ObtenirSequence retour='8b75de58-4b5b-44d1-9df2-0a1c527714da'
18:07:34.174|DEBUG|qtp726950788-13|89e2dccd-d0f9-4041-9a00-8aa1ed3db651|PE0529_OperationVieReseau|9ae475ae98dc4865824b2ea6c7f2f4b6|BL800_ObtenirSequence|FIN_ACTIVITE|Retour[resultat=OK, categorie=<null>(default), diagnostic=<null>(default), libelle=<null>(default), activite=<null>(default)]
18:07:34.180|INFO |qtp726950788-13|89e2dccd-d0f9-4041-9a00-8aa1ed3db651|PE0529_OperationVieReseau|9ae475ae98dc4865824b2ea6c7f2f4b6|PE0529_BL100_CreerOperationVDR|REQUETE_EMISE|operationVieReseauCreer Body='{"donneeBrute":"{\"ajoutsPortsPm\":[{\"boitierPm\":{\"nomPmTechnique\":\"ABCD123\",\"referenceBoitierPm\":\"BOITIER_D\"},\"liensPortPon\":[{\"nomOLT\":\"777nomOlt\",\"positionCartePon\":2,\"positionPortPon\":1}],\"panneauPm\":{\"nomPanneau\":\"PANNEAU_D\"},\"positionPortsPm\":{\"nomPanneau\":\"PANNEAU_B\",\"positionPort\":1,\"referenceBoitierPm\":\"BOITIER_B\",\"referencePmBytel\":\"SI758074\"}}],\"ajoutsPortsPon\":[{\"cartePon\":{\"modeleCarte\":\"m2\",\"position\":\"3\"},\"codificationVolume\":\"EDANN2\",\"maxOntId\":128,\"positionFoNro\":\"1/07/11/09\",\"positionPortPon\":{\"nomOLT\":\"777nomOlt\",\"position\":1,\"positionCarte\":2},\"referenceCableRenvoiNro\":\"R/DEG01\",\"sfpListeTechnologieCompatible\":[\"GPON\",\"XGPON\"]}],\"listeTypeEquipementImpacte\":[\"PM\",\"OLT\"],\"migrationsPortsPm\":[{\"positionPortPmCible\":{\"nomPanneau\":\"B1-M1-MODULE-HZTL-BOUY\",\"positionPort\":1,\"referenceBoitierPm\":\"BPI000010\",\"referencePmBytel\":\"SI758071\"},\"positionPortPmSource\":{\"nomPanneau\":\"B1-M1-MODULE-HZTL-BOUY\",\"positionPort\":1,\"referenceBoitierPm\":\"BPI000010\",\"referencePmBytel\":\"SI758074\"}}],\"modificationsPortsPm\":[{\"liensPortPonCible\":[{\"nomOLT\":\"777nomOlt\",\"positionCartePon\":2,\"positionPortPon\":2}],\"liensPortPonSource\":[{\"nomOLT\":\"777nomOlt\",\"positionCartePon\":2,\"positionPortPon\":1}],\"positionPortPm\":{\"nomPanneau\":\"B1-M1-MODULE-HZTL-BOUY\",\"positionPort\":1,\"referenceBoitierPm\":\"BPI000010\",\"referencePmBytel\":\"SI758074\"}}],\"modificationsPortsPon\":[{\"positionPortPon\":{\"nomOLT\":\"777nomOlt\",\"position\":2,\"positionCarte\":2},\"sfpListeTechnologieCompatible\":[\"XGPON\"]}],\"numeroGCR\":\"GCR-12345678\",\"suppressionsPortsPm\":[{\"positionPortsPm\":[{\"nomPanneau\":\"PANNEAU_E\",\"positionPort\":1,\"referenceBoitierPm\":\"BOITIER_E\",\"referencePmBytel\":\"SI758074\"}]}],\"typeVieReseau\":\"PON128\"}","idOperationVieReseau":"8b75de58-4b5b-44d1-9df2-0a1c527714da","numeroGCR":"GCR-12345678","statut":"ACQUITTE","typeOperationVieReseau":"PON128"}' Headers='X-Oauth2-Habilit: SPIRIT_STARK,Content-Type: application/json,X-Request-Id: X-Request-Id,X-Request-Id-Spirit: 89e2dccd-d0f9-4041-9a00-8aa1ed3db651,X-Source: tesla,X-Process: PE0529_OperationVieReseau,X-Process-Id-Spirit: 9ae475ae98dc4865824b2ea6c7f2f4b6'
18:07:34.180|DEBUG|qtp726950788-13|89e2dccd-d0f9-4041-9a00-8aa1ed3db651|PE0529_OperationVieReseau|9ae475ae98dc4865824b2ea6c7f2f4b6|PE0529_BL100_CreerOperationVDR|TECHNIQUE|AbstractInternalRESTConnector : URL (Name=REXConnectorURL0 AccesPoint=http://SPIRIT-saab-JPA-1:8080/ExecuteGenericRequestV2) gotten from the load balancer.
18:07:34.205|INFO |qtp726950788-13|89e2dccd-d0f9-4041-9a00-8aa1ed3db651|PE0529_OperationVieReseau|9ae475ae98dc4865824b2ea6c7f2f4b6|PE0529_BL100_CreerOperationVDR|REPONSE_RECUE|operationVieReseauCreer Body='{"retour":{"resultat":"OK"}}' HTTPCode='200' Headers='connection: close,content-type: application/json,Date: Wed, 17 Mar 2021 17:07:34 GMT,Server: Jetty(9.3.10.v20160621),Content-Type: application/json'
18:07:34.207|INFO |qtp726950788-13|89e2dccd-d0f9-4041-9a00-8aa1ed3db651|PE0529_OperationVieReseau|9ae475ae98dc4865824b2ea6c7f2f4b6|PE0529_BL100_CreerOperationVDR|REQUETE_EMISE|cleRechercheOperationVieReseauCreerListe Body='{"listeCleRechercheOperationVieReseau":[{"idOperationVieReseau":"8b75de58-4b5b-44d1-9df2-0a1c527714da","typeCle":"PM","typeOperationVieReseau":"PON128","valeurCle":"SI758074"},{"idOperationVieReseau":"8b75de58-4b5b-44d1-9df2-0a1c527714da","typeCle":"PM","typeOperationVieReseau":"PON128","valeurCle":"SI758071"},{"idOperationVieReseau":"8b75de58-4b5b-44d1-9df2-0a1c527714da","typeCle":"OLT","typeOperationVieReseau":"PON128","valeurCle":"777nomOlt"}]}' Headers='X-Oauth2-Habilit: SPIRIT_STARK,Content-Type: application/json,X-Request-Id: X-Request-Id,X-Request-Id-Spirit: 89e2dccd-d0f9-4041-9a00-8aa1ed3db651,X-Source: tesla,X-Process: PE0529_OperationVieReseau,X-Process-Id-Spirit: 9ae475ae98dc4865824b2ea6c7f2f4b6'
18:07:34.207|DEBUG|qtp726950788-13|89e2dccd-d0f9-4041-9a00-8aa1ed3db651|PE0529_OperationVieReseau|9ae475ae98dc4865824b2ea6c7f2f4b6|PE0529_BL100_CreerOperationVDR|TECHNIQUE|AbstractInternalRESTConnector : URL (Name=REXConnectorURL0 AccesPoint=http://SPIRIT-saab-JPA-1:8080/ExecuteGenericRequestV2) gotten from the load balancer.
18:07:34.225|INFO |qtp726950788-13|89e2dccd-d0f9-4041-9a00-8aa1ed3db651|PE0529_OperationVieReseau|9ae475ae98dc4865824b2ea6c7f2f4b6|PE0529_BL100_CreerOperationVDR|REPONSE_RECUE|cleRechercheOperationVieReseauCreerListe Body='{"retour":{"resultat":"OK"}}' HTTPCode='200' Headers='connection: close,content-type: application/json,Date: Wed, 17 Mar 2021 17:07:34 GMT,Server: Jetty(9.3.10.v20160621),Content-Type: application/json'
18:07:34.225|DEBUG|qtp726950788-13|89e2dccd-d0f9-4041-9a00-8aa1ed3db651|PE0529_OperationVieReseau|9ae475ae98dc4865824b2ea6c7f2f4b6|PE0529_BL100_CreerOperationVDR|FIN_ACTIVITE|Retour[resultat=OK, categorie=<null>(default), diagnostic=<null>(default), libelle=<null>(default), activite=<null>(default)]
18:07:34.225|DEBUG|qtp726950788-13|89e2dccd-d0f9-4041-9a00-8aa1ed3db651|PE0529_OperationVieReseau|9ae475ae98dc4865824b2ea6c7f2f4b6|PE0529_BL002_FormaterReponseCreation|DEBUT_ACTIVITE|PE0529_BL002_FormaterReponseCreation
18:07:34.225|DEBUG|qtp726950788-13|89e2dccd-d0f9-4041-9a00-8aa1ed3db651|PE0529_OperationVieReseau|9ae475ae98dc4865824b2ea6c7f2f4b6|PE0529_BL002_FormaterReponseCreation|FIN_ACTIVITE|Retour[resultat=OK, categorie=<null>(default), diagnostic=<null>(default), libelle=<null>(default), activite=<null>(default)]
18:07:34.225|INFO |qtp726950788-13|89e2dccd-d0f9-4041-9a00-8aa1ed3db651|PE0529_OperationVieReseau|9ae475ae98dc4865824b2ea6c7f2f4b6|PE0529_OperationVieReseau.startPostProcess|REPONSE_EMISE|{"idOperationVieReseau":"8b75de58-4b5b-44d1-9df2-0a1c527714da"}
18:07:34.225|INFO |qtp726950788-13|89e2dccd-d0f9-4041-9a00-8aa1ed3db651|PE0529_OperationVieReseau|9ae475ae98dc4865824b2ea6c7f2f4b6|PE0529_OperationVieReseau.startPostProcess|FIN_PROCESSUS|Retour[resultat=OK, categorie=<null>(default), diagnostic=<null>(default), libelle=<null>(default), activite=<null>(default)]
18:07:34.225|DEBUG|[qtp726950788-13] - IdProcess='9ae475ae98dc4865824b2ea6c7f2f4b6' MSG='END START' MSGID='89e2dccd-d0f9-4041-9a00-8aa1ed3db651' ProcessName='PE0529_OperationVieReseau' Request='WDxP1H9eDirFUKVcmqu7Rr19FLq3evX6s+NDalajG5qfi9oCAPSN+3k7AyfqfhuHlpYlJtj3x4nBjw59D5C/BA=='


## Nominal OK - PUT

### Request:

```
PUT http://10.136.132.71:8001/operations-vies-reseaux/8b75de58-4b5b-44d1-9df2-0a1c527714da/actions HTTP/1.1
Accept-Encoding: gzip,deflate
Content-Type: application/json;charset=UTF-8
X-Action-Id: X-Action-Id
X-Source: X-Source
X-Request-Id: X-Request-Id
X-Message-Id: X-Message-Id
X-Process: X-Process
Content-Length: 26
Host: 10.136.132.71:8001
Connection: Keep-Alive
User-Agent: Apache-HttpClient/4.1.1 (java 1.5)

{
  "action": "executer"
}
```

### Response:

```
HTTP/1.1 202 Accepted
Date: Wed, 17 Mar 2021 17:09:23 GMT
Content-Type: text/xml
Server: Jetty(9.3.10.v20160621)
X-Request-Id-Spirit: b3e53b13-a485-4ce9-93e0-83e02281b2c6
Content-Length: 0
```

### Logs:

18:09:23.380|DEBUG|[qtp726950788-18] - MSG='Request ExecuteGenericRequest received from 10.42.99.135' MSGID='b3e53b13-a485-4ce9-93e0-83e02281b2c6'
18:09:23.381|DEBUG|[qtp726950788-18] - MSG='LaunchProcess received.' MsgId='b3e53b13-a485-4ce9-93e0-83e02281b2c6'
18:09:23.381|DEBUG|[qtp726950788-18] - MSG='Getting the process type for operation 'PE0529_OperationVieReseau'. '
18:09:23.381|DEBUG|[qtp726950788-18] - MSG='Getting a new process for operation 'PE0529_OperationVieReseau'.'
18:09:23.381|DEBUG|[qtp726950788-18] - MSG='Getting the process type for operation 'PE0529_OperationVieReseau'. '
18:09:23.381|DEBUG|[qtp726950788-18] - IdClient='null' IdProcess='ec96ca4dc2724ce6ae1b9f3060c0fadd' MSG='START' MSGID='b3e53b13-a485-4ce9-93e0-83e02281b2c6' ProcessName='PE0529_OperationVieReseau' Request='aipwG3sp3ua5cmlwMW+dYNnZa1Th1s0X0E4ujAdYHzU='
18:09:23.381|DEBUG|[qtp726950788-18] - HTTP METHOD='PUT' MSG='REST START PROCESS' MSGID='b3e53b13-a485-4ce9-93e0-83e02281b2c6'
18:09:23.381|DEBUG|[qtp726950788-18] - MSG='RestApiProcessSkeleton : USER ROLES (  ) gotten from the request headers.' MSGID='b3e53b13-a485-4ce9-93e0-83e02281b2c6'
18:09:23.381|DEBUG|[qtp726950788-18] - MSG='RestApiProcessSkeleton : USER SCOPES (  ) gotten from the request headers.' MSGID='b3e53b13-a485-4ce9-93e0-83e02281b2c6'
18:09:23.381|INFO |qtp726950788-18|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_OperationVieReseau.startPutProcess|DEBUT_PROCESSUS|[X-Source=X-Source],[X-Request-Id=X-Request-Id],[X-Entry-URI=/operations-vies-reseaux/8b75de58-4b5b-44d1-9df2-0a1c527714da/actions],[X-Action-Id=X-Action-Id],[X-Message-Id=X-Message-Id],[X-Process=X-Process]
18:09:23.381|INFO |qtp726950788-18|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_OperationVieReseau.startPutProcess|REQUETE_RECUE Body='{
"action": "executer"
}' DynamicParameters='8b75de58-4b5b-44d1-9df2-0a1c527714da' Headers='Accept: text/xml,X-Source: X-Source,X-Request-Id: X-Request-Id,User-Agent: Apache-HttpClient/4.1.1 (java 1.5),Connection: keep-alive,Host: SPIRIT-tesla-PRA-1:8080,Accept-Encoding: gzip,deflate,Pragma: no-cache,X-Entry-URI: /operations-vies-reseaux/8b75de58-4b5b-44d1-9df2-0a1c527714da/actions,X-Action-Id: X-Action-Id,Cache-Control: no-cache,X-Message-Id: X-Message-Id,X-Process: X-Process,Content-Length: 26,Content-Type: application/json;charset=UTF-8'
18:09:23.381|DEBUG|qtp726950788-18|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL001_VerifierDonneesModification|DEBUT_ACTIVITE|PE0529_BL001_VerifierDonneesModification
18:09:23.388|DEBUG|qtp726950788-18|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL001_VerifierDonneesModification|FIN_ACTIVITE|Retour[resultat=OK, categorie=<null>(default), diagnostic=<null>(default), libelle=<null>(default), activite=<null>(default)]
18:09:23.389|DEBUG|qtp726950788-18|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL200_MajReferentiel|DEBUT_ACTIVITE|PE0529_BL200_MajReferentiel
18:09:23.389|INFO |qtp726950788-18|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL200_MajReferentiel|REQUETE_EMISE|operationVieReseauLireUn Headers='X-Oauth2-Habilit: SPIRIT_STARK,X-Request-Id: X-Request-Id,X-Request-Id-Spirit: b3e53b13-a485-4ce9-93e0-83e02281b2c6,X-Source: tesla,X-Process: PE0529_OperationVieReseau,X-Process-Id-Spirit: ec96ca4dc2724ce6ae1b9f3060c0fadd' Parameters='idOperationVieReseau = 8b75de58-4b5b-44d1-9df2-0a1c527714da'
18:09:23.389|DEBUG|qtp726950788-18|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL200_MajReferentiel|TECHNIQUE|AbstractInternalRESTConnector : URL (Name=REXConnectorURL0 AccesPoint=http://SPIRIT-saab-JPA-1:8080/ExecuteGenericRequestV2) gotten from the load balancer.
18:09:23.423|INFO |qtp726950788-18|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL200_MajReferentiel|REPONSE_RECUE|operationVieReseauLireUn Body='{"listeOperationVieReseau":[{"dateCreation":"2021-03-17T18:07:34.199+0100","dateModification":"2021-03-17T18:07:34.199+0100","donneeBrute":"{\"ajoutsPortsPm\":[{\"boitierPm\":{\"nomPmTechnique\":\"ABCD123\",\"referenceBoitierPm\":\"BOITIER_D\"},\"liensPortPon\":[{\"nomOLT\":\"777nomOlt\",\"positionCartePon\":2,\"positionPortPon\":1}],\"panneauPm\":{\"nomPanneau\":\"PANNEAU_D\"},\"positionPortsPm\":{\"nomPanneau\":\"PANNEAU_B\",\"positionPort\":1,\"referenceBoitierPm\":\"BOITIER_B\",\"referencePmBytel\":\"SI758074\"}}],\"ajoutsPortsPon\":[{\"cartePon\":{\"modeleCarte\":\"m2\",\"position\":\"3\"},\"codificationVolume\":\"EDANN2\",\"maxOntId\":128,\"positionFoNro\":\"1/07/11/09\",\"positionPortPon\":{\"nomOLT\":\"777nomOlt\",\"position\":1,\"positionCarte\":2},\"referenceCableRenvoiNro\":\"R/DEG01\",\"sfpListeTechnologieCompatible\":[\"GPON\",\"XGPON\"]}],\"listeTypeEquipementImpacte\":[\"PM\",\"OLT\"],\"migrationsPortsPm\":[{\"positionPortPmCible\":{\"nomPanneau\":\"B1-M1-MODULE-HZTL-BOUY\",\"positionPort\":1,\"referenceBoitierPm\":\"BPI000010\",\"referencePmBytel\":\"SI758071\"},\"positionPortPmSource\":{\"nomPanneau\":\"B1-M1-MODULE-HZTL-BOUY\",\"positionPort\":1,\"referenceBoitierPm\":\"BPI000010\",\"referencePmBytel\":\"SI758074\"}}],\"modificationsPortsPm\":[{\"liensPortPonCible\":[{\"nomOLT\":\"777nomOlt\",\"positionCartePon\":2,\"positionPortPon\":2}],\"liensPortPonSource\":[{\"nomOLT\":\"777nomOlt\",\"positionCartePon\":2,\"positionPortPon\":1}],\"positionPortPm\":{\"nomPanneau\":\"B1-M1-MODULE-HZTL-BOUY\",\"positionPort\":1,\"referenceBoitierPm\":\"BPI000010\",\"referencePmBytel\":\"SI758074\"}}],\"modificationsPortsPon\":[{\"positionPortPon\":{\"nomOLT\":\"777nomOlt\",\"position\":2,\"positionCarte\":2},\"sfpListeTechnologieCompatible\":[\"XGPON\"]}],\"numeroGCR\":\"GCR-12345678\",\"suppressionsPortsPm\":[{\"positionPortsPm\":[{\"nomPanneau\":\"PANNEAU_E\",\"positionPort\":1,\"referenceBoitierPm\":\"BOITIER_E\",\"referencePmBytel\":\"SI758074\"}]}],\"typeVieReseau\":\"PON128\"}","idOperationVieReseau":"8b75de58-4b5b-44d1-9df2-0a1c527714da","listeClientImpacte":[],"numeroGCR":"GCR-12345678","statut":"ACQUITTE","typeOperationVieReseau":"PON128"}],"retour":{"resultat":"OK"}}' HTTPCode='200' Headers='connection: close,content-type: application/json,Date: Wed, 17 Mar 2021 17:09:23 GMT,Server: Jetty(9.3.10.v20160621),Content-Type: application/json'
18:09:23.426|INFO |qtp726950788-18|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL200_MajReferentiel|REQUETE_EMISE|operationVieReseauLireUn Headers='X-Oauth2-Habilit: SPIRIT_STARK,X-Request-Id: X-Request-Id,X-Request-Id-Spirit: b3e53b13-a485-4ce9-93e0-83e02281b2c6,X-Source: tesla,X-Process: PE0529_OperationVieReseau,X-Process-Id-Spirit: ec96ca4dc2724ce6ae1b9f3060c0fadd' Parameters='typeCle = PM,valeurCle = SI758074,typeOperationVieReseau = PON128'
18:09:23.426|DEBUG|qtp726950788-18|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL200_MajReferentiel|TECHNIQUE|AbstractInternalRESTConnector : URL (Name=REXConnectorURL0 AccesPoint=http://SPIRIT-saab-JPA-1:8080/ExecuteGenericRequestV2) gotten from the load balancer.
18:09:23.457|INFO |qtp726950788-18|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL200_MajReferentiel|REPONSE_RECUE|operationVieReseauLireUn Body='{"listeOperationVieReseau":[{"dateCreation":"2021-03-17T18:07:34.199+0100","dateModification":"2021-03-17T18:07:34.199+0100","donneeBrute":"{\"ajoutsPortsPm\":[{\"boitierPm\":{\"nomPmTechnique\":\"ABCD123\",\"referenceBoitierPm\":\"BOITIER_D\"},\"liensPortPon\":[{\"nomOLT\":\"777nomOlt\",\"positionCartePon\":2,\"positionPortPon\":1}],\"panneauPm\":{\"nomPanneau\":\"PANNEAU_D\"},\"positionPortsPm\":{\"nomPanneau\":\"PANNEAU_B\",\"positionPort\":1,\"referenceBoitierPm\":\"BOITIER_B\",\"referencePmBytel\":\"SI758074\"}}],\"ajoutsPortsPon\":[{\"cartePon\":{\"modeleCarte\":\"m2\",\"position\":\"3\"},\"codificationVolume\":\"EDANN2\",\"maxOntId\":128,\"positionFoNro\":\"1/07/11/09\",\"positionPortPon\":{\"nomOLT\":\"777nomOlt\",\"position\":1,\"positionCarte\":2},\"referenceCableRenvoiNro\":\"R/DEG01\",\"sfpListeTechnologieCompatible\":[\"GPON\",\"XGPON\"]}],\"listeTypeEquipementImpacte\":[\"PM\",\"OLT\"],\"migrationsPortsPm\":[{\"positionPortPmCible\":{\"nomPanneau\":\"B1-M1-MODULE-HZTL-BOUY\",\"positionPort\":1,\"referenceBoitierPm\":\"BPI000010\",\"referencePmBytel\":\"SI758071\"},\"positionPortPmSource\":{\"nomPanneau\":\"B1-M1-MODULE-HZTL-BOUY\",\"positionPort\":1,\"referenceBoitierPm\":\"BPI000010\",\"referencePmBytel\":\"SI758074\"}}],\"modificationsPortsPm\":[{\"liensPortPonCible\":[{\"nomOLT\":\"777nomOlt\",\"positionCartePon\":2,\"positionPortPon\":2}],\"liensPortPonSource\":[{\"nomOLT\":\"777nomOlt\",\"positionCartePon\":2,\"positionPortPon\":1}],\"positionPortPm\":{\"nomPanneau\":\"B1-M1-MODULE-HZTL-BOUY\",\"positionPort\":1,\"referenceBoitierPm\":\"BPI000010\",\"referencePmBytel\":\"SI758074\"}}],\"modificationsPortsPon\":[{\"positionPortPon\":{\"nomOLT\":\"777nomOlt\",\"position\":2,\"positionCarte\":2},\"sfpListeTechnologieCompatible\":[\"XGPON\"]}],\"numeroGCR\":\"GCR-12345678\",\"suppressionsPortsPm\":[{\"positionPortsPm\":[{\"nomPanneau\":\"PANNEAU_E\",\"positionPort\":1,\"referenceBoitierPm\":\"BOITIER_E\",\"referencePmBytel\":\"SI758074\"}]}],\"typeVieReseau\":\"PON128\"}","idOperationVieReseau":"8b75de58-4b5b-44d1-9df2-0a1c527714da","listeClientImpacte":[],"numeroGCR":"GCR-12345678","statut":"ACQUITTE","typeOperationVieReseau":"PON128"}],"retour":{"resultat":"OK"}}' HTTPCode='200' Headers='connection: close,content-type: application/json,Date: Wed, 17 Mar 2021 17:09:23 GMT,Server: Jetty(9.3.10.v20160621),Content-Type: application/json'
18:09:23.457|INFO |qtp726950788-18|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL200_MajReferentiel|REQUETE_EMISE|operationVieReseauLireUn Headers='X-Oauth2-Habilit: SPIRIT_STARK,X-Request-Id: X-Request-Id,X-Request-Id-Spirit: b3e53b13-a485-4ce9-93e0-83e02281b2c6,X-Source: tesla,X-Process: PE0529_OperationVieReseau,X-Process-Id-Spirit: ec96ca4dc2724ce6ae1b9f3060c0fadd' Parameters='typeCle = PM,valeurCle = SI758071,typeOperationVieReseau = PON128'
18:09:23.457|DEBUG|qtp726950788-18|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL200_MajReferentiel|TECHNIQUE|AbstractInternalRESTConnector : URL (Name=REXConnectorURL0 AccesPoint=http://SPIRIT-saab-JPA-1:8080/ExecuteGenericRequestV2) gotten from the load balancer.
18:09:23.478|INFO |qtp726950788-18|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL200_MajReferentiel|REPONSE_RECUE|operationVieReseauLireUn Body='{"listeOperationVieReseau":[{"dateCreation":"2021-03-17T18:07:34.199+0100","dateModification":"2021-03-17T18:07:34.199+0100","donneeBrute":"{\"ajoutsPortsPm\":[{\"boitierPm\":{\"nomPmTechnique\":\"ABCD123\",\"referenceBoitierPm\":\"BOITIER_D\"},\"liensPortPon\":[{\"nomOLT\":\"777nomOlt\",\"positionCartePon\":2,\"positionPortPon\":1}],\"panneauPm\":{\"nomPanneau\":\"PANNEAU_D\"},\"positionPortsPm\":{\"nomPanneau\":\"PANNEAU_B\",\"positionPort\":1,\"referenceBoitierPm\":\"BOITIER_B\",\"referencePmBytel\":\"SI758074\"}}],\"ajoutsPortsPon\":[{\"cartePon\":{\"modeleCarte\":\"m2\",\"position\":\"3\"},\"codificationVolume\":\"EDANN2\",\"maxOntId\":128,\"positionFoNro\":\"1/07/11/09\",\"positionPortPon\":{\"nomOLT\":\"777nomOlt\",\"position\":1,\"positionCarte\":2},\"referenceCableRenvoiNro\":\"R/DEG01\",\"sfpListeTechnologieCompatible\":[\"GPON\",\"XGPON\"]}],\"listeTypeEquipementImpacte\":[\"PM\",\"OLT\"],\"migrationsPortsPm\":[{\"positionPortPmCible\":{\"nomPanneau\":\"B1-M1-MODULE-HZTL-BOUY\",\"positionPort\":1,\"referenceBoitierPm\":\"BPI000010\",\"referencePmBytel\":\"SI758071\"},\"positionPortPmSource\":{\"nomPanneau\":\"B1-M1-MODULE-HZTL-BOUY\",\"positionPort\":1,\"referenceBoitierPm\":\"BPI000010\",\"referencePmBytel\":\"SI758074\"}}],\"modificationsPortsPm\":[{\"liensPortPonCible\":[{\"nomOLT\":\"777nomOlt\",\"positionCartePon\":2,\"positionPortPon\":2}],\"liensPortPonSource\":[{\"nomOLT\":\"777nomOlt\",\"positionCartePon\":2,\"positionPortPon\":1}],\"positionPortPm\":{\"nomPanneau\":\"B1-M1-MODULE-HZTL-BOUY\",\"positionPort\":1,\"referenceBoitierPm\":\"BPI000010\",\"referencePmBytel\":\"SI758074\"}}],\"modificationsPortsPon\":[{\"positionPortPon\":{\"nomOLT\":\"777nomOlt\",\"position\":2,\"positionCarte\":2},\"sfpListeTechnologieCompatible\":[\"XGPON\"]}],\"numeroGCR\":\"GCR-12345678\",\"suppressionsPortsPm\":[{\"positionPortsPm\":[{\"nomPanneau\":\"PANNEAU_E\",\"positionPort\":1,\"referenceBoitierPm\":\"BOITIER_E\",\"referencePmBytel\":\"SI758074\"}]}],\"typeVieReseau\":\"PON128\"}","idOperationVieReseau":"8b75de58-4b5b-44d1-9df2-0a1c527714da","listeClientImpacte":[],"numeroGCR":"GCR-12345678","statut":"ACQUITTE","typeOperationVieReseau":"PON128"}],"retour":{"resultat":"OK"}}' HTTPCode='200' Headers='connection: close,content-type: application/json,Date: Wed, 17 Mar 2021 17:09:23 GMT,Server: Jetty(9.3.10.v20160621),Content-Type: application/json'
18:09:23.481|INFO |qtp726950788-18|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL200_MajReferentiel|REQUETE_EMISE|operationVieReseauLireUn Headers='X-Oauth2-Habilit: SPIRIT_STARK,X-Request-Id: X-Request-Id,X-Request-Id-Spirit: b3e53b13-a485-4ce9-93e0-83e02281b2c6,X-Source: tesla,X-Process: PE0529_OperationVieReseau,X-Process-Id-Spirit: ec96ca4dc2724ce6ae1b9f3060c0fadd' Parameters='typeCle = OLT,valeurCle = 777nomOlt,typeOperationVieReseau = PON128'
18:09:23.481|DEBUG|qtp726950788-18|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL200_MajReferentiel|TECHNIQUE|AbstractInternalRESTConnector : URL (Name=REXConnectorURL0 AccesPoint=http://SPIRIT-saab-JPA-1:8080/ExecuteGenericRequestV2) gotten from the load balancer.
18:09:23.506|INFO |qtp726950788-18|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL200_MajReferentiel|REPONSE_RECUE|operationVieReseauLireUn Body='{"listeOperationVieReseau":[{"dateCreation":"2021-03-17T18:07:34.199+0100","dateModification":"2021-03-17T18:07:34.199+0100","donneeBrute":"{\"ajoutsPortsPm\":[{\"boitierPm\":{\"nomPmTechnique\":\"ABCD123\",\"referenceBoitierPm\":\"BOITIER_D\"},\"liensPortPon\":[{\"nomOLT\":\"777nomOlt\",\"positionCartePon\":2,\"positionPortPon\":1}],\"panneauPm\":{\"nomPanneau\":\"PANNEAU_D\"},\"positionPortsPm\":{\"nomPanneau\":\"PANNEAU_B\",\"positionPort\":1,\"referenceBoitierPm\":\"BOITIER_B\",\"referencePmBytel\":\"SI758074\"}}],\"ajoutsPortsPon\":[{\"cartePon\":{\"modeleCarte\":\"m2\",\"position\":\"3\"},\"codificationVolume\":\"EDANN2\",\"maxOntId\":128,\"positionFoNro\":\"1/07/11/09\",\"positionPortPon\":{\"nomOLT\":\"777nomOlt\",\"position\":1,\"positionCarte\":2},\"referenceCableRenvoiNro\":\"R/DEG01\",\"sfpListeTechnologieCompatible\":[\"GPON\",\"XGPON\"]}],\"listeTypeEquipementImpacte\":[\"PM\",\"OLT\"],\"migrationsPortsPm\":[{\"positionPortPmCible\":{\"nomPanneau\":\"B1-M1-MODULE-HZTL-BOUY\",\"positionPort\":1,\"referenceBoitierPm\":\"BPI000010\",\"referencePmBytel\":\"SI758071\"},\"positionPortPmSource\":{\"nomPanneau\":\"B1-M1-MODULE-HZTL-BOUY\",\"positionPort\":1,\"referenceBoitierPm\":\"BPI000010\",\"referencePmBytel\":\"SI758074\"}}],\"modificationsPortsPm\":[{\"liensPortPonCible\":[{\"nomOLT\":\"777nomOlt\",\"positionCartePon\":2,\"positionPortPon\":2}],\"liensPortPonSource\":[{\"nomOLT\":\"777nomOlt\",\"positionCartePon\":2,\"positionPortPon\":1}],\"positionPortPm\":{\"nomPanneau\":\"B1-M1-MODULE-HZTL-BOUY\",\"positionPort\":1,\"referenceBoitierPm\":\"BPI000010\",\"referencePmBytel\":\"SI758074\"}}],\"modificationsPortsPon\":[{\"positionPortPon\":{\"nomOLT\":\"777nomOlt\",\"position\":2,\"positionCarte\":2},\"sfpListeTechnologieCompatible\":[\"XGPON\"]}],\"numeroGCR\":\"GCR-12345678\",\"suppressionsPortsPm\":[{\"positionPortsPm\":[{\"nomPanneau\":\"PANNEAU_E\",\"positionPort\":1,\"referenceBoitierPm\":\"BOITIER_E\",\"referencePmBytel\":\"SI758074\"}]}],\"typeVieReseau\":\"PON128\"}","idOperationVieReseau":"8b75de58-4b5b-44d1-9df2-0a1c527714da","listeClientImpacte":[],"numeroGCR":"GCR-12345678","statut":"ACQUITTE","typeOperationVieReseau":"PON128"}],"retour":{"resultat":"OK"}}' HTTPCode='200' Headers='connection: close,content-type: application/json,Date: Wed, 17 Mar 2021 17:09:23 GMT,Server: Jetty(9.3.10.v20160621),Content-Type: application/json'
18:09:23.506|INFO |qtp726950788-18|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL200_MajReferentiel|REQUETE_EMISE|operationVieReseauModifierStatut Body='{"idOperationVieReseau":"8b75de58-4b5b-44d1-9df2-0a1c527714da","statut":"EN_COURS_MAJ_REFERENTIEL"}' Headers='X-Oauth2-Habilit: SPIRIT_STARK,Content-Type: application/json,X-Request-Id: X-Request-Id,X-Request-Id-Spirit: b3e53b13-a485-4ce9-93e0-83e02281b2c6,X-Source: tesla,X-Process: PE0529_OperationVieReseau,X-Process-Id-Spirit: ec96ca4dc2724ce6ae1b9f3060c0fadd'
18:09:23.506|DEBUG|qtp726950788-18|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL200_MajReferentiel|TECHNIQUE|AbstractInternalRESTConnector : URL (Name=REXConnectorURL0 AccesPoint=http://SPIRIT-saab-JPA-1:8080/ExecuteGenericRequestV2) gotten from the load balancer.
18:09:23.522|INFO |qtp726950788-18|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL200_MajReferentiel|REPONSE_RECUE|operationVieReseauModifierStatut Body='{"retour":{"resultat":"OK"}}' HTTPCode='200'Headers='connection: close,content-type: application/json,Date: Wed, 17 Mar 2021 17:09:23 GMT,Server: Jetty(9.3.10.v20160621),Content-Type: application/json'
18:09:23.522|INFO |qtp726950788-18|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL200_MajReferentiel|REQUETE_EMISE|pmCompositeLireUnParReferencePmBytel Headers='X-Oauth2-Habilit: SPIRIT_STARK,X-Request-Id: X-Request-Id,X-Request-Id-Spirit: b3e53b13-a485-4ce9-93e0-83e02281b2c6,X-Source: tesla,X-Process: PE0529_OperationVieReseau,X-Process-Id-Spirit: ec96ca4dc2724ce6ae1b9f3060c0fadd' Parameters='referencePmBytel = SI758074'
18:09:23.522|DEBUG|qtp726950788-18|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL200_MajReferentiel|TECHNIQUE|AbstractInternalRESTConnector : URL (Name=RESConnectorURL0 AccesPoint=http://SPIRIT-saab-JPA-1:8080/ExecuteGenericRequestV2) gotten from the load balancer.
18:09:23.535|INFO |qtp726950788-18|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL200_MajReferentiel|REPONSE_RECUE|pmCompositeLireUnParReferencePmBytel Body='{"pmComposite":{"adressePM":{"accessible":"BAT-1 / ESC-1 / ETAGE-SOUS-SOL-01","autresInformations":"CLIENT","batiment":"A","codeAccesImmeuble":"Digicode + Clef facteur","codeAccesSousSol":"Clefs à lagence","codeImmeuble":"pas de digicode, pas de gardien.","codeInsee":"30042","codeLocal":"SOUS SOL","codePostal":"30140","commentairePm":"AdresseTemporaire","complement":"A","contactsImmeuble":"M Toto Titi 0101010101","contactsSyndic":"AGENCE DE LA HALLE AGENCE DE LA HALLE 01 01 01 01 01  ","coordonneePmx":"637443.56","coordonneePmy":"6885895.5","hexacle":"AD95566ZAB","infoObtentionCle":"M. TOTO 0101010101","localisation":"SRO-BPI-978742","nomVoie":"DANDUZE","numeroVoie":"1579","referenceConsultationNative":"YVFI_LOTZAPM_78160_20171110-YVFI01-Lot02","rivoli":"048A","typeProjectionGeographique":"RGF93","typeVoie":"ROUTE","typeZone":"ZMD","ville":"BOISSET-ET-GAUJAC"},"codeOperateurImmeuble":"SFRA","dateCreation":"2020-12-07T12:19:15.184+0100","dateDernierImport":"2021-02-23T10:28:19.168+0100","dateModification":"2021-02-23T10:28:19.168+0100","dateOuvertureCommerciale":"2020-12-12T00:00:00.000+0100","etatDeploiement":"OUVERT_COMMERCIALEMENT","listeBoitierPM":{"BPI000010":{"dateCreation":"2020-12-07T12:19:15.184+0100","dateModification":"2020-12-07T12:19:15.184+0100","listePanneauPM":{"B1-M1-MODULE-HZTL-BOUY":{"baie":"A_1","dateCreation":"2020-12-07T12:19:15.184+0100","dateModification":"2020-12-07T12:19:15.184+0100","face":1,"listePortPM":{"1":{"dateCreation":"2020-12-07T12:19:15.184+0100","dateModification":"2020-12-07T12:19:15.184+0100","listeLienPortPMPon":{"OLT0018_1_1":{"portPon":{"nomOLT":"OLT0018","positionCartePON":1,"positionPortPON":1},"statutDeploiement":"OPERATIONNEL"}},"nomCoupleur":"SPL-1*8-01-BOU","position":1,"statutTechnique":"OPERATIONNEL","surchargePortPM":{"statutBlocage":"INACTIF","statutExploitation":"OPERATIONNEL"}}},"nomPanneau":"B1-M1-MODULE-HZTL-BOUY","positionAlpha":"K","statutTechnique":"OPERATIONNEL","tiroir":"01"}},"nomPmTechnique":"PT 1505","referenceBoitierPm":"BPI000010","statutTechnique":"OPERATIONNEL","surchargeBoitierPM":{"commentaireBlocage":"blocage prise clients suite a operation vie reseau le 14:23:05.517Z","dateActivation":"2021-02-23T15:23:05.567+0100","statutBlocage":"ACTIF"}}},"modeFinancementPM":"COFI","operateurAdduction":"ZTD SFR","referencePmBytel":"SI758074","referencePmOi":"ABC-BPI-1234","referencePrestationPM":"VOFI-BOIL02","statutTechnique":"OPERATIONNEL","surchargePM":{"statutBlocage":"INACTIF"},"typeEmplacementPM":"PMI","typeIngenierie":"MonofibreZMD"},"retour":{"resultat":"OK"}}' HTTPCode='200' Headers='connection: close,content-type: application/json,Date: Wed, 17 Mar 2021 17:09:23 GMT,Server: Jetty(9.3.10.v20160621),Content-Type: application/json'
18:09:23.539|INFO |qtp726950788-18|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL200_MajReferentiel|REQUETE_EMISE|ressourceLireUn Headers='X-Oauth2-Habilit: SPIRIT_STARK,X-Request-Id: X-Request-Id,X-Request-Id-Spirit: b3e53b13-a485-4ce9-93e0-83e02281b2c6,X-Source: tesla,X-Process: PE0529_OperationVieReseau,X-Process-Id-Spirit: ec96ca4dc2724ce6ae1b9f3060c0fadd' Parameters='idRessource = SI758074||BPI000010||B1-M1-MODULE-HZTL-BOUY||1,typeRessource = PORT_PM'
18:09:23.539|DEBUG|qtp726950788-18|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL200_MajReferentiel|TECHNIQUE|AbstractInternalRESTConnector : URL (Name=RESConnectorURL0 AccesPoint=http://SPIRIT-saab-JPA-1:8080/ExecuteGenericRequestV2) gotten from the load balancer.
18:09:23.554|INFO |qtp726950788-18|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL200_MajReferentiel|REPONSE_RECUE|ressourceLireUn Body='{"listeRessource":[{"dateCreation":"2021-03-01T11:27:39.948+0100","dateModification":"2021-03-01T11:27:39.948+0100","idRessource":"SI758074||BPI000010||B1-M1-MODULE-HZTL-BOUY||1","idRessourceLie":"client2","nomPanneau":"B1-M1-MODULE-HZTL-BOUY","positionPortPm":1,"referenceBoitierPm":"BPI000010","referencePmBytel":"SI758074","statut":"LIBRE","typeRessource":"PORT_PM"}],"retour":{"resultat":"OK"}}' HTTPCode='200' Headers='connection: close,content-type: application/json,Date: Wed, 17 Mar 2021 17:09:23 GMT,Server: Jetty(9.3.10.v20160621),Content-Type: application/json'
18:09:23.555|INFO |qtp726950788-18|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL200_MajReferentiel|REQUETE_EMISE|pmCompositeGererImport Body='{"pmComposite":{"adressePM":{"accessible":"BAT-1 / ESC-1 / ETAGE-SOUS-SOL-01","autresInformations":"CLIENT","batiment":"A","codeAccesImmeuble":"Digicode + Clef facteur","codeAccesSousSol":"Clefs à lagence","codeImmeuble":"pas de digicode, pas de gardien.","codeInsee":"30042","codeLocal":"SOUS SOL","codePostal":"30140","commentairePm":"AdresseTemporaire","complement":"A","contactsImmeuble":"M Toto Titi 0101010101","contactsSyndic":"AGENCE DE LA HALLE AGENCE DE LA HALLE 01 01 01 01 01  ","coordonneePmx":"637443.56","coordonneePmy":"6885895.5","hexacle":"AD95566ZAB","infoObtentionCle":"M. TOTO 0101010101","localisation":"SRO-BPI-978742","nomVoie":"DANDUZE","numeroVoie":"1579","referenceConsultationNative":"YVFI_LOTZAPM_78160_20171110-YVFI01-Lot02","rivoli":"048A","typeProjectionGeographique":"RGF93","typeVoie":"ROUTE","typeZone":"ZMD","ville":"BOISSET-ET-GAUJAC"},"codeOperateurImmeuble":"SFRA","dateCreation":"2020-12-07T12:19:15.184+0100","dateModification":"2021-02-23T10:28:19.168+0100","dateOuvertureCommerciale":"2020-12-12T00:00:00.000+0100","etatDeploiement":"OUVERT_COMMERCIALEMENT","listeBoitierPM":{"BPI000010":{"dateCreation":"2020-12-07T12:19:15.184+0100","dateModification":"2020-12-07T12:19:15.184+0100","listePanneauPM":{"B1-M1-MODULE-HZTL-BOUY":{"baie":"A_1","dateCreation":"2020-12-07T12:19:15.184+0100","dateModification":"2020-12-07T12:19:15.184+0100","face":1,"listePortPM":{"1":{"dateCreation":"2020-12-07T12:19:15.184+0100","dateModification":"2020-12-07T12:19:15.184+0100","listeLienPortPMPon":{"OLT0018_1_1":{"portPon":{"nomOLT":"OLT0018","positionCartePON":1,"positionPortPON":1},"statutDeploiement":"OPERATIONNEL"},"777nomOlt_2_2":{"portPon":{"nomOLT":"777nomOlt","positionCartePON":2,"positionPortPON":2},"statutDeploiement":"OPERATIONNEL"}},"nomCoupleur":"SPL-1*8-01-BOU","position":1,"statutTechnique":"OPERATIONNEL","surchargePortPM":{"statutBlocage":"INACTIF","statutExploitation":"OPERATIONNEL"}}},"nomPanneau":"B1-M1-MODULE-HZTL-BOUY","positionAlpha":"K","statutTechnique":"OPERATIONNEL","tiroir":"01"}},"nomPmTechnique":"PT 1505","referenceBoitierPm":"BPI000010","statutTechnique":"OPERATIONNEL","surchargeBoitierPM":{"commentaireBlocage":"blocage prise clients suite a operation vie reseau le 14:23:05.517Z","dateActivation":"2021-02-23T15:23:05.567+0100","statutBlocage":"ACTIF"}},"BOITIER_D":{"listePanneauPM":{"PANNEAU_B":{"listePortPM":{"1":{"listeLienPortPMPon":{"777nomOlt_2_1":{"portPon":{"nomOLT":"777nomOlt","positionCartePON":2,"positionPortPON":1},"statutDeploiement":"OPERATIONNEL"}},"position":1,"statutTechnique":"OPERATIONNEL"}},"nomPanneau":"PANNEAU_B","statutTechnique":"OPERATIONNEL"}},"nomPmTechnique":"ABCD123","referenceBoitierPm":"BOITIER_D","statutTechnique":"OPERATIONNEL"}},"modeFinancementPM":"COFI","operateurAdduction":"ZTD SFR","referencePmBytel":"SI758074","referencePmOi":"ABC-BPI-1234","referencePrestationPM":"VOFI-BOIL02","statutTechnique":"OPERATIONNEL","surchargePM":{"statutBlocage":"INACTIF"},"typeEmplacementPM":"PMI","typeIngenierie":"MonofibreZMD"}}' Headers='X-Oauth2-Habilit: SPIRIT_STARK,Content-Type: application/json,X-Request-Id: X-Request-Id,X-Request-Id-Spirit: b3e53b13-a485-4ce9-93e0-83e02281b2c6,X-Source: tesla,X-Process: PE0529_OperationVieReseau,X-Process-Id-Spirit: ec96ca4dc2724ce6ae1b9f3060c0fadd' Parameters='action = GererImport,typeFluxImport = VIE_DE_RESEAU'
18:09:23.555|DEBUG|qtp726950788-18|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL200_MajReferentiel|TECHNIQUE|AbstractInternalRESTConnector : URL (Name=RESConnectorURL0 AccesPoint=http://SPIRIT-saab-JPA-1:8080/ExecuteGenericRequestV2) gotten from the load balancer.
18:09:23.588|INFO |qtp726950788-18|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL200_MajReferentiel|REPONSE_RECUE|pmCompositeGererImport Body='{"retour":{"resultat":"OK"}}' HTTPCode='200' Headers='connection: close,content-type: application/json,Date: Wed, 17 Mar 2021 17:09:23 GMT,Server: Jetty(9.3.10.v20160621),Content-Type: application/json'
18:09:23.589|INFO |qtp726950788-18|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL200_MajReferentiel|REQUETE_EMISE|pmCompositeLireUnParReferencePmBytel Headers='X-Oauth2-Habilit: SPIRIT_STARK,X-Request-Id: X-Request-Id,X-Request-Id-Spirit: b3e53b13-a485-4ce9-93e0-83e02281b2c6,X-Source: tesla,X-Process: PE0529_OperationVieReseau,X-Process-Id-Spirit: ec96ca4dc2724ce6ae1b9f3060c0fadd' Parameters='referencePmBytel = SI758071'
18:09:23.589|DEBUG|qtp726950788-18|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL200_MajReferentiel|TECHNIQUE|AbstractInternalRESTConnector : URL (Name=RESConnectorURL0 AccesPoint=http://SPIRIT-saab-JPA-1:8080/ExecuteGenericRequestV2) gotten from the load balancer.
18:09:23.600|INFO |qtp726950788-18|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL200_MajReferentiel|REPONSE_RECUE|pmCompositeLireUnParReferencePmBytel Body='{"pmComposite":{"adressePM":{"accessible":"BAT-1 / ESC-1 / ETAGE-SOUS-SOL-01","autresInformations":"CLIENT","batiment":"A","codeAccesImmeuble":"Digicode + Clef facteur","codeAccesSousSol":"Clefs à lagence","codeImmeuble":"pas de digicode, pas de gardien.","codeInsee":"30042","codeLocal":"SOUS SOL","codePostal":"30140","commentairePm":"AdresseTemporaire","complement":"A","contactsImmeuble":"M Toto Titi 0101010101","contactsSyndic":"AGENCE DE LA HALLE AGENCE DE LA HALLE 01 01 01 01 01  ","coordonneePmx":"637443.56","coordonneePmy":"6885895.5","hexacle":"AD95566ZAB","infoObtentionCle":"M. TOTO 0101010101","localisation":"SRO-BPI-978742","nomVoie":"DANDUZE","numeroVoie":"1579","referenceConsultationNative":"YVFI_LOTZAPM_78160_20171110-YVFI01-Lot02","rivoli":"048A","typeProjectionGeographique":"RGF93","typeVoie":"ROUTE","typeZone":"ZMD","ville":"BOISSET-ET-GAUJAC"},"codeOperateurImmeuble":"SFRA","dateCreation":"2021-02-08T13:29:37.784+0100","dateDernierImport":"2021-02-08T13:29:37.784+0100","dateModification":"2021-02-08T13:29:37.784+0100","dateOuvertureCommerciale":"2020-12-12T00:00:00.000+0100","etatDeploiement":"OUVERT_COMMERCIALEMENT","listeBoitierPM":{"BPI000010":{"dateCreation":"2021-02-08T13:29:37.784+0100","dateModification":"2021-02-08T13:29:37.784+0100","listePanneauPM":{"B1-M1-MODULE-HZTL-BOUY":{"baie":"A_1","dateCreation":"2021-02-08T13:29:37.784+0100","dateModification":"2021-02-08T13:29:37.784+0100","face":1,"listePortPM":{"1":{"dateCreation":"2021-02-08T13:29:37.784+0100","dateModification":"2021-02-08T13:29:37.784+0100","listeLienPortPMPon":{"OLT0018_1_1":{"portPon":{"nomOLT":"OLT0018","positionCartePON":1,"positionPortPON":1},"statutDeploiement":"OPERATIONNEL"}},"nomCoupleur":"SPL-1*8-01-BOU","position":1,"statutTechnique":"OPERATIONNEL","surchargePortPM":{"statutBlocage":"INACTIF","statutExploitation":"OPERATIONNEL"}}},"nomPanneau":"B1-M1-MODULE-HZTL-BOUY","positionAlpha":"K","statutTechnique":"OPERATIONNEL","tiroir":"01"}},"nomPmTechnique":"PT 1505","referenceBoitierPm":"BPI000010","statutTechnique":"OPERATIONNEL","surchargeBoitierPM":{"statutBlocage":"INACTIF"}}},"modeFinancementPM":"COFI","operateurAdduction":"ZTD SFR","referencePmBytel":"SI758071","referencePmOi":"SRO-BPI-1523556","referencePrestationPM":"VOFI-BOIL02","statutTechnique":"OPERATIONNEL","surchargePM":{"statutBlocage":"INACTIF"},"typeEmplacementPM":"PME","typeIngenierie":"MonofibreZMD"},"retour":{"resultat":"OK"}}' HTTPCode='200' Headers='connection: close,content-type: application/json,Date: Wed, 17 Mar 2021 17:09:23 GMT,Server: Jetty(9.3.10.v20160621),Content-Type: application/json'
18:09:23.606|INFO |qtp726950788-18|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL200_MajReferentiel|REQUETE_EMISE|ressourceLireUn Headers='X-Oauth2-Habilit: SPIRIT_STARK,X-Request-Id: X-Request-Id,X-Request-Id-Spirit: b3e53b13-a485-4ce9-93e0-83e02281b2c6,X-Source: tesla,X-Process: PE0529_OperationVieReseau,X-Process-Id-Spirit: ec96ca4dc2724ce6ae1b9f3060c0fadd' Parameters='idRessource = SI758074||BPI000010||B1-M1-MODULE-HZTL-BOUY||1,typeRessource = PORT_PM'
18:09:23.606|DEBUG|qtp726950788-18|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL200_MajReferentiel|TECHNIQUE|AbstractInternalRESTConnector : URL (Name=RESConnectorURL0 AccesPoint=http://SPIRIT-saab-JPA-1:8080/ExecuteGenericRequestV2) gotten from the load balancer.
18:09:23.619|INFO |qtp726950788-18|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL200_MajReferentiel|REPONSE_RECUE|ressourceLireUn Body='{"listeRessource":[{"dateCreation":"2021-03-01T11:27:39.948+0100","dateModification":"2021-03-01T11:27:39.948+0100","idRessource":"SI758074||BPI000010||B1-M1-MODULE-HZTL-BOUY||1","idRessourceLie":"client2","nomPanneau":"B1-M1-MODULE-HZTL-BOUY","positionPortPm":1,"referenceBoitierPm":"BPI000010","referencePmBytel":"SI758074","statut":"LIBRE","typeRessource":"PORT_PM"}],"retour":{"resultat":"OK"}}' HTTPCode='200' Headers='connection: close,content-type: application/json,Date: Wed, 17 Mar 2021 17:09:23 GMT,Server: Jetty(9.3.10.v20160621),Content-Type: application/json'
18:09:23.629|INFO |qtp726950788-18|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL200_MajReferentiel|REQUETE_EMISE|pmCompositeGererImport Body='{"pmComposite":{"adressePM":{"accessible":"BAT-1 / ESC-1 / ETAGE-SOUS-SOL-01","autresInformations":"CLIENT","batiment":"A","codeAccesImmeuble":"Digicode + Clef facteur","codeAccesSousSol":"Clefs à lagence","codeImmeuble":"pas de digicode, pas de gardien.","codeInsee":"30042","codeLocal":"SOUS SOL","codePostal":"30140","commentairePm":"AdresseTemporaire","complement":"A","contactsImmeuble":"M Toto Titi 0101010101","contactsSyndic":"AGENCE DE LA HALLE AGENCE DE LA HALLE 01 01 01 01 01  ","coordonneePmx":"637443.56","coordonneePmy":"6885895.5","hexacle":"AD95566ZAB","infoObtentionCle":"M. TOTO 0101010101","localisation":"SRO-BPI-978742","nomVoie":"DANDUZE","numeroVoie":"1579","referenceConsultationNative":"YVFI_LOTZAPM_78160_20171110-YVFI01-Lot02","rivoli":"048A","typeProjectionGeographique":"RGF93","typeVoie":"ROUTE","typeZone":"ZMD","ville":"BOISSET-ET-GAUJAC"},"codeOperateurImmeuble":"SFRA","dateCreation":"2021-02-08T13:29:37.784+0100","dateModification":"2021-02-08T13:29:37.784+0100","dateOuvertureCommerciale":"2020-12-12T00:00:00.000+0100","etatDeploiement":"OUVERT_COMMERCIALEMENT","listeBoitierPM":{"BPI000010":{"dateCreation":"2021-02-08T13:29:37.784+0100","dateModification":"2021-02-08T13:29:37.784+0100","listePanneauPM":{"B1-M1-MODULE-HZTL-BOUY":{"baie":"A_1","dateCreation":"2021-02-08T13:29:37.784+0100","dateModification":"2021-02-08T13:29:37.784+0100","face":1,"listePortPM":{"1":{"dateCreation":"2021-02-08T13:29:37.784+0100","dateModification":"2021-02-08T13:29:37.784+0100","listeLienPortPMPon":{"OLT0018_1_1":{"portPon":{"nomOLT":"OLT0018","positionCartePON":1,"positionPortPON":1},"statutDeploiement":"OPERATIONNEL"},"777nomOlt_2_2":{"portPon":{"nomOLT":"777nomOlt","positionCartePON":2,"positionPortPON":2},"statutDeploiement":"OPERATIONNEL"}},"nomCoupleur":"SPL-1*8-01-BOU","position":1,"statutTechnique":"OPERATIONNEL","surchargePortPM":{"statutBlocage":"INACTIF","statutExploitation":"OPERATIONNEL"}}},"nomPanneau":"B1-M1-MODULE-HZTL-BOUY","positionAlpha":"K","statutTechnique":"OPERATIONNEL","tiroir":"01"}},"nomPmTechnique":"PT 1505","referenceBoitierPm":"BPI000010","statutTechnique":"OPERATIONNEL","surchargeBoitierPM":{"statutBlocage":"INACTIF"}},"BOITIER_D":{"listePanneauPM":{"PANNEAU_B":{"listePortPM":{"1":{"listeLienPortPMPon":{"777nomOlt_2_1":{"portPon":{"nomOLT":"777nomOlt","positionCartePON":2,"positionPortPON":1},"statutDeploiement":"OPERATIONNEL"}},"position":1,"statutTechnique":"OPERATIONNEL"}},"nomPanneau":"PANNEAU_B","statutTechnique":"OPERATIONNEL"}},"nomPmTechnique":"ABCD123","referenceBoitierPm":"BOITIER_D","statutTechnique":"OPERATIONNEL"}},"modeFinancementPM":"COFI","operateurAdduction":"ZTD SFR","referencePmBytel":"SI758071","referencePmOi":"SRO-BPI-1523556","referencePrestationPM":"VOFI-BOIL02","statutTechnique":"OPERATIONNEL","surchargePM":{"statutBlocage":"INACTIF"},"typeEmplacementPM":"PME","typeIngenierie":"MonofibreZMD"}}' Headers='X-Oauth2-Habilit: SPIRIT_STARK,Content-Type: application/json,X-Request-Id: X-Request-Id,X-Request-Id-Spirit: b3e53b13-a485-4ce9-93e0-83e02281b2c6,X-Source: tesla,X-Process: PE0529_OperationVieReseau,X-Process-Id-Spirit: ec96ca4dc2724ce6ae1b9f3060c0fadd' Parameters='action = GererImport,typeFluxImport = VIE_DE_RESEAU'
18:09:23.629|DEBUG|qtp726950788-18|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL200_MajReferentiel|TECHNIQUE|AbstractInternalRESTConnector : URL (Name=RESConnectorURL0 AccesPoint=http://SPIRIT-saab-JPA-1:8080/ExecuteGenericRequestV2) gotten from the load balancer.
18:09:23.661|INFO |qtp726950788-18|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL200_MajReferentiel|REPONSE_RECUE|pmCompositeGererImport Body='{"retour":{"resultat":"OK"}}' HTTPCode='200' Headers='connection: close,content-type: application/json,Date: Wed, 17 Mar 2021 17:09:23 GMT,Server: Jetty(9.3.10.v20160621),Content-Type: application/json'
18:09:23.662|INFO |qtp726950788-18|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL200_MajReferentiel|REQUETE_EMISE|oltCompositeLireUn Headers='X-Oauth2-Habilit: SPIRIT_STARK,X-Request-Id: X-Request-Id,X-Request-Id-Spirit: b3e53b13-a485-4ce9-93e0-83e02281b2c6,X-Source: tesla,X-Process: PE0529_OperationVieReseau,X-Process-Id-Spirit: ec96ca4dc2724ce6ae1b9f3060c0fadd' Parameters='nomOLT = 777nomOlt'
18:09:23.662|DEBUG|qtp726950788-18|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL200_MajReferentiel|TECHNIQUE|AbstractInternalRESTConnector : URL (Name=RESConnectorURL0 AccesPoint=http://SPIRIT-saab-JPA-1:8080/ExecuteGenericRequestV2) gotten from the load balancer.
18:09:23.682|INFO |qtp726950788-18|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL200_MajReferentiel|REPONSE_RECUE|oltCompositeLireUn Body='{"oltComposite":{"constructeur":"huawei","dateCreation":"2018-12-28T17:03:23.422+0100","dateDernierImport":"2018-12-31T10:57:23.279+0100","dateModification":"2018-12-28T17:05:00.099+0100","ip":"192.168.0.44","listeCarteP2P":{"1":{"listeCageP2P":{"16":{"dateCreation":"2019-12-17T11:44:27.240+0100","dateModification":"2019-12-17T11:44:27.241+0100","listePortP2P":{"1":{"dateCreation":"2020-08-25T17:48:35.342+0200","dateModification":"2020-08-25T17:48:35.342+0200","position":1,"positionRelativeCarte":1,"statutTechnique":"OPERATIONNEL"},"2":{"dateCreation":"2020-08-25T17:48:35.342+0200","dateModification":"2020-08-25T17:48:35.342+0200","position":2,"positionRelativeCarte":2,"statutTechnique":"OPERATIONNEL"}},"position":16,"statutTechnique":"OPERATIONNEL","surchargeCageP2P":{"commentaireBlocage":"commentaire","dateActivation":"2020-08-25T17:48:35.342+0200","distanceMax":100,"statutBlocage":"ACTIF"}},"1":{"listePortP2P":{},"position":1,"statutTechnique":"OPERATIONNEL","surchargeCageP2P":{"distanceMax":10,"statutBlocage":"INACTIF"}}},"modele":"m2","position":1,"statutTechnique":"OPERATIONNEL","surchargeCarte":{"commentaireBlocage":"blocage prise clients suite a operation vie reseau le 14:23:05.517Z","dateActivation":"2021-02-23T15:23:05.527+0100","statutBlocage":"ACTIF"},"typeCarte":"CarteP2P"}},"listeCartePON":{"2":{"dateCreation":"2020-12-03T10:50:30.659+0100","dateModification":"2020-12-03T10:50:30.659+0100","listePortPON":{"2":{"codificationVolume":"test","dateCreation":"2020-12-03T10:50:30.659+0100","dateModification":"2020-12-03T10:50:30.659+0100","listeOntId":{},"maxOntId":10,"position":2,"positionFoNro":"test","referenceCableRenvoi":"test","sfpListeTechnologieCompatible":[],"statutTechnique":"OPERATIONNEL","surchargePortPON":{"debitGarantieCapaciteAllouee":10,"listeTechnologieAutorisee":["GPON","XPON"],"statutBlocage":"INACTIF"}}},"modele":"m2","position":2,"statutTechnique":"OPERATIONNEL","surchargeCarte":{"commentaireBlocage":"blocage prise clients suite a operation vie reseau le 14:23:05.517Z","dateActivation":"2021-02-23T15:23:05.554+0100","statutBlocage":"ACTIF"},"typeCarte":"CartePON"}},"modele":"m1","nomNR":"nomNR","nomOLT":"777nomOlt","statutTechnique":"OPERATIONNEL","surchargeOLT":{"nomOmc":"OMC_NCE","statutBlocage":"INACTIF","versionInterfaceEchange":"qos_convergee"}},"retour":{"resultat":"OK"}}' HTTPCode='200' Headers='connection: close,content-type: application/json,Date: Wed, 17 Mar 2021 17:09:23 GMT,Server: Jetty(9.3.10.v20160621),Content-Type: application/json'
18:09:23.688|INFO |qtp726950788-18|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL200_MajReferentiel|REQUETE_EMISE|oltCompositeGererImport Body='{"oltComposite":{"constructeur":"huawei","dateCreation":"2018-12-28T17:03:23.422+0100","dateModification":"2018-12-28T17:05:00.099+0100","ip":"192.168.0.44","listeCarteP2P":{"1":{"listeCageP2P":{"16":{"dateCreation":"2019-12-17T11:44:27.240+0100","dateModification":"2019-12-17T11:44:27.241+0100","listePortP2P":{"1":{"dateCreation":"2020-08-25T17:48:35.342+0200","dateModification":"2020-08-25T17:48:35.342+0200","position":1,"positionRelativeCarte":1,"statutTechnique":"OPERATIONNEL"},"2":{"dateCreation":"2020-08-25T17:48:35.342+0200","dateModification":"2020-08-25T17:48:35.342+0200","position":2,"positionRelativeCarte":2,"statutTechnique":"OPERATIONNEL"}},"position":16,"statutTechnique":"OPERATIONNEL","surchargeCageP2P":{"commentaireBlocage":"commentaire","dateActivation":"2020-08-25T17:48:35.342+0200","distanceMax":100,"statutBlocage":"ACTIF"}},"1":{"listePortP2P":{},"position":1,"statutTechnique":"OPERATIONNEL","surchargeCageP2P":{"distanceMax":10,"statutBlocage":"INACTIF"}}},"modele":"m2","position":1,"statutTechnique":"OPERATIONNEL","surchargeCarte":{"commentaireBlocage":"blocage prise clients suite a operation vie reseau le 14:23:05.517Z","dateActivation":"2021-02-23T15:23:05.527+0100","statutBlocage":"ACTIF"},"typeCarte":"CarteP2P"}},"listeCartePON":{"2":{"dateCreation":"2020-12-03T10:50:30.659+0100","dateModification":"2020-12-03T10:50:30.659+0100","listePortPON":{"2":{"codificationVolume":"test","dateCreation":"2020-12-03T10:50:30.659+0100","dateModification":"2020-12-03T10:50:30.659+0100","listeOntId":{},"maxOntId":10,"position":2,"positionFoNro":"test","referenceCableRenvoi":"test","sfpListeTechnologieCompatible":["XGPON"],"statutTechnique":"OPERATIONNEL","surchargePortPON":{"debitGarantieCapaciteAllouee":10,"listeTechnologieAutorisee":["GPON","XPON"],"statutBlocage":"INACTIF"}},"1":{"codificationVolume":"EDANN2","listeOntId":{},"maxOntId":128,"position":1,"positionFoNro":"1/07/11/09","referenceCableRenvoi":"R/DEG01","sfpListeTechnologieCompatible":["GPON","XGPON"],"statutTechnique":"OPERATIONNEL"}},"modele":"m2","position":2,"statutTechnique":"OPERATIONNEL","surchargeCarte":{"commentaireBlocage":"blocage prise clients suite a operation vie reseau le 14:23:05.517Z","dateActivation":"2021-02-23T15:23:05.554+0100","statutBlocage":"ACTIF"},"typeCarte":"CartePON"}},"modele":"m1","nomNR":"nomNR","nomOLT":"777nomOlt","statutTechnique":"OPERATIONNEL","surchargeOLT":{"nomOmc":"OMC_NCE","statutBlocage":"INACTIF","versionInterfaceEchange":"qos_convergee"}}}' Headers='X-Oauth2-Habilit: SPIRIT_STARK,Content-Type: application/json,X-Request-Id: X-Request-Id,X-Request-Id-Spirit: b3e53b13-a485-4ce9-93e0-83e02281b2c6,X-Source: tesla,X-Process: PE0529_OperationVieReseau,X-Process-Id-Spirit: ec96ca4dc2724ce6ae1b9f3060c0fadd' Parameters='action = GererImport'
18:09:23.689|DEBUG|qtp726950788-18|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL200_MajReferentiel|TECHNIQUE|AbstractInternalRESTConnector : URL (Name=RESConnectorURL0 AccesPoint=http://SPIRIT-saab-JPA-1:8080/ExecuteGenericRequestV2) gotten from the load balancer.
18:09:23.721|INFO |qtp726950788-18|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL200_MajReferentiel|REPONSE_RECUE|oltCompositeGererImport Body='{"retour":{"resultat":"OK"}}' HTTPCode='200' Headers='connection: close,content-type: application/json,Date: Wed, 17 Mar 2021 17:09:23 GMT,Server: Jetty(9.3.10.v20160621),Content-Type: application/json'
18:09:23.721|INFO |qtp726950788-18|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL200_MajReferentiel|REQUETE_EMISE|pmcompositeModifierSurchargeDateDebutQuarantainePM Headers='X-Oauth2-Habilit: SPIRIT_STARK,Content-Type: application/json,X-Request-Id: X-Request-Id,X-Request-Id-Spirit: b3e53b13-a485-4ce9-93e0-83e02281b2c6,X-Source: tesla,X-Process: PE0529_OperationVieReseau,X-Process-Id-Spirit: ec96ca4dc2724ce6ae1b9f3060c0fadd' Parameters='action = ModifierSurChargeDateDebutQuarantainePM,referencePmBytel = SI758074'
18:09:23.721|DEBUG|qtp726950788-18|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL200_MajReferentiel|TECHNIQUE|AbstractInternalRESTConnector : URL (Name=RESConnectorURL0 AccesPoint=http://SPIRIT-saab-JPA-1:8080/ExecuteGenericRequestV2) gotten from the load balancer.
18:09:23.736|INFO |qtp726950788-18|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL200_MajReferentiel|REPONSE_RECUE|pmcompositeModifierSurchargeDateDebutQuarantainePM Body='{"retour":{"resultat":"OK"}}' HTTPCode='200' Headers='connection: close,content-type: application/json,Date: Wed, 17 Mar 2021 17:09:23 GMT,Server: Jetty(9.3.10.v20160621),Content-Type: application/json'
18:09:23.737|INFO |qtp726950788-18|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL200_MajReferentiel|REQUETE_EMISE|pmcompositeModifierSurchargeDateDebutQuarantainePM Headers='X-Oauth2-Habilit: SPIRIT_STARK,Content-Type: application/json,X-Request-Id: X-Request-Id,X-Request-Id-Spirit: b3e53b13-a485-4ce9-93e0-83e02281b2c6,X-Source: tesla,X-Process: PE0529_OperationVieReseau,X-Process-Id-Spirit: ec96ca4dc2724ce6ae1b9f3060c0fadd' Parameters='action = ModifierSurChargeDateDebutQuarantainePM,referencePmBytel = SI758071'
18:09:23.737|DEBUG|qtp726950788-18|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL200_MajReferentiel|TECHNIQUE|AbstractInternalRESTConnector : URL (Name=RESConnectorURL0 AccesPoint=http://SPIRIT-saab-JPA-1:8080/ExecuteGenericRequestV2) gotten from the load balancer.
18:09:23.751|INFO |qtp726950788-18|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL200_MajReferentiel|REPONSE_RECUE|pmcompositeModifierSurchargeDateDebutQuarantainePM Body='{"retour":{"resultat":"OK"}}' HTTPCode='200' Headers='connection: close,content-type: application/json,Date: Wed, 17 Mar 2021 17:09:23 GMT,Server: Jetty(9.3.10.v20160621),Content-Type: application/json'
18:09:23.752|INFO |qtp726950788-18|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL200_MajReferentiel|REQUETE_EMISE|oltCompositemodifierSurchargeDateDebutQuarantaineOLT Headers='X-Oauth2-Habilit: SPIRIT_STARK,Content-Type: application/json,X-Request-Id: X-Request-Id,X-Request-Id-Spirit: b3e53b13-a485-4ce9-93e0-83e02281b2c6,X-Source: tesla,X-Process: PE0529_OperationVieReseau,X-Process-Id-Spirit: ec96ca4dc2724ce6ae1b9f3060c0fadd' Parameters='action = ModifierSurchargeDateDebutQuarantaineOLT,nomOLT = 777nomOlt'
18:09:23.752|DEBUG|qtp726950788-18|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL200_MajReferentiel|TECHNIQUE|AbstractInternalRESTConnector : URL (Name=RESConnectorURL0 AccesPoint=http://SPIRIT-saab-JPA-1:8080/ExecuteGenericRequestV2) gotten from the load balancer.
18:09:23.768|INFO |qtp726950788-18|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL200_MajReferentiel|REPONSE_RECUE|oltCompositemodifierSurchargeDateDebutQuarantaineOLT Body='{"retour":{"resultat":"OK"}}' HTTPCode='200' Headers='connection: close,content-type: application/json,Date: Wed, 17 Mar 2021 17:09:23 GMT,Server: Jetty(9.3.10.v20160621),Content-Type: application/json'
18:09:23.770|INFO |qtp726950788-18|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL200_MajReferentiel|REQUETE_EMISE|operationVieReseauLireUn Headers='X-Oauth2-Habilit: SPIRIT_STARK,X-Request-Id: X-Request-Id,X-Request-Id-Spirit: b3e53b13-a485-4ce9-93e0-83e02281b2c6,X-Source: tesla,X-Process: PE0529_OperationVieReseau,X-Process-Id-Spirit: ec96ca4dc2724ce6ae1b9f3060c0fadd' Parameters='idOperationVieReseau = 8b75de58-4b5b-44d1-9df2-0a1c527714da'
18:09:23.770|DEBUG|qtp726950788-18|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL200_MajReferentiel|TECHNIQUE|AbstractInternalRESTConnector : URL (Name=REXConnectorURL0 AccesPoint=http://SPIRIT-saab-JPA-1:8080/ExecuteGenericRequestV2) gotten from the load balancer.
18:09:23.782|INFO |qtp726950788-18|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL200_MajReferentiel|REPONSE_RECUE|operationVieReseauLireUn Body='{"listeOperationVieReseau":[{"dateCreation":"2021-03-17T18:07:34.199+0100","dateExecution":"2021-03-17T18:09:23.516+0100","dateModification":"2021-03-17T18:09:23.516+0100","donneeBrute":"{\"ajoutsPortsPm\":[{\"boitierPm\":{\"nomPmTechnique\":\"ABCD123\",\"referenceBoitierPm\":\"BOITIER_D\"},\"liensPortPon\":[{\"nomOLT\":\"777nomOlt\",\"positionCartePon\":2,\"positionPortPon\":1}],\"panneauPm\":{\"nomPanneau\":\"PANNEAU_D\"},\"positionPortsPm\":{\"nomPanneau\":\"PANNEAU_B\",\"positionPort\":1,\"referenceBoitierPm\":\"BOITIER_B\",\"referencePmBytel\":\"SI758074\"}}],\"ajoutsPortsPon\":[{\"cartePon\":{\"modeleCarte\":\"m2\",\"position\":\"3\"},\"codificationVolume\":\"EDANN2\",\"maxOntId\":128,\"positionFoNro\":\"1/07/11/09\",\"positionPortPon\":{\"nomOLT\":\"777nomOlt\",\"position\":1,\"positionCarte\":2},\"referenceCableRenvoiNro\":\"R/DEG01\",\"sfpListeTechnologieCompatible\":[\"GPON\",\"XGPON\"]}],\"listeTypeEquipementImpacte\":[\"PM\",\"OLT\"],\"migrationsPortsPm\":[{\"positionPortPmCible\":{\"nomPanneau\":\"B1-M1-MODULE-HZTL-BOUY\",\"positionPort\":1,\"referenceBoitierPm\":\"BPI000010\",\"referencePmBytel\":\"SI758071\"},\"positionPortPmSource\":{\"nomPanneau\":\"B1-M1-MODULE-HZTL-BOUY\",\"positionPort\":1,\"referenceBoitierPm\":\"BPI000010\",\"referencePmBytel\":\"SI758074\"}}],\"modificationsPortsPm\":[{\"liensPortPonCible\":[{\"nomOLT\":\"777nomOlt\",\"positionCartePon\":2,\"positionPortPon\":2}],\"liensPortPonSource\":[{\"nomOLT\":\"777nomOlt\",\"positionCartePon\":2,\"positionPortPon\":1}],\"positionPortPm\":{\"nomPanneau\":\"B1-M1-MODULE-HZTL-BOUY\",\"positionPort\":1,\"referenceBoitierPm\":\"BPI000010\",\"referencePmBytel\":\"SI758074\"}}],\"modificationsPortsPon\":[{\"positionPortPon\":{\"nomOLT\":\"777nomOlt\",\"position\":2,\"positionCarte\":2},\"sfpListeTechnologieCompatible\":[\"XGPON\"]}],\"numeroGCR\":\"GCR-12345678\",\"suppressionsPortsPm\":[{\"positionPortsPm\":[{\"nomPanneau\":\"PANNEAU_E\",\"positionPort\":1,\"referenceBoitierPm\":\"BOITIER_E\",\"referencePmBytel\":\"SI758074\"}]}],\"typeVieReseau\":\"PON128\"}","idOperationVieReseau":"8b75de58-4b5b-44d1-9df2-0a1c527714da","listeClientImpacte":[],"numeroGCR":"GCR-12345678","statut":"EN_COURS_MAJ_REFERENTIEL","typeOperationVieReseau":"PON128"}],"retour":{"resultat":"OK"}}' HTTPCode='200' Headers='connection: close,content-type: application/json,Date: Wed, 17 Mar 2021 17:09:23 GMT,Server: Jetty(9.3.10.v20160621),Content-Type: application/json'
18:09:23.783|DEBUG|qtp726950788-18|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL200_MajReferentiel|FIN_ACTIVITE|Retour[resultat=OK, categorie=<null>(default), diagnostic=<null>(default), libelle=<null>(default), activite=<null>(default)]
18:09:23.783|DEBUG|qtp726950788-18|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL002_FormaterReponseModification|DEBUT_ACTIVITE|PE0529_BL002_FormaterReponseModification
18:09:23.783|DEBUG|qtp726950788-18|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL002_FormaterReponseModification|FIN_ACTIVITE|Retour[resultat=OK, categorie=<null>(default), diagnostic=<null>(default), libelle=<null>(default), activite=<null>(default)]
18:09:23.783|INFO |qtp726950788-18|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_OperationVieReseau.startPutProcess|REPONSE_EMISE|
18:09:23.783|INFO |qtp726950788-18|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_OperationVieReseau.startPutProcess|FIN_PROCESSUS|Retour[resultat=OK, categorie=<null>(default), diagnostic=<null>(default), libelle=<null>(default), activite=<null>(default)],EN_ATTENTE
18:09:23.783|DEBUG|[qtp726950788-18] - IdProcess='ec96ca4dc2724ce6ae1b9f3060c0fadd' MSG='END START' MSGID='b3e53b13-a485-4ce9-93e0-83e02281b2c6' ProcessName='PE0529_OperationVieReseau'
18:09:23.783|DEBUG|[qtp726950788-18] - IdProcess='ec96ca4dc2724ce6ae1b9f3060c0fadd' MSG='Passivating the process.' MsgId='b3e53b13-a485-4ce9-93e0-83e02281b2c6'
18:09:23.794|DEBUG|[ProcessThread - ec96ca4dc2724ce6ae1b9f3060c0fadd] - IdProcess='ec96ca4dc2724ce6ae1b9f3060c0fadd' MSG='Asynchronous ContinueProcess received.' MsgId='b3e53b13-a485-4ce9-93e0-83e02281b2c6'
18:09:23.794|DEBUG|[ProcessThread - ec96ca4dc2724ce6ae1b9f3060c0fadd] - IdProcess='ec96ca4dc2724ce6ae1b9f3060c0fadd' MSG='CONTINUE PROCESS' MSGID='b3e53b13-a485-4ce9-93e0-83e02281b2c6' ProcessName='PE0529_OperationVieReseau'
18:09:23.794|DEBUG|[ProcessThread - ec96ca4dc2724ce6ae1b9f3060c0fadd] - HTTP METHOD='PUT' MSG='REST CONTINUE PROCESS' MSGID='b3e53b13-a485-4ce9-93e0-83e02281b2c6'
18:09:23.794|INFO |ProcessThread - ec96ca4dc2724ce6ae1b9f3060c0fadd|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_OperationVieReseau.continuePutProcess|DEBUT_CONTINUER_PROCESSUS|
18:09:23.794|DEBUG|ProcessThread - ec96ca4dc2724ce6ae1b9f3060c0fadd|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL400_Provisioning|DEBUT_ACTIVITE|PE0529_BL400_Provisioning
18:09:23.794|INFO |ProcessThread - ec96ca4dc2724ce6ae1b9f3060c0fadd|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL400_Provisioning|REQUETE_EMISE|operationVieReseauLireUn Headers='X-Oauth2-Habilit: SPIRIT_STARK,X-Request-Id: X-Request-Id,X-Request-Id-Spirit: b3e53b13-a485-4ce9-93e0-83e02281b2c6,X-Source: tesla,X-Process: PE0529_OperationVieReseau,X-Process-Id-Spirit: ec96ca4dc2724ce6ae1b9f3060c0fadd' Parameters='idOperationVieReseau = 8b75de58-4b5b-44d1-9df2-0a1c527714da'
18:09:23.794|DEBUG|ProcessThread - ec96ca4dc2724ce6ae1b9f3060c0fadd|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL400_Provisioning|TECHNIQUE|AbstractInternalRESTConnector : URL (Name=REXConnectorURL0 AccesPoint=http://SPIRIT-saab-JPA-1:8080/ExecuteGenericRequestV2) gotten from the load balancer.
18:09:23.804|INFO |ProcessThread - ec96ca4dc2724ce6ae1b9f3060c0fadd|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL400_Provisioning|REPONSE_RECUE|operationVieReseauLireUn Body='{"listeOperationVieReseau":[{"dateCreation":"2021-03-17T18:07:34.199+0100","dateExecution":"2021-03-17T18:09:23.516+0100","dateModification":"2021-03-17T18:09:23.516+0100","donneeBrute":"{\"ajoutsPortsPm\":[{\"boitierPm\":{\"nomPmTechnique\":\"ABCD123\",\"referenceBoitierPm\":\"BOITIER_D\"},\"liensPortPon\":[{\"nomOLT\":\"777nomOlt\",\"positionCartePon\":2,\"positionPortPon\":1}],\"panneauPm\":{\"nomPanneau\":\"PANNEAU_D\"},\"positionPortsPm\":{\"nomPanneau\":\"PANNEAU_B\",\"positionPort\":1,\"referenceBoitierPm\":\"BOITIER_B\",\"referencePmBytel\":\"SI758074\"}}],\"ajoutsPortsPon\":[{\"cartePon\":{\"modeleCarte\":\"m2\",\"position\":\"3\"},\"codificationVolume\":\"EDANN2\",\"maxOntId\":128,\"positionFoNro\":\"1/07/11/09\",\"positionPortPon\":{\"nomOLT\":\"777nomOlt\",\"position\":1,\"positionCarte\":2},\"referenceCableRenvoiNro\":\"R/DEG01\",\"sfpListeTechnologieCompatible\":[\"GPON\",\"XGPON\"]}],\"listeTypeEquipementImpacte\":[\"PM\",\"OLT\"],\"migrationsPortsPm\":[{\"positionPortPmCible\":{\"nomPanneau\":\"B1-M1-MODULE-HZTL-BOUY\",\"positionPort\":1,\"referenceBoitierPm\":\"BPI000010\",\"referencePmBytel\":\"SI758071\"},\"positionPortPmSource\":{\"nomPanneau\":\"B1-M1-MODULE-HZTL-BOUY\",\"positionPort\":1,\"referenceBoitierPm\":\"BPI000010\",\"referencePmBytel\":\"SI758074\"}}],\"modificationsPortsPm\":[{\"liensPortPonCible\":[{\"nomOLT\":\"777nomOlt\",\"positionCartePon\":2,\"positionPortPon\":2}],\"liensPortPonSource\":[{\"nomOLT\":\"777nomOlt\",\"positionCartePon\":2,\"positionPortPon\":1}],\"positionPortPm\":{\"nomPanneau\":\"B1-M1-MODULE-HZTL-BOUY\",\"positionPort\":1,\"referenceBoitierPm\":\"BPI000010\",\"referencePmBytel\":\"SI758074\"}}],\"modificationsPortsPon\":[{\"positionPortPon\":{\"nomOLT\":\"777nomOlt\",\"position\":2,\"positionCarte\":2},\"sfpListeTechnologieCompatible\":[\"XGPON\"]}],\"numeroGCR\":\"GCR-12345678\",\"suppressionsPortsPm\":[{\"positionPortsPm\":[{\"nomPanneau\":\"PANNEAU_E\",\"positionPort\":1,\"referenceBoitierPm\":\"BOITIER_E\",\"referencePmBytel\":\"SI758074\"}]}],\"typeVieReseau\":\"PON128\"}","idOperationVieReseau":"8b75de58-4b5b-44d1-9df2-0a1c527714da","listeClientImpacte":[],"numeroGCR":"GCR-12345678","statut":"EN_COURS_MAJ_REFERENTIEL","typeOperationVieReseau":"PON128"}],"retour":{"resultat":"OK"}}' HTTPCode='200' Headers='connection: close,content-type: application/json,Date: Wed, 17 Mar 2021 17:09:23 GMT,Server: Jetty(9.3.10.v20160621),Content-Type: application/json'
18:09:23.813|INFO |ProcessThread - ec96ca4dc2724ce6ae1b9f3060c0fadd|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL400_Provisioning|REQUETE_EMISE|ressourceLireUn Headers='X-Oauth2-Habilit: SPIRIT_STARK,X-Request-Id: X-Request-Id,X-Request-Id-Spirit: b3e53b13-a485-4ce9-93e0-83e02281b2c6,X-Source: tesla,X-Process: PE0529_OperationVieReseau,X-Process-Id-Spirit: ec96ca4dc2724ce6ae1b9f3060c0fadd' Parameters='idRessource = SI758074||BPI000010||B1-M1-MODULE-HZTL-BOUY||1,typeRessource = PORT_PM'
18:09:23.813|DEBUG|ProcessThread - ec96ca4dc2724ce6ae1b9f3060c0fadd|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL400_Provisioning|TECHNIQUE|AbstractInternalRESTConnector : URL (Name=RESConnectorURL0 AccesPoint=http://SPIRIT-saab-JPA-1:8080/ExecuteGenericRequestV2) gotten from the load balancer.
18:09:23.824|INFO |ProcessThread - ec96ca4dc2724ce6ae1b9f3060c0fadd|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL400_Provisioning|REPONSE_RECUE|ressourceLireUn Body='{"listeRessource":[{"dateCreation":"2021-03-01T11:27:39.948+0100","dateModification":"2021-03-01T11:27:39.948+0100","idRessource":"SI758074||BPI000010||B1-M1-MODULE-HZTL-BOUY||1","idRessourceLie":"client2","nomPanneau":"B1-M1-MODULE-HZTL-BOUY","positionPortPm":1,"referenceBoitierPm":"BPI000010","referencePmBytel":"SI758074","statut":"LIBRE","typeRessource":"PORT_PM"}],"retour":{"resultat":"OK"}}' HTTPCode='200' Headers='connection: close,content-type: application/json,Date: Wed, 17 Mar 2021 17:09:23 GMT,Server: Jetty(9.3.10.v20160621),Content-Type: application/json'
18:09:23.826|INFO |ProcessThread - ec96ca4dc2724ce6ae1b9f3060c0fadd|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL400_Provisioning|REQUETE_EMISE|pmCompositeLireUnParReferencePmBytel Headers='X-Oauth2-Habilit: SPIRIT_STARK,X-Request-Id: X-Request-Id,X-Request-Id-Spirit: b3e53b13-a485-4ce9-93e0-83e02281b2c6,X-Source: tesla,X-Process: PE0529_OperationVieReseau,X-Process-Id-Spirit: ec96ca4dc2724ce6ae1b9f3060c0fadd' Parameters='referencePmBytel = SI758074'
18:09:23.826|DEBUG|ProcessThread - ec96ca4dc2724ce6ae1b9f3060c0fadd|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL400_Provisioning|TECHNIQUE|AbstractInternalRESTConnector : URL (Name=RESConnectorURL0 AccesPoint=http://SPIRIT-saab-JPA-1:8080/ExecuteGenericRequestV2) gotten from the load balancer.
18:09:23.846|INFO |ProcessThread - ec96ca4dc2724ce6ae1b9f3060c0fadd|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL400_Provisioning|REPONSE_RECUE|pmCompositeLireUnParReferencePmBytel Body='{"pmComposite":{"adressePM":{"accessible":"BAT-1 / ESC-1 / ETAGE-SOUS-SOL-01","autresInformations":"CLIENT","batiment":"A","codeAccesImmeuble":"Digicode + Clef facteur","codeAccesSousSol":"Clefs à lagence","codeImmeuble":"pas de digicode, pas de gardien.","codeInsee":"30042","codeLocal":"SOUS SOL","codePostal":"30140","commentairePm":"AdresseTemporaire","complement":"A","contactsImmeuble":"M Toto Titi 0101010101","contactsSyndic":"AGENCE DE LA HALLE AGENCE DE LA HALLE 01 01 01 01 01  ","coordonneePmx":"637443.56","coordonneePmy":"6885895.5","hexacle":"AD95566ZAB","infoObtentionCle":"M. TOTO 0101010101","localisation":"SRO-BPI-978742","nomVoie":"DANDUZE","numeroVoie":"1579","referenceConsultationNative":"YVFI_LOTZAPM_78160_20171110-YVFI01-Lot02","rivoli":"048A","typeProjectionGeographique":"RGF93","typeVoie":"ROUTE","typeZone":"ZMD","ville":"BOISSET-ET-GAUJAC"},"codeOperateurImmeuble":"SFRA","dateCreation":"2020-12-07T12:19:15.184+0100","dateDernierImport":"2021-03-17T18:09:23.577+0100","dateModification":"2021-02-23T10:28:19.168+0100","dateOuvertureCommerciale":"2020-12-12T00:00:00.000+0100","etatDeploiement":"OUVERT_COMMERCIALEMENT","listeBoitierPM":{"BOITIER_D":{"dateCreation":"2021-03-17T18:09:23.577+0100","dateModification":"2021-03-17T18:09:23.577+0100","listePanneauPM":{"PANNEAU_B":{"dateCreation":"2021-03-17T18:09:23.577+0100","dateModification":"2021-03-17T18:09:23.577+0100","listePortPM":{"1":{"dateCreation":"2021-03-17T18:09:23.577+0100","dateModification":"2021-03-17T18:09:23.577+0100","listeLienPortPMPon":{"777nomOlt_2_1":{"portPon":{"nomOLT":"777nomOlt","positionCartePON":2,"positionPortPON":1},"statutDeploiement":"OPERATIONNEL"}},"position":1,"statutTechnique":"OPERATIONNEL","surchargePortPM":{"statutBlocage":"INACTIF","statutExploitation":"OPERATIONNEL"}}},"nomPanneau":"PANNEAU_B","statutTechnique":"OPERATIONNEL"}},"nomPmTechnique":"ABCD123","referenceBoitierPm":"BOITIER_D","statutTechnique":"OPERATIONNEL","surchargeBoitierPM":{"statutBlocage":"INACTIF"}},"BPI000010":{"dateCreation":"2020-12-07T12:19:15.184+0100","dateModification":"2020-12-07T12:19:15.184+0100","listePanneauPM":{"B1-M1-MODULE-HZTL-BOUY":{"baie":"A_1","dateCreation":"2020-12-07T12:19:15.184+0100","dateModification":"2020-12-07T12:19:15.184+0100","face":1,"listePortPM":{"1":{"dateCreation":"2020-12-07T12:19:15.184+0100","dateModification":"2021-03-17T18:09:23.577+0100","listeLienPortPMPon":{"777nomOlt_2_2":{"portPon":{"nomOLT":"777nomOlt","positionCartePON":2,"positionPortPON":2},"statutDeploiement":"OPERATIONNEL"},"OLT0018_1_1":{"portPon":{"nomOLT":"OLT0018","positionCartePON":1,"positionPortPON":1},"statutDeploiement":"OPERATIONNEL"}},"nomCoupleur":"SPL-1*8-01-BOU","position":1,"statutTechnique":"OPERATIONNEL","surchargePortPM":{"statutBlocage":"INACTIF","statutExploitation":"OPERATIONNEL"}}},"nomPanneau":"B1-M1-MODULE-HZTL-BOUY","positionAlpha":"K","statutTechnique":"OPERATIONNEL","tiroir":"01"}},"nomPmTechnique":"PT 1505","referenceBoitierPm":"BPI000010","statutTechnique":"OPERATIONNEL","surchargeBoitierPM":{"commentaireBlocage":"blocage prise clients suite a operation vie reseau le 14:23:05.517Z","dateActivation":"2021-02-23T15:23:05.567+0100","statutBlocage":"ACTIF"}}},"modeFinancementPM":"COFI","operateurAdduction":"ZTD SFR","referencePmBytel":"SI758074","referencePmOi":"ABC-BPI-1234","referencePrestationPM":"VOFI-BOIL02","statutTechnique":"OPERATIONNEL","surchargePM":{"dateDebutQuarantaineImport":"2021-03-17T18:09:23.726+0100","statutBlocage":"INACTIF"},"typeEmplacementPM":"PMI","typeIngenierie":"MonofibreZMD"},"retour":{"resultat":"OK"}}' HTTPCode='200' Headers='connection: close,content-type: application/json,Date: Wed, 17 Mar 2021 17:09:23 GMT,Server: Jetty(9.3.10.v20160621),Content-Type: application/json'
18:09:23.851|INFO |ProcessThread - ec96ca4dc2724ce6ae1b9f3060c0fadd|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL400_Provisioning|REQUETE_EMISE|ressourceLireUn Headers='X-Oauth2-Habilit: SPIRIT_STARK,X-Request-Id: X-Request-Id,X-Request-Id-Spirit: b3e53b13-a485-4ce9-93e0-83e02281b2c6,X-Source: tesla,X-Process: PE0529_OperationVieReseau,X-Process-Id-Spirit: ec96ca4dc2724ce6ae1b9f3060c0fadd' Parameters='idRessource = SI758074||BPI000010||B1-M1-MODULE-HZTL-BOUY||1,typeRessource = PORT_PM'
18:09:23.851|DEBUG|ProcessThread - ec96ca4dc2724ce6ae1b9f3060c0fadd|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL400_Provisioning|TECHNIQUE|AbstractInternalRESTConnector : URL (Name=RESConnectorURL0 AccesPoint=http://SPIRIT-saab-JPA-1:8080/ExecuteGenericRequestV2) gotten from the load balancer.
18:09:23.861|INFO |ProcessThread - ec96ca4dc2724ce6ae1b9f3060c0fadd|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL400_Provisioning|REPONSE_RECUE|ressourceLireUn Body='{"listeRessource":[{"dateCreation":"2021-03-01T11:27:39.948+0100","dateModification":"2021-03-01T11:27:39.948+0100","idRessource":"SI758074||BPI000010||B1-M1-MODULE-HZTL-BOUY||1","idRessourceLie":"client2","nomPanneau":"B1-M1-MODULE-HZTL-BOUY","positionPortPm":1,"referenceBoitierPm":"BPI000010","referencePmBytel":"SI758074","statut":"LIBRE","typeRessource":"PORT_PM"}],"retour":{"resultat":"OK"}}' HTTPCode='200' Headers='connection: close,content-type: application/json,Date: Wed, 17 Mar 2021 17:09:23 GMT,Server: Jetty(9.3.10.v20160621),Content-Type: application/json'
18:09:23.863|INFO |ProcessThread - ec96ca4dc2724ce6ae1b9f3060c0fadd|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL400_Provisioning|REQUETE_EMISE|operationVieReseauModifierStatut Body='{"idOperationVieReseau":"8b75de58-4b5b-44d1-9df2-0a1c527714da","statut":"TRAITE_OK"}' Headers='X-Oauth2-Habilit: SPIRIT_STARK,Content-Type: application/json,X-Request-Id: X-Request-Id,X-Request-Id-Spirit: b3e53b13-a485-4ce9-93e0-83e02281b2c6,X-Source: tesla,X-Process: PE0529_OperationVieReseau,X-Process-Id-Spirit: ec96ca4dc2724ce6ae1b9f3060c0fadd'
18:09:23.863|DEBUG|ProcessThread - ec96ca4dc2724ce6ae1b9f3060c0fadd|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL400_Provisioning|TECHNIQUE|AbstractInternalRESTConnector : URL (Name=REXConnectorURL0 AccesPoint=http://SPIRIT-saab-JPA-1:8080/ExecuteGenericRequestV2) gotten from the load balancer.
18:09:23.877|INFO |ProcessThread - ec96ca4dc2724ce6ae1b9f3060c0fadd|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL400_Provisioning|REPONSE_RECUE|operationVieReseauModifierStatut Body='{"retour":{"resultat":"OK"}}' HTTPCode='200' Headers='connection: close,content-type: application/json,Date: Wed, 17 Mar 2021 17:09:23 GMT,Server: Jetty(9.3.10.v20160621),Content-Type: application/json'
18:09:23.878|DEBUG|ProcessThread - ec96ca4dc2724ce6ae1b9f3060c0fadd|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL400_Provisioning|FIN_ACTIVITE|Retour[resultat=OK, categorie=<null>(default), diagnostic=<null>(default), libelle=<null>(default), activite=<null>(default)]
18:09:23.878|DEBUG|ProcessThread - ec96ca4dc2724ce6ae1b9f3060c0fadd|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL005_GererErreurPROSPERModification|DEBUT_ACTIVITE|PE0529_BL005_GererErreurPROSPERModification
18:09:23.878|DEBUG|ProcessThread - ec96ca4dc2724ce6ae1b9f3060c0fadd|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_BL005_GererErreurPROSPERModification|FIN_ACTIVITE|Retour[resultat=OK, categorie=<null>(default), diagnostic=<null>(default), libelle=<null>(default), activite=<null>(default)]
18:09:23.878|INFO |ProcessThread - ec96ca4dc2724ce6ae1b9f3060c0fadd|b3e53b13-a485-4ce9-93e0-83e02281b2c6|PE0529_OperationVieReseau|ec96ca4dc2724ce6ae1b9f3060c0fadd|PE0529_OperationVieReseau.continuePutProcess|FIN_CONTINUER_PROCESSUS|Retour[resultat=OK, categorie=<null>(default), diagnostic=<null>(default), libelle=<null>(default), activite=<null>(default)]
18:09:23.878|DEBUG|[ProcessThread - ec96ca4dc2724ce6ae1b9f3060c0fadd] - IdProcess='ec96ca4dc2724ce6ae1b9f3060c0fadd' MSG='END CONTINUE PROCESS' MSGID='b3e53b13-a485-4ce9-93e0-83e02281b2c6' ProcessName='PE0529_OperationVieReseau'


## Nominal OK - GET

### Request:

```
GET http://10.136.132.71:8001/operations-vies-reseaux/4be5c483-0c68-439b-9ec0-61378731ebb7 HTTP/1.1
Accept-Encoding: gzip,deflate
X-Action-Id: X-Action-Id
X-Source: X-Source
X-Request-Id: X-Request-Id
X-Message-Id: X-Message-Id
X-Process: X-Process
Host: 10.136.132.71:8001
Connection: Keep-Alive
User-Agent: Apache-HttpClient/4.1.1 (java 1.5)
```

### Response:

```
HTTP/1.1 200 OK
Date: Wed, 17 Mar 2021 17:01:13 GMT
Content-Type: application/json
Server: Jetty(9.3.10.v20160621)
X-Request-Id-Spirit: 1d1778de-3eaa-4872-8286-f31d16bd0d7f
Content-Length: 1876

{
  "ajoutsPortsPm": [
    {
      "boitierPm": {
        "nomPmTechnique": "ABCD123",
        "referenceBoitierPm": "BOITIER_D"
      },
      "liensPortPon": [
        {
          "nomOLT": "777nomOlt",
          "positionCartePon": 2,
          "positionPortPon": 1
        }
      ],
      "panneauPm": {
        "nomPanneau": "PANNEAU_D"
      },
      "positionPortsPm": {
        "nomPanneau": "PANNEAU_B",
        "positionPort": 1,
        "referenceBoitierPm": "BOITIER_B",
        "referencePmBytel": "SI758074"
      }
    }
  ],
  "ajoutsPortsPon": [
    {
      "cartePon": {
        "modeleCarte": "m2",
        "position": "3"
      },
      "codificationVolume": "EDANN2",
      "maxOntId": 128,
      "positionFoNro": "1/07/11/09",
      "positionPortPon": {
        "nomOLT": "777nomOlt",
        "position": 1,
        "positionCarte": 2
      },
      "referenceCableRenvoiNro": "R/DEG01",
      "sfpListeTechnologieCompatible": [
        "GPON",
        "XGPON"
      ]
    }
  ],
  "dateCreation": "2021-03-17T17:33:09.271+0100",
  "dateExecution": "2021-03-17T17:33:23.028+0100",
  "idOperationVieReseau": "4be5c483-0c68-439b-9ec0-61378731ebb7",
  "listeTypeEquipementImpacte": [
    "PM",
    "OLT"
  ],
  "migrationsPortsPm": [
    {
      "positionPortPmCible": {
        "nomPanneau": "B1-M1-MODULE-HZTL-BOUY",
        "positionPort": 1,
        "referenceBoitierPm": "BPI000010",
        "referencePmBytel": "SI758071"
      },
      "positionPortPmSource": {
        "nomPanneau": "B1-M1-MODULE-HZTL-BOUY",
        "positionPort": 1,
        "referenceBoitierPm": "BPI000010",
        "referencePmBytel": "SI758074"
      }
    }
  ],
  "modificationsPortsPm": [
    {
      "liensPortPonCible": [
        {
          "nomOLT": "777nomOlt",
          "positionCartePon": 2,
          "positionPortPon": 2
        }
      ],
      "liensPortPonSource": [
        {
          "nomOLT": "777nomOlt",
          "positionCartePon": 2,
          "positionPortPon": 1
        }
      ],
      "positionPortPm": {
        "nomPanneau": "B1-M1-MODULE-HZTL-BOUY",
        "positionPort": 1,
        "referenceBoitierPm": "BPI000010",
        "referencePmBytel": "SI758074"
      }
    }
  ],
  "modificationsPortsPon": [
    {
      "positionPortPon": {
        "nomOLT": "777nomOlt",
        "position": 2,
        "positionCarte": 2
      },
      "sfpListeTechnologieCompatible": [
        "XGPON"
      ]
    }
  ],
  "numeroGCR": "GCR-12345678",
  "statut": "TRAITE_OK",
  "suppressionsPortsPm": [
    {
      "positionPortsPm": [
        {
          "nomPanneau": "PANNEAU_E",
          "positionPort": 1,
          "referenceBoitierPm": "BOITIER_E",
          "referencePmBytel": "SI758074"
        }
      ]
    }
  ],
  "suppressionsPortsPon": [],
  "typeVieReseau": "PON128"
}
```

### Logs:

18:05:02.767|DEBUG|[qtp726950788-20] - MSG='Request ExecuteGenericRequest received from 10.42.99.135' MSGID='50f8acd3-b7a2-4894-9893-89c68a3352aa'
18:05:02.768|DEBUG|[qtp726950788-20] - MSG='LaunchProcess received.' MsgId='50f8acd3-b7a2-4894-9893-89c68a3352aa'
18:05:02.768|DEBUG|[qtp726950788-20] - MSG='Getting the process type for operation 'PE0529_OperationVieReseau'. '
18:05:02.768|DEBUG|[qtp726950788-20] - MSG='Getting a new process for operation 'PE0529_OperationVieReseau'.'
18:05:02.768|DEBUG|[qtp726950788-20] - MSG='Getting the process type for operation 'PE0529_OperationVieReseau'. '
18:05:02.768|DEBUG|[qtp726950788-20] - IdClient='null' IdProcess='fe6552745aa343faa2364eb0b46bb498' MSG='START' MSGID='50f8acd3-b7a2-4894-9893-89c68a3352aa' ProcessName='PE0529_OperationVieReseau' Request='Input request is empty.'
18:05:02.768|DEBUG|[qtp726950788-20] - HTTP METHOD='GET' MSG='REST START PROCESS' MSGID='50f8acd3-b7a2-4894-9893-89c68a3352aa'
18:05:02.768|DEBUG|[qtp726950788-20] - MSG='RestApiProcessSkeleton : USER ROLES (  ) gotten from the request headers.' MSGID='50f8acd3-b7a2-4894-9893-89c68a3352aa'
18:05:02.768|DEBUG|[qtp726950788-20] - MSG='RestApiProcessSkeleton : USER SCOPES (  ) gotten from the request headers.' MSGID='50f8acd3-b7a2-4894-9893-89c68a3352aa'
18:05:02.768|INFO |qtp726950788-20|50f8acd3-b7a2-4894-9893-89c68a3352aa|PE0529_OperationVieReseau|fe6552745aa343faa2364eb0b46bb498|PE0529_OperationVieReseau.startGetProcess|DEBUT_PROCESSUS|[X-Source=X-Source],[X-Request-Id=X-Request-Id],[X-Entry-URI=/operations-vies-reseaux/4be5c483-0c68-439b-9ec0-61378731ebb7],[X-Action-Id=X-Action-Id],[X-Message-Id=X-Message-Id],[X-Process=X-Process]
18:05:02.768|INFO |qtp726950788-20|50f8acd3-b7a2-4894-9893-89c68a3352aa|PE0529_OperationVieReseau|fe6552745aa343faa2364eb0b46bb498|PE0529_OperationVieReseau.startGetProcess|REQUETE_RECUE DynamicParameters='4be5c483-0c68-439b-9ec0-61378731ebb7' Headers='Accept: text/xml,X-Source: X-Source,X-Request-Id: X-Request-Id,User-Agent: Apache-HttpClient/4.1.1 (java 1.5),Connection: keep-alive,Host: SPIRIT-tesla-PRA-1:8080,Accept-Encoding: gzip,deflate,Pragma: no-cache,X-Entry-URI: /operations-vies-reseaux/4be5c483-0c68-439b-9ec0-61378731ebb7,X-Action-Id: X-Action-Id,Cache-Control: no-cache,X-Message-Id: X-Message-Id,X-Process: X-Process,Content-Type: text/xml'
18:05:02.768|DEBUG|qtp726950788-20|50f8acd3-b7a2-4894-9893-89c68a3352aa|PE0529_OperationVieReseau|fe6552745aa343faa2364eb0b46bb498|PE0529_BL001_VerifierDonneesConsultation|DEBUT_ACTIVITE|PE0529_BL001_VerifierDonneesConsultation
18:05:02.768|DEBUG|qtp726950788-20|50f8acd3-b7a2-4894-9893-89c68a3352aa|PE0529_OperationVieReseau|fe6552745aa343faa2364eb0b46bb498|PE0529_BL001_VerifierDonneesConsultation|FIN_ACTIVITE|Retour[resultat=OK, categorie=<null>(default), diagnostic=<null>(default), libelle=<null>(default), activite=<null>(default)]
18:05:02.769|DEBUG|qtp726950788-20|50f8acd3-b7a2-4894-9893-89c68a3352aa|PE0529_OperationVieReseau|fe6552745aa343faa2364eb0b46bb498|PE0529_BL100_ConsulterOperationVDR|DEBUT_ACTIVITE|PE0529_BL100_ConsulterOperationVDR
18:05:02.769|INFO |qtp726950788-20|50f8acd3-b7a2-4894-9893-89c68a3352aa|PE0529_OperationVieReseau|fe6552745aa343faa2364eb0b46bb498|PE0529_BL100_ConsulterOperationVDR|REQUETE_EMISE|operationVieReseauLireUn Headers='X-Oauth2-Habilit: SPIRIT_STARK,X-Request-Id: X-Request-Id,X-Request-Id-Spirit: 50f8acd3-b7a2-4894-9893-89c68a3352aa,X-Source: tesla,X-Process: PE0529_OperationVieReseau,X-Process-Id-Spirit: fe6552745aa343faa2364eb0b46bb498' Parameters='idOperationVieReseau = 4be5c483-0c68-439b-9ec0-61378731ebb7'
18:05:02.769|DEBUG|qtp726950788-20|50f8acd3-b7a2-4894-9893-89c68a3352aa|PE0529_OperationVieReseau|fe6552745aa343faa2364eb0b46bb498|PE0529_BL100_ConsulterOperationVDR|TECHNIQUE|AbstractInternalRESTConnector : URL (Name=REXConnectorURL0 AccesPoint=http://SPIRIT-saab-JPA-1:8080/ExecuteGenericRequestV2) gotten from the load balancer.
18:05:02.786|INFO |qtp726950788-20|50f8acd3-b7a2-4894-9893-89c68a3352aa|PE0529_OperationVieReseau|fe6552745aa343faa2364eb0b46bb498|PE0529_BL100_ConsulterOperationVDR|REPONSE_RECUE|operationVieReseauLireUn Body='{"listeOperationVieReseau":[{"dateCreation":"2021-03-17T17:33:09.271+0100","dateExecution":"2021-03-17T17:33:23.028+0100","dateModification":"2021-03-17T17:33:23.420+0100","donneeBrute":"{\"ajoutsPortsPm\":[{\"boitierPm\":{\"nomPmTechnique\":\"ABCD123\",\"referenceBoitierPm\":\"BOITIER_D\"},\"liensPortPon\":[{\"nomOLT\":\"777nomOlt\",\"positionCartePon\":2,\"positionPortPon\":1}],\"panneauPm\":{\"nomPanneau\":\"PANNEAU_D\"},\"positionPortsPm\":{\"nomPanneau\":\"PANNEAU_B\",\"positionPort\":1,\"referenceBoitierPm\":\"BOITIER_B\",\"referencePmBytel\":\"SI758074\"}}],\"ajoutsPortsPon\":[{\"cartePon\":{\"modeleCarte\":\"m2\",\"position\":\"3\"},\"codificationVolume\":\"EDANN2\",\"maxOntId\":128,\"positionFoNro\":\"1/07/11/09\",\"positionPortPon\":{\"nomOLT\":\"777nomOlt\",\"position\":1,\"positionCarte\":2},\"referenceCableRenvoiNro\":\"R/DEG01\",\"sfpListeTechnologieCompatible\":[\"GPON\",\"XGPON\"]}],\"listeTypeEquipementImpacte\":[\"PM\",\"OLT\"],\"migrationsPortsPm\":[{\"positionPortPmCible\":{\"nomPanneau\":\"B1-M1-MODULE-HZTL-BOUY\",\"positionPort\":1,\"referenceBoitierPm\":\"BPI000010\",\"referencePmBytel\":\"SI758071\"},\"positionPortPmSource\":{\"nomPanneau\":\"B1-M1-MODULE-HZTL-BOUY\",\"positionPort\":1,\"referenceBoitierPm\":\"BPI000010\",\"referencePmBytel\":\"SI758074\"}}],\"modificationsPortsPm\":[{\"liensPortPonCible\":[{\"nomOLT\":\"777nomOlt\",\"positionCartePon\":2,\"positionPortPon\":2}],\"liensPortPonSource\":[{\"nomOLT\":\"777nomOlt\",\"positionCartePon\":2,\"positionPortPon\":1}],\"positionPortPm\":{\"nomPanneau\":\"B1-M1-MODULE-HZTL-BOUY\",\"positionPort\":1,\"referenceBoitierPm\":\"BPI000010\",\"referencePmBytel\":\"SI758074\"}}],\"modificationsPortsPon\":[{\"positionPortPon\":{\"nomOLT\":\"777nomOlt\",\"position\":2,\"positionCarte\":2},\"sfpListeTechnologieCompatible\":[\"XGPON\"]}],\"numeroGCR\":\"GCR-12345678\",\"suppressionsPortsPm\":[{\"positionPortsPm\":[{\"nomPanneau\":\"PANNEAU_E\",\"positionPort\":1,\"referenceBoitierPm\":\"BOITIER_E\",\"referencePmBytel\":\"SI758074\"}]}],\"typeVieReseau\":\"PON128\"}","idOperationVieReseau":"4be5c483-0c68-439b-9ec0-61378731ebb7","listeClientImpacte":[],"numeroGCR":"GCR-12345678","statut":"TRAITE_OK","typeOperationVieReseau":"PON128"}],"retour":{"resultat":"OK"}}' HTTPCode='200' Headers='connection: close,content-type: application/json,Date: Wed, 17 Mar2021 17:05:02 GMT,Server: Jetty(9.3.10.v20160621),Content-Type: application/json'
18:05:02.793|DEBUG|qtp726950788-20|50f8acd3-b7a2-4894-9893-89c68a3352aa|PE0529_OperationVieReseau|fe6552745aa343faa2364eb0b46bb498|PE0529_BL100_ConsulterOperationVDR|FIN_ACTIVITE|Retour[resultat=OK, categorie=<null>(default), diagnostic=<null>(default), libelle=<null>(default), activite=<null>(default)]
18:05:02.793|DEBUG|qtp726950788-20|50f8acd3-b7a2-4894-9893-89c68a3352aa|PE0529_OperationVieReseau|fe6552745aa343faa2364eb0b46bb498|PE0529_BL002_FormaterReponseConsultation|DEBUT_ACTIVITE|PE0529_BL002_FormaterReponseConsultation
18:05:02.797|DEBUG|qtp726950788-20|50f8acd3-b7a2-4894-9893-89c68a3352aa|PE0529_OperationVieReseau|fe6552745aa343faa2364eb0b46bb498|PE0529_BL002_FormaterReponseConsultation|FIN_ACTIVITE|Retour[resultat=OK, categorie=<null>(default), diagnostic=<null>(default), libelle=<null>(default), activite=<null>(default)]
18:05:02.798|INFO |qtp726950788-20|50f8acd3-b7a2-4894-9893-89c68a3352aa|PE0529_OperationVieReseau|fe6552745aa343faa2364eb0b46bb498|PE0529_OperationVieReseau.startGetProcess|REPONSE_EMISE|{"ajoutsPortsPm":[{"boitierPm":{"nomPmTechnique":"ABCD123","referenceBoitierPm":"BOITIER_D"},"liensPortPon":[{"nomOLT":"777nomOlt","positionCartePon":2,"positionPortPon":1}],"panneauPm":{"nomPanneau":"PANNEAU_D"},"positionPortsPm":{"nomPanneau":"PANNEAU_B","positionPort":1,"referenceBoitierPm":"BOITIER_B","referencePmBytel":"SI758074"}}],"ajoutsPortsPon":[{"cartePon":{"modeleCarte":"m2","position":"3"},"codificationVolume":"EDANN2","maxOntId":128,"positionFoNro":"1/07/11/09","positionPortPon":{"nomOLT":"777nomOlt","position":1,"positionCarte":2},"referenceCableRenvoiNro":"R/DEG01","sfpListeTechnologieCompatible":["GPON","XGPON"]}],"dateCreation":"2021-03-17T17:33:09.271+0100","dateExecution":"2021-03-17T17:33:23.028+0100","idOperationVieReseau":"4be5c483-0c68-439b-9ec0-61378731ebb7","listeTypeEquipementImpacte":["PM","OLT"],"migrationsPortsPm":[{"positionPortPmCible":{"nomPanneau":"B1-M1-MODULE-HZTL-BOUY","positionPort":1,"referenceBoitierPm":"BPI000010","referencePmBytel":"SI758071"},"positionPortPmSource":{"nomPanneau":"B1-M1-MODULE-HZTL-BOUY","positionPort":1,"referenceBoitierPm":"BPI000010","referencePmBytel":"SI758074"}}],"modificationsPortsPm":[{"liensPortPonCible":[{"nomOLT":"777nomOlt","positionCartePon":2,"positionPortPon":2}],"liensPortPonSource":[{"nomOLT":"777nomOlt","positionCartePon":2,"positionPortPon":1}],"positionPortPm":{"nomPanneau":"B1-M1-MODULE-HZTL-BOUY","positionPort":1,"referenceBoitierPm":"BPI000010","referencePmBytel":"SI758074"}}],"modificationsPortsPon":[{"positionPortPon":{"nomOLT":"777nomOlt","position":2,"positionCarte":2},"sfpListeTechnologieCompatible":["XGPON"]}],"numeroGCR":"GCR-12345678","statut":"TRAITE_OK","suppressionsPortsPm":[{"positionPortsPm":[{"nomPanneau":"PANNEAU_E","positionPort":1,"referenceBoitierPm":"BOITIER_E","referencePmBytel":"SI758074"}]}],"suppressionsPortsPon":[],"typeVieReseau":"PON128"}
18:05:02.798|INFO |qtp726950788-20|50f8acd3-b7a2-4894-9893-89c68a3352aa|PE0529_OperationVieReseau|fe6552745aa343faa2364eb0b46bb498|PE0529_OperationVieReseau.startGetProcess|FIN_PROCESSUS|Retour[resultat=OK, categorie=<null>(default), diagnostic=<null>(default), libelle=<null>(default), activite=<null>(default)]