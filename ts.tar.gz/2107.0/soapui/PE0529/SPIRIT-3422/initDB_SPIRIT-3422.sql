TRUNCATE rex.operation_vie_reseau;
DELETE FROM res.pm_composite WHERE reference_pm_bytel='PM_VABF_21';
INSERT INTO res.idx_reference_pm_bytel_by_pm_oi JSON '{"reference_pm_oi": "ABC-BPI-1234","reference_pm_bytel": "PM_VABF_21"}';
INSERT INTO res.pm_composite JSON '{
  "reference_pm_bytel": "PM_VABF_21",
  "reference_boitier_pm": "BOITIER_PM_21",
  "nom_panneau": "PanneauFundao21",
  "port_position": 22,
  "adresse_pm": {
    "accessible": "BAT-1 / ESC-1 / ETAGE-SOUS-SOL-01",
    "autres_informations": "CLIENT",
    "batiment": "A",
    "code_acces_immeuble": "Digicode + Clef facteur",
    "code_acces_sous_sol": "Clefs à lagence",
    "code_immeuble": "pas de digicode, pas de gardien.",
    "code_insee": "30042",
    "code_local": "SOUS SOL",
    "code_postal": "30140",
    "commentaire_pm": "AdresseTemporaire",
    "complement": "A",
    "contacts_immeuble": "M Toto Titi 0101010101",
    "contacts_syndic": "AGENCE DE LA HALLE AGENCE DE LA HALLE 01 01 01 01 01  ",
    "coordonnee_pm_x": "637443.56",
    "coordonnee_pm_y": "6885895.5",
    "hexacle": "AD95566ZAB",
    "info_obtention_cle": "M. TOTO 0101010101",
    "localisation": "SRO-BPI-978742",
    "nom_voie": "DANDUZE",
    "numero_voie": "1579",
    "reference_consultation_native": "YVFI_LOTZAPM_78160_20171110-YVFI01-Lot02",
    "rivoli": "048A",
    "type_projection_geographique": "RGF93",
    "type_voie": "ROUTE",
    "type_zone": "ZMD",
    "ville": "BOISSET-ET-GAUJAC"
  },
  "boitier_date_creation": "2020-12-07T12:19:15.184+0100",
  "boitier_date_modification": "2020-12-07T12:19:15.184+0100",
  "boitier_nom_pm_technique": "PT 1505",
  "boitier_statut_technique": "OPERATIONNEL",
  "boitier_surcharge": {
    "bpc_commentaire_blocage": "blocage prise clients suite a operation vie reseau le 14:23:05.517Z",
    "bpc_date_activation": "2021-02-23T15:23:05.567+0100",
    "bpc_statut_blocage": "ACTIF"
  },
  "code_operateur_immeuble": "SFRA",
  "date_creation": "2020-12-07T12:19:15.184+0100",
  "date_dernier_import": "2021-02-23T10:28:19.168+0100",
  "date_modification": "2021-02-23T10:28:19.168+0100",
  "date_ouverture_commerciale": "2020-12-12T00:00:00.000+0100",
  "etat_deploiement": "OUVERT_COMMERCIALEMENT",
  "mode_financement_pm": "COFI",
  "operateur_adduction": "ZTD SFR",
  "panneau_baie": "A_1",
  "panneau_date_creation": "2020-12-07T12:19:15.184+0100",
  "panneau_date_modification": "2020-12-07T12:19:15.184+0100",
  "panneau_face": 1,
  "panneau_position_alpha": "K",
  "panneau_statut_technique": "OPERATIONNEL",
  "panneau_tiroir": "01",
  "port_date_creation": "2020-12-07T12:19:15.184+0100",
  "port_date_modification": "2020-12-07T12:19:15.184+0100",
  "port_lien_port_pon_liste": {
    "VABF21PT3_0_1": {
      "nom_olt": "VABF21PT3",
      "position_carte_pon": 0,
      "position_port_pon": 1,
      "statut_deploiement": "OPERATIONNEL"
    }
  },
  "port_nom_coupleur": "SPL-1*8-01-BOU",
  "port_statut_technique": "OPERATIONNEL",
  "port_surcharge": {
    "bpc_statut_blocage": "INACTIF",
    "exploitation_statut": "OPERATIONNEL"
  },
  "reference_pm_oi": "ABC-BPI-1234",
  "reference_prestation_pm": "VOFI-BOIL02",
  "statut_technique": "OPERATIONNEL",
  "surcharge_pm": {
    "bpc_statut_blocage": "INACTIF"
  },
  "type_emplacement_pm": "PMI",
  "type_ingenierie": "MonofibreZMD"
}';

TRUNCATE res.olt_composite;
INSERT INTO res.olt_composite JSON '{
  "nom_olt": "VABF21PT3",
  "carte_type_carte": "CartePON",
  "carte_position": 0,
  "sous_carte_position": 1,
  "carte_date_creation": "2020-12-03T10:50:30.659+0100",
  "carte_date_modification": "2020-12-03T10:50:30.659+0100",
  "carte_modele": "m2",
  "carte_statut_technique": "OPERATIONNEL",
  "carte_surcharge": {
    "bpc_commentaire_blocage": "blocage prise clients suite a operation vie reseau le 14:23:05.517Z",
    "bpc_date_activation": "2021-02-23T15:23:05.554+0100",
    "bpc_statut_blocage": "ACTIF"
  },
  "constructeur": "huawei",
  "date_creation": "2018-12-28T17:03:23.422+0100",
  "date_dernier_import": "2018-12-31T10:57:23.279+0100",
  "date_modification": "2018-12-28T17:05:00.099+0100",
  "ip": "192.168.0.44",
  "modele": "m1",
  "nom_nr": "nomNR",
  "port_pon_codification_volume": "test",
  "port_pon_date_creation": "2020-12-03T10:50:30.659+0100",
  "port_pon_date_modification": "2020-12-03T10:50:30.659+0100",
  "port_pon_max_ontid": 10,
  "port_pon_position_fo_nro": "test",
  "port_pon_reference_cable_renvoi_nro": "test",
  "port_pon_statut_technique": "OPERATIONNEL",
  "port_pon_surcharge": {
    "bpc_statut_blocage": "INACTIF",
    "port_pon_debit_garantie_capacite_allouee": 10,
    "port_pon_liste_technologie_autorisee": ["GPON","XPON"]
  },
  "statut_technique": "OPERATIONNEL",
  "surcharge_olt": {
    "olt_nom_omc": "OMC_NCE",
    "bpc_statut_blocage": "INACTIF",
    "olt_version_interface_echange": "qos_convergee"
  }
}';

INSERT INTO res.ressource_port_pm JSON '{
  "reference_pm_bytel": "PM_VABF_21",
  "reference_boitier_pm": "BOITIER_PM_21",
  "nom_panneau_pm": "PanneauFundao21",
  "position_port_pm": 22,
  "date_creation": "2021-03-01 10:27:39.948Z",
  "date_modification": "2021-03-01 10:27:39.948Z",
  "id_ressource_lie": "client2",
  "id_st": null,
  "statut": "ALLOUE"
}';

delete from res.ressource_raccordement where id_ressource = 'client2';
insert into res.ressource_raccordement json '{"id_ressource": "client2", "adresse_donnee": null, "code_acces_technique": null, "date_creation": "2019-06-16 15:45:22.000Z", "date_derniere_declaration_ont_installe": null, "date_modification": "2019-06-17 15:45:22.000Z", "id_ressource_lie": null, "id_st": "2556553", "no_serie_ont_installe": null, "nom_nr": null, "nrm_id": null, "statut": "xxx", "type_raccordement": "FTTH", "type_technologie_pon": null}';

TRUNCATE res.cfg_modele_carte;
insert into res.cfg_modele_carte json '{"type": "CarteP2P", "modele":"m2"}';
insert into res.cfg_modele_carte json '{"type": "CartePON", "modele":"m1"}';
insert into res.cfg_modele_carte json '{"type": "CartePON", "modele":"m2"}';

