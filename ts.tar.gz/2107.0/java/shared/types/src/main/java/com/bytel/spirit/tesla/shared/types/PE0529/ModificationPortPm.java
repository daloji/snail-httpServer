/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.tesla.shared.types.PE0529;

import static java.util.Objects.isNull;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import com.bytel.spirit.common.shared.misc.validation.IValidationConst;
import com.squareup.moshi.Json;

/**
 * Objet modificationPortPm
 *
 * @author JCHEVRON
 * @version ($Revision$ $Date$)
 */
public class ModificationPortPm implements Serializable
{
  private static final long serialVersionUID = -7966328414213052507L;

  /**
   * Position du port PM
   */
  @Valid
  @Json(name = "positionPortPm")
  @NotNull(message = IValidationConst.ATTRIBUT_OBLIGATOIRE_MANQUANT)
  private PositionPortPm _positionPortPm;

  /**
   * Tableau de Lien Port Pon OLT source adducté au Port PM
   */
  @Valid
  @Json(name = "liensPortPonSource")
  @NotEmpty(message = IValidationConst.ATTRIBUT_OBLIGATOIRE_MANQUANT)
  private List<LienPortPon> _liensPortPonSource;

  /**
   * Tableau Lien Port Pon OLT Cible adducté au Port PM
   */
  @Valid
  @Json(name = "liensPortPonCible")
  @NotEmpty(message = IValidationConst.ATTRIBUT_OBLIGATOIRE_MANQUANT)
  private List<LienPortPon> _liensPortPonCible;

  /**
   * Constructeur par copier
   *
   * @param modificationPortPm_p
   *          Objet à copier
   */
  public ModificationPortPm(ModificationPortPm modificationPortPm_p)
  {
    if (!isNull(modificationPortPm_p))
    {
      _positionPortPm = modificationPortPm_p._positionPortPm;
      _liensPortPonSource = modificationPortPm_p._liensPortPonSource;
      _liensPortPonCible = modificationPortPm_p._liensPortPonCible;
    }
  }

  /**
   * Constructeur complet
   *
   * @param positionPortPm_p
   *          Position du port PM
   * @param liensPortPonSource_p
   *          Tableau de Lien Port Pon OLT source adducté au Port PM
   * @param liensPortPonCible_p
   *          Tableau Lien Port Pon OLT Cible adducté au Port PM
   */
  public ModificationPortPm(PositionPortPm positionPortPm_p, List<LienPortPon> liensPortPonSource_p, List<LienPortPon> liensPortPonCible_p)
  {
    _positionPortPm = positionPortPm_p;
    _liensPortPonSource = isNull(liensPortPonSource_p) ? null : new ArrayList<>(liensPortPonSource_p);
    _liensPortPonCible = isNull(liensPortPonCible_p) ? null : new ArrayList<>(liensPortPonCible_p);
  }

  @Override
  public boolean equals(Object o_p)
  {
    if (this == o_p)
    {
      return true;
    }
    if (o_p == null || getClass() != o_p.getClass())
    {
      return false;
    }
    ModificationPortPm that = (ModificationPortPm) o_p;
    return Objects.equals(_positionPortPm, that._positionPortPm) && Objects.equals(_liensPortPonSource, that._liensPortPonSource) && Objects.equals(_liensPortPonCible, that._liensPortPonCible);
  }

  /**
   * @return the liensPortPonCible
   */
  public List<LienPortPon> getLiensPortPonCible()
  {
    return isNull(_liensPortPonCible) ? null : Collections.unmodifiableList(_liensPortPonCible);
  }

  /**
   * @return the liensPortPonSource
   */
  public List<LienPortPon> getLiensPortPonSource()
  {
    return isNull(_liensPortPonSource) ? null : Collections.unmodifiableList(_liensPortPonSource);
  }

  /**
   * @return the positionPortPm
   */
  public PositionPortPm getPositionPortPm()
  {
    return _positionPortPm;
  }

  @Override
  public int hashCode()
  {
    return Objects.hash(_positionPortPm, _liensPortPonSource, _liensPortPonCible);
  }

  /**
   * @param liensPortPonCible_p
   *          the liensPortPonCible to set
   */
  public void setLiensPortPonCible(List<LienPortPon> liensPortPonCible_p)
  {
    _liensPortPonCible = isNull(liensPortPonCible_p) ? null : new ArrayList<LienPortPon>(liensPortPonCible_p);
  }

  /**
   * @param liensPortPonSource_p
   *          the liensPortPonSource to set
   */
  public void setLiensPortPonSource(List<LienPortPon> liensPortPonSource_p)
  {
    _liensPortPonSource = isNull(liensPortPonSource_p) ? null : new ArrayList<>(liensPortPonSource_p);
  }

  /**
   * @param positionPortPm_p
   *          the positionPortPm to set
   */
  public void setPositionPortPm(PositionPortPm positionPortPm_p)
  {
    _positionPortPm = positionPortPm_p;
  }

  @Override
  public String toString()
  {
    return "ModificationPortPm [" + "_positionPortPm=" + _positionPortPm + ", _liensPortPonSource=" + _liensPortPonSource + ", _liensPortPonCible=" + _liensPortPonCible + "]"; // $NON-NLS-1$ // $NON-NLS-2$ // $NON-NLS-3$ // $NON-NLS-4$ // $NON-NLS-5$
  }
}
