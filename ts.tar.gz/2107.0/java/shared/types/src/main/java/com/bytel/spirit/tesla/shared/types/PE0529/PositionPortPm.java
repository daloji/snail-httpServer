/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.tesla.shared.types.PE0529;

import static java.util.Objects.isNull;

import java.io.Serializable;
import java.util.Objects;
import java.util.StringJoiner;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.bytel.spirit.common.shared.misc.validation.IValidationConst;
import com.squareup.moshi.Json;

/**
 * Objet positionPortPm
 *
 * @author JCHEVRON
 * @version ($Revision$ $Date$)
 */
public class PositionPortPm implements Serializable
{
  private static final long serialVersionUID = -1786580914520224847L;

  /**
   * Position du port PM
   */
  @Json(name = "positionPort")
  @NotNull(message = IValidationConst.ATTRIBUT_OBLIGATOIRE_MANQUANT)
  @Min(value = 0, message = IValidationConst.FORMAT_ATTRIBUT_NON_RESPECTE)
  private Integer _positionPort;

  /**
   * Nom du Panneau PM
   */
  @Json(name = "nomPanneau")
  @NotBlank(message = IValidationConst.ATTRIBUT_OBLIGATOIRE_MANQUANT)
  private String _nomPanneau;

  /**
   * Référence BoitierPM
   */
  @Json(name = "referenceBoitierPm")
  @NotBlank(message = IValidationConst.ATTRIBUT_OBLIGATOIRE_MANQUANT)
  private String _referenceBoitierPm;

  /**
   * Nom du PM Bytel
   */
  @Json(name = "referencePmBytel")
  @NotBlank(message = IValidationConst.ATTRIBUT_OBLIGATOIRE_MANQUANT)
  private String _referencePmBytel;

  /**
   * Nom du coupleur
   */
  @Json(name = "nomCoupleur")
  private String _nomCoupleur;

  /**
   * Id Liaison, cet attribut est déprécié sur l’interface SPIRIT
   */
  @Json(name = "idLiaison")
  private String _idLiaison;

  /**
   * Constructeur
   *
   * @param positionPort_p
   *          Position du port PM
   * @param nomPanneau_p
   *          Nom du Panneau PM
   * @param referenceBoitierPm_p
   *          Référence BoitierPM
   * @param referencePmBytel_p
   *          Nom du PM Bytel
   */
  public PositionPortPm(Integer positionPort_p, String nomPanneau_p, String referenceBoitierPm_p, String referencePmBytel_p)
  {
    _positionPort = positionPort_p;
    _nomPanneau = nomPanneau_p;
    _referenceBoitierPm = referenceBoitierPm_p;
    _referencePmBytel = referencePmBytel_p;
  }

  /**
   * Constructeur par copie
   *
   * @param positionPortPm_p
   *          Objet à copier
   */
  public PositionPortPm(PositionPortPm positionPortPm_p)
  {
    if (!isNull(positionPortPm_p))
    {
      _positionPort = positionPortPm_p._positionPort;
      _nomPanneau = positionPortPm_p._nomPanneau;
      _referenceBoitierPm = positionPortPm_p._referenceBoitierPm;
      _referencePmBytel = positionPortPm_p._referencePmBytel;
      _nomCoupleur = positionPortPm_p._nomCoupleur;
      _idLiaison = positionPortPm_p._idLiaison;
    }
  }

  @Override
  public boolean equals(Object o_p)
  {
    if (this == o_p)
    {
      return true;
    }
    if (o_p == null || getClass() != o_p.getClass())
    {
      return false;
    }
    PositionPortPm that = (PositionPortPm) o_p;
    return Objects.equals(_positionPort, that._positionPort) && Objects.equals(_nomPanneau, that._nomPanneau) && Objects.equals(_referenceBoitierPm, that._referenceBoitierPm) && Objects.equals(_referencePmBytel, that._referencePmBytel) && Objects.equals(_nomCoupleur, that._nomCoupleur) && Objects.equals(_idLiaison, that._idLiaison);
  }

  /**
   * @return the idLiaison
   */
  public String getIdLiaison()
  {
    return _idLiaison;
  }

  /**
   * @return the nomCoupleur
   */
  public String getNomCoupleur()
  {
    return _nomCoupleur;
  }

  /**
   * @return the nomPanneau
   */
  public String getNomPanneau()
  {
    return _nomPanneau;
  }

  /**
   * @return the positionPort
   */
  public Integer getPositionPort()
  {
    return _positionPort;
  }

  /**
   * @return the referenceBoitierPm
   */
  public String getReferenceBoitierPm()
  {
    return _referenceBoitierPm;
  }

  /**
   * @return the referencePmBytel
   */
  public String getReferencePmBytel()
  {
    return _referencePmBytel;
  }

  @Override
  public int hashCode()
  {
    return Objects.hash(_positionPort, _nomPanneau, _referenceBoitierPm, _referencePmBytel, _nomCoupleur, _idLiaison);
  }

  /**
   * @param idLiaison_p
   *          the idLiaison to set
   */
  public void setIdLiaison(String idLiaison_p)
  {
    _idLiaison = idLiaison_p;
  }

  /**
   * @param nomCoupleur_p
   *          the nomCoupleur to set
   */
  public void setNomCoupleur(String nomCoupleur_p)
  {
    _nomCoupleur = nomCoupleur_p;
  }

  /**
   * @param nomPanneau_p
   *          the nomPanneau to set
   */
  public void setNomPanneau(String nomPanneau_p)
  {
    _nomPanneau = nomPanneau_p;
  }

  /**
   * @param positionPort_p
   *          the positionPort to set
   */
  public void setPositionPort(Integer positionPort_p)
  {
    _positionPort = positionPort_p;
  }

  /**
   * @param referenceBoitierPm_p
   *          the referenceBoitierPm to set
   */
  public void setReferenceBoitierPm(String referenceBoitierPm_p)
  {
    _referenceBoitierPm = referenceBoitierPm_p;
  }

  /**
   * @param referencePmBytel_p
   *          the referencePmBytel to set
   */
  public void setReferencePmBytel(String referencePmBytel_p)
  {
    _referencePmBytel = referencePmBytel_p;
  }

  /**
   * Creation de l'identifiant ressource d'un port PM
   *
   * @return l'id de la ressource du port PM
   */
  public String toRessourceId()
  {
    StringJoiner joiner = new StringJoiner("||"); //$NON-NLS-1$
    joiner.add(_referencePmBytel);
    joiner.add(_referenceBoitierPm);
    joiner.add(_nomPanneau);
    joiner.add(String.valueOf(_positionPort));
    return joiner.toString();
  }

  @Override
  public String toString()
  {
    return "PositionPortPm [_positionPort=" + _positionPort + ", _nomPanneau=" + _nomPanneau + ", _nomCoupleur=" + _nomCoupleur + ", _idLiaison=" + _idLiaison + ", _referenceBoitierPm=" + _referenceBoitierPm + ", _referencePmBytel=" + _referencePmBytel + "]"; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$
  }


  /**
   * Functional compare this PositionPortPm object to another PositionPortPm object
   * Two PositionPortPm objects are functionally equals if the following instance variables are equals:
   * _positionPort
   * _nomPanneau
   * _referenceBoitierPm
   * _referencePmBytel
   *
   * @param positionPortPm_p
   * @return true if functional equals, false otherwise
   */
  public boolean isFunctionallyEquals(PositionPortPm positionPortPm_p)
  {
    if (positionPortPm_p == null)
    {
      return false;
    }

    return Objects.equals(_positionPort, positionPortPm_p._positionPort) && Objects.equals(_nomPanneau, positionPortPm_p._nomPanneau) && Objects.equals(_referenceBoitierPm, positionPortPm_p._referenceBoitierPm) && Objects.equals(_referencePmBytel, positionPortPm_p._referencePmBytel);
  }

}
