/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.tesla.shared.types.PE0529.response;

import static java.util.Objects.isNull;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import com.bytel.ravel.common.json.annotations.RavelLocalDateTimeFormat;
import com.bytel.ravel.common.json.format.impl.IsoShortOffsetDateTimeWithMillis;
import com.bytel.spirit.common.shared.misc.validation.IValidationConst;
import com.bytel.spirit.tesla.shared.types.PE0529.AjoutPortPm;
import com.bytel.spirit.tesla.shared.types.PE0529.AjoutPortPon;
import com.bytel.spirit.tesla.shared.types.PE0529.MigrationPortPm;
import com.bytel.spirit.tesla.shared.types.PE0529.ModificationPortPm;
import com.bytel.spirit.tesla.shared.types.PE0529.ModificationPortPon;
import com.bytel.spirit.tesla.shared.types.PE0529.SuppressionPortPm;
import com.bytel.spirit.tesla.shared.types.PE0529.SuppressionPortPon;
import com.squareup.moshi.Json;

/**
 * Reponse d'une requête GET sur le processus PE0529_OperationVieReseau.
 *
 * @author JCHEVRON
 * @version ($Revision$ $Date$)
 */
public class PE0529_GetResponse implements Serializable
{
  private static final long serialVersionUID = 1810627109969161364L;

  /**
   * Id de l’Opération Vie Reseau à consulter
   */
  @Json(name = "idOperationVieReseau") //$NON-NLS-1$
  @NotBlank(message = IValidationConst.ATTRIBUT_OBLIGATOIRE_MANQUANT)
  private String _idOperationVieReseau;

  /**
   * Id de l’Opération Vie Reseau à consulter
   */
  @Json(name = "statut") //$NON-NLS-1$

  @NotBlank(message = IValidationConst.ATTRIBUT_OBLIGATOIRE_MANQUANT)
  @Pattern(regexp = "ACQUITTE|EN_COURS_MAJ_REFERENTIEL|EN_COURS_PROVISIONING|OBSOLETE|TRAITE_OK|TRAITE_NOK", message = IValidationConst.FORMAT_ATTRIBUT_NON_RESPECTE) //$NON-NLS-1$
  private String _statut;

  /**
   * Date de création de l’opération
   */
  @Json(name = "dateCreation") //$NON-NLS-1$
  @NotNull(message = IValidationConst.ATTRIBUT_OBLIGATOIRE_MANQUANT)
  @RavelLocalDateTimeFormat(IsoShortOffsetDateTimeWithMillis.class)
  private LocalDateTime _dateCreation;

  /**
   * Date de réception de la demande l’exécution de l’opération vie de réseau
   */
  @Json(name = "dateExecution") //$NON-NLS-1$
  @RavelLocalDateTimeFormat(IsoShortOffsetDateTimeWithMillis.class)
  private LocalDateTime _dateExecution;

  /**
   * Date de réception de la demande d’annulation de l’opération vie de réseau
   */
  @Json(name = "dateAnnulation") //$NON-NLS-1$
  @RavelLocalDateTimeFormat(IsoShortOffsetDateTimeWithMillis.class)
  private LocalDateTime _dateAnnulation;

  /**
   * Le GCR de l’opération
   */
  @Json(name = "numeroGCR") //$NON-NLS-1$
  private String _numeroGCR;

  /**
   * Identifiant de l’opération précédente associée ou de l’opération à rollbacker
   */
  @Json(name = "idOperationVieReseauLie") //$NON-NLS-1$
  private String _idOperationVieReseauLie;

  /**
   * Le type de l’opération vie de réseau
   */
  @Json(name = "typeVieReseau") //$NON-NLS-1$
  @NotBlank(message = IValidationConst.ATTRIBUT_OBLIGATOIRE_MANQUANT)
  private String _typeVieReseau;

  /**
   * La liste des types des équipements impactés dans l’opération Vie Reseau
   */
  @Json(name = "listeTypeEquipementImpacte") //$NON-NLS-1$
  @NotEmpty(message = IValidationConst.ATTRIBUT_OBLIGATOIRE_MANQUANT)
  private List<String> _listeTypeEquipementImpacte;

  /**
   * Liste des Port PM a swapper sur des nouvelles position
   */
  @Json(name = "migrationsPortsPm") //$NON-NLS-1$
  @Valid
  private List<MigrationPortPm> _migrationsPortsPm;

  /**
   * Liste des Port PM pour lesquelles il faut changer le Port Pon d’adduction sur l’OLT
   */
  @Json(name = "modificationsPortsPm") //$NON-NLS-1$
  @Valid
  private List<ModificationPortPm> _modificationsPortsPm;

  /**
   * Liste des Port PM à ajouter
   */
  @Json(name = "ajoutsPortsPm") //$NON-NLS-1$
  @Valid
  private List<AjoutPortPm> _ajoutsPortsPm;

  /**
   * Liste des port Pm à supprimer
   */
  @Json(name = "suppressionsPortsPm") //$NON-NLS-1$
  @Valid
  private List<SuppressionPortPm> _suppressionsPortsPm;

  /**
   * Les port Pon à ajouter à une carte d’un OLT
   */
  @Json(name = "ajoutsPortsPon") //$NON-NLS-1$
  @Valid
  private List<AjoutPortPon> _ajoutsPortsPon;

  /**
   * Liste des Port Pon à supprimer sur une carte
   */
  @Json(name = "suppressionsPortsPon")
  @Valid
  private List<SuppressionPortPon> _suppressionsPortsPon;

  /**
   * Liste des modifications à apporter à des Ports Pon d’une carte
   */
  @Json(name = "modificationsPortsPon") //$NON-NLS-1$
  @Valid
  private List<ModificationPortPon> _modificationsPortsPon;

  /**
   * Constructeur utilisé depuis la réponse REX LireUn
   *
   * @param idOperationVieReseau_p
   *          the idOperationVieReseau.
   * @param statut_p
   *          the statut.
   * @param dateCreation_p
   *          the dateCreation.
   * @param dateAnnulation_p
   *          the dateAnnulation.
   * @param dateExecution_p
   *          the dateExecution.
   * @param typeOperationVieReseau_p
   *          the typeOperationVieReseau.
   * @param idOperationVieReseauLie_p
   *          the idOperationVieReseauLie.
   * @param numeroGCR_p
   *          the numeroGCR.
   */
  public PE0529_GetResponse(String idOperationVieReseau_p, String statut_p, LocalDateTime dateCreation_p, LocalDateTime dateAnnulation_p, LocalDateTime dateExecution_p, String typeOperationVieReseau_p, String idOperationVieReseauLie_p, String numeroGCR_p)
  {
    super();
    _idOperationVieReseau = idOperationVieReseau_p;
    _statut = statut_p;
    _dateCreation = dateCreation_p;
    _dateExecution = dateExecution_p;
    _dateAnnulation = dateAnnulation_p;
    _numeroGCR = numeroGCR_p;
    _idOperationVieReseauLie = idOperationVieReseauLie_p;
    _typeVieReseau = typeOperationVieReseau_p;
  }

  @Override
  public boolean equals(Object o_p)
  {
    if (this == o_p)
    {
      return true;
    }
    if (o_p == null || getClass() != o_p.getClass())
    {
      return false;
    }
    PE0529_GetResponse that = (PE0529_GetResponse) o_p;
    return Objects.equals(_idOperationVieReseau, that._idOperationVieReseau) && Objects.equals(_statut, that._statut) && Objects.equals(_dateCreation, that._dateCreation) && Objects.equals(_dateExecution, that._dateExecution) && Objects.equals(_dateAnnulation, that._dateAnnulation) && Objects.equals(_numeroGCR, that._numeroGCR) && Objects.equals(_idOperationVieReseauLie, that._idOperationVieReseauLie) && Objects.equals(_typeVieReseau, that._typeVieReseau) && Objects.equals(_listeTypeEquipementImpacte, that._listeTypeEquipementImpacte) && Objects.equals(_migrationsPortsPm, that._migrationsPortsPm) && Objects.equals(_modificationsPortsPm, that._modificationsPortsPm) && Objects.equals(_ajoutsPortsPm, that._ajoutsPortsPm) && Objects.equals(_suppressionsPortsPm, that._suppressionsPortsPm)
        && Objects.equals(_ajoutsPortsPon, that._ajoutsPortsPon) && Objects.equals(_suppressionsPortsPon, that._suppressionsPortsPon) && Objects.equals(_modificationsPortsPon, that._modificationsPortsPon);
  }

  /**
   * @return the ajoutsPortsPm
   */
  public List<AjoutPortPm> getAjoutsPortsPm()
  {
    return isNull(_ajoutsPortsPm) ? null : Collections.unmodifiableList(_ajoutsPortsPm);
  }

  /**
   * @return the ajoutsPortsPon
   */
  public List<AjoutPortPon> getAjoutsPortsPon()
  {
    return isNull(_ajoutsPortsPon) ? null : Collections.unmodifiableList(_ajoutsPortsPon);
  }

  /**
   * @return the dateAnnulation
   */
  public LocalDateTime getDateAnnulation()
  {
    return _dateAnnulation;
  }

  /**
   * @return the dateCreation
   */
  public LocalDateTime getDateCreation()
  {
    return _dateCreation;
  }

  /**
   * @return the dateExecution
   */
  public LocalDateTime getDateExecution()
  {
    return _dateExecution;
  }

  /**
   * @return the idOperationVieReseau
   */
  public String getIdOperationVieReseau()
  {
    return _idOperationVieReseau;
  }

  /**
   * @return the idOperationVieReseauLie
   */
  public String getIdOperationVieReseauLie()
  {
    return _idOperationVieReseauLie;
  }

  /**
   * @return the listeTypeEquipementImpacte
   */
  public List<String> getListeTypeEquipementImpacte()
  {
    return isNull(_listeTypeEquipementImpacte) ? null : Collections.unmodifiableList(_listeTypeEquipementImpacte);
  }

  /**
   * @return the migrationsPortsPm
   */
  public List<MigrationPortPm> getMigrationsPortsPm()
  {
    return isNull(_migrationsPortsPm) ? null : Collections.unmodifiableList(_migrationsPortsPm);
  }

  /**
   * @return the modificationsPortsPm
   */
  public List<ModificationPortPm> getModificationsPortsPm()
  {
    return isNull(_modificationsPortsPm) ? null : Collections.unmodifiableList(_modificationsPortsPm);
  }

  /**
   * @return the modificationsPortsPon
   */
  public List<ModificationPortPon> getModificationsPortsPon()
  {
    return isNull(_modificationsPortsPon) ? null : Collections.unmodifiableList(_modificationsPortsPon);
  }

  /**
   * @return the numeroGCR
   */
  public String getNumeroGCR()
  {
    return _numeroGCR;
  }

  /**
   * @return the statut
   */
  public String getStatut()
  {
    return _statut;
  }

  /**
   * @return the suppressionsPortsPm
   */
  public List<SuppressionPortPm> getSuppressionsPortsPm()
  {
    return isNull(_suppressionsPortsPm) ? null : Collections.unmodifiableList(_suppressionsPortsPm);
  }

  /**
   * @return the suppressionsPortsPon
   */
  public List<SuppressionPortPon> getSuppressionsPortsPon()
  {
    return isNull(_suppressionsPortsPon) ? null : Collections.unmodifiableList(_suppressionsPortsPon);
  }

  /**
   * @return the typeVieReseau
   */
  public String getTypeVieReseau()
  {
    return _typeVieReseau;
  }

  @Override
  public int hashCode()
  {
    return Objects.hash(_idOperationVieReseau, _statut, _dateCreation, _dateExecution, _dateAnnulation, _numeroGCR, _idOperationVieReseauLie, _typeVieReseau, _listeTypeEquipementImpacte, _migrationsPortsPm, _modificationsPortsPm, _ajoutsPortsPm, _suppressionsPortsPm, _ajoutsPortsPon, _suppressionsPortsPon, _modificationsPortsPon);
  }

  /**
   * @param ajoutsPortsPm_p
   *          the ajoutsPortsPm to set
   */
  public void setAjoutsPortsPm(List<AjoutPortPm> ajoutsPortsPm_p)
  {
    _ajoutsPortsPm = isNull(ajoutsPortsPm_p) ? null : new ArrayList<>(ajoutsPortsPm_p);
  }

  /**
   * @param ajoutsPortsPon_p
   *          the ajoutsPortsPon to set
   */
  public void setAjoutsPortsPon(List<AjoutPortPon> ajoutsPortsPon_p)
  {
    _ajoutsPortsPon = isNull(ajoutsPortsPon_p) ? null : new ArrayList<>(ajoutsPortsPon_p);
  }

  /**
   * @param dateAnnulation_p
   *          the dateAnnulation to set
   */
  public void setDateAnnulation(LocalDateTime dateAnnulation_p)
  {
    _dateAnnulation = dateAnnulation_p;
  }

  /**
   * @param dateCreation_p
   *          the dateCreation to set
   */
  public void setDateCreation(LocalDateTime dateCreation_p)
  {
    _dateCreation = dateCreation_p;
  }

  /**
   * @param dateExecution_p
   *          the dateExecution to set
   */
  public void setDateExecution(LocalDateTime dateExecution_p)
  {
    _dateExecution = dateExecution_p;
  }

  /**
   * @param idOperationVieReseau_p
   *          the idOperationVieReseau to set
   */
  public void setIdOperationVieReseau(String idOperationVieReseau_p)
  {
    _idOperationVieReseau = idOperationVieReseau_p;
  }

  /**
   * @param idOperationVieReseauLie_p
   *          the idOperationVieReseauLie to set
   */
  public void setIdOperationVieReseauLie(String idOperationVieReseauLie_p)
  {
    _idOperationVieReseauLie = idOperationVieReseauLie_p;
  }

  /**
   * @param listeTypeEquipementImpacte_p
   *          the listeTypeEquipementImpacte to set
   */
  public void setListeTypeEquipementImpacte(List<String> listeTypeEquipementImpacte_p)
  {
    _listeTypeEquipementImpacte = isNull(listeTypeEquipementImpacte_p) ? null : new ArrayList<>(listeTypeEquipementImpacte_p);
  }

  /**
   * @param migrationsPortsPm_p
   *          the migrationsPortsPm to set
   */
  public void setMigrationsPortsPm(List<MigrationPortPm> migrationsPortsPm_p)
  {
    _migrationsPortsPm = isNull(migrationsPortsPm_p) ? null : new ArrayList<>(migrationsPortsPm_p);
  }

  /**
   * @param modificationsPortsPm_p
   *          the modificationsPortsPm to set
   */
  public void setModificationsPortsPm(List<ModificationPortPm> modificationsPortsPm_p)
  {
    _modificationsPortsPm = isNull(modificationsPortsPm_p) ? null : new ArrayList<>(modificationsPortsPm_p);
  }

  /**
   * @param modificationsPortsPon_p
   *          the modificationsPortsPon to set
   */
  public void setModificationsPortsPon(List<ModificationPortPon> modificationsPortsPon_p)
  {
    _modificationsPortsPon = isNull(modificationsPortsPon_p) ? null : new ArrayList<>(modificationsPortsPon_p);
  }

  /**
   * @param numeroGCR_p
   *          the numeroGCR to set
   */
  public void setNumeroGCR(String numeroGCR_p)
  {
    _numeroGCR = numeroGCR_p;
  }

  /**
   * @param statut_p
   *          the statut to set
   */
  public void setStatut(String statut_p)
  {
    _statut = statut_p;
  }

  /**
   * @param suppressionsPortsPm_p
   *          the suppressionsPortsPm to set
   */
  public void setSuppressionsPortsPm(List<SuppressionPortPm> suppressionsPortsPm_p)
  {
    _suppressionsPortsPm = isNull(suppressionsPortsPm_p) ? null : new ArrayList<>(suppressionsPortsPm_p);
  }

  /**
   * @param suppressionsPortsPon_p
   *          the suppressionsPortsPon to set
   */
  public void setSuppressionsPortsPon(List<SuppressionPortPon> suppressionsPortsPon_p)
  {
    _suppressionsPortsPon = isNull(suppressionsPortsPon_p) ? null : new ArrayList<>(suppressionsPortsPon_p);
  }

  /**
   * @param typeVieReseau_p
   *          the typeVieReseau to set
   */
  public void setTypeVieReseau(String typeVieReseau_p)
  {
    _typeVieReseau = typeVieReseau_p;
  }

  @Override
  public String toString()
  {
    return "PE0529_GetResponse [" + "_idOperationVieReseau=" + _idOperationVieReseau + ", _statut=" + _statut + ", _dateCreation=" + _dateCreation + ", _dateExecution=" + _dateExecution + ", _dateAnnulation=" + _dateAnnulation + ", _numeroGCR=" + _numeroGCR + ", _idOperationVieReseauLie=" + _idOperationVieReseauLie + ", _typeVieReseau=" + _typeVieReseau + ", _listeTypeEquipementImpacte=" + _listeTypeEquipementImpacte + ", _migrationsPortsPm=" + _migrationsPortsPm + ", _modificationsPortsPm=" + _modificationsPortsPm + ", _ajoutsPortsPm=" + _ajoutsPortsPm + ", _suppressionsPortsPm=" + _suppressionsPortsPm + ", _ajoutsPortsPon=" + _ajoutsPortsPon + ", _suppressionsPortsPon=" + _suppressionsPortsPon + ", _modificationsPortsPon=" + _modificationsPortsPon + "]"; // $NON-NLS-1$ // $NON-NLS-2$ // $NON-NLS-3$ // $NON-NLS-4$ // $NON-NLS-5$ // $NON-NLS-6$ // $NON-NLS-7$ // $NON-NLS-8$ // $NON-NLS-9$ // $NON-NLS-10$ // $NON-NLS-11$ // $NON-NLS-12$ // $NON-NLS-13$ // $NON-NLS-14$ // $NON-NLS-15$ // $NON-NLS-16$ // $NON-NLS-17$ // $NON-NLS-18$
  }
}
