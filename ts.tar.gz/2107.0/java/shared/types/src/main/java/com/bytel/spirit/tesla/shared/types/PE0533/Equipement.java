/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.tesla.shared.types.PE0533;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import com.bytel.ravel.common.json.annotations.RavelPolymorphism;
import com.bytel.ravel.common.json.annotations.RavelPolymorphismProfil;
import com.bytel.ravel.common.json.annotations.RavelPolymorphisms;
import com.bytel.spirit.common.shared.misc.validation.IValidationConst;
import com.bytel.spirit.common.shared.types.ISAABable;
import com.squareup.moshi.Json;

/**
 * Objet abstrait Equipement
 *
 * @author JCHEVRON
 * @version ($Revision$ $Date$)
 */
@RavelPolymorphisms({ //
    @RavelPolymorphismProfil( //
        name = "STARK", //
        type = "type", //
        value = { //
            @RavelPolymorphism(type = "OLT", clazz = OLT.class), //
            @RavelPolymorphism(type = "PM", clazz = PM.class) //
        } //
    ) //
})
public abstract class Equipement implements ISAABable<com.bytel.spirit.common.shared.saab.rex.Equipement>, Comparable<Object>
{
  /**
   * Type d'equipement
   */
  @Json(name = "type")
  @NotBlank(message = IValidationConst.ATTRIBUT_OBLIGATOIRE_MANQUANT)
  @Pattern(regexp = "OLT|PM", message = IValidationConst.FORMAT_ATTRIBUT_NON_RESPECTE)
  protected String _type;

  /**
   * Constructeur
   *
   * @param type_p
   *          Type d'equipement
   */
  protected Equipement(String type_p)
  {
    _type = type_p;
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    Equipement other = (Equipement) obj;
    if (_type == null)
    {
      if (other._type != null)
      {
        return false;
      }
    }
    else if (!_type.equals(other._type))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the type
   */
  public String getType()
  {
    return _type;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_type == null) ? 0 : _type.hashCode());
    return result;
  }

  /**
   * @param type_p
   *          the type to set
   */
  public void setType(String type_p)
  {
    _type = type_p;
  }

  @Override
  public String toString()
  {
    return "Equipement [_type=" + _type + "]"; //$NON-NLS-1$ //$NON-NLS-2$
  }

}
