/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.tesla.shared.types.PE0529;

import static java.util.Objects.isNull;

import java.io.Serializable;
import java.util.Objects;

import javax.validation.constraints.NotBlank;

import com.bytel.spirit.common.shared.misc.validation.IValidationConst;
import com.squareup.moshi.Json;

/**
 * Objet CartePon
 *
 * @author JCHEVRON
 * @version ($Revision$ $Date$)
 */
public class CartePon implements Serializable
{
  private static final long serialVersionUID = -3136643869601840079L;

  /**
   * Numéro du slot du module optique
   */
  @Json(name = "position")
  @NotBlank(message = IValidationConst.ATTRIBUT_OBLIGATOIRE_MANQUANT)
  private String _position;

  /**
   * Nom du modèle de carte
   */
  @Json(name = "modeleCarte")
  @NotBlank(message = IValidationConst.ATTRIBUT_OBLIGATOIRE_MANQUANT)
  private String _modeleCarte;

  /**
   * Constructeur par copie
   *
   * @param cartePon_p
   *          Objet à copier
   */
  public CartePon(CartePon cartePon_p)
  {
    if (!isNull(cartePon_p))
    {
      _position = cartePon_p._position;
      _modeleCarte = cartePon_p._modeleCarte;
    }
  }

  /**
   * Constructeur
   *
   * @param position_p
   *          Numéro du slot du module optique
   * @param modeleCarte_p
   *          Nom du modèle de carte
   */
  public CartePon(String position_p, String modeleCarte_p)
  {
    _position = position_p;
    _modeleCarte = modeleCarte_p;
  }

  @Override
  public boolean equals(Object o_p)
  {
    if (this == o_p)
    {
      return true;
    }
    if (o_p == null || getClass() != o_p.getClass())
    {
      return false;
    }
    CartePon cartePon = (CartePon) o_p;
    return Objects.equals(_position, cartePon._position) && Objects.equals(_modeleCarte, cartePon._modeleCarte);
  }

  /**
   * @return the modeleCarte
   */
  public String getModeleCarte()
  {
    return _modeleCarte;
  }

  /**
   * @return the position
   */
  public String getPosition()
  {
    return _position;
  }

  @Override
  public int hashCode()
  {
    return Objects.hash(_position, _modeleCarte);
  }

  /**
   * @param modeleCarte_p
   *          the modeleCarte to set
   */
  public void setModeleCarte(String modeleCarte_p)
  {
    _modeleCarte = modeleCarte_p;
  }

  /**
   * @param position_p
   *          the position to set
   */
  public void setPosition(String position_p)
  {
    _position = position_p;
  }

  @Override
  public String toString()
  {
    return "CartePon [" + "_position=" + _position + ", _modeleCarte=" + _modeleCarte + "]"; // $NON-NLS-1$ // $NON-NLS-2$ // $NON-NLS-3$ // $NON-NLS-4$
  }
}
