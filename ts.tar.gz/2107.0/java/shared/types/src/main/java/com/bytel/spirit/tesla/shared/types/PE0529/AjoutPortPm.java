/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.tesla.shared.types.PE0529;

import static java.util.Objects.isNull;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import com.bytel.spirit.common.shared.misc.validation.IValidationConst;
import com.squareup.moshi.Json;

/**
 * Objet ajoutPortPm
 *
 * @author JCHEVRON
 * @version ($Revision$ $Date$)
 */
public class AjoutPortPm implements Serializable
{
  private static final long serialVersionUID = 5368470050535764075L;

  /**
   * Position des port Pm à ajouter
   */
  @Valid
  @Json(name = "positionPortsPm")
  @NotNull(message = IValidationConst.ATTRIBUT_OBLIGATOIRE_MANQUANT)
  private PositionPortPm _positionPortsPm;

  /**
   * Liste des Ports PON adductés au Port PM
   */
  @Valid
  @Json(name = "liensPortPon")
  @NotEmpty(message = IValidationConst.ATTRIBUT_OBLIGATOIRE_MANQUANT)
  private List<LienPortPon> _liensPortPon;

  /**
   * Le panneau PM à ajouter contenant les ports PM à créer
   */
  @Valid
  @Json(name = "panneauPm")
  @NotNull(message = IValidationConst.ATTRIBUT_OBLIGATOIRE_MANQUANT)
  private PanneauPm _panneauPm;

  /**
   * Le boitier PM à ajouter du panneau PM à créer
   */
  @Valid
  @Json(name = "boitierPm")
  @NotNull(message = IValidationConst.ATTRIBUT_OBLIGATOIRE_MANQUANT)
  private BoitierPm _boitierPm;

  /**
   * Constructeur par copie
   *
   * @param ajoutPortPm_p
   *          Objet à copier
   */
  public AjoutPortPm(AjoutPortPm ajoutPortPm_p)
  {
    if (!isNull(ajoutPortPm_p))
    {
      _positionPortsPm = ajoutPortPm_p._positionPortsPm;
      _liensPortPon = ajoutPortPm_p._liensPortPon;
      _panneauPm = ajoutPortPm_p._panneauPm;
      _boitierPm = ajoutPortPm_p._boitierPm;
    }
  }

  /**
   * Constructeur
   *
   * @param positionPortsPm_p
   *          Position des port Pm à ajouter
   * @param liensPortPon_p
   *          Liste des Ports PON adductés au Port PM
   * @param panneauPm_p
   *          Le panneau PM à ajouter contenant les ports PM à créer
   * @param boitierPm_p
   *          Le boitier PM à ajouter du panneau PM à créer
   */
  public AjoutPortPm(PositionPortPm positionPortsPm_p, List<LienPortPon> liensPortPon_p, PanneauPm panneauPm_p, BoitierPm boitierPm_p)
  {
    _positionPortsPm = positionPortsPm_p;
    _liensPortPon = isNull(liensPortPon_p) ? null : new ArrayList<>(liensPortPon_p);
    _panneauPm = panneauPm_p;
    _boitierPm = boitierPm_p;
  }

  @Override
  public boolean equals(Object o_p)
  {
    if (this == o_p)
    {
      return true;
    }
    if (o_p == null || getClass() != o_p.getClass())
    {
      return false;
    }
    AjoutPortPm that = (AjoutPortPm) o_p;
    return Objects.equals(_positionPortsPm, that._positionPortsPm) && Objects.equals(_liensPortPon, that._liensPortPon) && Objects.equals(_panneauPm, that._panneauPm) && Objects.equals(_boitierPm, that._boitierPm);
  }

  /**
   * @return the boitierPm
   */
  public BoitierPm getBoitierPm()
  {
    return _boitierPm;
  }

  /**
   * @return the liensPortPon
   */
  public List<LienPortPon> getLiensPortPon()
  {
    return isNull(_liensPortPon) ? null : Collections.unmodifiableList(_liensPortPon);
  }

  /**
   * @return the panneauPm
   */
  public PanneauPm getPanneauPm()
  {
    return _panneauPm;
  }

  /**
   * @return the positionPortsPm
   */
  public PositionPortPm getPositionPortsPm()
  {
    return _positionPortsPm;
  }

  @Override
  public int hashCode()
  {
    return Objects.hash(_positionPortsPm, _liensPortPon, _panneauPm, _boitierPm);
  }

  /**
   * @param boitierPm_p
   *          the boitierPm to set
   */
  public void setBoitierPm(BoitierPm boitierPm_p)
  {
    _boitierPm = boitierPm_p;
  }

  /**
   * @param liensPortPon_p
   *          the liensPortPon to set
   */
  public void setLiensPortPon(List<LienPortPon> liensPortPon_p)
  {
    _liensPortPon = isNull(liensPortPon_p) ? null : new ArrayList<>(liensPortPon_p);
  }

  /**
   * @param panneauPm_p
   *          the panneauPm to set
   */
  public void setPanneauPm(PanneauPm panneauPm_p)
  {
    _panneauPm = panneauPm_p;
  }

  /**
   * @param positionPortsPm_p
   *          the positionPortsPm to set
   */
  public void setPositionPortsPm(PositionPortPm positionPortsPm_p)
  {
    _positionPortsPm = positionPortsPm_p;
  }

  @Override
  public String toString()
  {
    return "AjoutPortPm [" + "_positionPortsPm=" + _positionPortsPm + ", _liensPortPon=" + _liensPortPon + ", _panneauPm=" + _panneauPm + ", _boitierPm=" + _boitierPm + "]"; // $NON-NLS-1$ // $NON-NLS-2$ // $NON-NLS-3$ // $NON-NLS-4$ // $NON-NLS-5$ // $NON-NLS-6$
  }
}
