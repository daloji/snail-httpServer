/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.tesla.shared.types.PE0529;

import static java.util.Objects.isNull;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

import javax.validation.Valid;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import com.bytel.spirit.common.shared.misc.validation.IValidationConst;
import com.squareup.moshi.Json;

/**
 * Objet AjoutPortPon
 *
 * @author JCHEVRON
 * @version ($Revision$ $Date$)
 */
public class AjoutPortPon implements Serializable
{
  private static final long serialVersionUID = 4995329917574388506L;

  /**
   * Position du port PON sur l’OLT
   */
  @Valid
  @Json(name = "positionPortPon")
  @NotNull(message = IValidationConst.ATTRIBUT_OBLIGATOIRE_MANQUANT)
  private PositionPortPon _positionPortPon;

  /**
   * Liste des technos compatibles. Ce Champ SPIRIT doit être ignoré par NRM dans l’interface OSS.NRM du projet PON128
   */
  @Json(name = "sfpListeTechnologieCompatible")
  @NotEmpty(message = IValidationConst.ATTRIBUT_OBLIGATOIRE_MANQUANT)
  private List<@Pattern(regexp = "GPON|XGSPON", message = IValidationConst.FORMAT_ATTRIBUT_NON_RESPECTE) String> _sfpListeTechnologieCompatible;

  /**
   * Nombre max d’ONT Id autorisé sur le port PON
   */
  @Json(name = "maxOntId")
  @NotNull(message = IValidationConst.ATTRIBUT_OBLIGATOIRE_MANQUANT)
  @Min(value = 0, message = IValidationConst.FORMAT_ATTRIBUT_NON_RESPECTE)
  private Integer _maxOntId;

  /**
   * La carte Pon de rattachement du Port PON
   */
  @Valid
  @Json(name = "cartePon")
  @NotNull(message = IValidationConst.ATTRIBUT_OBLIGATOIRE_MANQUANT)
  private CartePon _cartePon;

  /**
   * Référence câble de renvoi adducté au Port PON
   */
  @Json(name = "referenceCableRenvoiNro")
  private String _referenceCableRenvoiNro;

  /**
   * Codification de volume adducté au Port PON
   */
  @Json(name = "codificationVolume")
  private String _codificationVolume;

  /**
   * Position Fo au NRO adducté au Port PON
   */
  @Json(name = "positionFoNro")
  private String _positionFoNro;

  /**
   * Constructeur par copie
   *
   * @param ajoutPortPon_p
   *          Objet à copier
   */
  public AjoutPortPon(AjoutPortPon ajoutPortPon_p)
  {
    if (!isNull(ajoutPortPon_p))
    {
      _positionPortPon = ajoutPortPon_p._positionPortPon;
      _sfpListeTechnologieCompatible = ajoutPortPon_p._sfpListeTechnologieCompatible;
      _maxOntId = ajoutPortPon_p._maxOntId;
      _cartePon = ajoutPortPon_p._cartePon;
    }
  }

  /**
   * Constructeur complet
   *
   * @param positionPortPon_p
   *          Position du port PON sur l’OLT
   * @param sfpListeTechnologieCompatible_p
   *          Liste des technos compatibles
   * @param maxOntId_p
   *          Nombre max d’ONT Id autorisé sur le port PON
   * @param cartePon_p
   *          La carte Pon de rattachement du Port PON
   */
  public AjoutPortPon(PositionPortPon positionPortPon_p, List<String> sfpListeTechnologieCompatible_p, Integer maxOntId_p, CartePon cartePon_p)
  {
    _positionPortPon = positionPortPon_p;
    _sfpListeTechnologieCompatible = isNull(sfpListeTechnologieCompatible_p) ? null : new ArrayList<>(sfpListeTechnologieCompatible_p);
    _maxOntId = maxOntId_p;
    _cartePon = cartePon_p;
  }

  @Override
  public boolean equals(Object o_p)
  {
    if (this == o_p)
    {
      return true;
    }
    if (o_p == null || getClass() != o_p.getClass())
    {
      return false;
    }
    AjoutPortPon that = (AjoutPortPon) o_p;
    return Objects.equals(_positionPortPon, that._positionPortPon) && Objects.equals(_sfpListeTechnologieCompatible, that._sfpListeTechnologieCompatible) && Objects.equals(_maxOntId, that._maxOntId) && Objects.equals(_cartePon, that._cartePon) && Objects.equals(_referenceCableRenvoiNro, that._referenceCableRenvoiNro) && Objects.equals(_codificationVolume, that._codificationVolume) && Objects.equals(_positionFoNro, that._positionFoNro);
  }

  /**
   * @return the cartePon
   */
  public CartePon getCartePon()
  {
    return _cartePon;
  }

  /**
   * @return the codificationVolume
   */
  public String getCodificationVolume()
  {
    return _codificationVolume;
  }

  /**
   * @return the maxOntId
   */
  public Integer getMaxOntId()
  {
    return _maxOntId;
  }

  /**
   * @return the positionFoNro
   */
  public String getPositionFoNro()
  {
    return _positionFoNro;
  }

  /**
   * @return the positionPortPon
   */
  public PositionPortPon getPositionPortPon()
  {
    return _positionPortPon;
  }

  /**
   * @return the referenceCableRenvoiNro
   */
  public String getReferenceCableRenvoiNro()
  {
    return _referenceCableRenvoiNro;
  }

  /**
   * @return the sfpListeTechnologieCompatible
   */
  public List<String> getSfpListeTechnologieCompatible()
  {
    return isNull(_sfpListeTechnologieCompatible) ? null : Collections.unmodifiableList(_sfpListeTechnologieCompatible);
  }

  @Override
  public int hashCode()
  {
    return Objects.hash(_positionPortPon, _sfpListeTechnologieCompatible, _maxOntId, _cartePon, _referenceCableRenvoiNro, _codificationVolume, _positionFoNro);
  }

  /**
   * @param cartePon_p
   *          the cartePon to set
   */
  public void setCartePon(CartePon cartePon_p)
  {
    _cartePon = cartePon_p;
  }

  /**
   * @param codificationVolume_p
   *          the codificationVolume to set
   */
  public void setCodificationVolume(String codificationVolume_p)
  {
    _codificationVolume = codificationVolume_p;
  }

  /**
   * @param maxOntId_p
   *          the maxOntId to set
   */
  public void setMaxOntId(Integer maxOntId_p)
  {
    _maxOntId = maxOntId_p;
  }

  /**
   * @param positionFoNro_p
   *          the positionFoNro to set
   */
  public void setPositionFoNro(String positionFoNro_p)
  {
    _positionFoNro = positionFoNro_p;
  }

  /**
   * @param positionPortPon_p
   *          the positionPortPon to set
   */
  public void setPositionPortPon(PositionPortPon positionPortPon_p)
  {
    _positionPortPon = positionPortPon_p;
  }

  /**
   * @param referenceCableRenvoiNro_p
   *          the referenceCableRenvoiNro to set
   */
  public void setReferenceCableRenvoiNro(String referenceCableRenvoiNro_p)
  {
    _referenceCableRenvoiNro = referenceCableRenvoiNro_p;
  }

  /**
   * @param sfpListeTechnologieCompatible_p
   *          the sfpListeTechnologieCompatible to set
   */
  public void setSfpListeTechnologieCompatible(List<String> sfpListeTechnologieCompatible_p)
  {
    _sfpListeTechnologieCompatible = isNull(sfpListeTechnologieCompatible_p) ? null : new ArrayList<>(sfpListeTechnologieCompatible_p);
  }

  @Override
  public String toString()
  {
    return "AjoutPortPon [" + "_positionPortPon=" + _positionPortPon + ", _sfpListeTechnologieCompatible=" + _sfpListeTechnologieCompatible + ", _maxOntId=" + _maxOntId + ", _cartePon=" + _cartePon + ", _referenceCableRenvoiNro=" + _referenceCableRenvoiNro + ", _codificationVolume=" + _codificationVolume + ", _positionFoNro=" + _positionFoNro + "]"; // $NON-NLS-1$ // $NON-NLS-2$ // $NON-NLS-3$ // $NON-NLS-4$ // $NON-NLS-5$ // $NON-NLS-6$ // $NON-NLS-7$ // $NON-NLS-8$ // $NON-NLS-9$
  }
}
