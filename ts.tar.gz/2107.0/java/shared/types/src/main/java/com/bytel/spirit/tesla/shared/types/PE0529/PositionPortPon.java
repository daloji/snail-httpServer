/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.tesla.shared.types.PE0529;

import static java.util.Objects.isNull;

import java.io.Serializable;
import java.util.Objects;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.bytel.spirit.common.shared.misc.validation.IValidationConst;
import com.squareup.moshi.Json;

/**
 * Objet positionPortPon
 *
 * @author JCHEVRON
 * @version ($Revision$ $Date$)
 */
public class PositionPortPon implements Serializable
{
  private static final long serialVersionUID = 3236256922601494176L;

  /**
   * Position du port PON sur la carte
   */
  @Json(name = "position")
  @NotNull(message = IValidationConst.ATTRIBUT_OBLIGATOIRE_MANQUANT)
  @Min(value = 0, message = IValidationConst.FORMAT_ATTRIBUT_NON_RESPECTE)
  private Integer _position;

  /**
   * Position Carte PON sur l’OLT
   */
  @Json(name = "positionCarte")
  @NotNull(message = IValidationConst.ATTRIBUT_OBLIGATOIRE_MANQUANT)
  @Min(value = 0, message = IValidationConst.FORMAT_ATTRIBUT_NON_RESPECTE)
  private Integer _positionCarte;

  /**
   * Nom de l'OLT
   */
  @Json(name = "nomOLT")
  @NotBlank(message = IValidationConst.ATTRIBUT_OBLIGATOIRE_MANQUANT)
  private String _nomOLT;

  /**
   * Constructeur
   *
   * @param position_p
   *          Position du port PON sur la carte
   * @param positionCarte_p
   *          Position Carte PON sur l’OLT
   * @param nomOLT_p
   *          Nom de l'OLT
   */
  public PositionPortPon(Integer position_p, Integer positionCarte_p, String nomOLT_p)
  {
    _position = position_p;
    _positionCarte = positionCarte_p;
    _nomOLT = nomOLT_p;
  }

  /**
   * Constructeur par copie
   *
   * @param positionPortPon_p
   *          Objet à copier
   */
  public PositionPortPon(PositionPortPon positionPortPon_p)
  {
    if (!isNull(positionPortPon_p))
    {
      _position = positionPortPon_p._position;
      _positionCarte = positionPortPon_p._positionCarte;
      _nomOLT = positionPortPon_p._nomOLT;
    }
  }

  @Override
  public boolean equals(Object o_p)
  {
    if (this == o_p)
    {
      return true;
    }
    if (o_p == null || getClass() != o_p.getClass())
    {
      return false;
    }
    PositionPortPon that = (PositionPortPon) o_p;
    return Objects.equals(_position, that._position) && Objects.equals(_positionCarte, that._positionCarte) && Objects.equals(_nomOLT, that._nomOLT);
  }

  /**
   * @return the nomOLT
   */
  public String getNomOLT()
  {
    return _nomOLT;
  }

  /**
   * @return the position
   */
  public Integer getPosition()
  {
    return _position;
  }

  /**
   * @return the positionCarte
   */
  public Integer getPositionCarte()
  {
    return _positionCarte;
  }

  @Override
  public int hashCode()
  {
    return Objects.hash(_position, _positionCarte, _nomOLT);
  }

  /**
   * @param nomOLT_p
   *          the nomOLT to set
   */
  public void setNomOLT(String nomOLT_p)
  {
    _nomOLT = nomOLT_p;
  }

  /**
   * @param position_p
   *          the position to set
   */
  public void setPosition(Integer position_p)
  {
    _position = position_p;
  }

  /**
   * @param positionCarte_p
   *          the positionCarte to set
   */
  public void setPositionCarte(Integer positionCarte_p)
  {
    _positionCarte = positionCarte_p;
  }

  /**
   * Cast vers {@link LienPortPon}
   *
   * @return LienPortPon
   */
  public LienPortPon toLienPortPon()
  {
    return new LienPortPon(_nomOLT, _positionCarte, _position);
  }

  @Override
  public String toString()
  {
    return "PositionPortPon [" + "_position=" + _position + ", _positionCarte=" + _positionCarte + ", _nomOLT=" + _nomOLT + "]"; // $NON-NLS-1$ // $NON-NLS-2$ // $NON-NLS-3$ // $NON-NLS-4$ // $NON-NLS-5$
  }
}
