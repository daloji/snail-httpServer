/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.tesla.shared.types.PE0529.validation;

import static java.util.Objects.isNull;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import com.bytel.spirit.common.shared.misc.validation.IValidationConst;
import com.bytel.spirit.tesla.shared.types.PE0529.request.PE0529_PostRequest;
import com.bytel.spirit.tesla.shared.types.PE0533.TypeEquipement;

/**
 * Validation de PE0529_PostRequest selon le contenu de {@link PE0529_PostRequest#getListeTypeEquipementImpacte()}
 *
 * @author JCHEVRON
 * @version ($Revision$ $Date$)
 */
public class PE0529_PostRequestConstraintValidator implements ConstraintValidator<PE0529_PostRequestConstraint, PE0529_PostRequest>
{

  @Override
  public void initialize(final PE0529_PostRequestConstraint value_p)
  {
    // Nothing to do
  }

  @Override
  public boolean isValid(PE0529_PostRequest value_p, ConstraintValidatorContext context_p)
  {
    if (isNull(value_p))
    {
      return true;
    }

    context_p.disableDefaultConstraintViolation();
    if (!isNull(value_p.getListeTypeEquipementImpacte()) && !value_p.getListeTypeEquipementImpacte().isEmpty())
    {
      List<String> listeTypeEquipementImpacte = value_p.getListeTypeEquipementImpacte();
      List<String> listeReference = Arrays.asList(TypeEquipement.OLT.name(), TypeEquipement.PM.name());
      if (Collections.disjoint(listeTypeEquipementImpacte, listeReference))
      {
        context_p.buildConstraintViolationWithTemplate(IValidationConst.FORMAT_ATTRIBUT_NON_RESPECTE).addPropertyNode("_listeTypeEquipementImpacte").addConstraintViolation(); //$NON-NLS-1$
        return false;
      }

      if (!listeTypeEquipementImpacte.contains(TypeEquipement.OLT.name()) && //
          (!value_p.getAjoutsPortsPon().isEmpty() || !value_p.getSuppressionsPortsPon().isEmpty() || !value_p.getModificationsPortsPon().isEmpty()))
      {
        context_p.buildConstraintViolationWithTemplate(IValidationConst.FORMAT_ATTRIBUT_NON_RESPECTE).addPropertyNode("_listeTypeEquipementImpacte").addConstraintViolation(); //$NON-NLS-1$
        return false;
      }

      if (!listeTypeEquipementImpacte.contains(TypeEquipement.PM.name()) && //
          (!value_p.getAjoutsPortsPm().isEmpty() || !value_p.getSuppressionsPortsPm().isEmpty() || !value_p.getModificationsPortsPm().isEmpty() || !value_p.getMigrationsPortsPm().isEmpty()))
      {
        context_p.buildConstraintViolationWithTemplate(IValidationConst.FORMAT_ATTRIBUT_NON_RESPECTE).addPropertyNode("_listeTypeEquipementImpacte").addConstraintViolation(); //$NON-NLS-1$
        return false;
      }
    }

    return true;
  }

}
