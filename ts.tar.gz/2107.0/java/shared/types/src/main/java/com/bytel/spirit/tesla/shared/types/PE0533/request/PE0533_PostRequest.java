/*******************************************************************************
com.bytel.spirit.tesla.shared.types.PE0533* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.tesla.shared.types.PE0533.request;

import static java.util.Objects.isNull;

import java.io.Serializable;
import java.util.Collections;
import java.util.Set;
import java.util.TreeSet;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.bytel.spirit.common.shared.misc.validation.IValidationConst;
import com.bytel.spirit.tesla.shared.types.PE0533.Equipement;
import com.squareup.moshi.Json;

/**
 * Requête POST pour le processus {@link PE0533_BlocageEquipements}
 *
 * @author JCHEVRON
 * @version ($Revision$ $Date$)
 */
public class PE0533_PostRequest implements Serializable
{

  /**
   * Serial Version UID
   */
  private static final long serialVersionUID = -6693258009374078557L;

  /**
   * Liste des équipements sur lesquels le blocage equipement est appliqué
   */
  @NotNull(message = IValidationConst.ATTRIBUT_OBLIGATOIRE_MANQUANT)
  @Size(min = 1, message = IValidationConst.ATTRIBUT_OBLIGATOIRE_MANQUANT)
  @Valid
  @Json(name = "listeEquipement")
  private Set<Equipement> _listeEquipement;

  /**
   * La liste des idOperationVieReseau associées à l’objet BlocageEquipement
   */
  @NotNull(message = IValidationConst.ATTRIBUT_OBLIGATOIRE_MANQUANT)
  @Size(min = 1, message = IValidationConst.ATTRIBUT_OBLIGATOIRE_MANQUANT)
  @Valid
  @Json(name = "listeIdOperationVieReseau")
  private Set<String> _listeIdOperationVieReseau;

  /**
   * Constructeur par copie
   *
   * @param request_p
   *          Objet à copier
   */
  public PE0533_PostRequest(PE0533_PostRequest request_p)
  {
    if (!isNull(request_p))
    {
      _listeEquipement = request_p._listeEquipement;
      _listeIdOperationVieReseau = request_p._listeIdOperationVieReseau;
    }
  }

  /**
   * Constructeur complet
   *
   * @param listeEquipement_p
   *          Liste des équipements sur lesquels le blocage equipement est appliqué
   * @param listeIdOperationVieReseau_p
   *          La liste des idOperationVieReseau associées à l’objet BlocageEquipement
   */
  public PE0533_PostRequest(Set<Equipement> listeEquipement_p, Set<String> listeIdOperationVieReseau_p)
  {
    _listeEquipement = isNull(listeEquipement_p) ? null : new TreeSet<>(listeEquipement_p);
    _listeIdOperationVieReseau = isNull(listeIdOperationVieReseau_p) ? null : new TreeSet<>(listeIdOperationVieReseau_p);
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    PE0533_PostRequest other = (PE0533_PostRequest) obj;
    if (_listeEquipement == null)
    {
      if (other._listeEquipement != null)
      {
        return false;
      }
    }
    else if (!_listeEquipement.equals(other._listeEquipement))
    {
      return false;
    }
    if (_listeIdOperationVieReseau == null)
    {
      if (other._listeIdOperationVieReseau != null)
      {
        return false;
      }
    }
    else if (!_listeIdOperationVieReseau.equals(other._listeIdOperationVieReseau))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the listeEquipement
   */
  public Set<Equipement> getListeEquipement()
  {
    return isNull(_listeEquipement) ? null : Collections.unmodifiableSet(_listeEquipement);
  }

  /**
   * @return the listeIdOperationVieReseau
   */
  public Set<String> getListeIdOperationVieReseau()
  {
    return isNull(_listeIdOperationVieReseau) ? null : Collections.unmodifiableSet(_listeIdOperationVieReseau);
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_listeEquipement == null) ? 0 : _listeEquipement.hashCode());
    result = (prime * result) + ((_listeIdOperationVieReseau == null) ? 0 : _listeIdOperationVieReseau.hashCode());
    return result;
  }

  /**
   * @param listeEquipement_p
   *          the listeEquipements to set
   */
  public void setListeEquipement(Set<Equipement> listeEquipement_p)
  {
    _listeEquipement = isNull(listeEquipement_p) ? null : new TreeSet<>(listeEquipement_p);
  }

  /**
   * @param listeIdOperationVieReseau_p
   *          the listeIdOperationVieReseau to set
   */
  public void setListeIdOperationVieReseau(Set<String> listeIdOperationVieReseau_p)
  {
    _listeIdOperationVieReseau = isNull(listeIdOperationVieReseau_p) ? null : new TreeSet<>(listeIdOperationVieReseau_p);
  }

  @Override
  public String toString()
  {
    return "PE0533_PostRequest [listeEquipement=" + _listeEquipement + ", _listeIdOperationVieReseau=" + _listeIdOperationVieReseau + "]"; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
  }

}
