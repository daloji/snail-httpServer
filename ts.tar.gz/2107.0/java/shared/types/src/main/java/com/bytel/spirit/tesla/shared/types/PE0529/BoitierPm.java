/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.tesla.shared.types.PE0529;

import static java.util.Objects.isNull;

import java.io.Serializable;
import java.util.Objects;

import javax.validation.constraints.NotBlank;

import com.bytel.spirit.common.shared.misc.validation.IValidationConst;
import com.squareup.moshi.Json;

/**
 * Objet BoitierPM
 *
 * @author JCHEVRON
 * @version ($Revision$ $Date$)
 */
public class BoitierPm implements Serializable
{
  private static final long serialVersionUID = -6311851465481957201L;

  /**
   * Identifiant du BPI
   */
  @Json(name = "referenceBoitierPm")
  @NotBlank(message = IValidationConst.ATTRIBUT_OBLIGATOIRE_MANQUANT)
  private String _referenceBoitierPm;

  /**
   * Nom PM Technique
   */
  @Json(name = "nomPmTechnique")
  @NotBlank(message = IValidationConst.ATTRIBUT_OBLIGATOIRE_MANQUANT)
  private String _nomPmTechnique;

  /**
   * Constructeur par copie
   *
   * @param boitierPm_p
   *          Objet à copier
   */
  public BoitierPm(BoitierPm boitierPm_p)
  {
    if (!isNull(boitierPm_p))
    {
      _referenceBoitierPm = boitierPm_p._referenceBoitierPm;
      _nomPmTechnique = boitierPm_p._nomPmTechnique;
    }
  }

  /**
   * Constructeur
   *
   * @param referenceBoitierPm_p
   *          Identifiant du BPI
   * @param nomPmTechnique_p
   *          Nom PM Technique
   */
  public BoitierPm(String referenceBoitierPm_p, String nomPmTechnique_p)
  {
    _referenceBoitierPm = referenceBoitierPm_p;
    _nomPmTechnique = nomPmTechnique_p;
  }

  @Override
  public boolean equals(Object o_p)
  {
    if (this == o_p)
    {
      return true;
    }
    if (o_p == null || getClass() != o_p.getClass())
    {
      return false;
    }
    BoitierPm boitierPm = (BoitierPm) o_p;
    return Objects.equals(_referenceBoitierPm, boitierPm._referenceBoitierPm) && Objects.equals(_nomPmTechnique, boitierPm._nomPmTechnique);
  }

  /**
   * @return the nomPmTechnique
   */
  public String getNomPmTechnique()
  {
    return _nomPmTechnique;
  }

  /**
   * @return the referenceBoitierPm
   */
  public String getReferenceBoitierPm()
  {
    return _referenceBoitierPm;
  }

  @Override
  public int hashCode()
  {
    return Objects.hash(_referenceBoitierPm, _nomPmTechnique);
  }

  /**
   * @param nomPmTechnique_p
   *          the nomPmTechnique to set
   */
  public void setNomPmTechnique(String nomPmTechnique_p)
  {
    _nomPmTechnique = nomPmTechnique_p;
  }

  /**
   * @param referenceBoitierPm_p
   *          the referenceBoitierPm to set
   */
  public void setReferenceBoitierPm(String referenceBoitierPm_p)
  {
    _referenceBoitierPm = referenceBoitierPm_p;
  }

  @Override
  public String toString()
  {
    return "BoitierPm [" + "_referenceBoitierPm=" + _referenceBoitierPm + ", _nomPmTechnique=" + _nomPmTechnique + "]"; // $NON-NLS-1$ // $NON-NLS-2$ // $NON-NLS-3$ // $NON-NLS-4$
  }

}
