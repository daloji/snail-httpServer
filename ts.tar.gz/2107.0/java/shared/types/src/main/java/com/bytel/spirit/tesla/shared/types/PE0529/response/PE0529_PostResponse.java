/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.tesla.shared.types.PE0529.response;

import java.io.Serializable;

import com.bytel.ravel.common.business.generated.Retour;
import com.squareup.moshi.Json;

/**
 * @author JCHEVRON
 * @version ($Revision$ $Date$)
 */
public class PE0529_PostResponse implements Serializable
{
  private static final long serialVersionUID = 150778710980290646L;

  /**
   * Identifiant de la ressource opération Vie Reseau créée
   */
  @Json(name = "idOperationVieReseau")
  private String _idOperationVieReseau;

  /**
   * @return the idOperationVieReseau
   */
  public String getIdOperationVieReseau()
  {
    return _idOperationVieReseau;
  }

  /**
   * @param idOperationVieReseau_p
   *          the idOperationVieReseau to set
   */
  public void setIdOperationVieReseau(String idOperationVieReseau_p)
  {
    _idOperationVieReseau = idOperationVieReseau_p;
  }
}
