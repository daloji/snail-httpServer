/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.tesla.shared.types.PE0529;

import static java.util.Objects.isNull;

import java.io.Serializable;
import java.util.Objects;

import javax.validation.constraints.NotBlank;

import com.bytel.spirit.common.shared.misc.validation.IValidationConst;
import com.squareup.moshi.Json;

/**
 * Objet PanneauPM
 *
 * @author JCHEVRON
 * @version ($Revision$ $Date$)
 */
public class PanneauPm implements Serializable
{
  private static final long serialVersionUID = -6311851465481957201L;

  /**
   * Nom du Panneau
   */
  @Json(name = "nomPanneau")
  @NotBlank(message = IValidationConst.ATTRIBUT_OBLIGATOIRE_MANQUANT)
  private String _nomPanneau;

  /**
   * Coordonnée de la baie, attribut facultatif qui existe seulement en cas de PM Free type PMGC
   */
  @Json(name = "baie")
  private String _baie;

  /**
   * Numéro de la baie, attribut facultatif qui existe seulement en cas de PM Free type PMGC
   */
  @Json(name = "face")
  private Integer _face;

  /**
   * Tiroir, attribut facultatif qui existe seulement en cas de PM Free type PMGC
   */
  @Json(name = "tiroir")
  private String _tiroir;

  /**
   * La position Alpha, attribut facultatif qui existe seulement en cas de PM Free type PMGC
   */
  @Json(name = "positionAlpha")
  private String _positionAlpha;

  /**
   * Constructeur par copie
   *
   * @param panneauPm_p
   *          Objet à copier
   */
  public PanneauPm(PanneauPm panneauPm_p)
  {
    if (!isNull(panneauPm_p))
    {
      _nomPanneau = panneauPm_p._nomPanneau;
      _baie = panneauPm_p._baie;
      _face = panneauPm_p._face;
      _tiroir = panneauPm_p._tiroir;
      _positionAlpha = panneauPm_p._positionAlpha;
    }
  }

  /**
   * Constructeur
   *
   * @param nomPanneau_p
   *          Nom du panneau
   */
  public PanneauPm(String nomPanneau_p)
  {
    _nomPanneau = nomPanneau_p;
  }

  @Override
  public boolean equals(Object o_p)
  {
    if (this == o_p)
    {
      return true;
    }
    if (o_p == null || getClass() != o_p.getClass())
    {
      return false;
    }
    PanneauPm panneauPm = (PanneauPm) o_p;
    return Objects.equals(_nomPanneau, panneauPm._nomPanneau) && Objects.equals(_baie, panneauPm._baie) && Objects.equals(_face, panneauPm._face) && Objects.equals(_tiroir, panneauPm._tiroir) && Objects.equals(_positionAlpha, panneauPm._positionAlpha);
  }

  /**
   * @return the baie
   */
  public String getBaie()
  {
    return _baie;
  }

  /**
   * @return the face
   */
  public Integer getFace()
  {
    return _face;
  }

  /**
   * @return the nomPanneau
   */
  public String getNomPanneau()
  {
    return _nomPanneau;
  }

  /**
   * @return the positionAlpha
   */
  public String getPositionAlpha()
  {
    return _positionAlpha;
  }

  /**
   * @return the tiroir
   */
  public String getTiroir()
  {
    return _tiroir;
  }

  @Override
  public int hashCode()
  {
    return Objects.hash(_nomPanneau, _baie, _face, _tiroir, _positionAlpha);
  }

  /**
   * @param baie_p
   *          the baie to set
   */
  public void setBaie(String baie_p)
  {
    _baie = baie_p;
  }

  /**
   * @param face_p
   *          the face to set
   */
  public void setFace(Integer face_p)
  {
    _face = face_p;
  }

  /**
   * @param nomPanneau_p
   *          the nomPanneau to set
   */
  public void setNomPanneau(String nomPanneau_p)
  {
    _nomPanneau = nomPanneau_p;
  }

  /**
   * @param positionAlpha_p
   *          the positionAlpha to set
   */
  public void setPositionAlpha(String positionAlpha_p)
  {
    _positionAlpha = positionAlpha_p;
  }

  /**
   * @param tiroir_p
   *          the tiroir to set
   */
  public void setTiroir(String tiroir_p)
  {
    _tiroir = tiroir_p;
  }

  @Override
  public String toString()
  {
    return "PanneauPm [" + "_nomPanneau=" + _nomPanneau + ", _baie=" + _baie + ", _face=" + _face + ", _tiroir=" + _tiroir + ", _positionAlpha=" + _positionAlpha + "]"; // $NON-NLS-1$ // $NON-NLS-2$ // $NON-NLS-3$ // $NON-NLS-4$ // $NON-NLS-5$ // $NON-NLS-6$ // $NON-NLS-7$
  }
}
