/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.tesla.shared.types.PE0529;

import static java.util.Objects.isNull;

import java.io.Serializable;
import java.util.Objects;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.bytel.spirit.common.shared.misc.validation.IValidationConst;
import com.squareup.moshi.Json;

/**
 * Objet suppresionPortPon
 *
 * @author JCHEVRON
 * @version ($Revision$ $Date$)
 */
public class SuppressionPortPon implements Serializable
{
  private static final long serialVersionUID = 3341428778823786366L;

  /**
   * Position du port PON sur la carte
   */
  @Valid
  @Json(name = "positionPortPon")
  @NotNull(message = IValidationConst.ATTRIBUT_OBLIGATOIRE_MANQUANT)
  private PositionPortPon _positionPortPon;

  /**
   * Constructeur complet
   *
   * @param positionPortPon_p
   *          Position du port PON sur la carte
   */
  public SuppressionPortPon(PositionPortPon positionPortPon_p)
  {
    _positionPortPon = positionPortPon_p;
  }

  /**
   * Constructeur par copie
   *
   * @param suppressionPortPon_p
   *          Objet à copier
   */
  public SuppressionPortPon(SuppressionPortPon suppressionPortPon_p)
  {
    if (!isNull(suppressionPortPon_p))
    {
      _positionPortPon = suppressionPortPon_p._positionPortPon;
    }
  }

  @Override
  public boolean equals(Object o_p)
  {
    if (this == o_p)
    {
      return true;
    }
    if (o_p == null || getClass() != o_p.getClass())
    {
      return false;
    }
    SuppressionPortPon that = (SuppressionPortPon) o_p;
    return Objects.equals(_positionPortPon, that._positionPortPon);
  }

  /**
   * @return the positionPortPon
   */
  public PositionPortPon getPositionPortPon()
  {
    return _positionPortPon;
  }

  @Override
  public int hashCode()
  {
    return Objects.hash(_positionPortPon);
  }

  /**
   * @param positionPortPon_p
   *          the positionPortPon to set
   */
  public void setPositionPortPon(PositionPortPon positionPortPon_p)
  {
    _positionPortPon = positionPortPon_p;
  }

  @Override
  public String toString()
  {
    return "SuppressionPortPon [" + "_positionPortPon=" + _positionPortPon + "]"; // $NON-NLS-1$ // $NON-NLS-2$ // $NON-NLS-3$
  }
}
