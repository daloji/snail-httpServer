/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.tesla.shared.types.PE0529.request;

import static java.util.Objects.isNull;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.bytel.ravel.common.exception.RavelException;
import com.bytel.spirit.common.shared.functional.types.json.RavelJsonTools;
import com.bytel.spirit.common.shared.misc.validation.IValidationConst;
import com.bytel.spirit.tesla.shared.types.PE0529.AjoutPortPm;
import com.bytel.spirit.tesla.shared.types.PE0529.AjoutPortPon;
import com.bytel.spirit.tesla.shared.types.PE0529.LienPortPon;
import com.bytel.spirit.tesla.shared.types.PE0529.MigrationPortPm;
import com.bytel.spirit.tesla.shared.types.PE0529.ModificationPortPm;
import com.bytel.spirit.tesla.shared.types.PE0529.ModificationPortPon;
import com.bytel.spirit.tesla.shared.types.PE0529.PositionPortPm;
import com.bytel.spirit.tesla.shared.types.PE0529.SuppressionPortPm;
import com.bytel.spirit.tesla.shared.types.PE0529.SuppressionPortPon;
import com.bytel.spirit.tesla.shared.types.PE0529.validation.PE0529_PostRequestConstraint;
import com.squareup.moshi.Json;

/**
 * Requête POST pour le processus PE0529_OperationVieReseau.
 *
 * @author JCHEVRON
 * @version ($Revision$ $Date$)
 */
@PE0529_PostRequestConstraint
public class PE0529_PostRequest implements Serializable
{
  private static final long serialVersionUID = 1118195798714367981L;

  /**
   * Le type de l’opération vie de réseau
   */
  @Json(name = "typeVieReseau") //$NON-NLS-1$
  @NotBlank(message = IValidationConst.ATTRIBUT_OBLIGATOIRE_MANQUANT)
  @Pattern(regexp = "PON128|MODERN_ZTD|RECETTE_RES_OLT|DEMENAGEMENT_OLTNRO|REALIGNEMENT_CLIENTS", message = IValidationConst.FORMAT_ATTRIBUT_NON_RESPECTE) //$NON-NLS-1$
  private String _typeVieReseau;

  /**
   * La liste des types des équipements impactés dans l’opération Vie Reseau
   */
  @Json(name = "listeTypeEquipementImpacte") //$NON-NLS-1$
  @NotEmpty(message = IValidationConst.ATTRIBUT_OBLIGATOIRE_MANQUANT)
  @Size(max = 2, message = IValidationConst.FORMAT_ATTRIBUT_NON_RESPECTE)
  private List<String> _listeTypeEquipementImpacte;

  /**
   * Le numéro de GCR de l’opération
   */
  @Json(name = "numeroGCR") //$NON-NLS-1$
  private String _numeroGCR;

  /**
   * Le idOperationVieReseau de l’opération précédente associée à cette opération, soit par rollback ou dépendance
   * d’enchainement
   */
  @Json(name = "idOperationVieReseauLie") //$NON-NLS-1$
  private String _idOperationVieReseauLie;

  /**
   * Liste des Port PM a swapper sur des nouvelles position
   */
  @Valid
  @Json(name = "migrationsPortsPm") //$NON-NLS-1$
  private List<MigrationPortPm> _migrationsPortsPm;

  /**
   * Liste des Port PM pour lesquelles il faut changer le Port Pon d’adduction sur l’OLT
   */
  @Valid
  @Json(name = "modificationsPortsPm") //$NON-NLS-1$
  private List<ModificationPortPm> _modificationsPortsPm;

  /**
   * Liste des Port PM à ajouter
   */
  @Valid
  @Json(name = "ajoutsPortsPm") //$NON-NLS-1$
  private List<AjoutPortPm> _ajoutsPortsPm;

  /**
   * Liste des port Pm à supprimer
   */
  @Valid
  @Json(name = "suppressionsPortsPm") //$NON-NLS-1$
  private List<SuppressionPortPm> _suppressionsPortsPm;

  /**
   * Les port Pon à ajouter à une carte d’un OLT
   */
  @Valid
  @Json(name = "ajoutsPortsPon") //$NON-NLS-1$
  private List<AjoutPortPon> _ajoutsPortsPon;

  /**
   * Liste des Port Pon à supprimer sur une carte d’un OLT
   */
  @Valid
  @Json(name = "suppressionsPortsPon") //$NON-NLS-1$
  private List<SuppressionPortPon> _suppressionsPortsPon;

  /**
   * Liste des modifications à apporter à des Ports Pon d’une carte
   */
  @Valid
  @Json(name = "modificationsPortsPon") //$NON-NLS-1$
  private List<ModificationPortPon> _modificationsPortsPon;

  /**
   * Constructeur par copie
   *
   * @param request_p
   *          Objet à copier
   */
  public PE0529_PostRequest(PE0529_PostRequest request_p)
  {
    if (!isNull(request_p))
    {
      _typeVieReseau = request_p._typeVieReseau;
      _listeTypeEquipementImpacte = request_p._listeTypeEquipementImpacte;
      _numeroGCR = request_p._numeroGCR;
      _idOperationVieReseauLie = request_p._idOperationVieReseauLie;
      _migrationsPortsPm = request_p._migrationsPortsPm;
      _modificationsPortsPm = request_p._modificationsPortsPm;
      _ajoutsPortsPm = request_p._ajoutsPortsPm;
      _suppressionsPortsPm = request_p._suppressionsPortsPm;
      _ajoutsPortsPon = request_p._ajoutsPortsPon;
      _suppressionsPortsPon = request_p._suppressionsPortsPon;
      _modificationsPortsPon = request_p._modificationsPortsPon;
    }
  }

  /**
   * Constructeur
   *
   * @param typeVieReseau_p
   *          Le type de l’opération vie de réseau
   * @param listeTypeEquipementImpacte_p
   *          La liste des types des équipements impactés dans l’opération Vie Reseau
   */
  public PE0529_PostRequest(String typeVieReseau_p, List<String> listeTypeEquipementImpacte_p)
  {
    _typeVieReseau = typeVieReseau_p;
    _listeTypeEquipementImpacte = isNull(listeTypeEquipementImpacte_p) ? null : new ArrayList<>(listeTypeEquipementImpacte_p);
  }

  @Override
  public boolean equals(Object o_p)
  {
    if (this == o_p)
    {
      return true;
    }
    if (o_p == null || getClass() != o_p.getClass())
    {
      return false;
    }
    PE0529_PostRequest that = (PE0529_PostRequest) o_p;
    return Objects.equals(_typeVieReseau, that._typeVieReseau) && Objects.equals(_listeTypeEquipementImpacte, that._listeTypeEquipementImpacte) && Objects.equals(_numeroGCR, that._numeroGCR) && Objects.equals(_idOperationVieReseauLie, that._idOperationVieReseauLie) && Objects.equals(_migrationsPortsPm, that._migrationsPortsPm) && Objects.equals(_modificationsPortsPm, that._modificationsPortsPm) && Objects.equals(_ajoutsPortsPm, that._ajoutsPortsPm) && Objects.equals(_suppressionsPortsPm, that._suppressionsPortsPm) && Objects.equals(_ajoutsPortsPon, that._ajoutsPortsPon) && Objects.equals(_suppressionsPortsPon, that._suppressionsPortsPon) && Objects.equals(_modificationsPortsPon, that._modificationsPortsPon);
  }

  /**
   * Retourne un AjoutPortPon à partir d'un LienPortPon
   *
   * @param lienPortPon_p
   *          LienPortPon
   * @return {@link AjoutPortPon}
   */
  public AjoutPortPon getAjoutPortPonFromPositionPortPm(LienPortPon lienPortPon_p)
  {
    if (!isNull(_ajoutsPortsPon) && !isNull(lienPortPon_p))
    {
      Optional<AjoutPortPon> optAjout = _ajoutsPortsPon.stream().filter( //
          ajout -> ajout.getPositionPortPon().getNomOLT().equals(lienPortPon_p.getNomOLT()) //
              && (ajout.getPositionPortPon().getPosition().equals(lienPortPon_p.getPositionPortPon())) //
              && (ajout.getPositionPortPon().getPositionCarte().equals(lienPortPon_p.getPositionCartePon())) //
      ).findAny();

      if (optAjout.isPresent())
      {
        return optAjout.get();
      }
    }

    return null;
  }

  /**
   * @return the ajoutsPortsPm
   */
  public List<AjoutPortPm> getAjoutsPortsPm()
  {
    return isNull(_ajoutsPortsPm) ? new ArrayList<>() : Collections.unmodifiableList(_ajoutsPortsPm);
  }

  /**
   * @return the ajoutsPortsPon
   */
  public List<AjoutPortPon> getAjoutsPortsPon()
  {
    return isNull(_ajoutsPortsPon) ? new ArrayList<>() : Collections.unmodifiableList(_ajoutsPortsPon);
  }

  /**
   * @return donnees brutes de la requête
   * @throws RavelException
   *           on error.
   */
  public String getDonneesBrutes() throws RavelException
  {
    return RavelJsonTools.getInstance().toJson(this, this.getClass());
  }

  /**
   * @return the idOperationVieReseauLie
   */
  public String getIdOperationVieReseauLie()
  {
    return _idOperationVieReseauLie;
  }

  /**
   * Retourne la liste des references des boitiers PM impactés
   *
   * @return Set de {@link String}
   */
  public Set<String> getListeBoitierPM()
  {
    Set<String> boitiersPm = new HashSet<>();

    if (!isNull(_ajoutsPortsPm))
    {
      boitiersPm.addAll(_ajoutsPortsPm.stream().map(ajoutPortPm -> ajoutPortPm.getPositionPortsPm().getReferencePmBytel() + "|" + ajoutPortPm.getPositionPortsPm().getReferenceBoitierPm()).collect(Collectors.toSet()));
      boitiersPm.addAll(_ajoutsPortsPm.stream().map(ajoutPortPm -> ajoutPortPm.getPositionPortsPm().getReferencePmBytel() + "|" + ajoutPortPm.getBoitierPm().getReferenceBoitierPm()).collect(Collectors.toSet()));
    }

    if (!isNull(_modificationsPortsPm))
    {
      boitiersPm.addAll(_modificationsPortsPm.stream().map(modificationPortPm -> modificationPortPm.getPositionPortPm().getReferencePmBytel() + "|" + modificationPortPm.getPositionPortPm().getReferenceBoitierPm()).collect(Collectors.toSet()));
    }

    if (!isNull(_migrationsPortsPm))
    {
      boitiersPm.addAll(_migrationsPortsPm.stream().map(migrationPortPm -> migrationPortPm.getPositionPortPmSource().getReferencePmBytel() + "|" + migrationPortPm.getPositionPortPmSource().getReferenceBoitierPm()).collect(Collectors.toSet()));
      boitiersPm.addAll(_migrationsPortsPm.stream().map(migrationPortPm -> migrationPortPm.getPositionPortPmCible().getReferencePmBytel()  + "|" + migrationPortPm.getPositionPortPmCible().getReferenceBoitierPm()).collect(Collectors.toSet()));
    }

    if (!isNull(_suppressionsPortsPm))
    {
      boitiersPm.addAll(_suppressionsPortsPm.stream().map(SuppressionPortPm::getPositionPortsPm).flatMap(Collection::stream).map(pos -> pos.getReferencePmBytel() + "|" + pos.getReferenceBoitierPm()).collect(Collectors.toSet()));
    }

    return boitiersPm;
  }

  /**
   * Retourne la liste des liens port pon ajoute à partir d'une position port PM
   *
   * @param positionPortPmCible_p
   *          position port PM de reference
   * @return Liste des {@link LienPortPon}
   */
  public Set<LienPortPon> getListeLienPortPonAjouteFromPositionPortPm(PositionPortPm positionPortPmCible_p)
  {
    Set<LienPortPon> listeLienPortPon = new HashSet<>();

    if (!isNull(_ajoutsPortsPm) && !isNull(positionPortPmCible_p))
    {
      listeLienPortPon = _ajoutsPortsPm.stream().filter(ajout -> ajout.getPositionPortsPm().equals(positionPortPmCible_p)).map(AjoutPortPm::getLiensPortPon).flatMap(Collection::stream).collect(Collectors.toSet());
    }

    return listeLienPortPon;
  }

  /**
   * Retourne la liste des noms de tous les OLT impactés
   *
   * @return Set de {@link String}
   */
  public Set<String> getListeNomOlt()
  {
    Set<String> nomOlts = new HashSet<>();
    if (!isNull(_ajoutsPortsPm))
    {
      nomOlts.addAll(_ajoutsPortsPm.stream().map(AjoutPortPm::getLiensPortPon).flatMap(Collection::stream).map(LienPortPon::getNomOLT).collect(Collectors.toSet()));
    }
    if (!isNull(_modificationsPortsPm))
    {
      nomOlts.addAll(getModificationsPortsPm().stream().map(ModificationPortPm::getLiensPortPonCible).flatMap(Collection::stream).map(LienPortPon::getNomOLT).collect(Collectors.toSet()));
      nomOlts.addAll(getModificationsPortsPm().stream().map(ModificationPortPm::getLiensPortPonSource).flatMap(Collection::stream).map(LienPortPon::getNomOLT).collect(Collectors.toSet()));
    }
    nomOlts.addAll(getListeNomOltOperationPortPon());
    return nomOlts;
  }

  /**
   * Retourne la liste des OLT impactés par les operations sur les ports PON (ajout, suppression et modification)
   *
   * @return Set de {@link String}
   */
  public Set<String> getListeNomOltOperationPortPon()
  {
    Set<String> nomOlts = new HashSet<>();
    if (!isNull(_ajoutsPortsPon))
    {
      nomOlts.addAll(_ajoutsPortsPon.stream().map(ajoutPortPon -> ajoutPortPon.getPositionPortPon().getNomOLT()).collect(Collectors.toSet()));
    }
    if (!isNull(_modificationsPortsPon))
    {
      nomOlts.addAll(_modificationsPortsPon.stream().map(modificationPortPon -> modificationPortPon.getPositionPortPon().getNomOLT()).collect(Collectors.toSet()));
    }
    if (!isNull(_suppressionsPortsPon))
    {
      nomOlts.addAll(_suppressionsPortsPon.stream().map(suppressionPortPon -> suppressionPortPon.getPositionPortPon().getNomOLT()).collect(Collectors.toSet()));
    }
    return nomOlts;
  }

  /**
   * Retourne la liste de tous les objets {@link PositionPortPm} à ajouter
   *
   * @return Set de {@link PositionPortPm}
   */
  public Set<PositionPortPm> getListePortPmAjoutes()
  {
    if (!isNull(_ajoutsPortsPm))
    {
      return _ajoutsPortsPm.stream().map(AjoutPortPm::getPositionPortsPm).collect(Collectors.toSet());
    }
    return new HashSet<>();
  }

  /**
   * Retourne la liste de tous les objets {@link PositionPortPm} étant à la cible d'une migration
   *
   * @return Set de {@link PositionPortPm}
   */
  public Set<PositionPortPm> getListePortPmCibleMigres()
  {
    if (!isNull(_migrationsPortsPm))
    {
      return _migrationsPortsPm.stream().map(MigrationPortPm::getPositionPortPmCible).collect(Collectors.toSet());
    }

    return new HashSet<>();
  }

  /**
   * Retourne la liste de tous les objets {@link PositionPortPm} étant à la source d'une migration
   *
   * @return Set de {@link PositionPortPm}
   */
  public Set<PositionPortPm> getListePortPmSourceMigres()
  {
    if (!isNull(_migrationsPortsPm))
    {
      return _migrationsPortsPm.stream().map(MigrationPortPm::getPositionPortPmSource).collect(Collectors.toSet());
    }

    return new HashSet<>();
  }

  /**
   * Retourne la liste de tous les objets {@link PositionPortPm} à supprimer
   *
   * @return Set de {@link PositionPortPm}
   */
  public Set<PositionPortPm> getListePortPmSupprimes()
  {
    Set<PositionPortPm> listePortPmSupprimes = new HashSet<>();

    if (!isNull(_suppressionsPortsPm))
    {
      for (SuppressionPortPm suppression : getSuppressionsPortsPm())
      {
        listePortPmSupprimes.addAll(suppression.getPositionPortsPm());
      }
    }

    return listePortPmSupprimes;
  }

  /**
   * Retourne la liste de toutes les références PM Bytel impactés
   *
   * @return Set de {@link String}
   */
  public Set<String> getListeReferencesPmBytel()
  {
    Set<String> refPmBytel = new HashSet<>();

    if (!isNull(_ajoutsPortsPm))
    {
      refPmBytel.addAll(_ajoutsPortsPm.stream().map(ajoutPortPm -> ajoutPortPm.getPositionPortsPm().getReferencePmBytel()).collect(Collectors.toSet()));
    }

    if (!isNull(_modificationsPortsPm))
    {
      refPmBytel.addAll(_modificationsPortsPm.stream().map(modificationPortPm -> modificationPortPm.getPositionPortPm().getReferencePmBytel()).collect(Collectors.toSet()));
    }

    if (!isNull(_migrationsPortsPm))
    {
      refPmBytel.addAll(_migrationsPortsPm.stream().map(migrationPortPm -> migrationPortPm.getPositionPortPmSource().getReferencePmBytel()).collect(Collectors.toSet()));
      refPmBytel.addAll(_migrationsPortsPm.stream().map(migrationPortPm -> migrationPortPm.getPositionPortPmCible().getReferencePmBytel()).collect(Collectors.toSet()));
    }

    if (!isNull(_suppressionsPortsPm))
    {
      refPmBytel.addAll(_suppressionsPortsPm.stream().map(SuppressionPortPm::getPositionPortsPm).flatMap(Collection::stream).map(PositionPortPm::getReferencePmBytel).collect(Collectors.toSet()));
    }

    return refPmBytel;
  }

  /**
   * @return the listeTypeEquipementImpacte
   */
  public List<String> getListeTypeEquipementImpacte()
  {
    return isNull(_listeTypeEquipementImpacte) ? new ArrayList<>() : Collections.unmodifiableList(_listeTypeEquipementImpacte);
  }

  /**
   * @return the migrationsPortsPm
   */
  public List<MigrationPortPm> getMigrationsPortsPm()
  {
    return isNull(_migrationsPortsPm) ? new ArrayList<>() : Collections.unmodifiableList(_migrationsPortsPm);
  }

  /**
   * @return the modificationsPortsPm
   */
  public List<ModificationPortPm> getModificationsPortsPm()
  {
    return isNull(_modificationsPortsPm) ? new ArrayList<>() : Collections.unmodifiableList(_modificationsPortsPm);
  }

  /**
   * @return the modificationsPortsPon
   */
  public List<ModificationPortPon> getModificationsPortsPon()
  {
    return isNull(_modificationsPortsPon) ? new ArrayList<>() : new ArrayList<>(_modificationsPortsPon);
  }

  /**
   * @return the numeroGCR
   */
  public String getNumeroGCR()
  {
    return _numeroGCR;
  }

  /**
   * @return the suppressionsPortsPm
   */
  public List<SuppressionPortPm> getSuppressionsPortsPm()
  {
    return isNull(_suppressionsPortsPm) ? new ArrayList<>() : Collections.unmodifiableList(_suppressionsPortsPm);
  }

  /**
   * @return the suppressionsPortsPon
   */
  public List<SuppressionPortPon> getSuppressionsPortsPon()
  {
    return isNull(_suppressionsPortsPon) ? new ArrayList<>() : Collections.unmodifiableList(_suppressionsPortsPon);
  }

  /**
   * @return the typeVieReseau
   */
  public String getTypeVieReseau()
  {
    return _typeVieReseau;
  }

  @Override
  public int hashCode()
  {
    return Objects.hash(_typeVieReseau, _listeTypeEquipementImpacte, _numeroGCR, _idOperationVieReseauLie, _migrationsPortsPm, _modificationsPortsPm, _ajoutsPortsPm, _suppressionsPortsPm, _ajoutsPortsPon, _suppressionsPortsPon, _modificationsPortsPon);
  }

  /**
   * @param ajoutsPortsPm_p
   *          the ajoutsPortsPm to set
   */
  public void setAjoutsPortsPm(List<AjoutPortPm> ajoutsPortsPm_p)
  {
    _ajoutsPortsPm = isNull(ajoutsPortsPm_p) ? null : new ArrayList<>(ajoutsPortsPm_p);
  }

  /**
   * @param ajoutsPortsPon_p
   *          the ajoutsPortsPon to set
   */
  public void setAjoutsPortsPon(List<AjoutPortPon> ajoutsPortsPon_p)
  {
    _ajoutsPortsPon = isNull(ajoutsPortsPon_p) ? null : new ArrayList<>(ajoutsPortsPon_p);
  }

  /**
   * @param idOperationVieReseauLie_p
   *          the idOperationVieReseauLie to set
   */
  public void setIdOperationVieReseauLie(String idOperationVieReseauLie_p)
  {
    _idOperationVieReseauLie = idOperationVieReseauLie_p;
  }

  /**
   * @param listeTypeEquipementImpacte_p
   *          the listeTypeEquipementImpacte to set
   */
  public void setListeTypeEquipementImpacte(List<String> listeTypeEquipementImpacte_p)
  {
    _listeTypeEquipementImpacte = isNull(listeTypeEquipementImpacte_p) ? null : new ArrayList<>(listeTypeEquipementImpacte_p);
  }

  /**
   * @param migrationsPortsPm_p
   *          the migrationsPortsPm to set
   */
  public void setMigrationsPortsPm(List<MigrationPortPm> migrationsPortsPm_p)
  {
    _migrationsPortsPm = isNull(migrationsPortsPm_p) ? null : new ArrayList<>(migrationsPortsPm_p);
  }

  /**
   * @param modificationsPortsPm_p
   *          the modificationsPortsPm to set
   */
  public void setModificationsPortsPm(List<ModificationPortPm> modificationsPortsPm_p)
  {
    _modificationsPortsPm = isNull(modificationsPortsPm_p) ? null : new ArrayList<>(modificationsPortsPm_p);
  }

  /**
   * @param modificationsPortsPon_p
   *          the modificationsPortsPon to set
   */
  public void setModificationsPortsPon(List<ModificationPortPon> modificationsPortsPon_p)
  {
    _modificationsPortsPon = isNull(modificationsPortsPon_p) ? null : Collections.unmodifiableList(modificationsPortsPon_p);
  }

  /**
   * @param numeroGCR_p
   *          the numeroGCR to set
   */
  public void setNumeroGCR(String numeroGCR_p)
  {
    _numeroGCR = numeroGCR_p;
  }

  /**
   * @param suppressionsPortsPm_p
   *          the suppressionsPortsPm to set
   */
  public void setSuppressionsPortsPm(List<SuppressionPortPm> suppressionsPortsPm_p)
  {
    _suppressionsPortsPm = isNull(suppressionsPortsPm_p) ? null : new ArrayList<>(suppressionsPortsPm_p);
  }

  /**
   * @param suppressionsPortsPon_p
   *          the suppressionsPortsPon to set
   */
  public void setSuppressionsPortsPon(List<SuppressionPortPon> suppressionsPortsPon_p)
  {
    _suppressionsPortsPon = isNull(suppressionsPortsPon_p) ? null : new ArrayList<>(suppressionsPortsPon_p);
  }

  /**
   * @param typeVieReseau_p
   *          the typeVieReseau to set
   */
  public void setTypeVieReseau(String typeVieReseau_p)
  {
    _typeVieReseau = typeVieReseau_p;
  }

  @Override
  public String toString()
  {
    return "PE0529_PostRequest [" + "_typeVieReseau=" + _typeVieReseau + ", _listeTypeEquipementImpacte=" + _listeTypeEquipementImpacte + ", _numeroGCR=" + _numeroGCR + ", _idOperationVieReseauLie=" + _idOperationVieReseauLie + ", _migrationsPortsPm=" + _migrationsPortsPm + ", _modificationsPortsPm=" + _modificationsPortsPm + ", _ajoutsPortsPm=" + _ajoutsPortsPm + ", _suppressionsPortsPm=" + _suppressionsPortsPm + ", _ajoutsPortsPon=" + _ajoutsPortsPon + ", _suppressionsPortsPon=" + _suppressionsPortsPon + ", _modificationsPortsPon=" + _modificationsPortsPon + "]"; // $NON-NLS-1$ // $NON-NLS-2$ // $NON-NLS-3$ // $NON-NLS-4$ // $NON-NLS-5$ // $NON-NLS-6$ // $NON-NLS-7$ // $NON-NLS-8$ // $NON-NLS-9$ // $NON-NLS-10$ // $NON-NLS-11$ // $NON-NLS-12$ // $NON-NLS-13$
  }
}
