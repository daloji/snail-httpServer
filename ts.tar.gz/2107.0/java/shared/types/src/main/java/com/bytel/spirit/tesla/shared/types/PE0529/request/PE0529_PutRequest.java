/*******************************************************************************
com.bytel.spirit.tesla.shared.types.PE0533* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.tesla.shared.types.PE0529.request;

import static java.util.Objects.isNull;

import java.io.Serializable;
import java.util.Objects;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import com.bytel.spirit.common.shared.misc.validation.IValidationConst;
import com.squareup.moshi.Json;

/**
 * Requête PUT pour le processus PE0529_OperationVieReseau.
 *
 * @author JCHEVRON
 * @version ($Revision$ $Date$)
 */
public class PE0529_PutRequest implements Serializable
{
  private static final long serialVersionUID = 6916203310434587277L;

  /**
   * Action à réaliser sur l’opération Vie Reseau
   */
  @Json(name = "action") // $NON-NLS-1$
  @NotBlank(message = IValidationConst.ATTRIBUT_OBLIGATOIRE_MANQUANT)
  @Pattern(regexp = "executer|annuler", message = IValidationConst.FORMAT_ATTRIBUT_NON_RESPECTE) // $NON-NLS-1$
  private String _action;

  /**
   * Constructeur par copie
   *
   * @param request_p
   *          Objet à copier
   */
  public PE0529_PutRequest(PE0529_PutRequest request_p)
  {
    if (!isNull(request_p))
    {
      _action = request_p._action;
    }
  }

  /**
   * Constructeur
   *
   * @param action_p
   *          Action à réaliser sur l’opération Vie Reseau
   */
  public PE0529_PutRequest(String action_p)
  {
    _action = action_p;
  }

  @Override
  public boolean equals(Object o_p)
  {
    if (this == o_p)
    {
      return true;
    }
    if (o_p == null || getClass() != o_p.getClass())
    {
      return false;
    }
    PE0529_PutRequest that = (PE0529_PutRequest) o_p;
    return Objects.equals(_action, that._action);
  }

  /**
   * @return the action
   */
  public String getAction()
  {
    return _action;
  }

  @Override
  public int hashCode()
  {
    return Objects.hash(_action);
  }

  /**
   * @param action_p
   *          the action to set
   */
  public void setAction(String action_p)
  {
    _action = action_p;
  }

  @Override
  public String toString()
  {
    return "PE0529_PutRequest [" + "_action=" + _action + "]"; // $NON-NLS-1$ // $NON-NLS-2$ // $NON-NLS-3$
  }
}
