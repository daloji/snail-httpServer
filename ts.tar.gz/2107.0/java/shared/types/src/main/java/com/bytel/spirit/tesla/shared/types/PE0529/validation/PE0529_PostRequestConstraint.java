/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.tesla.shared.types.PE0529.validation;

import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import javax.validation.Constraint;
import javax.validation.Payload;
import javax.validation.ReportAsSingleViolation;

import com.bytel.spirit.common.shared.misc.validation.IValidationConst;
import com.bytel.spirit.tesla.shared.types.PE0529.request.PE0529_PostRequest;

/**
 * Validation de la classe {@link PE0529_PostRequest}
 *
 * @author JCHEVRON
 * @version ($Revision$ $Date$)
 */
@Documented
@Target({ FIELD, TYPE })
@Retention(RUNTIME)
@Constraint(validatedBy = { PE0529_PostRequestConstraintValidator.class })
@ReportAsSingleViolation
public @interface PE0529_PostRequestConstraint
{
  /**
   * Allows the specification of validation groups, to which this constraint belongs.
   *
   * @return Validation groups
   */
  Class<?>[] groups() default {};

  /**
   * The message to return when the instance of "PE0529_PostRequest" fails the validation.
   *
   * @return Error message
   */
  String message() default IValidationConst.ATTRIBUT_COND_MANQUANT;

  /**
   * Assign custom payload objects to a constraint.
   *
   * @return Custom payload
   */
  Class<? extends Payload>[] payload() default {};
}
