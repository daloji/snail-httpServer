/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.tesla.shared.types.PE0529;

import static java.util.Objects.isNull;

import java.io.Serializable;
import java.util.Objects;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.bytel.spirit.common.shared.misc.validation.IValidationConst;
import com.squareup.moshi.Json;

/**
 * Represents a port migration, which means a change from source port to target port.
 *
 * @author JCHEVRON
 * @version ($Revision$ $Date$)
 */
public class MigrationPortPm implements Serializable
{
  /**
   * Serial Version UID
   */
  private static final long serialVersionUID = 5355450937313946944L;

  /**
   * Position du port PM Source
   */
  @Valid
  @Json(name = "positionPortPmSource")
  @NotNull(message = IValidationConst.ATTRIBUT_OBLIGATOIRE_MANQUANT)
  private PositionPortPm _positionPortPmSource;

  /**
   * Position du port PM Cible
   */
  @Valid
  @Json(name = "positionPortPmCible")
  @NotNull(message = IValidationConst.ATTRIBUT_OBLIGATOIRE_MANQUANT)
  private PositionPortPm _positionPortPmCible;

  /**
   * Constructeur par copie
   *
   * @param migrationPortPm_p
   *          Objet à copier
   */
  public MigrationPortPm(MigrationPortPm migrationPortPm_p)
  {
    if (!isNull(migrationPortPm_p))
    {
      _positionPortPmSource = migrationPortPm_p._positionPortPmSource;
      _positionPortPmCible = migrationPortPm_p._positionPortPmCible;
    }
  }

  /**
   * Constructeur complet
   *
   * @param positionPortPmSource_p
   *          Position du port PM Source
   * @param positionPortPmCible_p
   *          Position du port PM Cible
   */
  public MigrationPortPm(PositionPortPm positionPortPmSource_p, PositionPortPm positionPortPmCible_p)
  {
    _positionPortPmSource = positionPortPmSource_p;
    _positionPortPmCible = positionPortPmCible_p;
  }

  @Override
  public boolean equals(Object o_p)
  {
    if (this == o_p)
    {
      return true;
    }
    if (o_p == null || getClass() != o_p.getClass())
    {
      return false;
    }
    MigrationPortPm that = (MigrationPortPm) o_p;
    return Objects.equals(_positionPortPmSource, that._positionPortPmSource) && Objects.equals(_positionPortPmCible, that._positionPortPmCible);
  }

  /**
   * @return the positionPortPmCible
   */
  public PositionPortPm getPositionPortPmCible()
  {
    return _positionPortPmCible;
  }

  /**
   * @return the positionPortPmSource
   */
  public PositionPortPm getPositionPortPmSource()
  {
    return _positionPortPmSource;
  }

  @Override
  public int hashCode()
  {
    return Objects.hash(_positionPortPmSource, _positionPortPmCible);
  }

  /**
   * @param positionPortPmCible_p
   *          the positionPortPmCible to set
   */
  public void setPositionPortPmCible(PositionPortPm positionPortPmCible_p)
  {
    _positionPortPmCible = positionPortPmCible_p;
  }

  /**
   * @param positionPortPmSource_p
   *          the positionPortPmSource to set
   */
  public void setPositionPortPmSource(PositionPortPm positionPortPmSource_p)
  {
    _positionPortPmSource = positionPortPmSource_p;
  }

  @Override
  public String toString()
  {
    return "MigrationPortPm [" + "_positionPortPmSource=" + _positionPortPmSource + ", _positionPortPmCible=" + _positionPortPmCible + "]"; // $NON-NLS-1$ // $NON-NLS-2$ // $NON-NLS-3$ // $NON-NLS-4$
  }
}
