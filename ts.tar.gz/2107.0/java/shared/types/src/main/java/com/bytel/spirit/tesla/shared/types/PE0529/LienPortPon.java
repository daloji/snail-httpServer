/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.tesla.shared.types.PE0529;

import static java.util.Objects.isNull;

import java.io.Serializable;
import java.util.Objects;
import java.util.StringJoiner;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.bytel.spirit.common.shared.misc.validation.IValidationConst;
import com.squareup.moshi.Json;

/**
 * Objet lienPortPon
 *
 * @author JCHEVRON
 * @version ($Revision$ $Date$)
 */
public class LienPortPon implements Serializable
{
  private static final long serialVersionUID = 8784535601663537427L;

  /**
   * Olt de rattachement du port panneau
   */
  @Json(name = "nomOLT")
  @NotBlank(message = IValidationConst.ATTRIBUT_OBLIGATOIRE_MANQUANT)
  private String _nomOLT;

  /**
   * La carte Olt de rattachement du port panneau
   */
  @Json(name = "positionCartePon")
  @NotNull(message = IValidationConst.ATTRIBUT_OBLIGATOIRE_MANQUANT)
  @Min(value = 0, message = IValidationConst.FORMAT_ATTRIBUT_NON_RESPECTE)
  private Integer _positionCartePon;

  /**
   * Le Port PON de rattachement du port panneau
   */
  @Json(name = "positionPortPon")
  @NotNull(message = IValidationConst.ATTRIBUT_OBLIGATOIRE_MANQUANT)
  @Min(value = 0, message = IValidationConst.FORMAT_ATTRIBUT_NON_RESPECTE)
  private Integer _positionPortPon;

  /**
   * Constructeur par copie
   *
   * @param lienPortPon_p
   *          Objet à copier
   */
  public LienPortPon(LienPortPon lienPortPon_p)
  {
    if (!isNull(lienPortPon_p))
    {
      _nomOLT = lienPortPon_p._nomOLT;
      _positionCartePon = lienPortPon_p._positionCartePon;
      _positionPortPon = lienPortPon_p._positionPortPon;
    }
  }

  /**
   * Constructeur complet
   *
   * @param nomOLT_p
   *          L’Olt de rattachement du port panneau
   * @param positionCartePon_p
   *          La carte Olt de rattachement du port panneau
   * @param positionPortPon_p
   *          Le Port PON de rattachement du port panneau
   */
  public LienPortPon(String nomOLT_p, Integer positionCartePon_p, Integer positionPortPon_p)
  {
    _nomOLT = nomOLT_p;
    _positionCartePon = positionCartePon_p;
    _positionPortPon = positionPortPon_p;
  }

  @Override
  public boolean equals(Object o_p)
  {
    if (this == o_p)
    {
      return true;
    }
    if (o_p == null || getClass() != o_p.getClass())
    {
      return false;
    }
    LienPortPon that = (LienPortPon) o_p;
    return Objects.equals(_nomOLT, that._nomOLT) && Objects.equals(_positionCartePon, that._positionCartePon) && Objects.equals(_positionPortPon, that._positionPortPon);
  }

  /**
   * @return the nomOLT
   */
  public String getNomOLT()
  {
    return _nomOLT;
  }

  /**
   * @return the positionCartePon
   */
  public Integer getPositionCartePon()
  {
    return _positionCartePon;
  }

  /**
   * @return the positionPortPon
   */
  public Integer getPositionPortPon()
  {
    return _positionPortPon;
  }

  @Override
  public int hashCode()
  {
    return Objects.hash(_nomOLT, _positionCartePon, _positionPortPon);
  }

  /**
   * @param nomOLT_p
   *          the nomOLT to set
   */
  public void setNomOLT(String nomOLT_p)
  {
    _nomOLT = nomOLT_p;
  }

  /**
   * @param positionCartePon_p
   *          the positionCartePon to set
   */
  public void setPositionCartePon(Integer positionCartePon_p)
  {
    _positionCartePon = positionCartePon_p;
  }

  /**
   * @param positionPortPon_p
   *          the positionPortPon to set
   */
  public void setPositionPortPon(Integer positionPortPon_p)
  {
    _positionPortPon = positionPortPon_p;
  }

  /**
   * Cast vers {@link PositionPortPon}
   *
   * @return PositionPortPon
   */
  public PositionPortPon toPositionPortPon()
  {
    return new PositionPortPon(_positionPortPon, _positionCartePon, _nomOLT);
  }

  /**
   * Creation de l'identifiant du LienPortPon
   *
   * @return l'id du lien port pon
   */
  public String toRessourceId()
  {
    StringJoiner joiner = new StringJoiner("_"); //$NON-NLS-1$
    joiner.add(_nomOLT);
    joiner.add(String.valueOf(_positionCartePon));
    joiner.add(String.valueOf(_positionPortPon));
    return joiner.toString();
  }

  @Override
  public String toString()
  {
    return "LienPortPon [" + "_nomOLT=" + _nomOLT + ", _positionCartePon=" + _positionCartePon + ", _positionPortPon=" + _positionPortPon + "]"; // $NON-NLS-1$ // $NON-NLS-2$ // $NON-NLS-3$ // $NON-NLS-4$ // $NON-NLS-5$
  }
}
