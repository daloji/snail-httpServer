/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.tesla.shared.types.PE0533;

/**
 * Types d'equipements
 *
 * @author JCHEVRON
 * @version ($Revision$ $Date$)
 */
public enum TypeEquipement
{
  /**
   * OLT
   */
  OLT,

  /**
   * PM
   */
  PM;
}
