/*******************************************************************************
com.bytel.spirit.tesla.shared.types.PE0533* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.tesla.shared.types.PE0533.response;

import static java.util.Objects.isNull;

import java.io.Serializable;
import java.util.Collections;
import java.util.Set;
import java.util.TreeSet;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;

import com.bytel.spirit.common.shared.misc.validation.IValidationConst;
import com.bytel.spirit.tesla.shared.types.PE0533.Equipement;
import com.squareup.moshi.Json;

/**
 * Reponse d'une requête GET sur le processus {@link PE0533_BlocageEquipement}
 *
 * @author JCHEVRON
 * @version ($Revision$ $Date$)
 */
public class PE0533_GetResponse implements Serializable
{

  /**
   * Serial Version UID
   */
  private static final long serialVersionUID = 4443953651933434589L;

  /**
   * Id de BlocageEquipement à consulter
   */
  @Json(name = "idBlocageEquipement")
  @NotBlank(message = IValidationConst.ATTRIBUT_OBLIGATOIRE_MANQUANT)
  private String _idBlocageEquipement;

  /**
   * Liste des équipements sur lesquels le blocage equipement est appliqué
   */
  @Json(name = "listeEquipement")
  @NotEmpty(message = IValidationConst.ATTRIBUT_OBLIGATOIRE_MANQUANT)
  @Valid
  private Set<Equipement> _listeEquipement;

  /**
   * La liste des idOperationVieReseau associées à l’objet BlocageEquipement
   */
  @Json(name = "listeIdOperationVieReseau")
  @NotEmpty(message = IValidationConst.ATTRIBUT_OBLIGATOIRE_MANQUANT)
  private Set<String> _listeIdOperationVieReseau;

  /**
   * Constructeur par copie
   *
   * @param response_p
   *          Objet à copier
   */
  public PE0533_GetResponse(PE0533_GetResponse response_p)
  {
    if (!isNull(response_p))
    {
      _idBlocageEquipement = response_p._idBlocageEquipement;
      _listeEquipement = response_p._listeEquipement;
      _listeIdOperationVieReseau = response_p._listeIdOperationVieReseau;
    }
  }

  /**
   * Constructeur
   *
   * @param idBlocageEquipement_p
   *          Id de BlocageEquipement à consulter
   * @param listeEquipement_p
   *          Liste des équipements sur lesquels le blocage equipement est appliqué
   * @param listeIdOperationVieReseau_p
   *          La liste des idOperationVieReseau associées à l’objet BlocageEquipement
   */
  public PE0533_GetResponse(String idBlocageEquipement_p, Set<Equipement> listeEquipement_p, Set<String> listeIdOperationVieReseau_p)
  {
    _idBlocageEquipement = idBlocageEquipement_p;
    _listeEquipement = isNull(listeEquipement_p) ? null : new TreeSet<>(listeEquipement_p);
    _listeIdOperationVieReseau = isNull(listeIdOperationVieReseau_p) ? null : new TreeSet<>(listeIdOperationVieReseau_p);
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    PE0533_GetResponse other = (PE0533_GetResponse) obj;
    if (_idBlocageEquipement == null)
    {
      if (other._idBlocageEquipement != null)
      {
        return false;
      }
    }
    else if (!_idBlocageEquipement.equals(other._idBlocageEquipement))
    {
      return false;
    }
    if (_listeEquipement == null)
    {
      if (other._listeEquipement != null)
      {
        return false;
      }
    }
    else if (!_listeEquipement.equals(other._listeEquipement))
    {
      return false;
    }
    if (_listeIdOperationVieReseau == null)
    {
      if (other._listeIdOperationVieReseau != null)
      {
        return false;
      }
    }
    else if (!_listeIdOperationVieReseau.equals(other._listeIdOperationVieReseau))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the idBlocageEquipement
   */
  public String getIdBlocageEquipement()
  {
    return _idBlocageEquipement;
  }

  /**
   * @return the listeEquipement
   */
  public Set<Equipement> getListeEquipement()
  {
    return isNull(_listeEquipement) ? null : Collections.unmodifiableSet(_listeEquipement);
  }

  /**
   * @return the listeIdOperationVieReseau
   */
  public Set<String> getListeIdOperationVieReseau()
  {
    return isNull(_listeIdOperationVieReseau) ? null : Collections.unmodifiableSet(_listeIdOperationVieReseau);
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_idBlocageEquipement == null) ? 0 : _idBlocageEquipement.hashCode());
    result = (prime * result) + ((_listeEquipement == null) ? 0 : _listeEquipement.hashCode());
    result = (prime * result) + ((_listeIdOperationVieReseau == null) ? 0 : _listeIdOperationVieReseau.hashCode());
    return result;
  }

  /**
   * @param idBlocageEquipement_p
   *          the idBlocageEquipement to set
   */
  public void setIdBlocageEquipement(String idBlocageEquipement_p)
  {
    _idBlocageEquipement = idBlocageEquipement_p;
  }

  /**
   * @param listeEquipement_p
   *          the listeEquipement to set
   */
  public void setListeEquipement(Set<Equipement> listeEquipement_p)
  {
    _listeEquipement = isNull(listeEquipement_p) ? null : new TreeSet<>(listeEquipement_p);
  }

  /**
   * @param listeIdOperationVieReseau_p
   *          the listeIdOperationVieReseau to set
   */
  public void setListeIdOperationVieReseau(Set<String> listeIdOperationVieReseau_p)
  {
    _listeIdOperationVieReseau = isNull(listeIdOperationVieReseau_p) ? null : new TreeSet<>(listeIdOperationVieReseau_p);
  }

  @Override
  public String toString()
  {
    return "PE0533_GetResponse [_idBlocageEquipement=" + _idBlocageEquipement + ", _listeEquipement=" + _listeEquipement + ", _listeIdOperationVieReseau=" + _listeIdOperationVieReseau + "]"; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
  }

}
