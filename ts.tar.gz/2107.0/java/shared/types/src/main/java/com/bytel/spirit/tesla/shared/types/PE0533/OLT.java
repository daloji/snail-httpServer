/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.tesla.shared.types.PE0533;

import static java.util.Objects.compare;
import static java.util.Objects.hash;
import static java.util.Objects.isNull;

import java.util.Collections;
import java.util.Comparator;
import java.util.Objects;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.bytel.spirit.common.shared.misc.validation.IValidationConst;
import com.squareup.moshi.Json;

/**
 * Equipement de type OLT
 *
 * @author JCHEVRON
 * @version ($Revision$ $Date$)
 */
public final class OLT extends Equipement
{
  /**
   * Nom de l'OLT
   */
  @Json(name = "nomOLT")
  @NotBlank(message = IValidationConst.ATTRIBUT_OBLIGATOIRE_MANQUANT)
  private String _nomOLT;

  /**
   * Liste des position des cartes de l’OLT
   */
  @Json(name = "listePositionCarte")
  private Set<Integer> _listePositionCarte;

  /**
   * Constructor for fucking SAAB object
   *
   * @param equipement_p
   *          SAAB object
   */
  public OLT(@NotNull final com.bytel.spirit.common.shared.saab.rex.Equipement equipement_p)
  {
    super(TypeEquipement.OLT.name());

    _nomOLT = equipement_p.getNomOLT();
    _listePositionCarte = isNull(equipement_p.getListePositionCarte()) ? null : equipement_p.getListePositionCarte().stream().map(Integer::valueOf).collect(Collectors.toCollection(TreeSet::new));
  }

  /**
   * Constructeur par copie
   *
   * @param olt_p
   *          Objet à copier
   */
  public OLT(final OLT olt_p)
  {
    super(TypeEquipement.OLT.name());

    if (!isNull(olt_p))
    {
      _nomOLT = olt_p.getNomOLT();
      _listePositionCarte = olt_p.getListePositionCarte();
    }
  }

  /**
   * Constructeur
   *
   * @param nomOLT_p
   *          Nom de l'OLT
   */
  public OLT(@NotNull final String nomOLT_p)
  {
    super(TypeEquipement.OLT.name());

    _nomOLT = nomOLT_p;
    _listePositionCarte = null;
  }

  @Override
  public final int compareTo(final Object object_p)
  {
    if (isNull(object_p) || //
        (getClass() != object_p.getClass()))
    {
      //Return 1 for PM (OLT return -1)
      return -1;
    }

    final OLT other = OLT.class.cast(object_p);
    if (_type.equals(other.getType()))
    {
      return compare(this, other, Comparator.comparing(OLT::getType) //
          .thenComparing(OLT::getNomOLT));
    }

    return -1;
  }

  @Override
  public boolean equals(final Object object_p)
  {
    if (this == object_p)
    {
      return true;
    }

    if (isNull(object_p) || //
        (getClass() != object_p.getClass()))
    {
      return false;
    }

    final OLT other = OLT.class.cast(object_p);
    return Objects.equals(_nomOLT, other.getNomOLT()) && //
        Objects.equals(_listePositionCarte, other.getListePositionCarte());
  }

  /**
   * @return the listePositionCarte
   */
  public Set<Integer> getListePositionCarte()
  {
    return isNull(_listePositionCarte) ? null : Collections.unmodifiableSet(_listePositionCarte);
  }

  /**
   * @return the nomOLT
   */
  public String getNomOLT()
  {
    return _nomOLT;
  }

  @Override
  public final int hashCode()
  {
    return hash(_nomOLT, _listePositionCarte);
  }

  /**
   * @param listePositionCarte_p
   *          the listePositionCarte to set
   */
  public void setListePositionCarte(final Set<Integer> listePositionCarte_p)
  {
    _listePositionCarte = isNull(listePositionCarte_p) ? null : new TreeSet<>(listePositionCarte_p);
  }

  /**
   * @param nomOLT_p
   *          the nomOLT to set
   */
  public void setNomOLT(@NotNull final String nomOLT_p)
  {
    _nomOLT = nomOLT_p;
  }

  @Override
  public com.bytel.spirit.common.shared.saab.rex.Equipement toSAAB()
  {
    final com.bytel.spirit.common.shared.saab.rex.Equipement equipement = new com.bytel.spirit.common.shared.saab.rex.Equipement(TypeEquipement.OLT.name());
    equipement.setNomOLT(_nomOLT);
    equipement.setListePositionCarte(isNull(_listePositionCarte) ? null : new TreeSet<>(_listePositionCarte));

    return equipement;
  }

  @Override
  public final String toString()
  {
    return new StringBuilder() //
        .append("OLT [_nomOLT=") //$NON-NLS-1$
        .append(_nomOLT) //
        .append(", _listePositionCarte=") //$NON-NLS-1$
        .append(_listePositionCarte) //
        .append("]") //$NON-NLS-1$
        .toString();
  }

  /**
   * @param listePositionCarte_p
   *          the listePositionCarte to set
   * @return The current handler
   * @note Support of fluentAPI
   */
  public OLT withListPositionCarte(@NotNull final Set<Integer> listePositionCarte_p)
  {
    _listePositionCarte = isNull(listePositionCarte_p) ? null : new TreeSet<>(listePositionCarte_p);

    return this;
  }
}
