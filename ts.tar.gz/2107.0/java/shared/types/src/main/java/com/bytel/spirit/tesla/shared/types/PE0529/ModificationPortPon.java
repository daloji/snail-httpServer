/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.tesla.shared.types.PE0529;

import static java.util.Objects.isNull;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import com.bytel.spirit.common.shared.misc.validation.IValidationConst;
import com.squareup.moshi.Json;

/**
 * Objet modificationPortPon
 *
 * @author JCHEVRON
 * @version ($Revision$ $Date$)
 */
public class ModificationPortPon implements Serializable
{
  private static final long serialVersionUID = -4627211712795459290L;

  /**
   * Position du port PON sur la carte
   */
  @Valid
  @Json(name = "positionPortPon")
  @NotNull(message = IValidationConst.ATTRIBUT_OBLIGATOIRE_MANQUANT)
  private PositionPortPon _positionPortPon;

  /**
   * Liste des technos compatibles. Ce Champ SPIRIT doit être ignoré par NRM dans l’interface OSS.NRM du projet PON128
   */
  @Json(name = "sfpListeTechnologieCompatible")
  @NotEmpty(message = IValidationConst.ATTRIBUT_OBLIGATOIRE_MANQUANT)
  private List<@Pattern(regexp = "GPON|XGSPON", message = IValidationConst.FORMAT_ATTRIBUT_NON_RESPECTE) String> _sfpListeTechnologieCompatible;

  /**
   * Constructeur par copie
   *
   * @param modificationPortPon_p
   *          Objet à copier
   */
  public ModificationPortPon(ModificationPortPon modificationPortPon_p)
  {
    if (!isNull(modificationPortPon_p))
    {
      _positionPortPon = modificationPortPon_p._positionPortPon;
      _sfpListeTechnologieCompatible = modificationPortPon_p._sfpListeTechnologieCompatible;
    }
  }

  /**
   * Constructeur complet
   *
   * @param positionPortPon_p
   *          Position du port PON sur la carte
   * @param sfpListeTechnologieCompatible_p
   *          Liste des technos compatibles.
   */
  public ModificationPortPon(PositionPortPon positionPortPon_p, List<String> sfpListeTechnologieCompatible_p)
  {
    _positionPortPon = positionPortPon_p;
    _sfpListeTechnologieCompatible = isNull(sfpListeTechnologieCompatible_p) ? null : new ArrayList<>(sfpListeTechnologieCompatible_p);
  }

  @Override
  public boolean equals(Object o_p)
  {
    if (this == o_p)
    {
      return true;
    }
    if (o_p == null || getClass() != o_p.getClass())
    {
      return false;
    }
    ModificationPortPon that = (ModificationPortPon) o_p;
    return Objects.equals(_positionPortPon, that._positionPortPon) && Objects.equals(_sfpListeTechnologieCompatible, that._sfpListeTechnologieCompatible);
  }

  /**
   * @return the positionPortPon
   */
  public PositionPortPon getPositionPortPon()
  {
    return _positionPortPon;
  }

  /**
   * @return the sfpListeTechnologieCompatible
   */
  public List<String> getSfpListeTechnologieCompatible()
  {
    return isNull(_sfpListeTechnologieCompatible) ? null : Collections.unmodifiableList(_sfpListeTechnologieCompatible);
  }

  @Override
  public int hashCode()
  {
    return Objects.hash(_positionPortPon, _sfpListeTechnologieCompatible);
  }

  /**
   * @param positionPortPon_p
   *          the positionPortPon to set
   */
  public void setPositionPortPon(PositionPortPon positionPortPon_p)
  {
    _positionPortPon = positionPortPon_p;
  }

  /**
   * @param sfpListeTechnologieCompatible_p
   *          the sfpListeTechnologieCompatible to set
   */
  public void setSfpListeTechnologieCompatible(List<String> sfpListeTechnologieCompatible_p)
  {
    _sfpListeTechnologieCompatible = isNull(sfpListeTechnologieCompatible_p) ? null : new ArrayList<>(sfpListeTechnologieCompatible_p);
  }

  @Override
  public String toString()
  {
    return "ModificationPortPon [" + "_positionPortPon=" + _positionPortPon + ", _sfpListeTechnologieCompatible=" + _sfpListeTechnologieCompatible + "]"; // $NON-NLS-1$ // $NON-NLS-2$ // $NON-NLS-3$ // $NON-NLS-4$
  }
}
