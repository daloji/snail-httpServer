/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.tesla.processes.PI0344;

import static org.junit.Assert.assertEquals;

import java.text.MessageFormat;
import java.time.LocalDateTime;

import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.test.context.ContextConfiguration;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.response.IRavelResponse;
import com.bytel.ravel.common.factory.response.RavelResponseFactory;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.utils.ACManagerUtil;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.RetourFactoryForTU;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.ProcessManager;
import com.bytel.ravel.services.utils.Test_Consts;
import com.bytel.spirit.common.connectors.nrm.oracle.NRMOracleConnectorProxy;
import com.bytel.spirit.common.connectors.nrm.structs.NRMDescReseauRetour;
import com.bytel.spirit.common.connectors.nrm.structs.NRMOracleRetour;
import com.bytel.spirit.common.shared.functional.types.json.RavelJsonTools;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.RetourConverter;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.StatutTechniqueOlt;
import com.bytel.spirit.tesla.processes.Messages;
import com.bytel.spirit.tesla.processes.PI0344.PI0344_RecupererDetailProvisioningPON.ParameterUrl;
import com.bytel.spirit.tesla.processes.PI0344.sti.PI0344_RecupererDetailProvisioningPONCarte;
import com.bytel.spirit.tesla.processes.PI0344.sti.PI0344_RecupererDetailProvisioningPONDonneesSpecifiques;
import com.bytel.spirit.tesla.processes.PI0344.sti.PI0344_RecupererDetailProvisioningPONOlt;
import com.bytel.spirit.tesla.processes.PI0344.sti.PI0344_RecupererDetailProvisioningPONSti;
import com.bytel.spirit.tesla.processes.PI0344.sti.PI0344_Retour;
import com.bytel.spirit.tesla.processes.PI0344.sti.PI0344_Retour.ReponseFonctionnelle;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author mbaptist
 * @version ($Revision$ $Date$)
 */

@RunWith(PowerMockRunner.class)
@ContextConfiguration("classpath:BeansProcessTestMocks.xml")
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
@PrepareForTest({ NRMOracleConnectorProxy.class })

public class PI0344_RecupererDetailProvisioningPONTest
{

  /**
   * Tracabilite
   */
  private static Tracabilite _tracabilite;

  /**
   * Factory de génération des beans
   */
  private static PodamFactory __podam = new PodamFactoryImpl();

  /**
   * SPRING context
   */
  @SuppressWarnings("unused")
  private static ClassPathXmlApplicationContext __context;

  /**
   * The default process name.
   */
  public static final String DEFAULT_PROCESSNAME = "PI0344_RecupererDetailProvisioningPON"; //$NON-NLS-1$

  /**
   * Initialization method: Create: - spring context - connectors - service manager.
   *
   * @throws RavelException
   *           the exception
   */
  @BeforeClass
  public static void init() throws RavelException
  {
    // désactivation du cache podam
    __podam.getStrategy().setMemoization(false);
    __podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());

    ACManagerUtil.resetACManager();
    __context = new ClassPathXmlApplicationContext("classpath:BeansProcessTestMocks.xml"); //$NON-NLS-1$
  }

  /**
   * Instance of {@link PI0344_RecupererDetailProvisioningPON}
   */
  private PI0344_RecupererDetailProvisioningPON _processInstance;

  /**
   * NRMOracle PRoxy
   */
  @MockStrict
  private NRMOracleConnectorProxy _nrmOracleProxy;

  /**
   * @param responseExpected_p
   *          the response expected
   * @param processResult_p
   *          the process result
   * @throws RavelException
   *           In case of an error
   */
  public void compareResponseNOK(String responseExpected_p, String processResult_p) throws RavelException
  {
    PI0344_Retour responseExpected = RavelJsonTools.getInstance().fromJson(responseExpected_p, PI0344_Retour.class);
    PI0344_Retour processResult = RavelJsonTools.getInstance().fromJson(processResult_p, PI0344_Retour.class);

    assertEquals(responseExpected.getRetour().getCategorie(), processResult.getRetour().getCategorie());
    assertEquals(responseExpected.getRetour().getDiagnostic(), processResult.getRetour().getDiagnostic());
    assertEquals(responseExpected.getRetour().getResultat(), processResult.getRetour().getResultat());
  }

  /**
   * @param responseExpected_p
   *          the response expected
   * @param processResult_p
   *          the process result
   * @throws RavelException
   *           In case of an error
   */
  public void compareResponseOK(String responseExpected_p, String processResult_p) throws RavelException
  {
    PI0344_Retour responseExpected = RavelJsonTools.getInstance().fromJson(responseExpected_p, PI0344_Retour.class);
    PI0344_Retour processResult = RavelJsonTools.getInstance().fromJson(processResult_p, PI0344_Retour.class);

    assertEquals(responseExpected.getReponseFonctionnelle().getPI0344RecupererDetailProvisioningPONCarte(), processResult.getReponseFonctionnelle().getPI0344RecupererDetailProvisioningPONCarte());
    assertEquals(responseExpected.getReponseFonctionnelle().getPI0344RecupererDetailProvisioningPONOlt().getConstructeur(), processResult.getReponseFonctionnelle().getPI0344RecupererDetailProvisioningPONOlt().getConstructeur());
    assertEquals(responseExpected.getReponseFonctionnelle().getPI0344RecupererDetailProvisioningPONOlt().getDateCreation(), processResult.getReponseFonctionnelle().getPI0344RecupererDetailProvisioningPONOlt().getDateCreation());
    assertEquals(responseExpected.getReponseFonctionnelle().getPI0344RecupererDetailProvisioningPONOlt().getDateModification(), processResult.getReponseFonctionnelle().getPI0344RecupererDetailProvisioningPONOlt().getDateModification());
    assertEquals(responseExpected.getReponseFonctionnelle().getPI0344RecupererDetailProvisioningPONOlt().getModele(), processResult.getReponseFonctionnelle().getPI0344RecupererDetailProvisioningPONOlt().getModele());
    assertEquals(responseExpected.getReponseFonctionnelle().getPI0344RecupererDetailProvisioningPONOlt().getNomNR(), processResult.getReponseFonctionnelle().getPI0344RecupererDetailProvisioningPONOlt().getNomNR());
    assertEquals(responseExpected.getReponseFonctionnelle().getPI0344RecupererDetailProvisioningPONOlt().getNomOLT(), processResult.getReponseFonctionnelle().getPI0344RecupererDetailProvisioningPONOlt().getNomOLT());
    assertEquals(responseExpected.getReponseFonctionnelle().getPI0344RecupererDetailProvisioningPONOlt().getVersionInterfaceEchange(), processResult.getReponseFonctionnelle().getPI0344RecupererDetailProvisioningPONOlt().getVersionInterfaceEchange());
    assertEquals(responseExpected.getReponseFonctionnelle().getPI0344RecupererDetailProvisioningPONOlt().getNomOmc(), processResult.getReponseFonctionnelle().getPI0344RecupererDetailProvisioningPONOlt().getNomOmc());
    assertEquals(responseExpected.getReponseFonctionnelle().getStatutTechnique(), processResult.getReponseFonctionnelle().getStatutTechnique());
  }

  /**
   * NON NOMINAL Tests the PI0344_RecupererDetailProvisioningPON
   *
   * Parameters are Ok<br>
   * Call continueProcess<br>
   * <b>Expected:</b> Request response : OK_0200 <br>
   * <b>"{\"retour\":{\"resultat\":\"OK\""<br>
   *
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void PI0344_RecupererDetailProvisioningPON_KO_ContinueProcess() throws Throwable
  {
    RavelException exception = null;
    Request request = prepareRequest("nomolt", 25); //$NON-NLS-1$

    try
    {
      _processInstance.continueProcess(request, new Tracabilite());
    }
    catch (RavelException e)
    {
      exception = e;
    }

    assertEquals("Unexpected continueProcess for PI0344_RecupererDetailProvisioningPON at the current state.", exception.getMessage()); //$NON-NLS-1$
    assertEquals(ExceptionType.UNEXPECTED, exception.getExceptionType());
    assertEquals(ErrorCode.PRCESS_00001, exception.getErrorCode());

  }

  /**
   * NON NOMINAL Tests - when the unmarshal gives an Exception.
   *
   * <b>Inputs:</b> Request without parameters<br>
   * <b>Expected:</b> Request response : KO_00400 <br>
   * <b>"{\"retour\":{\"resultat\":\"NOK\",\"categorie\":\"CAT-3\",\"diagnostic\":\"NON_RESPECT_STI\"<br>
   *
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void PI0344_RecupererDetailProvisioningPON_KO_EXCEPTION001() throws Throwable
  {
    Request request = new Request(DEFAULT_PROCESSNAME, "idProcess", "idClient"); //$NON-NLS-1$ //$NON-NLS-2$
    request.setMsgId(Test_Consts.DEFAULT_MSGID);

    request.setPayload("{/}"); //$NON-NLS-1$

    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, "Non respect du format d'entrée de la STI"); //$NON-NLS-1$

    PI0344_Retour responseExpected = new PI0344_Retour(RetourConverter.convertToJsonRetour(retour), null);
    ReponseFonctionnelle reponse = new ReponseFonctionnelle(null, null, null, _tracabilite, null);
    responseExpected.setReponseFonctionnelle(reponse);

    PowerMock.replayAll();
    _processInstance.run(request);

    PowerMock.verify();

    IRavelResponse response = request.getResponse();

    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(RavelJsonTools.getInstance().toJson(responseExpected, PI0344_Retour.class));

    assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    compareResponseNOK(ravelResponse.getResult(), response.getGenericResponse().getResult());
    assertEquals(RetourFactory.createOkRetour(), _processInstance.getRetour());
  }

  /**
   * NON NOMINAL Tests - when the NRMOracleConnectorProxy throws Exception.
   *
   * <b>Inputs:</b> Request without parameters<br>
   * <b>Expected:</b> Request response : KO_00503 <br>
   * <b>"{\"retour\":{\"resultat\":\"NOK\",\"categorie\":\"CAT-2\",\"diagnostic\":\"SERVICE_TIERS_INDISPONIBLE\"<br>
   *
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void PI0344_RecupererDetailProvisioningPON_KO_EXCEPTION002() throws Throwable
  {
    Request request = prepareRequest("nomolt", 25); //$NON-NLS-1$

    Retour retour = RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, "Error database"); //$NON-NLS-1$

    PI0344_Retour responseExpected = new PI0344_Retour(RetourConverter.convertToJsonRetour(retour), null);

    PI0344_RecupererDetailProvisioningPONOlt oltExpected = prepareOlt(StatutTechniqueOlt.OPERATIONNEL.name());
    PI0344_RecupererDetailProvisioningPONCarte carteExpected = prepareCarte(StatutTechniqueOlt.SUPPRIME.name());
    PI0344_RecupererDetailProvisioningPONDonneesSpecifiques donneesSpecifiquesP2PExpected = new PI0344_RecupererDetailProvisioningPONDonneesSpecifiques();
    String statutTechnique = StatutTechniqueOlt.SUPPRIME.name();
    ReponseFonctionnelle reponseFonctionnelle = new ReponseFonctionnelle(oltExpected, carteExpected, donneesSpecifiquesP2PExpected, _tracabilite, statutTechnique);
    responseExpected.setReponseFonctionnelle(reponseFonctionnelle);

    EasyMock.expect(NRMOracleConnectorProxy.getInstance()).andReturn(_nrmOracleProxy);
    EasyMock.expect(_nrmOracleProxy.lireNrmDescReseau(_tracabilite, "nomolt", 25)).andThrow(new RavelException(ExceptionType.DATABASE_ERROR, ErrorCode.CNCTOR_00010, "Error database")); //$NON-NLS-1$ //$NON-NLS-2$

    PowerMock.replayAll();
    _processInstance.run(request);

    PowerMock.verify();

    IRavelResponse response = request.getResponse();

    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(RavelJsonTools.getInstance().toJson(responseExpected, PI0344_Retour.class));

    assertEquals(ErrorCode.KO_00503, response.getErrorCode());
    compareResponseNOK(ravelResponse.getResult(), response.getGenericResponse().getResult());
    assertEquals(RetourFactory.createOkRetour(), _processInstance.getRetour());
  }

  /**
   * NON NOMINAL Tests the PI0344_RecupererDetailProvisioningPON process when request is invalid NomOlt null or empty.
   *
   * <b>Inputs:</b> Request without parameters<br>
   * <b>Expected:</b> Request response : KO_00400 <br>
   * <b>"{\"retour\":{\"resultat\":\"NOK\",\"categorie\":\"CAT-3\",\"diagnostic\":\"ENTREE_INCORRECTE\"<br>
   *
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void PI0344_RecupererDetailProvisioningPON_KO_PARAMETER001() throws Throwable
  {
    Request request = prepareRequest(null, null);

    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ENTREE_INCORRECTE, MessageFormat.format(Messages.getString("PI0344.BL001.ParameterNullOrEmpty"), ParameterUrl.nomOlt.name())); //$NON-NLS-1$

    PI0344_Retour responseExpected = new PI0344_Retour(RetourConverter.convertToJsonRetour(retour), null);
    ReponseFonctionnelle reponse = new ReponseFonctionnelle(null, null, null, _tracabilite, null);
    responseExpected.setReponseFonctionnelle(reponse);

    PowerMock.replayAll();
    _processInstance.run(request);

    PowerMock.verify();

    IRavelResponse response = request.getResponse();

    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(RavelJsonTools.getInstance().toJson(responseExpected, PI0344_Retour.class));

    assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    compareResponseNOK(ravelResponse.getResult(), response.getGenericResponse().getResult());
    assertEquals(RetourFactory.createOkRetour(), _processInstance.getRetour());
  }

  /**
   * NON NOMINAL Tests the PI0344_RecupererDetailProvisioningPON process when request is invalid PositionCartePON null
   * or empty.
   *
   * <b>Inputs:</b> Request with parameters, Missing PositionCartePON<br>
   * <b>Expected:</b> Request response : KO_00400 <br>
   * <b>"{\"retour\":{\"resultat\":\"NOK\",\"categorie\":\"CAT-3\",\"diagnostic\":\"ENTREE_INCORRECTE\"<br>
   *
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void PI0344_RecupererDetailProvisioningPON_KO_PARAMETER002() throws Throwable
  {
    Request request = prepareRequest("nomOlt", null); //$NON-NLS-1$

    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ENTREE_INCORRECTE, MessageFormat.format(Messages.getString("PI0344.BL001.ParameterNullOrEmpty"), ParameterUrl.positionCartePON.name())); //$NON-NLS-1$

    PI0344_Retour responseExpected = new PI0344_Retour(RetourConverter.convertToJsonRetour(retour), null);
    ReponseFonctionnelle reponse = new ReponseFonctionnelle(null, null, null, _tracabilite, null);
    responseExpected.setReponseFonctionnelle(reponse);

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verify();

    IRavelResponse response = request.getResponse();

    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(RavelJsonTools.getInstance().toJson(responseExpected, PI0344_Retour.class));

    assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    compareResponseNOK(ravelResponse.getResult(), response.getGenericResponse().getResult());
    assertEquals(RetourFactory.createOkRetour(), _processInstance.getRetour());
  }

  /**
   * NON NOMINAL Tests the PI0344_RecupererDetailProvisioningPON process when request is invalid PositionCartePON is
   * invalid.
   *
   * <b>Inputs:</b> Request with parameters, PositionCartePON is less than 0<br>
   * <b>Expected:</b> Request response : KO_00400 <br>
   * <b>"{\"retour\":{\"resultat\":\"NOK\",\"categorie\":\"CAT-3\",\"diagnostic\":\"ENTREE_INCORRECTE\"<br>
   *
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void PI0344_RecupererDetailProvisioningPON_KO_PARAMETER003() throws Throwable
  {
    Request request = prepareRequest("nomOlt", -2); //$NON-NLS-1$

    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ENTREE_INCORRECTE, MessageFormat.format(Messages.getString("PI0344.BL001.InvalidFieldValue"), ParameterUrl.positionCartePON.name())); //$NON-NLS-1$

    PI0344_Retour responseExpected = new PI0344_Retour(RetourConverter.convertToJsonRetour(retour), null);
    ReponseFonctionnelle reponse = new ReponseFonctionnelle(null, null, null, _tracabilite, null);
    responseExpected.setReponseFonctionnelle(reponse);

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verify();

    IRavelResponse response = request.getResponse();

    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(RavelJsonTools.getInstance().toJson(responseExpected, PI0344_Retour.class));

    assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    compareResponseNOK(ravelResponse.getResult(), response.getGenericResponse().getResult());
    assertEquals(RetourFactory.createOkRetour(), _processInstance.getRetour());
  }

  /**
   * NON NOMINAL Tests the PI0344_RecupererDetailProvisioningPON process when body parameter is null
   *
   * <b>Inputs:</b> Request with parameters, PositionCartePON is less than 0<br>
   * <b>Expected:</b> Request response : KO_00400 <br>
   * <b>"{\"retour\":{\"resultat\":\"NOK\",\"categorie\":\"CAT-3\",\"diagnostic\":\"ENTREE_INCORRECTE\"<br>
   *
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void PI0344_RecupererDetailProvisioningPON_KO_PARAMETER004() throws Throwable
  {
    Request request = prepareRequest("nomOlt", 25); //$NON-NLS-1$
    request.setPayload(null);

    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ENTREE_INCORRECTE, "The body request is empty."); //$NON-NLS-1$

    PI0344_Retour responseExpected = new PI0344_Retour(RetourConverter.convertToJsonRetour(retour), null);
    ReponseFonctionnelle reponse = new ReponseFonctionnelle(null, null, null, _tracabilite, null);
    responseExpected.setReponseFonctionnelle(reponse);

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verify();

    IRavelResponse response = request.getResponse();

    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(RavelJsonTools.getInstance().toJson(responseExpected, PI0344_Retour.class));

    assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    compareResponseNOK(ravelResponse.getResult(), response.getGenericResponse().getResult());
    assertEquals(RetourFactory.createOkRetour(), _processInstance.getRetour());
  }

  /**
   * NON NOMINAL Tests the PI0344_RecupererDetailProvisioningPON case
   * pad3200OltCompositeLireUn:CAT6/DONNEE_NON_DISPONIBLE.
   *
   * Parameters are Ok<br>
   * CALL BL001 return OK <br>
   * CALL BL100 return NOK <br>
   * CALL NRMOracleConnectorProxy.lireNrmDescReseau return NRMDescReseauRetour (constructeur, versionInterfaceEchange,
   * statutTechniqueOlt, statutTechniqueCarte) <br>
   * <b>Inputs:</b> Request with valid parameters <br>
   * <b>Expected:</b> Request response : KO_00500 <br>
   * <b>"{\"retour\":{\"resultat\":\"NOK\",\"categorie\":\"CAT-6\",\"diagnostic\":\"DONNEE_NON_DISPONIBLE\"<br>
   *
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void PI0344_RecupererDetailProvisioningPON_TEST01() throws Throwable
  {
    Request request = prepareRequest("nomolt", 1); //$NON-NLS-1$

    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT6, IMegSpiritConsts.DONNEE_NON_DISPONIBLE, ""); //$NON-NLS-1$

    PI0344_Retour responseExpected = new PI0344_Retour(RetourConverter.convertToJsonRetour(retour), null);
    ReponseFonctionnelle reponse = new ReponseFonctionnelle(null, null, null, _tracabilite, null);
    responseExpected.setReponseFonctionnelle(reponse);

    NRMOracleRetour nrmRetour = new NRMOracleRetour(-1, ""); //$NON-NLS-1$
    NRMDescReseauRetour retourNrmOracleConnectorProxy = new NRMDescReseauRetour("nomolt", "constructeur", "modele", "versionInterfaceEchange", "statutTechniqueOlt", "statutTechniqueCarte", "nomOmc"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$

    ConnectorResponse<NRMOracleRetour, NRMDescReseauRetour> resultNrmOracleProxy = new ConnectorResponse<NRMOracleRetour, NRMDescReseauRetour>(nrmRetour, retourNrmOracleConnectorProxy);

    EasyMock.expect(NRMOracleConnectorProxy.getInstance()).andReturn(_nrmOracleProxy);
    EasyMock.expect(_nrmOracleProxy.lireNrmDescReseau(_tracabilite, "nomolt", 1)).andReturn(resultNrmOracleProxy); //$NON-NLS-1$

    PowerMock.replayAll();
    _processInstance.run(request);

    PowerMock.verify();

    IRavelResponse response = request.getResponse();

    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(RavelJsonTools.getInstance().toJson(responseExpected, PI0344_Retour.class));

    assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    compareResponseNOK(ravelResponse.getResult(), response.getGenericResponse().getResult());
    assertEquals(RetourFactory.createOkRetour(), _processInstance.getRetour());
  }

  /**
   * NOMINAL Tests the PI0344_RecupererDetailProvisioningPON
   *
   * Parameters are Ok<br>
   * CALL BL001 return OK <br>
   * CALL BL100 return OK <br>
   * CALL NRMOracleConnectorProxy.lireNrmDescReseau return NRMDescReseauRetour (constructeur, versionInterfaceEchange,
   * statutTechniqueOlt, statutTechniqueCarte) <br>
   * <b>Inputs:</b> Request with valid parameters <br>
   * <b>Expected:</b> Request response : OK_0200 <br>
   * <b>"{\"retour\":{\"resultat\":\"OK\""<br>
   *
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void PI0344_RecupererDetailProvisioningPON_TEST02() throws Throwable
  {
    Request request = prepareRequest("nomolt", 25); //$NON-NLS-1$

    Retour retour = RetourFactory.createOkRetour();

    PI0344_Retour responseExpected = new PI0344_Retour(RetourConverter.convertToJsonRetour(retour), null);

    PI0344_RecupererDetailProvisioningPONOlt oltExpected = prepareOlt(StatutTechniqueOlt.OPERATIONNEL.name());
    PI0344_RecupererDetailProvisioningPONCarte carteExpected = prepareCarte(StatutTechniqueOlt.OPERATIONNEL.name());
    PI0344_RecupererDetailProvisioningPONDonneesSpecifiques donneesSpecifiquesP2PExpected = new PI0344_RecupererDetailProvisioningPONDonneesSpecifiques();
    String statutTechniqueExpected = StatutTechniqueOlt.OPERATIONNEL.name();
    ReponseFonctionnelle reponseFonctionnelle = new ReponseFonctionnelle(oltExpected, carteExpected, donneesSpecifiquesP2PExpected, _tracabilite, statutTechniqueExpected);
    responseExpected.setReponseFonctionnelle(reponseFonctionnelle);

    NRMOracleRetour nrmRetour = new NRMOracleRetour(1, ""); //$NON-NLS-1$
    NRMDescReseauRetour retourNrmOracleConnectorProxy = new NRMDescReseauRetour("nomNR", "constructeur", "modele", "versionInterfaceEchange", "OPERATIONAL", "OPERATIONAL", "nomOmc"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$

    ConnectorResponse<NRMOracleRetour, NRMDescReseauRetour> resultNrmOracleProxy = new ConnectorResponse<NRMOracleRetour, NRMDescReseauRetour>(nrmRetour, retourNrmOracleConnectorProxy);

    EasyMock.expect(NRMOracleConnectorProxy.getInstance()).andReturn(_nrmOracleProxy);
    EasyMock.expect(_nrmOracleProxy.lireNrmDescReseau(_tracabilite, "nomolt", 25)).andReturn(resultNrmOracleProxy); //$NON-NLS-1$

    PowerMock.replayAll();
    _processInstance.run(request);

    PowerMock.verify();

    IRavelResponse response = request.getResponse();

    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(RavelJsonTools.getInstance().toJson(responseExpected, PI0344_Retour.class));

    assertEquals(ErrorCode.OK_00200, response.getErrorCode());
    compareResponseOK(ravelResponse.getResult(), response.getGenericResponse().getResult());
    assertEquals(RetourFactory.createOkRetour(), _processInstance.getRetour());
  }

  /**
   * NOMINAL Tests the PI0344_RecupererDetailProvisioningPON
   *
   * Parameters are Ok<br>
   * CALL BL001 return OK <br>
   * CALL BL100 return OK <br>
   * CALL NRMOracleConnectorProxy.lireNrmDescReseau return NRMDescReseauRetour (constructeur, versionInterfaceEchange,
   * statutTechniqueOlt, statutTechniqueCarte) <br>
   * <b>Inputs:</b> Request with valid parameters <br>
   * <b>Expected:</b> Request response : OK_0200 <br>
   * <b>"{\"retour\":{\"resultat\":\"OK\""<br>
   *
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void PI0344_RecupererDetailProvisioningPON_TEST03() throws Throwable
  {
    Request request = prepareRequest("nomolt", 25); //$NON-NLS-1$

    Retour retour = RetourFactory.createOkRetour();

    PI0344_Retour responseExpected = new PI0344_Retour(RetourConverter.convertToJsonRetour(retour), null);

    PI0344_RecupererDetailProvisioningPONOlt oltExpected = prepareOlt(StatutTechniqueOlt.OPERATIONNEL.name());
    PI0344_RecupererDetailProvisioningPONCarte carteExpected = prepareCarte(StatutTechniqueOlt.SUPPRIME.name());
    PI0344_RecupererDetailProvisioningPONDonneesSpecifiques donneesSpecifiquesP2PExpected = new PI0344_RecupererDetailProvisioningPONDonneesSpecifiques();
    String statutTechnique = StatutTechniqueOlt.SUPPRIME.name();
    ReponseFonctionnelle reponseFonctionnelle = new ReponseFonctionnelle(oltExpected, carteExpected, donneesSpecifiquesP2PExpected, _tracabilite, statutTechnique);
    responseExpected.setReponseFonctionnelle(reponseFonctionnelle);

    NRMOracleRetour nrmRetour = new NRMOracleRetour(1, ""); //$NON-NLS-1$
    NRMDescReseauRetour retourNrmOracleConnectorProxy = new NRMDescReseauRetour("nomNR", "constructeur", "modele", "versionInterfaceEchange", "", "NOT_IN_USE", "nomOmc"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$

    ConnectorResponse<NRMOracleRetour, NRMDescReseauRetour> resultNrmOracleProxy = new ConnectorResponse<NRMOracleRetour, NRMDescReseauRetour>(nrmRetour, retourNrmOracleConnectorProxy);

    EasyMock.expect(NRMOracleConnectorProxy.getInstance()).andReturn(_nrmOracleProxy);
    EasyMock.expect(_nrmOracleProxy.lireNrmDescReseau(_tracabilite, "nomolt", 25)).andReturn(resultNrmOracleProxy); //$NON-NLS-1$

    PowerMock.replayAll();
    _processInstance.run(request);

    PowerMock.verify();

    IRavelResponse response = request.getResponse();

    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(RavelJsonTools.getInstance().toJson(responseExpected, PI0344_Retour.class));

    assertEquals(ErrorCode.OK_00200, response.getErrorCode());
    compareResponseOK(ravelResponse.getResult(), response.getGenericResponse().getResult());
    assertEquals(RetourFactory.createOkRetour(), _processInstance.getRetour());
  }

  /**
   * NOMINAL Tests the PI0344_RecupererDetailProvisioningPON
   *
   * Parameters are Ok<br>
   * CALL BL001 return OK <br>
   * CALL BL100 return OK <br>
   * CALL NRMOracleConnectorProxy.lireNrmDescReseau return NRMDescReseauRetour (constructeur, versionInterfaceEchange,
   * statutTechniqueOlt, statutTechniqueCarte) <br>
   * <b>Inputs:</b> Request with valid parameters <br>
   * <b>Expected:</b> Request response : OK_0200 <br>
   * <b>"{\"retour\":{\"resultat\":\"OK\""<br>
   *
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void PI0344_RecupererDetailProvisioningPON_TEST04() throws Throwable
  {
    Request request = prepareRequest("nomolt", 25); //$NON-NLS-1$

    Retour retour = RetourFactory.createOkRetour();

    PI0344_Retour responseExpected = new PI0344_Retour(RetourConverter.convertToJsonRetour(retour), null);

    PI0344_RecupererDetailProvisioningPONOlt oltExpected = prepareOlt(StatutTechniqueOlt.OPERATIONNEL.name());
    PI0344_RecupererDetailProvisioningPONCarte carteExpected = prepareCarte(StatutTechniqueOlt.OPERATIONNEL.name());
    PI0344_RecupererDetailProvisioningPONDonneesSpecifiques donneesSpecifiquesP2PExpected = new PI0344_RecupererDetailProvisioningPONDonneesSpecifiques();
    String statutTechnique = StatutTechniqueOlt.SUPPRIME.name();
    ReponseFonctionnelle reponseFonctionnelle = new ReponseFonctionnelle(oltExpected, carteExpected, donneesSpecifiquesP2PExpected, _tracabilite, statutTechnique);
    responseExpected.setReponseFonctionnelle(reponseFonctionnelle);

    NRMOracleRetour nrmRetour = new NRMOracleRetour(1, ""); //$NON-NLS-1$
    NRMDescReseauRetour retourNrmOracleConnectorProxy = new NRMDescReseauRetour("nomNR", "constructeur", "modele", "versionInterfaceEchange", "NOT_IN_USE", "OPERATIONAL", "nomOmc"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$

    ConnectorResponse<NRMOracleRetour, NRMDescReseauRetour> resultNrmOracleProxy = new ConnectorResponse<NRMOracleRetour, NRMDescReseauRetour>(nrmRetour, retourNrmOracleConnectorProxy);

    EasyMock.expect(NRMOracleConnectorProxy.getInstance()).andReturn(_nrmOracleProxy);
    EasyMock.expect(_nrmOracleProxy.lireNrmDescReseau(_tracabilite, "nomolt", 25)).andReturn(resultNrmOracleProxy); //$NON-NLS-1$

    PowerMock.replayAll();
    _processInstance.run(request);

    PowerMock.verify();

    IRavelResponse response = request.getResponse();

    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(RavelJsonTools.getInstance().toJson(responseExpected, PI0344_Retour.class));

    assertEquals(ErrorCode.OK_00200, response.getErrorCode());
    compareResponseOK(ravelResponse.getResult(), response.getGenericResponse().getResult());
    assertEquals(RetourFactory.createOkRetour(), _processInstance.getRetour());
  }

  /**
   * NOMINAL Tests the PI0344_RecupererDetailProvisioningPON
   *
   * Parameters are Ok<br>
   * CALL BL001 return OK <br>
   * CALL BL100 return OK <br>
   * CALL NRMOracleConnectorProxy.lireNrmDescReseau return NRMDescReseauRetour (constructeur, versionInterfaceEchange,
   * statutTechniqueOlt, statutTechniqueCarte) <br>
   * <b>Inputs:</b> Request with valid parameters <br>
   * <b>Expected:</b> Request response : OK_0200 <br>
   * <b>"{\"retour\":{\"resultat\":\"OK\""<br>
   *
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void PI0344_RecupererDetailProvisioningPON_TEST05() throws Throwable
  {
    Request request = prepareRequest("nomolt", 25); //$NON-NLS-1$

    Retour retour = RetourFactory.createOkRetour();

    PI0344_Retour responseExpected = new PI0344_Retour(RetourConverter.convertToJsonRetour(retour), null);

    PI0344_RecupererDetailProvisioningPONOlt oltExpected = prepareOlt(StatutTechniqueOlt.OPERATIONNEL.name());
    PI0344_RecupererDetailProvisioningPONCarte carteExpected = prepareCarte(StatutTechniqueOlt.SUPPRIME.name());
    PI0344_RecupererDetailProvisioningPONDonneesSpecifiques donneesSpecifiquesP2PExpected = new PI0344_RecupererDetailProvisioningPONDonneesSpecifiques();
    String statutTechniqueExpected = StatutTechniqueOlt.SUPPRIME.name();
    ReponseFonctionnelle reponseFonctionnelle = new ReponseFonctionnelle(oltExpected, carteExpected, donneesSpecifiquesP2PExpected, _tracabilite, statutTechniqueExpected);
    responseExpected.setReponseFonctionnelle(reponseFonctionnelle);

    NRMOracleRetour nrmRetour = new NRMOracleRetour(1, ""); //$NON-NLS-1$
    NRMDescReseauRetour retourNrmOracleConnectorProxy = new NRMDescReseauRetour("nomNR", "constructeur", "modele", "versionInterfaceEchange", "SUPPRIME", "SUPPRIME", "nomOmc"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$

    ConnectorResponse<NRMOracleRetour, NRMDescReseauRetour> resultNrmOracleProxy = new ConnectorResponse<NRMOracleRetour, NRMDescReseauRetour>(nrmRetour, retourNrmOracleConnectorProxy);

    EasyMock.expect(NRMOracleConnectorProxy.getInstance()).andReturn(_nrmOracleProxy);
    EasyMock.expect(_nrmOracleProxy.lireNrmDescReseau(_tracabilite, "nomolt", 25)).andReturn(resultNrmOracleProxy); //$NON-NLS-1$

    PowerMock.replayAll();
    _processInstance.run(request);

    PowerMock.verify();

    IRavelResponse response = request.getResponse();

    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(RavelJsonTools.getInstance().toJson(responseExpected, PI0344_Retour.class));

    assertEquals(ErrorCode.OK_00200, response.getErrorCode());
    compareResponseOK(ravelResponse.getResult(), response.getGenericResponse().getResult());
    assertEquals(RetourFactory.createOkRetour(), _processInstance.getRetour());
  }

  /**
   * NON NOMINAL Tests the PI0344_RecupererDetailProvisioningPON case
   * pad3200OltCompositeLireUn:CAT6/DONNEE_NON_DISPONIBLE.
   *
   * Parameters are Ok<br>
   * CALL BL001 return OK <br>
   * CALL BL100 return NOK <br>
   * CALL NRMOracleConnectorProxy.lireNrmDescReseau return NRMDescReseauRetour (constructeur, versionInterfaceEchange,
   * statutTechniqueOlt, statutTechniqueCarte) <br>
   * <b>Inputs:</b> Request with valid parameters <br>
   * <b>Expected:</b> Request response : KO_00404 <br>
   * <b>"{\"retour\":{\"resultat\":\"NOK\",\"categorie\":\"CAT-4\",\"diagnostic\":\"ACCES_REFUSE\"<br>
   *
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void PI0344_RecupererDetailProvisioningPON_TEST06() throws Throwable
  {
    Request request = prepareRequest("nomolt", 1); //$NON-NLS-1$

    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.ERREUR_EXTERNE, ""); //$NON-NLS-1$

    PI0344_Retour responseExpected = new PI0344_Retour(RetourConverter.convertToJsonRetour(retour), null);
    ReponseFonctionnelle reponse = new ReponseFonctionnelle(null, null, null, _tracabilite, null);
    responseExpected.setReponseFonctionnelle(reponse);

    NRMOracleRetour nrmRetour = new NRMOracleRetour(-2, ""); //$NON-NLS-1$
    NRMDescReseauRetour retourNrmOracleConnectorProxy = new NRMDescReseauRetour("nomolt", "constructeur", "modele", "versionInterfaceEchange", "statutTechniqueOlt", "statutTechniqueCarte", "nomOmc"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$

    ConnectorResponse<NRMOracleRetour, NRMDescReseauRetour> resultNrmOracleProxy = new ConnectorResponse<NRMOracleRetour, NRMDescReseauRetour>(nrmRetour, retourNrmOracleConnectorProxy);

    EasyMock.expect(NRMOracleConnectorProxy.getInstance()).andReturn(_nrmOracleProxy);
    EasyMock.expect(_nrmOracleProxy.lireNrmDescReseau(_tracabilite, "nomolt", 1)).andReturn(resultNrmOracleProxy); //$NON-NLS-1$

    PowerMock.replayAll();
    _processInstance.run(request);

    PowerMock.verify();

    IRavelResponse response = request.getResponse();

    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(RavelJsonTools.getInstance().toJson(responseExpected, PI0344_Retour.class));

    assertEquals(ErrorCode.KO_00404, response.getErrorCode());
    compareResponseNOK(ravelResponse.getResult(), response.getGenericResponse().getResult());
    assertEquals(RetourFactory.createOkRetour(), _processInstance.getRetour());
  }

  /**
   * Sets the test
   *
   */
  @Before
  public void setUp()
  {
    _processInstance = new PI0344_RecupererDetailProvisioningPON();
    _processInstance.initializeContext();

    _tracabilite = new Tracabilite();
    _tracabilite.setIdCorrelationByTel(StringConstants.EMPTY_STRING);
    _tracabilite.setIdProcessusSpirit(_processInstance.getIdProcess());
    _tracabilite.setIdCorrelationSpirit(Test_Consts.DEFAULT_MSGID);
    _tracabilite.setNomProcessus(StringConstants.EMPTY_STRING);
    _tracabilite.setNomSysteme(System.getenv("SERVICE")); //$NON-NLS-1$

    ProcessManager.getInstance().getProcessParams().clear();

    // on réinitialise tous les mocks afin de ne pas avoir d'interférence entre les tests
    PowerMock.resetAll();
    PowerMock.mockStatic(NRMOracleConnectorProxy.class);

  }

  /**
   * Prepare the object CarteP2P
   *
   * @param statutTechnique_p
   *          le statut technique
   *
   * @return CarteP2P
   */
  private PI0344_RecupererDetailProvisioningPONCarte prepareCarte(String statutTechnique_p)
  {
    return new PI0344_RecupererDetailProvisioningPONCarte(25, "CartePON", statutTechnique_p); //$NON-NLS-1$
  }

  /**
   * Prepare the object Olt
   *
   * @param statutTechnique_p
   *          le statut technique
   *
   * @return Olt
   */
  private PI0344_RecupererDetailProvisioningPONOlt prepareOlt(String statutTechnique_p)
  {
    PI0344_RecupererDetailProvisioningPONOlt olt = new PI0344_RecupererDetailProvisioningPONOlt("nomolt", "nomNR", "constructeur", "modele", "versionInterfaceEchange", statutTechnique_p, "nomOmc"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    olt.setDateDernierImport(LocalDateTime.now());
    return olt;
  }

  /**
   * Create a Generic Request to call PI0344_RecupererDetailProvisioningPON
   *
   * @param nomOlt_p
   *          nomOlt_p
   * @param positionCartePON_p
   *          positionCartePON
   *
   *          * @return GenericRequest to call PI0344_RecupererDetailProvisioningPON
   * @throws RavelException
   *           on error
   */

  private Request prepareRequest(String nomOlt_p, Integer positionCartePON_p) throws RavelException
  {
    Request request = new Request(DEFAULT_PROCESSNAME, "idProcess", "idClient"); //$NON-NLS-1$ //$NON-NLS-2$
    request.setMsgId(Test_Consts.DEFAULT_MSGID);

    PI0344_RecupererDetailProvisioningPONSti recupererDetailProv = new PI0344_RecupererDetailProvisioningPONSti(nomOlt_p, positionCartePON_p);

    //Body parameter
    String payload = RavelJsonTools.getInstance().toJson(recupererDetailProv, PI0344_RecupererDetailProvisioningPONSti.class);
    request.setPayload(payload);

    return request;
  }

}
