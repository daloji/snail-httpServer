/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.tesla.processes.PE0533;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import javax.ws.rs.HttpMethod;

import org.easymock.EasyMock;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PowerMockListener;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.testlisteners.FieldDefaulter;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.modules.junit4.PowerMockRunnerDelegate;
import org.springframework.test.context.ContextConfiguration;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.data.exchange.generated.RavelRequest.RequestHeader;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.request.UrlParameters;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.test.podam.PodamBytelJUnit4ClassRunner;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.net.http.HttpConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.utils.Test_Consts;
import com.bytel.spirit.common.connectors.res.RESProxy;
import com.bytel.spirit.common.connectors.rex.REXProxy;
import com.bytel.spirit.common.shared.functional.types.json.RavelJsonTools;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.error.ReponseErreur;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.TypeIdentifiant;
import com.bytel.spirit.common.shared.saab.rex.BlocageEquipement;
import com.bytel.spirit.tesla.processes.PE0533.PE0533_BlocageEquipements.EquipementComparator;
import com.bytel.spirit.tesla.shared.types.PE0533.Equipement;
import com.bytel.spirit.tesla.shared.types.PE0533.OLT;
import com.bytel.spirit.tesla.shared.types.PE0533.PM;
import com.bytel.spirit.tesla.shared.types.PE0533.response.PE0533_GetResponse;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author bsinquin
 * @version ($Revision$ $Date$)
 */

@RunWith(PowerMockRunner.class)
@PowerMockListener(FieldDefaulter.class)
@PowerMockRunnerDelegate(PodamBytelJUnit4ClassRunner.class)
@ContextConfiguration("classpath:BeansProcessTestMocks.xml")
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
@PrepareForTest({ PE0533_BlocageEquipements.class, REXProxy.class, RESProxy.class })
public final class PE0533_GetBlocageEquipementsTest
{
  /**
   * bean Factory generation
   */
  private static PodamFactory __podam;

  /**
   * The object {@Code Tracabilite}
   */
  private static Tracabilite __traceability;

  /**
   * The default process name.
   */
  public static final String DEFAULT_PROCESSNAME = "PE0533_BlocagePriseClients"; //$NON-NLS-1$

  /**
   * Error message for missing parameter
   */
  private static final Object MESSAGE_URL_PARAMETER_ABSENT = "URL Parameter obligatoire(s) manquant(s): idBlocageEquipement"; //$NON-NLS-1$

  /**
   * Initialize before all tests
   *
   * @throws Exception
   *           Exception to be thrown in case of failure
   */
  @BeforeClass
  public static void setUpBeforeClass() throws Exception
  {
    __podam = new PodamFactoryImpl();
    __podam.getStrategy().setMemoization(false);
    __podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());

    __traceability = __podam.manufacturePojoWithFullData(Tracabilite.class);

  }

  /**
   * Mock de {@link RESProxy}
   */
  @MockStrict
  protected RESProxy _resMock;

  /**
   * Mock de {@REXProxy}
   */
  @MockStrict
  protected REXProxy _rexMock;

  /**
   * Instance to evaluate
   */
  private PE0533_BlocageEquipements _processInstance;

  /**
   * Initialize before tests
   *
   * @throws Exception
   *           Thrown in case of error during switch in attributes of parent class
   */
  @Before
  public void beforeTest() throws Exception
  {

    _processInstance = new PE0533_BlocageEquipements();
    _processInstance.initializeContext();

    __traceability = new Tracabilite();

    PowerMock.resetAll();

    PowerMock.mockStaticStrict(REXProxy.class);
    PowerMock.mockStaticStrict(RESProxy.class);

  }

  /**
   * BL001 NOK Manque parametre idBlocageEquipement
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0533_BlocagePriseClients_GET_BL001_KO_001() throws Throwable
  {
    //Prepare request
    Request request = new Request(DEFAULT_PROCESSNAME, "idProcess", "idClient"); //$NON-NLS-1$ //$NON-NLS-2$
    request.setHttpMethod(HttpMethod.GET);
    request.setMsgId(Test_Consts.DEFAULT_MSGID);
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "Basic AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    request.setRequestHeader(headers);

    PowerMock.replayAll();

    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startGetProcess(request, __traceability);
    Response response = (Response) request.getResponse();

    //Checks
    PowerMock.verifyAll();

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals(MESSAGE_URL_PARAMETER_ABSENT, reponseactual.getErrorDescription());
    Assert.assertEquals(IMegSpiritConsts.DONNEE_INVALIDE, reponseactual.getError());
  }

  /**
   * BL001 NOK Manque parametre idBlocageEquipement #2
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0533_BlocagePriseClients_GET_BL001_KO_002() throws Throwable
  {
    //Prepare request
    Request request = new Request(DEFAULT_PROCESSNAME, "idProcess", "idClient"); //$NON-NLS-1$ //$NON-NLS-2$
    request.setHttpMethod(HttpMethod.GET);
    request.setMsgId(Test_Consts.DEFAULT_MSGID);
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "Basic AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    request.setRequestHeader(headers);

    UrlParameters urlParametersType = new UrlParameters();
    request.setUrlParameters(urlParametersType);

    PowerMock.replayAll();

    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startGetProcess(request, __traceability);
    Response response = (Response) request.getResponse();

    //Checks
    PowerMock.verifyAll();

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals(MESSAGE_URL_PARAMETER_ABSENT, reponseactual.getErrorDescription());
    Assert.assertEquals(IMegSpiritConsts.DONNEE_INVALIDE, reponseactual.getError());
  }

  /**
   * Retour NOK de REX blocageEquipementLireUn
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0533_BlocagePriseClients_GET_BL100_KO_001() throws Throwable
  {
    //Prepare request
    String idBlocagePriseClients = __podam.manufacturePojoWithFullData(String.class);
    Request request = prepareGetRequest(idBlocagePriseClients);

    //Prepare mocks responses
    String libelleErreur = __podam.manufacturePojoWithFullData(String.class);
    ConnectorResponse<Retour, BlocageEquipement> rexResponseLireUn = new ConnectorResponse<Retour, BlocageEquipement>(RetourFactory.createNOK(IMegConsts.CAT10, IMegConsts.TRAITEMENT_ARRETE, libelleErreur), null);

    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexMock).anyTimes();
    EasyMock.expect(_rexMock.blocageEquipementLireUn(__traceability, idBlocagePriseClients)).andReturn(rexResponseLireUn);

    //Execute tests
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startGetProcess(request, __traceability);
    Response response = (Response) request.getResponse();

    //Checks
    PowerMock.verifyAll();

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    Assert.assertEquals(libelleErreur, reponseactual.getErrorDescription());
    Assert.assertEquals(IMegConsts.TRAITEMENT_ARRETE, reponseactual.getError());
  }

  /**
   * Exception sur LireUn
   *
   * @throws Throwable
   *           the exception
   */
  @Test
  public void PE0533_BlocagePriseClients_GET_BL100_KO_002() throws Throwable
  {
    //Prepare request
    String idBlocagePriseClients = __podam.manufacturePojoWithFullData(String.class);
    Request request = prepareGetRequest(idBlocagePriseClients);

    //Prepare mocks responses

    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexMock).anyTimes();

    EasyMock.expect(_rexMock.blocageEquipementLireUn(__traceability, idBlocagePriseClients))//
        .andThrow(new RavelException(ExceptionType.UNDEFINED, ErrorCode.CNCTOR_00010, "Exception")); //$NON-NLS-1$

    //Execute tests
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startDeleteProcess(request, __traceability);
    Response actualResponse = (Response) request.getResponse();

    //Checks
    PowerMock.verifyAll();

    String resp = actualResponse.getGenericResponse().getResult();
    ReponseErreur actualReponseErreur = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00500, actualResponse.getErrorCode());
    Assert.assertEquals("Exception", actualReponseErreur.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegConsts.TRAITEMENT_ARRETE, actualReponseErreur.getError());
  }

  /**
   * Retour OK Aucun PM/OLT (null)
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0533_BlocagePriseClients_GET_BL100_OK_001() throws Throwable
  {
    //Prepare request
    String idBlocagePriseClients = __podam.manufacturePojoWithFullData(String.class);
    Request request = prepareGetRequest(idBlocagePriseClients);

    //Prepare mocks responses
    BlocageEquipement blocageEquipementMock = new BlocageEquipement(idBlocagePriseClients, "statut", null, null); //$NON-NLS-1$
    ConnectorResponse<Retour, BlocageEquipement> rexResponseLireUn = new ConnectorResponse<Retour, BlocageEquipement>(RetourFactory.createOkRetour(), blocageEquipementMock);

    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexMock).anyTimes();

    EasyMock.expect(_rexMock.blocageEquipementLireUn(__traceability, idBlocagePriseClients)).andReturn(rexResponseLireUn);

    //Execute tests
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startGetProcess(request, __traceability);
    Response actualResponse = (Response) request.getResponse();

    //Checks
    PowerMock.verifyAll();

    PE0533_GetResponse expectedGetResponse = new PE0533_GetResponse(idBlocagePriseClients, new TreeSet<Equipement>(), new TreeSet<String>());
    PE0533_GetResponse actualGetResponse = RavelJsonTools.getInstance().fromJson(actualResponse.getResult(), PE0533_GetResponse.class);
    Assert.assertEquals(ErrorCode.OK_00200, actualResponse.getErrorCode());
    Assert.assertEquals(expectedGetResponse, actualGetResponse);
  }

  /**
   * Retour OK Aucun PM/OLT (null)
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0533_BlocagePriseClients_GET_BL100_OK_002() throws Throwable
  {
    //Prepare request
    String idBlocagePriseClients = __podam.manufacturePojoWithFullData(String.class);
    Request request = prepareGetRequest(idBlocagePriseClients);

    //Prepare data
    //First Tesla Equipement (expected result list actually)
    Set<Equipement> listeEquipementTesla = new TreeSet<>();

    OLT olt = __podam.manufacturePojoWithFullData(OLT.class);
    olt.setNomOLT("OLT1"); //$NON-NLS-1$
    olt.setType(TypeIdentifiant.OLT.name());
    listeEquipementTesla.add(olt);

    PM pm = __podam.manufacturePojoWithFullData(PM.class);
    pm.setType(TypeIdentifiant.PM.name());
    pm.setReferencePmBytel("PM1"); //$NON-NLS-1$
    listeEquipementTesla.add(pm);

    //Then transformed into Saab Equipement (for the mock)
    Set<com.bytel.spirit.common.shared.saab.rex.Equipement> listeEquipementSaab = new TreeSet<>(new EquipementComparator());
    listeEquipementTesla.stream().forEach(teslaEqpt -> listeEquipementSaab.add(teslaEqpt.toSAAB()));

    Set<String> listeOperationVDR = new TreeSet<>();
    listeOperationVDR.add(__podam.manufacturePojoWithFullData(String.class));

    //Prepare mocks responses
    BlocageEquipement blocageEquipementMock = new BlocageEquipement(idBlocagePriseClients, "statut", listeOperationVDR, listeEquipementSaab); //$NON-NLS-1$
    ConnectorResponse<Retour, BlocageEquipement> rexResponseLireUn = new ConnectorResponse<Retour, BlocageEquipement>(RetourFactory.createOkRetour(), blocageEquipementMock);

    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexMock);
    EasyMock.expect(_rexMock.blocageEquipementLireUn(__traceability, idBlocagePriseClients)).andReturn(rexResponseLireUn);

    //Execute tests
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startGetProcess(request, __traceability);
    Response actualResponse = (Response) request.getResponse();

    //Checks
    PowerMock.verifyAll();
    Assert.assertEquals(ErrorCode.OK_00200, actualResponse.getErrorCode());
    Assert.assertNotNull(actualResponse.getResult());

    String expectedJSONGetResponse = RavelJsonTools.getInstance().toJson(new PE0533_GetResponse(idBlocagePriseClients, listeEquipementTesla, listeOperationVDR), PE0533_GetResponse.class);
    Assert.assertEquals(expectedJSONGetResponse, actualResponse.getResult());

  }

  /**
   * Method that does the needed clean up.<br/>
   *
   * <b>Entrées:</b> N/A for this test method. <br/>
   * <b>Attendu:</b> Clean up of some of our data.
   *
   */
  @After
  public void tearDown()
  {
    _processInstance = null;
  }

  /**
   * Add custom headers
   *
   * @param requestId_p
   *          {@link String}
   * @param process_p
   *          {@link String}
   * @param source_p
   *          {@link String}
   * @param messageId_p
   *          {@link String}
   * @param actionId_p
   *          {@link String}
   * @param authorization_p
   *          {@link String}
   * @return {@link List}
   */
  private List<RequestHeader> addXHeaders(String requestId_p, String process_p, String source_p, String messageId_p, String actionId_p, String authorization_p)
  {
    List<RequestHeader> headers = new ArrayList<>();
    RequestHeader hdr = new RequestHeader();

    hdr.setName(IHttpHeadersConsts.CONTENT_TYPE);
    hdr.setValue(HttpConstants.CONTENT_TYPE_JSON);
    headers.add(hdr);

    if (requestId_p != null)
    {
      hdr = new RequestHeader();
      hdr.setName(IHttpHeadersConsts.X_REQUEST_ID);
      hdr.setValue(requestId_p);
      headers.add(hdr);
    }

    if (source_p != null)
    {
      hdr = new RequestHeader();
      hdr.setName(IHttpHeadersConsts.X_SOURCE);
      hdr.setValue(source_p);
      headers.add(hdr);
    }

    if (process_p != null)
    {
      hdr = new RequestHeader();
      hdr.setName(IHttpHeadersConsts.X_PROCESS);
      hdr.setValue(process_p);
      headers.add(hdr);
    }

    if (messageId_p != null)
    {
      hdr = new RequestHeader();
      hdr.setName(IHttpHeadersConsts.X_MESSAGE_ID);
      hdr.setValue(messageId_p);
      headers.add(hdr);
    }

    if (actionId_p != null)
    {
      hdr = new RequestHeader();
      hdr.setName(IHttpHeadersConsts.X_ACTION_ID);
      hdr.setValue(actionId_p);
      headers.add(hdr);
    }

    if (authorization_p != null)
    {
      hdr = new RequestHeader();
      hdr.setName(IHttpHeadersConsts.AUTHORIZATION);
      hdr.setValue(authorization_p);
      headers.add(hdr);
    }

    return headers;

  }

  /**
   * Prepare the Get request for the test
   *
   * @param idBlocagePriseClients_p
   *          the id
   * @return The prepared request
   */
  private Request prepareGetRequest(String idBlocagePriseClients_p)
  {

    Request request = new Request(DEFAULT_PROCESSNAME, "idProcess", "idClient"); //$NON-NLS-1$ //$NON-NLS-2$
    request.setHttpMethod(HttpMethod.GET);
    request.setMsgId(Test_Consts.DEFAULT_MSGID);
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "Basic AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    request.setRequestHeader(headers);

    request.setUrlDynamicParameters(idBlocagePriseClients_p);

    return request;

  }

}