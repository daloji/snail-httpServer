/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.tesla.processes.PI0574;

import static org.junit.Assert.assertEquals;

import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.test.context.ContextConfiguration;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.response.IRavelResponse;
import com.bytel.ravel.common.factory.response.RavelResponseFactory;
import com.bytel.ravel.common.parameter.ParameterManager;
import com.bytel.ravel.common.utils.ACManagerUtil;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.services.utils.Test_Consts;
import com.bytel.spirit.common.activities.shared.BL6000_PublierEvenementFinProv;
import com.bytel.spirit.common.activities.shared.BL6000_PublierEvenementFinProv.BL6000_PublierEvenementFinProvBuilder;
import com.bytel.spirit.common.activities.shared.structs.DemandePublierEvenementFinProv;
import com.bytel.spirit.common.config.Configuration;
import com.bytel.spirit.common.config.Parameter;
import com.bytel.spirit.common.shared.functional.types.json.RavelJsonTools;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.types.parameters.GenericConfigurationFilter;
import com.bytel.spirit.tesla.processes.PI0574.sti.PI0574_EnvoyerModCommClotureRequest;

/**
 *
 * @author hduarte
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@ContextConfiguration("classpath:BeansProcessTestMocks.xml")
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
@PrepareForTest({ PI0574_EnvoyerModCommCloture.class, ParameterManager.class, BL6000_PublierEvenementFinProv.class, BL6000_PublierEvenementFinProvBuilder.class })
public class PI0574_EnvoyerModCommCloture_Test
{

  /**
   * Tracabilite
   */
  private static Tracabilite _tracabilite;

  /**
   * SPRING context
   */
  @SuppressWarnings("unused")
  private static ClassPathXmlApplicationContext __context;

  /**
   * The default process name.
   */
  public static final String DEFAULT_PROCESSNAME = "PI0574_EnvoyerModCommCloture"; //$NON-NLS-1$

  /**
   * Initialization method: Create: - spring context - connectors - service manager.
   *
   * @throws RavelException
   *           the exception
   */
  @BeforeClass
  public static void init() throws RavelException
  {

    ACManagerUtil.resetACManager();
    __context = new ClassPathXmlApplicationContext("classpath:BeansProcessTestMocks.xml"); //$NON-NLS-1$
  }

  /**
   * Instance of {@link PI0574_EnvoyerModCommCloture}
   */
  private PI0574_EnvoyerModCommCloture _processInstance;

  /**
   * BL6000_PublierEvenementFinProv Mock
   */
  @MockStrict
  private BL6000_PublierEvenementFinProv _bl6000Mock;

  /**
   * BL6000_PublierEvenementFinProvBuilder Mock
   */
  @MockStrict
  private BL6000_PublierEvenementFinProvBuilder _bl6000BuilderMock;

  /**
   * Mock de {@link ParameterManager}
   */
  @MockStrict
  private ParameterManager _parameterManager;

  /**
   * NON NOMINAL Tests the PI0574_EnvoyerModCommCloture
   *
   * Parameters are Ok<br>
   * Call continueProcess<br>
   * <b>Expected:</b> Request response : OK_00200 <br>
   * <b>"Retour":"resultat":"OK"<br>
   *
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void PI0574_EnvoyerModCommCloture_KO_ContinueProcess() throws Throwable
  {
    RavelException exception = null;
    Request request = prepareRequest("idCmd", "idExterne", "idModComm", "natureCommande", "statut", "raison_Erreur", "systemeAppelant", "clientOperateur", "noCompte"); //$NON-NLS-1$ //$NON-NLS-2$//$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$

    try
    {
      _processInstance.continueProcess(request, new Tracabilite());
    }
    catch (RavelException e)
    {
      exception = e;
    }

    assertEquals("Unexpected continueProcess for PI0574_EnvoyerModCommCloture at the current state.", exception.getMessage()); //$NON-NLS-1$
    assertEquals(ExceptionType.UNEXPECTED, exception.getExceptionType());
    assertEquals(ErrorCode.PRCESS_00001, exception.getErrorCode());

  }

  /**
   * NON NOMINAL Test - when the unmarshal gives an Exception.
   *
   * <b>Expected:</b> Request response : OK_00200 <br>
   * <b>"Retour":"resultat":"OK"<br>
   *
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void PI0574_EnvoyerModCommCloture_KO_Exception() throws Throwable
  {
    Request request = new Request(DEFAULT_PROCESSNAME, "idProcess", "idClient"); //$NON-NLS-1$ //$NON-NLS-2$
    request.setMsgId(Test_Consts.DEFAULT_MSGID);

    request.setPayload("{/}"); //$NON-NLS-1$

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verify();

    IRavelResponse response = request.getResponse();

    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$

    assertEquals(ErrorCode.OK_00200, response.getErrorCode());

    checkRetour(RetourFactory.createOkRetour(), _processInstance.getRetour());
  }

  /**
   * NON NOMINAL Test - when config parameter is null.
   *
   * <b>Inputs:</b> Request without parameters<br>
   * <b>Expected:</b> Request response : OK_00200 <br>
   * <b>"Retour":"resultat":"OK"<br>
   *
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void PI0574_EnvoyerModCommCloture_KO_Parameter001() throws Throwable
  {
    Parameter notif_SystemeAppelant_TTL = new Parameter();
    notif_SystemeAppelant_TTL.setKey("notif_SystemeAppelant_TTL"); //$NON-NLS-1$
    notif_SystemeAppelant_TTL.setValue(null);

    Configuration configuration = new Configuration();
    configuration.withParameter(notif_SystemeAppelant_TTL);

    EasyMock.expect(ParameterManager.getInstance()).andReturn(_parameterManager);
    EasyMock.expect(_parameterManager.findOne(EasyMock.eq("configEvenementFinProv"), EasyMock.anyObject(GenericConfigurationFilter.class))).andReturn(configuration); //$NON-NLS-1$

    Request request = prepareRequest("idCmd", "idExterne", "idModComm", "natureCommande", "TRAITE", "raison_Erreur", "systemeAppelant", "clientOperateur", "noCompte"); //$NON-NLS-1$ //$NON-NLS-2$//$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verify();

    IRavelResponse response = request.getResponse();

    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$

    assertEquals(ErrorCode.OK_00200, response.getErrorCode());

    checkRetour(RetourFactory.createOkRetour(), _processInstance.getRetour());
  }

  /**
   * NON NOMINAL Test - when request is invalid idCmd null or empty.
   *
   * <b>Inputs:</b> Request with invalid parameters<br>
   * <b>Expected:</b> Request response : OK_00200 <br>
   * <b>"Retour":"resultat":"OK"<br>
   *
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void PI0574_EnvoyerModCommCloture_KO_Parameter002() throws Throwable
  {
    mockParameterManager();

    Request request = prepareRequest("", "idExterne", "idModComm", "natureCommande", "TRAITE", "raison_Erreur", "systemeAppelant", "clientOperateur", "noCompte"); //$NON-NLS-1$ //$NON-NLS-2$//$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verify();

    IRavelResponse response = request.getResponse();

    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$

    assertEquals(ErrorCode.OK_00200, response.getErrorCode());

    checkRetour(RetourFactory.createOkRetour(), _processInstance.getRetour());
  }

  /**
   * NON NOMINAL Test - when request is invalid idExterne null or empty.
   *
   * <b>Inputs:</b> Request with invalid parameters<br>
   * <b>Expected:</b> Request response : OK_00200 <br>
   * <b>"Retour":"resultat":"OK"<br>
   *
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void PI0574_EnvoyerModCommCloture_KO_Parameter003() throws Throwable
  {
    mockParameterManager();

    Request request = prepareRequest("idCmd", "", "idModComm", "natureCommande", "TRAITE", "raison_Erreur", "systemeAppelant", "clientOperateur", "noCompte"); //$NON-NLS-1$ //$NON-NLS-2$//$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verify();

    IRavelResponse response = request.getResponse();

    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$

    assertEquals(ErrorCode.OK_00200, response.getErrorCode());

    checkRetour(RetourFactory.createOkRetour(), _processInstance.getRetour());
  }

  /**
   * NON NOMINAL Test - when request is invalid idModComm null or empty.
   *
   * <b>Inputs:</b> Request with invalid parameters<br>
   * <b>Expected:</b> Request response : OK_00200 <br>
   * <b>"Retour":"resultat":"OK"<br>
   *
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void PI0574_EnvoyerModCommCloture_KO_Parameter004() throws Throwable
  {
    mockParameterManager();

    Request request = prepareRequest("idCmd", "idExterne", "", "natureCommande", "TRAITE", "raison_Erreur", "systemeAppelant", "clientOperateur", "noCompte"); //$NON-NLS-1$ //$NON-NLS-2$//$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verify();

    IRavelResponse response = request.getResponse();

    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$

    assertEquals(ErrorCode.OK_00200, response.getErrorCode());

    checkRetour(RetourFactory.createOkRetour(), _processInstance.getRetour());
  }

  /**
   * NON NOMINAL Test - when request is invalid natureCommande null or empty.
   *
   * <b>Inputs:</b> Request with invalid parameters<br>
   * <b>Expected:</b> Request response : OK_00200 <br>
   * <b>"Retour":"resultat":"OK"<br>
   *
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void PI0574_EnvoyerModCommCloture_KO_Parameter005() throws Throwable
  {
    mockParameterManager();

    Request request = prepareRequest("idCmd", "idExterne", "idModComm", "", "TRAITE", "raison_Erreur", "systemeAppelant", "clientOperateur", "noCompte"); //$NON-NLS-1$ //$NON-NLS-2$//$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verify();

    IRavelResponse response = request.getResponse();

    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$

    assertEquals(ErrorCode.OK_00200, response.getErrorCode());

    checkRetour(RetourFactory.createOkRetour(), _processInstance.getRetour());
  }

  /**
   * NON NOMINAL Test - when request is invalid statut null or empty.
   *
   * <b>Inputs:</b> Request with invalid parameters<br>
   * <b>Expected:</b> Request response : OK_00200 <br>
   * <b>"Retour":"resultat":"OK"<br>
   *
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void PI0574_EnvoyerModCommCloture_KO_Parameter006() throws Throwable
  {
    mockParameterManager();

    Request request = prepareRequest("idCmd", "idExterne", "idModComm", "natureCommande", "", "raison_Erreur", "systemeAppelant", "clientOperateur", "noCompte"); //$NON-NLS-1$ //$NON-NLS-2$//$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verify();

    IRavelResponse response = request.getResponse();

    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$

    assertEquals(ErrorCode.OK_00200, response.getErrorCode());

    checkRetour(RetourFactory.createOkRetour(), _processInstance.getRetour());
  }

  /**
   * NON NOMINAL Test - when request is invalid systemeAppelant null or empty.
   *
   * <b>Inputs:</b> Request with invalid parameters<br>
   * <b>Expected:</b> Request response : OK_00200 <br>
   * <b>"Retour":"resultat":"OK"<br>
   *
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void PI0574_EnvoyerModCommCloture_KO_Parameter008() throws Throwable
  {
    mockParameterManager();

    Request request = prepareRequest("idCmd", "idExterne", "idModComm", "natureCommande", "TRAITE", "raison_Erreur", "", "clientOperateur", "noCompte"); //$NON-NLS-1$ //$NON-NLS-2$//$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verify();

    IRavelResponse response = request.getResponse();

    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$

    assertEquals(ErrorCode.OK_00200, response.getErrorCode());

    checkRetour(RetourFactory.createOkRetour(), _processInstance.getRetour());
  }

  /**
   * NON NOMINAL Test - when request is invalid clientOperateur null or empty.
   *
   * <b>Inputs:</b> Request with invalid parameters<br>
   * <b>Expected:</b> Request response : OK_00200 <br>
   * <b>"Retour":"resultat":"OK"<br>
   *
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void PI0574_EnvoyerModCommCloture_KO_Parameter009() throws Throwable
  {
    mockParameterManager();

    Request request = prepareRequest("idCmd", "idExterne", "idModComm", "natureCommande", "TRAITE", "raison_Erreur", "systemeAppelant", "", "noCompte"); //$NON-NLS-1$ //$NON-NLS-2$//$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verify();

    IRavelResponse response = request.getResponse();

    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$

    assertEquals(ErrorCode.OK_00200, response.getErrorCode());

    checkRetour(RetourFactory.createOkRetour(), _processInstance.getRetour());
  }

  /**
   * NON NOMINAL Test - when request is invalid noCompte null or empty.
   *
   * <b>Inputs:</b> Request with invalid parameters<br>
   * <b>Expected:</b> Request response : OK_00200 <br>
   * <b>"Retour":"resultat":"OK"<br>
   *
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void PI0574_EnvoyerModCommCloture_KO_Parameter010() throws Throwable
  {
    mockParameterManager();

    Request request = prepareRequest("idCmd", "idExterne", "idModComm", "natureCommande", "TRAITE", "raison_Erreur", "systemeAppelant", "clientOperateur", ""); //$NON-NLS-1$ //$NON-NLS-2$//$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verify();

    IRavelResponse response = request.getResponse();

    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$

    assertEquals(ErrorCode.OK_00200, response.getErrorCode());

    checkRetour(RetourFactory.createOkRetour(), _processInstance.getRetour());
  }

  /**
   * NON NOMINAL Test - when request is invalid statut != TRAITE.
   *
   * <b>Inputs:</b> Request with invalid parameters<br>
   * <b>Expected:</b> Request response : OK_00200 <br>
   * <b>"Retour":"resultat":"OK"<br>
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void PI0574_EnvoyerModCommCloture_KO_Parameter011() throws Throwable
  {
    mockParameterManager();

    Request request = prepareRequest("idCmd", "idExterne", "idModComm", "natureCommande", "statut", "raison_Erreur", "systemeAppelant", "clientOperateur", "noCompte"); //$NON-NLS-1$ //$NON-NLS-2$//$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verify();

    IRavelResponse response = request.getResponse();

    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$

    assertEquals(ErrorCode.OK_00200, response.getErrorCode());

    checkRetour(RetourFactory.createOkRetour(), _processInstance.getRetour());
  }

  /**
   * NON NOMINAL Test - BL6000 returns KO.
   *
   * <b>Inputs:</b> Request with OK parameters<br>
   * <b>Expected:</b> Request response : OK_00200 <br>
   * <b>"Retour":"resultat":"OK"<br>
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void PI0574_EnvoyerModCommCloture_KO_Parameter012() throws Throwable
  {

    mockParameterManager();
    Request request = prepareRequest("idCmd", "idExterne", "idModComm", "natureCommande", "TRAITE", "raison_Erreur", "systemeAppelant", "clientOperateur", "noCompte"); //$NON-NLS-1$ //$NON-NLS-2$//$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$

    PowerMock.expectNew(BL6000_PublierEvenementFinProv.BL6000_PublierEvenementFinProvBuilder.class).andReturn(_bl6000BuilderMock);
    EasyMock.expect(_bl6000BuilderMock.tracabilite(_tracabilite)).andReturn(_bl6000BuilderMock);
    EasyMock.expect(_bl6000BuilderMock.demandePublierEvenementFinProv(EasyMock.anyObject(DemandePublierEvenementFinProv.class))).andReturn(_bl6000BuilderMock);
    EasyMock.expect(_bl6000BuilderMock.configuration(EasyMock.anyString())).andReturn(_bl6000BuilderMock);
    EasyMock.expect(_bl6000BuilderMock.build()).andReturn(_bl6000Mock);
    EasyMock.expect(_bl6000Mock.execute(_processInstance)).andReturn(null);
    EasyMock.expect(_bl6000Mock.getRetour()).andReturn(RetourFactory.createKO("CAT-4", "DONNEE_INCONNUE", "Error in BL6000")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verify();

    IRavelResponse response = request.getResponse();

    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$

    assertEquals(ErrorCode.OK_00200, response.getErrorCode());

    checkRetour(RetourFactory.createOkRetour(), _processInstance.getRetour());
  }

  /**
   * NOMINAL Test .
   *
   * <b>Inputs:</b> Request with OK parameters<br>
   * <b>Expected:</b> Request response : OK_00200 <br>
   * <b>"Retour":"resultat":"OK"<br>
   *
   *
   *
   * @throws Throwable
   *           on unexpected error
   */
  @Test
  public void PI0574_EnvoyerModCommCloture_KO_Parameter013() throws Throwable
  {
    mockParameterManager();

    Request request = prepareRequest("idCmd", "idExterne", "idModComm", "natureCommande", "TRAITE", "raison_Erreur", "systemeAppelant", "clientOperateur", "noCompte"); //$NON-NLS-1$ //$NON-NLS-2$//$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$

    PowerMock.expectNew(BL6000_PublierEvenementFinProv.BL6000_PublierEvenementFinProvBuilder.class).andReturn(_bl6000BuilderMock);
    EasyMock.expect(_bl6000BuilderMock.tracabilite(_tracabilite)).andReturn(_bl6000BuilderMock);
    EasyMock.expect(_bl6000BuilderMock.demandePublierEvenementFinProv(EasyMock.anyObject(DemandePublierEvenementFinProv.class))).andReturn(_bl6000BuilderMock);
    EasyMock.expect(_bl6000BuilderMock.configuration(EasyMock.anyString())).andReturn(_bl6000BuilderMock);
    EasyMock.expect(_bl6000BuilderMock.build()).andReturn(_bl6000Mock);
    EasyMock.expect(_bl6000Mock.execute(_processInstance)).andReturn(null);
    EasyMock.expect(_bl6000Mock.getRetour()).andReturn(RetourFactory.createOkRetour());

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verify();

    IRavelResponse response = request.getResponse();

    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$

    assertEquals(ErrorCode.OK_00200, response.getErrorCode());

    checkRetour(RetourFactory.createOkRetour(), _processInstance.getRetour());
  }

  /**
   * Sets the test
   *
   */
  @Before
  public void setUp()
  {
    _processInstance = new PI0574_EnvoyerModCommCloture();
    _processInstance.initializeContext();

    _tracabilite = new Tracabilite();
    _tracabilite.setIdCorrelationByTel(StringConstants.EMPTY_STRING);
    _tracabilite.setIdProcessusSpirit(_processInstance.getIdProcess());
    _tracabilite.setIdCorrelationSpirit(Test_Consts.DEFAULT_MSGID);
    _tracabilite.setNomProcessus(StringConstants.EMPTY_STRING);
    _tracabilite.setNomSysteme(System.getenv("SERVICE")); //$NON-NLS-1$

    PowerMock.resetAll();
    PowerMock.mockStaticStrict(ParameterManager.class);
    PowerMock.mockStaticStrict(BL6000_PublierEvenementFinProv.class);
    PowerMock.mockStaticStrict(BL6000_PublierEvenementFinProvBuilder.class);
  }

  /**
   * Method to check retours
   *
   * @param retourExpected_p
   *          retourExpected
   * @param retourActual_p
   *          retourActual
   * @throws Exception
   *           on error
   */
  private void checkRetour(Retour retourExpected_p, Retour retourActual_p) throws Exception
  {
    assertEquals(retourExpected_p.getResultat(), retourActual_p.getResultat());
    assertEquals(retourExpected_p.getCategorie(), retourActual_p.getCategorie());
    assertEquals(retourExpected_p.getDiagnostic(), retourActual_p.getDiagnostic());
    assertEquals(retourExpected_p.getLibelle(), retourActual_p.getLibelle());
  }

  /**
   * createParamManager
   *
   */
  private void mockParameterManager()
  {
    Parameter notif_SystemeAppelant_TTL = new Parameter();
    notif_SystemeAppelant_TTL.setKey("notif_SystemeAppelant_TTL"); //$NON-NLS-1$
    notif_SystemeAppelant_TTL.setValue("259200"); //$NON-NLS-1$

    Configuration configuration = new Configuration();
    configuration.withParameter(notif_SystemeAppelant_TTL);

    EasyMock.expect(ParameterManager.getInstance()).andReturn(_parameterManager);
    EasyMock.expect(_parameterManager.findOne(EasyMock.eq("configEvenementFinProv"), EasyMock.anyObject(GenericConfigurationFilter.class))).andReturn(configuration); //$NON-NLS-1$
  }

  /**
   * Create a Generic Request to call PI0574_EnvoyerModCommCloture
   *
   * @param idCmd_p
   *          idCmd
   * @param idExterne_p
   *          idExterne
   * @param idModComm_p
   *          idModComm
   * @param natureCommande_p
   *          natureCommande
   * @param statut_p
   *          statut
   * @param raisonErreur_p
   *          raisonErreur
   * @param systemeAppelant_p
   *          systemeAppelant
   * @param clientOperateur_p
   *          clientOperateur
   * @param noCompte_p
   *          noCompte
   *
   * @return GenericRequest to call PI0574_EnvoyerModCommCloture
   * @throws RavelException
   *           on error
   */
  private Request prepareRequest(String idCmd_p, String idExterne_p, String idModComm_p, String natureCommande_p, String statut_p, String raisonErreur_p, String systemeAppelant_p, String clientOperateur_p, String noCompte_p) throws RavelException
  {
    Request request = new Request(DEFAULT_PROCESSNAME, "idProcess", "idClient"); //$NON-NLS-1$ //$NON-NLS-2$
    request.setMsgId(Test_Consts.DEFAULT_MSGID);

    PI0574_EnvoyerModCommClotureRequest envoyerModCommCloture = new PI0574_EnvoyerModCommClotureRequest(idCmd_p, idExterne_p, idModComm_p, natureCommande_p, statut_p, raisonErreur_p, systemeAppelant_p, clientOperateur_p, noCompte_p);

    //Body parameter
    String payload = RavelJsonTools.getInstance().toJson(envoyerModCommCloture, PI0574_EnvoyerModCommClotureRequest.class);
    request.setPayload(payload);

    return request;
  }
}
