/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.tesla.processes.PE0575;

import org.easymock.EasyMock;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.test.context.ContextConfiguration;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.datetime.DateTimeManager;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.utils.ACManagerUtil;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.connector.ftp.FTPProxy;
import com.bytel.ravel.services.process.ProcessManager;
import com.bytel.ravel.services.utils.Test_Consts;
import com.bytel.spirit.common.activities.sega.SEGA_SI148_NotifierDemandePROV;
import com.bytel.spirit.common.activities.sega.SEGA_SI148_NotifierDemandePROV.SEGA_SI148_NotifierDemandePROVBuilder;
import com.bytel.spirit.common.shared.functional.types.json.RavelJsonTools;
import com.bytel.spirit.common.shared.misc.error.ReponseErreur;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.tesla.processes.PI0344.PI0344_RecupererDetailProvisioningPON;
import com.bytel.spirit.tesla.processes.PE0575.structs.EvenementFinProv;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author jiantila
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@ContextConfiguration("classpath:BeansProcessTestMocks.xml")
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
@PrepareForTest({ PE0575_ConsulterEvenement.class, SEGA_SI148_NotifierDemandePROV.class })
public class PE0575_ConsulterEvenementTest
{

  /**
   * The default process name.
   */
  public static final String DEFAULT_PROCESSNAME = PE0575_ConsulterEvenement.class.getSimpleName(); //$NON-NLS-1$

  /**
   * Factory de génération des beans
   */
  private static PodamFactory __podam = new PodamFactoryImpl();

  /**
   * SPRING context
   */
  @SuppressWarnings("unused")
  private static ClassPathXmlApplicationContext __context;

  /**
   *
   */
  static Tracabilite _tracabilite;

  /**
   * Initialization method: Create: - spring context - connectors - service manager.
   *
   * @throws RavelException
   *           the exception
   */
  @BeforeClass
  public static void init() throws RavelException
  {
    // désactivation du cache podam
    __podam.getStrategy().setMemoization(false);
    __podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());
    _tracabilite = new Tracabilite();
    _tracabilite.setIdCorrelationByTel(StringConstants.EMPTY_STRING);
    _tracabilite.setIdProcessusSpirit("tIdProcess");
    _tracabilite.setIdCorrelationSpirit(Test_Consts.DEFAULT_MSGID);
    _tracabilite.setNomProcessus(StringConstants.EMPTY_STRING);
    _tracabilite.setNomSysteme(System.getenv("SERVICE")); //$NON-NLS-1$
    ACManagerUtil.resetACManager();
    __context = new ClassPathXmlApplicationContext("classpath:BeansProcessTestMocks.xml"); //$NON-NLS-1$
  }

  /**
   * Mock de {@link FTPProxy}
   */
  @MockStrict
  private SEGA_SI148_NotifierDemandePROVBuilder _segaSI148_NotifierDemandePROVBuilderMock;

  /**
   * Mock de {@link FTPProxy}
   */
  @MockStrict
  private SEGA_SI148_NotifierDemandePROV _segaSI148_NotifierDemandePROVMock;

  /**
   * Instance of {@link PE0575_ConsulterEvenement}
   */
  private PE0575_ConsulterEvenement _processInstance;

  /**
   * verification BL001_GET_VerifierDonnees idcmd null
   *
   * @throws Throwable
   */
  @Test
  public void PE0575_BL001_GET_VerifierDonnees_KO_001() throws Throwable
  {
    EvenementFinProv evenementFin = new EvenementFinProv();
    Request request = prepareRequest(evenementFin);
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verify();

    Response response = (Response) request.getResponse();
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponse = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);
    Assert.assertEquals(response.getErrorCode(), ErrorCode.KO_00404);
    Assert.assertEquals(reponse.getError(), IMegSpiritConsts.NON_RESPECT_STI);
    Assert.assertEquals(reponse.getErrorDescription(), "Paramètre [idCmd] null ou vide dans la requête."); //$NON-NLS-1$

  }

  /**
   * verification BL001_GET_VerifierDonnees statut non autorise
   *
   * @throws Throwable
   */
  @Test
  public void PE0575_BL001_GET_VerifierDonnees_KO_0010() throws Throwable
  {
    EvenementFinProv evenementFin = new EvenementFinProv();
    evenementFin.setIdCmd("idcmd"); //$NON-NLS-1$
    evenementFin.setIdExterne("idExterne"); //$NON-NLS-1$
    evenementFin.setDateTraitement(DateTimeManager.getInstance().now());
    evenementFin.setNatureCommande("CREATION_PFI"); //$NON-NLS-1$
    evenementFin.setStatut("TRAITE_NOK"); //$NON-NLS-1$
    Request request = prepareRequest(evenementFin);
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verify();

    Response response = (Response) request.getResponse();
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponse = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);
    Assert.assertEquals(response.getErrorCode(), ErrorCode.KO_00404);
    Assert.assertEquals(reponse.getError(), IMegSpiritConsts.NON_RESPECT_STI);
    Assert.assertEquals(reponse.getErrorDescription(), "le champ raisonErreur est obligatoire si statut TRAITE_NOK."); //$NON-NLS-1$

  }

  /**
   * verification BL001_GET_VerifierDonnees idExterne null
   *
   * @throws Throwable
   */
  @Test
  public void PE0575_BL001_GET_VerifierDonnees_KO_002() throws Throwable
  {
    EvenementFinProv evenementFin = new EvenementFinProv();
    evenementFin.setIdCmd("idcmd"); //$NON-NLS-1$
    Request request = prepareRequest(evenementFin);
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verify();

    Response response = (Response) request.getResponse();
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponse = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);
    Assert.assertEquals(response.getErrorCode(), ErrorCode.KO_00404);
    Assert.assertEquals(reponse.getError(), IMegSpiritConsts.NON_RESPECT_STI);
    Assert.assertEquals(reponse.getErrorDescription(), "Paramètre [idExterne] null ou vide dans la requête."); //$NON-NLS-1$

  }

  /**
   * verification BL001_GET_VerifierDonnees dateTraitement null
   *
   * @throws Throwable
   */
  @Test
  public void PE0575_BL001_GET_VerifierDonnees_KO_003() throws Throwable
  {
    EvenementFinProv evenementFin = new EvenementFinProv();
    evenementFin.setIdCmd("idcmd"); //$NON-NLS-1$
    evenementFin.setIdExterne("idExterne"); //$NON-NLS-1$
    Request request = prepareRequest(evenementFin);
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verify();

    Response response = (Response) request.getResponse();
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponse = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);
    Assert.assertEquals(response.getErrorCode(), ErrorCode.KO_00404);
    Assert.assertEquals(reponse.getError(), IMegSpiritConsts.NON_RESPECT_STI);
    Assert.assertEquals(reponse.getErrorDescription(), "Paramètre [dateTraitement] null ou vide dans la requête."); //$NON-NLS-1$

  }

  /**
   * verification BL001_GET_VerifierDonnees natureCommande null
   *
   * @throws Throwable
   */
  @Test
  public void PE0575_BL001_GET_VerifierDonnees_KO_005() throws Throwable
  {
    EvenementFinProv evenementFin = new EvenementFinProv();
    evenementFin.setIdCmd("idcmd"); //$NON-NLS-1$
    evenementFin.setIdExterne("idExterne"); //$NON-NLS-1$
    evenementFin.setDateTraitement(DateTimeManager.getInstance().now());
    Request request = prepareRequest(evenementFin);
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verify();

    Response response = (Response) request.getResponse();
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponse = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);
    Assert.assertEquals(response.getErrorCode(), ErrorCode.KO_00404);
    Assert.assertEquals(reponse.getError(), IMegSpiritConsts.NON_RESPECT_STI);
    Assert.assertEquals(reponse.getErrorDescription(), "Paramètre [natureCommande] null ou vide dans la requête."); //$NON-NLS-1$

  }

  /**
   * verification BL001_GET_VerifierDonnees natureCommande non autorisé
   *
   * @throws Throwable
   */
  @Test
  public void PE0575_BL001_GET_VerifierDonnees_KO_006() throws Throwable
  {
    EvenementFinProv evenementFin = new EvenementFinProv();
    evenementFin.setIdCmd("idcmd"); //$NON-NLS-1$
    evenementFin.setIdExterne("idExterne"); //$NON-NLS-1$
    evenementFin.setDateTraitement(DateTimeManager.getInstance().now());
    evenementFin.setNatureCommande("natureCommande"); //$NON-NLS-1$
    Request request = prepareRequest(evenementFin);
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verify();

    Response response = (Response) request.getResponse();
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponse = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);
    Assert.assertEquals(response.getErrorCode(), ErrorCode.KO_00404);
    Assert.assertEquals(reponse.getError(), IMegSpiritConsts.NON_RESPECT_STI);
    Assert.assertEquals(reponse.getErrorDescription(), "natureCommande doit être CREATION_PFI ou MODIFICATION_PFI ou SUPPRESSION_PFI."); //$NON-NLS-1$

  }

  /**
   * verification BL001_GET_VerifierDonnees statut null
   *
   * @throws Throwable
   */
  @Test
  public void PE0575_BL001_GET_VerifierDonnees_KO_007() throws Throwable
  {
    EvenementFinProv evenementFin = new EvenementFinProv();
    evenementFin.setIdCmd("idcmd"); //$NON-NLS-1$
    evenementFin.setIdExterne("idExterne"); //$NON-NLS-1$
    evenementFin.setDateTraitement(DateTimeManager.getInstance().now());
    evenementFin.setNatureCommande("CREATION_PFI"); //$NON-NLS-1$
    Request request = prepareRequest(evenementFin);
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verify();

    Response response = (Response) request.getResponse();
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponse = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);
    Assert.assertEquals(response.getErrorCode(), ErrorCode.KO_00404);
    Assert.assertEquals(reponse.getError(), IMegSpiritConsts.NON_RESPECT_STI);
    Assert.assertEquals(reponse.getErrorDescription(), "Paramètre [statut] null ou vide dans la requête."); //$NON-NLS-1$

  }

  /**
   * verification BL001_GET_VerifierDonnees statut non autorise
   *
   * @throws Throwable
   */
  @Test
  public void PE0575_BL001_GET_VerifierDonnees_KO_008() throws Throwable
  {
    EvenementFinProv evenementFin = new EvenementFinProv();
    evenementFin.setIdCmd("idcmd"); //$NON-NLS-1$
    evenementFin.setIdExterne("idExterne"); //$NON-NLS-1$
    evenementFin.setDateTraitement(DateTimeManager.getInstance().now());
    evenementFin.setNatureCommande("CREATION_PFI"); //$NON-NLS-1$
    evenementFin.setStatut("statut"); //$NON-NLS-1$
    Request request = prepareRequest(evenementFin);
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verify();

    Response response = (Response) request.getResponse();
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponse = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);
    Assert.assertEquals(response.getErrorCode(), ErrorCode.KO_00404);
    Assert.assertEquals(reponse.getError(), IMegSpiritConsts.NON_RESPECT_STI);
    Assert.assertEquals(reponse.getErrorDescription(), "statut doit être TRAITE_OK ou TRAITE_NOK ou OBSOLETE."); //$NON-NLS-1$

  }

  /**
   * verification BL001_GET_VerifierDonnees raisonErreur null
   *
   * @throws Throwable
   */
  @Test
  public void PE0575_BL001_GET_VerifierDonnees_KO_009() throws Throwable
  {
    EvenementFinProv evenementFin = new EvenementFinProv();
    evenementFin.setIdCmd("idcmd"); //$NON-NLS-1$
    evenementFin.setIdExterne("idExterne"); //$NON-NLS-1$
    evenementFin.setDateTraitement(DateTimeManager.getInstance().now());
    evenementFin.setNatureCommande("CREATION_PFI"); //$NON-NLS-1$
    evenementFin.setStatut("TRAITE_NOK"); //$NON-NLS-1$
    Request request = prepareRequest(evenementFin);
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verify();

    Response response = (Response) request.getResponse();
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponse = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);
    Assert.assertEquals(response.getErrorCode(), ErrorCode.KO_00404);
    Assert.assertEquals(reponse.getError(), IMegSpiritConsts.NON_RESPECT_STI);
    Assert.assertEquals(reponse.getErrorDescription(), "le champ raisonErreur est obligatoire si statut TRAITE_NOK."); //$NON-NLS-1$

  }

  /**
   * verification BL001_GET_VerifierDonnees raisonErreur null
   *
   * @throws Throwable
   */
  @Test
  public void PE0575_BL001_GET_VerifierDonnees_KO_010() throws Throwable
  {
    EvenementFinProv evenementFin = new EvenementFinProv();
    evenementFin.setIdCmd("idcmd"); //$NON-NLS-1$
    evenementFin.setIdExterne("idExterne"); //$NON-NLS-1$
    evenementFin.setDateTraitement(DateTimeManager.getInstance().now());
    evenementFin.setNatureCommande("CREATION_PFI"); //$NON-NLS-1$
    evenementFin.setStatut("TRAITE_OK"); //$NON-NLS-1$
    evenementFin.setRaisonErreur("raisonErreur_p"); //$NON-NLS-1$
    Request request = prepareRequest(evenementFin);
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verify();

    Response response = (Response) request.getResponse();
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponse = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);
    Assert.assertEquals(response.getErrorCode(), ErrorCode.KO_00404);
    Assert.assertEquals(reponse.getError(), IMegSpiritConsts.NON_RESPECT_STI);
    Assert.assertEquals(reponse.getErrorDescription(), "le champ raisonErreur doit être vide car le statut est TRAITE_OK ou OBSOLETE"); //$NON-NLS-1$

  }

  /**
   * verification BL100_RecupererNotification sega /ko/DONNEE_INCONNUE
   *
   * @throws Throwable
   */
  @Test
  public void PE0575_BL100_RecupererNotification_KO_001() throws Throwable
  {
    EvenementFinProv evenementFin = new EvenementFinProv();
    evenementFin.setIdCmd("idcmd"); //$NON-NLS-1$
    evenementFin.setIdExterne("idExterne"); //$NON-NLS-1$
    evenementFin.setDateTraitement(DateTimeManager.getInstance().now());
    evenementFin.setNatureCommande("CREATION_PFI"); //$NON-NLS-1$
    evenementFin.setStatut("TRAITE_OK"); //$NON-NLS-1$
    Retour retour = RetourFactory.createKO(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "erreur");
    Request request = prepareRequest(evenementFin);
    mockSEGA(evenementFin, retour);
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verify();

    Response response = (Response) request.getResponse();
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponse = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);
    Assert.assertEquals(response.getErrorCode(), ErrorCode.KO_00404);
    Assert.assertEquals(reponse.getError(), IMegConsts.DONNEE_INCONNUE);
    Assert.assertEquals(reponse.getErrorDescription(), "erreur"); //$NON-NLS-1$

  }

  /**
   * verification BL100_RecupererNotification sega /ko/DONNEE_INCONNUE
   *
   * @throws Throwable
   */
  @Test
  public void PE0575_BL100_RecupererNotification_KO_002() throws Throwable
  {
    EvenementFinProv evenementFin = new EvenementFinProv();
    evenementFin.setIdCmd("idcmd"); //$NON-NLS-1$
    evenementFin.setIdExterne("idExterne"); //$NON-NLS-1$
    evenementFin.setDateTraitement(DateTimeManager.getInstance().now());
    evenementFin.setNatureCommande("CREATION_PFI"); //$NON-NLS-1$
    evenementFin.setStatut("TRAITE_OK"); //$NON-NLS-1$
    Retour retour = RetourFactory.createKO(IMegConsts.CAT4, IMegConsts.MISE_A_JOUR_INDISPONIBLE, "libelle");
    Request request = prepareRequest(evenementFin);
    mockSEGA(evenementFin, retour);
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verify();

    Response response = (Response) request.getResponse();
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponse = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);
    Assert.assertEquals(response.getErrorCode(), ErrorCode.KO_00500);
    Assert.assertEquals(reponse.getError(), IMegConsts.MISE_A_JOUR_INDISPONIBLE);
    Assert.assertEquals(reponse.getErrorDescription(), "libelle"); //$NON-NLS-1$

  }

  /**
   * verification BL100_RecupererNotification sega /ko/DONNEE_INCONNUE
   *
   * @throws Throwable
   */
  @Test
  public void PE0575_BL100_RecupererNotification_KO_003() throws Throwable
  {
    EvenementFinProv evenementFin = new EvenementFinProv();
    evenementFin.setIdCmd("idcmd"); //$NON-NLS-1$
    evenementFin.setIdExterne("idExterne"); //$NON-NLS-1$
    evenementFin.setDateTraitement(DateTimeManager.getInstance().now());
    evenementFin.setNatureCommande("CREATION_PFI"); //$NON-NLS-1$
    evenementFin.setStatut("TRAITE_OK"); //$NON-NLS-1$
    Retour retour = RetourFactory.createKO(IMegConsts.CAT4, "INDISPONIBILITE_SESSION", "libelle");
    Request request = prepareRequest(evenementFin);
    mockSEGA(evenementFin, retour);
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verify();

    Response response = (Response) request.getResponse();
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponse = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);
    Assert.assertEquals(response.getErrorCode(), ErrorCode.KO_00500);
    Assert.assertEquals(reponse.getError(), "INDISPONIBILITE_SESSION");
    Assert.assertEquals(reponse.getErrorDescription(), "libelle"); //$NON-NLS-1$

  }

  /**
   * verification BL100_RecupererNotification sega /ko/DONNEE_INCONNUE
   *
   * @throws Throwable
   */
  @Test
  public void PE0575_nominal_OK() throws Throwable
  {
    EvenementFinProv evenementFin = new EvenementFinProv();
    evenementFin.setIdCmd("idcmd"); //$NON-NLS-1$
    evenementFin.setIdExterne("idExterne"); //$NON-NLS-1$
    evenementFin.setDateTraitement(DateTimeManager.getInstance().now());
    evenementFin.setNatureCommande("CREATION_PFI"); //$NON-NLS-1$
    evenementFin.setStatut("TRAITE_OK"); //$NON-NLS-1$
    Retour retourExpected = RetourFactory.createOkRetour();
    Request request = prepareRequest(evenementFin);
    mockSEGA(evenementFin, retourExpected);
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verify();

    Response response = (Response) request.getResponse();
    String resp = response.getGenericResponse().getResult();
    Retour retour = RavelJsonTools.getInstance().fromJson(resp, Retour.class);
    Assert.assertEquals(response.getErrorCode(), ErrorCode.OK_00200);
    Assert.assertEquals(retourExpected.getResultat(), retour.getResultat());

  }

  /**
   * Sets the test
   *
   */
  @Before
  public void setUp()
  {
    _processInstance = new PE0575_ConsulterEvenement();
    _processInstance.initializeContext();

    ProcessManager.getInstance().getProcessParams().clear();

    // on réinitialise tous les mocks afin de ne pas avoir d'interférence entre les tests
    PowerMock.resetAll();
    PowerMock.mockStaticStrict(SEGA_SI148_NotifierDemandePROV.class);
    PowerMock.mockStaticStrict(SEGA_SI148_NotifierDemandePROVBuilder.class);

  }

  /**
   * @param eventProv
   * @param retour
   * @throws Exception
   */
  private void mockSEGA(EvenementFinProv eventProv, Retour retour) throws Exception
  {
    PowerMock.expectNew(SEGA_SI148_NotifierDemandePROVBuilder.class).andReturn(_segaSI148_NotifierDemandePROVBuilderMock);
    EasyMock.expect(_segaSI148_NotifierDemandePROVBuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_segaSI148_NotifierDemandePROVBuilderMock);
    EasyMock.expect(_segaSI148_NotifierDemandePROVBuilderMock.commandeId(eventProv.getIdCmd())).andReturn(_segaSI148_NotifierDemandePROVBuilderMock);
    EasyMock.expect(_segaSI148_NotifierDemandePROVBuilderMock.statut(EasyMock.eq("OK"))).andReturn(_segaSI148_NotifierDemandePROVBuilderMock);
    EasyMock.expect(_segaSI148_NotifierDemandePROVBuilderMock.raisonErreur(null)).andReturn(_segaSI148_NotifierDemandePROVBuilderMock);
    EasyMock.expect(_segaSI148_NotifierDemandePROVBuilderMock.build()).andReturn(_segaSI148_NotifierDemandePROVMock);
    EasyMock.expect(_segaSI148_NotifierDemandePROVMock.execute(EasyMock.anyObject(PE0575_ConsulterEvenement.class))).andReturn(null);
    EasyMock.expect(_segaSI148_NotifierDemandePROVMock.getRetour()).andReturn(retour);
  }

  /**
   * @param evenementFinProv
   * @return
   * @throws RavelException
   */
  private Request prepareRequest(EvenementFinProv evenementFinProv) throws RavelException
  {
    Request request = new Request(DEFAULT_PROCESSNAME, "idProcess", "idClient"); //$NON-NLS-1$ //$NON-NLS-2$
    request.setMsgId(Test_Consts.DEFAULT_MSGID);

    //Body parameter
    String payload = RavelJsonTools.getInstance().toJson(evenementFinProv, EvenementFinProv.class);
    request.setPayload(payload);

    return request;
  }
}
