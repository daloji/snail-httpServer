/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.tesla.processes.PE0529;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.ws.rs.HttpMethod;
import javax.ws.rs.core.MediaType;

import com.bytel.ravel.common.datetime.DateTimeManager;
import com.bytel.ravel.common.utils.DateTimeTools;
import org.easymock.EasyMock;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockNice;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PowerMockListener;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.testlisteners.FieldDefaulter;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.modules.junit4.PowerMockRunnerDelegate;
import org.springframework.test.context.ContextConfiguration;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.data.exchange.generated.RavelRequest.RequestHeader;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.test.podam.PodamBytelJUnit4ClassRunner;
import com.bytel.ravel.common.utils.RetourFactoryForTU;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.utils.Test_Consts;
import com.bytel.spirit.common.activities.shared.BL800_ObtenirSequence;
import com.bytel.spirit.common.activities.shared.BL800_ObtenirSequence.BL800_ObtenirSequenceBuilder;
import com.bytel.spirit.common.activities.shared.structs.UniqueIdConstant;
import com.bytel.spirit.common.connectors.res.RESProxy;
import com.bytel.spirit.common.connectors.rex.REXProxy;
import com.bytel.spirit.common.shared.functional.types.json.RavelJsonTools;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.error.ReponseErreur;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.BoitierPM;
import com.bytel.spirit.common.shared.saab.res.CartePON;
import com.bytel.spirit.common.shared.saab.res.LienPortPMPon;
import com.bytel.spirit.common.shared.saab.res.OltComposite;
import com.bytel.spirit.common.shared.saab.res.OntId;
import com.bytel.spirit.common.shared.saab.res.PMComposite;
import com.bytel.spirit.common.shared.saab.res.PanneauPM;
import com.bytel.spirit.common.shared.saab.res.PortPM;
import com.bytel.spirit.common.shared.saab.res.PortPON;
import com.bytel.spirit.common.shared.saab.res.PortPonId;
import com.bytel.spirit.common.shared.saab.res.Ressource;
import com.bytel.spirit.common.shared.saab.res.RessourceOntId;
import com.bytel.spirit.common.shared.saab.res.RessourcePortPM;
import com.bytel.spirit.common.shared.saab.res.SurchargePortPON;
import com.bytel.spirit.common.shared.saab.res.TypeRessource;
import com.bytel.spirit.common.shared.saab.rex.CleRechercheOperationVieReseau;
import com.bytel.spirit.common.shared.saab.rex.OperationVieReseau;
import com.bytel.spirit.common.shared.saab.rex.request.ListeCleRechercheOperationVieReseauRequest;
import com.bytel.spirit.tesla.shared.types.PE0529.AjoutPortPm;
import com.bytel.spirit.tesla.shared.types.PE0529.AjoutPortPon;
import com.bytel.spirit.tesla.shared.types.PE0529.BoitierPm;
import com.bytel.spirit.tesla.shared.types.PE0529.CartePon;
import com.bytel.spirit.tesla.shared.types.PE0529.LienPortPon;
import com.bytel.spirit.tesla.shared.types.PE0529.MigrationPortPm;
import com.bytel.spirit.tesla.shared.types.PE0529.ModificationPortPm;
import com.bytel.spirit.tesla.shared.types.PE0529.ModificationPortPon;
import com.bytel.spirit.tesla.shared.types.PE0529.PanneauPm;
import com.bytel.spirit.tesla.shared.types.PE0529.PositionPortPm;
import com.bytel.spirit.tesla.shared.types.PE0529.PositionPortPon;
import com.bytel.spirit.tesla.shared.types.PE0529.SuppressionPortPm;
import com.bytel.spirit.tesla.shared.types.PE0529.SuppressionPortPon;
import com.bytel.spirit.tesla.shared.types.PE0529.request.PE0529_PostRequest;
import com.bytel.spirit.tesla.shared.types.PE0529.response.PE0529_PostResponse;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 * Classe de test pour la requête POST du processus {@link PE0529_OperationVieReseau}
 *
 * @author jchevron
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PowerMockListener(FieldDefaulter.class)
@PowerMockRunnerDelegate(PodamBytelJUnit4ClassRunner.class)
@ContextConfiguration("classpath:BeansProcessTestMocks.xml") //$NON-NLS-1$
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" }) //$NON-NLS-1$ //$NON-NLS-2$
@PrepareForTest({ PE0529_OperationVieReseau.class, BL800_ObtenirSequence.class, BL800_ObtenirSequenceBuilder.class, REXProxy.class, RESProxy.class })
public class PE0529_PostOperationVieReseauTest
{
  /**
   * Identifiant operation vie reseau
   */
  private static final String ID_OPERATION_VIE_RESEAU = "idOperationVieReseau"; //$NON-NLS-1$

  /**
   * The default process name.
   */
  public static final String DEFAULT_PROCESSNAME = "PE0529_OperationVieReseau"; //$NON-NLS-1$

  /**
   * bean Factory generation
   */
  private static PodamFactory __podam = new PodamFactoryImpl();

  /**
   * Initialize before all tests
   *
   * @throws Exception
   *           On errors Exception to be thrown in case of failure
   */
  @BeforeClass
  public static void setUpBeforeClass() throws Exception
  {
    __podam.getStrategy().setMemoization(false);
    __podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());
  }

  @MockStrict
  protected REXProxy _rexProxyMock;

  @MockStrict
  protected RESProxy _resProxyMock;

  @MockStrict
  protected BL800_ObtenirSequence _bl800Mock;

  @MockNice
  protected BL800_ObtenirSequenceBuilder _bl800BuilderMock;

  /**
   * Instance to evaluate
   */
  private PE0529_OperationVieReseau _processInstance;

  /**
   * Tracabilite
   */
  Tracabilite _tracabilite;

  /**
   * <b>Cas de test:</b> Headers tous null<br/>
   * <b>Entrées:</b> Header null ou vide<br/>
   * <b>Attendu:</b> ResponseErreur 400 - Header HTTP obligatoire manquant: Authorization<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_POST_BL001_NOK_001() throws Throwable
  {
    PE0529_PostRequest creationRequest = new PE0529_PostRequest(null);
    List<RequestHeader> headers = addXHeaders(null, null, null, null, null, null);
    Request request = preparePostRequest(creationRequest, headers);

    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPostProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals("Le entête \"X-Source\" est vide.", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegSpiritConsts.DONNEE_INVALIDE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> Header null<br/>
   * <b>Entrées:</b> Un header null ou vide<br/>
   * <b>Attendu:</b> ResponseErreur 400 - Header HTTP obligatoire manquant: Authorization<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_POST_BL001_NOK_002() throws Throwable
  {
    PE0529_PostRequest creationRequest = new PE0529_PostRequest(null);
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", null, "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
    Request request = preparePostRequest(creationRequest, headers);

    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPostProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals("Le entête \"X-Source\" est vide.", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegSpiritConsts.DONNEE_INVALIDE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> Request body null<br/>
   * <b>Entrées:</b> Requête avec body null<br/>
   * <b>Attendu:</b> ResponseErreur 400 - Non respect du format d'entrée de la STI<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_POST_BL001_NOK_003() throws Throwable
  {
    PE0529_PostRequest creationRequest = null;
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePostRequest(creationRequest, headers);

    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPostProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals("Le corps de la requête ne respecte pas le format demandé.", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegSpiritConsts.DONNEE_INVALIDE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> PE0529_PostRequest avec champs obligatoires vides (<br/>
   * <b>Entrées:</b> Requête avec body mais valeurs obligatoire vides<br/>
   * <b>Attendu:</b> ResponseErreur 400 - Attribut obligatoire manquant<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_POST_BL001_NOK_004() throws Throwable
  {
    PE0529_PostRequest creationRequest = new PE0529_PostRequest(null, null);
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePostRequest(creationRequest, headers);

    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPostProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Map<String, Set<String>> expectedDescription = new HashMap<>();
    expectedDescription.put("Attribut obligatoire manquant", new HashSet<>(Arrays.asList("_typeVieReseau", "_listeTypeEquipementImpacte"))); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    checkBodyStiErrors(expectedDescription, reponseactual.getErrorDescription());
    Assert.assertEquals(IMegSpiritConsts.DONNEE_INVALIDE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> PE0529_PostRequest avec champs obligatoires incorrects (<br/>
   * <b>Entrées:</b> Requête avec body mais valeurs obligatoire incorrectes<br/>
   * <b>Attendu:</b> ResponseErreur 400 - Format d'attribut non respecté<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_POST_BL001_NOK_005() throws Throwable
  {
    PE0529_PostRequest creationRequest = new PE0529_PostRequest("PON128", Collections.singletonList("unknown")); //$NON-NLS-1$ //$NON-NLS-2$
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePostRequest(creationRequest, headers);

    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPostProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Map<String, Set<String>> expectedDescription = new HashMap<>();
    expectedDescription.put("Format d'attribut non respecté", Collections.singleton("_listeTypeEquipementImpacte")); //$NON-NLS-1$ //$NON-NLS-2$

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    checkBodyStiErrors(expectedDescription, reponseactual.getErrorDescription());
    Assert.assertEquals(IMegSpiritConsts.DONNEE_INVALIDE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> Incoherence typeEquipementImpacte (PM) et actions reelles (ajout PortPON) (<br/>
   * <b>Entrées:</b> Requête avec body typeEquipementImpacte=["PM"] et ajoutPortPon non null<br/>
   * <b>Attendu:</b> ResponseErreur 400 - Format d'attribut non respecté<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_POST_BL001_NOK_006() throws Throwable
  {
    PositionPortPon positionPortPont = new PositionPortPon(1, 1, "nomOLT"); //$NON-NLS-1$
    CartePon cartePon = new CartePon("1", "nomCartPon"); //$NON-NLS-1$ //$NON-NLS-2$
    AjoutPortPon ajoutPortPon = new AjoutPortPon(positionPortPont, Arrays.asList("GPON", "XGSPON"), 1, cartePon); //$NON-NLS-1$ //$NON-NLS-2$

    PE0529_PostRequest creationRequest = new PE0529_PostRequest("PON128", Collections.singletonList("PM")); //$NON-NLS-1$ //$NON-NLS-2$
    creationRequest.setAjoutsPortsPon(Collections.singletonList(ajoutPortPon));
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePostRequest(creationRequest, headers);

    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPostProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Map<String, Set<String>> expectedDescription = new HashMap<>();
    expectedDescription.put("Format d'attribut non respecté", Collections.singleton("_listeTypeEquipementImpacte")); //$NON-NLS-1$ //$NON-NLS-2$

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    checkBodyStiErrors(expectedDescription, reponseactual.getErrorDescription());
    Assert.assertEquals(IMegSpiritConsts.DONNEE_INVALIDE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> Incoherence typeEquipementImpacte (OLT) et actions reelles (ajout PortPM) (<br/>
   * <b>Entrées:</b> Requête avec body typeEquipementImpacte=["OLT"] et ajoutPortPm non null<br/>
   * <b>Attendu:</b> ResponseErreur 400 - Format d'attribut non respecté<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_POST_BL001_NOK_007() throws Throwable
  {
    PositionPortPm posPortPm = new PositionPortPm(1, "nomPanneau", "refBoitierPm", "refPmBytel"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    LienPortPon lienPortPon = new LienPortPon("nomOlt", 1, 1); //$NON-NLS-1$
    PanneauPm panneauPm = new PanneauPm("nomPanneau"); //$NON-NLS-1$
    BoitierPm boitierPm = new BoitierPm("refBoitierPm", "nomPmTechnique"); //$NON-NLS-1$ //$NON-NLS-2$
    AjoutPortPm ajoutPortPm = new AjoutPortPm(posPortPm, Collections.singletonList(lienPortPon), panneauPm, boitierPm);

    PE0529_PostRequest creationRequest = new PE0529_PostRequest("PON128", Collections.singletonList("OLT")); //$NON-NLS-1$ //$NON-NLS-2$
    creationRequest.setAjoutsPortsPm(Collections.singletonList(ajoutPortPm));
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePostRequest(creationRequest, headers);

    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPostProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Map<String, Set<String>> expectedDescription = new HashMap<>();
    expectedDescription.put("Format d'attribut non respecté", Collections.singleton("_listeTypeEquipementImpacte")); //$NON-NLS-1$ //$NON-NLS-2$

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    checkBodyStiErrors(expectedDescription, reponseactual.getErrorDescription());
    Assert.assertEquals(IMegSpiritConsts.DONNEE_INVALIDE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> Tous les éléments finaux de la requêtes sont vides (<br/>
   * <b>Entrées:</b> Requête avec ajout/migration/modification/suppresion portPm mais éléments finaux vides<br/>
   * <b>Attendu:</b> ResponseErreur 400 - Attribut obligatoire manquant<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_POST_BL001_NOK_008() throws Throwable
  {
    PositionPortPm positionPortPm = new PositionPortPm(null, null, null, null);
    LienPortPon lienPortPon = new LienPortPon(null, null, null);
    PanneauPm panneauPm = new PanneauPm(""); //$NON-NLS-1$
    BoitierPm boitierPm = new BoitierPm(null, null);

    AjoutPortPm ajoutPortPm = new AjoutPortPm(positionPortPm, Collections.singletonList(lienPortPon), panneauPm, boitierPm);
    MigrationPortPm migrationPortPm = new MigrationPortPm(positionPortPm, positionPortPm);
    ModificationPortPm modificationPortPm = new ModificationPortPm(positionPortPm, Collections.singletonList(lienPortPon), Collections.singletonList(lienPortPon));
    SuppressionPortPm suppressionPortPm = new SuppressionPortPm(Collections.singletonList(positionPortPm));

    PE0529_PostRequest creationRequest = new PE0529_PostRequest("PON128", Collections.singletonList("PM")); //$NON-NLS-1$ //$NON-NLS-2$
    creationRequest.setAjoutsPortsPm(Collections.singletonList(ajoutPortPm));
    creationRequest.setMigrationsPortsPm(Collections.singletonList(migrationPortPm));
    creationRequest.setModificationsPortsPm(Collections.singletonList(modificationPortPm));
    creationRequest.setSuppressionsPortsPm(Collections.singletonList(suppressionPortPm));

    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePostRequest(creationRequest, headers);

    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPostProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Map<String, Set<String>> expectedDescription = new HashMap<>();
    Set<String> attributsManquants = new HashSet<>();
    attributsManquants.add("_ajoutsPortsPm[0]._positionPortsPm._positionPort"); //$NON-NLS-1$
    attributsManquants.add("_ajoutsPortsPm[0]._positionPortsPm._nomPanneau"); //$NON-NLS-1$
    attributsManquants.add("_ajoutsPortsPm[0]._positionPortsPm._referenceBoitierPm"); //$NON-NLS-1$
    attributsManquants.add("_ajoutsPortsPm[0]._positionPortsPm._referencePmBytel"); //$NON-NLS-1$
    attributsManquants.add("_ajoutsPortsPm[0]._liensPortPon[0]._positionPortPon"); //$NON-NLS-1$
    attributsManquants.add("_ajoutsPortsPm[0]._liensPortPon[0]._nomOLT"); //$NON-NLS-1$
    attributsManquants.add("_ajoutsPortsPm[0]._liensPortPon[0]._positionCartePon"); //$NON-NLS-1$
    attributsManquants.add("_ajoutsPortsPm[0]._boitierPm._referenceBoitierPm"); //$NON-NLS-1$
    attributsManquants.add("_ajoutsPortsPm[0]._boitierPm._nomPmTechnique"); //$NON-NLS-1$
    attributsManquants.add("_ajoutsPortsPm[0]._panneauPm._nomPanneau"); //$NON-NLS-1$
    attributsManquants.add("_migrationsPortsPm[0]._positionPortPmSource._positionPort"); //$NON-NLS-1$
    attributsManquants.add("_migrationsPortsPm[0]._positionPortPmSource._nomPanneau"); //$NON-NLS-1$
    attributsManquants.add("_migrationsPortsPm[0]._positionPortPmSource._referenceBoitierPm"); //$NON-NLS-1$
    attributsManquants.add("_migrationsPortsPm[0]._positionPortPmSource._referencePmBytel"); //$NON-NLS-1$
    attributsManquants.add("_migrationsPortsPm[0]._positionPortPmCible._positionPort"); //$NON-NLS-1$
    attributsManquants.add("_migrationsPortsPm[0]._positionPortPmCible._nomPanneau"); //$NON-NLS-1$
    attributsManquants.add("_migrationsPortsPm[0]._positionPortPmCible._referenceBoitierPm"); //$NON-NLS-1$
    attributsManquants.add("_migrationsPortsPm[0]._positionPortPmCible._referencePmBytel"); //$NON-NLS-1$
    attributsManquants.add("_modificationsPortsPm[0]._positionPortPm._positionPort"); //$NON-NLS-1$
    attributsManquants.add("_modificationsPortsPm[0]._positionPortPm._nomPanneau"); //$NON-NLS-1$
    attributsManquants.add("_modificationsPortsPm[0]._positionPortPm._referenceBoitierPm"); //$NON-NLS-1$
    attributsManquants.add("_modificationsPortsPm[0]._positionPortPm._referencePmBytel"); //$NON-NLS-1$
    attributsManquants.add("_modificationsPortsPm[0]._liensPortPonSource[0]._positionPortPon"); //$NON-NLS-1$
    attributsManquants.add("_modificationsPortsPm[0]._liensPortPonSource[0]._nomOLT"); //$NON-NLS-1$
    attributsManquants.add("_modificationsPortsPm[0]._liensPortPonSource[0]._positionCartePon"); //$NON-NLS-1$
    attributsManquants.add("_modificationsPortsPm[0]._liensPortPonCible[0]._positionPortPon"); //$NON-NLS-1$
    attributsManquants.add("_modificationsPortsPm[0]._liensPortPonCible[0]._nomOLT"); //$NON-NLS-1$
    attributsManquants.add("_modificationsPortsPm[0]._liensPortPonCible[0]._positionCartePon"); //$NON-NLS-1$
    attributsManquants.add("_suppressionsPortsPm[0]._positionPortsPm[0]._positionPort"); //$NON-NLS-1$
    attributsManquants.add("_suppressionsPortsPm[0]._positionPortsPm[0]._nomPanneau"); //$NON-NLS-1$
    attributsManquants.add("_suppressionsPortsPm[0]._positionPortsPm[0]._referenceBoitierPm"); //$NON-NLS-1$
    attributsManquants.add("_suppressionsPortsPm[0]._positionPortsPm[0]._referencePmBytel"); //$NON-NLS-1$
    expectedDescription.put("Attribut obligatoire manquant", attributsManquants); //$NON-NLS-1$

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    checkBodyStiErrors(expectedDescription, reponseactual.getErrorDescription());
    Assert.assertEquals(IMegSpiritConsts.DONNEE_INVALIDE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> Objets Ajout/Migration/Modification/Suppresion vides (<br/>
   * <b>Entrées:</b> Requête avec ajout/migration/modification/suppresion portPm mais éléments vides<br/>
   * <b>Attendu:</b> ResponseErreur 400 - Attribut obligatoire manquant<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_POST_BL001_NOK_009() throws Throwable
  {
    AjoutPortPm ajoutPortPm = new AjoutPortPm(null, null, null, null);
    MigrationPortPm migrationPortPm = new MigrationPortPm(null, null);
    ModificationPortPm modificationPortPm = new ModificationPortPm(null, null, null);
    SuppressionPortPm suppressionPortPm = new SuppressionPortPm(new ArrayList<>());

    PE0529_PostRequest creationRequest = new PE0529_PostRequest("PON128", Collections.singletonList("PM")); //$NON-NLS-1$ //$NON-NLS-2$
    creationRequest.setAjoutsPortsPm(Collections.singletonList(ajoutPortPm));
    creationRequest.setMigrationsPortsPm(Collections.singletonList(migrationPortPm));
    creationRequest.setModificationsPortsPm(Collections.singletonList(modificationPortPm));
    creationRequest.setSuppressionsPortsPm(Collections.singletonList(suppressionPortPm));

    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePostRequest(creationRequest, headers);

    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPostProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Map<String, Set<String>> expectedDescription = new HashMap<>();
    Set<String> attributsManquants = new HashSet<>();
    attributsManquants.add("_ajoutsPortsPm[0]._positionPortsPm"); //$NON-NLS-1$
    attributsManquants.add("_ajoutsPortsPm[0]._liensPortPon"); //$NON-NLS-1$
    attributsManquants.add("_ajoutsPortsPm[0]._boitierPm"); //$NON-NLS-1$
    attributsManquants.add("_ajoutsPortsPm[0]._panneauPm"); //$NON-NLS-1$
    attributsManquants.add("_migrationsPortsPm[0]._positionPortPmSource"); //$NON-NLS-1$
    attributsManquants.add("_migrationsPortsPm[0]._positionPortPmCible"); //$NON-NLS-1$
    attributsManquants.add("_modificationsPortsPm[0]._positionPortPm"); //$NON-NLS-1$
    attributsManquants.add("_modificationsPortsPm[0]._liensPortPonSource"); //$NON-NLS-1$
    attributsManquants.add("_modificationsPortsPm[0]._liensPortPonCible"); //$NON-NLS-1$
    attributsManquants.add("_suppressionsPortsPm[0]._positionPortsPm"); //$NON-NLS-1$
    expectedDescription.put("Attribut obligatoire manquant", attributsManquants); //$NON-NLS-1$

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    checkBodyStiErrors(expectedDescription, reponseactual.getErrorDescription());
    Assert.assertEquals(IMegSpiritConsts.DONNEE_INVALIDE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> Tous les éléments finaux de la requêtes sont vides (<br/>
   * <b>Entrées:</b> Requête avec ajout/migration/modification/suppresion portPon mais éléments finaux vides<br/>
   * <b>Attendu:</b> ResponseErreur 400 - Attribut obligatoire manquant<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_POST_BL001_NOK_010() throws Throwable
  {
    PositionPortPon positionPortPon = new PositionPortPon(null, null, null);
    CartePon cartePon = new CartePon(null, null);

    AjoutPortPon ajoutPortPon = new AjoutPortPon(positionPortPon, null, null, cartePon);
    ModificationPortPon modifPortPon = new ModificationPortPon(positionPortPon, null);
    SuppressionPortPon suppressionPortPon = new SuppressionPortPon(positionPortPon);

    PE0529_PostRequest creationRequest = new PE0529_PostRequest("PON128", Collections.singletonList("OLT")); //$NON-NLS-1$ //$NON-NLS-2$
    creationRequest.setAjoutsPortsPon(Collections.singletonList(ajoutPortPon));
    creationRequest.setModificationsPortsPon(Collections.singletonList(modifPortPon));
    creationRequest.setSuppressionsPortsPon(Collections.singletonList(suppressionPortPon));

    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePostRequest(creationRequest, headers);

    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPostProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Map<String, Set<String>> expectedDescription = new HashMap<>();
    Set<String> attributsManquants = new HashSet<>();
    attributsManquants.add("_ajoutsPortsPon[0]._positionPortPon._nomOLT"); //$NON-NLS-1$
    attributsManquants.add("_ajoutsPortsPon[0]._positionPortPon._position"); //$NON-NLS-1$
    attributsManquants.add("_ajoutsPortsPon[0]._positionPortPon._positionCarte"); //$NON-NLS-1$
    attributsManquants.add("_ajoutsPortsPon[0]._sfpListeTechnologieCompatible"); //$NON-NLS-1$
    attributsManquants.add("_ajoutsPortsPon[0]._maxOntId"); //$NON-NLS-1$
    attributsManquants.add("_ajoutsPortsPon[0]._cartePon._modeleCarte"); //$NON-NLS-1$
    attributsManquants.add("_ajoutsPortsPon[0]._cartePon._position"); //$NON-NLS-1$
    attributsManquants.add("_modificationsPortsPon[0]._positionPortPon._nomOLT"); //$NON-NLS-1$
    attributsManquants.add("_modificationsPortsPon[0]._positionPortPon._position"); //$NON-NLS-1$
    attributsManquants.add("_modificationsPortsPon[0]._positionPortPon._positionCarte"); //$NON-NLS-1$
    attributsManquants.add("_modificationsPortsPon[0]._sfpListeTechnologieCompatible"); //$NON-NLS-1$
    attributsManquants.add("_suppressionsPortsPon[0]._positionPortPon._nomOLT"); //$NON-NLS-1$
    attributsManquants.add("_suppressionsPortsPon[0]._positionPortPon._positionCarte"); //$NON-NLS-1$
    attributsManquants.add("_suppressionsPortsPon[0]._positionPortPon._position"); //$NON-NLS-1$
    expectedDescription.put("Attribut obligatoire manquant", attributsManquants); //$NON-NLS-1$

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    checkBodyStiErrors(expectedDescription, reponseactual.getErrorDescription());
    Assert.assertEquals(IMegSpiritConsts.DONNEE_INVALIDE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> Objets Ajout/Modification/Suppresion vides (<br/>
   * <b>Entrées:</b> Requête avec ajout/modification/suppresion portPon mais éléments vides<br/>
   * <b>Attendu:</b> ResponseErreur 400 - Attribut obligatoire manquant<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_POST_BL001_NOK_011() throws Throwable
  {
    PositionPortPon positionPortPon = new PositionPortPon(null, null, null);
    AjoutPortPon ajoutPortPon = new AjoutPortPon(null, null, null, null);
    ModificationPortPon modifPortPon = new ModificationPortPon(null, null);
    SuppressionPortPon suppressionPortPon = new SuppressionPortPon(positionPortPon);
    suppressionPortPon.setPositionPortPon(null);

    PE0529_PostRequest creationRequest = new PE0529_PostRequest("PON128", Collections.singletonList("OLT")); //$NON-NLS-1$ //$NON-NLS-2$
    creationRequest.setAjoutsPortsPon(Collections.singletonList(ajoutPortPon));
    creationRequest.setModificationsPortsPon(Collections.singletonList(modifPortPon));
    creationRequest.setSuppressionsPortsPon(Collections.singletonList(suppressionPortPon));

    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePostRequest(creationRequest, headers);

    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPostProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Map<String, Set<String>> expectedDescription = new HashMap<>();
    Set<String> attributsManquants = new HashSet<>();
    attributsManquants.add("_ajoutsPortsPon[0]._positionPortPon"); //$NON-NLS-1$
    attributsManquants.add("_ajoutsPortsPon[0]._sfpListeTechnologieCompatible"); //$NON-NLS-1$
    attributsManquants.add("_ajoutsPortsPon[0]._maxOntId"); //$NON-NLS-1$
    attributsManquants.add("_ajoutsPortsPon[0]._cartePon"); //$NON-NLS-1$
    attributsManquants.add("_modificationsPortsPon[0]._positionPortPon"); //$NON-NLS-1$
    attributsManquants.add("_modificationsPortsPon[0]._sfpListeTechnologieCompatible"); //$NON-NLS-1$
    attributsManquants.add("_suppressionsPortsPon[0]._positionPortPon"); //$NON-NLS-1$
    expectedDescription.put("Attribut obligatoire manquant", attributsManquants); //$NON-NLS-1$

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    checkBodyStiErrors(expectedDescription, reponseactual.getErrorDescription());
    Assert.assertEquals(IMegSpiritConsts.DONNEE_INVALIDE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> sfpListeTechnologieCompatible avec XGPON (<br/>
   * <b>Entrées:</b> sfpListeTechnologieCompatible avec XGPON <br/>
   * <b>Attendu:</b> ResponseErreur 400 - Format d'attribut non respecté<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_POST_BL001_NOK_012() throws Throwable
  {
    PositionPortPon positionPortPont = new PositionPortPon(1, 1, "nomOLT"); //$NON-NLS-1$
    CartePon cartePon = new CartePon("1", "nomCartPon"); //$NON-NLS-1$ //$NON-NLS-2$
    AjoutPortPon ajoutPortPon = new AjoutPortPon(positionPortPont, Arrays.asList("GPON", "XGPON"), 1, cartePon); //$NON-NLS-1$ //$NON-NLS-2$
    ModificationPortPon modifPortPon = new ModificationPortPon(positionPortPont,  Arrays.asList("GPON", "XGPON"));

    PE0529_PostRequest creationRequest = new PE0529_PostRequest("PON128", Collections.singletonList("OLT")); //$NON-NLS-1$ //$NON-NLS-2$
    creationRequest.setAjoutsPortsPon(Collections.singletonList(ajoutPortPon));
    creationRequest.setModificationsPortsPon(Collections.singletonList(modifPortPon));
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePostRequest(creationRequest, headers);

    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPostProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Map<String, Set<String>> expectedDescription = new HashMap<>();
    Set<String> formatAttribut = new HashSet<>();
    formatAttribut.add("_modificationsPortsPon[0]._sfpListeTechnologieCompatible[1].<list element>"); //$NON-NLS-1$
    formatAttribut.add("_ajoutsPortsPon[0]._sfpListeTechnologieCompatible[1].<list element>"); //$NON-NLS-1$
    expectedDescription.put("Format d'attribut non respecté", formatAttribut); //$NON-NLS-1$

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    checkBodyStiErrors(expectedDescription, reponseactual.getErrorDescription());
    Assert.assertEquals(IMegSpiritConsts.DONNEE_INVALIDE, reponseactual.getError());
  }

  /**
   * <b>Cas de test: Port à supprimer au statut ALLOUE</b> (<br/>
   * <b>Entrées:</b> Requête ok<br/>
   * <b>Attendu:</b> ResponseErreur 403 - ACCES_REFUSE - portPm ALLOUEE et n'est pas migré, ne peut être supprimé<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_POST_BL100_NOK_001() throws Throwable
  {
    // Préparation de la requête
    PositionPortPm posPortPmSupp = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    SuppressionPortPm suppPortPm = new SuppressionPortPm(Collections.singletonList(posPortPmSupp));
    PE0529_PostRequest creationRequest = new PE0529_PostRequest("PON128", Arrays.asList("PM", "OLT")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    creationRequest.setNumeroGCR("GCR-12345678"); //$NON-NLS-1$
    creationRequest.setSuppressionsPortsPm(Collections.singletonList(suppPortPm));
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePostRequest(creationRequest, headers);

    // MOCK RES.ressourceLireUn
    Ressource ressource = new RessourcePortPM("ALLOUE", "GHYUI890", "PANNEAU_A", "PANNEAU_A", 1); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource, "GHYUI890||BOITIER_A||PANNEAU_A||1", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPostProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Récupération du résultat de la requête
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    // Tests de retours
    Assert.assertEquals(ErrorCode.KO_00403, response.getErrorCode());
    Assert.assertEquals("L'objet portPm GHYUI890-BOITIER_A-PANNEAU_A-1 est ALLOUEE et nest pas migré, donc il ne peut pas être supprimé.", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegSpiritConsts.ACCES_REFUSE, reponseactual.getError());
  }

  /**
   * <b>Cas de test: Port PM source à migrer innexistant dans RES</b> (<br/>
   * <b>Entrées:</b> Requête ok<br/>
   * <b>Attendu:</b> ResponseErreur 404 - DONNEE_INCONNUE - objet portPm Source inexistant dans Referentiel SPIRIT<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_POST_BL100_NOK_002() throws Throwable
  {
    // Preparation de la requête
    PositionPortPm posPortPmMigreSrc = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmMigreCible = new PositionPortPm(1, "PANNEAU_B", "BOITIER_B", "GHYUI891"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    MigrationPortPm migrationPortPm = new MigrationPortPm(posPortPmMigreSrc, posPortPmMigreCible);
    PositionPortPm posPortPmMigreAjout = new PositionPortPm(1, "PANNEAU_C", "BOITIER_C", "GHYUI892"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    LienPortPon lienPortPonAjout = new LienPortPon("OLT2000", 2, 1); //$NON-NLS-1$
    PanneauPm panneauPm = new PanneauPm("PANNEAU_D"); //$NON-NLS-1$
    BoitierPm boitierPm = new BoitierPm("BOITIER_D", "ABCD123"); //$NON-NLS-1$ //$NON-NLS-2$
    AjoutPortPm ajoutPortPm = new AjoutPortPm(posPortPmMigreAjout, Collections.singletonList(lienPortPonAjout), panneauPm, boitierPm);
    PositionPortPm posPortPmSupp = new PositionPortPm(1, "PANNEAU_E", "BOITIER_E", "GHYUI893"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    SuppressionPortPm suppPortPm = new SuppressionPortPm(Collections.singletonList(posPortPmSupp));
    PE0529_PostRequest creationRequest = new PE0529_PostRequest("PON128", Arrays.asList("PM", "OLT")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    creationRequest.setNumeroGCR("GCR-12345678"); //$NON-NLS-1$
    creationRequest.setMigrationsPortsPm(Collections.singletonList(migrationPortPm));
    creationRequest.setAjoutsPortsPm(Collections.singletonList(ajoutPortPm));
    creationRequest.setSuppressionsPortsPm(Collections.singletonList(suppPortPm));
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePostRequest(creationRequest, headers);

    // MOCK RES.ressourceLireUn
    Ressource ressource = new RessourcePortPM("LIBRE", "GHYUI893", "BOITIER_E", "PANNEAU_E", 1); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource, "GHYUI893||BOITIER_E||PANNEAU_E||1", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    // MOCK RES.pmCompositeLireUnParReferencePmBytel (portPM Src)
    PMComposite pmCompositeSrc = createPMCompositeFromPositionPortPm(posPortPmMigreAjout);
    mockRES_PmCompositeLireUnParReferencePmBytel(RetourFactoryForTU.createOkRetour(), pmCompositeSrc, "GHYUI890"); //$NON-NLS-1$

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPostProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Récupération du résultat de la requête
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    // Tests de retours
    Assert.assertEquals(ErrorCode.KO_00404, response.getErrorCode());
    Assert.assertEquals("L'objet portPm Source GHYUI890-BOITIER_A-PANNEAU_A-1 inexistant dans Referentiel SPIRIT.", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegConsts.DONNEE_INCONNUE, reponseactual.getError());
  }

  /**
   * <b>Cas de test: </b> Port PM cible à migrer innexistant dans RES (<br/>
   * <b>Entrées:</b> Requête ok<br/>
   * <b>Attendu:</b> ResponseErreur 404 - DONNEE_INCONNUE - objet portPm Cible inexistant dans Referentiel SPIRIT et
   * dans ajoutsPortsPm<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_POST_BL100_NOK_003() throws Throwable
  {
    // Preparation de la requête
    PositionPortPm posPortPmMigreSrc = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmMigreCible = new PositionPortPm(1, "PANNEAU_B", "BOITIER_B", "GHYUI891"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    MigrationPortPm migrationPortPm = new MigrationPortPm(posPortPmMigreSrc, posPortPmMigreCible);
    PositionPortPm posPortPmAjout = new PositionPortPm(1, "PANNEAU_C", "BOITIER_C", "GHYUI892"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    LienPortPon lienPortPonAjout = new LienPortPon("OLT2000", 2, 1); //$NON-NLS-1$
    PanneauPm panneauPm = new PanneauPm("PANNEAU_D"); //$NON-NLS-1$
    BoitierPm boitierPm = new BoitierPm("BOITIER_D", "ABCD123"); //$NON-NLS-1$ //$NON-NLS-2$
    AjoutPortPm ajoutPortPm = new AjoutPortPm(posPortPmAjout, Collections.singletonList(lienPortPonAjout), panneauPm, boitierPm);
    PositionPortPm posPortPmSupp = new PositionPortPm(1, "PANNEAU_E", "BOITIER_E", "GHYUI893"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    SuppressionPortPm suppPortPm = new SuppressionPortPm(Collections.singletonList(posPortPmSupp));
    PE0529_PostRequest creationRequest = new PE0529_PostRequest("PON128", Arrays.asList("PM", "OLT")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    creationRequest.setNumeroGCR("GCR-12345678"); //$NON-NLS-1$
    creationRequest.setMigrationsPortsPm(Collections.singletonList(migrationPortPm));
    creationRequest.setAjoutsPortsPm(Collections.singletonList(ajoutPortPm));
    creationRequest.setSuppressionsPortsPm(Collections.singletonList(suppPortPm));
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePostRequest(creationRequest, headers);

    // MOCK RES.ressourceLireUn
    Ressource ressource = new RessourcePortPM("LIBRE", "GHYUI893", "BOITIER_E", "PANNEAU_E", 1); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource, "GHYUI893||BOITIER_E||PANNEAU_E||1", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    // MOCK RES.pmCompositeLireUnParReferencePmBytel (portPM Src)
    PMComposite pmCompositeSrc = createPMCompositeFromPositionPortPm(posPortPmMigreSrc);
    mockRES_PmCompositeLireUnParReferencePmBytel(RetourFactoryForTU.createOkRetour(), pmCompositeSrc, "GHYUI890"); //$NON-NLS-1$

    // MOCK RES.pmCompositeLireUnParReferencePmBytel (portPM Cible)
    PMComposite pmCompositeCible = createPMCompositeFromPositionPortPm(posPortPmMigreSrc);
    mockRES_PmCompositeLireUnParReferencePmBytel(RetourFactoryForTU.createOkRetour(), pmCompositeCible, "GHYUI891"); //$NON-NLS-1$

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPostProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Récupération du résultat de la requête
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    // Tests de retours
    Assert.assertEquals(ErrorCode.KO_00404, response.getErrorCode());
    Assert.assertEquals("L'objet portPm Cible GHYUI891-BOITIER_B-PANNEAU_B-1 est introuvable dans Referentiel SPIRIT et dans ajoutsPortsPm.", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegConsts.DONNEE_INCONNUE, reponseactual.getError());
  }

  /**
   * <b>Cas de test: </b> Verif migration - RES.oltCompositeLireUn KO - Source (<br/>
   * <b>Entrées:</b> Requête ok<br/>
   * <b>Attendu:</b> ResponseErreur 503 - SERVICE_TIERS_INDISPONIBLE <br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_POST_BL100_NOK_004() throws Throwable
  {
    // Preparation de la requête
    PositionPortPm posPortPmMigreSrc = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmMigreCible = new PositionPortPm(1, "PANNEAU_B", "BOITIER_B", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    MigrationPortPm migrationPortPm = new MigrationPortPm(posPortPmMigreSrc, posPortPmMigreCible);
    LienPortPon lienPortPonAjout = new LienPortPon("OLT2000", 2, 1); //$NON-NLS-1$
    PanneauPm panneauPm = new PanneauPm("PANNEAU_D"); //$NON-NLS-1$
    BoitierPm boitierPm = new BoitierPm("BOITIER_D", "ABCD123"); //$NON-NLS-1$ //$NON-NLS-2$
    AjoutPortPm ajoutPortPm = new AjoutPortPm(posPortPmMigreCible, Collections.singletonList(lienPortPonAjout), panneauPm, boitierPm);
    PositionPortPm posPortPmSupp = new PositionPortPm(1, "PANNEAU_E", "BOITIER_E", "GHYUI893"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    SuppressionPortPm suppPortPm = new SuppressionPortPm(Collections.singletonList(posPortPmSupp));
    PositionPortPm posPortPmModif = new PositionPortPm(1, "PANNEAU_F", "BOITIER_F", "GHYUI894"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    LienPortPon lienPortPonModifSrc = new LienPortPon("OLT2000", 2, 1); //$NON-NLS-1$
    LienPortPon lienPortPonModifCible = new LienPortPon("OLT2000", 2, 3); //$NON-NLS-1$
    ModificationPortPm modifPortPm = new ModificationPortPm(posPortPmModif, Collections.singletonList(lienPortPonModifSrc), Collections.singletonList(lienPortPonModifCible));
    PE0529_PostRequest creationRequest = new PE0529_PostRequest("PON128", Arrays.asList("PM", "OLT")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    creationRequest.setNumeroGCR("GCR-12345678"); //$NON-NLS-1$
    creationRequest.setMigrationsPortsPm(Collections.singletonList(migrationPortPm));
    creationRequest.setAjoutsPortsPm(Collections.singletonList(ajoutPortPm));
    creationRequest.setSuppressionsPortsPm(Collections.singletonList(suppPortPm));
    creationRequest.setModificationsPortsPm(Collections.singletonList(modifPortPm));
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePostRequest(creationRequest, headers);

    // MOCK RES.ressourceLireUn
    Ressource ressource = new RessourcePortPM("LIBRE", "GHYUI893", "BOITIER_E", "PANNEAU_E", 1); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource, "GHYUI893||BOITIER_E||PANNEAU_E||1", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    // MOCK RES.pmCompositeLireUnParReferencePmBytel (portPM Src)
    PMComposite pmComposite = new PMComposite();
    pmComposite.setReferencePmBytel("GHYUI890"); //$NON-NLS-1$
    LienPortPMPon lienPortPMPon = new LienPortPMPon("OPERATIONNEL", new PortPonId("OLT2000", 1, 1)); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, LienPortPMPon> lienPortPMPonMap = new HashMap<>();
    lienPortPMPonMap.put("OLT2000-1-1", lienPortPMPon); //$NON-NLS-1$
    PortPM portPmComposite = new PortPM(1, "OPERATIONNEL", lienPortPMPonMap); //$NON-NLS-1$
    PortPM portPmComposite2 = new PortPM(2, "OPERATIONNEL", lienPortPMPonMap); //$NON-NLS-1$
    Map<Integer, PortPM> portCompositeMap = new HashMap<>();
    portCompositeMap.put(1, portPmComposite);
    portCompositeMap.put(2, portPmComposite2);
    PanneauPM panneauPMComposite = new PanneauPM("PANNEAU_A", "OPERATIONNEL", portCompositeMap); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, PanneauPM> panneauCompositeMap = new HashMap<>();
    panneauCompositeMap.put("PANNEAU_A", panneauPMComposite); //$NON-NLS-1$
    BoitierPM boitierPmComposite = new BoitierPM("BOITIER_A", "OPERATIONNEL", panneauCompositeMap); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, BoitierPM> boitierCompositeMap = new HashMap<>();
    boitierCompositeMap.put("BOITIER_A", boitierPmComposite); //$NON-NLS-1$
    pmComposite.setListeBoitierPM(boitierCompositeMap);
    mockRES_PmCompositeLireUnParReferencePmBytel(RetourFactoryForTU.createOkRetour(), pmComposite, "GHYUI890"); //$NON-NLS-1$

    // MOCK RES.pmCompositeLireUnParReferencePmBytel (portPM Cible) - not needed, already in cache

    // MOCK RES.oltCompositeLireUn
    Retour retourKO = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, "Error in RES"); //$NON-NLS-1$
    mockRES_OltCompositeLireUn(retourKO, null, "OLT2000"); //$NON-NLS-1$

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPostProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Récupération du résultat de la requête
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    // Tests de retours
    Assert.assertEquals(ErrorCode.KO_00503, response.getErrorCode());
    Assert.assertEquals("Error in RES", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegConsts.SERVICE_TIERS_INDISPONIBLE, reponseactual.getError());
  }

  /**
   * <b>Cas de test: </b> Verif migration - RES.oltCompositeLireUn KO - Cible (<br/>
   * <b>Entrées:</b> Requête ok<br/>
   * <b>Attendu:</b> ResponseErreur 503 - SERVICE_TIERS_INDISPONIBLE <br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_POST_BL100_NOK_005() throws Throwable
  {
    // Preparation de la requête
    PositionPortPm posPortPmMigreSrc = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmMigreCible = new PositionPortPm(2, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    MigrationPortPm migrationPortPm = new MigrationPortPm(posPortPmMigreSrc, posPortPmMigreCible);

    LienPortPon lienPortPonAjout = new LienPortPon("OLT2000", 2, 1); //$NON-NLS-1$
    PanneauPm panneauPm = new PanneauPm("PANNEAU_D"); //$NON-NLS-1$
    BoitierPm boitierPm = new BoitierPm("BOITIER_D", "ABCD123"); //$NON-NLS-1$ //$NON-NLS-2$
    AjoutPortPm ajoutPortPm = new AjoutPortPm(posPortPmMigreCible, Collections.singletonList(lienPortPonAjout), panneauPm, boitierPm);

    PositionPortPm posPortPmSupp = new PositionPortPm(1, "PANNEAU_E", "BOITIER_E", "GHYUI893"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    SuppressionPortPm suppPortPm = new SuppressionPortPm(Collections.singletonList(posPortPmSupp));

    PositionPortPm posPortPmModif = new PositionPortPm(1, "PANNEAU_F", "BOITIER_F", "GHYUI894"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    LienPortPon lienPortPonModifSrc = new LienPortPon("OLT2000", 2, 1); //$NON-NLS-1$
    LienPortPon lienPortPonModifCible = new LienPortPon("OLT2000", 2, 3); //$NON-NLS-1$
    ModificationPortPm modifPortPm = new ModificationPortPm(posPortPmModif, Collections.singletonList(lienPortPonModifSrc), Collections.singletonList(lienPortPonModifCible));

    PE0529_PostRequest creationRequest = new PE0529_PostRequest("PON128", Arrays.asList("PM", "OLT")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    creationRequest.setNumeroGCR("GCR-12345678"); //$NON-NLS-1$
    creationRequest.setMigrationsPortsPm(Collections.singletonList(migrationPortPm));
    creationRequest.setAjoutsPortsPm(Collections.singletonList(ajoutPortPm));
    creationRequest.setSuppressionsPortsPm(Collections.singletonList(suppPortPm));
    creationRequest.setModificationsPortsPm(Collections.singletonList(modifPortPm));

    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePostRequest(creationRequest, headers);

    // MOCK RES.ressourceLireUn
    Ressource ressource = new RessourcePortPM("LIBRE", "GHYUI893", "BOITIER_E", "PANNEAU_E", 1); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource, "GHYUI893||BOITIER_E||PANNEAU_E||1", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    // MOCK RES.pmCompositeLireUnParReferencePmBytel (portPM Src)
    PMComposite pmComposite = new PMComposite();
    pmComposite.setReferencePmBytel("GHYUI890"); //$NON-NLS-1$
    LienPortPMPon lienPortPMPon = new LienPortPMPon("OPERATIONNEL", new PortPonId("OLT2000", 1, 1)); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, LienPortPMPon> lienPortPMPonMap = new HashMap<>();
    lienPortPMPonMap.put("OLT2000-1-1", lienPortPMPon); //$NON-NLS-1$
    PortPM portPmComposite = new PortPM(1, "OPERATIONNEL", lienPortPMPonMap); //$NON-NLS-1$

    LienPortPMPon lienPortPMPon2 = new LienPortPMPon("OPERATIONNEL", new PortPonId("OLT2001", 1, 1)); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, LienPortPMPon> lienPortPMPonMap2 = new HashMap<>();
    lienPortPMPonMap2.put("OLT2001-1-1", lienPortPMPon2); //$NON-NLS-1$
    PortPM portPmComposite2 = new PortPM(2, "OPERATIONNEL", lienPortPMPonMap2); //$NON-NLS-1$

    Map<Integer, PortPM> portCompositeMap = new HashMap<>();
    portCompositeMap.put(1, portPmComposite);
    portCompositeMap.put(2, portPmComposite2);
    PanneauPM panneauPMComposite = new PanneauPM("PANNEAU_A", "OPERATIONNEL", portCompositeMap); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, PanneauPM> panneauCompositeMap = new HashMap<>();
    panneauCompositeMap.put("PANNEAU_A", panneauPMComposite); //$NON-NLS-1$
    BoitierPM boitierPmComposite = new BoitierPM("BOITIER_A", "OPERATIONNEL", panneauCompositeMap); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, BoitierPM> boitierCompositeMap = new HashMap<>();
    boitierCompositeMap.put("BOITIER_A", boitierPmComposite); //$NON-NLS-1$
    pmComposite.setListeBoitierPM(boitierCompositeMap);
    mockRES_PmCompositeLireUnParReferencePmBytel(RetourFactoryForTU.createOkRetour(), pmComposite, "GHYUI890"); //$NON-NLS-1$

    // MOCK RES.pmCompositeLireUnParReferencePmBytel (portPM Cible) - not needed, already in cache

    // MOCK RES.oltCompositeLireUn
    OltComposite oltCompositeCible = createOLTCompositeFromPositionPortPm(1, 1, "OLT2000", Collections.singleton("XGSPON"), 0); //$NON-NLS-1$ //$NON-NLS-2$
    mockRES_OltCompositeLireUn(RetourFactoryForTU.createOkRetour(), oltCompositeCible, "OLT2000"); //$NON-NLS-1$

    // MOCK RES.oltCompositeLireUn
    Retour retourKO = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, "Error in RES"); //$NON-NLS-1$
    mockRES_OltCompositeLireUn(retourKO, null, "OLT2001"); //$NON-NLS-1$

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPostProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Récupération du résultat de la requête
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    // Tests de retours
    Assert.assertEquals(ErrorCode.KO_00503, response.getErrorCode());
    Assert.assertEquals("Error in RES", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegConsts.SERVICE_TIERS_INDISPONIBLE, reponseactual.getError());
  }

  /**
   * <b>Cas de test: </b> Verif Migration - Modification techno impossible (<br/>
   * <b>Entrées:</b> Requête ok<br/>
   * <b>Attendu:</b> ResponseErreur 403 - ACCES_REFUSE - SfpTechnologieCompatible du Port Pon ne peut etre modifiee dans
   * la modification du portPm<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_POST_BL100_NOK_006() throws Throwable
  {
    // Preparation de la requête
    PositionPortPm posPortPmMigreSrc = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmMigreCible = new PositionPortPm(2, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    MigrationPortPm migrationPortPm = new MigrationPortPm(posPortPmMigreSrc, posPortPmMigreCible);
    LienPortPon lienPortPonAjout = new LienPortPon("OLT2000", 2, 1); //$NON-NLS-1$
    PanneauPm panneauPm = new PanneauPm("PANNEAU_D"); //$NON-NLS-1$
    BoitierPm boitierPm = new BoitierPm("BOITIER_D", "ABCD123"); //$NON-NLS-1$ //$NON-NLS-2$
    AjoutPortPm ajoutPortPm = new AjoutPortPm(posPortPmMigreCible, Collections.singletonList(lienPortPonAjout), panneauPm, boitierPm);
    PositionPortPm posPortPmSupp = new PositionPortPm(1, "PANNEAU_E", "BOITIER_E", "GHYUI893"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    SuppressionPortPm suppPortPm = new SuppressionPortPm(Collections.singletonList(posPortPmSupp));
    PositionPortPm posPortPmModif = new PositionPortPm(1, "PANNEAU_F", "BOITIER_F", "GHYUI894"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    LienPortPon lienPortPonModifSrc = new LienPortPon("OLT2000", 2, 1); //$NON-NLS-1$
    LienPortPon lienPortPonModifCible = new LienPortPon("OLT2000", 2, 3); //$NON-NLS-1$
    ModificationPortPm modifPortPm = new ModificationPortPm(posPortPmModif, Collections.singletonList(lienPortPonModifSrc), Collections.singletonList(lienPortPonModifCible));
    PE0529_PostRequest creationRequest = new PE0529_PostRequest("PON128", Arrays.asList("PM", "OLT")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    creationRequest.setNumeroGCR("GCR-12345678"); //$NON-NLS-1$
    creationRequest.setMigrationsPortsPm(Collections.singletonList(migrationPortPm));
    creationRequest.setAjoutsPortsPm(Collections.singletonList(ajoutPortPm));
    creationRequest.setSuppressionsPortsPm(Collections.singletonList(suppPortPm));
    creationRequest.setModificationsPortsPm(Collections.singletonList(modifPortPm));
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePostRequest(creationRequest, headers);

    // MOCK RES.ressourceLireUn
    Ressource ressource = new RessourcePortPM("LIBRE", "GHYUI893", "BOITIER_E", "PANNEAU_E", 1); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource, "GHYUI893||BOITIER_E||PANNEAU_E||1", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    // MOCK RES.pmCompositeLireUnParReferencePmBytel (portPM Src)
    PMComposite pmComposite = new PMComposite();
    pmComposite.setReferencePmBytel("GHYUI890"); //$NON-NLS-1$
    LienPortPMPon lienPortPMPon = new LienPortPMPon("OPERATIONNEL", new PortPonId("OLT2000", 1, 1)); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, LienPortPMPon> lienPortPMPonMap = new HashMap<>();
    lienPortPMPonMap.put("OLT2000-1-1", lienPortPMPon); //$NON-NLS-1$
    PortPM portPmComposite = new PortPM(1, "OPERATIONNEL", lienPortPMPonMap); //$NON-NLS-1$

    LienPortPMPon lienPortPMPon2 = new LienPortPMPon("OPERATIONNEL", new PortPonId("OLT2001", 1, 1)); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, LienPortPMPon> lienPortPMPonMap2 = new HashMap<>();
    lienPortPMPonMap2.put("OLT2001-1-1", lienPortPMPon2); //$NON-NLS-1$

    PortPM portPmComposite2 = new PortPM(2, "OPERATIONNEL", lienPortPMPonMap2); //$NON-NLS-1$
    Map<Integer, PortPM> portCompositeMap = new HashMap<>();
    portCompositeMap.put(1, portPmComposite);
    portCompositeMap.put(2, portPmComposite2);
    PanneauPM panneauPMComposite = new PanneauPM("PANNEAU_A", "OPERATIONNEL", portCompositeMap); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, PanneauPM> panneauCompositeMap = new HashMap<>();
    panneauCompositeMap.put("PANNEAU_A", panneauPMComposite); //$NON-NLS-1$
    BoitierPM boitierPmComposite = new BoitierPM("BOITIER_A", "OPERATIONNEL", panneauCompositeMap); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, BoitierPM> boitierCompositeMap = new HashMap<>();
    boitierCompositeMap.put("BOITIER_A", boitierPmComposite); //$NON-NLS-1$
    pmComposite.setListeBoitierPM(boitierCompositeMap);
    mockRES_PmCompositeLireUnParReferencePmBytel(RetourFactoryForTU.createOkRetour(), pmComposite, "GHYUI890"); //$NON-NLS-1$

    // MOCK RES.pmCompositeLireUnParReferencePmBytel (portPM Cible) - not needed, already in cache

    // MOCK RES.oltCompositeLireUn
    OltComposite oltCompositeSrc = createOLTCompositeFromPositionPortPm(1, 1, "OLT2000", Collections.singleton("XGSPON"), 0); //$NON-NLS-1$ //$NON-NLS-2$
    mockRES_OltCompositeLireUn(RetourFactoryForTU.createOkRetour(), oltCompositeSrc, "OLT2000"); //$NON-NLS-1$

    // MOCK RES.oltCompositeLireUn
    OltComposite oltCompositeCible = createOLTCompositeFromPositionPortPm(1, 1, "OLT2001", Collections.singleton("GPON"), 0); //$NON-NLS-1$ //$NON-NLS-2$
    mockRES_OltCompositeLireUn(RetourFactoryForTU.createOkRetour(), oltCompositeCible, "OLT2001"); //$NON-NLS-1$

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPostProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Récupération du résultat de la requête
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    // Tests de retours
    Assert.assertEquals(ErrorCode.KO_00403, response.getErrorCode());
    Assert.assertEquals("SfpTechnologieCompatible du Port Pon ne peut pas être modifiée dans la modification du portPm Source: GHYUI890-BOITIER_A-PANNEAU_A-1.", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegSpiritConsts.ACCES_REFUSE, reponseactual.getError());
  }

  /**
   * <b>Cas de test: </b> Verif Migration - Port Cible pas dans PM et RES.oltCompositeLireUn KO(<br/>
   * <b>Entrées:</b> Requête ok<br/>
   * <b>Attendu:</b> ResponseErreur 503 - SERVICE_TIERS_INDISPONIBLE - Error in RESs<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_POST_BL100_NOK_007() throws Throwable
  {
    // Preparation de la requête
    PositionPortPm posPortPmMigreSrc = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmMigreCible = new PositionPortPm(2, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    MigrationPortPm migrationPortPm = new MigrationPortPm(posPortPmMigreSrc, posPortPmMigreCible);
    LienPortPon lienPortPonAjout = new LienPortPon("OLT2001", 2, 1); //$NON-NLS-1$
    PanneauPm panneauPm = new PanneauPm("PANNEAU_D"); //$NON-NLS-1$
    BoitierPm boitierPm = new BoitierPm("BOITIER_D", "ABCD123"); //$NON-NLS-1$ //$NON-NLS-2$
    AjoutPortPm ajoutPortPm = new AjoutPortPm(posPortPmMigreCible, Collections.singletonList(lienPortPonAjout), panneauPm, boitierPm);
    PositionPortPm posPortPmSupp = new PositionPortPm(1, "PANNEAU_E", "BOITIER_E", "GHYUI893"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    SuppressionPortPm suppPortPm = new SuppressionPortPm(Collections.singletonList(posPortPmSupp));
    PositionPortPm posPortPmModif = new PositionPortPm(1, "PANNEAU_F", "BOITIER_F", "GHYUI894"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    LienPortPon lienPortPonModifSrc = new LienPortPon("OLT2000", 2, 1); //$NON-NLS-1$
    LienPortPon lienPortPonModifCible = new LienPortPon("OLT2000", 2, 3); //$NON-NLS-1$
    ModificationPortPm modifPortPm = new ModificationPortPm(posPortPmModif, Collections.singletonList(lienPortPonModifSrc), Collections.singletonList(lienPortPonModifCible));
    PE0529_PostRequest creationRequest = new PE0529_PostRequest("PON128", Arrays.asList("PM", "OLT")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    creationRequest.setNumeroGCR("GCR-12345678"); //$NON-NLS-1$
    creationRequest.setMigrationsPortsPm(Collections.singletonList(migrationPortPm));
    creationRequest.setAjoutsPortsPm(Collections.singletonList(ajoutPortPm));
    creationRequest.setSuppressionsPortsPm(Collections.singletonList(suppPortPm));
    creationRequest.setModificationsPortsPm(Collections.singletonList(modifPortPm));
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePostRequest(creationRequest, headers);

    // MOCK RES.ressourceLireUn
    Ressource ressource = new RessourcePortPM("LIBRE", "GHYUI893", "BOITIER_E", "PANNEAU_E", 1); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource, "GHYUI893||BOITIER_E||PANNEAU_E||1", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    // MOCK RES.pmCompositeLireUnParReferencePmBytel (portPM Src)
    PMComposite pmComposite = new PMComposite();
    pmComposite.setReferencePmBytel("GHYUI890"); //$NON-NLS-1$
    LienPortPMPon lienPortPMPon = new LienPortPMPon("OPERATIONNEL", new PortPonId("OLT2000", 1, 1)); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, LienPortPMPon> lienPortPMPonMap = new HashMap<>();
    lienPortPMPonMap.put("OLT2000-1-1", lienPortPMPon); //$NON-NLS-1$
    PortPM portPmComposite = new PortPM(1, "OPERATIONNEL", lienPortPMPonMap); //$NON-NLS-1$
    Map<Integer, PortPM> portCompositeMap = new HashMap<>();
    portCompositeMap.put(1, portPmComposite);
    PanneauPM panneauPMComposite = new PanneauPM("PANNEAU_A", "OPERATIONNEL", portCompositeMap); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, PanneauPM> panneauCompositeMap = new HashMap<>();
    panneauCompositeMap.put("PANNEAU_A", panneauPMComposite); //$NON-NLS-1$
    BoitierPM boitierPmComposite = new BoitierPM("BOITIER_A", "OPERATIONNEL", panneauCompositeMap); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, BoitierPM> boitierCompositeMap = new HashMap<>();
    boitierCompositeMap.put("BOITIER_A", boitierPmComposite); //$NON-NLS-1$
    pmComposite.setListeBoitierPM(boitierCompositeMap);
    mockRES_PmCompositeLireUnParReferencePmBytel(RetourFactoryForTU.createOkRetour(), pmComposite, "GHYUI890"); //$NON-NLS-1$

    // MOCK RES.pmCompositeLireUnParReferencePmBytel (portPM Cible) - not needed, already in cache

    // MOCK RES.oltCompositeLireUn
    OltComposite oltCompositeSrc = createOLTCompositeFromPositionPortPm(1, 1, "OLT2000", Collections.singleton("XGSPON"), 0); //$NON-NLS-1$ //$NON-NLS-2$
    mockRES_OltCompositeLireUn(RetourFactoryForTU.createOkRetour(), oltCompositeSrc, "OLT2000"); //$NON-NLS-1$

    // MOCK RES.oltCompositeLireUn
    Retour retourKO = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, "Error in RES"); //$NON-NLS-1$
    mockRES_OltCompositeLireUn(retourKO, null, "OLT2001"); //$NON-NLS-1$

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPostProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Récupération du résultat de la requête
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    // Tests de retours
    Assert.assertEquals(ErrorCode.KO_00503, response.getErrorCode());
    Assert.assertEquals("Error in RES", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegConsts.SERVICE_TIERS_INDISPONIBLE, reponseactual.getError());
  }

  /**
   * <b>Cas de test: </b> Verif Migration - Port Cible pas dans PM et LienPortPon ni dans OLT et AjoutsPortsPon(<br/>
   * <b>Entrées:</b> Requête ok<br/>
   * <b>Attendu:</b> ResponseErreur CAT4 - DONNEE_INCONNUE - Objet liensPortPon introuvable dans le referentiel SPIRIT
   * et dans ajoutsPortsPon<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_POST_BL100_NOK_008() throws Throwable
  {
    // Preparation de la requête
    PositionPortPm posPortPmMigreSrc = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmMigreCible = new PositionPortPm(2, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    MigrationPortPm migrationPortPm = new MigrationPortPm(posPortPmMigreSrc, posPortPmMigreCible);
    LienPortPon lienPortPonAjout = new LienPortPon("OLT2001", 2, 1); //$NON-NLS-1$
    PanneauPm panneauPm = new PanneauPm("PANNEAU_D"); //$NON-NLS-1$
    BoitierPm boitierPm = new BoitierPm("BOITIER_D", "ABCD123"); //$NON-NLS-1$ //$NON-NLS-2$
    AjoutPortPm ajoutPortPm = new AjoutPortPm(posPortPmMigreCible, Collections.singletonList(lienPortPonAjout), panneauPm, boitierPm);
    PositionPortPm posPortPmSupp = new PositionPortPm(1, "PANNEAU_E", "BOITIER_E", "GHYUI893"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    SuppressionPortPm suppPortPm = new SuppressionPortPm(Collections.singletonList(posPortPmSupp));
    PositionPortPm posPortPmModif = new PositionPortPm(1, "PANNEAU_F", "BOITIER_F", "GHYUI894"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    LienPortPon lienPortPonModifSrc = new LienPortPon("OLT2000", 2, 1); //$NON-NLS-1$
    LienPortPon lienPortPonModifCible = new LienPortPon("OLT2000", 2, 3); //$NON-NLS-1$
    ModificationPortPm modifPortPm = new ModificationPortPm(posPortPmModif, Collections.singletonList(lienPortPonModifSrc), Collections.singletonList(lienPortPonModifCible));
    PE0529_PostRequest creationRequest = new PE0529_PostRequest("PON128", Arrays.asList("PM", "OLT")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    creationRequest.setNumeroGCR("GCR-12345678"); //$NON-NLS-1$
    creationRequest.setMigrationsPortsPm(Collections.singletonList(migrationPortPm));
    creationRequest.setAjoutsPortsPm(Collections.singletonList(ajoutPortPm));
    creationRequest.setSuppressionsPortsPm(Collections.singletonList(suppPortPm));
    creationRequest.setModificationsPortsPm(Collections.singletonList(modifPortPm));
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePostRequest(creationRequest, headers);

    // MOCK RES.ressourceLireUn
    Ressource ressource = new RessourcePortPM("LIBRE", "GHYUI893", "BOITIER_E", "PANNEAU_E", 1); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource, "GHYUI893||BOITIER_E||PANNEAU_E||1", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    // MOCK RES.pmCompositeLireUnParReferencePmBytel (portPM Src)
    PMComposite pmComposite = new PMComposite();
    pmComposite.setReferencePmBytel("GHYUI890"); //$NON-NLS-1$
    LienPortPMPon lienPortPMPon = new LienPortPMPon("OPERATIONNEL", new PortPonId("OLT2000", 1, 1)); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, LienPortPMPon> lienPortPMPonMap = new HashMap<>();
    lienPortPMPonMap.put("OLT2000-1-1", lienPortPMPon); //$NON-NLS-1$
    PortPM portPmComposite = new PortPM(1, "OPERATIONNEL", lienPortPMPonMap); //$NON-NLS-1$
    Map<Integer, PortPM> portCompositeMap = new HashMap<>();
    portCompositeMap.put(1, portPmComposite);
    PanneauPM panneauPMComposite = new PanneauPM("PANNEAU_A", "OPERATIONNEL", portCompositeMap); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, PanneauPM> panneauCompositeMap = new HashMap<>();
    panneauCompositeMap.put("PANNEAU_A", panneauPMComposite); //$NON-NLS-1$
    BoitierPM boitierPmComposite = new BoitierPM("BOITIER_A", "OPERATIONNEL", panneauCompositeMap); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, BoitierPM> boitierCompositeMap = new HashMap<>();
    boitierCompositeMap.put("BOITIER_A", boitierPmComposite); //$NON-NLS-1$
    pmComposite.setListeBoitierPM(boitierCompositeMap);
    mockRES_PmCompositeLireUnParReferencePmBytel(RetourFactoryForTU.createOkRetour(), pmComposite, "GHYUI890"); //$NON-NLS-1$

    // MOCK RES.pmCompositeLireUnParReferencePmBytel (portPM Cible) - not needed, already in cache

    // MOCK RES.oltCompositeLireUn
    OltComposite oltCompositeSrc = createOLTCompositeFromPositionPortPm(1, 1, "OLT2000", Collections.singleton("XGSPON"), 0); //$NON-NLS-1$ //$NON-NLS-2$
    mockRES_OltCompositeLireUn(RetourFactoryForTU.createOkRetour(), oltCompositeSrc, "OLT2000"); //$NON-NLS-1$

    // MOCK RES.oltCompositeLireUn
    OltComposite oltCompositeCible = createOLTCompositeFromPositionPortPm(1, 1, "OLT2001", Collections.singleton("GPON"), 0); //$NON-NLS-1$ //$NON-NLS-2$
    mockRES_OltCompositeLireUn(RetourFactoryForTU.createOkRetour(), oltCompositeCible, "OLT2001"); //$NON-NLS-1$

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPostProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Récupération du résultat de la requête
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    // Tests de retours
    Assert.assertEquals(ErrorCode.KO_00404, response.getErrorCode());
    Assert.assertEquals("L'objet lienPortPon OLT2001-2-1 est introuvable dans le referentiel SPIRIT et dans les ajoutsPortsPon.", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegConsts.DONNEE_INCONNUE, reponseactual.getError());
  }

  /**
   * <b>Cas de test: </b> Verif Migration - Port Cible pas dans PM et LienPortPon dans OLT mais Migration techno
   * impossible(<br/>
   * <b>Entrées:</b> Requête ok<br/>
   * <b>Attendu:</b> ResponseErreur 403 - ACCES_REFUSE - SfpTechnologieCompatible du Port Pon ne peut etre modifiee dans
   * la modification du portPm<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_POST_BL100_NOK_009() throws Throwable
  {
    // Preparation de la requête
    PositionPortPm posPortPmMigreSrc = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmMigreCible = new PositionPortPm(2, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    MigrationPortPm migrationPortPm = new MigrationPortPm(posPortPmMigreSrc, posPortPmMigreCible);

    LienPortPon lienPortPonAjout = new LienPortPon("OLT2000", 2, 1); //$NON-NLS-1$
    PanneauPm panneauPm = new PanneauPm("PANNEAU_D"); //$NON-NLS-1$
    BoitierPm boitierPm = new BoitierPm("BOITIER_D", "ABCD123"); //$NON-NLS-1$ //$NON-NLS-2$
    AjoutPortPm ajoutPortPm = new AjoutPortPm(posPortPmMigreCible, Collections.singletonList(lienPortPonAjout), panneauPm, boitierPm);

    PositionPortPm posPortPmSupp = new PositionPortPm(1, "PANNEAU_E", "BOITIER_E", "GHYUI893"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    SuppressionPortPm suppPortPm = new SuppressionPortPm(Collections.singletonList(posPortPmSupp));

    PositionPortPm posPortPmModif = new PositionPortPm(1, "PANNEAU_F", "BOITIER_F", "GHYUI894"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    LienPortPon lienPortPonModifSrc = new LienPortPon("OLT2000", 2, 1); //$NON-NLS-1$
    LienPortPon lienPortPonModifCible = new LienPortPon("OLT2000", 2, 3); //$NON-NLS-1$
    ModificationPortPm modifPortPm = new ModificationPortPm(posPortPmModif, Collections.singletonList(lienPortPonModifSrc), Collections.singletonList(lienPortPonModifCible));

    PE0529_PostRequest creationRequest = new PE0529_PostRequest("PON128", Arrays.asList("PM", "OLT")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    creationRequest.setNumeroGCR("GCR-12345678"); //$NON-NLS-1$
    creationRequest.setMigrationsPortsPm(Collections.singletonList(migrationPortPm));
    creationRequest.setAjoutsPortsPm(Collections.singletonList(ajoutPortPm));
    creationRequest.setSuppressionsPortsPm(Collections.singletonList(suppPortPm));
    creationRequest.setModificationsPortsPm(Collections.singletonList(modifPortPm));

    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePostRequest(creationRequest, headers);

    // MOCK RES.ressourceLireUn
    Ressource ressource = new RessourcePortPM("LIBRE", "GHYUI893", "BOITIER_E", "PANNEAU_E", 1); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource, "GHYUI893||BOITIER_E||PANNEAU_E||1", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    // MOCK RES.pmCompositeLireUnParReferencePmBytel (portPM Src)
    PMComposite pmComposite = new PMComposite();
    pmComposite.setReferencePmBytel("GHYUI890"); //$NON-NLS-1$
    LienPortPMPon lienPortPMPon = new LienPortPMPon("OPERATIONNEL", new PortPonId("OLT2000", 1, 1)); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, LienPortPMPon> lienPortPMPonMap = new HashMap<>();
    lienPortPMPonMap.put("OLT2000-1-1", lienPortPMPon); //$NON-NLS-1$
    PortPM portPmComposite = new PortPM(1, "OPERATIONNEL", lienPortPMPonMap); //$NON-NLS-1$
    Map<Integer, PortPM> portCompositeMap = new HashMap<>();
    portCompositeMap.put(1, portPmComposite);
    LienPortPMPon lienPortPMPon2 = new LienPortPMPon("OPERATIONNEL", new PortPonId("OLT2001", 1, 1)); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, LienPortPMPon> lienPortPMPonMap2 = new HashMap<>();
    lienPortPMPonMap2.put("OLT2001-1-1", lienPortPMPon2); //$NON-NLS-1$
    PortPM portPmComposite2 = new PortPM(2, "OPERATIONNEL", lienPortPMPonMap2); //$NON-NLS-1$
    portCompositeMap.put(2, portPmComposite2);
    PanneauPM panneauPMComposite = new PanneauPM("PANNEAU_A", "OPERATIONNEL", portCompositeMap); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, PanneauPM> panneauCompositeMap = new HashMap<>();
    panneauCompositeMap.put("PANNEAU_A", panneauPMComposite); //$NON-NLS-1$
    BoitierPM boitierPmComposite = new BoitierPM("BOITIER_A", "OPERATIONNEL", panneauCompositeMap); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, BoitierPM> boitierCompositeMap = new HashMap<>();
    boitierCompositeMap.put("BOITIER_A", boitierPmComposite); //$NON-NLS-1$
    pmComposite.setListeBoitierPM(boitierCompositeMap);
    mockRES_PmCompositeLireUnParReferencePmBytel(RetourFactoryForTU.createOkRetour(), pmComposite, "GHYUI890"); //$NON-NLS-1$

    // MOCK RES.pmCompositeLireUnParReferencePmBytel (portPM Cible) - not needed, already in cache

    // MOCK RES.oltCompositeLireUn
    OltComposite oltCompositeSrc = createOLTCompositeFromPositionPortPm(1, 1, "OLT2000", Collections.singleton("XGSPON"), 0); //$NON-NLS-1$ //$NON-NLS-2$
    mockRES_OltCompositeLireUn(RetourFactoryForTU.createOkRetour(), oltCompositeSrc, "OLT2000"); //$NON-NLS-1$

    // MOCK RES.oltCompositeLireUn
    OltComposite oltCompositeCible = createOLTCompositeFromPositionPortPm(1, 2, "OLT2001", Collections.singleton("GPON"), 0); //$NON-NLS-1$ //$NON-NLS-2$
    mockRES_OltCompositeLireUn(RetourFactoryForTU.createOkRetour(), oltCompositeCible, "OLT2001"); //$NON-NLS-1$

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPostProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Récupération du résultat de la requête
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    // Tests de retours
    Assert.assertEquals(ErrorCode.KO_00403, response.getErrorCode());
    Assert.assertEquals("SfpTechnologieCompatible du Port Pon ne peut pas être modifiée dans la modification du portPm Source: GHYUI890-BOITIER_A-PANNEAU_A-1.", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegSpiritConsts.ACCES_REFUSE, reponseactual.getError());
  }

  /**
   * <b>Cas de test: </b> Verif Migration - Port Cible pas dans PM et LienPortPon dans AjoutsPortsPon mais Migration
   * techno impossible(<br/>
   * <b>Entrées:</b> Requête ok<br/>
   * <b>Attendu:</b> ResponseErreur 403 - ACCES_REFUSE - SfpTechnologieCompatible du Port Pon ne peut etre modifiee dans
   * la modification du portPm<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_POST_BL100_NOK_010() throws Throwable
  {
    // Preparation de la requête
    PositionPortPm posPortPmMigreSrc = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmMigreCible = new PositionPortPm(2, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    MigrationPortPm migrationPortPm = new MigrationPortPm(posPortPmMigreSrc, posPortPmMigreCible);
    LienPortPon lienPortPonAjout = new LienPortPon("OLT2000", 2, 1); //$NON-NLS-1$
    PanneauPm panneauPm = new PanneauPm("PANNEAU_D"); //$NON-NLS-1$
    BoitierPm boitierPm = new BoitierPm("BOITIER_D", "ABCD123"); //$NON-NLS-1$ //$NON-NLS-2$
    AjoutPortPm ajoutPortPm = new AjoutPortPm(posPortPmMigreCible, Collections.singletonList(lienPortPonAjout), panneauPm, boitierPm);
    PositionPortPm posPortPmSupp = new PositionPortPm(1, "PANNEAU_E", "BOITIER_E", "GHYUI893"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    SuppressionPortPm suppPortPm = new SuppressionPortPm(Collections.singletonList(posPortPmSupp));
    PositionPortPm posPortPmModif = new PositionPortPm(1, "PANNEAU_F", "BOITIER_F", "GHYUI894"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    LienPortPon lienPortPonModifSrc = new LienPortPon("OLT2000", 2, 1); //$NON-NLS-1$
    LienPortPon lienPortPonModifCible = new LienPortPon("OLT2000", 2, 3); //$NON-NLS-1$
    ModificationPortPm modifPortPm = new ModificationPortPm(posPortPmModif, Collections.singletonList(lienPortPonModifSrc), Collections.singletonList(lienPortPonModifCible));
    PositionPortPon posPortPonAjout = new PositionPortPon(1, 2, "OLT2000"); //$NON-NLS-1$
    CartePon cartePon = new CartePon("2", "carte"); //$NON-NLS-1$ //$NON-NLS-2$
    AjoutPortPon ajoutPortPon = new AjoutPortPon(posPortPonAjout, Collections.singletonList("GPON"), 0, cartePon); //$NON-NLS-1$
    PE0529_PostRequest creationRequest = new PE0529_PostRequest("PON128", Arrays.asList("PM", "OLT")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    creationRequest.setNumeroGCR("GCR-12345678"); //$NON-NLS-1$
    creationRequest.setMigrationsPortsPm(Collections.singletonList(migrationPortPm));
    creationRequest.setAjoutsPortsPm(Collections.singletonList(ajoutPortPm));
    creationRequest.setSuppressionsPortsPm(Collections.singletonList(suppPortPm));
    creationRequest.setModificationsPortsPm(Collections.singletonList(modifPortPm));
    creationRequest.setAjoutsPortsPon(Collections.singletonList(ajoutPortPon));
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePostRequest(creationRequest, headers);

    // MOCK RES.ressourceLireUn
    Ressource ressource = new RessourcePortPM("LIBRE", "GHYUI893", "BOITIER_E", "PANNEAU_E", 1); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource, "GHYUI893||BOITIER_E||PANNEAU_E||1", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    // MOCK RES.pmCompositeLireUnParReferencePmBytel (portPM Src)
    PMComposite pmComposite = new PMComposite();
    pmComposite.setReferencePmBytel("GHYUI890"); //$NON-NLS-1$
    LienPortPMPon lienPortPMPon = new LienPortPMPon("OPERATIONNEL", new PortPonId("OLT2000", 1, 1)); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, LienPortPMPon> lienPortPMPonMap = new HashMap<>();
    lienPortPMPonMap.put("OLT2000-1-1", lienPortPMPon); //$NON-NLS-1$
    PortPM portPmComposite = new PortPM(1, "OPERATIONNEL", lienPortPMPonMap); //$NON-NLS-1$
    Map<Integer, PortPM> portCompositeMap = new HashMap<>();
    portCompositeMap.put(1, portPmComposite);
    PanneauPM panneauPMComposite = new PanneauPM("PANNEAU_A", "OPERATIONNEL", portCompositeMap); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, PanneauPM> panneauCompositeMap = new HashMap<>();
    panneauCompositeMap.put("PANNEAU_A", panneauPMComposite); //$NON-NLS-1$
    BoitierPM boitierPmComposite = new BoitierPM("BOITIER_A", "OPERATIONNEL", panneauCompositeMap); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, BoitierPM> boitierCompositeMap = new HashMap<>();
    boitierCompositeMap.put("BOITIER_A", boitierPmComposite); //$NON-NLS-1$
    pmComposite.setListeBoitierPM(boitierCompositeMap);
    mockRES_PmCompositeLireUnParReferencePmBytel(RetourFactoryForTU.createOkRetour(), pmComposite, "GHYUI890"); //$NON-NLS-1$

    // MOCK RES.pmCompositeLireUnParReferencePmBytel (portPM Cible) - not needed, already in cache

    // MOCK RES.oltCompositeLireUn
    OltComposite oltCompositeSrc = createOLTCompositeFromPositionPortPm(1, 1, "OLT2000", Collections.singleton("XGSPON"), 0); //$NON-NLS-1$ //$NON-NLS-2$
    mockRES_OltCompositeLireUn(RetourFactoryForTU.createOkRetour(), oltCompositeSrc, "OLT2000"); //$NON-NLS-1$

    // MOCK RES.oltCompositeLireUn - not needed, already in cache

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPostProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Récupération du résultat de la requête
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    // Tests de retours
    Assert.assertEquals(ErrorCode.KO_00403, response.getErrorCode());
    Assert.assertEquals("SfpTechnologieCompatible du Port Pon ne peut pas être modifiée dans la modification du portPm Source: GHYUI890-BOITIER_A-PANNEAU_A-1.", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegSpiritConsts.ACCES_REFUSE, reponseactual.getError());
  }

  /**
   * <b>Cas de test: </b> Verif Modification - RES.pmCompositeLireUnParReferencePmBytel(<br/>
   * <b>Entrées:</b> Requête ok<br/>
   * <b>Attendu:</b> ResponseErreur 503 - SERVICE_TIERS_INDISPONIBLE - Error in RESs<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_POST_BL100_NOK_011() throws Throwable
  {
    // Preparation de la requête
    PositionPortPm posPortPmMigreSrc = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmMigreCible = new PositionPortPm(2, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    MigrationPortPm migrationPortPm = new MigrationPortPm(posPortPmMigreSrc, posPortPmMigreCible);
    LienPortPon lienPortPonAjout = new LienPortPon("OLT2000", 2, 1); //$NON-NLS-1$
    PanneauPm panneauPm = new PanneauPm("PANNEAU_D"); //$NON-NLS-1$
    BoitierPm boitierPm = new BoitierPm("BOITIER_D", "ABCD123"); //$NON-NLS-1$ //$NON-NLS-2$
    AjoutPortPm ajoutPortPm = new AjoutPortPm(posPortPmMigreCible, Collections.singletonList(lienPortPonAjout), panneauPm, boitierPm);
    PositionPortPm posPortPmSupp = new PositionPortPm(1, "PANNEAU_E", "BOITIER_E", "GHYUI893"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    SuppressionPortPm suppPortPm = new SuppressionPortPm(Collections.singletonList(posPortPmSupp));
    PositionPortPm posPortPmModif = new PositionPortPm(1, "PANNEAU_B", "BOITIER_B", "GHYUI891"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    LienPortPon lienPortPonModifSrc = new LienPortPon("OLT2000", 2, 1); //$NON-NLS-1$
    LienPortPon lienPortPonModifCible = new LienPortPon("OLT2000", 2, 3); //$NON-NLS-1$
    ModificationPortPm modifPortPm = new ModificationPortPm(posPortPmModif, Collections.singletonList(lienPortPonModifSrc), Collections.singletonList(lienPortPonModifCible));
    PE0529_PostRequest creationRequest = new PE0529_PostRequest("PON128", Arrays.asList("PM", "OLT")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    creationRequest.setNumeroGCR("GCR-12345678"); //$NON-NLS-1$
    creationRequest.setMigrationsPortsPm(Collections.singletonList(migrationPortPm));
    creationRequest.setAjoutsPortsPm(Collections.singletonList(ajoutPortPm));
    creationRequest.setSuppressionsPortsPm(Collections.singletonList(suppPortPm));
    creationRequest.setModificationsPortsPm(Collections.singletonList(modifPortPm));
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePostRequest(creationRequest, headers);

    // MOCK RES.ressourceLireUn
    Ressource ressource = new RessourcePortPM("LIBRE", "GHYUI893", "BOITIER_E", "PANNEAU_E", 1); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource, "GHYUI893||BOITIER_E||PANNEAU_E||1", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    // MOCK RES.pmCompositeLireUnParReferencePmBytel (portPM Src)
    PMComposite pmComposite = new PMComposite();
    pmComposite.setReferencePmBytel("GHYUI890"); //$NON-NLS-1$
    LienPortPMPon lienPortPMPon = new LienPortPMPon("OPERATIONNEL", new PortPonId("OLT2000", 1, 1)); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, LienPortPMPon> lienPortPMPonMap = new HashMap<>();
    lienPortPMPonMap.put("OLT2000-1-1", lienPortPMPon); //$NON-NLS-1$
    PortPM portPmComposite = new PortPM(1, "OPERATIONNEL", lienPortPMPonMap); //$NON-NLS-1$
    PortPM portPmComposite2 = new PortPM(2, "OPERATIONNEL", lienPortPMPonMap); //$NON-NLS-1$
    Map<Integer, PortPM> portCompositeMap = new HashMap<>();
    portCompositeMap.put(1, portPmComposite);
    portCompositeMap.put(2, portPmComposite2);
    PanneauPM panneauPMComposite = new PanneauPM("PANNEAU_A", "OPERATIONNEL", portCompositeMap); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, PanneauPM> panneauCompositeMap = new HashMap<>();
    panneauCompositeMap.put("PANNEAU_A", panneauPMComposite); //$NON-NLS-1$
    BoitierPM boitierPmComposite = new BoitierPM("BOITIER_A", "OPERATIONNEL", panneauCompositeMap); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, BoitierPM> boitierCompositeMap = new HashMap<>();
    boitierCompositeMap.put("BOITIER_A", boitierPmComposite); //$NON-NLS-1$
    pmComposite.setListeBoitierPM(boitierCompositeMap);
    mockRES_PmCompositeLireUnParReferencePmBytel(RetourFactoryForTU.createOkRetour(), pmComposite, "GHYUI890"); //$NON-NLS-1$

    // MOCK RES.pmCompositeLireUnParReferencePmBytel (portPM Cible) - not needed, already in cache

    // MOCK RES.oltCompositeLireUn
    OltComposite oltCompositeSrc = createOLTCompositeFromPositionPortPm(1, 1, "OLT2000", Collections.singleton("XGSPON"), 0); //$NON-NLS-1$ //$NON-NLS-2$
    mockRES_OltCompositeLireUn(RetourFactoryForTU.createOkRetour(), oltCompositeSrc, "OLT2000"); //$NON-NLS-1$

    // MOCK RES.oltCompositeLireUn - not needed, already in cache

    // MOCK RES.pmCompositeLireUnParReferencePmBytel (portPM Cible)
    Retour retourKO = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, "Error in RES"); //$NON-NLS-1$
    mockRES_PmCompositeLireUnParReferencePmBytel(retourKO, null, "GHYUI891"); //$NON-NLS-1$

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPostProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Récupération du résultat de la requête
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    // Tests de retours
    Assert.assertEquals(ErrorCode.KO_00503, response.getErrorCode());
    Assert.assertEquals("Error in RES", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegConsts.SERVICE_TIERS_INDISPONIBLE, reponseactual.getError());
  }

  /**
   * <b>Cas de test: </b> Verif Modification - positionPortPon innexistant dans RES(<br/>
   * <b>Entrées:</b> Requête ok<br/>
   * <b>Attendu:</b> ResponseErreur 404 - DONNEE_INCONNUE - Objet PortPm introuvable dans le referentiel SPIRIT et dans
   * les ajoutsPortsPm<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_POST_BL100_NOK_012() throws Throwable
  {
    // Preparation de la requête
    PositionPortPm posPortPmMigreSrc = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmMigreCible = new PositionPortPm(2, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    MigrationPortPm migrationPortPm = new MigrationPortPm(posPortPmMigreSrc, posPortPmMigreCible);
    LienPortPon lienPortPonAjout = new LienPortPon("OLT2000", 2, 1); //$NON-NLS-1$
    PanneauPm panneauPm = new PanneauPm("PANNEAU_D"); //$NON-NLS-1$
    BoitierPm boitierPm = new BoitierPm("BOITIER_D", "ABCD123"); //$NON-NLS-1$ //$NON-NLS-2$
    AjoutPortPm ajoutPortPm = new AjoutPortPm(posPortPmMigreCible, Collections.singletonList(lienPortPonAjout), panneauPm, boitierPm);
    PositionPortPm posPortPmSupp = new PositionPortPm(1, "PANNEAU_E", "BOITIER_E", "GHYUI893"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    SuppressionPortPm suppPortPm = new SuppressionPortPm(Collections.singletonList(posPortPmSupp));
    PositionPortPm posPortPmModif = new PositionPortPm(1, "PANNEAU_B", "BOITIER_B", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    LienPortPon lienPortPonModifSrc = new LienPortPon("OLT2000", 2, 1); //$NON-NLS-1$
    LienPortPon lienPortPonModifCible = new LienPortPon("OLT2000", 2, 3); //$NON-NLS-1$
    ModificationPortPm modifPortPm = new ModificationPortPm(posPortPmModif, Collections.singletonList(lienPortPonModifSrc), Collections.singletonList(lienPortPonModifCible));
    PE0529_PostRequest creationRequest = new PE0529_PostRequest("PON128", Arrays.asList("PM", "OLT")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    creationRequest.setNumeroGCR("GCR-12345678"); //$NON-NLS-1$
    creationRequest.setMigrationsPortsPm(Collections.singletonList(migrationPortPm));
    creationRequest.setAjoutsPortsPm(Collections.singletonList(ajoutPortPm));
    creationRequest.setSuppressionsPortsPm(Collections.singletonList(suppPortPm));
    creationRequest.setModificationsPortsPm(Collections.singletonList(modifPortPm));
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePostRequest(creationRequest, headers);

    // MOCK RES.ressourceLireUn
    Ressource ressource = new RessourcePortPM("LIBRE", "GHYUI893", "BOITIER_E", "PANNEAU_E", 1); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource, "GHYUI893||BOITIER_E||PANNEAU_E||1", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    // MOCK RES.pmCompositeLireUnParReferencePmBytel (portPM Src)
    PMComposite pmComposite = new PMComposite();
    pmComposite.setReferencePmBytel("GHYUI890"); //$NON-NLS-1$
    LienPortPMPon lienPortPMPon = new LienPortPMPon("OPERATIONNEL", new PortPonId("OLT2000", 1, 1)); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, LienPortPMPon> lienPortPMPonMap = new HashMap<>();
    lienPortPMPonMap.put("OLT2000-1-1", lienPortPMPon); //$NON-NLS-1$
    PortPM portPmComposite = new PortPM(1, "OPERATIONNEL", lienPortPMPonMap); //$NON-NLS-1$
    PortPM portPmComposite2 = new PortPM(2, "OPERATIONNEL", lienPortPMPonMap); //$NON-NLS-1$
    Map<Integer, PortPM> portCompositeMap = new HashMap<>();
    portCompositeMap.put(1, portPmComposite);
    portCompositeMap.put(2, portPmComposite2);
    PanneauPM panneauPMComposite = new PanneauPM("PANNEAU_A", "OPERATIONNEL", portCompositeMap); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, PanneauPM> panneauCompositeMap = new HashMap<>();
    panneauCompositeMap.put("PANNEAU_A", panneauPMComposite); //$NON-NLS-1$
    BoitierPM boitierPmComposite = new BoitierPM("BOITIER_A", "OPERATIONNEL", panneauCompositeMap); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, BoitierPM> boitierCompositeMap = new HashMap<>();
    boitierCompositeMap.put("BOITIER_A", boitierPmComposite); //$NON-NLS-1$
    pmComposite.setListeBoitierPM(boitierCompositeMap);
    mockRES_PmCompositeLireUnParReferencePmBytel(RetourFactoryForTU.createOkRetour(), pmComposite, "GHYUI890"); //$NON-NLS-1$

    // MOCK RES.pmCompositeLireUnParReferencePmBytel (portPM Cible) - not needed, already in cache

    // MOCK RES.oltCompositeLireUn
    OltComposite oltCompositeSrc = createOLTCompositeFromPositionPortPm(1, 1, "OLT2000", Collections.singleton("XGSPON"), 0); //$NON-NLS-1$ //$NON-NLS-2$
    mockRES_OltCompositeLireUn(RetourFactoryForTU.createOkRetour(), oltCompositeSrc, "OLT2000"); //$NON-NLS-1$

    // MOCK RES.oltCompositeLireUn - not needed, already in cache

    // MOCK RES.pmCompositeLireUnParReferencePmBytel (portPM Cible) - not needed, already in cache

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPostProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Récupération du résultat de la requête
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    // Tests de retours
    Assert.assertEquals(ErrorCode.KO_00404, response.getErrorCode());
    Assert.assertEquals("L'objet PortPm GHYUI890-BOITIER_B-PANNEAU_B-1 est introuvable dans le referentiel SPIRIT et dans les ajoutsPortsPm.", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegConsts.DONNEE_INCONNUE, reponseactual.getError());
  }

  /**
   * <b>Cas de test: </b> Verif Modification - lienPortPon src - RES.oltCompositeLireUn NOK(<br/>
   * <b>Entrées:</b> Requête ok<br/>
   * <b>Attendu:</b> ResponseErreur 503 - SERVICE_TIERS_INDISPONIBLE - Error in RES<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_POST_BL100_NOK_013() throws Throwable
  {
    // Preparation de la requête
    PositionPortPm posPortPmMigreSrc = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmMigreCible = new PositionPortPm(2, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    MigrationPortPm migrationPortPm = new MigrationPortPm(posPortPmMigreSrc, posPortPmMigreCible);
    LienPortPon lienPortPonAjout = new LienPortPon("OLT2000", 2, 1); //$NON-NLS-1$
    PanneauPm panneauPm = new PanneauPm("PANNEAU_D"); //$NON-NLS-1$
    BoitierPm boitierPm = new BoitierPm("BOITIER_D", "ABCD123"); //$NON-NLS-1$ //$NON-NLS-2$
    AjoutPortPm ajoutPortPm = new AjoutPortPm(posPortPmMigreCible, Collections.singletonList(lienPortPonAjout), panneauPm, boitierPm);
    PositionPortPm posPortPmSupp = new PositionPortPm(1, "PANNEAU_E", "BOITIER_E", "GHYUI893"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    SuppressionPortPm suppPortPm = new SuppressionPortPm(Collections.singletonList(posPortPmSupp));
    PositionPortPm posPortPmModif = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    LienPortPon lienPortPonModifSrc = new LienPortPon("OLT2000", 2, 1); //$NON-NLS-1$
    LienPortPon lienPortPonModifCible = new LienPortPon("OLT2000", 2, 3); //$NON-NLS-1$
    ModificationPortPm modifPortPm = new ModificationPortPm(posPortPmModif, Collections.singletonList(lienPortPonModifSrc), Collections.singletonList(lienPortPonModifCible));
    PE0529_PostRequest creationRequest = new PE0529_PostRequest("PON128", Arrays.asList("PM", "OLT")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    creationRequest.setNumeroGCR("GCR-12345678"); //$NON-NLS-1$
    creationRequest.setMigrationsPortsPm(Collections.singletonList(migrationPortPm));
    creationRequest.setAjoutsPortsPm(Collections.singletonList(ajoutPortPm));
    creationRequest.setSuppressionsPortsPm(Collections.singletonList(suppPortPm));
    creationRequest.setModificationsPortsPm(Collections.singletonList(modifPortPm));
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePostRequest(creationRequest, headers);

    // MOCK RES.ressourceLireUn
    Ressource ressource = new RessourcePortPM("LIBRE", "GHYUI893", "BOITIER_E", "PANNEAU_E", 1); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource, "GHYUI893||BOITIER_E||PANNEAU_E||1", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    // MOCK RES.pmCompositeLireUnParReferencePmBytel (portPM Src)
    PMComposite pmComposite = new PMComposite();
    pmComposite.setReferencePmBytel("GHYUI890"); //$NON-NLS-1$
    LienPortPMPon lienPortPMPon = new LienPortPMPon("OPERATIONNEL", new PortPonId("OLT2000", 1, 1)); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, LienPortPMPon> lienPortPMPonMap = new HashMap<>();
    lienPortPMPonMap.put("OLT2000-1-1", lienPortPMPon); //$NON-NLS-1$
    LienPortPMPon lienPortPMPon2 = new LienPortPMPon("OPERATIONNEL", new PortPonId("OLT2001", 1, 1)); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, LienPortPMPon> lienPortPMPonMap2 = new HashMap<>();
    lienPortPMPonMap2.put("OLT2001-1-1", lienPortPMPon2); //$NON-NLS-1$
    PortPM portPmComposite = new PortPM(1, "OPERATIONNEL", lienPortPMPonMap); //$NON-NLS-1$
    PortPM portPmComposite2 = new PortPM(2, "OPERATIONNEL", lienPortPMPonMap2); //$NON-NLS-1$
    Map<Integer, PortPM> portCompositeMap = new HashMap<>();
    portCompositeMap.put(1, portPmComposite);
    portCompositeMap.put(2, portPmComposite2);
    PanneauPM panneauPMComposite = new PanneauPM("PANNEAU_A", "OPERATIONNEL", portCompositeMap); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, PanneauPM> panneauCompositeMap = new HashMap<>();
    panneauCompositeMap.put("PANNEAU_A", panneauPMComposite); //$NON-NLS-1$
    BoitierPM boitierPmComposite = new BoitierPM("BOITIER_A", "OPERATIONNEL", panneauCompositeMap); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, BoitierPM> boitierCompositeMap = new HashMap<>();
    boitierCompositeMap.put("BOITIER_A", boitierPmComposite); //$NON-NLS-1$
    pmComposite.setListeBoitierPM(boitierCompositeMap);
    mockRES_PmCompositeLireUnParReferencePmBytel(RetourFactoryForTU.createOkRetour(), pmComposite, "GHYUI890"); //$NON-NLS-1$

    // MOCK RES.pmCompositeLireUnParReferencePmBytel (portPM Cible) - not needed, already in cache

    // MOCK RES.oltCompositeLireUn
    OltComposite oltCompositeSrc = createOLTCompositeFromPositionPortPm(1, 1, "OLT2000", Collections.singleton("XGSPON"), 0); //$NON-NLS-1$ //$NON-NLS-2$
    mockRES_OltCompositeLireUn(RetourFactoryForTU.createOkRetour(), oltCompositeSrc, "OLT2000"); //$NON-NLS-1$

    // MOCK RES.oltCompositeLireUn - not needed, already in cache

    // MOCK RES.pmCompositeLireUnParReferencePmBytel - not needed, already in cache

    // MOCK RES.oltCompositeLireUn
    Retour retourKO = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, "Error in RES"); //$NON-NLS-1$
    mockRES_OltCompositeLireUn(retourKO, null, "OLT2001"); //$NON-NLS-1$

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPostProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Récupération du résultat de la requête
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    // Tests de retours
    Assert.assertEquals(ErrorCode.KO_00503, response.getErrorCode());
    Assert.assertEquals("Error in RES", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegConsts.SERVICE_TIERS_INDISPONIBLE, reponseactual.getError());
  }

  /**
   * <b>Cas de test: </b> Verif Modification - lienPortPon cible - RES.oltCompositeLireUn NOK(<br/>
   * <b>Entrées:</b> Requête ok<br/>
   * <b>Attendu:</b> ResponseErreur 503 - SERVICE_TIERS_INDISPONIBLE - Error in RES<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_POST_BL100_NOK_014() throws Throwable
  {
    // Preparation de la requête
    PositionPortPm posPortPmMigreSrc = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmMigreCible = new PositionPortPm(2, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    MigrationPortPm migrationPortPm = new MigrationPortPm(posPortPmMigreSrc, posPortPmMigreCible);
    LienPortPon lienPortPonAjout = new LienPortPon("OLT2000", 2, 1); //$NON-NLS-1$
    PanneauPm panneauPm = new PanneauPm("PANNEAU_D"); //$NON-NLS-1$
    BoitierPm boitierPm = new BoitierPm("BOITIER_D", "ABCD123"); //$NON-NLS-1$ //$NON-NLS-2$
    AjoutPortPm ajoutPortPm = new AjoutPortPm(posPortPmMigreCible, Collections.singletonList(lienPortPonAjout), panneauPm, boitierPm);
    PositionPortPm posPortPmSupp = new PositionPortPm(1, "PANNEAU_E", "BOITIER_E", "GHYUI893"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    SuppressionPortPm suppPortPm = new SuppressionPortPm(Collections.singletonList(posPortPmSupp));
    PositionPortPm posPortPmModif = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    LienPortPon lienPortPonModifSrc = new LienPortPon("OLT2000", 2, 1); //$NON-NLS-1$
    LienPortPon lienPortPonModifCible = new LienPortPon("OLT2001", 2, 3); //$NON-NLS-1$
    ModificationPortPm modifPortPm = new ModificationPortPm(posPortPmModif, Collections.singletonList(lienPortPonModifSrc), Collections.singletonList(lienPortPonModifCible));
    PE0529_PostRequest creationRequest = new PE0529_PostRequest("PON128", Arrays.asList("PM", "OLT")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    creationRequest.setNumeroGCR("GCR-12345678"); //$NON-NLS-1$
    creationRequest.setMigrationsPortsPm(Collections.singletonList(migrationPortPm));
    creationRequest.setAjoutsPortsPm(Collections.singletonList(ajoutPortPm));
    creationRequest.setSuppressionsPortsPm(Collections.singletonList(suppPortPm));
    creationRequest.setModificationsPortsPm(Collections.singletonList(modifPortPm));
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePostRequest(creationRequest, headers);

    // MOCK RES.ressourceLireUn
    Ressource ressource = new RessourcePortPM("LIBRE", "GHYUI893", "BOITIER_E", "PANNEAU_E", 1); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource, "GHYUI893||BOITIER_E||PANNEAU_E||1", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    // MOCK RES.pmCompositeLireUnParReferencePmBytel (portPM Src)
    PMComposite pmComposite = new PMComposite();
    pmComposite.setReferencePmBytel("GHYUI890"); //$NON-NLS-1$
    LienPortPMPon lienPortPMPon = new LienPortPMPon("OPERATIONNEL", new PortPonId("OLT2000", 1, 1)); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, LienPortPMPon> lienPortPMPonMap = new HashMap<>();
    lienPortPMPonMap.put("OLT2000-1-1", lienPortPMPon); //$NON-NLS-1$
    PortPM portPmComposite = new PortPM(1, "OPERATIONNEL", lienPortPMPonMap); //$NON-NLS-1$
    PortPM portPmComposite2 = new PortPM(2, "OPERATIONNEL", lienPortPMPonMap); //$NON-NLS-1$
    Map<Integer, PortPM> portCompositeMap = new HashMap<>();
    portCompositeMap.put(1, portPmComposite);
    portCompositeMap.put(2, portPmComposite2);
    PanneauPM panneauPMComposite = new PanneauPM("PANNEAU_A", "OPERATIONNEL", portCompositeMap); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, PanneauPM> panneauCompositeMap = new HashMap<>();
    panneauCompositeMap.put("PANNEAU_A", panneauPMComposite); //$NON-NLS-1$
    BoitierPM boitierPmComposite = new BoitierPM("BOITIER_A", "OPERATIONNEL", panneauCompositeMap); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, BoitierPM> boitierCompositeMap = new HashMap<>();
    boitierCompositeMap.put("BOITIER_A", boitierPmComposite); //$NON-NLS-1$
    pmComposite.setListeBoitierPM(boitierCompositeMap);
    mockRES_PmCompositeLireUnParReferencePmBytel(RetourFactoryForTU.createOkRetour(), pmComposite, "GHYUI890"); //$NON-NLS-1$

    // MOCK RES.pmCompositeLireUnParReferencePmBytel (portPM Cible) - not needed, already in cache

    // MOCK RES.oltCompositeLireUn
    OltComposite oltCompositeSrc = createOLTCompositeFromPositionPortPm(1, 1, "OLT2000", Collections.singleton("XGSPON"), 0); //$NON-NLS-1$ //$NON-NLS-2$
    mockRES_OltCompositeLireUn(RetourFactoryForTU.createOkRetour(), oltCompositeSrc, "OLT2000"); //$NON-NLS-1$

    // MOCK RES.oltCompositeLireUn - not needed, already in cache

    // MOCK RES.pmCompositeLireUnParReferencePmBytel - not needed, already in cache

    // MOCK RES.oltCompositeLireUn - src - not needed, already in cache

    // MOCK RES.oltCompositeLireUn - cible
    Retour retourKO = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, "Error in RES"); //$NON-NLS-1$
    mockRES_OltCompositeLireUn(retourKO, null, "OLT2001"); //$NON-NLS-1$

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPostProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Récupération du résultat de la requête
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    // Tests de retours
    Assert.assertEquals(ErrorCode.KO_00503, response.getErrorCode());
    Assert.assertEquals("Error in RES", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegConsts.SERVICE_TIERS_INDISPONIBLE, reponseactual.getError());
  }

  /**
   * <b>Cas de test: </b> Verif Modification - Modification techno impossible(<br/>
   * <b>Entrées:</b> Requête ok<br/>
   * <b>Attendu:</b> ResponseErreur 403 - ACCES_REFUSE - SfpTechnologieCompatible du Port Pon ne peut etre modifiee dans
   * la modification du portPm<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_POST_BL100_NOK_015() throws Throwable
  {
    // Preparation de la requête
    PositionPortPm posPortPmMigreSrc = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmMigreCible = new PositionPortPm(2, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    MigrationPortPm migrationPortPm = new MigrationPortPm(posPortPmMigreSrc, posPortPmMigreCible);
    LienPortPon lienPortPonAjout = new LienPortPon("OLT2000", 2, 1); //$NON-NLS-1$
    PanneauPm panneauPm = new PanneauPm("PANNEAU_D"); //$NON-NLS-1$
    BoitierPm boitierPm = new BoitierPm("BOITIER_D", "ABCD123"); //$NON-NLS-1$ //$NON-NLS-2$
    AjoutPortPm ajoutPortPm = new AjoutPortPm(posPortPmMigreCible, Collections.singletonList(lienPortPonAjout), panneauPm, boitierPm);
    PositionPortPm posPortPmSupp = new PositionPortPm(1, "PANNEAU_E", "BOITIER_E", "GHYUI893"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    SuppressionPortPm suppPortPm = new SuppressionPortPm(Collections.singletonList(posPortPmSupp));
    PositionPortPm posPortPmModif = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    LienPortPon lienPortPonModifSrc = new LienPortPon("OLT2000", 1, 1); //$NON-NLS-1$
    LienPortPon lienPortPonModifCible = new LienPortPon("OLT2001", 2, 3); //$NON-NLS-1$
    ModificationPortPm modifPortPm = new ModificationPortPm(posPortPmModif, Collections.singletonList(lienPortPonModifSrc), Collections.singletonList(lienPortPonModifCible));
    PE0529_PostRequest creationRequest = new PE0529_PostRequest("PON128", Arrays.asList("PM", "OLT")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    creationRequest.setNumeroGCR("GCR-12345678"); //$NON-NLS-1$
    creationRequest.setMigrationsPortsPm(Collections.singletonList(migrationPortPm));
    creationRequest.setAjoutsPortsPm(Collections.singletonList(ajoutPortPm));
    creationRequest.setSuppressionsPortsPm(Collections.singletonList(suppPortPm));
    creationRequest.setModificationsPortsPm(Collections.singletonList(modifPortPm));
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePostRequest(creationRequest, headers);

    // MOCK RES.ressourceLireUn
    Ressource ressource = new RessourcePortPM("LIBRE", "GHYUI893", "BOITIER_E", "PANNEAU_E", 1); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource, "GHYUI893||BOITIER_E||PANNEAU_E||1", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    // MOCK RES.pmCompositeLireUnParReferencePmBytel (portPM Src)
    PMComposite pmComposite = new PMComposite();
    pmComposite.setReferencePmBytel("GHYUI890"); //$NON-NLS-1$
    LienPortPMPon lienPortPMPon = new LienPortPMPon("OPERATIONNEL", new PortPonId("OLT2000", 1, 1)); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, LienPortPMPon> lienPortPMPonMap = new HashMap<>();
    lienPortPMPonMap.put("OLT2000-1-1", lienPortPMPon); //$NON-NLS-1$
    PortPM portPmComposite = new PortPM(1, "OPERATIONNEL", lienPortPMPonMap); //$NON-NLS-1$
    PortPM portPmComposite2 = new PortPM(2, "OPERATIONNEL", lienPortPMPonMap); //$NON-NLS-1$
    Map<Integer, PortPM> portCompositeMap = new HashMap<>();
    portCompositeMap.put(1, portPmComposite);
    portCompositeMap.put(2, portPmComposite2);
    PanneauPM panneauPMComposite = new PanneauPM("PANNEAU_A", "OPERATIONNEL", portCompositeMap); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, PanneauPM> panneauCompositeMap = new HashMap<>();
    panneauCompositeMap.put("PANNEAU_A", panneauPMComposite); //$NON-NLS-1$
    BoitierPM boitierPmComposite = new BoitierPM("BOITIER_A", "OPERATIONNEL", panneauCompositeMap); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, BoitierPM> boitierCompositeMap = new HashMap<>();
    boitierCompositeMap.put("BOITIER_A", boitierPmComposite); //$NON-NLS-1$
    pmComposite.setListeBoitierPM(boitierCompositeMap);
    mockRES_PmCompositeLireUnParReferencePmBytel(RetourFactoryForTU.createOkRetour(), pmComposite, "GHYUI890"); //$NON-NLS-1$

    // MOCK RES.pmCompositeLireUnParReferencePmBytel (portPM Cible) - not needed, already in cache

    // MOCK RES.oltCompositeLireUn
    OltComposite oltCompositeSrc = createOLTCompositeFromPositionPortPm(1, 1, "OLT2000", Collections.singleton("XGSPON"), 0); //$NON-NLS-1$ //$NON-NLS-2$
    mockRES_OltCompositeLireUn(RetourFactoryForTU.createOkRetour(), oltCompositeSrc, "OLT2000"); //$NON-NLS-1$

    // MOCK RES.oltCompositeLireUn - not needed, already in cache

    // MOCK RES.pmCompositeLireUnParReferencePmBytel - not needed, already in cache

    // MOCK RES.oltCompositeLireUn - src - not needed, already in cache

    // MOCK RES.oltCompositeLireUn - cible
    OltComposite oltCompositeCibleModif = createOLTCompositeFromPositionPortPm(3, 2, "OLT2001", Collections.singleton("GPON"), 0); //$NON-NLS-1$ //$NON-NLS-2$
    mockRES_OltCompositeLireUn(RetourFactoryForTU.createOkRetour(), oltCompositeCibleModif, "OLT2001"); //$NON-NLS-1$

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPostProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Récupération du résultat de la requête
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    // Tests de retours
    Assert.assertEquals(ErrorCode.KO_00403, response.getErrorCode());
    Assert.assertEquals("SfpTechnologieCompatible du Port Pon ne peut pas être modifiée dans la modification du portPm Source: GHYUI890-BOITIER_A-PANNEAU_A-1.", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegSpiritConsts.ACCES_REFUSE, reponseactual.getError());
  }

  /**
   * <b>Cas de test: </b> Verif Ajouts - RES.oltCompositeLireUn KO(<br/>
   * <b>Entrées:</b> Requête ok<br/>
   * <b>Attendu:</b> ResponseErreur 503 - SERVICE_TIERS_INDISPONIBLE - Error in RES<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_POST_BL100_NOK_016() throws Throwable
  {
    // Preparation de la requête
    PositionPortPm posPortPmMigreSrc = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmMigreCible = new PositionPortPm(2, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    MigrationPortPm migrationPortPm = new MigrationPortPm(posPortPmMigreSrc, posPortPmMigreCible);
    LienPortPon lienPortPonAjout = new LienPortPon("OLT2001", 2, 1); //$NON-NLS-1$
    PanneauPm panneauPm = new PanneauPm("PANNEAU_D"); //$NON-NLS-1$
    BoitierPm boitierPm = new BoitierPm("BOITIER_D", "ABCD123"); //$NON-NLS-1$ //$NON-NLS-2$
    AjoutPortPm ajoutPortPm = new AjoutPortPm(posPortPmMigreCible, Collections.singletonList(lienPortPonAjout), panneauPm, boitierPm);
    PositionPortPm posPortPmSupp = new PositionPortPm(1, "PANNEAU_E", "BOITIER_E", "GHYUI893"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    SuppressionPortPm suppPortPm = new SuppressionPortPm(Collections.singletonList(posPortPmSupp));
    PositionPortPm posPortPmModif = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    LienPortPon lienPortPonModifSrc = new LienPortPon("OLT2000", 2, 1); //$NON-NLS-1$
    LienPortPon lienPortPonModifCible = new LienPortPon("OLT2000", 2, 3); //$NON-NLS-1$
    ModificationPortPm modifPortPm = new ModificationPortPm(posPortPmModif, Collections.singletonList(lienPortPonModifSrc), Collections.singletonList(lienPortPonModifCible));
    PE0529_PostRequest creationRequest = new PE0529_PostRequest("PON128", Arrays.asList("PM", "OLT")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    creationRequest.setNumeroGCR("GCR-12345678"); //$NON-NLS-1$
    creationRequest.setMigrationsPortsPm(Collections.singletonList(migrationPortPm));
    creationRequest.setAjoutsPortsPm(Collections.singletonList(ajoutPortPm));
    creationRequest.setSuppressionsPortsPm(Collections.singletonList(suppPortPm));
    creationRequest.setModificationsPortsPm(Collections.singletonList(modifPortPm));
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePostRequest(creationRequest, headers);

    // MOCK RES.ressourceLireUn
    Ressource ressource = new RessourcePortPM("LIBRE", "GHYUI893", "BOITIER_E", "PANNEAU_E", 1); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource, "GHYUI893||BOITIER_E||PANNEAU_E||1", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    // MOCK RES.pmCompositeLireUnParReferencePmBytel (portPM Src)
    PMComposite pmComposite = new PMComposite();
    pmComposite.setReferencePmBytel("GHYUI890"); //$NON-NLS-1$
    LienPortPMPon lienPortPMPon = new LienPortPMPon("OPERATIONNEL", new PortPonId("OLT2000", 1, 1)); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, LienPortPMPon> lienPortPMPonMap = new HashMap<>();
    lienPortPMPonMap.put("OLT2000-1-1", lienPortPMPon); //$NON-NLS-1$
    PortPM portPmComposite = new PortPM(1, "OPERATIONNEL", lienPortPMPonMap); //$NON-NLS-1$
    PortPM portPmComposite2 = new PortPM(2, "OPERATIONNEL", lienPortPMPonMap); //$NON-NLS-1$
    Map<Integer, PortPM> portCompositeMap = new HashMap<>();
    portCompositeMap.put(1, portPmComposite);
    portCompositeMap.put(2, portPmComposite2);
    PanneauPM panneauPMComposite = new PanneauPM("PANNEAU_A", "OPERATIONNEL", portCompositeMap); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, PanneauPM> panneauCompositeMap = new HashMap<>();
    panneauCompositeMap.put("PANNEAU_A", panneauPMComposite); //$NON-NLS-1$
    BoitierPM boitierPmComposite = new BoitierPM("BOITIER_A", "OPERATIONNEL", panneauCompositeMap); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, BoitierPM> boitierCompositeMap = new HashMap<>();
    boitierCompositeMap.put("BOITIER_A", boitierPmComposite); //$NON-NLS-1$
    pmComposite.setListeBoitierPM(boitierCompositeMap);
    mockRES_PmCompositeLireUnParReferencePmBytel(RetourFactoryForTU.createOkRetour(), pmComposite, "GHYUI890"); //$NON-NLS-1$

    // MOCK RES.pmCompositeLireUnParReferencePmBytel (portPM Cible) - not needed, already in cache

    // MOCK RES.oltCompositeLireUn
    OltComposite oltCompositeSrc = createOLTCompositeFromPositionPortPm(1, 1, "OLT2000", Collections.singleton("XGSPON"), 0); //$NON-NLS-1$ //$NON-NLS-2$
    PortPON portPonComposite = new PortPON(1, "OK", Collections.emptySet(), 0); //$NON-NLS-1$
    Map<Integer, PortPON> portPonMap = new HashMap<>();
    portPonMap.put(3, portPonComposite);
    CartePON cartePonComposite = new CartePON(2, "modeleCarte", "OK"); //$NON-NLS-1$ //$NON-NLS-2$
    cartePonComposite.setListePortPON(portPonMap);
    oltCompositeSrc.getListeCartePON().put(2, cartePonComposite);
    mockRES_OltCompositeLireUn(RetourFactoryForTU.createOkRetour(), oltCompositeSrc, "OLT2000"); //$NON-NLS-1$

    // MOCK RES.oltCompositeLireUn - not needed, already in cache

    // MOCK RES.pmCompositeLireUnParReferencePmBytel - not needed, already in cache

    // MOCK RES.oltCompositeLireUn - src - not needed, already in cache

    // MOCK RES.oltCompositeLireUn - cible - not needed, already in cache

    // MOCK RES.oltCompositeLireUn - ajout
    Retour retourKO = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, "Error in RES"); //$NON-NLS-1$
    mockRES_OltCompositeLireUn(retourKO, null, "OLT2001"); //$NON-NLS-1$

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPostProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Récupération du résultat de la requête
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    // Tests de retours
    Assert.assertEquals(ErrorCode.KO_00503, response.getErrorCode());
    Assert.assertEquals("Error in RES", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegConsts.SERVICE_TIERS_INDISPONIBLE, reponseactual.getError());
  }

  /**
   * <b>Cas de test: </b> Verif Ajouts - lienPortPon ni dans OLT ni ajoutsPortPon(<br/>
   * <b>Entrées:</b> Requête ok<br/>
   * <b>Attendu:</b> ResponseErreur 404 - DONNEE_INCONNUE - objet lienPortPon introuvable dans le referentiel SPIRIT et
   * dans les ajoutsPortsPon<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_POST_BL100_NOK_017() throws Throwable
  {
    // Preparation de la requête
    PositionPortPm posPortPmMigreSrc = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmMigreCible = new PositionPortPm(2, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    MigrationPortPm migrationPortPm = new MigrationPortPm(posPortPmMigreSrc, posPortPmMigreCible);
    LienPortPon lienPortPonAjout = new LienPortPon("OLT2000", 2, 1); //$NON-NLS-1$
    PanneauPm panneauPm = new PanneauPm("PANNEAU_D"); //$NON-NLS-1$
    BoitierPm boitierPm = new BoitierPm("BOITIER_D", "ABCD123"); //$NON-NLS-1$ //$NON-NLS-2$
    AjoutPortPm ajoutPortPm = new AjoutPortPm(posPortPmMigreCible, Collections.singletonList(lienPortPonAjout), panneauPm, boitierPm);
    PositionPortPm posPortPmSupp = new PositionPortPm(1, "PANNEAU_E", "BOITIER_E", "GHYUI893"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    SuppressionPortPm suppPortPm = new SuppressionPortPm(Collections.singletonList(posPortPmSupp));
    PositionPortPm posPortPmModif = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    LienPortPon lienPortPonModifSrc = new LienPortPon("OLT2000", 2, 1); //$NON-NLS-1$
    LienPortPon lienPortPonModifCible = new LienPortPon("OLT2000", 2, 3); //$NON-NLS-1$
    ModificationPortPm modifPortPm = new ModificationPortPm(posPortPmModif, Collections.singletonList(lienPortPonModifSrc), Collections.singletonList(lienPortPonModifCible));
    PE0529_PostRequest creationRequest = new PE0529_PostRequest("PON128", Arrays.asList("PM", "OLT")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    creationRequest.setNumeroGCR("GCR-12345678"); //$NON-NLS-1$
    creationRequest.setMigrationsPortsPm(Collections.singletonList(migrationPortPm));
    creationRequest.setAjoutsPortsPm(Collections.singletonList(ajoutPortPm));
    creationRequest.setSuppressionsPortsPm(Collections.singletonList(suppPortPm));
    creationRequest.setModificationsPortsPm(Collections.singletonList(modifPortPm));
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePostRequest(creationRequest, headers);

    // MOCK RES.ressourceLireUn
    Ressource ressource = new RessourcePortPM("LIBRE", "GHYUI893", "BOITIER_E", "PANNEAU_E", 1); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource, "GHYUI893||BOITIER_E||PANNEAU_E||1", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    // MOCK RES.pmCompositeLireUnParReferencePmBytel (portPM Src)
    PMComposite pmComposite = new PMComposite();
    pmComposite.setReferencePmBytel("GHYUI890"); //$NON-NLS-1$
    LienPortPMPon lienPortPMPon = new LienPortPMPon("OPERATIONNEL", new PortPonId("OLT2000", 1, 1)); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, LienPortPMPon> lienPortPMPonMap = new HashMap<>();
    lienPortPMPonMap.put("OLT2000-1-1", lienPortPMPon); //$NON-NLS-1$
    PortPM portPmComposite = new PortPM(1, "OPERATIONNEL", lienPortPMPonMap); //$NON-NLS-1$
    PortPM portPmComposite2 = new PortPM(2, "OPERATIONNEL", lienPortPMPonMap); //$NON-NLS-1$
    Map<Integer, PortPM> portCompositeMap = new HashMap<>();
    portCompositeMap.put(1, portPmComposite);
    portCompositeMap.put(2, portPmComposite2);
    PanneauPM panneauPMComposite = new PanneauPM("PANNEAU_A", "OPERATIONNEL", portCompositeMap); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, PanneauPM> panneauCompositeMap = new HashMap<>();
    panneauCompositeMap.put("PANNEAU_A", panneauPMComposite); //$NON-NLS-1$
    BoitierPM boitierPmComposite = new BoitierPM("BOITIER_A", "OPERATIONNEL", panneauCompositeMap); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, BoitierPM> boitierCompositeMap = new HashMap<>();
    boitierCompositeMap.put("BOITIER_A", boitierPmComposite); //$NON-NLS-1$
    pmComposite.setListeBoitierPM(boitierCompositeMap);
    mockRES_PmCompositeLireUnParReferencePmBytel(RetourFactoryForTU.createOkRetour(), pmComposite, "GHYUI890"); //$NON-NLS-1$

    // MOCK RES.pmCompositeLireUnParReferencePmBytel (portPM Cible) - not needed, already in cache

    // MOCK RES.oltCompositeLireUn
    Set<String> technos = Collections.singleton("XGSPON"); //$NON-NLS-1$
    OltComposite oltCompositeSrc = createOLTCompositeFromPositionPortPm(1, 1, "OLT2000", technos, 0); //$NON-NLS-1$ //$NON-NLS-2$

    PortPON portPonComposite1 = new PortPON(1, "OK", technos, 0); //$NON-NLS-1$
    SurchargePortPON surchargePortPonComposite1 = new SurchargePortPON(0, technos, "OK"); //$NON-NLS-1$
    portPonComposite1.setSurchargePortPON(surchargePortPonComposite1);
    Map<Integer, PortPON> portPonMap = new HashMap<>();
    portPonMap.put(1, portPonComposite1);
    CartePON cartePonComposite2 = new CartePON(2, "modeleCarte", "OK"); //$NON-NLS-1$ //$NON-NLS-2$
    cartePonComposite2.setListePortPON(portPonMap);
    oltCompositeSrc.getListeCartePON().put(2, cartePonComposite2);

    mockRES_OltCompositeLireUn(RetourFactoryForTU.createOkRetour(), oltCompositeSrc, "OLT2000"); //$NON-NLS-1$

    // MOCK RES.oltCompositeLireUn - not needed, already in cache

    // MOCK RES.pmCompositeLireUnParReferencePmBytel - not needed, already in cache

    // MOCK RES.oltCompositeLireUn - src - not needed, already in cache

    // MOCK RES.oltCompositeLireUn - cible - not needed, already in cache

    // MOCK RES.oltCompositeLireUn - ajout - not needed, already in cache

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPostProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Récupération du résultat de la requête
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    // Tests de retours
    Assert.assertEquals(ErrorCode.KO_00404, response.getErrorCode());
    Assert.assertEquals("L'objet lienPortPon OLT2000-2-3 est introuvable dans le referentiel SPIRIT et dans les ajoutsPortsPon.", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegConsts.DONNEE_INCONNUE, reponseactual.getError());
  }

  /**
   * <b>Cas de test: Port PM à modifier avec un lien Port PON non existant dans RES</b> (<br/>
   * <b>Entrées:</b> Requête ok<br/>
   * <b>Attendu:</b> ResponseErreur 404 - DONNEE_INCONNUE - objet lienPortPon introuvable dans le referentiel SPIRIT et
   * dans les ajoutsPortsPoné<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_POST_BL100_NOK_018() throws Throwable
  {
    // Preparation de la requête
    PositionPortPm posPortPmMigreSrc = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmMigreCible = new PositionPortPm(2, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    MigrationPortPm migrationPortPm = new MigrationPortPm(posPortPmMigreSrc, posPortPmMigreCible);
    LienPortPon lienPortPonAjout = new LienPortPon("OLT2000", 2, 1); //$NON-NLS-1$
    PanneauPm panneauPm = new PanneauPm("PANNEAU_D"); //$NON-NLS-1$
    BoitierPm boitierPm = new BoitierPm("BOITIER_D", "ABCD123"); //$NON-NLS-1$ //$NON-NLS-2$
    AjoutPortPm ajoutPortPm = new AjoutPortPm(posPortPmMigreCible, Collections.singletonList(lienPortPonAjout), panneauPm, boitierPm);
    PositionPortPm posPortPmSupp = new PositionPortPm(1, "PANNEAU_E", "BOITIER_E", "GHYUI893"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    SuppressionPortPm suppPortPm = new SuppressionPortPm(Collections.singletonList(posPortPmSupp));
    PositionPortPm posPortPmModif = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    LienPortPon lienPortPonModifSrc = new LienPortPon("OLT2000", 2, 1); //$NON-NLS-1$
    LienPortPon lienPortPonModifCible = new LienPortPon("OLT2000", 2, 3); //$NON-NLS-1$
    ModificationPortPm modifPortPm = new ModificationPortPm(posPortPmModif, Collections.singletonList(lienPortPonModifSrc), Collections.singletonList(lienPortPonModifCible));
    PE0529_PostRequest creationRequest = new PE0529_PostRequest("PON128", Arrays.asList("PM", "OLT")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    creationRequest.setNumeroGCR("GCR-12345678"); //$NON-NLS-1$
    creationRequest.setMigrationsPortsPm(Collections.singletonList(migrationPortPm));
    creationRequest.setAjoutsPortsPm(Collections.singletonList(ajoutPortPm));
    creationRequest.setSuppressionsPortsPm(Collections.singletonList(suppPortPm));
    creationRequest.setModificationsPortsPm(Collections.singletonList(modifPortPm));
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePostRequest(creationRequest, headers);

    // MOCK RES.ressourceLireUn
    Ressource ressource = new RessourcePortPM("LIBRE", "GHYUI893", "BOITIER_E", "PANNEAU_E", 1); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource, "GHYUI893||BOITIER_E||PANNEAU_E||1", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    // MOCK RES.pmCompositeLireUnParReferencePmBytel (portPM Src)
    PMComposite pmComposite = new PMComposite();
    pmComposite.setReferencePmBytel("GHYUI890"); //$NON-NLS-1$
    LienPortPMPon lienPortPMPon = new LienPortPMPon("OPERATIONNEL", new PortPonId("OLT2000", 1, 1)); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, LienPortPMPon> lienPortPMPonMap = new HashMap<>();
    lienPortPMPonMap.put("OLT2000-1-1", lienPortPMPon); //$NON-NLS-1$
    PortPM portPmComposite = new PortPM(1, "OPERATIONNEL", lienPortPMPonMap); //$NON-NLS-1$
    PortPM portPmComposite2 = new PortPM(2, "OPERATIONNEL", lienPortPMPonMap); //$NON-NLS-1$
    Map<Integer, PortPM> portCompositeMap = new HashMap<>();
    portCompositeMap.put(1, portPmComposite);
    portCompositeMap.put(2, portPmComposite2);
    PanneauPM panneauPMComposite = new PanneauPM("PANNEAU_A", "OPERATIONNEL", portCompositeMap); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, PanneauPM> panneauCompositeMap = new HashMap<>();
    panneauCompositeMap.put("PANNEAU_A", panneauPMComposite); //$NON-NLS-1$
    BoitierPM boitierPmComposite = new BoitierPM("BOITIER_A", "OPERATIONNEL", panneauCompositeMap); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, BoitierPM> boitierCompositeMap = new HashMap<>();
    boitierCompositeMap.put("BOITIER_A", boitierPmComposite); //$NON-NLS-1$
    pmComposite.setListeBoitierPM(boitierCompositeMap);
    mockRES_PmCompositeLireUnParReferencePmBytel(RetourFactoryForTU.createOkRetour(), pmComposite, "GHYUI890"); //$NON-NLS-1$

    // MOCK RES.pmCompositeLireUnParReferencePmBytel (portPM Cible) - not needed, already in cache

    // MOCK RES.oltCompositeLireUn
    Set<String> technos = Collections.singleton("XGSPON"); //$NON-NLS-1$
    OltComposite oltCompositeSrc = createOLTCompositeFromPositionPortPm(1, 1, "OLT2000", technos, 0); //$NON-NLS-1$ //$NON-NLS-2$

    PortPON portPonComposite1 = new PortPON(1, "OK", technos, 0); //$NON-NLS-1$
    SurchargePortPON surchargePortPonComposite1 = new SurchargePortPON(0, technos, "OK"); //$NON-NLS-1$
    portPonComposite1.setSurchargePortPON(surchargePortPonComposite1);
    Map<Integer, PortPON> portPonMap = new HashMap<>();
    portPonMap.put(1, portPonComposite1);
    CartePON cartePonComposite2 = new CartePON(2, "modeleCarte", "OK"); //$NON-NLS-1$ //$NON-NLS-2$
    cartePonComposite2.setListePortPON(portPonMap);
    oltCompositeSrc.getListeCartePON().put(2, cartePonComposite2);

    mockRES_OltCompositeLireUn(RetourFactoryForTU.createOkRetour(), oltCompositeSrc, "OLT2000"); //$NON-NLS-1$

    // MOCK RES.oltCompositeLireUn - not needed, already in cache

    // MOCK RES.pmCompositeLireUnParReferencePmBytel - not needed, already in cache

    // MOCK RES.oltCompositeLireUn - src - not needed, already in cache

    // MOCK RES.oltCompositeLireUn - cible - not needed, already in cache

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPostProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Récupération du résultat de la requête
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    // Tests de retours
    Assert.assertEquals(ErrorCode.KO_00404, response.getErrorCode());
    Assert.assertEquals("L'objet lienPortPon OLT2000-2-3 est introuvable dans le referentiel SPIRIT et dans les ajoutsPortsPon.", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegConsts.DONNEE_INCONNUE, reponseactual.getError());
  }

  /**
   * <b>Cas de test: Modification du port pon impossible</b> (<br/>
   * <b>Entrées:</b> Requête ok<br/>
   * <b>Attendu:</b> ResponseErreur 403 - ACCES_REFUSE - SfpTechnologieCompatible du Port Pon ne peut etre modifiee
   * cause existance Clients avec debit garanti<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_POST_BL100_NOK_019() throws Throwable
  {
    // Preparation de la requête
    PositionPortPm posPortPmMigreSrc = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmMigreCible = new PositionPortPm(2, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    MigrationPortPm migrationPortPm = new MigrationPortPm(posPortPmMigreSrc, posPortPmMigreCible);
    LienPortPon lienPortPonAjout = new LienPortPon("OLT2000", 2, 1); //$NON-NLS-1$
    PanneauPm panneauPm = new PanneauPm("PANNEAU_D"); //$NON-NLS-1$
    BoitierPm boitierPm = new BoitierPm("BOITIER_D", "ABCD123"); //$NON-NLS-1$ //$NON-NLS-2$
    AjoutPortPm ajoutPortPm = new AjoutPortPm(posPortPmMigreCible, Collections.singletonList(lienPortPonAjout), panneauPm, boitierPm);
    PositionPortPm posPortPmSupp = new PositionPortPm(1, "PANNEAU_E", "BOITIER_E", "GHYUI893"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    SuppressionPortPm suppPortPm = new SuppressionPortPm(Collections.singletonList(posPortPmSupp));
    PositionPortPm posPortPmModif = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    LienPortPon lienPortPonModifSrc = new LienPortPon("OLT2000", 2, 1); //$NON-NLS-1$
    LienPortPon lienPortPonModifCible = new LienPortPon("OLT2000", 2, 3); //$NON-NLS-1$
    ModificationPortPm modifPortPm = new ModificationPortPm(posPortPmModif, Collections.singletonList(lienPortPonModifSrc), Collections.singletonList(lienPortPonModifCible));
    PositionPortPon posPortPonModif = new PositionPortPon(1, 1, "OLT2000"); //$NON-NLS-1$
    ModificationPortPon modifPortPon = new ModificationPortPon(posPortPonModif, Collections.singletonList("GPON")); //$NON-NLS-1$
    PE0529_PostRequest creationRequest = new PE0529_PostRequest("PON128", Arrays.asList("PM", "OLT")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    creationRequest.setNumeroGCR("GCR-12345678"); //$NON-NLS-1$
    creationRequest.setMigrationsPortsPm(Collections.singletonList(migrationPortPm));
    creationRequest.setAjoutsPortsPm(Collections.singletonList(ajoutPortPm));
    creationRequest.setSuppressionsPortsPm(Collections.singletonList(suppPortPm));
    creationRequest.setModificationsPortsPm(Collections.singletonList(modifPortPm));
    creationRequest.setModificationsPortsPon(Collections.singletonList(modifPortPon));
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePostRequest(creationRequest, headers);

    // MOCK RES.ressourceLireUn
    Ressource ressource = new RessourcePortPM("LIBRE", "GHYUI893", "BOITIER_E", "PANNEAU_E", 1); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource, "GHYUI893||BOITIER_E||PANNEAU_E||1", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    // MOCK RES.pmCompositeLireUnParReferencePmBytel (portPM Src)
    PMComposite pmComposite = new PMComposite();
    pmComposite.setReferencePmBytel("GHYUI890"); //$NON-NLS-1$
    LienPortPMPon lienPortPMPon = new LienPortPMPon("OPERATIONNEL", new PortPonId("OLT2000", 1, 1)); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, LienPortPMPon> lienPortPMPonMap = new HashMap<>();
    lienPortPMPonMap.put("OLT2000-1-1", lienPortPMPon); //$NON-NLS-1$
    PortPM portPmComposite = new PortPM(1, "OPERATIONNEL", lienPortPMPonMap); //$NON-NLS-1$
    PortPM portPmComposite2 = new PortPM(2, "OPERATIONNEL", lienPortPMPonMap); //$NON-NLS-1$
    Map<Integer, PortPM> portCompositeMap = new HashMap<>();
    portCompositeMap.put(1, portPmComposite);
    portCompositeMap.put(2, portPmComposite2);
    PanneauPM panneauPMComposite = new PanneauPM("PANNEAU_A", "OPERATIONNEL", portCompositeMap); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, PanneauPM> panneauCompositeMap = new HashMap<>();
    panneauCompositeMap.put("PANNEAU_A", panneauPMComposite); //$NON-NLS-1$
    BoitierPM boitierPmComposite = new BoitierPM("BOITIER_A", "OPERATIONNEL", panneauCompositeMap); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, BoitierPM> boitierCompositeMap = new HashMap<>();
    boitierCompositeMap.put("BOITIER_A", boitierPmComposite); //$NON-NLS-1$
    pmComposite.setListeBoitierPM(boitierCompositeMap);
    mockRES_PmCompositeLireUnParReferencePmBytel(RetourFactoryForTU.createOkRetour(), pmComposite, "GHYUI890"); //$NON-NLS-1$

    // MOCK RES.pmCompositeLireUnParReferencePmBytel (portPM Cible) - not needed, already in cache

    // MOCK RES.oltCompositeLireUn
    Set<String> technos = Collections.singleton("XGSPON"); //$NON-NLS-1$
    OltComposite oltCompositeSrc = createOLTCompositeFromPositionPortPm(1, 1, "OLT2000", technos, 10); //$NON-NLS-1$ //$NON-NLS-2$

    PortPON portPonComposite1 = new PortPON(1, "OK", technos, 0); //$NON-NLS-1$
    SurchargePortPON surchargePortPonComposite1 = new SurchargePortPON(0, technos, "OK"); //$NON-NLS-1$
    portPonComposite1.setSurchargePortPON(surchargePortPonComposite1);
    Map<Integer, PortPON> portPonMap = new HashMap<>();
    portPonMap.put(1, portPonComposite1);
    portPonMap.put(3, portPonComposite1);
    CartePON cartePonComposite2 = new CartePON(2, "modeleCarte", "OK"); //$NON-NLS-1$ //$NON-NLS-2$
    cartePonComposite2.setListePortPON(portPonMap);
    oltCompositeSrc.getListeCartePON().put(2, cartePonComposite2);

    mockRES_OltCompositeLireUn(RetourFactoryForTU.createOkRetour(), oltCompositeSrc, "OLT2000"); //$NON-NLS-1$

    // MOCK RES.oltCompositeLireUn - not needed, already in cache

    // MOCK RES.pmCompositeLireUnParReferencePmBytel - not needed, already in cache

    // MOCK RES.oltCompositeLireUn - src - not needed, already in cache

    // MOCK RES.oltCompositeLireUn - cible - not needed, already in cache

    // MOCK RES.oltCompositeLireUn - ajout - not needed, already in cache

    // MOCK RES.oltCompositeLireUn - not needed, already in cache

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPostProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Récupération du résultat de la requête
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    // Tests de retours
    Assert.assertEquals(ErrorCode.KO_00403, response.getErrorCode());
    Assert.assertEquals("SfpTechnologieCompatible du Port Pon OLT2000-1-1 ne peut pas être modifiée à cause de l'existance des Clients avec debit garanti.", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegSpiritConsts.ACCES_REFUSE, reponseactual.getError());
  }

  /**
   * <b>Cas de test: Suppression Port Pon - RES.oltCompositeLireUn NOK</b> (<br/>
   * <b>Entrées:</b> Requête ok<br/>
   * <b>Attendu:</b> ResponseErreur 503 - SERVICE_TIERS_INDISPONIBLE - Error in RES<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_POST_BL100_NOK_020() throws Throwable
  {
    // Preparation de la requête
    PositionPortPm posPortPmMigreSrc = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmMigreCible = new PositionPortPm(2, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    MigrationPortPm migrationPortPm = new MigrationPortPm(posPortPmMigreSrc, posPortPmMigreCible);
    LienPortPon lienPortPonAjout = new LienPortPon("OLT2000", 2, 1); //$NON-NLS-1$
    PanneauPm panneauPm = new PanneauPm("PANNEAU_D"); //$NON-NLS-1$
    BoitierPm boitierPm = new BoitierPm("BOITIER_D", "ABCD123"); //$NON-NLS-1$ //$NON-NLS-2$
    AjoutPortPm ajoutPortPm = new AjoutPortPm(posPortPmMigreCible, Collections.singletonList(lienPortPonAjout), panneauPm, boitierPm);
    PositionPortPm posPortPmSupp = new PositionPortPm(1, "PANNEAU_E", "BOITIER_E", "GHYUI893"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    SuppressionPortPm suppPortPm = new SuppressionPortPm(Collections.singletonList(posPortPmSupp));
    PositionPortPm posPortPmModif = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    LienPortPon lienPortPonModifSrc = new LienPortPon("OLT2000", 2, 1); //$NON-NLS-1$
    LienPortPon lienPortPonModifCible = new LienPortPon("OLT2000", 2, 3); //$NON-NLS-1$
    ModificationPortPm modifPortPm = new ModificationPortPm(posPortPmModif, Collections.singletonList(lienPortPonModifSrc), Collections.singletonList(lienPortPonModifCible));
    PositionPortPon posPortPonModif = new PositionPortPon(1, 1, "OLT2000"); //$NON-NLS-1$
    ModificationPortPon modifPortPon = new ModificationPortPon(posPortPonModif, Collections.singletonList("GPON")); //$NON-NLS-1$
    PositionPortPon posPortPonSupp = new PositionPortPon(4, 2, "OLT2001"); //$NON-NLS-1$
    SuppressionPortPon suppPortPon = new SuppressionPortPon(posPortPonSupp);
    PE0529_PostRequest creationRequest = new PE0529_PostRequest("PON128", Arrays.asList("PM", "OLT")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    creationRequest.setNumeroGCR("GCR-12345678"); //$NON-NLS-1$
    creationRequest.setMigrationsPortsPm(Collections.singletonList(migrationPortPm));
    creationRequest.setAjoutsPortsPm(Collections.singletonList(ajoutPortPm));
    creationRequest.setSuppressionsPortsPm(Collections.singletonList(suppPortPm));
    creationRequest.setModificationsPortsPm(Collections.singletonList(modifPortPm));
    creationRequest.setModificationsPortsPon(Collections.singletonList(modifPortPon));
    creationRequest.setSuppressionsPortsPon(Collections.singletonList(suppPortPon));
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePostRequest(creationRequest, headers);

    // MOCK RES.ressourceLireUn
    Ressource ressource = new RessourcePortPM("LIBRE", "GHYUI893", "BOITIER_E", "PANNEAU_E", 1); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource, "GHYUI893||BOITIER_E||PANNEAU_E||1", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    // MOCK RES.pmCompositeLireUnParReferencePmBytel (portPM Src)
    PMComposite pmComposite = new PMComposite();
    pmComposite.setReferencePmBytel("GHYUI890"); //$NON-NLS-1$
    LienPortPMPon lienPortPMPon = new LienPortPMPon("OPERATIONNEL", new PortPonId("OLT2000", 1, 1)); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, LienPortPMPon> lienPortPMPonMap = new HashMap<>();
    lienPortPMPonMap.put("OLT2000-1-1", lienPortPMPon); //$NON-NLS-1$
    PortPM portPmComposite = new PortPM(1, "OPERATIONNEL", lienPortPMPonMap); //$NON-NLS-1$
    PortPM portPmComposite2 = new PortPM(2, "OPERATIONNEL", lienPortPMPonMap); //$NON-NLS-1$
    Map<Integer, PortPM> portCompositeMap = new HashMap<>();
    portCompositeMap.put(1, portPmComposite);
    portCompositeMap.put(2, portPmComposite2);
    PanneauPM panneauPMComposite = new PanneauPM("PANNEAU_A", "OPERATIONNEL", portCompositeMap); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, PanneauPM> panneauCompositeMap = new HashMap<>();
    panneauCompositeMap.put("PANNEAU_A", panneauPMComposite); //$NON-NLS-1$
    BoitierPM boitierPmComposite = new BoitierPM("BOITIER_A", "OPERATIONNEL", panneauCompositeMap); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, BoitierPM> boitierCompositeMap = new HashMap<>();
    boitierCompositeMap.put("BOITIER_A", boitierPmComposite); //$NON-NLS-1$
    pmComposite.setListeBoitierPM(boitierCompositeMap);
    mockRES_PmCompositeLireUnParReferencePmBytel(RetourFactoryForTU.createOkRetour(), pmComposite, "GHYUI890"); //$NON-NLS-1$

    // MOCK RES.pmCompositeLireUnParReferencePmBytel (portPM Cible) - not needed, already in cache

    // MOCK RES.oltCompositeLireUn
    Set<String> technos = Collections.singleton("XGSPON"); //$NON-NLS-1$
    OltComposite oltCompositeSrc = createOLTCompositeFromPositionPortPm(1, 1, "OLT2000", technos, 0); //$NON-NLS-1$ //$NON-NLS-2$

    PortPON portPonComposite1 = new PortPON(1, "OK", technos, 0); //$NON-NLS-1$
    SurchargePortPON surchargePortPonComposite1 = new SurchargePortPON(0, technos, "OK"); //$NON-NLS-1$
    portPonComposite1.setSurchargePortPON(surchargePortPonComposite1);
    Map<Integer, PortPON> portPonMap = new HashMap<>();
    portPonMap.put(1, portPonComposite1);
    portPonMap.put(3, portPonComposite1);
    CartePON cartePonComposite2 = new CartePON(2, "modeleCarte", "OK"); //$NON-NLS-1$ //$NON-NLS-2$
    cartePonComposite2.setListePortPON(portPonMap);
    oltCompositeSrc.getListeCartePON().put(2, cartePonComposite2);

    mockRES_OltCompositeLireUn(RetourFactoryForTU.createOkRetour(), oltCompositeSrc, "OLT2000"); //$NON-NLS-1$

    // MOCK RES.oltCompositeLireUn - not needed, already in cache

    // MOCK RES.pmCompositeLireUnParReferencePmBytel - not needed, already in cache

    // MOCK RES.oltCompositeLireUn - src - not needed, already in cache

    // MOCK RES.oltCompositeLireUn - cible - not needed, already in cache

    // MOCK RES.oltCompositeLireUn - ajout - not needed, already in cache

    // MOCK RES.oltCompositeLireUn - Modif Pon - not needed, already in cache

    // MOCK RES.oltCompositeLireUn - Supp Pon
    Retour retourKO = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, "Error in RES"); //$NON-NLS-1$
    mockRES_OltCompositeLireUn(retourKO, null, "OLT2001"); //$NON-NLS-1$

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPostProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Récupération du résultat de la requête
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    // Tests de retours
    Assert.assertEquals(ErrorCode.KO_00503, response.getErrorCode());
    Assert.assertEquals("Error in RES", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegConsts.SERVICE_TIERS_INDISPONIBLE, reponseactual.getError());
  }

  /**
   * <b>Cas de test: Suppression Port Pon - RES.ressourceLireUn ONT_ID NOK != DONNEE_INCONNUE</b> (<br/>
   * <b>Entrées:</b> Requête ok<br/>
   * <b>Attendu:</b> ResponseErreur 503 - SERVICE_TIERS_INDISPONIBLE - Error in RES<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_POST_BL100_NOK_021() throws Throwable
  {
    // Preparation de la requête
    PositionPortPm posPortPmMigreSrc = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmMigreCible = new PositionPortPm(2, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    MigrationPortPm migrationPortPm = new MigrationPortPm(posPortPmMigreSrc, posPortPmMigreCible);
    LienPortPon lienPortPonAjout = new LienPortPon("OLT2000", 2, 1); //$NON-NLS-1$
    PanneauPm panneauPm = new PanneauPm("PANNEAU_D"); //$NON-NLS-1$
    BoitierPm boitierPm = new BoitierPm("BOITIER_D", "ABCD123"); //$NON-NLS-1$ //$NON-NLS-2$
    AjoutPortPm ajoutPortPm = new AjoutPortPm(posPortPmMigreCible, Collections.singletonList(lienPortPonAjout), panneauPm, boitierPm);
    PositionPortPm posPortPmSupp = new PositionPortPm(1, "PANNEAU_E", "BOITIER_E", "GHYUI893"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    SuppressionPortPm suppPortPm = new SuppressionPortPm(Collections.singletonList(posPortPmSupp));
    PositionPortPm posPortPmModif = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    LienPortPon lienPortPonModifSrc = new LienPortPon("OLT2000", 2, 1); //$NON-NLS-1$
    LienPortPon lienPortPonModifCible = new LienPortPon("OLT2000", 2, 3); //$NON-NLS-1$
    ModificationPortPm modifPortPm = new ModificationPortPm(posPortPmModif, Collections.singletonList(lienPortPonModifSrc), Collections.singletonList(lienPortPonModifCible));
    PositionPortPon posPortPonModif = new PositionPortPon(1, 1, "OLT2000"); //$NON-NLS-1$
    ModificationPortPon modifPortPon = new ModificationPortPon(posPortPonModif, Collections.singletonList("GPON")); //$NON-NLS-1$
    PositionPortPon posPortPonSupp = new PositionPortPon(4, 2, "OLT2000"); //$NON-NLS-1$
    SuppressionPortPon suppPortPon = new SuppressionPortPon(posPortPonSupp);
    PE0529_PostRequest creationRequest = new PE0529_PostRequest("PON128", Arrays.asList("PM", "OLT")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    creationRequest.setNumeroGCR("GCR-12345678"); //$NON-NLS-1$
    creationRequest.setMigrationsPortsPm(Collections.singletonList(migrationPortPm));
    creationRequest.setAjoutsPortsPm(Collections.singletonList(ajoutPortPm));
    creationRequest.setSuppressionsPortsPm(Collections.singletonList(suppPortPm));
    creationRequest.setModificationsPortsPm(Collections.singletonList(modifPortPm));
    creationRequest.setModificationsPortsPon(Collections.singletonList(modifPortPon));
    creationRequest.setSuppressionsPortsPon(Collections.singletonList(suppPortPon));
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePostRequest(creationRequest, headers);

    // MOCK RES.ressourceLireUn
    Ressource ressource = new RessourcePortPM("LIBRE", "GHYUI893", "BOITIER_E", "PANNEAU_E", 1); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource, "GHYUI893||BOITIER_E||PANNEAU_E||1", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    // MOCK RES.pmCompositeLireUnParReferencePmBytel (portPM Src)
    PMComposite pmComposite = new PMComposite();
    pmComposite.setReferencePmBytel("GHYUI890"); //$NON-NLS-1$
    LienPortPMPon lienPortPMPon = new LienPortPMPon("OPERATIONNEL", new PortPonId("OLT2000", 1, 1)); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, LienPortPMPon> lienPortPMPonMap = new HashMap<>();
    lienPortPMPonMap.put("OLT2000-1-1", lienPortPMPon); //$NON-NLS-1$
    PortPM portPmComposite = new PortPM(1, "OPERATIONNEL", lienPortPMPonMap); //$NON-NLS-1$
    PortPM portPmComposite2 = new PortPM(2, "OPERATIONNEL", lienPortPMPonMap); //$NON-NLS-1$
    Map<Integer, PortPM> portCompositeMap = new HashMap<>();
    portCompositeMap.put(1, portPmComposite);
    portCompositeMap.put(2, portPmComposite2);
    PanneauPM panneauPMComposite = new PanneauPM("PANNEAU_A", "OPERATIONNEL", portCompositeMap); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, PanneauPM> panneauCompositeMap = new HashMap<>();
    panneauCompositeMap.put("PANNEAU_A", panneauPMComposite); //$NON-NLS-1$
    BoitierPM boitierPmComposite = new BoitierPM("BOITIER_A", "OPERATIONNEL", panneauCompositeMap); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, BoitierPM> boitierCompositeMap = new HashMap<>();
    boitierCompositeMap.put("BOITIER_A", boitierPmComposite); //$NON-NLS-1$
    pmComposite.setListeBoitierPM(boitierCompositeMap);
    mockRES_PmCompositeLireUnParReferencePmBytel(RetourFactoryForTU.createOkRetour(), pmComposite, "GHYUI890"); //$NON-NLS-1$

    // MOCK RES.pmCompositeLireUnParReferencePmBytel (portPM Cible) - not needed, already in cache

    // MOCK RES.oltCompositeLireUn
    Set<String> technos = Collections.singleton("XGSPON"); //$NON-NLS-1$
    OltComposite oltCompositeSrc = createOLTCompositeFromPositionPortPm(1, 1, "OLT2000", technos, 0); //$NON-NLS-1$ //$NON-NLS-2$

    PortPON portPonComposite1 = new PortPON(1, "OK", technos, 0); //$NON-NLS-1$
    SurchargePortPON surchargePortPonComposite1 = new SurchargePortPON(0, technos, "OK"); //$NON-NLS-1$
    portPonComposite1.setSurchargePortPON(surchargePortPonComposite1);
    portPonComposite1.getListeOntId().put(1, new OntId(1, null));
    Map<Integer, PortPON> portPonMap = new HashMap<>();
    portPonMap.put(1, portPonComposite1);
    portPonMap.put(3, portPonComposite1);
    portPonMap.put(4, portPonComposite1);
    CartePON cartePonComposite2 = new CartePON(2, "modeleCarte", "OK"); //$NON-NLS-1$ //$NON-NLS-2$
    cartePonComposite2.setListePortPON(portPonMap);
    oltCompositeSrc.getListeCartePON().put(2, cartePonComposite2);

    mockRES_OltCompositeLireUn(RetourFactoryForTU.createOkRetour(), oltCompositeSrc, "OLT2000"); //$NON-NLS-1$

    // MOCK RES.oltCompositeLireUn - not needed, already in cache

    // MOCK RES.pmCompositeLireUnParReferencePmBytel - not needed, already in cache

    // MOCK RES.oltCompositeLireUn - src - not needed, already in cache

    // MOCK RES.oltCompositeLireUn - cible - not needed, already in cache

    // MOCK RES.oltCompositeLireUn - ajout - not needed, already in cache

    // MOCK RES.oltCompositeLireUn - Modif Pon - not needed, already in cache

    // MOCK RES.oltCompositeLireUn - Supp Pon - not needed, already in cache

    // MOCK RES.ressourceLireUn - Supp Pon
    Retour retourKO = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, "Error in RES"); //$NON-NLS-1$
    mockRES_RessourceLireUn(retourKO, null, "OLT2000-2-4-1", TypeRessource.ONT_ID.name()); //$NON-NLS-1$

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPostProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Récupération du résultat de la requête
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    // Tests de retours
    Assert.assertEquals(ErrorCode.KO_00503, response.getErrorCode());
    Assert.assertEquals("Error in RES", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegConsts.SERVICE_TIERS_INDISPONIBLE, reponseactual.getError());
  }

  /**
   * <b>Cas de test: Suppression Port Pon - OntId non ALLOUE</b> (<br/>
   * <b>Entrées:</b> Requête ok<br/>
   * <b>Attendu:</b> ResponseErreur 403 - ACCES_REFUSE - Suppression du port PON OLT200022 n’est pas autorisee :
   * existence de OntId 1 ALLOUE<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_POST_BL100_NOK_022() throws Throwable
  {
    // Preparation de la requête
    PositionPortPm posPortPmMigreSrc = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmMigreCible = new PositionPortPm(2, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    MigrationPortPm migrationPortPm = new MigrationPortPm(posPortPmMigreSrc, posPortPmMigreCible);
    LienPortPon lienPortPonAjout = new LienPortPon("OLT2000", 2, 1); //$NON-NLS-1$
    PanneauPm panneauPm = new PanneauPm("PANNEAU_D"); //$NON-NLS-1$
    BoitierPm boitierPm = new BoitierPm("BOITIER_D", "ABCD123"); //$NON-NLS-1$ //$NON-NLS-2$
    AjoutPortPm ajoutPortPm = new AjoutPortPm(posPortPmMigreCible, Collections.singletonList(lienPortPonAjout), panneauPm, boitierPm);
    PositionPortPm posPortPmSupp = new PositionPortPm(1, "PANNEAU_E", "BOITIER_E", "GHYUI893"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    SuppressionPortPm suppPortPm = new SuppressionPortPm(Collections.singletonList(posPortPmSupp));
    PositionPortPm posPortPmModif = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    LienPortPon lienPortPonModifSrc = new LienPortPon("OLT2000", 2, 1); //$NON-NLS-1$
    LienPortPon lienPortPonModifCible = new LienPortPon("OLT2000", 2, 3); //$NON-NLS-1$
    ModificationPortPm modifPortPm = new ModificationPortPm(posPortPmModif, Collections.singletonList(lienPortPonModifSrc), Collections.singletonList(lienPortPonModifCible));
    PositionPortPon posPortPonModif = new PositionPortPon(1, 1, "OLT2000"); //$NON-NLS-1$
    ModificationPortPon modifPortPon = new ModificationPortPon(posPortPonModif, Collections.singletonList("GPON")); //$NON-NLS-1$
    PositionPortPon posPortPonSupp = new PositionPortPon(4, 2, "OLT2000"); //$NON-NLS-1$
    SuppressionPortPon suppPortPon = new SuppressionPortPon(posPortPonSupp);
    PE0529_PostRequest creationRequest = new PE0529_PostRequest("PON128", Arrays.asList("PM", "OLT")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    creationRequest.setNumeroGCR("GCR-12345678"); //$NON-NLS-1$
    creationRequest.setMigrationsPortsPm(Collections.singletonList(migrationPortPm));
    creationRequest.setAjoutsPortsPm(Collections.singletonList(ajoutPortPm));
    creationRequest.setSuppressionsPortsPm(Collections.singletonList(suppPortPm));
    creationRequest.setModificationsPortsPm(Collections.singletonList(modifPortPm));
    creationRequest.setModificationsPortsPon(Collections.singletonList(modifPortPon));
    creationRequest.setSuppressionsPortsPon(Collections.singletonList(suppPortPon));
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePostRequest(creationRequest, headers);

    // MOCK RES.ressourceLireUn
    Ressource ressource = new RessourcePortPM("LIBRE", "GHYUI893", "BOITIER_E", "PANNEAU_E", 1); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource, "GHYUI893||BOITIER_E||PANNEAU_E||1", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    // MOCK RES.pmCompositeLireUnParReferencePmBytel (portPM Src)
    PMComposite pmComposite = new PMComposite();
    pmComposite.setReferencePmBytel("GHYUI890"); //$NON-NLS-1$
    LienPortPMPon lienPortPMPon = new LienPortPMPon("OPERATIONNEL", new PortPonId("OLT2000", 1, 1)); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, LienPortPMPon> lienPortPMPonMap = new HashMap<>();
    lienPortPMPonMap.put("OLT2000-1-1", lienPortPMPon); //$NON-NLS-1$
    PortPM portPmComposite = new PortPM(1, "OPERATIONNEL", lienPortPMPonMap); //$NON-NLS-1$
    PortPM portPmComposite2 = new PortPM(2, "OPERATIONNEL", lienPortPMPonMap); //$NON-NLS-1$
    Map<Integer, PortPM> portCompositeMap = new HashMap<>();
    portCompositeMap.put(1, portPmComposite);
    portCompositeMap.put(2, portPmComposite2);
    PanneauPM panneauPMComposite = new PanneauPM("PANNEAU_A", "OPERATIONNEL", portCompositeMap); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, PanneauPM> panneauCompositeMap = new HashMap<>();
    panneauCompositeMap.put("PANNEAU_A", panneauPMComposite); //$NON-NLS-1$
    BoitierPM boitierPmComposite = new BoitierPM("BOITIER_A", "OPERATIONNEL", panneauCompositeMap); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, BoitierPM> boitierCompositeMap = new HashMap<>();
    boitierCompositeMap.put("BOITIER_A", boitierPmComposite); //$NON-NLS-1$
    pmComposite.setListeBoitierPM(boitierCompositeMap);
    mockRES_PmCompositeLireUnParReferencePmBytel(RetourFactoryForTU.createOkRetour(), pmComposite, "GHYUI890"); //$NON-NLS-1$

    // MOCK RES.pmCompositeLireUnParReferencePmBytel (portPM Cible) - not needed, already in cache

    // MOCK RES.oltCompositeLireUn
    Set<String> technos = Collections.singleton("XGSPON"); //$NON-NLS-1$
    OltComposite oltCompositeSrc = createOLTCompositeFromPositionPortPm(1, 1, "OLT2000", technos, 0); //$NON-NLS-1$ //$NON-NLS-2$

    PortPON portPonComposite1 = new PortPON(1, "OK", technos, 0); //$NON-NLS-1$
    SurchargePortPON surchargePortPonComposite1 = new SurchargePortPON(0, technos, "OK"); //$NON-NLS-1$
    portPonComposite1.setSurchargePortPON(surchargePortPonComposite1);
    portPonComposite1.getListeOntId().put(1, new OntId(1, null));
    Map<Integer, PortPON> portPonMap = new HashMap<>();
    portPonMap.put(1, portPonComposite1);
    portPonMap.put(3, portPonComposite1);
    portPonMap.put(4, portPonComposite1);
    CartePON cartePonComposite2 = new CartePON(2, "modeleCarte", "OK"); //$NON-NLS-1$ //$NON-NLS-2$
    cartePonComposite2.setListePortPON(portPonMap);
    oltCompositeSrc.getListeCartePON().put(2, cartePonComposite2);

    mockRES_OltCompositeLireUn(RetourFactoryForTU.createOkRetour(), oltCompositeSrc, "OLT2000"); //$NON-NLS-1$

    // MOCK RES.oltCompositeLireUn - not needed, already in cache

    // MOCK RES.pmCompositeLireUnParReferencePmBytel - not needed, already in cache

    // MOCK RES.oltCompositeLireUn - src - not needed, already in cache

    // MOCK RES.oltCompositeLireUn - cible - not needed, already in cache

    // MOCK RES.oltCompositeLireUn - ajout - not needed, already in cache

    // MOCK RES.oltCompositeLireUn - Modif Pon - not needed, already in cache

    // MOCK RES.oltCompositeLireUn - Supp Pon - not needed, already in cache

    // MOCK RES.ressourceLireUn - Supp Pon
    RessourceOntId ressourceOntId = new RessourceOntId("ALLOUE", "", 0, 0, 0); //$NON-NLS-1$ //$NON-NLS-2$
    mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressourceOntId, "OLT2000-2-4-1", TypeRessource.ONT_ID.name()); //$NON-NLS-1$

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPostProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Récupération du résultat de la requête
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    // Tests de retours
    Assert.assertEquals(ErrorCode.KO_00403, response.getErrorCode());
    Assert.assertEquals("Suppression du port PON OLT2000-2-4 n'est pas autorisée: existence de OntId 1 ALLOUE.", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegSpiritConsts.ACCES_REFUSE, reponseactual.getError());
  }

  /**
   * <b>Cas de test: BL800 NOK</b> (<br/>
   * <b>Entrées:</b> Requête ok<br/>
   * <b>Attendu:</b> ResponseErreur 500 - TRAITEMENT_ARRETE<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_POST_BL100_NOK_023() throws Throwable
  {
    // Preparation de la requête
    PositionPortPm posPortPmMigreSrc = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmMigreCible = new PositionPortPm(2, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    MigrationPortPm migrationPortPm = new MigrationPortPm(posPortPmMigreSrc, posPortPmMigreCible);
    LienPortPon lienPortPonAjout = new LienPortPon("OLT2000", 2, 1); //$NON-NLS-1$
    PanneauPm panneauPm = new PanneauPm("PANNEAU_D"); //$NON-NLS-1$
    BoitierPm boitierPm = new BoitierPm("BOITIER_D", "ABCD123"); //$NON-NLS-1$ //$NON-NLS-2$
    AjoutPortPm ajoutPortPm = new AjoutPortPm(posPortPmMigreCible, Collections.singletonList(lienPortPonAjout), panneauPm, boitierPm);
    PositionPortPm posPortPmSupp = new PositionPortPm(1, "PANNEAU_E", "BOITIER_E", "GHYUI893"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    SuppressionPortPm suppPortPm = new SuppressionPortPm(Collections.singletonList(posPortPmSupp));
    PositionPortPm posPortPmModif = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    LienPortPon lienPortPonModifSrc = new LienPortPon("OLT2000", 2, 1); //$NON-NLS-1$
    LienPortPon lienPortPonModifCible = new LienPortPon("OLT2000", 2, 3); //$NON-NLS-1$
    ModificationPortPm modifPortPm = new ModificationPortPm(posPortPmModif, Collections.singletonList(lienPortPonModifSrc), Collections.singletonList(lienPortPonModifCible));
    PositionPortPon posPortPonModif = new PositionPortPon(1, 1, "OLT2000"); //$NON-NLS-1$
    ModificationPortPon modifPortPon = new ModificationPortPon(posPortPonModif, Collections.singletonList("GPON")); //$NON-NLS-1$
    PE0529_PostRequest creationRequest = new PE0529_PostRequest("PON128", Arrays.asList("PM", "OLT")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    creationRequest.setNumeroGCR("GCR-12345678"); //$NON-NLS-1$
    creationRequest.setMigrationsPortsPm(Collections.singletonList(migrationPortPm));
    creationRequest.setAjoutsPortsPm(Collections.singletonList(ajoutPortPm));
    creationRequest.setSuppressionsPortsPm(Collections.singletonList(suppPortPm));
    creationRequest.setModificationsPortsPm(Collections.singletonList(modifPortPm));
    creationRequest.setModificationsPortsPon(Collections.singletonList(modifPortPon));
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePostRequest(creationRequest, headers);

    // MOCK RES.ressourceLireUn
    Ressource ressource = new RessourcePortPM("LIBRE", "GHYUI893", "BOITIER_E", "PANNEAU_E", 1); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource, "GHYUI893||BOITIER_E||PANNEAU_E||1", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    // MOCK RES.pmCompositeLireUnParReferencePmBytel (portPM Src)
    PMComposite pmComposite = new PMComposite();
    pmComposite.setReferencePmBytel("GHYUI890"); //$NON-NLS-1$
    LienPortPMPon lienPortPMPon = new LienPortPMPon("OPERATIONNEL", new PortPonId("OLT2000", 1, 1)); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, LienPortPMPon> lienPortPMPonMap = new HashMap<>();
    lienPortPMPonMap.put("OLT2000-1-1", lienPortPMPon); //$NON-NLS-1$
    PortPM portPmComposite = new PortPM(1, "OPERATIONNEL", lienPortPMPonMap); //$NON-NLS-1$
    PortPM portPmComposite2 = new PortPM(2, "OPERATIONNEL", lienPortPMPonMap); //$NON-NLS-1$
    Map<Integer, PortPM> portCompositeMap = new HashMap<>();
    portCompositeMap.put(1, portPmComposite);
    portCompositeMap.put(2, portPmComposite2);
    PanneauPM panneauPMComposite = new PanneauPM("PANNEAU_A", "OPERATIONNEL", portCompositeMap); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, PanneauPM> panneauCompositeMap = new HashMap<>();
    panneauCompositeMap.put("PANNEAU_A", panneauPMComposite); //$NON-NLS-1$
    BoitierPM boitierPmComposite = new BoitierPM("BOITIER_A", "OPERATIONNEL", panneauCompositeMap); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, BoitierPM> boitierCompositeMap = new HashMap<>();
    boitierCompositeMap.put("BOITIER_A", boitierPmComposite); //$NON-NLS-1$
    pmComposite.setListeBoitierPM(boitierCompositeMap);
    mockRES_PmCompositeLireUnParReferencePmBytel(RetourFactoryForTU.createOkRetour(), pmComposite, "GHYUI890"); //$NON-NLS-1$

    // MOCK RES.pmCompositeLireUnParReferencePmBytel (portPM Cible) - not needed, already in cache

    // MOCK RES.oltCompositeLireUn
    Set<String> technos = Collections.singleton("XGSPON"); //$NON-NLS-1$
    OltComposite oltCompositeSrc = createOLTCompositeFromPositionPortPm(1, 1, "OLT2000", technos, 0); //$NON-NLS-1$ //$NON-NLS-2$

    PortPON portPonComposite1 = new PortPON(1, "OK", technos, 0); //$NON-NLS-1$
    SurchargePortPON surchargePortPonComposite1 = new SurchargePortPON(0, technos, "OK"); //$NON-NLS-1$
    portPonComposite1.setSurchargePortPON(surchargePortPonComposite1);
    portPonComposite1.getListeOntId().put(1, new OntId(1, null));
    Map<Integer, PortPON> portPonMap = new HashMap<>();
    portPonMap.put(1, portPonComposite1);
    portPonMap.put(3, portPonComposite1);
    CartePON cartePonComposite2 = new CartePON(2, "modeleCarte", "OK"); //$NON-NLS-1$ //$NON-NLS-2$
    cartePonComposite2.setListePortPON(portPonMap);
    oltCompositeSrc.getListeCartePON().put(2, cartePonComposite2);

    mockRES_OltCompositeLireUn(RetourFactoryForTU.createOkRetour(), oltCompositeSrc, "OLT2000"); //$NON-NLS-1$

    // MOCK RES.oltCompositeLireUn - not needed, already in cache

    // MOCK RES.pmCompositeLireUnParReferencePmBytel - not needed, already in cache

    // MOCK RES.oltCompositeLireUn - src - not needed, already in cache

    // MOCK RES.oltCompositeLireUn - cible - not needed, already in cache

    // MOCK RES.oltCompositeLireUn - ajout - not needed, already in cache

    // MOCK RES.oltCompositeLireUn - not needed, already in cache

    // MOCK BL800
    mockBL800(RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegConsts.TRAITEMENT_ARRETE, "Error in BL800")); //$NON-NLS-1$

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPostProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Récupération du résultat de la requête
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    // Tests de retours
    Assert.assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    Assert.assertEquals("Error in BL800", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegConsts.TRAITEMENT_ARRETE, reponseactual.getError());
  }

  /**
   * <b>Cas de test: REX.operationVieReseauCreer KO CAT-2/b> (<br/>
   * <b>Entrées:</b> Requête ok<br/>
   * <b>Attendu:</b> ResponseErreur 503 - SERVICE_TIERS_INDISPONIBLE<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_POST_BL100_NOK_025() throws Throwable
  {
    // Preparation de la requête
    PositionPortPm posPortPmMigreSrc = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmMigreCible = new PositionPortPm(2, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    MigrationPortPm migrationPortPm = new MigrationPortPm(posPortPmMigreSrc, posPortPmMigreCible);
    LienPortPon lienPortPonAjout = new LienPortPon("OLT2000", 2, 1); //$NON-NLS-1$
    PanneauPm panneauPm = new PanneauPm("PANNEAU_D"); //$NON-NLS-1$
    BoitierPm boitierPm = new BoitierPm("BOITIER_D", "ABCD123"); //$NON-NLS-1$ //$NON-NLS-2$
    AjoutPortPm ajoutPortPm = new AjoutPortPm(posPortPmMigreCible, Collections.singletonList(lienPortPonAjout), panneauPm, boitierPm);
    PositionPortPm posPortPmSupp = new PositionPortPm(1, "PANNEAU_E", "BOITIER_E", "GHYUI893"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    SuppressionPortPm suppPortPm = new SuppressionPortPm(Collections.singletonList(posPortPmSupp));
    PositionPortPm posPortPmModif = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    LienPortPon lienPortPonModifSrc = new LienPortPon("OLT2000", 2, 1); //$NON-NLS-1$
    LienPortPon lienPortPonModifCible = new LienPortPon("OLT2000", 2, 3); //$NON-NLS-1$
    ModificationPortPm modifPortPm = new ModificationPortPm(posPortPmModif, Collections.singletonList(lienPortPonModifSrc), Collections.singletonList(lienPortPonModifCible));
    PositionPortPon posPortPonModif = new PositionPortPon(1, 1, "OLT2000"); //$NON-NLS-1$
    ModificationPortPon modifPortPon = new ModificationPortPon(posPortPonModif, Collections.singletonList("GPON")); //$NON-NLS-1$
    PE0529_PostRequest creationRequest = new PE0529_PostRequest("PON128", Arrays.asList("PM", "OLT")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    creationRequest.setNumeroGCR("GCR-12345678"); //$NON-NLS-1$
    creationRequest.setMigrationsPortsPm(Collections.singletonList(migrationPortPm));
    creationRequest.setAjoutsPortsPm(Collections.singletonList(ajoutPortPm));
    creationRequest.setSuppressionsPortsPm(Collections.singletonList(suppPortPm));
    creationRequest.setModificationsPortsPm(Collections.singletonList(modifPortPm));
    creationRequest.setModificationsPortsPon(Collections.singletonList(modifPortPon));
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePostRequest(creationRequest, headers);

    // MOCK RES.ressourceLireUn
    Ressource ressource = new RessourcePortPM("LIBRE", "GHYUI893", "BOITIER_E", "PANNEAU_E", 1); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource, "GHYUI893||BOITIER_E||PANNEAU_E||1", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    // MOCK RES.pmCompositeLireUnParReferencePmBytel (portPM Src)
    PMComposite pmComposite = new PMComposite();
    pmComposite.setReferencePmBytel("GHYUI890"); //$NON-NLS-1$
    LienPortPMPon lienPortPMPon = new LienPortPMPon("OPERATIONNEL", new PortPonId("OLT2000", 1, 1)); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, LienPortPMPon> lienPortPMPonMap = new HashMap<>();
    lienPortPMPonMap.put("OLT2000-1-1", lienPortPMPon); //$NON-NLS-1$
    PortPM portPmComposite = new PortPM(1, "OPERATIONNEL", lienPortPMPonMap); //$NON-NLS-1$
    PortPM portPmComposite2 = new PortPM(2, "OPERATIONNEL", lienPortPMPonMap); //$NON-NLS-1$
    Map<Integer, PortPM> portCompositeMap = new HashMap<>();
    portCompositeMap.put(1, portPmComposite);
    portCompositeMap.put(2, portPmComposite2);
    PanneauPM panneauPMComposite = new PanneauPM("PANNEAU_A", "OPERATIONNEL", portCompositeMap); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, PanneauPM> panneauCompositeMap = new HashMap<>();
    panneauCompositeMap.put("PANNEAU_A", panneauPMComposite); //$NON-NLS-1$
    BoitierPM boitierPmComposite = new BoitierPM("BOITIER_A", "OPERATIONNEL", panneauCompositeMap); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, BoitierPM> boitierCompositeMap = new HashMap<>();
    boitierCompositeMap.put("BOITIER_A", boitierPmComposite); //$NON-NLS-1$
    pmComposite.setListeBoitierPM(boitierCompositeMap);
    mockRES_PmCompositeLireUnParReferencePmBytel(RetourFactoryForTU.createOkRetour(), pmComposite, "GHYUI890"); //$NON-NLS-1$

    // MOCK RES.pmCompositeLireUnParReferencePmBytel (portPM Cible) - not needed, already in cache

    // MOCK RES.oltCompositeLireUn
    Set<String> technos = Collections.singleton("XGSPON"); //$NON-NLS-1$
    OltComposite oltCompositeSrc = createOLTCompositeFromPositionPortPm(1, 1, "OLT2000", technos, 0); //$NON-NLS-1$ //$NON-NLS-2$

    PortPON portPonComposite1 = new PortPON(1, "OK", technos, 0); //$NON-NLS-1$
    SurchargePortPON surchargePortPonComposite1 = new SurchargePortPON(0, technos, "OK"); //$NON-NLS-1$
    portPonComposite1.setSurchargePortPON(surchargePortPonComposite1);
    portPonComposite1.getListeOntId().put(1, new OntId(1, null));
    Map<Integer, PortPON> portPonMap = new HashMap<>();
    portPonMap.put(1, portPonComposite1);
    portPonMap.put(3, portPonComposite1);
    CartePON cartePonComposite2 = new CartePON(2, "modeleCarte", "OK"); //$NON-NLS-1$ //$NON-NLS-2$
    cartePonComposite2.setListePortPON(portPonMap);
    oltCompositeSrc.getListeCartePON().put(2, cartePonComposite2);

    mockRES_OltCompositeLireUn(RetourFactoryForTU.createOkRetour(), oltCompositeSrc, "OLT2000"); //$NON-NLS-1$

    // MOCK RES.oltCompositeLireUn - not needed, already in cache

    // MOCK RES.pmCompositeLireUnParReferencePmBytel - not needed, already in cache

    // MOCK RES.oltCompositeLireUn - src - not needed, already in cache

    // MOCK RES.oltCompositeLireUn - cible - not needed, already in cache

    // MOCK RES.oltCompositeLireUn - ajout - not needed, already in cache

    // MOCK RES.oltCompositeLireUn - not needed, already in cache

    // MOCK BL800
    mockBL800(RetourFactoryForTU.createOkRetour());

    // MOCK REX.operationVieReseauCreer
    Retour retourKO = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, "Error in REX"); //$NON-NLS-1$
    OperationVieReseau ovr = new OperationVieReseau(ID_OPERATION_VIE_RESEAU, creationRequest.getTypeVieReseau(), "ACQUITTE", creationRequest.getDonneesBrutes()); //$NON-NLS-1$
    ovr.setNumeroGCR("GCR-12345678"); //$NON-NLS-1$
    mockREX_OperationVieReseauCreer(retourKO, ovr);

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPostProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Récupération du résultat de la requête
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    // Tests de retours
    Assert.assertEquals(ErrorCode.KO_00503, response.getErrorCode());
    Assert.assertEquals("Error in REX", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegConsts.SERVICE_TIERS_INDISPONIBLE, reponseactual.getError());
  }

  /**
   * <b>Cas de test: REX.cleRechercheOperationVieReseauCreerListe KO CAT-2/b> (<br/>
   * <b>Entrées:</b> Requête ok<br/>
   * <b>Attendu:</b> ResponseErreur 503 - SERVICE_TIERS_INDISPONIBLE<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_POST_BL100_NOK_026() throws Throwable
  {
    // Preparation de la requête
    PositionPortPm posPortPmMigreSrc = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmMigreCible = new PositionPortPm(2, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    MigrationPortPm migrationPortPm = new MigrationPortPm(posPortPmMigreSrc, posPortPmMigreCible);
    LienPortPon lienPortPonAjout = new LienPortPon("OLT2000", 2, 1); //$NON-NLS-1$
    PanneauPm panneauPm = new PanneauPm("PANNEAU_D"); //$NON-NLS-1$
    BoitierPm boitierPm = new BoitierPm("BOITIER_D", "ABCD123"); //$NON-NLS-1$ //$NON-NLS-2$
    AjoutPortPm ajoutPortPm = new AjoutPortPm(posPortPmMigreCible, Collections.singletonList(lienPortPonAjout), panneauPm, boitierPm);
    PositionPortPm posPortPmSupp = new PositionPortPm(1, "PANNEAU_E", "BOITIER_E", "GHYUI893"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    SuppressionPortPm suppPortPm = new SuppressionPortPm(Collections.singletonList(posPortPmSupp));
    PositionPortPm posPortPmModif = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    LienPortPon lienPortPonModifSrc = new LienPortPon("OLT2000", 2, 1); //$NON-NLS-1$
    LienPortPon lienPortPonModifCible = new LienPortPon("OLT2000", 2, 3); //$NON-NLS-1$
    ModificationPortPm modifPortPm = new ModificationPortPm(posPortPmModif, Collections.singletonList(lienPortPonModifSrc), Collections.singletonList(lienPortPonModifCible));
    PositionPortPon posPortPonModif = new PositionPortPon(1, 1, "OLT2000"); //$NON-NLS-1$
    ModificationPortPon modifPortPon = new ModificationPortPon(posPortPonModif, Collections.singletonList("GPON")); //$NON-NLS-1$
    PE0529_PostRequest creationRequest = new PE0529_PostRequest("PON128", Arrays.asList("PM", "OLT")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    creationRequest.setNumeroGCR("GCR-12345678"); //$NON-NLS-1$
    creationRequest.setMigrationsPortsPm(Collections.singletonList(migrationPortPm));
    creationRequest.setAjoutsPortsPm(Collections.singletonList(ajoutPortPm));
    creationRequest.setSuppressionsPortsPm(Collections.singletonList(suppPortPm));
    creationRequest.setModificationsPortsPm(Collections.singletonList(modifPortPm));
    creationRequest.setModificationsPortsPon(Collections.singletonList(modifPortPon));
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePostRequest(creationRequest, headers);

    // MOCK RES.ressourceLireUn
    Ressource ressource = new RessourcePortPM("LIBRE", "GHYUI893", "BOITIER_E", "PANNEAU_E", 1); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource, "GHYUI893||BOITIER_E||PANNEAU_E||1", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    // MOCK RES.pmCompositeLireUnParReferencePmBytel (portPM Src)
    PMComposite pmComposite = new PMComposite();
    pmComposite.setReferencePmBytel("GHYUI890"); //$NON-NLS-1$
    LienPortPMPon lienPortPMPon = new LienPortPMPon("OPERATIONNEL", new PortPonId("OLT2000", 1, 1)); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, LienPortPMPon> lienPortPMPonMap = new HashMap<>();
    lienPortPMPonMap.put("OLT2000-1-1", lienPortPMPon); //$NON-NLS-1$
    PortPM portPmComposite = new PortPM(1, "OPERATIONNEL", lienPortPMPonMap); //$NON-NLS-1$
    PortPM portPmComposite2 = new PortPM(2, "OPERATIONNEL", lienPortPMPonMap); //$NON-NLS-1$
    Map<Integer, PortPM> portCompositeMap = new HashMap<>();
    portCompositeMap.put(1, portPmComposite);
    portCompositeMap.put(2, portPmComposite2);
    PanneauPM panneauPMComposite = new PanneauPM("PANNEAU_A", "OPERATIONNEL", portCompositeMap); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, PanneauPM> panneauCompositeMap = new HashMap<>();
    panneauCompositeMap.put("PANNEAU_A", panneauPMComposite); //$NON-NLS-1$
    BoitierPM boitierPmComposite = new BoitierPM("BOITIER_A", "OPERATIONNEL", panneauCompositeMap); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, BoitierPM> boitierCompositeMap = new HashMap<>();
    boitierCompositeMap.put("BOITIER_A", boitierPmComposite); //$NON-NLS-1$
    pmComposite.setListeBoitierPM(boitierCompositeMap);
    mockRES_PmCompositeLireUnParReferencePmBytel(RetourFactoryForTU.createOkRetour(), pmComposite, "GHYUI890"); //$NON-NLS-1$

    // MOCK RES.pmCompositeLireUnParReferencePmBytel (portPM Cible) - not needed, already in cache

    // MOCK RES.oltCompositeLireUn
    Set<String> technos = Collections.singleton("XGSPON"); //$NON-NLS-1$
    OltComposite oltCompositeSrc = createOLTCompositeFromPositionPortPm(1, 1, "OLT2000", technos, 0); //$NON-NLS-1$ //$NON-NLS-2$

    PortPON portPonComposite1 = new PortPON(1, "OK", technos, 0); //$NON-NLS-1$
    SurchargePortPON surchargePortPonComposite1 = new SurchargePortPON(0, technos, "OK"); //$NON-NLS-1$
    portPonComposite1.setSurchargePortPON(surchargePortPonComposite1);
    portPonComposite1.getListeOntId().put(1, new OntId(1, null));
    Map<Integer, PortPON> portPonMap = new HashMap<>();
    portPonMap.put(1, portPonComposite1);
    portPonMap.put(3, portPonComposite1);
    CartePON cartePonComposite2 = new CartePON(2, "modeleCarte", "OK"); //$NON-NLS-1$ //$NON-NLS-2$
    cartePonComposite2.setListePortPON(portPonMap);
    oltCompositeSrc.getListeCartePON().put(2, cartePonComposite2);

    mockRES_OltCompositeLireUn(RetourFactoryForTU.createOkRetour(), oltCompositeSrc, "OLT2000"); //$NON-NLS-1$

    // MOCK RES.oltCompositeLireUn - not needed, already in cache

    // MOCK RES.pmCompositeLireUnParReferencePmBytel - not needed, already in cache

    // MOCK RES.oltCompositeLireUn - src - not needed, already in cache

    // MOCK RES.oltCompositeLireUn - cible - not needed, already in cache

    // MOCK RES.oltCompositeLireUn - ajout - not needed, already in cache

    // MOCK RES.oltCompositeLireUn - not needed, already in cache

    // MOCK BL800
    mockBL800(RetourFactoryForTU.createOkRetour());

    // MOCK REX.operationVieReseauCreer
    OperationVieReseau ovr = new OperationVieReseau(ID_OPERATION_VIE_RESEAU, creationRequest.getTypeVieReseau(), "ACQUITTE", creationRequest.getDonneesBrutes()); //$NON-NLS-1$
    ovr.setNumeroGCR("GCR-12345678"); //$NON-NLS-1$
    mockREX_OperationVieReseauCreer(RetourFactoryForTU.createOkRetour(), ovr);

    // MOCK REX.operationVieReseauLireUn
    LocalDateTime creationTime = DateTimeManager.getInstance().now();
    String formattedCreationTime = DateTimeTools.DateTimeFormatPattern.yyyy_dash_MM_dash_dd.format(creationTime);
    OperationVieReseau ovr2 = new OperationVieReseau(ovr.getIdOperationVieReseau(), ovr.getTypeOperationVieReseau(), ovr.getStatut(), ovr.getDonneeBrute());
    ovr2.setDateCreation(creationTime);
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), ovr2, ovr2.getIdOperationVieReseau());

    // MOCK Rex.cleRechercheOperationVieReseauCreerListe
    Retour retourKO = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, "Error in REX"); //$NON-NLS-1$
    List<CleRechercheOperationVieReseau> listeCleRechercheOperationVieReseau = new ArrayList<>();
    listeCleRechercheOperationVieReseau.add(new CleRechercheOperationVieReseau(creationRequest.getTypeVieReseau(), "PM", "GHYUI890", ID_OPERATION_VIE_RESEAU)); //$NON-NLS-1$ //$NON-NLS-2$
    listeCleRechercheOperationVieReseau.add(new CleRechercheOperationVieReseau(creationRequest.getTypeVieReseau(), "PM", "GHYUI893", ID_OPERATION_VIE_RESEAU)); //$NON-NLS-1$ //$NON-NLS-2$
    listeCleRechercheOperationVieReseau.add(new CleRechercheOperationVieReseau(creationRequest.getTypeVieReseau(), "BOITIER", "GHYUI890|BOITIER_D", ID_OPERATION_VIE_RESEAU)); //$NON-NLS-1$ //$NON-NLS-2$
    listeCleRechercheOperationVieReseau.add(new CleRechercheOperationVieReseau(creationRequest.getTypeVieReseau(), "BOITIER", "GHYUI893|BOITIER_E", ID_OPERATION_VIE_RESEAU)); //$NON-NLS-1$ //$NON-NLS-2$
    listeCleRechercheOperationVieReseau.add(new CleRechercheOperationVieReseau(creationRequest.getTypeVieReseau(), "BOITIER", "GHYUI890|BOITIER_A", ID_OPERATION_VIE_RESEAU)); //$NON-NLS-1$ //$NON-NLS-2$
    listeCleRechercheOperationVieReseau.add(new CleRechercheOperationVieReseau(creationRequest.getTypeVieReseau(), "DATE_CREATION", formattedCreationTime, ID_OPERATION_VIE_RESEAU)); //$NON-NLS-1$ //$NON-NLS-2$
    listeCleRechercheOperationVieReseau.add(new CleRechercheOperationVieReseau(creationRequest.getTypeVieReseau(), "OLT", "OLT2000", ID_OPERATION_VIE_RESEAU)); //$NON-NLS-1$ //$NON-NLS-2$
    ListeCleRechercheOperationVieReseauRequest listeCle = new ListeCleRechercheOperationVieReseauRequest(listeCleRechercheOperationVieReseau);
    mockREX_CleRechercheOperationVieReseauCreerListe(retourKO, listeCle);

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPostProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Récupération du résultat de la requête
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    // Tests de retours
    Assert.assertEquals(ErrorCode.KO_00503, response.getErrorCode());
    Assert.assertEquals("Error in REX", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegConsts.SERVICE_TIERS_INDISPONIBLE, reponseactual.getError());
  }

  /**
   * <b>Cas de test: RES.pmCompositeLireUnParReferencePmBytel KO CAT-2/b> (<br/>
   * <b>Entrées:</b> Requête ok<br/>
   * <b>Attendu:</b> ResponseErreur 503 - SERVICE_TIERS_INDISPONIBLE<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_POST_BL100_NOK_027() throws Throwable
  {
    // Preparation de la requête
    PositionPortPm posPortPmMigreSrc = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmMigreCible = new PositionPortPm(1, "PANNEAU_B", "BOITIER_B", "GHYUI891"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    MigrationPortPm migrationPortPm = new MigrationPortPm(posPortPmMigreSrc, posPortPmMigreCible);
    PositionPortPm posPortPmMigreAjout = new PositionPortPm(1, "PANNEAU_C", "BOITIER_C", "GHYUI892"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    LienPortPon lienPortPonAjout = new LienPortPon("OLT2000", 2, 1); //$NON-NLS-1$
    PanneauPm panneauPm = new PanneauPm("PANNEAU_D"); //$NON-NLS-1$
    BoitierPm boitierPm = new BoitierPm("BOITIER_D", "ABCD123"); //$NON-NLS-1$ //$NON-NLS-2$
    AjoutPortPm ajoutPortPm = new AjoutPortPm(posPortPmMigreAjout, Collections.singletonList(lienPortPonAjout), panneauPm, boitierPm);
    PositionPortPm posPortPmSupp = new PositionPortPm(1, "PANNEAU_E", "BOITIER_E", "GHYUI893"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    SuppressionPortPm suppPortPm = new SuppressionPortPm(Collections.singletonList(posPortPmSupp));
    PositionPortPm posPortPmModif = new PositionPortPm(1, "PANNEAU_F", "BOITIER_F", "GHYUI894"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    LienPortPon lienPortPonModifSrc = new LienPortPon("OLT2000", 2, 1); //$NON-NLS-1$
    LienPortPon lienPortPonModifCible = new LienPortPon("OLT2000", 2, 3); //$NON-NLS-1$
    ModificationPortPm modifPortPm = new ModificationPortPm(posPortPmModif, Collections.singletonList(lienPortPonModifSrc), Collections.singletonList(lienPortPonModifCible));
    PE0529_PostRequest creationRequest = new PE0529_PostRequest("PON128", Arrays.asList("PM", "OLT")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    creationRequest.setNumeroGCR("GCR-12345678"); //$NON-NLS-1$
    creationRequest.setMigrationsPortsPm(Collections.singletonList(migrationPortPm));
    creationRequest.setAjoutsPortsPm(Collections.singletonList(ajoutPortPm));
    creationRequest.setSuppressionsPortsPm(Collections.singletonList(suppPortPm));
    creationRequest.setModificationsPortsPm(Collections.singletonList(modifPortPm));
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePostRequest(creationRequest, headers);

    // MOCK RES.ressourceLireUn
    Retour retourKO = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, "Error in RES"); //$NON-NLS-1$
    Ressource ressource = new RessourcePortPM("LIBRE", "GHYUI893", "BOITIER_E", "PANNEAU_E", 1); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    mockRES_RessourceLireUn(retourKO, ressource, "GHYUI893||BOITIER_E||PANNEAU_E||1", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    // MOCK RES.pmCompositeLireUnParReferencePmBytel (portPM Src)
    PMComposite pmCompositeSrc = createPMCompositeFromPositionPortPm(posPortPmMigreSrc);
    mockRES_PmCompositeLireUnParReferencePmBytel(retourKO, pmCompositeSrc, "GHYUI890"); //$NON-NLS-1$

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPostProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Récupération du résultat de la requête
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    // Tests de retours
    Assert.assertEquals(ErrorCode.KO_00503, response.getErrorCode());
    Assert.assertEquals("Error in RES", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegConsts.SERVICE_TIERS_INDISPONIBLE, reponseactual.getError());
  }

  /**
   * <b>Cas de test: RES KO CAT-10/b> (<br/>
   * <b>Entrées:</b> Requête ok<br/>
   * <b>Attendu:</b> ResponseErreur 500 - TRAITEMENT_ARRETE<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_POST_BL100_NOK_028() throws Throwable
  {
    // Preparation de la requête
    PositionPortPm posPortPmMigreSrc = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmMigreCible = new PositionPortPm(1, "PANNEAU_B", "BOITIER_B", "GHYUI891"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    MigrationPortPm migrationPortPm = new MigrationPortPm(posPortPmMigreSrc, posPortPmMigreCible);
    PositionPortPm posPortPmMigreAjout = new PositionPortPm(1, "PANNEAU_C", "BOITIER_C", "GHYUI892"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    LienPortPon lienPortPonAjout = new LienPortPon("OLT2000", 2, 1); //$NON-NLS-1$
    PanneauPm panneauPm = new PanneauPm("PANNEAU_D"); //$NON-NLS-1$
    BoitierPm boitierPm = new BoitierPm("BOITIER_D", "ABCD123"); //$NON-NLS-1$ //$NON-NLS-2$
    AjoutPortPm ajoutPortPm = new AjoutPortPm(posPortPmMigreAjout, Collections.singletonList(lienPortPonAjout), panneauPm, boitierPm);
    PositionPortPm posPortPmSupp = new PositionPortPm(1, "PANNEAU_E", "BOITIER_E", "GHYUI893"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    SuppressionPortPm suppPortPm = new SuppressionPortPm(Collections.singletonList(posPortPmSupp));
    PositionPortPm posPortPmModif = new PositionPortPm(1, "PANNEAU_F", "BOITIER_F", "GHYUI894"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    LienPortPon lienPortPonModifSrc = new LienPortPon("OLT2000", 2, 1); //$NON-NLS-1$
    LienPortPon lienPortPonModifCible = new LienPortPon("OLT2000", 2, 3); //$NON-NLS-1$
    ModificationPortPm modifPortPm = new ModificationPortPm(posPortPmModif, Collections.singletonList(lienPortPonModifSrc), Collections.singletonList(lienPortPonModifCible));
    PE0529_PostRequest creationRequest = new PE0529_PostRequest("PON128", Arrays.asList("PM", "OLT")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    creationRequest.setNumeroGCR("GCR-12345678"); //$NON-NLS-1$
    creationRequest.setMigrationsPortsPm(Collections.singletonList(migrationPortPm));
    creationRequest.setAjoutsPortsPm(Collections.singletonList(ajoutPortPm));
    creationRequest.setSuppressionsPortsPm(Collections.singletonList(suppPortPm));
    creationRequest.setModificationsPortsPm(Collections.singletonList(modifPortPm));
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePostRequest(creationRequest, headers);

    // MOCK RES.ressourceLireUn
    Retour retourKO = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegConsts.TRAITEMENT_ARRETE, "Error in RES"); //$NON-NLS-1$
    Ressource ressource = new RessourcePortPM("LIBRE", "GHYUI893", "BOITIER_E", "PANNEAU_E", 1); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    mockRES_RessourceLireUn(retourKO, ressource, "GHYUI893||BOITIER_E||PANNEAU_E||1", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    // MOCK RES.pmCompositeLireUnParReferencePmBytel (portPM Src)
    PMComposite pmCompositeSrc = createPMCompositeFromPositionPortPm(posPortPmMigreSrc);
    mockRES_PmCompositeLireUnParReferencePmBytel(retourKO, pmCompositeSrc, "GHYUI890"); //$NON-NLS-1$

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPostProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Récupération du résultat de la requête
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    // Tests de retours
    Assert.assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    Assert.assertEquals("Error in RES", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegConsts.TRAITEMENT_ARRETE, reponseactual.getError());
  }

  /**
   * <b>Cas de test: RES.oltCompositeLireUn KO CAT-2/b> (<br/>
   * <b>Entrées:</b> Requête ok<br/>
   * <b>Attendu:</b> ResponseErreur 503 - SERVICE_TIERS_INDISPONIBLE<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_POST_BL100_NOK_029() throws Throwable
  {
    // Preparation de la requête
    PositionPortPm posPortPmMigreSrc = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmMigreCible = new PositionPortPm(1, "PANNEAU_B", "BOITIER_B", "GHYUI891"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    MigrationPortPm migrationPortPm = new MigrationPortPm(posPortPmMigreSrc, posPortPmMigreCible);
    LienPortPon lienPortPonAjout = new LienPortPon("OLT2000", 2, 1); //$NON-NLS-1$
    PanneauPm panneauPm = new PanneauPm("PANNEAU_D"); //$NON-NLS-1$
    BoitierPm boitierPm = new BoitierPm("BOITIER_D", "ABCD123"); //$NON-NLS-1$ //$NON-NLS-2$
    AjoutPortPm ajoutPortPm = new AjoutPortPm(posPortPmMigreCible, Collections.singletonList(lienPortPonAjout), panneauPm, boitierPm);
    PositionPortPm posPortPmSupp = new PositionPortPm(1, "PANNEAU_E", "BOITIER_E", "GHYUI893"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    SuppressionPortPm suppPortPm = new SuppressionPortPm(Collections.singletonList(posPortPmSupp));
    PositionPortPm posPortPmModif = new PositionPortPm(1, "PANNEAU_F", "BOITIER_F", "GHYUI894"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    LienPortPon lienPortPonModifSrc = new LienPortPon("OLT2000", 2, 1); //$NON-NLS-1$
    LienPortPon lienPortPonModifCible = new LienPortPon("OLT2000", 2, 3); //$NON-NLS-1$
    ModificationPortPm modifPortPm = new ModificationPortPm(posPortPmModif, Collections.singletonList(lienPortPonModifSrc), Collections.singletonList(lienPortPonModifCible));
    PositionPortPon posPortPonModif = new PositionPortPon(1, 1, "OLT2000"); //$NON-NLS-1$
    ModificationPortPon modifPortPon = new ModificationPortPon(posPortPonModif, Collections.singletonList("XGSPON")); //$NON-NLS-1$
    PE0529_PostRequest creationRequest = new PE0529_PostRequest("PON128", Arrays.asList("PM", "OLT")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    creationRequest.setNumeroGCR("GCR-12345678"); //$NON-NLS-1$
    creationRequest.setMigrationsPortsPm(Collections.singletonList(migrationPortPm));
    creationRequest.setAjoutsPortsPm(Collections.singletonList(ajoutPortPm));
    creationRequest.setSuppressionsPortsPm(Collections.singletonList(suppPortPm));
    creationRequest.setModificationsPortsPm(Collections.singletonList(modifPortPm));
    creationRequest.setModificationsPortsPon(Collections.singletonList(modifPortPon));
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePostRequest(creationRequest, headers);

    // MOCK RES.ressourceLireUn
    Ressource ressource = new RessourcePortPM("LIBRE", "GHYUI893", "BOITIER_E", "PANNEAU_E", 1); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource, "GHYUI893||BOITIER_E||PANNEAU_E||1", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    // MOCK RES.pmCompositeLireUnParReferencePmBytel (portPM Src)
    PMComposite pmCompositeSrc = createPMCompositeFromPositionPortPm(posPortPmMigreSrc);
    mockRES_PmCompositeLireUnParReferencePmBytel(RetourFactoryForTU.createOkRetour(), pmCompositeSrc, "GHYUI890"); //$NON-NLS-1$

    // MOCK RES.pmCompositeLireUnParReferencePmBytel (portPM Cible)
    PMComposite pmCompositeCible = createPMCompositeFromPositionPortPm(posPortPmMigreCible);
    mockRES_PmCompositeLireUnParReferencePmBytel(RetourFactoryForTU.createOkRetour(), pmCompositeCible, "GHYUI891"); //$NON-NLS-1$

    // MOCK RES.oltCompositeLireUn
    Retour retourKO = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, "Error in RES"); //$NON-NLS-1$
    mockRES_OltCompositeLireUn(retourKO, null, "OLT2000"); //$NON-NLS-1$

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPostProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Récupération du résultat de la requête
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    // Tests de retours
    Assert.assertEquals(ErrorCode.KO_00503, response.getErrorCode());
    Assert.assertEquals("Error in RES", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegConsts.SERVICE_TIERS_INDISPONIBLE, reponseactual.getError());
  }

  /**
   * <b>Cas de test: Exception pendant le processus</b> (<br/>
   * <b>Entrées:</b> Requête ok<br/>
   * <b>Attendu:</b> ResponseErreur 500 - TRAITEMENT_ARRETE<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_POST_BL100_NOK_030() throws Throwable
  {
    // Preparation de la requête
    PositionPortPm posPortPmMigreSrc = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmMigreCible = new PositionPortPm(1, "PANNEAU_B", "BOITIER_B", "GHYUI891"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    MigrationPortPm migrationPortPm = new MigrationPortPm(posPortPmMigreSrc, posPortPmMigreCible);
    LienPortPon lienPortPonAjout = new LienPortPon("OLT2000", 2, 1); //$NON-NLS-1$
    PanneauPm panneauPm = new PanneauPm("PANNEAU_D"); //$NON-NLS-1$
    BoitierPm boitierPm = new BoitierPm("BOITIER_D", "ABCD123"); //$NON-NLS-1$ //$NON-NLS-2$
    AjoutPortPm ajoutPortPm = new AjoutPortPm(posPortPmMigreCible, Collections.singletonList(lienPortPonAjout), panneauPm, boitierPm);
    PositionPortPm posPortPmSupp = new PositionPortPm(1, "PANNEAU_E", "BOITIER_E", "GHYUI893"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    SuppressionPortPm suppPortPm = new SuppressionPortPm(Collections.singletonList(posPortPmSupp));
    PositionPortPm posPortPmModif = new PositionPortPm(1, "PANNEAU_F", "BOITIER_F", "GHYUI894"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    LienPortPon lienPortPonModifSrc = new LienPortPon("OLT2000", 2, 1); //$NON-NLS-1$
    LienPortPon lienPortPonModifCible = new LienPortPon("OLT2000", 2, 3); //$NON-NLS-1$
    ModificationPortPm modifPortPm = new ModificationPortPm(posPortPmModif, Collections.singletonList(lienPortPonModifSrc), Collections.singletonList(lienPortPonModifCible));
    PositionPortPon posPortPonModif = new PositionPortPon(1, 1, "OLT2000"); //$NON-NLS-1$
    ModificationPortPon modifPortPon = new ModificationPortPon(posPortPonModif, Collections.singletonList("XGSPON")); //$NON-NLS-1$
    PE0529_PostRequest creationRequest = new PE0529_PostRequest("PON128", Arrays.asList("PM", "OLT")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    creationRequest.setNumeroGCR("GCR-12345678"); //$NON-NLS-1$
    creationRequest.setMigrationsPortsPm(Collections.singletonList(migrationPortPm));
    creationRequest.setAjoutsPortsPm(Collections.singletonList(ajoutPortPm));
    creationRequest.setSuppressionsPortsPm(Collections.singletonList(suppPortPm));
    creationRequest.setModificationsPortsPm(Collections.singletonList(modifPortPm));
    creationRequest.setModificationsPortsPon(Collections.singletonList(modifPortPon));
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePostRequest(creationRequest, headers);

    // MOCK RES.ressourceLireUn
    RavelException ravelException = new RavelException(ExceptionType.UNDEFINED, ErrorCode.CNCTOR_00010, "Exception"); //$NON-NLS-1$
    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxyMock).times(1);
    EasyMock.expect(_resProxyMock.ressourceLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("GHYUI893||BOITIER_E||PANNEAU_E||1"), EasyMock.eq(TypeRessource.PORT_PM.name()))) //$NON-NLS-1$
        .andThrow(ravelException);

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPostProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Récupération du résultat de la requête
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    // Tests de retours
    Assert.assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    Assert.assertEquals("Exception", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegConsts.TRAITEMENT_ARRETE, reponseactual.getError());
  }

  /**
   * <b>Cas de test: NullPointerException pendant le processus</b> (<br/>
   * <b>Entrées:</b> Requête ok<br/>
   * <b>Attendu:</b> ResponseErreur 500 - TRAITEMENT_ARRETE<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_POST_BL100_NOK_031() throws Throwable
  {
    // Preparation de la requête
    PositionPortPm posPortPmMigreSrc = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmMigreCible = new PositionPortPm(1, "PANNEAU_B", "BOITIER_B", "GHYUI891"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    MigrationPortPm migrationPortPm = new MigrationPortPm(posPortPmMigreSrc, posPortPmMigreCible);
    LienPortPon lienPortPonAjout = new LienPortPon("OLT2000", 2, 1); //$NON-NLS-1$
    PanneauPm panneauPm = new PanneauPm("PANNEAU_D"); //$NON-NLS-1$
    BoitierPm boitierPm = new BoitierPm("BOITIER_D", "ABCD123"); //$NON-NLS-1$ //$NON-NLS-2$
    AjoutPortPm ajoutPortPm = new AjoutPortPm(posPortPmMigreCible, Collections.singletonList(lienPortPonAjout), panneauPm, boitierPm);
    PositionPortPm posPortPmSupp = new PositionPortPm(1, "PANNEAU_E", "BOITIER_E", "GHYUI893"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    SuppressionPortPm suppPortPm = new SuppressionPortPm(Collections.singletonList(posPortPmSupp));
    PositionPortPm posPortPmModif = new PositionPortPm(1, "PANNEAU_F", "BOITIER_F", "GHYUI894"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    LienPortPon lienPortPonModifSrc = new LienPortPon("OLT2000", 2, 1); //$NON-NLS-1$
    LienPortPon lienPortPonModifCible = new LienPortPon("OLT2000", 2, 3); //$NON-NLS-1$
    ModificationPortPm modifPortPm = new ModificationPortPm(posPortPmModif, Collections.singletonList(lienPortPonModifSrc), Collections.singletonList(lienPortPonModifCible));
    PositionPortPon posPortPonModif = new PositionPortPon(1, 1, "OLT2000"); //$NON-NLS-1$
    ModificationPortPon modifPortPon = new ModificationPortPon(posPortPonModif, Collections.singletonList("XGSPON")); //$NON-NLS-1$
    PE0529_PostRequest creationRequest = new PE0529_PostRequest("PON128", Arrays.asList("PM", "OLT")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    creationRequest.setNumeroGCR("GCR-12345678"); //$NON-NLS-1$
    creationRequest.setMigrationsPortsPm(Collections.singletonList(migrationPortPm));
    creationRequest.setAjoutsPortsPm(Collections.singletonList(ajoutPortPm));
    creationRequest.setSuppressionsPortsPm(Collections.singletonList(suppPortPm));
    creationRequest.setModificationsPortsPm(Collections.singletonList(modifPortPm));
    creationRequest.setModificationsPortsPon(Collections.singletonList(modifPortPon));
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePostRequest(creationRequest, headers);

    // MOCK RES.ressourceLireUn
    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxyMock).times(1);
    EasyMock.expect(_resProxyMock.ressourceLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("GHYUI893||BOITIER_E||PANNEAU_E||1"), EasyMock.eq(TypeRessource.PORT_PM.name()))) //$NON-NLS-1$
        .andReturn(null);

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPostProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Récupération du résultat de la requête
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    // Tests de retours
    Assert.assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    Assert.assertEquals(IMegConsts.TRAITEMENT_ARRETE, reponseactual.getError());
  }

  /**
   * <b>Cas de test: REX.operationVieReseauLireUn KO CAT-2/b> (<br/>
   * <b>Entrées:</b> Requête ok<br/>
   * <b>Attendu:</b> ResponseErreur 503 - SERVICE_TIERS_INDISPONIBLE<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_POST_BL100_NOK_033() throws Throwable
  {
    // Preparation de la requête
    PositionPortPm posPortPmMigreSrc = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmMigreCible = new PositionPortPm(2, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    MigrationPortPm migrationPortPm = new MigrationPortPm(posPortPmMigreSrc, posPortPmMigreCible);
    LienPortPon lienPortPonAjout = new LienPortPon("OLT2000", 2, 1); //$NON-NLS-1$
    PanneauPm panneauPm = new PanneauPm("PANNEAU_D"); //$NON-NLS-1$
    BoitierPm boitierPm = new BoitierPm("BOITIER_D", "ABCD123"); //$NON-NLS-1$ //$NON-NLS-2$
    AjoutPortPm ajoutPortPm = new AjoutPortPm(posPortPmMigreCible, Collections.singletonList(lienPortPonAjout), panneauPm, boitierPm);
    PositionPortPm posPortPmSupp = new PositionPortPm(1, "PANNEAU_E", "BOITIER_E", "GHYUI893"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    SuppressionPortPm suppPortPm = new SuppressionPortPm(Collections.singletonList(posPortPmSupp));
    PositionPortPm posPortPmModif = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    LienPortPon lienPortPonModifSrc = new LienPortPon("OLT2000", 2, 1); //$NON-NLS-1$
    LienPortPon lienPortPonModifCible = new LienPortPon("OLT2000", 2, 3); //$NON-NLS-1$
    ModificationPortPm modifPortPm = new ModificationPortPm(posPortPmModif, Collections.singletonList(lienPortPonModifSrc), Collections.singletonList(lienPortPonModifCible));
    PositionPortPon posPortPonModif = new PositionPortPon(1, 1, "OLT2000"); //$NON-NLS-1$
    ModificationPortPon modifPortPon = new ModificationPortPon(posPortPonModif, Collections.singletonList("GPON")); //$NON-NLS-1$
    PE0529_PostRequest creationRequest = new PE0529_PostRequest("PON128", Arrays.asList("PM", "OLT")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    creationRequest.setNumeroGCR("GCR-12345678"); //$NON-NLS-1$
    creationRequest.setMigrationsPortsPm(Collections.singletonList(migrationPortPm));
    creationRequest.setAjoutsPortsPm(Collections.singletonList(ajoutPortPm));
    creationRequest.setSuppressionsPortsPm(Collections.singletonList(suppPortPm));
    creationRequest.setModificationsPortsPm(Collections.singletonList(modifPortPm));
    creationRequest.setModificationsPortsPon(Collections.singletonList(modifPortPon));
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePostRequest(creationRequest, headers);

    // MOCK RES.ressourceLireUn
    Ressource ressource = new RessourcePortPM("LIBRE", "GHYUI893", "BOITIER_E", "PANNEAU_E", 1); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource, "GHYUI893||BOITIER_E||PANNEAU_E||1", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    // MOCK RES.pmCompositeLireUnParReferencePmBytel (portPM Src)
    PMComposite pmComposite = new PMComposite();
    pmComposite.setReferencePmBytel("GHYUI890"); //$NON-NLS-1$
    LienPortPMPon lienPortPMPon = new LienPortPMPon("OPERATIONNEL", new PortPonId("OLT2000", 1, 1)); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, LienPortPMPon> lienPortPMPonMap = new HashMap<>();
    lienPortPMPonMap.put("OLT2000-1-1", lienPortPMPon); //$NON-NLS-1$
    PortPM portPmComposite = new PortPM(1, "OPERATIONNEL", lienPortPMPonMap); //$NON-NLS-1$
    PortPM portPmComposite2 = new PortPM(2, "OPERATIONNEL", lienPortPMPonMap); //$NON-NLS-1$
    Map<Integer, PortPM> portCompositeMap = new HashMap<>();
    portCompositeMap.put(1, portPmComposite);
    portCompositeMap.put(2, portPmComposite2);
    PanneauPM panneauPMComposite = new PanneauPM("PANNEAU_A", "OPERATIONNEL", portCompositeMap); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, PanneauPM> panneauCompositeMap = new HashMap<>();
    panneauCompositeMap.put("PANNEAU_A", panneauPMComposite); //$NON-NLS-1$
    BoitierPM boitierPmComposite = new BoitierPM("BOITIER_A", "OPERATIONNEL", panneauCompositeMap); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, BoitierPM> boitierCompositeMap = new HashMap<>();
    boitierCompositeMap.put("BOITIER_A", boitierPmComposite); //$NON-NLS-1$
    pmComposite.setListeBoitierPM(boitierCompositeMap);
    mockRES_PmCompositeLireUnParReferencePmBytel(RetourFactoryForTU.createOkRetour(), pmComposite, "GHYUI890"); //$NON-NLS-1$

    // MOCK RES.pmCompositeLireUnParReferencePmBytel (portPM Cible) - not needed, already in cache

    // MOCK RES.oltCompositeLireUn
    Set<String> technos = Collections.singleton("XGSPON"); //$NON-NLS-1$
    OltComposite oltCompositeSrc = createOLTCompositeFromPositionPortPm(1, 1, "OLT2000", technos, 0); //$NON-NLS-1$ //$NON-NLS-2$

    PortPON portPonComposite1 = new PortPON(1, "OK", technos, 0); //$NON-NLS-1$
    SurchargePortPON surchargePortPonComposite1 = new SurchargePortPON(0, technos, "OK"); //$NON-NLS-1$
    portPonComposite1.setSurchargePortPON(surchargePortPonComposite1);
    portPonComposite1.getListeOntId().put(1, new OntId(1, null));
    Map<Integer, PortPON> portPonMap = new HashMap<>();
    portPonMap.put(1, portPonComposite1);
    portPonMap.put(3, portPonComposite1);
    CartePON cartePonComposite2 = new CartePON(2, "modeleCarte", "OK"); //$NON-NLS-1$ //$NON-NLS-2$
    cartePonComposite2.setListePortPON(portPonMap);
    oltCompositeSrc.getListeCartePON().put(2, cartePonComposite2);

    mockRES_OltCompositeLireUn(RetourFactoryForTU.createOkRetour(), oltCompositeSrc, "OLT2000"); //$NON-NLS-1$

    // MOCK RES.oltCompositeLireUn - not needed, already in cache

    // MOCK RES.pmCompositeLireUnParReferencePmBytel - not needed, already in cache

    // MOCK RES.oltCompositeLireUn - src - not needed, already in cache

    // MOCK RES.oltCompositeLireUn - cible - not needed, already in cache

    // MOCK RES.oltCompositeLireUn - ajout - not needed, already in cache

    // MOCK RES.oltCompositeLireUn - not needed, already in cache

    // MOCK BL800
    mockBL800(RetourFactoryForTU.createOkRetour());

    // MOCK REX.operationVieReseauCreer
    OperationVieReseau ovr = new OperationVieReseau(ID_OPERATION_VIE_RESEAU, creationRequest.getTypeVieReseau(), "ACQUITTE", creationRequest.getDonneesBrutes()); //$NON-NLS-1$
    ovr.setNumeroGCR("GCR-12345678"); //$NON-NLS-1$
    mockREX_OperationVieReseauCreer(RetourFactoryForTU.createOkRetour(), ovr);

    // MOCK REX.operationVieReseauLireUn
    Retour retourKO = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, "Error in REX"); //$NON-NLS-1$
    mockREX_OperationVieReseauLireUn(retourKO, null, ovr.getIdOperationVieReseau());

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPostProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Récupération du résultat de la requête
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    // Tests de retours
    Assert.assertEquals(ErrorCode.KO_00503, response.getErrorCode());
    Assert.assertEquals("Error in REX", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegConsts.SERVICE_TIERS_INDISPONIBLE, reponseactual.getError());
  }

  /**
   * <b>Cas de test: Fonctionnement OK</b> (<br/>
   * <b>Entrées:</b> Requête avec <br/>
   * <b>Attendu:</b> Response 201<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_POST_BL100_OK_001() throws Throwable
  {
    // Preparation de la requête
    PositionPortPm posPortPmMigreSrc = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmMigreCible = new PositionPortPm(2, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    MigrationPortPm migrationPortPm = new MigrationPortPm(posPortPmMigreSrc, posPortPmMigreCible);
    LienPortPon lienPortPonAjout = new LienPortPon("OLT2000", 2, 1); //$NON-NLS-1$
    PanneauPm panneauPm = new PanneauPm("PANNEAU_D"); //$NON-NLS-1$
    BoitierPm boitierPm = new BoitierPm("BOITIER_D", "ABCD123"); //$NON-NLS-1$ //$NON-NLS-2$
    AjoutPortPm ajoutPortPm = new AjoutPortPm(posPortPmMigreCible, Collections.singletonList(lienPortPonAjout), panneauPm, boitierPm);
    PositionPortPm posPortPmSupp = new PositionPortPm(1, "PANNEAU_E", "BOITIER_E", "GHYUI893"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    SuppressionPortPm suppPortPm = new SuppressionPortPm(Collections.singletonList(posPortPmSupp));
    PositionPortPm posPortPmModif = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    LienPortPon lienPortPonModifSrc = new LienPortPon("OLT2000", 2, 1); //$NON-NLS-1$
    LienPortPon lienPortPonModifCible = new LienPortPon("OLT2000", 2, 3); //$NON-NLS-1$
    ModificationPortPm modifPortPm = new ModificationPortPm(posPortPmModif, Collections.singletonList(lienPortPonModifSrc), Collections.singletonList(lienPortPonModifCible));
    PositionPortPon posPortPonModif = new PositionPortPon(1, 1, "OLT2000"); //$NON-NLS-1$
    ModificationPortPon modifPortPon = new ModificationPortPon(posPortPonModif, Collections.singletonList("GPON")); //$NON-NLS-1$
    PositionPortPon posPortPonSupp = new PositionPortPon(4, 2, "OLT2000"); //$NON-NLS-1$
    SuppressionPortPon suppPortPon = new SuppressionPortPon(posPortPonSupp);
    PE0529_PostRequest creationRequest = new PE0529_PostRequest("PON128", Arrays.asList("PM", "OLT")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    creationRequest.setNumeroGCR("GCR-12345678"); //$NON-NLS-1$
    creationRequest.setMigrationsPortsPm(Collections.singletonList(migrationPortPm));
    creationRequest.setAjoutsPortsPm(Collections.singletonList(ajoutPortPm));
    creationRequest.setSuppressionsPortsPm(Collections.singletonList(suppPortPm));
    creationRequest.setModificationsPortsPm(Collections.singletonList(modifPortPm));
    creationRequest.setModificationsPortsPon(Collections.singletonList(modifPortPon));
    creationRequest.setSuppressionsPortsPon(Collections.singletonList(suppPortPon));
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePostRequest(creationRequest, headers);

    // MOCK RES.ressourceLireUn
    Ressource ressource = new RessourcePortPM("LIBRE", "GHYUI893", "BOITIER_E", "PANNEAU_E", 1); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource, "GHYUI893||BOITIER_E||PANNEAU_E||1", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    // MOCK RES.pmCompositeLireUnParReferencePmBytel (portPM Src)
    PMComposite pmComposite = new PMComposite();
    pmComposite.setReferencePmBytel("GHYUI890"); //$NON-NLS-1$
    LienPortPMPon lienPortPMPon = new LienPortPMPon("OPERATIONNEL", new PortPonId("OLT2000", 1, 1)); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, LienPortPMPon> lienPortPMPonMap = new HashMap<>();
    lienPortPMPonMap.put("OLT2000-1-1", lienPortPMPon); //$NON-NLS-1$
    PortPM portPmComposite = new PortPM(1, "OPERATIONNEL", lienPortPMPonMap); //$NON-NLS-1$
    PortPM portPmComposite2 = new PortPM(2, "OPERATIONNEL", lienPortPMPonMap); //$NON-NLS-1$
    Map<Integer, PortPM> portCompositeMap = new HashMap<>();
    portCompositeMap.put(1, portPmComposite);
    portCompositeMap.put(2, portPmComposite2);
    PanneauPM panneauPMComposite = new PanneauPM("PANNEAU_A", "OPERATIONNEL", portCompositeMap); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, PanneauPM> panneauCompositeMap = new HashMap<>();
    panneauCompositeMap.put("PANNEAU_A", panneauPMComposite); //$NON-NLS-1$
    BoitierPM boitierPmComposite = new BoitierPM("BOITIER_A", "OPERATIONNEL", panneauCompositeMap); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, BoitierPM> boitierCompositeMap = new HashMap<>();
    boitierCompositeMap.put("BOITIER_A", boitierPmComposite); //$NON-NLS-1$
    pmComposite.setListeBoitierPM(boitierCompositeMap);
    mockRES_PmCompositeLireUnParReferencePmBytel(RetourFactoryForTU.createOkRetour(), pmComposite, "GHYUI890"); //$NON-NLS-1$

    // MOCK RES.pmCompositeLireUnParReferencePmBytel (portPM Cible) - not needed, already in cache

    // MOCK RES.oltCompositeLireUn
    Set<String> technos = Collections.singleton("XGSPON"); //$NON-NLS-1$
    OltComposite oltCompositeSrc = createOLTCompositeFromPositionPortPm(1, 1, "OLT2000", technos, 0); //$NON-NLS-1$ //$NON-NLS-2$

    PortPON portPonComposite1 = new PortPON(1, "OK", technos, 0); //$NON-NLS-1$
    SurchargePortPON surchargePortPonComposite1 = new SurchargePortPON(0, technos, "OK"); //$NON-NLS-1$
    portPonComposite1.setSurchargePortPON(surchargePortPonComposite1);
    portPonComposite1.getListeOntId().put(1, new OntId(1, null));
    Map<Integer, PortPON> portPonMap = new HashMap<>();
    portPonMap.put(1, portPonComposite1);
    portPonMap.put(3, portPonComposite1);
    portPonMap.put(4, portPonComposite1);
    CartePON cartePonComposite2 = new CartePON(2, "modeleCarte", "OK"); //$NON-NLS-1$ //$NON-NLS-2$
    cartePonComposite2.setListePortPON(portPonMap);
    oltCompositeSrc.getListeCartePON().put(2, cartePonComposite2);

    mockRES_OltCompositeLireUn(RetourFactoryForTU.createOkRetour(), oltCompositeSrc, "OLT2000"); //$NON-NLS-1$

    // MOCK RES.oltCompositeLireUn - not needed, already in cache

    // MOCK RES.pmCompositeLireUnParReferencePmBytel - not needed, already in cache

    // MOCK RES.oltCompositeLireUn - src - not needed, already in cache

    // MOCK RES.oltCompositeLireUn - cible - not needed, already in cache

    // MOCK RES.oltCompositeLireUn - ajout - not needed, already in cache

    // MOCK RES.oltCompositeLireUn - Modif Pon - not needed, already in cache

    // MOCK RES.oltCompositeLireUn - Supp Pon - not needed, already in cache

    // MOCK RES.ressourceLireUn - Supp Pon
    RessourceOntId ressourceOntId = new RessourceOntId("GELE", "", 0, 0, 0); //$NON-NLS-1$ //$NON-NLS-2$
    mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressourceOntId, "OLT2000-2-4-1", TypeRessource.ONT_ID.name()); //$NON-NLS-1$

    // MOCK BL800
    mockBL800(RetourFactoryForTU.createOkRetour());

    // MOCK REX.operationVieReseauCreer
    OperationVieReseau ovr = new OperationVieReseau(ID_OPERATION_VIE_RESEAU, creationRequest.getTypeVieReseau(), "ACQUITTE", creationRequest.getDonneesBrutes()); //$NON-NLS-1$
    ovr.setNumeroGCR("GCR-12345678"); //$NON-NLS-1$
    mockREX_OperationVieReseauCreer(RetourFactoryForTU.createOkRetour(), ovr);

    // MOCK REX.operationVieReseauLireUn
    LocalDateTime creationTime = DateTimeManager.getInstance().now();
    String formattedCreationTime = DateTimeTools.DateTimeFormatPattern.yyyy_dash_MM_dash_dd.format(creationTime);
    OperationVieReseau ovr2 = new OperationVieReseau(ovr.getIdOperationVieReseau(), ovr.getTypeOperationVieReseau(), ovr.getStatut(), ovr.getDonneeBrute());
    ovr2.setDateCreation(creationTime);
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), ovr2, ovr2.getIdOperationVieReseau());

    // MOCK Rex.cleRechercheOperationVieReseauCreerListe
    List<CleRechercheOperationVieReseau> listeCleRechercheOperationVieReseau = new ArrayList<>();
    listeCleRechercheOperationVieReseau.add(new CleRechercheOperationVieReseau(creationRequest.getTypeVieReseau(), "PM", "GHYUI890", ID_OPERATION_VIE_RESEAU)); //$NON-NLS-1$ //$NON-NLS-2$
    listeCleRechercheOperationVieReseau.add(new CleRechercheOperationVieReseau(creationRequest.getTypeVieReseau(), "PM", "GHYUI893", ID_OPERATION_VIE_RESEAU)); //$NON-NLS-1$ //$NON-NLS-2$
    listeCleRechercheOperationVieReseau.add(new CleRechercheOperationVieReseau(creationRequest.getTypeVieReseau(), "BOITIER", "GHYUI890|BOITIER_D", ID_OPERATION_VIE_RESEAU)); //$NON-NLS-1$ //$NON-NLS-2$
    listeCleRechercheOperationVieReseau.add(new CleRechercheOperationVieReseau(creationRequest.getTypeVieReseau(), "BOITIER", "GHYUI893|BOITIER_E", ID_OPERATION_VIE_RESEAU)); //$NON-NLS-1$ //$NON-NLS-2$
    listeCleRechercheOperationVieReseau.add(new CleRechercheOperationVieReseau(creationRequest.getTypeVieReseau(), "BOITIER", "GHYUI890|BOITIER_A", ID_OPERATION_VIE_RESEAU)); //$NON-NLS-1$ //$NON-NLS-2$
    listeCleRechercheOperationVieReseau.add(new CleRechercheOperationVieReseau(creationRequest.getTypeVieReseau(), "DATE_CREATION", formattedCreationTime, ID_OPERATION_VIE_RESEAU)); //$NON-NLS-1$ //$NON-NLS-2$
    listeCleRechercheOperationVieReseau.add(new CleRechercheOperationVieReseau(creationRequest.getTypeVieReseau(), "OLT", "OLT2000", ID_OPERATION_VIE_RESEAU)); //$NON-NLS-1$ //$NON-NLS-2$
    ListeCleRechercheOperationVieReseauRequest listeCle = new ListeCleRechercheOperationVieReseauRequest(listeCleRechercheOperationVieReseau);
    mockREX_CleRechercheOperationVieReseauCreerListe(RetourFactoryForTU.createOkRetour(), listeCle);

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPostProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Récupération du résultat de la requête
    String resp = response.getGenericResponse().getResult();
    PE0529_PostResponse reponseactual = RavelJsonTools.getInstance().fromJson(resp, PE0529_PostResponse.class);

    // Test de retouurs
    Assert.assertEquals(ErrorCode.OK_00201, response.getErrorCode());
    Assert.assertEquals(ID_OPERATION_VIE_RESEAU, reponseactual.getIdOperationVieReseau());
  }

  /**
   * <b>Cas de test: Fonctionnement OK avec seulement ajoutPM</b> (<br/>
   * <b>Entrées:</b> Requête avec <br/>
   * <b>Attendu:</b> Response 201<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_POST_BL100_OK_002() throws Throwable
  {
    // Preparation de la requête
    PositionPortPm posPortPmAjout1 = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmAjout2 = new PositionPortPm(2, "PANNEAU_A", "BOITIER_A", "GHYUI891"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    LienPortPon lienPortPonAjout1 = new LienPortPon("OLT2000", 2, 1); //$NON-NLS-1$
    LienPortPon lienPortPonAjout2 = new LienPortPon("OLT2000", 2, 2); //$NON-NLS-1$
    PanneauPm panneauPm = new PanneauPm("PANNEAU_A"); //$NON-NLS-1$
    BoitierPm boitierPm = new BoitierPm("BOITIER_A", "ABCD123"); //$NON-NLS-1$ //$NON-NLS-2$
    AjoutPortPm ajoutPortPm1 = new AjoutPortPm(posPortPmAjout1, Collections.singletonList(lienPortPonAjout1), panneauPm, boitierPm);
    AjoutPortPm ajoutPortPm2 = new AjoutPortPm(posPortPmAjout2, Collections.singletonList(lienPortPonAjout2), panneauPm, boitierPm);
    PE0529_PostRequest creationRequest = new PE0529_PostRequest("PON128", Arrays.asList("PM", "OLT")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    creationRequest.setNumeroGCR("GCR-12345678"); //$NON-NLS-1$
    creationRequest.setAjoutsPortsPm(Arrays.asList(ajoutPortPm1, ajoutPortPm2));
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePostRequest(creationRequest, headers);

    // MOCK RES.oltCompositeLireUn - ajout
    Set<String> technos = Collections.singleton("XGSPON"); //$NON-NLS-1$
    OltComposite oltCompositeAjout = createOLTCompositeFromPositionPortPm(1, 2, "OLT2000", technos, 0); //$NON-NLS-1$ //$NON-NLS-2$

    PortPON portPonComposite2 = new PortPON(1, "OK", technos, 0); //$NON-NLS-1$
    SurchargePortPON surchargePortPonComposite1 = new SurchargePortPON(0, technos, "OK"); //$NON-NLS-1$
    portPonComposite2.setSurchargePortPON(surchargePortPonComposite1);
    portPonComposite2.getListeOntId().put(2, new OntId(2, null));
    Map<Integer, PortPON> portPonMap = new HashMap<>();
    portPonMap.put(1, portPonComposite2);
    portPonMap.put(2, portPonComposite2);
    CartePON cartePonComposite2 = new CartePON(2, "modeleCarte", "OK"); //$NON-NLS-1$ //$NON-NLS-2$
    cartePonComposite2.setListePortPON(portPonMap);

    oltCompositeAjout.getListeCartePON().put(2, cartePonComposite2);
    mockRES_OltCompositeLireUn(RetourFactoryForTU.createOkRetour(), oltCompositeAjout, "OLT2000"); //$NON-NLS-1$

    // MOCK RES.oltCompositeLireUn - ajout - not needed, already in cache

    // MOCK BL800
    mockBL800(RetourFactoryForTU.createOkRetour());

    // MOCK REX.operationVieReseauCreer
    OperationVieReseau ovr = new OperationVieReseau(ID_OPERATION_VIE_RESEAU, creationRequest.getTypeVieReseau(), "ACQUITTE", creationRequest.getDonneesBrutes()); //$NON-NLS-1$
    ovr.setNumeroGCR("GCR-12345678"); //$NON-NLS-1$
    mockREX_OperationVieReseauCreer(RetourFactoryForTU.createOkRetour(), ovr);

    // MOCK REX.operationVieReseauLireUn
    LocalDateTime creationTime = DateTimeManager.getInstance().now();
    String formattedCreationTime = DateTimeTools.DateTimeFormatPattern.yyyy_dash_MM_dash_dd.format(creationTime);
    OperationVieReseau ovr2 = new OperationVieReseau(ovr.getIdOperationVieReseau(), ovr.getTypeOperationVieReseau(), ovr.getStatut(), ovr.getDonneeBrute());
    ovr2.setDateCreation(creationTime);
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), ovr2, ovr2.getIdOperationVieReseau());

    // MOCK Rex.cleRechercheOperationVieReseauCreerListe
    List<CleRechercheOperationVieReseau> listeCleRechercheOperationVieReseau = new ArrayList<>();
    listeCleRechercheOperationVieReseau.add(new CleRechercheOperationVieReseau(creationRequest.getTypeVieReseau(), "PM", "GHYUI890", ID_OPERATION_VIE_RESEAU)); //$NON-NLS-1$ //$NON-NLS-2$
    listeCleRechercheOperationVieReseau.add(new CleRechercheOperationVieReseau(creationRequest.getTypeVieReseau(), "PM", "GHYUI891", ID_OPERATION_VIE_RESEAU)); //$NON-NLS-1$ //$NON-NLS-2$
    listeCleRechercheOperationVieReseau.add(new CleRechercheOperationVieReseau(creationRequest.getTypeVieReseau(), "BOITIER", "GHYUI891|BOITIER_A", ID_OPERATION_VIE_RESEAU)); //$NON-NLS-1$ //$NON-NLS-2$
    listeCleRechercheOperationVieReseau.add(new CleRechercheOperationVieReseau(creationRequest.getTypeVieReseau(), "BOITIER", "GHYUI890|BOITIER_A", ID_OPERATION_VIE_RESEAU)); //$NON-NLS-1$ //$NON-NLS-2$
    listeCleRechercheOperationVieReseau.add(new CleRechercheOperationVieReseau(creationRequest.getTypeVieReseau(), "DATE_CREATION", formattedCreationTime, ID_OPERATION_VIE_RESEAU)); //$NON-NLS-1$ //$NON-NLS-2$
    listeCleRechercheOperationVieReseau.add(new CleRechercheOperationVieReseau(creationRequest.getTypeVieReseau(), "OLT", "OLT2000", ID_OPERATION_VIE_RESEAU)); //$NON-NLS-1$ //$NON-NLS-2$
    ListeCleRechercheOperationVieReseauRequest listeCle = new ListeCleRechercheOperationVieReseauRequest(listeCleRechercheOperationVieReseau);
    mockREX_CleRechercheOperationVieReseauCreerListe(RetourFactoryForTU.createOkRetour(), listeCle);

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPostProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Récupération du résultat de la requête
    String resp = response.getGenericResponse().getResult();
    PE0529_PostResponse reponseactual = RavelJsonTools.getInstance().fromJson(resp, PE0529_PostResponse.class);

    // Test de retours
    Assert.assertEquals(ErrorCode.OK_00201, response.getErrorCode());
    Assert.assertEquals(ID_OPERATION_VIE_RESEAU, reponseactual.getIdOperationVieReseau());
  }

  /**
   * <b>Cas de test: Suppression Port Pon - RES.ressourceLireUn ONT_ID NOK DONNEE_INCONNUE</b> (<br/>
   * <b>Entrées:</b> Requête OK <br/>
   * <b>Attendu:</b> Response 201<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_POST_BL100_OK_003() throws Throwable
  {
    // Preparation de la requête
    PositionPortPm posPortPmMigreSrc = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmMigreCible = new PositionPortPm(2, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    MigrationPortPm migrationPortPm = new MigrationPortPm(posPortPmMigreSrc, posPortPmMigreCible);
    LienPortPon lienPortPonAjout = new LienPortPon("OLT2000", 2, 1); //$NON-NLS-1$
    PanneauPm panneauPm = new PanneauPm("PANNEAU_D"); //$NON-NLS-1$
    BoitierPm boitierPm = new BoitierPm("BOITIER_D", "ABCD123"); //$NON-NLS-1$ //$NON-NLS-2$
    AjoutPortPm ajoutPortPm = new AjoutPortPm(posPortPmMigreCible, Collections.singletonList(lienPortPonAjout), panneauPm, boitierPm);
    PositionPortPm posPortPmSupp = new PositionPortPm(1, "PANNEAU_E", "BOITIER_E", "GHYUI893"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    SuppressionPortPm suppPortPm = new SuppressionPortPm(Collections.singletonList(posPortPmSupp));
    PositionPortPm posPortPmModif = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    LienPortPon lienPortPonModifSrc = new LienPortPon("OLT2000", 2, 1); //$NON-NLS-1$
    LienPortPon lienPortPonModifCible = new LienPortPon("OLT2000", 2, 3); //$NON-NLS-1$
    ModificationPortPm modifPortPm = new ModificationPortPm(posPortPmModif, Collections.singletonList(lienPortPonModifSrc), Collections.singletonList(lienPortPonModifCible));
    PositionPortPon posPortPonModif = new PositionPortPon(1, 1, "OLT2000"); //$NON-NLS-1$
    ModificationPortPon modifPortPon = new ModificationPortPon(posPortPonModif, Collections.singletonList("GPON")); //$NON-NLS-1$
    PositionPortPon posPortPonSupp = new PositionPortPon(4, 2, "OLT2000"); //$NON-NLS-1$
    SuppressionPortPon suppPortPon = new SuppressionPortPon(posPortPonSupp);
    PE0529_PostRequest creationRequest = new PE0529_PostRequest("PON128", Arrays.asList("PM", "OLT")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    creationRequest.setNumeroGCR("GCR-12345678"); //$NON-NLS-1$
    creationRequest.setMigrationsPortsPm(Collections.singletonList(migrationPortPm));
    creationRequest.setAjoutsPortsPm(Collections.singletonList(ajoutPortPm));
    creationRequest.setSuppressionsPortsPm(Collections.singletonList(suppPortPm));
    creationRequest.setModificationsPortsPm(Collections.singletonList(modifPortPm));
    creationRequest.setModificationsPortsPon(Collections.singletonList(modifPortPon));
    creationRequest.setSuppressionsPortsPon(Collections.singletonList(suppPortPon));
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePostRequest(creationRequest, headers);

    // MOCK RES.ressourceLireUn
    Ressource ressource = new RessourcePortPM("LIBRE", "GHYUI893", "BOITIER_E", "PANNEAU_E", 1); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource, "GHYUI893||BOITIER_E||PANNEAU_E||1", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    // MOCK RES.pmCompositeLireUnParReferencePmBytel (portPM Src)
    PMComposite pmComposite = new PMComposite();
    pmComposite.setReferencePmBytel("GHYUI890"); //$NON-NLS-1$
    LienPortPMPon lienPortPMPon = new LienPortPMPon("OPERATIONNEL", new PortPonId("OLT2000", 1, 1)); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, LienPortPMPon> lienPortPMPonMap = new HashMap<>();
    lienPortPMPonMap.put("OLT2000-1-1", lienPortPMPon); //$NON-NLS-1$
    PortPM portPmComposite = new PortPM(1, "OPERATIONNEL", lienPortPMPonMap); //$NON-NLS-1$
    PortPM portPmComposite2 = new PortPM(2, "OPERATIONNEL", lienPortPMPonMap); //$NON-NLS-1$
    Map<Integer, PortPM> portCompositeMap = new HashMap<>();
    portCompositeMap.put(1, portPmComposite);
    portCompositeMap.put(2, portPmComposite2);
    PanneauPM panneauPMComposite = new PanneauPM("PANNEAU_A", "OPERATIONNEL", portCompositeMap); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, PanneauPM> panneauCompositeMap = new HashMap<>();
    panneauCompositeMap.put("PANNEAU_A", panneauPMComposite); //$NON-NLS-1$
    BoitierPM boitierPmComposite = new BoitierPM("BOITIER_A", "OPERATIONNEL", panneauCompositeMap); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, BoitierPM> boitierCompositeMap = new HashMap<>();
    boitierCompositeMap.put("BOITIER_A", boitierPmComposite); //$NON-NLS-1$
    pmComposite.setListeBoitierPM(boitierCompositeMap);
    mockRES_PmCompositeLireUnParReferencePmBytel(RetourFactoryForTU.createOkRetour(), pmComposite, "GHYUI890"); //$NON-NLS-1$

    // MOCK RES.pmCompositeLireUnParReferencePmBytel (portPM Cible) - not needed, already in cache

    // MOCK RES.oltCompositeLireUn
    Set<String> technos = Collections.singleton("XGSPON"); //$NON-NLS-1$
    OltComposite oltCompositeSrc = createOLTCompositeFromPositionPortPm(1, 1, "OLT2000", technos, 0); //$NON-NLS-1$ //$NON-NLS-2$

    PortPON portPonComposite1 = new PortPON(1, "OK", technos, 0); //$NON-NLS-1$
    SurchargePortPON surchargePortPonComposite1 = new SurchargePortPON(0, technos, "OK"); //$NON-NLS-1$
    portPonComposite1.setSurchargePortPON(surchargePortPonComposite1);
    portPonComposite1.getListeOntId().put(1, new OntId(1, null));
    Map<Integer, PortPON> portPonMap = new HashMap<>();
    portPonMap.put(1, portPonComposite1);
    portPonMap.put(3, portPonComposite1);
    portPonMap.put(4, portPonComposite1);
    CartePON cartePonComposite2 = new CartePON(2, "modeleCarte", "OK"); //$NON-NLS-1$ //$NON-NLS-2$
    cartePonComposite2.setListePortPON(portPonMap);
    oltCompositeSrc.getListeCartePON().put(2, cartePonComposite2);

    mockRES_OltCompositeLireUn(RetourFactoryForTU.createOkRetour(), oltCompositeSrc, "OLT2000"); //$NON-NLS-1$

    // MOCK RES.oltCompositeLireUn - not needed, already in cache

    // MOCK RES.pmCompositeLireUnParReferencePmBytel - not needed, already in cache

    // MOCK RES.oltCompositeLireUn - src - not needed, already in cache

    // MOCK RES.oltCompositeLireUn - cible - not needed, already in cache

    // MOCK RES.oltCompositeLireUn - ajout - not needed, already in cache

    // MOCK RES.oltCompositeLireUn - Modif Pon - not needed, already in cache

    // MOCK RES.oltCompositeLireUn - Supp Pon - not needed, already in cache

    // MOCK RES.ressourceLireUn - Supp Pon
    Retour retourKO = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "Error in RES"); //$NON-NLS-1$
    mockRES_RessourceLireUn(retourKO, null, "OLT2000-2-4-1", TypeRessource.ONT_ID.name()); //$NON-NLS-1$

    // MOCK BL800
    mockBL800(RetourFactoryForTU.createOkRetour());

    // MOCK REX.operationVieReseauCreer
    OperationVieReseau ovr = new OperationVieReseau(ID_OPERATION_VIE_RESEAU, creationRequest.getTypeVieReseau(), "ACQUITTE", creationRequest.getDonneesBrutes()); //$NON-NLS-1$
    ovr.setNumeroGCR("GCR-12345678"); //$NON-NLS-1$
    mockREX_OperationVieReseauCreer(RetourFactoryForTU.createOkRetour(), ovr);

    // MOCK REX.operationVieReseauLireUn
    LocalDateTime creationTime = DateTimeManager.getInstance().now();
    String formattedCreationTime = DateTimeTools.DateTimeFormatPattern.yyyy_dash_MM_dash_dd.format(creationTime);
    OperationVieReseau ovr2 = new OperationVieReseau(ovr.getIdOperationVieReseau(), ovr.getTypeOperationVieReseau(), ovr.getStatut(), ovr.getDonneeBrute());
    ovr2.setDateCreation(creationTime);
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), ovr2, ovr2.getIdOperationVieReseau());

    // MOCK Rex.cleRechercheOperationVieReseauCreerListe
    List<CleRechercheOperationVieReseau> listeCleRechercheOperationVieReseau = new ArrayList<>();
    listeCleRechercheOperationVieReseau.add(new CleRechercheOperationVieReseau(creationRequest.getTypeVieReseau(), "PM", "GHYUI890", ID_OPERATION_VIE_RESEAU)); //$NON-NLS-1$ //$NON-NLS-2$
    listeCleRechercheOperationVieReseau.add(new CleRechercheOperationVieReseau(creationRequest.getTypeVieReseau(), "PM", "GHYUI893", ID_OPERATION_VIE_RESEAU)); //$NON-NLS-1$ //$NON-NLS-2$
    listeCleRechercheOperationVieReseau.add(new CleRechercheOperationVieReseau(creationRequest.getTypeVieReseau(), "BOITIER", "GHYUI890|BOITIER_D", ID_OPERATION_VIE_RESEAU)); //$NON-NLS-1$ //$NON-NLS-2$
    listeCleRechercheOperationVieReseau.add(new CleRechercheOperationVieReseau(creationRequest.getTypeVieReseau(), "BOITIER", "GHYUI893|BOITIER_E", ID_OPERATION_VIE_RESEAU)); //$NON-NLS-1$ //$NON-NLS-2$
    listeCleRechercheOperationVieReseau.add(new CleRechercheOperationVieReseau(creationRequest.getTypeVieReseau(), "BOITIER", "GHYUI890|BOITIER_A", ID_OPERATION_VIE_RESEAU)); //$NON-NLS-1$ //$NON-NLS-2$
    listeCleRechercheOperationVieReseau.add(new CleRechercheOperationVieReseau(creationRequest.getTypeVieReseau(), "DATE_CREATION", formattedCreationTime, ID_OPERATION_VIE_RESEAU)); //$NON-NLS-1$ //$NON-NLS-2$
    listeCleRechercheOperationVieReseau.add(new CleRechercheOperationVieReseau(creationRequest.getTypeVieReseau(), "OLT", "OLT2000", ID_OPERATION_VIE_RESEAU)); //$NON-NLS-1$ //$NON-NLS-2$
    ListeCleRechercheOperationVieReseauRequest listeCle = new ListeCleRechercheOperationVieReseauRequest(listeCleRechercheOperationVieReseau);
    mockREX_CleRechercheOperationVieReseauCreerListe(RetourFactoryForTU.createOkRetour(), listeCle);

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPostProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Récupération du résultat de la requête
    String resp = response.getGenericResponse().getResult();
    PE0529_PostResponse reponseactual = RavelJsonTools.getInstance().fromJson(resp, PE0529_PostResponse.class);

    // Test de retouurs
    Assert.assertEquals(ErrorCode.OK_00201, response.getErrorCode());
    Assert.assertEquals(ID_OPERATION_VIE_RESEAU, reponseactual.getIdOperationVieReseau());
  }

  /**
   *
   * @throws Exception
   *           On errors Thrown in case of error during switch in attributes of parent class
   */
  @Before
  public void setUp() throws Exception
  {
    _processInstance = new PE0529_OperationVieReseau();
    _processInstance.initializeContext();

    _tracabilite = new Tracabilite();

    PowerMock.resetAll();

    PowerMock.mockStaticStrict(REXProxy.class);
    PowerMock.mockStaticStrict(RESProxy.class);
    PowerMock.mockStaticStrict(BL800_ObtenirSequence.class);
    PowerMock.mockStaticNice(BL800_ObtenirSequenceBuilder.class);
  }

  /**
   * Method that does the needed clean up.<br/>
   *
   * <b>Entrées:</b> N/A for this test method. <br/>
   * <b>Attendu:</b> Clean up of some of our data.
   *
   */
  @After
  public void tearDown()
  {
    _processInstance = null;
  }

  /**
   * Add custom headers
   *
   * @param requestId_p
   *          {@link String}
   * @param process_p
   *          {@link String}
   * @param source_p
   *          {@link String}
   * @param messageId_p
   *          {@link String}
   * @param actionId_p
   *          {@link String}
   * @param authorization_p
   *          {@link String}
   * @return {@link List}
   */
  private List<RequestHeader> addXHeaders(String requestId_p, String process_p, String source_p, String messageId_p, String actionId_p, String authorization_p)
  {
    List<RequestHeader> headers = new ArrayList<>();
    RequestHeader hdr = new RequestHeader();

    hdr.setName(IHttpHeadersConsts.CONTENT_TYPE);
    hdr.setValue(MediaType.APPLICATION_JSON);
    headers.add(hdr);

    if (requestId_p != null)
    {
      hdr = new RequestHeader();
      hdr.setName(IHttpHeadersConsts.X_REQUEST_ID);
      hdr.setValue(requestId_p);
      headers.add(hdr);
    }

    if (source_p != null)
    {
      hdr = new RequestHeader();
      hdr.setName(IHttpHeadersConsts.X_SOURCE);
      hdr.setValue(source_p);
      headers.add(hdr);
    }

    if (process_p != null)
    {
      hdr = new RequestHeader();
      hdr.setName(IHttpHeadersConsts.X_PROCESS);
      hdr.setValue(process_p);
      headers.add(hdr);
    }

    if (messageId_p != null)
    {
      hdr = new RequestHeader();
      hdr.setName(IHttpHeadersConsts.X_MESSAGE_ID);
      hdr.setValue(messageId_p);
      headers.add(hdr);
    }

    if (actionId_p != null)
    {
      hdr = new RequestHeader();
      hdr.setName(IHttpHeadersConsts.X_ACTION_ID);
      hdr.setValue(actionId_p);
      headers.add(hdr);
    }

    if (authorization_p != null)
    {
      hdr = new RequestHeader();
      hdr.setName(IHttpHeadersConsts.AUTHORIZATION);
      hdr.setValue(authorization_p);
      headers.add(hdr);
    }

    return headers;

  }

  /**
   * Vérifie les champs d'erreur STI
   *
   * @param expected
   *          {@link Map} contenant la liste des messages d'erreurs et champs associés
   * @param actualDescription
   *          {@link String} Description reelle issue du retour du processus
   */
  private void checkBodyStiErrors(Map<String, Set<String>> expected, String actualDescription)
  {
    Map<String, Set<String>> actual = new HashMap<>();
    String[] errors = actualDescription.split("}."); //$NON-NLS-1$
    for (String error : errors)
    {
      String[] split = error.split(" \\{"); //$NON-NLS-1$
      String message = split[0];
      String[] paths = split[1].split(", "); //$NON-NLS-1$
      Set<String> elements = new HashSet<>(Arrays.asList(paths));
      actual.put(message, elements);
    }

    Assert.assertEquals(expected, actual);
  }

  /**
   * Creation d'un OLT Composite
   *
   * @param positionPortPon_p
   *          Position du port PON
   * @param positionCartePon_p
   *          Position de la carte PON
   * @param nomOLT
   *          Nom de l'OLT
   * @param technos_p
   *          Technologies compatibles
   * @param debitGarantieCapaciteAllouee_p
   *          Débit
   * @return {@link OltComposite}
   */
  private OltComposite createOLTCompositeFromPositionPortPm(int positionPortPon_p, int positionCartePon_p, String nomOLT, Set<String> technos_p, int debitGarantieCapaciteAllouee_p)
  {
    PortPON portPonComposite = new PortPON(positionPortPon_p, "OK", technos_p, 0); //$NON-NLS-1$
    SurchargePortPON surchargePortPonComposite = new SurchargePortPON(debitGarantieCapaciteAllouee_p, technos_p, "OK"); //$NON-NLS-1$
    portPonComposite.setSurchargePortPON(surchargePortPonComposite);
    Map<Integer, PortPON> portPonMap = new HashMap<>();
    portPonMap.put(positionPortPon_p, portPonComposite);
    CartePON cartePonComposite = new CartePON(positionCartePon_p, "modeleCarte", "OK"); //$NON-NLS-1$ //$NON-NLS-2$
    cartePonComposite.setListePortPON(portPonMap);
    Map<Integer, CartePON> cartePonMap = new HashMap<>();
    cartePonMap.put(positionCartePon_p, cartePonComposite);
    OltComposite oltComposite = new OltComposite(nomOLT, "", "", "", ""); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    oltComposite.setListeCartePON(cartePonMap);
    return oltComposite;
  }

  /**
   * Creation d'un PM Composite
   *
   * @param posPortPm_p
   *          {@link PositionPortPm}
   * @return {@link PMComposite}
   */
  private PMComposite createPMCompositeFromPositionPortPm(PositionPortPm posPortPm_p)
  {
    PMComposite pmComposite = new PMComposite();
    pmComposite.setReferencePmBytel(posPortPm_p.getReferencePmBytel());
    LienPortPMPon lienPortPMPon = new LienPortPMPon("OPERATIONNEL", new PortPonId("OLT2000", 1, 1)); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, LienPortPMPon> lienPortPMPonMap = new HashMap<>();
    lienPortPMPonMap.put("OLT2000-1-1", lienPortPMPon); //$NON-NLS-1$
    PortPM portPmComposite = new PortPM(posPortPm_p.getPositionPort(), "OPERATIONNEL", lienPortPMPonMap); //$NON-NLS-1$
    PortPM portPmComposite2 = new PortPM(2, "OPERATIONNEL", lienPortPMPonMap); //$NON-NLS-1$
    Map<Integer, PortPM> portCompositeMap = new HashMap<>();
    portCompositeMap.put(1, portPmComposite);
    portCompositeMap.put(2, portPmComposite2);
    PanneauPM panneauPMComposite = new PanneauPM(posPortPm_p.getNomPanneau(), "OPERATIONNEL", portCompositeMap); //$NON-NLS-1$
    Map<String, PanneauPM> panneauCompositeMap = new HashMap<>();
    panneauCompositeMap.put(posPortPm_p.getNomPanneau(), panneauPMComposite);
    BoitierPM boitierPmComposite = new BoitierPM(posPortPm_p.getReferenceBoitierPm(), "OPERATIONNEL", panneauCompositeMap); //$NON-NLS-1$
    Map<String, BoitierPM> boitierCompositeMap = new HashMap<>();
    boitierCompositeMap.put(posPortPm_p.getReferenceBoitierPm(), boitierPmComposite);
    pmComposite.setListeBoitierPM(boitierCompositeMap);
    return pmComposite;
  }

  /**
   * Mock pour BL800
   *
   * @param retour_p
   *          {@link Retour}
   * @throws Exception
   *           if error
   */
  private void mockBL800(Retour retour_p) throws Exception
  {
    PowerMock.expectNew(BL800_ObtenirSequenceBuilder.class).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.tracabilite(_tracabilite)).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.code(UniqueIdConstant.ID_OPERATION_VIE_RESEAU)).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.build()).andReturn(_bl800Mock);
    EasyMock.expect(_bl800Mock.execute(_processInstance)).andReturn(ID_OPERATION_VIE_RESEAU);
    EasyMock.expect(_bl800Mock.getRetour()).andReturn(retour_p).anyTimes();
  }

  /**
   * Mock pour RES.oltCompositeLireUn
   *
   * @param retour_p
   *          Retour attendu
   * @param oltComposite_p
   *          OltComposite attendue
   * @param nomOlt_p
   *          Nom de l'olt en paramètre
   * @throws Exception
   *           en cas d'exception
   */
  private void mockRES_OltCompositeLireUn(Retour retour_p, OltComposite oltComposite_p, String nomOlt_p) throws Exception
  {
    ConnectorResponse<Retour, OltComposite> connectorResponse = new ConnectorResponse<>(retour_p, oltComposite_p);
    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxyMock).times(1);
    EasyMock.expect(_resProxyMock.oltCompositeLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(nomOlt_p))).andReturn(connectorResponse);
  }

  /**
   * Mock pour RES.pmCompositeLireUnParReferencePmBytel
   *
   * @param retour_p
   *          Retour attendu
   * @param pmComposite_p
   *          PMComposite attendue
   * @param referenceBytel_p
   *          Reference Bytel en paramètre
   * @throws Exception
   *           en cas d'exception
   */
  private void mockRES_PmCompositeLireUnParReferencePmBytel(Retour retour_p, PMComposite pmComposite_p, String referenceBytel_p) throws Exception
  {
    ConnectorResponse<Retour, PMComposite> connectorResponse = new ConnectorResponse<>(retour_p, pmComposite_p);
    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxyMock).times(1);
    EasyMock.expect(_resProxyMock.pmCompositeLireUnParReferencePmBytel(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(referenceBytel_p))).andReturn(connectorResponse);
  }

  /**
   * Mock pour RES.ressourceLireUn
   *
   * @param retour_p
   *          Retour attendu
   * @param ressource_p
   *          Ressource attendue
   * @param idRessource_p
   *          IdRessource en paramètre
   * @param typeRessource_p
   *          type de ressource en paramètre
   * @throws Exception
   *           en cas d'exception
   */
  private void mockRES_RessourceLireUn(Retour retour_p, Ressource ressource_p, String idRessource_p, String typeRessource_p) throws Exception
  {
    ConnectorResponse<Retour, Ressource> connectorResponse = new ConnectorResponse<>(retour_p, ressource_p);
    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxyMock).times(1);
    EasyMock.expect(_resProxyMock.ressourceLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(idRessource_p), EasyMock.eq(typeRessource_p))).andReturn(connectorResponse);
  }

  /**
   * Mock pour REX.cleRechercheOperationVieReseauCreerListe
   *
   * @param retour_p
   *          Retour attendu
   * @param liste_p
   *          Liste en paramètre
   * @throws Exception
   *           en cas d'exception
   */
  private void mockREX_CleRechercheOperationVieReseauCreerListe(Retour retour_p, ListeCleRechercheOperationVieReseauRequest liste_p) throws Exception
  {
    ConnectorResponse<Retour, Nothing> connectorResponse = new ConnectorResponse<>(retour_p, null);
    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxyMock).times(1);
    EasyMock.expect(_rexProxyMock.cleRechercheOperationVieReseauCreerListe(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(liste_p))).andReturn(connectorResponse);
  }

  /**
   * Mock pour REX.operationVieReseauCreer
   *
   * @param retour_p
   *          Retour attendu
   * @param operation_p
   *          Operation en paramètre
   * @throws Exception
   *           en cas d'exception
   */
  private void mockREX_OperationVieReseauCreer(Retour retour_p, OperationVieReseau operation_p) throws Exception
  {
    ConnectorResponse<Retour, Nothing> connectorResponse = new ConnectorResponse<>(retour_p, null);
    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxyMock).times(1);
    EasyMock.expect(_rexProxyMock.operationVieReseauCreer(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(operation_p))).andReturn(connectorResponse);
  }

  /**
   * Mock pour REX.operationVieReseauLireUn
   *
   * @param retour_p
   *          Retour attendu
   * @param operation_p
   *          Operation attendue
   * @param idOperation_p
   *          ID de l'operation en paramètre
   * @throws Exception
   *           en cas d'exception
   */
  private void mockREX_OperationVieReseauLireUn(Retour retour_p, OperationVieReseau operation_p, String idOperation_p) throws Exception
  {
    ConnectorResponse<Retour, OperationVieReseau> connectorResponse = new ConnectorResponse<>(retour_p, operation_p);
    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxyMock).times(1);
    EasyMock.expect(_rexProxyMock.operationVieReseauLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(idOperation_p))).andReturn(connectorResponse);
  }

  /**
   * prepare POST Request
   *
   * @param creationRequest_p
   *          {@link PE0529_PostRequest}
   * @param headers_p
   *          {@link List}
   *
   * @return {@link Request}
   * @throws RavelException
   *           on error.
   */
  private Request preparePostRequest(PE0529_PostRequest creationRequest_p, List<RequestHeader> headers_p) throws RavelException
  {
    Request request = new Request(DEFAULT_PROCESSNAME, "idProcess", "idClient"); //$NON-NLS-1$ //$NON-NLS-2$
    request.setHttpMethod(HttpMethod.POST);
    request.setMsgId(Test_Consts.DEFAULT_MSGID);
    String payload = RavelJsonTools.getInstance().toJson(creationRequest_p, PE0529_PostRequest.class);
    request.setPayload(payload);
    request.setRequestHeader(headers_p);

    return request;
  }

}
