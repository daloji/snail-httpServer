/*******************************************************************************
* $Id: PE0396_GererAlarmeDirecteTest.java 52224 2021-05-19 13:36:55Z jsantos $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.tesla.processes.PE0396;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentMap;

import org.easymock.EasyMock;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PowerMockListener;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.testlisteners.FieldDefaulter;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.modules.junit4.PowerMockRunnerDelegate;
import org.powermock.reflect.Whitebox;
import org.snmp4j.PDU;
import org.snmp4j.smi.OID;
import org.snmp4j.smi.OctetString;
import org.snmp4j.smi.Variable;
import org.snmp4j.smi.VariableBinding;
import org.springframework.test.context.ContextConfiguration;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.test.JUnitTools;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.test.podam.PodamBytelJUnit4ClassRunner;
import com.bytel.ravel.common.utils.Pair;
import com.bytel.ravel.common.utils.RetourFactoryForTU;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.ProcessManager;
import com.bytel.ravel.services.utils.Test_Consts;
import com.bytel.spirit.common.connectors.stark.STARKProxy;
import com.bytel.spirit.common.connectors.stark.structs.STARKResponse;
import com.bytel.spirit.common.shared.misc.error.ReponseErreur;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.tesla.processes.PE0396.PE0396_GererAlarmeDirecte.PE0396_GererAlarmeDirecteContext;
import com.bytel.spirit.tesla.processes.PE0396.structs.AlarmReseau;
import com.bytel.spirit.tesla.processes.PE0396.structs.ConfigurationPE0396;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author jiantila
 * @version ($Revision: 52224 $ $Date: 2021-05-19 15:36:55 +0200 (mer. 19 mai 2021) $)
 */
@RunWith(PowerMockRunner.class)
@PowerMockListener(FieldDefaulter.class)
@PowerMockRunnerDelegate(PodamBytelJUnit4ClassRunner.class)
@ContextConfiguration("classpath:BeansProcessTestMocks.xml")
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
@PrepareForTest({ STARKProxy.class, PE0396_GererAlarmeDirecte.class })
public class PE0396_GererAlarmeDirecteTest extends EasyMock
{
  /**
   * bean Factory generation
   */
  private static PodamFactory __podam = new PodamFactoryImpl();

  /**
   * Configuration parameter INK_CONNECTOR_ID
   */
  private static final String MES_ALARME_DIRECTE = "mesAlarmeDirecte"; //$NON-NLS-1$

  /**
  *
  */
  private static final String SLID_FILTRE_LISTE_PARAM = "slidFiltreListe"; //$NON-NLS-1$

  /**
  *
  */
  private static final String SLID_FILTRE_FLAG_PARAM = "slidFiltreFlag"; //$NON-NLS-1$

  /**
  *
  */
  private static final String SLID_PREFIX_HUAWEI_PARAM = "slidPrefixHuawei"; //$NON-NLS-1$

  /**
  *
  */
  private static final String SLID_PREFIX_NOKIA_PARAM = "slidPrefixNokia"; //$NON-NLS-1$

  /**
   *
   */
  public static final String DEFAULT_PROCESS_NAME = "PE0396_gererAlarmeDirecte"; //$NON-NLS-1$

  /**
   * Initialize before all tests
   *
   * @throws Exception
   *           On errors Exception to be thrown in case of failure
   */
  @BeforeClass
  public static void setUpBeforeClass() throws Exception
  {
    __podam.getStrategy().setMemoization(false);
    __podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());
  }

  /**
   *
   */
  private PE0396_GererAlarmeDirecteContext _processContext;

  /**
   * Tracabilite
   */
  Tracabilite _tracabilite;

  /**
   * PE0396_gererAlarmeDirecte
   */
  private PE0396_GererAlarmeDirecte _process;

  /**
   * Mock of {@CMDProxy}
   */
  @MockStrict
  private STARKProxy _starkProxyMock;

  /**
   *
   * <b>Cas de test:</b> PDU don't contains a correct OID HUAWEI<br/>
   * <b>Entrées:</b> PDU with no correct OID<br/>
   * <b>Attendu:</b> l'erreur CAT-3 / ENTREE_INCORRECTE / " l OID Date de l'alarme OLT n'est pas pas present
   * inconnu'<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0396_BL001_VerifierDonnees_KO_001() throws Throwable
  {
    PDU pdu = new PDU();
    pdu.setType(PDU.TRAP);
    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ENTREE_INCORRECTE, "Type de PDU inconnu"); //$NON-NLS-1$

    PowerMock.replayAll();
    Pair<Retour, AlarmReseau> bl001 = Whitebox.invokeMethod(_process, "PE0396_BL001_VerifierDonnees", _tracabilite, pdu); //$NON-NLS-1$    PowerMock.verifyAll();
    PowerMock.verifyAll();
    assertEquals(retourExpected, bl001._first);
    assertNull(bl001._second.getDateAlarme());
    assertNull(null, bl001._second.getNomOlt());
    assertNull(null, bl001._second.getPort());
    assertNull(null, bl001._second.getSlid());
    assertNull(null, bl001._second.getSlot());
    assertNull(null, bl001._second.getTypeEvenement());
    assertNull(null, bl001._second.getTypeOlt());
  }

  /**
   * <b>Cas de test:</b> Configuration routageAlarmeOnt not present in process Configuration<br/>
   * <b>Entrées:</b> all OID present<br/>
   *
   * <br/>
   * <b>Attendu:</b> : CAT-3 / ENTREE_INCORRECTE / "Cannot find param routageAlarmeOnt in process configuration <br/>
   *
   * @throws Throwable
   *           exception
   *
   */
  @Test
  public void PE0396_BL001_VerifierDonnees_KO_0010() throws Throwable
  {
    Map<String, String> map = new HashMap<>();
    map.put(SLID_FILTRE_FLAG_PARAM, "VALIDATION"); //$NON-NLS-1$
    map.put(SLID_PREFIX_NOKIA_PARAM, "00000"); //$NON-NLS-1$
    map.put(SLID_PREFIX_HUAWEI_PARAM, "0x00000"); //$NON-NLS-1$
    map.put(SLID_FILTRE_LISTE_PARAM, "^0x000001,^000001"); //$NON-NLS-1$

    ConcurrentMap<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.put(StringConstants.EMPTY_STRING, map);

    PDU pdu = new PDU();
    pdu.setType(PDU.TRAP);
    OID oid = new OID("1.3.6.1.4.1.637.69.6.1.1.1.15"); //$NON-NLS-1$
    Variable var = new OctetString("New ONT Discovered"); //$NON-NLS-1$
    pdu.add(new VariableBinding(oid, var));
    oid = new OID("1.3.6.1.4.1.637.69.6.1.1.1.5"); //$NON-NLS-1$
    var = new OctetString("Thu Nov 21 15:01:07 CET 2019"); //$NON-NLS-1$
    pdu.add(new VariableBinding(oid, var));
    oid = new OID("1.3.6.1.4.1.637.69.6.1.1.1.8"); //$NON-NLS-1$
    var = new OctetString("SERNUM = TCOM15E6BB8B, SLID = 00000143759718627317, LOID = , DISIND = , EQID = , USRATE = 1.25 Gb/s"); //$NON-NLS-1$*/
    pdu.add(new VariableBinding(oid, var));
    oid = new OID("1.3.6.1.4.1.637.69.6.1.1.1.9"); //$NON-NLS-1$
    var = new OctetString("ONT New:OLTM80005:R1.S1.LT8.PON16.NEWONT1"); //$NON-NLS-1$
    pdu.add(new VariableBinding(oid, var));
    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegConsts.ERREUR_TECHNIQUE, "Cannot find param mesAlarmeDirecte in process configuration"); //$NON-NLS-1$

    PowerMock.replayAll();
    Pair<Retour, AlarmReseau> bl001 = Whitebox.invokeMethod(_process, "PE0396_BL001_VerifierDonnees", _tracabilite, pdu); //$NON-NLS-1$    PowerMock.verifyAll();
    assertEquals(retourExpected, bl001._first);
    assertNull(bl001._second.getDateAlarme());
    assertNull(bl001._second.getNomOlt());
    assertNull(bl001._second.getPort());
    assertNull(null, bl001._second.getSlid());
    assertNull(null, bl001._second.getSlot());
    assertNull(null, bl001._second.getTypeEvenement());
    assertNull(null, bl001._second.getTypeOlt());
  }

  /**
   *
   * <b>Cas de test:</b> PDU don't contains name OLT Huawei<br/>
   * <b>Entrées:</b> PDU .1.3.6.1.4.1.2011.2.15.1.7.1.8.0="The GPON ONT is discovered by the OLT<br/>
   * </b>1.3.6.1.4.1.2011.2.15.1.7.1.3.0="source=OLT9003 location=Frame=0, Slot=1, Subslot=65535, Port=0, Serial
   * Number=54434F4D15E1CDFB LOID=NULL CHECKCODE=NULL<br/>
   * <b>Attendu:</b> l'erreur CAT-3 / ENTREE_INCORRECTE / " l OID contenant les valeurs Nom OLT, Slot, Port n'est pas
   * pas present <br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0396_BL001_VerifierDonnees_KO_002() throws Throwable
  {
    PDU pdu = new PDU();
    pdu.setType(PDU.TRAP);
    OID oid = new OID("1.3.6.1.4.1.2011.2.15.1.7.1.8.0"); //$NON-NLS-1$
    Variable var = new OctetString("The GPON ONT is discovered by the OLT"); //$NON-NLS-1$
    pdu.add(new VariableBinding(oid, var));
    oid = new OID("1.3.6.1.4.1.2011.2.15.1.7.1.3.0"); //$NON-NLS-1$
    var = new OctetString("source=OLT9003 location=Frame=0, Slot=1, Subslot=65535, Port=0, Serial Number=54434F4D15E1CDFB  LOID=NULL CHECKCODE=NULL"); //$NON-NLS-1$
    pdu.add(new VariableBinding(oid, var));
    oid = new OID("1.3.6.1.4.1.2011.2.15.1.7.1.5.0"); //$NON-NLS-1$
    var = new OctetString("2019/04/15 - 09:46:32Z"); //$NON-NLS-1$
    pdu.add(new VariableBinding(oid, var));
    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ENTREE_INCORRECTE, "Les OIDs suivants sont manquants : [1.3.6.1.4.1.2011.2.15.1.7.1.1.0]"); //$NON-NLS-1$

    PowerMock.replayAll();
    Pair<Retour, AlarmReseau> bl001 = Whitebox.invokeMethod(_process, "PE0396_BL001_VerifierDonnees", _tracabilite, pdu); //$NON-NLS-1$
    PowerMock.verifyAll();
    assertEquals(retourExpected, bl001._first);
    assertNull(bl001._second.getDateAlarme());
    assertNull(null, bl001._second.getNomOlt());
    assertNull(null, bl001._second.getPort());
    assertNull(null, bl001._second.getSlid());
    assertNull(null, bl001._second.getSlot());
    assertNull(null, bl001._second.getTypeEvenement());
    assertNull(null, bl001._second.getTypeOlt());
  }

  /**
   *
   * <b>Cas de test:</b> PDU contains a correct OID but SLID Huawei (Password) not present<br/>
   * <b>Entrées:</b> PDU .1.3.6.1.4.1.2011.2.15.1.7.1.8.0="The GPON ONT is discovered by the OLT<br/>
   * </b>1.3.6.1.4.1.2011.2.15.1.7.1.3.0="source=OLT9003 location=Frame=0, Slot=1, Subslot=65535, Port=0, Serial
   * Number=54434F4D15E1CDFB LOID=NULL CHECKCODE=NULL<br/>
   * <b>Attendu:</b> l'erreur CAT-3 / ENTREE_INCORRECTE / " Parametre SLID incorrect dans la trame reseau, l'Alarme ne
   * peut pas être traité. <br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0396_BL001_VerifierDonnees_KO_003() throws Throwable
  {
    prepareProcessConfiguration();
    PDU pdu = new PDU();
    pdu.setType(PDU.TRAP);
    OID oid = new OID("1.3.6.1.4.1.2011.2.15.1.7.1.8.0"); //$NON-NLS-1$
    Variable var = new OctetString("The GPON ONT is discovered by the OLT"); //$NON-NLS-1$
    pdu.add(new VariableBinding(oid, var));
    oid = new OID("1.3.6.1.4.1.2011.2.15.1.7.1.3.0"); //$NON-NLS-1$
    var = new OctetString("source=OLT9003 location=Frame=0, Slot=1, Subslot=65535, Port=0, Serial Number=54434F4D15E1CDFB  LOID=NULL CHECKCODE=NULL"); //$NON-NLS-1$
    pdu.add(new VariableBinding(oid, var));
    oid = new OID("1.3.6.1.4.1.2011.2.15.1.7.1.5.0"); //$NON-NLS-1$
    var = new OctetString("2019/04/15 - 09:46:32Z"); //$NON-NLS-1$
    pdu.add(new VariableBinding(oid, var));
    oid = new OID("1.3.6.1.4.1.2011.2.15.1.7.1.1.0"); //$NON-NLS-1$
    var = new OctetString("OLT9003"); //$NON-NLS-1$
    pdu.add(new VariableBinding(oid, var));
    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ENTREE_INCORRECTE, "Parametre SLID incorrect dans la trame reseau, l'alarme ne peut pas être traitée."); //$NON-NLS-1$

    PowerMock.replayAll();
    Pair<Retour, AlarmReseau> bl001 = Whitebox.invokeMethod(_process, "PE0396_BL001_VerifierDonnees", _tracabilite, pdu); //$NON-NLS-1$    PowerMock.verifyAll();
    assertEquals(retourExpected, bl001._first);
    assertNull(bl001._second.getDateAlarme());
    assertNull(null, bl001._second.getNomOlt());
    assertNull(null, bl001._second.getPort());
    assertNull(null, bl001._second.getSlid());
    assertNull(null, bl001._second.getSlot());
    assertEquals("The GPON ONT is discovered by the OLT", bl001._second.getTypeEvenement()); //$NON-NLS-1$
    assertEquals("huawei", bl001._second.getTypeOlt()); //$NON-NLS-1$
  }

  /**
   *
   * <b>Cas de test:</b> PDU contains a correct OID SLID not conforme for filter HUAWEI<br/>
   * <b>Entrées:</b> PDU .1.3.6.1.4.1.2011.2.15.1.7.1.8.0="The GPON ONT is discovered by the OLT<br/>
   * </b>1.3.6.1.4.1.2011.2.15.1.7.1.3.0="source=OLT9003 location=Frame=0, Slot=1, Subslot=65535, Port=0, Serial
   * Number=54434F4D15E1CDFB Password=0x00000143759619216780 LOID=NULL CHECKCODE=NULL<br/>
   * <b>Attendu:</b> l'erreur CAT-3 / ENTREE_INCORRECTE / " Parametre SLID incorrect dans la trame reseau, l'Alarme ne
   * peut pas être traité. <br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0396_BL001_VerifierDonnees_KO_004() throws Throwable
  {
    prepareProcessConfiguration();
    PDU pdu = new PDU();
    pdu.setType(PDU.TRAP);
    OID oid = new OID("1.3.6.1.4.1.2011.2.15.1.7.1.8.0"); //$NON-NLS-1$
    Variable var = new OctetString("The GPON ONT is discovered by the OLT"); //$NON-NLS-1$
    pdu.add(new VariableBinding(oid, var));
    oid = new OID("1.3.6.1.4.1.2011.2.15.1.7.1.3.0"); //$NON-NLS-1$
    var = new OctetString("source=OLT9003 location=Frame=0, Slot=1, Subslot=65535, Port=0, Serial Number=54434F4D15E1CDFB  Password=0x00000243759619216780  LOID=NULL CHECKCODE=NULL"); //$NON-NLS-1$
    pdu.add(new VariableBinding(oid, var));
    oid = new OID("1.3.6.1.4.1.2011.2.15.1.7.1.5.0"); //$NON-NLS-1$
    var = new OctetString("2019/04/15 - 09:46:32Z"); //$NON-NLS-1$
    pdu.add(new VariableBinding(oid, var));
    oid = new OID("1.3.6.1.4.1.2011.2.15.1.7.1.1.0"); //$NON-NLS-1$
    var = new OctetString("OLT9003"); //$NON-NLS-1$
    pdu.add(new VariableBinding(oid, var));
    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.DONNEE_INVALIDE, "Le slid de l'alarme réseau d'identifiant 00000243759619216780 n'est pas conforme avec la règle de validation. L'alarme ne peut pas être traitée"); //$NON-NLS-1$

    PowerMock.replayAll();
    Pair<Retour, AlarmReseau> bl001 = Whitebox.invokeMethod(_process, "PE0396_BL001_VerifierDonnees", _tracabilite, pdu); //$NON-NLS-1$
    PowerMock.verifyAll();
    assertEquals(retourExpected, bl001._first);
    assertNull(bl001._second.getDateAlarme());
    assertNull(null, bl001._second.getNomOlt());
    assertNull(null, bl001._second.getPort());
    assertEquals("00000243759619216780", bl001._second.getSlid()); //$NON-NLS-1$
    assertNull(null, bl001._second.getSlot());
    assertEquals("The GPON ONT is discovered by the OLT", bl001._second.getTypeEvenement()); //$NON-NLS-1$
    assertEquals("huawei", bl001._second.getTypeOlt()); //$NON-NLS-1$
  }

  /**
   * <b>Cas de test:</b> Parametre SLID incorrect dans la trame reseau, l'Alarme ne peut pas être traité.<br/>
   * <b>Entrées:</b> all OID SLID not present<br/>
   *
   * <br/>
   * <b>Attendu:</b> : CAT-3 / ENTREE_INCORRECTE / Parametre SLID incorrect dans la trame reseau, l'Alarme ne peut pas
   * être traité. <br/>
   *
   * @throws Throwable
   *           exception
   *
   */
  @Test
  public void PE0396_BL001_VerifierDonnees_KO_006() throws Throwable
  {
    PDU pdu = new PDU();
    pdu.setType(PDU.TRAP);
    OID oid = new OID("1.3.6.1.4.1.637.69.6.1.1.1.15"); //$NON-NLS-1$
    Variable var = new OctetString("New ONT Discovered"); //$NON-NLS-1$
    pdu.add(new VariableBinding(oid, var));
    oid = new OID("1.3.6.1.4.1.637.69.6.1.1.1.5"); //$NON-NLS-1$
    var = new OctetString("Thu Nov 21 15:01:07 CET 2019"); //$NON-NLS-1$
    pdu.add(new VariableBinding(oid, var));
    oid = new OID("1.3.6.1.4.1.637.69.6.1.1.1.9"); //$NON-NLS-1$
    var = new OctetString("ONT New:OLTM80005:R1.S1.LT8.PON16.NEWONT1"); //$NON-NLS-1$
    pdu.add(new VariableBinding(oid, var));
    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ENTREE_INCORRECTE, "Les OIDs suivants sont manquants : [1.3.6.1.4.1.637.69.6.1.1.1.8]"); //$NON-NLS-1$

    PowerMock.replayAll();
    Pair<Retour, AlarmReseau> bl001 = Whitebox.invokeMethod(_process, "PE0396_BL001_VerifierDonnees", _tracabilite, pdu); //$NON-NLS-1$    PowerMock.verifyAll();
    assertEquals(retourExpected, bl001._first);
    assertNull(bl001._second.getDateAlarme());
    assertNull(null, bl001._second.getNomOlt());
    assertNull(null, bl001._second.getPort());
    assertNull(null, bl001._second.getSlid());
    assertNull(null, bl001._second.getSlot());
    assertNull(null, bl001._second.getTypeEvenement());
  }

  /**
   * <b>Cas de test:</b> Configuration slidPrefixHuawei not present in process Configuration<br/>
   * <b>Entrées:</b> all OID present<br/>
   *
   * <br/>
   * <b>Attendu:</b> : CAT-3 / ENTREE_INCORRECTE / "Cannot find param slidPrefixHuawei in process configuration <br/>
   *
   * @throws Throwable
   *           exception
   *
   */
  @Test
  public void PE0396_BL001_VerifierDonnees_KO_007() throws Throwable
  {
    Map<String, String> map = new HashMap<>();
    map.put(MES_ALARME_DIRECTE, "true"); //$NON-NLS-1$
    map.put(SLID_FILTRE_FLAG_PARAM, "VALIDATION"); //$NON-NLS-1$
    map.put(SLID_FILTRE_LISTE_PARAM, "^0x000001,^000001"); //$NON-NLS-1$
    map.put(SLID_PREFIX_NOKIA_PARAM, "00000"); //$NON-NLS-1$
    ConcurrentMap<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.put(StringConstants.EMPTY_STRING, map);

    _processContext = new PE0396_GererAlarmeDirecteContext();
    ConfigurationPE0396 configPE = new ConfigurationPE0396();
    configPE.setMesAlarmeDirecte(Boolean.parseBoolean(map.get(MES_ALARME_DIRECTE)));
    configPE.setSlidFiltreFlag(SLID_FILTRE_FLAG_PARAM);
    configPE.setSlidFiltreListe(Collections.singletonList(map.get(SLID_FILTRE_LISTE_PARAM)));
    configPE.setSlidPrefixNokia(map.get(SLID_PREFIX_NOKIA_PARAM));
    _processContext.setConfigurationPE0396(configPE);
    PDU pdu = new PDU();
    pdu.setType(PDU.TRAP);
    OID oid = new OID("1.3.6.1.4.1.637.69.6.1.1.1.15"); //$NON-NLS-1$
    Variable var = new OctetString("New ONT Discovered"); //$NON-NLS-1$
    pdu.add(new VariableBinding(oid, var));
    oid = new OID("1.3.6.1.4.1.637.69.6.1.1.1.8"); //$NON-NLS-1$
    var = new OctetString("SERNUM = TCOM15E6BB8B, SLID = 00000143759718627317, LOID = , DISIND = , EQID = , USRATE = 1.25 Gb/s"); //$NON-NLS-1$*/
    pdu.add(new VariableBinding(oid, var));
    oid = new OID("1.3.6.1.4.1.637.69.6.1.1.1.5"); //$NON-NLS-1$
    var = new OctetString("Thu Nov 21 15:01:07 CET 2019"); //$NON-NLS-1$
    pdu.add(new VariableBinding(oid, var));
    oid = new OID("1.3.6.1.4.1.637.69.6.1.1.1.9"); //$NON-NLS-1$
    var = new OctetString("ONT New:OLTM80005:R1.S1.LT8.PON16.NEWONT1"); //$NON-NLS-1$
    pdu.add(new VariableBinding(oid, var));

    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegConsts.ERREUR_TECHNIQUE, "Cannot find param slidPrefixHuawei in process configuration"); //$NON-NLS-1$
    PowerMock.replayAll();

    Pair<Retour, AlarmReseau> bl001 = Whitebox.invokeMethod(_process, "PE0396_BL001_VerifierDonnees", _tracabilite, pdu); //$NON-NLS-1$    PowerMock.verifyAll();
    assertEquals(retourExpected, bl001._first);
    assertNull(bl001._second.getDateAlarme());
    assertNull(null, bl001._second.getNomOlt());
    assertNull(null, bl001._second.getPort());
    assertNull(null, bl001._second.getSlid());
    assertNull(null, bl001._second.getSlot());
    assertNull(null, bl001._second.getTypeEvenement());
    assertNull(null, bl001._second.getTypeOlt());
  }

  /**
   * <b>Cas de test:</b> Configuration slidFiltreListe not present in process Configuration<br/>
   * <b>Entrées:</b> all OID present<br/>
   *
   * <br/>
   * <b>Attendu:</b> : CAT-3 / ENTREE_INCORRECTE / "Cannot find param slidFiltreListe in process configuration <br/>
   *
   * @throws Throwable
   *           exception
   *
   */
  @Test
  public void PE0396_BL001_VerifierDonnees_KO_008() throws Throwable
  {
    Map<String, String> map = new HashMap<>();
    map.put(MES_ALARME_DIRECTE, "true"); //$NON-NLS-1$
    map.put(SLID_FILTRE_FLAG_PARAM, "VALIDATION"); //$NON-NLS-1$
    map.put(SLID_PREFIX_NOKIA_PARAM, "00000"); //$NON-NLS-1$
    map.put(SLID_PREFIX_HUAWEI_PARAM, "0x00000"); //$NON-NLS-1$
    ConcurrentMap<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.put(StringConstants.EMPTY_STRING, map);

    _processContext = new PE0396_GererAlarmeDirecteContext();
    ConfigurationPE0396 configPE = new ConfigurationPE0396();
    configPE.setMesAlarmeDirecte(Boolean.parseBoolean(map.get(MES_ALARME_DIRECTE)));
    configPE.setSlidFiltreFlag(SLID_FILTRE_FLAG_PARAM);
    configPE.setSlidFiltreListe(Collections.singletonList(map.get(SLID_FILTRE_LISTE_PARAM)));
    configPE.setSlidPrefixNokia(map.get(SLID_PREFIX_NOKIA_PARAM));
    configPE.setSlidPrefixHuawei(map.get(SLID_PREFIX_HUAWEI_PARAM));
    _processContext.setConfigurationPE0396(configPE);

    PDU pdu = new PDU();
    pdu.setType(PDU.TRAP);
    OID oid = new OID("1.3.6.1.4.1.637.69.6.1.1.1.15"); //$NON-NLS-1$
    Variable var = new OctetString("New ONT Discovered"); //$NON-NLS-1$
    pdu.add(new VariableBinding(oid, var));
    oid = new OID("1.3.6.1.4.1.637.69.6.1.1.1.5"); //$NON-NLS-1$
    var = new OctetString("Thu Nov 21 15:01:07 CET 2019"); //$NON-NLS-1$
    pdu.add(new VariableBinding(oid, var));
    oid = new OID("1.3.6.1.4.1.637.69.6.1.1.1.8"); //$NON-NLS-1$
    var = new OctetString("SERNUM = TCOM15E6BB8B, SLID = 00000143759718627317, LOID = , DISIND = , EQID = , USRATE = 1.25 Gb/s"); //$NON-NLS-1$*/
    pdu.add(new VariableBinding(oid, var));
    oid = new OID("1.3.6.1.4.1.637.69.6.1.1.1.9"); //$NON-NLS-1$
    var = new OctetString("ONT New:OLTM80005:R1.S1.LT8.PON16.NEWONT1"); //$NON-NLS-1$
    pdu.add(new VariableBinding(oid, var));
    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegConsts.ERREUR_TECHNIQUE, "Cannot find param slidFiltreListe in process configuration"); //$NON-NLS-1$

    PowerMock.replayAll();
    Pair<Retour, AlarmReseau> bl001 = Whitebox.invokeMethod(_process, "PE0396_BL001_VerifierDonnees", _tracabilite, pdu); //$NON-NLS-1$    PowerMock.verifyAll();
    assertEquals(retourExpected, bl001._first);
    assertNull(bl001._second.getDateAlarme());
    assertNull(null, bl001._second.getNomOlt());
    assertNull(null, bl001._second.getPort());
    assertNull(null, bl001._second.getSlid());
    assertNull(null, bl001._second.getSlot());
    assertNull(null, bl001._second.getTypeEvenement());
    assertNull(null, bl001._second.getTypeOlt());
  }

  /**
   * <b>Cas de test:</b> Configuration slidFiltreFlag not present in process Configuration<br/>
   * <b>Entrées:</b> all OID present<br/>
   *
   * <br/>
   * <b>Attendu:</b> : CAT-3 / ENTREE_INCORRECTE / "Cannot find param slidFiltreFlag in process configuration <br/>
   *
   * @throws Throwable
   *           exception
   *
   */
  @Test
  public void PE0396_BL001_VerifierDonnees_KO_009() throws Throwable
  {
    Map<String, String> map = new HashMap<>();
    map.put(SLID_PREFIX_NOKIA_PARAM, "00000"); //$NON-NLS-1$
    map.put(SLID_PREFIX_HUAWEI_PARAM, "0x00000"); //$NON-NLS-1$
    map.put(SLID_FILTRE_LISTE_PARAM, "^0x000001,^000001"); //$NON-NLS-1$
    map.put(MES_ALARME_DIRECTE, "true"); //$NON-NLS-1$

    ConcurrentMap<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.put(StringConstants.EMPTY_STRING, map);

    PDU pdu = new PDU();
    pdu.setType(PDU.TRAP);
    OID oid = new OID("1.3.6.1.4.1.637.69.6.1.1.1.15"); //$NON-NLS-1$
    Variable var = new OctetString("New ONT Discovered"); //$NON-NLS-1$
    pdu.add(new VariableBinding(oid, var));
    oid = new OID("1.3.6.1.4.1.637.69.6.1.1.1.5"); //$NON-NLS-1$
    var = new OctetString("Thu Nov 21 15:01:07 CET 2019"); //$NON-NLS-1$
    pdu.add(new VariableBinding(oid, var));
    oid = new OID("1.3.6.1.4.1.637.69.6.1.1.1.8"); //$NON-NLS-1$
    var = new OctetString("SERNUM = TCOM15E6BB8B, SLID = 00000143759718627317, LOID = , DISIND = , EQID = , USRATE = 1.25 Gb/s"); //$NON-NLS-1$*/
    pdu.add(new VariableBinding(oid, var));
    oid = new OID("1.3.6.1.4.1.637.69.6.1.1.1.9"); //$NON-NLS-1$
    var = new OctetString("ONT New:OLTM80005:R1.S1.LT8.PON16.NEWONT1"); //$NON-NLS-1$
    pdu.add(new VariableBinding(oid, var));
    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegConsts.ERREUR_TECHNIQUE, "Cannot find param slidFiltreFlag in process configuration"); //$NON-NLS-1$

    PowerMock.replayAll();
    Pair<Retour, AlarmReseau> bl001 = Whitebox.invokeMethod(_process, "PE0396_BL001_VerifierDonnees", _tracabilite, pdu); //$NON-NLS-1$    PowerMock.verifyAll();
    assertEquals(retourExpected, bl001._first);
    assertNull(bl001._second.getDateAlarme());
    assertNull(null, bl001._second.getNomOlt());
    assertNull(null, bl001._second.getPort());
    assertNull(null, bl001._second.getSlid());
    assertNull(null, bl001._second.getSlot());
    assertNull(null, bl001._second.getTypeEvenement());
    assertNull(null, bl001._second.getTypeOlt());
  }

  /**
   * <b>Cas de test:</b> Configuration slidFiltreFlag not present in process Configuration<br/>
   * <b>Entrées:</b> all OID present<br/>
   *
   * <br/>
   * <b>Attendu:</b> : CAT-3 / ENTREE_INCORRECTE / "Cannot find param slidFiltreFlag in process configuration <br/>
   *
   * @throws Throwable
   *           exception
   *
   */
  @Test
  public void PE0396_BL001_VerifierDonnees_KO_010() throws Throwable
  {
    Map<String, String> map = new HashMap<>();
    map.put(MES_ALARME_DIRECTE, "false"); //$NON-NLS-1$
    map.put(SLID_PREFIX_NOKIA_PARAM, "00000"); //$NON-NLS-1$
    map.put(SLID_PREFIX_HUAWEI_PARAM, "0x00000"); //$NON-NLS-1$
    map.put(SLID_FILTRE_LISTE_PARAM, "^0x000001,^000001"); //$NON-NLS-1$
    map.put(SLID_FILTRE_FLAG_PARAM, "VALIDATION"); //$NON-NLS-1$
    ConcurrentMap<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.put(StringConstants.EMPTY_STRING, map);
    PDU pdu = new PDU();
    pdu.setType(PDU.TRAP);
    OID oid = new OID("1.3.6.1.4.1.637.69.6.1.1.1.15"); //$NON-NLS-1$
    Variable var = new OctetString("New ONT Discovered"); //$NON-NLS-1$
    pdu.add(new VariableBinding(oid, var));
    oid = new OID("1.3.6.1.4.1.637.69.6.1.1.1.5"); //$NON-NLS-1$
    var = new OctetString("Thu Nov 21 15:01:07 CET 2019"); //$NON-NLS-1$
    pdu.add(new VariableBinding(oid, var));
    oid = new OID("1.3.6.1.4.1.637.69.6.1.1.1.8"); //$NON-NLS-1$
    var = new OctetString("SERNUM = TCOM15E6BB8B, SLID = 00000143759718627317, LOID = , DISIND = , EQID = , USRATE = 1.25 Gb/s"); //$NON-NLS-1$*/
    pdu.add(new VariableBinding(oid, var));
    oid = new OID("1.3.6.1.4.1.637.69.6.1.1.1.9"); //$NON-NLS-1$
    var = new OctetString("ONT New:OLTM80005:R1.S1.LT8.PON16.NEWONT1"); //$NON-NLS-1$
    pdu.add(new VariableBinding(oid, var));
    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, "Traitement d'alarmes directes désactivé (conf. mesAlarmeDirecte=false)"); //$NON-NLS-1$

    PowerMock.replayAll();
    Pair<Retour, AlarmReseau> bl001 = Whitebox.invokeMethod(_process, "PE0396_BL001_VerifierDonnees", _tracabilite, pdu); //$NON-NLS-1$    PowerMock.verifyAll();
    assertEquals(retourExpected, bl001._first);
    assertNull(bl001._second.getDateAlarme());
    assertNull(bl001._second.getNomOlt());
    assertNull(bl001._second.getPort());
    assertNull(bl001._second.getSlid());
    assertNull(bl001._second.getSlot());
    assertNull(bl001._second.getTypeEvenement());
    assertNull(bl001._second.getTypeOlt());
  }

  /**
   *
   * <b>Cas de test:</b> PDU contains all OID HUAWEI<br/>
   * <b>Entrées:</b> PDU .1.3.6.1.4.1.2011.2.15.1.7.1.8.0="The GPON ONT is discovered by the OLT<br/>
   * </b>1.3.6.1.4.1.2011.2.15.1.7.1.3.0="source=OLT9003 location=Frame=0, Slot=1, Subslot=65535, Port=0, Serial
   * Number=54434F4D15E1CDFB Password=0x00000143759619216780 LOID=NULL CHECKCODE=NULL
   * 1.3.6.1.4.1.2011.2.15.1.7.1.8.0="The GPON ONT is discovered by the OLT" <br/>
   * 1.3.6.1.4.1.2011.2.15.1.7.1.5.0="2019/04/15 - 09:46:32Z<br/>
   *
   * <br/>
   * <b>Attendu:</b> OK <br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0396_BL001_VerifierDonnees_OK_001() throws Throwable
  {
    prepareProcessConfiguration();
    PDU pdu = new PDU();
    pdu.setType(PDU.TRAP);
    OID oid = new OID("1.3.6.1.4.1.2011.2.15.1.7.1.8.0"); //$NON-NLS-1$
    Variable var = new OctetString("The GPON ONT is discovered by the OLT"); //$NON-NLS-1$
    pdu.add(new VariableBinding(oid, var));
    oid = new OID("1.3.6.1.4.1.2011.2.15.1.7.1.3.0"); //$NON-NLS-1$
    var = new OctetString("source=OLT9003 location=Frame=0, Slot=1, Subslot=65535, Port=0, Serial Number=54434F4D15E1CDFB  Password=0x00000143759619216780  LOID=NULL CHECKCODE=NULL"); //$NON-NLS-1$
    pdu.add(new VariableBinding(oid, var));
    oid = new OID("1.3.6.1.4.1.2011.2.15.1.7.1.1.0"); //$NON-NLS-1$
    var = new OctetString("OLT9003"); //$NON-NLS-1$
    pdu.add(new VariableBinding(oid, var));
    oid = new OID("1.3.6.1.4.1.2011.2.15.1.7.1.5.0"); //$NON-NLS-1$
    var = new OctetString("2019/03/27 - 09:46:32Z"); //$NON-NLS-1$
    pdu.add(new VariableBinding(oid, var));
    Retour retourExpected = RetourFactoryForTU.createOkRetour();

    PowerMock.replayAll();
    Pair<Retour, AlarmReseau> bl001 = Whitebox.invokeMethod(_process, "PE0396_BL001_VerifierDonnees", _tracabilite, pdu); //$NON-NLS-1$    PowerMock.verifyAll();

    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy/MM/dd - HH:mm:ss"); //$NON-NLS-1$
    LocalDateTime dateTime = LocalDateTime.parse("2019/03/27 - 10:46:32", formatter); //$NON-NLS-1$
    assertEquals(retourExpected, bl001._first);
    assertEquals(dateTime, bl001._second.getDateAlarme());
    assertEquals("OLT9003", bl001._second.getNomOlt()); //$NON-NLS-1$
    assertEquals("0", bl001._second.getPort()); //$NON-NLS-1$
    assertEquals("00000143759619216780", bl001._second.getSlid()); //$NON-NLS-1$
    assertEquals("1", bl001._second.getSlot()); //$NON-NLS-1$
    assertEquals("The GPON ONT is discovered by the OLT", bl001._second.getTypeEvenement()); //$NON-NLS-1$
    assertEquals("huawei", bl001._second.getTypeOlt()); //$NON-NLS-1$
  }

  /**
   *
   * <b>Cas de test:</b> PDU contains all OID (NOKIA)<br/>
   * <b>Entrées:</b> PDU 1.3.6.1.4.1.637.69.6.1.1.1.15="New ONT Discovered <br/>
   * 1.3.6.1.4.1.637.69.6.1.1.1.8="SERNUM = TCOM15E6BB8B, SLID = 00000143759718627317, LOID = , DISIND = , EQID = ,
   * USRATE = 1.25 Gb/s" <br/>
   * 1.3.6.1.4.1.637.69.6.1.1.1.9=ONT New:OLTM80005:R1.S1.LT8.PON16.NEWONT1<br/>
   * 1.3.6.1.4.1.637.69.6.1.1.1.15 =New ONT Discovered <br/>
   * <br/>
   * <b>Attendu:</b> OK <br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0396_BL001_VerifierDonnees_OK_002() throws Throwable
  {
    prepareProcessConfiguration();
    PDU pdu = new PDU();
    pdu.setType(PDU.TRAP);
    OID oid = new OID("1.3.6.1.4.1.637.69.6.1.1.1.15"); //$NON-NLS-1$
    Variable var = new OctetString("New ONT Discovered"); //$NON-NLS-1$
    pdu.add(new VariableBinding(oid, var));
    oid = new OID("1.3.6.1.4.1.637.69.6.1.1.1.8"); //$NON-NLS-1$
    var = new OctetString("SERNUM = TCOM15E6BB8B, SLID = 00000143759718627317, LOID = , DISIND = , EQID = , USRATE = 1.25 Gb/s"); //$NON-NLS-1$*/
    pdu.add(new VariableBinding(oid, var));
    oid = new OID("1.3.6.1.4.1.637.69.6.1.1.1.9"); //$NON-NLS-1$
    var = new OctetString("ONT New:OLTM80005:R1.S1.LT8.PON16.NEWONT1"); //$NON-NLS-1$*/
    pdu.add(new VariableBinding(oid, var));
    oid = new OID("1.3.6.1.4.1.637.69.6.1.1.1.15"); //$NON-NLS-1$
    var = new OctetString("New ONT Discovered"); //$NON-NLS-1$*/
    pdu.add(new VariableBinding(oid, var));
    oid = new OID("1.3.6.1.4.1.637.69.6.1.1.1.5"); //$NON-NLS-1$
    var = new OctetString("Thu Nov 21 15:01:07 CET 2019"); //$NON-NLS-1$
    pdu.add(new VariableBinding(oid, var));
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss z yyyy", Locale.ENGLISH); //$NON-NLS-1$
    LocalDateTime dateTime = LocalDateTime.parse("Thu Nov 21 15:01:07 CET 2019", formatter); //$NON-NLS-1$
    Retour retourExpected = RetourFactoryForTU.createOkRetour();

    PowerMock.replayAll();
    Pair<Retour, AlarmReseau> bl001 = Whitebox.invokeMethod(_process, "PE0396_BL001_VerifierDonnees", _tracabilite, pdu); //$NON-NLS-1$    PowerMock.verifyAll();
    assertEquals(retourExpected, bl001._first);
    assertEquals(dateTime, bl001._second.getDateAlarme());
    assertEquals("OLTM80005", bl001._second.getNomOlt()); //$NON-NLS-1$
    assertEquals("16", bl001._second.getPort()); //$NON-NLS-1$
    assertEquals("00000143759718627317", bl001._second.getSlid()); //$NON-NLS-1$
    assertEquals("8", bl001._second.getSlot()); //$NON-NLS-1$
    assertEquals("New ONT Discovered", bl001._second.getTypeEvenement()); //$NON-NLS-1$
    assertEquals("nokia", bl001._second.getTypeOlt()); //$NON-NLS-1$
  }

  /**
   * <b>Cas de test:</b>Nominal PE0396_BL200_ExecuterPM <br/>
   * <b>Entrées:</b> <br/>
   * <br/>
   * <b>Attendu:</b>OK <br/>
   *
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0396_BL200_ExecuterPM_0K_001() throws Throwable
  {
    prepareProcessConfiguration();
    String target = "Thu Nov 21 15:01:07 CET 2019"; //$NON-NLS-1$
    AlarmReseau alarmReseau = new AlarmReseau();
    alarmReseau.setTypeOlt("huawei"); //$NON-NLS-1$
    alarmReseau.setNomOlt("huawei"); //$NON-NLS-1$
    alarmReseau.setSlot("0"); //$NON-NLS-1$
    alarmReseau.setSlid("00000143759619216780"); //$NON-NLS-1$
    alarmReseau.setPort("1"); //$NON-NLS-1$
    alarmReseau.setTypeEvenement("typeEvenement"); //$NON-NLS-1$
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss z yyyy", Locale.ENGLISH); //$NON-NLS-1$
    LocalDateTime dateTime = LocalDateTime.parse(target, formatter);
    alarmReseau.setDateAlarme(dateTime);
    ReponseErreur reponseErreur = new ReponseErreur();
    reponseErreur.setError("error"); //$NON-NLS-1$
    reponseErreur.setErrorDescription("errorDescription"); //$NON-NLS-1$
    reponseErreur.setErrorUri("errorUri"); //$NON-NLS-1$
    reponseErreur.setErrorParameters(new ArrayList<>());
    Retour retourExpected = RetourFactoryForTU.createOkRetour();
    STARKResponse<ReponseErreur> starkResponse = new STARKResponse<>(200, null);
    ConnectorResponse<Retour, STARKResponse<ReponseErreur>> connectorResponse = new ConnectorResponse<Retour, STARKResponse<ReponseErreur>>(RetourFactoryForTU.createOkRetour(), starkResponse);
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxyMock);
    EasyMock.expect(_starkProxyMock.sendRequest(EasyMock.anyObject(), EasyMock.eq(ReponseErreur.class))).andReturn(connectorResponse);
    PowerMock.replayAll();
    Whitebox.setInternalState(_process, "_processContext", _processContext); //$NON-NLS-1$
    Retour bl200 = Whitebox.invokeMethod(_process, "PE0396_BL200_ExecuterPM", _tracabilite, alarmReseau); //$NON-NLS-1$
    PowerMock.verifyAll();
    assertEquals(retourExpected, bl200);
  }

  /**
   * <b>Cas de test:</b>PE0396_BL200_ExecuterPM HUAWEI error when call OSS_FAI_039<br/>
   * <b>Entrées:</b> <br/>
   * <br/>
   * <b>Attendu:</b> NOK / CAT3 / ERREUR_TECHNIQUE / erreur <br/>
   *
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0396_BL200_ExecuterPM_0K_003() throws Throwable
  {
    prepareProcessConfiguration();
    String target = "Thu Nov 21 15:01:07 CET 2019"; //$NON-NLS-1$
    AlarmReseau alarmReseau = new AlarmReseau();
    alarmReseau.setTypeOlt("huawei"); //$NON-NLS-1$
    alarmReseau.setNomOlt("huawei"); //$NON-NLS-1$
    alarmReseau.setSlot("0"); //$NON-NLS-1$
    alarmReseau.setSlid("00000143759619216780"); //$NON-NLS-1$
    alarmReseau.setPort("1"); //$NON-NLS-1$
    alarmReseau.setTypeEvenement("typeEvenement"); //$NON-NLS-1$
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss z yyyy", Locale.ENGLISH); //$NON-NLS-1$
    LocalDateTime dateTime = LocalDateTime.parse(target, formatter);
    alarmReseau.setDateAlarme(dateTime);
    ReponseErreur reponseErreur = new ReponseErreur();
    reponseErreur.setError("error"); //$NON-NLS-1$
    reponseErreur.setErrorDescription("errorDescription"); //$NON-NLS-1$
    reponseErreur.setErrorUri("errorUri"); //$NON-NLS-1$
    reponseErreur.setErrorParameters(new ArrayList<>());
    STARKResponse<ReponseErreur> starkResponse = new STARKResponse<>(200, null);
    ConnectorResponse<Retour, STARKResponse<ReponseErreur>> connectorResponse = new ConnectorResponse<Retour, STARKResponse<ReponseErreur>>(RetourFactoryForTU.createOkRetour(), starkResponse);
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxyMock);
    EasyMock.expect(_starkProxyMock.sendRequest(EasyMock.anyObject(), EasyMock.eq(ReponseErreur.class))).andReturn(connectorResponse);
    PowerMock.replayAll();
    Whitebox.setInternalState(_process, "_processContext", _processContext); //$NON-NLS-1$
    Retour bl200 = Whitebox.invokeMethod(_process, "PE0396_BL200_ExecuterPM", _tracabilite, alarmReseau); //$NON-NLS-1$
    PowerMock.verifyAll();
    assertEquals(RetourFactoryForTU.createOkRetour(), bl200);
  }

  /**
   * <b>Cas de test:</b>PE0396_BL200_ExecuterPM HUAWEI error when call Stark Connector<br/>
   * <b>Entrées:</b> <br/>
   * <br/>
   * <b>Attendu:</b> NOK / CAT1 / SERVICE_TIERS_INDISPONIBLE / erreur <br/>
   *
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0396_BL200_ExecuterPM_K0_001() throws Throwable
  {
    prepareProcessConfiguration();
    String target = "Thu Nov 21 15:01:07 CET 2019"; //$NON-NLS-1$
    AlarmReseau alarmReseau = new AlarmReseau();
    alarmReseau.setTypeOlt("huawei"); //$NON-NLS-1$
    alarmReseau.setNomOlt("huawei"); //$NON-NLS-1$
    alarmReseau.setSlot("0"); //$NON-NLS-1$
    alarmReseau.setPort("1"); //$NON-NLS-1$
    alarmReseau.setTypeEvenement("typeEvenement"); //$NON-NLS-1$
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss z yyyy", Locale.ENGLISH); //$NON-NLS-1$
    LocalDateTime dateTime = LocalDateTime.parse(target, formatter);
    alarmReseau.setDateAlarme(dateTime);
    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT1, IMegConsts.SERVICE_TIERS_INDISPONIBLE, "erreur"); //$NON-NLS-1$
    ConnectorResponse<Retour, STARKResponse<ReponseErreur>> connectorResponse = new ConnectorResponse<Retour, STARKResponse<ReponseErreur>>(retourExpected, null);
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxyMock);
    EasyMock.expect(_starkProxyMock.sendRequest(EasyMock.anyObject(), EasyMock.eq(ReponseErreur.class))).andReturn(connectorResponse);
    PowerMock.replayAll();
    Whitebox.setInternalState(_process, "_processContext", _processContext); //$NON-NLS-1$
    Retour bl200 = Whitebox.invokeMethod(_process, "PE0396_BL200_ExecuterPM", _tracabilite, alarmReseau); //$NON-NLS-1$
    PowerMock.verifyAll();
    assertEquals(retourExpected, bl200);
  }

  /**
   * <b>Cas de test:</b>PE0396_BL200_ExecuterPM HUAWEI error when call Stark Connector<br/>
   * <b>Entrées:</b> <br/>
   * <br/>
   * <b>Attendu:</b> NOK / CAT1 / SERVICE_TIERS_INDISPONIBLE / erreur <br/>
   *
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0396_BL200_ExecuterPM_K0_002() throws Throwable
  {
    prepareProcessConfiguration();
    String target = "Thu Nov 21 15:01:07 CET 2019"; //$NON-NLS-1$
    AlarmReseau alarmReseau = new AlarmReseau();
    alarmReseau.setTypeOlt("huawei"); //$NON-NLS-1$
    alarmReseau.setNomOlt("huawei"); //$NON-NLS-1$
    alarmReseau.setSlot("0"); //$NON-NLS-1$
    alarmReseau.setPort("1"); //$NON-NLS-1$
    alarmReseau.setTypeEvenement("typeEvenement"); //$NON-NLS-1$
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss z yyyy", Locale.ENGLISH); //$NON-NLS-1$
    LocalDateTime dateTime = LocalDateTime.parse(target, formatter);
    alarmReseau.setDateAlarme(dateTime);
    ReponseErreur reponseErreur = new ReponseErreur();
    reponseErreur.setError("error"); //$NON-NLS-1$
    reponseErreur.setErrorDescription("errorDescription"); //$NON-NLS-1$
    reponseErreur.setErrorUri("errorUri"); //$NON-NLS-1$
    reponseErreur.setErrorParameters(new ArrayList<>());
    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegConsts.ERREUR_TECHNIQUE, reponseErreur.getError() + "  " + reponseErreur.getErrorDescription()); //$NON-NLS-1$
    STARKResponse<ReponseErreur> starkResponse = new STARKResponse<>(200, null);
    starkResponse.setReponseErreur(reponseErreur);
    ConnectorResponse<Retour, STARKResponse<ReponseErreur>> connectorResponse = new ConnectorResponse<Retour, STARKResponse<ReponseErreur>>(RetourFactoryForTU.createOkRetour(), starkResponse);
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxyMock);
    EasyMock.expect(_starkProxyMock.sendRequest(EasyMock.anyObject(), EasyMock.eq(ReponseErreur.class))).andReturn(connectorResponse);
    PowerMock.replayAll();
    Whitebox.setInternalState(_process, "_processContext", _processContext); //$NON-NLS-1$
    Retour bl200 = Whitebox.invokeMethod(_process, "PE0396_BL200_ExecuterPM", _tracabilite, alarmReseau); //$NON-NLS-1$
    PowerMock.verifyAll();
    assertEquals(retourExpected, bl200);
  }

  /**
   * <b>Cas de test:</b>Nominal HUAWEI<br/>
   * <b>Entrées:</b> <br/>
   * <br/>
   * <b>Attendu:</b> OK <br/>
   *
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0396_gererAlarmeDirecte_Nominal_001() throws Throwable
  {
    prepareProcessConfiguration();
    PDU pdu = new PDU();
    pdu.setType(PDU.TRAP);
    OID oid = new OID("1.3.6.1.4.1.2011.2.15.1.7.1.8.0"); //$NON-NLS-1$
    Variable var = new OctetString("The GPON ONT is discovered by the OLT"); //$NON-NLS-1$
    pdu.add(new VariableBinding(oid, var));
    oid = new OID("1.3.6.1.4.1.2011.2.15.1.7.1.3.0"); //$NON-NLS-1$
    var = new OctetString("source=OLT9003 location=Frame=0, Slot=1, Subslot=65535, Port=0, Serial Number=54434F4D15E1CDFB  Password=0x00000143759619216780  LOID=NULL CHECKCODE=NULL"); //$NON-NLS-1$
    pdu.add(new VariableBinding(oid, var));
    oid = new OID("1.3.6.1.4.1.2011.2.15.1.7.1.1.0"); //$NON-NLS-1$
    var = new OctetString("OLT9003"); //$NON-NLS-1$
    pdu.add(new VariableBinding(oid, var));
    oid = new OID("1.3.6.1.4.1.2011.2.15.1.7.1.5.0"); //$NON-NLS-1$
    var = new OctetString("2019/04/15 - 09:46:32Z"); //$NON-NLS-1$
    pdu.add(new VariableBinding(oid, var));
    ByteArrayOutputStream bOutput = new ByteArrayOutputStream();
    pdu.encodeBER(bOutput);
    InputStream payload = new ByteArrayInputStream(bOutput.toByteArray());
    Request request = prepareRequest("POST", payload); //$NON-NLS-1$
    STARKResponse<ReponseErreur> starkResponse = new STARKResponse<>(200, null);
    ConnectorResponse<Retour, STARKResponse<ReponseErreur>> connectorResponse = new ConnectorResponse<Retour, STARKResponse<ReponseErreur>>(RetourFactoryForTU.createOkRetour(), starkResponse);
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxyMock);
    EasyMock.expect(_starkProxyMock.sendRequest(EasyMock.anyObject(), EasyMock.eq(ReponseErreur.class))).andReturn(connectorResponse);
    PowerMock.replayAll();
    _process.run(request);
    _process.continueProcess(request, _tracabilite);
    PowerMock.verifyAll();
  }

  /**
   * <b>Cas de test:</b>Nominal NOKIA, USRATE = 1.25 Gb/s<br/>
   * <b>Entrées:</b> <br/>
   * <br/>
   * <b>Attendu:</b> OK <br/>
   *
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0396_gererAlarmeDirecte_Nominal_002() throws Throwable
  {
    prepareProcessConfiguration();
    PDU pdu = new PDU();
    pdu.setType(PDU.TRAP);
    OID oid = new OID("1.3.6.1.4.1.637.69.6.1.1.1.15"); //$NON-NLS-1$
    Variable var = new OctetString("New ONT Discovered"); //$NON-NLS-1$
    pdu.add(new VariableBinding(oid, var));
    oid = new OID("1.3.6.1.4.1.637.69.6.1.1.1.8"); //$NON-NLS-1$
    var = new OctetString("SERNUM = TCOM15E6BB8B, SLID = 00000143759718627317, LOID = , DISIND = , EQID = , USRATE = 1.25 Gb/s"); //$NON-NLS-1$*/
    pdu.add(new VariableBinding(oid, var));
    oid = new OID("1.3.6.1.4.1.637.69.6.1.1.1.9"); //$NON-NLS-1$
    var = new OctetString("ONT New:OLTM80005:R1.S1.LT8.PON16.NEWONT1"); //$NON-NLS-1$*/
    pdu.add(new VariableBinding(oid, var));
    oid = new OID("1.3.6.1.4.1.637.69.6.1.1.1.15"); //$NON-NLS-1$
    var = new OctetString("New ONT Discovered"); //$NON-NLS-1$*/
    pdu.add(new VariableBinding(oid, var));
    oid = new OID("1.3.6.1.4.1.637.69.6.1.1.1.5"); //$NON-NLS-1$
    var = new OctetString("\"Thu Nov 21 15:01:07 CET 2019\""); //$NON-NLS-1$
    pdu.add(new VariableBinding(oid, var));
    ByteArrayOutputStream bOutput = new ByteArrayOutputStream();
    pdu.encodeBER(bOutput);
    InputStream payload = new ByteArrayInputStream(bOutput.toByteArray());
    Request request = prepareRequest("POST", payload); //$NON-NLS-1$
    STARKResponse<ReponseErreur> starkResponse = new STARKResponse<>(200, null);
    ConnectorResponse<Retour, STARKResponse<ReponseErreur>> connectorResponse = new ConnectorResponse<Retour, STARKResponse<ReponseErreur>>(RetourFactoryForTU.createOkRetour(), starkResponse);
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxyMock);
    EasyMock.expect(_starkProxyMock.sendRequest(EasyMock.anyObject(), EasyMock.eq(ReponseErreur.class))).andReturn(connectorResponse);
    PowerMock.replayAll();
    _process.run(request);
    _process.continueProcess(request, _tracabilite);
    PowerMock.verifyAll();
    PE0396_GererAlarmeDirecteContext context = (PE0396_GererAlarmeDirecteContext) JUnitTools.getInaccessibleFieldValue(_process, "_processContext"); //$NON-NLS-1$
    Assert.assertEquals("00000143759718627317", context.getAlarmReseau().getSlid()); //$NON-NLS-1$
  }

  /**
   * <b>Cas de test:</b>Nominal NOKIA, USRATE = 10 Gb/s<br/>
   * <b>Entrées:</b> <br/>
   * <br/>
   * <b>Attendu:</b> OK <br/>
   *
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0396_gererAlarmeDirecte_Nominal_003() throws Throwable
  {
    prepareProcessConfiguration();
    
    PDU pdu = new PDU();
    pdu.setType(PDU.TRAP);
    
    OID oid = new OID("1.3.6.1.4.1.637.69.6.1.1.1.15"); //$NON-NLS-1$
    Variable var = new OctetString("New ONT Discovered"); //$NON-NLS-1$
    pdu.add(new VariableBinding(oid, var));
    
    oid = new OID("1.3.6.1.4.1.637.69.6.1.1.1.8"); //$NON-NLS-1$
    var = new OctetString("SERNUM = TCOM15E6BB8B, SLID = 00000143759718627317, LOID = , DISIND = , EQID = , USRATE = 10 Gb/s"); //$NON-NLS-1$*/
    pdu.add(new VariableBinding(oid, var));
    
    oid = new OID("1.3.6.1.4.1.637.69.6.1.1.1.9"); //$NON-NLS-1$
    var = new OctetString("ONT New:OLTM80005:R1.S1.LT8.PONXGS16.NEWONT1"); //$NON-NLS-1$*/
    pdu.add(new VariableBinding(oid, var));
    
    oid = new OID("1.3.6.1.4.1.637.69.6.1.1.1.15"); //$NON-NLS-1$
    var = new OctetString("New ONT Discovered"); //$NON-NLS-1$*/
    pdu.add(new VariableBinding(oid, var));
    
    oid = new OID("1.3.6.1.4.1.637.69.6.1.1.1.5"); //$NON-NLS-1$
    var = new OctetString("\"Thu Nov 21 15:01:07 CET 2019\""); //$NON-NLS-1$
    pdu.add(new VariableBinding(oid, var));
    
    ByteArrayOutputStream bOutput = new ByteArrayOutputStream();
    pdu.encodeBER(bOutput);
    
    InputStream payload = new ByteArrayInputStream(bOutput.toByteArray());
    
    Request request = prepareRequest("POST", payload); //$NON-NLS-1$

    STARKResponse<ReponseErreur> starkResponse = new STARKResponse<>(200, null);
    ConnectorResponse<Retour, STARKResponse<ReponseErreur>> connectorResponse = new ConnectorResponse<Retour, STARKResponse<ReponseErreur>>(RetourFactoryForTU.createOkRetour(), starkResponse);

    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxyMock);
    EasyMock.expect(_starkProxyMock.sendRequest(EasyMock.anyObject(), EasyMock.eq(ReponseErreur.class))).andReturn(connectorResponse);

    // Run test
    PowerMock.replayAll();
    
    _process.run(request);
    _process.continueProcess(request, _tracabilite);
    
    PowerMock.verifyAll();

    PE0396_GererAlarmeDirecteContext context = (PE0396_GererAlarmeDirecteContext) JUnitTools.getInaccessibleFieldValue(_process, "_processContext"); //$NON-NLS-1$

    Assert.assertEquals(72, context.getAlarmReseau().getSlid().length()); //$NON-NLS-1$
    Assert.assertEquals("000001437597186273171111111111111111111111111111111111111111111111111111", context.getAlarmReseau().getSlid()); //$NON-NLS-1$
    
  }

  /**
   *
   * @throws Exception
   *           On errors Thrown in case of error during switch in attributes of parent class
   */
  @Before
  public void setUp() throws Exception
  {
    _process = new PE0396_GererAlarmeDirecte();
    _process.initializeContext();

    _tracabilite = __podam.manufacturePojoWithFullData(Tracabilite.class);
    _tracabilite.setNomProcessus(StringConstants.EMPTY_STRING);
    _tracabilite.setNomSysteme(null);
    _tracabilite.setIdCorrelationSpirit(Test_Consts.DEFAULT_MSGID);
    _tracabilite.setIdProcessusSpirit(_process.getIdProcess());
    _tracabilite.setRefFonc(new HashMap<>());
    PowerMock.resetAll();
    PowerMock.mockStaticStrict(STARKProxy.class);

  }

  /**
   * Prepare Process Configuration
   */
  private void prepareProcessConfiguration()
  {
    Map<String, String> map = new HashMap<>();
    map.put(MES_ALARME_DIRECTE, "true"); //$NON-NLS-1$
    map.put(SLID_FILTRE_FLAG_PARAM, "VALIDATION"); //$NON-NLS-1$
    map.put(SLID_FILTRE_LISTE_PARAM, "^0x000001,^000001"); //$NON-NLS-1$
    map.put(SLID_PREFIX_HUAWEI_PARAM, "0x00000"); //$NON-NLS-1$
    map.put(SLID_PREFIX_NOKIA_PARAM, "00000"); //$NON-NLS-1$
    ConcurrentMap<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.put(StringConstants.EMPTY_STRING, map);
    _processContext = new PE0396_GererAlarmeDirecteContext();
    ConfigurationPE0396 configPE = new ConfigurationPE0396();
    boolean value = Boolean.parseBoolean(map.get(MES_ALARME_DIRECTE));
    configPE.setMesAlarmeDirecte(value);
    configPE.setSlidFiltreFlag(map.get(SLID_FILTRE_FLAG_PARAM));
    configPE.setSlidPrefixHuawei(map.get(SLID_PREFIX_HUAWEI_PARAM));
    configPE.setSlidPrefixNokia(map.get(SLID_PREFIX_NOKIA_PARAM));
    configPE.setSlidFiltreListe(Collections.singletonList(map.get(SLID_FILTRE_LISTE_PARAM)));
    _processContext.setConfigurationPE0396(configPE);
  }

  /**
   * prepare Request
   *
   *
   * @param methode_p
   *          method
   * @param payload_p
   *          payload
   * @return Request
   *
   * @throws RavelException
   *           Exception
   * @throws IOException
   *           Exception
   */
  private Request prepareRequest(String methode_p, InputStream payload_p) throws RavelException, IOException
  {
    Request request = new Request("ProcessName", "idProcess", "idCli" + "ent"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$//$NON-NLS-4$
    request.setHttpMethod(methode_p);
    request.setMsgId(Test_Consts.DEFAULT_MSGID);
    request.setPayloadStream(payload_p);
    return request;
  }

}
