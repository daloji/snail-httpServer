/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.tesla.processes.PE0533;

import static com.bytel.ravel.common.utils.StringConstants.EMPTY_STRING;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.lang.reflect.Method;
import java.text.MessageFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Set;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import javax.ws.rs.HttpMethod;

import org.easymock.EasyMock;
import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.internal.util.collections.Sets;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PowerMockListener;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.testlisteners.FieldDefaulter;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.modules.junit4.PowerMockRunnerDelegate;
import org.powermock.reflect.Whitebox;
import org.springframework.test.context.ContextConfiguration;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.data.exchange.generated.RavelRequest.RequestHeader;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.response.IRavelResponse;
import com.bytel.ravel.common.factory.response.RavelResponseFactory;
import com.bytel.ravel.common.json.IRavelJson;
import com.bytel.ravel.common.json.IRavelJsonAdapter;
import com.bytel.ravel.common.json.RavelJson.RavelJsonBuilder;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.test.podam.JavaTimeManufacturer;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.test.podam.PodamBytelJUnit4ClassRunner;
import com.bytel.ravel.common.utils.DateTimeTools.DateTimeFormatPattern;
import com.bytel.ravel.common.utils.RetourFactoryForTU;
import com.bytel.ravel.net.http.HttpConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.activities.shared.BL800_ObtenirSequence;
import com.bytel.spirit.common.activities.shared.BL800_ObtenirSequence.BL800_ObtenirSequenceBuilder;
import com.bytel.spirit.common.activities.shared.structs.UniqueIdConstant;
import com.bytel.spirit.common.connectors.res.RESProxy;
import com.bytel.spirit.common.connectors.rex.REXProxy;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.processes.SpiritProcessSkeleton;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.StatutBlockage;
import com.bytel.spirit.common.shared.saab.rex.BlocageEquipement;
import com.bytel.spirit.common.shared.saab.rex.CleRechercheBlocageEquipement;
import com.bytel.spirit.common.shared.saab.rex.OperationVieReseau;
import com.bytel.spirit.common.shared.saab.rex.OperationVieReseauStatut;
import com.bytel.spirit.common.shared.saab.rex.request.ListeCleRechercheBlocageEquipementRequest;
import com.bytel.spirit.tesla.processes.Messages;
import com.bytel.spirit.tesla.processes.PE0533.PE0533_BlocageEquipements.CleRechercheBlocageEquipementComparator;
import com.bytel.spirit.tesla.processes.PE0533.PE0533_BlocageEquipements.EquipementComparator;
import com.bytel.spirit.tesla.processes.PE0533.PE0533_BlocageEquipements.PE0533ContentType;
import com.bytel.spirit.tesla.processes.PE0533.PE0533_BlocageEquipements.PE0533State;
import com.bytel.spirit.tesla.processes.PE0533.PE0533_BlocageEquipements.PE0533_BL001_VerifierDonneesReturn;
import com.bytel.spirit.tesla.processes.PE0533.PE0533_BlocageEquipements.PE0533_BL002_FormaterReponseCreationReturn;
import com.bytel.spirit.tesla.processes.PE0533.PE0533_BlocageEquipements.PE0533_BL200_CreerBlocageEquipementsReturn;
import com.bytel.spirit.tesla.processes.PE0533.PE0533_BlocageEquipements.PE0533_BlocageEquipementsContext;
import com.bytel.spirit.tesla.shared.types.PE0529.AjoutPortPm;
import com.bytel.spirit.tesla.shared.types.PE0529.LienPortPon;
import com.bytel.spirit.tesla.shared.types.PE0529.PositionPortPm;
import com.bytel.spirit.tesla.shared.types.PE0529.request.PE0529_PostRequest;
import com.bytel.spirit.tesla.shared.types.PE0533.Equipement;
import com.bytel.spirit.tesla.shared.types.PE0533.OLT;
import com.bytel.spirit.tesla.shared.types.PE0533.PM;
import com.bytel.spirit.tesla.shared.types.PE0533.request.PE0533_PostRequest;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author jjoly
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PowerMockListener(FieldDefaulter.class)
@PowerMockRunnerDelegate(PodamBytelJUnit4ClassRunner.class)
@ContextConfiguration("classpath:BeansProcessTestMocks.xml")
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
@PrepareForTest({ PE0533_BlocageEquipements.class, BL800_ObtenirSequence.class, BL800_ObtenirSequenceBuilder.class, REXProxy.class, RESProxy.class, LocalDateTime.class, RavelResponseFactory.class })
public final class PE0533_PostBlocageEquipementsTest
{
  /**
   * bean Factory generation
   */
  private static PodamFactory __podam;

  /**
   * The current timestamp
   */
  private static LocalDateTime __now;

  /**
   * The object {@Code Tracabilite}
   */
  private static Tracabilite __traceability;

  /**
   * Authorization
   */
  private static String __authorization;

  /**
   * Authorization
   */
  private static String __xSource;

  /**
   * X-Request-Id
   */
  private static String __xRequestId;

  /**
   * X-Message-Id
   */
  private static String __xMessageId;

  /**
   * X-Process
   */
  private static String __xProcess;

  /**
   * X-Action-Id
   */
  private static String __xActionId;

  /**
   * X-Version
   */
  private static String __xVersion;

  /**
   * Content-Type
   */
  private static PE0533ContentType __contentType;

  /**
   * Numero Compte PFS
   */
  @SuppressWarnings("unused")
  private static String __noCompte;

  /**
   * Client Operateur
   */
  @SuppressWarnings("unused")
  private static String __clientOperateur;

  /**
   * Lock equipment identifier
   */
  private static String __idBlocageEquipement;

  /**
   * OLT name
   */
  private static String __nomOlt;

  /**
   * OLT
   */
  private static OLT __olt;

  /**
   * Reference PM bytel
   */
  private static String __referencePmBytel;

  /**
   * Reference PM bytel
   */
  private static PM __pm;

  /**
   * Initialize before all tests
   *
   * @throws Exception
   *           Exception to be thrown in case of failure
   */
  @SuppressWarnings("unchecked")
  @BeforeClass
  public static void setUpBeforeClass() throws Exception
  {
    __podam = new PodamFactoryImpl();
    __podam.getStrategy().setMemoization(false);
    __podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());
    JavaTimeManufacturer.registerPodamFactory(__podam);

    __now = LocalDateTime.of(2016, 8, 25, 12, 0, 0, 0);

    __traceability = __podam.manufacturePojoWithFullData(Tracabilite.class);
    __authorization = __podam.manufacturePojo(String.class);
    __xSource = __podam.manufacturePojo(String.class);
    __xRequestId = __podam.manufacturePojo(String.class);
    __xMessageId = __podam.manufacturePojo(String.class);
    __xProcess = __podam.manufacturePojo(String.class);
    __xActionId = __podam.manufacturePojo(String.class);
    __xVersion = "1"; //$NON-NLS-1$

    __contentType = __podam.manufacturePojo(PE0533ContentType.class);
    __noCompte = __podam.manufacturePojo(String.class);
    __clientOperateur = __podam.manufacturePojo(String.class);

    __idBlocageEquipement = __podam.manufacturePojo(String.class);
    __nomOlt = __podam.manufacturePojoWithFullData(String.class);
    __referencePmBytel = __podam.manufacturePojoWithFullData(String.class);

    __olt = new OLT(__nomOlt).withListPositionCarte(__podam.manufacturePojoWithFullData(TreeSet.class, Integer.class));
    __pm = new PM(__referencePmBytel).withListeReferenceBoitierPm(__podam.manufacturePojo(TreeSet.class, String.class));
  }

  /**
   * Exception has been thrown
   */
  private Boolean _exception;

  /**
   * Mock de {@link RESProxy}
   */
  @MockStrict
  protected RESProxy _resMock;

  /**
   * Mock de {@link REXProxy}
   */
  @MockStrict
  protected REXProxy _rexMock;

  /**
   * Mock de {@Code BL800_ObtenirSequence}
   */
  @MockStrict
  protected BL800_ObtenirSequence _bl800Mock;

  /**
   * Builder of the {@Code BL800_ObtenirSequence}
   */
  @MockStrict
  private BL800_ObtenirSequenceBuilder _bl800MockBuilder;

  /**
   * Mock de {@link SpiritProcessSkeleton}
   */
  @MockStrict
  private SpiritProcessSkeleton _activityCallerMock;

  /**
   * The mock object {@code PE0533_BlocageEquipementsContext}
   */
  @MockStrict
  private PE0533_BlocageEquipementsContext _contextMock;

  /**
   * Instance to evaluate
   */
  @MockStrict
  private PE0533_BlocageEquipements _instance;

  /***
   * The mock object {@code RavelResponseFactory}
   */
  @MockStrict
  private RavelResponseFactory _ravelResponseFactoryMock;

  /**
   * The mock object {@code IRavelResponse}
   */
  @MockStrict
  private IRavelResponse _responseMock;

  /**
   * Initialize before tests
   *
   * @throws Exception
   *           On errors Thrown in case of error during switch in attributes of parent class
   */
  @Before
  public void setUp() throws Exception
  {
    _exception = false;
    _instance = new PE0533_BlocageEquipements();
    _instance.initializeContext();
    Whitebox.setInternalState(_instance, "_tracabilite", __traceability); //$NON-NLS-1$
    Whitebox.setInternalState(_instance, "_processContext", _contextMock); //$NON-NLS-1$

    PowerMock.resetAll();

    PowerMock.mockStaticStrict(LocalDateTime.class);
    PowerMock.mockStaticStrict(RESProxy.class);
    PowerMock.mockStaticStrict(REXProxy.class);
    PowerMock.mockStaticStrict(RavelResponseFactory.class);
  }

  /**
   * Method that does the needed clean up.<br/>
   *
   * <b>Entrées:</b> N/A for this test method. <br/>
   * <b>Attendu:</b> Clean up of some of our data.
   *
   */
  @After
  public void tearDown()
  {
    _instance = null;
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.tesla.processes.PE0533.PE0533_BlocageEquipements#PE0533_BL001_VerifierDonnesCreation}.
   * <b>Entrées:</b> Not headers & no parameters & no request<br/>
   * <b>Attendu:</b> Error NOK, CAT-10, TRAITEMENT_ARRETE <br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void test_PE0533_BL001_VerifierDonnesCreation_000() throws Exception
  {
    final PE0533_BL001_VerifierDonneesReturn<PE0533_PostRequest> expected = new PE0533_BL001_VerifierDonneesReturn<>(RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, "Non respect du format d'entree de la STI")); //$NON-NLS-1$
    PE0533_BL001_VerifierDonneesReturn<PE0533_PostRequest> actual = null;

    final Request request = new Request(EMPTY_STRING, EMPTY_STRING, EMPTY_STRING);
    request.setHttpMethod(HttpMethod.POST);

    try
    {
      EasyMock.expect(_contextMock.getAutorization()).andReturn(null).once();
      EasyMock.expect(_contextMock.getXSource()).andReturn(null).once();
      EasyMock.expect(_contextMock.getXRequestId()).andReturn(null).once();
      EasyMock.expect(_contextMock.getXMessageId()).andReturn(null).once();
      EasyMock.expect(_contextMock.getXProcess()).andReturn(null).once();
      EasyMock.expect(_contextMock.getXActionId()).andReturn(null).once();
      EasyMock.expect(_contextMock.getXVersion()).andReturn(null).once();
      EasyMock.expect(_contextMock.getContentType()).andReturn(null).once();

      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_instance, "PE0533_BL001_VerifierDonnesCreation", __traceability, request); //$NON-NLS-1$
    }
    catch (final Throwable ignore)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertFalse(_exception);
      assertNotNull(actual);

      assertEquals(expected, actual);
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.tesla.processes.PE0533.PE0533_BlocageEquipements#PE0533_BL001_VerifierDonnesCreation}.
   * <b>Entrées:</b> Not headers & no parametes<br/>
   * <b>Attendu:</b> Error NOK, CAT-3, DONNEE_INVALIDE <br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void test_PE0533_BL001_VerifierDonnesCreation_001() throws Exception
  {
    final PE0533_BL001_VerifierDonneesReturn<PE0533_PostRequest> expected = new PE0533_BL001_VerifierDonneesReturn<>(RetourFactoryForTU.createNOK( //
        IMegConsts.CAT3, //
        IMegSpiritConsts.DONNEE_INVALIDE, //
        "Attribut(s) obligatoire(s) manquant(s): _listeEquipement, _listeIdOperationVieReseau")); //$NON-NLS-1$
    PE0533_BL001_VerifierDonneesReturn<PE0533_PostRequest> actual = null;

    final Request request = new Request(EMPTY_STRING, EMPTY_STRING, EMPTY_STRING);
    request.setHttpMethod(HttpMethod.POST);
    request.getRequestHeader()
        .addAll(Sets.newSet( //
            new RequestHeader() //
                .withName(IHttpHeadersConsts.AUTHORIZATION) //
                .withValue(__authorization), //
            new RequestHeader() //
                .withName(IHttpHeadersConsts.X_SOURCE) //
                .withValue(__xSource), //
            new RequestHeader() //
                .withName(IHttpHeadersConsts.X_REQUEST_ID) //
                .withValue(__xRequestId), //
            new RequestHeader() //
                .withName(IHttpHeadersConsts.X_MESSAGE_ID) //
                .withValue(__xMessageId), //
            new RequestHeader() //
                .withName(IHttpHeadersConsts.X_PROCESS) //
                .withValue(__xProcess), //
            new RequestHeader() //
                .withName(IHttpHeadersConsts.X_ACTION_ID) //
                .withValue(__xActionId), //
            new RequestHeader() //
                .withName(IHttpHeadersConsts.X_VERSION) //
                .withValue(__xVersion), //
            new RequestHeader() //
                .withName(IHttpHeadersConsts.CONTENT_TYPE) //
                .withValue(PE0533ContentType.invalid.name())));
    request.setPayload("{}"); //$NON-NLS-1$

    try
    {
      _contextMock.setAutorization(__authorization);
      EasyMock.expectLastCall().once();
      _contextMock.setXSource(__xSource);
      EasyMock.expectLastCall().once();
      _contextMock.setXRequestId(__xRequestId);
      EasyMock.expectLastCall().once();
      _contextMock.setXMessageId(__xMessageId);
      EasyMock.expectLastCall().once();
      _contextMock.setXProcess(__xProcess);
      EasyMock.expectLastCall().once();
      _contextMock.setXActionId(__xActionId);
      EasyMock.expectLastCall().once();
      _contextMock.setXVersion(__xVersion);
      EasyMock.expectLastCall().once();
      _contextMock.setContentType(PE0533ContentType.invalid.name());
      EasyMock.expectLastCall().once();

      EasyMock.expect(_contextMock.getAutorization()).andReturn(__authorization).once();
      EasyMock.expect(_contextMock.getXSource()).andReturn(__xSource).once();
      EasyMock.expect(_contextMock.getXRequestId()).andReturn(__xRequestId).once();
      EasyMock.expect(_contextMock.getXMessageId()).andReturn(__xMessageId).once();
      EasyMock.expect(_contextMock.getXProcess()).andReturn(__xProcess).once();
      EasyMock.expect(_contextMock.getXActionId()).andReturn(__xActionId).once();
      EasyMock.expect(_contextMock.getXVersion()).andReturn(__xVersion).times(2);
      EasyMock.expect(_contextMock.getContentType()).andReturn(PE0533ContentType.invalid).times(3);

      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_instance, "PE0533_BL001_VerifierDonnesCreation", __traceability, request); //$NON-NLS-1$
    }
    catch (final Throwable ignore)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertFalse(_exception);
      assertNotNull(actual);

      assertEquals(expected, actual);
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.tesla.processes.PE0533.PE0533_BlocageEquipements#PE0533_BL001_VerifierDonnesCreation}.
   * <b>Entrées:</b> Not headers & no parametes<br/>
   * <b>Attendu:</b> Error NOK, CAT-3, DONNEE_INVALIDE <br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @SuppressWarnings("unchecked")
  @Test
  public void test_PE0533_BL001_VerifierDonnesCreation_002() throws Exception
  {
    final PE0533_BL001_VerifierDonneesReturn<PE0533_PostRequest> expected = new PE0533_BL001_VerifierDonneesReturn<>(null,
        RetourFactoryForTU.createNOK( //
            IMegConsts.CAT3, //
            IMegSpiritConsts.DONNEE_INVALIDE, //
            "Attribut(s) obligatoire(s) manquant(s): _listeEquipement[]._referencePmBytel")); //$NON-NLS-1$
    PE0533_BL001_VerifierDonneesReturn<PE0533_PostRequest> actual = null;

    final Request request = new Request(EMPTY_STRING, EMPTY_STRING, EMPTY_STRING);
    request.setHttpMethod(HttpMethod.POST);
    request.getRequestHeader()
        .addAll(Sets.newSet( //
            new RequestHeader() //
                .withName(IHttpHeadersConsts.AUTHORIZATION) //
                .withValue(__authorization), //
            new RequestHeader() //
                .withName(IHttpHeadersConsts.X_SOURCE) //
                .withValue(__xSource), //
            new RequestHeader() //
                .withName(IHttpHeadersConsts.X_REQUEST_ID) //
                .withValue(__xRequestId), //
            new RequestHeader() //
                .withName(IHttpHeadersConsts.X_MESSAGE_ID) //
                .withValue(__xMessageId), //
            new RequestHeader() //
                .withName(IHttpHeadersConsts.X_PROCESS) //
                .withValue(__xProcess), //
            new RequestHeader() //
                .withName(IHttpHeadersConsts.X_ACTION_ID) //
                .withValue(__xActionId), //
            new RequestHeader() //
                .withName(IHttpHeadersConsts.X_VERSION) //
                .withValue(__xVersion), //
            new RequestHeader() //
                .withName(IHttpHeadersConsts.CONTENT_TYPE) //
                .withValue(__contentType.name())));
    final IRavelJson instance = new RavelJsonBuilder() //
        .profil("STARK") //$NON-NLS-1$
        .build(); //
    final IRavelJsonAdapter<PE0533_PostRequest> adapter = instance.adapter(PE0533_PostRequest.class);
    request.setPayload(adapter.toJson(new PE0533_PostRequest( //
        Sets.newSet(new PM(String.class.cast(null))), //
        __podam.manufacturePojoWithFullData(TreeSet.class, String.class))));

    try
    {
      _contextMock.setAutorization(__authorization);
      EasyMock.expectLastCall().once();
      _contextMock.setXSource(__xSource);
      EasyMock.expectLastCall().once();
      _contextMock.setXRequestId(__xRequestId);
      EasyMock.expectLastCall().once();
      _contextMock.setXMessageId(__xMessageId);
      EasyMock.expectLastCall().once();
      _contextMock.setXProcess(__xProcess);
      EasyMock.expectLastCall().once();
      _contextMock.setXActionId(__xActionId);
      EasyMock.expectLastCall().once();
      _contextMock.setXVersion(__xVersion);
      EasyMock.expectLastCall().once();
      _contextMock.setContentType(__contentType.name());
      EasyMock.expectLastCall().once();

      EasyMock.expect(_contextMock.getAutorization()).andReturn(__authorization).once();
      EasyMock.expect(_contextMock.getXSource()).andReturn(__xSource).once();
      EasyMock.expect(_contextMock.getXRequestId()).andReturn(__xRequestId).once();
      EasyMock.expect(_contextMock.getXMessageId()).andReturn(__xMessageId).once();
      EasyMock.expect(_contextMock.getXProcess()).andReturn(__xProcess).once();
      EasyMock.expect(_contextMock.getXActionId()).andReturn(__xActionId).once();
      EasyMock.expect(_contextMock.getXVersion()).andReturn(__xVersion).times(2);
      EasyMock.expect(_contextMock.getContentType()).andReturn(__contentType).times(3);

      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_instance, "PE0533_BL001_VerifierDonnesCreation", __traceability, request); //$NON-NLS-1$
    }
    catch (final Throwable ignore)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertFalse(_exception);
      assertNotNull(actual);

      assertEquals(expected, actual);
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.tesla.processes.PE0533.PE0533_BlocageEquipements#PE0533_BL001_VerifierDonnesCreation}.
   * <b>Entrées:</b> Not headers & no parametes<br/>
   * <b>Attendu:</b> Error NOK, CAT-3, DONNEE_INVALIDE <br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void test_PE0533_BL001_VerifierDonnesCreation_003() throws Exception
  {
    @SuppressWarnings("unchecked")
    final PE0533_PostRequest jsonRequest = new PE0533_PostRequest( //
        Sets.newSet(new PM(__podam.manufacturePojoWithFullData(String.class))), //
        __podam.manufacturePojoWithFullData(TreeSet.class, String.class));
    final PE0533_BL001_VerifierDonneesReturn<PE0533_PostRequest> expected = new PE0533_BL001_VerifierDonneesReturn<>(jsonRequest, RetourFactoryForTU.createOkRetour());
    PE0533_BL001_VerifierDonneesReturn<PE0533_PostRequest> actual = null;

    final Request request = new Request(EMPTY_STRING, EMPTY_STRING, EMPTY_STRING);
    request.setHttpMethod(HttpMethod.POST);
    request.getRequestHeader()
        .addAll(Sets.newSet( //
            new RequestHeader() //
                .withName(IHttpHeadersConsts.AUTHORIZATION) //
                .withValue(__authorization), //
            new RequestHeader() //
                .withName(IHttpHeadersConsts.X_SOURCE) //
                .withValue(__xSource), //
            new RequestHeader() //
                .withName(IHttpHeadersConsts.X_REQUEST_ID) //
                .withValue(__xRequestId), //
            new RequestHeader() //
                .withName(IHttpHeadersConsts.X_MESSAGE_ID) //
                .withValue(__xMessageId), //
            new RequestHeader() //
                .withName(IHttpHeadersConsts.X_PROCESS) //
                .withValue(__xProcess), //
            new RequestHeader() //
                .withName(IHttpHeadersConsts.X_ACTION_ID) //
                .withValue(__xActionId), //
            new RequestHeader() //
                .withName(IHttpHeadersConsts.X_VERSION) //
                .withValue(__xVersion), //
            new RequestHeader() //
                .withName(IHttpHeadersConsts.CONTENT_TYPE) //
                .withValue(__contentType.name())));
    final IRavelJson instance = new RavelJsonBuilder() //
        .profil("STARK") //$NON-NLS-1$
        .build(); //
    final IRavelJsonAdapter<PE0533_PostRequest> adapter = instance.adapter(PE0533_PostRequest.class);
    request.setPayload(adapter.toJson(jsonRequest));

    try
    {
      _contextMock.setAutorization(__authorization);
      EasyMock.expectLastCall().once();
      _contextMock.setXSource(__xSource);
      EasyMock.expectLastCall().once();
      _contextMock.setXRequestId(__xRequestId);
      EasyMock.expectLastCall().once();
      _contextMock.setXMessageId(__xMessageId);
      EasyMock.expectLastCall().once();
      _contextMock.setXProcess(__xProcess);
      EasyMock.expectLastCall().once();
      _contextMock.setXActionId(__xActionId);
      EasyMock.expectLastCall().once();
      _contextMock.setXVersion(__xVersion);
      EasyMock.expectLastCall().once();
      _contextMock.setContentType(__contentType.name());
      EasyMock.expectLastCall().once();

      EasyMock.expect(_contextMock.getAutorization()).andReturn(__authorization).once();
      EasyMock.expect(_contextMock.getXSource()).andReturn(__xSource).once();
      EasyMock.expect(_contextMock.getXRequestId()).andReturn(__xRequestId).once();
      EasyMock.expect(_contextMock.getXMessageId()).andReturn(__xMessageId).once();
      EasyMock.expect(_contextMock.getXProcess()).andReturn(__xProcess).once();
      EasyMock.expect(_contextMock.getXActionId()).andReturn(__xActionId).once();
      EasyMock.expect(_contextMock.getXVersion()).andReturn(__xVersion).times(2);
      EasyMock.expect(_contextMock.getContentType()).andReturn(__contentType).times(2);

      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_instance, "PE0533_BL001_VerifierDonnesCreation", __traceability, request); //$NON-NLS-1$
    }
    catch (final Throwable ignore)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertFalse(_exception);
      assertNotNull(actual);

      assertEquals(expected, actual);
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.tesla.processes.PE0533.PE0533_BlocageEquipements#PE0533_BL001_VerifierDonnesCreation}.
   * <b>Entrées:</b> Not headers & no parametes<br/>
   * <b>Attendu:</b> Error NOK, CAT-3, DONNEE_INVALIDE <br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @SuppressWarnings("unchecked")
  @Test
  public void test_PE0533_BL001_VerifierDonnesCreation_004() throws Exception
  {
    final PE0533_BL001_VerifierDonneesReturn<PE0533_PostRequest> expected = new PE0533_BL001_VerifierDonneesReturn<>(null,
        RetourFactoryForTU.createNOK( //
            IMegConsts.CAT3, //
            IMegSpiritConsts.DONNEE_INVALIDE, //
            "Attribut(s) obligatoire(s) manquant(s): _listeEquipement[]._nomOLT")); //$NON-NLS-1$
    PE0533_BL001_VerifierDonneesReturn<PE0533_PostRequest> actual = null;

    final Request request = new Request(EMPTY_STRING, EMPTY_STRING, EMPTY_STRING);
    request.setHttpMethod(HttpMethod.POST);
    request.getRequestHeader()
        .addAll(Sets.newSet( //
            new RequestHeader() //
                .withName(IHttpHeadersConsts.AUTHORIZATION) //
                .withValue(__authorization), //
            new RequestHeader() //
                .withName(IHttpHeadersConsts.X_SOURCE) //
                .withValue(__xSource), //
            new RequestHeader() //
                .withName(IHttpHeadersConsts.X_REQUEST_ID) //
                .withValue(__xRequestId), //
            new RequestHeader() //
                .withName(IHttpHeadersConsts.X_MESSAGE_ID) //
                .withValue(__xMessageId), //
            new RequestHeader() //
                .withName(IHttpHeadersConsts.X_PROCESS) //
                .withValue(__xProcess), //
            new RequestHeader() //
                .withName(IHttpHeadersConsts.X_ACTION_ID) //
                .withValue(__xActionId), //
            new RequestHeader() //
                .withName(IHttpHeadersConsts.X_VERSION) //
                .withValue(__xVersion), //
            new RequestHeader() //
                .withName(IHttpHeadersConsts.CONTENT_TYPE) //
                .withValue(__contentType.name())));
    final IRavelJson instance = new RavelJsonBuilder() //
        .profil("STARK") //$NON-NLS-1$
        .build(); //
    final IRavelJsonAdapter<PE0533_PostRequest> adapter = instance.adapter(PE0533_PostRequest.class);
    request.setPayload(adapter.toJson(new PE0533_PostRequest( //
        Sets.newSet(new OLT(String.class.cast(null))), //
        __podam.manufacturePojoWithFullData(TreeSet.class, String.class))));

    try
    {
      _contextMock.setAutorization(__authorization);
      EasyMock.expectLastCall().once();
      _contextMock.setXSource(__xSource);
      EasyMock.expectLastCall().once();
      _contextMock.setXRequestId(__xRequestId);
      EasyMock.expectLastCall().once();
      _contextMock.setXMessageId(__xMessageId);
      EasyMock.expectLastCall().once();
      _contextMock.setXProcess(__xProcess);
      EasyMock.expectLastCall().once();
      _contextMock.setXActionId(__xActionId);
      EasyMock.expectLastCall().once();
      _contextMock.setXVersion(__xVersion);
      EasyMock.expectLastCall().once();
      _contextMock.setContentType(__contentType.name());
      EasyMock.expectLastCall().once();

      EasyMock.expect(_contextMock.getAutorization()).andReturn(__authorization).once();
      EasyMock.expect(_contextMock.getXSource()).andReturn(__xSource).once();
      EasyMock.expect(_contextMock.getXRequestId()).andReturn(__xRequestId).once();
      EasyMock.expect(_contextMock.getXMessageId()).andReturn(__xMessageId).once();
      EasyMock.expect(_contextMock.getXProcess()).andReturn(__xProcess).once();
      EasyMock.expect(_contextMock.getXActionId()).andReturn(__xActionId).once();
      EasyMock.expect(_contextMock.getXVersion()).andReturn(__xVersion).times(2);
      EasyMock.expect(_contextMock.getContentType()).andReturn(__contentType).times(2);

      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_instance, "PE0533_BL001_VerifierDonnesCreation", __traceability, request); //$NON-NLS-1$
    }
    catch (final Throwable ignore)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertFalse(_exception);
      assertNotNull(actual);

      assertEquals(expected, actual);
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.tesla.processes.PE0533.PE0533_BlocageEquipements#PE0533_BL001_VerifierDonnesCreation}.
   * <b>Entrées:</b> Not headers & no parametes<br/>
   * <b>Attendu:</b> Error NOK, CAT-3, DONNEE_INVALIDE <br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void test_PE0533_BL001_VerifierDonnesCreation_005() throws Exception
  {
    @SuppressWarnings("unchecked")
    final PE0533_PostRequest jsonRequest = new PE0533_PostRequest( //
        Sets.newSet(__olt), //
        __podam.manufacturePojoWithFullData(TreeSet.class, String.class));

    final PE0533_BL001_VerifierDonneesReturn<PE0533_PostRequest> expected = new PE0533_BL001_VerifierDonneesReturn<>(jsonRequest, RetourFactoryForTU.createOkRetour());
    PE0533_BL001_VerifierDonneesReturn<PE0533_PostRequest> actual = null;

    final Request request = new Request(EMPTY_STRING, EMPTY_STRING, EMPTY_STRING);
    request.setHttpMethod(HttpMethod.POST);
    request.getRequestHeader()
        .addAll(Sets.newSet( //
            new RequestHeader() //
                .withName(IHttpHeadersConsts.AUTHORIZATION) //
                .withValue(__authorization), //
            new RequestHeader() //
                .withName(IHttpHeadersConsts.X_SOURCE) //
                .withValue(__xSource), //
            new RequestHeader() //
                .withName(IHttpHeadersConsts.X_REQUEST_ID) //
                .withValue(__xRequestId), //
            new RequestHeader() //
                .withName(IHttpHeadersConsts.X_MESSAGE_ID) //
                .withValue(__xMessageId), //
            new RequestHeader() //
                .withName(IHttpHeadersConsts.X_PROCESS) //
                .withValue(__xProcess), //
            new RequestHeader() //
                .withName(IHttpHeadersConsts.X_ACTION_ID) //
                .withValue(__xActionId), //
            new RequestHeader() //
                .withName(IHttpHeadersConsts.X_VERSION) //
                .withValue(__xVersion), //
            new RequestHeader() //
                .withName(IHttpHeadersConsts.CONTENT_TYPE) //
                .withValue(__contentType.name())));
    final IRavelJson instance = new RavelJsonBuilder() //
        .profil("STARK") //$NON-NLS-1$
        .build(); //
    final IRavelJsonAdapter<PE0533_PostRequest> adapter = instance.adapter(PE0533_PostRequest.class);
    request.setPayload(adapter.toJson(jsonRequest));

    try
    {
      _contextMock.setAutorization(__authorization);
      EasyMock.expectLastCall().once();
      _contextMock.setXSource(__xSource);
      EasyMock.expectLastCall().once();
      _contextMock.setXRequestId(__xRequestId);
      EasyMock.expectLastCall().once();
      _contextMock.setXMessageId(__xMessageId);
      EasyMock.expectLastCall().once();
      _contextMock.setXProcess(__xProcess);
      EasyMock.expectLastCall().once();
      _contextMock.setXActionId(__xActionId);
      EasyMock.expectLastCall().once();
      _contextMock.setXVersion(__xVersion);
      EasyMock.expectLastCall().once();
      _contextMock.setContentType(__contentType.name());
      EasyMock.expectLastCall().once();

      EasyMock.expect(_contextMock.getAutorization()).andReturn(__authorization).once();
      EasyMock.expect(_contextMock.getXSource()).andReturn(__xSource).once();
      EasyMock.expect(_contextMock.getXRequestId()).andReturn(__xRequestId).once();
      EasyMock.expect(_contextMock.getXMessageId()).andReturn(__xMessageId).once();
      EasyMock.expect(_contextMock.getXProcess()).andReturn(__xProcess).once();
      EasyMock.expect(_contextMock.getXActionId()).andReturn(__xActionId).once();
      EasyMock.expect(_contextMock.getXVersion()).andReturn(__xVersion).times(2);
      EasyMock.expect(_contextMock.getContentType()).andReturn(__contentType).times(2);

      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_instance, "PE0533_BL001_VerifierDonnesCreation", __traceability, request); //$NON-NLS-1$
    }
    catch (final Throwable ignore)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertFalse(_exception);
      assertNotNull(actual);

      assertEquals(expected, actual);
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.tesla.processes.PE0533.PE0533_BlocageEquipements#PE0533_BL002_FormaterReponseCreation}.
   * <b>Entrées:</b> Error NOK, CAT-3, DONNEE_INVALIDE <br/>
   * <b>Attendu:</b> Error messages for async response <br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void test_PE0533_BL002_FormaterReponseCreation_000() throws Exception
  {
    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegConsts.DONNEE_INCONNUE, __podam.manufacturePojo(String.class));
    final PE0533_BL002_FormaterReponseCreationReturn expected = new PE0533_BL002_FormaterReponseCreationReturn(retour.getDiagnostic(), retour.getLibelle());
    PE0533_BL002_FormaterReponseCreationReturn actual = null;

    try
    {
      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_instance, "PE0533_BL002_FormaterReponseCreation", __traceability, retour, __idBlocageEquipement); //$NON-NLS-1$
    }
    catch (final Throwable ignore)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertFalse(_exception);
      assertNotNull(actual);

      assertEquals(expected, actual);
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.tesla.processes.PE0533.PE0533_BlocageEquipements#PE0533_BL002_FormaterReponseCreation}.
   * <b>Entrées:</b> Error OK <br/>
   * <b>Attendu:</b> nominal message for async response <br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void test_PE0533_BL002_FormaterReponseCreation_001() throws Exception
  {
    final Retour retour = RetourFactoryForTU.createOkRetour();
    final PE0533_BL002_FormaterReponseCreationReturn expected = new PE0533_BL002_FormaterReponseCreationReturn(__idBlocageEquipement);
    PE0533_BL002_FormaterReponseCreationReturn actual = null;

    try
    {
      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_instance, "PE0533_BL002_FormaterReponseCreation", __traceability, retour, __idBlocageEquipement); //$NON-NLS-1$
    }
    catch (final Throwable ignore)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertFalse(_exception);
      assertNotNull(actual);

      assertEquals(expected, actual);
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.tesla.processes.PE0533.PE0533_BlocageEquipements#PE0533_BL200_CreerBlocageEquipements}.
   * <b>Entrées:</b> <br/>
   * <b>Attendu:</b> <br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void test_PE0533_BL200_CreerBlocageEquipements_000() throws Exception
  {
    final String errmsg = __podam.manufacturePojo(String.class);
    final RavelException expected = new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.CNCTOR_00010, errmsg);

    @SuppressWarnings("unchecked")
    final PE0533_PostRequest jsonRequest = new PE0533_PostRequest( //
        Sets.newSet(__olt, __pm), //
        __podam.manufacturePojoWithFullData(TreeSet.class, String.class));

    try
    {
      for (final String idOperationVieReseau : jsonRequest.getListeIdOperationVieReseau())
      {
        EasyMock.expect(REXProxy.getInstance()).andReturn(_rexMock).once();
        EasyMock.expect(_rexMock.operationVieReseauLireUn(__traceability, idOperationVieReseau)).andThrow(new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.CNCTOR_00010, errmsg)).once();
        break; // Exit after the first call
      }

      PowerMock.replayAll();

      Whitebox.invokeMethod(_instance, "PE0533_BL200_CreerBlocageEquipements", __traceability, jsonRequest); //$NON-NLS-1$
    }
    catch (final RavelException actual)
    {
      assertEquals(expected, actual);

      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertTrue(_exception);
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.tesla.processes.PE0533.PE0533_BlocageEquipements#PE0533_BL200_CreerBlocageEquipements}.
   * <b>Entrées:</b> <br/>
   * <b>Attendu:</b> <br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void test_PE0533_BL200_CreerBlocageEquipements_001() throws Exception
  {
    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "Aucun identifiant OperationVieReseau n’est trouve"); //$NON-NLS-1$
    final PE0533_BL200_CreerBlocageEquipementsReturn expected = new PE0533_BL200_CreerBlocageEquipementsReturn(null, retour);
    PE0533_BL200_CreerBlocageEquipementsReturn actual = null;

    @SuppressWarnings("unchecked")
    final PE0533_PostRequest jsonRequest = new PE0533_PostRequest( //
        Sets.newSet(__olt, __pm), //
        __podam.manufacturePojoWithFullData(TreeSet.class, String.class));

    try
    {
      for (final String idOperationVieReseau : jsonRequest.getListeIdOperationVieReseau())
      {
        EasyMock.expect(REXProxy.getInstance()).andReturn(_rexMock).once();
        EasyMock.expect(_rexMock.operationVieReseauLireUn(__traceability, idOperationVieReseau)).andReturn(new ConnectorResponse<Retour, OperationVieReseau>(RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, EMPTY_STRING), null)).once();
      }

      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_instance, "PE0533_BL200_CreerBlocageEquipements", __traceability, jsonRequest); //$NON-NLS-1$
    }
    catch (final Throwable ignore)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertFalse(_exception);
      assertNotNull(actual);

      assertEquals(expected, actual);
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.tesla.processes.PE0533.PE0533_BlocageEquipements#PE0533_BL200_CreerBlocageEquipements}.
   * <b>Entrées:</b> <br/>
   * <b>Attendu:</b> <br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void test_PE0533_BL200_CreerBlocageEquipements_002() throws Exception
  {
    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.ACCES_REFUSE, "liste equipements non eligible pour créer un Blocage Equipement"); //$NON-NLS-1$
    final PE0533_BL200_CreerBlocageEquipementsReturn expected = new PE0533_BL200_CreerBlocageEquipementsReturn(null, retour);
    PE0533_BL200_CreerBlocageEquipementsReturn actual = null;

    @SuppressWarnings("unchecked")
    final PE0533_PostRequest jsonRequest = new PE0533_PostRequest( //
        Sets.newSet(__olt, __pm), //
        __podam.manufacturePojoWithFullData(TreeSet.class, String.class));

    final OperationVieReseau operationVieReseau = new OperationVieReseau( //
        __podam.manufacturePojoWithFullData(String.class), //
        __podam.manufacturePojoWithFullData(String.class), //
        "ACQUITTE", //$NON-NLS-1$
        "{}"); //$NON-NLS-1$

    try
    {
      for (final String idOperationVieReseau : jsonRequest.getListeIdOperationVieReseau())
      {
        EasyMock.expect(REXProxy.getInstance()).andReturn(_rexMock).once();
        EasyMock.expect(_rexMock.operationVieReseauLireUn(__traceability, idOperationVieReseau)).andReturn(new ConnectorResponse<Retour, OperationVieReseau>(RetourFactoryForTU.createOkRetour(), operationVieReseau)).once();
      }

      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_instance, "PE0533_BL200_CreerBlocageEquipements", __traceability, jsonRequest); //$NON-NLS-1$
    }
    catch (final Throwable ignore)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertFalse(_exception);
      assertNotNull(actual);

      assertEquals(expected, actual);
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.tesla.processes.PE0533.PE0533_BlocageEquipements#PE0533_BL200_CreerBlocageEquipements}.
   * <b>Entrées:</b> <br/>
   * <b>Attendu:</b> <br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void test_PE0533_BL200_CreerBlocageEquipements_003() throws Exception
  {
    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, EMPTY_STRING);
    final PE0533_BL200_CreerBlocageEquipementsReturn expected = new PE0533_BL200_CreerBlocageEquipementsReturn(null, retour);
    PE0533_BL200_CreerBlocageEquipementsReturn actual = null;

    @SuppressWarnings("unchecked")
    final PE0533_PostRequest jsonRequest = new PE0533_PostRequest( //
        Sets.newSet(__olt, __pm), //
        __podam.manufacturePojoWithFullData(TreeSet.class, String.class));

    final IRavelJson instance = new RavelJsonBuilder() //
        .profil("STARK") //$NON-NLS-1$
        .build(); //
    final IRavelJsonAdapter<PE0529_PostRequest> adapter = instance.adapter(PE0529_PostRequest.class);

    final PE0529_PostRequest mockRequest = new PE0529_PostRequest(null, null);
    //mockRequest.setAjoutsPortsPon(Sets.newSet(new AjoutPortPon(new PositionPortPon(null, null, __nomOLT), null, null, null)));
    mockRequest.setAjoutsPortsPm( //
        Arrays.asList(new AjoutPortPm(new PositionPortPm(null, null, null, __referencePmBytel), //
            Arrays.asList(new LienPortPon(__nomOlt, null, null)), null, null)));

    final OperationVieReseau operationVieReseau = new OperationVieReseau( //
        __podam.manufacturePojoWithFullData(String.class), //
        __podam.manufacturePojoWithFullData(String.class), //
        "ACQUITTE", //$NON-NLS-1$
        adapter.toJson(mockRequest));

    try
    {
      for (final String idOperationVieReseau : jsonRequest.getListeIdOperationVieReseau())
      {
        EasyMock.expect(REXProxy.getInstance()).andReturn(_rexMock).once();
        EasyMock.expect(_rexMock.operationVieReseauLireUn(__traceability, idOperationVieReseau)).andReturn(new ConnectorResponse<Retour, OperationVieReseau>(RetourFactoryForTU.createOkRetour(), operationVieReseau)).once();
      }

      PowerMock.expectNew(BL800_ObtenirSequenceBuilder.class).andReturn(_bl800MockBuilder).once();
      EasyMock.expect(_bl800MockBuilder.tracabilite(__traceability)).andReturn(_bl800MockBuilder).once();
      EasyMock.expect(_bl800MockBuilder.code(UniqueIdConstant.ID_BLOCAGE_EQUIPEMENT)).andReturn(_bl800MockBuilder).once();
      EasyMock.expect(_bl800MockBuilder.build()).andReturn(_bl800Mock).once();
      EasyMock.expect(_bl800Mock.execute(EasyMock.anyObject(PE0533_BlocageEquipements.class))).andReturn(null).once();
      EasyMock.expect(_bl800Mock.getRetour()).andReturn(RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, EMPTY_STRING)).times(2);

      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_instance, "PE0533_BL200_CreerBlocageEquipements", __traceability, jsonRequest); //$NON-NLS-1$
    }
    catch (final Throwable ignore)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertFalse(_exception);
      assertNotNull(actual);

      assertEquals(expected, actual);
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.tesla.processes.PE0533.PE0533_BlocageEquipements#PE0533_BL200_CreerBlocageEquipements}.
   * <b>Entrées:</b> <br/>
   * <b>Attendu:</b> <br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void test_PE0533_BL200_CreerBlocageEquipements_004() throws Exception
  {
    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, EMPTY_STRING);
    final PE0533_BL200_CreerBlocageEquipementsReturn expected = new PE0533_BL200_CreerBlocageEquipementsReturn(null, retour);
    PE0533_BL200_CreerBlocageEquipementsReturn actual = null;

    @SuppressWarnings("unchecked")
    final PE0533_PostRequest jsonRequest = new PE0533_PostRequest( //
        Sets.newSet(__olt, __pm), //
        __podam.manufacturePojoWithFullData(TreeSet.class, String.class));

    final IRavelJson instance = new RavelJsonBuilder() //
        .profil("STARK") //$NON-NLS-1$
        .build(); //
    final IRavelJsonAdapter<PE0529_PostRequest> adapter = instance.adapter(PE0529_PostRequest.class);

    final PE0529_PostRequest mockRequest = new PE0529_PostRequest(null, null);
    //mockRequest.setAjoutsPortsPon(Sets.newSet(new AjoutPortPon(new PositionPortPon(null, null, __nomOLT), null, null, null)));
    mockRequest.setAjoutsPortsPm( //
        Arrays.asList(new AjoutPortPm(new PositionPortPm(null, null, null, __referencePmBytel), //
            Arrays.asList(new LienPortPon(__nomOlt, null, null)), null, null)));

    final OperationVieReseau operationVieReseau = new OperationVieReseau( //
        __podam.manufacturePojoWithFullData(String.class), //
        __podam.manufacturePojoWithFullData(String.class), //
        "ACQUITTE", //$NON-NLS-1$
        adapter.toJson(mockRequest));

    final Set<com.bytel.spirit.common.shared.saab.rex.Equipement> equipements = new TreeSet<>(new EquipementComparator());
    equipements.addAll(jsonRequest.getListeEquipement().stream().map(Equipement::toSAAB).collect(Collectors.toSet()));
    final BlocageEquipement blocageEquipement = new BlocageEquipement(__idBlocageEquipement, StatutBlockage.ACTIF.name(), jsonRequest.getListeIdOperationVieReseau().stream().collect(Collectors.toSet()), equipements);

    try
    {
      for (final String idOperationVieReseau : jsonRequest.getListeIdOperationVieReseau())
      {
        EasyMock.expect(REXProxy.getInstance()).andReturn(_rexMock).once();
        EasyMock.expect(_rexMock.operationVieReseauLireUn(__traceability, idOperationVieReseau)).andReturn(new ConnectorResponse<Retour, OperationVieReseau>(RetourFactoryForTU.createOkRetour(), operationVieReseau)).once();
      }

      PowerMock.expectNew(BL800_ObtenirSequenceBuilder.class).andReturn(_bl800MockBuilder).once();
      EasyMock.expect(_bl800MockBuilder.tracabilite(__traceability)).andReturn(_bl800MockBuilder).once();
      EasyMock.expect(_bl800MockBuilder.code(UniqueIdConstant.ID_BLOCAGE_EQUIPEMENT)).andReturn(_bl800MockBuilder).once();
      EasyMock.expect(_bl800MockBuilder.build()).andReturn(_bl800Mock).once();
      EasyMock.expect(_bl800Mock.execute(EasyMock.anyObject(PE0533_BlocageEquipements.class))).andReturn(__idBlocageEquipement).once();
      EasyMock.expect(_bl800Mock.getRetour()).andReturn(RetourFactoryForTU.createOkRetour()).once();

      EasyMock.expect(REXProxy.getInstance()).andReturn(_rexMock).once();
      EasyMock.expect(_rexMock.blocageEquipementCreer(__traceability, blocageEquipement)).andReturn(new ConnectorResponse<Retour, Nothing>(RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, EMPTY_STRING), null)).once();

      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_instance, "PE0533_BL200_CreerBlocageEquipements", __traceability, jsonRequest); //$NON-NLS-1$
    }
    catch (final Throwable ignore)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertFalse(_exception);
      assertNotNull(actual);

      assertEquals(expected, actual);
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.tesla.processes.PE0533.PE0533_BlocageEquipements#PE0533_BL200_CreerBlocageEquipements}.
   * <b>Entrées:</b> <br/>
   * <b>Attendu:</b> <br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void test_PE0533_BL200_CreerBlocageEquipements_005() throws Exception
  {
    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, EMPTY_STRING);
    final PE0533_BL200_CreerBlocageEquipementsReturn expected = new PE0533_BL200_CreerBlocageEquipementsReturn(null, retour);
    PE0533_BL200_CreerBlocageEquipementsReturn actual = null;

    @SuppressWarnings("unchecked")
    final PE0533_PostRequest jsonRequest = new PE0533_PostRequest( //
        Sets.newSet(__olt, __pm), //
        __podam.manufacturePojoWithFullData(TreeSet.class, String.class));

    final IRavelJson instance = new RavelJsonBuilder() //
        .profil("STARK") //$NON-NLS-1$
        .build(); //
    final IRavelJsonAdapter<PE0529_PostRequest> adapter = instance.adapter(PE0529_PostRequest.class);

    final PE0529_PostRequest mockRequest = new PE0529_PostRequest(null, null);
    //mockRequest.setAjoutsPortsPon(Sets.newSet(new AjoutPortPon(new PositionPortPon(null, null, __nomOLT), null, null, null)));
    mockRequest.setAjoutsPortsPm( //
        Arrays.asList(new AjoutPortPm(new PositionPortPm(null, null, null, __referencePmBytel), //
            Arrays.asList(new LienPortPon(__nomOlt, null, null)), null, null)));

    final OperationVieReseau operationVieReseau = new OperationVieReseau( //
        __podam.manufacturePojoWithFullData(String.class), //
        __podam.manufacturePojoWithFullData(String.class), //
        "ACQUITTE", //$NON-NLS-1$
        adapter.toJson(mockRequest));

    final Set<com.bytel.spirit.common.shared.saab.rex.Equipement> equipements = new TreeSet<>(new EquipementComparator());
    equipements.addAll(jsonRequest.getListeEquipement().stream().map(Equipement::toSAAB).collect(Collectors.toSet()));
    final BlocageEquipement blocageEquipement = new BlocageEquipement(__idBlocageEquipement, StatutBlockage.ACTIF.name(), jsonRequest.getListeIdOperationVieReseau().stream().collect(Collectors.toSet()), equipements);

    try
    {
      for (final String idOperationVieReseau : jsonRequest.getListeIdOperationVieReseau())
      {
        EasyMock.expect(REXProxy.getInstance()).andReturn(_rexMock).once();
        EasyMock.expect(_rexMock.operationVieReseauLireUn(__traceability, idOperationVieReseau)).andReturn(new ConnectorResponse<Retour, OperationVieReseau>(RetourFactoryForTU.createOkRetour(), operationVieReseau)).once();
      }

      PowerMock.expectNew(BL800_ObtenirSequenceBuilder.class).andReturn(_bl800MockBuilder).once();
      EasyMock.expect(_bl800MockBuilder.tracabilite(__traceability)).andReturn(_bl800MockBuilder).once();
      EasyMock.expect(_bl800MockBuilder.code(UniqueIdConstant.ID_BLOCAGE_EQUIPEMENT)).andReturn(_bl800MockBuilder).once();
      EasyMock.expect(_bl800MockBuilder.build()).andReturn(_bl800Mock).once();
      EasyMock.expect(_bl800Mock.execute(EasyMock.anyObject(PE0533_BlocageEquipements.class))).andReturn(__idBlocageEquipement).once();
      EasyMock.expect(_bl800Mock.getRetour()).andReturn(RetourFactoryForTU.createOkRetour()).once();

      EasyMock.expect(REXProxy.getInstance()).andReturn(_rexMock).once();
      EasyMock.expect(_rexMock.blocageEquipementCreer(__traceability, blocageEquipement)).andReturn(new ConnectorResponse<Retour, Nothing>(RetourFactoryForTU.createOkRetour(), null)).once();

      for (String referenceBoitierPm : __pm.getListeReferenceBoitierPm())
      {
        EasyMock.expect(RESProxy.getInstance()).andReturn(_resMock).once();
        EasyMock.expect(LocalDateTime.now()).andReturn(__now).once();
        EasyMock.expect(_resMock.pmCompositeModifierSurchargePriseClientBoitierPM(__traceability, __referencePmBytel, referenceBoitierPm, StatutBlockage.ACTIF.name(), MessageFormat.format(Messages.getString("PE0533.blocageVR"), DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZ.format(__now)))).andReturn(new ConnectorResponse<Retour, Nothing>(RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, EMPTY_STRING), null)); //$NON-NLS-1$
        break; // Exit after the first call
      }

      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_instance, "PE0533_BL200_CreerBlocageEquipements", __traceability, jsonRequest); //$NON-NLS-1$
    }
    catch (final Throwable ignore)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertFalse(_exception);
      assertNotNull(actual);

      assertEquals(expected, actual);
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.tesla.processes.PE0533.PE0533_BlocageEquipements#PE0533_BL200_CreerBlocageEquipements}.
   * <b>Entrées:</b> <br/>
   * <b>Attendu:</b> <br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void test_PE0533_BL200_CreerBlocageEquipements_006() throws Exception
  {
    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, EMPTY_STRING);
    final PE0533_BL200_CreerBlocageEquipementsReturn expected = new PE0533_BL200_CreerBlocageEquipementsReturn(null, retour);
    PE0533_BL200_CreerBlocageEquipementsReturn actual = null;

    PM pm = new PM(__pm).withListeReferenceBoitierPm(null);

    @SuppressWarnings("unchecked")
    final PE0533_PostRequest jsonRequest = new PE0533_PostRequest( //
        Sets.newSet(__olt, pm), //
        __podam.manufacturePojoWithFullData(TreeSet.class, String.class));

    final IRavelJson instance = new RavelJsonBuilder() //
        .profil("STARK") //$NON-NLS-1$
        .build(); //
    final IRavelJsonAdapter<PE0529_PostRequest> adapter = instance.adapter(PE0529_PostRequest.class);

    final PE0529_PostRequest mockRequest = new PE0529_PostRequest(null, null);
    //mockRequest.setAjoutsPortsPon(Sets.newSet(new AjoutPortPon(new PositionPortPon(null, null, __nomOLT), null, null, null)));
    mockRequest.setAjoutsPortsPm( //
        Arrays.asList(new AjoutPortPm(new PositionPortPm(null, null, null, __referencePmBytel), //
            Arrays.asList(new LienPortPon(__nomOlt, null, null)), null, null)));

    final OperationVieReseau operationVieReseau = new OperationVieReseau( //
        __podam.manufacturePojoWithFullData(String.class), //
        __podam.manufacturePojoWithFullData(String.class), //
        "ACQUITTE", //$NON-NLS-1$
        adapter.toJson(mockRequest));

    final Set<com.bytel.spirit.common.shared.saab.rex.Equipement> equipements = new TreeSet<>(new EquipementComparator());
    equipements.addAll(jsonRequest.getListeEquipement().stream().map(Equipement::toSAAB).collect(Collectors.toSet()));
    final BlocageEquipement blocageEquipement = new BlocageEquipement(__idBlocageEquipement, StatutBlockage.ACTIF.name(), jsonRequest.getListeIdOperationVieReseau().stream().collect(Collectors.toSet()), equipements);

    try
    {
      for (final String idOperationVieReseau : jsonRequest.getListeIdOperationVieReseau())
      {
        EasyMock.expect(REXProxy.getInstance()).andReturn(_rexMock).once();
        EasyMock.expect(_rexMock.operationVieReseauLireUn(__traceability, idOperationVieReseau)).andReturn(new ConnectorResponse<Retour, OperationVieReseau>(RetourFactoryForTU.createOkRetour(), operationVieReseau)).once();
      }

      PowerMock.expectNew(BL800_ObtenirSequenceBuilder.class).andReturn(_bl800MockBuilder).once();
      EasyMock.expect(_bl800MockBuilder.tracabilite(__traceability)).andReturn(_bl800MockBuilder).once();
      EasyMock.expect(_bl800MockBuilder.code(UniqueIdConstant.ID_BLOCAGE_EQUIPEMENT)).andReturn(_bl800MockBuilder).once();
      EasyMock.expect(_bl800MockBuilder.build()).andReturn(_bl800Mock).once();
      EasyMock.expect(_bl800Mock.execute(EasyMock.anyObject(PE0533_BlocageEquipements.class))).andReturn(__idBlocageEquipement).once();
      EasyMock.expect(_bl800Mock.getRetour()).andReturn(RetourFactoryForTU.createOkRetour()).once();

      EasyMock.expect(REXProxy.getInstance()).andReturn(_rexMock).once();
      EasyMock.expect(_rexMock.blocageEquipementCreer(__traceability, blocageEquipement)).andReturn(new ConnectorResponse<Retour, Nothing>(RetourFactoryForTU.createOkRetour(), null)).once();

      EasyMock.expect(RESProxy.getInstance()).andReturn(_resMock).once();
      EasyMock.expect(LocalDateTime.now()).andReturn(__now).once();
      EasyMock.expect(_resMock.pmCompositeModifierSurchargePriseClientPM(__traceability, __referencePmBytel, StatutBlockage.ACTIF.name(), MessageFormat.format(Messages.getString("PE0533.blocageVR"), DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZ.format(__now)))).andReturn(new ConnectorResponse<Retour, Nothing>(RetourFactoryForTU.createOkRetour(), null)); //$NON-NLS-1$

      for (Integer positionCarte : __olt.getListePositionCarte())
      {
        EasyMock.expect(RESProxy.getInstance()).andReturn(_resMock).once();
        EasyMock.expect(LocalDateTime.now()).andReturn(__now).once();
        EasyMock.expect(_resMock.oltCompositeModifierSurchargePriseClientCarte(__traceability, __nomOlt, positionCarte.toString(), StatutBlockage.ACTIF.name(), MessageFormat.format(Messages.getString("PE0533.blocageVR"), DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZ.format(__now)))).andReturn(new ConnectorResponse<Retour, Nothing>(RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, EMPTY_STRING), null)); //$NON-NLS-1$
        break; // Exit after the first call
      }

      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_instance, "PE0533_BL200_CreerBlocageEquipements", __traceability, jsonRequest); //$NON-NLS-1$
    }
    catch (final Throwable ignore)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertFalse(_exception);
      assertNotNull(actual);

      assertEquals(expected, actual);
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.tesla.processes.PE0533.PE0533_BlocageEquipements#PE0533_BL200_CreerBlocageEquipements}.
   * <b>Entrées:</b> <br/>
   * <b>Attendu:</b> <br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void test_PE0533_BL200_CreerBlocageEquipements_007() throws Exception
  {
    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, EMPTY_STRING);
    final PE0533_BL200_CreerBlocageEquipementsReturn expected = new PE0533_BL200_CreerBlocageEquipementsReturn(null, retour);
    PE0533_BL200_CreerBlocageEquipementsReturn actual = null;

    final PM pm = new PM(__pm).withListeReferenceBoitierPm(null);
    final OLT olt = new OLT(__olt).withListPositionCarte(null);

    @SuppressWarnings("unchecked")
    final PE0533_PostRequest jsonRequest = new PE0533_PostRequest( //
        Sets.newSet(olt, pm), //
        __podam.manufacturePojoWithFullData(TreeSet.class, String.class));

    final IRavelJson instance = new RavelJsonBuilder() //
        .profil("STARK") //$NON-NLS-1$
        .build(); //
    final IRavelJsonAdapter<PE0529_PostRequest> adapter = instance.adapter(PE0529_PostRequest.class);

    final PE0529_PostRequest mockRequest = new PE0529_PostRequest(null, null);
    //mockRequest.setAjoutsPortsPon(Sets.newSet(new AjoutPortPon(new PositionPortPon(null, null, __nomOLT), null, null, null)));
    mockRequest.setAjoutsPortsPm( //
        Arrays.asList(new AjoutPortPm(new PositionPortPm(null, null, null, __referencePmBytel), //
            Arrays.asList(new LienPortPon(__nomOlt, null, null)), null, null)));

    final OperationVieReseau operationVieReseau = new OperationVieReseau( //
        __podam.manufacturePojoWithFullData(String.class), //
        __podam.manufacturePojoWithFullData(String.class), //
        "ACQUITTE", //$NON-NLS-1$
        adapter.toJson(mockRequest));

    final Set<com.bytel.spirit.common.shared.saab.rex.Equipement> equipements = new TreeSet<>(new EquipementComparator());
    equipements.addAll(jsonRequest.getListeEquipement().stream().map(Equipement::toSAAB).collect(Collectors.toSet()));
    final BlocageEquipement blocageEquipement = new BlocageEquipement(__idBlocageEquipement, StatutBlockage.ACTIF.name(), jsonRequest.getListeIdOperationVieReseau().stream().collect(Collectors.toSet()), equipements);

    final ListeCleRechercheBlocageEquipementRequest listeCleRechercheBlocageEquipementRequest = new ListeCleRechercheBlocageEquipementRequest(Arrays.asList( //
        new CleRechercheBlocageEquipement("OLT", __nomOlt, __idBlocageEquipement), //$NON-NLS-1$
        new CleRechercheBlocageEquipement("PM", __referencePmBytel, __idBlocageEquipement))); //$NON-NLS-1$

    try
    {
      for (final String idOperationVieReseau : jsonRequest.getListeIdOperationVieReseau())
      {
        EasyMock.expect(REXProxy.getInstance()).andReturn(_rexMock).once();
        EasyMock.expect(_rexMock.operationVieReseauLireUn(__traceability, idOperationVieReseau)).andReturn(new ConnectorResponse<Retour, OperationVieReseau>(RetourFactoryForTU.createOkRetour(), operationVieReseau)).once();
      }

      PowerMock.expectNew(BL800_ObtenirSequenceBuilder.class).andReturn(_bl800MockBuilder).once();
      EasyMock.expect(_bl800MockBuilder.tracabilite(__traceability)).andReturn(_bl800MockBuilder).once();
      EasyMock.expect(_bl800MockBuilder.code(UniqueIdConstant.ID_BLOCAGE_EQUIPEMENT)).andReturn(_bl800MockBuilder).once();
      EasyMock.expect(_bl800MockBuilder.build()).andReturn(_bl800Mock).once();
      EasyMock.expect(_bl800Mock.execute(EasyMock.anyObject(PE0533_BlocageEquipements.class))).andReturn(__idBlocageEquipement).once();
      EasyMock.expect(_bl800Mock.getRetour()).andReturn(RetourFactoryForTU.createOkRetour()).once();

      EasyMock.expect(REXProxy.getInstance()).andReturn(_rexMock).once();
      EasyMock.expect(_rexMock.blocageEquipementCreer(__traceability, blocageEquipement)).andReturn(new ConnectorResponse<Retour, Nothing>(RetourFactoryForTU.createOkRetour(), null)).once();

      EasyMock.expect(RESProxy.getInstance()).andReturn(_resMock).once();
      EasyMock.expect(LocalDateTime.now()).andReturn(__now).once();
      EasyMock.expect(_resMock.pmCompositeModifierSurchargePriseClientPM(__traceability, __referencePmBytel, StatutBlockage.ACTIF.name(), MessageFormat.format(Messages.getString("PE0533.blocageVR"), DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZ.format(__now)))).andReturn(new ConnectorResponse<Retour, Nothing>(RetourFactoryForTU.createOkRetour(), null)); //$NON-NLS-1$

      EasyMock.expect(RESProxy.getInstance()).andReturn(_resMock).once();
      EasyMock.expect(LocalDateTime.now()).andReturn(__now).once();
      EasyMock.expect(_resMock.oltCompositeModifierSurchargePriseClientOLT(__traceability, __nomOlt, StatutBlockage.ACTIF.name(), MessageFormat.format(Messages.getString("PE0533.blocageVR"), DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZ.format(__now)))).andReturn(new ConnectorResponse<Retour, Nothing>(RetourFactoryForTU.createOkRetour(), null)); //$NON-NLS-1$

      EasyMock.expect(REXProxy.getInstance()).andReturn(_rexMock).once();
      EasyMock.expect(_rexMock.cleRechercheBlocageEquipementCreerListe(__traceability, listeCleRechercheBlocageEquipementRequest)).andReturn(new ConnectorResponse<Retour, Nothing>(RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, EMPTY_STRING), null)).once();

      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_instance, "PE0533_BL200_CreerBlocageEquipements", __traceability, jsonRequest); //$NON-NLS-1$
    }
    catch (final Throwable ignore)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertFalse(_exception);
      assertNotNull(actual);

      assertEquals(expected, actual);
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.tesla.processes.PE0533.PE0533_BlocageEquipements#PE0533_BL200_CreerBlocageEquipements}.
   * <b>Entrées:</b> <br/>
   * <b>Attendu:</b> <br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void test_PE0533_BL200_CreerBlocageEquipements_008() throws Exception
  {
    final PE0533_BL200_CreerBlocageEquipementsReturn expected = new PE0533_BL200_CreerBlocageEquipementsReturn(__idBlocageEquipement, RetourFactoryForTU.createOkRetour());
    PE0533_BL200_CreerBlocageEquipementsReturn actual = null;

    @SuppressWarnings("unchecked")
    final PE0533_PostRequest jsonRequest = new PE0533_PostRequest( //
        Sets.newSet(__olt, __pm), //
        __podam.manufacturePojoWithFullData(TreeSet.class, String.class));

    final IRavelJson instance = new RavelJsonBuilder() //
        .profil("STARK") //$NON-NLS-1$
        .build(); //
    final IRavelJsonAdapter<PE0529_PostRequest> adapter = instance.adapter(PE0529_PostRequest.class);

    final PE0529_PostRequest mockRequest = new PE0529_PostRequest(null, null);
    //mockRequest.setAjoutsPortsPon(Sets.newSet(new AjoutPortPon(new PositionPortPon(null, null, __nomOLT), null, null, null)));
    mockRequest.setAjoutsPortsPm( //
        Arrays.asList(new AjoutPortPm(new PositionPortPm(null, null, null, __referencePmBytel), //
            Arrays.asList(new LienPortPon(__nomOlt, null, null)), null, null)));

    final OperationVieReseau operationVieReseau = new OperationVieReseau( //
        __podam.manufacturePojoWithFullData(String.class), //
        __podam.manufacturePojoWithFullData(String.class), //
        "ACQUITTE", //$NON-NLS-1$
        adapter.toJson(mockRequest));

    final Set<com.bytel.spirit.common.shared.saab.rex.Equipement> equipements = new TreeSet<>(new EquipementComparator());
    equipements.addAll(jsonRequest.getListeEquipement().stream().map(Equipement::toSAAB).collect(Collectors.toSet()));
    final BlocageEquipement blocageEquipement = new BlocageEquipement(__idBlocageEquipement, StatutBlockage.ACTIF.name(), jsonRequest.getListeIdOperationVieReseau().stream().collect(Collectors.toSet()), equipements);

    final Set<CleRechercheBlocageEquipement> listeCleRechercheBlocageEquipementRequest = new TreeSet<>(new CleRechercheBlocageEquipementComparator());
    listeCleRechercheBlocageEquipementRequest.add(new CleRechercheBlocageEquipement("PM", __referencePmBytel, __idBlocageEquipement)); //$NON-NLS-1$
    __pm.getListeReferenceBoitierPm().stream().map(referenceBoitierPm -> new CleRechercheBlocageEquipement("BOITIER", new StringBuilder().append(__referencePmBytel).append("|").append(referenceBoitierPm).toString(), __idBlocageEquipement)) // //$NON-NLS-1$ //$NON-NLS-2$
        .collect(Collectors.toSet()) //
        .forEach(listeCleRechercheBlocageEquipementRequest::add);
    listeCleRechercheBlocageEquipementRequest.add(new CleRechercheBlocageEquipement("OLT", __nomOlt, __idBlocageEquipement)); //$NON-NLS-1$
    __olt.getListePositionCarte().stream().map(positionCarte -> new CleRechercheBlocageEquipement("CARTE", new StringBuilder().append(__nomOlt).append("|").append(positionCarte).toString(), __idBlocageEquipement)) // //$NON-NLS-1$ //$NON-NLS-2$
        .collect(Collectors.toSet()) //
        .forEach(listeCleRechercheBlocageEquipementRequest::add);

    try
    {
      for (final String idOperationVieReseau : jsonRequest.getListeIdOperationVieReseau())
      {
        EasyMock.expect(REXProxy.getInstance()).andReturn(_rexMock).once();
        EasyMock.expect(_rexMock.operationVieReseauLireUn(__traceability, idOperationVieReseau)).andReturn(new ConnectorResponse<Retour, OperationVieReseau>(RetourFactoryForTU.createOkRetour(), operationVieReseau)).once();
      }

      PowerMock.expectNew(BL800_ObtenirSequenceBuilder.class).andReturn(_bl800MockBuilder).once();
      EasyMock.expect(_bl800MockBuilder.tracabilite(__traceability)).andReturn(_bl800MockBuilder).once();
      EasyMock.expect(_bl800MockBuilder.code(UniqueIdConstant.ID_BLOCAGE_EQUIPEMENT)).andReturn(_bl800MockBuilder).once();
      EasyMock.expect(_bl800MockBuilder.build()).andReturn(_bl800Mock).once();
      EasyMock.expect(_bl800Mock.execute(EasyMock.anyObject(PE0533_BlocageEquipements.class))).andReturn(__idBlocageEquipement).once();
      EasyMock.expect(_bl800Mock.getRetour()).andReturn(RetourFactoryForTU.createOkRetour()).once();

      EasyMock.expect(REXProxy.getInstance()).andReturn(_rexMock).once();
      EasyMock.expect(_rexMock.blocageEquipementCreer(__traceability, blocageEquipement)).andReturn(new ConnectorResponse<Retour, Nothing>(RetourFactoryForTU.createOkRetour(), null)).once();

      for (String referenceBoitierPm : __pm.getListeReferenceBoitierPm())
      {
        EasyMock.expect(RESProxy.getInstance()).andReturn(_resMock).once();
        EasyMock.expect(LocalDateTime.now()).andReturn(__now).once();
        EasyMock.expect(_resMock.pmCompositeModifierSurchargePriseClientBoitierPM(__traceability, __referencePmBytel, referenceBoitierPm, StatutBlockage.ACTIF.name(), MessageFormat.format(Messages.getString("PE0533.blocageVR"), DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZ.format(__now)))).andReturn(new ConnectorResponse<Retour, Nothing>(RetourFactoryForTU.createOkRetour(), null)); //$NON-NLS-1$
      }

      for (Integer positionCarte : __olt.getListePositionCarte())
      {
        EasyMock.expect(RESProxy.getInstance()).andReturn(_resMock).once();
        EasyMock.expect(LocalDateTime.now()).andReturn(__now).once();
        EasyMock.expect(_resMock.oltCompositeModifierSurchargePriseClientCarte(__traceability, __nomOlt, positionCarte.toString(), StatutBlockage.ACTIF.name(), MessageFormat.format(Messages.getString("PE0533.blocageVR"), DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZ.format(__now)))).andReturn(new ConnectorResponse<Retour, Nothing>(RetourFactoryForTU.createOkRetour(), null)); //$NON-NLS-1$
      }

      EasyMock.expect(REXProxy.getInstance()).andReturn(_rexMock).once();
      EasyMock.expect(_rexMock.cleRechercheBlocageEquipementCreerListe(__traceability, new ListeCleRechercheBlocageEquipementRequest(new ArrayList<>(listeCleRechercheBlocageEquipementRequest)))).andReturn(new ConnectorResponse<Retour, Nothing>(RetourFactoryForTU.createOkRetour(), null)).once();

      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_instance, "PE0533_BL200_CreerBlocageEquipements", __traceability, jsonRequest); //$NON-NLS-1$
    }
    catch (final Throwable ignore)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertFalse(_exception);
      assertNotNull(actual);

      assertEquals(expected, actual);
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.tesla.processes.PE0533.PE0533_BlocageEquipements#PE0533_BL200_CreerBlocageEquipements}.
   * <b>Entrées:</b> <br/>
   * <b>Attendu:</b> <br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void test_PE0533_BL200_CreerBlocageEquipements_009() throws Exception
  {
    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.ACCES_REFUSE, "Operation vie reseau non eligible pour créer un Blocage Prise Clients"); //$NON-NLS-1$
    final PE0533_BL200_CreerBlocageEquipementsReturn expected = new PE0533_BL200_CreerBlocageEquipementsReturn(null, retour);
    PE0533_BL200_CreerBlocageEquipementsReturn actual = null;

    @SuppressWarnings("unchecked")
    final PE0533_PostRequest jsonRequest = new PE0533_PostRequest( //
        Sets.newSet(__olt, __pm), //
        __podam.manufacturePojoWithFullData(TreeSet.class, String.class));

    final OperationVieReseau operationVieReseau = new OperationVieReseau( //
        __podam.manufacturePojoWithFullData(String.class), //
        __podam.manufacturePojoWithFullData(String.class), //
        OperationVieReseauStatut.OBSOLETE.name(), //
        "{}"); //$NON-NLS-1$

    try
    {
      for (final String idOperationVieReseau : jsonRequest.getListeIdOperationVieReseau())
      {
        EasyMock.expect(REXProxy.getInstance()).andReturn(_rexMock).once();
        EasyMock.expect(_rexMock.operationVieReseauLireUn(__traceability, idOperationVieReseau)).andReturn(new ConnectorResponse<Retour, OperationVieReseau>(RetourFactoryForTU.createOkRetour(), operationVieReseau)).once();
      }

      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_instance, "PE0533_BL200_CreerBlocageEquipements", __traceability, jsonRequest); //$NON-NLS-1$
    }
    catch (final Throwable ignore)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertFalse(_exception);
      assertNotNull(actual);

      assertEquals(expected, actual);
    }
  }

  /**
   * Test method for {@link com.bytel.spirit.tesla.processes.PE0533.PE0533_BlocageEquipements}. <b>Entrées:</b> <br/>
   * <b>Attendu:</b> <br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void test_PE0533_BlocageEquipements_000() throws Exception
  {
    _instance = PowerMock.createPartialMock(PE0533_BlocageEquipements.class, "PE0533_BL001_VerifierDonnesCreation", "PE0533_BL002_FormaterReponseCreation", "PE0533_BL200_CreerBlocageEquipements"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    Whitebox.setInternalState(_instance, "_processContext", _contextMock); //$NON-NLS-1$
    Whitebox.setInternalState(_instance, "_tracabilite", __traceability); //$NON-NLS-1$

    final String errmsg = __podam.manufacturePojo(String.class);
    final Retour expected = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, errmsg);
    Retour actual = null;

    final Request request = new Request(EMPTY_STRING, EMPTY_STRING, EMPTY_STRING);
    request.setHttpMethod(HttpMethod.POST);

    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, errmsg, null);
    final PE0533_BL002_FormaterReponseCreationReturn bl002 = new PE0533_BL002_FormaterReponseCreationReturn(retour.getDiagnostic(), retour.getLibelle());

    try
    {
      _contextMock.setState(PE0533State.PE0533_SYNC);
      EasyMock.expectLastCall().once();

      final Method method = _instance.getClass().getDeclaredMethod("startPostProcess", Request.class, Tracabilite.class); //$NON-NLS-1$
      final Matcher matcher = Pattern.compile("\\$\\$([0-9a-f]+)\\.").matcher(method.toString()); //$NON-NLS-1$
      while (matcher.find())
      {
        expected.setActivite("PE0533_BlocageEquipements$$EnhancerByCGLIB$$" + matcher.group(1) + ".startPostProcess"); //$NON-NLS-1$ //$NON-NLS-2$
        retour.setActivite("PE0533_BlocageEquipements$$EnhancerByCGLIB$$" + matcher.group(1) + ".startPostProcess"); //$NON-NLS-1$ //$NON-NLS-2$
        break; // Only one instance
      }

      PowerMock.expectPrivate(_instance, "PE0533_BL001_VerifierDonnesCreation", __traceability, request).andThrow(new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.CNCTOR_00010, errmsg)).once(); //$NON-NLS-1$

      EasyMock.expect(_contextMock.getIdBlocageEquipement()).andReturn(null).once();
      PowerMock.expectPrivate(_instance, "PE0533_BL002_FormaterReponseCreation", __traceability, retour, null).andReturn(bl002).once(); //$NON-NLS-1$

      EasyMock.expect(RavelResponseFactory.getInstance()).andReturn(_ravelResponseFactoryMock).once();
      EasyMock.expect(_ravelResponseFactoryMock.createResponse()).andReturn(_responseMock).once();
      _responseMock.setDataType(HttpConstants.CONTENT_TYPE_JSON);
      EasyMock.expectLastCall().andVoid().once();
      _responseMock.setResult(new StringBuilder().append("{\"error\":\"TRAITEMENT_ARRETE\",\"error_description\":\"").append(errmsg).append("\"}").toString()); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expectLastCall().andVoid().once();

      _contextMock.setState(PE0533State.PE0533_END);
      EasyMock.expectLastCall().andVoid().once();

      EasyMock.expect(_contextMock.getState()).andReturn(PE0533State.PE0533_END).once();
      EasyMock.expect(_responseMock.getResult()).andReturn(new StringBuilder().append("{\"error\":\"TRAITEMENT_ARRETE\",\"error_description\":\"").append(errmsg).append("\"}").toString()).once(); //$NON-NLS-1$ //$NON-NLS-2$

      PowerMock.replayAll();

      Whitebox.invokeMethod(_instance, "startPostProcess", request, __traceability); //$NON-NLS-1$
      actual = _instance.getRetour();
    }
    catch (final Throwable ignore)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertFalse(_exception);
      assertNotNull(actual);

      assertEquals(expected, actual);
    }
  }

  /**
   * Test method for {@link com.bytel.spirit.tesla.processes.PE0533.PE0533_BlocageEquipements}. <b>Entrées:</b> <br/>
   * <b>Attendu:</b> <br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void test_PE0533_BlocageEquipements_001() throws Exception
  {
    _instance = PowerMock.createPartialMock(PE0533_BlocageEquipements.class, "PE0533_BL001_VerifierDonnesCreation", "PE0533_BL002_FormaterReponseCreation", "PE0533_BL200_CreerBlocageEquipements"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    Whitebox.setInternalState(_instance, "_processContext", _contextMock); //$NON-NLS-1$
    Whitebox.setInternalState(_instance, "_tracabilite", __traceability); //$NON-NLS-1$

    final String errmsg = __podam.manufacturePojo(String.class);
    final Retour expected = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, errmsg);
    Retour actual = null;

    final Request request = new Request(EMPTY_STRING, EMPTY_STRING, EMPTY_STRING);
    request.setHttpMethod(HttpMethod.POST);

    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, errmsg);
    final PE0533_BL001_VerifierDonneesReturn<PE0533_PostRequest> bl001 = new PE0533_BL001_VerifierDonneesReturn<>(retour);
    final PE0533_BL002_FormaterReponseCreationReturn bl002 = new PE0533_BL002_FormaterReponseCreationReturn(retour.getDiagnostic(), retour.getLibelle());

    try
    {
      _contextMock.setState(PE0533State.PE0533_SYNC);
      EasyMock.expectLastCall().once();

      final Method method = _instance.getClass().getDeclaredMethod("startPostProcess", Request.class, Tracabilite.class); //$NON-NLS-1$
      final Matcher matcher = Pattern.compile("\\$\\$([0-9a-f]+)\\.").matcher(method.toString()); //$NON-NLS-1$
      while (matcher.find())
      {
        expected.setActivite("PE0533_BlocageEquipements$$EnhancerByCGLIB$$" + matcher.group(1) + ".startPostProcess"); //$NON-NLS-1$ //$NON-NLS-2$
        retour.setActivite("PE0533_BlocageEquipements$$EnhancerByCGLIB$$" + matcher.group(1) + ".startPostProcess"); //$NON-NLS-1$ //$NON-NLS-2$
        break; // Only one instance
      }

      PowerMock.expectPrivate(_instance, "PE0533_BL001_VerifierDonnesCreation", __traceability, request).andReturn(bl001).once(); //$NON-NLS-1$

      EasyMock.expect(_contextMock.getIdBlocageEquipement()).andReturn(null).once();
      PowerMock.expectPrivate(_instance, "PE0533_BL002_FormaterReponseCreation", __traceability, retour, null).andReturn(bl002).once(); //$NON-NLS-1$

      EasyMock.expect(RavelResponseFactory.getInstance()).andReturn(_ravelResponseFactoryMock).once();
      EasyMock.expect(_ravelResponseFactoryMock.createResponse()).andReturn(_responseMock).once();
      _responseMock.setDataType(HttpConstants.CONTENT_TYPE_JSON);
      EasyMock.expectLastCall().andVoid().once();
      _responseMock.setResult(new StringBuilder().append("{\"error\":\"DONNEE_INVALIDE\",\"error_description\":\"").append(errmsg).append("\"}").toString()); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expectLastCall().andVoid().once();

      _contextMock.setState(PE0533State.PE0533_END);
      EasyMock.expectLastCall().andVoid().once();

      EasyMock.expect(_contextMock.getState()).andReturn(PE0533State.PE0533_END).once();
      EasyMock.expect(_responseMock.getResult()).andReturn(new StringBuilder().append("{\"error\":\"DONNEE_INVALIDE\",\"error_description\":\"").append(errmsg).append("\"}").toString()).once(); //$NON-NLS-1$ //$NON-NLS-2$

      PowerMock.replayAll();

      Whitebox.invokeMethod(_instance, "startPostProcess", request, __traceability); //$NON-NLS-1$ actual =
      actual = _instance.getRetour();
    }
    catch (final Throwable ignore)
    {
      _exception = true;
      ignore.printStackTrace();
    }
    finally
    {
      PowerMock.verify();

      assertFalse(_exception);
      assertNotNull(actual);

      assertEquals(expected, actual);
    }
  }

  /**
   * Test method for {@link com.bytel.spirit.tesla.processes.PE0533.PE0533_BlocageEquipements}. <b>Entrées:</b> <br/>
   * <b>Attendu:</b> <br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void test_PE0533_BlocageEquipements_002() throws Exception
  {
    _instance = PowerMock.createPartialMock(PE0533_BlocageEquipements.class, "PE0533_BL001_VerifierDonnesCreation", "PE0533_BL002_FormaterReponseCreation", "PE0533_BL200_CreerBlocageEquipements"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    Whitebox.setInternalState(_instance, "_processContext", _contextMock); //$NON-NLS-1$
    Whitebox.setInternalState(_instance, "_tracabilite", __traceability); //$NON-NLS-1$

    final String errmsg = __podam.manufacturePojo(String.class);
    final Retour expected = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, errmsg);
    Retour actual = null;

    final Request request = new Request(EMPTY_STRING, EMPTY_STRING, EMPTY_STRING);
    request.setHttpMethod(HttpMethod.POST);

    @SuppressWarnings("unchecked")
    final PE0533_PostRequest data = new PE0533_PostRequest( //
        Sets.newSet(__olt, __pm), //
        __podam.manufacturePojoWithFullData(TreeSet.class, String.class));

    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegConsts.TRAITEMENT_ARRETE, errmsg);
    final PE0533_BL001_VerifierDonneesReturn<PE0533_PostRequest> bl001 = new PE0533_BL001_VerifierDonneesReturn<>(data, RetourFactoryForTU.createOkRetour());
    final PE0533_BL002_FormaterReponseCreationReturn bl002 = new PE0533_BL002_FormaterReponseCreationReturn(retour.getDiagnostic(), retour.getLibelle());

    try
    {
      _contextMock.setState(PE0533State.PE0533_SYNC);
      EasyMock.expectLastCall().once();

      final Method method = _instance.getClass().getDeclaredMethod("startPostProcess", Request.class, Tracabilite.class); //$NON-NLS-1$
      final Matcher matcher = Pattern.compile("\\$\\$([0-9a-f]+)\\.").matcher(method.toString()); //$NON-NLS-1$
      while (matcher.find())
      {
        expected.setActivite("PE0533_BlocageEquipements$$EnhancerByCGLIB$$" + matcher.group(1) + ".startPostProcess"); //$NON-NLS-1$ //$NON-NLS-2$
        retour.setActivite("PE0533_BlocageEquipements$$EnhancerByCGLIB$$" + matcher.group(1) + ".startPostProcess"); //$NON-NLS-1$ //$NON-NLS-2$
        break; // Only one instance
      }

      PowerMock.expectPrivate(_instance, "PE0533_BL001_VerifierDonnesCreation", __traceability, request).andReturn(bl001).once(); //$NON-NLS-1$

      PowerMock.expectPrivate(_instance, "PE0533_BL200_CreerBlocageEquipements", __traceability, data).andThrow(new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.CNCTOR_00010, errmsg)).once(); //$NON-NLS-1$

      EasyMock.expect(_contextMock.getIdBlocageEquipement()).andReturn(null).once();
      PowerMock.expectPrivate(_instance, "PE0533_BL002_FormaterReponseCreation", __traceability, retour, null).andReturn(bl002).once(); //$NON-NLS-1$

      EasyMock.expect(RavelResponseFactory.getInstance()).andReturn(_ravelResponseFactoryMock).once();
      EasyMock.expect(_ravelResponseFactoryMock.createResponse()).andReturn(_responseMock).once();
      _responseMock.setDataType(HttpConstants.CONTENT_TYPE_JSON);
      EasyMock.expectLastCall().andVoid().once();
      _responseMock.setResult(new StringBuilder().append("{\"error\":\"TRAITEMENT_ARRETE\",\"error_description\":\"").append(errmsg).append("\"}").toString()); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expectLastCall().andVoid().once();

      _contextMock.setState(PE0533State.PE0533_END);
      EasyMock.expectLastCall().andVoid().once();

      EasyMock.expect(_contextMock.getState()).andReturn(PE0533State.PE0533_END).once();
      EasyMock.expect(_responseMock.getResult()).andReturn(new StringBuilder().append("{\"error\":\"TRAITEMENT_ARRETE\",\"error_description\":\"").append(errmsg).append("\"}").toString()).once(); //$NON-NLS-1$ //$NON-NLS-2$

      PowerMock.replayAll();

      Whitebox.invokeMethod(_instance, "startPostProcess", request, __traceability); //$NON-NLS-1$
      actual = _instance.getRetour();
    }
    catch (final Throwable ignore)
    {
      _exception = true;
      ignore.printStackTrace();
    }
    finally
    {
      PowerMock.verify();

      assertFalse(_exception);
      assertNotNull(actual);

      assertEquals(expected, actual);
    }
  }

  /**
   * Test method for {@link com.bytel.spirit.tesla.processes.PE0533.PE0533_BlocageEquipements}. <b>Entrées:</b> <br/>
   * <b>Attendu:</b> <br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void test_PE0533_BlocageEquipements_003() throws Exception
  {
    _instance = PowerMock.createPartialMock(PE0533_BlocageEquipements.class, "PE0533_BL001_VerifierDonnesCreation", "PE0533_BL002_FormaterReponseCreation", "PE0533_BL200_CreerBlocageEquipements"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    Whitebox.setInternalState(_instance, "_processContext", _contextMock); //$NON-NLS-1$
    Whitebox.setInternalState(_instance, "_tracabilite", __traceability); //$NON-NLS-1$

    final Retour expected = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "Id Operation inexistant ou operation non eligible pour créer un Blocage Pise Clients"); //$NON-NLS-1$
    Retour actual = null;

    final Request request = new Request(EMPTY_STRING, EMPTY_STRING, EMPTY_STRING);
    request.setHttpMethod(HttpMethod.POST);
    @SuppressWarnings("unchecked")
    final PE0533_PostRequest data = new PE0533_PostRequest( //
        Sets.newSet(__olt, __pm), //
        __podam.manufacturePojoWithFullData(TreeSet.class, String.class));

    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "Id Operation inexistant ou operation non eligible pour créer un Blocage Pise Clients"); //$NON-NLS-1$
    final PE0533_BL001_VerifierDonneesReturn<PE0533_PostRequest> bl001 = new PE0533_BL001_VerifierDonneesReturn<>(data, RetourFactoryForTU.createOkRetour());
    final PE0533_BL002_FormaterReponseCreationReturn bl002 = new PE0533_BL002_FormaterReponseCreationReturn(retour.getDiagnostic(), retour.getLibelle());
    final PE0533_BL200_CreerBlocageEquipementsReturn bl200 = new PE0533_BL200_CreerBlocageEquipementsReturn(retour);

    try
    {
      _contextMock.setState(PE0533State.PE0533_SYNC);
      EasyMock.expectLastCall().once();

      final Method method = _instance.getClass().getDeclaredMethod("startPostProcess", Request.class, Tracabilite.class); //$NON-NLS-1$
      final Matcher matcher = Pattern.compile("\\$\\$([0-9a-f]+)\\.").matcher(method.toString()); //$NON-NLS-1$
      while (matcher.find())
      {
        expected.setActivite("PE0533_BlocageEquipements$$EnhancerByCGLIB$$" + matcher.group(1) + ".startPostProcess"); //$NON-NLS-1$ //$NON-NLS-2$
        retour.setActivite("PE0533_BlocageEquipements$$EnhancerByCGLIB$$" + matcher.group(1) + ".startPostProcess"); //$NON-NLS-1$ //$NON-NLS-2$
        break; // Only one instance
      }

      PowerMock.expectPrivate(_instance, "PE0533_BL001_VerifierDonnesCreation", __traceability, request).andReturn(bl001).once(); //$NON-NLS-1$

      PowerMock.expectPrivate(_instance, "PE0533_BL200_CreerBlocageEquipements", __traceability, data).andReturn(bl200).once(); //$NON-NLS-1$
      _contextMock.setIdBlocageEquipement(null);
      EasyMock.expectLastCall().once();

      EasyMock.expect(_contextMock.getIdBlocageEquipement()).andReturn(null).once();
      PowerMock.expectPrivate(_instance, "PE0533_BL002_FormaterReponseCreation", __traceability, retour, null).andReturn(bl002).once(); //$NON-NLS-1$

      EasyMock.expect(RavelResponseFactory.getInstance()).andReturn(_ravelResponseFactoryMock).once();
      EasyMock.expect(_ravelResponseFactoryMock.createResponse()).andReturn(_responseMock).once();
      _responseMock.setDataType(HttpConstants.CONTENT_TYPE_JSON);
      EasyMock.expectLastCall().andVoid().once();
      _responseMock.setResult("{\"error\":\"DONNEE_INCONNUE\",\"error_description\":\"Id Operation inexistant ou operation non eligible pour créer un Blocage Pise Clients\"}"); //$NON-NLS-1$
      EasyMock.expectLastCall().andVoid().once();

      _contextMock.setState(PE0533State.PE0533_END);
      EasyMock.expectLastCall().andVoid().once();

      EasyMock.expect(_contextMock.getState()).andReturn(PE0533State.PE0533_END).once();
      EasyMock.expect(_responseMock.getResult()).andReturn("{\"error\":\"DONNEE_INCONNUE\",\"error_description\":\"Id Operation inexistant ou operation non eligible pour créer un Blocage Pise Clients\"}").once(); //$NON-NLS-1$

      PowerMock.replayAll();

      Whitebox.invokeMethod(_instance, "startPostProcess", request, __traceability); //$NON-NLS-1$
      actual = _instance.getRetour();
    }
    catch (final Throwable ignore)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertFalse(_exception);
      assertNotNull(actual);

      assertEquals(expected, actual);
    }
  }

  /**
   * Test method for {@link com.bytel.spirit.tesla.processes.PE0533.PE0533_BlocageEquipements}. <b>Entrées:</b> <br/>
   * <b>Attendu:</b> <br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void test_PE0533_BlocageEquipements_004() throws Exception
  {
    _instance = PowerMock.createPartialMock(PE0533_BlocageEquipements.class, "PE0533_BL001_VerifierDonnesCreation", "PE0533_BL002_FormaterReponseCreation", "PE0533_BL200_CreerBlocageEquipements"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    Whitebox.setInternalState(_instance, "_processContext", _contextMock); //$NON-NLS-1$
    Whitebox.setInternalState(_instance, "_tracabilite", __traceability); //$NON-NLS-1$

    final Retour expected = RetourFactoryForTU.createOkRetour();
    Retour actual = null;

    final Request request = new Request(EMPTY_STRING, EMPTY_STRING, EMPTY_STRING);
    request.setHttpMethod(HttpMethod.POST);
    @SuppressWarnings("unchecked")
    final PE0533_PostRequest data = new PE0533_PostRequest( //
        Sets.newSet(__olt, __pm), //
        __podam.manufacturePojoWithFullData(TreeSet.class, String.class));

    final Retour retour = RetourFactoryForTU.createOkRetour();
    final PE0533_BL001_VerifierDonneesReturn<PE0533_PostRequest> bl001 = new PE0533_BL001_VerifierDonneesReturn<>(data, retour);
    final PE0533_BL002_FormaterReponseCreationReturn bl002 = new PE0533_BL002_FormaterReponseCreationReturn(__idBlocageEquipement);
    final PE0533_BL200_CreerBlocageEquipementsReturn bl200 = new PE0533_BL200_CreerBlocageEquipementsReturn(__idBlocageEquipement, retour);

    try
    {
      _contextMock.setState(PE0533State.PE0533_SYNC);
      EasyMock.expectLastCall().once();

      final Method method = _instance.getClass().getDeclaredMethod("startPostProcess", Request.class, Tracabilite.class); //$NON-NLS-1$
      final Matcher matcher = Pattern.compile("\\$\\$([0-9a-f]+)\\.").matcher(method.toString()); //$NON-NLS-1$
      while (matcher.find())
      {
        expected.setActivite("PE0533_BlocageEquipements$$EnhancerByCGLIB$$" + matcher.group(1) + ".startPostProcess"); //$NON-NLS-1$ //$NON-NLS-2$
        retour.setActivite("PE0533_BlocageEquipements$$EnhancerByCGLIB$$" + matcher.group(1) + ".startPostProcess"); //$NON-NLS-1$ //$NON-NLS-2$
        break; // Only one instance
      }

      PowerMock.expectPrivate(_instance, "PE0533_BL001_VerifierDonnesCreation", __traceability, request).andReturn(bl001).once(); //$NON-NLS-1$

      PowerMock.expectPrivate(_instance, "PE0533_BL200_CreerBlocageEquipements", __traceability, data).andReturn(bl200).once(); //$NON-NLS-1$
      _contextMock.setIdBlocageEquipement(__idBlocageEquipement);
      EasyMock.expectLastCall().once();

      EasyMock.expect(_contextMock.getIdBlocageEquipement()).andReturn(__idBlocageEquipement).once();
      PowerMock.expectPrivate(_instance, "PE0533_BL002_FormaterReponseCreation", __traceability, retour, __idBlocageEquipement).andReturn(bl002).once(); //$NON-NLS-1$

      EasyMock.expect(RavelResponseFactory.getInstance()).andReturn(_ravelResponseFactoryMock).once();
      EasyMock.expect(_ravelResponseFactoryMock.createResponse()).andReturn(_responseMock).once();
      _responseMock.setDataType(HttpConstants.CONTENT_TYPE_JSON);
      EasyMock.expectLastCall().andVoid().once();
      _responseMock.setResult(new StringBuilder().append("{\"idBlocageEquipement\":\"").append(__idBlocageEquipement).append("\"}").toString()); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expectLastCall().andVoid().once();

      _contextMock.setState(PE0533State.PE0533_END);
      EasyMock.expectLastCall().andVoid().once();

      EasyMock.expect(_contextMock.getState()).andReturn(PE0533State.PE0533_END).once();
      EasyMock.expect(_responseMock.getResult()).andReturn(new StringBuilder().append("{\"idBlocageEquipement\":\"").append(__idBlocageEquipement).append("\"}").toString()).once(); //$NON-NLS-1$ //$NON-NLS-2$

      PowerMock.replayAll();

      Whitebox.invokeMethod(_instance, "startPostProcess", request, __traceability); //$NON-NLS-1$
      actual = _instance.getRetour();
    }
    catch (final Throwable ignore)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertFalse(_exception);
      assertNotNull(actual);

      assertEquals(expected, actual);
    }
  }

  /**
   * Test method for {@link com.bytel.spirit.tesla.processes.PE0533.PE0533_BlocageEquipements}. <b>Entrées:</b> <br/>
   * <b>Attendu:</b> <br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void test_PE0533_BlocageEquipements_005() throws Exception
  {
    final Retour expected = RetourFactoryForTU.createOkRetour();
    Retour actual = null;

    final IRavelJson instance = new RavelJsonBuilder() //
        .profil("STARK") //$NON-NLS-1$
        .build(); //
    final IRavelJsonAdapter<PE0529_PostRequest> adapter1 = instance.adapter(PE0529_PostRequest.class);
    final IRavelJsonAdapter<PE0533_PostRequest> adapter2 = instance.adapter(PE0533_PostRequest.class);

    @SuppressWarnings("unchecked")
    final PE0533_PostRequest jsonRequest = new PE0533_PostRequest( //
        Sets.newSet(__olt, __pm), //
        __podam.manufacturePojoWithFullData(TreeSet.class, String.class));

    final Request request = new Request(EMPTY_STRING, EMPTY_STRING, EMPTY_STRING);
    request.setHttpMethod(HttpMethod.POST);
    request.getRequestHeader()
        .addAll(Sets.newSet( //
            new RequestHeader() //
                .withName(IHttpHeadersConsts.AUTHORIZATION) //
                .withValue(__authorization), //
            new RequestHeader() //
                .withName(IHttpHeadersConsts.X_SOURCE) //
                .withValue(__xSource), //
            new RequestHeader() //
                .withName(IHttpHeadersConsts.X_REQUEST_ID) //
                .withValue(__xRequestId), //
            new RequestHeader() //
                .withName(IHttpHeadersConsts.X_MESSAGE_ID) //
                .withValue(__xMessageId), //
            new RequestHeader() //
                .withName(IHttpHeadersConsts.X_PROCESS) //
                .withValue(__xProcess), //
            new RequestHeader() //
                .withName(IHttpHeadersConsts.X_ACTION_ID) //
                .withValue(__xActionId), //
            new RequestHeader() //
                .withName(IHttpHeadersConsts.X_VERSION) //
                .withValue(__xVersion), //
            new RequestHeader() //
                .withName(IHttpHeadersConsts.CONTENT_TYPE) //
                .withValue(__contentType.name())));
    request.setPayload(adapter2.toJson(jsonRequest));

    final PE0529_PostRequest mockRequest = new PE0529_PostRequest(null, null);
    //mockRequest.setAjoutsPortsPon(Sets.newSet(new AjoutPortPon(new PositionPortPon(null, null, __nomOLT), null, null, null)));
    mockRequest.setAjoutsPortsPm( //
        Arrays.asList(new AjoutPortPm(new PositionPortPm(null, null, null, __referencePmBytel), //
            Arrays.asList(new LienPortPon(__nomOlt, null, null)), null, null)));

    final OperationVieReseau operationVieReseau = new OperationVieReseau(__podam.manufacturePojoWithFullData(String.class), __podam.manufacturePojoWithFullData(String.class), "ACQUITTE", adapter1.toJson(mockRequest)); //$NON-NLS-1$
    final Set<com.bytel.spirit.common.shared.saab.rex.Equipement> equipements = new TreeSet<>(new EquipementComparator());
    equipements.addAll(jsonRequest.getListeEquipement().stream().map(Equipement::toSAAB).collect(Collectors.toSet()));
    final BlocageEquipement blocageEquipement = new BlocageEquipement(__idBlocageEquipement, StatutBlockage.ACTIF.name(), jsonRequest.getListeIdOperationVieReseau().stream().collect(Collectors.toSet()), equipements);

    final Set<CleRechercheBlocageEquipement> listeCleRechercheBlocageEquipementRequest = new TreeSet<>(new CleRechercheBlocageEquipementComparator());
    listeCleRechercheBlocageEquipementRequest.add(new CleRechercheBlocageEquipement("PM", __referencePmBytel, __idBlocageEquipement)); //$NON-NLS-1$
    __pm.getListeReferenceBoitierPm().stream().map(referenceBoitierPm -> new CleRechercheBlocageEquipement("BOITIER", new StringBuilder().append(__referencePmBytel).append("|").append(referenceBoitierPm).toString(), __idBlocageEquipement)) // //$NON-NLS-1$ //$NON-NLS-2$
        .collect(Collectors.toSet()) //
        .forEach(listeCleRechercheBlocageEquipementRequest::add);
    listeCleRechercheBlocageEquipementRequest.add(new CleRechercheBlocageEquipement("OLT", __nomOlt, __idBlocageEquipement)); //$NON-NLS-1$
    __olt.getListePositionCarte().stream().map(positionCarte -> new CleRechercheBlocageEquipement("CARTE", new StringBuilder().append(__nomOlt).append("|").append(positionCarte).toString(), __idBlocageEquipement)) // //$NON-NLS-1$ //$NON-NLS-2$
        .collect(Collectors.toSet()) //
        .forEach(listeCleRechercheBlocageEquipementRequest::add);

    final Retour retour = RetourFactoryForTU.createOkRetour();

    try
    {
      for (final String idOperationVieReseau : jsonRequest.getListeIdOperationVieReseau())
      {
        EasyMock.expect(REXProxy.getInstance()).andReturn(_rexMock).once();
        EasyMock.expect(_rexMock.operationVieReseauLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(idOperationVieReseau))).andReturn(new ConnectorResponse<Retour, OperationVieReseau>(retour, operationVieReseau)).once();
      }

      PowerMock.expectNew(BL800_ObtenirSequenceBuilder.class).andReturn(_bl800MockBuilder).once();
      EasyMock.expect(_bl800MockBuilder.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl800MockBuilder).once();
      EasyMock.expect(_bl800MockBuilder.code(UniqueIdConstant.ID_BLOCAGE_EQUIPEMENT)).andReturn(_bl800MockBuilder).once();
      EasyMock.expect(_bl800MockBuilder.build()).andReturn(_bl800Mock).once();
      EasyMock.expect(_bl800Mock.execute(EasyMock.anyObject(PE0533_BlocageEquipements.class))).andReturn(__idBlocageEquipement).once();
      EasyMock.expect(_bl800Mock.getRetour()).andReturn(RetourFactoryForTU.createOkRetour()).once();

      EasyMock.expect(REXProxy.getInstance()).andReturn(_rexMock).once();
      EasyMock.expect(_rexMock.blocageEquipementCreer(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(blocageEquipement))).andReturn(new ConnectorResponse<Retour, Nothing>(retour, null)).once();

      for (String referenceBoitierPm : __pm.getListeReferenceBoitierPm())
      {
        EasyMock.expect(RESProxy.getInstance()).andReturn(_resMock).once();
        EasyMock.expect(LocalDateTime.now()).andReturn(__now).once();
        EasyMock.expect(_resMock.pmCompositeModifierSurchargePriseClientBoitierPM(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(__referencePmBytel), EasyMock.eq(referenceBoitierPm), EasyMock.eq(StatutBlockage.ACTIF.name()), EasyMock.eq(MessageFormat.format(Messages.getString("PE0533.blocageVR"), DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZ.format(__now))))).andReturn(new ConnectorResponse<Retour, Nothing>(retour, null)); //$NON-NLS-1$
      }

      for (Integer positionCarte : __olt.getListePositionCarte())
      {
        EasyMock.expect(RESProxy.getInstance()).andReturn(_resMock).once();
        EasyMock.expect(LocalDateTime.now()).andReturn(__now).once();
        EasyMock.expect(_resMock.oltCompositeModifierSurchargePriseClientCarte(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(__nomOlt), EasyMock.eq(positionCarte.toString()), EasyMock.eq(StatutBlockage.ACTIF.name()), EasyMock.eq(MessageFormat.format(Messages.getString("PE0533.blocageVR"), DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZ.format(__now))))).andReturn(new ConnectorResponse<Retour, Nothing>(retour, null)); //$NON-NLS-1$
      }

      EasyMock.expect(REXProxy.getInstance()).andReturn(_rexMock).once();
      EasyMock.expect(_rexMock.cleRechercheBlocageEquipementCreerListe(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(new ListeCleRechercheBlocageEquipementRequest(new ArrayList<>(listeCleRechercheBlocageEquipementRequest))))).andReturn(new ConnectorResponse<Retour, Nothing>(retour, null)).once();

      EasyMock.expect(RavelResponseFactory.getInstance()).andReturn(_ravelResponseFactoryMock).once();
      EasyMock.expect(_ravelResponseFactoryMock.createResponse()).andReturn(_responseMock).once();
      _responseMock.setDataType(HttpConstants.CONTENT_TYPE_JSON);
      EasyMock.expectLastCall().andVoid().once();
      _responseMock.setResult(new StringBuilder().append("{\"idBlocageEquipement\":\"").append(__idBlocageEquipement).append("\"}").toString()); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expectLastCall().andVoid().once();

      EasyMock.expect(_responseMock.getResult()).andReturn(new StringBuilder().append("{\"idBlocageEquipement\":\"").append(__idBlocageEquipement).append("\"}").toString()).times(3); //$NON-NLS-1$ //$NON-NLS-2$

      PowerMock.replayAll();

      _instance.initializeContext();
      _instance.run(request);
      actual = _instance.getRetour();
    }
    catch (final Throwable ignore)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertFalse(_exception);
      assertNotNull(actual);

      assertEquals(expected, actual);
    }
  }
}
