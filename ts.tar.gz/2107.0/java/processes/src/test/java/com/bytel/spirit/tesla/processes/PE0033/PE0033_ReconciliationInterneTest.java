/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.tesla.processes.PE0033;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.easymock.EasyMock;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.modules.junit4.PowerMockRunnerDelegate;
import org.springframework.test.context.ContextConfiguration;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.data.exchange.generated.RavelRequest.RequestHeader;
import com.bytel.ravel.common.datetime.DateTimeManager;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.request.Parameter;
import com.bytel.ravel.common.factory.request.UrlParameters;
import com.bytel.ravel.common.factory.response.IRavelResponse;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.test.podam.PodamBytelJUnit4ClassRunner;
import com.bytel.ravel.common.utils.RetourFactoryForTU;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.utils.Test_Consts;
import com.bytel.spirit.common.activities.shared.BL5100_CreerActionCorrective;
import com.bytel.spirit.common.activities.shared.BL5100_CreerActionCorrective.BL5100_CreerActionCorrectiveBuilder;
import com.bytel.spirit.common.activities.shared.BL5110_ExecuterActionCorrective;
import com.bytel.spirit.common.activities.shared.BL5110_ExecuterActionCorrective.BL5110_ExecuterActionCorrectiveBuilder;
import com.bytel.spirit.common.connectors.rpg.RPGProxy;
import com.bytel.spirit.common.connectors.rst.RSTProxy;
import com.bytel.spirit.common.shared.functional.types.json.RavelJsonTools;
import com.bytel.spirit.common.shared.functional.types.json.action_corrective.ActionCorrective;
import com.bytel.spirit.common.shared.functional.types.json.action_corrective.ActionServiceTechnique;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.TypePFS;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.mail.StPfsMail;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.BasicResponse;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.TypeObjetCommercial;
import com.bytel.spirit.common.shared.saab.res.TypeRessource;
import com.bytel.spirit.common.shared.saab.rpg.PFI;
import com.bytel.spirit.common.shared.saab.rst.ServiceTechnique;
import com.bytel.spirit.common.shared.saab.rst.StLienAllocationCommercial;
import com.bytel.spirit.common.shared.saab.rst.TypeST;
import com.bytel.spirit.tesla.processes.PE0033.sti.PE0033_Request;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author rdavid
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
//@PowerMockListener(FieldDefaulter.class)
@PowerMockRunnerDelegate(PodamBytelJUnit4ClassRunner.class)
@ContextConfiguration("classpath:BeansProcessTestMocks.xml")
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
@PrepareForTest({ PE0033_ReconciliationInterne.class, RPGProxy.class, RSTProxy.class, BL5100_CreerActionCorrective.class, BL5100_CreerActionCorrectiveBuilder.class, BL5110_ExecuterActionCorrective.class, BL5110_ExecuterActionCorrectiveBuilder.class })
public class PE0033_ReconciliationInterneTest
{
  /**
   * Constant clientOperateur.<br/>
   */
  private static final String CLIENT_OPERATEUR = "clientOperateur"; //$NON-NLS-1$

  /**
   * Constant noCompte.<br/>
   */
  private static final String NO_COMPTE = "noCompte"; //$NON-NLS-1$

  /**
   * Constant portee.<br/>
   */
  private static final String PORTEE = "portee"; //$NON-NLS-1$

  /**
   * The default process name.<br/>
   */
  public static final String DEFAULT_PROCESSNAME = "PE0033_ReconciliationInterne"; //$NON-NLS-1$

  /**
   * Tracabilite.<br/>
   */
  private static Tracabilite _tracabilite;

  /**
   * Factory de génération des beans.<br/>
   */
  private static final PodamFactory __podam = new PodamFactoryImpl();

  /**
   * RPGProxy Mock.<br/>
   */
  @MockStrict
  private RPGProxy _rpgProxyMock;

  /**
   * RSTProxy Mock.<br/>
   */
  @MockStrict
  private RSTProxy _rstProxyMock;

  /**
   * BL5100 Mock.<br/>
   */
  @MockStrict
  private BL5100_CreerActionCorrective _bl5100Mock;

  /**
   * BL5100 builder Mock.<br/>
   */
  @MockStrict
  private BL5100_CreerActionCorrectiveBuilder _bl5100BuilderMock;

  /**
   * BL5110 Mock.<br/>
   */
  @MockStrict
  private BL5110_ExecuterActionCorrective _bl5110Mock;

  /**
   * BL5110 builder Mock.<br/>
   */
  @MockStrict
  private BL5110_ExecuterActionCorrectiveBuilder _bl5110BuilderMock;

  /**
   * Instnace of process.<br/>
   */
  private PE0033_ReconciliationInterne _processInstance;

  /**
   * Scenario: PE0033_ReconciliationInterne_BL001_VerifierDonnees.<br/>
   * <b>Input:</b>No mandatory headers are set<br/>
   * <b>Result:</b> KO/CAT-3/NON_RESPECT_STI/Header HTTP obligatoire manquant: Header HTTP obligatoire manquant:<br/>
   * X-Process,X-Source<br/>
   *
   * @throws Throwable
   *           On unexpected error
   */
  @Test
  public void PE0033_ReconciliationInterneTest_BL001_VerifierDonnees_KO_001() throws Throwable
  {
    Retour retourexpected = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, "Header(s) HTTP obligatoire(s) manquant: X-Source, X-Process"); //$NON-NLS-1$

    Request request = prepareRequest("Headers Empty", "Object Empty", null); //$NON-NLS-1$//$NON-NLS-2$

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verify();

    IRavelResponse response = request.getResponse();
    String result = response.getGenericResponse().getResult();
    BasicResponse responsePE0033 = RavelJsonTools.getInstance().fromJson(result, BasicResponse.class);
    Assert.assertEquals(ErrorCode.KO_00400.getHttpErrorCode(), response.getErrorCode().getHttpErrorCode());
    Assert.assertEquals(retourexpected.getDiagnostic(), responsePE0033.getRetour().getDiagnostic());
    Assert.assertEquals(retourexpected.getCategorie(), responsePE0033.getRetour().getCategorie());
    Assert.assertEquals(retourexpected.getLibelle(), responsePE0033.getRetour().getLibelle());
  }

  /**
   * Scenario: PE0033_ReconciliationInterne_BL001_VerifierDonnees.<br/>
   * <b>Input:</b>No mandatory headers are set<br/>
   * <b>Result:</b> KO/CAT-3/NON_RESPECT_STI/Header HTTP obligatoire manquant: Header HTTP obligatoire manquant:<br/>
   * X-Source<br/>
   *
   * @throws Throwable
   *           On unexpected error
   */
  @Test
  public void PE0033_ReconciliationInterneTest_BL001_VerifierDonnees_KO_002() throws Throwable
  {
    Retour retourexpected = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, "Header(s) HTTP obligatoire(s) manquant: X-Source"); //$NON-NLS-1$

    Request request = prepareRequest("Header Source Missing", "Body Empty", null); //$NON-NLS-1$//$NON-NLS-2$

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verify();

    IRavelResponse response = request.getResponse();
    String result = response.getGenericResponse().getResult();
    BasicResponse responsePE0033 = RavelJsonTools.getInstance().fromJson(result, BasicResponse.class);
    Assert.assertEquals(ErrorCode.KO_00400.getHttpErrorCode(), response.getErrorCode().getHttpErrorCode());
    Assert.assertEquals(retourexpected.getDiagnostic(), responsePE0033.getRetour().getDiagnostic());
    Assert.assertEquals(retourexpected.getCategorie(), responsePE0033.getRetour().getCategorie());
    Assert.assertEquals(retourexpected.getLibelle(), responsePE0033.getRetour().getLibelle());
  }

  /**
   * Scenario: PE0033_ReconciliationInterne_BL001_VerifierDonnees.<br/>
   * <b>Input:</b>No mandatory headers are set<br/>
   * <b>Result:</b> KO/CAT-3/NON_RESPECT_STI/Header HTTP obligatoire manquant: Header HTTP obligatoire manquant:<br/>
   * X-Process<br/>
   *
   * @throws Throwable
   *           On unexpected error
   */
  @Test
  public void PE0033_ReconciliationInterneTest_BL001_VerifierDonnees_KO_003() throws Throwable
  {
    Retour retourexpected = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, "Header(s) HTTP obligatoire(s) manquant: X-Process"); //$NON-NLS-1$

    Request request = prepareRequest("Header Process Missing", "Body Empty", null); //$NON-NLS-1$//$NON-NLS-2$

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verify();

    IRavelResponse response = request.getResponse();
    String result = response.getGenericResponse().getResult();
    BasicResponse responsePE0033 = RavelJsonTools.getInstance().fromJson(result, BasicResponse.class);
    Assert.assertEquals(ErrorCode.KO_00400.getHttpErrorCode(), response.getErrorCode().getHttpErrorCode());
    Assert.assertEquals(retourexpected.getDiagnostic(), responsePE0033.getRetour().getDiagnostic());
    Assert.assertEquals(retourexpected.getCategorie(), responsePE0033.getRetour().getCategorie());
    Assert.assertEquals(retourexpected.getLibelle(), responsePE0033.getRetour().getLibelle());
  }

  /**
   * Scenario: PE0033_ReconciliationInterne_BL001_VerifierDonnees.<br/>
   * <b>Input:</b>The request payload is empty<br/>
   * <b>Result:</b> KO/CAT-3/NON_RESPECT_STI/Request Body is empty, STI request object is null.<br/>
   *
   * @throws Throwable
   *           On unexpected error
   */
  @Test
  public void PE0033_ReconciliationInterneTest_BL001_VerifierDonnees_KO_004() throws Throwable
  {
    Retour retourexpected = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, "Request Body is empty, STI request object is null"); //$NON-NLS-1$

    Request request = prepareRequest("Headers Filled", "Body Empty", null); //$NON-NLS-1$//$NON-NLS-2$

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verify();

    IRavelResponse response = request.getResponse();
    String result = response.getGenericResponse().getResult();
    BasicResponse responsePE0033 = RavelJsonTools.getInstance().fromJson(result, BasicResponse.class);
    Assert.assertEquals(ErrorCode.KO_00400.getHttpErrorCode(), response.getErrorCode().getHttpErrorCode());
    Assert.assertEquals(retourexpected.getDiagnostic(), responsePE0033.getRetour().getDiagnostic());
    Assert.assertEquals(retourexpected.getCategorie(), responsePE0033.getRetour().getCategorie());
    Assert.assertEquals(retourexpected.getLibelle(), responsePE0033.getRetour().getLibelle());
  }

  /**
   * Scenario: PE0033_ReconciliationInterne_BL001_VerifierDonnees.<br/>
   * <b>Input:</b>The request payload as both parameters missing<br/>
   * <b>Result:</b> KO/CAT-3/NON_RESPECT_STI/Body parametre(s) obligatoire(s) manquant: ClientOperateur, NoCompte.<br/>
   *
   * @throws Throwable
   *           On unexpected error
   */
  @Test
  public void PE0033_ReconciliationInterneTest_BL001_VerifierDonnees_KO_005() throws Throwable
  {
    Retour retourexpected = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, "Attribut(s) obligatoire(s) manquant(s): [_clientOperateur, _noCompte]"); //$NON-NLS-1$

    Request request = prepareRequest("Headers Filled", "Object Empty", null); //$NON-NLS-1$//$NON-NLS-2$

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verify();

    IRavelResponse response = request.getResponse();
    String result = response.getGenericResponse().getResult();
    BasicResponse responsePE0033 = RavelJsonTools.getInstance().fromJson(result, BasicResponse.class);
    Assert.assertEquals(ErrorCode.KO_00400.getHttpErrorCode(), response.getErrorCode().getHttpErrorCode());
    Assert.assertEquals(retourexpected.getDiagnostic(), responsePE0033.getRetour().getDiagnostic());
    Assert.assertEquals(retourexpected.getCategorie(), responsePE0033.getRetour().getCategorie());
    Assert.assertEquals(retourexpected.getLibelle(), responsePE0033.getRetour().getLibelle());
  }

  /**
   * Scenario: PE0033_ReconciliationInterne_BL001_VerifierDonnees.<br/>
   * <b>Input:</b>The request payload as both parameters missing<br/>
   * <b>Result:</b> KO/CAT-3/NON_RESPECT_STI/Body parametre(s) obligatoire(s) manquant: ClientOperateur, NoCompte.<br/>
   *
   * @throws Throwable
   *           On unexpected error
   */
  @Test
  public void PE0033_ReconciliationInterneTest_BL001_VerifierDonnees_KO_006() throws Throwable
  {
    Retour retourexpected = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, "Format d'attribut(s) non respecté(s): [_clientOperateur, _noCompte]"); //$NON-NLS-1$

    Request request = prepareRequest("Headers Filled", "ClientOperateur and NoCompte on wrong format", null); //$NON-NLS-1$//$NON-NLS-2$

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verify();

    IRavelResponse response = request.getResponse();
    String result = response.getGenericResponse().getResult();
    BasicResponse responsePE0033 = RavelJsonTools.getInstance().fromJson(result, BasicResponse.class);
    Assert.assertEquals(ErrorCode.KO_00400.getHttpErrorCode(), response.getErrorCode().getHttpErrorCode());
    Assert.assertEquals(retourexpected.getDiagnostic(), responsePE0033.getRetour().getDiagnostic());
    Assert.assertEquals(retourexpected.getCategorie(), responsePE0033.getRetour().getCategorie());
    Assert.assertEquals(retourexpected.getLibelle(), responsePE0033.getRetour().getLibelle());
  }

  /**
   * Scenario: PE0033_ReconciliationInterne_BL001_VerifierDonnees.<br/>
   * <b>Input:</b>The request payload as a parameter missing<br/>
   * <b>Result:</b> KO/CAT-3/NON_RESPECT_STI/Body parametre(s) obligatoire(s) manquant: ClientOperateur.<br/>
   *
   * @throws Throwable
   *           On unexpected error
   */
  @Test
  public void PE0033_ReconciliationInterneTest_BL001_VerifierDonnees_KO_007() throws Throwable
  {
    Retour retourexpected = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, "Attribut(s) obligatoire(s) manquant(s): [_clientOperateur]"); //$NON-NLS-1$

    Request request = prepareRequest("Headers Filled", "ClientOperateur Missing", null); //$NON-NLS-1$//$NON-NLS-2$

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verify();

    IRavelResponse response = request.getResponse();
    String result = response.getGenericResponse().getResult();
    BasicResponse responsePE0033 = RavelJsonTools.getInstance().fromJson(result, BasicResponse.class);
    Assert.assertEquals(ErrorCode.KO_00400.getHttpErrorCode(), response.getErrorCode().getHttpErrorCode());
    Assert.assertEquals(retourexpected.getDiagnostic(), responsePE0033.getRetour().getDiagnostic());
    Assert.assertEquals(retourexpected.getCategorie(), responsePE0033.getRetour().getCategorie());
    Assert.assertEquals(retourexpected.getLibelle(), responsePE0033.getRetour().getLibelle());
  }

  /**
   * Scenario: PE0033_ReconciliationInterne_BL001_VerifierDonnees.<br/>
   * <b>Input:</b>The request payload as a parameter missing<br/>
   * <b>Result:</b> KO/CAT-3/NON_RESPECT_STI/Body parametre(s) obligatoire(s) manquant: NoCompte.<br/>
   *
   * @throws Throwable
   *           On unexpected error
   */
  @Test
  public void PE0033_ReconciliationInterneTest_BL001_VerifierDonnees_KO_008() throws Throwable
  {
    Retour retourexpected = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, "Attribut(s) obligatoire(s) manquant(s): [_noCompte]"); //$NON-NLS-1$

    Request request = prepareRequest("Headers Filled", "NoCompte Missing", null); //$NON-NLS-1$//$NON-NLS-2$

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verify();

    IRavelResponse response = request.getResponse();
    String result = response.getGenericResponse().getResult();
    BasicResponse responsePE0033 = RavelJsonTools.getInstance().fromJson(result, BasicResponse.class);
    Assert.assertEquals(ErrorCode.KO_00400.getHttpErrorCode(), response.getErrorCode().getHttpErrorCode());
    Assert.assertEquals(retourexpected.getDiagnostic(), responsePE0033.getRetour().getDiagnostic());
    Assert.assertEquals(retourexpected.getCategorie(), responsePE0033.getRetour().getCategorie());
    Assert.assertEquals(retourexpected.getLibelle(), responsePE0033.getRetour().getLibelle());
  }

  /**
   * Scenario: PE0033_ReconciliationInterne_BL001_VerifierDonnees.<br/>
   * <b>Input:</b>The call to RPGProxy pfiLireUn returns NOK/CAT-4/DONNEE_INCONNUE.<br/>
   * <b>Result:</b> KO/CAT-4/NUMERO_COMPTE_INCONNU/Il n'existe pas de numero de compte noCompte pour le client opérateur
   * clientOperateur.<br/>
   *
   * @throws Throwable
   *           On unexpected error
   */
  @Test
  public void PE0033_ReconciliationInterneTest_BL001_VerifierDonnees_KO_009() throws Throwable
  {
    Retour retourexpected = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.NUMERO_COMPTE_INCONNU, "Il n'existe pas de numero de compte " + NO_COMPTE + " pour le client opérateur " + CLIENT_OPERATEUR); //$NON-NLS-1$ //$NON-NLS-2$

    Request request = prepareRequest("Headers Filled", "STIObject OK", null); //$NON-NLS-1$//$NON-NLS-2$

    Retour retourRPGProxy = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, IMegSpiritConsts.NUMERO_COMPTE_INCONNU);
    prepareMockRPGProxy(retourRPGProxy);

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verify();

    IRavelResponse response = request.getResponse();
    String result = response.getGenericResponse().getResult();
    BasicResponse responsePE0033 = RavelJsonTools.getInstance().fromJson(result, BasicResponse.class);
    Assert.assertEquals(ErrorCode.KO_00404.getHttpErrorCode(), response.getErrorCode().getHttpErrorCode());
    Assert.assertEquals(retourexpected.getDiagnostic(), responsePE0033.getRetour().getDiagnostic());
    Assert.assertEquals(retourexpected.getCategorie(), responsePE0033.getRetour().getCategorie());
    Assert.assertEquals(retourexpected.getLibelle(), responsePE0033.getRetour().getLibelle());
  }

  /**
   * Scenario: PE0033_ReconciliationInterne_BL001_VerifierDonnees.<br/>
   * <b>Input:</b>The call to RPGProxy pfiLireUn returns NOK/CAT-4/DONNEE_INCONNUE.<br/>
   * <b>Result:</b> KO/CAT-4/NUMERO_COMPTE_INCONNU/Il n'existe pas de numero de compte noCompte pour le client opérateur
   * clientOperateur.<br/>
   *
   * @throws Throwable
   *           On unexpected error
   */
  @Test
  public void PE0033_ReconciliationInterneTest_BL001_VerifierDonnees_KO_010() throws Throwable
  {
    Retour retourexpected = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, "The Service is Unavailable"); //$NON-NLS-1$
    Request request = prepareRequest("Headers Filled", "STIObject OK", null); //$NON-NLS-1$//$NON-NLS-2$

    Retour retourRPGProxy = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, "The Service is Unavailable"); //$NON-NLS-1$
    prepareMockRPGProxy(retourRPGProxy);

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verify();

    IRavelResponse response = request.getResponse();
    String result = response.getGenericResponse().getResult();
    BasicResponse responsePE0033 = RavelJsonTools.getInstance().fromJson(result, BasicResponse.class);
    Assert.assertEquals(ErrorCode.KO_00503.getHttpErrorCode(), response.getErrorCode().getHttpErrorCode());
    Assert.assertEquals(retourexpected.getDiagnostic(), responsePE0033.getRetour().getDiagnostic());
    Assert.assertEquals(retourexpected.getCategorie(), responsePE0033.getRetour().getCategorie());
    Assert.assertEquals(retourexpected.getLibelle(), responsePE0033.getRetour().getLibelle());
  }

  /**
   * Scenario: PE0033_ReconciliationInterne_BL001_VerifierDonnees.<br/>
   * <b>Input:</b>The portee is invalid<br/>
   * <b>Result:</b> KO/CAT-3/NON_RESPECT_STI/Invalid value for attribute portee.<br/>
   *
   * @throws Throwable
   *           On unexpected error
   */
  @Test
  public void PE0033_ReconciliationInterneTest_BL001_VerifierDonnees_KO_011() throws Throwable
  {
    Retour retourexpected = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, "Invalid value for attribute portee."); //$NON-NLS-1$

    Request request = prepareRequest("Headers Filled", "Invalid Portee", null); //$NON-NLS-1$//$NON-NLS-2$

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verify();

    IRavelResponse response = request.getResponse();
    String result = response.getGenericResponse().getResult();
    BasicResponse responsePE0033 = RavelJsonTools.getInstance().fromJson(result, BasicResponse.class);
    Assert.assertEquals(ErrorCode.KO_00400.getHttpErrorCode(), response.getErrorCode().getHttpErrorCode());
    Assert.assertEquals(retourexpected.getDiagnostic(), responsePE0033.getRetour().getDiagnostic());
    Assert.assertEquals(retourexpected.getCategorie(), responsePE0033.getRetour().getCategorie());
    Assert.assertEquals(retourexpected.getLibelle(), responsePE0033.getRetour().getLibelle());
  }

  /**
   * Scenario: PE0033_ReconciliationInterne_BL100_Traitment.<br/>
   * <b>Input:</b>The call to BL5100 returns NOK/CAT-4/DONNEE_INCONNUE.<br/>
   * <b>Result:</b> KO/CAT-4/DONNEE_INCONNUE/Error while calling BL5100.<br/>
   * clientOperateur.<br/>
   *
   * @throws Throwable
   *           On unexpected error
   */
  @Test
  public void PE0033_ReconciliationInterneTest_BL100_VerifierDonnees_KO_001() throws Throwable
  {
    Retour retourexpected = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "Error while calling BL5100"); //$NON-NLS-1$
    Request request = prepareRequest("Headers Filled", "STIObject OK", null); //$NON-NLS-1$//$NON-NLS-2$

    Retour retourRPGProxy = RetourFactoryForTU.createOkRetour();
    prepareMockRPGProxy(retourRPGProxy);

    Retour retourBL5100 = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "Error while calling BL5100"); //$NON-NLS-1$
    prepareMockBL5100(retourBL5100);

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verify();

    IRavelResponse response = request.getResponse();
    String result = response.getGenericResponse().getResult();
    BasicResponse responsePE0033 = RavelJsonTools.getInstance().fromJson(result, BasicResponse.class);
    Assert.assertEquals(ErrorCode.KO_00503.getHttpErrorCode(), response.getErrorCode().getHttpErrorCode());
    Assert.assertEquals(retourexpected.getDiagnostic(), responsePE0033.getRetour().getDiagnostic());
    Assert.assertEquals(retourexpected.getCategorie(), responsePE0033.getRetour().getCategorie());
    Assert.assertEquals(retourexpected.getLibelle(), responsePE0033.getRetour().getLibelle());
  }

  /**
   * Scenario: PE0033_ReconciliationInterne_BL100_Traitment.<br/>
   * <b>Input:</b>The call to BL5110 returns NOK/CAT-4/DONNEE_INCONNUE.<br/>
   * <b>Result:</b> KO/CAT-4/DONNEE_INCONNUE/Error while calling BL5110.<br/>
   * clientOperateur.<br/>
   *
   * @throws Throwable
   *           On unexpected error
   */
  @Test
  public void PE0033_ReconciliationInterneTest_BL100_VerifierDonnees_KO_002() throws Throwable
  {
    Retour retourexpected = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "Error while calling BL5100"); //$NON-NLS-1$
    Request request = prepareRequest("Headers Filled", "STIObject OK", null); //$NON-NLS-1$//$NON-NLS-2$

    Retour retourRPGProxy = RetourFactoryForTU.createOkRetour();
    prepareMockRPGProxy(retourRPGProxy);

    Retour retourBL5100 = RetourFactoryForTU.createOkRetour();
    prepareMockBL5100(retourBL5100);

    Retour retourBL5110 = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "Error while calling BL5100"); //$NON-NLS-1$
    prepareMockBL5110(retourBL5110);

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verify();

    IRavelResponse response = request.getResponse();
    String result = response.getGenericResponse().getResult();
    BasicResponse responsePE0033 = RavelJsonTools.getInstance().fromJson(result, BasicResponse.class);
    Assert.assertEquals(ErrorCode.KO_00503.getHttpErrorCode(), response.getErrorCode().getHttpErrorCode());
    Assert.assertEquals(retourexpected.getDiagnostic(), responsePE0033.getRetour().getDiagnostic());
    Assert.assertEquals(retourexpected.getCategorie(), responsePE0033.getRetour().getCategorie());
    Assert.assertEquals(retourexpected.getLibelle(), responsePE0033.getRetour().getLibelle());
  }

  /**
   * Scenario: PE0033_ReconciliationInterne_BL100_Traitment OK.<br/>
   * <b>Input:</b>OK inputs, Portee ESSAYER_REPROV.<br/>
   * <b>Result:</b> OK.<br/>
   * clientOperateur.<br/>
   *
   * @throws Throwable
   *           On unexpected error
   */
  @Test
  public void PE0033_ReconciliationInterneTest_Nominal_OK_Portee_ESSAYER_REPROV() throws Throwable
  {
    Retour retourexpected = RetourFactoryForTU.createOkRetour();
    Request request = prepareRequest("Headers Filled", "STIObject OK Portee ESSAYER_REPROV", null); //$NON-NLS-1$//$NON-NLS-2$

    prepareMockRPGProxy(RetourFactoryForTU.createOkRetour());

    List<ServiceTechnique> listSt = createListServiceTechnique();

    ActionCorrective actionCorrective = new ActionCorrective(CLIENT_OPERATEUR, NO_COMPTE);
    List<ActionServiceTechnique> listActionSt = new ArrayList<>();
    LocalDateTime now = DateTimeManager.getInstance().now();
    ActionServiceTechnique stlac = new ActionServiceTechnique();
    stlac.setTypeAction("MODIFICATION"); //$NON-NLS-1$
    stlac.setIdSt("idST"); //$NON-NLS-1$
    stlac.setTypeServiceTechnique("LAC"); //$NON-NLS-1$
    stlac.setStatut("INDETERMINE"); //$NON-NLS-1$
    stlac.setDateModification(now);

    ActionServiceTechnique pfsMail = new ActionServiceTechnique();
    pfsMail.setTypePfs("MAIL"); //$NON-NLS-1$
    pfsMail.setTypeAction("MODIFICATION"); //$NON-NLS-1$
    pfsMail.setIdSt("idST"); //$NON-NLS-1$
    pfsMail.setTypeServiceTechnique("PFS"); //$NON-NLS-1$
    pfsMail.setStatut("INDETERMINE"); //$NON-NLS-1$
    pfsMail.setDateModification(now);

    listActionSt.add(stlac);
    listActionSt.add(pfsMail);
    actionCorrective.setActionsServicesTechniques(listActionSt);

    ConnectorResponse<Retour, List<ServiceTechnique>> stLireTousResponse = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), listSt);

    EasyMock.expect(RSTProxy.getInstance()).andReturn(_rstProxyMock).anyTimes();
    EasyMock.expect(_rstProxyMock.serviceTechniqueLireTousParPfi(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(CLIENT_OPERATEUR), EasyMock.eq(NO_COMPTE), EasyMock.eq(null), EasyMock.eq(null))).andReturn(stLireTousResponse);

    PowerMock.expectNew(BL5100_CreerActionCorrectiveBuilder.class).andReturn(_bl5100BuilderMock);
    EasyMock.expect(_bl5100BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl5100BuilderMock);
    EasyMock.expect(_bl5100BuilderMock.idExterne(_tracabilite.getIdCorrelationSpirit())).andReturn(_bl5100BuilderMock);
    EasyMock.expect(_bl5100BuilderMock.actionCorrective(actionCorrective)).andReturn(_bl5100BuilderMock);
    EasyMock.expect(_bl5100BuilderMock.build()).andReturn(_bl5100Mock);
    String idActionCorrective = "101010"; //$NON-NLS-1$
    EasyMock.expect(_bl5100Mock.execute(EasyMock.anyObject(PE0033_ReconciliationInterne.class))).andReturn(idActionCorrective);
    EasyMock.expect(_bl5100Mock.getRetour()).andReturn(RetourFactoryForTU.createOkRetour());

    prepareMockBL5110(RetourFactoryForTU.createOkRetour());

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verify();

    IRavelResponse response = request.getResponse();
    String result = response.getGenericResponse().getResult();
    BasicResponse responsePE0033 = RavelJsonTools.getInstance().fromJson(result, BasicResponse.class);
    Assert.assertEquals(ErrorCode.KO_00200.getHttpErrorCode(), response.getErrorCode().getHttpErrorCode());
    Assert.assertEquals(retourexpected.getResultat(), responsePE0033.getRetour().getResultat());
  }

  /**
   * Scenario: PE0033_ReconciliationInterne_BL100_Traitment OK.<br/>
   * <b>Input:</b>OK inputs, Portee ESSAYER_REPROV.<br/>
   * <b>Result:</b> OK.<br/>
   * clientOperateur.<br/>
   *
   * @throws Throwable
   *           On unexpected error
   */
  @Test
  public void PE0033_ReconciliationInterneTest_Nominal_OK_Portee_ESSAYER_REPROV_CleSequencement() throws Throwable
  {
    Retour retourexpected = RetourFactoryForTU.createOkRetour();
    List<String> listeCleSequencement = Arrays.asList("CLE1", "CLE2"); //$NON-NLS-1$ //$NON-NLS-2$
    Request request = prepareRequest("Headers Filled", "STIObject OK Portee ESSAYER_REPROV", listeCleSequencement); //$NON-NLS-1$//$NON-NLS-2$

    prepareMockRPGProxy(RetourFactoryForTU.createOkRetour());

    List<ServiceTechnique> listSt = createListServiceTechnique();

    ActionCorrective actionCorrective = new ActionCorrective(CLIENT_OPERATEUR, NO_COMPTE);
    List<ActionServiceTechnique> listActionSt = new ArrayList<>();
    LocalDateTime now = DateTimeManager.getInstance().now();
    ActionServiceTechnique stlac = new ActionServiceTechnique();
    stlac.setTypeAction("MODIFICATION"); //$NON-NLS-1$
    stlac.setIdSt("idST"); //$NON-NLS-1$
    stlac.setTypeServiceTechnique("LAC"); //$NON-NLS-1$
    stlac.setStatut("INDETERMINE"); //$NON-NLS-1$
    stlac.setDateModification(now);

    ActionServiceTechnique pfsMail = new ActionServiceTechnique();
    pfsMail.setTypePfs("MAIL"); //$NON-NLS-1$
    pfsMail.setTypeAction("MODIFICATION"); //$NON-NLS-1$
    pfsMail.setIdSt("idST"); //$NON-NLS-1$
    pfsMail.setTypeServiceTechnique("PFS"); //$NON-NLS-1$
    pfsMail.setStatut("INDETERMINE"); //$NON-NLS-1$
    pfsMail.setDateModification(now);

    listActionSt.add(stlac);
    listActionSt.add(pfsMail);
    actionCorrective.setActionsServicesTechniques(listActionSt);
    actionCorrective.setListeCleSequencement(listeCleSequencement);

    ConnectorResponse<Retour, List<ServiceTechnique>> stLireTousResponse = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), listSt);

    EasyMock.expect(RSTProxy.getInstance()).andReturn(_rstProxyMock).anyTimes();
    EasyMock.expect(_rstProxyMock.serviceTechniqueLireTousParPfi(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(CLIENT_OPERATEUR), EasyMock.eq(NO_COMPTE), EasyMock.eq(null), EasyMock.eq(null))).andReturn(stLireTousResponse);

    PowerMock.expectNew(BL5100_CreerActionCorrectiveBuilder.class).andReturn(_bl5100BuilderMock);
    EasyMock.expect(_bl5100BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl5100BuilderMock);
    EasyMock.expect(_bl5100BuilderMock.idExterne(_tracabilite.getIdCorrelationSpirit())).andReturn(_bl5100BuilderMock);
    EasyMock.expect(_bl5100BuilderMock.actionCorrective(actionCorrective)).andReturn(_bl5100BuilderMock);
    EasyMock.expect(_bl5100BuilderMock.build()).andReturn(_bl5100Mock);
    String idActionCorrective = "101010"; //$NON-NLS-1$
    EasyMock.expect(_bl5100Mock.execute(EasyMock.anyObject(PE0033_ReconciliationInterne.class))).andReturn(idActionCorrective);
    EasyMock.expect(_bl5100Mock.getRetour()).andReturn(RetourFactoryForTU.createOkRetour());

    prepareMockBL5110(RetourFactoryForTU.createOkRetour());

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verify();

    IRavelResponse response = request.getResponse();
    String result = response.getGenericResponse().getResult();
    BasicResponse responsePE0033 = RavelJsonTools.getInstance().fromJson(result, BasicResponse.class);
    Assert.assertEquals(ErrorCode.KO_00200.getHttpErrorCode(), response.getErrorCode().getHttpErrorCode());
    Assert.assertEquals(retourexpected.getResultat(), responsePE0033.getRetour().getResultat());
  }

  /**
   * Scenario: PE0033_ReconciliationInterne_BL100_Traitment OK.<br/>
   * <b>Input:</b>OK inputs, Portee FORCER_REPROV.<br/>
   * <b>Result:</b> OK.<br/>
   * clientOperateur.<br/>
   *
   * @throws Throwable
   *           On unexpected error
   */
  @Test
  public void PE0033_ReconciliationInterneTest_Nominal_OK_Portee_FORCER_REPROV() throws Throwable
  {
    Retour retourexpected = RetourFactoryForTU.createOkRetour();
    Request request = prepareRequest("Headers Filled", "STIObject OK Portee FORCER_REPROV", null); //$NON-NLS-1$//$NON-NLS-2$

    prepareMockRPGProxy(RetourFactoryForTU.createOkRetour());

    List<ServiceTechnique> listSt = createListServiceTechnique();

    ActionCorrective actionCorrective = new ActionCorrective(CLIENT_OPERATEUR, NO_COMPTE);
    List<ActionServiceTechnique> listActionSt = new ArrayList<>();
    LocalDateTime now = DateTimeManager.getInstance().now();
    ActionServiceTechnique stlac = new ActionServiceTechnique();
    stlac.setTypeAction("MODIFICATION"); //$NON-NLS-1$
    stlac.setIdSt("idST"); //$NON-NLS-1$
    stlac.setTypeServiceTechnique("LAC"); //$NON-NLS-1$
    stlac.setStatut("INACTIF"); //$NON-NLS-1$
    stlac.setDateModification(now);

    ActionServiceTechnique pfsMail = new ActionServiceTechnique();
    pfsMail.setTypePfs("MAIL"); //$NON-NLS-1$
    pfsMail.setTypeAction("MODIFICATION"); //$NON-NLS-1$
    pfsMail.setIdSt("idST"); //$NON-NLS-1$
    pfsMail.setTypeServiceTechnique("PFS"); //$NON-NLS-1$
    pfsMail.setStatut("INACTIF"); //$NON-NLS-1$
    pfsMail.setDateModification(now);

    listActionSt.add(stlac);
    listActionSt.add(pfsMail);
    actionCorrective.setActionsServicesTechniques(listActionSt);

    ConnectorResponse<Retour, List<ServiceTechnique>> stLireTousResponse = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), listSt);

    EasyMock.expect(RSTProxy.getInstance()).andReturn(_rstProxyMock).anyTimes();
    EasyMock.expect(_rstProxyMock.serviceTechniqueLireTousParPfi(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(CLIENT_OPERATEUR), EasyMock.eq(NO_COMPTE), EasyMock.eq(null), EasyMock.eq(null))).andReturn(stLireTousResponse);

    PowerMock.expectNew(BL5100_CreerActionCorrectiveBuilder.class).andReturn(_bl5100BuilderMock);
    EasyMock.expect(_bl5100BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl5100BuilderMock);
    EasyMock.expect(_bl5100BuilderMock.idExterne(_tracabilite.getIdCorrelationSpirit())).andReturn(_bl5100BuilderMock);
    EasyMock.expect(_bl5100BuilderMock.actionCorrective(actionCorrective)).andReturn(_bl5100BuilderMock);
    EasyMock.expect(_bl5100BuilderMock.build()).andReturn(_bl5100Mock);
    String idActionCorrective = "101010"; //$NON-NLS-1$
    EasyMock.expect(_bl5100Mock.execute(EasyMock.anyObject(PE0033_ReconciliationInterne.class))).andReturn(idActionCorrective);
    EasyMock.expect(_bl5100Mock.getRetour()).andReturn(RetourFactoryForTU.createOkRetour());

    prepareMockBL5110(RetourFactoryForTU.createOkRetour());

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verify();

    IRavelResponse response = request.getResponse();
    String result = response.getGenericResponse().getResult();
    BasicResponse responsePE0033 = RavelJsonTools.getInstance().fromJson(result, BasicResponse.class);
    Assert.assertEquals(ErrorCode.KO_00200.getHttpErrorCode(), response.getErrorCode().getHttpErrorCode());
    Assert.assertEquals(retourexpected.getResultat(), responsePE0033.getRetour().getResultat());
  }

  /**
   * Scenario: PE0033_ReconciliationInterne_BL100_Traitment OK.<br/>
   * <b>Input:</b>OK inputs, Portee FORCER_REPROV.<br/>
   * <b>Result:</b> OK.<br/>
   * clientOperateur.<br/>
   *
   * @throws Throwable
   *           On unexpected error
   */
  @Test
  public void PE0033_ReconciliationInterneTest_Nominal_OK_Portee_FORCER_REPROV_CleSequencement() throws Throwable
  {
    Retour retourexpected = RetourFactoryForTU.createOkRetour();
    List<String> listeCleSequencement = Arrays.asList("CLE1", "CLE2"); //$NON-NLS-1$ //$NON-NLS-2$
    Request request = prepareRequest("Headers Filled", "STIObject OK Portee FORCER_REPROV", listeCleSequencement); //$NON-NLS-1$//$NON-NLS-2$

    prepareMockRPGProxy(RetourFactoryForTU.createOkRetour());

    List<ServiceTechnique> listSt = createListServiceTechnique();

    ActionCorrective actionCorrective = new ActionCorrective(CLIENT_OPERATEUR, NO_COMPTE);
    List<ActionServiceTechnique> listActionSt = new ArrayList<>();
    LocalDateTime now = DateTimeManager.getInstance().now();
    ActionServiceTechnique stlac = new ActionServiceTechnique();
    stlac.setTypeAction("MODIFICATION"); //$NON-NLS-1$
    stlac.setIdSt("idST"); //$NON-NLS-1$
    stlac.setTypeServiceTechnique("LAC"); //$NON-NLS-1$
    stlac.setStatut("INACTIF"); //$NON-NLS-1$
    stlac.setDateModification(now);

    ActionServiceTechnique pfsMail = new ActionServiceTechnique();
    pfsMail.setTypePfs("MAIL"); //$NON-NLS-1$
    pfsMail.setTypeAction("MODIFICATION"); //$NON-NLS-1$
    pfsMail.setIdSt("idST"); //$NON-NLS-1$
    pfsMail.setTypeServiceTechnique("PFS"); //$NON-NLS-1$
    pfsMail.setStatut("INACTIF"); //$NON-NLS-1$
    pfsMail.setDateModification(now);

    listActionSt.add(stlac);
    listActionSt.add(pfsMail);
    actionCorrective.setActionsServicesTechniques(listActionSt);
    actionCorrective.setListeCleSequencement(listeCleSequencement);

    ConnectorResponse<Retour, List<ServiceTechnique>> stLireTousResponse = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), listSt);

    EasyMock.expect(RSTProxy.getInstance()).andReturn(_rstProxyMock).anyTimes();
    EasyMock.expect(_rstProxyMock.serviceTechniqueLireTousParPfi(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(CLIENT_OPERATEUR), EasyMock.eq(NO_COMPTE), EasyMock.eq(null), EasyMock.eq(null))).andReturn(stLireTousResponse);

    PowerMock.expectNew(BL5100_CreerActionCorrectiveBuilder.class).andReturn(_bl5100BuilderMock);
    EasyMock.expect(_bl5100BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl5100BuilderMock);
    EasyMock.expect(_bl5100BuilderMock.idExterne(_tracabilite.getIdCorrelationSpirit())).andReturn(_bl5100BuilderMock);
    EasyMock.expect(_bl5100BuilderMock.actionCorrective(actionCorrective)).andReturn(_bl5100BuilderMock);
    EasyMock.expect(_bl5100BuilderMock.build()).andReturn(_bl5100Mock);
    String idActionCorrective = "101010"; //$NON-NLS-1$
    EasyMock.expect(_bl5100Mock.execute(EasyMock.anyObject(PE0033_ReconciliationInterne.class))).andReturn(idActionCorrective);
    EasyMock.expect(_bl5100Mock.getRetour()).andReturn(RetourFactoryForTU.createOkRetour());

    prepareMockBL5110(RetourFactoryForTU.createOkRetour());

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verify();

    IRavelResponse response = request.getResponse();
    String result = response.getGenericResponse().getResult();
    BasicResponse responsePE0033 = RavelJsonTools.getInstance().fromJson(result, BasicResponse.class);
    Assert.assertEquals(ErrorCode.KO_00200.getHttpErrorCode(), response.getErrorCode().getHttpErrorCode());
    Assert.assertEquals(retourexpected.getResultat(), responsePE0033.getRetour().getResultat());
  }

  /**
   * Scenario: PE0033_ReconciliationInterne_BL100_Traitment OK.<br/>
   * <b>Input:</b>OK inputs, Portee Null.<br/>
   * <b>Result:</b> OK.<br/>
   * clientOperateur.<br/>
   *
   * @throws Throwable
   *           On unexpected error
   */
  @Test
  public void PE0033_ReconciliationInterneTest_Nominal_OK_Portee_Null() throws Throwable
  {
    Retour retourexpected = RetourFactoryForTU.createOkRetour();
    Request request = prepareRequest("Headers Filled", "STIObject OK", null); //$NON-NLS-1$//$NON-NLS-2$

    Retour retourRPGProxy = RetourFactoryForTU.createOkRetour();
    prepareMockRPGProxy(retourRPGProxy);

    Retour retourBL5100 = RetourFactoryForTU.createOkRetour();
    prepareMockBL5100(retourBL5100);

    Retour retourBL5110 = RetourFactoryForTU.createOkRetour();
    prepareMockBL5110(retourBL5110);

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verify();

    IRavelResponse response = request.getResponse();
    String result = response.getGenericResponse().getResult();
    BasicResponse responsePE0033 = RavelJsonTools.getInstance().fromJson(result, BasicResponse.class);
    Assert.assertEquals(ErrorCode.KO_00200.getHttpErrorCode(), response.getErrorCode().getHttpErrorCode());
    Assert.assertEquals(retourexpected.getResultat(), responsePE0033.getRetour().getResultat());
  }

  /**
   * Initialize before tests.<br/>
   *
   * @throws Exception
   *           Thrown in case of error during switch in attributes of parent class
   */
  @Before
  public void before() throws Exception
  {
    _tracabilite = __podam.manufacturePojo(Tracabilite.class);
    _tracabilite.setNomProcessus(DEFAULT_PROCESSNAME);
    Map<String, String> refFonc = new HashMap<>();
    refFonc.put("cliOpe", CLIENT_OPERATEUR); //$NON-NLS-1$
    refFonc.put("noCpt", NO_COMPTE); //$NON-NLS-1$
    _tracabilite.setRefFonc(refFonc);
    _tracabilite.setIdCorrelationSpirit("4C25AE9D-CA17-4831-9243-30DC02C78079"); //$NON-NLS-1$

    PowerMock.resetAll();

    PowerMock.mockStaticStrict(BL5100_CreerActionCorrective.class);
    PowerMock.mockStaticStrict(BL5100_CreerActionCorrectiveBuilder.class);
    PowerMock.mockStaticStrict(BL5110_ExecuterActionCorrective.class);
    PowerMock.mockStaticStrict(BL5110_ExecuterActionCorrectiveBuilder.class);
    PowerMock.mockStaticStrict(RPGProxy.class);
    PowerMock.mockStaticStrict(RSTProxy.class);

    _processInstance = new PE0033_ReconciliationInterne();
    _processInstance.initializeContext();
  }

  /**
   * Method that does the needed clean up.<br/>
   *
   * <b>Entrées:</b> N/A for this test method. <br/>
   * <b>Attendu:</b> Clean up of some of our data.
   *
   */
  @After
  public void tearDown()
  {
    _processInstance = null;

  }

  /**
   * @return List ServiceTechnique
   */
  private List<ServiceTechnique> createListServiceTechnique()
  {
    LocalDateTime now = DateTimeManager.getInstance().now();

    ServiceTechnique stPfsMail = __podam.manufacturePojoWithFullData(StPfsMail.class);
    stPfsMail.setTypeServiceTechnique(TypeST.PFS.name());
    ((StPfsMail) stPfsMail).setTypePfs(TypePFS.MAIL.name());
    stPfsMail.setStatut(com.bytel.spirit.common.shared.saab.rst.Statut.ECHEC.toString());
    stPfsMail.setIdSt("idST"); //$NON-NLS-1$
    stPfsMail.setDateCreation(now);
    stPfsMail.setDateModification(now);

    StLienAllocationCommercial stLAC = new StLienAllocationCommercial("idST", "ECHEC", CLIENT_OPERATEUR, NO_COMPTE, TypeObjetCommercial.PA.name(), "BSS_GP", "ocNoCompte", "idRessource", TypeRessource.ADRESSE_MAIL.name()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
    stLAC.setDateCreation(now);
    stLAC.setDateModification(now);

    List<ServiceTechnique> listServiceTechnique = new ArrayList<>();
    listServiceTechnique.add(stLAC);
    listServiceTechnique.add(stPfsMail);

    return listServiceTechnique;
  }

  /**
   * Method to prepare mock call to BL5100.<br/>
   *
   * @param retour_p
   *          retour_p
   * @throws Throwable
   *           on error
   */
  private void prepareMockBL5100(Retour retour_p) throws Throwable
  {
    ActionCorrective actionCorrective = new ActionCorrective(CLIENT_OPERATEUR, NO_COMPTE);

    PowerMock.expectNew(BL5100_CreerActionCorrectiveBuilder.class).andReturn(_bl5100BuilderMock);
    EasyMock.expect(_bl5100BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl5100BuilderMock);
    EasyMock.expect(_bl5100BuilderMock.idExterne(_tracabilite.getIdCorrelationSpirit())).andReturn(_bl5100BuilderMock);
    EasyMock.expect(_bl5100BuilderMock.actionCorrective(actionCorrective)).andReturn(_bl5100BuilderMock);
    EasyMock.expect(_bl5100BuilderMock.build()).andReturn(_bl5100Mock);
    String idActionCorrective = "101010"; //$NON-NLS-1$
    EasyMock.expect(_bl5100Mock.execute(EasyMock.anyObject(PE0033_ReconciliationInterne.class))).andReturn(idActionCorrective);
    EasyMock.expect(_bl5100Mock.getRetour()).andReturn(retour_p);
  }

  /**
   * Method to prepare mock call to BL5110.<br/>
   *
   * @param retour_p
   *          retour_p
   * @throws Throwable
   *           on error
   */
  private void prepareMockBL5110(Retour retour_p) throws Throwable
  {
    PowerMock.expectNew(BL5110_ExecuterActionCorrectiveBuilder.class).andReturn(_bl5110BuilderMock);
    EasyMock.expect(_bl5110BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl5110BuilderMock);
    EasyMock.expect(_bl5110BuilderMock.configPath(EasyMock.anyString())).andReturn(_bl5110BuilderMock);
    EasyMock.expect(_bl5110BuilderMock.idActionCorrective("101010")).andReturn(_bl5110BuilderMock); //$NON-NLS-1$
    EasyMock.expect(_bl5110BuilderMock.ttl(EasyMock.anyObject(Duration.class))).andReturn(_bl5110BuilderMock);
    EasyMock.expect(_bl5110BuilderMock.build()).andReturn(_bl5110Mock);
    EasyMock.expect(_bl5110Mock.execute(EasyMock.anyObject(PE0033_ReconciliationInterne.class))).andReturn(null);
    EasyMock.expect(_bl5110Mock.getRetour()).andReturn(retour_p);
  }

  /**
   * Method to prepare mock call to BL1700.<br/>
   *
   * @param retour_p
   *          retour
   * @throws RavelException
   *           on error
   */
  private void prepareMockRPGProxy(Retour retour_p) throws RavelException
  {
    PFI pfi = new PFI();

    ConnectorResponse<Retour, PFI> pfiLireUnResponse = new ConnectorResponse<>(retour_p, pfi);

    EasyMock.expect(RPGProxy.getInstance()).andReturn(_rpgProxyMock).anyTimes();
    EasyMock.expect(_rpgProxyMock.pfiLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(CLIENT_OPERATEUR), EasyMock.eq(NO_COMPTE))).andReturn(pfiLireUnResponse);
  }

  /**
   * Method to prepare Request Headers and Payload.<br/>
   *
   * @param caseHeader_p
   *          caseHeader
   * @param caseSTIObject_p
   *          caseSTIObject
   * @param listeCleSequencement_p
   *          listeCleSequencement
   * @return Request
   * @throws RavelException
   *           on error
   */
  private Request prepareRequest(String caseHeader_p, String caseSTIObject_p, List<String> listeCleSequencement_p) throws RavelException
  {
    Request request = new Request(DEFAULT_PROCESSNAME, "idProcess", "idClient"); //$NON-NLS-1$ //$NON-NLS-2$
    request.setHttpMethod("POST"); //$NON-NLS-1$
    request.setMsgId(Test_Consts.DEFAULT_MSGID);

    RequestHeader requestHeaderProcess = null;
    RequestHeader requestHeaderSource = null;

    switch (caseHeader_p)
    {
      case "Headers Empty": //$NON-NLS-1$

        break;

      case "Header Source Missing": //$NON-NLS-1$

        requestHeaderProcess = new RequestHeader();
        requestHeaderProcess.setName(IHttpHeadersConsts.X_PROCESS);
        requestHeaderProcess.setValue(__podam.manufacturePojo(String.class));
        request.getRequestHeader().add(requestHeaderProcess);
        break;

      case "Header Process Missing": //$NON-NLS-1$

        requestHeaderSource = new RequestHeader();
        requestHeaderSource.setName(IHttpHeadersConsts.X_SOURCE);
        requestHeaderSource.setValue(__podam.manufacturePojo(String.class));
        request.getRequestHeader().add(requestHeaderSource);
        break;

      case "Headers Filled": //$NON-NLS-1$

        requestHeaderProcess = new RequestHeader();
        requestHeaderProcess.setName(IHttpHeadersConsts.X_PROCESS);
        requestHeaderProcess.setValue(_tracabilite.getNomProcessus());
        request.getRequestHeader().add(requestHeaderProcess);

        requestHeaderSource = new RequestHeader();
        requestHeaderSource.setName(IHttpHeadersConsts.X_SOURCE);
        requestHeaderSource.setValue(__podam.manufacturePojo(String.class));
        request.getRequestHeader().add(requestHeaderSource);

    }

    String payload = null;
    PE0033_Request stiRequestObject = null;

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();

    switch (caseSTIObject_p)
    {
      case "Body Empty": //$NON-NLS-1$

        break;

      case "Object Empty": //$NON-NLS-1$

        stiRequestObject = new PE0033_Request();
        break;

      case "ClientOperateur and NoCompte on wrong format": //$NON-NLS-1$

        stiRequestObject = new PE0033_Request("ClientOperateurrrrrrrr", "NoCompteeeeeeeeeeeeeee"); //$NON-NLS-1$ //$NON-NLS-2$
        stiRequestObject.setListeCleSequencement(listeCleSequencement_p);
        break;

      case "ClientOperateur Missing": //$NON-NLS-1$

        stiRequestObject = new PE0033_Request(null, NO_COMPTE);
        stiRequestObject.setListeCleSequencement(listeCleSequencement_p);
        break;

      case "NoCompte Missing": //$NON-NLS-1$

        stiRequestObject = new PE0033_Request(CLIENT_OPERATEUR, null);
        stiRequestObject.setListeCleSequencement(listeCleSequencement_p);
        break;

      case "STIObject OK": //$NON-NLS-1$

        stiRequestObject = new PE0033_Request(CLIENT_OPERATEUR, NO_COMPTE);
        stiRequestObject.setListeCleSequencement(listeCleSequencement_p);
        break;

      case "Invalid Portee": //$NON-NLS-1$

        stiRequestObject = new PE0033_Request(CLIENT_OPERATEUR, NO_COMPTE);
        stiRequestObject.setListeCleSequencement(listeCleSequencement_p);

        list.add(new Parameter(PORTEE, "invalidPortee")); //$NON-NLS-1$
        urlParametersType.setUrlParameters(list);
        request.setUrlParameters(urlParametersType);
        break;

      case "STIObject OK Portee ESSAYER_REPROV": //$NON-NLS-1$

        stiRequestObject = new PE0033_Request(CLIENT_OPERATEUR, NO_COMPTE);
        stiRequestObject.setListeCleSequencement(listeCleSequencement_p);

        list.add(new Parameter(PORTEE, "ESSAYER_REPROV")); //$NON-NLS-1$
        urlParametersType.setUrlParameters(list);
        request.setUrlParameters(urlParametersType);
        break;

      case "STIObject OK Portee FORCER_REPROV": //$NON-NLS-1$

        stiRequestObject = new PE0033_Request(CLIENT_OPERATEUR, NO_COMPTE);
        stiRequestObject.setListeCleSequencement(listeCleSequencement_p);

        list.add(new Parameter(PORTEE, "FORCER_REPROV")); //$NON-NLS-1$
        urlParametersType.setUrlParameters(list);
        request.setUrlParameters(urlParametersType);
        break;
    }

    payload = RavelJsonTools.getInstance().toJson(stiRequestObject, PE0033_Request.class);
    request.setPayload(payload);

    return request;
  }

}
