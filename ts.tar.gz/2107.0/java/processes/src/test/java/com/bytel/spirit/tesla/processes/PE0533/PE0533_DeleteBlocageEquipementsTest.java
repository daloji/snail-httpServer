/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.tesla.processes.PE0533;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import javax.ws.rs.HttpMethod;

import org.easymock.EasyMock;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PowerMockListener;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.testlisteners.FieldDefaulter;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.modules.junit4.PowerMockRunnerDelegate;
import org.springframework.test.context.ContextConfiguration;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.data.exchange.generated.RavelRequest.RequestHeader;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.request.UrlParameters;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.test.podam.PodamBytelJUnit4ClassRunner;
import com.bytel.ravel.common.utils.DateTimeTools.DateTimeFormatPattern;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.net.http.HttpConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.utils.Test_Consts;
import com.bytel.spirit.common.connectors.res.RESProxy;
import com.bytel.spirit.common.connectors.rex.REXProxy;
import com.bytel.spirit.common.shared.functional.types.json.RavelJsonTools;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.error.ReponseErreur;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.TypeIdentifiant;
import com.bytel.spirit.common.shared.saab.rex.BlocageEquipement;
import com.bytel.spirit.common.shared.saab.rex.BlocageEquipementStatut;
import com.bytel.spirit.common.shared.saab.rex.Equipement;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author bsinquin
 * @version ($Revision$ $Date$)
 */

@RunWith(PowerMockRunner.class)
@PowerMockListener(FieldDefaulter.class)
@PowerMockRunnerDelegate(PodamBytelJUnit4ClassRunner.class)
@ContextConfiguration("classpath:BeansProcessTestMocks.xml")
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
@PrepareForTest({ PE0533_BlocageEquipements.class, REXProxy.class, RESProxy.class })
public final class PE0533_DeleteBlocageEquipementsTest
{
  /**
   * bean Factory generation
   */
  private static PodamFactory __podam;

  /**
   * The current timestamp
   */
  private static LocalDateTime __now;

  /**
   * The object {@Code Tracabilite}
   */
  private static Tracabilite __traceability;

  /**
   * The default process name.
   */
  public static final String DEFAULT_PROCESSNAME = "PE0533_BlocagePriseClients"; //$NON-NLS-1$

  /**
   * Constant for RES call
   */
  private static final String COMMENTAIRE_BLOCAGE = "desactivation blocage le "; //$NON-NLS-1$

  /**
   * Expected error message
   */
  private static final Object MESSAGE_URL_PARAMETER_ABSENT = "URL Parameter obligatoire(s) manquant(s): idBlocageEquipement"; //$NON-NLS-1$

  /**
   * Initialize before all tests
   *
   * @throws Exception
   *           Exception to be thrown in case of failure
   */
  @BeforeClass
  public static void setUpBeforeClass() throws Exception
  {
    __podam = new PodamFactoryImpl();
    __podam.getStrategy().setMemoization(false);
    __podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());

    __traceability = __podam.manufacturePojoWithFullData(Tracabilite.class);

  }

  /**
   * Mock de {@link RESProxy}
   */
  @MockStrict
  protected RESProxy _resMock;

  /**
   * Mock de {@REXProxy}
   */
  @MockStrict
  protected REXProxy _rexMock;

  /**
   * Instance to evaluate
   */
  private PE0533_BlocageEquipements _processInstance;

  /**
   * Initialize before tests
   *
   * @throws Exception
   *           Thrown in case of error during switch in attributes of parent class
   */
  @Before
  public void beforeTest() throws Exception
  {

    _processInstance = new PE0533_BlocageEquipements();
    _processInstance.initializeContext();

    __traceability = new Tracabilite();
    __now = LocalDateTime.now();
    PowerMock.resetAll();

    PowerMock.mockStaticStrict(REXProxy.class);
    PowerMock.mockStaticStrict(RESProxy.class);
    PowerMock.mockStaticNice(LocalDateTime.class);
    EasyMock.expect(LocalDateTime.now()).andReturn(__now).anyTimes();

  }

  /**
   * BL001 NOK Manque parametre idBlocageEquipement
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0533_BlocagePriseClients_DELETE_BL001_KO_001() throws Throwable
  {
    //Prepare request
    Request request = new Request(DEFAULT_PROCESSNAME, "idProcess", "idClient"); //$NON-NLS-1$ //$NON-NLS-2$
    request.setHttpMethod(HttpMethod.GET);
    request.setMsgId(Test_Consts.DEFAULT_MSGID);
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "Basic AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    request.setRequestHeader(headers);

    PowerMock.replayAll();

    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startDeleteProcess(request, __traceability);
    Response response = (Response) request.getResponse();

    //Checks
    PowerMock.verifyAll();

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals(MESSAGE_URL_PARAMETER_ABSENT, reponseactual.getErrorDescription());
    Assert.assertEquals(IMegSpiritConsts.DONNEE_INVALIDE, reponseactual.getError());
  }

  /**
   * BL001 NOK Manque parametre idBlocageEquipement #2
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0533_BlocagePriseClients_DELETE_BL001_KO_002() throws Throwable
  {
    //Prepare request
    Request request = new Request(DEFAULT_PROCESSNAME, "idProcess", "idClient"); //$NON-NLS-1$ //$NON-NLS-2$
    request.setHttpMethod(HttpMethod.GET);
    request.setMsgId(Test_Consts.DEFAULT_MSGID);
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "Basic AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    request.setRequestHeader(headers);

    UrlParameters urlParametersType = new UrlParameters();
    request.setUrlParameters(urlParametersType);

    PowerMock.replayAll();

    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startDeleteProcess(request, __traceability);
    Response response = (Response) request.getResponse();

    //Checks
    PowerMock.verifyAll();

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals(MESSAGE_URL_PARAMETER_ABSENT, reponseactual.getErrorDescription());
    Assert.assertEquals(IMegSpiritConsts.DONNEE_INVALIDE, reponseactual.getError());
  }

  /**
   * Retour NOK de REX blocageEquipementLireUn
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0533_BlocagePriseClients_DELETE_BL100_KO_001() throws Throwable
  {
    //Prepare request
    String idBlocagePriseClients = __podam.manufacturePojoWithFullData(String.class);
    Request request = prepareDeleteRequest(idBlocagePriseClients);

    //Prepare mocks responses
    String libelleErreur = __podam.manufacturePojoWithFullData(String.class);
    ConnectorResponse<Retour, BlocageEquipement> rexResponseLireUn = new ConnectorResponse<Retour, BlocageEquipement>(RetourFactory.createNOK(IMegConsts.CAT10, IMegConsts.TRAITEMENT_ARRETE, libelleErreur), null);

    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexMock).anyTimes();

    EasyMock.expect(_rexMock.blocageEquipementLireUn(__traceability, idBlocagePriseClients)).andReturn(rexResponseLireUn);

    //Execute tests
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startDeleteProcess(request, __traceability);
    Response response = (Response) request.getResponse();

    //Checks
    PowerMock.verifyAll();

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    Assert.assertEquals(libelleErreur, reponseactual.getErrorDescription());
    Assert.assertEquals(IMegConsts.TRAITEMENT_ARRETE, reponseactual.getError());
  }

  /**
   * Retour NOK de REX blocageEquipementSupprimer
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0533_BlocagePriseClients_DELETE_BL100_KO_002() throws Throwable
  {
    //Prepare request
    String idBlocagePriseClients = __podam.manufacturePojoWithFullData(String.class);
    Request request = prepareDeleteRequest(idBlocagePriseClients);

    //Prepare mocks responses
    String libelleErreur = __podam.manufacturePojoWithFullData(String.class);
    ConnectorResponse<Retour, BlocageEquipement> rexResponseLireUn = new ConnectorResponse<Retour, BlocageEquipement>(RetourFactory.createOkRetour(), __podam.manufacturePojoWithFullData(BlocageEquipement.class));
    ConnectorResponse<Retour, Nothing> rexResponseSupprimer = new ConnectorResponse<Retour, Nothing>(RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, libelleErreur), null);

    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexMock).anyTimes();

    EasyMock.expect(_rexMock.blocageEquipementLireUn(__traceability, idBlocagePriseClients)).andReturn(rexResponseLireUn);
    EasyMock.expect(_rexMock.blocageEquipementSupprimer(__traceability, idBlocagePriseClients)).andReturn(rexResponseSupprimer);

    //Execute tests
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startDeleteProcess(request, __traceability);
    Response response = (Response) request.getResponse();

    //Checks
    PowerMock.verifyAll();

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00404, response.getErrorCode());
    Assert.assertEquals(libelleErreur, reponseactual.getErrorDescription());
    Assert.assertEquals(IMegConsts.DONNEE_INCONNUE, reponseactual.getError());
  }

  /**
   * Retour NOK pmCompositeModifierSurchargePriseClientPM
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0533_BlocagePriseClients_DELETE_BL100_KO_003() throws Throwable
  {
    //Prepare request
    String idBlocagePriseClients = __podam.manufacturePojoWithFullData(String.class);
    Request request = prepareDeleteRequest(idBlocagePriseClients);

    //Prepare mocks responses
    String libelleErreur = __podam.manufacturePojoWithFullData(String.class);
    PrepareMocksForDelete(idBlocagePriseClients, false, false, true, false, RetourFactory.createNOK(IMegConsts.CAT3, IMegConsts.DONNEE_INCONNUE, libelleErreur));

    //Execute tests
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startDeleteProcess(request, __traceability);
    Response actualResponse = (Response) request.getResponse();

    //Checks
    PowerMock.verifyAll();

    String resp = actualResponse.getGenericResponse().getResult();
    ReponseErreur actualReponseErreur = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, actualResponse.getErrorCode());
    Assert.assertEquals(libelleErreur, actualReponseErreur.getErrorDescription());
    Assert.assertEquals(IMegConsts.DONNEE_INCONNUE, actualReponseErreur.getError());
  }

  /**
   * Retour NOK pmCompositeModifierSurchargePriseClientBoitierPM
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0533_BlocagePriseClients_DELETE_BL100_KO_004() throws Throwable
  {
    //Prepare request
    String idBlocagePriseClients = __podam.manufacturePojoWithFullData(String.class);
    Request request = prepareDeleteRequest(idBlocagePriseClients);

    //Prepare mocks responses
    String libelleErreur = __podam.manufacturePojoWithFullData(String.class);
    PrepareMocksForDelete(idBlocagePriseClients, false, true, false, false, RetourFactory.createNOK(IMegConsts.CAT3, IMegConsts.DONNEE_INCONNUE, libelleErreur));

    //Execute tests
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startDeleteProcess(request, __traceability);
    Response actualResponse = (Response) request.getResponse();

    //Checks
    PowerMock.verifyAll();

    String resp = actualResponse.getGenericResponse().getResult();
    ReponseErreur actualReponseErreur = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, actualResponse.getErrorCode());
    Assert.assertEquals(libelleErreur, actualReponseErreur.getErrorDescription());
    Assert.assertEquals(IMegConsts.DONNEE_INCONNUE, actualReponseErreur.getError());
  }

  /**
   * Retour NOK oltCompositeModifierSurchargePriseClientCarte
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0533_BlocagePriseClients_DELETE_BL100_KO_005() throws Throwable
  {
    //Prepare request
    String idBlocagePriseClients = __podam.manufacturePojoWithFullData(String.class);
    Request request = prepareDeleteRequest(idBlocagePriseClients);

    //Prepare mocks responses
    String libelleErreur = __podam.manufacturePojoWithFullData(String.class);
    PrepareMocksForDelete(idBlocagePriseClients, true, false, false, false, RetourFactory.createNOK(IMegConsts.CAT6, IMegConsts.DONNEE_INCONNUE, libelleErreur));

    //Execute tests
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startDeleteProcess(request, __traceability);
    Response actualResponse = (Response) request.getResponse();

    //Checks
    PowerMock.verifyAll();

    String resp = actualResponse.getGenericResponse().getResult();
    ReponseErreur actualReponseErreur = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00500, actualResponse.getErrorCode());
    Assert.assertEquals(libelleErreur, actualReponseErreur.getErrorDescription());
    Assert.assertEquals(IMegConsts.DONNEE_INCONNUE, actualReponseErreur.getError());
  }

  /**
   * Retour NOK oltCompositeModifierSurchargePriseClientOLT
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0533_BlocagePriseClients_DELETE_BL100_KO_006() throws Throwable
  {
    //Prepare request
    String idBlocagePriseClients = __podam.manufacturePojoWithFullData(String.class);
    Request request = prepareDeleteRequest(idBlocagePriseClients);

    //Prepare mocks responses
    String libelleErreur = __podam.manufacturePojoWithFullData(String.class);
    PrepareMocksForDelete(idBlocagePriseClients, false, false, false, true, RetourFactory.createNOK(IMegConsts.CAT3, IMegConsts.DONNEE_INCONNUE, libelleErreur));

    //Execute tests
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startDeleteProcess(request, __traceability);
    Response actualResponse = (Response) request.getResponse();

    //Checks
    PowerMock.verifyAll();

    String resp = actualResponse.getGenericResponse().getResult();
    ReponseErreur actualReponseErreur = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, actualResponse.getErrorCode());
    Assert.assertEquals(libelleErreur, actualReponseErreur.getErrorDescription());
    Assert.assertEquals(IMegConsts.DONNEE_INCONNUE, actualReponseErreur.getError());
  }

  /**
   * Exception sur pmCompositeModifierSurchargePriseClientPM
   *
   * @throws Throwable
   *           exception
   */
  @Test
  public void PE0533_BlocagePriseClients_DELETE_BL100_KO_007() throws Throwable
  {
    //Prepare request
    String idBlocagePriseClients = __podam.manufacturePojoWithFullData(String.class);
    Request request = prepareDeleteRequest(idBlocagePriseClients);

    //Prepare mocks responses
    Set<Equipement> listeEquipement = new LinkedHashSet<>();
    DateTimeFormatPattern formatter = DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZ;
    String commentaireBlocage = COMMENTAIRE_BLOCAGE.concat(formatter.format(__now));

    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexMock).anyTimes();
    EasyMock.expect(RESProxy.getInstance()).andReturn(_resMock).anyTimes();

    Equipement eqptPM_SansReferenceBoitier = new Equipement(TypeIdentifiant.PM.name());
    eqptPM_SansReferenceBoitier.setReferencePmBytel("PM1"); //$NON-NLS-1$
    listeEquipement.add(eqptPM_SansReferenceBoitier);
    EasyMock.expect(_resMock.pmCompositeModifierSurchargePriseClientPM(__traceability, eqptPM_SansReferenceBoitier.getReferencePmBytel(), BlocageEquipementStatut.INACTIF.name(), commentaireBlocage))//
        .andThrow(new RavelException(ExceptionType.UNDEFINED, ErrorCode.CNCTOR_00010, "Exception")); //$NON-NLS-1$

    BlocageEquipement blocageEquipementMock = new BlocageEquipement(idBlocagePriseClients, "statut", new HashSet<>(), listeEquipement); //$NON-NLS-1$
    ConnectorResponse<Retour, BlocageEquipement> rexResponseLireUn = new ConnectorResponse<Retour, BlocageEquipement>(RetourFactory.createOkRetour(), blocageEquipementMock);
    ConnectorResponse<Retour, Nothing> rexResponseSupprimer = new ConnectorResponse<Retour, Nothing>(RetourFactory.createOkRetour(), null);

    EasyMock.expect(_rexMock.blocageEquipementLireUn(__traceability, idBlocagePriseClients)).andReturn(rexResponseLireUn);
    EasyMock.expect(_rexMock.blocageEquipementSupprimer(__traceability, idBlocagePriseClients)).andReturn(rexResponseSupprimer);

    //Execute tests
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startDeleteProcess(request, __traceability);
    Response actualResponse = (Response) request.getResponse();

    //Checks
    PowerMock.verifyAll();

    String resp = actualResponse.getGenericResponse().getResult();
    ReponseErreur actualReponseErreur = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00500, actualResponse.getErrorCode());
    Assert.assertEquals("Exception", actualReponseErreur.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegConsts.TRAITEMENT_ARRETE, actualReponseErreur.getError());
  }

  /**
   * Exception sur pmCompositeModifierSurchargePriseClientBoitierPM
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0533_BlocagePriseClients_DELETE_BL100_KO_008() throws Throwable
  {
    //Prepare request
    String idBlocagePriseClients = __podam.manufacturePojoWithFullData(String.class);
    Request request = prepareDeleteRequest(idBlocagePriseClients);

    //Prepare mocks responses
    Set<Equipement> listeEquipement = new LinkedHashSet<>();
    DateTimeFormatPattern formatter = DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZ;
    String commentaireBlocage = COMMENTAIRE_BLOCAGE.concat(formatter.format(__now));

    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexMock).anyTimes();
    EasyMock.expect(RESProxy.getInstance()).andReturn(_resMock).anyTimes();

    Equipement eqptPM_AvecReferenceBoitier = new Equipement(TypeIdentifiant.PM.name());
    eqptPM_AvecReferenceBoitier.setReferencePmBytel("PM2"); //$NON-NLS-1$
    Set<String> listeRefBoitier = new LinkedHashSet<>();
    listeRefBoitier.add("PM_REF1"); //$NON-NLS-1$
    eqptPM_AvecReferenceBoitier.setListeReferenceBoitierPm(listeRefBoitier);
    listeEquipement.add(eqptPM_AvecReferenceBoitier);
    EasyMock.expect(_resMock.pmCompositeModifierSurchargePriseClientBoitierPM(__traceability, eqptPM_AvecReferenceBoitier.getReferencePmBytel(), "PM_REF1", BlocageEquipementStatut.INACTIF.name(), commentaireBlocage))// //$NON-NLS-1$
        .andThrow(new RavelException(ExceptionType.UNDEFINED, ErrorCode.CNCTOR_00010, "Exception")); //$NON-NLS-1$

    BlocageEquipement blocageEquipementMock = new BlocageEquipement(idBlocagePriseClients, "statut", new HashSet<>(), listeEquipement); //$NON-NLS-1$
    ConnectorResponse<Retour, BlocageEquipement> rexResponseLireUn = new ConnectorResponse<Retour, BlocageEquipement>(RetourFactory.createOkRetour(), blocageEquipementMock);
    ConnectorResponse<Retour, Nothing> rexResponseSupprimer = new ConnectorResponse<Retour, Nothing>(RetourFactory.createOkRetour(), null);

    EasyMock.expect(_rexMock.blocageEquipementLireUn(__traceability, idBlocagePriseClients)).andReturn(rexResponseLireUn);
    EasyMock.expect(_rexMock.blocageEquipementSupprimer(__traceability, idBlocagePriseClients)).andReturn(rexResponseSupprimer);

    //Execute tests
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startDeleteProcess(request, __traceability);
    Response actualResponse = (Response) request.getResponse();

    //Checks
    PowerMock.verifyAll();

    String resp = actualResponse.getGenericResponse().getResult();
    ReponseErreur actualReponseErreur = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00500, actualResponse.getErrorCode());
    Assert.assertEquals("Exception", actualReponseErreur.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegConsts.TRAITEMENT_ARRETE, actualReponseErreur.getError());
  }

  /**
   * Exception sur oltCompositeModifierSurchargePriseClientCarte
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0533_BlocagePriseClients_DELETE_BL100_KO_009() throws Throwable
  {
    //Prepare request
    String idBlocagePriseClients = __podam.manufacturePojoWithFullData(String.class);
    Request request = prepareDeleteRequest(idBlocagePriseClients);

    //Prepare mocks responses
    Set<Equipement> listeEquipement = new LinkedHashSet<>();
    DateTimeFormatPattern formatter = DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZ;
    String commentaireBlocage = COMMENTAIRE_BLOCAGE.concat(formatter.format(__now));

    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexMock).anyTimes();
    EasyMock.expect(RESProxy.getInstance()).andReturn(_resMock).anyTimes();

    Equipement eqptOLT_AvecPositionCarte = new Equipement(TypeIdentifiant.OLT.name());
    eqptOLT_AvecPositionCarte.setNomOLT("OLT2"); //$NON-NLS-1$
    Set<Integer> listeRefOLT = new LinkedHashSet<>();
    listeRefOLT.add(1);
    EasyMock.expect(_resMock.oltCompositeModifierSurchargePriseClientCarte(__traceability, eqptOLT_AvecPositionCarte.getNomOLT(), "1", BlocageEquipementStatut.INACTIF.name(), commentaireBlocage))// //$NON-NLS-1$
        .andThrow(new RavelException(ExceptionType.UNDEFINED, ErrorCode.CNCTOR_00010, "Exception")); //$NON-NLS-1$
    eqptOLT_AvecPositionCarte.setListePositionCarte(listeRefOLT);
    listeEquipement.add(eqptOLT_AvecPositionCarte);

    BlocageEquipement blocageEquipementMock = new BlocageEquipement(idBlocagePriseClients, "statut", new HashSet<>(), listeEquipement); //$NON-NLS-1$
    ConnectorResponse<Retour, BlocageEquipement> rexResponseLireUn = new ConnectorResponse<Retour, BlocageEquipement>(RetourFactory.createOkRetour(), blocageEquipementMock);
    ConnectorResponse<Retour, Nothing> rexResponseSupprimer = new ConnectorResponse<Retour, Nothing>(RetourFactory.createOkRetour(), null);

    EasyMock.expect(_rexMock.blocageEquipementLireUn(__traceability, idBlocagePriseClients)).andReturn(rexResponseLireUn);
    EasyMock.expect(_rexMock.blocageEquipementSupprimer(__traceability, idBlocagePriseClients)).andReturn(rexResponseSupprimer);

    //Execute tests
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startDeleteProcess(request, __traceability);
    Response actualResponse = (Response) request.getResponse();

    //Checks
    PowerMock.verifyAll();

    String resp = actualResponse.getGenericResponse().getResult();
    ReponseErreur actualReponseErreur = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00500, actualResponse.getErrorCode());
    Assert.assertEquals("Exception", actualReponseErreur.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegConsts.TRAITEMENT_ARRETE, actualReponseErreur.getError());
  }

  /**
   * Exception sur pmCompositeModifierSurchargePriseClientPM
   *
   * @throws Throwable
   *           the exception
   */
  @Test
  public void PE0533_BlocagePriseClients_DELETE_BL100_KO_010() throws Throwable
  {
    //Prepare request
    String idBlocagePriseClients = __podam.manufacturePojoWithFullData(String.class);
    Request request = prepareDeleteRequest(idBlocagePriseClients);

    //Prepare mocks responses
    Set<Equipement> listeEquipement = new LinkedHashSet<>();
    DateTimeFormatPattern formatter = DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZ;
    String commentaireBlocage = COMMENTAIRE_BLOCAGE.concat(formatter.format(__now));

    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexMock).anyTimes();
    EasyMock.expect(RESProxy.getInstance()).andReturn(_resMock).anyTimes();

    Equipement eqptOLT_SansPositionCarte = new Equipement(TypeIdentifiant.OLT.name());
    eqptOLT_SansPositionCarte.setNomOLT("OLT1"); //$NON-NLS-1$
    listeEquipement.add(eqptOLT_SansPositionCarte);
    EasyMock.expect(_resMock.oltCompositeModifierSurchargePriseClientOLT(__traceability, eqptOLT_SansPositionCarte.getNomOLT(), BlocageEquipementStatut.INACTIF.name(), commentaireBlocage))//
        .andThrow(new RavelException(ExceptionType.UNDEFINED, ErrorCode.CNCTOR_00010, "Exception")); //$NON-NLS-1$

    BlocageEquipement blocageEquipementMock = new BlocageEquipement(idBlocagePriseClients, "statut", new HashSet<>(), listeEquipement); //$NON-NLS-1$
    ConnectorResponse<Retour, BlocageEquipement> rexResponseLireUn = new ConnectorResponse<Retour, BlocageEquipement>(RetourFactory.createOkRetour(), blocageEquipementMock);
    ConnectorResponse<Retour, Nothing> rexResponseSupprimer = new ConnectorResponse<Retour, Nothing>(RetourFactory.createOkRetour(), null);

    EasyMock.expect(_rexMock.blocageEquipementLireUn(__traceability, idBlocagePriseClients)).andReturn(rexResponseLireUn);
    EasyMock.expect(_rexMock.blocageEquipementSupprimer(__traceability, idBlocagePriseClients)).andReturn(rexResponseSupprimer);

    //Execute tests
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startDeleteProcess(request, __traceability);
    Response actualResponse = (Response) request.getResponse();

    //Checks
    PowerMock.verifyAll();

    String resp = actualResponse.getGenericResponse().getResult();
    ReponseErreur actualReponseErreur = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00500, actualResponse.getErrorCode());
    Assert.assertEquals("Exception", actualReponseErreur.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegConsts.TRAITEMENT_ARRETE, actualReponseErreur.getError());
  }

  /**
   * Retour OK Aucun PM/OLT a debloquer
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0533_BlocagePriseClients_DELETE_BL100_OK_001() throws Throwable
  {
    //Prepare request
    String idBlocagePriseClients = __podam.manufacturePojoWithFullData(String.class);
    Request request = prepareDeleteRequest(idBlocagePriseClients);

    //Prepare mocks responses
    BlocageEquipement blocageEquipementMock = new BlocageEquipement(idBlocagePriseClients, "statut", null, null); //$NON-NLS-1$
    ConnectorResponse<Retour, BlocageEquipement> rexResponseLireUn = new ConnectorResponse<Retour, BlocageEquipement>(RetourFactory.createOkRetour(), blocageEquipementMock);
    ConnectorResponse<Retour, Nothing> rexResponseSupprimer = new ConnectorResponse<Retour, Nothing>(RetourFactory.createOkRetour(), null);

    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexMock).anyTimes();

    EasyMock.expect(_rexMock.blocageEquipementLireUn(__traceability, idBlocagePriseClients)).andReturn(rexResponseLireUn);
    EasyMock.expect(_rexMock.blocageEquipementSupprimer(__traceability, idBlocagePriseClients)).andReturn(rexResponseSupprimer);

    //Execute tests
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startDeleteProcess(request, __traceability);
    Response actualResponse = (Response) request.getResponse();

    //Checks
    PowerMock.verifyAll();

    Assert.assertEquals(ErrorCode.OK_00200, actualResponse.getErrorCode());
    Assert.assertNull(actualResponse.getResult());
  }

  /**
   * Retour OK Plusieurs PM et OLT, tous types d'appels
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0533_BlocagePriseClients_DELETE_BL100_OK_002() throws Throwable
  {
    //Prepare request
    String idBlocagePriseClients = __podam.manufacturePojoWithFullData(String.class);
    Request request = prepareDeleteRequest(idBlocagePriseClients);

    //Prepare mocks responses
    PrepareMocksForDelete(idBlocagePriseClients, true, true, true, true, RetourFactory.createOkRetour());

    //Execute tests
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startDeleteProcess(request, __traceability);
    Response actualResponse = (Response) request.getResponse();

    //Checks
    PowerMock.verifyAll();

    Assert.assertEquals(ErrorCode.OK_00200, actualResponse.getErrorCode());
    Assert.assertNull(actualResponse.getResult());
  }

  /**
   * Method that does the needed clean up.<br/>
   *
   * <b>Entrées:</b> N/A for this test method. <br/>
   * <b>Attendu:</b> Clean up of some of our data.
   *
   */
  @After
  public void tearDown()
  {
    _processInstance = null;
  }

  /**
   * Add custom headers
   *
   * @param requestId_p
   *          {@link String}
   * @param process_p
   *          {@link String}
   * @param source_p
   *          {@link String}
   * @param messageId_p
   *          {@link String}
   * @param actionId_p
   *          {@link String}
   * @param authorization_p
   *          {@link String}
   * @return {@link List}
   */
  private List<RequestHeader> addXHeaders(String requestId_p, String process_p, String source_p, String messageId_p, String actionId_p, String authorization_p)
  {
    List<RequestHeader> headers = new ArrayList<>();
    RequestHeader hdr = new RequestHeader();

    hdr.setName(IHttpHeadersConsts.CONTENT_TYPE);
    hdr.setValue(HttpConstants.CONTENT_TYPE_JSON);
    headers.add(hdr);

    if (requestId_p != null)
    {
      hdr = new RequestHeader();
      hdr.setName(IHttpHeadersConsts.X_REQUEST_ID);
      hdr.setValue(requestId_p);
      headers.add(hdr);
    }

    if (source_p != null)
    {
      hdr = new RequestHeader();
      hdr.setName(IHttpHeadersConsts.X_SOURCE);
      hdr.setValue(source_p);
      headers.add(hdr);
    }

    if (process_p != null)
    {
      hdr = new RequestHeader();
      hdr.setName(IHttpHeadersConsts.X_PROCESS);
      hdr.setValue(process_p);
      headers.add(hdr);
    }

    if (messageId_p != null)
    {
      hdr = new RequestHeader();
      hdr.setName(IHttpHeadersConsts.X_MESSAGE_ID);
      hdr.setValue(messageId_p);
      headers.add(hdr);
    }

    if (actionId_p != null)
    {
      hdr = new RequestHeader();
      hdr.setName(IHttpHeadersConsts.X_ACTION_ID);
      hdr.setValue(actionId_p);
      headers.add(hdr);
    }

    if (authorization_p != null)
    {
      hdr = new RequestHeader();
      hdr.setName(IHttpHeadersConsts.AUTHORIZATION);
      hdr.setValue(authorization_p);
      headers.add(hdr);
    }

    return headers;

  }

  /**
   * Prepare the Delete request for the test
   *
   * @param idBlocagePriseClients_p
   *          the id
   * @return The prepared request
   */
  private Request prepareDeleteRequest(String idBlocagePriseClients_p)
  {

    Request request = new Request(DEFAULT_PROCESSNAME, "idProcess", "idClient"); //$NON-NLS-1$ //$NON-NLS-2$
    request.setHttpMethod(HttpMethod.GET);
    request.setMsgId(Test_Consts.DEFAULT_MSGID);
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "Basic AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    request.setRequestHeader(headers);

    request.setUrlDynamicParameters(idBlocagePriseClients_p);
    return request;

  }

  /**
   * Prepare the REX and RES mocks for the delete request
   *
   *
   * @param idBlocagePriseClients_p
   *          String
   * @param oltWithRef_p
   *          boolean generate or not an Equipement of type OLT with References
   * @param oltWithoutRef_p
   *          boolean generate or not an Equipement of type OL without References
   * @param pmWithRef_p
   *          boolean generate or not an Equipement of type PM with References
   * @param pmWithoutRef_p
   *          boolean generate or not an Equipement of type PM without References
   * @param resRetour_p
   *          Retour the Retour to be returned by RES mock
   * @throws Throwable
   *           the exception
   */
  private void PrepareMocksForDelete(String idBlocagePriseClients_p, Boolean oltWithRef_p, Boolean oltWithoutRef_p, Boolean pmWithRef_p, Boolean pmWithoutRef_p, Retour resRetour_p) throws Throwable
  {
    //Prepare request

    Set<Equipement> listeEquipement = new LinkedHashSet<>();
    DateTimeFormatPattern formatter = DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZ;
    String commentaireBlocage = COMMENTAIRE_BLOCAGE.concat(formatter.format(__now));

    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexMock).anyTimes();
    EasyMock.expect(RESProxy.getInstance()).andReturn(_resMock).anyTimes();

    // ! Order of these blocs is important as they generate a call to the same mock
    //Equipement values are set with static values as collections are Sets the order depends on the values

    if (oltWithRef_p)
    {
      //#1 Equipement OLT with 2 References in ListeEquipement
      Equipement eqptOLT_AvecPositionCarte = new Equipement(TypeIdentifiant.OLT.name());
      eqptOLT_AvecPositionCarte.setNomOLT("OLT1"); //$NON-NLS-1$
      Set<Integer> listeRefOLT = new LinkedHashSet<>();
      listeRefOLT.add(1);
      EasyMock.expect(_resMock.oltCompositeModifierSurchargePriseClientCarte(__traceability, eqptOLT_AvecPositionCarte.getNomOLT(), "1", BlocageEquipementStatut.INACTIF.name(), commentaireBlocage))// //$NON-NLS-1$
          .andReturn(new ConnectorResponse<Retour, Nothing>(resRetour_p, null));
      if (StringConstants.OK.equals(resRetour_p.getResultat()))
      {//If return is NOK only first Equipement is processed in the FOR loop
        listeRefOLT.add(2);
        EasyMock.expect(_resMock.oltCompositeModifierSurchargePriseClientCarte(__traceability, eqptOLT_AvecPositionCarte.getNomOLT(), "2", BlocageEquipementStatut.INACTIF.name(), commentaireBlocage))// //$NON-NLS-1$
            .andReturn(new ConnectorResponse<Retour, Nothing>(resRetour_p, null));
      }
      eqptOLT_AvecPositionCarte.setListePositionCarte(listeRefOLT);
      listeEquipement.add(eqptOLT_AvecPositionCarte);
    }

    if (oltWithoutRef_p)
    {
      //#4 Equipement OLT without References in ListeEquipement
      Equipement eqptOLT_SansPositionCarte = new Equipement(TypeIdentifiant.OLT.name());
      eqptOLT_SansPositionCarte.setNomOLT("OLT2"); //$NON-NLS-1$
      listeEquipement.add(eqptOLT_SansPositionCarte);
      EasyMock.expect(_resMock.oltCompositeModifierSurchargePriseClientOLT(__traceability, eqptOLT_SansPositionCarte.getNomOLT(), BlocageEquipementStatut.INACTIF.name(), commentaireBlocage))//
          .andReturn(new ConnectorResponse<Retour, Nothing>(resRetour_p, null));
    }

    if (pmWithRef_p)
    {
      //#2 Equipement PM with 2 References in ListeEquipement
      Equipement eqptPM_AvecReferenceBoitier = new Equipement(TypeIdentifiant.PM.name());
      eqptPM_AvecReferenceBoitier.setReferencePmBytel("PM1"); //$NON-NLS-1$
      Set<String> listeRefBoitier = new LinkedHashSet<>();
      listeRefBoitier.add("PM_REF1"); //$NON-NLS-1$
      EasyMock.expect(_resMock.pmCompositeModifierSurchargePriseClientBoitierPM(__traceability, eqptPM_AvecReferenceBoitier.getReferencePmBytel(), "PM_REF1", BlocageEquipementStatut.INACTIF.name(), commentaireBlocage))// //$NON-NLS-1$
          .andReturn(new ConnectorResponse<Retour, Nothing>(resRetour_p, null));
      if (StringConstants.OK.equals(resRetour_p.getResultat()))
      {//If return is NOK only first Equipement is processed in the FOR loop
        listeRefBoitier.add("PM_REF2"); //$NON-NLS-1$
        EasyMock.expect(_resMock.pmCompositeModifierSurchargePriseClientBoitierPM(__traceability, eqptPM_AvecReferenceBoitier.getReferencePmBytel(), "PM_REF2", BlocageEquipementStatut.INACTIF.name(), commentaireBlocage))// //$NON-NLS-1$
            .andReturn(new ConnectorResponse<Retour, Nothing>(resRetour_p, null));
      }
      eqptPM_AvecReferenceBoitier.setListeReferenceBoitierPm(listeRefBoitier);
      listeEquipement.add(eqptPM_AvecReferenceBoitier);
    }

    if (pmWithoutRef_p)
    {
      //#3 Equipement PM without References in ListeEquipement
      Equipement eqptPM_SansReferenceBoitier = new Equipement(TypeIdentifiant.PM.name());
      eqptPM_SansReferenceBoitier.setReferencePmBytel("PM2"); //$NON-NLS-1$
      listeEquipement.add(eqptPM_SansReferenceBoitier);
      EasyMock.expect(_resMock.pmCompositeModifierSurchargePriseClientPM(__traceability, eqptPM_SansReferenceBoitier.getReferencePmBytel(), BlocageEquipementStatut.INACTIF.name(), commentaireBlocage))//
          .andReturn(new ConnectorResponse<Retour, Nothing>(resRetour_p, null));
    }

    BlocageEquipement blocageEquipementMock = new BlocageEquipement(idBlocagePriseClients_p, "statut", new HashSet<>(), listeEquipement); //$NON-NLS-1$
    ConnectorResponse<Retour, BlocageEquipement> rexResponseLireUn = new ConnectorResponse<Retour, BlocageEquipement>(RetourFactory.createOkRetour(), blocageEquipementMock);
    ConnectorResponse<Retour, Nothing> rexResponseSupprimer = new ConnectorResponse<Retour, Nothing>(RetourFactory.createOkRetour(), null);

    EasyMock.expect(_rexMock.blocageEquipementLireUn(__traceability, idBlocagePriseClients_p)).andReturn(rexResponseLireUn);
    EasyMock.expect(_rexMock.blocageEquipementSupprimer(__traceability, idBlocagePriseClients_p)).andReturn(rexResponseSupprimer);

  }
}
