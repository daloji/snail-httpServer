/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.tesla.processes.PE0341;

import java.io.File;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.ws.rs.core.MediaType;

import org.easymock.EasyMock;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockNice;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PowerMockListener;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.testlisteners.FieldDefaulter;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.modules.junit4.PowerMockRunnerDelegate;
import org.springframework.test.context.ContextConfiguration;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.data.exchange.generated.RavelRequest.RequestHeader;
import com.bytel.ravel.common.datetime.DateTimeManager;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.test.podam.PodamBytelJUnit4ClassRunner;
import com.bytel.ravel.common.utils.Pair;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.RetourFactoryForTU;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.net.http.HttpConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.ProcessManager;
import com.bytel.ravel.services.utils.Test_Consts;
import com.bytel.spirit.common.activities.shared.BL5400_DecoderSlid;
import com.bytel.spirit.common.activities.shared.BL5400_DecoderSlid.BL5400_DecoderSlidBuilder;
import com.bytel.spirit.common.activities.shared.BL800_ObtenirSequence;
import com.bytel.spirit.common.activities.shared.BL800_ObtenirSequence.BL800_ObtenirSequenceBuilder;
import com.bytel.spirit.common.activities.shared.structs.BL5400_Return;
import com.bytel.spirit.common.activities.shared.structs.UniqueIdConstant;
import com.bytel.spirit.common.connectors.rex.REXProxy;
import com.bytel.spirit.common.shared.functional.types.json.RavelJsonTools;
import com.bytel.spirit.common.shared.functional.types.json.notification.AbstractNotificationReseau;
import com.bytel.spirit.common.shared.functional.types.json.notification.NotificationReseauONTInconnuJSON;
import com.bytel.spirit.common.shared.functional.types.json.notification.NotificationReseauRecommandationTvJSON;
import com.bytel.spirit.common.shared.functional.types.json.notification.NotificationReseauTypeEvenement;
import com.bytel.spirit.common.shared.functional.types.json.notification.structs.DonneesOntInconnu;
import com.bytel.spirit.common.shared.functional.types.json.notification.structs.Pfi;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.error.ReponseErreur;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.rex.NotificationReseauStatut;
import com.bytel.spirit.common.shared.saab.rex.NotificationReseauType;
import com.bytel.spirit.common.shared.saab.rex.request.UpdateNotificationReseauStatutRequest;
import com.bytel.spirit.tesla.activities.PE0341.PE0341_BL500_TraiterNotificationReseau;
import com.bytel.spirit.tesla.activities.PE0341.PE0341_BL500_TraiterNotificationReseau.PE0341_BL500_TraiterNotificationReseauBuilder;
import com.bytel.spirit.tesla.activities.PE0341.structs.TraiterNotificationReturn;
import com.bytel.spirit.tesla.processes.PE0341.sti.PE0341_NotificationReseauPut;
import com.bytel.spirit.tesla.processes.PE0341.sti.PE0341_NotificationReseauSTI;
import com.google.gson.Gson;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author aazzouzi
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PowerMockListener(FieldDefaulter.class)
@PowerMockRunnerDelegate(PodamBytelJUnit4ClassRunner.class)
@ContextConfiguration("classpath:BeansProcessTestMocks.xml")
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
@PrepareForTest({ PE0341_NotificationReseau.class, BL800_ObtenirSequence.class, REXProxy.class, BL800_ObtenirSequenceBuilder.class, BL5400_DecoderSlid.class, BL5400_DecoderSlidBuilder.class, PE0341_BL500_TraiterNotificationReseau.class, PE0341_BL500_TraiterNotificationReseauBuilder.class })
public class PE0341_NotificationReseauTest
{
  /**
   *
   */
  private static final String LOCATION_HEADER_URL_PARAM_VALUE = "https://spirittb3-services:8443/reconciliations-commerciales/"; //$NON-NLS-1$

  /**
   *
   */
  private static final String ID_NOTIFICATION_RESEAU = "ID_NOTIFICATION_RESEAU"; //$NON-NLS-1$

  /**
   *
   */
  private static final String NOM_OLT = "nomOLT"; //$NON-NLS-1$

  /**
   *
   */
  private static final String SLID = "slid"; //$NON-NLS-1$

  /**
   * locationHeaderUrl
   */
  private static final String LOCATION_HEADER_URL_PARAM = "locationHeaderUrl"; //$NON-NLS-1$

  /**
   * FILE_PATH
   */
  private static final String PARAM_FILE_PATH = "FILE_PATH"; //$NON-NLS-1$

  /**
   * The default process name.
   */
  public static final String DEFAULT_PROCESSNAME = "PE0341_NotificationReseau"; //$NON-NLS-1$

  /**
   * bean Factory generation
   */
  private static PodamFactory __podam = new PodamFactoryImpl();

  /**
   * Initialize before all tests
   *
   * @throws Exception
   *           On errors Exception to be thrown in case of failure
   */
  @BeforeClass
  public static void setUpBeforeClass() throws Exception
  {
    __podam.getStrategy().setMemoization(false);
    __podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());
  }

  /**
   * Mock de {@REXProxy}
   */
  @MockStrict
  protected REXProxy _rexProxyMock;

  /**
   * Mock de {PE0341_BL500_TraiterNotificationReseau}
   */
  @MockStrict
  protected PE0341_BL500_TraiterNotificationReseau _pe0341_BL500_TraiterNotificationReseau;

  /**
   * Mock de {PE0341_BL500_TraiterNotificationReseauBuilder}
   */
  @MockStrict
  protected PE0341_BL500_TraiterNotificationReseauBuilder _pe0341_BL500_TraiterNotificationReseauBuilder;

  /**
   * Mock de {BL5400_DecoderSlid}
   */
  @MockStrict
  protected BL5400_DecoderSlid _bl5400Mock;

  /**
   * Mock de {BL5400_DecoderSlidBuilder}
   */
  @MockStrict
  protected BL5400_DecoderSlidBuilder _bl5400BuilderMock;

  /**
   * Mock de {@BL800_ObtenirSequence}
   */
  @MockStrict
  protected BL800_ObtenirSequence _bl800Mock;

  /**
   * Mock de {@BL800_ObtenirSequenceBuilder}
   */
  @MockNice
  protected BL800_ObtenirSequenceBuilder _bl800BuilderMock;

  /**
   * Instance to evaluate
   */
  private PE0341_NotificationReseau _processInstance;

  /**
   * Tracabilite
   */
  Tracabilite _tracabilite;

  //  /**
  //   * <b>Cas de test:</b> When typeEvenement is THE_GPON_ONT_IS_DISCOVERED_BY_OLT AND REX.notificationReseauCreer returns
  //   * NOK<br/>
  //   * <b>Entrées:</b> input param null or empty<br/>
  //   * <b>Attendu:</b> ENTREE_INCORRECTE<br/>
  //   *
  //   * @throws Throwable
  //   *           on errors
  //   */
  //  @Test
  //  public void PE0341_NotificationReseau_KO_012() throws Throwable
  //  {
  //    String typeEvenement = NotificationReseauTypeEvenement.THE_GPON_ONT_IS_DISCOVERED_BY_OLT.getDisplayName();
  //    DonneesOntInconnu donneesOntInconnu = new DonneesOntInconnu("nomOlt", 2, 80, "slid"); //$NON-NLS-1$ //$NON-NLS-2$ //;
  //
  //    PE0341_NotificationReseauSTI notificationReseauSti = new PE0341_NotificationReseauSTI(typeEvenement, donneesOntInconnu, null);
  //    Request request = prepareRequest(_tracabilite, HttpConstants.POST_METHOD, notificationReseauSti);
  //
  //    String expectedNotificationId = "notificationId"; //$NON-NLS-1$
  //    String typeNotificationReseau = "NEW_ONT_DISCOVERED_HUAWEI_JSON";
  //    String statut = "";//NotificationReseauStatut.INITIE.name();
  //    Map<String, String> headers = new HashMap<>();
  //    headers.put(IHttpHeadersConsts.X_REQUEST_ID, _tracabilite.getIdCorrelationByTel());
  //    headers.put(IHttpHeadersConsts.X_PROCESS, DEFAULT_PROCESSNAME);
  //    headers.put(IHttpHeadersConsts.X_SOURCE, "X_Source"); //$NON-NLS-1$
  //
  //    NotificationONTInconnuJSONBody body = new NotificationONTInconnuJSONBody(notificationReseauSti.getTypeEvenement(), notificationReseauSti.getDonneeOntInconnu());
  //    // NotificationONTInconnuJSON donneesNotificationReseau = new NotificationONTInconnuJSON(null, headers, body);
  //
  //    NotificationReseauONTInconnuJSON notificationReseauRex = new NotificationReseauONTInconnuJSON();
  //    notificationReseauRex.setIdNotificationReseau(expectedNotificationId);
  //    notificationReseauRex.setTypeNotificationReseau(typeNotificationReseau);
  //    notificationReseauRex.setStatut(statut);
  //    //  notificationReseauRex.setNotificationONTInconnuJSON(donneesNotificationReseau);
  //    notificationReseauRex.setDateReception(LocalDateTime.now());
  //
  //    ConnectorResponse<Retour, Nothing> rexNokRetour = new ConnectorResponse<Retour, Nothing>(RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegConsts.ERREUR_TECHNIQUE, "libelle erreur technique"), null); //$NON-NLS-1$
  //
  //    PowerMock.expectNew(BL800_ObtenirSequenceBuilder.class).andReturn(_bl800BuilderMock);
  //    EasyMock.expect(_bl800BuilderMock.tracabilite(EasyMock.anyObject())).andReturn(_bl800BuilderMock);
  //    EasyMock.expect(_bl800BuilderMock.code(UniqueIdConstant.ID_NOTIFICATION_RESEAU)).andReturn(_bl800BuilderMock);
  //    EasyMock.expect(_bl800BuilderMock.build()).andReturn(_bl800Mock);
  //    EasyMock.expect(_bl800Mock.execute(EasyMock.anyObject())).andReturn(expectedNotificationId);
  //
  //    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxyMock);
  //    EasyMock.expect(_rexProxyMock.notificationReseauCreer(EasyMock.anyObject(), EasyMock.anyObject())).andReturn(rexNokRetour);
  //
  //    PowerMock.replayAll();
  //    Response response = executeProcess(request, DEFAULT_PROCESSNAME);
  //    PowerMock.verifyAll();
  //
  //    String resp = response.getGenericResponse().getResult();
  //    ReponseErreur reponseactual = new Gson().fromJson(resp, ReponseErreur.class);
  //
  //    Assert.assertEquals(ErrorCode.KO_00500, response.getErrorCode());
  //    Assert.assertEquals(rexNokRetour.getResult().getLibelle(), reponseactual.getErrorDescription());
  //    Assert.assertEquals(IMegConsts.ERREUR_TECHNIQUE, reponseactual.getError());
  //  }
  //
  //  /**
  //   * <b>Cas de test:</b> When typeEvenement is NEW_ONT_DISCOVERED AND REX.notificationReseauCreer returns NOK<br/>
  //   * <b>Entrées:</b> input param null or empty<br/>
  //   * <b>Attendu:</b> ENTREE_INCORRECTE<br/>
  //   *
  //   * @throws Throwable
  //   *           on errors
  //   */
  //  @Test
  //  public void PE0341_NotificationReseau_KO_013() throws Throwable
  //  {
  //    String typeEvenement = NotificationReseauTypeEvenement.NEW_ONT_DISCOVERED.getDisplayName();
  //    DonneesOntInconnu donneesOntInconnu = new DonneesOntInconnu("nomOlt", 2, 80, "slid"); //$NON-NLS-1$ //$NON-NLS-2$ //;
  //
  //    PE0341_NotificationReseauSTI notificationReseauSti = new PE0341_NotificationReseauSTI(typeEvenement, donneesOntInconnu, null);
  //    Request request = prepareRequest(_tracabilite, HttpConstants.POST_METHOD, notificationReseauSti);
  //
  //    String expectedNotificationId = "notificationId"; //$NON-NLS-1$
  //    String typeNotificationReseau = "NEW_ONT_DISCOVERED_HUAWEI_JSON";
  //    String statut = "";//NotificationReseauStatut.INITIE.name();
  //    Map<String, String> headers = new HashMap<>();
  //    headers.put(IHttpHeadersConsts.X_REQUEST_ID, _tracabilite.getIdCorrelationByTel());
  //    headers.put(IHttpHeadersConsts.X_PROCESS, DEFAULT_PROCESSNAME);
  //    headers.put(IHttpHeadersConsts.X_SOURCE, "X_Source"); //$NON-NLS-1$
  //
  //    NotificationONTInconnuJSONBody body = new NotificationONTInconnuJSONBody(notificationReseauSti.getTypeEvenement(), notificationReseauSti.getDonneeOntInconnu());
  //    //    NotificationONTInconnuJSON donneesNotificationReseau = new NotificationONTInconnuJSON(null, headers, body);
  //
  //    NotificationReseauONTInconnuJSON notificationReseauRex = new NotificationReseauONTInconnuJSON();
  //    notificationReseauRex.setIdNotificationReseau(expectedNotificationId);
  //    notificationReseauRex.setTypeNotificationReseau(typeNotificationReseau);
  //    notificationReseauRex.setStatut(statut);
  //    //   notificationReseauRex.setNotificationONTInconnuJSON(donneesNotificationReseau);
  //    notificationReseauRex.setDateReception(LocalDateTime.now());
  //
  //    ConnectorResponse<Retour, Nothing> rexNokRetour = new ConnectorResponse<Retour, Nothing>(RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegConsts.ERREUR_TECHNIQUE, "libelle erreur technique"), null); //$NON-NLS-1$
  //
  //    PowerMock.expectNew(BL800_ObtenirSequenceBuilder.class).andReturn(_bl800BuilderMock);
  //    EasyMock.expect(_bl800BuilderMock.tracabilite(EasyMock.anyObject())).andReturn(_bl800BuilderMock);
  //    EasyMock.expect(_bl800BuilderMock.code(UniqueIdConstant.ID_NOTIFICATION_RESEAU)).andReturn(_bl800BuilderMock);
  //    EasyMock.expect(_bl800BuilderMock.build()).andReturn(_bl800Mock);
  //    EasyMock.expect(_bl800Mock.execute(EasyMock.anyObject())).andReturn(expectedNotificationId);
  //
  //    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxyMock);
  //    EasyMock.expect(_rexProxyMock.notificationReseauCreer(EasyMock.anyObject(), EasyMock.anyObject())).andReturn(rexNokRetour);
  //
  //    PowerMock.replayAll();
  //    Response response = executeProcess(request, DEFAULT_PROCESSNAME);
  //    PowerMock.verifyAll();
  //
  //    String resp = response.getGenericResponse().getResult();
  //    ReponseErreur reponseactual = new Gson().fromJson(resp, ReponseErreur.class);
  //
  //    Assert.assertEquals(ErrorCode.KO_00500, response.getErrorCode());
  //    Assert.assertEquals(rexNokRetour.getResult().getLibelle(), reponseactual.getErrorDescription());
  //    Assert.assertEquals(IMegConsts.ERREUR_TECHNIQUE, reponseactual.getError());
  //  }
  //
  //  /**
  //   * <b>Cas de test:</b> When typeEvenement is NEW_ONT_DISCOVERED AND REX.notificationReseauCreer returns OK, BL5400
  //   * returns a ResponseError with an OK retour for process, notificationReseauModifierStatut returns NOK<br/>
  //   * <b>Entrées:</b> input param null or empty<br/>
  //   * <b>Attendu:</b> ENTREE_INCORRECTE<br/>
  //   *
  //   * @throws Throwable
  //   *           on errors
  //   */
  //  @Test
  //  public void PE0341_NotificationReseau_KO_014() throws Throwable
  //  {
  //    String typeEvenement = NotificationReseauTypeEvenement.NEW_ONT_DISCOVERED.getDisplayName();
  //    DonneesOntInconnu donneesOntInconnu = new DonneesOntInconnu("nomOlt", 2, 80, "slid"); //$NON-NLS-1$ //$NON-NLS-2$ //;
  //
  //    PE0341_NotificationReseauSTI notificationReseauSti = new PE0341_NotificationReseauSTI(typeEvenement, donneesOntInconnu, null);
  //    Request request = prepareRequest(_tracabilite, HttpConstants.POST_METHOD, notificationReseauSti);
  //
  //    String expectedNotificationId = "notificationId"; //$NON-NLS-1$
  //    String typeNotificationReseau = "NEW_ONT_DISCOVERED_HUAWEI_JSON";
  //    String statut = "";//NotificationReseauStatut.INITIE.name();
  //    Map<String, String> headers = new HashMap<>();
  //    headers.put(IHttpHeadersConsts.X_REQUEST_ID, _tracabilite.getIdCorrelationByTel());
  //    headers.put(IHttpHeadersConsts.X_PROCESS, DEFAULT_PROCESSNAME);
  //    headers.put(IHttpHeadersConsts.X_SOURCE, "X_Source"); //$NON-NLS-1$
  //
  //    NotificationONTInconnuJSONBody body = new NotificationONTInconnuJSONBody(notificationReseauSti.getTypeEvenement(), notificationReseauSti.getDonneeOntInconnu());
  //    //    NotificationONTInconnuJSON donneesNotificationReseau = new NotificationONTInconnuJSON(null, headers, body);
  //
  //    NotificationReseauONTInconnuJSON notificationReseauRex = new NotificationReseauONTInconnuJSON();
  //    notificationReseauRex.setIdNotificationReseau(expectedNotificationId);
  //    notificationReseauRex.setTypeNotificationReseau(typeNotificationReseau);
  //    notificationReseauRex.setStatut(statut);
  //    //   notificationReseauRex.setNotificationONTInconnuJSON(donneesNotificationReseau);
  //    notificationReseauRex.setDateReception(LocalDateTime.now());
  //
  //    ConnectorResponse<Retour, Nothing> rexOkRetour = new ConnectorResponse<Retour, Nothing>(RetourFactoryForTU.createOkRetour(), null);
  //    ReponseErreur resp5400 = new ReponseErreur();
  //    resp5400.setError(IMegSpiritConsts.ACCES_REFUSE);
  //
  //    Retour retourBl5400KO = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, ""); //actually STARKConnector returns this Retour //$NON-NLS-1$
  //
  //    PowerMock.expectNew(BL800_ObtenirSequenceBuilder.class).andReturn(_bl800BuilderMock);
  //    EasyMock.expect(_bl800BuilderMock.tracabilite(EasyMock.anyObject())).andReturn(_bl800BuilderMock);
  //    EasyMock.expect(_bl800BuilderMock.code(UniqueIdConstant.ID_NOTIFICATION_RESEAU)).andReturn(_bl800BuilderMock);
  //    EasyMock.expect(_bl800BuilderMock.build()).andReturn(_bl800Mock);
  //    EasyMock.expect(_bl800Mock.execute(EasyMock.anyObject())).andReturn(expectedNotificationId);
  //
  //    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxyMock);
  //    EasyMock.expect(_rexProxyMock.notificationReseauCreer(EasyMock.anyObject(), EasyMock.anyObject())).andReturn(rexOkRetour);
  //
  //    PowerMock.expectNew(BL5400_DecoderSlidBuilder.class).andReturn(_bl5400BuilderMock);
  //    EasyMock.expect(_bl5400BuilderMock.tracabilite(EasyMock.anyObject())).andReturn(_bl5400BuilderMock);
  //    //    EasyMock.expect(_bl5400BuilderMock.idNotificationReseauREX(EasyMock.anyObject())).andReturn(_bl5400BuilderMock);
  //    //    EasyMock.expect(_bl5400BuilderMock.typeNotificationReseau(EasyMock.anyObject())).andReturn(_bl5400BuilderMock);
  //    EasyMock.expect(_bl5400BuilderMock.build()).andReturn(_bl5400Mock);
  //    //    EasyMock.expect(_bl5400Mock.execute(EasyMock.anyObject())).andReturn(resp5400);
  //    EasyMock.expect(_bl5400Mock.getRetour()).andReturn(retourBl5400KO);
  //
  //    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxyMock);
  //    Retour retourNok = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegConsts.ERREUR_TECHNIQUE, "libelle erreur technique"); //$NON-NLS-1$
  //    ConnectorResponse<Retour, Nothing> respModifierStatut = new ConnectorResponse<>(retourNok, null);
  //    UpdateNotificationReseauStatutRequest updateNotificationReseauStatutRequest = new UpdateNotificationReseauStatutRequest(expectedNotificationId, NotificationReseauStatut.TRAITE_NOK.name());
  //    EasyMock.expect(_rexProxyMock.notificationReseauModifierStatut(EasyMock.anyObject(), EasyMock.eq(updateNotificationReseauStatutRequest))).andReturn(respModifierStatut);
  //
  //    PowerMock.replayAll();
  //    Response response = executeProcess(request, DEFAULT_PROCESSNAME);
  //    PowerMock.verifyAll();
  //
  //    String resp = response.getGenericResponse().getResult();
  //    ReponseErreur reponseactual = new Gson().fromJson(resp, ReponseErreur.class);
  //
  //    Assert.assertEquals(ErrorCode.KO_00503, response.getErrorCode());
  //    Assert.assertEquals(rexOkRetour.getResult().getLibelle(), reponseactual.getErrorDescription());
  //    Assert.assertEquals(IMegSpiritConsts.ACCES_REFUSE, reponseactual.getError());
  //  }
  //
  //  /**
  //   * <b>Cas de test:</b> When typeEvenement is RECOMMANDATION_TV AND REX.notificationReseauCreer returns NOK<br/>
  //   * <b>Entrées:</b> input param null or empty<br/>
  //   * <b>Attendu:</b> ENTREE_INCORRECTE<br/>
  //   *
  //   * @throws Throwable
  //   *           on errors
  //   */
  //  @Test
  //  public void PE0341_NotificationReseau_KO_018() throws Throwable
  //  {
  //    String typeEvenement = NotificationReseauTypeEvenement.RECOMMANDATION_TV.getDisplayName();
  //    DonneesOntInconnu donneesOntInconnu = new DonneesOntInconnu("nomOlt", 2, 80, "slid"); //$NON-NLS-1$ //$NON-NLS-2$ //;
  //    Pfi pfi = new Pfi("BSS_GP", "noCompte1");//$NON-NLS-1$ //$NON-NLS-2$ //
  //
  //    PE0341_NotificationReseauSTI notificationReseauSti = new PE0341_NotificationReseauSTI(typeEvenement, donneesOntInconnu, pfi);
  //    Request request = prepareRequest(_tracabilite, HttpConstants.POST_METHOD, notificationReseauSti);
  //
  //    String expectedNotificationId = "notificationId"; //$NON-NLS-1$
  //    String typeNotificationReseau = "NEW_ONT_DISCOVERED_HUAWEI_JSON";
  //    String statut = "";//NotificationReseauStatut.INITIE.name();
  //    Map<String, String> headers = new HashMap<>();
  //    headers.put(IHttpHeadersConsts.X_REQUEST_ID, _tracabilite.getIdCorrelationByTel());
  //    headers.put(IHttpHeadersConsts.X_PROCESS, DEFAULT_PROCESSNAME);
  //    headers.put(IHttpHeadersConsts.X_SOURCE, "X_Source"); //$NON-NLS-1$
  //
  //    Pfi pfi2 = new Pfi(pfi.getClientOperateur(), pfi.getNoCompte());
  //
  //    NotificationRecommandationTvJSONBody body = new NotificationRecommandationTvJSONBody(notificationReseauSti.getTypeEvenement(), pfi2);
  //    NotificationRecommandationTvJSON donneesNotificationReseau = new NotificationRecommandationTvJSON(null, headers, body);
  //
  //    NotificationReseauRecommandationTvJSON notificationReseauRex = new NotificationReseauRecommandationTvJSON();
  //    notificationReseauRex.setIdNotificationReseau(expectedNotificationId);
  //    notificationReseauRex.setTypeNotificationReseau(typeNotificationReseau);
  //    notificationReseauRex.setStatut(statut);
  //    // notificationReseauRex.setNotificationRecommandationTvJSON(donneesNotificationReseau);
  //    notificationReseauRex.setDateReception(LocalDateTime.now());
  //
  //    ConnectorResponse<Retour, Nothing> rexNokRetour = new ConnectorResponse<Retour, Nothing>(RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegConsts.ERREUR_TECHNIQUE, "libelle erreur technique"), null); //$NON-NLS-1$
  //
  //    PowerMock.expectNew(BL800_ObtenirSequenceBuilder.class).andReturn(_bl800BuilderMock);
  //    EasyMock.expect(_bl800BuilderMock.tracabilite(EasyMock.anyObject())).andReturn(_bl800BuilderMock);
  //    EasyMock.expect(_bl800BuilderMock.code(UniqueIdConstant.ID_NOTIFICATION_RESEAU)).andReturn(_bl800BuilderMock);
  //    EasyMock.expect(_bl800BuilderMock.build()).andReturn(_bl800Mock);
  //    EasyMock.expect(_bl800Mock.execute(EasyMock.anyObject())).andReturn(expectedNotificationId);
  //
  //    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxyMock);
  //    EasyMock.expect(_rexProxyMock.notificationReseauCreer(EasyMock.anyObject(), EasyMock.anyObject())).andReturn(rexNokRetour);
  //
  //    PowerMock.replayAll();
  //    Response response = executeProcess(request, DEFAULT_PROCESSNAME);
  //    PowerMock.verifyAll();
  //
  //    String resp = response.getGenericResponse().getResult();
  //    ReponseErreur reponseactual = new Gson().fromJson(resp, ReponseErreur.class);
  //
  //    Assert.assertEquals(ErrorCode.KO_00500, response.getErrorCode());
  //    Assert.assertEquals(rexNokRetour.getResult().getLibelle(), reponseactual.getErrorDescription());
  //    Assert.assertEquals(IMegConsts.ERREUR_TECHNIQUE, reponseactual.getError());
  //  }
  //
  //  /**
  //   * <b>Cas de test:</b> When typeEvenement is THE_GPON_ONT_IS_DISCOVERED_BY_OLT AND REX.notificationReseauCreer returns
  //   * OK, BL5400 returns null(no error)<br/>
  //   * <b>Entrées:</b> input param null or empty<br/>
  //   * <b>Attendu:</b> ENTREE_INCORRECTE<br/>
  //   *
  //   * @throws Throwable
  //   *           on errors
  //   */
  //  @Test
  //  public void PE0341_NotificationReseau_OK_001() throws Throwable
  //  {
  //    String typeEvenement = NotificationReseauTypeEvenement.THE_GPON_ONT_IS_DISCOVERED_BY_OLT.getDisplayName();
  //    DonneesOntInconnu donneesOntInconnu = new DonneesOntInconnu("nomOlt", 2, 80, "slid"); //$NON-NLS-1$ //$NON-NLS-2$ //;
  //
  //    PE0341_NotificationReseauSTI notificationReseauSti = new PE0341_NotificationReseauSTI(typeEvenement, donneesOntInconnu, null);
  //    notificationReseauSti.setDateReception(LocalDateTime.now());
  //    Request request = prepareRequest(_tracabilite, HttpConstants.POST_METHOD, notificationReseauSti);
  //
  //    String expectedNotificationId = "notificationId"; //$NON-NLS-1$
  //    String typeNotificationReseau = "NEW_ONT_DISCOVERED_HUAWEI_JSON";
  //    String statut = "";//NotificationReseauStatut.INITIE.name();
  //    Map<String, String> headers = new HashMap<>();
  //    headers.put(IHttpHeadersConsts.X_REQUEST_ID, _tracabilite.getIdCorrelationByTel());
  //    headers.put(IHttpHeadersConsts.X_PROCESS, DEFAULT_PROCESSNAME);
  //    headers.put(IHttpHeadersConsts.X_SOURCE, "X_Source"); //$NON-NLS-1$
  //
  //    NotificationONTInconnuJSONBody body = new NotificationONTInconnuJSONBody(notificationReseauSti.getTypeEvenement(), notificationReseauSti.getDonneeOntInconnu());
  //    //    NotificationONTInconnuJSON donneesNotificationReseau = new NotificationONTInconnuJSON(null, headers, body);
  //
  //    NotificationReseauONTInconnuJSON notificationReseauRex = new NotificationReseauONTInconnuJSON();
  //    notificationReseauRex.setIdNotificationReseau(expectedNotificationId);
  //    notificationReseauRex.setTypeNotificationReseau(typeNotificationReseau);
  //    notificationReseauRex.setStatut(statut);
  //    //    notificationReseauRex.setNotificationONTInconnuJSON(donneesNotificationReseau);
  //    notificationReseauRex.setDateReception(LocalDateTime.now());
  //
  //    ConnectorResponse<Retour, Nothing> rexOkRetour = new ConnectorResponse<Retour, Nothing>(RetourFactoryForTU.createOkRetour(), null);
  //
  //    PowerMock.expectNew(BL800_ObtenirSequenceBuilder.class).andReturn(_bl800BuilderMock);
  //    EasyMock.expect(_bl800BuilderMock.tracabilite(EasyMock.anyObject())).andReturn(_bl800BuilderMock);
  //    EasyMock.expect(_bl800BuilderMock.code(UniqueIdConstant.ID_NOTIFICATION_RESEAU)).andReturn(_bl800BuilderMock);
  //    EasyMock.expect(_bl800BuilderMock.build()).andReturn(_bl800Mock);
  //    EasyMock.expect(_bl800Mock.execute(EasyMock.anyObject())).andReturn(expectedNotificationId);
  //
  //    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxyMock);
  //    EasyMock.expect(_rexProxyMock.notificationReseauCreer(EasyMock.anyObject(), EasyMock.anyObject())).andReturn(rexOkRetour);
  //
  //    PowerMock.expectNew(BL5400_DecoderSlidBuilder.class).andReturn(_bl5400BuilderMock);
  //    EasyMock.expect(_bl5400BuilderMock.tracabilite(EasyMock.anyObject())).andReturn(_bl5400BuilderMock);
  //    //    EasyMock.expect(_bl5400BuilderMock.idNotificationReseauREX(EasyMock.anyObject())).andReturn(_bl5400BuilderMock);
  //    //    EasyMock.expect(_bl5400BuilderMock.typeNotificationReseau(EasyMock.anyObject())).andReturn(_bl5400BuilderMock);
  //    EasyMock.expect(_bl5400BuilderMock.build()).andReturn(_bl5400Mock);
  //    EasyMock.expect(_bl5400Mock.execute(EasyMock.anyObject())).andReturn(null);
  //    EasyMock.expect(_bl5400Mock.getRetour()).andReturn(RetourFactoryForTU.createOkRetour());
  //
  //    PowerMock.replayAll();
  //    Response response = executeProcess(request, DEFAULT_PROCESSNAME);
  //    PowerMock.verifyAll();
  //
  //    String resp = response.getGenericResponse().getResult();
  //    ReponseErreur reponseactual = new Gson().fromJson(resp, ReponseErreur.class);
  //
  //    Assert.assertEquals(ErrorCode.OK_00201, response.getErrorCode());
  //    Assert.assertEquals(null, reponseactual);
  //  }
  //
  //  /**
  //   * <b>Cas de test:</b> When typeEvenement is RECOMMANDATION_TV AND REX.notificationReseauCreer returns OK, BL5400
  //   * returns null(no error)<br/>
  //   * <b>Entrées:</b> input param null or empty<br/>
  //   * <b>Attendu:</b> ENTREE_INCORRECTE<br/>
  //   *
  //   * @throws Throwable
  //   *           on errors
  //   */
  //  @Test
  //  public void PE0341_NotificationReseau_OK_002() throws Throwable
  //  {
  //    String typeEvenement = NotificationReseauTypeEvenement.RECOMMANDATION_TV.getDisplayName();
  //    DonneesOntInconnu donneesOntInconnu = new DonneesOntInconnu("nomOlt", 2, 80, "slid"); //$NON-NLS-1$ //$NON-NLS-2$ //;
  //
  //    Pfi pfi = new Pfi("BSS_GP", "noCompte1");//$NON-NLS-1$ //$NON-NLS-2$ //
  //
  //    PE0341_NotificationReseauSTI notificationReseauSti = new PE0341_NotificationReseauSTI(typeEvenement, donneesOntInconnu, pfi);
  //    notificationReseauSti.setDateReception(LocalDateTime.now());
  //    Request request = prepareRequest(_tracabilite, HttpConstants.POST_METHOD, notificationReseauSti);
  //
  //    String expectedNotificationId = "notificationId"; //$NON-NLS-1$
  //    String typeNotificationReseau = "NEW_ONT_DISCOVERED_HUAWEI_JSON";
  //    String statut = "";//NotificationReseauStatut.INITIE.name();
  //    Map<String, String> headers = new HashMap<>();
  //    headers.put(IHttpHeadersConsts.X_REQUEST_ID, _tracabilite.getIdCorrelationByTel());
  //    headers.put(IHttpHeadersConsts.X_PROCESS, DEFAULT_PROCESSNAME);
  //    headers.put(IHttpHeadersConsts.X_SOURCE, "X_Source"); //$NON-NLS-1$
  //
  //    Pfi pfi2 = new Pfi(pfi.getClientOperateur(), pfi.getNoCompte());
  //
  //    NotificationRecommandationTvJSONBody body = new NotificationRecommandationTvJSONBody(notificationReseauSti.getTypeEvenement(), pfi2);
  //    NotificationRecommandationTvJSON donneesNotificationReseau = new NotificationRecommandationTvJSON(null, headers, body);
  //
  //    NotificationReseauRecommandationTvJSON notificationReseauRex = new NotificationReseauRecommandationTvJSON();
  //    notificationReseauRex.setIdNotificationReseau(expectedNotificationId);
  //    notificationReseauRex.setTypeNotificationReseau(typeNotificationReseau);
  //    notificationReseauRex.setStatut(statut);
  //    //    notificationReseauRex.setNotificationRecommandationTvJSON(donneesNotificationReseau);
  //    notificationReseauRex.setDateReception(LocalDateTime.now());
  //
  //    ConnectorResponse<Retour, Nothing> rexOkRetour = new ConnectorResponse<Retour, Nothing>(RetourFactoryForTU.createOkRetour(), null);
  //
  //    PowerMock.expectNew(BL800_ObtenirSequenceBuilder.class).andReturn(_bl800BuilderMock);
  //    EasyMock.expect(_bl800BuilderMock.tracabilite(EasyMock.anyObject())).andReturn(_bl800BuilderMock);
  //    EasyMock.expect(_bl800BuilderMock.code(UniqueIdConstant.ID_NOTIFICATION_RESEAU)).andReturn(_bl800BuilderMock);
  //    EasyMock.expect(_bl800BuilderMock.build()).andReturn(_bl800Mock);
  //    EasyMock.expect(_bl800Mock.execute(EasyMock.anyObject())).andReturn(expectedNotificationId);
  //
  //    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxyMock);
  //    EasyMock.expect(_rexProxyMock.notificationReseauCreer(EasyMock.anyObject(), EasyMock.anyObject())).andReturn(rexOkRetour);
  //
  //    PowerMock.expectNew(BL5400_DecoderSlidBuilder.class).andReturn(_bl5400BuilderMock);
  //    EasyMock.expect(_bl5400BuilderMock.tracabilite(EasyMock.anyObject())).andReturn(_bl5400BuilderMock);
  //    //    EasyMock.expect(_bl5400BuilderMock.idNotificationReseauREX(EasyMock.anyObject())).andReturn(_bl5400BuilderMock);
  //    //    EasyMock.expect(_bl5400BuilderMock.typeNotificationReseau(EasyMock.anyObject())).andReturn(_bl5400BuilderMock);
  //    EasyMock.expect(_bl5400BuilderMock.build()).andReturn(_bl5400Mock);
  //    EasyMock.expect(_bl5400Mock.execute(EasyMock.anyObject())).andReturn(null);
  //    EasyMock.expect(_bl5400Mock.getRetour()).andReturn(RetourFactoryForTU.createOkRetour());
  //
  //    PowerMock.replayAll();
  //    Response response = executeProcess(request, DEFAULT_PROCESSNAME);
  //    PowerMock.verifyAll();
  //
  //    String resp = response.getGenericResponse().getResult();
  //    ReponseErreur reponseactual = new Gson().fromJson(resp, ReponseErreur.class);
  //
  //    Assert.assertEquals(ErrorCode.OK_00201, response.getErrorCode());
  //    Assert.assertEquals(null, reponseactual);
  //  }

  /**
   * Le Return de la BL002 est ResponseErreu != null
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0341_NotificationReseau_continueProcess_POST_KO_001() throws Throwable
  {

    Pair<Retour, ReponseErreur> bl002Return = createBL002Retour(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ENTREE_INCORRECTE, "The body request is empty.")); //$NON-NLS-1$
    _processInstance.getProcessContext().setState(PE0341_NotificationReseau.State.PE0341_CONTINUE);
    _processInstance.getProcessContext().setBl002Return(bl002Return);
    _processInstance.getProcessContext().setProcessRetour(bl002Return._first);

    _processInstance.continuePostProcess(_tracabilite);

    Assert.assertEquals(PE0341_NotificationReseau.State.PE0341_END, _processInstance.getProcessContext().getState());
    Assert.assertEquals(bl002Return._first, _processInstance.getRetour());

  }

  /**
   * Le Return de la BL002 est ResponseErreu == null et REX return NOK
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0341_NotificationReseau_continueProcess_POST_KO_002() throws Throwable
  {

    String typeEvenement = NotificationReseauTypeEvenement.THE_GPON_ONT_IS_DISCOVERED_BY_OLT.getDisplayName();
    DonneesOntInconnu donneesOntInconnu = new DonneesOntInconnu(NOM_OLT, 2, 80, SLID);
    PE0341_NotificationReseauSTI notificationReseauSti = new PE0341_NotificationReseauSTI(typeEvenement, donneesOntInconnu, null);

    Pair<Retour, ReponseErreur> bl002Return = createBL002Retour(RetourFactory.createOkRetour());
    bl002Return._second = null;
    _processInstance.getProcessContext().setState(PE0341_NotificationReseau.State.PE0341_CONTINUE);
    _processInstance.getProcessContext().setBl002Return(bl002Return);
    _processInstance.getProcessContext().setProcessRetour(bl002Return._first);
    _processInstance.getProcessContext().setAbstractNotificationReseau(createNotificationReseuBySTI(notificationReseauSti, ID_NOTIFICATION_RESEAU));

    Retour retourRex = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.SERVICE_INDISPONIBLE, "REX service unavaiable.");//$NON-NLS-1$
    ConnectorResponse<Retour, Nothing> responseRex = new ConnectorResponse<>(retourRex, null);

    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxyMock);
    EasyMock.expect(_rexProxyMock.notificationReseauModifierStatut(EasyMock.anyObject(), EasyMock.anyObject())).andReturn(responseRex);

    PowerMock.replayAll();
    _processInstance.continuePostProcess(_tracabilite);
    PowerMock.verifyAll();

    Assert.assertEquals(PE0341_NotificationReseau.State.PE0341_END, _processInstance.getProcessContext().getState());
    Assert.assertEquals(retourRex, _processInstance.getRetour());

  }

  /**
   * Le return de la BL002 est ResponseErreu == null, REX return OK et BL500 return KO avec compenserTraitment true
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0341_NotificationReseau_continueProcess_POST_KO_003() throws Throwable
  {

    String typeEvenement = NotificationReseauTypeEvenement.THE_GPON_ONT_IS_DISCOVERED_BY_OLT.getDisplayName();
    DonneesOntInconnu donneesOntInconnu = new DonneesOntInconnu(NOM_OLT, 2, 80, SLID);
    PE0341_NotificationReseauSTI notificationReseauSti = new PE0341_NotificationReseauSTI(typeEvenement, donneesOntInconnu, null);

    Pair<Retour, ReponseErreur> bl002Return = createBL002Retour(RetourFactory.createOkRetour());
    bl002Return._second = null;
    _processInstance.getProcessContext().setState(PE0341_NotificationReseau.State.PE0341_CONTINUE);
    _processInstance.getProcessContext().setBl002Return(bl002Return);
    _processInstance.getProcessContext().setProcessRetour(bl002Return._first);
    _processInstance.getProcessContext().setAbstractNotificationReseau(createNotificationReseuBySTI(notificationReseauSti, ID_NOTIFICATION_RESEAU));

    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxyMock);
    EasyMock.expect(_rexProxyMock.notificationReseauModifierStatut(EasyMock.anyObject(), EasyMock.anyObject())).andReturn(new ConnectorResponse<>(RetourFactory.createOkRetour(), null));

    Retour bl500Retour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.SERVICE_INDISPONIBLE, "Service unavaiable."); //$NON-NLS-1$
    mockBL500(bl500Retour, true, 1, 20);

    PowerMock.replayAll();
    _processInstance.continuePostProcess(_tracabilite);
    PowerMock.verifyAll();

    Assert.assertEquals(PE0341_NotificationReseau.State.PE0341_BL500, _processInstance.getProcessContext().getState());
    Assert.assertEquals(bl500Retour, _processInstance.getRetour());
    Assert.assertEquals(new Integer(1), _processInstance.getProcessContext().getNombreCompensation());
    Assert.assertEquals(Duration.ofMillis(20L), _processInstance.getSleepTime());

  }

  /**
   * Le return de la BL002 est ResponseErreu == null, REX return OK et BL500 return KO avec compenserTraitment false et
   * REX return KO
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0341_NotificationReseau_continueProcess_POST_KO_004() throws Throwable
  {

    String typeEvenement = NotificationReseauTypeEvenement.THE_GPON_ONT_IS_DISCOVERED_BY_OLT.getDisplayName();
    DonneesOntInconnu donneesOntInconnu = new DonneesOntInconnu(NOM_OLT, 2, 80, SLID);
    PE0341_NotificationReseauSTI notificationReseauSti = new PE0341_NotificationReseauSTI(typeEvenement, donneesOntInconnu, null);

    Pair<Retour, ReponseErreur> bl002Return = createBL002Retour(RetourFactory.createOkRetour());
    bl002Return._second = null;
    _processInstance.getProcessContext().setState(PE0341_NotificationReseau.State.PE0341_CONTINUE);
    _processInstance.getProcessContext().setBl002Return(bl002Return);
    _processInstance.getProcessContext().setProcessRetour(bl002Return._first);
    _processInstance.getProcessContext().setAbstractNotificationReseau(createNotificationReseuBySTI(notificationReseauSti, ID_NOTIFICATION_RESEAU));

    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxyMock).times(2);
    EasyMock.expect(_rexProxyMock.notificationReseauModifierStatut(EasyMock.anyObject(), EasyMock.anyObject())).andReturn(new ConnectorResponse<>(RetourFactory.createOkRetour(), null)).once();

    Retour bl500Retour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.SERVICE_INDISPONIBLE, "Service unavaiable."); //$NON-NLS-1$
    mockBL500(bl500Retour, false, 2, 20);

    Retour retourRex = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.SERVICE_INDISPONIBLE, "Service unavaiable."); //$NON-NLS-1$
    EasyMock.expect(_rexProxyMock.notificationReseauModifierStatut(EasyMock.anyObject(), EasyMock.anyObject())).andReturn(new ConnectorResponse<>(retourRex, null)).once();

    PowerMock.replayAll();
    _processInstance.continuePostProcess(_tracabilite);
    PowerMock.verifyAll();

    Assert.assertEquals(PE0341_NotificationReseau.State.PE0341_END, _processInstance.getProcessContext().getState());
    Assert.assertEquals(retourRex, _processInstance.getRetour());

  }

  /**
   * Le return de la BL002 est ResponseErreu == null, REX return OK et BL500 throw exception et REX return KO
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0341_NotificationReseau_continueProcess_POST_KO_005() throws Throwable
  {

    String typeEvenement = NotificationReseauTypeEvenement.THE_GPON_ONT_IS_DISCOVERED_BY_OLT.getDisplayName();
    DonneesOntInconnu donneesOntInconnu = new DonneesOntInconnu(NOM_OLT, 2, 80, SLID);
    PE0341_NotificationReseauSTI notificationReseauSti = new PE0341_NotificationReseauSTI(typeEvenement, donneesOntInconnu, null);

    Pair<Retour, ReponseErreur> bl002Return = createBL002Retour(RetourFactory.createOkRetour());
    bl002Return._second = null;
    _processInstance.getProcessContext().setState(PE0341_NotificationReseau.State.PE0341_CONTINUE);
    _processInstance.getProcessContext().setBl002Return(bl002Return);
    _processInstance.getProcessContext().setProcessRetour(bl002Return._first);
    _processInstance.getProcessContext().setAbstractNotificationReseau(createNotificationReseuBySTI(notificationReseauSti, ID_NOTIFICATION_RESEAU));

    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxyMock).times(2);
    EasyMock.expect(_rexProxyMock.notificationReseauModifierStatut(EasyMock.anyObject(), EasyMock.anyObject())).andReturn(new ConnectorResponse<>(RetourFactory.createOkRetour(), null)).once();

    mockBL500(null, false, 2, 20, true);

    Retour retourRex = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.SERVICE_INDISPONIBLE, "Service unavaiable."); //$NON-NLS-1$
    EasyMock.expect(_rexProxyMock.notificationReseauModifierStatut(EasyMock.anyObject(), EasyMock.anyObject())).andReturn(new ConnectorResponse<>(retourRex, null)).once();

    PowerMock.replayAll();
    _processInstance.continuePostProcess(_tracabilite);
    PowerMock.verifyAll();

    Assert.assertEquals(PE0341_NotificationReseau.State.PE0341_END, _processInstance.getProcessContext().getState());
    Assert.assertEquals(retourRex, _processInstance.getRetour());

  }

  /**
   * Le return de la BL002 est ResponseErreu == null, REX return OK , BL500 return OK et REX return OK
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0341_NotificationReseau_continueProcess_POST_OK_001() throws Throwable
  {

    String typeEvenement = NotificationReseauTypeEvenement.THE_GPON_ONT_IS_DISCOVERED_BY_OLT.getDisplayName();
    DonneesOntInconnu donneesOntInconnu = new DonneesOntInconnu(NOM_OLT, 2, 80, SLID);
    PE0341_NotificationReseauSTI notificationReseauSti = new PE0341_NotificationReseauSTI(typeEvenement, donneesOntInconnu, null);

    Pair<Retour, ReponseErreur> bl002Return = createBL002Retour(RetourFactory.createOkRetour());
    bl002Return._second = null;
    _processInstance.getProcessContext().setState(PE0341_NotificationReseau.State.PE0341_CONTINUE);
    _processInstance.getProcessContext().setBl002Return(bl002Return);
    _processInstance.getProcessContext().setProcessRetour(bl002Return._first);
    _processInstance.getProcessContext().setAbstractNotificationReseau(createNotificationReseuBySTI(notificationReseauSti, ID_NOTIFICATION_RESEAU));

    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxyMock).times(2);
    EasyMock.expect(_rexProxyMock.notificationReseauModifierStatut(EasyMock.anyObject(), EasyMock.anyObject())).andReturn(new ConnectorResponse<>(RetourFactory.createOkRetour(), null)).once();

    mockBL500(null, false, 2, 20, true);

    Retour retourRex = RetourFactory.createOkRetour();
    EasyMock.expect(_rexProxyMock.notificationReseauModifierStatut(EasyMock.anyObject(), EasyMock.anyObject())).andReturn(new ConnectorResponse<>(retourRex, null)).once();

    PowerMock.replayAll();
    _processInstance.continuePostProcess(_tracabilite);
    PowerMock.verifyAll();

    Assert.assertEquals(PE0341_NotificationReseau.State.PE0341_END, _processInstance.getProcessContext().getState());
    Assert.assertEquals(retourRex, _processInstance.getRetour());

  }

  /**
   * Le Return de la BL002 est ResponseErreu != null
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0341_NotificationReseau_continueProcess_PUT_KO_001() throws Throwable
  {

    Pair<Retour, ReponseErreur> bl002Return = createBL002Retour(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ENTREE_INCORRECTE, "The body request is empty.")); //$NON-NLS-1$
    _processInstance.getProcessContext().setState(PE0341_NotificationReseau.State.PE0341_CONTINUE);
    _processInstance.getProcessContext().setBl002Return(bl002Return);
    _processInstance.getProcessContext().setProcessRetour(bl002Return._first);

    _processInstance.continuePutProcess(_tracabilite);

    Assert.assertEquals(PE0341_NotificationReseau.State.PE0341_END, _processInstance.getProcessContext().getState());
    Assert.assertEquals(bl002Return._first, _processInstance.getRetour());

  }

  /**
   * Le Return de la BL002 est ResponseErreu == null et REX return NOK
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0341_NotificationReseau_continueProcess_PUT_KO_002() throws Throwable
  {

    String typeEvenement = NotificationReseauTypeEvenement.THE_GPON_ONT_IS_DISCOVERED_BY_OLT.getDisplayName();
    DonneesOntInconnu donneesOntInconnu = new DonneesOntInconnu(NOM_OLT, 2, 80, SLID);
    PE0341_NotificationReseauSTI notificationReseauSti = new PE0341_NotificationReseauSTI(typeEvenement, donneesOntInconnu, null);

    Pair<Retour, ReponseErreur> bl002Return = createBL002Retour(RetourFactory.createOkRetour());
    bl002Return._second = null;
    _processInstance.getProcessContext().setState(PE0341_NotificationReseau.State.PE0341_CONTINUE);
    _processInstance.getProcessContext().setBl002Return(bl002Return);
    _processInstance.getProcessContext().setProcessRetour(bl002Return._first);
    _processInstance.getProcessContext().setAbstractNotificationReseau(createNotificationReseuBySTI(notificationReseauSti, ID_NOTIFICATION_RESEAU));

    Retour retourRex = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.SERVICE_INDISPONIBLE, "REX service unavaiable.");//$NON-NLS-1$
    ConnectorResponse<Retour, Nothing> responseRex = new ConnectorResponse<>(retourRex, null);

    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxyMock);
    EasyMock.expect(_rexProxyMock.notificationReseauModifierStatut(EasyMock.anyObject(), EasyMock.anyObject())).andReturn(responseRex);

    PowerMock.replayAll();
    _processInstance.continuePutProcess(_tracabilite);
    PowerMock.verifyAll();

    Assert.assertEquals(PE0341_NotificationReseau.State.PE0341_END, _processInstance.getProcessContext().getState());
    Assert.assertEquals(retourRex, _processInstance.getRetour());

  }

  /**
   * Le return de la BL002 est ResponseErreu == null, REX return OK et BL500 return KO avec compenserTraitment true
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0341_NotificationReseau_continueProcess_PUT_KO_003() throws Throwable
  {

    String typeEvenement = NotificationReseauTypeEvenement.THE_GPON_ONT_IS_DISCOVERED_BY_OLT.getDisplayName();
    DonneesOntInconnu donneesOntInconnu = new DonneesOntInconnu(NOM_OLT, 2, 80, SLID);
    PE0341_NotificationReseauSTI notificationReseauSti = new PE0341_NotificationReseauSTI(typeEvenement, donneesOntInconnu, null);

    Pair<Retour, ReponseErreur> bl002Return = createBL002Retour(RetourFactory.createOkRetour());
    bl002Return._second = null;
    _processInstance.getProcessContext().setState(PE0341_NotificationReseau.State.PE0341_CONTINUE);
    _processInstance.getProcessContext().setBl002Return(bl002Return);
    _processInstance.getProcessContext().setProcessRetour(bl002Return._first);
    _processInstance.getProcessContext().setAbstractNotificationReseau(createNotificationReseuBySTI(notificationReseauSti, ID_NOTIFICATION_RESEAU));

    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxyMock);
    EasyMock.expect(_rexProxyMock.notificationReseauModifierStatut(EasyMock.anyObject(), EasyMock.anyObject())).andReturn(new ConnectorResponse<>(RetourFactory.createOkRetour(), null));

    Retour bl500Retour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.SERVICE_INDISPONIBLE, "Service unavaiable."); //$NON-NLS-1$
    mockBL500(bl500Retour, true, 1, 20);

    PowerMock.replayAll();
    _processInstance.continuePutProcess(_tracabilite);
    PowerMock.verifyAll();

    Assert.assertEquals(PE0341_NotificationReseau.State.PE0341_BL500, _processInstance.getProcessContext().getState());
    Assert.assertEquals(bl500Retour, _processInstance.getRetour());
    Assert.assertEquals(new Integer(1), _processInstance.getProcessContext().getNombreCompensation());
    Assert.assertEquals(Duration.ofMillis(20L), _processInstance.getSleepTime());

  }

  /**
   * Le return de la BL002 est ResponseErreu == null, REX return OK et BL500 return KO avec compenserTraitment false et
   * REX return KO
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0341_NotificationReseau_continueProcess_PUT_KO_004() throws Throwable
  {

    String typeEvenement = NotificationReseauTypeEvenement.THE_GPON_ONT_IS_DISCOVERED_BY_OLT.getDisplayName();
    DonneesOntInconnu donneesOntInconnu = new DonneesOntInconnu(NOM_OLT, 2, 80, SLID);
    PE0341_NotificationReseauSTI notificationReseauSti = new PE0341_NotificationReseauSTI(typeEvenement, donneesOntInconnu, null);

    Pair<Retour, ReponseErreur> bl002Return = createBL002Retour(RetourFactory.createOkRetour());
    bl002Return._second = null;
    _processInstance.getProcessContext().setState(PE0341_NotificationReseau.State.PE0341_CONTINUE);
    _processInstance.getProcessContext().setBl002Return(bl002Return);
    _processInstance.getProcessContext().setProcessRetour(bl002Return._first);
    _processInstance.getProcessContext().setAbstractNotificationReseau(createNotificationReseuBySTI(notificationReseauSti, ID_NOTIFICATION_RESEAU));

    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxyMock).times(2);
    EasyMock.expect(_rexProxyMock.notificationReseauModifierStatut(EasyMock.anyObject(), EasyMock.anyObject())).andReturn(new ConnectorResponse<>(RetourFactory.createOkRetour(), null)).once();

    Retour bl500Retour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.SERVICE_INDISPONIBLE, "Service unavaiable."); //$NON-NLS-1$
    mockBL500(bl500Retour, false, 2, 20);

    Retour retourRex = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.SERVICE_INDISPONIBLE, "Service unavaiable."); //$NON-NLS-1$
    EasyMock.expect(_rexProxyMock.notificationReseauModifierStatut(EasyMock.anyObject(), EasyMock.anyObject())).andReturn(new ConnectorResponse<>(retourRex, null)).once();

    PowerMock.replayAll();
    _processInstance.continuePutProcess(_tracabilite);
    PowerMock.verifyAll();

    Assert.assertEquals(PE0341_NotificationReseau.State.PE0341_END, _processInstance.getProcessContext().getState());
    Assert.assertEquals(retourRex, _processInstance.getRetour());

  }

  /**
   * Le return de la BL002 est ResponseErreu == null, REX return OK et BL500 throw exception et REX return KO
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0341_NotificationReseau_continueProcess_PUT_KO_005() throws Throwable
  {

    String typeEvenement = NotificationReseauTypeEvenement.THE_GPON_ONT_IS_DISCOVERED_BY_OLT.getDisplayName();
    DonneesOntInconnu donneesOntInconnu = new DonneesOntInconnu(NOM_OLT, 2, 80, SLID);
    PE0341_NotificationReseauSTI notificationReseauSti = new PE0341_NotificationReseauSTI(typeEvenement, donneesOntInconnu, null);

    Pair<Retour, ReponseErreur> bl002Return = createBL002Retour(RetourFactory.createOkRetour());
    bl002Return._second = null;
    _processInstance.getProcessContext().setState(PE0341_NotificationReseau.State.PE0341_CONTINUE);
    _processInstance.getProcessContext().setBl002Return(bl002Return);
    _processInstance.getProcessContext().setProcessRetour(bl002Return._first);
    _processInstance.getProcessContext().setAbstractNotificationReseau(createNotificationReseuBySTI(notificationReseauSti, ID_NOTIFICATION_RESEAU));

    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxyMock).times(2);
    EasyMock.expect(_rexProxyMock.notificationReseauModifierStatut(EasyMock.anyObject(), EasyMock.anyObject())).andReturn(new ConnectorResponse<>(RetourFactory.createOkRetour(), null)).once();

    mockBL500(null, false, 2, 20, true);

    Retour retourRex = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.SERVICE_INDISPONIBLE, "Service unavaiable."); //$NON-NLS-1$
    EasyMock.expect(_rexProxyMock.notificationReseauModifierStatut(EasyMock.anyObject(), EasyMock.anyObject())).andReturn(new ConnectorResponse<>(retourRex, null)).once();

    PowerMock.replayAll();
    _processInstance.continuePutProcess(_tracabilite);
    PowerMock.verifyAll();

    Assert.assertEquals(PE0341_NotificationReseau.State.PE0341_END, _processInstance.getProcessContext().getState());
    Assert.assertEquals(retourRex, _processInstance.getRetour());

  }

  /**
   * Le return de la BL002 est ResponseErreu == null, REX return OK , BL500 return OK et REX return OK
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0341_NotificationReseau_continueProcess_PUT_OK_001() throws Throwable
  {

    String typeEvenement = NotificationReseauTypeEvenement.THE_GPON_ONT_IS_DISCOVERED_BY_OLT.getDisplayName();
    DonneesOntInconnu donneesOntInconnu = new DonneesOntInconnu(NOM_OLT, 2, 80, SLID);
    PE0341_NotificationReseauSTI notificationReseauSti = new PE0341_NotificationReseauSTI(typeEvenement, donneesOntInconnu, null);

    Pair<Retour, ReponseErreur> bl002Return = createBL002Retour(RetourFactory.createOkRetour());
    bl002Return._second = null;
    _processInstance.getProcessContext().setState(PE0341_NotificationReseau.State.PE0341_CONTINUE);
    _processInstance.getProcessContext().setBl002Return(bl002Return);
    _processInstance.getProcessContext().setProcessRetour(bl002Return._first);
    _processInstance.getProcessContext().setAbstractNotificationReseau(createNotificationReseuBySTI(notificationReseauSti, ID_NOTIFICATION_RESEAU));

    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxyMock).times(2);
    EasyMock.expect(_rexProxyMock.notificationReseauModifierStatut(EasyMock.anyObject(), EasyMock.anyObject())).andReturn(new ConnectorResponse<>(RetourFactory.createOkRetour(), null)).once();

    mockBL500(null, false, 2, 20, true);

    Retour retourRex = RetourFactory.createOkRetour();
    EasyMock.expect(_rexProxyMock.notificationReseauModifierStatut(EasyMock.anyObject(), EasyMock.anyObject())).andReturn(new ConnectorResponse<>(retourRex, null)).once();

    PowerMock.replayAll();
    _processInstance.continuePutProcess(_tracabilite);
    PowerMock.verifyAll();

    Assert.assertEquals(PE0341_NotificationReseau.State.PE0341_END, _processInstance.getProcessContext().getState());
    Assert.assertEquals(retourRex, _processInstance.getRetour());

  }

  /**
   * <b>Cas de test:</b> When headers are not valid<br/>
   * <b>Entrées:</b> Header null or empty<br/>
   * <b>Attendu:</b> ResponseErreur not null<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0341_NotificationReseau_POST_KO_001() throws Throwable
  {

    PE0341_NotificationReseauSTI notificationReseauSti = new PE0341_NotificationReseauSTI(null, null, null);
    List<RequestHeader> headers = addXHeaders(null, null, null, null, null);
    Request request = prepareRequest(HttpConstants.POST_METHOD, notificationReseauSti, headers);

    PowerMock.replayAll();
    Response response = executeStartPostProcess(request, DEFAULT_PROCESSNAME);
    PowerMock.verifyAll();

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = new Gson().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals("Header X-Request-Id null ou vide.", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegSpiritConsts.ENTREE_INCORRECTE, reponseactual.getError());

  }

  /**
   * <b>Cas de test:</b> When headers are not valid<br/>
   * <b>Entrées:</b> Header null or empty<br/>
   * <b>Attendu:</b> ResponseErreur not null<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0341_NotificationReseau_POST_KO_002() throws Throwable
  {
    PE0341_NotificationReseauSTI notificationReseauSti = new PE0341_NotificationReseauSTI(null, null, null);
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", null, null, null, null); //$NON-NLS-1$
    Request request = prepareRequest(HttpConstants.POST_METHOD, notificationReseauSti, headers);

    PowerMock.replayAll();
    Response response = executeStartPostProcess(request, DEFAULT_PROCESSNAME);
    PowerMock.verifyAll();

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = new Gson().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals("Header X-Process null ou vide.", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegSpiritConsts.ENTREE_INCORRECTE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> When headers are not valid<br/>
   * <b>Entrées:</b> Header null or empty<br/>
   * <b>Attendu:</b> ResponseErreur not null<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0341_NotificationReseau_POST_KO_003() throws Throwable
  {
    PE0341_NotificationReseauSTI notificationReseauSti = new PE0341_NotificationReseauSTI(null, null, null);
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", null, "MESSAGE", "ACTION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    Request request = prepareRequest(HttpConstants.POST_METHOD, notificationReseauSti, headers);

    request.setRequestHeader(headers);

    PowerMock.replayAll();
    Response response = executeStartPostProcess(request, DEFAULT_PROCESSNAME);
    PowerMock.verifyAll();

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = new Gson().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals("Header X-Source null ou vide.", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegSpiritConsts.ENTREE_INCORRECTE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> When input params are not valid<br/>
   * <b>Entrées:</b> input param null or empty<br/>
   * <b>Attendu:</b> ENTREE_INCORRECTE<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0341_NotificationReseau_POST_KO_004() throws Throwable
  {
    // notificationReseauSti null
    PE0341_NotificationReseauSTI notificationReseauSti = null;
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
    Request request = prepareRequest(HttpConstants.POST_METHOD, notificationReseauSti, headers);

    PowerMock.replayAll();
    Response response = executeStartPostProcess(request, DEFAULT_PROCESSNAME);
    PowerMock.verifyAll();

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = new Gson().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals("The body request is empty.", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegSpiritConsts.ENTREE_INCORRECTE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> When input params are not valid<br/>
   * <b>Entrées:</b> input param null or empty<br/>
   * <b>Attendu:</b> ENTREE_INCORRECTE<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0341_NotificationReseau_POST_KO_005() throws Throwable
  {
    // typeEvenement null
    String typeEvenement = null;
    DonneesOntInconnu donneesOntInconnu = new DonneesOntInconnu(NOM_OLT, 2, 80, SLID);
    PE0341_NotificationReseauSTI notificationReseauSti = new PE0341_NotificationReseauSTI(typeEvenement, donneesOntInconnu, null);
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
    Request request = prepareRequest(HttpConstants.POST_METHOD, notificationReseauSti, headers);

    PowerMock.replayAll();
    Response response = executeStartPostProcess(request, DEFAULT_PROCESSNAME);
    PowerMock.verifyAll();

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = new Gson().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals("Paramètre typeEvenement null ou vide dans la requête.", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegSpiritConsts.ENTREE_INCORRECTE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> When input params are not valid<br/>
   * <b>Entrées:</b> input param null or empty<br/>
   * <b>Attendu:</b> ENTREE_INCORRECTE<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0341_NotificationReseau_POST_KO_006() throws Throwable
  {
    // donneesOntInconnu null when typeEvenement = The GPON ONT is discovered by the OLT
    String typeEvenement = NotificationReseauTypeEvenement.THE_GPON_ONT_IS_DISCOVERED_BY_OLT.getDisplayName();
    DonneesOntInconnu donneesOntInconnu = null;

    PE0341_NotificationReseauSTI notificationReseauSti = new PE0341_NotificationReseauSTI(typeEvenement, donneesOntInconnu, null);
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
    Request request = prepareRequest(HttpConstants.POST_METHOD, notificationReseauSti, headers);

    PowerMock.replayAll();
    Response response = executeStartPostProcess(request, DEFAULT_PROCESSNAME);
    PowerMock.verifyAll();

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = new Gson().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals("invalid value for attribute donneesOntInconnu: " + donneesOntInconnu, reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegSpiritConsts.ENTREE_INCORRECTE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> When input params are not valid<br/>
   * <b>Entrées:</b> input param null or empty<br/>
   * <b>Attendu:</b> ENTREE_INCORRECTE<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0341_NotificationReseau_POST_KO_007() throws Throwable
  {
    // nomOLT null when typeEvenement = The GPON ONT is discovered by the OLT
    String typeEvenement = NotificationReseauTypeEvenement.THE_GPON_ONT_IS_DISCOVERED_BY_OLT.getDisplayName();
    DonneesOntInconnu donneesOntInconnu = new DonneesOntInconnu(null, 2, 80, SLID); //;

    PE0341_NotificationReseauSTI notificationReseauSti = new PE0341_NotificationReseauSTI(typeEvenement, donneesOntInconnu, null);
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
    Request request = prepareRequest(HttpConstants.POST_METHOD, notificationReseauSti, headers);

    PowerMock.replayAll();
    Response response = executeStartPostProcess(request, DEFAULT_PROCESSNAME);
    PowerMock.verifyAll();

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = new Gson().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals("invalid value for attribute nomOlt: null", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegSpiritConsts.ENTREE_INCORRECTE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> When input params are not valid<br/>
   * <b>Entrées:</b> input param null or empty<br/>
   * <b>Attendu:</b> ENTREE_INCORRECTE<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0341_NotificationReseau_POST_KO_008() throws Throwable
  {
    // slid null when typeEvenement = The GPON ONT is discovered by the OLT
    String typeEvenement = NotificationReseauTypeEvenement.THE_GPON_ONT_IS_DISCOVERED_BY_OLT.getDisplayName();
    DonneesOntInconnu donneesOntInconnu = new DonneesOntInconnu("nomOlt", 2, 80, null); //$NON-NLS-1$ //;

    PE0341_NotificationReseauSTI notificationReseauSti = new PE0341_NotificationReseauSTI(typeEvenement, donneesOntInconnu, null);
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", null, null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    Request request = prepareRequest(HttpConstants.POST_METHOD, notificationReseauSti, headers);

    PowerMock.replayAll();
    Response response = executeStartPostProcess(request, DEFAULT_PROCESSNAME);
    PowerMock.verifyAll();

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = new Gson().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals("invalid value for attribute slid: null", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegSpiritConsts.ENTREE_INCORRECTE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> When input params are not valid<br/>
   * <b>Entrées:</b> input param null or empty<br/>
   * <b>Attendu:</b> ENTREE_INCORRECTE<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0341_NotificationReseau_POST_KO_009() throws Throwable
  {
    // port null when typeEvenement = The GPON ONT is discovered by the OLT
    String typeEvenement = NotificationReseauTypeEvenement.THE_GPON_ONT_IS_DISCOVERED_BY_OLT.getDisplayName();
    DonneesOntInconnu donneesOntInconnu = new DonneesOntInconnu("nomOlt", null, 80, SLID); //$NON-NLS-1$ //;

    PE0341_NotificationReseauSTI notificationReseauSti = new PE0341_NotificationReseauSTI(typeEvenement, donneesOntInconnu, null);
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
    Request request = prepareRequest(HttpConstants.POST_METHOD, notificationReseauSti, headers);

    PowerMock.replayAll();
    Response response = executeStartPostProcess(request, DEFAULT_PROCESSNAME);
    PowerMock.verifyAll();

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = new Gson().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals("invalid value for attribute slot: null", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegSpiritConsts.ENTREE_INCORRECTE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> When input params are not valid<br/>
   * <b>Entrées:</b> input param null or empty<br/>
   * <b>Attendu:</b> ENTREE_INCORRECTE<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0341_NotificationReseau_POST_KO_010() throws Throwable
  {
    // port null when typeEvenement = The GPON ONT is discovered by the OLT
    String typeEvenement = NotificationReseauTypeEvenement.THE_GPON_ONT_IS_DISCOVERED_BY_OLT.getDisplayName();
    DonneesOntInconnu donneesOntInconnu = new DonneesOntInconnu("nomOlt", 2, null, SLID); //$NON-NLS-1$ //;

    PE0341_NotificationReseauSTI notificationReseauSti = new PE0341_NotificationReseauSTI(typeEvenement, donneesOntInconnu, null);
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
    Request request = prepareRequest(HttpConstants.POST_METHOD, notificationReseauSti, headers);

    PowerMock.replayAll();
    Response response = executeStartPostProcess(request, DEFAULT_PROCESSNAME);
    PowerMock.verifyAll();

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = new Gson().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals("invalid value for attribute port: null", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegSpiritConsts.ENTREE_INCORRECTE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> When input params are not valid<br/>
   * <b>Entrées:</b> input param null or empty<br/>
   * <b>Attendu:</b> ENTREE_INCORRECTE<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0341_NotificationReseau_POST_KO_011() throws Throwable
  {
    // typeEvenement invalide
    String typeEvenement = "typeEvd"; //$NON-NLS-1$
    DonneesOntInconnu donneesOntInconnu = new DonneesOntInconnu(NOM_OLT, 2, 80, SLID);
    PE0341_NotificationReseauSTI notificationReseauSti = new PE0341_NotificationReseauSTI(typeEvenement, donneesOntInconnu, null);
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
    Request request = prepareRequest(HttpConstants.POST_METHOD, notificationReseauSti, headers);

    PowerMock.replayAll();
    Response response = executeStartPostProcess(request, DEFAULT_PROCESSNAME);
    PowerMock.verifyAll();

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = new Gson().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals("invalid value for attribute typeEvenement: " + typeEvenement, reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegSpiritConsts.ENTREE_INCORRECTE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> When input params are not valid for RECOMMANDATION_TV, pfi null<br/>
   * <b>Entrées:</b> input param null or empty<br/>
   * <b>Attendu:</b> ENTREE_INCORRECTE<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0341_NotificationReseau_POST_KO_012() throws Throwable
  {
    String typeEvenement = NotificationReseauTypeEvenement.RECOMMANDATION_TV.getDisplayName();
    // notificationReseauSti null
    PE0341_NotificationReseauSTI notificationReseauSti = new PE0341_NotificationReseauSTI(typeEvenement, null, null);
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
    Request request = prepareRequest(HttpConstants.POST_METHOD, notificationReseauSti, headers);

    PowerMock.replayAll();
    Response response = executeStartPostProcess(request, DEFAULT_PROCESSNAME);
    PowerMock.verifyAll();

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = new Gson().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals("invalid value for attribute Pfi: null", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegSpiritConsts.ENTREE_INCORRECTE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> When input params are not valid for RECOMMANDATION_TV, clientOperateur or empty<br/>
   * <b>Entrées:</b> input param null or empty<br/>
   * <b>Attendu:</b> ENTREE_INCORRECTE<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0341_NotificationReseau_POST_KO_013() throws Throwable
  {
    String typeEvenement = NotificationReseauTypeEvenement.RECOMMANDATION_TV.getDisplayName();
    Pfi pfi = new Pfi("Diferent_from_BSS_GP", "NoCompte1"); //$NON-NLS-1$ //$NON-NLS-2$
    // notificationReseauSti null
    PE0341_NotificationReseauSTI notificationReseauSti = new PE0341_NotificationReseauSTI(typeEvenement, null, pfi);
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
    Request request = prepareRequest(HttpConstants.POST_METHOD, notificationReseauSti, headers);

    PowerMock.replayAll();
    Response response = executeStartPostProcess(request, DEFAULT_PROCESSNAME);
    PowerMock.verifyAll();

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = new Gson().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals("invalid value for attribute clientOperateur: Diferent_from_BSS_GP", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegSpiritConsts.ENTREE_INCORRECTE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> When input params are not valid for RECOMMANDATION_TV, clientOperateur or empty<br/>
   * <b>Entrées:</b> input param null or empty<br/>
   * <b>Attendu:</b> ENTREE_INCORRECTE<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0341_NotificationReseau_POST_KO_014() throws Throwable
  {
    String typeEvenement = NotificationReseauTypeEvenement.RECOMMANDATION_TV.getDisplayName();
    Pfi pfi = new Pfi("BSS_GP", null); //$NON-NLS-1$
    // notificationReseauSti null
    PE0341_NotificationReseauSTI notificationReseauSti = new PE0341_NotificationReseauSTI(typeEvenement, null, pfi);
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
    Request request = prepareRequest(HttpConstants.POST_METHOD, notificationReseauSti, headers);

    PowerMock.replayAll();
    Response response = executeStartPostProcess(request, DEFAULT_PROCESSNAME);
    PowerMock.verifyAll();

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = new Gson().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals("invalid value for attribute noCompte: null", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegSpiritConsts.ENTREE_INCORRECTE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> When FILE_PATH param for ConfigurationAChaudPE file is not defined in configFile<br/>
   * <b>Entrées:</b> input param null or empty<br/>
   * <b>Attendu:</b> ENTREE_INCORRECTE<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0341_NotificationReseau_POST_KO_015() throws Throwable
  {
    Request request = createRequestOntInconnu(true)._second;

    ProcessManager.getInstance().getProcessParams().get(StringConstants.EMPTY_STRING).remove(PARAM_FILE_PATH);

    PowerMock.replayAll();
    Response response = executeStartPostProcess(request, DEFAULT_PROCESSNAME);
    PowerMock.verifyAll();

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = new Gson().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00404, response.getErrorCode());
    Assert.assertEquals("Cannot find param FILE_PATH in process configuration", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegConsts.CONFIGURATION_INVALIDE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> When FILE_PATH has an invalid value<br/>
   * <b>Entrées:</b> input param null or empty<br/>
   * <b>Attendu:</b> ENTREE_INCORRECTE<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0341_NotificationReseau_POST_KO_016() throws Throwable
  {
    Request request = createRequestOntInconnu(true)._second;

    ProcessManager.getInstance().getProcessParams().get(StringConstants.EMPTY_STRING).replace(PARAM_FILE_PATH, "garbage"); //$NON-NLS-1$

    PowerMock.replayAll();
    Response response = executeStartPostProcess(request, DEFAULT_PROCESSNAME);
    PowerMock.verifyAll();

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = new Gson().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00404, response.getErrorCode());
    Assert.assertEquals("Fichier de configuration en erreur [garbage]", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegConsts.CONFIGURATION_INVALIDE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> When ConfigurationAChaudPE has typeEvenement null<br/>
   * <b>Entrées:</b> input param null or empty<br/>
   * <b>Attendu:</b> ENTREE_INCORRECTE<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0341_NotificationReseau_POST_KO_017() throws Throwable
  {
    Request request = createRequestOntInconnu(true)._second;

    File classpath = new File(PE0341_NotificationReseauTest.class.getResource("/").getFile()); //$NON-NLS-1$
    ProcessManager.getInstance().getProcessParams().get(StringConstants.EMPTY_STRING).replace(PARAM_FILE_PATH, classpath + "/PE0341/ConfigurationPE0341_typeEvenementNull.xml"); //$NON-NLS-1$

    PowerMock.replayAll();
    Response response = executeStartPostProcess(request, DEFAULT_PROCESSNAME);
    PowerMock.verifyAll();

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = new Gson().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00404, response.getErrorCode());
    Assert.assertEquals("Cannot find param typeNotification in process configuration a chaud", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegConsts.CONFIGURATION_INVALIDE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> When ConfigurationAChaudPE param typeEvenement has invalid value<br/>
   * <b>Entrées:</b> input param null or empty<br/>
   * <b>Attendu:</b> ENTREE_INCORRECTE<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0341_NotificationReseau_POST_KO_018() throws Throwable
  {
    Request request = createRequestOntInconnu(true)._second;

    File classpath = new File(PE0341_NotificationReseauTest.class.getResource("/").getFile()); //$NON-NLS-1$
    ProcessManager.getInstance().getProcessParams().get(StringConstants.EMPTY_STRING).replace(PARAM_FILE_PATH, classpath + "/PE0341/ConfigurationPE0341_typeEvenementWrong.xml"); //$NON-NLS-1$

    PowerMock.replayAll();
    Response response = executeStartPostProcess(request, DEFAULT_PROCESSNAME);
    PowerMock.verifyAll();

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = new Gson().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00404, response.getErrorCode());
    Assert.assertEquals("Cannot find param typeNotification in process configuration a chaud", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegConsts.CONFIGURATION_INVALIDE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> When ConfigurationAChaudPE param tempoMax is null<br/>
   * <b>Entrées:</b> input param null or empty<br/>
   * <b>Attendu:</b> ENTREE_INCORRECTE<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0341_NotificationReseau_POST_KO_019() throws Throwable
  {
    Request request = createRequestOntInconnu(true)._second;

    File classpath = new File(PE0341_NotificationReseauTest.class.getResource("/").getFile()); //$NON-NLS-1$
    ProcessManager.getInstance().getProcessParams().get(StringConstants.EMPTY_STRING).replace(PARAM_FILE_PATH, classpath + "/PE0341/ConfigurationPE0341_tempoMaxNull.xml"); //$NON-NLS-1$

    PowerMock.replayAll();
    Response response = executeStartPostProcess(request, DEFAULT_PROCESSNAME);
    PowerMock.verifyAll();

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = new Gson().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00404, response.getErrorCode());
    Assert.assertEquals("Cannot find param tempoMax in process configuration a chaud", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegConsts.CONFIGURATION_INVALIDE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> When ConfigurationAChaudPE param tempoMax is negative<br/>
   * <b>Entrées:</b> input param null or empty<br/>
   * <b>Attendu:</b> ENTREE_INCORRECTE<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0341_NotificationReseau_POST_KO_020() throws Throwable
  {
    Request request = createRequestOntInconnu(true)._second;

    File classpath = new File(PE0341_NotificationReseauTest.class.getResource("/").getFile()); //$NON-NLS-1$
    ProcessManager.getInstance().getProcessParams().get(StringConstants.EMPTY_STRING).replace(PARAM_FILE_PATH, classpath + "/PE0341/ConfigurationPE0341_tempoMaxNegative.xml"); //$NON-NLS-1$

    PowerMock.replayAll();
    Response response = executeStartPostProcess(request, DEFAULT_PROCESSNAME);
    PowerMock.verifyAll();

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = new Gson().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00404, response.getErrorCode());
    Assert.assertEquals("Param tempoMax invalid. Less than 0.", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegConsts.CONFIGURATION_INVALIDE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> When ConfigurationAChaudPE param nbrCompensationMax is null<br/>
   * <b>Entrées:</b> input param null or empty<br/>
   * <b>Attendu:</b> ENTREE_INCORRECTE<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0341_NotificationReseau_POST_KO_021() throws Throwable
  {
    Request request = createRequestOntInconnu(true)._second;

    File classpath = new File(PE0341_NotificationReseauTest.class.getResource("/").getFile()); //$NON-NLS-1$
    ProcessManager.getInstance().getProcessParams().get(StringConstants.EMPTY_STRING).replace(PARAM_FILE_PATH, classpath + "/PE0341/ConfigurationPE0341_nbrCompensationMaxNull.xml"); //$NON-NLS-1$

    PowerMock.replayAll();
    Response response = executeStartPostProcess(request, DEFAULT_PROCESSNAME);
    PowerMock.verifyAll();

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = new Gson().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00404, response.getErrorCode());
    Assert.assertEquals("Cannot find param nbrCompensationMax in process configuration a chaud", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegConsts.CONFIGURATION_INVALIDE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> When ConfigurationAChaudPE param nbrCompentationMax is negative<br/>
   * <b>Entrées:</b> input param null or empty<br/>
   * <b>Attendu:</b> ENTREE_INCORRECTE<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0341_NotificationReseau_POST_KO_022() throws Throwable
  {
    Request request = createRequestOntInconnu(true)._second;

    File classpath = new File(PE0341_NotificationReseauTest.class.getResource("/").getFile()); //$NON-NLS-1$
    ProcessManager.getInstance().getProcessParams().get(StringConstants.EMPTY_STRING).replace(PARAM_FILE_PATH, classpath + "/PE0341/ConfigurationPE0341_nbrCompensationMaxNegative.xml"); //$NON-NLS-1$

    PowerMock.replayAll();
    Response response = executeStartPostProcess(request, DEFAULT_PROCESSNAME);
    PowerMock.verifyAll();

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = new Gson().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00404, response.getErrorCode());
    Assert.assertEquals("Param nbrCompensationMax invalid. Less than or equals to 0.", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegConsts.CONFIGURATION_INVALIDE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> When locationHeaderUrl param is not defined in configFile <br/>
   * <b>Entrées:</b> input param null or empty<br/>
   * <b>Attendu:</b> ENTREE_INCORRECTE<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0341_NotificationReseau_POST_KO_023() throws Throwable
  {
    Request request = createRequestOntInconnu(true)._second;

    ProcessManager.getInstance().getProcessParams().get(StringConstants.EMPTY_STRING).remove(LOCATION_HEADER_URL_PARAM);

    PowerMock.replayAll();
    Response response = executeStartPostProcess(request, DEFAULT_PROCESSNAME);
    PowerMock.verifyAll();

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = new Gson().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00404, response.getErrorCode());
    Assert.assertEquals("Cannot find param locationHeaderUrl in process configuration", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegConsts.CONFIGURATION_INVALIDE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> Teste la BL100 lorsque BL800_ObtenirSequence return NOK <br/>
   * <b>Entrées:</b> input param null or empty<br/>
   * <b>Attendu:</b> ENTREE_INCORRECTE<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0341_NotificationReseau_POST_KO_024() throws Throwable
  {
    Request request = createRequestOntInconnu(true)._second;

    mockBL800(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, "erro"));//$NON-NLS-1$

    PowerMock.replayAll();
    Response response = executeStartPostProcess(request, DEFAULT_PROCESSNAME);
    PowerMock.verifyAll();

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = new Gson().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    Assert.assertEquals("erro", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegConsts.TRAITEMENT_ARRETE, reponseactual.getError());
  }

  /**
   * Teste la BL100 lorsque BL800_ObtenirSequence return OK, typeEvenement est RECOMMANDATION_TV, dateReception est null
   * et dateGenerationEvenementReseau est null et REXProxy return NOK
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0341_NotificationReseau_POST_KO_025() throws Throwable
  {
    Request request = createRequestRecommandationTv(true)._second;

    mockBL800(RetourFactory.createOkRetour());

    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxyMock);
    EasyMock.expect(_rexProxyMock.notificationReseauCreer(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject(NotificationReseauRecommandationTvJSON.class))).andReturn(new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, "erro"), null)); //$NON-NLS-1$

    PowerMock.replayAll();
    Response response = executeStartPostProcess(request, DEFAULT_PROCESSNAME);
    PowerMock.verifyAll();

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = new Gson().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    Assert.assertEquals("erro", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegConsts.TRAITEMENT_ARRETE, reponseactual.getError());

  }

  /**
   * Teste la BL100 lorsque BL800_ObtenirSequence return OK, typeEvenement est ONT_INCONNU, dateReception n'est pas null
   * et dateGenerationEvenementReseau n'est pas null et REXProxy return NOK
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0341_NotificationReseau_POST_KO_026() throws Throwable
  {

    Request request = createRequestOntInconnu(false)._second;

    mockBL800(RetourFactory.createOkRetour());

    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxyMock);
    EasyMock.expect(_rexProxyMock.notificationReseauCreer(EasyMock.anyObject(), EasyMock.anyObject())).andReturn(new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, "erro"), null)); //$NON-NLS-1$

    PowerMock.replayAll();
    Response response = executeStartPostProcess(request, DEFAULT_PROCESSNAME);
    PowerMock.verifyAll();

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = new Gson().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    Assert.assertEquals("erro", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegConsts.TRAITEMENT_ARRETE, reponseactual.getError());

  }

  /**
   * Teste la BL200 lorsque typeEvenement est ONT_INCONNU, la BL5400 return NOK et
   * REXProxy.cleRechercheNotificationReseau return NOK
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0341_NotificationReseau_POST_KO_027() throws Throwable
  {
    Pair<PE0341_NotificationReseauSTI, Request> input = createRequestOntInconnu(false);
    PE0341_NotificationReseauSTI sti = input._first;
    Request request = input._second;

    mockBL800(RetourFactory.createOkRetour());

    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxyMock).times(2);
    EasyMock.expect(_rexProxyMock.notificationReseauCreer(EasyMock.anyObject(), EasyMock.anyObject())).andReturn(new ConnectorResponse<>(RetourFactory.createOkRetour(), null));

    mockBL5400(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, "erro"), true); //$NON-NLS-1$

    EasyMock.expect(_rexProxyMock.cleRechercheNotificationReseau(EasyMock.anyObject(), EasyMock.anyObject())).andReturn(new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, "erro"), null)); //$NON-NLS-1$

    PowerMock.replayAll();
    Response response = executeStartPostProcess(request, DEFAULT_PROCESSNAME);
    PowerMock.verifyAll();

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = new Gson().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    Assert.assertEquals("erro", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegConsts.TRAITEMENT_ARRETE, reponseactual.getError());
    Assert.assertTrue(comparerAbstractNotificationReseau(createNotificationReseuBySTI(sti, ID_NOTIFICATION_RESEAU), _processInstance.getProcessContext().getAbstractNotificationReseau()));
  }

  /**
   * Teste la BL200 lorsque typeEvenement est ONT_INCONNU, la BL5400 return OK et
   * REXProxy.cleRechercheNotificationReseau return NOK
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0341_NotificationReseau_POST_KO_028() throws Throwable
  {
    Pair<PE0341_NotificationReseauSTI, Request> input = createRequestOntInconnu(false);
    PE0341_NotificationReseauSTI sti = input._first;
    Request request = input._second;

    mockBL800(RetourFactory.createOkRetour());

    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxyMock).times(2);
    EasyMock.expect(_rexProxyMock.notificationReseauCreer(EasyMock.anyObject(), EasyMock.anyObject())).andReturn(new ConnectorResponse<>(RetourFactory.createOkRetour(), null));

    mockBL5400(RetourFactory.createOkRetour(), false);

    EasyMock.expect(_rexProxyMock.cleRechercheNotificationReseau(EasyMock.anyObject(), EasyMock.anyObject())).andReturn(new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, "erro"), null)); //$NON-NLS-1$

    PowerMock.replayAll();
    Response response = executeStartPostProcess(request, DEFAULT_PROCESSNAME);
    PowerMock.verifyAll();

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = new Gson().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    Assert.assertEquals("erro", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegConsts.TRAITEMENT_ARRETE, reponseactual.getError());
    Assert.assertTrue(comparerAbstractNotificationReseau(createNotificationReseuBySTI(sti, ID_NOTIFICATION_RESEAU), _processInstance.getProcessContext().getAbstractNotificationReseau()));
  }

  /**
   * Teste la BL200 lorsque typeEvenement est RECOMMANDATION_TV et REXProxy.cleRechercheNotificationReseau return NOK
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0341_NotificationReseau_POST_KO_029() throws Throwable
  {
    Pair<PE0341_NotificationReseauSTI, Request> input = createRequestRecommandationTv(false);
    PE0341_NotificationReseauSTI sti = input._first;
    Request request = input._second;

    mockBL800(RetourFactory.createOkRetour());

    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxyMock).times(2);
    EasyMock.expect(_rexProxyMock.notificationReseauCreer(EasyMock.anyObject(), EasyMock.anyObject())).andReturn(new ConnectorResponse<>(RetourFactory.createOkRetour(), null));

    EasyMock.expect(_rexProxyMock.cleRechercheNotificationReseau(EasyMock.anyObject(), EasyMock.anyObject())).andReturn(new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, "erro"), null)); //$NON-NLS-1$

    PowerMock.replayAll();
    Response response = executeStartPostProcess(request, DEFAULT_PROCESSNAME);
    PowerMock.verifyAll();

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = new Gson().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    Assert.assertEquals("erro", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegConsts.TRAITEMENT_ARRETE, reponseactual.getError());
    Assert.assertTrue(comparerAbstractNotificationReseau(createNotificationReseuBySTI(sti, ID_NOTIFICATION_RESEAU), _processInstance.getProcessContext().getAbstractNotificationReseau()));
  }

  /**
   * <b>Cas de test:</b> When ConfigurationAChaudPE param nbrCompensationMax is zero<br/>
   * <b>Entrées:</b> input param null or empty<br/>
   * <b>Attendu:</b> ENTREE_INCORRECTE<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0341_NotificationReseau_POST_KO_030() throws Throwable
  {
    Request request = createRequestOntInconnu(true)._second;

    File classpath = new File(PE0341_NotificationReseauTest.class.getResource("/").getFile()); //$NON-NLS-1$
    ProcessManager.getInstance().getProcessParams().get(StringConstants.EMPTY_STRING).replace(PARAM_FILE_PATH, classpath + "/PE0341/ConfigurationPE0341_nbrCompensationMaxZero.xml"); //$NON-NLS-1$

    PowerMock.replayAll();
    Response response = executeStartPostProcess(request, DEFAULT_PROCESSNAME);
    PowerMock.verifyAll();

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = new Gson().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00404, response.getErrorCode());
    Assert.assertEquals("Param nbrCompensationMax invalid. Less than or equals to 0.", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegConsts.CONFIGURATION_INVALIDE, reponseactual.getError());
  }

  /**
   * Teste typeEvenement est ONT_INCONNU et tout retourne OK.
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0341_NotificationReseau_POST_OK_001() throws Throwable
  {
    Pair<PE0341_NotificationReseauSTI, Request> input = createRequestOntInconnu(false);
    PE0341_NotificationReseauSTI sti = input._first;
    Request request = input._second;

    mockBL800(RetourFactory.createOkRetour());

    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxyMock).times(2);
    EasyMock.expect(_rexProxyMock.notificationReseauCreer(EasyMock.anyObject(), EasyMock.anyObject())).andReturn(new ConnectorResponse<>(RetourFactory.createOkRetour(), null));

    mockBL5400(RetourFactory.createOkRetour(), false);

    EasyMock.expect(_rexProxyMock.cleRechercheNotificationReseau(EasyMock.anyObject(), EasyMock.anyObject())).andReturn(new ConnectorResponse<>(RetourFactory.createOkRetour(), null));

    PowerMock.replayAll();
    Response response = executeStartPostProcess(request, DEFAULT_PROCESSNAME);
    PowerMock.verifyAll();

    Assert.assertEquals(ErrorCode.OK_00201, response.getErrorCode());
    Assert.assertNull(response.getGenericResponse().getResult());
    Assert.assertEquals(IHttpHeadersConsts.LOCATION, response.getResponseHeader().get(0).getName());
    Assert.assertEquals(LOCATION_HEADER_URL_PARAM_VALUE + ID_NOTIFICATION_RESEAU, response.getResponseHeader().get(0).getValue());
    Assert.assertTrue(comparerAbstractNotificationReseau(createNotificationReseuBySTI(sti, ID_NOTIFICATION_RESEAU), _processInstance.getProcessContext().getAbstractNotificationReseau()));
  }

  /**
   * Teste typeEvenement est RECOMMANDATION_TV et tout retourne OK.
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0341_NotificationReseau_POST_OK_002() throws Throwable
  {
    Pair<PE0341_NotificationReseauSTI, Request> input = createRequestRecommandationTv(false);
    PE0341_NotificationReseauSTI sti = input._first;
    Request request = input._second;

    mockBL800(RetourFactory.createOkRetour());

    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxyMock).times(2);
    EasyMock.expect(_rexProxyMock.notificationReseauCreer(EasyMock.anyObject(), EasyMock.anyObject())).andReturn(new ConnectorResponse<>(RetourFactory.createOkRetour(), null));

    EasyMock.expect(_rexProxyMock.cleRechercheNotificationReseau(EasyMock.anyObject(), EasyMock.anyObject())).andReturn(new ConnectorResponse<>(RetourFactory.createOkRetour(), null));

    PowerMock.replayAll();
    Response response = executeStartPostProcess(request, DEFAULT_PROCESSNAME);
    PowerMock.verifyAll();

    Assert.assertEquals(ErrorCode.OK_00201, response.getErrorCode());
    Assert.assertNull(response.getGenericResponse().getResult());
    Assert.assertEquals(IHttpHeadersConsts.LOCATION, response.getResponseHeader().get(0).getName());
    Assert.assertEquals(LOCATION_HEADER_URL_PARAM_VALUE + ID_NOTIFICATION_RESEAU, response.getResponseHeader().get(0).getValue());
    Assert.assertTrue(comparerAbstractNotificationReseau(createNotificationReseuBySTI(sti, ID_NOTIFICATION_RESEAU), _processInstance.getProcessContext().getAbstractNotificationReseau()));
  }

  /**
   * Test KO Header X-REQUEST-ID null or empty
   *
   * @throws Throwable
   *           if error
   */
  @Test
  public void PE0341_NotificationReseau_PUT_KO_001() throws Throwable
  {

    List<RequestHeader> headers = addXHeaders(null, null, null, null, null);
    Request request = prepareRequestPut(headers);

    PowerMock.replayAll();
    Response response = executeStartPutProcess(request, DEFAULT_PROCESSNAME);
    PowerMock.verifyAll();

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = new Gson().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals("Header X-Request-Id null ou vide.", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegSpiritConsts.NON_RESPECT_STI, reponseactual.getError());

  }

  /**
   * Test KO Header X-PROCESS null or empty
   *
   * @throws Throwable
   *           if error
   */
  @Test
  public void PE0341_NotificationReseau_PUT_KO_002() throws Throwable
  {

    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "", "", "", ""); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
    Request request = prepareRequestPut(headers);

    PowerMock.replayAll();
    Response response = executeStartPutProcess(request, DEFAULT_PROCESSNAME);
    PowerMock.verifyAll();

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = new Gson().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals("Header X-Process null ou vide.", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegSpiritConsts.NON_RESPECT_STI, reponseactual.getError());

  }

  /**
   * Test KO Header X-SOURCE null or empty
   *
   * @throws Throwable
   *           if error
   */
  @Test
  public void PE0341_NotificationReseau_PUT_KO_003() throws Throwable
  {

    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "", "", ""); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
    Request request = prepareRequestPut(headers);

    PowerMock.replayAll();
    Response response = executeStartPutProcess(request, DEFAULT_PROCESSNAME);
    PowerMock.verifyAll();

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = new Gson().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals("Header X-Source null ou vide.", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegSpiritConsts.NON_RESPECT_STI, reponseactual.getError());

  }

  /**
   * Test KO NON_RESPECT_TI
   *
   * @throws Throwable
   *           if error
   */
  @Test
  public void PE0341_NotificationReseau_PUT_KO_004() throws Throwable
  {

    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
    Request request = prepareRequestPut(headers);

    PowerMock.replayAll();
    Response response = executeStartPutProcess(request, DEFAULT_PROCESSNAME);
    PowerMock.verifyAll();

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = new Gson().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals("Paramètre idNotificationReseau null ou vide dans la requête.", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegSpiritConsts.NON_RESPECT_STI, reponseactual.getError());
  }

  /**
   * Test Response OK
   *
   * @throws Throwable
   *           if error
   */
  @Test
  public void PE0341_NotificationReseau_PUT_OK_001() throws Throwable
  {

    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", ""); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    Request request = prepareRequestPut(headers);
    request.setUrlDynamicParameters(ID_NOTIFICATION_RESEAU);

    AbstractNotificationReseau notificationReseau = new NotificationReseauONTInconnuJSON();
    notificationReseau.setIdNotificationReseau(ID_NOTIFICATION_RESEAU);
    ConnectorResponse<Retour, AbstractNotificationReseau> crReseau = new ConnectorResponse<Retour, AbstractNotificationReseau>(RetourFactoryForTU.createOkRetour(), notificationReseau);
    ConnectorResponse<Retour, Nothing> crModifierStatut = new ConnectorResponse<Retour, Nothing>(RetourFactoryForTU.createOkRetour(), null);
    UpdateNotificationReseauStatutRequest updateReq = new UpdateNotificationReseauStatutRequest(notificationReseau.getIdNotificationReseau(), NotificationReseauStatut.ACQUITTE.name());

    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxyMock).times(2);
    EasyMock.expect(_rexProxyMock.notificationReseauLireUn(_tracabilite, ID_NOTIFICATION_RESEAU)).andReturn(crReseau);
    EasyMock.expect(_rexProxyMock.notificationReseauModifierStatut(_tracabilite, updateReq)).andReturn(crModifierStatut);

    PowerMock.replayAll();
    Response response = executeStartPutProcess(request, DEFAULT_PROCESSNAME);
    PowerMock.verifyAll();

    Assert.assertEquals(ErrorCode.OK_00202, response.getErrorCode());
    Assert.assertEquals(ID_NOTIFICATION_RESEAU, updateReq.getIdNotificationReseau());
  }

  /**
   *
   * @throws Exception
   *           On errors Thrown in case of error during switch in attributes of parent class
   */
  @Before
  public void setUp() throws Exception
  {
    _processInstance = new PE0341_NotificationReseau();
    _processInstance.initializeContext();

    _tracabilite = new Tracabilite();

    PowerMock.resetAll();

    PowerMock.mockStaticStrict(REXProxy.class);
    PowerMock.mockStaticStrict(BL800_ObtenirSequence.class);
    PowerMock.mockStaticNice(BL800_ObtenirSequenceBuilder.class);
    PowerMock.mockStaticStrict(BL5400_DecoderSlid.class);
    PowerMock.mockStaticStrict(BL5400_DecoderSlidBuilder.class);
    PowerMock.mockStaticStrict(PE0341_BL500_TraiterNotificationReseau.class);
    PowerMock.mockStaticStrict(PE0341_BL500_TraiterNotificationReseauBuilder.class);

    ProcessManager.getInstance().getProcessParams().clear();
    Map<String, String> map = new ConcurrentHashMap<>();
    File classpath = new File(PE0341_NotificationReseauTest.class.getResource("/").getFile()); //$NON-NLS-1$
    map.put(PARAM_FILE_PATH, classpath + "/PE0341/ConfigurationPE0341.xml"); //$NON-NLS-1$
    map.put(LOCATION_HEADER_URL_PARAM, LOCATION_HEADER_URL_PARAM_VALUE);
    ProcessManager.getInstance().getProcessParams().put(StringConstants.EMPTY_STRING, map);

  }

  /**
   * Method that does the needed clean up.<br/>
   *
   * <b>Entrées:</b> N/A for this test method. <br/>
   * <b>Attendu:</b> Clean up of some of our data.
   *
   */
  @After
  public void tearDown()
  {
    _processInstance = null;
  }

  /**
   * Add custom headers
   *
   * @param requestId_p
   *          {@link String}
   * @param process_p
   *          {@link String}
   * @param source_p
   *          {@link String}
   * @param messageId_p
   *          {@link String}
   * @param actionId_p
   *          {@link String}
   * @return {@link List}
   */
  private List<RequestHeader> addXHeaders(String requestId_p, String process_p, String source_p, String messageId_p, String actionId_p)
  {
    List<RequestHeader> headers = new ArrayList<>();
    RequestHeader hdr = new RequestHeader();

    hdr.setName(IHttpHeadersConsts.CONTENT_TYPE);
    hdr.setValue(MediaType.APPLICATION_JSON);
    headers.add(hdr);

    if (requestId_p != null)
    {
      hdr = new RequestHeader();
      hdr.setName(IHttpHeadersConsts.X_REQUEST_ID);
      hdr.setValue(requestId_p);
      headers.add(hdr);
    }

    if (source_p != null)
    {
      hdr = new RequestHeader();
      hdr.setName(IHttpHeadersConsts.X_SOURCE);
      hdr.setValue(source_p);
      headers.add(hdr);
    }

    if (process_p != null)
    {
      hdr = new RequestHeader();
      hdr.setName(IHttpHeadersConsts.X_PROCESS);
      hdr.setValue(process_p);
      headers.add(hdr);
    }

    if (messageId_p != null)
    {
      hdr = new RequestHeader();
      hdr.setName(IHttpHeadersConsts.X_MESSAGE_ID);
      hdr.setValue(messageId_p);
      headers.add(hdr);
    }

    if (actionId_p != null)
    {
      hdr = new RequestHeader();
      hdr.setName(IHttpHeadersConsts.X_ACTION_ID);
      hdr.setValue(actionId_p);
      headers.add(hdr);
    }

    return headers;

  }

  /**
   * @param expected
   *          {@link AbstractNotificationReseau}
   * @param actual
   *          {@link AbstractNotificationReseau}
   * @return {@link Boolean}
   */
  private boolean comparerAbstractNotificationReseau(AbstractNotificationReseau expected, AbstractNotificationReseau actual)
  {

    if (expected == actual)
    {
      return true;
    }
    if (actual == null)
    {
      return false;
    }
    if (expected.getClass() != actual.getClass())
    {
      return false;
    }
    if (expected.getCodeErreur() == null)
    {
      if (actual.getCodeErreur() != null)
      {
        return false;
      }
    }
    else if (!expected.getCodeErreur().equals(actual.getCodeErreur()))
    {
      return false;
    }
    if (expected.getDateCreation() == null)
    {
      if (actual.getDateCreation() != null)
      {
        return false;
      }
    }
    else if (!expected.getDateCreation().equals(actual.getDateCreation()))
    {
      return false;
    }
    if (expected.getDateGenerationEvenementReseau() == null)
    {
      if (actual.getDateGenerationEvenementReseau() != null)
      {
        return false;
      }
    }
    else if (!expected.getDateGenerationEvenementReseau().equals(actual.getDateGenerationEvenementReseau()))
    {
      return false;
    }
    if (expected.getDateModification() == null)
    {
      if (actual.getDateModification() != null)
      {
        return false;
      }
    }
    else if (!expected.getDateModification().equals(actual.getDateModification()))
    {
      return false;
    }
    if (expected.getDateReception() == null)
    {
      if (actual.getDateReception() != null)
      {
        return false;
      }
    }
    else if (!expected.getDateReception().equals(actual.getDateReception()))
    {
      return false;
    }
    if (expected.getIdCmd() == null)
    {
      if (actual.getIdCmd() != null)
      {
        return false;
      }
    }
    else if (!expected.getIdCmd().equals(actual.getIdCmd()))
    {
      return false;
    }
    if (expected.getIdNotificationReseau() == null)
    {
      if (actual.getIdNotificationReseau() != null)
      {
        return false;
      }
    }
    else if (!expected.getIdNotificationReseau().equals(actual.getIdNotificationReseau()))
    {
      return false;
    }
    if (expected.getLibelleErreur() == null)
    {
      if (actual.getLibelleErreur() != null)
      {
        return false;
      }
    }
    else if (!expected.getLibelleErreur().equals(actual.getLibelleErreur()))
    {
      return false;
    }
    if (expected.getNbRelance() == null)
    {
      if (actual.getNbRelance() != null)
      {
        return false;
      }
    }
    else if (!expected.getNbRelance().equals(actual.getNbRelance()))
    {
      return false;
    }
    if (expected.getStatut() == null)
    {
      if (actual.getStatut() != null)
      {
        return false;
      }
    }
    else if (!expected.getStatut().equals(actual.getStatut()))
    {
      return false;
    }
    if (expected.getTypeNotificationReseau() == null)
    {
      if (actual.getTypeNotificationReseau() != null)
      {
        return false;
      }
    }
    else if (!expected.getTypeNotificationReseau().equals(actual.getTypeNotificationReseau()))
    {
      return false;
    }

    return true;

  }

  /**
   * @param retour_p
   *          {@link Retour}
   * @return {@link Pair}
   */
  private Pair<Retour, ReponseErreur> createBL002Retour(Retour retour_p)
  {
    ReponseErreur reponseErreur = null;

    if (RetourFactory.isRetourNOK(retour_p))
    {
      reponseErreur = new ReponseErreur();
      reponseErreur.setError(retour_p.getDiagnostic());
      reponseErreur.setErrorDescription(retour_p.getLibelle());
    }

    return new Pair<>(retour_p, reponseErreur);
  }

  /**
   * @param notificationReseauSti_p
   *          {@link PE0341_NotificationReseauSTI}
   * @param idNotificationReseau_p
   *          {@link String}
   * @return {@link AbstractNotificationReseau}
   */
  private AbstractNotificationReseau createNotificationReseuBySTI(PE0341_NotificationReseauSTI notificationReseauSti_p, String idNotificationReseau_p)
  {
    String typeNotificationReseau = null;

    if (NotificationReseauType.RECOMMANDATION_TV.name().equals(notificationReseauSti_p.getTypeEvenement()))
    {
      typeNotificationReseau = NotificationReseauType.RECOMMANDATION_TV.name();
    }
    else
    {
      typeNotificationReseau = NotificationReseauType.ONT_INCONNU.name();
    }

    AbstractNotificationReseau notificationReseau = null;

    if (NotificationReseauType.ONT_INCONNU.name().equals(typeNotificationReseau))
    {
      NotificationReseauONTInconnuJSON notificationReseauONT = new NotificationReseauONTInconnuJSON();
      notificationReseauONT.setNomOlt(notificationReseauSti_p.getDonneeOntInconnu().getNomOLT());
      notificationReseauONT.setPositionCartePon(notificationReseauSti_p.getDonneeOntInconnu().getSlot().toString());
      notificationReseauONT.setPositionPon(notificationReseauSti_p.getDonneeOntInconnu().getPort().toString());
      notificationReseauONT.setSlid(notificationReseauSti_p.getDonneeOntInconnu().getSlid());

      notificationReseau = notificationReseauONT;
    }
    else
    {
      NotificationReseauRecommandationTvJSON notificationReseauRecommandation = new NotificationReseauRecommandationTvJSON();
      notificationReseauRecommandation.setClientOperateur(notificationReseauSti_p.getPfi().getClientOperateur());
      notificationReseauRecommandation.setNoCompte(notificationReseauSti_p.getPfi().getNoCompte());

      notificationReseau = notificationReseauRecommandation;
    }

    LocalDateTime dateReception = null;
    LocalDateTime dateGenerationEvenementReseau = null;

    if (notificationReseauSti_p.getDateReception() == null)
    {
      dateReception = DateTimeManager.getInstance().now();
    }
    else
    {
      dateReception = notificationReseauSti_p.getDateReception();
    }

    if (notificationReseauSti_p.getDateGenerationEvenementReseau() == null)
    {
      dateGenerationEvenementReseau = dateReception;
    }
    else
    {
      dateGenerationEvenementReseau = notificationReseauSti_p.getDateGenerationEvenementReseau();
    }

    notificationReseau.setIdNotificationReseau(idNotificationReseau_p);
    notificationReseau.setTypeNotificationReseau(typeNotificationReseau);
    notificationReseau.setStatut(NotificationReseauStatut.ACQUITTE.name());
    notificationReseau.setDateReception(dateReception);
    notificationReseau.setDateGenerationEvenementReseau(dateGenerationEvenementReseau);
    notificationReseau.setNbRelance(0);
    return notificationReseau;
  }

  /**
   * @param datesNull
   *          {@link Boolean}
   * @return {@link Pair}
   * @throws RavelException
   *           en cas d'error
   */
  private Pair<PE0341_NotificationReseauSTI, Request> createRequestOntInconnu(boolean datesNull) throws RavelException
  {
    String typeEvenement = NotificationReseauTypeEvenement.THE_GPON_ONT_IS_DISCOVERED_BY_OLT.getDisplayName();
    DonneesOntInconnu donneesOntInconnu = new DonneesOntInconnu(NOM_OLT, 2, 80, SLID);
    PE0341_NotificationReseauSTI notificationReseauSti = new PE0341_NotificationReseauSTI(typeEvenement, donneesOntInconnu, null);
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
    if (datesNull)
    {
      notificationReseauSti.setDateReception(DateTimeManager.getInstance().now());
      notificationReseauSti.setDateGenerationEvenementReseau(DateTimeManager.getInstance().now());
    }
    return new Pair<>(notificationReseauSti, prepareRequest(HttpConstants.POST_METHOD, notificationReseauSti, headers));
  }

  /**
   * @param datesNull
   *          {@link Boolean}
   * @return {@link Pair}
   * @throws RavelException
   *           en cas d'error
   */
  private Pair<PE0341_NotificationReseauSTI, Request> createRequestRecommandationTv(boolean datesNull) throws RavelException
  {
    String typeEvenement = NotificationReseauTypeEvenement.RECOMMANDATION_TV.getDisplayName();
    Pfi pfi = new Pfi("BSS_GP", "noCompte"); //$NON-NLS-1$ //$NON-NLS-2$
    PE0341_NotificationReseauSTI notificationReseauSti = new PE0341_NotificationReseauSTI(typeEvenement, null, pfi);
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
    if (!datesNull)
    {
      notificationReseauSti.setDateReception(DateTimeManager.getInstance().now());
      notificationReseauSti.setDateGenerationEvenementReseau(DateTimeManager.getInstance().now());
    }

    return new Pair<>(notificationReseauSti, prepareRequest(HttpConstants.POST_METHOD, notificationReseauSti, headers));
  }

  /**
   * Execute start process.
   *
   * @param request_p
   *          The input request.
   * @param processName_p
   *          The process name.
   * @return The response.
   * @throws Throwable
   *           The throwable.
   */
  private Response executeStartPostProcess(Request request_p, String processName_p) throws Throwable
  {
    Response ret = null;
    request_p.setOperation(processName_p);
    _processInstance.startPostProcess(request_p, _tracabilite);
    ret = (Response) request_p.getResponse();
    return ret;
  }

  /**
   * Execute start process.
   *
   * @param request_p
   *          The input request.
   * @param processName_p
   *          The process name.
   * @return The response.
   * @throws Throwable
   *           The throwable.
   */
  private Response executeStartPutProcess(Request request_p, String processName_p) throws Throwable
  {
    Response ret = null;
    request_p.setOperation(processName_p);
    _processInstance.startPutProcess(request_p, _tracabilite);
    ret = (Response) request_p.getResponse();
    return ret;
  }

  /**
   * @param retour
   *          {@link Retour}
   * @param compenser
   *          true s'il faut compenser le traitement. {@link Boolean}
   * @param nbrCompensation
   *          Nombre de compensations.
   * @param delai
   *          {@link Boolean}
   * @throws Exception
   *           if error
   */
  private void mockBL500(Retour retour, boolean compenser, Integer nbrCompensation, Integer delai) throws Exception
  {
    mockBL500(retour, compenser, nbrCompensation, delai, false);
  }

  /**
   * @param retour
   *          {@link Retour}
   * @param compenser
   *          true s'il faut compenser le traitement. {@link Boolean}
   * @param nbrCompensation
   *          Nombre de compensations.
   * @param delai
   *          {@link Boolean}
   * @param lancerException
   *          {@link Boolean}
   * @throws Exception
   *           if error
   */
  private void mockBL500(Retour retour, boolean compenser, Integer nbrCompensation, Integer delai, boolean lancerException) throws Exception
  {
    PowerMock.expectNew(PE0341_BL500_TraiterNotificationReseauBuilder.class).andReturn(_pe0341_BL500_TraiterNotificationReseauBuilder);
    EasyMock.expect(_pe0341_BL500_TraiterNotificationReseauBuilder.tracabilite(_tracabilite)).andReturn(_pe0341_BL500_TraiterNotificationReseauBuilder);
    EasyMock.expect(_pe0341_BL500_TraiterNotificationReseauBuilder.configurationAChaudPE(EasyMock.anyObject())).andReturn(_pe0341_BL500_TraiterNotificationReseauBuilder);
    EasyMock.expect(_pe0341_BL500_TraiterNotificationReseauBuilder.nombreCompensation(EasyMock.anyInt())).andReturn(_pe0341_BL500_TraiterNotificationReseauBuilder);
    EasyMock.expect(_pe0341_BL500_TraiterNotificationReseauBuilder.notificationReseau(EasyMock.anyObject())).andReturn(_pe0341_BL500_TraiterNotificationReseauBuilder);
    EasyMock.expect(_pe0341_BL500_TraiterNotificationReseauBuilder.build()).andReturn(_pe0341_BL500_TraiterNotificationReseau);

    if (!lancerException)
    {
      TraiterNotificationReturn bl500Return = new TraiterNotificationReturn(compenser, null, delai);
      bl500Return.setNombreCompensation(nbrCompensation);
      EasyMock.expect(_pe0341_BL500_TraiterNotificationReseau.execute(_processInstance)).andReturn(bl500Return);
    }
    else
    {
      EasyMock.expect(_pe0341_BL500_TraiterNotificationReseau.execute(_processInstance)).andThrow(new RavelException(ExceptionType.TIMEOUT, ErrorCode.CNCTOR_00010, "timeout")); //$NON-NLS-1$
    }
    EasyMock.expect(_pe0341_BL500_TraiterNotificationReseau.getRetour()).andReturn(retour).anyTimes();
  }

  /**
   * @param retour
   *          {@link Retour}
   * @param returnNull
   *          {@link Boolean}
   * @throws Exception
   *           if error
   */
  private void mockBL5400(Retour retour, boolean returnNull) throws Exception
  {
    PowerMock.expectNew(BL5400_DecoderSlidBuilder.class).andReturn(_bl5400BuilderMock);
    EasyMock.expect(_bl5400BuilderMock.tracabilite(_tracabilite)).andReturn(_bl5400BuilderMock);
    EasyMock.expect(_bl5400BuilderMock.slid(SLID)).andReturn(_bl5400BuilderMock);
    EasyMock.expect(_bl5400BuilderMock.build()).andReturn(_bl5400Mock);

    if (returnNull)
    {
      EasyMock.expect(_bl5400Mock.execute(_processInstance)).andReturn(null);
    }
    else
    {
      BL5400_Return bl5400_Return = new BL5400_Return();
      bl5400_Return.setNumeroSerieOnt("1234567"); //$NON-NLS-1$
      EasyMock.expect(_bl5400Mock.execute(_processInstance)).andReturn(bl5400_Return);
    }
    EasyMock.expect(_bl5400Mock.getRetour()).andReturn(retour).anyTimes();
  }

  /**
   * @param retour
   *          {@link Retour}
   * @throws Exception
   *           if error
   */
  private void mockBL800(Retour retour) throws Exception
  {
    PowerMock.expectNew(BL800_ObtenirSequenceBuilder.class).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.tracabilite(_tracabilite)).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.code(UniqueIdConstant.ID_NOTIFICATION_RESEAU)).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.build()).andReturn(_bl800Mock);
    EasyMock.expect(_bl800Mock.execute(_processInstance)).andReturn(ID_NOTIFICATION_RESEAU);
    EasyMock.expect(_bl800Mock.getRetour()).andReturn(retour).anyTimes();
  }

  /**
   * prepareGetRequest
   *
   * @param methode_p
   *          {@link String}
   * @param notificationReseauSti_p
   *          {@link PE0341_NotificationReseauSTI}
   * @param headers
   *          {@link List}
   *
   * @return {@link Request}
   * @throws RavelException
   *           {@link RavelException}
   */
  private Request prepareRequest(String methode_p, PE0341_NotificationReseauSTI notificationReseauSti_p, List<RequestHeader> headers) throws RavelException
  {

    Request request = new Request(DEFAULT_PROCESSNAME, "idProcess", "idClient"); //$NON-NLS-1$ //$NON-NLS-2$
    request.setHttpMethod(methode_p);
    request.setMsgId(Test_Consts.DEFAULT_MSGID);
    String payload = RavelJsonTools.getInstance().toJson(notificationReseauSti_p, PE0341_NotificationReseauSTI.class);
    request.setPayload(payload);
    request.setRequestHeader(headers);

    return request;
  }

  /**
   * preparePutRequest
   *
   * @param headers
   *          {@link List}
   * @return {@link Request}
   * @throws RavelException
   *           if error
   */
  private Request prepareRequestPut(List<RequestHeader> headers) throws RavelException
  {
    Request request = new Request(DEFAULT_PROCESSNAME, "idProcess", "idClient"); //$NON-NLS-1$ //$NON-NLS-2$
    request.setHttpMethod("PUT"); //$NON-NLS-1$
    request.setMsgId(Test_Consts.DEFAULT_MSGID);
    request.setRequestHeader(headers);
    PE0341_NotificationReseauPut notificationReseauPutBody = new PE0341_NotificationReseauPut();
    notificationReseauPutBody.setAction("relance"); //$NON-NLS-1$
    String payload = RavelJsonTools.getInstance().toJson(notificationReseauPutBody, PE0341_NotificationReseauPut.class);
    request.setPayload(payload);
    return request;

  }

}
