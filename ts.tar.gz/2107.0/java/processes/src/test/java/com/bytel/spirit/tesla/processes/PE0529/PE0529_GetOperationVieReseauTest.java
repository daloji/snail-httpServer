/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.tesla.processes.PE0529;

import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.HttpMethod;
import javax.ws.rs.core.MediaType;

import org.easymock.EasyMock;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PowerMockListener;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.testlisteners.FieldDefaulter;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.modules.junit4.PowerMockRunnerDelegate;
import org.springframework.test.context.ContextConfiguration;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.data.exchange.generated.RavelRequest.RequestHeader;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.test.JUnitTools;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.test.podam.PodamBytelJUnit4ClassRunner;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.utils.Test_Consts;
import com.bytel.spirit.common.connectors.rex.REXProxy;
import com.bytel.spirit.common.shared.functional.types.json.RavelJsonTools;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.error.ReponseErreur;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.rex.ClientImpacte;
import com.bytel.spirit.common.shared.saab.rex.OperationVieReseau;
import com.bytel.spirit.tesla.shared.types.PE0529.request.PE0529_PostRequest;
import com.bytel.spirit.tesla.shared.types.PE0529.response.PE0529_GetResponse;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 * Classe de test pour la requête GET du processus {@link PE0529_OperationVieReseau}
 *
 * @author BSINQUIN
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PowerMockListener(FieldDefaulter.class)
@PowerMockRunnerDelegate(PodamBytelJUnit4ClassRunner.class)
@ContextConfiguration("classpath:BeansProcessTestMocks.xml") //$NON-NLS-1$
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" }) //$NON-NLS-1$ //$NON-NLS-2$
@PrepareForTest({ PE0529_OperationVieReseau.class, REXProxy.class })
public class PE0529_GetOperationVieReseauTest
{
  /**
   * ID Operation Vie Reseau
   */
  private static final String ID_OPERATION_VIE_RESEAU = "idOperationVieReseau"; //$NON-NLS-1$

  /**
   * The default process name.
   */
  public static final String DEFAULT_PROCESSNAME = "PE0529_OperationVieReseau"; //$NON-NLS-1$

  /**
   * bean Factory generation
   */
  private static PodamFactory __podam = new PodamFactoryImpl();

  /**
   * Initialize before all tests
   *
   * @throws Exception
   *           On errors Exception to be thrown in case of failure
   */
  @BeforeClass
  public static void setUpBeforeClass() throws Exception
  {
    __podam.getStrategy().setMemoization(false);
    __podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());
  }

  @MockStrict
  protected REXProxy _rexProxyMock;

  /**
   * Instance to evaluate
   */
  private PE0529_OperationVieReseau _processInstance;

  /**
   * Tracabilite
   */
  Tracabilite _tracabilite;

  /**
   * <b>Cas de test:</b> Header manquant en entrée X-Source </br>
   * <b>Attendu:</b> Retour NOK
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_GET_BL001_KO_002() throws Throwable
  {
    Request request = new Request(DEFAULT_PROCESSNAME, "idProcess", "idClient"); //$NON-NLS-1$ //$NON-NLS-2$
    request.setHttpMethod(HttpMethod.GET);
    request.setMsgId(Test_Consts.DEFAULT_MSGID);
    List<RequestHeader> headers = addXHeaders(__podam.manufacturePojoWithFullData(String.class), //
        __podam.manufacturePojoWithFullData(String.class), //
        null, //
        __podam.manufacturePojoWithFullData(String.class), //
        __podam.manufacturePojoWithFullData(String.class), //
        __podam.manufacturePojoWithFullData(String.class));
    request.setRequestHeader(headers);

    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startGetProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals("Le entête \"X-Source\" est vide.", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegSpiritConsts.DONNEE_INVALIDE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> Header manquant en entrée X-Process</br>
   * <b>Attendu:</b> Retour NOK
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_GET_BL001_KO_003() throws Throwable
  {
    Request request = new Request(DEFAULT_PROCESSNAME, "idProcess", "idClient"); //$NON-NLS-1$ //$NON-NLS-2$
    request.setHttpMethod(HttpMethod.GET);
    request.setMsgId(Test_Consts.DEFAULT_MSGID);
    List<RequestHeader> headers = addXHeaders(__podam.manufacturePojoWithFullData(String.class), null, __podam.manufacturePojoWithFullData(String.class), __podam.manufacturePojoWithFullData(String.class), __podam.manufacturePojoWithFullData(String.class), __podam.manufacturePojoWithFullData(String.class));
    request.setRequestHeader(headers);

    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startGetProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals("Le entête \"X-Process\" est vide.", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegSpiritConsts.DONNEE_INVALIDE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> Header manquant en entrée X-Message-Id</br>
   * <b>Attendu:</b> Retour NOK
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_GET_BL001_KO_004() throws Throwable
  {
    Request request = new Request(DEFAULT_PROCESSNAME, "idProcess", "idClient"); //$NON-NLS-1$ //$NON-NLS-2$
    request.setHttpMethod(HttpMethod.GET);
    request.setMsgId(Test_Consts.DEFAULT_MSGID);
    List<RequestHeader> headers = addXHeaders(__podam.manufacturePojoWithFullData(String.class), __podam.manufacturePojoWithFullData(String.class), __podam.manufacturePojoWithFullData(String.class), null, __podam.manufacturePojoWithFullData(String.class), __podam.manufacturePojoWithFullData(String.class));
    request.setRequestHeader(headers);

    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startGetProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals("Le entête \"X-Message-Id\" est vide.", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegSpiritConsts.DONNEE_INVALIDE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> Header manquant en entrée X-Message-Id</br>
   * <b>Attendu:</b> Retour NOK
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_GET_BL001_KO_005() throws Throwable
  {
    Request request = new Request(DEFAULT_PROCESSNAME, "idProcess", "idClient"); //$NON-NLS-1$ //$NON-NLS-2$
    request.setHttpMethod(HttpMethod.GET);
    request.setMsgId(Test_Consts.DEFAULT_MSGID);
    List<RequestHeader> headers = addXHeaders(__podam.manufacturePojoWithFullData(String.class), __podam.manufacturePojoWithFullData(String.class), __podam.manufacturePojoWithFullData(String.class), null, __podam.manufacturePojoWithFullData(String.class), __podam.manufacturePojoWithFullData(String.class));
    request.setRequestHeader(headers);

    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startGetProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals("Le entête \"X-Message-Id\" est vide.", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegSpiritConsts.DONNEE_INVALIDE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> Header manquant en entrée X-Action-Id</br>
   * <b>Attendu:</b> Retour NOK
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_GET_BL001_KO_006() throws Throwable
  {
    Request request = new Request(DEFAULT_PROCESSNAME, "idProcess", "idClient"); //$NON-NLS-1$ //$NON-NLS-2$
    request.setHttpMethod(HttpMethod.GET);
    request.setMsgId(Test_Consts.DEFAULT_MSGID);
    List<RequestHeader> headers = addXHeaders(__podam.manufacturePojoWithFullData(String.class), //
        __podam.manufacturePojoWithFullData(String.class), //
        __podam.manufacturePojoWithFullData(String.class), //
        __podam.manufacturePojoWithFullData(String.class), //
        null, //
        __podam.manufacturePojoWithFullData(String.class));
    request.setRequestHeader(headers);

    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startGetProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals("Le entête \"X-Action-Id\" est vide.", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegSpiritConsts.DONNEE_INVALIDE, reponseactual.getError());

  }

  /**
   *
   * <b>Cas de test:</b> paramètre idOperationVieReseau absent</br>
   * <b>Attendu:</b> Retour NOK
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_GET_BL001_KO_007() throws Throwable
  {
    Request request = new Request(DEFAULT_PROCESSNAME, "idProcess", "idClient"); //$NON-NLS-1$ //$NON-NLS-2$
    request.setHttpMethod(HttpMethod.GET);
    request.setMsgId(Test_Consts.DEFAULT_MSGID);
    List<RequestHeader> headers = addXHeaders(__podam.manufacturePojoWithFullData(String.class), __podam.manufacturePojoWithFullData(String.class), __podam.manufacturePojoWithFullData(String.class), __podam.manufacturePojoWithFullData(String.class), __podam.manufacturePojoWithFullData(String.class), __podam.manufacturePojoWithFullData(String.class));
    request.setRequestHeader(headers);

    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startGetProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals("Le paramètre \"idOperationVieReseau\", dans la requête, avec le valeur \"null\" est vide ou invalide.", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegSpiritConsts.DONNEE_INVALIDE, reponseactual.getError());
  }

  /**
   *
   * <b>Cas de test:</b> paramètre idOperationVieReseau absent (URI parameters vide)</br>
   * <b>Attendu:</b> Retour NOK
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_GET_BL001_KO_007b() throws Throwable
  {
    Request request = new Request(DEFAULT_PROCESSNAME, "idProcess", "idClient"); //$NON-NLS-1$ //$NON-NLS-2$
    request.setHttpMethod(HttpMethod.GET);
    request.setMsgId(Test_Consts.DEFAULT_MSGID);
    List<RequestHeader> headers = addXHeaders(__podam.manufacturePojoWithFullData(String.class), __podam.manufacturePojoWithFullData(String.class), __podam.manufacturePojoWithFullData(String.class), __podam.manufacturePojoWithFullData(String.class), __podam.manufacturePojoWithFullData(String.class), __podam.manufacturePojoWithFullData(String.class));
    request.setRequestHeader(headers);
    request.setUrlDynamicParameters(null);

    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startGetProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseActual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals("Le paramètre \"idOperationVieReseau\", dans la requête, avec le valeur \"null\" est vide ou invalide.", reponseActual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegSpiritConsts.DONNEE_INVALIDE, reponseActual.getError());
  }

  /**
   * <b>Cas de test:</b> Donnee brutes null <br/>
   * <b>Attendu:</b> Reponse en erreur du processus
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_GET_BL100_KO_001() throws Throwable
  {
    //Prepare request
    Request request = new Request(DEFAULT_PROCESSNAME, "idProcess", "idClient"); //$NON-NLS-1$ //$NON-NLS-2$
    request.setHttpMethod(HttpMethod.GET);
    request.setMsgId(Test_Consts.DEFAULT_MSGID);
    List<RequestHeader> headers = addXHeaders(__podam.manufacturePojoWithFullData(String.class), __podam.manufacturePojoWithFullData(String.class), __podam.manufacturePojoWithFullData(String.class), __podam.manufacturePojoWithFullData(String.class), __podam.manufacturePojoWithFullData(String.class), __podam.manufacturePojoWithFullData(String.class));
    request.setRequestHeader(headers);
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    request.setUrlDynamicParameters(idOperationVieReseau);

    //Prepare mocks responses
    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxyMock);
    EasyMock.expect(_rexProxyMock.operationVieReseauLireUn(_tracabilite, idOperationVieReseau))//
        .andThrow(new RavelException(ExceptionType.UNDEFINED, ErrorCode.CNCTOR_00010, "Exception")); //$NON-NLS-1$

    //Execute tests
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startGetProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();

    //Checks
    PowerMock.verifyAll();

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    Assert.assertEquals("Exception", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegConsts.TRAITEMENT_ARRETE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> Reponse NOK de REX <br/>
   * <b>Attendu:</b> Reponse en erreur du processus
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_GET_BL100_KO_002() throws Throwable
  {
    //Prepare request
    Request request = new Request(DEFAULT_PROCESSNAME, "idProcess", "idClient"); //$NON-NLS-1$ //$NON-NLS-2$
    request.setHttpMethod(HttpMethod.GET);
    request.setMsgId(Test_Consts.DEFAULT_MSGID);
    List<RequestHeader> headers = addXHeaders(__podam.manufacturePojoWithFullData(String.class), __podam.manufacturePojoWithFullData(String.class), __podam.manufacturePojoWithFullData(String.class), __podam.manufacturePojoWithFullData(String.class), __podam.manufacturePojoWithFullData(String.class), __podam.manufacturePojoWithFullData(String.class));
    request.setRequestHeader(headers);
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    request.setUrlDynamicParameters(idOperationVieReseau);

    //Prepare mocks responses
    OperationVieReseau mockedResponseOpVieReseau = __podam.manufacturePojoWithFullData(OperationVieReseau.class);
    JUnitTools.setInaccessibleFieldValue(mockedResponseOpVieReseau, "_donneeBrute", null); //$NON-NLS-1$
    ConnectorResponse<Retour, OperationVieReseau> rexResponse = new ConnectorResponse<Retour, OperationVieReseau>(RetourFactory.createOkRetour(), mockedResponseOpVieReseau);
    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxyMock);
    EasyMock.expect(_rexProxyMock.operationVieReseauLireUn(_tracabilite, idOperationVieReseau)).andReturn(rexResponse);

    //Execute tests
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startGetProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();

    //Checks
    PowerMock.verifyAll();

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    Assert.assertEquals("Donnee brute de l'Operation " + idOperationVieReseau + " null ou format incorrect.", reponseactual.getErrorDescription()); //$NON-NLS-1$ //$NON-NLS-2$
    Assert.assertEquals(IMegConsts.TRAITEMENT_ARRETE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> OK </br>
   * <b>Attendu:</b> Reponse 200 OK
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_GET_BL100_OK_001() throws Throwable
  {
    //Prepare request
    Request request = new Request(DEFAULT_PROCESSNAME, "idProcess", "idClient"); //$NON-NLS-1$ //$NON-NLS-2$
    request.setHttpMethod(HttpMethod.GET);
    request.setMsgId(Test_Consts.DEFAULT_MSGID);
    List<RequestHeader> headers = addXHeaders(__podam.manufacturePojoWithFullData(String.class), //
        __podam.manufacturePojoWithFullData(String.class), //
        __podam.manufacturePojoWithFullData(String.class), //
        __podam.manufacturePojoWithFullData(String.class), //
        __podam.manufacturePojoWithFullData(String.class), //
        __podam.manufacturePojoWithFullData(String.class));
    request.setRequestHeader(headers);
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    request.setUrlDynamicParameters(idOperationVieReseau);

    //Prepare mocks responses

    //Mock response of REX LireUn
    PE0529_PostRequest mockedDonneesBrutes = __podam.manufacturePojoWithFullData(PE0529_PostRequest.class);
    String donneesBrutes = RavelJsonTools.getInstance().toJson(mockedDonneesBrutes, PE0529_PostRequest.class);
    OperationVieReseau mockedResponseOpVieReseau = __podam.manufacturePojoWithFullData(OperationVieReseau.class);
    JUnitTools.setInaccessibleFieldValue(mockedResponseOpVieReseau, "_donneeBrute", donneesBrutes); //$NON-NLS-1$

    ConnectorResponse<Retour, OperationVieReseau> rexResponse = new ConnectorResponse<Retour, OperationVieReseau>(RetourFactory.createOkRetour(), mockedResponseOpVieReseau);

    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxyMock);
    EasyMock.expect(_rexProxyMock.operationVieReseauLireUn(_tracabilite, idOperationVieReseau)).andReturn(rexResponse);

    //Execute tests
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startGetProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();

    //Checks
    PowerMock.verifyAll();

    PE0529_GetResponse actualGetReponse = RavelJsonTools.getInstance().fromJson(response.getGenericResponse().getResult(), PE0529_GetResponse.class);

    //On repart de l'objet serialisé car le format des dates est transformé à la serialisation
    PE0529_PostRequest expectedDonneesBrutes = RavelJsonTools.getInstance().fromJson(donneesBrutes, PE0529_PostRequest.class);
    PE0529_GetResponse expectedResponse = new PE0529_GetResponse(mockedResponseOpVieReseau.getIdOperationVieReseau(), //
        mockedResponseOpVieReseau.getStatut(), //
        mockedResponseOpVieReseau.getDateCreation().truncatedTo(ChronoUnit.MILLIS), //Truncated to millisecond as in serialized JSON
        mockedResponseOpVieReseau.getDateAnnulation().truncatedTo(ChronoUnit.MILLIS), //
        mockedResponseOpVieReseau.getDateExecution().truncatedTo(ChronoUnit.MILLIS), //
        mockedResponseOpVieReseau.getTypeOperationVieReseau(), //
        mockedResponseOpVieReseau.getIdOperationVieReseauLie(), //
        mockedResponseOpVieReseau.getNumeroGCR());

    expectedResponse = RavelJsonTools.getInstance().fromJson(rexResponse._second.getDonneeBrute(), PE0529_GetResponse.class);
    expectedResponse.setDateAnnulation(mockedResponseOpVieReseau.getDateAnnulation());
    expectedResponse.setDateCreation(mockedResponseOpVieReseau.getDateCreation());
    expectedResponse.setDateExecution(mockedResponseOpVieReseau.getDateExecution());

    expectedResponse.setIdOperationVieReseauLie(mockedResponseOpVieReseau.getIdOperationVieReseauLie());

    List<ClientImpacte> listeClientImpacte = new ArrayList<>();
    listeClientImpacte.addAll(mockedResponseOpVieReseau.getListeClientImpacte());

    expectedResponse.setNumeroGCR(mockedResponseOpVieReseau.getNumeroGCR());
    expectedResponse.setStatut(mockedResponseOpVieReseau.getStatut());
    expectedResponse.setTypeVieReseau(mockedResponseOpVieReseau.getTypeOperationVieReseau());

    Assert.assertEquals(ErrorCode.OK_00200, response.getErrorCode());

    Assert.assertEquals(mockedResponseOpVieReseau.getIdOperationVieReseau(), actualGetReponse.getIdOperationVieReseau());
    Assert.assertEquals(mockedResponseOpVieReseau.getStatut(), actualGetReponse.getStatut());

    //les dates sont tronquées à la millisecond car c'est perdu dans la serialisation JSON
    Assert.assertEquals(mockedResponseOpVieReseau.getDateCreation().truncatedTo(ChronoUnit.MILLIS), actualGetReponse.getDateCreation());
    Assert.assertEquals(mockedResponseOpVieReseau.getDateExecution().truncatedTo(ChronoUnit.MILLIS), actualGetReponse.getDateExecution());
    Assert.assertEquals(mockedResponseOpVieReseau.getDateAnnulation().truncatedTo(ChronoUnit.MILLIS), actualGetReponse.getDateAnnulation());

    Assert.assertEquals(mockedResponseOpVieReseau.getNumeroGCR(), actualGetReponse.getNumeroGCR());
    Assert.assertEquals(mockedResponseOpVieReseau.getIdOperationVieReseauLie(), actualGetReponse.getIdOperationVieReseauLie());
    Assert.assertEquals(mockedResponseOpVieReseau.getTypeOperationVieReseau(), actualGetReponse.getTypeVieReseau());

    Assert.assertEquals(mockedResponseOpVieReseau.getTypeOperationVieReseau(), actualGetReponse.getTypeVieReseau());
    Assert.assertEquals(expectedDonneesBrutes.getListeTypeEquipementImpacte(), actualGetReponse.getListeTypeEquipementImpacte());

    Assert.assertEquals(expectedDonneesBrutes.getMigrationsPortsPm(), actualGetReponse.getMigrationsPortsPm());
    Assert.assertEquals(expectedDonneesBrutes.getModificationsPortsPm(), actualGetReponse.getModificationsPortsPm());
    Assert.assertEquals(expectedDonneesBrutes.getAjoutsPortsPm(), actualGetReponse.getAjoutsPortsPm());
    Assert.assertEquals(expectedDonneesBrutes.getSuppressionsPortsPm(), actualGetReponse.getSuppressionsPortsPm());

    Assert.assertEquals(expectedDonneesBrutes.getAjoutsPortsPon(), actualGetReponse.getAjoutsPortsPon());
    Assert.assertEquals(expectedDonneesBrutes.getSuppressionsPortsPon(), actualGetReponse.getSuppressionsPortsPon());
    Assert.assertEquals(expectedDonneesBrutes.getModificationsPortsPon(), actualGetReponse.getModificationsPortsPon());

  }

  /**
   *
   * @throws Exception
   *           On errors Thrown in case of error during switch in attributes of parent class
   */
  @Before
  public void setUp() throws Exception
  {
    _processInstance = new PE0529_OperationVieReseau();
    _processInstance.initializeContext();

    _tracabilite = new Tracabilite();

    PowerMock.resetAll();
    PowerMock.mockStaticStrict(REXProxy.class);
  }

  /**
   * Method that does the needed clean up.<br/>
   *
   * <b>Entrées:</b> N/A for this test method. <br/>
   * <b>Attendu:</b> Clean up of some of our data.
   *
   */
  @After
  public void tearDown()
  {
    _processInstance = null;
  }

  /**
   * Add custom headers
   *
   * @param requestId_p
   *          {@link String}
   * @param process_p
   *          {@link String}
   * @param source_p
   *          {@link String}
   * @param messageId_p
   *          {@link String}
   * @param actionId_p
   *          {@link String}
   * @param authorization_p
   *          {@link String}
   * @return {@link List}
   */
  private List<RequestHeader> addXHeaders(String requestId_p, String process_p, String source_p, String messageId_p, String actionId_p, String authorization_p)
  {
    List<RequestHeader> headers = new ArrayList<>();
    RequestHeader hdr = new RequestHeader();

    hdr.setName(IHttpHeadersConsts.CONTENT_TYPE);
    hdr.setValue(MediaType.APPLICATION_JSON);
    headers.add(hdr);

    if (requestId_p != null)
    {
      hdr = new RequestHeader();
      hdr.setName(IHttpHeadersConsts.X_REQUEST_ID);
      hdr.setValue(requestId_p);
      headers.add(hdr);
    }

    if (source_p != null)
    {
      hdr = new RequestHeader();
      hdr.setName(IHttpHeadersConsts.X_SOURCE);
      hdr.setValue(source_p);
      headers.add(hdr);
    }

    if (process_p != null)
    {
      hdr = new RequestHeader();
      hdr.setName(IHttpHeadersConsts.X_PROCESS);
      hdr.setValue(process_p);
      headers.add(hdr);
    }

    if (messageId_p != null)
    {
      hdr = new RequestHeader();
      hdr.setName(IHttpHeadersConsts.X_MESSAGE_ID);
      hdr.setValue(messageId_p);
      headers.add(hdr);
    }

    if (actionId_p != null)
    {
      hdr = new RequestHeader();
      hdr.setName(IHttpHeadersConsts.X_ACTION_ID);
      hdr.setValue(actionId_p);
      headers.add(hdr);
    }

    if (authorization_p != null)
    {
      hdr = new RequestHeader();
      hdr.setName(IHttpHeadersConsts.AUTHORIZATION);
      hdr.setValue(authorization_p);
      headers.add(hdr);
    }

    return headers;

  }
}
